// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function getCounters() {
  return getRaw("counters");
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getActivity() {
  return getRaw("activity");
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/options.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var form = $("settings-form");
var ownerInput = $("owner");
var repoInput = $("repo");
var branchInput = $("branch");
var patInput = $("pat");
var revealBtn = $("reveal-pat");
var saveStatus = $("save-status");
var connDetail = $("conn-detail");
var accountList = $("account-readonly");
var refreshBtn = $("refresh-accounts");
var diagBox = $("diagnostics");
var copyDiagBtn = $("copy-diagnostics");
var clearStorageBtn = $("clear-storage");
var diagStatus = $("diag-status");
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setStatus(el, kind, msg) {
  el.className = kind ? `status ${kind}` : "status";
  el.textContent = msg;
}
async function loadSettings() {
  const s = await getSettings();
  ownerInput.value = s.owner || DEFAULT_SETTINGS.owner;
  repoInput.value = s.repo || DEFAULT_SETTINGS.repo;
  branchInput.value = s.branch || DEFAULT_SETTINGS.branch;
  if (s.pat) {
    patInput.value = s.pat;
    patInput.placeholder = `\u2026${s.pat.slice(-4)}`;
  }
  await paintConnDetail();
}
async function paintConnDetail() {
  const conn = await getConnection();
  const s = await getSettings();
  const lines = [];
  lines.push(`Status: ${conn.status}`);
  if (conn.login) lines.push(`Logged in as: @${conn.login}`);
  lines.push(`Repository: ${s.owner || "?"}/${s.repo || "?"}@${s.branch || "?"}`);
  if (conn.checkedAt) lines.push(`Last checked: ${conn.checkedAt}`);
  if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
    const resetIso = new Date(conn.rateLimitResetAt * 1e3).toISOString();
    const deltaSec = conn.rateLimitResetAt - Math.floor(Date.now() / 1e3);
    const inLabel = deltaSec <= 0 ? "momentarily" : deltaSec < 60 ? `in ${deltaSec}s` : deltaSec < 3600 ? `in ${Math.round(deltaSec / 60)}m` : `in ${Math.round(deltaSec / 3600)}h`;
    lines.push(`Rate limit resets: ${resetIso} (${inLabel})`);
  }
  if (conn.error) lines.push(`Error: ${conn.error}`);
  connDetail.textContent = lines.join("\n");
}
async function paintAccounts() {
  const list = await getAccounts();
  accountList.replaceChildren();
  for (const a of list) {
    const li = document.createElement("li");
    const handle = document.createElement("span");
    handle.className = "handle";
    handle.textContent = `@${a.handle}`;
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = a.label;
    li.append(handle, label);
    accountList.append(li);
  }
}
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const pat = patInput.value.trim();
  const owner = ownerInput.value.trim();
  const repo = repoInput.value.trim();
  const branch = branchInput.value.trim() || "main";
  if (!pat || !owner || !repo) {
    setStatus(saveStatus, "err", "All fields are required.");
    return;
  }
  setStatus(saveStatus, "", "Saving\u2026");
  await updateSettings({ pat, owner, repo, branch, configuredAt: Date.now() });
  setStatus(saveStatus, "", "Verifying\u2026");
  await send({ type: "verify-connection" });
  await send({ type: "refresh-accounts" });
  const conn = await getConnection();
  if (conn.status === "ok") {
    setStatus(saveStatus, "ok", `Connected as @${conn.login ?? "?"}.`);
  } else if (conn.status === "auth-error") {
    setStatus(saveStatus, "err", "Auth failed \u2014 check the PAT and its repo scope.");
  } else if (conn.status === "rate-limited") {
    setStatus(saveStatus, "warn", "Rate-limited \u2014 token is valid but GitHub is throttling.");
  } else if (conn.status === "network-error") {
    setStatus(saveStatus, "err", "Network error \u2014 check connectivity.");
  } else {
    setStatus(saveStatus, "err", `Verification: ${conn.status}`);
  }
  await paintConnDetail();
  await paintAccounts();
  await refreshDiag();
});
revealBtn.addEventListener("click", () => {
  if (patInput.type === "password") {
    patInput.type = "text";
    revealBtn.textContent = "Hide";
  } else {
    patInput.type = "password";
    revealBtn.textContent = "Show";
  }
});
refreshBtn.addEventListener("click", async () => {
  refreshBtn.disabled = true;
  try {
    await send({ type: "refresh-accounts" });
    await paintAccounts();
    setStatus(diagStatus, "ok", "Accounts refreshed.");
  } catch (err) {
    setStatus(diagStatus, "err", `Refresh failed: ${err.message}`);
  } finally {
    refreshBtn.disabled = false;
  }
});
async function refreshDiag() {
  const [settings, conn, accounts, counters, buffers, activity] = await Promise.all([
    getSettings(),
    getConnection(),
    getAccounts(),
    getCounters(),
    getRunBuffers(),
    getActivity()
  ]);
  const redactedBuffers = Object.fromEntries(
    Object.entries(buffers).map(([k, b]) => [
      k,
      {
        run_id: b.run_id,
        started_at: b.started_at,
        last_capture_at: b.last_capture_at,
        tweets_count: Object.keys(b.tweets_by_id).length,
        observed_count: b.tweet_ids_observed.length,
        endpoints_seen: b.endpoints_seen,
        source_url: b.source_url
      }
    ])
  );
  const dump = {
    version: browser.runtime.getManifest().version,
    user_agent: navigator.userAgent,
    settings: {
      owner: settings.owner,
      repo: settings.repo,
      branch: settings.branch,
      autoCapture: settings.autoCapture,
      configuredAt: settings.configuredAt,
      patSet: settings.pat.length > 0,
      patSuffix: settings.pat.length >= 4 ? settings.pat.slice(-4) : ""
    },
    connection: conn,
    accounts,
    counters,
    runBuffers: redactedBuffers,
    activity_tail_size: activity.length,
    activity_recent: activity.slice(0, 30)
  };
  diagBox.value = JSON.stringify(dump, null, 2);
}
copyDiagBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(diagBox.value);
  setStatus(diagStatus, "ok", "Copied diagnostics to clipboard.");
});
clearStorageBtn.addEventListener("click", async () => {
  const ok = window.confirm(
    "Clear extension storage? This erases your PAT, settings, counters, buffered captures, and activity tail. There is no undo."
  );
  if (!ok) return;
  await clearAll();
  setStatus(diagStatus, "warn", "Storage cleared.");
  await loadSettings();
  await paintAccounts();
  await refreshDiag();
});
void loadSettings();
void paintAccounts();
void refreshDiag();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9vcHRpb25zLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgdHlwZSB7IEFjY291bnRDb25maWcsIFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XHJcbiAgcGF0OiAnJyxcclxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxyXG4gIHJlcG86ICd4JyxcclxuICAvLyBUaGUgcmVwbydzIGN1cnJlbnQgZGVmYXVsdCBicmFuY2ggaXMgXCJtYXN0ZXJcIi4gSWYgeW91IGZvcmsgb3IgcmVuYW1lXHJcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cclxuICBicmFuY2g6ICdtYXN0ZXInLFxyXG4gIGVuYWJsZWQ6IHRydWUsXHJcbiAgYXV0b0NhcHR1cmU6IHRydWUsXHJcbiAgY29uZmlndXJlZEF0OiBudWxsLFxyXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcclxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01BWF9TRUMgPSA2MDtcclxuXHJcbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXHJcbi8vIHJlcG8gaGFzIGJlZW4gaW5pdGlhbGl6ZWQgb3IgUEFUIG1pc2NvbmZpZ3VyZWQpLiBLZXB0IGluIHN5bmMgd2l0aCB0aGUgZmlsZS5cclxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXHJcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdJQ0Vnb3YnLCBsYWJlbDogJ1UuUy4gSW1taWdyYXRpb24gYW5kIEN1c3RvbXMgRW5mb3JjZW1lbnQnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdXaGl0ZUhvdXNlJywgbGFiZWw6ICdUaGUgV2hpdGUgSG91c2UnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1VTRE9MJywgbGFiZWw6ICdVLlMuIERlcGFydG1lbnQgb2YgTGFib3InLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG5dO1xyXG5cclxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cclxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdVc2VyVHdlZXRzJyxcclxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxyXG4gICdVc2VyTWVkaWEnLFxyXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXHJcbiAgJ1R3ZWV0RGV0YWlsJyxcclxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXHJcbiAgJ0xpa2VzJyxcclxuICAnQm9va21hcmtzJyxcclxuICAnSG9tZVRpbWVsaW5lJyxcclxuICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcclxuICAnU2VhcmNoVGltZWxpbmUnLFxyXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxyXG5dKTtcclxuXHJcbi8vIEVuZHBvaW50cyB0aGF0IGNhcnJ5IENvbW11bml0eSBOb3RlIGJvZGllcyBcdTIwMTQgY2FwdHVyZWQgZm9yIGNvbXBsZXRlbmVzcyBidXRcclxuLy8gdGhleSBkb24ndCBpbnRyb2R1Y2UgbmV3IHR3ZWV0cywgc28gdGhleSBkb24ndCBuZWVkIHRvIGJlIGluIFRXRUVUX0VORFBPSU5UUy5cclxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnQmlyZHdhdGNoRmV0Y2hPbmVOb3RlJyxcclxuICAnQmlyZHdhdGNoRmV0Y2hOb3RlcycsXHJcbl0pO1xyXG5cclxuLy8gQXV4aWxpYXJ5IGVuZHBvaW50cyB3ZSBkb24ndCBleHRyYWN0IHR3ZWV0cyBmcm9tIGJ1dCB1c2UgZm9yIGNvbnRleHQgKGUuZy4sXHJcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXHJcbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcclxuXHJcbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxyXG4vLyBjb252ZXJzYXRpb24gXHUyMDE0IGkuZS4gdmlzaXRpbmcgYC88aGFuZGxlPmAgLyBgLzxoYW5kbGU+L3dpdGhfcmVwbGllc2AsXHJcbi8vIGxvb2tpbmcgYXQgb25lIHR3ZWV0LCBldGMuIEV2ZXJ5IHR3ZWV0IHJldHVybmVkIGJ5IHRoZXNlIGVuZHBvaW50cyBpc1xyXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cclxuLy8gKHJldHdlZXRlZCwgcXVvdGVkLCByZXBsaWVkIHRvKSwgc28gd2Uga2VlcCBldmVyeXRoaW5nIHdlIHNlZSByYXRoZXJcclxuLy8gdGhhbiBkcm9wcGluZyBub24tdHJhY2tlZCBhdXRob3JzLiBUaGF0IHdheSBhIHJldHdlZXQgb2YgYSBub24tdHJhY2tlZFxyXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXHJcbi8vXHJcbi8vIEVuZHBvaW50cyBOT1QgaW4gdGhpcyBzZXQgKEhvbWVUaW1lbGluZSwgU2VhcmNoVGltZWxpbmUsIExpa2VzLCBldGMuKVxyXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3NcclxuLy8gXCJCcm93c2luZyBteSBob21lIHRpbWVsaW5lIGlzIGlnbm9yZWRcIiBydWxlLlxyXG5leHBvcnQgY29uc3QgVVNFUl9QQUdFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdVc2VyVHdlZXRzJyxcclxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxyXG4gICdVc2VyTWVkaWEnLFxyXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXHJcbiAgJ1R3ZWV0RGV0YWlsJyxcclxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXHJcbl0pO1xyXG5cclxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XHJcblxyXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xyXG5cclxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcclxuXHJcbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cclxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xyXG5cclxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxyXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcclxuXHJcbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xyXG4iLCAiLyoqXHJcbiAqIGNyeXB0by50cyBcdTIwMTQgYXQtcmVzdCBlbmNyeXB0aW9uIGZvciBzZW5zaXRpdmUgc2V0dGluZ3MgKHRoZSBQQVQpLlxyXG4gKlxyXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcclxuICogZm9yZ290dGVuIGJhY2t1cCwgYSBtaXNjb25maWd1cmVkIHByb2ZpbGUgc3luYykgc2hvdWxkIG5vdCBzZWUgYSB1c2FibGVcclxuICogR2l0SHViIFBBVCBpbiBwbGFpbnRleHQuIEEgZGV0ZXJtaW5lZCBhdHRhY2tlciB3aXRoIHRoZSBleHRlbnNpb24ncyBzb3VyY2VcclxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcclxuICogY29uZmlkZW50aWFsaXR5LiBUaGUgYWltIGlzIHRvIHJhaXNlIHRoZSBiYXIgc28gdGhlIFBBVCBpc24ndCBhIGNvcHlhYmxlXHJcbiAqIHN0cmluZyBzaXR0aW5nIG5leHQgdG8gaXRzIGtleSBuYW1lIGluIGV4dGVuc2lvbiBzdG9yYWdlLlxyXG4gKlxyXG4gKiBTY2hlbWU6XHJcbiAqICAgLSBPbiBmaXJzdCBlbmNyeXB0aW9uIHdlIGdlbmVyYXRlIGEgMzItYnl0ZSBzYWx0IGFuZCBwZXJzaXN0IGl0IGluXHJcbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxyXG4gKiAgIC0gV2UgZGVyaXZlIGFuIEFFUy1HQ00ga2V5IGJ5IFNIQS0yNTYnaW5nIGBzYWx0IHx8IHJ1bnRpbWUuaWQgfHwgdmVyc2lvblxyXG4gKiAgICAgfHwgXCJpbW0tYXJjaGl2ZS1wYXQtdjFcImAuIFRoZSBzYWx0IGJlaW5nIHBlci1pbnN0YWxsIG1lYW5zIHR3byBjb3BpZXNcclxuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xyXG4gKiAgICAgVVVJRCBcdTIwMTQgc3RhYmxlIGZvciBhIGdpdmVuIGluc3RhbGwgYnV0IHVua25vd24gdG8gYSByZW1vdGUgYXR0YWNrZXIuXHJcbiAqICAgLSBQbGFpbnRleHQgaXMgZW5jcnlwdGVkIHdpdGggYSBmcmVzaCAxMi1ieXRlIElWLiBUaGUgZW52ZWxvcGUgZm9ybWF0IGlzXHJcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXHJcbiAqXHJcbiAqIEJhY2t3YXJkcyBjb21wYXRpYmlsaXR5OiBhbiB1bnByZWZpeGVkIHZhbHVlIGlzIHRyZWF0ZWQgYXMgbGVnYWN5XHJcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cclxuICovXHJcblxyXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcclxuY29uc3QgRU5WRUxPUEVfUFJFRklYID0gJ3YxOic7XHJcblxyXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcclxubGV0IGRlcml2ZWRLZXlDYWNoZVNhbHQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xyXG5cclxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcclxuICBsZXQgcyA9ICcnO1xyXG4gIGZvciAoY29uc3QgYiBvZiBidWYpIHMgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShiKTtcclxuICByZXR1cm4gYnRvYShzKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcclxuICBjb25zdCBiaW4gPSBhdG9iKHMpO1xyXG4gIGNvbnN0IG91dCA9IG5ldyBVaW50OEFycmF5KGJpbi5sZW5ndGgpO1xyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBsb2FkT3JDcmVhdGVTYWx0KCk6IFByb21pc2U8eyBzYWx0QjY0OiBzdHJpbmc7IHNhbHQ6IFVpbnQ4QXJyYXkgfT4ge1xyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoU0FMVF9TVE9SQUdFX0tFWSk7XHJcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcclxuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xyXG4gICAgcmV0dXJuIHsgc2FsdEI2NDogdiwgc2FsdDogZnJvbUJhc2U2NCh2KSB9O1xyXG4gIH1cclxuICBjb25zdCBzYWx0ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgzMikpO1xyXG4gIGNvbnN0IHNhbHRCNjQgPSB0b0Jhc2U2NChzYWx0KTtcclxuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xyXG4gIHJldHVybiB7IHNhbHRCNjQsIHNhbHQgfTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZGVyaXZlS2V5KCk6IFByb21pc2U8Q3J5cHRvS2V5PiB7XHJcbiAgY29uc3QgeyBzYWx0QjY0LCBzYWx0IH0gPSBhd2FpdCBsb2FkT3JDcmVhdGVTYWx0KCk7XHJcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XHJcbiAgICByZXR1cm4gZGVyaXZlZEtleUNhY2hlO1xyXG4gIH1cclxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxyXG4gICAgYCR7YnJvd3Nlci5ydW50aW1lLmlkfXwke2Jyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb259fGltbS1hcmNoaXZlLXBhdC12MWBcclxuICApO1xyXG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XHJcbiAgY29tYmluZWQuc2V0KHNlZWQsIDApO1xyXG4gIGNvbWJpbmVkLnNldChzYWx0LCBzZWVkLmxlbmd0aCk7XHJcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xyXG4gIGNvbnN0IGtleSA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuaW1wb3J0S2V5KCdyYXcnLCBoYXNoLCB7IG5hbWU6ICdBRVMtR0NNJyB9LCBmYWxzZSwgW1xyXG4gICAgJ2VuY3J5cHQnLFxyXG4gICAgJ2RlY3J5cHQnLFxyXG4gIF0pO1xyXG4gIGRlcml2ZWRLZXlDYWNoZSA9IGtleTtcclxuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcclxuICByZXR1cm4ga2V5O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaXNFbmNyeXB0ZWRQYXQodjogc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgcmV0dXJuIHYuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5jcnlwdFBhdChwbGFpbnRleHQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcclxuICBjb25zdCBrZXkgPSBhd2FpdCBkZXJpdmVLZXkoKTtcclxuICBjb25zdCBpdiA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTIpKTtcclxuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcclxuICAgIHsgbmFtZTogJ0FFUy1HQ00nLCBpdiB9LFxyXG4gICAga2V5LFxyXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcclxuICApO1xyXG4gIHJldHVybiBgJHtFTlZFTE9QRV9QUkVGSVh9JHt0b0Jhc2U2NChpdil9OiR7dG9CYXNlNjQobmV3IFVpbnQ4QXJyYXkoY3QpKX1gO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVjcnlwdFBhdChlbnZlbG9wZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XHJcbiAgLy8gTGVnYWN5IHBsYWludGV4dCAocHJlLWVuY3J5cHRpb24gaW5zdGFsbHMpOiBwYXNzIHRocm91Z2guIFRoZSBuZXh0IHNhdmVcclxuICAvLyByZS1lbmNyeXB0cyBpdCB2aWEgdGhlIHN0b3JhZ2UgbGF5ZXIuXHJcbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcclxuICBjb25zdCBwYXJ0cyA9IGVudmVsb3BlLnNsaWNlKEVOVkVMT1BFX1BSRUZJWC5sZW5ndGgpLnNwbGl0KCc6Jyk7XHJcbiAgaWYgKHBhcnRzLmxlbmd0aCAhPT0gMikgcmV0dXJuICcnO1xyXG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XHJcbiAgaWYgKCFpdkI2NCB8fCAhY3RCNjQpIHJldHVybiAnJztcclxuICB0cnkge1xyXG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XHJcbiAgICBjb25zdCBpdiA9IGZyb21CYXNlNjQoaXZCNjQpO1xyXG4gICAgY29uc3QgY3QgPSBmcm9tQmFzZTY0KGN0QjY0KTtcclxuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxyXG4gICAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXY6IGl2IGFzIEJ1ZmZlclNvdXJjZSB9LFxyXG4gICAgICBrZXksXHJcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxyXG4gICAgKTtcclxuICAgIHJldHVybiBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUocHQpO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuICcnO1xyXG4gIH1cclxufVxyXG4iLCAiaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUywgRkFMTEJBQ0tfQUNDT1VOVFMsIEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9jb25maWcuanMnO1xyXG5pbXBvcnQgeyBkZWNyeXB0UGF0LCBlbmNyeXB0UGF0LCBpc0VuY3J5cHRlZFBhdCB9IGZyb20gJy4vY3J5cHRvLmpzJztcclxuaW1wb3J0IHR5cGUge1xyXG4gIEFjY291bnRDb25maWcsXHJcbiAgQWNjb3VudENvdW50ZXIsXHJcbiAgQ2Fub25pY2FsVHdlZXQsXHJcbiAgQ29ubmVjdGlvblN0YXRlLFxyXG4gIExvZ0V2ZW50LFxyXG4gIFNldHRpbmdzLFxyXG4gIFVuYXZhaWxhYmxlVHdlZXQsXHJcbn0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG4vKipcclxuICogQnVmZmVyZWQgdHdlZXRzIGZvciBhIGdpdmVuIGFjY291bnQsIGF3YWl0aW5nIGNvbW1pdC4gQSBcInJ1blwiIGlzIG9uZSBlbnRyeVxyXG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcclxuICogc3Vydml2ZXMgSlNPTiBzZXJpYWxpemF0aW9uIHRocm91Z2ggYnJvd3Nlci5zdG9yYWdlLlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xyXG4gIHJ1bl9pZDogc3RyaW5nO1xyXG4gIGFjY291bnRfaGFuZGxlOiBzdHJpbmc7XHJcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xyXG4gIGxhc3RfY2FwdHVyZV9hdDogc3RyaW5nO1xyXG4gIHR3ZWV0c19ieV9pZDogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+O1xyXG4gIHVuYXZhaWxhYmxlX2J5X2lkPzogUmVjb3JkPHN0cmluZywgVW5hdmFpbGFibGVUd2VldD47XHJcbiAgdHdlZXRfaWRzX29ic2VydmVkOiBzdHJpbmdbXTtcclxuICBlbmRwb2ludHNfc2Vlbjogc3RyaW5nW107XHJcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcclxufVxyXG5cclxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxyXG4gKiBVc2VkIHRvIHNraXAgcmUtY2FwdHVyaW5nIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IHB1c2hlZCB3aXRoIGlkZW50aWNhbFxyXG4gKiBlbmdhZ2VtZW50IGNvdW50cyBcdTIwMTQgYXZvaWRzIGdlbmVyYXRpbmcgb25lIG5ldyByYXcvKiBmaWxlIGV2ZXJ5IGJyb3dzZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XHJcbiAgdHM6IHN0cmluZzsgLy8gSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBjb21taXRcclxuICBzaWc6IHN0cmluZzsgLy8gZW5nYWdlbWVudCBzaWduYXR1cmU6IFwibGlrZXxydHxyZXBseXxxdW90ZVwiXHJcbn1cclxuXHJcbi8qKiBQcm9ncmVzcyArIGluZmxpZ2h0IHRyYWNraW5nIGZvciBhIHF1ZXVlLWRyaXZlbiBsb29wIChyZWZldGNoIC8gbWVkaWEtY3Jhd2wpLlxyXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcclxuICogXCJYIG9mIFkgcHJvY2Vzc2VkXCIgXHUyMDE0IGFuZCB0aGUgd2FpdC1mb3ItaW5nZXN0IGd1YXJkIGtub3dzIHdoYXQgdG8gZXhwZWN0LlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XHJcbiAgLyoqIEluaXRpYWwgcXVldWUgc2l6ZSB3aGVuIHRoZSB1c2VyIGNsaWNrZWQgXCJTdGFydFwiLiAqL1xyXG4gIHRvdGFsQXRTdGFydDogbnVtYmVyO1xyXG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cclxuICBwcm9jZXNzZWQ6IG51bWJlcjtcclxuICAvKiogSVNPIG9mIHdoZW4gdGhpcyBzZXNzaW9uIHN0YXJ0ZWQuICovXHJcbiAgc3RhcnRlZEF0OiBzdHJpbmc7XHJcbiAgLyoqIFR3ZWV0IGN1cnJlbnRseSBpbmZsaWdodCBcdTIwMTQgd2UgbmF2aWdhdGVkIHRvIGl0IGFuZCBhcmUgd2FpdGluZyBmb3IgdGhlXHJcbiAgICogcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIHJlc3BvbnNlIGJlZm9yZSBhZHZhbmNpbmcuIG51bGwgYmV0d2VlbiB0aWNrc1xyXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xyXG4gIGluZmxpZ2h0OiB7IHR3ZWV0SWQ6IHN0cmluZzsgbmF2aWdhdGVkQXQ6IHN0cmluZyB9IHwgbnVsbDtcclxufVxyXG5cclxuLyoqIEF1dG8tc2Nyb2xsIHNlc3Npb246IGNvdW50cyBvZiB0aWNrcyBhbmQgdHdlZXRzIGluZ2VzdGVkIHNpbmNlIHRoZSB1c2VyXHJcbiAqIGNsaWNrZWQgU3RhcnQuIFBlcnNpc3RlZCBzbyBTVyBldmljdGlvbiBkdXJpbmcgYSBydW4ga2VlcHMgcHJvZ3Jlc3MuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xyXG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xyXG4gIHNjcm9sbENvdW50OiBudW1iZXI7XHJcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xyXG4gIGV4cGFuZGVkQ291bnQ6IG51bWJlcjtcclxufVxyXG5cclxuaW50ZXJmYWNlIFN0b3JhZ2VTaGFwZSB7XHJcbiAgc2V0dGluZ3M6IFNldHRpbmdzO1xyXG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XHJcbiAgLyoqIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3Qgc3VjY2Vzc2Z1bCBhY2NvdW50cy55YW1sIGZldGNoIGZyb20gdGhlIHJlcG8uXHJcbiAgICogVXNlZCBieSBgcmVmcmVzaEFjY291bnRzTGlzdGAgdG8gc2tpcCByZS1mZXRjaGluZyBvbiBldmVyeSBTVyB3YWtlIFx1MjAxNCB0aGVcclxuICAgKiBmaWxlIGNoYW5nZXMgcmFyZWx5IGFuZCBhbiBhdXRoZW50aWNhdGVkIHJhdyBmZXRjaCBldmVyeSB3YWtlIGFkZHMgdXAuICovXHJcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogc3RyaW5nIHwgbnVsbDtcclxuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uU3RhdGU7XHJcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcclxuICBydW5CdWZmZXJzOiBSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+O1xyXG4gIGFjdGl2aXR5OiBMb2dFdmVudFtdO1xyXG4gIGNvbW1pdHRlZEluZGV4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+O1xyXG4gIC8qKiBUd2VldHMgdGhlIG5vcm1hbGl6ZXIgZmxhZ2dlZCBhcyB0cnVuY2F0ZWQgYW5kIHRoYXQgd2UgaGF2ZW4ndCBzZWVuIGFcclxuICAgKiBmdWxsLXRleHQgdmVyc2lvbiBvZiB5ZXQuIEtleWVkIGJ5IGhhbmRsZSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiAqL1xyXG4gIHJlZmV0Y2hRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xyXG4gIC8qKiBUd2VldCBJRHMgc2VlbiB2aWEgTWVkaWEtdGFiIC8gcGFydGlhbCBjYXB0dXJlcyB0aGF0IGNvdWxkbid0IGJlXHJcbiAgICogbm9ybWFsaXplZCBpbnRvIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIEtleWVkIGJ5IGhpbnQtaGFuZGxlIChvclxyXG4gICAqIFwiX3Vua25vd25cIikgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gVGhlIHVzZXIgY2FuIGRyaXZlIGEgY3Jhd2wgdGhhdFxyXG4gICAqIG9wZW5zIGVhY2ggZGV0YWlsIHBhZ2UgdG8gY2FwdHVyZSB0aGUgcmVhbCB0aGluZy4gKi9cclxuICBtZWRpYUNyYXdsUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcclxuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xyXG4gIG1lZGlhQ3Jhd2xTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XHJcbiAgYXV0b1Njcm9sbFNlc3Npb246IEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbDtcclxufVxyXG5cclxuY29uc3QgREVGQVVMVF9DT05ORUNUSU9OOiBDb25uZWN0aW9uU3RhdGUgPSB7XHJcbiAgc3RhdHVzOiAndW5rbm93bicsXHJcbiAgbG9naW46IG51bGwsXHJcbiAgY2hlY2tlZEF0OiBudWxsLFxyXG4gIGVycm9yOiBudWxsLFxyXG4gIGRlZmF1bHRCcmFuY2g6IG51bGwsXHJcbiAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcclxuICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxyXG59O1xyXG5cclxuY29uc3QgREVGQVVMVFM6IFN0b3JhZ2VTaGFwZSA9IHtcclxuICBzZXR0aW5nczogeyAuLi5ERUZBVUxUX1NFVFRJTkdTIH0sXHJcbiAgYWNjb3VudHM6IFsuLi5GQUxMQkFDS19BQ0NPVU5UU10sXHJcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogbnVsbCxcclxuICBjb25uZWN0aW9uOiB7IC4uLkRFRkFVTFRfQ09OTkVDVElPTiB9LFxyXG4gIGNvdW50ZXJzOiB7fSxcclxuICBydW5CdWZmZXJzOiB7fSxcclxuICBhY3Rpdml0eTogW10sXHJcbiAgY29tbWl0dGVkSW5kZXg6IHt9LFxyXG4gIHJlZmV0Y2hRdWV1ZToge30sXHJcbiAgbWVkaWFDcmF3bFF1ZXVlOiB7fSxcclxuICByZWZldGNoU2Vzc2lvbjogbnVsbCxcclxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcclxuICBhdXRvU2Nyb2xsU2Vzc2lvbjogbnVsbCxcclxufTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEspOiBQcm9taXNlPFN0b3JhZ2VTaGFwZVtLXT4ge1xyXG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoa2V5KTtcclxuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xyXG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICByZXR1cm4gc3RydWN0dXJlZENsb25lKERFRkFVTFRTW2tleV0pO1xyXG4gIH1cclxuICByZXR1cm4gdmFsdWUgYXMgU3RvcmFnZVNoYXBlW0tdO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLLCB2YWx1ZTogU3RvcmFnZVNoYXBlW0tdKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtrZXldOiB2YWx1ZSB9KTtcclxufVxyXG5cclxuLy8gLS0tIFNldHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XHJcbiAgLy8gQmFja2ZpbGwgYW55IGtleXMgdGhlIHVzZXIncyBzdG9yZWQgc2V0dGluZ3MgcHJlZGF0ZSBcdTIwMTQgcmVhZGVycyBjYW4gcmVseVxyXG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XHJcbiAgLy8gZXZlcnkgY2FsbHNpdGUuIFRoZSBQQVQgaXMgc3RvcmVkIGVuY3J5cHRlZC1hdC1yZXN0IGFzIG9mIHYwLjIuMDsgd2VcclxuICAvLyBkZWNyeXB0IHRyYW5zcGFyZW50bHkgc28gY2FsbGVycyBjb250aW51ZSB0byBzZWUgcGxhaW50ZXh0LlxyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcclxuICBjb25zdCBtZXJnZWQgPSB7IC4uLkRFRkFVTFRfU0VUVElOR1MsIC4uLnN0b3JlZCB9O1xyXG4gIGlmIChtZXJnZWQucGF0ICYmIGlzRW5jcnlwdGVkUGF0KG1lcmdlZC5wYXQpKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBtZXJnZWQucGF0ID0gYXdhaXQgZGVjcnlwdFBhdChtZXJnZWQucGF0KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBtZXJnZWQucGF0ID0gJyc7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBtZXJnZWQ7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXHJcbiAgLy8gb24gdGhlIG5leHQgc2F2ZS5cclxuICBjb25zdCB0b1dyaXRlOiBTZXR0aW5ncyA9IHsgLi4ucyB9O1xyXG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XHJcbiAgICB0b1dyaXRlLnBhdCA9IGF3YWl0IGVuY3J5cHRQYXQodG9Xcml0ZS5wYXQpO1xyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHBhdGNoOiBQYXJ0aWFsPFNldHRpbmdzPik6IFByb21pc2U8U2V0dGluZ3M+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IG5leHQgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcclxuICBhd2FpdCBzZXRTZXR0aW5ncyhuZXh0KTtcclxuICByZXR1cm4gbmV4dDtcclxufVxyXG5cclxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50cygpOiBQcm9taXNlPEFjY291bnRDb25maWdbXT4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzKGE6IEFjY291bnRDb25maWdbXSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzUmVmcmVzaGVkQXQoaXNvOiBzdHJpbmcgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcclxufVxyXG5cclxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb24oKTogUHJvbWlzZTxDb25uZWN0aW9uU3RhdGU+IHtcclxuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XHJcbiAgLy8gQmFja2ZpbGwgZmllbGRzIGFkZGVkIGFmdGVyIHRoZSB1c2VyJ3Mgc3RvcmFnZSB3YXMgd3JpdHRlbi5cclxuICBjb25zdCBvdXQ6IENvbm5lY3Rpb25TdGF0ZSA9IHtcclxuICAgIC4uLmMsXHJcbiAgICBkZWZhdWx0QnJhbmNoOiBjLmRlZmF1bHRCcmFuY2ggPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmRlZmF1bHRCcmFuY2gsXHJcbiAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOlxyXG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXHJcbiAgICByYXRlTGltaXRSZXNldEF0OiBjLnJhdGVMaW1pdFJlc2V0QXQgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLnJhdGVMaW1pdFJlc2V0QXQsXHJcbiAgfTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb25uZWN0aW9uKGM6IENvbm5lY3Rpb25TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xyXG59XHJcblxyXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZnVuY3Rpb24gdG9kYXlJU08oKTogc3RyaW5nIHtcclxuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnY291bnRlcnMnKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXHJcbiAgaGFuZGxlOiBzdHJpbmcsXHJcbiAgcGF0Y2g6IFBhcnRpYWw8QWNjb3VudENvdW50ZXI+XHJcbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRDb3VudGVycygpO1xyXG4gIGNvbnN0IGN1ciA9IGFsbFtoYW5kbGVdID8/IHtcclxuICAgIHRvZGF5Q291bnQ6IDAsXHJcbiAgICB0b2RheURhdGU6IHRvZGF5SVNPKCksXHJcbiAgICBsYXN0Q2FwdHVyZUF0OiBudWxsLFxyXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXHJcbiAgICBidWZmZXJlZENvdW50OiAwLFxyXG4gIH07XHJcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcclxuICAgIGN1ci50b2RheURhdGUgPSB0b2RheUlTTygpO1xyXG4gICAgY3VyLnRvZGF5Q291bnQgPSAwO1xyXG4gIH1cclxuICBjb25zdCBuZXh0OiBBY2NvdW50Q291bnRlciA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xyXG4gIGFsbFtoYW5kbGVdID0gbmV4dDtcclxuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcclxuICByZXR1cm4gbmV4dDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlOiBzdHJpbmcsIGNvdW50OiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHsgYnVmZmVyZWRDb3VudDogY291bnQgfSk7XHJcbn1cclxuXHJcbi8vIC0tLSBSdW4gYnVmZmVycyAodGhlIHBlbmRpbmcgY2FwdHVyZXMgYXdhaXRpbmcgY29tbWl0KSAtLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5CdWZmZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3J1bkJ1ZmZlcnMnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8UnVuQnVmZmVyIHwgbnVsbD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICByZXR1cm4gYWxsW2hhbmRsZV0gPz8gbnVsbDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZywgYnVmOiBSdW5CdWZmZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgYWxsW2hhbmRsZV0gPSBidWY7XHJcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyUnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcclxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xyXG59XHJcblxyXG4vLyAtLS0gQWN0aXZpdHkgdGFpbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjdGl2aXR5Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBlbmRBY3Rpdml0eShldjogTG9nRXZlbnQpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRBY3Rpdml0eSgpO1xyXG4gIGN1ci51bnNoaWZ0KGV2KTtcclxuICBpZiAoY3VyLmxlbmd0aCA+IEFDVElWSVRZX1RBSUxfTUFYKSBjdXIubGVuZ3RoID0gQUNUSVZJVFlfVEFJTF9NQVg7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIGN1cik7XHJcbiAgcmV0dXJuIGN1cjtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIFtdKTtcclxufVxyXG5cclxuLy8gLS0tIENvbW1pdHRlZC10d2VldHMgZGVkdXAgaW5kZXggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2NvbW1pdHRlZEluZGV4Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb21taXR0ZWRJbmRleChcclxuICBpZHg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj5cclxuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdjb21taXR0ZWRJbmRleCcsIGlkeCk7XHJcbn1cclxuXHJcbi8qKiBDb21wdXRlIHRoZSBlbmdhZ2VtZW50IHNpZ25hdHVyZSB3ZSB1c2UgdG8gZGVjaWRlIHdoZXRoZXIgYSByZS1jYXB0dXJlZFxyXG4gKiB0d2VldCBpcyBcIm1hdGVyaWFsbHkgZGlmZmVyZW50XCIgZnJvbSB3aGF0IHdlIGxhc3QgY29tbWl0dGVkLiBXZSBvbWl0XHJcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXHJcbiAqIGRlZmVhdCB0aGUgZGVkdXAuIExpa2VzIC8gUlRzIC8gcmVwbGllcyAvIHF1b3RlcyBjaGFuZ2UgcmFyZWx5IGVub3VnaCB0aGF0XHJcbiAqIGVhY2ggY2hhbmdlIGlzIHdvcnRoIGEgcmUtY29tbWl0IChhbmQgYW4gZW5nYWdlbWVudF9oaXN0b3J5IHNuYXBzaG90KS5cclxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxyXG4gKiB0aGUgZnVsbCBgbm90ZV90d2VldGAgYm9keSBieXBhc3NlcyB0aGUgZGVkdXAgZXZlbiB3aGVuIGVuZ2FnZW1lbnQgY291bnRzXHJcbiAqIGhhdmVuJ3QgbW92ZWQgXHUyMDE0IG90aGVyd2lzZSB0aGUgbmV3IGJvZHkgd291bGQgYmUgc2lsZW50bHkgZHJvcHBlZC4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXHJcbiAgbGlrZXM6IG51bWJlcixcclxuICByZXR3ZWV0czogbnVtYmVyLFxyXG4gIHJlcGxpZXM6IG51bWJlcixcclxuICBxdW90ZXM6IG51bWJlcixcclxuICBpc1RydW5jYXRlZDogYm9vbGVhbiA9IGZhbHNlXHJcbik6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGAke2xpa2VzfXwke3JldHdlZXRzfXwke3JlcGxpZXN9fCR7cXVvdGVzfXwke2lzVHJ1bmNhdGVkID8gJ3QnIDogJ2YnfWA7XHJcbn1cclxuXHJcbi8qKiBEcm9wIGVudHJpZXMgb2xkZXIgdGhhbiBgbWF4QWdlTXNgLiBSZXR1cm5zIHRoZSBudW1iZXIgcHJ1bmVkLiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJ1bmVDb21taXR0ZWRJbmRleChtYXhBZ2VNczogbnVtYmVyKTogUHJvbWlzZTxudW1iZXI+IHtcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGNvbnN0IGN1dG9mZiA9IG5ldyBEYXRlKERhdGUubm93KCkgLSBtYXhBZ2VNcykudG9JU09TdHJpbmcoKTtcclxuICBsZXQgcHJ1bmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XHJcbiAgICBjb25zdCBpbm5lciA9IGlkeFtoYW5kbGVdO1xyXG4gICAgaWYgKCFpbm5lcikgY29udGludWU7XHJcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcclxuICAgICAgY29uc3QgZSA9IGlubmVyW3RpZF07XHJcbiAgICAgIGlmIChlICYmIGUudHMgPCBjdXRvZmYpIHtcclxuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcclxuICAgICAgICBwcnVuZWQgKz0gMTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKE9iamVjdC5rZXlzKGlubmVyKS5sZW5ndGggPT09IDApIGRlbGV0ZSBpZHhbaGFuZGxlXTtcclxuICB9XHJcbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XHJcbiAgcmV0dXJuIHBydW5lZDtcclxufVxyXG5cclxuLy8gLS0tIFJlZmV0Y2ggcXVldWUgKHR3ZWV0cyBuZWVkaW5nIGZ1bGwtdGV4dCByZWNhcHR1cmUpIC0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFF1ZXVlJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWZldGNoUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBsZXQgdG90YWwgPSAwO1xyXG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XHJcbiAgcmV0dXJuIHRvdGFsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBjb25zdCBpZHMgPSBxW2hhbmRsZV0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtoYW5kbGVdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXTtcclxuICBpZiAoIWlkcykgcmV0dXJuO1xyXG4gIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcclxuICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtoYW5kbGVdO1xyXG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRSZWZldGNoVGFyZ2V0KCk6IFByb21pc2U8e1xyXG4gIGhhbmRsZTogc3RyaW5nO1xyXG4gIHR3ZWV0SWQ6IHN0cmluZztcclxufSB8IG51bGw+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XHJcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGhhbmRsZSwgdHdlZXRJZDogaWRzWzBdISB9O1xyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBsZXQgdG90YWwgPSAwO1xyXG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XHJcbiAgcmV0dXJuIHRvdGFsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZU1lZGlhQ3Jhd2woaGludEhhbmRsZTogc3RyaW5nIHwgbnVsbCwgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcclxuICBjb25zdCBpZHMgPSBxW2J1Y2tldF0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtidWNrZXRdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcclxuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xyXG4gICAgY29uc3QgaWRzID0gcVtidWNrZXRdO1xyXG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xyXG4gICAgaWYgKGZpbHRlcmVkLmxlbmd0aCAhPT0gaWRzLmxlbmd0aCkge1xyXG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcclxuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcclxuICAgICAgZWxzZSBxW2J1Y2tldF0gPSBmaWx0ZXJlZDtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKGNoYW5nZWQpIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgcSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0TWVkaWFDcmF3bFRhcmdldCgpOiBQcm9taXNlPHtcclxuICBidWNrZXQ6IHN0cmluZztcclxuICB0d2VldElkOiBzdHJpbmc7XHJcbn0gfCBudWxsPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xyXG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBidWNrZXQsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXHJcbiAqIGVucXVldWVpbmcgbWVkaWEtY3Jhd2wgdGFyZ2V0cyB3ZSd2ZSBhbHJlYWR5IGFyY2hpdmVkLiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNDb21taXR0ZWQodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBmb3IgKGNvbnN0IGlubmVyIG9mIE9iamVjdC52YWx1ZXMoaWR4KSkge1xyXG4gICAgaWYgKGlubmVyICYmIHR3ZWV0SWQgaW4gaW5uZXIpIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbi8vIC0tLSBMb29wIHNlc3Npb24gc3RhdGUgKHByb2dyZXNzICsgaW5mbGlnaHQgZ2F0aW5nKSAtLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFNlc3Npb24nLCBzKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJywgcyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEF1dG9TY3JvbGxTZXNzaW9uKCk6IFByb21pc2U8QXV0b1Njcm9sbFNlc3Npb24gfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXV0b1Njcm9sbFNlc3Npb24oczogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicsIHMpO1xyXG59XHJcblxyXG4vLyAtLS0gUHVyZ2U6IHVucmVsYXRlZCBidWZmZXJzLCBjb3VudGVycywgcXVldWUgZW50cmllcyAtLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4vKipcclxuICogRHJvcCBldmVyeSBwZXItaGFuZGxlIGJpdCBvZiBzdGF0ZSAoY291bnRlcnMsIHJ1biBidWZmZXIsIGNvbW1pdHRlZC1pbmRleFxyXG4gKiBlbnRyaWVzLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcXVldWUgZW50cmllcykgdGhhdCBkb2Vzbid0IGNvcnJlc3BvbmQgdG8gYVxyXG4gKiB0cmFja2VkIGFjY291bnQuIFJldHVybnMgYSBzdW1tYXJ5IGRlc2NyaWJpbmcgd2hhdCB3YXMgY2xlYXJlZCBzbyB0aGVcclxuICogY2FsbGVyIGNhbiBsb2cgaXQuXHJcbiAqXHJcbiAqIFRyYWNrZWQgYWNjb3VudHMgYXJlIHBhc3NlZCBpbiAoY2FsbGVyIHJlc29sdmVzIGZyb20gdGhlIGxpdmUgY29uZmlnKS5cclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwdXJnZVVucmVsYXRlZFN0YXRlKHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+KTogUHJvbWlzZTx7XHJcbiAgY291bnRlcnNSZW1vdmVkOiBudW1iZXI7XHJcbiAgYnVmZmVyc1JlbW92ZWQ6IG51bWJlcjtcclxuICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkOiBudW1iZXI7XHJcbn0+IHtcclxuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcclxuICBjb25zdCBpc1RhcmdldGVkID0gKGg6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGFyZ0xvd2VyLmhhcyhoLnRvTG93ZXJDYXNlKCkpO1xyXG5cclxuICAvLyBDb3VudGVyc1xyXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcclxuICBsZXQgY291bnRlcnNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGNvdW50ZXJzW2hdO1xyXG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcclxuXHJcbiAgLy8gUnVuIGJ1ZmZlcnNcclxuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGxldCBidWZmZXJzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGJ1ZmZlcnMpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGJ1ZmZlcnNbaF07XHJcbiAgICAgIGJ1ZmZlcnNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGJ1ZmZlcnMpO1xyXG5cclxuICAvLyBDb21taXR0ZWQgZGVkdXAgaW5kZXhcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgaWR4W2hdO1xyXG4gICAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xyXG5cclxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXHJcbiAgY29uc3QgcnEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBsZXQgcmVmZXRjaEhhbmRsZXNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIHJxW2hdO1xyXG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XHJcblxyXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiBidWNrZXRzIGFyZSBoaW50LWhhbmRsZXMgKG9yIFwiX3Vua25vd25cIikuIERyb3BcclxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCBcdTIwMTQgaW5jbHVkaW5nIFwiX3Vua25vd25cIiBzaW5jZSB3ZVxyXG4gIC8vIGNhbid0IHZlcmlmeSByZWxhdGlvbi5cclxuICBjb25zdCBtcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKG1xKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xyXG4gICAgICBkZWxldGUgbXFbaF07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgbXEpO1xyXG5cclxuICByZXR1cm4ge1xyXG4gICAgY291bnRlcnNSZW1vdmVkLFxyXG4gICAgYnVmZmVyc1JlbW92ZWQsXHJcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcclxuICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCxcclxuICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkLFxyXG4gIH07XHJcbn1cclxuXHJcbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcclxufVxyXG4iLCAiLyoqXHJcbiAqIG9wdGlvbnMudHMgXHUyMDE0IHNldHRpbmdzIHBhZ2UuXHJcbiAqXHJcbiAqIFN0b3JlcyBQQVQgYW5kIHJlcG8gaWRlbnRpZmllcnMgaW4gYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAsIHZlcmlmaWVzIGFjY2Vzc1xyXG4gKiBieSBjYWxsaW5nIC91c2VyIGFuZCAvcmVwb3MvOm93bmVyLzpyZXBvLCBhbmQgc3VyZmFjZXMgdGhlIHJlc3VsdGluZ1xyXG4gKiBjb25uZWN0aW9uIHN0YXRlLlxyXG4gKi9cclxuXHJcbmltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MgfSBmcm9tICcuL2xpYi9jb25maWcuanMnO1xyXG5pbXBvcnQge1xyXG4gIGNsZWFyQWxsLFxyXG4gIGdldEFjY291bnRzLFxyXG4gIGdldEFjdGl2aXR5LFxyXG4gIGdldENvbm5lY3Rpb24sXHJcbiAgZ2V0Q291bnRlcnMsXHJcbiAgZ2V0UnVuQnVmZmVycyxcclxuICBnZXRTZXR0aW5ncyxcclxuICB1cGRhdGVTZXR0aW5ncyxcclxufSBmcm9tICcuL2xpYi9zdG9yYWdlLmpzJztcclxuaW1wb3J0IHR5cGUgeyBSdW50aW1lTWVzc2FnZSB9IGZyb20gJy4vbGliL3R5cGVzLmpzJztcclxuXHJcbmNvbnN0ICQgPSA8VCBleHRlbmRzIEhUTUxFbGVtZW50ID0gSFRNTEVsZW1lbnQ+KGlkOiBzdHJpbmcpOiBUID0+IHtcclxuICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcclxuICBpZiAoIWVsKSB0aHJvdyBuZXcgRXJyb3IoYG1pc3NpbmcgZWxlbWVudCAjJHtpZH1gKTtcclxuICByZXR1cm4gZWwgYXMgVDtcclxufTtcclxuXHJcbmNvbnN0IGZvcm0gPSAkPEhUTUxGb3JtRWxlbWVudD4oJ3NldHRpbmdzLWZvcm0nKTtcclxuY29uc3Qgb3duZXJJbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ293bmVyJyk7XHJcbmNvbnN0IHJlcG9JbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ3JlcG8nKTtcclxuY29uc3QgYnJhbmNoSW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdicmFuY2gnKTtcclxuY29uc3QgcGF0SW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdwYXQnKTtcclxuY29uc3QgcmV2ZWFsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JldmVhbC1wYXQnKTtcclxuY29uc3Qgc2F2ZVN0YXR1cyA9ICQ8SFRNTFNwYW5FbGVtZW50Pignc2F2ZS1zdGF0dXMnKTtcclxuY29uc3QgY29ubkRldGFpbCA9ICQoJ2Nvbm4tZGV0YWlsJyk7XHJcbmNvbnN0IGFjY291bnRMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWNjb3VudC1yZWFkb25seScpO1xyXG5jb25zdCByZWZyZXNoQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZnJlc2gtYWNjb3VudHMnKTtcclxuY29uc3QgZGlhZ0JveCA9ICQ8SFRNTFRleHRBcmVhRWxlbWVudD4oJ2RpYWdub3N0aWNzJyk7XHJcbmNvbnN0IGNvcHlEaWFnQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NvcHktZGlhZ25vc3RpY3MnKTtcclxuY29uc3QgY2xlYXJTdG9yYWdlQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NsZWFyLXN0b3JhZ2UnKTtcclxuY29uc3QgZGlhZ1N0YXR1cyA9ICQ8SFRNTFNwYW5FbGVtZW50PignZGlhZy1zdGF0dXMnKTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNlbmQ8VD4obXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8VD4ge1xyXG4gIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKSBhcyBQcm9taXNlPFQ+O1xyXG59XHJcblxyXG5mdW5jdGlvbiBzZXRTdGF0dXMoZWw6IEhUTUxFbGVtZW50LCBraW5kOiAnb2snIHwgJ2VycicgfCAnd2FybicgfCAnJywgbXNnOiBzdHJpbmcpOiB2b2lkIHtcclxuICBlbC5jbGFzc05hbWUgPSBraW5kID8gYHN0YXR1cyAke2tpbmR9YCA6ICdzdGF0dXMnO1xyXG4gIGVsLnRleHRDb250ZW50ID0gbXNnO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBsb2FkU2V0dGluZ3MoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgb3duZXJJbnB1dC52YWx1ZSA9IHMub3duZXIgfHwgREVGQVVMVF9TRVRUSU5HUy5vd25lcjtcclxuICByZXBvSW5wdXQudmFsdWUgPSBzLnJlcG8gfHwgREVGQVVMVF9TRVRUSU5HUy5yZXBvO1xyXG4gIGJyYW5jaElucHV0LnZhbHVlID0gcy5icmFuY2ggfHwgREVGQVVMVF9TRVRUSU5HUy5icmFuY2g7XHJcbiAgaWYgKHMucGF0KSB7XHJcbiAgICBwYXRJbnB1dC52YWx1ZSA9IHMucGF0O1xyXG4gICAgcGF0SW5wdXQucGxhY2Vob2xkZXIgPSBgXHUyMDI2JHtzLnBhdC5zbGljZSgtNCl9YDtcclxuICB9XHJcbiAgYXdhaXQgcGFpbnRDb25uRGV0YWlsKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHBhaW50Q29ubkRldGFpbCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xyXG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IGxpbmVzOiBzdHJpbmdbXSA9IFtdO1xyXG4gIGxpbmVzLnB1c2goYFN0YXR1czogJHtjb25uLnN0YXR1c31gKTtcclxuICBpZiAoY29ubi5sb2dpbikgbGluZXMucHVzaChgTG9nZ2VkIGluIGFzOiBAJHtjb25uLmxvZ2lufWApO1xyXG4gIGxpbmVzLnB1c2goYFJlcG9zaXRvcnk6ICR7cy5vd25lciB8fCAnPyd9LyR7cy5yZXBvIHx8ICc/J31AJHtzLmJyYW5jaCB8fCAnPyd9YCk7XHJcbiAgaWYgKGNvbm4uY2hlY2tlZEF0KSBsaW5lcy5wdXNoKGBMYXN0IGNoZWNrZWQ6ICR7Y29ubi5jaGVja2VkQXR9YCk7XHJcbiAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcclxuICAgIGNvbnN0IHJlc2V0SXNvID0gbmV3IERhdGUoY29ubi5yYXRlTGltaXRSZXNldEF0ICogMTAwMCkudG9JU09TdHJpbmcoKTtcclxuICAgIGNvbnN0IGRlbHRhU2VjID0gY29ubi5yYXRlTGltaXRSZXNldEF0IC0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XHJcbiAgICBjb25zdCBpbkxhYmVsID1cclxuICAgICAgZGVsdGFTZWMgPD0gMFxyXG4gICAgICAgID8gJ21vbWVudGFyaWx5J1xyXG4gICAgICAgIDogZGVsdGFTZWMgPCA2MFxyXG4gICAgICAgICAgPyBgaW4gJHtkZWx0YVNlY31zYFxyXG4gICAgICAgICAgOiBkZWx0YVNlYyA8IDM2MDBcclxuICAgICAgICAgICAgPyBgaW4gJHtNYXRoLnJvdW5kKGRlbHRhU2VjIC8gNjApfW1gXHJcbiAgICAgICAgICAgIDogYGluICR7TWF0aC5yb3VuZChkZWx0YVNlYyAvIDM2MDApfWhgO1xyXG4gICAgbGluZXMucHVzaChgUmF0ZSBsaW1pdCByZXNldHM6ICR7cmVzZXRJc299ICgke2luTGFiZWx9KWApO1xyXG4gIH1cclxuICBpZiAoY29ubi5lcnJvcikgbGluZXMucHVzaChgRXJyb3I6ICR7Y29ubi5lcnJvcn1gKTtcclxuICBjb25uRGV0YWlsLnRleHRDb250ZW50ID0gbGluZXMuam9pbignXFxuJyk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHBhaW50QWNjb3VudHMoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgbGlzdCA9IGF3YWl0IGdldEFjY291bnRzKCk7XHJcbiAgYWNjb3VudExpc3QucmVwbGFjZUNoaWxkcmVuKCk7XHJcbiAgZm9yIChjb25zdCBhIG9mIGxpc3QpIHtcclxuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcclxuICAgIGNvbnN0IGhhbmRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIGhhbmRsZS5jbGFzc05hbWUgPSAnaGFuZGxlJztcclxuICAgIGhhbmRsZS50ZXh0Q29udGVudCA9IGBAJHthLmhhbmRsZX1gO1xyXG4gICAgY29uc3QgbGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBsYWJlbC5jbGFzc05hbWUgPSAnbGFiZWwnO1xyXG4gICAgbGFiZWwudGV4dENvbnRlbnQgPSBhLmxhYmVsO1xyXG4gICAgbGkuYXBwZW5kKGhhbmRsZSwgbGFiZWwpO1xyXG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcclxuICB9XHJcbn1cclxuXHJcbmZvcm0uYWRkRXZlbnRMaXN0ZW5lcignc3VibWl0JywgYXN5bmMgKGU6IEV2ZW50KSA9PiB7XHJcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIGNvbnN0IHBhdCA9IHBhdElucHV0LnZhbHVlLnRyaW0oKTtcclxuICBjb25zdCBvd25lciA9IG93bmVySW5wdXQudmFsdWUudHJpbSgpO1xyXG4gIGNvbnN0IHJlcG8gPSByZXBvSW5wdXQudmFsdWUudHJpbSgpO1xyXG4gIGNvbnN0IGJyYW5jaCA9IGJyYW5jaElucHV0LnZhbHVlLnRyaW0oKSB8fCAnbWFpbic7XHJcbiAgaWYgKCFwYXQgfHwgIW93bmVyIHx8ICFyZXBvKSB7XHJcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ2VycicsICdBbGwgZmllbGRzIGFyZSByZXF1aXJlZC4nKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICcnLCAnU2F2aW5nXHUyMDI2Jyk7XHJcbiAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBwYXQsIG93bmVyLCByZXBvLCBicmFuY2gsIGNvbmZpZ3VyZWRBdDogRGF0ZS5ub3coKSB9KTtcclxuICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJycsICdWZXJpZnlpbmdcdTIwMjYnKTtcclxuICBhd2FpdCBzZW5kKHsgdHlwZTogJ3ZlcmlmeS1jb25uZWN0aW9uJyB9KTtcclxuICBhd2FpdCBzZW5kKHsgdHlwZTogJ3JlZnJlc2gtYWNjb3VudHMnIH0pO1xyXG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgaWYgKGNvbm4uc3RhdHVzID09PSAnb2snKSB7XHJcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ29rJywgYENvbm5lY3RlZCBhcyBAJHtjb25uLmxvZ2luID8/ICc/J30uYCk7XHJcbiAgfSBlbHNlIGlmIChjb25uLnN0YXR1cyA9PT0gJ2F1dGgtZXJyb3InKSB7XHJcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ2VycicsICdBdXRoIGZhaWxlZCBcdTIwMTQgY2hlY2sgdGhlIFBBVCBhbmQgaXRzIHJlcG8gc2NvcGUuJyk7XHJcbiAgfSBlbHNlIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcclxuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnd2FybicsICdSYXRlLWxpbWl0ZWQgXHUyMDE0IHRva2VuIGlzIHZhbGlkIGJ1dCBHaXRIdWIgaXMgdGhyb3R0bGluZy4nKTtcclxuICB9IGVsc2UgaWYgKGNvbm4uc3RhdHVzID09PSAnbmV0d29yay1lcnJvcicpIHtcclxuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgJ05ldHdvcmsgZXJyb3IgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpdml0eS4nKTtcclxuICB9IGVsc2Uge1xyXG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICdlcnInLCBgVmVyaWZpY2F0aW9uOiAke2Nvbm4uc3RhdHVzfWApO1xyXG4gIH1cclxuICBhd2FpdCBwYWludENvbm5EZXRhaWwoKTtcclxuICBhd2FpdCBwYWludEFjY291bnRzKCk7XHJcbiAgYXdhaXQgcmVmcmVzaERpYWcoKTtcclxufSk7XHJcblxyXG5yZXZlYWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgaWYgKHBhdElucHV0LnR5cGUgPT09ICdwYXNzd29yZCcpIHtcclxuICAgIHBhdElucHV0LnR5cGUgPSAndGV4dCc7XHJcbiAgICByZXZlYWxCdG4udGV4dENvbnRlbnQgPSAnSGlkZSc7XHJcbiAgfSBlbHNlIHtcclxuICAgIHBhdElucHV0LnR5cGUgPSAncGFzc3dvcmQnO1xyXG4gICAgcmV2ZWFsQnRuLnRleHRDb250ZW50ID0gJ1Nob3cnO1xyXG4gIH1cclxufSk7XHJcblxyXG5yZWZyZXNoQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xyXG4gIHJlZnJlc2hCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ3JlZnJlc2gtYWNjb3VudHMnIH0pO1xyXG4gICAgYXdhaXQgcGFpbnRBY2NvdW50cygpO1xyXG4gICAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICdvaycsICdBY2NvdW50cyByZWZyZXNoZWQuJyk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBzZXRTdGF0dXMoZGlhZ1N0YXR1cywgJ2VycicsIGBSZWZyZXNoIGZhaWxlZDogJHsoZXJyIGFzIEVycm9yKS5tZXNzYWdlfWApO1xyXG4gIH0gZmluYWxseSB7XHJcbiAgICByZWZyZXNoQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfVxyXG59KTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hEaWFnKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IFtzZXR0aW5ncywgY29ubiwgYWNjb3VudHMsIGNvdW50ZXJzLCBidWZmZXJzLCBhY3Rpdml0eV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICBnZXRTZXR0aW5ncygpLFxyXG4gICAgZ2V0Q29ubmVjdGlvbigpLFxyXG4gICAgZ2V0QWNjb3VudHMoKSxcclxuICAgIGdldENvdW50ZXJzKCksXHJcbiAgICBnZXRSdW5CdWZmZXJzKCksXHJcbiAgICBnZXRBY3Rpdml0eSgpLFxyXG4gIF0pO1xyXG4gIGNvbnN0IHJlZGFjdGVkQnVmZmVycyA9IE9iamVjdC5mcm9tRW50cmllcyhcclxuICAgIE9iamVjdC5lbnRyaWVzKGJ1ZmZlcnMpLm1hcCgoW2ssIGJdKSA9PiBbXHJcbiAgICAgIGssXHJcbiAgICAgIHtcclxuICAgICAgICBydW5faWQ6IGIucnVuX2lkLFxyXG4gICAgICAgIHN0YXJ0ZWRfYXQ6IGIuc3RhcnRlZF9hdCxcclxuICAgICAgICBsYXN0X2NhcHR1cmVfYXQ6IGIubGFzdF9jYXB0dXJlX2F0LFxyXG4gICAgICAgIHR3ZWV0c19jb3VudDogT2JqZWN0LmtleXMoYi50d2VldHNfYnlfaWQpLmxlbmd0aCxcclxuICAgICAgICBvYnNlcnZlZF9jb3VudDogYi50d2VldF9pZHNfb2JzZXJ2ZWQubGVuZ3RoLFxyXG4gICAgICAgIGVuZHBvaW50c19zZWVuOiBiLmVuZHBvaW50c19zZWVuLFxyXG4gICAgICAgIHNvdXJjZV91cmw6IGIuc291cmNlX3VybCxcclxuICAgICAgfSxcclxuICAgIF0pXHJcbiAgKTtcclxuICBjb25zdCBkdW1wID0ge1xyXG4gICAgdmVyc2lvbjogYnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbixcclxuICAgIHVzZXJfYWdlbnQ6IG5hdmlnYXRvci51c2VyQWdlbnQsXHJcbiAgICBzZXR0aW5nczoge1xyXG4gICAgICBvd25lcjogc2V0dGluZ3Mub3duZXIsXHJcbiAgICAgIHJlcG86IHNldHRpbmdzLnJlcG8sXHJcbiAgICAgIGJyYW5jaDogc2V0dGluZ3MuYnJhbmNoLFxyXG4gICAgICBhdXRvQ2FwdHVyZTogc2V0dGluZ3MuYXV0b0NhcHR1cmUsXHJcbiAgICAgIGNvbmZpZ3VyZWRBdDogc2V0dGluZ3MuY29uZmlndXJlZEF0LFxyXG4gICAgICBwYXRTZXQ6IHNldHRpbmdzLnBhdC5sZW5ndGggPiAwLFxyXG4gICAgICBwYXRTdWZmaXg6IHNldHRpbmdzLnBhdC5sZW5ndGggPj0gNCA/IHNldHRpbmdzLnBhdC5zbGljZSgtNCkgOiAnJyxcclxuICAgIH0sXHJcbiAgICBjb25uZWN0aW9uOiBjb25uLFxyXG4gICAgYWNjb3VudHMsXHJcbiAgICBjb3VudGVycyxcclxuICAgIHJ1bkJ1ZmZlcnM6IHJlZGFjdGVkQnVmZmVycyxcclxuICAgIGFjdGl2aXR5X3RhaWxfc2l6ZTogYWN0aXZpdHkubGVuZ3RoLFxyXG4gICAgYWN0aXZpdHlfcmVjZW50OiBhY3Rpdml0eS5zbGljZSgwLCAzMCksXHJcbiAgfTtcclxuICBkaWFnQm94LnZhbHVlID0gSlNPTi5zdHJpbmdpZnkoZHVtcCwgbnVsbCwgMik7XHJcbn1cclxuXHJcbmNvcHlEaWFnQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xyXG4gIGF3YWl0IG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KGRpYWdCb3gudmFsdWUpO1xyXG4gIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnb2snLCAnQ29waWVkIGRpYWdub3N0aWNzIHRvIGNsaXBib2FyZC4nKTtcclxufSk7XHJcblxyXG5jbGVhclN0b3JhZ2VCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgY29uc3Qgb2sgPSB3aW5kb3cuY29uZmlybShcclxuICAgICdDbGVhciBleHRlbnNpb24gc3RvcmFnZT8gVGhpcyBlcmFzZXMgeW91ciBQQVQsIHNldHRpbmdzLCBjb3VudGVycywgYnVmZmVyZWQgY2FwdHVyZXMsIGFuZCBhY3Rpdml0eSB0YWlsLiBUaGVyZSBpcyBubyB1bmRvLidcclxuICApO1xyXG4gIGlmICghb2spIHJldHVybjtcclxuICBhd2FpdCBjbGVhckFsbCgpO1xyXG4gIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnd2FybicsICdTdG9yYWdlIGNsZWFyZWQuJyk7XHJcbiAgYXdhaXQgbG9hZFNldHRpbmdzKCk7XHJcbiAgYXdhaXQgcGFpbnRBY2NvdW50cygpO1xyXG4gIGF3YWl0IHJlZnJlc2hEaWFnKCk7XHJcbn0pO1xyXG5cclxudm9pZCBsb2FkU2V0dGluZ3MoKTtcclxudm9pZCBwYWludEFjY291bnRzKCk7XHJcbnZvaWQgcmVmcmVzaERpYWcoKTtcclxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUVPLElBQU0sbUJBQTZCO0FBQUEsRUFDeEMsS0FBSztBQUFBLEVBQ0wsT0FBTztBQUFBLEVBQ1AsTUFBTTtBQUFBO0FBQUE7QUFBQSxFQUdOLFFBQVE7QUFBQSxFQUNSLFNBQVM7QUFBQSxFQUNULGFBQWE7QUFBQSxFQUNiLGNBQWM7QUFBQSxFQUNkLHVCQUF1QjtBQUN6QjtBQU9PLElBQU0sb0JBQXFDO0FBQUEsRUFDaEQsRUFBRSxRQUFRLFVBQVUsT0FBTyxtQ0FBbUMsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFVBQVUsT0FBTyw0Q0FBNEMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLE9BQU8sT0FBTyxzQ0FBc0MsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw2Q0FBNkMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLGNBQWMsT0FBTyxtQkFBbUIsVUFBVSxPQUFPO0FBQUEsRUFDbkUsRUFBRSxRQUFRLFlBQVksT0FBTywrQkFBK0IsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyxrQ0FBa0MsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw0QkFBNEIsVUFBVSxPQUFPO0FBQUEsRUFDdkUsRUFBRSxRQUFRLG1CQUFtQixPQUFPLHFCQUFxQixVQUFVLE9BQU87QUFDNUU7QUE4RE8sSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLOzs7QUNwRXZELElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sa0JBQWtCO0FBRXhCLElBQUksa0JBQW9DO0FBQ3hDLElBQUksc0JBQXFDO0FBRXpDLFNBQVMsU0FBUyxLQUF5QjtBQUN6QyxNQUFJLElBQUk7QUFDUixhQUFXLEtBQUssSUFBSyxNQUFLLE9BQU8sYUFBYSxDQUFDO0FBQy9DLFNBQU8sS0FBSyxDQUFDO0FBQ2Y7QUFFQSxTQUFTLFdBQVcsR0FBdUI7QUFDekMsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixRQUFNLE1BQU0sSUFBSSxXQUFXLElBQUksTUFBTTtBQUNyQyxXQUFTLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxJQUFLLEtBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDO0FBQzlELFNBQU87QUFDVDtBQUVBLGVBQWUsbUJBQW1FO0FBQ2hGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksZ0JBQWdCO0FBQy9ELFFBQU0sSUFBSSxPQUFPLGdCQUFnQjtBQUNqQyxNQUFJLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxHQUFHO0FBQ3pDLFdBQU8sRUFBRSxTQUFTLEdBQUcsTUFBTSxXQUFXLENBQUMsRUFBRTtBQUFBLEVBQzNDO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsUUFBTSxVQUFVLFNBQVMsSUFBSTtBQUM3QixRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGdCQUFnQixHQUFHLFFBQVEsQ0FBQztBQUMvRCxTQUFPLEVBQUUsU0FBUyxLQUFLO0FBQ3pCO0FBRUEsZUFBZSxZQUFnQztBQUM3QyxRQUFNLEVBQUUsU0FBUyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDakQsTUFBSSxvQkFBb0IsUUFBUSx3QkFBd0IsU0FBUztBQUMvRCxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRTtBQUFBLElBQzdCLEdBQUcsUUFBUSxRQUFRLEVBQUUsSUFBSSxRQUFRLFFBQVEsWUFBWSxFQUFFLE9BQU87QUFBQSxFQUNoRTtBQUNBLFFBQU0sV0FBVyxJQUFJLFdBQVcsS0FBSyxTQUFTLEtBQUssTUFBTTtBQUN6RCxXQUFTLElBQUksTUFBTSxDQUFDO0FBQ3BCLFdBQVMsSUFBSSxNQUFNLEtBQUssTUFBTTtBQUM5QixRQUFNLE9BQU8sTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLFFBQVE7QUFDM0QsUUFBTSxNQUFNLE1BQU0sT0FBTyxPQUFPLFVBQVUsT0FBTyxNQUFNLEVBQUUsTUFBTSxVQUFVLEdBQUcsT0FBTztBQUFBLElBQ2pGO0FBQUEsSUFDQTtBQUFBLEVBQ0YsQ0FBQztBQUNELG9CQUFrQjtBQUNsQix3QkFBc0I7QUFDdEIsU0FBTztBQUNUO0FBRU8sU0FBUyxlQUFlLEdBQW9CO0FBQ2pELFNBQU8sRUFBRSxXQUFXLGVBQWU7QUFDckM7QUFFQSxlQUFzQixXQUFXLFdBQW9DO0FBQ25FLE1BQUksQ0FBQyxVQUFXLFFBQU87QUFDdkIsUUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixRQUFNLEtBQUssT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUNwRCxRQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxJQUM3QixFQUFFLE1BQU0sV0FBVyxHQUFHO0FBQUEsSUFDdEI7QUFBQSxJQUNBLElBQUksWUFBWSxFQUFFLE9BQU8sU0FBUztBQUFBLEVBQ3BDO0FBQ0EsU0FBTyxHQUFHLGVBQWUsR0FBRyxTQUFTLEVBQUUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxXQUFXLEVBQUUsQ0FBQyxDQUFDO0FBQzFFO0FBRUEsZUFBc0IsV0FBVyxVQUFtQztBQUNsRSxNQUFJLENBQUMsU0FBVSxRQUFPO0FBR3RCLE1BQUksQ0FBQyxTQUFTLFdBQVcsZUFBZSxFQUFHLFFBQU87QUFDbEQsUUFBTSxRQUFRLFNBQVMsTUFBTSxnQkFBZ0IsTUFBTSxFQUFFLE1BQU0sR0FBRztBQUM5RCxNQUFJLE1BQU0sV0FBVyxFQUFHLFFBQU87QUFDL0IsUUFBTSxDQUFDLE9BQU8sS0FBSyxJQUFJO0FBQ3ZCLE1BQUksQ0FBQyxTQUFTLENBQUMsTUFBTyxRQUFPO0FBQzdCLE1BQUk7QUFDRixVQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxNQUM3QixFQUFFLE1BQU0sV0FBVyxHQUF1QjtBQUFBLE1BQzFDO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxXQUFPLElBQUksWUFBWSxFQUFFLE9BQU8sRUFBRTtBQUFBLEVBQ3BDLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGOzs7QUMxQkEsSUFBTSxxQkFBc0M7QUFBQSxFQUMxQyxRQUFRO0FBQUEsRUFDUixPQUFPO0FBQUEsRUFDUCxXQUFXO0FBQUEsRUFDWCxPQUFPO0FBQUEsRUFDUCxlQUFlO0FBQUEsRUFDZix3QkFBd0I7QUFBQSxFQUN4QixrQkFBa0I7QUFDcEI7QUFFQSxJQUFNLFdBQXlCO0FBQUEsRUFDN0IsVUFBVSxFQUFFLEdBQUcsaUJBQWlCO0FBQUEsRUFDaEMsVUFBVSxDQUFDLEdBQUcsaUJBQWlCO0FBQUEsRUFDL0IscUJBQXFCO0FBQUEsRUFDckIsWUFBWSxFQUFFLEdBQUcsbUJBQW1CO0FBQUEsRUFDcEMsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLENBQUM7QUFBQSxFQUNiLFVBQVUsQ0FBQztBQUFBLEVBQ1gsZ0JBQWdCLENBQUM7QUFBQSxFQUNqQixjQUFjLENBQUM7QUFBQSxFQUNmLGlCQUFpQixDQUFDO0FBQUEsRUFDbEIsZ0JBQWdCO0FBQUEsRUFDaEIsbUJBQW1CO0FBQUEsRUFDbkIsbUJBQW1CO0FBQ3JCO0FBRUEsZUFBZSxPQUFxQyxLQUFrQztBQUNwRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDbEQsUUFBTSxRQUFRLE9BQU8sR0FBRztBQUN4QixNQUFJLFVBQVUsUUFBVztBQUN2QixXQUFPLGdCQUFnQixTQUFTLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBQ0EsU0FBTztBQUNUO0FBRUEsZUFBZSxPQUFxQyxLQUFRLE9BQXVDO0FBQ2pHLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQztBQUNsRDtBQUlBLGVBQXNCLGNBQWlDO0FBS3JELFFBQU0sU0FBUyxNQUFNLE9BQU8sVUFBVTtBQUN0QyxRQUFNLFNBQVMsRUFBRSxHQUFHLGtCQUFrQixHQUFHLE9BQU87QUFDaEQsTUFBSSxPQUFPLE9BQU8sZUFBZSxPQUFPLEdBQUcsR0FBRztBQUM1QyxRQUFJO0FBQ0YsYUFBTyxNQUFNLE1BQU0sV0FBVyxPQUFPLEdBQUc7QUFBQSxJQUMxQyxRQUFRO0FBQ04sYUFBTyxNQUFNO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixZQUFZLEdBQTRCO0FBRzVELFFBQU0sVUFBb0IsRUFBRSxHQUFHLEVBQUU7QUFDakMsTUFBSSxRQUFRLE9BQU8sQ0FBQyxlQUFlLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFlBQVEsTUFBTSxNQUFNLFdBQVcsUUFBUSxHQUFHO0FBQUEsRUFDNUM7QUFDQSxRQUFNLE9BQU8sWUFBWSxPQUFPO0FBQ2xDO0FBQ0EsZUFBc0IsZUFBZSxPQUE2QztBQUNoRixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEMsUUFBTSxZQUFZLElBQUk7QUFDdEIsU0FBTztBQUNUO0FBSUEsZUFBc0IsY0FBd0M7QUFDNUQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFhQSxlQUFzQixnQkFBMEM7QUFDOUQsUUFBTSxJQUFJLE1BQU0sT0FBTyxZQUFZO0FBRW5DLFFBQU0sTUFBdUI7QUFBQSxJQUMzQixHQUFHO0FBQUEsSUFDSCxlQUFlLEVBQUUsa0JBQWtCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDeEQsd0JBQ0UsRUFBRSwyQkFBMkIsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUNwRCxrQkFBa0IsRUFBRSxxQkFBcUIsU0FBWSxPQUFPLEVBQUU7QUFBQSxFQUNoRTtBQUNBLFNBQU87QUFDVDtBQVdBLGVBQXNCLGNBQXVEO0FBQzNFLFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBNkJBLGVBQXNCLGdCQUFvRDtBQUN4RSxTQUFPLE9BQU8sWUFBWTtBQUM1QjtBQXFCQSxlQUFzQixjQUFtQztBQUN2RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQXVSQSxlQUFzQixXQUEwQjtBQUM5QyxRQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU07QUFDcEM7OztBQ3BnQkEsSUFBTSxJQUFJLENBQXNDLE9BQWtCO0FBQ2hFLFFBQU0sS0FBSyxTQUFTLGVBQWUsRUFBRTtBQUNyQyxNQUFJLENBQUMsR0FBSSxPQUFNLElBQUksTUFBTSxvQkFBb0IsRUFBRSxFQUFFO0FBQ2pELFNBQU87QUFDVDtBQUVBLElBQU0sT0FBTyxFQUFtQixlQUFlO0FBQy9DLElBQU0sYUFBYSxFQUFvQixPQUFPO0FBQzlDLElBQU0sWUFBWSxFQUFvQixNQUFNO0FBQzVDLElBQU0sY0FBYyxFQUFvQixRQUFRO0FBQ2hELElBQU0sV0FBVyxFQUFvQixLQUFLO0FBQzFDLElBQU0sWUFBWSxFQUFxQixZQUFZO0FBQ25ELElBQU0sYUFBYSxFQUFtQixhQUFhO0FBQ25ELElBQU0sYUFBYSxFQUFFLGFBQWE7QUFDbEMsSUFBTSxjQUFjLEVBQW9CLGtCQUFrQjtBQUMxRCxJQUFNLGFBQWEsRUFBcUIsa0JBQWtCO0FBQzFELElBQU0sVUFBVSxFQUF1QixhQUFhO0FBQ3BELElBQU0sY0FBYyxFQUFxQixrQkFBa0I7QUFDM0QsSUFBTSxrQkFBa0IsRUFBcUIsZUFBZTtBQUM1RCxJQUFNLGFBQWEsRUFBbUIsYUFBYTtBQUVuRCxlQUFlLEtBQVEsS0FBaUM7QUFDdEQsU0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ3hDO0FBRUEsU0FBUyxVQUFVLElBQWlCLE1BQWtDLEtBQW1CO0FBQ3ZGLEtBQUcsWUFBWSxPQUFPLFVBQVUsSUFBSSxLQUFLO0FBQ3pDLEtBQUcsY0FBYztBQUNuQjtBQUVBLGVBQWUsZUFBOEI7QUFDM0MsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixhQUFXLFFBQVEsRUFBRSxTQUFTLGlCQUFpQjtBQUMvQyxZQUFVLFFBQVEsRUFBRSxRQUFRLGlCQUFpQjtBQUM3QyxjQUFZLFFBQVEsRUFBRSxVQUFVLGlCQUFpQjtBQUNqRCxNQUFJLEVBQUUsS0FBSztBQUNULGFBQVMsUUFBUSxFQUFFO0FBQ25CLGFBQVMsY0FBYyxTQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsQ0FBQztBQUFBLEVBQzVDO0FBQ0EsUUFBTSxnQkFBZ0I7QUFDeEI7QUFFQSxlQUFlLGtCQUFpQztBQUM5QyxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxRQUFrQixDQUFDO0FBQ3pCLFFBQU0sS0FBSyxXQUFXLEtBQUssTUFBTSxFQUFFO0FBQ25DLE1BQUksS0FBSyxNQUFPLE9BQU0sS0FBSyxrQkFBa0IsS0FBSyxLQUFLLEVBQUU7QUFDekQsUUFBTSxLQUFLLGVBQWUsRUFBRSxTQUFTLEdBQUcsSUFBSSxFQUFFLFFBQVEsR0FBRyxJQUFJLEVBQUUsVUFBVSxHQUFHLEVBQUU7QUFDOUUsTUFBSSxLQUFLLFVBQVcsT0FBTSxLQUFLLGlCQUFpQixLQUFLLFNBQVMsRUFBRTtBQUNoRSxNQUFJLEtBQUssV0FBVyxrQkFBa0IsS0FBSyxxQkFBcUIsTUFBTTtBQUNwRSxVQUFNLFdBQVcsSUFBSSxLQUFLLEtBQUssbUJBQW1CLEdBQUksRUFBRSxZQUFZO0FBQ3BFLFVBQU0sV0FBVyxLQUFLLG1CQUFtQixLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUNyRSxVQUFNLFVBQ0osWUFBWSxJQUNSLGdCQUNBLFdBQVcsS0FDVCxNQUFNLFFBQVEsTUFDZCxXQUFXLE9BQ1QsTUFBTSxLQUFLLE1BQU0sV0FBVyxFQUFFLENBQUMsTUFDL0IsTUFBTSxLQUFLLE1BQU0sV0FBVyxJQUFJLENBQUM7QUFDM0MsVUFBTSxLQUFLLHNCQUFzQixRQUFRLEtBQUssT0FBTyxHQUFHO0FBQUEsRUFDMUQ7QUFDQSxNQUFJLEtBQUssTUFBTyxPQUFNLEtBQUssVUFBVSxLQUFLLEtBQUssRUFBRTtBQUNqRCxhQUFXLGNBQWMsTUFBTSxLQUFLLElBQUk7QUFDMUM7QUFFQSxlQUFlLGdCQUErQjtBQUM1QyxRQUFNLE9BQU8sTUFBTSxZQUFZO0FBQy9CLGNBQVksZ0JBQWdCO0FBQzVCLGFBQVcsS0FBSyxNQUFNO0FBQ3BCLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxVQUFNLFNBQVMsU0FBUyxjQUFjLE1BQU07QUFDNUMsV0FBTyxZQUFZO0FBQ25CLFdBQU8sY0FBYyxJQUFJLEVBQUUsTUFBTTtBQUNqQyxVQUFNLFFBQVEsU0FBUyxjQUFjLE1BQU07QUFDM0MsVUFBTSxZQUFZO0FBQ2xCLFVBQU0sY0FBYyxFQUFFO0FBQ3RCLE9BQUcsT0FBTyxRQUFRLEtBQUs7QUFDdkIsZ0JBQVksT0FBTyxFQUFFO0FBQUEsRUFDdkI7QUFDRjtBQUVBLEtBQUssaUJBQWlCLFVBQVUsT0FBTyxNQUFhO0FBQ2xELElBQUUsZUFBZTtBQUNqQixRQUFNLE1BQU0sU0FBUyxNQUFNLEtBQUs7QUFDaEMsUUFBTSxRQUFRLFdBQVcsTUFBTSxLQUFLO0FBQ3BDLFFBQU0sT0FBTyxVQUFVLE1BQU0sS0FBSztBQUNsQyxRQUFNLFNBQVMsWUFBWSxNQUFNLEtBQUssS0FBSztBQUMzQyxNQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNO0FBQzNCLGNBQVUsWUFBWSxPQUFPLDBCQUEwQjtBQUN2RDtBQUFBLEVBQ0Y7QUFDQSxZQUFVLFlBQVksSUFBSSxjQUFTO0FBQ25DLFFBQU0sZUFBZSxFQUFFLEtBQUssT0FBTyxNQUFNLFFBQVEsY0FBYyxLQUFLLElBQUksRUFBRSxDQUFDO0FBQzNFLFlBQVUsWUFBWSxJQUFJLGlCQUFZO0FBQ3RDLFFBQU0sS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDeEMsUUFBTSxLQUFLLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUN2QyxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLE1BQUksS0FBSyxXQUFXLE1BQU07QUFDeEIsY0FBVSxZQUFZLE1BQU0saUJBQWlCLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFBQSxFQUNuRSxXQUFXLEtBQUssV0FBVyxjQUFjO0FBQ3ZDLGNBQVUsWUFBWSxPQUFPLHNEQUFpRDtBQUFBLEVBQ2hGLFdBQVcsS0FBSyxXQUFXLGdCQUFnQjtBQUN6QyxjQUFVLFlBQVksUUFBUSw4REFBeUQ7QUFBQSxFQUN6RixXQUFXLEtBQUssV0FBVyxpQkFBaUI7QUFDMUMsY0FBVSxZQUFZLE9BQU8sMENBQXFDO0FBQUEsRUFDcEUsT0FBTztBQUNMLGNBQVUsWUFBWSxPQUFPLGlCQUFpQixLQUFLLE1BQU0sRUFBRTtBQUFBLEVBQzdEO0FBQ0EsUUFBTSxnQkFBZ0I7QUFDdEIsUUFBTSxjQUFjO0FBQ3BCLFFBQU0sWUFBWTtBQUNwQixDQUFDO0FBRUQsVUFBVSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3hDLE1BQUksU0FBUyxTQUFTLFlBQVk7QUFDaEMsYUFBUyxPQUFPO0FBQ2hCLGNBQVUsY0FBYztBQUFBLEVBQzFCLE9BQU87QUFDTCxhQUFTLE9BQU87QUFDaEIsY0FBVSxjQUFjO0FBQUEsRUFDMUI7QUFDRixDQUFDO0FBRUQsV0FBVyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9DLGFBQVcsV0FBVztBQUN0QixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUN2QyxVQUFNLGNBQWM7QUFDcEIsY0FBVSxZQUFZLE1BQU0scUJBQXFCO0FBQUEsRUFDbkQsU0FBUyxLQUFLO0FBQ1osY0FBVSxZQUFZLE9BQU8sbUJBQW9CLElBQWMsT0FBTyxFQUFFO0FBQUEsRUFDMUUsVUFBRTtBQUNBLGVBQVcsV0FBVztBQUFBLEVBQ3hCO0FBQ0YsQ0FBQztBQUVELGVBQWUsY0FBNkI7QUFDMUMsUUFBTSxDQUFDLFVBQVUsTUFBTSxVQUFVLFVBQVUsU0FBUyxRQUFRLElBQUksTUFBTSxRQUFRLElBQUk7QUFBQSxJQUNoRixZQUFZO0FBQUEsSUFDWixjQUFjO0FBQUEsSUFDZCxZQUFZO0FBQUEsSUFDWixZQUFZO0FBQUEsSUFDWixjQUFjO0FBQUEsSUFDZCxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBQ0QsUUFBTSxrQkFBa0IsT0FBTztBQUFBLElBQzdCLE9BQU8sUUFBUSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU07QUFBQSxNQUN0QztBQUFBLE1BQ0E7QUFBQSxRQUNFLFFBQVEsRUFBRTtBQUFBLFFBQ1YsWUFBWSxFQUFFO0FBQUEsUUFDZCxpQkFBaUIsRUFBRTtBQUFBLFFBQ25CLGNBQWMsT0FBTyxLQUFLLEVBQUUsWUFBWSxFQUFFO0FBQUEsUUFDMUMsZ0JBQWdCLEVBQUUsbUJBQW1CO0FBQUEsUUFDckMsZ0JBQWdCLEVBQUU7QUFBQSxRQUNsQixZQUFZLEVBQUU7QUFBQSxNQUNoQjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLE9BQU87QUFBQSxJQUNYLFNBQVMsUUFBUSxRQUFRLFlBQVksRUFBRTtBQUFBLElBQ3ZDLFlBQVksVUFBVTtBQUFBLElBQ3RCLFVBQVU7QUFBQSxNQUNSLE9BQU8sU0FBUztBQUFBLE1BQ2hCLE1BQU0sU0FBUztBQUFBLE1BQ2YsUUFBUSxTQUFTO0FBQUEsTUFDakIsYUFBYSxTQUFTO0FBQUEsTUFDdEIsY0FBYyxTQUFTO0FBQUEsTUFDdkIsUUFBUSxTQUFTLElBQUksU0FBUztBQUFBLE1BQzlCLFdBQVcsU0FBUyxJQUFJLFVBQVUsSUFBSSxTQUFTLElBQUksTUFBTSxFQUFFLElBQUk7QUFBQSxJQUNqRTtBQUFBLElBQ0EsWUFBWTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZO0FBQUEsSUFDWixvQkFBb0IsU0FBUztBQUFBLElBQzdCLGlCQUFpQixTQUFTLE1BQU0sR0FBRyxFQUFFO0FBQUEsRUFDdkM7QUFDQSxVQUFRLFFBQVEsS0FBSyxVQUFVLE1BQU0sTUFBTSxDQUFDO0FBQzlDO0FBRUEsWUFBWSxpQkFBaUIsU0FBUyxZQUFZO0FBQ2hELFFBQU0sVUFBVSxVQUFVLFVBQVUsUUFBUSxLQUFLO0FBQ2pELFlBQVUsWUFBWSxNQUFNLGtDQUFrQztBQUNoRSxDQUFDO0FBRUQsZ0JBQWdCLGlCQUFpQixTQUFTLFlBQVk7QUFDcEQsUUFBTSxLQUFLLE9BQU87QUFBQSxJQUNoQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsR0FBSTtBQUNULFFBQU0sU0FBUztBQUNmLFlBQVUsWUFBWSxRQUFRLGtCQUFrQjtBQUNoRCxRQUFNLGFBQWE7QUFDbkIsUUFBTSxjQUFjO0FBQ3BCLFFBQU0sWUFBWTtBQUNwQixDQUFDO0FBRUQsS0FBSyxhQUFhO0FBQ2xCLEtBQUssY0FBYztBQUNuQixLQUFLLFlBQVk7IiwKICAibmFtZXMiOiBbXQp9Cg==
