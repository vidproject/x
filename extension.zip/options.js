// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function getCounters() {
  return getRaw("counters");
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getActivity() {
  return getRaw("activity");
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/options.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var form = $("settings-form");
var ownerInput = $("owner");
var repoInput = $("repo");
var branchInput = $("branch");
var patInput = $("pat");
var revealBtn = $("reveal-pat");
var saveStatus = $("save-status");
var connDetail = $("conn-detail");
var accountList = $("account-readonly");
var refreshBtn = $("refresh-accounts");
var diagBox = $("diagnostics");
var copyDiagBtn = $("copy-diagnostics");
var clearStorageBtn = $("clear-storage");
var diagStatus = $("diag-status");
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setStatus(el, kind, msg) {
  el.className = kind ? `status ${kind}` : "status";
  el.textContent = msg;
}
async function loadSettings() {
  const s = await getSettings();
  ownerInput.value = s.owner || DEFAULT_SETTINGS.owner;
  repoInput.value = s.repo || DEFAULT_SETTINGS.repo;
  branchInput.value = s.branch || DEFAULT_SETTINGS.branch;
  if (s.pat) {
    patInput.value = s.pat;
    patInput.placeholder = `\u2026${s.pat.slice(-4)}`;
  }
  await paintConnDetail();
}
async function paintConnDetail() {
  const conn = await getConnection();
  const s = await getSettings();
  const lines = [];
  lines.push(`Status: ${conn.status}`);
  if (conn.login) lines.push(`Logged in as: @${conn.login}`);
  lines.push(`Repository: ${s.owner || "?"}/${s.repo || "?"}@${s.branch || "?"}`);
  if (conn.checkedAt) lines.push(`Last checked: ${conn.checkedAt}`);
  if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
    const resetIso = new Date(conn.rateLimitResetAt * 1e3).toISOString();
    const deltaSec = conn.rateLimitResetAt - Math.floor(Date.now() / 1e3);
    const inLabel = deltaSec <= 0 ? "momentarily" : deltaSec < 60 ? `in ${deltaSec}s` : deltaSec < 3600 ? `in ${Math.round(deltaSec / 60)}m` : `in ${Math.round(deltaSec / 3600)}h`;
    lines.push(`Rate limit resets: ${resetIso} (${inLabel})`);
  }
  if (conn.error) lines.push(`Error: ${conn.error}`);
  connDetail.textContent = lines.join("\n");
}
async function paintAccounts() {
  const list = await getAccounts();
  accountList.replaceChildren();
  for (const a of list) {
    const li = document.createElement("li");
    const handle = document.createElement("span");
    handle.className = "handle";
    handle.textContent = `@${a.handle}`;
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = a.label;
    li.append(handle, label);
    accountList.append(li);
  }
}
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const pat = patInput.value.trim();
  const owner = ownerInput.value.trim();
  const repo = repoInput.value.trim();
  const branch = branchInput.value.trim() || "main";
  if (!pat || !owner || !repo) {
    setStatus(saveStatus, "err", "All fields are required.");
    return;
  }
  setStatus(saveStatus, "", "Saving\u2026");
  await updateSettings({ pat, owner, repo, branch, configuredAt: Date.now() });
  setStatus(saveStatus, "", "Verifying\u2026");
  await send({ type: "verify-connection" });
  await send({ type: "refresh-accounts" });
  const conn = await getConnection();
  if (conn.status === "ok") {
    setStatus(saveStatus, "ok", `Connected as @${conn.login ?? "?"}.`);
  } else if (conn.status === "auth-error") {
    setStatus(saveStatus, "err", "Auth failed \u2014 check the PAT and its repo scope.");
  } else if (conn.status === "rate-limited") {
    setStatus(saveStatus, "warn", "Rate-limited \u2014 token is valid but GitHub is throttling.");
  } else if (conn.status === "network-error") {
    setStatus(saveStatus, "err", "Network error \u2014 check connectivity.");
  } else {
    setStatus(saveStatus, "err", `Verification: ${conn.status}`);
  }
  await paintConnDetail();
  await paintAccounts();
  await refreshDiag();
});
revealBtn.addEventListener("click", () => {
  if (patInput.type === "password") {
    patInput.type = "text";
    revealBtn.textContent = "Hide";
  } else {
    patInput.type = "password";
    revealBtn.textContent = "Show";
  }
});
refreshBtn.addEventListener("click", async () => {
  refreshBtn.disabled = true;
  try {
    await send({ type: "refresh-accounts" });
    await paintAccounts();
    setStatus(diagStatus, "ok", "Accounts refreshed.");
  } catch (err) {
    setStatus(diagStatus, "err", `Refresh failed: ${err.message}`);
  } finally {
    refreshBtn.disabled = false;
  }
});
async function refreshDiag() {
  const [settings, conn, accounts, counters, buffers, activity] = await Promise.all([
    getSettings(),
    getConnection(),
    getAccounts(),
    getCounters(),
    getRunBuffers(),
    getActivity()
  ]);
  const redactedBuffers = Object.fromEntries(
    Object.entries(buffers).map(([k, b]) => [
      k,
      {
        run_id: b.run_id,
        started_at: b.started_at,
        last_capture_at: b.last_capture_at,
        tweets_count: Object.keys(b.tweets_by_id).length,
        observed_count: b.tweet_ids_observed.length,
        endpoints_seen: b.endpoints_seen,
        source_url: b.source_url
      }
    ])
  );
  const dump = {
    version: browser.runtime.getManifest().version,
    user_agent: navigator.userAgent,
    settings: {
      owner: settings.owner,
      repo: settings.repo,
      branch: settings.branch,
      autoCapture: settings.autoCapture,
      configuredAt: settings.configuredAt,
      patSet: settings.pat.length > 0,
      patSuffix: settings.pat.length >= 4 ? settings.pat.slice(-4) : ""
    },
    connection: conn,
    accounts,
    counters,
    runBuffers: redactedBuffers,
    activity_tail_size: activity.length,
    activity_recent: activity.slice(0, 30)
  };
  diagBox.value = JSON.stringify(dump, null, 2);
}
copyDiagBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(diagBox.value);
  setStatus(diagStatus, "ok", "Copied diagnostics to clipboard.");
});
clearStorageBtn.addEventListener("click", async () => {
  const ok = window.confirm(
    "Clear extension storage? This erases your PAT, settings, counters, buffered captures, and activity tail. There is no undo."
  );
  if (!ok) return;
  await clearAll();
  setStatus(diagStatus, "warn", "Storage cleared.");
  await loadSettings();
  await paintAccounts();
  await refreshDiag();
});
void loadSettings();
void paintAccounts();
void refreshDiag();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9vcHRpb25zLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgdHlwZSB7IEFjY291bnRDb25maWcsIFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBTZXR0aW5ncyA9IHtcbiAgcGF0OiAnJyxcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcbiAgcmVwbzogJ3gnLFxuICAvLyBUaGUgcmVwbydzIGN1cnJlbnQgZGVmYXVsdCBicmFuY2ggaXMgXCJtYXN0ZXJcIi4gSWYgeW91IGZvcmsgb3IgcmVuYW1lXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXG4gIGJyYW5jaDogJ21hc3RlcicsXG4gIGVuYWJsZWQ6IHRydWUsXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxuICBjb25maWd1cmVkQXQ6IG51bGwsXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcbiAgdXBkYXRlRXhpc3Rpbmc6IHRydWUsXG59O1xuXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xuXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cbiAqXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXG4gKiBHaXRIdWIgUEFUIGluIHBsYWludGV4dC4gQSBkZXRlcm1pbmVkIGF0dGFja2VyIHdpdGggdGhlIGV4dGVuc2lvbidzIHNvdXJjZVxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxuICogc3RyaW5nIHNpdHRpbmcgbmV4dCB0byBpdHMga2V5IG5hbWUgaW4gZXh0ZW5zaW9uIHN0b3JhZ2UuXG4gKlxuICogU2NoZW1lOlxuICogICAtIE9uIGZpcnN0IGVuY3J5cHRpb24gd2UgZ2VuZXJhdGUgYSAzMi1ieXRlIHNhbHQgYW5kIHBlcnNpc3QgaXQgaW5cbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cbiAqICAgICB8fCBcImltbS1hcmNoaXZlLXBhdC12MVwiYC4gVGhlIHNhbHQgYmVpbmcgcGVyLWluc3RhbGwgbWVhbnMgdHdvIGNvcGllc1xuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxuICogICAtIFBsYWludGV4dCBpcyBlbmNyeXB0ZWQgd2l0aCBhIGZyZXNoIDEyLWJ5dGUgSVYuIFRoZSBlbnZlbG9wZSBmb3JtYXQgaXNcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXG4gKlxuICogQmFja3dhcmRzIGNvbXBhdGliaWxpdHk6IGFuIHVucHJlZml4ZWQgdmFsdWUgaXMgdHJlYXRlZCBhcyBsZWdhY3lcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cbiAqL1xuXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xuXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcbiAgbGV0IHMgPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIGJ1ZikgcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShzKTtcbn1cblxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcbiAgY29uc3QgYmluID0gYXRvYihzKTtcbiAgY29uc3Qgb3V0ID0gbmV3IFVpbnQ4QXJyYXkoYmluLmxlbmd0aCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChTQUxUX1NUT1JBR0VfS0VZKTtcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4geyBzYWx0QjY0OiB2LCBzYWx0OiBmcm9tQmFzZTY0KHYpIH07XG4gIH1cbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcbiAgY29uc3Qgc2FsdEI2NCA9IHRvQmFzZTY0KHNhbHQpO1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICBjb25zdCB7IHNhbHRCNjQsIHNhbHQgfSA9IGF3YWl0IGxvYWRPckNyZWF0ZVNhbHQoKTtcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcbiAgfVxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXG4gICk7XG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcbiAgY29tYmluZWQuc2V0KHNhbHQsIHNlZWQubGVuZ3RoKTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcbiAgICAnZW5jcnlwdCcsXG4gICAgJ2RlY3J5cHQnLFxuICBdKTtcbiAgZGVyaXZlZEtleUNhY2hlID0ga2V5O1xuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcbiAgcmV0dXJuIGtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdi5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbmNyeXB0UGF0KHBsYWludGV4dDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gIGNvbnN0IGl2ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMikpO1xuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcbiAgICBrZXksXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcbiAgKTtcbiAgcmV0dXJuIGAke0VOVkVMT1BFX1BSRUZJWH0ke3RvQmFzZTY0KGl2KX06JHt0b0Jhc2U2NChuZXcgVWludDhBcnJheShjdCkpfWA7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWNyeXB0UGF0KGVudmVsb3BlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXG4gIC8vIHJlLWVuY3J5cHRzIGl0IHZpYSB0aGUgc3RvcmFnZSBsYXllci5cbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xuICBpZiAocGFydHMubGVuZ3RoICE9PSAyKSByZXR1cm4gJyc7XG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XG4gIHRyeSB7XG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcbiAgICBjb25zdCBjdCA9IGZyb21CYXNlNjQoY3RCNjQpO1xuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcbiAgICAgIGtleSxcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShwdCk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnJztcbiAgfVxufVxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB7IGRlY3J5cHRQYXQsIGVuY3J5cHRQYXQsIGlzRW5jcnlwdGVkUGF0IH0gZnJvbSAnLi9jcnlwdG8uanMnO1xuaW1wb3J0IHR5cGUge1xuICBBY2NvdW50Q29uZmlnLFxuICBBY2NvdW50Q291bnRlcixcbiAgQ2Fub25pY2FsVHdlZXQsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFNldHRpbmdzLFxuICBVbmF2YWlsYWJsZVR3ZWV0LFxufSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBCdWZmZXJlZCB0d2VldHMgZm9yIGEgZ2l2ZW4gYWNjb3VudCwgYXdhaXRpbmcgY29tbWl0LiBBIFwicnVuXCIgaXMgb25lIGVudHJ5XG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xuICBydW5faWQ6IHN0cmluZztcbiAgYWNjb3VudF9oYW5kbGU6IHN0cmluZztcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcbiAgdHdlZXRzX2J5X2lkOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD47XG4gIHVuYXZhaWxhYmxlX2J5X2lkPzogUmVjb3JkPHN0cmluZywgVW5hdmFpbGFibGVUd2VldD47XG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XG4gIGVuZHBvaW50c19zZWVuOiBzdHJpbmdbXTtcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcbn1cblxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxuICogVXNlZCB0byBza2lwIHJlLWNhcHR1cmluZyB0d2VldHMgd2UndmUgYWxyZWFkeSBwdXNoZWQgd2l0aCBpZGVudGljYWxcbiAqIGVuZ2FnZW1lbnQgY291bnRzIFx1MjAxNCBhdm9pZHMgZ2VuZXJhdGluZyBvbmUgbmV3IHJhdy8qIGZpbGUgZXZlcnkgYnJvd3NlLiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XG4gIHRzOiBzdHJpbmc7IC8vIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3QgY29tbWl0XG4gIHNpZzogc3RyaW5nOyAvLyBlbmdhZ2VtZW50IHNpZ25hdHVyZTogXCJsaWtlfHJ0fHJlcGx5fHF1b3RlXCJcbn1cblxuLyoqIFByb2dyZXNzICsgaW5mbGlnaHQgdHJhY2tpbmcgZm9yIGEgcXVldWUtZHJpdmVuIGxvb3AgKHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCkuXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcbiAqIFwiWCBvZiBZIHByb2Nlc3NlZFwiIFx1MjAxNCBhbmQgdGhlIHdhaXQtZm9yLWluZ2VzdCBndWFyZCBrbm93cyB3aGF0IHRvIGV4cGVjdC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XG4gIC8qKiBJbml0aWFsIHF1ZXVlIHNpemUgd2hlbiB0aGUgdXNlciBjbGlja2VkIFwiU3RhcnRcIi4gKi9cbiAgdG90YWxBdFN0YXJ0OiBudW1iZXI7XG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cbiAgcHJvY2Vzc2VkOiBudW1iZXI7XG4gIC8qKiBJU08gb2Ygd2hlbiB0aGlzIHNlc3Npb24gc3RhcnRlZC4gKi9cbiAgc3RhcnRlZEF0OiBzdHJpbmc7XG4gIC8qKiBUd2VldCBjdXJyZW50bHkgaW5mbGlnaHQgXHUyMDE0IHdlIG5hdmlnYXRlZCB0byBpdCBhbmQgYXJlIHdhaXRpbmcgZm9yIHRoZVxuICAgKiBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgcmVzcG9uc2UgYmVmb3JlIGFkdmFuY2luZy4gbnVsbCBiZXR3ZWVuIHRpY2tzXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xuICBpbmZsaWdodDogeyB0d2VldElkOiBzdHJpbmc7IG5hdmlnYXRlZEF0OiBzdHJpbmcgfSB8IG51bGw7XG59XG5cbi8qKiBBdXRvLXNjcm9sbCBzZXNzaW9uOiBjb3VudHMgb2YgdGlja3MgYW5kIHR3ZWV0cyBpbmdlc3RlZCBzaW5jZSB0aGUgdXNlclxuICogY2xpY2tlZCBTdGFydC4gUGVyc2lzdGVkIHNvIFNXIGV2aWN0aW9uIGR1cmluZyBhIHJ1biBrZWVwcyBwcm9ncmVzcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xuICBzdGFydGVkQXQ6IHN0cmluZztcbiAgc2Nyb2xsQ291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xuICBleHBhbmRlZENvdW50OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xuICBzZXR0aW5nczogU2V0dGluZ3M7XG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XG4gIC8qKiBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IHN1Y2Nlc3NmdWwgYWNjb3VudHMueWFtbCBmZXRjaCBmcm9tIHRoZSByZXBvLlxuICAgKiBVc2VkIGJ5IGByZWZyZXNoQWNjb3VudHNMaXN0YCB0byBza2lwIHJlLWZldGNoaW5nIG9uIGV2ZXJ5IFNXIHdha2UgXHUyMDE0IHRoZVxuICAgKiBmaWxlIGNoYW5nZXMgcmFyZWx5IGFuZCBhbiBhdXRoZW50aWNhdGVkIHJhdyBmZXRjaCBldmVyeSB3YWtlIGFkZHMgdXAuICovXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IHN0cmluZyB8IG51bGw7XG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcbiAgcnVuQnVmZmVyczogUmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPjtcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XG4gIGNvbW1pdHRlZEluZGV4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+O1xuICAvKiogVHdlZXRzIHRoZSBub3JtYWxpemVyIGZsYWdnZWQgYXMgdHJ1bmNhdGVkIGFuZCB0aGF0IHdlIGhhdmVuJ3Qgc2VlbiBhXG4gICAqIGZ1bGwtdGV4dCB2ZXJzaW9uIG9mIHlldC4gS2V5ZWQgYnkgaGFuZGxlIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuICovXG4gIHJlZmV0Y2hRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogVHdlZXQgSURzIHNlZW4gdmlhIE1lZGlhLXRhYiAvIHBhcnRpYWwgY2FwdHVyZXMgdGhhdCBjb3VsZG4ndCBiZVxuICAgKiBub3JtYWxpemVkIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gS2V5ZWQgYnkgaGludC1oYW5kbGUgKG9yXG4gICAqIFwiX3Vua25vd25cIikgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gVGhlIHVzZXIgY2FuIGRyaXZlIGEgY3Jhd2wgdGhhdFxuICAgKiBvcGVucyBlYWNoIGRldGFpbCBwYWdlIHRvIGNhcHR1cmUgdGhlIHJlYWwgdGhpbmcuICovXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBtZWRpYUNyYXdsU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBhdXRvU2Nyb2xsU2Vzc2lvbjogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsO1xufVxuXG5jb25zdCBERUZBVUxUX0NPTk5FQ1RJT046IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgc3RhdHVzOiAndW5rbm93bicsXG4gIGxvZ2luOiBudWxsLFxuICBjaGVja2VkQXQ6IG51bGwsXG4gIGVycm9yOiBudWxsLFxuICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxufTtcblxuY29uc3QgREVGQVVMVFM6IFN0b3JhZ2VTaGFwZSA9IHtcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9LFxuICBhY2NvdW50czogWy4uLkZBTExCQUNLX0FDQ09VTlRTXSxcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogbnVsbCxcbiAgY29ubmVjdGlvbjogeyAuLi5ERUZBVUxUX0NPTk5FQ1RJT04gfSxcbiAgY291bnRlcnM6IHt9LFxuICBydW5CdWZmZXJzOiB7fSxcbiAgYWN0aXZpdHk6IFtdLFxuICBjb21taXR0ZWRJbmRleDoge30sXG4gIHJlZmV0Y2hRdWV1ZToge30sXG4gIG1lZGlhQ3Jhd2xRdWV1ZToge30sXG4gIHJlZmV0Y2hTZXNzaW9uOiBudWxsLFxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcbiAgYXV0b1Njcm9sbFNlc3Npb246IG51bGwsXG59O1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChrZXkpO1xuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUoREVGQVVMVFNba2V5XSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW2tleV06IHZhbHVlIH0pO1xufVxuXG4vLyAtLS0gU2V0dGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICAvLyBCYWNrZmlsbCBhbnkga2V5cyB0aGUgdXNlcidzIHN0b3JlZCBzZXR0aW5ncyBwcmVkYXRlIFx1MjAxNCByZWFkZXJzIGNhbiByZWx5XG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XG4gIC8vIGV2ZXJ5IGNhbGxzaXRlLiBUaGUgUEFUIGlzIHN0b3JlZCBlbmNyeXB0ZWQtYXQtcmVzdCBhcyBvZiB2MC4yLjA7IHdlXG4gIC8vIGRlY3J5cHQgdHJhbnNwYXJlbnRseSBzbyBjYWxsZXJzIGNvbnRpbnVlIHRvIHNlZSBwbGFpbnRleHQuXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcbiAgY29uc3QgbWVyZ2VkID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi5zdG9yZWQgfTtcbiAgaWYgKG1lcmdlZC5wYXQgJiYgaXNFbmNyeXB0ZWRQYXQobWVyZ2VkLnBhdCkpIHtcbiAgICB0cnkge1xuICAgICAgbWVyZ2VkLnBhdCA9IGF3YWl0IGRlY3J5cHRQYXQobWVyZ2VkLnBhdCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBtZXJnZWQucGF0ID0gJyc7XG4gICAgfVxuICB9XG4gIHJldHVybiBtZXJnZWQ7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXG4gIC8vIG9uIHRoZSBuZXh0IHNhdmUuXG4gIGNvbnN0IHRvV3JpdGU6IFNldHRpbmdzID0geyAuLi5zIH07XG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XG4gICAgdG9Xcml0ZS5wYXQgPSBhd2FpdCBlbmNyeXB0UGF0KHRvV3JpdGUucGF0KTtcbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2V0dGluZ3MocGF0Y2g6IFBhcnRpYWw8U2V0dGluZ3M+KTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBuZXh0ID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGF3YWl0IHNldFNldHRpbmdzKG5leHQpO1xuICByZXR1cm4gbmV4dDtcbn1cblxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzKCk6IFByb21pc2U8QWNjb3VudENvbmZpZ1tdPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHMoYTogQWNjb3VudENvbmZpZ1tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50c1JlZnJlc2hlZEF0KCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHNSZWZyZXNoZWRBdChpc286IHN0cmluZyB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcbn1cblxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29ubmVjdGlvbigpOiBQcm9taXNlPENvbm5lY3Rpb25TdGF0ZT4ge1xuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XG4gIC8vIEJhY2tmaWxsIGZpZWxkcyBhZGRlZCBhZnRlciB0aGUgdXNlcidzIHN0b3JhZ2Ugd2FzIHdyaXR0ZW4uXG4gIGNvbnN0IG91dDogQ29ubmVjdGlvblN0YXRlID0ge1xuICAgIC4uLmMsXG4gICAgZGVmYXVsdEJyYW5jaDogYy5kZWZhdWx0QnJhbmNoID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5kZWZhdWx0QnJhbmNoLFxuICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6XG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgcmF0ZUxpbWl0UmVzZXRBdDogYy5yYXRlTGltaXRSZXNldEF0ID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5yYXRlTGltaXRSZXNldEF0LFxuICB9O1xuICByZXR1cm4gb3V0O1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xufVxuXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ2NvdW50ZXJzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xuICAgIHRvZGF5Q291bnQ6IDAsXG4gICAgdG9kYXlEYXRlOiB0b2RheUlTTygpLFxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXG4gICAgYnVmZmVyZWRDb3VudDogMCxcbiAgfTtcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcbiAgICBjdXIudG9kYXlEYXRlID0gdG9kYXlJU08oKTtcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XG4gIH1cbiAgY29uc3QgbmV4dDogQWNjb3VudENvdW50ZXIgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRCdWZmZXJlZENvdW50KGhhbmRsZTogc3RyaW5nLCBjb3VudDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcbn1cblxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj4+IHtcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgcmV0dXJuIGFsbFtoYW5kbGVdID8/IG51bGw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcsIGJ1ZjogUnVuQnVmZmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYWxsW2hhbmRsZV0gPSBidWY7XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcbn1cblxuLy8gLS0tIEFjdGl2aXR5IHRhaWwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY3Rpdml0eScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwZW5kQWN0aXZpdHkoZXY6IExvZ0V2ZW50KTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XG4gIGN1ci51bnNoaWZ0KGV2KTtcbiAgaWYgKGN1ci5sZW5ndGggPiBBQ1RJVklUWV9UQUlMX01BWCkgY3VyLmxlbmd0aCA9IEFDVElWSVRZX1RBSUxfTUFYO1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcbiAgcmV0dXJuIGN1cjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBbXSk7XG59XG5cbi8vIC0tLSBDb21taXR0ZWQtdHdlZXRzIGRlZHVwIGluZGV4IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb21taXR0ZWRJbmRleCcpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29tbWl0dGVkSW5kZXgoXG4gIGlkeDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PlxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29tbWl0dGVkSW5kZXgnLCBpZHgpO1xufVxuXG4vKiogQ29tcHV0ZSB0aGUgZW5nYWdlbWVudCBzaWduYXR1cmUgd2UgdXNlIHRvIGRlY2lkZSB3aGV0aGVyIGEgcmUtY2FwdHVyZWRcbiAqIHR3ZWV0IGlzIFwibWF0ZXJpYWxseSBkaWZmZXJlbnRcIiBmcm9tIHdoYXQgd2UgbGFzdCBjb21taXR0ZWQuIFdlIG9taXRcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXG4gKiBkZWZlYXQgdGhlIGRlZHVwLiBMaWtlcyAvIFJUcyAvIHJlcGxpZXMgLyBxdW90ZXMgY2hhbmdlIHJhcmVseSBlbm91Z2ggdGhhdFxuICogZWFjaCBjaGFuZ2UgaXMgd29ydGggYSByZS1jb21taXQgKGFuZCBhbiBlbmdhZ2VtZW50X2hpc3Rvcnkgc25hcHNob3QpLlxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxuICogdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkgYnlwYXNzZXMgdGhlIGRlZHVwIGV2ZW4gd2hlbiBlbmdhZ2VtZW50IGNvdW50c1xuICogaGF2ZW4ndCBtb3ZlZCBcdTIwMTQgb3RoZXJ3aXNlIHRoZSBuZXcgYm9keSB3b3VsZCBiZSBzaWxlbnRseSBkcm9wcGVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXG4gIGxpa2VzOiBudW1iZXIsXG4gIHJldHdlZXRzOiBudW1iZXIsXG4gIHJlcGxpZXM6IG51bWJlcixcbiAgcXVvdGVzOiBudW1iZXIsXG4gIGlzVHJ1bmNhdGVkOiBib29sZWFuID0gZmFsc2Vcbik6IHN0cmluZyB7XG4gIHJldHVybiBgJHtsaWtlc318JHtyZXR3ZWV0c318JHtyZXBsaWVzfXwke3F1b3Rlc318JHtpc1RydW5jYXRlZCA/ICd0JyA6ICdmJ31gO1xufVxuXG4vKiogRHJvcCBlbnRyaWVzIG9sZGVyIHRoYW4gYG1heEFnZU1zYC4gUmV0dXJucyB0aGUgbnVtYmVyIHBydW5lZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcnVuZUNvbW1pdHRlZEluZGV4KG1heEFnZU1zOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBjb25zdCBjdXRvZmYgPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gbWF4QWdlTXMpLnRvSVNPU3RyaW5nKCk7XG4gIGxldCBwcnVuZWQgPSAwO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgY29uc3QgaW5uZXIgPSBpZHhbaGFuZGxlXTtcbiAgICBpZiAoIWlubmVyKSBjb250aW51ZTtcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcbiAgICAgIGNvbnN0IGUgPSBpbm5lclt0aWRdO1xuICAgICAgaWYgKGUgJiYgZS50cyA8IGN1dG9mZikge1xuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcbiAgICAgICAgcHJ1bmVkICs9IDE7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhpbm5lcikubGVuZ3RoID09PSAwKSBkZWxldGUgaWR4W2hhbmRsZV07XG4gIH1cbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG4gIHJldHVybiBwcnVuZWQ7XG59XG5cbi8vIC0tLSBSZWZldGNoIHF1ZXVlICh0d2VldHMgbmVlZGluZyBmdWxsLXRleHQgcmVjYXB0dXJlKSAtLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hRdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbaGFuZGxlXSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdO1xuICBpZiAoIWlkcykgcmV0dXJuO1xuICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2hhbmRsZV07XG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0UmVmZXRjaFRhcmdldCgpOiBQcm9taXNlPHtcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIHR3ZWV0SWQ6IHN0cmluZztcbn0gfCBudWxsPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBoYW5kbGUsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVNZWRpYUNyYXdsKGhpbnRIYW5kbGU6IHN0cmluZyB8IG51bGwsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcbiAgY29uc3QgaWRzID0gcVtidWNrZXRdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbYnVja2V0XSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcbiAgICBpZiAoIWlkcykgY29udGludWU7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XG4gICAgfVxuICB9XG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTogUHJvbWlzZTx7XG4gIGJ1Y2tldDogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgYnVja2V0LCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXG4gKiBlbnF1ZXVlaW5nIG1lZGlhLWNyYXdsIHRhcmdldHMgd2UndmUgYWxyZWFkeSBhcmNoaXZlZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpc0NvbW1pdHRlZCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgZm9yIChjb25zdCBpbm5lciBvZiBPYmplY3QudmFsdWVzKGlkeCkpIHtcbiAgICBpZiAoaW5uZXIgJiYgdHdlZXRJZCBpbiBpbm5lcikgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyAtLS0gTG9vcCBzZXNzaW9uIHN0YXRlIChwcm9ncmVzcyArIGluZmxpZ2h0IGdhdGluZykgLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEF1dG9TY3JvbGxTZXNzaW9uKCk6IFByb21pc2U8QXV0b1Njcm9sbFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXV0b1Njcm9sbFNlc3Npb24oczogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nLCBzKTtcbn1cblxuLy8gLS0tIFB1cmdlOiB1bnJlbGF0ZWQgYnVmZmVycywgY291bnRlcnMsIHF1ZXVlIGVudHJpZXMgLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vKipcbiAqIERyb3AgZXZlcnkgcGVyLWhhbmRsZSBiaXQgb2Ygc3RhdGUgKGNvdW50ZXJzLCBydW4gYnVmZmVyLCBjb21taXR0ZWQtaW5kZXhcbiAqIGVudHJpZXMsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyaWVzKSB0aGF0IGRvZXNuJ3QgY29ycmVzcG9uZCB0byBhXG4gKiB0cmFja2VkIGFjY291bnQuIFJldHVybnMgYSBzdW1tYXJ5IGRlc2NyaWJpbmcgd2hhdCB3YXMgY2xlYXJlZCBzbyB0aGVcbiAqIGNhbGxlciBjYW4gbG9nIGl0LlxuICpcbiAqIFRyYWNrZWQgYWNjb3VudHMgYXJlIHBhc3NlZCBpbiAoY2FsbGVyIHJlc29sdmVzIGZyb20gdGhlIGxpdmUgY29uZmlnKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1cmdlVW5yZWxhdGVkU3RhdGUodGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4pOiBQcm9taXNlPHtcbiAgY291bnRlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGJ1ZmZlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XG4gIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xuICBtZWRpYUNyYXdsSWRzUmVtb3ZlZDogbnVtYmVyO1xufT4ge1xuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcbiAgY29uc3QgaXNUYXJnZXRlZCA9IChoOiBzdHJpbmcpOiBib29sZWFuID0+IHRhcmdMb3dlci5oYXMoaC50b0xvd2VyQ2FzZSgpKTtcblxuICAvLyBDb3VudGVyc1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCBjb3VudGVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgY291bnRlcnNbaF07XG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcblxuICAvLyBSdW4gYnVmZmVyc1xuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBsZXQgYnVmZmVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoYnVmZmVycykpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBidWZmZXJzW2hdO1xuICAgICAgYnVmZmVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYnVmZmVycyk7XG5cbiAgLy8gQ29tbWl0dGVkIGRlZHVwIGluZGV4XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgaWR4W2hdO1xuICAgICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcblxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXG4gIGNvbnN0IHJxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGxldCByZWZldGNoSGFuZGxlc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgcnFbaF07XG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XG5cbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IGJ1Y2tldHMgYXJlIGhpbnQtaGFuZGxlcyAob3IgXCJfdW5rbm93blwiKS4gRHJvcFxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCBcdTIwMTQgaW5jbHVkaW5nIFwiX3Vua25vd25cIiBzaW5jZSB3ZVxuICAvLyBjYW4ndCB2ZXJpZnkgcmVsYXRpb24uXG4gIGNvbnN0IG1xID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhtcSkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xuICAgICAgZGVsZXRlIG1xW2hdO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIG1xKTtcblxuICByZXR1cm4ge1xuICAgIGNvdW50ZXJzUmVtb3ZlZCxcbiAgICBidWZmZXJzUmVtb3ZlZCxcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcbiAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQsXG4gICAgbWVkaWFDcmF3bElkc1JlbW92ZWQsXG4gIH07XG59XG5cbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbn1cbiIsICIvKipcbiAqIG9wdGlvbnMudHMgXHUyMDE0IHNldHRpbmdzIHBhZ2UuXG4gKlxuICogU3RvcmVzIFBBVCBhbmQgcmVwbyBpZGVudGlmaWVycyBpbiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgdmVyaWZpZXMgYWNjZXNzXG4gKiBieSBjYWxsaW5nIC91c2VyIGFuZCAvcmVwb3MvOm93bmVyLzpyZXBvLCBhbmQgc3VyZmFjZXMgdGhlIHJlc3VsdGluZ1xuICogY29ubmVjdGlvbiBzdGF0ZS5cbiAqL1xuXG5pbXBvcnQgeyBERUZBVUxUX1NFVFRJTkdTIH0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcbmltcG9ydCB7XG4gIGNsZWFyQWxsLFxuICBnZXRBY2NvdW50cyxcbiAgZ2V0QWN0aXZpdHksXG4gIGdldENvbm5lY3Rpb24sXG4gIGdldENvdW50ZXJzLFxuICBnZXRSdW5CdWZmZXJzLFxuICBnZXRTZXR0aW5ncyxcbiAgdXBkYXRlU2V0dGluZ3MsXG59IGZyb20gJy4vbGliL3N0b3JhZ2UuanMnO1xuaW1wb3J0IHR5cGUgeyBSdW50aW1lTWVzc2FnZSB9IGZyb20gJy4vbGliL3R5cGVzLmpzJztcblxuY29uc3QgJCA9IDxUIGV4dGVuZHMgSFRNTEVsZW1lbnQgPSBIVE1MRWxlbWVudD4oaWQ6IHN0cmluZyk6IFQgPT4ge1xuICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcbiAgaWYgKCFlbCkgdGhyb3cgbmV3IEVycm9yKGBtaXNzaW5nIGVsZW1lbnQgIyR7aWR9YCk7XG4gIHJldHVybiBlbCBhcyBUO1xufTtcblxuY29uc3QgZm9ybSA9ICQ8SFRNTEZvcm1FbGVtZW50Pignc2V0dGluZ3MtZm9ybScpO1xuY29uc3Qgb3duZXJJbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ293bmVyJyk7XG5jb25zdCByZXBvSW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdyZXBvJyk7XG5jb25zdCBicmFuY2hJbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2JyYW5jaCcpO1xuY29uc3QgcGF0SW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdwYXQnKTtcbmNvbnN0IHJldmVhbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZXZlYWwtcGF0Jyk7XG5jb25zdCBzYXZlU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdzYXZlLXN0YXR1cycpO1xuY29uc3QgY29ubkRldGFpbCA9ICQoJ2Nvbm4tZGV0YWlsJyk7XG5jb25zdCBhY2NvdW50TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjY291bnQtcmVhZG9ubHknKTtcbmNvbnN0IHJlZnJlc2hCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmcmVzaC1hY2NvdW50cycpO1xuY29uc3QgZGlhZ0JveCA9ICQ8SFRNTFRleHRBcmVhRWxlbWVudD4oJ2RpYWdub3N0aWNzJyk7XG5jb25zdCBjb3B5RGlhZ0J0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjb3B5LWRpYWdub3N0aWNzJyk7XG5jb25zdCBjbGVhclN0b3JhZ2VCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2xlYXItc3RvcmFnZScpO1xuY29uc3QgZGlhZ1N0YXR1cyA9ICQ8SFRNTFNwYW5FbGVtZW50PignZGlhZy1zdGF0dXMnKTtcblxuYXN5bmMgZnVuY3Rpb24gc2VuZDxUPihtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTxUPiB7XG4gIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKSBhcyBQcm9taXNlPFQ+O1xufVxuXG5mdW5jdGlvbiBzZXRTdGF0dXMoZWw6IEhUTUxFbGVtZW50LCBraW5kOiAnb2snIHwgJ2VycicgfCAnd2FybicgfCAnJywgbXNnOiBzdHJpbmcpOiB2b2lkIHtcbiAgZWwuY2xhc3NOYW1lID0ga2luZCA/IGBzdGF0dXMgJHtraW5kfWAgOiAnc3RhdHVzJztcbiAgZWwudGV4dENvbnRlbnQgPSBtc2c7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWRTZXR0aW5ncygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIG93bmVySW5wdXQudmFsdWUgPSBzLm93bmVyIHx8IERFRkFVTFRfU0VUVElOR1Mub3duZXI7XG4gIHJlcG9JbnB1dC52YWx1ZSA9IHMucmVwbyB8fCBERUZBVUxUX1NFVFRJTkdTLnJlcG87XG4gIGJyYW5jaElucHV0LnZhbHVlID0gcy5icmFuY2ggfHwgREVGQVVMVF9TRVRUSU5HUy5icmFuY2g7XG4gIGlmIChzLnBhdCkge1xuICAgIHBhdElucHV0LnZhbHVlID0gcy5wYXQ7XG4gICAgcGF0SW5wdXQucGxhY2Vob2xkZXIgPSBgXHUyMDI2JHtzLnBhdC5zbGljZSgtNCl9YDtcbiAgfVxuICBhd2FpdCBwYWludENvbm5EZXRhaWwoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcGFpbnRDb25uRGV0YWlsKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgbGluZXM6IHN0cmluZ1tdID0gW107XG4gIGxpbmVzLnB1c2goYFN0YXR1czogJHtjb25uLnN0YXR1c31gKTtcbiAgaWYgKGNvbm4ubG9naW4pIGxpbmVzLnB1c2goYExvZ2dlZCBpbiBhczogQCR7Y29ubi5sb2dpbn1gKTtcbiAgbGluZXMucHVzaChgUmVwb3NpdG9yeTogJHtzLm93bmVyIHx8ICc/J30vJHtzLnJlcG8gfHwgJz8nfUAke3MuYnJhbmNoIHx8ICc/J31gKTtcbiAgaWYgKGNvbm4uY2hlY2tlZEF0KSBsaW5lcy5wdXNoKGBMYXN0IGNoZWNrZWQ6ICR7Y29ubi5jaGVja2VkQXR9YCk7XG4gIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcgJiYgY29ubi5yYXRlTGltaXRSZXNldEF0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgcmVzZXRJc28gPSBuZXcgRGF0ZShjb25uLnJhdGVMaW1pdFJlc2V0QXQgKiAxMDAwKS50b0lTT1N0cmluZygpO1xuICAgIGNvbnN0IGRlbHRhU2VjID0gY29ubi5yYXRlTGltaXRSZXNldEF0IC0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gICAgY29uc3QgaW5MYWJlbCA9XG4gICAgICBkZWx0YVNlYyA8PSAwXG4gICAgICAgID8gJ21vbWVudGFyaWx5J1xuICAgICAgICA6IGRlbHRhU2VjIDwgNjBcbiAgICAgICAgICA/IGBpbiAke2RlbHRhU2VjfXNgXG4gICAgICAgICAgOiBkZWx0YVNlYyA8IDM2MDBcbiAgICAgICAgICAgID8gYGluICR7TWF0aC5yb3VuZChkZWx0YVNlYyAvIDYwKX1tYFxuICAgICAgICAgICAgOiBgaW4gJHtNYXRoLnJvdW5kKGRlbHRhU2VjIC8gMzYwMCl9aGA7XG4gICAgbGluZXMucHVzaChgUmF0ZSBsaW1pdCByZXNldHM6ICR7cmVzZXRJc299ICgke2luTGFiZWx9KWApO1xuICB9XG4gIGlmIChjb25uLmVycm9yKSBsaW5lcy5wdXNoKGBFcnJvcjogJHtjb25uLmVycm9yfWApO1xuICBjb25uRGV0YWlsLnRleHRDb250ZW50ID0gbGluZXMuam9pbignXFxuJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHBhaW50QWNjb3VudHMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGxpc3QgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICBhY2NvdW50TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgZm9yIChjb25zdCBhIG9mIGxpc3QpIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgY29uc3QgaGFuZGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGhhbmRsZS5jbGFzc05hbWUgPSAnaGFuZGxlJztcbiAgICBoYW5kbGUudGV4dENvbnRlbnQgPSBgQCR7YS5oYW5kbGV9YDtcbiAgICBjb25zdCBsYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBsYWJlbC5jbGFzc05hbWUgPSAnbGFiZWwnO1xuICAgIGxhYmVsLnRleHRDb250ZW50ID0gYS5sYWJlbDtcbiAgICBsaS5hcHBlbmQoaGFuZGxlLCBsYWJlbCk7XG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcbiAgfVxufVxuXG5mb3JtLmFkZEV2ZW50TGlzdGVuZXIoJ3N1Ym1pdCcsIGFzeW5jIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIGNvbnN0IHBhdCA9IHBhdElucHV0LnZhbHVlLnRyaW0oKTtcbiAgY29uc3Qgb3duZXIgPSBvd25lcklucHV0LnZhbHVlLnRyaW0oKTtcbiAgY29uc3QgcmVwbyA9IHJlcG9JbnB1dC52YWx1ZS50cmltKCk7XG4gIGNvbnN0IGJyYW5jaCA9IGJyYW5jaElucHV0LnZhbHVlLnRyaW0oKSB8fCAnbWFpbic7XG4gIGlmICghcGF0IHx8ICFvd25lciB8fCAhcmVwbykge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgJ0FsbCBmaWVsZHMgYXJlIHJlcXVpcmVkLicpO1xuICAgIHJldHVybjtcbiAgfVxuICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJycsICdTYXZpbmdcdTIwMjYnKTtcbiAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBwYXQsIG93bmVyLCByZXBvLCBicmFuY2gsIGNvbmZpZ3VyZWRBdDogRGF0ZS5ub3coKSB9KTtcbiAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICcnLCAnVmVyaWZ5aW5nXHUyMDI2Jyk7XG4gIGF3YWl0IHNlbmQoeyB0eXBlOiAndmVyaWZ5LWNvbm5lY3Rpb24nIH0pO1xuICBhd2FpdCBzZW5kKHsgdHlwZTogJ3JlZnJlc2gtYWNjb3VudHMnIH0pO1xuICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICBpZiAoY29ubi5zdGF0dXMgPT09ICdvaycpIHtcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ29rJywgYENvbm5lY3RlZCBhcyBAJHtjb25uLmxvZ2luID8/ICc/J30uYCk7XG4gIH0gZWxzZSBpZiAoY29ubi5zdGF0dXMgPT09ICdhdXRoLWVycm9yJykge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgJ0F1dGggZmFpbGVkIFx1MjAxNCBjaGVjayB0aGUgUEFUIGFuZCBpdHMgcmVwbyBzY29wZS4nKTtcbiAgfSBlbHNlIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ3dhcm4nLCAnUmF0ZS1saW1pdGVkIFx1MjAxNCB0b2tlbiBpcyB2YWxpZCBidXQgR2l0SHViIGlzIHRocm90dGxpbmcuJyk7XG4gIH0gZWxzZSBpZiAoY29ubi5zdGF0dXMgPT09ICduZXR3b3JrLWVycm9yJykge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgJ05ldHdvcmsgZXJyb3IgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpdml0eS4nKTtcbiAgfSBlbHNlIHtcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ2VycicsIGBWZXJpZmljYXRpb246ICR7Y29ubi5zdGF0dXN9YCk7XG4gIH1cbiAgYXdhaXQgcGFpbnRDb25uRGV0YWlsKCk7XG4gIGF3YWl0IHBhaW50QWNjb3VudHMoKTtcbiAgYXdhaXQgcmVmcmVzaERpYWcoKTtcbn0pO1xuXG5yZXZlYWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGlmIChwYXRJbnB1dC50eXBlID09PSAncGFzc3dvcmQnKSB7XG4gICAgcGF0SW5wdXQudHlwZSA9ICd0ZXh0JztcbiAgICByZXZlYWxCdG4udGV4dENvbnRlbnQgPSAnSGlkZSc7XG4gIH0gZWxzZSB7XG4gICAgcGF0SW5wdXQudHlwZSA9ICdwYXNzd29yZCc7XG4gICAgcmV2ZWFsQnRuLnRleHRDb250ZW50ID0gJ1Nob3cnO1xuICB9XG59KTtcblxucmVmcmVzaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgcmVmcmVzaEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdyZWZyZXNoLWFjY291bnRzJyB9KTtcbiAgICBhd2FpdCBwYWludEFjY291bnRzKCk7XG4gICAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICdvaycsICdBY2NvdW50cyByZWZyZXNoZWQuJyk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnZXJyJywgYFJlZnJlc2ggZmFpbGVkOiAkeyhlcnIgYXMgRXJyb3IpLm1lc3NhZ2V9YCk7XG4gIH0gZmluYWxseSB7XG4gICAgcmVmcmVzaEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaERpYWcoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IFtzZXR0aW5ncywgY29ubiwgYWNjb3VudHMsIGNvdW50ZXJzLCBidWZmZXJzLCBhY3Rpdml0eV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgZ2V0U2V0dGluZ3MoKSxcbiAgICBnZXRDb25uZWN0aW9uKCksXG4gICAgZ2V0QWNjb3VudHMoKSxcbiAgICBnZXRDb3VudGVycygpLFxuICAgIGdldFJ1bkJ1ZmZlcnMoKSxcbiAgICBnZXRBY3Rpdml0eSgpLFxuICBdKTtcbiAgY29uc3QgcmVkYWN0ZWRCdWZmZXJzID0gT2JqZWN0LmZyb21FbnRyaWVzKFxuICAgIE9iamVjdC5lbnRyaWVzKGJ1ZmZlcnMpLm1hcCgoW2ssIGJdKSA9PiBbXG4gICAgICBrLFxuICAgICAge1xuICAgICAgICBydW5faWQ6IGIucnVuX2lkLFxuICAgICAgICBzdGFydGVkX2F0OiBiLnN0YXJ0ZWRfYXQsXG4gICAgICAgIGxhc3RfY2FwdHVyZV9hdDogYi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICAgIHR3ZWV0c19jb3VudDogT2JqZWN0LmtleXMoYi50d2VldHNfYnlfaWQpLmxlbmd0aCxcbiAgICAgICAgb2JzZXJ2ZWRfY291bnQ6IGIudHdlZXRfaWRzX29ic2VydmVkLmxlbmd0aCxcbiAgICAgICAgZW5kcG9pbnRzX3NlZW46IGIuZW5kcG9pbnRzX3NlZW4sXG4gICAgICAgIHNvdXJjZV91cmw6IGIuc291cmNlX3VybCxcbiAgICAgIH0sXG4gICAgXSlcbiAgKTtcbiAgY29uc3QgZHVtcCA9IHtcbiAgICB2ZXJzaW9uOiBicm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uLFxuICAgIHVzZXJfYWdlbnQ6IG5hdmlnYXRvci51c2VyQWdlbnQsXG4gICAgc2V0dGluZ3M6IHtcbiAgICAgIG93bmVyOiBzZXR0aW5ncy5vd25lcixcbiAgICAgIHJlcG86IHNldHRpbmdzLnJlcG8sXG4gICAgICBicmFuY2g6IHNldHRpbmdzLmJyYW5jaCxcbiAgICAgIGF1dG9DYXB0dXJlOiBzZXR0aW5ncy5hdXRvQ2FwdHVyZSxcbiAgICAgIGNvbmZpZ3VyZWRBdDogc2V0dGluZ3MuY29uZmlndXJlZEF0LFxuICAgICAgcGF0U2V0OiBzZXR0aW5ncy5wYXQubGVuZ3RoID4gMCxcbiAgICAgIHBhdFN1ZmZpeDogc2V0dGluZ3MucGF0Lmxlbmd0aCA+PSA0ID8gc2V0dGluZ3MucGF0LnNsaWNlKC00KSA6ICcnLFxuICAgIH0sXG4gICAgY29ubmVjdGlvbjogY29ubixcbiAgICBhY2NvdW50cyxcbiAgICBjb3VudGVycyxcbiAgICBydW5CdWZmZXJzOiByZWRhY3RlZEJ1ZmZlcnMsXG4gICAgYWN0aXZpdHlfdGFpbF9zaXplOiBhY3Rpdml0eS5sZW5ndGgsXG4gICAgYWN0aXZpdHlfcmVjZW50OiBhY3Rpdml0eS5zbGljZSgwLCAzMCksXG4gIH07XG4gIGRpYWdCb3gudmFsdWUgPSBKU09OLnN0cmluZ2lmeShkdW1wLCBudWxsLCAyKTtcbn1cblxuY29weURpYWdCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGF3YWl0IG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KGRpYWdCb3gudmFsdWUpO1xuICBzZXRTdGF0dXMoZGlhZ1N0YXR1cywgJ29rJywgJ0NvcGllZCBkaWFnbm9zdGljcyB0byBjbGlwYm9hcmQuJyk7XG59KTtcblxuY2xlYXJTdG9yYWdlQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBjb25zdCBvayA9IHdpbmRvdy5jb25maXJtKFxuICAgICdDbGVhciBleHRlbnNpb24gc3RvcmFnZT8gVGhpcyBlcmFzZXMgeW91ciBQQVQsIHNldHRpbmdzLCBjb3VudGVycywgYnVmZmVyZWQgY2FwdHVyZXMsIGFuZCBhY3Rpdml0eSB0YWlsLiBUaGVyZSBpcyBubyB1bmRvLidcbiAgKTtcbiAgaWYgKCFvaykgcmV0dXJuO1xuICBhd2FpdCBjbGVhckFsbCgpO1xuICBzZXRTdGF0dXMoZGlhZ1N0YXR1cywgJ3dhcm4nLCAnU3RvcmFnZSBjbGVhcmVkLicpO1xuICBhd2FpdCBsb2FkU2V0dGluZ3MoKTtcbiAgYXdhaXQgcGFpbnRBY2NvdW50cygpO1xuICBhd2FpdCByZWZyZXNoRGlhZygpO1xufSk7XG5cbnZvaWQgbG9hZFNldHRpbmdzKCk7XG52b2lkIHBhaW50QWNjb3VudHMoKTtcbnZvaWQgcmVmcmVzaERpYWcoKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFBQSxFQUNQLE1BQU07QUFBQTtBQUFBO0FBQUEsRUFHTixRQUFRO0FBQUEsRUFDUixTQUFTO0FBQUEsRUFDVCxhQUFhO0FBQUEsRUFDYixjQUFjO0FBQUEsRUFDZCx1QkFBdUI7QUFBQSxFQUN2QixnQkFBZ0I7QUFDbEI7QUFPTyxJQUFNLG9CQUFxQztBQUFBLEVBQ2hELEVBQUUsUUFBUSxVQUFVLE9BQU8sbUNBQW1DLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxVQUFVLE9BQU8sNENBQTRDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxPQUFPLE9BQU8sc0NBQXNDLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxTQUFTLE9BQU8sNkNBQTZDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxjQUFjLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUFBLEVBQ25FLEVBQUUsUUFBUSxZQUFZLE9BQU8sK0JBQStCLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sa0NBQWtDLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sNEJBQTRCLFVBQVUsT0FBTztBQUFBLEVBQ3ZFLEVBQUUsUUFBUSxtQkFBbUIsT0FBTyxxQkFBcUIsVUFBVSxPQUFPO0FBQzVFO0FBOERPLElBQU0sZ0NBQWdDLEtBQUssS0FBSzs7O0FDckV2RCxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGtCQUFrQjtBQUV4QixJQUFJLGtCQUFvQztBQUN4QyxJQUFJLHNCQUFxQztBQUV6QyxTQUFTLFNBQVMsS0FBeUI7QUFDekMsTUFBSSxJQUFJO0FBQ1IsYUFBVyxLQUFLLElBQUssTUFBSyxPQUFPLGFBQWEsQ0FBQztBQUMvQyxTQUFPLEtBQUssQ0FBQztBQUNmO0FBRUEsU0FBUyxXQUFXLEdBQXVCO0FBQ3pDLFFBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsUUFBTSxNQUFNLElBQUksV0FBVyxJQUFJLE1BQU07QUFDckMsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsSUFBSyxLQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQztBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxlQUFlLG1CQUFtRTtBQUNoRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUMvRCxRQUFNLElBQUksT0FBTyxnQkFBZ0I7QUFDakMsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxXQUFPLEVBQUUsU0FBUyxHQUFHLE1BQU0sV0FBVyxDQUFDLEVBQUU7QUFBQSxFQUMzQztBQUNBLFFBQU0sT0FBTyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxTQUFTLElBQUk7QUFDN0IsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUM7QUFDL0QsU0FBTyxFQUFFLFNBQVMsS0FBSztBQUN6QjtBQUVBLGVBQWUsWUFBZ0M7QUFDN0MsUUFBTSxFQUFFLFNBQVMsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBQ2pELE1BQUksb0JBQW9CLFFBQVEsd0JBQXdCLFNBQVM7QUFDL0QsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUU7QUFBQSxJQUM3QixHQUFHLFFBQVEsUUFBUSxFQUFFLElBQUksUUFBUSxRQUFRLFlBQVksRUFBRSxPQUFPO0FBQUEsRUFDaEU7QUFDQSxRQUFNLFdBQVcsSUFBSSxXQUFXLEtBQUssU0FBUyxLQUFLLE1BQU07QUFDekQsV0FBUyxJQUFJLE1BQU0sQ0FBQztBQUNwQixXQUFTLElBQUksTUFBTSxLQUFLLE1BQU07QUFDOUIsUUFBTSxPQUFPLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxRQUFRO0FBQzNELFFBQU0sTUFBTSxNQUFNLE9BQU8sT0FBTyxVQUFVLE9BQU8sTUFBTSxFQUFFLE1BQU0sVUFBVSxHQUFHLE9BQU87QUFBQSxJQUNqRjtBQUFBLElBQ0E7QUFBQSxFQUNGLENBQUM7QUFDRCxvQkFBa0I7QUFDbEIsd0JBQXNCO0FBQ3RCLFNBQU87QUFDVDtBQUVPLFNBQVMsZUFBZSxHQUFvQjtBQUNqRCxTQUFPLEVBQUUsV0FBVyxlQUFlO0FBQ3JDO0FBRUEsZUFBc0IsV0FBVyxXQUFvQztBQUNuRSxNQUFJLENBQUMsVUFBVyxRQUFPO0FBQ3ZCLFFBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsUUFBTSxLQUFLLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDcEQsUUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsSUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBRztBQUFBLElBQ3RCO0FBQUEsSUFDQSxJQUFJLFlBQVksRUFBRSxPQUFPLFNBQVM7QUFBQSxFQUNwQztBQUNBLFNBQU8sR0FBRyxlQUFlLEdBQUcsU0FBUyxFQUFFLENBQUMsSUFBSSxTQUFTLElBQUksV0FBVyxFQUFFLENBQUMsQ0FBQztBQUMxRTtBQUVBLGVBQXNCLFdBQVcsVUFBbUM7QUFDbEUsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUd0QixNQUFJLENBQUMsU0FBUyxXQUFXLGVBQWUsRUFBRyxRQUFPO0FBQ2xELFFBQU0sUUFBUSxTQUFTLE1BQU0sZ0JBQWdCLE1BQU0sRUFBRSxNQUFNLEdBQUc7QUFDOUQsTUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBQy9CLFFBQU0sQ0FBQyxPQUFPLEtBQUssSUFBSTtBQUN2QixNQUFJLENBQUMsU0FBUyxDQUFDLE1BQU8sUUFBTztBQUM3QixNQUFJO0FBQ0YsVUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsTUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBdUI7QUFBQSxNQUMxQztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsV0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEVBQUU7QUFBQSxFQUNwQyxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjs7O0FDMUJBLElBQU0scUJBQXNDO0FBQUEsRUFDMUMsUUFBUTtBQUFBLEVBQ1IsT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUFBLEVBQ1AsZUFBZTtBQUFBLEVBQ2Ysd0JBQXdCO0FBQUEsRUFDeEIsa0JBQWtCO0FBQ3BCO0FBRUEsSUFBTSxXQUF5QjtBQUFBLEVBQzdCLFVBQVUsRUFBRSxHQUFHLGlCQUFpQjtBQUFBLEVBQ2hDLFVBQVUsQ0FBQyxHQUFHLGlCQUFpQjtBQUFBLEVBQy9CLHFCQUFxQjtBQUFBLEVBQ3JCLFlBQVksRUFBRSxHQUFHLG1CQUFtQjtBQUFBLEVBQ3BDLFVBQVUsQ0FBQztBQUFBLEVBQ1gsWUFBWSxDQUFDO0FBQUEsRUFDYixVQUFVLENBQUM7QUFBQSxFQUNYLGdCQUFnQixDQUFDO0FBQUEsRUFDakIsY0FBYyxDQUFDO0FBQUEsRUFDZixpQkFBaUIsQ0FBQztBQUFBLEVBQ2xCLGdCQUFnQjtBQUFBLEVBQ2hCLG1CQUFtQjtBQUFBLEVBQ25CLG1CQUFtQjtBQUNyQjtBQUVBLGVBQWUsT0FBcUMsS0FBa0M7QUFDcEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxHQUFHO0FBQ2xELFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsTUFBSSxVQUFVLFFBQVc7QUFDdkIsV0FBTyxnQkFBZ0IsU0FBUyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUNBLFNBQU87QUFDVDtBQUVBLGVBQWUsT0FBcUMsS0FBUSxPQUF1QztBQUNqRyxRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUM7QUFDbEQ7QUFJQSxlQUFzQixjQUFpQztBQUtyRCxRQUFNLFNBQVMsTUFBTSxPQUFPLFVBQVU7QUFDdEMsUUFBTSxTQUFTLEVBQUUsR0FBRyxrQkFBa0IsR0FBRyxPQUFPO0FBQ2hELE1BQUksT0FBTyxPQUFPLGVBQWUsT0FBTyxHQUFHLEdBQUc7QUFDNUMsUUFBSTtBQUNGLGFBQU8sTUFBTSxNQUFNLFdBQVcsT0FBTyxHQUFHO0FBQUEsSUFDMUMsUUFBUTtBQUNOLGFBQU8sTUFBTTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsWUFBWSxHQUE0QjtBQUc1RCxRQUFNLFVBQW9CLEVBQUUsR0FBRyxFQUFFO0FBQ2pDLE1BQUksUUFBUSxPQUFPLENBQUMsZUFBZSxRQUFRLEdBQUcsR0FBRztBQUMvQyxZQUFRLE1BQU0sTUFBTSxXQUFXLFFBQVEsR0FBRztBQUFBLEVBQzVDO0FBQ0EsUUFBTSxPQUFPLFlBQVksT0FBTztBQUNsQztBQUNBLGVBQXNCLGVBQWUsT0FBNkM7QUFDaEYsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE9BQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hDLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFNBQU87QUFDVDtBQUlBLGVBQXNCLGNBQXdDO0FBQzVELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBYUEsZUFBc0IsZ0JBQTBDO0FBQzlELFFBQU0sSUFBSSxNQUFNLE9BQU8sWUFBWTtBQUVuQyxRQUFNLE1BQXVCO0FBQUEsSUFDM0IsR0FBRztBQUFBLElBQ0gsZUFBZSxFQUFFLGtCQUFrQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3hELHdCQUNFLEVBQUUsMkJBQTJCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDcEQsa0JBQWtCLEVBQUUscUJBQXFCLFNBQVksT0FBTyxFQUFFO0FBQUEsRUFDaEU7QUFDQSxTQUFPO0FBQ1Q7QUFXQSxlQUFzQixjQUF1RDtBQUMzRSxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQTZCQSxlQUFzQixnQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLFlBQVk7QUFDNUI7QUFxQkEsZUFBc0IsY0FBbUM7QUFDdkQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUF1UkEsZUFBc0IsV0FBMEI7QUFDOUMsUUFBTSxRQUFRLFFBQVEsTUFBTSxNQUFNO0FBQ3BDOzs7QUNwZ0JBLElBQU0sSUFBSSxDQUFzQyxPQUFrQjtBQUNoRSxRQUFNLEtBQUssU0FBUyxlQUFlLEVBQUU7QUFDckMsTUFBSSxDQUFDLEdBQUksT0FBTSxJQUFJLE1BQU0sb0JBQW9CLEVBQUUsRUFBRTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxJQUFNLE9BQU8sRUFBbUIsZUFBZTtBQUMvQyxJQUFNLGFBQWEsRUFBb0IsT0FBTztBQUM5QyxJQUFNLFlBQVksRUFBb0IsTUFBTTtBQUM1QyxJQUFNLGNBQWMsRUFBb0IsUUFBUTtBQUNoRCxJQUFNLFdBQVcsRUFBb0IsS0FBSztBQUMxQyxJQUFNLFlBQVksRUFBcUIsWUFBWTtBQUNuRCxJQUFNLGFBQWEsRUFBbUIsYUFBYTtBQUNuRCxJQUFNLGFBQWEsRUFBRSxhQUFhO0FBQ2xDLElBQU0sY0FBYyxFQUFvQixrQkFBa0I7QUFDMUQsSUFBTSxhQUFhLEVBQXFCLGtCQUFrQjtBQUMxRCxJQUFNLFVBQVUsRUFBdUIsYUFBYTtBQUNwRCxJQUFNLGNBQWMsRUFBcUIsa0JBQWtCO0FBQzNELElBQU0sa0JBQWtCLEVBQXFCLGVBQWU7QUFDNUQsSUFBTSxhQUFhLEVBQW1CLGFBQWE7QUFFbkQsZUFBZSxLQUFRLEtBQWlDO0FBQ3RELFNBQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUN4QztBQUVBLFNBQVMsVUFBVSxJQUFpQixNQUFrQyxLQUFtQjtBQUN2RixLQUFHLFlBQVksT0FBTyxVQUFVLElBQUksS0FBSztBQUN6QyxLQUFHLGNBQWM7QUFDbkI7QUFFQSxlQUFlLGVBQThCO0FBQzNDLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsYUFBVyxRQUFRLEVBQUUsU0FBUyxpQkFBaUI7QUFDL0MsWUFBVSxRQUFRLEVBQUUsUUFBUSxpQkFBaUI7QUFDN0MsY0FBWSxRQUFRLEVBQUUsVUFBVSxpQkFBaUI7QUFDakQsTUFBSSxFQUFFLEtBQUs7QUFDVCxhQUFTLFFBQVEsRUFBRTtBQUNuQixhQUFTLGNBQWMsU0FBSSxFQUFFLElBQUksTUFBTSxFQUFFLENBQUM7QUFBQSxFQUM1QztBQUNBLFFBQU0sZ0JBQWdCO0FBQ3hCO0FBRUEsZUFBZSxrQkFBaUM7QUFDOUMsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sUUFBa0IsQ0FBQztBQUN6QixRQUFNLEtBQUssV0FBVyxLQUFLLE1BQU0sRUFBRTtBQUNuQyxNQUFJLEtBQUssTUFBTyxPQUFNLEtBQUssa0JBQWtCLEtBQUssS0FBSyxFQUFFO0FBQ3pELFFBQU0sS0FBSyxlQUFlLEVBQUUsU0FBUyxHQUFHLElBQUksRUFBRSxRQUFRLEdBQUcsSUFBSSxFQUFFLFVBQVUsR0FBRyxFQUFFO0FBQzlFLE1BQUksS0FBSyxVQUFXLE9BQU0sS0FBSyxpQkFBaUIsS0FBSyxTQUFTLEVBQUU7QUFDaEUsTUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsVUFBTSxXQUFXLElBQUksS0FBSyxLQUFLLG1CQUFtQixHQUFJLEVBQUUsWUFBWTtBQUNwRSxVQUFNLFdBQVcsS0FBSyxtQkFBbUIsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDckUsVUFBTSxVQUNKLFlBQVksSUFDUixnQkFDQSxXQUFXLEtBQ1QsTUFBTSxRQUFRLE1BQ2QsV0FBVyxPQUNULE1BQU0sS0FBSyxNQUFNLFdBQVcsRUFBRSxDQUFDLE1BQy9CLE1BQU0sS0FBSyxNQUFNLFdBQVcsSUFBSSxDQUFDO0FBQzNDLFVBQU0sS0FBSyxzQkFBc0IsUUFBUSxLQUFLLE9BQU8sR0FBRztBQUFBLEVBQzFEO0FBQ0EsTUFBSSxLQUFLLE1BQU8sT0FBTSxLQUFLLFVBQVUsS0FBSyxLQUFLLEVBQUU7QUFDakQsYUFBVyxjQUFjLE1BQU0sS0FBSyxJQUFJO0FBQzFDO0FBRUEsZUFBZSxnQkFBK0I7QUFDNUMsUUFBTSxPQUFPLE1BQU0sWUFBWTtBQUMvQixjQUFZLGdCQUFnQjtBQUM1QixhQUFXLEtBQUssTUFBTTtBQUNwQixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsVUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0FBQzVDLFdBQU8sWUFBWTtBQUNuQixXQUFPLGNBQWMsSUFBSSxFQUFFLE1BQU07QUFDakMsVUFBTSxRQUFRLFNBQVMsY0FBYyxNQUFNO0FBQzNDLFVBQU0sWUFBWTtBQUNsQixVQUFNLGNBQWMsRUFBRTtBQUN0QixPQUFHLE9BQU8sUUFBUSxLQUFLO0FBQ3ZCLGdCQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxLQUFLLGlCQUFpQixVQUFVLE9BQU8sTUFBYTtBQUNsRCxJQUFFLGVBQWU7QUFDakIsUUFBTSxNQUFNLFNBQVMsTUFBTSxLQUFLO0FBQ2hDLFFBQU0sUUFBUSxXQUFXLE1BQU0sS0FBSztBQUNwQyxRQUFNLE9BQU8sVUFBVSxNQUFNLEtBQUs7QUFDbEMsUUFBTSxTQUFTLFlBQVksTUFBTSxLQUFLLEtBQUs7QUFDM0MsTUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsTUFBTTtBQUMzQixjQUFVLFlBQVksT0FBTywwQkFBMEI7QUFDdkQ7QUFBQSxFQUNGO0FBQ0EsWUFBVSxZQUFZLElBQUksY0FBUztBQUNuQyxRQUFNLGVBQWUsRUFBRSxLQUFLLE9BQU8sTUFBTSxRQUFRLGNBQWMsS0FBSyxJQUFJLEVBQUUsQ0FBQztBQUMzRSxZQUFVLFlBQVksSUFBSSxpQkFBWTtBQUN0QyxRQUFNLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ3hDLFFBQU0sS0FBSyxFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDdkMsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxNQUFJLEtBQUssV0FBVyxNQUFNO0FBQ3hCLGNBQVUsWUFBWSxNQUFNLGlCQUFpQixLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQUEsRUFDbkUsV0FBVyxLQUFLLFdBQVcsY0FBYztBQUN2QyxjQUFVLFlBQVksT0FBTyxzREFBaUQ7QUFBQSxFQUNoRixXQUFXLEtBQUssV0FBVyxnQkFBZ0I7QUFDekMsY0FBVSxZQUFZLFFBQVEsOERBQXlEO0FBQUEsRUFDekYsV0FBVyxLQUFLLFdBQVcsaUJBQWlCO0FBQzFDLGNBQVUsWUFBWSxPQUFPLDBDQUFxQztBQUFBLEVBQ3BFLE9BQU87QUFDTCxjQUFVLFlBQVksT0FBTyxpQkFBaUIsS0FBSyxNQUFNLEVBQUU7QUFBQSxFQUM3RDtBQUNBLFFBQU0sZ0JBQWdCO0FBQ3RCLFFBQU0sY0FBYztBQUNwQixRQUFNLFlBQVk7QUFDcEIsQ0FBQztBQUVELFVBQVUsaUJBQWlCLFNBQVMsTUFBTTtBQUN4QyxNQUFJLFNBQVMsU0FBUyxZQUFZO0FBQ2hDLGFBQVMsT0FBTztBQUNoQixjQUFVLGNBQWM7QUFBQSxFQUMxQixPQUFPO0FBQ0wsYUFBUyxPQUFPO0FBQ2hCLGNBQVUsY0FBYztBQUFBLEVBQzFCO0FBQ0YsQ0FBQztBQUVELFdBQVcsaUJBQWlCLFNBQVMsWUFBWTtBQUMvQyxhQUFXLFdBQVc7QUFDdEIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDdkMsVUFBTSxjQUFjO0FBQ3BCLGNBQVUsWUFBWSxNQUFNLHFCQUFxQjtBQUFBLEVBQ25ELFNBQVMsS0FBSztBQUNaLGNBQVUsWUFBWSxPQUFPLG1CQUFvQixJQUFjLE9BQU8sRUFBRTtBQUFBLEVBQzFFLFVBQUU7QUFDQSxlQUFXLFdBQVc7QUFBQSxFQUN4QjtBQUNGLENBQUM7QUFFRCxlQUFlLGNBQTZCO0FBQzFDLFFBQU0sQ0FBQyxVQUFVLE1BQU0sVUFBVSxVQUFVLFNBQVMsUUFBUSxJQUFJLE1BQU0sUUFBUSxJQUFJO0FBQUEsSUFDaEYsWUFBWTtBQUFBLElBQ1osY0FBYztBQUFBLElBQ2QsWUFBWTtBQUFBLElBQ1osWUFBWTtBQUFBLElBQ1osY0FBYztBQUFBLElBQ2QsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUNELFFBQU0sa0JBQWtCLE9BQU87QUFBQSxJQUM3QixPQUFPLFFBQVEsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNO0FBQUEsTUFDdEM7QUFBQSxNQUNBO0FBQUEsUUFDRSxRQUFRLEVBQUU7QUFBQSxRQUNWLFlBQVksRUFBRTtBQUFBLFFBQ2QsaUJBQWlCLEVBQUU7QUFBQSxRQUNuQixjQUFjLE9BQU8sS0FBSyxFQUFFLFlBQVksRUFBRTtBQUFBLFFBQzFDLGdCQUFnQixFQUFFLG1CQUFtQjtBQUFBLFFBQ3JDLGdCQUFnQixFQUFFO0FBQUEsUUFDbEIsWUFBWSxFQUFFO0FBQUEsTUFDaEI7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxPQUFPO0FBQUEsSUFDWCxTQUFTLFFBQVEsUUFBUSxZQUFZLEVBQUU7QUFBQSxJQUN2QyxZQUFZLFVBQVU7QUFBQSxJQUN0QixVQUFVO0FBQUEsTUFDUixPQUFPLFNBQVM7QUFBQSxNQUNoQixNQUFNLFNBQVM7QUFBQSxNQUNmLFFBQVEsU0FBUztBQUFBLE1BQ2pCLGFBQWEsU0FBUztBQUFBLE1BQ3RCLGNBQWMsU0FBUztBQUFBLE1BQ3ZCLFFBQVEsU0FBUyxJQUFJLFNBQVM7QUFBQSxNQUM5QixXQUFXLFNBQVMsSUFBSSxVQUFVLElBQUksU0FBUyxJQUFJLE1BQU0sRUFBRSxJQUFJO0FBQUEsSUFDakU7QUFBQSxJQUNBLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWTtBQUFBLElBQ1osb0JBQW9CLFNBQVM7QUFBQSxJQUM3QixpQkFBaUIsU0FBUyxNQUFNLEdBQUcsRUFBRTtBQUFBLEVBQ3ZDO0FBQ0EsVUFBUSxRQUFRLEtBQUssVUFBVSxNQUFNLE1BQU0sQ0FBQztBQUM5QztBQUVBLFlBQVksaUJBQWlCLFNBQVMsWUFBWTtBQUNoRCxRQUFNLFVBQVUsVUFBVSxVQUFVLFFBQVEsS0FBSztBQUNqRCxZQUFVLFlBQVksTUFBTSxrQ0FBa0M7QUFDaEUsQ0FBQztBQUVELGdCQUFnQixpQkFBaUIsU0FBUyxZQUFZO0FBQ3BELFFBQU0sS0FBSyxPQUFPO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLEdBQUk7QUFDVCxRQUFNLFNBQVM7QUFDZixZQUFVLFlBQVksUUFBUSxrQkFBa0I7QUFDaEQsUUFBTSxhQUFhO0FBQ25CLFFBQU0sY0FBYztBQUNwQixRQUFNLFlBQVk7QUFDcEIsQ0FBQztBQUVELEtBQUssYUFBYTtBQUNsQixLQUFLLGNBQWM7QUFDbkIsS0FBSyxZQUFZOyIsCiAgIm5hbWVzIjogW10KfQo=
