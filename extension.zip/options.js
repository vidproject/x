// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function getCounters() {
  return getRaw("counters");
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getActivity() {
  return getRaw("activity");
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/options.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var form = $("settings-form");
var ownerInput = $("owner");
var repoInput = $("repo");
var branchInput = $("branch");
var patInput = $("pat");
var revealBtn = $("reveal-pat");
var saveStatus = $("save-status");
var connDetail = $("conn-detail");
var accountList = $("account-readonly");
var refreshBtn = $("refresh-accounts");
var diagBox = $("diagnostics");
var copyDiagBtn = $("copy-diagnostics");
var clearStorageBtn = $("clear-storage");
var diagStatus = $("diag-status");
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setStatus(el, kind, msg) {
  el.className = kind ? `status ${kind}` : "status";
  el.textContent = msg;
}
async function loadSettings() {
  const s = await getSettings();
  ownerInput.value = s.owner || DEFAULT_SETTINGS.owner;
  repoInput.value = s.repo || DEFAULT_SETTINGS.repo;
  branchInput.value = s.branch || DEFAULT_SETTINGS.branch;
  if (s.pat) {
    patInput.value = s.pat;
    patInput.placeholder = `\u2026${s.pat.slice(-4)}`;
  }
  await paintConnDetail();
}
async function paintConnDetail() {
  const conn = await getConnection();
  const s = await getSettings();
  const lines = [];
  lines.push(`Status: ${conn.status}`);
  if (conn.login) lines.push(`Logged in as: @${conn.login}`);
  lines.push(`Repository: ${s.owner || "?"}/${s.repo || "?"}@${s.branch || "?"}`);
  if (conn.checkedAt) lines.push(`Last checked: ${conn.checkedAt}`);
  if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
    const resetIso = new Date(conn.rateLimitResetAt * 1e3).toISOString();
    const deltaSec = conn.rateLimitResetAt - Math.floor(Date.now() / 1e3);
    const inLabel = deltaSec <= 0 ? "momentarily" : deltaSec < 60 ? `in ${deltaSec}s` : deltaSec < 3600 ? `in ${Math.round(deltaSec / 60)}m` : `in ${Math.round(deltaSec / 3600)}h`;
    lines.push(`Rate limit resets: ${resetIso} (${inLabel})`);
  }
  if (conn.error) lines.push(`Error: ${conn.error}`);
  connDetail.textContent = lines.join("\n");
}
async function paintAccounts() {
  const list = await getAccounts();
  accountList.replaceChildren();
  for (const a of list) {
    const li = document.createElement("li");
    const handle = document.createElement("span");
    handle.className = "handle";
    handle.textContent = `@${a.handle}`;
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = a.label;
    li.append(handle, label);
    accountList.append(li);
  }
}
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const pat = patInput.value.trim();
  const owner = ownerInput.value.trim();
  const repo = repoInput.value.trim();
  const branch = branchInput.value.trim() || "main";
  if (!pat || !owner || !repo) {
    setStatus(saveStatus, "err", "All fields are required.");
    return;
  }
  setStatus(saveStatus, "", "Saving\u2026");
  await updateSettings({ pat, owner, repo, branch, configuredAt: Date.now() });
  setStatus(saveStatus, "", "Verifying\u2026");
  await send({ type: "verify-connection" });
  await send({ type: "refresh-accounts" });
  const conn = await getConnection();
  if (conn.status === "ok") {
    setStatus(saveStatus, "ok", `Connected as @${conn.login ?? "?"}.`);
  } else if (conn.status === "auth-error") {
    setStatus(saveStatus, "err", "Auth failed \u2014 check the PAT and its repo scope.");
  } else if (conn.status === "rate-limited") {
    setStatus(saveStatus, "warn", "Rate-limited \u2014 token is valid but GitHub is throttling.");
  } else if (conn.status === "network-error") {
    setStatus(saveStatus, "err", "Network error \u2014 check connectivity.");
  } else {
    setStatus(saveStatus, "err", `Verification: ${conn.status}`);
  }
  await paintConnDetail();
  await paintAccounts();
  await refreshDiag();
});
revealBtn.addEventListener("click", () => {
  if (patInput.type === "password") {
    patInput.type = "text";
    revealBtn.textContent = "Hide";
  } else {
    patInput.type = "password";
    revealBtn.textContent = "Show";
  }
});
refreshBtn.addEventListener("click", async () => {
  refreshBtn.disabled = true;
  try {
    await send({ type: "refresh-accounts" });
    await paintAccounts();
    setStatus(diagStatus, "ok", "Accounts refreshed.");
  } catch (err) {
    setStatus(diagStatus, "err", `Refresh failed: ${err.message}`);
  } finally {
    refreshBtn.disabled = false;
  }
});
async function refreshDiag() {
  const [settings, conn, accounts, counters, buffers, activity] = await Promise.all([
    getSettings(),
    getConnection(),
    getAccounts(),
    getCounters(),
    getRunBuffers(),
    getActivity()
  ]);
  const redactedBuffers = Object.fromEntries(
    Object.entries(buffers).map(([k, b]) => [
      k,
      {
        run_id: b.run_id,
        started_at: b.started_at,
        last_capture_at: b.last_capture_at,
        tweets_count: Object.keys(b.tweets_by_id).length,
        observed_count: b.tweet_ids_observed.length,
        endpoints_seen: b.endpoints_seen,
        source_url: b.source_url
      }
    ])
  );
  const dump = {
    version: browser.runtime.getManifest().version,
    user_agent: navigator.userAgent,
    settings: {
      owner: settings.owner,
      repo: settings.repo,
      branch: settings.branch,
      autoCapture: settings.autoCapture,
      configuredAt: settings.configuredAt,
      patSet: settings.pat.length > 0,
      patSuffix: settings.pat.length >= 4 ? settings.pat.slice(-4) : ""
    },
    connection: conn,
    accounts,
    counters,
    runBuffers: redactedBuffers,
    activity_tail_size: activity.length,
    activity_recent: activity.slice(0, 30)
  };
  diagBox.value = JSON.stringify(dump, null, 2);
}
copyDiagBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(diagBox.value);
  setStatus(diagStatus, "ok", "Copied diagnostics to clipboard.");
});
clearStorageBtn.addEventListener("click", async () => {
  const ok = window.confirm(
    "Clear extension storage? This erases your PAT, settings, counters, buffered captures, and activity tail. There is no undo."
  );
  if (!ok) return;
  await clearAll();
  setStatus(diagStatus, "warn", "Storage cleared.");
  await loadSettings();
  await paintAccounts();
  await refreshDiag();
});
void loadSettings();
void paintAccounts();
void refreshDiag();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9vcHRpb25zLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgdHlwZSB7IEFjY291bnRDb25maWcsIFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XHJcbiAgcGF0OiAnJyxcclxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxyXG4gIHJlcG86ICd4JyxcclxuICAvLyBUaGUgcmVwbydzIGN1cnJlbnQgZGVmYXVsdCBicmFuY2ggaXMgXCJtYXN0ZXJcIi4gSWYgeW91IGZvcmsgb3IgcmVuYW1lXHJcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cclxuICBicmFuY2g6ICdtYXN0ZXInLFxyXG4gIGVuYWJsZWQ6IHRydWUsXHJcbiAgYXV0b0NhcHR1cmU6IHRydWUsXHJcbiAgY29uZmlndXJlZEF0OiBudWxsLFxyXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcclxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01BWF9TRUMgPSA2MDtcclxuXHJcbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXHJcbi8vIHJlcG8gaGFzIGJlZW4gaW5pdGlhbGl6ZWQgb3IgUEFUIG1pc2NvbmZpZ3VyZWQpLiBLZXB0IGluIHN5bmMgd2l0aCB0aGUgZmlsZS5cclxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXHJcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdJQ0Vnb3YnLCBsYWJlbDogJ1UuUy4gSW1taWdyYXRpb24gYW5kIEN1c3RvbXMgRW5mb3JjZW1lbnQnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdXaGl0ZUhvdXNlJywgbGFiZWw6ICdUaGUgV2hpdGUgSG91c2UnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1VTRE9MJywgbGFiZWw6ICdVLlMuIERlcGFydG1lbnQgb2YgTGFib3InLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG5dO1xyXG5cclxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cclxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdVc2VyVHdlZXRzJyxcclxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxyXG4gICdVc2VyTWVkaWEnLFxyXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXHJcbiAgJ1R3ZWV0RGV0YWlsJyxcclxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXHJcbiAgJ0xpa2VzJyxcclxuICAnQm9va21hcmtzJyxcclxuICAnSG9tZVRpbWVsaW5lJyxcclxuICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcclxuICAnU2VhcmNoVGltZWxpbmUnLFxyXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxyXG5dKTtcclxuXHJcbi8vIEVuZHBvaW50cyB0aGF0IGNhcnJ5IENvbW11bml0eSBOb3RlIGJvZGllcyBcdTIwMTQgY2FwdHVyZWQgZm9yIGNvbXBsZXRlbmVzcyBidXRcclxuLy8gdGhleSBkb24ndCBpbnRyb2R1Y2UgbmV3IHR3ZWV0cywgc28gdGhleSBkb24ndCBuZWVkIHRvIGJlIGluIFRXRUVUX0VORFBPSU5UUy5cclxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnQmlyZHdhdGNoRmV0Y2hPbmVOb3RlJyxcclxuICAnQmlyZHdhdGNoRmV0Y2hOb3RlcycsXHJcbl0pO1xyXG5cclxuLy8gQXV4aWxpYXJ5IGVuZHBvaW50cyB3ZSBkb24ndCBleHRyYWN0IHR3ZWV0cyBmcm9tIGJ1dCB1c2UgZm9yIGNvbnRleHQgKGUuZy4sXHJcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXHJcbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcclxuXHJcbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxyXG4vLyBjb252ZXJzYXRpb24gXHUyMDE0IGkuZS4gdmlzaXRpbmcgYC88aGFuZGxlPmAgLyBgLzxoYW5kbGU+L3dpdGhfcmVwbGllc2AsXHJcbi8vIGxvb2tpbmcgYXQgb25lIHR3ZWV0LCBldGMuIEV2ZXJ5IHR3ZWV0IHJldHVybmVkIGJ5IHRoZXNlIGVuZHBvaW50cyBpc1xyXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cclxuLy8gKHJldHdlZXRlZCwgcXVvdGVkLCByZXBsaWVkIHRvKSwgc28gd2Uga2VlcCBldmVyeXRoaW5nIHdlIHNlZSByYXRoZXJcclxuLy8gdGhhbiBkcm9wcGluZyBub24tdHJhY2tlZCBhdXRob3JzLiBUaGF0IHdheSBhIHJldHdlZXQgb2YgYSBub24tdHJhY2tlZFxyXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXHJcbi8vXHJcbi8vIEVuZHBvaW50cyBOT1QgaW4gdGhpcyBzZXQgKEhvbWVUaW1lbGluZSwgU2VhcmNoVGltZWxpbmUsIExpa2VzLCBldGMuKVxyXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3NcclxuLy8gXCJCcm93c2luZyBteSBob21lIHRpbWVsaW5lIGlzIGlnbm9yZWRcIiBydWxlLlxyXG5leHBvcnQgY29uc3QgVVNFUl9QQUdFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdVc2VyVHdlZXRzJyxcclxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxyXG4gICdVc2VyTWVkaWEnLFxyXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXHJcbiAgJ1R3ZWV0RGV0YWlsJyxcclxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXHJcbl0pO1xyXG5cclxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XHJcblxyXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xyXG5cclxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcclxuXHJcbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cclxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xyXG5cclxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxyXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcclxuXHJcbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xyXG4iLCAiLyoqXHJcbiAqIGNyeXB0by50cyBcdTIwMTQgYXQtcmVzdCBlbmNyeXB0aW9uIGZvciBzZW5zaXRpdmUgc2V0dGluZ3MgKHRoZSBQQVQpLlxyXG4gKlxyXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcclxuICogZm9yZ290dGVuIGJhY2t1cCwgYSBtaXNjb25maWd1cmVkIHByb2ZpbGUgc3luYykgc2hvdWxkIG5vdCBzZWUgYSB1c2FibGVcclxuICogR2l0SHViIFBBVCBpbiBwbGFpbnRleHQuIEEgZGV0ZXJtaW5lZCBhdHRhY2tlciB3aXRoIHRoZSBleHRlbnNpb24ncyBzb3VyY2VcclxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcclxuICogY29uZmlkZW50aWFsaXR5LiBUaGUgYWltIGlzIHRvIHJhaXNlIHRoZSBiYXIgc28gdGhlIFBBVCBpc24ndCBhIGNvcHlhYmxlXHJcbiAqIHN0cmluZyBzaXR0aW5nIG5leHQgdG8gaXRzIGtleSBuYW1lIGluIGV4dGVuc2lvbiBzdG9yYWdlLlxyXG4gKlxyXG4gKiBTY2hlbWU6XHJcbiAqICAgLSBPbiBmaXJzdCBlbmNyeXB0aW9uIHdlIGdlbmVyYXRlIGEgMzItYnl0ZSBzYWx0IGFuZCBwZXJzaXN0IGl0IGluXHJcbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxyXG4gKiAgIC0gV2UgZGVyaXZlIGFuIEFFUy1HQ00ga2V5IGJ5IFNIQS0yNTYnaW5nIGBzYWx0IHx8IHJ1bnRpbWUuaWQgfHwgdmVyc2lvblxyXG4gKiAgICAgfHwgXCJpbW0tYXJjaGl2ZS1wYXQtdjFcImAuIFRoZSBzYWx0IGJlaW5nIHBlci1pbnN0YWxsIG1lYW5zIHR3byBjb3BpZXNcclxuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xyXG4gKiAgICAgVVVJRCBcdTIwMTQgc3RhYmxlIGZvciBhIGdpdmVuIGluc3RhbGwgYnV0IHVua25vd24gdG8gYSByZW1vdGUgYXR0YWNrZXIuXHJcbiAqICAgLSBQbGFpbnRleHQgaXMgZW5jcnlwdGVkIHdpdGggYSBmcmVzaCAxMi1ieXRlIElWLiBUaGUgZW52ZWxvcGUgZm9ybWF0IGlzXHJcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXHJcbiAqXHJcbiAqIEJhY2t3YXJkcyBjb21wYXRpYmlsaXR5OiBhbiB1bnByZWZpeGVkIHZhbHVlIGlzIHRyZWF0ZWQgYXMgbGVnYWN5XHJcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cclxuICovXHJcblxyXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcclxuY29uc3QgRU5WRUxPUEVfUFJFRklYID0gJ3YxOic7XHJcblxyXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcclxubGV0IGRlcml2ZWRLZXlDYWNoZVNhbHQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xyXG5cclxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcclxuICBsZXQgcyA9ICcnO1xyXG4gIGZvciAoY29uc3QgYiBvZiBidWYpIHMgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShiKTtcclxuICByZXR1cm4gYnRvYShzKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcclxuICBjb25zdCBiaW4gPSBhdG9iKHMpO1xyXG4gIGNvbnN0IG91dCA9IG5ldyBVaW50OEFycmF5KGJpbi5sZW5ndGgpO1xyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBsb2FkT3JDcmVhdGVTYWx0KCk6IFByb21pc2U8eyBzYWx0QjY0OiBzdHJpbmc7IHNhbHQ6IFVpbnQ4QXJyYXkgfT4ge1xyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoU0FMVF9TVE9SQUdFX0tFWSk7XHJcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcclxuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xyXG4gICAgcmV0dXJuIHsgc2FsdEI2NDogdiwgc2FsdDogZnJvbUJhc2U2NCh2KSB9O1xyXG4gIH1cclxuICBjb25zdCBzYWx0ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgzMikpO1xyXG4gIGNvbnN0IHNhbHRCNjQgPSB0b0Jhc2U2NChzYWx0KTtcclxuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xyXG4gIHJldHVybiB7IHNhbHRCNjQsIHNhbHQgfTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZGVyaXZlS2V5KCk6IFByb21pc2U8Q3J5cHRvS2V5PiB7XHJcbiAgY29uc3QgeyBzYWx0QjY0LCBzYWx0IH0gPSBhd2FpdCBsb2FkT3JDcmVhdGVTYWx0KCk7XHJcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XHJcbiAgICByZXR1cm4gZGVyaXZlZEtleUNhY2hlO1xyXG4gIH1cclxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxyXG4gICAgYCR7YnJvd3Nlci5ydW50aW1lLmlkfXwke2Jyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb259fGltbS1hcmNoaXZlLXBhdC12MWBcclxuICApO1xyXG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XHJcbiAgY29tYmluZWQuc2V0KHNlZWQsIDApO1xyXG4gIGNvbWJpbmVkLnNldChzYWx0LCBzZWVkLmxlbmd0aCk7XHJcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xyXG4gIGNvbnN0IGtleSA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuaW1wb3J0S2V5KCdyYXcnLCBoYXNoLCB7IG5hbWU6ICdBRVMtR0NNJyB9LCBmYWxzZSwgW1xyXG4gICAgJ2VuY3J5cHQnLFxyXG4gICAgJ2RlY3J5cHQnLFxyXG4gIF0pO1xyXG4gIGRlcml2ZWRLZXlDYWNoZSA9IGtleTtcclxuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcclxuICByZXR1cm4ga2V5O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaXNFbmNyeXB0ZWRQYXQodjogc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgcmV0dXJuIHYuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5jcnlwdFBhdChwbGFpbnRleHQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcclxuICBjb25zdCBrZXkgPSBhd2FpdCBkZXJpdmVLZXkoKTtcclxuICBjb25zdCBpdiA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTIpKTtcclxuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcclxuICAgIHsgbmFtZTogJ0FFUy1HQ00nLCBpdiB9LFxyXG4gICAga2V5LFxyXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcclxuICApO1xyXG4gIHJldHVybiBgJHtFTlZFTE9QRV9QUkVGSVh9JHt0b0Jhc2U2NChpdil9OiR7dG9CYXNlNjQobmV3IFVpbnQ4QXJyYXkoY3QpKX1gO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVjcnlwdFBhdChlbnZlbG9wZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XHJcbiAgLy8gTGVnYWN5IHBsYWludGV4dCAocHJlLWVuY3J5cHRpb24gaW5zdGFsbHMpOiBwYXNzIHRocm91Z2guIFRoZSBuZXh0IHNhdmVcclxuICAvLyByZS1lbmNyeXB0cyBpdCB2aWEgdGhlIHN0b3JhZ2UgbGF5ZXIuXHJcbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcclxuICBjb25zdCBwYXJ0cyA9IGVudmVsb3BlLnNsaWNlKEVOVkVMT1BFX1BSRUZJWC5sZW5ndGgpLnNwbGl0KCc6Jyk7XHJcbiAgaWYgKHBhcnRzLmxlbmd0aCAhPT0gMikgcmV0dXJuICcnO1xyXG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XHJcbiAgaWYgKCFpdkI2NCB8fCAhY3RCNjQpIHJldHVybiAnJztcclxuICB0cnkge1xyXG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XHJcbiAgICBjb25zdCBpdiA9IGZyb21CYXNlNjQoaXZCNjQpO1xyXG4gICAgY29uc3QgY3QgPSBmcm9tQmFzZTY0KGN0QjY0KTtcclxuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxyXG4gICAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXY6IGl2IGFzIEJ1ZmZlclNvdXJjZSB9LFxyXG4gICAgICBrZXksXHJcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxyXG4gICAgKTtcclxuICAgIHJldHVybiBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUocHQpO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuICcnO1xyXG4gIH1cclxufVxyXG4iLCAiaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUywgRkFMTEJBQ0tfQUNDT1VOVFMsIEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9jb25maWcuanMnO1xyXG5pbXBvcnQgeyBkZWNyeXB0UGF0LCBlbmNyeXB0UGF0LCBpc0VuY3J5cHRlZFBhdCB9IGZyb20gJy4vY3J5cHRvLmpzJztcclxuaW1wb3J0IHR5cGUge1xyXG4gIEFjY291bnRDb25maWcsXHJcbiAgQWNjb3VudENvdW50ZXIsXHJcbiAgQ2Fub25pY2FsVHdlZXQsXHJcbiAgQ29ubmVjdGlvblN0YXRlLFxyXG4gIExvZ0V2ZW50LFxyXG4gIFNldHRpbmdzLFxyXG59IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuLyoqXHJcbiAqIEJ1ZmZlcmVkIHR3ZWV0cyBmb3IgYSBnaXZlbiBhY2NvdW50LCBhd2FpdGluZyBjb21taXQuIEEgXCJydW5cIiBpcyBvbmUgZW50cnlcclxuICogaW4gdGhpcyBtYXA7IGZsdXNoaW5nIGNsZWFycyB0aGUgZW50cnkuIFdlIHN0b3JlIGFzIFJlY29yZCBzbyB0aGUgc3RydWN0dXJlXHJcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgUnVuQnVmZmVyIHtcclxuICBydW5faWQ6IHN0cmluZztcclxuICBhY2NvdW50X2hhbmRsZTogc3RyaW5nO1xyXG4gIHN0YXJ0ZWRfYXQ6IHN0cmluZztcclxuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcclxuICB0d2VldHNfYnlfaWQ6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PjtcclxuICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IHN0cmluZ1tdO1xyXG4gIGVuZHBvaW50c19zZWVuOiBzdHJpbmdbXTtcclxuICBzb3VyY2VfdXJsOiBzdHJpbmcgfCBudWxsO1xyXG59XHJcblxyXG4vKiogUGVyLXR3ZWV0IGNvbW1pdHRlZC1zdGF0ZSBpbmRleCwga2V5ZWQgYnkgaGFuZGxlIHRoZW4gdHdlZXRfaWQuXHJcbiAqIFVzZWQgdG8gc2tpcCByZS1jYXB0dXJpbmcgdHdlZXRzIHdlJ3ZlIGFscmVhZHkgcHVzaGVkIHdpdGggaWRlbnRpY2FsXHJcbiAqIGVuZ2FnZW1lbnQgY291bnRzIFx1MjAxNCBhdm9pZHMgZ2VuZXJhdGluZyBvbmUgbmV3IHJhdy8qIGZpbGUgZXZlcnkgYnJvd3NlLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdHRlZEVudHJ5IHtcclxuICB0czogc3RyaW5nOyAvLyBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IGNvbW1pdFxyXG4gIHNpZzogc3RyaW5nOyAvLyBlbmdhZ2VtZW50IHNpZ25hdHVyZTogXCJsaWtlfHJ0fHJlcGx5fHF1b3RlXCJcclxufVxyXG5cclxuLyoqIFByb2dyZXNzICsgaW5mbGlnaHQgdHJhY2tpbmcgZm9yIGEgcXVldWUtZHJpdmVuIGxvb3AgKHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCkuXHJcbiAqIFRoZSBsb29wIHBlcnNpc3RzIHRoaXMgc28gYSBTVyBldmljdGlvbiBpbiB0aGUgbWlkZGxlIG9mIGEgcnVuIHByZXNlcnZlc1xyXG4gKiBcIlggb2YgWSBwcm9jZXNzZWRcIiBcdTIwMTQgYW5kIHRoZSB3YWl0LWZvci1pbmdlc3QgZ3VhcmQga25vd3Mgd2hhdCB0byBleHBlY3QuXHJcbiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIExvb3BTZXNzaW9uIHtcclxuICAvKiogSW5pdGlhbCBxdWV1ZSBzaXplIHdoZW4gdGhlIHVzZXIgY2xpY2tlZCBcIlN0YXJ0XCIuICovXHJcbiAgdG90YWxBdFN0YXJ0OiBudW1iZXI7XHJcbiAgLyoqIFR3ZWV0cyBwcm9jZXNzZWQgKGluZ2VzdGVkIE9SIGRyb3BwZWQgYWZ0ZXIgcmV0cmllcykgc28gZmFyLiAqL1xyXG4gIHByb2Nlc3NlZDogbnVtYmVyO1xyXG4gIC8qKiBJU08gb2Ygd2hlbiB0aGlzIHNlc3Npb24gc3RhcnRlZC4gKi9cclxuICBzdGFydGVkQXQ6IHN0cmluZztcclxuICAvKiogVHdlZXQgY3VycmVudGx5IGluZmxpZ2h0IFx1MjAxNCB3ZSBuYXZpZ2F0ZWQgdG8gaXQgYW5kIGFyZSB3YWl0aW5nIGZvciB0aGVcclxuICAgKiBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgcmVzcG9uc2UgYmVmb3JlIGFkdmFuY2luZy4gbnVsbCBiZXR3ZWVuIHRpY2tzXHJcbiAgICogKGFuZCBvbmNlIGFuIGluZ2VzdCBoYXMgYmVlbiBvYnNlcnZlZCkuICovXHJcbiAgaW5mbGlnaHQ6IHsgdHdlZXRJZDogc3RyaW5nOyBuYXZpZ2F0ZWRBdDogc3RyaW5nIH0gfCBudWxsO1xyXG59XHJcblxyXG4vKiogQXV0by1zY3JvbGwgc2Vzc2lvbjogY291bnRzIG9mIHRpY2tzIGFuZCB0d2VldHMgaW5nZXN0ZWQgc2luY2UgdGhlIHVzZXJcclxuICogY2xpY2tlZCBTdGFydC4gUGVyc2lzdGVkIHNvIFNXIGV2aWN0aW9uIGR1cmluZyBhIHJ1biBrZWVwcyBwcm9ncmVzcy4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBBdXRvU2Nyb2xsU2Vzc2lvbiB7XHJcbiAgc3RhcnRlZEF0OiBzdHJpbmc7XHJcbiAgc2Nyb2xsQ291bnQ6IG51bWJlcjtcclxuICBpbmdlc3RlZENvdW50OiBudW1iZXI7XHJcbiAgZXhwYW5kZWRDb3VudDogbnVtYmVyO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgU3RvcmFnZVNoYXBlIHtcclxuICBzZXR0aW5nczogU2V0dGluZ3M7XHJcbiAgYWNjb3VudHM6IEFjY291bnRDb25maWdbXTtcclxuICAvKiogSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBzdWNjZXNzZnVsIGFjY291bnRzLnlhbWwgZmV0Y2ggZnJvbSB0aGUgcmVwby5cclxuICAgKiBVc2VkIGJ5IGByZWZyZXNoQWNjb3VudHNMaXN0YCB0byBza2lwIHJlLWZldGNoaW5nIG9uIGV2ZXJ5IFNXIHdha2UgXHUyMDE0IHRoZVxyXG4gICAqIGZpbGUgY2hhbmdlcyByYXJlbHkgYW5kIGFuIGF1dGhlbnRpY2F0ZWQgcmF3IGZldGNoIGV2ZXJ5IHdha2UgYWRkcyB1cC4gKi9cclxuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBzdHJpbmcgfCBudWxsO1xyXG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcclxuICBjb3VudGVyczogUmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+O1xyXG4gIHJ1bkJ1ZmZlcnM6IFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj47XHJcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XHJcbiAgY29tbWl0dGVkSW5kZXg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj47XHJcbiAgLyoqIFR3ZWV0cyB0aGUgbm9ybWFsaXplciBmbGFnZ2VkIGFzIHRydW5jYXRlZCBhbmQgdGhhdCB3ZSBoYXZlbid0IHNlZW4gYVxyXG4gICAqIGZ1bGwtdGV4dCB2ZXJzaW9uIG9mIHlldC4gS2V5ZWQgYnkgaGFuZGxlIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuICovXHJcbiAgcmVmZXRjaFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XHJcbiAgLyoqIFR3ZWV0IElEcyBzZWVuIHZpYSBNZWRpYS10YWIgLyBwYXJ0aWFsIGNhcHR1cmVzIHRoYXQgY291bGRuJ3QgYmVcclxuICAgKiBub3JtYWxpemVkIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gS2V5ZWQgYnkgaGludC1oYW5kbGUgKG9yXHJcbiAgICogXCJfdW5rbm93blwiKSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiBUaGUgdXNlciBjYW4gZHJpdmUgYSBjcmF3bCB0aGF0XHJcbiAgICogb3BlbnMgZWFjaCBkZXRhaWwgcGFnZSB0byBjYXB0dXJlIHRoZSByZWFsIHRoaW5nLiAqL1xyXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xyXG4gIHJlZmV0Y2hTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XHJcbiAgbWVkaWFDcmF3bFNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcclxuICBhdXRvU2Nyb2xsU2Vzc2lvbjogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsO1xyXG59XHJcblxyXG5jb25zdCBERUZBVUxUX0NPTk5FQ1RJT046IENvbm5lY3Rpb25TdGF0ZSA9IHtcclxuICBzdGF0dXM6ICd1bmtub3duJyxcclxuICBsb2dpbjogbnVsbCxcclxuICBjaGVja2VkQXQ6IG51bGwsXHJcbiAgZXJyb3I6IG51bGwsXHJcbiAgZGVmYXVsdEJyYW5jaDogbnVsbCxcclxuICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxyXG4gIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXHJcbn07XHJcblxyXG5jb25zdCBERUZBVUxUUzogU3RvcmFnZVNoYXBlID0ge1xyXG4gIHNldHRpbmdzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MgfSxcclxuICBhY2NvdW50czogWy4uLkZBTExCQUNLX0FDQ09VTlRTXSxcclxuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBudWxsLFxyXG4gIGNvbm5lY3Rpb246IHsgLi4uREVGQVVMVF9DT05ORUNUSU9OIH0sXHJcbiAgY291bnRlcnM6IHt9LFxyXG4gIHJ1bkJ1ZmZlcnM6IHt9LFxyXG4gIGFjdGl2aXR5OiBbXSxcclxuICBjb21taXR0ZWRJbmRleDoge30sXHJcbiAgcmVmZXRjaFF1ZXVlOiB7fSxcclxuICBtZWRpYUNyYXdsUXVldWU6IHt9LFxyXG4gIHJlZmV0Y2hTZXNzaW9uOiBudWxsLFxyXG4gIG1lZGlhQ3Jhd2xTZXNzaW9uOiBudWxsLFxyXG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBudWxsLFxyXG59O1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSyk6IFByb21pc2U8U3RvcmFnZVNoYXBlW0tdPiB7XHJcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChrZXkpO1xyXG4gIGNvbnN0IHZhbHVlID0gcmVzdWx0W2tleV07XHJcbiAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcclxuICAgIHJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUoREVGQVVMVFNba2V5XSk7XHJcbiAgfVxyXG4gIHJldHVybiB2YWx1ZSBhcyBTdG9yYWdlU2hhcGVbS107XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEssIHZhbHVlOiBTdG9yYWdlU2hhcGVbS10pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW2tleV06IHZhbHVlIH0pO1xyXG59XHJcblxyXG4vLyAtLS0gU2V0dGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNldHRpbmdzKCk6IFByb21pc2U8U2V0dGluZ3M+IHtcclxuICAvLyBCYWNrZmlsbCBhbnkga2V5cyB0aGUgdXNlcidzIHN0b3JlZCBzZXR0aW5ncyBwcmVkYXRlIFx1MjAxNCByZWFkZXJzIGNhbiByZWx5XHJcbiAgLy8gb24gZXZlcnkgU2V0dGluZ3MgZmllbGQgYmVpbmcgcHJlc2VudCByYXRoZXIgdGhhbiBgPz8gZGVmYXVsdGluZ2AgYXRcclxuICAvLyBldmVyeSBjYWxsc2l0ZS4gVGhlIFBBVCBpcyBzdG9yZWQgZW5jcnlwdGVkLWF0LXJlc3QgYXMgb2YgdjAuMi4wOyB3ZVxyXG4gIC8vIGRlY3J5cHQgdHJhbnNwYXJlbnRseSBzbyBjYWxsZXJzIGNvbnRpbnVlIHRvIHNlZSBwbGFpbnRleHQuXHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgZ2V0UmF3KCdzZXR0aW5ncycpO1xyXG4gIGNvbnN0IG1lcmdlZCA9IHsgLi4uREVGQVVMVF9TRVRUSU5HUywgLi4uc3RvcmVkIH07XHJcbiAgaWYgKG1lcmdlZC5wYXQgJiYgaXNFbmNyeXB0ZWRQYXQobWVyZ2VkLnBhdCkpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIG1lcmdlZC5wYXQgPSBhd2FpdCBkZWNyeXB0UGF0KG1lcmdlZC5wYXQpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIG1lcmdlZC5wYXQgPSAnJztcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG1lcmdlZDtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAvLyBFbmNyeXB0IHRoZSBQQVQgYmVmb3JlIHBlcnNpc3Rpbmc7IGxlZ2FjeSBwbGFpbnRleHQgUEFUcyBnZXQgdXBncmFkZWRcclxuICAvLyBvbiB0aGUgbmV4dCBzYXZlLlxyXG4gIGNvbnN0IHRvV3JpdGU6IFNldHRpbmdzID0geyAuLi5zIH07XHJcbiAgaWYgKHRvV3JpdGUucGF0ICYmICFpc0VuY3J5cHRlZFBhdCh0b1dyaXRlLnBhdCkpIHtcclxuICAgIHRvV3JpdGUucGF0ID0gYXdhaXQgZW5jcnlwdFBhdCh0b1dyaXRlLnBhdCk7XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygnc2V0dGluZ3MnLCB0b1dyaXRlKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2V0dGluZ3MocGF0Y2g6IFBhcnRpYWw8U2V0dGluZ3M+KTogUHJvbWlzZTxTZXR0aW5ncz4ge1xyXG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgY29uc3QgbmV4dCA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xyXG4gIGF3YWl0IHNldFNldHRpbmdzKG5leHQpO1xyXG4gIHJldHVybiBuZXh0O1xyXG59XHJcblxyXG4vLyAtLS0gQWNjb3VudHMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzKCk6IFByb21pc2U8QWNjb3VudENvbmZpZ1tdPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHMnKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHMoYTogQWNjb3VudENvbmZpZ1tdKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50cycsIGEpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50c1JlZnJlc2hlZEF0KCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzUmVmcmVzaGVkQXQnKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHNSZWZyZXNoZWRBdChpc286IHN0cmluZyB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzUmVmcmVzaGVkQXQnLCBpc28pO1xyXG59XHJcblxyXG4vLyAtLS0gQ29ubmVjdGlvbiBzdGF0ZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29ubmVjdGlvbigpOiBQcm9taXNlPENvbm5lY3Rpb25TdGF0ZT4ge1xyXG4gIGNvbnN0IGMgPSBhd2FpdCBnZXRSYXcoJ2Nvbm5lY3Rpb24nKTtcclxuICAvLyBCYWNrZmlsbCBmaWVsZHMgYWRkZWQgYWZ0ZXIgdGhlIHVzZXIncyBzdG9yYWdlIHdhcyB3cml0dGVuLlxyXG4gIGNvbnN0IG91dDogQ29ubmVjdGlvblN0YXRlID0ge1xyXG4gICAgLi4uYyxcclxuICAgIGRlZmF1bHRCcmFuY2g6IGMuZGVmYXVsdEJyYW5jaCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuZGVmYXVsdEJyYW5jaCxcclxuICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6XHJcbiAgICAgIGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcclxuICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGMucmF0ZUxpbWl0UmVzZXRBdCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMucmF0ZUxpbWl0UmVzZXRBdCxcclxuICB9O1xyXG4gIHJldHVybiBvdXQ7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdjb25uZWN0aW9uJywgYyk7XHJcbn1cclxuXHJcbi8vIC0tLSBDb3VudGVycyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xyXG4gIHJldHVybiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q291bnRlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBBY2NvdW50Q291bnRlcj4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdjb3VudGVycycpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBidW1wQ291bnRlcihcclxuICBoYW5kbGU6IHN0cmluZyxcclxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cclxuKTogUHJvbWlzZTxBY2NvdW50Q291bnRlcj4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldENvdW50ZXJzKCk7XHJcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xyXG4gICAgdG9kYXlDb3VudDogMCxcclxuICAgIHRvZGF5RGF0ZTogdG9kYXlJU08oKSxcclxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXHJcbiAgICB0b3RhbENvbW1pdHRlZDogMCxcclxuICAgIGJ1ZmZlcmVkQ291bnQ6IDAsXHJcbiAgfTtcclxuICBpZiAoY3VyLnRvZGF5RGF0ZSAhPT0gdG9kYXlJU08oKSkge1xyXG4gICAgY3VyLnRvZGF5RGF0ZSA9IHRvZGF5SVNPKCk7XHJcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XHJcbiAgfVxyXG4gIGNvbnN0IG5leHQ6IEFjY291bnRDb3VudGVyID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XHJcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xyXG4gIGF3YWl0IHNldFJhdygnY291bnRlcnMnLCBhbGwpO1xyXG4gIHJldHVybiBuZXh0O1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QnVmZmVyZWRDb3VudChoYW5kbGU6IHN0cmluZywgY291bnQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcclxufVxyXG5cclxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIHJldHVybiBhbGxbaGFuZGxlXSA/PyBudWxsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nLCBidWY6IFJ1bkJ1ZmZlcik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBhbGxbaGFuZGxlXSA9IGJ1ZjtcclxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgZGVsZXRlIGFsbFtoYW5kbGVdO1xyXG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XHJcbn1cclxuXHJcbi8vIC0tLSBBY3Rpdml0eSB0YWlsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWN0aXZpdHkoKTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYWN0aXZpdHknKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGVuZEFjdGl2aXR5KGV2OiBMb2dFdmVudCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xyXG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XHJcbiAgY3VyLnVuc2hpZnQoZXYpO1xyXG4gIGlmIChjdXIubGVuZ3RoID4gQUNUSVZJVFlfVEFJTF9NQVgpIGN1ci5sZW5ndGggPSBBQ1RJVklUWV9UQUlMX01BWDtcclxuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcclxuICByZXR1cm4gY3VyO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJBY3Rpdml0eSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgW10pO1xyXG59XHJcblxyXG4vLyAtLS0gQ29tbWl0dGVkLXR3ZWV0cyBkZWR1cCBpbmRleCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29tbWl0dGVkSW5kZXgoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnY29tbWl0dGVkSW5kZXgnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbW1pdHRlZEluZGV4KFxyXG4gIGlkeDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PlxyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2NvbW1pdHRlZEluZGV4JywgaWR4KTtcclxufVxyXG5cclxuLyoqIENvbXB1dGUgdGhlIGVuZ2FnZW1lbnQgc2lnbmF0dXJlIHdlIHVzZSB0byBkZWNpZGUgd2hldGhlciBhIHJlLWNhcHR1cmVkXHJcbiAqIHR3ZWV0IGlzIFwibWF0ZXJpYWxseSBkaWZmZXJlbnRcIiBmcm9tIHdoYXQgd2UgbGFzdCBjb21taXR0ZWQuIFdlIG9taXRcclxuICogdmlld19jb3VudCBiZWNhdXNlIGl0IHRpY2tzIHVwIGZyZXF1ZW50bHkgb24gYWN0aXZlIHR3ZWV0cyBhbmQgd291bGRcclxuICogZGVmZWF0IHRoZSBkZWR1cC4gTGlrZXMgLyBSVHMgLyByZXBsaWVzIC8gcXVvdGVzIGNoYW5nZSByYXJlbHkgZW5vdWdoIHRoYXRcclxuICogZWFjaCBjaGFuZ2UgaXMgd29ydGggYSByZS1jb21taXQgKGFuZCBhbiBlbmdhZ2VtZW50X2hpc3Rvcnkgc25hcHNob3QpLlxyXG4gKiBgaXNfdHJ1bmNhdGVkYCBpcyBmb2xkZWQgaW4gc28gYSByZWZldGNoIHRoYXQgc3dhcHMgdGhlIDI4MC1jaGFyIGhlYWQgZm9yXHJcbiAqIHRoZSBmdWxsIGBub3RlX3R3ZWV0YCBib2R5IGJ5cGFzc2VzIHRoZSBkZWR1cCBldmVuIHdoZW4gZW5nYWdlbWVudCBjb3VudHNcclxuICogaGF2ZW4ndCBtb3ZlZCBcdTIwMTQgb3RoZXJ3aXNlIHRoZSBuZXcgYm9keSB3b3VsZCBiZSBzaWxlbnRseSBkcm9wcGVkLiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gZW5nYWdlbWVudFNpZyhcclxuICBsaWtlczogbnVtYmVyLFxyXG4gIHJldHdlZXRzOiBudW1iZXIsXHJcbiAgcmVwbGllczogbnVtYmVyLFxyXG4gIHF1b3RlczogbnVtYmVyLFxyXG4gIGlzVHJ1bmNhdGVkOiBib29sZWFuID0gZmFsc2VcclxuKTogc3RyaW5nIHtcclxuICByZXR1cm4gYCR7bGlrZXN9fCR7cmV0d2VldHN9fCR7cmVwbGllc318JHtxdW90ZXN9fCR7aXNUcnVuY2F0ZWQgPyAndCcgOiAnZid9YDtcclxufVxyXG5cclxuLyoqIERyb3AgZW50cmllcyBvbGRlciB0aGFuIGBtYXhBZ2VNc2AuIFJldHVybnMgdGhlIG51bWJlciBwcnVuZWQuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcnVuZUNvbW1pdHRlZEluZGV4KG1heEFnZU1zOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgY29uc3QgY3V0b2ZmID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIG1heEFnZU1zKS50b0lTT1N0cmluZygpO1xyXG4gIGxldCBwcnVuZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcclxuICAgIGNvbnN0IGlubmVyID0gaWR4W2hhbmRsZV07XHJcbiAgICBpZiAoIWlubmVyKSBjb250aW51ZTtcclxuICAgIGZvciAoY29uc3QgdGlkIG9mIE9iamVjdC5rZXlzKGlubmVyKSkge1xyXG4gICAgICBjb25zdCBlID0gaW5uZXJbdGlkXTtcclxuICAgICAgaWYgKGUgJiYgZS50cyA8IGN1dG9mZikge1xyXG4gICAgICAgIGRlbGV0ZSBpbm5lclt0aWRdO1xyXG4gICAgICAgIHBydW5lZCArPSAxO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoT2JqZWN0LmtleXMoaW5uZXIpLmxlbmd0aCA9PT0gMCkgZGVsZXRlIGlkeFtoYW5kbGVdO1xyXG4gIH1cclxuICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcclxuICByZXR1cm4gcHJ1bmVkO1xyXG59XHJcblxyXG4vLyAtLS0gUmVmZXRjaCBxdWV1ZSAodHdlZXRzIG5lZWRpbmcgZnVsbC10ZXh0IHJlY2FwdHVyZSkgLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoUXVldWUnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlZmV0Y2hRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGxldCB0b3RhbCA9IDA7XHJcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcclxuICByZXR1cm4gdG90YWw7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXSA/PyBbXTtcclxuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xyXG4gICAgaWRzLnB1c2godHdlZXRJZCk7XHJcbiAgICBxW2hhbmRsZV0gPSBpZHM7XHJcbiAgICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVSZWZldGNoKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdO1xyXG4gIGlmICghaWRzKSByZXR1cm47XHJcbiAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xyXG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2hhbmRsZV07XHJcbiAgZWxzZSBxW2hhbmRsZV0gPSBmaWx0ZXJlZDtcclxuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dFJlZmV0Y2hUYXJnZXQoKTogUHJvbWlzZTx7XHJcbiAgaGFuZGxlOiBzdHJpbmc7XHJcbiAgdHdlZXRJZDogc3RyaW5nO1xyXG59IHwgbnVsbD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcclxuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgaGFuZGxlLCB0d2VldElkOiBpZHNbMF0hIH07XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcblxyXG4vLyAtLS0gTWVkaWEtY3Jhd2wgcXVldWUgKHBhcnRpYWwgY2FwdHVyZXMgYXdhaXRpbmcgZGV0YWlsLXBhZ2UgZmV0Y2gpIC0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGxldCB0b3RhbCA9IDA7XHJcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcclxuICByZXR1cm4gdG90YWw7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlTWVkaWFDcmF3bChoaW50SGFuZGxlOiBzdHJpbmcgfCBudWxsLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgY29uc3QgYnVja2V0ID0gaGludEhhbmRsZSA/PyAnX3Vua25vd24nO1xyXG4gIGNvbnN0IGlkcyA9IHFbYnVja2V0XSA/PyBbXTtcclxuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xyXG4gICAgaWRzLnB1c2godHdlZXRJZCk7XHJcbiAgICBxW2J1Y2tldF0gPSBpZHM7XHJcbiAgICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVNZWRpYUNyYXdsKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xyXG4gIGZvciAoY29uc3QgYnVja2V0IG9mIE9iamVjdC5rZXlzKHEpKSB7XHJcbiAgICBjb25zdCBpZHMgPSBxW2J1Y2tldF07XHJcbiAgICBpZiAoIWlkcykgY29udGludWU7XHJcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XHJcbiAgICBpZiAoZmlsdGVyZWQubGVuZ3RoICE9PSBpZHMubGVuZ3RoKSB7XHJcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xyXG4gICAgICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtidWNrZXRdO1xyXG4gICAgICBlbHNlIHFbYnVja2V0XSA9IGZpbHRlcmVkO1xyXG4gICAgfVxyXG4gIH1cclxuICBpZiAoY2hhbmdlZCkgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRNZWRpYUNyYXdsVGFyZ2V0KCk6IFByb21pc2U8e1xyXG4gIGJ1Y2tldDogc3RyaW5nO1xyXG4gIHR3ZWV0SWQ6IHN0cmluZztcclxufSB8IG51bGw+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgZm9yIChjb25zdCBbYnVja2V0LCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XHJcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGJ1Y2tldCwgdHdlZXRJZDogaWRzWzBdISB9O1xyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuLyoqIEhhcyB0aGlzIHR3ZWV0IGlkIGFscmVhZHkgYmVlbiBjb21taXR0ZWQgKGFueSBoYW5kbGUpPyBVc2VkIHRvIHNraXBcclxuICogZW5xdWV1ZWluZyBtZWRpYS1jcmF3bCB0YXJnZXRzIHdlJ3ZlIGFscmVhZHkgYXJjaGl2ZWQuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpc0NvbW1pdHRlZCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGZvciAoY29uc3QgaW5uZXIgb2YgT2JqZWN0LnZhbHVlcyhpZHgpKSB7XHJcbiAgICBpZiAoaW5uZXIgJiYgdHdlZXRJZCBpbiBpbm5lcikgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG4gIHJldHVybiBmYWxzZTtcclxufVxyXG5cclxuLy8gLS0tIExvb3Agc2Vzc2lvbiBzdGF0ZSAocHJvZ3Jlc3MgKyBpbmZsaWdodCBnYXRpbmcpIC0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hTZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFNlc3Npb24nKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UmVmZXRjaFNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoU2Vzc2lvbicsIHMpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nLCBzKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTogUHJvbWlzZTxBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJywgcyk7XHJcbn1cclxuXHJcbi8vIC0tLSBQdXJnZTogdW5yZWxhdGVkIGJ1ZmZlcnMsIGNvdW50ZXJzLCBxdWV1ZSBlbnRyaWVzIC0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbi8qKlxyXG4gKiBEcm9wIGV2ZXJ5IHBlci1oYW5kbGUgYml0IG9mIHN0YXRlIChjb3VudGVycywgcnVuIGJ1ZmZlciwgY29tbWl0dGVkLWluZGV4XHJcbiAqIGVudHJpZXMsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyaWVzKSB0aGF0IGRvZXNuJ3QgY29ycmVzcG9uZCB0byBhXHJcbiAqIHRyYWNrZWQgYWNjb3VudC4gUmV0dXJucyBhIHN1bW1hcnkgZGVzY3JpYmluZyB3aGF0IHdhcyBjbGVhcmVkIHNvIHRoZVxyXG4gKiBjYWxsZXIgY2FuIGxvZyBpdC5cclxuICpcclxuICogVHJhY2tlZCBhY2NvdW50cyBhcmUgcGFzc2VkIGluIChjYWxsZXIgcmVzb2x2ZXMgZnJvbSB0aGUgbGl2ZSBjb25maWcpLlxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1cmdlVW5yZWxhdGVkU3RhdGUodGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4pOiBQcm9taXNlPHtcclxuICBjb3VudGVyc1JlbW92ZWQ6IG51bWJlcjtcclxuICBidWZmZXJzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XHJcbiAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XHJcbiAgbWVkaWFDcmF3bElkc1JlbW92ZWQ6IG51bWJlcjtcclxufT4ge1xyXG4gIGNvbnN0IHRhcmdMb3dlciA9IG5ldyBTZXQoWy4uLnRhcmdldGVkXS5tYXAoKGgpID0+IGgudG9Mb3dlckNhc2UoKSkpO1xyXG4gIGNvbnN0IGlzVGFyZ2V0ZWQgPSAoaDogc3RyaW5nKTogYm9vbGVhbiA9PiB0YXJnTG93ZXIuaGFzKGgudG9Mb3dlckNhc2UoKSk7XHJcblxyXG4gIC8vIENvdW50ZXJzXHJcbiAgY29uc3QgY291bnRlcnMgPSBhd2FpdCBnZXRDb3VudGVycygpO1xyXG4gIGxldCBjb3VudGVyc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhjb3VudGVycykpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgY291bnRlcnNbaF07XHJcbiAgICAgIGNvdW50ZXJzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgY291bnRlcnMpO1xyXG5cclxuICAvLyBSdW4gYnVmZmVyc1xyXG4gIGNvbnN0IGJ1ZmZlcnMgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgbGV0IGJ1ZmZlcnNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoYnVmZmVycykpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgYnVmZmVyc1toXTtcclxuICAgICAgYnVmZmVyc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYnVmZmVycyk7XHJcblxyXG4gIC8vIENvbW1pdHRlZCBkZWR1cCBpbmRleFxyXG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgbGV0IGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoaWR4KSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIGRlbGV0ZSBpZHhbaF07XHJcbiAgICAgIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XHJcblxyXG4gIC8vIFJlZmV0Y2ggcXVldWU6IGJ1Y2tldHMgYXJlIGtleWVkIGJ5IGhhbmRsZS5cclxuICBjb25zdCBycSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGxldCByZWZldGNoSGFuZGxlc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhycSkpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgcnFbaF07XHJcbiAgICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHJxKTtcclxuXHJcbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IGJ1Y2tldHMgYXJlIGhpbnQtaGFuZGxlcyAob3IgXCJfdW5rbm93blwiKS4gRHJvcFxyXG4gIC8vIGVudHJpZXMgd2hvc2UgYnVja2V0IGlzbid0IHRhcmdldGVkIFx1MjAxNCBpbmNsdWRpbmcgXCJfdW5rbm93blwiIHNpbmNlIHdlXHJcbiAgLy8gY2FuJ3QgdmVyaWZ5IHJlbGF0aW9uLlxyXG4gIGNvbnN0IG1xID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgbGV0IG1lZGlhQ3Jhd2xJZHNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMobXEpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgbWVkaWFDcmF3bElkc1JlbW92ZWQgKz0gKG1xW2hdID8/IFtdKS5sZW5ndGg7XHJcbiAgICAgIGRlbGV0ZSBtcVtoXTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBtcSk7XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBjb3VudGVyc1JlbW92ZWQsXHJcbiAgICBidWZmZXJzUmVtb3ZlZCxcclxuICAgIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkLFxyXG4gICAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkLFxyXG4gICAgbWVkaWFDcmF3bElkc1JlbW92ZWQsXHJcbiAgfTtcclxufVxyXG5cclxuLy8gLS0tIEZ1bGwgcmVzZXQgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5jbGVhcigpO1xyXG59XHJcbiIsICIvKipcclxuICogb3B0aW9ucy50cyBcdTIwMTQgc2V0dGluZ3MgcGFnZS5cclxuICpcclxuICogU3RvcmVzIFBBVCBhbmQgcmVwbyBpZGVudGlmaWVycyBpbiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgdmVyaWZpZXMgYWNjZXNzXHJcbiAqIGJ5IGNhbGxpbmcgL3VzZXIgYW5kIC9yZXBvcy86b3duZXIvOnJlcG8sIGFuZCBzdXJmYWNlcyB0aGUgcmVzdWx0aW5nXHJcbiAqIGNvbm5lY3Rpb24gc3RhdGUuXHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUyB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XHJcbmltcG9ydCB7XHJcbiAgY2xlYXJBbGwsXHJcbiAgZ2V0QWNjb3VudHMsXHJcbiAgZ2V0QWN0aXZpdHksXHJcbiAgZ2V0Q29ubmVjdGlvbixcclxuICBnZXRDb3VudGVycyxcclxuICBnZXRSdW5CdWZmZXJzLFxyXG4gIGdldFNldHRpbmdzLFxyXG4gIHVwZGF0ZVNldHRpbmdzLFxyXG59IGZyb20gJy4vbGliL3N0b3JhZ2UuanMnO1xyXG5pbXBvcnQgdHlwZSB7IFJ1bnRpbWVNZXNzYWdlIH0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xyXG5cclxuY29uc3QgJCA9IDxUIGV4dGVuZHMgSFRNTEVsZW1lbnQgPSBIVE1MRWxlbWVudD4oaWQ6IHN0cmluZyk6IFQgPT4ge1xyXG4gIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xyXG4gIGlmICghZWwpIHRocm93IG5ldyBFcnJvcihgbWlzc2luZyBlbGVtZW50ICMke2lkfWApO1xyXG4gIHJldHVybiBlbCBhcyBUO1xyXG59O1xyXG5cclxuY29uc3QgZm9ybSA9ICQ8SFRNTEZvcm1FbGVtZW50Pignc2V0dGluZ3MtZm9ybScpO1xyXG5jb25zdCBvd25lcklucHV0ID0gJDxIVE1MSW5wdXRFbGVtZW50Pignb3duZXInKTtcclxuY29uc3QgcmVwb0lucHV0ID0gJDxIVE1MSW5wdXRFbGVtZW50PigncmVwbycpO1xyXG5jb25zdCBicmFuY2hJbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2JyYW5jaCcpO1xyXG5jb25zdCBwYXRJbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ3BhdCcpO1xyXG5jb25zdCByZXZlYWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmV2ZWFsLXBhdCcpO1xyXG5jb25zdCBzYXZlU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdzYXZlLXN0YXR1cycpO1xyXG5jb25zdCBjb25uRGV0YWlsID0gJCgnY29ubi1kZXRhaWwnKTtcclxuY29uc3QgYWNjb3VudExpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdhY2NvdW50LXJlYWRvbmx5Jyk7XHJcbmNvbnN0IHJlZnJlc2hCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmcmVzaC1hY2NvdW50cycpO1xyXG5jb25zdCBkaWFnQm94ID0gJDxIVE1MVGV4dEFyZWFFbGVtZW50PignZGlhZ25vc3RpY3MnKTtcclxuY29uc3QgY29weURpYWdCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY29weS1kaWFnbm9zdGljcycpO1xyXG5jb25zdCBjbGVhclN0b3JhZ2VCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2xlYXItc3RvcmFnZScpO1xyXG5jb25zdCBkaWFnU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdkaWFnLXN0YXR1cycpO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2VuZDxUPihtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTxUPiB7XHJcbiAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZShtc2cpIGFzIFByb21pc2U8VD47XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNldFN0YXR1cyhlbDogSFRNTEVsZW1lbnQsIGtpbmQ6ICdvaycgfCAnZXJyJyB8ICd3YXJuJyB8ICcnLCBtc2c6IHN0cmluZyk6IHZvaWQge1xyXG4gIGVsLmNsYXNzTmFtZSA9IGtpbmQgPyBgc3RhdHVzICR7a2luZH1gIDogJ3N0YXR1cyc7XHJcbiAgZWwudGV4dENvbnRlbnQgPSBtc2c7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGxvYWRTZXR0aW5ncygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBvd25lcklucHV0LnZhbHVlID0gcy5vd25lciB8fCBERUZBVUxUX1NFVFRJTkdTLm93bmVyO1xyXG4gIHJlcG9JbnB1dC52YWx1ZSA9IHMucmVwbyB8fCBERUZBVUxUX1NFVFRJTkdTLnJlcG87XHJcbiAgYnJhbmNoSW5wdXQudmFsdWUgPSBzLmJyYW5jaCB8fCBERUZBVUxUX1NFVFRJTkdTLmJyYW5jaDtcclxuICBpZiAocy5wYXQpIHtcclxuICAgIHBhdElucHV0LnZhbHVlID0gcy5wYXQ7XHJcbiAgICBwYXRJbnB1dC5wbGFjZWhvbGRlciA9IGBcdTIwMjYke3MucGF0LnNsaWNlKC00KX1gO1xyXG4gIH1cclxuICBhd2FpdCBwYWludENvbm5EZXRhaWwoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcGFpbnRDb25uRGV0YWlsKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgY29uc3QgbGluZXM6IHN0cmluZ1tdID0gW107XHJcbiAgbGluZXMucHVzaChgU3RhdHVzOiAke2Nvbm4uc3RhdHVzfWApO1xyXG4gIGlmIChjb25uLmxvZ2luKSBsaW5lcy5wdXNoKGBMb2dnZWQgaW4gYXM6IEAke2Nvbm4ubG9naW59YCk7XHJcbiAgbGluZXMucHVzaChgUmVwb3NpdG9yeTogJHtzLm93bmVyIHx8ICc/J30vJHtzLnJlcG8gfHwgJz8nfUAke3MuYnJhbmNoIHx8ICc/J31gKTtcclxuICBpZiAoY29ubi5jaGVja2VkQXQpIGxpbmVzLnB1c2goYExhc3QgY2hlY2tlZDogJHtjb25uLmNoZWNrZWRBdH1gKTtcclxuICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xyXG4gICAgY29uc3QgcmVzZXRJc28gPSBuZXcgRGF0ZShjb25uLnJhdGVMaW1pdFJlc2V0QXQgKiAxMDAwKS50b0lTT1N0cmluZygpO1xyXG4gICAgY29uc3QgZGVsdGFTZWMgPSBjb25uLnJhdGVMaW1pdFJlc2V0QXQgLSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcclxuICAgIGNvbnN0IGluTGFiZWwgPVxyXG4gICAgICBkZWx0YVNlYyA8PSAwXHJcbiAgICAgICAgPyAnbW9tZW50YXJpbHknXHJcbiAgICAgICAgOiBkZWx0YVNlYyA8IDYwXHJcbiAgICAgICAgICA/IGBpbiAke2RlbHRhU2VjfXNgXHJcbiAgICAgICAgICA6IGRlbHRhU2VjIDwgMzYwMFxyXG4gICAgICAgICAgICA/IGBpbiAke01hdGgucm91bmQoZGVsdGFTZWMgLyA2MCl9bWBcclxuICAgICAgICAgICAgOiBgaW4gJHtNYXRoLnJvdW5kKGRlbHRhU2VjIC8gMzYwMCl9aGA7XHJcbiAgICBsaW5lcy5wdXNoKGBSYXRlIGxpbWl0IHJlc2V0czogJHtyZXNldElzb30gKCR7aW5MYWJlbH0pYCk7XHJcbiAgfVxyXG4gIGlmIChjb25uLmVycm9yKSBsaW5lcy5wdXNoKGBFcnJvcjogJHtjb25uLmVycm9yfWApO1xyXG4gIGNvbm5EZXRhaWwudGV4dENvbnRlbnQgPSBsaW5lcy5qb2luKCdcXG4nKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcGFpbnRBY2NvdW50cygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBsaXN0ID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcclxuICBhY2NvdW50TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcclxuICBmb3IgKGNvbnN0IGEgb2YgbGlzdCkge1xyXG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xyXG4gICAgY29uc3QgaGFuZGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgaGFuZGxlLmNsYXNzTmFtZSA9ICdoYW5kbGUnO1xyXG4gICAgaGFuZGxlLnRleHRDb250ZW50ID0gYEAke2EuaGFuZGxlfWA7XHJcbiAgICBjb25zdCBsYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIGxhYmVsLmNsYXNzTmFtZSA9ICdsYWJlbCc7XHJcbiAgICBsYWJlbC50ZXh0Q29udGVudCA9IGEubGFiZWw7XHJcbiAgICBsaS5hcHBlbmQoaGFuZGxlLCBsYWJlbCk7XHJcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xyXG4gIH1cclxufVxyXG5cclxuZm9ybS5hZGRFdmVudExpc3RlbmVyKCdzdWJtaXQnLCBhc3luYyAoZTogRXZlbnQpID0+IHtcclxuICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgY29uc3QgcGF0ID0gcGF0SW5wdXQudmFsdWUudHJpbSgpO1xyXG4gIGNvbnN0IG93bmVyID0gb3duZXJJbnB1dC52YWx1ZS50cmltKCk7XHJcbiAgY29uc3QgcmVwbyA9IHJlcG9JbnB1dC52YWx1ZS50cmltKCk7XHJcbiAgY29uc3QgYnJhbmNoID0gYnJhbmNoSW5wdXQudmFsdWUudHJpbSgpIHx8ICdtYWluJztcclxuICBpZiAoIXBhdCB8fCAhb3duZXIgfHwgIXJlcG8pIHtcclxuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgJ0FsbCBmaWVsZHMgYXJlIHJlcXVpcmVkLicpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJycsICdTYXZpbmdcdTIwMjYnKTtcclxuICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IHBhdCwgb3duZXIsIHJlcG8sIGJyYW5jaCwgY29uZmlndXJlZEF0OiBEYXRlLm5vdygpIH0pO1xyXG4gIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnJywgJ1ZlcmlmeWluZ1x1MjAyNicpO1xyXG4gIGF3YWl0IHNlbmQoeyB0eXBlOiAndmVyaWZ5LWNvbm5lY3Rpb24nIH0pO1xyXG4gIGF3YWl0IHNlbmQoeyB0eXBlOiAncmVmcmVzaC1hY2NvdW50cycgfSk7XHJcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcclxuICBpZiAoY29ubi5zdGF0dXMgPT09ICdvaycpIHtcclxuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnb2snLCBgQ29ubmVjdGVkIGFzIEAke2Nvbm4ubG9naW4gPz8gJz8nfS5gKTtcclxuICB9IGVsc2UgaWYgKGNvbm4uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcclxuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgJ0F1dGggZmFpbGVkIFx1MjAxNCBjaGVjayB0aGUgUEFUIGFuZCBpdHMgcmVwbyBzY29wZS4nKTtcclxuICB9IGVsc2UgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJykge1xyXG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICd3YXJuJywgJ1JhdGUtbGltaXRlZCBcdTIwMTQgdG9rZW4gaXMgdmFsaWQgYnV0IEdpdEh1YiBpcyB0aHJvdHRsaW5nLicpO1xyXG4gIH0gZWxzZSBpZiAoY29ubi5zdGF0dXMgPT09ICduZXR3b3JrLWVycm9yJykge1xyXG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICdlcnInLCAnTmV0d29yayBlcnJvciBcdTIwMTQgY2hlY2sgY29ubmVjdGl2aXR5LicpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ2VycicsIGBWZXJpZmljYXRpb246ICR7Y29ubi5zdGF0dXN9YCk7XHJcbiAgfVxyXG4gIGF3YWl0IHBhaW50Q29ubkRldGFpbCgpO1xyXG4gIGF3YWl0IHBhaW50QWNjb3VudHMoKTtcclxuICBhd2FpdCByZWZyZXNoRGlhZygpO1xyXG59KTtcclxuXHJcbnJldmVhbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICBpZiAocGF0SW5wdXQudHlwZSA9PT0gJ3Bhc3N3b3JkJykge1xyXG4gICAgcGF0SW5wdXQudHlwZSA9ICd0ZXh0JztcclxuICAgIHJldmVhbEJ0bi50ZXh0Q29udGVudCA9ICdIaWRlJztcclxuICB9IGVsc2Uge1xyXG4gICAgcGF0SW5wdXQudHlwZSA9ICdwYXNzd29yZCc7XHJcbiAgICByZXZlYWxCdG4udGV4dENvbnRlbnQgPSAnU2hvdyc7XHJcbiAgfVxyXG59KTtcclxuXHJcbnJlZnJlc2hCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgcmVmcmVzaEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAncmVmcmVzaC1hY2NvdW50cycgfSk7XHJcbiAgICBhd2FpdCBwYWludEFjY291bnRzKCk7XHJcbiAgICBzZXRTdGF0dXMoZGlhZ1N0YXR1cywgJ29rJywgJ0FjY291bnRzIHJlZnJlc2hlZC4nKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnZXJyJywgYFJlZnJlc2ggZmFpbGVkOiAkeyhlcnIgYXMgRXJyb3IpLm1lc3NhZ2V9YCk7XHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIHJlZnJlc2hCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9XHJcbn0pO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaERpYWcoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgW3NldHRpbmdzLCBjb25uLCBhY2NvdW50cywgY291bnRlcnMsIGJ1ZmZlcnMsIGFjdGl2aXR5XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgIGdldFNldHRpbmdzKCksXHJcbiAgICBnZXRDb25uZWN0aW9uKCksXHJcbiAgICBnZXRBY2NvdW50cygpLFxyXG4gICAgZ2V0Q291bnRlcnMoKSxcclxuICAgIGdldFJ1bkJ1ZmZlcnMoKSxcclxuICAgIGdldEFjdGl2aXR5KCksXHJcbiAgXSk7XHJcbiAgY29uc3QgcmVkYWN0ZWRCdWZmZXJzID0gT2JqZWN0LmZyb21FbnRyaWVzKFxyXG4gICAgT2JqZWN0LmVudHJpZXMoYnVmZmVycykubWFwKChbaywgYl0pID0+IFtcclxuICAgICAgayxcclxuICAgICAge1xyXG4gICAgICAgIHJ1bl9pZDogYi5ydW5faWQsXHJcbiAgICAgICAgc3RhcnRlZF9hdDogYi5zdGFydGVkX2F0LFxyXG4gICAgICAgIGxhc3RfY2FwdHVyZV9hdDogYi5sYXN0X2NhcHR1cmVfYXQsXHJcbiAgICAgICAgdHdlZXRzX2NvdW50OiBPYmplY3Qua2V5cyhiLnR3ZWV0c19ieV9pZCkubGVuZ3RoLFxyXG4gICAgICAgIG9ic2VydmVkX2NvdW50OiBiLnR3ZWV0X2lkc19vYnNlcnZlZC5sZW5ndGgsXHJcbiAgICAgICAgZW5kcG9pbnRzX3NlZW46IGIuZW5kcG9pbnRzX3NlZW4sXHJcbiAgICAgICAgc291cmNlX3VybDogYi5zb3VyY2VfdXJsLFxyXG4gICAgICB9LFxyXG4gICAgXSlcclxuICApO1xyXG4gIGNvbnN0IGR1bXAgPSB7XHJcbiAgICB2ZXJzaW9uOiBicm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uLFxyXG4gICAgdXNlcl9hZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcclxuICAgIHNldHRpbmdzOiB7XHJcbiAgICAgIG93bmVyOiBzZXR0aW5ncy5vd25lcixcclxuICAgICAgcmVwbzogc2V0dGluZ3MucmVwbyxcclxuICAgICAgYnJhbmNoOiBzZXR0aW5ncy5icmFuY2gsXHJcbiAgICAgIGF1dG9DYXB0dXJlOiBzZXR0aW5ncy5hdXRvQ2FwdHVyZSxcclxuICAgICAgY29uZmlndXJlZEF0OiBzZXR0aW5ncy5jb25maWd1cmVkQXQsXHJcbiAgICAgIHBhdFNldDogc2V0dGluZ3MucGF0Lmxlbmd0aCA+IDAsXHJcbiAgICAgIHBhdFN1ZmZpeDogc2V0dGluZ3MucGF0Lmxlbmd0aCA+PSA0ID8gc2V0dGluZ3MucGF0LnNsaWNlKC00KSA6ICcnLFxyXG4gICAgfSxcclxuICAgIGNvbm5lY3Rpb246IGNvbm4sXHJcbiAgICBhY2NvdW50cyxcclxuICAgIGNvdW50ZXJzLFxyXG4gICAgcnVuQnVmZmVyczogcmVkYWN0ZWRCdWZmZXJzLFxyXG4gICAgYWN0aXZpdHlfdGFpbF9zaXplOiBhY3Rpdml0eS5sZW5ndGgsXHJcbiAgICBhY3Rpdml0eV9yZWNlbnQ6IGFjdGl2aXR5LnNsaWNlKDAsIDMwKSxcclxuICB9O1xyXG4gIGRpYWdCb3gudmFsdWUgPSBKU09OLnN0cmluZ2lmeShkdW1wLCBudWxsLCAyKTtcclxufVxyXG5cclxuY29weURpYWdCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgYXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQoZGlhZ0JveC52YWx1ZSk7XHJcbiAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICdvaycsICdDb3BpZWQgZGlhZ25vc3RpY3MgdG8gY2xpcGJvYXJkLicpO1xyXG59KTtcclxuXHJcbmNsZWFyU3RvcmFnZUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICBjb25zdCBvayA9IHdpbmRvdy5jb25maXJtKFxyXG4gICAgJ0NsZWFyIGV4dGVuc2lvbiBzdG9yYWdlPyBUaGlzIGVyYXNlcyB5b3VyIFBBVCwgc2V0dGluZ3MsIGNvdW50ZXJzLCBidWZmZXJlZCBjYXB0dXJlcywgYW5kIGFjdGl2aXR5IHRhaWwuIFRoZXJlIGlzIG5vIHVuZG8uJ1xyXG4gICk7XHJcbiAgaWYgKCFvaykgcmV0dXJuO1xyXG4gIGF3YWl0IGNsZWFyQWxsKCk7XHJcbiAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICd3YXJuJywgJ1N0b3JhZ2UgY2xlYXJlZC4nKTtcclxuICBhd2FpdCBsb2FkU2V0dGluZ3MoKTtcclxuICBhd2FpdCBwYWludEFjY291bnRzKCk7XHJcbiAgYXdhaXQgcmVmcmVzaERpYWcoKTtcclxufSk7XHJcblxyXG52b2lkIGxvYWRTZXR0aW5ncygpO1xyXG52b2lkIHBhaW50QWNjb3VudHMoKTtcclxudm9pZCByZWZyZXNoRGlhZygpO1xyXG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRU8sSUFBTSxtQkFBNkI7QUFBQSxFQUN4QyxLQUFLO0FBQUEsRUFDTCxPQUFPO0FBQUEsRUFDUCxNQUFNO0FBQUE7QUFBQTtBQUFBLEVBR04sUUFBUTtBQUFBLEVBQ1IsU0FBUztBQUFBLEVBQ1QsYUFBYTtBQUFBLEVBQ2IsY0FBYztBQUFBLEVBQ2QsdUJBQXVCO0FBQ3pCO0FBT08sSUFBTSxvQkFBcUM7QUFBQSxFQUNoRCxFQUFFLFFBQVEsVUFBVSxPQUFPLG1DQUFtQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsVUFBVSxPQUFPLDRDQUE0QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsT0FBTyxPQUFPLHNDQUFzQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsU0FBUyxPQUFPLDZDQUE2QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsY0FBYyxPQUFPLG1CQUFtQixVQUFVLE9BQU87QUFBQSxFQUNuRSxFQUFFLFFBQVEsWUFBWSxPQUFPLCtCQUErQixVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLGtDQUFrQyxVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLDRCQUE0QixVQUFVLE9BQU87QUFBQSxFQUN2RSxFQUFFLFFBQVEsbUJBQW1CLE9BQU8scUJBQXFCLFVBQVUsT0FBTztBQUM1RTtBQThETyxJQUFNLGdDQUFnQyxLQUFLLEtBQUs7OztBQ3BFdkQsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0I7QUFFeEIsSUFBSSxrQkFBb0M7QUFDeEMsSUFBSSxzQkFBcUM7QUFFekMsU0FBUyxTQUFTLEtBQXlCO0FBQ3pDLE1BQUksSUFBSTtBQUNSLGFBQVcsS0FBSyxJQUFLLE1BQUssT0FBTyxhQUFhLENBQUM7QUFDL0MsU0FBTyxLQUFLLENBQUM7QUFDZjtBQUVBLFNBQVMsV0FBVyxHQUF1QjtBQUN6QyxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFFBQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxNQUFNO0FBQ3JDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUssS0FBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFDOUQsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUU7QUFDaEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDL0QsUUFBTSxJQUFJLE9BQU8sZ0JBQWdCO0FBQ2pDLE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsV0FBTyxFQUFFLFNBQVMsR0FBRyxNQUFNLFdBQVcsQ0FBQyxFQUFFO0FBQUEsRUFDM0M7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxRQUFNLFVBQVUsU0FBUyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0FBQy9ELFNBQU8sRUFBRSxTQUFTLEtBQUs7QUFDekI7QUFFQSxlQUFlLFlBQWdDO0FBQzdDLFFBQU0sRUFBRSxTQUFTLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUNqRCxNQUFJLG9CQUFvQixRQUFRLHdCQUF3QixTQUFTO0FBQy9ELFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFO0FBQUEsSUFDN0IsR0FBRyxRQUFRLFFBQVEsRUFBRSxJQUFJLFFBQVEsUUFBUSxZQUFZLEVBQUUsT0FBTztBQUFBLEVBQ2hFO0FBQ0EsUUFBTSxXQUFXLElBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNO0FBQ3pELFdBQVMsSUFBSSxNQUFNLENBQUM7QUFDcEIsV0FBUyxJQUFJLE1BQU0sS0FBSyxNQUFNO0FBQzlCLFFBQU0sT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUTtBQUMzRCxRQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLE1BQU0sRUFBRSxNQUFNLFVBQVUsR0FBRyxPQUFPO0FBQUEsSUFDakY7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBQ0Qsb0JBQWtCO0FBQ2xCLHdCQUFzQjtBQUN0QixTQUFPO0FBQ1Q7QUFFTyxTQUFTLGVBQWUsR0FBb0I7QUFDakQsU0FBTyxFQUFFLFdBQVcsZUFBZTtBQUNyQztBQUVBLGVBQXNCLFdBQVcsV0FBb0M7QUFDbkUsTUFBSSxDQUFDLFVBQVcsUUFBTztBQUN2QixRQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFFBQU0sS0FBSyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3BELFFBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLElBQzdCLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxJQUN0QjtBQUFBLElBQ0EsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTO0FBQUEsRUFDcEM7QUFDQSxTQUFPLEdBQUcsZUFBZSxHQUFHLFNBQVMsRUFBRSxDQUFDLElBQUksU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMUU7QUFFQSxlQUFzQixXQUFXLFVBQW1DO0FBQ2xFLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFHdEIsTUFBSSxDQUFDLFNBQVMsV0FBVyxlQUFlLEVBQUcsUUFBTztBQUNsRCxRQUFNLFFBQVEsU0FBUyxNQUFNLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxHQUFHO0FBQzlELE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUMvQixRQUFNLENBQUMsT0FBTyxLQUFLLElBQUk7QUFDdkIsTUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFPLFFBQU87QUFDN0IsTUFBSTtBQUNGLFVBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQzdCLEVBQUUsTUFBTSxXQUFXLEdBQXVCO0FBQUEsTUFDMUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDcEMsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7OztBQzVCQSxJQUFNLHFCQUFzQztBQUFBLEVBQzFDLFFBQVE7QUFBQSxFQUNSLE9BQU87QUFBQSxFQUNQLFdBQVc7QUFBQSxFQUNYLE9BQU87QUFBQSxFQUNQLGVBQWU7QUFBQSxFQUNmLHdCQUF3QjtBQUFBLEVBQ3hCLGtCQUFrQjtBQUNwQjtBQUVBLElBQU0sV0FBeUI7QUFBQSxFQUM3QixVQUFVLEVBQUUsR0FBRyxpQkFBaUI7QUFBQSxFQUNoQyxVQUFVLENBQUMsR0FBRyxpQkFBaUI7QUFBQSxFQUMvQixxQkFBcUI7QUFBQSxFQUNyQixZQUFZLEVBQUUsR0FBRyxtQkFBbUI7QUFBQSxFQUNwQyxVQUFVLENBQUM7QUFBQSxFQUNYLFlBQVksQ0FBQztBQUFBLEVBQ2IsVUFBVSxDQUFDO0FBQUEsRUFDWCxnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGNBQWMsQ0FBQztBQUFBLEVBQ2YsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixnQkFBZ0I7QUFBQSxFQUNoQixtQkFBbUI7QUFBQSxFQUNuQixtQkFBbUI7QUFDckI7QUFFQSxlQUFlLE9BQXFDLEtBQWtDO0FBQ3BGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksR0FBRztBQUNsRCxRQUFNLFFBQVEsT0FBTyxHQUFHO0FBQ3hCLE1BQUksVUFBVSxRQUFXO0FBQ3ZCLFdBQU8sZ0JBQWdCLFNBQVMsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxlQUFlLE9BQXFDLEtBQVEsT0FBdUM7QUFDakcsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDO0FBQ2xEO0FBSUEsZUFBc0IsY0FBaUM7QUFLckQsUUFBTSxTQUFTLE1BQU0sT0FBTyxVQUFVO0FBQ3RDLFFBQU0sU0FBUyxFQUFFLEdBQUcsa0JBQWtCLEdBQUcsT0FBTztBQUNoRCxNQUFJLE9BQU8sT0FBTyxlQUFlLE9BQU8sR0FBRyxHQUFHO0FBQzVDLFFBQUk7QUFDRixhQUFPLE1BQU0sTUFBTSxXQUFXLE9BQU8sR0FBRztBQUFBLElBQzFDLFFBQVE7QUFDTixhQUFPLE1BQU07QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLFlBQVksR0FBNEI7QUFHNUQsUUFBTSxVQUFvQixFQUFFLEdBQUcsRUFBRTtBQUNqQyxNQUFJLFFBQVEsT0FBTyxDQUFDLGVBQWUsUUFBUSxHQUFHLEdBQUc7QUFDL0MsWUFBUSxNQUFNLE1BQU0sV0FBVyxRQUFRLEdBQUc7QUFBQSxFQUM1QztBQUNBLFFBQU0sT0FBTyxZQUFZLE9BQU87QUFDbEM7QUFDQSxlQUFzQixlQUFlLE9BQTZDO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxPQUFPLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoQyxRQUFNLFlBQVksSUFBSTtBQUN0QixTQUFPO0FBQ1Q7QUFJQSxlQUFzQixjQUF3QztBQUM1RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQWFBLGVBQXNCLGdCQUEwQztBQUM5RCxRQUFNLElBQUksTUFBTSxPQUFPLFlBQVk7QUFFbkMsUUFBTSxNQUF1QjtBQUFBLElBQzNCLEdBQUc7QUFBQSxJQUNILGVBQWUsRUFBRSxrQkFBa0IsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUN4RCx3QkFDRSxFQUFFLDJCQUEyQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3BELGtCQUFrQixFQUFFLHFCQUFxQixTQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ2hFO0FBQ0EsU0FBTztBQUNUO0FBV0EsZUFBc0IsY0FBdUQ7QUFDM0UsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUE2QkEsZUFBc0IsZ0JBQW9EO0FBQ3hFLFNBQU8sT0FBTyxZQUFZO0FBQzVCO0FBcUJBLGVBQXNCLGNBQW1DO0FBQ3ZELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBdVJBLGVBQXNCLFdBQTBCO0FBQzlDLFFBQU0sUUFBUSxRQUFRLE1BQU0sTUFBTTtBQUNwQzs7O0FDbGdCQSxJQUFNLElBQUksQ0FBc0MsT0FBa0I7QUFDaEUsUUFBTSxLQUFLLFNBQVMsZUFBZSxFQUFFO0FBQ3JDLE1BQUksQ0FBQyxHQUFJLE9BQU0sSUFBSSxNQUFNLG9CQUFvQixFQUFFLEVBQUU7QUFDakQsU0FBTztBQUNUO0FBRUEsSUFBTSxPQUFPLEVBQW1CLGVBQWU7QUFDL0MsSUFBTSxhQUFhLEVBQW9CLE9BQU87QUFDOUMsSUFBTSxZQUFZLEVBQW9CLE1BQU07QUFDNUMsSUFBTSxjQUFjLEVBQW9CLFFBQVE7QUFDaEQsSUFBTSxXQUFXLEVBQW9CLEtBQUs7QUFDMUMsSUFBTSxZQUFZLEVBQXFCLFlBQVk7QUFDbkQsSUFBTSxhQUFhLEVBQW1CLGFBQWE7QUFDbkQsSUFBTSxhQUFhLEVBQUUsYUFBYTtBQUNsQyxJQUFNLGNBQWMsRUFBb0Isa0JBQWtCO0FBQzFELElBQU0sYUFBYSxFQUFxQixrQkFBa0I7QUFDMUQsSUFBTSxVQUFVLEVBQXVCLGFBQWE7QUFDcEQsSUFBTSxjQUFjLEVBQXFCLGtCQUFrQjtBQUMzRCxJQUFNLGtCQUFrQixFQUFxQixlQUFlO0FBQzVELElBQU0sYUFBYSxFQUFtQixhQUFhO0FBRW5ELGVBQWUsS0FBUSxLQUFpQztBQUN0RCxTQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDeEM7QUFFQSxTQUFTLFVBQVUsSUFBaUIsTUFBa0MsS0FBbUI7QUFDdkYsS0FBRyxZQUFZLE9BQU8sVUFBVSxJQUFJLEtBQUs7QUFDekMsS0FBRyxjQUFjO0FBQ25CO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLGFBQVcsUUFBUSxFQUFFLFNBQVMsaUJBQWlCO0FBQy9DLFlBQVUsUUFBUSxFQUFFLFFBQVEsaUJBQWlCO0FBQzdDLGNBQVksUUFBUSxFQUFFLFVBQVUsaUJBQWlCO0FBQ2pELE1BQUksRUFBRSxLQUFLO0FBQ1QsYUFBUyxRQUFRLEVBQUU7QUFDbkIsYUFBUyxjQUFjLFNBQUksRUFBRSxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFDNUM7QUFDQSxRQUFNLGdCQUFnQjtBQUN4QjtBQUVBLGVBQWUsa0JBQWlDO0FBQzlDLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFFBQWtCLENBQUM7QUFDekIsUUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLEVBQUU7QUFDbkMsTUFBSSxLQUFLLE1BQU8sT0FBTSxLQUFLLGtCQUFrQixLQUFLLEtBQUssRUFBRTtBQUN6RCxRQUFNLEtBQUssZUFBZSxFQUFFLFNBQVMsR0FBRyxJQUFJLEVBQUUsUUFBUSxHQUFHLElBQUksRUFBRSxVQUFVLEdBQUcsRUFBRTtBQUM5RSxNQUFJLEtBQUssVUFBVyxPQUFNLEtBQUssaUJBQWlCLEtBQUssU0FBUyxFQUFFO0FBQ2hFLE1BQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFVBQU0sV0FBVyxJQUFJLEtBQUssS0FBSyxtQkFBbUIsR0FBSSxFQUFFLFlBQVk7QUFDcEUsVUFBTSxXQUFXLEtBQUssbUJBQW1CLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQ3JFLFVBQU0sVUFDSixZQUFZLElBQ1IsZ0JBQ0EsV0FBVyxLQUNULE1BQU0sUUFBUSxNQUNkLFdBQVcsT0FDVCxNQUFNLEtBQUssTUFBTSxXQUFXLEVBQUUsQ0FBQyxNQUMvQixNQUFNLEtBQUssTUFBTSxXQUFXLElBQUksQ0FBQztBQUMzQyxVQUFNLEtBQUssc0JBQXNCLFFBQVEsS0FBSyxPQUFPLEdBQUc7QUFBQSxFQUMxRDtBQUNBLE1BQUksS0FBSyxNQUFPLE9BQU0sS0FBSyxVQUFVLEtBQUssS0FBSyxFQUFFO0FBQ2pELGFBQVcsY0FBYyxNQUFNLEtBQUssSUFBSTtBQUMxQztBQUVBLGVBQWUsZ0JBQStCO0FBQzVDLFFBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsY0FBWSxnQkFBZ0I7QUFDNUIsYUFBVyxLQUFLLE1BQU07QUFDcEIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVk7QUFDbkIsV0FBTyxjQUFjLElBQUksRUFBRSxNQUFNO0FBQ2pDLFVBQU0sUUFBUSxTQUFTLGNBQWMsTUFBTTtBQUMzQyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxjQUFjLEVBQUU7QUFDdEIsT0FBRyxPQUFPLFFBQVEsS0FBSztBQUN2QixnQkFBWSxPQUFPLEVBQUU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsS0FBSyxpQkFBaUIsVUFBVSxPQUFPLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLFFBQU0sTUFBTSxTQUFTLE1BQU0sS0FBSztBQUNoQyxRQUFNLFFBQVEsV0FBVyxNQUFNLEtBQUs7QUFDcEMsUUFBTSxPQUFPLFVBQVUsTUFBTSxLQUFLO0FBQ2xDLFFBQU0sU0FBUyxZQUFZLE1BQU0sS0FBSyxLQUFLO0FBQzNDLE1BQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU07QUFDM0IsY0FBVSxZQUFZLE9BQU8sMEJBQTBCO0FBQ3ZEO0FBQUEsRUFDRjtBQUNBLFlBQVUsWUFBWSxJQUFJLGNBQVM7QUFDbkMsUUFBTSxlQUFlLEVBQUUsS0FBSyxPQUFPLE1BQU0sUUFBUSxjQUFjLEtBQUssSUFBSSxFQUFFLENBQUM7QUFDM0UsWUFBVSxZQUFZLElBQUksaUJBQVk7QUFDdEMsUUFBTSxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUN4QyxRQUFNLEtBQUssRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3ZDLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsTUFBSSxLQUFLLFdBQVcsTUFBTTtBQUN4QixjQUFVLFlBQVksTUFBTSxpQkFBaUIsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUFBLEVBQ25FLFdBQVcsS0FBSyxXQUFXLGNBQWM7QUFDdkMsY0FBVSxZQUFZLE9BQU8sc0RBQWlEO0FBQUEsRUFDaEYsV0FBVyxLQUFLLFdBQVcsZ0JBQWdCO0FBQ3pDLGNBQVUsWUFBWSxRQUFRLDhEQUF5RDtBQUFBLEVBQ3pGLFdBQVcsS0FBSyxXQUFXLGlCQUFpQjtBQUMxQyxjQUFVLFlBQVksT0FBTywwQ0FBcUM7QUFBQSxFQUNwRSxPQUFPO0FBQ0wsY0FBVSxZQUFZLE9BQU8saUJBQWlCLEtBQUssTUFBTSxFQUFFO0FBQUEsRUFDN0Q7QUFDQSxRQUFNLGdCQUFnQjtBQUN0QixRQUFNLGNBQWM7QUFDcEIsUUFBTSxZQUFZO0FBQ3BCLENBQUM7QUFFRCxVQUFVLGlCQUFpQixTQUFTLE1BQU07QUFDeEMsTUFBSSxTQUFTLFNBQVMsWUFBWTtBQUNoQyxhQUFTLE9BQU87QUFDaEIsY0FBVSxjQUFjO0FBQUEsRUFDMUIsT0FBTztBQUNMLGFBQVMsT0FBTztBQUNoQixjQUFVLGNBQWM7QUFBQSxFQUMxQjtBQUNGLENBQUM7QUFFRCxXQUFXLGlCQUFpQixTQUFTLFlBQVk7QUFDL0MsYUFBVyxXQUFXO0FBQ3RCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3ZDLFVBQU0sY0FBYztBQUNwQixjQUFVLFlBQVksTUFBTSxxQkFBcUI7QUFBQSxFQUNuRCxTQUFTLEtBQUs7QUFDWixjQUFVLFlBQVksT0FBTyxtQkFBb0IsSUFBYyxPQUFPLEVBQUU7QUFBQSxFQUMxRSxVQUFFO0FBQ0EsZUFBVyxXQUFXO0FBQUEsRUFDeEI7QUFDRixDQUFDO0FBRUQsZUFBZSxjQUE2QjtBQUMxQyxRQUFNLENBQUMsVUFBVSxNQUFNLFVBQVUsVUFBVSxTQUFTLFFBQVEsSUFBSSxNQUFNLFFBQVEsSUFBSTtBQUFBLElBQ2hGLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxJQUNaLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxFQUNkLENBQUM7QUFDRCxRQUFNLGtCQUFrQixPQUFPO0FBQUEsSUFDN0IsT0FBTyxRQUFRLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUFBLE1BQ3RDO0FBQUEsTUFDQTtBQUFBLFFBQ0UsUUFBUSxFQUFFO0FBQUEsUUFDVixZQUFZLEVBQUU7QUFBQSxRQUNkLGlCQUFpQixFQUFFO0FBQUEsUUFDbkIsY0FBYyxPQUFPLEtBQUssRUFBRSxZQUFZLEVBQUU7QUFBQSxRQUMxQyxnQkFBZ0IsRUFBRSxtQkFBbUI7QUFBQSxRQUNyQyxnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLFlBQVksRUFBRTtBQUFBLE1BQ2hCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sT0FBTztBQUFBLElBQ1gsU0FBUyxRQUFRLFFBQVEsWUFBWSxFQUFFO0FBQUEsSUFDdkMsWUFBWSxVQUFVO0FBQUEsSUFDdEIsVUFBVTtBQUFBLE1BQ1IsT0FBTyxTQUFTO0FBQUEsTUFDaEIsTUFBTSxTQUFTO0FBQUEsTUFDZixRQUFRLFNBQVM7QUFBQSxNQUNqQixhQUFhLFNBQVM7QUFBQSxNQUN0QixjQUFjLFNBQVM7QUFBQSxNQUN2QixRQUFRLFNBQVMsSUFBSSxTQUFTO0FBQUEsTUFDOUIsV0FBVyxTQUFTLElBQUksVUFBVSxJQUFJLFNBQVMsSUFBSSxNQUFNLEVBQUUsSUFBSTtBQUFBLElBQ2pFO0FBQUEsSUFDQSxZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVk7QUFBQSxJQUNaLG9CQUFvQixTQUFTO0FBQUEsSUFDN0IsaUJBQWlCLFNBQVMsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUN2QztBQUNBLFVBQVEsUUFBUSxLQUFLLFVBQVUsTUFBTSxNQUFNLENBQUM7QUFDOUM7QUFFQSxZQUFZLGlCQUFpQixTQUFTLFlBQVk7QUFDaEQsUUFBTSxVQUFVLFVBQVUsVUFBVSxRQUFRLEtBQUs7QUFDakQsWUFBVSxZQUFZLE1BQU0sa0NBQWtDO0FBQ2hFLENBQUM7QUFFRCxnQkFBZ0IsaUJBQWlCLFNBQVMsWUFBWTtBQUNwRCxRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsUUFBTSxTQUFTO0FBQ2YsWUFBVSxZQUFZLFFBQVEsa0JBQWtCO0FBQ2hELFFBQU0sYUFBYTtBQUNuQixRQUFNLGNBQWM7QUFDcEIsUUFBTSxZQUFZO0FBQ3BCLENBQUM7QUFFRCxLQUFLLGFBQWE7QUFDbEIsS0FBSyxjQUFjO0FBQ25CLEtBQUssWUFBWTsiLAogICJuYW1lcyI6IFtdCn0K
