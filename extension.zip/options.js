// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function getCounters() {
  return getRaw("counters");
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getActivity() {
  return getRaw("activity");
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/options.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var form = $("settings-form");
var ownerInput = $("owner");
var repoInput = $("repo");
var branchInput = $("branch");
var patInput = $("pat");
var revealBtn = $("reveal-pat");
var saveStatus = $("save-status");
var connDetail = $("conn-detail");
var accountList = $("account-readonly");
var refreshBtn = $("refresh-accounts");
var diagBox = $("diagnostics");
var copyDiagBtn = $("copy-diagnostics");
var clearStorageBtn = $("clear-storage");
var diagStatus = $("diag-status");
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setStatus(el, kind, msg) {
  el.className = kind ? `status ${kind}` : "status";
  el.textContent = msg;
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
async function loadSettings() {
  const s = await getSettings();
  ownerInput.value = s.owner || DEFAULT_SETTINGS.owner;
  repoInput.value = s.repo || DEFAULT_SETTINGS.repo;
  branchInput.value = s.branch || DEFAULT_SETTINGS.branch;
  if (s.pat) {
    patInput.value = s.pat;
    patInput.placeholder = `\u2026${s.pat.slice(-4)}`;
  }
  await paintConnDetail();
}
async function paintConnDetail() {
  const conn = await getConnection();
  const s = await getSettings();
  const lines = [];
  lines.push(`Status: ${conn.status}`);
  if (conn.login) lines.push(`Logged in as: @${conn.login}`);
  lines.push(`Repository: ${s.owner || "?"}/${s.repo || "?"}@${s.branch || "?"}`);
  if (conn.checkedAt) lines.push(`Last checked: ${conn.checkedAt}`);
  if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
    const resetIso = new Date(conn.rateLimitResetAt * 1e3).toISOString();
    const deltaSec = conn.rateLimitResetAt - Math.floor(Date.now() / 1e3);
    const inLabel = deltaSec <= 0 ? "momentarily" : deltaSec < 60 ? `in ${deltaSec}s` : deltaSec < 3600 ? `in ${Math.round(deltaSec / 60)}m` : `in ${Math.round(deltaSec / 3600)}h`;
    lines.push(`Rate limit resets: ${resetIso} (${inLabel})`);
  }
  if (conn.error) lines.push(`Error: ${conn.error}`);
  connDetail.textContent = lines.join("\n");
}
async function paintAccounts() {
  const list = await getAccounts();
  accountList.replaceChildren();
  for (const a of list) {
    const li = document.createElement("li");
    const handle = document.createElement("span");
    handle.className = "handle";
    handle.textContent = `@${a.handle}`;
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = a.label;
    li.append(handle, label);
    accountList.append(li);
  }
}
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const pat = patInput.value.trim();
  const owner = ownerInput.value.trim();
  const repo = repoInput.value.trim();
  const branch = branchInput.value.trim() || "main";
  if (!pat || !owner || !repo) {
    setStatus(saveStatus, "err", "All fields are required.");
    return;
  }
  setStatus(saveStatus, "", "Saving\u2026");
  await updateSettings({ pat, owner, repo, branch, configuredAt: Date.now() });
  setStatus(saveStatus, "", "Verifying\u2026");
  await send({ type: "verify-connection" });
  await send({ type: "refresh-accounts" });
  const conn = await getConnection();
  if (conn.status === "ok") {
    setStatus(saveStatus, "ok", `Connected as @${conn.login ?? "?"}.`);
  } else if (conn.status === "auth-error") {
    setStatus(
      saveStatus,
      "err",
      isWriteAuthError(conn.error) ? "PAT can read this repo but cannot write. Set Contents: Read & Write." : "Auth failed - check the PAT and its repo scope."
    );
  } else if (conn.status === "rate-limited") {
    setStatus(saveStatus, "warn", "Rate-limited \u2014 token is valid but GitHub is throttling.");
  } else if (conn.status === "network-error") {
    setStatus(saveStatus, "err", "Network error \u2014 check connectivity.");
  } else {
    setStatus(saveStatus, "err", `Verification: ${conn.status}`);
  }
  await paintConnDetail();
  await paintAccounts();
  await refreshDiag();
});
revealBtn.addEventListener("click", () => {
  if (patInput.type === "password") {
    patInput.type = "text";
    revealBtn.textContent = "Hide";
  } else {
    patInput.type = "password";
    revealBtn.textContent = "Show";
  }
});
refreshBtn.addEventListener("click", async () => {
  refreshBtn.disabled = true;
  try {
    await send({ type: "refresh-accounts" });
    await paintAccounts();
    setStatus(diagStatus, "ok", "Accounts refreshed.");
  } catch (err) {
    setStatus(diagStatus, "err", `Refresh failed: ${err.message}`);
  } finally {
    refreshBtn.disabled = false;
  }
});
async function refreshDiag() {
  const [settings, conn, accounts, counters, buffers, activity, archiveSnapshot] = await Promise.all([
    getSettings(),
    getConnection(),
    getAccounts(),
    getCounters(),
    getRunBuffers(),
    getActivity(),
    getArchiveSnapshot()
  ]);
  const redactedBuffers = Object.fromEntries(
    Object.entries(buffers).map(([k, b]) => [
      k,
      {
        run_id: b.run_id,
        started_at: b.started_at,
        last_capture_at: b.last_capture_at,
        tweets_count: Object.keys(b.tweets_by_id).length,
        observed_count: b.tweet_ids_observed.length,
        endpoints_seen: b.endpoints_seen,
        source_url: b.source_url
      }
    ])
  );
  const dump = {
    version: browser.runtime.getManifest().version,
    user_agent: navigator.userAgent,
    settings: {
      owner: settings.owner,
      repo: settings.repo,
      branch: settings.branch,
      autoCapture: settings.autoCapture,
      updateExisting: settings.updateExisting,
      configuredAt: settings.configuredAt,
      patSet: settings.pat.length > 0,
      patSuffix: settings.pat.length >= 4 ? settings.pat.slice(-4) : ""
    },
    connection: conn,
    accounts,
    counters,
    archiveSnapshot: archiveSnapshot ? {
      generated_at: archiveSnapshot.generated_at,
      fetched_at: archiveSnapshot.fetched_at,
      accounts: Object.keys(archiveSnapshot.accounts).length
    } : null,
    runBuffers: redactedBuffers,
    activity_tail_size: activity.length,
    activity_recent: activity.slice(0, 30)
  };
  diagBox.value = JSON.stringify(dump, null, 2);
}
copyDiagBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(diagBox.value);
  setStatus(diagStatus, "ok", "Copied diagnostics to clipboard.");
});
clearStorageBtn.addEventListener("click", async () => {
  const ok = window.confirm(
    "Clear extension storage? This erases your PAT, settings, counters, buffered captures, and activity tail. There is no undo."
  );
  if (!ok) return;
  await clearAll();
  setStatus(diagStatus, "warn", "Storage cleared.");
  await loadSettings();
  await paintAccounts();
  await refreshDiag();
});
void loadSettings();
void paintAccounts();
void refreshDiag();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9vcHRpb25zLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgdHlwZSB7IEFjY291bnRDb25maWcsIFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBTZXR0aW5ncyA9IHtcbiAgcGF0OiAnJyxcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcbiAgcmVwbzogJ3gnLFxuICAvLyBUaGUgcmVwbydzIGN1cnJlbnQgZGVmYXVsdCBicmFuY2ggaXMgXCJtYXN0ZXJcIi4gSWYgeW91IGZvcmsgb3IgcmVuYW1lXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXG4gIGJyYW5jaDogJ21hc3RlcicsXG4gIGVuYWJsZWQ6IHRydWUsXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxuICBjb25maWd1cmVkQXQ6IG51bGwsXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcbiAgdXBkYXRlRXhpc3Rpbmc6IHRydWUsXG59O1xuXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xuXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cbiAqXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXG4gKiBHaXRIdWIgUEFUIGluIHBsYWludGV4dC4gQSBkZXRlcm1pbmVkIGF0dGFja2VyIHdpdGggdGhlIGV4dGVuc2lvbidzIHNvdXJjZVxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxuICogc3RyaW5nIHNpdHRpbmcgbmV4dCB0byBpdHMga2V5IG5hbWUgaW4gZXh0ZW5zaW9uIHN0b3JhZ2UuXG4gKlxuICogU2NoZW1lOlxuICogICAtIE9uIGZpcnN0IGVuY3J5cHRpb24gd2UgZ2VuZXJhdGUgYSAzMi1ieXRlIHNhbHQgYW5kIHBlcnNpc3QgaXQgaW5cbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cbiAqICAgICB8fCBcImltbS1hcmNoaXZlLXBhdC12MVwiYC4gVGhlIHNhbHQgYmVpbmcgcGVyLWluc3RhbGwgbWVhbnMgdHdvIGNvcGllc1xuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxuICogICAtIFBsYWludGV4dCBpcyBlbmNyeXB0ZWQgd2l0aCBhIGZyZXNoIDEyLWJ5dGUgSVYuIFRoZSBlbnZlbG9wZSBmb3JtYXQgaXNcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXG4gKlxuICogQmFja3dhcmRzIGNvbXBhdGliaWxpdHk6IGFuIHVucHJlZml4ZWQgdmFsdWUgaXMgdHJlYXRlZCBhcyBsZWdhY3lcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cbiAqL1xuXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xuXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcbiAgbGV0IHMgPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIGJ1ZikgcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShzKTtcbn1cblxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcbiAgY29uc3QgYmluID0gYXRvYihzKTtcbiAgY29uc3Qgb3V0ID0gbmV3IFVpbnQ4QXJyYXkoYmluLmxlbmd0aCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChTQUxUX1NUT1JBR0VfS0VZKTtcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4geyBzYWx0QjY0OiB2LCBzYWx0OiBmcm9tQmFzZTY0KHYpIH07XG4gIH1cbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcbiAgY29uc3Qgc2FsdEI2NCA9IHRvQmFzZTY0KHNhbHQpO1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICBjb25zdCB7IHNhbHRCNjQsIHNhbHQgfSA9IGF3YWl0IGxvYWRPckNyZWF0ZVNhbHQoKTtcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcbiAgfVxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXG4gICk7XG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcbiAgY29tYmluZWQuc2V0KHNhbHQsIHNlZWQubGVuZ3RoKTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcbiAgICAnZW5jcnlwdCcsXG4gICAgJ2RlY3J5cHQnLFxuICBdKTtcbiAgZGVyaXZlZEtleUNhY2hlID0ga2V5O1xuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcbiAgcmV0dXJuIGtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdi5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbmNyeXB0UGF0KHBsYWludGV4dDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gIGNvbnN0IGl2ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMikpO1xuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcbiAgICBrZXksXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcbiAgKTtcbiAgcmV0dXJuIGAke0VOVkVMT1BFX1BSRUZJWH0ke3RvQmFzZTY0KGl2KX06JHt0b0Jhc2U2NChuZXcgVWludDhBcnJheShjdCkpfWA7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWNyeXB0UGF0KGVudmVsb3BlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXG4gIC8vIHJlLWVuY3J5cHRzIGl0IHZpYSB0aGUgc3RvcmFnZSBsYXllci5cbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xuICBpZiAocGFydHMubGVuZ3RoICE9PSAyKSByZXR1cm4gJyc7XG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XG4gIHRyeSB7XG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcbiAgICBjb25zdCBjdCA9IGZyb21CYXNlNjQoY3RCNjQpO1xuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcbiAgICAgIGtleSxcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShwdCk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnJztcbiAgfVxufVxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB7IGRlY3J5cHRQYXQsIGVuY3J5cHRQYXQsIGlzRW5jcnlwdGVkUGF0IH0gZnJvbSAnLi9jcnlwdG8uanMnO1xuaW1wb3J0IHR5cGUge1xuICBBY2NvdW50Q29uZmlnLFxuICBBY2NvdW50Q291bnRlcixcbiAgQXJjaGl2ZVNuYXBzaG90LFxuICBDYW5vbmljYWxUd2VldCxcbiAgQ29ubmVjdGlvblN0YXRlLFxuICBMb2dFdmVudCxcbiAgU2V0dGluZ3MsXG4gIFVuYXZhaWxhYmxlVHdlZXQsXG59IGZyb20gJy4vdHlwZXMuanMnO1xuXG4vKipcbiAqIEJ1ZmZlcmVkIHR3ZWV0cyBmb3IgYSBnaXZlbiBhY2NvdW50LCBhd2FpdGluZyBjb21taXQuIEEgXCJydW5cIiBpcyBvbmUgZW50cnlcbiAqIGluIHRoaXMgbWFwOyBmbHVzaGluZyBjbGVhcnMgdGhlIGVudHJ5LiBXZSBzdG9yZSBhcyBSZWNvcmQgc28gdGhlIHN0cnVjdHVyZVxuICogc3Vydml2ZXMgSlNPTiBzZXJpYWxpemF0aW9uIHRocm91Z2ggYnJvd3Nlci5zdG9yYWdlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFJ1bkJ1ZmZlciB7XG4gIHJ1bl9pZDogc3RyaW5nO1xuICBhY2NvdW50X2hhbmRsZTogc3RyaW5nO1xuICBzdGFydGVkX2F0OiBzdHJpbmc7XG4gIGxhc3RfY2FwdHVyZV9hdDogc3RyaW5nO1xuICB0d2VldHNfYnlfaWQ6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PjtcbiAgdW5hdmFpbGFibGVfYnlfaWQ/OiBSZWNvcmQ8c3RyaW5nLCBVbmF2YWlsYWJsZVR3ZWV0PjtcbiAgdHdlZXRfaWRzX29ic2VydmVkOiBzdHJpbmdbXTtcbiAgZW5kcG9pbnRzX3NlZW46IHN0cmluZ1tdO1xuICBzb3VyY2VfdXJsOiBzdHJpbmcgfCBudWxsO1xufVxuXG4vKiogUGVyLXR3ZWV0IGNvbW1pdHRlZC1zdGF0ZSBpbmRleCwga2V5ZWQgYnkgaGFuZGxlIHRoZW4gdHdlZXRfaWQuXG4gKiBVc2VkIHRvIHNraXAgcmUtY2FwdHVyaW5nIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IHB1c2hlZCB3aXRoIGlkZW50aWNhbFxuICogZW5nYWdlbWVudCBjb3VudHMgXHUyMDE0IGF2b2lkcyBnZW5lcmF0aW5nIG9uZSBuZXcgcmF3LyogZmlsZSBldmVyeSBicm93c2UuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdHRlZEVudHJ5IHtcbiAgdHM6IHN0cmluZzsgLy8gSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBjb21taXRcbiAgc2lnOiBzdHJpbmc7IC8vIGVuZ2FnZW1lbnQgc2lnbmF0dXJlOiBcImxpa2V8cnR8cmVwbHl8cXVvdGVcIlxufVxuXG4vKiogUHJvZ3Jlc3MgKyBpbmZsaWdodCB0cmFja2luZyBmb3IgYSBxdWV1ZS1kcml2ZW4gbG9vcCAocmVmZXRjaCAvIG1lZGlhLWNyYXdsKS5cbiAqIFRoZSBsb29wIHBlcnNpc3RzIHRoaXMgc28gYSBTVyBldmljdGlvbiBpbiB0aGUgbWlkZGxlIG9mIGEgcnVuIHByZXNlcnZlc1xuICogXCJYIG9mIFkgcHJvY2Vzc2VkXCIgXHUyMDE0IGFuZCB0aGUgd2FpdC1mb3ItaW5nZXN0IGd1YXJkIGtub3dzIHdoYXQgdG8gZXhwZWN0LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIExvb3BTZXNzaW9uIHtcbiAgLyoqIEluaXRpYWwgcXVldWUgc2l6ZSB3aGVuIHRoZSB1c2VyIGNsaWNrZWQgXCJTdGFydFwiLiAqL1xuICB0b3RhbEF0U3RhcnQ6IG51bWJlcjtcbiAgLyoqIFR3ZWV0cyBwcm9jZXNzZWQgKGluZ2VzdGVkIE9SIGRyb3BwZWQgYWZ0ZXIgcmV0cmllcykgc28gZmFyLiAqL1xuICBwcm9jZXNzZWQ6IG51bWJlcjtcbiAgLyoqIElTTyBvZiB3aGVuIHRoaXMgc2Vzc2lvbiBzdGFydGVkLiAqL1xuICBzdGFydGVkQXQ6IHN0cmluZztcbiAgLyoqIFR3ZWV0IGN1cnJlbnRseSBpbmZsaWdodCBcdTIwMTQgd2UgbmF2aWdhdGVkIHRvIGl0IGFuZCBhcmUgd2FpdGluZyBmb3IgdGhlXG4gICAqIHBhZ2UtaG9vayB0byBjYXB0dXJlIHRoZSByZXNwb25zZSBiZWZvcmUgYWR2YW5jaW5nLiBudWxsIGJldHdlZW4gdGlja3NcbiAgICogKGFuZCBvbmNlIGFuIGluZ2VzdCBoYXMgYmVlbiBvYnNlcnZlZCkuICovXG4gIGluZmxpZ2h0OiB7IHR3ZWV0SWQ6IHN0cmluZzsgbmF2aWdhdGVkQXQ6IHN0cmluZyB9IHwgbnVsbDtcbn1cblxuLyoqIEF1dG8tc2Nyb2xsIHNlc3Npb246IGNvdW50cyBvZiB0aWNrcyBhbmQgdHdlZXRzIGluZ2VzdGVkIHNpbmNlIHRoZSB1c2VyXG4gKiBjbGlja2VkIFN0YXJ0LiBQZXJzaXN0ZWQgc28gU1cgZXZpY3Rpb24gZHVyaW5nIGEgcnVuIGtlZXBzIHByb2dyZXNzLiAqL1xuZXhwb3J0IGludGVyZmFjZSBBdXRvU2Nyb2xsU2Vzc2lvbiB7XG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xuICBzY3JvbGxDb3VudDogbnVtYmVyO1xuICBpbmdlc3RlZENvdW50OiBudW1iZXI7XG4gIGluZ2VzdGVkTmV3Q291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWRFeGlzdGluZ0NvdW50OiBudW1iZXI7XG4gIHNraXBwZWRPbGRDb3VudDogbnVtYmVyO1xuICBleHBhbmRlZENvdW50OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xuICBzZXR0aW5nczogU2V0dGluZ3M7XG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XG4gIC8qKiBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IHN1Y2Nlc3NmdWwgYWNjb3VudHMueWFtbCBmZXRjaCBmcm9tIHRoZSByZXBvLlxuICAgKiBVc2VkIGJ5IGByZWZyZXNoQWNjb3VudHNMaXN0YCB0byBza2lwIHJlLWZldGNoaW5nIG9uIGV2ZXJ5IFNXIHdha2UgXHUyMDE0IHRoZVxuICAgKiBmaWxlIGNoYW5nZXMgcmFyZWx5IGFuZCBhbiBhdXRoZW50aWNhdGVkIHJhdyBmZXRjaCBldmVyeSB3YWtlIGFkZHMgdXAuICovXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IHN0cmluZyB8IG51bGw7XG4gIGFyY2hpdmVTbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbDtcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvblN0YXRlO1xuICBjb3VudGVyczogUmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+O1xuICBydW5CdWZmZXJzOiBSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+O1xuICBhY3Rpdml0eTogTG9nRXZlbnRbXTtcbiAgY29tbWl0dGVkSW5kZXg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj47XG4gIC8qKiBUd2VldHMgdGhlIG5vcm1hbGl6ZXIgZmxhZ2dlZCBhcyB0cnVuY2F0ZWQgYW5kIHRoYXQgd2UgaGF2ZW4ndCBzZWVuIGFcbiAgICogZnVsbC10ZXh0IHZlcnNpb24gb2YgeWV0LiBLZXllZCBieSBoYW5kbGUgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gKi9cbiAgcmVmZXRjaFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XG4gIC8qKiBUd2VldCBJRHMgc2VlbiB2aWEgTWVkaWEtdGFiIC8gcGFydGlhbCBjYXB0dXJlcyB0aGF0IGNvdWxkbid0IGJlXG4gICAqIG5vcm1hbGl6ZWQgaW50byBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBLZXllZCBieSBoaW50LWhhbmRsZSAob3JcbiAgICogXCJfdW5rbm93blwiKSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiBUaGUgdXNlciBjYW4gZHJpdmUgYSBjcmF3bCB0aGF0XG4gICAqIG9wZW5zIGVhY2ggZGV0YWlsIHBhZ2UgdG8gY2FwdHVyZSB0aGUgcmVhbCB0aGluZy4gKi9cbiAgbWVkaWFDcmF3bFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XG4gIHJlZmV0Y2hTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XG4gIG1lZGlhQ3Jhd2xTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw7XG59XG5cbmNvbnN0IERFRkFVTFRfQ09OTkVDVElPTjogQ29ubmVjdGlvblN0YXRlID0ge1xuICBzdGF0dXM6ICd1bmtub3duJyxcbiAgbG9naW46IG51bGwsXG4gIGNoZWNrZWRBdDogbnVsbCxcbiAgZXJyb3I6IG51bGwsXG4gIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG59O1xuXG5jb25zdCBERUZBVUxUUzogU3RvcmFnZVNoYXBlID0ge1xuICBzZXR0aW5nczogeyAuLi5ERUZBVUxUX1NFVFRJTkdTIH0sXG4gIGFjY291bnRzOiBbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdLFxuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBudWxsLFxuICBhcmNoaXZlU25hcHNob3Q6IG51bGwsXG4gIGNvbm5lY3Rpb246IHsgLi4uREVGQVVMVF9DT05ORUNUSU9OIH0sXG4gIGNvdW50ZXJzOiB7fSxcbiAgcnVuQnVmZmVyczoge30sXG4gIGFjdGl2aXR5OiBbXSxcbiAgY29tbWl0dGVkSW5kZXg6IHt9LFxuICByZWZldGNoUXVldWU6IHt9LFxuICBtZWRpYUNyYXdsUXVldWU6IHt9LFxuICByZWZldGNoU2Vzc2lvbjogbnVsbCxcbiAgbWVkaWFDcmF3bFNlc3Npb246IG51bGwsXG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBudWxsLFxufTtcblxuYXN5bmMgZnVuY3Rpb24gZ2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSyk6IFByb21pc2U8U3RvcmFnZVNoYXBlW0tdPiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoa2V5KTtcbiAgY29uc3QgdmFsdWUgPSByZXN1bHRba2V5XTtcbiAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gc3RydWN0dXJlZENsb25lKERFRkFVTFRTW2tleV0pO1xuICB9XG4gIHJldHVybiB2YWx1ZSBhcyBTdG9yYWdlU2hhcGVbS107XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEssIHZhbHVlOiBTdG9yYWdlU2hhcGVbS10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtrZXldOiB2YWx1ZSB9KTtcbn1cblxuLy8gLS0tIFNldHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNldHRpbmdzKCk6IFByb21pc2U8U2V0dGluZ3M+IHtcbiAgLy8gQmFja2ZpbGwgYW55IGtleXMgdGhlIHVzZXIncyBzdG9yZWQgc2V0dGluZ3MgcHJlZGF0ZSBcdTIwMTQgcmVhZGVycyBjYW4gcmVseVxuICAvLyBvbiBldmVyeSBTZXR0aW5ncyBmaWVsZCBiZWluZyBwcmVzZW50IHJhdGhlciB0aGFuIGA/PyBkZWZhdWx0aW5nYCBhdFxuICAvLyBldmVyeSBjYWxsc2l0ZS4gVGhlIFBBVCBpcyBzdG9yZWQgZW5jcnlwdGVkLWF0LXJlc3QgYXMgb2YgdjAuMi4wOyB3ZVxuICAvLyBkZWNyeXB0IHRyYW5zcGFyZW50bHkgc28gY2FsbGVycyBjb250aW51ZSB0byBzZWUgcGxhaW50ZXh0LlxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBnZXRSYXcoJ3NldHRpbmdzJyk7XG4gIGNvbnN0IG1lcmdlZCA9IHsgLi4uREVGQVVMVF9TRVRUSU5HUywgLi4uc3RvcmVkIH07XG4gIGlmIChtZXJnZWQucGF0ICYmIGlzRW5jcnlwdGVkUGF0KG1lcmdlZC5wYXQpKSB7XG4gICAgdHJ5IHtcbiAgICAgIG1lcmdlZC5wYXQgPSBhd2FpdCBkZWNyeXB0UGF0KG1lcmdlZC5wYXQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgbWVyZ2VkLnBhdCA9ICcnO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbWVyZ2VkO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIEVuY3J5cHQgdGhlIFBBVCBiZWZvcmUgcGVyc2lzdGluZzsgbGVnYWN5IHBsYWludGV4dCBQQVRzIGdldCB1cGdyYWRlZFxuICAvLyBvbiB0aGUgbmV4dCBzYXZlLlxuICBjb25zdCB0b1dyaXRlOiBTZXR0aW5ncyA9IHsgLi4ucyB9O1xuICBpZiAodG9Xcml0ZS5wYXQgJiYgIWlzRW5jcnlwdGVkUGF0KHRvV3JpdGUucGF0KSkge1xuICAgIHRvV3JpdGUucGF0ID0gYXdhaXQgZW5jcnlwdFBhdCh0b1dyaXRlLnBhdCk7XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdzZXR0aW5ncycsIHRvV3JpdGUpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHBhdGNoOiBQYXJ0aWFsPFNldHRpbmdzPik6IFByb21pc2U8U2V0dGluZ3M+IHtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgbmV4dCA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xuICBhd2FpdCBzZXRTZXR0aW5ncyhuZXh0KTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbi8vIC0tLSBBY2NvdW50cyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50cygpOiBQcm9taXNlPEFjY291bnRDb25maWdbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50cycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzKGE6IEFjY291bnRDb25maWdbXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzJywgYSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzUmVmcmVzaGVkQXQoaXNvOiBzdHJpbmcgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcsIGlzbyk7XG59XG5cbi8vIC0tLSBBcmNoaXZlIHNuYXBzaG90IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFyY2hpdmVTbmFwc2hvdCgpOiBQcm9taXNlPEFyY2hpdmVTbmFwc2hvdCB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYXJjaGl2ZVNuYXBzaG90Jyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBcmNoaXZlU25hcHNob3Qoc25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhcmNoaXZlU25hcHNob3QnLCBzbmFwc2hvdCk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHN0YXRlIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb24oKTogUHJvbWlzZTxDb25uZWN0aW9uU3RhdGU+IHtcbiAgY29uc3QgYyA9IGF3YWl0IGdldFJhdygnY29ubmVjdGlvbicpO1xuICAvLyBCYWNrZmlsbCBmaWVsZHMgYWRkZWQgYWZ0ZXIgdGhlIHVzZXIncyBzdG9yYWdlIHdhcyB3cml0dGVuLlxuICBjb25zdCBvdXQ6IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgICAuLi5jLFxuICAgIGRlZmF1bHRCcmFuY2g6IGMuZGVmYXVsdEJyYW5jaCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuZGVmYXVsdEJyYW5jaCxcbiAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOlxuICAgICAgYy5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxuICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGMucmF0ZUxpbWl0UmVzZXRBdCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMucmF0ZUxpbWl0UmVzZXRBdCxcbiAgfTtcbiAgcmV0dXJuIG91dDtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb25uZWN0aW9uKGM6IENvbm5lY3Rpb25TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2Nvbm5lY3Rpb24nLCBjKTtcbn1cblxuLy8gLS0tIENvdW50ZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZnVuY3Rpb24gdG9kYXlJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3VudGVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb3VudGVycycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGJ1bXBDb3VudGVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgcGF0Y2g6IFBhcnRpYWw8QWNjb3VudENvdW50ZXI+XG4pOiBQcm9taXNlPEFjY291bnRDb3VudGVyPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGNvbnN0IGN1ciA9IGFsbFtoYW5kbGVdID8/IHtcbiAgICB0b2RheUNvdW50OiAwLFxuICAgIHRvZGF5RGF0ZTogdG9kYXlJU08oKSxcbiAgICBsYXN0Q2FwdHVyZUF0OiBudWxsLFxuICAgIHRvdGFsQ29tbWl0dGVkOiAwLFxuICAgIGJ1ZmZlcmVkQ291bnQ6IDAsXG4gIH07XG4gIGlmIChjdXIudG9kYXlEYXRlICE9PSB0b2RheUlTTygpKSB7XG4gICAgY3VyLnRvZGF5RGF0ZSA9IHRvZGF5SVNPKCk7XG4gICAgY3VyLnRvZGF5Q291bnQgPSAwO1xuICB9XG4gIGNvbnN0IG5leHQ6IEFjY291bnRDb3VudGVyID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGFsbFtoYW5kbGVdID0gbmV4dDtcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGFsbCk7XG4gIHJldHVybiBuZXh0O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QnVmZmVyZWRDb3VudChoYW5kbGU6IHN0cmluZywgY291bnQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHsgYnVmZmVyZWRDb3VudDogY291bnQgfSk7XG59XG5cbi8vIC0tLSBSdW4gYnVmZmVycyAodGhlIHBlbmRpbmcgY2FwdHVyZXMgYXdhaXRpbmcgY29tbWl0KSAtLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3J1bkJ1ZmZlcnMnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8UnVuQnVmZmVyIHwgbnVsbD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIHJldHVybiBhbGxbaGFuZGxlXSA/PyBudWxsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nLCBidWY6IFJ1bkJ1ZmZlcik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGFsbFtoYW5kbGVdID0gYnVmO1xuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBkZWxldGUgYWxsW2hhbmRsZV07XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbi8vIC0tLSBBY3Rpdml0eSB0YWlsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY3Rpdml0eSgpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcbiAgcmV0dXJuIGdldFJhdygnYWN0aXZpdHknKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGVuZEFjdGl2aXR5KGV2OiBMb2dFdmVudCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRBY3Rpdml0eSgpO1xuICBjdXIudW5zaGlmdChldik7XG4gIGlmIChjdXIubGVuZ3RoID4gQUNUSVZJVFlfVEFJTF9NQVgpIGN1ci5sZW5ndGggPSBBQ1RJVklUWV9UQUlMX01BWDtcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIGN1cik7XG4gIHJldHVybiBjdXI7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgW10pO1xufVxuXG4vLyAtLS0gQ29tbWl0dGVkLXR3ZWV0cyBkZWR1cCBpbmRleCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb21taXR0ZWRJbmRleCgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj4+IHtcbiAgcmV0dXJuIGdldFJhdygnY29tbWl0dGVkSW5kZXgnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbW1pdHRlZEluZGV4KFxuICBpZHg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj5cbik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2NvbW1pdHRlZEluZGV4JywgaWR4KTtcbn1cblxuLyoqIENvbXB1dGUgdGhlIGVuZ2FnZW1lbnQgc2lnbmF0dXJlIHdlIHVzZSB0byBkZWNpZGUgd2hldGhlciBhIHJlLWNhcHR1cmVkXG4gKiB0d2VldCBpcyBcIm1hdGVyaWFsbHkgZGlmZmVyZW50XCIgZnJvbSB3aGF0IHdlIGxhc3QgY29tbWl0dGVkLiBXZSBvbWl0XG4gKiB2aWV3X2NvdW50IGJlY2F1c2UgaXQgdGlja3MgdXAgZnJlcXVlbnRseSBvbiBhY3RpdmUgdHdlZXRzIGFuZCB3b3VsZFxuICogZGVmZWF0IHRoZSBkZWR1cC4gTGlrZXMgLyBSVHMgLyByZXBsaWVzIC8gcXVvdGVzIGNoYW5nZSByYXJlbHkgZW5vdWdoIHRoYXRcbiAqIGVhY2ggY2hhbmdlIGlzIHdvcnRoIGEgcmUtY29tbWl0IChhbmQgYW4gZW5nYWdlbWVudF9oaXN0b3J5IHNuYXBzaG90KS5cbiAqIGBpc190cnVuY2F0ZWRgIGlzIGZvbGRlZCBpbiBzbyBhIHJlZmV0Y2ggdGhhdCBzd2FwcyB0aGUgMjgwLWNoYXIgaGVhZCBmb3JcbiAqIHRoZSBmdWxsIGBub3RlX3R3ZWV0YCBib2R5IGJ5cGFzc2VzIHRoZSBkZWR1cCBldmVuIHdoZW4gZW5nYWdlbWVudCBjb3VudHNcbiAqIGhhdmVuJ3QgbW92ZWQgXHUyMDE0IG90aGVyd2lzZSB0aGUgbmV3IGJvZHkgd291bGQgYmUgc2lsZW50bHkgZHJvcHBlZC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbmdhZ2VtZW50U2lnKFxuICBsaWtlczogbnVtYmVyLFxuICByZXR3ZWV0czogbnVtYmVyLFxuICByZXBsaWVzOiBudW1iZXIsXG4gIHF1b3RlczogbnVtYmVyLFxuICBpc1RydW5jYXRlZDogYm9vbGVhbiA9IGZhbHNlXG4pOiBzdHJpbmcge1xuICByZXR1cm4gYCR7bGlrZXN9fCR7cmV0d2VldHN9fCR7cmVwbGllc318JHtxdW90ZXN9fCR7aXNUcnVuY2F0ZWQgPyAndCcgOiAnZid9YDtcbn1cblxuLyoqIERyb3AgZW50cmllcyBvbGRlciB0aGFuIGBtYXhBZ2VNc2AuIFJldHVybnMgdGhlIG51bWJlciBwcnVuZWQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJ1bmVDb21taXR0ZWRJbmRleChtYXhBZ2VNczogbnVtYmVyKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgY29uc3QgY3V0b2ZmID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIG1heEFnZU1zKS50b0lTT1N0cmluZygpO1xuICBsZXQgcHJ1bmVkID0gMDtcbiAgZm9yIChjb25zdCBoYW5kbGUgb2YgT2JqZWN0LmtleXMoaWR4KSkge1xuICAgIGNvbnN0IGlubmVyID0gaWR4W2hhbmRsZV07XG4gICAgaWYgKCFpbm5lcikgY29udGludWU7XG4gICAgZm9yIChjb25zdCB0aWQgb2YgT2JqZWN0LmtleXMoaW5uZXIpKSB7XG4gICAgICBjb25zdCBlID0gaW5uZXJbdGlkXTtcbiAgICAgIGlmIChlICYmIGUudHMgPCBjdXRvZmYpIHtcbiAgICAgICAgZGVsZXRlIGlubmVyW3RpZF07XG4gICAgICAgIHBydW5lZCArPSAxO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoT2JqZWN0LmtleXMoaW5uZXIpLmxlbmd0aCA9PT0gMCkgZGVsZXRlIGlkeFtoYW5kbGVdO1xuICB9XG4gIGlmIChwcnVuZWQgPiAwKSBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xuICByZXR1cm4gcHJ1bmVkO1xufVxuXG4vLyAtLS0gUmVmZXRjaCBxdWV1ZSAodHdlZXRzIG5lZWRpbmcgZnVsbC10ZXh0IHJlY2FwdHVyZSkgLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hRdWV1ZSgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoUXVldWUnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlZmV0Y2hRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgbGV0IHRvdGFsID0gMDtcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcbiAgcmV0dXJuIHRvdGFsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXSA/PyBbXTtcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcbiAgICBpZHMucHVzaCh0d2VldElkKTtcbiAgICBxW2hhbmRsZV0gPSBpZHM7XG4gICAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXTtcbiAgaWYgKCFpZHMpIHJldHVybjtcbiAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtoYW5kbGVdO1xuICBlbHNlIHFbaGFuZGxlXSA9IGZpbHRlcmVkO1xuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dFJlZmV0Y2hUYXJnZXQoKTogUHJvbWlzZTx7XG4gIGhhbmRsZTogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgaGFuZGxlLCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8vIC0tLSBNZWRpYS1jcmF3bCBxdWV1ZSAocGFydGlhbCBjYXB0dXJlcyBhd2FpdGluZyBkZXRhaWwtcGFnZSBmZXRjaCkgLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlTWVkaWFDcmF3bChoaW50SGFuZGxlOiBzdHJpbmcgfCBudWxsLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBjb25zdCBidWNrZXQgPSBoaW50SGFuZGxlID8/ICdfdW5rbm93bic7XG4gIGNvbnN0IGlkcyA9IHFbYnVja2V0XSA/PyBbXTtcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcbiAgICBpZHMucHVzaCh0d2VldElkKTtcbiAgICBxW2J1Y2tldF0gPSBpZHM7XG4gICAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZU1lZGlhQ3Jhd2wodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgZm9yIChjb25zdCBidWNrZXQgb2YgT2JqZWN0LmtleXMocSkpIHtcbiAgICBjb25zdCBpZHMgPSBxW2J1Y2tldF07XG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcbiAgICBpZiAoZmlsdGVyZWQubGVuZ3RoICE9PSBpZHMubGVuZ3RoKSB7XG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2J1Y2tldF07XG4gICAgICBlbHNlIHFbYnVja2V0XSA9IGZpbHRlcmVkO1xuICAgIH1cbiAgfVxuICBpZiAoY2hhbmdlZCkgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRNZWRpYUNyYXdsVGFyZ2V0KCk6IFByb21pc2U8e1xuICBidWNrZXQ6IHN0cmluZztcbiAgdHdlZXRJZDogc3RyaW5nO1xufSB8IG51bGw+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBmb3IgKGNvbnN0IFtidWNrZXQsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGJ1Y2tldCwgdHdlZXRJZDogaWRzWzBdISB9O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vKiogSGFzIHRoaXMgdHdlZXQgaWQgYWxyZWFkeSBiZWVuIGNvbW1pdHRlZCAoYW55IGhhbmRsZSk/IFVzZWQgdG8gc2tpcFxuICogZW5xdWV1ZWluZyBtZWRpYS1jcmF3bCB0YXJnZXRzIHdlJ3ZlIGFscmVhZHkgYXJjaGl2ZWQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNDb21taXR0ZWQodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGZvciAoY29uc3QgaW5uZXIgb2YgT2JqZWN0LnZhbHVlcyhpZHgpKSB7XG4gICAgaWYgKGlubmVyICYmIHR3ZWV0SWQgaW4gaW5uZXIpIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuLy8gLS0tIExvb3Agc2Vzc2lvbiBzdGF0ZSAocHJvZ3Jlc3MgKyBpbmZsaWdodCBnYXRpbmcpIC0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSZWZldGNoU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nLCBzKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpOiBQcm9taXNlPEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEF1dG9TY3JvbGxTZXNzaW9uKHM6IEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJywgcyk7XG59XG5cbi8vIC0tLSBQdXJnZTogdW5yZWxhdGVkIGJ1ZmZlcnMsIGNvdW50ZXJzLCBxdWV1ZSBlbnRyaWVzIC0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLyoqXG4gKiBEcm9wIGV2ZXJ5IHBlci1oYW5kbGUgYml0IG9mIHN0YXRlIChjb3VudGVycywgcnVuIGJ1ZmZlciwgY29tbWl0dGVkLWluZGV4XG4gKiBlbnRyaWVzLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcXVldWUgZW50cmllcykgdGhhdCBkb2Vzbid0IGNvcnJlc3BvbmQgdG8gYVxuICogdHJhY2tlZCBhY2NvdW50LiBSZXR1cm5zIGEgc3VtbWFyeSBkZXNjcmliaW5nIHdoYXQgd2FzIGNsZWFyZWQgc28gdGhlXG4gKiBjYWxsZXIgY2FuIGxvZyBpdC5cbiAqXG4gKiBUcmFja2VkIGFjY291bnRzIGFyZSBwYXNzZWQgaW4gKGNhbGxlciByZXNvbHZlcyBmcm9tIHRoZSBsaXZlIGNvbmZpZykuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwdXJnZVVucmVsYXRlZFN0YXRlKHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+KTogUHJvbWlzZTx7XG4gIGNvdW50ZXJzUmVtb3ZlZDogbnVtYmVyO1xuICBidWZmZXJzUmVtb3ZlZDogbnVtYmVyO1xuICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xuICByZWZldGNoSGFuZGxlc1JlbW92ZWQ6IG51bWJlcjtcbiAgbWVkaWFDcmF3bElkc1JlbW92ZWQ6IG51bWJlcjtcbn0+IHtcbiAgY29uc3QgdGFyZ0xvd2VyID0gbmV3IFNldChbLi4udGFyZ2V0ZWRdLm1hcCgoaCkgPT4gaC50b0xvd2VyQ2FzZSgpKSk7XG4gIGNvbnN0IGlzVGFyZ2V0ZWQgPSAoaDogc3RyaW5nKTogYm9vbGVhbiA9PiB0YXJnTG93ZXIuaGFzKGgudG9Mb3dlckNhc2UoKSk7XG5cbiAgLy8gQ291bnRlcnNcbiAgY29uc3QgY291bnRlcnMgPSBhd2FpdCBnZXRDb3VudGVycygpO1xuICBsZXQgY291bnRlcnNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGNvdW50ZXJzKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIGNvdW50ZXJzW2hdO1xuICAgICAgY291bnRlcnNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygnY291bnRlcnMnLCBjb3VudGVycyk7XG5cbiAgLy8gUnVuIGJ1ZmZlcnNcbiAgY29uc3QgYnVmZmVycyA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgbGV0IGJ1ZmZlcnNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGJ1ZmZlcnMpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgYnVmZmVyc1toXTtcbiAgICAgIGJ1ZmZlcnNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGJ1ZmZlcnMpO1xuXG4gIC8vIENvbW1pdHRlZCBkZWR1cCBpbmRleFxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBsZXQgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoaWR4KSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIGlkeFtoXTtcbiAgICAgIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG5cbiAgLy8gUmVmZXRjaCBxdWV1ZTogYnVja2V0cyBhcmUga2V5ZWQgYnkgaGFuZGxlLlxuICBjb25zdCBycSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBsZXQgcmVmZXRjaEhhbmRsZXNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKHJxKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIHJxW2hdO1xuICAgICAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcnEpO1xuXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiBidWNrZXRzIGFyZSBoaW50LWhhbmRsZXMgKG9yIFwiX3Vua25vd25cIikuIERyb3BcbiAgLy8gZW50cmllcyB3aG9zZSBidWNrZXQgaXNuJ3QgdGFyZ2V0ZWQgXHUyMDE0IGluY2x1ZGluZyBcIl91bmtub3duXCIgc2luY2Ugd2VcbiAgLy8gY2FuJ3QgdmVyaWZ5IHJlbGF0aW9uLlxuICBjb25zdCBtcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgbWVkaWFDcmF3bElkc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMobXEpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBtZWRpYUNyYXdsSWRzUmVtb3ZlZCArPSAobXFbaF0gPz8gW10pLmxlbmd0aDtcbiAgICAgIGRlbGV0ZSBtcVtoXTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBtcSk7XG5cbiAgcmV0dXJuIHtcbiAgICBjb3VudGVyc1JlbW92ZWQsXG4gICAgYnVmZmVyc1JlbW92ZWQsXG4gICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQsXG4gICAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkLFxuICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkLFxuICB9O1xufVxuXG4vLyAtLS0gRnVsbCByZXNldCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmNsZWFyKCk7XG59XG4iLCAiLyoqXG4gKiBvcHRpb25zLnRzIFx1MjAxNCBzZXR0aW5ncyBwYWdlLlxuICpcbiAqIFN0b3JlcyBQQVQgYW5kIHJlcG8gaWRlbnRpZmllcnMgaW4gYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAsIHZlcmlmaWVzIGFjY2Vzc1xuICogYnkgY2FsbGluZyAvdXNlciBhbmQgL3JlcG9zLzpvd25lci86cmVwbywgYW5kIHN1cmZhY2VzIHRoZSByZXN1bHRpbmdcbiAqIGNvbm5lY3Rpb24gc3RhdGUuXG4gKi9cblxuaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUyB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XG5pbXBvcnQge1xuICBjbGVhckFsbCxcbiAgZ2V0QWNjb3VudHMsXG4gIGdldEFjdGl2aXR5LFxuICBnZXRBcmNoaXZlU25hcHNob3QsXG4gIGdldENvbm5lY3Rpb24sXG4gIGdldENvdW50ZXJzLFxuICBnZXRSdW5CdWZmZXJzLFxuICBnZXRTZXR0aW5ncyxcbiAgdXBkYXRlU2V0dGluZ3MsXG59IGZyb20gJy4vbGliL3N0b3JhZ2UuanMnO1xuaW1wb3J0IHR5cGUgeyBSdW50aW1lTWVzc2FnZSB9IGZyb20gJy4vbGliL3R5cGVzLmpzJztcblxuY29uc3QgJCA9IDxUIGV4dGVuZHMgSFRNTEVsZW1lbnQgPSBIVE1MRWxlbWVudD4oaWQ6IHN0cmluZyk6IFQgPT4ge1xuICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcbiAgaWYgKCFlbCkgdGhyb3cgbmV3IEVycm9yKGBtaXNzaW5nIGVsZW1lbnQgIyR7aWR9YCk7XG4gIHJldHVybiBlbCBhcyBUO1xufTtcblxuY29uc3QgZm9ybSA9ICQ8SFRNTEZvcm1FbGVtZW50Pignc2V0dGluZ3MtZm9ybScpO1xuY29uc3Qgb3duZXJJbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ293bmVyJyk7XG5jb25zdCByZXBvSW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdyZXBvJyk7XG5jb25zdCBicmFuY2hJbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2JyYW5jaCcpO1xuY29uc3QgcGF0SW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdwYXQnKTtcbmNvbnN0IHJldmVhbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZXZlYWwtcGF0Jyk7XG5jb25zdCBzYXZlU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdzYXZlLXN0YXR1cycpO1xuY29uc3QgY29ubkRldGFpbCA9ICQoJ2Nvbm4tZGV0YWlsJyk7XG5jb25zdCBhY2NvdW50TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjY291bnQtcmVhZG9ubHknKTtcbmNvbnN0IHJlZnJlc2hCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmcmVzaC1hY2NvdW50cycpO1xuY29uc3QgZGlhZ0JveCA9ICQ8SFRNTFRleHRBcmVhRWxlbWVudD4oJ2RpYWdub3N0aWNzJyk7XG5jb25zdCBjb3B5RGlhZ0J0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjb3B5LWRpYWdub3N0aWNzJyk7XG5jb25zdCBjbGVhclN0b3JhZ2VCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2xlYXItc3RvcmFnZScpO1xuY29uc3QgZGlhZ1N0YXR1cyA9ICQ8SFRNTFNwYW5FbGVtZW50PignZGlhZy1zdGF0dXMnKTtcblxuYXN5bmMgZnVuY3Rpb24gc2VuZDxUPihtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTxUPiB7XG4gIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKSBhcyBQcm9taXNlPFQ+O1xufVxuXG5mdW5jdGlvbiBzZXRTdGF0dXMoZWw6IEhUTUxFbGVtZW50LCBraW5kOiAnb2snIHwgJ2VycicgfCAnd2FybicgfCAnJywgbXNnOiBzdHJpbmcpOiB2b2lkIHtcbiAgZWwuY2xhc3NOYW1lID0ga2luZCA/IGBzdGF0dXMgJHtraW5kfWAgOiAnc3RhdHVzJztcbiAgZWwudGV4dENvbnRlbnQgPSBtc2c7XG59XG5cbmZ1bmN0aW9uIGlzV3JpdGVBdXRoRXJyb3IobWVzc2FnZTogc3RyaW5nIHwgbnVsbCk6IGJvb2xlYW4ge1xuICByZXR1cm4gKFxuICAgIHR5cGVvZiBtZXNzYWdlID09PSAnc3RyaW5nJyAmJlxuICAgIC9SZXNvdXJjZSBub3QgYWNjZXNzaWJsZSBieSBwZXJzb25hbCBhY2Nlc3MgdG9rZW58XFwvZ2l0XFwvYmxvYnN8XFwvZ2l0XFwvcmVmcy9pLnRlc3QobWVzc2FnZSlcbiAgKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZFNldHRpbmdzKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgb3duZXJJbnB1dC52YWx1ZSA9IHMub3duZXIgfHwgREVGQVVMVF9TRVRUSU5HUy5vd25lcjtcbiAgcmVwb0lucHV0LnZhbHVlID0gcy5yZXBvIHx8IERFRkFVTFRfU0VUVElOR1MucmVwbztcbiAgYnJhbmNoSW5wdXQudmFsdWUgPSBzLmJyYW5jaCB8fCBERUZBVUxUX1NFVFRJTkdTLmJyYW5jaDtcbiAgaWYgKHMucGF0KSB7XG4gICAgcGF0SW5wdXQudmFsdWUgPSBzLnBhdDtcbiAgICBwYXRJbnB1dC5wbGFjZWhvbGRlciA9IGBcdTIwMjYke3MucGF0LnNsaWNlKC00KX1gO1xuICB9XG4gIGF3YWl0IHBhaW50Q29ubkRldGFpbCgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBwYWludENvbm5EZXRhaWwoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBsaW5lczogc3RyaW5nW10gPSBbXTtcbiAgbGluZXMucHVzaChgU3RhdHVzOiAke2Nvbm4uc3RhdHVzfWApO1xuICBpZiAoY29ubi5sb2dpbikgbGluZXMucHVzaChgTG9nZ2VkIGluIGFzOiBAJHtjb25uLmxvZ2lufWApO1xuICBsaW5lcy5wdXNoKGBSZXBvc2l0b3J5OiAke3Mub3duZXIgfHwgJz8nfS8ke3MucmVwbyB8fCAnPyd9QCR7cy5icmFuY2ggfHwgJz8nfWApO1xuICBpZiAoY29ubi5jaGVja2VkQXQpIGxpbmVzLnB1c2goYExhc3QgY2hlY2tlZDogJHtjb25uLmNoZWNrZWRBdH1gKTtcbiAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcbiAgICBjb25zdCByZXNldElzbyA9IG5ldyBEYXRlKGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAqIDEwMDApLnRvSVNPU3RyaW5nKCk7XG4gICAgY29uc3QgZGVsdGFTZWMgPSBjb25uLnJhdGVMaW1pdFJlc2V0QXQgLSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcbiAgICBjb25zdCBpbkxhYmVsID1cbiAgICAgIGRlbHRhU2VjIDw9IDBcbiAgICAgICAgPyAnbW9tZW50YXJpbHknXG4gICAgICAgIDogZGVsdGFTZWMgPCA2MFxuICAgICAgICAgID8gYGluICR7ZGVsdGFTZWN9c2BcbiAgICAgICAgICA6IGRlbHRhU2VjIDwgMzYwMFxuICAgICAgICAgICAgPyBgaW4gJHtNYXRoLnJvdW5kKGRlbHRhU2VjIC8gNjApfW1gXG4gICAgICAgICAgICA6IGBpbiAke01hdGgucm91bmQoZGVsdGFTZWMgLyAzNjAwKX1oYDtcbiAgICBsaW5lcy5wdXNoKGBSYXRlIGxpbWl0IHJlc2V0czogJHtyZXNldElzb30gKCR7aW5MYWJlbH0pYCk7XG4gIH1cbiAgaWYgKGNvbm4uZXJyb3IpIGxpbmVzLnB1c2goYEVycm9yOiAke2Nvbm4uZXJyb3J9YCk7XG4gIGNvbm5EZXRhaWwudGV4dENvbnRlbnQgPSBsaW5lcy5qb2luKCdcXG4nKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcGFpbnRBY2NvdW50cygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgbGlzdCA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGFjY291bnRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBmb3IgKGNvbnN0IGEgb2YgbGlzdCkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBjb25zdCBoYW5kbGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgaGFuZGxlLmNsYXNzTmFtZSA9ICdoYW5kbGUnO1xuICAgIGhhbmRsZS50ZXh0Q29udGVudCA9IGBAJHthLmhhbmRsZX1gO1xuICAgIGNvbnN0IGxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGxhYmVsLmNsYXNzTmFtZSA9ICdsYWJlbCc7XG4gICAgbGFiZWwudGV4dENvbnRlbnQgPSBhLmxhYmVsO1xuICAgIGxpLmFwcGVuZChoYW5kbGUsIGxhYmVsKTtcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZvcm0uYWRkRXZlbnRMaXN0ZW5lcignc3VibWl0JywgYXN5bmMgKGU6IEV2ZW50KSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKTtcbiAgY29uc3QgcGF0ID0gcGF0SW5wdXQudmFsdWUudHJpbSgpO1xuICBjb25zdCBvd25lciA9IG93bmVySW5wdXQudmFsdWUudHJpbSgpO1xuICBjb25zdCByZXBvID0gcmVwb0lucHV0LnZhbHVlLnRyaW0oKTtcbiAgY29uc3QgYnJhbmNoID0gYnJhbmNoSW5wdXQudmFsdWUudHJpbSgpIHx8ICdtYWluJztcbiAgaWYgKCFwYXQgfHwgIW93bmVyIHx8ICFyZXBvKSB7XG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICdlcnInLCAnQWxsIGZpZWxkcyBhcmUgcmVxdWlyZWQuJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnJywgJ1NhdmluZ1x1MjAyNicpO1xuICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IHBhdCwgb3duZXIsIHJlcG8sIGJyYW5jaCwgY29uZmlndXJlZEF0OiBEYXRlLm5vdygpIH0pO1xuICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJycsICdWZXJpZnlpbmdcdTIwMjYnKTtcbiAgYXdhaXQgc2VuZCh7IHR5cGU6ICd2ZXJpZnktY29ubmVjdGlvbicgfSk7XG4gIGF3YWl0IHNlbmQoeyB0eXBlOiAncmVmcmVzaC1hY2NvdW50cycgfSk7XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGlmIChjb25uLnN0YXR1cyA9PT0gJ29rJykge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnb2snLCBgQ29ubmVjdGVkIGFzIEAke2Nvbm4ubG9naW4gPz8gJz8nfS5gKTtcbiAgfSBlbHNlIGlmIChjb25uLnN0YXR1cyA9PT0gJ2F1dGgtZXJyb3InKSB7XG4gICAgc2V0U3RhdHVzKFxuICAgICAgc2F2ZVN0YXR1cyxcbiAgICAgICdlcnInLFxuICAgICAgaXNXcml0ZUF1dGhFcnJvcihjb25uLmVycm9yKVxuICAgICAgICA/ICdQQVQgY2FuIHJlYWQgdGhpcyByZXBvIGJ1dCBjYW5ub3Qgd3JpdGUuIFNldCBDb250ZW50czogUmVhZCAmIFdyaXRlLidcbiAgICAgICAgOiAnQXV0aCBmYWlsZWQgLSBjaGVjayB0aGUgUEFUIGFuZCBpdHMgcmVwbyBzY29wZS4nXG4gICAgKTtcbiAgfSBlbHNlIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ3dhcm4nLCAnUmF0ZS1saW1pdGVkIFx1MjAxNCB0b2tlbiBpcyB2YWxpZCBidXQgR2l0SHViIGlzIHRocm90dGxpbmcuJyk7XG4gIH0gZWxzZSBpZiAoY29ubi5zdGF0dXMgPT09ICduZXR3b3JrLWVycm9yJykge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgJ05ldHdvcmsgZXJyb3IgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpdml0eS4nKTtcbiAgfSBlbHNlIHtcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ2VycicsIGBWZXJpZmljYXRpb246ICR7Y29ubi5zdGF0dXN9YCk7XG4gIH1cbiAgYXdhaXQgcGFpbnRDb25uRGV0YWlsKCk7XG4gIGF3YWl0IHBhaW50QWNjb3VudHMoKTtcbiAgYXdhaXQgcmVmcmVzaERpYWcoKTtcbn0pO1xuXG5yZXZlYWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGlmIChwYXRJbnB1dC50eXBlID09PSAncGFzc3dvcmQnKSB7XG4gICAgcGF0SW5wdXQudHlwZSA9ICd0ZXh0JztcbiAgICByZXZlYWxCdG4udGV4dENvbnRlbnQgPSAnSGlkZSc7XG4gIH0gZWxzZSB7XG4gICAgcGF0SW5wdXQudHlwZSA9ICdwYXNzd29yZCc7XG4gICAgcmV2ZWFsQnRuLnRleHRDb250ZW50ID0gJ1Nob3cnO1xuICB9XG59KTtcblxucmVmcmVzaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgcmVmcmVzaEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdyZWZyZXNoLWFjY291bnRzJyB9KTtcbiAgICBhd2FpdCBwYWludEFjY291bnRzKCk7XG4gICAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICdvaycsICdBY2NvdW50cyByZWZyZXNoZWQuJyk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnZXJyJywgYFJlZnJlc2ggZmFpbGVkOiAkeyhlcnIgYXMgRXJyb3IpLm1lc3NhZ2V9YCk7XG4gIH0gZmluYWxseSB7XG4gICAgcmVmcmVzaEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaERpYWcoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IFtzZXR0aW5ncywgY29ubiwgYWNjb3VudHMsIGNvdW50ZXJzLCBidWZmZXJzLCBhY3Rpdml0eSwgYXJjaGl2ZVNuYXBzaG90XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICBnZXRTZXR0aW5ncygpLFxuICAgIGdldENvbm5lY3Rpb24oKSxcbiAgICBnZXRBY2NvdW50cygpLFxuICAgIGdldENvdW50ZXJzKCksXG4gICAgZ2V0UnVuQnVmZmVycygpLFxuICAgIGdldEFjdGl2aXR5KCksXG4gICAgZ2V0QXJjaGl2ZVNuYXBzaG90KCksXG4gIF0pO1xuICBjb25zdCByZWRhY3RlZEJ1ZmZlcnMgPSBPYmplY3QuZnJvbUVudHJpZXMoXG4gICAgT2JqZWN0LmVudHJpZXMoYnVmZmVycykubWFwKChbaywgYl0pID0+IFtcbiAgICAgIGssXG4gICAgICB7XG4gICAgICAgIHJ1bl9pZDogYi5ydW5faWQsXG4gICAgICAgIHN0YXJ0ZWRfYXQ6IGIuc3RhcnRlZF9hdCxcbiAgICAgICAgbGFzdF9jYXB0dXJlX2F0OiBiLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgICAgdHdlZXRzX2NvdW50OiBPYmplY3Qua2V5cyhiLnR3ZWV0c19ieV9pZCkubGVuZ3RoLFxuICAgICAgICBvYnNlcnZlZF9jb3VudDogYi50d2VldF9pZHNfb2JzZXJ2ZWQubGVuZ3RoLFxuICAgICAgICBlbmRwb2ludHNfc2VlbjogYi5lbmRwb2ludHNfc2VlbixcbiAgICAgICAgc291cmNlX3VybDogYi5zb3VyY2VfdXJsLFxuICAgICAgfSxcbiAgICBdKVxuICApO1xuICBjb25zdCBkdW1wID0ge1xuICAgIHZlcnNpb246IGJyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb24sXG4gICAgdXNlcl9hZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcbiAgICBzZXR0aW5nczoge1xuICAgICAgb3duZXI6IHNldHRpbmdzLm93bmVyLFxuICAgICAgcmVwbzogc2V0dGluZ3MucmVwbyxcbiAgICAgIGJyYW5jaDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgYXV0b0NhcHR1cmU6IHNldHRpbmdzLmF1dG9DYXB0dXJlLFxuICAgICAgdXBkYXRlRXhpc3Rpbmc6IHNldHRpbmdzLnVwZGF0ZUV4aXN0aW5nLFxuICAgICAgY29uZmlndXJlZEF0OiBzZXR0aW5ncy5jb25maWd1cmVkQXQsXG4gICAgICBwYXRTZXQ6IHNldHRpbmdzLnBhdC5sZW5ndGggPiAwLFxuICAgICAgcGF0U3VmZml4OiBzZXR0aW5ncy5wYXQubGVuZ3RoID49IDQgPyBzZXR0aW5ncy5wYXQuc2xpY2UoLTQpIDogJycsXG4gICAgfSxcbiAgICBjb25uZWN0aW9uOiBjb25uLFxuICAgIGFjY291bnRzLFxuICAgIGNvdW50ZXJzLFxuICAgIGFyY2hpdmVTbmFwc2hvdDogYXJjaGl2ZVNuYXBzaG90XG4gICAgICA/IHtcbiAgICAgICAgICBnZW5lcmF0ZWRfYXQ6IGFyY2hpdmVTbmFwc2hvdC5nZW5lcmF0ZWRfYXQsXG4gICAgICAgICAgZmV0Y2hlZF9hdDogYXJjaGl2ZVNuYXBzaG90LmZldGNoZWRfYXQsXG4gICAgICAgICAgYWNjb3VudHM6IE9iamVjdC5rZXlzKGFyY2hpdmVTbmFwc2hvdC5hY2NvdW50cykubGVuZ3RoLFxuICAgICAgICB9XG4gICAgICA6IG51bGwsXG4gICAgcnVuQnVmZmVyczogcmVkYWN0ZWRCdWZmZXJzLFxuICAgIGFjdGl2aXR5X3RhaWxfc2l6ZTogYWN0aXZpdHkubGVuZ3RoLFxuICAgIGFjdGl2aXR5X3JlY2VudDogYWN0aXZpdHkuc2xpY2UoMCwgMzApLFxuICB9O1xuICBkaWFnQm94LnZhbHVlID0gSlNPTi5zdHJpbmdpZnkoZHVtcCwgbnVsbCwgMik7XG59XG5cbmNvcHlEaWFnQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChkaWFnQm94LnZhbHVlKTtcbiAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICdvaycsICdDb3BpZWQgZGlhZ25vc3RpY3MgdG8gY2xpcGJvYXJkLicpO1xufSk7XG5cbmNsZWFyU3RvcmFnZUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgY29uc3Qgb2sgPSB3aW5kb3cuY29uZmlybShcbiAgICAnQ2xlYXIgZXh0ZW5zaW9uIHN0b3JhZ2U/IFRoaXMgZXJhc2VzIHlvdXIgUEFULCBzZXR0aW5ncywgY291bnRlcnMsIGJ1ZmZlcmVkIGNhcHR1cmVzLCBhbmQgYWN0aXZpdHkgdGFpbC4gVGhlcmUgaXMgbm8gdW5kby4nXG4gICk7XG4gIGlmICghb2spIHJldHVybjtcbiAgYXdhaXQgY2xlYXJBbGwoKTtcbiAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICd3YXJuJywgJ1N0b3JhZ2UgY2xlYXJlZC4nKTtcbiAgYXdhaXQgbG9hZFNldHRpbmdzKCk7XG4gIGF3YWl0IHBhaW50QWNjb3VudHMoKTtcbiAgYXdhaXQgcmVmcmVzaERpYWcoKTtcbn0pO1xuXG52b2lkIGxvYWRTZXR0aW5ncygpO1xudm9pZCBwYWludEFjY291bnRzKCk7XG52b2lkIHJlZnJlc2hEaWFnKCk7XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRU8sSUFBTSxtQkFBNkI7QUFBQSxFQUN4QyxLQUFLO0FBQUEsRUFDTCxPQUFPO0FBQUEsRUFDUCxNQUFNO0FBQUE7QUFBQTtBQUFBLEVBR04sUUFBUTtBQUFBLEVBQ1IsU0FBUztBQUFBLEVBQ1QsYUFBYTtBQUFBLEVBQ2IsY0FBYztBQUFBLEVBQ2QsdUJBQXVCO0FBQUEsRUFDdkIsZ0JBQWdCO0FBQ2xCO0FBT08sSUFBTSxvQkFBcUM7QUFBQSxFQUNoRCxFQUFFLFFBQVEsVUFBVSxPQUFPLG1DQUFtQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsVUFBVSxPQUFPLDRDQUE0QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsT0FBTyxPQUFPLHNDQUFzQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsU0FBUyxPQUFPLDZDQUE2QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsY0FBYyxPQUFPLG1CQUFtQixVQUFVLE9BQU87QUFBQSxFQUNuRSxFQUFFLFFBQVEsWUFBWSxPQUFPLCtCQUErQixVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLGtDQUFrQyxVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLDRCQUE0QixVQUFVLE9BQU87QUFBQSxFQUN2RSxFQUFFLFFBQVEsbUJBQW1CLE9BQU8scUJBQXFCLFVBQVUsT0FBTztBQUM1RTtBQThETyxJQUFNLGdDQUFnQyxLQUFLLEtBQUs7OztBQ3JFdkQsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0I7QUFFeEIsSUFBSSxrQkFBb0M7QUFDeEMsSUFBSSxzQkFBcUM7QUFFekMsU0FBUyxTQUFTLEtBQXlCO0FBQ3pDLE1BQUksSUFBSTtBQUNSLGFBQVcsS0FBSyxJQUFLLE1BQUssT0FBTyxhQUFhLENBQUM7QUFDL0MsU0FBTyxLQUFLLENBQUM7QUFDZjtBQUVBLFNBQVMsV0FBVyxHQUF1QjtBQUN6QyxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFFBQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxNQUFNO0FBQ3JDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUssS0FBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFDOUQsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUU7QUFDaEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDL0QsUUFBTSxJQUFJLE9BQU8sZ0JBQWdCO0FBQ2pDLE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsV0FBTyxFQUFFLFNBQVMsR0FBRyxNQUFNLFdBQVcsQ0FBQyxFQUFFO0FBQUEsRUFDM0M7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxRQUFNLFVBQVUsU0FBUyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0FBQy9ELFNBQU8sRUFBRSxTQUFTLEtBQUs7QUFDekI7QUFFQSxlQUFlLFlBQWdDO0FBQzdDLFFBQU0sRUFBRSxTQUFTLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUNqRCxNQUFJLG9CQUFvQixRQUFRLHdCQUF3QixTQUFTO0FBQy9ELFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFO0FBQUEsSUFDN0IsR0FBRyxRQUFRLFFBQVEsRUFBRSxJQUFJLFFBQVEsUUFBUSxZQUFZLEVBQUUsT0FBTztBQUFBLEVBQ2hFO0FBQ0EsUUFBTSxXQUFXLElBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNO0FBQ3pELFdBQVMsSUFBSSxNQUFNLENBQUM7QUFDcEIsV0FBUyxJQUFJLE1BQU0sS0FBSyxNQUFNO0FBQzlCLFFBQU0sT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUTtBQUMzRCxRQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLE1BQU0sRUFBRSxNQUFNLFVBQVUsR0FBRyxPQUFPO0FBQUEsSUFDakY7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBQ0Qsb0JBQWtCO0FBQ2xCLHdCQUFzQjtBQUN0QixTQUFPO0FBQ1Q7QUFFTyxTQUFTLGVBQWUsR0FBb0I7QUFDakQsU0FBTyxFQUFFLFdBQVcsZUFBZTtBQUNyQztBQUVBLGVBQXNCLFdBQVcsV0FBb0M7QUFDbkUsTUFBSSxDQUFDLFVBQVcsUUFBTztBQUN2QixRQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFFBQU0sS0FBSyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3BELFFBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLElBQzdCLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxJQUN0QjtBQUFBLElBQ0EsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTO0FBQUEsRUFDcEM7QUFDQSxTQUFPLEdBQUcsZUFBZSxHQUFHLFNBQVMsRUFBRSxDQUFDLElBQUksU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMUU7QUFFQSxlQUFzQixXQUFXLFVBQW1DO0FBQ2xFLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFHdEIsTUFBSSxDQUFDLFNBQVMsV0FBVyxlQUFlLEVBQUcsUUFBTztBQUNsRCxRQUFNLFFBQVEsU0FBUyxNQUFNLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxHQUFHO0FBQzlELE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUMvQixRQUFNLENBQUMsT0FBTyxLQUFLLElBQUk7QUFDdkIsTUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFPLFFBQU87QUFDN0IsTUFBSTtBQUNGLFVBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQzdCLEVBQUUsTUFBTSxXQUFXLEdBQXVCO0FBQUEsTUFDMUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDcEMsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7OztBQ3JCQSxJQUFNLHFCQUFzQztBQUFBLEVBQzFDLFFBQVE7QUFBQSxFQUNSLE9BQU87QUFBQSxFQUNQLFdBQVc7QUFBQSxFQUNYLE9BQU87QUFBQSxFQUNQLGVBQWU7QUFBQSxFQUNmLHdCQUF3QjtBQUFBLEVBQ3hCLGtCQUFrQjtBQUNwQjtBQUVBLElBQU0sV0FBeUI7QUFBQSxFQUM3QixVQUFVLEVBQUUsR0FBRyxpQkFBaUI7QUFBQSxFQUNoQyxVQUFVLENBQUMsR0FBRyxpQkFBaUI7QUFBQSxFQUMvQixxQkFBcUI7QUFBQSxFQUNyQixpQkFBaUI7QUFBQSxFQUNqQixZQUFZLEVBQUUsR0FBRyxtQkFBbUI7QUFBQSxFQUNwQyxVQUFVLENBQUM7QUFBQSxFQUNYLFlBQVksQ0FBQztBQUFBLEVBQ2IsVUFBVSxDQUFDO0FBQUEsRUFDWCxnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGNBQWMsQ0FBQztBQUFBLEVBQ2YsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixnQkFBZ0I7QUFBQSxFQUNoQixtQkFBbUI7QUFBQSxFQUNuQixtQkFBbUI7QUFDckI7QUFFQSxlQUFlLE9BQXFDLEtBQWtDO0FBQ3BGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksR0FBRztBQUNsRCxRQUFNLFFBQVEsT0FBTyxHQUFHO0FBQ3hCLE1BQUksVUFBVSxRQUFXO0FBQ3ZCLFdBQU8sZ0JBQWdCLFNBQVMsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxlQUFlLE9BQXFDLEtBQVEsT0FBdUM7QUFDakcsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDO0FBQ2xEO0FBSUEsZUFBc0IsY0FBaUM7QUFLckQsUUFBTSxTQUFTLE1BQU0sT0FBTyxVQUFVO0FBQ3RDLFFBQU0sU0FBUyxFQUFFLEdBQUcsa0JBQWtCLEdBQUcsT0FBTztBQUNoRCxNQUFJLE9BQU8sT0FBTyxlQUFlLE9BQU8sR0FBRyxHQUFHO0FBQzVDLFFBQUk7QUFDRixhQUFPLE1BQU0sTUFBTSxXQUFXLE9BQU8sR0FBRztBQUFBLElBQzFDLFFBQVE7QUFDTixhQUFPLE1BQU07QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLFlBQVksR0FBNEI7QUFHNUQsUUFBTSxVQUFvQixFQUFFLEdBQUcsRUFBRTtBQUNqQyxNQUFJLFFBQVEsT0FBTyxDQUFDLGVBQWUsUUFBUSxHQUFHLEdBQUc7QUFDL0MsWUFBUSxNQUFNLE1BQU0sV0FBVyxRQUFRLEdBQUc7QUFBQSxFQUM1QztBQUNBLFFBQU0sT0FBTyxZQUFZLE9BQU87QUFDbEM7QUFDQSxlQUFzQixlQUFlLE9BQTZDO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxPQUFPLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoQyxRQUFNLFlBQVksSUFBSTtBQUN0QixTQUFPO0FBQ1Q7QUFJQSxlQUFzQixjQUF3QztBQUM1RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQWFBLGVBQXNCLHFCQUFzRDtBQUMxRSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBUUEsZUFBc0IsZ0JBQTBDO0FBQzlELFFBQU0sSUFBSSxNQUFNLE9BQU8sWUFBWTtBQUVuQyxRQUFNLE1BQXVCO0FBQUEsSUFDM0IsR0FBRztBQUFBLElBQ0gsZUFBZSxFQUFFLGtCQUFrQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3hELHdCQUNFLEVBQUUsMkJBQTJCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDcEQsa0JBQWtCLEVBQUUscUJBQXFCLFNBQVksT0FBTyxFQUFFO0FBQUEsRUFDaEU7QUFDQSxTQUFPO0FBQ1Q7QUFXQSxlQUFzQixjQUF1RDtBQUMzRSxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQTZCQSxlQUFzQixnQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLFlBQVk7QUFDNUI7QUFxQkEsZUFBc0IsY0FBbUM7QUFDdkQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUF1UkEsZUFBc0IsV0FBMEI7QUFDOUMsUUFBTSxRQUFRLFFBQVEsTUFBTSxNQUFNO0FBQ3BDOzs7QUNuaEJBLElBQU0sSUFBSSxDQUFzQyxPQUFrQjtBQUNoRSxRQUFNLEtBQUssU0FBUyxlQUFlLEVBQUU7QUFDckMsTUFBSSxDQUFDLEdBQUksT0FBTSxJQUFJLE1BQU0sb0JBQW9CLEVBQUUsRUFBRTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxJQUFNLE9BQU8sRUFBbUIsZUFBZTtBQUMvQyxJQUFNLGFBQWEsRUFBb0IsT0FBTztBQUM5QyxJQUFNLFlBQVksRUFBb0IsTUFBTTtBQUM1QyxJQUFNLGNBQWMsRUFBb0IsUUFBUTtBQUNoRCxJQUFNLFdBQVcsRUFBb0IsS0FBSztBQUMxQyxJQUFNLFlBQVksRUFBcUIsWUFBWTtBQUNuRCxJQUFNLGFBQWEsRUFBbUIsYUFBYTtBQUNuRCxJQUFNLGFBQWEsRUFBRSxhQUFhO0FBQ2xDLElBQU0sY0FBYyxFQUFvQixrQkFBa0I7QUFDMUQsSUFBTSxhQUFhLEVBQXFCLGtCQUFrQjtBQUMxRCxJQUFNLFVBQVUsRUFBdUIsYUFBYTtBQUNwRCxJQUFNLGNBQWMsRUFBcUIsa0JBQWtCO0FBQzNELElBQU0sa0JBQWtCLEVBQXFCLGVBQWU7QUFDNUQsSUFBTSxhQUFhLEVBQW1CLGFBQWE7QUFFbkQsZUFBZSxLQUFRLEtBQWlDO0FBQ3RELFNBQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUN4QztBQUVBLFNBQVMsVUFBVSxJQUFpQixNQUFrQyxLQUFtQjtBQUN2RixLQUFHLFlBQVksT0FBTyxVQUFVLElBQUksS0FBSztBQUN6QyxLQUFHLGNBQWM7QUFDbkI7QUFFQSxTQUFTLGlCQUFpQixTQUFpQztBQUN6RCxTQUNFLE9BQU8sWUFBWSxZQUNuQiw2RUFBNkUsS0FBSyxPQUFPO0FBRTdGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLGFBQVcsUUFBUSxFQUFFLFNBQVMsaUJBQWlCO0FBQy9DLFlBQVUsUUFBUSxFQUFFLFFBQVEsaUJBQWlCO0FBQzdDLGNBQVksUUFBUSxFQUFFLFVBQVUsaUJBQWlCO0FBQ2pELE1BQUksRUFBRSxLQUFLO0FBQ1QsYUFBUyxRQUFRLEVBQUU7QUFDbkIsYUFBUyxjQUFjLFNBQUksRUFBRSxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFDNUM7QUFDQSxRQUFNLGdCQUFnQjtBQUN4QjtBQUVBLGVBQWUsa0JBQWlDO0FBQzlDLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFFBQWtCLENBQUM7QUFDekIsUUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLEVBQUU7QUFDbkMsTUFBSSxLQUFLLE1BQU8sT0FBTSxLQUFLLGtCQUFrQixLQUFLLEtBQUssRUFBRTtBQUN6RCxRQUFNLEtBQUssZUFBZSxFQUFFLFNBQVMsR0FBRyxJQUFJLEVBQUUsUUFBUSxHQUFHLElBQUksRUFBRSxVQUFVLEdBQUcsRUFBRTtBQUM5RSxNQUFJLEtBQUssVUFBVyxPQUFNLEtBQUssaUJBQWlCLEtBQUssU0FBUyxFQUFFO0FBQ2hFLE1BQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFVBQU0sV0FBVyxJQUFJLEtBQUssS0FBSyxtQkFBbUIsR0FBSSxFQUFFLFlBQVk7QUFDcEUsVUFBTSxXQUFXLEtBQUssbUJBQW1CLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQ3JFLFVBQU0sVUFDSixZQUFZLElBQ1IsZ0JBQ0EsV0FBVyxLQUNULE1BQU0sUUFBUSxNQUNkLFdBQVcsT0FDVCxNQUFNLEtBQUssTUFBTSxXQUFXLEVBQUUsQ0FBQyxNQUMvQixNQUFNLEtBQUssTUFBTSxXQUFXLElBQUksQ0FBQztBQUMzQyxVQUFNLEtBQUssc0JBQXNCLFFBQVEsS0FBSyxPQUFPLEdBQUc7QUFBQSxFQUMxRDtBQUNBLE1BQUksS0FBSyxNQUFPLE9BQU0sS0FBSyxVQUFVLEtBQUssS0FBSyxFQUFFO0FBQ2pELGFBQVcsY0FBYyxNQUFNLEtBQUssSUFBSTtBQUMxQztBQUVBLGVBQWUsZ0JBQStCO0FBQzVDLFFBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsY0FBWSxnQkFBZ0I7QUFDNUIsYUFBVyxLQUFLLE1BQU07QUFDcEIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVk7QUFDbkIsV0FBTyxjQUFjLElBQUksRUFBRSxNQUFNO0FBQ2pDLFVBQU0sUUFBUSxTQUFTLGNBQWMsTUFBTTtBQUMzQyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxjQUFjLEVBQUU7QUFDdEIsT0FBRyxPQUFPLFFBQVEsS0FBSztBQUN2QixnQkFBWSxPQUFPLEVBQUU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsS0FBSyxpQkFBaUIsVUFBVSxPQUFPLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLFFBQU0sTUFBTSxTQUFTLE1BQU0sS0FBSztBQUNoQyxRQUFNLFFBQVEsV0FBVyxNQUFNLEtBQUs7QUFDcEMsUUFBTSxPQUFPLFVBQVUsTUFBTSxLQUFLO0FBQ2xDLFFBQU0sU0FBUyxZQUFZLE1BQU0sS0FBSyxLQUFLO0FBQzNDLE1BQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU07QUFDM0IsY0FBVSxZQUFZLE9BQU8sMEJBQTBCO0FBQ3ZEO0FBQUEsRUFDRjtBQUNBLFlBQVUsWUFBWSxJQUFJLGNBQVM7QUFDbkMsUUFBTSxlQUFlLEVBQUUsS0FBSyxPQUFPLE1BQU0sUUFBUSxjQUFjLEtBQUssSUFBSSxFQUFFLENBQUM7QUFDM0UsWUFBVSxZQUFZLElBQUksaUJBQVk7QUFDdEMsUUFBTSxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUN4QyxRQUFNLEtBQUssRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3ZDLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsTUFBSSxLQUFLLFdBQVcsTUFBTTtBQUN4QixjQUFVLFlBQVksTUFBTSxpQkFBaUIsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUFBLEVBQ25FLFdBQVcsS0FBSyxXQUFXLGNBQWM7QUFDdkM7QUFBQSxNQUNFO0FBQUEsTUFDQTtBQUFBLE1BQ0EsaUJBQWlCLEtBQUssS0FBSyxJQUN2Qix5RUFDQTtBQUFBLElBQ047QUFBQSxFQUNGLFdBQVcsS0FBSyxXQUFXLGdCQUFnQjtBQUN6QyxjQUFVLFlBQVksUUFBUSw4REFBeUQ7QUFBQSxFQUN6RixXQUFXLEtBQUssV0FBVyxpQkFBaUI7QUFDMUMsY0FBVSxZQUFZLE9BQU8sMENBQXFDO0FBQUEsRUFDcEUsT0FBTztBQUNMLGNBQVUsWUFBWSxPQUFPLGlCQUFpQixLQUFLLE1BQU0sRUFBRTtBQUFBLEVBQzdEO0FBQ0EsUUFBTSxnQkFBZ0I7QUFDdEIsUUFBTSxjQUFjO0FBQ3BCLFFBQU0sWUFBWTtBQUNwQixDQUFDO0FBRUQsVUFBVSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3hDLE1BQUksU0FBUyxTQUFTLFlBQVk7QUFDaEMsYUFBUyxPQUFPO0FBQ2hCLGNBQVUsY0FBYztBQUFBLEVBQzFCLE9BQU87QUFDTCxhQUFTLE9BQU87QUFDaEIsY0FBVSxjQUFjO0FBQUEsRUFDMUI7QUFDRixDQUFDO0FBRUQsV0FBVyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9DLGFBQVcsV0FBVztBQUN0QixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUN2QyxVQUFNLGNBQWM7QUFDcEIsY0FBVSxZQUFZLE1BQU0scUJBQXFCO0FBQUEsRUFDbkQsU0FBUyxLQUFLO0FBQ1osY0FBVSxZQUFZLE9BQU8sbUJBQW9CLElBQWMsT0FBTyxFQUFFO0FBQUEsRUFDMUUsVUFBRTtBQUNBLGVBQVcsV0FBVztBQUFBLEVBQ3hCO0FBQ0YsQ0FBQztBQUVELGVBQWUsY0FBNkI7QUFDMUMsUUFBTSxDQUFDLFVBQVUsTUFBTSxVQUFVLFVBQVUsU0FBUyxVQUFVLGVBQWUsSUFBSSxNQUFNLFFBQVEsSUFBSTtBQUFBLElBQ2pHLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxJQUNaLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxJQUNaLG1CQUFtQjtBQUFBLEVBQ3JCLENBQUM7QUFDRCxRQUFNLGtCQUFrQixPQUFPO0FBQUEsSUFDN0IsT0FBTyxRQUFRLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUFBLE1BQ3RDO0FBQUEsTUFDQTtBQUFBLFFBQ0UsUUFBUSxFQUFFO0FBQUEsUUFDVixZQUFZLEVBQUU7QUFBQSxRQUNkLGlCQUFpQixFQUFFO0FBQUEsUUFDbkIsY0FBYyxPQUFPLEtBQUssRUFBRSxZQUFZLEVBQUU7QUFBQSxRQUMxQyxnQkFBZ0IsRUFBRSxtQkFBbUI7QUFBQSxRQUNyQyxnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLFlBQVksRUFBRTtBQUFBLE1BQ2hCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sT0FBTztBQUFBLElBQ1gsU0FBUyxRQUFRLFFBQVEsWUFBWSxFQUFFO0FBQUEsSUFDdkMsWUFBWSxVQUFVO0FBQUEsSUFDdEIsVUFBVTtBQUFBLE1BQ1IsT0FBTyxTQUFTO0FBQUEsTUFDaEIsTUFBTSxTQUFTO0FBQUEsTUFDZixRQUFRLFNBQVM7QUFBQSxNQUNqQixhQUFhLFNBQVM7QUFBQSxNQUN0QixnQkFBZ0IsU0FBUztBQUFBLE1BQ3pCLGNBQWMsU0FBUztBQUFBLE1BQ3ZCLFFBQVEsU0FBUyxJQUFJLFNBQVM7QUFBQSxNQUM5QixXQUFXLFNBQVMsSUFBSSxVQUFVLElBQUksU0FBUyxJQUFJLE1BQU0sRUFBRSxJQUFJO0FBQUEsSUFDakU7QUFBQSxJQUNBLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsaUJBQWlCLGtCQUNiO0FBQUEsTUFDRSxjQUFjLGdCQUFnQjtBQUFBLE1BQzlCLFlBQVksZ0JBQWdCO0FBQUEsTUFDNUIsVUFBVSxPQUFPLEtBQUssZ0JBQWdCLFFBQVEsRUFBRTtBQUFBLElBQ2xELElBQ0E7QUFBQSxJQUNKLFlBQVk7QUFBQSxJQUNaLG9CQUFvQixTQUFTO0FBQUEsSUFDN0IsaUJBQWlCLFNBQVMsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUN2QztBQUNBLFVBQVEsUUFBUSxLQUFLLFVBQVUsTUFBTSxNQUFNLENBQUM7QUFDOUM7QUFFQSxZQUFZLGlCQUFpQixTQUFTLFlBQVk7QUFDaEQsUUFBTSxVQUFVLFVBQVUsVUFBVSxRQUFRLEtBQUs7QUFDakQsWUFBVSxZQUFZLE1BQU0sa0NBQWtDO0FBQ2hFLENBQUM7QUFFRCxnQkFBZ0IsaUJBQWlCLFNBQVMsWUFBWTtBQUNwRCxRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsUUFBTSxTQUFTO0FBQ2YsWUFBVSxZQUFZLFFBQVEsa0JBQWtCO0FBQ2hELFFBQU0sYUFBYTtBQUNuQixRQUFNLGNBQWM7QUFDcEIsUUFBTSxZQUFZO0FBQ3BCLENBQUM7QUFFRCxLQUFLLGFBQWE7QUFDbEIsS0FBSyxjQUFjO0FBQ25CLEtBQUssWUFBWTsiLAogICJuYW1lcyI6IFtdCn0K
