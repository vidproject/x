// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  threadOpenQueue: {},
  threadOpenSeen: {},
  refetchSession: null,
  mediaCrawlSession: null,
  threadOpenSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function getCounters() {
  return getRaw("counters");
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getActivity() {
  return getRaw("activity");
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/options.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var form = $("settings-form");
var ownerInput = $("owner");
var repoInput = $("repo");
var branchInput = $("branch");
var patInput = $("pat");
var revealBtn = $("reveal-pat");
var saveStatus = $("save-status");
var connDetail = $("conn-detail");
var accountList = $("account-readonly");
var refreshBtn = $("refresh-accounts");
var diagBox = $("diagnostics");
var copyDiagBtn = $("copy-diagnostics");
var clearStorageBtn = $("clear-storage");
var diagStatus = $("diag-status");
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setStatus(el, kind, msg) {
  el.className = kind ? `status ${kind}` : "status";
  el.textContent = msg;
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
async function loadSettings() {
  const s = await getSettings();
  ownerInput.value = s.owner || DEFAULT_SETTINGS.owner;
  repoInput.value = s.repo || DEFAULT_SETTINGS.repo;
  branchInput.value = s.branch || DEFAULT_SETTINGS.branch;
  if (s.pat) {
    patInput.value = s.pat;
    patInput.placeholder = `\u2026${s.pat.slice(-4)}`;
  }
  await paintConnDetail();
}
async function paintConnDetail() {
  const conn = await getConnection();
  const s = await getSettings();
  const lines = [];
  lines.push(`Status: ${conn.status}`);
  if (conn.login) lines.push(`Logged in as: @${conn.login}`);
  lines.push(`Repository: ${s.owner || "?"}/${s.repo || "?"}@${s.branch || "?"}`);
  if (conn.checkedAt) lines.push(`Last checked: ${conn.checkedAt}`);
  if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
    const resetIso = new Date(conn.rateLimitResetAt * 1e3).toISOString();
    const deltaSec = conn.rateLimitResetAt - Math.floor(Date.now() / 1e3);
    const inLabel = deltaSec <= 0 ? "momentarily" : deltaSec < 60 ? `in ${deltaSec}s` : deltaSec < 3600 ? `in ${Math.round(deltaSec / 60)}m` : `in ${Math.round(deltaSec / 3600)}h`;
    lines.push(`Rate limit resets: ${resetIso} (${inLabel})`);
  }
  if (conn.error) lines.push(`Error: ${conn.error}`);
  connDetail.textContent = lines.join("\n");
}
async function paintAccounts() {
  const list = await getAccounts();
  accountList.replaceChildren();
  for (const a of list) {
    const li = document.createElement("li");
    const handle = document.createElement("span");
    handle.className = "handle";
    handle.textContent = `@${a.handle}`;
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = a.label;
    li.append(handle, label);
    accountList.append(li);
  }
}
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const pat = patInput.value.trim();
  const owner = ownerInput.value.trim();
  const repo = repoInput.value.trim();
  const branch = branchInput.value.trim() || "main";
  if (!pat || !owner || !repo) {
    setStatus(saveStatus, "err", "All fields are required.");
    return;
  }
  setStatus(saveStatus, "", "Saving\u2026");
  await updateSettings({ pat, owner, repo, branch, configuredAt: Date.now() });
  setStatus(saveStatus, "", "Verifying\u2026");
  await send({ type: "verify-connection" });
  await send({ type: "refresh-accounts" });
  const conn = await getConnection();
  if (conn.status === "ok") {
    setStatus(saveStatus, "ok", `Connected as @${conn.login ?? "?"}.`);
  } else if (conn.status === "auth-error") {
    setStatus(
      saveStatus,
      "err",
      isWriteAuthError(conn.error) ? "PAT can read this repo but cannot write. Set Contents: Read & Write." : "Auth failed - check the PAT and its repo scope."
    );
  } else if (conn.status === "rate-limited") {
    setStatus(saveStatus, "warn", "Rate-limited \u2014 token is valid but GitHub is throttling.");
  } else if (conn.status === "network-error") {
    setStatus(saveStatus, "err", "Network error \u2014 check connectivity.");
  } else {
    setStatus(saveStatus, "err", `Verification: ${conn.status}`);
  }
  await paintConnDetail();
  await paintAccounts();
  await refreshDiag();
});
revealBtn.addEventListener("click", () => {
  if (patInput.type === "password") {
    patInput.type = "text";
    revealBtn.textContent = "Hide";
  } else {
    patInput.type = "password";
    revealBtn.textContent = "Show";
  }
});
refreshBtn.addEventListener("click", async () => {
  refreshBtn.disabled = true;
  try {
    await send({ type: "refresh-accounts" });
    await paintAccounts();
    setStatus(diagStatus, "ok", "Accounts refreshed.");
  } catch (err) {
    setStatus(diagStatus, "err", `Refresh failed: ${err.message}`);
  } finally {
    refreshBtn.disabled = false;
  }
});
async function refreshDiag() {
  const [settings, conn, accounts, counters, buffers, activity, archiveSnapshot] = await Promise.all([
    getSettings(),
    getConnection(),
    getAccounts(),
    getCounters(),
    getRunBuffers(),
    getActivity(),
    getArchiveSnapshot()
  ]);
  const redactedBuffers = Object.fromEntries(
    Object.entries(buffers).map(([k, b]) => [
      k,
      {
        run_id: b.run_id,
        started_at: b.started_at,
        last_capture_at: b.last_capture_at,
        tweets_count: Object.keys(b.tweets_by_id).length,
        observed_count: b.tweet_ids_observed.length,
        endpoints_seen: b.endpoints_seen,
        source_url: b.source_url
      }
    ])
  );
  const dump = {
    version: browser.runtime.getManifest().version,
    user_agent: navigator.userAgent,
    settings: {
      owner: settings.owner,
      repo: settings.repo,
      branch: settings.branch,
      autoCapture: settings.autoCapture,
      updateExisting: settings.updateExisting,
      configuredAt: settings.configuredAt,
      patSet: settings.pat.length > 0,
      patSuffix: settings.pat.length >= 4 ? settings.pat.slice(-4) : ""
    },
    connection: conn,
    accounts,
    counters,
    archiveSnapshot: archiveSnapshot ? {
      generated_at: archiveSnapshot.generated_at,
      fetched_at: archiveSnapshot.fetched_at,
      accounts: Object.keys(archiveSnapshot.accounts).length
    } : null,
    runBuffers: redactedBuffers,
    activity_tail_size: activity.length,
    activity_recent: activity.slice(0, 30)
  };
  diagBox.value = JSON.stringify(dump, null, 2);
}
copyDiagBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(diagBox.value);
  setStatus(diagStatus, "ok", "Copied diagnostics to clipboard.");
});
clearStorageBtn.addEventListener("click", async () => {
  const ok = window.confirm(
    "Clear extension storage? This erases your PAT, settings, counters, buffered captures, and activity tail. There is no undo."
  );
  if (!ok) return;
  await clearAll();
  setStatus(diagStatus, "warn", "Storage cleared.");
  await loadSettings();
  await paintAccounts();
  await refreshDiag();
});
void loadSettings();
void paintAccounts();
void refreshDiag();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9vcHRpb25zLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgdHlwZSB7IEFjY291bnRDb25maWcsIFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBTZXR0aW5ncyA9IHtcbiAgcGF0OiAnJyxcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcbiAgcmVwbzogJ3gnLFxuICAvLyBUaGUgcmVwbydzIGN1cnJlbnQgZGVmYXVsdCBicmFuY2ggaXMgXCJtYXN0ZXJcIi4gSWYgeW91IGZvcmsgb3IgcmVuYW1lXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXG4gIGJyYW5jaDogJ21hc3RlcicsXG4gIGVuYWJsZWQ6IHRydWUsXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxuICBjb25maWd1cmVkQXQ6IG51bGwsXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcbiAgdXBkYXRlRXhpc3Rpbmc6IHRydWUsXG59O1xuXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xuXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cbiAqXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXG4gKiBHaXRIdWIgUEFUIGluIHBsYWludGV4dC4gQSBkZXRlcm1pbmVkIGF0dGFja2VyIHdpdGggdGhlIGV4dGVuc2lvbidzIHNvdXJjZVxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxuICogc3RyaW5nIHNpdHRpbmcgbmV4dCB0byBpdHMga2V5IG5hbWUgaW4gZXh0ZW5zaW9uIHN0b3JhZ2UuXG4gKlxuICogU2NoZW1lOlxuICogICAtIE9uIGZpcnN0IGVuY3J5cHRpb24gd2UgZ2VuZXJhdGUgYSAzMi1ieXRlIHNhbHQgYW5kIHBlcnNpc3QgaXQgaW5cbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cbiAqICAgICB8fCBcImltbS1hcmNoaXZlLXBhdC12MVwiYC4gVGhlIHNhbHQgYmVpbmcgcGVyLWluc3RhbGwgbWVhbnMgdHdvIGNvcGllc1xuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxuICogICAtIFBsYWludGV4dCBpcyBlbmNyeXB0ZWQgd2l0aCBhIGZyZXNoIDEyLWJ5dGUgSVYuIFRoZSBlbnZlbG9wZSBmb3JtYXQgaXNcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXG4gKlxuICogQmFja3dhcmRzIGNvbXBhdGliaWxpdHk6IGFuIHVucHJlZml4ZWQgdmFsdWUgaXMgdHJlYXRlZCBhcyBsZWdhY3lcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cbiAqL1xuXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xuXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcbiAgbGV0IHMgPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIGJ1ZikgcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShzKTtcbn1cblxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcbiAgY29uc3QgYmluID0gYXRvYihzKTtcbiAgY29uc3Qgb3V0ID0gbmV3IFVpbnQ4QXJyYXkoYmluLmxlbmd0aCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChTQUxUX1NUT1JBR0VfS0VZKTtcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4geyBzYWx0QjY0OiB2LCBzYWx0OiBmcm9tQmFzZTY0KHYpIH07XG4gIH1cbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcbiAgY29uc3Qgc2FsdEI2NCA9IHRvQmFzZTY0KHNhbHQpO1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICBjb25zdCB7IHNhbHRCNjQsIHNhbHQgfSA9IGF3YWl0IGxvYWRPckNyZWF0ZVNhbHQoKTtcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcbiAgfVxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXG4gICk7XG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcbiAgY29tYmluZWQuc2V0KHNhbHQsIHNlZWQubGVuZ3RoKTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcbiAgICAnZW5jcnlwdCcsXG4gICAgJ2RlY3J5cHQnLFxuICBdKTtcbiAgZGVyaXZlZEtleUNhY2hlID0ga2V5O1xuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcbiAgcmV0dXJuIGtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdi5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbmNyeXB0UGF0KHBsYWludGV4dDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gIGNvbnN0IGl2ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMikpO1xuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcbiAgICBrZXksXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcbiAgKTtcbiAgcmV0dXJuIGAke0VOVkVMT1BFX1BSRUZJWH0ke3RvQmFzZTY0KGl2KX06JHt0b0Jhc2U2NChuZXcgVWludDhBcnJheShjdCkpfWA7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWNyeXB0UGF0KGVudmVsb3BlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXG4gIC8vIHJlLWVuY3J5cHRzIGl0IHZpYSB0aGUgc3RvcmFnZSBsYXllci5cbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xuICBpZiAocGFydHMubGVuZ3RoICE9PSAyKSByZXR1cm4gJyc7XG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XG4gIHRyeSB7XG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcbiAgICBjb25zdCBjdCA9IGZyb21CYXNlNjQoY3RCNjQpO1xuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcbiAgICAgIGtleSxcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShwdCk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnJztcbiAgfVxufVxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB7IGRlY3J5cHRQYXQsIGVuY3J5cHRQYXQsIGlzRW5jcnlwdGVkUGF0IH0gZnJvbSAnLi9jcnlwdG8uanMnO1xuaW1wb3J0IHR5cGUge1xuICBBY2NvdW50Q29uZmlnLFxuICBBY2NvdW50Q291bnRlcixcbiAgQXJjaGl2ZVNuYXBzaG90LFxuICBDYW5vbmljYWxUd2VldCxcbiAgQ29ubmVjdGlvblN0YXRlLFxuICBMb2dFdmVudCxcbiAgUmV0d2VldEVkZ2UsXG4gIFNldHRpbmdzLFxuICBUd2VldFNpZ2h0aW5nLFxuICBVbmF2YWlsYWJsZVR3ZWV0LFxufSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBCdWZmZXJlZCB0d2VldHMgZm9yIGEgZ2l2ZW4gYWNjb3VudCwgYXdhaXRpbmcgY29tbWl0LiBBIFwicnVuXCIgaXMgb25lIGVudHJ5XG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xuICBydW5faWQ6IHN0cmluZztcbiAgYWNjb3VudF9oYW5kbGU6IHN0cmluZztcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcbiAgdHdlZXRzX2J5X2lkOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD47XG4gIHVuYXZhaWxhYmxlX2J5X2lkPzogUmVjb3JkPHN0cmluZywgVW5hdmFpbGFibGVUd2VldD47XG4gIHJldHdlZXRfZWRnZXNfYnlfa2V5PzogUmVjb3JkPHN0cmluZywgUmV0d2VldEVkZ2U+O1xuICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IHN0cmluZ1tdO1xuICBlbmRwb2ludHNfc2Vlbjogc3RyaW5nW107XG4gIHNvdXJjZV91cmw6IHN0cmluZyB8IG51bGw7XG59XG5cbi8qKiBQZXItdHdlZXQgY29tbWl0dGVkLXN0YXRlIGluZGV4LCBrZXllZCBieSBoYW5kbGUgdGhlbiB0d2VldF9pZC5cbiAqIFVzZWQgdG8gc2tpcCByZS1jYXB0dXJpbmcgdHdlZXRzIHdlJ3ZlIGFscmVhZHkgcHVzaGVkIHdpdGggaWRlbnRpY2FsXG4gKiBlbmdhZ2VtZW50IGNvdW50cyBcdTIwMTQgYXZvaWRzIGdlbmVyYXRpbmcgb25lIG5ldyByYXcvKiBmaWxlIGV2ZXJ5IGJyb3dzZS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0dGVkRW50cnkge1xuICB0czogc3RyaW5nOyAvLyBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IGNvbW1pdFxuICBzaWc6IHN0cmluZzsgLy8gZW5nYWdlbWVudCBzaWduYXR1cmU6IFwibGlrZXxydHxyZXBseXxxdW90ZVwiXG59XG5cbi8qKiBQcm9ncmVzcyArIGluZmxpZ2h0IHRyYWNraW5nIGZvciBhIHF1ZXVlLWRyaXZlbiBsb29wIChyZWZldGNoIC8gbWVkaWEtY3Jhd2wpLlxuICogVGhlIGxvb3AgcGVyc2lzdHMgdGhpcyBzbyBhIFNXIGV2aWN0aW9uIGluIHRoZSBtaWRkbGUgb2YgYSBydW4gcHJlc2VydmVzXG4gKiBcIlggb2YgWSBwcm9jZXNzZWRcIiBcdTIwMTQgYW5kIHRoZSB3YWl0LWZvci1pbmdlc3QgZ3VhcmQga25vd3Mgd2hhdCB0byBleHBlY3QuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTG9vcFNlc3Npb24ge1xuICAvKiogSW5pdGlhbCBxdWV1ZSBzaXplIHdoZW4gdGhlIHVzZXIgY2xpY2tlZCBcIlN0YXJ0XCIuICovXG4gIHRvdGFsQXRTdGFydDogbnVtYmVyO1xuICAvKiogVHdlZXRzIHByb2Nlc3NlZCAoaW5nZXN0ZWQgT1IgZHJvcHBlZCBhZnRlciByZXRyaWVzKSBzbyBmYXIuICovXG4gIHByb2Nlc3NlZDogbnVtYmVyO1xuICAvKiogSVNPIG9mIHdoZW4gdGhpcyBzZXNzaW9uIHN0YXJ0ZWQuICovXG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xuICAvKiogVHdlZXQgY3VycmVudGx5IGluZmxpZ2h0IFx1MjAxNCB3ZSBuYXZpZ2F0ZWQgdG8gaXQgYW5kIGFyZSB3YWl0aW5nIGZvciB0aGVcbiAgICogcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIHJlc3BvbnNlIGJlZm9yZSBhZHZhbmNpbmcuIG51bGwgYmV0d2VlbiB0aWNrc1xuICAgKiAoYW5kIG9uY2UgYW4gaW5nZXN0IGhhcyBiZWVuIG9ic2VydmVkKS4gKi9cbiAgaW5mbGlnaHQ6IHsgdHdlZXRJZDogc3RyaW5nOyBuYXZpZ2F0ZWRBdDogc3RyaW5nIH0gfCBudWxsO1xufVxuXG4vKiogQXV0by1zY3JvbGwgc2Vzc2lvbjogY291bnRzIG9mIHRpY2tzIGFuZCB0d2VldHMgaW5nZXN0ZWQgc2luY2UgdGhlIHVzZXJcbiAqIGNsaWNrZWQgU3RhcnQuIFBlcnNpc3RlZCBzbyBTVyBldmljdGlvbiBkdXJpbmcgYSBydW4ga2VlcHMgcHJvZ3Jlc3MuICovXG5leHBvcnQgaW50ZXJmYWNlIEF1dG9TY3JvbGxTZXNzaW9uIHtcbiAgc3RhcnRlZEF0OiBzdHJpbmc7XG4gIHNjcm9sbENvdW50OiBudW1iZXI7XG4gIGluZ2VzdGVkQ291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWROZXdDb3VudDogbnVtYmVyO1xuICBpbmdlc3RlZEV4aXN0aW5nQ291bnQ6IG51bWJlcjtcbiAgc2tpcHBlZE9sZENvdW50OiBudW1iZXI7XG4gIGV4cGFuZGVkQ291bnQ6IG51bWJlcjtcbn1cblxuaW50ZXJmYWNlIFN0b3JhZ2VTaGFwZSB7XG4gIHNldHRpbmdzOiBTZXR0aW5ncztcbiAgYWNjb3VudHM6IEFjY291bnRDb25maWdbXTtcbiAgLyoqIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3Qgc3VjY2Vzc2Z1bCBhY2NvdW50cy55YW1sIGZldGNoIGZyb20gdGhlIHJlcG8uXG4gICAqIFVzZWQgYnkgYHJlZnJlc2hBY2NvdW50c0xpc3RgIHRvIHNraXAgcmUtZmV0Y2hpbmcgb24gZXZlcnkgU1cgd2FrZSBcdTIwMTQgdGhlXG4gICAqIGZpbGUgY2hhbmdlcyByYXJlbHkgYW5kIGFuIGF1dGhlbnRpY2F0ZWQgcmF3IGZldGNoIGV2ZXJ5IHdha2UgYWRkcyB1cC4gKi9cbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogc3RyaW5nIHwgbnVsbDtcbiAgYXJjaGl2ZVNuYXBzaG90OiBBcmNoaXZlU25hcHNob3QgfCBudWxsO1xuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uU3RhdGU7XG4gIGNvdW50ZXJzOiBSZWNvcmQ8c3RyaW5nLCBBY2NvdW50Q291bnRlcj47XG4gIHJ1bkJ1ZmZlcnM6IFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj47XG4gIGFjdGl2aXR5OiBMb2dFdmVudFtdO1xuICByZWNlbnRUd2VldFNpZ2h0aW5nczogVHdlZXRTaWdodGluZ1tdO1xuICBjb21taXR0ZWRJbmRleDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PjtcbiAgLyoqIFR3ZWV0cyB0aGUgbm9ybWFsaXplciBmbGFnZ2VkIGFzIHRydW5jYXRlZCBhbmQgdGhhdCB3ZSBoYXZlbid0IHNlZW4gYVxuICAgKiBmdWxsLXRleHQgdmVyc2lvbiBvZiB5ZXQuIEtleWVkIGJ5IGhhbmRsZSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiAqL1xuICByZWZldGNoUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcbiAgLyoqIFR3ZWV0IElEcyBzZWVuIHZpYSBNZWRpYS10YWIgLyBwYXJ0aWFsIGNhcHR1cmVzIHRoYXQgY291bGRuJ3QgYmVcbiAgICogbm9ybWFsaXplZCBpbnRvIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIEtleWVkIGJ5IGhpbnQtaGFuZGxlIChvclxuICAgKiBcIl91bmtub3duXCIpIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuIFRoZSB1c2VyIGNhbiBkcml2ZSBhIGNyYXdsIHRoYXRcbiAgICogb3BlbnMgZWFjaCBkZXRhaWwgcGFnZSB0byBjYXB0dXJlIHRoZSByZWFsIHRoaW5nLiAqL1xuICBtZWRpYUNyYXdsUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcbiAgLyoqIENvcmUtYWNjb3VudCB0aHJlYWQgcm9vdHMgd29ydGggb3BlbmluZyBiZWNhdXNlIHRpbWVsaW5lL3NlYXJjaCB2aWV3cyBtYXlcbiAgICogb21pdCBsYXRlciBzZWxmLXJlcGxpZXMuIEtleWVkIGJ5IGhpbnQtaGFuZGxlIC0+IHJvb3QgdHdlZXQgaWRzLiAqL1xuICB0aHJlYWRPcGVuUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcbiAgLyoqIFJvb3QgdHdlZXQgaWRzIGFscmVhZHkgYXR0ZW1wdGVkIGJ5IHRoZSB0aHJlYWQtb3BlbmluZyB1dGlsaXR5LiAqL1xuICB0aHJlYWRPcGVuU2VlbjogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgcmVmZXRjaFNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcbiAgbWVkaWFDcmF3bFNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcbiAgdGhyZWFkT3BlblNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcbiAgYXV0b1Njcm9sbFNlc3Npb246IEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbDtcbn1cblxuY29uc3QgREVGQVVMVF9DT05ORUNUSU9OOiBDb25uZWN0aW9uU3RhdGUgPSB7XG4gIHN0YXR1czogJ3Vua25vd24nLFxuICBsb2dpbjogbnVsbCxcbiAgY2hlY2tlZEF0OiBudWxsLFxuICBlcnJvcjogbnVsbCxcbiAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbn07XG5cbmNvbnN0IERFRkFVTFRTOiBTdG9yYWdlU2hhcGUgPSB7XG4gIHNldHRpbmdzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MgfSxcbiAgYWNjb3VudHM6IFsuLi5GQUxMQkFDS19BQ0NPVU5UU10sXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IG51bGwsXG4gIGFyY2hpdmVTbmFwc2hvdDogbnVsbCxcbiAgY29ubmVjdGlvbjogeyAuLi5ERUZBVUxUX0NPTk5FQ1RJT04gfSxcbiAgY291bnRlcnM6IHt9LFxuICBydW5CdWZmZXJzOiB7fSxcbiAgYWN0aXZpdHk6IFtdLFxuICByZWNlbnRUd2VldFNpZ2h0aW5nczogW10sXG4gIGNvbW1pdHRlZEluZGV4OiB7fSxcbiAgcmVmZXRjaFF1ZXVlOiB7fSxcbiAgbWVkaWFDcmF3bFF1ZXVlOiB7fSxcbiAgdGhyZWFkT3BlblF1ZXVlOiB7fSxcbiAgdGhyZWFkT3BlblNlZW46IHt9LFxuICByZWZldGNoU2Vzc2lvbjogbnVsbCxcbiAgbWVkaWFDcmF3bFNlc3Npb246IG51bGwsXG4gIHRocmVhZE9wZW5TZXNzaW9uOiBudWxsLFxuICBhdXRvU2Nyb2xsU2Vzc2lvbjogbnVsbCxcbn07XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEspOiBQcm9taXNlPFN0b3JhZ2VTaGFwZVtLXT4ge1xuICBjb25zdCByZXN1bHQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KGtleSk7XG4gIGNvbnN0IHZhbHVlID0gcmVzdWx0W2tleV07XG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIHN0cnVjdHVyZWRDbG9uZShERUZBVUxUU1trZXldKTtcbiAgfVxuICByZXR1cm4gdmFsdWUgYXMgU3RvcmFnZVNoYXBlW0tdO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLLCB2YWx1ZTogU3RvcmFnZVNoYXBlW0tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBba2V5XTogdmFsdWUgfSk7XG59XG5cbi8vIC0tLSBTZXR0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gIC8vIEJhY2tmaWxsIGFueSBrZXlzIHRoZSB1c2VyJ3Mgc3RvcmVkIHNldHRpbmdzIHByZWRhdGUgXHUyMDE0IHJlYWRlcnMgY2FuIHJlbHlcbiAgLy8gb24gZXZlcnkgU2V0dGluZ3MgZmllbGQgYmVpbmcgcHJlc2VudCByYXRoZXIgdGhhbiBgPz8gZGVmYXVsdGluZ2AgYXRcbiAgLy8gZXZlcnkgY2FsbHNpdGUuIFRoZSBQQVQgaXMgc3RvcmVkIGVuY3J5cHRlZC1hdC1yZXN0IGFzIG9mIHYwLjIuMDsgd2VcbiAgLy8gZGVjcnlwdCB0cmFuc3BhcmVudGx5IHNvIGNhbGxlcnMgY29udGludWUgdG8gc2VlIHBsYWludGV4dC5cbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgZ2V0UmF3KCdzZXR0aW5ncycpO1xuICBjb25zdCBtZXJnZWQgPSB7IC4uLkRFRkFVTFRfU0VUVElOR1MsIC4uLnN0b3JlZCB9O1xuICBpZiAobWVyZ2VkLnBhdCAmJiBpc0VuY3J5cHRlZFBhdChtZXJnZWQucGF0KSkge1xuICAgIHRyeSB7XG4gICAgICBtZXJnZWQucGF0ID0gYXdhaXQgZGVjcnlwdFBhdChtZXJnZWQucGF0KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIG1lcmdlZC5wYXQgPSAnJztcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG1lcmdlZDtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBFbmNyeXB0IHRoZSBQQVQgYmVmb3JlIHBlcnNpc3Rpbmc7IGxlZ2FjeSBwbGFpbnRleHQgUEFUcyBnZXQgdXBncmFkZWRcbiAgLy8gb24gdGhlIG5leHQgc2F2ZS5cbiAgY29uc3QgdG9Xcml0ZTogU2V0dGluZ3MgPSB7IC4uLnMgfTtcbiAgaWYgKHRvV3JpdGUucGF0ICYmICFpc0VuY3J5cHRlZFBhdCh0b1dyaXRlLnBhdCkpIHtcbiAgICB0b1dyaXRlLnBhdCA9IGF3YWl0IGVuY3J5cHRQYXQodG9Xcml0ZS5wYXQpO1xuICB9XG4gIGF3YWl0IHNldFJhdygnc2V0dGluZ3MnLCB0b1dyaXRlKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVTZXR0aW5ncyhwYXRjaDogUGFydGlhbDxTZXR0aW5ncz4pOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IG5leHQgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYXdhaXQgc2V0U2V0dGluZ3MobmV4dCk7XG4gIHJldHVybiBuZXh0O1xufVxuXG4vLyAtLS0gQWNjb3VudHMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHMoKTogUHJvbWlzZTxBY2NvdW50Q29uZmlnW10+IHtcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHMnKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50cyhhOiBBY2NvdW50Q29uZmlnW10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50cycsIGEpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzUmVmcmVzaGVkQXQoKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzUmVmcmVzaGVkQXQnKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KGlzbzogc3RyaW5nIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzUmVmcmVzaGVkQXQnLCBpc28pO1xufVxuXG4vLyAtLS0gQXJjaGl2ZSBzbmFwc2hvdCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBcmNoaXZlU25hcHNob3QoKTogUHJvbWlzZTxBcmNoaXZlU25hcHNob3QgfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FyY2hpdmVTbmFwc2hvdCcpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXJjaGl2ZVNuYXBzaG90KHNuYXBzaG90OiBBcmNoaXZlU25hcHNob3QgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYXJjaGl2ZVNuYXBzaG90Jywgc25hcHNob3QpO1xufVxuXG4vLyAtLS0gQ29ubmVjdGlvbiBzdGF0ZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25uZWN0aW9uKCk6IFByb21pc2U8Q29ubmVjdGlvblN0YXRlPiB7XG4gIGNvbnN0IGMgPSBhd2FpdCBnZXRSYXcoJ2Nvbm5lY3Rpb24nKTtcbiAgLy8gQmFja2ZpbGwgZmllbGRzIGFkZGVkIGFmdGVyIHRoZSB1c2VyJ3Mgc3RvcmFnZSB3YXMgd3JpdHRlbi5cbiAgY29uc3Qgb3V0OiBDb25uZWN0aW9uU3RhdGUgPSB7XG4gICAgLi4uYyxcbiAgICBkZWZhdWx0QnJhbmNoOiBjLmRlZmF1bHRCcmFuY2ggPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmRlZmF1bHRCcmFuY2gsXG4gICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czpcbiAgICAgIGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcbiAgICByYXRlTGltaXRSZXNldEF0OiBjLnJhdGVMaW1pdFJlc2V0QXQgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLnJhdGVMaW1pdFJlc2V0QXQsXG4gIH07XG4gIHJldHVybiBvdXQ7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29ubmVjdGlvbihjOiBDb25uZWN0aW9uU3RhdGUpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdjb25uZWN0aW9uJywgYyk7XG59XG5cbi8vIC0tLSBDb3VudGVycyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmZ1bmN0aW9uIHRvZGF5SVNPKCk6IHN0cmluZyB7XG4gIHJldHVybiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q291bnRlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBBY2NvdW50Q291bnRlcj4+IHtcbiAgcmV0dXJuIGdldFJhdygnY291bnRlcnMnKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBidW1wQ291bnRlcihcbiAgaGFuZGxlOiBzdHJpbmcsXG4gIHBhdGNoOiBQYXJ0aWFsPEFjY291bnRDb3VudGVyPlxuKTogUHJvbWlzZTxBY2NvdW50Q291bnRlcj4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRDb3VudGVycygpO1xuICBjb25zdCBjdXIgPSBhbGxbaGFuZGxlXSA/PyB7XG4gICAgdG9kYXlDb3VudDogMCxcbiAgICB0b2RheURhdGU6IHRvZGF5SVNPKCksXG4gICAgbGFzdENhcHR1cmVBdDogbnVsbCxcbiAgICB0b3RhbENvbW1pdHRlZDogMCxcbiAgICBidWZmZXJlZENvdW50OiAwLFxuICB9O1xuICBpZiAoY3VyLnRvZGF5RGF0ZSAhPT0gdG9kYXlJU08oKSkge1xuICAgIGN1ci50b2RheURhdGUgPSB0b2RheUlTTygpO1xuICAgIGN1ci50b2RheUNvdW50ID0gMDtcbiAgfVxuICBjb25zdCBuZXh0OiBBY2NvdW50Q291bnRlciA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xuICBhbGxbaGFuZGxlXSA9IG5leHQ7XG4gIGF3YWl0IHNldFJhdygnY291bnRlcnMnLCBhbGwpO1xuICByZXR1cm4gbmV4dDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlOiBzdHJpbmcsIGNvdW50OiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnVtcENvdW50ZXIoaGFuZGxlLCB7IGJ1ZmZlcmVkQ291bnQ6IGNvdW50IH0pO1xufVxuXG4vLyAtLS0gUnVuIGJ1ZmZlcnMgKHRoZSBwZW5kaW5nIGNhcHR1cmVzIGF3YWl0aW5nIGNvbW1pdCkgLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5CdWZmZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdydW5CdWZmZXJzJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPFJ1bkJ1ZmZlciB8IG51bGw+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICByZXR1cm4gYWxsW2hhbmRsZV0gPz8gbnVsbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZywgYnVmOiBSdW5CdWZmZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBhbGxbaGFuZGxlXSA9IGJ1ZjtcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyUnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgZGVsZXRlIGFsbFtoYW5kbGVdO1xuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xufVxuXG4vLyAtLS0gQWN0aXZpdHkgdGFpbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWN0aXZpdHkoKTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FjdGl2aXR5Jyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBlbmRBY3Rpdml0eShldjogTG9nRXZlbnQpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0QWN0aXZpdHkoKTtcbiAgY3VyLnVuc2hpZnQoZXYpO1xuICBpZiAoY3VyLmxlbmd0aCA+IEFDVElWSVRZX1RBSUxfTUFYKSBjdXIubGVuZ3RoID0gQUNUSVZJVFlfVEFJTF9NQVg7XG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBjdXIpO1xuICByZXR1cm4gY3VyO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJBY3Rpdml0eSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIFtdKTtcbn1cblxuLy8gLS0tIFJlY2VudCB0d2VldCBzaWdodGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmNvbnN0IFJFQ0VOVF9UV0VFVF9TSUdIVElOR1NfTUFYID0gODA7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncygpOiBQcm9taXNlPFR3ZWV0U2lnaHRpbmdbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWNlbnRUd2VldFNpZ2h0aW5ncycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJlcGVuZFJlY2VudFR3ZWV0U2lnaHRpbmdzKHJvd3M6IFR3ZWV0U2lnaHRpbmdbXSk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAocm93cy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0UmVjZW50VHdlZXRTaWdodGluZ3MoKTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCBuZXh0OiBUd2VldFNpZ2h0aW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCByb3cgb2Ygcm93cykge1xuICAgIGNvbnN0IGtleSA9IGAke3Jvdy5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpfToke3Jvdy50d2VldF9pZH1gO1xuICAgIGlmIChzZWVuLmhhcyhrZXkpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChrZXkpO1xuICAgIG5leHQucHVzaChyb3cpO1xuICB9XG4gIGZvciAoY29uc3Qgcm93IG9mIGN1cikge1xuICAgIGNvbnN0IGtleSA9IGAke3Jvdy5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpfToke3Jvdy50d2VldF9pZH1gO1xuICAgIGlmIChzZWVuLmhhcyhrZXkpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChrZXkpO1xuICAgIG5leHQucHVzaChyb3cpO1xuICB9XG4gIG5leHQubGVuZ3RoID0gTWF0aC5taW4obmV4dC5sZW5ndGgsIFJFQ0VOVF9UV0VFVF9TSUdIVElOR1NfTUFYKTtcbiAgYXdhaXQgc2V0UmF3KCdyZWNlbnRUd2VldFNpZ2h0aW5ncycsIG5leHQpO1xufVxuXG4vLyAtLS0gQ29tbWl0dGVkLXR3ZWV0cyBkZWR1cCBpbmRleCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb21taXR0ZWRJbmRleCgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj4+IHtcbiAgcmV0dXJuIGdldFJhdygnY29tbWl0dGVkSW5kZXgnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbW1pdHRlZEluZGV4KFxuICBpZHg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj5cbik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2NvbW1pdHRlZEluZGV4JywgaWR4KTtcbn1cblxuLyoqIENvbXB1dGUgdGhlIGVuZ2FnZW1lbnQgc2lnbmF0dXJlIHdlIHVzZSB0byBkZWNpZGUgd2hldGhlciBhIHJlLWNhcHR1cmVkXG4gKiB0d2VldCBpcyBcIm1hdGVyaWFsbHkgZGlmZmVyZW50XCIgZnJvbSB3aGF0IHdlIGxhc3QgY29tbWl0dGVkLiBXZSBvbWl0XG4gKiB2aWV3X2NvdW50IGJlY2F1c2UgaXQgdGlja3MgdXAgZnJlcXVlbnRseSBvbiBhY3RpdmUgdHdlZXRzIGFuZCB3b3VsZFxuICogZGVmZWF0IHRoZSBkZWR1cC4gTGlrZXMgLyBSVHMgLyByZXBsaWVzIC8gcXVvdGVzIGNoYW5nZSByYXJlbHkgZW5vdWdoIHRoYXRcbiAqIGVhY2ggY2hhbmdlIGlzIHdvcnRoIGEgcmUtY29tbWl0IChhbmQgYW4gZW5nYWdlbWVudF9oaXN0b3J5IHNuYXBzaG90KS5cbiAqIGBpc190cnVuY2F0ZWRgIGlzIGZvbGRlZCBpbiBzbyBhIHJlZmV0Y2ggdGhhdCBzd2FwcyB0aGUgMjgwLWNoYXIgaGVhZCBmb3JcbiAqIHRoZSBmdWxsIGBub3RlX3R3ZWV0YCBib2R5IGJ5cGFzc2VzIHRoZSBkZWR1cCBldmVuIHdoZW4gZW5nYWdlbWVudCBjb3VudHNcbiAqIGhhdmVuJ3QgbW92ZWQgXHUyMDE0IG90aGVyd2lzZSB0aGUgbmV3IGJvZHkgd291bGQgYmUgc2lsZW50bHkgZHJvcHBlZC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbmdhZ2VtZW50U2lnKFxuICBsaWtlczogbnVtYmVyLFxuICByZXR3ZWV0czogbnVtYmVyLFxuICByZXBsaWVzOiBudW1iZXIsXG4gIHF1b3RlczogbnVtYmVyLFxuICBpc1RydW5jYXRlZDogYm9vbGVhbiA9IGZhbHNlXG4pOiBzdHJpbmcge1xuICByZXR1cm4gYCR7bGlrZXN9fCR7cmV0d2VldHN9fCR7cmVwbGllc318JHtxdW90ZXN9fCR7aXNUcnVuY2F0ZWQgPyAndCcgOiAnZid9YDtcbn1cblxuLyoqIERyb3AgZW50cmllcyBvbGRlciB0aGFuIGBtYXhBZ2VNc2AuIFJldHVybnMgdGhlIG51bWJlciBwcnVuZWQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJ1bmVDb21taXR0ZWRJbmRleChtYXhBZ2VNczogbnVtYmVyKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgY29uc3QgY3V0b2ZmID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIG1heEFnZU1zKS50b0lTT1N0cmluZygpO1xuICBsZXQgcHJ1bmVkID0gMDtcbiAgZm9yIChjb25zdCBoYW5kbGUgb2YgT2JqZWN0LmtleXMoaWR4KSkge1xuICAgIGNvbnN0IGlubmVyID0gaWR4W2hhbmRsZV07XG4gICAgaWYgKCFpbm5lcikgY29udGludWU7XG4gICAgZm9yIChjb25zdCB0aWQgb2YgT2JqZWN0LmtleXMoaW5uZXIpKSB7XG4gICAgICBjb25zdCBlID0gaW5uZXJbdGlkXTtcbiAgICAgIGlmIChlICYmIGUudHMgPCBjdXRvZmYpIHtcbiAgICAgICAgZGVsZXRlIGlubmVyW3RpZF07XG4gICAgICAgIHBydW5lZCArPSAxO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoT2JqZWN0LmtleXMoaW5uZXIpLmxlbmd0aCA9PT0gMCkgZGVsZXRlIGlkeFtoYW5kbGVdO1xuICB9XG4gIGlmIChwcnVuZWQgPiAwKSBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xuICByZXR1cm4gcHJ1bmVkO1xufVxuXG4vLyAtLS0gUmVmZXRjaCBxdWV1ZSAodHdlZXRzIG5lZWRpbmcgZnVsbC10ZXh0IHJlY2FwdHVyZSkgLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hRdWV1ZSgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoUXVldWUnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlZmV0Y2hRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgbGV0IHRvdGFsID0gMDtcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcbiAgcmV0dXJuIHRvdGFsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXSA/PyBbXTtcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcbiAgICBpZHMucHVzaCh0d2VldElkKTtcbiAgICBxW2hhbmRsZV0gPSBpZHM7XG4gICAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXTtcbiAgaWYgKCFpZHMpIHJldHVybjtcbiAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtoYW5kbGVdO1xuICBlbHNlIHFbaGFuZGxlXSA9IGZpbHRlcmVkO1xuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dFJlZmV0Y2hUYXJnZXQoKTogUHJvbWlzZTx7XG4gIGhhbmRsZTogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgaGFuZGxlLCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8vIC0tLSBNZWRpYS1jcmF3bCBxdWV1ZSAocGFydGlhbCBjYXB0dXJlcyBhd2FpdGluZyBkZXRhaWwtcGFnZSBmZXRjaCkgLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlTWVkaWFDcmF3bChoaW50SGFuZGxlOiBzdHJpbmcgfCBudWxsLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBjb25zdCBidWNrZXQgPSBoaW50SGFuZGxlID8/ICdfdW5rbm93bic7XG4gIGNvbnN0IGlkcyA9IHFbYnVja2V0XSA/PyBbXTtcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcbiAgICBpZHMucHVzaCh0d2VldElkKTtcbiAgICBxW2J1Y2tldF0gPSBpZHM7XG4gICAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZU1lZGlhQ3Jhd2wodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgZm9yIChjb25zdCBidWNrZXQgb2YgT2JqZWN0LmtleXMocSkpIHtcbiAgICBjb25zdCBpZHMgPSBxW2J1Y2tldF07XG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcbiAgICBpZiAoZmlsdGVyZWQubGVuZ3RoICE9PSBpZHMubGVuZ3RoKSB7XG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2J1Y2tldF07XG4gICAgICBlbHNlIHFbYnVja2V0XSA9IGZpbHRlcmVkO1xuICAgIH1cbiAgfVxuICBpZiAoY2hhbmdlZCkgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRNZWRpYUNyYXdsVGFyZ2V0KCk6IFByb21pc2U8e1xuICBidWNrZXQ6IHN0cmluZztcbiAgdHdlZXRJZDogc3RyaW5nO1xufSB8IG51bGw+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBmb3IgKGNvbnN0IFtidWNrZXQsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGJ1Y2tldCwgdHdlZXRJZDogaWRzWzBdISB9O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vLyAtLS0gVGhyZWFkLW9wZW5pbmcgcXVldWUgKGNvcmUgY29udmVyc2F0aW9uIHJvb3RzIHRvIHZpc2l0KSAtLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUaHJlYWRPcGVuUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygndGhyZWFkT3BlblF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB0aHJlYWRPcGVuUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhc1RocmVhZE9wZW5TZWVuKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCBzZWVuID0gYXdhaXQgZ2V0UmF3KCd0aHJlYWRPcGVuU2VlbicpO1xuICByZXR1cm4gdHdlZXRJZCBpbiBzZWVuO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWFya1RocmVhZE9wZW5TZWVuKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZWVuID0gYXdhaXQgZ2V0UmF3KCd0aHJlYWRPcGVuU2VlbicpO1xuICBzZWVuW3R3ZWV0SWRdID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5TZWVuJywgc2Vlbik7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlVGhyZWFkT3BlbihoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChhd2FpdCBoYXNUaHJlYWRPcGVuU2Vlbih0d2VldElkKSkgcmV0dXJuO1xuICBjb25zdCBxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXSA/PyBbXTtcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcbiAgICBpZHMucHVzaCh0d2VldElkKTtcbiAgICBxW2hhbmRsZV0gPSBpZHM7XG4gICAgYXdhaXQgc2V0UmF3KCd0aHJlYWRPcGVuUXVldWUnLCBxKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZVRocmVhZE9wZW4odHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgZm9yIChjb25zdCBidWNrZXQgb2YgT2JqZWN0LmtleXMocSkpIHtcbiAgICBjb25zdCBpZHMgPSBxW2J1Y2tldF07XG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcbiAgICBpZiAoZmlsdGVyZWQubGVuZ3RoICE9PSBpZHMubGVuZ3RoKSB7XG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2J1Y2tldF07XG4gICAgICBlbHNlIHFbYnVja2V0XSA9IGZpbHRlcmVkO1xuICAgIH1cbiAgfVxuICBpZiAoY2hhbmdlZCkgYXdhaXQgc2V0UmF3KCd0aHJlYWRPcGVuUXVldWUnLCBxKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRUaHJlYWRPcGVuVGFyZ2V0KCk6IFByb21pc2U8e1xuICBoYW5kbGU6IHN0cmluZztcbiAgdHdlZXRJZDogc3RyaW5nO1xufSB8IG51bGw+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGhhbmRsZSwgdHdlZXRJZDogaWRzWzBdISB9O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vKiogSGFzIHRoaXMgdHdlZXQgaWQgYWxyZWFkeSBiZWVuIGNvbW1pdHRlZCAoYW55IGhhbmRsZSk/IFVzZWQgdG8gc2tpcFxuICogZW5xdWV1ZWluZyBtZWRpYS1jcmF3bCB0YXJnZXRzIHdlJ3ZlIGFscmVhZHkgYXJjaGl2ZWQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNDb21taXR0ZWQodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGZvciAoY29uc3QgaW5uZXIgb2YgT2JqZWN0LnZhbHVlcyhpZHgpKSB7XG4gICAgaWYgKGlubmVyICYmIHR3ZWV0SWQgaW4gaW5uZXIpIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuLy8gLS0tIExvb3Agc2Vzc2lvbiBzdGF0ZSAocHJvZ3Jlc3MgKyBpbmZsaWdodCBnYXRpbmcpIC0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSZWZldGNoU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nLCBzKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUaHJlYWRPcGVuU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCd0aHJlYWRPcGVuU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFRocmVhZE9wZW5TZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5TZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTogUHJvbWlzZTxBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicsIHMpO1xufVxuXG4vLyAtLS0gUHVyZ2U6IHVucmVsYXRlZCBidWZmZXJzLCBjb3VudGVycywgcXVldWUgZW50cmllcyAtLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi8qKlxuICogRHJvcCBldmVyeSBwZXItaGFuZGxlIGJpdCBvZiBzdGF0ZSAoY291bnRlcnMsIHJ1biBidWZmZXIsIGNvbW1pdHRlZC1pbmRleFxuICogZW50cmllcywgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHF1ZXVlIGVudHJpZXMpIHRoYXQgZG9lc24ndCBjb3JyZXNwb25kIHRvIGFcbiAqIHRyYWNrZWQgYWNjb3VudC4gUmV0dXJucyBhIHN1bW1hcnkgZGVzY3JpYmluZyB3aGF0IHdhcyBjbGVhcmVkIHNvIHRoZVxuICogY2FsbGVyIGNhbiBsb2cgaXQuXG4gKlxuICogVHJhY2tlZCBhY2NvdW50cyBhcmUgcGFzc2VkIGluIChjYWxsZXIgcmVzb2x2ZXMgZnJvbSB0aGUgbGl2ZSBjb25maWcpLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHVyZ2VVbnJlbGF0ZWRTdGF0ZSh0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPik6IFByb21pc2U8e1xuICBjb3VudGVyc1JlbW92ZWQ6IG51bWJlcjtcbiAgYnVmZmVyc1JlbW92ZWQ6IG51bWJlcjtcbiAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQ6IG51bWJlcjtcbiAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XG4gIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkOiBudW1iZXI7XG4gIHRocmVhZE9wZW5JZHNSZW1vdmVkOiBudW1iZXI7XG59PiB7XG4gIGNvbnN0IHRhcmdMb3dlciA9IG5ldyBTZXQoWy4uLnRhcmdldGVkXS5tYXAoKGgpID0+IGgudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBpc1RhcmdldGVkID0gKGg6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGFyZ0xvd2VyLmhhcyhoLnRvTG93ZXJDYXNlKCkpO1xuXG4gIC8vIENvdW50ZXJzXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgbGV0IGNvdW50ZXJzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhjb3VudGVycykpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBjb3VudGVyc1toXTtcbiAgICAgIGNvdW50ZXJzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgY291bnRlcnMpO1xuXG4gIC8vIFJ1biBidWZmZXJzXG4gIGNvbnN0IGJ1ZmZlcnMgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGxldCBidWZmZXJzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhidWZmZXJzKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIGJ1ZmZlcnNbaF07XG4gICAgICBidWZmZXJzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBidWZmZXJzKTtcblxuICAvLyBDb21taXR0ZWQgZGVkdXAgaW5kZXhcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgbGV0IGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBpZHhbaF07XG4gICAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xuXG4gIC8vIFJlZmV0Y2ggcXVldWU6IGJ1Y2tldHMgYXJlIGtleWVkIGJ5IGhhbmRsZS5cbiAgY29uc3QgcnEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgbGV0IHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhycSkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBycVtoXTtcbiAgICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHJxKTtcblxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogYnVja2V0cyBhcmUgaGludC1oYW5kbGVzIChvciBcIl91bmtub3duXCIpLiBEcm9wXG4gIC8vIGVudHJpZXMgd2hvc2UgYnVja2V0IGlzbid0IHRhcmdldGVkIFx1MjAxNCBpbmNsdWRpbmcgXCJfdW5rbm93blwiIHNpbmNlIHdlXG4gIC8vIGNhbid0IHZlcmlmeSByZWxhdGlvbi5cbiAgY29uc3QgbXEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgbGV0IG1lZGlhQ3Jhd2xJZHNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKG1xKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgbWVkaWFDcmF3bElkc1JlbW92ZWQgKz0gKG1xW2hdID8/IFtdKS5sZW5ndGg7XG4gICAgICBkZWxldGUgbXFbaF07XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgbXEpO1xuXG4gIGNvbnN0IHRxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XG4gIGxldCB0aHJlYWRPcGVuSWRzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyh0cSkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIHRocmVhZE9wZW5JZHNSZW1vdmVkICs9ICh0cVtoXSA/PyBbXSkubGVuZ3RoO1xuICAgICAgZGVsZXRlIHRxW2hdO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5RdWV1ZScsIHRxKTtcblxuICByZXR1cm4ge1xuICAgIGNvdW50ZXJzUmVtb3ZlZCxcbiAgICBidWZmZXJzUmVtb3ZlZCxcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcbiAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQsXG4gICAgbWVkaWFDcmF3bElkc1JlbW92ZWQsXG4gICAgdGhyZWFkT3Blbklkc1JlbW92ZWQsXG4gIH07XG59XG5cbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbn1cbiIsICIvKipcbiAqIG9wdGlvbnMudHMgXHUyMDE0IHNldHRpbmdzIHBhZ2UuXG4gKlxuICogU3RvcmVzIFBBVCBhbmQgcmVwbyBpZGVudGlmaWVycyBpbiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgdmVyaWZpZXMgYWNjZXNzXG4gKiBieSBjYWxsaW5nIC91c2VyIGFuZCAvcmVwb3MvOm93bmVyLzpyZXBvLCBhbmQgc3VyZmFjZXMgdGhlIHJlc3VsdGluZ1xuICogY29ubmVjdGlvbiBzdGF0ZS5cbiAqL1xuXG5pbXBvcnQgeyBERUZBVUxUX1NFVFRJTkdTIH0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcbmltcG9ydCB7XG4gIGNsZWFyQWxsLFxuICBnZXRBY2NvdW50cyxcbiAgZ2V0QWN0aXZpdHksXG4gIGdldEFyY2hpdmVTbmFwc2hvdCxcbiAgZ2V0Q29ubmVjdGlvbixcbiAgZ2V0Q291bnRlcnMsXG4gIGdldFJ1bkJ1ZmZlcnMsXG4gIGdldFNldHRpbmdzLFxuICB1cGRhdGVTZXR0aW5ncyxcbn0gZnJvbSAnLi9saWIvc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7IFJ1bnRpbWVNZXNzYWdlIH0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xuXG5jb25zdCAkID0gPFQgZXh0ZW5kcyBIVE1MRWxlbWVudCA9IEhUTUxFbGVtZW50PihpZDogc3RyaW5nKTogVCA9PiB7XG4gIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xuICBpZiAoIWVsKSB0aHJvdyBuZXcgRXJyb3IoYG1pc3NpbmcgZWxlbWVudCAjJHtpZH1gKTtcbiAgcmV0dXJuIGVsIGFzIFQ7XG59O1xuXG5jb25zdCBmb3JtID0gJDxIVE1MRm9ybUVsZW1lbnQ+KCdzZXR0aW5ncy1mb3JtJyk7XG5jb25zdCBvd25lcklucHV0ID0gJDxIVE1MSW5wdXRFbGVtZW50Pignb3duZXInKTtcbmNvbnN0IHJlcG9JbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ3JlcG8nKTtcbmNvbnN0IGJyYW5jaElucHV0ID0gJDxIVE1MSW5wdXRFbGVtZW50PignYnJhbmNoJyk7XG5jb25zdCBwYXRJbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ3BhdCcpO1xuY29uc3QgcmV2ZWFsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JldmVhbC1wYXQnKTtcbmNvbnN0IHNhdmVTdGF0dXMgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3NhdmUtc3RhdHVzJyk7XG5jb25zdCBjb25uRGV0YWlsID0gJCgnY29ubi1kZXRhaWwnKTtcbmNvbnN0IGFjY291bnRMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWNjb3VudC1yZWFkb25seScpO1xuY29uc3QgcmVmcmVzaEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZWZyZXNoLWFjY291bnRzJyk7XG5jb25zdCBkaWFnQm94ID0gJDxIVE1MVGV4dEFyZWFFbGVtZW50PignZGlhZ25vc3RpY3MnKTtcbmNvbnN0IGNvcHlEaWFnQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NvcHktZGlhZ25vc3RpY3MnKTtcbmNvbnN0IGNsZWFyU3RvcmFnZUJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjbGVhci1zdG9yYWdlJyk7XG5jb25zdCBkaWFnU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdkaWFnLXN0YXR1cycpO1xuXG5hc3luYyBmdW5jdGlvbiBzZW5kPFQ+KG1zZzogUnVudGltZU1lc3NhZ2UpOiBQcm9taXNlPFQ+IHtcbiAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZShtc2cpIGFzIFByb21pc2U8VD47XG59XG5cbmZ1bmN0aW9uIHNldFN0YXR1cyhlbDogSFRNTEVsZW1lbnQsIGtpbmQ6ICdvaycgfCAnZXJyJyB8ICd3YXJuJyB8ICcnLCBtc2c6IHN0cmluZyk6IHZvaWQge1xuICBlbC5jbGFzc05hbWUgPSBraW5kID8gYHN0YXR1cyAke2tpbmR9YCA6ICdzdGF0dXMnO1xuICBlbC50ZXh0Q29udGVudCA9IG1zZztcbn1cblxuZnVuY3Rpb24gaXNXcml0ZUF1dGhFcnJvcihtZXNzYWdlOiBzdHJpbmcgfCBudWxsKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnICYmXG4gICAgL1Jlc291cmNlIG5vdCBhY2Nlc3NpYmxlIGJ5IHBlcnNvbmFsIGFjY2VzcyB0b2tlbnxcXC9naXRcXC9ibG9ic3xcXC9naXRcXC9yZWZzL2kudGVzdChtZXNzYWdlKVxuICApO1xufVxuXG5hc3luYyBmdW5jdGlvbiBsb2FkU2V0dGluZ3MoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBvd25lcklucHV0LnZhbHVlID0gcy5vd25lciB8fCBERUZBVUxUX1NFVFRJTkdTLm93bmVyO1xuICByZXBvSW5wdXQudmFsdWUgPSBzLnJlcG8gfHwgREVGQVVMVF9TRVRUSU5HUy5yZXBvO1xuICBicmFuY2hJbnB1dC52YWx1ZSA9IHMuYnJhbmNoIHx8IERFRkFVTFRfU0VUVElOR1MuYnJhbmNoO1xuICBpZiAocy5wYXQpIHtcbiAgICBwYXRJbnB1dC52YWx1ZSA9IHMucGF0O1xuICAgIHBhdElucHV0LnBsYWNlaG9sZGVyID0gYFx1MjAyNiR7cy5wYXQuc2xpY2UoLTQpfWA7XG4gIH1cbiAgYXdhaXQgcGFpbnRDb25uRGV0YWlsKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHBhaW50Q29ubkRldGFpbCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IGxpbmVzOiBzdHJpbmdbXSA9IFtdO1xuICBsaW5lcy5wdXNoKGBTdGF0dXM6ICR7Y29ubi5zdGF0dXN9YCk7XG4gIGlmIChjb25uLmxvZ2luKSBsaW5lcy5wdXNoKGBMb2dnZWQgaW4gYXM6IEAke2Nvbm4ubG9naW59YCk7XG4gIGxpbmVzLnB1c2goYFJlcG9zaXRvcnk6ICR7cy5vd25lciB8fCAnPyd9LyR7cy5yZXBvIHx8ICc/J31AJHtzLmJyYW5jaCB8fCAnPyd9YCk7XG4gIGlmIChjb25uLmNoZWNrZWRBdCkgbGluZXMucHVzaChgTGFzdCBjaGVja2VkOiAke2Nvbm4uY2hlY2tlZEF0fWApO1xuICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IHJlc2V0SXNvID0gbmV3IERhdGUoY29ubi5yYXRlTGltaXRSZXNldEF0ICogMTAwMCkudG9JU09TdHJpbmcoKTtcbiAgICBjb25zdCBkZWx0YVNlYyA9IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAtIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICAgIGNvbnN0IGluTGFiZWwgPVxuICAgICAgZGVsdGFTZWMgPD0gMFxuICAgICAgICA/ICdtb21lbnRhcmlseSdcbiAgICAgICAgOiBkZWx0YVNlYyA8IDYwXG4gICAgICAgICAgPyBgaW4gJHtkZWx0YVNlY31zYFxuICAgICAgICAgIDogZGVsdGFTZWMgPCAzNjAwXG4gICAgICAgICAgICA/IGBpbiAke01hdGgucm91bmQoZGVsdGFTZWMgLyA2MCl9bWBcbiAgICAgICAgICAgIDogYGluICR7TWF0aC5yb3VuZChkZWx0YVNlYyAvIDM2MDApfWhgO1xuICAgIGxpbmVzLnB1c2goYFJhdGUgbGltaXQgcmVzZXRzOiAke3Jlc2V0SXNvfSAoJHtpbkxhYmVsfSlgKTtcbiAgfVxuICBpZiAoY29ubi5lcnJvcikgbGluZXMucHVzaChgRXJyb3I6ICR7Y29ubi5lcnJvcn1gKTtcbiAgY29ubkRldGFpbC50ZXh0Q29udGVudCA9IGxpbmVzLmpvaW4oJ1xcbicpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBwYWludEFjY291bnRzKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBsaXN0ID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgYWNjb3VudExpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGZvciAoY29uc3QgYSBvZiBsaXN0KSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGNvbnN0IGhhbmRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBoYW5kbGUuY2xhc3NOYW1lID0gJ2hhbmRsZSc7XG4gICAgaGFuZGxlLnRleHRDb250ZW50ID0gYEAke2EuaGFuZGxlfWA7XG4gICAgY29uc3QgbGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgbGFiZWwuY2xhc3NOYW1lID0gJ2xhYmVsJztcbiAgICBsYWJlbC50ZXh0Q29udGVudCA9IGEubGFiZWw7XG4gICAgbGkuYXBwZW5kKGhhbmRsZSwgbGFiZWwpO1xuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XG4gIH1cbn1cblxuZm9ybS5hZGRFdmVudExpc3RlbmVyKCdzdWJtaXQnLCBhc3luYyAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICBjb25zdCBwYXQgPSBwYXRJbnB1dC52YWx1ZS50cmltKCk7XG4gIGNvbnN0IG93bmVyID0gb3duZXJJbnB1dC52YWx1ZS50cmltKCk7XG4gIGNvbnN0IHJlcG8gPSByZXBvSW5wdXQudmFsdWUudHJpbSgpO1xuICBjb25zdCBicmFuY2ggPSBicmFuY2hJbnB1dC52YWx1ZS50cmltKCkgfHwgJ21haW4nO1xuICBpZiAoIXBhdCB8fCAhb3duZXIgfHwgIXJlcG8pIHtcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ2VycicsICdBbGwgZmllbGRzIGFyZSByZXF1aXJlZC4nKTtcbiAgICByZXR1cm47XG4gIH1cbiAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICcnLCAnU2F2aW5nXHUyMDI2Jyk7XG4gIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgcGF0LCBvd25lciwgcmVwbywgYnJhbmNoLCBjb25maWd1cmVkQXQ6IERhdGUubm93KCkgfSk7XG4gIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnJywgJ1ZlcmlmeWluZ1x1MjAyNicpO1xuICBhd2FpdCBzZW5kKHsgdHlwZTogJ3ZlcmlmeS1jb25uZWN0aW9uJyB9KTtcbiAgYXdhaXQgc2VuZCh7IHR5cGU6ICdyZWZyZXNoLWFjY291bnRzJyB9KTtcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgaWYgKGNvbm4uc3RhdHVzID09PSAnb2snKSB7XG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICdvaycsIGBDb25uZWN0ZWQgYXMgQCR7Y29ubi5sb2dpbiA/PyAnPyd9LmApO1xuICB9IGVsc2UgaWYgKGNvbm4uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcbiAgICBzZXRTdGF0dXMoXG4gICAgICBzYXZlU3RhdHVzLFxuICAgICAgJ2VycicsXG4gICAgICBpc1dyaXRlQXV0aEVycm9yKGNvbm4uZXJyb3IpXG4gICAgICAgID8gJ1BBVCBjYW4gcmVhZCB0aGlzIHJlcG8gYnV0IGNhbm5vdCB3cml0ZS4gU2V0IENvbnRlbnRzOiBSZWFkICYgV3JpdGUuJ1xuICAgICAgICA6ICdBdXRoIGZhaWxlZCAtIGNoZWNrIHRoZSBQQVQgYW5kIGl0cyByZXBvIHNjb3BlLidcbiAgICApO1xuICB9IGVsc2UgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJykge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnd2FybicsICdSYXRlLWxpbWl0ZWQgXHUyMDE0IHRva2VuIGlzIHZhbGlkIGJ1dCBHaXRIdWIgaXMgdGhyb3R0bGluZy4nKTtcbiAgfSBlbHNlIGlmIChjb25uLnN0YXR1cyA9PT0gJ25ldHdvcmstZXJyb3InKSB7XG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICdlcnInLCAnTmV0d29yayBlcnJvciBcdTIwMTQgY2hlY2sgY29ubmVjdGl2aXR5LicpO1xuICB9IGVsc2Uge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgYFZlcmlmaWNhdGlvbjogJHtjb25uLnN0YXR1c31gKTtcbiAgfVxuICBhd2FpdCBwYWludENvbm5EZXRhaWwoKTtcbiAgYXdhaXQgcGFpbnRBY2NvdW50cygpO1xuICBhd2FpdCByZWZyZXNoRGlhZygpO1xufSk7XG5cbnJldmVhbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgaWYgKHBhdElucHV0LnR5cGUgPT09ICdwYXNzd29yZCcpIHtcbiAgICBwYXRJbnB1dC50eXBlID0gJ3RleHQnO1xuICAgIHJldmVhbEJ0bi50ZXh0Q29udGVudCA9ICdIaWRlJztcbiAgfSBlbHNlIHtcbiAgICBwYXRJbnB1dC50eXBlID0gJ3Bhc3N3b3JkJztcbiAgICByZXZlYWxCdG4udGV4dENvbnRlbnQgPSAnU2hvdyc7XG4gIH1cbn0pO1xuXG5yZWZyZXNoQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICByZWZyZXNoQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ3JlZnJlc2gtYWNjb3VudHMnIH0pO1xuICAgIGF3YWl0IHBhaW50QWNjb3VudHMoKTtcbiAgICBzZXRTdGF0dXMoZGlhZ1N0YXR1cywgJ29rJywgJ0FjY291bnRzIHJlZnJlc2hlZC4nKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICdlcnInLCBgUmVmcmVzaCBmYWlsZWQ6ICR7KGVyciBhcyBFcnJvcikubWVzc2FnZX1gKTtcbiAgfSBmaW5hbGx5IHtcbiAgICByZWZyZXNoQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoRGlhZygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgW3NldHRpbmdzLCBjb25uLCBhY2NvdW50cywgY291bnRlcnMsIGJ1ZmZlcnMsIGFjdGl2aXR5LCBhcmNoaXZlU25hcHNob3RdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgIGdldFNldHRpbmdzKCksXG4gICAgZ2V0Q29ubmVjdGlvbigpLFxuICAgIGdldEFjY291bnRzKCksXG4gICAgZ2V0Q291bnRlcnMoKSxcbiAgICBnZXRSdW5CdWZmZXJzKCksXG4gICAgZ2V0QWN0aXZpdHkoKSxcbiAgICBnZXRBcmNoaXZlU25hcHNob3QoKSxcbiAgXSk7XG4gIGNvbnN0IHJlZGFjdGVkQnVmZmVycyA9IE9iamVjdC5mcm9tRW50cmllcyhcbiAgICBPYmplY3QuZW50cmllcyhidWZmZXJzKS5tYXAoKFtrLCBiXSkgPT4gW1xuICAgICAgayxcbiAgICAgIHtcbiAgICAgICAgcnVuX2lkOiBiLnJ1bl9pZCxcbiAgICAgICAgc3RhcnRlZF9hdDogYi5zdGFydGVkX2F0LFxuICAgICAgICBsYXN0X2NhcHR1cmVfYXQ6IGIubGFzdF9jYXB0dXJlX2F0LFxuICAgICAgICB0d2VldHNfY291bnQ6IE9iamVjdC5rZXlzKGIudHdlZXRzX2J5X2lkKS5sZW5ndGgsXG4gICAgICAgIG9ic2VydmVkX2NvdW50OiBiLnR3ZWV0X2lkc19vYnNlcnZlZC5sZW5ndGgsXG4gICAgICAgIGVuZHBvaW50c19zZWVuOiBiLmVuZHBvaW50c19zZWVuLFxuICAgICAgICBzb3VyY2VfdXJsOiBiLnNvdXJjZV91cmwsXG4gICAgICB9LFxuICAgIF0pXG4gICk7XG4gIGNvbnN0IGR1bXAgPSB7XG4gICAgdmVyc2lvbjogYnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbixcbiAgICB1c2VyX2FnZW50OiBuYXZpZ2F0b3IudXNlckFnZW50LFxuICAgIHNldHRpbmdzOiB7XG4gICAgICBvd25lcjogc2V0dGluZ3Mub3duZXIsXG4gICAgICByZXBvOiBzZXR0aW5ncy5yZXBvLFxuICAgICAgYnJhbmNoOiBzZXR0aW5ncy5icmFuY2gsXG4gICAgICBhdXRvQ2FwdHVyZTogc2V0dGluZ3MuYXV0b0NhcHR1cmUsXG4gICAgICB1cGRhdGVFeGlzdGluZzogc2V0dGluZ3MudXBkYXRlRXhpc3RpbmcsXG4gICAgICBjb25maWd1cmVkQXQ6IHNldHRpbmdzLmNvbmZpZ3VyZWRBdCxcbiAgICAgIHBhdFNldDogc2V0dGluZ3MucGF0Lmxlbmd0aCA+IDAsXG4gICAgICBwYXRTdWZmaXg6IHNldHRpbmdzLnBhdC5sZW5ndGggPj0gNCA/IHNldHRpbmdzLnBhdC5zbGljZSgtNCkgOiAnJyxcbiAgICB9LFxuICAgIGNvbm5lY3Rpb246IGNvbm4sXG4gICAgYWNjb3VudHMsXG4gICAgY291bnRlcnMsXG4gICAgYXJjaGl2ZVNuYXBzaG90OiBhcmNoaXZlU25hcHNob3RcbiAgICAgID8ge1xuICAgICAgICAgIGdlbmVyYXRlZF9hdDogYXJjaGl2ZVNuYXBzaG90LmdlbmVyYXRlZF9hdCxcbiAgICAgICAgICBmZXRjaGVkX2F0OiBhcmNoaXZlU25hcHNob3QuZmV0Y2hlZF9hdCxcbiAgICAgICAgICBhY2NvdW50czogT2JqZWN0LmtleXMoYXJjaGl2ZVNuYXBzaG90LmFjY291bnRzKS5sZW5ndGgsXG4gICAgICAgIH1cbiAgICAgIDogbnVsbCxcbiAgICBydW5CdWZmZXJzOiByZWRhY3RlZEJ1ZmZlcnMsXG4gICAgYWN0aXZpdHlfdGFpbF9zaXplOiBhY3Rpdml0eS5sZW5ndGgsXG4gICAgYWN0aXZpdHlfcmVjZW50OiBhY3Rpdml0eS5zbGljZSgwLCAzMCksXG4gIH07XG4gIGRpYWdCb3gudmFsdWUgPSBKU09OLnN0cmluZ2lmeShkdW1wLCBudWxsLCAyKTtcbn1cblxuY29weURpYWdCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGF3YWl0IG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KGRpYWdCb3gudmFsdWUpO1xuICBzZXRTdGF0dXMoZGlhZ1N0YXR1cywgJ29rJywgJ0NvcGllZCBkaWFnbm9zdGljcyB0byBjbGlwYm9hcmQuJyk7XG59KTtcblxuY2xlYXJTdG9yYWdlQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBjb25zdCBvayA9IHdpbmRvdy5jb25maXJtKFxuICAgICdDbGVhciBleHRlbnNpb24gc3RvcmFnZT8gVGhpcyBlcmFzZXMgeW91ciBQQVQsIHNldHRpbmdzLCBjb3VudGVycywgYnVmZmVyZWQgY2FwdHVyZXMsIGFuZCBhY3Rpdml0eSB0YWlsLiBUaGVyZSBpcyBubyB1bmRvLidcbiAgKTtcbiAgaWYgKCFvaykgcmV0dXJuO1xuICBhd2FpdCBjbGVhckFsbCgpO1xuICBzZXRTdGF0dXMoZGlhZ1N0YXR1cywgJ3dhcm4nLCAnU3RvcmFnZSBjbGVhcmVkLicpO1xuICBhd2FpdCBsb2FkU2V0dGluZ3MoKTtcbiAgYXdhaXQgcGFpbnRBY2NvdW50cygpO1xuICBhd2FpdCByZWZyZXNoRGlhZygpO1xufSk7XG5cbnZvaWQgbG9hZFNldHRpbmdzKCk7XG52b2lkIHBhaW50QWNjb3VudHMoKTtcbnZvaWQgcmVmcmVzaERpYWcoKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFBQSxFQUNQLE1BQU07QUFBQTtBQUFBO0FBQUEsRUFHTixRQUFRO0FBQUEsRUFDUixTQUFTO0FBQUEsRUFDVCxhQUFhO0FBQUEsRUFDYixjQUFjO0FBQUEsRUFDZCx1QkFBdUI7QUFBQSxFQUN2QixnQkFBZ0I7QUFDbEI7QUFPTyxJQUFNLG9CQUFxQztBQUFBLEVBQ2hELEVBQUUsUUFBUSxVQUFVLE9BQU8sbUNBQW1DLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxVQUFVLE9BQU8sNENBQTRDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxPQUFPLE9BQU8sc0NBQXNDLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxTQUFTLE9BQU8sNkNBQTZDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxjQUFjLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUFBLEVBQ25FLEVBQUUsUUFBUSxZQUFZLE9BQU8sK0JBQStCLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sa0NBQWtDLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sNEJBQTRCLFVBQVUsT0FBTztBQUFBLEVBQ3ZFLEVBQUUsUUFBUSxtQkFBbUIsT0FBTyxxQkFBcUIsVUFBVSxPQUFPO0FBQzVFO0FBOERPLElBQU0sZ0NBQWdDLEtBQUssS0FBSzs7O0FDckV2RCxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGtCQUFrQjtBQUV4QixJQUFJLGtCQUFvQztBQUN4QyxJQUFJLHNCQUFxQztBQUV6QyxTQUFTLFNBQVMsS0FBeUI7QUFDekMsTUFBSSxJQUFJO0FBQ1IsYUFBVyxLQUFLLElBQUssTUFBSyxPQUFPLGFBQWEsQ0FBQztBQUMvQyxTQUFPLEtBQUssQ0FBQztBQUNmO0FBRUEsU0FBUyxXQUFXLEdBQXVCO0FBQ3pDLFFBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsUUFBTSxNQUFNLElBQUksV0FBVyxJQUFJLE1BQU07QUFDckMsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsSUFBSyxLQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQztBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxlQUFlLG1CQUFtRTtBQUNoRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUMvRCxRQUFNLElBQUksT0FBTyxnQkFBZ0I7QUFDakMsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxXQUFPLEVBQUUsU0FBUyxHQUFHLE1BQU0sV0FBVyxDQUFDLEVBQUU7QUFBQSxFQUMzQztBQUNBLFFBQU0sT0FBTyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxTQUFTLElBQUk7QUFDN0IsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUM7QUFDL0QsU0FBTyxFQUFFLFNBQVMsS0FBSztBQUN6QjtBQUVBLGVBQWUsWUFBZ0M7QUFDN0MsUUFBTSxFQUFFLFNBQVMsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBQ2pELE1BQUksb0JBQW9CLFFBQVEsd0JBQXdCLFNBQVM7QUFDL0QsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUU7QUFBQSxJQUM3QixHQUFHLFFBQVEsUUFBUSxFQUFFLElBQUksUUFBUSxRQUFRLFlBQVksRUFBRSxPQUFPO0FBQUEsRUFDaEU7QUFDQSxRQUFNLFdBQVcsSUFBSSxXQUFXLEtBQUssU0FBUyxLQUFLLE1BQU07QUFDekQsV0FBUyxJQUFJLE1BQU0sQ0FBQztBQUNwQixXQUFTLElBQUksTUFBTSxLQUFLLE1BQU07QUFDOUIsUUFBTSxPQUFPLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxRQUFRO0FBQzNELFFBQU0sTUFBTSxNQUFNLE9BQU8sT0FBTyxVQUFVLE9BQU8sTUFBTSxFQUFFLE1BQU0sVUFBVSxHQUFHLE9BQU87QUFBQSxJQUNqRjtBQUFBLElBQ0E7QUFBQSxFQUNGLENBQUM7QUFDRCxvQkFBa0I7QUFDbEIsd0JBQXNCO0FBQ3RCLFNBQU87QUFDVDtBQUVPLFNBQVMsZUFBZSxHQUFvQjtBQUNqRCxTQUFPLEVBQUUsV0FBVyxlQUFlO0FBQ3JDO0FBRUEsZUFBc0IsV0FBVyxXQUFvQztBQUNuRSxNQUFJLENBQUMsVUFBVyxRQUFPO0FBQ3ZCLFFBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsUUFBTSxLQUFLLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDcEQsUUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsSUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBRztBQUFBLElBQ3RCO0FBQUEsSUFDQSxJQUFJLFlBQVksRUFBRSxPQUFPLFNBQVM7QUFBQSxFQUNwQztBQUNBLFNBQU8sR0FBRyxlQUFlLEdBQUcsU0FBUyxFQUFFLENBQUMsSUFBSSxTQUFTLElBQUksV0FBVyxFQUFFLENBQUMsQ0FBQztBQUMxRTtBQUVBLGVBQXNCLFdBQVcsVUFBbUM7QUFDbEUsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUd0QixNQUFJLENBQUMsU0FBUyxXQUFXLGVBQWUsRUFBRyxRQUFPO0FBQ2xELFFBQU0sUUFBUSxTQUFTLE1BQU0sZ0JBQWdCLE1BQU0sRUFBRSxNQUFNLEdBQUc7QUFDOUQsTUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBQy9CLFFBQU0sQ0FBQyxPQUFPLEtBQUssSUFBSTtBQUN2QixNQUFJLENBQUMsU0FBUyxDQUFDLE1BQU8sUUFBTztBQUM3QixNQUFJO0FBQ0YsVUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsTUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBdUI7QUFBQSxNQUMxQztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsV0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEVBQUU7QUFBQSxFQUNwQyxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjs7O0FDWEEsSUFBTSxxQkFBc0M7QUFBQSxFQUMxQyxRQUFRO0FBQUEsRUFDUixPQUFPO0FBQUEsRUFDUCxXQUFXO0FBQUEsRUFDWCxPQUFPO0FBQUEsRUFDUCxlQUFlO0FBQUEsRUFDZix3QkFBd0I7QUFBQSxFQUN4QixrQkFBa0I7QUFDcEI7QUFFQSxJQUFNLFdBQXlCO0FBQUEsRUFDN0IsVUFBVSxFQUFFLEdBQUcsaUJBQWlCO0FBQUEsRUFDaEMsVUFBVSxDQUFDLEdBQUcsaUJBQWlCO0FBQUEsRUFDL0IscUJBQXFCO0FBQUEsRUFDckIsaUJBQWlCO0FBQUEsRUFDakIsWUFBWSxFQUFFLEdBQUcsbUJBQW1CO0FBQUEsRUFDcEMsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLENBQUM7QUFBQSxFQUNiLFVBQVUsQ0FBQztBQUFBLEVBQ1gsc0JBQXNCLENBQUM7QUFBQSxFQUN2QixnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGNBQWMsQ0FBQztBQUFBLEVBQ2YsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixpQkFBaUIsQ0FBQztBQUFBLEVBQ2xCLGdCQUFnQixDQUFDO0FBQUEsRUFDakIsZ0JBQWdCO0FBQUEsRUFDaEIsbUJBQW1CO0FBQUEsRUFDbkIsbUJBQW1CO0FBQUEsRUFDbkIsbUJBQW1CO0FBQ3JCO0FBRUEsZUFBZSxPQUFxQyxLQUFrQztBQUNwRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDbEQsUUFBTSxRQUFRLE9BQU8sR0FBRztBQUN4QixNQUFJLFVBQVUsUUFBVztBQUN2QixXQUFPLGdCQUFnQixTQUFTLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBQ0EsU0FBTztBQUNUO0FBRUEsZUFBZSxPQUFxQyxLQUFRLE9BQXVDO0FBQ2pHLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQztBQUNsRDtBQUlBLGVBQXNCLGNBQWlDO0FBS3JELFFBQU0sU0FBUyxNQUFNLE9BQU8sVUFBVTtBQUN0QyxRQUFNLFNBQVMsRUFBRSxHQUFHLGtCQUFrQixHQUFHLE9BQU87QUFDaEQsTUFBSSxPQUFPLE9BQU8sZUFBZSxPQUFPLEdBQUcsR0FBRztBQUM1QyxRQUFJO0FBQ0YsYUFBTyxNQUFNLE1BQU0sV0FBVyxPQUFPLEdBQUc7QUFBQSxJQUMxQyxRQUFRO0FBQ04sYUFBTyxNQUFNO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixZQUFZLEdBQTRCO0FBRzVELFFBQU0sVUFBb0IsRUFBRSxHQUFHLEVBQUU7QUFDakMsTUFBSSxRQUFRLE9BQU8sQ0FBQyxlQUFlLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFlBQVEsTUFBTSxNQUFNLFdBQVcsUUFBUSxHQUFHO0FBQUEsRUFDNUM7QUFDQSxRQUFNLE9BQU8sWUFBWSxPQUFPO0FBQ2xDO0FBQ0EsZUFBc0IsZUFBZSxPQUE2QztBQUNoRixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEMsUUFBTSxZQUFZLElBQUk7QUFDdEIsU0FBTztBQUNUO0FBSUEsZUFBc0IsY0FBd0M7QUFDNUQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFhQSxlQUFzQixxQkFBc0Q7QUFDMUUsU0FBTyxPQUFPLGlCQUFpQjtBQUNqQztBQVFBLGVBQXNCLGdCQUEwQztBQUM5RCxRQUFNLElBQUksTUFBTSxPQUFPLFlBQVk7QUFFbkMsUUFBTSxNQUF1QjtBQUFBLElBQzNCLEdBQUc7QUFBQSxJQUNILGVBQWUsRUFBRSxrQkFBa0IsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUN4RCx3QkFDRSxFQUFFLDJCQUEyQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3BELGtCQUFrQixFQUFFLHFCQUFxQixTQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ2hFO0FBQ0EsU0FBTztBQUNUO0FBV0EsZUFBc0IsY0FBdUQ7QUFDM0UsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUE2QkEsZUFBc0IsZ0JBQW9EO0FBQ3hFLFNBQU8sT0FBTyxZQUFZO0FBQzVCO0FBcUJBLGVBQXNCLGNBQW1DO0FBQ3ZELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBb1lBLGVBQXNCLFdBQTBCO0FBQzlDLFFBQU0sUUFBUSxRQUFRLE1BQU0sTUFBTTtBQUNwQzs7O0FDOW9CQSxJQUFNLElBQUksQ0FBc0MsT0FBa0I7QUFDaEUsUUFBTSxLQUFLLFNBQVMsZUFBZSxFQUFFO0FBQ3JDLE1BQUksQ0FBQyxHQUFJLE9BQU0sSUFBSSxNQUFNLG9CQUFvQixFQUFFLEVBQUU7QUFDakQsU0FBTztBQUNUO0FBRUEsSUFBTSxPQUFPLEVBQW1CLGVBQWU7QUFDL0MsSUFBTSxhQUFhLEVBQW9CLE9BQU87QUFDOUMsSUFBTSxZQUFZLEVBQW9CLE1BQU07QUFDNUMsSUFBTSxjQUFjLEVBQW9CLFFBQVE7QUFDaEQsSUFBTSxXQUFXLEVBQW9CLEtBQUs7QUFDMUMsSUFBTSxZQUFZLEVBQXFCLFlBQVk7QUFDbkQsSUFBTSxhQUFhLEVBQW1CLGFBQWE7QUFDbkQsSUFBTSxhQUFhLEVBQUUsYUFBYTtBQUNsQyxJQUFNLGNBQWMsRUFBb0Isa0JBQWtCO0FBQzFELElBQU0sYUFBYSxFQUFxQixrQkFBa0I7QUFDMUQsSUFBTSxVQUFVLEVBQXVCLGFBQWE7QUFDcEQsSUFBTSxjQUFjLEVBQXFCLGtCQUFrQjtBQUMzRCxJQUFNLGtCQUFrQixFQUFxQixlQUFlO0FBQzVELElBQU0sYUFBYSxFQUFtQixhQUFhO0FBRW5ELGVBQWUsS0FBUSxLQUFpQztBQUN0RCxTQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDeEM7QUFFQSxTQUFTLFVBQVUsSUFBaUIsTUFBa0MsS0FBbUI7QUFDdkYsS0FBRyxZQUFZLE9BQU8sVUFBVSxJQUFJLEtBQUs7QUFDekMsS0FBRyxjQUFjO0FBQ25CO0FBRUEsU0FBUyxpQkFBaUIsU0FBaUM7QUFDekQsU0FDRSxPQUFPLFlBQVksWUFDbkIsNkVBQTZFLEtBQUssT0FBTztBQUU3RjtBQUVBLGVBQWUsZUFBOEI7QUFDM0MsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixhQUFXLFFBQVEsRUFBRSxTQUFTLGlCQUFpQjtBQUMvQyxZQUFVLFFBQVEsRUFBRSxRQUFRLGlCQUFpQjtBQUM3QyxjQUFZLFFBQVEsRUFBRSxVQUFVLGlCQUFpQjtBQUNqRCxNQUFJLEVBQUUsS0FBSztBQUNULGFBQVMsUUFBUSxFQUFFO0FBQ25CLGFBQVMsY0FBYyxTQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsQ0FBQztBQUFBLEVBQzVDO0FBQ0EsUUFBTSxnQkFBZ0I7QUFDeEI7QUFFQSxlQUFlLGtCQUFpQztBQUM5QyxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxRQUFrQixDQUFDO0FBQ3pCLFFBQU0sS0FBSyxXQUFXLEtBQUssTUFBTSxFQUFFO0FBQ25DLE1BQUksS0FBSyxNQUFPLE9BQU0sS0FBSyxrQkFBa0IsS0FBSyxLQUFLLEVBQUU7QUFDekQsUUFBTSxLQUFLLGVBQWUsRUFBRSxTQUFTLEdBQUcsSUFBSSxFQUFFLFFBQVEsR0FBRyxJQUFJLEVBQUUsVUFBVSxHQUFHLEVBQUU7QUFDOUUsTUFBSSxLQUFLLFVBQVcsT0FBTSxLQUFLLGlCQUFpQixLQUFLLFNBQVMsRUFBRTtBQUNoRSxNQUFJLEtBQUssV0FBVyxrQkFBa0IsS0FBSyxxQkFBcUIsTUFBTTtBQUNwRSxVQUFNLFdBQVcsSUFBSSxLQUFLLEtBQUssbUJBQW1CLEdBQUksRUFBRSxZQUFZO0FBQ3BFLFVBQU0sV0FBVyxLQUFLLG1CQUFtQixLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUNyRSxVQUFNLFVBQ0osWUFBWSxJQUNSLGdCQUNBLFdBQVcsS0FDVCxNQUFNLFFBQVEsTUFDZCxXQUFXLE9BQ1QsTUFBTSxLQUFLLE1BQU0sV0FBVyxFQUFFLENBQUMsTUFDL0IsTUFBTSxLQUFLLE1BQU0sV0FBVyxJQUFJLENBQUM7QUFDM0MsVUFBTSxLQUFLLHNCQUFzQixRQUFRLEtBQUssT0FBTyxHQUFHO0FBQUEsRUFDMUQ7QUFDQSxNQUFJLEtBQUssTUFBTyxPQUFNLEtBQUssVUFBVSxLQUFLLEtBQUssRUFBRTtBQUNqRCxhQUFXLGNBQWMsTUFBTSxLQUFLLElBQUk7QUFDMUM7QUFFQSxlQUFlLGdCQUErQjtBQUM1QyxRQUFNLE9BQU8sTUFBTSxZQUFZO0FBQy9CLGNBQVksZ0JBQWdCO0FBQzVCLGFBQVcsS0FBSyxNQUFNO0FBQ3BCLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxVQUFNLFNBQVMsU0FBUyxjQUFjLE1BQU07QUFDNUMsV0FBTyxZQUFZO0FBQ25CLFdBQU8sY0FBYyxJQUFJLEVBQUUsTUFBTTtBQUNqQyxVQUFNLFFBQVEsU0FBUyxjQUFjLE1BQU07QUFDM0MsVUFBTSxZQUFZO0FBQ2xCLFVBQU0sY0FBYyxFQUFFO0FBQ3RCLE9BQUcsT0FBTyxRQUFRLEtBQUs7QUFDdkIsZ0JBQVksT0FBTyxFQUFFO0FBQUEsRUFDdkI7QUFDRjtBQUVBLEtBQUssaUJBQWlCLFVBQVUsT0FBTyxNQUFhO0FBQ2xELElBQUUsZUFBZTtBQUNqQixRQUFNLE1BQU0sU0FBUyxNQUFNLEtBQUs7QUFDaEMsUUFBTSxRQUFRLFdBQVcsTUFBTSxLQUFLO0FBQ3BDLFFBQU0sT0FBTyxVQUFVLE1BQU0sS0FBSztBQUNsQyxRQUFNLFNBQVMsWUFBWSxNQUFNLEtBQUssS0FBSztBQUMzQyxNQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNO0FBQzNCLGNBQVUsWUFBWSxPQUFPLDBCQUEwQjtBQUN2RDtBQUFBLEVBQ0Y7QUFDQSxZQUFVLFlBQVksSUFBSSxjQUFTO0FBQ25DLFFBQU0sZUFBZSxFQUFFLEtBQUssT0FBTyxNQUFNLFFBQVEsY0FBYyxLQUFLLElBQUksRUFBRSxDQUFDO0FBQzNFLFlBQVUsWUFBWSxJQUFJLGlCQUFZO0FBQ3RDLFFBQU0sS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDeEMsUUFBTSxLQUFLLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUN2QyxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLE1BQUksS0FBSyxXQUFXLE1BQU07QUFDeEIsY0FBVSxZQUFZLE1BQU0saUJBQWlCLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFBQSxFQUNuRSxXQUFXLEtBQUssV0FBVyxjQUFjO0FBQ3ZDO0FBQUEsTUFDRTtBQUFBLE1BQ0E7QUFBQSxNQUNBLGlCQUFpQixLQUFLLEtBQUssSUFDdkIseUVBQ0E7QUFBQSxJQUNOO0FBQUEsRUFDRixXQUFXLEtBQUssV0FBVyxnQkFBZ0I7QUFDekMsY0FBVSxZQUFZLFFBQVEsOERBQXlEO0FBQUEsRUFDekYsV0FBVyxLQUFLLFdBQVcsaUJBQWlCO0FBQzFDLGNBQVUsWUFBWSxPQUFPLDBDQUFxQztBQUFBLEVBQ3BFLE9BQU87QUFDTCxjQUFVLFlBQVksT0FBTyxpQkFBaUIsS0FBSyxNQUFNLEVBQUU7QUFBQSxFQUM3RDtBQUNBLFFBQU0sZ0JBQWdCO0FBQ3RCLFFBQU0sY0FBYztBQUNwQixRQUFNLFlBQVk7QUFDcEIsQ0FBQztBQUVELFVBQVUsaUJBQWlCLFNBQVMsTUFBTTtBQUN4QyxNQUFJLFNBQVMsU0FBUyxZQUFZO0FBQ2hDLGFBQVMsT0FBTztBQUNoQixjQUFVLGNBQWM7QUFBQSxFQUMxQixPQUFPO0FBQ0wsYUFBUyxPQUFPO0FBQ2hCLGNBQVUsY0FBYztBQUFBLEVBQzFCO0FBQ0YsQ0FBQztBQUVELFdBQVcsaUJBQWlCLFNBQVMsWUFBWTtBQUMvQyxhQUFXLFdBQVc7QUFDdEIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDdkMsVUFBTSxjQUFjO0FBQ3BCLGNBQVUsWUFBWSxNQUFNLHFCQUFxQjtBQUFBLEVBQ25ELFNBQVMsS0FBSztBQUNaLGNBQVUsWUFBWSxPQUFPLG1CQUFvQixJQUFjLE9BQU8sRUFBRTtBQUFBLEVBQzFFLFVBQUU7QUFDQSxlQUFXLFdBQVc7QUFBQSxFQUN4QjtBQUNGLENBQUM7QUFFRCxlQUFlLGNBQTZCO0FBQzFDLFFBQU0sQ0FBQyxVQUFVLE1BQU0sVUFBVSxVQUFVLFNBQVMsVUFBVSxlQUFlLElBQUksTUFBTSxRQUFRLElBQUk7QUFBQSxJQUNqRyxZQUFZO0FBQUEsSUFDWixjQUFjO0FBQUEsSUFDZCxZQUFZO0FBQUEsSUFDWixZQUFZO0FBQUEsSUFDWixjQUFjO0FBQUEsSUFDZCxZQUFZO0FBQUEsSUFDWixtQkFBbUI7QUFBQSxFQUNyQixDQUFDO0FBQ0QsUUFBTSxrQkFBa0IsT0FBTztBQUFBLElBQzdCLE9BQU8sUUFBUSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU07QUFBQSxNQUN0QztBQUFBLE1BQ0E7QUFBQSxRQUNFLFFBQVEsRUFBRTtBQUFBLFFBQ1YsWUFBWSxFQUFFO0FBQUEsUUFDZCxpQkFBaUIsRUFBRTtBQUFBLFFBQ25CLGNBQWMsT0FBTyxLQUFLLEVBQUUsWUFBWSxFQUFFO0FBQUEsUUFDMUMsZ0JBQWdCLEVBQUUsbUJBQW1CO0FBQUEsUUFDckMsZ0JBQWdCLEVBQUU7QUFBQSxRQUNsQixZQUFZLEVBQUU7QUFBQSxNQUNoQjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLE9BQU87QUFBQSxJQUNYLFNBQVMsUUFBUSxRQUFRLFlBQVksRUFBRTtBQUFBLElBQ3ZDLFlBQVksVUFBVTtBQUFBLElBQ3RCLFVBQVU7QUFBQSxNQUNSLE9BQU8sU0FBUztBQUFBLE1BQ2hCLE1BQU0sU0FBUztBQUFBLE1BQ2YsUUFBUSxTQUFTO0FBQUEsTUFDakIsYUFBYSxTQUFTO0FBQUEsTUFDdEIsZ0JBQWdCLFNBQVM7QUFBQSxNQUN6QixjQUFjLFNBQVM7QUFBQSxNQUN2QixRQUFRLFNBQVMsSUFBSSxTQUFTO0FBQUEsTUFDOUIsV0FBVyxTQUFTLElBQUksVUFBVSxJQUFJLFNBQVMsSUFBSSxNQUFNLEVBQUUsSUFBSTtBQUFBLElBQ2pFO0FBQUEsSUFDQSxZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLGlCQUFpQixrQkFDYjtBQUFBLE1BQ0UsY0FBYyxnQkFBZ0I7QUFBQSxNQUM5QixZQUFZLGdCQUFnQjtBQUFBLE1BQzVCLFVBQVUsT0FBTyxLQUFLLGdCQUFnQixRQUFRLEVBQUU7QUFBQSxJQUNsRCxJQUNBO0FBQUEsSUFDSixZQUFZO0FBQUEsSUFDWixvQkFBb0IsU0FBUztBQUFBLElBQzdCLGlCQUFpQixTQUFTLE1BQU0sR0FBRyxFQUFFO0FBQUEsRUFDdkM7QUFDQSxVQUFRLFFBQVEsS0FBSyxVQUFVLE1BQU0sTUFBTSxDQUFDO0FBQzlDO0FBRUEsWUFBWSxpQkFBaUIsU0FBUyxZQUFZO0FBQ2hELFFBQU0sVUFBVSxVQUFVLFVBQVUsUUFBUSxLQUFLO0FBQ2pELFlBQVUsWUFBWSxNQUFNLGtDQUFrQztBQUNoRSxDQUFDO0FBRUQsZ0JBQWdCLGlCQUFpQixTQUFTLFlBQVk7QUFDcEQsUUFBTSxLQUFLLE9BQU87QUFBQSxJQUNoQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsR0FBSTtBQUNULFFBQU0sU0FBUztBQUNmLFlBQVUsWUFBWSxRQUFRLGtCQUFrQjtBQUNoRCxRQUFNLGFBQWE7QUFDbkIsUUFBTSxjQUFjO0FBQ3BCLFFBQU0sWUFBWTtBQUNwQixDQUFDO0FBRUQsS0FBSyxhQUFhO0FBQ2xCLEtBQUssY0FBYztBQUNuQixLQUFLLFlBQVk7IiwKICAibmFtZXMiOiBbXQp9Cg==
