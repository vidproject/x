// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function getCounters() {
  return getRaw("counters");
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getActivity() {
  return getRaw("activity");
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/options.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var form = $("settings-form");
var ownerInput = $("owner");
var repoInput = $("repo");
var branchInput = $("branch");
var patInput = $("pat");
var revealBtn = $("reveal-pat");
var saveStatus = $("save-status");
var connDetail = $("conn-detail");
var accountList = $("account-readonly");
var refreshBtn = $("refresh-accounts");
var diagBox = $("diagnostics");
var copyDiagBtn = $("copy-diagnostics");
var clearStorageBtn = $("clear-storage");
var diagStatus = $("diag-status");
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setStatus(el, kind, msg) {
  el.className = kind ? `status ${kind}` : "status";
  el.textContent = msg;
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
async function loadSettings() {
  const s = await getSettings();
  ownerInput.value = s.owner || DEFAULT_SETTINGS.owner;
  repoInput.value = s.repo || DEFAULT_SETTINGS.repo;
  branchInput.value = s.branch || DEFAULT_SETTINGS.branch;
  if (s.pat) {
    patInput.value = s.pat;
    patInput.placeholder = `\u2026${s.pat.slice(-4)}`;
  }
  await paintConnDetail();
}
async function paintConnDetail() {
  const conn = await getConnection();
  const s = await getSettings();
  const lines = [];
  lines.push(`Status: ${conn.status}`);
  if (conn.login) lines.push(`Logged in as: @${conn.login}`);
  lines.push(`Repository: ${s.owner || "?"}/${s.repo || "?"}@${s.branch || "?"}`);
  if (conn.checkedAt) lines.push(`Last checked: ${conn.checkedAt}`);
  if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
    const resetIso = new Date(conn.rateLimitResetAt * 1e3).toISOString();
    const deltaSec = conn.rateLimitResetAt - Math.floor(Date.now() / 1e3);
    const inLabel = deltaSec <= 0 ? "momentarily" : deltaSec < 60 ? `in ${deltaSec}s` : deltaSec < 3600 ? `in ${Math.round(deltaSec / 60)}m` : `in ${Math.round(deltaSec / 3600)}h`;
    lines.push(`Rate limit resets: ${resetIso} (${inLabel})`);
  }
  if (conn.error) lines.push(`Error: ${conn.error}`);
  connDetail.textContent = lines.join("\n");
}
async function paintAccounts() {
  const list = await getAccounts();
  accountList.replaceChildren();
  for (const a of list) {
    const li = document.createElement("li");
    const handle = document.createElement("span");
    handle.className = "handle";
    handle.textContent = `@${a.handle}`;
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = a.label;
    li.append(handle, label);
    accountList.append(li);
  }
}
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const pat = patInput.value.trim();
  const owner = ownerInput.value.trim();
  const repo = repoInput.value.trim();
  const branch = branchInput.value.trim() || "main";
  if (!pat || !owner || !repo) {
    setStatus(saveStatus, "err", "All fields are required.");
    return;
  }
  setStatus(saveStatus, "", "Saving\u2026");
  await updateSettings({ pat, owner, repo, branch, configuredAt: Date.now() });
  setStatus(saveStatus, "", "Verifying\u2026");
  await send({ type: "verify-connection" });
  await send({ type: "refresh-accounts" });
  const conn = await getConnection();
  if (conn.status === "ok") {
    setStatus(saveStatus, "ok", `Connected as @${conn.login ?? "?"}.`);
  } else if (conn.status === "auth-error") {
    setStatus(
      saveStatus,
      "err",
      isWriteAuthError(conn.error) ? "PAT can read this repo but cannot write. Set Contents: Read & Write." : "Auth failed - check the PAT and its repo scope."
    );
  } else if (conn.status === "rate-limited") {
    setStatus(saveStatus, "warn", "Rate-limited \u2014 token is valid but GitHub is throttling.");
  } else if (conn.status === "network-error") {
    setStatus(saveStatus, "err", "Network error \u2014 check connectivity.");
  } else {
    setStatus(saveStatus, "err", `Verification: ${conn.status}`);
  }
  await paintConnDetail();
  await paintAccounts();
  await refreshDiag();
});
revealBtn.addEventListener("click", () => {
  if (patInput.type === "password") {
    patInput.type = "text";
    revealBtn.textContent = "Hide";
  } else {
    patInput.type = "password";
    revealBtn.textContent = "Show";
  }
});
refreshBtn.addEventListener("click", async () => {
  refreshBtn.disabled = true;
  try {
    await send({ type: "refresh-accounts" });
    await paintAccounts();
    setStatus(diagStatus, "ok", "Accounts refreshed.");
  } catch (err) {
    setStatus(diagStatus, "err", `Refresh failed: ${err.message}`);
  } finally {
    refreshBtn.disabled = false;
  }
});
async function refreshDiag() {
  const [settings, conn, accounts, counters, buffers, activity, archiveSnapshot] = await Promise.all([
    getSettings(),
    getConnection(),
    getAccounts(),
    getCounters(),
    getRunBuffers(),
    getActivity(),
    getArchiveSnapshot()
  ]);
  const redactedBuffers = Object.fromEntries(
    Object.entries(buffers).map(([k, b]) => [
      k,
      {
        run_id: b.run_id,
        started_at: b.started_at,
        last_capture_at: b.last_capture_at,
        tweets_count: Object.keys(b.tweets_by_id).length,
        observed_count: b.tweet_ids_observed.length,
        endpoints_seen: b.endpoints_seen,
        source_url: b.source_url
      }
    ])
  );
  const dump = {
    version: browser.runtime.getManifest().version,
    user_agent: navigator.userAgent,
    settings: {
      owner: settings.owner,
      repo: settings.repo,
      branch: settings.branch,
      autoCapture: settings.autoCapture,
      updateExisting: settings.updateExisting,
      configuredAt: settings.configuredAt,
      patSet: settings.pat.length > 0,
      patSuffix: settings.pat.length >= 4 ? settings.pat.slice(-4) : ""
    },
    connection: conn,
    accounts,
    counters,
    archiveSnapshot: archiveSnapshot ? {
      generated_at: archiveSnapshot.generated_at,
      fetched_at: archiveSnapshot.fetched_at,
      accounts: Object.keys(archiveSnapshot.accounts).length
    } : null,
    runBuffers: redactedBuffers,
    activity_tail_size: activity.length,
    activity_recent: activity.slice(0, 30)
  };
  diagBox.value = JSON.stringify(dump, null, 2);
}
copyDiagBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(diagBox.value);
  setStatus(diagStatus, "ok", "Copied diagnostics to clipboard.");
});
clearStorageBtn.addEventListener("click", async () => {
  const ok = window.confirm(
    "Clear extension storage? This erases your PAT, settings, counters, buffered captures, and activity tail. There is no undo."
  );
  if (!ok) return;
  await clearAll();
  setStatus(diagStatus, "warn", "Storage cleared.");
  await loadSettings();
  await paintAccounts();
  await refreshDiag();
});
void loadSettings();
void paintAccounts();
void refreshDiag();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9vcHRpb25zLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgdHlwZSB7IEFjY291bnRDb25maWcsIFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XHJcbiAgcGF0OiAnJyxcclxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxyXG4gIHJlcG86ICd4JyxcclxuICAvLyBUaGUgcmVwbydzIGN1cnJlbnQgZGVmYXVsdCBicmFuY2ggaXMgXCJtYXN0ZXJcIi4gSWYgeW91IGZvcmsgb3IgcmVuYW1lXHJcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cclxuICBicmFuY2g6ICdtYXN0ZXInLFxyXG4gIGVuYWJsZWQ6IHRydWUsXHJcbiAgYXV0b0NhcHR1cmU6IHRydWUsXHJcbiAgY29uZmlndXJlZEF0OiBudWxsLFxyXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcclxuICB1cGRhdGVFeGlzdGluZzogdHJ1ZSxcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcclxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01BWF9TRUMgPSA2MDtcclxuXHJcbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXHJcbi8vIHJlcG8gaGFzIGJlZW4gaW5pdGlhbGl6ZWQgb3IgUEFUIG1pc2NvbmZpZ3VyZWQpLiBLZXB0IGluIHN5bmMgd2l0aCB0aGUgZmlsZS5cclxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXHJcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdJQ0Vnb3YnLCBsYWJlbDogJ1UuUy4gSW1taWdyYXRpb24gYW5kIEN1c3RvbXMgRW5mb3JjZW1lbnQnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdXaGl0ZUhvdXNlJywgbGFiZWw6ICdUaGUgV2hpdGUgSG91c2UnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1VTRE9MJywgbGFiZWw6ICdVLlMuIERlcGFydG1lbnQgb2YgTGFib3InLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG5dO1xyXG5cclxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cclxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdVc2VyVHdlZXRzJyxcclxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxyXG4gICdVc2VyTWVkaWEnLFxyXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXHJcbiAgJ1R3ZWV0RGV0YWlsJyxcclxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXHJcbiAgJ0xpa2VzJyxcclxuICAnQm9va21hcmtzJyxcclxuICAnSG9tZVRpbWVsaW5lJyxcclxuICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcclxuICAnU2VhcmNoVGltZWxpbmUnLFxyXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxyXG5dKTtcclxuXHJcbi8vIEVuZHBvaW50cyB0aGF0IGNhcnJ5IENvbW11bml0eSBOb3RlIGJvZGllcyBcdTIwMTQgY2FwdHVyZWQgZm9yIGNvbXBsZXRlbmVzcyBidXRcclxuLy8gdGhleSBkb24ndCBpbnRyb2R1Y2UgbmV3IHR3ZWV0cywgc28gdGhleSBkb24ndCBuZWVkIHRvIGJlIGluIFRXRUVUX0VORFBPSU5UUy5cclxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnQmlyZHdhdGNoRmV0Y2hPbmVOb3RlJyxcclxuICAnQmlyZHdhdGNoRmV0Y2hOb3RlcycsXHJcbl0pO1xyXG5cclxuLy8gQXV4aWxpYXJ5IGVuZHBvaW50cyB3ZSBkb24ndCBleHRyYWN0IHR3ZWV0cyBmcm9tIGJ1dCB1c2UgZm9yIGNvbnRleHQgKGUuZy4sXHJcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXHJcbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcclxuXHJcbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxyXG4vLyBjb252ZXJzYXRpb24gXHUyMDE0IGkuZS4gdmlzaXRpbmcgYC88aGFuZGxlPmAgLyBgLzxoYW5kbGU+L3dpdGhfcmVwbGllc2AsXHJcbi8vIGxvb2tpbmcgYXQgb25lIHR3ZWV0LCBldGMuIEV2ZXJ5IHR3ZWV0IHJldHVybmVkIGJ5IHRoZXNlIGVuZHBvaW50cyBpc1xyXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cclxuLy8gKHJldHdlZXRlZCwgcXVvdGVkLCByZXBsaWVkIHRvKSwgc28gd2Uga2VlcCBldmVyeXRoaW5nIHdlIHNlZSByYXRoZXJcclxuLy8gdGhhbiBkcm9wcGluZyBub24tdHJhY2tlZCBhdXRob3JzLiBUaGF0IHdheSBhIHJldHdlZXQgb2YgYSBub24tdHJhY2tlZFxyXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXHJcbi8vXHJcbi8vIEVuZHBvaW50cyBOT1QgaW4gdGhpcyBzZXQgKEhvbWVUaW1lbGluZSwgU2VhcmNoVGltZWxpbmUsIExpa2VzLCBldGMuKVxyXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3NcclxuLy8gXCJCcm93c2luZyBteSBob21lIHRpbWVsaW5lIGlzIGlnbm9yZWRcIiBydWxlLlxyXG5leHBvcnQgY29uc3QgVVNFUl9QQUdFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdVc2VyVHdlZXRzJyxcclxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxyXG4gICdVc2VyTWVkaWEnLFxyXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXHJcbiAgJ1R3ZWV0RGV0YWlsJyxcclxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXHJcbl0pO1xyXG5cclxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XHJcblxyXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xyXG5cclxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcclxuXHJcbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cclxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xyXG5cclxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxyXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcclxuXHJcbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xyXG4iLCAiLyoqXHJcbiAqIGNyeXB0by50cyBcdTIwMTQgYXQtcmVzdCBlbmNyeXB0aW9uIGZvciBzZW5zaXRpdmUgc2V0dGluZ3MgKHRoZSBQQVQpLlxyXG4gKlxyXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcclxuICogZm9yZ290dGVuIGJhY2t1cCwgYSBtaXNjb25maWd1cmVkIHByb2ZpbGUgc3luYykgc2hvdWxkIG5vdCBzZWUgYSB1c2FibGVcclxuICogR2l0SHViIFBBVCBpbiBwbGFpbnRleHQuIEEgZGV0ZXJtaW5lZCBhdHRhY2tlciB3aXRoIHRoZSBleHRlbnNpb24ncyBzb3VyY2VcclxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcclxuICogY29uZmlkZW50aWFsaXR5LiBUaGUgYWltIGlzIHRvIHJhaXNlIHRoZSBiYXIgc28gdGhlIFBBVCBpc24ndCBhIGNvcHlhYmxlXHJcbiAqIHN0cmluZyBzaXR0aW5nIG5leHQgdG8gaXRzIGtleSBuYW1lIGluIGV4dGVuc2lvbiBzdG9yYWdlLlxyXG4gKlxyXG4gKiBTY2hlbWU6XHJcbiAqICAgLSBPbiBmaXJzdCBlbmNyeXB0aW9uIHdlIGdlbmVyYXRlIGEgMzItYnl0ZSBzYWx0IGFuZCBwZXJzaXN0IGl0IGluXHJcbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxyXG4gKiAgIC0gV2UgZGVyaXZlIGFuIEFFUy1HQ00ga2V5IGJ5IFNIQS0yNTYnaW5nIGBzYWx0IHx8IHJ1bnRpbWUuaWQgfHwgdmVyc2lvblxyXG4gKiAgICAgfHwgXCJpbW0tYXJjaGl2ZS1wYXQtdjFcImAuIFRoZSBzYWx0IGJlaW5nIHBlci1pbnN0YWxsIG1lYW5zIHR3byBjb3BpZXNcclxuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xyXG4gKiAgICAgVVVJRCBcdTIwMTQgc3RhYmxlIGZvciBhIGdpdmVuIGluc3RhbGwgYnV0IHVua25vd24gdG8gYSByZW1vdGUgYXR0YWNrZXIuXHJcbiAqICAgLSBQbGFpbnRleHQgaXMgZW5jcnlwdGVkIHdpdGggYSBmcmVzaCAxMi1ieXRlIElWLiBUaGUgZW52ZWxvcGUgZm9ybWF0IGlzXHJcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXHJcbiAqXHJcbiAqIEJhY2t3YXJkcyBjb21wYXRpYmlsaXR5OiBhbiB1bnByZWZpeGVkIHZhbHVlIGlzIHRyZWF0ZWQgYXMgbGVnYWN5XHJcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cclxuICovXHJcblxyXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcclxuY29uc3QgRU5WRUxPUEVfUFJFRklYID0gJ3YxOic7XHJcblxyXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcclxubGV0IGRlcml2ZWRLZXlDYWNoZVNhbHQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xyXG5cclxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcclxuICBsZXQgcyA9ICcnO1xyXG4gIGZvciAoY29uc3QgYiBvZiBidWYpIHMgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShiKTtcclxuICByZXR1cm4gYnRvYShzKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcclxuICBjb25zdCBiaW4gPSBhdG9iKHMpO1xyXG4gIGNvbnN0IG91dCA9IG5ldyBVaW50OEFycmF5KGJpbi5sZW5ndGgpO1xyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBsb2FkT3JDcmVhdGVTYWx0KCk6IFByb21pc2U8eyBzYWx0QjY0OiBzdHJpbmc7IHNhbHQ6IFVpbnQ4QXJyYXkgfT4ge1xyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoU0FMVF9TVE9SQUdFX0tFWSk7XHJcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcclxuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xyXG4gICAgcmV0dXJuIHsgc2FsdEI2NDogdiwgc2FsdDogZnJvbUJhc2U2NCh2KSB9O1xyXG4gIH1cclxuICBjb25zdCBzYWx0ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgzMikpO1xyXG4gIGNvbnN0IHNhbHRCNjQgPSB0b0Jhc2U2NChzYWx0KTtcclxuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xyXG4gIHJldHVybiB7IHNhbHRCNjQsIHNhbHQgfTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZGVyaXZlS2V5KCk6IFByb21pc2U8Q3J5cHRvS2V5PiB7XHJcbiAgY29uc3QgeyBzYWx0QjY0LCBzYWx0IH0gPSBhd2FpdCBsb2FkT3JDcmVhdGVTYWx0KCk7XHJcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XHJcbiAgICByZXR1cm4gZGVyaXZlZEtleUNhY2hlO1xyXG4gIH1cclxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxyXG4gICAgYCR7YnJvd3Nlci5ydW50aW1lLmlkfXwke2Jyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb259fGltbS1hcmNoaXZlLXBhdC12MWBcclxuICApO1xyXG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XHJcbiAgY29tYmluZWQuc2V0KHNlZWQsIDApO1xyXG4gIGNvbWJpbmVkLnNldChzYWx0LCBzZWVkLmxlbmd0aCk7XHJcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xyXG4gIGNvbnN0IGtleSA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuaW1wb3J0S2V5KCdyYXcnLCBoYXNoLCB7IG5hbWU6ICdBRVMtR0NNJyB9LCBmYWxzZSwgW1xyXG4gICAgJ2VuY3J5cHQnLFxyXG4gICAgJ2RlY3J5cHQnLFxyXG4gIF0pO1xyXG4gIGRlcml2ZWRLZXlDYWNoZSA9IGtleTtcclxuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcclxuICByZXR1cm4ga2V5O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaXNFbmNyeXB0ZWRQYXQodjogc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgcmV0dXJuIHYuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5jcnlwdFBhdChwbGFpbnRleHQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcclxuICBjb25zdCBrZXkgPSBhd2FpdCBkZXJpdmVLZXkoKTtcclxuICBjb25zdCBpdiA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTIpKTtcclxuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcclxuICAgIHsgbmFtZTogJ0FFUy1HQ00nLCBpdiB9LFxyXG4gICAga2V5LFxyXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcclxuICApO1xyXG4gIHJldHVybiBgJHtFTlZFTE9QRV9QUkVGSVh9JHt0b0Jhc2U2NChpdil9OiR7dG9CYXNlNjQobmV3IFVpbnQ4QXJyYXkoY3QpKX1gO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVjcnlwdFBhdChlbnZlbG9wZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XHJcbiAgLy8gTGVnYWN5IHBsYWludGV4dCAocHJlLWVuY3J5cHRpb24gaW5zdGFsbHMpOiBwYXNzIHRocm91Z2guIFRoZSBuZXh0IHNhdmVcclxuICAvLyByZS1lbmNyeXB0cyBpdCB2aWEgdGhlIHN0b3JhZ2UgbGF5ZXIuXHJcbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcclxuICBjb25zdCBwYXJ0cyA9IGVudmVsb3BlLnNsaWNlKEVOVkVMT1BFX1BSRUZJWC5sZW5ndGgpLnNwbGl0KCc6Jyk7XHJcbiAgaWYgKHBhcnRzLmxlbmd0aCAhPT0gMikgcmV0dXJuICcnO1xyXG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XHJcbiAgaWYgKCFpdkI2NCB8fCAhY3RCNjQpIHJldHVybiAnJztcclxuICB0cnkge1xyXG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XHJcbiAgICBjb25zdCBpdiA9IGZyb21CYXNlNjQoaXZCNjQpO1xyXG4gICAgY29uc3QgY3QgPSBmcm9tQmFzZTY0KGN0QjY0KTtcclxuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxyXG4gICAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXY6IGl2IGFzIEJ1ZmZlclNvdXJjZSB9LFxyXG4gICAgICBrZXksXHJcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxyXG4gICAgKTtcclxuICAgIHJldHVybiBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUocHQpO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuICcnO1xyXG4gIH1cclxufVxyXG4iLCAiaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUywgRkFMTEJBQ0tfQUNDT1VOVFMsIEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9jb25maWcuanMnO1xyXG5pbXBvcnQgeyBkZWNyeXB0UGF0LCBlbmNyeXB0UGF0LCBpc0VuY3J5cHRlZFBhdCB9IGZyb20gJy4vY3J5cHRvLmpzJztcclxuaW1wb3J0IHR5cGUge1xyXG4gIEFjY291bnRDb25maWcsXHJcbiAgQWNjb3VudENvdW50ZXIsXHJcbiAgQXJjaGl2ZVNuYXBzaG90LFxyXG4gIENhbm9uaWNhbFR3ZWV0LFxyXG4gIENvbm5lY3Rpb25TdGF0ZSxcclxuICBMb2dFdmVudCxcclxuICBTZXR0aW5ncyxcclxuICBUd2VldFNpZ2h0aW5nLFxyXG4gIFVuYXZhaWxhYmxlVHdlZXQsXHJcbn0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG4vKipcclxuICogQnVmZmVyZWQgdHdlZXRzIGZvciBhIGdpdmVuIGFjY291bnQsIGF3YWl0aW5nIGNvbW1pdC4gQSBcInJ1blwiIGlzIG9uZSBlbnRyeVxyXG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcclxuICogc3Vydml2ZXMgSlNPTiBzZXJpYWxpemF0aW9uIHRocm91Z2ggYnJvd3Nlci5zdG9yYWdlLlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xyXG4gIHJ1bl9pZDogc3RyaW5nO1xyXG4gIGFjY291bnRfaGFuZGxlOiBzdHJpbmc7XHJcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xyXG4gIGxhc3RfY2FwdHVyZV9hdDogc3RyaW5nO1xyXG4gIHR3ZWV0c19ieV9pZDogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+O1xyXG4gIHVuYXZhaWxhYmxlX2J5X2lkPzogUmVjb3JkPHN0cmluZywgVW5hdmFpbGFibGVUd2VldD47XHJcbiAgdHdlZXRfaWRzX29ic2VydmVkOiBzdHJpbmdbXTtcclxuICBlbmRwb2ludHNfc2Vlbjogc3RyaW5nW107XHJcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcclxufVxyXG5cclxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxyXG4gKiBVc2VkIHRvIHNraXAgcmUtY2FwdHVyaW5nIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IHB1c2hlZCB3aXRoIGlkZW50aWNhbFxyXG4gKiBlbmdhZ2VtZW50IGNvdW50cyBcdTIwMTQgYXZvaWRzIGdlbmVyYXRpbmcgb25lIG5ldyByYXcvKiBmaWxlIGV2ZXJ5IGJyb3dzZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XHJcbiAgdHM6IHN0cmluZzsgLy8gSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBjb21taXRcclxuICBzaWc6IHN0cmluZzsgLy8gZW5nYWdlbWVudCBzaWduYXR1cmU6IFwibGlrZXxydHxyZXBseXxxdW90ZVwiXHJcbn1cclxuXHJcbi8qKiBQcm9ncmVzcyArIGluZmxpZ2h0IHRyYWNraW5nIGZvciBhIHF1ZXVlLWRyaXZlbiBsb29wIChyZWZldGNoIC8gbWVkaWEtY3Jhd2wpLlxyXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcclxuICogXCJYIG9mIFkgcHJvY2Vzc2VkXCIgXHUyMDE0IGFuZCB0aGUgd2FpdC1mb3ItaW5nZXN0IGd1YXJkIGtub3dzIHdoYXQgdG8gZXhwZWN0LlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XHJcbiAgLyoqIEluaXRpYWwgcXVldWUgc2l6ZSB3aGVuIHRoZSB1c2VyIGNsaWNrZWQgXCJTdGFydFwiLiAqL1xyXG4gIHRvdGFsQXRTdGFydDogbnVtYmVyO1xyXG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cclxuICBwcm9jZXNzZWQ6IG51bWJlcjtcclxuICAvKiogSVNPIG9mIHdoZW4gdGhpcyBzZXNzaW9uIHN0YXJ0ZWQuICovXHJcbiAgc3RhcnRlZEF0OiBzdHJpbmc7XHJcbiAgLyoqIFR3ZWV0IGN1cnJlbnRseSBpbmZsaWdodCBcdTIwMTQgd2UgbmF2aWdhdGVkIHRvIGl0IGFuZCBhcmUgd2FpdGluZyBmb3IgdGhlXHJcbiAgICogcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIHJlc3BvbnNlIGJlZm9yZSBhZHZhbmNpbmcuIG51bGwgYmV0d2VlbiB0aWNrc1xyXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xyXG4gIGluZmxpZ2h0OiB7IHR3ZWV0SWQ6IHN0cmluZzsgbmF2aWdhdGVkQXQ6IHN0cmluZyB9IHwgbnVsbDtcclxufVxyXG5cclxuLyoqIEF1dG8tc2Nyb2xsIHNlc3Npb246IGNvdW50cyBvZiB0aWNrcyBhbmQgdHdlZXRzIGluZ2VzdGVkIHNpbmNlIHRoZSB1c2VyXHJcbiAqIGNsaWNrZWQgU3RhcnQuIFBlcnNpc3RlZCBzbyBTVyBldmljdGlvbiBkdXJpbmcgYSBydW4ga2VlcHMgcHJvZ3Jlc3MuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xyXG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xyXG4gIHNjcm9sbENvdW50OiBudW1iZXI7XHJcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xyXG4gIGluZ2VzdGVkTmV3Q291bnQ6IG51bWJlcjtcclxuICBpbmdlc3RlZEV4aXN0aW5nQ291bnQ6IG51bWJlcjtcclxuICBza2lwcGVkT2xkQ291bnQ6IG51bWJlcjtcclxuICBleHBhbmRlZENvdW50OiBudW1iZXI7XHJcbn1cclxuXHJcbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xyXG4gIHNldHRpbmdzOiBTZXR0aW5ncztcclxuICBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdO1xyXG4gIC8qKiBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IHN1Y2Nlc3NmdWwgYWNjb3VudHMueWFtbCBmZXRjaCBmcm9tIHRoZSByZXBvLlxyXG4gICAqIFVzZWQgYnkgYHJlZnJlc2hBY2NvdW50c0xpc3RgIHRvIHNraXAgcmUtZmV0Y2hpbmcgb24gZXZlcnkgU1cgd2FrZSBcdTIwMTQgdGhlXHJcbiAgICogZmlsZSBjaGFuZ2VzIHJhcmVseSBhbmQgYW4gYXV0aGVudGljYXRlZCByYXcgZmV0Y2ggZXZlcnkgd2FrZSBhZGRzIHVwLiAqL1xyXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IHN0cmluZyB8IG51bGw7XHJcbiAgYXJjaGl2ZVNuYXBzaG90OiBBcmNoaXZlU25hcHNob3QgfCBudWxsO1xyXG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcclxuICBjb3VudGVyczogUmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+O1xyXG4gIHJ1bkJ1ZmZlcnM6IFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj47XHJcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XHJcbiAgcmVjZW50VHdlZXRTaWdodGluZ3M6IFR3ZWV0U2lnaHRpbmdbXTtcclxuICBjb21taXR0ZWRJbmRleDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PjtcclxuICAvKiogVHdlZXRzIHRoZSBub3JtYWxpemVyIGZsYWdnZWQgYXMgdHJ1bmNhdGVkIGFuZCB0aGF0IHdlIGhhdmVuJ3Qgc2VlbiBhXHJcbiAgICogZnVsbC10ZXh0IHZlcnNpb24gb2YgeWV0LiBLZXllZCBieSBoYW5kbGUgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gKi9cclxuICByZWZldGNoUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcclxuICAvKiogVHdlZXQgSURzIHNlZW4gdmlhIE1lZGlhLXRhYiAvIHBhcnRpYWwgY2FwdHVyZXMgdGhhdCBjb3VsZG4ndCBiZVxyXG4gICAqIG5vcm1hbGl6ZWQgaW50byBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBLZXllZCBieSBoaW50LWhhbmRsZSAob3JcclxuICAgKiBcIl91bmtub3duXCIpIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuIFRoZSB1c2VyIGNhbiBkcml2ZSBhIGNyYXdsIHRoYXRcclxuICAgKiBvcGVucyBlYWNoIGRldGFpbCBwYWdlIHRvIGNhcHR1cmUgdGhlIHJlYWwgdGhpbmcuICovXHJcbiAgbWVkaWFDcmF3bFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XHJcbiAgcmVmZXRjaFNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcclxuICBtZWRpYUNyYXdsU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xyXG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw7XHJcbn1cclxuXHJcbmNvbnN0IERFRkFVTFRfQ09OTkVDVElPTjogQ29ubmVjdGlvblN0YXRlID0ge1xyXG4gIHN0YXR1czogJ3Vua25vd24nLFxyXG4gIGxvZ2luOiBudWxsLFxyXG4gIGNoZWNrZWRBdDogbnVsbCxcclxuICBlcnJvcjogbnVsbCxcclxuICBkZWZhdWx0QnJhbmNoOiBudWxsLFxyXG4gIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXHJcbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcclxufTtcclxuXHJcbmNvbnN0IERFRkFVTFRTOiBTdG9yYWdlU2hhcGUgPSB7XHJcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9LFxyXG4gIGFjY291bnRzOiBbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdLFxyXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IG51bGwsXHJcbiAgYXJjaGl2ZVNuYXBzaG90OiBudWxsLFxyXG4gIGNvbm5lY3Rpb246IHsgLi4uREVGQVVMVF9DT05ORUNUSU9OIH0sXHJcbiAgY291bnRlcnM6IHt9LFxyXG4gIHJ1bkJ1ZmZlcnM6IHt9LFxyXG4gIGFjdGl2aXR5OiBbXSxcclxuICByZWNlbnRUd2VldFNpZ2h0aW5nczogW10sXHJcbiAgY29tbWl0dGVkSW5kZXg6IHt9LFxyXG4gIHJlZmV0Y2hRdWV1ZToge30sXHJcbiAgbWVkaWFDcmF3bFF1ZXVlOiB7fSxcclxuICByZWZldGNoU2Vzc2lvbjogbnVsbCxcclxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcclxuICBhdXRvU2Nyb2xsU2Vzc2lvbjogbnVsbCxcclxufTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEspOiBQcm9taXNlPFN0b3JhZ2VTaGFwZVtLXT4ge1xyXG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoa2V5KTtcclxuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xyXG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICByZXR1cm4gc3RydWN0dXJlZENsb25lKERFRkFVTFRTW2tleV0pO1xyXG4gIH1cclxuICByZXR1cm4gdmFsdWUgYXMgU3RvcmFnZVNoYXBlW0tdO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLLCB2YWx1ZTogU3RvcmFnZVNoYXBlW0tdKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtrZXldOiB2YWx1ZSB9KTtcclxufVxyXG5cclxuLy8gLS0tIFNldHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XHJcbiAgLy8gQmFja2ZpbGwgYW55IGtleXMgdGhlIHVzZXIncyBzdG9yZWQgc2V0dGluZ3MgcHJlZGF0ZSBcdTIwMTQgcmVhZGVycyBjYW4gcmVseVxyXG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XHJcbiAgLy8gZXZlcnkgY2FsbHNpdGUuIFRoZSBQQVQgaXMgc3RvcmVkIGVuY3J5cHRlZC1hdC1yZXN0IGFzIG9mIHYwLjIuMDsgd2VcclxuICAvLyBkZWNyeXB0IHRyYW5zcGFyZW50bHkgc28gY2FsbGVycyBjb250aW51ZSB0byBzZWUgcGxhaW50ZXh0LlxyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcclxuICBjb25zdCBtZXJnZWQgPSB7IC4uLkRFRkFVTFRfU0VUVElOR1MsIC4uLnN0b3JlZCB9O1xyXG4gIGlmIChtZXJnZWQucGF0ICYmIGlzRW5jcnlwdGVkUGF0KG1lcmdlZC5wYXQpKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBtZXJnZWQucGF0ID0gYXdhaXQgZGVjcnlwdFBhdChtZXJnZWQucGF0KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBtZXJnZWQucGF0ID0gJyc7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBtZXJnZWQ7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXHJcbiAgLy8gb24gdGhlIG5leHQgc2F2ZS5cclxuICBjb25zdCB0b1dyaXRlOiBTZXR0aW5ncyA9IHsgLi4ucyB9O1xyXG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XHJcbiAgICB0b1dyaXRlLnBhdCA9IGF3YWl0IGVuY3J5cHRQYXQodG9Xcml0ZS5wYXQpO1xyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHBhdGNoOiBQYXJ0aWFsPFNldHRpbmdzPik6IFByb21pc2U8U2V0dGluZ3M+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IG5leHQgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcclxuICBhd2FpdCBzZXRTZXR0aW5ncyhuZXh0KTtcclxuICByZXR1cm4gbmV4dDtcclxufVxyXG5cclxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50cygpOiBQcm9taXNlPEFjY291bnRDb25maWdbXT4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzKGE6IEFjY291bnRDb25maWdbXSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzUmVmcmVzaGVkQXQoaXNvOiBzdHJpbmcgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcclxufVxyXG5cclxuLy8gLS0tIEFyY2hpdmUgc25hcHNob3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFyY2hpdmVTbmFwc2hvdCgpOiBQcm9taXNlPEFyY2hpdmVTbmFwc2hvdCB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhcmNoaXZlU25hcHNob3QnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFyY2hpdmVTbmFwc2hvdChzbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYXJjaGl2ZVNuYXBzaG90Jywgc25hcHNob3QpO1xyXG59XHJcblxyXG4vLyAtLS0gQ29ubmVjdGlvbiBzdGF0ZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29ubmVjdGlvbigpOiBQcm9taXNlPENvbm5lY3Rpb25TdGF0ZT4ge1xyXG4gIGNvbnN0IGMgPSBhd2FpdCBnZXRSYXcoJ2Nvbm5lY3Rpb24nKTtcclxuICAvLyBCYWNrZmlsbCBmaWVsZHMgYWRkZWQgYWZ0ZXIgdGhlIHVzZXIncyBzdG9yYWdlIHdhcyB3cml0dGVuLlxyXG4gIGNvbnN0IG91dDogQ29ubmVjdGlvblN0YXRlID0ge1xyXG4gICAgLi4uYyxcclxuICAgIGRlZmF1bHRCcmFuY2g6IGMuZGVmYXVsdEJyYW5jaCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuZGVmYXVsdEJyYW5jaCxcclxuICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6XHJcbiAgICAgIGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcclxuICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGMucmF0ZUxpbWl0UmVzZXRBdCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMucmF0ZUxpbWl0UmVzZXRBdCxcclxuICB9O1xyXG4gIHJldHVybiBvdXQ7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdjb25uZWN0aW9uJywgYyk7XHJcbn1cclxuXHJcbi8vIC0tLSBDb3VudGVycyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xyXG4gIHJldHVybiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q291bnRlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBBY2NvdW50Q291bnRlcj4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdjb3VudGVycycpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBidW1wQ291bnRlcihcclxuICBoYW5kbGU6IHN0cmluZyxcclxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cclxuKTogUHJvbWlzZTxBY2NvdW50Q291bnRlcj4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldENvdW50ZXJzKCk7XHJcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xyXG4gICAgdG9kYXlDb3VudDogMCxcclxuICAgIHRvZGF5RGF0ZTogdG9kYXlJU08oKSxcclxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXHJcbiAgICB0b3RhbENvbW1pdHRlZDogMCxcclxuICAgIGJ1ZmZlcmVkQ291bnQ6IDAsXHJcbiAgfTtcclxuICBpZiAoY3VyLnRvZGF5RGF0ZSAhPT0gdG9kYXlJU08oKSkge1xyXG4gICAgY3VyLnRvZGF5RGF0ZSA9IHRvZGF5SVNPKCk7XHJcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XHJcbiAgfVxyXG4gIGNvbnN0IG5leHQ6IEFjY291bnRDb3VudGVyID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XHJcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xyXG4gIGF3YWl0IHNldFJhdygnY291bnRlcnMnLCBhbGwpO1xyXG4gIHJldHVybiBuZXh0O1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QnVmZmVyZWRDb3VudChoYW5kbGU6IHN0cmluZywgY291bnQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcclxufVxyXG5cclxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIHJldHVybiBhbGxbaGFuZGxlXSA/PyBudWxsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nLCBidWY6IFJ1bkJ1ZmZlcik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBhbGxbaGFuZGxlXSA9IGJ1ZjtcclxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgZGVsZXRlIGFsbFtoYW5kbGVdO1xyXG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XHJcbn1cclxuXHJcbi8vIC0tLSBBY3Rpdml0eSB0YWlsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWN0aXZpdHkoKTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYWN0aXZpdHknKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGVuZEFjdGl2aXR5KGV2OiBMb2dFdmVudCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xyXG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XHJcbiAgY3VyLnVuc2hpZnQoZXYpO1xyXG4gIGlmIChjdXIubGVuZ3RoID4gQUNUSVZJVFlfVEFJTF9NQVgpIGN1ci5sZW5ndGggPSBBQ1RJVklUWV9UQUlMX01BWDtcclxuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcclxuICByZXR1cm4gY3VyO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJBY3Rpdml0eSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgW10pO1xyXG59XHJcblxyXG4vLyAtLS0gUmVjZW50IHR3ZWV0IHNpZ2h0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmNvbnN0IFJFQ0VOVF9UV0VFVF9TSUdIVElOR1NfTUFYID0gODA7XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVjZW50VHdlZXRTaWdodGluZ3MoKTogUHJvbWlzZTxUd2VldFNpZ2h0aW5nW10+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdyZWNlbnRUd2VldFNpZ2h0aW5ncycpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJlcGVuZFJlY2VudFR3ZWV0U2lnaHRpbmdzKHJvd3M6IFR3ZWV0U2lnaHRpbmdbXSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk7XHJcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGNvbnN0IG5leHQ6IFR3ZWV0U2lnaHRpbmdbXSA9IFtdO1xyXG4gIGZvciAoY29uc3Qgcm93IG9mIHJvd3MpIHtcclxuICAgIGNvbnN0IGtleSA9IGAke3Jvdy5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpfToke3Jvdy50d2VldF9pZH1gO1xyXG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xyXG4gICAgc2Vlbi5hZGQoa2V5KTtcclxuICAgIG5leHQucHVzaChyb3cpO1xyXG4gIH1cclxuICBmb3IgKGNvbnN0IHJvdyBvZiBjdXIpIHtcclxuICAgIGNvbnN0IGtleSA9IGAke3Jvdy5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpfToke3Jvdy50d2VldF9pZH1gO1xyXG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xyXG4gICAgc2Vlbi5hZGQoa2V5KTtcclxuICAgIG5leHQucHVzaChyb3cpO1xyXG4gIH1cclxuICBuZXh0Lmxlbmd0aCA9IE1hdGgubWluKG5leHQubGVuZ3RoLCBSRUNFTlRfVFdFRVRfU0lHSFRJTkdTX01BWCk7XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWNlbnRUd2VldFNpZ2h0aW5ncycsIG5leHQpO1xyXG59XHJcblxyXG4vLyAtLS0gQ29tbWl0dGVkLXR3ZWV0cyBkZWR1cCBpbmRleCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29tbWl0dGVkSW5kZXgoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnY29tbWl0dGVkSW5kZXgnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbW1pdHRlZEluZGV4KFxyXG4gIGlkeDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PlxyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2NvbW1pdHRlZEluZGV4JywgaWR4KTtcclxufVxyXG5cclxuLyoqIENvbXB1dGUgdGhlIGVuZ2FnZW1lbnQgc2lnbmF0dXJlIHdlIHVzZSB0byBkZWNpZGUgd2hldGhlciBhIHJlLWNhcHR1cmVkXHJcbiAqIHR3ZWV0IGlzIFwibWF0ZXJpYWxseSBkaWZmZXJlbnRcIiBmcm9tIHdoYXQgd2UgbGFzdCBjb21taXR0ZWQuIFdlIG9taXRcclxuICogdmlld19jb3VudCBiZWNhdXNlIGl0IHRpY2tzIHVwIGZyZXF1ZW50bHkgb24gYWN0aXZlIHR3ZWV0cyBhbmQgd291bGRcclxuICogZGVmZWF0IHRoZSBkZWR1cC4gTGlrZXMgLyBSVHMgLyByZXBsaWVzIC8gcXVvdGVzIGNoYW5nZSByYXJlbHkgZW5vdWdoIHRoYXRcclxuICogZWFjaCBjaGFuZ2UgaXMgd29ydGggYSByZS1jb21taXQgKGFuZCBhbiBlbmdhZ2VtZW50X2hpc3Rvcnkgc25hcHNob3QpLlxyXG4gKiBgaXNfdHJ1bmNhdGVkYCBpcyBmb2xkZWQgaW4gc28gYSByZWZldGNoIHRoYXQgc3dhcHMgdGhlIDI4MC1jaGFyIGhlYWQgZm9yXHJcbiAqIHRoZSBmdWxsIGBub3RlX3R3ZWV0YCBib2R5IGJ5cGFzc2VzIHRoZSBkZWR1cCBldmVuIHdoZW4gZW5nYWdlbWVudCBjb3VudHNcclxuICogaGF2ZW4ndCBtb3ZlZCBcdTIwMTQgb3RoZXJ3aXNlIHRoZSBuZXcgYm9keSB3b3VsZCBiZSBzaWxlbnRseSBkcm9wcGVkLiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gZW5nYWdlbWVudFNpZyhcclxuICBsaWtlczogbnVtYmVyLFxyXG4gIHJldHdlZXRzOiBudW1iZXIsXHJcbiAgcmVwbGllczogbnVtYmVyLFxyXG4gIHF1b3RlczogbnVtYmVyLFxyXG4gIGlzVHJ1bmNhdGVkOiBib29sZWFuID0gZmFsc2VcclxuKTogc3RyaW5nIHtcclxuICByZXR1cm4gYCR7bGlrZXN9fCR7cmV0d2VldHN9fCR7cmVwbGllc318JHtxdW90ZXN9fCR7aXNUcnVuY2F0ZWQgPyAndCcgOiAnZid9YDtcclxufVxyXG5cclxuLyoqIERyb3AgZW50cmllcyBvbGRlciB0aGFuIGBtYXhBZ2VNc2AuIFJldHVybnMgdGhlIG51bWJlciBwcnVuZWQuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcnVuZUNvbW1pdHRlZEluZGV4KG1heEFnZU1zOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgY29uc3QgY3V0b2ZmID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIG1heEFnZU1zKS50b0lTT1N0cmluZygpO1xyXG4gIGxldCBwcnVuZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcclxuICAgIGNvbnN0IGlubmVyID0gaWR4W2hhbmRsZV07XHJcbiAgICBpZiAoIWlubmVyKSBjb250aW51ZTtcclxuICAgIGZvciAoY29uc3QgdGlkIG9mIE9iamVjdC5rZXlzKGlubmVyKSkge1xyXG4gICAgICBjb25zdCBlID0gaW5uZXJbdGlkXTtcclxuICAgICAgaWYgKGUgJiYgZS50cyA8IGN1dG9mZikge1xyXG4gICAgICAgIGRlbGV0ZSBpbm5lclt0aWRdO1xyXG4gICAgICAgIHBydW5lZCArPSAxO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoT2JqZWN0LmtleXMoaW5uZXIpLmxlbmd0aCA9PT0gMCkgZGVsZXRlIGlkeFtoYW5kbGVdO1xyXG4gIH1cclxuICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcclxuICByZXR1cm4gcHJ1bmVkO1xyXG59XHJcblxyXG4vLyAtLS0gUmVmZXRjaCBxdWV1ZSAodHdlZXRzIG5lZWRpbmcgZnVsbC10ZXh0IHJlY2FwdHVyZSkgLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoUXVldWUnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlZmV0Y2hRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGxldCB0b3RhbCA9IDA7XHJcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcclxuICByZXR1cm4gdG90YWw7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXSA/PyBbXTtcclxuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xyXG4gICAgaWRzLnB1c2godHdlZXRJZCk7XHJcbiAgICBxW2hhbmRsZV0gPSBpZHM7XHJcbiAgICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVSZWZldGNoKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdO1xyXG4gIGlmICghaWRzKSByZXR1cm47XHJcbiAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xyXG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2hhbmRsZV07XHJcbiAgZWxzZSBxW2hhbmRsZV0gPSBmaWx0ZXJlZDtcclxuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dFJlZmV0Y2hUYXJnZXQoKTogUHJvbWlzZTx7XHJcbiAgaGFuZGxlOiBzdHJpbmc7XHJcbiAgdHdlZXRJZDogc3RyaW5nO1xyXG59IHwgbnVsbD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcclxuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgaGFuZGxlLCB0d2VldElkOiBpZHNbMF0hIH07XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcblxyXG4vLyAtLS0gTWVkaWEtY3Jhd2wgcXVldWUgKHBhcnRpYWwgY2FwdHVyZXMgYXdhaXRpbmcgZGV0YWlsLXBhZ2UgZmV0Y2gpIC0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGxldCB0b3RhbCA9IDA7XHJcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcclxuICByZXR1cm4gdG90YWw7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlTWVkaWFDcmF3bChoaW50SGFuZGxlOiBzdHJpbmcgfCBudWxsLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgY29uc3QgYnVja2V0ID0gaGludEhhbmRsZSA/PyAnX3Vua25vd24nO1xyXG4gIGNvbnN0IGlkcyA9IHFbYnVja2V0XSA/PyBbXTtcclxuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xyXG4gICAgaWRzLnB1c2godHdlZXRJZCk7XHJcbiAgICBxW2J1Y2tldF0gPSBpZHM7XHJcbiAgICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVNZWRpYUNyYXdsKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xyXG4gIGZvciAoY29uc3QgYnVja2V0IG9mIE9iamVjdC5rZXlzKHEpKSB7XHJcbiAgICBjb25zdCBpZHMgPSBxW2J1Y2tldF07XHJcbiAgICBpZiAoIWlkcykgY29udGludWU7XHJcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XHJcbiAgICBpZiAoZmlsdGVyZWQubGVuZ3RoICE9PSBpZHMubGVuZ3RoKSB7XHJcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xyXG4gICAgICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtidWNrZXRdO1xyXG4gICAgICBlbHNlIHFbYnVja2V0XSA9IGZpbHRlcmVkO1xyXG4gICAgfVxyXG4gIH1cclxuICBpZiAoY2hhbmdlZCkgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRNZWRpYUNyYXdsVGFyZ2V0KCk6IFByb21pc2U8e1xyXG4gIGJ1Y2tldDogc3RyaW5nO1xyXG4gIHR3ZWV0SWQ6IHN0cmluZztcclxufSB8IG51bGw+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgZm9yIChjb25zdCBbYnVja2V0LCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XHJcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGJ1Y2tldCwgdHdlZXRJZDogaWRzWzBdISB9O1xyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuLyoqIEhhcyB0aGlzIHR3ZWV0IGlkIGFscmVhZHkgYmVlbiBjb21taXR0ZWQgKGFueSBoYW5kbGUpPyBVc2VkIHRvIHNraXBcclxuICogZW5xdWV1ZWluZyBtZWRpYS1jcmF3bCB0YXJnZXRzIHdlJ3ZlIGFscmVhZHkgYXJjaGl2ZWQuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpc0NvbW1pdHRlZCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGZvciAoY29uc3QgaW5uZXIgb2YgT2JqZWN0LnZhbHVlcyhpZHgpKSB7XHJcbiAgICBpZiAoaW5uZXIgJiYgdHdlZXRJZCBpbiBpbm5lcikgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG4gIHJldHVybiBmYWxzZTtcclxufVxyXG5cclxuLy8gLS0tIExvb3Agc2Vzc2lvbiBzdGF0ZSAocHJvZ3Jlc3MgKyBpbmZsaWdodCBnYXRpbmcpIC0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hTZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFNlc3Npb24nKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UmVmZXRjaFNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoU2Vzc2lvbicsIHMpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nLCBzKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTogUHJvbWlzZTxBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJywgcyk7XHJcbn1cclxuXHJcbi8vIC0tLSBQdXJnZTogdW5yZWxhdGVkIGJ1ZmZlcnMsIGNvdW50ZXJzLCBxdWV1ZSBlbnRyaWVzIC0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbi8qKlxyXG4gKiBEcm9wIGV2ZXJ5IHBlci1oYW5kbGUgYml0IG9mIHN0YXRlIChjb3VudGVycywgcnVuIGJ1ZmZlciwgY29tbWl0dGVkLWluZGV4XHJcbiAqIGVudHJpZXMsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyaWVzKSB0aGF0IGRvZXNuJ3QgY29ycmVzcG9uZCB0byBhXHJcbiAqIHRyYWNrZWQgYWNjb3VudC4gUmV0dXJucyBhIHN1bW1hcnkgZGVzY3JpYmluZyB3aGF0IHdhcyBjbGVhcmVkIHNvIHRoZVxyXG4gKiBjYWxsZXIgY2FuIGxvZyBpdC5cclxuICpcclxuICogVHJhY2tlZCBhY2NvdW50cyBhcmUgcGFzc2VkIGluIChjYWxsZXIgcmVzb2x2ZXMgZnJvbSB0aGUgbGl2ZSBjb25maWcpLlxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1cmdlVW5yZWxhdGVkU3RhdGUodGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4pOiBQcm9taXNlPHtcclxuICBjb3VudGVyc1JlbW92ZWQ6IG51bWJlcjtcclxuICBidWZmZXJzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XHJcbiAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XHJcbiAgbWVkaWFDcmF3bElkc1JlbW92ZWQ6IG51bWJlcjtcclxufT4ge1xyXG4gIGNvbnN0IHRhcmdMb3dlciA9IG5ldyBTZXQoWy4uLnRhcmdldGVkXS5tYXAoKGgpID0+IGgudG9Mb3dlckNhc2UoKSkpO1xyXG4gIGNvbnN0IGlzVGFyZ2V0ZWQgPSAoaDogc3RyaW5nKTogYm9vbGVhbiA9PiB0YXJnTG93ZXIuaGFzKGgudG9Mb3dlckNhc2UoKSk7XHJcblxyXG4gIC8vIENvdW50ZXJzXHJcbiAgY29uc3QgY291bnRlcnMgPSBhd2FpdCBnZXRDb3VudGVycygpO1xyXG4gIGxldCBjb3VudGVyc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhjb3VudGVycykpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgY291bnRlcnNbaF07XHJcbiAgICAgIGNvdW50ZXJzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgY291bnRlcnMpO1xyXG5cclxuICAvLyBSdW4gYnVmZmVyc1xyXG4gIGNvbnN0IGJ1ZmZlcnMgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgbGV0IGJ1ZmZlcnNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoYnVmZmVycykpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgYnVmZmVyc1toXTtcclxuICAgICAgYnVmZmVyc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYnVmZmVycyk7XHJcblxyXG4gIC8vIENvbW1pdHRlZCBkZWR1cCBpbmRleFxyXG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgbGV0IGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoaWR4KSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIGRlbGV0ZSBpZHhbaF07XHJcbiAgICAgIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XHJcblxyXG4gIC8vIFJlZmV0Y2ggcXVldWU6IGJ1Y2tldHMgYXJlIGtleWVkIGJ5IGhhbmRsZS5cclxuICBjb25zdCBycSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGxldCByZWZldGNoSGFuZGxlc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhycSkpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgcnFbaF07XHJcbiAgICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHJxKTtcclxuXHJcbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IGJ1Y2tldHMgYXJlIGhpbnQtaGFuZGxlcyAob3IgXCJfdW5rbm93blwiKS4gRHJvcFxyXG4gIC8vIGVudHJpZXMgd2hvc2UgYnVja2V0IGlzbid0IHRhcmdldGVkIFx1MjAxNCBpbmNsdWRpbmcgXCJfdW5rbm93blwiIHNpbmNlIHdlXHJcbiAgLy8gY2FuJ3QgdmVyaWZ5IHJlbGF0aW9uLlxyXG4gIGNvbnN0IG1xID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgbGV0IG1lZGlhQ3Jhd2xJZHNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMobXEpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgbWVkaWFDcmF3bElkc1JlbW92ZWQgKz0gKG1xW2hdID8/IFtdKS5sZW5ndGg7XHJcbiAgICAgIGRlbGV0ZSBtcVtoXTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBtcSk7XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBjb3VudGVyc1JlbW92ZWQsXHJcbiAgICBidWZmZXJzUmVtb3ZlZCxcclxuICAgIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkLFxyXG4gICAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkLFxyXG4gICAgbWVkaWFDcmF3bElkc1JlbW92ZWQsXHJcbiAgfTtcclxufVxyXG5cclxuLy8gLS0tIEZ1bGwgcmVzZXQgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5jbGVhcigpO1xyXG59XHJcbiIsICIvKipcclxuICogb3B0aW9ucy50cyBcdTIwMTQgc2V0dGluZ3MgcGFnZS5cclxuICpcclxuICogU3RvcmVzIFBBVCBhbmQgcmVwbyBpZGVudGlmaWVycyBpbiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgdmVyaWZpZXMgYWNjZXNzXHJcbiAqIGJ5IGNhbGxpbmcgL3VzZXIgYW5kIC9yZXBvcy86b3duZXIvOnJlcG8sIGFuZCBzdXJmYWNlcyB0aGUgcmVzdWx0aW5nXHJcbiAqIGNvbm5lY3Rpb24gc3RhdGUuXHJcbiAqL1xyXG5cclxuaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUyB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XHJcbmltcG9ydCB7XHJcbiAgY2xlYXJBbGwsXHJcbiAgZ2V0QWNjb3VudHMsXG4gIGdldEFjdGl2aXR5LFxuICBnZXRBcmNoaXZlU25hcHNob3QsXG4gIGdldENvbm5lY3Rpb24sXG4gIGdldENvdW50ZXJzLFxyXG4gIGdldFJ1bkJ1ZmZlcnMsXHJcbiAgZ2V0U2V0dGluZ3MsXHJcbiAgdXBkYXRlU2V0dGluZ3MsXHJcbn0gZnJvbSAnLi9saWIvc3RvcmFnZS5qcyc7XHJcbmltcG9ydCB0eXBlIHsgUnVudGltZU1lc3NhZ2UgfSBmcm9tICcuL2xpYi90eXBlcy5qcyc7XHJcblxyXG5jb25zdCAkID0gPFQgZXh0ZW5kcyBIVE1MRWxlbWVudCA9IEhUTUxFbGVtZW50PihpZDogc3RyaW5nKTogVCA9PiB7XHJcbiAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCk7XHJcbiAgaWYgKCFlbCkgdGhyb3cgbmV3IEVycm9yKGBtaXNzaW5nIGVsZW1lbnQgIyR7aWR9YCk7XHJcbiAgcmV0dXJuIGVsIGFzIFQ7XHJcbn07XHJcblxyXG5jb25zdCBmb3JtID0gJDxIVE1MRm9ybUVsZW1lbnQ+KCdzZXR0aW5ncy1mb3JtJyk7XHJcbmNvbnN0IG93bmVySW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdvd25lcicpO1xyXG5jb25zdCByZXBvSW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdyZXBvJyk7XHJcbmNvbnN0IGJyYW5jaElucHV0ID0gJDxIVE1MSW5wdXRFbGVtZW50PignYnJhbmNoJyk7XHJcbmNvbnN0IHBhdElucHV0ID0gJDxIVE1MSW5wdXRFbGVtZW50PigncGF0Jyk7XHJcbmNvbnN0IHJldmVhbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZXZlYWwtcGF0Jyk7XHJcbmNvbnN0IHNhdmVTdGF0dXMgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3NhdmUtc3RhdHVzJyk7XHJcbmNvbnN0IGNvbm5EZXRhaWwgPSAkKCdjb25uLWRldGFpbCcpO1xyXG5jb25zdCBhY2NvdW50TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjY291bnQtcmVhZG9ubHknKTtcclxuY29uc3QgcmVmcmVzaEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZWZyZXNoLWFjY291bnRzJyk7XHJcbmNvbnN0IGRpYWdCb3ggPSAkPEhUTUxUZXh0QXJlYUVsZW1lbnQ+KCdkaWFnbm9zdGljcycpO1xyXG5jb25zdCBjb3B5RGlhZ0J0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjb3B5LWRpYWdub3N0aWNzJyk7XHJcbmNvbnN0IGNsZWFyU3RvcmFnZUJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjbGVhci1zdG9yYWdlJyk7XHJcbmNvbnN0IGRpYWdTdGF0dXMgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2RpYWctc3RhdHVzJyk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzZW5kPFQ+KG1zZzogUnVudGltZU1lc3NhZ2UpOiBQcm9taXNlPFQ+IHtcclxuICByZXR1cm4gYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKG1zZykgYXMgUHJvbWlzZTxUPjtcclxufVxyXG5cclxuZnVuY3Rpb24gc2V0U3RhdHVzKGVsOiBIVE1MRWxlbWVudCwga2luZDogJ29rJyB8ICdlcnInIHwgJ3dhcm4nIHwgJycsIG1zZzogc3RyaW5nKTogdm9pZCB7XG4gIGVsLmNsYXNzTmFtZSA9IGtpbmQgPyBgc3RhdHVzICR7a2luZH1gIDogJ3N0YXR1cyc7XG4gIGVsLnRleHRDb250ZW50ID0gbXNnO1xufVxuXG5mdW5jdGlvbiBpc1dyaXRlQXV0aEVycm9yKG1lc3NhZ2U6IHN0cmluZyB8IG51bGwpOiBib29sZWFuIHtcbiAgcmV0dXJuIChcbiAgICB0eXBlb2YgbWVzc2FnZSA9PT0gJ3N0cmluZycgJiZcbiAgICAvUmVzb3VyY2Ugbm90IGFjY2Vzc2libGUgYnkgcGVyc29uYWwgYWNjZXNzIHRva2VufFxcL2dpdFxcL2Jsb2JzfFxcL2dpdFxcL3JlZnMvaS50ZXN0KG1lc3NhZ2UpXG4gICk7XG59XG5cclxuYXN5bmMgZnVuY3Rpb24gbG9hZFNldHRpbmdzKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIG93bmVySW5wdXQudmFsdWUgPSBzLm93bmVyIHx8IERFRkFVTFRfU0VUVElOR1Mub3duZXI7XHJcbiAgcmVwb0lucHV0LnZhbHVlID0gcy5yZXBvIHx8IERFRkFVTFRfU0VUVElOR1MucmVwbztcclxuICBicmFuY2hJbnB1dC52YWx1ZSA9IHMuYnJhbmNoIHx8IERFRkFVTFRfU0VUVElOR1MuYnJhbmNoO1xyXG4gIGlmIChzLnBhdCkge1xyXG4gICAgcGF0SW5wdXQudmFsdWUgPSBzLnBhdDtcclxuICAgIHBhdElucHV0LnBsYWNlaG9sZGVyID0gYFx1MjAyNiR7cy5wYXQuc2xpY2UoLTQpfWA7XHJcbiAgfVxyXG4gIGF3YWl0IHBhaW50Q29ubkRldGFpbCgpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBwYWludENvbm5EZXRhaWwoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBjb25zdCBsaW5lczogc3RyaW5nW10gPSBbXTtcclxuICBsaW5lcy5wdXNoKGBTdGF0dXM6ICR7Y29ubi5zdGF0dXN9YCk7XHJcbiAgaWYgKGNvbm4ubG9naW4pIGxpbmVzLnB1c2goYExvZ2dlZCBpbiBhczogQCR7Y29ubi5sb2dpbn1gKTtcclxuICBsaW5lcy5wdXNoKGBSZXBvc2l0b3J5OiAke3Mub3duZXIgfHwgJz8nfS8ke3MucmVwbyB8fCAnPyd9QCR7cy5icmFuY2ggfHwgJz8nfWApO1xyXG4gIGlmIChjb25uLmNoZWNrZWRBdCkgbGluZXMucHVzaChgTGFzdCBjaGVja2VkOiAke2Nvbm4uY2hlY2tlZEF0fWApO1xyXG4gIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcgJiYgY29ubi5yYXRlTGltaXRSZXNldEF0ICE9PSBudWxsKSB7XHJcbiAgICBjb25zdCByZXNldElzbyA9IG5ldyBEYXRlKGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAqIDEwMDApLnRvSVNPU3RyaW5nKCk7XHJcbiAgICBjb25zdCBkZWx0YVNlYyA9IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAtIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xyXG4gICAgY29uc3QgaW5MYWJlbCA9XHJcbiAgICAgIGRlbHRhU2VjIDw9IDBcclxuICAgICAgICA/ICdtb21lbnRhcmlseSdcclxuICAgICAgICA6IGRlbHRhU2VjIDwgNjBcclxuICAgICAgICAgID8gYGluICR7ZGVsdGFTZWN9c2BcclxuICAgICAgICAgIDogZGVsdGFTZWMgPCAzNjAwXHJcbiAgICAgICAgICAgID8gYGluICR7TWF0aC5yb3VuZChkZWx0YVNlYyAvIDYwKX1tYFxyXG4gICAgICAgICAgICA6IGBpbiAke01hdGgucm91bmQoZGVsdGFTZWMgLyAzNjAwKX1oYDtcclxuICAgIGxpbmVzLnB1c2goYFJhdGUgbGltaXQgcmVzZXRzOiAke3Jlc2V0SXNvfSAoJHtpbkxhYmVsfSlgKTtcclxuICB9XHJcbiAgaWYgKGNvbm4uZXJyb3IpIGxpbmVzLnB1c2goYEVycm9yOiAke2Nvbm4uZXJyb3J9YCk7XHJcbiAgY29ubkRldGFpbC50ZXh0Q29udGVudCA9IGxpbmVzLmpvaW4oJ1xcbicpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBwYWludEFjY291bnRzKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGxpc3QgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gIGFjY291bnRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xyXG4gIGZvciAoY29uc3QgYSBvZiBsaXN0KSB7XHJcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgICBjb25zdCBoYW5kbGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBoYW5kbGUuY2xhc3NOYW1lID0gJ2hhbmRsZSc7XHJcbiAgICBoYW5kbGUudGV4dENvbnRlbnQgPSBgQCR7YS5oYW5kbGV9YDtcclxuICAgIGNvbnN0IGxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgbGFiZWwuY2xhc3NOYW1lID0gJ2xhYmVsJztcclxuICAgIGxhYmVsLnRleHRDb250ZW50ID0gYS5sYWJlbDtcclxuICAgIGxpLmFwcGVuZChoYW5kbGUsIGxhYmVsKTtcclxuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XHJcbiAgfVxyXG59XHJcblxyXG5mb3JtLmFkZEV2ZW50TGlzdGVuZXIoJ3N1Ym1pdCcsIGFzeW5jIChlOiBFdmVudCkgPT4ge1xyXG4gIGUucHJldmVudERlZmF1bHQoKTtcclxuICBjb25zdCBwYXQgPSBwYXRJbnB1dC52YWx1ZS50cmltKCk7XHJcbiAgY29uc3Qgb3duZXIgPSBvd25lcklucHV0LnZhbHVlLnRyaW0oKTtcclxuICBjb25zdCByZXBvID0gcmVwb0lucHV0LnZhbHVlLnRyaW0oKTtcclxuICBjb25zdCBicmFuY2ggPSBicmFuY2hJbnB1dC52YWx1ZS50cmltKCkgfHwgJ21haW4nO1xyXG4gIGlmICghcGF0IHx8ICFvd25lciB8fCAhcmVwbykge1xyXG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICdlcnInLCAnQWxsIGZpZWxkcyBhcmUgcmVxdWlyZWQuJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnJywgJ1NhdmluZ1x1MjAyNicpO1xyXG4gIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgcGF0LCBvd25lciwgcmVwbywgYnJhbmNoLCBjb25maWd1cmVkQXQ6IERhdGUubm93KCkgfSk7XHJcbiAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICcnLCAnVmVyaWZ5aW5nXHUyMDI2Jyk7XHJcbiAgYXdhaXQgc2VuZCh7IHR5cGU6ICd2ZXJpZnktY29ubmVjdGlvbicgfSk7XHJcbiAgYXdhaXQgc2VuZCh7IHR5cGU6ICdyZWZyZXNoLWFjY291bnRzJyB9KTtcclxuICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xyXG4gIGlmIChjb25uLnN0YXR1cyA9PT0gJ29rJykge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnb2snLCBgQ29ubmVjdGVkIGFzIEAke2Nvbm4ubG9naW4gPz8gJz8nfS5gKTtcbiAgfSBlbHNlIGlmIChjb25uLnN0YXR1cyA9PT0gJ2F1dGgtZXJyb3InKSB7XG4gICAgc2V0U3RhdHVzKFxuICAgICAgc2F2ZVN0YXR1cyxcbiAgICAgICdlcnInLFxuICAgICAgaXNXcml0ZUF1dGhFcnJvcihjb25uLmVycm9yKVxuICAgICAgICA/ICdQQVQgY2FuIHJlYWQgdGhpcyByZXBvIGJ1dCBjYW5ub3Qgd3JpdGUuIFNldCBDb250ZW50czogUmVhZCAmIFdyaXRlLidcbiAgICAgICAgOiAnQXV0aCBmYWlsZWQgLSBjaGVjayB0aGUgUEFUIGFuZCBpdHMgcmVwbyBzY29wZS4nXG4gICAgKTtcbiAgfSBlbHNlIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcclxuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnd2FybicsICdSYXRlLWxpbWl0ZWQgXHUyMDE0IHRva2VuIGlzIHZhbGlkIGJ1dCBHaXRIdWIgaXMgdGhyb3R0bGluZy4nKTtcclxuICB9IGVsc2UgaWYgKGNvbm4uc3RhdHVzID09PSAnbmV0d29yay1lcnJvcicpIHtcclxuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgJ05ldHdvcmsgZXJyb3IgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpdml0eS4nKTtcclxuICB9IGVsc2Uge1xyXG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICdlcnInLCBgVmVyaWZpY2F0aW9uOiAke2Nvbm4uc3RhdHVzfWApO1xyXG4gIH1cclxuICBhd2FpdCBwYWludENvbm5EZXRhaWwoKTtcclxuICBhd2FpdCBwYWludEFjY291bnRzKCk7XHJcbiAgYXdhaXQgcmVmcmVzaERpYWcoKTtcclxufSk7XHJcblxyXG5yZXZlYWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgaWYgKHBhdElucHV0LnR5cGUgPT09ICdwYXNzd29yZCcpIHtcclxuICAgIHBhdElucHV0LnR5cGUgPSAndGV4dCc7XHJcbiAgICByZXZlYWxCdG4udGV4dENvbnRlbnQgPSAnSGlkZSc7XHJcbiAgfSBlbHNlIHtcclxuICAgIHBhdElucHV0LnR5cGUgPSAncGFzc3dvcmQnO1xyXG4gICAgcmV2ZWFsQnRuLnRleHRDb250ZW50ID0gJ1Nob3cnO1xyXG4gIH1cclxufSk7XHJcblxyXG5yZWZyZXNoQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xyXG4gIHJlZnJlc2hCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ3JlZnJlc2gtYWNjb3VudHMnIH0pO1xyXG4gICAgYXdhaXQgcGFpbnRBY2NvdW50cygpO1xyXG4gICAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICdvaycsICdBY2NvdW50cyByZWZyZXNoZWQuJyk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBzZXRTdGF0dXMoZGlhZ1N0YXR1cywgJ2VycicsIGBSZWZyZXNoIGZhaWxlZDogJHsoZXJyIGFzIEVycm9yKS5tZXNzYWdlfWApO1xyXG4gIH0gZmluYWxseSB7XHJcbiAgICByZWZyZXNoQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfVxyXG59KTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hEaWFnKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IFtzZXR0aW5ncywgY29ubiwgYWNjb3VudHMsIGNvdW50ZXJzLCBidWZmZXJzLCBhY3Rpdml0eSwgYXJjaGl2ZVNuYXBzaG90XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICBnZXRTZXR0aW5ncygpLFxuICAgIGdldENvbm5lY3Rpb24oKSxcbiAgICBnZXRBY2NvdW50cygpLFxuICAgIGdldENvdW50ZXJzKCksXG4gICAgZ2V0UnVuQnVmZmVycygpLFxuICAgIGdldEFjdGl2aXR5KCksXG4gICAgZ2V0QXJjaGl2ZVNuYXBzaG90KCksXG4gIF0pO1xuICBjb25zdCByZWRhY3RlZEJ1ZmZlcnMgPSBPYmplY3QuZnJvbUVudHJpZXMoXHJcbiAgICBPYmplY3QuZW50cmllcyhidWZmZXJzKS5tYXAoKFtrLCBiXSkgPT4gW1xyXG4gICAgICBrLFxyXG4gICAgICB7XHJcbiAgICAgICAgcnVuX2lkOiBiLnJ1bl9pZCxcclxuICAgICAgICBzdGFydGVkX2F0OiBiLnN0YXJ0ZWRfYXQsXHJcbiAgICAgICAgbGFzdF9jYXB0dXJlX2F0OiBiLmxhc3RfY2FwdHVyZV9hdCxcclxuICAgICAgICB0d2VldHNfY291bnQ6IE9iamVjdC5rZXlzKGIudHdlZXRzX2J5X2lkKS5sZW5ndGgsXHJcbiAgICAgICAgb2JzZXJ2ZWRfY291bnQ6IGIudHdlZXRfaWRzX29ic2VydmVkLmxlbmd0aCxcclxuICAgICAgICBlbmRwb2ludHNfc2VlbjogYi5lbmRwb2ludHNfc2VlbixcclxuICAgICAgICBzb3VyY2VfdXJsOiBiLnNvdXJjZV91cmwsXHJcbiAgICAgIH0sXHJcbiAgICBdKVxyXG4gICk7XHJcbiAgY29uc3QgZHVtcCA9IHtcclxuICAgIHZlcnNpb246IGJyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb24sXHJcbiAgICB1c2VyX2FnZW50OiBuYXZpZ2F0b3IudXNlckFnZW50LFxyXG4gICAgc2V0dGluZ3M6IHtcclxuICAgICAgb3duZXI6IHNldHRpbmdzLm93bmVyLFxyXG4gICAgICByZXBvOiBzZXR0aW5ncy5yZXBvLFxyXG4gICAgICBicmFuY2g6IHNldHRpbmdzLmJyYW5jaCxcbiAgICAgIGF1dG9DYXB0dXJlOiBzZXR0aW5ncy5hdXRvQ2FwdHVyZSxcbiAgICAgIHVwZGF0ZUV4aXN0aW5nOiBzZXR0aW5ncy51cGRhdGVFeGlzdGluZyxcbiAgICAgIGNvbmZpZ3VyZWRBdDogc2V0dGluZ3MuY29uZmlndXJlZEF0LFxuICAgICAgcGF0U2V0OiBzZXR0aW5ncy5wYXQubGVuZ3RoID4gMCxcclxuICAgICAgcGF0U3VmZml4OiBzZXR0aW5ncy5wYXQubGVuZ3RoID49IDQgPyBzZXR0aW5ncy5wYXQuc2xpY2UoLTQpIDogJycsXHJcbiAgICB9LFxyXG4gICAgY29ubmVjdGlvbjogY29ubixcclxuICAgIGFjY291bnRzLFxuICAgIGNvdW50ZXJzLFxuICAgIGFyY2hpdmVTbmFwc2hvdDogYXJjaGl2ZVNuYXBzaG90XG4gICAgICA/IHtcbiAgICAgICAgICBnZW5lcmF0ZWRfYXQ6IGFyY2hpdmVTbmFwc2hvdC5nZW5lcmF0ZWRfYXQsXG4gICAgICAgICAgZmV0Y2hlZF9hdDogYXJjaGl2ZVNuYXBzaG90LmZldGNoZWRfYXQsXG4gICAgICAgICAgYWNjb3VudHM6IE9iamVjdC5rZXlzKGFyY2hpdmVTbmFwc2hvdC5hY2NvdW50cykubGVuZ3RoLFxuICAgICAgICB9XG4gICAgICA6IG51bGwsXG4gICAgcnVuQnVmZmVyczogcmVkYWN0ZWRCdWZmZXJzLFxuICAgIGFjdGl2aXR5X3RhaWxfc2l6ZTogYWN0aXZpdHkubGVuZ3RoLFxyXG4gICAgYWN0aXZpdHlfcmVjZW50OiBhY3Rpdml0eS5zbGljZSgwLCAzMCksXHJcbiAgfTtcclxuICBkaWFnQm94LnZhbHVlID0gSlNPTi5zdHJpbmdpZnkoZHVtcCwgbnVsbCwgMik7XHJcbn1cclxuXHJcbmNvcHlEaWFnQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xyXG4gIGF3YWl0IG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KGRpYWdCb3gudmFsdWUpO1xyXG4gIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnb2snLCAnQ29waWVkIGRpYWdub3N0aWNzIHRvIGNsaXBib2FyZC4nKTtcclxufSk7XHJcblxyXG5jbGVhclN0b3JhZ2VCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgY29uc3Qgb2sgPSB3aW5kb3cuY29uZmlybShcclxuICAgICdDbGVhciBleHRlbnNpb24gc3RvcmFnZT8gVGhpcyBlcmFzZXMgeW91ciBQQVQsIHNldHRpbmdzLCBjb3VudGVycywgYnVmZmVyZWQgY2FwdHVyZXMsIGFuZCBhY3Rpdml0eSB0YWlsLiBUaGVyZSBpcyBubyB1bmRvLidcclxuICApO1xyXG4gIGlmICghb2spIHJldHVybjtcclxuICBhd2FpdCBjbGVhckFsbCgpO1xyXG4gIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnd2FybicsICdTdG9yYWdlIGNsZWFyZWQuJyk7XHJcbiAgYXdhaXQgbG9hZFNldHRpbmdzKCk7XHJcbiAgYXdhaXQgcGFpbnRBY2NvdW50cygpO1xyXG4gIGF3YWl0IHJlZnJlc2hEaWFnKCk7XHJcbn0pO1xyXG5cclxudm9pZCBsb2FkU2V0dGluZ3MoKTtcclxudm9pZCBwYWludEFjY291bnRzKCk7XHJcbnZvaWQgcmVmcmVzaERpYWcoKTtcclxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUVPLElBQU0sbUJBQTZCO0FBQUEsRUFDeEMsS0FBSztBQUFBLEVBQ0wsT0FBTztBQUFBLEVBQ1AsTUFBTTtBQUFBO0FBQUE7QUFBQSxFQUdOLFFBQVE7QUFBQSxFQUNSLFNBQVM7QUFBQSxFQUNULGFBQWE7QUFBQSxFQUNiLGNBQWM7QUFBQSxFQUNkLHVCQUF1QjtBQUFBLEVBQ3ZCLGdCQUFnQjtBQUNsQjtBQU9PLElBQU0sb0JBQXFDO0FBQUEsRUFDaEQsRUFBRSxRQUFRLFVBQVUsT0FBTyxtQ0FBbUMsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFVBQVUsT0FBTyw0Q0FBNEMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLE9BQU8sT0FBTyxzQ0FBc0MsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw2Q0FBNkMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLGNBQWMsT0FBTyxtQkFBbUIsVUFBVSxPQUFPO0FBQUEsRUFDbkUsRUFBRSxRQUFRLFlBQVksT0FBTywrQkFBK0IsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyxrQ0FBa0MsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw0QkFBNEIsVUFBVSxPQUFPO0FBQUEsRUFDdkUsRUFBRSxRQUFRLG1CQUFtQixPQUFPLHFCQUFxQixVQUFVLE9BQU87QUFDNUU7QUE4RE8sSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLOzs7QUNyRXZELElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sa0JBQWtCO0FBRXhCLElBQUksa0JBQW9DO0FBQ3hDLElBQUksc0JBQXFDO0FBRXpDLFNBQVMsU0FBUyxLQUF5QjtBQUN6QyxNQUFJLElBQUk7QUFDUixhQUFXLEtBQUssSUFBSyxNQUFLLE9BQU8sYUFBYSxDQUFDO0FBQy9DLFNBQU8sS0FBSyxDQUFDO0FBQ2Y7QUFFQSxTQUFTLFdBQVcsR0FBdUI7QUFDekMsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixRQUFNLE1BQU0sSUFBSSxXQUFXLElBQUksTUFBTTtBQUNyQyxXQUFTLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxJQUFLLEtBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDO0FBQzlELFNBQU87QUFDVDtBQUVBLGVBQWUsbUJBQW1FO0FBQ2hGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksZ0JBQWdCO0FBQy9ELFFBQU0sSUFBSSxPQUFPLGdCQUFnQjtBQUNqQyxNQUFJLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxHQUFHO0FBQ3pDLFdBQU8sRUFBRSxTQUFTLEdBQUcsTUFBTSxXQUFXLENBQUMsRUFBRTtBQUFBLEVBQzNDO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsUUFBTSxVQUFVLFNBQVMsSUFBSTtBQUM3QixRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGdCQUFnQixHQUFHLFFBQVEsQ0FBQztBQUMvRCxTQUFPLEVBQUUsU0FBUyxLQUFLO0FBQ3pCO0FBRUEsZUFBZSxZQUFnQztBQUM3QyxRQUFNLEVBQUUsU0FBUyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDakQsTUFBSSxvQkFBb0IsUUFBUSx3QkFBd0IsU0FBUztBQUMvRCxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRTtBQUFBLElBQzdCLEdBQUcsUUFBUSxRQUFRLEVBQUUsSUFBSSxRQUFRLFFBQVEsWUFBWSxFQUFFLE9BQU87QUFBQSxFQUNoRTtBQUNBLFFBQU0sV0FBVyxJQUFJLFdBQVcsS0FBSyxTQUFTLEtBQUssTUFBTTtBQUN6RCxXQUFTLElBQUksTUFBTSxDQUFDO0FBQ3BCLFdBQVMsSUFBSSxNQUFNLEtBQUssTUFBTTtBQUM5QixRQUFNLE9BQU8sTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLFFBQVE7QUFDM0QsUUFBTSxNQUFNLE1BQU0sT0FBTyxPQUFPLFVBQVUsT0FBTyxNQUFNLEVBQUUsTUFBTSxVQUFVLEdBQUcsT0FBTztBQUFBLElBQ2pGO0FBQUEsSUFDQTtBQUFBLEVBQ0YsQ0FBQztBQUNELG9CQUFrQjtBQUNsQix3QkFBc0I7QUFDdEIsU0FBTztBQUNUO0FBRU8sU0FBUyxlQUFlLEdBQW9CO0FBQ2pELFNBQU8sRUFBRSxXQUFXLGVBQWU7QUFDckM7QUFFQSxlQUFzQixXQUFXLFdBQW9DO0FBQ25FLE1BQUksQ0FBQyxVQUFXLFFBQU87QUFDdkIsUUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixRQUFNLEtBQUssT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUNwRCxRQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxJQUM3QixFQUFFLE1BQU0sV0FBVyxHQUFHO0FBQUEsSUFDdEI7QUFBQSxJQUNBLElBQUksWUFBWSxFQUFFLE9BQU8sU0FBUztBQUFBLEVBQ3BDO0FBQ0EsU0FBTyxHQUFHLGVBQWUsR0FBRyxTQUFTLEVBQUUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxXQUFXLEVBQUUsQ0FBQyxDQUFDO0FBQzFFO0FBRUEsZUFBc0IsV0FBVyxVQUFtQztBQUNsRSxNQUFJLENBQUMsU0FBVSxRQUFPO0FBR3RCLE1BQUksQ0FBQyxTQUFTLFdBQVcsZUFBZSxFQUFHLFFBQU87QUFDbEQsUUFBTSxRQUFRLFNBQVMsTUFBTSxnQkFBZ0IsTUFBTSxFQUFFLE1BQU0sR0FBRztBQUM5RCxNQUFJLE1BQU0sV0FBVyxFQUFHLFFBQU87QUFDL0IsUUFBTSxDQUFDLE9BQU8sS0FBSyxJQUFJO0FBQ3ZCLE1BQUksQ0FBQyxTQUFTLENBQUMsTUFBTyxRQUFPO0FBQzdCLE1BQUk7QUFDRixVQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxNQUM3QixFQUFFLE1BQU0sV0FBVyxHQUF1QjtBQUFBLE1BQzFDO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxXQUFPLElBQUksWUFBWSxFQUFFLE9BQU8sRUFBRTtBQUFBLEVBQ3BDLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGOzs7QUNuQkEsSUFBTSxxQkFBc0M7QUFBQSxFQUMxQyxRQUFRO0FBQUEsRUFDUixPQUFPO0FBQUEsRUFDUCxXQUFXO0FBQUEsRUFDWCxPQUFPO0FBQUEsRUFDUCxlQUFlO0FBQUEsRUFDZix3QkFBd0I7QUFBQSxFQUN4QixrQkFBa0I7QUFDcEI7QUFFQSxJQUFNLFdBQXlCO0FBQUEsRUFDN0IsVUFBVSxFQUFFLEdBQUcsaUJBQWlCO0FBQUEsRUFDaEMsVUFBVSxDQUFDLEdBQUcsaUJBQWlCO0FBQUEsRUFDL0IscUJBQXFCO0FBQUEsRUFDckIsaUJBQWlCO0FBQUEsRUFDakIsWUFBWSxFQUFFLEdBQUcsbUJBQW1CO0FBQUEsRUFDcEMsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLENBQUM7QUFBQSxFQUNiLFVBQVUsQ0FBQztBQUFBLEVBQ1gsc0JBQXNCLENBQUM7QUFBQSxFQUN2QixnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGNBQWMsQ0FBQztBQUFBLEVBQ2YsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixnQkFBZ0I7QUFBQSxFQUNoQixtQkFBbUI7QUFBQSxFQUNuQixtQkFBbUI7QUFDckI7QUFFQSxlQUFlLE9BQXFDLEtBQWtDO0FBQ3BGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksR0FBRztBQUNsRCxRQUFNLFFBQVEsT0FBTyxHQUFHO0FBQ3hCLE1BQUksVUFBVSxRQUFXO0FBQ3ZCLFdBQU8sZ0JBQWdCLFNBQVMsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxlQUFlLE9BQXFDLEtBQVEsT0FBdUM7QUFDakcsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDO0FBQ2xEO0FBSUEsZUFBc0IsY0FBaUM7QUFLckQsUUFBTSxTQUFTLE1BQU0sT0FBTyxVQUFVO0FBQ3RDLFFBQU0sU0FBUyxFQUFFLEdBQUcsa0JBQWtCLEdBQUcsT0FBTztBQUNoRCxNQUFJLE9BQU8sT0FBTyxlQUFlLE9BQU8sR0FBRyxHQUFHO0FBQzVDLFFBQUk7QUFDRixhQUFPLE1BQU0sTUFBTSxXQUFXLE9BQU8sR0FBRztBQUFBLElBQzFDLFFBQVE7QUFDTixhQUFPLE1BQU07QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLFlBQVksR0FBNEI7QUFHNUQsUUFBTSxVQUFvQixFQUFFLEdBQUcsRUFBRTtBQUNqQyxNQUFJLFFBQVEsT0FBTyxDQUFDLGVBQWUsUUFBUSxHQUFHLEdBQUc7QUFDL0MsWUFBUSxNQUFNLE1BQU0sV0FBVyxRQUFRLEdBQUc7QUFBQSxFQUM1QztBQUNBLFFBQU0sT0FBTyxZQUFZLE9BQU87QUFDbEM7QUFDQSxlQUFzQixlQUFlLE9BQTZDO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxPQUFPLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoQyxRQUFNLFlBQVksSUFBSTtBQUN0QixTQUFPO0FBQ1Q7QUFJQSxlQUFzQixjQUF3QztBQUM1RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQWFBLGVBQXNCLHFCQUFzRDtBQUMxRSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBUUEsZUFBc0IsZ0JBQTBDO0FBQzlELFFBQU0sSUFBSSxNQUFNLE9BQU8sWUFBWTtBQUVuQyxRQUFNLE1BQXVCO0FBQUEsSUFDM0IsR0FBRztBQUFBLElBQ0gsZUFBZSxFQUFFLGtCQUFrQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3hELHdCQUNFLEVBQUUsMkJBQTJCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDcEQsa0JBQWtCLEVBQUUscUJBQXFCLFNBQVksT0FBTyxFQUFFO0FBQUEsRUFDaEU7QUFDQSxTQUFPO0FBQ1Q7QUFXQSxlQUFzQixjQUF1RDtBQUMzRSxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQTZCQSxlQUFzQixnQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLFlBQVk7QUFDNUI7QUFxQkEsZUFBc0IsY0FBbUM7QUFDdkQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFvVEEsZUFBc0IsV0FBMEI7QUFDOUMsUUFBTSxRQUFRLFFBQVEsTUFBTSxNQUFNO0FBQ3BDOzs7QUNuakJBLElBQU0sSUFBSSxDQUFzQyxPQUFrQjtBQUNoRSxRQUFNLEtBQUssU0FBUyxlQUFlLEVBQUU7QUFDckMsTUFBSSxDQUFDLEdBQUksT0FBTSxJQUFJLE1BQU0sb0JBQW9CLEVBQUUsRUFBRTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxJQUFNLE9BQU8sRUFBbUIsZUFBZTtBQUMvQyxJQUFNLGFBQWEsRUFBb0IsT0FBTztBQUM5QyxJQUFNLFlBQVksRUFBb0IsTUFBTTtBQUM1QyxJQUFNLGNBQWMsRUFBb0IsUUFBUTtBQUNoRCxJQUFNLFdBQVcsRUFBb0IsS0FBSztBQUMxQyxJQUFNLFlBQVksRUFBcUIsWUFBWTtBQUNuRCxJQUFNLGFBQWEsRUFBbUIsYUFBYTtBQUNuRCxJQUFNLGFBQWEsRUFBRSxhQUFhO0FBQ2xDLElBQU0sY0FBYyxFQUFvQixrQkFBa0I7QUFDMUQsSUFBTSxhQUFhLEVBQXFCLGtCQUFrQjtBQUMxRCxJQUFNLFVBQVUsRUFBdUIsYUFBYTtBQUNwRCxJQUFNLGNBQWMsRUFBcUIsa0JBQWtCO0FBQzNELElBQU0sa0JBQWtCLEVBQXFCLGVBQWU7QUFDNUQsSUFBTSxhQUFhLEVBQW1CLGFBQWE7QUFFbkQsZUFBZSxLQUFRLEtBQWlDO0FBQ3RELFNBQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUN4QztBQUVBLFNBQVMsVUFBVSxJQUFpQixNQUFrQyxLQUFtQjtBQUN2RixLQUFHLFlBQVksT0FBTyxVQUFVLElBQUksS0FBSztBQUN6QyxLQUFHLGNBQWM7QUFDbkI7QUFFQSxTQUFTLGlCQUFpQixTQUFpQztBQUN6RCxTQUNFLE9BQU8sWUFBWSxZQUNuQiw2RUFBNkUsS0FBSyxPQUFPO0FBRTdGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLGFBQVcsUUFBUSxFQUFFLFNBQVMsaUJBQWlCO0FBQy9DLFlBQVUsUUFBUSxFQUFFLFFBQVEsaUJBQWlCO0FBQzdDLGNBQVksUUFBUSxFQUFFLFVBQVUsaUJBQWlCO0FBQ2pELE1BQUksRUFBRSxLQUFLO0FBQ1QsYUFBUyxRQUFRLEVBQUU7QUFDbkIsYUFBUyxjQUFjLFNBQUksRUFBRSxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFDNUM7QUFDQSxRQUFNLGdCQUFnQjtBQUN4QjtBQUVBLGVBQWUsa0JBQWlDO0FBQzlDLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFFBQWtCLENBQUM7QUFDekIsUUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLEVBQUU7QUFDbkMsTUFBSSxLQUFLLE1BQU8sT0FBTSxLQUFLLGtCQUFrQixLQUFLLEtBQUssRUFBRTtBQUN6RCxRQUFNLEtBQUssZUFBZSxFQUFFLFNBQVMsR0FBRyxJQUFJLEVBQUUsUUFBUSxHQUFHLElBQUksRUFBRSxVQUFVLEdBQUcsRUFBRTtBQUM5RSxNQUFJLEtBQUssVUFBVyxPQUFNLEtBQUssaUJBQWlCLEtBQUssU0FBUyxFQUFFO0FBQ2hFLE1BQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFVBQU0sV0FBVyxJQUFJLEtBQUssS0FBSyxtQkFBbUIsR0FBSSxFQUFFLFlBQVk7QUFDcEUsVUFBTSxXQUFXLEtBQUssbUJBQW1CLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQ3JFLFVBQU0sVUFDSixZQUFZLElBQ1IsZ0JBQ0EsV0FBVyxLQUNULE1BQU0sUUFBUSxNQUNkLFdBQVcsT0FDVCxNQUFNLEtBQUssTUFBTSxXQUFXLEVBQUUsQ0FBQyxNQUMvQixNQUFNLEtBQUssTUFBTSxXQUFXLElBQUksQ0FBQztBQUMzQyxVQUFNLEtBQUssc0JBQXNCLFFBQVEsS0FBSyxPQUFPLEdBQUc7QUFBQSxFQUMxRDtBQUNBLE1BQUksS0FBSyxNQUFPLE9BQU0sS0FBSyxVQUFVLEtBQUssS0FBSyxFQUFFO0FBQ2pELGFBQVcsY0FBYyxNQUFNLEtBQUssSUFBSTtBQUMxQztBQUVBLGVBQWUsZ0JBQStCO0FBQzVDLFFBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsY0FBWSxnQkFBZ0I7QUFDNUIsYUFBVyxLQUFLLE1BQU07QUFDcEIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVk7QUFDbkIsV0FBTyxjQUFjLElBQUksRUFBRSxNQUFNO0FBQ2pDLFVBQU0sUUFBUSxTQUFTLGNBQWMsTUFBTTtBQUMzQyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxjQUFjLEVBQUU7QUFDdEIsT0FBRyxPQUFPLFFBQVEsS0FBSztBQUN2QixnQkFBWSxPQUFPLEVBQUU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsS0FBSyxpQkFBaUIsVUFBVSxPQUFPLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLFFBQU0sTUFBTSxTQUFTLE1BQU0sS0FBSztBQUNoQyxRQUFNLFFBQVEsV0FBVyxNQUFNLEtBQUs7QUFDcEMsUUFBTSxPQUFPLFVBQVUsTUFBTSxLQUFLO0FBQ2xDLFFBQU0sU0FBUyxZQUFZLE1BQU0sS0FBSyxLQUFLO0FBQzNDLE1BQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU07QUFDM0IsY0FBVSxZQUFZLE9BQU8sMEJBQTBCO0FBQ3ZEO0FBQUEsRUFDRjtBQUNBLFlBQVUsWUFBWSxJQUFJLGNBQVM7QUFDbkMsUUFBTSxlQUFlLEVBQUUsS0FBSyxPQUFPLE1BQU0sUUFBUSxjQUFjLEtBQUssSUFBSSxFQUFFLENBQUM7QUFDM0UsWUFBVSxZQUFZLElBQUksaUJBQVk7QUFDdEMsUUFBTSxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUN4QyxRQUFNLEtBQUssRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3ZDLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsTUFBSSxLQUFLLFdBQVcsTUFBTTtBQUN4QixjQUFVLFlBQVksTUFBTSxpQkFBaUIsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUFBLEVBQ25FLFdBQVcsS0FBSyxXQUFXLGNBQWM7QUFDdkM7QUFBQSxNQUNFO0FBQUEsTUFDQTtBQUFBLE1BQ0EsaUJBQWlCLEtBQUssS0FBSyxJQUN2Qix5RUFDQTtBQUFBLElBQ047QUFBQSxFQUNGLFdBQVcsS0FBSyxXQUFXLGdCQUFnQjtBQUN6QyxjQUFVLFlBQVksUUFBUSw4REFBeUQ7QUFBQSxFQUN6RixXQUFXLEtBQUssV0FBVyxpQkFBaUI7QUFDMUMsY0FBVSxZQUFZLE9BQU8sMENBQXFDO0FBQUEsRUFDcEUsT0FBTztBQUNMLGNBQVUsWUFBWSxPQUFPLGlCQUFpQixLQUFLLE1BQU0sRUFBRTtBQUFBLEVBQzdEO0FBQ0EsUUFBTSxnQkFBZ0I7QUFDdEIsUUFBTSxjQUFjO0FBQ3BCLFFBQU0sWUFBWTtBQUNwQixDQUFDO0FBRUQsVUFBVSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3hDLE1BQUksU0FBUyxTQUFTLFlBQVk7QUFDaEMsYUFBUyxPQUFPO0FBQ2hCLGNBQVUsY0FBYztBQUFBLEVBQzFCLE9BQU87QUFDTCxhQUFTLE9BQU87QUFDaEIsY0FBVSxjQUFjO0FBQUEsRUFDMUI7QUFDRixDQUFDO0FBRUQsV0FBVyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9DLGFBQVcsV0FBVztBQUN0QixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUN2QyxVQUFNLGNBQWM7QUFDcEIsY0FBVSxZQUFZLE1BQU0scUJBQXFCO0FBQUEsRUFDbkQsU0FBUyxLQUFLO0FBQ1osY0FBVSxZQUFZLE9BQU8sbUJBQW9CLElBQWMsT0FBTyxFQUFFO0FBQUEsRUFDMUUsVUFBRTtBQUNBLGVBQVcsV0FBVztBQUFBLEVBQ3hCO0FBQ0YsQ0FBQztBQUVELGVBQWUsY0FBNkI7QUFDMUMsUUFBTSxDQUFDLFVBQVUsTUFBTSxVQUFVLFVBQVUsU0FBUyxVQUFVLGVBQWUsSUFBSSxNQUFNLFFBQVEsSUFBSTtBQUFBLElBQ2pHLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxJQUNaLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxJQUNaLG1CQUFtQjtBQUFBLEVBQ3JCLENBQUM7QUFDRCxRQUFNLGtCQUFrQixPQUFPO0FBQUEsSUFDN0IsT0FBTyxRQUFRLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUFBLE1BQ3RDO0FBQUEsTUFDQTtBQUFBLFFBQ0UsUUFBUSxFQUFFO0FBQUEsUUFDVixZQUFZLEVBQUU7QUFBQSxRQUNkLGlCQUFpQixFQUFFO0FBQUEsUUFDbkIsY0FBYyxPQUFPLEtBQUssRUFBRSxZQUFZLEVBQUU7QUFBQSxRQUMxQyxnQkFBZ0IsRUFBRSxtQkFBbUI7QUFBQSxRQUNyQyxnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLFlBQVksRUFBRTtBQUFBLE1BQ2hCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sT0FBTztBQUFBLElBQ1gsU0FBUyxRQUFRLFFBQVEsWUFBWSxFQUFFO0FBQUEsSUFDdkMsWUFBWSxVQUFVO0FBQUEsSUFDdEIsVUFBVTtBQUFBLE1BQ1IsT0FBTyxTQUFTO0FBQUEsTUFDaEIsTUFBTSxTQUFTO0FBQUEsTUFDZixRQUFRLFNBQVM7QUFBQSxNQUNqQixhQUFhLFNBQVM7QUFBQSxNQUN0QixnQkFBZ0IsU0FBUztBQUFBLE1BQ3pCLGNBQWMsU0FBUztBQUFBLE1BQ3ZCLFFBQVEsU0FBUyxJQUFJLFNBQVM7QUFBQSxNQUM5QixXQUFXLFNBQVMsSUFBSSxVQUFVLElBQUksU0FBUyxJQUFJLE1BQU0sRUFBRSxJQUFJO0FBQUEsSUFDakU7QUFBQSxJQUNBLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsaUJBQWlCLGtCQUNiO0FBQUEsTUFDRSxjQUFjLGdCQUFnQjtBQUFBLE1BQzlCLFlBQVksZ0JBQWdCO0FBQUEsTUFDNUIsVUFBVSxPQUFPLEtBQUssZ0JBQWdCLFFBQVEsRUFBRTtBQUFBLElBQ2xELElBQ0E7QUFBQSxJQUNKLFlBQVk7QUFBQSxJQUNaLG9CQUFvQixTQUFTO0FBQUEsSUFDN0IsaUJBQWlCLFNBQVMsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUN2QztBQUNBLFVBQVEsUUFBUSxLQUFLLFVBQVUsTUFBTSxNQUFNLENBQUM7QUFDOUM7QUFFQSxZQUFZLGlCQUFpQixTQUFTLFlBQVk7QUFDaEQsUUFBTSxVQUFVLFVBQVUsVUFBVSxRQUFRLEtBQUs7QUFDakQsWUFBVSxZQUFZLE1BQU0sa0NBQWtDO0FBQ2hFLENBQUM7QUFFRCxnQkFBZ0IsaUJBQWlCLFNBQVMsWUFBWTtBQUNwRCxRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsUUFBTSxTQUFTO0FBQ2YsWUFBVSxZQUFZLFFBQVEsa0JBQWtCO0FBQ2hELFFBQU0sYUFBYTtBQUNuQixRQUFNLGNBQWM7QUFDcEIsUUFBTSxZQUFZO0FBQ3BCLENBQUM7QUFFRCxLQUFLLGFBQWE7QUFDbEIsS0FBSyxjQUFjO0FBQ25CLEtBQUssWUFBWTsiLAogICJuYW1lcyI6IFtdCn0K
