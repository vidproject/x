// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function getCounters() {
  return getRaw("counters");
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getActivity() {
  return getRaw("activity");
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/options.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var form = $("settings-form");
var ownerInput = $("owner");
var repoInput = $("repo");
var branchInput = $("branch");
var patInput = $("pat");
var revealBtn = $("reveal-pat");
var saveStatus = $("save-status");
var connDetail = $("conn-detail");
var accountList = $("account-readonly");
var refreshBtn = $("refresh-accounts");
var diagBox = $("diagnostics");
var copyDiagBtn = $("copy-diagnostics");
var clearStorageBtn = $("clear-storage");
var diagStatus = $("diag-status");
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setStatus(el, kind, msg) {
  el.className = kind ? `status ${kind}` : "status";
  el.textContent = msg;
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
async function loadSettings() {
  const s = await getSettings();
  ownerInput.value = s.owner || DEFAULT_SETTINGS.owner;
  repoInput.value = s.repo || DEFAULT_SETTINGS.repo;
  branchInput.value = s.branch || DEFAULT_SETTINGS.branch;
  if (s.pat) {
    patInput.value = s.pat;
    patInput.placeholder = `\u2026${s.pat.slice(-4)}`;
  }
  await paintConnDetail();
}
async function paintConnDetail() {
  const conn = await getConnection();
  const s = await getSettings();
  const lines = [];
  lines.push(`Status: ${conn.status}`);
  if (conn.login) lines.push(`Logged in as: @${conn.login}`);
  lines.push(`Repository: ${s.owner || "?"}/${s.repo || "?"}@${s.branch || "?"}`);
  if (conn.checkedAt) lines.push(`Last checked: ${conn.checkedAt}`);
  if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
    const resetIso = new Date(conn.rateLimitResetAt * 1e3).toISOString();
    const deltaSec = conn.rateLimitResetAt - Math.floor(Date.now() / 1e3);
    const inLabel = deltaSec <= 0 ? "momentarily" : deltaSec < 60 ? `in ${deltaSec}s` : deltaSec < 3600 ? `in ${Math.round(deltaSec / 60)}m` : `in ${Math.round(deltaSec / 3600)}h`;
    lines.push(`Rate limit resets: ${resetIso} (${inLabel})`);
  }
  if (conn.error) lines.push(`Error: ${conn.error}`);
  connDetail.textContent = lines.join("\n");
}
async function paintAccounts() {
  const list = await getAccounts();
  accountList.replaceChildren();
  for (const a of list) {
    const li = document.createElement("li");
    const handle = document.createElement("span");
    handle.className = "handle";
    handle.textContent = `@${a.handle}`;
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = a.label;
    li.append(handle, label);
    accountList.append(li);
  }
}
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const pat = patInput.value.trim();
  const owner = ownerInput.value.trim();
  const repo = repoInput.value.trim();
  const branch = branchInput.value.trim() || "main";
  if (!pat || !owner || !repo) {
    setStatus(saveStatus, "err", "All fields are required.");
    return;
  }
  setStatus(saveStatus, "", "Saving\u2026");
  await updateSettings({ pat, owner, repo, branch, configuredAt: Date.now() });
  setStatus(saveStatus, "", "Verifying\u2026");
  await send({ type: "verify-connection" });
  await send({ type: "refresh-accounts" });
  const conn = await getConnection();
  if (conn.status === "ok") {
    setStatus(saveStatus, "ok", `Connected as @${conn.login ?? "?"}.`);
  } else if (conn.status === "auth-error") {
    setStatus(
      saveStatus,
      "err",
      isWriteAuthError(conn.error) ? "PAT can read this repo but cannot write. Set Contents: Read & Write." : "Auth failed - check the PAT and its repo scope."
    );
  } else if (conn.status === "rate-limited") {
    setStatus(saveStatus, "warn", "Rate-limited \u2014 token is valid but GitHub is throttling.");
  } else if (conn.status === "network-error") {
    setStatus(saveStatus, "err", "Network error \u2014 check connectivity.");
  } else {
    setStatus(saveStatus, "err", `Verification: ${conn.status}`);
  }
  await paintConnDetail();
  await paintAccounts();
  await refreshDiag();
});
revealBtn.addEventListener("click", () => {
  if (patInput.type === "password") {
    patInput.type = "text";
    revealBtn.textContent = "Hide";
  } else {
    patInput.type = "password";
    revealBtn.textContent = "Show";
  }
});
refreshBtn.addEventListener("click", async () => {
  refreshBtn.disabled = true;
  try {
    await send({ type: "refresh-accounts" });
    await paintAccounts();
    setStatus(diagStatus, "ok", "Accounts refreshed.");
  } catch (err) {
    setStatus(diagStatus, "err", `Refresh failed: ${err.message}`);
  } finally {
    refreshBtn.disabled = false;
  }
});
async function refreshDiag() {
  const [settings, conn, accounts, counters, buffers, activity, archiveSnapshot] = await Promise.all([
    getSettings(),
    getConnection(),
    getAccounts(),
    getCounters(),
    getRunBuffers(),
    getActivity(),
    getArchiveSnapshot()
  ]);
  const redactedBuffers = Object.fromEntries(
    Object.entries(buffers).map(([k, b]) => [
      k,
      {
        run_id: b.run_id,
        started_at: b.started_at,
        last_capture_at: b.last_capture_at,
        tweets_count: Object.keys(b.tweets_by_id).length,
        observed_count: b.tweet_ids_observed.length,
        endpoints_seen: b.endpoints_seen,
        source_url: b.source_url
      }
    ])
  );
  const dump = {
    version: browser.runtime.getManifest().version,
    user_agent: navigator.userAgent,
    settings: {
      owner: settings.owner,
      repo: settings.repo,
      branch: settings.branch,
      autoCapture: settings.autoCapture,
      updateExisting: settings.updateExisting,
      configuredAt: settings.configuredAt,
      patSet: settings.pat.length > 0,
      patSuffix: settings.pat.length >= 4 ? settings.pat.slice(-4) : ""
    },
    connection: conn,
    accounts,
    counters,
    archiveSnapshot: archiveSnapshot ? {
      generated_at: archiveSnapshot.generated_at,
      fetched_at: archiveSnapshot.fetched_at,
      accounts: Object.keys(archiveSnapshot.accounts).length
    } : null,
    runBuffers: redactedBuffers,
    activity_tail_size: activity.length,
    activity_recent: activity.slice(0, 30)
  };
  diagBox.value = JSON.stringify(dump, null, 2);
}
copyDiagBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(diagBox.value);
  setStatus(diagStatus, "ok", "Copied diagnostics to clipboard.");
});
clearStorageBtn.addEventListener("click", async () => {
  const ok = window.confirm(
    "Clear extension storage? This erases your PAT, settings, counters, buffered captures, and activity tail. There is no undo."
  );
  if (!ok) return;
  await clearAll();
  setStatus(diagStatus, "warn", "Storage cleared.");
  await loadSettings();
  await paintAccounts();
  await refreshDiag();
});
void loadSettings();
void paintAccounts();
void refreshDiag();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9vcHRpb25zLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgdHlwZSB7IEFjY291bnRDb25maWcsIFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBTZXR0aW5ncyA9IHtcbiAgcGF0OiAnJyxcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcbiAgcmVwbzogJ3gnLFxuICAvLyBUaGUgcmVwbydzIGN1cnJlbnQgZGVmYXVsdCBicmFuY2ggaXMgXCJtYXN0ZXJcIi4gSWYgeW91IGZvcmsgb3IgcmVuYW1lXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXG4gIGJyYW5jaDogJ21hc3RlcicsXG4gIGVuYWJsZWQ6IHRydWUsXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxuICBjb25maWd1cmVkQXQ6IG51bGwsXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcbiAgdXBkYXRlRXhpc3Rpbmc6IHRydWUsXG59O1xuXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xuXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cbiAqXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXG4gKiBHaXRIdWIgUEFUIGluIHBsYWludGV4dC4gQSBkZXRlcm1pbmVkIGF0dGFja2VyIHdpdGggdGhlIGV4dGVuc2lvbidzIHNvdXJjZVxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxuICogc3RyaW5nIHNpdHRpbmcgbmV4dCB0byBpdHMga2V5IG5hbWUgaW4gZXh0ZW5zaW9uIHN0b3JhZ2UuXG4gKlxuICogU2NoZW1lOlxuICogICAtIE9uIGZpcnN0IGVuY3J5cHRpb24gd2UgZ2VuZXJhdGUgYSAzMi1ieXRlIHNhbHQgYW5kIHBlcnNpc3QgaXQgaW5cbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cbiAqICAgICB8fCBcImltbS1hcmNoaXZlLXBhdC12MVwiYC4gVGhlIHNhbHQgYmVpbmcgcGVyLWluc3RhbGwgbWVhbnMgdHdvIGNvcGllc1xuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxuICogICAtIFBsYWludGV4dCBpcyBlbmNyeXB0ZWQgd2l0aCBhIGZyZXNoIDEyLWJ5dGUgSVYuIFRoZSBlbnZlbG9wZSBmb3JtYXQgaXNcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXG4gKlxuICogQmFja3dhcmRzIGNvbXBhdGliaWxpdHk6IGFuIHVucHJlZml4ZWQgdmFsdWUgaXMgdHJlYXRlZCBhcyBsZWdhY3lcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cbiAqL1xuXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xuXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcbiAgbGV0IHMgPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIGJ1ZikgcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShzKTtcbn1cblxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcbiAgY29uc3QgYmluID0gYXRvYihzKTtcbiAgY29uc3Qgb3V0ID0gbmV3IFVpbnQ4QXJyYXkoYmluLmxlbmd0aCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChTQUxUX1NUT1JBR0VfS0VZKTtcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4geyBzYWx0QjY0OiB2LCBzYWx0OiBmcm9tQmFzZTY0KHYpIH07XG4gIH1cbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcbiAgY29uc3Qgc2FsdEI2NCA9IHRvQmFzZTY0KHNhbHQpO1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICBjb25zdCB7IHNhbHRCNjQsIHNhbHQgfSA9IGF3YWl0IGxvYWRPckNyZWF0ZVNhbHQoKTtcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcbiAgfVxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXG4gICk7XG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcbiAgY29tYmluZWQuc2V0KHNhbHQsIHNlZWQubGVuZ3RoKTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcbiAgICAnZW5jcnlwdCcsXG4gICAgJ2RlY3J5cHQnLFxuICBdKTtcbiAgZGVyaXZlZEtleUNhY2hlID0ga2V5O1xuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcbiAgcmV0dXJuIGtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdi5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbmNyeXB0UGF0KHBsYWludGV4dDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gIGNvbnN0IGl2ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMikpO1xuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcbiAgICBrZXksXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcbiAgKTtcbiAgcmV0dXJuIGAke0VOVkVMT1BFX1BSRUZJWH0ke3RvQmFzZTY0KGl2KX06JHt0b0Jhc2U2NChuZXcgVWludDhBcnJheShjdCkpfWA7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWNyeXB0UGF0KGVudmVsb3BlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXG4gIC8vIHJlLWVuY3J5cHRzIGl0IHZpYSB0aGUgc3RvcmFnZSBsYXllci5cbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xuICBpZiAocGFydHMubGVuZ3RoICE9PSAyKSByZXR1cm4gJyc7XG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XG4gIHRyeSB7XG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcbiAgICBjb25zdCBjdCA9IGZyb21CYXNlNjQoY3RCNjQpO1xuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcbiAgICAgIGtleSxcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShwdCk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnJztcbiAgfVxufVxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB7IGRlY3J5cHRQYXQsIGVuY3J5cHRQYXQsIGlzRW5jcnlwdGVkUGF0IH0gZnJvbSAnLi9jcnlwdG8uanMnO1xuaW1wb3J0IHR5cGUge1xuICBBY2NvdW50Q29uZmlnLFxuICBBY2NvdW50Q291bnRlcixcbiAgQXJjaGl2ZVNuYXBzaG90LFxuICBDYW5vbmljYWxUd2VldCxcbiAgQ29ubmVjdGlvblN0YXRlLFxuICBMb2dFdmVudCxcbiAgU2V0dGluZ3MsXG4gIFR3ZWV0U2lnaHRpbmcsXG4gIFVuYXZhaWxhYmxlVHdlZXQsXG59IGZyb20gJy4vdHlwZXMuanMnO1xuXG4vKipcbiAqIEJ1ZmZlcmVkIHR3ZWV0cyBmb3IgYSBnaXZlbiBhY2NvdW50LCBhd2FpdGluZyBjb21taXQuIEEgXCJydW5cIiBpcyBvbmUgZW50cnlcbiAqIGluIHRoaXMgbWFwOyBmbHVzaGluZyBjbGVhcnMgdGhlIGVudHJ5LiBXZSBzdG9yZSBhcyBSZWNvcmQgc28gdGhlIHN0cnVjdHVyZVxuICogc3Vydml2ZXMgSlNPTiBzZXJpYWxpemF0aW9uIHRocm91Z2ggYnJvd3Nlci5zdG9yYWdlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFJ1bkJ1ZmZlciB7XG4gIHJ1bl9pZDogc3RyaW5nO1xuICBhY2NvdW50X2hhbmRsZTogc3RyaW5nO1xuICBzdGFydGVkX2F0OiBzdHJpbmc7XG4gIGxhc3RfY2FwdHVyZV9hdDogc3RyaW5nO1xuICB0d2VldHNfYnlfaWQ6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PjtcbiAgdW5hdmFpbGFibGVfYnlfaWQ/OiBSZWNvcmQ8c3RyaW5nLCBVbmF2YWlsYWJsZVR3ZWV0PjtcbiAgdHdlZXRfaWRzX29ic2VydmVkOiBzdHJpbmdbXTtcbiAgZW5kcG9pbnRzX3NlZW46IHN0cmluZ1tdO1xuICBzb3VyY2VfdXJsOiBzdHJpbmcgfCBudWxsO1xufVxuXG4vKiogUGVyLXR3ZWV0IGNvbW1pdHRlZC1zdGF0ZSBpbmRleCwga2V5ZWQgYnkgaGFuZGxlIHRoZW4gdHdlZXRfaWQuXG4gKiBVc2VkIHRvIHNraXAgcmUtY2FwdHVyaW5nIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IHB1c2hlZCB3aXRoIGlkZW50aWNhbFxuICogZW5nYWdlbWVudCBjb3VudHMgXHUyMDE0IGF2b2lkcyBnZW5lcmF0aW5nIG9uZSBuZXcgcmF3LyogZmlsZSBldmVyeSBicm93c2UuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdHRlZEVudHJ5IHtcbiAgdHM6IHN0cmluZzsgLy8gSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBjb21taXRcbiAgc2lnOiBzdHJpbmc7IC8vIGVuZ2FnZW1lbnQgc2lnbmF0dXJlOiBcImxpa2V8cnR8cmVwbHl8cXVvdGVcIlxufVxuXG4vKiogUHJvZ3Jlc3MgKyBpbmZsaWdodCB0cmFja2luZyBmb3IgYSBxdWV1ZS1kcml2ZW4gbG9vcCAocmVmZXRjaCAvIG1lZGlhLWNyYXdsKS5cbiAqIFRoZSBsb29wIHBlcnNpc3RzIHRoaXMgc28gYSBTVyBldmljdGlvbiBpbiB0aGUgbWlkZGxlIG9mIGEgcnVuIHByZXNlcnZlc1xuICogXCJYIG9mIFkgcHJvY2Vzc2VkXCIgXHUyMDE0IGFuZCB0aGUgd2FpdC1mb3ItaW5nZXN0IGd1YXJkIGtub3dzIHdoYXQgdG8gZXhwZWN0LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIExvb3BTZXNzaW9uIHtcbiAgLyoqIEluaXRpYWwgcXVldWUgc2l6ZSB3aGVuIHRoZSB1c2VyIGNsaWNrZWQgXCJTdGFydFwiLiAqL1xuICB0b3RhbEF0U3RhcnQ6IG51bWJlcjtcbiAgLyoqIFR3ZWV0cyBwcm9jZXNzZWQgKGluZ2VzdGVkIE9SIGRyb3BwZWQgYWZ0ZXIgcmV0cmllcykgc28gZmFyLiAqL1xuICBwcm9jZXNzZWQ6IG51bWJlcjtcbiAgLyoqIElTTyBvZiB3aGVuIHRoaXMgc2Vzc2lvbiBzdGFydGVkLiAqL1xuICBzdGFydGVkQXQ6IHN0cmluZztcbiAgLyoqIFR3ZWV0IGN1cnJlbnRseSBpbmZsaWdodCBcdTIwMTQgd2UgbmF2aWdhdGVkIHRvIGl0IGFuZCBhcmUgd2FpdGluZyBmb3IgdGhlXG4gICAqIHBhZ2UtaG9vayB0byBjYXB0dXJlIHRoZSByZXNwb25zZSBiZWZvcmUgYWR2YW5jaW5nLiBudWxsIGJldHdlZW4gdGlja3NcbiAgICogKGFuZCBvbmNlIGFuIGluZ2VzdCBoYXMgYmVlbiBvYnNlcnZlZCkuICovXG4gIGluZmxpZ2h0OiB7IHR3ZWV0SWQ6IHN0cmluZzsgbmF2aWdhdGVkQXQ6IHN0cmluZyB9IHwgbnVsbDtcbn1cblxuLyoqIEF1dG8tc2Nyb2xsIHNlc3Npb246IGNvdW50cyBvZiB0aWNrcyBhbmQgdHdlZXRzIGluZ2VzdGVkIHNpbmNlIHRoZSB1c2VyXG4gKiBjbGlja2VkIFN0YXJ0LiBQZXJzaXN0ZWQgc28gU1cgZXZpY3Rpb24gZHVyaW5nIGEgcnVuIGtlZXBzIHByb2dyZXNzLiAqL1xuZXhwb3J0IGludGVyZmFjZSBBdXRvU2Nyb2xsU2Vzc2lvbiB7XG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xuICBzY3JvbGxDb3VudDogbnVtYmVyO1xuICBpbmdlc3RlZENvdW50OiBudW1iZXI7XG4gIGluZ2VzdGVkTmV3Q291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWRFeGlzdGluZ0NvdW50OiBudW1iZXI7XG4gIHNraXBwZWRPbGRDb3VudDogbnVtYmVyO1xuICBleHBhbmRlZENvdW50OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xuICBzZXR0aW5nczogU2V0dGluZ3M7XG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XG4gIC8qKiBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IHN1Y2Nlc3NmdWwgYWNjb3VudHMueWFtbCBmZXRjaCBmcm9tIHRoZSByZXBvLlxuICAgKiBVc2VkIGJ5IGByZWZyZXNoQWNjb3VudHNMaXN0YCB0byBza2lwIHJlLWZldGNoaW5nIG9uIGV2ZXJ5IFNXIHdha2UgXHUyMDE0IHRoZVxuICAgKiBmaWxlIGNoYW5nZXMgcmFyZWx5IGFuZCBhbiBhdXRoZW50aWNhdGVkIHJhdyBmZXRjaCBldmVyeSB3YWtlIGFkZHMgdXAuICovXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IHN0cmluZyB8IG51bGw7XG4gIGFyY2hpdmVTbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbDtcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvblN0YXRlO1xuICBjb3VudGVyczogUmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+O1xuICBydW5CdWZmZXJzOiBSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+O1xuICBhY3Rpdml0eTogTG9nRXZlbnRbXTtcbiAgcmVjZW50VHdlZXRTaWdodGluZ3M6IFR3ZWV0U2lnaHRpbmdbXTtcbiAgY29tbWl0dGVkSW5kZXg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj47XG4gIC8qKiBUd2VldHMgdGhlIG5vcm1hbGl6ZXIgZmxhZ2dlZCBhcyB0cnVuY2F0ZWQgYW5kIHRoYXQgd2UgaGF2ZW4ndCBzZWVuIGFcbiAgICogZnVsbC10ZXh0IHZlcnNpb24gb2YgeWV0LiBLZXllZCBieSBoYW5kbGUgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gKi9cbiAgcmVmZXRjaFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XG4gIC8qKiBUd2VldCBJRHMgc2VlbiB2aWEgTWVkaWEtdGFiIC8gcGFydGlhbCBjYXB0dXJlcyB0aGF0IGNvdWxkbid0IGJlXG4gICAqIG5vcm1hbGl6ZWQgaW50byBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBLZXllZCBieSBoaW50LWhhbmRsZSAob3JcbiAgICogXCJfdW5rbm93blwiKSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiBUaGUgdXNlciBjYW4gZHJpdmUgYSBjcmF3bCB0aGF0XG4gICAqIG9wZW5zIGVhY2ggZGV0YWlsIHBhZ2UgdG8gY2FwdHVyZSB0aGUgcmVhbCB0aGluZy4gKi9cbiAgbWVkaWFDcmF3bFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XG4gIHJlZmV0Y2hTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XG4gIG1lZGlhQ3Jhd2xTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw7XG59XG5cbmNvbnN0IERFRkFVTFRfQ09OTkVDVElPTjogQ29ubmVjdGlvblN0YXRlID0ge1xuICBzdGF0dXM6ICd1bmtub3duJyxcbiAgbG9naW46IG51bGwsXG4gIGNoZWNrZWRBdDogbnVsbCxcbiAgZXJyb3I6IG51bGwsXG4gIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG59O1xuXG5jb25zdCBERUZBVUxUUzogU3RvcmFnZVNoYXBlID0ge1xuICBzZXR0aW5nczogeyAuLi5ERUZBVUxUX1NFVFRJTkdTIH0sXG4gIGFjY291bnRzOiBbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdLFxuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBudWxsLFxuICBhcmNoaXZlU25hcHNob3Q6IG51bGwsXG4gIGNvbm5lY3Rpb246IHsgLi4uREVGQVVMVF9DT05ORUNUSU9OIH0sXG4gIGNvdW50ZXJzOiB7fSxcbiAgcnVuQnVmZmVyczoge30sXG4gIGFjdGl2aXR5OiBbXSxcbiAgcmVjZW50VHdlZXRTaWdodGluZ3M6IFtdLFxuICBjb21taXR0ZWRJbmRleDoge30sXG4gIHJlZmV0Y2hRdWV1ZToge30sXG4gIG1lZGlhQ3Jhd2xRdWV1ZToge30sXG4gIHJlZmV0Y2hTZXNzaW9uOiBudWxsLFxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcbiAgYXV0b1Njcm9sbFNlc3Npb246IG51bGwsXG59O1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChrZXkpO1xuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUoREVGQVVMVFNba2V5XSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW2tleV06IHZhbHVlIH0pO1xufVxuXG4vLyAtLS0gU2V0dGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICAvLyBCYWNrZmlsbCBhbnkga2V5cyB0aGUgdXNlcidzIHN0b3JlZCBzZXR0aW5ncyBwcmVkYXRlIFx1MjAxNCByZWFkZXJzIGNhbiByZWx5XG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XG4gIC8vIGV2ZXJ5IGNhbGxzaXRlLiBUaGUgUEFUIGlzIHN0b3JlZCBlbmNyeXB0ZWQtYXQtcmVzdCBhcyBvZiB2MC4yLjA7IHdlXG4gIC8vIGRlY3J5cHQgdHJhbnNwYXJlbnRseSBzbyBjYWxsZXJzIGNvbnRpbnVlIHRvIHNlZSBwbGFpbnRleHQuXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcbiAgY29uc3QgbWVyZ2VkID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi5zdG9yZWQgfTtcbiAgaWYgKG1lcmdlZC5wYXQgJiYgaXNFbmNyeXB0ZWRQYXQobWVyZ2VkLnBhdCkpIHtcbiAgICB0cnkge1xuICAgICAgbWVyZ2VkLnBhdCA9IGF3YWl0IGRlY3J5cHRQYXQobWVyZ2VkLnBhdCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBtZXJnZWQucGF0ID0gJyc7XG4gICAgfVxuICB9XG4gIHJldHVybiBtZXJnZWQ7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXG4gIC8vIG9uIHRoZSBuZXh0IHNhdmUuXG4gIGNvbnN0IHRvV3JpdGU6IFNldHRpbmdzID0geyAuLi5zIH07XG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XG4gICAgdG9Xcml0ZS5wYXQgPSBhd2FpdCBlbmNyeXB0UGF0KHRvV3JpdGUucGF0KTtcbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2V0dGluZ3MocGF0Y2g6IFBhcnRpYWw8U2V0dGluZ3M+KTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBuZXh0ID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGF3YWl0IHNldFNldHRpbmdzKG5leHQpO1xuICByZXR1cm4gbmV4dDtcbn1cblxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzKCk6IFByb21pc2U8QWNjb3VudENvbmZpZ1tdPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHMoYTogQWNjb3VudENvbmZpZ1tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50c1JlZnJlc2hlZEF0KCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHNSZWZyZXNoZWRBdChpc286IHN0cmluZyB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcbn1cblxuLy8gLS0tIEFyY2hpdmUgc25hcHNob3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXJjaGl2ZVNuYXBzaG90KCk6IFByb21pc2U8QXJjaGl2ZVNuYXBzaG90IHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhcmNoaXZlU25hcHNob3QnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFyY2hpdmVTbmFwc2hvdChzbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FyY2hpdmVTbmFwc2hvdCcsIHNuYXBzaG90KTtcbn1cblxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29ubmVjdGlvbigpOiBQcm9taXNlPENvbm5lY3Rpb25TdGF0ZT4ge1xuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XG4gIC8vIEJhY2tmaWxsIGZpZWxkcyBhZGRlZCBhZnRlciB0aGUgdXNlcidzIHN0b3JhZ2Ugd2FzIHdyaXR0ZW4uXG4gIGNvbnN0IG91dDogQ29ubmVjdGlvblN0YXRlID0ge1xuICAgIC4uLmMsXG4gICAgZGVmYXVsdEJyYW5jaDogYy5kZWZhdWx0QnJhbmNoID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5kZWZhdWx0QnJhbmNoLFxuICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6XG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgcmF0ZUxpbWl0UmVzZXRBdDogYy5yYXRlTGltaXRSZXNldEF0ID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5yYXRlTGltaXRSZXNldEF0LFxuICB9O1xuICByZXR1cm4gb3V0O1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xufVxuXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ2NvdW50ZXJzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xuICAgIHRvZGF5Q291bnQ6IDAsXG4gICAgdG9kYXlEYXRlOiB0b2RheUlTTygpLFxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXG4gICAgYnVmZmVyZWRDb3VudDogMCxcbiAgfTtcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcbiAgICBjdXIudG9kYXlEYXRlID0gdG9kYXlJU08oKTtcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XG4gIH1cbiAgY29uc3QgbmV4dDogQWNjb3VudENvdW50ZXIgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRCdWZmZXJlZENvdW50KGhhbmRsZTogc3RyaW5nLCBjb3VudDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcbn1cblxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj4+IHtcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgcmV0dXJuIGFsbFtoYW5kbGVdID8/IG51bGw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcsIGJ1ZjogUnVuQnVmZmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYWxsW2hhbmRsZV0gPSBidWY7XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcbn1cblxuLy8gLS0tIEFjdGl2aXR5IHRhaWwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY3Rpdml0eScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwZW5kQWN0aXZpdHkoZXY6IExvZ0V2ZW50KTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XG4gIGN1ci51bnNoaWZ0KGV2KTtcbiAgaWYgKGN1ci5sZW5ndGggPiBBQ1RJVklUWV9UQUlMX01BWCkgY3VyLmxlbmd0aCA9IEFDVElWSVRZX1RBSUxfTUFYO1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcbiAgcmV0dXJuIGN1cjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBbXSk7XG59XG5cbi8vIC0tLSBSZWNlbnQgdHdlZXQgc2lnaHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5jb25zdCBSRUNFTlRfVFdFRVRfU0lHSFRJTkdTX01BWCA9IDgwO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVjZW50VHdlZXRTaWdodGluZ3MoKTogUHJvbWlzZTxUd2VldFNpZ2h0aW5nW10+IHtcbiAgcmV0dXJuIGdldFJhdygncmVjZW50VHdlZXRTaWdodGluZ3MnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByZXBlbmRSZWNlbnRUd2VldFNpZ2h0aW5ncyhyb3dzOiBUd2VldFNpZ2h0aW5nW10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKHJvd3MubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgbmV4dDogVHdlZXRTaWdodGluZ1tdID0gW107XG4gIGZvciAoY29uc3Qgcm93IG9mIHJvd3MpIHtcbiAgICBjb25zdCBrZXkgPSBgJHtyb3cuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKX06JHtyb3cudHdlZXRfaWR9YDtcbiAgICBpZiAoc2Vlbi5oYXMoa2V5KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQoa2V5KTtcbiAgICBuZXh0LnB1c2gocm93KTtcbiAgfVxuICBmb3IgKGNvbnN0IHJvdyBvZiBjdXIpIHtcbiAgICBjb25zdCBrZXkgPSBgJHtyb3cuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKX06JHtyb3cudHdlZXRfaWR9YDtcbiAgICBpZiAoc2Vlbi5oYXMoa2V5KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQoa2V5KTtcbiAgICBuZXh0LnB1c2gocm93KTtcbiAgfVxuICBuZXh0Lmxlbmd0aCA9IE1hdGgubWluKG5leHQubGVuZ3RoLCBSRUNFTlRfVFdFRVRfU0lHSFRJTkdTX01BWCk7XG4gIGF3YWl0IHNldFJhdygncmVjZW50VHdlZXRTaWdodGluZ3MnLCBuZXh0KTtcbn1cblxuLy8gLS0tIENvbW1pdHRlZC10d2VldHMgZGVkdXAgaW5kZXggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29tbWl0dGVkSW5kZXgoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+PiB7XG4gIHJldHVybiBnZXRSYXcoJ2NvbW1pdHRlZEluZGV4Jyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb21taXR0ZWRJbmRleChcbiAgaWR4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+XG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdjb21taXR0ZWRJbmRleCcsIGlkeCk7XG59XG5cbi8qKiBDb21wdXRlIHRoZSBlbmdhZ2VtZW50IHNpZ25hdHVyZSB3ZSB1c2UgdG8gZGVjaWRlIHdoZXRoZXIgYSByZS1jYXB0dXJlZFxuICogdHdlZXQgaXMgXCJtYXRlcmlhbGx5IGRpZmZlcmVudFwiIGZyb20gd2hhdCB3ZSBsYXN0IGNvbW1pdHRlZC4gV2Ugb21pdFxuICogdmlld19jb3VudCBiZWNhdXNlIGl0IHRpY2tzIHVwIGZyZXF1ZW50bHkgb24gYWN0aXZlIHR3ZWV0cyBhbmQgd291bGRcbiAqIGRlZmVhdCB0aGUgZGVkdXAuIExpa2VzIC8gUlRzIC8gcmVwbGllcyAvIHF1b3RlcyBjaGFuZ2UgcmFyZWx5IGVub3VnaCB0aGF0XG4gKiBlYWNoIGNoYW5nZSBpcyB3b3J0aCBhIHJlLWNvbW1pdCAoYW5kIGFuIGVuZ2FnZW1lbnRfaGlzdG9yeSBzbmFwc2hvdCkuXG4gKiBgaXNfdHJ1bmNhdGVkYCBpcyBmb2xkZWQgaW4gc28gYSByZWZldGNoIHRoYXQgc3dhcHMgdGhlIDI4MC1jaGFyIGhlYWQgZm9yXG4gKiB0aGUgZnVsbCBgbm90ZV90d2VldGAgYm9keSBieXBhc3NlcyB0aGUgZGVkdXAgZXZlbiB3aGVuIGVuZ2FnZW1lbnQgY291bnRzXG4gKiBoYXZlbid0IG1vdmVkIFx1MjAxNCBvdGhlcndpc2UgdGhlIG5ldyBib2R5IHdvdWxkIGJlIHNpbGVudGx5IGRyb3BwZWQuICovXG5leHBvcnQgZnVuY3Rpb24gZW5nYWdlbWVudFNpZyhcbiAgbGlrZXM6IG51bWJlcixcbiAgcmV0d2VldHM6IG51bWJlcixcbiAgcmVwbGllczogbnVtYmVyLFxuICBxdW90ZXM6IG51bWJlcixcbiAgaXNUcnVuY2F0ZWQ6IGJvb2xlYW4gPSBmYWxzZVxuKTogc3RyaW5nIHtcbiAgcmV0dXJuIGAke2xpa2VzfXwke3JldHdlZXRzfXwke3JlcGxpZXN9fCR7cXVvdGVzfXwke2lzVHJ1bmNhdGVkID8gJ3QnIDogJ2YnfWA7XG59XG5cbi8qKiBEcm9wIGVudHJpZXMgb2xkZXIgdGhhbiBgbWF4QWdlTXNgLiBSZXR1cm5zIHRoZSBudW1iZXIgcHJ1bmVkLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBydW5lQ29tbWl0dGVkSW5kZXgobWF4QWdlTXM6IG51bWJlcik6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGNvbnN0IGN1dG9mZiA9IG5ldyBEYXRlKERhdGUubm93KCkgLSBtYXhBZ2VNcykudG9JU09TdHJpbmcoKTtcbiAgbGV0IHBydW5lZCA9IDA7XG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcbiAgICBjb25zdCBpbm5lciA9IGlkeFtoYW5kbGVdO1xuICAgIGlmICghaW5uZXIpIGNvbnRpbnVlO1xuICAgIGZvciAoY29uc3QgdGlkIG9mIE9iamVjdC5rZXlzKGlubmVyKSkge1xuICAgICAgY29uc3QgZSA9IGlubmVyW3RpZF07XG4gICAgICBpZiAoZSAmJiBlLnRzIDwgY3V0b2ZmKSB7XG4gICAgICAgIGRlbGV0ZSBpbm5lclt0aWRdO1xuICAgICAgICBwcnVuZWQgKz0gMTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKE9iamVjdC5rZXlzKGlubmVyKS5sZW5ndGggPT09IDApIGRlbGV0ZSBpZHhbaGFuZGxlXTtcbiAgfVxuICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcbiAgcmV0dXJuIHBydW5lZDtcbn1cblxuLy8gLS0tIFJlZmV0Y2ggcXVldWUgKHR3ZWV0cyBuZWVkaW5nIGZ1bGwtdGV4dCByZWNhcHR1cmUpIC0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWZldGNoUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVSZWZldGNoKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBjb25zdCBpZHMgPSBxW2hhbmRsZV0gPz8gW107XG4gIGlmICghaWRzLmluY2x1ZGVzKHR3ZWV0SWQpKSB7XG4gICAgaWRzLnB1c2godHdlZXRJZCk7XG4gICAgcVtoYW5kbGVdID0gaWRzO1xuICAgIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVSZWZldGNoKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBjb25zdCBpZHMgPSBxW2hhbmRsZV07XG4gIGlmICghaWRzKSByZXR1cm47XG4gIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcbiAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbaGFuZGxlXTtcbiAgZWxzZSBxW2hhbmRsZV0gPSBmaWx0ZXJlZDtcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRSZWZldGNoVGFyZ2V0KCk6IFByb21pc2U8e1xuICBoYW5kbGU6IHN0cmluZztcbiAgdHdlZXRJZDogc3RyaW5nO1xufSB8IG51bGw+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGhhbmRsZSwgdHdlZXRJZDogaWRzWzBdISB9O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vLyAtLS0gTWVkaWEtY3Jhd2wgcXVldWUgKHBhcnRpYWwgY2FwdHVyZXMgYXdhaXRpbmcgZGV0YWlsLXBhZ2UgZmV0Y2gpIC0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xRdWV1ZSgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgbGV0IHRvdGFsID0gMDtcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcbiAgcmV0dXJuIHRvdGFsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZU1lZGlhQ3Jhd2woaGludEhhbmRsZTogc3RyaW5nIHwgbnVsbCwgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgY29uc3QgYnVja2V0ID0gaGludEhhbmRsZSA/PyAnX3Vua25vd24nO1xuICBjb25zdCBpZHMgPSBxW2J1Y2tldF0gPz8gW107XG4gIGlmICghaWRzLmluY2x1ZGVzKHR3ZWV0SWQpKSB7XG4gICAgaWRzLnB1c2godHdlZXRJZCk7XG4gICAgcVtidWNrZXRdID0gaWRzO1xuICAgIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgcSk7XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVNZWRpYUNyYXdsKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCBjaGFuZ2VkID0gZmFsc2U7XG4gIGZvciAoY29uc3QgYnVja2V0IG9mIE9iamVjdC5rZXlzKHEpKSB7XG4gICAgY29uc3QgaWRzID0gcVtidWNrZXRdO1xuICAgIGlmICghaWRzKSBjb250aW51ZTtcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XG4gICAgaWYgKGZpbHRlcmVkLmxlbmd0aCAhPT0gaWRzLmxlbmd0aCkge1xuICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtidWNrZXRdO1xuICAgICAgZWxzZSBxW2J1Y2tldF0gPSBmaWx0ZXJlZDtcbiAgICB9XG4gIH1cbiAgaWYgKGNoYW5nZWQpIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgcSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0TWVkaWFDcmF3bFRhcmdldCgpOiBQcm9taXNlPHtcbiAgYnVja2V0OiBzdHJpbmc7XG4gIHR3ZWV0SWQ6IHN0cmluZztcbn0gfCBudWxsPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgZm9yIChjb25zdCBbYnVja2V0LCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBidWNrZXQsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLyoqIEhhcyB0aGlzIHR3ZWV0IGlkIGFscmVhZHkgYmVlbiBjb21taXR0ZWQgKGFueSBoYW5kbGUpPyBVc2VkIHRvIHNraXBcbiAqIGVucXVldWVpbmcgbWVkaWEtY3Jhd2wgdGFyZ2V0cyB3ZSd2ZSBhbHJlYWR5IGFyY2hpdmVkLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGlzQ29tbWl0dGVkKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBmb3IgKGNvbnN0IGlubmVyIG9mIE9iamVjdC52YWx1ZXMoaWR4KSkge1xuICAgIGlmIChpbm5lciAmJiB0d2VldElkIGluIGlubmVyKSByZXR1cm4gdHJ1ZTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbi8vIC0tLSBMb29wIHNlc3Npb24gc3RhdGUgKHByb2dyZXNzICsgaW5mbGlnaHQgZ2F0aW5nKSAtLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hTZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UmVmZXRjaFNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFNlc3Npb24nLCBzKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTogUHJvbWlzZTxBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicsIHMpO1xufVxuXG4vLyAtLS0gUHVyZ2U6IHVucmVsYXRlZCBidWZmZXJzLCBjb3VudGVycywgcXVldWUgZW50cmllcyAtLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi8qKlxuICogRHJvcCBldmVyeSBwZXItaGFuZGxlIGJpdCBvZiBzdGF0ZSAoY291bnRlcnMsIHJ1biBidWZmZXIsIGNvbW1pdHRlZC1pbmRleFxuICogZW50cmllcywgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHF1ZXVlIGVudHJpZXMpIHRoYXQgZG9lc24ndCBjb3JyZXNwb25kIHRvIGFcbiAqIHRyYWNrZWQgYWNjb3VudC4gUmV0dXJucyBhIHN1bW1hcnkgZGVzY3JpYmluZyB3aGF0IHdhcyBjbGVhcmVkIHNvIHRoZVxuICogY2FsbGVyIGNhbiBsb2cgaXQuXG4gKlxuICogVHJhY2tlZCBhY2NvdW50cyBhcmUgcGFzc2VkIGluIChjYWxsZXIgcmVzb2x2ZXMgZnJvbSB0aGUgbGl2ZSBjb25maWcpLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHVyZ2VVbnJlbGF0ZWRTdGF0ZSh0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPik6IFByb21pc2U8e1xuICBjb3VudGVyc1JlbW92ZWQ6IG51bWJlcjtcbiAgYnVmZmVyc1JlbW92ZWQ6IG51bWJlcjtcbiAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQ6IG51bWJlcjtcbiAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XG4gIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkOiBudW1iZXI7XG59PiB7XG4gIGNvbnN0IHRhcmdMb3dlciA9IG5ldyBTZXQoWy4uLnRhcmdldGVkXS5tYXAoKGgpID0+IGgudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBpc1RhcmdldGVkID0gKGg6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGFyZ0xvd2VyLmhhcyhoLnRvTG93ZXJDYXNlKCkpO1xuXG4gIC8vIENvdW50ZXJzXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgbGV0IGNvdW50ZXJzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhjb3VudGVycykpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBjb3VudGVyc1toXTtcbiAgICAgIGNvdW50ZXJzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgY291bnRlcnMpO1xuXG4gIC8vIFJ1biBidWZmZXJzXG4gIGNvbnN0IGJ1ZmZlcnMgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGxldCBidWZmZXJzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhidWZmZXJzKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIGJ1ZmZlcnNbaF07XG4gICAgICBidWZmZXJzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBidWZmZXJzKTtcblxuICAvLyBDb21taXR0ZWQgZGVkdXAgaW5kZXhcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgbGV0IGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBpZHhbaF07XG4gICAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xuXG4gIC8vIFJlZmV0Y2ggcXVldWU6IGJ1Y2tldHMgYXJlIGtleWVkIGJ5IGhhbmRsZS5cbiAgY29uc3QgcnEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgbGV0IHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhycSkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBycVtoXTtcbiAgICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHJxKTtcblxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogYnVja2V0cyBhcmUgaGludC1oYW5kbGVzIChvciBcIl91bmtub3duXCIpLiBEcm9wXG4gIC8vIGVudHJpZXMgd2hvc2UgYnVja2V0IGlzbid0IHRhcmdldGVkIFx1MjAxNCBpbmNsdWRpbmcgXCJfdW5rbm93blwiIHNpbmNlIHdlXG4gIC8vIGNhbid0IHZlcmlmeSByZWxhdGlvbi5cbiAgY29uc3QgbXEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgbGV0IG1lZGlhQ3Jhd2xJZHNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKG1xKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgbWVkaWFDcmF3bElkc1JlbW92ZWQgKz0gKG1xW2hdID8/IFtdKS5sZW5ndGg7XG4gICAgICBkZWxldGUgbXFbaF07XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgbXEpO1xuXG4gIHJldHVybiB7XG4gICAgY291bnRlcnNSZW1vdmVkLFxuICAgIGJ1ZmZlcnNSZW1vdmVkLFxuICAgIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkLFxuICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCxcbiAgICBtZWRpYUNyYXdsSWRzUmVtb3ZlZCxcbiAgfTtcbn1cblxuLy8gLS0tIEZ1bGwgcmVzZXQgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJBbGwoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5jbGVhcigpO1xufVxuIiwgIi8qKlxuICogb3B0aW9ucy50cyBcdTIwMTQgc2V0dGluZ3MgcGFnZS5cbiAqXG4gKiBTdG9yZXMgUEFUIGFuZCByZXBvIGlkZW50aWZpZXJzIGluIGBicm93c2VyLnN0b3JhZ2UubG9jYWxgLCB2ZXJpZmllcyBhY2Nlc3NcbiAqIGJ5IGNhbGxpbmcgL3VzZXIgYW5kIC9yZXBvcy86b3duZXIvOnJlcG8sIGFuZCBzdXJmYWNlcyB0aGUgcmVzdWx0aW5nXG4gKiBjb25uZWN0aW9uIHN0YXRlLlxuICovXG5cbmltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MgfSBmcm9tICcuL2xpYi9jb25maWcuanMnO1xuaW1wb3J0IHtcbiAgY2xlYXJBbGwsXG4gIGdldEFjY291bnRzLFxuICBnZXRBY3Rpdml0eSxcbiAgZ2V0QXJjaGl2ZVNuYXBzaG90LFxuICBnZXRDb25uZWN0aW9uLFxuICBnZXRDb3VudGVycyxcbiAgZ2V0UnVuQnVmZmVycyxcbiAgZ2V0U2V0dGluZ3MsXG4gIHVwZGF0ZVNldHRpbmdzLFxufSBmcm9tICcuL2xpYi9zdG9yYWdlLmpzJztcbmltcG9ydCB0eXBlIHsgUnVudGltZU1lc3NhZ2UgfSBmcm9tICcuL2xpYi90eXBlcy5qcyc7XG5cbmNvbnN0ICQgPSA8VCBleHRlbmRzIEhUTUxFbGVtZW50ID0gSFRNTEVsZW1lbnQ+KGlkOiBzdHJpbmcpOiBUID0+IHtcbiAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCk7XG4gIGlmICghZWwpIHRocm93IG5ldyBFcnJvcihgbWlzc2luZyBlbGVtZW50ICMke2lkfWApO1xuICByZXR1cm4gZWwgYXMgVDtcbn07XG5cbmNvbnN0IGZvcm0gPSAkPEhUTUxGb3JtRWxlbWVudD4oJ3NldHRpbmdzLWZvcm0nKTtcbmNvbnN0IG93bmVySW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdvd25lcicpO1xuY29uc3QgcmVwb0lucHV0ID0gJDxIVE1MSW5wdXRFbGVtZW50PigncmVwbycpO1xuY29uc3QgYnJhbmNoSW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdicmFuY2gnKTtcbmNvbnN0IHBhdElucHV0ID0gJDxIVE1MSW5wdXRFbGVtZW50PigncGF0Jyk7XG5jb25zdCByZXZlYWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmV2ZWFsLXBhdCcpO1xuY29uc3Qgc2F2ZVN0YXR1cyA9ICQ8SFRNTFNwYW5FbGVtZW50Pignc2F2ZS1zdGF0dXMnKTtcbmNvbnN0IGNvbm5EZXRhaWwgPSAkKCdjb25uLWRldGFpbCcpO1xuY29uc3QgYWNjb3VudExpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdhY2NvdW50LXJlYWRvbmx5Jyk7XG5jb25zdCByZWZyZXNoQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZnJlc2gtYWNjb3VudHMnKTtcbmNvbnN0IGRpYWdCb3ggPSAkPEhUTUxUZXh0QXJlYUVsZW1lbnQ+KCdkaWFnbm9zdGljcycpO1xuY29uc3QgY29weURpYWdCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY29weS1kaWFnbm9zdGljcycpO1xuY29uc3QgY2xlYXJTdG9yYWdlQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NsZWFyLXN0b3JhZ2UnKTtcbmNvbnN0IGRpYWdTdGF0dXMgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2RpYWctc3RhdHVzJyk7XG5cbmFzeW5jIGZ1bmN0aW9uIHNlbmQ8VD4obXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8VD4ge1xuICByZXR1cm4gYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKG1zZykgYXMgUHJvbWlzZTxUPjtcbn1cblxuZnVuY3Rpb24gc2V0U3RhdHVzKGVsOiBIVE1MRWxlbWVudCwga2luZDogJ29rJyB8ICdlcnInIHwgJ3dhcm4nIHwgJycsIG1zZzogc3RyaW5nKTogdm9pZCB7XG4gIGVsLmNsYXNzTmFtZSA9IGtpbmQgPyBgc3RhdHVzICR7a2luZH1gIDogJ3N0YXR1cyc7XG4gIGVsLnRleHRDb250ZW50ID0gbXNnO1xufVxuXG5mdW5jdGlvbiBpc1dyaXRlQXV0aEVycm9yKG1lc3NhZ2U6IHN0cmluZyB8IG51bGwpOiBib29sZWFuIHtcbiAgcmV0dXJuIChcbiAgICB0eXBlb2YgbWVzc2FnZSA9PT0gJ3N0cmluZycgJiZcbiAgICAvUmVzb3VyY2Ugbm90IGFjY2Vzc2libGUgYnkgcGVyc29uYWwgYWNjZXNzIHRva2VufFxcL2dpdFxcL2Jsb2JzfFxcL2dpdFxcL3JlZnMvaS50ZXN0KG1lc3NhZ2UpXG4gICk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWRTZXR0aW5ncygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIG93bmVySW5wdXQudmFsdWUgPSBzLm93bmVyIHx8IERFRkFVTFRfU0VUVElOR1Mub3duZXI7XG4gIHJlcG9JbnB1dC52YWx1ZSA9IHMucmVwbyB8fCBERUZBVUxUX1NFVFRJTkdTLnJlcG87XG4gIGJyYW5jaElucHV0LnZhbHVlID0gcy5icmFuY2ggfHwgREVGQVVMVF9TRVRUSU5HUy5icmFuY2g7XG4gIGlmIChzLnBhdCkge1xuICAgIHBhdElucHV0LnZhbHVlID0gcy5wYXQ7XG4gICAgcGF0SW5wdXQucGxhY2Vob2xkZXIgPSBgXHUyMDI2JHtzLnBhdC5zbGljZSgtNCl9YDtcbiAgfVxuICBhd2FpdCBwYWludENvbm5EZXRhaWwoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcGFpbnRDb25uRGV0YWlsKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgbGluZXM6IHN0cmluZ1tdID0gW107XG4gIGxpbmVzLnB1c2goYFN0YXR1czogJHtjb25uLnN0YXR1c31gKTtcbiAgaWYgKGNvbm4ubG9naW4pIGxpbmVzLnB1c2goYExvZ2dlZCBpbiBhczogQCR7Y29ubi5sb2dpbn1gKTtcbiAgbGluZXMucHVzaChgUmVwb3NpdG9yeTogJHtzLm93bmVyIHx8ICc/J30vJHtzLnJlcG8gfHwgJz8nfUAke3MuYnJhbmNoIHx8ICc/J31gKTtcbiAgaWYgKGNvbm4uY2hlY2tlZEF0KSBsaW5lcy5wdXNoKGBMYXN0IGNoZWNrZWQ6ICR7Y29ubi5jaGVja2VkQXR9YCk7XG4gIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcgJiYgY29ubi5yYXRlTGltaXRSZXNldEF0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgcmVzZXRJc28gPSBuZXcgRGF0ZShjb25uLnJhdGVMaW1pdFJlc2V0QXQgKiAxMDAwKS50b0lTT1N0cmluZygpO1xuICAgIGNvbnN0IGRlbHRhU2VjID0gY29ubi5yYXRlTGltaXRSZXNldEF0IC0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gICAgY29uc3QgaW5MYWJlbCA9XG4gICAgICBkZWx0YVNlYyA8PSAwXG4gICAgICAgID8gJ21vbWVudGFyaWx5J1xuICAgICAgICA6IGRlbHRhU2VjIDwgNjBcbiAgICAgICAgICA/IGBpbiAke2RlbHRhU2VjfXNgXG4gICAgICAgICAgOiBkZWx0YVNlYyA8IDM2MDBcbiAgICAgICAgICAgID8gYGluICR7TWF0aC5yb3VuZChkZWx0YVNlYyAvIDYwKX1tYFxuICAgICAgICAgICAgOiBgaW4gJHtNYXRoLnJvdW5kKGRlbHRhU2VjIC8gMzYwMCl9aGA7XG4gICAgbGluZXMucHVzaChgUmF0ZSBsaW1pdCByZXNldHM6ICR7cmVzZXRJc299ICgke2luTGFiZWx9KWApO1xuICB9XG4gIGlmIChjb25uLmVycm9yKSBsaW5lcy5wdXNoKGBFcnJvcjogJHtjb25uLmVycm9yfWApO1xuICBjb25uRGV0YWlsLnRleHRDb250ZW50ID0gbGluZXMuam9pbignXFxuJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHBhaW50QWNjb3VudHMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGxpc3QgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICBhY2NvdW50TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgZm9yIChjb25zdCBhIG9mIGxpc3QpIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgY29uc3QgaGFuZGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGhhbmRsZS5jbGFzc05hbWUgPSAnaGFuZGxlJztcbiAgICBoYW5kbGUudGV4dENvbnRlbnQgPSBgQCR7YS5oYW5kbGV9YDtcbiAgICBjb25zdCBsYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBsYWJlbC5jbGFzc05hbWUgPSAnbGFiZWwnO1xuICAgIGxhYmVsLnRleHRDb250ZW50ID0gYS5sYWJlbDtcbiAgICBsaS5hcHBlbmQoaGFuZGxlLCBsYWJlbCk7XG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcbiAgfVxufVxuXG5mb3JtLmFkZEV2ZW50TGlzdGVuZXIoJ3N1Ym1pdCcsIGFzeW5jIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIGNvbnN0IHBhdCA9IHBhdElucHV0LnZhbHVlLnRyaW0oKTtcbiAgY29uc3Qgb3duZXIgPSBvd25lcklucHV0LnZhbHVlLnRyaW0oKTtcbiAgY29uc3QgcmVwbyA9IHJlcG9JbnB1dC52YWx1ZS50cmltKCk7XG4gIGNvbnN0IGJyYW5jaCA9IGJyYW5jaElucHV0LnZhbHVlLnRyaW0oKSB8fCAnbWFpbic7XG4gIGlmICghcGF0IHx8ICFvd25lciB8fCAhcmVwbykge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgJ0FsbCBmaWVsZHMgYXJlIHJlcXVpcmVkLicpO1xuICAgIHJldHVybjtcbiAgfVxuICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJycsICdTYXZpbmdcdTIwMjYnKTtcbiAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBwYXQsIG93bmVyLCByZXBvLCBicmFuY2gsIGNvbmZpZ3VyZWRBdDogRGF0ZS5ub3coKSB9KTtcbiAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICcnLCAnVmVyaWZ5aW5nXHUyMDI2Jyk7XG4gIGF3YWl0IHNlbmQoeyB0eXBlOiAndmVyaWZ5LWNvbm5lY3Rpb24nIH0pO1xuICBhd2FpdCBzZW5kKHsgdHlwZTogJ3JlZnJlc2gtYWNjb3VudHMnIH0pO1xuICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICBpZiAoY29ubi5zdGF0dXMgPT09ICdvaycpIHtcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ29rJywgYENvbm5lY3RlZCBhcyBAJHtjb25uLmxvZ2luID8/ICc/J30uYCk7XG4gIH0gZWxzZSBpZiAoY29ubi5zdGF0dXMgPT09ICdhdXRoLWVycm9yJykge1xuICAgIHNldFN0YXR1cyhcbiAgICAgIHNhdmVTdGF0dXMsXG4gICAgICAnZXJyJyxcbiAgICAgIGlzV3JpdGVBdXRoRXJyb3IoY29ubi5lcnJvcilcbiAgICAgICAgPyAnUEFUIGNhbiByZWFkIHRoaXMgcmVwbyBidXQgY2Fubm90IHdyaXRlLiBTZXQgQ29udGVudHM6IFJlYWQgJiBXcml0ZS4nXG4gICAgICAgIDogJ0F1dGggZmFpbGVkIC0gY2hlY2sgdGhlIFBBVCBhbmQgaXRzIHJlcG8gc2NvcGUuJ1xuICAgICk7XG4gIH0gZWxzZSBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnKSB7XG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICd3YXJuJywgJ1JhdGUtbGltaXRlZCBcdTIwMTQgdG9rZW4gaXMgdmFsaWQgYnV0IEdpdEh1YiBpcyB0aHJvdHRsaW5nLicpO1xuICB9IGVsc2UgaWYgKGNvbm4uc3RhdHVzID09PSAnbmV0d29yay1lcnJvcicpIHtcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ2VycicsICdOZXR3b3JrIGVycm9yIFx1MjAxNCBjaGVjayBjb25uZWN0aXZpdHkuJyk7XG4gIH0gZWxzZSB7XG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICdlcnInLCBgVmVyaWZpY2F0aW9uOiAke2Nvbm4uc3RhdHVzfWApO1xuICB9XG4gIGF3YWl0IHBhaW50Q29ubkRldGFpbCgpO1xuICBhd2FpdCBwYWludEFjY291bnRzKCk7XG4gIGF3YWl0IHJlZnJlc2hEaWFnKCk7XG59KTtcblxucmV2ZWFsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBpZiAocGF0SW5wdXQudHlwZSA9PT0gJ3Bhc3N3b3JkJykge1xuICAgIHBhdElucHV0LnR5cGUgPSAndGV4dCc7XG4gICAgcmV2ZWFsQnRuLnRleHRDb250ZW50ID0gJ0hpZGUnO1xuICB9IGVsc2Uge1xuICAgIHBhdElucHV0LnR5cGUgPSAncGFzc3dvcmQnO1xuICAgIHJldmVhbEJ0bi50ZXh0Q29udGVudCA9ICdTaG93JztcbiAgfVxufSk7XG5cbnJlZnJlc2hCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIHJlZnJlc2hCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAncmVmcmVzaC1hY2NvdW50cycgfSk7XG4gICAgYXdhaXQgcGFpbnRBY2NvdW50cygpO1xuICAgIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnb2snLCAnQWNjb3VudHMgcmVmcmVzaGVkLicpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBzZXRTdGF0dXMoZGlhZ1N0YXR1cywgJ2VycicsIGBSZWZyZXNoIGZhaWxlZDogJHsoZXJyIGFzIEVycm9yKS5tZXNzYWdlfWApO1xuICB9IGZpbmFsbHkge1xuICAgIHJlZnJlc2hCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfVxufSk7XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hEaWFnKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBbc2V0dGluZ3MsIGNvbm4sIGFjY291bnRzLCBjb3VudGVycywgYnVmZmVycywgYWN0aXZpdHksIGFyY2hpdmVTbmFwc2hvdF0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgZ2V0U2V0dGluZ3MoKSxcbiAgICBnZXRDb25uZWN0aW9uKCksXG4gICAgZ2V0QWNjb3VudHMoKSxcbiAgICBnZXRDb3VudGVycygpLFxuICAgIGdldFJ1bkJ1ZmZlcnMoKSxcbiAgICBnZXRBY3Rpdml0eSgpLFxuICAgIGdldEFyY2hpdmVTbmFwc2hvdCgpLFxuICBdKTtcbiAgY29uc3QgcmVkYWN0ZWRCdWZmZXJzID0gT2JqZWN0LmZyb21FbnRyaWVzKFxuICAgIE9iamVjdC5lbnRyaWVzKGJ1ZmZlcnMpLm1hcCgoW2ssIGJdKSA9PiBbXG4gICAgICBrLFxuICAgICAge1xuICAgICAgICBydW5faWQ6IGIucnVuX2lkLFxuICAgICAgICBzdGFydGVkX2F0OiBiLnN0YXJ0ZWRfYXQsXG4gICAgICAgIGxhc3RfY2FwdHVyZV9hdDogYi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICAgIHR3ZWV0c19jb3VudDogT2JqZWN0LmtleXMoYi50d2VldHNfYnlfaWQpLmxlbmd0aCxcbiAgICAgICAgb2JzZXJ2ZWRfY291bnQ6IGIudHdlZXRfaWRzX29ic2VydmVkLmxlbmd0aCxcbiAgICAgICAgZW5kcG9pbnRzX3NlZW46IGIuZW5kcG9pbnRzX3NlZW4sXG4gICAgICAgIHNvdXJjZV91cmw6IGIuc291cmNlX3VybCxcbiAgICAgIH0sXG4gICAgXSlcbiAgKTtcbiAgY29uc3QgZHVtcCA9IHtcbiAgICB2ZXJzaW9uOiBicm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uLFxuICAgIHVzZXJfYWdlbnQ6IG5hdmlnYXRvci51c2VyQWdlbnQsXG4gICAgc2V0dGluZ3M6IHtcbiAgICAgIG93bmVyOiBzZXR0aW5ncy5vd25lcixcbiAgICAgIHJlcG86IHNldHRpbmdzLnJlcG8sXG4gICAgICBicmFuY2g6IHNldHRpbmdzLmJyYW5jaCxcbiAgICAgIGF1dG9DYXB0dXJlOiBzZXR0aW5ncy5hdXRvQ2FwdHVyZSxcbiAgICAgIHVwZGF0ZUV4aXN0aW5nOiBzZXR0aW5ncy51cGRhdGVFeGlzdGluZyxcbiAgICAgIGNvbmZpZ3VyZWRBdDogc2V0dGluZ3MuY29uZmlndXJlZEF0LFxuICAgICAgcGF0U2V0OiBzZXR0aW5ncy5wYXQubGVuZ3RoID4gMCxcbiAgICAgIHBhdFN1ZmZpeDogc2V0dGluZ3MucGF0Lmxlbmd0aCA+PSA0ID8gc2V0dGluZ3MucGF0LnNsaWNlKC00KSA6ICcnLFxuICAgIH0sXG4gICAgY29ubmVjdGlvbjogY29ubixcbiAgICBhY2NvdW50cyxcbiAgICBjb3VudGVycyxcbiAgICBhcmNoaXZlU25hcHNob3Q6IGFyY2hpdmVTbmFwc2hvdFxuICAgICAgPyB7XG4gICAgICAgICAgZ2VuZXJhdGVkX2F0OiBhcmNoaXZlU25hcHNob3QuZ2VuZXJhdGVkX2F0LFxuICAgICAgICAgIGZldGNoZWRfYXQ6IGFyY2hpdmVTbmFwc2hvdC5mZXRjaGVkX2F0LFxuICAgICAgICAgIGFjY291bnRzOiBPYmplY3Qua2V5cyhhcmNoaXZlU25hcHNob3QuYWNjb3VudHMpLmxlbmd0aCxcbiAgICAgICAgfVxuICAgICAgOiBudWxsLFxuICAgIHJ1bkJ1ZmZlcnM6IHJlZGFjdGVkQnVmZmVycyxcbiAgICBhY3Rpdml0eV90YWlsX3NpemU6IGFjdGl2aXR5Lmxlbmd0aCxcbiAgICBhY3Rpdml0eV9yZWNlbnQ6IGFjdGl2aXR5LnNsaWNlKDAsIDMwKSxcbiAgfTtcbiAgZGlhZ0JveC52YWx1ZSA9IEpTT04uc3RyaW5naWZ5KGR1bXAsIG51bGwsIDIpO1xufVxuXG5jb3B5RGlhZ0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgYXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQoZGlhZ0JveC52YWx1ZSk7XG4gIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnb2snLCAnQ29waWVkIGRpYWdub3N0aWNzIHRvIGNsaXBib2FyZC4nKTtcbn0pO1xuXG5jbGVhclN0b3JhZ2VCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGNvbnN0IG9rID0gd2luZG93LmNvbmZpcm0oXG4gICAgJ0NsZWFyIGV4dGVuc2lvbiBzdG9yYWdlPyBUaGlzIGVyYXNlcyB5b3VyIFBBVCwgc2V0dGluZ3MsIGNvdW50ZXJzLCBidWZmZXJlZCBjYXB0dXJlcywgYW5kIGFjdGl2aXR5IHRhaWwuIFRoZXJlIGlzIG5vIHVuZG8uJ1xuICApO1xuICBpZiAoIW9rKSByZXR1cm47XG4gIGF3YWl0IGNsZWFyQWxsKCk7XG4gIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnd2FybicsICdTdG9yYWdlIGNsZWFyZWQuJyk7XG4gIGF3YWl0IGxvYWRTZXR0aW5ncygpO1xuICBhd2FpdCBwYWludEFjY291bnRzKCk7XG4gIGF3YWl0IHJlZnJlc2hEaWFnKCk7XG59KTtcblxudm9pZCBsb2FkU2V0dGluZ3MoKTtcbnZvaWQgcGFpbnRBY2NvdW50cygpO1xudm9pZCByZWZyZXNoRGlhZygpO1xuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUVPLElBQU0sbUJBQTZCO0FBQUEsRUFDeEMsS0FBSztBQUFBLEVBQ0wsT0FBTztBQUFBLEVBQ1AsTUFBTTtBQUFBO0FBQUE7QUFBQSxFQUdOLFFBQVE7QUFBQSxFQUNSLFNBQVM7QUFBQSxFQUNULGFBQWE7QUFBQSxFQUNiLGNBQWM7QUFBQSxFQUNkLHVCQUF1QjtBQUFBLEVBQ3ZCLGdCQUFnQjtBQUNsQjtBQU9PLElBQU0sb0JBQXFDO0FBQUEsRUFDaEQsRUFBRSxRQUFRLFVBQVUsT0FBTyxtQ0FBbUMsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFVBQVUsT0FBTyw0Q0FBNEMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLE9BQU8sT0FBTyxzQ0FBc0MsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw2Q0FBNkMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLGNBQWMsT0FBTyxtQkFBbUIsVUFBVSxPQUFPO0FBQUEsRUFDbkUsRUFBRSxRQUFRLFlBQVksT0FBTywrQkFBK0IsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyxrQ0FBa0MsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw0QkFBNEIsVUFBVSxPQUFPO0FBQUEsRUFDdkUsRUFBRSxRQUFRLG1CQUFtQixPQUFPLHFCQUFxQixVQUFVLE9BQU87QUFDNUU7QUE4RE8sSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLOzs7QUNyRXZELElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sa0JBQWtCO0FBRXhCLElBQUksa0JBQW9DO0FBQ3hDLElBQUksc0JBQXFDO0FBRXpDLFNBQVMsU0FBUyxLQUF5QjtBQUN6QyxNQUFJLElBQUk7QUFDUixhQUFXLEtBQUssSUFBSyxNQUFLLE9BQU8sYUFBYSxDQUFDO0FBQy9DLFNBQU8sS0FBSyxDQUFDO0FBQ2Y7QUFFQSxTQUFTLFdBQVcsR0FBdUI7QUFDekMsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixRQUFNLE1BQU0sSUFBSSxXQUFXLElBQUksTUFBTTtBQUNyQyxXQUFTLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxJQUFLLEtBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDO0FBQzlELFNBQU87QUFDVDtBQUVBLGVBQWUsbUJBQW1FO0FBQ2hGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksZ0JBQWdCO0FBQy9ELFFBQU0sSUFBSSxPQUFPLGdCQUFnQjtBQUNqQyxNQUFJLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxHQUFHO0FBQ3pDLFdBQU8sRUFBRSxTQUFTLEdBQUcsTUFBTSxXQUFXLENBQUMsRUFBRTtBQUFBLEVBQzNDO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsUUFBTSxVQUFVLFNBQVMsSUFBSTtBQUM3QixRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGdCQUFnQixHQUFHLFFBQVEsQ0FBQztBQUMvRCxTQUFPLEVBQUUsU0FBUyxLQUFLO0FBQ3pCO0FBRUEsZUFBZSxZQUFnQztBQUM3QyxRQUFNLEVBQUUsU0FBUyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDakQsTUFBSSxvQkFBb0IsUUFBUSx3QkFBd0IsU0FBUztBQUMvRCxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRTtBQUFBLElBQzdCLEdBQUcsUUFBUSxRQUFRLEVBQUUsSUFBSSxRQUFRLFFBQVEsWUFBWSxFQUFFLE9BQU87QUFBQSxFQUNoRTtBQUNBLFFBQU0sV0FBVyxJQUFJLFdBQVcsS0FBSyxTQUFTLEtBQUssTUFBTTtBQUN6RCxXQUFTLElBQUksTUFBTSxDQUFDO0FBQ3BCLFdBQVMsSUFBSSxNQUFNLEtBQUssTUFBTTtBQUM5QixRQUFNLE9BQU8sTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLFFBQVE7QUFDM0QsUUFBTSxNQUFNLE1BQU0sT0FBTyxPQUFPLFVBQVUsT0FBTyxNQUFNLEVBQUUsTUFBTSxVQUFVLEdBQUcsT0FBTztBQUFBLElBQ2pGO0FBQUEsSUFDQTtBQUFBLEVBQ0YsQ0FBQztBQUNELG9CQUFrQjtBQUNsQix3QkFBc0I7QUFDdEIsU0FBTztBQUNUO0FBRU8sU0FBUyxlQUFlLEdBQW9CO0FBQ2pELFNBQU8sRUFBRSxXQUFXLGVBQWU7QUFDckM7QUFFQSxlQUFzQixXQUFXLFdBQW9DO0FBQ25FLE1BQUksQ0FBQyxVQUFXLFFBQU87QUFDdkIsUUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixRQUFNLEtBQUssT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUNwRCxRQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxJQUM3QixFQUFFLE1BQU0sV0FBVyxHQUFHO0FBQUEsSUFDdEI7QUFBQSxJQUNBLElBQUksWUFBWSxFQUFFLE9BQU8sU0FBUztBQUFBLEVBQ3BDO0FBQ0EsU0FBTyxHQUFHLGVBQWUsR0FBRyxTQUFTLEVBQUUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxXQUFXLEVBQUUsQ0FBQyxDQUFDO0FBQzFFO0FBRUEsZUFBc0IsV0FBVyxVQUFtQztBQUNsRSxNQUFJLENBQUMsU0FBVSxRQUFPO0FBR3RCLE1BQUksQ0FBQyxTQUFTLFdBQVcsZUFBZSxFQUFHLFFBQU87QUFDbEQsUUFBTSxRQUFRLFNBQVMsTUFBTSxnQkFBZ0IsTUFBTSxFQUFFLE1BQU0sR0FBRztBQUM5RCxNQUFJLE1BQU0sV0FBVyxFQUFHLFFBQU87QUFDL0IsUUFBTSxDQUFDLE9BQU8sS0FBSyxJQUFJO0FBQ3ZCLE1BQUksQ0FBQyxTQUFTLENBQUMsTUFBTyxRQUFPO0FBQzdCLE1BQUk7QUFDRixVQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxNQUM3QixFQUFFLE1BQU0sV0FBVyxHQUF1QjtBQUFBLE1BQzFDO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxXQUFPLElBQUksWUFBWSxFQUFFLE9BQU8sRUFBRTtBQUFBLEVBQ3BDLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGOzs7QUNuQkEsSUFBTSxxQkFBc0M7QUFBQSxFQUMxQyxRQUFRO0FBQUEsRUFDUixPQUFPO0FBQUEsRUFDUCxXQUFXO0FBQUEsRUFDWCxPQUFPO0FBQUEsRUFDUCxlQUFlO0FBQUEsRUFDZix3QkFBd0I7QUFBQSxFQUN4QixrQkFBa0I7QUFDcEI7QUFFQSxJQUFNLFdBQXlCO0FBQUEsRUFDN0IsVUFBVSxFQUFFLEdBQUcsaUJBQWlCO0FBQUEsRUFDaEMsVUFBVSxDQUFDLEdBQUcsaUJBQWlCO0FBQUEsRUFDL0IscUJBQXFCO0FBQUEsRUFDckIsaUJBQWlCO0FBQUEsRUFDakIsWUFBWSxFQUFFLEdBQUcsbUJBQW1CO0FBQUEsRUFDcEMsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLENBQUM7QUFBQSxFQUNiLFVBQVUsQ0FBQztBQUFBLEVBQ1gsc0JBQXNCLENBQUM7QUFBQSxFQUN2QixnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGNBQWMsQ0FBQztBQUFBLEVBQ2YsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixnQkFBZ0I7QUFBQSxFQUNoQixtQkFBbUI7QUFBQSxFQUNuQixtQkFBbUI7QUFDckI7QUFFQSxlQUFlLE9BQXFDLEtBQWtDO0FBQ3BGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksR0FBRztBQUNsRCxRQUFNLFFBQVEsT0FBTyxHQUFHO0FBQ3hCLE1BQUksVUFBVSxRQUFXO0FBQ3ZCLFdBQU8sZ0JBQWdCLFNBQVMsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxlQUFlLE9BQXFDLEtBQVEsT0FBdUM7QUFDakcsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDO0FBQ2xEO0FBSUEsZUFBc0IsY0FBaUM7QUFLckQsUUFBTSxTQUFTLE1BQU0sT0FBTyxVQUFVO0FBQ3RDLFFBQU0sU0FBUyxFQUFFLEdBQUcsa0JBQWtCLEdBQUcsT0FBTztBQUNoRCxNQUFJLE9BQU8sT0FBTyxlQUFlLE9BQU8sR0FBRyxHQUFHO0FBQzVDLFFBQUk7QUFDRixhQUFPLE1BQU0sTUFBTSxXQUFXLE9BQU8sR0FBRztBQUFBLElBQzFDLFFBQVE7QUFDTixhQUFPLE1BQU07QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLFlBQVksR0FBNEI7QUFHNUQsUUFBTSxVQUFvQixFQUFFLEdBQUcsRUFBRTtBQUNqQyxNQUFJLFFBQVEsT0FBTyxDQUFDLGVBQWUsUUFBUSxHQUFHLEdBQUc7QUFDL0MsWUFBUSxNQUFNLE1BQU0sV0FBVyxRQUFRLEdBQUc7QUFBQSxFQUM1QztBQUNBLFFBQU0sT0FBTyxZQUFZLE9BQU87QUFDbEM7QUFDQSxlQUFzQixlQUFlLE9BQTZDO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxPQUFPLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoQyxRQUFNLFlBQVksSUFBSTtBQUN0QixTQUFPO0FBQ1Q7QUFJQSxlQUFzQixjQUF3QztBQUM1RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQWFBLGVBQXNCLHFCQUFzRDtBQUMxRSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBUUEsZUFBc0IsZ0JBQTBDO0FBQzlELFFBQU0sSUFBSSxNQUFNLE9BQU8sWUFBWTtBQUVuQyxRQUFNLE1BQXVCO0FBQUEsSUFDM0IsR0FBRztBQUFBLElBQ0gsZUFBZSxFQUFFLGtCQUFrQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3hELHdCQUNFLEVBQUUsMkJBQTJCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDcEQsa0JBQWtCLEVBQUUscUJBQXFCLFNBQVksT0FBTyxFQUFFO0FBQUEsRUFDaEU7QUFDQSxTQUFPO0FBQ1Q7QUFXQSxlQUFzQixjQUF1RDtBQUMzRSxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQTZCQSxlQUFzQixnQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLFlBQVk7QUFDNUI7QUFxQkEsZUFBc0IsY0FBbUM7QUFDdkQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFvVEEsZUFBc0IsV0FBMEI7QUFDOUMsUUFBTSxRQUFRLFFBQVEsTUFBTSxNQUFNO0FBQ3BDOzs7QUNuakJBLElBQU0sSUFBSSxDQUFzQyxPQUFrQjtBQUNoRSxRQUFNLEtBQUssU0FBUyxlQUFlLEVBQUU7QUFDckMsTUFBSSxDQUFDLEdBQUksT0FBTSxJQUFJLE1BQU0sb0JBQW9CLEVBQUUsRUFBRTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxJQUFNLE9BQU8sRUFBbUIsZUFBZTtBQUMvQyxJQUFNLGFBQWEsRUFBb0IsT0FBTztBQUM5QyxJQUFNLFlBQVksRUFBb0IsTUFBTTtBQUM1QyxJQUFNLGNBQWMsRUFBb0IsUUFBUTtBQUNoRCxJQUFNLFdBQVcsRUFBb0IsS0FBSztBQUMxQyxJQUFNLFlBQVksRUFBcUIsWUFBWTtBQUNuRCxJQUFNLGFBQWEsRUFBbUIsYUFBYTtBQUNuRCxJQUFNLGFBQWEsRUFBRSxhQUFhO0FBQ2xDLElBQU0sY0FBYyxFQUFvQixrQkFBa0I7QUFDMUQsSUFBTSxhQUFhLEVBQXFCLGtCQUFrQjtBQUMxRCxJQUFNLFVBQVUsRUFBdUIsYUFBYTtBQUNwRCxJQUFNLGNBQWMsRUFBcUIsa0JBQWtCO0FBQzNELElBQU0sa0JBQWtCLEVBQXFCLGVBQWU7QUFDNUQsSUFBTSxhQUFhLEVBQW1CLGFBQWE7QUFFbkQsZUFBZSxLQUFRLEtBQWlDO0FBQ3RELFNBQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUN4QztBQUVBLFNBQVMsVUFBVSxJQUFpQixNQUFrQyxLQUFtQjtBQUN2RixLQUFHLFlBQVksT0FBTyxVQUFVLElBQUksS0FBSztBQUN6QyxLQUFHLGNBQWM7QUFDbkI7QUFFQSxTQUFTLGlCQUFpQixTQUFpQztBQUN6RCxTQUNFLE9BQU8sWUFBWSxZQUNuQiw2RUFBNkUsS0FBSyxPQUFPO0FBRTdGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLGFBQVcsUUFBUSxFQUFFLFNBQVMsaUJBQWlCO0FBQy9DLFlBQVUsUUFBUSxFQUFFLFFBQVEsaUJBQWlCO0FBQzdDLGNBQVksUUFBUSxFQUFFLFVBQVUsaUJBQWlCO0FBQ2pELE1BQUksRUFBRSxLQUFLO0FBQ1QsYUFBUyxRQUFRLEVBQUU7QUFDbkIsYUFBUyxjQUFjLFNBQUksRUFBRSxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFDNUM7QUFDQSxRQUFNLGdCQUFnQjtBQUN4QjtBQUVBLGVBQWUsa0JBQWlDO0FBQzlDLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFFBQWtCLENBQUM7QUFDekIsUUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLEVBQUU7QUFDbkMsTUFBSSxLQUFLLE1BQU8sT0FBTSxLQUFLLGtCQUFrQixLQUFLLEtBQUssRUFBRTtBQUN6RCxRQUFNLEtBQUssZUFBZSxFQUFFLFNBQVMsR0FBRyxJQUFJLEVBQUUsUUFBUSxHQUFHLElBQUksRUFBRSxVQUFVLEdBQUcsRUFBRTtBQUM5RSxNQUFJLEtBQUssVUFBVyxPQUFNLEtBQUssaUJBQWlCLEtBQUssU0FBUyxFQUFFO0FBQ2hFLE1BQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFVBQU0sV0FBVyxJQUFJLEtBQUssS0FBSyxtQkFBbUIsR0FBSSxFQUFFLFlBQVk7QUFDcEUsVUFBTSxXQUFXLEtBQUssbUJBQW1CLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQ3JFLFVBQU0sVUFDSixZQUFZLElBQ1IsZ0JBQ0EsV0FBVyxLQUNULE1BQU0sUUFBUSxNQUNkLFdBQVcsT0FDVCxNQUFNLEtBQUssTUFBTSxXQUFXLEVBQUUsQ0FBQyxNQUMvQixNQUFNLEtBQUssTUFBTSxXQUFXLElBQUksQ0FBQztBQUMzQyxVQUFNLEtBQUssc0JBQXNCLFFBQVEsS0FBSyxPQUFPLEdBQUc7QUFBQSxFQUMxRDtBQUNBLE1BQUksS0FBSyxNQUFPLE9BQU0sS0FBSyxVQUFVLEtBQUssS0FBSyxFQUFFO0FBQ2pELGFBQVcsY0FBYyxNQUFNLEtBQUssSUFBSTtBQUMxQztBQUVBLGVBQWUsZ0JBQStCO0FBQzVDLFFBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsY0FBWSxnQkFBZ0I7QUFDNUIsYUFBVyxLQUFLLE1BQU07QUFDcEIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVk7QUFDbkIsV0FBTyxjQUFjLElBQUksRUFBRSxNQUFNO0FBQ2pDLFVBQU0sUUFBUSxTQUFTLGNBQWMsTUFBTTtBQUMzQyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxjQUFjLEVBQUU7QUFDdEIsT0FBRyxPQUFPLFFBQVEsS0FBSztBQUN2QixnQkFBWSxPQUFPLEVBQUU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsS0FBSyxpQkFBaUIsVUFBVSxPQUFPLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLFFBQU0sTUFBTSxTQUFTLE1BQU0sS0FBSztBQUNoQyxRQUFNLFFBQVEsV0FBVyxNQUFNLEtBQUs7QUFDcEMsUUFBTSxPQUFPLFVBQVUsTUFBTSxLQUFLO0FBQ2xDLFFBQU0sU0FBUyxZQUFZLE1BQU0sS0FBSyxLQUFLO0FBQzNDLE1BQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU07QUFDM0IsY0FBVSxZQUFZLE9BQU8sMEJBQTBCO0FBQ3ZEO0FBQUEsRUFDRjtBQUNBLFlBQVUsWUFBWSxJQUFJLGNBQVM7QUFDbkMsUUFBTSxlQUFlLEVBQUUsS0FBSyxPQUFPLE1BQU0sUUFBUSxjQUFjLEtBQUssSUFBSSxFQUFFLENBQUM7QUFDM0UsWUFBVSxZQUFZLElBQUksaUJBQVk7QUFDdEMsUUFBTSxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUN4QyxRQUFNLEtBQUssRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3ZDLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsTUFBSSxLQUFLLFdBQVcsTUFBTTtBQUN4QixjQUFVLFlBQVksTUFBTSxpQkFBaUIsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUFBLEVBQ25FLFdBQVcsS0FBSyxXQUFXLGNBQWM7QUFDdkM7QUFBQSxNQUNFO0FBQUEsTUFDQTtBQUFBLE1BQ0EsaUJBQWlCLEtBQUssS0FBSyxJQUN2Qix5RUFDQTtBQUFBLElBQ047QUFBQSxFQUNGLFdBQVcsS0FBSyxXQUFXLGdCQUFnQjtBQUN6QyxjQUFVLFlBQVksUUFBUSw4REFBeUQ7QUFBQSxFQUN6RixXQUFXLEtBQUssV0FBVyxpQkFBaUI7QUFDMUMsY0FBVSxZQUFZLE9BQU8sMENBQXFDO0FBQUEsRUFDcEUsT0FBTztBQUNMLGNBQVUsWUFBWSxPQUFPLGlCQUFpQixLQUFLLE1BQU0sRUFBRTtBQUFBLEVBQzdEO0FBQ0EsUUFBTSxnQkFBZ0I7QUFDdEIsUUFBTSxjQUFjO0FBQ3BCLFFBQU0sWUFBWTtBQUNwQixDQUFDO0FBRUQsVUFBVSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3hDLE1BQUksU0FBUyxTQUFTLFlBQVk7QUFDaEMsYUFBUyxPQUFPO0FBQ2hCLGNBQVUsY0FBYztBQUFBLEVBQzFCLE9BQU87QUFDTCxhQUFTLE9BQU87QUFDaEIsY0FBVSxjQUFjO0FBQUEsRUFDMUI7QUFDRixDQUFDO0FBRUQsV0FBVyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9DLGFBQVcsV0FBVztBQUN0QixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUN2QyxVQUFNLGNBQWM7QUFDcEIsY0FBVSxZQUFZLE1BQU0scUJBQXFCO0FBQUEsRUFDbkQsU0FBUyxLQUFLO0FBQ1osY0FBVSxZQUFZLE9BQU8sbUJBQW9CLElBQWMsT0FBTyxFQUFFO0FBQUEsRUFDMUUsVUFBRTtBQUNBLGVBQVcsV0FBVztBQUFBLEVBQ3hCO0FBQ0YsQ0FBQztBQUVELGVBQWUsY0FBNkI7QUFDMUMsUUFBTSxDQUFDLFVBQVUsTUFBTSxVQUFVLFVBQVUsU0FBUyxVQUFVLGVBQWUsSUFBSSxNQUFNLFFBQVEsSUFBSTtBQUFBLElBQ2pHLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxJQUNaLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxJQUNaLG1CQUFtQjtBQUFBLEVBQ3JCLENBQUM7QUFDRCxRQUFNLGtCQUFrQixPQUFPO0FBQUEsSUFDN0IsT0FBTyxRQUFRLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUFBLE1BQ3RDO0FBQUEsTUFDQTtBQUFBLFFBQ0UsUUFBUSxFQUFFO0FBQUEsUUFDVixZQUFZLEVBQUU7QUFBQSxRQUNkLGlCQUFpQixFQUFFO0FBQUEsUUFDbkIsY0FBYyxPQUFPLEtBQUssRUFBRSxZQUFZLEVBQUU7QUFBQSxRQUMxQyxnQkFBZ0IsRUFBRSxtQkFBbUI7QUFBQSxRQUNyQyxnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLFlBQVksRUFBRTtBQUFBLE1BQ2hCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sT0FBTztBQUFBLElBQ1gsU0FBUyxRQUFRLFFBQVEsWUFBWSxFQUFFO0FBQUEsSUFDdkMsWUFBWSxVQUFVO0FBQUEsSUFDdEIsVUFBVTtBQUFBLE1BQ1IsT0FBTyxTQUFTO0FBQUEsTUFDaEIsTUFBTSxTQUFTO0FBQUEsTUFDZixRQUFRLFNBQVM7QUFBQSxNQUNqQixhQUFhLFNBQVM7QUFBQSxNQUN0QixnQkFBZ0IsU0FBUztBQUFBLE1BQ3pCLGNBQWMsU0FBUztBQUFBLE1BQ3ZCLFFBQVEsU0FBUyxJQUFJLFNBQVM7QUFBQSxNQUM5QixXQUFXLFNBQVMsSUFBSSxVQUFVLElBQUksU0FBUyxJQUFJLE1BQU0sRUFBRSxJQUFJO0FBQUEsSUFDakU7QUFBQSxJQUNBLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsaUJBQWlCLGtCQUNiO0FBQUEsTUFDRSxjQUFjLGdCQUFnQjtBQUFBLE1BQzlCLFlBQVksZ0JBQWdCO0FBQUEsTUFDNUIsVUFBVSxPQUFPLEtBQUssZ0JBQWdCLFFBQVEsRUFBRTtBQUFBLElBQ2xELElBQ0E7QUFBQSxJQUNKLFlBQVk7QUFBQSxJQUNaLG9CQUFvQixTQUFTO0FBQUEsSUFDN0IsaUJBQWlCLFNBQVMsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUN2QztBQUNBLFVBQVEsUUFBUSxLQUFLLFVBQVUsTUFBTSxNQUFNLENBQUM7QUFDOUM7QUFFQSxZQUFZLGlCQUFpQixTQUFTLFlBQVk7QUFDaEQsUUFBTSxVQUFVLFVBQVUsVUFBVSxRQUFRLEtBQUs7QUFDakQsWUFBVSxZQUFZLE1BQU0sa0NBQWtDO0FBQ2hFLENBQUM7QUFFRCxnQkFBZ0IsaUJBQWlCLFNBQVMsWUFBWTtBQUNwRCxRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsUUFBTSxTQUFTO0FBQ2YsWUFBVSxZQUFZLFFBQVEsa0JBQWtCO0FBQ2hELFFBQU0sYUFBYTtBQUNuQixRQUFNLGNBQWM7QUFDcEIsUUFBTSxZQUFZO0FBQ3BCLENBQUM7QUFFRCxLQUFLLGFBQWE7QUFDbEIsS0FBSyxjQUFjO0FBQ25CLEtBQUssWUFBWTsiLAogICJuYW1lcyI6IFtdCn0K
