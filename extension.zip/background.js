// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  branch: "main",
  autoCapture: true,
  configuredAt: null
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement" },
  { handle: "CBP", label: "U.S. Customs and Border Protection" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services" },
  { handle: "WhiteHouse", label: "The White House" },
  { handle: "PressSec", label: "White House Press Secretary" },
  { handle: "POTUS", label: "President of the United States" },
  { handle: "USDOL", label: "U.S. Department of Labor" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: []
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  return getRaw("settings");
}
async function setSettings(s) {
  await setRaw("settings", s);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getConnection() {
  return getRaw("connection");
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category
    });
  }
};
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase64(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const observed = [];
  for (const raw of rawTweets) {
    try {
      const t = buildTweet(raw, ctx);
      if (!t) continue;
      observed.push(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  return { tweets, observed_ids: observed };
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy);
  if (!restId || !legacy) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userLegacy = obj(userResult?.legacy);
  const handle = strOrNull(userLegacy?.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    hashtags,
    mentions,
    urls,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      if (current.handle && current.label) accounts.push(current);
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      if (current.handle && current.label) accounts.push(current);
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
  }
  if (current.handle && current.label) accounts.push(current);
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await flushOrphanedBuffersIfStale();
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
async function handleMessage(msg) {
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const settings = await getSettings();
  const accounts = await getAccounts();
  if (!settings.pat) {
    await warn("capture ignored: PAT not configured", { endpoint });
    return;
  }
  const allowed = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: allowed
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  if (normalized.tweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of normalized.tweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, Object.keys(buf.tweets_by_id).length);
    if (added > 0) {
      await info("captured tweets", {
        handle,
        endpoint,
        added,
        total: Object.keys(buf.tweets_by_id).length
      });
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      await flushHandle(handle, "idle");
    }
  }
}
async function flushOrphanedBuffersIfStale() {
  const all = await getRunBuffers();
  const now = Date.now();
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      await flushHandle(handle, "wake");
    }
  }
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  for (const handle of Object.keys(all)) {
    await flushHandle(handle, reason);
  }
}
async function flushHandle(handle, reason) {
  const buf = await getRunBuffer(handle);
  if (!buf) return;
  const tweets = Object.values(buf.tweets_by_id);
  if (tweets.length === 0) {
    await clearRunBuffer(handle);
    return;
  }
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", { handle });
    return;
  }
  const client = new GitHubClient(settings);
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const rawPath = `raw/${handle}/${ts}-${shortRunId(buf.run_id)}.json`;
  const seenPath = `seen/${handle}/${ts}-${shortRunId(buf.run_id)}.json`;
  const capture = {
    schema_version: 1,
    capture_run_id: buf.run_id,
    account_handle: handle,
    captured_at: buf.last_capture_at,
    endpoint: buf.endpoints_seen.join(","),
    user_agent: navigator.userAgent,
    source_url: buf.source_url,
    tweets
  };
  const seen = {
    schema_version: 1,
    capture_run_id: buf.run_id,
    account_handle: handle,
    captured_at: buf.last_capture_at,
    tweet_ids_observed: buf.tweet_ids_observed
  };
  const commitMsg = `capture: ${handle} ${day} ${tweets.length} tweet${tweets.length === 1 ? "" : "s"} (run ${shortRunId(buf.run_id)})`;
  try {
    await client.putFile({
      path: rawPath,
      contentBase64: toBase64(JSON.stringify(capture, null, 2) + "\n"),
      message: commitMsg
    });
    await client.putFile({
      path: seenPath,
      contentBase64: toBase64(JSON.stringify(seen, null, 2) + "\n"),
      message: `seen: ${handle} ${day} ${seen.tweet_ids_observed.length} ids (run ${shortRunId(buf.run_id)})`
    });
    await clearRunBuffer(handle);
    await bumpCounter(handle, {
      todayCount: (await getCounters())[handle]?.todayCount ?? 0,
      todayDate: day,
      lastCaptureAt: buf.last_capture_at,
      totalCommitted: ((await getCounters())[handle]?.totalCommitted ?? 0) + tweets.length,
      bufferedCount: 0
    });
    await info("flush committed", {
      handle,
      reason,
      tweets: tweets.length,
      run: shortRunId(buf.run_id),
      path: rawPath
    });
    await setConnection({
      status: "ok",
      login: (await getConnection()).login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null
    });
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message
      });
      await error("flush failed", {
        handle,
        reason,
        category: err.category,
        status: err.status,
        message: err.message
      });
    } else {
      await error("flush failed", { handle, reason, ...describeError(err) });
    }
  } finally {
    await broadcastState();
  }
}
async function captureNow(handle) {
  await info("capture-now requested", { handle });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: `https://x.com/${handle}`
    });
  }
  await browser.tabs.create({ url: `https://x.com/${handle}`, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase64(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force && conn.status === "ok" && conn.checkedAt) {
    const age = Date.now() - Date.parse(conn.checkedAt);
    if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null
    });
    await info("connection verified", { login: r.login, repo: r.full_name });
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message
    });
    await warn("connection check failed", { category: cat, ...describeError(err) });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      return;
    }
    await setAccounts(parsed);
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHBhdDogJycsXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXG4gIHJlcG86ICd4JyxcbiAgYnJhbmNoOiAnbWFpbicsXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxuICBjb25maWd1cmVkQXQ6IG51bGwsXG59O1xuXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JyB9LFxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcgfSxcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nIH0sXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJyB9LFxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScgfSxcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JyB9LFxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnIH0sXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicgfSxcbl07XG5cbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXG5leHBvcnQgY29uc3QgVFdFRVRfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbiAgJ0xpa2VzJyxcbiAgJ0Jvb2ttYXJrcycsXG4gICdIb21lVGltZWxpbmUnLFxuICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcbiAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXG5dKTtcblxuLy8gQXV4aWxpYXJ5IGVuZHBvaW50cyB3ZSBkb24ndCBleHRyYWN0IHR3ZWV0cyBmcm9tIGJ1dCB1c2UgZm9yIGNvbnRleHQgKGUuZy4sXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxuZXhwb3J0IGNvbnN0IFBST0ZJTEVfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJCeVNjcmVlbk5hbWUnLCAnVXNlckJ5UmVzdElkJ10pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUywgRkFMTEJBQ0tfQUNDT1VOVFMsIEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9jb25maWcuanMnO1xuaW1wb3J0IHR5cGUge1xuICBBY2NvdW50Q29uZmlnLFxuICBBY2NvdW50Q291bnRlcixcbiAgQ2Fub25pY2FsVHdlZXQsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFNldHRpbmdzLFxufSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBCdWZmZXJlZCB0d2VldHMgZm9yIGEgZ2l2ZW4gYWNjb3VudCwgYXdhaXRpbmcgY29tbWl0LiBBIFwicnVuXCIgaXMgb25lIGVudHJ5XG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xuICBydW5faWQ6IHN0cmluZztcbiAgYWNjb3VudF9oYW5kbGU6IHN0cmluZztcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcbiAgdHdlZXRzX2J5X2lkOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD47XG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XG4gIGVuZHBvaW50c19zZWVuOiBzdHJpbmdbXTtcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcbn1cblxuaW50ZXJmYWNlIFN0b3JhZ2VTaGFwZSB7XG4gIHNldHRpbmdzOiBTZXR0aW5ncztcbiAgYWNjb3VudHM6IEFjY291bnRDb25maWdbXTtcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvblN0YXRlO1xuICBjb3VudGVyczogUmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+O1xuICBydW5CdWZmZXJzOiBSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+O1xuICBhY3Rpdml0eTogTG9nRXZlbnRbXTtcbn1cblxuY29uc3QgREVGQVVMVF9DT05ORUNUSU9OOiBDb25uZWN0aW9uU3RhdGUgPSB7XG4gIHN0YXR1czogJ3Vua25vd24nLFxuICBsb2dpbjogbnVsbCxcbiAgY2hlY2tlZEF0OiBudWxsLFxuICBlcnJvcjogbnVsbCxcbn07XG5cbmNvbnN0IERFRkFVTFRTOiBTdG9yYWdlU2hhcGUgPSB7XG4gIHNldHRpbmdzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MgfSxcbiAgYWNjb3VudHM6IFsuLi5GQUxMQkFDS19BQ0NPVU5UU10sXG4gIGNvbm5lY3Rpb246IHsgLi4uREVGQVVMVF9DT05ORUNUSU9OIH0sXG4gIGNvdW50ZXJzOiB7fSxcbiAgcnVuQnVmZmVyczoge30sXG4gIGFjdGl2aXR5OiBbXSxcbn07XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEspOiBQcm9taXNlPFN0b3JhZ2VTaGFwZVtLXT4ge1xuICBjb25zdCByZXN1bHQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KGtleSk7XG4gIGNvbnN0IHZhbHVlID0gcmVzdWx0W2tleV07XG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIHN0cnVjdHVyZWRDbG9uZShERUZBVUxUU1trZXldKTtcbiAgfVxuICByZXR1cm4gdmFsdWUgYXMgU3RvcmFnZVNoYXBlW0tdO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLLCB2YWx1ZTogU3RvcmFnZVNoYXBlW0tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBba2V5XTogdmFsdWUgfSk7XG59XG5cbi8vIC0tLSBTZXR0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gIHJldHVybiBnZXRSYXcoJ3NldHRpbmdzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdzZXR0aW5ncycsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHBhdGNoOiBQYXJ0aWFsPFNldHRpbmdzPik6IFByb21pc2U8U2V0dGluZ3M+IHtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgbmV4dCA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xuICBhd2FpdCBzZXRTZXR0aW5ncyhuZXh0KTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbi8vIC0tLSBBY2NvdW50cyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50cygpOiBQcm9taXNlPEFjY291bnRDb25maWdbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50cycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzKGE6IEFjY291bnRDb25maWdbXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzJywgYSk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHN0YXRlIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb24oKTogUHJvbWlzZTxDb25uZWN0aW9uU3RhdGU+IHtcbiAgcmV0dXJuIGdldFJhdygnY29ubmVjdGlvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xufVxuXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ2NvdW50ZXJzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xuICAgIHRvZGF5Q291bnQ6IDAsXG4gICAgdG9kYXlEYXRlOiB0b2RheUlTTygpLFxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXG4gICAgYnVmZmVyZWRDb3VudDogMCxcbiAgfTtcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcbiAgICBjdXIudG9kYXlEYXRlID0gdG9kYXlJU08oKTtcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XG4gIH1cbiAgY29uc3QgbmV4dDogQWNjb3VudENvdW50ZXIgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRCdWZmZXJlZENvdW50KGhhbmRsZTogc3RyaW5nLCBjb3VudDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcbn1cblxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj4+IHtcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgcmV0dXJuIGFsbFtoYW5kbGVdID8/IG51bGw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcsIGJ1ZjogUnVuQnVmZmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYWxsW2hhbmRsZV0gPSBidWY7XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcbn1cblxuLy8gLS0tIEFjdGl2aXR5IHRhaWwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY3Rpdml0eScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwZW5kQWN0aXZpdHkoZXY6IExvZ0V2ZW50KTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XG4gIGN1ci51bnNoaWZ0KGV2KTtcbiAgaWYgKGN1ci5sZW5ndGggPiBBQ1RJVklUWV9UQUlMX01BWCkgY3VyLmxlbmd0aCA9IEFDVElWSVRZX1RBSUxfTUFYO1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcbiAgcmV0dXJuIGN1cjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBbXSk7XG59XG5cbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbn1cbiIsICJpbXBvcnQgeyBhcHBlbmRBY3Rpdml0eSB9IGZyb20gJy4vc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5sZXQgYnJvYWRjYXN0OiAoKGV2OiBMb2dFdmVudCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldEJyb2FkY2FzdGVyKGZuOiAoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKTogdm9pZCB7XG4gIGJyb2FkY2FzdCA9IGZuO1xufVxuXG5mdW5jdGlvbiBub3dJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBldjogTG9nRXZlbnQgPSB7IHRzOiBub3dJU08oKSwgbGV2ZWwsIG1zZywgY29udGV4dDogcmVkYWN0KGNvbnRleHQpIH07XG4gIC8vIENvbnNvbGUgZm9yIGRldnRvb2xzLlxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xuICBpZiAobGV2ZWwgPT09ICdlcnJvcicpIGNvbnNvbGUuZXJyb3IobGluZSwgZXYuY29udGV4dCk7XG4gIGVsc2UgaWYgKGxldmVsID09PSAnd2FybicpIGNvbnNvbGUud2FybihsaW5lLCBldi5jb250ZXh0KTtcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcbiAgLy8gUGVyc2lzdGVudCB0YWlsLlxuICB0cnkge1xuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGZhaWxlZCB0byBhcHBlbmQgYWN0aXZpdHknLCBlcnIpO1xuICB9XG4gIC8vIExpdmUgYnJvYWRjYXN0IChlLmcuIHRvIHNpZGViYXIpLlxuICB0cnkge1xuICAgIGJyb2FkY2FzdD8uKGV2KTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gU2lkZWJhciBtYXkgbm90IGJlIG9wZW47IHRoYXQncyBmaW5lLlxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCdpbmZvJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCd3YXJuJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gZW1pdCgnZXJyb3InLCBtc2csIGNvbnRleHQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmVFcnJvcihlcnI6IHVua25vd24pOiB7IG1lc3NhZ2U6IHN0cmluZzsgc3RhY2s6IHN0cmluZyB8IG51bGwgfSB7XG4gIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcbiAgfVxuICB0cnkge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4geyBtZXNzYWdlOiAnPHVucHJpbnRhYmxlIGVycm9yPicsIHN0YWNrOiBudWxsIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTdHJpcCBhbnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSBQQVQgb3Igb3RoZXIgbG9uZyBzZWNyZXQgZnJvbSBhIGNvbnRleHRcbiAqIG9iamVjdCBiZWZvcmUgcGVyc2lzdGluZyBpdC4gRGVmZW5zaXZlOiBjYWxsZXJzIHNob3VsZCBub3QgbG9nIHRva2VucywgYnV0XG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxuICovXG5mdW5jdGlvbiByZWRhY3QoY3R4OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhjdHgpKSB7XG4gICAgaWYgKGsudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygndG9rZW4nKSB8fCBrLnRvTG93ZXJDYXNlKCkgPT09ICdwYXQnIHx8IGsgPT09ICdhdXRob3JpemF0aW9uJykge1xuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIC9naXRodWJfcGF0X1tBLVphLXowLTlfXXszMCx9Ly50ZXN0KHYpKSB7XG4gICAgICBvdXRba10gPSB2LnJlcGxhY2UoL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dKy9nLCAnZ2l0aHViX3BhdF88cmVkYWN0ZWQ+Jyk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XG4gICAgICBvdXRba10gPSBgJHt2LnNsaWNlKDAsIDQwOTYpfVx1MjAyNjx0cnVuY2F0ZWQ+YDtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0W2tdID0gdjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cbiIsICJpbXBvcnQgeyBkZXNjcmliZUVycm9yIH0gZnJvbSAnLi9sb2dnZXIuanMnO1xuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5jb25zdCBBUElfQkFTRSA9ICdodHRwczovL2FwaS5naXRodWIuY29tJztcbmNvbnN0IFJBV19CQVNFID0gJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZU9wdGlvbnMge1xuICBwYXRoOiBzdHJpbmc7XG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBleHBlY3RlZFNoYT86IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZVJlc3VsdCB7XG4gIHBhdGg6IHN0cmluZztcbiAgc2hhOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xufVxuXG5leHBvcnQgY2xhc3MgR2l0SHViRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIHN0YXR1czogbnVtYmVyO1xuICBib2R5OiB1bmtub3duO1xuICByZXRyaWFibGU6IGJvb2xlYW47XG4gIGNhdGVnb3J5OiAnYXV0aCcgfCAncmF0ZS1saW1pdCcgfCAnY29uZmxpY3QnIHwgJ25vdC1mb3VuZCcgfCAnc2VydmVyJyB8ICduZXR3b3JrJyB8ICd1bmtub3duJztcblxuICBjb25zdHJ1Y3RvcihvcHRzOiB7XG4gICAgc3RhdHVzOiBudW1iZXI7XG4gICAgYm9keTogdW5rbm93bjtcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgcmV0cmlhYmxlOiBib29sZWFuO1xuICAgIGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXTtcbiAgfSkge1xuICAgIHN1cGVyKG9wdHMubWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0dpdEh1YkVycm9yJztcbiAgICB0aGlzLnN0YXR1cyA9IG9wdHMuc3RhdHVzO1xuICAgIHRoaXMuYm9keSA9IG9wdHMuYm9keTtcbiAgICB0aGlzLnJldHJpYWJsZSA9IG9wdHMucmV0cmlhYmxlO1xuICAgIHRoaXMuY2F0ZWdvcnkgPSBvcHRzLmNhdGVnb3J5O1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBHaXRIdWJDbGllbnQge1xuICBwcml2YXRlIHJlYWRvbmx5IHNldHRpbmdzOiBTZXR0aW5ncztcblxuICBjb25zdHJ1Y3RvcihzZXR0aW5nczogU2V0dGluZ3MpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gIH1cblxuICAvKiogUmV0dXJucyB0aGUgYXV0aGVudGljYXRlZCB1c2VyJ3MgbG9naW4uIFRocm93cyBvbiBhdXRoIGZhaWx1cmUuICovXG4gIGFzeW5jIHdob2FtaSgpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICByZXR1cm4gKHJlcyBhcyB7IGxvZ2luPzogc3RyaW5nIH0pLmxvZ2luID8/ICc8dW5rbm93bj4nO1xuICB9XG5cbiAgLyoqIFZlcmlmaWVzIHRoZSBQQVQgY2FuIHNlZSB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xuICBhc3luYyB2ZXJpZnlSZXBvQWNjZXNzKCk6IFByb21pc2U8eyBsb2dpbjogc3RyaW5nOyBmdWxsX25hbWU6IHN0cmluZzsgZGVmYXVsdF9icmFuY2g6IHN0cmluZyB9PiB7XG4gICAgY29uc3QgbWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgJy91c2VyJyk7XG4gICAgY29uc3QgcmVwbyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99YCk7XG4gICAgY29uc3QgciA9IHJlcG8gYXMgeyBmdWxsX25hbWU6IHN0cmluZzsgZGVmYXVsdF9icmFuY2g6IHN0cmluZyB9O1xuICAgIHJldHVybiB7XG4gICAgICBsb2dpbjogKG1lIGFzIHsgbG9naW46IHN0cmluZyB9KS5sb2dpbixcbiAgICAgIGZ1bGxfbmFtZTogci5mdWxsX25hbWUsXG4gICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIEZldGNoIGEgdGV4dCBmaWxlIGZyb20gcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSBhdXRoZW50aWNhdGVkIHdpdGggdGhlXG4gICAqIFBBVC4gUmV0dXJucyBudWxsIGlmIHRoZSBmaWxlIGRvZXNuJ3QgZXhpc3QuIFVzZWQgZm9yIGNvbmZpZy9hY2NvdW50cy55YW1sLlxuICAgKi9cbiAgYXN5bmMgZmV0Y2hSYXdUZXh0KHBhdGhJblJlcG86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IHVybCA9IGAke1JBV19CQVNFfS8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS8ke3RoaXMuc2V0dGluZ3MuYnJhbmNofS8ke3BhdGhJblJlcG99YDtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLnNldHRpbmdzLnBhdH1gIH0sXG4gICAgfSk7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkgcmV0dXJuIG51bGw7XG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yKHJlcywgYEdFVCByYXcgJHtwYXRoSW5SZXBvfWApO1xuICAgIHJldHVybiByZXMudGV4dCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvb2sgdXAgYW4gZXhpc3RpbmcgZmlsZSdzIFNIQSB2aWEgdGhlIENvbnRlbnRzIEFQSSwgb3IgbnVsbCBpZiBub3QgZm91bmQuXG4gICAqIFVzZWQgd2hlbiByZXRyeWluZyBhIFBVVCBhZnRlciBhIDQyMiBzaGEgbWlzbWF0Y2guXG4gICAqL1xuICBhc3luYyBnZXRGaWxlU2hhKHBhdGg6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vY29udGVudHMvJHtlbmNvZGVQYXRoKHBhdGgpfT9yZWY9JHtlbmNvZGVVUklDb21wb25lbnQodGhpcy5zZXR0aW5ncy5icmFuY2gpfWBcbiAgICAgICk7XG4gICAgICBjb25zdCByID0gcmVzIGFzIHsgc2hhPzogc3RyaW5nIH07XG4gICAgICByZXR1cm4gci5zaGEgPz8gbnVsbDtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gbnVsbDtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUFVUIGEgZmlsZSB0byB0aGUgcmVwby4gSGFuZGxlcyA0MjIgKHNoYSByZXF1aXJlZCkgYnkgcmUtZmV0Y2hpbmcgdGhlXG4gICAqIGV4aXN0aW5nIHNoYSBhbmQgcmV0cnlpbmcgb25jZS4gUmV0cmllcyBuZXR3b3JrIC8gNXh4IC8gcmF0ZS1saW1pdCBlcnJvcnNcbiAgICogd2l0aCBleHBvbmVudGlhbCBiYWNrb2ZmIHVwIHRvIG1heEF0dGVtcHRzLlxuICAgKi9cbiAgYXN5bmMgcHV0RmlsZShvcHRzOiBQdXRGaWxlT3B0aW9ucyk6IFByb21pc2U8UHV0RmlsZVJlc3VsdD4ge1xuICAgIGNvbnN0IHBhdGggPSBvcHRzLnBhdGg7XG4gICAgY29uc3QgdXJsID0gYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9YDtcbiAgICBsZXQgc2hhOiBzdHJpbmcgfCBudWxsID0gb3B0cy5leHBlY3RlZFNoYSA/PyBudWxsO1xuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcbiAgICAgIGNvbnN0IGJvZHk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXG4gICAgICAgIGNvbnRlbnQ6IG9wdHMuY29udGVudEJhc2U2NCxcbiAgICAgICAgYnJhbmNoOiB0aGlzLnNldHRpbmdzLmJyYW5jaCxcbiAgICAgIH07XG4gICAgICBpZiAoc2hhKSBib2R5LnNoYSA9IHNoYTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdQVVQnLCB1cmwsIGJvZHkpO1xuICAgICAgICBjb25zdCBvdXQgPSByZXMgYXMgeyBjb250ZW50OiB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nOyBwYXRoOiBzdHJpbmcgfSB9O1xuICAgICAgICByZXR1cm4geyBwYXRoOiBvdXQuY29udGVudC5wYXRoLCBzaGE6IG91dC5jb250ZW50LnNoYSwgdXJsOiBvdXQuY29udGVudC5odG1sX3VybCB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xuICAgICAgICBpZiAoZXJyLnN0YXR1cyA9PT0gNDIyICYmICFzaGEpIHtcbiAgICAgICAgICAvLyBGaWxlIGFscmVhZHkgZXhpc3RzOyBmZXRjaCBpdHMgc2hhIGFuZCByZXRyeSBvbmNlLlxuICAgICAgICAgIHNoYSA9IGF3YWl0IHRoaXMuZ2V0RmlsZVNoYShwYXRoKTtcbiAgICAgICAgICBpZiAoIXNoYSkgdGhyb3cgZXJyO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZXJyLnJldHJpYWJsZSB8fCBhdHRlbXB0ID09PSBtYXhBdHRlbXB0cykgdGhyb3cgZXJyO1xuICAgICAgICBhd2FpdCBzbGVlcChiYWNrb2ZmTXMoYXR0ZW1wdCwgZXJyKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihgcHV0RmlsZTogZXhoYXVzdGVkIGF0dGVtcHRzIGZvciAke3BhdGh9YCk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZldGNoSnNvbihtZXRob2Q6IHN0cmluZywgcGF0aDogc3RyaW5nLCBib2R5PzogdW5rbm93bik6IFByb21pc2U8dW5rbm93bj4ge1xuICAgIGNvbnN0IHVybCA9IHBhdGguc3RhcnRzV2l0aCgnaHR0cCcpID8gcGF0aCA6IGAke0FQSV9CQVNFfSR7cGF0aH1gO1xuICAgIGNvbnN0IGluaXQ6IFJlcXVlc3RJbml0ID0ge1xuICAgICAgbWV0aG9kLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dGhpcy5zZXR0aW5ncy5wYXR9YCxcbiAgICAgICAgQWNjZXB0OiAnYXBwbGljYXRpb24vdm5kLmdpdGh1Yitqc29uJyxcbiAgICAgICAgJ1gtR2l0SHViLUFwaS1WZXJzaW9uJzogJzIwMjItMTEtMjgnLFxuICAgICAgICAuLi4oYm9keSA/IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IDoge30pLFxuICAgICAgfSxcbiAgICAgIC4uLihib2R5ID8geyBib2R5OiBKU09OLnN0cmluZ2lmeShib2R5KSB9IDoge30pLFxuICAgIH07XG4gICAgbGV0IHJlczogUmVzcG9uc2U7XG4gICAgdHJ5IHtcbiAgICAgIHJlcyA9IGF3YWl0IGZldGNoKHVybCwgaW5pdCk7XG4gICAgfSBjYXRjaCAobmV0RXJyKSB7XG4gICAgICB0aHJvdyBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgICBzdGF0dXM6IDAsXG4gICAgICAgIGJvZHk6IG51bGwsXG4gICAgICAgIG1lc3NhZ2U6IGBuZXR3b3JrOiAke2Rlc2NyaWJlRXJyb3IobmV0RXJyKS5tZXNzYWdlfWAsXG4gICAgICAgIHJldHJpYWJsZTogdHJ1ZSxcbiAgICAgICAgY2F0ZWdvcnk6ICduZXR3b3JrJyxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gMjA0KSByZXR1cm4gbnVsbDtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICBpZiAodGV4dCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBwYXJzZWQgPSB0ZXh0O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBgJHttZXRob2R9ICR7cGF0aH1gKTtcbiAgICByZXR1cm4gcGFyc2VkO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBtYWtlRXJyb3IocmVzOiBSZXNwb25zZSwgbGFiZWw6IHN0cmluZyk6IFByb21pc2U8R2l0SHViRXJyb3I+IHtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICBpZiAodGV4dCkgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBsYWJlbCk7XG4gIH1cblxuICBwcml2YXRlIG1ha2VFcnJvckZyb21QYXJzZWQocmVzOiBSZXNwb25zZSwgYm9keTogdW5rbm93biwgbGFiZWw6IHN0cmluZyk6IEdpdEh1YkVycm9yIHtcbiAgICBjb25zdCBtc2cgPVxuICAgICAgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmIGJvZHkgJiYgJ21lc3NhZ2UnIGluIGJvZHlcbiAgICAgICAgPyBTdHJpbmcoKGJvZHkgYXMgeyBtZXNzYWdlOiB1bmtub3duIH0pLm1lc3NhZ2UpXG4gICAgICAgIDogcmVzLnN0YXR1c1RleHQ7XG4gICAgbGV0IGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXSA9ICd1bmtub3duJztcbiAgICBsZXQgcmV0cmlhYmxlID0gZmFsc2U7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSB8fCByZXMuc3RhdHVzID09PSA0MDMpIHtcbiAgICAgIC8vIDQwMyBjYW4gYmUgZWl0aGVyIGF1dGggb3IgcmF0ZSBsaW1pdDsgY2hlY2sgaGVhZGVycy5cbiAgICAgIGNvbnN0IHJhdGUgPSByZXMuaGVhZGVycy5nZXQoJ3gtcmF0ZWxpbWl0LXJlbWFpbmluZycpO1xuICAgICAgaWYgKHJhdGUgPT09ICcwJyB8fCAvcmF0ZSBsaW1pdC9pLnRlc3QobXNnKSkge1xuICAgICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNhdGVnb3J5ID0gJ2F1dGgnO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSB7XG4gICAgICBjYXRlZ29yeSA9ICdub3QtZm91bmQnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA5IHx8IHJlcy5zdGF0dXMgPT09IDQyMikge1xuICAgICAgY2F0ZWdvcnkgPSAnY29uZmxpY3QnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA+PSA1MDApIHtcbiAgICAgIGNhdGVnb3J5ID0gJ3NlcnZlcic7XG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDI5KSB7XG4gICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgc3RhdHVzOiByZXMuc3RhdHVzLFxuICAgICAgYm9keSxcbiAgICAgIG1lc3NhZ2U6IGAke2xhYmVsfSBcdTIxOTIgJHtyZXMuc3RhdHVzfTogJHttc2d9YCxcbiAgICAgIHJldHJpYWJsZSxcbiAgICAgIGNhdGVnb3J5LFxuICAgIH0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVuY29kZVBhdGgocGF0aDogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gRW5jb2RlIHNlZ21lbnRzIGluZGl2aWR1YWxseSBzbyBzbGFzaGVzIHJlbWFpbi5cbiAgcmV0dXJuIHBhdGguc3BsaXQoJy8nKS5tYXAoZW5jb2RlVVJJQ29tcG9uZW50KS5qb2luKCcvJyk7XG59XG5cbmZ1bmN0aW9uIGJhY2tvZmZNcyhhdHRlbXB0OiBudW1iZXIsIGVycjogR2l0SHViRXJyb3IpOiBudW1iZXIge1xuICAvLyBFeHBvbmVudGlhbCB3aXRoIGppdHRlcjsgYnVtcCBoaWdoZXIgZm9yIHJhdGUtbGltaXQgcmVzcG9uc2VzLlxuICBjb25zdCBiYXNlID0gZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyA1MDAwIDogNTAwO1xuICBjb25zdCBqaXR0ZXIgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0MDApO1xuICByZXR1cm4gTWF0aC5taW4oNjBfMDAwLCBiYXNlICogMiAqKiAoYXR0ZW1wdCAtIDEpICsgaml0dGVyKTtcbn1cblxuZnVuY3Rpb24gc2xlZXAobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBieXRlcyBpcyBhIFVURi04IHN0cmluZyBvZiBKU09OOyBlbmNvZGUgdG8gYmFzZTY0IHRoZSBzYWZlIHdheS5cbiAgY29uc3QgdXRmOCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShieXRlcyk7XG4gIGxldCBiaW4gPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIHV0ZjgpIGJpbiArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShiaW4pO1xufVxuIiwgImltcG9ydCB7IFRXRUVUX1VSTF9QUkVGSVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7IENhbm9uaWNhbFR3ZWV0LCBNZWRpYUl0ZW0sIFR3ZWV0VHlwZSwgVXJsRW50aXR5IH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTm9ybWFsaXplIEdyYXBoUUwgcmVzcG9uc2UgcGF5bG9hZHMgZnJvbSBYJ3MgaW50ZXJuYWwgQVBJIGludG9cbiAqIGBDYW5vbmljYWxUd2VldGBzLiBNYW55IGVuZHBvaW50cyBzaGFyZSBhIHNpbWlsYXIgdHdlZXQgc2hhcGUgYnV0IHdyYXAgaXQgaW5cbiAqIGRpZmZlcmVudCBlbnZlbG9wZXM7IHRoaXMgbW9kdWxlIHdhbGtzIHRoZSBzdHJ1Y3R1cmUgZGVmZW5zaXZlbHkuXG4gKlxuICogVGhlIHBhcnNlciBpcyBpbnRlbnRpb25hbGx5IHBlcm1pc3NpdmU6IGl0IHdpbGwgc2lsZW50bHkgc2tpcCBlbnRyaWVzIGl0XG4gKiBjYW4ndCByZWNvZ25pemUgYXMgdHdlZXRzIChjdXJzb3JzLCBhZHMsIGdhcCBlbnRyaWVzLCBtb2R1bGVzIG9mIG90aGVyXG4gKiB0d2VldHMsIHRvbWJzdG9uZXMpLiBJdCB0aHJvd3MgKm9ubHkqIHdoZW4gZ2l2ZW4gYSBwYXlsb2FkIGl0IGRvZXNuJ3Qga25vd1xuICogaG93IHRvIHdhbGsgYXQgYWxsIFx1MjAxNCB0aG9zZSBjYXNlcyBhcmUgY2F1Z2h0IGFuZCBxdWFyYW50aW5lZCB1cHN0cmVhbS5cbiAqL1xuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZUNvbnRleHQge1xuICBjYXB0dXJlZEF0OiBzdHJpbmc7XG4gIHJ1bklkOiBzdHJpbmc7XG4gIGVuZHBvaW50OiBzdHJpbmc7XG4gIGFsbG93ZWRIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZVJlc3VsdCB7XG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcbiAgb2JzZXJ2ZWRfaWRzOiBzdHJpbmdbXTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShwYXlsb2FkOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBOb3JtYWxpemVSZXN1bHQge1xuICBjb25zdCByYXdUd2VldHMgPSBjb2xsZWN0VHdlZXRzKHBheWxvYWQpO1xuICBjb25zdCB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10gPSBbXTtcbiAgY29uc3Qgb2JzZXJ2ZWQ6IHN0cmluZ1tdID0gW107XG4gIGZvciAoY29uc3QgcmF3IG9mIHJhd1R3ZWV0cykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0ID0gYnVpbGRUd2VldChyYXcsIGN0eCk7XG4gICAgICBpZiAoIXQpIGNvbnRpbnVlO1xuICAgICAgb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIGlmIChjdHguYWxsb3dlZEhhbmRsZXMuc2l6ZSA9PT0gMCB8fCBjdHguYWxsb3dlZEhhbmRsZXMuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgdHdlZXRzLnB1c2godCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBPbmUgYmFkIGVudHJ5IHNob3VsZG4ndCB0YWtlIGRvd24gdGhlIHdob2xlIGJhdGNoLlxuICAgIH1cbiAgfVxuICByZXR1cm4geyB0d2VldHMsIG9ic2VydmVkX2lkczogb2JzZXJ2ZWQgfTtcbn1cblxuZnVuY3Rpb24gY29sbGVjdFR3ZWV0cyhvYmo6IHVua25vd24pOiB1bmtub3duW10ge1xuICAvLyBXYWxrIHRoZSByZXNwb25zZSB0cmVlIGdhdGhlcmluZyBldmVyeXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIHR3ZWV0XG4gIC8vIHJlc3VsdC4gV2UgbG9vayBmb3Igbm9kZXMgc2hhcGVkIGxpa2U6XG4gIC8vICAgeyBfX3R5cGVuYW1lPzogJ1R3ZWV0J3wnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnLCByZXN0X2lkLCBsZWdhY3kgfVxuICAvLyBhbmQgdW53cmFwIHZpc2liaWxpdHkgd3JhcHBlcnMuXG4gIGNvbnN0IG91dDogdW5rbm93bltdID0gW107XG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbb2JqXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBub2RlID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG5vZGUgPT09IG51bGwgfHwgbm9kZSA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcbiAgICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAoc2Vlbi5oYXMobm9kZSBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChub2RlIGFzIG9iamVjdCk7XG5cbiAgICBpZiAobG9va3NMaWtlVHdlZXQobm9kZSkpIHtcbiAgICAgIG91dC5wdXNoKHVud3JhcFR3ZWV0KG5vZGUpKTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobm9kZSkpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBub2RlKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gbG9va3NMaWtlVHdlZXQobm9kZTogdW5rbm93bik6IG5vZGUgaXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIGNvbnN0IHR5cGVuYW1lID0gbi5fX3R5cGVuYW1lO1xuICBpZiAoXG4gICAgdHlwZW5hbWUgPT09ICdUd2VldCcgfHxcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyB8fFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnXG4gICkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIC8vIFNvbWUgZW50cmllcyBsYWNrIF9fdHlwZW5hbWUgYnV0IHN0aWxsIGNhcnJ5IGxlZ2FjeSArIHJlc3RfaWQgKyBjb3JlLlxuICByZXR1cm4gdHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgdHlwZW9mIG4ubGVnYWN5ID09PSAnb2JqZWN0JyAmJiBuLmxlZ2FjeSAhPT0gbnVsbDtcbn1cblxuZnVuY3Rpb24gdW53cmFwVHdlZXQobm9kZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XG4gIGlmIChub2RlLl9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgJiYgdHlwZW9mIG5vZGUudHdlZXQgPT09ICdvYmplY3QnKSB7XG4gICAgcmV0dXJuIG5vZGUudHdlZXQgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIH1cbiAgcmV0dXJuIG5vZGU7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkVHdlZXQocmF3OiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBDYW5vbmljYWxUd2VldCB8IG51bGwge1xuICBpZiAodHlwZW9mIHJhdyAhPT0gJ29iamVjdCcgfHwgcmF3ID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgdCA9IHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcblxuICBpZiAodC5fX3R5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCByZXN0SWQgPSBzdHJPck51bGwodC5yZXN0X2lkKTtcbiAgY29uc3QgbGVnYWN5ID0gb2JqKHQubGVnYWN5KTtcbiAgaWYgKCFyZXN0SWQgfHwgIWxlZ2FjeSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgY29yZSA9IG9iaih0LmNvcmUpO1xuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihjb3JlPy51c2VyX3Jlc3VsdHMpPy5yZXN1bHQpO1xuICBjb25zdCB1c2VyTGVnYWN5ID0gb2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk7XG4gIGNvbnN0IGhhbmRsZSA9IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5zY3JlZW5fbmFtZSk7XG4gIGNvbnN0IGFjY291bnRJZCA9IHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5yZXN0X2lkKSA/PyBzdHJPck51bGwobGVnYWN5LnVzZXJfaWRfc3RyKTtcbiAgaWYgKCFoYW5kbGUgfHwgIWFjY291bnRJZCkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgbm90ZVR3ZWV0ID0gb2JqKG9iaihvYmoodC5ub3RlX3R3ZWV0KT8ubm90ZV90d2VldF9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgY29uc3QgdGV4dEZyb21Ob3RlID0gc3RyT3JOdWxsKG5vdGVUd2VldD8udGV4dCk7XG4gIGNvbnN0IHRleHRGcm9tTGVnYWN5ID0gc3RyT3JOdWxsKGxlZ2FjeS5mdWxsX3RleHQpID8/ICcnO1xuICBjb25zdCB0ZXh0ID0gdGV4dEZyb21Ob3RlID8/IHRleHRGcm9tTGVnYWN5O1xuXG4gIGNvbnN0IGVudGl0aWVzID0gb2JqKGxlZ2FjeS5lbnRpdGllcykgPz8ge307XG4gIGNvbnN0IGVudGl0aWVzRnJvbU5vdGUgPSBvYmoobm90ZVR3ZWV0Py5lbnRpdHlfc2V0KTtcbiAgY29uc3QgaGFzaHRhZ3MgPSBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IG1lbnRpb25zID0gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xuICBjb25zdCB1cmxzID0gZXh0cmFjdFVybHMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IG1lZGlhID0gZXh0cmFjdE1lZGlhKGxlZ2FjeSk7XG5cbiAgY29uc3QgdHdlZXRUeXBlID0gY2xhc3NpZnlUd2VldFR5cGUodCwgbGVnYWN5KTtcblxuICBjb25zdCBwb3N0ZWRBdCA9IHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKGxlZ2FjeS5jcmVhdGVkX2F0KSk7XG4gIGlmICghcG9zdGVkQXQpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHZpZXdzID0gb2JqKHQudmlld3MpO1xuICBjb25zdCB2aWV3Q291bnQgPSBudW1Pck51bGwodmlld3M/LmNvdW50KSA/PyBudW1Pck51bGwoc3RyT3JOdWxsKHZpZXdzPy5jb3VudCkpO1xuXG4gIGNvbnN0IHR3ZWV0OiBDYW5vbmljYWxUd2VldCA9IHtcbiAgICB0d2VldF9pZDogcmVzdElkLFxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgYWNjb3VudF9pZDogYWNjb3VudElkLFxuICAgIHBvc3RlZF9hdDogcG9zdGVkQXQsXG4gICAgZmlyc3RfY2FwdHVyZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxuICAgIGxhc3Rfc2Vlbl9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgZGVsZXRpb25fZGV0ZWN0ZWRfYXQ6IG51bGwsXG4gICAgdHdlZXRfdXJsOiBgJHtUV0VFVF9VUkxfUFJFRklYfS8ke2hhbmRsZX0vc3RhdHVzLyR7cmVzdElkfWAsXG4gICAgdHdlZXRfdHlwZTogdHdlZXRUeXBlLFxuICAgIHJlcGx5X3RvX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpLFxuICAgIHJlcGx5X3RvX2FjY291bnQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc2NyZWVuX25hbWUpLFxuICAgIHF1b3RlZF90d2VldF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0ciksXG4gICAgcmV0d2VldGVkX3R3ZWV0X2lkOiBzdHJPck51bGwoXG4gICAgICBvYmoob2JqKGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX3Jlc3VsdCk/LnJlc3VsdCk/LnJlc3RfaWQgPz9cbiAgICAgICAgKGxlZ2FjeSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikucmV0d2VldGVkX3N0YXR1c19pZF9zdHJcbiAgICApLFxuICAgIHRleHQsXG4gICAgdGV4dF9yZXNvbHZlZDogcmVzb2x2ZVNob3J0VXJscyh0ZXh0LCB1cmxzKSxcbiAgICBsYW5nOiBzdHJPck51bGwobGVnYWN5LmxhbmcpLFxuICAgIGhhc2h0YWdzLFxuICAgIG1lbnRpb25zLFxuICAgIHVybHMsXG4gICAgbWVkaWEsXG4gICAgbGlrZV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5mYXZvcml0ZV9jb3VudCksXG4gICAgcmV0d2VldF9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcbiAgICByZXBseV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXBseV9jb3VudCksXG4gICAgcXVvdGVfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucXVvdGVfY291bnQpLFxuICAgIHZpZXdfY291bnQ6IHZpZXdDb3VudCxcbiAgICBib29rbWFya19jb3VudDogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXG4gICAgZW5nYWdlbWVudF9oaXN0b3J5OiBbXG4gICAgICB7XG4gICAgICAgIGNhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICAgICAgbGlrZXM6IG51bU9yWmVybyhsZWdhY3kuZmF2b3JpdGVfY291bnQpLFxuICAgICAgICByZXR3ZWV0czogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcbiAgICAgICAgcmVwbGllczogbnVtT3JaZXJvKGxlZ2FjeS5yZXBseV9jb3VudCksXG4gICAgICAgIHF1b3RlczogbnVtT3JaZXJvKGxlZ2FjeS5xdW90ZV9jb3VudCksXG4gICAgICAgIHZpZXdzOiB2aWV3Q291bnQsXG4gICAgICAgIGJvb2ttYXJrczogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXG4gICAgICB9LFxuICAgIF0sXG4gICAgd2F5YmFja191cmw6IG51bGwsXG4gICAgd2F5YmFja19zdWJtaXR0ZWRfYXQ6IG51bGwsXG4gICAgY2FwdHVyZV9zb3VyY2U6ICdleHRlbnNpb24nLFxuICAgIGNhcHR1cmVfcnVuX2lkOiBjdHgucnVuSWQsXG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gIH07XG5cbiAgcmV0dXJuIHR3ZWV0O1xufVxuXG5mdW5jdGlvbiBjbGFzc2lmeVR3ZWV0VHlwZSh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFR3ZWV0VHlwZSB7XG4gIGlmIChsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQgfHwgbGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JldHdlZXQnO1xuICBpZiAobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpIHJldHVybiAncmVwbHknO1xuICBpZiAobGVnYWN5LmlzX3F1b3RlX3N0YXR1cyA9PT0gdHJ1ZSB8fCBsZWdhY3kucXVvdGVkX3N0YXR1c19pZF9zdHIpIHJldHVybiAncXVvdGUnO1xuICBpZiAodC5fX3R5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnKSB7XG4gICAgLy8gcGFzcyB0aHJvdWdoXG4gIH1cbiAgcmV0dXJuICdvcmlnaW5hbCc7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RIYXNodGFncyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLmhhc2h0YWdzO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICByZXR1cm4gYXJyXG4gICAgLm1hcCgoaCkgPT5cbiAgICAgIHR5cGVvZiBoID09PSAnb2JqZWN0JyAmJiBoICYmICd0ZXh0JyBpbiBoID8gU3RyaW5nKChoIGFzIHsgdGV4dDogdW5rbm93biB9KS50ZXh0KSA6IG51bGxcbiAgICApXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0TWVudGlvbnMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy51c2VyX21lbnRpb25zO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICByZXR1cm4gYXJyXG4gICAgLm1hcCgodSkgPT5cbiAgICAgIHR5cGVvZiB1ID09PSAnb2JqZWN0JyAmJiB1ICYmICdzY3JlZW5fbmFtZScgaW4gdVxuICAgICAgICA/IFN0cmluZygodSBhcyB7IHNjcmVlbl9uYW1lOiB1bmtub3duIH0pLnNjcmVlbl9uYW1lKVxuICAgICAgICA6IG51bGxcbiAgICApXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0VXJscyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBVcmxFbnRpdHlbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLnVybHM7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XG4gIGNvbnN0IG91dDogVXJsRW50aXR5W10gPSBbXTtcbiAgZm9yIChjb25zdCB1IG9mIGFycikge1xuICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XG4gICAgY29uc3QgbyA9IHUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgY29uc3Qgc2hvcnQgPSBzdHJPck51bGwoby51cmwpO1xuICAgIGNvbnN0IGV4cGFuZGVkID0gc3RyT3JOdWxsKG8uZXhwYW5kZWRfdXJsKTtcbiAgICBjb25zdCBkaXNwbGF5ID0gc3RyT3JOdWxsKG8uZGlzcGxheV91cmwpO1xuICAgIGlmICghc2hvcnQgfHwgIWV4cGFuZGVkKSBjb250aW51ZTtcbiAgICBvdXQucHVzaCh7IHNob3J0LCBleHBhbmRlZCwgZGlzcGxheTogZGlzcGxheSA/PyBleHBhbmRlZCB9KTtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBleHRyYWN0TWVkaWEobGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbVtdIHtcbiAgY29uc3QgZXh0ZW5kZWQgPSBvYmoobGVnYWN5LmV4dGVuZGVkX2VudGl0aWVzKTtcbiAgY29uc3QgZnJvbUV4dCA9IGV4dGVuZGVkID8gdG9BcnJheShleHRlbmRlZC5tZWRpYSkgOiBbXTtcbiAgY29uc3QgZnJvbUVudCA9IHRvQXJyYXkob2JqKGxlZ2FjeS5lbnRpdGllcyk/Lm1lZGlhKTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCBtZXJnZWQgPSBbLi4uZnJvbUV4dCwgLi4uZnJvbUVudF0uZmlsdGVyKChtKSA9PiB7XG4gICAgaWYgKHR5cGVvZiBtICE9PSAnb2JqZWN0JyB8fCBtID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgaWQgPVxuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5tZWRpYV9rZXkpID8/XG4gICAgICBzdHJPck51bGwoKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLmlkX3N0cik7XG4gICAgaWYgKCFpZCkgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChzZWVuLmhhcyhpZCkpIHJldHVybiBmYWxzZTtcbiAgICBzZWVuLmFkZChpZCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuICByZXR1cm4gbWVyZ2VkLm1hcCgocmF3KSA9PiBidWlsZE1lZGlhKHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpO1xufVxuXG5mdW5jdGlvbiBidWlsZE1lZGlhKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogTWVkaWFJdGVtIHtcbiAgY29uc3QgdHlwZSA9IHN0ck9yTnVsbChtLnR5cGUpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddO1xuICBjb25zdCBvcmlnaW5hbCA9IHBpY2tPcmlnaW5hbFVybChtLCB0eXBlKTtcbiAgY29uc3QgaW5mbyA9IG9iaihtLm9yaWdpbmFsX2luZm8pO1xuICBjb25zdCB2aWRlb0luZm8gPSBvYmoobS52aWRlb19pbmZvKTtcbiAgY29uc3QgZHVyYXRpb25NcyA9IG51bU9yTnVsbCh2aWRlb0luZm8/LmR1cmF0aW9uX21pbGxpcyk7XG4gIGNvbnN0IGFsdFRleHQgPSBzdHJPck51bGwobS5leHRfYWx0X3RleHQpO1xuICBjb25zdCBtZWRpYUlkID1cbiAgICBzdHJPck51bGwobS5tZWRpYV9rZXkpID8/XG4gICAgc3RyT3JOdWxsKG0uaWRfc3RyKSA/P1xuICAgIGAke3R5cGUgPz8gJ21lZGlhJ30tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKX1gO1xuICByZXR1cm4ge1xuICAgIG1lZGlhX2lkOiBtZWRpYUlkLFxuICAgIG1lZGlhX3R5cGU6ICh0eXBlID8/ICdwaG90bycpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddLFxuICAgIG9yaWdpbmFsX3VybDogb3JpZ2luYWwgPz8gJycsXG4gICAgcmVsZWFzZV9hc3NldF91cmw6IG51bGwsXG4gICAgc2hhMjU2OiBudWxsLFxuICAgIGJ5dGVzOiBudWxsLFxuICAgIGR1cmF0aW9uX3NlYzogZHVyYXRpb25NcyAhPT0gbnVsbCA/IGR1cmF0aW9uTXMgLyAxMDAwIDogbnVsbCxcbiAgICB3aWR0aDogbnVtT3JOdWxsKGluZm8/LndpZHRoKSxcbiAgICBoZWlnaHQ6IG51bU9yTnVsbChpbmZvPy5oZWlnaHQpLFxuICAgIGFsdF90ZXh0OiBhbHRUZXh0LFxuICAgIGFyY2hpdmVfc3RhdHVzOiAncGVuZGluZycsXG4gICAgYXJjaGl2ZV9hdHRlbXB0czogMCxcbiAgICBsYXN0X2F0dGVtcHRfYXQ6IG51bGwsXG4gIH07XG59XG5cbmZ1bmN0aW9uIHBpY2tPcmlnaW5hbFVybChtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdHlwZTogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAodHlwZSA9PT0gJ3Bob3RvJykgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcykgPz8gc3RyT3JOdWxsKG0ubWVkaWFfdXJsKTtcbiAgY29uc3QgdmFyaWFudHMgPSB0b0FycmF5KG9iaihtLnZpZGVvX2luZm8pPy52YXJpYW50cykgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj5bXTtcbiAgaWYgKHZhcmlhbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcyk7XG4gIC8vIEhpZ2hlc3QtYml0cmF0ZSBtcDQuXG4gIGxldCBiZXN0OiB7IHVybDogc3RyaW5nOyBiaXRyYXRlOiBudW1iZXIgfSB8IG51bGwgPSBudWxsO1xuICBmb3IgKGNvbnN0IHYgb2YgdmFyaWFudHMpIHtcbiAgICBjb25zdCBjdCA9IHN0ck9yTnVsbCh2LmNvbnRlbnRfdHlwZSk7XG4gICAgY29uc3QgdXJsID0gc3RyT3JOdWxsKHYudXJsKTtcbiAgICBpZiAoIXVybCkgY29udGludWU7XG4gICAgaWYgKGN0ID09PSAndmlkZW8vbXA0Jykge1xuICAgICAgY29uc3QgYnIgPSBudW1Pck51bGwodi5iaXRyYXRlKSA/PyAwO1xuICAgICAgaWYgKCFiZXN0IHx8IGJyID4gYmVzdC5iaXRyYXRlKSBiZXN0ID0geyB1cmwsIGJpdHJhdGU6IGJyIH07XG4gICAgfSBlbHNlIGlmICghYmVzdCkge1xuICAgICAgLy8gRmFsbGJhY2sgdG8gYW55IHZhcmlhbnQgaWYgbm8gbXA0IGZvdW5kLlxuICAgICAgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiAwIH07XG4gICAgfVxuICB9XG4gIHJldHVybiBiZXN0Py51cmwgPz8gbnVsbDtcbn1cblxuZnVuY3Rpb24gcmVzb2x2ZVNob3J0VXJscyh0ZXh0OiBzdHJpbmcsIHVybHM6IFVybEVudGl0eVtdKTogc3RyaW5nIHtcbiAgaWYgKHVybHMubGVuZ3RoID09PSAwKSByZXR1cm4gdGV4dDtcbiAgbGV0IG91dCA9IHRleHQ7XG4gIGZvciAoY29uc3QgdSBvZiB1cmxzKSBvdXQgPSBvdXQuc3BsaXQodS5zaG9ydCkuam9pbih1LmV4cGFuZGVkKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gcGFyc2VUd2l0dGVyRGF0ZShzOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICghcykgcmV0dXJuIG51bGw7XG4gIC8vIFR3aXR0ZXIgc2hpcHMgZGF0ZXMgbGlrZSBcIk1vbiBBcHIgMTIgMTQ6MjM6MDEgKzAwMDAgMjAyNVwiLlxuICBjb25zdCBkID0gbmV3IERhdGUocyk7XG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIGQudG9JU09TdHJpbmcoKTtcbn1cblxuZnVuY3Rpb24gc3RyT3JOdWxsKHY6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDAgPyB2IDogbnVsbDtcbn1cbmZ1bmN0aW9uIG51bU9yTnVsbCh2OiB1bmtub3duKTogbnVtYmVyIHwgbnVsbCB7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ251bWJlcicgJiYgTnVtYmVyLmlzRmluaXRlKHYpKSByZXR1cm4gdjtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gTnVtYmVyKHYpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikpIHJldHVybiBuO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gbnVtT3JaZXJvKHY6IHVua25vd24pOiBudW1iZXIge1xuICByZXR1cm4gbnVtT3JOdWxsKHYpID8/IDA7XG59XG5mdW5jdGlvbiBvYmoodjogdW5rbm93bik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ29iamVjdCcgJiYgdiAhPT0gbnVsbCAmJiAhQXJyYXkuaXNBcnJheSh2KVxuICAgID8gKHYgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pXG4gICAgOiBudWxsO1xufVxuZnVuY3Rpb24gdG9BcnJheSh2OiB1bmtub3duKTogdW5rbm93bltdIHtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkodikgPyB2IDogW107XG59XG4iLCAiLyoqXG4gKiBMaWdodHdlaWdodCBVTElELWxpa2UgaWQgZ2VuZXJhdG9yOiAyNi1jaGFyYWN0ZXIgQ3JvY2tmb3JkIGJhc2UzMiBzdHJpbmdcbiAqIG9mICh0aW1lc3RhbXBfbXMgfHwgcmFuZG9tbmVzcykuIEdvb2QgZW5vdWdoIGZvciBydW4gaWRlbnRpZmllcnMgd2l0aG91dFxuICogcHVsbGluZyBpbiBhIHJlYWwgVUxJRCBkZXBlbmRlbmN5LlxuICovXG5cbmNvbnN0IEFMUEhBQkVUID0gJzAxMjM0NTY3ODlBQkNERUZHSEpLTU5QUVJTVFZXWFlaJzsgLy8gQ3JvY2tmb3JkXG5cbmV4cG9ydCBmdW5jdGlvbiBuZXdSdW5JZCgpOiBzdHJpbmcge1xuICBjb25zdCB0cyA9IERhdGUubm93KCk7XG4gIGxldCB0c1BhcnQgPSAnJztcbiAgbGV0IHQgPSB0cztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDsgaSsrKSB7XG4gICAgdHNQYXJ0ID0gKEFMUEhBQkVUW3QgJSAzMl0gPz8gJzAnKSArIHRzUGFydDtcbiAgICB0ID0gTWF0aC5mbG9vcih0IC8gMzIpO1xuICB9XG4gIGNvbnN0IHJhbmQgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEwKSk7XG4gIGxldCByYW5kUGFydCA9ICcnO1xuICBmb3IgKGNvbnN0IGIgb2YgcmFuZCkgcmFuZFBhcnQgKz0gQUxQSEFCRVRbYiAlIDMyXSA/PyAnMCc7XG4gIHJldHVybiB0c1BhcnQgKyByYW5kUGFydDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNob3J0UnVuSWQoaWQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBpZC5zbGljZSgtOCk7XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTWluaW1hbCBwYXJzZXIgZm9yIHRoZSBzdHJpY3Qgc2hhcGUgdXNlZCBieSBgY29uZmlnL2FjY291bnRzLnlhbWxgOlxuICpcbiAqICAgYWNjb3VudHM6XG4gKiAgICAgLSBoYW5kbGU6IERIU2dvdlxuICogICAgICAgbGFiZWw6IERlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHlcbiAqXG4gKiBXZSBkZWxpYmVyYXRlbHkgZG9uJ3QgcHVsbCBpbiBhIGZ1bGwgWUFNTCBsaWJyYXJ5IFx1MjAxNCB3ZSBjb250cm9sIGJvdGggZW5kcyBvZlxuICogdGhpcyBmaWxlLCBhbmQgYSA1MC1saW5lIHBhcnNlciBpcyBlYXNpZXIgdG8gYXVkaXQgdGhhbiB0aGUgYWx0ZXJuYXRpdmVzLlxuICogVW5rbm93biBrZXlzIGFuZCBjb21tZW50cyBhcmUgdG9sZXJhdGVkOyBtYWxmb3JtZWQgbGluZXMgYXJlIHNraXBwZWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUFjY291bnRzWWFtbCh0ZXh0OiBzdHJpbmcpOiBBY2NvdW50Q29uZmlnW10ge1xuICBjb25zdCBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdID0gW107XG4gIGxldCBjdXJyZW50OiBQYXJ0aWFsPEFjY291bnRDb25maWc+ID0ge307XG4gIGxldCBpbkFjY291bnRzID0gZmFsc2U7XG4gIGZvciAoY29uc3QgcmF3TGluZSBvZiB0ZXh0LnNwbGl0KCdcXG4nKSkge1xuICAgIGNvbnN0IGxpbmUgPSBzdHJpcENvbW1lbnRzKHJhd0xpbmUpO1xuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gJycpIGNvbnRpbnVlO1xuICAgIGlmICgvXmFjY291bnRzXFxzKjovLnRlc3QobGluZSkpIHtcbiAgICAgIGluQWNjb3VudHMgPSB0cnVlO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICghaW5BY2NvdW50cykgY29udGludWU7XG5cbiAgICBjb25zdCBpdGVtTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKi1cXHMqaGFuZGxlXFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoaXRlbU1hdGNoKSB7XG4gICAgICBpZiAoY3VycmVudC5oYW5kbGUgJiYgY3VycmVudC5sYWJlbCkgYWNjb3VudHMucHVzaChjdXJyZW50IGFzIEFjY291bnRDb25maWcpO1xuICAgICAgY3VycmVudCA9IHsgaGFuZGxlOiB1bnF1b3RlKGl0ZW1NYXRjaFsxXSA/PyAnJykgfTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBoYW5kbGVPbmx5ID0gbGluZS5tYXRjaCgvXlxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChoYW5kbGVPbmx5ICYmICFsaW5lLmluY2x1ZGVzKCctJykpIHtcbiAgICAgIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSBhY2NvdW50cy5wdXNoKGN1cnJlbnQgYXMgQWNjb3VudENvbmZpZyk7XG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaGFuZGxlT25seVsxXSA/PyAnJykgfTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBsYWJlbE1hdGNoID0gbGluZS5tYXRjaCgvXlxccypsYWJlbFxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGxhYmVsTWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcbiAgICAgIGN1cnJlbnQubGFiZWwgPSB1bnF1b3RlKGxhYmVsTWF0Y2hbMV0gPz8gJycpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICB9XG4gIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSBhY2NvdW50cy5wdXNoKGN1cnJlbnQgYXMgQWNjb3VudENvbmZpZyk7XG4gIHJldHVybiBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuaGFuZGxlLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBzdHJpcENvbW1lbnRzKGxpbmU6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIE5haXZlIGJ1dCBhZGVxdWF0ZSBmb3Igb3VyIGZvcm1hdDogc3RyaXAgZXZlcnl0aGluZyBhZnRlciBhIGAjYCB0aGF0IGlzbid0XG4gIC8vIGluc2lkZSBxdW90ZXMuIE91ciBjb25maWcgbmV2ZXIgdXNlcyBpbmxpbmUgc3RyaW5ncyB3aXRoIGAjYC5cbiAgY29uc3QgaWR4ID0gbGluZS5pbmRleE9mKCcjJyk7XG4gIHJldHVybiBpZHggPT09IC0xID8gbGluZSA6IGxpbmUuc2xpY2UoMCwgaWR4KTtcbn1cblxuZnVuY3Rpb24gdW5xdW90ZShzOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCB0cmltbWVkID0gcy50cmltKCk7XG4gIGlmIChcbiAgICAodHJpbW1lZC5zdGFydHNXaXRoKCdcIicpICYmIHRyaW1tZWQuZW5kc1dpdGgoJ1wiJykpIHx8XG4gICAgKHRyaW1tZWQuc3RhcnRzV2l0aChcIidcIikgJiYgdHJpbW1lZC5lbmRzV2l0aChcIidcIikpXG4gICkge1xuICAgIHJldHVybiB0cmltbWVkLnNsaWNlKDEsIC0xKTtcbiAgfVxuICByZXR1cm4gdHJpbW1lZDtcbn1cbiIsICIvKipcbiAqIGJhY2tncm91bmQudHMgXHUyMDE0IGV4dGVuc2lvbiBzZXJ2aWNlIHdvcmtlci5cbiAqXG4gKiBPd25zIHRoZSBjYXB0dXJlIHBpcGVsaW5lOiByZWNlaXZlcyBgZ3JhcGhxbC1jYXB0dXJlYCBtZXNzYWdlcyBmcm9tIHRoZVxuICogY29udGVudCBzY3JpcHQsIG5vcm1hbGl6ZXMgdGhlbSwgYWNjdW11bGF0ZXMgcGVyLWhhbmRsZSBydW4gYnVmZmVycyBpblxuICogYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAsIGFuZCBjb21taXRzIHRoZW0gdG8gdGhlIGNvbmZpZ3VyZWQgR2l0SHViIHJlcG9cbiAqIHZpYSB0aGUgQ29udGVudHMgQVBJLlxuICpcbiAqIFNlcnZpY2Ugd29ya2VycyBpbiBNVjMgbWF5IGJlIGV2aWN0ZWQgYXQgYW55IHRpbWUsIHNvIGFsbCBjcml0aWNhbCBzdGF0ZVxuICogbGl2ZXMgaW4gc3RvcmFnZSAobmV2ZXIgbW9kdWxlLXNjb3BlKS4gT24gZXZlcnkgd2FrZSB3ZSByZS1kZXJpdmUgd2hhdCB3ZVxuICogbmVlZDsgcGVuZGluZyBmbHVzaGVzIGFyZSBkcml2ZW4gYnkgYGJyb3dzZXIuYWxhcm1zYCByYXRoZXIgdGhhbiB0aW1lcnMuXG4gKi9cblxuaW1wb3J0IHtcbiAgRkFMTEJBQ0tfQUNDT1VOVFMsXG4gIEZMVVNIX0FMQVJNX01JTlVURVMsXG4gIEZMVVNIX0lETEVfTVMsXG4gIEZMVVNIX1RXRUVUX1RIUkVTSE9MRCxcbiAgUFJPRklMRV9FTkRQT0lOVFMsXG4gIFRXRUVUX0VORFBPSU5UUyxcbiAgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMsXG59IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XG5pbXBvcnQgeyBHaXRIdWJDbGllbnQsIEdpdEh1YkVycm9yLCB0b0Jhc2U2NCB9IGZyb20gJy4vbGliL2dpdGh1Yi5qcyc7XG5pbXBvcnQgeyBkZXNjcmliZUVycm9yLCBlcnJvciBhcyBsb2dFcnIsIGluZm8sIHNldEJyb2FkY2FzdGVyLCB3YXJuIH0gZnJvbSAnLi9saWIvbG9nZ2VyLmpzJztcbmltcG9ydCB7IG5vcm1hbGl6ZSB9IGZyb20gJy4vbGliL25vcm1hbGl6ZS5qcyc7XG5pbXBvcnQgeyBuZXdSdW5JZCwgc2hvcnRSdW5JZCB9IGZyb20gJy4vbGliL3J1bmlkcy5qcyc7XG5pbXBvcnQge1xuICBidW1wQ291bnRlcixcbiAgY2xlYXJBY3Rpdml0eSxcbiAgY2xlYXJBbGwsXG4gIGNsZWFyUnVuQnVmZmVyLFxuICBnZXRBY2NvdW50cyxcbiAgZ2V0QWN0aXZpdHksXG4gIGdldENvbm5lY3Rpb24sXG4gIGdldENvdW50ZXJzLFxuICBnZXRSdW5CdWZmZXIsXG4gIGdldFJ1bkJ1ZmZlcnMsXG4gIGdldFNldHRpbmdzLFxuICBzZXRBY2NvdW50cyxcbiAgc2V0QnVmZmVyZWRDb3VudCxcbiAgc2V0Q29ubmVjdGlvbixcbiAgc2V0UnVuQnVmZmVyLFxuICB0eXBlIFJ1bkJ1ZmZlcixcbiAgdXBkYXRlU2V0dGluZ3MsXG59IGZyb20gJy4vbGliL3N0b3JhZ2UuanMnO1xuaW1wb3J0IHR5cGUge1xuICBDYW5vbmljYWxUd2VldCxcbiAgQ2FwdHVyZVBheWxvYWQsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgRXh0ZW5zaW9uU3RhdGUsXG4gIExvZ0V2ZW50LFxuICBRdWFyYW50aW5lUGF5bG9hZCxcbiAgUnVudGltZU1lc3NhZ2UsXG4gIFNlZW5QYXlsb2FkLFxuICBTZXR0aW5ncyxcbn0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xuaW1wb3J0IHsgcGFyc2VBY2NvdW50c1lhbWwgfSBmcm9tICcuL2xpYi95YW1sLmpzJztcblxuY29uc3QgRVhUX1ZFUlNJT04gPSBicm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uO1xuXG5zZXRCcm9hZGNhc3RlcigoZXY6IExvZ0V2ZW50KSA9PiB7XG4gIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdsb2ctZXZlbnQnLCBldmVudDogZXYgfSkuY2F0Y2goKCkgPT4ge30pO1xufSk7XG5cbi8vIC0tLSBXYWtlIGhhbmRsZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmJyb3dzZXIucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XG4gIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBpbnN0YWxsZWQnLCB7IHZlcnNpb246IEVYVF9WRVJTSU9OIH0pO1xuICBhd2FpdCBvbldha2UoJ2luc3RhbGwnKTtcbn0pO1xuXG5icm93c2VyLnJ1bnRpbWUub25TdGFydHVwLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgdm9pZCBvbldha2UoJ3N0YXJ0dXAnKTtcbn0pO1xuXG4vLyBGb3JjZSBhdCBsZWFzdCBvbmUgd2FrZSB0byByZWdpc3RlciBhbGFybXMgLyB2ZXJpZnkgY29ubmVjdGlvbi5cbnZvaWQgb25XYWtlKCdtb2R1bGUtbG9hZCcpO1xuXG5hc3luYyBmdW5jdGlvbiBvbldha2UocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBlbnN1cmVBbGFybXMoKTtcbiAgICBhd2FpdCBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTtcbiAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgaWYgKHNldHRpbmdzLnBhdCAmJiBzZXR0aW5ncy5vd25lciAmJiBzZXR0aW5ncy5yZXBvKSB7XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgICAgIGF3YWl0IHJlZnJlc2hBY2NvdW50c0xpc3QoZmFsc2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgICBsb2dpbjogbnVsbCxcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBpbmZvKCdleHRlbnNpb24gYXdha2U7IHNldHRpbmdzIGluY29tcGxldGUnLCB7IHJlYXNvbiB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IGxvZ0Vycignd2FrZSBmYWlsZWQnLCB7IHJlYXNvbiwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUFsYXJtcygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ2ZsdXNoLXN3ZWVwJyk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd2ZXJpZnktY29ubmVjdGlvbicpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jcmVhdGUoJ2ZsdXNoLXN3ZWVwJywgeyBwZXJpb2RJbk1pbnV0ZXM6IEZMVVNIX0FMQVJNX01JTlVURVMgfSk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgndmVyaWZ5LWNvbm5lY3Rpb24nLCB7XG4gICAgcGVyaW9kSW5NaW51dGVzOiBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyAvIDYwXzAwMCxcbiAgfSk7XG59XG5cbmJyb3dzZXIuYWxhcm1zLm9uQWxhcm0uYWRkTGlzdGVuZXIoKGFsYXJtKSA9PiB7XG4gIGlmIChhbGFybS5uYW1lID09PSAnZmx1c2gtc3dlZXAnKSB7XG4gICAgdm9pZCBmbHVzaElkbGVCdWZmZXJzKCk7XG4gIH0gZWxzZSBpZiAoYWxhcm0ubmFtZSA9PT0gJ3ZlcmlmeS1jb25uZWN0aW9uJykge1xuICAgIHZvaWQgdmVyaWZ5Q29ubmVjdGlvbihmYWxzZSk7XG4gIH1cbn0pO1xuXG4vLyAtLS0gVG9vbGJhciBhY3Rpb246IHRvZ2dsZSB0aGUgc2lkZWJhciAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5pZiAoYnJvd3Nlci5hY3Rpb24/Lm9uQ2xpY2tlZCkge1xuICBicm93c2VyLmFjdGlvbi5vbkNsaWNrZWQuYWRkTGlzdGVuZXIoYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnNpZGViYXJBY3Rpb24udG9nZ2xlKCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAvLyBGYWxsYmFjazogb3BlbiBvcHRpb25zIGlmIHNpZGViYXIgY2FuJ3QgYmUgdG9nZ2xlZC5cbiAgICAgIGF3YWl0IHdhcm4oJ3NpZGViYXIgdG9nZ2xlIGZhaWxlZDsgb3BlbmluZyBvcHRpb25zJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICAgIGF3YWl0IGJyb3dzZXIucnVudGltZS5vcGVuT3B0aW9uc1BhZ2UoKTtcbiAgICB9XG4gIH0pO1xufVxuXG4vLyAtLS0gUnVudGltZSBtZXNzYWdlIGRpc3BhdGNoIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93biwgX3NlbmRlcikgPT4ge1xuICBpZiAoIWlzUnVudGltZU1lc3NhZ2UobXNnKSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgcmV0dXJuIGhhbmRsZU1lc3NhZ2UobXNnKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgdm9pZCBsb2dFcnIoJ21lc3NhZ2UgaGFuZGxlciBmYWlsZWQnLCB7IHR5cGU6IG1zZy50eXBlLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gICAgdGhyb3cgZXJyO1xuICB9KTtcbn0pO1xuXG5mdW5jdGlvbiBpc1J1bnRpbWVNZXNzYWdlKG06IHVua25vd24pOiBtIGlzIFJ1bnRpbWVNZXNzYWdlIHtcbiAgcmV0dXJuICEhbSAmJiB0eXBlb2YgbSA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIChtIGFzIHsgdHlwZT86IHVua25vd24gfSkudHlwZSA9PT0gJ3N0cmluZyc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UobXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8dW5rbm93bj4ge1xuICBzd2l0Y2ggKG1zZy50eXBlKSB7XG4gICAgY2FzZSAnZ3JhcGhxbC1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IG9uR3JhcGhxbENhcHR1cmUobXNnLmVuZHBvaW50LCBtc2cudXJsLCBtc2cucmVzcG9uc2UpO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdjb250ZW50LWFsaXZlJzpcbiAgICAgIGF3YWl0IGluZm8oJ2NvbnRlbnQgc2NyaXB0IGFsaXZlIG9uIHBhZ2UnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAncGFnZS1ob29rLWFjdGl2ZSc6XG4gICAgICBhd2FpdCBpbmZvKCdwYWdlIGhvb2sgcGF0Y2hlZCBmZXRjaC9YSFInLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnbG9nLWNvbnRlbnQtZXZlbnQnOlxuICAgICAgaWYgKG1zZy5sZXZlbCA9PT0gJ3dhcm4nKSB7XG4gICAgICAgIGF3YWl0IHdhcm4obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9IGVsc2UgaWYgKG1zZy5sZXZlbCA9PT0gJ2Vycm9yJykge1xuICAgICAgICBhd2FpdCBsb2dFcnIobXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCBpbmZvKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdnZXQtc3RhdGUnOlxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLW5vdyc6XG4gICAgICBhd2FpdCBjYXB0dXJlTm93KG1zZy5oYW5kbGUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLWFsbCc6XG4gICAgICBhd2FpdCBjYXB0dXJlQWxsKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2ZsdXNoLWFsbCc6XG4gICAgICBhd2FpdCBmbHVzaEFsbCgndXNlcicpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdmbHVzaC1oYW5kbGUnOlxuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUobXNnLmhhbmRsZSwgJ3VzZXInKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAndG9nZ2xlLWF1dG8tY2FwdHVyZSc6XG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGF1dG9DYXB0dXJlOiBtc2cub24gfSk7XG4gICAgICBhd2FpdCBpbmZvKCdhdXRvLWNhcHR1cmUgdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAncmVmcmVzaC1hY2NvdW50cyc6XG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd2ZXJpZnktY29ubmVjdGlvbic6XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjbGVhci1hY3Rpdml0eSc6XG4gICAgICBhd2FpdCBjbGVhckFjdGl2aXR5KCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tb3B0aW9ucyc6XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tdmlld2VyJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgICBjb25zdCB1cmwgPSB2aWV3ZXJVcmwocyk7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICd1bmtub3duIG1lc3NhZ2UgdHlwZScgfTtcbiAgfVxufVxuXG4vLyAtLS0gQ2FwdHVyZSBwaXBlbGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBvbkdyYXBocWxDYXB0dXJlKGVuZHBvaW50OiBzdHJpbmcsIHVybDogc3RyaW5nLCByZXNwb25zZTogdW5rbm93bik6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoUFJPRklMRV9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuOyAvLyBub3QgdHdlZXQtYmVhcmluZ1xuICBpZiAoIVRXRUVUX0VORFBPSU5UUy5oYXMoZW5kcG9pbnQpKSByZXR1cm47XG5cbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0KSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZSBpZ25vcmVkOiBQQVQgbm90IGNvbmZpZ3VyZWQnLCB7IGVuZHBvaW50IH0pO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IGFsbG93ZWQgPSBuZXcgU2V0KGFjY291bnRzLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBjYXB0dXJlZEF0ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuXG4gIGxldCBub3JtYWxpemVkO1xuICB0cnkge1xuICAgIG5vcm1hbGl6ZWQgPSBub3JtYWxpemUocmVzcG9uc2UsIHtcbiAgICAgIGNhcHR1cmVkQXQsXG4gICAgICBydW5JZDogJ3BlbmRpbmcnLFxuICAgICAgZW5kcG9pbnQsXG4gICAgICBhbGxvd2VkSGFuZGxlczogYWxsb3dlZCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgcXVhcmFudGluZSgnbm9ybWFsaXplLXRocmV3JywgZW5kcG9pbnQsIHVybCwgcmVzcG9uc2UsIGVycik7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gIC8vIEdyb3VwIHR3ZWV0cyBieSBhdXRob3IgaGFuZGxlLlxuICBjb25zdCBieUhhbmRsZSA9IG5ldyBNYXA8c3RyaW5nLCBDYW5vbmljYWxUd2VldFtdPigpO1xuICBmb3IgKGNvbnN0IHQgb2Ygbm9ybWFsaXplZC50d2VldHMpIHtcbiAgICBjb25zdCBhcnIgPSBieUhhbmRsZS5nZXQodC5hY2NvdW50X2hhbmRsZSkgPz8gW107XG4gICAgYXJyLnB1c2godCk7XG4gICAgYnlIYW5kbGUuc2V0KHQuYWNjb3VudF9oYW5kbGUsIGFycik7XG4gIH1cblxuICBmb3IgKGNvbnN0IFtoYW5kbGUsIHR3ZWV0c10gb2YgYnlIYW5kbGUpIHtcbiAgICBjb25zdCBidWYgPSBhd2FpdCBlbnN1cmVSdW5CdWZmZXIoaGFuZGxlLCBjYXB0dXJlZEF0LCB1cmwsIGVuZHBvaW50KTtcbiAgICBsZXQgYWRkZWQgPSAwO1xuICAgIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICAgIGNvbnN0IGV4aXN0aW5nID0gYnVmLnR3ZWV0c19ieV9pZFt0LnR3ZWV0X2lkXTtcbiAgICAgIGlmIChleGlzdGluZykge1xuICAgICAgICAvLyBQcmVzZXJ2ZSBmaXJzdF9jYXB0dXJlZF9hdCwgYXBwZW5kIGVuZ2FnZW1lbnQgc25hcHNob3QsIHJlZnJlc2hcbiAgICAgICAgLy8gbGFzdF9zZWVuX2F0ICsgY291bnRzICh0aGUgbGF0ZXN0IHNjcmFwZSB3aW5zIGZvciBjb3VudHMpLlxuICAgICAgICBleGlzdGluZy5sYXN0X3NlZW5fYXQgPSBjYXB0dXJlZEF0O1xuICAgICAgICBleGlzdGluZy5saWtlX2NvdW50ID0gdC5saWtlX2NvdW50O1xuICAgICAgICBleGlzdGluZy5yZXR3ZWV0X2NvdW50ID0gdC5yZXR3ZWV0X2NvdW50O1xuICAgICAgICBleGlzdGluZy5yZXBseV9jb3VudCA9IHQucmVwbHlfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnF1b3RlX2NvdW50ID0gdC5xdW90ZV9jb3VudDtcbiAgICAgICAgZXhpc3Rpbmcudmlld19jb3VudCA9IHQudmlld19jb3VudDtcbiAgICAgICAgZXhpc3RpbmcuYm9va21hcmtfY291bnQgPSB0LmJvb2ttYXJrX2NvdW50O1xuICAgICAgICBjb25zdCBsYXN0ID0gZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5W2V4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeS5sZW5ndGggLSAxXTtcbiAgICAgICAgY29uc3Qgc25hcCA9IHQuZW5nYWdlbWVudF9oaXN0b3J5WzBdO1xuICAgICAgICBpZiAoc25hcCAmJiAoIWxhc3QgfHwgbGFzdC5jYXB0dXJlZF9hdCAhPT0gc25hcC5jYXB0dXJlZF9hdCkpIHtcbiAgICAgICAgICBleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnkucHVzaChzbmFwKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3Qgc3RhbXBlZDogQ2Fub25pY2FsVHdlZXQgPSB7IC4uLnQsIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkIH07XG4gICAgICAgIGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF0gPSBzdGFtcGVkO1xuICAgICAgICBhZGRlZCArPSAxO1xuICAgICAgfVxuICAgICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHQudHdlZXRfaWQpKSB7XG4gICAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFidWYuZW5kcG9pbnRzX3NlZW4uaW5jbHVkZXMoZW5kcG9pbnQpKSBidWYuZW5kcG9pbnRzX3NlZW4ucHVzaChlbmRwb2ludCk7XG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcbiAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoKTtcbiAgICBpZiAoYWRkZWQgPiAwKSB7XG4gICAgICBhd2FpdCBpbmZvKCdjYXB0dXJlZCB0d2VldHMnLCB7XG4gICAgICAgIGhhbmRsZSxcbiAgICAgICAgZW5kcG9pbnQsXG4gICAgICAgIGFkZGVkLFxuICAgICAgICB0b3RhbDogT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggPj0gRkxVU0hfVFdFRVRfVEhSRVNIT0xEKSB7XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICd0aHJlc2hvbGQnKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlUnVuQnVmZmVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgdHM6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8UnVuQnVmZmVyPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpO1xuICBpZiAoY3VyKSByZXR1cm4gY3VyO1xuICBjb25zdCBidWY6IFJ1bkJ1ZmZlciA9IHtcbiAgICBydW5faWQ6IG5ld1J1bklkKCksXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBzdGFydGVkX2F0OiB0cyxcbiAgICBsYXN0X2NhcHR1cmVfYXQ6IHRzLFxuICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcbiAgICBlbmRwb2ludHNfc2VlbjogW2VuZHBvaW50XSxcbiAgICBzb3VyY2VfdXJsOiBzb3VyY2VVcmwsXG4gIH07XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gIGF3YWl0IGluZm8oJ3J1biBzdGFydGVkJywgeyBoYW5kbGUsIHJ1bjogc2hvcnRSdW5JZChidWYucnVuX2lkKSB9KTtcbiAgcmV0dXJuIGJ1Zjtcbn1cblxuLy8gLS0tIEZsdXNoIGxvZ2ljIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hJZGxlQnVmZmVycygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICdpZGxlJyk7XG4gICAgfVxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoT3JwaGFuZWRCdWZmZXJzSWZTdGFsZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gT24gd29ya2VyIHdha2UsIGFueSBidWZmZXIgb2xkZXIgdGhhbiB0aGUgaWRsZSB0aHJlc2hvbGQgZ2V0cyBhIGNoYW5jZSB0b1xuICAvLyBjb21taXQgaW1tZWRpYXRlbHkgXHUyMDE0IHVzZWZ1bCB3aGVuIHRoZSB3b3JrZXIgd2FzIGV2aWN0ZWQgYmVmb3JlIGlkbGUtZmx1c2guXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUoaGFuZGxlLCAnd2FrZScpO1xuICAgIH1cbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaEFsbChyZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIE9iamVjdC5rZXlzKGFsbCkpIHtcbiAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsIHJlYXNvbik7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGUoaGFuZGxlOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGJ1ZiA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpO1xuICBpZiAoIWJ1ZikgcmV0dXJuO1xuICBjb25zdCB0d2VldHMgPSBPYmplY3QudmFsdWVzKGJ1Zi50d2VldHNfYnlfaWQpO1xuICBpZiAodHdlZXRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGF3YWl0IGNsZWFyUnVuQnVmZmVyKGhhbmRsZSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSB7XG4gICAgYXdhaXQgd2FybignZmx1c2ggZGVmZXJyZWQ6IHNldHRpbmdzIGluY29tcGxldGUnLCB7IGhhbmRsZSB9KTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChidWYuc3RhcnRlZF9hdCk7XG4gIGNvbnN0IGRheSA9IGJ1Zi5zdGFydGVkX2F0LnNsaWNlKDAsIDEwKTtcbiAgY29uc3QgcmF3UGF0aCA9IGByYXcvJHtoYW5kbGV9LyR7dHN9LSR7c2hvcnRSdW5JZChidWYucnVuX2lkKX0uanNvbmA7XG4gIGNvbnN0IHNlZW5QYXRoID0gYHNlZW4vJHtoYW5kbGV9LyR7dHN9LSR7c2hvcnRSdW5JZChidWYucnVuX2lkKX0uanNvbmA7XG5cbiAgY29uc3QgY2FwdHVyZTogQ2FwdHVyZVBheWxvYWQgPSB7XG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICBlbmRwb2ludDogYnVmLmVuZHBvaW50c19zZWVuLmpvaW4oJywnKSxcbiAgICB1c2VyX2FnZW50OiBuYXZpZ2F0b3IudXNlckFnZW50LFxuICAgIHNvdXJjZV91cmw6IGJ1Zi5zb3VyY2VfdXJsLFxuICAgIHR3ZWV0cyxcbiAgfTtcbiAgY29uc3Qgc2VlbjogU2VlblBheWxvYWQgPSB7XG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQsXG4gIH07XG5cbiAgY29uc3QgY29tbWl0TXNnID0gYGNhcHR1cmU6ICR7aGFuZGxlfSAke2RheX0gJHt0d2VldHMubGVuZ3RofSB0d2VldCR7dHdlZXRzLmxlbmd0aCA9PT0gMSA/ICcnIDogJ3MnfSAocnVuICR7c2hvcnRSdW5JZChidWYucnVuX2lkKX0pYDtcblxuICB0cnkge1xuICAgIGF3YWl0IGNsaWVudC5wdXRGaWxlKHtcbiAgICAgIHBhdGg6IHJhd1BhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShjYXB0dXJlLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICAgIG1lc3NhZ2U6IGNvbW1pdE1zZyxcbiAgICB9KTtcbiAgICBhd2FpdCBjbGllbnQucHV0RmlsZSh7XG4gICAgICBwYXRoOiBzZWVuUGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHNlZW4sIG51bGwsIDIpICsgJ1xcbicpLFxuICAgICAgbWVzc2FnZTogYHNlZW46ICR7aGFuZGxlfSAke2RheX0gJHtzZWVuLnR3ZWV0X2lkc19vYnNlcnZlZC5sZW5ndGh9IGlkcyAocnVuICR7c2hvcnRSdW5JZChidWYucnVuX2lkKX0pYCxcbiAgICB9KTtcbiAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihoYW5kbGUpO1xuICAgIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwge1xuICAgICAgdG9kYXlDb3VudDogKGF3YWl0IGdldENvdW50ZXJzKCkpW2hhbmRsZV0/LnRvZGF5Q291bnQgPz8gMCxcbiAgICAgIHRvZGF5RGF0ZTogZGF5LFxuICAgICAgbGFzdENhcHR1cmVBdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgIHRvdGFsQ29tbWl0dGVkOiAoKGF3YWl0IGdldENvdW50ZXJzKCkpW2hhbmRsZV0/LnRvdGFsQ29tbWl0dGVkID8/IDApICsgdHdlZXRzLmxlbmd0aCxcbiAgICAgIGJ1ZmZlcmVkQ291bnQ6IDAsXG4gICAgfSk7XG4gICAgYXdhaXQgaW5mbygnZmx1c2ggY29tbWl0dGVkJywge1xuICAgICAgaGFuZGxlLFxuICAgICAgcmVhc29uLFxuICAgICAgdHdlZXRzOiB0d2VldHMubGVuZ3RoLFxuICAgICAgcnVuOiBzaG9ydFJ1bklkKGJ1Zi5ydW5faWQpLFxuICAgICAgcGF0aDogcmF3UGF0aCxcbiAgICB9KTtcbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1czogJ29rJyxcbiAgICAgIGxvZ2luOiAoYXdhaXQgZ2V0Q29ubmVjdGlvbigpKS5sb2dpbixcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IG51bGwsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvcikge1xuICAgICAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XG4gICAgICAgIGVyci5jYXRlZ29yeSA9PT0gJ2F1dGgnXG4gICAgICAgICAgPyAnYXV0aC1lcnJvcidcbiAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnXG4gICAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ25ldHdvcmsnXG4gICAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXG4gICAgICAgICAgICAgIDogY29ubi5zdGF0dXM7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzLFxuICAgICAgICBsb2dpbjogY29ubi5sb2dpbixcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBlcnIubWVzc2FnZSxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgbG9nRXJyKCdmbHVzaCBmYWlsZWQnLCB7XG4gICAgICAgIGhhbmRsZSxcbiAgICAgICAgcmVhc29uLFxuICAgICAgICBjYXRlZ29yeTogZXJyLmNhdGVnb3J5LFxuICAgICAgICBzdGF0dXM6IGVyci5zdGF0dXMsXG4gICAgICAgIG1lc3NhZ2U6IGVyci5tZXNzYWdlLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGxvZ0VycignZmx1c2ggZmFpbGVkJywgeyBoYW5kbGUsIHJlYXNvbiwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICAgIH1cbiAgICAvLyBMZWF2ZSBidWZmZXIgaW50YWN0IGZvciByZXRyeS5cbiAgfSBmaW5hbGx5IHtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICB9XG59XG5cbi8vIC0tLSBDYXB0dXJlLW5vdyAvIGNhcHR1cmUtYWxsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gY2FwdHVyZU5vdyhoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBpbmZvKCdjYXB0dXJlLW5vdyByZXF1ZXN0ZWQnLCB7IGhhbmRsZSB9KTtcbiAgLy8gUHJlLXNlZWQgYW4gZW1wdHkgYnVmZmVyIHNvIHRoZSBhY3Rpdml0eSB0YWlsIHJlZmxlY3RzIGludGVudCBldmVuIGJlZm9yZVxuICAvLyB0aGUgZmlyc3QgR3JhcGhRTCByZXNwb25zZSBsYW5kcy5cbiAgaWYgKCEoYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSkpKSB7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIHtcbiAgICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBzdGFydGVkX2F0OiBub3csXG4gICAgICBsYXN0X2NhcHR1cmVfYXQ6IG5vdyxcbiAgICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IFtdLFxuICAgICAgZW5kcG9pbnRzX3NlZW46IFtdLFxuICAgICAgc291cmNlX3VybDogYGh0dHBzOi8veC5jb20vJHtoYW5kbGV9YCxcbiAgICB9KTtcbiAgfVxuICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsOiBgaHR0cHM6Ly94LmNvbS8ke2hhbmRsZX1gLCBhY3RpdmU6IHRydWUgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVBbGwoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgYXdhaXQgaW5mbygnY2FwdHVyZS1hbGwgcmVxdWVzdGVkJywgeyBjb3VudDogYWNjb3VudHMubGVuZ3RoIH0pO1xuICBmb3IgKGNvbnN0IGEgb2YgYWNjb3VudHMpIHtcbiAgICBhd2FpdCBjYXB0dXJlTm93KGEuaGFuZGxlKTtcbiAgfVxufVxuXG4vLyAtLS0gUXVhcmFudGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBxdWFyYW50aW5lKFxuICByZWFzb246IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgdXJsOiBzdHJpbmcsXG4gIHJhdzogdW5rbm93bixcbiAgZXJyOiB1bmtub3duXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgbG9nRXJyKCdxdWFyYW50aW5pbmcgY2FwdHVyZScsIHsgcmVhc29uLCBlbmRwb2ludCwgdXJsLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSByZXR1cm47XG4gIGNvbnN0IHBheWxvYWQ6IFF1YXJhbnRpbmVQYXlsb2FkID0ge1xuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgIHJlYXNvbixcbiAgICBlbmRwb2ludCxcbiAgICBjYXB0dXJlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNvdXJjZV91cmw6IHVybCxcbiAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIHJhdyxcbiAgfTtcbiAgY29uc3QgdHMgPSBpc29Db21wYWN0KHBheWxvYWQuY2FwdHVyZWRfYXQpO1xuICBjb25zdCBoYXNoID0gYXdhaXQgc2hhOChKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XG4gIGNvbnN0IHBhdGggPSBgcmF3L19xdWFyYW50aW5lLyR7dHN9LSR7aGFzaH0uanNvbmA7XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgYXdhaXQgY2xpZW50LnB1dEZpbGUoe1xuICAgICAgcGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHBheWxvYWQsIG51bGwsIDIpICsgJ1xcbicpLFxuICAgICAgbWVzc2FnZTogYHF1YXJhbnRpbmU6ICR7cmVhc29ufSAke2VuZHBvaW50fWAsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKHFlcnIpIHtcbiAgICBhd2FpdCBsb2dFcnIoJ3F1YXJhbnRpbmUgY29tbWl0IGZhaWxlZCcsIHsgLi4uZGVzY3JpYmVFcnJvcihxZXJyKSB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzaGE4KHM6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGJ1ZiA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcbiAgY29uc3QgZGlnZXN0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBidWYpO1xuICBjb25zdCBoZXggPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGRpZ2VzdCkpXG4gICAgLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcbiAgICAuam9pbignJyk7XG4gIHJldHVybiBoZXguc2xpY2UoMCwgOCk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHZlcmlmaWNhdGlvbiAmIGFjY291bnRzIGxpc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5Q29ubmVjdGlvbihmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgbG9naW46IG51bGwsXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGlmICghZm9yY2UgJiYgY29ubi5zdGF0dXMgPT09ICdvaycgJiYgY29ubi5jaGVja2VkQXQpIHtcbiAgICBjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShjb25uLmNoZWNrZWRBdCk7XG4gICAgaWYgKGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XG4gIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgICBjb25zdCByID0gYXdhaXQgY2xpZW50LnZlcmlmeVJlcG9BY2Nlc3MoKTtcbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1czogJ29rJyxcbiAgICAgIGxvZ2luOiByLmxvZ2luLFxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlcnJvcjogbnVsbCxcbiAgICB9KTtcbiAgICBhd2FpdCBpbmZvKCdjb25uZWN0aW9uIHZlcmlmaWVkJywgeyBsb2dpbjogci5sb2dpbiwgcmVwbzogci5mdWxsX25hbWUgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnN0IGNhdCA9IGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yID8gZXJyLmNhdGVnb3J5IDogJ3Vua25vd24nO1xuICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XG4gICAgICBjYXQgPT09ICdhdXRoJ1xuICAgICAgICA/ICdhdXRoLWVycm9yJ1xuICAgICAgICA6IGNhdCA9PT0gJ3JhdGUtbGltaXQnXG4gICAgICAgICAgPyAncmF0ZS1saW1pdGVkJ1xuICAgICAgICAgIDogY2F0ID09PSAnbmV0d29yaydcbiAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXG4gICAgICAgICAgICA6ICdhdXRoLWVycm9yJztcbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1cyxcbiAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLm1lc3NhZ2UsXG4gICAgfSk7XG4gICAgYXdhaXQgd2FybignY29ubmVjdGlvbiBjaGVjayBmYWlsZWQnLCB7IGNhdGVnb3J5OiBjYXQsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQWNjb3VudHNMaXN0KGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQpIHtcbiAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcbiAgICByZXR1cm47XG4gIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgY2xpZW50LmZldGNoUmF3VGV4dCgnY29uZmlnL2FjY291bnRzLnlhbWwnKTtcbiAgICBpZiAoIXRleHQpIHtcbiAgICAgIGlmIChmb3JjZSkgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBub3QgZm91bmQgaW4gcmVwbzsgdXNpbmcgZmFsbGJhY2snKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBwYXJzZWQgPSBwYXJzZUFjY291bnRzWWFtbCh0ZXh0KTtcbiAgICBpZiAocGFyc2VkLmxlbmd0aCA9PT0gMCkge1xuICAgICAgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBwYXJzZWQgZW1wdHk7IGtlZXBpbmcgZmFsbGJhY2snKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhd2FpdCBzZXRBY2NvdW50cyhwYXJzZWQpO1xuICAgIGlmIChmb3JjZSkgYXdhaXQgaW5mbygnYWNjb3VudHMgbGlzdCByZWZyZXNoZWQnLCB7IGNvdW50OiBwYXJzZWQubGVuZ3RoIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdyZWZyZXNoIGFjY291bnRzIGZhaWxlZDsga2VlcGluZyBjdXJyZW50IGxpc3QnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbi8vIC0tLSBTdGF0ZSBicm9hZGNhc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gYnJvYWRjYXN0U3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgYnVpbGRTdGF0ZSgpO1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIHJldHVybiB7XG4gICAgdmVyc2lvbjogRVhUX1ZFUlNJT04sXG4gICAgc2V0dGluZ3M6IHJlZGFjdFNldHRpbmdzKHNldHRpbmdzKSxcbiAgICBjb25uZWN0aW9uOiBjb25uLFxuICAgIGFjY291bnRzLFxuICAgIGNvdW50ZXJzLFxuICB9O1xufVxuXG5mdW5jdGlvbiByZWRhY3RTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IEV4dGVuc2lvblN0YXRlWydzZXR0aW5ncyddIHtcbiAgcmV0dXJuIHtcbiAgICBvd25lcjogcy5vd25lcixcbiAgICByZXBvOiBzLnJlcG8sXG4gICAgYnJhbmNoOiBzLmJyYW5jaCxcbiAgICBhdXRvQ2FwdHVyZTogcy5hdXRvQ2FwdHVyZSxcbiAgICBjb25maWd1cmVkQXQ6IHMuY29uZmlndXJlZEF0LFxuICAgIHBhdFNldDogcy5wYXQubGVuZ3RoID4gMCxcbiAgICBwYXRTdWZmaXg6IHMucGF0Lmxlbmd0aCA+PSA0ID8gcy5wYXQuc2xpY2UoLTQpIDogJycsXG4gIH07XG59XG5cbmZ1bmN0aW9uIGlzb0NvbXBhY3QoaXNvOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyAyMDI1LTA0LTEyVDE0OjIzOjAxLjAwMFogXHUyMTkyIDIwMjUtMDQtMTJUMTQyMzAxWlxuICBjb25zdCBkID0gbmV3IERhdGUoaXNvKTtcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBpc28ucmVwbGFjZSgvWzouXS9nLCAnJyk7XG4gIGNvbnN0IHBhZCA9IChuOiBudW1iZXIsIHcgPSAyKSA9PiBTdHJpbmcobikucGFkU3RhcnQodywgJzAnKTtcbiAgcmV0dXJuIChcbiAgICBgJHtkLmdldFVUQ0Z1bGxZZWFyKCl9LSR7cGFkKGQuZ2V0VVRDTW9udGgoKSArIDEpfS0ke3BhZChkLmdldFVUQ0RhdGUoKSl9YCArXG4gICAgYFQke3BhZChkLmdldFVUQ0hvdXJzKCkpfSR7cGFkKGQuZ2V0VVRDTWludXRlcygpKX0ke3BhZChkLmdldFVUQ1NlY29uZHMoKSl9WmBcbiAgKTtcbn1cblxuZnVuY3Rpb24gdmlld2VyVXJsKHM6IFNldHRpbmdzKTogc3RyaW5nIHtcbiAgcmV0dXJuIGBodHRwczovLyR7cy5vd25lcn0uZ2l0aHViLmlvLyR7cy5yZXBvfS9gO1xufVxuXG5mdW5jdGlvbiBzaG9ydGVuVXJsKHU6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIEFjdGl2aXR5LXRhaWwgY29udGV4dCBpcyBtb3JlIHVzZWZ1bCB3aXRoIGp1c3QgdGhlIHBhdGg7IGZ1bGwgVVJMcyBiZWNvbWVcbiAgLy8gaGFyZCB0byByZWFkIGF0IHRoZSBzaWRlYmFyJ3Mgd2lkdGguXG4gIHRyeSB7XG4gICAgY29uc3QgcGFyc2VkID0gbmV3IFVSTCh1KTtcbiAgICBjb25zdCBwYXRoID0gcGFyc2VkLnBhdGhuYW1lICsgKHBhcnNlZC5zZWFyY2ggPyAnP1x1MjAyNicgOiAnJyk7XG4gICAgcmV0dXJuIHBhcnNlZC5ob3N0ID09PSAneC5jb20nIHx8IHBhcnNlZC5ob3N0ID09PSAndHdpdHRlci5jb20nXG4gICAgICA/IHBhdGhcbiAgICAgIDogYCR7cGFyc2VkLmhvc3R9JHtwYXRofWA7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiB1Lmxlbmd0aCA+IDgwID8gYCR7dS5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHU7XG4gIH1cbn1cblxuLy8gLS0tIERldiBoZWxwZXJzIGV4cG9zZWQgb24gZ2xvYmFsVGhpcyBmb3IgdGhlIGRldnRvb2xzIGNvbnNvbGUgLS0tLS0tLS0tLVxuLy8gKGUuZy4gYF9faW1tQXJjaGl2ZS5jbGVhckFsbCgpYCBpbiB0aGUgYmFja2dyb3VuZCB3b3JrZXIncyBkZXZ0b29scykuXG5cbihnbG9iYWxUaGlzIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5fX2ltbUFyY2hpdmUgPSB7XG4gIGNsZWFyQWxsLFxuICBhY3Rpdml0eTogZ2V0QWN0aXZpdHksXG4gIGFjY291bnRzOiBnZXRBY2NvdW50cyxcbiAgYnVmZmVyczogZ2V0UnVuQnVmZmVycyxcbiAgZmx1c2hBbGw6ICgpID0+IGZsdXNoQWxsKCdkZXZ0b29scycpLFxuICBzdGF0ZTogYnVpbGRTdGF0ZSxcbn07XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRU8sSUFBTSxtQkFBNkI7QUFBQSxFQUN4QyxLQUFLO0FBQUEsRUFDTCxPQUFPO0FBQUEsRUFDUCxNQUFNO0FBQUEsRUFDTixRQUFRO0FBQUEsRUFDUixhQUFhO0FBQUEsRUFDYixjQUFjO0FBQ2hCO0FBSU8sSUFBTSxvQkFBcUM7QUFBQSxFQUNoRCxFQUFFLFFBQVEsVUFBVSxPQUFPLGtDQUFrQztBQUFBLEVBQzdELEVBQUUsUUFBUSxVQUFVLE9BQU8sMkNBQTJDO0FBQUEsRUFDdEUsRUFBRSxRQUFRLE9BQU8sT0FBTyxxQ0FBcUM7QUFBQSxFQUM3RCxFQUFFLFFBQVEsU0FBUyxPQUFPLDRDQUE0QztBQUFBLEVBQ3RFLEVBQUUsUUFBUSxjQUFjLE9BQU8sa0JBQWtCO0FBQUEsRUFDakQsRUFBRSxRQUFRLFlBQVksT0FBTyw4QkFBOEI7QUFBQSxFQUMzRCxFQUFFLFFBQVEsU0FBUyxPQUFPLGlDQUFpQztBQUFBLEVBQzNELEVBQUUsUUFBUSxTQUFTLE9BQU8sMkJBQTJCO0FBQ3ZEO0FBR08sSUFBTSxrQkFBdUMsb0JBQUksSUFBSTtBQUFBLEVBQzFEO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBSU0sSUFBTSxvQkFBeUMsb0JBQUksSUFBSSxDQUFDLG9CQUFvQixjQUFjLENBQUM7QUFHM0YsSUFBTSx3QkFBd0I7QUFHOUIsSUFBTSxnQkFBZ0I7QUFHdEIsSUFBTSxzQkFBc0I7QUFHNUIsSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLO0FBRWhELElBQU0sbUJBQW1COzs7QUN4QmhDLElBQU0scUJBQXNDO0FBQUEsRUFDMUMsUUFBUTtBQUFBLEVBQ1IsT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUNUO0FBRUEsSUFBTSxXQUF5QjtBQUFBLEVBQzdCLFVBQVUsRUFBRSxHQUFHLGlCQUFpQjtBQUFBLEVBQ2hDLFVBQVUsQ0FBQyxHQUFHLGlCQUFpQjtBQUFBLEVBQy9CLFlBQVksRUFBRSxHQUFHLG1CQUFtQjtBQUFBLEVBQ3BDLFVBQVUsQ0FBQztBQUFBLEVBQ1gsWUFBWSxDQUFDO0FBQUEsRUFDYixVQUFVLENBQUM7QUFDYjtBQUVBLGVBQWUsT0FBcUMsS0FBa0M7QUFDcEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxHQUFHO0FBQ2xELFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsTUFBSSxVQUFVLFFBQVc7QUFDdkIsV0FBTyxnQkFBZ0IsU0FBUyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUNBLFNBQU87QUFDVDtBQUVBLGVBQWUsT0FBcUMsS0FBUSxPQUF1QztBQUNqRyxRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUM7QUFDbEQ7QUFJQSxlQUFzQixjQUFpQztBQUNyRCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQVksR0FBNEI7QUFDNUQsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUM1QjtBQUNBLGVBQXNCLGVBQWUsT0FBNkM7QUFDaEYsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE9BQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hDLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFNBQU87QUFDVDtBQUlBLGVBQXNCLGNBQXdDO0FBQzVELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFBWSxHQUFtQztBQUNuRSxRQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzVCO0FBSUEsZUFBc0IsZ0JBQTBDO0FBQzlELFNBQU8sT0FBTyxZQUFZO0FBQzVCO0FBQ0EsZUFBc0IsY0FBYyxHQUFtQztBQUNyRSxRQUFNLE9BQU8sY0FBYyxDQUFDO0FBQzlCO0FBSUEsU0FBUyxXQUFtQjtBQUMxQixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDN0M7QUFFQSxlQUFzQixjQUF1RDtBQUMzRSxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQ3BCLFFBQ0EsT0FDeUI7QUFDekIsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUs7QUFBQSxJQUN6QixZQUFZO0FBQUEsSUFDWixXQUFXLFNBQVM7QUFBQSxJQUNwQixlQUFlO0FBQUEsSUFDZixnQkFBZ0I7QUFBQSxJQUNoQixlQUFlO0FBQUEsRUFDakI7QUFDQSxNQUFJLElBQUksY0FBYyxTQUFTLEdBQUc7QUFDaEMsUUFBSSxZQUFZLFNBQVM7QUFDekIsUUFBSSxhQUFhO0FBQUEsRUFDbkI7QUFDQSxRQUFNLE9BQXVCLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoRCxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsaUJBQWlCLFFBQWdCLE9BQThCO0FBQ25GLFFBQU0sWUFBWSxRQUFRLEVBQUUsZUFBZSxNQUFNLENBQUM7QUFDcEQ7QUFJQSxlQUFzQixnQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLFlBQVk7QUFDNUI7QUFFQSxlQUFzQixhQUFhLFFBQTJDO0FBQzVFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU0sS0FBSztBQUN4QjtBQUVBLGVBQXNCLGFBQWEsUUFBZ0IsS0FBK0I7QUFDaEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFFQSxlQUFzQixlQUFlLFFBQStCO0FBQ2xFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU07QUFDakIsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUlBLGVBQXNCLGNBQW1DO0FBQ3ZELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBRUEsZUFBc0IsZUFBZSxJQUFtQztBQUN0RSxRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLE1BQUksUUFBUSxFQUFFO0FBQ2QsTUFBSSxJQUFJLFNBQVMsa0JBQW1CLEtBQUksU0FBUztBQUNqRCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGdCQUErQjtBQUNuRCxRQUFNLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDN0I7QUFJQSxlQUFzQixXQUEwQjtBQUM5QyxRQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU07QUFDcEM7OztBQzlLQSxJQUFJLFlBQTZDO0FBRTFDLFNBQVMsZUFBZSxJQUFrQztBQUMvRCxjQUFZO0FBQ2Q7QUFFQSxTQUFTLFNBQWlCO0FBQ3hCLFVBQU8sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDaEM7QUFFQSxlQUFlLEtBQUssT0FBaUIsS0FBYSxTQUFpRDtBQUNqRyxRQUFNLEtBQWUsRUFBRSxJQUFJLE9BQU8sR0FBRyxPQUFPLEtBQUssU0FBUyxPQUFPLE9BQU8sRUFBRTtBQUUxRSxRQUFNLE9BQU8saUJBQWlCLE1BQU0sWUFBWSxDQUFDLElBQUksR0FBRztBQUN4RCxNQUFJLFVBQVUsUUFBUyxTQUFRLE1BQU0sTUFBTSxHQUFHLE9BQU87QUFBQSxXQUM1QyxVQUFVLE9BQVEsU0FBUSxLQUFLLE1BQU0sR0FBRyxPQUFPO0FBQUEsTUFDbkQsU0FBUSxJQUFJLE1BQU0sR0FBRyxPQUFPO0FBRWpDLE1BQUk7QUFDRixVQUFNLGVBQWUsRUFBRTtBQUFBLEVBQ3pCLFNBQVMsS0FBSztBQUNaLFlBQVEsS0FBSywyQ0FBMkMsR0FBRztBQUFBLEVBQzdEO0FBRUEsTUFBSTtBQUNGLGdCQUFZLEVBQUU7QUFBQSxFQUNoQixRQUFRO0FBQUEsRUFFUjtBQUNGO0FBRU8sU0FBUyxLQUFLLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN0RixTQUFPLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDbEM7QUFDTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsTUFBTSxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdkYsU0FBTyxLQUFLLFNBQVMsS0FBSyxPQUFPO0FBQ25DO0FBRU8sU0FBUyxjQUFjLEtBQXlEO0FBQ3JGLE1BQUksZUFBZSxPQUFPO0FBQ3hCLFdBQU8sRUFBRSxTQUFTLElBQUksU0FBUyxPQUFPLElBQUksU0FBUyxLQUFLO0FBQUEsRUFDMUQ7QUFDQSxNQUFJO0FBQ0YsV0FBTyxFQUFFLFNBQVMsT0FBTyxHQUFHLEdBQUcsT0FBTyxLQUFLO0FBQUEsRUFDN0MsUUFBUTtBQUNOLFdBQU8sRUFBRSxTQUFTLHVCQUF1QixPQUFPLEtBQUs7QUFBQSxFQUN2RDtBQUNGO0FBT0EsU0FBUyxPQUFPLEtBQXVEO0FBQ3JFLFFBQU0sTUFBK0IsQ0FBQztBQUN0QyxhQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUN4QyxRQUFJLEVBQUUsWUFBWSxFQUFFLFNBQVMsT0FBTyxLQUFLLEVBQUUsWUFBWSxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7QUFDM0YsVUFBSSxDQUFDLElBQUk7QUFBQSxJQUNYLFdBQVcsT0FBTyxNQUFNLFlBQVksK0JBQStCLEtBQUssQ0FBQyxHQUFHO0FBQzFFLFVBQUksQ0FBQyxJQUFJLEVBQUUsUUFBUSw2QkFBNkIsdUJBQXVCO0FBQUEsSUFDekUsV0FBVyxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsTUFBTTtBQUNuRCxVQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsTUFBTSxHQUFHLElBQUksQ0FBQztBQUFBLElBQzlCLE9BQU87QUFDTCxVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1g7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUOzs7QUN2RUEsSUFBTSxXQUFXO0FBQ2pCLElBQU0sV0FBVztBQWVWLElBQU0sY0FBTixjQUEwQixNQUFNO0FBQUEsRUFDckM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUVBLFlBQVksTUFNVDtBQUNELFVBQU0sS0FBSyxPQUFPO0FBQ2xCLFNBQUssT0FBTztBQUNaLFNBQUssU0FBUyxLQUFLO0FBQ25CLFNBQUssT0FBTyxLQUFLO0FBQ2pCLFNBQUssWUFBWSxLQUFLO0FBQ3RCLFNBQUssV0FBVyxLQUFLO0FBQUEsRUFDdkI7QUFDRjtBQUVPLElBQU0sZUFBTixNQUFtQjtBQUFBLEVBQ1A7QUFBQSxFQUVqQixZQUFZLFVBQW9CO0FBQzlCLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUE7QUFBQSxFQUdBLE1BQU0sU0FBMEI7QUFDOUIsVUFBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTztBQUMvQyxXQUFRLElBQTJCLFNBQVM7QUFBQSxFQUM5QztBQUFBO0FBQUEsRUFHQSxNQUFNLG1CQUEwRjtBQUM5RixVQUFNLEtBQUssTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQzlDLFVBQU0sT0FBTyxNQUFNLEtBQUssVUFBVSxPQUFPLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxFQUFFO0FBQzlGLFVBQU0sSUFBSTtBQUNWLFdBQU87QUFBQSxNQUNMLE9BQVEsR0FBeUI7QUFBQSxNQUNqQyxXQUFXLEVBQUU7QUFBQSxNQUNiLGdCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sYUFBYSxZQUE0QztBQUM3RCxVQUFNLE1BQU0sR0FBRyxRQUFRLElBQUksS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssU0FBUyxNQUFNLElBQUksVUFBVTtBQUMxRyxVQUFNLE1BQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxNQUMzQixRQUFRO0FBQUEsTUFDUixTQUFTLEVBQUUsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFBQSxJQUMxRCxDQUFDO0FBQ0QsUUFBSSxJQUFJLFdBQVcsSUFBSyxRQUFPO0FBQy9CLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxNQUFNLEtBQUssVUFBVSxLQUFLLFdBQVcsVUFBVSxFQUFFO0FBQ3BFLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxXQUFXLE1BQXNDO0FBQ3JELFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsUUFDckI7QUFBQSxRQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDLFFBQVEsbUJBQW1CLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxNQUNsSTtBQUNBLFlBQU0sSUFBSTtBQUNWLGFBQU8sRUFBRSxPQUFPO0FBQUEsSUFDbEIsU0FBUyxLQUFLO0FBQ1osVUFBSSxlQUFlLGVBQWUsSUFBSSxhQUFhLFlBQWEsUUFBTztBQUN2RSxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxNQUFNLFFBQVEsTUFBOEM7QUFDMUQsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxNQUFNLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDO0FBQzVGLFFBQUksTUFBcUIsS0FBSyxlQUFlO0FBQzdDLFVBQU0sY0FBYztBQUVwQixhQUFTLFVBQVUsR0FBRyxXQUFXLGFBQWEsV0FBVztBQUN2RCxZQUFNLE9BQWdDO0FBQUEsUUFDcEMsU0FBUyxLQUFLO0FBQUEsUUFDZCxTQUFTLEtBQUs7QUFBQSxRQUNkLFFBQVEsS0FBSyxTQUFTO0FBQUEsTUFDeEI7QUFDQSxVQUFJLElBQUssTUFBSyxNQUFNO0FBQ3BCLFVBQUk7QUFDRixjQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxLQUFLLElBQUk7QUFDakQsY0FBTSxNQUFNO0FBQ1osZUFBTyxFQUFFLE1BQU0sSUFBSSxRQUFRLE1BQU0sS0FBSyxJQUFJLFFBQVEsS0FBSyxLQUFLLElBQUksUUFBUSxTQUFTO0FBQUEsTUFDbkYsU0FBUyxLQUFLO0FBQ1osWUFBSSxFQUFFLGVBQWUsYUFBYyxPQUFNO0FBQ3pDLFlBQUksSUFBSSxXQUFXLE9BQU8sQ0FBQyxLQUFLO0FBRTlCLGdCQUFNLE1BQU0sS0FBSyxXQUFXLElBQUk7QUFDaEMsY0FBSSxDQUFDLElBQUssT0FBTTtBQUNoQjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLENBQUMsSUFBSSxhQUFhLFlBQVksWUFBYSxPQUFNO0FBQ3JELGNBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxJQUFJLE1BQU0sbUNBQW1DLElBQUksRUFBRTtBQUFBLEVBQzNEO0FBQUEsRUFFQSxNQUFjLFVBQVUsUUFBZ0IsTUFBYyxNQUFrQztBQUN0RixVQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU0sSUFBSSxPQUFPLEdBQUcsUUFBUSxHQUFHLElBQUk7QUFDL0QsVUFBTSxPQUFvQjtBQUFBLE1BQ3hCO0FBQUEsTUFDQSxTQUFTO0FBQUEsUUFDUCxlQUFlLFVBQVUsS0FBSyxTQUFTLEdBQUc7QUFBQSxRQUMxQyxRQUFRO0FBQUEsUUFDUix3QkFBd0I7QUFBQSxRQUN4QixHQUFJLE9BQU8sRUFBRSxnQkFBZ0IsbUJBQW1CLElBQUksQ0FBQztBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxHQUFJLE9BQU8sRUFBRSxNQUFNLEtBQUssVUFBVSxJQUFJLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDL0M7QUFDQSxRQUFJO0FBQ0osUUFBSTtBQUNGLFlBQU0sTUFBTSxNQUFNLEtBQUssSUFBSTtBQUFBLElBQzdCLFNBQVMsUUFBUTtBQUNmLFlBQU0sSUFBSSxZQUFZO0FBQUEsUUFDcEIsUUFBUTtBQUFBLFFBQ1IsTUFBTTtBQUFBLFFBQ04sU0FBUyxZQUFZLGNBQWMsTUFBTSxFQUFFLE9BQU87QUFBQSxRQUNsRCxXQUFXO0FBQUEsUUFDWCxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLFNBQWtCO0FBQ3RCLFVBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixRQUFJLE1BQU07QUFDUixVQUFJO0FBQ0YsaUJBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxNQUMxQixRQUFRO0FBQ04saUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxNQUFNLEtBQUssb0JBQW9CLEtBQUssUUFBUSxHQUFHLE1BQU0sSUFBSSxJQUFJLEVBQUU7QUFDbEYsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE1BQWMsVUFBVSxLQUFlLE9BQXFDO0FBQzFFLFFBQUksU0FBa0I7QUFDdEIsUUFBSTtBQUNGLFlBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixVQUFJLEtBQU0sVUFBUyxLQUFLLE1BQU0sSUFBSTtBQUFBLElBQ3BDLFFBQVE7QUFBQSxJQUVSO0FBQ0EsV0FBTyxLQUFLLG9CQUFvQixLQUFLLFFBQVEsS0FBSztBQUFBLEVBQ3BEO0FBQUEsRUFFUSxvQkFBb0IsS0FBZSxNQUFlLE9BQTRCO0FBQ3BGLFVBQU0sTUFDSixPQUFPLFNBQVMsWUFBWSxRQUFRLGFBQWEsT0FDN0MsT0FBUSxLQUE4QixPQUFPLElBQzdDLElBQUk7QUFDVixRQUFJLFdBQW9DO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0FBRTVDLFlBQU0sT0FBTyxJQUFJLFFBQVEsSUFBSSx1QkFBdUI7QUFDcEQsVUFBSSxTQUFTLE9BQU8sY0FBYyxLQUFLLEdBQUcsR0FBRztBQUMzQyxtQkFBVztBQUNYLG9CQUFZO0FBQUEsTUFDZCxPQUFPO0FBQ0wsbUJBQVc7QUFBQSxNQUNiO0FBQUEsSUFDRixXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQUEsSUFDYixXQUFXLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0FBQ25ELGlCQUFXO0FBQUEsSUFDYixXQUFXLElBQUksVUFBVSxLQUFLO0FBQzVCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkLFdBQVcsSUFBSSxXQUFXLEtBQUs7QUFDN0IsaUJBQVc7QUFDWCxrQkFBWTtBQUFBLElBQ2Q7QUFDQSxXQUFPLElBQUksWUFBWTtBQUFBLE1BQ3JCLFFBQVEsSUFBSTtBQUFBLE1BQ1o7QUFBQSxNQUNBLFNBQVMsR0FBRyxLQUFLLFdBQU0sSUFBSSxNQUFNLEtBQUssR0FBRztBQUFBLE1BQ3pDO0FBQUEsTUFDQTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQUVBLFNBQVMsV0FBVyxNQUFzQjtBQUV4QyxTQUFPLEtBQUssTUFBTSxHQUFHLEVBQUUsSUFBSSxrQkFBa0IsRUFBRSxLQUFLLEdBQUc7QUFDekQ7QUFFQSxTQUFTLFVBQVUsU0FBaUIsS0FBMEI7QUFFNUQsUUFBTSxPQUFPLElBQUksYUFBYSxlQUFlLE1BQU87QUFDcEQsUUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFHO0FBQzdDLFNBQU8sS0FBSyxJQUFJLEtBQVEsT0FBTyxNQUFNLFVBQVUsS0FBSyxNQUFNO0FBQzVEO0FBRUEsU0FBUyxNQUFNLElBQTJCO0FBQ3hDLFNBQU8sSUFBSSxRQUFRLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQzdDO0FBRU8sU0FBUyxTQUFTLE9BQXVCO0FBRTlDLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEtBQUs7QUFDM0MsTUFBSSxNQUFNO0FBQ1YsYUFBVyxLQUFLLEtBQU0sUUFBTyxPQUFPLGFBQWEsQ0FBQztBQUNsRCxTQUFPLEtBQUssR0FBRztBQUNqQjs7O0FDMU5PLFNBQVMsVUFBVSxTQUFrQixLQUF3QztBQUNsRixRQUFNLFlBQVksY0FBYyxPQUFPO0FBQ3ZDLFFBQU0sU0FBMkIsQ0FBQztBQUNsQyxRQUFNLFdBQXFCLENBQUM7QUFDNUIsYUFBVyxPQUFPLFdBQVc7QUFDM0IsUUFBSTtBQUNGLFlBQU0sSUFBSSxXQUFXLEtBQUssR0FBRztBQUM3QixVQUFJLENBQUMsRUFBRztBQUNSLGVBQVMsS0FBSyxFQUFFLFFBQVE7QUFDeEIsVUFBSSxJQUFJLGVBQWUsU0FBUyxLQUFLLElBQUksZUFBZSxJQUFJLEVBQUUsZUFBZSxZQUFZLENBQUMsR0FBRztBQUMzRixlQUFPLEtBQUssQ0FBQztBQUFBLE1BQ2Y7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUVSO0FBQUEsRUFDRjtBQUNBLFNBQU8sRUFBRSxRQUFRLGNBQWMsU0FBUztBQUMxQztBQUVBLFNBQVMsY0FBY0EsTUFBeUI7QUFLOUMsUUFBTSxNQUFpQixDQUFDO0FBQ3hCLFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUNBLElBQUc7QUFDN0IsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE9BQU8sTUFBTSxJQUFJO0FBQ3ZCLFFBQUksU0FBUyxRQUFRLFNBQVMsT0FBVztBQUN6QyxRQUFJLE9BQU8sU0FBUyxTQUFVO0FBQzlCLFFBQUksS0FBSyxJQUFJLElBQWMsRUFBRztBQUM5QixTQUFLLElBQUksSUFBYztBQUV2QixRQUFJLGVBQWUsSUFBSSxHQUFHO0FBQ3hCLFVBQUksS0FBSyxZQUFZLElBQUksQ0FBQztBQUFBLElBQzVCO0FBQ0EsUUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGlCQUFXLEtBQUssS0FBTSxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ3BDLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxJQUErQixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDOUU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxlQUFlLE1BQWdEO0FBQ3RFLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsUUFBTSxXQUFXLEVBQUU7QUFDbkIsTUFDRSxhQUFhLFdBQ2IsYUFBYSxnQ0FDYixhQUFhLGtCQUNiO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUFPLE9BQU8sRUFBRSxZQUFZLFlBQVksT0FBTyxFQUFFLFdBQVcsWUFBWSxFQUFFLFdBQVc7QUFDdkY7QUFFQSxTQUFTLFlBQVksTUFBd0Q7QUFDM0UsTUFBSSxLQUFLLGVBQWUsZ0NBQWdDLE9BQU8sS0FBSyxVQUFVLFVBQVU7QUFDdEYsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxLQUFjLEtBQThDO0FBQzlFLE1BQUksT0FBTyxRQUFRLFlBQVksUUFBUSxLQUFNLFFBQU87QUFDcEQsUUFBTSxJQUFJO0FBRVYsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFFOUMsUUFBTSxTQUFTLFVBQVUsRUFBRSxPQUFPO0FBQ2xDLFFBQU0sU0FBUyxJQUFJLEVBQUUsTUFBTTtBQUMzQixNQUFJLENBQUMsVUFBVSxDQUFDLE9BQVEsUUFBTztBQUUvQixRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksSUFBSSxNQUFNLFlBQVksR0FBRyxNQUFNO0FBQ3RELFFBQU0sYUFBYSxJQUFJLFlBQVksTUFBTTtBQUN6QyxRQUFNLFNBQVMsVUFBVSxZQUFZLFdBQVc7QUFDaEQsUUFBTSxZQUFZLFVBQVUsWUFBWSxPQUFPLEtBQUssVUFBVSxPQUFPLFdBQVc7QUFDaEYsTUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFXLFFBQU87QUFFbEMsUUFBTSxZQUFZLElBQUksSUFBSSxJQUFJLEVBQUUsVUFBVSxHQUFHLGtCQUFrQixHQUFHLE1BQU07QUFDeEUsUUFBTSxlQUFlLFVBQVUsV0FBVyxJQUFJO0FBQzlDLFFBQU0saUJBQWlCLFVBQVUsT0FBTyxTQUFTLEtBQUs7QUFDdEQsUUFBTSxPQUFPLGdCQUFnQjtBQUU3QixRQUFNLFdBQVcsSUFBSSxPQUFPLFFBQVEsS0FBSyxDQUFDO0FBQzFDLFFBQU0sbUJBQW1CLElBQUksV0FBVyxVQUFVO0FBQ2xELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxXQUFXLGdCQUFnQixvQkFBb0IsUUFBUTtBQUM3RCxRQUFNLE9BQU8sWUFBWSxvQkFBb0IsUUFBUTtBQUNyRCxRQUFNLFFBQVEsYUFBYSxNQUFNO0FBRWpDLFFBQU0sWUFBWSxrQkFBa0IsR0FBRyxNQUFNO0FBRTdDLFFBQU0sV0FBVyxpQkFBaUIsVUFBVSxPQUFPLFVBQVUsQ0FBQztBQUM5RCxNQUFJLENBQUMsU0FBVSxRQUFPO0FBRXRCLFFBQU0sUUFBUSxJQUFJLEVBQUUsS0FBSztBQUN6QixRQUFNLFlBQVksVUFBVSxPQUFPLEtBQUssS0FBSyxVQUFVLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFFOUUsUUFBTSxRQUF3QjtBQUFBLElBQzVCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLFdBQVc7QUFBQSxJQUNYLG1CQUFtQixJQUFJO0FBQUEsSUFDdkIsY0FBYyxJQUFJO0FBQUEsSUFDbEIsc0JBQXNCO0FBQUEsSUFDdEIsV0FBVyxHQUFHLGdCQUFnQixJQUFJLE1BQU0sV0FBVyxNQUFNO0FBQUEsSUFDekQsWUFBWTtBQUFBLElBQ1osbUJBQW1CLFVBQVUsT0FBTyx5QkFBeUI7QUFBQSxJQUM3RCxrQkFBa0IsVUFBVSxPQUFPLHVCQUF1QjtBQUFBLElBQzFELGlCQUFpQixVQUFVLE9BQU8sb0JBQW9CO0FBQUEsSUFDdEQsb0JBQW9CO0FBQUEsTUFDbEIsSUFBSSxJQUFJLE9BQU8sdUJBQXVCLEdBQUcsTUFBTSxHQUFHLFdBQy9DLE9BQW1DO0FBQUEsSUFDeEM7QUFBQSxJQUNBO0FBQUEsSUFDQSxlQUFlLGlCQUFpQixNQUFNLElBQUk7QUFBQSxJQUMxQyxNQUFNLFVBQVUsT0FBTyxJQUFJO0FBQUEsSUFDM0I7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVksVUFBVSxPQUFPLGNBQWM7QUFBQSxJQUMzQyxlQUFlLFVBQVUsT0FBTyxhQUFhO0FBQUEsSUFDN0MsYUFBYSxVQUFVLE9BQU8sV0FBVztBQUFBLElBQ3pDLGFBQWEsVUFBVSxPQUFPLFdBQVc7QUFBQSxJQUN6QyxZQUFZO0FBQUEsSUFDWixnQkFBZ0IsVUFBVSxPQUFPLGNBQWM7QUFBQSxJQUMvQyxvQkFBb0I7QUFBQSxNQUNsQjtBQUFBLFFBQ0UsYUFBYSxJQUFJO0FBQUEsUUFDakIsT0FBTyxVQUFVLE9BQU8sY0FBYztBQUFBLFFBQ3RDLFVBQVUsVUFBVSxPQUFPLGFBQWE7QUFBQSxRQUN4QyxTQUFTLFVBQVUsT0FBTyxXQUFXO0FBQUEsUUFDckMsUUFBUSxVQUFVLE9BQU8sV0FBVztBQUFBLFFBQ3BDLE9BQU87QUFBQSxRQUNQLFdBQVcsVUFBVSxPQUFPLGNBQWM7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFBQSxJQUNBLGFBQWE7QUFBQSxJQUNiLHNCQUFzQjtBQUFBLElBQ3RCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsRUFDbEI7QUFFQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGtCQUFrQixHQUE0QixRQUE0QztBQUNqRyxNQUFJLE9BQU8sMkJBQTJCLE9BQU8sd0JBQXlCLFFBQU87QUFDN0UsTUFBSSxPQUFPLDBCQUEyQixRQUFPO0FBQzdDLE1BQUksT0FBTyxvQkFBb0IsUUFBUSxPQUFPLHFCQUFzQixRQUFPO0FBQzNFLE1BQUksRUFBRSxlQUFlLDhCQUE4QjtBQUFBLEVBRW5EO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxnQkFBZ0IsVUFBNkM7QUFDcEUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFNBQU8sSUFDSjtBQUFBLElBQUksQ0FBQyxNQUNKLE9BQU8sTUFBTSxZQUFZLEtBQUssVUFBVSxJQUFJLE9BQVEsRUFBd0IsSUFBSSxJQUFJO0FBQUEsRUFDdEYsRUFDQyxPQUFPLENBQUMsTUFBbUIsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLENBQUM7QUFDckU7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsSUFDM0MsT0FBUSxFQUErQixXQUFXLElBQ2xEO0FBQUEsRUFDTixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsWUFBWSxVQUFnRDtBQUNuRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsUUFBTSxNQUFtQixDQUFDO0FBQzFCLGFBQVcsS0FBSyxLQUFLO0FBQ25CLFFBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFVBQU0sSUFBSTtBQUNWLFVBQU0sUUFBUSxVQUFVLEVBQUUsR0FBRztBQUM3QixVQUFNLFdBQVcsVUFBVSxFQUFFLFlBQVk7QUFDekMsVUFBTSxVQUFVLFVBQVUsRUFBRSxXQUFXO0FBQ3ZDLFFBQUksQ0FBQyxTQUFTLENBQUMsU0FBVTtBQUN6QixRQUFJLEtBQUssRUFBRSxPQUFPLFVBQVUsU0FBUyxXQUFXLFNBQVMsQ0FBQztBQUFBLEVBQzVEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLFFBQThDO0FBQ2xFLFFBQU0sV0FBVyxJQUFJLE9BQU8saUJBQWlCO0FBQzdDLFFBQU0sVUFBVSxXQUFXLFFBQVEsU0FBUyxLQUFLLElBQUksQ0FBQztBQUN0RCxRQUFNLFVBQVUsUUFBUSxJQUFJLE9BQU8sUUFBUSxHQUFHLEtBQUs7QUFDbkQsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxTQUFTLENBQUMsR0FBRyxTQUFTLEdBQUcsT0FBTyxFQUFFLE9BQU8sQ0FBQyxNQUFNO0FBQ3BELFFBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNLFFBQU87QUFDaEQsVUFBTSxLQUNKLFVBQVcsRUFBOEIsU0FBUyxLQUNsRCxVQUFXLEVBQThCLE1BQU07QUFDakQsUUFBSSxDQUFDLEdBQUksUUFBTztBQUNoQixRQUFJLEtBQUssSUFBSSxFQUFFLEVBQUcsUUFBTztBQUN6QixTQUFLLElBQUksRUFBRTtBQUNYLFdBQU87QUFBQSxFQUNULENBQUM7QUFDRCxTQUFPLE9BQU8sSUFBSSxDQUFDLFFBQVEsV0FBVyxHQUE4QixDQUFDO0FBQ3ZFO0FBRUEsU0FBUyxXQUFXLEdBQXVDO0FBQ3pELFFBQU0sT0FBTyxVQUFVLEVBQUUsSUFBSTtBQUM3QixRQUFNLFdBQVcsZ0JBQWdCLEdBQUcsSUFBSTtBQUN4QyxRQUFNQyxRQUFPLElBQUksRUFBRSxhQUFhO0FBQ2hDLFFBQU0sWUFBWSxJQUFJLEVBQUUsVUFBVTtBQUNsQyxRQUFNLGFBQWEsVUFBVSxXQUFXLGVBQWU7QUFDdkQsUUFBTSxVQUFVLFVBQVUsRUFBRSxZQUFZO0FBQ3hDLFFBQU0sVUFDSixVQUFVLEVBQUUsU0FBUyxLQUNyQixVQUFVLEVBQUUsTUFBTSxLQUNsQixHQUFHLFFBQVEsT0FBTyxJQUFJLEtBQUssT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQzNELFNBQU87QUFBQSxJQUNMLFVBQVU7QUFBQSxJQUNWLFlBQWEsUUFBUTtBQUFBLElBQ3JCLGNBQWMsWUFBWTtBQUFBLElBQzFCLG1CQUFtQjtBQUFBLElBQ25CLFFBQVE7QUFBQSxJQUNSLE9BQU87QUFBQSxJQUNQLGNBQWMsZUFBZSxPQUFPLGFBQWEsTUFBTztBQUFBLElBQ3hELE9BQU8sVUFBVUEsT0FBTSxLQUFLO0FBQUEsSUFDNUIsUUFBUSxVQUFVQSxPQUFNLE1BQU07QUFBQSxJQUM5QixVQUFVO0FBQUEsSUFDVixnQkFBZ0I7QUFBQSxJQUNoQixrQkFBa0I7QUFBQSxJQUNsQixpQkFBaUI7QUFBQSxFQUNuQjtBQUNGO0FBRUEsU0FBUyxnQkFBZ0IsR0FBNEIsTUFBb0M7QUFDdkYsTUFBSSxTQUFTLFFBQVMsUUFBTyxVQUFVLEVBQUUsZUFBZSxLQUFLLFVBQVUsRUFBRSxTQUFTO0FBQ2xGLFFBQU0sV0FBVyxRQUFRLElBQUksRUFBRSxVQUFVLEdBQUcsUUFBUTtBQUNwRCxNQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sVUFBVSxFQUFFLGVBQWU7QUFFN0QsTUFBSSxPQUFnRDtBQUNwRCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLEtBQUssVUFBVSxFQUFFLFlBQVk7QUFDbkMsVUFBTSxNQUFNLFVBQVUsRUFBRSxHQUFHO0FBQzNCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsUUFBSSxPQUFPLGFBQWE7QUFDdEIsWUFBTSxLQUFLLFVBQVUsRUFBRSxPQUFPLEtBQUs7QUFDbkMsVUFBSSxDQUFDLFFBQVEsS0FBSyxLQUFLLFFBQVMsUUFBTyxFQUFFLEtBQUssU0FBUyxHQUFHO0FBQUEsSUFDNUQsV0FBVyxDQUFDLE1BQU07QUFFaEIsYUFBTyxFQUFFLEtBQUssU0FBUyxFQUFFO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0EsU0FBTyxNQUFNLE9BQU87QUFDdEI7QUFFQSxTQUFTLGlCQUFpQixNQUFjLE1BQTJCO0FBQ2pFLE1BQUksS0FBSyxXQUFXLEVBQUcsUUFBTztBQUM5QixNQUFJLE1BQU07QUFDVixhQUFXLEtBQUssS0FBTSxPQUFNLElBQUksTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUTtBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxNQUFJLENBQUMsRUFBRyxRQUFPO0FBRWYsUUFBTSxJQUFJLElBQUksS0FBSyxDQUFDO0FBQ3BCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTztBQUN0QyxTQUFPLEVBQUUsWUFBWTtBQUN2QjtBQUVBLFNBQVMsVUFBVSxHQUEyQjtBQUM1QyxTQUFPLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxJQUFJLElBQUk7QUFDckQ7QUFDQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFDeEQsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxVQUFNLElBQUksT0FBTyxDQUFDO0FBQ2xCLFFBQUksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQUEsRUFDakM7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFVBQVUsR0FBb0I7QUFDckMsU0FBTyxVQUFVLENBQUMsS0FBSztBQUN6QjtBQUNBLFNBQVMsSUFBSSxHQUE0QztBQUN2RCxTQUFPLE9BQU8sTUFBTSxZQUFZLE1BQU0sUUFBUSxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQ3pELElBQ0Q7QUFDTjtBQUNBLFNBQVMsUUFBUSxHQUF1QjtBQUN0QyxTQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDO0FBQ2pDOzs7QUN2VUEsSUFBTSxXQUFXO0FBRVYsU0FBUyxXQUFtQjtBQUNqQyxRQUFNLEtBQUssS0FBSyxJQUFJO0FBQ3BCLE1BQUksU0FBUztBQUNiLE1BQUksSUFBSTtBQUNSLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLGNBQVUsU0FBUyxJQUFJLEVBQUUsS0FBSyxPQUFPO0FBQ3JDLFFBQUksS0FBSyxNQUFNLElBQUksRUFBRTtBQUFBLEVBQ3ZCO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLEtBQU0sYUFBWSxTQUFTLElBQUksRUFBRSxLQUFLO0FBQ3RELFNBQU8sU0FBUztBQUNsQjtBQUVPLFNBQVMsV0FBVyxJQUFvQjtBQUM3QyxTQUFPLEdBQUcsTUFBTSxFQUFFO0FBQ3BCOzs7QUNYTyxTQUFTLGtCQUFrQixNQUErQjtBQUMvRCxRQUFNLFdBQTRCLENBQUM7QUFDbkMsTUFBSSxVQUFrQyxDQUFDO0FBQ3ZDLE1BQUksYUFBYTtBQUNqQixhQUFXLFdBQVcsS0FBSyxNQUFNLElBQUksR0FBRztBQUN0QyxVQUFNLE9BQU8sY0FBYyxPQUFPO0FBQ2xDLFFBQUksS0FBSyxLQUFLLE1BQU0sR0FBSTtBQUN4QixRQUFJLGdCQUFnQixLQUFLLElBQUksR0FBRztBQUM5QixtQkFBYTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxXQUFZO0FBRWpCLFVBQU0sWUFBWSxLQUFLLE1BQU0sNEJBQTRCO0FBQ3pELFFBQUksV0FBVztBQUNiLFVBQUksUUFBUSxVQUFVLFFBQVEsTUFBTyxVQUFTLEtBQUssT0FBd0I7QUFDM0UsZ0JBQVUsRUFBRSxRQUFRLFFBQVEsVUFBVSxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2hEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sd0JBQXdCO0FBQ3RELFFBQUksY0FBYyxDQUFDLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFDckMsVUFBSSxRQUFRLFVBQVUsUUFBUSxNQUFPLFVBQVMsS0FBSyxPQUF3QjtBQUMzRSxnQkFBVSxFQUFFLFFBQVEsUUFBUSxXQUFXLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDakQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx1QkFBdUI7QUFDckQsUUFBSSxjQUFjLFFBQVEsUUFBUTtBQUNoQyxjQUFRLFFBQVEsUUFBUSxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQzNDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFFBQVEsVUFBVSxRQUFRLE1BQU8sVUFBUyxLQUFLLE9BQXdCO0FBQzNFLFNBQU8sU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sU0FBUyxDQUFDO0FBQ25EO0FBRUEsU0FBUyxjQUFjLE1BQXNCO0FBRzNDLFFBQU0sTUFBTSxLQUFLLFFBQVEsR0FBRztBQUM1QixTQUFPLFFBQVEsS0FBSyxPQUFPLEtBQUssTUFBTSxHQUFHLEdBQUc7QUFDOUM7QUFFQSxTQUFTLFFBQVEsR0FBbUI7QUFDbEMsUUFBTSxVQUFVLEVBQUUsS0FBSztBQUN2QixNQUNHLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsS0FDL0MsUUFBUSxXQUFXLEdBQUcsS0FBSyxRQUFRLFNBQVMsR0FBRyxHQUNoRDtBQUNBLFdBQU8sUUFBUSxNQUFNLEdBQUcsRUFBRTtBQUFBLEVBQzVCO0FBQ0EsU0FBTztBQUNUOzs7QUNOQSxJQUFNLGNBQWMsUUFBUSxRQUFRLFlBQVksRUFBRTtBQUVsRCxlQUFlLENBQUMsT0FBaUI7QUFDL0IsVUFBUSxRQUFRLFlBQVksRUFBRSxNQUFNLGFBQWEsT0FBTyxHQUFHLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDOUUsQ0FBQztBQUlELFFBQVEsUUFBUSxZQUFZLFlBQVksWUFBWTtBQUNsRCxRQUFNLEtBQUssdUJBQXVCLEVBQUUsU0FBUyxZQUFZLENBQUM7QUFDMUQsUUFBTSxPQUFPLFNBQVM7QUFDeEIsQ0FBQztBQUVELFFBQVEsUUFBUSxVQUFVLFlBQVksTUFBTTtBQUMxQyxPQUFLLE9BQU8sU0FBUztBQUN2QixDQUFDO0FBR0QsS0FBSyxPQUFPLGFBQWE7QUFFekIsZUFBZSxPQUFPLFFBQStCO0FBQ25ELE1BQUk7QUFDRixVQUFNLGFBQWE7QUFDbkIsVUFBTSw0QkFBNEI7QUFDbEMsVUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFJLFNBQVMsT0FBTyxTQUFTLFNBQVMsU0FBUyxNQUFNO0FBQ25ELFlBQU0saUJBQWlCLEtBQUs7QUFDNUIsWUFBTSxvQkFBb0IsS0FBSztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTztBQUFBLE1BQ1QsQ0FBQztBQUNELFlBQU0sS0FBSyx3Q0FBd0MsRUFBRSxPQUFPLENBQUM7QUFBQSxJQUMvRDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFPLGVBQWUsRUFBRSxRQUFRLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQy9EO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLFFBQU0sUUFBUSxPQUFPLE1BQU0sYUFBYTtBQUN4QyxRQUFNLFFBQVEsT0FBTyxNQUFNLG1CQUFtQjtBQUM5QyxRQUFNLFFBQVEsT0FBTyxPQUFPLGVBQWUsRUFBRSxpQkFBaUIsb0JBQW9CLENBQUM7QUFDbkYsUUFBTSxRQUFRLE9BQU8sT0FBTyxxQkFBcUI7QUFBQSxJQUMvQyxpQkFBaUIsZ0NBQWdDO0FBQUEsRUFDbkQsQ0FBQztBQUNIO0FBRUEsUUFBUSxPQUFPLFFBQVEsWUFBWSxDQUFDLFVBQVU7QUFDNUMsTUFBSSxNQUFNLFNBQVMsZUFBZTtBQUNoQyxTQUFLLGlCQUFpQjtBQUFBLEVBQ3hCLFdBQVcsTUFBTSxTQUFTLHFCQUFxQjtBQUM3QyxTQUFLLGlCQUFpQixLQUFLO0FBQUEsRUFDN0I7QUFDRixDQUFDO0FBSUQsSUFBSSxRQUFRLFFBQVEsV0FBVztBQUM3QixVQUFRLE9BQU8sVUFBVSxZQUFZLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU0sUUFBUSxjQUFjLE9BQU87QUFBQSxJQUNyQyxTQUFTLEtBQUs7QUFFWixZQUFNLEtBQUssMENBQTBDLGNBQWMsR0FBRyxDQUFDO0FBQ3ZFLFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUFBLElBQ3hDO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFJQSxRQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsS0FBYyxZQUFZO0FBQy9ELE1BQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFHLFFBQU87QUFDbkMsU0FBTyxjQUFjLEdBQUcsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUN2QyxTQUFLLE1BQU8sMEJBQTBCLEVBQUUsTUFBTSxJQUFJLE1BQU0sR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQy9FLFVBQU07QUFBQSxFQUNSLENBQUM7QUFDSCxDQUFDO0FBRUQsU0FBUyxpQkFBaUIsR0FBaUM7QUFDekQsU0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFBWSxPQUFRLEVBQXlCLFNBQVM7QUFDbkY7QUFFQSxlQUFlLGNBQWMsS0FBdUM7QUFDbEUsVUFBUSxJQUFJLE1BQU07QUFBQSxJQUNoQixLQUFLO0FBQ0gsWUFBTSxpQkFBaUIsSUFBSSxVQUFVLElBQUksS0FBSyxJQUFJLFFBQVE7QUFDMUQsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdkUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssK0JBQStCLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdEUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxVQUFJLElBQUksVUFBVSxRQUFRO0FBQ3hCLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xELFdBQVcsSUFBSSxVQUFVLFNBQVM7QUFDaEMsY0FBTSxNQUFPLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDcEQsT0FBTztBQUNMLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xEO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxXQUFXLElBQUksTUFBTTtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxXQUFXO0FBQ2pCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFNBQVMsTUFBTTtBQUNyQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxZQUFZLElBQUksUUFBUSxNQUFNO0FBQ3BDLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGVBQWUsRUFBRSxhQUFhLElBQUksR0FBRyxDQUFDO0FBQzVDLFlBQU0sS0FBSyx3QkFBd0IsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQ2pELGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLG9CQUFvQixJQUFJO0FBQzlCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGNBQWM7QUFDcEIsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFDdEMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssZUFBZTtBQUNsQixZQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFlBQU0sTUFBTSxVQUFVLENBQUM7QUFDdkIsWUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLElBQUksQ0FBQztBQUNqQyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQ0UsYUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLHVCQUF1QjtBQUFBLEVBQ3REO0FBQ0Y7QUFJQSxlQUFlLGlCQUFpQixVQUFrQixLQUFhLFVBQWtDO0FBQy9GLE1BQUksa0JBQWtCLElBQUksUUFBUSxFQUFHO0FBQ3JDLE1BQUksQ0FBQyxnQkFBZ0IsSUFBSSxRQUFRLEVBQUc7QUFFcEMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLEtBQUs7QUFDakIsVUFBTSxLQUFLLHVDQUF1QyxFQUFFLFNBQVMsQ0FBQztBQUM5RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNLFVBQVUsSUFBSSxJQUFJLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUUxQyxNQUFJO0FBQ0osTUFBSTtBQUNGLGlCQUFhLFVBQVUsVUFBVTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsZ0JBQWdCO0FBQUEsSUFDbEIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxXQUFXLG1CQUFtQixVQUFVLEtBQUssVUFBVSxHQUFHO0FBQ2hFO0FBQUEsRUFDRjtBQUVBLE1BQUksV0FBVyxPQUFPLFdBQVcsRUFBRztBQUdwQyxRQUFNLFdBQVcsb0JBQUksSUFBOEI7QUFDbkQsYUFBVyxLQUFLLFdBQVcsUUFBUTtBQUNqQyxVQUFNLE1BQU0sU0FBUyxJQUFJLEVBQUUsY0FBYyxLQUFLLENBQUM7QUFDL0MsUUFBSSxLQUFLLENBQUM7QUFDVixhQUFTLElBQUksRUFBRSxnQkFBZ0IsR0FBRztBQUFBLEVBQ3BDO0FBRUEsYUFBVyxDQUFDLFFBQVEsTUFBTSxLQUFLLFVBQVU7QUFDdkMsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxLQUFLLFFBQVE7QUFDbkUsUUFBSSxRQUFRO0FBQ1osZUFBVyxLQUFLLFFBQVE7QUFDdEIsWUFBTSxXQUFXLElBQUksYUFBYSxFQUFFLFFBQVE7QUFDNUMsVUFBSSxVQUFVO0FBR1osaUJBQVMsZUFBZTtBQUN4QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsZ0JBQWdCLEVBQUU7QUFDM0IsaUJBQVMsY0FBYyxFQUFFO0FBQ3pCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsaUJBQWlCLEVBQUU7QUFDNUIsY0FBTSxPQUFPLFNBQVMsbUJBQW1CLFNBQVMsbUJBQW1CLFNBQVMsQ0FBQztBQUMvRSxjQUFNLE9BQU8sRUFBRSxtQkFBbUIsQ0FBQztBQUNuQyxZQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssZ0JBQWdCLEtBQUssY0FBYztBQUM1RCxtQkFBUyxtQkFBbUIsS0FBSyxJQUFJO0FBQUEsUUFDdkM7QUFBQSxNQUNGLE9BQU87QUFDTCxjQUFNLFVBQTBCLEVBQUUsR0FBRyxHQUFHLGdCQUFnQixJQUFJLE9BQU87QUFDbkUsWUFBSSxhQUFhLEVBQUUsUUFBUSxJQUFJO0FBQy9CLGlCQUFTO0FBQUEsTUFDWDtBQUNBLFVBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQ2hELFlBQUksbUJBQW1CLEtBQUssRUFBRSxRQUFRO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTSxpQkFBaUIsUUFBUSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsTUFBTTtBQUNuRSxRQUFJLFFBQVEsR0FBRztBQUNiLFlBQU0sS0FBSyxtQkFBbUI7QUFBQSxRQUM1QjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxPQUFPLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRTtBQUFBLE1BQ3ZDLENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsVUFBVSx1QkFBdUI7QUFDakUsWUFBTSxZQUFZLFFBQVEsV0FBVztBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsZ0JBQ2IsUUFDQSxJQUNBLFdBQ0EsVUFDb0I7QUFDcEIsUUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBQ3JDLE1BQUksSUFBSyxRQUFPO0FBQ2hCLFFBQU0sTUFBaUI7QUFBQSxJQUNyQixRQUFRLFNBQVM7QUFBQSxJQUNqQixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixpQkFBaUI7QUFBQSxJQUNqQixjQUFjLENBQUM7QUFBQSxJQUNmLG9CQUFvQixDQUFDO0FBQUEsSUFDckIsZ0JBQWdCLENBQUMsUUFBUTtBQUFBLElBQ3pCLFlBQVk7QUFBQSxFQUNkO0FBQ0EsUUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixRQUFNLEtBQUssZUFBZSxFQUFFLFFBQVEsS0FBSyxXQUFXLElBQUksTUFBTSxFQUFFLENBQUM7QUFDakUsU0FBTztBQUNUO0FBSUEsZUFBZSxtQkFBa0M7QUFDL0MsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFVBQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxlQUFlO0FBQzNDLFFBQUksT0FBTyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsZUFBZTtBQUN4RCxZQUFNLFlBQVksUUFBUSxNQUFNO0FBQUEsSUFDbEM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlLDhCQUE2QztBQUcxRCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELFlBQU0sWUFBWSxRQUFRLE1BQU07QUFBQSxJQUNsQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWUsU0FBUyxRQUErQjtBQUNyRCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLGFBQVcsVUFBVSxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ3JDLFVBQU0sWUFBWSxRQUFRLE1BQU07QUFBQSxFQUNsQztBQUNGO0FBRUEsZUFBZSxZQUFZLFFBQWdCLFFBQStCO0FBQ3hFLFFBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUNyQyxNQUFJLENBQUMsSUFBSztBQUNWLFFBQU0sU0FBUyxPQUFPLE9BQU8sSUFBSSxZQUFZO0FBQzdDLE1BQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsVUFBTSxlQUFlLE1BQU07QUFDM0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sS0FBSyx1Q0FBdUMsRUFBRSxPQUFPLENBQUM7QUFDNUQ7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFFBQU0sS0FBSyxXQUFXLElBQUksVUFBVTtBQUNwQyxRQUFNLE1BQU0sSUFBSSxXQUFXLE1BQU0sR0FBRyxFQUFFO0FBQ3RDLFFBQU0sVUFBVSxPQUFPLE1BQU0sSUFBSSxFQUFFLElBQUksV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUM3RCxRQUFNLFdBQVcsUUFBUSxNQUFNLElBQUksRUFBRSxJQUFJLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFFL0QsUUFBTSxVQUEwQjtBQUFBLElBQzlCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsSUFDaEIsYUFBYSxJQUFJO0FBQUEsSUFDakIsVUFBVSxJQUFJLGVBQWUsS0FBSyxHQUFHO0FBQUEsSUFDckMsWUFBWSxVQUFVO0FBQUEsSUFDdEIsWUFBWSxJQUFJO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFvQjtBQUFBLElBQ3hCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsSUFDaEIsYUFBYSxJQUFJO0FBQUEsSUFDakIsb0JBQW9CLElBQUk7QUFBQSxFQUMxQjtBQUVBLFFBQU0sWUFBWSxZQUFZLE1BQU0sSUFBSSxHQUFHLElBQUksT0FBTyxNQUFNLFNBQVMsT0FBTyxXQUFXLElBQUksS0FBSyxHQUFHLFNBQVMsV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUVsSSxNQUFJO0FBQ0YsVUFBTSxPQUFPLFFBQVE7QUFBQSxNQUNuQixNQUFNO0FBQUEsTUFDTixlQUFlLFNBQVMsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLE1BQy9ELFNBQVM7QUFBQSxJQUNYLENBQUM7QUFDRCxVQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ25CLE1BQU07QUFBQSxNQUNOLGVBQWUsU0FBUyxLQUFLLFVBQVUsTUFBTSxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsTUFDNUQsU0FBUyxTQUFTLE1BQU0sSUFBSSxHQUFHLElBQUksS0FBSyxtQkFBbUIsTUFBTSxhQUFhLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFBQSxJQUN0RyxDQUFDO0FBQ0QsVUFBTSxlQUFlLE1BQU07QUFDM0IsVUFBTSxZQUFZLFFBQVE7QUFBQSxNQUN4QixhQUFhLE1BQU0sWUFBWSxHQUFHLE1BQU0sR0FBRyxjQUFjO0FBQUEsTUFDekQsV0FBVztBQUFBLE1BQ1gsZUFBZSxJQUFJO0FBQUEsTUFDbkIsa0JBQWtCLE1BQU0sWUFBWSxHQUFHLE1BQU0sR0FBRyxrQkFBa0IsS0FBSyxPQUFPO0FBQUEsTUFDOUUsZUFBZTtBQUFBLElBQ2pCLENBQUM7QUFDRCxVQUFNLEtBQUssbUJBQW1CO0FBQUEsTUFDNUI7QUFBQSxNQUNBO0FBQUEsTUFDQSxRQUFRLE9BQU87QUFBQSxNQUNmLEtBQUssV0FBVyxJQUFJLE1BQU07QUFBQSxNQUMxQixNQUFNO0FBQUEsSUFDUixDQUFDO0FBQ0QsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsUUFBUSxNQUFNLGNBQWMsR0FBRztBQUFBLE1BQy9CLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixRQUFJLGVBQWUsYUFBYTtBQUM5QixZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sU0FDSixJQUFJLGFBQWEsU0FDYixlQUNBLElBQUksYUFBYSxlQUNmLGlCQUNBLElBQUksYUFBYSxZQUNmLGtCQUNBLEtBQUs7QUFDZixZQUFNLGNBQWM7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTyxJQUFJO0FBQUEsTUFDYixDQUFDO0FBQ0QsWUFBTSxNQUFPLGdCQUFnQjtBQUFBLFFBQzNCO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVSxJQUFJO0FBQUEsUUFDZCxRQUFRLElBQUk7QUFBQSxRQUNaLFNBQVMsSUFBSTtBQUFBLE1BQ2YsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMLFlBQU0sTUFBTyxnQkFBZ0IsRUFBRSxRQUFRLFFBQVEsR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDeEU7QUFBQSxFQUVGLFVBQUU7QUFDQSxVQUFNLGVBQWU7QUFBQSxFQUN2QjtBQUNGO0FBSUEsZUFBZSxXQUFXLFFBQStCO0FBQ3ZELFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxPQUFPLENBQUM7QUFHOUMsTUFBSSxDQUFFLE1BQU0sYUFBYSxNQUFNLEdBQUk7QUFDakMsVUFBTSxPQUFNLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ25DLFVBQU0sYUFBYSxRQUFRO0FBQUEsTUFDekIsUUFBUSxTQUFTO0FBQUEsTUFDakIsZ0JBQWdCO0FBQUEsTUFDaEIsWUFBWTtBQUFBLE1BQ1osaUJBQWlCO0FBQUEsTUFDakIsY0FBYyxDQUFDO0FBQUEsTUFDZixvQkFBb0IsQ0FBQztBQUFBLE1BQ3JCLGdCQUFnQixDQUFDO0FBQUEsTUFDakIsWUFBWSxpQkFBaUIsTUFBTTtBQUFBLElBQ3JDLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssaUJBQWlCLE1BQU0sSUFBSSxRQUFRLEtBQUssQ0FBQztBQUM1RTtBQUVBLGVBQWUsYUFBNEI7QUFDekMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsT0FBTyxTQUFTLE9BQU8sQ0FBQztBQUM5RCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLFdBQVcsRUFBRSxNQUFNO0FBQUEsRUFDM0I7QUFDRjtBQUlBLGVBQWUsV0FDYixRQUNBLFVBQ0EsS0FDQSxLQUNBLEtBQ2U7QUFDZixRQUFNLE1BQU8sd0JBQXdCLEVBQUUsUUFBUSxVQUFVLEtBQUssR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQ3JGLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLFVBQTZCO0FBQUEsSUFDakMsZ0JBQWdCO0FBQUEsSUFDaEI7QUFBQSxJQUNBO0FBQUEsSUFDQSxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDcEMsWUFBWTtBQUFBLElBQ1osT0FBTyxjQUFjLEdBQUc7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssV0FBVyxRQUFRLFdBQVc7QUFDekMsUUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxDQUFDO0FBQy9DLFFBQU0sT0FBTyxtQkFBbUIsRUFBRSxJQUFJLElBQUk7QUFDMUMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ25CO0FBQUEsTUFDQSxlQUFlLFNBQVMsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLE1BQy9ELFNBQVMsZUFBZSxNQUFNLElBQUksUUFBUTtBQUFBLElBQzVDLENBQUM7QUFBQSxFQUNILFNBQVMsTUFBTTtBQUNiLFVBQU0sTUFBTyw0QkFBNEIsRUFBRSxHQUFHLGNBQWMsSUFBSSxFQUFFLENBQUM7QUFBQSxFQUNyRTtBQUNGO0FBRUEsZUFBZSxLQUFLLEdBQTRCO0FBQzlDLFFBQU0sTUFBTSxJQUFJLFlBQVksRUFBRSxPQUFPLENBQUM7QUFDdEMsUUFBTSxTQUFTLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxHQUFHO0FBQ3hELFFBQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxXQUFXLE1BQU0sQ0FBQyxFQUMxQyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFO0FBQ1YsU0FBTyxJQUFJLE1BQU0sR0FBRyxDQUFDO0FBQ3ZCO0FBSUEsZUFBZSxpQkFBaUIsT0FBK0I7QUFDN0QsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU87QUFBQSxNQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsSUFDVCxDQUFDO0FBQ0QsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsTUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXLFFBQVEsS0FBSyxXQUFXO0FBQ3BELFVBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTO0FBQ2xELFFBQUksTUFBTSw4QkFBK0I7QUFBQSxFQUMzQztBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxJQUFJLE1BQU0sT0FBTyxpQkFBaUI7QUFDeEMsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTyxFQUFFO0FBQUEsTUFDVCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLElBQ1QsQ0FBQztBQUNELFVBQU0sS0FBSyx1QkFBdUIsRUFBRSxPQUFPLEVBQUUsT0FBTyxNQUFNLEVBQUUsVUFBVSxDQUFDO0FBQUEsRUFDekUsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFNLGVBQWUsY0FBYyxJQUFJLFdBQVc7QUFDeEQsVUFBTSxTQUNKLFFBQVEsU0FDSixlQUNBLFFBQVEsZUFDTixpQkFDQSxRQUFRLFlBQ04sa0JBQ0E7QUFDVixVQUFNLGNBQWM7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU8sY0FBYyxHQUFHLEVBQUU7QUFBQSxJQUM1QixDQUFDO0FBQ0QsVUFBTSxLQUFLLDJCQUEyQixFQUFFLFVBQVUsS0FBSyxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFBQSxFQUNoRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsb0JBQW9CLE9BQStCO0FBQ2hFLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsS0FBSztBQUNqQixVQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxPQUFPLE1BQU0sT0FBTyxhQUFhLHNCQUFzQjtBQUM3RCxRQUFJLENBQUMsTUFBTTtBQUNULFVBQUksTUFBTyxPQUFNLEtBQUssaURBQWlEO0FBQ3ZFLFlBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFTLGtCQUFrQixJQUFJO0FBQ3JDLFFBQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsWUFBTSxLQUFLLDhDQUE4QztBQUN6RCxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDO0FBQUEsSUFDRjtBQUNBLFVBQU0sWUFBWSxNQUFNO0FBQ3hCLFFBQUksTUFBTyxPQUFNLEtBQUssMkJBQTJCLEVBQUUsT0FBTyxPQUFPLE9BQU8sQ0FBQztBQUFBLEVBQzNFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUNoRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUlBLGVBQWUsaUJBQWdDO0FBQzdDLFFBQU0sUUFBUSxNQUFNLFdBQVc7QUFDL0IsVUFBUSxRQUFRLFlBQVksRUFBRSxNQUFNLGlCQUFpQixNQUFNLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDOUU7QUFFQSxlQUFlLGFBQXNDO0FBQ25ELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsU0FBTztBQUFBLElBQ0wsU0FBUztBQUFBLElBQ1QsVUFBVSxlQUFlLFFBQVE7QUFBQSxJQUNqQyxZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBeUM7QUFDL0QsU0FBTztBQUFBLElBQ0wsT0FBTyxFQUFFO0FBQUEsSUFDVCxNQUFNLEVBQUU7QUFBQSxJQUNSLFFBQVEsRUFBRTtBQUFBLElBQ1YsYUFBYSxFQUFFO0FBQUEsSUFDZixjQUFjLEVBQUU7QUFBQSxJQUNoQixRQUFRLEVBQUUsSUFBSSxTQUFTO0FBQUEsSUFDdkIsV0FBVyxFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSTtBQUFBLEVBQ25EO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsS0FBcUI7QUFFdkMsUUFBTSxJQUFJLElBQUksS0FBSyxHQUFHO0FBQ3RCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTyxJQUFJLFFBQVEsU0FBUyxFQUFFO0FBQzdELFFBQU0sTUFBTSxDQUFDLEdBQVcsSUFBSSxNQUFNLE9BQU8sQ0FBQyxFQUFFLFNBQVMsR0FBRyxHQUFHO0FBQzNELFNBQ0UsR0FBRyxFQUFFLGVBQWUsQ0FBQyxJQUFJLElBQUksRUFBRSxZQUFZLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQ3BFLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQztBQUU5RTtBQUVBLFNBQVMsVUFBVSxHQUFxQjtBQUN0QyxTQUFPLFdBQVcsRUFBRSxLQUFLLGNBQWMsRUFBRSxJQUFJO0FBQy9DO0FBRUEsU0FBUyxXQUFXLEdBQW1CO0FBR3JDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFDeEIsVUFBTSxPQUFPLE9BQU8sWUFBWSxPQUFPLFNBQVMsWUFBTztBQUN2RCxXQUFPLE9BQU8sU0FBUyxXQUFXLE9BQU8sU0FBUyxnQkFDOUMsT0FDQSxHQUFHLE9BQU8sSUFBSSxHQUFHLElBQUk7QUFBQSxFQUMzQixRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQ7QUFDRjtBQUtDLFdBQXVDLGVBQWU7QUFBQSxFQUNyRDtBQUFBLEVBQ0EsVUFBVTtBQUFBLEVBQ1YsVUFBVTtBQUFBLEVBQ1YsU0FBUztBQUFBLEVBQ1QsVUFBVSxNQUFNLFNBQVMsVUFBVTtBQUFBLEVBQ25DLE9BQU87QUFDVDsiLAogICJuYW1lcyI6IFsib2JqIiwgImluZm8iXQp9Cg==
