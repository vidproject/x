// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  autoCapture: true,
  configuredAt: null
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement" },
  { handle: "CBP", label: "U.S. Customs and Border Protection" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services" },
  { handle: "WhiteHouse", label: "The White House" },
  { handle: "PressSec", label: "White House Press Secretary" },
  { handle: "POTUS", label: "President of the United States" },
  { handle: "USDOL", label: "U.S. Department of Labor" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: []
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  return getRaw("settings");
}
async function setSettings(s) {
  await setRaw("settings", s);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category
    });
  }
};
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase64(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const observed = [];
  for (const raw of rawTweets) {
    try {
      const t = buildTweet(raw, ctx);
      if (!t) continue;
      observed.push(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  return { tweets, observed_ids: observed };
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy);
  if (!restId || !legacy) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userLegacy = obj(userResult?.legacy);
  const handle = strOrNull(userLegacy?.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    hashtags,
    mentions,
    urls,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      if (current.handle && current.label) accounts.push(current);
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      if (current.handle && current.label) accounts.push(current);
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
  }
  if (current.handle && current.label) accounts.push(current);
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await flushOrphanedBuffersIfStale();
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
async function handleMessage(msg) {
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const accounts = await getAccounts();
  const allowed = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: allowed
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      key_paths: probeKeyPaths(response, 4).slice(0, 40),
      typenames: probeTypenames(response).slice(0, 30),
      has_errors: hasErrorsField(response)
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.tweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of normalized.tweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, Object.keys(buf.tweets_by_id).length);
    if (added > 0) {
      await info("captured tweets", {
        handle,
        endpoint,
        added,
        total: Object.keys(buf.tweets_by_id).length
      });
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      await flushHandle(handle, "idle");
    }
  }
}
async function flushOrphanedBuffersIfStale() {
  const all = await getRunBuffers();
  const now = Date.now();
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      await flushHandle(handle, "wake");
    }
  }
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  for (const handle of Object.keys(all)) {
    await flushHandle(handle, reason);
  }
}
async function flushHandle(handle, reason) {
  const buf = await getRunBuffer(handle);
  if (!buf) return;
  const tweets = Object.values(buf.tweets_by_id);
  if (tweets.length === 0) {
    await clearRunBuffer(handle);
    return;
  }
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", { handle });
    return;
  }
  const client = new GitHubClient(settings);
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const rawPath = `raw/${handle}/${ts}-${shortRunId(buf.run_id)}.json`;
  const seenPath = `seen/${handle}/${ts}-${shortRunId(buf.run_id)}.json`;
  const capture = {
    schema_version: 1,
    capture_run_id: buf.run_id,
    account_handle: handle,
    captured_at: buf.last_capture_at,
    endpoint: buf.endpoints_seen.join(","),
    user_agent: navigator.userAgent,
    source_url: buf.source_url,
    tweets
  };
  const seen = {
    schema_version: 1,
    capture_run_id: buf.run_id,
    account_handle: handle,
    captured_at: buf.last_capture_at,
    tweet_ids_observed: buf.tweet_ids_observed
  };
  const commitMsg = `capture: ${handle} ${day} ${tweets.length} tweet${tweets.length === 1 ? "" : "s"} (run ${shortRunId(buf.run_id)})`;
  try {
    await client.putFile({
      path: rawPath,
      contentBase64: toBase64(JSON.stringify(capture, null, 2) + "\n"),
      message: commitMsg
    });
    await client.putFile({
      path: seenPath,
      contentBase64: toBase64(JSON.stringify(seen, null, 2) + "\n"),
      message: `seen: ${handle} ${day} ${seen.tweet_ids_observed.length} ids (run ${shortRunId(buf.run_id)})`
    });
    await clearRunBuffer(handle);
    await bumpCounter(handle, {
      todayCount: (await getCounters())[handle]?.todayCount ?? 0,
      todayDate: day,
      lastCaptureAt: buf.last_capture_at,
      totalCommitted: ((await getCounters())[handle]?.totalCommitted ?? 0) + tweets.length,
      bufferedCount: 0
    });
    await info("flush committed", {
      handle,
      reason,
      tweets: tweets.length,
      run: shortRunId(buf.run_id),
      path: rawPath
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists
      });
      await error("flush failed", {
        handle,
        reason,
        category: err.category,
        status: err.status,
        message: err.message
      });
    } else {
      await error("flush failed", { handle, reason, ...describeError(err) });
    }
  } finally {
    await broadcastState();
  }
}
async function captureNow(handle) {
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase64(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force && conn.status === "ok" && conn.checkedAt) {
    const age = Date.now() - Date.parse(conn.checkedAt);
    if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null
    });
    await warn("connection check failed", { category: cat, ...describeError(err) });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      return;
    }
    await setAccounts(parsed);
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeKeyPaths(node, maxDepth) {
  const out = [];
  function walk(n, depth, prefix) {
    if (depth > maxDepth || n === null || typeof n !== "object") return;
    if (Array.isArray(n)) {
      out.push(`${prefix}[len=${n.length}]`);
      if (n.length > 0) walk(n[0], depth + 1, `${prefix}[0]`);
      return;
    }
    for (const k of Object.keys(n)) {
      const path = prefix ? `${prefix}.${k}` : k;
      out.push(path);
      walk(n[k], depth + 1, path);
    }
  }
  walk(node, 0, "");
  return out;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function hasErrorsField(node) {
  return typeof node === "object" && node !== null && Array.isArray(node.errors) && node.errors.length > 0;
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHBhdDogJycsXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXG4gIHJlcG86ICd4JyxcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxuICBicmFuY2g6ICdtYXN0ZXInLFxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcbiAgY29uZmlndXJlZEF0OiBudWxsLFxufTtcblxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcbi8vIHJlcG8gaGFzIGJlZW4gaW5pdGlhbGl6ZWQgb3IgUEFUIG1pc2NvbmZpZ3VyZWQpLiBLZXB0IGluIHN5bmMgd2l0aCB0aGUgZmlsZS5cbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScgfSxcbiAgeyBoYW5kbGU6ICdJQ0Vnb3YnLCBsYWJlbDogJ1UuUy4gSW1taWdyYXRpb24gYW5kIEN1c3RvbXMgRW5mb3JjZW1lbnQnIH0sXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJyB9LFxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycgfSxcbiAgeyBoYW5kbGU6ICdXaGl0ZUhvdXNlJywgbGFiZWw6ICdUaGUgV2hpdGUgSG91c2UnIH0sXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScgfSxcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJyB9LFxuICB7IGhhbmRsZTogJ1VTRE9MJywgbGFiZWw6ICdVLlMuIERlcGFydG1lbnQgb2YgTGFib3InIH0sXG5dO1xuXG4vLyBHcmFwaFFMIGVuZHBvaW50IG5hbWVzIHdlIGNhcmUgYWJvdXQgKG1hdGNoZWQgYnkgc3Vic3RyaW5nIGFnYWluc3QgVVJMIHBhdGgpLlxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG4gICdMaWtlcycsXG4gICdCb29rbWFya3MnLFxuICAnSG9tZVRpbWVsaW5lJyxcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXG4gICdTZWFyY2hUaW1lbGluZScsXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxuXSk7XG5cbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxuLy8gdG8gbGVhcm4gYWNjb3VudF9pZCA8LT4gaGFuZGxlIGJpbmRpbmdzKS5cbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcblxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xuXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcblxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XG5cbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcblxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XG5cbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB0eXBlIHtcbiAgQWNjb3VudENvbmZpZyxcbiAgQWNjb3VudENvdW50ZXIsXG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDb25uZWN0aW9uU3RhdGUsXG4gIExvZ0V2ZW50LFxuICBTZXR0aW5ncyxcbn0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogQnVmZmVyZWQgdHdlZXRzIGZvciBhIGdpdmVuIGFjY291bnQsIGF3YWl0aW5nIGNvbW1pdC4gQSBcInJ1blwiIGlzIG9uZSBlbnRyeVxuICogaW4gdGhpcyBtYXA7IGZsdXNoaW5nIGNsZWFycyB0aGUgZW50cnkuIFdlIHN0b3JlIGFzIFJlY29yZCBzbyB0aGUgc3RydWN0dXJlXG4gKiBzdXJ2aXZlcyBKU09OIHNlcmlhbGl6YXRpb24gdGhyb3VnaCBicm93c2VyLnN0b3JhZ2UuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUnVuQnVmZmVyIHtcbiAgcnVuX2lkOiBzdHJpbmc7XG4gIGFjY291bnRfaGFuZGxlOiBzdHJpbmc7XG4gIHN0YXJ0ZWRfYXQ6IHN0cmluZztcbiAgbGFzdF9jYXB0dXJlX2F0OiBzdHJpbmc7XG4gIHR3ZWV0c19ieV9pZDogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+O1xuICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IHN0cmluZ1tdO1xuICBlbmRwb2ludHNfc2Vlbjogc3RyaW5nW107XG4gIHNvdXJjZV91cmw6IHN0cmluZyB8IG51bGw7XG59XG5cbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xuICBzZXR0aW5nczogU2V0dGluZ3M7XG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcbiAgcnVuQnVmZmVyczogUmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPjtcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XG59XG5cbmNvbnN0IERFRkFVTFRfQ09OTkVDVElPTjogQ29ubmVjdGlvblN0YXRlID0ge1xuICBzdGF0dXM6ICd1bmtub3duJyxcbiAgbG9naW46IG51bGwsXG4gIGNoZWNrZWRBdDogbnVsbCxcbiAgZXJyb3I6IG51bGwsXG4gIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG59O1xuXG5jb25zdCBERUZBVUxUUzogU3RvcmFnZVNoYXBlID0ge1xuICBzZXR0aW5nczogeyAuLi5ERUZBVUxUX1NFVFRJTkdTIH0sXG4gIGFjY291bnRzOiBbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdLFxuICBjb25uZWN0aW9uOiB7IC4uLkRFRkFVTFRfQ09OTkVDVElPTiB9LFxuICBjb3VudGVyczoge30sXG4gIHJ1bkJ1ZmZlcnM6IHt9LFxuICBhY3Rpdml0eTogW10sXG59O1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChrZXkpO1xuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUoREVGQVVMVFNba2V5XSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW2tleV06IHZhbHVlIH0pO1xufVxuXG4vLyAtLS0gU2V0dGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICByZXR1cm4gZ2V0UmF3KCdzZXR0aW5ncycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnc2V0dGluZ3MnLCBzKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVTZXR0aW5ncyhwYXRjaDogUGFydGlhbDxTZXR0aW5ncz4pOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IG5leHQgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYXdhaXQgc2V0U2V0dGluZ3MobmV4dCk7XG4gIHJldHVybiBuZXh0O1xufVxuXG4vLyAtLS0gQWNjb3VudHMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHMoKTogUHJvbWlzZTxBY2NvdW50Q29uZmlnW10+IHtcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHMnKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50cyhhOiBBY2NvdW50Q29uZmlnW10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50cycsIGEpO1xufVxuXG4vLyAtLS0gQ29ubmVjdGlvbiBzdGF0ZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25uZWN0aW9uKCk6IFByb21pc2U8Q29ubmVjdGlvblN0YXRlPiB7XG4gIGNvbnN0IGMgPSBhd2FpdCBnZXRSYXcoJ2Nvbm5lY3Rpb24nKTtcbiAgLy8gQmFja2ZpbGwgZmllbGRzIGFkZGVkIGFmdGVyIHRoZSB1c2VyJ3Mgc3RvcmFnZSB3YXMgd3JpdHRlbi5cbiAgY29uc3Qgb3V0OiBDb25uZWN0aW9uU3RhdGUgPSB7XG4gICAgLi4uYyxcbiAgICBkZWZhdWx0QnJhbmNoOiBjLmRlZmF1bHRCcmFuY2ggPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmRlZmF1bHRCcmFuY2gsXG4gICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czpcbiAgICAgIGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcbiAgfTtcbiAgcmV0dXJuIG91dDtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb25uZWN0aW9uKGM6IENvbm5lY3Rpb25TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2Nvbm5lY3Rpb24nLCBjKTtcbn1cblxuLy8gLS0tIENvdW50ZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZnVuY3Rpb24gdG9kYXlJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3VudGVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb3VudGVycycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGJ1bXBDb3VudGVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgcGF0Y2g6IFBhcnRpYWw8QWNjb3VudENvdW50ZXI+XG4pOiBQcm9taXNlPEFjY291bnRDb3VudGVyPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGNvbnN0IGN1ciA9IGFsbFtoYW5kbGVdID8/IHtcbiAgICB0b2RheUNvdW50OiAwLFxuICAgIHRvZGF5RGF0ZTogdG9kYXlJU08oKSxcbiAgICBsYXN0Q2FwdHVyZUF0OiBudWxsLFxuICAgIHRvdGFsQ29tbWl0dGVkOiAwLFxuICAgIGJ1ZmZlcmVkQ291bnQ6IDAsXG4gIH07XG4gIGlmIChjdXIudG9kYXlEYXRlICE9PSB0b2RheUlTTygpKSB7XG4gICAgY3VyLnRvZGF5RGF0ZSA9IHRvZGF5SVNPKCk7XG4gICAgY3VyLnRvZGF5Q291bnQgPSAwO1xuICB9XG4gIGNvbnN0IG5leHQ6IEFjY291bnRDb3VudGVyID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGFsbFtoYW5kbGVdID0gbmV4dDtcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGFsbCk7XG4gIHJldHVybiBuZXh0O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QnVmZmVyZWRDb3VudChoYW5kbGU6IHN0cmluZywgY291bnQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHsgYnVmZmVyZWRDb3VudDogY291bnQgfSk7XG59XG5cbi8vIC0tLSBSdW4gYnVmZmVycyAodGhlIHBlbmRpbmcgY2FwdHVyZXMgYXdhaXRpbmcgY29tbWl0KSAtLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3J1bkJ1ZmZlcnMnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8UnVuQnVmZmVyIHwgbnVsbD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIHJldHVybiBhbGxbaGFuZGxlXSA/PyBudWxsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nLCBidWY6IFJ1bkJ1ZmZlcik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGFsbFtoYW5kbGVdID0gYnVmO1xuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBkZWxldGUgYWxsW2hhbmRsZV07XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbi8vIC0tLSBBY3Rpdml0eSB0YWlsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY3Rpdml0eSgpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcbiAgcmV0dXJuIGdldFJhdygnYWN0aXZpdHknKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGVuZEFjdGl2aXR5KGV2OiBMb2dFdmVudCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRBY3Rpdml0eSgpO1xuICBjdXIudW5zaGlmdChldik7XG4gIGlmIChjdXIubGVuZ3RoID4gQUNUSVZJVFlfVEFJTF9NQVgpIGN1ci5sZW5ndGggPSBBQ1RJVklUWV9UQUlMX01BWDtcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIGN1cik7XG4gIHJldHVybiBjdXI7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgW10pO1xufVxuXG4vLyAtLS0gRnVsbCByZXNldCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmNsZWFyKCk7XG59XG4iLCAiaW1wb3J0IHsgYXBwZW5kQWN0aXZpdHkgfSBmcm9tICcuL3N0b3JhZ2UuanMnO1xuaW1wb3J0IHR5cGUgeyBMb2dFdmVudCwgTG9nTGV2ZWwgfSBmcm9tICcuL3R5cGVzLmpzJztcblxubGV0IGJyb2FkY2FzdDogKChldjogTG9nRXZlbnQpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XG5cbmV4cG9ydCBmdW5jdGlvbiBzZXRCcm9hZGNhc3RlcihmbjogKGV2OiBMb2dFdmVudCkgPT4gdm9pZCk6IHZvaWQge1xuICBicm9hZGNhc3QgPSBmbjtcbn1cblxuZnVuY3Rpb24gbm93SVNPKCk6IHN0cmluZyB7XG4gIHJldHVybiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVtaXQobGV2ZWw6IExvZ0xldmVsLCBtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgZXY6IExvZ0V2ZW50ID0geyB0czogbm93SVNPKCksIGxldmVsLCBtc2csIGNvbnRleHQ6IHJlZGFjdChjb250ZXh0KSB9O1xuICAvLyBDb25zb2xlIGZvciBkZXZ0b29scy5cbiAgY29uc3QgbGluZSA9IGBbaW1tLWFyY2hpdmVdICR7bGV2ZWwudG9VcHBlckNhc2UoKX0gJHttc2d9YDtcbiAgaWYgKGxldmVsID09PSAnZXJyb3InKSBjb25zb2xlLmVycm9yKGxpbmUsIGV2LmNvbnRleHQpO1xuICBlbHNlIGlmIChsZXZlbCA9PT0gJ3dhcm4nKSBjb25zb2xlLndhcm4obGluZSwgZXYuY29udGV4dCk7XG4gIGVsc2UgY29uc29sZS5sb2cobGluZSwgZXYuY29udGV4dCk7XG4gIC8vIFBlcnNpc3RlbnQgdGFpbC5cbiAgdHJ5IHtcbiAgICBhd2FpdCBhcHBlbmRBY3Rpdml0eShldik7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBmYWlsZWQgdG8gYXBwZW5kIGFjdGl2aXR5JywgZXJyKTtcbiAgfVxuICAvLyBMaXZlIGJyb2FkY2FzdCAoZS5nLiB0byBzaWRlYmFyKS5cbiAgdHJ5IHtcbiAgICBicm9hZGNhc3Q/Lihldik7XG4gIH0gY2F0Y2gge1xuICAgIC8vIFNpZGViYXIgbWF5IG5vdCBiZSBvcGVuOyB0aGF0J3MgZmluZS5cbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gaW5mbyhtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gZW1pdCgnaW5mbycsIG1zZywgY29udGV4dCk7XG59XG5leHBvcnQgZnVuY3Rpb24gd2Fybihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gZW1pdCgnd2FybicsIG1zZywgY29udGV4dCk7XG59XG5leHBvcnQgZnVuY3Rpb24gZXJyb3IobXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge30pOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIGVtaXQoJ2Vycm9yJywgbXNnLCBjb250ZXh0KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlc2NyaWJlRXJyb3IoZXJyOiB1bmtub3duKTogeyBtZXNzYWdlOiBzdHJpbmc7IHN0YWNrOiBzdHJpbmcgfCBudWxsIH0ge1xuICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICByZXR1cm4geyBtZXNzYWdlOiBlcnIubWVzc2FnZSwgc3RhY2s6IGVyci5zdGFjayA/PyBudWxsIH07XG4gIH1cbiAgdHJ5IHtcbiAgICByZXR1cm4geyBtZXNzYWdlOiBTdHJpbmcoZXJyKSwgc3RhY2s6IG51bGwgfTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHsgbWVzc2FnZTogJzx1bnByaW50YWJsZSBlcnJvcj4nLCBzdGFjazogbnVsbCB9O1xuICB9XG59XG5cbi8qKlxuICogU3RyaXAgYW55dGhpbmcgdGhhdCBsb29rcyBsaWtlIGEgUEFUIG9yIG90aGVyIGxvbmcgc2VjcmV0IGZyb20gYSBjb250ZXh0XG4gKiBvYmplY3QgYmVmb3JlIHBlcnNpc3RpbmcgaXQuIERlZmVuc2l2ZTogY2FsbGVycyBzaG91bGQgbm90IGxvZyB0b2tlbnMsIGJ1dFxuICogaWYgdGhleSBzbGlwIHRocm91Z2ggd2Ugd2FudCB0byByZWRhY3QgdGhlbS5cbiAqL1xuZnVuY3Rpb24gcmVkYWN0KGN0eDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XG4gIGNvbnN0IG91dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgZm9yIChjb25zdCBbaywgdl0gb2YgT2JqZWN0LmVudHJpZXMoY3R4KSkge1xuICAgIGlmIChrLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ3Rva2VuJykgfHwgay50b0xvd2VyQ2FzZSgpID09PSAncGF0JyB8fCBrID09PSAnYXV0aG9yaXphdGlvbicpIHtcbiAgICAgIG91dFtrXSA9ICc8cmVkYWN0ZWQ+JztcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiAvZ2l0aHViX3BhdF9bQS1aYS16MC05X117MzAsfS8udGVzdCh2KSkge1xuICAgICAgb3V0W2tdID0gdi5yZXBsYWNlKC9naXRodWJfcGF0X1tBLVphLXowLTlfXSsvZywgJ2dpdGh1Yl9wYXRfPHJlZGFjdGVkPicpO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gNDA5Nikge1xuICAgICAgb3V0W2tdID0gYCR7di5zbGljZSgwLCA0MDk2KX1cdTIwMjY8dHJ1bmNhdGVkPmA7XG4gICAgfSBlbHNlIHtcbiAgICAgIG91dFtrXSA9IHY7XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXQ7XG59XG4iLCAiaW1wb3J0IHsgZGVzY3JpYmVFcnJvciB9IGZyb20gJy4vbG9nZ2VyLmpzJztcbmltcG9ydCB0eXBlIHsgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuY29uc3QgQVBJX0JBU0UgPSAnaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbSc7XG5jb25zdCBSQVdfQkFTRSA9ICdodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20nO1xuXG5leHBvcnQgaW50ZXJmYWNlIFB1dEZpbGVPcHRpb25zIHtcbiAgcGF0aDogc3RyaW5nO1xuICBjb250ZW50QmFzZTY0OiBzdHJpbmc7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgZXhwZWN0ZWRTaGE/OiBzdHJpbmcgfCBudWxsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFB1dEZpbGVSZXN1bHQge1xuICBwYXRoOiBzdHJpbmc7XG4gIHNoYTogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbn1cblxuZXhwb3J0IGNsYXNzIEdpdEh1YkVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBzdGF0dXM6IG51bWJlcjtcbiAgYm9keTogdW5rbm93bjtcbiAgcmV0cmlhYmxlOiBib29sZWFuO1xuICBjYXRlZ29yeTogJ2F1dGgnIHwgJ3JhdGUtbGltaXQnIHwgJ2NvbmZsaWN0JyB8ICdub3QtZm91bmQnIHwgJ3NlcnZlcicgfCAnbmV0d29yaycgfCAndW5rbm93bic7XG5cbiAgY29uc3RydWN0b3Iob3B0czoge1xuICAgIHN0YXR1czogbnVtYmVyO1xuICAgIGJvZHk6IHVua25vd247XG4gICAgbWVzc2FnZTogc3RyaW5nO1xuICAgIHJldHJpYWJsZTogYm9vbGVhbjtcbiAgICBjYXRlZ29yeTogR2l0SHViRXJyb3JbJ2NhdGVnb3J5J107XG4gIH0pIHtcbiAgICBzdXBlcihvcHRzLm1lc3NhZ2UpO1xuICAgIHRoaXMubmFtZSA9ICdHaXRIdWJFcnJvcic7XG4gICAgdGhpcy5zdGF0dXMgPSBvcHRzLnN0YXR1cztcbiAgICB0aGlzLmJvZHkgPSBvcHRzLmJvZHk7XG4gICAgdGhpcy5yZXRyaWFibGUgPSBvcHRzLnJldHJpYWJsZTtcbiAgICB0aGlzLmNhdGVnb3J5ID0gb3B0cy5jYXRlZ29yeTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgR2l0SHViQ2xpZW50IHtcbiAgcHJpdmF0ZSByZWFkb25seSBzZXR0aW5nczogU2V0dGluZ3M7XG5cbiAgY29uc3RydWN0b3Ioc2V0dGluZ3M6IFNldHRpbmdzKSB7XG4gICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzO1xuICB9XG5cbiAgLyoqIFJldHVybnMgdGhlIGF1dGhlbnRpY2F0ZWQgdXNlcidzIGxvZ2luLiBUaHJvd3Mgb24gYXV0aCBmYWlsdXJlLiAqL1xuICBhc3luYyB3aG9hbWkoKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgJy91c2VyJyk7XG4gICAgcmV0dXJuIChyZXMgYXMgeyBsb2dpbj86IHN0cmluZyB9KS5sb2dpbiA/PyAnPHVua25vd24+JztcbiAgfVxuXG4gIC8qKiBSZXR1cm5zIHRydWUgaWYgdGhlIGdpdmVuIGJyYW5jaCBleGlzdHMgb24gdGhlIGNvbmZpZ3VyZWQgcmVwby4gKi9cbiAgYXN5bmMgYnJhbmNoRXhpc3RzKGJyYW5jaDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9icmFuY2hlcy8ke2VuY29kZVVSSUNvbXBvbmVudChicmFuY2gpfWBcbiAgICAgICk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gZmFsc2U7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgLyoqIFZlcmlmaWVzIHRoZSBQQVQgY2FuIHNlZSB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xuICBhc3luYyB2ZXJpZnlSZXBvQWNjZXNzKCk6IFByb21pc2U8eyBsb2dpbjogc3RyaW5nOyBmdWxsX25hbWU6IHN0cmluZzsgZGVmYXVsdF9icmFuY2g6IHN0cmluZyB9PiB7XG4gICAgY29uc3QgbWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgJy91c2VyJyk7XG4gICAgY29uc3QgcmVwbyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99YCk7XG4gICAgY29uc3QgciA9IHJlcG8gYXMgeyBmdWxsX25hbWU6IHN0cmluZzsgZGVmYXVsdF9icmFuY2g6IHN0cmluZyB9O1xuICAgIHJldHVybiB7XG4gICAgICBsb2dpbjogKG1lIGFzIHsgbG9naW46IHN0cmluZyB9KS5sb2dpbixcbiAgICAgIGZ1bGxfbmFtZTogci5mdWxsX25hbWUsXG4gICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIEZldGNoIGEgdGV4dCBmaWxlIGZyb20gcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSBhdXRoZW50aWNhdGVkIHdpdGggdGhlXG4gICAqIFBBVC4gUmV0dXJucyBudWxsIGlmIHRoZSBmaWxlIGRvZXNuJ3QgZXhpc3QuIFVzZWQgZm9yIGNvbmZpZy9hY2NvdW50cy55YW1sLlxuICAgKi9cbiAgYXN5bmMgZmV0Y2hSYXdUZXh0KHBhdGhJblJlcG86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IHVybCA9IGAke1JBV19CQVNFfS8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS8ke3RoaXMuc2V0dGluZ3MuYnJhbmNofS8ke3BhdGhJblJlcG99YDtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLnNldHRpbmdzLnBhdH1gIH0sXG4gICAgfSk7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkgcmV0dXJuIG51bGw7XG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yKHJlcywgYEdFVCByYXcgJHtwYXRoSW5SZXBvfWApO1xuICAgIHJldHVybiByZXMudGV4dCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvb2sgdXAgYW4gZXhpc3RpbmcgZmlsZSdzIFNIQSB2aWEgdGhlIENvbnRlbnRzIEFQSSwgb3IgbnVsbCBpZiBub3QgZm91bmQuXG4gICAqIFVzZWQgd2hlbiByZXRyeWluZyBhIFBVVCBhZnRlciBhIDQyMiBzaGEgbWlzbWF0Y2guXG4gICAqL1xuICBhc3luYyBnZXRGaWxlU2hhKHBhdGg6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vY29udGVudHMvJHtlbmNvZGVQYXRoKHBhdGgpfT9yZWY9JHtlbmNvZGVVUklDb21wb25lbnQodGhpcy5zZXR0aW5ncy5icmFuY2gpfWBcbiAgICAgICk7XG4gICAgICBjb25zdCByID0gcmVzIGFzIHsgc2hhPzogc3RyaW5nIH07XG4gICAgICByZXR1cm4gci5zaGEgPz8gbnVsbDtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gbnVsbDtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUFVUIGEgZmlsZSB0byB0aGUgcmVwby4gSGFuZGxlcyA0MjIgKHNoYSByZXF1aXJlZCkgYnkgcmUtZmV0Y2hpbmcgdGhlXG4gICAqIGV4aXN0aW5nIHNoYSBhbmQgcmV0cnlpbmcgb25jZS4gUmV0cmllcyBuZXR3b3JrIC8gNXh4IC8gcmF0ZS1saW1pdCBlcnJvcnNcbiAgICogd2l0aCBleHBvbmVudGlhbCBiYWNrb2ZmIHVwIHRvIG1heEF0dGVtcHRzLlxuICAgKi9cbiAgYXN5bmMgcHV0RmlsZShvcHRzOiBQdXRGaWxlT3B0aW9ucyk6IFByb21pc2U8UHV0RmlsZVJlc3VsdD4ge1xuICAgIGNvbnN0IHBhdGggPSBvcHRzLnBhdGg7XG4gICAgY29uc3QgdXJsID0gYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9YDtcbiAgICBsZXQgc2hhOiBzdHJpbmcgfCBudWxsID0gb3B0cy5leHBlY3RlZFNoYSA/PyBudWxsO1xuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcbiAgICAgIGNvbnN0IGJvZHk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXG4gICAgICAgIGNvbnRlbnQ6IG9wdHMuY29udGVudEJhc2U2NCxcbiAgICAgICAgYnJhbmNoOiB0aGlzLnNldHRpbmdzLmJyYW5jaCxcbiAgICAgIH07XG4gICAgICBpZiAoc2hhKSBib2R5LnNoYSA9IHNoYTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdQVVQnLCB1cmwsIGJvZHkpO1xuICAgICAgICBjb25zdCBvdXQgPSByZXMgYXMgeyBjb250ZW50OiB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nOyBwYXRoOiBzdHJpbmcgfSB9O1xuICAgICAgICByZXR1cm4geyBwYXRoOiBvdXQuY29udGVudC5wYXRoLCBzaGE6IG91dC5jb250ZW50LnNoYSwgdXJsOiBvdXQuY29udGVudC5odG1sX3VybCB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xuICAgICAgICBpZiAoZXJyLnN0YXR1cyA9PT0gNDIyICYmICFzaGEpIHtcbiAgICAgICAgICAvLyBGaWxlIGFscmVhZHkgZXhpc3RzOyBmZXRjaCBpdHMgc2hhIGFuZCByZXRyeSBvbmNlLlxuICAgICAgICAgIHNoYSA9IGF3YWl0IHRoaXMuZ2V0RmlsZVNoYShwYXRoKTtcbiAgICAgICAgICBpZiAoIXNoYSkgdGhyb3cgZXJyO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZXJyLnJldHJpYWJsZSB8fCBhdHRlbXB0ID09PSBtYXhBdHRlbXB0cykgdGhyb3cgZXJyO1xuICAgICAgICBhd2FpdCBzbGVlcChiYWNrb2ZmTXMoYXR0ZW1wdCwgZXJyKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihgcHV0RmlsZTogZXhoYXVzdGVkIGF0dGVtcHRzIGZvciAke3BhdGh9YCk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZldGNoSnNvbihtZXRob2Q6IHN0cmluZywgcGF0aDogc3RyaW5nLCBib2R5PzogdW5rbm93bik6IFByb21pc2U8dW5rbm93bj4ge1xuICAgIGNvbnN0IHVybCA9IHBhdGguc3RhcnRzV2l0aCgnaHR0cCcpID8gcGF0aCA6IGAke0FQSV9CQVNFfSR7cGF0aH1gO1xuICAgIGNvbnN0IGluaXQ6IFJlcXVlc3RJbml0ID0ge1xuICAgICAgbWV0aG9kLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dGhpcy5zZXR0aW5ncy5wYXR9YCxcbiAgICAgICAgQWNjZXB0OiAnYXBwbGljYXRpb24vdm5kLmdpdGh1Yitqc29uJyxcbiAgICAgICAgJ1gtR2l0SHViLUFwaS1WZXJzaW9uJzogJzIwMjItMTEtMjgnLFxuICAgICAgICAuLi4oYm9keSA/IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IDoge30pLFxuICAgICAgfSxcbiAgICAgIC4uLihib2R5ID8geyBib2R5OiBKU09OLnN0cmluZ2lmeShib2R5KSB9IDoge30pLFxuICAgIH07XG4gICAgbGV0IHJlczogUmVzcG9uc2U7XG4gICAgdHJ5IHtcbiAgICAgIHJlcyA9IGF3YWl0IGZldGNoKHVybCwgaW5pdCk7XG4gICAgfSBjYXRjaCAobmV0RXJyKSB7XG4gICAgICB0aHJvdyBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgICBzdGF0dXM6IDAsXG4gICAgICAgIGJvZHk6IG51bGwsXG4gICAgICAgIG1lc3NhZ2U6IGBuZXR3b3JrOiAke2Rlc2NyaWJlRXJyb3IobmV0RXJyKS5tZXNzYWdlfWAsXG4gICAgICAgIHJldHJpYWJsZTogdHJ1ZSxcbiAgICAgICAgY2F0ZWdvcnk6ICduZXR3b3JrJyxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gMjA0KSByZXR1cm4gbnVsbDtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICBpZiAodGV4dCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBwYXJzZWQgPSB0ZXh0O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBgJHttZXRob2R9ICR7cGF0aH1gKTtcbiAgICByZXR1cm4gcGFyc2VkO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBtYWtlRXJyb3IocmVzOiBSZXNwb25zZSwgbGFiZWw6IHN0cmluZyk6IFByb21pc2U8R2l0SHViRXJyb3I+IHtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICBpZiAodGV4dCkgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBsYWJlbCk7XG4gIH1cblxuICBwcml2YXRlIG1ha2VFcnJvckZyb21QYXJzZWQocmVzOiBSZXNwb25zZSwgYm9keTogdW5rbm93biwgbGFiZWw6IHN0cmluZyk6IEdpdEh1YkVycm9yIHtcbiAgICBjb25zdCBtc2cgPVxuICAgICAgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmIGJvZHkgJiYgJ21lc3NhZ2UnIGluIGJvZHlcbiAgICAgICAgPyBTdHJpbmcoKGJvZHkgYXMgeyBtZXNzYWdlOiB1bmtub3duIH0pLm1lc3NhZ2UpXG4gICAgICAgIDogcmVzLnN0YXR1c1RleHQ7XG4gICAgbGV0IGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXSA9ICd1bmtub3duJztcbiAgICBsZXQgcmV0cmlhYmxlID0gZmFsc2U7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSB8fCByZXMuc3RhdHVzID09PSA0MDMpIHtcbiAgICAgIC8vIDQwMyBjYW4gYmUgZWl0aGVyIGF1dGggb3IgcmF0ZSBsaW1pdDsgY2hlY2sgaGVhZGVycy5cbiAgICAgIGNvbnN0IHJhdGUgPSByZXMuaGVhZGVycy5nZXQoJ3gtcmF0ZWxpbWl0LXJlbWFpbmluZycpO1xuICAgICAgaWYgKHJhdGUgPT09ICcwJyB8fCAvcmF0ZSBsaW1pdC9pLnRlc3QobXNnKSkge1xuICAgICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNhdGVnb3J5ID0gJ2F1dGgnO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSB7XG4gICAgICBjYXRlZ29yeSA9ICdub3QtZm91bmQnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA5IHx8IHJlcy5zdGF0dXMgPT09IDQyMikge1xuICAgICAgY2F0ZWdvcnkgPSAnY29uZmxpY3QnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA+PSA1MDApIHtcbiAgICAgIGNhdGVnb3J5ID0gJ3NlcnZlcic7XG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDI5KSB7XG4gICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgc3RhdHVzOiByZXMuc3RhdHVzLFxuICAgICAgYm9keSxcbiAgICAgIG1lc3NhZ2U6IGAke2xhYmVsfSBcdTIxOTIgJHtyZXMuc3RhdHVzfTogJHttc2d9YCxcbiAgICAgIHJldHJpYWJsZSxcbiAgICAgIGNhdGVnb3J5LFxuICAgIH0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVuY29kZVBhdGgocGF0aDogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gRW5jb2RlIHNlZ21lbnRzIGluZGl2aWR1YWxseSBzbyBzbGFzaGVzIHJlbWFpbi5cbiAgcmV0dXJuIHBhdGguc3BsaXQoJy8nKS5tYXAoZW5jb2RlVVJJQ29tcG9uZW50KS5qb2luKCcvJyk7XG59XG5cbmZ1bmN0aW9uIGJhY2tvZmZNcyhhdHRlbXB0OiBudW1iZXIsIGVycjogR2l0SHViRXJyb3IpOiBudW1iZXIge1xuICAvLyBFeHBvbmVudGlhbCB3aXRoIGppdHRlcjsgYnVtcCBoaWdoZXIgZm9yIHJhdGUtbGltaXQgcmVzcG9uc2VzLlxuICBjb25zdCBiYXNlID0gZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyA1MDAwIDogNTAwO1xuICBjb25zdCBqaXR0ZXIgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0MDApO1xuICByZXR1cm4gTWF0aC5taW4oNjBfMDAwLCBiYXNlICogMiAqKiAoYXR0ZW1wdCAtIDEpICsgaml0dGVyKTtcbn1cblxuZnVuY3Rpb24gc2xlZXAobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBieXRlcyBpcyBhIFVURi04IHN0cmluZyBvZiBKU09OOyBlbmNvZGUgdG8gYmFzZTY0IHRoZSBzYWZlIHdheS5cbiAgY29uc3QgdXRmOCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShieXRlcyk7XG4gIGxldCBiaW4gPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIHV0ZjgpIGJpbiArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShiaW4pO1xufVxuIiwgImltcG9ydCB7IFRXRUVUX1VSTF9QUkVGSVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7IENhbm9uaWNhbFR3ZWV0LCBNZWRpYUl0ZW0sIFR3ZWV0VHlwZSwgVXJsRW50aXR5IH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTm9ybWFsaXplIEdyYXBoUUwgcmVzcG9uc2UgcGF5bG9hZHMgZnJvbSBYJ3MgaW50ZXJuYWwgQVBJIGludG9cbiAqIGBDYW5vbmljYWxUd2VldGBzLiBNYW55IGVuZHBvaW50cyBzaGFyZSBhIHNpbWlsYXIgdHdlZXQgc2hhcGUgYnV0IHdyYXAgaXQgaW5cbiAqIGRpZmZlcmVudCBlbnZlbG9wZXM7IHRoaXMgbW9kdWxlIHdhbGtzIHRoZSBzdHJ1Y3R1cmUgZGVmZW5zaXZlbHkuXG4gKlxuICogVGhlIHBhcnNlciBpcyBpbnRlbnRpb25hbGx5IHBlcm1pc3NpdmU6IGl0IHdpbGwgc2lsZW50bHkgc2tpcCBlbnRyaWVzIGl0XG4gKiBjYW4ndCByZWNvZ25pemUgYXMgdHdlZXRzIChjdXJzb3JzLCBhZHMsIGdhcCBlbnRyaWVzLCBtb2R1bGVzIG9mIG90aGVyXG4gKiB0d2VldHMsIHRvbWJzdG9uZXMpLiBJdCB0aHJvd3MgKm9ubHkqIHdoZW4gZ2l2ZW4gYSBwYXlsb2FkIGl0IGRvZXNuJ3Qga25vd1xuICogaG93IHRvIHdhbGsgYXQgYWxsIFx1MjAxNCB0aG9zZSBjYXNlcyBhcmUgY2F1Z2h0IGFuZCBxdWFyYW50aW5lZCB1cHN0cmVhbS5cbiAqL1xuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZUNvbnRleHQge1xuICBjYXB0dXJlZEF0OiBzdHJpbmc7XG4gIHJ1bklkOiBzdHJpbmc7XG4gIGVuZHBvaW50OiBzdHJpbmc7XG4gIGFsbG93ZWRIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZVJlc3VsdCB7XG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcbiAgb2JzZXJ2ZWRfaWRzOiBzdHJpbmdbXTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShwYXlsb2FkOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBOb3JtYWxpemVSZXN1bHQge1xuICBjb25zdCByYXdUd2VldHMgPSBjb2xsZWN0VHdlZXRzKHBheWxvYWQpO1xuICBjb25zdCB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10gPSBbXTtcbiAgY29uc3Qgb2JzZXJ2ZWQ6IHN0cmluZ1tdID0gW107XG4gIGZvciAoY29uc3QgcmF3IG9mIHJhd1R3ZWV0cykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0ID0gYnVpbGRUd2VldChyYXcsIGN0eCk7XG4gICAgICBpZiAoIXQpIGNvbnRpbnVlO1xuICAgICAgb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIGlmIChjdHguYWxsb3dlZEhhbmRsZXMuc2l6ZSA9PT0gMCB8fCBjdHguYWxsb3dlZEhhbmRsZXMuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgdHdlZXRzLnB1c2godCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBPbmUgYmFkIGVudHJ5IHNob3VsZG4ndCB0YWtlIGRvd24gdGhlIHdob2xlIGJhdGNoLlxuICAgIH1cbiAgfVxuICByZXR1cm4geyB0d2VldHMsIG9ic2VydmVkX2lkczogb2JzZXJ2ZWQgfTtcbn1cblxuZnVuY3Rpb24gY29sbGVjdFR3ZWV0cyhvYmo6IHVua25vd24pOiB1bmtub3duW10ge1xuICAvLyBXYWxrIHRoZSByZXNwb25zZSB0cmVlIGdhdGhlcmluZyBldmVyeXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIHR3ZWV0XG4gIC8vIHJlc3VsdC4gV2UgbG9vayBmb3Igbm9kZXMgc2hhcGVkIGxpa2U6XG4gIC8vICAgeyBfX3R5cGVuYW1lPzogJ1R3ZWV0J3wnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnLCByZXN0X2lkLCBsZWdhY3kgfVxuICAvLyBhbmQgdW53cmFwIHZpc2liaWxpdHkgd3JhcHBlcnMuXG4gIGNvbnN0IG91dDogdW5rbm93bltdID0gW107XG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbb2JqXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBub2RlID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG5vZGUgPT09IG51bGwgfHwgbm9kZSA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcbiAgICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAoc2Vlbi5oYXMobm9kZSBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChub2RlIGFzIG9iamVjdCk7XG5cbiAgICBpZiAobG9va3NMaWtlVHdlZXQobm9kZSkpIHtcbiAgICAgIG91dC5wdXNoKHVud3JhcFR3ZWV0KG5vZGUpKTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobm9kZSkpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBub2RlKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gbG9va3NMaWtlVHdlZXQobm9kZTogdW5rbm93bik6IG5vZGUgaXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIGNvbnN0IHR5cGVuYW1lID0gbi5fX3R5cGVuYW1lO1xuICBpZiAoXG4gICAgdHlwZW5hbWUgPT09ICdUd2VldCcgfHxcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyB8fFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnXG4gICkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIC8vIFNvbWUgZW50cmllcyBsYWNrIF9fdHlwZW5hbWUgYnV0IHN0aWxsIGNhcnJ5IGxlZ2FjeSArIHJlc3RfaWQgKyBjb3JlLlxuICByZXR1cm4gdHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgdHlwZW9mIG4ubGVnYWN5ID09PSAnb2JqZWN0JyAmJiBuLmxlZ2FjeSAhPT0gbnVsbDtcbn1cblxuZnVuY3Rpb24gdW53cmFwVHdlZXQobm9kZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XG4gIGlmIChub2RlLl9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgJiYgdHlwZW9mIG5vZGUudHdlZXQgPT09ICdvYmplY3QnKSB7XG4gICAgcmV0dXJuIG5vZGUudHdlZXQgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIH1cbiAgcmV0dXJuIG5vZGU7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkVHdlZXQocmF3OiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBDYW5vbmljYWxUd2VldCB8IG51bGwge1xuICBpZiAodHlwZW9mIHJhdyAhPT0gJ29iamVjdCcgfHwgcmF3ID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgdCA9IHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcblxuICBpZiAodC5fX3R5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCByZXN0SWQgPSBzdHJPck51bGwodC5yZXN0X2lkKTtcbiAgY29uc3QgbGVnYWN5ID0gb2JqKHQubGVnYWN5KTtcbiAgaWYgKCFyZXN0SWQgfHwgIWxlZ2FjeSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgY29yZSA9IG9iaih0LmNvcmUpO1xuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihjb3JlPy51c2VyX3Jlc3VsdHMpPy5yZXN1bHQpO1xuICBjb25zdCB1c2VyTGVnYWN5ID0gb2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk7XG4gIGNvbnN0IGhhbmRsZSA9IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5zY3JlZW5fbmFtZSk7XG4gIGNvbnN0IGFjY291bnRJZCA9IHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5yZXN0X2lkKSA/PyBzdHJPck51bGwobGVnYWN5LnVzZXJfaWRfc3RyKTtcbiAgaWYgKCFoYW5kbGUgfHwgIWFjY291bnRJZCkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgbm90ZVR3ZWV0ID0gb2JqKG9iaihvYmoodC5ub3RlX3R3ZWV0KT8ubm90ZV90d2VldF9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgY29uc3QgdGV4dEZyb21Ob3RlID0gc3RyT3JOdWxsKG5vdGVUd2VldD8udGV4dCk7XG4gIGNvbnN0IHRleHRGcm9tTGVnYWN5ID0gc3RyT3JOdWxsKGxlZ2FjeS5mdWxsX3RleHQpID8/ICcnO1xuICBjb25zdCB0ZXh0ID0gdGV4dEZyb21Ob3RlID8/IHRleHRGcm9tTGVnYWN5O1xuXG4gIGNvbnN0IGVudGl0aWVzID0gb2JqKGxlZ2FjeS5lbnRpdGllcykgPz8ge307XG4gIGNvbnN0IGVudGl0aWVzRnJvbU5vdGUgPSBvYmoobm90ZVR3ZWV0Py5lbnRpdHlfc2V0KTtcbiAgY29uc3QgaGFzaHRhZ3MgPSBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IG1lbnRpb25zID0gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xuICBjb25zdCB1cmxzID0gZXh0cmFjdFVybHMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IG1lZGlhID0gZXh0cmFjdE1lZGlhKGxlZ2FjeSk7XG5cbiAgY29uc3QgdHdlZXRUeXBlID0gY2xhc3NpZnlUd2VldFR5cGUodCwgbGVnYWN5KTtcblxuICBjb25zdCBwb3N0ZWRBdCA9IHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKGxlZ2FjeS5jcmVhdGVkX2F0KSk7XG4gIGlmICghcG9zdGVkQXQpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHZpZXdzID0gb2JqKHQudmlld3MpO1xuICBjb25zdCB2aWV3Q291bnQgPSBudW1Pck51bGwodmlld3M/LmNvdW50KSA/PyBudW1Pck51bGwoc3RyT3JOdWxsKHZpZXdzPy5jb3VudCkpO1xuXG4gIGNvbnN0IHR3ZWV0OiBDYW5vbmljYWxUd2VldCA9IHtcbiAgICB0d2VldF9pZDogcmVzdElkLFxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgYWNjb3VudF9pZDogYWNjb3VudElkLFxuICAgIHBvc3RlZF9hdDogcG9zdGVkQXQsXG4gICAgZmlyc3RfY2FwdHVyZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxuICAgIGxhc3Rfc2Vlbl9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgZGVsZXRpb25fZGV0ZWN0ZWRfYXQ6IG51bGwsXG4gICAgdHdlZXRfdXJsOiBgJHtUV0VFVF9VUkxfUFJFRklYfS8ke2hhbmRsZX0vc3RhdHVzLyR7cmVzdElkfWAsXG4gICAgdHdlZXRfdHlwZTogdHdlZXRUeXBlLFxuICAgIHJlcGx5X3RvX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpLFxuICAgIHJlcGx5X3RvX2FjY291bnQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc2NyZWVuX25hbWUpLFxuICAgIHF1b3RlZF90d2VldF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0ciksXG4gICAgcmV0d2VldGVkX3R3ZWV0X2lkOiBzdHJPck51bGwoXG4gICAgICBvYmoob2JqKGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX3Jlc3VsdCk/LnJlc3VsdCk/LnJlc3RfaWQgPz9cbiAgICAgICAgKGxlZ2FjeSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikucmV0d2VldGVkX3N0YXR1c19pZF9zdHJcbiAgICApLFxuICAgIHRleHQsXG4gICAgdGV4dF9yZXNvbHZlZDogcmVzb2x2ZVNob3J0VXJscyh0ZXh0LCB1cmxzKSxcbiAgICBsYW5nOiBzdHJPck51bGwobGVnYWN5LmxhbmcpLFxuICAgIGhhc2h0YWdzLFxuICAgIG1lbnRpb25zLFxuICAgIHVybHMsXG4gICAgbWVkaWEsXG4gICAgbGlrZV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5mYXZvcml0ZV9jb3VudCksXG4gICAgcmV0d2VldF9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcbiAgICByZXBseV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXBseV9jb3VudCksXG4gICAgcXVvdGVfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucXVvdGVfY291bnQpLFxuICAgIHZpZXdfY291bnQ6IHZpZXdDb3VudCxcbiAgICBib29rbWFya19jb3VudDogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXG4gICAgZW5nYWdlbWVudF9oaXN0b3J5OiBbXG4gICAgICB7XG4gICAgICAgIGNhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICAgICAgbGlrZXM6IG51bU9yWmVybyhsZWdhY3kuZmF2b3JpdGVfY291bnQpLFxuICAgICAgICByZXR3ZWV0czogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcbiAgICAgICAgcmVwbGllczogbnVtT3JaZXJvKGxlZ2FjeS5yZXBseV9jb3VudCksXG4gICAgICAgIHF1b3RlczogbnVtT3JaZXJvKGxlZ2FjeS5xdW90ZV9jb3VudCksXG4gICAgICAgIHZpZXdzOiB2aWV3Q291bnQsXG4gICAgICAgIGJvb2ttYXJrczogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXG4gICAgICB9LFxuICAgIF0sXG4gICAgd2F5YmFja191cmw6IG51bGwsXG4gICAgd2F5YmFja19zdWJtaXR0ZWRfYXQ6IG51bGwsXG4gICAgY2FwdHVyZV9zb3VyY2U6ICdleHRlbnNpb24nLFxuICAgIGNhcHR1cmVfcnVuX2lkOiBjdHgucnVuSWQsXG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gIH07XG5cbiAgcmV0dXJuIHR3ZWV0O1xufVxuXG5mdW5jdGlvbiBjbGFzc2lmeVR3ZWV0VHlwZSh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFR3ZWV0VHlwZSB7XG4gIGlmIChsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQgfHwgbGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JldHdlZXQnO1xuICBpZiAobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpIHJldHVybiAncmVwbHknO1xuICBpZiAobGVnYWN5LmlzX3F1b3RlX3N0YXR1cyA9PT0gdHJ1ZSB8fCBsZWdhY3kucXVvdGVkX3N0YXR1c19pZF9zdHIpIHJldHVybiAncXVvdGUnO1xuICBpZiAodC5fX3R5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnKSB7XG4gICAgLy8gcGFzcyB0aHJvdWdoXG4gIH1cbiAgcmV0dXJuICdvcmlnaW5hbCc7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RIYXNodGFncyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLmhhc2h0YWdzO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICByZXR1cm4gYXJyXG4gICAgLm1hcCgoaCkgPT5cbiAgICAgIHR5cGVvZiBoID09PSAnb2JqZWN0JyAmJiBoICYmICd0ZXh0JyBpbiBoID8gU3RyaW5nKChoIGFzIHsgdGV4dDogdW5rbm93biB9KS50ZXh0KSA6IG51bGxcbiAgICApXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0TWVudGlvbnMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy51c2VyX21lbnRpb25zO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICByZXR1cm4gYXJyXG4gICAgLm1hcCgodSkgPT5cbiAgICAgIHR5cGVvZiB1ID09PSAnb2JqZWN0JyAmJiB1ICYmICdzY3JlZW5fbmFtZScgaW4gdVxuICAgICAgICA/IFN0cmluZygodSBhcyB7IHNjcmVlbl9uYW1lOiB1bmtub3duIH0pLnNjcmVlbl9uYW1lKVxuICAgICAgICA6IG51bGxcbiAgICApXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0VXJscyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBVcmxFbnRpdHlbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLnVybHM7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XG4gIGNvbnN0IG91dDogVXJsRW50aXR5W10gPSBbXTtcbiAgZm9yIChjb25zdCB1IG9mIGFycikge1xuICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XG4gICAgY29uc3QgbyA9IHUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgY29uc3Qgc2hvcnQgPSBzdHJPck51bGwoby51cmwpO1xuICAgIGNvbnN0IGV4cGFuZGVkID0gc3RyT3JOdWxsKG8uZXhwYW5kZWRfdXJsKTtcbiAgICBjb25zdCBkaXNwbGF5ID0gc3RyT3JOdWxsKG8uZGlzcGxheV91cmwpO1xuICAgIGlmICghc2hvcnQgfHwgIWV4cGFuZGVkKSBjb250aW51ZTtcbiAgICBvdXQucHVzaCh7IHNob3J0LCBleHBhbmRlZCwgZGlzcGxheTogZGlzcGxheSA/PyBleHBhbmRlZCB9KTtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBleHRyYWN0TWVkaWEobGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbVtdIHtcbiAgY29uc3QgZXh0ZW5kZWQgPSBvYmoobGVnYWN5LmV4dGVuZGVkX2VudGl0aWVzKTtcbiAgY29uc3QgZnJvbUV4dCA9IGV4dGVuZGVkID8gdG9BcnJheShleHRlbmRlZC5tZWRpYSkgOiBbXTtcbiAgY29uc3QgZnJvbUVudCA9IHRvQXJyYXkob2JqKGxlZ2FjeS5lbnRpdGllcyk/Lm1lZGlhKTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCBtZXJnZWQgPSBbLi4uZnJvbUV4dCwgLi4uZnJvbUVudF0uZmlsdGVyKChtKSA9PiB7XG4gICAgaWYgKHR5cGVvZiBtICE9PSAnb2JqZWN0JyB8fCBtID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgaWQgPVxuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5tZWRpYV9rZXkpID8/XG4gICAgICBzdHJPck51bGwoKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLmlkX3N0cik7XG4gICAgaWYgKCFpZCkgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChzZWVuLmhhcyhpZCkpIHJldHVybiBmYWxzZTtcbiAgICBzZWVuLmFkZChpZCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuICByZXR1cm4gbWVyZ2VkLm1hcCgocmF3KSA9PiBidWlsZE1lZGlhKHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpO1xufVxuXG5mdW5jdGlvbiBidWlsZE1lZGlhKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogTWVkaWFJdGVtIHtcbiAgY29uc3QgdHlwZSA9IHN0ck9yTnVsbChtLnR5cGUpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddO1xuICBjb25zdCBvcmlnaW5hbCA9IHBpY2tPcmlnaW5hbFVybChtLCB0eXBlKTtcbiAgY29uc3QgaW5mbyA9IG9iaihtLm9yaWdpbmFsX2luZm8pO1xuICBjb25zdCB2aWRlb0luZm8gPSBvYmoobS52aWRlb19pbmZvKTtcbiAgY29uc3QgZHVyYXRpb25NcyA9IG51bU9yTnVsbCh2aWRlb0luZm8/LmR1cmF0aW9uX21pbGxpcyk7XG4gIGNvbnN0IGFsdFRleHQgPSBzdHJPck51bGwobS5leHRfYWx0X3RleHQpO1xuICBjb25zdCBtZWRpYUlkID1cbiAgICBzdHJPck51bGwobS5tZWRpYV9rZXkpID8/XG4gICAgc3RyT3JOdWxsKG0uaWRfc3RyKSA/P1xuICAgIGAke3R5cGUgPz8gJ21lZGlhJ30tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKX1gO1xuICByZXR1cm4ge1xuICAgIG1lZGlhX2lkOiBtZWRpYUlkLFxuICAgIG1lZGlhX3R5cGU6ICh0eXBlID8/ICdwaG90bycpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddLFxuICAgIG9yaWdpbmFsX3VybDogb3JpZ2luYWwgPz8gJycsXG4gICAgcmVsZWFzZV9hc3NldF91cmw6IG51bGwsXG4gICAgc2hhMjU2OiBudWxsLFxuICAgIGJ5dGVzOiBudWxsLFxuICAgIGR1cmF0aW9uX3NlYzogZHVyYXRpb25NcyAhPT0gbnVsbCA/IGR1cmF0aW9uTXMgLyAxMDAwIDogbnVsbCxcbiAgICB3aWR0aDogbnVtT3JOdWxsKGluZm8/LndpZHRoKSxcbiAgICBoZWlnaHQ6IG51bU9yTnVsbChpbmZvPy5oZWlnaHQpLFxuICAgIGFsdF90ZXh0OiBhbHRUZXh0LFxuICAgIGFyY2hpdmVfc3RhdHVzOiAncGVuZGluZycsXG4gICAgYXJjaGl2ZV9hdHRlbXB0czogMCxcbiAgICBsYXN0X2F0dGVtcHRfYXQ6IG51bGwsXG4gIH07XG59XG5cbmZ1bmN0aW9uIHBpY2tPcmlnaW5hbFVybChtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdHlwZTogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAodHlwZSA9PT0gJ3Bob3RvJykgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcykgPz8gc3RyT3JOdWxsKG0ubWVkaWFfdXJsKTtcbiAgY29uc3QgdmFyaWFudHMgPSB0b0FycmF5KG9iaihtLnZpZGVvX2luZm8pPy52YXJpYW50cykgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj5bXTtcbiAgaWYgKHZhcmlhbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcyk7XG4gIC8vIEhpZ2hlc3QtYml0cmF0ZSBtcDQuXG4gIGxldCBiZXN0OiB7IHVybDogc3RyaW5nOyBiaXRyYXRlOiBudW1iZXIgfSB8IG51bGwgPSBudWxsO1xuICBmb3IgKGNvbnN0IHYgb2YgdmFyaWFudHMpIHtcbiAgICBjb25zdCBjdCA9IHN0ck9yTnVsbCh2LmNvbnRlbnRfdHlwZSk7XG4gICAgY29uc3QgdXJsID0gc3RyT3JOdWxsKHYudXJsKTtcbiAgICBpZiAoIXVybCkgY29udGludWU7XG4gICAgaWYgKGN0ID09PSAndmlkZW8vbXA0Jykge1xuICAgICAgY29uc3QgYnIgPSBudW1Pck51bGwodi5iaXRyYXRlKSA/PyAwO1xuICAgICAgaWYgKCFiZXN0IHx8IGJyID4gYmVzdC5iaXRyYXRlKSBiZXN0ID0geyB1cmwsIGJpdHJhdGU6IGJyIH07XG4gICAgfSBlbHNlIGlmICghYmVzdCkge1xuICAgICAgLy8gRmFsbGJhY2sgdG8gYW55IHZhcmlhbnQgaWYgbm8gbXA0IGZvdW5kLlxuICAgICAgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiAwIH07XG4gICAgfVxuICB9XG4gIHJldHVybiBiZXN0Py51cmwgPz8gbnVsbDtcbn1cblxuZnVuY3Rpb24gcmVzb2x2ZVNob3J0VXJscyh0ZXh0OiBzdHJpbmcsIHVybHM6IFVybEVudGl0eVtdKTogc3RyaW5nIHtcbiAgaWYgKHVybHMubGVuZ3RoID09PSAwKSByZXR1cm4gdGV4dDtcbiAgbGV0IG91dCA9IHRleHQ7XG4gIGZvciAoY29uc3QgdSBvZiB1cmxzKSBvdXQgPSBvdXQuc3BsaXQodS5zaG9ydCkuam9pbih1LmV4cGFuZGVkKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gcGFyc2VUd2l0dGVyRGF0ZShzOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICghcykgcmV0dXJuIG51bGw7XG4gIC8vIFR3aXR0ZXIgc2hpcHMgZGF0ZXMgbGlrZSBcIk1vbiBBcHIgMTIgMTQ6MjM6MDEgKzAwMDAgMjAyNVwiLlxuICBjb25zdCBkID0gbmV3IERhdGUocyk7XG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIGQudG9JU09TdHJpbmcoKTtcbn1cblxuZnVuY3Rpb24gc3RyT3JOdWxsKHY6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDAgPyB2IDogbnVsbDtcbn1cbmZ1bmN0aW9uIG51bU9yTnVsbCh2OiB1bmtub3duKTogbnVtYmVyIHwgbnVsbCB7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ251bWJlcicgJiYgTnVtYmVyLmlzRmluaXRlKHYpKSByZXR1cm4gdjtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gTnVtYmVyKHYpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikpIHJldHVybiBuO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gbnVtT3JaZXJvKHY6IHVua25vd24pOiBudW1iZXIge1xuICByZXR1cm4gbnVtT3JOdWxsKHYpID8/IDA7XG59XG5mdW5jdGlvbiBvYmoodjogdW5rbm93bik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ29iamVjdCcgJiYgdiAhPT0gbnVsbCAmJiAhQXJyYXkuaXNBcnJheSh2KVxuICAgID8gKHYgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pXG4gICAgOiBudWxsO1xufVxuZnVuY3Rpb24gdG9BcnJheSh2OiB1bmtub3duKTogdW5rbm93bltdIHtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkodikgPyB2IDogW107XG59XG4iLCAiLyoqXG4gKiBMaWdodHdlaWdodCBVTElELWxpa2UgaWQgZ2VuZXJhdG9yOiAyNi1jaGFyYWN0ZXIgQ3JvY2tmb3JkIGJhc2UzMiBzdHJpbmdcbiAqIG9mICh0aW1lc3RhbXBfbXMgfHwgcmFuZG9tbmVzcykuIEdvb2QgZW5vdWdoIGZvciBydW4gaWRlbnRpZmllcnMgd2l0aG91dFxuICogcHVsbGluZyBpbiBhIHJlYWwgVUxJRCBkZXBlbmRlbmN5LlxuICovXG5cbmNvbnN0IEFMUEhBQkVUID0gJzAxMjM0NTY3ODlBQkNERUZHSEpLTU5QUVJTVFZXWFlaJzsgLy8gQ3JvY2tmb3JkXG5cbmV4cG9ydCBmdW5jdGlvbiBuZXdSdW5JZCgpOiBzdHJpbmcge1xuICBjb25zdCB0cyA9IERhdGUubm93KCk7XG4gIGxldCB0c1BhcnQgPSAnJztcbiAgbGV0IHQgPSB0cztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDsgaSsrKSB7XG4gICAgdHNQYXJ0ID0gKEFMUEhBQkVUW3QgJSAzMl0gPz8gJzAnKSArIHRzUGFydDtcbiAgICB0ID0gTWF0aC5mbG9vcih0IC8gMzIpO1xuICB9XG4gIGNvbnN0IHJhbmQgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEwKSk7XG4gIGxldCByYW5kUGFydCA9ICcnO1xuICBmb3IgKGNvbnN0IGIgb2YgcmFuZCkgcmFuZFBhcnQgKz0gQUxQSEFCRVRbYiAlIDMyXSA/PyAnMCc7XG4gIHJldHVybiB0c1BhcnQgKyByYW5kUGFydDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNob3J0UnVuSWQoaWQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBpZC5zbGljZSgtOCk7XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTWluaW1hbCBwYXJzZXIgZm9yIHRoZSBzdHJpY3Qgc2hhcGUgdXNlZCBieSBgY29uZmlnL2FjY291bnRzLnlhbWxgOlxuICpcbiAqICAgYWNjb3VudHM6XG4gKiAgICAgLSBoYW5kbGU6IERIU2dvdlxuICogICAgICAgbGFiZWw6IERlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHlcbiAqXG4gKiBXZSBkZWxpYmVyYXRlbHkgZG9uJ3QgcHVsbCBpbiBhIGZ1bGwgWUFNTCBsaWJyYXJ5IFx1MjAxNCB3ZSBjb250cm9sIGJvdGggZW5kcyBvZlxuICogdGhpcyBmaWxlLCBhbmQgYSA1MC1saW5lIHBhcnNlciBpcyBlYXNpZXIgdG8gYXVkaXQgdGhhbiB0aGUgYWx0ZXJuYXRpdmVzLlxuICogVW5rbm93biBrZXlzIGFuZCBjb21tZW50cyBhcmUgdG9sZXJhdGVkOyBtYWxmb3JtZWQgbGluZXMgYXJlIHNraXBwZWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUFjY291bnRzWWFtbCh0ZXh0OiBzdHJpbmcpOiBBY2NvdW50Q29uZmlnW10ge1xuICBjb25zdCBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdID0gW107XG4gIGxldCBjdXJyZW50OiBQYXJ0aWFsPEFjY291bnRDb25maWc+ID0ge307XG4gIGxldCBpbkFjY291bnRzID0gZmFsc2U7XG4gIGZvciAoY29uc3QgcmF3TGluZSBvZiB0ZXh0LnNwbGl0KCdcXG4nKSkge1xuICAgIGNvbnN0IGxpbmUgPSBzdHJpcENvbW1lbnRzKHJhd0xpbmUpO1xuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gJycpIGNvbnRpbnVlO1xuICAgIGlmICgvXmFjY291bnRzXFxzKjovLnRlc3QobGluZSkpIHtcbiAgICAgIGluQWNjb3VudHMgPSB0cnVlO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICghaW5BY2NvdW50cykgY29udGludWU7XG5cbiAgICBjb25zdCBpdGVtTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKi1cXHMqaGFuZGxlXFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoaXRlbU1hdGNoKSB7XG4gICAgICBpZiAoY3VycmVudC5oYW5kbGUgJiYgY3VycmVudC5sYWJlbCkgYWNjb3VudHMucHVzaChjdXJyZW50IGFzIEFjY291bnRDb25maWcpO1xuICAgICAgY3VycmVudCA9IHsgaGFuZGxlOiB1bnF1b3RlKGl0ZW1NYXRjaFsxXSA/PyAnJykgfTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBoYW5kbGVPbmx5ID0gbGluZS5tYXRjaCgvXlxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChoYW5kbGVPbmx5ICYmICFsaW5lLmluY2x1ZGVzKCctJykpIHtcbiAgICAgIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSBhY2NvdW50cy5wdXNoKGN1cnJlbnQgYXMgQWNjb3VudENvbmZpZyk7XG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaGFuZGxlT25seVsxXSA/PyAnJykgfTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBsYWJlbE1hdGNoID0gbGluZS5tYXRjaCgvXlxccypsYWJlbFxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGxhYmVsTWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcbiAgICAgIGN1cnJlbnQubGFiZWwgPSB1bnF1b3RlKGxhYmVsTWF0Y2hbMV0gPz8gJycpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICB9XG4gIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSBhY2NvdW50cy5wdXNoKGN1cnJlbnQgYXMgQWNjb3VudENvbmZpZyk7XG4gIHJldHVybiBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuaGFuZGxlLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBzdHJpcENvbW1lbnRzKGxpbmU6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIE5haXZlIGJ1dCBhZGVxdWF0ZSBmb3Igb3VyIGZvcm1hdDogc3RyaXAgZXZlcnl0aGluZyBhZnRlciBhIGAjYCB0aGF0IGlzbid0XG4gIC8vIGluc2lkZSBxdW90ZXMuIE91ciBjb25maWcgbmV2ZXIgdXNlcyBpbmxpbmUgc3RyaW5ncyB3aXRoIGAjYC5cbiAgY29uc3QgaWR4ID0gbGluZS5pbmRleE9mKCcjJyk7XG4gIHJldHVybiBpZHggPT09IC0xID8gbGluZSA6IGxpbmUuc2xpY2UoMCwgaWR4KTtcbn1cblxuZnVuY3Rpb24gdW5xdW90ZShzOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCB0cmltbWVkID0gcy50cmltKCk7XG4gIGlmIChcbiAgICAodHJpbW1lZC5zdGFydHNXaXRoKCdcIicpICYmIHRyaW1tZWQuZW5kc1dpdGgoJ1wiJykpIHx8XG4gICAgKHRyaW1tZWQuc3RhcnRzV2l0aChcIidcIikgJiYgdHJpbW1lZC5lbmRzV2l0aChcIidcIikpXG4gICkge1xuICAgIHJldHVybiB0cmltbWVkLnNsaWNlKDEsIC0xKTtcbiAgfVxuICByZXR1cm4gdHJpbW1lZDtcbn1cbiIsICIvKipcbiAqIGJhY2tncm91bmQudHMgXHUyMDE0IGV4dGVuc2lvbiBzZXJ2aWNlIHdvcmtlci5cbiAqXG4gKiBPd25zIHRoZSBjYXB0dXJlIHBpcGVsaW5lOiByZWNlaXZlcyBgZ3JhcGhxbC1jYXB0dXJlYCBtZXNzYWdlcyBmcm9tIHRoZVxuICogY29udGVudCBzY3JpcHQsIG5vcm1hbGl6ZXMgdGhlbSwgYWNjdW11bGF0ZXMgcGVyLWhhbmRsZSBydW4gYnVmZmVycyBpblxuICogYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAsIGFuZCBjb21taXRzIHRoZW0gdG8gdGhlIGNvbmZpZ3VyZWQgR2l0SHViIHJlcG9cbiAqIHZpYSB0aGUgQ29udGVudHMgQVBJLlxuICpcbiAqIFNlcnZpY2Ugd29ya2VycyBpbiBNVjMgbWF5IGJlIGV2aWN0ZWQgYXQgYW55IHRpbWUsIHNvIGFsbCBjcml0aWNhbCBzdGF0ZVxuICogbGl2ZXMgaW4gc3RvcmFnZSAobmV2ZXIgbW9kdWxlLXNjb3BlKS4gT24gZXZlcnkgd2FrZSB3ZSByZS1kZXJpdmUgd2hhdCB3ZVxuICogbmVlZDsgcGVuZGluZyBmbHVzaGVzIGFyZSBkcml2ZW4gYnkgYGJyb3dzZXIuYWxhcm1zYCByYXRoZXIgdGhhbiB0aW1lcnMuXG4gKi9cblxuaW1wb3J0IHtcbiAgRkFMTEJBQ0tfQUNDT1VOVFMsXG4gIEZMVVNIX0FMQVJNX01JTlVURVMsXG4gIEZMVVNIX0lETEVfTVMsXG4gIEZMVVNIX1RXRUVUX1RIUkVTSE9MRCxcbiAgUFJPRklMRV9FTkRQT0lOVFMsXG4gIFRXRUVUX0VORFBPSU5UUyxcbiAgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMsXG59IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XG5pbXBvcnQgeyBHaXRIdWJDbGllbnQsIEdpdEh1YkVycm9yLCB0b0Jhc2U2NCB9IGZyb20gJy4vbGliL2dpdGh1Yi5qcyc7XG5pbXBvcnQgeyBkZXNjcmliZUVycm9yLCBlcnJvciBhcyBsb2dFcnIsIGluZm8sIHNldEJyb2FkY2FzdGVyLCB3YXJuIH0gZnJvbSAnLi9saWIvbG9nZ2VyLmpzJztcbmltcG9ydCB7IG5vcm1hbGl6ZSB9IGZyb20gJy4vbGliL25vcm1hbGl6ZS5qcyc7XG5pbXBvcnQgeyBuZXdSdW5JZCwgc2hvcnRSdW5JZCB9IGZyb20gJy4vbGliL3J1bmlkcy5qcyc7XG5pbXBvcnQge1xuICBidW1wQ291bnRlcixcbiAgY2xlYXJBY3Rpdml0eSxcbiAgY2xlYXJBbGwsXG4gIGNsZWFyUnVuQnVmZmVyLFxuICBnZXRBY2NvdW50cyxcbiAgZ2V0QWN0aXZpdHksXG4gIGdldENvbm5lY3Rpb24sXG4gIGdldENvdW50ZXJzLFxuICBnZXRSdW5CdWZmZXIsXG4gIGdldFJ1bkJ1ZmZlcnMsXG4gIGdldFNldHRpbmdzLFxuICBzZXRBY2NvdW50cyxcbiAgc2V0QnVmZmVyZWRDb3VudCxcbiAgc2V0Q29ubmVjdGlvbixcbiAgc2V0UnVuQnVmZmVyLFxuICB0eXBlIFJ1bkJ1ZmZlcixcbiAgdXBkYXRlU2V0dGluZ3MsXG59IGZyb20gJy4vbGliL3N0b3JhZ2UuanMnO1xuaW1wb3J0IHR5cGUge1xuICBDYW5vbmljYWxUd2VldCxcbiAgQ2FwdHVyZVBheWxvYWQsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgRXh0ZW5zaW9uU3RhdGUsXG4gIExvZ0V2ZW50LFxuICBRdWFyYW50aW5lUGF5bG9hZCxcbiAgUnVudGltZU1lc3NhZ2UsXG4gIFNlZW5QYXlsb2FkLFxuICBTZXR0aW5ncyxcbn0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xuaW1wb3J0IHsgcGFyc2VBY2NvdW50c1lhbWwgfSBmcm9tICcuL2xpYi95YW1sLmpzJztcblxuY29uc3QgRVhUX1ZFUlNJT04gPSBicm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uO1xuXG5zZXRCcm9hZGNhc3RlcigoZXY6IExvZ0V2ZW50KSA9PiB7XG4gIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdsb2ctZXZlbnQnLCBldmVudDogZXYgfSkuY2F0Y2goKCkgPT4ge30pO1xufSk7XG5cbi8vIC0tLSBXYWtlIGhhbmRsZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmJyb3dzZXIucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XG4gIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBpbnN0YWxsZWQnLCB7IHZlcnNpb246IEVYVF9WRVJTSU9OIH0pO1xuICBhd2FpdCBvbldha2UoJ2luc3RhbGwnKTtcbn0pO1xuXG5icm93c2VyLnJ1bnRpbWUub25TdGFydHVwLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgdm9pZCBvbldha2UoJ3N0YXJ0dXAnKTtcbn0pO1xuXG4vLyBGb3JjZSBhdCBsZWFzdCBvbmUgd2FrZSB0byByZWdpc3RlciBhbGFybXMgLyB2ZXJpZnkgY29ubmVjdGlvbi5cbnZvaWQgb25XYWtlKCdtb2R1bGUtbG9hZCcpO1xuXG5hc3luYyBmdW5jdGlvbiBvbldha2UocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBlbnN1cmVBbGFybXMoKTtcbiAgICBhd2FpdCBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTtcbiAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgaWYgKHNldHRpbmdzLnBhdCAmJiBzZXR0aW5ncy5vd25lciAmJiBzZXR0aW5ncy5yZXBvKSB7XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgICAgIGF3YWl0IHJlZnJlc2hBY2NvdW50c0xpc3QoZmFsc2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgICBsb2dpbjogbnVsbCxcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBpbmZvKCdleHRlbnNpb24gYXdha2U7IHNldHRpbmdzIGluY29tcGxldGUnLCB7IHJlYXNvbiB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IGxvZ0Vycignd2FrZSBmYWlsZWQnLCB7IHJlYXNvbiwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUFsYXJtcygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ2ZsdXNoLXN3ZWVwJyk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd2ZXJpZnktY29ubmVjdGlvbicpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jcmVhdGUoJ2ZsdXNoLXN3ZWVwJywgeyBwZXJpb2RJbk1pbnV0ZXM6IEZMVVNIX0FMQVJNX01JTlVURVMgfSk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgndmVyaWZ5LWNvbm5lY3Rpb24nLCB7XG4gICAgcGVyaW9kSW5NaW51dGVzOiBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyAvIDYwXzAwMCxcbiAgfSk7XG59XG5cbmJyb3dzZXIuYWxhcm1zLm9uQWxhcm0uYWRkTGlzdGVuZXIoKGFsYXJtKSA9PiB7XG4gIGlmIChhbGFybS5uYW1lID09PSAnZmx1c2gtc3dlZXAnKSB7XG4gICAgdm9pZCBmbHVzaElkbGVCdWZmZXJzKCk7XG4gIH0gZWxzZSBpZiAoYWxhcm0ubmFtZSA9PT0gJ3ZlcmlmeS1jb25uZWN0aW9uJykge1xuICAgIHZvaWQgdmVyaWZ5Q29ubmVjdGlvbihmYWxzZSk7XG4gIH1cbn0pO1xuXG4vLyAtLS0gVG9vbGJhciBhY3Rpb246IHRvZ2dsZSB0aGUgc2lkZWJhciAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5pZiAoYnJvd3Nlci5hY3Rpb24/Lm9uQ2xpY2tlZCkge1xuICBicm93c2VyLmFjdGlvbi5vbkNsaWNrZWQuYWRkTGlzdGVuZXIoYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnNpZGViYXJBY3Rpb24udG9nZ2xlKCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAvLyBGYWxsYmFjazogb3BlbiBvcHRpb25zIGlmIHNpZGViYXIgY2FuJ3QgYmUgdG9nZ2xlZC5cbiAgICAgIGF3YWl0IHdhcm4oJ3NpZGViYXIgdG9nZ2xlIGZhaWxlZDsgb3BlbmluZyBvcHRpb25zJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICAgIGF3YWl0IGJyb3dzZXIucnVudGltZS5vcGVuT3B0aW9uc1BhZ2UoKTtcbiAgICB9XG4gIH0pO1xufVxuXG4vLyAtLS0gUnVudGltZSBtZXNzYWdlIGRpc3BhdGNoIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93biwgX3NlbmRlcikgPT4ge1xuICBpZiAoIWlzUnVudGltZU1lc3NhZ2UobXNnKSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgcmV0dXJuIGhhbmRsZU1lc3NhZ2UobXNnKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgdm9pZCBsb2dFcnIoJ21lc3NhZ2UgaGFuZGxlciBmYWlsZWQnLCB7IHR5cGU6IG1zZy50eXBlLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gICAgdGhyb3cgZXJyO1xuICB9KTtcbn0pO1xuXG5mdW5jdGlvbiBpc1J1bnRpbWVNZXNzYWdlKG06IHVua25vd24pOiBtIGlzIFJ1bnRpbWVNZXNzYWdlIHtcbiAgcmV0dXJuICEhbSAmJiB0eXBlb2YgbSA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIChtIGFzIHsgdHlwZT86IHVua25vd24gfSkudHlwZSA9PT0gJ3N0cmluZyc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UobXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8dW5rbm93bj4ge1xuICBzd2l0Y2ggKG1zZy50eXBlKSB7XG4gICAgY2FzZSAnZ3JhcGhxbC1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IG9uR3JhcGhxbENhcHR1cmUobXNnLmVuZHBvaW50LCBtc2cudXJsLCBtc2cucmVzcG9uc2UpO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdjb250ZW50LWFsaXZlJzpcbiAgICAgIGF3YWl0IGluZm8oJ2NvbnRlbnQgc2NyaXB0IGFsaXZlIG9uIHBhZ2UnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAncGFnZS1ob29rLWFjdGl2ZSc6XG4gICAgICBhd2FpdCBpbmZvKCdwYWdlIGhvb2sgcGF0Y2hlZCBmZXRjaC9YSFInLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnbG9nLWNvbnRlbnQtZXZlbnQnOlxuICAgICAgaWYgKG1zZy5sZXZlbCA9PT0gJ3dhcm4nKSB7XG4gICAgICAgIGF3YWl0IHdhcm4obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9IGVsc2UgaWYgKG1zZy5sZXZlbCA9PT0gJ2Vycm9yJykge1xuICAgICAgICBhd2FpdCBsb2dFcnIobXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCBpbmZvKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdnZXQtc3RhdGUnOlxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLW5vdyc6XG4gICAgICBhd2FpdCBjYXB0dXJlTm93KG1zZy5oYW5kbGUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLWFsbCc6XG4gICAgICBhd2FpdCBjYXB0dXJlQWxsKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2ZsdXNoLWFsbCc6XG4gICAgICBhd2FpdCBmbHVzaEFsbCgndXNlcicpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdmbHVzaC1oYW5kbGUnOlxuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUobXNnLmhhbmRsZSwgJ3VzZXInKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAndG9nZ2xlLWF1dG8tY2FwdHVyZSc6XG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGF1dG9DYXB0dXJlOiBtc2cub24gfSk7XG4gICAgICBhd2FpdCBpbmZvKCdhdXRvLWNhcHR1cmUgdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAncmVmcmVzaC1hY2NvdW50cyc6XG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd2ZXJpZnktY29ubmVjdGlvbic6XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjbGVhci1hY3Rpdml0eSc6XG4gICAgICBhd2FpdCBjbGVhckFjdGl2aXR5KCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tb3B0aW9ucyc6XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tdmlld2VyJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgICBjb25zdCB1cmwgPSB2aWV3ZXJVcmwocyk7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICd1bmtub3duIG1lc3NhZ2UgdHlwZScgfTtcbiAgfVxufVxuXG4vLyAtLS0gQ2FwdHVyZSBwaXBlbGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBvbkdyYXBocWxDYXB0dXJlKGVuZHBvaW50OiBzdHJpbmcsIHVybDogc3RyaW5nLCByZXNwb25zZTogdW5rbm93bik6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoUFJPRklMRV9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuOyAvLyBub3QgdHdlZXQtYmVhcmluZ1xuICBpZiAoIVRXRUVUX0VORFBPSU5UUy5oYXMoZW5kcG9pbnQpKSByZXR1cm47XG5cbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICAvLyBXZSBkZWxpYmVyYXRlbHkgZG8gTk9UIHNob3J0LWNpcmN1aXQgd2hlbiB0aGUgUEFUIGlzIG1pc3NpbmcuIFRoZVxuICAvLyBub3JtYWxpemUgc3RlcCBpcyBjaGVhcCwgdGhlIGJ1ZmZlciBzdXJ2aXZlcyBzZXJ2aWNlLXdvcmtlciBldmljdGlvbixcbiAgLy8gYW5kIG9uY2UgdGhlIFBBVCBpcyBzZXQgdGhlIG5leHQgYWxhcm0gb3IgdXNlci10cmlnZ2VyZWQgZmx1c2ggY29tbWl0c1xuICAvLyBldmVyeXRoaW5nIHdlJ3ZlIHNlZW4uIERyb3BwaW5nIGNhcHR1cmVzIGhlcmUgd2FzIGhpZGluZyB0aGUgdXNlcidzXG4gIC8vIGZpcnN0IGJyb3dzaW5nIHNlc3Npb24gZW50aXJlbHkuXG5cbiAgY29uc3QgYWxsb3dlZCA9IG5ldyBTZXQoYWNjb3VudHMubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKSk7XG4gIGNvbnN0IGNhcHR1cmVkQXQgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG5cbiAgbGV0IG5vcm1hbGl6ZWQ7XG4gIHRyeSB7XG4gICAgbm9ybWFsaXplZCA9IG5vcm1hbGl6ZShyZXNwb25zZSwge1xuICAgICAgY2FwdHVyZWRBdCxcbiAgICAgIHJ1bklkOiAncGVuZGluZycsXG4gICAgICBlbmRwb2ludCxcbiAgICAgIGFsbG93ZWRIYW5kbGVzOiBhbGxvd2VkLFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCBxdWFyYW50aW5lKCdub3JtYWxpemUtdGhyZXcnLCBlbmRwb2ludCwgdXJsLCByZXNwb25zZSwgZXJyKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBEaWFnbm9zdGljOiBldmVyeSB0d2VldC1lbmRwb2ludCBwYXlsb2FkIGdldHMgYSBsaW5lIGluIHRoZSBhY3Rpdml0eVxuICAvLyB0YWlsIHdpdGggd2hhdCB3ZSBzYXcgdnMga2VwdC4gV2hlbiBvYnNlcnZlZD0wIHdlIGFsc28gZW1pdCBhIHNoYXBlXG4gIC8vIHByb2JlIChrZXkgcGF0aHMgKyB0eXBlbmFtZXMpIHNvIHdlIGNhbiB0ZWxsIHdoZXRoZXIgWCByZXR1cm5lZCBhblxuICAvLyBlbXB0eSBlbnZlbG9wZSwgYSBsb2dpbi13YWxsIHJlc3BvbnNlLCBvciBhIG5ldyBzaGFwZSB3ZSBkb24ndCBrbm93IGhvd1xuICAvLyB0byB3YWxrIHlldC5cbiAgaWYgKG5vcm1hbGl6ZWQub2JzZXJ2ZWRfaWRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGF3YWl0IGluZm8oJ2dyYXBocWwgcGF5bG9hZCBlbXB0eSBcdTIwMTQgc2hhcGUgcHJvYmUnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIGtleV9wYXRoczogcHJvYmVLZXlQYXRocyhyZXNwb25zZSwgNCkuc2xpY2UoMCwgNDApLFxuICAgICAgdHlwZW5hbWVzOiBwcm9iZVR5cGVuYW1lcyhyZXNwb25zZSkuc2xpY2UoMCwgMzApLFxuICAgICAgaGFzX2Vycm9yczogaGFzRXJyb3JzRmllbGQocmVzcG9uc2UpLFxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGF3YWl0IGluZm8oJ2dyYXBocWwgcGF5bG9hZCBzZWVuJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBvYnNlcnZlZDogbm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoLFxuICAgICAga2VwdDogbm9ybWFsaXplZC50d2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG5cbiAgaWYgKG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gIC8vIEdyb3VwIHR3ZWV0cyBieSBhdXRob3IgaGFuZGxlLlxuICBjb25zdCBieUhhbmRsZSA9IG5ldyBNYXA8c3RyaW5nLCBDYW5vbmljYWxUd2VldFtdPigpO1xuICBmb3IgKGNvbnN0IHQgb2Ygbm9ybWFsaXplZC50d2VldHMpIHtcbiAgICBjb25zdCBhcnIgPSBieUhhbmRsZS5nZXQodC5hY2NvdW50X2hhbmRsZSkgPz8gW107XG4gICAgYXJyLnB1c2godCk7XG4gICAgYnlIYW5kbGUuc2V0KHQuYWNjb3VudF9oYW5kbGUsIGFycik7XG4gIH1cblxuICBmb3IgKGNvbnN0IFtoYW5kbGUsIHR3ZWV0c10gb2YgYnlIYW5kbGUpIHtcbiAgICBjb25zdCBidWYgPSBhd2FpdCBlbnN1cmVSdW5CdWZmZXIoaGFuZGxlLCBjYXB0dXJlZEF0LCB1cmwsIGVuZHBvaW50KTtcbiAgICBsZXQgYWRkZWQgPSAwO1xuICAgIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICAgIGNvbnN0IGV4aXN0aW5nID0gYnVmLnR3ZWV0c19ieV9pZFt0LnR3ZWV0X2lkXTtcbiAgICAgIGlmIChleGlzdGluZykge1xuICAgICAgICAvLyBQcmVzZXJ2ZSBmaXJzdF9jYXB0dXJlZF9hdCwgYXBwZW5kIGVuZ2FnZW1lbnQgc25hcHNob3QsIHJlZnJlc2hcbiAgICAgICAgLy8gbGFzdF9zZWVuX2F0ICsgY291bnRzICh0aGUgbGF0ZXN0IHNjcmFwZSB3aW5zIGZvciBjb3VudHMpLlxuICAgICAgICBleGlzdGluZy5sYXN0X3NlZW5fYXQgPSBjYXB0dXJlZEF0O1xuICAgICAgICBleGlzdGluZy5saWtlX2NvdW50ID0gdC5saWtlX2NvdW50O1xuICAgICAgICBleGlzdGluZy5yZXR3ZWV0X2NvdW50ID0gdC5yZXR3ZWV0X2NvdW50O1xuICAgICAgICBleGlzdGluZy5yZXBseV9jb3VudCA9IHQucmVwbHlfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnF1b3RlX2NvdW50ID0gdC5xdW90ZV9jb3VudDtcbiAgICAgICAgZXhpc3Rpbmcudmlld19jb3VudCA9IHQudmlld19jb3VudDtcbiAgICAgICAgZXhpc3RpbmcuYm9va21hcmtfY291bnQgPSB0LmJvb2ttYXJrX2NvdW50O1xuICAgICAgICBjb25zdCBsYXN0ID0gZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5W2V4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeS5sZW5ndGggLSAxXTtcbiAgICAgICAgY29uc3Qgc25hcCA9IHQuZW5nYWdlbWVudF9oaXN0b3J5WzBdO1xuICAgICAgICBpZiAoc25hcCAmJiAoIWxhc3QgfHwgbGFzdC5jYXB0dXJlZF9hdCAhPT0gc25hcC5jYXB0dXJlZF9hdCkpIHtcbiAgICAgICAgICBleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnkucHVzaChzbmFwKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3Qgc3RhbXBlZDogQ2Fub25pY2FsVHdlZXQgPSB7IC4uLnQsIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkIH07XG4gICAgICAgIGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF0gPSBzdGFtcGVkO1xuICAgICAgICBhZGRlZCArPSAxO1xuICAgICAgfVxuICAgICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHQudHdlZXRfaWQpKSB7XG4gICAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFidWYuZW5kcG9pbnRzX3NlZW4uaW5jbHVkZXMoZW5kcG9pbnQpKSBidWYuZW5kcG9pbnRzX3NlZW4ucHVzaChlbmRwb2ludCk7XG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcbiAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoKTtcbiAgICBpZiAoYWRkZWQgPiAwKSB7XG4gICAgICBhd2FpdCBpbmZvKCdjYXB0dXJlZCB0d2VldHMnLCB7XG4gICAgICAgIGhhbmRsZSxcbiAgICAgICAgZW5kcG9pbnQsXG4gICAgICAgIGFkZGVkLFxuICAgICAgICB0b3RhbDogT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggPj0gRkxVU0hfVFdFRVRfVEhSRVNIT0xEKSB7XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICd0aHJlc2hvbGQnKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlUnVuQnVmZmVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgdHM6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8UnVuQnVmZmVyPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpO1xuICBpZiAoY3VyKSByZXR1cm4gY3VyO1xuICBjb25zdCBidWY6IFJ1bkJ1ZmZlciA9IHtcbiAgICBydW5faWQ6IG5ld1J1bklkKCksXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBzdGFydGVkX2F0OiB0cyxcbiAgICBsYXN0X2NhcHR1cmVfYXQ6IHRzLFxuICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcbiAgICBlbmRwb2ludHNfc2VlbjogW2VuZHBvaW50XSxcbiAgICBzb3VyY2VfdXJsOiBzb3VyY2VVcmwsXG4gIH07XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gIGF3YWl0IGluZm8oJ3J1biBzdGFydGVkJywgeyBoYW5kbGUsIHJ1bjogc2hvcnRSdW5JZChidWYucnVuX2lkKSB9KTtcbiAgcmV0dXJuIGJ1Zjtcbn1cblxuLy8gLS0tIEZsdXNoIGxvZ2ljIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hJZGxlQnVmZmVycygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICdpZGxlJyk7XG4gICAgfVxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoT3JwaGFuZWRCdWZmZXJzSWZTdGFsZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gT24gd29ya2VyIHdha2UsIGFueSBidWZmZXIgb2xkZXIgdGhhbiB0aGUgaWRsZSB0aHJlc2hvbGQgZ2V0cyBhIGNoYW5jZSB0b1xuICAvLyBjb21taXQgaW1tZWRpYXRlbHkgXHUyMDE0IHVzZWZ1bCB3aGVuIHRoZSB3b3JrZXIgd2FzIGV2aWN0ZWQgYmVmb3JlIGlkbGUtZmx1c2guXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUoaGFuZGxlLCAnd2FrZScpO1xuICAgIH1cbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaEFsbChyZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIE9iamVjdC5rZXlzKGFsbCkpIHtcbiAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsIHJlYXNvbik7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGUoaGFuZGxlOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGJ1ZiA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpO1xuICBpZiAoIWJ1ZikgcmV0dXJuO1xuICBjb25zdCB0d2VldHMgPSBPYmplY3QudmFsdWVzKGJ1Zi50d2VldHNfYnlfaWQpO1xuICBpZiAodHdlZXRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGF3YWl0IGNsZWFyUnVuQnVmZmVyKGhhbmRsZSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSB7XG4gICAgYXdhaXQgd2FybignZmx1c2ggZGVmZXJyZWQ6IHNldHRpbmdzIGluY29tcGxldGUnLCB7IGhhbmRsZSB9KTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChidWYuc3RhcnRlZF9hdCk7XG4gIGNvbnN0IGRheSA9IGJ1Zi5zdGFydGVkX2F0LnNsaWNlKDAsIDEwKTtcbiAgY29uc3QgcmF3UGF0aCA9IGByYXcvJHtoYW5kbGV9LyR7dHN9LSR7c2hvcnRSdW5JZChidWYucnVuX2lkKX0uanNvbmA7XG4gIGNvbnN0IHNlZW5QYXRoID0gYHNlZW4vJHtoYW5kbGV9LyR7dHN9LSR7c2hvcnRSdW5JZChidWYucnVuX2lkKX0uanNvbmA7XG5cbiAgY29uc3QgY2FwdHVyZTogQ2FwdHVyZVBheWxvYWQgPSB7XG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICBlbmRwb2ludDogYnVmLmVuZHBvaW50c19zZWVuLmpvaW4oJywnKSxcbiAgICB1c2VyX2FnZW50OiBuYXZpZ2F0b3IudXNlckFnZW50LFxuICAgIHNvdXJjZV91cmw6IGJ1Zi5zb3VyY2VfdXJsLFxuICAgIHR3ZWV0cyxcbiAgfTtcbiAgY29uc3Qgc2VlbjogU2VlblBheWxvYWQgPSB7XG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQsXG4gIH07XG5cbiAgY29uc3QgY29tbWl0TXNnID0gYGNhcHR1cmU6ICR7aGFuZGxlfSAke2RheX0gJHt0d2VldHMubGVuZ3RofSB0d2VldCR7dHdlZXRzLmxlbmd0aCA9PT0gMSA/ICcnIDogJ3MnfSAocnVuICR7c2hvcnRSdW5JZChidWYucnVuX2lkKX0pYDtcblxuICB0cnkge1xuICAgIGF3YWl0IGNsaWVudC5wdXRGaWxlKHtcbiAgICAgIHBhdGg6IHJhd1BhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShjYXB0dXJlLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICAgIG1lc3NhZ2U6IGNvbW1pdE1zZyxcbiAgICB9KTtcbiAgICBhd2FpdCBjbGllbnQucHV0RmlsZSh7XG4gICAgICBwYXRoOiBzZWVuUGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHNlZW4sIG51bGwsIDIpICsgJ1xcbicpLFxuICAgICAgbWVzc2FnZTogYHNlZW46ICR7aGFuZGxlfSAke2RheX0gJHtzZWVuLnR3ZWV0X2lkc19vYnNlcnZlZC5sZW5ndGh9IGlkcyAocnVuICR7c2hvcnRSdW5JZChidWYucnVuX2lkKX0pYCxcbiAgICB9KTtcbiAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihoYW5kbGUpO1xuICAgIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwge1xuICAgICAgdG9kYXlDb3VudDogKGF3YWl0IGdldENvdW50ZXJzKCkpW2hhbmRsZV0/LnRvZGF5Q291bnQgPz8gMCxcbiAgICAgIHRvZGF5RGF0ZTogZGF5LFxuICAgICAgbGFzdENhcHR1cmVBdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgIHRvdGFsQ29tbWl0dGVkOiAoKGF3YWl0IGdldENvdW50ZXJzKCkpW2hhbmRsZV0/LnRvdGFsQ29tbWl0dGVkID8/IDApICsgdHdlZXRzLmxlbmd0aCxcbiAgICAgIGJ1ZmZlcmVkQ291bnQ6IDAsXG4gICAgfSk7XG4gICAgYXdhaXQgaW5mbygnZmx1c2ggY29tbWl0dGVkJywge1xuICAgICAgaGFuZGxlLFxuICAgICAgcmVhc29uLFxuICAgICAgdHdlZXRzOiB0d2VldHMubGVuZ3RoLFxuICAgICAgcnVuOiBzaG9ydFJ1bklkKGJ1Zi5ydW5faWQpLFxuICAgICAgcGF0aDogcmF3UGF0aCxcbiAgICB9KTtcbiAgICB7XG4gICAgICBjb25zdCBwcmV2ID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICAgIHN0YXR1czogJ29rJyxcbiAgICAgICAgbG9naW46IHByZXYubG9naW4sXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogcHJldi5kZWZhdWx0QnJhbmNoLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBwcmV2LmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgICB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvcikge1xuICAgICAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XG4gICAgICAgIGVyci5jYXRlZ29yeSA9PT0gJ2F1dGgnXG4gICAgICAgICAgPyAnYXV0aC1lcnJvcidcbiAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnXG4gICAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ25ldHdvcmsnXG4gICAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXG4gICAgICAgICAgICAgIDogY29ubi5zdGF0dXM7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzLFxuICAgICAgICBsb2dpbjogY29ubi5sb2dpbixcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBlcnIubWVzc2FnZSxcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogY29ubi5kZWZhdWx0QnJhbmNoLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBjb25uLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGxvZ0VycignZmx1c2ggZmFpbGVkJywge1xuICAgICAgICBoYW5kbGUsXG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgY2F0ZWdvcnk6IGVyci5jYXRlZ29yeSxcbiAgICAgICAgc3RhdHVzOiBlcnIuc3RhdHVzLFxuICAgICAgICBtZXNzYWdlOiBlcnIubWVzc2FnZSxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBsb2dFcnIoJ2ZsdXNoIGZhaWxlZCcsIHsgaGFuZGxlLCByZWFzb24sIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgICB9XG4gICAgLy8gTGVhdmUgYnVmZmVyIGludGFjdCBmb3IgcmV0cnkuXG4gIH0gZmluYWxseSB7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgfVxufVxuXG4vLyAtLS0gQ2FwdHVyZS1ub3cgLyBjYXB0dXJlLWFsbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVOb3coaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gTGFuZCBvbiB0aGUgUmVwbGllcyB0YWIgc28gWCBmZXRjaGVzIHZpYSBVc2VyVHdlZXRzQW5kUmVwbGllcyBcdTIwMTQgdGhhdFxuICAvLyBlbmRwb2ludCByZXR1cm5zIGJvdGggdG9wLWxldmVsIHBvc3RzIGFuZCByZXBsaWVzLCB3aGljaCBpcyB0aGUgc3VwZXJzZXRcbiAgLy8gd2Ugd2FudCBmb3IgdGhlIGFyY2hpdmUuIFRoZSBwbGFpbiBgLzxoYW5kbGU+YCBVUkwgaGl0cyBVc2VyVHdlZXRzLFxuICAvLyB3aGljaCBvbWl0cyByZXBsaWVzLiBUaGUgcGFnZS1ob29rIGludGVyY2VwdHMgZWl0aGVyIGVuZHBvaW50LCBidXRcbiAgLy8gZm9yY2luZyB0aGUgYnJvYWRlciB0YWIgb24gdXNlci1pbml0aWF0ZWQgY2FwdHVyZXMgaXMgdGhlIHJpZ2h0IGRlZmF1bHQuXG4gIGNvbnN0IHRhcmdldFVybCA9IGBodHRwczovL3guY29tLyR7aGFuZGxlfS93aXRoX3JlcGxpZXNgO1xuICBhd2FpdCBpbmZvKCdjYXB0dXJlLW5vdyByZXF1ZXN0ZWQnLCB7IGhhbmRsZSwgdGFiOiAnd2l0aF9yZXBsaWVzJyB9KTtcbiAgaWYgKCEoYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSkpKSB7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIHtcbiAgICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBzdGFydGVkX2F0OiBub3csXG4gICAgICBsYXN0X2NhcHR1cmVfYXQ6IG5vdyxcbiAgICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IFtdLFxuICAgICAgZW5kcG9pbnRzX3NlZW46IFtdLFxuICAgICAgc291cmNlX3VybDogdGFyZ2V0VXJsLFxuICAgIH0pO1xuICB9XG4gIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmw6IHRhcmdldFVybCwgYWN0aXZlOiB0cnVlIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtYWxsIHJlcXVlc3RlZCcsIHsgY291bnQ6IGFjY291bnRzLmxlbmd0aCB9KTtcbiAgZm9yIChjb25zdCBhIG9mIGFjY291bnRzKSB7XG4gICAgYXdhaXQgY2FwdHVyZU5vdyhhLmhhbmRsZSk7XG4gIH1cbn1cblxuLy8gLS0tIFF1YXJhbnRpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gcXVhcmFudGluZShcbiAgcmVhc29uOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHVybDogc3RyaW5nLFxuICByYXc6IHVua25vd24sXG4gIGVycjogdW5rbm93blxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGxvZ0VycigncXVhcmFudGluaW5nIGNhcHR1cmUnLCB7IHJlYXNvbiwgZW5kcG9pbnQsIHVybCwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykgcmV0dXJuO1xuICBjb25zdCBwYXlsb2FkOiBRdWFyYW50aW5lUGF5bG9hZCA9IHtcbiAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgICByZWFzb24sXG4gICAgZW5kcG9pbnQsXG4gICAgY2FwdHVyZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBzb3VyY2VfdXJsOiB1cmwsXG4gICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICByYXcsXG4gIH07XG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChwYXlsb2FkLmNhcHR1cmVkX2F0KTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IHNoYTgoSlNPTi5zdHJpbmdpZnkocGF5bG9hZCkpO1xuICBjb25zdCBwYXRoID0gYHJhdy9fcXVhcmFudGluZS8ke3RzfS0ke2hhc2h9Lmpzb25gO1xuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGF3YWl0IGNsaWVudC5wdXRGaWxlKHtcbiAgICAgIHBhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShwYXlsb2FkLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICAgIG1lc3NhZ2U6IGBxdWFyYW50aW5lOiAke3JlYXNvbn0gJHtlbmRwb2ludH1gLFxuICAgIH0pO1xuICB9IGNhdGNoIChxZXJyKSB7XG4gICAgYXdhaXQgbG9nRXJyKCdxdWFyYW50aW5lIGNvbW1pdCBmYWlsZWQnLCB7IC4uLmRlc2NyaWJlRXJyb3IocWVycikgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gc2hhOChzOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBidWYgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUocyk7XG4gIGNvbnN0IGRpZ2VzdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgYnVmKTtcbiAgY29uc3QgaGV4ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShkaWdlc3QpKVxuICAgIC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG4gICAgLmpvaW4oJycpO1xuICByZXR1cm4gaGV4LnNsaWNlKDAsIDgpO1xufVxuXG4vLyAtLS0gQ29ubmVjdGlvbiB2ZXJpZmljYXRpb24gJiBhY2NvdW50cyBsaXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIHZlcmlmeUNvbm5lY3Rpb24oZm9yY2U6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHtcbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcbiAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlcnJvcjogbnVsbCxcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGlmICghZm9yY2UgJiYgY29ubi5zdGF0dXMgPT09ICdvaycgJiYgY29ubi5jaGVja2VkQXQpIHtcbiAgICBjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShjb25uLmNoZWNrZWRBdCk7XG4gICAgaWYgKGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XG4gIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgICBjb25zdCByID0gYXdhaXQgY2xpZW50LnZlcmlmeVJlcG9BY2Nlc3MoKTtcbiAgICAvLyBQcm9iZSB0aGUgY29uZmlndXJlZCBicmFuY2guIEEgbm9uLWRlZmF1bHQgYnJhbmNoIGlzIGZpbmUgXHUyMDE0IGl0J3NcbiAgICAvLyByb3V0aW5lIHRvIGNhcHR1cmUgaW50byBhIHdvcmtpbmcgYnJhbmNoIFx1MjAxNCBidXQgYSAqbWlzc2luZyogYnJhbmNoXG4gICAgLy8gd291bGQgNDIyIGV2ZXJ5IGNvbW1pdC5cbiAgICBsZXQgYnJhbmNoT2sgPSB0cnVlO1xuICAgIGlmIChzZXR0aW5ncy5icmFuY2ggJiYgc2V0dGluZ3MuYnJhbmNoICE9PSByLmRlZmF1bHRfYnJhbmNoKSB7XG4gICAgICBicmFuY2hPayA9IGF3YWl0IGNsaWVudC5icmFuY2hFeGlzdHMoc2V0dGluZ3MuYnJhbmNoKTtcbiAgICB9XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXM6ICdvaycsXG4gICAgICBsb2dpbjogci5sb2dpbixcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IG51bGwsXG4gICAgICBkZWZhdWx0QnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogYnJhbmNoT2ssXG4gICAgfSk7XG4gICAgYXdhaXQgaW5mbygnY29ubmVjdGlvbiB2ZXJpZmllZCcsIHtcbiAgICAgIGxvZ2luOiByLmxvZ2luLFxuICAgICAgcmVwbzogci5mdWxsX25hbWUsXG4gICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRfYnJhbmNoOiBzZXR0aW5ncy5icmFuY2gsXG4gICAgICBjb25maWd1cmVkX2JyYW5jaF9leGlzdHM6IGJyYW5jaE9rLFxuICAgIH0pO1xuICAgIGlmICghYnJhbmNoT2spIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2NvbmZpZ3VyZWQgYnJhbmNoIGRvZXMgbm90IGV4aXN0IG9uIHJlbW90ZScsIHtcbiAgICAgICAgY29uZmlndXJlZDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgICAgZml4OiAnb3BlbiBTZXR0aW5ncyBhbmQgY2hhbmdlIGJyYW5jaCB0byAnICsgci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc3QgY2F0ID0gZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgPyBlcnIuY2F0ZWdvcnkgOiAndW5rbm93bic7XG4gICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgIGNhdCA9PT0gJ2F1dGgnXG4gICAgICAgID8gJ2F1dGgtZXJyb3InXG4gICAgICAgIDogY2F0ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgOiBjYXQgPT09ICduZXR3b3JrJ1xuICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgIDogJ2F1dGgtZXJyb3InO1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzLFxuICAgICAgbG9naW46IG51bGwsXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBkZXNjcmliZUVycm9yKGVycikubWVzc2FnZSxcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IHdhcm4oJ2Nvbm5lY3Rpb24gY2hlY2sgZmFpbGVkJywgeyBjYXRlZ29yeTogY2F0LCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjY291bnRzTGlzdChmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0KSB7XG4gICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IGNsaWVudC5mZXRjaFJhd1RleHQoJ2NvbmZpZy9hY2NvdW50cy55YW1sJyk7XG4gICAgaWYgKCF0ZXh0KSB7XG4gICAgICBpZiAoZm9yY2UpIGF3YWl0IHdhcm4oJ2FjY291bnRzLnlhbWwgbm90IGZvdW5kIGluIHJlcG87IHVzaW5nIGZhbGxiYWNrJyk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcGFyc2VkID0gcGFyc2VBY2NvdW50c1lhbWwodGV4dCk7XG4gICAgaWYgKHBhcnNlZC5sZW5ndGggPT09IDApIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2FjY291bnRzLnlhbWwgcGFyc2VkIGVtcHR5OyBrZWVwaW5nIGZhbGxiYWNrJyk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgYXdhaXQgc2V0QWNjb3VudHMocGFyc2VkKTtcbiAgICBpZiAoZm9yY2UpIGF3YWl0IGluZm8oJ2FjY291bnRzIGxpc3QgcmVmcmVzaGVkJywgeyBjb3VudDogcGFyc2VkLmxlbmd0aCB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybigncmVmcmVzaCBhY2NvdW50cyBmYWlsZWQ7IGtlZXBpbmcgY3VycmVudCBsaXN0JywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG4vLyAtLS0gU3RhdGUgYnJvYWRjYXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIGJyb2FkY2FzdFN0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzdGF0ZSA9IGF3YWl0IGJ1aWxkU3RhdGUoKTtcbiAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ3N0YXRlLWNoYW5nZWQnLCBzdGF0ZSB9KS5jYXRjaCgoKSA9PiB7fSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGJ1aWxkU3RhdGUoKTogUHJvbWlzZTxFeHRlbnNpb25TdGF0ZT4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgY29uc3QgY291bnRlcnMgPSBhd2FpdCBnZXRDb3VudGVycygpO1xuICByZXR1cm4ge1xuICAgIHZlcnNpb246IEVYVF9WRVJTSU9OLFxuICAgIHNldHRpbmdzOiByZWRhY3RTZXR0aW5ncyhzZXR0aW5ncyksXG4gICAgY29ubmVjdGlvbjogY29ubixcbiAgICBhY2NvdW50cyxcbiAgICBjb3VudGVycyxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcmVkYWN0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBFeHRlbnNpb25TdGF0ZVsnc2V0dGluZ3MnXSB7XG4gIHJldHVybiB7XG4gICAgb3duZXI6IHMub3duZXIsXG4gICAgcmVwbzogcy5yZXBvLFxuICAgIGJyYW5jaDogcy5icmFuY2gsXG4gICAgYXV0b0NhcHR1cmU6IHMuYXV0b0NhcHR1cmUsXG4gICAgY29uZmlndXJlZEF0OiBzLmNvbmZpZ3VyZWRBdCxcbiAgICBwYXRTZXQ6IHMucGF0Lmxlbmd0aCA+IDAsXG4gICAgcGF0U3VmZml4OiBzLnBhdC5sZW5ndGggPj0gNCA/IHMucGF0LnNsaWNlKC00KSA6ICcnLFxuICB9O1xufVxuXG5mdW5jdGlvbiBpc29Db21wYWN0KGlzbzogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gMjAyNS0wNC0xMlQxNDoyMzowMS4wMDBaIFx1MjE5MiAyMDI1LTA0LTEyVDE0MjMwMVpcbiAgY29uc3QgZCA9IG5ldyBEYXRlKGlzbyk7XG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gaXNvLnJlcGxhY2UoL1s6Ll0vZywgJycpO1xuICBjb25zdCBwYWQgPSAobjogbnVtYmVyLCB3ID0gMikgPT4gU3RyaW5nKG4pLnBhZFN0YXJ0KHcsICcwJyk7XG4gIHJldHVybiAoXG4gICAgYCR7ZC5nZXRVVENGdWxsWWVhcigpfS0ke3BhZChkLmdldFVUQ01vbnRoKCkgKyAxKX0tJHtwYWQoZC5nZXRVVENEYXRlKCkpfWAgK1xuICAgIGBUJHtwYWQoZC5nZXRVVENIb3VycygpKX0ke3BhZChkLmdldFVUQ01pbnV0ZXMoKSl9JHtwYWQoZC5nZXRVVENTZWNvbmRzKCkpfVpgXG4gICk7XG59XG5cbmZ1bmN0aW9uIHZpZXdlclVybChzOiBTZXR0aW5ncyk6IHN0cmluZyB7XG4gIHJldHVybiBgaHR0cHM6Ly8ke3Mub3duZXJ9LmdpdGh1Yi5pby8ke3MucmVwb30vYDtcbn1cblxuLyoqXG4gKiBXYWxrIGBub2RlYCBjb2xsZWN0aW5nIGRvdHRlZCBrZXkgcGF0aHMgdXAgdG8gYG1heERlcHRoYCBkZWVwLiBBcnJheVxuICogaW5kaWNlcyBjb2xsYXBzZSB0byBgWzBdYCAod2Ugb25seSBkZXNjZW5kIGludG8gdGhlIGZpcnN0IGVsZW1lbnQpLiBVc2VkXG4gKiB0byBzdXJmYWNlIHRoZSBzdHJ1Y3R1cmFsIHNrZWxldG9uIG9mIGFuIHVuZmFtaWxpYXIgR3JhcGhRTCByZXNwb25zZVxuICogd2l0aG91dCBpbmNsdWRpbmcgYW55IGRhdGEgdmFsdWVzLlxuICovXG5mdW5jdGlvbiBwcm9iZUtleVBhdGhzKG5vZGU6IHVua25vd24sIG1heERlcHRoOiBudW1iZXIpOiBzdHJpbmdbXSB7XG4gIGNvbnN0IG91dDogc3RyaW5nW10gPSBbXTtcbiAgZnVuY3Rpb24gd2FsayhuOiB1bmtub3duLCBkZXB0aDogbnVtYmVyLCBwcmVmaXg6IHN0cmluZyk6IHZvaWQge1xuICAgIGlmIChkZXB0aCA+IG1heERlcHRoIHx8IG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSByZXR1cm47XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIG91dC5wdXNoKGAke3ByZWZpeH1bbGVuPSR7bi5sZW5ndGh9XWApO1xuICAgICAgaWYgKG4ubGVuZ3RoID4gMCkgd2FsayhuWzBdLCBkZXB0aCArIDEsIGAke3ByZWZpeH1bMF1gKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrIG9mIE9iamVjdC5rZXlzKG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSB7XG4gICAgICBjb25zdCBwYXRoID0gcHJlZml4ID8gYCR7cHJlZml4fS4ke2t9YCA6IGs7XG4gICAgICBvdXQucHVzaChwYXRoKTtcbiAgICAgIHdhbGsoKG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW2tdLCBkZXB0aCArIDEsIHBhdGgpO1xuICAgIH1cbiAgfVxuICB3YWxrKG5vZGUsIDAsICcnKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuLyoqIENvbGxlY3QgZXZlcnkgZGlzdGluY3QgYF9fdHlwZW5hbWVgIHZhbHVlIGZvdW5kIGFueXdoZXJlIGluIHRoZSB0cmVlLiAqL1xuZnVuY3Rpb24gcHJvYmVUeXBlbmFtZXMobm9kZTogdW5rbm93bik6IHN0cmluZ1tdIHtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobiA9PT0gbnVsbCB8fCB0eXBlb2YgbiAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShuKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG9iaiA9IG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBpZiAodHlwZW9mIG9iai5fX3R5cGVuYW1lID09PSAnc3RyaW5nJykgc2Vlbi5hZGQob2JqLl9fdHlwZW5hbWUpO1xuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIFsuLi5zZWVuXS5zb3J0KCk7XG59XG5cbi8qKiBUcnVlIGlmIHRoZSByZXNwb25zZSBoYXMgYSB0b3AtbGV2ZWwgYGVycm9yc2AgYXJyYXksIEdyYXBoUUwtc3R5bGUuICovXG5mdW5jdGlvbiBoYXNFcnJvcnNGaWVsZChub2RlOiB1bmtub3duKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIG5vZGUgPT09ICdvYmplY3QnICYmXG4gICAgbm9kZSAhPT0gbnVsbCAmJlxuICAgIEFycmF5LmlzQXJyYXkoKG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLmVycm9ycykgJiZcbiAgICAobm9kZSBhcyB7IGVycm9yczogdW5rbm93bltdIH0pLmVycm9ycy5sZW5ndGggPiAwXG4gICk7XG59XG5cbmZ1bmN0aW9uIHNob3J0ZW5VcmwodTogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gQWN0aXZpdHktdGFpbCBjb250ZXh0IGlzIG1vcmUgdXNlZnVsIHdpdGgganVzdCB0aGUgcGF0aDsgZnVsbCBVUkxzIGJlY29tZVxuICAvLyBoYXJkIHRvIHJlYWQgYXQgdGhlIHNpZGViYXIncyB3aWR0aC5cbiAgdHJ5IHtcbiAgICBjb25zdCBwYXJzZWQgPSBuZXcgVVJMKHUpO1xuICAgIGNvbnN0IHBhdGggPSBwYXJzZWQucGF0aG5hbWUgKyAocGFyc2VkLnNlYXJjaCA/ICc/XHUyMDI2JyA6ICcnKTtcbiAgICByZXR1cm4gcGFyc2VkLmhvc3QgPT09ICd4LmNvbScgfHwgcGFyc2VkLmhvc3QgPT09ICd0d2l0dGVyLmNvbSdcbiAgICAgID8gcGF0aFxuICAgICAgOiBgJHtwYXJzZWQuaG9zdH0ke3BhdGh9YDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHUubGVuZ3RoID4gODAgPyBgJHt1LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdTtcbiAgfVxufVxuXG4vLyAtLS0gRGV2IGhlbHBlcnMgZXhwb3NlZCBvbiBnbG9iYWxUaGlzIGZvciB0aGUgZGV2dG9vbHMgY29uc29sZSAtLS0tLS0tLS0tXG4vLyAoZS5nLiBgX19pbW1BcmNoaXZlLmNsZWFyQWxsKClgIGluIHRoZSBiYWNrZ3JvdW5kIHdvcmtlcidzIGRldnRvb2xzKS5cblxuKGdsb2JhbFRoaXMgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLl9faW1tQXJjaGl2ZSA9IHtcbiAgY2xlYXJBbGwsXG4gIGFjdGl2aXR5OiBnZXRBY3Rpdml0eSxcbiAgYWNjb3VudHM6IGdldEFjY291bnRzLFxuICBidWZmZXJzOiBnZXRSdW5CdWZmZXJzLFxuICBmbHVzaEFsbDogKCkgPT4gZmx1c2hBbGwoJ2RldnRvb2xzJyksXG4gIHN0YXRlOiBidWlsZFN0YXRlLFxufTtcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFBQSxFQUNQLE1BQU07QUFBQTtBQUFBO0FBQUEsRUFHTixRQUFRO0FBQUEsRUFDUixhQUFhO0FBQUEsRUFDYixjQUFjO0FBQ2hCO0FBSU8sSUFBTSxvQkFBcUM7QUFBQSxFQUNoRCxFQUFFLFFBQVEsVUFBVSxPQUFPLGtDQUFrQztBQUFBLEVBQzdELEVBQUUsUUFBUSxVQUFVLE9BQU8sMkNBQTJDO0FBQUEsRUFDdEUsRUFBRSxRQUFRLE9BQU8sT0FBTyxxQ0FBcUM7QUFBQSxFQUM3RCxFQUFFLFFBQVEsU0FBUyxPQUFPLDRDQUE0QztBQUFBLEVBQ3RFLEVBQUUsUUFBUSxjQUFjLE9BQU8sa0JBQWtCO0FBQUEsRUFDakQsRUFBRSxRQUFRLFlBQVksT0FBTyw4QkFBOEI7QUFBQSxFQUMzRCxFQUFFLFFBQVEsU0FBUyxPQUFPLGlDQUFpQztBQUFBLEVBQzNELEVBQUUsUUFBUSxTQUFTLE9BQU8sMkJBQTJCO0FBQ3ZEO0FBR08sSUFBTSxrQkFBdUMsb0JBQUksSUFBSTtBQUFBLEVBQzFEO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBSU0sSUFBTSxvQkFBeUMsb0JBQUksSUFBSSxDQUFDLG9CQUFvQixjQUFjLENBQUM7QUFHM0YsSUFBTSx3QkFBd0I7QUFHOUIsSUFBTSxnQkFBZ0I7QUFHdEIsSUFBTSxzQkFBc0I7QUFHNUIsSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLO0FBRWhELElBQU0sbUJBQW1COzs7QUMxQmhDLElBQU0scUJBQXNDO0FBQUEsRUFDMUMsUUFBUTtBQUFBLEVBQ1IsT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUFBLEVBQ1AsZUFBZTtBQUFBLEVBQ2Ysd0JBQXdCO0FBQzFCO0FBRUEsSUFBTSxXQUF5QjtBQUFBLEVBQzdCLFVBQVUsRUFBRSxHQUFHLGlCQUFpQjtBQUFBLEVBQ2hDLFVBQVUsQ0FBQyxHQUFHLGlCQUFpQjtBQUFBLEVBQy9CLFlBQVksRUFBRSxHQUFHLG1CQUFtQjtBQUFBLEVBQ3BDLFVBQVUsQ0FBQztBQUFBLEVBQ1gsWUFBWSxDQUFDO0FBQUEsRUFDYixVQUFVLENBQUM7QUFDYjtBQUVBLGVBQWUsT0FBcUMsS0FBa0M7QUFDcEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxHQUFHO0FBQ2xELFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsTUFBSSxVQUFVLFFBQVc7QUFDdkIsV0FBTyxnQkFBZ0IsU0FBUyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUNBLFNBQU87QUFDVDtBQUVBLGVBQWUsT0FBcUMsS0FBUSxPQUF1QztBQUNqRyxRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUM7QUFDbEQ7QUFJQSxlQUFzQixjQUFpQztBQUNyRCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQVksR0FBNEI7QUFDNUQsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUM1QjtBQUNBLGVBQXNCLGVBQWUsT0FBNkM7QUFDaEYsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE9BQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hDLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFNBQU87QUFDVDtBQUlBLGVBQXNCLGNBQXdDO0FBQzVELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFBWSxHQUFtQztBQUNuRSxRQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzVCO0FBSUEsZUFBc0IsZ0JBQTBDO0FBQzlELFFBQU0sSUFBSSxNQUFNLE9BQU8sWUFBWTtBQUVuQyxRQUFNLE1BQXVCO0FBQUEsSUFDM0IsR0FBRztBQUFBLElBQ0gsZUFBZSxFQUFFLGtCQUFrQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3hELHdCQUNFLEVBQUUsMkJBQTJCLFNBQVksT0FBTyxFQUFFO0FBQUEsRUFDdEQ7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixjQUFjLEdBQW1DO0FBQ3JFLFFBQU0sT0FBTyxjQUFjLENBQUM7QUFDOUI7QUFJQSxTQUFTLFdBQW1CO0FBQzFCLFVBQU8sb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUM3QztBQUVBLGVBQXNCLGNBQXVEO0FBQzNFLFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFDcEIsUUFDQSxPQUN5QjtBQUN6QixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sTUFBTSxJQUFJLE1BQU0sS0FBSztBQUFBLElBQ3pCLFlBQVk7QUFBQSxJQUNaLFdBQVcsU0FBUztBQUFBLElBQ3BCLGVBQWU7QUFBQSxJQUNmLGdCQUFnQjtBQUFBLElBQ2hCLGVBQWU7QUFBQSxFQUNqQjtBQUNBLE1BQUksSUFBSSxjQUFjLFNBQVMsR0FBRztBQUNoQyxRQUFJLFlBQVksU0FBUztBQUN6QixRQUFJLGFBQWE7QUFBQSxFQUNuQjtBQUNBLFFBQU0sT0FBdUIsRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hELE1BQUksTUFBTSxJQUFJO0FBQ2QsUUFBTSxPQUFPLFlBQVksR0FBRztBQUM1QixTQUFPO0FBQ1Q7QUFFQSxlQUFzQixpQkFBaUIsUUFBZ0IsT0FBOEI7QUFDbkYsUUFBTSxZQUFZLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztBQUNwRDtBQUlBLGVBQXNCLGdCQUFvRDtBQUN4RSxTQUFPLE9BQU8sWUFBWTtBQUM1QjtBQUVBLGVBQXNCLGFBQWEsUUFBMkM7QUFDNUUsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxTQUFPLElBQUksTUFBTSxLQUFLO0FBQ3hCO0FBRUEsZUFBc0IsYUFBYSxRQUFnQixLQUErQjtBQUNoRixRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLE1BQUksTUFBTSxJQUFJO0FBQ2QsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUVBLGVBQXNCLGVBQWUsUUFBK0I7QUFDbEUsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxTQUFPLElBQUksTUFBTTtBQUNqQixRQUFNLE9BQU8sY0FBYyxHQUFHO0FBQ2hDO0FBSUEsZUFBc0IsY0FBbUM7QUFDdkQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFFQSxlQUFzQixlQUFlLElBQW1DO0FBQ3RFLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsTUFBSSxRQUFRLEVBQUU7QUFDZCxNQUFJLElBQUksU0FBUyxrQkFBbUIsS0FBSSxTQUFTO0FBQ2pELFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsZ0JBQStCO0FBQ25ELFFBQU0sT0FBTyxZQUFZLENBQUMsQ0FBQztBQUM3QjtBQUlBLGVBQXNCLFdBQTBCO0FBQzlDLFFBQU0sUUFBUSxRQUFRLE1BQU0sTUFBTTtBQUNwQzs7O0FDeExBLElBQUksWUFBNkM7QUFFMUMsU0FBUyxlQUFlLElBQWtDO0FBQy9ELGNBQVk7QUFDZDtBQUVBLFNBQVMsU0FBaUI7QUFDeEIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNoQztBQUVBLGVBQWUsS0FBSyxPQUFpQixLQUFhLFNBQWlEO0FBQ2pHLFFBQU0sS0FBZSxFQUFFLElBQUksT0FBTyxHQUFHLE9BQU8sS0FBSyxTQUFTLE9BQU8sT0FBTyxFQUFFO0FBRTFFLFFBQU0sT0FBTyxpQkFBaUIsTUFBTSxZQUFZLENBQUMsSUFBSSxHQUFHO0FBQ3hELE1BQUksVUFBVSxRQUFTLFNBQVEsTUFBTSxNQUFNLEdBQUcsT0FBTztBQUFBLFdBQzVDLFVBQVUsT0FBUSxTQUFRLEtBQUssTUFBTSxHQUFHLE9BQU87QUFBQSxNQUNuRCxTQUFRLElBQUksTUFBTSxHQUFHLE9BQU87QUFFakMsTUFBSTtBQUNGLFVBQU0sZUFBZSxFQUFFO0FBQUEsRUFDekIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDJDQUEyQyxHQUFHO0FBQUEsRUFDN0Q7QUFFQSxNQUFJO0FBQ0YsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCLFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUFFTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxNQUFNLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN2RixTQUFPLEtBQUssU0FBUyxLQUFLLE9BQU87QUFDbkM7QUFFTyxTQUFTLGNBQWMsS0FBeUQ7QUFDckYsTUFBSSxlQUFlLE9BQU87QUFDeEIsV0FBTyxFQUFFLFNBQVMsSUFBSSxTQUFTLE9BQU8sSUFBSSxTQUFTLEtBQUs7QUFBQSxFQUMxRDtBQUNBLE1BQUk7QUFDRixXQUFPLEVBQUUsU0FBUyxPQUFPLEdBQUcsR0FBRyxPQUFPLEtBQUs7QUFBQSxFQUM3QyxRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsdUJBQXVCLE9BQU8sS0FBSztBQUFBLEVBQ3ZEO0FBQ0Y7QUFPQSxTQUFTLE9BQU8sS0FBdUQ7QUFDckUsUUFBTSxNQUErQixDQUFDO0FBQ3RDLGFBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQ3hDLFFBQUksRUFBRSxZQUFZLEVBQUUsU0FBUyxPQUFPLEtBQUssRUFBRSxZQUFZLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtBQUMzRixVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1gsV0FBVyxPQUFPLE1BQU0sWUFBWSwrQkFBK0IsS0FBSyxDQUFDLEdBQUc7QUFDMUUsVUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLDZCQUE2Qix1QkFBdUI7QUFBQSxJQUN6RSxXQUFXLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxNQUFNO0FBQ25ELFVBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsSUFDOUIsT0FBTztBQUNMLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7OztBQ3ZFQSxJQUFNLFdBQVc7QUFDakIsSUFBTSxXQUFXO0FBZVYsSUFBTSxjQUFOLGNBQTBCLE1BQU07QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBRUEsWUFBWSxNQU1UO0FBQ0QsVUFBTSxLQUFLLE9BQU87QUFDbEIsU0FBSyxPQUFPO0FBQ1osU0FBSyxTQUFTLEtBQUs7QUFDbkIsU0FBSyxPQUFPLEtBQUs7QUFDakIsU0FBSyxZQUFZLEtBQUs7QUFDdEIsU0FBSyxXQUFXLEtBQUs7QUFBQSxFQUN2QjtBQUNGO0FBRU8sSUFBTSxlQUFOLE1BQW1CO0FBQUEsRUFDUDtBQUFBLEVBRWpCLFlBQVksVUFBb0I7QUFDOUIsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFBQTtBQUFBLEVBR0EsTUFBTSxTQUEwQjtBQUM5QixVQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQy9DLFdBQVEsSUFBMkIsU0FBUztBQUFBLEVBQzlDO0FBQUE7QUFBQSxFQUdBLE1BQU0sYUFBYSxRQUFrQztBQUNuRCxRQUFJO0FBQ0YsWUFBTSxLQUFLO0FBQUEsUUFDVDtBQUFBLFFBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsbUJBQW1CLE1BQU0sQ0FBQztBQUFBLE1BQzVGO0FBQ0EsYUFBTztBQUFBLElBQ1QsU0FBUyxLQUFLO0FBQ1osVUFBSSxlQUFlLGVBQWUsSUFBSSxhQUFhLFlBQWEsUUFBTztBQUN2RSxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQTtBQUFBLEVBR0EsTUFBTSxtQkFBMEY7QUFDOUYsVUFBTSxLQUFLLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTztBQUM5QyxVQUFNLE9BQU8sTUFBTSxLQUFLLFVBQVUsT0FBTyxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksRUFBRTtBQUM5RixVQUFNLElBQUk7QUFDVixXQUFPO0FBQUEsTUFDTCxPQUFRLEdBQXlCO0FBQUEsTUFDakMsV0FBVyxFQUFFO0FBQUEsTUFDYixnQkFBZ0IsRUFBRTtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLGFBQWEsWUFBNEM7QUFDN0QsVUFBTSxNQUFNLEdBQUcsUUFBUSxJQUFJLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFNBQVMsTUFBTSxJQUFJLFVBQVU7QUFDMUcsVUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDM0IsUUFBUTtBQUFBLE1BQ1IsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQUEsSUFDMUQsQ0FBQztBQUNELFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLFVBQVUsS0FBSyxXQUFXLFVBQVUsRUFBRTtBQUNwRSxXQUFPLElBQUksS0FBSztBQUFBLEVBQ2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sV0FBVyxNQUFzQztBQUNyRCxRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLFFBQ3JCO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQyxRQUFRLG1CQUFtQixLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDbEk7QUFDQSxZQUFNLElBQUk7QUFDVixhQUFPLEVBQUUsT0FBTztBQUFBLElBQ2xCLFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxRQUFRLE1BQThDO0FBQzFELFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sTUFBTSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQztBQUM1RixRQUFJLE1BQXFCLEtBQUssZUFBZTtBQUM3QyxVQUFNLGNBQWM7QUFFcEIsYUFBUyxVQUFVLEdBQUcsV0FBVyxhQUFhLFdBQVc7QUFDdkQsWUFBTSxPQUFnQztBQUFBLFFBQ3BDLFNBQVMsS0FBSztBQUFBLFFBQ2QsU0FBUyxLQUFLO0FBQUEsUUFDZCxRQUFRLEtBQUssU0FBUztBQUFBLE1BQ3hCO0FBQ0EsVUFBSSxJQUFLLE1BQUssTUFBTTtBQUNwQixVQUFJO0FBQ0YsY0FBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sS0FBSyxJQUFJO0FBQ2pELGNBQU0sTUFBTTtBQUNaLGVBQU8sRUFBRSxNQUFNLElBQUksUUFBUSxNQUFNLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLFFBQVEsU0FBUztBQUFBLE1BQ25GLFNBQVMsS0FBSztBQUNaLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFJLElBQUksV0FBVyxPQUFPLENBQUMsS0FBSztBQUU5QixnQkFBTSxNQUFNLEtBQUssV0FBVyxJQUFJO0FBQ2hDLGNBQUksQ0FBQyxJQUFLLE9BQU07QUFDaEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxDQUFDLElBQUksYUFBYSxZQUFZLFlBQWEsT0FBTTtBQUNyRCxjQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sSUFBSSxNQUFNLG1DQUFtQyxJQUFJLEVBQUU7QUFBQSxFQUMzRDtBQUFBLEVBRUEsTUFBYyxVQUFVLFFBQWdCLE1BQWMsTUFBa0M7QUFDdEYsVUFBTSxNQUFNLEtBQUssV0FBVyxNQUFNLElBQUksT0FBTyxHQUFHLFFBQVEsR0FBRyxJQUFJO0FBQy9ELFVBQU0sT0FBb0I7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsU0FBUztBQUFBLFFBQ1AsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHO0FBQUEsUUFDMUMsUUFBUTtBQUFBLFFBQ1Isd0JBQXdCO0FBQUEsUUFDeEIsR0FBSSxPQUFPLEVBQUUsZ0JBQWdCLG1CQUFtQixJQUFJLENBQUM7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsR0FBSSxPQUFPLEVBQUUsTUFBTSxLQUFLLFVBQVUsSUFBSSxFQUFFLElBQUksQ0FBQztBQUFBLElBQy9DO0FBQ0EsUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLLElBQUk7QUFBQSxJQUM3QixTQUFTLFFBQVE7QUFDZixZQUFNLElBQUksWUFBWTtBQUFBLFFBQ3BCLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxRQUNOLFNBQVMsWUFBWSxjQUFjLE1BQU0sRUFBRSxPQUFPO0FBQUEsUUFDbEQsV0FBVztBQUFBLFFBQ1gsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFDQSxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxTQUFrQjtBQUN0QixVQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsUUFBSSxNQUFNO0FBQ1IsVUFBSTtBQUNGLGlCQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsTUFDMUIsUUFBUTtBQUNOLGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLG9CQUFvQixLQUFLLFFBQVEsR0FBRyxNQUFNLElBQUksSUFBSSxFQUFFO0FBQ2xGLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLFVBQVUsS0FBZSxPQUFxQztBQUMxRSxRQUFJLFNBQWtCO0FBQ3RCLFFBQUk7QUFDRixZQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsVUFBSSxLQUFNLFVBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxJQUNwQyxRQUFRO0FBQUEsSUFFUjtBQUNBLFdBQU8sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEtBQUs7QUFBQSxFQUNwRDtBQUFBLEVBRVEsb0JBQW9CLEtBQWUsTUFBZSxPQUE0QjtBQUNwRixVQUFNLE1BQ0osT0FBTyxTQUFTLFlBQVksUUFBUSxhQUFhLE9BQzdDLE9BQVEsS0FBOEIsT0FBTyxJQUM3QyxJQUFJO0FBQ1YsUUFBSSxXQUFvQztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUU1QyxZQUFNLE9BQU8sSUFBSSxRQUFRLElBQUksdUJBQXVCO0FBQ3BELFVBQUksU0FBUyxPQUFPLGNBQWMsS0FBSyxHQUFHLEdBQUc7QUFDM0MsbUJBQVc7QUFDWCxvQkFBWTtBQUFBLE1BQ2QsT0FBTztBQUNMLG1CQUFXO0FBQUEsTUFDYjtBQUFBLElBQ0YsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUNuRCxpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFVBQVUsS0FBSztBQUM1QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZCxXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkO0FBQ0EsV0FBTyxJQUFJLFlBQVk7QUFBQSxNQUNyQixRQUFRLElBQUk7QUFBQSxNQUNaO0FBQUEsTUFDQSxTQUFTLEdBQUcsS0FBSyxXQUFNLElBQUksTUFBTSxLQUFLLEdBQUc7QUFBQSxNQUN6QztBQUFBLE1BQ0E7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsTUFBc0I7QUFFeEMsU0FBTyxLQUFLLE1BQU0sR0FBRyxFQUFFLElBQUksa0JBQWtCLEVBQUUsS0FBSyxHQUFHO0FBQ3pEO0FBRUEsU0FBUyxVQUFVLFNBQWlCLEtBQTBCO0FBRTVELFFBQU0sT0FBTyxJQUFJLGFBQWEsZUFBZSxNQUFPO0FBQ3BELFFBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksR0FBRztBQUM3QyxTQUFPLEtBQUssSUFBSSxLQUFRLE9BQU8sTUFBTSxVQUFVLEtBQUssTUFBTTtBQUM1RDtBQUVBLFNBQVMsTUFBTSxJQUEyQjtBQUN4QyxTQUFPLElBQUksUUFBUSxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQztBQUM3QztBQUVPLFNBQVMsU0FBUyxPQUF1QjtBQUU5QyxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxLQUFLO0FBQzNDLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLFFBQU8sT0FBTyxhQUFhLENBQUM7QUFDbEQsU0FBTyxLQUFLLEdBQUc7QUFDakI7OztBQ3hPTyxTQUFTLFVBQVUsU0FBa0IsS0FBd0M7QUFDbEYsUUFBTSxZQUFZLGNBQWMsT0FBTztBQUN2QyxRQUFNLFNBQTJCLENBQUM7QUFDbEMsUUFBTSxXQUFxQixDQUFDO0FBQzVCLGFBQVcsT0FBTyxXQUFXO0FBQzNCLFFBQUk7QUFDRixZQUFNLElBQUksV0FBVyxLQUFLLEdBQUc7QUFDN0IsVUFBSSxDQUFDLEVBQUc7QUFDUixlQUFTLEtBQUssRUFBRSxRQUFRO0FBQ3hCLFVBQUksSUFBSSxlQUFlLFNBQVMsS0FBSyxJQUFJLGVBQWUsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEdBQUc7QUFDM0YsZUFBTyxLQUFLLENBQUM7QUFBQSxNQUNmO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLEVBQUUsUUFBUSxjQUFjLFNBQVM7QUFDMUM7QUFFQSxTQUFTLGNBQWNBLE1BQXlCO0FBSzlDLFFBQU0sTUFBaUIsQ0FBQztBQUN4QixRQUFNLE9BQU8sb0JBQUksUUFBZ0I7QUFDakMsUUFBTSxRQUFtQixDQUFDQSxJQUFHO0FBQzdCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxPQUFPLE1BQU0sSUFBSTtBQUN2QixRQUFJLFNBQVMsUUFBUSxTQUFTLE9BQVc7QUFDekMsUUFBSSxPQUFPLFNBQVMsU0FBVTtBQUM5QixRQUFJLEtBQUssSUFBSSxJQUFjLEVBQUc7QUFDOUIsU0FBSyxJQUFJLElBQWM7QUFFdkIsUUFBSSxlQUFlLElBQUksR0FBRztBQUN4QixVQUFJLEtBQUssWUFBWSxJQUFJLENBQUM7QUFBQSxJQUM1QjtBQUNBLFFBQUksTUFBTSxRQUFRLElBQUksR0FBRztBQUN2QixpQkFBVyxLQUFLLEtBQU0sT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNwQyxPQUFPO0FBQ0wsaUJBQVcsS0FBSyxPQUFPLE9BQU8sSUFBK0IsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQzlFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsZUFBZSxNQUFnRDtBQUN0RSxNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLFFBQU0sV0FBVyxFQUFFO0FBQ25CLE1BQ0UsYUFBYSxXQUNiLGFBQWEsZ0NBQ2IsYUFBYSxrQkFDYjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FBTyxPQUFPLEVBQUUsWUFBWSxZQUFZLE9BQU8sRUFBRSxXQUFXLFlBQVksRUFBRSxXQUFXO0FBQ3ZGO0FBRUEsU0FBUyxZQUFZLE1BQXdEO0FBQzNFLE1BQUksS0FBSyxlQUFlLGdDQUFnQyxPQUFPLEtBQUssVUFBVSxVQUFVO0FBQ3RGLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFdBQVcsS0FBYyxLQUE4QztBQUM5RSxNQUFJLE9BQU8sUUFBUSxZQUFZLFFBQVEsS0FBTSxRQUFPO0FBQ3BELFFBQU0sSUFBSTtBQUVWLE1BQUksRUFBRSxlQUFlLGlCQUFrQixRQUFPO0FBRTlDLFFBQU0sU0FBUyxVQUFVLEVBQUUsT0FBTztBQUNsQyxRQUFNLFNBQVMsSUFBSSxFQUFFLE1BQU07QUFDM0IsTUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFRLFFBQU87QUFFL0IsUUFBTSxPQUFPLElBQUksRUFBRSxJQUFJO0FBQ3ZCLFFBQU0sYUFBYSxJQUFJLElBQUksTUFBTSxZQUFZLEdBQUcsTUFBTTtBQUN0RCxRQUFNLGFBQWEsSUFBSSxZQUFZLE1BQU07QUFDekMsUUFBTSxTQUFTLFVBQVUsWUFBWSxXQUFXO0FBQ2hELFFBQU0sWUFBWSxVQUFVLFlBQVksT0FBTyxLQUFLLFVBQVUsT0FBTyxXQUFXO0FBQ2hGLE1BQUksQ0FBQyxVQUFVLENBQUMsVUFBVyxRQUFPO0FBRWxDLFFBQU0sWUFBWSxJQUFJLElBQUksSUFBSSxFQUFFLFVBQVUsR0FBRyxrQkFBa0IsR0FBRyxNQUFNO0FBQ3hFLFFBQU0sZUFBZSxVQUFVLFdBQVcsSUFBSTtBQUM5QyxRQUFNLGlCQUFpQixVQUFVLE9BQU8sU0FBUyxLQUFLO0FBQ3RELFFBQU0sT0FBTyxnQkFBZ0I7QUFFN0IsUUFBTSxXQUFXLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQztBQUMxQyxRQUFNLG1CQUFtQixJQUFJLFdBQVcsVUFBVTtBQUNsRCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxPQUFPLFlBQVksb0JBQW9CLFFBQVE7QUFDckQsUUFBTSxRQUFRLGFBQWEsTUFBTTtBQUVqQyxRQUFNLFlBQVksa0JBQWtCLEdBQUcsTUFBTTtBQUU3QyxRQUFNLFdBQVcsaUJBQWlCLFVBQVUsT0FBTyxVQUFVLENBQUM7QUFDOUQsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUV0QixRQUFNLFFBQVEsSUFBSSxFQUFFLEtBQUs7QUFDekIsUUFBTSxZQUFZLFVBQVUsT0FBTyxLQUFLLEtBQUssVUFBVSxVQUFVLE9BQU8sS0FBSyxDQUFDO0FBRTlFLFFBQU0sUUFBd0I7QUFBQSxJQUM1QixVQUFVO0FBQUEsSUFDVixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixXQUFXO0FBQUEsSUFDWCxtQkFBbUIsSUFBSTtBQUFBLElBQ3ZCLGNBQWMsSUFBSTtBQUFBLElBQ2xCLHNCQUFzQjtBQUFBLElBQ3RCLFdBQVcsR0FBRyxnQkFBZ0IsSUFBSSxNQUFNLFdBQVcsTUFBTTtBQUFBLElBQ3pELFlBQVk7QUFBQSxJQUNaLG1CQUFtQixVQUFVLE9BQU8seUJBQXlCO0FBQUEsSUFDN0Qsa0JBQWtCLFVBQVUsT0FBTyx1QkFBdUI7QUFBQSxJQUMxRCxpQkFBaUIsVUFBVSxPQUFPLG9CQUFvQjtBQUFBLElBQ3RELG9CQUFvQjtBQUFBLE1BQ2xCLElBQUksSUFBSSxPQUFPLHVCQUF1QixHQUFHLE1BQU0sR0FBRyxXQUMvQyxPQUFtQztBQUFBLElBQ3hDO0FBQUEsSUFDQTtBQUFBLElBQ0EsZUFBZSxpQkFBaUIsTUFBTSxJQUFJO0FBQUEsSUFDMUMsTUFBTSxVQUFVLE9BQU8sSUFBSTtBQUFBLElBQzNCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDM0MsZUFBZSxVQUFVLE9BQU8sYUFBYTtBQUFBLElBQzdDLGFBQWEsVUFBVSxPQUFPLFdBQVc7QUFBQSxJQUN6QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsWUFBWTtBQUFBLElBQ1osZ0JBQWdCLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDL0Msb0JBQW9CO0FBQUEsTUFDbEI7QUFBQSxRQUNFLGFBQWEsSUFBSTtBQUFBLFFBQ2pCLE9BQU8sVUFBVSxPQUFPLGNBQWM7QUFBQSxRQUN0QyxVQUFVLFVBQVUsT0FBTyxhQUFhO0FBQUEsUUFDeEMsU0FBUyxVQUFVLE9BQU8sV0FBVztBQUFBLFFBQ3JDLFFBQVEsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNwQyxPQUFPO0FBQUEsUUFDUCxXQUFXLFVBQVUsT0FBTyxjQUFjO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQUEsSUFDQSxhQUFhO0FBQUEsSUFDYixzQkFBc0I7QUFBQSxJQUN0QixnQkFBZ0I7QUFBQSxJQUNoQixnQkFBZ0IsSUFBSTtBQUFBLElBQ3BCLGdCQUFnQjtBQUFBLEVBQ2xCO0FBRUEsU0FBTztBQUNUO0FBRUEsU0FBUyxrQkFBa0IsR0FBNEIsUUFBNEM7QUFDakcsTUFBSSxPQUFPLDJCQUEyQixPQUFPLHdCQUF5QixRQUFPO0FBQzdFLE1BQUksT0FBTywwQkFBMkIsUUFBTztBQUM3QyxNQUFJLE9BQU8sb0JBQW9CLFFBQVEsT0FBTyxxQkFBc0IsUUFBTztBQUMzRSxNQUFJLEVBQUUsZUFBZSw4QkFBOEI7QUFBQSxFQUVuRDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLFVBQVUsSUFBSSxPQUFRLEVBQXdCLElBQUksSUFBSTtBQUFBLEVBQ3RGLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxnQkFBZ0IsVUFBNkM7QUFDcEUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFNBQU8sSUFDSjtBQUFBLElBQUksQ0FBQyxNQUNKLE9BQU8sTUFBTSxZQUFZLEtBQUssaUJBQWlCLElBQzNDLE9BQVEsRUFBK0IsV0FBVyxJQUNsRDtBQUFBLEVBQ04sRUFDQyxPQUFPLENBQUMsTUFBbUIsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLENBQUM7QUFDckU7QUFFQSxTQUFTLFlBQVksVUFBZ0Q7QUFDbkUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFFBQU0sTUFBbUIsQ0FBQztBQUMxQixhQUFXLEtBQUssS0FBSztBQUNuQixRQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTTtBQUN6QyxVQUFNLElBQUk7QUFDVixVQUFNLFFBQVEsVUFBVSxFQUFFLEdBQUc7QUFDN0IsVUFBTSxXQUFXLFVBQVUsRUFBRSxZQUFZO0FBQ3pDLFVBQU0sVUFBVSxVQUFVLEVBQUUsV0FBVztBQUN2QyxRQUFJLENBQUMsU0FBUyxDQUFDLFNBQVU7QUFDekIsUUFBSSxLQUFLLEVBQUUsT0FBTyxVQUFVLFNBQVMsV0FBVyxTQUFTLENBQUM7QUFBQSxFQUM1RDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsYUFBYSxRQUE4QztBQUNsRSxRQUFNLFdBQVcsSUFBSSxPQUFPLGlCQUFpQjtBQUM3QyxRQUFNLFVBQVUsV0FBVyxRQUFRLFNBQVMsS0FBSyxJQUFJLENBQUM7QUFDdEQsUUFBTSxVQUFVLFFBQVEsSUFBSSxPQUFPLFFBQVEsR0FBRyxLQUFLO0FBQ25ELFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sU0FBUyxDQUFDLEdBQUcsU0FBUyxHQUFHLE9BQU8sRUFBRSxPQUFPLENBQUMsTUFBTTtBQUNwRCxRQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTSxRQUFPO0FBQ2hELFVBQU0sS0FDSixVQUFXLEVBQThCLFNBQVMsS0FDbEQsVUFBVyxFQUE4QixNQUFNO0FBQ2pELFFBQUksQ0FBQyxHQUFJLFFBQU87QUFDaEIsUUFBSSxLQUFLLElBQUksRUFBRSxFQUFHLFFBQU87QUFDekIsU0FBSyxJQUFJLEVBQUU7QUFDWCxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0QsU0FBTyxPQUFPLElBQUksQ0FBQyxRQUFRLFdBQVcsR0FBOEIsQ0FBQztBQUN2RTtBQUVBLFNBQVMsV0FBVyxHQUF1QztBQUN6RCxRQUFNLE9BQU8sVUFBVSxFQUFFLElBQUk7QUFDN0IsUUFBTSxXQUFXLGdCQUFnQixHQUFHLElBQUk7QUFDeEMsUUFBTUMsUUFBTyxJQUFJLEVBQUUsYUFBYTtBQUNoQyxRQUFNLFlBQVksSUFBSSxFQUFFLFVBQVU7QUFDbEMsUUFBTSxhQUFhLFVBQVUsV0FBVyxlQUFlO0FBQ3ZELFFBQU0sVUFBVSxVQUFVLEVBQUUsWUFBWTtBQUN4QyxRQUFNLFVBQ0osVUFBVSxFQUFFLFNBQVMsS0FDckIsVUFBVSxFQUFFLE1BQU0sS0FDbEIsR0FBRyxRQUFRLE9BQU8sSUFBSSxLQUFLLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUMzRCxTQUFPO0FBQUEsSUFDTCxVQUFVO0FBQUEsSUFDVixZQUFhLFFBQVE7QUFBQSxJQUNyQixjQUFjLFlBQVk7QUFBQSxJQUMxQixtQkFBbUI7QUFBQSxJQUNuQixRQUFRO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxjQUFjLGVBQWUsT0FBTyxhQUFhLE1BQU87QUFBQSxJQUN4RCxPQUFPLFVBQVVBLE9BQU0sS0FBSztBQUFBLElBQzVCLFFBQVEsVUFBVUEsT0FBTSxNQUFNO0FBQUEsSUFDOUIsVUFBVTtBQUFBLElBQ1YsZ0JBQWdCO0FBQUEsSUFDaEIsa0JBQWtCO0FBQUEsSUFDbEIsaUJBQWlCO0FBQUEsRUFDbkI7QUFDRjtBQUVBLFNBQVMsZ0JBQWdCLEdBQTRCLE1BQW9DO0FBQ3ZGLE1BQUksU0FBUyxRQUFTLFFBQU8sVUFBVSxFQUFFLGVBQWUsS0FBSyxVQUFVLEVBQUUsU0FBUztBQUNsRixRQUFNLFdBQVcsUUFBUSxJQUFJLEVBQUUsVUFBVSxHQUFHLFFBQVE7QUFDcEQsTUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLFVBQVUsRUFBRSxlQUFlO0FBRTdELE1BQUksT0FBZ0Q7QUFDcEQsYUFBVyxLQUFLLFVBQVU7QUFDeEIsVUFBTSxLQUFLLFVBQVUsRUFBRSxZQUFZO0FBQ25DLFVBQU0sTUFBTSxVQUFVLEVBQUUsR0FBRztBQUMzQixRQUFJLENBQUMsSUFBSztBQUNWLFFBQUksT0FBTyxhQUFhO0FBQ3RCLFlBQU0sS0FBSyxVQUFVLEVBQUUsT0FBTyxLQUFLO0FBQ25DLFVBQUksQ0FBQyxRQUFRLEtBQUssS0FBSyxRQUFTLFFBQU8sRUFBRSxLQUFLLFNBQVMsR0FBRztBQUFBLElBQzVELFdBQVcsQ0FBQyxNQUFNO0FBRWhCLGFBQU8sRUFBRSxLQUFLLFNBQVMsRUFBRTtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNBLFNBQU8sTUFBTSxPQUFPO0FBQ3RCO0FBRUEsU0FBUyxpQkFBaUIsTUFBYyxNQUEyQjtBQUNqRSxNQUFJLEtBQUssV0FBVyxFQUFHLFFBQU87QUFDOUIsTUFBSSxNQUFNO0FBQ1YsYUFBVyxLQUFLLEtBQU0sT0FBTSxJQUFJLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVE7QUFDOUQsU0FBTztBQUNUO0FBRUEsU0FBUyxpQkFBaUIsR0FBaUM7QUFDekQsTUFBSSxDQUFDLEVBQUcsUUFBTztBQUVmLFFBQU0sSUFBSSxJQUFJLEtBQUssQ0FBQztBQUNwQixNQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU87QUFDdEMsU0FBTyxFQUFFLFlBQVk7QUFDdkI7QUFFQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsU0FBTyxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsSUFBSSxJQUFJO0FBQ3JEO0FBQ0EsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ3hELE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsVUFBTSxJQUFJLE9BQU8sQ0FBQztBQUNsQixRQUFJLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUFBLEVBQ2pDO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLEdBQW9CO0FBQ3JDLFNBQU8sVUFBVSxDQUFDLEtBQUs7QUFDekI7QUFDQSxTQUFTLElBQUksR0FBNEM7QUFDdkQsU0FBTyxPQUFPLE1BQU0sWUFBWSxNQUFNLFFBQVEsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUN6RCxJQUNEO0FBQ047QUFDQSxTQUFTLFFBQVEsR0FBdUI7QUFDdEMsU0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQztBQUNqQzs7O0FDdlVBLElBQU0sV0FBVztBQUVWLFNBQVMsV0FBbUI7QUFDakMsUUFBTSxLQUFLLEtBQUssSUFBSTtBQUNwQixNQUFJLFNBQVM7QUFDYixNQUFJLElBQUk7QUFDUixXQUFTLElBQUksR0FBRyxJQUFJLElBQUksS0FBSztBQUMzQixjQUFVLFNBQVMsSUFBSSxFQUFFLEtBQUssT0FBTztBQUNyQyxRQUFJLEtBQUssTUFBTSxJQUFJLEVBQUU7QUFBQSxFQUN2QjtBQUNBLFFBQU0sT0FBTyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3RELE1BQUksV0FBVztBQUNmLGFBQVcsS0FBSyxLQUFNLGFBQVksU0FBUyxJQUFJLEVBQUUsS0FBSztBQUN0RCxTQUFPLFNBQVM7QUFDbEI7QUFFTyxTQUFTLFdBQVcsSUFBb0I7QUFDN0MsU0FBTyxHQUFHLE1BQU0sRUFBRTtBQUNwQjs7O0FDWE8sU0FBUyxrQkFBa0IsTUFBK0I7QUFDL0QsUUFBTSxXQUE0QixDQUFDO0FBQ25DLE1BQUksVUFBa0MsQ0FBQztBQUN2QyxNQUFJLGFBQWE7QUFDakIsYUFBVyxXQUFXLEtBQUssTUFBTSxJQUFJLEdBQUc7QUFDdEMsVUFBTSxPQUFPLGNBQWMsT0FBTztBQUNsQyxRQUFJLEtBQUssS0FBSyxNQUFNLEdBQUk7QUFDeEIsUUFBSSxnQkFBZ0IsS0FBSyxJQUFJLEdBQUc7QUFDOUIsbUJBQWE7QUFDYjtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsV0FBWTtBQUVqQixVQUFNLFlBQVksS0FBSyxNQUFNLDRCQUE0QjtBQUN6RCxRQUFJLFdBQVc7QUFDYixVQUFJLFFBQVEsVUFBVSxRQUFRLE1BQU8sVUFBUyxLQUFLLE9BQXdCO0FBQzNFLGdCQUFVLEVBQUUsUUFBUSxRQUFRLFVBQVUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtBQUNoRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGFBQWEsS0FBSyxNQUFNLHdCQUF3QjtBQUN0RCxRQUFJLGNBQWMsQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQ3JDLFVBQUksUUFBUSxVQUFVLFFBQVEsTUFBTyxVQUFTLEtBQUssT0FBd0I7QUFDM0UsZ0JBQVUsRUFBRSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2pEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sdUJBQXVCO0FBQ3JELFFBQUksY0FBYyxRQUFRLFFBQVE7QUFDaEMsY0FBUSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRTtBQUMzQztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsTUFBSSxRQUFRLFVBQVUsUUFBUSxNQUFPLFVBQVMsS0FBSyxPQUF3QjtBQUMzRSxTQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUNuRDtBQUVBLFNBQVMsY0FBYyxNQUFzQjtBQUczQyxRQUFNLE1BQU0sS0FBSyxRQUFRLEdBQUc7QUFDNUIsU0FBTyxRQUFRLEtBQUssT0FBTyxLQUFLLE1BQU0sR0FBRyxHQUFHO0FBQzlDO0FBRUEsU0FBUyxRQUFRLEdBQW1CO0FBQ2xDLFFBQU0sVUFBVSxFQUFFLEtBQUs7QUFDdkIsTUFDRyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQy9DLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsR0FDaEQ7QUFDQSxXQUFPLFFBQVEsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUM1QjtBQUNBLFNBQU87QUFDVDs7O0FDTkEsSUFBTSxjQUFjLFFBQVEsUUFBUSxZQUFZLEVBQUU7QUFFbEQsZUFBZSxDQUFDLE9BQWlCO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxhQUFhLE9BQU8sR0FBRyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFLENBQUM7QUFJRCxRQUFRLFFBQVEsWUFBWSxZQUFZLFlBQVk7QUFDbEQsUUFBTSxLQUFLLHVCQUF1QixFQUFFLFNBQVMsWUFBWSxDQUFDO0FBQzFELFFBQU0sT0FBTyxTQUFTO0FBQ3hCLENBQUM7QUFFRCxRQUFRLFFBQVEsVUFBVSxZQUFZLE1BQU07QUFDMUMsT0FBSyxPQUFPLFNBQVM7QUFDdkIsQ0FBQztBQUdELEtBQUssT0FBTyxhQUFhO0FBRXpCLGVBQWUsT0FBTyxRQUErQjtBQUNuRCxNQUFJO0FBQ0YsVUFBTSxhQUFhO0FBQ25CLFVBQU0sNEJBQTRCO0FBQ2xDLFVBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBSSxTQUFTLE9BQU8sU0FBUyxTQUFTLFNBQVMsTUFBTTtBQUNuRCxZQUFNLGlCQUFpQixLQUFLO0FBQzVCLFlBQU0sb0JBQW9CLEtBQUs7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTSxjQUFjO0FBQUEsUUFDbEIsUUFBUTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWU7QUFBQSxRQUNmLHdCQUF3QjtBQUFBLE1BQzFCLENBQUM7QUFDRCxZQUFNLEtBQUssd0NBQXdDLEVBQUUsT0FBTyxDQUFDO0FBQUEsSUFDL0Q7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sTUFBTyxlQUFlLEVBQUUsUUFBUSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFBQSxFQUMvRDtBQUNGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxRQUFNLFFBQVEsT0FBTyxNQUFNLGFBQWE7QUFDeEMsUUFBTSxRQUFRLE9BQU8sTUFBTSxtQkFBbUI7QUFDOUMsUUFBTSxRQUFRLE9BQU8sT0FBTyxlQUFlLEVBQUUsaUJBQWlCLG9CQUFvQixDQUFDO0FBQ25GLFFBQU0sUUFBUSxPQUFPLE9BQU8scUJBQXFCO0FBQUEsSUFDL0MsaUJBQWlCLGdDQUFnQztBQUFBLEVBQ25ELENBQUM7QUFDSDtBQUVBLFFBQVEsT0FBTyxRQUFRLFlBQVksQ0FBQyxVQUFVO0FBQzVDLE1BQUksTUFBTSxTQUFTLGVBQWU7QUFDaEMsU0FBSyxpQkFBaUI7QUFBQSxFQUN4QixXQUFXLE1BQU0sU0FBUyxxQkFBcUI7QUFDN0MsU0FBSyxpQkFBaUIsS0FBSztBQUFBLEVBQzdCO0FBQ0YsQ0FBQztBQUlELElBQUksUUFBUSxRQUFRLFdBQVc7QUFDN0IsVUFBUSxPQUFPLFVBQVUsWUFBWSxZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNLFFBQVEsY0FBYyxPQUFPO0FBQUEsSUFDckMsU0FBUyxLQUFLO0FBRVosWUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUN2RSxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFBQSxJQUN4QztBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBSUEsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLEtBQWMsWUFBWTtBQUMvRCxNQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRyxRQUFPO0FBQ25DLFNBQU8sY0FBYyxHQUFHLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDdkMsU0FBSyxNQUFPLDBCQUEwQixFQUFFLE1BQU0sSUFBSSxNQUFNLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUMvRSxVQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0gsQ0FBQztBQUVELFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELFNBQU8sQ0FBQyxDQUFDLEtBQUssT0FBTyxNQUFNLFlBQVksT0FBUSxFQUF5QixTQUFTO0FBQ25GO0FBRUEsZUFBZSxjQUFjLEtBQXVDO0FBQ2xFLFVBQVEsSUFBSSxNQUFNO0FBQUEsSUFDaEIsS0FBSztBQUNILFlBQU0saUJBQWlCLElBQUksVUFBVSxJQUFJLEtBQUssSUFBSSxRQUFRO0FBQzFELGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxLQUFLLGdDQUFnQyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ3ZFLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxLQUFLLCtCQUErQixFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ3RFLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsVUFBSSxJQUFJLFVBQVUsUUFBUTtBQUN4QixjQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNsRCxXQUFXLElBQUksVUFBVSxTQUFTO0FBQ2hDLGNBQU0sTUFBTyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ3BELE9BQU87QUFDTCxjQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNsRDtBQUNBLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVyxJQUFJLE1BQU07QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVztBQUNqQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxTQUFTLE1BQU07QUFDckIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sWUFBWSxJQUFJLFFBQVEsTUFBTTtBQUNwQyxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxlQUFlLEVBQUUsYUFBYSxJQUFJLEdBQUcsQ0FBQztBQUM1QyxZQUFNLEtBQUssd0JBQXdCLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUNqRCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxvQkFBb0IsSUFBSTtBQUM5QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxpQkFBaUIsSUFBSTtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxjQUFjO0FBQ3BCLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxRQUFRLFFBQVEsZ0JBQWdCO0FBQ3RDLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLLGVBQWU7QUFDbEIsWUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixZQUFNLE1BQU0sVUFBVSxDQUFDO0FBQ3ZCLFlBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFDakMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCO0FBQUEsSUFDQTtBQUNFLGFBQU8sRUFBRSxJQUFJLE9BQU8sT0FBTyx1QkFBdUI7QUFBQSxFQUN0RDtBQUNGO0FBSUEsZUFBZSxpQkFBaUIsVUFBa0IsS0FBYSxVQUFrQztBQUMvRixNQUFJLGtCQUFrQixJQUFJLFFBQVEsRUFBRztBQUNyQyxNQUFJLENBQUMsZ0JBQWdCLElBQUksUUFBUSxFQUFHO0FBRXBDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFPbkMsUUFBTSxVQUFVLElBQUksSUFBSSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUNuRSxRQUFNLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFFMUMsTUFBSTtBQUNKLE1BQUk7QUFDRixpQkFBYSxVQUFVLFVBQVU7QUFBQSxNQUMvQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1A7QUFBQSxNQUNBLGdCQUFnQjtBQUFBLElBQ2xCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sV0FBVyxtQkFBbUIsVUFBVSxLQUFLLFVBQVUsR0FBRztBQUNoRTtBQUFBLEVBQ0Y7QUFPQSxNQUFJLFdBQVcsYUFBYSxXQUFXLEdBQUc7QUFDeEMsVUFBTSxLQUFLLDRDQUF1QztBQUFBLE1BQ2hEO0FBQUEsTUFDQSxXQUFXLGNBQWMsVUFBVSxDQUFDLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxNQUNqRCxXQUFXLGVBQWUsUUFBUSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsTUFDL0MsWUFBWSxlQUFlLFFBQVE7QUFBQSxJQUNyQyxDQUFDO0FBQUEsRUFDSCxPQUFPO0FBQ0wsVUFBTSxLQUFLLHdCQUF3QjtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxVQUFVLFdBQVcsYUFBYTtBQUFBLE1BQ2xDLE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDMUIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxNQUFJLFdBQVcsT0FBTyxXQUFXLEVBQUc7QUFHcEMsUUFBTSxXQUFXLG9CQUFJLElBQThCO0FBQ25ELGFBQVcsS0FBSyxXQUFXLFFBQVE7QUFDakMsVUFBTSxNQUFNLFNBQVMsSUFBSSxFQUFFLGNBQWMsS0FBSyxDQUFDO0FBQy9DLFFBQUksS0FBSyxDQUFDO0FBQ1YsYUFBUyxJQUFJLEVBQUUsZ0JBQWdCLEdBQUc7QUFBQSxFQUNwQztBQUVBLGFBQVcsQ0FBQyxRQUFRLE1BQU0sS0FBSyxVQUFVO0FBQ3ZDLFVBQU0sTUFBTSxNQUFNLGdCQUFnQixRQUFRLFlBQVksS0FBSyxRQUFRO0FBQ25FLFFBQUksUUFBUTtBQUNaLGVBQVcsS0FBSyxRQUFRO0FBQ3RCLFlBQU0sV0FBVyxJQUFJLGFBQWEsRUFBRSxRQUFRO0FBQzVDLFVBQUksVUFBVTtBQUdaLGlCQUFTLGVBQWU7QUFDeEIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGdCQUFnQixFQUFFO0FBQzNCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxjQUFjLEVBQUU7QUFDekIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGlCQUFpQixFQUFFO0FBQzVCLGNBQU0sT0FBTyxTQUFTLG1CQUFtQixTQUFTLG1CQUFtQixTQUFTLENBQUM7QUFDL0UsY0FBTSxPQUFPLEVBQUUsbUJBQW1CLENBQUM7QUFDbkMsWUFBSSxTQUFTLENBQUMsUUFBUSxLQUFLLGdCQUFnQixLQUFLLGNBQWM7QUFDNUQsbUJBQVMsbUJBQW1CLEtBQUssSUFBSTtBQUFBLFFBQ3ZDO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxVQUEwQixFQUFFLEdBQUcsR0FBRyxnQkFBZ0IsSUFBSSxPQUFPO0FBQ25FLFlBQUksYUFBYSxFQUFFLFFBQVEsSUFBSTtBQUMvQixpQkFBUztBQUFBLE1BQ1g7QUFDQSxVQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsR0FBRztBQUNoRCxZQUFJLG1CQUFtQixLQUFLLEVBQUUsUUFBUTtBQUFBLE1BQ3hDO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLE1BQU07QUFDbkUsUUFBSSxRQUFRLEdBQUc7QUFDYixZQUFNLEtBQUssbUJBQW1CO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsT0FBTyxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUU7QUFBQSxNQUN2QyxDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUksT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFVBQVUsdUJBQXVCO0FBQ2pFLFlBQU0sWUFBWSxRQUFRLFdBQVc7QUFBQSxJQUN2QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGdCQUNiLFFBQ0EsSUFDQSxXQUNBLFVBQ29CO0FBQ3BCLFFBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUNyQyxNQUFJLElBQUssUUFBTztBQUNoQixRQUFNLE1BQWlCO0FBQUEsSUFDckIsUUFBUSxTQUFTO0FBQUEsSUFDakIsZ0JBQWdCO0FBQUEsSUFDaEIsWUFBWTtBQUFBLElBQ1osaUJBQWlCO0FBQUEsSUFDakIsY0FBYyxDQUFDO0FBQUEsSUFDZixvQkFBb0IsQ0FBQztBQUFBLElBQ3JCLGdCQUFnQixDQUFDLFFBQVE7QUFBQSxJQUN6QixZQUFZO0FBQUEsRUFDZDtBQUNBLFFBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsUUFBTSxLQUFLLGVBQWUsRUFBRSxRQUFRLEtBQUssV0FBVyxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQ2pFLFNBQU87QUFDVDtBQUlBLGVBQWUsbUJBQWtDO0FBQy9DLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxNQUFNLEtBQUssSUFBSTtBQUNyQixhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUMvQyxVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksZUFBZTtBQUMzQyxRQUFJLE9BQU8sU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLGVBQWU7QUFDeEQsWUFBTSxZQUFZLFFBQVEsTUFBTTtBQUFBLElBQ2xDO0FBQUEsRUFDRjtBQUNGO0FBRUEsZUFBZSw4QkFBNkM7QUFHMUQsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFVBQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxlQUFlO0FBQzNDLFFBQUksT0FBTyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsZUFBZTtBQUN4RCxZQUFNLFlBQVksUUFBUSxNQUFNO0FBQUEsSUFDbEM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlLFNBQVMsUUFBK0I7QUFDckQsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxhQUFXLFVBQVUsT0FBTyxLQUFLLEdBQUcsR0FBRztBQUNyQyxVQUFNLFlBQVksUUFBUSxNQUFNO0FBQUEsRUFDbEM7QUFDRjtBQUVBLGVBQWUsWUFBWSxRQUFnQixRQUErQjtBQUN4RSxRQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFDckMsTUFBSSxDQUFDLElBQUs7QUFDVixRQUFNLFNBQVMsT0FBTyxPQUFPLElBQUksWUFBWTtBQUM3QyxNQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFVBQU0sZUFBZSxNQUFNO0FBQzNCO0FBQUEsRUFDRjtBQUNBLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsTUFBTTtBQUN0RCxVQUFNLEtBQUssdUNBQXVDLEVBQUUsT0FBTyxDQUFDO0FBQzVEO0FBQUEsRUFDRjtBQUNBLFFBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxRQUFNLEtBQUssV0FBVyxJQUFJLFVBQVU7QUFDcEMsUUFBTSxNQUFNLElBQUksV0FBVyxNQUFNLEdBQUcsRUFBRTtBQUN0QyxRQUFNLFVBQVUsT0FBTyxNQUFNLElBQUksRUFBRSxJQUFJLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFDN0QsUUFBTSxXQUFXLFFBQVEsTUFBTSxJQUFJLEVBQUUsSUFBSSxXQUFXLElBQUksTUFBTSxDQUFDO0FBRS9ELFFBQU0sVUFBMEI7QUFBQSxJQUM5QixnQkFBZ0I7QUFBQSxJQUNoQixnQkFBZ0IsSUFBSTtBQUFBLElBQ3BCLGdCQUFnQjtBQUFBLElBQ2hCLGFBQWEsSUFBSTtBQUFBLElBQ2pCLFVBQVUsSUFBSSxlQUFlLEtBQUssR0FBRztBQUFBLElBQ3JDLFlBQVksVUFBVTtBQUFBLElBQ3RCLFlBQVksSUFBSTtBQUFBLElBQ2hCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBb0I7QUFBQSxJQUN4QixnQkFBZ0I7QUFBQSxJQUNoQixnQkFBZ0IsSUFBSTtBQUFBLElBQ3BCLGdCQUFnQjtBQUFBLElBQ2hCLGFBQWEsSUFBSTtBQUFBLElBQ2pCLG9CQUFvQixJQUFJO0FBQUEsRUFDMUI7QUFFQSxRQUFNLFlBQVksWUFBWSxNQUFNLElBQUksR0FBRyxJQUFJLE9BQU8sTUFBTSxTQUFTLE9BQU8sV0FBVyxJQUFJLEtBQUssR0FBRyxTQUFTLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFFbEksTUFBSTtBQUNGLFVBQU0sT0FBTyxRQUFRO0FBQUEsTUFDbkIsTUFBTTtBQUFBLE1BQ04sZUFBZSxTQUFTLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUMvRCxTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQ0QsVUFBTSxPQUFPLFFBQVE7QUFBQSxNQUNuQixNQUFNO0FBQUEsTUFDTixlQUFlLFNBQVMsS0FBSyxVQUFVLE1BQU0sTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLE1BQzVELFNBQVMsU0FBUyxNQUFNLElBQUksR0FBRyxJQUFJLEtBQUssbUJBQW1CLE1BQU0sYUFBYSxXQUFXLElBQUksTUFBTSxDQUFDO0FBQUEsSUFDdEcsQ0FBQztBQUNELFVBQU0sZUFBZSxNQUFNO0FBQzNCLFVBQU0sWUFBWSxRQUFRO0FBQUEsTUFDeEIsYUFBYSxNQUFNLFlBQVksR0FBRyxNQUFNLEdBQUcsY0FBYztBQUFBLE1BQ3pELFdBQVc7QUFBQSxNQUNYLGVBQWUsSUFBSTtBQUFBLE1BQ25CLGtCQUFrQixNQUFNLFlBQVksR0FBRyxNQUFNLEdBQUcsa0JBQWtCLEtBQUssT0FBTztBQUFBLE1BQzlFLGVBQWU7QUFBQSxJQUNqQixDQUFDO0FBQ0QsVUFBTSxLQUFLLG1CQUFtQjtBQUFBLE1BQzVCO0FBQUEsTUFDQTtBQUFBLE1BQ0EsUUFBUSxPQUFPO0FBQUEsTUFDZixLQUFLLFdBQVcsSUFBSSxNQUFNO0FBQUEsTUFDMUIsTUFBTTtBQUFBLElBQ1IsQ0FBQztBQUNEO0FBQ0UsWUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixRQUFJLGVBQWUsYUFBYTtBQUM5QixZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sU0FDSixJQUFJLGFBQWEsU0FDYixlQUNBLElBQUksYUFBYSxlQUNmLGlCQUNBLElBQUksYUFBYSxZQUNmLGtCQUNBLEtBQUs7QUFDZixZQUFNLGNBQWM7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTyxJQUFJO0FBQUEsUUFDWCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLE1BQy9CLENBQUM7QUFDRCxZQUFNLE1BQU8sZ0JBQWdCO0FBQUEsUUFDM0I7QUFBQSxRQUNBO0FBQUEsUUFDQSxVQUFVLElBQUk7QUFBQSxRQUNkLFFBQVEsSUFBSTtBQUFBLFFBQ1osU0FBUyxJQUFJO0FBQUEsTUFDZixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0wsWUFBTSxNQUFPLGdCQUFnQixFQUFFLFFBQVEsUUFBUSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFBQSxJQUN4RTtBQUFBLEVBRUYsVUFBRTtBQUNBLFVBQU0sZUFBZTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFJQSxlQUFlLFdBQVcsUUFBK0I7QUFNdkQsUUFBTSxZQUFZLGlCQUFpQixNQUFNO0FBQ3pDLFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxRQUFRLEtBQUssZUFBZSxDQUFDO0FBQ25FLE1BQUksQ0FBRSxNQUFNLGFBQWEsTUFBTSxHQUFJO0FBQ2pDLFVBQU0sT0FBTSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNuQyxVQUFNLGFBQWEsUUFBUTtBQUFBLE1BQ3pCLFFBQVEsU0FBUztBQUFBLE1BQ2pCLGdCQUFnQjtBQUFBLE1BQ2hCLFlBQVk7QUFBQSxNQUNaLGlCQUFpQjtBQUFBLE1BQ2pCLGNBQWMsQ0FBQztBQUFBLE1BQ2Ysb0JBQW9CLENBQUM7QUFBQSxNQUNyQixnQkFBZ0IsQ0FBQztBQUFBLE1BQ2pCLFlBQVk7QUFBQSxJQUNkLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssV0FBVyxRQUFRLEtBQUssQ0FBQztBQUM1RDtBQUVBLGVBQWUsYUFBNEI7QUFDekMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsT0FBTyxTQUFTLE9BQU8sQ0FBQztBQUM5RCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLFdBQVcsRUFBRSxNQUFNO0FBQUEsRUFDM0I7QUFDRjtBQUlBLGVBQWUsV0FDYixRQUNBLFVBQ0EsS0FDQSxLQUNBLEtBQ2U7QUFDZixRQUFNLE1BQU8sd0JBQXdCLEVBQUUsUUFBUSxVQUFVLEtBQUssR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQ3JGLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLFVBQTZCO0FBQUEsSUFDakMsZ0JBQWdCO0FBQUEsSUFDaEI7QUFBQSxJQUNBO0FBQUEsSUFDQSxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDcEMsWUFBWTtBQUFBLElBQ1osT0FBTyxjQUFjLEdBQUc7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssV0FBVyxRQUFRLFdBQVc7QUFDekMsUUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxDQUFDO0FBQy9DLFFBQU0sT0FBTyxtQkFBbUIsRUFBRSxJQUFJLElBQUk7QUFDMUMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ25CO0FBQUEsTUFDQSxlQUFlLFNBQVMsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLE1BQy9ELFNBQVMsZUFBZSxNQUFNLElBQUksUUFBUTtBQUFBLElBQzVDLENBQUM7QUFBQSxFQUNILFNBQVMsTUFBTTtBQUNiLFVBQU0sTUFBTyw0QkFBNEIsRUFBRSxHQUFHLGNBQWMsSUFBSSxFQUFFLENBQUM7QUFBQSxFQUNyRTtBQUNGO0FBRUEsZUFBZSxLQUFLLEdBQTRCO0FBQzlDLFFBQU0sTUFBTSxJQUFJLFlBQVksRUFBRSxPQUFPLENBQUM7QUFDdEMsUUFBTSxTQUFTLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxHQUFHO0FBQ3hELFFBQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxXQUFXLE1BQU0sQ0FBQyxFQUMxQyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFO0FBQ1YsU0FBTyxJQUFJLE1BQU0sR0FBRyxDQUFDO0FBQ3ZCO0FBSUEsZUFBZSxpQkFBaUIsT0FBK0I7QUFDN0QsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU87QUFBQSxNQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsTUFDUCxlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxJQUMxQixDQUFDO0FBQ0QsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsTUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXLFFBQVEsS0FBSyxXQUFXO0FBQ3BELFVBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTO0FBQ2xELFFBQUksTUFBTSw4QkFBK0I7QUFBQSxFQUMzQztBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxJQUFJLE1BQU0sT0FBTyxpQkFBaUI7QUFJeEMsUUFBSSxXQUFXO0FBQ2YsUUFBSSxTQUFTLFVBQVUsU0FBUyxXQUFXLEVBQUUsZ0JBQWdCO0FBQzNELGlCQUFXLE1BQU0sT0FBTyxhQUFhLFNBQVMsTUFBTTtBQUFBLElBQ3REO0FBQ0EsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTyxFQUFFO0FBQUEsTUFDVCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZSxFQUFFO0FBQUEsTUFDakIsd0JBQXdCO0FBQUEsSUFDMUIsQ0FBQztBQUNELFVBQU0sS0FBSyx1QkFBdUI7QUFBQSxNQUNoQyxPQUFPLEVBQUU7QUFBQSxNQUNULE1BQU0sRUFBRTtBQUFBLE1BQ1IsZ0JBQWdCLEVBQUU7QUFBQSxNQUNsQixtQkFBbUIsU0FBUztBQUFBLE1BQzVCLDBCQUEwQjtBQUFBLElBQzVCLENBQUM7QUFDRCxRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sS0FBSyw4Q0FBOEM7QUFBQSxRQUN2RCxZQUFZLFNBQVM7QUFBQSxRQUNyQixnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLEtBQUssd0NBQXdDLEVBQUU7QUFBQSxNQUNqRCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFNLGVBQWUsY0FBYyxJQUFJLFdBQVc7QUFDeEQsVUFBTSxTQUNKLFFBQVEsU0FDSixlQUNBLFFBQVEsZUFDTixpQkFDQSxRQUFRLFlBQ04sa0JBQ0E7QUFDVixVQUFNLGNBQWM7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU8sY0FBYyxHQUFHLEVBQUU7QUFBQSxNQUMxQixlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxJQUMxQixDQUFDO0FBQ0QsVUFBTSxLQUFLLDJCQUEyQixFQUFFLFVBQVUsS0FBSyxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFBQSxFQUNoRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsb0JBQW9CLE9BQStCO0FBQ2hFLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsS0FBSztBQUNqQixVQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxPQUFPLE1BQU0sT0FBTyxhQUFhLHNCQUFzQjtBQUM3RCxRQUFJLENBQUMsTUFBTTtBQUNULFVBQUksTUFBTyxPQUFNLEtBQUssaURBQWlEO0FBQ3ZFLFlBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFTLGtCQUFrQixJQUFJO0FBQ3JDLFFBQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsWUFBTSxLQUFLLDhDQUE4QztBQUN6RCxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDO0FBQUEsSUFDRjtBQUNBLFVBQU0sWUFBWSxNQUFNO0FBQ3hCLFFBQUksTUFBTyxPQUFNLEtBQUssMkJBQTJCLEVBQUUsT0FBTyxPQUFPLE9BQU8sQ0FBQztBQUFBLEVBQzNFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUNoRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUlBLGVBQWUsaUJBQWdDO0FBQzdDLFFBQU0sUUFBUSxNQUFNLFdBQVc7QUFDL0IsVUFBUSxRQUFRLFlBQVksRUFBRSxNQUFNLGlCQUFpQixNQUFNLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDOUU7QUFFQSxlQUFlLGFBQXNDO0FBQ25ELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsU0FBTztBQUFBLElBQ0wsU0FBUztBQUFBLElBQ1QsVUFBVSxlQUFlLFFBQVE7QUFBQSxJQUNqQyxZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBeUM7QUFDL0QsU0FBTztBQUFBLElBQ0wsT0FBTyxFQUFFO0FBQUEsSUFDVCxNQUFNLEVBQUU7QUFBQSxJQUNSLFFBQVEsRUFBRTtBQUFBLElBQ1YsYUFBYSxFQUFFO0FBQUEsSUFDZixjQUFjLEVBQUU7QUFBQSxJQUNoQixRQUFRLEVBQUUsSUFBSSxTQUFTO0FBQUEsSUFDdkIsV0FBVyxFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSTtBQUFBLEVBQ25EO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsS0FBcUI7QUFFdkMsUUFBTSxJQUFJLElBQUksS0FBSyxHQUFHO0FBQ3RCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTyxJQUFJLFFBQVEsU0FBUyxFQUFFO0FBQzdELFFBQU0sTUFBTSxDQUFDLEdBQVcsSUFBSSxNQUFNLE9BQU8sQ0FBQyxFQUFFLFNBQVMsR0FBRyxHQUFHO0FBQzNELFNBQ0UsR0FBRyxFQUFFLGVBQWUsQ0FBQyxJQUFJLElBQUksRUFBRSxZQUFZLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQ3BFLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQztBQUU5RTtBQUVBLFNBQVMsVUFBVSxHQUFxQjtBQUN0QyxTQUFPLFdBQVcsRUFBRSxLQUFLLGNBQWMsRUFBRSxJQUFJO0FBQy9DO0FBUUEsU0FBUyxjQUFjLE1BQWUsVUFBNEI7QUFDaEUsUUFBTSxNQUFnQixDQUFDO0FBQ3ZCLFdBQVMsS0FBSyxHQUFZLE9BQWUsUUFBc0I7QUFDN0QsUUFBSSxRQUFRLFlBQVksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQzdELFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixVQUFJLEtBQUssR0FBRyxNQUFNLFFBQVEsRUFBRSxNQUFNLEdBQUc7QUFDckMsVUFBSSxFQUFFLFNBQVMsRUFBRyxNQUFLLEVBQUUsQ0FBQyxHQUFHLFFBQVEsR0FBRyxHQUFHLE1BQU0sS0FBSztBQUN0RDtBQUFBLElBQ0Y7QUFDQSxlQUFXLEtBQUssT0FBTyxLQUFLLENBQTRCLEdBQUc7QUFDekQsWUFBTSxPQUFPLFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQyxLQUFLO0FBQ3pDLFVBQUksS0FBSyxJQUFJO0FBQ2IsV0FBTSxFQUE4QixDQUFDLEdBQUcsUUFBUSxHQUFHLElBQUk7QUFBQSxJQUN6RDtBQUFBLEVBQ0Y7QUFDQSxPQUFLLE1BQU0sR0FBRyxFQUFFO0FBQ2hCLFNBQU87QUFDVDtBQUdBLFNBQVMsZUFBZSxNQUF5QjtBQUMvQyxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1DLE9BQU07QUFDWixVQUFJLE9BQU9BLEtBQUksZUFBZSxTQUFVLE1BQUssSUFBSUEsS0FBSSxVQUFVO0FBQy9ELGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsS0FBSztBQUN4QjtBQUdBLFNBQVMsZUFBZSxNQUF3QjtBQUM5QyxTQUNFLE9BQU8sU0FBUyxZQUNoQixTQUFTLFFBQ1QsTUFBTSxRQUFTLEtBQWlDLE1BQU0sS0FDckQsS0FBK0IsT0FBTyxTQUFTO0FBRXBEO0FBRUEsU0FBUyxXQUFXLEdBQW1CO0FBR3JDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFDeEIsVUFBTSxPQUFPLE9BQU8sWUFBWSxPQUFPLFNBQVMsWUFBTztBQUN2RCxXQUFPLE9BQU8sU0FBUyxXQUFXLE9BQU8sU0FBUyxnQkFDOUMsT0FDQSxHQUFHLE9BQU8sSUFBSSxHQUFHLElBQUk7QUFBQSxFQUMzQixRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQ7QUFDRjtBQUtDLFdBQXVDLGVBQWU7QUFBQSxFQUNyRDtBQUFBLEVBQ0EsVUFBVTtBQUFBLEVBQ1YsVUFBVTtBQUFBLEVBQ1YsU0FBUztBQUFBLEVBQ1QsVUFBVSxNQUFNLFNBQVMsVUFBVTtBQUFBLEVBQ25DLE9BQU87QUFDVDsiLAogICJuYW1lcyI6IFsib2JqIiwgImluZm8iLCAib2JqIl0KfQo=
