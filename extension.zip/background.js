// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function setArchiveSnapshot(snapshot) {
  await setRaw("archiveSnapshot", snapshot);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
var RECENT_TWEET_SIGHTINGS_MAX = 80;
async function getRecentTweetSightings() {
  return getRaw("recentTweetSightings");
}
async function prependRecentTweetSightings(rows) {
  if (rows.length === 0) return;
  const cur = await getRecentTweetSightings();
  const seen = /* @__PURE__ */ new Set();
  const next = [];
  for (const row of rows) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  for (const row of cur) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  next.length = Math.min(next.length, RECENT_TWEET_SIGHTINGS_MAX);
  await setRaw("recentTweetSightings", next);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Verify the PAT can write to the configured branch without creating a
   * commit. Moving a ref to its current SHA is a no-op, but GitHub still
   * enforces the Contents: Write permission required by commitFiles().
   */
  async verifyWriteAccess() {
    const head = await this.getBranchHead();
    await this.fetchJson(
      "PATCH",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
      {
        sha: head.sha,
        force: false
      }
    );
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const unavailableTweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const unavailable = pickUnavailableTweet(raw, ctx);
      if (unavailable) {
        unavailableTweets.push(unavailable);
        observed.push(unavailable.tweet_id);
        built.add(unavailable.tweet_id);
        continue;
      }
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, unavailable_tweets: unavailableTweets, partial_ids };
}
function pickUnavailableTweet(node, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename !== "TweetTombstone") return null;
  const tweetId = strOrNull(n.rest_id) ?? pickTweetIdFromUrls(node) ?? (ctx.sourceUrl ? tweetIdFromTweetUrl(ctx.sourceUrl) : null);
  if (!tweetId || !TWEET_ID_RE.test(tweetId)) return null;
  const unavailableText = pickTombstoneText(node);
  return {
    tweet_id: tweetId,
    account_handle: pickHandleFromTweetUrls(node, tweetId) ?? (ctx.sourceUrl ? handleFromTweetUrl(ctx.sourceUrl, tweetId) : null),
    unavailable_detected_at: ctx.capturedAt,
    unavailable_reason: classifyUnavailableReason(unavailableText),
    unavailable_text: unavailableText,
    unavailable_source_url: ctx.sourceUrl ?? null
  };
}
function pickTweetIdFromUrls(node) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const id = tweetIdFromTweetUrl(cur);
      if (id) return id;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function tweetIdFromTweetUrl(rawUrl) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/[A-Za-z0-9_]{1,15}\/status\/(\d{15,20})(?:\/|$)/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
function pickTombstoneText(node) {
  const strings = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const trimmed = cur.trim();
      if (trimmed.length >= 4 && !trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
        strings.push(trimmed);
      }
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  const preferred = strings.find(
    (s) => /\b(copyright|dmca|unavailable|withheld|removed|deleted|violat|suspended)\b/i.test(s)
  );
  return preferred ?? strings[0] ?? null;
}
function classifyUnavailableReason(text) {
  if (!text) return null;
  if (/\b(copyright|dmca)\b/i.test(text)) return "copyright";
  if (/\bwithheld\b/i.test(text)) return "withheld";
  if (/\bdeleted|removed\b/i.test(text)) return "removed";
  if (/\bsuspended\b/i.test(text)) return "suspended";
  if (/\bunavailable|not available\b/i.test(text)) return "unavailable";
  return null;
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  const hintHandle = pickHintHandle(node, restId);
  if (!hintHandle) return null;
  return { tweet_id: restId, hint_handle: hintHandle };
}
function pickHintHandle(node, tweetId) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name) ?? pickHandleFromTweetUrls(node, tweetId);
}
function pickHandleFromTweetUrls(node, tweetId) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const handle = handleFromTweetUrl(cur, tweetId);
      if (handle) return handle;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function handleFromTweetUrl(rawUrl, tweetId) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d{15,20})(?:\/|$)/);
    if (!match || match[2] !== tweetId) return null;
    return match[1] ?? null;
  } catch {
    return null;
  }
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    unavailable_detected_at: null,
    unavailable_reason: null,
    unavailable_text: null,
    unavailable_source_url: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted, coreHandles = /* @__PURE__ */ new Set()) {
  if (targeted.size === 0 && coreHandles.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (coreHandles.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
var MANUAL_CAPTURE_WINDOW_MS = 9e4;
var manualCaptureUntilMs = 0;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
function allowManualCaptureWindow() {
  manualCaptureUntilMs = Date.now() + MANUAL_CAPTURE_WINDOW_MS;
}
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  allowManualCaptureWindow();
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    ingestedNewCount: 0,
    ingestedExistingCount: 0,
    skippedOldCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let expandedCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        // Cast: the @types/firefox-webext-browser type signature insists
        // `func` returns void, but the API actually surfaces the return
        // value via `result[0].result`. We use that for the expand count.
        func: () => {
          const SHOW_MORE_SELECTORS = [
            '[data-testid="tweet-text-show-more-link"]',
            'button[data-testid="tweet-text-show-more-link"]',
            'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
          ];
          const clicked = /* @__PURE__ */ new Set();
          let expanded = 0;
          for (const sel of SHOW_MORE_SELECTORS) {
            for (const el of Array.from(document.querySelectorAll(sel))) {
              if (clicked.has(el)) continue;
              const t = (el.textContent || "").trim().toLowerCase();
              if (t !== "show more" && t !== "show this thread") continue;
              const rect = el.getBoundingClientRect();
              if (rect.width === 0 || rect.height === 0) continue;
              clicked.add(el);
              try {
                el.click();
                expanded += 1;
              } catch {
              }
            }
          }
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { expanded };
        }
      });
      scrollCount += 1;
      const r = results[0]?.result;
      if (r && typeof r.expanded === "number") expandedCount += r.expanded;
    } catch {
    }
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      sess.expandedCount += expandedCount;
      await setAutoScrollSession(sess);
    }
  }
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.pageUrl ?? null, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-update-existing":
      await updateSettings({ updateExisting: msg.on });
      await info("update-existing toggled", { on: msg.on });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, pageUrl, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const settings = await getSettings();
  if (settings.enabled === false) return;
  if (settings.autoCapture === false) {
    const explicitCaptureActive = Date.now() < manualCaptureUntilMs || await getAutoScrollSession() !== null || await getRefetchSession() !== null || await getMediaCrawlSession() !== null;
    if (!explicitCaptureActive) return;
  }
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const core = new Set(
    accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase())
  );
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set(),
      sourceUrl: pageUrl
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked, core);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.unavailable_tweets.length > 0) {
    await recordUnavailableTweets(
      normalized.unavailable_tweets,
      tracked,
      capturedAt,
      url,
      endpoint
    );
  }
  if (normalized.tweets.length === 0) return;
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const updateExisting = settings.updateExisting !== false;
  const committedIdx = await getCommittedIndex();
  const archiveSnapshot = await getArchiveSnapshot();
  let dedupedSkipped = 0;
  let skippedNoUpdateLocal = 0;
  let skippedNoUpdateSnapshot = 0;
  let oldFromSnapshot = 0;
  const liveTweets = [];
  const freshnessById = /* @__PURE__ */ new Map();
  const actionById = /* @__PURE__ */ new Map();
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const oldBySnapshot = !prev && archiveSnapshotHasTweet(t, archiveSnapshot);
    const previouslyArchived = Boolean(prev) || oldBySnapshot;
    freshnessById.set(t.tweet_id, previouslyArchived ? "existing" : "new");
    if (oldBySnapshot) oldFromSnapshot += 1;
    if (previouslyArchived && !updateExisting) {
      if (prev) skippedNoUpdateLocal += 1;
      else skippedNoUpdateSnapshot += 1;
      actionById.set(t.tweet_id, "skipped");
      continue;
    }
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      actionById.set(t.tweet_id, "unchanged");
      continue;
    }
    actionById.set(t.tweet_id, "buffered");
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (skippedNoUpdateLocal + skippedNoUpdateSnapshot > 0) {
    const skippedOld = skippedNoUpdateLocal + skippedNoUpdateSnapshot;
    await info("dedup: skipped previously archived tweets (updateExisting=false)", {
      endpoint,
      skipped: skippedOld,
      local_index: skippedNoUpdateLocal,
      archive_snapshot: skippedNoUpdateSnapshot,
      remaining: liveTweets.length
    });
    const asSess = await getAutoScrollSession();
    if (asSess !== null) {
      asSess.skippedOldCount = (asSess.skippedOldCount ?? 0) + skippedOld;
      await setAutoScrollSession(asSess);
    }
  }
  if (oldFromSnapshot > 0 && updateExisting) {
    await info("archive snapshot recognized old tweets", {
      endpoint,
      old: oldFromSnapshot,
      action: "buffering because updateExisting=true",
      snapshot_generated_at: archiveSnapshot?.generated_at ?? null
    });
  }
  await prependRecentTweetSightings(
    normalized.tweets.map(
      (t) => buildTweetSighting(t, endpoint, capturedAt, freshnessById.get(t.tweet_id), actionById.get(t.tweet_id))
    )
  );
  await enqueueMissingParents(normalized.tweets, endpoint);
  if (liveTweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    let addedNew = 0;
    let addedExisting = 0;
    let updatedBuffered = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
        updatedBuffered += 1;
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
        if (freshnessById.get(t.tweet_id) === "existing") addedExisting += 1;
        else addedNew += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(
      handle,
      Object.keys(buf.tweets_by_id).length + Object.keys(buf.unavailable_by_id ?? {}).length
    );
    if (added > 0 || updatedBuffered > 0) {
      await info("buffered tweets", {
        handle,
        endpoint,
        added,
        new: addedNew,
        existing: addedExisting,
        updated_buffered: updatedBuffered,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        asSess.ingestedNewCount = (asSess.ingestedNewCount ?? 0) + addedNew;
        asSess.ingestedExistingCount = (asSess.ingestedExistingCount ?? 0) + addedExisting;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function recordUnavailableTweets(unavailableTweets, tracked, capturedAt, sourceUrl, endpoint) {
  const committedIdx = await getCommittedIndex();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  let recorded = 0;
  let skipped = 0;
  let missingHandle = 0;
  for (const u of unavailableTweets) {
    const handle = u.account_handle;
    if (!handle) {
      missingHandle += 1;
      await dequeueMediaCrawl(u.tweet_id);
      continue;
    }
    if (tracked.size > 0 && !tracked.has(handle.toLowerCase())) {
      skipped += 1;
      continue;
    }
    await dequeueMediaCrawl(u.tweet_id);
    await dequeueRefetch(handle, u.tweet_id);
    if (refetchSess?.inflight?.tweetId === u.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === u.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    const sig = unavailableSig(u);
    const prev = committedIdx[handle]?.[u.tweet_id];
    if (prev?.sig === sig) {
      skipped += 1;
      continue;
    }
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const unavailableById = buf.unavailable_by_id ?? {};
    unavailableById[u.tweet_id] = u;
    buf.unavailable_by_id = unavailableById;
    if (!buf.tweet_ids_observed.includes(u.tweet_id)) {
      buf.tweet_ids_observed.push(u.tweet_id);
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(
      handle,
      Object.keys(buf.tweets_by_id).length + Object.keys(unavailableById).length
    );
    recorded += 1;
  }
  if (recorded > 0 || missingHandle > 0 || skipped > 0) {
    await info("unavailable tweets observed", { endpoint, recorded, skipped, missingHandle });
  }
  await broadcastState();
}
function unavailableSig(u) {
  return `unavailable|${u.unavailable_reason ?? ""}|${u.unavailable_text ?? ""}`;
}
async function enqueueMissingParents(tweets, endpoint) {
  if (tweets.length === 0) return;
  const sameBatchIds = /* @__PURE__ */ new Set();
  for (const t of tweets) sameBatchIds.add(t.tweet_id);
  let enqueued = 0;
  for (const t of tweets) {
    const parents = [];
    if (t.reply_to_tweet_id) {
      parents.push({ id: t.reply_to_tweet_id, hint: t.reply_to_account });
    }
    if (t.quoted_tweet_id) parents.push({ id: t.quoted_tweet_id, hint: null });
    if (t.retweeted_tweet_id) parents.push({ id: t.retweeted_tweet_id, hint: null });
    for (const p of parents) {
      if (sameBatchIds.has(p.id)) continue;
      if (await isCommitted(p.id)) continue;
      await enqueueMediaCrawl(p.hint, p.id);
      enqueued += 1;
    }
  }
  if (enqueued > 0) {
    await info("queued missing parent tweets for detail-page crawl", {
      endpoint,
      enqueued,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    unavailable_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    const unavailableTweets = Object.values(buf.unavailable_by_id ?? {});
    if (tweets.length === 0 && unavailableTweets.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets, unavailableTweets));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length + item.unavailableTweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length + item.unavailableTweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      for (const u of item.unavailableTweets) {
        inner[u.tweet_id] = {
          ts: nowIso,
          sig: unavailableSig(u)
        };
      }
      idx[item.handle] = inner;
      await info("flush committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        unavailable: item.unavailableTweets.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("flush batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      unavailable: items.reduce((total, item) => total + item.unavailableTweets.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets, unavailableTweets) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    unavailableTweets,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets,
      unavailable_tweets: unavailableTweets
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    const unavailableCount2 = item.unavailableTweets.length;
    const suffix2 = unavailableCount2 > 0 ? `, ${unavailableCount2} unavailable` : "";
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"}${suffix2} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  const unavailableCount = items.reduce((total, item) => total + item.unavailableTweets.length, 0);
  const suffix = unavailableCount > 0 ? `, ${unavailableCount} unavailable` : "";
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"}${suffix} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return Object.keys(current.tweets_by_id).length;
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  for (const u of item.unavailableTweets) {
    committed.set(u.tweet_id, unavailableSig(u));
  }
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingUnavailable = {};
  for (const [tweetId, unavailable] of Object.entries(current.unavailable_by_id ?? {})) {
    const committedSig = committed.get(tweetId);
    const currentSig = unavailableSig(unavailable);
    if (!committedSig || committedSig !== currentSig) {
      remainingUnavailable[tweetId] = { ...unavailable };
    }
  }
  const remainingIds = /* @__PURE__ */ new Set([
    ...Object.keys(remainingTweets),
    ...Object.keys(remainingUnavailable)
  ]);
  const remainingCount = remainingIds.size;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    unavailable_by_id: remainingUnavailable,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => remainingIds.has(id))
  });
  await info("flush kept newer buffered tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  allowManualCaptureWindow();
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      unavailable_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  allowManualCaptureWindow();
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  allowManualCaptureWindow();
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  allowManualCaptureWindow();
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = target.bucket === "_unknown" ? `https://x.com/i/web/status/${target.tweetId}` : `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    const checkWrite = force || isWriteAuthError(conn.error);
    if (branchOk && checkWrite) {
      await client.verifyWriteAccess();
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk,
      write_access: checkWrite ? "checked" : "not_checked"
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await refreshArchiveSnapshot(client, force);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function refreshArchiveSnapshot(client, force) {
  const text = await client.fetchRawText("data/manifest.json");
  if (!text) {
    await setArchiveSnapshot(null);
    if (force) await warn("archive manifest not found; old-tweet detection disabled");
    return;
  }
  try {
    const snapshot = parseArchiveSnapshot(JSON.parse(text));
    await setArchiveSnapshot(snapshot);
    if (force) {
      await info("archive snapshot refreshed", {
        accounts: Object.keys(snapshot.accounts).length,
        generated_at: snapshot.generated_at
      });
    }
  } catch (err) {
    await warn("archive snapshot parse failed; old-tweet detection disabled", describeError(err));
  }
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const autoScrollSess = await getAutoScrollSession();
  const recentTweetSightings = await getRecentTweetSightings();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      ingestedNewCount: autoScrollSess?.ingestedNewCount ?? 0,
      ingestedExistingCount: autoScrollSess?.ingestedExistingCount ?? 0,
      skippedOldCount: autoScrollSess?.skippedOldCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    },
    recentTweetSightings
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    updateExisting: s.updateExisting,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function parseArchiveSnapshot(raw) {
  if (!raw || typeof raw !== "object") throw new Error("manifest is not an object");
  const manifest = raw;
  if (!Array.isArray(manifest.accounts)) throw new Error("manifest.accounts is not an array");
  const accounts = {};
  for (const entry of manifest.accounts) {
    if (!entry || typeof entry !== "object") continue;
    const row = entry;
    const handle = typeof row.handle === "string" ? row.handle : "";
    if (!handle || handle === "_misc") continue;
    accounts[handle.toLowerCase()] = {
      handle,
      latest_post_at: typeof row.latest_post_at === "string" ? row.latest_post_at : null,
      latest_capture_at: typeof row.latest_capture_at === "string" ? row.latest_capture_at : null,
      row_count: typeof row.row_count === "number" ? row.row_count : null
    };
  }
  return {
    generated_at: typeof manifest.generated_at === "string" ? manifest.generated_at : null,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    accounts
  };
}
function archiveSnapshotHasTweet(t, snapshot) {
  if (!snapshot) return false;
  const entry = snapshot.accounts[t.account_handle.toLowerCase()];
  if (!entry?.latest_post_at) return false;
  const posted = Date.parse(t.posted_at);
  const latest = Date.parse(entry.latest_post_at);
  return Number.isFinite(posted) && Number.isFinite(latest) && posted <= latest;
}
function buildTweetSighting(t, endpoint, seenAt, freshness = "new", action = "buffered") {
  return {
    tweet_id: t.tweet_id,
    account_handle: t.account_handle,
    posted_at: t.posted_at,
    text: t.text_resolved || t.text,
    tweet_type: t.tweet_type,
    tweet_url: t.tweet_url,
    seen_at: seenAt,
    endpoint,
    archive_status: freshness === "existing" ? "saved" : "new",
    action
  };
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xyXG4gIHBhdDogJycsXHJcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcclxuICByZXBvOiAneCcsXHJcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxyXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXHJcbiAgYnJhbmNoOiAnbWFzdGVyJyxcclxuICBlbmFibGVkOiB0cnVlLFxyXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxyXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcclxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXHJcbiAgdXBkYXRlRXhpc3Rpbmc6IHRydWUsXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XHJcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XHJcblxyXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxyXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXHJcbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xyXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuXTtcclxuXHJcbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXHJcbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG4gICdMaWtlcycsXHJcbiAgJ0Jvb2ttYXJrcycsXHJcbiAgJ0hvbWVUaW1lbGluZScsXHJcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXHJcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcclxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcclxuXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XHJcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXHJcbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXHJcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxyXG5dKTtcclxuXHJcbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxyXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxyXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3JcclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxyXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcclxuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXHJcbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXHJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcclxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxyXG4vL1xyXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcclxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXHJcbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cclxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG5dKTtcclxuXHJcbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxyXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xyXG5cclxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcclxuXHJcbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XHJcblxyXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXHJcbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcclxuXHJcbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cclxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XHJcblxyXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcclxuIiwgIi8qKlxyXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cclxuICpcclxuICogVGhyZWF0IG1vZGVsOiBhbiBhdHRhY2tlciB3aG8gcmVhZHMgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgKGRldnRvb2xzLCBhXHJcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXHJcbiAqIEdpdEh1YiBQQVQgaW4gcGxhaW50ZXh0LiBBIGRldGVybWluZWQgYXR0YWNrZXIgd2l0aCB0aGUgZXh0ZW5zaW9uJ3Mgc291cmNlXHJcbiAqIGNhbiBzdGlsbCBkZXJpdmUgdGhlIGtleSBcdTIwMTQgd2UgbWFrZSBubyBjbGFpbSBvZiBcInJlYWxcIiBjcnlwdG9ncmFwaGljXHJcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxyXG4gKiBzdHJpbmcgc2l0dGluZyBuZXh0IHRvIGl0cyBrZXkgbmFtZSBpbiBleHRlbnNpb24gc3RvcmFnZS5cclxuICpcclxuICogU2NoZW1lOlxyXG4gKiAgIC0gT24gZmlyc3QgZW5jcnlwdGlvbiB3ZSBnZW5lcmF0ZSBhIDMyLWJ5dGUgc2FsdCBhbmQgcGVyc2lzdCBpdCBpblxyXG4gKiAgICAgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgdW5kZXIgYF9faW1tX2FyY2hpdmVfc2FsdF9fYC5cclxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cclxuICogICAgIHx8IFwiaW1tLWFyY2hpdmUtcGF0LXYxXCJgLiBUaGUgc2FsdCBiZWluZyBwZXItaW5zdGFsbCBtZWFucyB0d28gY29waWVzXHJcbiAqICAgICBvZiB0aGUgZXh0ZW5zaW9uIGRvbid0IHNoYXJlIGEga2V5LiBUaGUgcnVudGltZS5pZCBpcyB0aGUgZXh0ZW5zaW9uJ3NcclxuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxyXG4gKiAgIC0gUGxhaW50ZXh0IGlzIGVuY3J5cHRlZCB3aXRoIGEgZnJlc2ggMTItYnl0ZSBJVi4gVGhlIGVudmVsb3BlIGZvcm1hdCBpc1xyXG4gKiAgICAgYHYxOjxpdi1iNjQ+OjxjaXBoZXJ0ZXh0LWI2ND5gIGFuZCBpcyB3aGF0IGdldHMgc3RvcmVkLlxyXG4gKlxyXG4gKiBCYWNrd2FyZHMgY29tcGF0aWJpbGl0eTogYW4gdW5wcmVmaXhlZCB2YWx1ZSBpcyB0cmVhdGVkIGFzIGxlZ2FjeVxyXG4gKiBwbGFpbnRleHQsIGRlY3J5cHRlZCB0byBpdHNlbGYsIGFuZCByZS1lbmNyeXB0ZWQgb24gdGhlIG5leHQgd3JpdGUuXHJcbiAqL1xyXG5cclxuY29uc3QgU0FMVF9TVE9SQUdFX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3NhbHRfXyc7XHJcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xyXG5cclxubGV0IGRlcml2ZWRLZXlDYWNoZTogQ3J5cHRvS2V5IHwgbnVsbCA9IG51bGw7XHJcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHRvQmFzZTY0KGJ1ZjogVWludDhBcnJheSk6IHN0cmluZyB7XHJcbiAgbGV0IHMgPSAnJztcclxuICBmb3IgKGNvbnN0IGIgb2YgYnVmKSBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYik7XHJcbiAgcmV0dXJuIGJ0b2Eocyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZyb21CYXNlNjQoczogc3RyaW5nKTogVWludDhBcnJheSB7XHJcbiAgY29uc3QgYmluID0gYXRvYihzKTtcclxuICBjb25zdCBvdXQgPSBuZXcgVWludDhBcnJheShiaW4ubGVuZ3RoKTtcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IGJpbi5sZW5ndGg7IGkrKykgb3V0W2ldID0gYmluLmNoYXJDb2RlQXQoaSk7XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcclxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFNBTFRfU1RPUkFHRV9LRVkpO1xyXG4gIGNvbnN0IHYgPSBzdG9yZWRbU0FMVF9TVE9SQUdFX0tFWV07XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcclxuICAgIHJldHVybiB7IHNhbHRCNjQ6IHYsIHNhbHQ6IGZyb21CYXNlNjQodikgfTtcclxuICB9XHJcbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcclxuICBjb25zdCBzYWx0QjY0ID0gdG9CYXNlNjQoc2FsdCk7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtTQUxUX1NUT1JBR0VfS0VZXTogc2FsdEI2NCB9KTtcclxuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xyXG4gIGNvbnN0IHsgc2FsdEI2NCwgc2FsdCB9ID0gYXdhaXQgbG9hZE9yQ3JlYXRlU2FsdCgpO1xyXG4gIGlmIChkZXJpdmVkS2V5Q2FjaGUgIT09IG51bGwgJiYgZGVyaXZlZEtleUNhY2hlU2FsdCA9PT0gc2FsdEI2NCkge1xyXG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcclxuICB9XHJcbiAgY29uc3Qgc2VlZCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcclxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXHJcbiAgKTtcclxuICBjb25zdCBjb21iaW5lZCA9IG5ldyBVaW50OEFycmF5KHNlZWQubGVuZ3RoICsgc2FsdC5sZW5ndGgpO1xyXG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcclxuICBjb21iaW5lZC5zZXQoc2FsdCwgc2VlZC5sZW5ndGgpO1xyXG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGNvbWJpbmVkKTtcclxuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcclxuICAgICdlbmNyeXB0JyxcclxuICAgICdkZWNyeXB0JyxcclxuICBdKTtcclxuICBkZXJpdmVkS2V5Q2FjaGUgPSBrZXk7XHJcbiAgZGVyaXZlZEtleUNhY2hlU2FsdCA9IHNhbHRCNjQ7XHJcbiAgcmV0dXJuIGtleTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gIHJldHVybiB2LnN0YXJ0c1dpdGgoRU5WRUxPUEVfUFJFRklYKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVuY3J5cHRQYXQocGxhaW50ZXh0OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIGlmICghcGxhaW50ZXh0KSByZXR1cm4gJyc7XHJcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XHJcbiAgY29uc3QgaXYgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEyKSk7XHJcbiAgY29uc3QgY3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmVuY3J5cHQoXHJcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcclxuICAgIGtleSxcclxuICAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShwbGFpbnRleHQpXHJcbiAgKTtcclxuICByZXR1cm4gYCR7RU5WRUxPUEVfUFJFRklYfSR7dG9CYXNlNjQoaXYpfToke3RvQmFzZTY0KG5ldyBVaW50OEFycmF5KGN0KSl9YDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlY3J5cHRQYXQoZW52ZWxvcGU6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgaWYgKCFlbnZlbG9wZSkgcmV0dXJuICcnO1xyXG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXHJcbiAgLy8gcmUtZW5jcnlwdHMgaXQgdmlhIHRoZSBzdG9yYWdlIGxheWVyLlxyXG4gIGlmICghZW52ZWxvcGUuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpKSByZXR1cm4gZW52ZWxvcGU7XHJcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xyXG4gIGlmIChwYXJ0cy5sZW5ndGggIT09IDIpIHJldHVybiAnJztcclxuICBjb25zdCBbaXZCNjQsIGN0QjY0XSA9IHBhcnRzO1xyXG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGtleSA9IGF3YWl0IGRlcml2ZUtleSgpO1xyXG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcclxuICAgIGNvbnN0IGN0ID0gZnJvbUJhc2U2NChjdEI2NCk7XHJcbiAgICBjb25zdCBwdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGVjcnlwdChcclxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcclxuICAgICAga2V5LFxyXG4gICAgICBjdCBhcyBCdWZmZXJTb3VyY2VcclxuICAgICk7XHJcbiAgICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKHB0KTtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiAnJztcclxuICB9XHJcbn1cclxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcclxuaW1wb3J0IHsgZGVjcnlwdFBhdCwgZW5jcnlwdFBhdCwgaXNFbmNyeXB0ZWRQYXQgfSBmcm9tICcuL2NyeXB0by5qcyc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBBY2NvdW50Q29uZmlnLFxyXG4gIEFjY291bnRDb3VudGVyLFxyXG4gIEFyY2hpdmVTbmFwc2hvdCxcclxuICBDYW5vbmljYWxUd2VldCxcclxuICBDb25uZWN0aW9uU3RhdGUsXHJcbiAgTG9nRXZlbnQsXHJcbiAgU2V0dGluZ3MsXHJcbiAgVHdlZXRTaWdodGluZyxcclxuICBVbmF2YWlsYWJsZVR3ZWV0LFxyXG59IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuLyoqXHJcbiAqIEJ1ZmZlcmVkIHR3ZWV0cyBmb3IgYSBnaXZlbiBhY2NvdW50LCBhd2FpdGluZyBjb21taXQuIEEgXCJydW5cIiBpcyBvbmUgZW50cnlcclxuICogaW4gdGhpcyBtYXA7IGZsdXNoaW5nIGNsZWFycyB0aGUgZW50cnkuIFdlIHN0b3JlIGFzIFJlY29yZCBzbyB0aGUgc3RydWN0dXJlXHJcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgUnVuQnVmZmVyIHtcclxuICBydW5faWQ6IHN0cmluZztcclxuICBhY2NvdW50X2hhbmRsZTogc3RyaW5nO1xyXG4gIHN0YXJ0ZWRfYXQ6IHN0cmluZztcclxuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcclxuICB0d2VldHNfYnlfaWQ6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PjtcclxuICB1bmF2YWlsYWJsZV9ieV9pZD86IFJlY29yZDxzdHJpbmcsIFVuYXZhaWxhYmxlVHdlZXQ+O1xyXG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XHJcbiAgZW5kcG9pbnRzX3NlZW46IHN0cmluZ1tdO1xyXG4gIHNvdXJjZV91cmw6IHN0cmluZyB8IG51bGw7XHJcbn1cclxuXHJcbi8qKiBQZXItdHdlZXQgY29tbWl0dGVkLXN0YXRlIGluZGV4LCBrZXllZCBieSBoYW5kbGUgdGhlbiB0d2VldF9pZC5cclxuICogVXNlZCB0byBza2lwIHJlLWNhcHR1cmluZyB0d2VldHMgd2UndmUgYWxyZWFkeSBwdXNoZWQgd2l0aCBpZGVudGljYWxcclxuICogZW5nYWdlbWVudCBjb3VudHMgXHUyMDE0IGF2b2lkcyBnZW5lcmF0aW5nIG9uZSBuZXcgcmF3LyogZmlsZSBldmVyeSBicm93c2UuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0dGVkRW50cnkge1xyXG4gIHRzOiBzdHJpbmc7IC8vIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3QgY29tbWl0XHJcbiAgc2lnOiBzdHJpbmc7IC8vIGVuZ2FnZW1lbnQgc2lnbmF0dXJlOiBcImxpa2V8cnR8cmVwbHl8cXVvdGVcIlxyXG59XHJcblxyXG4vKiogUHJvZ3Jlc3MgKyBpbmZsaWdodCB0cmFja2luZyBmb3IgYSBxdWV1ZS1kcml2ZW4gbG9vcCAocmVmZXRjaCAvIG1lZGlhLWNyYXdsKS5cclxuICogVGhlIGxvb3AgcGVyc2lzdHMgdGhpcyBzbyBhIFNXIGV2aWN0aW9uIGluIHRoZSBtaWRkbGUgb2YgYSBydW4gcHJlc2VydmVzXHJcbiAqIFwiWCBvZiBZIHByb2Nlc3NlZFwiIFx1MjAxNCBhbmQgdGhlIHdhaXQtZm9yLWluZ2VzdCBndWFyZCBrbm93cyB3aGF0IHRvIGV4cGVjdC5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgTG9vcFNlc3Npb24ge1xyXG4gIC8qKiBJbml0aWFsIHF1ZXVlIHNpemUgd2hlbiB0aGUgdXNlciBjbGlja2VkIFwiU3RhcnRcIi4gKi9cclxuICB0b3RhbEF0U3RhcnQ6IG51bWJlcjtcclxuICAvKiogVHdlZXRzIHByb2Nlc3NlZCAoaW5nZXN0ZWQgT1IgZHJvcHBlZCBhZnRlciByZXRyaWVzKSBzbyBmYXIuICovXHJcbiAgcHJvY2Vzc2VkOiBudW1iZXI7XHJcbiAgLyoqIElTTyBvZiB3aGVuIHRoaXMgc2Vzc2lvbiBzdGFydGVkLiAqL1xyXG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xyXG4gIC8qKiBUd2VldCBjdXJyZW50bHkgaW5mbGlnaHQgXHUyMDE0IHdlIG5hdmlnYXRlZCB0byBpdCBhbmQgYXJlIHdhaXRpbmcgZm9yIHRoZVxyXG4gICAqIHBhZ2UtaG9vayB0byBjYXB0dXJlIHRoZSByZXNwb25zZSBiZWZvcmUgYWR2YW5jaW5nLiBudWxsIGJldHdlZW4gdGlja3NcclxuICAgKiAoYW5kIG9uY2UgYW4gaW5nZXN0IGhhcyBiZWVuIG9ic2VydmVkKS4gKi9cclxuICBpbmZsaWdodDogeyB0d2VldElkOiBzdHJpbmc7IG5hdmlnYXRlZEF0OiBzdHJpbmcgfSB8IG51bGw7XHJcbn1cclxuXHJcbi8qKiBBdXRvLXNjcm9sbCBzZXNzaW9uOiBjb3VudHMgb2YgdGlja3MgYW5kIHR3ZWV0cyBpbmdlc3RlZCBzaW5jZSB0aGUgdXNlclxyXG4gKiBjbGlja2VkIFN0YXJ0LiBQZXJzaXN0ZWQgc28gU1cgZXZpY3Rpb24gZHVyaW5nIGEgcnVuIGtlZXBzIHByb2dyZXNzLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIEF1dG9TY3JvbGxTZXNzaW9uIHtcclxuICBzdGFydGVkQXQ6IHN0cmluZztcclxuICBzY3JvbGxDb3VudDogbnVtYmVyO1xyXG4gIGluZ2VzdGVkQ291bnQ6IG51bWJlcjtcclxuICBpbmdlc3RlZE5ld0NvdW50OiBudW1iZXI7XHJcbiAgaW5nZXN0ZWRFeGlzdGluZ0NvdW50OiBudW1iZXI7XHJcbiAgc2tpcHBlZE9sZENvdW50OiBudW1iZXI7XHJcbiAgZXhwYW5kZWRDb3VudDogbnVtYmVyO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgU3RvcmFnZVNoYXBlIHtcclxuICBzZXR0aW5nczogU2V0dGluZ3M7XHJcbiAgYWNjb3VudHM6IEFjY291bnRDb25maWdbXTtcclxuICAvKiogSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBzdWNjZXNzZnVsIGFjY291bnRzLnlhbWwgZmV0Y2ggZnJvbSB0aGUgcmVwby5cclxuICAgKiBVc2VkIGJ5IGByZWZyZXNoQWNjb3VudHNMaXN0YCB0byBza2lwIHJlLWZldGNoaW5nIG9uIGV2ZXJ5IFNXIHdha2UgXHUyMDE0IHRoZVxyXG4gICAqIGZpbGUgY2hhbmdlcyByYXJlbHkgYW5kIGFuIGF1dGhlbnRpY2F0ZWQgcmF3IGZldGNoIGV2ZXJ5IHdha2UgYWRkcyB1cC4gKi9cclxuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBzdHJpbmcgfCBudWxsO1xyXG4gIGFyY2hpdmVTbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbDtcclxuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uU3RhdGU7XHJcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcclxuICBydW5CdWZmZXJzOiBSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+O1xyXG4gIGFjdGl2aXR5OiBMb2dFdmVudFtdO1xyXG4gIHJlY2VudFR3ZWV0U2lnaHRpbmdzOiBUd2VldFNpZ2h0aW5nW107XHJcbiAgY29tbWl0dGVkSW5kZXg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj47XHJcbiAgLyoqIFR3ZWV0cyB0aGUgbm9ybWFsaXplciBmbGFnZ2VkIGFzIHRydW5jYXRlZCBhbmQgdGhhdCB3ZSBoYXZlbid0IHNlZW4gYVxyXG4gICAqIGZ1bGwtdGV4dCB2ZXJzaW9uIG9mIHlldC4gS2V5ZWQgYnkgaGFuZGxlIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuICovXHJcbiAgcmVmZXRjaFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XHJcbiAgLyoqIFR3ZWV0IElEcyBzZWVuIHZpYSBNZWRpYS10YWIgLyBwYXJ0aWFsIGNhcHR1cmVzIHRoYXQgY291bGRuJ3QgYmVcclxuICAgKiBub3JtYWxpemVkIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gS2V5ZWQgYnkgaGludC1oYW5kbGUgKG9yXHJcbiAgICogXCJfdW5rbm93blwiKSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiBUaGUgdXNlciBjYW4gZHJpdmUgYSBjcmF3bCB0aGF0XHJcbiAgICogb3BlbnMgZWFjaCBkZXRhaWwgcGFnZSB0byBjYXB0dXJlIHRoZSByZWFsIHRoaW5nLiAqL1xyXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xyXG4gIHJlZmV0Y2hTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XHJcbiAgbWVkaWFDcmF3bFNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcclxuICBhdXRvU2Nyb2xsU2Vzc2lvbjogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsO1xyXG59XHJcblxyXG5jb25zdCBERUZBVUxUX0NPTk5FQ1RJT046IENvbm5lY3Rpb25TdGF0ZSA9IHtcclxuICBzdGF0dXM6ICd1bmtub3duJyxcclxuICBsb2dpbjogbnVsbCxcclxuICBjaGVja2VkQXQ6IG51bGwsXHJcbiAgZXJyb3I6IG51bGwsXHJcbiAgZGVmYXVsdEJyYW5jaDogbnVsbCxcclxuICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxyXG4gIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXHJcbn07XHJcblxyXG5jb25zdCBERUZBVUxUUzogU3RvcmFnZVNoYXBlID0ge1xyXG4gIHNldHRpbmdzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MgfSxcclxuICBhY2NvdW50czogWy4uLkZBTExCQUNLX0FDQ09VTlRTXSxcclxuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBudWxsLFxyXG4gIGFyY2hpdmVTbmFwc2hvdDogbnVsbCxcclxuICBjb25uZWN0aW9uOiB7IC4uLkRFRkFVTFRfQ09OTkVDVElPTiB9LFxyXG4gIGNvdW50ZXJzOiB7fSxcclxuICBydW5CdWZmZXJzOiB7fSxcclxuICBhY3Rpdml0eTogW10sXHJcbiAgcmVjZW50VHdlZXRTaWdodGluZ3M6IFtdLFxyXG4gIGNvbW1pdHRlZEluZGV4OiB7fSxcclxuICByZWZldGNoUXVldWU6IHt9LFxyXG4gIG1lZGlhQ3Jhd2xRdWV1ZToge30sXHJcbiAgcmVmZXRjaFNlc3Npb246IG51bGwsXHJcbiAgbWVkaWFDcmF3bFNlc3Npb246IG51bGwsXHJcbiAgYXV0b1Njcm9sbFNlc3Npb246IG51bGwsXHJcbn07XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcclxuICBjb25zdCByZXN1bHQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KGtleSk7XHJcbiAgY29uc3QgdmFsdWUgPSByZXN1bHRba2V5XTtcclxuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgcmV0dXJuIHN0cnVjdHVyZWRDbG9uZShERUZBVUxUU1trZXldKTtcclxuICB9XHJcbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBba2V5XTogdmFsdWUgfSk7XHJcbn1cclxuXHJcbi8vIC0tLSBTZXR0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xyXG4gIC8vIEJhY2tmaWxsIGFueSBrZXlzIHRoZSB1c2VyJ3Mgc3RvcmVkIHNldHRpbmdzIHByZWRhdGUgXHUyMDE0IHJlYWRlcnMgY2FuIHJlbHlcclxuICAvLyBvbiBldmVyeSBTZXR0aW5ncyBmaWVsZCBiZWluZyBwcmVzZW50IHJhdGhlciB0aGFuIGA/PyBkZWZhdWx0aW5nYCBhdFxyXG4gIC8vIGV2ZXJ5IGNhbGxzaXRlLiBUaGUgUEFUIGlzIHN0b3JlZCBlbmNyeXB0ZWQtYXQtcmVzdCBhcyBvZiB2MC4yLjA7IHdlXHJcbiAgLy8gZGVjcnlwdCB0cmFuc3BhcmVudGx5IHNvIGNhbGxlcnMgY29udGludWUgdG8gc2VlIHBsYWludGV4dC5cclxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBnZXRSYXcoJ3NldHRpbmdzJyk7XHJcbiAgY29uc3QgbWVyZ2VkID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi5zdG9yZWQgfTtcclxuICBpZiAobWVyZ2VkLnBhdCAmJiBpc0VuY3J5cHRlZFBhdChtZXJnZWQucGF0KSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgbWVyZ2VkLnBhdCA9IGF3YWl0IGRlY3J5cHRQYXQobWVyZ2VkLnBhdCk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgbWVyZ2VkLnBhdCA9ICcnO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gbWVyZ2VkO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIC8vIEVuY3J5cHQgdGhlIFBBVCBiZWZvcmUgcGVyc2lzdGluZzsgbGVnYWN5IHBsYWludGV4dCBQQVRzIGdldCB1cGdyYWRlZFxyXG4gIC8vIG9uIHRoZSBuZXh0IHNhdmUuXHJcbiAgY29uc3QgdG9Xcml0ZTogU2V0dGluZ3MgPSB7IC4uLnMgfTtcclxuICBpZiAodG9Xcml0ZS5wYXQgJiYgIWlzRW5jcnlwdGVkUGF0KHRvV3JpdGUucGF0KSkge1xyXG4gICAgdG9Xcml0ZS5wYXQgPSBhd2FpdCBlbmNyeXB0UGF0KHRvV3JpdGUucGF0KTtcclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdzZXR0aW5ncycsIHRvV3JpdGUpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVTZXR0aW5ncyhwYXRjaDogUGFydGlhbDxTZXR0aW5ncz4pOiBQcm9taXNlPFNldHRpbmdzPiB7XHJcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBjb25zdCBuZXh0ID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XHJcbiAgYXdhaXQgc2V0U2V0dGluZ3MobmV4dCk7XHJcbiAgcmV0dXJuIG5leHQ7XHJcbn1cclxuXHJcbi8vIC0tLSBBY2NvdW50cyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHMoKTogUHJvbWlzZTxBY2NvdW50Q29uZmlnW10+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50cycpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50cyhhOiBBY2NvdW50Q29uZmlnW10pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzJywgYSk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzUmVmcmVzaGVkQXQoKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KGlzbzogc3RyaW5nIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcsIGlzbyk7XHJcbn1cclxuXHJcbi8vIC0tLSBBcmNoaXZlIHNuYXBzaG90IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBcmNoaXZlU25hcHNob3QoKTogUHJvbWlzZTxBcmNoaXZlU25hcHNob3QgfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYXJjaGl2ZVNuYXBzaG90Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBcmNoaXZlU25hcHNob3Qoc25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2FyY2hpdmVTbmFwc2hvdCcsIHNuYXBzaG90KTtcclxufVxyXG5cclxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb24oKTogUHJvbWlzZTxDb25uZWN0aW9uU3RhdGU+IHtcclxuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XHJcbiAgLy8gQmFja2ZpbGwgZmllbGRzIGFkZGVkIGFmdGVyIHRoZSB1c2VyJ3Mgc3RvcmFnZSB3YXMgd3JpdHRlbi5cclxuICBjb25zdCBvdXQ6IENvbm5lY3Rpb25TdGF0ZSA9IHtcclxuICAgIC4uLmMsXHJcbiAgICBkZWZhdWx0QnJhbmNoOiBjLmRlZmF1bHRCcmFuY2ggPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmRlZmF1bHRCcmFuY2gsXHJcbiAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOlxyXG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXHJcbiAgICByYXRlTGltaXRSZXNldEF0OiBjLnJhdGVMaW1pdFJlc2V0QXQgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLnJhdGVMaW1pdFJlc2V0QXQsXHJcbiAgfTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb25uZWN0aW9uKGM6IENvbm5lY3Rpb25TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xyXG59XHJcblxyXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZnVuY3Rpb24gdG9kYXlJU08oKTogc3RyaW5nIHtcclxuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnY291bnRlcnMnKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXHJcbiAgaGFuZGxlOiBzdHJpbmcsXHJcbiAgcGF0Y2g6IFBhcnRpYWw8QWNjb3VudENvdW50ZXI+XHJcbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRDb3VudGVycygpO1xyXG4gIGNvbnN0IGN1ciA9IGFsbFtoYW5kbGVdID8/IHtcclxuICAgIHRvZGF5Q291bnQ6IDAsXHJcbiAgICB0b2RheURhdGU6IHRvZGF5SVNPKCksXHJcbiAgICBsYXN0Q2FwdHVyZUF0OiBudWxsLFxyXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXHJcbiAgICBidWZmZXJlZENvdW50OiAwLFxyXG4gIH07XHJcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcclxuICAgIGN1ci50b2RheURhdGUgPSB0b2RheUlTTygpO1xyXG4gICAgY3VyLnRvZGF5Q291bnQgPSAwO1xyXG4gIH1cclxuICBjb25zdCBuZXh0OiBBY2NvdW50Q291bnRlciA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xyXG4gIGFsbFtoYW5kbGVdID0gbmV4dDtcclxuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcclxuICByZXR1cm4gbmV4dDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlOiBzdHJpbmcsIGNvdW50OiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHsgYnVmZmVyZWRDb3VudDogY291bnQgfSk7XHJcbn1cclxuXHJcbi8vIC0tLSBSdW4gYnVmZmVycyAodGhlIHBlbmRpbmcgY2FwdHVyZXMgYXdhaXRpbmcgY29tbWl0KSAtLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5CdWZmZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3J1bkJ1ZmZlcnMnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8UnVuQnVmZmVyIHwgbnVsbD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICByZXR1cm4gYWxsW2hhbmRsZV0gPz8gbnVsbDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZywgYnVmOiBSdW5CdWZmZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgYWxsW2hhbmRsZV0gPSBidWY7XHJcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyUnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcclxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xyXG59XHJcblxyXG4vLyAtLS0gQWN0aXZpdHkgdGFpbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjdGl2aXR5Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBlbmRBY3Rpdml0eShldjogTG9nRXZlbnQpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRBY3Rpdml0eSgpO1xyXG4gIGN1ci51bnNoaWZ0KGV2KTtcclxuICBpZiAoY3VyLmxlbmd0aCA+IEFDVElWSVRZX1RBSUxfTUFYKSBjdXIubGVuZ3RoID0gQUNUSVZJVFlfVEFJTF9NQVg7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIGN1cik7XHJcbiAgcmV0dXJuIGN1cjtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIFtdKTtcclxufVxyXG5cclxuLy8gLS0tIFJlY2VudCB0d2VldCBzaWdodGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5jb25zdCBSRUNFTlRfVFdFRVRfU0lHSFRJTkdTX01BWCA9IDgwO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk6IFByb21pc2U8VHdlZXRTaWdodGluZ1tdPiB7XHJcbiAgcmV0dXJuIGdldFJhdygncmVjZW50VHdlZXRTaWdodGluZ3MnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByZXBlbmRSZWNlbnRUd2VldFNpZ2h0aW5ncyhyb3dzOiBUd2VldFNpZ2h0aW5nW10pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBpZiAocm93cy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncygpO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBjb25zdCBuZXh0OiBUd2VldFNpZ2h0aW5nW10gPSBbXTtcclxuICBmb3IgKGNvbnN0IHJvdyBvZiByb3dzKSB7XHJcbiAgICBjb25zdCBrZXkgPSBgJHtyb3cuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKX06JHtyb3cudHdlZXRfaWR9YDtcclxuICAgIGlmIChzZWVuLmhhcyhrZXkpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKGtleSk7XHJcbiAgICBuZXh0LnB1c2gocm93KTtcclxuICB9XHJcbiAgZm9yIChjb25zdCByb3cgb2YgY3VyKSB7XHJcbiAgICBjb25zdCBrZXkgPSBgJHtyb3cuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKX06JHtyb3cudHdlZXRfaWR9YDtcclxuICAgIGlmIChzZWVuLmhhcyhrZXkpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKGtleSk7XHJcbiAgICBuZXh0LnB1c2gocm93KTtcclxuICB9XHJcbiAgbmV4dC5sZW5ndGggPSBNYXRoLm1pbihuZXh0Lmxlbmd0aCwgUkVDRU5UX1RXRUVUX1NJR0hUSU5HU19NQVgpO1xyXG4gIGF3YWl0IHNldFJhdygncmVjZW50VHdlZXRTaWdodGluZ3MnLCBuZXh0KTtcclxufVxyXG5cclxuLy8gLS0tIENvbW1pdHRlZC10d2VldHMgZGVkdXAgaW5kZXggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2NvbW1pdHRlZEluZGV4Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb21taXR0ZWRJbmRleChcclxuICBpZHg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj5cclxuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdjb21taXR0ZWRJbmRleCcsIGlkeCk7XHJcbn1cclxuXHJcbi8qKiBDb21wdXRlIHRoZSBlbmdhZ2VtZW50IHNpZ25hdHVyZSB3ZSB1c2UgdG8gZGVjaWRlIHdoZXRoZXIgYSByZS1jYXB0dXJlZFxyXG4gKiB0d2VldCBpcyBcIm1hdGVyaWFsbHkgZGlmZmVyZW50XCIgZnJvbSB3aGF0IHdlIGxhc3QgY29tbWl0dGVkLiBXZSBvbWl0XHJcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXHJcbiAqIGRlZmVhdCB0aGUgZGVkdXAuIExpa2VzIC8gUlRzIC8gcmVwbGllcyAvIHF1b3RlcyBjaGFuZ2UgcmFyZWx5IGVub3VnaCB0aGF0XHJcbiAqIGVhY2ggY2hhbmdlIGlzIHdvcnRoIGEgcmUtY29tbWl0IChhbmQgYW4gZW5nYWdlbWVudF9oaXN0b3J5IHNuYXBzaG90KS5cclxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxyXG4gKiB0aGUgZnVsbCBgbm90ZV90d2VldGAgYm9keSBieXBhc3NlcyB0aGUgZGVkdXAgZXZlbiB3aGVuIGVuZ2FnZW1lbnQgY291bnRzXHJcbiAqIGhhdmVuJ3QgbW92ZWQgXHUyMDE0IG90aGVyd2lzZSB0aGUgbmV3IGJvZHkgd291bGQgYmUgc2lsZW50bHkgZHJvcHBlZC4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXHJcbiAgbGlrZXM6IG51bWJlcixcclxuICByZXR3ZWV0czogbnVtYmVyLFxyXG4gIHJlcGxpZXM6IG51bWJlcixcclxuICBxdW90ZXM6IG51bWJlcixcclxuICBpc1RydW5jYXRlZDogYm9vbGVhbiA9IGZhbHNlXHJcbik6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGAke2xpa2VzfXwke3JldHdlZXRzfXwke3JlcGxpZXN9fCR7cXVvdGVzfXwke2lzVHJ1bmNhdGVkID8gJ3QnIDogJ2YnfWA7XHJcbn1cclxuXHJcbi8qKiBEcm9wIGVudHJpZXMgb2xkZXIgdGhhbiBgbWF4QWdlTXNgLiBSZXR1cm5zIHRoZSBudW1iZXIgcHJ1bmVkLiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJ1bmVDb21taXR0ZWRJbmRleChtYXhBZ2VNczogbnVtYmVyKTogUHJvbWlzZTxudW1iZXI+IHtcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGNvbnN0IGN1dG9mZiA9IG5ldyBEYXRlKERhdGUubm93KCkgLSBtYXhBZ2VNcykudG9JU09TdHJpbmcoKTtcclxuICBsZXQgcHJ1bmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XHJcbiAgICBjb25zdCBpbm5lciA9IGlkeFtoYW5kbGVdO1xyXG4gICAgaWYgKCFpbm5lcikgY29udGludWU7XHJcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcclxuICAgICAgY29uc3QgZSA9IGlubmVyW3RpZF07XHJcbiAgICAgIGlmIChlICYmIGUudHMgPCBjdXRvZmYpIHtcclxuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcclxuICAgICAgICBwcnVuZWQgKz0gMTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKE9iamVjdC5rZXlzKGlubmVyKS5sZW5ndGggPT09IDApIGRlbGV0ZSBpZHhbaGFuZGxlXTtcclxuICB9XHJcbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XHJcbiAgcmV0dXJuIHBydW5lZDtcclxufVxyXG5cclxuLy8gLS0tIFJlZmV0Y2ggcXVldWUgKHR3ZWV0cyBuZWVkaW5nIGZ1bGwtdGV4dCByZWNhcHR1cmUpIC0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFF1ZXVlJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWZldGNoUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBsZXQgdG90YWwgPSAwO1xyXG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XHJcbiAgcmV0dXJuIHRvdGFsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBjb25zdCBpZHMgPSBxW2hhbmRsZV0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtoYW5kbGVdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXTtcclxuICBpZiAoIWlkcykgcmV0dXJuO1xyXG4gIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcclxuICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtoYW5kbGVdO1xyXG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRSZWZldGNoVGFyZ2V0KCk6IFByb21pc2U8e1xyXG4gIGhhbmRsZTogc3RyaW5nO1xyXG4gIHR3ZWV0SWQ6IHN0cmluZztcclxufSB8IG51bGw+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XHJcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGhhbmRsZSwgdHdlZXRJZDogaWRzWzBdISB9O1xyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBsZXQgdG90YWwgPSAwO1xyXG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XHJcbiAgcmV0dXJuIHRvdGFsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZU1lZGlhQ3Jhd2woaGludEhhbmRsZTogc3RyaW5nIHwgbnVsbCwgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcclxuICBjb25zdCBpZHMgPSBxW2J1Y2tldF0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtidWNrZXRdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcclxuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xyXG4gICAgY29uc3QgaWRzID0gcVtidWNrZXRdO1xyXG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xyXG4gICAgaWYgKGZpbHRlcmVkLmxlbmd0aCAhPT0gaWRzLmxlbmd0aCkge1xyXG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcclxuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcclxuICAgICAgZWxzZSBxW2J1Y2tldF0gPSBmaWx0ZXJlZDtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKGNoYW5nZWQpIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgcSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0TWVkaWFDcmF3bFRhcmdldCgpOiBQcm9taXNlPHtcclxuICBidWNrZXQ6IHN0cmluZztcclxuICB0d2VldElkOiBzdHJpbmc7XHJcbn0gfCBudWxsPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xyXG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBidWNrZXQsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXHJcbiAqIGVucXVldWVpbmcgbWVkaWEtY3Jhd2wgdGFyZ2V0cyB3ZSd2ZSBhbHJlYWR5IGFyY2hpdmVkLiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNDb21taXR0ZWQodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBmb3IgKGNvbnN0IGlubmVyIG9mIE9iamVjdC52YWx1ZXMoaWR4KSkge1xyXG4gICAgaWYgKGlubmVyICYmIHR3ZWV0SWQgaW4gaW5uZXIpIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbi8vIC0tLSBMb29wIHNlc3Npb24gc3RhdGUgKHByb2dyZXNzICsgaW5mbGlnaHQgZ2F0aW5nKSAtLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFNlc3Npb24nLCBzKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJywgcyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEF1dG9TY3JvbGxTZXNzaW9uKCk6IFByb21pc2U8QXV0b1Njcm9sbFNlc3Npb24gfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXV0b1Njcm9sbFNlc3Npb24oczogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicsIHMpO1xyXG59XHJcblxyXG4vLyAtLS0gUHVyZ2U6IHVucmVsYXRlZCBidWZmZXJzLCBjb3VudGVycywgcXVldWUgZW50cmllcyAtLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4vKipcclxuICogRHJvcCBldmVyeSBwZXItaGFuZGxlIGJpdCBvZiBzdGF0ZSAoY291bnRlcnMsIHJ1biBidWZmZXIsIGNvbW1pdHRlZC1pbmRleFxyXG4gKiBlbnRyaWVzLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcXVldWUgZW50cmllcykgdGhhdCBkb2Vzbid0IGNvcnJlc3BvbmQgdG8gYVxyXG4gKiB0cmFja2VkIGFjY291bnQuIFJldHVybnMgYSBzdW1tYXJ5IGRlc2NyaWJpbmcgd2hhdCB3YXMgY2xlYXJlZCBzbyB0aGVcclxuICogY2FsbGVyIGNhbiBsb2cgaXQuXHJcbiAqXHJcbiAqIFRyYWNrZWQgYWNjb3VudHMgYXJlIHBhc3NlZCBpbiAoY2FsbGVyIHJlc29sdmVzIGZyb20gdGhlIGxpdmUgY29uZmlnKS5cclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwdXJnZVVucmVsYXRlZFN0YXRlKHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+KTogUHJvbWlzZTx7XHJcbiAgY291bnRlcnNSZW1vdmVkOiBudW1iZXI7XHJcbiAgYnVmZmVyc1JlbW92ZWQ6IG51bWJlcjtcclxuICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkOiBudW1iZXI7XHJcbn0+IHtcclxuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcclxuICBjb25zdCBpc1RhcmdldGVkID0gKGg6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGFyZ0xvd2VyLmhhcyhoLnRvTG93ZXJDYXNlKCkpO1xyXG5cclxuICAvLyBDb3VudGVyc1xyXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcclxuICBsZXQgY291bnRlcnNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGNvdW50ZXJzW2hdO1xyXG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcclxuXHJcbiAgLy8gUnVuIGJ1ZmZlcnNcclxuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGxldCBidWZmZXJzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGJ1ZmZlcnMpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGJ1ZmZlcnNbaF07XHJcbiAgICAgIGJ1ZmZlcnNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGJ1ZmZlcnMpO1xyXG5cclxuICAvLyBDb21taXR0ZWQgZGVkdXAgaW5kZXhcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgaWR4W2hdO1xyXG4gICAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xyXG5cclxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXHJcbiAgY29uc3QgcnEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBsZXQgcmVmZXRjaEhhbmRsZXNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIHJxW2hdO1xyXG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XHJcblxyXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiBidWNrZXRzIGFyZSBoaW50LWhhbmRsZXMgKG9yIFwiX3Vua25vd25cIikuIERyb3BcclxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCBcdTIwMTQgaW5jbHVkaW5nIFwiX3Vua25vd25cIiBzaW5jZSB3ZVxyXG4gIC8vIGNhbid0IHZlcmlmeSByZWxhdGlvbi5cclxuICBjb25zdCBtcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKG1xKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xyXG4gICAgICBkZWxldGUgbXFbaF07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgbXEpO1xyXG5cclxuICByZXR1cm4ge1xyXG4gICAgY291bnRlcnNSZW1vdmVkLFxyXG4gICAgYnVmZmVyc1JlbW92ZWQsXHJcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcclxuICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCxcclxuICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkLFxyXG4gIH07XHJcbn1cclxuXHJcbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcclxufVxyXG4iLCAiaW1wb3J0IHsgYXBwZW5kQWN0aXZpdHkgfSBmcm9tICcuL3N0b3JhZ2UuanMnO1xyXG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxubGV0IGJyb2FkY2FzdDogKChldjogTG9nRXZlbnQpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc2V0QnJvYWRjYXN0ZXIoZm46IChldjogTG9nRXZlbnQpID0+IHZvaWQpOiB2b2lkIHtcclxuICBicm9hZGNhc3QgPSBmbjtcclxufVxyXG5cclxuZnVuY3Rpb24gbm93SVNPKCk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGV2OiBMb2dFdmVudCA9IHsgdHM6IG5vd0lTTygpLCBsZXZlbCwgbXNnLCBjb250ZXh0OiByZWRhY3QoY29udGV4dCkgfTtcclxuICAvLyBDb25zb2xlIGZvciBkZXZ0b29scy5cclxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xyXG4gIGlmIChsZXZlbCA9PT0gJ2Vycm9yJykgY29uc29sZS5lcnJvcihsaW5lLCBldi5jb250ZXh0KTtcclxuICBlbHNlIGlmIChsZXZlbCA9PT0gJ3dhcm4nKSBjb25zb2xlLndhcm4obGluZSwgZXYuY29udGV4dCk7XHJcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcclxuICAvLyBQZXJzaXN0ZW50IHRhaWwuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBmYWlsZWQgdG8gYXBwZW5kIGFjdGl2aXR5JywgZXJyKTtcclxuICB9XHJcbiAgLy8gTGl2ZSBicm9hZGNhc3QgKGUuZy4gdG8gc2lkZWJhcikuXHJcbiAgdHJ5IHtcclxuICAgIGJyb2FkY2FzdD8uKGV2KTtcclxuICB9IGNhdGNoIHtcclxuICAgIC8vIFNpZGViYXIgbWF5IG5vdCBiZSBvcGVuOyB0aGF0J3MgZmluZS5cclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIGVtaXQoJ2luZm8nLCBtc2csIGNvbnRleHQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIGVtaXQoJ3dhcm4nLCBtc2csIGNvbnRleHQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHJldHVybiBlbWl0KCdlcnJvcicsIG1zZywgY29udGV4dCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZUVycm9yKGVycjogdW5rbm93bik6IHsgbWVzc2FnZTogc3RyaW5nOyBzdGFjazogc3RyaW5nIHwgbnVsbCB9IHtcclxuICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcclxuICB9XHJcbiAgdHJ5IHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIHsgbWVzc2FnZTogJzx1bnByaW50YWJsZSBlcnJvcj4nLCBzdGFjazogbnVsbCB9O1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFN0cmlwIGFueXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIFBBVCBvciBvdGhlciBsb25nIHNlY3JldCBmcm9tIGEgY29udGV4dFxyXG4gKiBvYmplY3QgYmVmb3JlIHBlcnNpc3RpbmcgaXQuIERlZmVuc2l2ZTogY2FsbGVycyBzaG91bGQgbm90IGxvZyB0b2tlbnMsIGJ1dFxyXG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxyXG4gKi9cclxuZnVuY3Rpb24gcmVkYWN0KGN0eDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XHJcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xyXG4gIGZvciAoY29uc3QgW2ssIHZdIG9mIE9iamVjdC5lbnRyaWVzKGN0eCkpIHtcclxuICAgIGlmIChrLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ3Rva2VuJykgfHwgay50b0xvd2VyQ2FzZSgpID09PSAncGF0JyB8fCBrID09PSAnYXV0aG9yaXphdGlvbicpIHtcclxuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dezMwLH0vLnRlc3QodikpIHtcclxuICAgICAgb3V0W2tdID0gdi5yZXBsYWNlKC9naXRodWJfcGF0X1tBLVphLXowLTlfXSsvZywgJ2dpdGh1Yl9wYXRfPHJlZGFjdGVkPicpO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XHJcbiAgICAgIG91dFtrXSA9IGAke3Yuc2xpY2UoMCwgNDA5Nil9XHUyMDI2PHRydW5jYXRlZD5gO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgb3V0W2tdID0gdjtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG4iLCAiaW1wb3J0IHsgZGVzY3JpYmVFcnJvciB9IGZyb20gJy4vbG9nZ2VyLmpzJztcclxuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuY29uc3QgQVBJX0JBU0UgPSAnaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbSc7XHJcbmNvbnN0IFJBV19CQVNFID0gJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFB1dEZpbGVPcHRpb25zIHtcclxuICBwYXRoOiBzdHJpbmc7XHJcbiAgY29udGVudEJhc2U2NDogc3RyaW5nO1xyXG4gIG1lc3NhZ2U6IHN0cmluZztcclxuICBleHBlY3RlZFNoYT86IHN0cmluZyB8IG51bGw7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZVJlc3VsdCB7XHJcbiAgcGF0aDogc3RyaW5nO1xyXG4gIHNoYTogc3RyaW5nO1xyXG4gIHVybDogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVPcHRpb25zIHtcclxuICBwYXRoOiBzdHJpbmc7XHJcbiAgY29udGVudEJhc2U2NDogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVzT3B0aW9ucyB7XHJcbiAgZmlsZXM6IENvbW1pdEZpbGVPcHRpb25zW107XHJcbiAgbWVzc2FnZTogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVzUmVzdWx0IHtcclxuICBjb21taXRTaGE6IHN0cmluZztcclxuICB1cmw6IHN0cmluZztcclxuICBmaWxlczogc3RyaW5nW107XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBHaXRIdWJFcnJvciBleHRlbmRzIEVycm9yIHtcclxuICBzdGF0dXM6IG51bWJlcjtcclxuICBib2R5OiB1bmtub3duO1xyXG4gIHJldHJpYWJsZTogYm9vbGVhbjtcclxuICBjYXRlZ29yeTogJ2F1dGgnIHwgJ3JhdGUtbGltaXQnIHwgJ2NvbmZsaWN0JyB8ICdub3QtZm91bmQnIHwgJ3NlcnZlcicgfCAnbmV0d29yaycgfCAndW5rbm93bic7XHJcbiAgLyoqIFdoZW4gdGhlIEdpdEh1YiByYXRlLWxpbWl0IHdpbmRvdyBmb3IgdGhpcyB0b2tlbiByZXNldHMsIGFzIGEgVW5peFxyXG4gICAqIGVwb2NoIGluIHNlY29uZHMuIFBvcHVsYXRlZCBmcm9tIGBYLVJhdGVMaW1pdC1SZXNldGAgb24gNDAzLzQyOSwgb3JcclxuICAgKiBkZXJpdmVkIGZyb20gYFJldHJ5LUFmdGVyYCBmb3Igc2Vjb25kYXJ5IGxpbWl0cy4gbnVsbCB3aGVuIHVua25vd24uICovXHJcbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVtYmVyIHwgbnVsbDtcclxuXHJcbiAgY29uc3RydWN0b3Iob3B0czoge1xyXG4gICAgc3RhdHVzOiBudW1iZXI7XHJcbiAgICBib2R5OiB1bmtub3duO1xyXG4gICAgbWVzc2FnZTogc3RyaW5nO1xyXG4gICAgcmV0cmlhYmxlOiBib29sZWFuO1xyXG4gICAgY2F0ZWdvcnk6IEdpdEh1YkVycm9yWydjYXRlZ29yeSddO1xyXG4gICAgcmF0ZUxpbWl0UmVzZXRBdD86IG51bWJlciB8IG51bGw7XHJcbiAgfSkge1xyXG4gICAgc3VwZXIob3B0cy5tZXNzYWdlKTtcclxuICAgIHRoaXMubmFtZSA9ICdHaXRIdWJFcnJvcic7XHJcbiAgICB0aGlzLnN0YXR1cyA9IG9wdHMuc3RhdHVzO1xyXG4gICAgdGhpcy5ib2R5ID0gb3B0cy5ib2R5O1xyXG4gICAgdGhpcy5yZXRyaWFibGUgPSBvcHRzLnJldHJpYWJsZTtcclxuICAgIHRoaXMuY2F0ZWdvcnkgPSBvcHRzLmNhdGVnb3J5O1xyXG4gICAgdGhpcy5yYXRlTGltaXRSZXNldEF0ID0gb3B0cy5yYXRlTGltaXRSZXNldEF0ID8/IG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgR2l0SHViQ2xpZW50IHtcclxuICBwcml2YXRlIHJlYWRvbmx5IHNldHRpbmdzOiBTZXR0aW5ncztcclxuXHJcbiAgY29uc3RydWN0b3Ioc2V0dGluZ3M6IFNldHRpbmdzKSB7XHJcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XHJcbiAgfVxyXG5cclxuICAvKiogUmV0dXJucyB0aGUgYXV0aGVudGljYXRlZCB1c2VyJ3MgbG9naW4uIFRocm93cyBvbiBhdXRoIGZhaWx1cmUuICovXHJcbiAgYXN5bmMgd2hvYW1pKCk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgJy91c2VyJyk7XHJcbiAgICByZXR1cm4gKHJlcyBhcyB7IGxvZ2luPzogc3RyaW5nIH0pLmxvZ2luID8/ICc8dW5rbm93bj4nO1xyXG4gIH1cclxuXHJcbiAgLyoqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZ2l2ZW4gYnJhbmNoIGV4aXN0cyBvbiB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xyXG4gIGFzeW5jIGJyYW5jaEV4aXN0cyhicmFuY2g6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXHJcbiAgICAgICAgJ0dFVCcsXHJcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9icmFuY2hlcy8ke2VuY29kZVVSSUNvbXBvbmVudChicmFuY2gpfWBcclxuICAgICAgKTtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBmYWxzZTtcclxuICAgICAgdGhyb3cgZXJyO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqIFZlcmlmaWVzIHRoZSBQQVQgY2FuIHNlZSB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xyXG4gIGFzeW5jIHZlcmlmeVJlcG9BY2Nlc3MoKTogUHJvbWlzZTx7IGxvZ2luOiBzdHJpbmc7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH0+IHtcbiAgICBjb25zdCBtZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICBjb25zdCByZXBvID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb31gKTtcbiAgICBjb25zdCByID0gcmVwbyBhcyB7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGxvZ2luOiAobWUgYXMgeyBsb2dpbjogc3RyaW5nIH0pLmxvZ2luLFxuICAgICAgZnVsbF9uYW1lOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogVmVyaWZ5IHRoZSBQQVQgY2FuIHdyaXRlIHRvIHRoZSBjb25maWd1cmVkIGJyYW5jaCB3aXRob3V0IGNyZWF0aW5nIGFcbiAgICogY29tbWl0LiBNb3ZpbmcgYSByZWYgdG8gaXRzIGN1cnJlbnQgU0hBIGlzIGEgbm8tb3AsIGJ1dCBHaXRIdWIgc3RpbGxcbiAgICogZW5mb3JjZXMgdGhlIENvbnRlbnRzOiBXcml0ZSBwZXJtaXNzaW9uIHJlcXVpcmVkIGJ5IGNvbW1pdEZpbGVzKCkuXG4gICAqL1xuICBhc3luYyB2ZXJpZnlXcml0ZUFjY2VzcygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XG4gICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAnUEFUQ0gnLFxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXG4gICAgICB7XG4gICAgICAgIHNoYTogaGVhZC5zaGEsXG4gICAgICAgIGZvcmNlOiBmYWxzZSxcbiAgICAgIH1cbiAgICApO1xuICB9XG5cclxuICAvKipcclxuICAgKiBGZXRjaCBhIHRleHQgZmlsZSBmcm9tIHJhdy5naXRodWJ1c2VyY29udGVudC5jb20gYXV0aGVudGljYXRlZCB3aXRoIHRoZVxyXG4gICAqIFBBVC4gUmV0dXJucyBudWxsIGlmIHRoZSBmaWxlIGRvZXNuJ3QgZXhpc3QuIFVzZWQgZm9yIGNvbmZpZy9hY2NvdW50cy55YW1sLlxyXG4gICAqL1xyXG4gIGFzeW5jIGZldGNoUmF3VGV4dChwYXRoSW5SZXBvOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICAgIGNvbnN0IHVybCA9IGAke1JBV19CQVNFfS8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS8ke3RoaXMuc2V0dGluZ3MuYnJhbmNofS8ke3BhdGhJblJlcG99YDtcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCwge1xyXG4gICAgICBtZXRob2Q6ICdHRVQnLFxyXG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLnNldHRpbmdzLnBhdH1gIH0sXHJcbiAgICB9KTtcclxuICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDQpIHJldHVybiBudWxsO1xyXG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yKHJlcywgYEdFVCByYXcgJHtwYXRoSW5SZXBvfWApO1xyXG4gICAgcmV0dXJuIHJlcy50ZXh0KCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBMb29rIHVwIGFuIGV4aXN0aW5nIGZpbGUncyBTSEEgdmlhIHRoZSBDb250ZW50cyBBUEksIG9yIG51bGwgaWYgbm90IGZvdW5kLlxyXG4gICAqIFVzZWQgd2hlbiByZXRyeWluZyBhIFBVVCBhZnRlciBhIDQyMiBzaGEgbWlzbWF0Y2guXHJcbiAgICovXHJcbiAgYXN5bmMgZ2V0RmlsZVNoYShwYXRoOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICdHRVQnLFxyXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vY29udGVudHMvJHtlbmNvZGVQYXRoKHBhdGgpfT9yZWY9JHtlbmNvZGVVUklDb21wb25lbnQodGhpcy5zZXR0aW5ncy5icmFuY2gpfWBcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgciA9IHJlcyBhcyB7IHNoYT86IHN0cmluZyB9O1xyXG4gICAgICByZXR1cm4gci5zaGEgPz8gbnVsbDtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBpZiAoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgZXJyLmNhdGVnb3J5ID09PSAnbm90LWZvdW5kJykgcmV0dXJuIG51bGw7XHJcbiAgICAgIHRocm93IGVycjtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFBVVCBhIGZpbGUgdG8gdGhlIHJlcG8uIEhhbmRsZXMgNDIyIChzaGEgcmVxdWlyZWQpIGJ5IHJlLWZldGNoaW5nIHRoZVxyXG4gICAqIGV4aXN0aW5nIHNoYSBhbmQgcmV0cnlpbmcgb25jZS4gUmV0cmllcyBuZXR3b3JrIC8gNXh4IC8gcmF0ZS1saW1pdCBlcnJvcnNcclxuICAgKiB3aXRoIGV4cG9uZW50aWFsIGJhY2tvZmYgdXAgdG8gbWF4QXR0ZW1wdHMuXHJcbiAgICovXHJcbiAgYXN5bmMgcHV0RmlsZShvcHRzOiBQdXRGaWxlT3B0aW9ucyk6IFByb21pc2U8UHV0RmlsZVJlc3VsdD4ge1xyXG4gICAgY29uc3QgcGF0aCA9IG9wdHMucGF0aDtcclxuICAgIGNvbnN0IHVybCA9IGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vY29udGVudHMvJHtlbmNvZGVQYXRoKHBhdGgpfWA7XHJcbiAgICBsZXQgc2hhOiBzdHJpbmcgfCBudWxsID0gb3B0cy5leHBlY3RlZFNoYSA/PyBudWxsO1xyXG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xyXG5cclxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcclxuICAgICAgY29uc3QgYm9keTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XHJcbiAgICAgICAgbWVzc2FnZTogb3B0cy5tZXNzYWdlLFxyXG4gICAgICAgIGNvbnRlbnQ6IG9wdHMuY29udGVudEJhc2U2NCxcclxuICAgICAgICBicmFuY2g6IHRoaXMuc2V0dGluZ3MuYnJhbmNoLFxyXG4gICAgICB9O1xyXG4gICAgICBpZiAoc2hhKSBib2R5LnNoYSA9IHNoYTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignUFVUJywgdXJsLCBib2R5KTtcclxuICAgICAgICBjb25zdCBvdXQgPSByZXMgYXMgeyBjb250ZW50OiB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nOyBwYXRoOiBzdHJpbmcgfSB9O1xyXG4gICAgICAgIHJldHVybiB7IHBhdGg6IG91dC5jb250ZW50LnBhdGgsIHNoYTogb3V0LmNvbnRlbnQuc2hhLCB1cmw6IG91dC5jb250ZW50Lmh0bWxfdXJsIH07XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xyXG4gICAgICAgIGlmIChlcnIuc3RhdHVzID09PSA0MjIgJiYgIXNoYSkge1xyXG4gICAgICAgICAgLy8gRmlsZSBhbHJlYWR5IGV4aXN0czsgZmV0Y2ggaXRzIHNoYSBhbmQgcmV0cnkgb25jZS5cclxuICAgICAgICAgIHNoYSA9IGF3YWl0IHRoaXMuZ2V0RmlsZVNoYShwYXRoKTtcclxuICAgICAgICAgIGlmICghc2hhKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCFlcnIucmV0cmlhYmxlIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoYHB1dEZpbGU6IGV4aGF1c3RlZCBhdHRlbXB0cyBmb3IgJHtwYXRofWApO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ29tbWl0IHNldmVyYWwgZmlsZXMgd2l0aCBvbmUgYnJhbmNoIHVwZGF0ZS4gVGhlIENvbnRlbnRzIEFQSSBjcmVhdGVzIG9uZVxyXG4gICAqIGNvbW1pdCBwZXIgUFVULCBzbyByYXBpZCBmbHVzaGVzIHJhY2UgZWFjaCBvdGhlciBvbiB0aGUgYnJhbmNoIGhlYWQuIFRoaXNcclxuICAgKiB1c2VzIHRoZSBsb3dlci1sZXZlbCBHaXQgRGF0YSBBUEkgaW5zdGVhZDogdXBsb2FkIGJsb2JzLCBidWlsZCBhIHRyZWUsXHJcbiAgICogY3JlYXRlIG9uZSBjb21taXQsIHRoZW4gbW92ZSB0aGUgYnJhbmNoIHJlZiBvbmNlLiBJZiBhbm90aGVyIHdyaXRlciBtb3Zlc1xyXG4gICAqIHRoZSBicmFuY2ggZmlyc3QsIHJlYmFzZSB0aGlzIHRyZWUgcGF0Y2ggb250byB0aGUgbGF0ZXN0IGhlYWQgYW5kIHJldHJ5LlxyXG4gICAqL1xyXG4gIGFzeW5jIGNvbW1pdEZpbGVzKG9wdHM6IENvbW1pdEZpbGVzT3B0aW9ucyk6IFByb21pc2U8Q29tbWl0RmlsZXNSZXN1bHQ+IHtcclxuICAgIGlmIChvcHRzLmZpbGVzLmxlbmd0aCA9PT0gMCkgdGhyb3cgbmV3IEVycm9yKCdjb21taXRGaWxlczogbm8gZmlsZXMgdG8gY29tbWl0Jyk7XHJcbiAgICBjb25zdCBtYXhBdHRlbXB0cyA9IDU7XHJcbiAgICBsZXQgbGFzdEVycjogdW5rbm93biA9IG51bGw7XHJcblxyXG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDE7IGF0dGVtcHQgPD0gbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGJsb2JzID0gYXdhaXQgUHJvbWlzZS5hbGwoXHJcbiAgICAgICAgICBvcHRzLmZpbGVzLm1hcChhc3luYyAoZmlsZSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBvdXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcclxuICAgICAgICAgICAgICAnUE9TVCcsXHJcbiAgICAgICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvYmxvYnNgLFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGZpbGUuY29udGVudEJhc2U2NCxcclxuICAgICAgICAgICAgICAgIGVuY29kaW5nOiAnYmFzZTY0JyxcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgcGF0aDogZmlsZS5wYXRoLFxyXG4gICAgICAgICAgICAgIHNoYTogKG91dCBhcyB7IHNoYTogc3RyaW5nIH0pLnNoYSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgY29uc3QgaGVhZCA9IGF3YWl0IHRoaXMuZ2V0QnJhbmNoSGVhZCgpO1xyXG4gICAgICAgIGNvbnN0IHRyZWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcclxuICAgICAgICAgICdQT1NUJyxcclxuICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L3RyZWVzYCxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgYmFzZV90cmVlOiBoZWFkLnRyZWVTaGEsXHJcbiAgICAgICAgICAgIHRyZWU6IGJsb2JzLm1hcCgoYmxvYikgPT4gKHtcclxuICAgICAgICAgICAgICBwYXRoOiBibG9iLnBhdGgsXHJcbiAgICAgICAgICAgICAgbW9kZTogJzEwMDY0NCcsXHJcbiAgICAgICAgICAgICAgdHlwZTogJ2Jsb2InLFxyXG4gICAgICAgICAgICAgIHNoYTogYmxvYi5zaGEsXHJcbiAgICAgICAgICAgIH0pKSxcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IHRyZWVTaGEgPSAodHJlZSBhcyB7IHNoYTogc3RyaW5nIH0pLnNoYTtcclxuICAgICAgICBjb25zdCBjb21taXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcclxuICAgICAgICAgICdQT1NUJyxcclxuICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L2NvbW1pdHNgLFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgIHRyZWU6IHRyZWVTaGEsXHJcbiAgICAgICAgICAgIHBhcmVudHM6IFtoZWFkLnNoYV0sXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgICAgICBjb25zdCBjb21taXRPdXQgPSBjb21taXQgYXMgeyBzaGE6IHN0cmluZzsgaHRtbF91cmw6IHN0cmluZyB9O1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCB0aGlzLmZldGNoSnNvbihcclxuICAgICAgICAgICAgJ1BBVENIJyxcclxuICAgICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBzaGE6IGNvbW1pdE91dC5zaGEsXHJcbiAgICAgICAgICAgICAgZm9yY2U6IGZhbHNlLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgaWYgKGlzQ29uZmxpY3QoZXJyKSAmJiBhdHRlbXB0IDwgbWF4QXR0ZW1wdHMpIHtcclxuICAgICAgICAgICAgbGFzdEVyciA9IGVycjtcclxuICAgICAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xyXG4gICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRocm93IGVycjtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGNvbW1pdFNoYTogY29tbWl0T3V0LnNoYSxcclxuICAgICAgICAgIHVybDogY29tbWl0T3V0Lmh0bWxfdXJsLFxyXG4gICAgICAgICAgZmlsZXM6IG9wdHMuZmlsZXMubWFwKChmaWxlKSA9PiBmaWxlLnBhdGgpLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGxhc3RFcnIgPSBlcnI7XHJcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgaWYgKCghZXJyLnJldHJpYWJsZSAmJiAhaXNDb25mbGljdChlcnIpKSB8fCBhdHRlbXB0ID09PSBtYXhBdHRlbXB0cykgdGhyb3cgZXJyO1xyXG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhyb3cgbGFzdEVyciBpbnN0YW5jZW9mIEVycm9yID8gbGFzdEVyciA6IG5ldyBFcnJvcignY29tbWl0RmlsZXM6IGV4aGF1c3RlZCBhdHRlbXB0cycpO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhc3luYyBnZXRCcmFuY2hIZWFkKCk6IFByb21pc2U8eyBzaGE6IHN0cmluZzsgdHJlZVNoYTogc3RyaW5nIH0+IHtcclxuICAgIGNvbnN0IHJlZiA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAnR0VUJyxcclxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmL2hlYWRzLyR7ZW5jb2RlUGF0aCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxyXG4gICAgKTtcclxuICAgIGNvbnN0IGhlYWRTaGEgPSAocmVmIGFzIHsgb2JqZWN0OiB7IHNoYTogc3RyaW5nIH0gfSkub2JqZWN0LnNoYTtcclxuICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAnR0VUJyxcclxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvY29tbWl0cy8ke2hlYWRTaGF9YFxyXG4gICAgKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHNoYTogaGVhZFNoYSxcclxuICAgICAgdHJlZVNoYTogKGNvbW1pdCBhcyB7IHRyZWU6IHsgc2hhOiBzdHJpbmcgfSB9KS50cmVlLnNoYSxcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGFzeW5jIGZldGNoSnNvbihtZXRob2Q6IHN0cmluZywgcGF0aDogc3RyaW5nLCBib2R5PzogdW5rbm93bik6IFByb21pc2U8dW5rbm93bj4ge1xyXG4gICAgY29uc3QgdXJsID0gcGF0aC5zdGFydHNXaXRoKCdodHRwJykgPyBwYXRoIDogYCR7QVBJX0JBU0V9JHtwYXRofWA7XHJcbiAgICBjb25zdCBpbml0OiBSZXF1ZXN0SW5pdCA9IHtcclxuICAgICAgbWV0aG9kLFxyXG4gICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAsXHJcbiAgICAgICAgQWNjZXB0OiAnYXBwbGljYXRpb24vdm5kLmdpdGh1Yitqc29uJyxcclxuICAgICAgICAnWC1HaXRIdWItQXBpLVZlcnNpb24nOiAnMjAyMi0xMS0yOCcsXHJcbiAgICAgICAgLi4uKGJvZHkgPyB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSA6IHt9KSxcclxuICAgICAgfSxcclxuICAgICAgLi4uKGJvZHkgPyB7IGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpIH0gOiB7fSksXHJcbiAgICB9O1xyXG4gICAgbGV0IHJlczogUmVzcG9uc2U7XHJcbiAgICB0cnkge1xyXG4gICAgICByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIGluaXQpO1xyXG4gICAgfSBjYXRjaCAobmV0RXJyKSB7XHJcbiAgICAgIHRocm93IG5ldyBHaXRIdWJFcnJvcih7XHJcbiAgICAgICAgc3RhdHVzOiAwLFxyXG4gICAgICAgIGJvZHk6IG51bGwsXHJcbiAgICAgICAgbWVzc2FnZTogYG5ldHdvcms6ICR7ZGVzY3JpYmVFcnJvcihuZXRFcnIpLm1lc3NhZ2V9YCxcclxuICAgICAgICByZXRyaWFibGU6IHRydWUsXHJcbiAgICAgICAgY2F0ZWdvcnk6ICduZXR3b3JrJyxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gMjA0KSByZXR1cm4gbnVsbDtcclxuICAgIGxldCBwYXJzZWQ6IHVua25vd24gPSBudWxsO1xyXG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XHJcbiAgICBpZiAodGV4dCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XHJcbiAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgIHBhcnNlZCA9IHRleHQ7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICghcmVzLm9rKSB0aHJvdyBhd2FpdCB0aGlzLm1ha2VFcnJvckZyb21QYXJzZWQocmVzLCBwYXJzZWQsIGAke21ldGhvZH0gJHtwYXRofWApO1xyXG4gICAgcmV0dXJuIHBhcnNlZDtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgYXN5bmMgbWFrZUVycm9yKHJlczogUmVzcG9uc2UsIGxhYmVsOiBzdHJpbmcpOiBQcm9taXNlPEdpdEh1YkVycm9yPiB7XHJcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xyXG4gICAgICBpZiAodGV4dCkgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBpZ25vcmVcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLm1ha2VFcnJvckZyb21QYXJzZWQocmVzLCBwYXJzZWQsIGxhYmVsKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgbWFrZUVycm9yRnJvbVBhcnNlZChyZXM6IFJlc3BvbnNlLCBib2R5OiB1bmtub3duLCBsYWJlbDogc3RyaW5nKTogR2l0SHViRXJyb3Ige1xyXG4gICAgY29uc3QgbXNnID1cclxuICAgICAgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmIGJvZHkgJiYgJ21lc3NhZ2UnIGluIGJvZHlcclxuICAgICAgICA/IFN0cmluZygoYm9keSBhcyB7IG1lc3NhZ2U6IHVua25vd24gfSkubWVzc2FnZSlcclxuICAgICAgICA6IHJlcy5zdGF0dXNUZXh0O1xyXG4gICAgbGV0IGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXSA9ICd1bmtub3duJztcclxuICAgIGxldCByZXRyaWFibGUgPSBmYWxzZTtcclxuICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDEgfHwgcmVzLnN0YXR1cyA9PT0gNDAzKSB7XHJcbiAgICAgIC8vIDQwMyBjYW4gYmUgZWl0aGVyIGF1dGggb3IgcmF0ZSBsaW1pdDsgY2hlY2sgaGVhZGVycy5cclxuICAgICAgY29uc3QgcmF0ZSA9IHJlcy5oZWFkZXJzLmdldCgneC1yYXRlbGltaXQtcmVtYWluaW5nJyk7XHJcbiAgICAgIGlmIChyYXRlID09PSAnMCcgfHwgL3JhdGUgbGltaXQvaS50ZXN0KG1zZykpIHtcclxuICAgICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcclxuICAgICAgICByZXRyaWFibGUgPSB0cnVlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNhdGVnb3J5ID0gJ2F1dGgnO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkge1xyXG4gICAgICBjYXRlZ29yeSA9ICdub3QtZm91bmQnO1xyXG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID09PSA0MDkgfHwgcmVzLnN0YXR1cyA9PT0gNDIyKSB7XHJcbiAgICAgIGNhdGVnb3J5ID0gJ2NvbmZsaWN0JztcclxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA+PSA1MDApIHtcclxuICAgICAgY2F0ZWdvcnkgPSAnc2VydmVyJztcclxuICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcclxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDI5KSB7XHJcbiAgICAgIGNhdGVnb3J5ID0gJ3JhdGUtbGltaXQnO1xyXG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBHaXRIdWJFcnJvcih7XHJcbiAgICAgIHN0YXR1czogcmVzLnN0YXR1cyxcclxuICAgICAgYm9keSxcclxuICAgICAgbWVzc2FnZTogYCR7bGFiZWx9IFx1MjE5MiAke3Jlcy5zdGF0dXN9OiAke21zZ31gLFxyXG4gICAgICByZXRyaWFibGUsXHJcbiAgICAgIGNhdGVnb3J5LFxyXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBjYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnID8gcGFyc2VSYXRlTGltaXRSZXNldChyZXMuaGVhZGVycykgOiBudWxsLFxyXG4gICAgfSk7XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogQmVzdC1lZmZvcnQgcGFyc2Ugb2Ygd2hlbiB0aGUgY3VycmVudCByYXRlLWxpbWl0IHdpbmRvdyBlbmRzLiBHaXRIdWInc1xyXG4gKiBwcmltYXJ5IGxpbWl0IHJlcG9ydHMgYFgtUmF0ZUxpbWl0LVJlc2V0YCBhcyBhIFVuaXggZXBvY2ggaW4gc2Vjb25kcy5cclxuICogU2Vjb25kYXJ5IC8gYWJ1c2UgbGltaXRzIHVzZSBgUmV0cnktQWZ0ZXJgLCB3aGljaCBpcyBlaXRoZXIgYW4gSFRUUC1kYXRlXHJcbiAqIG9yIGEgZGVsdGEgaW4gc2Vjb25kcyBcdTIwMTQgd2Ugbm9ybWFsaXplIGJvdGggdG8gZXBvY2ggc2Vjb25kcy5cclxuICovXHJcbmZ1bmN0aW9uIHBhcnNlUmF0ZUxpbWl0UmVzZXQoaGVhZGVyczogSGVhZGVycyk6IG51bWJlciB8IG51bGwge1xyXG4gIGNvbnN0IHJlc2V0ID0gaGVhZGVycy5nZXQoJ3gtcmF0ZWxpbWl0LXJlc2V0Jyk7XHJcbiAgaWYgKHJlc2V0KSB7XHJcbiAgICBjb25zdCBuID0gTnVtYmVyLnBhcnNlSW50KHJlc2V0LCAxMCk7XHJcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKG4pICYmIG4gPiAwKSByZXR1cm4gbjtcclxuICB9XHJcbiAgY29uc3QgcmV0cnlBZnRlciA9IGhlYWRlcnMuZ2V0KCdyZXRyeS1hZnRlcicpO1xyXG4gIGlmIChyZXRyeUFmdGVyKSB7XHJcbiAgICBjb25zdCBkZWx0YSA9IE51bWJlci5wYXJzZUludChyZXRyeUFmdGVyLCAxMCk7XHJcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGRlbHRhKSAmJiBkZWx0YSA+PSAwKSB7XHJcbiAgICAgIHJldHVybiBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKSArIGRlbHRhO1xyXG4gICAgfVxyXG4gICAgY29uc3QgYXNEYXRlID0gRGF0ZS5wYXJzZShyZXRyeUFmdGVyKTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYXNEYXRlKSkgcmV0dXJuIE1hdGguZmxvb3IoYXNEYXRlIC8gMTAwMCk7XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcblxyXG5mdW5jdGlvbiBlbmNvZGVQYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgLy8gRW5jb2RlIHNlZ21lbnRzIGluZGl2aWR1YWxseSBzbyBzbGFzaGVzIHJlbWFpbi5cclxuICByZXR1cm4gcGF0aC5zcGxpdCgnLycpLm1hcChlbmNvZGVVUklDb21wb25lbnQpLmpvaW4oJy8nKTtcclxufVxyXG5cclxuZnVuY3Rpb24gYmFja29mZk1zKGF0dGVtcHQ6IG51bWJlciwgZXJyOiBHaXRIdWJFcnJvcik6IG51bWJlciB7XHJcbiAgLy8gRXhwb25lbnRpYWwgd2l0aCBqaXR0ZXI7IGJ1bXAgaGlnaGVyIGZvciByYXRlLWxpbWl0IHJlc3BvbnNlcy5cclxuICBjb25zdCBiYXNlID0gZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyA1MDAwIDogNTAwO1xyXG4gIGNvbnN0IGppdHRlciA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDQwMCk7XHJcbiAgcmV0dXJuIE1hdGgubWluKDYwXzAwMCwgYmFzZSAqIDIgKiogKGF0dGVtcHQgLSAxKSArIGppdHRlcik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGlzQ29uZmxpY3QoZXJyOiB1bmtub3duKTogZXJyIGlzIEdpdEh1YkVycm9yIHtcclxuICByZXR1cm4gZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgZXJyLmNhdGVnb3J5ID09PSAnY29uZmxpY3QnO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzbGVlcChtczogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB0b0Jhc2U2NChieXRlczogc3RyaW5nKTogc3RyaW5nIHtcclxuICAvLyBieXRlcyBpcyBhIFVURi04IHN0cmluZyBvZiBKU09OOyBlbmNvZGUgdG8gYmFzZTY0IHRoZSBzYWZlIHdheS5cclxuICBjb25zdCB1dGY4ID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKGJ5dGVzKTtcclxuICBsZXQgYmluID0gJyc7XHJcbiAgZm9yIChjb25zdCBiIG9mIHV0ZjgpIGJpbiArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xyXG4gIHJldHVybiBidG9hKGJpbik7XHJcbn1cclxuIiwgImltcG9ydCB7IFRXRUVUX1VSTF9QUkVGSVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBDYW5vbmljYWxUd2VldCxcclxuICBDb21tdW5pdHlOb3RlLFxyXG4gIE1lZGlhSXRlbSxcclxuICBUd2VldENhcmQsXHJcbiAgVHdlZXRUeXBlLFxyXG4gIFVuYXZhaWxhYmxlVHdlZXQsXHJcbiAgVXJsRW50aXR5LFxyXG4gIFVzZXJTbmFwc2hvdCxcclxufSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbi8qKlxyXG4gKiBOb3JtYWxpemUgR3JhcGhRTCByZXNwb25zZSBwYXlsb2FkcyBmcm9tIFgncyBpbnRlcm5hbCBBUEkgaW50b1xyXG4gKiBgQ2Fub25pY2FsVHdlZXRgcy4gTWFueSBlbmRwb2ludHMgc2hhcmUgYSBzaW1pbGFyIHR3ZWV0IHNoYXBlIGJ1dCB3cmFwIGl0IGluXHJcbiAqIGRpZmZlcmVudCBlbnZlbG9wZXM7IHRoaXMgbW9kdWxlIHdhbGtzIHRoZSBzdHJ1Y3R1cmUgZGVmZW5zaXZlbHkuXHJcbiAqXHJcbiAqIFRoZSBwYXJzZXIgaXMgaW50ZW50aW9uYWxseSBwZXJtaXNzaXZlOiBpdCB3aWxsIHNpbGVudGx5IHNraXAgZW50cmllcyBpdFxyXG4gKiBjYW4ndCByZWNvZ25pemUgYXMgdHdlZXRzIChjdXJzb3JzLCBhZHMsIGdhcCBlbnRyaWVzLCBtb2R1bGVzIG9mIG90aGVyXHJcbiAqIHR3ZWV0cywgdG9tYnN0b25lcykuIEl0IHRocm93cyAqb25seSogd2hlbiBnaXZlbiBhIHBheWxvYWQgaXQgZG9lc24ndCBrbm93XHJcbiAqIGhvdyB0byB3YWxrIGF0IGFsbCBcdTIwMTQgdGhvc2UgY2FzZXMgYXJlIGNhdWdodCBhbmQgcXVhcmFudGluZWQgdXBzdHJlYW0uXHJcbiAqL1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBOb3JtYWxpemVDb250ZXh0IHtcclxuICBjYXB0dXJlZEF0OiBzdHJpbmc7XHJcbiAgcnVuSWQ6IHN0cmluZztcclxuICBlbmRwb2ludDogc3RyaW5nO1xyXG4gIGFsbG93ZWRIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+O1xyXG4gIHNvdXJjZVVybD86IHN0cmluZyB8IG51bGw7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgTm9ybWFsaXplUmVzdWx0IHtcclxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W107XHJcbiAgb2JzZXJ2ZWRfaWRzOiBzdHJpbmdbXTtcclxuICB1bmF2YWlsYWJsZV90d2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXTtcclxuICAvKipcclxuICAgKiBUd2VldC1zaGFwZWQgbm9kZXMgdGhlIHdhbGtlciBzYXcgKGhhZCBhIGByZXN0X2lkYCkgYnV0IGNvdWxkbid0IHR1cm5cclxuICAgKiBpbnRvIGEgZnVsbCBgQ2Fub25pY2FsVHdlZXRgIFx1MjAxNCB0eXBpY2FsbHkgYmVjYXVzZSB0aGUgZW1iZWRkZWQgdXNlclxyXG4gICAqIGluZm8gd2FzIG1pc3Npbmcgb3IgdGhlIGVudHJ5IHdhcyBhIG1lZGlhLW9ubHkgdGh1bWJuYWlsIGNhcmQgZnJvbVxyXG4gICAqIHRoZSBVc2VyTWVkaWEgZW5kcG9pbnQuIE9ubHkgSURzIHdpdGggYSB0cnVzdHdvcnRoeSBoYW5kbGUgZnJvbSB0aGVcclxuICAgKiB0d2VldCBub2RlIGl0c2VsZiBhcmUgcmV0dXJuZWQ7IG90aGVyd2lzZSB0aGUgYmFja2dyb3VuZCBjYW5ub3QgYnVpbGRcclxuICAgKiBhIHJlbGlhYmxlIC88aGFuZGxlPi9zdGF0dXMvPGlkPiBkZXRhaWwgVVJMLlxyXG4gICAqL1xyXG4gIHBhcnRpYWxfaWRzOiBBcnJheTx7IHR3ZWV0X2lkOiBzdHJpbmc7IGhpbnRfaGFuZGxlOiBzdHJpbmcgfCBudWxsIH0+O1xyXG59XHJcblxyXG4vLyBYIHR3ZWV0IElEcyBhcmUgNjQtYml0IHBvc2l0aXZlIGludGVnZXJzIHNlcmlhbGl6ZWQgYXMgZGVjaW1hbCBzdHJpbmdzLlxyXG4vLyBUaGV5J3ZlIGdyb3duIHRvIDE5IGNoYXJzICh+MS41ZTE4KSBieSAyMDI2LiBSZWplY3QgYW55dGhpbmcgdGhhdCBkb2Vzbid0XHJcbi8vIG1hdGNoIHRoaXMgc2hhcGUgXHUyMDE0IG90aGVyd2lzZSBzcHVyaW91cyBjYXJkIElEcywgY3Vyc29yIHN0cmluZ3MsIGFkIHNsb3RcclxuLy8gSURzLCBldGMuIGVuZCB1cCBpbiB0aGUgcGFydGlhbC1jYXB0dXJlIHF1ZXVlIGFuZCB0aGUgY3Jhd2wgbG9vcFxyXG4vLyBuYXZpZ2F0ZXMgdG8gaW52YWxpZCBVUkxzIHRoYXQgc2hvdyBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXHJcbmNvbnN0IFRXRUVUX0lEX1JFID0gL15cXGR7MTUsMjB9JC87XHJcblxyXG4vLyBPbmx5IG9uZSBlbmRwb2ludCBhY3R1YWxseSBleHBvc2VzIHRoZSBmYWlsdXJlIG1vZGUgdGhlIHBhcnRpYWwtY2FwdHVyZVxyXG4vLyBxdWV1ZSBleGlzdHMgZm9yIFx1MjAxNCB0aGUgTWVkaWEgdGFiJ3MgYFVzZXJNZWRpYWAgcXVlcnkgcmV0dXJuaW5nXHJcbi8vIHRodW1ibmFpbC1vbmx5IGVudHJpZXMgd2l0aG91dCBhIHBvcHVsYXRlZCBhdXRob3IgYmxvY2suIEV2ZXJ5IG90aGVyXHJcbi8vIGVuZHBvaW50IHRoYXQgaGFuZHMgdXMgYSBgVHdlZXRgIHNoYXBlIGdpdmVzIHVzIHRoZSBmdWxsIGVudHJ5OyBpZlxyXG4vLyBgYnVpbGRUd2VldGAgZmFpbHMgdGhlcmUgaXQncyBhIHJlYWwgZXJyb3IsIG5vdCBcImdvIHJlLWZldGNoIHRoaXNcIi5cclxuLy8gUmVzdHJpY3RpbmcgcGFydGlhbC1pZCBlbWlzc2lvbiB0byBVc2VyTWVkaWEgc3RvcHMgdGhlIGZsb29kcyBvZlxyXG4vLyBmYWxzZSBwb3NpdGl2ZXMgcmVwb3J0ZWQgb24gUmVwbGllcyAvIFR3ZWV0RGV0YWlsIC8gU2VhcmNoVGltZWxpbmUuXHJcbmNvbnN0IFBBUlRJQUxfT0tfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJNZWRpYSddKTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemUocGF5bG9hZDogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogTm9ybWFsaXplUmVzdWx0IHtcclxuICBjb25zdCByYXdUd2VldHMgPSBjb2xsZWN0VHdlZXRzKHBheWxvYWQpO1xyXG4gIGNvbnN0IHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSA9IFtdO1xyXG4gIGNvbnN0IHVuYXZhaWxhYmxlVHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W10gPSBbXTtcclxuICBjb25zdCBvYnNlcnZlZDogc3RyaW5nW10gPSBbXTtcclxuICBjb25zdCBidWlsdCA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGNvbnN0IHBhcnRpYWxNYXAgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nIHwgbnVsbD4oKTtcclxuICBjb25zdCBjb2xsZWN0UGFydGlhbHMgPSBQQVJUSUFMX09LX0VORFBPSU5UUy5oYXMoY3R4LmVuZHBvaW50KTtcclxuICBmb3IgKGNvbnN0IHJhdyBvZiByYXdUd2VldHMpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHVuYXZhaWxhYmxlID0gcGlja1VuYXZhaWxhYmxlVHdlZXQocmF3LCBjdHgpO1xyXG4gICAgICBpZiAodW5hdmFpbGFibGUpIHtcclxuICAgICAgICB1bmF2YWlsYWJsZVR3ZWV0cy5wdXNoKHVuYXZhaWxhYmxlKTtcclxuICAgICAgICBvYnNlcnZlZC5wdXNoKHVuYXZhaWxhYmxlLnR3ZWV0X2lkKTtcclxuICAgICAgICBidWlsdC5hZGQodW5hdmFpbGFibGUudHdlZXRfaWQpO1xyXG4gICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IHQgPSBidWlsZFR3ZWV0KHJhdywgY3R4KTtcclxuICAgICAgaWYgKCF0KSB7XHJcbiAgICAgICAgaWYgKGNvbGxlY3RQYXJ0aWFscykge1xyXG4gICAgICAgICAgLy8gT25seSBlbnF1ZXVlIHJlYWwtdHdlZXQgc2hlbGxzIHdpdGggYSB0cnVzdHdvcnRoeSBoYW5kbGUgKG5vdFxyXG4gICAgICAgICAgLy8gdG9tYnN0b25lcywgc3RyaXBwZWQgbm9kZXMgbGFja2luZyBhIGxlZ2FjeSBibG9jaywgZ2FyYmFnZSBJRHMsXHJcbiAgICAgICAgICAvLyBvciBJRHMgdGhhdCB3b3VsZCByZXF1aXJlIGd1ZXNzaW5nIHRoZSBhdXRob3IgZnJvbSB0aGUgcGFnZSkuXHJcbiAgICAgICAgICBjb25zdCBwYXJ0aWFsID0gcGlja1BhcnRpYWwocmF3KTtcclxuICAgICAgICAgIGlmIChwYXJ0aWFsKSBwYXJ0aWFsTWFwLnNldChwYXJ0aWFsLnR3ZWV0X2lkLCBwYXJ0aWFsLmhpbnRfaGFuZGxlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29udGludWU7XHJcbiAgICAgIH1cclxuICAgICAgb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcclxuICAgICAgYnVpbHQuYWRkKHQudHdlZXRfaWQpO1xyXG4gICAgICBpZiAoY3R4LmFsbG93ZWRIYW5kbGVzLnNpemUgPT09IDAgfHwgY3R4LmFsbG93ZWRIYW5kbGVzLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSB7XHJcbiAgICAgICAgdHdlZXRzLnB1c2godCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBPbmUgYmFkIGVudHJ5IHNob3VsZG4ndCB0YWtlIGRvd24gdGhlIHdob2xlIGJhdGNoLlxyXG4gICAgfVxyXG4gIH1cclxuICAvLyBBbnl0aGluZyB0aGF0IGVuZGVkIHVwIGluIHBhcnRpYWxNYXAgYnV0IEFMU08gY2FtZSBiYWNrIGFzIGEgYnVpbHRcclxuICAvLyB0d2VldCAoZGlmZmVyZW50IHdhbGtlciBwYXNzLCBzYW1lIGlkKSBpc24ndCBhY3R1YWxseSBwYXJ0aWFsLlxyXG4gIGNvbnN0IHBhcnRpYWxfaWRzOiBBcnJheTx7IHR3ZWV0X2lkOiBzdHJpbmc7IGhpbnRfaGFuZGxlOiBzdHJpbmcgfCBudWxsIH0+ID0gW107XHJcbiAgZm9yIChjb25zdCBbaWQsIGhpbnRdIG9mIHBhcnRpYWxNYXApIHtcclxuICAgIGlmIChidWlsdC5oYXMoaWQpKSBjb250aW51ZTtcclxuICAgIHBhcnRpYWxfaWRzLnB1c2goeyB0d2VldF9pZDogaWQsIGhpbnRfaGFuZGxlOiBoaW50IH0pO1xyXG4gIH1cclxuICByZXR1cm4geyB0d2VldHMsIG9ic2VydmVkX2lkczogb2JzZXJ2ZWQsIHVuYXZhaWxhYmxlX3R3ZWV0czogdW5hdmFpbGFibGVUd2VldHMsIHBhcnRpYWxfaWRzIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tVbmF2YWlsYWJsZVR3ZWV0KG5vZGU6IHVua25vd24sIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IFVuYXZhaWxhYmxlVHdlZXQgfCBudWxsIHtcclxuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIGlmIChuLl9fdHlwZW5hbWUgIT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCB0d2VldElkID1cclxuICAgIHN0ck9yTnVsbChuLnJlc3RfaWQpID8/XHJcbiAgICBwaWNrVHdlZXRJZEZyb21VcmxzKG5vZGUpID8/XHJcbiAgICAoY3R4LnNvdXJjZVVybCA/IHR3ZWV0SWRGcm9tVHdlZXRVcmwoY3R4LnNvdXJjZVVybCkgOiBudWxsKTtcclxuICBpZiAoIXR3ZWV0SWQgfHwgIVRXRUVUX0lEX1JFLnRlc3QodHdlZXRJZCkpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCB1bmF2YWlsYWJsZVRleHQgPSBwaWNrVG9tYnN0b25lVGV4dChub2RlKTtcclxuICByZXR1cm4ge1xyXG4gICAgdHdlZXRfaWQ6IHR3ZWV0SWQsXHJcbiAgICBhY2NvdW50X2hhbmRsZTpcclxuICAgICAgcGlja0hhbmRsZUZyb21Ud2VldFVybHMobm9kZSwgdHdlZXRJZCkgPz9cclxuICAgICAgKGN0eC5zb3VyY2VVcmwgPyBoYW5kbGVGcm9tVHdlZXRVcmwoY3R4LnNvdXJjZVVybCwgdHdlZXRJZCkgOiBudWxsKSxcclxuICAgIHVuYXZhaWxhYmxlX2RldGVjdGVkX2F0OiBjdHguY2FwdHVyZWRBdCxcclxuICAgIHVuYXZhaWxhYmxlX3JlYXNvbjogY2xhc3NpZnlVbmF2YWlsYWJsZVJlYXNvbih1bmF2YWlsYWJsZVRleHQpLFxyXG4gICAgdW5hdmFpbGFibGVfdGV4dDogdW5hdmFpbGFibGVUZXh0LFxyXG4gICAgdW5hdmFpbGFibGVfc291cmNlX3VybDogY3R4LnNvdXJjZVVybCA/PyBudWxsLFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tUd2VldElkRnJvbVVybHMobm9kZTogdW5rbm93bik6IHN0cmluZyB8IG51bGwge1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgY3VyID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgY29uc3QgaWQgPSB0d2VldElkRnJvbVR3ZWV0VXJsKGN1cik7XHJcbiAgICAgIGlmIChpZCkgcmV0dXJuIGlkO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHNlZW4uaGFzKGN1ciBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgY3VyKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHR3ZWV0SWRGcm9tVHdlZXRVcmwocmF3VXJsOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChyYXdVcmwsIFRXRUVUX1VSTF9QUkVGSVgpO1xyXG4gICAgaWYgKHVybC5ob3N0bmFtZSAhPT0gJ3guY29tJyAmJiB1cmwuaG9zdG5hbWUgIT09ICd0d2l0dGVyLmNvbScpIHJldHVybiBudWxsO1xyXG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC9bQS1aYS16MC05X117MSwxNX1cXC9zdGF0dXNcXC8oXFxkezE1LDIwfSkoPzpcXC98JCkvKTtcclxuICAgIHJldHVybiBtYXRjaD8uWzFdID8/IG51bGw7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tUb21ic3RvbmVUZXh0KG5vZGU6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcclxuICBjb25zdCBzdHJpbmdzOiBzdHJpbmdbXSA9IFtdO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgY3VyID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgY29uc3QgdHJpbW1lZCA9IGN1ci50cmltKCk7XHJcbiAgICAgIGlmIChcclxuICAgICAgICB0cmltbWVkLmxlbmd0aCA+PSA0ICYmXHJcbiAgICAgICAgIXRyaW1tZWQuc3RhcnRzV2l0aCgnaHR0cDovLycpICYmXHJcbiAgICAgICAgIXRyaW1tZWQuc3RhcnRzV2l0aCgnaHR0cHM6Ly8nKVxyXG4gICAgICApIHtcclxuICAgICAgICBzdHJpbmdzLnB1c2godHJpbW1lZCk7XHJcbiAgICAgIH1cclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAoY3VyID09PSBudWxsIHx8IHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSBjb250aW51ZTtcclxuICAgIGlmIChzZWVuLmhhcyhjdXIgYXMgb2JqZWN0KSkgY29udGludWU7XHJcbiAgICBzZWVuLmFkZChjdXIgYXMgb2JqZWN0KTtcclxuICAgIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIGN1cikgc3RhY2sucHVzaCh2KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IHByZWZlcnJlZCA9IHN0cmluZ3MuZmluZCgocykgPT5cclxuICAgIC9cXGIoY29weXJpZ2h0fGRtY2F8dW5hdmFpbGFibGV8d2l0aGhlbGR8cmVtb3ZlZHxkZWxldGVkfHZpb2xhdHxzdXNwZW5kZWQpXFxiL2kudGVzdChzKVxyXG4gICk7XHJcbiAgcmV0dXJuIHByZWZlcnJlZCA/PyBzdHJpbmdzWzBdID8/IG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNsYXNzaWZ5VW5hdmFpbGFibGVSZWFzb24odGV4dDogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xyXG4gIGlmICghdGV4dCkgcmV0dXJuIG51bGw7XHJcbiAgaWYgKC9cXGIoY29weXJpZ2h0fGRtY2EpXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICdjb3B5cmlnaHQnO1xyXG4gIGlmICgvXFxid2l0aGhlbGRcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3dpdGhoZWxkJztcclxuICBpZiAoL1xcYmRlbGV0ZWR8cmVtb3ZlZFxcYi9pLnRlc3QodGV4dCkpIHJldHVybiAncmVtb3ZlZCc7XHJcbiAgaWYgKC9cXGJzdXNwZW5kZWRcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3N1c3BlbmRlZCc7XHJcbiAgaWYgKC9cXGJ1bmF2YWlsYWJsZXxub3QgYXZhaWxhYmxlXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICd1bmF2YWlsYWJsZSc7XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tQYXJ0aWFsKG5vZGU6IHVua25vd24pOiB7IHR3ZWV0X2lkOiBzdHJpbmc7IGhpbnRfaGFuZGxlOiBzdHJpbmcgfCBudWxsIH0gfCBudWxsIHtcclxuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIC8vIERlbGV0ZWQgdHdlZXRzIHN1cmZhY2UgYXMgVHdlZXRUb21ic3RvbmUgXHUyMDE0IHRoZXJlJ3Mgbm90aGluZyB0byByZWZldGNoLFxyXG4gIC8vIHNraXAgdGhlbSBvciB0aGUgY3Jhd2wgbG9vcCB3aWxsIHNwaW4gb24gXCJ0aGlzIHBhZ2UgZG9lc24ndCBleGlzdFwiLlxyXG4gIGlmIChuLl9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xyXG4gIC8vIFJlcXVpcmUgYSByZWNvZ25pemVkIFR3ZWV0IHR5cGVuYW1lIE9SIGEgbGVnYWN5IGJsb2NrLiBDdXJzb3JzLCBhZHMsXHJcbiAgLy8gbW9kdWxlIGhlYWRlcnMsIGFuZCB0aGUgbGlrZSBnZXQgcmVqZWN0ZWQgaGVyZS5cclxuICBjb25zdCB0biA9IG4uX190eXBlbmFtZTtcclxuICBpZiAodG4gIT09ICdUd2VldCcgJiYgdG4gIT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgJiYgIW9iaihuLmxlZ2FjeSkpIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuICBjb25zdCByZXN0SWQgPVxyXG4gICAgKHR5cGVvZiBuLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIG4ucmVzdF9pZCkgfHxcclxuICAgICh0eXBlb2Ygb2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0ID09PSAnb2JqZWN0JyAmJlxyXG4gICAgICAob2JqKG9iaihuLnR3ZWV0X3Jlc3VsdCk/LnJlc3VsdCk/LnJlc3RfaWQgYXMgc3RyaW5nKSk7XHJcbiAgaWYgKHR5cGVvZiByZXN0SWQgIT09ICdzdHJpbmcnIHx8ICFUV0VFVF9JRF9SRS50ZXN0KHJlc3RJZCkpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IGhpbnRIYW5kbGUgPSBwaWNrSGludEhhbmRsZShub2RlLCByZXN0SWQpO1xyXG4gIGlmICghaGludEhhbmRsZSkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIHsgdHdlZXRfaWQ6IHJlc3RJZCwgaGludF9oYW5kbGU6IGhpbnRIYW5kbGUgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gcGlja0hpbnRIYW5kbGUobm9kZTogdW5rbm93biwgdHdlZXRJZDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JyB8fCBub2RlID09PSBudWxsKSByZXR1cm4gbnVsbDtcclxuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihvYmoobi5jb3JlKT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcclxuICByZXR1cm4gKFxyXG4gICAgc3RyT3JOdWxsKG9iaih1c2VyUmVzdWx0Py5jb3JlKT8uc2NyZWVuX25hbWUpID8/XHJcbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKG9iaihuLmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgcGlja0hhbmRsZUZyb21Ud2VldFVybHMobm9kZSwgdHdlZXRJZClcclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlOiB1bmtub3duLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xyXG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XHJcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IGN1ciA9IHN0YWNrLnBvcCgpO1xyXG4gICAgaWYgKHR5cGVvZiBjdXIgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgIGNvbnN0IGhhbmRsZSA9IGhhbmRsZUZyb21Ud2VldFVybChjdXIsIHR3ZWV0SWQpO1xyXG4gICAgICBpZiAoaGFuZGxlKSByZXR1cm4gaGFuZGxlO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHNlZW4uaGFzKGN1ciBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgY3VyKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGhhbmRsZUZyb21Ud2VldFVybChyYXdVcmw6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmF3VXJsLCBUV0VFVF9VUkxfUFJFRklYKTtcclxuICAgIGlmICh1cmwuaG9zdG5hbWUgIT09ICd4LmNvbScgJiYgdXJsLmhvc3RuYW1lICE9PSAndHdpdHRlci5jb20nKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IG1hdGNoID0gdXJsLnBhdGhuYW1lLm1hdGNoKC9eXFwvKFtBLVphLXowLTlfXXsxLDE1fSlcXC9zdGF0dXNcXC8oXFxkezE1LDIwfSkoPzpcXC98JCkvKTtcclxuICAgIGlmICghbWF0Y2ggfHwgbWF0Y2hbMl0gIT09IHR3ZWV0SWQpIHJldHVybiBudWxsO1xyXG4gICAgcmV0dXJuIG1hdGNoWzFdID8/IG51bGw7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNvbGxlY3RUd2VldHMob2JqOiB1bmtub3duKTogdW5rbm93bltdIHtcclxuICAvLyBXYWxrIHRoZSByZXNwb25zZSB0cmVlIGdhdGhlcmluZyBldmVyeXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIHR3ZWV0XHJcbiAgLy8gcmVzdWx0LiBXZSBsb29rIGZvciBub2RlcyBzaGFwZWQgbGlrZTpcclxuICAvLyAgIHsgX190eXBlbmFtZT86ICdUd2VldCd8J1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJywgcmVzdF9pZCwgbGVnYWN5IH1cclxuICAvLyBhbmQgdW53cmFwIHZpc2liaWxpdHkgd3JhcHBlcnMuXHJcbiAgY29uc3Qgb3V0OiB1bmtub3duW10gPSBbXTtcclxuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xyXG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbb2JqXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3Qgbm9kZSA9IHN0YWNrLnBvcCgpO1xyXG4gICAgaWYgKG5vZGUgPT09IG51bGwgfHwgbm9kZSA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcclxuICAgIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHNlZW4uaGFzKG5vZGUgYXMgb2JqZWN0KSkgY29udGludWU7XHJcbiAgICBzZWVuLmFkZChub2RlIGFzIG9iamVjdCk7XHJcblxyXG4gICAgaWYgKGxvb2tzTGlrZVR3ZWV0KG5vZGUpKSB7XHJcbiAgICAgIG91dC5wdXNoKHVud3JhcFR3ZWV0KG5vZGUpKTtcclxuICAgIH1cclxuICAgIGlmIChBcnJheS5pc0FycmF5KG5vZGUpKSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBub2RlKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMobm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBvdXQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGxvb2tzTGlrZVR3ZWV0KG5vZGU6IHVua25vd24pOiBub2RlIGlzIFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcclxuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICBjb25zdCB0eXBlbmFtZSA9IG4uX190eXBlbmFtZTtcclxuICBpZiAoXHJcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0JyB8fFxyXG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgfHxcclxuICAgIHR5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnXHJcbiAgKSB7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbiAgLy8gU29tZSBlbnRyaWVzIGxhY2sgX190eXBlbmFtZSBidXQgc3RpbGwgY2FycnkgbGVnYWN5ICsgcmVzdF9pZCArIGNvcmUuXHJcbiAgcmV0dXJuIHR5cGVvZiBuLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBuLmxlZ2FjeSA9PT0gJ29iamVjdCcgJiYgbi5sZWdhY3kgIT09IG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHVud3JhcFR3ZWV0KG5vZGU6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xyXG4gIGlmIChub2RlLl9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgJiYgdHlwZW9mIG5vZGUudHdlZXQgPT09ICdvYmplY3QnKSB7XHJcbiAgICByZXR1cm4gbm9kZS50d2VldCBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICB9XHJcbiAgcmV0dXJuIG5vZGU7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGJ1aWxkVHdlZXQocmF3OiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBDYW5vbmljYWxUd2VldCB8IG51bGwge1xyXG4gIGlmICh0eXBlb2YgcmF3ICE9PSAnb2JqZWN0JyB8fCByYXcgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IHQgPSByYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcblxyXG4gIGlmICh0Ll9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCByZXN0SWQgPSBzdHJPck51bGwodC5yZXN0X2lkKTtcclxuICAvLyBgbGVnYWN5YCBpcyBzdGlsbCB3aGVyZSBtb3N0IGVuZ2FnZW1lbnQgLyBlbnRpdGllcyBsaXZlIGluIDIwMjYtZXJhIFhcclxuICAvLyBwYXlsb2FkcywgYnV0IGFzIG9mIHJlY2VudCBzY2hlbWEgbWlncmF0aW9ucyBzZXZlcmFsIGZpZWxkcyBwcmV2aW91c2x5XHJcbiAgLy8gdGhlcmUgKG5vdGFibHkgdGhlIGF1dGhvciBoYW5kbGUpIGhhdmUgbW92ZWQgdG8gc2libGluZyBsb2NhdGlvbnMuIFdlXHJcbiAgLy8gdG9sZXJhdGUgYSBtaXNzaW5nIGxlZ2FjeSBoZXJlIGFuZCBsb29rIHVwIGV2ZXJ5dGhpbmcgdmlhIGZhbGxiYWNrcy5cclxuICBjb25zdCBsZWdhY3kgPSBvYmoodC5sZWdhY3kpID8/IHt9O1xyXG4gIGlmICghcmVzdElkKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3QgY29yZSA9IG9iaih0LmNvcmUpO1xyXG4gIGNvbnN0IHVzZXJSZXN1bHQgPSBvYmoob2JqKGNvcmU/LnVzZXJfcmVzdWx0cyk/LnJlc3VsdCk7XHJcbiAgLy8gQXV0aG9yIGhhbmRsZTogdHJ5IHRoZSBuZXcgYGNvcmVgIHN1YnN0cnVjdHVyZSBmaXJzdCAoY3VycmVudCBYIHNoYXBlKSxcclxuICAvLyB0aGVuIHRoZSBsZWdhY3kgYGxlZ2FjeS5zY3JlZW5fbmFtZWAsIHRoZW4gYSBjb3VwbGUgb2Ygb2xkZXIgdmFyaWFudHMuXHJcbiAgY29uc3QgdXNlckNvcmVOZXcgPSBvYmoodXNlclJlc3VsdD8uY29yZSk7XHJcbiAgY29uc3QgdXNlckxlZ2FjeSA9IG9iaih1c2VyUmVzdWx0Py5sZWdhY3kpO1xyXG4gIGNvbnN0IHVzZXJBdmF0YXJPYmogPSBvYmoodXNlclJlc3VsdD8uYXZhdGFyKTtcclxuICBjb25zdCBoYW5kbGUgPVxyXG4gICAgc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5zY3JlZW5fbmFtZSkgPz9cclxuICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5zY3JlZW5fbmFtZSkgPz9cclxuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5zY3JlZW5fbmFtZSkgPz9cclxuICAgIHN0ck9yTnVsbChsZWdhY3kuc2NyZWVuX25hbWUpO1xyXG4gIGNvbnN0IGFjY291bnRJZCA9XHJcbiAgICBzdHJPck51bGwodXNlclJlc3VsdD8ucmVzdF9pZCkgPz9cclxuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5pZF9zdHIpID8/XHJcbiAgICBzdHJPck51bGwobGVnYWN5LnVzZXJfaWRfc3RyKTtcclxuICBpZiAoIWhhbmRsZSB8fCAhYWNjb3VudElkKSByZXR1cm4gbnVsbDtcclxuICAvLyBBdXRob3Igc25hcHNob3QuIERpc3BsYXkgbmFtZSArIGF2YXRhciBtb3ZlZCBiZXR3ZWVuIGBsZWdhY3lgIGFuZCB0aGVcclxuICAvLyBuZXcgYGNvcmVgIHN1YnN0cnVjdHVyZSBvdmVyIHRpbWU7IHRoZSByZXN0ICh2ZXJpZmljYXRpb24sIGZvbGxvd2VyXHJcbiAgLy8gY291bnRzLCBhY2NvdW50X2NyZWF0ZWRfYXQpIGlzIHN0aWxsIGluIGBsZWdhY3lgLiBXZSBzbmFwc2hvdCB0aGVcclxuICAvLyB3aG9sZSBVc2VyU25hcHNob3QgcGVyIHR3ZWV0IGJlY2F1c2UgdGhlc2UgdmFsdWVzIGRyaWZ0IG92ZXIgdGltZVxyXG4gIC8vIGFuZCB0aGUgYXQtY2FwdHVyZSBzdGF0ZSBpcyB0aGUgb25seSByZWxpYWJsZSByZWNvcmQuXHJcbiAgY29uc3QgYXV0aG9yID0gZXh0cmFjdFVzZXJTbmFwc2hvdCh1c2VyUmVzdWx0LCB1c2VyQ29yZU5ldywgdXNlckxlZ2FjeSwgdXNlckF2YXRhck9iaik7XHJcblxyXG4gIGNvbnN0IG5vdGVUd2VldCA9IG9iaihvYmoob2JqKHQubm90ZV90d2VldCk/Lm5vdGVfdHdlZXRfcmVzdWx0cyk/LnJlc3VsdCk7XHJcbiAgY29uc3QgdGV4dEZyb21Ob3RlID0gc3RyT3JOdWxsKG5vdGVUd2VldD8udGV4dCk7XHJcbiAgY29uc3QgdGV4dEZyb21MZWdhY3kgPSBzdHJPck51bGwobGVnYWN5LmZ1bGxfdGV4dCkgPz8gJyc7XHJcbiAgY29uc3QgdGV4dCA9IHRleHRGcm9tTm90ZSA/PyB0ZXh0RnJvbUxlZ2FjeTtcclxuICBjb25zdCBpc1RydW5jYXRlZCA9IGRldGVjdFRydW5jYXRpb24obm90ZVR3ZWV0LCBsZWdhY3ksIHRleHRGcm9tTGVnYWN5KTtcclxuICBjb25zdCBjb21tdW5pdHlOb3RlID0gZXh0cmFjdENvbW11bml0eU5vdGUodCwgbGVnYWN5LCBjdHguY2FwdHVyZWRBdCk7XHJcblxyXG4gIGNvbnN0IGVudGl0aWVzID0gb2JqKGxlZ2FjeS5lbnRpdGllcykgPz8ge307XHJcbiAgY29uc3QgZW50aXRpZXNGcm9tTm90ZSA9IG9iaihub3RlVHdlZXQ/LmVudGl0eV9zZXQpO1xyXG4gIGNvbnN0IGhhc2h0YWdzID0gZXh0cmFjdEhhc2h0YWdzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xyXG4gIGNvbnN0IG1lbnRpb25zID0gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xyXG4gIGNvbnN0IHVybHMgPSBleHRyYWN0VXJscyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcclxuICBjb25zdCBtZWRpYSA9IGV4dHJhY3RNZWRpYShsZWdhY3kpO1xyXG5cclxuICBjb25zdCB0d2VldFR5cGUgPSBjbGFzc2lmeVR3ZWV0VHlwZSh0LCBsZWdhY3kpO1xyXG5cclxuICAvLyBwb3N0ZWRfYXQ6IGxlZ2FjeS5jcmVhdGVkX2F0IHJlbWFpbnMgdGhlIGNhbm9uaWNhbCBsb2NhdGlvbjsgaWYgdGhhdCdzXHJcbiAgLy8gbWlzc2luZyBpbiBhIGZ1dHVyZSBzY2hlbWEgd2UgZmFsbCBiYWNrIHRvIHRvcC1sZXZlbCBjcmVhdGVkX2F0LlxyXG4gIGNvbnN0IHBvc3RlZEF0ID1cclxuICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKGxlZ2FjeS5jcmVhdGVkX2F0KSkgPz8gcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodC5jcmVhdGVkX2F0KSk7XHJcbiAgaWYgKCFwb3N0ZWRBdCkgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IHZpZXdzID0gb2JqKHQudmlld3MpO1xyXG4gIGNvbnN0IHZpZXdDb3VudCA9IG51bU9yTnVsbCh2aWV3cz8uY291bnQpID8/IG51bU9yTnVsbChzdHJPck51bGwodmlld3M/LmNvdW50KSk7XHJcblxyXG4gIGNvbnN0IGNhcmQgPSBleHRyYWN0Q2FyZCh0KTtcclxuICBjb25zdCBwbGFjZSA9IG9iaihsZWdhY3kucGxhY2UpO1xyXG5cclxuICBjb25zdCB0d2VldDogQ2Fub25pY2FsVHdlZXQgPSB7XHJcbiAgICB0d2VldF9pZDogcmVzdElkLFxyXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcclxuICAgIGFjY291bnRfaWQ6IGFjY291bnRJZCxcclxuICAgIHBvc3RlZF9hdDogcG9zdGVkQXQsXHJcbiAgICBmaXJzdF9jYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXHJcbiAgICBsYXN0X3NlZW5fYXQ6IGN0eC5jYXB0dXJlZEF0LFxyXG4gICAgZGVsZXRpb25fZGV0ZWN0ZWRfYXQ6IG51bGwsXHJcbiAgICB1bmF2YWlsYWJsZV9kZXRlY3RlZF9hdDogbnVsbCxcclxuICAgIHVuYXZhaWxhYmxlX3JlYXNvbjogbnVsbCxcclxuICAgIHVuYXZhaWxhYmxlX3RleHQ6IG51bGwsXHJcbiAgICB1bmF2YWlsYWJsZV9zb3VyY2VfdXJsOiBudWxsLFxyXG4gICAgdHdlZXRfdXJsOiBgJHtUV0VFVF9VUkxfUFJFRklYfS8ke2hhbmRsZX0vc3RhdHVzLyR7cmVzdElkfWAsXHJcbiAgICB0d2VldF90eXBlOiB0d2VldFR5cGUsXHJcbiAgICBjb252ZXJzYXRpb25faWQ6IHN0ck9yTnVsbChsZWdhY3kuY29udmVyc2F0aW9uX2lkX3N0ciksXHJcbiAgICByZXBseV90b190d2VldF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zdGF0dXNfaWRfc3RyKSxcclxuICAgIHJlcGx5X3RvX2FjY291bnQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc2NyZWVuX25hbWUpLFxyXG4gICAgcmVwbHlfdG9fYWNjb3VudF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b191c2VyX2lkX3N0ciksXHJcbiAgICBxdW90ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChsZWdhY3kucXVvdGVkX3N0YXR1c19pZF9zdHIpLFxyXG4gICAgcmV0d2VldGVkX3R3ZWV0X2lkOiBzdHJPck51bGwoXHJcbiAgICAgIG9iaihvYmoobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCA/P1xyXG4gICAgICAgIChsZWdhY3kgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLnJldHdlZXRlZF9zdGF0dXNfaWRfc3RyXHJcbiAgICApLFxyXG4gICAgdGV4dCxcclxuICAgIHRleHRfcmVzb2x2ZWQ6IHJlc29sdmVTaG9ydFVybHModGV4dCwgdXJscyksXHJcbiAgICBsYW5nOiBzdHJPck51bGwobGVnYWN5LmxhbmcpLFxyXG4gICAgcG9zc2libHlfc2Vuc2l0aXZlOiBib29sT3JOdWxsKGxlZ2FjeS5wb3NzaWJseV9zZW5zaXRpdmUpLFxyXG4gICAgc291cmNlOiBzdHJPck51bGwobGVnYWN5LnNvdXJjZSkgPz8gc3RyT3JOdWxsKHQuc291cmNlKSxcclxuICAgIHBsYWNlX2Z1bGxfbmFtZTogc3RyT3JOdWxsKHBsYWNlPy5mdWxsX25hbWUpLFxyXG4gICAgaGFzaHRhZ3MsXHJcbiAgICBtZW50aW9ucyxcclxuICAgIHVybHMsXHJcbiAgICBjYXJkLFxyXG4gICAgbWVkaWEsXHJcbiAgICBsaWtlX2NvdW50OiBudW1Pclplcm8obGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcclxuICAgIHJldHdlZXRfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXHJcbiAgICByZXBseV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXBseV9jb3VudCksXHJcbiAgICBxdW90ZV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5xdW90ZV9jb3VudCksXHJcbiAgICB2aWV3X2NvdW50OiB2aWV3Q291bnQsXHJcbiAgICBib29rbWFya19jb3VudDogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXHJcbiAgICBlbmdhZ2VtZW50X2hpc3Rvcnk6IFtcclxuICAgICAge1xyXG4gICAgICAgIGNhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcclxuICAgICAgICBsaWtlczogbnVtT3JaZXJvKGxlZ2FjeS5mYXZvcml0ZV9jb3VudCksXHJcbiAgICAgICAgcmV0d2VldHM6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXHJcbiAgICAgICAgcmVwbGllczogbnVtT3JaZXJvKGxlZ2FjeS5yZXBseV9jb3VudCksXHJcbiAgICAgICAgcXVvdGVzOiBudW1Pclplcm8obGVnYWN5LnF1b3RlX2NvdW50KSxcclxuICAgICAgICB2aWV3czogdmlld0NvdW50LFxyXG4gICAgICAgIGJvb2ttYXJrczogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gICAgYXV0aG9yLFxyXG4gICAgY29tbXVuaXR5X25vdGU6IGNvbW11bml0eU5vdGUsXHJcbiAgICBpc190cnVuY2F0ZWQ6IGlzVHJ1bmNhdGVkLFxyXG4gICAgd2F5YmFja191cmw6IG51bGwsXHJcbiAgICB3YXliYWNrX3N1Ym1pdHRlZF9hdDogbnVsbCxcclxuICAgIGNhcHR1cmVfc291cmNlOiAnZXh0ZW5zaW9uJyxcclxuICAgIGNhcHR1cmVfcnVuX2lkOiBjdHgucnVuSWQsXHJcbiAgICBzY2hlbWFfdmVyc2lvbjogMSxcclxuICB9O1xyXG5cclxuICByZXR1cm4gdHdlZXQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNsYXNzaWZ5VHdlZXRUeXBlKHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVHdlZXRUeXBlIHtcclxuICBpZiAobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0IHx8IGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXR3ZWV0JztcclxuICBpZiAobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpIHJldHVybiAncmVwbHknO1xyXG4gIGlmIChsZWdhY3kuaXNfcXVvdGVfc3RhdHVzID09PSB0cnVlIHx8IGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdxdW90ZSc7XHJcbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJykge1xyXG4gICAgLy8gcGFzcyB0aHJvdWdoXHJcbiAgfVxyXG4gIHJldHVybiAnb3JpZ2luYWwnO1xyXG59XHJcblxyXG5mdW5jdGlvbiBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xyXG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLmhhc2h0YWdzO1xyXG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XHJcbiAgcmV0dXJuIGFyclxyXG4gICAgLm1hcCgoaCkgPT5cclxuICAgICAgdHlwZW9mIGggPT09ICdvYmplY3QnICYmIGggJiYgJ3RleHQnIGluIGggPyBTdHJpbmcoKGggYXMgeyB0ZXh0OiB1bmtub3duIH0pLnRleHQpIDogbnVsbFxyXG4gICAgKVxyXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBleHRyYWN0TWVudGlvbnMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xyXG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLnVzZXJfbWVudGlvbnM7XHJcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcclxuICByZXR1cm4gYXJyXHJcbiAgICAubWFwKCh1KSA9PlxyXG4gICAgICB0eXBlb2YgdSA9PT0gJ29iamVjdCcgJiYgdSAmJiAnc2NyZWVuX25hbWUnIGluIHVcclxuICAgICAgICA/IFN0cmluZygodSBhcyB7IHNjcmVlbl9uYW1lOiB1bmtub3duIH0pLnNjcmVlbl9uYW1lKVxyXG4gICAgICAgIDogbnVsbFxyXG4gICAgKVxyXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBleHRyYWN0VXJscyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBVcmxFbnRpdHlbXSB7XHJcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXJscztcclxuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xyXG4gIGNvbnN0IG91dDogVXJsRW50aXR5W10gPSBbXTtcclxuICBmb3IgKGNvbnN0IHUgb2YgYXJyKSB7XHJcbiAgICBpZiAodHlwZW9mIHUgIT09ICdvYmplY3QnIHx8IHUgPT09IG51bGwpIGNvbnRpbnVlO1xyXG4gICAgY29uc3QgbyA9IHUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcbiAgICBjb25zdCBzaG9ydCA9IHN0ck9yTnVsbChvLnVybCk7XHJcbiAgICBjb25zdCBleHBhbmRlZCA9IHN0ck9yTnVsbChvLmV4cGFuZGVkX3VybCk7XHJcbiAgICBjb25zdCBkaXNwbGF5ID0gc3RyT3JOdWxsKG8uZGlzcGxheV91cmwpO1xyXG4gICAgaWYgKCFzaG9ydCB8fCAhZXhwYW5kZWQpIGNvbnRpbnVlO1xyXG4gICAgb3V0LnB1c2goeyBzaG9ydCwgZXhwYW5kZWQsIGRpc3BsYXk6IGRpc3BsYXkgPz8gZXhwYW5kZWQgfSk7XHJcbiAgfVxyXG4gIHJldHVybiBvdXQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGV4dHJhY3RNZWRpYShsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogTWVkaWFJdGVtW10ge1xyXG4gIGNvbnN0IGV4dGVuZGVkID0gb2JqKGxlZ2FjeS5leHRlbmRlZF9lbnRpdGllcyk7XHJcbiAgY29uc3QgZnJvbUV4dCA9IGV4dGVuZGVkID8gdG9BcnJheShleHRlbmRlZC5tZWRpYSkgOiBbXTtcclxuICBjb25zdCBmcm9tRW50ID0gdG9BcnJheShvYmoobGVnYWN5LmVudGl0aWVzKT8ubWVkaWEpO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBjb25zdCBtZXJnZWQgPSBbLi4uZnJvbUV4dCwgLi4uZnJvbUVudF0uZmlsdGVyKChtKSA9PiB7XHJcbiAgICBpZiAodHlwZW9mIG0gIT09ICdvYmplY3QnIHx8IG0gPT09IG51bGwpIHJldHVybiBmYWxzZTtcclxuICAgIGNvbnN0IGlkID1cclxuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5tZWRpYV9rZXkpID8/XHJcbiAgICAgIHN0ck9yTnVsbCgobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuaWRfc3RyKTtcclxuICAgIGlmICghaWQpIHJldHVybiBmYWxzZTtcclxuICAgIGlmIChzZWVuLmhhcyhpZCkpIHJldHVybiBmYWxzZTtcclxuICAgIHNlZW4uYWRkKGlkKTtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH0pO1xyXG4gIHJldHVybiBtZXJnZWQubWFwKChyYXcpID0+IGJ1aWxkTWVkaWEocmF3IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGJ1aWxkTWVkaWEobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW0ge1xyXG4gIGNvbnN0IHR5cGUgPSBzdHJPck51bGwobS50eXBlKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXTtcclxuICBjb25zdCBvcmlnaW5hbCA9IHBpY2tPcmlnaW5hbFVybChtLCB0eXBlKTtcclxuICBjb25zdCBpbmZvID0gb2JqKG0ub3JpZ2luYWxfaW5mbyk7XHJcbiAgY29uc3QgdmlkZW9JbmZvID0gb2JqKG0udmlkZW9faW5mbyk7XHJcbiAgY29uc3QgZHVyYXRpb25NcyA9IG51bU9yTnVsbCh2aWRlb0luZm8/LmR1cmF0aW9uX21pbGxpcyk7XHJcbiAgY29uc3QgYWx0VGV4dCA9IHN0ck9yTnVsbChtLmV4dF9hbHRfdGV4dCk7XHJcbiAgY29uc3QgbWVkaWFJZCA9XHJcbiAgICBzdHJPck51bGwobS5tZWRpYV9rZXkpID8/XHJcbiAgICBzdHJPck51bGwobS5pZF9zdHIpID8/XHJcbiAgICBgJHt0eXBlID8/ICdtZWRpYSd9LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMil9YDtcclxuICByZXR1cm4ge1xyXG4gICAgbWVkaWFfaWQ6IG1lZGlhSWQsXHJcbiAgICBtZWRpYV90eXBlOiAodHlwZSA/PyAncGhvdG8nKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXSxcclxuICAgIG9yaWdpbmFsX3VybDogb3JpZ2luYWwgPz8gJycsXHJcbiAgICByZWxlYXNlX2Fzc2V0X3VybDogbnVsbCxcclxuICAgIHNoYTI1NjogbnVsbCxcclxuICAgIGJ5dGVzOiBudWxsLFxyXG4gICAgZHVyYXRpb25fc2VjOiBkdXJhdGlvbk1zICE9PSBudWxsID8gZHVyYXRpb25NcyAvIDEwMDAgOiBudWxsLFxyXG4gICAgd2lkdGg6IG51bU9yTnVsbChpbmZvPy53aWR0aCksXHJcbiAgICBoZWlnaHQ6IG51bU9yTnVsbChpbmZvPy5oZWlnaHQpLFxyXG4gICAgYWx0X3RleHQ6IGFsdFRleHQsXHJcbiAgICBhcmNoaXZlX3N0YXR1czogJ3BlbmRpbmcnLFxyXG4gICAgYXJjaGl2ZV9hdHRlbXB0czogMCxcclxuICAgIGxhc3RfYXR0ZW1wdF9hdDogbnVsbCxcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBwaWNrT3JpZ2luYWxVcmwobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHR5cGU6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAodHlwZSA9PT0gJ3Bob3RvJykgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcykgPz8gc3RyT3JOdWxsKG0ubWVkaWFfdXJsKTtcclxuICBjb25zdCB2YXJpYW50cyA9IHRvQXJyYXkob2JqKG0udmlkZW9faW5mbyk/LnZhcmlhbnRzKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPltdO1xyXG4gIGlmICh2YXJpYW50cy5sZW5ndGggPT09IDApIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpO1xyXG4gIC8vIEhpZ2hlc3QtYml0cmF0ZSBtcDQuXHJcbiAgbGV0IGJlc3Q6IHsgdXJsOiBzdHJpbmc7IGJpdHJhdGU6IG51bWJlciB9IHwgbnVsbCA9IG51bGw7XHJcbiAgZm9yIChjb25zdCB2IG9mIHZhcmlhbnRzKSB7XHJcbiAgICBjb25zdCBjdCA9IHN0ck9yTnVsbCh2LmNvbnRlbnRfdHlwZSk7XHJcbiAgICBjb25zdCB1cmwgPSBzdHJPck51bGwodi51cmwpO1xyXG4gICAgaWYgKCF1cmwpIGNvbnRpbnVlO1xyXG4gICAgaWYgKGN0ID09PSAndmlkZW8vbXA0Jykge1xyXG4gICAgICBjb25zdCBiciA9IG51bU9yTnVsbCh2LmJpdHJhdGUpID8/IDA7XHJcbiAgICAgIGlmICghYmVzdCB8fCBiciA+IGJlc3QuYml0cmF0ZSkgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiBiciB9O1xyXG4gICAgfSBlbHNlIGlmICghYmVzdCkge1xyXG4gICAgICAvLyBGYWxsYmFjayB0byBhbnkgdmFyaWFudCBpZiBubyBtcDQgZm91bmQuXHJcbiAgICAgIGJlc3QgPSB7IHVybCwgYml0cmF0ZTogMCB9O1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gYmVzdD8udXJsID8/IG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlc29sdmVTaG9ydFVybHModGV4dDogc3RyaW5nLCB1cmxzOiBVcmxFbnRpdHlbXSk6IHN0cmluZyB7XHJcbiAgaWYgKHVybHMubGVuZ3RoID09PSAwKSByZXR1cm4gdGV4dDtcclxuICBsZXQgb3V0ID0gdGV4dDtcclxuICBmb3IgKGNvbnN0IHUgb2YgdXJscykgb3V0ID0gb3V0LnNwbGl0KHUuc2hvcnQpLmpvaW4odS5leHBhbmRlZCk7XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuZnVuY3Rpb24gcGFyc2VUd2l0dGVyRGF0ZShzOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgaWYgKCFzKSByZXR1cm4gbnVsbDtcclxuICAvLyBUd2l0dGVyIHNoaXBzIGRhdGVzIGxpa2UgXCJNb24gQXByIDEyIDE0OjIzOjAxICswMDAwIDIwMjVcIi5cclxuICBjb25zdCBkID0gbmV3IERhdGUocyk7XHJcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBudWxsO1xyXG4gIHJldHVybiBkLnRvSVNPU3RyaW5nKCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHN0ck9yTnVsbCh2OiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDAgPyB2IDogbnVsbDtcclxufVxyXG5mdW5jdGlvbiBib29sT3JOdWxsKHY6IHVua25vd24pOiBib29sZWFuIHwgbnVsbCB7XHJcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnYm9vbGVhbicgPyB2IDogbnVsbDtcclxufVxyXG5mdW5jdGlvbiBudW1Pck51bGwodjogdW5rbm93bik6IG51bWJlciB8IG51bGwge1xyXG4gIGlmICh0eXBlb2YgdiA9PT0gJ251bWJlcicgJiYgTnVtYmVyLmlzRmluaXRlKHYpKSByZXR1cm4gdjtcclxuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgbiA9IE51bWJlcih2KTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikpIHJldHVybiBuO1xyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5mdW5jdGlvbiBudW1Pclplcm8odjogdW5rbm93bik6IG51bWJlciB7XHJcbiAgcmV0dXJuIG51bU9yTnVsbCh2KSA/PyAwO1xyXG59XHJcbmZ1bmN0aW9uIG9iaih2OiB1bmtub3duKTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsIHtcclxuICByZXR1cm4gdHlwZW9mIHYgPT09ICdvYmplY3QnICYmIHYgIT09IG51bGwgJiYgIUFycmF5LmlzQXJyYXkodilcclxuICAgID8gKHYgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pXHJcbiAgICA6IG51bGw7XHJcbn1cclxuZnVuY3Rpb24gdG9BcnJheSh2OiB1bmtub3duKTogdW5rbm93bltdIHtcclxuICByZXR1cm4gQXJyYXkuaXNBcnJheSh2KSA/IHYgOiBbXTtcclxufVxyXG5cclxuLyoqXHJcbiAqIERlY2lkZSB3aGV0aGVyIGEgdHdlZXQncyBhcmNoaXZlZCBgdGV4dGAgaXMgdGhlIHRydW5jYXRlZCBoZWFkIG9mIGEgbG9uZ2VyXHJcbiAqIGJvZHkuIEEgdHJ1bmNhdGVkIHR3ZWV0IGhhcyBYJ3MgXCJTaG93IG1vcmVcIiB0LmNvIFVSTCBhcHBlbmRlZCBcdTIwMTQgdGhhdCBVUkxcclxuICogc3BlY2lmaWNhbGx5IGV4cGFuZHMgdG8gdGhlIHR3ZWV0J3Mgb3duIC9pL3dlYi9zdGF0dXMvPGlkPiBwZXJtYWxpbmssIGFuZFxyXG4gKiBpcyB0aGUgb25seSByZWxpYWJsZSBkaXN0aW5ndWlzaGluZyBmZWF0dXJlLiBQbGVudHkgb2Ygbm9ybWFsIHR3ZWV0cyBoYXZlXHJcbiAqIHRyYWlsaW5nIHQuY28gVVJMcyAobWVkaWEsIHF1b3RlcywgcmVndWxhciBsaW5rcyksIGFuZCB0aGVpclxyXG4gKiBkaXNwbGF5X3RleHRfcmFuZ2UgYWxzbyB0cmltcyBwYXN0IGZ1bGxfdGV4dC5sZW5ndGgsIHNvIHRoZSBvbGRcclxuICogXCJkaXNwbGF5X3RleHRfcmFuZ2VbMV0gPCBmdWxsX3RleHQubGVuZ3RoXCIgaGV1cmlzdGljIHdhcyBvdmVyZmxhZ2dpbmdcclxuICogZXNzZW50aWFsbHkgZXZlcnkgdHdlZXQgd2l0aCBhIGxpbmsgaW4gaXQuXHJcbiAqXHJcbiAqIFJ1bGVzOlxyXG4gKiAgIC0gbm90ZV90d2VldCBwcmVzZW50ICBcdTIxOTIgbm90IHRydW5jYXRlZCAod2UgYWxyZWFkeSBoYXZlIHRoZSBmdWxsIGJvZHkpLlxyXG4gKiAgIC0gT25lIG9mIGxlZ2FjeS5lbnRpdGllcy51cmxzIGhhcyBhbiBleHBhbmRlZF91cmwgbGlrZVxyXG4gKiAgICAgXCIuLi4vaS93ZWIvc3RhdHVzLzxpZD5cIiAgXHUyMTkyICB0cnVuY2F0ZWQuXHJcbiAqICAgLSBPdGhlcndpc2UgXHUyMTkyIG5vdCB0cnVuY2F0ZWQuXHJcbiAqXHJcbiAqIFRoZSBwcmV2aW91cyBmYWxsYmFjayAoXCJ0cmFpbGluZyB0LmNvIFVSTCArIGxlbmd0aCBcdTIyNjUgMjcwXCIpIGZsYWdnZWQgZXZlcnlcclxuICogbWVkaWEgdHdlZXQgZXhhY3RseSBhdCB0aGUgMjgwLWNoYXIgbGltaXQuIFdlIGRyb3AgaXQgZW50aXJlbHk7IHRoZSBvbmx5XHJcbiAqIGNvc3QgaXMgbWlzc2luZyBnZW51aW5lbHktdHJ1bmNhdGVkIHR3ZWV0cyB3aG9zZSBwYXlsb2FkIHdhcyBzbyBkZWdyYWRlZFxyXG4gKiBpdCBsYWNrZWQgZW50aXRpZXMgXHUyMDE0IHdoaWNoIGlzIGFsc28gd2hlcmUgdGhlIHJlZmV0Y2ggbG9vcCB3b3VsZCBmYWlsXHJcbiAqIGFueXdheSwgc28gbm90aGluZyBpcyBhY3R1YWxseSBsb3N0LlxyXG4gKi9cclxuZnVuY3Rpb24gZGV0ZWN0VHJ1bmNhdGlvbihcclxuICBub3RlVHdlZXQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcclxuICBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxyXG4gIGZ1bGxUZXh0OiBzdHJpbmdcclxuKTogYm9vbGVhbiB7XHJcbiAgaWYgKG5vdGVUd2VldCkgcmV0dXJuIGZhbHNlO1xyXG4gIGlmICghZnVsbFRleHQpIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBlbnRpdGllcyA9IG9iaihsZWdhY3kuZW50aXRpZXMpO1xyXG4gIGNvbnN0IHVybHMgPSBlbnRpdGllcyA/IGVudGl0aWVzLnVybHMgOiBudWxsO1xyXG4gIGlmIChBcnJheS5pc0FycmF5KHVybHMpKSB7XHJcbiAgICBmb3IgKGNvbnN0IHUgb2YgdXJscykge1xyXG4gICAgICBpZiAodHlwZW9mIHUgIT09ICdvYmplY3QnIHx8IHUgPT09IG51bGwpIGNvbnRpbnVlO1xyXG4gICAgICBjb25zdCBleHAgPSAodSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuZXhwYW5kZWRfdXJsO1xyXG4gICAgICAvLyBUaGUgXCJTaG93IG1vcmVcIiBsaW5rIGV4cGFuZHMgdG8gZWl0aGVyIG9mIHRoZXNlIHNlbGYtcGVybWFsaW5rXHJcbiAgICAgIC8vIHNoYXBlczogIGh0dHBzOi8veC5jb20vaS93ZWIvc3RhdHVzLzxpZD5cclxuICAgICAgLy8gICAgICAgICAgaHR0cHM6Ly90d2l0dGVyLmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxyXG4gICAgICBpZiAodHlwZW9mIGV4cCA9PT0gJ3N0cmluZycgJiYgL1xcL2lcXC93ZWJcXC9zdGF0dXNcXC9cXGQrLy50ZXN0KGV4cCkpIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGaWx0ZXIgYHR3ZWV0c2AgZG93biB0byB0aG9zZSByZWxhdGVkIHRvIGEgdHJhY2tlZCBhY2NvdW50LiBBIHR3ZWV0IGlzXHJcbiAqIFwicmVsYXRlZFwiIGlmIGFueSBvZiB0aGUgZm9sbG93aW5nIGhvbGQ6XHJcbiAqXHJcbiAqICAgLSBpdHMgYXV0aG9yIGlzIHRyYWNrZWQgKGhhbmRsZSBpbiBgdGFyZ2V0ZWRgKSxcclxuICogICAtIGl0cyBhdXRob3IgaXMgY29yZSAoaGFuZGxlIGluIGBjb3JlSGFuZGxlc2ApLCByZWdhcmRsZXNzIG9mIHdoZXJlIFhcclxuICogICAgIHN1cmZhY2VkIGl0LFxyXG4gKiAgIC0gaXQgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZSxcclxuICogICAtIGl0IHJlcGxpZXMgdG8gYSB0cmFja2VkIGFjY291bnQsXHJcbiAqICAgLSBpdCBxdW90ZXMvcmVwbGllcy10byBhIHR3ZWV0IHRoYXQncyBhbHNvIHByZXNlbnQgaW4gdGhlXHJcbiAqICAgICBiYXRjaCAqYW5kKiBhdXRob3JlZCBieSBhIHRyYWNrZWQgYWNjb3VudCAodHJhbnNpdGl2ZWx5IHJlbGF0ZWQgXHUyMDE0XHJcbiAqICAgICBjYXB0dXJlcyBxdW90ZWQvcmVwbHkgY29udGV4dCB0aGF0IGFwcGVhcnMgYXMgYSBzaWJsaW5nIG5vZGUgaW4gdGhlXHJcbiAqICAgICBzYW1lIEdyYXBoUUwgcmVzcG9uc2UpLlxyXG4gKlxyXG4gKiBOb24tY29yZSByZXR3ZWV0IHdyYXBwZXJzIGFyZSBub3Qga2VwdCBtZXJlbHkgYmVjYXVzZSB0aGV5IHJldHdlZXRlZCBhXHJcbiAqIHRyYWNrZWQvY29yZSB0d2VldC4gVGhlIHVuZGVybHlpbmcgY29yZSB0d2VldCBpcyBrZXB0IGFzIGl0cyBvd24gcm93IHdoZW5cclxuICogcHJlc2VudCBpbiB0aGUgcGF5bG9hZC5cclxuICpcclxuICogQW55dGhpbmcgZWxzZSAocmFuZG9tIHJlcGxpZXMgdW5kZXIgYSB0cmFja2VkIGFjY291bnQncyB0d2VldCwgcmFuZG9tXHJcbiAqIGF1dGhvcnMgdGhhdCBoYXBwZW4gdG8gc3VyZmFjZSBpbiBhIHRyYWNrZWQgYWNjb3VudCdzIHRocmVhZCkgaXMgZHJvcHBlZC5cclxuICogUGFzcyBhbiBlbXB0eSBgdGFyZ2V0ZWRgIHNldCB0byBkaXNhYmxlIGZpbHRlcmluZyBlbnRpcmVseS5cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBmaWx0ZXJSZWxhdGVkKFxyXG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSxcclxuICB0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPixcclxuICBjb3JlSGFuZGxlczogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxyXG4pOiBDYW5vbmljYWxUd2VldFtdIHtcclxuICBpZiAodGFyZ2V0ZWQuc2l6ZSA9PT0gMCAmJiBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm4gdHdlZXRzO1xyXG4gIC8vIEZpcnN0IHBhc3M6IHdoaWNoIHR3ZWV0IElEcyBkbyB0cmFja2VkLWF1dGhvciB0d2VldHMgcmVmZXJlbmNlICh0aGVcclxuICAvLyBcImZvcndhcmRcIiBkaXJlY3Rpb24gXHUyMDE0IHRyYWNrZWQgYWNjb3VudCBxdW90ZXMgLyBSVHMgLyByZXBsaWVzIHRvIFgpP1xyXG4gIC8vIEFuZCB3aGljaCB0d2VldCBJRHMgQVJFIHRyYWNrZWQtYXV0aG9yZWQgKHRoZSBcInJldmVyc2VcIiBkaXJlY3Rpb24gXHUyMDE0XHJcbiAgLy8gWCBxdW90ZXMgLyBSVHMgLyByZXBsaWVzIHRvIGEgdHJhY2tlZCB0d2VldCk/XHJcbiAgY29uc3QgcmVmZXJlbmNlZElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGNvbnN0IHRhcmdldGVkVHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XHJcbiAgICBpZiAoIXRhcmdldGVkLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSBjb250aW51ZTtcclxuICAgIHRhcmdldGVkVHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xyXG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnF1b3RlZF90d2VldF9pZCk7XHJcbiAgICBpZiAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucmV0d2VldGVkX3R3ZWV0X2lkKTtcclxuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnJlcGx5X3RvX3R3ZWV0X2lkKTtcclxuICB9XHJcbiAgcmV0dXJuIHR3ZWV0cy5maWx0ZXIoKHQpID0+IHtcclxuICAgIGNvbnN0IGggPSB0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCk7XHJcbiAgICBpZiAodGFyZ2V0ZWQuaGFzKGgpKSByZXR1cm4gdHJ1ZTtcclxuICAgIGlmIChjb3JlSGFuZGxlcy5oYXMoaCkpIHJldHVybiB0cnVlO1xyXG4gICAgLy8gRm9yd2FyZDogYSB0cmFja2VkLWF1dGhvciB0d2VldCBwb2ludGVkIGF0IHRoaXMgb25lLlxyXG4gICAgaWYgKHJlZmVyZW5jZWRJZHMuaGFzKHQudHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcclxuICAgIC8vIFJldmVyc2U6IHRoaXMgdHdlZXQgcXVvdGVzL3JlcGxpZXMgdG8gYSB0cmFja2VkLWF1dGhvciB0d2VldCBpbiB0aGVcclxuICAgIC8vIGJhdGNoLiBSZXZlcnNlIHJldHdlZXRzIGFyZSBqdXN0IFwibm9uLWNvcmUgYWNjb3VudCByZXR3ZWV0ZWQgY29yZVxyXG4gICAgLy8gdHdlZXRcIiB3cmFwcGVycywgYW5kIGRvIG5vdCBhZGQgY29yZSBhcmNoaXZlIHZhbHVlLlxyXG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucXVvdGVkX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XHJcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCAmJiB0YXJnZXRlZFR3ZWV0SWRzLmhhcyh0LnJlcGx5X3RvX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XHJcbiAgICAvLyBSZXBseS10by1hY2NvdW50IG9yIG1lbnRpb25zIGEgdHJhY2tlZCBoYW5kbGUuXHJcbiAgICBpZiAodC5yZXBseV90b19hY2NvdW50ICYmIHRhcmdldGVkLmhhcyh0LnJlcGx5X3RvX2FjY291bnQudG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xyXG4gICAgZm9yIChjb25zdCBtIG9mIHQubWVudGlvbnMpIHtcclxuICAgICAgaWYgKHRhcmdldGVkLmhhcyhtLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFB1bGwgdGhlIENvbW11bml0eSBOb3RlIChmb3JtZXJseSBCaXJkd2F0Y2gpIGJsb2NrIGF0dGFjaGVkIHRvIGEgdHdlZXQsIGlmXHJcbiAqIGFueS4gVGhlIHBpdm90IGNhbiBsaXZlIGF0IGB0d2VldC5sZWdhY3kuYmlyZHdhdGNoX3Bpdm90YCAob2xkZXIgc2hhcGUpIG9yXHJcbiAqIGB0d2VldC5iaXJkd2F0Y2hfcGl2b3RgIChjdXJyZW50IHNoYXBlKS4gVGhlIHN1bW1hcnkgdGV4dCBpcyB3aGF0IHJlYWRlcnNcclxuICogYWN0dWFsbHkgc2VlOyB3ZSBrZWVwIHRoZSBzdXJyb3VuZGluZyBtZXRhZGF0YSBzbyBkb3duc3RyZWFtIHRvb2xpbmcgY2FuXHJcbiAqIHRlbGwgZHJhZnRzIGFwYXJ0IGZyb20gcmF0ZWQtaGVscGZ1bCBub3Rlcy5cclxuICovXHJcbmZ1bmN0aW9uIGV4dHJhY3RDb21tdW5pdHlOb3RlKFxyXG4gIHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxyXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXHJcbiAgb2JzZXJ2ZWRBdDogc3RyaW5nXHJcbik6IENvbW11bml0eU5vdGUgfCBudWxsIHtcclxuICBjb25zdCBwaXZvdCA9IG9iaih0LmJpcmR3YXRjaF9waXZvdCkgPz8gb2JqKGxlZ2FjeS5iaXJkd2F0Y2hfcGl2b3QpO1xyXG4gIGlmICghcGl2b3QpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IHN1YnRpdGxlID0gb2JqKHBpdm90LnN1YnRpdGxlKTtcclxuICBjb25zdCBub3RlID0gb2JqKHBpdm90Lm5vdGUpO1xyXG4gIGNvbnN0IHN1bW1hcnkgPSBzdHJPck51bGwoc3VidGl0bGU/LnRleHQpO1xyXG4gIGNvbnN0IHRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnRpdGxlKTtcclxuICBjb25zdCBzaG9ydFRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnNob3J0VGl0bGUpO1xyXG4gIGNvbnN0IGRlc3RpbmF0aW9uVXJsID0gc3RyT3JOdWxsKHBpdm90LmRlc3RpbmF0aW9uVXJsKTtcclxuICBjb25zdCBub3RlSWQgPSBzdHJPck51bGwocGl2b3Qubm90ZUlkKSA/PyBzdHJPck51bGwobm90ZT8ucmVzdF9pZCk7XHJcbiAgLy8gU2tpcCBlbXB0eSBzaGVsbHMgdGhhdCBoYXZlIG5vIGFjdHVhbCBjb250ZW50LlxyXG4gIGlmICghc3VtbWFyeSAmJiAhdGl0bGUgJiYgIW5vdGVJZCkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIHtcclxuICAgIG5vdGVfaWQ6IG5vdGVJZCxcclxuICAgIHRpdGxlLFxyXG4gICAgc2hvcnRfdGl0bGU6IHNob3J0VGl0bGUsXHJcbiAgICBzdW1tYXJ5LFxyXG4gICAgZGVzdGluYXRpb25fdXJsOiBkZXN0aW5hdGlvblVybCxcclxuICAgIG9ic2VydmVkX2F0OiBvYnNlcnZlZEF0LFxyXG4gIH07XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBQdWxsIGEgcGVyLWF1dGhvciBVc2VyU25hcHNob3QgZnJvbSB0aGUgdHdlZXQncyB1c2VyX3Jlc3VsdHMgbm9kZS4gRXZlcnlcclxuICogZmllbGQgZGVmYXVsdHMgdG8gbnVsbCB3aGVuIG1pc3Npbmcgc28gdGhlIHNjaGVtYSBzdGF5cyBzdGFibGUgYWNyb3NzXHJcbiAqIHRoZSBsZWdhY3kgLyBjb3JlIHNoYXBlIG1pZ3JhdGlvbnMgWCBoYXMgYmVlbiBkb2luZy5cclxuICovXHJcbmZ1bmN0aW9uIGV4dHJhY3RVc2VyU25hcHNob3QoXHJcbiAgdXNlclJlc3VsdDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxyXG4gIHVzZXJDb3JlTmV3OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXHJcbiAgdXNlckxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxyXG4gIHVzZXJBdmF0YXJPYmo6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbFxyXG4pOiBVc2VyU25hcHNob3Qge1xyXG4gIGNvbnN0IHZlcmlmaWNhdGlvbiA9IG9iaih1c2VyUmVzdWx0Py52ZXJpZmljYXRpb24pO1xyXG4gIHJldHVybiB7XHJcbiAgICBkaXNwbGF5X25hbWU6XHJcbiAgICAgIHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8ubmFtZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/Lm5hbWUpID8/IHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5uYW1lKSxcclxuICAgIGF2YXRhcl91cmw6XHJcbiAgICAgIHN0ck9yTnVsbCh1c2VyQXZhdGFyT2JqPy5pbWFnZV91cmwpID8/XHJcbiAgICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5wcm9maWxlX2ltYWdlX3VybF9odHRwcykgPz9cclxuICAgICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzKSxcclxuICAgIHZlcmlmaWVkOiBib29sT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWQpID8/IGJvb2xPck51bGwodXNlckxlZ2FjeT8udmVyaWZpZWQpLFxyXG4gICAgaXNfYmx1ZV92ZXJpZmllZDogYm9vbE9yTnVsbCh1c2VyUmVzdWx0Py5pc19ibHVlX3ZlcmlmaWVkKSxcclxuICAgIHZlcmlmaWVkX3R5cGU6IHN0ck9yTnVsbCh2ZXJpZmljYXRpb24/LnZlcmlmaWVkX3R5cGUpID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py52ZXJpZmllZF90eXBlKSxcclxuICAgIGRlc2NyaXB0aW9uOiBzdHJPck51bGwodXNlckxlZ2FjeT8uZGVzY3JpcHRpb24pLFxyXG4gICAgbG9jYXRpb246IHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubG9jYXRpb24pPy5sb2NhdGlvbikgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmxvY2F0aW9uKSxcclxuICAgIHVybDogc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnVybCksXHJcbiAgICBmb2xsb3dlcnNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5mb2xsb3dlcnNfY291bnQpLFxyXG4gICAgZnJpZW5kc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZyaWVuZHNfY291bnQpLFxyXG4gICAgc3RhdHVzZXNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5zdGF0dXNlc19jb3VudCksXHJcbiAgICBhY2NvdW50X2NyZWF0ZWRfYXQ6XHJcbiAgICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5jcmVhdGVkX2F0KSkgPz9cclxuICAgICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodXNlckxlZ2FjeT8uY3JlYXRlZF9hdCkpLFxyXG4gICAgcHJvdGVjdGVkOiBib29sT3JOdWxsKHVzZXJMZWdhY3k/LnByb3RlY3RlZCksXHJcbiAgfTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFdhbGsgdGhlIHR3ZWV0J3MgYGNhcmQubGVnYWN5LmJpbmRpbmdfdmFsdWVzYCAoa2V5L3ZhbHVlIGFycmF5KSBpbnRvIGFcclxuICogZmxhdCBUd2VldENhcmQgd2l0aCB0aXRsZSwgZGVzY3JpcHRpb24sIGFuZCBhIHJlcHJlc2VudGF0aXZlIGltYWdlIFVSTC5cclxuICogUmV0dXJucyBudWxsIHdoZW4gdGhlIHR3ZWV0IGhhcyBubyBjYXJkLlxyXG4gKi9cclxuZnVuY3Rpb24gZXh0cmFjdENhcmQodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldENhcmQgfCBudWxsIHtcclxuICBjb25zdCBjYXJkID0gb2JqKHQuY2FyZCk7XHJcbiAgY29uc3QgY2FyZExlZ2FjeSA9IG9iaihjYXJkPy5sZWdhY3kpO1xyXG4gIGlmICghY2FyZExlZ2FjeSkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgYmluZGluZ3MgPSBjYXJkTGVnYWN5LmJpbmRpbmdfdmFsdWVzO1xyXG4gIGNvbnN0IGJ5S2V5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xyXG4gIGlmIChBcnJheS5pc0FycmF5KGJpbmRpbmdzKSkge1xyXG4gICAgZm9yIChjb25zdCBidiBvZiBiaW5kaW5ncykge1xyXG4gICAgICBpZiAodHlwZW9mIGJ2ICE9PSAnb2JqZWN0JyB8fCBidiA9PT0gbnVsbCkgY29udGludWU7XHJcbiAgICAgIGNvbnN0IG8gPSBidiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgICAgY29uc3QgayA9IHN0ck9yTnVsbChvLmtleSk7XHJcbiAgICAgIGNvbnN0IHYgPSBvYmooby52YWx1ZSk7XHJcbiAgICAgIGlmICghayB8fCAhdikgY29udGludWU7XHJcbiAgICAgIGJ5S2V5W2tdID1cclxuICAgICAgICBzdHJPck51bGwodi5zdHJpbmdfdmFsdWUpID8/XHJcbiAgICAgICAgc3RyT3JOdWxsKG9iaih2LmltYWdlX3ZhbHVlKT8udXJsKSA/P1xyXG4gICAgICAgIHN0ck9yTnVsbChvYmoodi5pbWFnZV9jb2xvcl92YWx1ZSk/LnBhbGV0dGUpO1xyXG4gICAgfVxyXG4gIH1cclxuICBjb25zdCBuYW1lID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kubmFtZSk7XHJcbiAgY29uc3QgY2FyZFVybCA9IHN0ck9yTnVsbChjYXJkTGVnYWN5LnVybCk7XHJcbiAgY29uc3QgdmVuZG9yVXJsID1cclxuICAgIHR5cGVvZiBieUtleVsndmFuaXR5X3VybCddID09PSAnc3RyaW5nJyA/IChieUtleVsndmFuaXR5X3VybCddIGFzIHN0cmluZykgOiBudWxsO1xyXG4gIGNvbnN0IHRpdGxlID0gdHlwZW9mIGJ5S2V5Wyd0aXRsZSddID09PSAnc3RyaW5nJyA/IChieUtleVsndGl0bGUnXSBhcyBzdHJpbmcpIDogbnVsbDtcclxuICBjb25zdCBkZXNjcmlwdGlvbiA9XHJcbiAgICB0eXBlb2YgYnlLZXlbJ2Rlc2NyaXB0aW9uJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5WydkZXNjcmlwdGlvbiddIGFzIHN0cmluZykgOiBudWxsO1xyXG4gIGNvbnN0IGltYWdlVXJsID1cclxuICAgICh0eXBlb2YgYnlLZXlbJ3Bob3RvX2ltYWdlX2Z1bGxfc2l6ZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xyXG4gICAgICA/IChieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxyXG4gICAgICA6IG51bGwpID8/XHJcbiAgICAodHlwZW9mIGJ5S2V5Wyd0aHVtYm5haWxfaW1hZ2Vfb3JpZ2luYWwnXSA9PT0gJ3N0cmluZydcclxuICAgICAgPyAoYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcclxuICAgICAgOiBudWxsKSA/P1xyXG4gICAgKHR5cGVvZiBieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xyXG4gICAgICA/IChieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcclxuICAgICAgOiBudWxsKTtcclxuICBpZiAoIW5hbWUgJiYgIXRpdGxlICYmICFkZXNjcmlwdGlvbiAmJiAhaW1hZ2VVcmwpIHJldHVybiBudWxsO1xyXG4gIHJldHVybiB7XHJcbiAgICBuYW1lLFxyXG4gICAgY2FyZF91cmw6IGNhcmRVcmwsXHJcbiAgICB2ZW5kb3JfdXJsOiB2ZW5kb3JVcmwsXHJcbiAgICB0aXRsZSxcclxuICAgIGRlc2NyaXB0aW9uLFxyXG4gICAgaW1hZ2VfdXJsOiBpbWFnZVVybCxcclxuICB9O1xyXG59XHJcbiIsICIvKipcclxuICogTGlnaHR3ZWlnaHQgVUxJRC1saWtlIGlkIGdlbmVyYXRvcjogMjYtY2hhcmFjdGVyIENyb2NrZm9yZCBiYXNlMzIgc3RyaW5nXHJcbiAqIG9mICh0aW1lc3RhbXBfbXMgfHwgcmFuZG9tbmVzcykuIEdvb2QgZW5vdWdoIGZvciBydW4gaWRlbnRpZmllcnMgd2l0aG91dFxyXG4gKiBwdWxsaW5nIGluIGEgcmVhbCBVTElEIGRlcGVuZGVuY3kuXHJcbiAqL1xyXG5cclxuY29uc3QgQUxQSEFCRVQgPSAnMDEyMzQ1Njc4OUFCQ0RFRkdISktNTlBRUlNUVldYWVonOyAvLyBDcm9ja2ZvcmRcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBuZXdSdW5JZCgpOiBzdHJpbmcge1xyXG4gIGNvbnN0IHRzID0gRGF0ZS5ub3coKTtcclxuICBsZXQgdHNQYXJ0ID0gJyc7XHJcbiAgbGV0IHQgPSB0cztcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IDEwOyBpKyspIHtcclxuICAgIHRzUGFydCA9IChBTFBIQUJFVFt0ICUgMzJdID8/ICcwJykgKyB0c1BhcnQ7XHJcbiAgICB0ID0gTWF0aC5mbG9vcih0IC8gMzIpO1xyXG4gIH1cclxuICBjb25zdCByYW5kID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMCkpO1xyXG4gIGxldCByYW5kUGFydCA9ICcnO1xyXG4gIGZvciAoY29uc3QgYiBvZiByYW5kKSByYW5kUGFydCArPSBBTFBIQUJFVFtiICUgMzJdID8/ICcwJztcclxuICByZXR1cm4gdHNQYXJ0ICsgcmFuZFBhcnQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzaG9ydFJ1bklkKGlkOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIHJldHVybiBpZC5zbGljZSgtOCk7XHJcbn1cclxuIiwgImltcG9ydCB0eXBlIHsgQWNjb3VudENhdGVnb3J5LCBBY2NvdW50Q29uZmlnIH0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG4vKipcclxuICogTWluaW1hbCBwYXJzZXIgZm9yIHRoZSBzdHJpY3Qgc2hhcGUgdXNlZCBieSBgY29uZmlnL2FjY291bnRzLnlhbWxgOlxyXG4gKlxyXG4gKiAgIGFjY291bnRzOlxyXG4gKiAgICAgLSBoYW5kbGU6IERIU2dvdlxyXG4gKiAgICAgICBsYWJlbDogRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eVxyXG4gKiAgICAgICBjYXRlZ29yeTogY29yZVxyXG4gKlxyXG4gKiBXZSBkZWxpYmVyYXRlbHkgZG9uJ3QgcHVsbCBpbiBhIGZ1bGwgWUFNTCBsaWJyYXJ5IFx1MjAxNCB3ZSBjb250cm9sIGJvdGggZW5kcyBvZlxyXG4gKiB0aGlzIGZpbGUsIGFuZCBhIHNtYWxsIHBhcnNlciBpcyBlYXNpZXIgdG8gYXVkaXQgdGhhbiB0aGUgYWx0ZXJuYXRpdmVzLlxyXG4gKiBVbmtub3duIGtleXMgYW5kIGNvbW1lbnRzIGFyZSB0b2xlcmF0ZWQ7IG1hbGZvcm1lZCBsaW5lcyBhcmUgc2tpcHBlZC5cclxuICpcclxuICogRW50cmllcyBtaXNzaW5nIGEgYGNhdGVnb3J5YCBkZWZhdWx0IHRvIGBjb3JlYCBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eVxyXG4gKiB3aXRoIHRoZSBwcmUtY2F0ZWdvcml6YXRpb24gZmlsZSBzaGFwZS5cclxuICovXHJcbmNvbnN0IFZBTElEX0NBVEVHT1JJRVM6IFJlYWRvbmx5U2V0PEFjY291bnRDYXRlZ29yeT4gPSBuZXcgU2V0KFtcclxuICAnY29yZScsXHJcbiAgJ2dvdmVybm1lbnQnLFxyXG4gICdvZmZpY2lhbHMnLFxyXG4gICdwdWJsaWNfZmlndXJlcycsXHJcbiAgJ3B1YmxpYycsXHJcbl0pO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQWNjb3VudHNZYW1sKHRleHQ6IHN0cmluZyk6IEFjY291bnRDb25maWdbXSB7XHJcbiAgY29uc3QgYWNjb3VudHM6IEFjY291bnRDb25maWdbXSA9IFtdO1xyXG4gIGxldCBjdXJyZW50OiBQYXJ0aWFsPEFjY291bnRDb25maWc+ID0ge307XHJcbiAgbGV0IGluQWNjb3VudHMgPSBmYWxzZTtcclxuICBjb25zdCBmbHVzaCA9ICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSB7XHJcbiAgICAgIGlmICghY3VycmVudC5jYXRlZ29yeSkgY3VycmVudC5jYXRlZ29yeSA9ICdjb3JlJztcclxuICAgICAgYWNjb3VudHMucHVzaChjdXJyZW50IGFzIEFjY291bnRDb25maWcpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgZm9yIChjb25zdCByYXdMaW5lIG9mIHRleHQuc3BsaXQoJ1xcbicpKSB7XHJcbiAgICBjb25zdCBsaW5lID0gc3RyaXBDb21tZW50cyhyYXdMaW5lKTtcclxuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gJycpIGNvbnRpbnVlO1xyXG4gICAgaWYgKC9eYWNjb3VudHNcXHMqOi8udGVzdChsaW5lKSkge1xyXG4gICAgICBpbkFjY291bnRzID0gdHJ1ZTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAoIWluQWNjb3VudHMpIGNvbnRpbnVlO1xyXG5cclxuICAgIGNvbnN0IGl0ZW1NYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqLVxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xyXG4gICAgaWYgKGl0ZW1NYXRjaCkge1xyXG4gICAgICBmbHVzaCgpO1xyXG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaXRlbU1hdGNoWzFdID8/ICcnKSB9O1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGhhbmRsZU9ubHkgPSBsaW5lLm1hdGNoKC9eXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XHJcbiAgICBpZiAoaGFuZGxlT25seSAmJiAhbGluZS5pbmNsdWRlcygnLScpKSB7XHJcbiAgICAgIGZsdXNoKCk7XHJcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShoYW5kbGVPbmx5WzFdID8/ICcnKSB9O1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGxhYmVsTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmxhYmVsXFxzKjpcXHMqKC4rKSQvKTtcclxuICAgIGlmIChsYWJlbE1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XHJcbiAgICAgIGN1cnJlbnQubGFiZWwgPSB1bnF1b3RlKGxhYmVsTWF0Y2hbMV0gPz8gJycpO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGNhdGVnb3J5TWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmNhdGVnb3J5XFxzKjpcXHMqKC4rKSQvKTtcclxuICAgIGlmIChjYXRlZ29yeU1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XHJcbiAgICAgIGNvbnN0IHJhdyA9IHVucXVvdGUoY2F0ZWdvcnlNYXRjaFsxXSA/PyAnJyk7XHJcbiAgICAgIGN1cnJlbnQuY2F0ZWdvcnkgPSBWQUxJRF9DQVRFR09SSUVTLmhhcyhyYXcgYXMgQWNjb3VudENhdGVnb3J5KVxyXG4gICAgICAgID8gKHJhdyBhcyBBY2NvdW50Q2F0ZWdvcnkpXHJcbiAgICAgICAgOiAnY29yZSc7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gIH1cclxuICBmbHVzaCgpO1xyXG4gIHJldHVybiBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuaGFuZGxlLmxlbmd0aCA+IDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdHJpcENvbW1lbnRzKGxpbmU6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgLy8gTmFpdmUgYnV0IGFkZXF1YXRlIGZvciBvdXIgZm9ybWF0OiBzdHJpcCBldmVyeXRoaW5nIGFmdGVyIGEgYCNgIHRoYXQgaXNuJ3RcclxuICAvLyBpbnNpZGUgcXVvdGVzLiBPdXIgY29uZmlnIG5ldmVyIHVzZXMgaW5saW5lIHN0cmluZ3Mgd2l0aCBgI2AuXHJcbiAgY29uc3QgaWR4ID0gbGluZS5pbmRleE9mKCcjJyk7XHJcbiAgcmV0dXJuIGlkeCA9PT0gLTEgPyBsaW5lIDogbGluZS5zbGljZSgwLCBpZHgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgY29uc3QgdHJpbW1lZCA9IHMudHJpbSgpO1xyXG4gIGlmIChcclxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoJ1wiJykgJiYgdHJpbW1lZC5lbmRzV2l0aCgnXCInKSkgfHxcclxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoXCInXCIpICYmIHRyaW1tZWQuZW5kc1dpdGgoXCInXCIpKVxyXG4gICkge1xyXG4gICAgcmV0dXJuIHRyaW1tZWQuc2xpY2UoMSwgLTEpO1xyXG4gIH1cclxuICByZXR1cm4gdHJpbW1lZDtcclxufVxyXG4iLCAiLyoqXHJcbiAqIGJhY2tncm91bmQudHMgXHUyMDE0IGV4dGVuc2lvbiBzZXJ2aWNlIHdvcmtlci5cclxuICpcclxuICogT3ducyB0aGUgY2FwdHVyZSBwaXBlbGluZTogcmVjZWl2ZXMgYGdyYXBocWwtY2FwdHVyZWAgbWVzc2FnZXMgZnJvbSB0aGVcclxuICogY29udGVudCBzY3JpcHQsIG5vcm1hbGl6ZXMgdGhlbSwgYWNjdW11bGF0ZXMgcGVyLWhhbmRsZSBydW4gYnVmZmVycyBpblxyXG4gKiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgYW5kIGNvbW1pdHMgdGhlbSB0byB0aGUgY29uZmlndXJlZCBHaXRIdWIgcmVwb1xyXG4gKiB2aWEgdGhlIEdpdCBEYXRhIEFQSS5cclxuICpcclxuICogU2VydmljZSB3b3JrZXJzIGluIE1WMyBtYXkgYmUgZXZpY3RlZCBhdCBhbnkgdGltZSwgc28gYWxsIGNyaXRpY2FsIHN0YXRlXHJcbiAqIGxpdmVzIGluIHN0b3JhZ2UgKG5ldmVyIG1vZHVsZS1zY29wZSkuIE9uIGV2ZXJ5IHdha2Ugd2UgcmUtZGVyaXZlIHdoYXQgd2VcclxuICogbmVlZDsgcGVuZGluZyBmbHVzaGVzIGFyZSBkcml2ZW4gYnkgYGJyb3dzZXIuYWxhcm1zYCByYXRoZXIgdGhhbiB0aW1lcnMuXHJcbiAqL1xyXG5cclxuaW1wb3J0IHtcclxuICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxyXG4gIEFVVE9fU0NST0xMX01JTl9TRUMsXHJcbiAgRkFMTEJBQ0tfQUNDT1VOVFMsXHJcbiAgRkxVU0hfQUxBUk1fTUlOVVRFUyxcclxuICBGTFVTSF9JRExFX01TLFxyXG4gIEZMVVNIX1RXRUVUX1RIUkVTSE9MRCxcclxuICBQUk9GSUxFX0VORFBPSU5UUyxcclxuICBUV0VFVF9FTkRQT0lOVFMsXHJcbiAgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMsXHJcbn0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcclxuaW1wb3J0IHsgR2l0SHViQ2xpZW50LCBHaXRIdWJFcnJvciwgdG9CYXNlNjQgfSBmcm9tICcuL2xpYi9naXRodWIuanMnO1xyXG5pbXBvcnQgeyBkZXNjcmliZUVycm9yLCBlcnJvciBhcyBsb2dFcnIsIGluZm8sIHNldEJyb2FkY2FzdGVyLCB3YXJuIH0gZnJvbSAnLi9saWIvbG9nZ2VyLmpzJztcclxuaW1wb3J0IHsgZmlsdGVyUmVsYXRlZCwgbm9ybWFsaXplIH0gZnJvbSAnLi9saWIvbm9ybWFsaXplLmpzJztcclxuaW1wb3J0IHsgbmV3UnVuSWQsIHNob3J0UnVuSWQgfSBmcm9tICcuL2xpYi9ydW5pZHMuanMnO1xyXG5pbXBvcnQge1xyXG4gIGJ1bXBDb3VudGVyLFxyXG4gIGNsZWFyQWN0aXZpdHksXHJcbiAgY2xlYXJBbGwsXHJcbiAgY2xlYXJSdW5CdWZmZXIsXHJcbiAgZGVxdWV1ZU1lZGlhQ3Jhd2wsXHJcbiAgZGVxdWV1ZVJlZmV0Y2gsXHJcbiAgZW5nYWdlbWVudFNpZyxcclxuICBlbnF1ZXVlTWVkaWFDcmF3bCxcclxuICBlbnF1ZXVlUmVmZXRjaCxcclxuICBnZXRBY2NvdW50cyxcclxuICBnZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxyXG4gIGdldEFjdGl2aXR5LFxyXG4gIGdldEFyY2hpdmVTbmFwc2hvdCxcclxuICBnZXRBdXRvU2Nyb2xsU2Vzc2lvbixcclxuICBnZXRDb21taXR0ZWRJbmRleCxcclxuICBnZXRDb25uZWN0aW9uLFxyXG4gIGdldENvdW50ZXJzLFxyXG4gIGdldE1lZGlhQ3Jhd2xRdWV1ZSxcclxuICBnZXRNZWRpYUNyYXdsU2Vzc2lvbixcclxuICBnZXRSZWZldGNoUXVldWUsXHJcbiAgZ2V0UmVmZXRjaFNlc3Npb24sXHJcbiAgZ2V0UmVjZW50VHdlZXRTaWdodGluZ3MsXHJcbiAgZ2V0UnVuQnVmZmVyLFxyXG4gIGdldFJ1bkJ1ZmZlcnMsXHJcbiAgZ2V0U2V0dGluZ3MsXHJcbiAgaXNDb21taXR0ZWQsXHJcbiAgbWVkaWFDcmF3bFF1ZXVlVG90YWwsXHJcbiAgbmV4dE1lZGlhQ3Jhd2xUYXJnZXQsXHJcbiAgbmV4dFJlZmV0Y2hUYXJnZXQsXHJcbiAgcHJ1bmVDb21taXR0ZWRJbmRleCxcclxuICBwdXJnZVVucmVsYXRlZFN0YXRlLFxyXG4gIHJlZmV0Y2hRdWV1ZVRvdGFsLFxyXG4gIHByZXBlbmRSZWNlbnRUd2VldFNpZ2h0aW5ncyxcclxuICBzZXRBY2NvdW50cyxcclxuICBzZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxyXG4gIHNldEFyY2hpdmVTbmFwc2hvdCxcclxuICBzZXRBdXRvU2Nyb2xsU2Vzc2lvbixcclxuICBzZXRCdWZmZXJlZENvdW50LFxyXG4gIHNldENvbW1pdHRlZEluZGV4LFxyXG4gIHNldENvbm5lY3Rpb24sXHJcbiAgc2V0TWVkaWFDcmF3bFNlc3Npb24sXHJcbiAgc2V0UmVmZXRjaFNlc3Npb24sXHJcbiAgc2V0UnVuQnVmZmVyLFxyXG4gIHR5cGUgUnVuQnVmZmVyLFxyXG4gIHVwZGF0ZVNldHRpbmdzLFxyXG59IGZyb20gJy4vbGliL3N0b3JhZ2UuanMnO1xyXG5pbXBvcnQgdHlwZSB7XHJcbiAgQ2Fub25pY2FsVHdlZXQsXHJcbiAgQ2FwdHVyZVBheWxvYWQsXHJcbiAgQXJjaGl2ZVNuYXBzaG90LFxyXG4gIENvbm5lY3Rpb25TdGF0ZSxcclxuICBFeHRlbnNpb25TdGF0ZSxcclxuICBMb2dFdmVudCxcclxuICBRdWFyYW50aW5lUGF5bG9hZCxcclxuICBSdW50aW1lTWVzc2FnZSxcclxuICBTZWVuUGF5bG9hZCxcclxuICBTZXR0aW5ncyxcclxuICBUd2VldFNpZ2h0aW5nLFxyXG4gIFVuYXZhaWxhYmxlVHdlZXQsXHJcbn0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xyXG5pbXBvcnQgeyBwYXJzZUFjY291bnRzWWFtbCB9IGZyb20gJy4vbGliL3lhbWwuanMnO1xyXG5cclxuY29uc3QgRVhUX1ZFUlNJT04gPSBicm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uO1xyXG5jb25zdCBNQU5VQUxfQ0FQVFVSRV9XSU5ET1dfTVMgPSA5MF8wMDA7XHJcbmxldCBtYW51YWxDYXB0dXJlVW50aWxNcyA9IDA7XHJcblxyXG5zZXRCcm9hZGNhc3RlcigoZXY6IExvZ0V2ZW50KSA9PiB7XHJcbiAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2xvZy1ldmVudCcsIGV2ZW50OiBldiB9KS5jYXRjaCgoKSA9PiB7fSk7XHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk6IHZvaWQge1xyXG4gIG1hbnVhbENhcHR1cmVVbnRpbE1zID0gRGF0ZS5ub3coKSArIE1BTlVBTF9DQVBUVVJFX1dJTkRPV19NUztcclxufVxyXG5cclxuLy8gLS0tIFdha2UgaGFuZGxlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmJyb3dzZXIucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XHJcbiAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIGluc3RhbGxlZCcsIHsgdmVyc2lvbjogRVhUX1ZFUlNJT04gfSk7XHJcbiAgYXdhaXQgb25XYWtlKCdpbnN0YWxsJyk7XHJcbn0pO1xyXG5cclxuYnJvd3Nlci5ydW50aW1lLm9uU3RhcnR1cC5hZGRMaXN0ZW5lcigoKSA9PiB7XHJcbiAgdm9pZCBvbldha2UoJ3N0YXJ0dXAnKTtcclxufSk7XHJcblxyXG4vLyBGb3JjZSBhdCBsZWFzdCBvbmUgd2FrZSB0byByZWdpc3RlciBhbGFybXMgLyB2ZXJpZnkgY29ubmVjdGlvbi5cclxudm9pZCBvbldha2UoJ21vZHVsZS1sb2FkJyk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBvbldha2UocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICB0cnkge1xyXG4gICAgYXdhaXQgZW5zdXJlQWxhcm1zKCk7XHJcbiAgICBhd2FpdCBlbnN1cmVBdXRvU2Nyb2xsQWxhcm0oKTtcclxuICAgIGF3YWl0IGZsdXNoT3JwaGFuZWRCdWZmZXJzSWZTdGFsZSgpO1xyXG4gICAgYXdhaXQgcmVpbmplY3RJbnRvT3BlblRhYnMoKTtcclxuICAgIC8vIERyb3AgZGVkdXAtaW5kZXggZW50cmllcyBvbGRlciB0aGFuIDMwIGRheXMgc28gdGhlIHN0b3JlIGRvZXNuJ3RcclxuICAgIC8vIGdyb3cgdW5ib3VuZGVkIG92ZXIgbW9udGhzIG9mIGNhcHR1cmUgc2Vzc2lvbnMuXHJcbiAgICBjb25zdCBwcnVuZWQgPSBhd2FpdCBwcnVuZUNvbW1pdHRlZEluZGV4KDMwICogMjQgKiA2MCAqIDYwICogMTAwMCk7XHJcbiAgICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgaW5mbygncHJ1bmVkIGNvbW1pdHRlZCBpbmRleCcsIHsgcHJ1bmVkIH0pO1xyXG4gICAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gICAgaWYgKHNldHRpbmdzLnBhdCAmJiBzZXR0aW5ncy5vd25lciAmJiBzZXR0aW5ncy5yZXBvKSB7XHJcbiAgICAgIGF3YWl0IHZlcmlmeUNvbm5lY3Rpb24oZmFsc2UpO1xyXG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KGZhbHNlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xyXG4gICAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcclxuICAgICAgICBsb2dpbjogbnVsbCxcclxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxyXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXHJcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcclxuICAgICAgfSk7XHJcbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBhd2FrZTsgc2V0dGluZ3MgaW5jb21wbGV0ZScsIHsgcmVhc29uIH0pO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgYXdhaXQgbG9nRXJyKCd3YWtlIGZhaWxlZCcsIHsgcmVhc29uLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogUmUtaW5qZWN0IHRoZSBNQUlOLXdvcmxkIHBhZ2UtaG9vayArIGlzb2xhdGVkLXdvcmxkIGNvbnRlbnQgc2NyaXB0IGludG9cclxuICogZXZlcnkgYWxyZWFkeS1vcGVuIHguY29tIC8gdHdpdHRlci5jb20gdGFiLlxyXG4gKlxyXG4gKiBNYW5pZmVzdCBjb250ZW50X3NjcmlwdHMgb25seSBpbmplY3Qgb24gZnJlc2ggbmF2aWdhdGlvbiAocnVuX2F0OlxyXG4gKiBkb2N1bWVudF9zdGFydCkuIFdoZW4gdGhlIHVzZXIgcmVsb2FkcyB0aGUgZXh0ZW5zaW9uIHdoaWxlIFggdGFicyBhcmVcclxuICogb3BlbiwgdGhvc2UgdGFicyBrZWVwIHRoZWlyIGNvbnRlbnQgc2NyaXB0cyBidXQgbmV2ZXIgZ2V0IGEgbmV3IHBhZ2UtaG9va1xyXG4gKiBcdTIwMTQgc28gZmV0Y2gvWEhSIHN0YXlzIHVucGF0Y2hlZCBhbmQgY2FwdHVyZXMgc2lsZW50bHkgZmFpbC4gRG9pbmcgdGhpcyBvblxyXG4gKiBldmVyeSB3YWtlIGlzIGlkZW1wb3RlbnQgKHBhZ2UtaG9vayBoYXMgYSBUQUcgZ3VhcmQpIGFuZCBjaGVhcC5cclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIHJlaW5qZWN0SW50b09wZW5UYWJzKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XHJcbiAgdHJ5IHtcclxuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgYXdhaXQgd2FybignY291bGQgbm90IHF1ZXJ5IG9wZW4gdGFicycsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcclxuICAgIGlmICh0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJykgY29udGludWU7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcclxuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxyXG4gICAgICAgIGZpbGVzOiBbJ3BhZ2UtaG9vay5qcyddLFxyXG4gICAgICAgIC8vIEZpcmVmb3ggMTI4KyBzdXBwb3J0cyB0aGUgTUFJTiBleGVjdXRpb24gd29ybGQgdmlhIHRoaXMgQVBJLCBidXRcclxuICAgICAgICAvLyB0aGUgQHR5cGVzL2ZpcmVmb3gtd2ViZXh0LWJyb3dzZXIgcGFja2FnZSB3ZSdyZSBvbiBzdGlsbCBvbmx5XHJcbiAgICAgICAgLy8gZGVjbGFyZXMgJ0lTT0xBVEVEJy4gQ2FzdCB0aHJvdWdoIHRoZSBsaXRlcmFsIHVuaW9uLlxyXG4gICAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcclxuICAgICAgfSk7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXHJcbiAgICAgICAgZmlsZXM6IFsnY29udGVudC5qcyddLFxyXG4gICAgICB9KTtcclxuICAgICAgYXdhaXQgaW5mbygncmUtaW5qZWN0ZWQgc2NyaXB0cyBpbnRvIG9wZW4gdGFiJywge1xyXG4gICAgICAgIHRhYklkOiB0YWIuaWQsXHJcbiAgICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwgPz8gJycpLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAvLyBTb21lIHRhYnMgKGFib3V0OiBwYWdlcywgZGlzY2FyZGVkIHRhYnMsIG1pZC1uYXZpZ2F0aW9uKSByZWplY3RcclxuICAgICAgLy8gZXhlY3V0ZVNjcmlwdC4gVGhhdCdzIGZpbmUgXHUyMDE0IHdlJ2xsIGNhdGNoIHRoZW0gb24gdGhlIG5leHQgd2FrZSBvclxyXG4gICAgICAvLyB3aGVuIHRoZSB1c2VyIG5hdmlnYXRlcy5cclxuICAgICAgYXdhaXQgd2FybigncmUtaW5qZWN0IGZhaWxlZCBmb3IgdGFiOyBjb250aW51aW5nJywge1xyXG4gICAgICAgIHRhYklkOiB0YWIuaWQsXHJcbiAgICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwgPz8gJycpLFxyXG4gICAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVBbGFybXMoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ2ZsdXNoLXN3ZWVwJyk7XHJcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3ZlcmlmeS1jb25uZWN0aW9uJyk7XHJcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY3JlYXRlKCdmbHVzaC1zd2VlcCcsIHsgcGVyaW9kSW5NaW51dGVzOiBGTFVTSF9BTEFSTV9NSU5VVEVTIH0pO1xyXG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgndmVyaWZ5LWNvbm5lY3Rpb24nLCB7XHJcbiAgICBwZXJpb2RJbk1pbnV0ZXM6IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TIC8gNjBfMDAwLFxyXG4gIH0pO1xyXG59XHJcblxyXG4vLyBGaXJlZm94IE1WMyBhbGFybXMgaGF2ZSBhIDMwcyBtaW5pbXVtIHBlcmlvZCwgYnV0IHdlIHdhbnQgc3ViLW1pbnV0ZVxyXG4vLyBzY3JvbGxpbmcuIFRoZSBhdXRvLXNjcm9sbCBsb29wIHRoZXJlZm9yZSBydW5zIG9uIGFuIGluLVNXIGludGVydmFsLlxyXG4vLyBgYXV0b1Njcm9sbFNlc3Npb25gIGluIHN0b3JhZ2UgaXMgdGhlIHNvdXJjZSBvZiB0cnV0aCBmb3Igd2hldGhlciB0aGUgbG9vcFxyXG4vLyBpcyBtZWFudCB0byBiZSBydW5uaW5nIFx1MjAxNCB0aGUgdGltZXIgaXMganVzdCB0aGUgbG9jYWwgZXhlY3V0aW9uIGFybS5cclxubGV0IGF1dG9TY3JvbGxUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XHJcblxyXG4vLyBXYWl0LWZvci1pbmdlc3QgdGltZW91dDogaWYgYSByZWZldGNoIC8gbWVkaWEtY3Jhd2wgdGFiIG5hdmlnYXRpb24gZG9lc24ndFxyXG4vLyBwcm9kdWNlIGFuIGluZ2VzdGVkIGNhcHR1cmUgd2l0aGluIHRoaXMgbWFueSBtcywgYWR2YW5jZSBhbnl3YXkgc28gd2VcclxuLy8gZG9uJ3QgZGVhZGxvY2sgb24gZGVsZXRlZCAvIDQwNCAvIHBheXdhbGxlZCB0d2VldHMuXHJcbmNvbnN0IElOR0VTVF9XQUlUX01TID0gMjVfMDAwO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQXV0b1Njcm9sbEFsYXJtKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIC8vIFdhcyB0aGUgbG9vcCBydW5uaW5nIGJlZm9yZSB0aGUgU1cgZXZpY3Rpb24/IFJlLWFybSBpZiBzby5cclxuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoc2VzcyAhPT0gbnVsbCAmJiBzLmVuYWJsZWQgIT09IGZhbHNlKSB7XHJcbiAgICBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTogdm9pZCB7XHJcbiAgaWYgKGF1dG9TY3JvbGxUaW1lciAhPT0gbnVsbCkge1xyXG4gICAgY2xlYXJJbnRlcnZhbChhdXRvU2Nyb2xsVGltZXIpO1xyXG4gICAgYXV0b1Njcm9sbFRpbWVyID0gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFybUF1dG9TY3JvbGxUaW1lcihpbnRlcnZhbFNlYzogbnVtYmVyKTogdm9pZCB7XHJcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcclxuICBjb25zdCBjbGFtcGVkID0gTWF0aC5taW4oXHJcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxyXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChpbnRlcnZhbFNlYykpXHJcbiAgKTtcclxuICBhdXRvU2Nyb2xsVGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIGF1dG9TY3JvbGxUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ2F1dG8tc2Nyb2xsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIH0pO1xyXG4gIH0sIGNsYW1wZWQgKiAxMDAwKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc3RhcnRBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbih7XHJcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIHNjcm9sbENvdW50OiAwLFxyXG4gICAgaW5nZXN0ZWRDb3VudDogMCxcclxuICAgIGluZ2VzdGVkTmV3Q291bnQ6IDAsXHJcbiAgICBpbmdlc3RlZEV4aXN0aW5nQ291bnQ6IDAsXHJcbiAgICBza2lwcGVkT2xkQ291bnQ6IDAsXHJcbiAgICBleHBhbmRlZENvdW50OiAwLFxyXG4gIH0pO1xyXG4gIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XHJcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBzdGFydGVkJywgeyBpbnRlcnZhbF9zZWM6IHMuYXV0b1Njcm9sbEludGVydmFsU2VjIH0pO1xyXG4gIC8vIEZpcmUgb25lIGltbWVkaWF0ZSB0aWNrIHNvIHRoZSB1c2VyIHNlZXMgbW90aW9uIHJpZ2h0IGF3YXkuXHJcbiAgdm9pZCBhdXRvU2Nyb2xsVGljaygpO1xyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbEF1dG9TY3JvbGxMb29wKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24obnVsbCk7XHJcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBzY3JvbGxzOiBzZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxyXG4gICAgaW5nZXN0ZWQ6IHNlc3M/LmluZ2VzdGVkQ291bnQgPz8gMCxcclxuICAgIGV4cGFuZGVkOiBzZXNzPy5leHBhbmRlZENvdW50ID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gYXV0b1Njcm9sbFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcclxuICB0cnkge1xyXG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdhdXRvLXNjcm9sbDogdGFiIHF1ZXJ5IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gIGxldCBzY3JvbGxDb3VudCA9IDA7XHJcbiAgbGV0IGV4cGFuZGVkQ291bnQgPSAwO1xyXG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcclxuICAgIGlmICh0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJykgY29udGludWU7XHJcbiAgICBpZiAodGFiLmRpc2NhcmRlZCkgY29udGludWU7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXN1bHRzID0gKGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXHJcbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxyXG4gICAgICAgIC8vIENhc3Q6IHRoZSBAdHlwZXMvZmlyZWZveC13ZWJleHQtYnJvd3NlciB0eXBlIHNpZ25hdHVyZSBpbnNpc3RzXHJcbiAgICAgICAgLy8gYGZ1bmNgIHJldHVybnMgdm9pZCwgYnV0IHRoZSBBUEkgYWN0dWFsbHkgc3VyZmFjZXMgdGhlIHJldHVyblxyXG4gICAgICAgIC8vIHZhbHVlIHZpYSBgcmVzdWx0WzBdLnJlc3VsdGAuIFdlIHVzZSB0aGF0IGZvciB0aGUgZXhwYW5kIGNvdW50LlxyXG4gICAgICAgIGZ1bmM6ICgoKSA9PiB7XHJcbiAgICAgICAgICAvLyAxLiBDbGljayBhbnkgdmlzaWJsZSBcIlNob3cgbW9yZVwiIGxpbmtzIGluIGxvbmctdHdlZXQgYm9kaWVzIHNvIFhcclxuICAgICAgICAgIC8vICAgIGlubGluZXMgdGhlIG5vdGVfdHdlZXQgYm9keSBhbmQgb3VyIHBhZ2UtaG9vayBjYXB0dXJlcyB0aGVcclxuICAgICAgICAgIC8vICAgIGZ1bGwgdGV4dCB3aXRob3V0IHRoZSByZWZldGNoIGRldG91ci4gVHJ5IHNldmVyYWwgc2VsZWN0b3JzXHJcbiAgICAgICAgICAvLyAgICBiZWNhdXNlIFggcm90YXRlcyB0aGUgdGVzdGlkIGxhYmVsIHNlbWktcmVndWxhcmx5LlxyXG4gICAgICAgICAgY29uc3QgU0hPV19NT1JFX1NFTEVDVE9SUyA9IFtcclxuICAgICAgICAgICAgJ1tkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxyXG4gICAgICAgICAgICAnYnV0dG9uW2RhdGEtdGVzdGlkPVwidHdlZXQtdGV4dC1zaG93LW1vcmUtbGlua1wiXScsXHJcbiAgICAgICAgICAgICdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0gW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcclxuICAgICAgICAgIF07XHJcbiAgICAgICAgICBjb25zdCBjbGlja2VkID0gbmV3IFNldDxFbGVtZW50PigpO1xyXG4gICAgICAgICAgbGV0IGV4cGFuZGVkID0gMDtcclxuICAgICAgICAgIGZvciAoY29uc3Qgc2VsIG9mIFNIT1dfTU9SRV9TRUxFQ1RPUlMpIHtcclxuICAgICAgICAgICAgZm9yIChjb25zdCBlbCBvZiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsKSkpIHtcclxuICAgICAgICAgICAgICBpZiAoY2xpY2tlZC5oYXMoZWwpKSBjb250aW51ZTtcclxuICAgICAgICAgICAgICAvLyBDb25maXJtIGl0J3MgYWN0dWFsbHkgdGhlIHNob3ctbW9yZSBhZmZvcmRhbmNlIGJ5IHRleHQuXHJcbiAgICAgICAgICAgICAgY29uc3QgdCA9IChlbC50ZXh0Q29udGVudCB8fCAnJykudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgICAgaWYgKHQgIT09ICdzaG93IG1vcmUnICYmIHQgIT09ICdzaG93IHRoaXMgdGhyZWFkJykgY29udGludWU7XHJcbiAgICAgICAgICAgICAgY29uc3QgcmVjdCA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgICAgICAgIGlmIChyZWN0LndpZHRoID09PSAwIHx8IHJlY3QuaGVpZ2h0ID09PSAwKSBjb250aW51ZTtcclxuICAgICAgICAgICAgICBjbGlja2VkLmFkZChlbCk7XHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIChlbCBhcyBIVE1MRWxlbWVudCkuY2xpY2soKTtcclxuICAgICAgICAgICAgICAgIGV4cGFuZGVkICs9IDE7XHJcbiAgICAgICAgICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgICAgICAgICAvLyBpZ25vcmVcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC8vIDIuIFNjcm9sbCB0aGUgcGFnZS4gRGlzcGF0Y2ggRW5kIGtleSBmaXJzdCBzaW5jZSBtYW55IFggc3VyZmFjZXNcclxuICAgICAgICAgIC8vICAgIChsaXN0cywgc2VhcmNoLCByZXBsaWVzKSBiaW5kIHBhZ2luYXRpb24gdHJpZ2dlcnMgdG8gaXQgdmlhXHJcbiAgICAgICAgICAvLyAgICBSZWFjdCBoYW5kbGVyczsgdGhlbiBleHBsaWNpdGx5IHNjcm9sbCB0aGUgZG9jdW1lbnQuXHJcbiAgICAgICAgICBjb25zdCBvcHRzOiBLZXlib2FyZEV2ZW50SW5pdCA9IHtcclxuICAgICAgICAgICAga2V5OiAnRW5kJyxcclxuICAgICAgICAgICAgY29kZTogJ0VuZCcsXHJcbiAgICAgICAgICAgIGtleUNvZGU6IDM1LFxyXG4gICAgICAgICAgICB3aGljaDogMzUsXHJcbiAgICAgICAgICAgIGJ1YmJsZXM6IHRydWUsXHJcbiAgICAgICAgICAgIGNhbmNlbGFibGU6IHRydWUsXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgY29uc3QgZm9jdXMgPSAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCB8IG51bGwpID8/IGRvY3VtZW50LmJvZHk7XHJcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXlkb3duJywgb3B0cykpO1xyXG4gICAgICAgICAgZm9jdXMuZGlzcGF0Y2hFdmVudChuZXcgS2V5Ym9hcmRFdmVudCgna2V5dXAnLCBvcHRzKSk7XHJcbiAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oe1xyXG4gICAgICAgICAgICB0b3A6IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxIZWlnaHQsXHJcbiAgICAgICAgICAgIGJlaGF2aW9yOiAnYXV0bycsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHJldHVybiB7IGV4cGFuZGVkIH07XHJcbiAgICAgICAgfSkgYXMgKCkgPT4gdm9pZCxcclxuICAgICAgfSkpIGFzIEFycmF5PHsgcmVzdWx0PzogdW5rbm93biB9PjtcclxuICAgICAgc2Nyb2xsQ291bnQgKz0gMTtcclxuICAgICAgY29uc3QgciA9IHJlc3VsdHNbMF0/LnJlc3VsdCBhcyB7IGV4cGFuZGVkPzogbnVtYmVyIH0gfCB1bmRlZmluZWQ7XHJcbiAgICAgIGlmIChyICYmIHR5cGVvZiByLmV4cGFuZGVkID09PSAnbnVtYmVyJykgZXhwYW5kZWRDb3VudCArPSByLmV4cGFuZGVkO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIFRhYnMgdGhhdCBkaXNhbGxvdyBzY3JpcHRpbmcgKGFib3V0OiwgZGlzY2FyZGVkLCBtaWQtbmF2aWdhdGlvbilcclxuICAgICAgLy8ganVzdCBnZXQgc2tpcHBlZCBcdTIwMTQgdGhleSdsbCBiZSBlbGlnaWJsZSBvbiBhIGxhdGVyIHRpY2suXHJcbiAgICB9XHJcbiAgfVxyXG4gIGlmIChzY3JvbGxDb3VudCA+IDApIHtcclxuICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xyXG4gICAgaWYgKHNlc3MgIT09IG51bGwpIHtcclxuICAgICAgc2Vzcy5zY3JvbGxDb3VudCArPSBzY3JvbGxDb3VudDtcclxuICAgICAgc2Vzcy5leHBhbmRlZENvdW50ICs9IGV4cGFuZGVkQ291bnQ7XHJcbiAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKHNlc3MpO1xyXG4gICAgICAvLyBObyBicm9hZGNhc3Qgb24gZXZlcnkgdGljayBcdTIwMTQgdGhlIDE1cyBzaWRlYmFyIHJlZnJlc2ggcGlja3MgaXQgdXAuXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5icm93c2VyLmFsYXJtcy5vbkFsYXJtLmFkZExpc3RlbmVyKChhbGFybSkgPT4ge1xyXG4gIGlmIChhbGFybS5uYW1lID09PSAnZmx1c2gtc3dlZXAnKSB7XHJcbiAgICB2b2lkIGZsdXNoSWRsZUJ1ZmZlcnMoKTtcclxuICB9IGVsc2UgaWYgKGFsYXJtLm5hbWUgPT09ICd2ZXJpZnktY29ubmVjdGlvbicpIHtcclxuICAgIHZvaWQgdmVyaWZ5Q29ubmVjdGlvbihmYWxzZSk7XHJcbiAgfVxyXG4gIC8vIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBwcmV2aW91c2x5IHJhbiB2aWEgYWxhcm1zOyB0aGV5IG5vdyB1c2VcclxuICAvLyBzZXRJbnRlcnZhbCB0byBlc2NhcGUgdGhlIDMwcyBhbGFybSBmbG9vci4gTGVhdmUgdGhlIG5hbWVzIGxpc3RlZFxyXG4gIC8vIG5vd2hlcmUgc28gYW55IG9ycGhhbmVkIGFsYXJtcyAoZnJvbSBvbGRlciBidWlsZHMpIGp1c3Qgbm8tb3AuXHJcbn0pO1xyXG5cclxuLy8gLS0tIFRvb2xiYXIgYWN0aW9uOiB0b2dnbGUgdGhlIHNpZGViYXIgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmlmIChicm93c2VyLmFjdGlvbj8ub25DbGlja2VkKSB7XHJcbiAgYnJvd3Nlci5hY3Rpb24ub25DbGlja2VkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2lkZWJhckFjdGlvbi50b2dnbGUoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAvLyBGYWxsYmFjazogb3BlbiBvcHRpb25zIGlmIHNpZGViYXIgY2FuJ3QgYmUgdG9nZ2xlZC5cclxuICAgICAgYXdhaXQgd2Fybignc2lkZWJhciB0b2dnbGUgZmFpbGVkOyBvcGVuaW5nIG9wdGlvbnMnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XHJcbiAgICB9XHJcbiAgfSk7XHJcbn1cclxuXHJcbi8vIC0tLSBSdW50aW1lIG1lc3NhZ2UgZGlzcGF0Y2ggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93biwgX3NlbmRlcikgPT4ge1xyXG4gIGlmICghaXNSdW50aW1lTWVzc2FnZShtc2cpKSByZXR1cm4gdW5kZWZpbmVkO1xyXG4gIHJldHVybiBoYW5kbGVNZXNzYWdlKG1zZykuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgdm9pZCBsb2dFcnIoJ21lc3NhZ2UgaGFuZGxlciBmYWlsZWQnLCB7IHR5cGU6IG1zZy50eXBlLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XHJcbiAgICB0aHJvdyBlcnI7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gaXNSdW50aW1lTWVzc2FnZShtOiB1bmtub3duKTogbSBpcyBSdW50aW1lTWVzc2FnZSB7XHJcbiAgcmV0dXJuICEhbSAmJiB0eXBlb2YgbSA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIChtIGFzIHsgdHlwZT86IHVua25vd24gfSkudHlwZSA9PT0gJ3N0cmluZyc7XHJcbn1cclxuXHJcbi8qKiBNZXNzYWdlcyB0aGF0IGRyaXZlIHRoZSBjYXB0dXJlIHBpcGVsaW5lLiBXaGVuIHRoZSBtYXN0ZXIgc3dpdGNoIGlzIE9GRlxyXG4gKiB3ZSBpZ25vcmUgdGhlc2UgYnV0IHN0aWxsIHJlc3BvbmQgdG8gc3RhdHVzIC8gY29uZmlndXJhdGlvbiBxdWVyaWVzLiAqL1xyXG5jb25zdCBDQVBUVVJFX1BJUEVMSU5FX01FU1NBR0VTID0gbmV3IFNldDxSdW50aW1lTWVzc2FnZVsndHlwZSddPihbXHJcbiAgJ2dyYXBocWwtY2FwdHVyZScsXHJcbiAgJ2NhcHR1cmUtbm93JyxcclxuICAnY2FwdHVyZS1hbGwnLFxyXG4gICdjYXB0dXJlLXRoaXMtcGFnZScsXHJcbiAgJ2ZsdXNoLWFsbCcsXHJcbiAgJ2ZsdXNoLWhhbmRsZScsXHJcbiAgJ3N0YXJ0LXJlZmV0Y2gnLFxyXG4gICdzdGFydC1tZWRpYS1jcmF3bCcsXHJcbiAgJ3N0YXJ0LWF1dG8tc2Nyb2xsJyxcclxuXSk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBpc0VuYWJsZWQoKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgcmV0dXJuIHMuZW5hYmxlZCAhPT0gZmFsc2U7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UobXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8dW5rbm93bj4ge1xyXG4gIC8vIE1hc3RlciBzd2l0Y2g6IHdoZW4gdGhlIHVzZXIgaGFzIHBhdXNlZCB0aGUgZXh0ZW5zaW9uIHdlIHN0aWxsIG5lZWRcclxuICAvLyB0aGUgbWV0YS1jaGFubmVscyAoZ2V0LXN0YXRlLCB0b2dnbGUtZW5hYmxlZCwgb3Blbi1vcHRpb25zLCBcdTIwMjYpIHNvIHRoZVxyXG4gIC8vIHNpZGViYXIgc3RheXMgZnVuY3Rpb25hbCwgYnV0IGFueXRoaW5nIHRoYXQgd291bGQgYWN0dWFsbHkgY2FwdHVyZSxcclxuICAvLyBjb21taXQsIG9yIGRyaXZlIGEgdGFiIGlzIGEgbm8tb3AuXHJcbiAgaWYgKCEoYXdhaXQgaXNFbmFibGVkKCkpICYmIENBUFRVUkVfUElQRUxJTkVfTUVTU0FHRVMuaGFzKG1zZy50eXBlKSkge1xyXG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHBhdXNlZDogdHJ1ZSB9O1xyXG4gIH1cclxuICBzd2l0Y2ggKG1zZy50eXBlKSB7XHJcbiAgICBjYXNlICdncmFwaHFsLWNhcHR1cmUnOlxyXG4gICAgICBhd2FpdCBvbkdyYXBocWxDYXB0dXJlKG1zZy5lbmRwb2ludCwgbXNnLnVybCwgbXNnLnBhZ2VVcmwgPz8gbnVsbCwgbXNnLnJlc3BvbnNlKTtcclxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgIGNhc2UgJ2NvbnRlbnQtYWxpdmUnOlxyXG4gICAgICBhd2FpdCBpbmZvKCdjb250ZW50IHNjcmlwdCBhbGl2ZSBvbiBwYWdlJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdwYWdlLWhvb2stYWN0aXZlJzpcclxuICAgICAgYXdhaXQgaW5mbygncGFnZSBob29rIHBhdGNoZWQgZmV0Y2gvWEhSJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdsb2ctY29udGVudC1ldmVudCc6XHJcbiAgICAgIGlmIChtc2cubGV2ZWwgPT09ICd3YXJuJykge1xyXG4gICAgICAgIGF3YWl0IHdhcm4obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAobXNnLmxldmVsID09PSAnZXJyb3InKSB7XHJcbiAgICAgICAgYXdhaXQgbG9nRXJyKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGF3YWl0IGluZm8obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgIGNhc2UgJ2dldC1zdGF0ZSc6XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdjYXB0dXJlLW5vdyc6XHJcbiAgICAgIGF3YWl0IGNhcHR1cmVOb3cobXNnLmhhbmRsZSk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdjYXB0dXJlLWFsbCc6XHJcbiAgICAgIGF3YWl0IGNhcHR1cmVBbGwoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NhcHR1cmUtdGhpcy1wYWdlJzpcclxuICAgICAgYXdhaXQgY2FwdHVyZVRoaXNQYWdlKCk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdmbHVzaC1hbGwnOlxyXG4gICAgICBhd2FpdCBmbHVzaEFsbCgndXNlcicpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnZmx1c2gtaGFuZGxlJzpcclxuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUobXNnLmhhbmRsZSwgJ3VzZXInKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3RvZ2dsZS1hdXRvLWNhcHR1cmUnOlxyXG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGF1dG9DYXB0dXJlOiBtc2cub24gfSk7XHJcbiAgICAgIGF3YWl0IGluZm8oJ2F1dG8tY2FwdHVyZSB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAndG9nZ2xlLXVwZGF0ZS1leGlzdGluZyc6XHJcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgdXBkYXRlRXhpc3Rpbmc6IG1zZy5vbiB9KTtcclxuICAgICAgYXdhaXQgaW5mbygndXBkYXRlLWV4aXN0aW5nIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICd0b2dnbGUtZW5hYmxlZCc6IHtcclxuICAgICAgY29uc3QgcyA9IGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgZW5hYmxlZDogbXNnLm9uIH0pO1xyXG4gICAgICBpZiAoIW1zZy5vbikge1xyXG4gICAgICAgIC8vIFBhdXNpbmcgc3RvcHMgYWxsIGluLWZsaWdodCBsb29wcyBzbyB0aGUgdXNlciBnZXRzIGltbWVkaWF0ZVxyXG4gICAgICAgIC8vIHF1aWV0LCBub3QgYSBcIm9uZSBtb3JlIHRpY2tcIiBzdXJwcmlzZS5cclxuICAgICAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xyXG4gICAgICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcclxuICAgICAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XHJcbiAgICAgICAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxyXG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gUmVzdW1pbmcgcmUtYXJtcyBhbnkgbG9vcHMgd2hvc2Ugc2Vzc2lvbiBpcyBzdGlsbCBzZXQuXHJcbiAgICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgICAgICAgaWYgKHNlc3MgIT09IG51bGwpIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XHJcbiAgICAgIH1cclxuICAgICAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIG1hc3RlciBzd2l0Y2ggdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIH1cclxuICAgIGNhc2UgJ3N0YXJ0LWF1dG8tc2Nyb2xsJzpcclxuICAgICAgYXdhaXQgc3RhcnRBdXRvU2Nyb2xsTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2FuY2VsLWF1dG8tc2Nyb2xsJzpcclxuICAgICAgYXdhaXQgY2FuY2VsQXV0b1Njcm9sbExvb3AoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCc6IHtcclxuICAgICAgY29uc3Qgc2Vjb25kcyA9IE1hdGgubWluKFxyXG4gICAgICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXHJcbiAgICAgICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChtc2cuc2Vjb25kcykpXHJcbiAgICAgICk7XHJcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzZWNvbmRzIH0pO1xyXG4gICAgICAvLyBSZS1hcm0gYW55IGFjdGl2ZSBsb29wcyB3aXRoIHRoZSBuZXcgaW50ZXJ2YWwuXHJcbiAgICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xyXG4gICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHNlY29uZHMpO1xyXG4gICAgICBpZiAocmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcclxuICAgICAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgc3RhcnRNZWRpYUNyYXdsSW50ZXJ2YWwoc2Vjb25kcyk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICB9XHJcbiAgICBjYXNlICdzdGFydC1yZWZldGNoJzpcclxuICAgICAgYXdhaXQgc3RhcnRSZWZldGNoTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2FuY2VsLXJlZmV0Y2gnOlxyXG4gICAgICBhd2FpdCBjYW5jZWxSZWZldGNoTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnc3RhcnQtbWVkaWEtY3Jhd2wnOlxyXG4gICAgICBhd2FpdCBzdGFydE1lZGlhQ3Jhd2xMb29wKCk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdjYW5jZWwtbWVkaWEtY3Jhd2wnOlxyXG4gICAgICBhd2FpdCBjYW5jZWxNZWRpYUNyYXdsTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAncHVyZ2UtdW5yZWxhdGVkJzoge1xyXG4gICAgICBjb25zdCBhY2NzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcclxuICAgICAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjcy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcclxuICAgICAgY29uc3Qgc3VtbWFyeSA9IGF3YWl0IHB1cmdlVW5yZWxhdGVkU3RhdGUodHJhY2tlZCk7XHJcbiAgICAgIGF3YWl0IGluZm8oJ3B1cmdlZCB1bnJlbGF0ZWQgc3RhdGUnLCBzdW1tYXJ5KTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIH1cclxuICAgIGNhc2UgJ3JlZnJlc2gtYWNjb3VudHMnOlxyXG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KHRydWUpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAndmVyaWZ5LWNvbm5lY3Rpb24nOlxyXG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKHRydWUpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2xlYXItYWN0aXZpdHknOlxyXG4gICAgICBhd2FpdCBjbGVhckFjdGl2aXR5KCk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdvcGVuLW9wdGlvbnMnOlxyXG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdvcGVuLXZpZXdlcic6IHtcclxuICAgICAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgICAgIGNvbnN0IHVybCA9IHZpZXdlclVybChzKTtcclxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCB9KTtcclxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgIH1cclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICd1bmtub3duIG1lc3NhZ2UgdHlwZScgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLSBDYXB0dXJlIHBpcGVsaW5lIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5hc3luYyBmdW5jdGlvbiBvbkdyYXBocWxDYXB0dXJlKFxyXG4gIGVuZHBvaW50OiBzdHJpbmcsXHJcbiAgdXJsOiBzdHJpbmcsXHJcbiAgcGFnZVVybDogc3RyaW5nIHwgbnVsbCxcclxuICByZXNwb25zZTogdW5rbm93blxyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBpZiAoUFJPRklMRV9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuOyAvLyBub3QgdHdlZXQtYmVhcmluZ1xyXG4gIGlmICghVFdFRVRfRU5EUE9JTlRTLmhhcyhlbmRwb2ludCkpIHJldHVybjtcclxuXHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGlmIChzZXR0aW5ncy5lbmFibGVkID09PSBmYWxzZSkgcmV0dXJuO1xyXG4gIGlmIChzZXR0aW5ncy5hdXRvQ2FwdHVyZSA9PT0gZmFsc2UpIHtcclxuICAgIGNvbnN0IGV4cGxpY2l0Q2FwdHVyZUFjdGl2ZSA9XHJcbiAgICAgIERhdGUubm93KCkgPCBtYW51YWxDYXB0dXJlVW50aWxNcyB8fFxyXG4gICAgICAoYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKSkgIT09IG51bGwgfHxcclxuICAgICAgKGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCkpICE9PSBudWxsIHx8XHJcbiAgICAgIChhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpKSAhPT0gbnVsbDtcclxuICAgIGlmICghZXhwbGljaXRDYXB0dXJlQWN0aXZlKSByZXR1cm47XHJcbiAgfVxyXG5cclxuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XHJcbiAgLy8gV2UgZGVsaWJlcmF0ZWx5IGRvIE5PVCBzaG9ydC1jaXJjdWl0IHdoZW4gdGhlIFBBVCBpcyBtaXNzaW5nLiBUaGVcclxuICAvLyBub3JtYWxpemUgc3RlcCBpcyBjaGVhcCwgdGhlIGJ1ZmZlciBzdXJ2aXZlcyBzZXJ2aWNlLXdvcmtlciBldmljdGlvbixcclxuICAvLyBhbmQgb25jZSB0aGUgUEFUIGlzIHNldCB0aGUgbmV4dCBhbGFybSBvciB1c2VyLXRyaWdnZXJlZCBmbHVzaCBjb21taXRzXHJcbiAgLy8gZXZlcnl0aGluZyB3ZSd2ZSBzZWVuLiBEcm9wcGluZyBjYXB0dXJlcyBoZXJlIHdhcyBoaWRpbmcgdGhlIHVzZXInc1xyXG4gIC8vIGZpcnN0IGJyb3dzaW5nIHNlc3Npb24gZW50aXJlbHkuXHJcblxyXG4gIC8vIFR3by1zdGFnZSBmaWx0ZXI6XHJcbiAgLy8gICAxLiBCdWlsZCBFVkVSWSBjYW5vbmljYWwgdHdlZXQgd2UgY2FuIGZpbmQgaW4gdGhlIHJlc3BvbnNlIChubyBoYW5kbGVcclxuICAvLyAgICAgIGZpbHRlciBhdCB0aGUgbm9ybWFsaXplciBsZXZlbCBcdTIwMTQgd2Ugc3RpbGwgd2FudCBxdW90ZWQvUlQnZCBwYXJlbnRzXHJcbiAgLy8gICAgICB0aGF0IGFwcGVhciBhcyBzaWJsaW5nIG5vZGVzKS5cclxuICAvLyAgIDIuIEFwcGx5IGBmaWx0ZXJSZWxhdGVkYCBwb3N0LWhvYyB0byBkcm9wIGFueXRoaW5nIHRoYXQgaGFzIG5vXHJcbiAgLy8gICAgICByZWxhdGlvbnNoaXAgdG8gYSB0cmFja2VkIGFjY291bnQuIFRoZSBvbGQgYmVoYXZpb3VyIChcImVtcHR5XHJcbiAgLy8gICAgICBhbGxvd2VkLXNldCBvbiB1c2VyLXBhZ2UgZW5kcG9pbnRzLCBmdWxsIGZpbHRlciBvbiBob21lL3NlYXJjaFwiKVxyXG4gIC8vICAgICAgd2FzIHdheSB0b28gcGVybWlzc2l2ZSBvbiB0aGUgUmVwbGllcyB0YWI6IGV2ZXJ5IHJhbmRvbSByZXBsaWVyJ3NcclxuICAvLyAgICAgIHJlcGx5IGxhbmRlZCBpbiBhIHBlci1oYW5kbGUgYnVmZmVyIGtleWVkIGJ5IHRoZWlyIG93biBoYW5kbGUuXHJcbiAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjb3VudHMubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKSk7XHJcbiAgY29uc3QgY29yZSA9IG5ldyBTZXQoXHJcbiAgICBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuY2F0ZWdvcnkgPT09ICdjb3JlJykubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKVxyXG4gICk7XHJcbiAgY29uc3QgY2FwdHVyZWRBdCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxuXHJcbiAgbGV0IG5vcm1hbGl6ZWQ7XHJcbiAgdHJ5IHtcclxuICAgIG5vcm1hbGl6ZWQgPSBub3JtYWxpemUocmVzcG9uc2UsIHtcclxuICAgICAgY2FwdHVyZWRBdCxcclxuICAgICAgcnVuSWQ6ICdwZW5kaW5nJyxcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIGFsbG93ZWRIYW5kbGVzOiBuZXcgU2V0PHN0cmluZz4oKSxcclxuICAgICAgc291cmNlVXJsOiBwYWdlVXJsLFxyXG4gICAgfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCBxdWFyYW50aW5lKCdub3JtYWxpemUtdGhyZXcnLCBlbmRwb2ludCwgdXJsLCByZXNwb25zZSwgZXJyKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgLy8gRHJvcCB1bnJlbGF0ZWQgdHdlZXRzLiBUaGUgZmlsdGVyIGlzIGVuZHBvaW50LWF3YXJlOlxyXG4gIC8vICAgLSBPbiB0aGUgaG9tZSAvIHNlYXJjaCB0aW1lbGluZXMgd2UnZCBhbHJlYWR5IGJlZW4gZmlsdGVyaW5nIHRvXHJcbiAgLy8gICAgIHRyYWNrZWQgYXV0aG9ycyBvbmx5IFx1MjAxNCBrZWVwIHRoYXQgYmVoYXZpb3VyIGJ1dCBnbyB0aHJvdWdoIHRoZSBzYW1lXHJcbiAgLy8gICAgIGBmaWx0ZXJSZWxhdGVkYCBoZWxwZXIgc28gdGhlIHJ1bGVzIGFyZSB1bmlmb3JtLlxyXG4gIC8vICAgLSBPbiB1c2VyLXBhZ2UgZW5kcG9pbnRzIHdlIG5vdyBhbHNvIGRyb3AgYW55dGhpbmcgdGhhdCBpc24ndCBlaXRoZXJcclxuICAvLyAgICAgYXV0aG9yZWQtYnksIG1lbnRpb25pbmcsIHJlcGx5aW5nLXRvLCBvciByZWZlcmVuY2VkLWJ5IGEgdHJhY2tlZFxyXG4gIC8vICAgICBhY2NvdW50LlxyXG4gIGNvbnN0IGJlZm9yZUZpbHRlciA9IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aDtcclxuICBub3JtYWxpemVkLnR3ZWV0cyA9IGZpbHRlclJlbGF0ZWQobm9ybWFsaXplZC50d2VldHMsIHRyYWNrZWQsIGNvcmUpO1xyXG4gIGNvbnN0IGRyb3BwZWRVbnJlbGF0ZWQgPSBiZWZvcmVGaWx0ZXIgLSBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGg7XHJcbiAgaWYgKGRyb3BwZWRVbnJlbGF0ZWQgPiAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdkcm9wcGVkIHVucmVsYXRlZCB0d2VldHMnLCB7XHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICBkcm9wcGVkOiBkcm9wcGVkVW5yZWxhdGVkLFxyXG4gICAgICBrZXB0OiBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGgsXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8vIERpYWdub3N0aWM6IGV2ZXJ5IHR3ZWV0LWVuZHBvaW50IHBheWxvYWQgZ2V0cyBhIGxpbmUgaW4gdGhlIGFjdGl2aXR5XHJcbiAgLy8gdGFpbCB3aXRoIHdoYXQgd2Ugc2F3IHZzIGtlcHQuIFdoZW4gb2JzZXJ2ZWQ9MCB3ZSBhbHNvIGVtaXQgYSBzaGFwZVxyXG4gIC8vIHByb2JlIChrZXkgcGF0aHMgKyB0eXBlbmFtZXMpIHNvIHdlIGNhbiB0ZWxsIHdoZXRoZXIgWCByZXR1cm5lZCBhblxyXG4gIC8vIGVtcHR5IGVudmVsb3BlLCBhIGxvZ2luLXdhbGwgcmVzcG9uc2UsIG9yIGEgbmV3IHNoYXBlIHdlIGRvbid0IGtub3cgaG93XHJcbiAgLy8gdG8gd2FsayB5ZXQuXHJcbiAgaWYgKG5vcm1hbGl6ZWQub2JzZXJ2ZWRfaWRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgYXdhaXQgaW5mbygnZ3JhcGhxbCBwYXlsb2FkIGVtcHR5IFx1MjAxNCBzaGFwZSBwcm9iZScsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIHR5cGVuYW1lczogcHJvYmVUeXBlbmFtZXMocmVzcG9uc2UpLnNsaWNlKDAsIDMwKSxcclxuICAgICAgdHdlZXRfa2V5czogcHJvYmVGaXJzdFR5cGVTaGFwZShyZXNwb25zZSwgJ1R3ZWV0JyksXHJcbiAgICAgIHR3ZWV0X2NvcmVfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgWydjb3JlJ10pLFxyXG4gICAgICB0d2VldF9sZWdhY3lfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgWydsZWdhY3knXSksXHJcbiAgICAgIHVzZXJfcmVzdWx0c19yZXN1bHRfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xyXG4gICAgICAgICdjb3JlJyxcclxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcclxuICAgICAgICAncmVzdWx0JyxcclxuICAgICAgXSksXHJcbiAgICAgIHVzZXJfcmVzdWx0c19yZXN1bHRfY29yZV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXHJcbiAgICAgICAgJ2NvcmUnLFxyXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxyXG4gICAgICAgICdyZXN1bHQnLFxyXG4gICAgICAgICdjb3JlJyxcclxuICAgICAgXSksXHJcbiAgICAgIHVzZXJfcmVzdWx0c19yZXN1bHRfbGVnYWN5X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcclxuICAgICAgICAnY29yZScsXHJcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXHJcbiAgICAgICAgJ3Jlc3VsdCcsXHJcbiAgICAgICAgJ2xlZ2FjeScsXHJcbiAgICAgIF0pLFxyXG4gICAgfSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGF3YWl0IGluZm8oJ2dyYXBocWwgcGF5bG9hZCBzZWVuJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgb2JzZXJ2ZWQ6IG5vcm1hbGl6ZWQub2JzZXJ2ZWRfaWRzLmxlbmd0aCxcclxuICAgICAga2VwdDogbm9ybWFsaXplZC50d2VldHMubGVuZ3RoLFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBpZiAobm9ybWFsaXplZC51bmF2YWlsYWJsZV90d2VldHMubGVuZ3RoID4gMCkge1xyXG4gICAgYXdhaXQgcmVjb3JkVW5hdmFpbGFibGVUd2VldHMoXHJcbiAgICAgIG5vcm1hbGl6ZWQudW5hdmFpbGFibGVfdHdlZXRzLFxyXG4gICAgICB0cmFja2VkLFxyXG4gICAgICBjYXB0dXJlZEF0LFxyXG4gICAgICB1cmwsXHJcbiAgICAgIGVuZHBvaW50XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgaWYgKG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG5cclxuICAvLyBSZWZldGNoIHF1ZXVlIGhvdXNla2VlcGluZyBcdTIwMTQgcnVucyBCRUZPUkUgdGhlIGRlZHVwIHNob3J0LWNpcmN1aXQuIEFcclxuICAvLyByZWZldGNoIGNhcHR1cmUgY29tZXMgYmFjayB3aXRoIHRoZSBzYW1lIGVuZ2FnZW1lbnQgY291bnRzICh3ZSdyZVxyXG4gIC8vIG9ubHkgYWZ0ZXIgdGhlIGZ1bGwgdGV4dCksIHNvIHRoZSBkZWR1cCBiZWxvdyB3b3VsZCBzaWxlbnRseSBkcm9wXHJcbiAgLy8gaXQgYW5kIHRoZSBxdWV1ZSB3b3VsZCBuZXZlciBkcmFpbi4gSG9pc3QgdGhlIGVucXVldWUvZGVxdWV1ZSBoZXJlXHJcbiAgLy8gc28gdGhlIGxvb3AgcmVsaWFibHkgYWR2YW5jZXMgZXZlbiB3aGVuIG5vIGNvbW1pdCBoYXBwZW5zLlxyXG4gIC8vXHJcbiAgLy8gQWxzbzogaWYgZWl0aGVyIGxvb3AncyBpbmZsaWdodCB0YXJnZXQgYXBwZWFycyBoZXJlLCBtYXJrIHRoZSBsb29wXHJcbiAgLy8gYXMgXCJpbmdlc3RlZFwiIHNvIHRoZSBuZXh0IHRpY2sgY2FuIGFkdmFuY2UuIFRoZSB3YWl0LWZvci1pbmdlc3RcclxuICAvLyBndWFyZCBvdGhlcndpc2UgYmxvY2tzIHVudGlsIHRoZSBuYXZpZ2F0aW9uLXRpbWVvdXQgZmlyZXMuXHJcbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xyXG4gIGNvbnN0IG1lZGlhQ3Jhd2xTZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcclxuICBmb3IgKGNvbnN0IHQgb2Ygbm9ybWFsaXplZC50d2VldHMpIHtcclxuICAgIGlmICh0LmlzX3RydW5jYXRlZCkge1xyXG4gICAgICBhd2FpdCBlbnF1ZXVlUmVmZXRjaCh0LmFjY291bnRfaGFuZGxlLCB0LnR3ZWV0X2lkKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xyXG4gICAgfVxyXG4gICAgLy8gU3VjY2Vzc2Z1bGx5IGJ1aWx0IHR3ZWV0cyBhcmUgbm8gbG9uZ2VyIFwicGFydGlhbFwiIFx1MjAxNCBkcm9wIGZyb20gdGhlXHJcbiAgICAvLyBtZWRpYS1jcmF3bCBxdWV1ZSByZWdhcmRsZXNzIG9mIHdoaWNoIGhhbmRsZSB3ZSdkIGhpbnRlZCBlYXJsaWVyLlxyXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodC50d2VldF9pZCk7XHJcbiAgICBpZiAocmVmZXRjaFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XHJcbiAgICAgIHJlZmV0Y2hTZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgICAgcmVmZXRjaFNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHJlZmV0Y2hTZXNzKTtcclxuICAgIH1cclxuICAgIGlmIChtZWRpYUNyYXdsU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcclxuICAgICAgbWVkaWFDcmF3bFNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgICBtZWRpYUNyYXdsU2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obWVkaWFDcmF3bFNlc3MpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IHR3ZWV0LXNoYXBlZCBub2RlcyB0aGUgd2Fsa2VyIHNhdyBidXQgY291bGRuJ3QgdHVyblxyXG4gIC8vIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gRW5xdWV1ZSBvbmx5IElEcyB3ZSBoYXZlbid0IGFscmVhZHlcclxuICAvLyBjb21taXR0ZWQgKHVzZXItcmVxdWVzdGVkIGRlZHVwIGFnYWluc3QgdGhlIGFyY2hpdmUpLlxyXG4gIGZvciAoY29uc3QgcGFydGlhbCBvZiBub3JtYWxpemVkLnBhcnRpYWxfaWRzKSB7XHJcbiAgICBpZiAoYXdhaXQgaXNDb21taXR0ZWQocGFydGlhbC50d2VldF9pZCkpIGNvbnRpbnVlO1xyXG4gICAgYXdhaXQgZW5xdWV1ZU1lZGlhQ3Jhd2wocGFydGlhbC5oaW50X2hhbmRsZSwgcGFydGlhbC50d2VldF9pZCk7XHJcbiAgfVxyXG4gIGlmIChub3JtYWxpemVkLnBhcnRpYWxfaWRzLmxlbmd0aCA+IDApIHtcclxuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsOiBlbnF1ZXVlZCBwYXJ0aWFsIGNhcHR1cmVzJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgcGFydGlhbDogbm9ybWFsaXplZC5wYXJ0aWFsX2lkcy5sZW5ndGgsXHJcbiAgICAgIHF1ZXVlX3RvdGFsOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvLyBDcm9zcy1zZXNzaW9uIGRlZHVwOiBkcm9wIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IGNvbW1pdHRlZCB3aXRoIGlkZW50aWNhbFxyXG4gIC8vIGVuZ2FnZW1lbnQgY291bnRzLiBMaWtlcy9SVHMvcmVwbGllcy9xdW90ZXMgc3RpbGwgdHJpZ2dlciBhIHJlY2FwdHVyZVxyXG4gIC8vIHNvIGVuZ2FnZW1lbnRfaGlzdG9yeSBncm93cyBvdmVyIHRpbWUuIHZpZXdfY291bnQgaXMgaW50ZW50aW9uYWxseVxyXG4gIC8vIGV4Y2x1ZGVkIFx1MjAxNCBpdCBjaHVybnMgdG9vIGZhc3QgdG8gYmUgdXNlZnVsIGFzIGEgZnJlc2huZXNzIHNpZ25hbC5cclxuICAvLyBgaXNfdHJ1bmNhdGVkYCBpcyBwYXJ0IG9mIHRoZSBzaWduYXR1cmUgc28gYSByZWZldGNoIHRoYXQgZmxpcHNcclxuICAvLyB0cnVuY2F0ZWRcdTIxOTJmdWxsIGlzIHRyZWF0ZWQgYXMgYSBtYXRlcmlhbCBjaGFuZ2UgYW5kIGdldHMgY29tbWl0dGVkLlxyXG4gIC8vXHJcbiAgLy8gV2hlbiB0aGUgdXNlciBoYXMgdHVybmVkIG9mZiBcInVwZGF0ZSBleGlzdGluZ1wiLCB3ZSBza2lwIHRoZSBlbmdhZ2VtZW50XHJcbiAgLy8gY29tcGFyaXNvbiBlbnRpcmVseTogYW55IHR3ZWV0IHRoYXQncyBhbHJlYWR5IGNvbW1pdHRlZCB1bmRlciBhbnlcclxuICAvLyBoYW5kbGUgZ2V0cyBkcm9wcGVkIGhlcmUsIHNvIHdlIGRvbid0IHBheSBHaXRIdWItQVBJIG92ZXJoZWFkIGp1c3QgdG9cclxuICAvLyByZWZyZXNoIGxpa2UgLyBSVCBjb3VudHMuIE5ldyB0d2VldHMgYW5kIHRydW5jYXRlZFx1MjE5MmZ1bGwgcmVmZXRjaGVzXHJcbiAgLy8gc3RpbGwgZmxvdyB0aHJvdWdoIG5vcm1hbGx5IGJlY2F1c2UgdGhleSBhcmVuJ3QgaW4gdGhlIGluZGV4IHlldFxyXG4gIC8vIChvciBjYXJyeSBhbiBpc190cnVuY2F0ZWQgdHJhbnNpdGlvbiB0aGF0IGZhaWxzIHRoZSBzaWcgY2hlY2spLlxyXG4gIGNvbnN0IHVwZGF0ZUV4aXN0aW5nID0gc2V0dGluZ3MudXBkYXRlRXhpc3RpbmcgIT09IGZhbHNlO1xyXG4gIGNvbnN0IGNvbW1pdHRlZElkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgY29uc3QgYXJjaGl2ZVNuYXBzaG90ID0gYXdhaXQgZ2V0QXJjaGl2ZVNuYXBzaG90KCk7XHJcbiAgbGV0IGRlZHVwZWRTa2lwcGVkID0gMDtcclxuICBsZXQgc2tpcHBlZE5vVXBkYXRlTG9jYWwgPSAwO1xyXG4gIGxldCBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCA9IDA7XHJcbiAgbGV0IG9sZEZyb21TbmFwc2hvdCA9IDA7XHJcbiAgY29uc3QgbGl2ZVR3ZWV0czogdHlwZW9mIG5vcm1hbGl6ZWQudHdlZXRzID0gW107XHJcbiAgY29uc3QgZnJlc2huZXNzQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCAnbmV3JyB8ICdleGlzdGluZyc+KCk7XHJcbiAgY29uc3QgYWN0aW9uQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCBUd2VldFNpZ2h0aW5nWydhY3Rpb24nXT4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2Ygbm9ybWFsaXplZC50d2VldHMpIHtcclxuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbdC5hY2NvdW50X2hhbmRsZV0/Llt0LnR3ZWV0X2lkXTtcclxuICAgIGNvbnN0IG9sZEJ5U25hcHNob3QgPSAhcHJldiAmJiBhcmNoaXZlU25hcHNob3RIYXNUd2VldCh0LCBhcmNoaXZlU25hcHNob3QpO1xyXG4gICAgY29uc3QgcHJldmlvdXNseUFyY2hpdmVkID0gQm9vbGVhbihwcmV2KSB8fCBvbGRCeVNuYXBzaG90O1xyXG4gICAgZnJlc2huZXNzQnlJZC5zZXQodC50d2VldF9pZCwgcHJldmlvdXNseUFyY2hpdmVkID8gJ2V4aXN0aW5nJyA6ICduZXcnKTtcclxuICAgIGlmIChvbGRCeVNuYXBzaG90KSBvbGRGcm9tU25hcHNob3QgKz0gMTtcclxuICAgIGlmIChwcmV2aW91c2x5QXJjaGl2ZWQgJiYgIXVwZGF0ZUV4aXN0aW5nKSB7XHJcbiAgICAgIGlmIChwcmV2KSBza2lwcGVkTm9VcGRhdGVMb2NhbCArPSAxO1xyXG4gICAgICBlbHNlIHNraXBwZWROb1VwZGF0ZVNuYXBzaG90ICs9IDE7XHJcbiAgICAgIGFjdGlvbkJ5SWQuc2V0KHQudHdlZXRfaWQsICdza2lwcGVkJyk7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgY29uc3Qgc2lnID0gZW5nYWdlbWVudFNpZyhcclxuICAgICAgdC5saWtlX2NvdW50LFxyXG4gICAgICB0LnJldHdlZXRfY291bnQsXHJcbiAgICAgIHQucmVwbHlfY291bnQsXHJcbiAgICAgIHQucXVvdGVfY291bnQsXHJcbiAgICAgIHQuaXNfdHJ1bmNhdGVkXHJcbiAgICApO1xyXG4gICAgaWYgKHByZXYgJiYgcHJldi5zaWcgPT09IHNpZykge1xyXG4gICAgICBkZWR1cGVkU2tpcHBlZCArPSAxO1xyXG4gICAgICBhY3Rpb25CeUlkLnNldCh0LnR3ZWV0X2lkLCAndW5jaGFuZ2VkJyk7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgYWN0aW9uQnlJZC5zZXQodC50d2VldF9pZCwgJ2J1ZmZlcmVkJyk7XHJcbiAgICBsaXZlVHdlZXRzLnB1c2godCk7XHJcbiAgfVxyXG4gIGlmIChkZWR1cGVkU2tpcHBlZCA+IDApIHtcclxuICAgIGF3YWl0IGluZm8oJ2RlZHVwOiBza2lwcGVkIHVuY2hhbmdlZCB0d2VldHMnLCB7XHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICBza2lwcGVkOiBkZWR1cGVkU2tpcHBlZCxcclxuICAgICAgcmVtYWluaW5nOiBsaXZlVHdlZXRzLmxlbmd0aCxcclxuICAgIH0pO1xyXG4gIH1cclxuICBpZiAoc2tpcHBlZE5vVXBkYXRlTG9jYWwgKyBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCA+IDApIHtcclxuICAgIGNvbnN0IHNraXBwZWRPbGQgPSBza2lwcGVkTm9VcGRhdGVMb2NhbCArIHNraXBwZWROb1VwZGF0ZVNuYXBzaG90O1xyXG4gICAgYXdhaXQgaW5mbygnZGVkdXA6IHNraXBwZWQgcHJldmlvdXNseSBhcmNoaXZlZCB0d2VldHMgKHVwZGF0ZUV4aXN0aW5nPWZhbHNlKScsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIHNraXBwZWQ6IHNraXBwZWRPbGQsXHJcbiAgICAgIGxvY2FsX2luZGV4OiBza2lwcGVkTm9VcGRhdGVMb2NhbCxcclxuICAgICAgYXJjaGl2ZV9zbmFwc2hvdDogc2tpcHBlZE5vVXBkYXRlU25hcHNob3QsXHJcbiAgICAgIHJlbWFpbmluZzogbGl2ZVR3ZWV0cy5sZW5ndGgsXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IGFzU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgICBpZiAoYXNTZXNzICE9PSBudWxsKSB7XHJcbiAgICAgIGFzU2Vzcy5za2lwcGVkT2xkQ291bnQgPSAoYXNTZXNzLnNraXBwZWRPbGRDb3VudCA/PyAwKSArIHNraXBwZWRPbGQ7XHJcbiAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKGFzU2Vzcyk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGlmIChvbGRGcm9tU25hcHNob3QgPiAwICYmIHVwZGF0ZUV4aXN0aW5nKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdhcmNoaXZlIHNuYXBzaG90IHJlY29nbml6ZWQgb2xkIHR3ZWV0cycsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIG9sZDogb2xkRnJvbVNuYXBzaG90LFxyXG4gICAgICBhY3Rpb246ICdidWZmZXJpbmcgYmVjYXVzZSB1cGRhdGVFeGlzdGluZz10cnVlJyxcclxuICAgICAgc25hcHNob3RfZ2VuZXJhdGVkX2F0OiBhcmNoaXZlU25hcHNob3Q/LmdlbmVyYXRlZF9hdCA/PyBudWxsLFxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGF3YWl0IHByZXBlbmRSZWNlbnRUd2VldFNpZ2h0aW5ncyhcclxuICAgIG5vcm1hbGl6ZWQudHdlZXRzLm1hcCgodCkgPT5cclxuICAgICAgYnVpbGRUd2VldFNpZ2h0aW5nKHQsIGVuZHBvaW50LCBjYXB0dXJlZEF0LCBmcmVzaG5lc3NCeUlkLmdldCh0LnR3ZWV0X2lkKSwgYWN0aW9uQnlJZC5nZXQodC50d2VldF9pZCkpXHJcbiAgICApXHJcbiAgKTtcclxuICAvLyAtLS0gTWlzc2luZy1wYXJlbnQgcmVjb3ZlcnkgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gIC8vIFgncyBVc2VyVHdlZXRzQW5kUmVwbGllcyBlbmRwb2ludCBzb21ldGltZXMgc2VydmVzIGEgcmVwbHkgd2l0aG91dCB0aGVcclxuICAvLyBwYXJlbnQgdHdlZXQgaXQgcG9pbnRzIGF0IFx1MjAxNCBvbmx5IGFuIGluX3JlcGx5X3RvX3NjcmVlbl9uYW1lIGFuY2hvci4gV2VcclxuICAvLyBuZXZlciBzZWUgdGhhdCBwYXJlbnQsIHNvIGl0IG5ldmVyIGxhbmRzIGluIHRoZSBhcmNoaXZlLiBTYW1lIGZvclxyXG4gIC8vIHF1b3RlZF90d2VldF9pZCAvIHJldHdlZXRlZF90d2VldF9pZCB3aGVuIFggc3RyaXBzIHRoZSByZWZlcmVuY2VkXHJcbiAgLy8gbm9kZS4gV2FsayB0aGUgdHdlZXRzIHdlIGp1c3Qgc2F3LCBmaW5kIGFueSBwYXJlbnQgSUQgd2UgZG9uJ3QgaGF2ZSxcclxuICAvLyBhbmQgZW5xdWV1ZSBpdCBvbiB0aGUgbWVkaWEtY3Jhd2wgbG9vcCBzbyBpdHMgZGV0YWlsIHBhZ2UgZ2V0c1xyXG4gIC8vIHZpc2l0ZWQgYW5kIGluZ2VzdGVkIG5leHQgdGltZSB0aGUgdXNlciBzdGFydHMgdGhlIGNyYXdsLlxyXG4gIGF3YWl0IGVucXVldWVNaXNzaW5nUGFyZW50cyhub3JtYWxpemVkLnR3ZWV0cywgZW5kcG9pbnQpO1xyXG4gIGlmIChsaXZlVHdlZXRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG5cclxuICAvLyBHcm91cCBzdXJ2aXZpbmcgdHdlZXRzIGJ5IGF1dGhvciBoYW5kbGUuXHJcbiAgY29uc3QgYnlIYW5kbGUgPSBuZXcgTWFwPHN0cmluZywgQ2Fub25pY2FsVHdlZXRbXT4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2YgbGl2ZVR3ZWV0cykge1xyXG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUpID8/IFtdO1xyXG4gICAgYXJyLnB1c2godCk7XHJcbiAgICBieUhhbmRsZS5zZXQodC5hY2NvdW50X2hhbmRsZSwgYXJyKTtcclxuICB9XHJcblxyXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgdHdlZXRzXSBvZiBieUhhbmRsZSkge1xyXG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgdXJsLCBlbmRwb2ludCk7XHJcbiAgICBsZXQgYWRkZWQgPSAwO1xyXG4gICAgbGV0IGFkZGVkTmV3ID0gMDtcclxuICAgIGxldCBhZGRlZEV4aXN0aW5nID0gMDtcclxuICAgIGxldCB1cGRhdGVkQnVmZmVyZWQgPSAwO1xyXG4gICAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xyXG4gICAgICBjb25zdCBleGlzdGluZyA9IGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF07XHJcbiAgICAgIGlmIChleGlzdGluZykge1xyXG4gICAgICAgIC8vIFByZXNlcnZlIGZpcnN0X2NhcHR1cmVkX2F0LCBhcHBlbmQgZW5nYWdlbWVudCBzbmFwc2hvdCwgcmVmcmVzaFxyXG4gICAgICAgIC8vIGxhc3Rfc2Vlbl9hdCArIGNvdW50cyAodGhlIGxhdGVzdCBzY3JhcGUgd2lucyBmb3IgY291bnRzKS5cclxuICAgICAgICBleGlzdGluZy5sYXN0X3NlZW5fYXQgPSBjYXB0dXJlZEF0O1xyXG4gICAgICAgIGV4aXN0aW5nLmxpa2VfY291bnQgPSB0Lmxpa2VfY291bnQ7XHJcbiAgICAgICAgZXhpc3RpbmcucmV0d2VldF9jb3VudCA9IHQucmV0d2VldF9jb3VudDtcclxuICAgICAgICBleGlzdGluZy5yZXBseV9jb3VudCA9IHQucmVwbHlfY291bnQ7XHJcbiAgICAgICAgZXhpc3RpbmcucXVvdGVfY291bnQgPSB0LnF1b3RlX2NvdW50O1xyXG4gICAgICAgIGV4aXN0aW5nLnZpZXdfY291bnQgPSB0LnZpZXdfY291bnQ7XHJcbiAgICAgICAgZXhpc3RpbmcuYm9va21hcmtfY291bnQgPSB0LmJvb2ttYXJrX2NvdW50O1xyXG4gICAgICAgIGNvbnN0IGxhc3QgPSBleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnlbZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5Lmxlbmd0aCAtIDFdO1xyXG4gICAgICAgIGNvbnN0IHNuYXAgPSB0LmVuZ2FnZW1lbnRfaGlzdG9yeVswXTtcclxuICAgICAgICBpZiAoc25hcCAmJiAoIWxhc3QgfHwgbGFzdC5jYXB0dXJlZF9hdCAhPT0gc25hcC5jYXB0dXJlZF9hdCkpIHtcclxuICAgICAgICAgIGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeS5wdXNoKHNuYXApO1xyXG4gICAgICAgIH1cclxuICAgICAgICB1cGRhdGVkQnVmZmVyZWQgKz0gMTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zdCBzdGFtcGVkOiBDYW5vbmljYWxUd2VldCA9IHsgLi4udCwgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQgfTtcclxuICAgICAgICBidWYudHdlZXRzX2J5X2lkW3QudHdlZXRfaWRdID0gc3RhbXBlZDtcclxuICAgICAgICBhZGRlZCArPSAxO1xyXG4gICAgICAgIGlmIChmcmVzaG5lc3NCeUlkLmdldCh0LnR3ZWV0X2lkKSA9PT0gJ2V4aXN0aW5nJykgYWRkZWRFeGlzdGluZyArPSAxO1xyXG4gICAgICAgIGVsc2UgYWRkZWROZXcgKz0gMTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoIWJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQuaW5jbHVkZXModC50d2VldF9pZCkpIHtcclxuICAgICAgICBidWYudHdlZXRfaWRzX29ic2VydmVkLnB1c2godC50d2VldF9pZCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xyXG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XHJcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xyXG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChcclxuICAgICAgaGFuZGxlLFxyXG4gICAgICBPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggKyBPYmplY3Qua2V5cyhidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge30pLmxlbmd0aFxyXG4gICAgKTtcclxuICAgIGlmIChhZGRlZCA+IDAgfHwgdXBkYXRlZEJ1ZmZlcmVkID4gMCkge1xyXG4gICAgICBhd2FpdCBpbmZvKCdidWZmZXJlZCB0d2VldHMnLCB7XHJcbiAgICAgICAgaGFuZGxlLFxyXG4gICAgICAgIGVuZHBvaW50LFxyXG4gICAgICAgIGFkZGVkLFxyXG4gICAgICAgIG5ldzogYWRkZWROZXcsXHJcbiAgICAgICAgZXhpc3Rpbmc6IGFkZGVkRXhpc3RpbmcsXHJcbiAgICAgICAgdXBkYXRlZF9idWZmZXJlZDogdXBkYXRlZEJ1ZmZlcmVkLFxyXG4gICAgICAgIHRvdGFsOiBPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGgsXHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyBCdW1wIHRoZSBhdXRvLXNjcm9sbCBwcm9ncmVzcyBzbyB0aGUgdXNlciBzZWVzIFwiWCBpbmdlc3RlZFwiIHRpY2sgdXBcclxuICAgICAgLy8gaW4gcmVhbCB0aW1lLiBXZSBjb3VudCBhY3R1YWxseS1uZXcgdHdlZXRzLCBub3QgZHVwbGljYXRlcy5cclxuICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICAgICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xyXG4gICAgICAgIGFzU2Vzcy5pbmdlc3RlZENvdW50ICs9IGFkZGVkO1xyXG4gICAgICAgIGFzU2Vzcy5pbmdlc3RlZE5ld0NvdW50ID0gKGFzU2Vzcy5pbmdlc3RlZE5ld0NvdW50ID8/IDApICsgYWRkZWROZXc7XHJcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkRXhpc3RpbmdDb3VudCA9XHJcbiAgICAgICAgICAoYXNTZXNzLmluZ2VzdGVkRXhpc3RpbmdDb3VudCA/PyAwKSArIGFkZGVkRXhpc3Rpbmc7XHJcbiAgICAgICAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oYXNTZXNzKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCA+PSBGTFVTSF9UV0VFVF9USFJFU0hPTEQpIHtcclxuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUoaGFuZGxlLCAndGhyZXNob2xkJyk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlY29yZFVuYXZhaWxhYmxlVHdlZXRzKFxyXG4gIHVuYXZhaWxhYmxlVHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W10sXHJcbiAgdHJhY2tlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPixcclxuICBjYXB0dXJlZEF0OiBzdHJpbmcsXHJcbiAgc291cmNlVXJsOiBzdHJpbmcsXHJcbiAgZW5kcG9pbnQ6IHN0cmluZ1xyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBjb21taXR0ZWRJZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGNvbnN0IHJlZmV0Y2hTZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcclxuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XHJcbiAgbGV0IHJlY29yZGVkID0gMDtcclxuICBsZXQgc2tpcHBlZCA9IDA7XHJcbiAgbGV0IG1pc3NpbmdIYW5kbGUgPSAwO1xyXG5cclxuICBmb3IgKGNvbnN0IHUgb2YgdW5hdmFpbGFibGVUd2VldHMpIHtcclxuICAgIGNvbnN0IGhhbmRsZSA9IHUuYWNjb3VudF9oYW5kbGU7XHJcbiAgICBpZiAoIWhhbmRsZSkge1xyXG4gICAgICBtaXNzaW5nSGFuZGxlICs9IDE7XHJcbiAgICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHUudHdlZXRfaWQpO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmICh0cmFja2VkLnNpemUgPiAwICYmICF0cmFja2VkLmhhcyhoYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcclxuICAgICAgc2tpcHBlZCArPSAxO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh1LnR3ZWV0X2lkKTtcclxuICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKGhhbmRsZSwgdS50d2VldF9pZCk7XHJcbiAgICBpZiAocmVmZXRjaFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB1LnR3ZWV0X2lkKSB7XHJcbiAgICAgIHJlZmV0Y2hTZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgICAgcmVmZXRjaFNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHJlZmV0Y2hTZXNzKTtcclxuICAgIH1cclxuICAgIGlmIChtZWRpYUNyYXdsU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHUudHdlZXRfaWQpIHtcclxuICAgICAgbWVkaWFDcmF3bFNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgICBtZWRpYUNyYXdsU2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obWVkaWFDcmF3bFNlc3MpO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHNpZyA9IHVuYXZhaWxhYmxlU2lnKHUpO1xyXG4gICAgY29uc3QgcHJldiA9IGNvbW1pdHRlZElkeFtoYW5kbGVdPy5bdS50d2VldF9pZF07XHJcbiAgICBpZiAocHJldj8uc2lnID09PSBzaWcpIHtcclxuICAgICAgc2tpcHBlZCArPSAxO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBidWYgPSBhd2FpdCBlbnN1cmVSdW5CdWZmZXIoaGFuZGxlLCBjYXB0dXJlZEF0LCBzb3VyY2VVcmwsIGVuZHBvaW50KTtcclxuICAgIGNvbnN0IHVuYXZhaWxhYmxlQnlJZCA9IGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fTtcclxuICAgIHVuYXZhaWxhYmxlQnlJZFt1LnR3ZWV0X2lkXSA9IHU7XHJcbiAgICBidWYudW5hdmFpbGFibGVfYnlfaWQgPSB1bmF2YWlsYWJsZUJ5SWQ7XHJcbiAgICBpZiAoIWJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQuaW5jbHVkZXModS50d2VldF9pZCkpIHtcclxuICAgICAgYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5wdXNoKHUudHdlZXRfaWQpO1xyXG4gICAgfVxyXG4gICAgaWYgKCFidWYuZW5kcG9pbnRzX3NlZW4uaW5jbHVkZXMoZW5kcG9pbnQpKSBidWYuZW5kcG9pbnRzX3NlZW4ucHVzaChlbmRwb2ludCk7XHJcbiAgICBidWYubGFzdF9jYXB0dXJlX2F0ID0gY2FwdHVyZWRBdDtcclxuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XHJcbiAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KFxyXG4gICAgICBoYW5kbGUsXHJcbiAgICAgIE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCArIE9iamVjdC5rZXlzKHVuYXZhaWxhYmxlQnlJZCkubGVuZ3RoXHJcbiAgICApO1xyXG4gICAgcmVjb3JkZWQgKz0gMTtcclxuICB9XHJcblxyXG4gIGlmIChyZWNvcmRlZCA+IDAgfHwgbWlzc2luZ0hhbmRsZSA+IDAgfHwgc2tpcHBlZCA+IDApIHtcclxuICAgIGF3YWl0IGluZm8oJ3VuYXZhaWxhYmxlIHR3ZWV0cyBvYnNlcnZlZCcsIHsgZW5kcG9pbnQsIHJlY29yZGVkLCBza2lwcGVkLCBtaXNzaW5nSGFuZGxlIH0pO1xyXG4gIH1cclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiB1bmF2YWlsYWJsZVNpZyh1OiBVbmF2YWlsYWJsZVR3ZWV0KTogc3RyaW5nIHtcclxuICByZXR1cm4gYHVuYXZhaWxhYmxlfCR7dS51bmF2YWlsYWJsZV9yZWFzb24gPz8gJyd9fCR7dS51bmF2YWlsYWJsZV90ZXh0ID8/ICcnfWA7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGaW5kIGV2ZXJ5IHBhcmVudCB0d2VldCByZWZlcmVuY2VkIGJ5IHRoZSBjYXB0dXJlcyB3ZSBqdXN0IGluZ2VzdGVkXHJcbiAqIChgcmVwbHlfdG9fdHdlZXRfaWRgLCBgcXVvdGVkX3R3ZWV0X2lkYCwgYHJldHdlZXRlZF90d2VldF9pZGApIHRoYXQgd2VcclxuICogZG9uJ3QgeWV0IGhhdmUgaW4gdGhlIGFyY2hpdmUsIGFuZCBlbnF1ZXVlIGl0IG9uIHRoZSBtZWRpYS1jcmF3bCBsb29wLlxyXG4gKlxyXG4gKiBXaHk6IFgncyBVc2VyVHdlZXRzQW5kUmVwbGllcyBlbmRwb2ludCBzb21ldGltZXMgcmV0dXJucyBhIHRyYWNrZWRcclxuICogYWNjb3VudCdzIHJlcGx5ICp3aXRob3V0KiB0aGUgcGFyZW50IGl0IHBvaW50cyBhdC4gVGhlIGByZXBseV90b18qYFxyXG4gKiBmaWVsZHMgb24gdGhlIHJlcGx5IHN0aWxsIGdldCBzZXQgZnJvbSBgaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0cmAsIGJ1dFxyXG4gKiBgZmlsdGVyUmVsYXRlZGAgaGFzIG5vdGhpbmcgdG8ga2VlcCBcdTIwMTQgdGhlcmUgaXMgbm8gcGFyZW50IG5vZGUgaW4gdGhlXHJcbiAqIGJhdGNoIHRvIGtlZXAuIFJlc3VsdDogdGhlIGFyY2hpdmUgc2hvd3MgREhTZ292J3MgcmVwbHkgYnV0IG5vdCB0aGVcclxuICogb3JpZ2luYWwgaXQncyByZXBseWluZyB0by4gU3ltbWV0cmljIHByb2JsZW0gZm9yIG9ycGhhbmVkIHF1b3RlIC8gUlRcclxuICogcG9pbnRlcnMuXHJcbiAqXHJcbiAqIFJldXNpbmcgdGhlIG1lZGlhLWNyYXdsIHF1ZXVlICsgbG9vcCBtZWFucyBubyBuZXcgVUk7IHRoZSB1c2VyIGFscmVhZHlcclxuICogc3RhcnRzIGl0IG1hbnVhbGx5IHdoZW4gdGhleSB3YW50IHRvIGZldGNoIHBhcnRpYWwtY2FwdHVyZWQgdHdlZXRzLlxyXG4gKiBTYW1lIGRlZHVwIHJ1bGVzIGFwcGx5IChjb21taXR0ZWQgXHUyMTkyIHNraXA7IGFscmVhZHkgcXVldWVkIFx1MjE5MiBuby1vcCkuXHJcbiAqXHJcbiAqIFdlIG9ubHkgd2FsayB0aGUgdHdlZXRzIHRoYXQgc3Vydml2ZWQgYGZpbHRlclJlbGF0ZWRgIHNvIHdlIGRvbid0IGNyYXdsXHJcbiAqIHBhcmVudHMgb2YgcmFuZG9tIHJlcGxpZXMgdGhhdCB3b3VsZG4ndCBoYXZlIGJlZW4ga2VwdCBhbnl3YXkuXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBlbnF1ZXVlTWlzc2luZ1BhcmVudHMoXHJcbiAgdHdlZXRzOiBSZWFkb25seUFycmF5PENhbm9uaWNhbFR3ZWV0PixcclxuICBlbmRwb2ludDogc3RyaW5nXHJcbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGlmICh0d2VldHMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcbiAgLy8gQnVpbGQgYSBzYW1lLWJhdGNoIElEIHNldCBzbyB3ZSBkb24ndCBlbnF1ZXVlIGEgcGFyZW50IHRoYXQgYWxyZWFkeVxyXG4gIC8vIGFycml2ZWQgaW4gdGhpcyB2ZXJ5IHJlc3BvbnNlLlxyXG4gIGNvbnN0IHNhbWVCYXRjaElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHNhbWVCYXRjaElkcy5hZGQodC50d2VldF9pZCk7XHJcblxyXG4gIGxldCBlbnF1ZXVlZCA9IDA7XHJcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xyXG4gICAgY29uc3QgcGFyZW50czogQXJyYXk8eyBpZDogc3RyaW5nOyBoaW50OiBzdHJpbmcgfCBudWxsIH0+ID0gW107XHJcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCkge1xyXG4gICAgICBwYXJlbnRzLnB1c2goeyBpZDogdC5yZXBseV90b190d2VldF9pZCwgaGludDogdC5yZXBseV90b19hY2NvdW50IH0pO1xyXG4gICAgfVxyXG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkKSBwYXJlbnRzLnB1c2goeyBpZDogdC5xdW90ZWRfdHdlZXRfaWQsIGhpbnQ6IG51bGwgfSk7XHJcbiAgICBpZiAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpIHBhcmVudHMucHVzaCh7IGlkOiB0LnJldHdlZXRlZF90d2VldF9pZCwgaGludDogbnVsbCB9KTtcclxuICAgIGZvciAoY29uc3QgcCBvZiBwYXJlbnRzKSB7XHJcbiAgICAgIGlmIChzYW1lQmF0Y2hJZHMuaGFzKHAuaWQpKSBjb250aW51ZTtcclxuICAgICAgaWYgKGF3YWl0IGlzQ29tbWl0dGVkKHAuaWQpKSBjb250aW51ZTtcclxuICAgICAgYXdhaXQgZW5xdWV1ZU1lZGlhQ3Jhd2wocC5oaW50LCBwLmlkKTtcclxuICAgICAgZW5xdWV1ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKGVucXVldWVkID4gMCkge1xyXG4gICAgYXdhaXQgaW5mbygncXVldWVkIG1pc3NpbmcgcGFyZW50IHR3ZWV0cyBmb3IgZGV0YWlsLXBhZ2UgY3Jhd2wnLCB7XHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICBlbnF1ZXVlZCxcclxuICAgICAgcXVldWVfdG90YWw6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZVJ1bkJ1ZmZlcihcclxuICBoYW5kbGU6IHN0cmluZyxcclxuICB0czogc3RyaW5nLFxyXG4gIHNvdXJjZVVybDogc3RyaW5nLFxyXG4gIGVuZHBvaW50OiBzdHJpbmdcclxuKTogUHJvbWlzZTxSdW5CdWZmZXI+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRSdW5CdWZmZXIoaGFuZGxlKTtcclxuICBpZiAoY3VyKSByZXR1cm4gY3VyO1xyXG4gIGNvbnN0IGJ1ZjogUnVuQnVmZmVyID0ge1xyXG4gICAgcnVuX2lkOiBuZXdSdW5JZCgpLFxyXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcclxuICAgIHN0YXJ0ZWRfYXQ6IHRzLFxyXG4gICAgbGFzdF9jYXB0dXJlX2F0OiB0cyxcclxuICAgIHR3ZWV0c19ieV9pZDoge30sXHJcbiAgICB1bmF2YWlsYWJsZV9ieV9pZDoge30sXHJcbiAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IFtdLFxyXG4gICAgZW5kcG9pbnRzX3NlZW46IFtlbmRwb2ludF0sXHJcbiAgICBzb3VyY2VfdXJsOiBzb3VyY2VVcmwsXHJcbiAgfTtcclxuICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xyXG4gIGF3YWl0IGluZm8oJ3J1biBzdGFydGVkJywgeyBoYW5kbGUsIHJ1bjogc2hvcnRSdW5JZChidWYucnVuX2lkKSB9KTtcclxuICByZXR1cm4gYnVmO1xyXG59XHJcblxyXG4vLyAtLS0gRmx1c2ggbG9naWMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxubGV0IGZsdXNoQ2hhaW46IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKTtcclxuXHJcbmludGVyZmFjZSBGbHVzaEl0ZW0ge1xyXG4gIGhhbmRsZTogc3RyaW5nO1xyXG4gIGJ1ZjogUnVuQnVmZmVyO1xyXG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcclxuICB1bmF2YWlsYWJsZVR3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdO1xyXG4gIHJhd1BhdGg6IHN0cmluZztcclxuICBzZWVuUGF0aDogc3RyaW5nO1xyXG4gIGNhcHR1cmU6IENhcHR1cmVQYXlsb2FkO1xyXG4gIHNlZW46IFNlZW5QYXlsb2FkO1xyXG4gIGRheTogc3RyaW5nO1xyXG4gIHJ1blNob3J0OiBzdHJpbmc7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSWRsZUJ1ZmZlcnMoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XHJcbiAgY29uc3QgaGFuZGxlczogc3RyaW5nW10gPSBbXTtcclxuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xyXG4gICAgY29uc3QgbGFzdCA9IERhdGUucGFyc2UoYnVmLmxhc3RfY2FwdHVyZV9hdCk7XHJcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xyXG4gICAgICBoYW5kbGVzLnB1c2goaGFuZGxlKTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKGhhbmRsZXMsICdpZGxlJyk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGZsdXNoT3JwaGFuZWRCdWZmZXJzSWZTdGFsZSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAvLyBPbiB3b3JrZXIgd2FrZSwgYW55IGJ1ZmZlciBvbGRlciB0aGFuIHRoZSBpZGxlIHRocmVzaG9sZCBnZXRzIGEgY2hhbmNlIHRvXHJcbiAgLy8gY29tbWl0IGltbWVkaWF0ZWx5IFx1MjAxNCB1c2VmdWwgd2hlbiB0aGUgd29ya2VyIHdhcyBldmljdGVkIGJlZm9yZSBpZGxlLWZsdXNoLlxyXG4gIC8vIElmIHRoZSBQQVQvb3duZXIvcmVwbyBhcmVuJ3Qgc2V0IHdlJ2QganVzdCBlbWl0IFwiZmx1c2ggZGVmZXJyZWRcIiBmb3IgZXZlcnlcclxuICAvLyBzaW5nbGUgaGFuZGxlIGluIHN0b3JhZ2UgKHRoZSBkaWFnbm9zdGljIHNob3dlZCB0aGlzIGZpcmluZyAzMDArIHRpbWVzIGluXHJcbiAgLy8gYSByb3cgd2hlbiB0aGUgZXh0ZW5zaW9uIHdva2UgYmVmb3JlIHNldHRpbmdzIGxvYWQpLCBzbyBzaG9ydC1jaXJjdWl0XHJcbiAgLy8gaGVyZSBpbnN0ZWFkLlxyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcclxuICBjb25zdCBoYW5kbGVzOiBzdHJpbmdbXSA9IFtdO1xyXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgYnVmXSBvZiBPYmplY3QuZW50cmllcyhhbGwpKSB7XHJcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XHJcbiAgICAgIGhhbmRsZXMucHVzaChoYW5kbGUpO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBmbHVzaEhhbmRsZXMoaGFuZGxlcywgJ3dha2UnKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZmx1c2hBbGwocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKE9iamVjdC5rZXlzKGFsbCksIHJlYXNvbik7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlKGhhbmRsZTogc3RyaW5nLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhbaGFuZGxlXSwgcmVhc29uKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGVzKGhhbmRsZXM6IHN0cmluZ1tdLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHVuaXF1ZSA9IFsuLi5uZXcgU2V0KGhhbmRsZXMpXS5maWx0ZXIoKGgpID0+IGgubGVuZ3RoID4gMCk7XHJcbiAgaWYgKHVuaXF1ZS5sZW5ndGggPT09IDApIHJldHVybjtcclxuICBjb25zdCBydW4gPSBmbHVzaENoYWluLnRoZW4oKCkgPT4gZmx1c2hIYW5kbGVzTG9ja2VkKHVuaXF1ZSwgcmVhc29uKSk7XHJcbiAgZmx1c2hDaGFpbiA9IHJ1bi5jYXRjaCgoKSA9PiB7fSk7XHJcbiAgcmV0dXJuIHJ1bjtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGVzTG9ja2VkKGhhbmRsZXM6IHN0cmluZ1tdLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBjb25zdCBpdGVtczogRmx1c2hJdGVtW10gPSBbXTtcclxuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBoYW5kbGVzKSB7XHJcbiAgICBjb25zdCBidWYgPSBhbGxbaGFuZGxlXTtcclxuICAgIGlmICghYnVmKSBjb250aW51ZTtcclxuICAgIGNvbnN0IHR3ZWV0cyA9IE9iamVjdC52YWx1ZXMoYnVmLnR3ZWV0c19ieV9pZCk7XHJcbiAgICBjb25zdCB1bmF2YWlsYWJsZVR3ZWV0cyA9IE9iamVjdC52YWx1ZXMoYnVmLnVuYXZhaWxhYmxlX2J5X2lkID8/IHt9KTtcclxuICAgIGlmICh0d2VldHMubGVuZ3RoID09PSAwICYmIHVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihoYW5kbGUpO1xyXG4gICAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgMCk7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgaXRlbXMucHVzaChidWlsZEZsdXNoSXRlbShoYW5kbGUsIGJ1ZiwgdHdlZXRzLCB1bmF2YWlsYWJsZVR3ZWV0cykpO1xyXG4gIH1cclxuICBpZiAoaXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHtcclxuICAgIGF3YWl0IHdhcm4oJ2ZsdXNoIGRlZmVycmVkOiBzZXR0aW5ncyBpbmNvbXBsZXRlJywge1xyXG4gICAgICBjb3VudDogaXRlbXMubGVuZ3RoLFxyXG4gICAgICBoYW5kbGVzOiBpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uaGFuZGxlKS5zbGljZSgwLCAyMCksXHJcbiAgICB9KTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XHJcbiAgY29uc3QgZmlsZXMgPSBpdGVtcy5mbGF0TWFwKChpdGVtKSA9PiBbXHJcbiAgICB7XHJcbiAgICAgIHBhdGg6IGl0ZW0ucmF3UGF0aCxcclxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkoaXRlbS5jYXB0dXJlLCBudWxsLCAyKSArICdcXG4nKSxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIHBhdGg6IGl0ZW0uc2VlblBhdGgsXHJcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KGl0ZW0uc2VlbiwgbnVsbCwgMikgKyAnXFxuJyksXHJcbiAgICB9LFxyXG4gIF0pO1xyXG4gIGNvbnN0IGNvbW1pdE1zZyA9IGJ1aWxkQmF0Y2hDb21taXRNZXNzYWdlKGl0ZW1zKTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNsaWVudC5jb21taXRGaWxlcyh7XHJcbiAgICAgIGZpbGVzLFxyXG4gICAgICBtZXNzYWdlOiBjb21taXRNc2csXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgaXRlbXMpIHtcclxuICAgICAgY29uc3QgcmVtYWluaW5nQ291bnQgPSBhd2FpdCBjbGVhckNvbW1pdHRlZFR3ZWV0c0Zyb21CdWZmZXIoaXRlbSk7XHJcbiAgICAgIC8vIENvdW50ZXIgYnVtcDogYWN0dWFsbHkgSU5DUkVNRU5UIHRvZGF5Q291bnQgYW5kIHRvdGFsQ29tbWl0dGVkIGJ5XHJcbiAgICAgIC8vIHRoZSBudW1iZXIgb2YgdHdlZXRzIHdlIGp1c3QgcGVyc2lzdGVkICh0aGUgcHJldmlvdXMgY29kZSByZWFkIHRoZVxyXG4gICAgICAvLyBleGlzdGluZyB2YWx1ZXMgYW5kIHdyb3RlIHRoZW0gYmFjaywgbGVhdmluZyB0aGUgY291bnRlciBwZWdnZWQgYXRcclxuICAgICAgLy8gemVybykuXHJcbiAgICAgIGNvbnN0IHByZXYgPSAoYXdhaXQgZ2V0Q291bnRlcnMoKSlbaXRlbS5oYW5kbGVdO1xyXG4gICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XHJcbiAgICAgIGNvbnN0IGNhcnJpZWRUb2RheSA9IHByZXYgJiYgcHJldi50b2RheURhdGUgPT09IHRvZGF5ID8gcHJldi50b2RheUNvdW50IDogMDtcclxuICAgICAgYXdhaXQgYnVtcENvdW50ZXIoaXRlbS5oYW5kbGUsIHtcclxuICAgICAgICB0b2RheUNvdW50OiBjYXJyaWVkVG9kYXkgKyBpdGVtLnR3ZWV0cy5sZW5ndGggKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCxcclxuICAgICAgICB0b2RheURhdGU6IHRvZGF5LFxyXG4gICAgICAgIGxhc3RDYXB0dXJlQXQ6IGl0ZW0uYnVmLmxhc3RfY2FwdHVyZV9hdCxcclxuICAgICAgICB0b3RhbENvbW1pdHRlZDpcclxuICAgICAgICAgIChwcmV2Py50b3RhbENvbW1pdHRlZCA/PyAwKSArIGl0ZW0udHdlZXRzLmxlbmd0aCArIGl0ZW0udW5hdmFpbGFibGVUd2VldHMubGVuZ3RoLFxyXG4gICAgICAgIGJ1ZmZlcmVkQ291bnQ6IHJlbWFpbmluZ0NvdW50LFxyXG4gICAgICB9KTtcclxuICAgICAgLy8gUmVjb3JkIGNvbW1pdHMgaW4gdGhlIGRlZHVwIGluZGV4IHNvIHdlIGRvbid0IHJlLWNvbW1pdCB0aGVtIG5leHRcclxuICAgICAgLy8gYnJvd3NlIHdpdGggdW5jaGFuZ2VkIGVuZ2FnZW1lbnQuXHJcbiAgICAgIGNvbnN0IGlubmVyID0gaWR4W2l0ZW0uaGFuZGxlXSA/PyB7fTtcclxuICAgICAgY29uc3Qgbm93SXNvID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xyXG4gICAgICBmb3IgKGNvbnN0IHQgb2YgaXRlbS50d2VldHMpIHtcclxuICAgICAgICBpbm5lclt0LnR3ZWV0X2lkXSA9IHtcclxuICAgICAgICAgIHRzOiBub3dJc28sXHJcbiAgICAgICAgICBzaWc6IGVuZ2FnZW1lbnRTaWcoXHJcbiAgICAgICAgICAgIHQubGlrZV9jb3VudCxcclxuICAgICAgICAgICAgdC5yZXR3ZWV0X2NvdW50LFxyXG4gICAgICAgICAgICB0LnJlcGx5X2NvdW50LFxyXG4gICAgICAgICAgICB0LnF1b3RlX2NvdW50LFxyXG4gICAgICAgICAgICB0LmlzX3RydW5jYXRlZFxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9O1xyXG4gICAgICB9XHJcbiAgICAgIGZvciAoY29uc3QgdSBvZiBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzKSB7XHJcbiAgICAgICAgaW5uZXJbdS50d2VldF9pZF0gPSB7XHJcbiAgICAgICAgICB0czogbm93SXNvLFxyXG4gICAgICAgICAgc2lnOiB1bmF2YWlsYWJsZVNpZyh1KSxcclxuICAgICAgICB9O1xyXG4gICAgICB9XHJcbiAgICAgIGlkeFtpdGVtLmhhbmRsZV0gPSBpbm5lcjtcclxuICAgICAgYXdhaXQgaW5mbygnZmx1c2ggY29tbWl0dGVkJywge1xyXG4gICAgICAgIGhhbmRsZTogaXRlbS5oYW5kbGUsXHJcbiAgICAgICAgcmVhc29uLFxyXG4gICAgICAgIHR3ZWV0czogaXRlbS50d2VldHMubGVuZ3RoLFxyXG4gICAgICAgIHVuYXZhaWxhYmxlOiBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCxcclxuICAgICAgICBydW46IGl0ZW0ucnVuU2hvcnQsXHJcbiAgICAgICAgcGF0aDogaXRlbS5yYXdQYXRoLFxyXG4gICAgICAgIGJhdGNoX2NvbW1pdDogcmVzdWx0LmNvbW1pdFNoYSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xyXG4gICAgYXdhaXQgaW5mbygnZmx1c2ggYmF0Y2ggY29tbWl0dGVkJywge1xyXG4gICAgICByZWFzb24sXHJcbiAgICAgIHJ1bnM6IGl0ZW1zLmxlbmd0aCxcclxuICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcclxuICAgICAgdHdlZXRzOiBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udHdlZXRzLmxlbmd0aCwgMCksXHJcbiAgICAgIHVuYXZhaWxhYmxlOiBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udW5hdmFpbGFibGVUd2VldHMubGVuZ3RoLCAwKSxcclxuICAgICAgY29tbWl0OiByZXN1bHQuY29tbWl0U2hhLFxyXG4gICAgfSk7XHJcbiAgICB7XHJcbiAgICAgIGNvbnN0IHByZXYgPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xyXG4gICAgICAgIHN0YXR1czogJ29rJyxcclxuICAgICAgICBsb2dpbjogcHJldi5sb2dpbixcclxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBwcmV2LmRlZmF1bHRCcmFuY2gsXHJcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogcHJldi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxyXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSB7XHJcbiAgICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XHJcbiAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAnYXV0aCdcclxuICAgICAgICAgID8gJ2F1dGgtZXJyb3InXHJcbiAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnXHJcbiAgICAgICAgICAgID8gJ3JhdGUtbGltaXRlZCdcclxuICAgICAgICAgICAgOiBlcnIuY2F0ZWdvcnkgPT09ICduZXR3b3JrJ1xyXG4gICAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXHJcbiAgICAgICAgICAgICAgOiBjb25uLnN0YXR1cztcclxuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgICAgc3RhdHVzLFxyXG4gICAgICAgIGxvZ2luOiBjb25uLmxvZ2luLFxyXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIGVycm9yOiBlcnIubWVzc2FnZSxcclxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBjb25uLmRlZmF1bHRCcmFuY2gsXHJcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogY29ubi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxyXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6XHJcbiAgICAgICAgICBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IGVyci5yYXRlTGltaXRSZXNldEF0IDogY29ubi5yYXRlTGltaXRSZXNldEF0LFxyXG4gICAgICB9KTtcclxuICAgICAgYXdhaXQgbG9nRXJyKCdmbHVzaCBmYWlsZWQnLCB7XHJcbiAgICAgICAgcmVhc29uLFxyXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcclxuICAgICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXHJcbiAgICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcclxuICAgICAgICBjYXRlZ29yeTogZXJyLmNhdGVnb3J5LFxyXG4gICAgICAgIHN0YXR1czogZXJyLnN0YXR1cyxcclxuICAgICAgICBtZXNzYWdlOiBlcnIubWVzc2FnZSxcclxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBlcnIucmF0ZUxpbWl0UmVzZXRBdCxcclxuICAgICAgfSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhd2FpdCBsb2dFcnIoJ2ZsdXNoIGZhaWxlZCcsIHtcclxuICAgICAgICByZWFzb24sXHJcbiAgICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxyXG4gICAgICAgIHJ1bnM6IGl0ZW1zLmxlbmd0aCxcclxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxyXG4gICAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICAvLyBMZWF2ZSBidWZmZXIgaW50YWN0IGZvciByZXRyeS5cclxuICB9IGZpbmFsbHkge1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGJ1aWxkRmx1c2hJdGVtKFxyXG4gIGhhbmRsZTogc3RyaW5nLFxyXG4gIGJ1ZjogUnVuQnVmZmVyLFxyXG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSxcclxuICB1bmF2YWlsYWJsZVR3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdXHJcbik6IEZsdXNoSXRlbSB7XHJcbiAgY29uc3QgdHMgPSBpc29Db21wYWN0KGJ1Zi5zdGFydGVkX2F0KTtcclxuICBjb25zdCBkYXkgPSBidWYuc3RhcnRlZF9hdC5zbGljZSgwLCAxMCk7XHJcbiAgY29uc3QgcnVuU2hvcnQgPSBzaG9ydFJ1bklkKGJ1Zi5ydW5faWQpO1xyXG4gIGNvbnN0IHJhd1BhdGggPSBgcmF3LyR7aGFuZGxlfS8ke3RzfS0ke3J1blNob3J0fS5qc29uYDtcclxuICBjb25zdCBzZWVuUGF0aCA9IGBzZWVuLyR7aGFuZGxlfS8ke3RzfS0ke3J1blNob3J0fS5qc29uYDtcclxuICByZXR1cm4ge1xyXG4gICAgaGFuZGxlLFxyXG4gICAgYnVmLFxyXG4gICAgdHdlZXRzLFxyXG4gICAgdW5hdmFpbGFibGVUd2VldHMsXHJcbiAgICByYXdQYXRoLFxyXG4gICAgc2VlblBhdGgsXHJcbiAgICBkYXksXHJcbiAgICBydW5TaG9ydCxcclxuICAgIGNhcHR1cmU6IHtcclxuICAgICAgc2NoZW1hX3ZlcnNpb246IDEsXHJcbiAgICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxyXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxyXG4gICAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcclxuICAgICAgZW5kcG9pbnQ6IGJ1Zi5lbmRwb2ludHNfc2Vlbi5qb2luKCcsJyksXHJcbiAgICAgIHVzZXJfYWdlbnQ6IG5hdmlnYXRvci51c2VyQWdlbnQsXHJcbiAgICAgIHNvdXJjZV91cmw6IGJ1Zi5zb3VyY2VfdXJsLFxyXG4gICAgICB0d2VldHMsXHJcbiAgICAgIHVuYXZhaWxhYmxlX3R3ZWV0czogdW5hdmFpbGFibGVUd2VldHMsXHJcbiAgICB9LFxyXG4gICAgc2Vlbjoge1xyXG4gICAgICBzY2hlbWFfdmVyc2lvbjogMSxcclxuICAgICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXHJcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXHJcbiAgICAgIGNhcHR1cmVkX2F0OiBidWYubGFzdF9jYXB0dXJlX2F0LFxyXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQsXHJcbiAgICB9LFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGJ1aWxkQmF0Y2hDb21taXRNZXNzYWdlKGl0ZW1zOiBGbHVzaEl0ZW1bXSk6IHN0cmluZyB7XHJcbiAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMSkge1xyXG4gICAgY29uc3QgaXRlbSA9IGl0ZW1zWzBdITtcclxuICAgIGNvbnN0IHVuYXZhaWxhYmxlQ291bnQgPSBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aDtcclxuICAgIGNvbnN0IHN1ZmZpeCA9IHVuYXZhaWxhYmxlQ291bnQgPiAwID8gYCwgJHt1bmF2YWlsYWJsZUNvdW50fSB1bmF2YWlsYWJsZWAgOiAnJztcclxuICAgIHJldHVybiBgY2FwdHVyZTogJHtpdGVtLmhhbmRsZX0gJHtpdGVtLmRheX0gJHtpdGVtLnR3ZWV0cy5sZW5ndGh9IHR3ZWV0JHtpdGVtLnR3ZWV0cy5sZW5ndGggPT09IDEgPyAnJyA6ICdzJ30ke3N1ZmZpeH0gKHJ1biAke2l0ZW0ucnVuU2hvcnR9KWA7XHJcbiAgfVxyXG4gIGNvbnN0IGRheXMgPSBbLi4ubmV3IFNldChpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uZGF5KSldLnNvcnQoKTtcclxuICBjb25zdCBkYXlMYWJlbCA9IGRheXMubGVuZ3RoID09PSAxID8gZGF5c1swXSEgOiBgJHtkYXlzWzBdfS4uJHtkYXlzW2RheXMubGVuZ3RoIC0gMV19YDtcclxuICBjb25zdCB0d2VldENvdW50ID0gaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApO1xyXG4gIGNvbnN0IHVuYXZhaWxhYmxlQ291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udW5hdmFpbGFibGVUd2VldHMubGVuZ3RoLCAwKTtcclxuICBjb25zdCBzdWZmaXggPSB1bmF2YWlsYWJsZUNvdW50ID4gMCA/IGAsICR7dW5hdmFpbGFibGVDb3VudH0gdW5hdmFpbGFibGVgIDogJyc7XHJcbiAgcmV0dXJuIGBjYXB0dXJlIGJhdGNoOiAke2l0ZW1zLmxlbmd0aH0gcnVucywgJHt0d2VldENvdW50fSB0d2VldCR7dHdlZXRDb3VudCA9PT0gMSA/ICcnIDogJ3MnfSR7c3VmZml4fSAoJHtkYXlMYWJlbH0pYDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gY2xlYXJDb21taXR0ZWRUd2VldHNGcm9tQnVmZmVyKGl0ZW06IEZsdXNoSXRlbSk6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgY29uc3QgY3VycmVudCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSk7XHJcbiAgaWYgKCFjdXJyZW50KSByZXR1cm4gMDtcclxuICBpZiAoY3VycmVudC5ydW5faWQgIT09IGl0ZW0uYnVmLnJ1bl9pZCkgcmV0dXJuIE9iamVjdC5rZXlzKGN1cnJlbnQudHdlZXRzX2J5X2lkKS5sZW5ndGg7XHJcblxyXG4gIGNvbnN0IGNvbW1pdHRlZCA9IG5ldyBNYXAoXHJcbiAgICBpdGVtLnR3ZWV0cy5tYXAoKHQpID0+IFtcclxuICAgICAgdC50d2VldF9pZCxcclxuICAgICAgZW5nYWdlbWVudFNpZyh0Lmxpa2VfY291bnQsIHQucmV0d2VldF9jb3VudCwgdC5yZXBseV9jb3VudCwgdC5xdW90ZV9jb3VudCwgdC5pc190cnVuY2F0ZWQpLFxyXG4gICAgXSlcclxuICApO1xyXG4gIGZvciAoY29uc3QgdSBvZiBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzKSB7XHJcbiAgICBjb21taXR0ZWQuc2V0KHUudHdlZXRfaWQsIHVuYXZhaWxhYmxlU2lnKHUpKTtcclxuICB9XHJcbiAgY29uc3QgcmVtYWluaW5nVHdlZXRzOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD4gPSB7fTtcclxuICBmb3IgKGNvbnN0IFt0d2VldElkLCB0d2VldF0gb2YgT2JqZWN0LmVudHJpZXMoY3VycmVudC50d2VldHNfYnlfaWQpKSB7XHJcbiAgICBjb25zdCBjb21taXR0ZWRTaWcgPSBjb21taXR0ZWQuZ2V0KHR3ZWV0SWQpO1xyXG4gICAgY29uc3QgY3VycmVudFNpZyA9IGVuZ2FnZW1lbnRTaWcoXHJcbiAgICAgIHR3ZWV0Lmxpa2VfY291bnQsXHJcbiAgICAgIHR3ZWV0LnJldHdlZXRfY291bnQsXHJcbiAgICAgIHR3ZWV0LnJlcGx5X2NvdW50LFxyXG4gICAgICB0d2VldC5xdW90ZV9jb3VudCxcclxuICAgICAgdHdlZXQuaXNfdHJ1bmNhdGVkXHJcbiAgICApO1xyXG4gICAgaWYgKCFjb21taXR0ZWRTaWcgfHwgY29tbWl0dGVkU2lnICE9PSBjdXJyZW50U2lnKSB7XHJcbiAgICAgIHJlbWFpbmluZ1R3ZWV0c1t0d2VldElkXSA9IHsgLi4udHdlZXQgfTtcclxuICAgIH1cclxuICB9XHJcbiAgY29uc3QgcmVtYWluaW5nVW5hdmFpbGFibGU6IFJlY29yZDxzdHJpbmcsIFVuYXZhaWxhYmxlVHdlZXQ+ID0ge307XHJcbiAgZm9yIChjb25zdCBbdHdlZXRJZCwgdW5hdmFpbGFibGVdIG9mIE9iamVjdC5lbnRyaWVzKGN1cnJlbnQudW5hdmFpbGFibGVfYnlfaWQgPz8ge30pKSB7XHJcbiAgICBjb25zdCBjb21taXR0ZWRTaWcgPSBjb21taXR0ZWQuZ2V0KHR3ZWV0SWQpO1xyXG4gICAgY29uc3QgY3VycmVudFNpZyA9IHVuYXZhaWxhYmxlU2lnKHVuYXZhaWxhYmxlKTtcclxuICAgIGlmICghY29tbWl0dGVkU2lnIHx8IGNvbW1pdHRlZFNpZyAhPT0gY3VycmVudFNpZykge1xyXG4gICAgICByZW1haW5pbmdVbmF2YWlsYWJsZVt0d2VldElkXSA9IHsgLi4udW5hdmFpbGFibGUgfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IHJlbWFpbmluZ0lkcyA9IG5ldyBTZXQoW1xyXG4gICAgLi4uT2JqZWN0LmtleXMocmVtYWluaW5nVHdlZXRzKSxcclxuICAgIC4uLk9iamVjdC5rZXlzKHJlbWFpbmluZ1VuYXZhaWxhYmxlKSxcclxuICBdKTtcclxuICBjb25zdCByZW1haW5pbmdDb3VudCA9IHJlbWFpbmluZ0lkcy5zaXplO1xyXG4gIGlmIChyZW1haW5pbmdDb3VudCA9PT0gMCkge1xyXG4gICAgYXdhaXQgY2xlYXJSdW5CdWZmZXIoaXRlbS5oYW5kbGUpO1xyXG4gICAgcmV0dXJuIDA7XHJcbiAgfVxyXG5cclxuICBjb25zdCBuZXh0UnVuSWQgPSBuZXdSdW5JZCgpO1xyXG4gIGZvciAoY29uc3QgdHdlZXQgb2YgT2JqZWN0LnZhbHVlcyhyZW1haW5pbmdUd2VldHMpKSB7XHJcbiAgICB0d2VldC5jYXB0dXJlX3J1bl9pZCA9IG5leHRSdW5JZDtcclxuICB9XHJcbiAgYXdhaXQgc2V0UnVuQnVmZmVyKGl0ZW0uaGFuZGxlLCB7XHJcbiAgICAuLi5jdXJyZW50LFxyXG4gICAgcnVuX2lkOiBuZXh0UnVuSWQsXHJcbiAgICBzdGFydGVkX2F0OiBjdXJyZW50Lmxhc3RfY2FwdHVyZV9hdCxcclxuICAgIHR3ZWV0c19ieV9pZDogcmVtYWluaW5nVHdlZXRzLFxyXG4gICAgdW5hdmFpbGFibGVfYnlfaWQ6IHJlbWFpbmluZ1VuYXZhaWxhYmxlLFxyXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBjdXJyZW50LnR3ZWV0X2lkc19vYnNlcnZlZC5maWx0ZXIoKGlkKSA9PiByZW1haW5pbmdJZHMuaGFzKGlkKSksXHJcbiAgfSk7XHJcbiAgYXdhaXQgaW5mbygnZmx1c2gga2VwdCBuZXdlciBidWZmZXJlZCB0d2VldHMnLCB7XHJcbiAgICBoYW5kbGU6IGl0ZW0uaGFuZGxlLFxyXG4gICAgY29tbWl0dGVkX3J1bjogaXRlbS5ydW5TaG9ydCxcclxuICAgIG5leHRfcnVuOiBzaG9ydFJ1bklkKG5leHRSdW5JZCksXHJcbiAgICByZW1haW5pbmc6IHJlbWFpbmluZ0NvdW50LFxyXG4gIH0pO1xyXG4gIHJldHVybiByZW1haW5pbmdDb3VudDtcclxufVxyXG5cclxuLy8gLS0tIENhcHR1cmUtbm93IC8gY2FwdHVyZS1hbGwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gY2FwdHVyZU5vdyhoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGFsbG93TWFudWFsQ2FwdHVyZVdpbmRvdygpO1xyXG4gIC8vIExhbmQgb24gdGhlIFJlcGxpZXMgdGFiIHNvIFggZmV0Y2hlcyB2aWEgVXNlclR3ZWV0c0FuZFJlcGxpZXMgXHUyMDE0IHRoYXRcclxuICAvLyBlbmRwb2ludCByZXR1cm5zIGJvdGggdG9wLWxldmVsIHBvc3RzIGFuZCByZXBsaWVzLCB3aGljaCBpcyB0aGUgc3VwZXJzZXRcclxuICAvLyB3ZSB3YW50IGZvciB0aGUgYXJjaGl2ZS4gVGhlIHBsYWluIGAvPGhhbmRsZT5gIFVSTCBoaXRzIFVzZXJUd2VldHMsXHJcbiAgLy8gd2hpY2ggb21pdHMgcmVwbGllcy4gVGhlIHBhZ2UtaG9vayBpbnRlcmNlcHRzIGVpdGhlciBlbmRwb2ludCwgYnV0XHJcbiAgLy8gZm9yY2luZyB0aGUgYnJvYWRlciB0YWIgb24gdXNlci1pbml0aWF0ZWQgY2FwdHVyZXMgaXMgdGhlIHJpZ2h0IGRlZmF1bHQuXHJcbiAgY29uc3QgdGFyZ2V0VXJsID0gYGh0dHBzOi8veC5jb20vJHtoYW5kbGV9L3dpdGhfcmVwbGllc2A7XHJcbiAgYXdhaXQgaW5mbygnY2FwdHVyZS1ub3cgcmVxdWVzdGVkJywgeyBoYW5kbGUsIHRhYjogJ3dpdGhfcmVwbGllcycgfSk7XHJcbiAgaWYgKCEoYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSkpKSB7XHJcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XHJcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCB7XHJcbiAgICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcclxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcclxuICAgICAgc3RhcnRlZF9hdDogbm93LFxyXG4gICAgICBsYXN0X2NhcHR1cmVfYXQ6IG5vdyxcclxuICAgICAgdHdlZXRzX2J5X2lkOiB7fSxcclxuICAgICAgdW5hdmFpbGFibGVfYnlfaWQ6IHt9LFxyXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IFtdLFxyXG4gICAgICBlbmRwb2ludHNfc2VlbjogW10sXHJcbiAgICAgIHNvdXJjZV91cmw6IHRhcmdldFVybCxcclxuICAgIH0pO1xyXG4gIH1cclxuICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsOiB0YXJnZXRVcmwsIGFjdGl2ZTogdHJ1ZSB9KTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gY2FwdHVyZUFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XHJcbiAgYXdhaXQgaW5mbygnY2FwdHVyZS1hbGwgcmVxdWVzdGVkJywgeyBjb3VudDogYWNjb3VudHMubGVuZ3RoIH0pO1xyXG4gIGZvciAoY29uc3QgYSBvZiBhY2NvdW50cykge1xyXG4gICAgYXdhaXQgY2FwdHVyZU5vdyhhLmhhbmRsZSk7XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogQ2FwdHVyZSB3aGF0ZXZlciB0aGUgdXNlciBpcyBjdXJyZW50bHkgbG9va2luZyBhdDogZW5zdXJlcyBwYWdlLWhvb2sgaXNcclxuICogcGF0Y2hlZCBpbnRvIHRoZSBhY3RpdmUgdGFiLCB0aGVuIG51ZGdlcyB0aGUgcGFnZSB3aXRoIGEgcHJvZ3JhbW1hdGljXHJcbiAqIHNjcm9sbCBzbyBYIGZpcmVzIGFub3RoZXIgYmF0Y2ggb2YgR3JhcGhRTCByZXF1ZXN0cyB3ZSBjYW4gaW50ZXJjZXB0LlxyXG4gKlxyXG4gKiBMZXNzIGRpc3J1cHRpdmUgdGhhbiBgQ2FwdHVyZSBub3dgIChubyBuZXcgdGFiLCBubyBuYXZpZ2F0aW9uKSBhbmQgd29ya3NcclxuICogZm9yIGFyYml0cmFyeSBYIFVSTHMgKHNwZWNpZmljIHR3ZWV0IHRocmVhZHMsIHNlYXJjaCByZXN1bHRzLCBsaXN0cylcclxuICogdGhhdCBkb24ndCBtYXAgY2xlYW5seSB0byBvbmUgb2YgdGhlIGNvbmZpZ3VyZWQgaGFuZGxlcy5cclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVUaGlzUGFnZSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcclxuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xyXG4gIHRyeSB7XHJcbiAgICB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGNvdWxkIG5vdCBxdWVyeSBhY3RpdmUgdGFiJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgY29uc3QgdGFiID0gdGFic1swXTtcclxuICBpZiAoIXRhYiB8fCB0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJyB8fCAhdGFiLnVybCkge1xyXG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IG5vIGFjdGl2ZSB0YWInKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgaWYgKCEvXmh0dHBzOlxcL1xcLyh4fHR3aXR0ZXIpXFwuY29tXFwvLy50ZXN0KHRhYi51cmwpKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogYWN0aXZlIHRhYiBpcyBub3Qgb24geC5jb20gLyB0d2l0dGVyLmNvbScsIHtcclxuICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwpLFxyXG4gICAgfSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtdGhpcy1wYWdlIHJlcXVlc3RlZCcsIHsgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwpIH0pO1xyXG4gIC8vIChSZS0paW5qZWN0IHRoZSBwYWdlLWhvb2sgKyBpc29sYXRlZCBjb250ZW50IHNjcmlwdCBzbyBmZXRjaC9YSFIgYXJlXHJcbiAgLy8gcGF0Y2hlZCBldmVuIG9uIHRhYnMgb3BlbmVkIGJlZm9yZSB0aGUgZXh0ZW5zaW9uIHJlbG9hZGVkLlxyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcclxuICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcclxuICAgICAgZmlsZXM6IFsncGFnZS1ob29rLmpzJ10sXHJcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XHJcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXHJcbiAgICAgIGZpbGVzOiBbJ2NvbnRlbnQuanMnXSxcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IHJlLWluamVjdCBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gIH1cclxuICAvLyBOdWRnZSBYIHRvIGZpcmUgbW9yZSBHcmFwaFFMIHJlcXVlc3RzIGJ5IHNjcm9sbGluZy4gTW9zdCB0aW1lbGluZSAvXHJcbiAgLy8gY29udmVyc2F0aW9uIHZpZXdzIGZldGNoIG9uIGludGVyc2VjdGlvbi1vYnNlcnZlciB0cmlnZ2Vycy5cclxuICB0cnkge1xyXG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XHJcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXHJcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcclxuICAgICAgZnVuYzogKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGggPSB3aW5kb3cuaW5uZXJIZWlnaHQ7XHJcbiAgICAgICAgd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgNjAwKTtcclxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuNSwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pLCAxMjAwKTtcclxuICAgICAgfSxcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IHNjcm9sbC1udWRnZSBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tIFJlZmV0Y2ggbG9vcCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy9cclxuLy8gWCB0cnVuY2F0ZXMgbG9uZyB0d2VldHMgaW4gdGltZWxpbmUgcGF5bG9hZHMgXHUyMDE0IGBub3RlX3R3ZWV0YCBpcyBvbmx5XHJcbi8vIGlubGluZWQgZm9yIHNvbWUgZW5kcG9pbnRzLiBSZS1vcGVuaW5nIGVhY2ggdHJ1bmNhdGVkIHR3ZWV0J3MgZGV0YWlsIHBhZ2VcclxuLy8gY2F1c2VzIHRoZSBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgZnVsbCBgbm90ZV90d2VldGAgYm9keS4gVGhlIGxvb3BcclxuLy8gZHJpdmVzIHRoYXQgYnkgbmF2aWdhdGluZyBhIHNpbmdsZSBkZWRpY2F0ZWQgdGFiIHRocm91Z2ggdGhlIHF1ZXVlLCBvbmVcclxuLy8gdHdlZXQgYXQgYSB0aW1lLCBnYXRlZCBvbiB0aGUgcGFnZS1ob29rIGFjdHVhbGx5IGluZ2VzdGluZyBhIHJlc3BvbnNlIGZvclxyXG4vLyB0aGUgdHdlZXQgd2UganVzdCBuYXZpZ2F0ZWQgdG8gKHNvIGRlbGV0ZWQgLyBwYXl3YWxsZWQgLyA0MDQnZCB0d2VldHNcclxuLy8gZG9uJ3QgbWFrZSB1cyBzcGluIGFuZCBzbyB3ZSBkb24ndCBzbGFtIFggd2l0aCByZWZyZXNoZXMgZmFzdGVyIHRoYW4gdGhlXHJcbi8vIHRhYiBjYW4gbG9hZCkuXHJcblxyXG5jb25zdCBSRUZFVENIX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV9yZWZldGNoX3RhYl9pZF9fJztcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hUYWJJZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcclxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFJFRkVUQ0hfVEFCX0tFWSk7XHJcbiAgY29uc3QgaWQgPSBzdG9yZWRbUkVGRVRDSF9UQUJfS0VZXTtcclxuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2V0UmVmZXRjaFRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgaWYgKGlkID09PSBudWxsKSB7XHJcbiAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFJFRkVUQ0hfVEFCX0tFWSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbUkVGRVRDSF9UQUJfS0VZXTogaWQgfSk7XHJcbiAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzdGFydFJlZmV0Y2hMb29wKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGFsbG93TWFudWFsQ2FwdHVyZVdpbmRvdygpO1xyXG4gIGNvbnN0IHRvdGFsID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcclxuICBpZiAodG90YWwgPT09IDApIHtcclxuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2g6IG5vdGhpbmcgcXVldWVkJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcclxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXHJcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcclxuICApO1xyXG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHtcclxuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXHJcbiAgICBwcm9jZXNzZWQ6IDAsXHJcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIGluZmxpZ2h0OiBudWxsLFxyXG4gIH0pO1xyXG4gIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHMpO1xyXG4gIHZvaWQgcmVmZXRjaFRpY2soKTtcclxuICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3Agc3RhcnRlZCcsIHsgcXVldWVkOiB0b3RhbCwgaW50ZXJ2YWxfc2VjOiBzZWNvbmRzIH0pO1xyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmxldCByZWZldGNoSW50ZXJ2YWxIYW5kbGU6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xyXG5cclxuZnVuY3Rpb24gc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kczogbnVtYmVyKTogdm9pZCB7XHJcbiAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgY2xlYXJJbnRlcnZhbChyZWZldGNoSW50ZXJ2YWxIYW5kbGUpO1xyXG4gIHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKCgpID0+IHtcclxuICAgIHZvaWQgcmVmZXRjaFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgIHZvaWQgd2FybigncmVmZXRjaCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgICB9KTtcclxuICB9LCBzZWNvbmRzICogMTAwMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTogdm9pZCB7XHJcbiAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkge1xyXG4gICAgY2xlYXJJbnRlcnZhbChyZWZldGNoSW50ZXJ2YWxIYW5kbGUpO1xyXG4gICAgcmVmZXRjaEludGVydmFsSGFuZGxlID0gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbFJlZmV0Y2hMb29wKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcclxuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigncmVmZXRjaC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXHJcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRSZWZldGNoVGFiSWQoKTtcclxuICBhd2FpdCBzZXRSZWZldGNoVGFiSWQobnVsbCk7XHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XHJcbiAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24obnVsbCk7XHJcbiAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIGNhbmNlbGxlZCcsIHtcclxuICAgIGhhZF90YWI6IHRhYklkICE9PSBudWxsLFxyXG4gICAgcHJvY2Vzc2VkOiBzZXNzPy5wcm9jZXNzZWQgPz8gMCxcclxuICB9KTtcclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiByZWZldGNoVGljaygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBsZXQgc2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XHJcbiAgaWYgKHNlc3MgPT09IG51bGwpIHtcclxuICAgIC8vIExvb3Agd2FzIGNhbmNlbGxlZCBvciBuZXZlciBzdGFydGVkOyBub3RoaW5nIHRvIGRvLlxyXG4gICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICAvLyBXYWl0LWZvci1pbmdlc3QgZ3VhcmQ6IGlmIHdlJ3JlIHN0aWxsIGV4cGVjdGluZyBhIGNhcHR1cmUgZm9yIHRoZVxyXG4gIC8vIHByZXZpb3VzbHktbmF2aWdhdGVkIHRhcmdldCwgb25seSBhZHZhbmNlIG9uY2Ugd2UndmUgZWl0aGVyIHNlZW4gdGhlXHJcbiAgLy8gY2FwdHVyZSAob25HcmFwaHFsQ2FwdHVyZSBjbGVhcnMgYGluZmxpZ2h0YCkgb3IgaGl0IHRoZSB0aW1lb3V0LlxyXG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XHJcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2Uoc2Vzcy5pbmZsaWdodC5uYXZpZ2F0ZWRBdCk7XHJcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XHJcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBcdTIwMTQgcGFnZS1ob29rIG1heSB5ZXQgY2FwdHVyZSB0aGUgcmVzcG9uc2UuXHJcbiAgICB9XHJcbiAgICAvLyBUaW1lZCBvdXQuIFRyZWF0IGFzIFwidGhpcyB0YXJnZXQgd29uJ3QgaW5nZXN0XCIgYW5kIGRyb3AgaXQuXHJcbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoOiB0YXJnZXQgdGltZWQgb3V0IHdhaXRpbmcgZm9yIGluZ2VzdCcsIHtcclxuICAgICAgdHdlZXRfaWQ6IHNlc3MuaW5mbGlnaHQudHdlZXRJZCxcclxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxyXG4gICAgfSk7XHJcbiAgICAvLyBGaW5kIHdoaWNoIGhhbmRsZSB0aGlzIGlkIGlzIHF1ZXVlZCB1bmRlciBzbyB3ZSBjYW4gZGVxdWV1ZSBpdC5cclxuICAgIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICAgIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xyXG4gICAgICBpZiAoaWRzLmluY2x1ZGVzKHNlc3MuaW5mbGlnaHQudHdlZXRJZCkpIHtcclxuICAgICAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaChoYW5kbGUsIHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dFJlZmV0Y2hUYXJnZXQoKTtcclxuICBpZiAoIXRhcmdldCkge1xyXG4gICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xyXG4gICAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xyXG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24obnVsbCk7XHJcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XHJcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuaGFuZGxlfS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xyXG4gIGxldCB0YWJJZCA9IGF3YWl0IGdldFJlZmV0Y2hUYWJJZCgpO1xyXG4gIGlmICh0YWJJZCAhPT0gbnVsbCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmdldCh0YWJJZCk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgdGFiSWQgPSBudWxsO1xyXG4gICAgfVxyXG4gIH1cclxuICB0cnkge1xyXG4gICAgaWYgKHRhYklkID09PSBudWxsKSB7XHJcbiAgICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwsIGFjdGl2ZTogZmFsc2UgfSk7XHJcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkID09PSAnbnVtYmVyJykgYXdhaXQgc2V0UmVmZXRjaFRhYklkKHRhYi5pZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcclxuICAgIH1cclxuICAgIHNlc3MgPSAoYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKSkgPz8gc2VzcztcclxuICAgIHNlc3MuaW5mbGlnaHQgPSB7XHJcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxyXG4gICAgICBuYXZpZ2F0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgfTtcclxuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xyXG4gICAgYXdhaXQgaW5mbygncmVmZXRjaCB0aWNrJywge1xyXG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgcmVtYWluaW5nOiBhd2FpdCByZWZldGNoUXVldWVUb3RhbCgpLFxyXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxyXG4gICAgICB0b3RhbF9hdF9zdGFydDogc2Vzcy50b3RhbEF0U3RhcnQsXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ3JlZmV0Y2ggbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XHJcbiAgICAgIGhhbmRsZTogdGFyZ2V0LmhhbmRsZSxcclxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxyXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXHJcbiAgICB9KTtcclxuICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHRhcmdldC5oYW5kbGUsIHRhcmdldC50d2VldElkKTtcclxuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xyXG4gIH1cclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG4vLyAtLS0gTWVkaWEtY3Jhd2wgbG9vcCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vL1xyXG4vLyBNaXJyb3JzIHRoZSByZWZldGNoIGxvb3AgYnV0IHRhcmdldHMgdGhlIG1lZGlhLWNyYXdsIHF1ZXVlOiB0d2VldHMgdGhhdFxyXG4vLyB0aGUgbm9ybWFsaXplciBvYnNlcnZlZCB2aWEgdGhlIE1lZGlhIHRhYiAvIFVzZXJNZWRpYSBlbmRwb2ludCB3aXRoXHJcbi8vIGluc3VmZmljaWVudCBkYXRhIHRvIGJ1aWxkIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIFRoZSBjcmF3bCBsb29wIHdhbGtzXHJcbi8vIGEgZGVkaWNhdGVkIHRhYiB0aHJvdWdoIGVhY2ggdHdlZXQncyBkZXRhaWwgcGFnZSAoaGFuZGxlLWxlc3MgVVJMIGZvcm1cclxuLy8gd2hlbiB0aGUgaGludC1oYW5kbGUgaXMgbWlzc2luZyksIGF0IHRoZSBhdXRvLXNjcm9sbCBjYWRlbmNlLCBzbyB0aGVcclxuLy8gcGFnZS1ob29rIGNhbiBjYXB0dXJlIHRoZSByZWFsIHR3ZWV0IHNoYXBlLlxyXG5cclxuY29uc3QgTUVESUFfQ1JBV0xfVEFCX0tFWSA9ICdfX2ltbV9hcmNoaXZlX21lZGlhX2NyYXdsX3RhYl9pZF9fJztcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xUYWJJZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcclxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KE1FRElBX0NSQVdMX1RBQl9LRVkpO1xyXG4gIGNvbnN0IGlkID0gc3RvcmVkW01FRElBX0NSQVdMX1RBQl9LRVldO1xyXG4gIHJldHVybiB0eXBlb2YgaWQgPT09ICdudW1iZXInID8gaWQgOiBudWxsO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsVGFiSWQoaWQ6IG51bWJlciB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBpZiAoaWQgPT09IG51bGwpIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5yZW1vdmUoTUVESUFfQ1JBV0xfVEFCX0tFWSk7XHJcbiAgZWxzZSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW01FRElBX0NSQVdMX1RBQl9LRVldOiBpZCB9KTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc3RhcnRNZWRpYUNyYXdsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcclxuICBjb25zdCB0b3RhbCA9IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCk7XHJcbiAgaWYgKHRvdGFsID09PSAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogbm90aGluZyBxdWV1ZWQnKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgY29uc3Qgc2Vjb25kcyA9IE1hdGgubWluKFxyXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcclxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxyXG4gICk7XHJcbiAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oe1xyXG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcclxuICAgIHByb2Nlc3NlZDogMCxcclxuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgaW5mbGlnaHQ6IG51bGwsXHJcbiAgfSk7XHJcbiAgc3RhcnRNZWRpYUNyYXdsSW50ZXJ2YWwoc2Vjb25kcyk7XHJcbiAgdm9pZCBtZWRpYUNyYXdsVGljaygpO1xyXG4gIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIGxvb3Agc3RhcnRlZCcsIHsgcXVldWVkOiB0b3RhbCwgaW50ZXJ2YWxfc2VjOiBzZWNvbmRzIH0pO1xyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmxldCBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGU6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xyXG5cclxuZnVuY3Rpb24gc3RhcnRNZWRpYUNyYXdsSW50ZXJ2YWwoc2Vjb25kczogbnVtYmVyKTogdm9pZCB7XHJcbiAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgY2xlYXJJbnRlcnZhbChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUpO1xyXG4gIG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKCgpID0+IHtcclxuICAgIHZvaWQgbWVkaWFDcmF3bFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgIHZvaWQgd2FybignbWVkaWEtY3Jhd2wgdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gICAgfSk7XHJcbiAgfSwgc2Vjb25kcyAqIDEwMDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk6IHZvaWQge1xyXG4gIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcclxuICAgIGNsZWFySW50ZXJ2YWwobWVkaWFDcmF3bEludGVydmFsSGFuZGxlKTtcclxuICAgIG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSA9IG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxNZWRpYUNyYXdsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XHJcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ21lZGlhLWNyYXdsLXRpY2snKTsgLy8gbGVnYWN5IGNsZWFudXBcclxuICBjb25zdCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xyXG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZChudWxsKTtcclxuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcclxuICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihudWxsKTtcclxuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNhbmNlbGxlZCcsIHtcclxuICAgIGhhZF90YWI6IHRhYklkICE9PSBudWxsLFxyXG4gICAgcHJvY2Vzc2VkOiBzZXNzPy5wcm9jZXNzZWQgPz8gMCxcclxuICB9KTtcclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsVGljaygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBsZXQgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XHJcbiAgaWYgKHNlc3MgPT09IG51bGwpIHtcclxuICAgIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgaWYgKHNlc3MuaW5mbGlnaHQgIT09IG51bGwpIHtcclxuICAgIGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShzZXNzLmluZmxpZ2h0Lm5hdmlnYXRlZEF0KTtcclxuICAgIGlmIChlbGFwc2VkIDwgSU5HRVNUX1dBSVRfTVMpIHtcclxuICAgICAgcmV0dXJuOyAvLyBzdGlsbCB3YWl0aW5nIG9uIHRoZSBwYWdlLWhvb2tcclxuICAgIH1cclxuICAgIGF3YWl0IHdhcm4oJ21lZGlhLWNyYXdsOiB0YXJnZXQgdGltZWQgb3V0IHdhaXRpbmcgZm9yIGluZ2VzdCcsIHtcclxuICAgICAgdHdlZXRfaWQ6IHNlc3MuaW5mbGlnaHQudHdlZXRJZCxcclxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bChzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xyXG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XHJcbiAgfVxyXG5cclxuICBjb25zdCB0YXJnZXQgPSBhd2FpdCBuZXh0TWVkaWFDcmF3bFRhcmdldCgpO1xyXG4gIGlmICghdGFyZ2V0KSB7XHJcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XHJcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQobnVsbCk7XHJcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihudWxsKTtcclxuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XHJcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICAvLyBTa2lwIGlmIGFscmVhZHkgaW4gdGhlIGFyY2hpdmUgXHUyMDE0IHBhcnRpYWwgY2FwdHVyZXMgY2FuIG91dGxpdmUgYVxyXG4gIC8vIHNlcGFyYXRlIGZ1bGwgY2FwdHVyZSBwYXRoLlxyXG4gIGlmIChhd2FpdCBpc0NvbW1pdHRlZCh0YXJnZXQudHdlZXRJZCkpIHtcclxuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHRhcmdldC50d2VldElkKTtcclxuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIC8vIFdoZW4gd2UgZG9uJ3Qga25vdyB0aGUgcGFyZW50J3MgYXV0aG9yIGhhbmRsZSAocXVvdGUvUlQgb2YgYSB0d2VldFxyXG4gIC8vIFggc3RyaXBwZWQsIG9yIGEgVXNlck1lZGlhIHRodW1ibmFpbCB0aGF0IGxhY2tlZCB0aGUgYXV0aG9yIGJsb2NrKSxcclxuICAvLyBmYWxsIGJhY2sgdG8gYC9pL3dlYi9zdGF0dXMvPGlkPmAuIFggcmVzb2x2ZXMgaXQgdG8gdGhlIGNvcnJlY3RcclxuICAvLyBkZXRhaWwgcGFnZSwgd2hpY2ggaXMgZW5vdWdoIGZvciB0aGUgcGFnZS1ob29rIHRvIGluZ2VzdCBhXHJcbiAgLy8gVHdlZXREZXRhaWwgcmVzcG9uc2UuXHJcbiAgY29uc3QgdXJsID1cclxuICAgIHRhcmdldC5idWNrZXQgPT09ICdfdW5rbm93bidcclxuICAgICAgPyBgaHR0cHM6Ly94LmNvbS9pL3dlYi9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gXHJcbiAgICAgIDogYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuYnVja2V0fS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xyXG4gIGxldCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xyXG4gIGlmICh0YWJJZCAhPT0gbnVsbCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmdldCh0YWJJZCk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgdGFiSWQgPSBudWxsO1xyXG4gICAgfVxyXG4gIH1cclxuICB0cnkge1xyXG4gICAgaWYgKHRhYklkID09PSBudWxsKSB7XHJcbiAgICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwsIGFjdGl2ZTogZmFsc2UgfSk7XHJcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkID09PSAnbnVtYmVyJykgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKHRhYi5pZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcclxuICAgIH1cclxuICAgIHNlc3MgPSAoYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKSkgPz8gc2VzcztcclxuICAgIHNlc3MuaW5mbGlnaHQgPSB7XHJcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxyXG4gICAgICBuYXZpZ2F0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgfTtcclxuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xyXG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgdGljaycsIHtcclxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxyXG4gICAgICBoaW50X2hhbmRsZTogdGFyZ2V0LmJ1Y2tldCA9PT0gJ191bmtub3duJyA/IG51bGwgOiB0YXJnZXQuYnVja2V0LFxyXG4gICAgICByZW1haW5pbmc6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXHJcbiAgICAgIHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQsXHJcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBzZXNzLnRvdGFsQXRTdGFydCxcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgYXdhaXQgd2FybignbWVkaWEtY3Jhd2wgbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuLy8gLS0tIFF1YXJhbnRpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHF1YXJhbnRpbmUoXHJcbiAgcmVhc29uOiBzdHJpbmcsXHJcbiAgZW5kcG9pbnQ6IHN0cmluZyxcclxuICB1cmw6IHN0cmluZyxcclxuICByYXc6IHVua25vd24sXHJcbiAgZXJyOiB1bmtub3duXHJcbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGxvZ0VycigncXVhcmFudGluaW5nIGNhcHR1cmUnLCB7IHJlYXNvbiwgZW5kcG9pbnQsIHVybCwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcclxuICBjb25zdCBwYXlsb2FkOiBRdWFyYW50aW5lUGF5bG9hZCA9IHtcclxuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxyXG4gICAgcmVhc29uLFxyXG4gICAgZW5kcG9pbnQsXHJcbiAgICBjYXB0dXJlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgc291cmNlX3VybDogdXJsLFxyXG4gICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKSxcclxuICAgIHJhdyxcclxuICB9O1xyXG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChwYXlsb2FkLmNhcHR1cmVkX2F0KTtcclxuICBjb25zdCBoYXNoID0gYXdhaXQgc2hhOChKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XHJcbiAgY29uc3QgcGF0aCA9IGByYXcvX3F1YXJhbnRpbmUvJHt0c30tJHtoYXNofS5qc29uYDtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XHJcbiAgICBhd2FpdCBjbGllbnQucHV0RmlsZSh7XHJcbiAgICAgIHBhdGgsXHJcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHBheWxvYWQsIG51bGwsIDIpICsgJ1xcbicpLFxyXG4gICAgICBtZXNzYWdlOiBgcXVhcmFudGluZTogJHtyZWFzb259ICR7ZW5kcG9pbnR9YCxcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKHFlcnIpIHtcclxuICAgIGF3YWl0IGxvZ0VycigncXVhcmFudGluZSBjb21taXQgZmFpbGVkJywgeyAuLi5kZXNjcmliZUVycm9yKHFlcnIpIH0pO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2hhOChzOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIGNvbnN0IGJ1ZiA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcclxuICBjb25zdCBkaWdlc3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGJ1Zik7XHJcbiAgY29uc3QgaGV4ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShkaWdlc3QpKVxyXG4gICAgLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcclxuICAgIC5qb2luKCcnKTtcclxuICByZXR1cm4gaGV4LnNsaWNlKDAsIDgpO1xyXG59XHJcblxyXG4vLyAtLS0gQ29ubmVjdGlvbiB2ZXJpZmljYXRpb24gJiBhY2NvdW50cyBsaXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5hc3luYyBmdW5jdGlvbiB2ZXJpZnlDb25uZWN0aW9uKGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xyXG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcclxuICAgICAgbG9naW46IG51bGwsXHJcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcclxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcclxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcclxuICBpZiAoIWZvcmNlKSB7XHJcbiAgICAvLyBTa2lwIGlmIHdlJ3JlIGluc2lkZSB0aGUgcmVwb3J0ZWQgcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IHJlLWNoZWNraW5nXHJcbiAgICAvLyBiZWZvcmUgcmVzZXQganVzdCB3YXN0ZXMgbW9yZSBvZiB0aGUgc2FtZSBleGhhdXN0ZWQgcXVvdGEgYW5kIGtlZXBzXHJcbiAgICAvLyB0aGUgNDAzcyBjb21pbmcuXHJcbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xyXG4gICAgICBjb25zdCBub3dTZWMgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcclxuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgLy8gQXBwbHkgdGhlIHBlcmlvZGljLWNoZWNrIGdhdGUgdG8gZXZlcnkgc3RhdHVzLCBub3QganVzdCAnb2snLiBUaGVcclxuICAgIC8vIHByZXZpb3VzIGJlaGF2aW9yIHJlLXZlcmlmaWVkIG9uIGV2ZXJ5IHdha2Ugd2hlbmV2ZXIgdGhlIGNvbm5lY3Rpb25cclxuICAgIC8vIHdhc24ndCAnb2snLCB3aGljaCBkdXJpbmcgYSByYXRlLWxpbWl0IHdpbmRvdyBtZWFudCAyIEFQSSBjYWxscyBwZXJcclxuICAgIC8vIFNXIHdha2UgKHZlcmlmeVJlcG9BY2Nlc3MgZG9lcyBHRVQgL3VzZXIgKyBHRVQgL3JlcG9zL3tvfS97cn0pLlxyXG4gICAgaWYgKGNvbm4uY2hlY2tlZEF0KSB7XHJcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGNvbm4uY2hlY2tlZEF0KTtcclxuICAgICAgaWYgKGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XHJcbiAgICB9XHJcbiAgfVxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcclxuICAgIGNvbnN0IHIgPSBhd2FpdCBjbGllbnQudmVyaWZ5UmVwb0FjY2VzcygpO1xyXG4gICAgLy8gUHJvYmUgdGhlIGNvbmZpZ3VyZWQgYnJhbmNoLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCBpcyBmaW5lIFx1MjAxNCBpdCdzXHJcbiAgICAvLyByb3V0aW5lIHRvIGNhcHR1cmUgaW50byBhIHdvcmtpbmcgYnJhbmNoIFx1MjAxNCBidXQgYSAqbWlzc2luZyogYnJhbmNoXHJcbiAgICAvLyB3b3VsZCA0MjIgZXZlcnkgY29tbWl0LlxyXG4gICAgbGV0IGJyYW5jaE9rID0gdHJ1ZTtcclxuICAgIGlmIChzZXR0aW5ncy5icmFuY2ggJiYgc2V0dGluZ3MuYnJhbmNoICE9PSByLmRlZmF1bHRfYnJhbmNoKSB7XHJcbiAgICAgIGJyYW5jaE9rID0gYXdhaXQgY2xpZW50LmJyYW5jaEV4aXN0cyhzZXR0aW5ncy5icmFuY2gpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgY2hlY2tXcml0ZSA9IGZvcmNlIHx8IGlzV3JpdGVBdXRoRXJyb3IoY29ubi5lcnJvcik7XHJcbiAgICBpZiAoYnJhbmNoT2sgJiYgY2hlY2tXcml0ZSkge1xyXG4gICAgICBhd2FpdCBjbGllbnQudmVyaWZ5V3JpdGVBY2Nlc3MoKTtcclxuICAgIH1cclxuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xyXG4gICAgICBzdGF0dXM6ICdvaycsXHJcbiAgICAgIGxvZ2luOiByLmxvZ2luLFxyXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgZXJyb3I6IG51bGwsXHJcbiAgICAgIGRlZmF1bHRCcmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXHJcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGJyYW5jaE9rLFxyXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBpbmZvKCdjb25uZWN0aW9uIHZlcmlmaWVkJywge1xyXG4gICAgICBsb2dpbjogci5sb2dpbixcclxuICAgICAgcmVwbzogci5mdWxsX25hbWUsXHJcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxyXG4gICAgICBjb25maWd1cmVkX2JyYW5jaDogc2V0dGluZ3MuYnJhbmNoLFxyXG4gICAgICBjb25maWd1cmVkX2JyYW5jaF9leGlzdHM6IGJyYW5jaE9rLFxyXG4gICAgICB3cml0ZV9hY2Nlc3M6IGNoZWNrV3JpdGUgPyAnY2hlY2tlZCcgOiAnbm90X2NoZWNrZWQnLFxyXG4gICAgfSk7XHJcbiAgICBpZiAoIWJyYW5jaE9rKSB7XHJcbiAgICAgIGF3YWl0IHdhcm4oJ2NvbmZpZ3VyZWQgYnJhbmNoIGRvZXMgbm90IGV4aXN0IG9uIHJlbW90ZScsIHtcclxuICAgICAgICBjb25maWd1cmVkOiBzZXR0aW5ncy5icmFuY2gsXHJcbiAgICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXHJcbiAgICAgICAgZml4OiAnb3BlbiBTZXR0aW5ncyBhbmQgY2hhbmdlIGJyYW5jaCB0byAnICsgci5kZWZhdWx0X2JyYW5jaCxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zdCBjYXQgPSBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciA/IGVyci5jYXRlZ29yeSA6ICd1bmtub3duJztcclxuICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XHJcbiAgICAgIGNhdCA9PT0gJ2F1dGgnXHJcbiAgICAgICAgPyAnYXV0aC1lcnJvcidcclxuICAgICAgICA6IGNhdCA9PT0gJ3JhdGUtbGltaXQnXHJcbiAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXHJcbiAgICAgICAgICA6IGNhdCA9PT0gJ25ldHdvcmsnXHJcbiAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXHJcbiAgICAgICAgICAgIDogJ2F1dGgtZXJyb3InO1xyXG4gICAgY29uc3QgcmVzZXRBdCA9XHJcbiAgICAgIGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGNhdCA9PT0gJ3JhdGUtbGltaXQnID8gZXJyLnJhdGVMaW1pdFJlc2V0QXQgOiBudWxsO1xyXG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgIHN0YXR1cyxcclxuICAgICAgbG9naW46IG51bGwsXHJcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLm1lc3NhZ2UsXHJcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXHJcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXHJcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXHJcbiAgICB9KTtcclxuICAgIGF3YWl0IHdhcm4oJ2Nvbm5lY3Rpb24gY2hlY2sgZmFpbGVkJywge1xyXG4gICAgICBjYXRlZ29yeTogY2F0LFxyXG4gICAgICByYXRlTGltaXRSZXNldEF0OiByZXNldEF0LFxyXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXHJcbiAgICB9KTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjY291bnRzTGlzdChmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCkge1xyXG4gICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmICghZm9yY2UpIHtcclxuICAgIC8vIFNraXAgd2hpbGUgaW5zaWRlIGEga25vd24gcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IGFjY291bnRzLnlhbWwgaXMgZmV0Y2hlZFxyXG4gICAgLy8gdmlhIGF1dGhlbnRpY2F0ZWQgcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSwgd2hpY2ggY291bnRzIGFnYWluc3QgdGhlXHJcbiAgICAvLyBzYW1lIHF1b3RhLlxyXG4gICAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcclxuICAgIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcgJiYgY29ubi5yYXRlTGltaXRSZXNldEF0ICE9PSBudWxsKSB7XHJcbiAgICAgIGNvbnN0IG5vd1NlYyA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xyXG4gICAgICBpZiAobm93U2VjIDwgY29ubi5yYXRlTGltaXRSZXNldEF0KSByZXR1cm47XHJcbiAgICB9XHJcbiAgICAvLyBTa2lwIGlmIHdlIHJlZnJlc2hlZCByZWNlbnRseS4gYWNjb3VudHMueWFtbCBjaGFuZ2VzIHJhcmVseSBcdTIwMTQgdGhlIG9sZFxyXG4gICAgLy8gY29kZSByZS1mZXRjaGVkIGl0IG9uIGV2ZXJ5IFNXIHdha2UsIHdoaWNoIGR1cmluZyBoZWF2eSBicm93c2luZyBtZWFudFxyXG4gICAgLy8gYSBHaXRIdWIgY2FsbCBldmVyeSBmZXcgc2Vjb25kcyBldmVuIHdoZW4gbm90aGluZyB3YXMgYmVpbmcgY2FwdHVyZWQuXHJcbiAgICBjb25zdCBsYXN0UmVmcmVzaGVkID0gYXdhaXQgZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpO1xyXG4gICAgaWYgKGxhc3RSZWZyZXNoZWQpIHtcclxuICAgICAgY29uc3QgYWdlID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2UobGFzdFJlZnJlc2hlZCk7XHJcbiAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYWdlKSAmJiBhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xyXG4gICAgfVxyXG4gIH1cclxuICB0cnkge1xyXG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XHJcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgY2xpZW50LmZldGNoUmF3VGV4dCgnY29uZmlnL2FjY291bnRzLnlhbWwnKTtcclxuICAgIGlmICghdGV4dCkge1xyXG4gICAgICBpZiAoZm9yY2UpIGF3YWl0IHdhcm4oJ2FjY291bnRzLnlhbWwgbm90IGZvdW5kIGluIHJlcG87IHVzaW5nIGZhbGxiYWNrJyk7XHJcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xyXG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlQWNjb3VudHNZYW1sKHRleHQpO1xyXG4gICAgaWYgKHBhcnNlZC5sZW5ndGggPT09IDApIHtcclxuICAgICAgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBwYXJzZWQgZW1wdHk7IGtlZXBpbmcgZmFsbGJhY2snKTtcclxuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XHJcbiAgICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgYXdhaXQgc2V0QWNjb3VudHMocGFyc2VkKTtcclxuICAgIGF3YWl0IHJlZnJlc2hBcmNoaXZlU25hcHNob3QoY2xpZW50LCBmb3JjZSk7XHJcbiAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XHJcbiAgICBpZiAoZm9yY2UpIGF3YWl0IGluZm8oJ2FjY291bnRzIGxpc3QgcmVmcmVzaGVkJywgeyBjb3VudDogcGFyc2VkLmxlbmd0aCB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ3JlZnJlc2ggYWNjb3VudHMgZmFpbGVkOyBrZWVwaW5nIGN1cnJlbnQgbGlzdCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgfVxyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hBcmNoaXZlU25hcHNob3QoY2xpZW50OiBHaXRIdWJDbGllbnQsIGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgdGV4dCA9IGF3YWl0IGNsaWVudC5mZXRjaFJhd1RleHQoJ2RhdGEvbWFuaWZlc3QuanNvbicpO1xyXG4gIGlmICghdGV4dCkge1xyXG4gICAgYXdhaXQgc2V0QXJjaGl2ZVNuYXBzaG90KG51bGwpO1xyXG4gICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhcmNoaXZlIG1hbmlmZXN0IG5vdCBmb3VuZDsgb2xkLXR3ZWV0IGRldGVjdGlvbiBkaXNhYmxlZCcpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICB0cnkge1xyXG4gICAgY29uc3Qgc25hcHNob3QgPSBwYXJzZUFyY2hpdmVTbmFwc2hvdChKU09OLnBhcnNlKHRleHQpIGFzIHVua25vd24pO1xyXG4gICAgYXdhaXQgc2V0QXJjaGl2ZVNuYXBzaG90KHNuYXBzaG90KTtcclxuICAgIGlmIChmb3JjZSkge1xyXG4gICAgICBhd2FpdCBpbmZvKCdhcmNoaXZlIHNuYXBzaG90IHJlZnJlc2hlZCcsIHtcclxuICAgICAgICBhY2NvdW50czogT2JqZWN0LmtleXMoc25hcHNob3QuYWNjb3VudHMpLmxlbmd0aCxcclxuICAgICAgICBnZW5lcmF0ZWRfYXQ6IHNuYXBzaG90LmdlbmVyYXRlZF9hdCxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdhcmNoaXZlIHNuYXBzaG90IHBhcnNlIGZhaWxlZDsgb2xkLXR3ZWV0IGRldGVjdGlvbiBkaXNhYmxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0gU3RhdGUgYnJvYWRjYXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5hc3luYyBmdW5jdGlvbiBicm9hZGNhc3RTdGF0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBzdGF0ZSA9IGF3YWl0IGJ1aWxkU3RhdGUoKTtcclxuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcclxuICBsZXQgdGFiQ291bnQgPSAwO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcclxuICAgIHRhYkNvdW50ID0gdGFicy5sZW5ndGg7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyB0YWJzLnF1ZXJ5IGlzIGFsbG93ZWQgYnkgdGhlIG1hbmlmZXN0IGJ1dCBjYW4gdHJhbnNpZW50bHkgZmFpbFxyXG4gICAgLy8gYXJvdW5kIGV4dGVuc2lvbiBzdGFydHVwOyBzdXJmYWNpbmcgMCBpcyBmaW5lLlxyXG4gIH1cclxuICBjb25zdCByZWZldGNoUXVldWVkID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcclxuICBjb25zdCBtZWRpYUNyYXdsUXVldWVkID0gYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTtcclxuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XHJcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xyXG4gIGNvbnN0IGF1dG9TY3JvbGxTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICBjb25zdCByZWNlbnRUd2VldFNpZ2h0aW5ncyA9IGF3YWl0IGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk7XHJcbiAgcmV0dXJuIHtcclxuICAgIHZlcnNpb246IEVYVF9WRVJTSU9OLFxyXG4gICAgc2V0dGluZ3M6IHJlZGFjdFNldHRpbmdzKHNldHRpbmdzKSxcclxuICAgIGNvbm5lY3Rpb246IGNvbm4sXHJcbiAgICBhY2NvdW50cyxcclxuICAgIGNvdW50ZXJzLFxyXG4gICAgYXV0b1Njcm9sbDoge1xyXG4gICAgICBhY3RpdmU6IGF1dG9TY3JvbGxTZXNzICE9PSBudWxsICYmIGF1dG9TY3JvbGxUaW1lciAhPT0gbnVsbCxcclxuICAgICAgdGFiQ291bnQsXHJcbiAgICAgIHNjcm9sbENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uc2Nyb2xsQ291bnQgPz8gMCxcclxuICAgICAgaW5nZXN0ZWRDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkQ291bnQgPz8gMCxcclxuICAgICAgaW5nZXN0ZWROZXdDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkTmV3Q291bnQgPz8gMCxcclxuICAgICAgaW5nZXN0ZWRFeGlzdGluZ0NvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uaW5nZXN0ZWRFeGlzdGluZ0NvdW50ID8/IDAsXHJcbiAgICAgIHNraXBwZWRPbGRDb3VudDogYXV0b1Njcm9sbFNlc3M/LnNraXBwZWRPbGRDb3VudCA/PyAwLFxyXG4gICAgICBleHBhbmRlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uZXhwYW5kZWRDb3VudCA/PyAwLFxyXG4gICAgfSxcclxuICAgIHJlZmV0Y2hRdWV1ZToge1xyXG4gICAgICB0b3RhbDogcmVmZXRjaFF1ZXVlZCxcclxuICAgICAgcnVubmluZzogcmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsLFxyXG4gICAgICBwcm9jZXNzZWQ6IHJlZmV0Y2hTZXNzPy5wcm9jZXNzZWQgPz8gMCxcclxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHJlZmV0Y2hTZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcclxuICAgIH0sXHJcbiAgICBtZWRpYUNyYXdsUXVldWU6IHtcclxuICAgICAgdG90YWw6IG1lZGlhQ3Jhd2xRdWV1ZWQsXHJcbiAgICAgIHJ1bm5pbmc6IG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcclxuICAgICAgcHJvY2Vzc2VkOiBtZWRpYUNyYXdsU2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBtZWRpYUNyYXdsU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXHJcbiAgICB9LFxyXG4gICAgcmVjZW50VHdlZXRTaWdodGluZ3MsXHJcbiAgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gcmVkYWN0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBFeHRlbnNpb25TdGF0ZVsnc2V0dGluZ3MnXSB7XHJcbiAgcmV0dXJuIHtcclxuICAgIG93bmVyOiBzLm93bmVyLFxyXG4gICAgcmVwbzogcy5yZXBvLFxyXG4gICAgYnJhbmNoOiBzLmJyYW5jaCxcclxuICAgIGVuYWJsZWQ6IHMuZW5hYmxlZCxcclxuICAgIGF1dG9DYXB0dXJlOiBzLmF1dG9DYXB0dXJlLFxyXG4gICAgY29uZmlndXJlZEF0OiBzLmNvbmZpZ3VyZWRBdCxcclxuICAgIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogcy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMsXHJcbiAgICB1cGRhdGVFeGlzdGluZzogcy51cGRhdGVFeGlzdGluZyxcclxuICAgIHBhdFNldDogcy5wYXQubGVuZ3RoID4gMCxcclxuICAgIHBhdFN1ZmZpeDogcy5wYXQubGVuZ3RoID49IDQgPyBzLnBhdC5zbGljZSgtNCkgOiAnJyxcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYXJzZUFyY2hpdmVTbmFwc2hvdChyYXc6IHVua25vd24pOiBBcmNoaXZlU25hcHNob3Qge1xyXG4gIGlmICghcmF3IHx8IHR5cGVvZiByYXcgIT09ICdvYmplY3QnKSB0aHJvdyBuZXcgRXJyb3IoJ21hbmlmZXN0IGlzIG5vdCBhbiBvYmplY3QnKTtcclxuICBjb25zdCBtYW5pZmVzdCA9IHJhdyBhcyB7IGdlbmVyYXRlZF9hdD86IHVua25vd247IGFjY291bnRzPzogdW5rbm93biB9O1xyXG4gIGlmICghQXJyYXkuaXNBcnJheShtYW5pZmVzdC5hY2NvdW50cykpIHRocm93IG5ldyBFcnJvcignbWFuaWZlc3QuYWNjb3VudHMgaXMgbm90IGFuIGFycmF5Jyk7XHJcbiAgY29uc3QgYWNjb3VudHM6IEFyY2hpdmVTbmFwc2hvdFsnYWNjb3VudHMnXSA9IHt9O1xyXG4gIGZvciAoY29uc3QgZW50cnkgb2YgbWFuaWZlc3QuYWNjb3VudHMpIHtcclxuICAgIGlmICghZW50cnkgfHwgdHlwZW9mIGVudHJ5ICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBjb25zdCByb3cgPSBlbnRyeSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgIGNvbnN0IGhhbmRsZSA9IHR5cGVvZiByb3cuaGFuZGxlID09PSAnc3RyaW5nJyA/IHJvdy5oYW5kbGUgOiAnJztcclxuICAgIGlmICghaGFuZGxlIHx8IGhhbmRsZSA9PT0gJ19taXNjJykgY29udGludWU7XHJcbiAgICBhY2NvdW50c1toYW5kbGUudG9Mb3dlckNhc2UoKV0gPSB7XHJcbiAgICAgIGhhbmRsZSxcclxuICAgICAgbGF0ZXN0X3Bvc3RfYXQ6IHR5cGVvZiByb3cubGF0ZXN0X3Bvc3RfYXQgPT09ICdzdHJpbmcnID8gcm93LmxhdGVzdF9wb3N0X2F0IDogbnVsbCxcclxuICAgICAgbGF0ZXN0X2NhcHR1cmVfYXQ6IHR5cGVvZiByb3cubGF0ZXN0X2NhcHR1cmVfYXQgPT09ICdzdHJpbmcnID8gcm93LmxhdGVzdF9jYXB0dXJlX2F0IDogbnVsbCxcclxuICAgICAgcm93X2NvdW50OiB0eXBlb2Ygcm93LnJvd19jb3VudCA9PT0gJ251bWJlcicgPyByb3cucm93X2NvdW50IDogbnVsbCxcclxuICAgIH07XHJcbiAgfVxyXG4gIHJldHVybiB7XHJcbiAgICBnZW5lcmF0ZWRfYXQ6IHR5cGVvZiBtYW5pZmVzdC5nZW5lcmF0ZWRfYXQgPT09ICdzdHJpbmcnID8gbWFuaWZlc3QuZ2VuZXJhdGVkX2F0IDogbnVsbCxcclxuICAgIGZldGNoZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIGFjY291bnRzLFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFyY2hpdmVTbmFwc2hvdEhhc1R3ZWV0KHQ6IENhbm9uaWNhbFR3ZWV0LCBzbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbCk6IGJvb2xlYW4ge1xyXG4gIGlmICghc25hcHNob3QpIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBlbnRyeSA9IHNuYXBzaG90LmFjY291bnRzW3QuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKV07XHJcbiAgaWYgKCFlbnRyeT8ubGF0ZXN0X3Bvc3RfYXQpIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBwb3N0ZWQgPSBEYXRlLnBhcnNlKHQucG9zdGVkX2F0KTtcclxuICBjb25zdCBsYXRlc3QgPSBEYXRlLnBhcnNlKGVudHJ5LmxhdGVzdF9wb3N0X2F0KTtcclxuICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHBvc3RlZCkgJiYgTnVtYmVyLmlzRmluaXRlKGxhdGVzdCkgJiYgcG9zdGVkIDw9IGxhdGVzdDtcclxufVxyXG5cclxuZnVuY3Rpb24gYnVpbGRUd2VldFNpZ2h0aW5nKFxyXG4gIHQ6IENhbm9uaWNhbFR3ZWV0LFxyXG4gIGVuZHBvaW50OiBzdHJpbmcsXHJcbiAgc2VlbkF0OiBzdHJpbmcsXHJcbiAgZnJlc2huZXNzOiAnbmV3JyB8ICdleGlzdGluZycgPSAnbmV3JyxcclxuICBhY3Rpb246IFR3ZWV0U2lnaHRpbmdbJ2FjdGlvbiddID0gJ2J1ZmZlcmVkJ1xyXG4pOiBUd2VldFNpZ2h0aW5nIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHdlZXRfaWQ6IHQudHdlZXRfaWQsXHJcbiAgICBhY2NvdW50X2hhbmRsZTogdC5hY2NvdW50X2hhbmRsZSxcclxuICAgIHBvc3RlZF9hdDogdC5wb3N0ZWRfYXQsXHJcbiAgICB0ZXh0OiB0LnRleHRfcmVzb2x2ZWQgfHwgdC50ZXh0LFxyXG4gICAgdHdlZXRfdHlwZTogdC50d2VldF90eXBlLFxyXG4gICAgdHdlZXRfdXJsOiB0LnR3ZWV0X3VybCxcclxuICAgIHNlZW5fYXQ6IHNlZW5BdCxcclxuICAgIGVuZHBvaW50LFxyXG4gICAgYXJjaGl2ZV9zdGF0dXM6IGZyZXNobmVzcyA9PT0gJ2V4aXN0aW5nJyA/ICdzYXZlZCcgOiAnbmV3JyxcclxuICAgIGFjdGlvbixcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBpc1dyaXRlQXV0aEVycm9yKG1lc3NhZ2U6IHN0cmluZyB8IG51bGwpOiBib29sZWFuIHtcclxuICByZXR1cm4gKFxyXG4gICAgdHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnICYmXHJcbiAgICAvUmVzb3VyY2Ugbm90IGFjY2Vzc2libGUgYnkgcGVyc29uYWwgYWNjZXNzIHRva2VufFxcL2dpdFxcL2Jsb2JzfFxcL2dpdFxcL3JlZnMvaS50ZXN0KG1lc3NhZ2UpXHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gaXNvQ29tcGFjdChpc286IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgLy8gMjAyNS0wNC0xMlQxNDoyMzowMS4wMDBaIFx1MjE5MiAyMDI1LTA0LTEyVDE0MjMwMVpcclxuICBjb25zdCBkID0gbmV3IERhdGUoaXNvKTtcclxuICBpZiAoTnVtYmVyLmlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIGlzby5yZXBsYWNlKC9bOi5dL2csICcnKTtcclxuICBjb25zdCBwYWQgPSAobjogbnVtYmVyLCB3ID0gMikgPT4gU3RyaW5nKG4pLnBhZFN0YXJ0KHcsICcwJyk7XHJcbiAgcmV0dXJuIChcclxuICAgIGAke2QuZ2V0VVRDRnVsbFllYXIoKX0tJHtwYWQoZC5nZXRVVENNb250aCgpICsgMSl9LSR7cGFkKGQuZ2V0VVRDRGF0ZSgpKX1gICtcclxuICAgIGBUJHtwYWQoZC5nZXRVVENIb3VycygpKX0ke3BhZChkLmdldFVUQ01pbnV0ZXMoKSl9JHtwYWQoZC5nZXRVVENTZWNvbmRzKCkpfVpgXHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gdmlld2VyVXJsKHM6IFNldHRpbmdzKTogc3RyaW5nIHtcclxuICByZXR1cm4gYGh0dHBzOi8vJHtzLm93bmVyfS5naXRodWIuaW8vJHtzLnJlcG99L2A7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBXYWxrIGBub2RlYCBjb2xsZWN0aW5nIGRvdHRlZCBrZXkgcGF0aHMgdXAgdG8gYG1heERlcHRoYCBkZWVwLiBBcnJheVxyXG4gKiBpbmRpY2VzIGNvbGxhcHNlIHRvIGBbMF1gICh3ZSBvbmx5IGRlc2NlbmQgaW50byB0aGUgZmlyc3QgZWxlbWVudCkuIFVzZWRcclxuICogdG8gc3VyZmFjZSB0aGUgc3RydWN0dXJhbCBza2VsZXRvbiBvZiBhbiB1bmZhbWlsaWFyIEdyYXBoUUwgcmVzcG9uc2VcclxuICogd2l0aG91dCBpbmNsdWRpbmcgYW55IGRhdGEgdmFsdWVzLlxyXG4gKi9cclxuLyoqIENvbGxlY3QgZXZlcnkgZGlzdGluY3QgYF9fdHlwZW5hbWVgIHZhbHVlIGZvdW5kIGFueXdoZXJlIGluIHRoZSB0cmVlLiAqL1xyXG5mdW5jdGlvbiBwcm9iZVR5cGVuYW1lcyhub2RlOiB1bmtub3duKTogc3RyaW5nW10ge1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xyXG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XHJcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcclxuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcclxuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgICAgaWYgKHR5cGVvZiBvYmouX190eXBlbmFtZSA9PT0gJ3N0cmluZycpIHNlZW4uYWRkKG9iai5fX3R5cGVuYW1lKTtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIFsuLi5zZWVuXS5zb3J0KCk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIGFueXdoZXJlIGluIHRoZSB0cmVlIHdob3NlIGBfX3R5cGVuYW1lYCBtYXRjaGVzIGFuZFxyXG4gKiByZXR1cm4gaXRzIHRvcC1sZXZlbCBrZXkgbGlzdCAoc29ydGVkKS4gVXNlZnVsIGZvciBkaXNjb3ZlcmluZyB3aGF0IGZpZWxkc1xyXG4gKiBYIGlzIGFjdHVhbGx5IHNoaXBwaW5nIGZvciBhIGdpdmVuIG5vZGUgdHlwZSBhZnRlciBhIHNjaGVtYSBjaGFuZ2UuXHJcbiAqL1xyXG5mdW5jdGlvbiBwcm9iZUZpcnN0VHlwZVNoYXBlKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcpOiBzdHJpbmdbXSB8IG51bGwge1xyXG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xyXG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcclxuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xyXG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gICAgICBpZiAob2JqLl9fdHlwZW5hbWUgPT09IHR5cGVuYW1lKSB7XHJcbiAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKG9iaikuc29ydCgpO1xyXG4gICAgICB9XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcblxyXG4vKipcclxuICogRmluZCB0aGUgZmlyc3Qgbm9kZSB3aXRoIGBfX3R5cGVuYW1lID09PSB0eXBlbmFtZWAsIHRoZW4gZGVzY2VuZCB0aHJvdWdoXHJcbiAqIHRoZSBnaXZlbiBrZXkgcGF0aCwgYW5kIHJldHVybiB0aGUgdG9wLWxldmVsIGtleXMgb2Ygd2hhdGV2ZXIgaXMgYXQgdGhlXHJcbiAqIGVuZC4gUmV0dXJucyBhIG1hcmtlciBzdHJpbmcgd2hlbiB0aGUgcGF0aCBsZWFkcyBzb21ld2hlcmUgbm9uLW9iamVjdCBzb1xyXG4gKiB3ZSBjYW4gdGVsbCBhcGFydCBcImFic2VudFwiIGZyb20gXCJwcmVzZW50IGJ1dCBub3QgYW4gb2JqZWN0XCIuXHJcbiAqL1xyXG5mdW5jdGlvbiBwcm9iZVR5cGVkTmVzdGVkKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcsIHBhdGg6IHN0cmluZ1tdKTogdW5rbm93biB7XHJcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcclxuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xyXG4gIGxldCBmb3VuZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsID0gbnVsbDtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xyXG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcclxuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xyXG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gICAgICBpZiAob2JqLl9fdHlwZW5hbWUgPT09IHR5cGVuYW1lKSB7XHJcbiAgICAgICAgZm91bmQgPSBvYmo7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKCFmb3VuZCkgcmV0dXJuIG51bGw7XHJcbiAgbGV0IGN1cjogdW5rbm93biA9IGZvdW5kO1xyXG4gIGZvciAoY29uc3Qgc2VnIG9mIHBhdGgpIHtcclxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIHJldHVybiBgPCR7Y3VyID09PSBudWxsID8gJ251bGwnIDogdHlwZW9mIGN1cn0+YDtcclxuICAgIGN1ciA9IChjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW3NlZ107XHJcbiAgfVxyXG4gIGlmIChjdXIgPT09IHVuZGVmaW5lZCkgcmV0dXJuICc8bWlzc2luZz4nO1xyXG4gIGlmIChjdXIgPT09IG51bGwpIHJldHVybiAnPG51bGw+JztcclxuICBpZiAodHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIHJldHVybiBgPCR7dHlwZW9mIGN1cn0+YDtcclxuICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSByZXR1cm4gYDxhcnJheSBsZW49JHtjdXIubGVuZ3RofT5gO1xyXG4gIHJldHVybiBPYmplY3Qua2V5cyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLnNvcnQoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc2hvcnRlblVybCh1OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIC8vIEFjdGl2aXR5LXRhaWwgY29udGV4dCBpcyBtb3JlIHVzZWZ1bCB3aXRoIGp1c3QgdGhlIHBhdGg7IGZ1bGwgVVJMcyBiZWNvbWVcclxuICAvLyBoYXJkIHRvIHJlYWQgYXQgdGhlIHNpZGViYXIncyB3aWR0aC5cclxuICB0cnkge1xyXG4gICAgY29uc3QgcGFyc2VkID0gbmV3IFVSTCh1KTtcclxuICAgIGNvbnN0IHBhdGggPSBwYXJzZWQucGF0aG5hbWUgKyAocGFyc2VkLnNlYXJjaCA/ICc/XHUyMDI2JyA6ICcnKTtcclxuICAgIHJldHVybiBwYXJzZWQuaG9zdCA9PT0gJ3guY29tJyB8fCBwYXJzZWQuaG9zdCA9PT0gJ3R3aXR0ZXIuY29tJ1xyXG4gICAgICA/IHBhdGhcclxuICAgICAgOiBgJHtwYXJzZWQuaG9zdH0ke3BhdGh9YDtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiB1Lmxlbmd0aCA+IDgwID8gYCR7dS5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHU7XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0gRGV2IGhlbHBlcnMgZXhwb3NlZCBvbiBnbG9iYWxUaGlzIGZvciB0aGUgZGV2dG9vbHMgY29uc29sZSAtLS0tLS0tLS0tXHJcbi8vIChlLmcuIGBfX2ltbUFyY2hpdmUuY2xlYXJBbGwoKWAgaW4gdGhlIGJhY2tncm91bmQgd29ya2VyJ3MgZGV2dG9vbHMpLlxyXG5cclxuKGdsb2JhbFRoaXMgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLl9faW1tQXJjaGl2ZSA9IHtcclxuICBjbGVhckFsbCxcclxuICBhY3Rpdml0eTogZ2V0QWN0aXZpdHksXHJcbiAgYWNjb3VudHM6IGdldEFjY291bnRzLFxyXG4gIGJ1ZmZlcnM6IGdldFJ1bkJ1ZmZlcnMsXHJcbiAgZmx1c2hBbGw6ICgpID0+IGZsdXNoQWxsKCdkZXZ0b29scycpLFxyXG4gIHN0YXRlOiBidWlsZFN0YXRlLFxyXG4gIHJlZmV0Y2hRdWV1ZTogZ2V0UmVmZXRjaFF1ZXVlLFxyXG4gIHN0YXJ0UmVmZXRjaDogc3RhcnRSZWZldGNoTG9vcCxcclxuICBjYW5jZWxSZWZldGNoOiBjYW5jZWxSZWZldGNoTG9vcCxcclxuICBtZWRpYUNyYXdsUXVldWU6IGdldE1lZGlhQ3Jhd2xRdWV1ZSxcclxuICBzdGFydE1lZGlhQ3Jhd2w6IHN0YXJ0TWVkaWFDcmF3bExvb3AsXHJcbiAgY2FuY2VsTWVkaWFDcmF3bDogY2FuY2VsTWVkaWFDcmF3bExvb3AsXHJcbn07XHJcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFBQSxFQUNQLE1BQU07QUFBQTtBQUFBO0FBQUEsRUFHTixRQUFRO0FBQUEsRUFDUixTQUFTO0FBQUEsRUFDVCxhQUFhO0FBQUEsRUFDYixjQUFjO0FBQUEsRUFDZCx1QkFBdUI7QUFBQSxFQUN2QixnQkFBZ0I7QUFDbEI7QUFFTyxJQUFNLHNCQUFzQjtBQUM1QixJQUFNLHNCQUFzQjtBQUk1QixJQUFNLG9CQUFxQztBQUFBLEVBQ2hELEVBQUUsUUFBUSxVQUFVLE9BQU8sbUNBQW1DLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxVQUFVLE9BQU8sNENBQTRDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxPQUFPLE9BQU8sc0NBQXNDLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxTQUFTLE9BQU8sNkNBQTZDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxjQUFjLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUFBLEVBQ25FLEVBQUUsUUFBUSxZQUFZLE9BQU8sK0JBQStCLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sa0NBQWtDLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sNEJBQTRCLFVBQVUsT0FBTztBQUFBLEVBQ3ZFLEVBQUUsUUFBUSxtQkFBbUIsT0FBTyxxQkFBcUIsVUFBVSxPQUFPO0FBQzVFO0FBR08sSUFBTSxrQkFBdUMsb0JBQUksSUFBSTtBQUFBLEVBQzFEO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBV00sSUFBTSxvQkFBeUMsb0JBQUksSUFBSSxDQUFDLG9CQUFvQixjQUFjLENBQUM7QUF1QjNGLElBQU0sd0JBQXdCO0FBRzlCLElBQU0sZ0JBQWdCO0FBR3RCLElBQU0sc0JBQXNCO0FBRzVCLElBQU0sb0JBQW9CO0FBRzFCLElBQU0sZ0NBQWdDLEtBQUssS0FBSztBQUVoRCxJQUFNLG1CQUFtQjs7O0FDdkVoQyxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGtCQUFrQjtBQUV4QixJQUFJLGtCQUFvQztBQUN4QyxJQUFJLHNCQUFxQztBQUV6QyxTQUFTLFNBQVMsS0FBeUI7QUFDekMsTUFBSSxJQUFJO0FBQ1IsYUFBVyxLQUFLLElBQUssTUFBSyxPQUFPLGFBQWEsQ0FBQztBQUMvQyxTQUFPLEtBQUssQ0FBQztBQUNmO0FBRUEsU0FBUyxXQUFXLEdBQXVCO0FBQ3pDLFFBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsUUFBTSxNQUFNLElBQUksV0FBVyxJQUFJLE1BQU07QUFDckMsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsSUFBSyxLQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQztBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxlQUFlLG1CQUFtRTtBQUNoRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUMvRCxRQUFNLElBQUksT0FBTyxnQkFBZ0I7QUFDakMsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxXQUFPLEVBQUUsU0FBUyxHQUFHLE1BQU0sV0FBVyxDQUFDLEVBQUU7QUFBQSxFQUMzQztBQUNBLFFBQU0sT0FBTyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxTQUFTLElBQUk7QUFDN0IsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUM7QUFDL0QsU0FBTyxFQUFFLFNBQVMsS0FBSztBQUN6QjtBQUVBLGVBQWUsWUFBZ0M7QUFDN0MsUUFBTSxFQUFFLFNBQVMsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBQ2pELE1BQUksb0JBQW9CLFFBQVEsd0JBQXdCLFNBQVM7QUFDL0QsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUU7QUFBQSxJQUM3QixHQUFHLFFBQVEsUUFBUSxFQUFFLElBQUksUUFBUSxRQUFRLFlBQVksRUFBRSxPQUFPO0FBQUEsRUFDaEU7QUFDQSxRQUFNLFdBQVcsSUFBSSxXQUFXLEtBQUssU0FBUyxLQUFLLE1BQU07QUFDekQsV0FBUyxJQUFJLE1BQU0sQ0FBQztBQUNwQixXQUFTLElBQUksTUFBTSxLQUFLLE1BQU07QUFDOUIsUUFBTSxPQUFPLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxRQUFRO0FBQzNELFFBQU0sTUFBTSxNQUFNLE9BQU8sT0FBTyxVQUFVLE9BQU8sTUFBTSxFQUFFLE1BQU0sVUFBVSxHQUFHLE9BQU87QUFBQSxJQUNqRjtBQUFBLElBQ0E7QUFBQSxFQUNGLENBQUM7QUFDRCxvQkFBa0I7QUFDbEIsd0JBQXNCO0FBQ3RCLFNBQU87QUFDVDtBQUVPLFNBQVMsZUFBZSxHQUFvQjtBQUNqRCxTQUFPLEVBQUUsV0FBVyxlQUFlO0FBQ3JDO0FBRUEsZUFBc0IsV0FBVyxXQUFvQztBQUNuRSxNQUFJLENBQUMsVUFBVyxRQUFPO0FBQ3ZCLFFBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsUUFBTSxLQUFLLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDcEQsUUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsSUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBRztBQUFBLElBQ3RCO0FBQUEsSUFDQSxJQUFJLFlBQVksRUFBRSxPQUFPLFNBQVM7QUFBQSxFQUNwQztBQUNBLFNBQU8sR0FBRyxlQUFlLEdBQUcsU0FBUyxFQUFFLENBQUMsSUFBSSxTQUFTLElBQUksV0FBVyxFQUFFLENBQUMsQ0FBQztBQUMxRTtBQUVBLGVBQXNCLFdBQVcsVUFBbUM7QUFDbEUsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUd0QixNQUFJLENBQUMsU0FBUyxXQUFXLGVBQWUsRUFBRyxRQUFPO0FBQ2xELFFBQU0sUUFBUSxTQUFTLE1BQU0sZ0JBQWdCLE1BQU0sRUFBRSxNQUFNLEdBQUc7QUFDOUQsTUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBQy9CLFFBQU0sQ0FBQyxPQUFPLEtBQUssSUFBSTtBQUN2QixNQUFJLENBQUMsU0FBUyxDQUFDLE1BQU8sUUFBTztBQUM3QixNQUFJO0FBQ0YsVUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsTUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBdUI7QUFBQSxNQUMxQztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsV0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEVBQUU7QUFBQSxFQUNwQyxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjs7O0FDbkJBLElBQU0scUJBQXNDO0FBQUEsRUFDMUMsUUFBUTtBQUFBLEVBQ1IsT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUFBLEVBQ1AsZUFBZTtBQUFBLEVBQ2Ysd0JBQXdCO0FBQUEsRUFDeEIsa0JBQWtCO0FBQ3BCO0FBRUEsSUFBTSxXQUF5QjtBQUFBLEVBQzdCLFVBQVUsRUFBRSxHQUFHLGlCQUFpQjtBQUFBLEVBQ2hDLFVBQVUsQ0FBQyxHQUFHLGlCQUFpQjtBQUFBLEVBQy9CLHFCQUFxQjtBQUFBLEVBQ3JCLGlCQUFpQjtBQUFBLEVBQ2pCLFlBQVksRUFBRSxHQUFHLG1CQUFtQjtBQUFBLEVBQ3BDLFVBQVUsQ0FBQztBQUFBLEVBQ1gsWUFBWSxDQUFDO0FBQUEsRUFDYixVQUFVLENBQUM7QUFBQSxFQUNYLHNCQUFzQixDQUFDO0FBQUEsRUFDdkIsZ0JBQWdCLENBQUM7QUFBQSxFQUNqQixjQUFjLENBQUM7QUFBQSxFQUNmLGlCQUFpQixDQUFDO0FBQUEsRUFDbEIsZ0JBQWdCO0FBQUEsRUFDaEIsbUJBQW1CO0FBQUEsRUFDbkIsbUJBQW1CO0FBQ3JCO0FBRUEsZUFBZSxPQUFxQyxLQUFrQztBQUNwRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDbEQsUUFBTSxRQUFRLE9BQU8sR0FBRztBQUN4QixNQUFJLFVBQVUsUUFBVztBQUN2QixXQUFPLGdCQUFnQixTQUFTLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBQ0EsU0FBTztBQUNUO0FBRUEsZUFBZSxPQUFxQyxLQUFRLE9BQXVDO0FBQ2pHLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQztBQUNsRDtBQUlBLGVBQXNCLGNBQWlDO0FBS3JELFFBQU0sU0FBUyxNQUFNLE9BQU8sVUFBVTtBQUN0QyxRQUFNLFNBQVMsRUFBRSxHQUFHLGtCQUFrQixHQUFHLE9BQU87QUFDaEQsTUFBSSxPQUFPLE9BQU8sZUFBZSxPQUFPLEdBQUcsR0FBRztBQUM1QyxRQUFJO0FBQ0YsYUFBTyxNQUFNLE1BQU0sV0FBVyxPQUFPLEdBQUc7QUFBQSxJQUMxQyxRQUFRO0FBQ04sYUFBTyxNQUFNO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixZQUFZLEdBQTRCO0FBRzVELFFBQU0sVUFBb0IsRUFBRSxHQUFHLEVBQUU7QUFDakMsTUFBSSxRQUFRLE9BQU8sQ0FBQyxlQUFlLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFlBQVEsTUFBTSxNQUFNLFdBQVcsUUFBUSxHQUFHO0FBQUEsRUFDNUM7QUFDQSxRQUFNLE9BQU8sWUFBWSxPQUFPO0FBQ2xDO0FBQ0EsZUFBc0IsZUFBZSxPQUE2QztBQUNoRixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEMsUUFBTSxZQUFZLElBQUk7QUFDdEIsU0FBTztBQUNUO0FBSUEsZUFBc0IsY0FBd0M7QUFDNUQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUFZLEdBQW1DO0FBQ25FLFFBQU0sT0FBTyxZQUFZLENBQUM7QUFDNUI7QUFDQSxlQUFzQix5QkFBaUQ7QUFDckUsU0FBTyxPQUFPLHFCQUFxQjtBQUNyQztBQUNBLGVBQXNCLHVCQUF1QixLQUFtQztBQUM5RSxRQUFNLE9BQU8sdUJBQXVCLEdBQUc7QUFDekM7QUFJQSxlQUFzQixxQkFBc0Q7QUFDMUUsU0FBTyxPQUFPLGlCQUFpQjtBQUNqQztBQUVBLGVBQXNCLG1CQUFtQixVQUFpRDtBQUN4RixRQUFNLE9BQU8sbUJBQW1CLFFBQVE7QUFDMUM7QUFJQSxlQUFzQixnQkFBMEM7QUFDOUQsUUFBTSxJQUFJLE1BQU0sT0FBTyxZQUFZO0FBRW5DLFFBQU0sTUFBdUI7QUFBQSxJQUMzQixHQUFHO0FBQUEsSUFDSCxlQUFlLEVBQUUsa0JBQWtCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDeEQsd0JBQ0UsRUFBRSwyQkFBMkIsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUNwRCxrQkFBa0IsRUFBRSxxQkFBcUIsU0FBWSxPQUFPLEVBQUU7QUFBQSxFQUNoRTtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLGNBQWMsR0FBbUM7QUFDckUsUUFBTSxPQUFPLGNBQWMsQ0FBQztBQUM5QjtBQUlBLFNBQVMsV0FBbUI7QUFDMUIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQzdDO0FBRUEsZUFBc0IsY0FBdUQ7QUFDM0UsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUNwQixRQUNBLE9BQ3lCO0FBQ3pCLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxNQUFNLElBQUksTUFBTSxLQUFLO0FBQUEsSUFDekIsWUFBWTtBQUFBLElBQ1osV0FBVyxTQUFTO0FBQUEsSUFDcEIsZUFBZTtBQUFBLElBQ2YsZ0JBQWdCO0FBQUEsSUFDaEIsZUFBZTtBQUFBLEVBQ2pCO0FBQ0EsTUFBSSxJQUFJLGNBQWMsU0FBUyxHQUFHO0FBQ2hDLFFBQUksWUFBWSxTQUFTO0FBQ3pCLFFBQUksYUFBYTtBQUFBLEVBQ25CO0FBQ0EsUUFBTSxPQUF1QixFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEQsTUFBSSxNQUFNLElBQUk7QUFDZCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGlCQUFpQixRQUFnQixPQUE4QjtBQUNuRixRQUFNLFlBQVksUUFBUSxFQUFFLGVBQWUsTUFBTSxDQUFDO0FBQ3BEO0FBSUEsZUFBc0IsZ0JBQW9EO0FBQ3hFLFNBQU8sT0FBTyxZQUFZO0FBQzVCO0FBRUEsZUFBc0IsYUFBYSxRQUEyQztBQUM1RSxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFNBQU8sSUFBSSxNQUFNLEtBQUs7QUFDeEI7QUFFQSxlQUFzQixhQUFhLFFBQWdCLEtBQStCO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsTUFBSSxNQUFNLElBQUk7QUFDZCxRQUFNLE9BQU8sY0FBYyxHQUFHO0FBQ2hDO0FBRUEsZUFBc0IsZUFBZSxRQUErQjtBQUNsRSxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFNBQU8sSUFBSSxNQUFNO0FBQ2pCLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFJQSxlQUFzQixjQUFtQztBQUN2RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUVBLGVBQXNCLGVBQWUsSUFBbUM7QUFDdEUsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixNQUFJLFFBQVEsRUFBRTtBQUNkLE1BQUksSUFBSSxTQUFTLGtCQUFtQixLQUFJLFNBQVM7QUFDakQsUUFBTSxPQUFPLFlBQVksR0FBRztBQUM1QixTQUFPO0FBQ1Q7QUFFQSxlQUFzQixnQkFBK0I7QUFDbkQsUUFBTSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQzdCO0FBSUEsSUFBTSw2QkFBNkI7QUFFbkMsZUFBc0IsMEJBQW9EO0FBQ3hFLFNBQU8sT0FBTyxzQkFBc0I7QUFDdEM7QUFFQSxlQUFzQiw0QkFBNEIsTUFBc0M7QUFDdEYsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixRQUFNLE1BQU0sTUFBTSx3QkFBd0I7QUFDMUMsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxPQUF3QixDQUFDO0FBQy9CLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFVBQU0sTUFBTSxHQUFHLElBQUksZUFBZSxZQUFZLENBQUMsSUFBSSxJQUFJLFFBQVE7QUFDL0QsUUFBSSxLQUFLLElBQUksR0FBRyxFQUFHO0FBQ25CLFNBQUssSUFBSSxHQUFHO0FBQ1osU0FBSyxLQUFLLEdBQUc7QUFBQSxFQUNmO0FBQ0EsYUFBVyxPQUFPLEtBQUs7QUFDckIsVUFBTSxNQUFNLEdBQUcsSUFBSSxlQUFlLFlBQVksQ0FBQyxJQUFJLElBQUksUUFBUTtBQUMvRCxRQUFJLEtBQUssSUFBSSxHQUFHLEVBQUc7QUFDbkIsU0FBSyxJQUFJLEdBQUc7QUFDWixTQUFLLEtBQUssR0FBRztBQUFBLEVBQ2Y7QUFDQSxPQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssUUFBUSwwQkFBMEI7QUFDOUQsUUFBTSxPQUFPLHdCQUF3QixJQUFJO0FBQzNDO0FBSUEsZUFBc0Isb0JBQTZFO0FBQ2pHLFNBQU8sT0FBTyxnQkFBZ0I7QUFDaEM7QUFFQSxlQUFzQixrQkFDcEIsS0FDZTtBQUNmLFFBQU0sT0FBTyxrQkFBa0IsR0FBRztBQUNwQztBQVVPLFNBQVMsY0FDZCxPQUNBLFVBQ0EsU0FDQSxRQUNBLGNBQXVCLE9BQ2Y7QUFDUixTQUFPLEdBQUcsS0FBSyxJQUFJLFFBQVEsSUFBSSxPQUFPLElBQUksTUFBTSxJQUFJLGNBQWMsTUFBTSxHQUFHO0FBQzdFO0FBR0EsZUFBc0Isb0JBQW9CLFVBQW1DO0FBQzNFLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxRQUFNLFNBQVMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLFFBQVEsRUFBRSxZQUFZO0FBQzNELE1BQUksU0FBUztBQUNiLGFBQVcsVUFBVSxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ3JDLFVBQU0sUUFBUSxJQUFJLE1BQU07QUFDeEIsUUFBSSxDQUFDLE1BQU87QUFDWixlQUFXLE9BQU8sT0FBTyxLQUFLLEtBQUssR0FBRztBQUNwQyxZQUFNLElBQUksTUFBTSxHQUFHO0FBQ25CLFVBQUksS0FBSyxFQUFFLEtBQUssUUFBUTtBQUN0QixlQUFPLE1BQU0sR0FBRztBQUNoQixrQkFBVTtBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLEtBQUssS0FBSyxFQUFFLFdBQVcsRUFBRyxRQUFPLElBQUksTUFBTTtBQUFBLEVBQ3hEO0FBQ0EsTUFBSSxTQUFTLEVBQUcsT0FBTSxrQkFBa0IsR0FBRztBQUMzQyxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixrQkFBcUQ7QUFDekUsU0FBTyxPQUFPLGNBQWM7QUFDOUI7QUFFQSxlQUFzQixvQkFBcUM7QUFDekQsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixlQUFlLFFBQWdCLFNBQWdDO0FBQ25GLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUFBLEVBQ2hDO0FBQ0Y7QUFFQSxlQUFzQixlQUFlLFFBQWdCLFNBQWdDO0FBQ25GLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxRQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLE1BQUksQ0FBQyxJQUFLO0FBQ1YsUUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxNQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUNqQixRQUFNLE9BQU8sZ0JBQWdCLENBQUM7QUFDaEM7QUFFQSxlQUFzQixvQkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLHFCQUF3RDtBQUM1RSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBRUEsZUFBc0IsdUJBQXdDO0FBQzVELFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0Isa0JBQWtCLFlBQTJCLFNBQWdDO0FBQ2pHLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxRQUFNLFNBQVMsY0FBYztBQUM3QixRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUFBLEVBQ25DO0FBQ0Y7QUFFQSxlQUFzQixrQkFBa0IsU0FBZ0M7QUFDdEUsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksVUFBVTtBQUNkLGFBQVcsVUFBVSxPQUFPLEtBQUssQ0FBQyxHQUFHO0FBQ25DLFVBQU0sTUFBTSxFQUFFLE1BQU07QUFDcEIsUUFBSSxDQUFDLElBQUs7QUFDVixVQUFNLFdBQVcsSUFBSSxPQUFPLENBQUMsT0FBTyxPQUFPLE9BQU87QUFDbEQsUUFBSSxTQUFTLFdBQVcsSUFBSSxRQUFRO0FBQ2xDLGdCQUFVO0FBQ1YsVUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLEVBQUUsTUFBTTtBQUFBLFVBQ3JDLEdBQUUsTUFBTSxJQUFJO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxRQUFTLE9BQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUNoRDtBQUVBLGVBQXNCLHVCQUdaO0FBQ1IsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFFBQUksSUFBSSxTQUFTLEVBQUcsUUFBTyxFQUFFLFFBQVEsU0FBUyxJQUFJLENBQUMsRUFBRztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0IsWUFBWSxTQUFtQztBQUNuRSxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsYUFBVyxTQUFTLE9BQU8sT0FBTyxHQUFHLEdBQUc7QUFDdEMsUUFBSSxTQUFTLFdBQVcsTUFBTyxRQUFPO0FBQUEsRUFDeEM7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixvQkFBaUQ7QUFDckUsU0FBTyxPQUFPLGdCQUFnQjtBQUNoQztBQUNBLGVBQXNCLGtCQUFrQixHQUFzQztBQUM1RSxRQUFNLE9BQU8sa0JBQWtCLENBQUM7QUFDbEM7QUFDQSxlQUFzQix1QkFBb0Q7QUFDeEUsU0FBTyxPQUFPLG1CQUFtQjtBQUNuQztBQUNBLGVBQXNCLHFCQUFxQixHQUFzQztBQUMvRSxRQUFNLE9BQU8scUJBQXFCLENBQUM7QUFDckM7QUFDQSxlQUFzQix1QkFBMEQ7QUFDOUUsU0FBTyxPQUFPLG1CQUFtQjtBQUNuQztBQUNBLGVBQXNCLHFCQUFxQixHQUE0QztBQUNyRixRQUFNLE9BQU8scUJBQXFCLENBQUM7QUFDckM7QUFZQSxlQUFzQixvQkFBb0IsVUFNdkM7QUFDRCxRQUFNLFlBQVksSUFBSSxJQUFJLENBQUMsR0FBRyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsQ0FBQztBQUNuRSxRQUFNLGFBQWEsQ0FBQyxNQUF1QixVQUFVLElBQUksRUFBRSxZQUFZLENBQUM7QUFHeEUsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLGtCQUFrQjtBQUN0QixhQUFXLEtBQUssT0FBTyxLQUFLLFFBQVEsR0FBRztBQUNyQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxTQUFTLENBQUM7QUFDakIseUJBQW1CO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLFlBQVksUUFBUTtBQUdqQyxRQUFNLFVBQVUsTUFBTSxjQUFjO0FBQ3BDLE1BQUksaUJBQWlCO0FBQ3JCLGFBQVcsS0FBSyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3BDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLFFBQVEsQ0FBQztBQUNoQix3QkFBa0I7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sY0FBYyxPQUFPO0FBR2xDLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxNQUFJLDBCQUEwQjtBQUM5QixhQUFXLEtBQUssT0FBTyxLQUFLLEdBQUcsR0FBRztBQUNoQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxJQUFJLENBQUM7QUFDWixpQ0FBMkI7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGtCQUFrQixHQUFHO0FBRzNCLFFBQU0sS0FBSyxNQUFNLGdCQUFnQjtBQUNqQyxNQUFJLHdCQUF3QjtBQUM1QixhQUFXLEtBQUssT0FBTyxLQUFLLEVBQUUsR0FBRztBQUMvQixRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxHQUFHLENBQUM7QUFDWCwrQkFBeUI7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sZ0JBQWdCLEVBQUU7QUFLL0IsUUFBTSxLQUFLLE1BQU0sbUJBQW1CO0FBQ3BDLE1BQUksdUJBQXVCO0FBQzNCLGFBQVcsS0FBSyxPQUFPLEtBQUssRUFBRSxHQUFHO0FBQy9CLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQiwrQkFBeUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHO0FBQ3RDLGFBQU8sR0FBRyxDQUFDO0FBQUEsSUFDYjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sbUJBQW1CLEVBQUU7QUFFbEMsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBSUEsZUFBc0IsV0FBMEI7QUFDOUMsUUFBTSxRQUFRLFFBQVEsTUFBTSxNQUFNO0FBQ3BDOzs7QUN0a0JBLElBQUksWUFBNkM7QUFFMUMsU0FBUyxlQUFlLElBQWtDO0FBQy9ELGNBQVk7QUFDZDtBQUVBLFNBQVMsU0FBaUI7QUFDeEIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNoQztBQUVBLGVBQWUsS0FBSyxPQUFpQixLQUFhLFNBQWlEO0FBQ2pHLFFBQU0sS0FBZSxFQUFFLElBQUksT0FBTyxHQUFHLE9BQU8sS0FBSyxTQUFTLE9BQU8sT0FBTyxFQUFFO0FBRTFFLFFBQU0sT0FBTyxpQkFBaUIsTUFBTSxZQUFZLENBQUMsSUFBSSxHQUFHO0FBQ3hELE1BQUksVUFBVSxRQUFTLFNBQVEsTUFBTSxNQUFNLEdBQUcsT0FBTztBQUFBLFdBQzVDLFVBQVUsT0FBUSxTQUFRLEtBQUssTUFBTSxHQUFHLE9BQU87QUFBQSxNQUNuRCxTQUFRLElBQUksTUFBTSxHQUFHLE9BQU87QUFFakMsTUFBSTtBQUNGLFVBQU0sZUFBZSxFQUFFO0FBQUEsRUFDekIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDJDQUEyQyxHQUFHO0FBQUEsRUFDN0Q7QUFFQSxNQUFJO0FBQ0YsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCLFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUFFTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxNQUFNLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN2RixTQUFPLEtBQUssU0FBUyxLQUFLLE9BQU87QUFDbkM7QUFFTyxTQUFTLGNBQWMsS0FBeUQ7QUFDckYsTUFBSSxlQUFlLE9BQU87QUFDeEIsV0FBTyxFQUFFLFNBQVMsSUFBSSxTQUFTLE9BQU8sSUFBSSxTQUFTLEtBQUs7QUFBQSxFQUMxRDtBQUNBLE1BQUk7QUFDRixXQUFPLEVBQUUsU0FBUyxPQUFPLEdBQUcsR0FBRyxPQUFPLEtBQUs7QUFBQSxFQUM3QyxRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsdUJBQXVCLE9BQU8sS0FBSztBQUFBLEVBQ3ZEO0FBQ0Y7QUFPQSxTQUFTLE9BQU8sS0FBdUQ7QUFDckUsUUFBTSxNQUErQixDQUFDO0FBQ3RDLGFBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQ3hDLFFBQUksRUFBRSxZQUFZLEVBQUUsU0FBUyxPQUFPLEtBQUssRUFBRSxZQUFZLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtBQUMzRixVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1gsV0FBVyxPQUFPLE1BQU0sWUFBWSwrQkFBK0IsS0FBSyxDQUFDLEdBQUc7QUFDMUUsVUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLDZCQUE2Qix1QkFBdUI7QUFBQSxJQUN6RSxXQUFXLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxNQUFNO0FBQ25ELFVBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsSUFDOUIsT0FBTztBQUNMLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7OztBQ3ZFQSxJQUFNLFdBQVc7QUFDakIsSUFBTSxXQUFXO0FBK0JWLElBQU0sY0FBTixjQUEwQixNQUFNO0FBQUEsRUFDckM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBO0FBQUEsRUFFQSxZQUFZLE1BT1Q7QUFDRCxVQUFNLEtBQUssT0FBTztBQUNsQixTQUFLLE9BQU87QUFDWixTQUFLLFNBQVMsS0FBSztBQUNuQixTQUFLLE9BQU8sS0FBSztBQUNqQixTQUFLLFlBQVksS0FBSztBQUN0QixTQUFLLFdBQVcsS0FBSztBQUNyQixTQUFLLG1CQUFtQixLQUFLLG9CQUFvQjtBQUFBLEVBQ25EO0FBQ0Y7QUFFTyxJQUFNLGVBQU4sTUFBbUI7QUFBQSxFQUNQO0FBQUEsRUFFakIsWUFBWSxVQUFvQjtBQUM5QixTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBO0FBQUEsRUFHQSxNQUFNLFNBQTBCO0FBQzlCLFVBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDL0MsV0FBUSxJQUEyQixTQUFTO0FBQUEsRUFDOUM7QUFBQTtBQUFBLEVBR0EsTUFBTSxhQUFhLFFBQWtDO0FBQ25ELFFBQUk7QUFDRixZQUFNLEtBQUs7QUFBQSxRQUNUO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxtQkFBbUIsTUFBTSxDQUFDO0FBQUEsTUFDNUY7QUFDQSxhQUFPO0FBQUEsSUFDVCxTQUFTLEtBQUs7QUFDWixVQUFJLGVBQWUsZUFBZSxJQUFJLGFBQWEsWUFBYSxRQUFPO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFHQSxNQUFNLG1CQUEwRjtBQUM5RixVQUFNLEtBQUssTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQzlDLFVBQU0sT0FBTyxNQUFNLEtBQUssVUFBVSxPQUFPLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxFQUFFO0FBQzlGLFVBQU0sSUFBSTtBQUNWLFdBQU87QUFBQSxNQUNMLE9BQVEsR0FBeUI7QUFBQSxNQUNqQyxXQUFXLEVBQUU7QUFBQSxNQUNiLGdCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxvQkFBbUM7QUFDdkMsVUFBTSxPQUFPLE1BQU0sS0FBSyxjQUFjO0FBQ3RDLFVBQU0sS0FBSztBQUFBLE1BQ1Q7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxtQkFBbUIsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDdEc7QUFBQSxRQUNFLEtBQUssS0FBSztBQUFBLFFBQ1YsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLGFBQWEsWUFBNEM7QUFDN0QsVUFBTSxNQUFNLEdBQUcsUUFBUSxJQUFJLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFNBQVMsTUFBTSxJQUFJLFVBQVU7QUFDMUcsVUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDM0IsUUFBUTtBQUFBLE1BQ1IsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQUEsSUFDMUQsQ0FBQztBQUNELFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLFVBQVUsS0FBSyxXQUFXLFVBQVUsRUFBRTtBQUNwRSxXQUFPLElBQUksS0FBSztBQUFBLEVBQ2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sV0FBVyxNQUFzQztBQUNyRCxRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLFFBQ3JCO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQyxRQUFRLG1CQUFtQixLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDbEk7QUFDQSxZQUFNLElBQUk7QUFDVixhQUFPLEVBQUUsT0FBTztBQUFBLElBQ2xCLFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxRQUFRLE1BQThDO0FBQzFELFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sTUFBTSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQztBQUM1RixRQUFJLE1BQXFCLEtBQUssZUFBZTtBQUM3QyxVQUFNLGNBQWM7QUFFcEIsYUFBUyxVQUFVLEdBQUcsV0FBVyxhQUFhLFdBQVc7QUFDdkQsWUFBTSxPQUFnQztBQUFBLFFBQ3BDLFNBQVMsS0FBSztBQUFBLFFBQ2QsU0FBUyxLQUFLO0FBQUEsUUFDZCxRQUFRLEtBQUssU0FBUztBQUFBLE1BQ3hCO0FBQ0EsVUFBSSxJQUFLLE1BQUssTUFBTTtBQUNwQixVQUFJO0FBQ0YsY0FBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sS0FBSyxJQUFJO0FBQ2pELGNBQU0sTUFBTTtBQUNaLGVBQU8sRUFBRSxNQUFNLElBQUksUUFBUSxNQUFNLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLFFBQVEsU0FBUztBQUFBLE1BQ25GLFNBQVMsS0FBSztBQUNaLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFJLElBQUksV0FBVyxPQUFPLENBQUMsS0FBSztBQUU5QixnQkFBTSxNQUFNLEtBQUssV0FBVyxJQUFJO0FBQ2hDLGNBQUksQ0FBQyxJQUFLLE9BQU07QUFDaEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxDQUFDLElBQUksYUFBYSxZQUFZLFlBQWEsT0FBTTtBQUNyRCxjQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sSUFBSSxNQUFNLG1DQUFtQyxJQUFJLEVBQUU7QUFBQSxFQUMzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxNQUFNLFlBQVksTUFBc0Q7QUFDdEUsUUFBSSxLQUFLLE1BQU0sV0FBVyxFQUFHLE9BQU0sSUFBSSxNQUFNLGlDQUFpQztBQUM5RSxVQUFNLGNBQWM7QUFDcEIsUUFBSSxVQUFtQjtBQUV2QixhQUFTLFVBQVUsR0FBRyxXQUFXLGFBQWEsV0FBVztBQUN2RCxVQUFJO0FBQ0YsY0FBTSxRQUFRLE1BQU0sUUFBUTtBQUFBLFVBQzFCLEtBQUssTUFBTSxJQUFJLE9BQU8sU0FBUztBQUM3QixrQkFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLGNBQ3JCO0FBQUEsY0FDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxjQUNuRDtBQUFBLGdCQUNFLFNBQVMsS0FBSztBQUFBLGdCQUNkLFVBQVU7QUFBQSxjQUNaO0FBQUEsWUFDRjtBQUNBLG1CQUFPO0FBQUEsY0FDTCxNQUFNLEtBQUs7QUFBQSxjQUNYLEtBQU0sSUFBd0I7QUFBQSxZQUNoQztBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFFQSxjQUFNLE9BQU8sTUFBTSxLQUFLLGNBQWM7QUFDdEMsY0FBTSxPQUFPLE1BQU0sS0FBSztBQUFBLFVBQ3RCO0FBQUEsVUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxVQUNuRDtBQUFBLFlBQ0UsV0FBVyxLQUFLO0FBQUEsWUFDaEIsTUFBTSxNQUFNLElBQUksQ0FBQyxVQUFVO0FBQUEsY0FDekIsTUFBTSxLQUFLO0FBQUEsY0FDWCxNQUFNO0FBQUEsY0FDTixNQUFNO0FBQUEsY0FDTixLQUFLLEtBQUs7QUFBQSxZQUNaLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUNBLGNBQU0sVUFBVyxLQUF5QjtBQUMxQyxjQUFNLFNBQVMsTUFBTSxLQUFLO0FBQUEsVUFDeEI7QUFBQSxVQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLFVBQ25EO0FBQUEsWUFDRSxTQUFTLEtBQUs7QUFBQSxZQUNkLE1BQU07QUFBQSxZQUNOLFNBQVMsQ0FBQyxLQUFLLEdBQUc7QUFBQSxVQUNwQjtBQUFBLFFBQ0Y7QUFDQSxjQUFNLFlBQVk7QUFDbEIsWUFBSTtBQUNGLGdCQUFNLEtBQUs7QUFBQSxZQUNUO0FBQUEsWUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksbUJBQW1CLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLFlBQ3RHO0FBQUEsY0FDRSxLQUFLLFVBQVU7QUFBQSxjQUNmLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0YsU0FBUyxLQUFLO0FBQ1osY0FBSSxXQUFXLEdBQUcsS0FBSyxVQUFVLGFBQWE7QUFDNUMsc0JBQVU7QUFDVixrQkFBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFDbkM7QUFBQSxVQUNGO0FBQ0EsZ0JBQU07QUFBQSxRQUNSO0FBQ0EsZUFBTztBQUFBLFVBQ0wsV0FBVyxVQUFVO0FBQUEsVUFDckIsS0FBSyxVQUFVO0FBQUEsVUFDZixPQUFPLEtBQUssTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUk7QUFBQSxRQUMzQztBQUFBLE1BQ0YsU0FBUyxLQUFLO0FBQ1osa0JBQVU7QUFDVixZQUFJLEVBQUUsZUFBZSxhQUFjLE9BQU07QUFDekMsWUFBSyxDQUFDLElBQUksYUFBYSxDQUFDLFdBQVcsR0FBRyxLQUFNLFlBQVksWUFBYSxPQUFNO0FBQzNFLGNBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxtQkFBbUIsUUFBUSxVQUFVLElBQUksTUFBTSxpQ0FBaUM7QUFBQSxFQUN4RjtBQUFBLEVBRUEsTUFBYyxnQkFBMkQ7QUFDdkUsVUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLE1BQ3JCO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksa0JBQWtCLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLElBQ3ZHO0FBQ0EsVUFBTSxVQUFXLElBQW9DLE9BQU87QUFDNUQsVUFBTSxTQUFTLE1BQU0sS0FBSztBQUFBLE1BQ3hCO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksZ0JBQWdCLE9BQU87QUFBQSxJQUM1RTtBQUNBLFdBQU87QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLFNBQVUsT0FBcUMsS0FBSztBQUFBLElBQ3REO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBYyxVQUFVLFFBQWdCLE1BQWMsTUFBa0M7QUFDdEYsVUFBTSxNQUFNLEtBQUssV0FBVyxNQUFNLElBQUksT0FBTyxHQUFHLFFBQVEsR0FBRyxJQUFJO0FBQy9ELFVBQU0sT0FBb0I7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsU0FBUztBQUFBLFFBQ1AsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHO0FBQUEsUUFDMUMsUUFBUTtBQUFBLFFBQ1Isd0JBQXdCO0FBQUEsUUFDeEIsR0FBSSxPQUFPLEVBQUUsZ0JBQWdCLG1CQUFtQixJQUFJLENBQUM7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsR0FBSSxPQUFPLEVBQUUsTUFBTSxLQUFLLFVBQVUsSUFBSSxFQUFFLElBQUksQ0FBQztBQUFBLElBQy9DO0FBQ0EsUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLLElBQUk7QUFBQSxJQUM3QixTQUFTLFFBQVE7QUFDZixZQUFNLElBQUksWUFBWTtBQUFBLFFBQ3BCLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxRQUNOLFNBQVMsWUFBWSxjQUFjLE1BQU0sRUFBRSxPQUFPO0FBQUEsUUFDbEQsV0FBVztBQUFBLFFBQ1gsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFDQSxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxTQUFrQjtBQUN0QixVQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsUUFBSSxNQUFNO0FBQ1IsVUFBSTtBQUNGLGlCQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsTUFDMUIsUUFBUTtBQUNOLGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLG9CQUFvQixLQUFLLFFBQVEsR0FBRyxNQUFNLElBQUksSUFBSSxFQUFFO0FBQ2xGLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLFVBQVUsS0FBZSxPQUFxQztBQUMxRSxRQUFJLFNBQWtCO0FBQ3RCLFFBQUk7QUFDRixZQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsVUFBSSxLQUFNLFVBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxJQUNwQyxRQUFRO0FBQUEsSUFFUjtBQUNBLFdBQU8sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEtBQUs7QUFBQSxFQUNwRDtBQUFBLEVBRVEsb0JBQW9CLEtBQWUsTUFBZSxPQUE0QjtBQUNwRixVQUFNLE1BQ0osT0FBTyxTQUFTLFlBQVksUUFBUSxhQUFhLE9BQzdDLE9BQVEsS0FBOEIsT0FBTyxJQUM3QyxJQUFJO0FBQ1YsUUFBSSxXQUFvQztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUU1QyxZQUFNLE9BQU8sSUFBSSxRQUFRLElBQUksdUJBQXVCO0FBQ3BELFVBQUksU0FBUyxPQUFPLGNBQWMsS0FBSyxHQUFHLEdBQUc7QUFDM0MsbUJBQVc7QUFDWCxvQkFBWTtBQUFBLE1BQ2QsT0FBTztBQUNMLG1CQUFXO0FBQUEsTUFDYjtBQUFBLElBQ0YsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUNuRCxpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFVBQVUsS0FBSztBQUM1QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZCxXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkO0FBQ0EsV0FBTyxJQUFJLFlBQVk7QUFBQSxNQUNyQixRQUFRLElBQUk7QUFBQSxNQUNaO0FBQUEsTUFDQSxTQUFTLEdBQUcsS0FBSyxXQUFNLElBQUksTUFBTSxLQUFLLEdBQUc7QUFBQSxNQUN6QztBQUFBLE1BQ0E7QUFBQSxNQUNBLGtCQUFrQixhQUFhLGVBQWUsb0JBQW9CLElBQUksT0FBTyxJQUFJO0FBQUEsSUFDbkYsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQVFBLFNBQVMsb0JBQW9CLFNBQWlDO0FBQzVELFFBQU0sUUFBUSxRQUFRLElBQUksbUJBQW1CO0FBQzdDLE1BQUksT0FBTztBQUNULFVBQU0sSUFBSSxPQUFPLFNBQVMsT0FBTyxFQUFFO0FBQ25DLFFBQUksT0FBTyxTQUFTLENBQUMsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUFBLEVBQzFDO0FBQ0EsUUFBTSxhQUFhLFFBQVEsSUFBSSxhQUFhO0FBQzVDLE1BQUksWUFBWTtBQUNkLFVBQU0sUUFBUSxPQUFPLFNBQVMsWUFBWSxFQUFFO0FBQzVDLFFBQUksT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLEdBQUc7QUFDeEMsYUFBTyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSSxJQUFJO0FBQUEsSUFDekM7QUFDQSxVQUFNLFNBQVMsS0FBSyxNQUFNLFVBQVU7QUFDcEMsUUFBSSxPQUFPLFNBQVMsTUFBTSxFQUFHLFFBQU8sS0FBSyxNQUFNLFNBQVMsR0FBSTtBQUFBLEVBQzlEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLE1BQXNCO0FBRXhDLFNBQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJLGtCQUFrQixFQUFFLEtBQUssR0FBRztBQUN6RDtBQUVBLFNBQVMsVUFBVSxTQUFpQixLQUEwQjtBQUU1RCxRQUFNLE9BQU8sSUFBSSxhQUFhLGVBQWUsTUFBTztBQUNwRCxRQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQUc7QUFDN0MsU0FBTyxLQUFLLElBQUksS0FBUSxPQUFPLE1BQU0sVUFBVSxLQUFLLE1BQU07QUFDNUQ7QUFFQSxTQUFTLFdBQVcsS0FBa0M7QUFDcEQsU0FBTyxlQUFlLGVBQWUsSUFBSSxhQUFhO0FBQ3hEO0FBRUEsU0FBUyxNQUFNLElBQTJCO0FBQ3hDLFNBQU8sSUFBSSxRQUFRLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQzdDO0FBRU8sU0FBU0EsVUFBUyxPQUF1QjtBQUU5QyxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxLQUFLO0FBQzNDLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLFFBQU8sT0FBTyxhQUFhLENBQUM7QUFDbEQsU0FBTyxLQUFLLEdBQUc7QUFDakI7OztBQzNYQSxJQUFNLGNBQWM7QUFTcEIsSUFBTSx1QkFBNEMsb0JBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUVoRSxTQUFTLFVBQVUsU0FBa0IsS0FBd0M7QUFDbEYsUUFBTSxZQUFZLGNBQWMsT0FBTztBQUN2QyxRQUFNLFNBQTJCLENBQUM7QUFDbEMsUUFBTSxvQkFBd0MsQ0FBQztBQUMvQyxRQUFNLFdBQXFCLENBQUM7QUFDNUIsUUFBTSxRQUFRLG9CQUFJLElBQVk7QUFDOUIsUUFBTSxhQUFhLG9CQUFJLElBQTJCO0FBQ2xELFFBQU0sa0JBQWtCLHFCQUFxQixJQUFJLElBQUksUUFBUTtBQUM3RCxhQUFXLE9BQU8sV0FBVztBQUMzQixRQUFJO0FBQ0YsWUFBTSxjQUFjLHFCQUFxQixLQUFLLEdBQUc7QUFDakQsVUFBSSxhQUFhO0FBQ2YsMEJBQWtCLEtBQUssV0FBVztBQUNsQyxpQkFBUyxLQUFLLFlBQVksUUFBUTtBQUNsQyxjQUFNLElBQUksWUFBWSxRQUFRO0FBQzlCO0FBQUEsTUFDRjtBQUNBLFlBQU0sSUFBSSxXQUFXLEtBQUssR0FBRztBQUM3QixVQUFJLENBQUMsR0FBRztBQUNOLFlBQUksaUJBQWlCO0FBSW5CLGdCQUFNLFVBQVUsWUFBWSxHQUFHO0FBQy9CLGNBQUksUUFBUyxZQUFXLElBQUksUUFBUSxVQUFVLFFBQVEsV0FBVztBQUFBLFFBQ25FO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsZUFBUyxLQUFLLEVBQUUsUUFBUTtBQUN4QixZQUFNLElBQUksRUFBRSxRQUFRO0FBQ3BCLFVBQUksSUFBSSxlQUFlLFNBQVMsS0FBSyxJQUFJLGVBQWUsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEdBQUc7QUFDM0YsZUFBTyxLQUFLLENBQUM7QUFBQSxNQUNmO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFHQSxRQUFNLGNBQXVFLENBQUM7QUFDOUUsYUFBVyxDQUFDLElBQUksSUFBSSxLQUFLLFlBQVk7QUFDbkMsUUFBSSxNQUFNLElBQUksRUFBRSxFQUFHO0FBQ25CLGdCQUFZLEtBQUssRUFBRSxVQUFVLElBQUksYUFBYSxLQUFLLENBQUM7QUFBQSxFQUN0RDtBQUNBLFNBQU8sRUFBRSxRQUFRLGNBQWMsVUFBVSxvQkFBb0IsbUJBQW1CLFlBQVk7QUFDOUY7QUFFQSxTQUFTLHFCQUFxQixNQUFlLEtBQWdEO0FBQzNGLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFFOUMsUUFBTSxVQUNKLFVBQVUsRUFBRSxPQUFPLEtBQ25CLG9CQUFvQixJQUFJLE1BQ3ZCLElBQUksWUFBWSxvQkFBb0IsSUFBSSxTQUFTLElBQUk7QUFDeEQsTUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEtBQUssT0FBTyxFQUFHLFFBQU87QUFFbkQsUUFBTSxrQkFBa0Isa0JBQWtCLElBQUk7QUFDOUMsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsZ0JBQ0Usd0JBQXdCLE1BQU0sT0FBTyxNQUNwQyxJQUFJLFlBQVksbUJBQW1CLElBQUksV0FBVyxPQUFPLElBQUk7QUFBQSxJQUNoRSx5QkFBeUIsSUFBSTtBQUFBLElBQzdCLG9CQUFvQiwwQkFBMEIsZUFBZTtBQUFBLElBQzdELGtCQUFrQjtBQUFBLElBQ2xCLHdCQUF3QixJQUFJLGFBQWE7QUFBQSxFQUMzQztBQUNGO0FBRUEsU0FBUyxvQkFBb0IsTUFBOEI7QUFDekQsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sS0FBSyxvQkFBb0IsR0FBRztBQUNsQyxVQUFJLEdBQUksUUFBTztBQUNmO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLG9CQUFvQixRQUErQjtBQUMxRCxNQUFJO0FBQ0YsVUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLGdCQUFnQjtBQUM1QyxRQUFJLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxjQUFlLFFBQU87QUFDdkUsVUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLG9EQUFvRDtBQUNyRixXQUFPLFFBQVEsQ0FBQyxLQUFLO0FBQUEsRUFDdkIsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixNQUE4QjtBQUN2RCxRQUFNLFVBQW9CLENBQUM7QUFDM0IsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sVUFBVSxJQUFJLEtBQUs7QUFDekIsVUFDRSxRQUFRLFVBQVUsS0FDbEIsQ0FBQyxRQUFRLFdBQVcsU0FBUyxLQUM3QixDQUFDLFFBQVEsV0FBVyxVQUFVLEdBQzlCO0FBQ0EsZ0JBQVEsS0FBSyxPQUFPO0FBQUEsTUFDdEI7QUFDQTtBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVTtBQUM3QyxRQUFJLEtBQUssSUFBSSxHQUFhLEVBQUc7QUFDN0IsU0FBSyxJQUFJLEdBQWE7QUFDdEIsUUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQ3RCLGlCQUFXLEtBQUssSUFBSyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ25DLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxHQUE4QixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDN0U7QUFBQSxFQUNGO0FBQ0EsUUFBTSxZQUFZLFFBQVE7QUFBQSxJQUFLLENBQUMsTUFDOUIsOEVBQThFLEtBQUssQ0FBQztBQUFBLEVBQ3RGO0FBQ0EsU0FBTyxhQUFhLFFBQVEsQ0FBQyxLQUFLO0FBQ3BDO0FBRUEsU0FBUywwQkFBMEIsTUFBb0M7QUFDckUsTUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixNQUFJLHdCQUF3QixLQUFLLElBQUksRUFBRyxRQUFPO0FBQy9DLE1BQUksZ0JBQWdCLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDdkMsTUFBSSx1QkFBdUIsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUM5QyxNQUFJLGlCQUFpQixLQUFLLElBQUksRUFBRyxRQUFPO0FBQ3hDLE1BQUksaUNBQWlDLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDeEQsU0FBTztBQUNUO0FBRUEsU0FBUyxZQUFZLE1BQXdFO0FBQzNGLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBR1YsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFHOUMsUUFBTSxLQUFLLEVBQUU7QUFDYixNQUFJLE9BQU8sV0FBVyxPQUFPLGdDQUFnQyxDQUFDLElBQUksRUFBRSxNQUFNLEdBQUc7QUFDM0UsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLFNBQ0gsT0FBTyxFQUFFLFlBQVksWUFBWSxFQUFFLFdBQ25DLE9BQU8sSUFBSSxFQUFFLFlBQVksR0FBRyxXQUFXLFlBQ3JDLElBQUksSUFBSSxFQUFFLFlBQVksR0FBRyxNQUFNLEdBQUc7QUFDdkMsTUFBSSxPQUFPLFdBQVcsWUFBWSxDQUFDLFlBQVksS0FBSyxNQUFNLEVBQUcsUUFBTztBQUNwRSxRQUFNLGFBQWEsZUFBZSxNQUFNLE1BQU07QUFDOUMsTUFBSSxDQUFDLFdBQVksUUFBTztBQUN4QixTQUFPLEVBQUUsVUFBVSxRQUFRLGFBQWEsV0FBVztBQUNyRDtBQUVBLFNBQVMsZUFBZSxNQUFlLFNBQWdDO0FBQ3JFLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsUUFBTSxhQUFhLElBQUksSUFBSSxJQUFJLEVBQUUsSUFBSSxHQUFHLFlBQVksR0FBRyxNQUFNO0FBQzdELFNBQ0UsVUFBVSxJQUFJLFlBQVksSUFBSSxHQUFHLFdBQVcsS0FDNUMsVUFBVSxJQUFJLFlBQVksTUFBTSxHQUFHLFdBQVcsS0FDOUMsVUFBVSxJQUFJLEVBQUUsTUFBTSxHQUFHLFdBQVcsS0FDcEMsd0JBQXdCLE1BQU0sT0FBTztBQUV6QztBQUVBLFNBQVMsd0JBQXdCLE1BQWUsU0FBZ0M7QUFDOUUsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sU0FBUyxtQkFBbUIsS0FBSyxPQUFPO0FBQzlDLFVBQUksT0FBUSxRQUFPO0FBQ25CO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLG1CQUFtQixRQUFnQixTQUFnQztBQUMxRSxNQUFJO0FBQ0YsVUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLGdCQUFnQjtBQUM1QyxRQUFJLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxjQUFlLFFBQU87QUFDdkUsVUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLHNEQUFzRDtBQUN2RixRQUFJLENBQUMsU0FBUyxNQUFNLENBQUMsTUFBTSxRQUFTLFFBQU87QUFDM0MsV0FBTyxNQUFNLENBQUMsS0FBSztBQUFBLEVBQ3JCLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxjQUFjQyxNQUF5QjtBQUs5QyxRQUFNLE1BQWlCLENBQUM7QUFDeEIsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQ0EsSUFBRztBQUM3QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sT0FBTyxNQUFNLElBQUk7QUFDdkIsUUFBSSxTQUFTLFFBQVEsU0FBUyxPQUFXO0FBQ3pDLFFBQUksT0FBTyxTQUFTLFNBQVU7QUFDOUIsUUFBSSxLQUFLLElBQUksSUFBYyxFQUFHO0FBQzlCLFNBQUssSUFBSSxJQUFjO0FBRXZCLFFBQUksZUFBZSxJQUFJLEdBQUc7QUFDeEIsVUFBSSxLQUFLLFlBQVksSUFBSSxDQUFDO0FBQUEsSUFDNUI7QUFDQSxRQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDdkIsaUJBQVcsS0FBSyxLQUFNLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDcEMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLElBQStCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM5RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGVBQWUsTUFBZ0Q7QUFDdEUsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLFdBQVcsRUFBRTtBQUNuQixNQUNFLGFBQWEsV0FDYixhQUFhLGdDQUNiLGFBQWEsa0JBQ2I7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQU8sT0FBTyxFQUFFLFlBQVksWUFBWSxPQUFPLEVBQUUsV0FBVyxZQUFZLEVBQUUsV0FBVztBQUN2RjtBQUVBLFNBQVMsWUFBWSxNQUF3RDtBQUMzRSxNQUFJLEtBQUssZUFBZSxnQ0FBZ0MsT0FBTyxLQUFLLFVBQVUsVUFBVTtBQUN0RixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLEtBQWMsS0FBOEM7QUFDOUUsTUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLEtBQU0sUUFBTztBQUNwRCxRQUFNLElBQUk7QUFFVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUU5QyxRQUFNLFNBQVMsVUFBVSxFQUFFLE9BQU87QUFLbEMsUUFBTSxTQUFTLElBQUksRUFBRSxNQUFNLEtBQUssQ0FBQztBQUNqQyxNQUFJLENBQUMsT0FBUSxRQUFPO0FBRXBCLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxJQUFJLE1BQU0sWUFBWSxHQUFHLE1BQU07QUFHdEQsUUFBTSxjQUFjLElBQUksWUFBWSxJQUFJO0FBQ3hDLFFBQU0sYUFBYSxJQUFJLFlBQVksTUFBTTtBQUN6QyxRQUFNLGdCQUFnQixJQUFJLFlBQVksTUFBTTtBQUM1QyxRQUFNLFNBQ0osVUFBVSxhQUFhLFdBQVcsS0FDbEMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxPQUFPLFdBQVc7QUFDOUIsUUFBTSxZQUNKLFVBQVUsWUFBWSxPQUFPLEtBQzdCLFVBQVUsWUFBWSxNQUFNLEtBQzVCLFVBQVUsT0FBTyxXQUFXO0FBQzlCLE1BQUksQ0FBQyxVQUFVLENBQUMsVUFBVyxRQUFPO0FBTWxDLFFBQU0sU0FBUyxvQkFBb0IsWUFBWSxhQUFhLFlBQVksYUFBYTtBQUVyRixRQUFNLFlBQVksSUFBSSxJQUFJLElBQUksRUFBRSxVQUFVLEdBQUcsa0JBQWtCLEdBQUcsTUFBTTtBQUN4RSxRQUFNLGVBQWUsVUFBVSxXQUFXLElBQUk7QUFDOUMsUUFBTSxpQkFBaUIsVUFBVSxPQUFPLFNBQVMsS0FBSztBQUN0RCxRQUFNLE9BQU8sZ0JBQWdCO0FBQzdCLFFBQU0sY0FBYyxpQkFBaUIsV0FBVyxRQUFRLGNBQWM7QUFDdEUsUUFBTSxnQkFBZ0IscUJBQXFCLEdBQUcsUUFBUSxJQUFJLFVBQVU7QUFFcEUsUUFBTSxXQUFXLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQztBQUMxQyxRQUFNLG1CQUFtQixJQUFJLFdBQVcsVUFBVTtBQUNsRCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxPQUFPLFlBQVksb0JBQW9CLFFBQVE7QUFDckQsUUFBTSxRQUFRLGFBQWEsTUFBTTtBQUVqQyxRQUFNLFlBQVksa0JBQWtCLEdBQUcsTUFBTTtBQUk3QyxRQUFNLFdBQ0osaUJBQWlCLFVBQVUsT0FBTyxVQUFVLENBQUMsS0FBSyxpQkFBaUIsVUFBVSxFQUFFLFVBQVUsQ0FBQztBQUM1RixNQUFJLENBQUMsU0FBVSxRQUFPO0FBRXRCLFFBQU0sUUFBUSxJQUFJLEVBQUUsS0FBSztBQUN6QixRQUFNLFlBQVksVUFBVSxPQUFPLEtBQUssS0FBSyxVQUFVLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFFOUUsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUMxQixRQUFNLFFBQVEsSUFBSSxPQUFPLEtBQUs7QUFFOUIsUUFBTSxRQUF3QjtBQUFBLElBQzVCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLFdBQVc7QUFBQSxJQUNYLG1CQUFtQixJQUFJO0FBQUEsSUFDdkIsY0FBYyxJQUFJO0FBQUEsSUFDbEIsc0JBQXNCO0FBQUEsSUFDdEIseUJBQXlCO0FBQUEsSUFDekIsb0JBQW9CO0FBQUEsSUFDcEIsa0JBQWtCO0FBQUEsSUFDbEIsd0JBQXdCO0FBQUEsSUFDeEIsV0FBVyxHQUFHLGdCQUFnQixJQUFJLE1BQU0sV0FBVyxNQUFNO0FBQUEsSUFDekQsWUFBWTtBQUFBLElBQ1osaUJBQWlCLFVBQVUsT0FBTyxtQkFBbUI7QUFBQSxJQUNyRCxtQkFBbUIsVUFBVSxPQUFPLHlCQUF5QjtBQUFBLElBQzdELGtCQUFrQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDMUQscUJBQXFCLFVBQVUsT0FBTyx1QkFBdUI7QUFBQSxJQUM3RCxpQkFBaUIsVUFBVSxPQUFPLG9CQUFvQjtBQUFBLElBQ3RELG9CQUFvQjtBQUFBLE1BQ2xCLElBQUksSUFBSSxPQUFPLHVCQUF1QixHQUFHLE1BQU0sR0FBRyxXQUMvQyxPQUFtQztBQUFBLElBQ3hDO0FBQUEsSUFDQTtBQUFBLElBQ0EsZUFBZSxpQkFBaUIsTUFBTSxJQUFJO0FBQUEsSUFDMUMsTUFBTSxVQUFVLE9BQU8sSUFBSTtBQUFBLElBQzNCLG9CQUFvQixXQUFXLE9BQU8sa0JBQWtCO0FBQUEsSUFDeEQsUUFBUSxVQUFVLE9BQU8sTUFBTSxLQUFLLFVBQVUsRUFBRSxNQUFNO0FBQUEsSUFDdEQsaUJBQWlCLFVBQVUsT0FBTyxTQUFTO0FBQUEsSUFDM0M7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDM0MsZUFBZSxVQUFVLE9BQU8sYUFBYTtBQUFBLElBQzdDLGFBQWEsVUFBVSxPQUFPLFdBQVc7QUFBQSxJQUN6QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsWUFBWTtBQUFBLElBQ1osZ0JBQWdCLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDL0Msb0JBQW9CO0FBQUEsTUFDbEI7QUFBQSxRQUNFLGFBQWEsSUFBSTtBQUFBLFFBQ2pCLE9BQU8sVUFBVSxPQUFPLGNBQWM7QUFBQSxRQUN0QyxVQUFVLFVBQVUsT0FBTyxhQUFhO0FBQUEsUUFDeEMsU0FBUyxVQUFVLE9BQU8sV0FBVztBQUFBLFFBQ3JDLFFBQVEsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNwQyxPQUFPO0FBQUEsUUFDUCxXQUFXLFVBQVUsT0FBTyxjQUFjO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLElBQ0EsZ0JBQWdCO0FBQUEsSUFDaEIsY0FBYztBQUFBLElBQ2QsYUFBYTtBQUFBLElBQ2Isc0JBQXNCO0FBQUEsSUFDdEIsZ0JBQWdCO0FBQUEsSUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxJQUNwQixnQkFBZ0I7QUFBQSxFQUNsQjtBQUVBLFNBQU87QUFDVDtBQUVBLFNBQVMsa0JBQWtCLEdBQTRCLFFBQTRDO0FBQ2pHLE1BQUksT0FBTywyQkFBMkIsT0FBTyx3QkFBeUIsUUFBTztBQUM3RSxNQUFJLE9BQU8sMEJBQTJCLFFBQU87QUFDN0MsTUFBSSxPQUFPLG9CQUFvQixRQUFRLE9BQU8scUJBQXNCLFFBQU87QUFDM0UsTUFBSSxFQUFFLGVBQWUsOEJBQThCO0FBQUEsRUFFbkQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxVQUFVLElBQUksT0FBUSxFQUF3QixJQUFJLElBQUk7QUFBQSxFQUN0RixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixJQUMzQyxPQUFRLEVBQStCLFdBQVcsSUFDbEQ7QUFBQSxFQUNOLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxZQUFZLFVBQWdEO0FBQ25FLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxRQUFNLE1BQW1CLENBQUM7QUFDMUIsYUFBVyxLQUFLLEtBQUs7QUFDbkIsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU07QUFDekMsVUFBTSxJQUFJO0FBQ1YsVUFBTSxRQUFRLFVBQVUsRUFBRSxHQUFHO0FBQzdCLFVBQU0sV0FBVyxVQUFVLEVBQUUsWUFBWTtBQUN6QyxVQUFNLFVBQVUsVUFBVSxFQUFFLFdBQVc7QUFDdkMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFVO0FBQ3pCLFFBQUksS0FBSyxFQUFFLE9BQU8sVUFBVSxTQUFTLFdBQVcsU0FBUyxDQUFDO0FBQUEsRUFDNUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGFBQWEsUUFBOEM7QUFDbEUsUUFBTSxXQUFXLElBQUksT0FBTyxpQkFBaUI7QUFDN0MsUUFBTSxVQUFVLFdBQVcsUUFBUSxTQUFTLEtBQUssSUFBSSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxRQUFRLElBQUksT0FBTyxRQUFRLEdBQUcsS0FBSztBQUNuRCxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFNBQVMsQ0FBQyxHQUFHLFNBQVMsR0FBRyxPQUFPLEVBQUUsT0FBTyxDQUFDLE1BQU07QUFDcEQsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU0sUUFBTztBQUNoRCxVQUFNLEtBQ0osVUFBVyxFQUE4QixTQUFTLEtBQ2xELFVBQVcsRUFBOEIsTUFBTTtBQUNqRCxRQUFJLENBQUMsR0FBSSxRQUFPO0FBQ2hCLFFBQUksS0FBSyxJQUFJLEVBQUUsRUFBRyxRQUFPO0FBQ3pCLFNBQUssSUFBSSxFQUFFO0FBQ1gsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNELFNBQU8sT0FBTyxJQUFJLENBQUMsUUFBUSxXQUFXLEdBQThCLENBQUM7QUFDdkU7QUFFQSxTQUFTLFdBQVcsR0FBdUM7QUFDekQsUUFBTSxPQUFPLFVBQVUsRUFBRSxJQUFJO0FBQzdCLFFBQU0sV0FBVyxnQkFBZ0IsR0FBRyxJQUFJO0FBQ3hDLFFBQU1DLFFBQU8sSUFBSSxFQUFFLGFBQWE7QUFDaEMsUUFBTSxZQUFZLElBQUksRUFBRSxVQUFVO0FBQ2xDLFFBQU0sYUFBYSxVQUFVLFdBQVcsZUFBZTtBQUN2RCxRQUFNLFVBQVUsVUFBVSxFQUFFLFlBQVk7QUFDeEMsUUFBTSxVQUNKLFVBQVUsRUFBRSxTQUFTLEtBQ3JCLFVBQVUsRUFBRSxNQUFNLEtBQ2xCLEdBQUcsUUFBUSxPQUFPLElBQUksS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDM0QsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsWUFBYSxRQUFRO0FBQUEsSUFDckIsY0FBYyxZQUFZO0FBQUEsSUFDMUIsbUJBQW1CO0FBQUEsSUFDbkIsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsY0FBYyxlQUFlLE9BQU8sYUFBYSxNQUFPO0FBQUEsSUFDeEQsT0FBTyxVQUFVQSxPQUFNLEtBQUs7QUFBQSxJQUM1QixRQUFRLFVBQVVBLE9BQU0sTUFBTTtBQUFBLElBQzlCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLGtCQUFrQjtBQUFBLElBQ2xCLGlCQUFpQjtBQUFBLEVBQ25CO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixHQUE0QixNQUFvQztBQUN2RixNQUFJLFNBQVMsUUFBUyxRQUFPLFVBQVUsRUFBRSxlQUFlLEtBQUssVUFBVSxFQUFFLFNBQVM7QUFDbEYsUUFBTSxXQUFXLFFBQVEsSUFBSSxFQUFFLFVBQVUsR0FBRyxRQUFRO0FBQ3BELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxVQUFVLEVBQUUsZUFBZTtBQUU3RCxNQUFJLE9BQWdEO0FBQ3BELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sS0FBSyxVQUFVLEVBQUUsWUFBWTtBQUNuQyxVQUFNLE1BQU0sVUFBVSxFQUFFLEdBQUc7QUFDM0IsUUFBSSxDQUFDLElBQUs7QUFDVixRQUFJLE9BQU8sYUFBYTtBQUN0QixZQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sS0FBSztBQUNuQyxVQUFJLENBQUMsUUFBUSxLQUFLLEtBQUssUUFBUyxRQUFPLEVBQUUsS0FBSyxTQUFTLEdBQUc7QUFBQSxJQUM1RCxXQUFXLENBQUMsTUFBTTtBQUVoQixhQUFPLEVBQUUsS0FBSyxTQUFTLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLE1BQU0sT0FBTztBQUN0QjtBQUVBLFNBQVMsaUJBQWlCLE1BQWMsTUFBMkI7QUFDakUsTUFBSSxLQUFLLFdBQVcsRUFBRyxRQUFPO0FBQzlCLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLE9BQU0sSUFBSSxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRO0FBQzlELFNBQU87QUFDVDtBQUVBLFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELE1BQUksQ0FBQyxFQUFHLFFBQU87QUFFZixRQUFNLElBQUksSUFBSSxLQUFLLENBQUM7QUFDcEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPO0FBQ3RDLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLFNBQU8sT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLElBQUksSUFBSTtBQUNyRDtBQUNBLFNBQVMsV0FBVyxHQUE0QjtBQUM5QyxTQUFPLE9BQU8sTUFBTSxZQUFZLElBQUk7QUFDdEM7QUFDQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFDeEQsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxVQUFNLElBQUksT0FBTyxDQUFDO0FBQ2xCLFFBQUksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQUEsRUFDakM7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFVBQVUsR0FBb0I7QUFDckMsU0FBTyxVQUFVLENBQUMsS0FBSztBQUN6QjtBQUNBLFNBQVMsSUFBSSxHQUE0QztBQUN2RCxTQUFPLE9BQU8sTUFBTSxZQUFZLE1BQU0sUUFBUSxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQ3pELElBQ0Q7QUFDTjtBQUNBLFNBQVMsUUFBUSxHQUF1QjtBQUN0QyxTQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDO0FBQ2pDO0FBd0JBLFNBQVMsaUJBQ1AsV0FDQSxRQUNBLFVBQ1M7QUFDVCxNQUFJLFVBQVcsUUFBTztBQUN0QixNQUFJLENBQUMsU0FBVSxRQUFPO0FBQ3RCLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUTtBQUNwQyxRQUFNLE9BQU8sV0FBVyxTQUFTLE9BQU87QUFDeEMsTUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGVBQVcsS0FBSyxNQUFNO0FBQ3BCLFVBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFlBQU0sTUFBTyxFQUE4QjtBQUkzQyxVQUFJLE9BQU8sUUFBUSxZQUFZLHdCQUF3QixLQUFLLEdBQUcsR0FBRztBQUNoRSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBd0JPLFNBQVMsY0FDZCxRQUNBLFVBQ0EsY0FBbUMsb0JBQUksSUFBSSxHQUN6QjtBQUNsQixNQUFJLFNBQVMsU0FBUyxLQUFLLFlBQVksU0FBUyxFQUFHLFFBQU87QUFLMUQsUUFBTSxnQkFBZ0Isb0JBQUksSUFBWTtBQUN0QyxRQUFNLG1CQUFtQixvQkFBSSxJQUFZO0FBQ3pDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxFQUFHO0FBQ25ELHFCQUFpQixJQUFJLEVBQUUsUUFBUTtBQUMvQixRQUFJLEVBQUUsZ0JBQWlCLGVBQWMsSUFBSSxFQUFFLGVBQWU7QUFDMUQsUUFBSSxFQUFFLG1CQUFvQixlQUFjLElBQUksRUFBRSxrQkFBa0I7QUFDaEUsUUFBSSxFQUFFLGtCQUFtQixlQUFjLElBQUksRUFBRSxpQkFBaUI7QUFBQSxFQUNoRTtBQUNBLFNBQU8sT0FBTyxPQUFPLENBQUMsTUFBTTtBQUMxQixVQUFNLElBQUksRUFBRSxlQUFlLFlBQVk7QUFDdkMsUUFBSSxTQUFTLElBQUksQ0FBQyxFQUFHLFFBQU87QUFDNUIsUUFBSSxZQUFZLElBQUksQ0FBQyxFQUFHLFFBQU87QUFFL0IsUUFBSSxjQUFjLElBQUksRUFBRSxRQUFRLEVBQUcsUUFBTztBQUkxQyxRQUFJLEVBQUUsbUJBQW1CLGlCQUFpQixJQUFJLEVBQUUsZUFBZSxFQUFHLFFBQU87QUFDekUsUUFBSSxFQUFFLHFCQUFxQixpQkFBaUIsSUFBSSxFQUFFLGlCQUFpQixFQUFHLFFBQU87QUFFN0UsUUFBSSxFQUFFLG9CQUFvQixTQUFTLElBQUksRUFBRSxpQkFBaUIsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUNqRixlQUFXLEtBQUssRUFBRSxVQUFVO0FBQzFCLFVBQUksU0FBUyxJQUFJLEVBQUUsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUFBLElBQzVDO0FBQ0EsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNIO0FBU0EsU0FBUyxxQkFDUCxHQUNBLFFBQ0EsWUFDc0I7QUFDdEIsUUFBTSxRQUFRLElBQUksRUFBRSxlQUFlLEtBQUssSUFBSSxPQUFPLGVBQWU7QUFDbEUsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixRQUFNLFdBQVcsSUFBSSxNQUFNLFFBQVE7QUFDbkMsUUFBTSxPQUFPLElBQUksTUFBTSxJQUFJO0FBQzNCLFFBQU0sVUFBVSxVQUFVLFVBQVUsSUFBSTtBQUN4QyxRQUFNLFFBQVEsVUFBVSxNQUFNLEtBQUs7QUFDbkMsUUFBTSxhQUFhLFVBQVUsTUFBTSxVQUFVO0FBQzdDLFFBQU0saUJBQWlCLFVBQVUsTUFBTSxjQUFjO0FBQ3JELFFBQU0sU0FBUyxVQUFVLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPO0FBRWpFLE1BQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQVEsUUFBTztBQUMxQyxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVDtBQUFBLElBQ0EsYUFBYTtBQUFBLElBQ2I7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLElBQ2pCLGFBQWE7QUFBQSxFQUNmO0FBQ0Y7QUFPQSxTQUFTLG9CQUNQLFlBQ0EsYUFDQSxZQUNBLGVBQ2M7QUFDZCxRQUFNLGVBQWUsSUFBSSxZQUFZLFlBQVk7QUFDakQsU0FBTztBQUFBLElBQ0wsY0FDRSxVQUFVLGFBQWEsSUFBSSxLQUFLLFVBQVUsWUFBWSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUk7QUFBQSxJQUMzRixZQUNFLFVBQVUsZUFBZSxTQUFTLEtBQ2xDLFVBQVUsWUFBWSx1QkFBdUIsS0FDN0MsVUFBVSxZQUFZLHVCQUF1QjtBQUFBLElBQy9DLFVBQVUsV0FBVyxjQUFjLFFBQVEsS0FBSyxXQUFXLFlBQVksUUFBUTtBQUFBLElBQy9FLGtCQUFrQixXQUFXLFlBQVksZ0JBQWdCO0FBQUEsSUFDekQsZUFBZSxVQUFVLGNBQWMsYUFBYSxLQUFLLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDNUYsYUFBYSxVQUFVLFlBQVksV0FBVztBQUFBLElBQzlDLFVBQVUsVUFBVSxJQUFJLFlBQVksUUFBUSxHQUFHLFFBQVEsS0FBSyxVQUFVLFlBQVksUUFBUTtBQUFBLElBQzFGLEtBQUssVUFBVSxZQUFZLEdBQUc7QUFBQSxJQUM5QixpQkFBaUIsVUFBVSxZQUFZLGVBQWU7QUFBQSxJQUN0RCxlQUFlLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDbEQsZ0JBQWdCLFVBQVUsWUFBWSxjQUFjO0FBQUEsSUFDcEQsb0JBQ0UsaUJBQWlCLFVBQVUsYUFBYSxVQUFVLENBQUMsS0FDbkQsaUJBQWlCLFVBQVUsWUFBWSxVQUFVLENBQUM7QUFBQSxJQUNwRCxXQUFXLFdBQVcsWUFBWSxTQUFTO0FBQUEsRUFDN0M7QUFDRjtBQU9BLFNBQVMsWUFBWSxHQUE4QztBQUNqRSxRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksTUFBTSxNQUFNO0FBQ25DLE1BQUksQ0FBQyxXQUFZLFFBQU87QUFDeEIsUUFBTSxXQUFXLFdBQVc7QUFDNUIsUUFBTSxRQUFpQyxDQUFDO0FBQ3hDLE1BQUksTUFBTSxRQUFRLFFBQVEsR0FBRztBQUMzQixlQUFXLE1BQU0sVUFBVTtBQUN6QixVQUFJLE9BQU8sT0FBTyxZQUFZLE9BQU8sS0FBTTtBQUMzQyxZQUFNLElBQUk7QUFDVixZQUFNLElBQUksVUFBVSxFQUFFLEdBQUc7QUFDekIsWUFBTSxJQUFJLElBQUksRUFBRSxLQUFLO0FBQ3JCLFVBQUksQ0FBQyxLQUFLLENBQUMsRUFBRztBQUNkLFlBQU0sQ0FBQyxJQUNMLFVBQVUsRUFBRSxZQUFZLEtBQ3hCLFVBQVUsSUFBSSxFQUFFLFdBQVcsR0FBRyxHQUFHLEtBQ2pDLFVBQVUsSUFBSSxFQUFFLGlCQUFpQixHQUFHLE9BQU87QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sVUFBVSxXQUFXLElBQUk7QUFDdEMsUUFBTSxVQUFVLFVBQVUsV0FBVyxHQUFHO0FBQ3hDLFFBQU0sWUFDSixPQUFPLE1BQU0sWUFBWSxNQUFNLFdBQVksTUFBTSxZQUFZLElBQWU7QUFDOUUsUUFBTSxRQUFRLE9BQU8sTUFBTSxPQUFPLE1BQU0sV0FBWSxNQUFNLE9BQU8sSUFBZTtBQUNoRixRQUFNLGNBQ0osT0FBTyxNQUFNLGFBQWEsTUFBTSxXQUFZLE1BQU0sYUFBYSxJQUFlO0FBQ2hGLFFBQU0sWUFDSCxPQUFPLE1BQU0sZ0NBQWdDLE1BQU0sV0FDL0MsTUFBTSxnQ0FBZ0MsSUFDdkMsVUFDSCxPQUFPLE1BQU0sMEJBQTBCLE1BQU0sV0FDekMsTUFBTSwwQkFBMEIsSUFDakMsVUFDSCxPQUFPLE1BQU0sOEJBQThCLE1BQU0sV0FDN0MsTUFBTSw4QkFBOEIsSUFDckM7QUFDTixNQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsU0FBVSxRQUFPO0FBQ3pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiO0FBQ0Y7OztBQzl6QkEsSUFBTSxXQUFXO0FBRVYsU0FBUyxXQUFtQjtBQUNqQyxRQUFNLEtBQUssS0FBSyxJQUFJO0FBQ3BCLE1BQUksU0FBUztBQUNiLE1BQUksSUFBSTtBQUNSLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLGNBQVUsU0FBUyxJQUFJLEVBQUUsS0FBSyxPQUFPO0FBQ3JDLFFBQUksS0FBSyxNQUFNLElBQUksRUFBRTtBQUFBLEVBQ3ZCO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLEtBQU0sYUFBWSxTQUFTLElBQUksRUFBRSxLQUFLO0FBQ3RELFNBQU8sU0FBUztBQUNsQjtBQUVPLFNBQVMsV0FBVyxJQUFvQjtBQUM3QyxTQUFPLEdBQUcsTUFBTSxFQUFFO0FBQ3BCOzs7QUNQQSxJQUFNLG1CQUFpRCxvQkFBSSxJQUFJO0FBQUEsRUFDN0Q7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVNLFNBQVMsa0JBQWtCLE1BQStCO0FBQy9ELFFBQU0sV0FBNEIsQ0FBQztBQUNuQyxNQUFJLFVBQWtDLENBQUM7QUFDdkMsTUFBSSxhQUFhO0FBQ2pCLFFBQU0sUUFBUSxNQUFNO0FBQ2xCLFFBQUksUUFBUSxVQUFVLFFBQVEsT0FBTztBQUNuQyxVQUFJLENBQUMsUUFBUSxTQUFVLFNBQVEsV0FBVztBQUMxQyxlQUFTLEtBQUssT0FBd0I7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFDQSxhQUFXLFdBQVcsS0FBSyxNQUFNLElBQUksR0FBRztBQUN0QyxVQUFNLE9BQU8sY0FBYyxPQUFPO0FBQ2xDLFFBQUksS0FBSyxLQUFLLE1BQU0sR0FBSTtBQUN4QixRQUFJLGdCQUFnQixLQUFLLElBQUksR0FBRztBQUM5QixtQkFBYTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxXQUFZO0FBRWpCLFVBQU0sWUFBWSxLQUFLLE1BQU0sNEJBQTRCO0FBQ3pELFFBQUksV0FBVztBQUNiLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxVQUFVLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDaEQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx3QkFBd0I7QUFDdEQsUUFBSSxjQUFjLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUNyQyxZQUFNO0FBQ04sZ0JBQVUsRUFBRSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2pEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sdUJBQXVCO0FBQ3JELFFBQUksY0FBYyxRQUFRLFFBQVE7QUFDaEMsY0FBUSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRTtBQUMzQztBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixLQUFLLE1BQU0sMEJBQTBCO0FBQzNELFFBQUksaUJBQWlCLFFBQVEsUUFBUTtBQUNuQyxZQUFNLE1BQU0sUUFBUSxjQUFjLENBQUMsS0FBSyxFQUFFO0FBQzFDLGNBQVEsV0FBVyxpQkFBaUIsSUFBSSxHQUFzQixJQUN6RCxNQUNEO0FBQ0o7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU07QUFDTixTQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUNuRDtBQUVBLFNBQVMsY0FBYyxNQUFzQjtBQUczQyxRQUFNLE1BQU0sS0FBSyxRQUFRLEdBQUc7QUFDNUIsU0FBTyxRQUFRLEtBQUssT0FBTyxLQUFLLE1BQU0sR0FBRyxHQUFHO0FBQzlDO0FBRUEsU0FBUyxRQUFRLEdBQW1CO0FBQ2xDLFFBQU0sVUFBVSxFQUFFLEtBQUs7QUFDdkIsTUFDRyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQy9DLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsR0FDaEQ7QUFDQSxXQUFPLFFBQVEsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUM1QjtBQUNBLFNBQU87QUFDVDs7O0FDQ0EsSUFBTSxjQUFjLFFBQVEsUUFBUSxZQUFZLEVBQUU7QUFDbEQsSUFBTSwyQkFBMkI7QUFDakMsSUFBSSx1QkFBdUI7QUFFM0IsZUFBZSxDQUFDLE9BQWlCO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxhQUFhLE9BQU8sR0FBRyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFLENBQUM7QUFFRCxTQUFTLDJCQUFpQztBQUN4Qyx5QkFBdUIsS0FBSyxJQUFJLElBQUk7QUFDdEM7QUFJQSxRQUFRLFFBQVEsWUFBWSxZQUFZLFlBQVk7QUFDbEQsUUFBTSxLQUFLLHVCQUF1QixFQUFFLFNBQVMsWUFBWSxDQUFDO0FBQzFELFFBQU0sT0FBTyxTQUFTO0FBQ3hCLENBQUM7QUFFRCxRQUFRLFFBQVEsVUFBVSxZQUFZLE1BQU07QUFDMUMsT0FBSyxPQUFPLFNBQVM7QUFDdkIsQ0FBQztBQUdELEtBQUssT0FBTyxhQUFhO0FBRXpCLGVBQWUsT0FBTyxRQUErQjtBQUNuRCxNQUFJO0FBQ0YsVUFBTSxhQUFhO0FBQ25CLFVBQU0sc0JBQXNCO0FBQzVCLFVBQU0sNEJBQTRCO0FBQ2xDLFVBQU0scUJBQXFCO0FBRzNCLFVBQU0sU0FBUyxNQUFNLG9CQUFvQixLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUk7QUFDakUsUUFBSSxTQUFTLEVBQUcsT0FBTSxLQUFLLDBCQUEwQixFQUFFLE9BQU8sQ0FBQztBQUMvRCxVQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQUksU0FBUyxPQUFPLFNBQVMsU0FBUyxTQUFTLE1BQU07QUFDbkQsWUFBTSxpQkFBaUIsS0FBSztBQUM1QixZQUFNLG9CQUFvQixLQUFLO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU87QUFBQSxRQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlO0FBQUEsUUFDZix3QkFBd0I7QUFBQSxRQUN4QixrQkFBa0I7QUFBQSxNQUNwQixDQUFDO0FBQ0QsWUFBTSxLQUFLLHdDQUF3QyxFQUFFLE9BQU8sQ0FBQztBQUFBLElBQy9EO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixVQUFNLE1BQU8sZUFBZSxFQUFFLFFBQVEsR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDL0Q7QUFDRjtBQVlBLGVBQWUsdUJBQXNDO0FBQ25ELE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsRUFDdkYsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDZCQUE2QixjQUFjLEdBQUcsQ0FBQztBQUMxRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJO0FBQ0YsWUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJdEIsT0FBTztBQUFBLE1BQ1QsQ0FBQztBQUNELFlBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLE1BQ3RCLENBQUM7QUFDRCxZQUFNLEtBQUsscUNBQXFDO0FBQUEsUUFDOUMsT0FBTyxJQUFJO0FBQUEsUUFDWCxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUU7QUFBQSxNQUMvQixDQUFDO0FBQUEsSUFDSCxTQUFTLEtBQUs7QUFJWixZQUFNLEtBQUssd0NBQXdDO0FBQUEsUUFDakQsT0FBTyxJQUFJO0FBQUEsUUFDWCxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUU7QUFBQSxRQUM3QixHQUFHLGNBQWMsR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxRQUFNLFFBQVEsT0FBTyxNQUFNLGFBQWE7QUFDeEMsUUFBTSxRQUFRLE9BQU8sTUFBTSxtQkFBbUI7QUFDOUMsUUFBTSxRQUFRLE9BQU8sT0FBTyxlQUFlLEVBQUUsaUJBQWlCLG9CQUFvQixDQUFDO0FBQ25GLFFBQU0sUUFBUSxPQUFPLE9BQU8scUJBQXFCO0FBQUEsSUFDL0MsaUJBQWlCLGdDQUFnQztBQUFBLEVBQ25ELENBQUM7QUFDSDtBQU1BLElBQUksa0JBQXlEO0FBSzdELElBQU0saUJBQWlCO0FBRXZCLGVBQWUsd0JBQXVDO0FBRXBELFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLE1BQUksU0FBUyxRQUFRLEVBQUUsWUFBWSxPQUFPO0FBQ3hDLHVCQUFtQixFQUFFLHFCQUFxQjtBQUFBLEVBQzVDLE9BQU87QUFDTCx5QkFBcUI7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyx1QkFBNkI7QUFDcEMsTUFBSSxvQkFBb0IsTUFBTTtBQUM1QixrQkFBYyxlQUFlO0FBQzdCLHNCQUFrQjtBQUFBLEVBQ3BCO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixhQUEyQjtBQUNyRCx1QkFBcUI7QUFDckIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sV0FBVyxDQUFDO0FBQUEsRUFDdkQ7QUFDQSxvQkFBa0IsWUFBWSxNQUFNO0FBQ2xDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELDJCQUF5QjtBQUN6QixRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLGFBQWE7QUFBQSxJQUNiLGVBQWU7QUFBQSxJQUNmLGtCQUFrQjtBQUFBLElBQ2xCLHVCQUF1QjtBQUFBLElBQ3ZCLGlCQUFpQjtBQUFBLElBQ2pCLGVBQWU7QUFBQSxFQUNqQixDQUFDO0FBQ0QscUJBQW1CLEVBQUUscUJBQXFCO0FBQzFDLFFBQU0sS0FBSyw0QkFBNEIsRUFBRSxjQUFjLEVBQUUsc0JBQXNCLENBQUM7QUFFaEYsT0FBSyxlQUFlO0FBQ3BCLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHVCQUFxQjtBQUNyQixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxNQUFNLGVBQWU7QUFBQSxJQUM5QixVQUFVLE1BQU0saUJBQWlCO0FBQUEsSUFDakMsVUFBVSxNQUFNLGlCQUFpQjtBQUFBLEVBQ25DLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUFBLEVBQ3ZGLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpQ0FBaUMsY0FBYyxHQUFHLENBQUM7QUFDOUQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixNQUFJLGNBQWM7QUFDbEIsTUFBSSxnQkFBZ0I7QUFDcEIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxPQUFPLElBQUksT0FBTyxTQUFVO0FBQ2hDLFFBQUksSUFBSSxVQUFXO0FBQ25CLFFBQUk7QUFDRixZQUFNLFVBQVcsTUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3JELFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlQLE1BQU8sTUFBTTtBQUtYLGdCQUFNLHNCQUFzQjtBQUFBLFlBQzFCO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sVUFBVSxvQkFBSSxJQUFhO0FBQ2pDLGNBQUksV0FBVztBQUNmLHFCQUFXLE9BQU8scUJBQXFCO0FBQ3JDLHVCQUFXLE1BQU0sTUFBTSxLQUFLLFNBQVMsaUJBQWlCLEdBQUcsQ0FBQyxHQUFHO0FBQzNELGtCQUFJLFFBQVEsSUFBSSxFQUFFLEVBQUc7QUFFckIsb0JBQU0sS0FBSyxHQUFHLGVBQWUsSUFBSSxLQUFLLEVBQUUsWUFBWTtBQUNwRCxrQkFBSSxNQUFNLGVBQWUsTUFBTSxtQkFBb0I7QUFDbkQsb0JBQU0sT0FBTyxHQUFHLHNCQUFzQjtBQUN0QyxrQkFBSSxLQUFLLFVBQVUsS0FBSyxLQUFLLFdBQVcsRUFBRztBQUMzQyxzQkFBUSxJQUFJLEVBQUU7QUFDZCxrQkFBSTtBQUNGLGdCQUFDLEdBQW1CLE1BQU07QUFDMUIsNEJBQVk7QUFBQSxjQUNkLFFBQVE7QUFBQSxjQUVSO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFJQSxnQkFBTSxPQUEwQjtBQUFBLFlBQzlCLEtBQUs7QUFBQSxZQUNMLE1BQU07QUFBQSxZQUNOLFNBQVM7QUFBQSxZQUNULE9BQU87QUFBQSxZQUNQLFNBQVM7QUFBQSxZQUNULFlBQVk7QUFBQSxVQUNkO0FBQ0EsZ0JBQU0sUUFBUyxTQUFTLGlCQUF3QyxTQUFTO0FBQ3pFLGdCQUFNLGNBQWMsSUFBSSxjQUFjLFdBQVcsSUFBSSxDQUFDO0FBQ3RELGdCQUFNLGNBQWMsSUFBSSxjQUFjLFNBQVMsSUFBSSxDQUFDO0FBQ3BELGlCQUFPLFNBQVM7QUFBQSxZQUNkLEtBQUssU0FBUyxnQkFBZ0I7QUFBQSxZQUM5QixVQUFVO0FBQUEsVUFDWixDQUFDO0FBQ0QsaUJBQU8sRUFBRSxTQUFTO0FBQUEsUUFDcEI7QUFBQSxNQUNGLENBQUM7QUFDRCxxQkFBZTtBQUNmLFlBQU0sSUFBSSxRQUFRLENBQUMsR0FBRztBQUN0QixVQUFJLEtBQUssT0FBTyxFQUFFLGFBQWEsU0FBVSxrQkFBaUIsRUFBRTtBQUFBLElBQzlELFFBQVE7QUFBQSxJQUdSO0FBQUEsRUFDRjtBQUNBLE1BQUksY0FBYyxHQUFHO0FBQ25CLFVBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFJLFNBQVMsTUFBTTtBQUNqQixXQUFLLGVBQWU7QUFDcEIsV0FBSyxpQkFBaUI7QUFDdEIsWUFBTSxxQkFBcUIsSUFBSTtBQUFBLElBRWpDO0FBQUEsRUFDRjtBQUNGO0FBRUEsUUFBUSxPQUFPLFFBQVEsWUFBWSxDQUFDLFVBQVU7QUFDNUMsTUFBSSxNQUFNLFNBQVMsZUFBZTtBQUNoQyxTQUFLLGlCQUFpQjtBQUFBLEVBQ3hCLFdBQVcsTUFBTSxTQUFTLHFCQUFxQjtBQUM3QyxTQUFLLGlCQUFpQixLQUFLO0FBQUEsRUFDN0I7QUFJRixDQUFDO0FBSUQsSUFBSSxRQUFRLFFBQVEsV0FBVztBQUM3QixVQUFRLE9BQU8sVUFBVSxZQUFZLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU0sUUFBUSxjQUFjLE9BQU87QUFBQSxJQUNyQyxTQUFTLEtBQUs7QUFFWixZQUFNLEtBQUssMENBQTBDLGNBQWMsR0FBRyxDQUFDO0FBQ3ZFLFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUFBLElBQ3hDO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFJQSxRQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsS0FBYyxZQUFZO0FBQy9ELE1BQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFHLFFBQU87QUFDbkMsU0FBTyxjQUFjLEdBQUcsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUN2QyxTQUFLLE1BQU8sMEJBQTBCLEVBQUUsTUFBTSxJQUFJLE1BQU0sR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQy9FLFVBQU07QUFBQSxFQUNSLENBQUM7QUFDSCxDQUFDO0FBRUQsU0FBUyxpQkFBaUIsR0FBaUM7QUFDekQsU0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFBWSxPQUFRLEVBQXlCLFNBQVM7QUFDbkY7QUFJQSxJQUFNLDRCQUE0QixvQkFBSSxJQUE0QjtBQUFBLEVBQ2hFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBRUQsZUFBZSxZQUE4QjtBQUMzQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsZUFBZSxjQUFjLEtBQXVDO0FBS2xFLE1BQUksQ0FBRSxNQUFNLFVBQVUsS0FBTSwwQkFBMEIsSUFBSSxJQUFJLElBQUksR0FBRztBQUNuRSxXQUFPLEVBQUUsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUFBLEVBQ2xDO0FBQ0EsVUFBUSxJQUFJLE1BQU07QUFBQSxJQUNoQixLQUFLO0FBQ0gsWUFBTSxpQkFBaUIsSUFBSSxVQUFVLElBQUksS0FBSyxJQUFJLFdBQVcsTUFBTSxJQUFJLFFBQVE7QUFDL0UsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdkUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssK0JBQStCLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdEUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxVQUFJLElBQUksVUFBVSxRQUFRO0FBQ3hCLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xELFdBQVcsSUFBSSxVQUFVLFNBQVM7QUFDaEMsY0FBTSxNQUFPLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDcEQsT0FBTztBQUNMLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xEO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxXQUFXLElBQUksTUFBTTtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxXQUFXO0FBQ2pCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGdCQUFnQjtBQUN0QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxTQUFTLE1BQU07QUFDckIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sWUFBWSxJQUFJLFFBQVEsTUFBTTtBQUNwQyxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxlQUFlLEVBQUUsYUFBYSxJQUFJLEdBQUcsQ0FBQztBQUM1QyxZQUFNLEtBQUssd0JBQXdCLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUNqRCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxlQUFlLEVBQUUsZ0JBQWdCLElBQUksR0FBRyxDQUFDO0FBQy9DLFlBQU0sS0FBSywyQkFBMkIsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQ3BELGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssa0JBQWtCO0FBQ3JCLFlBQU0sSUFBSSxNQUFNLGVBQWUsRUFBRSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2xELFVBQUksQ0FBQyxJQUFJLElBQUk7QUFHWCw2QkFBcUI7QUFDckIsNEJBQW9CO0FBQ3BCLCtCQUF1QjtBQUN2QixjQUFNLFFBQVEsT0FBTyxNQUFNLGNBQWM7QUFDekMsY0FBTSxRQUFRLE9BQU8sTUFBTSxrQkFBa0I7QUFBQSxNQUMvQyxPQUFPO0FBRUwsY0FBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFlBQUksU0FBUyxLQUFNLG9CQUFtQixFQUFFLHFCQUFxQjtBQUFBLE1BQy9EO0FBQ0EsWUFBTSxLQUFLLG1DQUFtQyxFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDNUQsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQjtBQUMxQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxxQkFBcUI7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSyw0QkFBNEI7QUFDL0IsWUFBTSxVQUFVLEtBQUs7QUFBQSxRQUNuQjtBQUFBLFFBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sSUFBSSxPQUFPLENBQUM7QUFBQSxNQUN2RDtBQUNBLFlBQU0sZUFBZSxFQUFFLHVCQUF1QixRQUFRLENBQUM7QUFFdkQsWUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFVBQUksU0FBUyxLQUFNLG9CQUFtQixPQUFPO0FBQzdDLFVBQUksMEJBQTBCLEtBQU0sc0JBQXFCLE9BQU87QUFDaEUsVUFBSSw2QkFBNkIsS0FBTSx5QkFBd0IsT0FBTztBQUN0RSxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0saUJBQWlCO0FBQ3ZCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGtCQUFrQjtBQUN4QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssbUJBQW1CO0FBQ3RCLFlBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsWUFBTSxVQUFVLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUMvRCxZQUFNLFVBQVUsTUFBTSxvQkFBb0IsT0FBTztBQUNqRCxZQUFNLEtBQUssMEJBQTBCLE9BQU87QUFDNUMsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQixJQUFJO0FBQzlCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGNBQWM7QUFDcEIsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFDdEMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssZUFBZTtBQUNsQixZQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFlBQU0sTUFBTSxVQUFVLENBQUM7QUFDdkIsWUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLElBQUksQ0FBQztBQUNqQyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQ0UsYUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLHVCQUF1QjtBQUFBLEVBQ3REO0FBQ0Y7QUFJQSxlQUFlLGlCQUNiLFVBQ0EsS0FDQSxTQUNBLFVBQ2U7QUFDZixNQUFJLGtCQUFrQixJQUFJLFFBQVEsRUFBRztBQUNyQyxNQUFJLENBQUMsZ0JBQWdCLElBQUksUUFBUSxFQUFHO0FBRXBDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxTQUFTLFlBQVksTUFBTztBQUNoQyxNQUFJLFNBQVMsZ0JBQWdCLE9BQU87QUFDbEMsVUFBTSx3QkFDSixLQUFLLElBQUksSUFBSSx3QkFDWixNQUFNLHFCQUFxQixNQUFPLFFBQ2xDLE1BQU0sa0JBQWtCLE1BQU8sUUFDL0IsTUFBTSxxQkFBcUIsTUFBTztBQUNyQyxRQUFJLENBQUMsc0JBQXVCO0FBQUEsRUFDOUI7QUFFQSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBZ0JuQyxRQUFNLFVBQVUsSUFBSSxJQUFJLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sT0FBTyxJQUFJO0FBQUEsSUFDZixTQUFTLE9BQU8sQ0FBQyxNQUFNLEVBQUUsYUFBYSxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQztBQUFBLEVBQ2pGO0FBQ0EsUUFBTSxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBRTFDLE1BQUk7QUFDSixNQUFJO0FBQ0YsaUJBQWEsVUFBVSxVQUFVO0FBQUEsTUFDL0I7QUFBQSxNQUNBLE9BQU87QUFBQSxNQUNQO0FBQUEsTUFDQSxnQkFBZ0Isb0JBQUksSUFBWTtBQUFBLE1BQ2hDLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sV0FBVyxtQkFBbUIsVUFBVSxLQUFLLFVBQVUsR0FBRztBQUNoRTtBQUFBLEVBQ0Y7QUFRQSxRQUFNLGVBQWUsV0FBVyxPQUFPO0FBQ3ZDLGFBQVcsU0FBUyxjQUFjLFdBQVcsUUFBUSxTQUFTLElBQUk7QUFDbEUsUUFBTSxtQkFBbUIsZUFBZSxXQUFXLE9BQU87QUFDMUQsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLEtBQUssNEJBQTRCO0FBQUEsTUFDckM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDMUIsQ0FBQztBQUFBLEVBQ0g7QUFPQSxNQUFJLFdBQVcsYUFBYSxXQUFXLEdBQUc7QUFDeEMsVUFBTSxLQUFLLDRDQUF1QztBQUFBLE1BQ2hEO0FBQUEsTUFDQSxXQUFXLGVBQWUsUUFBUSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsTUFDL0MsWUFBWSxvQkFBb0IsVUFBVSxPQUFPO0FBQUEsTUFDakQsaUJBQWlCLGlCQUFpQixVQUFVLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFBQSxNQUM3RCxtQkFBbUIsaUJBQWlCLFVBQVUsU0FBUyxDQUFDLFFBQVEsQ0FBQztBQUFBLE1BQ2pFLDBCQUEwQixpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDNUQ7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLE1BQ0QsK0JBQStCLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUNqRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLE1BQ0QsaUNBQWlDLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUNuRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0gsT0FBTztBQUNMLFVBQU0sS0FBSyx3QkFBd0I7QUFBQSxNQUNqQztBQUFBLE1BQ0EsVUFBVSxXQUFXLGFBQWE7QUFBQSxNQUNsQyxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBRUEsTUFBSSxXQUFXLG1CQUFtQixTQUFTLEdBQUc7QUFDNUMsVUFBTTtBQUFBLE1BQ0osV0FBVztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLE1BQUksV0FBVyxPQUFPLFdBQVcsRUFBRztBQVdwQyxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsYUFBVyxLQUFLLFdBQVcsUUFBUTtBQUNqQyxRQUFJLEVBQUUsY0FBYztBQUNsQixZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRO0FBQUEsSUFDbkQsT0FBTztBQUNMLFlBQU0sZUFBZSxFQUFFLGdCQUFnQixFQUFFLFFBQVE7QUFBQSxJQUNuRDtBQUdBLFVBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxRQUFJLGFBQWEsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNqRCxrQkFBWSxXQUFXO0FBQ3ZCLGtCQUFZLGFBQWE7QUFDekIsWUFBTSxrQkFBa0IsV0FBVztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUtBLGFBQVcsV0FBVyxXQUFXLGFBQWE7QUFDNUMsUUFBSSxNQUFNLFlBQVksUUFBUSxRQUFRLEVBQUc7QUFDekMsVUFBTSxrQkFBa0IsUUFBUSxhQUFhLFFBQVEsUUFBUTtBQUFBLEVBQy9EO0FBQ0EsTUFBSSxXQUFXLFlBQVksU0FBUyxHQUFHO0FBQ3JDLFVBQU0sS0FBSywwQ0FBMEM7QUFBQSxNQUNuRDtBQUFBLE1BQ0EsU0FBUyxXQUFXLFlBQVk7QUFBQSxNQUNoQyxhQUFhLE1BQU0scUJBQXFCO0FBQUEsSUFDMUMsQ0FBQztBQUFBLEVBQ0g7QUFlQSxRQUFNLGlCQUFpQixTQUFTLG1CQUFtQjtBQUNuRCxRQUFNLGVBQWUsTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxrQkFBa0IsTUFBTSxtQkFBbUI7QUFDakQsTUFBSSxpQkFBaUI7QUFDckIsTUFBSSx1QkFBdUI7QUFDM0IsTUFBSSwwQkFBMEI7QUFDOUIsTUFBSSxrQkFBa0I7QUFDdEIsUUFBTSxhQUF1QyxDQUFDO0FBQzlDLFFBQU0sZ0JBQWdCLG9CQUFJLElBQWdDO0FBQzFELFFBQU0sYUFBYSxvQkFBSSxJQUFxQztBQUM1RCxhQUFXLEtBQUssV0FBVyxRQUFRO0FBQ2pDLFVBQU0sT0FBTyxhQUFhLEVBQUUsY0FBYyxJQUFJLEVBQUUsUUFBUTtBQUN4RCxVQUFNLGdCQUFnQixDQUFDLFFBQVEsd0JBQXdCLEdBQUcsZUFBZTtBQUN6RSxVQUFNLHFCQUFxQixRQUFRLElBQUksS0FBSztBQUM1QyxrQkFBYyxJQUFJLEVBQUUsVUFBVSxxQkFBcUIsYUFBYSxLQUFLO0FBQ3JFLFFBQUksY0FBZSxvQkFBbUI7QUFDdEMsUUFBSSxzQkFBc0IsQ0FBQyxnQkFBZ0I7QUFDekMsVUFBSSxLQUFNLHlCQUF3QjtBQUFBLFVBQzdCLDRCQUEyQjtBQUNoQyxpQkFBVyxJQUFJLEVBQUUsVUFBVSxTQUFTO0FBQ3BDO0FBQUEsSUFDRjtBQUNBLFVBQU0sTUFBTTtBQUFBLE1BQ1YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0o7QUFDQSxRQUFJLFFBQVEsS0FBSyxRQUFRLEtBQUs7QUFDNUIsd0JBQWtCO0FBQ2xCLGlCQUFXLElBQUksRUFBRSxVQUFVLFdBQVc7QUFDdEM7QUFBQSxJQUNGO0FBQ0EsZUFBVyxJQUFJLEVBQUUsVUFBVSxVQUFVO0FBQ3JDLGVBQVcsS0FBSyxDQUFDO0FBQUEsRUFDbkI7QUFDQSxNQUFJLGlCQUFpQixHQUFHO0FBQ3RCLFVBQU0sS0FBSyxtQ0FBbUM7QUFBQSxNQUM1QztBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsV0FBVyxXQUFXO0FBQUEsSUFDeEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxNQUFJLHVCQUF1QiwwQkFBMEIsR0FBRztBQUN0RCxVQUFNLGFBQWEsdUJBQXVCO0FBQzFDLFVBQU0sS0FBSyxvRUFBb0U7QUFBQSxNQUM3RTtBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsYUFBYTtBQUFBLE1BQ2Isa0JBQWtCO0FBQUEsTUFDbEIsV0FBVyxXQUFXO0FBQUEsSUFDeEIsQ0FBQztBQUNELFVBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxRQUFJLFdBQVcsTUFBTTtBQUNuQixhQUFPLG1CQUFtQixPQUFPLG1CQUFtQixLQUFLO0FBQ3pELFlBQU0scUJBQXFCLE1BQU07QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFDQSxNQUFJLGtCQUFrQixLQUFLLGdCQUFnQjtBQUN6QyxVQUFNLEtBQUssMENBQTBDO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLEtBQUs7QUFBQSxNQUNMLFFBQVE7QUFBQSxNQUNSLHVCQUF1QixpQkFBaUIsZ0JBQWdCO0FBQUEsSUFDMUQsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNO0FBQUEsSUFDSixXQUFXLE9BQU87QUFBQSxNQUFJLENBQUMsTUFDckIsbUJBQW1CLEdBQUcsVUFBVSxZQUFZLGNBQWMsSUFBSSxFQUFFLFFBQVEsR0FBRyxXQUFXLElBQUksRUFBRSxRQUFRLENBQUM7QUFBQSxJQUN2RztBQUFBLEVBQ0Y7QUFTQSxRQUFNLHNCQUFzQixXQUFXLFFBQVEsUUFBUTtBQUN2RCxNQUFJLFdBQVcsV0FBVyxFQUFHO0FBRzdCLFFBQU0sV0FBVyxvQkFBSSxJQUE4QjtBQUNuRCxhQUFXLEtBQUssWUFBWTtBQUMxQixVQUFNLE1BQU0sU0FBUyxJQUFJLEVBQUUsY0FBYyxLQUFLLENBQUM7QUFDL0MsUUFBSSxLQUFLLENBQUM7QUFDVixhQUFTLElBQUksRUFBRSxnQkFBZ0IsR0FBRztBQUFBLEVBQ3BDO0FBRUEsYUFBVyxDQUFDLFFBQVEsTUFBTSxLQUFLLFVBQVU7QUFDdkMsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxLQUFLLFFBQVE7QUFDbkUsUUFBSSxRQUFRO0FBQ1osUUFBSSxXQUFXO0FBQ2YsUUFBSSxnQkFBZ0I7QUFDcEIsUUFBSSxrQkFBa0I7QUFDdEIsZUFBVyxLQUFLLFFBQVE7QUFDdEIsWUFBTSxXQUFXLElBQUksYUFBYSxFQUFFLFFBQVE7QUFDNUMsVUFBSSxVQUFVO0FBR1osaUJBQVMsZUFBZTtBQUN4QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsZ0JBQWdCLEVBQUU7QUFDM0IsaUJBQVMsY0FBYyxFQUFFO0FBQ3pCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsaUJBQWlCLEVBQUU7QUFDNUIsY0FBTSxPQUFPLFNBQVMsbUJBQW1CLFNBQVMsbUJBQW1CLFNBQVMsQ0FBQztBQUMvRSxjQUFNLE9BQU8sRUFBRSxtQkFBbUIsQ0FBQztBQUNuQyxZQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssZ0JBQWdCLEtBQUssY0FBYztBQUM1RCxtQkFBUyxtQkFBbUIsS0FBSyxJQUFJO0FBQUEsUUFDdkM7QUFDQSwyQkFBbUI7QUFBQSxNQUNyQixPQUFPO0FBQ0wsY0FBTSxVQUEwQixFQUFFLEdBQUcsR0FBRyxnQkFBZ0IsSUFBSSxPQUFPO0FBQ25FLFlBQUksYUFBYSxFQUFFLFFBQVEsSUFBSTtBQUMvQixpQkFBUztBQUNULFlBQUksY0FBYyxJQUFJLEVBQUUsUUFBUSxNQUFNLFdBQVksa0JBQWlCO0FBQUEsWUFDOUQsYUFBWTtBQUFBLE1BQ25CO0FBQ0EsVUFBSSxDQUFDLElBQUksbUJBQW1CLFNBQVMsRUFBRSxRQUFRLEdBQUc7QUFDaEQsWUFBSSxtQkFBbUIsS0FBSyxFQUFFLFFBQVE7QUFBQSxNQUN4QztBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxlQUFlLFNBQVMsUUFBUSxFQUFHLEtBQUksZUFBZSxLQUFLLFFBQVE7QUFDNUUsUUFBSSxrQkFBa0I7QUFDdEIsVUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixVQUFNO0FBQUEsTUFDSjtBQUFBLE1BQ0EsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFNBQVMsT0FBTyxLQUFLLElBQUkscUJBQXFCLENBQUMsQ0FBQyxFQUFFO0FBQUEsSUFDbEY7QUFDQSxRQUFJLFFBQVEsS0FBSyxrQkFBa0IsR0FBRztBQUNwQyxZQUFNLEtBQUssbUJBQW1CO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0wsVUFBVTtBQUFBLFFBQ1Ysa0JBQWtCO0FBQUEsUUFDbEIsT0FBTyxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUU7QUFBQSxNQUN2QyxDQUFDO0FBR0QsWUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8saUJBQWlCO0FBQ3hCLGVBQU8sb0JBQW9CLE9BQU8sb0JBQW9CLEtBQUs7QUFDM0QsZUFBTyx5QkFDSixPQUFPLHlCQUF5QixLQUFLO0FBQ3hDLGNBQU0scUJBQXFCLE1BQU07QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRSxVQUFVLHVCQUF1QjtBQUNqRSxZQUFNLFlBQVksUUFBUSxXQUFXO0FBQUEsSUFDdkM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSx3QkFDYixtQkFDQSxTQUNBLFlBQ0EsV0FDQSxVQUNlO0FBQ2YsUUFBTSxlQUFlLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sY0FBYyxNQUFNLGtCQUFrQjtBQUM1QyxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxNQUFJLFdBQVc7QUFDZixNQUFJLFVBQVU7QUFDZCxNQUFJLGdCQUFnQjtBQUVwQixhQUFXLEtBQUssbUJBQW1CO0FBQ2pDLFVBQU0sU0FBUyxFQUFFO0FBQ2pCLFFBQUksQ0FBQyxRQUFRO0FBQ1gsdUJBQWlCO0FBQ2pCLFlBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQztBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsT0FBTyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sWUFBWSxDQUFDLEdBQUc7QUFDMUQsaUJBQVc7QUFDWDtBQUFBLElBQ0Y7QUFFQSxVQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsVUFBTSxlQUFlLFFBQVEsRUFBRSxRQUFRO0FBQ3ZDLFFBQUksYUFBYSxVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ2pELGtCQUFZLFdBQVc7QUFDdkIsa0JBQVksYUFBYTtBQUN6QixZQUFNLGtCQUFrQixXQUFXO0FBQUEsSUFDckM7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLHFCQUFxQixjQUFjO0FBQUEsSUFDM0M7QUFFQSxVQUFNLE1BQU0sZUFBZSxDQUFDO0FBQzVCLFVBQU0sT0FBTyxhQUFhLE1BQU0sSUFBSSxFQUFFLFFBQVE7QUFDOUMsUUFBSSxNQUFNLFFBQVEsS0FBSztBQUNyQixpQkFBVztBQUNYO0FBQUEsSUFDRjtBQUVBLFVBQU0sTUFBTSxNQUFNLGdCQUFnQixRQUFRLFlBQVksV0FBVyxRQUFRO0FBQ3pFLFVBQU0sa0JBQWtCLElBQUkscUJBQXFCLENBQUM7QUFDbEQsb0JBQWdCLEVBQUUsUUFBUSxJQUFJO0FBQzlCLFFBQUksb0JBQW9CO0FBQ3hCLFFBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQ2hELFVBQUksbUJBQW1CLEtBQUssRUFBRSxRQUFRO0FBQUEsSUFDeEM7QUFDQSxRQUFJLENBQUMsSUFBSSxlQUFlLFNBQVMsUUFBUSxFQUFHLEtBQUksZUFBZSxLQUFLLFFBQVE7QUFDNUUsUUFBSSxrQkFBa0I7QUFDdEIsVUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixVQUFNO0FBQUEsTUFDSjtBQUFBLE1BQ0EsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFNBQVMsT0FBTyxLQUFLLGVBQWUsRUFBRTtBQUFBLElBQ3RFO0FBQ0EsZ0JBQVk7QUFBQSxFQUNkO0FBRUEsTUFBSSxXQUFXLEtBQUssZ0JBQWdCLEtBQUssVUFBVSxHQUFHO0FBQ3BELFVBQU0sS0FBSywrQkFBK0IsRUFBRSxVQUFVLFVBQVUsU0FBUyxjQUFjLENBQUM7QUFBQSxFQUMxRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLFNBQVMsZUFBZSxHQUE2QjtBQUNuRCxTQUFPLGVBQWUsRUFBRSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7QUFDOUU7QUFzQkEsZUFBZSxzQkFDYixRQUNBLFVBQ2U7QUFDZixNQUFJLE9BQU8sV0FBVyxFQUFHO0FBR3pCLFFBQU0sZUFBZSxvQkFBSSxJQUFZO0FBQ3JDLGFBQVcsS0FBSyxPQUFRLGNBQWEsSUFBSSxFQUFFLFFBQVE7QUFFbkQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLFFBQVE7QUFDdEIsVUFBTSxVQUFzRCxDQUFDO0FBQzdELFFBQUksRUFBRSxtQkFBbUI7QUFDdkIsY0FBUSxLQUFLLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixNQUFNLEVBQUUsaUJBQWlCLENBQUM7QUFBQSxJQUNwRTtBQUNBLFFBQUksRUFBRSxnQkFBaUIsU0FBUSxLQUFLLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixNQUFNLEtBQUssQ0FBQztBQUN6RSxRQUFJLEVBQUUsbUJBQW9CLFNBQVEsS0FBSyxFQUFFLElBQUksRUFBRSxvQkFBb0IsTUFBTSxLQUFLLENBQUM7QUFDL0UsZUFBVyxLQUFLLFNBQVM7QUFDdkIsVUFBSSxhQUFhLElBQUksRUFBRSxFQUFFLEVBQUc7QUFDNUIsVUFBSSxNQUFNLFlBQVksRUFBRSxFQUFFLEVBQUc7QUFDN0IsWUFBTSxrQkFBa0IsRUFBRSxNQUFNLEVBQUUsRUFBRTtBQUNwQyxrQkFBWTtBQUFBLElBQ2Q7QUFBQSxFQUNGO0FBQ0EsTUFBSSxXQUFXLEdBQUc7QUFDaEIsVUFBTSxLQUFLLHNEQUFzRDtBQUFBLE1BQy9EO0FBQUEsTUFDQTtBQUFBLE1BQ0EsYUFBYSxNQUFNLHFCQUFxQjtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxlQUFlLGdCQUNiLFFBQ0EsSUFDQSxXQUNBLFVBQ29CO0FBQ3BCLFFBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUNyQyxNQUFJLElBQUssUUFBTztBQUNoQixRQUFNLE1BQWlCO0FBQUEsSUFDckIsUUFBUSxTQUFTO0FBQUEsSUFDakIsZ0JBQWdCO0FBQUEsSUFDaEIsWUFBWTtBQUFBLElBQ1osaUJBQWlCO0FBQUEsSUFDakIsY0FBYyxDQUFDO0FBQUEsSUFDZixtQkFBbUIsQ0FBQztBQUFBLElBQ3BCLG9CQUFvQixDQUFDO0FBQUEsSUFDckIsZ0JBQWdCLENBQUMsUUFBUTtBQUFBLElBQ3pCLFlBQVk7QUFBQSxFQUNkO0FBQ0EsUUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixRQUFNLEtBQUssZUFBZSxFQUFFLFFBQVEsS0FBSyxXQUFXLElBQUksTUFBTSxFQUFFLENBQUM7QUFDakUsU0FBTztBQUNUO0FBSUEsSUFBSSxhQUE0QixRQUFRLFFBQVE7QUFlaEQsZUFBZSxtQkFBa0M7QUFDL0MsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLFFBQU0sVUFBb0IsQ0FBQztBQUMzQixhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUMvQyxVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksZUFBZTtBQUMzQyxRQUFJLE9BQU8sU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLGVBQWU7QUFDeEQsY0FBUSxLQUFLLE1BQU07QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsU0FBUyxNQUFNO0FBQ3BDO0FBRUEsZUFBZSw4QkFBNkM7QUFPMUQsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxLQUFNO0FBQ3hELFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxNQUFNLEtBQUssSUFBSTtBQUNyQixRQUFNLFVBQW9CLENBQUM7QUFDM0IsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELGNBQVEsS0FBSyxNQUFNO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxhQUFhLFNBQVMsTUFBTTtBQUNwQztBQUVBLGVBQWUsU0FBUyxRQUErQjtBQUNyRCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sYUFBYSxPQUFPLEtBQUssR0FBRyxHQUFHLE1BQU07QUFDN0M7QUFFQSxlQUFlLFlBQVksUUFBZ0IsUUFBK0I7QUFDeEUsUUFBTSxhQUFhLENBQUMsTUFBTSxHQUFHLE1BQU07QUFDckM7QUFFQSxlQUFlLGFBQWEsU0FBbUIsUUFBK0I7QUFDNUUsUUFBTSxTQUFTLENBQUMsR0FBRyxJQUFJLElBQUksT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7QUFDL0QsTUFBSSxPQUFPLFdBQVcsRUFBRztBQUN6QixRQUFNLE1BQU0sV0FBVyxLQUFLLE1BQU0sbUJBQW1CLFFBQVEsTUFBTSxDQUFDO0FBQ3BFLGVBQWEsSUFBSSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDL0IsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUIsU0FBbUIsUUFBK0I7QUFDbEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLFFBQXFCLENBQUM7QUFDNUIsYUFBVyxVQUFVLFNBQVM7QUFDNUIsVUFBTSxNQUFNLElBQUksTUFBTTtBQUN0QixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sU0FBUyxPQUFPLE9BQU8sSUFBSSxZQUFZO0FBQzdDLFVBQU0sb0JBQW9CLE9BQU8sT0FBTyxJQUFJLHFCQUFxQixDQUFDLENBQUM7QUFDbkUsUUFBSSxPQUFPLFdBQVcsS0FBSyxrQkFBa0IsV0FBVyxHQUFHO0FBQ3pELFlBQU0sZUFBZSxNQUFNO0FBQzNCLFlBQU0saUJBQWlCLFFBQVEsQ0FBQztBQUNoQztBQUFBLElBQ0Y7QUFDQSxVQUFNLEtBQUssZUFBZSxRQUFRLEtBQUssUUFBUSxpQkFBaUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsTUFBSSxNQUFNLFdBQVcsRUFBRztBQUV4QixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLE1BQU07QUFDdEQsVUFBTSxLQUFLLHVDQUF1QztBQUFBLE1BQ2hELE9BQU8sTUFBTTtBQUFBLE1BQ2IsU0FBUyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsSUFDdkQsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxRQUFNLFFBQVEsTUFBTSxRQUFRLENBQUMsU0FBUztBQUFBLElBQ3BDO0FBQUEsTUFDRSxNQUFNLEtBQUs7QUFBQSxNQUNYLGVBQWVDLFVBQVMsS0FBSyxVQUFVLEtBQUssU0FBUyxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsSUFDdEU7QUFBQSxJQUNBO0FBQUEsTUFDRSxNQUFNLEtBQUs7QUFBQSxNQUNYLGVBQWVBLFVBQVMsS0FBSyxVQUFVLEtBQUssTUFBTSxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsSUFDbkU7QUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNLFlBQVksd0JBQXdCLEtBQUs7QUFFL0MsTUFBSTtBQUNGLFVBQU0sU0FBUyxNQUFNLE9BQU8sWUFBWTtBQUFBLE1BQ3RDO0FBQUEsTUFDQSxTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQ0QsVUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLGVBQVcsUUFBUSxPQUFPO0FBQ3hCLFlBQU0saUJBQWlCLE1BQU0sK0JBQStCLElBQUk7QUFLaEUsWUFBTSxRQUFRLE1BQU0sWUFBWSxHQUFHLEtBQUssTUFBTTtBQUM5QyxZQUFNLFNBQVEsb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUNsRCxZQUFNLGVBQWUsUUFBUSxLQUFLLGNBQWMsUUFBUSxLQUFLLGFBQWE7QUFDMUUsWUFBTSxZQUFZLEtBQUssUUFBUTtBQUFBLFFBQzdCLFlBQVksZUFBZSxLQUFLLE9BQU8sU0FBUyxLQUFLLGtCQUFrQjtBQUFBLFFBQ3ZFLFdBQVc7QUFBQSxRQUNYLGVBQWUsS0FBSyxJQUFJO0FBQUEsUUFDeEIsaUJBQ0csTUFBTSxrQkFBa0IsS0FBSyxLQUFLLE9BQU8sU0FBUyxLQUFLLGtCQUFrQjtBQUFBLFFBQzVFLGVBQWU7QUFBQSxNQUNqQixDQUFDO0FBR0QsWUFBTSxRQUFRLElBQUksS0FBSyxNQUFNLEtBQUssQ0FBQztBQUNuQyxZQUFNLFVBQVMsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDdEMsaUJBQVcsS0FBSyxLQUFLLFFBQVE7QUFDM0IsY0FBTSxFQUFFLFFBQVEsSUFBSTtBQUFBLFVBQ2xCLElBQUk7QUFBQSxVQUNKLEtBQUs7QUFBQSxZQUNILEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3RDLGNBQU0sRUFBRSxRQUFRLElBQUk7QUFBQSxVQUNsQixJQUFJO0FBQUEsVUFDSixLQUFLLGVBQWUsQ0FBQztBQUFBLFFBQ3ZCO0FBQUEsTUFDRjtBQUNBLFVBQUksS0FBSyxNQUFNLElBQUk7QUFDbkIsWUFBTSxLQUFLLG1CQUFtQjtBQUFBLFFBQzVCLFFBQVEsS0FBSztBQUFBLFFBQ2I7QUFBQSxRQUNBLFFBQVEsS0FBSyxPQUFPO0FBQUEsUUFDcEIsYUFBYSxLQUFLLGtCQUFrQjtBQUFBLFFBQ3BDLEtBQUssS0FBSztBQUFBLFFBQ1YsTUFBTSxLQUFLO0FBQUEsUUFDWCxjQUFjLE9BQU87QUFBQSxNQUN2QixDQUFDO0FBQUEsSUFDSDtBQUNBLFVBQU0sa0JBQWtCLEdBQUc7QUFDM0IsVUFBTSxLQUFLLHlCQUF5QjtBQUFBLE1BQ2xDO0FBQUEsTUFDQSxNQUFNLE1BQU07QUFBQSxNQUNaLE9BQU8sTUFBTTtBQUFBLE1BQ2IsUUFBUSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQUEsTUFDbkUsYUFBYSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLGtCQUFrQixRQUFRLENBQUM7QUFBQSxNQUNuRixRQUFRLE9BQU87QUFBQSxJQUNqQixDQUFDO0FBQ0Q7QUFDRSxZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU8sS0FBSztBQUFBLFFBQ1osWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWUsS0FBSztBQUFBLFFBQ3BCLHdCQUF3QixLQUFLO0FBQUEsUUFDN0Isa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFFBQUksZUFBZSxhQUFhO0FBQzlCLFlBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsWUFBTSxTQUNKLElBQUksYUFBYSxTQUNiLGVBQ0EsSUFBSSxhQUFhLGVBQ2YsaUJBQ0EsSUFBSSxhQUFhLFlBQ2Ysa0JBQ0EsS0FBSztBQUNmLFlBQU0sY0FBYztBQUFBLFFBQ2xCO0FBQUEsUUFDQSxPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPLElBQUk7QUFBQSxRQUNYLGVBQWUsS0FBSztBQUFBLFFBQ3BCLHdCQUF3QixLQUFLO0FBQUEsUUFDN0Isa0JBQ0UsSUFBSSxhQUFhLGVBQWUsSUFBSSxtQkFBbUIsS0FBSztBQUFBLE1BQ2hFLENBQUM7QUFDRCxZQUFNLE1BQU8sZ0JBQWdCO0FBQUEsUUFDM0I7QUFBQSxRQUNBLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3JELE1BQU0sTUFBTTtBQUFBLFFBQ1osT0FBTyxNQUFNO0FBQUEsUUFDYixVQUFVLElBQUk7QUFBQSxRQUNkLFFBQVEsSUFBSTtBQUFBLFFBQ1osU0FBUyxJQUFJO0FBQUEsUUFDYixrQkFBa0IsSUFBSTtBQUFBLE1BQ3hCLENBQUM7QUFBQSxJQUNILE9BQU87QUFDTCxZQUFNLE1BQU8sZ0JBQWdCO0FBQUEsUUFDM0I7QUFBQSxRQUNBLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3JELE1BQU0sTUFBTTtBQUFBLFFBQ1osT0FBTyxNQUFNO0FBQUEsUUFDYixHQUFHLGNBQWMsR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFFRixVQUFFO0FBQ0EsVUFBTSxlQUFlO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsZUFDUCxRQUNBLEtBQ0EsUUFDQSxtQkFDVztBQUNYLFFBQU0sS0FBSyxXQUFXLElBQUksVUFBVTtBQUNwQyxRQUFNLE1BQU0sSUFBSSxXQUFXLE1BQU0sR0FBRyxFQUFFO0FBQ3RDLFFBQU0sV0FBVyxXQUFXLElBQUksTUFBTTtBQUN0QyxRQUFNLFVBQVUsT0FBTyxNQUFNLElBQUksRUFBRSxJQUFJLFFBQVE7QUFDL0MsUUFBTSxXQUFXLFFBQVEsTUFBTSxJQUFJLEVBQUUsSUFBSSxRQUFRO0FBQ2pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsU0FBUztBQUFBLE1BQ1AsZ0JBQWdCO0FBQUEsTUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxNQUNwQixnQkFBZ0I7QUFBQSxNQUNoQixhQUFhLElBQUk7QUFBQSxNQUNqQixVQUFVLElBQUksZUFBZSxLQUFLLEdBQUc7QUFBQSxNQUNyQyxZQUFZLFVBQVU7QUFBQSxNQUN0QixZQUFZLElBQUk7QUFBQSxNQUNoQjtBQUFBLE1BQ0Esb0JBQW9CO0FBQUEsSUFDdEI7QUFBQSxJQUNBLE1BQU07QUFBQSxNQUNKLGdCQUFnQjtBQUFBLE1BQ2hCLGdCQUFnQixJQUFJO0FBQUEsTUFDcEIsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYSxJQUFJO0FBQUEsTUFDakIsb0JBQW9CLElBQUk7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsd0JBQXdCLE9BQTRCO0FBQzNELE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdEIsVUFBTSxPQUFPLE1BQU0sQ0FBQztBQUNwQixVQUFNQyxvQkFBbUIsS0FBSyxrQkFBa0I7QUFDaEQsVUFBTUMsVUFBU0Qsb0JBQW1CLElBQUksS0FBS0EsaUJBQWdCLGlCQUFpQjtBQUM1RSxXQUFPLFlBQVksS0FBSyxNQUFNLElBQUksS0FBSyxHQUFHLElBQUksS0FBSyxPQUFPLE1BQU0sU0FBUyxLQUFLLE9BQU8sV0FBVyxJQUFJLEtBQUssR0FBRyxHQUFHQyxPQUFNLFNBQVMsS0FBSyxRQUFRO0FBQUEsRUFDN0k7QUFDQSxRQUFNLE9BQU8sQ0FBQyxHQUFHLElBQUksSUFBSSxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLO0FBQzlELFFBQU0sV0FBVyxLQUFLLFdBQVcsSUFBSSxLQUFLLENBQUMsSUFBSyxHQUFHLEtBQUssQ0FBQyxDQUFDLEtBQUssS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDO0FBQ3BGLFFBQU0sYUFBYSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQzlFLFFBQU0sbUJBQW1CLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssa0JBQWtCLFFBQVEsQ0FBQztBQUMvRixRQUFNLFNBQVMsbUJBQW1CLElBQUksS0FBSyxnQkFBZ0IsaUJBQWlCO0FBQzVFLFNBQU8sa0JBQWtCLE1BQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxlQUFlLElBQUksS0FBSyxHQUFHLEdBQUcsTUFBTSxLQUFLLFFBQVE7QUFDckg7QUFFQSxlQUFlLCtCQUErQixNQUFrQztBQUM5RSxRQUFNLFVBQVUsTUFBTSxhQUFhLEtBQUssTUFBTTtBQUM5QyxNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLE1BQUksUUFBUSxXQUFXLEtBQUssSUFBSSxPQUFRLFFBQU8sT0FBTyxLQUFLLFFBQVEsWUFBWSxFQUFFO0FBRWpGLFFBQU0sWUFBWSxJQUFJO0FBQUEsSUFDcEIsS0FBSyxPQUFPLElBQUksQ0FBQyxNQUFNO0FBQUEsTUFDckIsRUFBRTtBQUFBLE1BQ0YsY0FBYyxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRSxZQUFZO0FBQUEsSUFDM0YsQ0FBQztBQUFBLEVBQ0g7QUFDQSxhQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdEMsY0FBVSxJQUFJLEVBQUUsVUFBVSxlQUFlLENBQUMsQ0FBQztBQUFBLEVBQzdDO0FBQ0EsUUFBTSxrQkFBa0QsQ0FBQztBQUN6RCxhQUFXLENBQUMsU0FBUyxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ25FLFVBQU0sZUFBZSxVQUFVLElBQUksT0FBTztBQUMxQyxVQUFNLGFBQWE7QUFBQSxNQUNqQixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsSUFDUjtBQUNBLFFBQUksQ0FBQyxnQkFBZ0IsaUJBQWlCLFlBQVk7QUFDaEQsc0JBQWdCLE9BQU8sSUFBSSxFQUFFLEdBQUcsTUFBTTtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sdUJBQXlELENBQUM7QUFDaEUsYUFBVyxDQUFDLFNBQVMsV0FBVyxLQUFLLE9BQU8sUUFBUSxRQUFRLHFCQUFxQixDQUFDLENBQUMsR0FBRztBQUNwRixVQUFNLGVBQWUsVUFBVSxJQUFJLE9BQU87QUFDMUMsVUFBTSxhQUFhLGVBQWUsV0FBVztBQUM3QyxRQUFJLENBQUMsZ0JBQWdCLGlCQUFpQixZQUFZO0FBQ2hELDJCQUFxQixPQUFPLElBQUksRUFBRSxHQUFHLFlBQVk7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNLGVBQWUsb0JBQUksSUFBSTtBQUFBLElBQzNCLEdBQUcsT0FBTyxLQUFLLGVBQWU7QUFBQSxJQUM5QixHQUFHLE9BQU8sS0FBSyxvQkFBb0I7QUFBQSxFQUNyQyxDQUFDO0FBQ0QsUUFBTSxpQkFBaUIsYUFBYTtBQUNwQyxNQUFJLG1CQUFtQixHQUFHO0FBQ3hCLFVBQU0sZUFBZSxLQUFLLE1BQU07QUFDaEMsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNLFlBQVksU0FBUztBQUMzQixhQUFXLFNBQVMsT0FBTyxPQUFPLGVBQWUsR0FBRztBQUNsRCxVQUFNLGlCQUFpQjtBQUFBLEVBQ3pCO0FBQ0EsUUFBTSxhQUFhLEtBQUssUUFBUTtBQUFBLElBQzlCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVksUUFBUTtBQUFBLElBQ3BCLGNBQWM7QUFBQSxJQUNkLG1CQUFtQjtBQUFBLElBQ25CLG9CQUFvQixRQUFRLG1CQUFtQixPQUFPLENBQUMsT0FBTyxhQUFhLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDcEYsQ0FBQztBQUNELFFBQU0sS0FBSyxvQ0FBb0M7QUFBQSxJQUM3QyxRQUFRLEtBQUs7QUFBQSxJQUNiLGVBQWUsS0FBSztBQUFBLElBQ3BCLFVBQVUsV0FBVyxTQUFTO0FBQUEsSUFDOUIsV0FBVztBQUFBLEVBQ2IsQ0FBQztBQUNELFNBQU87QUFDVDtBQUlBLGVBQWUsV0FBVyxRQUErQjtBQUN2RCwyQkFBeUI7QUFNekIsUUFBTSxZQUFZLGlCQUFpQixNQUFNO0FBQ3pDLFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxRQUFRLEtBQUssZUFBZSxDQUFDO0FBQ25FLE1BQUksQ0FBRSxNQUFNLGFBQWEsTUFBTSxHQUFJO0FBQ2pDLFVBQU0sT0FBTSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNuQyxVQUFNLGFBQWEsUUFBUTtBQUFBLE1BQ3pCLFFBQVEsU0FBUztBQUFBLE1BQ2pCLGdCQUFnQjtBQUFBLE1BQ2hCLFlBQVk7QUFBQSxNQUNaLGlCQUFpQjtBQUFBLE1BQ2pCLGNBQWMsQ0FBQztBQUFBLE1BQ2YsbUJBQW1CLENBQUM7QUFBQSxNQUNwQixvQkFBb0IsQ0FBQztBQUFBLE1BQ3JCLGdCQUFnQixDQUFDO0FBQUEsTUFDakIsWUFBWTtBQUFBLElBQ2QsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxXQUFXLFFBQVEsS0FBSyxDQUFDO0FBQzVEO0FBRUEsZUFBZSxhQUE0QjtBQUN6QyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxPQUFPLFNBQVMsT0FBTyxDQUFDO0FBQzlELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sV0FBVyxFQUFFLE1BQU07QUFBQSxFQUMzQjtBQUNGO0FBV0EsZUFBZSxrQkFBaUM7QUFDOUMsMkJBQXlCO0FBQ3pCLE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsUUFBUSxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQUEsRUFDdkUsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlEQUFpRCxjQUFjLEdBQUcsQ0FBQztBQUM5RTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLE1BQUksQ0FBQyxPQUFPLE9BQU8sSUFBSSxPQUFPLFlBQVksQ0FBQyxJQUFJLEtBQUs7QUFDbEQsVUFBTSxLQUFLLGtDQUFrQztBQUM3QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsZ0NBQWdDLEtBQUssSUFBSSxHQUFHLEdBQUc7QUFDbEQsVUFBTSxLQUFLLCtEQUErRDtBQUFBLE1BQ3hFLEtBQUssV0FBVyxJQUFJLEdBQUc7QUFBQSxJQUN6QixDQUFDO0FBQ0Q7QUFBQSxFQUNGO0FBQ0EsUUFBTSxLQUFLLCtCQUErQixFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBR3RFLE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTyxDQUFDLGNBQWM7QUFBQSxNQUN0QixPQUFPO0FBQUEsSUFDVCxDQUFDO0FBQ0QsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU8sQ0FBQyxZQUFZO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLHVDQUF1QyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ3RFO0FBR0EsTUFBSTtBQUNGLFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPO0FBQUEsTUFDUCxNQUFNLE1BQU07QUFDVixjQUFNLElBQUksT0FBTztBQUNqQixlQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQztBQUNwRCxtQkFBVyxNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDLEdBQUcsR0FBRztBQUMzRSxtQkFBVyxNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDLEdBQUcsSUFBSTtBQUFBLE1BQzlFO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssMENBQTBDLGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDekU7QUFDRjtBQWFBLElBQU0sa0JBQWtCO0FBRXhCLGVBQWUsa0JBQTBDO0FBQ3ZELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksZUFBZTtBQUM5RCxRQUFNLEtBQUssT0FBTyxlQUFlO0FBQ2pDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsZ0JBQWdCLElBQWtDO0FBQy9ELE1BQUksT0FBTyxNQUFNO0FBQ2YsVUFBTSxRQUFRLFFBQVEsTUFBTSxPQUFPLGVBQWU7QUFBQSxFQUNwRCxPQUFPO0FBQ0wsVUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxlQUFlLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDM0Q7QUFDRjtBQUVBLGVBQWUsbUJBQWtDO0FBQy9DLDJCQUF5QjtBQUN6QixRQUFNLFFBQVEsTUFBTSxrQkFBa0I7QUFDdEMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUsseUJBQXlCO0FBQ3BDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxrQkFBa0I7QUFBQSxJQUN0QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELHVCQUFxQixPQUFPO0FBQzVCLE9BQUssWUFBWTtBQUNqQixRQUFNLEtBQUssd0JBQXdCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQzNFLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksd0JBQStEO0FBRW5FLFNBQVMscUJBQXFCLFNBQXVCO0FBQ25ELE1BQUksMEJBQTBCLEtBQU0sZUFBYyxxQkFBcUI7QUFDdkUsMEJBQXdCLFlBQVksTUFBTTtBQUN4QyxTQUFLLFlBQVksRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNoQyxXQUFLLEtBQUssdUJBQXVCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDckQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHNCQUE0QjtBQUNuQyxNQUFJLDBCQUEwQixNQUFNO0FBQ2xDLGtCQUFjLHFCQUFxQjtBQUNuQyw0QkFBd0I7QUFBQSxFQUMxQjtBQUNGO0FBRUEsZUFBZSxvQkFBbUM7QUFDaEQsc0JBQW9CO0FBQ3BCLFFBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxRQUFNLFFBQVEsTUFBTSxnQkFBZ0I7QUFDcEMsUUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixRQUFNLE9BQU8sTUFBTSxrQkFBa0I7QUFDckMsUUFBTSxrQkFBa0IsSUFBSTtBQUM1QixRQUFNLEtBQUssMEJBQTBCO0FBQUEsSUFDbkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxjQUE2QjtBQUMxQyxNQUFJLE9BQU8sTUFBTSxrQkFBa0I7QUFDbkMsTUFBSSxTQUFTLE1BQU07QUFFakIsd0JBQW9CO0FBQ3BCO0FBQUEsRUFDRjtBQUlBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUVBLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFFRCxVQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsZUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsVUFBSSxJQUFJLFNBQVMsS0FBSyxTQUFTLE9BQU8sR0FBRztBQUN2QyxjQUFNLGVBQWUsUUFBUSxLQUFLLFNBQVMsT0FBTztBQUNsRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLGtCQUFrQixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNLFNBQVMsTUFBTSxrQkFBa0I7QUFDdkMsTUFBSSxDQUFDLFFBQVE7QUFDWCx3QkFBb0I7QUFDcEIsVUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyx5QkFBeUIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ2pFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLE1BQU0saUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUNuRSxNQUFJLFFBQVEsTUFBTSxnQkFBZ0I7QUFDbEMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLGdCQUFnQixJQUFJLEVBQUU7QUFBQSxJQUM5RCxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxXQUFRLE1BQU0sa0JBQWtCLEtBQU07QUFDdEMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyxnQkFBZ0I7QUFBQSxNQUN6QixRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLFdBQVcsTUFBTSxrQkFBa0I7QUFBQSxNQUNuQyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyw0Q0FBNEM7QUFBQSxNQUNyRCxRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sZUFBZSxPQUFPLFFBQVEsT0FBTyxPQUFPO0FBQ2xELFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBV0EsSUFBTSxzQkFBc0I7QUFFNUIsZUFBZSxxQkFBNkM7QUFDMUQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxtQkFBbUI7QUFDbEUsUUFBTSxLQUFLLE9BQU8sbUJBQW1CO0FBQ3JDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsbUJBQW1CLElBQWtDO0FBQ2xFLE1BQUksT0FBTyxLQUFNLE9BQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxtQkFBbUI7QUFBQSxNQUNsRSxPQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUNwRTtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELDJCQUF5QjtBQUN6QixRQUFNLFFBQVEsTUFBTSxxQkFBcUI7QUFDekMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUssNkJBQTZCO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELDBCQUF3QixPQUFPO0FBQy9CLE9BQUssZUFBZTtBQUNwQixRQUFNLEtBQUssNEJBQTRCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQy9FLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksMkJBQWtFO0FBRXRFLFNBQVMsd0JBQXdCLFNBQXVCO0FBQ3RELE1BQUksNkJBQTZCLEtBQU0sZUFBYyx3QkFBd0I7QUFDN0UsNkJBQTJCLFlBQVksTUFBTTtBQUMzQyxTQUFLLGVBQWUsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNuQyxXQUFLLEtBQUssMkJBQTJCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDekQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHlCQUErQjtBQUN0QyxNQUFJLDZCQUE2QixNQUFNO0FBQ3JDLGtCQUFjLHdCQUF3QjtBQUN0QywrQkFBMkI7QUFBQSxFQUM3QjtBQUNGO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQseUJBQXVCO0FBQ3ZCLFFBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sUUFBUSxNQUFNLG1CQUFtQjtBQUN2QyxRQUFNLG1CQUFtQixJQUFJO0FBQzdCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLFVBQVU7QUFBQSxJQUNuQixXQUFXLE1BQU0sYUFBYTtBQUFBLEVBQ2hDLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJLE9BQU8sTUFBTSxxQkFBcUI7QUFDdEMsTUFBSSxTQUFTLE1BQU07QUFDakIsMkJBQXVCO0FBQ3ZCO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUNBLFVBQU0sS0FBSyxvREFBb0Q7QUFBQSxNQUM3RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFDRCxVQUFNLGtCQUFrQixLQUFLLFNBQVMsT0FBTztBQUM3QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUVBLFFBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxNQUFJLENBQUMsUUFBUTtBQUNYLDJCQUF1QjtBQUN2QixVQUFNLG1CQUFtQixJQUFJO0FBQzdCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLDZCQUE2QixFQUFFLFdBQVcsS0FBSyxVQUFVLENBQUM7QUFDckUsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUdBLE1BQUksTUFBTSxZQUFZLE9BQU8sT0FBTyxHQUFHO0FBQ3JDLFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQU9BLFFBQU0sTUFDSixPQUFPLFdBQVcsYUFDZCw4QkFBOEIsT0FBTyxPQUFPLEtBQzVDLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDN0QsTUFBSSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3JDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxtQkFBbUIsSUFBSSxFQUFFO0FBQUEsSUFDakUsT0FBTztBQUNMLFlBQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQztBQUFBLElBQzFDO0FBQ0EsV0FBUSxNQUFNLHFCQUFxQixLQUFNO0FBQ3pDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLEtBQUssb0JBQW9CO0FBQUEsTUFDN0IsVUFBVSxPQUFPO0FBQUEsTUFDakIsYUFBYSxPQUFPLFdBQVcsYUFBYSxPQUFPLE9BQU87QUFBQSxNQUMxRCxXQUFXLE1BQU0scUJBQXFCO0FBQUEsTUFDdEMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsVUFBVSxPQUFPO0FBQUEsTUFDakIsR0FBRyxjQUFjLEdBQUc7QUFBQSxJQUN0QixDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBSUEsZUFBZSxXQUNiLFFBQ0EsVUFDQSxLQUNBLEtBQ0EsS0FDZTtBQUNmLFFBQU0sTUFBTyx3QkFBd0IsRUFBRSxRQUFRLFVBQVUsS0FBSyxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDckYsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxLQUFNO0FBQ3hELFFBQU0sVUFBNkI7QUFBQSxJQUNqQyxnQkFBZ0I7QUFBQSxJQUNoQjtBQUFBLElBQ0E7QUFBQSxJQUNBLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNwQyxZQUFZO0FBQUEsSUFDWixPQUFPLGNBQWMsR0FBRztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUNBLFFBQU0sS0FBSyxXQUFXLFFBQVEsV0FBVztBQUN6QyxRQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUssVUFBVSxPQUFPLENBQUM7QUFDL0MsUUFBTSxPQUFPLG1CQUFtQixFQUFFLElBQUksSUFBSTtBQUMxQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxRQUFRO0FBQUEsTUFDbkI7QUFBQSxNQUNBLGVBQWVGLFVBQVMsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLE1BQy9ELFNBQVMsZUFBZSxNQUFNLElBQUksUUFBUTtBQUFBLElBQzVDLENBQUM7QUFBQSxFQUNILFNBQVMsTUFBTTtBQUNiLFVBQU0sTUFBTyw0QkFBNEIsRUFBRSxHQUFHLGNBQWMsSUFBSSxFQUFFLENBQUM7QUFBQSxFQUNyRTtBQUNGO0FBRUEsZUFBZSxLQUFLLEdBQTRCO0FBQzlDLFFBQU0sTUFBTSxJQUFJLFlBQVksRUFBRSxPQUFPLENBQUM7QUFDdEMsUUFBTSxTQUFTLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxHQUFHO0FBQ3hELFFBQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxXQUFXLE1BQU0sQ0FBQyxFQUMxQyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFO0FBQ1YsU0FBTyxJQUFJLE1BQU0sR0FBRyxDQUFDO0FBQ3ZCO0FBSUEsZUFBZSxpQkFBaUIsT0FBK0I7QUFDN0QsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU87QUFBQSxNQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsTUFDUCxlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsTUFBSSxDQUFDLE9BQU87QUFJVixRQUFJLEtBQUssV0FBVyxrQkFBa0IsS0FBSyxxQkFBcUIsTUFBTTtBQUNwRSxZQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDM0MsVUFBSSxTQUFTLEtBQUssaUJBQWtCO0FBQUEsSUFDdEM7QUFLQSxRQUFJLEtBQUssV0FBVztBQUNsQixZQUFNLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUztBQUNsRCxVQUFJLE1BQU0sOEJBQStCO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLElBQUksTUFBTSxPQUFPLGlCQUFpQjtBQUl4QyxRQUFJLFdBQVc7QUFDZixRQUFJLFNBQVMsVUFBVSxTQUFTLFdBQVcsRUFBRSxnQkFBZ0I7QUFDM0QsaUJBQVcsTUFBTSxPQUFPLGFBQWEsU0FBUyxNQUFNO0FBQUEsSUFDdEQ7QUFDQSxVQUFNLGFBQWEsU0FBUyxpQkFBaUIsS0FBSyxLQUFLO0FBQ3ZELFFBQUksWUFBWSxZQUFZO0FBQzFCLFlBQU0sT0FBTyxrQkFBa0I7QUFBQSxJQUNqQztBQUNBLFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU8sRUFBRTtBQUFBLE1BQ1QsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU87QUFBQSxNQUNQLGVBQWUsRUFBRTtBQUFBLE1BQ2pCLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLEtBQUssdUJBQXVCO0FBQUEsTUFDaEMsT0FBTyxFQUFFO0FBQUEsTUFDVCxNQUFNLEVBQUU7QUFBQSxNQUNSLGdCQUFnQixFQUFFO0FBQUEsTUFDbEIsbUJBQW1CLFNBQVM7QUFBQSxNQUM1QiwwQkFBMEI7QUFBQSxNQUMxQixjQUFjLGFBQWEsWUFBWTtBQUFBLElBQ3pDLENBQUM7QUFDRCxRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sS0FBSyw4Q0FBOEM7QUFBQSxRQUN2RCxZQUFZLFNBQVM7QUFBQSxRQUNyQixnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLEtBQUssd0NBQXdDLEVBQUU7QUFBQSxNQUNqRCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFNLGVBQWUsY0FBYyxJQUFJLFdBQVc7QUFDeEQsVUFBTSxTQUNKLFFBQVEsU0FDSixlQUNBLFFBQVEsZUFDTixpQkFDQSxRQUFRLFlBQ04sa0JBQ0E7QUFDVixVQUFNLFVBQ0osZUFBZSxlQUFlLFFBQVEsZUFBZSxJQUFJLG1CQUFtQjtBQUM5RSxVQUFNLGNBQWM7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU8sY0FBYyxHQUFHLEVBQUU7QUFBQSxNQUMxQixlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxLQUFLLDJCQUEyQjtBQUFBLE1BQ3BDLFVBQVU7QUFBQSxNQUNWLGtCQUFrQjtBQUFBLE1BQ2xCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLG9CQUFvQixPQUErQjtBQUNoRSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLEtBQUs7QUFDakIsVUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsT0FBTztBQUlWLFVBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBSUEsVUFBTSxnQkFBZ0IsTUFBTSx1QkFBdUI7QUFDbkQsUUFBSSxlQUFlO0FBQ2pCLFlBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sYUFBYTtBQUNqRCxVQUFJLE9BQU8sU0FBUyxHQUFHLEtBQUssTUFBTSw4QkFBK0I7QUFBQSxJQUNuRTtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxNQUFNLE9BQU8sYUFBYSxzQkFBc0I7QUFDN0QsUUFBSSxDQUFDLE1BQU07QUFDVCxVQUFJLE1BQU8sT0FBTSxLQUFLLGlEQUFpRDtBQUN2RSxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFTLGtCQUFrQixJQUFJO0FBQ3JDLFFBQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsWUFBTSxLQUFLLDhDQUE4QztBQUN6RCxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxZQUFZLE1BQU07QUFDeEIsVUFBTSx1QkFBdUIsUUFBUSxLQUFLO0FBQzFDLFVBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQsUUFBSSxNQUFPLE9BQU0sS0FBSywyQkFBMkIsRUFBRSxPQUFPLE9BQU8sT0FBTyxDQUFDO0FBQUEsRUFDM0UsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlEQUFpRCxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ2hGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSx1QkFBdUIsUUFBc0IsT0FBK0I7QUFDekYsUUFBTSxPQUFPLE1BQU0sT0FBTyxhQUFhLG9CQUFvQjtBQUMzRCxNQUFJLENBQUMsTUFBTTtBQUNULFVBQU0sbUJBQW1CLElBQUk7QUFDN0IsUUFBSSxNQUFPLE9BQU0sS0FBSywwREFBMEQ7QUFDaEY7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sV0FBVyxxQkFBcUIsS0FBSyxNQUFNLElBQUksQ0FBWTtBQUNqRSxVQUFNLG1CQUFtQixRQUFRO0FBQ2pDLFFBQUksT0FBTztBQUNULFlBQU0sS0FBSyw4QkFBOEI7QUFBQSxRQUN2QyxVQUFVLE9BQU8sS0FBSyxTQUFTLFFBQVEsRUFBRTtBQUFBLFFBQ3pDLGNBQWMsU0FBUztBQUFBLE1BQ3pCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssK0RBQStELGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDOUY7QUFDRjtBQUlBLGVBQWUsaUJBQWdDO0FBQzdDLFFBQU0sUUFBUSxNQUFNLFdBQVc7QUFDL0IsVUFBUSxRQUFRLFlBQVksRUFBRSxNQUFNLGlCQUFpQixNQUFNLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDOUU7QUFFQSxlQUFlLGFBQXNDO0FBQ25ELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxXQUFXO0FBQ2YsTUFBSTtBQUNGLFVBQU0sT0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQzNGLGVBQVcsS0FBSztBQUFBLEVBQ2xCLFFBQVE7QUFBQSxFQUdSO0FBQ0EsUUFBTSxnQkFBZ0IsTUFBTSxrQkFBa0I7QUFDOUMsUUFBTSxtQkFBbUIsTUFBTSxxQkFBcUI7QUFDcEQsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0sdUJBQXVCLE1BQU0sd0JBQXdCO0FBQzNELFNBQU87QUFBQSxJQUNMLFNBQVM7QUFBQSxJQUNULFVBQVUsZUFBZSxRQUFRO0FBQUEsSUFDakMsWUFBWTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZO0FBQUEsTUFDVixRQUFRLG1CQUFtQixRQUFRLG9CQUFvQjtBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxhQUFhLGdCQUFnQixlQUFlO0FBQUEsTUFDNUMsZUFBZSxnQkFBZ0IsaUJBQWlCO0FBQUEsTUFDaEQsa0JBQWtCLGdCQUFnQixvQkFBb0I7QUFBQSxNQUN0RCx1QkFBdUIsZ0JBQWdCLHlCQUF5QjtBQUFBLE1BQ2hFLGlCQUFpQixnQkFBZ0IsbUJBQW1CO0FBQUEsTUFDcEQsZUFBZSxnQkFBZ0IsaUJBQWlCO0FBQUEsSUFDbEQ7QUFBQSxJQUNBLGNBQWM7QUFBQSxNQUNaLE9BQU87QUFBQSxNQUNQLFNBQVMsMEJBQTBCO0FBQUEsTUFDbkMsV0FBVyxhQUFhLGFBQWE7QUFBQSxNQUNyQyxnQkFBZ0IsYUFBYSxnQkFBZ0I7QUFBQSxJQUMvQztBQUFBLElBQ0EsaUJBQWlCO0FBQUEsTUFDZixPQUFPO0FBQUEsTUFDUCxTQUFTLDZCQUE2QjtBQUFBLE1BQ3RDLFdBQVcsZ0JBQWdCLGFBQWE7QUFBQSxNQUN4QyxnQkFBZ0IsZ0JBQWdCLGdCQUFnQjtBQUFBLElBQ2xEO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUF5QztBQUMvRCxTQUFPO0FBQUEsSUFDTCxPQUFPLEVBQUU7QUFBQSxJQUNULE1BQU0sRUFBRTtBQUFBLElBQ1IsUUFBUSxFQUFFO0FBQUEsSUFDVixTQUFTLEVBQUU7QUFBQSxJQUNYLGFBQWEsRUFBRTtBQUFBLElBQ2YsY0FBYyxFQUFFO0FBQUEsSUFDaEIsdUJBQXVCLEVBQUU7QUFBQSxJQUN6QixnQkFBZ0IsRUFBRTtBQUFBLElBQ2xCLFFBQVEsRUFBRSxJQUFJLFNBQVM7QUFBQSxJQUN2QixXQUFXLEVBQUUsSUFBSSxVQUFVLElBQUksRUFBRSxJQUFJLE1BQU0sRUFBRSxJQUFJO0FBQUEsRUFDbkQ7QUFDRjtBQUVBLFNBQVMscUJBQXFCLEtBQStCO0FBQzNELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVLE9BQU0sSUFBSSxNQUFNLDJCQUEyQjtBQUNoRixRQUFNLFdBQVc7QUFDakIsTUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTLFFBQVEsRUFBRyxPQUFNLElBQUksTUFBTSxtQ0FBbUM7QUFDMUYsUUFBTSxXQUF3QyxDQUFDO0FBQy9DLGFBQVcsU0FBUyxTQUFTLFVBQVU7QUFDckMsUUFBSSxDQUFDLFNBQVMsT0FBTyxVQUFVLFNBQVU7QUFDekMsVUFBTSxNQUFNO0FBQ1osVUFBTSxTQUFTLE9BQU8sSUFBSSxXQUFXLFdBQVcsSUFBSSxTQUFTO0FBQzdELFFBQUksQ0FBQyxVQUFVLFdBQVcsUUFBUztBQUNuQyxhQUFTLE9BQU8sWUFBWSxDQUFDLElBQUk7QUFBQSxNQUMvQjtBQUFBLE1BQ0EsZ0JBQWdCLE9BQU8sSUFBSSxtQkFBbUIsV0FBVyxJQUFJLGlCQUFpQjtBQUFBLE1BQzlFLG1CQUFtQixPQUFPLElBQUksc0JBQXNCLFdBQVcsSUFBSSxvQkFBb0I7QUFBQSxNQUN2RixXQUFXLE9BQU8sSUFBSSxjQUFjLFdBQVcsSUFBSSxZQUFZO0FBQUEsSUFDakU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0wsY0FBYyxPQUFPLFNBQVMsaUJBQWlCLFdBQVcsU0FBUyxlQUFlO0FBQUEsSUFDbEYsYUFBWSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ25DO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyx3QkFBd0IsR0FBbUIsVUFBMkM7QUFDN0YsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUN0QixRQUFNLFFBQVEsU0FBUyxTQUFTLEVBQUUsZUFBZSxZQUFZLENBQUM7QUFDOUQsTUFBSSxDQUFDLE9BQU8sZUFBZ0IsUUFBTztBQUNuQyxRQUFNLFNBQVMsS0FBSyxNQUFNLEVBQUUsU0FBUztBQUNyQyxRQUFNLFNBQVMsS0FBSyxNQUFNLE1BQU0sY0FBYztBQUM5QyxTQUFPLE9BQU8sU0FBUyxNQUFNLEtBQUssT0FBTyxTQUFTLE1BQU0sS0FBSyxVQUFVO0FBQ3pFO0FBRUEsU0FBUyxtQkFDUCxHQUNBLFVBQ0EsUUFDQSxZQUFnQyxPQUNoQyxTQUFrQyxZQUNuQjtBQUNmLFNBQU87QUFBQSxJQUNMLFVBQVUsRUFBRTtBQUFBLElBQ1osZ0JBQWdCLEVBQUU7QUFBQSxJQUNsQixXQUFXLEVBQUU7QUFBQSxJQUNiLE1BQU0sRUFBRSxpQkFBaUIsRUFBRTtBQUFBLElBQzNCLFlBQVksRUFBRTtBQUFBLElBQ2QsV0FBVyxFQUFFO0FBQUEsSUFDYixTQUFTO0FBQUEsSUFDVDtBQUFBLElBQ0EsZ0JBQWdCLGNBQWMsYUFBYSxVQUFVO0FBQUEsSUFDckQ7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGlCQUFpQixTQUFpQztBQUN6RCxTQUNFLE9BQU8sWUFBWSxZQUNuQiw2RUFBNkUsS0FBSyxPQUFPO0FBRTdGO0FBRUEsU0FBUyxXQUFXLEtBQXFCO0FBRXZDLFFBQU0sSUFBSSxJQUFJLEtBQUssR0FBRztBQUN0QixNQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU8sSUFBSSxRQUFRLFNBQVMsRUFBRTtBQUM3RCxRQUFNLE1BQU0sQ0FBQyxHQUFXLElBQUksTUFBTSxPQUFPLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUMzRCxTQUNFLEdBQUcsRUFBRSxlQUFlLENBQUMsSUFBSSxJQUFJLEVBQUUsWUFBWSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUNwRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7QUFFOUU7QUFFQSxTQUFTLFVBQVUsR0FBcUI7QUFDdEMsU0FBTyxXQUFXLEVBQUUsS0FBSyxjQUFjLEVBQUUsSUFBSTtBQUMvQztBQVNBLFNBQVMsZUFBZSxNQUF5QjtBQUMvQyxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1HLE9BQU07QUFDWixVQUFJLE9BQU9BLEtBQUksZUFBZSxTQUFVLE1BQUssSUFBSUEsS0FBSSxVQUFVO0FBQy9ELGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsS0FBSztBQUN4QjtBQU9BLFNBQVMsb0JBQW9CLE1BQWUsVUFBbUM7QUFDN0UsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNQSxPQUFNO0FBQ1osVUFBSUEsS0FBSSxlQUFlLFVBQVU7QUFDL0IsZUFBTyxPQUFPLEtBQUtBLElBQUcsRUFBRSxLQUFLO0FBQUEsTUFDL0I7QUFDQSxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBUUEsU0FBUyxpQkFBaUIsTUFBZSxVQUFrQixNQUF5QjtBQUNsRixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsTUFBSSxRQUF3QztBQUM1QyxTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUEsT0FBTTtBQUNaLFVBQUlBLEtBQUksZUFBZSxVQUFVO0FBQy9CLGdCQUFRQTtBQUNSO0FBQUEsTUFDRjtBQUNBLGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLE1BQUksTUFBZTtBQUNuQixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVSxRQUFPLElBQUksUUFBUSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzFGLFVBQU8sSUFBZ0MsR0FBRztBQUFBLEVBQzVDO0FBQ0EsTUFBSSxRQUFRLE9BQVcsUUFBTztBQUM5QixNQUFJLFFBQVEsS0FBTSxRQUFPO0FBQ3pCLE1BQUksT0FBTyxRQUFRLFNBQVUsUUFBTyxJQUFJLE9BQU8sR0FBRztBQUNsRCxNQUFJLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxjQUFjLElBQUksTUFBTTtBQUN2RCxTQUFPLE9BQU8sS0FBSyxHQUE4QixFQUFFLEtBQUs7QUFDMUQ7QUFFQSxTQUFTLFdBQVcsR0FBbUI7QUFHckMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLElBQUksQ0FBQztBQUN4QixVQUFNLE9BQU8sT0FBTyxZQUFZLE9BQU8sU0FBUyxZQUFPO0FBQ3ZELFdBQU8sT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTLGdCQUM5QyxPQUNBLEdBQUcsT0FBTyxJQUFJLEdBQUcsSUFBSTtBQUFBLEVBQzNCLFFBQVE7QUFDTixXQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFBQSxFQUNoRDtBQUNGO0FBS0MsV0FBdUMsZUFBZTtBQUFBLEVBQ3JEO0FBQUEsRUFDQSxVQUFVO0FBQUEsRUFDVixVQUFVO0FBQUEsRUFDVixTQUFTO0FBQUEsRUFDVCxVQUFVLE1BQU0sU0FBUyxVQUFVO0FBQUEsRUFDbkMsT0FBTztBQUFBLEVBQ1AsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsZUFBZTtBQUFBLEVBQ2YsaUJBQWlCO0FBQUEsRUFDakIsaUJBQWlCO0FBQUEsRUFDakIsa0JBQWtCO0FBQ3BCOyIsCiAgIm5hbWVzIjogWyJ0b0Jhc2U2NCIsICJvYmoiLCAiaW5mbyIsICJ0b0Jhc2U2NCIsICJ1bmF2YWlsYWJsZUNvdW50IiwgInN1ZmZpeCIsICJvYmoiXQp9Cg==
