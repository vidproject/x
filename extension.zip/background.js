// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true,
  lowBandwidthBrowsing: false
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" },
  { handle: "StephenM", label: "Stephen Miller", category: "core" },
  { handle: "GregoryKBovino", label: "Gregory Bovino", category: "core" },
  { handle: "RealTomHoman", label: "Thomas D. Homan", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  threadOpenQueue: {},
  threadOpenSeen: {},
  refetchSession: null,
  mediaCrawlSession: null,
  threadOpenSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function setArchiveSnapshot(snapshot) {
  await setRaw("archiveSnapshot", snapshot);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
var RECENT_TWEET_SIGHTINGS_MAX = 80;
async function getRecentTweetSightings() {
  return getRaw("recentTweetSightings");
}
async function prependRecentTweetSightings(rows) {
  if (rows.length === 0) return;
  const cur = await getRecentTweetSightings();
  const seen = /* @__PURE__ */ new Set();
  const next = [];
  for (const row of rows) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  for (const row of cur) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  next.length = Math.min(next.length, RECENT_TWEET_SIGHTINGS_MAX);
  await setRaw("recentTweetSightings", next);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function getThreadOpenQueue() {
  return getRaw("threadOpenQueue");
}
async function threadOpenQueueTotal() {
  const q = await getThreadOpenQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function hasThreadOpenSeen(tweetId) {
  const seen = await getRaw("threadOpenSeen");
  return tweetId in seen;
}
async function markThreadOpenSeen(tweetId) {
  const seen = await getRaw("threadOpenSeen");
  seen[tweetId] = (/* @__PURE__ */ new Date()).toISOString();
  await setRaw("threadOpenSeen", seen);
}
async function enqueueThreadOpen(handle, tweetId) {
  if (await hasThreadOpenSeen(tweetId)) return;
  const q = await getThreadOpenQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("threadOpenQueue", q);
  }
}
async function dequeueThreadOpen(tweetId) {
  const q = await getThreadOpenQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("threadOpenQueue", q);
}
async function nextThreadOpenTarget() {
  const q = await getThreadOpenQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getThreadOpenSession() {
  return getRaw("threadOpenSession");
}
async function setThreadOpenSession(s) {
  await setRaw("threadOpenSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  const tq = await getThreadOpenQueue();
  let threadOpenIdsRemoved = 0;
  for (const h of Object.keys(tq)) {
    if (!isTargeted(h)) {
      threadOpenIdsRemoved += (tq[h] ?? []).length;
      delete tq[h];
    }
  }
  await setRaw("threadOpenQueue", tq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved,
    threadOpenIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Verify the PAT can write to the configured branch without creating a
   * commit. Moving a ref to its current SHA is a no-op, but GitHub still
   * enforces the Contents: Write permission required by commitFiles().
   */
  async verifyWriteAccess() {
    const head = await this.getBranchHead();
    await this.fetchJson(
      "PATCH",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
      {
        sha: head.sha,
        force: false
      }
    );
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const unavailableTweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const unavailable = pickUnavailableTweet(raw, ctx);
      if (unavailable) {
        unavailableTweets.push(unavailable);
        observed.push(unavailable.tweet_id);
        built.add(unavailable.tweet_id);
        continue;
      }
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, unavailable_tweets: unavailableTweets, partial_ids };
}
function pickUnavailableTweet(node, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename !== "TweetTombstone") return null;
  const tweetId = strOrNull(n.rest_id) ?? pickTweetIdFromUrls(node) ?? (ctx.sourceUrl ? tweetIdFromTweetUrl(ctx.sourceUrl) : null);
  if (!tweetId || !TWEET_ID_RE.test(tweetId)) return null;
  const unavailableText = pickTombstoneText(node);
  return {
    tweet_id: tweetId,
    account_handle: pickHandleFromTweetUrls(node, tweetId) ?? (ctx.sourceUrl ? handleFromTweetUrl(ctx.sourceUrl, tweetId) : null),
    unavailable_detected_at: ctx.capturedAt,
    unavailable_reason: classifyUnavailableReason(unavailableText),
    unavailable_text: unavailableText,
    unavailable_source_url: ctx.sourceUrl ?? null
  };
}
function pickTweetIdFromUrls(node) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const id = tweetIdFromTweetUrl(cur);
      if (id) return id;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function tweetIdFromTweetUrl(rawUrl) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/[A-Za-z0-9_]{1,15}\/status\/(\d{15,20})(?:\/|$)/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
function pickTombstoneText(node) {
  const strings = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const trimmed = cur.trim();
      if (trimmed.length >= 4 && !trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
        strings.push(trimmed);
      }
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  const preferred = strings.find(
    (s) => /\b(copyright|dmca|unavailable|withheld|removed|deleted|violat|suspended)\b/i.test(s)
  );
  return preferred ?? strings[0] ?? null;
}
function classifyUnavailableReason(text) {
  if (!text) return null;
  if (/\b(copyright|dmca)\b/i.test(text)) return "copyright";
  if (/\bwithheld\b/i.test(text)) return "withheld";
  if (/\bdeleted|removed\b/i.test(text)) return "removed";
  if (/\bsuspended\b/i.test(text)) return "suspended";
  if (/\bunavailable|not available\b/i.test(text)) return "unavailable";
  return null;
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  const hintHandle = pickHintHandle(node, restId);
  if (!hintHandle) return null;
  return { tweet_id: restId, hint_handle: hintHandle };
}
function pickHintHandle(node, tweetId) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name) ?? pickHandleFromTweetUrls(node, tweetId);
}
function pickHandleFromTweetUrls(node, tweetId) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const handle = handleFromTweetUrl(cur, tweetId);
      if (handle) return handle;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function handleFromTweetUrl(rawUrl, tweetId) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d{15,20})(?:\/|$)/);
    if (!match || match[2] !== tweetId) return null;
    return match[1] ?? null;
  } catch {
    return null;
  }
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    unavailable_detected_at: null,
    unavailable_reason: null,
    unavailable_text: null,
    unavailable_source_url: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted, coreHandles = /* @__PURE__ */ new Set()) {
  if (targeted.size === 0 && coreHandles.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (coreHandles.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
var MANUAL_CAPTURE_WINDOW_MS = 9e4;
var LOW_BANDWIDTH_RULE_ID = 760001;
var LOW_BANDWIDTH_RESOURCE_TYPES = ["image", "media", "font"];
var manualCaptureUntilMs = 0;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
function allowManualCaptureWindow() {
  manualCaptureUntilMs = Date.now() + MANUAL_CAPTURE_WINDOW_MS;
}
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await syncLowBandwidthRules({ reason: `wake:${reason}`, log: false });
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
function dnrApi() {
  const maybeBrowser = browser;
  return maybeBrowser.declarativeNetRequest ?? null;
}
async function currentXTabIds() {
  const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  return tabs.flatMap((tab) => typeof tab.id === "number" ? [tab.id] : []);
}
async function syncLowBandwidthRules({
  reason,
  log
}) {
  const settings = await getSettings();
  const dnr = dnrApi();
  if (!dnr) {
    if (settings.lowBandwidthBrowsing && log) {
      await warn("low-bandwidth browsing unavailable; declarativeNetRequest API missing", {
        reason
      });
    }
    return;
  }
  const tabIds = settings.lowBandwidthBrowsing ? await currentXTabIds() : [];
  const addRules = tabIds.length > 0 ? [
    {
      id: LOW_BANDWIDTH_RULE_ID,
      priority: 1,
      action: { type: "block" },
      condition: {
        tabIds,
        resourceTypes: [...LOW_BANDWIDTH_RESOURCE_TYPES]
      }
    }
  ] : [];
  await dnr.updateSessionRules({
    removeRuleIds: [LOW_BANDWIDTH_RULE_ID],
    addRules
  });
  if (log) {
    await info("low-bandwidth browsing rules updated", {
      enabled: settings.lowBandwidthBrowsing,
      tab_count: tabIds.length,
      blocked_resource_types: LOW_BANDWIDTH_RESOURCE_TYPES.join(","),
      reason
    });
  }
}
browser.tabs.onUpdated.addListener((_tabId, changeInfo) => {
  if (changeInfo.url || changeInfo.status === "complete") {
    void syncLowBandwidthRules({ reason: "tab-updated", log: false }).catch((err) => {
      void warn("low-bandwidth rule refresh failed", describeError(err));
    });
  }
});
browser.tabs.onRemoved.addListener(() => {
  void syncLowBandwidthRules({ reason: "tab-removed", log: false }).catch((err) => {
    void warn("low-bandwidth rule refresh failed", describeError(err));
  });
});
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var SHOW_MORE_RELEVANCE_TTL_MS = 10 * 60 * 1e3;
var showMoreRelevantTweetsByTab = /* @__PURE__ */ new Map();
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  allowManualCaptureWindow();
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    ingestedNewCount: 0,
    ingestedExistingCount: 0,
    skippedOldCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: () => {
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
        }
      });
      scrollCount += 1;
    } catch {
    }
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      await setAutoScrollSession(sess);
    }
  }
}
function pruneShowMoreRelevance() {
  const cutoff = Date.now() - SHOW_MORE_RELEVANCE_TTL_MS;
  for (const [tabId, entry] of showMoreRelevantTweetsByTab) {
    if (entry.updatedAt < cutoff) showMoreRelevantTweetsByTab.delete(tabId);
  }
}
function rememberShowMoreRelevantTweets(tabId, pageUrl, tweets, coreHandles) {
  if (tabId === null || tweets.length === 0 || coreHandles.size === 0) return;
  const coreTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (coreHandles.has(t.account_handle.toLowerCase())) coreTweetIds.add(t.tweet_id);
  }
  const existing = showMoreRelevantTweetsByTab.get(tabId);
  const tweetIds = existing?.tweetIds ?? /* @__PURE__ */ new Set();
  for (const t of tweets) {
    const handle = t.account_handle.toLowerCase();
    const replyHandle = t.reply_to_account?.toLowerCase() ?? null;
    if (coreHandles.has(handle) || replyHandle !== null && coreHandles.has(replyHandle) || t.reply_to_tweet_id !== null && coreTweetIds.has(t.reply_to_tweet_id) || t.quoted_tweet_id !== null && coreTweetIds.has(t.quoted_tweet_id) || t.retweeted_tweet_id !== null && coreTweetIds.has(t.retweeted_tweet_id)) {
      tweetIds.add(t.tweet_id);
    }
  }
  showMoreRelevantTweetsByTab.set(tabId, {
    updatedAt: Date.now(),
    pageUrl,
    tweetIds
  });
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg, sender).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-thread-open",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg, sender) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(
        msg.endpoint,
        msg.url,
        msg.pageUrl ?? null,
        msg.response,
        sender?.tab?.id ?? null
      );
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-unfold-targets": {
      const settings = await getSettings();
      if (settings.enabled === false) {
        return { enabled: false, coreHandles: [], relevantTweetIds: [] };
      }
      pruneShowMoreRelevance();
      const accounts = await getAccounts();
      const coreHandles = accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase());
      const tabId = sender?.tab?.id ?? null;
      return {
        enabled: true,
        coreHandles,
        relevantTweetIds: tabId === null ? [] : Array.from(showMoreRelevantTweetsByTab.get(tabId)?.tweetIds ?? [])
      };
    }
    case "show-more-unfolded": {
      if (msg.count > 0) {
        const asSess = await getAutoScrollSession();
        if (asSess !== null) {
          asSess.expandedCount += msg.count;
          await setAutoScrollSession(asSess);
        }
      }
      return { ok: true };
    }
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-update-existing":
      await updateSettings({ updateExisting: msg.on });
      await info("update-existing toggled", { on: msg.on });
      return buildState();
    case "toggle-low-bandwidth":
      await updateSettings({ lowBandwidthBrowsing: msg.on });
      await syncLowBandwidthRules({ reason: "toggle", log: true });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        stopThreadOpenInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
        await browser.alarms.clear("thread-open-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      if (threadOpenIntervalHandle !== null) startThreadOpenInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "start-thread-open":
      await startThreadOpenLoop();
      return buildState();
    case "cancel-thread-open":
      await cancelThreadOpenLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, pageUrl, response, senderTabId) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const settings = await getSettings();
  if (settings.enabled === false) return;
  if (settings.autoCapture === false) {
    const explicitCaptureActive = Date.now() < manualCaptureUntilMs || await getAutoScrollSession() !== null || await getRefetchSession() !== null || await getMediaCrawlSession() !== null;
    if (!explicitCaptureActive) return;
  }
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const core = new Set(
    accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase())
  );
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set(),
      sourceUrl: pageUrl
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const retweetEdges = buildRetweetEdges(
    normalized.tweets,
    accounts,
    capturedAt,
    endpoint,
    pageUrl ?? url
  );
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked, core);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  rememberShowMoreRelevantTweets(senderTabId, pageUrl, normalized.tweets, core);
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.unavailable_tweets.length > 0) {
    await recordUnavailableTweets(
      normalized.unavailable_tweets,
      tracked,
      capturedAt,
      url,
      endpoint
    );
  }
  if (normalized.tweets.length === 0) {
    const bufferedEdges = await bufferRetweetEdges(
      retweetEdges,
      capturedAt,
      pageUrl ?? url,
      endpoint
    );
    if (bufferedEdges > 0) await broadcastState();
    return;
  }
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    if (threadOpenSess?.inflight?.tweetId === t.tweet_id) {
      threadOpenSess.inflight = null;
      threadOpenSess.processed += 1;
      await markThreadOpenSeen(t.tweet_id);
      await dequeueThreadOpen(t.tweet_id);
      await setThreadOpenSession(threadOpenSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const updateExisting = settings.updateExisting !== false;
  const committedIdx = await getCommittedIndex();
  const archiveSnapshot = await getArchiveSnapshot();
  let dedupedSkipped = 0;
  let skippedNoUpdateLocal = 0;
  let skippedNoUpdateSnapshot = 0;
  let oldFromSnapshot = 0;
  let fullTextUpgrades = 0;
  const liveTweets = [];
  const freshnessById = /* @__PURE__ */ new Map();
  const actionById = /* @__PURE__ */ new Map();
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const oldBySnapshot = !prev && archiveSnapshotHasTweet(t, archiveSnapshot);
    const previouslyArchived = Boolean(prev) || oldBySnapshot;
    freshnessById.set(t.tweet_id, previouslyArchived ? "existing" : "new");
    if (oldBySnapshot) oldFromSnapshot += 1;
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    const fullTextUpgrade = prev !== void 0 && sigMarksTruncated(prev.sig) && !t.is_truncated;
    if (previouslyArchived && !updateExisting && !fullTextUpgrade) {
      if (prev) skippedNoUpdateLocal += 1;
      else skippedNoUpdateSnapshot += 1;
      actionById.set(t.tweet_id, "skipped");
      continue;
    }
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      actionById.set(t.tweet_id, "unchanged");
      continue;
    }
    if (fullTextUpgrade) fullTextUpgrades += 1;
    actionById.set(t.tweet_id, "buffered");
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (skippedNoUpdateLocal + skippedNoUpdateSnapshot > 0) {
    const skippedOld = skippedNoUpdateLocal + skippedNoUpdateSnapshot;
    await info("dedup: skipped previously archived tweets (updateExisting=false)", {
      endpoint,
      skipped: skippedOld,
      local_index: skippedNoUpdateLocal,
      archive_snapshot: skippedNoUpdateSnapshot,
      remaining: liveTweets.length
    });
    const asSess = await getAutoScrollSession();
    if (asSess !== null) {
      asSess.skippedOldCount = (asSess.skippedOldCount ?? 0) + skippedOld;
      await setAutoScrollSession(asSess);
    }
  }
  if (oldFromSnapshot > 0 && updateExisting) {
    await info("archive snapshot recognized old tweets", {
      endpoint,
      old: oldFromSnapshot,
      action: "buffering because updateExisting=true",
      snapshot_generated_at: archiveSnapshot?.generated_at ?? null
    });
  }
  if (fullTextUpgrades > 0) {
    await info("dedup: buffering full-text upgrades", {
      endpoint,
      upgrades: fullTextUpgrades,
      updateExisting,
      remaining: liveTweets.length
    });
  }
  await prependRecentTweetSightings(
    normalized.tweets.map(
      (t) => buildTweetSighting(
        t,
        endpoint,
        capturedAt,
        freshnessById.get(t.tweet_id),
        actionById.get(t.tweet_id)
      )
    )
  );
  await enqueueMissingParents(normalized.tweets, endpoint);
  await enqueueThreadOpenCandidates(normalized.tweets, core, endpoint);
  const bufferedRetweetEdges = await bufferRetweetEdges(
    retweetEdges,
    capturedAt,
    pageUrl ?? url,
    endpoint
  );
  if (liveTweets.length === 0) {
    if (bufferedRetweetEdges > 0) await broadcastState();
    return;
  }
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    let addedNew = 0;
    let addedExisting = 0;
    let updatedBuffered = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
        updatedBuffered += 1;
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
        if (freshnessById.get(t.tweet_id) === "existing") addedExisting += 1;
        else addedNew += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    if (added > 0 || updatedBuffered > 0) {
      await info("buffered tweets", {
        handle,
        endpoint,
        added,
        new: addedNew,
        existing: addedExisting,
        updated_buffered: updatedBuffered,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        asSess.ingestedNewCount = (asSess.ingestedNewCount ?? 0) + addedNew;
        asSess.ingestedExistingCount = (asSess.ingestedExistingCount ?? 0) + addedExisting;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function recordUnavailableTweets(unavailableTweets, tracked, capturedAt, sourceUrl, endpoint) {
  const committedIdx = await getCommittedIndex();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  let recorded = 0;
  let skipped = 0;
  let missingHandle = 0;
  for (const u of unavailableTweets) {
    const handle = u.account_handle;
    if (!handle) {
      missingHandle += 1;
      await dequeueMediaCrawl(u.tweet_id);
      await dequeueThreadOpen(u.tweet_id);
      continue;
    }
    if (tracked.size > 0 && !tracked.has(handle.toLowerCase())) {
      skipped += 1;
      continue;
    }
    await dequeueMediaCrawl(u.tweet_id);
    await dequeueRefetch(handle, u.tweet_id);
    await dequeueThreadOpen(u.tweet_id);
    if (refetchSess?.inflight?.tweetId === u.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === u.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    if (threadOpenSess?.inflight?.tweetId === u.tweet_id) {
      threadOpenSess.inflight = null;
      threadOpenSess.processed += 1;
      await markThreadOpenSeen(u.tweet_id);
      await setThreadOpenSession(threadOpenSess);
    }
    const sig = unavailableSig(u);
    const prev = committedIdx[handle]?.[u.tweet_id];
    if (prev?.sig === sig) {
      skipped += 1;
      continue;
    }
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const unavailableById = buf.unavailable_by_id ?? {};
    unavailableById[u.tweet_id] = u;
    buf.unavailable_by_id = unavailableById;
    if (!buf.tweet_ids_observed.includes(u.tweet_id)) {
      buf.tweet_ids_observed.push(u.tweet_id);
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    recorded += 1;
  }
  if (recorded > 0 || missingHandle > 0 || skipped > 0) {
    await info("unavailable tweets observed", { endpoint, recorded, skipped, missingHandle });
  }
  await broadcastState();
}
function unavailableSig(u) {
  return `unavailable|${u.unavailable_reason ?? ""}|${u.unavailable_text ?? ""}`;
}
function sigMarksTruncated(sig) {
  const parts = sig.split("|");
  return parts[parts.length - 1] === "t";
}
function runBufferItemCount(buf) {
  return Object.keys(buf.tweets_by_id).length + Object.keys(buf.unavailable_by_id ?? {}).length + Object.keys(buf.retweet_edges_by_key ?? {}).length;
}
function retweetEdgeKey(edge) {
  return [edge.retweeter_handle.toLowerCase(), edge.retweet_tweet_id, edge.original_tweet_id].join(
    "|"
  );
}
function inferRetweetedHandle(text) {
  const match = text.match(/^RT\s+@([A-Za-z0-9_]{1,15})\b/i);
  return match?.[1] ?? null;
}
function buildRetweetEdges(tweets, accounts, capturedAt, endpoint, sourceUrl) {
  const categoryByHandle = new Map(accounts.map((a) => [a.handle.toLowerCase(), a.category]));
  const byId = new Map(tweets.map((t) => [t.tweet_id, t]));
  const out = /* @__PURE__ */ new Map();
  for (const t of tweets) {
    if (t.tweet_type !== "retweet" || !t.retweeted_tweet_id) continue;
    const retweeterCategory = categoryByHandle.get(t.account_handle.toLowerCase());
    if (!retweeterCategory) continue;
    const original = byId.get(t.retweeted_tweet_id);
    const originalHandle = original?.account_handle ?? inferRetweetedHandle(t.text_resolved || t.text);
    const originalCategory = originalHandle ? categoryByHandle.get(originalHandle.toLowerCase()) ?? "public" : null;
    const edge = {
      retweeter_handle: t.account_handle,
      retweeter_account_id: t.account_id ?? null,
      retweeter_category: retweeterCategory,
      retweet_tweet_id: t.tweet_id,
      retweet_url: t.tweet_url,
      original_tweet_id: t.retweeted_tweet_id,
      original_author_handle: originalHandle,
      original_author_account_id: original?.account_id ?? null,
      original_author_category: originalCategory,
      captured_at: capturedAt,
      capture_run_id: "pending",
      endpoint,
      source_url: sourceUrl
    };
    out.set(retweetEdgeKey(edge), edge);
  }
  return [...out.values()];
}
async function bufferRetweetEdges(edges, capturedAt, sourceUrl, endpoint) {
  if (edges.length === 0) return 0;
  const byHandle = /* @__PURE__ */ new Map();
  for (const edge of edges) {
    const arr = byHandle.get(edge.retweeter_handle) ?? [];
    arr.push(edge);
    byHandle.set(edge.retweeter_handle, arr);
  }
  let added = 0;
  for (const [handle, handleEdges] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const edgeMap = buf.retweet_edges_by_key ?? {};
    let addedForHandle = 0;
    for (const edge of handleEdges) {
      const stamped = { ...edge, capture_run_id: buf.run_id };
      const key = retweetEdgeKey(stamped);
      if (!edgeMap[key]) addedForHandle += 1;
      edgeMap[key] = stamped;
      if (!buf.tweet_ids_observed.includes(stamped.retweet_tweet_id)) {
        buf.tweet_ids_observed.push(stamped.retweet_tweet_id);
      }
      if (!buf.tweet_ids_observed.includes(stamped.original_tweet_id)) {
        buf.tweet_ids_observed.push(stamped.original_tweet_id);
      }
    }
    if (addedForHandle === 0) continue;
    buf.retweet_edges_by_key = edgeMap;
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    added += addedForHandle;
    await info("buffered retweet edges", {
      handle,
      endpoint,
      added: addedForHandle,
      total: Object.keys(edgeMap).length
    });
  }
  return added;
}
async function enqueueMissingParents(tweets, endpoint) {
  if (tweets.length === 0) return;
  const sameBatchIds = /* @__PURE__ */ new Set();
  for (const t of tweets) sameBatchIds.add(t.tweet_id);
  let enqueued = 0;
  for (const t of tweets) {
    const parents = [];
    if (t.reply_to_tweet_id) {
      parents.push({ id: t.reply_to_tweet_id, hint: t.reply_to_account });
    }
    if (t.quoted_tweet_id) parents.push({ id: t.quoted_tweet_id, hint: null });
    if (t.retweeted_tweet_id) parents.push({ id: t.retweeted_tweet_id, hint: null });
    for (const p of parents) {
      if (sameBatchIds.has(p.id)) continue;
      if (await isCommitted(p.id)) continue;
      await enqueueMediaCrawl(p.hint, p.id);
      enqueued += 1;
    }
  }
  if (enqueued > 0) {
    await info("queued missing parent tweets for detail-page crawl", {
      endpoint,
      enqueued,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
}
async function enqueueThreadOpenCandidates(tweets, coreHandles, endpoint) {
  if (tweets.length === 0 || coreHandles.size === 0) return;
  if (endpoint.includes("TweetDetail") || endpoint.includes("TweetResultByRestId")) return;
  const candidates = /* @__PURE__ */ new Map();
  for (const t of tweets) {
    const handle = t.account_handle.toLowerCase();
    if (!coreHandles.has(handle)) continue;
    const rootId = t.conversation_id ?? t.tweet_id;
    const isRoot = rootId === t.tweet_id || t.reply_to_tweet_id === null;
    const isCoreReply = t.reply_to_tweet_id !== null;
    if (isRoot && t.reply_count > 0) {
      candidates.set(rootId, t.account_handle);
    } else if (isCoreReply && rootId) {
      candidates.set(rootId, t.account_handle);
    }
  }
  let enqueued = 0;
  for (const [tweetId, handle] of candidates) {
    const before = await threadOpenQueueTotal();
    await enqueueThreadOpen(handle, tweetId);
    const after = await threadOpenQueueTotal();
    if (after > before) enqueued += 1;
  }
  if (enqueued > 0) {
    await info("queued core thread roots for opening", {
      endpoint,
      enqueued,
      queue_total: await threadOpenQueueTotal()
    });
  }
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    unavailable_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    const unavailableTweets = Object.values(buf.unavailable_by_id ?? {});
    const retweetEdges = Object.values(buf.retweet_edges_by_key ?? {});
    if (tweets.length === 0 && unavailableTweets.length === 0 && retweetEdges.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets, unavailableTweets, retweetEdges));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("upload buffer deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length + item.unavailableTweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length + item.unavailableTweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      for (const u of item.unavailableTweets) {
        inner[u.tweet_id] = {
          ts: nowIso,
          sig: unavailableSig(u)
        };
      }
      idx[item.handle] = inner;
      await info("upload buffer committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        unavailable: item.unavailableTweets.length,
        retweet_edges: item.retweetEdges.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("upload buffer batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      unavailable: items.reduce((total, item) => total + item.unavailableTweets.length, 0),
      retweet_edges: items.reduce((total, item) => total + item.retweetEdges.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("upload buffer failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("upload buffer failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets, unavailableTweets, retweetEdges) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    unavailableTweets,
    retweetEdges,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets,
      unavailable_tweets: unavailableTweets,
      retweet_edges: retweetEdges
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    const unavailableCount2 = item.unavailableTweets.length;
    const edgeCount2 = item.retweetEdges.length;
    const suffix2 = (unavailableCount2 > 0 ? `, ${unavailableCount2} unavailable` : "") + (edgeCount2 > 0 ? `, ${edgeCount2} retweet edge${edgeCount2 === 1 ? "" : "s"}` : "");
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"}${suffix2} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  const unavailableCount = items.reduce((total, item) => total + item.unavailableTweets.length, 0);
  const edgeCount = items.reduce((total, item) => total + item.retweetEdges.length, 0);
  const suffix = (unavailableCount > 0 ? `, ${unavailableCount} unavailable` : "") + (edgeCount > 0 ? `, ${edgeCount} retweet edge${edgeCount === 1 ? "" : "s"}` : "");
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"}${suffix} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return runBufferItemCount(current);
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  for (const u of item.unavailableTweets) {
    committed.set(u.tweet_id, unavailableSig(u));
  }
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingUnavailable = {};
  for (const [tweetId, unavailable] of Object.entries(current.unavailable_by_id ?? {})) {
    const committedSig = committed.get(tweetId);
    const currentSig = unavailableSig(unavailable);
    if (!committedSig || committedSig !== currentSig) {
      remainingUnavailable[tweetId] = { ...unavailable };
    }
  }
  const remainingRetweetEdges = {};
  for (const [key, edge] of Object.entries(current.retweet_edges_by_key ?? {})) {
    if (!item.retweetEdges.some((committedEdge) => retweetEdgeKey(committedEdge) === key)) {
      remainingRetweetEdges[key] = { ...edge };
    }
  }
  const remainingIds = /* @__PURE__ */ new Set([
    ...Object.keys(remainingTweets),
    ...Object.keys(remainingUnavailable),
    ...Object.values(remainingRetweetEdges).flatMap((edge) => [
      edge.retweet_tweet_id,
      edge.original_tweet_id
    ])
  ]);
  const remainingCount = Object.keys(remainingTweets).length + Object.keys(remainingUnavailable).length + Object.keys(remainingRetweetEdges).length;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  for (const edge of Object.values(remainingRetweetEdges)) {
    edge.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    unavailable_by_id: remainingUnavailable,
    retweet_edges_by_key: remainingRetweetEdges,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => remainingIds.has(id))
  });
  await info("upload buffer kept newer tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  allowManualCaptureWindow();
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      unavailable_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  allowManualCaptureWindow();
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  allowManualCaptureWindow();
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  allowManualCaptureWindow();
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = target.bucket === "_unknown" ? `https://x.com/i/web/status/${target.tweetId}` : `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
var THREAD_OPEN_TAB_KEY = "__imm_archive_thread_open_tab_id__";
async function getThreadOpenTabId() {
  const stored = await browser.storage.local.get(THREAD_OPEN_TAB_KEY);
  const id = stored[THREAD_OPEN_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setThreadOpenTabId(id) {
  if (id === null) await browser.storage.local.remove(THREAD_OPEN_TAB_KEY);
  else await browser.storage.local.set({ [THREAD_OPEN_TAB_KEY]: id });
}
async function startThreadOpenLoop() {
  allowManualCaptureWindow();
  const total = await threadOpenQueueTotal();
  if (total === 0) {
    await info("thread-open: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setThreadOpenSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startThreadOpenInterval(seconds);
  void threadOpenTick();
  await info("thread-open loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var threadOpenIntervalHandle = null;
function startThreadOpenInterval(seconds) {
  if (threadOpenIntervalHandle !== null) clearInterval(threadOpenIntervalHandle);
  threadOpenIntervalHandle = setInterval(() => {
    void threadOpenTick().catch((err) => {
      void warn("thread-open tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopThreadOpenInterval() {
  if (threadOpenIntervalHandle !== null) {
    clearInterval(threadOpenIntervalHandle);
    threadOpenIntervalHandle = null;
  }
}
async function cancelThreadOpenLoop() {
  stopThreadOpenInterval();
  await browser.alarms.clear("thread-open-tick");
  const tabId = await getThreadOpenTabId();
  await setThreadOpenTabId(null);
  const sess = await getThreadOpenSession();
  await setThreadOpenSession(null);
  await info("thread-open loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function threadOpenTick() {
  let sess = await getThreadOpenSession();
  if (sess === null) {
    stopThreadOpenInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) return;
    await warn("thread-open: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await markThreadOpenSeen(sess.inflight.tweetId);
    await dequeueThreadOpen(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
  }
  const target = await nextThreadOpenTarget();
  if (!target) {
    stopThreadOpenInterval();
    await setThreadOpenTabId(null);
    await setThreadOpenSession(null);
    await info("thread-open loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await hasThreadOpenSeen(target.tweetId)) {
    await dequeueThreadOpen(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getThreadOpenTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id !== "number") throw new Error("created tab without id");
      tabId = tab.id;
      await setThreadOpenTabId(tabId);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    await markThreadOpenSeen(target.tweetId);
    sess = await getThreadOpenSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setThreadOpenSession(sess);
    if (tabId !== null) {
      void nudgeThreadOpenTab(tabId);
    }
    await info("thread-open tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await threadOpenQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("thread-open navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await markThreadOpenSeen(target.tweetId);
    await dequeueThreadOpen(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
  }
  await broadcastState();
}
async function nudgeThreadOpenTab(tabId) {
  await new Promise((resolve) => setTimeout(resolve, 1500));
  try {
    await browser.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        const step = () => window.scrollBy({ top: h * 1.3, behavior: "smooth" });
        step();
        setTimeout(step, 1400);
        setTimeout(step, 2800);
      }
    });
  } catch (err) {
    await warn("thread-open scroll-nudge failed", describeError(err));
  }
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    const checkWrite = force || isWriteAuthError(conn.error);
    if (branchOk && checkWrite) {
      await client.verifyWriteAccess();
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk,
      write_access: checkWrite ? "checked" : "not_checked"
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await refreshArchiveSnapshot(client, force);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function refreshArchiveSnapshot(client, force) {
  const text = await client.fetchRawText("data/manifest.json");
  if (!text) {
    await setArchiveSnapshot(null);
    if (force) await warn("archive manifest not found; old-tweet detection disabled");
    return;
  }
  try {
    const snapshot = parseArchiveSnapshot(JSON.parse(text));
    await setArchiveSnapshot(snapshot);
    if (force) {
      await info("archive snapshot refreshed", {
        accounts: Object.keys(snapshot.accounts).length,
        generated_at: snapshot.generated_at
      });
    }
  } catch (err) {
    await warn("archive snapshot parse failed; old-tweet detection disabled", describeError(err));
  }
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const threadOpenQueued = await threadOpenQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  const autoScrollSess = await getAutoScrollSession();
  const recentTweetSightings = await getRecentTweetSightings();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      ingestedNewCount: autoScrollSess?.ingestedNewCount ?? 0,
      ingestedExistingCount: autoScrollSess?.ingestedExistingCount ?? 0,
      skippedOldCount: autoScrollSess?.skippedOldCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    },
    threadOpenQueue: {
      total: threadOpenQueued,
      running: threadOpenIntervalHandle !== null,
      processed: threadOpenSess?.processed ?? 0,
      total_at_start: threadOpenSess?.totalAtStart ?? 0
    },
    recentTweetSightings
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    updateExisting: s.updateExisting,
    lowBandwidthBrowsing: s.lowBandwidthBrowsing,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function parseArchiveSnapshot(raw) {
  if (!raw || typeof raw !== "object") throw new Error("manifest is not an object");
  const manifest = raw;
  if (!Array.isArray(manifest.accounts)) throw new Error("manifest.accounts is not an array");
  const accounts = {};
  for (const entry of manifest.accounts) {
    if (!entry || typeof entry !== "object") continue;
    const row = entry;
    const handle = typeof row.handle === "string" ? row.handle : "";
    if (!handle || handle === "_misc") continue;
    accounts[handle.toLowerCase()] = {
      handle,
      latest_post_at: typeof row.latest_post_at === "string" ? row.latest_post_at : null,
      latest_capture_at: typeof row.latest_capture_at === "string" ? row.latest_capture_at : null,
      row_count: typeof row.row_count === "number" ? row.row_count : null
    };
  }
  return {
    generated_at: typeof manifest.generated_at === "string" ? manifest.generated_at : null,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    accounts
  };
}
function archiveSnapshotHasTweet(t, snapshot) {
  if (!snapshot) return false;
  const entry = snapshot.accounts[t.account_handle.toLowerCase()];
  if (!entry?.latest_post_at) return false;
  const posted = Date.parse(t.posted_at);
  const latest = Date.parse(entry.latest_post_at);
  return Number.isFinite(posted) && Number.isFinite(latest) && posted <= latest;
}
function buildTweetSighting(t, endpoint, seenAt, freshness = "new", action = "buffered") {
  return {
    tweet_id: t.tweet_id,
    account_handle: t.account_handle,
    posted_at: t.posted_at,
    text: t.text_resolved || t.text,
    tweet_type: t.tweet_type,
    tweet_url: t.tweet_url,
    seen_at: seenAt,
    endpoint,
    archive_status: freshness === "existing" ? "saved" : "new",
    action
  };
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop,
  threadOpenQueue: getThreadOpenQueue,
  startThreadOpen: startThreadOpenLoop,
  cancelThreadOpen: cancelThreadOpenLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHBhdDogJycsXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXG4gIHJlcG86ICd4JyxcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxuICBicmFuY2g6ICdtYXN0ZXInLFxuICBlbmFibGVkOiB0cnVlLFxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcbiAgY29uZmlndXJlZEF0OiBudWxsLFxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXG4gIHVwZGF0ZUV4aXN0aW5nOiB0cnVlLFxuICBsb3dCYW5kd2lkdGhCcm93c2luZzogZmFsc2UsXG59O1xuXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xuXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1N0ZXBoZW5NJywgbGFiZWw6ICdTdGVwaGVuIE1pbGxlcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdHcmVnb3J5S0JvdmlubycsIGxhYmVsOiAnR3JlZ29yeSBCb3Zpbm8nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUmVhbFRvbUhvbWFuJywgbGFiZWw6ICdUaG9tYXMgRC4gSG9tYW4nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG5dO1xuXG4vLyBHcmFwaFFMIGVuZHBvaW50IG5hbWVzIHdlIGNhcmUgYWJvdXQgKG1hdGNoZWQgYnkgc3Vic3RyaW5nIGFnYWluc3QgVVJMIHBhdGgpLlxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG4gICdMaWtlcycsXG4gICdCb29rbWFya3MnLFxuICAnSG9tZVRpbWVsaW5lJyxcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXG4gICdTZWFyY2hUaW1lbGluZScsXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxuXSk7XG5cbi8vIEVuZHBvaW50cyB0aGF0IGNhcnJ5IENvbW11bml0eSBOb3RlIGJvZGllcyBcdTIwMTQgY2FwdHVyZWQgZm9yIGNvbXBsZXRlbmVzcyBidXRcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXG5leHBvcnQgY29uc3QgQklSRFdBVENIX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnQmlyZHdhdGNoRmV0Y2hPbmVOb3RlJyxcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxuXSk7XG5cbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxuLy8gdG8gbGVhcm4gYWNjb3VudF9pZCA8LT4gaGFuZGxlIGJpbmRpbmdzKS5cbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcblxuLy8gRW5kcG9pbnRzIHdob3NlIHJlc3BvbnNlcyBhcmUgc2NvcGVkIHRvIGEgcGFydGljdWxhciBhY2NvdW50IG9yXG4vLyBjb252ZXJzYXRpb24gXHUyMDE0IGkuZS4gdmlzaXRpbmcgYC88aGFuZGxlPmAgLyBgLzxoYW5kbGU+L3dpdGhfcmVwbGllc2AsXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcbi8vIGVpdGhlciBhdXRob3JlZCBieSB0aGUgdHJhY2tlZCBhY2NvdW50IG9yIGRpcmVjdGx5IHJlZmVyZW5jZWQgYnkgdGhlbVxuLy8gKHJldHdlZXRlZCwgcXVvdGVkLCByZXBsaWVkIHRvKSwgc28gd2Uga2VlcCBldmVyeXRoaW5nIHdlIHNlZSByYXRoZXJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcbi8vIGFjY291bnQgc3RpbGwgZ2V0cyBpdHMgb3JpZ2luYWwtdHdlZXQgY29udGVudCBhcmNoaXZlZC5cbi8vXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcbi8vIHN0aWxsIGdldCBmaWx0ZXJlZCB0byB0cmFja2VkLWhhbmRsZSBhdXRob3JzIFx1MjAxNCBzZWUgdGhlIHNwZWMnc1xuLy8gXCJCcm93c2luZyBteSBob21lIHRpbWVsaW5lIGlzIGlnbm9yZWRcIiBydWxlLlxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuXSk7XG5cbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxuZXhwb3J0IGNvbnN0IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCA9IDIwMDtcblxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxuZXhwb3J0IGNvbnN0IEZMVVNIX0lETEVfTVMgPSA0NV8wMDA7XG5cbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxuZXhwb3J0IGNvbnN0IEZMVVNIX0FMQVJNX01JTlVURVMgPSAxO1xuXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXG5leHBvcnQgY29uc3QgQUNUSVZJVFlfVEFJTF9NQVggPSAyNTA7XG5cbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cbmV4cG9ydCBjb25zdCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyA9IDEwICogNjAgKiAxMDAwO1xuXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcbiIsICIvKipcbiAqIGNyeXB0by50cyBcdTIwMTQgYXQtcmVzdCBlbmNyeXB0aW9uIGZvciBzZW5zaXRpdmUgc2V0dGluZ3MgKHRoZSBQQVQpLlxuICpcbiAqIFRocmVhdCBtb2RlbDogYW4gYXR0YWNrZXIgd2hvIHJlYWRzIGBicm93c2VyLnN0b3JhZ2UubG9jYWxgIChkZXZ0b29scywgYVxuICogZm9yZ290dGVuIGJhY2t1cCwgYSBtaXNjb25maWd1cmVkIHByb2ZpbGUgc3luYykgc2hvdWxkIG5vdCBzZWUgYSB1c2FibGVcbiAqIEdpdEh1YiBQQVQgaW4gcGxhaW50ZXh0LiBBIGRldGVybWluZWQgYXR0YWNrZXIgd2l0aCB0aGUgZXh0ZW5zaW9uJ3Mgc291cmNlXG4gKiBjYW4gc3RpbGwgZGVyaXZlIHRoZSBrZXkgXHUyMDE0IHdlIG1ha2Ugbm8gY2xhaW0gb2YgXCJyZWFsXCIgY3J5cHRvZ3JhcGhpY1xuICogY29uZmlkZW50aWFsaXR5LiBUaGUgYWltIGlzIHRvIHJhaXNlIHRoZSBiYXIgc28gdGhlIFBBVCBpc24ndCBhIGNvcHlhYmxlXG4gKiBzdHJpbmcgc2l0dGluZyBuZXh0IHRvIGl0cyBrZXkgbmFtZSBpbiBleHRlbnNpb24gc3RvcmFnZS5cbiAqXG4gKiBTY2hlbWU6XG4gKiAgIC0gT24gZmlyc3QgZW5jcnlwdGlvbiB3ZSBnZW5lcmF0ZSBhIDMyLWJ5dGUgc2FsdCBhbmQgcGVyc2lzdCBpdCBpblxuICogICAgIGBicm93c2VyLnN0b3JhZ2UubG9jYWxgIHVuZGVyIGBfX2ltbV9hcmNoaXZlX3NhbHRfX2AuXG4gKiAgIC0gV2UgZGVyaXZlIGFuIEFFUy1HQ00ga2V5IGJ5IFNIQS0yNTYnaW5nIGBzYWx0IHx8IHJ1bnRpbWUuaWQgfHwgdmVyc2lvblxuICogICAgIHx8IFwiaW1tLWFyY2hpdmUtcGF0LXYxXCJgLiBUaGUgc2FsdCBiZWluZyBwZXItaW5zdGFsbCBtZWFucyB0d28gY29waWVzXG4gKiAgICAgb2YgdGhlIGV4dGVuc2lvbiBkb24ndCBzaGFyZSBhIGtleS4gVGhlIHJ1bnRpbWUuaWQgaXMgdGhlIGV4dGVuc2lvbidzXG4gKiAgICAgVVVJRCBcdTIwMTQgc3RhYmxlIGZvciBhIGdpdmVuIGluc3RhbGwgYnV0IHVua25vd24gdG8gYSByZW1vdGUgYXR0YWNrZXIuXG4gKiAgIC0gUGxhaW50ZXh0IGlzIGVuY3J5cHRlZCB3aXRoIGEgZnJlc2ggMTItYnl0ZSBJVi4gVGhlIGVudmVsb3BlIGZvcm1hdCBpc1xuICogICAgIGB2MTo8aXYtYjY0Pjo8Y2lwaGVydGV4dC1iNjQ+YCBhbmQgaXMgd2hhdCBnZXRzIHN0b3JlZC5cbiAqXG4gKiBCYWNrd2FyZHMgY29tcGF0aWJpbGl0eTogYW4gdW5wcmVmaXhlZCB2YWx1ZSBpcyB0cmVhdGVkIGFzIGxlZ2FjeVxuICogcGxhaW50ZXh0LCBkZWNyeXB0ZWQgdG8gaXRzZWxmLCBhbmQgcmUtZW5jcnlwdGVkIG9uIHRoZSBuZXh0IHdyaXRlLlxuICovXG5cbmNvbnN0IFNBTFRfU1RPUkFHRV9LRVkgPSAnX19pbW1fYXJjaGl2ZV9zYWx0X18nO1xuY29uc3QgRU5WRUxPUEVfUFJFRklYID0gJ3YxOic7XG5cbmxldCBkZXJpdmVkS2V5Q2FjaGU6IENyeXB0b0tleSB8IG51bGwgPSBudWxsO1xubGV0IGRlcml2ZWRLZXlDYWNoZVNhbHQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiB0b0Jhc2U2NChidWY6IFVpbnQ4QXJyYXkpOiBzdHJpbmcge1xuICBsZXQgcyA9ICcnO1xuICBmb3IgKGNvbnN0IGIgb2YgYnVmKSBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYik7XG4gIHJldHVybiBidG9hKHMpO1xufVxuXG5mdW5jdGlvbiBmcm9tQmFzZTY0KHM6IHN0cmluZyk6IFVpbnQ4QXJyYXkge1xuICBjb25zdCBiaW4gPSBhdG9iKHMpO1xuICBjb25zdCBvdXQgPSBuZXcgVWludDhBcnJheShiaW4ubGVuZ3RoKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBiaW4ubGVuZ3RoOyBpKyspIG91dFtpXSA9IGJpbi5jaGFyQ29kZUF0KGkpO1xuICByZXR1cm4gb3V0O1xufVxuXG5hc3luYyBmdW5jdGlvbiBsb2FkT3JDcmVhdGVTYWx0KCk6IFByb21pc2U8eyBzYWx0QjY0OiBzdHJpbmc7IHNhbHQ6IFVpbnQ4QXJyYXkgfT4ge1xuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFNBTFRfU1RPUkFHRV9LRVkpO1xuICBjb25zdCB2ID0gc3RvcmVkW1NBTFRfU1RPUkFHRV9LRVldO1xuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xuICAgIHJldHVybiB7IHNhbHRCNjQ6IHYsIHNhbHQ6IGZyb21CYXNlNjQodikgfTtcbiAgfVxuICBjb25zdCBzYWx0ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgzMikpO1xuICBjb25zdCBzYWx0QjY0ID0gdG9CYXNlNjQoc2FsdCk7XG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbU0FMVF9TVE9SQUdFX0tFWV06IHNhbHRCNjQgfSk7XG4gIHJldHVybiB7IHNhbHRCNjQsIHNhbHQgfTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZGVyaXZlS2V5KCk6IFByb21pc2U8Q3J5cHRvS2V5PiB7XG4gIGNvbnN0IHsgc2FsdEI2NCwgc2FsdCB9ID0gYXdhaXQgbG9hZE9yQ3JlYXRlU2FsdCgpO1xuICBpZiAoZGVyaXZlZEtleUNhY2hlICE9PSBudWxsICYmIGRlcml2ZWRLZXlDYWNoZVNhbHQgPT09IHNhbHRCNjQpIHtcbiAgICByZXR1cm4gZGVyaXZlZEtleUNhY2hlO1xuICB9XG4gIGNvbnN0IHNlZWQgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoXG4gICAgYCR7YnJvd3Nlci5ydW50aW1lLmlkfXwke2Jyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb259fGltbS1hcmNoaXZlLXBhdC12MWBcbiAgKTtcbiAgY29uc3QgY29tYmluZWQgPSBuZXcgVWludDhBcnJheShzZWVkLmxlbmd0aCArIHNhbHQubGVuZ3RoKTtcbiAgY29tYmluZWQuc2V0KHNlZWQsIDApO1xuICBjb21iaW5lZC5zZXQoc2FsdCwgc2VlZC5sZW5ndGgpO1xuICBjb25zdCBoYXNoID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBjb21iaW5lZCk7XG4gIGNvbnN0IGtleSA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuaW1wb3J0S2V5KCdyYXcnLCBoYXNoLCB7IG5hbWU6ICdBRVMtR0NNJyB9LCBmYWxzZSwgW1xuICAgICdlbmNyeXB0JyxcbiAgICAnZGVjcnlwdCcsXG4gIF0pO1xuICBkZXJpdmVkS2V5Q2FjaGUgPSBrZXk7XG4gIGRlcml2ZWRLZXlDYWNoZVNhbHQgPSBzYWx0QjY0O1xuICByZXR1cm4ga2V5O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNFbmNyeXB0ZWRQYXQodjogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiB2LnN0YXJ0c1dpdGgoRU5WRUxPUEVfUFJFRklYKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVuY3J5cHRQYXQocGxhaW50ZXh0OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBpZiAoIXBsYWludGV4dCkgcmV0dXJuICcnO1xuICBjb25zdCBrZXkgPSBhd2FpdCBkZXJpdmVLZXkoKTtcbiAgY29uc3QgaXYgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEyKSk7XG4gIGNvbnN0IGN0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5lbmNyeXB0KFxuICAgIHsgbmFtZTogJ0FFUy1HQ00nLCBpdiB9LFxuICAgIGtleSxcbiAgICBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUocGxhaW50ZXh0KVxuICApO1xuICByZXR1cm4gYCR7RU5WRUxPUEVfUFJFRklYfSR7dG9CYXNlNjQoaXYpfToke3RvQmFzZTY0KG5ldyBVaW50OEFycmF5KGN0KSl9YDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlY3J5cHRQYXQoZW52ZWxvcGU6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGlmICghZW52ZWxvcGUpIHJldHVybiAnJztcbiAgLy8gTGVnYWN5IHBsYWludGV4dCAocHJlLWVuY3J5cHRpb24gaW5zdGFsbHMpOiBwYXNzIHRocm91Z2guIFRoZSBuZXh0IHNhdmVcbiAgLy8gcmUtZW5jcnlwdHMgaXQgdmlhIHRoZSBzdG9yYWdlIGxheWVyLlxuICBpZiAoIWVudmVsb3BlLnN0YXJ0c1dpdGgoRU5WRUxPUEVfUFJFRklYKSkgcmV0dXJuIGVudmVsb3BlO1xuICBjb25zdCBwYXJ0cyA9IGVudmVsb3BlLnNsaWNlKEVOVkVMT1BFX1BSRUZJWC5sZW5ndGgpLnNwbGl0KCc6Jyk7XG4gIGlmIChwYXJ0cy5sZW5ndGggIT09IDIpIHJldHVybiAnJztcbiAgY29uc3QgW2l2QjY0LCBjdEI2NF0gPSBwYXJ0cztcbiAgaWYgKCFpdkI2NCB8fCAhY3RCNjQpIHJldHVybiAnJztcbiAgdHJ5IHtcbiAgICBjb25zdCBrZXkgPSBhd2FpdCBkZXJpdmVLZXkoKTtcbiAgICBjb25zdCBpdiA9IGZyb21CYXNlNjQoaXZCNjQpO1xuICAgIGNvbnN0IGN0ID0gZnJvbUJhc2U2NChjdEI2NCk7XG4gICAgY29uc3QgcHQgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRlY3J5cHQoXG4gICAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXY6IGl2IGFzIEJ1ZmZlclNvdXJjZSB9LFxuICAgICAga2V5LFxuICAgICAgY3QgYXMgQnVmZmVyU291cmNlXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKHB0KTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuICcnO1xuICB9XG59XG4iLCAiaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUywgRkFMTEJBQ0tfQUNDT1VOVFMsIEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9jb25maWcuanMnO1xuaW1wb3J0IHsgZGVjcnlwdFBhdCwgZW5jcnlwdFBhdCwgaXNFbmNyeXB0ZWRQYXQgfSBmcm9tICcuL2NyeXB0by5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIEFjY291bnRDb25maWcsXG4gIEFjY291bnRDb3VudGVyLFxuICBBcmNoaXZlU25hcHNob3QsXG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDb25uZWN0aW9uU3RhdGUsXG4gIExvZ0V2ZW50LFxuICBSZXR3ZWV0RWRnZSxcbiAgU2V0dGluZ3MsXG4gIFR3ZWV0U2lnaHRpbmcsXG4gIFVuYXZhaWxhYmxlVHdlZXQsXG59IGZyb20gJy4vdHlwZXMuanMnO1xuXG4vKipcbiAqIEJ1ZmZlcmVkIHR3ZWV0cyBmb3IgYSBnaXZlbiBhY2NvdW50LCBhd2FpdGluZyBjb21taXQuIEEgXCJydW5cIiBpcyBvbmUgZW50cnlcbiAqIGluIHRoaXMgbWFwOyBmbHVzaGluZyBjbGVhcnMgdGhlIGVudHJ5LiBXZSBzdG9yZSBhcyBSZWNvcmQgc28gdGhlIHN0cnVjdHVyZVxuICogc3Vydml2ZXMgSlNPTiBzZXJpYWxpemF0aW9uIHRocm91Z2ggYnJvd3Nlci5zdG9yYWdlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFJ1bkJ1ZmZlciB7XG4gIHJ1bl9pZDogc3RyaW5nO1xuICBhY2NvdW50X2hhbmRsZTogc3RyaW5nO1xuICBzdGFydGVkX2F0OiBzdHJpbmc7XG4gIGxhc3RfY2FwdHVyZV9hdDogc3RyaW5nO1xuICB0d2VldHNfYnlfaWQ6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PjtcbiAgdW5hdmFpbGFibGVfYnlfaWQ/OiBSZWNvcmQ8c3RyaW5nLCBVbmF2YWlsYWJsZVR3ZWV0PjtcbiAgcmV0d2VldF9lZGdlc19ieV9rZXk/OiBSZWNvcmQ8c3RyaW5nLCBSZXR3ZWV0RWRnZT47XG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XG4gIGVuZHBvaW50c19zZWVuOiBzdHJpbmdbXTtcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcbn1cblxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxuICogVXNlZCB0byBza2lwIHJlLWNhcHR1cmluZyB0d2VldHMgd2UndmUgYWxyZWFkeSBwdXNoZWQgd2l0aCBpZGVudGljYWxcbiAqIGVuZ2FnZW1lbnQgY291bnRzIFx1MjAxNCBhdm9pZHMgZ2VuZXJhdGluZyBvbmUgbmV3IHJhdy8qIGZpbGUgZXZlcnkgYnJvd3NlLiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XG4gIHRzOiBzdHJpbmc7IC8vIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3QgY29tbWl0XG4gIHNpZzogc3RyaW5nOyAvLyBlbmdhZ2VtZW50IHNpZ25hdHVyZTogXCJsaWtlfHJ0fHJlcGx5fHF1b3RlXCJcbn1cblxuLyoqIFByb2dyZXNzICsgaW5mbGlnaHQgdHJhY2tpbmcgZm9yIGEgcXVldWUtZHJpdmVuIGxvb3AgKHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCkuXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcbiAqIFwiWCBvZiBZIHByb2Nlc3NlZFwiIFx1MjAxNCBhbmQgdGhlIHdhaXQtZm9yLWluZ2VzdCBndWFyZCBrbm93cyB3aGF0IHRvIGV4cGVjdC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XG4gIC8qKiBJbml0aWFsIHF1ZXVlIHNpemUgd2hlbiB0aGUgdXNlciBjbGlja2VkIFwiU3RhcnRcIi4gKi9cbiAgdG90YWxBdFN0YXJ0OiBudW1iZXI7XG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cbiAgcHJvY2Vzc2VkOiBudW1iZXI7XG4gIC8qKiBJU08gb2Ygd2hlbiB0aGlzIHNlc3Npb24gc3RhcnRlZC4gKi9cbiAgc3RhcnRlZEF0OiBzdHJpbmc7XG4gIC8qKiBUd2VldCBjdXJyZW50bHkgaW5mbGlnaHQgXHUyMDE0IHdlIG5hdmlnYXRlZCB0byBpdCBhbmQgYXJlIHdhaXRpbmcgZm9yIHRoZVxuICAgKiBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgcmVzcG9uc2UgYmVmb3JlIGFkdmFuY2luZy4gbnVsbCBiZXR3ZWVuIHRpY2tzXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xuICBpbmZsaWdodDogeyB0d2VldElkOiBzdHJpbmc7IG5hdmlnYXRlZEF0OiBzdHJpbmcgfSB8IG51bGw7XG59XG5cbi8qKiBBdXRvLXNjcm9sbCBzZXNzaW9uOiBjb3VudHMgb2YgdGlja3MgYW5kIHR3ZWV0cyBpbmdlc3RlZCBzaW5jZSB0aGUgdXNlclxuICogY2xpY2tlZCBTdGFydC4gUGVyc2lzdGVkIHNvIFNXIGV2aWN0aW9uIGR1cmluZyBhIHJ1biBrZWVwcyBwcm9ncmVzcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xuICBzdGFydGVkQXQ6IHN0cmluZztcbiAgc2Nyb2xsQ291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xuICBpbmdlc3RlZE5ld0NvdW50OiBudW1iZXI7XG4gIGluZ2VzdGVkRXhpc3RpbmdDb3VudDogbnVtYmVyO1xuICBza2lwcGVkT2xkQ291bnQ6IG51bWJlcjtcbiAgZXhwYW5kZWRDb3VudDogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgU3RvcmFnZVNoYXBlIHtcbiAgc2V0dGluZ3M6IFNldHRpbmdzO1xuICBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdO1xuICAvKiogSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBzdWNjZXNzZnVsIGFjY291bnRzLnlhbWwgZmV0Y2ggZnJvbSB0aGUgcmVwby5cbiAgICogVXNlZCBieSBgcmVmcmVzaEFjY291bnRzTGlzdGAgdG8gc2tpcCByZS1mZXRjaGluZyBvbiBldmVyeSBTVyB3YWtlIFx1MjAxNCB0aGVcbiAgICogZmlsZSBjaGFuZ2VzIHJhcmVseSBhbmQgYW4gYXV0aGVudGljYXRlZCByYXcgZmV0Y2ggZXZlcnkgd2FrZSBhZGRzIHVwLiAqL1xuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBzdHJpbmcgfCBudWxsO1xuICBhcmNoaXZlU25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGw7XG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcbiAgcnVuQnVmZmVyczogUmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPjtcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XG4gIHJlY2VudFR3ZWV0U2lnaHRpbmdzOiBUd2VldFNpZ2h0aW5nW107XG4gIGNvbW1pdHRlZEluZGV4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+O1xuICAvKiogVHdlZXRzIHRoZSBub3JtYWxpemVyIGZsYWdnZWQgYXMgdHJ1bmNhdGVkIGFuZCB0aGF0IHdlIGhhdmVuJ3Qgc2VlbiBhXG4gICAqIGZ1bGwtdGV4dCB2ZXJzaW9uIG9mIHlldC4gS2V5ZWQgYnkgaGFuZGxlIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuICovXG4gIHJlZmV0Y2hRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogVHdlZXQgSURzIHNlZW4gdmlhIE1lZGlhLXRhYiAvIHBhcnRpYWwgY2FwdHVyZXMgdGhhdCBjb3VsZG4ndCBiZVxuICAgKiBub3JtYWxpemVkIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gS2V5ZWQgYnkgaGludC1oYW5kbGUgKG9yXG4gICAqIFwiX3Vua25vd25cIikgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gVGhlIHVzZXIgY2FuIGRyaXZlIGEgY3Jhd2wgdGhhdFxuICAgKiBvcGVucyBlYWNoIGRldGFpbCBwYWdlIHRvIGNhcHR1cmUgdGhlIHJlYWwgdGhpbmcuICovXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogQ29yZS1hY2NvdW50IHRocmVhZCByb290cyB3b3J0aCBvcGVuaW5nIGJlY2F1c2UgdGltZWxpbmUvc2VhcmNoIHZpZXdzIG1heVxuICAgKiBvbWl0IGxhdGVyIHNlbGYtcmVwbGllcy4gS2V5ZWQgYnkgaGludC1oYW5kbGUgLT4gcm9vdCB0d2VldCBpZHMuICovXG4gIHRocmVhZE9wZW5RdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogUm9vdCB0d2VldCBpZHMgYWxyZWFkeSBhdHRlbXB0ZWQgYnkgdGhlIHRocmVhZC1vcGVuaW5nIHV0aWxpdHkuICovXG4gIHRocmVhZE9wZW5TZWVuOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBtZWRpYUNyYXdsU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICB0aHJlYWRPcGVuU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBhdXRvU2Nyb2xsU2Vzc2lvbjogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsO1xufVxuXG5jb25zdCBERUZBVUxUX0NPTk5FQ1RJT046IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgc3RhdHVzOiAndW5rbm93bicsXG4gIGxvZ2luOiBudWxsLFxuICBjaGVja2VkQXQ6IG51bGwsXG4gIGVycm9yOiBudWxsLFxuICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxufTtcblxuY29uc3QgREVGQVVMVFM6IFN0b3JhZ2VTaGFwZSA9IHtcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9LFxuICBhY2NvdW50czogWy4uLkZBTExCQUNLX0FDQ09VTlRTXSxcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogbnVsbCxcbiAgYXJjaGl2ZVNuYXBzaG90OiBudWxsLFxuICBjb25uZWN0aW9uOiB7IC4uLkRFRkFVTFRfQ09OTkVDVElPTiB9LFxuICBjb3VudGVyczoge30sXG4gIHJ1bkJ1ZmZlcnM6IHt9LFxuICBhY3Rpdml0eTogW10sXG4gIHJlY2VudFR3ZWV0U2lnaHRpbmdzOiBbXSxcbiAgY29tbWl0dGVkSW5kZXg6IHt9LFxuICByZWZldGNoUXVldWU6IHt9LFxuICBtZWRpYUNyYXdsUXVldWU6IHt9LFxuICB0aHJlYWRPcGVuUXVldWU6IHt9LFxuICB0aHJlYWRPcGVuU2Vlbjoge30sXG4gIHJlZmV0Y2hTZXNzaW9uOiBudWxsLFxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcbiAgdGhyZWFkT3BlblNlc3Npb246IG51bGwsXG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBudWxsLFxufTtcblxuYXN5bmMgZnVuY3Rpb24gZ2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSyk6IFByb21pc2U8U3RvcmFnZVNoYXBlW0tdPiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoa2V5KTtcbiAgY29uc3QgdmFsdWUgPSByZXN1bHRba2V5XTtcbiAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gc3RydWN0dXJlZENsb25lKERFRkFVTFRTW2tleV0pO1xuICB9XG4gIHJldHVybiB2YWx1ZSBhcyBTdG9yYWdlU2hhcGVbS107XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEssIHZhbHVlOiBTdG9yYWdlU2hhcGVbS10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtrZXldOiB2YWx1ZSB9KTtcbn1cblxuLy8gLS0tIFNldHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNldHRpbmdzKCk6IFByb21pc2U8U2V0dGluZ3M+IHtcbiAgLy8gQmFja2ZpbGwgYW55IGtleXMgdGhlIHVzZXIncyBzdG9yZWQgc2V0dGluZ3MgcHJlZGF0ZSBcdTIwMTQgcmVhZGVycyBjYW4gcmVseVxuICAvLyBvbiBldmVyeSBTZXR0aW5ncyBmaWVsZCBiZWluZyBwcmVzZW50IHJhdGhlciB0aGFuIGA/PyBkZWZhdWx0aW5nYCBhdFxuICAvLyBldmVyeSBjYWxsc2l0ZS4gVGhlIFBBVCBpcyBzdG9yZWQgZW5jcnlwdGVkLWF0LXJlc3QgYXMgb2YgdjAuMi4wOyB3ZVxuICAvLyBkZWNyeXB0IHRyYW5zcGFyZW50bHkgc28gY2FsbGVycyBjb250aW51ZSB0byBzZWUgcGxhaW50ZXh0LlxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBnZXRSYXcoJ3NldHRpbmdzJyk7XG4gIGNvbnN0IG1lcmdlZCA9IHsgLi4uREVGQVVMVF9TRVRUSU5HUywgLi4uc3RvcmVkIH07XG4gIGlmIChtZXJnZWQucGF0ICYmIGlzRW5jcnlwdGVkUGF0KG1lcmdlZC5wYXQpKSB7XG4gICAgdHJ5IHtcbiAgICAgIG1lcmdlZC5wYXQgPSBhd2FpdCBkZWNyeXB0UGF0KG1lcmdlZC5wYXQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgbWVyZ2VkLnBhdCA9ICcnO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbWVyZ2VkO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIEVuY3J5cHQgdGhlIFBBVCBiZWZvcmUgcGVyc2lzdGluZzsgbGVnYWN5IHBsYWludGV4dCBQQVRzIGdldCB1cGdyYWRlZFxuICAvLyBvbiB0aGUgbmV4dCBzYXZlLlxuICBjb25zdCB0b1dyaXRlOiBTZXR0aW5ncyA9IHsgLi4ucyB9O1xuICBpZiAodG9Xcml0ZS5wYXQgJiYgIWlzRW5jcnlwdGVkUGF0KHRvV3JpdGUucGF0KSkge1xuICAgIHRvV3JpdGUucGF0ID0gYXdhaXQgZW5jcnlwdFBhdCh0b1dyaXRlLnBhdCk7XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdzZXR0aW5ncycsIHRvV3JpdGUpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHBhdGNoOiBQYXJ0aWFsPFNldHRpbmdzPik6IFByb21pc2U8U2V0dGluZ3M+IHtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgbmV4dCA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xuICBhd2FpdCBzZXRTZXR0aW5ncyhuZXh0KTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbi8vIC0tLSBBY2NvdW50cyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50cygpOiBQcm9taXNlPEFjY291bnRDb25maWdbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50cycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzKGE6IEFjY291bnRDb25maWdbXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzJywgYSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzUmVmcmVzaGVkQXQoaXNvOiBzdHJpbmcgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcsIGlzbyk7XG59XG5cbi8vIC0tLSBBcmNoaXZlIHNuYXBzaG90IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFyY2hpdmVTbmFwc2hvdCgpOiBQcm9taXNlPEFyY2hpdmVTbmFwc2hvdCB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYXJjaGl2ZVNuYXBzaG90Jyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBcmNoaXZlU25hcHNob3Qoc25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhcmNoaXZlU25hcHNob3QnLCBzbmFwc2hvdCk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHN0YXRlIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb24oKTogUHJvbWlzZTxDb25uZWN0aW9uU3RhdGU+IHtcbiAgY29uc3QgYyA9IGF3YWl0IGdldFJhdygnY29ubmVjdGlvbicpO1xuICAvLyBCYWNrZmlsbCBmaWVsZHMgYWRkZWQgYWZ0ZXIgdGhlIHVzZXIncyBzdG9yYWdlIHdhcyB3cml0dGVuLlxuICBjb25zdCBvdXQ6IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgICAuLi5jLFxuICAgIGRlZmF1bHRCcmFuY2g6IGMuZGVmYXVsdEJyYW5jaCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuZGVmYXVsdEJyYW5jaCxcbiAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOlxuICAgICAgYy5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxuICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGMucmF0ZUxpbWl0UmVzZXRBdCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMucmF0ZUxpbWl0UmVzZXRBdCxcbiAgfTtcbiAgcmV0dXJuIG91dDtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb25uZWN0aW9uKGM6IENvbm5lY3Rpb25TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2Nvbm5lY3Rpb24nLCBjKTtcbn1cblxuLy8gLS0tIENvdW50ZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZnVuY3Rpb24gdG9kYXlJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3VudGVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb3VudGVycycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGJ1bXBDb3VudGVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgcGF0Y2g6IFBhcnRpYWw8QWNjb3VudENvdW50ZXI+XG4pOiBQcm9taXNlPEFjY291bnRDb3VudGVyPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGNvbnN0IGN1ciA9IGFsbFtoYW5kbGVdID8/IHtcbiAgICB0b2RheUNvdW50OiAwLFxuICAgIHRvZGF5RGF0ZTogdG9kYXlJU08oKSxcbiAgICBsYXN0Q2FwdHVyZUF0OiBudWxsLFxuICAgIHRvdGFsQ29tbWl0dGVkOiAwLFxuICAgIGJ1ZmZlcmVkQ291bnQ6IDAsXG4gIH07XG4gIGlmIChjdXIudG9kYXlEYXRlICE9PSB0b2RheUlTTygpKSB7XG4gICAgY3VyLnRvZGF5RGF0ZSA9IHRvZGF5SVNPKCk7XG4gICAgY3VyLnRvZGF5Q291bnQgPSAwO1xuICB9XG4gIGNvbnN0IG5leHQ6IEFjY291bnRDb3VudGVyID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGFsbFtoYW5kbGVdID0gbmV4dDtcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGFsbCk7XG4gIHJldHVybiBuZXh0O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QnVmZmVyZWRDb3VudChoYW5kbGU6IHN0cmluZywgY291bnQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHsgYnVmZmVyZWRDb3VudDogY291bnQgfSk7XG59XG5cbi8vIC0tLSBSdW4gYnVmZmVycyAodGhlIHBlbmRpbmcgY2FwdHVyZXMgYXdhaXRpbmcgY29tbWl0KSAtLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3J1bkJ1ZmZlcnMnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8UnVuQnVmZmVyIHwgbnVsbD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIHJldHVybiBhbGxbaGFuZGxlXSA/PyBudWxsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nLCBidWY6IFJ1bkJ1ZmZlcik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGFsbFtoYW5kbGVdID0gYnVmO1xuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBkZWxldGUgYWxsW2hhbmRsZV07XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbi8vIC0tLSBBY3Rpdml0eSB0YWlsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY3Rpdml0eSgpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcbiAgcmV0dXJuIGdldFJhdygnYWN0aXZpdHknKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGVuZEFjdGl2aXR5KGV2OiBMb2dFdmVudCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRBY3Rpdml0eSgpO1xuICBjdXIudW5zaGlmdChldik7XG4gIGlmIChjdXIubGVuZ3RoID4gQUNUSVZJVFlfVEFJTF9NQVgpIGN1ci5sZW5ndGggPSBBQ1RJVklUWV9UQUlMX01BWDtcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIGN1cik7XG4gIHJldHVybiBjdXI7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgW10pO1xufVxuXG4vLyAtLS0gUmVjZW50IHR3ZWV0IHNpZ2h0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuY29uc3QgUkVDRU5UX1RXRUVUX1NJR0hUSU5HU19NQVggPSA4MDtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk6IFByb21pc2U8VHdlZXRTaWdodGluZ1tdPiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlY2VudFR3ZWV0U2lnaHRpbmdzJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVwZW5kUmVjZW50VHdlZXRTaWdodGluZ3Mocm93czogVHdlZXRTaWdodGluZ1tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncygpO1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IG5leHQ6IFR3ZWV0U2lnaHRpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHJvdyBvZiByb3dzKSB7XG4gICAgY29uc3Qga2V5ID0gYCR7cm93LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCl9OiR7cm93LnR3ZWV0X2lkfWA7XG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGtleSk7XG4gICAgbmV4dC5wdXNoKHJvdyk7XG4gIH1cbiAgZm9yIChjb25zdCByb3cgb2YgY3VyKSB7XG4gICAgY29uc3Qga2V5ID0gYCR7cm93LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCl9OiR7cm93LnR3ZWV0X2lkfWA7XG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGtleSk7XG4gICAgbmV4dC5wdXNoKHJvdyk7XG4gIH1cbiAgbmV4dC5sZW5ndGggPSBNYXRoLm1pbihuZXh0Lmxlbmd0aCwgUkVDRU5UX1RXRUVUX1NJR0hUSU5HU19NQVgpO1xuICBhd2FpdCBzZXRSYXcoJ3JlY2VudFR3ZWV0U2lnaHRpbmdzJywgbmV4dCk7XG59XG5cbi8vIC0tLSBDb21taXR0ZWQtdHdlZXRzIGRlZHVwIGluZGV4IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb21taXR0ZWRJbmRleCcpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29tbWl0dGVkSW5kZXgoXG4gIGlkeDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PlxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29tbWl0dGVkSW5kZXgnLCBpZHgpO1xufVxuXG4vKiogQ29tcHV0ZSB0aGUgZW5nYWdlbWVudCBzaWduYXR1cmUgd2UgdXNlIHRvIGRlY2lkZSB3aGV0aGVyIGEgcmUtY2FwdHVyZWRcbiAqIHR3ZWV0IGlzIFwibWF0ZXJpYWxseSBkaWZmZXJlbnRcIiBmcm9tIHdoYXQgd2UgbGFzdCBjb21taXR0ZWQuIFdlIG9taXRcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXG4gKiBkZWZlYXQgdGhlIGRlZHVwLiBMaWtlcyAvIFJUcyAvIHJlcGxpZXMgLyBxdW90ZXMgY2hhbmdlIHJhcmVseSBlbm91Z2ggdGhhdFxuICogZWFjaCBjaGFuZ2UgaXMgd29ydGggYSByZS1jb21taXQgKGFuZCBhbiBlbmdhZ2VtZW50X2hpc3Rvcnkgc25hcHNob3QpLlxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxuICogdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkgYnlwYXNzZXMgdGhlIGRlZHVwIGV2ZW4gd2hlbiBlbmdhZ2VtZW50IGNvdW50c1xuICogaGF2ZW4ndCBtb3ZlZCBcdTIwMTQgb3RoZXJ3aXNlIHRoZSBuZXcgYm9keSB3b3VsZCBiZSBzaWxlbnRseSBkcm9wcGVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXG4gIGxpa2VzOiBudW1iZXIsXG4gIHJldHdlZXRzOiBudW1iZXIsXG4gIHJlcGxpZXM6IG51bWJlcixcbiAgcXVvdGVzOiBudW1iZXIsXG4gIGlzVHJ1bmNhdGVkOiBib29sZWFuID0gZmFsc2Vcbik6IHN0cmluZyB7XG4gIHJldHVybiBgJHtsaWtlc318JHtyZXR3ZWV0c318JHtyZXBsaWVzfXwke3F1b3Rlc318JHtpc1RydW5jYXRlZCA/ICd0JyA6ICdmJ31gO1xufVxuXG4vKiogRHJvcCBlbnRyaWVzIG9sZGVyIHRoYW4gYG1heEFnZU1zYC4gUmV0dXJucyB0aGUgbnVtYmVyIHBydW5lZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcnVuZUNvbW1pdHRlZEluZGV4KG1heEFnZU1zOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBjb25zdCBjdXRvZmYgPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gbWF4QWdlTXMpLnRvSVNPU3RyaW5nKCk7XG4gIGxldCBwcnVuZWQgPSAwO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgY29uc3QgaW5uZXIgPSBpZHhbaGFuZGxlXTtcbiAgICBpZiAoIWlubmVyKSBjb250aW51ZTtcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcbiAgICAgIGNvbnN0IGUgPSBpbm5lclt0aWRdO1xuICAgICAgaWYgKGUgJiYgZS50cyA8IGN1dG9mZikge1xuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcbiAgICAgICAgcHJ1bmVkICs9IDE7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhpbm5lcikubGVuZ3RoID09PSAwKSBkZWxldGUgaWR4W2hhbmRsZV07XG4gIH1cbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG4gIHJldHVybiBwcnVuZWQ7XG59XG5cbi8vIC0tLSBSZWZldGNoIHF1ZXVlICh0d2VldHMgbmVlZGluZyBmdWxsLXRleHQgcmVjYXB0dXJlKSAtLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hRdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbaGFuZGxlXSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdO1xuICBpZiAoIWlkcykgcmV0dXJuO1xuICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2hhbmRsZV07XG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0UmVmZXRjaFRhcmdldCgpOiBQcm9taXNlPHtcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIHR3ZWV0SWQ6IHN0cmluZztcbn0gfCBudWxsPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBoYW5kbGUsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVNZWRpYUNyYXdsKGhpbnRIYW5kbGU6IHN0cmluZyB8IG51bGwsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcbiAgY29uc3QgaWRzID0gcVtidWNrZXRdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbYnVja2V0XSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcbiAgICBpZiAoIWlkcykgY29udGludWU7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XG4gICAgfVxuICB9XG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTogUHJvbWlzZTx7XG4gIGJ1Y2tldDogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgYnVja2V0LCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8vIC0tLSBUaHJlYWQtb3BlbmluZyBxdWV1ZSAoY29yZSBjb252ZXJzYXRpb24gcm9vdHMgdG8gdmlzaXQpIC0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRocmVhZE9wZW5RdWV1ZSgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICByZXR1cm4gZ2V0UmF3KCd0aHJlYWRPcGVuUXVldWUnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRocmVhZE9wZW5RdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcbiAgbGV0IHRvdGFsID0gMDtcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcbiAgcmV0dXJuIHRvdGFsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFzVGhyZWFkT3BlblNlZW4odHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHNlZW4gPSBhd2FpdCBnZXRSYXcoJ3RocmVhZE9wZW5TZWVuJyk7XG4gIHJldHVybiB0d2VldElkIGluIHNlZW47XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtYXJrVGhyZWFkT3BlblNlZW4odHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHNlZW4gPSBhd2FpdCBnZXRSYXcoJ3RocmVhZE9wZW5TZWVuJyk7XG4gIHNlZW5bdHdlZXRJZF0gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblNlZW4nLCBzZWVuKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVUaHJlYWRPcGVuKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGF3YWl0IGhhc1RocmVhZE9wZW5TZWVuKHR3ZWV0SWQpKSByZXR1cm47XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbaGFuZGxlXSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5RdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlVGhyZWFkT3Blbih0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcbiAgICBpZiAoIWlkcykgY29udGludWU7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XG4gICAgfVxuICB9XG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5RdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dFRocmVhZE9wZW5UYXJnZXQoKTogUHJvbWlzZTx7XG4gIGhhbmRsZTogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgaGFuZGxlLCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXG4gKiBlbnF1ZXVlaW5nIG1lZGlhLWNyYXdsIHRhcmdldHMgd2UndmUgYWxyZWFkeSBhcmNoaXZlZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpc0NvbW1pdHRlZCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgZm9yIChjb25zdCBpbm5lciBvZiBPYmplY3QudmFsdWVzKGlkeCkpIHtcbiAgICBpZiAoaW5uZXIgJiYgdHdlZXRJZCBpbiBpbm5lcikgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyAtLS0gTG9vcCBzZXNzaW9uIHN0YXRlIChwcm9ncmVzcyArIGluZmxpZ2h0IGdhdGluZykgLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRocmVhZE9wZW5TZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ3RocmVhZE9wZW5TZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0VGhyZWFkT3BlblNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblNlc3Npb24nLCBzKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpOiBQcm9taXNlPEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEF1dG9TY3JvbGxTZXNzaW9uKHM6IEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJywgcyk7XG59XG5cbi8vIC0tLSBQdXJnZTogdW5yZWxhdGVkIGJ1ZmZlcnMsIGNvdW50ZXJzLCBxdWV1ZSBlbnRyaWVzIC0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLyoqXG4gKiBEcm9wIGV2ZXJ5IHBlci1oYW5kbGUgYml0IG9mIHN0YXRlIChjb3VudGVycywgcnVuIGJ1ZmZlciwgY29tbWl0dGVkLWluZGV4XG4gKiBlbnRyaWVzLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcXVldWUgZW50cmllcykgdGhhdCBkb2Vzbid0IGNvcnJlc3BvbmQgdG8gYVxuICogdHJhY2tlZCBhY2NvdW50LiBSZXR1cm5zIGEgc3VtbWFyeSBkZXNjcmliaW5nIHdoYXQgd2FzIGNsZWFyZWQgc28gdGhlXG4gKiBjYWxsZXIgY2FuIGxvZyBpdC5cbiAqXG4gKiBUcmFja2VkIGFjY291bnRzIGFyZSBwYXNzZWQgaW4gKGNhbGxlciByZXNvbHZlcyBmcm9tIHRoZSBsaXZlIGNvbmZpZykuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwdXJnZVVucmVsYXRlZFN0YXRlKHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+KTogUHJvbWlzZTx7XG4gIGNvdW50ZXJzUmVtb3ZlZDogbnVtYmVyO1xuICBidWZmZXJzUmVtb3ZlZDogbnVtYmVyO1xuICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xuICByZWZldGNoSGFuZGxlc1JlbW92ZWQ6IG51bWJlcjtcbiAgbWVkaWFDcmF3bElkc1JlbW92ZWQ6IG51bWJlcjtcbiAgdGhyZWFkT3Blbklkc1JlbW92ZWQ6IG51bWJlcjtcbn0+IHtcbiAgY29uc3QgdGFyZ0xvd2VyID0gbmV3IFNldChbLi4udGFyZ2V0ZWRdLm1hcCgoaCkgPT4gaC50b0xvd2VyQ2FzZSgpKSk7XG4gIGNvbnN0IGlzVGFyZ2V0ZWQgPSAoaDogc3RyaW5nKTogYm9vbGVhbiA9PiB0YXJnTG93ZXIuaGFzKGgudG9Mb3dlckNhc2UoKSk7XG5cbiAgLy8gQ291bnRlcnNcbiAgY29uc3QgY291bnRlcnMgPSBhd2FpdCBnZXRDb3VudGVycygpO1xuICBsZXQgY291bnRlcnNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGNvdW50ZXJzKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIGNvdW50ZXJzW2hdO1xuICAgICAgY291bnRlcnNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygnY291bnRlcnMnLCBjb3VudGVycyk7XG5cbiAgLy8gUnVuIGJ1ZmZlcnNcbiAgY29uc3QgYnVmZmVycyA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgbGV0IGJ1ZmZlcnNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGJ1ZmZlcnMpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgYnVmZmVyc1toXTtcbiAgICAgIGJ1ZmZlcnNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGJ1ZmZlcnMpO1xuXG4gIC8vIENvbW1pdHRlZCBkZWR1cCBpbmRleFxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBsZXQgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoaWR4KSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIGlkeFtoXTtcbiAgICAgIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG5cbiAgLy8gUmVmZXRjaCBxdWV1ZTogYnVja2V0cyBhcmUga2V5ZWQgYnkgaGFuZGxlLlxuICBjb25zdCBycSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBsZXQgcmVmZXRjaEhhbmRsZXNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKHJxKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIHJxW2hdO1xuICAgICAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcnEpO1xuXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiBidWNrZXRzIGFyZSBoaW50LWhhbmRsZXMgKG9yIFwiX3Vua25vd25cIikuIERyb3BcbiAgLy8gZW50cmllcyB3aG9zZSBidWNrZXQgaXNuJ3QgdGFyZ2V0ZWQgXHUyMDE0IGluY2x1ZGluZyBcIl91bmtub3duXCIgc2luY2Ugd2VcbiAgLy8gY2FuJ3QgdmVyaWZ5IHJlbGF0aW9uLlxuICBjb25zdCBtcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgbWVkaWFDcmF3bElkc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMobXEpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBtZWRpYUNyYXdsSWRzUmVtb3ZlZCArPSAobXFbaF0gPz8gW10pLmxlbmd0aDtcbiAgICAgIGRlbGV0ZSBtcVtoXTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBtcSk7XG5cbiAgY29uc3QgdHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcbiAgbGV0IHRocmVhZE9wZW5JZHNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKHRxKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgdGhyZWFkT3Blbklkc1JlbW92ZWQgKz0gKHRxW2hdID8/IFtdKS5sZW5ndGg7XG4gICAgICBkZWxldGUgdHFbaF07XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblF1ZXVlJywgdHEpO1xuXG4gIHJldHVybiB7XG4gICAgY291bnRlcnNSZW1vdmVkLFxuICAgIGJ1ZmZlcnNSZW1vdmVkLFxuICAgIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkLFxuICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCxcbiAgICBtZWRpYUNyYXdsSWRzUmVtb3ZlZCxcbiAgICB0aHJlYWRPcGVuSWRzUmVtb3ZlZCxcbiAgfTtcbn1cblxuLy8gLS0tIEZ1bGwgcmVzZXQgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJBbGwoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5jbGVhcigpO1xufVxuIiwgImltcG9ydCB7IGFwcGVuZEFjdGl2aXR5IH0gZnJvbSAnLi9zdG9yYWdlLmpzJztcbmltcG9ydCB0eXBlIHsgTG9nRXZlbnQsIExvZ0xldmVsIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmxldCBicm9hZGNhc3Q6ICgoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKSB8IG51bGwgPSBudWxsO1xuXG5leHBvcnQgZnVuY3Rpb24gc2V0QnJvYWRjYXN0ZXIoZm46IChldjogTG9nRXZlbnQpID0+IHZvaWQpOiB2b2lkIHtcbiAgYnJvYWRjYXN0ID0gZm47XG59XG5cbmZ1bmN0aW9uIG5vd0lTTygpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBlbWl0KGxldmVsOiBMb2dMZXZlbCwgbXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGV2OiBMb2dFdmVudCA9IHsgdHM6IG5vd0lTTygpLCBsZXZlbCwgbXNnLCBjb250ZXh0OiByZWRhY3QoY29udGV4dCkgfTtcbiAgLy8gQ29uc29sZSBmb3IgZGV2dG9vbHMuXG4gIGNvbnN0IGxpbmUgPSBgW2ltbS1hcmNoaXZlXSAke2xldmVsLnRvVXBwZXJDYXNlKCl9ICR7bXNnfWA7XG4gIGlmIChsZXZlbCA9PT0gJ2Vycm9yJykgY29uc29sZS5lcnJvcihsaW5lLCBldi5jb250ZXh0KTtcbiAgZWxzZSBpZiAobGV2ZWwgPT09ICd3YXJuJykgY29uc29sZS53YXJuKGxpbmUsIGV2LmNvbnRleHQpO1xuICBlbHNlIGNvbnNvbGUubG9nKGxpbmUsIGV2LmNvbnRleHQpO1xuICAvLyBQZXJzaXN0ZW50IHRhaWwuXG4gIHRyeSB7XG4gICAgYXdhaXQgYXBwZW5kQWN0aXZpdHkoZXYpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gZmFpbGVkIHRvIGFwcGVuZCBhY3Rpdml0eScsIGVycik7XG4gIH1cbiAgLy8gTGl2ZSBicm9hZGNhc3QgKGUuZy4gdG8gc2lkZWJhcikuXG4gIHRyeSB7XG4gICAgYnJvYWRjYXN0Py4oZXYpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBTaWRlYmFyIG1heSBub3QgYmUgb3BlbjsgdGhhdCdzIGZpbmUuXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGluZm8obXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge30pOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIGVtaXQoJ2luZm8nLCBtc2csIGNvbnRleHQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHdhcm4obXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge30pOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIGVtaXQoJ3dhcm4nLCBtc2csIGNvbnRleHQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGVycm9yKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCdlcnJvcicsIG1zZywgY29udGV4dCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZUVycm9yKGVycjogdW5rbm93bik6IHsgbWVzc2FnZTogc3RyaW5nOyBzdGFjazogc3RyaW5nIHwgbnVsbCB9IHtcbiAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgcmV0dXJuIHsgbWVzc2FnZTogZXJyLm1lc3NhZ2UsIHN0YWNrOiBlcnIuc3RhY2sgPz8gbnVsbCB9O1xuICB9XG4gIHRyeSB7XG4gICAgcmV0dXJuIHsgbWVzc2FnZTogU3RyaW5nKGVyciksIHN0YWNrOiBudWxsIH07XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6ICc8dW5wcmludGFibGUgZXJyb3I+Jywgc3RhY2s6IG51bGwgfTtcbiAgfVxufVxuXG4vKipcbiAqIFN0cmlwIGFueXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIFBBVCBvciBvdGhlciBsb25nIHNlY3JldCBmcm9tIGEgY29udGV4dFxuICogb2JqZWN0IGJlZm9yZSBwZXJzaXN0aW5nIGl0LiBEZWZlbnNpdmU6IGNhbGxlcnMgc2hvdWxkIG5vdCBsb2cgdG9rZW5zLCBidXRcbiAqIGlmIHRoZXkgc2xpcCB0aHJvdWdoIHdlIHdhbnQgdG8gcmVkYWN0IHRoZW0uXG4gKi9cbmZ1bmN0aW9uIHJlZGFjdChjdHg6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xuICBjb25zdCBvdXQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XG4gIGZvciAoY29uc3QgW2ssIHZdIG9mIE9iamVjdC5lbnRyaWVzKGN0eCkpIHtcbiAgICBpZiAoay50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCd0b2tlbicpIHx8IGsudG9Mb3dlckNhc2UoKSA9PT0gJ3BhdCcgfHwgayA9PT0gJ2F1dGhvcml6YXRpb24nKSB7XG4gICAgICBvdXRba10gPSAnPHJlZGFjdGVkPic7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dezMwLH0vLnRlc3QodikpIHtcbiAgICAgIG91dFtrXSA9IHYucmVwbGFjZSgvZ2l0aHViX3BhdF9bQS1aYS16MC05X10rL2csICdnaXRodWJfcGF0XzxyZWRhY3RlZD4nKTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDQwOTYpIHtcbiAgICAgIG91dFtrXSA9IGAke3Yuc2xpY2UoMCwgNDA5Nil9XHUyMDI2PHRydW5jYXRlZD5gO1xuICAgIH0gZWxzZSB7XG4gICAgICBvdXRba10gPSB2O1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufVxuIiwgImltcG9ydCB7IGRlc2NyaWJlRXJyb3IgfSBmcm9tICcuL2xvZ2dlci5qcyc7XG5pbXBvcnQgdHlwZSB7IFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmNvbnN0IEFQSV9CQVNFID0gJ2h0dHBzOi8vYXBpLmdpdGh1Yi5jb20nO1xuY29uc3QgUkFXX0JBU0UgPSAnaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tJztcblxuZXhwb3J0IGludGVyZmFjZSBQdXRGaWxlT3B0aW9ucyB7XG4gIHBhdGg6IHN0cmluZztcbiAgY29udGVudEJhc2U2NDogc3RyaW5nO1xuICBtZXNzYWdlOiBzdHJpbmc7XG4gIGV4cGVjdGVkU2hhPzogc3RyaW5nIHwgbnVsbDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQdXRGaWxlUmVzdWx0IHtcbiAgcGF0aDogc3RyaW5nO1xuICBzaGE6IHN0cmluZztcbiAgdXJsOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZU9wdGlvbnMge1xuICBwYXRoOiBzdHJpbmc7XG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlc09wdGlvbnMge1xuICBmaWxlczogQ29tbWl0RmlsZU9wdGlvbnNbXTtcbiAgbWVzc2FnZTogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVzUmVzdWx0IHtcbiAgY29tbWl0U2hhOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xuICBmaWxlczogc3RyaW5nW107XG59XG5cbmV4cG9ydCBjbGFzcyBHaXRIdWJFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgc3RhdHVzOiBudW1iZXI7XG4gIGJvZHk6IHVua25vd247XG4gIHJldHJpYWJsZTogYm9vbGVhbjtcbiAgY2F0ZWdvcnk6ICdhdXRoJyB8ICdyYXRlLWxpbWl0JyB8ICdjb25mbGljdCcgfCAnbm90LWZvdW5kJyB8ICdzZXJ2ZXInIHwgJ25ldHdvcmsnIHwgJ3Vua25vd24nO1xuICAvKiogV2hlbiB0aGUgR2l0SHViIHJhdGUtbGltaXQgd2luZG93IGZvciB0aGlzIHRva2VuIHJlc2V0cywgYXMgYSBVbml4XG4gICAqIGVwb2NoIGluIHNlY29uZHMuIFBvcHVsYXRlZCBmcm9tIGBYLVJhdGVMaW1pdC1SZXNldGAgb24gNDAzLzQyOSwgb3JcbiAgICogZGVyaXZlZCBmcm9tIGBSZXRyeS1BZnRlcmAgZm9yIHNlY29uZGFyeSBsaW1pdHMuIG51bGwgd2hlbiB1bmtub3duLiAqL1xuICByYXRlTGltaXRSZXNldEF0OiBudW1iZXIgfCBudWxsO1xuXG4gIGNvbnN0cnVjdG9yKG9wdHM6IHtcbiAgICBzdGF0dXM6IG51bWJlcjtcbiAgICBib2R5OiB1bmtub3duO1xuICAgIG1lc3NhZ2U6IHN0cmluZztcbiAgICByZXRyaWFibGU6IGJvb2xlYW47XG4gICAgY2F0ZWdvcnk6IEdpdEh1YkVycm9yWydjYXRlZ29yeSddO1xuICAgIHJhdGVMaW1pdFJlc2V0QXQ/OiBudW1iZXIgfCBudWxsO1xuICB9KSB7XG4gICAgc3VwZXIob3B0cy5tZXNzYWdlKTtcbiAgICB0aGlzLm5hbWUgPSAnR2l0SHViRXJyb3InO1xuICAgIHRoaXMuc3RhdHVzID0gb3B0cy5zdGF0dXM7XG4gICAgdGhpcy5ib2R5ID0gb3B0cy5ib2R5O1xuICAgIHRoaXMucmV0cmlhYmxlID0gb3B0cy5yZXRyaWFibGU7XG4gICAgdGhpcy5jYXRlZ29yeSA9IG9wdHMuY2F0ZWdvcnk7XG4gICAgdGhpcy5yYXRlTGltaXRSZXNldEF0ID0gb3B0cy5yYXRlTGltaXRSZXNldEF0ID8/IG51bGw7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIEdpdEh1YkNsaWVudCB7XG4gIHByaXZhdGUgcmVhZG9ubHkgc2V0dGluZ3M6IFNldHRpbmdzO1xuXG4gIGNvbnN0cnVjdG9yKHNldHRpbmdzOiBTZXR0aW5ncykge1xuICAgIHRoaXMuc2V0dGluZ3MgPSBzZXR0aW5ncztcbiAgfVxuXG4gIC8qKiBSZXR1cm5zIHRoZSBhdXRoZW50aWNhdGVkIHVzZXIncyBsb2dpbi4gVGhyb3dzIG9uIGF1dGggZmFpbHVyZS4gKi9cbiAgYXN5bmMgd2hvYW1pKCk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsICcvdXNlcicpO1xuICAgIHJldHVybiAocmVzIGFzIHsgbG9naW4/OiBzdHJpbmcgfSkubG9naW4gPz8gJzx1bmtub3duPic7XG4gIH1cblxuICAvKiogUmV0dXJucyB0cnVlIGlmIHRoZSBnaXZlbiBicmFuY2ggZXhpc3RzIG9uIHRoZSBjb25maWd1cmVkIHJlcG8uICovXG4gIGFzeW5jIGJyYW5jaEV4aXN0cyhicmFuY2g6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vYnJhbmNoZXMvJHtlbmNvZGVVUklDb21wb25lbnQoYnJhbmNoKX1gXG4gICAgICApO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBpZiAoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgZXJyLmNhdGVnb3J5ID09PSAnbm90LWZvdW5kJykgcmV0dXJuIGZhbHNlO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKiBWZXJpZmllcyB0aGUgUEFUIGNhbiBzZWUgdGhlIGNvbmZpZ3VyZWQgcmVwby4gKi9cbiAgYXN5bmMgdmVyaWZ5UmVwb0FjY2VzcygpOiBQcm9taXNlPHsgbG9naW46IHN0cmluZzsgZnVsbF9uYW1lOiBzdHJpbmc7IGRlZmF1bHRfYnJhbmNoOiBzdHJpbmcgfT4ge1xuICAgIGNvbnN0IG1lID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsICcvdXNlcicpO1xuICAgIGNvbnN0IHJlcG8gPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfWApO1xuICAgIGNvbnN0IHIgPSByZXBvIGFzIHsgZnVsbF9uYW1lOiBzdHJpbmc7IGRlZmF1bHRfYnJhbmNoOiBzdHJpbmcgfTtcbiAgICByZXR1cm4ge1xuICAgICAgbG9naW46IChtZSBhcyB7IGxvZ2luOiBzdHJpbmcgfSkubG9naW4sXG4gICAgICBmdWxsX25hbWU6IHIuZnVsbF9uYW1lLFxuICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBWZXJpZnkgdGhlIFBBVCBjYW4gd3JpdGUgdG8gdGhlIGNvbmZpZ3VyZWQgYnJhbmNoIHdpdGhvdXQgY3JlYXRpbmcgYVxuICAgKiBjb21taXQuIE1vdmluZyBhIHJlZiB0byBpdHMgY3VycmVudCBTSEEgaXMgYSBuby1vcCwgYnV0IEdpdEh1YiBzdGlsbFxuICAgKiBlbmZvcmNlcyB0aGUgQ29udGVudHM6IFdyaXRlIHBlcm1pc3Npb24gcmVxdWlyZWQgYnkgY29tbWl0RmlsZXMoKS5cbiAgICovXG4gIGFzeW5jIHZlcmlmeVdyaXRlQWNjZXNzKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGhlYWQgPSBhd2FpdCB0aGlzLmdldEJyYW5jaEhlYWQoKTtcbiAgICBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICdQQVRDSCcsXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9yZWZzL2hlYWRzLyR7ZW5jb2RlUGF0aCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YCxcbiAgICAgIHtcbiAgICAgICAgc2hhOiBoZWFkLnNoYSxcbiAgICAgICAgZm9yY2U6IGZhbHNlLFxuICAgICAgfVxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogRmV0Y2ggYSB0ZXh0IGZpbGUgZnJvbSByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tIGF1dGhlbnRpY2F0ZWQgd2l0aCB0aGVcbiAgICogUEFULiBSZXR1cm5zIG51bGwgaWYgdGhlIGZpbGUgZG9lc24ndCBleGlzdC4gVXNlZCBmb3IgY29uZmlnL2FjY291bnRzLnlhbWwuXG4gICAqL1xuICBhc3luYyBmZXRjaFJhd1RleHQocGF0aEluUmVwbzogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgdXJsID0gYCR7UkFXX0JBU0V9LyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99LyR7dGhpcy5zZXR0aW5ncy5icmFuY2h9LyR7cGF0aEluUmVwb31gO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAgfSxcbiAgICB9KTtcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSByZXR1cm4gbnVsbDtcbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3IocmVzLCBgR0VUIHJhdyAke3BhdGhJblJlcG99YCk7XG4gICAgcmV0dXJuIHJlcy50ZXh0KCk7XG4gIH1cblxuICAvKipcbiAgICogTG9vayB1cCBhbiBleGlzdGluZyBmaWxlJ3MgU0hBIHZpYSB0aGUgQ29udGVudHMgQVBJLCBvciBudWxsIGlmIG5vdCBmb3VuZC5cbiAgICogVXNlZCB3aGVuIHJldHJ5aW5nIGEgUFVUIGFmdGVyIGEgNDIyIHNoYSBtaXNtYXRjaC5cbiAgICovXG4gIGFzeW5jIGdldEZpbGVTaGEocGF0aDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9P3JlZj0ke2VuY29kZVVSSUNvbXBvbmVudCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHIgPSByZXMgYXMgeyBzaGE/OiBzdHJpbmcgfTtcbiAgICAgIHJldHVybiByLnNoYSA/PyBudWxsO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBudWxsO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBQVVQgYSBmaWxlIHRvIHRoZSByZXBvLiBIYW5kbGVzIDQyMiAoc2hhIHJlcXVpcmVkKSBieSByZS1mZXRjaGluZyB0aGVcbiAgICogZXhpc3Rpbmcgc2hhIGFuZCByZXRyeWluZyBvbmNlLiBSZXRyaWVzIG5ldHdvcmsgLyA1eHggLyByYXRlLWxpbWl0IGVycm9yc1xuICAgKiB3aXRoIGV4cG9uZW50aWFsIGJhY2tvZmYgdXAgdG8gbWF4QXR0ZW1wdHMuXG4gICAqL1xuICBhc3luYyBwdXRGaWxlKG9wdHM6IFB1dEZpbGVPcHRpb25zKTogUHJvbWlzZTxQdXRGaWxlUmVzdWx0PiB7XG4gICAgY29uc3QgcGF0aCA9IG9wdHMucGF0aDtcbiAgICBjb25zdCB1cmwgPSBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2NvbnRlbnRzLyR7ZW5jb2RlUGF0aChwYXRoKX1gO1xuICAgIGxldCBzaGE6IHN0cmluZyB8IG51bGwgPSBvcHRzLmV4cGVjdGVkU2hhID8/IG51bGw7XG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xuXG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDE7IGF0dGVtcHQgPD0gbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xuICAgICAgY29uc3QgYm9keTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICAgIG1lc3NhZ2U6IG9wdHMubWVzc2FnZSxcbiAgICAgICAgY29udGVudDogb3B0cy5jb250ZW50QmFzZTY0LFxuICAgICAgICBicmFuY2g6IHRoaXMuc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgfTtcbiAgICAgIGlmIChzaGEpIGJvZHkuc2hhID0gc2hhO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ1BVVCcsIHVybCwgYm9keSk7XG4gICAgICAgIGNvbnN0IG91dCA9IHJlcyBhcyB7IGNvbnRlbnQ6IHsgc2hhOiBzdHJpbmc7IGh0bWxfdXJsOiBzdHJpbmc7IHBhdGg6IHN0cmluZyB9IH07XG4gICAgICAgIHJldHVybiB7IHBhdGg6IG91dC5jb250ZW50LnBhdGgsIHNoYTogb3V0LmNvbnRlbnQuc2hhLCB1cmw6IG91dC5jb250ZW50Lmh0bWxfdXJsIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XG4gICAgICAgIGlmIChlcnIuc3RhdHVzID09PSA0MjIgJiYgIXNoYSkge1xuICAgICAgICAgIC8vIEZpbGUgYWxyZWFkeSBleGlzdHM7IGZldGNoIGl0cyBzaGEgYW5kIHJldHJ5IG9uY2UuXG4gICAgICAgICAgc2hhID0gYXdhaXQgdGhpcy5nZXRGaWxlU2hhKHBhdGgpO1xuICAgICAgICAgIGlmICghc2hhKSB0aHJvdyBlcnI7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFlcnIucmV0cmlhYmxlIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGBwdXRGaWxlOiBleGhhdXN0ZWQgYXR0ZW1wdHMgZm9yICR7cGF0aH1gKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb21taXQgc2V2ZXJhbCBmaWxlcyB3aXRoIG9uZSBicmFuY2ggdXBkYXRlLiBUaGUgQ29udGVudHMgQVBJIGNyZWF0ZXMgb25lXG4gICAqIGNvbW1pdCBwZXIgUFVULCBzbyByYXBpZCBmbHVzaGVzIHJhY2UgZWFjaCBvdGhlciBvbiB0aGUgYnJhbmNoIGhlYWQuIFRoaXNcbiAgICogdXNlcyB0aGUgbG93ZXItbGV2ZWwgR2l0IERhdGEgQVBJIGluc3RlYWQ6IHVwbG9hZCBibG9icywgYnVpbGQgYSB0cmVlLFxuICAgKiBjcmVhdGUgb25lIGNvbW1pdCwgdGhlbiBtb3ZlIHRoZSBicmFuY2ggcmVmIG9uY2UuIElmIGFub3RoZXIgd3JpdGVyIG1vdmVzXG4gICAqIHRoZSBicmFuY2ggZmlyc3QsIHJlYmFzZSB0aGlzIHRyZWUgcGF0Y2ggb250byB0aGUgbGF0ZXN0IGhlYWQgYW5kIHJldHJ5LlxuICAgKi9cbiAgYXN5bmMgY29tbWl0RmlsZXMob3B0czogQ29tbWl0RmlsZXNPcHRpb25zKTogUHJvbWlzZTxDb21taXRGaWxlc1Jlc3VsdD4ge1xuICAgIGlmIChvcHRzLmZpbGVzLmxlbmd0aCA9PT0gMCkgdGhyb3cgbmV3IEVycm9yKCdjb21taXRGaWxlczogbm8gZmlsZXMgdG8gY29tbWl0Jyk7XG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xuICAgIGxldCBsYXN0RXJyOiB1bmtub3duID0gbnVsbDtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGJsb2JzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgICAgb3B0cy5maWxlcy5tYXAoYXN5bmMgKGZpbGUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG91dCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L2Jsb2JzYCxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGZpbGUuY29udGVudEJhc2U2NCxcbiAgICAgICAgICAgICAgICBlbmNvZGluZzogJ2Jhc2U2NCcsXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBwYXRoOiBmaWxlLnBhdGgsXG4gICAgICAgICAgICAgIHNoYTogKG91dCBhcyB7IHNoYTogc3RyaW5nIH0pLnNoYSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSlcbiAgICAgICAgKTtcblxuICAgICAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XG4gICAgICAgIGNvbnN0IHRyZWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvdHJlZXNgLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGJhc2VfdHJlZTogaGVhZC50cmVlU2hhLFxuICAgICAgICAgICAgdHJlZTogYmxvYnMubWFwKChibG9iKSA9PiAoe1xuICAgICAgICAgICAgICBwYXRoOiBibG9iLnBhdGgsXG4gICAgICAgICAgICAgIG1vZGU6ICcxMDA2NDQnLFxuICAgICAgICAgICAgICB0eXBlOiAnYmxvYicsXG4gICAgICAgICAgICAgIHNoYTogYmxvYi5zaGEsXG4gICAgICAgICAgICB9KSksXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICBjb25zdCB0cmVlU2hhID0gKHRyZWUgYXMgeyBzaGE6IHN0cmluZyB9KS5zaGE7XG4gICAgICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICdQT1NUJyxcbiAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9jb21taXRzYCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXG4gICAgICAgICAgICB0cmVlOiB0cmVlU2hhLFxuICAgICAgICAgICAgcGFyZW50czogW2hlYWQuc2hhXSxcbiAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGNvbW1pdE91dCA9IGNvbW1pdCBhcyB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nIH07XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICAgICAnUEFUQ0gnLFxuICAgICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNoYTogY29tbWl0T3V0LnNoYSxcbiAgICAgICAgICAgICAgZm9yY2U6IGZhbHNlLFxuICAgICAgICAgICAgfVxuICAgICAgICAgICk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGlmIChpc0NvbmZsaWN0KGVycikgJiYgYXR0ZW1wdCA8IG1heEF0dGVtcHRzKSB7XG4gICAgICAgICAgICBsYXN0RXJyID0gZXJyO1xuICAgICAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGNvbW1pdFNoYTogY29tbWl0T3V0LnNoYSxcbiAgICAgICAgICB1cmw6IGNvbW1pdE91dC5odG1sX3VybCxcbiAgICAgICAgICBmaWxlczogb3B0cy5maWxlcy5tYXAoKGZpbGUpID0+IGZpbGUucGF0aCksXG4gICAgICAgIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgbGFzdEVyciA9IGVycjtcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XG4gICAgICAgIGlmICgoIWVyci5yZXRyaWFibGUgJiYgIWlzQ29uZmxpY3QoZXJyKSkgfHwgYXR0ZW1wdCA9PT0gbWF4QXR0ZW1wdHMpIHRocm93IGVycjtcbiAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aHJvdyBsYXN0RXJyIGluc3RhbmNlb2YgRXJyb3IgPyBsYXN0RXJyIDogbmV3IEVycm9yKCdjb21taXRGaWxlczogZXhoYXVzdGVkIGF0dGVtcHRzJyk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGdldEJyYW5jaEhlYWQoKTogUHJvbWlzZTx7IHNoYTogc3RyaW5nOyB0cmVlU2hhOiBzdHJpbmcgfT4ge1xuICAgIGNvbnN0IHJlZiA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgJ0dFVCcsXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9yZWYvaGVhZHMvJHtlbmNvZGVQYXRoKHRoaXMuc2V0dGluZ3MuYnJhbmNoKX1gXG4gICAgKTtcbiAgICBjb25zdCBoZWFkU2hhID0gKHJlZiBhcyB7IG9iamVjdDogeyBzaGE6IHN0cmluZyB9IH0pLm9iamVjdC5zaGE7XG4gICAgY29uc3QgY29tbWl0ID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAnR0VUJyxcbiAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L2NvbW1pdHMvJHtoZWFkU2hhfWBcbiAgICApO1xuICAgIHJldHVybiB7XG4gICAgICBzaGE6IGhlYWRTaGEsXG4gICAgICB0cmVlU2hhOiAoY29tbWl0IGFzIHsgdHJlZTogeyBzaGE6IHN0cmluZyB9IH0pLnRyZWUuc2hhLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZldGNoSnNvbihtZXRob2Q6IHN0cmluZywgcGF0aDogc3RyaW5nLCBib2R5PzogdW5rbm93bik6IFByb21pc2U8dW5rbm93bj4ge1xuICAgIGNvbnN0IHVybCA9IHBhdGguc3RhcnRzV2l0aCgnaHR0cCcpID8gcGF0aCA6IGAke0FQSV9CQVNFfSR7cGF0aH1gO1xuICAgIGNvbnN0IGluaXQ6IFJlcXVlc3RJbml0ID0ge1xuICAgICAgbWV0aG9kLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dGhpcy5zZXR0aW5ncy5wYXR9YCxcbiAgICAgICAgQWNjZXB0OiAnYXBwbGljYXRpb24vdm5kLmdpdGh1Yitqc29uJyxcbiAgICAgICAgJ1gtR2l0SHViLUFwaS1WZXJzaW9uJzogJzIwMjItMTEtMjgnLFxuICAgICAgICAuLi4oYm9keSA/IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IDoge30pLFxuICAgICAgfSxcbiAgICAgIC4uLihib2R5ID8geyBib2R5OiBKU09OLnN0cmluZ2lmeShib2R5KSB9IDoge30pLFxuICAgIH07XG4gICAgbGV0IHJlczogUmVzcG9uc2U7XG4gICAgdHJ5IHtcbiAgICAgIHJlcyA9IGF3YWl0IGZldGNoKHVybCwgaW5pdCk7XG4gICAgfSBjYXRjaCAobmV0RXJyKSB7XG4gICAgICB0aHJvdyBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgICBzdGF0dXM6IDAsXG4gICAgICAgIGJvZHk6IG51bGwsXG4gICAgICAgIG1lc3NhZ2U6IGBuZXR3b3JrOiAke2Rlc2NyaWJlRXJyb3IobmV0RXJyKS5tZXNzYWdlfWAsXG4gICAgICAgIHJldHJpYWJsZTogdHJ1ZSxcbiAgICAgICAgY2F0ZWdvcnk6ICduZXR3b3JrJyxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gMjA0KSByZXR1cm4gbnVsbDtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICBpZiAodGV4dCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBwYXJzZWQgPSB0ZXh0O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBgJHttZXRob2R9ICR7cGF0aH1gKTtcbiAgICByZXR1cm4gcGFyc2VkO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBtYWtlRXJyb3IocmVzOiBSZXNwb25zZSwgbGFiZWw6IHN0cmluZyk6IFByb21pc2U8R2l0SHViRXJyb3I+IHtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICBpZiAodGV4dCkgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBsYWJlbCk7XG4gIH1cblxuICBwcml2YXRlIG1ha2VFcnJvckZyb21QYXJzZWQocmVzOiBSZXNwb25zZSwgYm9keTogdW5rbm93biwgbGFiZWw6IHN0cmluZyk6IEdpdEh1YkVycm9yIHtcbiAgICBjb25zdCBtc2cgPVxuICAgICAgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmIGJvZHkgJiYgJ21lc3NhZ2UnIGluIGJvZHlcbiAgICAgICAgPyBTdHJpbmcoKGJvZHkgYXMgeyBtZXNzYWdlOiB1bmtub3duIH0pLm1lc3NhZ2UpXG4gICAgICAgIDogcmVzLnN0YXR1c1RleHQ7XG4gICAgbGV0IGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXSA9ICd1bmtub3duJztcbiAgICBsZXQgcmV0cmlhYmxlID0gZmFsc2U7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSB8fCByZXMuc3RhdHVzID09PSA0MDMpIHtcbiAgICAgIC8vIDQwMyBjYW4gYmUgZWl0aGVyIGF1dGggb3IgcmF0ZSBsaW1pdDsgY2hlY2sgaGVhZGVycy5cbiAgICAgIGNvbnN0IHJhdGUgPSByZXMuaGVhZGVycy5nZXQoJ3gtcmF0ZWxpbWl0LXJlbWFpbmluZycpO1xuICAgICAgaWYgKHJhdGUgPT09ICcwJyB8fCAvcmF0ZSBsaW1pdC9pLnRlc3QobXNnKSkge1xuICAgICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNhdGVnb3J5ID0gJ2F1dGgnO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSB7XG4gICAgICBjYXRlZ29yeSA9ICdub3QtZm91bmQnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA5IHx8IHJlcy5zdGF0dXMgPT09IDQyMikge1xuICAgICAgY2F0ZWdvcnkgPSAnY29uZmxpY3QnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA+PSA1MDApIHtcbiAgICAgIGNhdGVnb3J5ID0gJ3NlcnZlcic7XG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDI5KSB7XG4gICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgc3RhdHVzOiByZXMuc3RhdHVzLFxuICAgICAgYm9keSxcbiAgICAgIG1lc3NhZ2U6IGAke2xhYmVsfSBcdTIxOTIgJHtyZXMuc3RhdHVzfTogJHttc2d9YCxcbiAgICAgIHJldHJpYWJsZSxcbiAgICAgIGNhdGVnb3J5LFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IHBhcnNlUmF0ZUxpbWl0UmVzZXQocmVzLmhlYWRlcnMpIDogbnVsbCxcbiAgICB9KTtcbiAgfVxufVxuXG4vKipcbiAqIEJlc3QtZWZmb3J0IHBhcnNlIG9mIHdoZW4gdGhlIGN1cnJlbnQgcmF0ZS1saW1pdCB3aW5kb3cgZW5kcy4gR2l0SHViJ3NcbiAqIHByaW1hcnkgbGltaXQgcmVwb3J0cyBgWC1SYXRlTGltaXQtUmVzZXRgIGFzIGEgVW5peCBlcG9jaCBpbiBzZWNvbmRzLlxuICogU2Vjb25kYXJ5IC8gYWJ1c2UgbGltaXRzIHVzZSBgUmV0cnktQWZ0ZXJgLCB3aGljaCBpcyBlaXRoZXIgYW4gSFRUUC1kYXRlXG4gKiBvciBhIGRlbHRhIGluIHNlY29uZHMgXHUyMDE0IHdlIG5vcm1hbGl6ZSBib3RoIHRvIGVwb2NoIHNlY29uZHMuXG4gKi9cbmZ1bmN0aW9uIHBhcnNlUmF0ZUxpbWl0UmVzZXQoaGVhZGVyczogSGVhZGVycyk6IG51bWJlciB8IG51bGwge1xuICBjb25zdCByZXNldCA9IGhlYWRlcnMuZ2V0KCd4LXJhdGVsaW1pdC1yZXNldCcpO1xuICBpZiAocmVzZXQpIHtcbiAgICBjb25zdCBuID0gTnVtYmVyLnBhcnNlSW50KHJlc2V0LCAxMCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShuKSAmJiBuID4gMCkgcmV0dXJuIG47XG4gIH1cbiAgY29uc3QgcmV0cnlBZnRlciA9IGhlYWRlcnMuZ2V0KCdyZXRyeS1hZnRlcicpO1xuICBpZiAocmV0cnlBZnRlcikge1xuICAgIGNvbnN0IGRlbHRhID0gTnVtYmVyLnBhcnNlSW50KHJldHJ5QWZ0ZXIsIDEwKTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGRlbHRhKSAmJiBkZWx0YSA+PSAwKSB7XG4gICAgICByZXR1cm4gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCkgKyBkZWx0YTtcbiAgICB9XG4gICAgY29uc3QgYXNEYXRlID0gRGF0ZS5wYXJzZShyZXRyeUFmdGVyKTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGFzRGF0ZSkpIHJldHVybiBNYXRoLmZsb29yKGFzRGF0ZSAvIDEwMDApO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBlbmNvZGVQYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIEVuY29kZSBzZWdtZW50cyBpbmRpdmlkdWFsbHkgc28gc2xhc2hlcyByZW1haW4uXG4gIHJldHVybiBwYXRoLnNwbGl0KCcvJykubWFwKGVuY29kZVVSSUNvbXBvbmVudCkuam9pbignLycpO1xufVxuXG5mdW5jdGlvbiBiYWNrb2ZmTXMoYXR0ZW1wdDogbnVtYmVyLCBlcnI6IEdpdEh1YkVycm9yKTogbnVtYmVyIHtcbiAgLy8gRXhwb25lbnRpYWwgd2l0aCBqaXR0ZXI7IGJ1bXAgaGlnaGVyIGZvciByYXRlLWxpbWl0IHJlc3BvbnNlcy5cbiAgY29uc3QgYmFzZSA9IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnID8gNTAwMCA6IDUwMDtcbiAgY29uc3Qgaml0dGVyID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNDAwKTtcbiAgcmV0dXJuIE1hdGgubWluKDYwXzAwMCwgYmFzZSAqIDIgKiogKGF0dGVtcHQgLSAxKSArIGppdHRlcik7XG59XG5cbmZ1bmN0aW9uIGlzQ29uZmxpY3QoZXJyOiB1bmtub3duKTogZXJyIGlzIEdpdEh1YkVycm9yIHtcbiAgcmV0dXJuIGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ2NvbmZsaWN0Jztcbn1cblxuZnVuY3Rpb24gc2xlZXAobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBieXRlcyBpcyBhIFVURi04IHN0cmluZyBvZiBKU09OOyBlbmNvZGUgdG8gYmFzZTY0IHRoZSBzYWZlIHdheS5cbiAgY29uc3QgdXRmOCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShieXRlcyk7XG4gIGxldCBiaW4gPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIHV0ZjgpIGJpbiArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShiaW4pO1xufVxuIiwgImltcG9ydCB7IFRXRUVUX1VSTF9QUkVGSVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDb21tdW5pdHlOb3RlLFxuICBNZWRpYUl0ZW0sXG4gIFR3ZWV0Q2FyZCxcbiAgVHdlZXRUeXBlLFxuICBVbmF2YWlsYWJsZVR3ZWV0LFxuICBVcmxFbnRpdHksXG4gIFVzZXJTbmFwc2hvdCxcbn0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTm9ybWFsaXplIEdyYXBoUUwgcmVzcG9uc2UgcGF5bG9hZHMgZnJvbSBYJ3MgaW50ZXJuYWwgQVBJIGludG9cbiAqIGBDYW5vbmljYWxUd2VldGBzLiBNYW55IGVuZHBvaW50cyBzaGFyZSBhIHNpbWlsYXIgdHdlZXQgc2hhcGUgYnV0IHdyYXAgaXQgaW5cbiAqIGRpZmZlcmVudCBlbnZlbG9wZXM7IHRoaXMgbW9kdWxlIHdhbGtzIHRoZSBzdHJ1Y3R1cmUgZGVmZW5zaXZlbHkuXG4gKlxuICogVGhlIHBhcnNlciBpcyBpbnRlbnRpb25hbGx5IHBlcm1pc3NpdmU6IGl0IHdpbGwgc2lsZW50bHkgc2tpcCBlbnRyaWVzIGl0XG4gKiBjYW4ndCByZWNvZ25pemUgYXMgdHdlZXRzIChjdXJzb3JzLCBhZHMsIGdhcCBlbnRyaWVzLCBtb2R1bGVzIG9mIG90aGVyXG4gKiB0d2VldHMsIHRvbWJzdG9uZXMpLiBJdCB0aHJvd3MgKm9ubHkqIHdoZW4gZ2l2ZW4gYSBwYXlsb2FkIGl0IGRvZXNuJ3Qga25vd1xuICogaG93IHRvIHdhbGsgYXQgYWxsIFx1MjAxNCB0aG9zZSBjYXNlcyBhcmUgY2F1Z2h0IGFuZCBxdWFyYW50aW5lZCB1cHN0cmVhbS5cbiAqL1xuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZUNvbnRleHQge1xuICBjYXB0dXJlZEF0OiBzdHJpbmc7XG4gIHJ1bklkOiBzdHJpbmc7XG4gIGVuZHBvaW50OiBzdHJpbmc7XG4gIGFsbG93ZWRIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+O1xuICBzb3VyY2VVcmw/OiBzdHJpbmcgfCBudWxsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZVJlc3VsdCB7XG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcbiAgb2JzZXJ2ZWRfaWRzOiBzdHJpbmdbXTtcbiAgdW5hdmFpbGFibGVfdHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W107XG4gIC8qKlxuICAgKiBUd2VldC1zaGFwZWQgbm9kZXMgdGhlIHdhbGtlciBzYXcgKGhhZCBhIGByZXN0X2lkYCkgYnV0IGNvdWxkbid0IHR1cm5cbiAgICogaW50byBhIGZ1bGwgYENhbm9uaWNhbFR3ZWV0YCBcdTIwMTQgdHlwaWNhbGx5IGJlY2F1c2UgdGhlIGVtYmVkZGVkIHVzZXJcbiAgICogaW5mbyB3YXMgbWlzc2luZyBvciB0aGUgZW50cnkgd2FzIGEgbWVkaWEtb25seSB0aHVtYm5haWwgY2FyZCBmcm9tXG4gICAqIHRoZSBVc2VyTWVkaWEgZW5kcG9pbnQuIE9ubHkgSURzIHdpdGggYSB0cnVzdHdvcnRoeSBoYW5kbGUgZnJvbSB0aGVcbiAgICogdHdlZXQgbm9kZSBpdHNlbGYgYXJlIHJldHVybmVkOyBvdGhlcndpc2UgdGhlIGJhY2tncm91bmQgY2Fubm90IGJ1aWxkXG4gICAqIGEgcmVsaWFibGUgLzxoYW5kbGU+L3N0YXR1cy88aWQ+IGRldGFpbCBVUkwuXG4gICAqL1xuICBwYXJ0aWFsX2lkczogQXJyYXk8eyB0d2VldF9pZDogc3RyaW5nOyBoaW50X2hhbmRsZTogc3RyaW5nIHwgbnVsbCB9Pjtcbn1cblxuLy8gWCB0d2VldCBJRHMgYXJlIDY0LWJpdCBwb3NpdGl2ZSBpbnRlZ2VycyBzZXJpYWxpemVkIGFzIGRlY2ltYWwgc3RyaW5ncy5cbi8vIFRoZXkndmUgZ3Jvd24gdG8gMTkgY2hhcnMgKH4xLjVlMTgpIGJ5IDIwMjYuIFJlamVjdCBhbnl0aGluZyB0aGF0IGRvZXNuJ3Rcbi8vIG1hdGNoIHRoaXMgc2hhcGUgXHUyMDE0IG90aGVyd2lzZSBzcHVyaW91cyBjYXJkIElEcywgY3Vyc29yIHN0cmluZ3MsIGFkIHNsb3Rcbi8vIElEcywgZXRjLiBlbmQgdXAgaW4gdGhlIHBhcnRpYWwtY2FwdHVyZSBxdWV1ZSBhbmQgdGhlIGNyYXdsIGxvb3Bcbi8vIG5hdmlnYXRlcyB0byBpbnZhbGlkIFVSTHMgdGhhdCBzaG93IFwidGhpcyBwYWdlIGRvZXNuJ3QgZXhpc3RcIi5cbmNvbnN0IFRXRUVUX0lEX1JFID0gL15cXGR7MTUsMjB9JC87XG5cbi8vIE9ubHkgb25lIGVuZHBvaW50IGFjdHVhbGx5IGV4cG9zZXMgdGhlIGZhaWx1cmUgbW9kZSB0aGUgcGFydGlhbC1jYXB0dXJlXG4vLyBxdWV1ZSBleGlzdHMgZm9yIFx1MjAxNCB0aGUgTWVkaWEgdGFiJ3MgYFVzZXJNZWRpYWAgcXVlcnkgcmV0dXJuaW5nXG4vLyB0aHVtYm5haWwtb25seSBlbnRyaWVzIHdpdGhvdXQgYSBwb3B1bGF0ZWQgYXV0aG9yIGJsb2NrLiBFdmVyeSBvdGhlclxuLy8gZW5kcG9pbnQgdGhhdCBoYW5kcyB1cyBhIGBUd2VldGAgc2hhcGUgZ2l2ZXMgdXMgdGhlIGZ1bGwgZW50cnk7IGlmXG4vLyBgYnVpbGRUd2VldGAgZmFpbHMgdGhlcmUgaXQncyBhIHJlYWwgZXJyb3IsIG5vdCBcImdvIHJlLWZldGNoIHRoaXNcIi5cbi8vIFJlc3RyaWN0aW5nIHBhcnRpYWwtaWQgZW1pc3Npb24gdG8gVXNlck1lZGlhIHN0b3BzIHRoZSBmbG9vZHMgb2Zcbi8vIGZhbHNlIHBvc2l0aXZlcyByZXBvcnRlZCBvbiBSZXBsaWVzIC8gVHdlZXREZXRhaWwgLyBTZWFyY2hUaW1lbGluZS5cbmNvbnN0IFBBUlRJQUxfT0tfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJNZWRpYSddKTtcblxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShwYXlsb2FkOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBOb3JtYWxpemVSZXN1bHQge1xuICBjb25zdCByYXdUd2VldHMgPSBjb2xsZWN0VHdlZXRzKHBheWxvYWQpO1xuICBjb25zdCB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10gPSBbXTtcbiAgY29uc3QgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXSA9IFtdO1xuICBjb25zdCBvYnNlcnZlZDogc3RyaW5nW10gPSBbXTtcbiAgY29uc3QgYnVpbHQgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgcGFydGlhbE1hcCA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmcgfCBudWxsPigpO1xuICBjb25zdCBjb2xsZWN0UGFydGlhbHMgPSBQQVJUSUFMX09LX0VORFBPSU5UUy5oYXMoY3R4LmVuZHBvaW50KTtcbiAgZm9yIChjb25zdCByYXcgb2YgcmF3VHdlZXRzKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVuYXZhaWxhYmxlID0gcGlja1VuYXZhaWxhYmxlVHdlZXQocmF3LCBjdHgpO1xuICAgICAgaWYgKHVuYXZhaWxhYmxlKSB7XG4gICAgICAgIHVuYXZhaWxhYmxlVHdlZXRzLnB1c2godW5hdmFpbGFibGUpO1xuICAgICAgICBvYnNlcnZlZC5wdXNoKHVuYXZhaWxhYmxlLnR3ZWV0X2lkKTtcbiAgICAgICAgYnVpbHQuYWRkKHVuYXZhaWxhYmxlLnR3ZWV0X2lkKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBjb25zdCB0ID0gYnVpbGRUd2VldChyYXcsIGN0eCk7XG4gICAgICBpZiAoIXQpIHtcbiAgICAgICAgaWYgKGNvbGxlY3RQYXJ0aWFscykge1xuICAgICAgICAgIC8vIE9ubHkgZW5xdWV1ZSByZWFsLXR3ZWV0IHNoZWxscyB3aXRoIGEgdHJ1c3R3b3J0aHkgaGFuZGxlIChub3RcbiAgICAgICAgICAvLyB0b21ic3RvbmVzLCBzdHJpcHBlZCBub2RlcyBsYWNraW5nIGEgbGVnYWN5IGJsb2NrLCBnYXJiYWdlIElEcyxcbiAgICAgICAgICAvLyBvciBJRHMgdGhhdCB3b3VsZCByZXF1aXJlIGd1ZXNzaW5nIHRoZSBhdXRob3IgZnJvbSB0aGUgcGFnZSkuXG4gICAgICAgICAgY29uc3QgcGFydGlhbCA9IHBpY2tQYXJ0aWFsKHJhdyk7XG4gICAgICAgICAgaWYgKHBhcnRpYWwpIHBhcnRpYWxNYXAuc2V0KHBhcnRpYWwudHdlZXRfaWQsIHBhcnRpYWwuaGludF9oYW5kbGUpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIGJ1aWx0LmFkZCh0LnR3ZWV0X2lkKTtcbiAgICAgIGlmIChjdHguYWxsb3dlZEhhbmRsZXMuc2l6ZSA9PT0gMCB8fCBjdHguYWxsb3dlZEhhbmRsZXMuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgdHdlZXRzLnB1c2godCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBPbmUgYmFkIGVudHJ5IHNob3VsZG4ndCB0YWtlIGRvd24gdGhlIHdob2xlIGJhdGNoLlxuICAgIH1cbiAgfVxuICAvLyBBbnl0aGluZyB0aGF0IGVuZGVkIHVwIGluIHBhcnRpYWxNYXAgYnV0IEFMU08gY2FtZSBiYWNrIGFzIGEgYnVpbHRcbiAgLy8gdHdlZXQgKGRpZmZlcmVudCB3YWxrZXIgcGFzcywgc2FtZSBpZCkgaXNuJ3QgYWN0dWFsbHkgcGFydGlhbC5cbiAgY29uc3QgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcbiAgZm9yIChjb25zdCBbaWQsIGhpbnRdIG9mIHBhcnRpYWxNYXApIHtcbiAgICBpZiAoYnVpbHQuaGFzKGlkKSkgY29udGludWU7XG4gICAgcGFydGlhbF9pZHMucHVzaCh7IHR3ZWV0X2lkOiBpZCwgaGludF9oYW5kbGU6IGhpbnQgfSk7XG4gIH1cbiAgcmV0dXJuIHsgdHdlZXRzLCBvYnNlcnZlZF9pZHM6IG9ic2VydmVkLCB1bmF2YWlsYWJsZV90d2VldHM6IHVuYXZhaWxhYmxlVHdlZXRzLCBwYXJ0aWFsX2lkcyB9O1xufVxuXG5mdW5jdGlvbiBwaWNrVW5hdmFpbGFibGVUd2VldChub2RlOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBVbmF2YWlsYWJsZVR3ZWV0IHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBpZiAobi5fX3R5cGVuYW1lICE9PSAnVHdlZXRUb21ic3RvbmUnKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCB0d2VldElkID1cbiAgICBzdHJPck51bGwobi5yZXN0X2lkKSA/P1xuICAgIHBpY2tUd2VldElkRnJvbVVybHMobm9kZSkgPz9cbiAgICAoY3R4LnNvdXJjZVVybCA/IHR3ZWV0SWRGcm9tVHdlZXRVcmwoY3R4LnNvdXJjZVVybCkgOiBudWxsKTtcbiAgaWYgKCF0d2VldElkIHx8ICFUV0VFVF9JRF9SRS50ZXN0KHR3ZWV0SWQpKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCB1bmF2YWlsYWJsZVRleHQgPSBwaWNrVG9tYnN0b25lVGV4dChub2RlKTtcbiAgcmV0dXJuIHtcbiAgICB0d2VldF9pZDogdHdlZXRJZCxcbiAgICBhY2NvdW50X2hhbmRsZTpcbiAgICAgIHBpY2tIYW5kbGVGcm9tVHdlZXRVcmxzKG5vZGUsIHR3ZWV0SWQpID8/XG4gICAgICAoY3R4LnNvdXJjZVVybCA/IGhhbmRsZUZyb21Ud2VldFVybChjdHguc291cmNlVXJsLCB0d2VldElkKSA6IG51bGwpLFxuICAgIHVuYXZhaWxhYmxlX2RldGVjdGVkX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICB1bmF2YWlsYWJsZV9yZWFzb246IGNsYXNzaWZ5VW5hdmFpbGFibGVSZWFzb24odW5hdmFpbGFibGVUZXh0KSxcbiAgICB1bmF2YWlsYWJsZV90ZXh0OiB1bmF2YWlsYWJsZVRleHQsXG4gICAgdW5hdmFpbGFibGVfc291cmNlX3VybDogY3R4LnNvdXJjZVVybCA/PyBudWxsLFxuICB9O1xufVxuXG5mdW5jdGlvbiBwaWNrVHdlZXRJZEZyb21VcmxzKG5vZGU6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBjdXIgPSBzdGFjay5wb3AoKTtcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGNvbnN0IGlkID0gdHdlZXRJZEZyb21Ud2VldFVybChjdXIpO1xuICAgICAgaWYgKGlkKSByZXR1cm4gaWQ7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHNlZW4uaGFzKGN1ciBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChjdXIgYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgY3VyKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gdHdlZXRJZEZyb21Ud2VldFVybChyYXdVcmw6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICB0cnkge1xuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmF3VXJsLCBUV0VFVF9VUkxfUFJFRklYKTtcbiAgICBpZiAodXJsLmhvc3RuYW1lICE9PSAneC5jb20nICYmIHVybC5ob3N0bmFtZSAhPT0gJ3R3aXR0ZXIuY29tJykgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC9bQS1aYS16MC05X117MSwxNX1cXC9zdGF0dXNcXC8oXFxkezE1LDIwfSkoPzpcXC98JCkvKTtcbiAgICByZXR1cm4gbWF0Y2g/LlsxXSA/PyBudWxsO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBwaWNrVG9tYnN0b25lVGV4dChub2RlOiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gIGNvbnN0IHN0cmluZ3M6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgY3VyID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKHR5cGVvZiBjdXIgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25zdCB0cmltbWVkID0gY3VyLnRyaW0oKTtcbiAgICAgIGlmIChcbiAgICAgICAgdHJpbW1lZC5sZW5ndGggPj0gNCAmJlxuICAgICAgICAhdHJpbW1lZC5zdGFydHNXaXRoKCdodHRwOi8vJykgJiZcbiAgICAgICAgIXRyaW1tZWQuc3RhcnRzV2l0aCgnaHR0cHM6Ly8nKVxuICAgICAgKSB7XG4gICAgICAgIHN0cmluZ3MucHVzaCh0cmltbWVkKTtcbiAgICAgIH1cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY3VyID09PSBudWxsIHx8IHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAoc2Vlbi5oYXMoY3VyIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBjdXIpIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIGNvbnN0IHByZWZlcnJlZCA9IHN0cmluZ3MuZmluZCgocykgPT5cbiAgICAvXFxiKGNvcHlyaWdodHxkbWNhfHVuYXZhaWxhYmxlfHdpdGhoZWxkfHJlbW92ZWR8ZGVsZXRlZHx2aW9sYXR8c3VzcGVuZGVkKVxcYi9pLnRlc3QocylcbiAgKTtcbiAgcmV0dXJuIHByZWZlcnJlZCA/PyBzdHJpbmdzWzBdID8/IG51bGw7XG59XG5cbmZ1bmN0aW9uIGNsYXNzaWZ5VW5hdmFpbGFibGVSZWFzb24odGV4dDogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAoIXRleHQpIHJldHVybiBudWxsO1xuICBpZiAoL1xcYihjb3B5cmlnaHR8ZG1jYSlcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ2NvcHlyaWdodCc7XG4gIGlmICgvXFxid2l0aGhlbGRcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3dpdGhoZWxkJztcbiAgaWYgKC9cXGJkZWxldGVkfHJlbW92ZWRcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3JlbW92ZWQnO1xuICBpZiAoL1xcYnN1c3BlbmRlZFxcYi9pLnRlc3QodGV4dCkpIHJldHVybiAnc3VzcGVuZGVkJztcbiAgaWYgKC9cXGJ1bmF2YWlsYWJsZXxub3QgYXZhaWxhYmxlXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICd1bmF2YWlsYWJsZSc7XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBwaWNrUGFydGlhbChub2RlOiB1bmtub3duKTogeyB0d2VldF9pZDogc3RyaW5nOyBoaW50X2hhbmRsZTogc3RyaW5nIHwgbnVsbCB9IHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAvLyBEZWxldGVkIHR3ZWV0cyBzdXJmYWNlIGFzIFR3ZWV0VG9tYnN0b25lIFx1MjAxNCB0aGVyZSdzIG5vdGhpbmcgdG8gcmVmZXRjaCxcbiAgLy8gc2tpcCB0aGVtIG9yIHRoZSBjcmF3bCBsb29wIHdpbGwgc3BpbiBvbiBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXG4gIGlmIChuLl9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xuICAvLyBSZXF1aXJlIGEgcmVjb2duaXplZCBUd2VldCB0eXBlbmFtZSBPUiBhIGxlZ2FjeSBibG9jay4gQ3Vyc29ycywgYWRzLFxuICAvLyBtb2R1bGUgaGVhZGVycywgYW5kIHRoZSBsaWtlIGdldCByZWplY3RlZCBoZXJlLlxuICBjb25zdCB0biA9IG4uX190eXBlbmFtZTtcbiAgaWYgKHRuICE9PSAnVHdlZXQnICYmIHRuICE9PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnICYmICFvYmoobi5sZWdhY3kpKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgcmVzdElkID1cbiAgICAodHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgbi5yZXN0X2lkKSB8fFxuICAgICh0eXBlb2Ygb2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0ID09PSAnb2JqZWN0JyAmJlxuICAgICAgKG9iaihvYmoobi50d2VldF9yZXN1bHQpPy5yZXN1bHQpPy5yZXN0X2lkIGFzIHN0cmluZykpO1xuICBpZiAodHlwZW9mIHJlc3RJZCAhPT0gJ3N0cmluZycgfHwgIVRXRUVUX0lEX1JFLnRlc3QocmVzdElkKSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGhpbnRIYW5kbGUgPSBwaWNrSGludEhhbmRsZShub2RlLCByZXN0SWQpO1xuICBpZiAoIWhpbnRIYW5kbGUpIHJldHVybiBudWxsO1xuICByZXR1cm4geyB0d2VldF9pZDogcmVzdElkLCBoaW50X2hhbmRsZTogaGludEhhbmRsZSB9O1xufVxuXG5mdW5jdGlvbiBwaWNrSGludEhhbmRsZShub2RlOiB1bmtub3duLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JyB8fCBub2RlID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIGNvbnN0IHVzZXJSZXN1bHQgPSBvYmoob2JqKG9iaihuLmNvcmUpPy51c2VyX3Jlc3VsdHMpPy5yZXN1bHQpO1xuICByZXR1cm4gKFxuICAgIHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8uY29yZSk/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubGVnYWN5KT8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKG9iaihuLmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHBpY2tIYW5kbGVGcm9tVHdlZXRVcmxzKG5vZGUsIHR3ZWV0SWQpXG4gICk7XG59XG5cbmZ1bmN0aW9uIHBpY2tIYW5kbGVGcm9tVHdlZXRVcmxzKG5vZGU6IHVua25vd24sIHR3ZWV0SWQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGN1ciA9IHN0YWNrLnBvcCgpO1xuICAgIGlmICh0eXBlb2YgY3VyID09PSAnc3RyaW5nJykge1xuICAgICAgY29uc3QgaGFuZGxlID0gaGFuZGxlRnJvbVR3ZWV0VXJsKGN1ciwgdHdlZXRJZCk7XG4gICAgICBpZiAoaGFuZGxlKSByZXR1cm4gaGFuZGxlO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmIChzZWVuLmhhcyhjdXIgYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQoY3VyIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIGN1cikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmZ1bmN0aW9uIGhhbmRsZUZyb21Ud2VldFVybChyYXdVcmw6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIHRyeSB7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChyYXdVcmwsIFRXRUVUX1VSTF9QUkVGSVgpO1xuICAgIGlmICh1cmwuaG9zdG5hbWUgIT09ICd4LmNvbScgJiYgdXJsLmhvc3RuYW1lICE9PSAndHdpdHRlci5jb20nKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBtYXRjaCA9IHVybC5wYXRobmFtZS5tYXRjaCgvXlxcLyhbQS1aYS16MC05X117MSwxNX0pXFwvc3RhdHVzXFwvKFxcZHsxNSwyMH0pKD86XFwvfCQpLyk7XG4gICAgaWYgKCFtYXRjaCB8fCBtYXRjaFsyXSAhPT0gdHdlZXRJZCkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIG1hdGNoWzFdID8/IG51bGw7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNvbGxlY3RUd2VldHMob2JqOiB1bmtub3duKTogdW5rbm93bltdIHtcbiAgLy8gV2FsayB0aGUgcmVzcG9uc2UgdHJlZSBnYXRoZXJpbmcgZXZlcnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSB0d2VldFxuICAvLyByZXN1bHQuIFdlIGxvb2sgZm9yIG5vZGVzIHNoYXBlZCBsaWtlOlxuICAvLyAgIHsgX190eXBlbmFtZT86ICdUd2VldCd8J1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJywgcmVzdF9pZCwgbGVnYWN5IH1cbiAgLy8gYW5kIHVud3JhcCB2aXNpYmlsaXR5IHdyYXBwZXJzLlxuICBjb25zdCBvdXQ6IHVua25vd25bXSA9IFtdO1xuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW29ial07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3Qgbm9kZSA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChub2RlID09PSBudWxsIHx8IG5vZGUgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHNlZW4uaGFzKG5vZGUgYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQobm9kZSBhcyBvYmplY3QpO1xuXG4gICAgaWYgKGxvb2tzTGlrZVR3ZWV0KG5vZGUpKSB7XG4gICAgICBvdXQucHVzaCh1bndyYXBUd2VldChub2RlKSk7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KG5vZGUpKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbm9kZSkgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMobm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIGxvb2tzTGlrZVR3ZWV0KG5vZGU6IHVua25vd24pOiBub2RlIGlzIFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JyB8fCBub2RlID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBjb25zdCB0eXBlbmFtZSA9IG4uX190eXBlbmFtZTtcbiAgaWYgKFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXQnIHx8XG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgfHxcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJ1xuICApIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICAvLyBTb21lIGVudHJpZXMgbGFjayBfX3R5cGVuYW1lIGJ1dCBzdGlsbCBjYXJyeSBsZWdhY3kgKyByZXN0X2lkICsgY29yZS5cbiAgcmV0dXJuIHR5cGVvZiBuLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBuLmxlZ2FjeSA9PT0gJ29iamVjdCcgJiYgbi5sZWdhY3kgIT09IG51bGw7XG59XG5cbmZ1bmN0aW9uIHVud3JhcFR3ZWV0KG5vZGU6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xuICBpZiAobm9kZS5fX3R5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnICYmIHR5cGVvZiBub2RlLnR3ZWV0ID09PSAnb2JqZWN0Jykge1xuICAgIHJldHVybiBub2RlLnR3ZWV0IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICB9XG4gIHJldHVybiBub2RlO1xufVxuXG5mdW5jdGlvbiBidWlsZFR3ZWV0KHJhdzogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogQ2Fub25pY2FsVHdlZXQgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiByYXcgIT09ICdvYmplY3QnIHx8IHJhdyA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHQgPSByYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG5cbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgcmVzdElkID0gc3RyT3JOdWxsKHQucmVzdF9pZCk7XG4gIC8vIGBsZWdhY3lgIGlzIHN0aWxsIHdoZXJlIG1vc3QgZW5nYWdlbWVudCAvIGVudGl0aWVzIGxpdmUgaW4gMjAyNi1lcmEgWFxuICAvLyBwYXlsb2FkcywgYnV0IGFzIG9mIHJlY2VudCBzY2hlbWEgbWlncmF0aW9ucyBzZXZlcmFsIGZpZWxkcyBwcmV2aW91c2x5XG4gIC8vIHRoZXJlIChub3RhYmx5IHRoZSBhdXRob3IgaGFuZGxlKSBoYXZlIG1vdmVkIHRvIHNpYmxpbmcgbG9jYXRpb25zLiBXZVxuICAvLyB0b2xlcmF0ZSBhIG1pc3NpbmcgbGVnYWN5IGhlcmUgYW5kIGxvb2sgdXAgZXZlcnl0aGluZyB2aWEgZmFsbGJhY2tzLlxuICBjb25zdCBsZWdhY3kgPSBvYmoodC5sZWdhY3kpID8/IHt9O1xuICBpZiAoIXJlc3RJZCkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgY29yZSA9IG9iaih0LmNvcmUpO1xuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihjb3JlPy51c2VyX3Jlc3VsdHMpPy5yZXN1bHQpO1xuICAvLyBBdXRob3IgaGFuZGxlOiB0cnkgdGhlIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIGZpcnN0IChjdXJyZW50IFggc2hhcGUpLFxuICAvLyB0aGVuIHRoZSBsZWdhY3kgYGxlZ2FjeS5zY3JlZW5fbmFtZWAsIHRoZW4gYSBjb3VwbGUgb2Ygb2xkZXIgdmFyaWFudHMuXG4gIGNvbnN0IHVzZXJDb3JlTmV3ID0gb2JqKHVzZXJSZXN1bHQ/LmNvcmUpO1xuICBjb25zdCB1c2VyTGVnYWN5ID0gb2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk7XG4gIGNvbnN0IHVzZXJBdmF0YXJPYmogPSBvYmoodXNlclJlc3VsdD8uYXZhdGFyKTtcbiAgY29uc3QgaGFuZGxlID1cbiAgICBzdHJPck51bGwodXNlckNvcmVOZXc/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwodXNlclJlc3VsdD8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKGxlZ2FjeS5zY3JlZW5fbmFtZSk7XG4gIGNvbnN0IGFjY291bnRJZCA9XG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnJlc3RfaWQpID8/XG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LmlkX3N0cikgPz9cbiAgICBzdHJPck51bGwobGVnYWN5LnVzZXJfaWRfc3RyKTtcbiAgaWYgKCFoYW5kbGUgfHwgIWFjY291bnRJZCkgcmV0dXJuIG51bGw7XG4gIC8vIEF1dGhvciBzbmFwc2hvdC4gRGlzcGxheSBuYW1lICsgYXZhdGFyIG1vdmVkIGJldHdlZW4gYGxlZ2FjeWAgYW5kIHRoZVxuICAvLyBuZXcgYGNvcmVgIHN1YnN0cnVjdHVyZSBvdmVyIHRpbWU7IHRoZSByZXN0ICh2ZXJpZmljYXRpb24sIGZvbGxvd2VyXG4gIC8vIGNvdW50cywgYWNjb3VudF9jcmVhdGVkX2F0KSBpcyBzdGlsbCBpbiBgbGVnYWN5YC4gV2Ugc25hcHNob3QgdGhlXG4gIC8vIHdob2xlIFVzZXJTbmFwc2hvdCBwZXIgdHdlZXQgYmVjYXVzZSB0aGVzZSB2YWx1ZXMgZHJpZnQgb3ZlciB0aW1lXG4gIC8vIGFuZCB0aGUgYXQtY2FwdHVyZSBzdGF0ZSBpcyB0aGUgb25seSByZWxpYWJsZSByZWNvcmQuXG4gIGNvbnN0IGF1dGhvciA9IGV4dHJhY3RVc2VyU25hcHNob3QodXNlclJlc3VsdCwgdXNlckNvcmVOZXcsIHVzZXJMZWdhY3ksIHVzZXJBdmF0YXJPYmopO1xuXG4gIGNvbnN0IG5vdGVUd2VldCA9IG9iaihvYmoob2JqKHQubm90ZV90d2VldCk/Lm5vdGVfdHdlZXRfcmVzdWx0cyk/LnJlc3VsdCk7XG4gIGNvbnN0IHRleHRGcm9tTm90ZSA9IHN0ck9yTnVsbChub3RlVHdlZXQ/LnRleHQpO1xuICBjb25zdCB0ZXh0RnJvbUxlZ2FjeSA9IHN0ck9yTnVsbChsZWdhY3kuZnVsbF90ZXh0KSA/PyAnJztcbiAgY29uc3QgdGV4dCA9IHRleHRGcm9tTm90ZSA/PyB0ZXh0RnJvbUxlZ2FjeTtcbiAgY29uc3QgaXNUcnVuY2F0ZWQgPSBkZXRlY3RUcnVuY2F0aW9uKG5vdGVUd2VldCwgbGVnYWN5LCB0ZXh0RnJvbUxlZ2FjeSk7XG4gIGNvbnN0IGNvbW11bml0eU5vdGUgPSBleHRyYWN0Q29tbXVuaXR5Tm90ZSh0LCBsZWdhY3ksIGN0eC5jYXB0dXJlZEF0KTtcblxuICBjb25zdCBlbnRpdGllcyA9IG9iaihsZWdhY3kuZW50aXRpZXMpID8/IHt9O1xuICBjb25zdCBlbnRpdGllc0Zyb21Ob3RlID0gb2JqKG5vdGVUd2VldD8uZW50aXR5X3NldCk7XG4gIGNvbnN0IGhhc2h0YWdzID0gZXh0cmFjdEhhc2h0YWdzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xuICBjb25zdCBtZW50aW9ucyA9IGV4dHJhY3RNZW50aW9ucyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgdXJscyA9IGV4dHJhY3RVcmxzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xuICBjb25zdCBtZWRpYSA9IGV4dHJhY3RNZWRpYShsZWdhY3kpO1xuXG4gIGNvbnN0IHR3ZWV0VHlwZSA9IGNsYXNzaWZ5VHdlZXRUeXBlKHQsIGxlZ2FjeSk7XG5cbiAgLy8gcG9zdGVkX2F0OiBsZWdhY3kuY3JlYXRlZF9hdCByZW1haW5zIHRoZSBjYW5vbmljYWwgbG9jYXRpb247IGlmIHRoYXQnc1xuICAvLyBtaXNzaW5nIGluIGEgZnV0dXJlIHNjaGVtYSB3ZSBmYWxsIGJhY2sgdG8gdG9wLWxldmVsIGNyZWF0ZWRfYXQuXG4gIGNvbnN0IHBvc3RlZEF0ID1cbiAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbChsZWdhY3kuY3JlYXRlZF9hdCkpID8/IHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHQuY3JlYXRlZF9hdCkpO1xuICBpZiAoIXBvc3RlZEF0KSByZXR1cm4gbnVsbDtcblxuICBjb25zdCB2aWV3cyA9IG9iaih0LnZpZXdzKTtcbiAgY29uc3Qgdmlld0NvdW50ID0gbnVtT3JOdWxsKHZpZXdzPy5jb3VudCkgPz8gbnVtT3JOdWxsKHN0ck9yTnVsbCh2aWV3cz8uY291bnQpKTtcblxuICBjb25zdCBjYXJkID0gZXh0cmFjdENhcmQodCk7XG4gIGNvbnN0IHBsYWNlID0gb2JqKGxlZ2FjeS5wbGFjZSk7XG5cbiAgY29uc3QgdHdlZXQ6IENhbm9uaWNhbFR3ZWV0ID0ge1xuICAgIHR3ZWV0X2lkOiByZXN0SWQsXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBhY2NvdW50X2lkOiBhY2NvdW50SWQsXG4gICAgcG9zdGVkX2F0OiBwb3N0ZWRBdCxcbiAgICBmaXJzdF9jYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgbGFzdF9zZWVuX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICBkZWxldGlvbl9kZXRlY3RlZF9hdDogbnVsbCxcbiAgICB1bmF2YWlsYWJsZV9kZXRlY3RlZF9hdDogbnVsbCxcbiAgICB1bmF2YWlsYWJsZV9yZWFzb246IG51bGwsXG4gICAgdW5hdmFpbGFibGVfdGV4dDogbnVsbCxcbiAgICB1bmF2YWlsYWJsZV9zb3VyY2VfdXJsOiBudWxsLFxuICAgIHR3ZWV0X3VybDogYCR7VFdFRVRfVVJMX1BSRUZJWH0vJHtoYW5kbGV9L3N0YXR1cy8ke3Jlc3RJZH1gLFxuICAgIHR3ZWV0X3R5cGU6IHR3ZWV0VHlwZSxcbiAgICBjb252ZXJzYXRpb25faWQ6IHN0ck9yTnVsbChsZWdhY3kuY29udmVyc2F0aW9uX2lkX3N0ciksXG4gICAgcmVwbHlfdG9fdHdlZXRfaWQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0ciksXG4gICAgcmVwbHlfdG9fYWNjb3VudDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zY3JlZW5fbmFtZSksXG4gICAgcmVwbHlfdG9fYWNjb3VudF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b191c2VyX2lkX3N0ciksXG4gICAgcXVvdGVkX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSxcbiAgICByZXR3ZWV0ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChcbiAgICAgIG9iaihvYmoobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCA/P1xuICAgICAgICAobGVnYWN5IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0clxuICAgICksXG4gICAgdGV4dCxcbiAgICB0ZXh0X3Jlc29sdmVkOiByZXNvbHZlU2hvcnRVcmxzKHRleHQsIHVybHMpLFxuICAgIGxhbmc6IHN0ck9yTnVsbChsZWdhY3kubGFuZyksXG4gICAgcG9zc2libHlfc2Vuc2l0aXZlOiBib29sT3JOdWxsKGxlZ2FjeS5wb3NzaWJseV9zZW5zaXRpdmUpLFxuICAgIHNvdXJjZTogc3RyT3JOdWxsKGxlZ2FjeS5zb3VyY2UpID8/IHN0ck9yTnVsbCh0LnNvdXJjZSksXG4gICAgcGxhY2VfZnVsbF9uYW1lOiBzdHJPck51bGwocGxhY2U/LmZ1bGxfbmFtZSksXG4gICAgaGFzaHRhZ3MsXG4gICAgbWVudGlvbnMsXG4gICAgdXJscyxcbiAgICBjYXJkLFxuICAgIG1lZGlhLFxuICAgIGxpa2VfY291bnQ6IG51bU9yWmVybyhsZWdhY3kuZmF2b3JpdGVfY291bnQpLFxuICAgIHJldHdlZXRfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXG4gICAgcmVwbHlfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucmVwbHlfY291bnQpLFxuICAgIHF1b3RlX2NvdW50OiBudW1Pclplcm8obGVnYWN5LnF1b3RlX2NvdW50KSxcbiAgICB2aWV3X2NvdW50OiB2aWV3Q291bnQsXG4gICAgYm9va21hcmtfY291bnQ6IG51bU9yTnVsbChsZWdhY3kuYm9va21hcmtfY291bnQpLFxuICAgIGVuZ2FnZW1lbnRfaGlzdG9yeTogW1xuICAgICAge1xuICAgICAgICBjYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgICAgIGxpa2VzOiBudW1Pclplcm8obGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcbiAgICAgICAgcmV0d2VldHM6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXG4gICAgICAgIHJlcGxpZXM6IG51bU9yWmVybyhsZWdhY3kucmVwbHlfY291bnQpLFxuICAgICAgICBxdW90ZXM6IG51bU9yWmVybyhsZWdhY3kucXVvdGVfY291bnQpLFxuICAgICAgICB2aWV3czogdmlld0NvdW50LFxuICAgICAgICBib29rbWFya3M6IG51bU9yTnVsbChsZWdhY3kuYm9va21hcmtfY291bnQpLFxuICAgICAgfSxcbiAgICBdLFxuICAgIGF1dGhvcixcbiAgICBjb21tdW5pdHlfbm90ZTogY29tbXVuaXR5Tm90ZSxcbiAgICBpc190cnVuY2F0ZWQ6IGlzVHJ1bmNhdGVkLFxuICAgIHdheWJhY2tfdXJsOiBudWxsLFxuICAgIHdheWJhY2tfc3VibWl0dGVkX2F0OiBudWxsLFxuICAgIGNhcHR1cmVfc291cmNlOiAnZXh0ZW5zaW9uJyxcbiAgICBjYXB0dXJlX3J1bl9pZDogY3R4LnJ1bklkLFxuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICB9O1xuXG4gIHJldHVybiB0d2VldDtcbn1cblxuZnVuY3Rpb24gY2xhc3NpZnlUd2VldFR5cGUodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldFR5cGUge1xuICBpZiAobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0IHx8IGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXR3ZWV0JztcbiAgaWYgKGxlZ2FjeS5pbl9yZXBseV90b19zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JlcGx5JztcbiAgaWYgKGxlZ2FjeS5pc19xdW90ZV9zdGF0dXMgPT09IHRydWUgfHwgbGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3F1b3RlJztcbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJykge1xuICAgIC8vIHBhc3MgdGhyb3VnaFxuICB9XG4gIHJldHVybiAnb3JpZ2luYWwnO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy5oYXNodGFncztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgcmV0dXJuIGFyclxuICAgIC5tYXAoKGgpID0+XG4gICAgICB0eXBlb2YgaCA9PT0gJ29iamVjdCcgJiYgaCAmJiAndGV4dCcgaW4gaCA/IFN0cmluZygoaCBhcyB7IHRleHQ6IHVua25vd24gfSkudGV4dCkgOiBudWxsXG4gICAgKVxuICAgIC5maWx0ZXIoKHMpOiBzIGlzIHN0cmluZyA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZ1tdIHtcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXNlcl9tZW50aW9ucztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgcmV0dXJuIGFyclxuICAgIC5tYXAoKHUpID0+XG4gICAgICB0eXBlb2YgdSA9PT0gJ29iamVjdCcgJiYgdSAmJiAnc2NyZWVuX25hbWUnIGluIHVcbiAgICAgICAgPyBTdHJpbmcoKHUgYXMgeyBzY3JlZW5fbmFtZTogdW5rbm93biB9KS5zY3JlZW5fbmFtZSlcbiAgICAgICAgOiBudWxsXG4gICAgKVxuICAgIC5maWx0ZXIoKHMpOiBzIGlzIHN0cmluZyA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdFVybHMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVXJsRW50aXR5W10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy51cmxzO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICBjb25zdCBvdXQ6IFVybEVudGl0eVtdID0gW107XG4gIGZvciAoY29uc3QgdSBvZiBhcnIpIHtcbiAgICBpZiAodHlwZW9mIHUgIT09ICdvYmplY3QnIHx8IHUgPT09IG51bGwpIGNvbnRpbnVlO1xuICAgIGNvbnN0IG8gPSB1IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIGNvbnN0IHNob3J0ID0gc3RyT3JOdWxsKG8udXJsKTtcbiAgICBjb25zdCBleHBhbmRlZCA9IHN0ck9yTnVsbChvLmV4cGFuZGVkX3VybCk7XG4gICAgY29uc3QgZGlzcGxheSA9IHN0ck9yTnVsbChvLmRpc3BsYXlfdXJsKTtcbiAgICBpZiAoIXNob3J0IHx8ICFleHBhbmRlZCkgY29udGludWU7XG4gICAgb3V0LnB1c2goeyBzaG9ydCwgZXhwYW5kZWQsIGRpc3BsYXk6IGRpc3BsYXkgPz8gZXhwYW5kZWQgfSk7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdE1lZGlhKGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW1bXSB7XG4gIGNvbnN0IGV4dGVuZGVkID0gb2JqKGxlZ2FjeS5leHRlbmRlZF9lbnRpdGllcyk7XG4gIGNvbnN0IGZyb21FeHQgPSBleHRlbmRlZCA/IHRvQXJyYXkoZXh0ZW5kZWQubWVkaWEpIDogW107XG4gIGNvbnN0IGZyb21FbnQgPSB0b0FycmF5KG9iaihsZWdhY3kuZW50aXRpZXMpPy5tZWRpYSk7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgbWVyZ2VkID0gWy4uLmZyb21FeHQsIC4uLmZyb21FbnRdLmZpbHRlcigobSkgPT4ge1xuICAgIGlmICh0eXBlb2YgbSAhPT0gJ29iamVjdCcgfHwgbSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGlkID1cbiAgICAgIHN0ck9yTnVsbCgobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikubWVkaWFfa2V5KSA/P1xuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5pZF9zdHIpO1xuICAgIGlmICghaWQpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoc2Vlbi5oYXMoaWQpKSByZXR1cm4gZmFsc2U7XG4gICAgc2Vlbi5hZGQoaWQpO1xuICAgIHJldHVybiB0cnVlO1xuICB9KTtcbiAgcmV0dXJuIG1lcmdlZC5tYXAoKHJhdykgPT4gYnVpbGRNZWRpYShyYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKTtcbn1cblxuZnVuY3Rpb24gYnVpbGRNZWRpYShtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbSB7XG4gIGNvbnN0IHR5cGUgPSBzdHJPck51bGwobS50eXBlKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXTtcbiAgY29uc3Qgb3JpZ2luYWwgPSBwaWNrT3JpZ2luYWxVcmwobSwgdHlwZSk7XG4gIGNvbnN0IGluZm8gPSBvYmoobS5vcmlnaW5hbF9pbmZvKTtcbiAgY29uc3QgdmlkZW9JbmZvID0gb2JqKG0udmlkZW9faW5mbyk7XG4gIGNvbnN0IGR1cmF0aW9uTXMgPSBudW1Pck51bGwodmlkZW9JbmZvPy5kdXJhdGlvbl9taWxsaXMpO1xuICBjb25zdCBhbHRUZXh0ID0gc3RyT3JOdWxsKG0uZXh0X2FsdF90ZXh0KTtcbiAgY29uc3QgbWVkaWFJZCA9XG4gICAgc3RyT3JOdWxsKG0ubWVkaWFfa2V5KSA/P1xuICAgIHN0ck9yTnVsbChtLmlkX3N0cikgPz9cbiAgICBgJHt0eXBlID8/ICdtZWRpYSd9LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMil9YDtcbiAgcmV0dXJuIHtcbiAgICBtZWRpYV9pZDogbWVkaWFJZCxcbiAgICBtZWRpYV90eXBlOiAodHlwZSA/PyAncGhvdG8nKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXSxcbiAgICBvcmlnaW5hbF91cmw6IG9yaWdpbmFsID8/ICcnLFxuICAgIHJlbGVhc2VfYXNzZXRfdXJsOiBudWxsLFxuICAgIHNoYTI1NjogbnVsbCxcbiAgICBieXRlczogbnVsbCxcbiAgICBkdXJhdGlvbl9zZWM6IGR1cmF0aW9uTXMgIT09IG51bGwgPyBkdXJhdGlvbk1zIC8gMTAwMCA6IG51bGwsXG4gICAgd2lkdGg6IG51bU9yTnVsbChpbmZvPy53aWR0aCksXG4gICAgaGVpZ2h0OiBudW1Pck51bGwoaW5mbz8uaGVpZ2h0KSxcbiAgICBhbHRfdGV4dDogYWx0VGV4dCxcbiAgICBhcmNoaXZlX3N0YXR1czogJ3BlbmRpbmcnLFxuICAgIGFyY2hpdmVfYXR0ZW1wdHM6IDAsXG4gICAgbGFzdF9hdHRlbXB0X2F0OiBudWxsLFxuICB9O1xufVxuXG5mdW5jdGlvbiBwaWNrT3JpZ2luYWxVcmwobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHR5cGU6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKHR5cGUgPT09ICdwaG90bycpIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpID8/IHN0ck9yTnVsbChtLm1lZGlhX3VybCk7XG4gIGNvbnN0IHZhcmlhbnRzID0gdG9BcnJheShvYmoobS52aWRlb19pbmZvKT8udmFyaWFudHMpIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+W107XG4gIGlmICh2YXJpYW50cy5sZW5ndGggPT09IDApIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpO1xuICAvLyBIaWdoZXN0LWJpdHJhdGUgbXA0LlxuICBsZXQgYmVzdDogeyB1cmw6IHN0cmluZzsgYml0cmF0ZTogbnVtYmVyIH0gfCBudWxsID0gbnVsbDtcbiAgZm9yIChjb25zdCB2IG9mIHZhcmlhbnRzKSB7XG4gICAgY29uc3QgY3QgPSBzdHJPck51bGwodi5jb250ZW50X3R5cGUpO1xuICAgIGNvbnN0IHVybCA9IHN0ck9yTnVsbCh2LnVybCk7XG4gICAgaWYgKCF1cmwpIGNvbnRpbnVlO1xuICAgIGlmIChjdCA9PT0gJ3ZpZGVvL21wNCcpIHtcbiAgICAgIGNvbnN0IGJyID0gbnVtT3JOdWxsKHYuYml0cmF0ZSkgPz8gMDtcbiAgICAgIGlmICghYmVzdCB8fCBiciA+IGJlc3QuYml0cmF0ZSkgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiBiciB9O1xuICAgIH0gZWxzZSBpZiAoIWJlc3QpIHtcbiAgICAgIC8vIEZhbGxiYWNrIHRvIGFueSB2YXJpYW50IGlmIG5vIG1wNCBmb3VuZC5cbiAgICAgIGJlc3QgPSB7IHVybCwgYml0cmF0ZTogMCB9O1xuICAgIH1cbiAgfVxuICByZXR1cm4gYmVzdD8udXJsID8/IG51bGw7XG59XG5cbmZ1bmN0aW9uIHJlc29sdmVTaG9ydFVybHModGV4dDogc3RyaW5nLCB1cmxzOiBVcmxFbnRpdHlbXSk6IHN0cmluZyB7XG4gIGlmICh1cmxzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHRleHQ7XG4gIGxldCBvdXQgPSB0ZXh0O1xuICBmb3IgKGNvbnN0IHUgb2YgdXJscykgb3V0ID0gb3V0LnNwbGl0KHUuc2hvcnQpLmpvaW4odS5leHBhbmRlZCk7XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIHBhcnNlVHdpdHRlckRhdGUoczogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAoIXMpIHJldHVybiBudWxsO1xuICAvLyBUd2l0dGVyIHNoaXBzIGRhdGVzIGxpa2UgXCJNb24gQXByIDEyIDE0OjIzOjAxICswMDAwIDIwMjVcIi5cbiAgY29uc3QgZCA9IG5ldyBEYXRlKHMpO1xuICBpZiAoTnVtYmVyLmlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiBkLnRvSVNPU3RyaW5nKCk7XG59XG5cbmZ1bmN0aW9uIHN0ck9yTnVsbCh2OiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwID8gdiA6IG51bGw7XG59XG5mdW5jdGlvbiBib29sT3JOdWxsKHY6IHVua25vd24pOiBib29sZWFuIHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nID8gdiA6IG51bGw7XG59XG5mdW5jdGlvbiBudW1Pck51bGwodjogdW5rbm93bik6IG51bWJlciB8IG51bGwge1xuICBpZiAodHlwZW9mIHYgPT09ICdudW1iZXInICYmIE51bWJlci5pc0Zpbml0ZSh2KSkgcmV0dXJuIHY7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IE51bWJlcih2KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKG4pKSByZXR1cm4gbjtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIG51bU9yWmVybyh2OiB1bmtub3duKTogbnVtYmVyIHtcbiAgcmV0dXJuIG51bU9yTnVsbCh2KSA/PyAwO1xufVxuZnVuY3Rpb24gb2JqKHY6IHVua25vd24pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwge1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdvYmplY3QnICYmIHYgIT09IG51bGwgJiYgIUFycmF5LmlzQXJyYXkodilcbiAgICA/ICh2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVxuICAgIDogbnVsbDtcbn1cbmZ1bmN0aW9uIHRvQXJyYXkodjogdW5rbm93bik6IHVua25vd25bXSB7XG4gIHJldHVybiBBcnJheS5pc0FycmF5KHYpID8gdiA6IFtdO1xufVxuXG4vKipcbiAqIERlY2lkZSB3aGV0aGVyIGEgdHdlZXQncyBhcmNoaXZlZCBgdGV4dGAgaXMgdGhlIHRydW5jYXRlZCBoZWFkIG9mIGEgbG9uZ2VyXG4gKiBib2R5LiBBIHRydW5jYXRlZCB0d2VldCBoYXMgWCdzIFwiU2hvdyBtb3JlXCIgdC5jbyBVUkwgYXBwZW5kZWQgXHUyMDE0IHRoYXQgVVJMXG4gKiBzcGVjaWZpY2FsbHkgZXhwYW5kcyB0byB0aGUgdHdlZXQncyBvd24gL2kvd2ViL3N0YXR1cy88aWQ+IHBlcm1hbGluaywgYW5kXG4gKiBpcyB0aGUgb25seSByZWxpYWJsZSBkaXN0aW5ndWlzaGluZyBmZWF0dXJlLiBQbGVudHkgb2Ygbm9ybWFsIHR3ZWV0cyBoYXZlXG4gKiB0cmFpbGluZyB0LmNvIFVSTHMgKG1lZGlhLCBxdW90ZXMsIHJlZ3VsYXIgbGlua3MpLCBhbmQgdGhlaXJcbiAqIGRpc3BsYXlfdGV4dF9yYW5nZSBhbHNvIHRyaW1zIHBhc3QgZnVsbF90ZXh0Lmxlbmd0aCwgc28gdGhlIG9sZFxuICogXCJkaXNwbGF5X3RleHRfcmFuZ2VbMV0gPCBmdWxsX3RleHQubGVuZ3RoXCIgaGV1cmlzdGljIHdhcyBvdmVyZmxhZ2dpbmdcbiAqIGVzc2VudGlhbGx5IGV2ZXJ5IHR3ZWV0IHdpdGggYSBsaW5rIGluIGl0LlxuICpcbiAqIFJ1bGVzOlxuICogICAtIG5vdGVfdHdlZXQgcHJlc2VudCAgXHUyMTkyIG5vdCB0cnVuY2F0ZWQgKHdlIGFscmVhZHkgaGF2ZSB0aGUgZnVsbCBib2R5KS5cbiAqICAgLSBPbmUgb2YgbGVnYWN5LmVudGl0aWVzLnVybHMgaGFzIGFuIGV4cGFuZGVkX3VybCBsaWtlXG4gKiAgICAgXCIuLi4vaS93ZWIvc3RhdHVzLzxpZD5cIiAgXHUyMTkyICB0cnVuY2F0ZWQuXG4gKiAgIC0gT3RoZXJ3aXNlIFx1MjE5MiBub3QgdHJ1bmNhdGVkLlxuICpcbiAqIFRoZSBwcmV2aW91cyBmYWxsYmFjayAoXCJ0cmFpbGluZyB0LmNvIFVSTCArIGxlbmd0aCBcdTIyNjUgMjcwXCIpIGZsYWdnZWQgZXZlcnlcbiAqIG1lZGlhIHR3ZWV0IGV4YWN0bHkgYXQgdGhlIDI4MC1jaGFyIGxpbWl0LiBXZSBkcm9wIGl0IGVudGlyZWx5OyB0aGUgb25seVxuICogY29zdCBpcyBtaXNzaW5nIGdlbnVpbmVseS10cnVuY2F0ZWQgdHdlZXRzIHdob3NlIHBheWxvYWQgd2FzIHNvIGRlZ3JhZGVkXG4gKiBpdCBsYWNrZWQgZW50aXRpZXMgXHUyMDE0IHdoaWNoIGlzIGFsc28gd2hlcmUgdGhlIHJlZmV0Y2ggbG9vcCB3b3VsZCBmYWlsXG4gKiBhbnl3YXksIHNvIG5vdGhpbmcgaXMgYWN0dWFsbHkgbG9zdC5cbiAqL1xuZnVuY3Rpb24gZGV0ZWN0VHJ1bmNhdGlvbihcbiAgbm90ZVR3ZWV0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gIGZ1bGxUZXh0OiBzdHJpbmdcbik6IGJvb2xlYW4ge1xuICBpZiAobm90ZVR3ZWV0KSByZXR1cm4gZmFsc2U7XG4gIGlmICghZnVsbFRleHQpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKTtcbiAgY29uc3QgdXJscyA9IGVudGl0aWVzID8gZW50aXRpZXMudXJscyA6IG51bGw7XG4gIGlmIChBcnJheS5pc0FycmF5KHVybHMpKSB7XG4gICAgZm9yIChjb25zdCB1IG9mIHVybHMpIHtcbiAgICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XG4gICAgICBjb25zdCBleHAgPSAodSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuZXhwYW5kZWRfdXJsO1xuICAgICAgLy8gVGhlIFwiU2hvdyBtb3JlXCIgbGluayBleHBhbmRzIHRvIGVpdGhlciBvZiB0aGVzZSBzZWxmLXBlcm1hbGlua1xuICAgICAgLy8gc2hhcGVzOiAgaHR0cHM6Ly94LmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxuICAgICAgLy8gICAgICAgICAgaHR0cHM6Ly90d2l0dGVyLmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxuICAgICAgaWYgKHR5cGVvZiBleHAgPT09ICdzdHJpbmcnICYmIC9cXC9pXFwvd2ViXFwvc3RhdHVzXFwvXFxkKy8udGVzdChleHApKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbi8qKlxuICogRmlsdGVyIGB0d2VldHNgIGRvd24gdG8gdGhvc2UgcmVsYXRlZCB0byBhIHRyYWNrZWQgYWNjb3VudC4gQSB0d2VldCBpc1xuICogXCJyZWxhdGVkXCIgaWYgYW55IG9mIHRoZSBmb2xsb3dpbmcgaG9sZDpcbiAqXG4gKiAgIC0gaXRzIGF1dGhvciBpcyB0cmFja2VkIChoYW5kbGUgaW4gYHRhcmdldGVkYCksXG4gKiAgIC0gaXRzIGF1dGhvciBpcyBjb3JlIChoYW5kbGUgaW4gYGNvcmVIYW5kbGVzYCksIHJlZ2FyZGxlc3Mgb2Ygd2hlcmUgWFxuICogICAgIHN1cmZhY2VkIGl0LFxuICogICAtIGl0IG1lbnRpb25zIGEgdHJhY2tlZCBoYW5kbGUsXG4gKiAgIC0gaXQgcmVwbGllcyB0byBhIHRyYWNrZWQgYWNjb3VudCxcbiAqICAgLSBpdCBxdW90ZXMvcmVwbGllcy10byBhIHR3ZWV0IHRoYXQncyBhbHNvIHByZXNlbnQgaW4gdGhlXG4gKiAgICAgYmF0Y2ggKmFuZCogYXV0aG9yZWQgYnkgYSB0cmFja2VkIGFjY291bnQgKHRyYW5zaXRpdmVseSByZWxhdGVkIFx1MjAxNFxuICogICAgIGNhcHR1cmVzIHF1b3RlZC9yZXBseSBjb250ZXh0IHRoYXQgYXBwZWFycyBhcyBhIHNpYmxpbmcgbm9kZSBpbiB0aGVcbiAqICAgICBzYW1lIEdyYXBoUUwgcmVzcG9uc2UpLlxuICpcbiAqIE5vbi1jb3JlIHJldHdlZXQgd3JhcHBlcnMgYXJlIG5vdCBrZXB0IG1lcmVseSBiZWNhdXNlIHRoZXkgcmV0d2VldGVkIGFcbiAqIHRyYWNrZWQvY29yZSB0d2VldC4gVGhlIHVuZGVybHlpbmcgY29yZSB0d2VldCBpcyBrZXB0IGFzIGl0cyBvd24gcm93IHdoZW5cbiAqIHByZXNlbnQgaW4gdGhlIHBheWxvYWQuXG4gKlxuICogQW55dGhpbmcgZWxzZSAocmFuZG9tIHJlcGxpZXMgdW5kZXIgYSB0cmFja2VkIGFjY291bnQncyB0d2VldCwgcmFuZG9tXG4gKiBhdXRob3JzIHRoYXQgaGFwcGVuIHRvIHN1cmZhY2UgaW4gYSB0cmFja2VkIGFjY291bnQncyB0aHJlYWQpIGlzIGRyb3BwZWQuXG4gKiBQYXNzIGFuIGVtcHR5IGB0YXJnZXRlZGAgc2V0IHRvIGRpc2FibGUgZmlsdGVyaW5nIGVudGlyZWx5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyUmVsYXRlZChcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdLFxuICB0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPixcbiAgY29yZUhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KClcbik6IENhbm9uaWNhbFR3ZWV0W10ge1xuICBpZiAodGFyZ2V0ZWQuc2l6ZSA9PT0gMCAmJiBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm4gdHdlZXRzO1xuICAvLyBGaXJzdCBwYXNzOiB3aGljaCB0d2VldCBJRHMgZG8gdHJhY2tlZC1hdXRob3IgdHdlZXRzIHJlZmVyZW5jZSAodGhlXG4gIC8vIFwiZm9yd2FyZFwiIGRpcmVjdGlvbiBcdTIwMTQgdHJhY2tlZCBhY2NvdW50IHF1b3RlcyAvIFJUcyAvIHJlcGxpZXMgdG8gWCk/XG4gIC8vIEFuZCB3aGljaCB0d2VldCBJRHMgQVJFIHRyYWNrZWQtYXV0aG9yZWQgKHRoZSBcInJldmVyc2VcIiBkaXJlY3Rpb24gXHUyMDE0XG4gIC8vIFggcXVvdGVzIC8gUlRzIC8gcmVwbGllcyB0byBhIHRyYWNrZWQgdHdlZXQpP1xuICBjb25zdCByZWZlcmVuY2VkSWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHRhcmdldGVkVHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgIGlmICghdGFyZ2V0ZWQuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIGNvbnRpbnVlO1xuICAgIHRhcmdldGVkVHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xuICAgIGlmICh0LnF1b3RlZF90d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5xdW90ZWRfdHdlZXRfaWQpO1xuICAgIGlmICh0LnJldHdlZXRlZF90d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpO1xuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnJlcGx5X3RvX3R3ZWV0X2lkKTtcbiAgfVxuICByZXR1cm4gdHdlZXRzLmZpbHRlcigodCkgPT4ge1xuICAgIGNvbnN0IGggPSB0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKHRhcmdldGVkLmhhcyhoKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKGNvcmVIYW5kbGVzLmhhcyhoKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gRm9yd2FyZDogYSB0cmFja2VkLWF1dGhvciB0d2VldCBwb2ludGVkIGF0IHRoaXMgb25lLlxuICAgIGlmIChyZWZlcmVuY2VkSWRzLmhhcyh0LnR3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gUmV2ZXJzZTogdGhpcyB0d2VldCBxdW90ZXMvcmVwbGllcyB0byBhIHRyYWNrZWQtYXV0aG9yIHR3ZWV0IGluIHRoZVxuICAgIC8vIGJhdGNoLiBSZXZlcnNlIHJldHdlZXRzIGFyZSBqdXN0IFwibm9uLWNvcmUgYWNjb3VudCByZXR3ZWV0ZWQgY29yZVxuICAgIC8vIHR3ZWV0XCIgd3JhcHBlcnMsIGFuZCBkbyBub3QgYWRkIGNvcmUgYXJjaGl2ZSB2YWx1ZS5cbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQgJiYgdGFyZ2V0ZWRUd2VldElkcy5oYXModC5xdW90ZWRfdHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCAmJiB0YXJnZXRlZFR3ZWV0SWRzLmhhcyh0LnJlcGx5X3RvX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gUmVwbHktdG8tYWNjb3VudCBvciBtZW50aW9ucyBhIHRyYWNrZWQgaGFuZGxlLlxuICAgIGlmICh0LnJlcGx5X3RvX2FjY291bnQgJiYgdGFyZ2V0ZWQuaGFzKHQucmVwbHlfdG9fYWNjb3VudC50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIHRydWU7XG4gICAgZm9yIChjb25zdCBtIG9mIHQubWVudGlvbnMpIHtcbiAgICAgIGlmICh0YXJnZXRlZC5oYXMobS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfSk7XG59XG5cbi8qKlxuICogUHVsbCB0aGUgQ29tbXVuaXR5IE5vdGUgKGZvcm1lcmx5IEJpcmR3YXRjaCkgYmxvY2sgYXR0YWNoZWQgdG8gYSB0d2VldCwgaWZcbiAqIGFueS4gVGhlIHBpdm90IGNhbiBsaXZlIGF0IGB0d2VldC5sZWdhY3kuYmlyZHdhdGNoX3Bpdm90YCAob2xkZXIgc2hhcGUpIG9yXG4gKiBgdHdlZXQuYmlyZHdhdGNoX3Bpdm90YCAoY3VycmVudCBzaGFwZSkuIFRoZSBzdW1tYXJ5IHRleHQgaXMgd2hhdCByZWFkZXJzXG4gKiBhY3R1YWxseSBzZWU7IHdlIGtlZXAgdGhlIHN1cnJvdW5kaW5nIG1ldGFkYXRhIHNvIGRvd25zdHJlYW0gdG9vbGluZyBjYW5cbiAqIHRlbGwgZHJhZnRzIGFwYXJ0IGZyb20gcmF0ZWQtaGVscGZ1bCBub3Rlcy5cbiAqL1xuZnVuY3Rpb24gZXh0cmFjdENvbW11bml0eU5vdGUoXG4gIHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICBvYnNlcnZlZEF0OiBzdHJpbmdcbik6IENvbW11bml0eU5vdGUgfCBudWxsIHtcbiAgY29uc3QgcGl2b3QgPSBvYmoodC5iaXJkd2F0Y2hfcGl2b3QpID8/IG9iaihsZWdhY3kuYmlyZHdhdGNoX3Bpdm90KTtcbiAgaWYgKCFwaXZvdCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHN1YnRpdGxlID0gb2JqKHBpdm90LnN1YnRpdGxlKTtcbiAgY29uc3Qgbm90ZSA9IG9iaihwaXZvdC5ub3RlKTtcbiAgY29uc3Qgc3VtbWFyeSA9IHN0ck9yTnVsbChzdWJ0aXRsZT8udGV4dCk7XG4gIGNvbnN0IHRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnRpdGxlKTtcbiAgY29uc3Qgc2hvcnRUaXRsZSA9IHN0ck9yTnVsbChwaXZvdC5zaG9ydFRpdGxlKTtcbiAgY29uc3QgZGVzdGluYXRpb25VcmwgPSBzdHJPck51bGwocGl2b3QuZGVzdGluYXRpb25VcmwpO1xuICBjb25zdCBub3RlSWQgPSBzdHJPck51bGwocGl2b3Qubm90ZUlkKSA/PyBzdHJPck51bGwobm90ZT8ucmVzdF9pZCk7XG4gIC8vIFNraXAgZW1wdHkgc2hlbGxzIHRoYXQgaGF2ZSBubyBhY3R1YWwgY29udGVudC5cbiAgaWYgKCFzdW1tYXJ5ICYmICF0aXRsZSAmJiAhbm90ZUlkKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHtcbiAgICBub3RlX2lkOiBub3RlSWQsXG4gICAgdGl0bGUsXG4gICAgc2hvcnRfdGl0bGU6IHNob3J0VGl0bGUsXG4gICAgc3VtbWFyeSxcbiAgICBkZXN0aW5hdGlvbl91cmw6IGRlc3RpbmF0aW9uVXJsLFxuICAgIG9ic2VydmVkX2F0OiBvYnNlcnZlZEF0LFxuICB9O1xufVxuXG4vKipcbiAqIFB1bGwgYSBwZXItYXV0aG9yIFVzZXJTbmFwc2hvdCBmcm9tIHRoZSB0d2VldCdzIHVzZXJfcmVzdWx0cyBub2RlLiBFdmVyeVxuICogZmllbGQgZGVmYXVsdHMgdG8gbnVsbCB3aGVuIG1pc3Npbmcgc28gdGhlIHNjaGVtYSBzdGF5cyBzdGFibGUgYWNyb3NzXG4gKiB0aGUgbGVnYWN5IC8gY29yZSBzaGFwZSBtaWdyYXRpb25zIFggaGFzIGJlZW4gZG9pbmcuXG4gKi9cbmZ1bmN0aW9uIGV4dHJhY3RVc2VyU25hcHNob3QoXG4gIHVzZXJSZXN1bHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgdXNlckNvcmVOZXc6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgdXNlckxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxuICB1c2VyQXZhdGFyT2JqOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGxcbik6IFVzZXJTbmFwc2hvdCB7XG4gIGNvbnN0IHZlcmlmaWNhdGlvbiA9IG9iaih1c2VyUmVzdWx0Py52ZXJpZmljYXRpb24pO1xuICByZXR1cm4ge1xuICAgIGRpc3BsYXlfbmFtZTpcbiAgICAgIHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8ubmFtZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/Lm5hbWUpID8/IHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5uYW1lKSxcbiAgICBhdmF0YXJfdXJsOlxuICAgICAgc3RyT3JOdWxsKHVzZXJBdmF0YXJPYmo/LmltYWdlX3VybCkgPz9cbiAgICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5wcm9maWxlX2ltYWdlX3VybF9odHRwcykgPz9cbiAgICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5wcm9maWxlX2ltYWdlX3VybF9odHRwcyksXG4gICAgdmVyaWZpZWQ6IGJvb2xPck51bGwodmVyaWZpY2F0aW9uPy52ZXJpZmllZCkgPz8gYm9vbE9yTnVsbCh1c2VyTGVnYWN5Py52ZXJpZmllZCksXG4gICAgaXNfYmx1ZV92ZXJpZmllZDogYm9vbE9yTnVsbCh1c2VyUmVzdWx0Py5pc19ibHVlX3ZlcmlmaWVkKSxcbiAgICB2ZXJpZmllZF90eXBlOiBzdHJPck51bGwodmVyaWZpY2F0aW9uPy52ZXJpZmllZF90eXBlKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8udmVyaWZpZWRfdHlwZSksXG4gICAgZGVzY3JpcHRpb246IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5kZXNjcmlwdGlvbiksXG4gICAgbG9jYXRpb246IHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubG9jYXRpb24pPy5sb2NhdGlvbikgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmxvY2F0aW9uKSxcbiAgICB1cmw6IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py51cmwpLFxuICAgIGZvbGxvd2Vyc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZvbGxvd2Vyc19jb3VudCksXG4gICAgZnJpZW5kc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZyaWVuZHNfY291bnQpLFxuICAgIHN0YXR1c2VzX2NvdW50OiBudW1Pck51bGwodXNlckxlZ2FjeT8uc3RhdHVzZXNfY291bnQpLFxuICAgIGFjY291bnRfY3JlYXRlZF9hdDpcbiAgICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5jcmVhdGVkX2F0KSkgPz9cbiAgICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmNyZWF0ZWRfYXQpKSxcbiAgICBwcm90ZWN0ZWQ6IGJvb2xPck51bGwodXNlckxlZ2FjeT8ucHJvdGVjdGVkKSxcbiAgfTtcbn1cblxuLyoqXG4gKiBXYWxrIHRoZSB0d2VldCdzIGBjYXJkLmxlZ2FjeS5iaW5kaW5nX3ZhbHVlc2AgKGtleS92YWx1ZSBhcnJheSkgaW50byBhXG4gKiBmbGF0IFR3ZWV0Q2FyZCB3aXRoIHRpdGxlLCBkZXNjcmlwdGlvbiwgYW5kIGEgcmVwcmVzZW50YXRpdmUgaW1hZ2UgVVJMLlxuICogUmV0dXJucyBudWxsIHdoZW4gdGhlIHR3ZWV0IGhhcyBubyBjYXJkLlxuICovXG5mdW5jdGlvbiBleHRyYWN0Q2FyZCh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFR3ZWV0Q2FyZCB8IG51bGwge1xuICBjb25zdCBjYXJkID0gb2JqKHQuY2FyZCk7XG4gIGNvbnN0IGNhcmRMZWdhY3kgPSBvYmooY2FyZD8ubGVnYWN5KTtcbiAgaWYgKCFjYXJkTGVnYWN5KSByZXR1cm4gbnVsbDtcbiAgY29uc3QgYmluZGluZ3MgPSBjYXJkTGVnYWN5LmJpbmRpbmdfdmFsdWVzO1xuICBjb25zdCBieUtleTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgaWYgKEFycmF5LmlzQXJyYXkoYmluZGluZ3MpKSB7XG4gICAgZm9yIChjb25zdCBidiBvZiBiaW5kaW5ncykge1xuICAgICAgaWYgKHR5cGVvZiBidiAhPT0gJ29iamVjdCcgfHwgYnYgPT09IG51bGwpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgbyA9IGJ2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgY29uc3QgayA9IHN0ck9yTnVsbChvLmtleSk7XG4gICAgICBjb25zdCB2ID0gb2JqKG8udmFsdWUpO1xuICAgICAgaWYgKCFrIHx8ICF2KSBjb250aW51ZTtcbiAgICAgIGJ5S2V5W2tdID1cbiAgICAgICAgc3RyT3JOdWxsKHYuc3RyaW5nX3ZhbHVlKSA/P1xuICAgICAgICBzdHJPck51bGwob2JqKHYuaW1hZ2VfdmFsdWUpPy51cmwpID8/XG4gICAgICAgIHN0ck9yTnVsbChvYmoodi5pbWFnZV9jb2xvcl92YWx1ZSk/LnBhbGV0dGUpO1xuICAgIH1cbiAgfVxuICBjb25zdCBuYW1lID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kubmFtZSk7XG4gIGNvbnN0IGNhcmRVcmwgPSBzdHJPck51bGwoY2FyZExlZ2FjeS51cmwpO1xuICBjb25zdCB2ZW5kb3JVcmwgPVxuICAgIHR5cGVvZiBieUtleVsndmFuaXR5X3VybCddID09PSAnc3RyaW5nJyA/IChieUtleVsndmFuaXR5X3VybCddIGFzIHN0cmluZykgOiBudWxsO1xuICBjb25zdCB0aXRsZSA9IHR5cGVvZiBieUtleVsndGl0bGUnXSA9PT0gJ3N0cmluZycgPyAoYnlLZXlbJ3RpdGxlJ10gYXMgc3RyaW5nKSA6IG51bGw7XG4gIGNvbnN0IGRlc2NyaXB0aW9uID1cbiAgICB0eXBlb2YgYnlLZXlbJ2Rlc2NyaXB0aW9uJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5WydkZXNjcmlwdGlvbiddIGFzIHN0cmluZykgOiBudWxsO1xuICBjb25zdCBpbWFnZVVybCA9XG4gICAgKHR5cGVvZiBieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXG4gICAgICA/IChieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxuICAgICAgOiBudWxsKSA/P1xuICAgICh0eXBlb2YgYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xuICAgICAgPyAoYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcbiAgICAgIDogbnVsbCkgPz9cbiAgICAodHlwZW9mIGJ5S2V5WydzdW1tYXJ5X3Bob3RvX2ltYWdlX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXG4gICAgICA/IChieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcbiAgICAgIDogbnVsbCk7XG4gIGlmICghbmFtZSAmJiAhdGl0bGUgJiYgIWRlc2NyaXB0aW9uICYmICFpbWFnZVVybCkgcmV0dXJuIG51bGw7XG4gIHJldHVybiB7XG4gICAgbmFtZSxcbiAgICBjYXJkX3VybDogY2FyZFVybCxcbiAgICB2ZW5kb3JfdXJsOiB2ZW5kb3JVcmwsXG4gICAgdGl0bGUsXG4gICAgZGVzY3JpcHRpb24sXG4gICAgaW1hZ2VfdXJsOiBpbWFnZVVybCxcbiAgfTtcbn1cbiIsICIvKipcbiAqIExpZ2h0d2VpZ2h0IFVMSUQtbGlrZSBpZCBnZW5lcmF0b3I6IDI2LWNoYXJhY3RlciBDcm9ja2ZvcmQgYmFzZTMyIHN0cmluZ1xuICogb2YgKHRpbWVzdGFtcF9tcyB8fCByYW5kb21uZXNzKS4gR29vZCBlbm91Z2ggZm9yIHJ1biBpZGVudGlmaWVycyB3aXRob3V0XG4gKiBwdWxsaW5nIGluIGEgcmVhbCBVTElEIGRlcGVuZGVuY3kuXG4gKi9cblxuY29uc3QgQUxQSEFCRVQgPSAnMDEyMzQ1Njc4OUFCQ0RFRkdISktNTlBRUlNUVldYWVonOyAvLyBDcm9ja2ZvcmRcblxuZXhwb3J0IGZ1bmN0aW9uIG5ld1J1bklkKCk6IHN0cmluZyB7XG4gIGNvbnN0IHRzID0gRGF0ZS5ub3coKTtcbiAgbGV0IHRzUGFydCA9ICcnO1xuICBsZXQgdCA9IHRzO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDEwOyBpKyspIHtcbiAgICB0c1BhcnQgPSAoQUxQSEFCRVRbdCAlIDMyXSA/PyAnMCcpICsgdHNQYXJ0O1xuICAgIHQgPSBNYXRoLmZsb29yKHQgLyAzMik7XG4gIH1cbiAgY29uc3QgcmFuZCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTApKTtcbiAgbGV0IHJhbmRQYXJ0ID0gJyc7XG4gIGZvciAoY29uc3QgYiBvZiByYW5kKSByYW5kUGFydCArPSBBTFBIQUJFVFtiICUgMzJdID8/ICcwJztcbiAgcmV0dXJuIHRzUGFydCArIHJhbmRQYXJ0O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2hvcnRSdW5JZChpZDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIGlkLnNsaWNlKC04KTtcbn1cbiIsICJpbXBvcnQgdHlwZSB7IEFjY291bnRDYXRlZ29yeSwgQWNjb3VudENvbmZpZyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG4vKipcbiAqIE1pbmltYWwgcGFyc2VyIGZvciB0aGUgc3RyaWN0IHNoYXBlIHVzZWQgYnkgYGNvbmZpZy9hY2NvdW50cy55YW1sYDpcbiAqXG4gKiAgIGFjY291bnRzOlxuICogICAgIC0gaGFuZGxlOiBESFNnb3ZcbiAqICAgICAgIGxhYmVsOiBEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5XG4gKiAgICAgICBjYXRlZ29yeTogY29yZVxuICpcbiAqIFdlIGRlbGliZXJhdGVseSBkb24ndCBwdWxsIGluIGEgZnVsbCBZQU1MIGxpYnJhcnkgXHUyMDE0IHdlIGNvbnRyb2wgYm90aCBlbmRzIG9mXG4gKiB0aGlzIGZpbGUsIGFuZCBhIHNtYWxsIHBhcnNlciBpcyBlYXNpZXIgdG8gYXVkaXQgdGhhbiB0aGUgYWx0ZXJuYXRpdmVzLlxuICogVW5rbm93biBrZXlzIGFuZCBjb21tZW50cyBhcmUgdG9sZXJhdGVkOyBtYWxmb3JtZWQgbGluZXMgYXJlIHNraXBwZWQuXG4gKlxuICogRW50cmllcyBtaXNzaW5nIGEgYGNhdGVnb3J5YCBkZWZhdWx0IHRvIGBjb3JlYCBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eVxuICogd2l0aCB0aGUgcHJlLWNhdGVnb3JpemF0aW9uIGZpbGUgc2hhcGUuXG4gKi9cbmNvbnN0IFZBTElEX0NBVEVHT1JJRVM6IFJlYWRvbmx5U2V0PEFjY291bnRDYXRlZ29yeT4gPSBuZXcgU2V0KFtcbiAgJ2NvcmUnLFxuICAnZ292ZXJubWVudCcsXG4gICdvZmZpY2lhbHMnLFxuICAncHVibGljX2ZpZ3VyZXMnLFxuICAncHVibGljJyxcbl0pO1xuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VBY2NvdW50c1lhbWwodGV4dDogc3RyaW5nKTogQWNjb3VudENvbmZpZ1tdIHtcbiAgY29uc3QgYWNjb3VudHM6IEFjY291bnRDb25maWdbXSA9IFtdO1xuICBsZXQgY3VycmVudDogUGFydGlhbDxBY2NvdW50Q29uZmlnPiA9IHt9O1xuICBsZXQgaW5BY2NvdW50cyA9IGZhbHNlO1xuICBjb25zdCBmbHVzaCA9ICgpID0+IHtcbiAgICBpZiAoY3VycmVudC5oYW5kbGUgJiYgY3VycmVudC5sYWJlbCkge1xuICAgICAgaWYgKCFjdXJyZW50LmNhdGVnb3J5KSBjdXJyZW50LmNhdGVnb3J5ID0gJ2NvcmUnO1xuICAgICAgYWNjb3VudHMucHVzaChjdXJyZW50IGFzIEFjY291bnRDb25maWcpO1xuICAgIH1cbiAgfTtcbiAgZm9yIChjb25zdCByYXdMaW5lIG9mIHRleHQuc3BsaXQoJ1xcbicpKSB7XG4gICAgY29uc3QgbGluZSA9IHN0cmlwQ29tbWVudHMocmF3TGluZSk7XG4gICAgaWYgKGxpbmUudHJpbSgpID09PSAnJykgY29udGludWU7XG4gICAgaWYgKC9eYWNjb3VudHNcXHMqOi8udGVzdChsaW5lKSkge1xuICAgICAgaW5BY2NvdW50cyA9IHRydWU7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKCFpbkFjY291bnRzKSBjb250aW51ZTtcblxuICAgIGNvbnN0IGl0ZW1NYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqLVxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChpdGVtTWF0Y2gpIHtcbiAgICAgIGZsdXNoKCk7XG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaXRlbU1hdGNoWzFdID8/ICcnKSB9O1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IGhhbmRsZU9ubHkgPSBsaW5lLm1hdGNoKC9eXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGhhbmRsZU9ubHkgJiYgIWxpbmUuaW5jbHVkZXMoJy0nKSkge1xuICAgICAgZmx1c2goKTtcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShoYW5kbGVPbmx5WzFdID8/ICcnKSB9O1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IGxhYmVsTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmxhYmVsXFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAobGFiZWxNYXRjaCAmJiBjdXJyZW50LmhhbmRsZSkge1xuICAgICAgY3VycmVudC5sYWJlbCA9IHVucXVvdGUobGFiZWxNYXRjaFsxXSA/PyAnJyk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgY2F0ZWdvcnlNYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqY2F0ZWdvcnlcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChjYXRlZ29yeU1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XG4gICAgICBjb25zdCByYXcgPSB1bnF1b3RlKGNhdGVnb3J5TWF0Y2hbMV0gPz8gJycpO1xuICAgICAgY3VycmVudC5jYXRlZ29yeSA9IFZBTElEX0NBVEVHT1JJRVMuaGFzKHJhdyBhcyBBY2NvdW50Q2F0ZWdvcnkpXG4gICAgICAgID8gKHJhdyBhcyBBY2NvdW50Q2F0ZWdvcnkpXG4gICAgICAgIDogJ2NvcmUnO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICB9XG4gIGZsdXNoKCk7XG4gIHJldHVybiBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuaGFuZGxlLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBzdHJpcENvbW1lbnRzKGxpbmU6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIE5haXZlIGJ1dCBhZGVxdWF0ZSBmb3Igb3VyIGZvcm1hdDogc3RyaXAgZXZlcnl0aGluZyBhZnRlciBhIGAjYCB0aGF0IGlzbid0XG4gIC8vIGluc2lkZSBxdW90ZXMuIE91ciBjb25maWcgbmV2ZXIgdXNlcyBpbmxpbmUgc3RyaW5ncyB3aXRoIGAjYC5cbiAgY29uc3QgaWR4ID0gbGluZS5pbmRleE9mKCcjJyk7XG4gIHJldHVybiBpZHggPT09IC0xID8gbGluZSA6IGxpbmUuc2xpY2UoMCwgaWR4KTtcbn1cblxuZnVuY3Rpb24gdW5xdW90ZShzOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCB0cmltbWVkID0gcy50cmltKCk7XG4gIGlmIChcbiAgICAodHJpbW1lZC5zdGFydHNXaXRoKCdcIicpICYmIHRyaW1tZWQuZW5kc1dpdGgoJ1wiJykpIHx8XG4gICAgKHRyaW1tZWQuc3RhcnRzV2l0aChcIidcIikgJiYgdHJpbW1lZC5lbmRzV2l0aChcIidcIikpXG4gICkge1xuICAgIHJldHVybiB0cmltbWVkLnNsaWNlKDEsIC0xKTtcbiAgfVxuICByZXR1cm4gdHJpbW1lZDtcbn1cbiIsICIvKipcbiAqIGJhY2tncm91bmQudHMgXHUyMDE0IGV4dGVuc2lvbiBzZXJ2aWNlIHdvcmtlci5cbiAqXG4gKiBPd25zIHRoZSBjYXB0dXJlIHBpcGVsaW5lOiByZWNlaXZlcyBgZ3JhcGhxbC1jYXB0dXJlYCBtZXNzYWdlcyBmcm9tIHRoZVxuICogY29udGVudCBzY3JpcHQsIG5vcm1hbGl6ZXMgdGhlbSwgYWNjdW11bGF0ZXMgcGVyLWhhbmRsZSBydW4gYnVmZmVycyBpblxuICogYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAsIGFuZCBjb21taXRzIHRoZW0gdG8gdGhlIGNvbmZpZ3VyZWQgR2l0SHViIHJlcG9cbiAqIHZpYSB0aGUgR2l0IERhdGEgQVBJLlxuICpcbiAqIFNlcnZpY2Ugd29ya2VycyBpbiBNVjMgbWF5IGJlIGV2aWN0ZWQgYXQgYW55IHRpbWUsIHNvIGFsbCBjcml0aWNhbCBzdGF0ZVxuICogbGl2ZXMgaW4gc3RvcmFnZSAobmV2ZXIgbW9kdWxlLXNjb3BlKS4gT24gZXZlcnkgd2FrZSB3ZSByZS1kZXJpdmUgd2hhdCB3ZVxuICogbmVlZDsgcGVuZGluZyBmbHVzaGVzIGFyZSBkcml2ZW4gYnkgYGJyb3dzZXIuYWxhcm1zYCByYXRoZXIgdGhhbiB0aW1lcnMuXG4gKi9cblxuaW1wb3J0IHtcbiAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgQVVUT19TQ1JPTExfTUlOX1NFQyxcbiAgRkFMTEJBQ0tfQUNDT1VOVFMsXG4gIEZMVVNIX0FMQVJNX01JTlVURVMsXG4gIEZMVVNIX0lETEVfTVMsXG4gIEZMVVNIX1RXRUVUX1RIUkVTSE9MRCxcbiAgUFJPRklMRV9FTkRQT0lOVFMsXG4gIFRXRUVUX0VORFBPSU5UUyxcbiAgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMsXG59IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XG5pbXBvcnQgeyBHaXRIdWJDbGllbnQsIEdpdEh1YkVycm9yLCB0b0Jhc2U2NCB9IGZyb20gJy4vbGliL2dpdGh1Yi5qcyc7XG5pbXBvcnQgeyBkZXNjcmliZUVycm9yLCBlcnJvciBhcyBsb2dFcnIsIGluZm8sIHNldEJyb2FkY2FzdGVyLCB3YXJuIH0gZnJvbSAnLi9saWIvbG9nZ2VyLmpzJztcbmltcG9ydCB7IGZpbHRlclJlbGF0ZWQsIG5vcm1hbGl6ZSB9IGZyb20gJy4vbGliL25vcm1hbGl6ZS5qcyc7XG5pbXBvcnQgeyBuZXdSdW5JZCwgc2hvcnRSdW5JZCB9IGZyb20gJy4vbGliL3J1bmlkcy5qcyc7XG5pbXBvcnQge1xuICBidW1wQ291bnRlcixcbiAgY2xlYXJBY3Rpdml0eSxcbiAgY2xlYXJBbGwsXG4gIGNsZWFyUnVuQnVmZmVyLFxuICBkZXF1ZXVlTWVkaWFDcmF3bCxcbiAgZGVxdWV1ZVJlZmV0Y2gsXG4gIGRlcXVldWVUaHJlYWRPcGVuLFxuICBlbmdhZ2VtZW50U2lnLFxuICBlbnF1ZXVlTWVkaWFDcmF3bCxcbiAgZW5xdWV1ZVJlZmV0Y2gsXG4gIGVucXVldWVUaHJlYWRPcGVuLFxuICBnZXRBY2NvdW50cyxcbiAgZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCxcbiAgZ2V0QWN0aXZpdHksXG4gIGdldEFyY2hpdmVTbmFwc2hvdCxcbiAgZ2V0QXV0b1Njcm9sbFNlc3Npb24sXG4gIGdldENvbW1pdHRlZEluZGV4LFxuICBnZXRDb25uZWN0aW9uLFxuICBnZXRDb3VudGVycyxcbiAgZ2V0TWVkaWFDcmF3bFF1ZXVlLFxuICBnZXRNZWRpYUNyYXdsU2Vzc2lvbixcbiAgZ2V0UmVmZXRjaFF1ZXVlLFxuICBnZXRSZWZldGNoU2Vzc2lvbixcbiAgZ2V0UmVjZW50VHdlZXRTaWdodGluZ3MsXG4gIGdldFJ1bkJ1ZmZlcixcbiAgZ2V0UnVuQnVmZmVycyxcbiAgZ2V0U2V0dGluZ3MsXG4gIGdldFRocmVhZE9wZW5RdWV1ZSxcbiAgZ2V0VGhyZWFkT3BlblNlc3Npb24sXG4gIGhhc1RocmVhZE9wZW5TZWVuLFxuICBpc0NvbW1pdHRlZCxcbiAgbWFya1RocmVhZE9wZW5TZWVuLFxuICBtZWRpYUNyYXdsUXVldWVUb3RhbCxcbiAgbmV4dE1lZGlhQ3Jhd2xUYXJnZXQsXG4gIG5leHRSZWZldGNoVGFyZ2V0LFxuICBuZXh0VGhyZWFkT3BlblRhcmdldCxcbiAgcHJ1bmVDb21taXR0ZWRJbmRleCxcbiAgcHVyZ2VVbnJlbGF0ZWRTdGF0ZSxcbiAgcmVmZXRjaFF1ZXVlVG90YWwsXG4gIHByZXBlbmRSZWNlbnRUd2VldFNpZ2h0aW5ncyxcbiAgc2V0QWNjb3VudHMsXG4gIHNldEFjY291bnRzUmVmcmVzaGVkQXQsXG4gIHNldEFyY2hpdmVTbmFwc2hvdCxcbiAgc2V0QXV0b1Njcm9sbFNlc3Npb24sXG4gIHNldEJ1ZmZlcmVkQ291bnQsXG4gIHNldENvbW1pdHRlZEluZGV4LFxuICBzZXRDb25uZWN0aW9uLFxuICBzZXRNZWRpYUNyYXdsU2Vzc2lvbixcbiAgc2V0UmVmZXRjaFNlc3Npb24sXG4gIHNldFJ1bkJ1ZmZlcixcbiAgc2V0VGhyZWFkT3BlblNlc3Npb24sXG4gIHRocmVhZE9wZW5RdWV1ZVRvdGFsLFxuICB0eXBlIFJ1bkJ1ZmZlcixcbiAgdXBkYXRlU2V0dGluZ3MsXG59IGZyb20gJy4vbGliL3N0b3JhZ2UuanMnO1xuaW1wb3J0IHR5cGUge1xuICBDYW5vbmljYWxUd2VldCxcbiAgQ2FwdHVyZVBheWxvYWQsXG4gIEFyY2hpdmVTbmFwc2hvdCxcbiAgQ29ubmVjdGlvblN0YXRlLFxuICBFeHRlbnNpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFF1YXJhbnRpbmVQYXlsb2FkLFxuICBSZXR3ZWV0RWRnZSxcbiAgUnVudGltZU1lc3NhZ2UsXG4gIFNlZW5QYXlsb2FkLFxuICBTZXR0aW5ncyxcbiAgVHdlZXRTaWdodGluZyxcbiAgVW5hdmFpbGFibGVUd2VldCxcbn0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xuaW1wb3J0IHsgcGFyc2VBY2NvdW50c1lhbWwgfSBmcm9tICcuL2xpYi95YW1sLmpzJztcblxuY29uc3QgRVhUX1ZFUlNJT04gPSBicm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uO1xuY29uc3QgTUFOVUFMX0NBUFRVUkVfV0lORE9XX01TID0gOTBfMDAwO1xuY29uc3QgTE9XX0JBTkRXSURUSF9SVUxFX0lEID0gNzYwXzAwMTtcbmNvbnN0IExPV19CQU5EV0lEVEhfUkVTT1VSQ0VfVFlQRVMgPSBbJ2ltYWdlJywgJ21lZGlhJywgJ2ZvbnQnXSBhcyBjb25zdDtcbmxldCBtYW51YWxDYXB0dXJlVW50aWxNcyA9IDA7XG5cbnR5cGUgTG93QmFuZHdpZHRoUmVzb3VyY2VUeXBlID0gKHR5cGVvZiBMT1dfQkFORFdJRFRIX1JFU09VUkNFX1RZUEVTKVtudW1iZXJdO1xuXG5pbnRlcmZhY2UgTG93QmFuZHdpZHRoUnVsZSB7XG4gIGlkOiBudW1iZXI7XG4gIHByaW9yaXR5OiBudW1iZXI7XG4gIGFjdGlvbjogeyB0eXBlOiAnYmxvY2snIH07XG4gIGNvbmRpdGlvbjoge1xuICAgIHRhYklkczogbnVtYmVyW107XG4gICAgcmVzb3VyY2VUeXBlczogTG93QmFuZHdpZHRoUmVzb3VyY2VUeXBlW107XG4gIH07XG59XG5cbmludGVyZmFjZSBEZWNsYXJhdGl2ZU5ldFJlcXVlc3RBcGkge1xuICB1cGRhdGVTZXNzaW9uUnVsZXModXBkYXRlOiB7XG4gICAgYWRkUnVsZXM/OiBMb3dCYW5kd2lkdGhSdWxlW107XG4gICAgcmVtb3ZlUnVsZUlkcz86IG51bWJlcltdO1xuICB9KTogUHJvbWlzZTx2b2lkPjtcbn1cblxuc2V0QnJvYWRjYXN0ZXIoKGV2OiBMb2dFdmVudCkgPT4ge1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnbG9nLWV2ZW50JywgZXZlbnQ6IGV2IH0pLmNhdGNoKCgpID0+IHt9KTtcbn0pO1xuXG5mdW5jdGlvbiBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTogdm9pZCB7XG4gIG1hbnVhbENhcHR1cmVVbnRpbE1zID0gRGF0ZS5ub3coKSArIE1BTlVBTF9DQVBUVVJFX1dJTkRPV19NUztcbn1cblxuLy8gLS0tIFdha2UgaGFuZGxlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYnJvd3Nlci5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIGluc3RhbGxlZCcsIHsgdmVyc2lvbjogRVhUX1ZFUlNJT04gfSk7XG4gIGF3YWl0IG9uV2FrZSgnaW5zdGFsbCcpO1xufSk7XG5cbmJyb3dzZXIucnVudGltZS5vblN0YXJ0dXAuYWRkTGlzdGVuZXIoKCkgPT4ge1xuICB2b2lkIG9uV2FrZSgnc3RhcnR1cCcpO1xufSk7XG5cbi8vIEZvcmNlIGF0IGxlYXN0IG9uZSB3YWtlIHRvIHJlZ2lzdGVyIGFsYXJtcyAvIHZlcmlmeSBjb25uZWN0aW9uLlxudm9pZCBvbldha2UoJ21vZHVsZS1sb2FkJyk7XG5cbmFzeW5jIGZ1bmN0aW9uIG9uV2FrZShyZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGF3YWl0IGVuc3VyZUFsYXJtcygpO1xuICAgIGF3YWl0IGVuc3VyZUF1dG9TY3JvbGxBbGFybSgpO1xuICAgIGF3YWl0IHN5bmNMb3dCYW5kd2lkdGhSdWxlcyh7IHJlYXNvbjogYHdha2U6JHtyZWFzb259YCwgbG9nOiBmYWxzZSB9KTtcbiAgICBhd2FpdCBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTtcbiAgICBhd2FpdCByZWluamVjdEludG9PcGVuVGFicygpO1xuICAgIC8vIERyb3AgZGVkdXAtaW5kZXggZW50cmllcyBvbGRlciB0aGFuIDMwIGRheXMgc28gdGhlIHN0b3JlIGRvZXNuJ3RcbiAgICAvLyBncm93IHVuYm91bmRlZCBvdmVyIG1vbnRocyBvZiBjYXB0dXJlIHNlc3Npb25zLlxuICAgIGNvbnN0IHBydW5lZCA9IGF3YWl0IHBydW5lQ29tbWl0dGVkSW5kZXgoMzAgKiAyNCAqIDYwICogNjAgKiAxMDAwKTtcbiAgICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgaW5mbygncHJ1bmVkIGNvbW1pdHRlZCBpbmRleCcsIHsgcHJ1bmVkIH0pO1xuICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgICBpZiAoc2V0dGluZ3MucGF0ICYmIHNldHRpbmdzLm93bmVyICYmIHNldHRpbmdzLnJlcG8pIHtcbiAgICAgIGF3YWl0IHZlcmlmeUNvbm5lY3Rpb24oZmFsc2UpO1xuICAgICAgYXdhaXQgcmVmcmVzaEFjY291bnRzTGlzdChmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXM6ICdub3QtY29uZmlndXJlZCcsXG4gICAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBhd2FrZTsgc2V0dGluZ3MgaW5jb21wbGV0ZScsIHsgcmVhc29uIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgbG9nRXJyKCd3YWtlIGZhaWxlZCcsIHsgcmVhc29uLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZG5yQXBpKCk6IERlY2xhcmF0aXZlTmV0UmVxdWVzdEFwaSB8IG51bGwge1xuICBjb25zdCBtYXliZUJyb3dzZXIgPSBicm93c2VyIGFzIHVua25vd24gYXMge1xuICAgIGRlY2xhcmF0aXZlTmV0UmVxdWVzdD86IERlY2xhcmF0aXZlTmV0UmVxdWVzdEFwaTtcbiAgfTtcbiAgcmV0dXJuIG1heWJlQnJvd3Nlci5kZWNsYXJhdGl2ZU5ldFJlcXVlc3QgPz8gbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY3VycmVudFhUYWJJZHMoKTogUHJvbWlzZTxudW1iZXJbXT4ge1xuICBjb25zdCB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcbiAgcmV0dXJuIHRhYnMuZmxhdE1hcCgodGFiKSA9PiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicgPyBbdGFiLmlkXSA6IFtdKSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN5bmNMb3dCYW5kd2lkdGhSdWxlcyh7XG4gIHJlYXNvbixcbiAgbG9nLFxufToge1xuICByZWFzb246IHN0cmluZztcbiAgbG9nOiBib29sZWFuO1xufSk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IGRuciA9IGRuckFwaSgpO1xuICBpZiAoIWRucikge1xuICAgIGlmIChzZXR0aW5ncy5sb3dCYW5kd2lkdGhCcm93c2luZyAmJiBsb2cpIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2xvdy1iYW5kd2lkdGggYnJvd3NpbmcgdW5hdmFpbGFibGU7IGRlY2xhcmF0aXZlTmV0UmVxdWVzdCBBUEkgbWlzc2luZycsIHtcbiAgICAgICAgcmVhc29uLFxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHRhYklkcyA9IHNldHRpbmdzLmxvd0JhbmR3aWR0aEJyb3dzaW5nID8gYXdhaXQgY3VycmVudFhUYWJJZHMoKSA6IFtdO1xuICBjb25zdCBhZGRSdWxlczogTG93QmFuZHdpZHRoUnVsZVtdID1cbiAgICB0YWJJZHMubGVuZ3RoID4gMFxuICAgICAgPyBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6IExPV19CQU5EV0lEVEhfUlVMRV9JRCxcbiAgICAgICAgICAgIHByaW9yaXR5OiAxLFxuICAgICAgICAgICAgYWN0aW9uOiB7IHR5cGU6ICdibG9jaycgfSxcbiAgICAgICAgICAgIGNvbmRpdGlvbjoge1xuICAgICAgICAgICAgICB0YWJJZHMsXG4gICAgICAgICAgICAgIHJlc291cmNlVHlwZXM6IFsuLi5MT1dfQkFORFdJRFRIX1JFU09VUkNFX1RZUEVTXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXVxuICAgICAgOiBbXTtcbiAgYXdhaXQgZG5yLnVwZGF0ZVNlc3Npb25SdWxlcyh7XG4gICAgcmVtb3ZlUnVsZUlkczogW0xPV19CQU5EV0lEVEhfUlVMRV9JRF0sXG4gICAgYWRkUnVsZXMsXG4gIH0pO1xuXG4gIGlmIChsb2cpIHtcbiAgICBhd2FpdCBpbmZvKCdsb3ctYmFuZHdpZHRoIGJyb3dzaW5nIHJ1bGVzIHVwZGF0ZWQnLCB7XG4gICAgICBlbmFibGVkOiBzZXR0aW5ncy5sb3dCYW5kd2lkdGhCcm93c2luZyxcbiAgICAgIHRhYl9jb3VudDogdGFiSWRzLmxlbmd0aCxcbiAgICAgIGJsb2NrZWRfcmVzb3VyY2VfdHlwZXM6IExPV19CQU5EV0lEVEhfUkVTT1VSQ0VfVFlQRVMuam9pbignLCcpLFxuICAgICAgcmVhc29uLFxuICAgIH0pO1xuICB9XG59XG5cbmJyb3dzZXIudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoKF90YWJJZCwgY2hhbmdlSW5mbykgPT4ge1xuICBpZiAoY2hhbmdlSW5mby51cmwgfHwgY2hhbmdlSW5mby5zdGF0dXMgPT09ICdjb21wbGV0ZScpIHtcbiAgICB2b2lkIHN5bmNMb3dCYW5kd2lkdGhSdWxlcyh7IHJlYXNvbjogJ3RhYi11cGRhdGVkJywgbG9nOiBmYWxzZSB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ2xvdy1iYW5kd2lkdGggcnVsZSByZWZyZXNoIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH1cbn0pO1xuXG5icm93c2VyLnRhYnMub25SZW1vdmVkLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgdm9pZCBzeW5jTG93QmFuZHdpZHRoUnVsZXMoeyByZWFzb246ICd0YWItcmVtb3ZlZCcsIGxvZzogZmFsc2UgfSkuY2F0Y2goKGVycikgPT4ge1xuICAgIHZvaWQgd2FybignbG93LWJhbmR3aWR0aCBydWxlIHJlZnJlc2ggZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfSk7XG59KTtcblxuLyoqXG4gKiBSZS1pbmplY3QgdGhlIE1BSU4td29ybGQgcGFnZS1ob29rICsgaXNvbGF0ZWQtd29ybGQgY29udGVudCBzY3JpcHQgaW50b1xuICogZXZlcnkgYWxyZWFkeS1vcGVuIHguY29tIC8gdHdpdHRlci5jb20gdGFiLlxuICpcbiAqIE1hbmlmZXN0IGNvbnRlbnRfc2NyaXB0cyBvbmx5IGluamVjdCBvbiBmcmVzaCBuYXZpZ2F0aW9uIChydW5fYXQ6XG4gKiBkb2N1bWVudF9zdGFydCkuIFdoZW4gdGhlIHVzZXIgcmVsb2FkcyB0aGUgZXh0ZW5zaW9uIHdoaWxlIFggdGFicyBhcmVcbiAqIG9wZW4sIHRob3NlIHRhYnMga2VlcCB0aGVpciBjb250ZW50IHNjcmlwdHMgYnV0IG5ldmVyIGdldCBhIG5ldyBwYWdlLWhvb2tcbiAqIFx1MjAxNCBzbyBmZXRjaC9YSFIgc3RheXMgdW5wYXRjaGVkIGFuZCBjYXB0dXJlcyBzaWxlbnRseSBmYWlsLiBEb2luZyB0aGlzIG9uXG4gKiBldmVyeSB3YWtlIGlzIGlkZW1wb3RlbnQgKHBhZ2UtaG9vayBoYXMgYSBUQUcgZ3VhcmQpIGFuZCBjaGVhcC5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gcmVpbmplY3RJbnRvT3BlblRhYnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XG4gIHRyeSB7XG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NvdWxkIG5vdCBxdWVyeSBvcGVuIHRhYnMnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodGFicy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgZm9yIChjb25zdCB0YWIgb2YgdGFicykge1xuICAgIGlmICh0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJykgY29udGludWU7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICBmaWxlczogWydwYWdlLWhvb2suanMnXSxcbiAgICAgICAgLy8gRmlyZWZveCAxMjgrIHN1cHBvcnRzIHRoZSBNQUlOIGV4ZWN1dGlvbiB3b3JsZCB2aWEgdGhpcyBBUEksIGJ1dFxuICAgICAgICAvLyB0aGUgQHR5cGVzL2ZpcmVmb3gtd2ViZXh0LWJyb3dzZXIgcGFja2FnZSB3ZSdyZSBvbiBzdGlsbCBvbmx5XG4gICAgICAgIC8vIGRlY2xhcmVzICdJU09MQVRFRCcuIENhc3QgdGhyb3VnaCB0aGUgbGl0ZXJhbCB1bmlvbi5cbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgZmlsZXM6IFsnY29udGVudC5qcyddLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBpbmZvKCdyZS1pbmplY3RlZCBzY3JpcHRzIGludG8gb3BlbiB0YWInLCB7XG4gICAgICAgIHRhYklkOiB0YWIuaWQsXG4gICAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsID8/ICcnKSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgLy8gU29tZSB0YWJzIChhYm91dDogcGFnZXMsIGRpc2NhcmRlZCB0YWJzLCBtaWQtbmF2aWdhdGlvbikgcmVqZWN0XG4gICAgICAvLyBleGVjdXRlU2NyaXB0LiBUaGF0J3MgZmluZSBcdTIwMTQgd2UnbGwgY2F0Y2ggdGhlbSBvbiB0aGUgbmV4dCB3YWtlIG9yXG4gICAgICAvLyB3aGVuIHRoZSB1c2VyIG5hdmlnYXRlcy5cbiAgICAgIGF3YWl0IHdhcm4oJ3JlLWluamVjdCBmYWlsZWQgZm9yIHRhYjsgY29udGludWluZycsIHtcbiAgICAgICAgdGFiSWQ6IHRhYi5pZCxcbiAgICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwgPz8gJycpLFxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQWxhcm1zKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignZmx1c2gtc3dlZXAnKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3ZlcmlmeS1jb25uZWN0aW9uJyk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgnZmx1c2gtc3dlZXAnLCB7IHBlcmlvZEluTWludXRlczogRkxVU0hfQUxBUk1fTUlOVVRFUyB9KTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY3JlYXRlKCd2ZXJpZnktY29ubmVjdGlvbicsIHtcbiAgICBwZXJpb2RJbk1pbnV0ZXM6IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TIC8gNjBfMDAwLFxuICB9KTtcbn1cblxuLy8gRmlyZWZveCBNVjMgYWxhcm1zIGhhdmUgYSAzMHMgbWluaW11bSBwZXJpb2QsIGJ1dCB3ZSB3YW50IHN1Yi1taW51dGVcbi8vIHNjcm9sbGluZy4gVGhlIGF1dG8tc2Nyb2xsIGxvb3AgdGhlcmVmb3JlIHJ1bnMgb24gYW4gaW4tU1cgaW50ZXJ2YWwuXG4vLyBgYXV0b1Njcm9sbFNlc3Npb25gIGluIHN0b3JhZ2UgaXMgdGhlIHNvdXJjZSBvZiB0cnV0aCBmb3Igd2hldGhlciB0aGUgbG9vcFxuLy8gaXMgbWVhbnQgdG8gYmUgcnVubmluZyBcdTIwMTQgdGhlIHRpbWVyIGlzIGp1c3QgdGhlIGxvY2FsIGV4ZWN1dGlvbiBhcm0uXG5sZXQgYXV0b1Njcm9sbFRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcbmNvbnN0IFNIT1dfTU9SRV9SRUxFVkFOQ0VfVFRMX01TID0gMTAgKiA2MCAqIDEwMDA7XG5pbnRlcmZhY2UgVGFiUmVsZXZhbnRUd2VldHMge1xuICB1cGRhdGVkQXQ6IG51bWJlcjtcbiAgcGFnZVVybDogc3RyaW5nIHwgbnVsbDtcbiAgdHdlZXRJZHM6IFNldDxzdHJpbmc+O1xufVxuY29uc3Qgc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiID0gbmV3IE1hcDxudW1iZXIsIFRhYlJlbGV2YW50VHdlZXRzPigpO1xuXG4vLyBXYWl0LWZvci1pbmdlc3QgdGltZW91dDogaWYgYSByZWZldGNoIC8gbWVkaWEtY3Jhd2wgdGFiIG5hdmlnYXRpb24gZG9lc24ndFxuLy8gcHJvZHVjZSBhbiBpbmdlc3RlZCBjYXB0dXJlIHdpdGhpbiB0aGlzIG1hbnkgbXMsIGFkdmFuY2UgYW55d2F5IHNvIHdlXG4vLyBkb24ndCBkZWFkbG9jayBvbiBkZWxldGVkIC8gNDA0IC8gcGF5d2FsbGVkIHR3ZWV0cy5cbmNvbnN0IElOR0VTVF9XQUlUX01TID0gMjVfMDAwO1xuXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVBdXRvU2Nyb2xsQWxhcm0oKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIFdhcyB0aGUgbG9vcCBydW5uaW5nIGJlZm9yZSB0aGUgU1cgZXZpY3Rpb24/IFJlLWFybSBpZiBzby5cbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoc2VzcyAhPT0gbnVsbCAmJiBzLmVuYWJsZWQgIT09IGZhbHNlKSB7XG4gICAgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcbiAgfSBlbHNlIHtcbiAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk6IHZvaWQge1xuICBpZiAoYXV0b1Njcm9sbFRpbWVyICE9PSBudWxsKSB7XG4gICAgY2xlYXJJbnRlcnZhbChhdXRvU2Nyb2xsVGltZXIpO1xuICAgIGF1dG9TY3JvbGxUaW1lciA9IG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gYXJtQXV0b1Njcm9sbFRpbWVyKGludGVydmFsU2VjOiBudW1iZXIpOiB2b2lkIHtcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgY29uc3QgY2xhbXBlZCA9IE1hdGgubWluKFxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChpbnRlcnZhbFNlYykpXG4gICk7XG4gIGF1dG9TY3JvbGxUaW1lciA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIGF1dG9TY3JvbGxUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCdhdXRvLXNjcm9sbCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIGNsYW1wZWQgKiAxMDAwKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbih7XG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgc2Nyb2xsQ291bnQ6IDAsXG4gICAgaW5nZXN0ZWRDb3VudDogMCxcbiAgICBpbmdlc3RlZE5ld0NvdW50OiAwLFxuICAgIGluZ2VzdGVkRXhpc3RpbmdDb3VudDogMCxcbiAgICBza2lwcGVkT2xkQ291bnQ6IDAsXG4gICAgZXhwYW5kZWRDb3VudDogMCxcbiAgfSk7XG4gIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XG4gIGF3YWl0IGluZm8oJ2F1dG8tc2Nyb2xsIGxvb3Agc3RhcnRlZCcsIHsgaW50ZXJ2YWxfc2VjOiBzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyB9KTtcbiAgLy8gRmlyZSBvbmUgaW1tZWRpYXRlIHRpY2sgc28gdGhlIHVzZXIgc2VlcyBtb3Rpb24gcmlnaHQgYXdheS5cbiAgdm9pZCBhdXRvU2Nyb2xsVGljaygpO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdhdXRvLXNjcm9sbCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBzY3JvbGxzOiBzZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxuICAgIGluZ2VzdGVkOiBzZXNzPy5pbmdlc3RlZENvdW50ID8/IDAsXG4gICAgZXhwYW5kZWQ6IHNlc3M/LmV4cGFuZGVkQ291bnQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGF1dG9TY3JvbGxUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdhdXRvLXNjcm9sbDogdGFiIHF1ZXJ5IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBsZXQgc2Nyb2xsQ291bnQgPSAwO1xuICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XG4gICAgaWYgKHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInKSBjb250aW51ZTtcbiAgICBpZiAodGFiLmRpc2NhcmRlZCkgY29udGludWU7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdHMgPSAoYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgICAgZnVuYzogKCgpID0+IHtcbiAgICAgICAgICAvLyBTY3JvbGwgdGhlIHBhZ2UuIERpc3BhdGNoIEVuZCBrZXkgZmlyc3Qgc2luY2UgbWFueSBYIHN1cmZhY2VzXG4gICAgICAgICAgLy8gICAgKGxpc3RzLCBzZWFyY2gsIHJlcGxpZXMpIGJpbmQgcGFnaW5hdGlvbiB0cmlnZ2VycyB0byBpdCB2aWFcbiAgICAgICAgICAvLyAgICBSZWFjdCBoYW5kbGVyczsgdGhlbiBleHBsaWNpdGx5IHNjcm9sbCB0aGUgZG9jdW1lbnQuXG4gICAgICAgICAgY29uc3Qgb3B0czogS2V5Ym9hcmRFdmVudEluaXQgPSB7XG4gICAgICAgICAgICBrZXk6ICdFbmQnLFxuICAgICAgICAgICAgY29kZTogJ0VuZCcsXG4gICAgICAgICAgICBrZXlDb2RlOiAzNSxcbiAgICAgICAgICAgIHdoaWNoOiAzNSxcbiAgICAgICAgICAgIGJ1YmJsZXM6IHRydWUsXG4gICAgICAgICAgICBjYW5jZWxhYmxlOiB0cnVlLFxuICAgICAgICAgIH07XG4gICAgICAgICAgY29uc3QgZm9jdXMgPSAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCB8IG51bGwpID8/IGRvY3VtZW50LmJvZHk7XG4gICAgICAgICAgZm9jdXMuZGlzcGF0Y2hFdmVudChuZXcgS2V5Ym9hcmRFdmVudCgna2V5ZG93bicsIG9wdHMpKTtcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXl1cCcsIG9wdHMpKTtcbiAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oe1xuICAgICAgICAgICAgdG9wOiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsSGVpZ2h0LFxuICAgICAgICAgICAgYmVoYXZpb3I6ICdhdXRvJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSkgYXMgKCkgPT4gdm9pZCxcbiAgICAgIH0pKSBhcyBBcnJheTx7IHJlc3VsdD86IHVua25vd24gfT47XG4gICAgICBzY3JvbGxDb3VudCArPSAxO1xuICAgICAgdm9pZCByZXN1bHRzO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gVGFicyB0aGF0IGRpc2FsbG93IHNjcmlwdGluZyAoYWJvdXQ6LCBkaXNjYXJkZWQsIG1pZC1uYXZpZ2F0aW9uKVxuICAgICAgLy8ganVzdCBnZXQgc2tpcHBlZCBcdTIwMTQgdGhleSdsbCBiZSBlbGlnaWJsZSBvbiBhIGxhdGVyIHRpY2suXG4gICAgfVxuICB9XG4gIGlmIChzY3JvbGxDb3VudCA+IDApIHtcbiAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICBpZiAoc2VzcyAhPT0gbnVsbCkge1xuICAgICAgc2Vzcy5zY3JvbGxDb3VudCArPSBzY3JvbGxDb3VudDtcbiAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKHNlc3MpO1xuICAgICAgLy8gTm8gYnJvYWRjYXN0IG9uIGV2ZXJ5IHRpY2sgXHUyMDE0IHRoZSAxNXMgc2lkZWJhciByZWZyZXNoIHBpY2tzIGl0IHVwLlxuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBwcnVuZVNob3dNb3JlUmVsZXZhbmNlKCk6IHZvaWQge1xuICBjb25zdCBjdXRvZmYgPSBEYXRlLm5vdygpIC0gU0hPV19NT1JFX1JFTEVWQU5DRV9UVExfTVM7XG4gIGZvciAoY29uc3QgW3RhYklkLCBlbnRyeV0gb2Ygc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiKSB7XG4gICAgaWYgKGVudHJ5LnVwZGF0ZWRBdCA8IGN1dG9mZikgc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiLmRlbGV0ZSh0YWJJZCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVtZW1iZXJTaG93TW9yZVJlbGV2YW50VHdlZXRzKFxuICB0YWJJZDogbnVtYmVyIHwgbnVsbCxcbiAgcGFnZVVybDogc3RyaW5nIHwgbnVsbCxcbiAgdHdlZXRzOiBSZWFkb25seUFycmF5PENhbm9uaWNhbFR3ZWV0PixcbiAgY29yZUhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz5cbik6IHZvaWQge1xuICBpZiAodGFiSWQgPT09IG51bGwgfHwgdHdlZXRzLmxlbmd0aCA9PT0gMCB8fCBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm47XG4gIGNvbnN0IGNvcmVUd2VldElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgaWYgKGNvcmVIYW5kbGVzLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSBjb3JlVHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xuICB9XG4gIGNvbnN0IGV4aXN0aW5nID0gc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiLmdldCh0YWJJZCk7XG4gIGNvbnN0IHR3ZWV0SWRzID0gZXhpc3Rpbmc/LnR3ZWV0SWRzID8/IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgY29uc3QgaGFuZGxlID0gdC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IHJlcGx5SGFuZGxlID0gdC5yZXBseV90b19hY2NvdW50Py50b0xvd2VyQ2FzZSgpID8/IG51bGw7XG4gICAgaWYgKFxuICAgICAgY29yZUhhbmRsZXMuaGFzKGhhbmRsZSkgfHxcbiAgICAgIChyZXBseUhhbmRsZSAhPT0gbnVsbCAmJiBjb3JlSGFuZGxlcy5oYXMocmVwbHlIYW5kbGUpKSB8fFxuICAgICAgKHQucmVwbHlfdG9fdHdlZXRfaWQgIT09IG51bGwgJiYgY29yZVR3ZWV0SWRzLmhhcyh0LnJlcGx5X3RvX3R3ZWV0X2lkKSkgfHxcbiAgICAgICh0LnF1b3RlZF90d2VldF9pZCAhPT0gbnVsbCAmJiBjb3JlVHdlZXRJZHMuaGFzKHQucXVvdGVkX3R3ZWV0X2lkKSkgfHxcbiAgICAgICh0LnJldHdlZXRlZF90d2VldF9pZCAhPT0gbnVsbCAmJiBjb3JlVHdlZXRJZHMuaGFzKHQucmV0d2VldGVkX3R3ZWV0X2lkKSlcbiAgICApIHtcbiAgICAgIHR3ZWV0SWRzLmFkZCh0LnR3ZWV0X2lkKTtcbiAgICB9XG4gIH1cbiAgc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiLnNldCh0YWJJZCwge1xuICAgIHVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcbiAgICBwYWdlVXJsLFxuICAgIHR3ZWV0SWRzLFxuICB9KTtcbn1cblxuYnJvd3Nlci5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcigoYWxhcm0pID0+IHtcbiAgaWYgKGFsYXJtLm5hbWUgPT09ICdmbHVzaC1zd2VlcCcpIHtcbiAgICB2b2lkIGZsdXNoSWRsZUJ1ZmZlcnMoKTtcbiAgfSBlbHNlIGlmIChhbGFybS5uYW1lID09PSAndmVyaWZ5LWNvbm5lY3Rpb24nKSB7XG4gICAgdm9pZCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgfVxuICAvLyByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcHJldmlvdXNseSByYW4gdmlhIGFsYXJtczsgdGhleSBub3cgdXNlXG4gIC8vIHNldEludGVydmFsIHRvIGVzY2FwZSB0aGUgMzBzIGFsYXJtIGZsb29yLiBMZWF2ZSB0aGUgbmFtZXMgbGlzdGVkXG4gIC8vIG5vd2hlcmUgc28gYW55IG9ycGhhbmVkIGFsYXJtcyAoZnJvbSBvbGRlciBidWlsZHMpIGp1c3Qgbm8tb3AuXG59KTtcblxuLy8gLS0tIFRvb2xiYXIgYWN0aW9uOiB0b2dnbGUgdGhlIHNpZGViYXIgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuaWYgKGJyb3dzZXIuYWN0aW9uPy5vbkNsaWNrZWQpIHtcbiAgYnJvd3Nlci5hY3Rpb24ub25DbGlja2VkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci5zaWRlYmFyQWN0aW9uLnRvZ2dsZSgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgLy8gRmFsbGJhY2s6IG9wZW4gb3B0aW9ucyBpZiBzaWRlYmFyIGNhbid0IGJlIHRvZ2dsZWQuXG4gICAgICBhd2FpdCB3YXJuKCdzaWRlYmFyIHRvZ2dsZSBmYWlsZWQ7IG9wZW5pbmcgb3B0aW9ucycsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgfVxuICB9KTtcbn1cblxuLy8gLS0tIFJ1bnRpbWUgbWVzc2FnZSBkaXNwYXRjaCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24sIHNlbmRlcikgPT4ge1xuICBpZiAoIWlzUnVudGltZU1lc3NhZ2UobXNnKSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgcmV0dXJuIGhhbmRsZU1lc3NhZ2UobXNnLCBzZW5kZXIpLmNhdGNoKChlcnIpID0+IHtcbiAgICB2b2lkIGxvZ0VycignbWVzc2FnZSBoYW5kbGVyIGZhaWxlZCcsIHsgdHlwZTogbXNnLnR5cGUsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgICB0aHJvdyBlcnI7XG4gIH0pO1xufSk7XG5cbmZ1bmN0aW9uIGlzUnVudGltZU1lc3NhZ2UobTogdW5rbm93bik6IG0gaXMgUnVudGltZU1lc3NhZ2Uge1xuICByZXR1cm4gISFtICYmIHR5cGVvZiBtID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgKG0gYXMgeyB0eXBlPzogdW5rbm93biB9KS50eXBlID09PSAnc3RyaW5nJztcbn1cblxuLyoqIE1lc3NhZ2VzIHRoYXQgZHJpdmUgdGhlIGNhcHR1cmUgcGlwZWxpbmUuIFdoZW4gdGhlIG1hc3RlciBzd2l0Y2ggaXMgT0ZGXG4gKiB3ZSBpZ25vcmUgdGhlc2UgYnV0IHN0aWxsIHJlc3BvbmQgdG8gc3RhdHVzIC8gY29uZmlndXJhdGlvbiBxdWVyaWVzLiAqL1xuY29uc3QgQ0FQVFVSRV9QSVBFTElORV9NRVNTQUdFUyA9IG5ldyBTZXQ8UnVudGltZU1lc3NhZ2VbJ3R5cGUnXT4oW1xuICAnZ3JhcGhxbC1jYXB0dXJlJyxcbiAgJ2NhcHR1cmUtbm93JyxcbiAgJ2NhcHR1cmUtYWxsJyxcbiAgJ2NhcHR1cmUtdGhpcy1wYWdlJyxcbiAgJ2ZsdXNoLWFsbCcsXG4gICdmbHVzaC1oYW5kbGUnLFxuICAnc3RhcnQtcmVmZXRjaCcsXG4gICdzdGFydC1tZWRpYS1jcmF3bCcsXG4gICdzdGFydC10aHJlYWQtb3BlbicsXG4gICdzdGFydC1hdXRvLXNjcm9sbCcsXG5dKTtcblxuYXN5bmMgZnVuY3Rpb24gaXNFbmFibGVkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgcmV0dXJuIHMuZW5hYmxlZCAhPT0gZmFsc2U7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UoXG4gIG1zZzogUnVudGltZU1lc3NhZ2UsXG4gIHNlbmRlcj86IGJyb3dzZXIucnVudGltZS5NZXNzYWdlU2VuZGVyXG4pOiBQcm9taXNlPHVua25vd24+IHtcbiAgLy8gTWFzdGVyIHN3aXRjaDogd2hlbiB0aGUgdXNlciBoYXMgcGF1c2VkIHRoZSBleHRlbnNpb24gd2Ugc3RpbGwgbmVlZFxuICAvLyB0aGUgbWV0YS1jaGFubmVscyAoZ2V0LXN0YXRlLCB0b2dnbGUtZW5hYmxlZCwgb3Blbi1vcHRpb25zLCBcdTIwMjYpIHNvIHRoZVxuICAvLyBzaWRlYmFyIHN0YXlzIGZ1bmN0aW9uYWwsIGJ1dCBhbnl0aGluZyB0aGF0IHdvdWxkIGFjdHVhbGx5IGNhcHR1cmUsXG4gIC8vIGNvbW1pdCwgb3IgZHJpdmUgYSB0YWIgaXMgYSBuby1vcC5cbiAgaWYgKCEoYXdhaXQgaXNFbmFibGVkKCkpICYmIENBUFRVUkVfUElQRUxJTkVfTUVTU0FHRVMuaGFzKG1zZy50eXBlKSkge1xuICAgIHJldHVybiB7IG9rOiB0cnVlLCBwYXVzZWQ6IHRydWUgfTtcbiAgfVxuICBzd2l0Y2ggKG1zZy50eXBlKSB7XG4gICAgY2FzZSAnZ3JhcGhxbC1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IG9uR3JhcGhxbENhcHR1cmUoXG4gICAgICAgIG1zZy5lbmRwb2ludCxcbiAgICAgICAgbXNnLnVybCxcbiAgICAgICAgbXNnLnBhZ2VVcmwgPz8gbnVsbCxcbiAgICAgICAgbXNnLnJlc3BvbnNlLFxuICAgICAgICBzZW5kZXI/LnRhYj8uaWQgPz8gbnVsbFxuICAgICAgKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnY29udGVudC1hbGl2ZSc6XG4gICAgICBhd2FpdCBpbmZvKCdjb250ZW50IHNjcmlwdCBhbGl2ZSBvbiBwYWdlJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ3BhZ2UtaG9vay1hY3RpdmUnOlxuICAgICAgYXdhaXQgaW5mbygncGFnZSBob29rIHBhdGNoZWQgZmV0Y2gvWEhSJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2xvZy1jb250ZW50LWV2ZW50JzpcbiAgICAgIGlmIChtc2cubGV2ZWwgPT09ICd3YXJuJykge1xuICAgICAgICBhd2FpdCB3YXJuKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfSBlbHNlIGlmIChtc2cubGV2ZWwgPT09ICdlcnJvcicpIHtcbiAgICAgICAgYXdhaXQgbG9nRXJyKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgaW5mbyhtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnZ2V0LXVuZm9sZC10YXJnZXRzJzoge1xuICAgICAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICAgICAgaWYgKHNldHRpbmdzLmVuYWJsZWQgPT09IGZhbHNlKSB7XG4gICAgICAgIHJldHVybiB7IGVuYWJsZWQ6IGZhbHNlLCBjb3JlSGFuZGxlczogW10sIHJlbGV2YW50VHdlZXRJZHM6IFtdIH07XG4gICAgICB9XG4gICAgICBwcnVuZVNob3dNb3JlUmVsZXZhbmNlKCk7XG4gICAgICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gICAgICBjb25zdCBjb3JlSGFuZGxlcyA9IGFjY291bnRzXG4gICAgICAgIC5maWx0ZXIoKGEpID0+IGEuY2F0ZWdvcnkgPT09ICdjb3JlJylcbiAgICAgICAgLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSk7XG4gICAgICBjb25zdCB0YWJJZCA9IHNlbmRlcj8udGFiPy5pZCA/PyBudWxsO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgY29yZUhhbmRsZXMsXG4gICAgICAgIHJlbGV2YW50VHdlZXRJZHM6XG4gICAgICAgICAgdGFiSWQgPT09IG51bGwgPyBbXSA6IEFycmF5LmZyb20oc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiLmdldCh0YWJJZCk/LnR3ZWV0SWRzID8/IFtdKSxcbiAgICAgIH07XG4gICAgfVxuICAgIGNhc2UgJ3Nob3ctbW9yZS11bmZvbGRlZCc6IHtcbiAgICAgIGlmIChtc2cuY291bnQgPiAwKSB7XG4gICAgICAgIGNvbnN0IGFzU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICAgIGlmIChhc1Nlc3MgIT09IG51bGwpIHtcbiAgICAgICAgICBhc1Nlc3MuZXhwYW5kZWRDb3VudCArPSBtc2cuY291bnQ7XG4gICAgICAgICAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oYXNTZXNzKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gICAgY2FzZSAnZ2V0LXN0YXRlJzpcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS1ub3cnOlxuICAgICAgYXdhaXQgY2FwdHVyZU5vdyhtc2cuaGFuZGxlKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS1hbGwnOlxuICAgICAgYXdhaXQgY2FwdHVyZUFsbCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLXRoaXMtcGFnZSc6XG4gICAgICBhd2FpdCBjYXB0dXJlVGhpc1BhZ2UoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnZmx1c2gtYWxsJzpcbiAgICAgIGF3YWl0IGZsdXNoQWxsKCd1c2VyJyk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2ZsdXNoLWhhbmRsZSc6XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShtc2cuaGFuZGxlLCAndXNlcicpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtYXV0by1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b0NhcHR1cmU6IG1zZy5vbiB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2F1dG8tY2FwdHVyZSB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtdXBkYXRlLWV4aXN0aW5nJzpcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgdXBkYXRlRXhpc3Rpbmc6IG1zZy5vbiB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ3VwZGF0ZS1leGlzdGluZyB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtbG93LWJhbmR3aWR0aCc6XG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGxvd0JhbmR3aWR0aEJyb3dzaW5nOiBtc2cub24gfSk7XG4gICAgICBhd2FpdCBzeW5jTG93QmFuZHdpZHRoUnVsZXMoeyByZWFzb246ICd0b2dnbGUnLCBsb2c6IHRydWUgfSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3RvZ2dsZS1lbmFibGVkJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgZW5hYmxlZDogbXNnLm9uIH0pO1xuICAgICAgaWYgKCFtc2cub24pIHtcbiAgICAgICAgLy8gUGF1c2luZyBzdG9wcyBhbGwgaW4tZmxpZ2h0IGxvb3BzIHNvIHRoZSB1c2VyIGdldHMgaW1tZWRpYXRlXG4gICAgICAgIC8vIHF1aWV0LCBub3QgYSBcIm9uZSBtb3JlIHRpY2tcIiBzdXJwcmlzZS5cbiAgICAgICAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgICAgICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICAgICAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgICAgIHN0b3BUaHJlYWRPcGVuSW50ZXJ2YWwoKTtcbiAgICAgICAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignbWVkaWEtY3Jhd2wtdGljaycpO1xuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigndGhyZWFkLW9wZW4tdGljaycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gUmVzdW1pbmcgcmUtYXJtcyBhbnkgbG9vcHMgd2hvc2Ugc2Vzc2lvbiBpcyBzdGlsbCBzZXQuXG4gICAgICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBtYXN0ZXIgc3dpdGNoIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIH1cbiAgICBjYXNlICdzdGFydC1hdXRvLXNjcm9sbCc6XG4gICAgICBhd2FpdCBzdGFydEF1dG9TY3JvbGxMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1hdXRvLXNjcm9sbCc6XG4gICAgICBhd2FpdCBjYW5jZWxBdXRvU2Nyb2xsTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdzZXQtYXV0by1zY3JvbGwtaW50ZXJ2YWwnOiB7XG4gICAgICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXG4gICAgICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQobXNnLnNlY29uZHMpKVxuICAgICAgKTtcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzZWNvbmRzIH0pO1xuICAgICAgLy8gUmUtYXJtIGFueSBhY3RpdmUgbG9vcHMgd2l0aCB0aGUgbmV3IGludGVydmFsLlxuICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHNlY29uZHMpO1xuICAgICAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kcyk7XG4gICAgICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzKTtcbiAgICAgIGlmICh0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHN0YXJ0VGhyZWFkT3BlbkludGVydmFsKHNlY29uZHMpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAnc3RhcnQtcmVmZXRjaCc6XG4gICAgICBhd2FpdCBzdGFydFJlZmV0Y2hMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1yZWZldGNoJzpcbiAgICAgIGF3YWl0IGNhbmNlbFJlZmV0Y2hMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3N0YXJ0LW1lZGlhLWNyYXdsJzpcbiAgICAgIGF3YWl0IHN0YXJ0TWVkaWFDcmF3bExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLW1lZGlhLWNyYXdsJzpcbiAgICAgIGF3YWl0IGNhbmNlbE1lZGlhQ3Jhd2xMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3N0YXJ0LXRocmVhZC1vcGVuJzpcbiAgICAgIGF3YWl0IHN0YXJ0VGhyZWFkT3Blbkxvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLXRocmVhZC1vcGVuJzpcbiAgICAgIGF3YWl0IGNhbmNlbFRocmVhZE9wZW5Mb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3B1cmdlLXVucmVsYXRlZCc6IHtcbiAgICAgIGNvbnN0IGFjY3MgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICAgICAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjcy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcbiAgICAgIGNvbnN0IHN1bW1hcnkgPSBhd2FpdCBwdXJnZVVucmVsYXRlZFN0YXRlKHRyYWNrZWQpO1xuICAgICAgYXdhaXQgaW5mbygncHVyZ2VkIHVucmVsYXRlZCBzdGF0ZScsIHN1bW1hcnkpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAncmVmcmVzaC1hY2NvdW50cyc6XG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd2ZXJpZnktY29ubmVjdGlvbic6XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjbGVhci1hY3Rpdml0eSc6XG4gICAgICBhd2FpdCBjbGVhckFjdGl2aXR5KCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tb3B0aW9ucyc6XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tdmlld2VyJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgICBjb25zdCB1cmwgPSB2aWV3ZXJVcmwocyk7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICd1bmtub3duIG1lc3NhZ2UgdHlwZScgfTtcbiAgfVxufVxuXG4vLyAtLS0gQ2FwdHVyZSBwaXBlbGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBvbkdyYXBocWxDYXB0dXJlKFxuICBlbmRwb2ludDogc3RyaW5nLFxuICB1cmw6IHN0cmluZyxcbiAgcGFnZVVybDogc3RyaW5nIHwgbnVsbCxcbiAgcmVzcG9uc2U6IHVua25vd24sXG4gIHNlbmRlclRhYklkOiBudW1iZXIgfCBudWxsXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKFBST0ZJTEVfRU5EUE9JTlRTLmhhcyhlbmRwb2ludCkpIHJldHVybjsgLy8gbm90IHR3ZWV0LWJlYXJpbmdcbiAgaWYgKCFUV0VFVF9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuO1xuXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKHNldHRpbmdzLmVuYWJsZWQgPT09IGZhbHNlKSByZXR1cm47XG4gIGlmIChzZXR0aW5ncy5hdXRvQ2FwdHVyZSA9PT0gZmFsc2UpIHtcbiAgICBjb25zdCBleHBsaWNpdENhcHR1cmVBY3RpdmUgPVxuICAgICAgRGF0ZS5ub3coKSA8IG1hbnVhbENhcHR1cmVVbnRpbE1zIHx8XG4gICAgICAoYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKSkgIT09IG51bGwgfHxcbiAgICAgIChhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpKSAhPT0gbnVsbCB8fFxuICAgICAgKGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCkpICE9PSBudWxsO1xuICAgIGlmICghZXhwbGljaXRDYXB0dXJlQWN0aXZlKSByZXR1cm47XG4gIH1cblxuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIC8vIFdlIGRlbGliZXJhdGVseSBkbyBOT1Qgc2hvcnQtY2lyY3VpdCB3aGVuIHRoZSBQQVQgaXMgbWlzc2luZy4gVGhlXG4gIC8vIG5vcm1hbGl6ZSBzdGVwIGlzIGNoZWFwLCB0aGUgYnVmZmVyIHN1cnZpdmVzIHNlcnZpY2Utd29ya2VyIGV2aWN0aW9uLFxuICAvLyBhbmQgb25jZSB0aGUgUEFUIGlzIHNldCB0aGUgbmV4dCBhbGFybSBvciB1c2VyLXRyaWdnZXJlZCBmbHVzaCBjb21taXRzXG4gIC8vIGV2ZXJ5dGhpbmcgd2UndmUgc2Vlbi4gRHJvcHBpbmcgY2FwdHVyZXMgaGVyZSB3YXMgaGlkaW5nIHRoZSB1c2VyJ3NcbiAgLy8gZmlyc3QgYnJvd3Npbmcgc2Vzc2lvbiBlbnRpcmVseS5cblxuICAvLyBUd28tc3RhZ2UgZmlsdGVyOlxuICAvLyAgIDEuIEJ1aWxkIEVWRVJZIGNhbm9uaWNhbCB0d2VldCB3ZSBjYW4gZmluZCBpbiB0aGUgcmVzcG9uc2UgKG5vIGhhbmRsZVxuICAvLyAgICAgIGZpbHRlciBhdCB0aGUgbm9ybWFsaXplciBsZXZlbCBcdTIwMTQgd2Ugc3RpbGwgd2FudCBxdW90ZWQvUlQnZCBwYXJlbnRzXG4gIC8vICAgICAgdGhhdCBhcHBlYXIgYXMgc2libGluZyBub2RlcykuXG4gIC8vICAgMi4gQXBwbHkgYGZpbHRlclJlbGF0ZWRgIHBvc3QtaG9jIHRvIGRyb3AgYW55dGhpbmcgdGhhdCBoYXMgbm9cbiAgLy8gICAgICByZWxhdGlvbnNoaXAgdG8gYSB0cmFja2VkIGFjY291bnQuIFRoZSBvbGQgYmVoYXZpb3VyIChcImVtcHR5XG4gIC8vICAgICAgYWxsb3dlZC1zZXQgb24gdXNlci1wYWdlIGVuZHBvaW50cywgZnVsbCBmaWx0ZXIgb24gaG9tZS9zZWFyY2hcIilcbiAgLy8gICAgICB3YXMgd2F5IHRvbyBwZXJtaXNzaXZlIG9uIHRoZSBSZXBsaWVzIHRhYjogZXZlcnkgcmFuZG9tIHJlcGxpZXInc1xuICAvLyAgICAgIHJlcGx5IGxhbmRlZCBpbiBhIHBlci1oYW5kbGUgYnVmZmVyIGtleWVkIGJ5IHRoZWlyIG93biBoYW5kbGUuXG4gIGNvbnN0IHRyYWNrZWQgPSBuZXcgU2V0KGFjY291bnRzLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBjb3JlID0gbmV3IFNldChcbiAgICBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuY2F0ZWdvcnkgPT09ICdjb3JlJykubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKVxuICApO1xuICBjb25zdCBjYXB0dXJlZEF0ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuXG4gIGxldCBub3JtYWxpemVkO1xuICB0cnkge1xuICAgIG5vcm1hbGl6ZWQgPSBub3JtYWxpemUocmVzcG9uc2UsIHtcbiAgICAgIGNhcHR1cmVkQXQsXG4gICAgICBydW5JZDogJ3BlbmRpbmcnLFxuICAgICAgZW5kcG9pbnQsXG4gICAgICBhbGxvd2VkSGFuZGxlczogbmV3IFNldDxzdHJpbmc+KCksXG4gICAgICBzb3VyY2VVcmw6IHBhZ2VVcmwsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHF1YXJhbnRpbmUoJ25vcm1hbGl6ZS10aHJldycsIGVuZHBvaW50LCB1cmwsIHJlc3BvbnNlLCBlcnIpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCByZXR3ZWV0RWRnZXMgPSBidWlsZFJldHdlZXRFZGdlcyhcbiAgICBub3JtYWxpemVkLnR3ZWV0cyxcbiAgICBhY2NvdW50cyxcbiAgICBjYXB0dXJlZEF0LFxuICAgIGVuZHBvaW50LFxuICAgIHBhZ2VVcmwgPz8gdXJsXG4gICk7XG4gIC8vIERyb3AgdW5yZWxhdGVkIHR3ZWV0cy4gVGhlIGZpbHRlciBpcyBlbmRwb2ludC1hd2FyZTpcbiAgLy8gICAtIE9uIHRoZSBob21lIC8gc2VhcmNoIHRpbWVsaW5lcyB3ZSdkIGFscmVhZHkgYmVlbiBmaWx0ZXJpbmcgdG9cbiAgLy8gICAgIHRyYWNrZWQgYXV0aG9ycyBvbmx5IFx1MjAxNCBrZWVwIHRoYXQgYmVoYXZpb3VyIGJ1dCBnbyB0aHJvdWdoIHRoZSBzYW1lXG4gIC8vICAgICBgZmlsdGVyUmVsYXRlZGAgaGVscGVyIHNvIHRoZSBydWxlcyBhcmUgdW5pZm9ybS5cbiAgLy8gICAtIE9uIHVzZXItcGFnZSBlbmRwb2ludHMgd2Ugbm93IGFsc28gZHJvcCBhbnl0aGluZyB0aGF0IGlzbid0IGVpdGhlclxuICAvLyAgICAgYXV0aG9yZWQtYnksIG1lbnRpb25pbmcsIHJlcGx5aW5nLXRvLCBvciByZWZlcmVuY2VkLWJ5IGEgdHJhY2tlZFxuICAvLyAgICAgYWNjb3VudC5cbiAgY29uc3QgYmVmb3JlRmlsdGVyID0gbm9ybWFsaXplZC50d2VldHMubGVuZ3RoO1xuICBub3JtYWxpemVkLnR3ZWV0cyA9IGZpbHRlclJlbGF0ZWQobm9ybWFsaXplZC50d2VldHMsIHRyYWNrZWQsIGNvcmUpO1xuICBjb25zdCBkcm9wcGVkVW5yZWxhdGVkID0gYmVmb3JlRmlsdGVyIC0gbm9ybWFsaXplZC50d2VldHMubGVuZ3RoO1xuICBpZiAoZHJvcHBlZFVucmVsYXRlZCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdkcm9wcGVkIHVucmVsYXRlZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIGRyb3BwZWQ6IGRyb3BwZWRVbnJlbGF0ZWQsXG4gICAgICBrZXB0OiBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGgsXG4gICAgfSk7XG4gIH1cbiAgcmVtZW1iZXJTaG93TW9yZVJlbGV2YW50VHdlZXRzKHNlbmRlclRhYklkLCBwYWdlVXJsLCBub3JtYWxpemVkLnR3ZWV0cywgY29yZSk7XG5cbiAgLy8gRGlhZ25vc3RpYzogZXZlcnkgdHdlZXQtZW5kcG9pbnQgcGF5bG9hZCBnZXRzIGEgbGluZSBpbiB0aGUgYWN0aXZpdHlcbiAgLy8gdGFpbCB3aXRoIHdoYXQgd2Ugc2F3IHZzIGtlcHQuIFdoZW4gb2JzZXJ2ZWQ9MCB3ZSBhbHNvIGVtaXQgYSBzaGFwZVxuICAvLyBwcm9iZSAoa2V5IHBhdGhzICsgdHlwZW5hbWVzKSBzbyB3ZSBjYW4gdGVsbCB3aGV0aGVyIFggcmV0dXJuZWQgYW5cbiAgLy8gZW1wdHkgZW52ZWxvcGUsIGEgbG9naW4td2FsbCByZXNwb25zZSwgb3IgYSBuZXcgc2hhcGUgd2UgZG9uJ3Qga25vdyBob3dcbiAgLy8gdG8gd2FsayB5ZXQuXG4gIGlmIChub3JtYWxpemVkLm9ic2VydmVkX2lkcy5sZW5ndGggPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdncmFwaHFsIHBheWxvYWQgZW1wdHkgXHUyMDE0IHNoYXBlIHByb2JlJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICB0eXBlbmFtZXM6IHByb2JlVHlwZW5hbWVzKHJlc3BvbnNlKS5zbGljZSgwLCAzMCksXG4gICAgICB0d2VldF9rZXlzOiBwcm9iZUZpcnN0VHlwZVNoYXBlKHJlc3BvbnNlLCAnVHdlZXQnKSxcbiAgICAgIHR3ZWV0X2NvcmVfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgWydjb3JlJ10pLFxuICAgICAgdHdlZXRfbGVnYWN5X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFsnbGVnYWN5J10pLFxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXG4gICAgICAgICdjb3JlJyxcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXG4gICAgICAgICdyZXN1bHQnLFxuICAgICAgXSksXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2NvcmVfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xuICAgICAgICAnY29yZScsXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxuICAgICAgICAncmVzdWx0JyxcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgXSksXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2xlZ2FjeV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXG4gICAgICAgICdjb3JlJyxcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXG4gICAgICAgICdyZXN1bHQnLFxuICAgICAgICAnbGVnYWN5JyxcbiAgICAgIF0pLFxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGF3YWl0IGluZm8oJ2dyYXBocWwgcGF5bG9hZCBzZWVuJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBvYnNlcnZlZDogbm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoLFxuICAgICAga2VwdDogbm9ybWFsaXplZC50d2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG5cbiAgaWYgKG5vcm1hbGl6ZWQudW5hdmFpbGFibGVfdHdlZXRzLmxlbmd0aCA+IDApIHtcbiAgICBhd2FpdCByZWNvcmRVbmF2YWlsYWJsZVR3ZWV0cyhcbiAgICAgIG5vcm1hbGl6ZWQudW5hdmFpbGFibGVfdHdlZXRzLFxuICAgICAgdHJhY2tlZCxcbiAgICAgIGNhcHR1cmVkQXQsXG4gICAgICB1cmwsXG4gICAgICBlbmRwb2ludFxuICAgICk7XG4gIH1cblxuICBpZiAobm9ybWFsaXplZC50d2VldHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgYnVmZmVyZWRFZGdlcyA9IGF3YWl0IGJ1ZmZlclJldHdlZXRFZGdlcyhcbiAgICAgIHJldHdlZXRFZGdlcyxcbiAgICAgIGNhcHR1cmVkQXQsXG4gICAgICBwYWdlVXJsID8/IHVybCxcbiAgICAgIGVuZHBvaW50XG4gICAgKTtcbiAgICBpZiAoYnVmZmVyZWRFZGdlcyA+IDApIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gUmVmZXRjaCBxdWV1ZSBob3VzZWtlZXBpbmcgXHUyMDE0IHJ1bnMgQkVGT1JFIHRoZSBkZWR1cCBzaG9ydC1jaXJjdWl0LiBBXG4gIC8vIHJlZmV0Y2ggY2FwdHVyZSBjb21lcyBiYWNrIHdpdGggdGhlIHNhbWUgZW5nYWdlbWVudCBjb3VudHMgKHdlJ3JlXG4gIC8vIG9ubHkgYWZ0ZXIgdGhlIGZ1bGwgdGV4dCksIHNvIHRoZSBkZWR1cCBiZWxvdyB3b3VsZCBzaWxlbnRseSBkcm9wXG4gIC8vIGl0IGFuZCB0aGUgcXVldWUgd291bGQgbmV2ZXIgZHJhaW4uIEhvaXN0IHRoZSBlbnF1ZXVlL2RlcXVldWUgaGVyZVxuICAvLyBzbyB0aGUgbG9vcCByZWxpYWJseSBhZHZhbmNlcyBldmVuIHdoZW4gbm8gY29tbWl0IGhhcHBlbnMuXG4gIC8vXG4gIC8vIEFsc286IGlmIGVpdGhlciBsb29wJ3MgaW5mbGlnaHQgdGFyZ2V0IGFwcGVhcnMgaGVyZSwgbWFyayB0aGUgbG9vcFxuICAvLyBhcyBcImluZ2VzdGVkXCIgc28gdGhlIG5leHQgdGljayBjYW4gYWR2YW5jZS4gVGhlIHdhaXQtZm9yLWluZ2VzdFxuICAvLyBndWFyZCBvdGhlcndpc2UgYmxvY2tzIHVudGlsIHRoZSBuYXZpZ2F0aW9uLXRpbWVvdXQgZmlyZXMuXG4gIGNvbnN0IHJlZmV0Y2hTZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBjb25zdCB0aHJlYWRPcGVuU2VzcyA9IGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCk7XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGlmICh0LmlzX3RydW5jYXRlZCkge1xuICAgICAgYXdhaXQgZW5xdWV1ZVJlZmV0Y2godC5hY2NvdW50X2hhbmRsZSwgdC50d2VldF9pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xuICAgIH1cbiAgICAvLyBTdWNjZXNzZnVsbHkgYnVpbHQgdHdlZXRzIGFyZSBubyBsb25nZXIgXCJwYXJ0aWFsXCIgXHUyMDE0IGRyb3AgZnJvbSB0aGVcbiAgICAvLyBtZWRpYS1jcmF3bCBxdWV1ZSByZWdhcmRsZXNzIG9mIHdoaWNoIGhhbmRsZSB3ZSdkIGhpbnRlZCBlYXJsaWVyLlxuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHQudHdlZXRfaWQpO1xuICAgIGlmIChyZWZldGNoU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcbiAgICAgIHJlZmV0Y2hTZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIHJlZmV0Y2hTZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24ocmVmZXRjaFNlc3MpO1xuICAgIH1cbiAgICBpZiAobWVkaWFDcmF3bFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XG4gICAgICBtZWRpYUNyYXdsU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICBtZWRpYUNyYXdsU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG1lZGlhQ3Jhd2xTZXNzKTtcbiAgICB9XG4gICAgaWYgKHRocmVhZE9wZW5TZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdC50d2VldF9pZCkge1xuICAgICAgdGhyZWFkT3BlblNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgICAgdGhyZWFkT3BlblNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgICBhd2FpdCBtYXJrVGhyZWFkT3BlblNlZW4odC50d2VldF9pZCk7XG4gICAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih0LnR3ZWV0X2lkKTtcbiAgICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHRocmVhZE9wZW5TZXNzKTtcbiAgICB9XG4gIH1cblxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXQtc2hhcGVkIG5vZGVzIHRoZSB3YWxrZXIgc2F3IGJ1dCBjb3VsZG4ndCB0dXJuXG4gIC8vIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gRW5xdWV1ZSBvbmx5IElEcyB3ZSBoYXZlbid0IGFscmVhZHlcbiAgLy8gY29tbWl0dGVkICh1c2VyLXJlcXVlc3RlZCBkZWR1cCBhZ2FpbnN0IHRoZSBhcmNoaXZlKS5cbiAgZm9yIChjb25zdCBwYXJ0aWFsIG9mIG5vcm1hbGl6ZWQucGFydGlhbF9pZHMpIHtcbiAgICBpZiAoYXdhaXQgaXNDb21taXR0ZWQocGFydGlhbC50d2VldF9pZCkpIGNvbnRpbnVlO1xuICAgIGF3YWl0IGVucXVldWVNZWRpYUNyYXdsKHBhcnRpYWwuaGludF9oYW5kbGUsIHBhcnRpYWwudHdlZXRfaWQpO1xuICB9XG4gIGlmIChub3JtYWxpemVkLnBhcnRpYWxfaWRzLmxlbmd0aCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogZW5xdWV1ZWQgcGFydGlhbCBjYXB0dXJlcycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgcGFydGlhbDogbm9ybWFsaXplZC5wYXJ0aWFsX2lkcy5sZW5ndGgsXG4gICAgICBxdWV1ZV90b3RhbDogYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKSxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIENyb3NzLXNlc3Npb24gZGVkdXA6IGRyb3AgdHdlZXRzIHdlJ3ZlIGFscmVhZHkgY29tbWl0dGVkIHdpdGggaWRlbnRpY2FsXG4gIC8vIGVuZ2FnZW1lbnQgY291bnRzLiBMaWtlcy9SVHMvcmVwbGllcy9xdW90ZXMgc3RpbGwgdHJpZ2dlciBhIHJlY2FwdHVyZVxuICAvLyBzbyBlbmdhZ2VtZW50X2hpc3RvcnkgZ3Jvd3Mgb3ZlciB0aW1lLiB2aWV3X2NvdW50IGlzIGludGVudGlvbmFsbHlcbiAgLy8gZXhjbHVkZWQgXHUyMDE0IGl0IGNodXJucyB0b28gZmFzdCB0byBiZSB1c2VmdWwgYXMgYSBmcmVzaG5lc3Mgc2lnbmFsLlxuICAvLyBgaXNfdHJ1bmNhdGVkYCBpcyBwYXJ0IG9mIHRoZSBzaWduYXR1cmUgc28gYSByZWZldGNoIHRoYXQgZmxpcHNcbiAgLy8gdHJ1bmNhdGVkXHUyMTkyZnVsbCBpcyB0cmVhdGVkIGFzIGEgbWF0ZXJpYWwgY2hhbmdlIGFuZCBnZXRzIGNvbW1pdHRlZC5cbiAgLy9cbiAgLy8gV2hlbiB0aGUgdXNlciBoYXMgdHVybmVkIG9mZiBcInVwZGF0ZSBleGlzdGluZ1wiLCB3ZSBza2lwIHRoZSBlbmdhZ2VtZW50XG4gIC8vIGNvbXBhcmlzb24gZW50aXJlbHk6IGFueSB0d2VldCB0aGF0J3MgYWxyZWFkeSBjb21taXR0ZWQgdW5kZXIgYW55XG4gIC8vIGhhbmRsZSBnZXRzIGRyb3BwZWQgaGVyZSwgc28gd2UgZG9uJ3QgcGF5IEdpdEh1Yi1BUEkgb3ZlcmhlYWQganVzdCB0b1xuICAvLyByZWZyZXNoIGxpa2UgLyBSVCBjb3VudHMuIE5ldyB0d2VldHMgYW5kIHRydW5jYXRlZFx1MjE5MmZ1bGwgcmVmZXRjaGVzXG4gIC8vIHN0aWxsIGZsb3cgdGhyb3VnaCBub3JtYWxseSBiZWNhdXNlIHRoZXkgYXJlbid0IGluIHRoZSBpbmRleCB5ZXRcbiAgLy8gKG9yIGNhcnJ5IGFuIGlzX3RydW5jYXRlZCB0cmFuc2l0aW9uIHRoYXQgZmFpbHMgdGhlIHNpZyBjaGVjaykuXG4gIC8vIEZ1bGwtdGV4dCB1cGdyYWRlcyBieXBhc3MgdGhpcyBza2lwIGV2ZW4gd2l0aCB1cGRhdGVFeGlzdGluZz1mYWxzZS5cbiAgY29uc3QgdXBkYXRlRXhpc3RpbmcgPSBzZXR0aW5ncy51cGRhdGVFeGlzdGluZyAhPT0gZmFsc2U7XG4gIGNvbnN0IGNvbW1pdHRlZElkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGNvbnN0IGFyY2hpdmVTbmFwc2hvdCA9IGF3YWl0IGdldEFyY2hpdmVTbmFwc2hvdCgpO1xuICBsZXQgZGVkdXBlZFNraXBwZWQgPSAwO1xuICBsZXQgc2tpcHBlZE5vVXBkYXRlTG9jYWwgPSAwO1xuICBsZXQgc2tpcHBlZE5vVXBkYXRlU25hcHNob3QgPSAwO1xuICBsZXQgb2xkRnJvbVNuYXBzaG90ID0gMDtcbiAgbGV0IGZ1bGxUZXh0VXBncmFkZXMgPSAwO1xuICBjb25zdCBsaXZlVHdlZXRzOiB0eXBlb2Ygbm9ybWFsaXplZC50d2VldHMgPSBbXTtcbiAgY29uc3QgZnJlc2huZXNzQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCAnbmV3JyB8ICdleGlzdGluZyc+KCk7XG4gIGNvbnN0IGFjdGlvbkJ5SWQgPSBuZXcgTWFwPHN0cmluZywgVHdlZXRTaWdodGluZ1snYWN0aW9uJ10+KCk7XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbdC5hY2NvdW50X2hhbmRsZV0/Llt0LnR3ZWV0X2lkXTtcbiAgICBjb25zdCBvbGRCeVNuYXBzaG90ID0gIXByZXYgJiYgYXJjaGl2ZVNuYXBzaG90SGFzVHdlZXQodCwgYXJjaGl2ZVNuYXBzaG90KTtcbiAgICBjb25zdCBwcmV2aW91c2x5QXJjaGl2ZWQgPSBCb29sZWFuKHByZXYpIHx8IG9sZEJ5U25hcHNob3Q7XG4gICAgZnJlc2huZXNzQnlJZC5zZXQodC50d2VldF9pZCwgcHJldmlvdXNseUFyY2hpdmVkID8gJ2V4aXN0aW5nJyA6ICduZXcnKTtcbiAgICBpZiAob2xkQnlTbmFwc2hvdCkgb2xkRnJvbVNuYXBzaG90ICs9IDE7XG4gICAgY29uc3Qgc2lnID0gZW5nYWdlbWVudFNpZyhcbiAgICAgIHQubGlrZV9jb3VudCxcbiAgICAgIHQucmV0d2VldF9jb3VudCxcbiAgICAgIHQucmVwbHlfY291bnQsXG4gICAgICB0LnF1b3RlX2NvdW50LFxuICAgICAgdC5pc190cnVuY2F0ZWRcbiAgICApO1xuICAgIGNvbnN0IGZ1bGxUZXh0VXBncmFkZSA9IHByZXYgIT09IHVuZGVmaW5lZCAmJiBzaWdNYXJrc1RydW5jYXRlZChwcmV2LnNpZykgJiYgIXQuaXNfdHJ1bmNhdGVkO1xuICAgIGlmIChwcmV2aW91c2x5QXJjaGl2ZWQgJiYgIXVwZGF0ZUV4aXN0aW5nICYmICFmdWxsVGV4dFVwZ3JhZGUpIHtcbiAgICAgIGlmIChwcmV2KSBza2lwcGVkTm9VcGRhdGVMb2NhbCArPSAxO1xuICAgICAgZWxzZSBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCArPSAxO1xuICAgICAgYWN0aW9uQnlJZC5zZXQodC50d2VldF9pZCwgJ3NraXBwZWQnKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAocHJldiAmJiBwcmV2LnNpZyA9PT0gc2lnKSB7XG4gICAgICBkZWR1cGVkU2tpcHBlZCArPSAxO1xuICAgICAgYWN0aW9uQnlJZC5zZXQodC50d2VldF9pZCwgJ3VuY2hhbmdlZCcpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChmdWxsVGV4dFVwZ3JhZGUpIGZ1bGxUZXh0VXBncmFkZXMgKz0gMTtcbiAgICBhY3Rpb25CeUlkLnNldCh0LnR3ZWV0X2lkLCAnYnVmZmVyZWQnKTtcbiAgICBsaXZlVHdlZXRzLnB1c2godCk7XG4gIH1cbiAgaWYgKGRlZHVwZWRTa2lwcGVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2RlZHVwOiBza2lwcGVkIHVuY2hhbmdlZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHNraXBwZWQ6IGRlZHVwZWRTa2lwcGVkLFxuICAgICAgcmVtYWluaW5nOiBsaXZlVHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuICBpZiAoc2tpcHBlZE5vVXBkYXRlTG9jYWwgKyBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCA+IDApIHtcbiAgICBjb25zdCBza2lwcGVkT2xkID0gc2tpcHBlZE5vVXBkYXRlTG9jYWwgKyBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdDtcbiAgICBhd2FpdCBpbmZvKCdkZWR1cDogc2tpcHBlZCBwcmV2aW91c2x5IGFyY2hpdmVkIHR3ZWV0cyAodXBkYXRlRXhpc3Rpbmc9ZmFsc2UpJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBza2lwcGVkOiBza2lwcGVkT2xkLFxuICAgICAgbG9jYWxfaW5kZXg6IHNraXBwZWROb1VwZGF0ZUxvY2FsLFxuICAgICAgYXJjaGl2ZV9zbmFwc2hvdDogc2tpcHBlZE5vVXBkYXRlU25hcHNob3QsXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICAgIGNvbnN0IGFzU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xuICAgICAgYXNTZXNzLnNraXBwZWRPbGRDb3VudCA9IChhc1Nlc3Muc2tpcHBlZE9sZENvdW50ID8/IDApICsgc2tpcHBlZE9sZDtcbiAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKGFzU2Vzcyk7XG4gICAgfVxuICB9XG4gIGlmIChvbGRGcm9tU25hcHNob3QgPiAwICYmIHVwZGF0ZUV4aXN0aW5nKSB7XG4gICAgYXdhaXQgaW5mbygnYXJjaGl2ZSBzbmFwc2hvdCByZWNvZ25pemVkIG9sZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIG9sZDogb2xkRnJvbVNuYXBzaG90LFxuICAgICAgYWN0aW9uOiAnYnVmZmVyaW5nIGJlY2F1c2UgdXBkYXRlRXhpc3Rpbmc9dHJ1ZScsXG4gICAgICBzbmFwc2hvdF9nZW5lcmF0ZWRfYXQ6IGFyY2hpdmVTbmFwc2hvdD8uZ2VuZXJhdGVkX2F0ID8/IG51bGwsXG4gICAgfSk7XG4gIH1cbiAgaWYgKGZ1bGxUZXh0VXBncmFkZXMgPiAwKSB7XG4gICAgYXdhaXQgaW5mbygnZGVkdXA6IGJ1ZmZlcmluZyBmdWxsLXRleHQgdXBncmFkZXMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHVwZ3JhZGVzOiBmdWxsVGV4dFVwZ3JhZGVzLFxuICAgICAgdXBkYXRlRXhpc3RpbmcsXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG4gIGF3YWl0IHByZXBlbmRSZWNlbnRUd2VldFNpZ2h0aW5ncyhcbiAgICBub3JtYWxpemVkLnR3ZWV0cy5tYXAoKHQpID0+XG4gICAgICBidWlsZFR3ZWV0U2lnaHRpbmcoXG4gICAgICAgIHQsXG4gICAgICAgIGVuZHBvaW50LFxuICAgICAgICBjYXB0dXJlZEF0LFxuICAgICAgICBmcmVzaG5lc3NCeUlkLmdldCh0LnR3ZWV0X2lkKSxcbiAgICAgICAgYWN0aW9uQnlJZC5nZXQodC50d2VldF9pZClcbiAgICAgIClcbiAgICApXG4gICk7XG4gIC8vIC0tLSBNaXNzaW5nLXBhcmVudCByZWNvdmVyeSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFgncyBVc2VyVHdlZXRzQW5kUmVwbGllcyBlbmRwb2ludCBzb21ldGltZXMgc2VydmVzIGEgcmVwbHkgd2l0aG91dCB0aGVcbiAgLy8gcGFyZW50IHR3ZWV0IGl0IHBvaW50cyBhdCBcdTIwMTQgb25seSBhbiBpbl9yZXBseV90b19zY3JlZW5fbmFtZSBhbmNob3IuIFdlXG4gIC8vIG5ldmVyIHNlZSB0aGF0IHBhcmVudCwgc28gaXQgbmV2ZXIgbGFuZHMgaW4gdGhlIGFyY2hpdmUuIFNhbWUgZm9yXG4gIC8vIHF1b3RlZF90d2VldF9pZCAvIHJldHdlZXRlZF90d2VldF9pZCB3aGVuIFggc3RyaXBzIHRoZSByZWZlcmVuY2VkXG4gIC8vIG5vZGUuIFdhbGsgdGhlIHR3ZWV0cyB3ZSBqdXN0IHNhdywgZmluZCBhbnkgcGFyZW50IElEIHdlIGRvbid0IGhhdmUsXG4gIC8vIGFuZCBlbnF1ZXVlIGl0IG9uIHRoZSBtZWRpYS1jcmF3bCBsb29wIHNvIGl0cyBkZXRhaWwgcGFnZSBnZXRzXG4gIC8vIHZpc2l0ZWQgYW5kIGluZ2VzdGVkIG5leHQgdGltZSB0aGUgdXNlciBzdGFydHMgdGhlIGNyYXdsLlxuICBhd2FpdCBlbnF1ZXVlTWlzc2luZ1BhcmVudHMobm9ybWFsaXplZC50d2VldHMsIGVuZHBvaW50KTtcbiAgYXdhaXQgZW5xdWV1ZVRocmVhZE9wZW5DYW5kaWRhdGVzKG5vcm1hbGl6ZWQudHdlZXRzLCBjb3JlLCBlbmRwb2ludCk7XG4gIGNvbnN0IGJ1ZmZlcmVkUmV0d2VldEVkZ2VzID0gYXdhaXQgYnVmZmVyUmV0d2VldEVkZ2VzKFxuICAgIHJldHdlZXRFZGdlcyxcbiAgICBjYXB0dXJlZEF0LFxuICAgIHBhZ2VVcmwgPz8gdXJsLFxuICAgIGVuZHBvaW50XG4gICk7XG4gIGlmIChsaXZlVHdlZXRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGlmIChidWZmZXJlZFJldHdlZXRFZGdlcyA+IDApIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gR3JvdXAgc3Vydml2aW5nIHR3ZWV0cyBieSBhdXRob3IgaGFuZGxlLlxuICBjb25zdCBieUhhbmRsZSA9IG5ldyBNYXA8c3RyaW5nLCBDYW5vbmljYWxUd2VldFtdPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgbGl2ZVR3ZWV0cykge1xuICAgIGNvbnN0IGFyciA9IGJ5SGFuZGxlLmdldCh0LmFjY291bnRfaGFuZGxlKSA/PyBbXTtcbiAgICBhcnIucHVzaCh0KTtcbiAgICBieUhhbmRsZS5zZXQodC5hY2NvdW50X2hhbmRsZSwgYXJyKTtcbiAgfVxuXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgdHdlZXRzXSBvZiBieUhhbmRsZSkge1xuICAgIGNvbnN0IGJ1ZiA9IGF3YWl0IGVuc3VyZVJ1bkJ1ZmZlcihoYW5kbGUsIGNhcHR1cmVkQXQsIHVybCwgZW5kcG9pbnQpO1xuICAgIGxldCBhZGRlZCA9IDA7XG4gICAgbGV0IGFkZGVkTmV3ID0gMDtcbiAgICBsZXQgYWRkZWRFeGlzdGluZyA9IDA7XG4gICAgbGV0IHVwZGF0ZWRCdWZmZXJlZCA9IDA7XG4gICAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgICAgY29uc3QgZXhpc3RpbmcgPSBidWYudHdlZXRzX2J5X2lkW3QudHdlZXRfaWRdO1xuICAgICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICAgIC8vIFByZXNlcnZlIGZpcnN0X2NhcHR1cmVkX2F0LCBhcHBlbmQgZW5nYWdlbWVudCBzbmFwc2hvdCwgcmVmcmVzaFxuICAgICAgICAvLyBsYXN0X3NlZW5fYXQgKyBjb3VudHMgKHRoZSBsYXRlc3Qgc2NyYXBlIHdpbnMgZm9yIGNvdW50cykuXG4gICAgICAgIGV4aXN0aW5nLmxhc3Rfc2Vlbl9hdCA9IGNhcHR1cmVkQXQ7XG4gICAgICAgIGV4aXN0aW5nLmxpa2VfY291bnQgPSB0Lmxpa2VfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnJldHdlZXRfY291bnQgPSB0LnJldHdlZXRfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnJlcGx5X2NvdW50ID0gdC5yZXBseV9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucXVvdGVfY291bnQgPSB0LnF1b3RlX2NvdW50O1xuICAgICAgICBleGlzdGluZy52aWV3X2NvdW50ID0gdC52aWV3X2NvdW50O1xuICAgICAgICBleGlzdGluZy5ib29rbWFya19jb3VudCA9IHQuYm9va21hcmtfY291bnQ7XG4gICAgICAgIGNvbnN0IGxhc3QgPSBleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnlbZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5Lmxlbmd0aCAtIDFdO1xuICAgICAgICBjb25zdCBzbmFwID0gdC5lbmdhZ2VtZW50X2hpc3RvcnlbMF07XG4gICAgICAgIGlmIChzbmFwICYmICghbGFzdCB8fCBsYXN0LmNhcHR1cmVkX2F0ICE9PSBzbmFwLmNhcHR1cmVkX2F0KSkge1xuICAgICAgICAgIGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeS5wdXNoKHNuYXApO1xuICAgICAgICB9XG4gICAgICAgIHVwZGF0ZWRCdWZmZXJlZCArPSAxO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3Qgc3RhbXBlZDogQ2Fub25pY2FsVHdlZXQgPSB7IC4uLnQsIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkIH07XG4gICAgICAgIGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF0gPSBzdGFtcGVkO1xuICAgICAgICBhZGRlZCArPSAxO1xuICAgICAgICBpZiAoZnJlc2huZXNzQnlJZC5nZXQodC50d2VldF9pZCkgPT09ICdleGlzdGluZycpIGFkZGVkRXhpc3RpbmcgKz0gMTtcbiAgICAgICAgZWxzZSBhZGRlZE5ldyArPSAxO1xuICAgICAgfVxuICAgICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHQudHdlZXRfaWQpKSB7XG4gICAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFidWYuZW5kcG9pbnRzX3NlZW4uaW5jbHVkZXMoZW5kcG9pbnQpKSBidWYuZW5kcG9pbnRzX3NlZW4ucHVzaChlbmRwb2ludCk7XG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcbiAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgcnVuQnVmZmVySXRlbUNvdW50KGJ1ZikpO1xuICAgIGlmIChhZGRlZCA+IDAgfHwgdXBkYXRlZEJ1ZmZlcmVkID4gMCkge1xuICAgICAgYXdhaXQgaW5mbygnYnVmZmVyZWQgdHdlZXRzJywge1xuICAgICAgICBoYW5kbGUsXG4gICAgICAgIGVuZHBvaW50LFxuICAgICAgICBhZGRlZCxcbiAgICAgICAgbmV3OiBhZGRlZE5ldyxcbiAgICAgICAgZXhpc3Rpbmc6IGFkZGVkRXhpc3RpbmcsXG4gICAgICAgIHVwZGF0ZWRfYnVmZmVyZWQ6IHVwZGF0ZWRCdWZmZXJlZCxcbiAgICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCxcbiAgICAgIH0pO1xuICAgICAgLy8gQnVtcCB0aGUgYXV0by1zY3JvbGwgcHJvZ3Jlc3Mgc28gdGhlIHVzZXIgc2VlcyBcIlggaW5nZXN0ZWRcIiB0aWNrIHVwXG4gICAgICAvLyBpbiByZWFsIHRpbWUuIFdlIGNvdW50IGFjdHVhbGx5LW5ldyB0d2VldHMsIG5vdCBkdXBsaWNhdGVzLlxuICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgIGlmIChhc1Nlc3MgIT09IG51bGwpIHtcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkQ291bnQgKz0gYWRkZWQ7XG4gICAgICAgIGFzU2Vzcy5pbmdlc3RlZE5ld0NvdW50ID0gKGFzU2Vzcy5pbmdlc3RlZE5ld0NvdW50ID8/IDApICsgYWRkZWROZXc7XG4gICAgICAgIGFzU2Vzcy5pbmdlc3RlZEV4aXN0aW5nQ291bnQgPSAoYXNTZXNzLmluZ2VzdGVkRXhpc3RpbmdDb3VudCA/PyAwKSArIGFkZGVkRXhpc3Rpbmc7XG4gICAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKGFzU2Vzcyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggPj0gRkxVU0hfVFdFRVRfVEhSRVNIT0xEKSB7XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICd0aHJlc2hvbGQnKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVjb3JkVW5hdmFpbGFibGVUd2VldHMoXG4gIHVuYXZhaWxhYmxlVHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W10sXG4gIHRyYWNrZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4sXG4gIGNhcHR1cmVkQXQ6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBjb21taXR0ZWRJZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xTZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgY29uc3QgdGhyZWFkT3BlblNlc3MgPSBhd2FpdCBnZXRUaHJlYWRPcGVuU2Vzc2lvbigpO1xuICBsZXQgcmVjb3JkZWQgPSAwO1xuICBsZXQgc2tpcHBlZCA9IDA7XG4gIGxldCBtaXNzaW5nSGFuZGxlID0gMDtcblxuICBmb3IgKGNvbnN0IHUgb2YgdW5hdmFpbGFibGVUd2VldHMpIHtcbiAgICBjb25zdCBoYW5kbGUgPSB1LmFjY291bnRfaGFuZGxlO1xuICAgIGlmICghaGFuZGxlKSB7XG4gICAgICBtaXNzaW5nSGFuZGxlICs9IDE7XG4gICAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh1LnR3ZWV0X2lkKTtcbiAgICAgIGF3YWl0IGRlcXVldWVUaHJlYWRPcGVuKHUudHdlZXRfaWQpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICh0cmFja2VkLnNpemUgPiAwICYmICF0cmFja2VkLmhhcyhoYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgIHNraXBwZWQgKz0gMTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHUudHdlZXRfaWQpO1xuICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKGhhbmRsZSwgdS50d2VldF9pZCk7XG4gICAgYXdhaXQgZGVxdWV1ZVRocmVhZE9wZW4odS50d2VldF9pZCk7XG4gICAgaWYgKHJlZmV0Y2hTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdS50d2VldF9pZCkge1xuICAgICAgcmVmZXRjaFNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgICAgcmVmZXRjaFNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihyZWZldGNoU2Vzcyk7XG4gICAgfVxuICAgIGlmIChtZWRpYUNyYXdsU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHUudHdlZXRfaWQpIHtcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obWVkaWFDcmF3bFNlc3MpO1xuICAgIH1cbiAgICBpZiAodGhyZWFkT3BlblNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB1LnR3ZWV0X2lkKSB7XG4gICAgICB0aHJlYWRPcGVuU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICB0aHJlYWRPcGVuU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IG1hcmtUaHJlYWRPcGVuU2Vlbih1LnR3ZWV0X2lkKTtcbiAgICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHRocmVhZE9wZW5TZXNzKTtcbiAgICB9XG5cbiAgICBjb25zdCBzaWcgPSB1bmF2YWlsYWJsZVNpZyh1KTtcbiAgICBjb25zdCBwcmV2ID0gY29tbWl0dGVkSWR4W2hhbmRsZV0/Llt1LnR3ZWV0X2lkXTtcbiAgICBpZiAocHJldj8uc2lnID09PSBzaWcpIHtcbiAgICAgIHNraXBwZWQgKz0gMTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGNvbnN0IGJ1ZiA9IGF3YWl0IGVuc3VyZVJ1bkJ1ZmZlcihoYW5kbGUsIGNhcHR1cmVkQXQsIHNvdXJjZVVybCwgZW5kcG9pbnQpO1xuICAgIGNvbnN0IHVuYXZhaWxhYmxlQnlJZCA9IGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fTtcbiAgICB1bmF2YWlsYWJsZUJ5SWRbdS50d2VldF9pZF0gPSB1O1xuICAgIGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA9IHVuYXZhaWxhYmxlQnlJZDtcbiAgICBpZiAoIWJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQuaW5jbHVkZXModS50d2VldF9pZCkpIHtcbiAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh1LnR3ZWV0X2lkKTtcbiAgICB9XG4gICAgaWYgKCFidWYuZW5kcG9pbnRzX3NlZW4uaW5jbHVkZXMoZW5kcG9pbnQpKSBidWYuZW5kcG9pbnRzX3NlZW4ucHVzaChlbmRwb2ludCk7XG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcbiAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgcnVuQnVmZmVySXRlbUNvdW50KGJ1ZikpO1xuICAgIHJlY29yZGVkICs9IDE7XG4gIH1cblxuICBpZiAocmVjb3JkZWQgPiAwIHx8IG1pc3NpbmdIYW5kbGUgPiAwIHx8IHNraXBwZWQgPiAwKSB7XG4gICAgYXdhaXQgaW5mbygndW5hdmFpbGFibGUgdHdlZXRzIG9ic2VydmVkJywgeyBlbmRwb2ludCwgcmVjb3JkZWQsIHNraXBwZWQsIG1pc3NpbmdIYW5kbGUgfSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuZnVuY3Rpb24gdW5hdmFpbGFibGVTaWcodTogVW5hdmFpbGFibGVUd2VldCk6IHN0cmluZyB7XG4gIHJldHVybiBgdW5hdmFpbGFibGV8JHt1LnVuYXZhaWxhYmxlX3JlYXNvbiA/PyAnJ318JHt1LnVuYXZhaWxhYmxlX3RleHQgPz8gJyd9YDtcbn1cblxuZnVuY3Rpb24gc2lnTWFya3NUcnVuY2F0ZWQoc2lnOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3QgcGFydHMgPSBzaWcuc3BsaXQoJ3wnKTtcbiAgcmV0dXJuIHBhcnRzW3BhcnRzLmxlbmd0aCAtIDFdID09PSAndCc7XG59XG5cbmZ1bmN0aW9uIHJ1bkJ1ZmZlckl0ZW1Db3VudChidWY6IFJ1bkJ1ZmZlcik6IG51bWJlciB7XG4gIHJldHVybiAoXG4gICAgT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoICtcbiAgICBPYmplY3Qua2V5cyhidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge30pLmxlbmd0aCArXG4gICAgT2JqZWN0LmtleXMoYnVmLnJldHdlZXRfZWRnZXNfYnlfa2V5ID8/IHt9KS5sZW5ndGhcbiAgKTtcbn1cblxuZnVuY3Rpb24gcmV0d2VldEVkZ2VLZXkoZWRnZTogUmV0d2VldEVkZ2UpOiBzdHJpbmcge1xuICByZXR1cm4gW2VkZ2UucmV0d2VldGVyX2hhbmRsZS50b0xvd2VyQ2FzZSgpLCBlZGdlLnJldHdlZXRfdHdlZXRfaWQsIGVkZ2Uub3JpZ2luYWxfdHdlZXRfaWRdLmpvaW4oXG4gICAgJ3wnXG4gICk7XG59XG5cbmZ1bmN0aW9uIGluZmVyUmV0d2VldGVkSGFuZGxlKHRleHQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBtYXRjaCA9IHRleHQubWF0Y2goL15SVFxccytAKFtBLVphLXowLTlfXXsxLDE1fSlcXGIvaSk7XG4gIHJldHVybiBtYXRjaD8uWzFdID8/IG51bGw7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkUmV0d2VldEVkZ2VzKFxuICB0d2VldHM6IFJlYWRvbmx5QXJyYXk8Q2Fub25pY2FsVHdlZXQ+LFxuICBhY2NvdW50czogUmVhZG9ubHlBcnJheTx7IGhhbmRsZTogc3RyaW5nOyBjYXRlZ29yeTogc3RyaW5nIH0+LFxuICBjYXB0dXJlZEF0OiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHNvdXJjZVVybDogc3RyaW5nIHwgbnVsbFxuKTogUmV0d2VldEVkZ2VbXSB7XG4gIGNvbnN0IGNhdGVnb3J5QnlIYW5kbGUgPSBuZXcgTWFwKGFjY291bnRzLm1hcCgoYSkgPT4gW2EuaGFuZGxlLnRvTG93ZXJDYXNlKCksIGEuY2F0ZWdvcnldKSk7XG4gIGNvbnN0IGJ5SWQgPSBuZXcgTWFwKHR3ZWV0cy5tYXAoKHQpID0+IFt0LnR3ZWV0X2lkLCB0XSkpO1xuICBjb25zdCBvdXQgPSBuZXcgTWFwPHN0cmluZywgUmV0d2VldEVkZ2U+KCk7XG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICBpZiAodC50d2VldF90eXBlICE9PSAncmV0d2VldCcgfHwgIXQucmV0d2VldGVkX3R3ZWV0X2lkKSBjb250aW51ZTtcbiAgICBjb25zdCByZXR3ZWV0ZXJDYXRlZ29yeSA9IGNhdGVnb3J5QnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSk7XG4gICAgaWYgKCFyZXR3ZWV0ZXJDYXRlZ29yeSkgY29udGludWU7XG4gICAgY29uc3Qgb3JpZ2luYWwgPSBieUlkLmdldCh0LnJldHdlZXRlZF90d2VldF9pZCk7XG4gICAgY29uc3Qgb3JpZ2luYWxIYW5kbGUgPVxuICAgICAgb3JpZ2luYWw/LmFjY291bnRfaGFuZGxlID8/IGluZmVyUmV0d2VldGVkSGFuZGxlKHQudGV4dF9yZXNvbHZlZCB8fCB0LnRleHQpO1xuICAgIGNvbnN0IG9yaWdpbmFsQ2F0ZWdvcnkgPSBvcmlnaW5hbEhhbmRsZVxuICAgICAgPyAoY2F0ZWdvcnlCeUhhbmRsZS5nZXQob3JpZ2luYWxIYW5kbGUudG9Mb3dlckNhc2UoKSkgPz8gJ3B1YmxpYycpXG4gICAgICA6IG51bGw7XG4gICAgY29uc3QgZWRnZTogUmV0d2VldEVkZ2UgPSB7XG4gICAgICByZXR3ZWV0ZXJfaGFuZGxlOiB0LmFjY291bnRfaGFuZGxlLFxuICAgICAgcmV0d2VldGVyX2FjY291bnRfaWQ6IHQuYWNjb3VudF9pZCA/PyBudWxsLFxuICAgICAgcmV0d2VldGVyX2NhdGVnb3J5OiByZXR3ZWV0ZXJDYXRlZ29yeSxcbiAgICAgIHJldHdlZXRfdHdlZXRfaWQ6IHQudHdlZXRfaWQsXG4gICAgICByZXR3ZWV0X3VybDogdC50d2VldF91cmwsXG4gICAgICBvcmlnaW5hbF90d2VldF9pZDogdC5yZXR3ZWV0ZWRfdHdlZXRfaWQsXG4gICAgICBvcmlnaW5hbF9hdXRob3JfaGFuZGxlOiBvcmlnaW5hbEhhbmRsZSxcbiAgICAgIG9yaWdpbmFsX2F1dGhvcl9hY2NvdW50X2lkOiBvcmlnaW5hbD8uYWNjb3VudF9pZCA/PyBudWxsLFxuICAgICAgb3JpZ2luYWxfYXV0aG9yX2NhdGVnb3J5OiBvcmlnaW5hbENhdGVnb3J5LFxuICAgICAgY2FwdHVyZWRfYXQ6IGNhcHR1cmVkQXQsXG4gICAgICBjYXB0dXJlX3J1bl9pZDogJ3BlbmRpbmcnLFxuICAgICAgZW5kcG9pbnQsXG4gICAgICBzb3VyY2VfdXJsOiBzb3VyY2VVcmwsXG4gICAgfTtcbiAgICBvdXQuc2V0KHJldHdlZXRFZGdlS2V5KGVkZ2UpLCBlZGdlKTtcbiAgfVxuICByZXR1cm4gWy4uLm91dC52YWx1ZXMoKV07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGJ1ZmZlclJldHdlZXRFZGdlcyhcbiAgZWRnZXM6IFJlYWRvbmx5QXJyYXk8UmV0d2VldEVkZ2U+LFxuICBjYXB0dXJlZEF0OiBzdHJpbmcsXG4gIHNvdXJjZVVybDogc3RyaW5nLFxuICBlbmRwb2ludDogc3RyaW5nXG4pOiBQcm9taXNlPG51bWJlcj4ge1xuICBpZiAoZWRnZXMubGVuZ3RoID09PSAwKSByZXR1cm4gMDtcbiAgY29uc3QgYnlIYW5kbGUgPSBuZXcgTWFwPHN0cmluZywgUmV0d2VldEVkZ2VbXT4oKTtcbiAgZm9yIChjb25zdCBlZGdlIG9mIGVkZ2VzKSB7XG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KGVkZ2UucmV0d2VldGVyX2hhbmRsZSkgPz8gW107XG4gICAgYXJyLnB1c2goZWRnZSk7XG4gICAgYnlIYW5kbGUuc2V0KGVkZ2UucmV0d2VldGVyX2hhbmRsZSwgYXJyKTtcbiAgfVxuICBsZXQgYWRkZWQgPSAwO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGhhbmRsZUVkZ2VzXSBvZiBieUhhbmRsZSkge1xuICAgIGNvbnN0IGJ1ZiA9IGF3YWl0IGVuc3VyZVJ1bkJ1ZmZlcihoYW5kbGUsIGNhcHR1cmVkQXQsIHNvdXJjZVVybCwgZW5kcG9pbnQpO1xuICAgIGNvbnN0IGVkZ2VNYXAgPSBidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge307XG4gICAgbGV0IGFkZGVkRm9ySGFuZGxlID0gMDtcbiAgICBmb3IgKGNvbnN0IGVkZ2Ugb2YgaGFuZGxlRWRnZXMpIHtcbiAgICAgIGNvbnN0IHN0YW1wZWQ6IFJldHdlZXRFZGdlID0geyAuLi5lZGdlLCBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCB9O1xuICAgICAgY29uc3Qga2V5ID0gcmV0d2VldEVkZ2VLZXkoc3RhbXBlZCk7XG4gICAgICBpZiAoIWVkZ2VNYXBba2V5XSkgYWRkZWRGb3JIYW5kbGUgKz0gMTtcbiAgICAgIGVkZ2VNYXBba2V5XSA9IHN0YW1wZWQ7XG4gICAgICBpZiAoIWJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQuaW5jbHVkZXMoc3RhbXBlZC5yZXR3ZWV0X3R3ZWV0X2lkKSkge1xuICAgICAgICBidWYudHdlZXRfaWRzX29ic2VydmVkLnB1c2goc3RhbXBlZC5yZXR3ZWV0X3R3ZWV0X2lkKTtcbiAgICAgIH1cbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyhzdGFtcGVkLm9yaWdpbmFsX3R3ZWV0X2lkKSkge1xuICAgICAgICBidWYudHdlZXRfaWRzX29ic2VydmVkLnB1c2goc3RhbXBlZC5vcmlnaW5hbF90d2VldF9pZCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChhZGRlZEZvckhhbmRsZSA9PT0gMCkgY29udGludWU7XG4gICAgYnVmLnJldHdlZXRfZWRnZXNfYnlfa2V5ID0gZWRnZU1hcDtcbiAgICBpZiAoIWJ1Zi5lbmRwb2ludHNfc2Vlbi5pbmNsdWRlcyhlbmRwb2ludCkpIGJ1Zi5lbmRwb2ludHNfc2Vlbi5wdXNoKGVuZHBvaW50KTtcbiAgICBidWYubGFzdF9jYXB0dXJlX2F0ID0gY2FwdHVyZWRBdDtcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICAgIGF3YWl0IHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlLCBydW5CdWZmZXJJdGVtQ291bnQoYnVmKSk7XG4gICAgYWRkZWQgKz0gYWRkZWRGb3JIYW5kbGU7XG4gICAgYXdhaXQgaW5mbygnYnVmZmVyZWQgcmV0d2VldCBlZGdlcycsIHtcbiAgICAgIGhhbmRsZSxcbiAgICAgIGVuZHBvaW50LFxuICAgICAgYWRkZWQ6IGFkZGVkRm9ySGFuZGxlLFxuICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGVkZ2VNYXApLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gYWRkZWQ7XG59XG5cbi8qKlxuICogRmluZCBldmVyeSBwYXJlbnQgdHdlZXQgcmVmZXJlbmNlZCBieSB0aGUgY2FwdHVyZXMgd2UganVzdCBpbmdlc3RlZFxuICogKGByZXBseV90b190d2VldF9pZGAsIGBxdW90ZWRfdHdlZXRfaWRgLCBgcmV0d2VldGVkX3R3ZWV0X2lkYCkgdGhhdCB3ZVxuICogZG9uJ3QgeWV0IGhhdmUgaW4gdGhlIGFyY2hpdmUsIGFuZCBlbnF1ZXVlIGl0IG9uIHRoZSBtZWRpYS1jcmF3bCBsb29wLlxuICpcbiAqIFdoeTogWCdzIFVzZXJUd2VldHNBbmRSZXBsaWVzIGVuZHBvaW50IHNvbWV0aW1lcyByZXR1cm5zIGEgdHJhY2tlZFxuICogYWNjb3VudCdzIHJlcGx5ICp3aXRob3V0KiB0aGUgcGFyZW50IGl0IHBvaW50cyBhdC4gVGhlIGByZXBseV90b18qYFxuICogZmllbGRzIG9uIHRoZSByZXBseSBzdGlsbCBnZXQgc2V0IGZyb20gYGluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHJgLCBidXRcbiAqIGBmaWx0ZXJSZWxhdGVkYCBoYXMgbm90aGluZyB0byBrZWVwIFx1MjAxNCB0aGVyZSBpcyBubyBwYXJlbnQgbm9kZSBpbiB0aGVcbiAqIGJhdGNoIHRvIGtlZXAuIFJlc3VsdDogdGhlIGFyY2hpdmUgc2hvd3MgREhTZ292J3MgcmVwbHkgYnV0IG5vdCB0aGVcbiAqIG9yaWdpbmFsIGl0J3MgcmVwbHlpbmcgdG8uIFN5bW1ldHJpYyBwcm9ibGVtIGZvciBvcnBoYW5lZCBxdW90ZSAvIFJUXG4gKiBwb2ludGVycy5cbiAqXG4gKiBSZXVzaW5nIHRoZSBtZWRpYS1jcmF3bCBxdWV1ZSArIGxvb3AgbWVhbnMgbm8gbmV3IFVJOyB0aGUgdXNlciBhbHJlYWR5XG4gKiBzdGFydHMgaXQgbWFudWFsbHkgd2hlbiB0aGV5IHdhbnQgdG8gZmV0Y2ggcGFydGlhbC1jYXB0dXJlZCB0d2VldHMuXG4gKiBTYW1lIGRlZHVwIHJ1bGVzIGFwcGx5IChjb21taXR0ZWQgXHUyMTkyIHNraXA7IGFscmVhZHkgcXVldWVkIFx1MjE5MiBuby1vcCkuXG4gKlxuICogV2Ugb25seSB3YWxrIHRoZSB0d2VldHMgdGhhdCBzdXJ2aXZlZCBgZmlsdGVyUmVsYXRlZGAgc28gd2UgZG9uJ3QgY3Jhd2xcbiAqIHBhcmVudHMgb2YgcmFuZG9tIHJlcGxpZXMgdGhhdCB3b3VsZG4ndCBoYXZlIGJlZW4ga2VwdCBhbnl3YXkuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGVucXVldWVNaXNzaW5nUGFyZW50cyhcbiAgdHdlZXRzOiBSZWFkb25seUFycmF5PENhbm9uaWNhbFR3ZWV0PixcbiAgZW5kcG9pbnQ6IHN0cmluZ1xuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmICh0d2VldHMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIC8vIEJ1aWxkIGEgc2FtZS1iYXRjaCBJRCBzZXQgc28gd2UgZG9uJ3QgZW5xdWV1ZSBhIHBhcmVudCB0aGF0IGFscmVhZHlcbiAgLy8gYXJyaXZlZCBpbiB0aGlzIHZlcnkgcmVzcG9uc2UuXG4gIGNvbnN0IHNhbWVCYXRjaElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSBzYW1lQmF0Y2hJZHMuYWRkKHQudHdlZXRfaWQpO1xuXG4gIGxldCBlbnF1ZXVlZCA9IDA7XG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICBjb25zdCBwYXJlbnRzOiBBcnJheTx7IGlkOiBzdHJpbmc7IGhpbnQ6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCkge1xuICAgICAgcGFyZW50cy5wdXNoKHsgaWQ6IHQucmVwbHlfdG9fdHdlZXRfaWQsIGhpbnQ6IHQucmVwbHlfdG9fYWNjb3VudCB9KTtcbiAgICB9XG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkKSBwYXJlbnRzLnB1c2goeyBpZDogdC5xdW90ZWRfdHdlZXRfaWQsIGhpbnQ6IG51bGwgfSk7XG4gICAgaWYgKHQucmV0d2VldGVkX3R3ZWV0X2lkKSBwYXJlbnRzLnB1c2goeyBpZDogdC5yZXR3ZWV0ZWRfdHdlZXRfaWQsIGhpbnQ6IG51bGwgfSk7XG4gICAgZm9yIChjb25zdCBwIG9mIHBhcmVudHMpIHtcbiAgICAgIGlmIChzYW1lQmF0Y2hJZHMuaGFzKHAuaWQpKSBjb250aW51ZTtcbiAgICAgIGlmIChhd2FpdCBpc0NvbW1pdHRlZChwLmlkKSkgY29udGludWU7XG4gICAgICBhd2FpdCBlbnF1ZXVlTWVkaWFDcmF3bChwLmhpbnQsIHAuaWQpO1xuICAgICAgZW5xdWV1ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgaWYgKGVucXVldWVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ3F1ZXVlZCBtaXNzaW5nIHBhcmVudCB0d2VldHMgZm9yIGRldGFpbC1wYWdlIGNyYXdsJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBlbnF1ZXVlZCxcbiAgICAgIHF1ZXVlX3RvdGFsOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxuICAgIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVucXVldWVUaHJlYWRPcGVuQ2FuZGlkYXRlcyhcbiAgdHdlZXRzOiBSZWFkb25seUFycmF5PENhbm9uaWNhbFR3ZWV0PixcbiAgY29yZUhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz4sXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8dm9pZD4ge1xuICBpZiAodHdlZXRzLmxlbmd0aCA9PT0gMCB8fCBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm47XG4gIGlmIChlbmRwb2ludC5pbmNsdWRlcygnVHdlZXREZXRhaWwnKSB8fCBlbmRwb2ludC5pbmNsdWRlcygnVHdlZXRSZXN1bHRCeVJlc3RJZCcpKSByZXR1cm47XG5cbiAgY29uc3QgY2FuZGlkYXRlcyA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICBjb25zdCBoYW5kbGUgPSB0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKCFjb3JlSGFuZGxlcy5oYXMoaGFuZGxlKSkgY29udGludWU7XG5cbiAgICBjb25zdCByb290SWQgPSB0LmNvbnZlcnNhdGlvbl9pZCA/PyB0LnR3ZWV0X2lkO1xuICAgIGNvbnN0IGlzUm9vdCA9IHJvb3RJZCA9PT0gdC50d2VldF9pZCB8fCB0LnJlcGx5X3RvX3R3ZWV0X2lkID09PSBudWxsO1xuICAgIGNvbnN0IGlzQ29yZVJlcGx5ID0gdC5yZXBseV90b190d2VldF9pZCAhPT0gbnVsbDtcbiAgICBpZiAoaXNSb290ICYmIHQucmVwbHlfY291bnQgPiAwKSB7XG4gICAgICBjYW5kaWRhdGVzLnNldChyb290SWQsIHQuYWNjb3VudF9oYW5kbGUpO1xuICAgIH0gZWxzZSBpZiAoaXNDb3JlUmVwbHkgJiYgcm9vdElkKSB7XG4gICAgICBjYW5kaWRhdGVzLnNldChyb290SWQsIHQuYWNjb3VudF9oYW5kbGUpO1xuICAgIH1cbiAgfVxuXG4gIGxldCBlbnF1ZXVlZCA9IDA7XG4gIGZvciAoY29uc3QgW3R3ZWV0SWQsIGhhbmRsZV0gb2YgY2FuZGlkYXRlcykge1xuICAgIGNvbnN0IGJlZm9yZSA9IGF3YWl0IHRocmVhZE9wZW5RdWV1ZVRvdGFsKCk7XG4gICAgYXdhaXQgZW5xdWV1ZVRocmVhZE9wZW4oaGFuZGxlLCB0d2VldElkKTtcbiAgICBjb25zdCBhZnRlciA9IGF3YWl0IHRocmVhZE9wZW5RdWV1ZVRvdGFsKCk7XG4gICAgaWYgKGFmdGVyID4gYmVmb3JlKSBlbnF1ZXVlZCArPSAxO1xuICB9XG4gIGlmIChlbnF1ZXVlZCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdxdWV1ZWQgY29yZSB0aHJlYWQgcm9vdHMgZm9yIG9wZW5pbmcnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIGVucXVldWVkLFxuICAgICAgcXVldWVfdG90YWw6IGF3YWl0IHRocmVhZE9wZW5RdWV1ZVRvdGFsKCksXG4gICAgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlUnVuQnVmZmVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgdHM6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8UnVuQnVmZmVyPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpO1xuICBpZiAoY3VyKSByZXR1cm4gY3VyO1xuICBjb25zdCBidWY6IFJ1bkJ1ZmZlciA9IHtcbiAgICBydW5faWQ6IG5ld1J1bklkKCksXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBzdGFydGVkX2F0OiB0cyxcbiAgICBsYXN0X2NhcHR1cmVfYXQ6IHRzLFxuICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgdW5hdmFpbGFibGVfYnlfaWQ6IHt9LFxuICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogW10sXG4gICAgZW5kcG9pbnRzX3NlZW46IFtlbmRwb2ludF0sXG4gICAgc291cmNlX3VybDogc291cmNlVXJsLFxuICB9O1xuICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICBhd2FpdCBpbmZvKCdydW4gc3RhcnRlZCcsIHsgaGFuZGxlLCBydW46IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCkgfSk7XG4gIHJldHVybiBidWY7XG59XG5cbi8vIC0tLSBGbHVzaCBsb2dpYyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmxldCBmbHVzaENoYWluOiBQcm9taXNlPHZvaWQ+ID0gUHJvbWlzZS5yZXNvbHZlKCk7XG5cbmludGVyZmFjZSBGbHVzaEl0ZW0ge1xuICBoYW5kbGU6IHN0cmluZztcbiAgYnVmOiBSdW5CdWZmZXI7XG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXTtcbiAgcmV0d2VldEVkZ2VzOiBSZXR3ZWV0RWRnZVtdO1xuICByYXdQYXRoOiBzdHJpbmc7XG4gIHNlZW5QYXRoOiBzdHJpbmc7XG4gIGNhcHR1cmU6IENhcHR1cmVQYXlsb2FkO1xuICBzZWVuOiBTZWVuUGF5bG9hZDtcbiAgZGF5OiBzdHJpbmc7XG4gIHJ1blNob3J0OiBzdHJpbmc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSWRsZUJ1ZmZlcnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgY29uc3QgaGFuZGxlczogc3RyaW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xuICAgICAgaGFuZGxlcy5wdXNoKGhhbmRsZSk7XG4gICAgfVxuICB9XG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhoYW5kbGVzLCAnaWRsZScpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIE9uIHdvcmtlciB3YWtlLCBhbnkgYnVmZmVyIG9sZGVyIHRoYW4gdGhlIGlkbGUgdGhyZXNob2xkIGdldHMgYSBjaGFuY2UgdG9cbiAgLy8gY29tbWl0IGltbWVkaWF0ZWx5IFx1MjAxNCB1c2VmdWwgd2hlbiB0aGUgd29ya2VyIHdhcyBldmljdGVkIGJlZm9yZSBpZGxlLWZsdXNoLlxuICAvLyBJZiB0aGUgUEFUL293bmVyL3JlcG8gYXJlbid0IHNldCB3ZSdkIGp1c3QgZW1pdCBcImZsdXNoIGRlZmVycmVkXCIgZm9yIGV2ZXJ5XG4gIC8vIHNpbmdsZSBoYW5kbGUgaW4gc3RvcmFnZSAodGhlIGRpYWdub3N0aWMgc2hvd2VkIHRoaXMgZmlyaW5nIDMwMCsgdGltZXMgaW5cbiAgLy8gYSByb3cgd2hlbiB0aGUgZXh0ZW5zaW9uIHdva2UgYmVmb3JlIHNldHRpbmdzIGxvYWQpLCBzbyBzaG9ydC1jaXJjdWl0XG4gIC8vIGhlcmUgaW5zdGVhZC5cbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBjb25zdCBoYW5kbGVzOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XG4gICAgICBoYW5kbGVzLnB1c2goaGFuZGxlKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgZmx1c2hIYW5kbGVzKGhhbmRsZXMsICd3YWtlJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoQWxsKHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKE9iamVjdC5rZXlzKGFsbCksIHJlYXNvbik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlKGhhbmRsZTogc3RyaW5nLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBmbHVzaEhhbmRsZXMoW2hhbmRsZV0sIHJlYXNvbik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlcyhoYW5kbGVzOiBzdHJpbmdbXSwgcmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdW5pcXVlID0gWy4uLm5ldyBTZXQoaGFuZGxlcyldLmZpbHRlcigoaCkgPT4gaC5sZW5ndGggPiAwKTtcbiAgaWYgKHVuaXF1ZS5sZW5ndGggPT09IDApIHJldHVybjtcbiAgY29uc3QgcnVuID0gZmx1c2hDaGFpbi50aGVuKCgpID0+IGZsdXNoSGFuZGxlc0xvY2tlZCh1bmlxdWUsIHJlYXNvbikpO1xuICBmbHVzaENoYWluID0gcnVuLmNhdGNoKCgpID0+IHt9KTtcbiAgcmV0dXJuIHJ1bjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGVzTG9ja2VkKGhhbmRsZXM6IHN0cmluZ1tdLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGNvbnN0IGl0ZW1zOiBGbHVzaEl0ZW1bXSA9IFtdO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBoYW5kbGVzKSB7XG4gICAgY29uc3QgYnVmID0gYWxsW2hhbmRsZV07XG4gICAgaWYgKCFidWYpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHR3ZWV0cyA9IE9iamVjdC52YWx1ZXMoYnVmLnR3ZWV0c19ieV9pZCk7XG4gICAgY29uc3QgdW5hdmFpbGFibGVUd2VldHMgPSBPYmplY3QudmFsdWVzKGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fSk7XG4gICAgY29uc3QgcmV0d2VldEVkZ2VzID0gT2JqZWN0LnZhbHVlcyhidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge30pO1xuICAgIGlmICh0d2VldHMubGVuZ3RoID09PSAwICYmIHVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCA9PT0gMCAmJiByZXR3ZWV0RWRnZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihoYW5kbGUpO1xuICAgICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIDApO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGl0ZW1zLnB1c2goYnVpbGRGbHVzaEl0ZW0oaGFuZGxlLCBidWYsIHR3ZWV0cywgdW5hdmFpbGFibGVUd2VldHMsIHJldHdlZXRFZGdlcykpO1xuICB9XG4gIGlmIChpdGVtcy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHdhcm4oJ3VwbG9hZCBidWZmZXIgZGVmZXJyZWQ6IHNldHRpbmdzIGluY29tcGxldGUnLCB7XG4gICAgICBjb3VudDogaXRlbXMubGVuZ3RoLFxuICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgY29uc3QgZmlsZXMgPSBpdGVtcy5mbGF0TWFwKChpdGVtKSA9PiBbXG4gICAge1xuICAgICAgcGF0aDogaXRlbS5yYXdQYXRoLFxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkoaXRlbS5jYXB0dXJlLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICB9LFxuICAgIHtcbiAgICAgIHBhdGg6IGl0ZW0uc2VlblBhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShpdGVtLnNlZW4sIG51bGwsIDIpICsgJ1xcbicpLFxuICAgIH0sXG4gIF0pO1xuICBjb25zdCBjb21taXRNc2cgPSBidWlsZEJhdGNoQ29tbWl0TWVzc2FnZShpdGVtcyk7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQuY29tbWl0RmlsZXMoe1xuICAgICAgZmlsZXMsXG4gICAgICBtZXNzYWdlOiBjb21taXRNc2csXG4gICAgfSk7XG4gICAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgaXRlbXMpIHtcbiAgICAgIGNvbnN0IHJlbWFpbmluZ0NvdW50ID0gYXdhaXQgY2xlYXJDb21taXR0ZWRUd2VldHNGcm9tQnVmZmVyKGl0ZW0pO1xuICAgICAgLy8gQ291bnRlciBidW1wOiBhY3R1YWxseSBJTkNSRU1FTlQgdG9kYXlDb3VudCBhbmQgdG90YWxDb21taXR0ZWQgYnlcbiAgICAgIC8vIHRoZSBudW1iZXIgb2YgdHdlZXRzIHdlIGp1c3QgcGVyc2lzdGVkICh0aGUgcHJldmlvdXMgY29kZSByZWFkIHRoZVxuICAgICAgLy8gZXhpc3RpbmcgdmFsdWVzIGFuZCB3cm90ZSB0aGVtIGJhY2ssIGxlYXZpbmcgdGhlIGNvdW50ZXIgcGVnZ2VkIGF0XG4gICAgICAvLyB6ZXJvKS5cbiAgICAgIGNvbnN0IHByZXYgPSAoYXdhaXQgZ2V0Q291bnRlcnMoKSlbaXRlbS5oYW5kbGVdO1xuICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuICAgICAgY29uc3QgY2FycmllZFRvZGF5ID0gcHJldiAmJiBwcmV2LnRvZGF5RGF0ZSA9PT0gdG9kYXkgPyBwcmV2LnRvZGF5Q291bnQgOiAwO1xuICAgICAgYXdhaXQgYnVtcENvdW50ZXIoaXRlbS5oYW5kbGUsIHtcbiAgICAgICAgdG9kYXlDb3VudDogY2FycmllZFRvZGF5ICsgaXRlbS50d2VldHMubGVuZ3RoICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIHRvZGF5RGF0ZTogdG9kYXksXG4gICAgICAgIGxhc3RDYXB0dXJlQXQ6IGl0ZW0uYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgICAgdG90YWxDb21taXR0ZWQ6XG4gICAgICAgICAgKHByZXY/LnRvdGFsQ29tbWl0dGVkID8/IDApICsgaXRlbS50d2VldHMubGVuZ3RoICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIGJ1ZmZlcmVkQ291bnQ6IHJlbWFpbmluZ0NvdW50LFxuICAgICAgfSk7XG4gICAgICAvLyBSZWNvcmQgY29tbWl0cyBpbiB0aGUgZGVkdXAgaW5kZXggc28gd2UgZG9uJ3QgcmUtY29tbWl0IHRoZW0gbmV4dFxuICAgICAgLy8gYnJvd3NlIHdpdGggdW5jaGFuZ2VkIGVuZ2FnZW1lbnQuXG4gICAgICBjb25zdCBpbm5lciA9IGlkeFtpdGVtLmhhbmRsZV0gPz8ge307XG4gICAgICBjb25zdCBub3dJc28gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgICBmb3IgKGNvbnN0IHQgb2YgaXRlbS50d2VldHMpIHtcbiAgICAgICAgaW5uZXJbdC50d2VldF9pZF0gPSB7XG4gICAgICAgICAgdHM6IG5vd0lzbyxcbiAgICAgICAgICBzaWc6IGVuZ2FnZW1lbnRTaWcoXG4gICAgICAgICAgICB0Lmxpa2VfY291bnQsXG4gICAgICAgICAgICB0LnJldHdlZXRfY291bnQsXG4gICAgICAgICAgICB0LnJlcGx5X2NvdW50LFxuICAgICAgICAgICAgdC5xdW90ZV9jb3VudCxcbiAgICAgICAgICAgIHQuaXNfdHJ1bmNhdGVkXG4gICAgICAgICAgKSxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgdSBvZiBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzKSB7XG4gICAgICAgIGlubmVyW3UudHdlZXRfaWRdID0ge1xuICAgICAgICAgIHRzOiBub3dJc28sXG4gICAgICAgICAgc2lnOiB1bmF2YWlsYWJsZVNpZyh1KSxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGlkeFtpdGVtLmhhbmRsZV0gPSBpbm5lcjtcbiAgICAgIGF3YWl0IGluZm8oJ3VwbG9hZCBidWZmZXIgY29tbWl0dGVkJywge1xuICAgICAgICBoYW5kbGU6IGl0ZW0uaGFuZGxlLFxuICAgICAgICByZWFzb24sXG4gICAgICAgIHR3ZWV0czogaXRlbS50d2VldHMubGVuZ3RoLFxuICAgICAgICB1bmF2YWlsYWJsZTogaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIHJldHdlZXRfZWRnZXM6IGl0ZW0ucmV0d2VldEVkZ2VzLmxlbmd0aCxcbiAgICAgICAgcnVuOiBpdGVtLnJ1blNob3J0LFxuICAgICAgICBwYXRoOiBpdGVtLnJhd1BhdGgsXG4gICAgICAgIGJhdGNoX2NvbW1pdDogcmVzdWx0LmNvbW1pdFNoYSxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xuICAgIGF3YWl0IGluZm8oJ3VwbG9hZCBidWZmZXIgYmF0Y2ggY29tbWl0dGVkJywge1xuICAgICAgcmVhc29uLFxuICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcbiAgICAgIHR3ZWV0czogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApLFxuICAgICAgdW5hdmFpbGFibGU6IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsIDApLFxuICAgICAgcmV0d2VldF9lZGdlczogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnJldHdlZXRFZGdlcy5sZW5ndGgsIDApLFxuICAgICAgY29tbWl0OiByZXN1bHQuY29tbWl0U2hhLFxuICAgIH0pO1xuICAgIHtcbiAgICAgIGNvbnN0IHByZXYgPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzOiAnb2snLFxuICAgICAgICBsb2dpbjogcHJldi5sb2dpbixcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBwcmV2LmRlZmF1bHRCcmFuY2gsXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IHByZXYuY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSB7XG4gICAgICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICAgICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAnYXV0aCdcbiAgICAgICAgICA/ICdhdXRoLWVycm9yJ1xuICAgICAgICAgIDogZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICAgID8gJ3JhdGUtbGltaXRlZCdcbiAgICAgICAgICAgIDogZXJyLmNhdGVnb3J5ID09PSAnbmV0d29yaydcbiAgICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgICAgOiBjb25uLnN0YXR1cztcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXMsXG4gICAgICAgIGxvZ2luOiBjb25uLmxvZ2luLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IGVyci5tZXNzYWdlLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBjb25uLmRlZmF1bHRCcmFuY2gsXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGNvbm4uY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDpcbiAgICAgICAgICBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IGVyci5yYXRlTGltaXRSZXNldEF0IDogY29ubi5yYXRlTGltaXRSZXNldEF0LFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBsb2dFcnIoJ3VwbG9hZCBidWZmZXIgZmFpbGVkJywge1xuICAgICAgICByZWFzb24sXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcbiAgICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgICBjYXRlZ29yeTogZXJyLmNhdGVnb3J5LFxuICAgICAgICBzdGF0dXM6IGVyci5zdGF0dXMsXG4gICAgICAgIG1lc3NhZ2U6IGVyci5tZXNzYWdlLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBlcnIucmF0ZUxpbWl0UmVzZXRBdCxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBsb2dFcnIoJ3VwbG9hZCBidWZmZXIgZmFpbGVkJywge1xuICAgICAgICByZWFzb24sXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcbiAgICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgICB9KTtcbiAgICB9XG4gICAgLy8gTGVhdmUgYnVmZmVyIGludGFjdCBmb3IgcmV0cnkuXG4gIH0gZmluYWxseSB7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBidWlsZEZsdXNoSXRlbShcbiAgaGFuZGxlOiBzdHJpbmcsXG4gIGJ1ZjogUnVuQnVmZmVyLFxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10sXG4gIHVuYXZhaWxhYmxlVHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W10sXG4gIHJldHdlZXRFZGdlczogUmV0d2VldEVkZ2VbXVxuKTogRmx1c2hJdGVtIHtcbiAgY29uc3QgdHMgPSBpc29Db21wYWN0KGJ1Zi5zdGFydGVkX2F0KTtcbiAgY29uc3QgZGF5ID0gYnVmLnN0YXJ0ZWRfYXQuc2xpY2UoMCwgMTApO1xuICBjb25zdCBydW5TaG9ydCA9IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCk7XG4gIGNvbnN0IHJhd1BhdGggPSBgcmF3LyR7aGFuZGxlfS8ke3RzfS0ke3J1blNob3J0fS5qc29uYDtcbiAgY29uc3Qgc2VlblBhdGggPSBgc2Vlbi8ke2hhbmRsZX0vJHt0c30tJHtydW5TaG9ydH0uanNvbmA7XG4gIHJldHVybiB7XG4gICAgaGFuZGxlLFxuICAgIGJ1ZixcbiAgICB0d2VldHMsXG4gICAgdW5hdmFpbGFibGVUd2VldHMsXG4gICAgcmV0d2VldEVkZ2VzLFxuICAgIHJhd1BhdGgsXG4gICAgc2VlblBhdGgsXG4gICAgZGF5LFxuICAgIHJ1blNob3J0LFxuICAgIGNhcHR1cmU6IHtcbiAgICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICBlbmRwb2ludDogYnVmLmVuZHBvaW50c19zZWVuLmpvaW4oJywnKSxcbiAgICAgIHVzZXJfYWdlbnQ6IG5hdmlnYXRvci51c2VyQWdlbnQsXG4gICAgICBzb3VyY2VfdXJsOiBidWYuc291cmNlX3VybCxcbiAgICAgIHR3ZWV0cyxcbiAgICAgIHVuYXZhaWxhYmxlX3R3ZWV0czogdW5hdmFpbGFibGVUd2VldHMsXG4gICAgICByZXR3ZWV0X2VkZ2VzOiByZXR3ZWV0RWRnZXMsXG4gICAgfSxcbiAgICBzZWVuOiB7XG4gICAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICAgIGNhcHR1cmVkX2F0OiBidWYubGFzdF9jYXB0dXJlX2F0LFxuICAgICAgdHdlZXRfaWRzX29ic2VydmVkOiBidWYudHdlZXRfaWRzX29ic2VydmVkLFxuICAgIH0sXG4gIH07XG59XG5cbmZ1bmN0aW9uIGJ1aWxkQmF0Y2hDb21taXRNZXNzYWdlKGl0ZW1zOiBGbHVzaEl0ZW1bXSk6IHN0cmluZyB7XG4gIGlmIChpdGVtcy5sZW5ndGggPT09IDEpIHtcbiAgICBjb25zdCBpdGVtID0gaXRlbXNbMF0hO1xuICAgIGNvbnN0IHVuYXZhaWxhYmxlQ291bnQgPSBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aDtcbiAgICBjb25zdCBlZGdlQ291bnQgPSBpdGVtLnJldHdlZXRFZGdlcy5sZW5ndGg7XG4gICAgY29uc3Qgc3VmZml4ID1cbiAgICAgICh1bmF2YWlsYWJsZUNvdW50ID4gMCA/IGAsICR7dW5hdmFpbGFibGVDb3VudH0gdW5hdmFpbGFibGVgIDogJycpICtcbiAgICAgIChlZGdlQ291bnQgPiAwID8gYCwgJHtlZGdlQ291bnR9IHJldHdlZXQgZWRnZSR7ZWRnZUNvdW50ID09PSAxID8gJycgOiAncyd9YCA6ICcnKTtcbiAgICByZXR1cm4gYGNhcHR1cmU6ICR7aXRlbS5oYW5kbGV9ICR7aXRlbS5kYXl9ICR7aXRlbS50d2VldHMubGVuZ3RofSB0d2VldCR7aXRlbS50d2VldHMubGVuZ3RoID09PSAxID8gJycgOiAncyd9JHtzdWZmaXh9IChydW4gJHtpdGVtLnJ1blNob3J0fSlgO1xuICB9XG4gIGNvbnN0IGRheXMgPSBbLi4ubmV3IFNldChpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uZGF5KSldLnNvcnQoKTtcbiAgY29uc3QgZGF5TGFiZWwgPSBkYXlzLmxlbmd0aCA9PT0gMSA/IGRheXNbMF0hIDogYCR7ZGF5c1swXX0uLiR7ZGF5c1tkYXlzLmxlbmd0aCAtIDFdfWA7XG4gIGNvbnN0IHR3ZWV0Q291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udHdlZXRzLmxlbmd0aCwgMCk7XG4gIGNvbnN0IHVuYXZhaWxhYmxlQ291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udW5hdmFpbGFibGVUd2VldHMubGVuZ3RoLCAwKTtcbiAgY29uc3QgZWRnZUNvdW50ID0gaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnJldHdlZXRFZGdlcy5sZW5ndGgsIDApO1xuICBjb25zdCBzdWZmaXggPVxuICAgICh1bmF2YWlsYWJsZUNvdW50ID4gMCA/IGAsICR7dW5hdmFpbGFibGVDb3VudH0gdW5hdmFpbGFibGVgIDogJycpICtcbiAgICAoZWRnZUNvdW50ID4gMCA/IGAsICR7ZWRnZUNvdW50fSByZXR3ZWV0IGVkZ2Uke2VkZ2VDb3VudCA9PT0gMSA/ICcnIDogJ3MnfWAgOiAnJyk7XG4gIHJldHVybiBgY2FwdHVyZSBiYXRjaDogJHtpdGVtcy5sZW5ndGh9IHJ1bnMsICR7dHdlZXRDb3VudH0gdHdlZXQke3R3ZWV0Q291bnQgPT09IDEgPyAnJyA6ICdzJ30ke3N1ZmZpeH0gKCR7ZGF5TGFiZWx9KWA7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNsZWFyQ29tbWl0dGVkVHdlZXRzRnJvbUJ1ZmZlcihpdGVtOiBGbHVzaEl0ZW0pOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBjdXJyZW50ID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcbiAgaWYgKCFjdXJyZW50KSByZXR1cm4gMDtcbiAgaWYgKGN1cnJlbnQucnVuX2lkICE9PSBpdGVtLmJ1Zi5ydW5faWQpIHJldHVybiBydW5CdWZmZXJJdGVtQ291bnQoY3VycmVudCk7XG5cbiAgY29uc3QgY29tbWl0dGVkID0gbmV3IE1hcChcbiAgICBpdGVtLnR3ZWV0cy5tYXAoKHQpID0+IFtcbiAgICAgIHQudHdlZXRfaWQsXG4gICAgICBlbmdhZ2VtZW50U2lnKHQubGlrZV9jb3VudCwgdC5yZXR3ZWV0X2NvdW50LCB0LnJlcGx5X2NvdW50LCB0LnF1b3RlX2NvdW50LCB0LmlzX3RydW5jYXRlZCksXG4gICAgXSlcbiAgKTtcbiAgZm9yIChjb25zdCB1IG9mIGl0ZW0udW5hdmFpbGFibGVUd2VldHMpIHtcbiAgICBjb21taXR0ZWQuc2V0KHUudHdlZXRfaWQsIHVuYXZhaWxhYmxlU2lnKHUpKTtcbiAgfVxuICBjb25zdCByZW1haW5pbmdUd2VldHM6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PiA9IHt9O1xuICBmb3IgKGNvbnN0IFt0d2VldElkLCB0d2VldF0gb2YgT2JqZWN0LmVudHJpZXMoY3VycmVudC50d2VldHNfYnlfaWQpKSB7XG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcbiAgICBjb25zdCBjdXJyZW50U2lnID0gZW5nYWdlbWVudFNpZyhcbiAgICAgIHR3ZWV0Lmxpa2VfY291bnQsXG4gICAgICB0d2VldC5yZXR3ZWV0X2NvdW50LFxuICAgICAgdHdlZXQucmVwbHlfY291bnQsXG4gICAgICB0d2VldC5xdW90ZV9jb3VudCxcbiAgICAgIHR3ZWV0LmlzX3RydW5jYXRlZFxuICAgICk7XG4gICAgaWYgKCFjb21taXR0ZWRTaWcgfHwgY29tbWl0dGVkU2lnICE9PSBjdXJyZW50U2lnKSB7XG4gICAgICByZW1haW5pbmdUd2VldHNbdHdlZXRJZF0gPSB7IC4uLnR3ZWV0IH07XG4gICAgfVxuICB9XG4gIGNvbnN0IHJlbWFpbmluZ1VuYXZhaWxhYmxlOiBSZWNvcmQ8c3RyaW5nLCBVbmF2YWlsYWJsZVR3ZWV0PiA9IHt9O1xuICBmb3IgKGNvbnN0IFt0d2VldElkLCB1bmF2YWlsYWJsZV0gb2YgT2JqZWN0LmVudHJpZXMoY3VycmVudC51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fSkpIHtcbiAgICBjb25zdCBjb21taXR0ZWRTaWcgPSBjb21taXR0ZWQuZ2V0KHR3ZWV0SWQpO1xuICAgIGNvbnN0IGN1cnJlbnRTaWcgPSB1bmF2YWlsYWJsZVNpZyh1bmF2YWlsYWJsZSk7XG4gICAgaWYgKCFjb21taXR0ZWRTaWcgfHwgY29tbWl0dGVkU2lnICE9PSBjdXJyZW50U2lnKSB7XG4gICAgICByZW1haW5pbmdVbmF2YWlsYWJsZVt0d2VldElkXSA9IHsgLi4udW5hdmFpbGFibGUgfTtcbiAgICB9XG4gIH1cbiAgY29uc3QgcmVtYWluaW5nUmV0d2VldEVkZ2VzOiBSZWNvcmQ8c3RyaW5nLCBSZXR3ZWV0RWRnZT4gPSB7fTtcbiAgZm9yIChjb25zdCBba2V5LCBlZGdlXSBvZiBPYmplY3QuZW50cmllcyhjdXJyZW50LnJldHdlZXRfZWRnZXNfYnlfa2V5ID8/IHt9KSkge1xuICAgIGlmICghaXRlbS5yZXR3ZWV0RWRnZXMuc29tZSgoY29tbWl0dGVkRWRnZSkgPT4gcmV0d2VldEVkZ2VLZXkoY29tbWl0dGVkRWRnZSkgPT09IGtleSkpIHtcbiAgICAgIHJlbWFpbmluZ1JldHdlZXRFZGdlc1trZXldID0geyAuLi5lZGdlIH07XG4gICAgfVxuICB9XG5cbiAgY29uc3QgcmVtYWluaW5nSWRzID0gbmV3IFNldChbXG4gICAgLi4uT2JqZWN0LmtleXMocmVtYWluaW5nVHdlZXRzKSxcbiAgICAuLi5PYmplY3Qua2V5cyhyZW1haW5pbmdVbmF2YWlsYWJsZSksXG4gICAgLi4uT2JqZWN0LnZhbHVlcyhyZW1haW5pbmdSZXR3ZWV0RWRnZXMpLmZsYXRNYXAoKGVkZ2UpID0+IFtcbiAgICAgIGVkZ2UucmV0d2VldF90d2VldF9pZCxcbiAgICAgIGVkZ2Uub3JpZ2luYWxfdHdlZXRfaWQsXG4gICAgXSksXG4gIF0pO1xuICBjb25zdCByZW1haW5pbmdDb3VudCA9XG4gICAgT2JqZWN0LmtleXMocmVtYWluaW5nVHdlZXRzKS5sZW5ndGggK1xuICAgIE9iamVjdC5rZXlzKHJlbWFpbmluZ1VuYXZhaWxhYmxlKS5sZW5ndGggK1xuICAgIE9iamVjdC5rZXlzKHJlbWFpbmluZ1JldHdlZXRFZGdlcykubGVuZ3RoO1xuICBpZiAocmVtYWluaW5nQ291bnQgPT09IDApIHtcbiAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSk7XG4gICAgcmV0dXJuIDA7XG4gIH1cblxuICBjb25zdCBuZXh0UnVuSWQgPSBuZXdSdW5JZCgpO1xuICBmb3IgKGNvbnN0IHR3ZWV0IG9mIE9iamVjdC52YWx1ZXMocmVtYWluaW5nVHdlZXRzKSkge1xuICAgIHR3ZWV0LmNhcHR1cmVfcnVuX2lkID0gbmV4dFJ1bklkO1xuICB9XG4gIGZvciAoY29uc3QgZWRnZSBvZiBPYmplY3QudmFsdWVzKHJlbWFpbmluZ1JldHdlZXRFZGdlcykpIHtcbiAgICBlZGdlLmNhcHR1cmVfcnVuX2lkID0gbmV4dFJ1bklkO1xuICB9XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSwge1xuICAgIC4uLmN1cnJlbnQsXG4gICAgcnVuX2lkOiBuZXh0UnVuSWQsXG4gICAgc3RhcnRlZF9hdDogY3VycmVudC5sYXN0X2NhcHR1cmVfYXQsXG4gICAgdHdlZXRzX2J5X2lkOiByZW1haW5pbmdUd2VldHMsXG4gICAgdW5hdmFpbGFibGVfYnlfaWQ6IHJlbWFpbmluZ1VuYXZhaWxhYmxlLFxuICAgIHJldHdlZXRfZWRnZXNfYnlfa2V5OiByZW1haW5pbmdSZXR3ZWV0RWRnZXMsXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBjdXJyZW50LnR3ZWV0X2lkc19vYnNlcnZlZC5maWx0ZXIoKGlkKSA9PiByZW1haW5pbmdJZHMuaGFzKGlkKSksXG4gIH0pO1xuICBhd2FpdCBpbmZvKCd1cGxvYWQgYnVmZmVyIGtlcHQgbmV3ZXIgdHdlZXRzJywge1xuICAgIGhhbmRsZTogaXRlbS5oYW5kbGUsXG4gICAgY29tbWl0dGVkX3J1bjogaXRlbS5ydW5TaG9ydCxcbiAgICBuZXh0X3J1bjogc2hvcnRSdW5JZChuZXh0UnVuSWQpLFxuICAgIHJlbWFpbmluZzogcmVtYWluaW5nQ291bnQsXG4gIH0pO1xuICByZXR1cm4gcmVtYWluaW5nQ291bnQ7XG59XG5cbi8vIC0tLSBDYXB0dXJlLW5vdyAvIGNhcHR1cmUtYWxsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gY2FwdHVyZU5vdyhoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcbiAgLy8gTGFuZCBvbiB0aGUgUmVwbGllcyB0YWIgc28gWCBmZXRjaGVzIHZpYSBVc2VyVHdlZXRzQW5kUmVwbGllcyBcdTIwMTQgdGhhdFxuICAvLyBlbmRwb2ludCByZXR1cm5zIGJvdGggdG9wLWxldmVsIHBvc3RzIGFuZCByZXBsaWVzLCB3aGljaCBpcyB0aGUgc3VwZXJzZXRcbiAgLy8gd2Ugd2FudCBmb3IgdGhlIGFyY2hpdmUuIFRoZSBwbGFpbiBgLzxoYW5kbGU+YCBVUkwgaGl0cyBVc2VyVHdlZXRzLFxuICAvLyB3aGljaCBvbWl0cyByZXBsaWVzLiBUaGUgcGFnZS1ob29rIGludGVyY2VwdHMgZWl0aGVyIGVuZHBvaW50LCBidXRcbiAgLy8gZm9yY2luZyB0aGUgYnJvYWRlciB0YWIgb24gdXNlci1pbml0aWF0ZWQgY2FwdHVyZXMgaXMgdGhlIHJpZ2h0IGRlZmF1bHQuXG4gIGNvbnN0IHRhcmdldFVybCA9IGBodHRwczovL3guY29tLyR7aGFuZGxlfS93aXRoX3JlcGxpZXNgO1xuICBhd2FpdCBpbmZvKCdjYXB0dXJlLW5vdyByZXF1ZXN0ZWQnLCB7IGhhbmRsZSwgdGFiOiAnd2l0aF9yZXBsaWVzJyB9KTtcbiAgaWYgKCEoYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSkpKSB7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIHtcbiAgICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBzdGFydGVkX2F0OiBub3csXG4gICAgICBsYXN0X2NhcHR1cmVfYXQ6IG5vdyxcbiAgICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgICB1bmF2YWlsYWJsZV9ieV9pZDoge30sXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IFtdLFxuICAgICAgZW5kcG9pbnRzX3NlZW46IFtdLFxuICAgICAgc291cmNlX3VybDogdGFyZ2V0VXJsLFxuICAgIH0pO1xuICB9XG4gIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmw6IHRhcmdldFVybCwgYWN0aXZlOiB0cnVlIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtYWxsIHJlcXVlc3RlZCcsIHsgY291bnQ6IGFjY291bnRzLmxlbmd0aCB9KTtcbiAgZm9yIChjb25zdCBhIG9mIGFjY291bnRzKSB7XG4gICAgYXdhaXQgY2FwdHVyZU5vdyhhLmhhbmRsZSk7XG4gIH1cbn1cblxuLyoqXG4gKiBDYXB0dXJlIHdoYXRldmVyIHRoZSB1c2VyIGlzIGN1cnJlbnRseSBsb29raW5nIGF0OiBlbnN1cmVzIHBhZ2UtaG9vayBpc1xuICogcGF0Y2hlZCBpbnRvIHRoZSBhY3RpdmUgdGFiLCB0aGVuIG51ZGdlcyB0aGUgcGFnZSB3aXRoIGEgcHJvZ3JhbW1hdGljXG4gKiBzY3JvbGwgc28gWCBmaXJlcyBhbm90aGVyIGJhdGNoIG9mIEdyYXBoUUwgcmVxdWVzdHMgd2UgY2FuIGludGVyY2VwdC5cbiAqXG4gKiBMZXNzIGRpc3J1cHRpdmUgdGhhbiBgQ2FwdHVyZSBub3dgIChubyBuZXcgdGFiLCBubyBuYXZpZ2F0aW9uKSBhbmQgd29ya3NcbiAqIGZvciBhcmJpdHJhcnkgWCBVUkxzIChzcGVjaWZpYyB0d2VldCB0aHJlYWRzLCBzZWFyY2ggcmVzdWx0cywgbGlzdHMpXG4gKiB0aGF0IGRvbid0IG1hcCBjbGVhbmx5IHRvIG9uZSBvZiB0aGUgY29uZmlndXJlZCBoYW5kbGVzLlxuICovXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlVGhpc1BhZ2UoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGFsbG93TWFudWFsQ2FwdHVyZVdpbmRvdygpO1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyBhY3RpdmU6IHRydWUsIGN1cnJlbnRXaW5kb3c6IHRydWUgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBjb3VsZCBub3QgcXVlcnkgYWN0aXZlIHRhYicsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHRhYiA9IHRhYnNbMF07XG4gIGlmICghdGFiIHx8IHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInIHx8ICF0YWIudXJsKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IG5vIGFjdGl2ZSB0YWInKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKCEvXmh0dHBzOlxcL1xcLyh4fHR3aXR0ZXIpXFwuY29tXFwvLy50ZXN0KHRhYi51cmwpKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGFjdGl2ZSB0YWIgaXMgbm90IG9uIHguY29tIC8gdHdpdHRlci5jb20nLCB7XG4gICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCksXG4gICAgfSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtdGhpcy1wYWdlIHJlcXVlc3RlZCcsIHsgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwpIH0pO1xuICAvLyAoUmUtKWluamVjdCB0aGUgcGFnZS1ob29rICsgaXNvbGF0ZWQgY29udGVudCBzY3JpcHQgc28gZmV0Y2gvWEhSIGFyZVxuICAvLyBwYXRjaGVkIGV2ZW4gb24gdGFicyBvcGVuZWQgYmVmb3JlIHRoZSBleHRlbnNpb24gcmVsb2FkZWQuXG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgZmlsZXM6IFsncGFnZS1ob29rLmpzJ10sXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXG4gICAgfSk7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgZmlsZXM6IFsnY29udGVudC5qcyddLFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogcmUtaW5qZWN0IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbiAgLy8gTnVkZ2UgWCB0byBmaXJlIG1vcmUgR3JhcGhRTCByZXF1ZXN0cyBieSBzY3JvbGxpbmcuIE1vc3QgdGltZWxpbmUgL1xuICAvLyBjb252ZXJzYXRpb24gdmlld3MgZmV0Y2ggb24gaW50ZXJzZWN0aW9uLW9ic2VydmVyIHRyaWdnZXJzLlxuICB0cnkge1xuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgIGZ1bmM6ICgpID0+IHtcbiAgICAgICAgY29uc3QgaCA9IHdpbmRvdy5pbm5lckhlaWdodDtcbiAgICAgICAgd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSksIDYwMCk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSksIDEyMDApO1xuICAgICAgfSxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IHNjcm9sbC1udWRnZSBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG59XG5cbi8vIC0tLSBSZWZldGNoIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vL1xuLy8gWCB0cnVuY2F0ZXMgbG9uZyB0d2VldHMgaW4gdGltZWxpbmUgcGF5bG9hZHMgXHUyMDE0IGBub3RlX3R3ZWV0YCBpcyBvbmx5XG4vLyBpbmxpbmVkIGZvciBzb21lIGVuZHBvaW50cy4gUmUtb3BlbmluZyBlYWNoIHRydW5jYXRlZCB0d2VldCdzIGRldGFpbCBwYWdlXG4vLyBjYXVzZXMgdGhlIHBhZ2UtaG9vayB0byBjYXB0dXJlIHRoZSBmdWxsIGBub3RlX3R3ZWV0YCBib2R5LiBUaGUgbG9vcFxuLy8gZHJpdmVzIHRoYXQgYnkgbmF2aWdhdGluZyBhIHNpbmdsZSBkZWRpY2F0ZWQgdGFiIHRocm91Z2ggdGhlIHF1ZXVlLCBvbmVcbi8vIHR3ZWV0IGF0IGEgdGltZSwgZ2F0ZWQgb24gdGhlIHBhZ2UtaG9vayBhY3R1YWxseSBpbmdlc3RpbmcgYSByZXNwb25zZSBmb3Jcbi8vIHRoZSB0d2VldCB3ZSBqdXN0IG5hdmlnYXRlZCB0byAoc28gZGVsZXRlZCAvIHBheXdhbGxlZCAvIDQwNCdkIHR3ZWV0c1xuLy8gZG9uJ3QgbWFrZSB1cyBzcGluIGFuZCBzbyB3ZSBkb24ndCBzbGFtIFggd2l0aCByZWZyZXNoZXMgZmFzdGVyIHRoYW4gdGhlXG4vLyB0YWIgY2FuIGxvYWQpLlxuXG5jb25zdCBSRUZFVENIX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV9yZWZldGNoX3RhYl9pZF9fJztcblxuYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFRhYklkKCk6IFByb21pc2U8bnVtYmVyIHwgbnVsbD4ge1xuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFJFRkVUQ0hfVEFCX0tFWSk7XG4gIGNvbnN0IGlkID0gc3RvcmVkW1JFRkVUQ0hfVEFCX0tFWV07XG4gIHJldHVybiB0eXBlb2YgaWQgPT09ICdudW1iZXInID8gaWQgOiBudWxsO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRSZWZldGNoVGFiSWQoaWQ6IG51bWJlciB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGlkID09PSBudWxsKSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnJlbW92ZShSRUZFVENIX1RBQl9LRVkpO1xuICB9IGVsc2Uge1xuICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbUkVGRVRDSF9UQUJfS0VZXTogaWQgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XG4gIGNvbnN0IHRvdGFsID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcbiAgaWYgKHRvdGFsID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygncmVmZXRjaDogbm90aGluZyBxdWV1ZWQnKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxuICApO1xuICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbih7XG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcbiAgICBwcm9jZXNzZWQ6IDAsXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgaW5mbGlnaHQ6IG51bGwsXG4gIH0pO1xuICBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcbiAgdm9pZCByZWZldGNoVGljaygpO1xuICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3Agc3RhcnRlZCcsIHsgcXVldWVkOiB0b3RhbCwgaW50ZXJ2YWxfc2VjOiBzZWNvbmRzIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5sZXQgcmVmZXRjaEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kczogbnVtYmVyKTogdm9pZCB7XG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcbiAgcmVmZXRjaEludGVydmFsSGFuZGxlID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgcmVmZXRjaFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ3JlZmV0Y2ggdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIH0pO1xuICB9LCBzZWNvbmRzICogMTAwMCk7XG59XG5cbmZ1bmN0aW9uIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTogdm9pZCB7XG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSk7XG4gICAgcmVmZXRjaEludGVydmFsSGFuZGxlID0gbnVsbDtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigncmVmZXRjaC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XG4gIGF3YWl0IHNldFJlZmV0Y2hUYWJJZChudWxsKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3AgY2FuY2VsbGVkJywge1xuICAgIGhhZF90YWI6IHRhYklkICE9PSBudWxsLFxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZldGNoVGljaygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBpZiAoc2VzcyA9PT0gbnVsbCkge1xuICAgIC8vIExvb3Agd2FzIGNhbmNlbGxlZCBvciBuZXZlciBzdGFydGVkOyBub3RoaW5nIHRvIGRvLlxuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gV2FpdC1mb3ItaW5nZXN0IGd1YXJkOiBpZiB3ZSdyZSBzdGlsbCBleHBlY3RpbmcgYSBjYXB0dXJlIGZvciB0aGVcbiAgLy8gcHJldmlvdXNseS1uYXZpZ2F0ZWQgdGFyZ2V0LCBvbmx5IGFkdmFuY2Ugb25jZSB3ZSd2ZSBlaXRoZXIgc2VlbiB0aGVcbiAgLy8gY2FwdHVyZSAob25HcmFwaHFsQ2FwdHVyZSBjbGVhcnMgYGluZmxpZ2h0YCkgb3IgaGl0IHRoZSB0aW1lb3V0LlxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShzZXNzLmluZmxpZ2h0Lm5hdmlnYXRlZEF0KTtcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgXHUyMDE0IHBhZ2UtaG9vayBtYXkgeWV0IGNhcHR1cmUgdGhlIHJlc3BvbnNlLlxuICAgIH1cbiAgICAvLyBUaW1lZCBvdXQuIFRyZWF0IGFzIFwidGhpcyB0YXJnZXQgd29uJ3QgaW5nZXN0XCIgYW5kIGRyb3AgaXQuXG4gICAgYXdhaXQgd2FybigncmVmZXRjaDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XG4gICAgICB0d2VldF9pZDogc2Vzcy5pbmZsaWdodC50d2VldElkLFxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxuICAgIH0pO1xuICAgIC8vIEZpbmQgd2hpY2ggaGFuZGxlIHRoaXMgaWQgaXMgcXVldWVkIHVuZGVyIHNvIHdlIGNhbiBkZXF1ZXVlIGl0LlxuICAgIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICAgIGlmIChpZHMuaW5jbHVkZXMoc2Vzcy5pbmZsaWdodC50d2VldElkKSkge1xuICAgICAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaChoYW5kbGUsIHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICB9XG5cbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dFJlZmV0Y2hUYXJnZXQoKTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBjb21wbGV0ZScsIHsgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCB9KTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHVybCA9IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmhhbmRsZX0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcbiAgbGV0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XG4gIGlmICh0YWJJZCAhPT0gbnVsbCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRhYklkID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBpZiAodGFiSWQgPT09IG51bGwpIHtcbiAgICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwsIGFjdGl2ZTogZmFsc2UgfSk7XG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicpIGF3YWl0IHNldFJlZmV0Y2hUYWJJZCh0YWIuaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcbiAgICB9XG4gICAgc2VzcyA9IChhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpKSA/PyBzZXNzO1xuICAgIHNlc3MuaW5mbGlnaHQgPSB7XG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIG5hdmlnYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoIHRpY2snLCB7XG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICByZW1haW5pbmc6IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCksXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIH0pO1xuICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHRhcmdldC5oYW5kbGUsIHRhcmdldC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbi8vIC0tLSBNZWRpYS1jcmF3bCBsb29wIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vL1xuLy8gTWlycm9ycyB0aGUgcmVmZXRjaCBsb29wIGJ1dCB0YXJnZXRzIHRoZSBtZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXRzIHRoYXRcbi8vIHRoZSBub3JtYWxpemVyIG9ic2VydmVkIHZpYSB0aGUgTWVkaWEgdGFiIC8gVXNlck1lZGlhIGVuZHBvaW50IHdpdGhcbi8vIGluc3VmZmljaWVudCBkYXRhIHRvIGJ1aWxkIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIFRoZSBjcmF3bCBsb29wIHdhbGtzXG4vLyBhIGRlZGljYXRlZCB0YWIgdGhyb3VnaCBlYWNoIHR3ZWV0J3MgZGV0YWlsIHBhZ2UgKGhhbmRsZS1sZXNzIFVSTCBmb3JtXG4vLyB3aGVuIHRoZSBoaW50LWhhbmRsZSBpcyBtaXNzaW5nKSwgYXQgdGhlIGF1dG8tc2Nyb2xsIGNhZGVuY2UsIHNvIHRoZVxuLy8gcGFnZS1ob29rIGNhbiBjYXB0dXJlIHRoZSByZWFsIHR3ZWV0IHNoYXBlLlxuXG5jb25zdCBNRURJQV9DUkFXTF9UQUJfS0VZID0gJ19faW1tX2FyY2hpdmVfbWVkaWFfY3Jhd2xfdGFiX2lkX18nO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoTUVESUFfQ1JBV0xfVEFCX0tFWSk7XG4gIGNvbnN0IGlkID0gc3RvcmVkW01FRElBX0NSQVdMX1RBQl9LRVldO1xuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChpZCA9PT0gbnVsbCkgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnJlbW92ZShNRURJQV9DUkFXTF9UQUJfS0VZKTtcbiAgZWxzZSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW01FRElBX0NSQVdMX1RBQl9LRVldOiBpZCB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRNZWRpYUNyYXdsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XG4gIGNvbnN0IHRvdGFsID0gYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTtcbiAgaWYgKHRvdGFsID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IG5vdGhpbmcgcXVldWVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcbiAgKTtcbiAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oe1xuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXG4gICAgcHJvY2Vzc2VkOiAwLFxuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIGluZmxpZ2h0OiBudWxsLFxuICB9KTtcbiAgc3RhcnRNZWRpYUNyYXdsSW50ZXJ2YWwoc2Vjb25kcyk7XG4gIHZvaWQgbWVkaWFDcmF3bFRpY2soKTtcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBzdGFydGVkJywgeyBxdWV1ZWQ6IHRvdGFsLCBpbnRlcnZhbF9zZWM6IHNlY29uZHMgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmxldCBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGU6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzOiBudW1iZXIpOiB2b2lkIHtcbiAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgY2xlYXJJbnRlcnZhbChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUpO1xuICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgdm9pZCBtZWRpYUNyYXdsVGljaygpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybignbWVkaWEtY3Jhd2wgdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIH0pO1xuICB9LCBzZWNvbmRzICogMTAwMCk7XG59XG5cbmZ1bmN0aW9uIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTogdm9pZCB7XG4gIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XG4gICAgbWVkaWFDcmF3bEludGVydmFsSGFuZGxlID0gbnVsbDtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxNZWRpYUNyYXdsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignbWVkaWEtY3Jhd2wtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxuICBjb25zdCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQobnVsbCk7XG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihudWxsKTtcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBjYW5jZWxsZWQnLCB7XG4gICAgaGFkX3RhYjogdGFiSWQgIT09IG51bGwsXG4gICAgcHJvY2Vzc2VkOiBzZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG1lZGlhQ3Jhd2xUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGlmIChzZXNzID09PSBudWxsKSB7XG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShzZXNzLmluZmxpZ2h0Lm5hdmlnYXRlZEF0KTtcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgb24gdGhlIHBhZ2UtaG9va1xuICAgIH1cbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XG4gICAgICB0d2VldF9pZDogc2Vzcy5pbmZsaWdodC50d2VldElkLFxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxuICAgIH0pO1xuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgfVxuXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRNZWRpYUNyYXdsVGFyZ2V0KCk7XG4gIGlmICghdGFyZ2V0KSB7XG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZChudWxsKTtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihudWxsKTtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIFNraXAgaWYgYWxyZWFkeSBpbiB0aGUgYXJjaGl2ZSBcdTIwMTQgcGFydGlhbCBjYXB0dXJlcyBjYW4gb3V0bGl2ZSBhXG4gIC8vIHNlcGFyYXRlIGZ1bGwgY2FwdHVyZSBwYXRoLlxuICBpZiAoYXdhaXQgaXNDb21taXR0ZWQodGFyZ2V0LnR3ZWV0SWQpKSB7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBXaGVuIHdlIGRvbid0IGtub3cgdGhlIHBhcmVudCdzIGF1dGhvciBoYW5kbGUgKHF1b3RlL1JUIG9mIGEgdHdlZXRcbiAgLy8gWCBzdHJpcHBlZCwgb3IgYSBVc2VyTWVkaWEgdGh1bWJuYWlsIHRoYXQgbGFja2VkIHRoZSBhdXRob3IgYmxvY2spLFxuICAvLyBmYWxsIGJhY2sgdG8gYC9pL3dlYi9zdGF0dXMvPGlkPmAuIFggcmVzb2x2ZXMgaXQgdG8gdGhlIGNvcnJlY3RcbiAgLy8gZGV0YWlsIHBhZ2UsIHdoaWNoIGlzIGVub3VnaCBmb3IgdGhlIHBhZ2UtaG9vayB0byBpbmdlc3QgYVxuICAvLyBUd2VldERldGFpbCByZXNwb25zZS5cbiAgY29uc3QgdXJsID1cbiAgICB0YXJnZXQuYnVja2V0ID09PSAnX3Vua25vd24nXG4gICAgICA/IGBodHRwczovL3guY29tL2kvd2ViL3N0YXR1cy8ke3RhcmdldC50d2VldElkfWBcbiAgICAgIDogYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuYnVja2V0fS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRNZWRpYUNyYXdsVGFiSWQoKTtcbiAgaWYgKHRhYklkICE9PSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdGFiSWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiBmYWxzZSB9KTtcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkID09PSAnbnVtYmVyJykgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKHRhYi5pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy51cGRhdGUodGFiSWQsIHsgdXJsIH0pO1xuICAgIH1cbiAgICBzZXNzID0gKGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCkpID8/IHNlc3M7XG4gICAgc2Vzcy5pbmZsaWdodCA9IHtcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIHRpY2snLCB7XG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBoaW50X2hhbmRsZTogdGFyZ2V0LmJ1Y2tldCA9PT0gJ191bmtub3duJyA/IG51bGwgOiB0YXJnZXQuYnVja2V0LFxuICAgICAgcmVtYWluaW5nOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBzZXNzLnRvdGFsQXRTdGFydCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignbWVkaWEtY3Jhd2wgbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuLy8gLS0tIFRocmVhZC1vcGVuaW5nIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy9cbi8vIFRpbWVsaW5lcyBvZnRlbiBzaG93IGEgY29yZSBhY2NvdW50J3Mgcm9vdCB0d2VldCB3aXRob3V0IGV2ZXJ5IGxhdGVyXG4vLyBzZWxmLXJlcGx5IGluIHRoZSBjb252ZXJzYXRpb24uIFRoaXMgdXRpbGl0eSB3YWxrcyBhIGRlZGljYXRlZCB0YWIgdGhyb3VnaFxuLy8gcXVldWVkIGNvcmUgdGhyZWFkIHJvb3RzIGFuZCBudWRnZXMgdGhlIGRldGFpbCBwYWdlIHNvIFR3ZWV0RGV0YWlsIHBheWxvYWRzXG4vLyBsb2FkIHRoZSByZXN0IG9mIHRoZSBjb252ZXJzYXRpb24uXG5cbmNvbnN0IFRIUkVBRF9PUEVOX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV90aHJlYWRfb3Blbl90YWJfaWRfXyc7XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFRocmVhZE9wZW5UYWJJZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChUSFJFQURfT1BFTl9UQUJfS0VZKTtcbiAgY29uc3QgaWQgPSBzdG9yZWRbVEhSRUFEX09QRU5fVEFCX0tFWV07XG4gIHJldHVybiB0eXBlb2YgaWQgPT09ICdudW1iZXInID8gaWQgOiBudWxsO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRUaHJlYWRPcGVuVGFiSWQoaWQ6IG51bWJlciB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGlkID09PSBudWxsKSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFRIUkVBRF9PUEVOX1RBQl9LRVkpO1xuICBlbHNlIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbVEhSRUFEX09QRU5fVEFCX0tFWV06IGlkIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydFRocmVhZE9wZW5Mb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcbiAgY29uc3QgdG90YWwgPSBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpO1xuICBpZiAodG90YWwgPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCd0aHJlYWQtb3Blbjogbm90aGluZyBxdWV1ZWQnKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxuICApO1xuICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbih7XG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcbiAgICBwcm9jZXNzZWQ6IDAsXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgaW5mbGlnaHQ6IG51bGwsXG4gIH0pO1xuICBzdGFydFRocmVhZE9wZW5JbnRlcnZhbChzZWNvbmRzKTtcbiAgdm9pZCB0aHJlYWRPcGVuVGljaygpO1xuICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxubGV0IHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZTogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIHN0YXJ0VGhyZWFkT3BlbkludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xuICBpZiAodGhyZWFkT3BlbkludGVydmFsSGFuZGxlICE9PSBudWxsKSBjbGVhckludGVydmFsKHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSk7XG4gIHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIHRocmVhZE9wZW5UaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCd0aHJlYWQtb3BlbiB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcbn1cblxuZnVuY3Rpb24gc3RvcFRocmVhZE9wZW5JbnRlcnZhbCgpOiB2b2lkIHtcbiAgaWYgKHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwodGhyZWFkT3BlbkludGVydmFsSGFuZGxlKTtcbiAgICB0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbFRocmVhZE9wZW5Mb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd0aHJlYWQtb3Blbi10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0VGhyZWFkT3BlblRhYklkKCk7XG4gIGF3YWl0IHNldFRocmVhZE9wZW5UYWJJZChudWxsKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCk7XG4gIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcbiAgICBwcm9jZXNzZWQ6IHNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gdGhyZWFkT3BlblRpY2soKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBzZXNzID0gYXdhaXQgZ2V0VGhyZWFkT3BlblNlc3Npb24oKTtcbiAgaWYgKHNlc3MgPT09IG51bGwpIHtcbiAgICBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xuICAgIGlmIChlbGFwc2VkIDwgSU5HRVNUX1dBSVRfTVMpIHJldHVybjtcbiAgICBhd2FpdCB3YXJuKCd0aHJlYWQtb3BlbjogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XG4gICAgICB0d2VldF9pZDogc2Vzcy5pbmZsaWdodC50d2VldElkLFxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxuICAgIH0pO1xuICAgIGF3YWl0IG1hcmtUaHJlYWRPcGVuU2VlbihzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xuICAgIGF3YWl0IGRlcXVldWVUaHJlYWRPcGVuKHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzZXNzKTtcbiAgfVxuXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRUaHJlYWRPcGVuVGFyZ2V0KCk7XG4gIGlmICghdGFyZ2V0KSB7XG4gICAgc3RvcFRocmVhZE9wZW5JbnRlcnZhbCgpO1xuICAgIGF3YWl0IHNldFRocmVhZE9wZW5UYWJJZChudWxsKTtcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihudWxsKTtcbiAgICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChhd2FpdCBoYXNUaHJlYWRPcGVuU2Vlbih0YXJnZXQudHdlZXRJZCkpIHtcbiAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHVybCA9IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmhhbmRsZX0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcbiAgbGV0IHRhYklkID0gYXdhaXQgZ2V0VGhyZWFkT3BlblRhYklkKCk7XG4gIGlmICh0YWJJZCAhPT0gbnVsbCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRhYklkID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBpZiAodGFiSWQgPT09IG51bGwpIHtcbiAgICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwsIGFjdGl2ZTogZmFsc2UgfSk7XG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIHRocm93IG5ldyBFcnJvcignY3JlYXRlZCB0YWIgd2l0aG91dCBpZCcpO1xuICAgICAgdGFiSWQgPSB0YWIuaWQ7XG4gICAgICBhd2FpdCBzZXRUaHJlYWRPcGVuVGFiSWQodGFiSWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcbiAgICB9XG4gICAgYXdhaXQgbWFya1RocmVhZE9wZW5TZWVuKHRhcmdldC50d2VldElkKTtcbiAgICBzZXNzID0gKGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCkpID8/IHNlc3M7XG4gICAgc2Vzcy5pbmZsaWdodCA9IHtcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHNlc3MpO1xuICAgIGlmICh0YWJJZCAhPT0gbnVsbCkge1xuICAgICAgdm9pZCBudWRnZVRocmVhZE9wZW5UYWIodGFiSWQpO1xuICAgIH1cbiAgICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiB0aWNrJywge1xuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgcmVtYWluaW5nOiBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpLFxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBzZXNzLnRvdGFsQXRTdGFydCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybigndGhyZWFkLW9wZW4gbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gICAgYXdhaXQgbWFya1RocmVhZE9wZW5TZWVuKHRhcmdldC50d2VldElkKTtcbiAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzZXNzKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBudWRnZVRocmVhZE9wZW5UYWIodGFiSWQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCAxNTAwKSk7XG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQgfSxcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgIGZ1bmM6ICgpID0+IHtcbiAgICAgICAgY29uc3QgaCA9IHdpbmRvdy5pbm5lckhlaWdodDtcbiAgICAgICAgY29uc3Qgc3RlcCA9ICgpID0+IHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuMywgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xuICAgICAgICBzdGVwKCk7XG4gICAgICAgIHNldFRpbWVvdXQoc3RlcCwgMTQwMCk7XG4gICAgICAgIHNldFRpbWVvdXQoc3RlcCwgMjgwMCk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCd0aHJlYWQtb3BlbiBzY3JvbGwtbnVkZ2UgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxufVxuXG4vLyAtLS0gUXVhcmFudGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBxdWFyYW50aW5lKFxuICByZWFzb246IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgdXJsOiBzdHJpbmcsXG4gIHJhdzogdW5rbm93bixcbiAgZXJyOiB1bmtub3duXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgbG9nRXJyKCdxdWFyYW50aW5pbmcgY2FwdHVyZScsIHsgcmVhc29uLCBlbmRwb2ludCwgdXJsLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSByZXR1cm47XG4gIGNvbnN0IHBheWxvYWQ6IFF1YXJhbnRpbmVQYXlsb2FkID0ge1xuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgIHJlYXNvbixcbiAgICBlbmRwb2ludCxcbiAgICBjYXB0dXJlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNvdXJjZV91cmw6IHVybCxcbiAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIHJhdyxcbiAgfTtcbiAgY29uc3QgdHMgPSBpc29Db21wYWN0KHBheWxvYWQuY2FwdHVyZWRfYXQpO1xuICBjb25zdCBoYXNoID0gYXdhaXQgc2hhOChKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XG4gIGNvbnN0IHBhdGggPSBgcmF3L19xdWFyYW50aW5lLyR7dHN9LSR7aGFzaH0uanNvbmA7XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgYXdhaXQgY2xpZW50LnB1dEZpbGUoe1xuICAgICAgcGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHBheWxvYWQsIG51bGwsIDIpICsgJ1xcbicpLFxuICAgICAgbWVzc2FnZTogYHF1YXJhbnRpbmU6ICR7cmVhc29ufSAke2VuZHBvaW50fWAsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKHFlcnIpIHtcbiAgICBhd2FpdCBsb2dFcnIoJ3F1YXJhbnRpbmUgY29tbWl0IGZhaWxlZCcsIHsgLi4uZGVzY3JpYmVFcnJvcihxZXJyKSB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzaGE4KHM6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGJ1ZiA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcbiAgY29uc3QgZGlnZXN0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBidWYpO1xuICBjb25zdCBoZXggPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGRpZ2VzdCkpXG4gICAgLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcbiAgICAuam9pbignJyk7XG4gIHJldHVybiBoZXguc2xpY2UoMCwgOCk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHZlcmlmaWNhdGlvbiAmIGFjY291bnRzIGxpc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5Q29ubmVjdGlvbihmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgbG9naW46IG51bGwsXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGlmICghZm9yY2UpIHtcbiAgICAvLyBTa2lwIGlmIHdlJ3JlIGluc2lkZSB0aGUgcmVwb3J0ZWQgcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IHJlLWNoZWNraW5nXG4gICAgLy8gYmVmb3JlIHJlc2V0IGp1c3Qgd2FzdGVzIG1vcmUgb2YgdGhlIHNhbWUgZXhoYXVzdGVkIHF1b3RhIGFuZCBrZWVwc1xuICAgIC8vIHRoZSA0MDNzIGNvbWluZy5cbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xuICAgICAgY29uc3Qgbm93U2VjID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gICAgICBpZiAobm93U2VjIDwgY29ubi5yYXRlTGltaXRSZXNldEF0KSByZXR1cm47XG4gICAgfVxuICAgIC8vIEFwcGx5IHRoZSBwZXJpb2RpYy1jaGVjayBnYXRlIHRvIGV2ZXJ5IHN0YXR1cywgbm90IGp1c3QgJ29rJy4gVGhlXG4gICAgLy8gcHJldmlvdXMgYmVoYXZpb3IgcmUtdmVyaWZpZWQgb24gZXZlcnkgd2FrZSB3aGVuZXZlciB0aGUgY29ubmVjdGlvblxuICAgIC8vIHdhc24ndCAnb2snLCB3aGljaCBkdXJpbmcgYSByYXRlLWxpbWl0IHdpbmRvdyBtZWFudCAyIEFQSSBjYWxscyBwZXJcbiAgICAvLyBTVyB3YWtlICh2ZXJpZnlSZXBvQWNjZXNzIGRvZXMgR0VUIC91c2VyICsgR0VUIC9yZXBvcy97b30ve3J9KS5cbiAgICBpZiAoY29ubi5jaGVja2VkQXQpIHtcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGNvbm4uY2hlY2tlZEF0KTtcbiAgICAgIGlmIChhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHIgPSBhd2FpdCBjbGllbnQudmVyaWZ5UmVwb0FjY2VzcygpO1xuICAgIC8vIFByb2JlIHRoZSBjb25maWd1cmVkIGJyYW5jaC4gQSBub24tZGVmYXVsdCBicmFuY2ggaXMgZmluZSBcdTIwMTQgaXQnc1xuICAgIC8vIHJvdXRpbmUgdG8gY2FwdHVyZSBpbnRvIGEgd29ya2luZyBicmFuY2ggXHUyMDE0IGJ1dCBhICptaXNzaW5nKiBicmFuY2hcbiAgICAvLyB3b3VsZCA0MjIgZXZlcnkgY29tbWl0LlxuICAgIGxldCBicmFuY2hPayA9IHRydWU7XG4gICAgaWYgKHNldHRpbmdzLmJyYW5jaCAmJiBzZXR0aW5ncy5icmFuY2ggIT09IHIuZGVmYXVsdF9icmFuY2gpIHtcbiAgICAgIGJyYW5jaE9rID0gYXdhaXQgY2xpZW50LmJyYW5jaEV4aXN0cyhzZXR0aW5ncy5icmFuY2gpO1xuICAgIH1cbiAgICBjb25zdCBjaGVja1dyaXRlID0gZm9yY2UgfHwgaXNXcml0ZUF1dGhFcnJvcihjb25uLmVycm9yKTtcbiAgICBpZiAoYnJhbmNoT2sgJiYgY2hlY2tXcml0ZSkge1xuICAgICAgYXdhaXQgY2xpZW50LnZlcmlmeVdyaXRlQWNjZXNzKCk7XG4gICAgfVxuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnb2snLFxuICAgICAgbG9naW46IHIubG9naW4sXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgZGVmYXVsdEJyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGJyYW5jaE9rLFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbiAgICB9KTtcbiAgICBhd2FpdCBpbmZvKCdjb25uZWN0aW9uIHZlcmlmaWVkJywge1xuICAgICAgbG9naW46IHIubG9naW4sXG4gICAgICByZXBvOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgY29uZmlndXJlZF9icmFuY2g6IHNldHRpbmdzLmJyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRfYnJhbmNoX2V4aXN0czogYnJhbmNoT2ssXG4gICAgICB3cml0ZV9hY2Nlc3M6IGNoZWNrV3JpdGUgPyAnY2hlY2tlZCcgOiAnbm90X2NoZWNrZWQnLFxuICAgIH0pO1xuICAgIGlmICghYnJhbmNoT2spIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2NvbmZpZ3VyZWQgYnJhbmNoIGRvZXMgbm90IGV4aXN0IG9uIHJlbW90ZScsIHtcbiAgICAgICAgY29uZmlndXJlZDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgICAgZml4OiAnb3BlbiBTZXR0aW5ncyBhbmQgY2hhbmdlIGJyYW5jaCB0byAnICsgci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc3QgY2F0ID0gZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgPyBlcnIuY2F0ZWdvcnkgOiAndW5rbm93bic7XG4gICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgIGNhdCA9PT0gJ2F1dGgnXG4gICAgICAgID8gJ2F1dGgtZXJyb3InXG4gICAgICAgIDogY2F0ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgOiBjYXQgPT09ICduZXR3b3JrJ1xuICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgIDogJ2F1dGgtZXJyb3InO1xuICAgIGNvbnN0IHJlc2V0QXQgPVxuICAgICAgZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgY2F0ID09PSAncmF0ZS1saW1pdCcgPyBlcnIucmF0ZUxpbWl0UmVzZXRBdCA6IG51bGw7XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXMsXG4gICAgICBsb2dpbjogbnVsbCxcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKS5tZXNzYWdlLFxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiByZXNldEF0LFxuICAgIH0pO1xuICAgIGF3YWl0IHdhcm4oJ2Nvbm5lY3Rpb24gY2hlY2sgZmFpbGVkJywge1xuICAgICAgY2F0ZWdvcnk6IGNhdCxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjY291bnRzTGlzdChmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0KSB7XG4gICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICghZm9yY2UpIHtcbiAgICAvLyBTa2lwIHdoaWxlIGluc2lkZSBhIGtub3duIHJhdGUtbGltaXQgd2luZG93IFx1MjAxNCBhY2NvdW50cy55YW1sIGlzIGZldGNoZWRcbiAgICAvLyB2aWEgYXV0aGVudGljYXRlZCByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLCB3aGljaCBjb3VudHMgYWdhaW5zdCB0aGVcbiAgICAvLyBzYW1lIHF1b3RhLlxuICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcbiAgICAgIGNvbnN0IG5vd1NlYyA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBTa2lwIGlmIHdlIHJlZnJlc2hlZCByZWNlbnRseS4gYWNjb3VudHMueWFtbCBjaGFuZ2VzIHJhcmVseSBcdTIwMTQgdGhlIG9sZFxuICAgIC8vIGNvZGUgcmUtZmV0Y2hlZCBpdCBvbiBldmVyeSBTVyB3YWtlLCB3aGljaCBkdXJpbmcgaGVhdnkgYnJvd3NpbmcgbWVhbnRcbiAgICAvLyBhIEdpdEh1YiBjYWxsIGV2ZXJ5IGZldyBzZWNvbmRzIGV2ZW4gd2hlbiBub3RoaW5nIHdhcyBiZWluZyBjYXB0dXJlZC5cbiAgICBjb25zdCBsYXN0UmVmcmVzaGVkID0gYXdhaXQgZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpO1xuICAgIGlmIChsYXN0UmVmcmVzaGVkKSB7XG4gICAgICBjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShsYXN0UmVmcmVzaGVkKTtcbiAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYWdlKSAmJiBhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCBjbGllbnQuZmV0Y2hSYXdUZXh0KCdjb25maWcvYWNjb3VudHMueWFtbCcpO1xuICAgIGlmICghdGV4dCkge1xuICAgICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIG5vdCBmb3VuZCBpbiByZXBvOyB1c2luZyBmYWxsYmFjaycpO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlQWNjb3VudHNZYW1sKHRleHQpO1xuICAgIGlmIChwYXJzZWQubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIHBhcnNlZCBlbXB0eTsga2VlcGluZyBmYWxsYmFjaycpO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGF3YWl0IHNldEFjY291bnRzKHBhcnNlZCk7XG4gICAgYXdhaXQgcmVmcmVzaEFyY2hpdmVTbmFwc2hvdChjbGllbnQsIGZvcmNlKTtcbiAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgaWYgKGZvcmNlKSBhd2FpdCBpbmZvKCdhY2NvdW50cyBsaXN0IHJlZnJlc2hlZCcsIHsgY291bnQ6IHBhcnNlZC5sZW5ndGggfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ3JlZnJlc2ggYWNjb3VudHMgZmFpbGVkOyBrZWVwaW5nIGN1cnJlbnQgbGlzdCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFyY2hpdmVTbmFwc2hvdChjbGllbnQ6IEdpdEh1YkNsaWVudCwgZm9yY2U6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdGV4dCA9IGF3YWl0IGNsaWVudC5mZXRjaFJhd1RleHQoJ2RhdGEvbWFuaWZlc3QuanNvbicpO1xuICBpZiAoIXRleHQpIHtcbiAgICBhd2FpdCBzZXRBcmNoaXZlU25hcHNob3QobnVsbCk7XG4gICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhcmNoaXZlIG1hbmlmZXN0IG5vdCBmb3VuZDsgb2xkLXR3ZWV0IGRldGVjdGlvbiBkaXNhYmxlZCcpO1xuICAgIHJldHVybjtcbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IHNuYXBzaG90ID0gcGFyc2VBcmNoaXZlU25hcHNob3QoSlNPTi5wYXJzZSh0ZXh0KSBhcyB1bmtub3duKTtcbiAgICBhd2FpdCBzZXRBcmNoaXZlU25hcHNob3Qoc25hcHNob3QpO1xuICAgIGlmIChmb3JjZSkge1xuICAgICAgYXdhaXQgaW5mbygnYXJjaGl2ZSBzbmFwc2hvdCByZWZyZXNoZWQnLCB7XG4gICAgICAgIGFjY291bnRzOiBPYmplY3Qua2V5cyhzbmFwc2hvdC5hY2NvdW50cykubGVuZ3RoLFxuICAgICAgICBnZW5lcmF0ZWRfYXQ6IHNuYXBzaG90LmdlbmVyYXRlZF9hdCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignYXJjaGl2ZSBzbmFwc2hvdCBwYXJzZSBmYWlsZWQ7IG9sZC10d2VldCBkZXRlY3Rpb24gZGlzYWJsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG59XG5cbi8vIC0tLSBTdGF0ZSBicm9hZGNhc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gYnJvYWRjYXN0U3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgYnVpbGRTdGF0ZSgpO1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCB0YWJDb3VudCA9IDA7XG4gIHRyeSB7XG4gICAgY29uc3QgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gICAgdGFiQ291bnQgPSB0YWJzLmxlbmd0aDtcbiAgfSBjYXRjaCB7XG4gICAgLy8gdGFicy5xdWVyeSBpcyBhbGxvd2VkIGJ5IHRoZSBtYW5pZmVzdCBidXQgY2FuIHRyYW5zaWVudGx5IGZhaWxcbiAgICAvLyBhcm91bmQgZXh0ZW5zaW9uIHN0YXJ0dXA7IHN1cmZhY2luZyAwIGlzIGZpbmUuXG4gIH1cbiAgY29uc3QgcmVmZXRjaFF1ZXVlZCA9IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xRdWV1ZWQgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xuICBjb25zdCB0aHJlYWRPcGVuUXVldWVkID0gYXdhaXQgdGhyZWFkT3BlblF1ZXVlVG90YWwoKTtcbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGNvbnN0IHRocmVhZE9wZW5TZXNzID0gYXdhaXQgZ2V0VGhyZWFkT3BlblNlc3Npb24oKTtcbiAgY29uc3QgYXV0b1Njcm9sbFNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICBjb25zdCByZWNlbnRUd2VldFNpZ2h0aW5ncyA9IGF3YWl0IGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk7XG4gIHJldHVybiB7XG4gICAgdmVyc2lvbjogRVhUX1ZFUlNJT04sXG4gICAgc2V0dGluZ3M6IHJlZGFjdFNldHRpbmdzKHNldHRpbmdzKSxcbiAgICBjb25uZWN0aW9uOiBjb25uLFxuICAgIGFjY291bnRzLFxuICAgIGNvdW50ZXJzLFxuICAgIGF1dG9TY3JvbGw6IHtcbiAgICAgIGFjdGl2ZTogYXV0b1Njcm9sbFNlc3MgIT09IG51bGwgJiYgYXV0b1Njcm9sbFRpbWVyICE9PSBudWxsLFxuICAgICAgdGFiQ291bnQsXG4gICAgICBzY3JvbGxDb3VudDogYXV0b1Njcm9sbFNlc3M/LnNjcm9sbENvdW50ID8/IDAsXG4gICAgICBpbmdlc3RlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uaW5nZXN0ZWRDb3VudCA/PyAwLFxuICAgICAgaW5nZXN0ZWROZXdDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkTmV3Q291bnQgPz8gMCxcbiAgICAgIGluZ2VzdGVkRXhpc3RpbmdDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkRXhpc3RpbmdDb3VudCA/PyAwLFxuICAgICAgc2tpcHBlZE9sZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uc2tpcHBlZE9sZENvdW50ID8/IDAsXG4gICAgICBleHBhbmRlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uZXhwYW5kZWRDb3VudCA/PyAwLFxuICAgIH0sXG4gICAgcmVmZXRjaFF1ZXVlOiB7XG4gICAgICB0b3RhbDogcmVmZXRjaFF1ZXVlZCxcbiAgICAgIHJ1bm5pbmc6IHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcbiAgICAgIHByb2Nlc3NlZDogcmVmZXRjaFNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHJlZmV0Y2hTZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcbiAgICB9LFxuICAgIG1lZGlhQ3Jhd2xRdWV1ZToge1xuICAgICAgdG90YWw6IG1lZGlhQ3Jhd2xRdWV1ZWQsXG4gICAgICBydW5uaW5nOiBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwsXG4gICAgICBwcm9jZXNzZWQ6IG1lZGlhQ3Jhd2xTZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBtZWRpYUNyYXdsU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXG4gICAgfSxcbiAgICB0aHJlYWRPcGVuUXVldWU6IHtcbiAgICAgIHRvdGFsOiB0aHJlYWRPcGVuUXVldWVkLFxuICAgICAgcnVubmluZzogdGhyZWFkT3BlbkludGVydmFsSGFuZGxlICE9PSBudWxsLFxuICAgICAgcHJvY2Vzc2VkOiB0aHJlYWRPcGVuU2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gICAgICB0b3RhbF9hdF9zdGFydDogdGhyZWFkT3BlblNlc3M/LnRvdGFsQXRTdGFydCA/PyAwLFxuICAgIH0sXG4gICAgcmVjZW50VHdlZXRTaWdodGluZ3MsXG4gIH07XG59XG5cbmZ1bmN0aW9uIHJlZGFjdFNldHRpbmdzKHM6IFNldHRpbmdzKTogRXh0ZW5zaW9uU3RhdGVbJ3NldHRpbmdzJ10ge1xuICByZXR1cm4ge1xuICAgIG93bmVyOiBzLm93bmVyLFxuICAgIHJlcG86IHMucmVwbyxcbiAgICBicmFuY2g6IHMuYnJhbmNoLFxuICAgIGVuYWJsZWQ6IHMuZW5hYmxlZCxcbiAgICBhdXRvQ2FwdHVyZTogcy5hdXRvQ2FwdHVyZSxcbiAgICBjb25maWd1cmVkQXQ6IHMuY29uZmlndXJlZEF0LFxuICAgIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogcy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMsXG4gICAgdXBkYXRlRXhpc3Rpbmc6IHMudXBkYXRlRXhpc3RpbmcsXG4gICAgbG93QmFuZHdpZHRoQnJvd3Npbmc6IHMubG93QmFuZHdpZHRoQnJvd3NpbmcsXG4gICAgcGF0U2V0OiBzLnBhdC5sZW5ndGggPiAwLFxuICAgIHBhdFN1ZmZpeDogcy5wYXQubGVuZ3RoID49IDQgPyBzLnBhdC5zbGljZSgtNCkgOiAnJyxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcGFyc2VBcmNoaXZlU25hcHNob3QocmF3OiB1bmtub3duKTogQXJjaGl2ZVNuYXBzaG90IHtcbiAgaWYgKCFyYXcgfHwgdHlwZW9mIHJhdyAhPT0gJ29iamVjdCcpIHRocm93IG5ldyBFcnJvcignbWFuaWZlc3QgaXMgbm90IGFuIG9iamVjdCcpO1xuICBjb25zdCBtYW5pZmVzdCA9IHJhdyBhcyB7IGdlbmVyYXRlZF9hdD86IHVua25vd247IGFjY291bnRzPzogdW5rbm93biB9O1xuICBpZiAoIUFycmF5LmlzQXJyYXkobWFuaWZlc3QuYWNjb3VudHMpKSB0aHJvdyBuZXcgRXJyb3IoJ21hbmlmZXN0LmFjY291bnRzIGlzIG5vdCBhbiBhcnJheScpO1xuICBjb25zdCBhY2NvdW50czogQXJjaGl2ZVNuYXBzaG90WydhY2NvdW50cyddID0ge307XG4gIGZvciAoY29uc3QgZW50cnkgb2YgbWFuaWZlc3QuYWNjb3VudHMpIHtcbiAgICBpZiAoIWVudHJ5IHx8IHR5cGVvZiBlbnRyeSAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHJvdyA9IGVudHJ5IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIGNvbnN0IGhhbmRsZSA9IHR5cGVvZiByb3cuaGFuZGxlID09PSAnc3RyaW5nJyA/IHJvdy5oYW5kbGUgOiAnJztcbiAgICBpZiAoIWhhbmRsZSB8fCBoYW5kbGUgPT09ICdfbWlzYycpIGNvbnRpbnVlO1xuICAgIGFjY291bnRzW2hhbmRsZS50b0xvd2VyQ2FzZSgpXSA9IHtcbiAgICAgIGhhbmRsZSxcbiAgICAgIGxhdGVzdF9wb3N0X2F0OiB0eXBlb2Ygcm93LmxhdGVzdF9wb3N0X2F0ID09PSAnc3RyaW5nJyA/IHJvdy5sYXRlc3RfcG9zdF9hdCA6IG51bGwsXG4gICAgICBsYXRlc3RfY2FwdHVyZV9hdDogdHlwZW9mIHJvdy5sYXRlc3RfY2FwdHVyZV9hdCA9PT0gJ3N0cmluZycgPyByb3cubGF0ZXN0X2NhcHR1cmVfYXQgOiBudWxsLFxuICAgICAgcm93X2NvdW50OiB0eXBlb2Ygcm93LnJvd19jb3VudCA9PT0gJ251bWJlcicgPyByb3cucm93X2NvdW50IDogbnVsbCxcbiAgICB9O1xuICB9XG4gIHJldHVybiB7XG4gICAgZ2VuZXJhdGVkX2F0OiB0eXBlb2YgbWFuaWZlc3QuZ2VuZXJhdGVkX2F0ID09PSAnc3RyaW5nJyA/IG1hbmlmZXN0LmdlbmVyYXRlZF9hdCA6IG51bGwsXG4gICAgZmV0Y2hlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIGFjY291bnRzLFxuICB9O1xufVxuXG5mdW5jdGlvbiBhcmNoaXZlU25hcHNob3RIYXNUd2VldCh0OiBDYW5vbmljYWxUd2VldCwgc25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGwpOiBib29sZWFuIHtcbiAgaWYgKCFzbmFwc2hvdCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBlbnRyeSA9IHNuYXBzaG90LmFjY291bnRzW3QuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKV07XG4gIGlmICghZW50cnk/LmxhdGVzdF9wb3N0X2F0KSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHBvc3RlZCA9IERhdGUucGFyc2UodC5wb3N0ZWRfYXQpO1xuICBjb25zdCBsYXRlc3QgPSBEYXRlLnBhcnNlKGVudHJ5LmxhdGVzdF9wb3N0X2F0KTtcbiAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZShwb3N0ZWQpICYmIE51bWJlci5pc0Zpbml0ZShsYXRlc3QpICYmIHBvc3RlZCA8PSBsYXRlc3Q7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkVHdlZXRTaWdodGluZyhcbiAgdDogQ2Fub25pY2FsVHdlZXQsXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHNlZW5BdDogc3RyaW5nLFxuICBmcmVzaG5lc3M6ICduZXcnIHwgJ2V4aXN0aW5nJyA9ICduZXcnLFxuICBhY3Rpb246IFR3ZWV0U2lnaHRpbmdbJ2FjdGlvbiddID0gJ2J1ZmZlcmVkJ1xuKTogVHdlZXRTaWdodGluZyB7XG4gIHJldHVybiB7XG4gICAgdHdlZXRfaWQ6IHQudHdlZXRfaWQsXG4gICAgYWNjb3VudF9oYW5kbGU6IHQuYWNjb3VudF9oYW5kbGUsXG4gICAgcG9zdGVkX2F0OiB0LnBvc3RlZF9hdCxcbiAgICB0ZXh0OiB0LnRleHRfcmVzb2x2ZWQgfHwgdC50ZXh0LFxuICAgIHR3ZWV0X3R5cGU6IHQudHdlZXRfdHlwZSxcbiAgICB0d2VldF91cmw6IHQudHdlZXRfdXJsLFxuICAgIHNlZW5fYXQ6IHNlZW5BdCxcbiAgICBlbmRwb2ludCxcbiAgICBhcmNoaXZlX3N0YXR1czogZnJlc2huZXNzID09PSAnZXhpc3RpbmcnID8gJ3NhdmVkJyA6ICduZXcnLFxuICAgIGFjdGlvbixcbiAgfTtcbn1cblxuZnVuY3Rpb24gaXNXcml0ZUF1dGhFcnJvcihtZXNzYWdlOiBzdHJpbmcgfCBudWxsKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnICYmXG4gICAgL1Jlc291cmNlIG5vdCBhY2Nlc3NpYmxlIGJ5IHBlcnNvbmFsIGFjY2VzcyB0b2tlbnxcXC9naXRcXC9ibG9ic3xcXC9naXRcXC9yZWZzL2kudGVzdChtZXNzYWdlKVxuICApO1xufVxuXG5mdW5jdGlvbiBpc29Db21wYWN0KGlzbzogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gMjAyNS0wNC0xMlQxNDoyMzowMS4wMDBaIFx1MjE5MiAyMDI1LTA0LTEyVDE0MjMwMVpcbiAgY29uc3QgZCA9IG5ldyBEYXRlKGlzbyk7XG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gaXNvLnJlcGxhY2UoL1s6Ll0vZywgJycpO1xuICBjb25zdCBwYWQgPSAobjogbnVtYmVyLCB3ID0gMikgPT4gU3RyaW5nKG4pLnBhZFN0YXJ0KHcsICcwJyk7XG4gIHJldHVybiAoXG4gICAgYCR7ZC5nZXRVVENGdWxsWWVhcigpfS0ke3BhZChkLmdldFVUQ01vbnRoKCkgKyAxKX0tJHtwYWQoZC5nZXRVVENEYXRlKCkpfWAgK1xuICAgIGBUJHtwYWQoZC5nZXRVVENIb3VycygpKX0ke3BhZChkLmdldFVUQ01pbnV0ZXMoKSl9JHtwYWQoZC5nZXRVVENTZWNvbmRzKCkpfVpgXG4gICk7XG59XG5cbmZ1bmN0aW9uIHZpZXdlclVybChzOiBTZXR0aW5ncyk6IHN0cmluZyB7XG4gIHJldHVybiBgaHR0cHM6Ly8ke3Mub3duZXJ9LmdpdGh1Yi5pby8ke3MucmVwb30vYDtcbn1cblxuLyoqXG4gKiBXYWxrIGBub2RlYCBjb2xsZWN0aW5nIGRvdHRlZCBrZXkgcGF0aHMgdXAgdG8gYG1heERlcHRoYCBkZWVwLiBBcnJheVxuICogaW5kaWNlcyBjb2xsYXBzZSB0byBgWzBdYCAod2Ugb25seSBkZXNjZW5kIGludG8gdGhlIGZpcnN0IGVsZW1lbnQpLiBVc2VkXG4gKiB0byBzdXJmYWNlIHRoZSBzdHJ1Y3R1cmFsIHNrZWxldG9uIG9mIGFuIHVuZmFtaWxpYXIgR3JhcGhRTCByZXNwb25zZVxuICogd2l0aG91dCBpbmNsdWRpbmcgYW55IGRhdGEgdmFsdWVzLlxuICovXG4vKiogQ29sbGVjdCBldmVyeSBkaXN0aW5jdCBgX190eXBlbmFtZWAgdmFsdWUgZm91bmQgYW55d2hlcmUgaW4gdGhlIHRyZWUuICovXG5mdW5jdGlvbiBwcm9iZVR5cGVuYW1lcyhub2RlOiB1bmtub3duKTogc3RyaW5nW10ge1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGlmICh0eXBlb2Ygb2JqLl9fdHlwZW5hbWUgPT09ICdzdHJpbmcnKSBzZWVuLmFkZChvYmouX190eXBlbmFtZSk7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gWy4uLnNlZW5dLnNvcnQoKTtcbn1cblxuLyoqXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIGFueXdoZXJlIGluIHRoZSB0cmVlIHdob3NlIGBfX3R5cGVuYW1lYCBtYXRjaGVzIGFuZFxuICogcmV0dXJuIGl0cyB0b3AtbGV2ZWwga2V5IGxpc3QgKHNvcnRlZCkuIFVzZWZ1bCBmb3IgZGlzY292ZXJpbmcgd2hhdCBmaWVsZHNcbiAqIFggaXMgYWN0dWFsbHkgc2hpcHBpbmcgZm9yIGEgZ2l2ZW4gbm9kZSB0eXBlIGFmdGVyIGEgc2NoZW1hIGNoYW5nZS5cbiAqL1xuZnVuY3Rpb24gcHJvYmVGaXJzdFR5cGVTaGFwZShub2RlOiB1bmtub3duLCB0eXBlbmFtZTogc3RyaW5nKTogc3RyaW5nW10gfCBudWxsIHtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSB0eXBlbmFtZSkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMob2JqKS5zb3J0KCk7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLyoqXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIHdpdGggYF9fdHlwZW5hbWUgPT09IHR5cGVuYW1lYCwgdGhlbiBkZXNjZW5kIHRocm91Z2hcbiAqIHRoZSBnaXZlbiBrZXkgcGF0aCwgYW5kIHJldHVybiB0aGUgdG9wLWxldmVsIGtleXMgb2Ygd2hhdGV2ZXIgaXMgYXQgdGhlXG4gKiBlbmQuIFJldHVybnMgYSBtYXJrZXIgc3RyaW5nIHdoZW4gdGhlIHBhdGggbGVhZHMgc29tZXdoZXJlIG5vbi1vYmplY3Qgc29cbiAqIHdlIGNhbiB0ZWxsIGFwYXJ0IFwiYWJzZW50XCIgZnJvbSBcInByZXNlbnQgYnV0IG5vdCBhbiBvYmplY3RcIi5cbiAqL1xuZnVuY3Rpb24gcHJvYmVUeXBlZE5lc3RlZChub2RlOiB1bmtub3duLCB0eXBlbmFtZTogc3RyaW5nLCBwYXRoOiBzdHJpbmdbXSk6IHVua25vd24ge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICBsZXQgZm91bmQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCA9IG51bGw7XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGlmIChvYmouX190eXBlbmFtZSA9PT0gdHlwZW5hbWUpIHtcbiAgICAgICAgZm91bmQgPSBvYmo7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgaWYgKCFmb3VuZCkgcmV0dXJuIG51bGw7XG4gIGxldCBjdXI6IHVua25vd24gPSBmb3VuZDtcbiAgZm9yIChjb25zdCBzZWcgb2YgcGF0aCkge1xuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIHJldHVybiBgPCR7Y3VyID09PSBudWxsID8gJ251bGwnIDogdHlwZW9mIGN1cn0+YDtcbiAgICBjdXIgPSAoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVtzZWddO1xuICB9XG4gIGlmIChjdXIgPT09IHVuZGVmaW5lZCkgcmV0dXJuICc8bWlzc2luZz4nO1xuICBpZiAoY3VyID09PSBudWxsKSByZXR1cm4gJzxudWxsPic7XG4gIGlmICh0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgcmV0dXJuIGA8JHt0eXBlb2YgY3VyfT5gO1xuICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSByZXR1cm4gYDxhcnJheSBsZW49JHtjdXIubGVuZ3RofT5gO1xuICByZXR1cm4gT2JqZWN0LmtleXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5zb3J0KCk7XG59XG5cbmZ1bmN0aW9uIHNob3J0ZW5VcmwodTogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gQWN0aXZpdHktdGFpbCBjb250ZXh0IGlzIG1vcmUgdXNlZnVsIHdpdGgganVzdCB0aGUgcGF0aDsgZnVsbCBVUkxzIGJlY29tZVxuICAvLyBoYXJkIHRvIHJlYWQgYXQgdGhlIHNpZGViYXIncyB3aWR0aC5cbiAgdHJ5IHtcbiAgICBjb25zdCBwYXJzZWQgPSBuZXcgVVJMKHUpO1xuICAgIGNvbnN0IHBhdGggPSBwYXJzZWQucGF0aG5hbWUgKyAocGFyc2VkLnNlYXJjaCA/ICc/XHUyMDI2JyA6ICcnKTtcbiAgICByZXR1cm4gcGFyc2VkLmhvc3QgPT09ICd4LmNvbScgfHwgcGFyc2VkLmhvc3QgPT09ICd0d2l0dGVyLmNvbSdcbiAgICAgID8gcGF0aFxuICAgICAgOiBgJHtwYXJzZWQuaG9zdH0ke3BhdGh9YDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHUubGVuZ3RoID4gODAgPyBgJHt1LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdTtcbiAgfVxufVxuXG4vLyAtLS0gRGV2IGhlbHBlcnMgZXhwb3NlZCBvbiBnbG9iYWxUaGlzIGZvciB0aGUgZGV2dG9vbHMgY29uc29sZSAtLS0tLS0tLS0tXG4vLyAoZS5nLiBgX19pbW1BcmNoaXZlLmNsZWFyQWxsKClgIGluIHRoZSBiYWNrZ3JvdW5kIHdvcmtlcidzIGRldnRvb2xzKS5cblxuKGdsb2JhbFRoaXMgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLl9faW1tQXJjaGl2ZSA9IHtcbiAgY2xlYXJBbGwsXG4gIGFjdGl2aXR5OiBnZXRBY3Rpdml0eSxcbiAgYWNjb3VudHM6IGdldEFjY291bnRzLFxuICBidWZmZXJzOiBnZXRSdW5CdWZmZXJzLFxuICBmbHVzaEFsbDogKCkgPT4gZmx1c2hBbGwoJ2RldnRvb2xzJyksXG4gIHN0YXRlOiBidWlsZFN0YXRlLFxuICByZWZldGNoUXVldWU6IGdldFJlZmV0Y2hRdWV1ZSxcbiAgc3RhcnRSZWZldGNoOiBzdGFydFJlZmV0Y2hMb29wLFxuICBjYW5jZWxSZWZldGNoOiBjYW5jZWxSZWZldGNoTG9vcCxcbiAgbWVkaWFDcmF3bFF1ZXVlOiBnZXRNZWRpYUNyYXdsUXVldWUsXG4gIHN0YXJ0TWVkaWFDcmF3bDogc3RhcnRNZWRpYUNyYXdsTG9vcCxcbiAgY2FuY2VsTWVkaWFDcmF3bDogY2FuY2VsTWVkaWFDcmF3bExvb3AsXG4gIHRocmVhZE9wZW5RdWV1ZTogZ2V0VGhyZWFkT3BlblF1ZXVlLFxuICBzdGFydFRocmVhZE9wZW46IHN0YXJ0VGhyZWFkT3Blbkxvb3AsXG4gIGNhbmNlbFRocmVhZE9wZW46IGNhbmNlbFRocmVhZE9wZW5Mb29wLFxufTtcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFBQSxFQUNQLE1BQU07QUFBQTtBQUFBO0FBQUEsRUFHTixRQUFRO0FBQUEsRUFDUixTQUFTO0FBQUEsRUFDVCxhQUFhO0FBQUEsRUFDYixjQUFjO0FBQUEsRUFDZCx1QkFBdUI7QUFBQSxFQUN2QixnQkFBZ0I7QUFBQSxFQUNoQixzQkFBc0I7QUFDeEI7QUFFTyxJQUFNLHNCQUFzQjtBQUM1QixJQUFNLHNCQUFzQjtBQUk1QixJQUFNLG9CQUFxQztBQUFBLEVBQ2hELEVBQUUsUUFBUSxVQUFVLE9BQU8sbUNBQW1DLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxVQUFVLE9BQU8sNENBQTRDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxPQUFPLE9BQU8sc0NBQXNDLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxTQUFTLE9BQU8sNkNBQTZDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxjQUFjLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUFBLEVBQ25FLEVBQUUsUUFBUSxZQUFZLE9BQU8sK0JBQStCLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sa0NBQWtDLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sNEJBQTRCLFVBQVUsT0FBTztBQUFBLEVBQ3ZFLEVBQUUsUUFBUSxtQkFBbUIsT0FBTyxxQkFBcUIsVUFBVSxPQUFPO0FBQUEsRUFDMUUsRUFBRSxRQUFRLFlBQVksT0FBTyxrQkFBa0IsVUFBVSxPQUFPO0FBQUEsRUFDaEUsRUFBRSxRQUFRLGtCQUFrQixPQUFPLGtCQUFrQixVQUFVLE9BQU87QUFBQSxFQUN0RSxFQUFFLFFBQVEsZ0JBQWdCLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUN2RTtBQUdPLElBQU0sa0JBQXVDLG9CQUFJLElBQUk7QUFBQSxFQUMxRDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQVdNLElBQU0sb0JBQXlDLG9CQUFJLElBQUksQ0FBQyxvQkFBb0IsY0FBYyxDQUFDO0FBdUIzRixJQUFNLHdCQUF3QjtBQUc5QixJQUFNLGdCQUFnQjtBQUd0QixJQUFNLHNCQUFzQjtBQUc1QixJQUFNLG9CQUFvQjtBQUcxQixJQUFNLGdDQUFnQyxLQUFLLEtBQUs7QUFFaEQsSUFBTSxtQkFBbUI7OztBQzNFaEMsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0I7QUFFeEIsSUFBSSxrQkFBb0M7QUFDeEMsSUFBSSxzQkFBcUM7QUFFekMsU0FBUyxTQUFTLEtBQXlCO0FBQ3pDLE1BQUksSUFBSTtBQUNSLGFBQVcsS0FBSyxJQUFLLE1BQUssT0FBTyxhQUFhLENBQUM7QUFDL0MsU0FBTyxLQUFLLENBQUM7QUFDZjtBQUVBLFNBQVMsV0FBVyxHQUF1QjtBQUN6QyxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFFBQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxNQUFNO0FBQ3JDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUssS0FBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFDOUQsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUU7QUFDaEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDL0QsUUFBTSxJQUFJLE9BQU8sZ0JBQWdCO0FBQ2pDLE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsV0FBTyxFQUFFLFNBQVMsR0FBRyxNQUFNLFdBQVcsQ0FBQyxFQUFFO0FBQUEsRUFDM0M7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxRQUFNLFVBQVUsU0FBUyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0FBQy9ELFNBQU8sRUFBRSxTQUFTLEtBQUs7QUFDekI7QUFFQSxlQUFlLFlBQWdDO0FBQzdDLFFBQU0sRUFBRSxTQUFTLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUNqRCxNQUFJLG9CQUFvQixRQUFRLHdCQUF3QixTQUFTO0FBQy9ELFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFO0FBQUEsSUFDN0IsR0FBRyxRQUFRLFFBQVEsRUFBRSxJQUFJLFFBQVEsUUFBUSxZQUFZLEVBQUUsT0FBTztBQUFBLEVBQ2hFO0FBQ0EsUUFBTSxXQUFXLElBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNO0FBQ3pELFdBQVMsSUFBSSxNQUFNLENBQUM7QUFDcEIsV0FBUyxJQUFJLE1BQU0sS0FBSyxNQUFNO0FBQzlCLFFBQU0sT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUTtBQUMzRCxRQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLE1BQU0sRUFBRSxNQUFNLFVBQVUsR0FBRyxPQUFPO0FBQUEsSUFDakY7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBQ0Qsb0JBQWtCO0FBQ2xCLHdCQUFzQjtBQUN0QixTQUFPO0FBQ1Q7QUFFTyxTQUFTLGVBQWUsR0FBb0I7QUFDakQsU0FBTyxFQUFFLFdBQVcsZUFBZTtBQUNyQztBQUVBLGVBQXNCLFdBQVcsV0FBb0M7QUFDbkUsTUFBSSxDQUFDLFVBQVcsUUFBTztBQUN2QixRQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFFBQU0sS0FBSyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3BELFFBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLElBQzdCLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxJQUN0QjtBQUFBLElBQ0EsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTO0FBQUEsRUFDcEM7QUFDQSxTQUFPLEdBQUcsZUFBZSxHQUFHLFNBQVMsRUFBRSxDQUFDLElBQUksU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMUU7QUFFQSxlQUFzQixXQUFXLFVBQW1DO0FBQ2xFLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFHdEIsTUFBSSxDQUFDLFNBQVMsV0FBVyxlQUFlLEVBQUcsUUFBTztBQUNsRCxRQUFNLFFBQVEsU0FBUyxNQUFNLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxHQUFHO0FBQzlELE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUMvQixRQUFNLENBQUMsT0FBTyxLQUFLLElBQUk7QUFDdkIsTUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFPLFFBQU87QUFDN0IsTUFBSTtBQUNGLFVBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQzdCLEVBQUUsTUFBTSxXQUFXLEdBQXVCO0FBQUEsTUFDMUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDcEMsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7OztBQ1hBLElBQU0scUJBQXNDO0FBQUEsRUFDMUMsUUFBUTtBQUFBLEVBQ1IsT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUFBLEVBQ1AsZUFBZTtBQUFBLEVBQ2Ysd0JBQXdCO0FBQUEsRUFDeEIsa0JBQWtCO0FBQ3BCO0FBRUEsSUFBTSxXQUF5QjtBQUFBLEVBQzdCLFVBQVUsRUFBRSxHQUFHLGlCQUFpQjtBQUFBLEVBQ2hDLFVBQVUsQ0FBQyxHQUFHLGlCQUFpQjtBQUFBLEVBQy9CLHFCQUFxQjtBQUFBLEVBQ3JCLGlCQUFpQjtBQUFBLEVBQ2pCLFlBQVksRUFBRSxHQUFHLG1CQUFtQjtBQUFBLEVBQ3BDLFVBQVUsQ0FBQztBQUFBLEVBQ1gsWUFBWSxDQUFDO0FBQUEsRUFDYixVQUFVLENBQUM7QUFBQSxFQUNYLHNCQUFzQixDQUFDO0FBQUEsRUFDdkIsZ0JBQWdCLENBQUM7QUFBQSxFQUNqQixjQUFjLENBQUM7QUFBQSxFQUNmLGlCQUFpQixDQUFDO0FBQUEsRUFDbEIsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGdCQUFnQjtBQUFBLEVBQ2hCLG1CQUFtQjtBQUFBLEVBQ25CLG1CQUFtQjtBQUFBLEVBQ25CLG1CQUFtQjtBQUNyQjtBQUVBLGVBQWUsT0FBcUMsS0FBa0M7QUFDcEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxHQUFHO0FBQ2xELFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsTUFBSSxVQUFVLFFBQVc7QUFDdkIsV0FBTyxnQkFBZ0IsU0FBUyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUNBLFNBQU87QUFDVDtBQUVBLGVBQWUsT0FBcUMsS0FBUSxPQUF1QztBQUNqRyxRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUM7QUFDbEQ7QUFJQSxlQUFzQixjQUFpQztBQUtyRCxRQUFNLFNBQVMsTUFBTSxPQUFPLFVBQVU7QUFDdEMsUUFBTSxTQUFTLEVBQUUsR0FBRyxrQkFBa0IsR0FBRyxPQUFPO0FBQ2hELE1BQUksT0FBTyxPQUFPLGVBQWUsT0FBTyxHQUFHLEdBQUc7QUFDNUMsUUFBSTtBQUNGLGFBQU8sTUFBTSxNQUFNLFdBQVcsT0FBTyxHQUFHO0FBQUEsSUFDMUMsUUFBUTtBQUNOLGFBQU8sTUFBTTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsWUFBWSxHQUE0QjtBQUc1RCxRQUFNLFVBQW9CLEVBQUUsR0FBRyxFQUFFO0FBQ2pDLE1BQUksUUFBUSxPQUFPLENBQUMsZUFBZSxRQUFRLEdBQUcsR0FBRztBQUMvQyxZQUFRLE1BQU0sTUFBTSxXQUFXLFFBQVEsR0FBRztBQUFBLEVBQzVDO0FBQ0EsUUFBTSxPQUFPLFlBQVksT0FBTztBQUNsQztBQUNBLGVBQXNCLGVBQWUsT0FBNkM7QUFDaEYsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE9BQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hDLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFNBQU87QUFDVDtBQUlBLGVBQXNCLGNBQXdDO0FBQzVELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFBWSxHQUFtQztBQUNuRSxRQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzVCO0FBQ0EsZUFBc0IseUJBQWlEO0FBQ3JFLFNBQU8sT0FBTyxxQkFBcUI7QUFDckM7QUFDQSxlQUFzQix1QkFBdUIsS0FBbUM7QUFDOUUsUUFBTSxPQUFPLHVCQUF1QixHQUFHO0FBQ3pDO0FBSUEsZUFBc0IscUJBQXNEO0FBQzFFLFNBQU8sT0FBTyxpQkFBaUI7QUFDakM7QUFFQSxlQUFzQixtQkFBbUIsVUFBaUQ7QUFDeEYsUUFBTSxPQUFPLG1CQUFtQixRQUFRO0FBQzFDO0FBSUEsZUFBc0IsZ0JBQTBDO0FBQzlELFFBQU0sSUFBSSxNQUFNLE9BQU8sWUFBWTtBQUVuQyxRQUFNLE1BQXVCO0FBQUEsSUFDM0IsR0FBRztBQUFBLElBQ0gsZUFBZSxFQUFFLGtCQUFrQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3hELHdCQUNFLEVBQUUsMkJBQTJCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDcEQsa0JBQWtCLEVBQUUscUJBQXFCLFNBQVksT0FBTyxFQUFFO0FBQUEsRUFDaEU7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixjQUFjLEdBQW1DO0FBQ3JFLFFBQU0sT0FBTyxjQUFjLENBQUM7QUFDOUI7QUFJQSxTQUFTLFdBQW1CO0FBQzFCLFVBQU8sb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUM3QztBQUVBLGVBQXNCLGNBQXVEO0FBQzNFLFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFDcEIsUUFDQSxPQUN5QjtBQUN6QixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sTUFBTSxJQUFJLE1BQU0sS0FBSztBQUFBLElBQ3pCLFlBQVk7QUFBQSxJQUNaLFdBQVcsU0FBUztBQUFBLElBQ3BCLGVBQWU7QUFBQSxJQUNmLGdCQUFnQjtBQUFBLElBQ2hCLGVBQWU7QUFBQSxFQUNqQjtBQUNBLE1BQUksSUFBSSxjQUFjLFNBQVMsR0FBRztBQUNoQyxRQUFJLFlBQVksU0FBUztBQUN6QixRQUFJLGFBQWE7QUFBQSxFQUNuQjtBQUNBLFFBQU0sT0FBdUIsRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hELE1BQUksTUFBTSxJQUFJO0FBQ2QsUUFBTSxPQUFPLFlBQVksR0FBRztBQUM1QixTQUFPO0FBQ1Q7QUFFQSxlQUFzQixpQkFBaUIsUUFBZ0IsT0FBOEI7QUFDbkYsUUFBTSxZQUFZLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztBQUNwRDtBQUlBLGVBQXNCLGdCQUFvRDtBQUN4RSxTQUFPLE9BQU8sWUFBWTtBQUM1QjtBQUVBLGVBQXNCLGFBQWEsUUFBMkM7QUFDNUUsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxTQUFPLElBQUksTUFBTSxLQUFLO0FBQ3hCO0FBRUEsZUFBc0IsYUFBYSxRQUFnQixLQUErQjtBQUNoRixRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLE1BQUksTUFBTSxJQUFJO0FBQ2QsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUVBLGVBQXNCLGVBQWUsUUFBK0I7QUFDbEUsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxTQUFPLElBQUksTUFBTTtBQUNqQixRQUFNLE9BQU8sY0FBYyxHQUFHO0FBQ2hDO0FBSUEsZUFBc0IsY0FBbUM7QUFDdkQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFFQSxlQUFzQixlQUFlLElBQW1DO0FBQ3RFLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsTUFBSSxRQUFRLEVBQUU7QUFDZCxNQUFJLElBQUksU0FBUyxrQkFBbUIsS0FBSSxTQUFTO0FBQ2pELFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsZ0JBQStCO0FBQ25ELFFBQU0sT0FBTyxZQUFZLENBQUMsQ0FBQztBQUM3QjtBQUlBLElBQU0sNkJBQTZCO0FBRW5DLGVBQXNCLDBCQUFvRDtBQUN4RSxTQUFPLE9BQU8sc0JBQXNCO0FBQ3RDO0FBRUEsZUFBc0IsNEJBQTRCLE1BQXNDO0FBQ3RGLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsUUFBTSxNQUFNLE1BQU0sd0JBQXdCO0FBQzFDLFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sT0FBd0IsQ0FBQztBQUMvQixhQUFXLE9BQU8sTUFBTTtBQUN0QixVQUFNLE1BQU0sR0FBRyxJQUFJLGVBQWUsWUFBWSxDQUFDLElBQUksSUFBSSxRQUFRO0FBQy9ELFFBQUksS0FBSyxJQUFJLEdBQUcsRUFBRztBQUNuQixTQUFLLElBQUksR0FBRztBQUNaLFNBQUssS0FBSyxHQUFHO0FBQUEsRUFDZjtBQUNBLGFBQVcsT0FBTyxLQUFLO0FBQ3JCLFVBQU0sTUFBTSxHQUFHLElBQUksZUFBZSxZQUFZLENBQUMsSUFBSSxJQUFJLFFBQVE7QUFDL0QsUUFBSSxLQUFLLElBQUksR0FBRyxFQUFHO0FBQ25CLFNBQUssSUFBSSxHQUFHO0FBQ1osU0FBSyxLQUFLLEdBQUc7QUFBQSxFQUNmO0FBQ0EsT0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFFBQVEsMEJBQTBCO0FBQzlELFFBQU0sT0FBTyx3QkFBd0IsSUFBSTtBQUMzQztBQUlBLGVBQXNCLG9CQUE2RTtBQUNqRyxTQUFPLE9BQU8sZ0JBQWdCO0FBQ2hDO0FBRUEsZUFBc0Isa0JBQ3BCLEtBQ2U7QUFDZixRQUFNLE9BQU8sa0JBQWtCLEdBQUc7QUFDcEM7QUFVTyxTQUFTLGNBQ2QsT0FDQSxVQUNBLFNBQ0EsUUFDQSxjQUF1QixPQUNmO0FBQ1IsU0FBTyxHQUFHLEtBQUssSUFBSSxRQUFRLElBQUksT0FBTyxJQUFJLE1BQU0sSUFBSSxjQUFjLE1BQU0sR0FBRztBQUM3RTtBQUdBLGVBQXNCLG9CQUFvQixVQUFtQztBQUMzRSxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsUUFBTSxTQUFTLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxRQUFRLEVBQUUsWUFBWTtBQUMzRCxNQUFJLFNBQVM7QUFDYixhQUFXLFVBQVUsT0FBTyxLQUFLLEdBQUcsR0FBRztBQUNyQyxVQUFNLFFBQVEsSUFBSSxNQUFNO0FBQ3hCLFFBQUksQ0FBQyxNQUFPO0FBQ1osZUFBVyxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDcEMsWUFBTSxJQUFJLE1BQU0sR0FBRztBQUNuQixVQUFJLEtBQUssRUFBRSxLQUFLLFFBQVE7QUFDdEIsZUFBTyxNQUFNLEdBQUc7QUFDaEIsa0JBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxLQUFLLEtBQUssRUFBRSxXQUFXLEVBQUcsUUFBTyxJQUFJLE1BQU07QUFBQSxFQUN4RDtBQUNBLE1BQUksU0FBUyxFQUFHLE9BQU0sa0JBQWtCLEdBQUc7QUFDM0MsU0FBTztBQUNUO0FBSUEsZUFBc0Isa0JBQXFEO0FBQ3pFLFNBQU8sT0FBTyxjQUFjO0FBQzlCO0FBRUEsZUFBc0Isb0JBQXFDO0FBQ3pELFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0IsZUFBZSxRQUFnQixTQUFnQztBQUNuRixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsUUFBTSxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDMUIsTUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUc7QUFDMUIsUUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBRSxNQUFNLElBQUk7QUFDWixVQUFNLE9BQU8sZ0JBQWdCLENBQUM7QUFBQSxFQUNoQztBQUNGO0FBRUEsZUFBc0IsZUFBZSxRQUFnQixTQUFnQztBQUNuRixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsUUFBTSxNQUFNLEVBQUUsTUFBTTtBQUNwQixNQUFJLENBQUMsSUFBSztBQUNWLFFBQU0sV0FBVyxJQUFJLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTztBQUNsRCxNQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNO0FBQUEsTUFDckMsR0FBRSxNQUFNLElBQUk7QUFDakIsUUFBTSxPQUFPLGdCQUFnQixDQUFDO0FBQ2hDO0FBRUEsZUFBc0Isb0JBR1o7QUFDUixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFHO0FBQUEsRUFDeEQ7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixxQkFBd0Q7QUFDNUUsU0FBTyxPQUFPLGlCQUFpQjtBQUNqQztBQUVBLGVBQXNCLHVCQUF3QztBQUM1RCxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxRQUFRO0FBQ1osYUFBVyxPQUFPLE9BQU8sT0FBTyxDQUFDLEVBQUcsVUFBUyxJQUFJO0FBQ2pELFNBQU87QUFDVDtBQUVBLGVBQXNCLGtCQUFrQixZQUEyQixTQUFnQztBQUNqRyxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsUUFBTSxTQUFTLGNBQWM7QUFDN0IsUUFBTSxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDMUIsTUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUc7QUFDMUIsUUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBRSxNQUFNLElBQUk7QUFDWixVQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFBQSxFQUNuQztBQUNGO0FBRUEsZUFBc0Isa0JBQWtCLFNBQWdDO0FBQ3RFLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFVBQVU7QUFDZCxhQUFXLFVBQVUsT0FBTyxLQUFLLENBQUMsR0FBRztBQUNuQyxVQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsVUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELFFBQUksU0FBUyxXQUFXLElBQUksUUFBUTtBQUNsQyxnQkFBVTtBQUNWLFVBQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxVQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLE1BQUksUUFBUyxPQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFDaEQ7QUFFQSxlQUFzQix1QkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLHFCQUF3RDtBQUM1RSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBRUEsZUFBc0IsdUJBQXdDO0FBQzVELFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0Isa0JBQWtCLFNBQW1DO0FBQ3pFLFFBQU0sT0FBTyxNQUFNLE9BQU8sZ0JBQWdCO0FBQzFDLFNBQU8sV0FBVztBQUNwQjtBQUVBLGVBQXNCLG1CQUFtQixTQUFnQztBQUN2RSxRQUFNLE9BQU8sTUFBTSxPQUFPLGdCQUFnQjtBQUMxQyxPQUFLLE9BQU8sS0FBSSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUN2QyxRQUFNLE9BQU8sa0JBQWtCLElBQUk7QUFDckM7QUFFQSxlQUFzQixrQkFBa0IsUUFBZ0IsU0FBZ0M7QUFDdEYsTUFBSSxNQUFNLGtCQUFrQixPQUFPLEVBQUc7QUFDdEMsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLFFBQU0sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzFCLE1BQUksQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHO0FBQzFCLFFBQUksS0FBSyxPQUFPO0FBQ2hCLE1BQUUsTUFBTSxJQUFJO0FBQ1osVUFBTSxPQUFPLG1CQUFtQixDQUFDO0FBQUEsRUFDbkM7QUFDRjtBQUVBLGVBQXNCLGtCQUFrQixTQUFnQztBQUN0RSxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxVQUFVO0FBQ2QsYUFBVyxVQUFVLE9BQU8sS0FBSyxDQUFDLEdBQUc7QUFDbkMsVUFBTSxNQUFNLEVBQUUsTUFBTTtBQUNwQixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sV0FBVyxJQUFJLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTztBQUNsRCxRQUFJLFNBQVMsV0FBVyxJQUFJLFFBQVE7QUFDbEMsZ0JBQVU7QUFDVixVQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNO0FBQUEsVUFDckMsR0FBRSxNQUFNLElBQUk7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFFBQVMsT0FBTSxPQUFPLG1CQUFtQixDQUFDO0FBQ2hEO0FBRUEsZUFBc0IsdUJBR1o7QUFDUixRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFHO0FBQUEsRUFDeEQ7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixZQUFZLFNBQW1DO0FBQ25FLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxhQUFXLFNBQVMsT0FBTyxPQUFPLEdBQUcsR0FBRztBQUN0QyxRQUFJLFNBQVMsV0FBVyxNQUFPLFFBQU87QUFBQSxFQUN4QztBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLG9CQUFpRDtBQUNyRSxTQUFPLE9BQU8sZ0JBQWdCO0FBQ2hDO0FBQ0EsZUFBc0Isa0JBQWtCLEdBQXNDO0FBQzVFLFFBQU0sT0FBTyxrQkFBa0IsQ0FBQztBQUNsQztBQUNBLGVBQXNCLHVCQUFvRDtBQUN4RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQXNDO0FBQy9FLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQUNBLGVBQXNCLHVCQUFvRDtBQUN4RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQXNDO0FBQy9FLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQUNBLGVBQXNCLHVCQUEwRDtBQUM5RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQTRDO0FBQ3JGLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQVlBLGVBQXNCLG9CQUFvQixVQU92QztBQUNELFFBQU0sWUFBWSxJQUFJLElBQUksQ0FBQyxHQUFHLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sYUFBYSxDQUFDLE1BQXVCLFVBQVUsSUFBSSxFQUFFLFlBQVksQ0FBQztBQUd4RSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksa0JBQWtCO0FBQ3RCLGFBQVcsS0FBSyxPQUFPLEtBQUssUUFBUSxHQUFHO0FBQ3JDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLFNBQVMsQ0FBQztBQUNqQix5QkFBbUI7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sWUFBWSxRQUFRO0FBR2pDLFFBQU0sVUFBVSxNQUFNLGNBQWM7QUFDcEMsTUFBSSxpQkFBaUI7QUFDckIsYUFBVyxLQUFLLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDcEMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sUUFBUSxDQUFDO0FBQ2hCLHdCQUFrQjtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxjQUFjLE9BQU87QUFHbEMsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLE1BQUksMEJBQTBCO0FBQzlCLGFBQVcsS0FBSyxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ2hDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLElBQUksQ0FBQztBQUNaLGlDQUEyQjtBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUNBLFFBQU0sa0JBQWtCLEdBQUc7QUFHM0IsUUFBTSxLQUFLLE1BQU0sZ0JBQWdCO0FBQ2pDLE1BQUksd0JBQXdCO0FBQzVCLGFBQVcsS0FBSyxPQUFPLEtBQUssRUFBRSxHQUFHO0FBQy9CLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLEdBQUcsQ0FBQztBQUNYLCtCQUF5QjtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxnQkFBZ0IsRUFBRTtBQUsvQixRQUFNLEtBQUssTUFBTSxtQkFBbUI7QUFDcEMsTUFBSSx1QkFBdUI7QUFDM0IsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLCtCQUF5QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDdEMsYUFBTyxHQUFHLENBQUM7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxtQkFBbUIsRUFBRTtBQUVsQyxRQUFNLEtBQUssTUFBTSxtQkFBbUI7QUFDcEMsTUFBSSx1QkFBdUI7QUFDM0IsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLCtCQUF5QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDdEMsYUFBTyxHQUFHLENBQUM7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxtQkFBbUIsRUFBRTtBQUVsQyxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBSUEsZUFBc0IsV0FBMEI7QUFDOUMsUUFBTSxRQUFRLFFBQVEsTUFBTSxNQUFNO0FBQ3BDOzs7QUNqcUJBLElBQUksWUFBNkM7QUFFMUMsU0FBUyxlQUFlLElBQWtDO0FBQy9ELGNBQVk7QUFDZDtBQUVBLFNBQVMsU0FBaUI7QUFDeEIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNoQztBQUVBLGVBQWUsS0FBSyxPQUFpQixLQUFhLFNBQWlEO0FBQ2pHLFFBQU0sS0FBZSxFQUFFLElBQUksT0FBTyxHQUFHLE9BQU8sS0FBSyxTQUFTLE9BQU8sT0FBTyxFQUFFO0FBRTFFLFFBQU0sT0FBTyxpQkFBaUIsTUFBTSxZQUFZLENBQUMsSUFBSSxHQUFHO0FBQ3hELE1BQUksVUFBVSxRQUFTLFNBQVEsTUFBTSxNQUFNLEdBQUcsT0FBTztBQUFBLFdBQzVDLFVBQVUsT0FBUSxTQUFRLEtBQUssTUFBTSxHQUFHLE9BQU87QUFBQSxNQUNuRCxTQUFRLElBQUksTUFBTSxHQUFHLE9BQU87QUFFakMsTUFBSTtBQUNGLFVBQU0sZUFBZSxFQUFFO0FBQUEsRUFDekIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDJDQUEyQyxHQUFHO0FBQUEsRUFDN0Q7QUFFQSxNQUFJO0FBQ0YsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCLFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUFFTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxNQUFNLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN2RixTQUFPLEtBQUssU0FBUyxLQUFLLE9BQU87QUFDbkM7QUFFTyxTQUFTLGNBQWMsS0FBeUQ7QUFDckYsTUFBSSxlQUFlLE9BQU87QUFDeEIsV0FBTyxFQUFFLFNBQVMsSUFBSSxTQUFTLE9BQU8sSUFBSSxTQUFTLEtBQUs7QUFBQSxFQUMxRDtBQUNBLE1BQUk7QUFDRixXQUFPLEVBQUUsU0FBUyxPQUFPLEdBQUcsR0FBRyxPQUFPLEtBQUs7QUFBQSxFQUM3QyxRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsdUJBQXVCLE9BQU8sS0FBSztBQUFBLEVBQ3ZEO0FBQ0Y7QUFPQSxTQUFTLE9BQU8sS0FBdUQ7QUFDckUsUUFBTSxNQUErQixDQUFDO0FBQ3RDLGFBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQ3hDLFFBQUksRUFBRSxZQUFZLEVBQUUsU0FBUyxPQUFPLEtBQUssRUFBRSxZQUFZLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtBQUMzRixVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1gsV0FBVyxPQUFPLE1BQU0sWUFBWSwrQkFBK0IsS0FBSyxDQUFDLEdBQUc7QUFDMUUsVUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLDZCQUE2Qix1QkFBdUI7QUFBQSxJQUN6RSxXQUFXLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxNQUFNO0FBQ25ELFVBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsSUFDOUIsT0FBTztBQUNMLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7OztBQ3ZFQSxJQUFNLFdBQVc7QUFDakIsSUFBTSxXQUFXO0FBK0JWLElBQU0sY0FBTixjQUEwQixNQUFNO0FBQUEsRUFDckM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBO0FBQUEsRUFFQSxZQUFZLE1BT1Q7QUFDRCxVQUFNLEtBQUssT0FBTztBQUNsQixTQUFLLE9BQU87QUFDWixTQUFLLFNBQVMsS0FBSztBQUNuQixTQUFLLE9BQU8sS0FBSztBQUNqQixTQUFLLFlBQVksS0FBSztBQUN0QixTQUFLLFdBQVcsS0FBSztBQUNyQixTQUFLLG1CQUFtQixLQUFLLG9CQUFvQjtBQUFBLEVBQ25EO0FBQ0Y7QUFFTyxJQUFNLGVBQU4sTUFBbUI7QUFBQSxFQUNQO0FBQUEsRUFFakIsWUFBWSxVQUFvQjtBQUM5QixTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBO0FBQUEsRUFHQSxNQUFNLFNBQTBCO0FBQzlCLFVBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDL0MsV0FBUSxJQUEyQixTQUFTO0FBQUEsRUFDOUM7QUFBQTtBQUFBLEVBR0EsTUFBTSxhQUFhLFFBQWtDO0FBQ25ELFFBQUk7QUFDRixZQUFNLEtBQUs7QUFBQSxRQUNUO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxtQkFBbUIsTUFBTSxDQUFDO0FBQUEsTUFDNUY7QUFDQSxhQUFPO0FBQUEsSUFDVCxTQUFTLEtBQUs7QUFDWixVQUFJLGVBQWUsZUFBZSxJQUFJLGFBQWEsWUFBYSxRQUFPO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFHQSxNQUFNLG1CQUEwRjtBQUM5RixVQUFNLEtBQUssTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQzlDLFVBQU0sT0FBTyxNQUFNLEtBQUssVUFBVSxPQUFPLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxFQUFFO0FBQzlGLFVBQU0sSUFBSTtBQUNWLFdBQU87QUFBQSxNQUNMLE9BQVEsR0FBeUI7QUFBQSxNQUNqQyxXQUFXLEVBQUU7QUFBQSxNQUNiLGdCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxvQkFBbUM7QUFDdkMsVUFBTSxPQUFPLE1BQU0sS0FBSyxjQUFjO0FBQ3RDLFVBQU0sS0FBSztBQUFBLE1BQ1Q7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxtQkFBbUIsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDdEc7QUFBQSxRQUNFLEtBQUssS0FBSztBQUFBLFFBQ1YsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLGFBQWEsWUFBNEM7QUFDN0QsVUFBTSxNQUFNLEdBQUcsUUFBUSxJQUFJLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFNBQVMsTUFBTSxJQUFJLFVBQVU7QUFDMUcsVUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDM0IsUUFBUTtBQUFBLE1BQ1IsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQUEsSUFDMUQsQ0FBQztBQUNELFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLFVBQVUsS0FBSyxXQUFXLFVBQVUsRUFBRTtBQUNwRSxXQUFPLElBQUksS0FBSztBQUFBLEVBQ2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sV0FBVyxNQUFzQztBQUNyRCxRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLFFBQ3JCO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQyxRQUFRLG1CQUFtQixLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDbEk7QUFDQSxZQUFNLElBQUk7QUFDVixhQUFPLEVBQUUsT0FBTztBQUFBLElBQ2xCLFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxRQUFRLE1BQThDO0FBQzFELFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sTUFBTSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQztBQUM1RixRQUFJLE1BQXFCLEtBQUssZUFBZTtBQUM3QyxVQUFNLGNBQWM7QUFFcEIsYUFBUyxVQUFVLEdBQUcsV0FBVyxhQUFhLFdBQVc7QUFDdkQsWUFBTSxPQUFnQztBQUFBLFFBQ3BDLFNBQVMsS0FBSztBQUFBLFFBQ2QsU0FBUyxLQUFLO0FBQUEsUUFDZCxRQUFRLEtBQUssU0FBUztBQUFBLE1BQ3hCO0FBQ0EsVUFBSSxJQUFLLE1BQUssTUFBTTtBQUNwQixVQUFJO0FBQ0YsY0FBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sS0FBSyxJQUFJO0FBQ2pELGNBQU0sTUFBTTtBQUNaLGVBQU8sRUFBRSxNQUFNLElBQUksUUFBUSxNQUFNLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLFFBQVEsU0FBUztBQUFBLE1BQ25GLFNBQVMsS0FBSztBQUNaLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFJLElBQUksV0FBVyxPQUFPLENBQUMsS0FBSztBQUU5QixnQkFBTSxNQUFNLEtBQUssV0FBVyxJQUFJO0FBQ2hDLGNBQUksQ0FBQyxJQUFLLE9BQU07QUFDaEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxDQUFDLElBQUksYUFBYSxZQUFZLFlBQWEsT0FBTTtBQUNyRCxjQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sSUFBSSxNQUFNLG1DQUFtQyxJQUFJLEVBQUU7QUFBQSxFQUMzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxNQUFNLFlBQVksTUFBc0Q7QUFDdEUsUUFBSSxLQUFLLE1BQU0sV0FBVyxFQUFHLE9BQU0sSUFBSSxNQUFNLGlDQUFpQztBQUM5RSxVQUFNLGNBQWM7QUFDcEIsUUFBSSxVQUFtQjtBQUV2QixhQUFTLFVBQVUsR0FBRyxXQUFXLGFBQWEsV0FBVztBQUN2RCxVQUFJO0FBQ0YsY0FBTSxRQUFRLE1BQU0sUUFBUTtBQUFBLFVBQzFCLEtBQUssTUFBTSxJQUFJLE9BQU8sU0FBUztBQUM3QixrQkFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLGNBQ3JCO0FBQUEsY0FDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxjQUNuRDtBQUFBLGdCQUNFLFNBQVMsS0FBSztBQUFBLGdCQUNkLFVBQVU7QUFBQSxjQUNaO0FBQUEsWUFDRjtBQUNBLG1CQUFPO0FBQUEsY0FDTCxNQUFNLEtBQUs7QUFBQSxjQUNYLEtBQU0sSUFBd0I7QUFBQSxZQUNoQztBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFFQSxjQUFNLE9BQU8sTUFBTSxLQUFLLGNBQWM7QUFDdEMsY0FBTSxPQUFPLE1BQU0sS0FBSztBQUFBLFVBQ3RCO0FBQUEsVUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxVQUNuRDtBQUFBLFlBQ0UsV0FBVyxLQUFLO0FBQUEsWUFDaEIsTUFBTSxNQUFNLElBQUksQ0FBQyxVQUFVO0FBQUEsY0FDekIsTUFBTSxLQUFLO0FBQUEsY0FDWCxNQUFNO0FBQUEsY0FDTixNQUFNO0FBQUEsY0FDTixLQUFLLEtBQUs7QUFBQSxZQUNaLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUNBLGNBQU0sVUFBVyxLQUF5QjtBQUMxQyxjQUFNLFNBQVMsTUFBTSxLQUFLO0FBQUEsVUFDeEI7QUFBQSxVQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLFVBQ25EO0FBQUEsWUFDRSxTQUFTLEtBQUs7QUFBQSxZQUNkLE1BQU07QUFBQSxZQUNOLFNBQVMsQ0FBQyxLQUFLLEdBQUc7QUFBQSxVQUNwQjtBQUFBLFFBQ0Y7QUFDQSxjQUFNLFlBQVk7QUFDbEIsWUFBSTtBQUNGLGdCQUFNLEtBQUs7QUFBQSxZQUNUO0FBQUEsWUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksbUJBQW1CLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLFlBQ3RHO0FBQUEsY0FDRSxLQUFLLFVBQVU7QUFBQSxjQUNmLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0YsU0FBUyxLQUFLO0FBQ1osY0FBSSxXQUFXLEdBQUcsS0FBSyxVQUFVLGFBQWE7QUFDNUMsc0JBQVU7QUFDVixrQkFBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFDbkM7QUFBQSxVQUNGO0FBQ0EsZ0JBQU07QUFBQSxRQUNSO0FBQ0EsZUFBTztBQUFBLFVBQ0wsV0FBVyxVQUFVO0FBQUEsVUFDckIsS0FBSyxVQUFVO0FBQUEsVUFDZixPQUFPLEtBQUssTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUk7QUFBQSxRQUMzQztBQUFBLE1BQ0YsU0FBUyxLQUFLO0FBQ1osa0JBQVU7QUFDVixZQUFJLEVBQUUsZUFBZSxhQUFjLE9BQU07QUFDekMsWUFBSyxDQUFDLElBQUksYUFBYSxDQUFDLFdBQVcsR0FBRyxLQUFNLFlBQVksWUFBYSxPQUFNO0FBQzNFLGNBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxtQkFBbUIsUUFBUSxVQUFVLElBQUksTUFBTSxpQ0FBaUM7QUFBQSxFQUN4RjtBQUFBLEVBRUEsTUFBYyxnQkFBMkQ7QUFDdkUsVUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLE1BQ3JCO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksa0JBQWtCLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLElBQ3ZHO0FBQ0EsVUFBTSxVQUFXLElBQW9DLE9BQU87QUFDNUQsVUFBTSxTQUFTLE1BQU0sS0FBSztBQUFBLE1BQ3hCO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksZ0JBQWdCLE9BQU87QUFBQSxJQUM1RTtBQUNBLFdBQU87QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLFNBQVUsT0FBcUMsS0FBSztBQUFBLElBQ3REO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBYyxVQUFVLFFBQWdCLE1BQWMsTUFBa0M7QUFDdEYsVUFBTSxNQUFNLEtBQUssV0FBVyxNQUFNLElBQUksT0FBTyxHQUFHLFFBQVEsR0FBRyxJQUFJO0FBQy9ELFVBQU0sT0FBb0I7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsU0FBUztBQUFBLFFBQ1AsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHO0FBQUEsUUFDMUMsUUFBUTtBQUFBLFFBQ1Isd0JBQXdCO0FBQUEsUUFDeEIsR0FBSSxPQUFPLEVBQUUsZ0JBQWdCLG1CQUFtQixJQUFJLENBQUM7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsR0FBSSxPQUFPLEVBQUUsTUFBTSxLQUFLLFVBQVUsSUFBSSxFQUFFLElBQUksQ0FBQztBQUFBLElBQy9DO0FBQ0EsUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLLElBQUk7QUFBQSxJQUM3QixTQUFTLFFBQVE7QUFDZixZQUFNLElBQUksWUFBWTtBQUFBLFFBQ3BCLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxRQUNOLFNBQVMsWUFBWSxjQUFjLE1BQU0sRUFBRSxPQUFPO0FBQUEsUUFDbEQsV0FBVztBQUFBLFFBQ1gsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFDQSxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxTQUFrQjtBQUN0QixVQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsUUFBSSxNQUFNO0FBQ1IsVUFBSTtBQUNGLGlCQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsTUFDMUIsUUFBUTtBQUNOLGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLG9CQUFvQixLQUFLLFFBQVEsR0FBRyxNQUFNLElBQUksSUFBSSxFQUFFO0FBQ2xGLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLFVBQVUsS0FBZSxPQUFxQztBQUMxRSxRQUFJLFNBQWtCO0FBQ3RCLFFBQUk7QUFDRixZQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsVUFBSSxLQUFNLFVBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxJQUNwQyxRQUFRO0FBQUEsSUFFUjtBQUNBLFdBQU8sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEtBQUs7QUFBQSxFQUNwRDtBQUFBLEVBRVEsb0JBQW9CLEtBQWUsTUFBZSxPQUE0QjtBQUNwRixVQUFNLE1BQ0osT0FBTyxTQUFTLFlBQVksUUFBUSxhQUFhLE9BQzdDLE9BQVEsS0FBOEIsT0FBTyxJQUM3QyxJQUFJO0FBQ1YsUUFBSSxXQUFvQztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUU1QyxZQUFNLE9BQU8sSUFBSSxRQUFRLElBQUksdUJBQXVCO0FBQ3BELFVBQUksU0FBUyxPQUFPLGNBQWMsS0FBSyxHQUFHLEdBQUc7QUFDM0MsbUJBQVc7QUFDWCxvQkFBWTtBQUFBLE1BQ2QsT0FBTztBQUNMLG1CQUFXO0FBQUEsTUFDYjtBQUFBLElBQ0YsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUNuRCxpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFVBQVUsS0FBSztBQUM1QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZCxXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkO0FBQ0EsV0FBTyxJQUFJLFlBQVk7QUFBQSxNQUNyQixRQUFRLElBQUk7QUFBQSxNQUNaO0FBQUEsTUFDQSxTQUFTLEdBQUcsS0FBSyxXQUFNLElBQUksTUFBTSxLQUFLLEdBQUc7QUFBQSxNQUN6QztBQUFBLE1BQ0E7QUFBQSxNQUNBLGtCQUFrQixhQUFhLGVBQWUsb0JBQW9CLElBQUksT0FBTyxJQUFJO0FBQUEsSUFDbkYsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQVFBLFNBQVMsb0JBQW9CLFNBQWlDO0FBQzVELFFBQU0sUUFBUSxRQUFRLElBQUksbUJBQW1CO0FBQzdDLE1BQUksT0FBTztBQUNULFVBQU0sSUFBSSxPQUFPLFNBQVMsT0FBTyxFQUFFO0FBQ25DLFFBQUksT0FBTyxTQUFTLENBQUMsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUFBLEVBQzFDO0FBQ0EsUUFBTSxhQUFhLFFBQVEsSUFBSSxhQUFhO0FBQzVDLE1BQUksWUFBWTtBQUNkLFVBQU0sUUFBUSxPQUFPLFNBQVMsWUFBWSxFQUFFO0FBQzVDLFFBQUksT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLEdBQUc7QUFDeEMsYUFBTyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSSxJQUFJO0FBQUEsSUFDekM7QUFDQSxVQUFNLFNBQVMsS0FBSyxNQUFNLFVBQVU7QUFDcEMsUUFBSSxPQUFPLFNBQVMsTUFBTSxFQUFHLFFBQU8sS0FBSyxNQUFNLFNBQVMsR0FBSTtBQUFBLEVBQzlEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLE1BQXNCO0FBRXhDLFNBQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJLGtCQUFrQixFQUFFLEtBQUssR0FBRztBQUN6RDtBQUVBLFNBQVMsVUFBVSxTQUFpQixLQUEwQjtBQUU1RCxRQUFNLE9BQU8sSUFBSSxhQUFhLGVBQWUsTUFBTztBQUNwRCxRQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQUc7QUFDN0MsU0FBTyxLQUFLLElBQUksS0FBUSxPQUFPLE1BQU0sVUFBVSxLQUFLLE1BQU07QUFDNUQ7QUFFQSxTQUFTLFdBQVcsS0FBa0M7QUFDcEQsU0FBTyxlQUFlLGVBQWUsSUFBSSxhQUFhO0FBQ3hEO0FBRUEsU0FBUyxNQUFNLElBQTJCO0FBQ3hDLFNBQU8sSUFBSSxRQUFRLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQzdDO0FBRU8sU0FBU0EsVUFBUyxPQUF1QjtBQUU5QyxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxLQUFLO0FBQzNDLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLFFBQU8sT0FBTyxhQUFhLENBQUM7QUFDbEQsU0FBTyxLQUFLLEdBQUc7QUFDakI7OztBQzNYQSxJQUFNLGNBQWM7QUFTcEIsSUFBTSx1QkFBNEMsb0JBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUVoRSxTQUFTLFVBQVUsU0FBa0IsS0FBd0M7QUFDbEYsUUFBTSxZQUFZLGNBQWMsT0FBTztBQUN2QyxRQUFNLFNBQTJCLENBQUM7QUFDbEMsUUFBTSxvQkFBd0MsQ0FBQztBQUMvQyxRQUFNLFdBQXFCLENBQUM7QUFDNUIsUUFBTSxRQUFRLG9CQUFJLElBQVk7QUFDOUIsUUFBTSxhQUFhLG9CQUFJLElBQTJCO0FBQ2xELFFBQU0sa0JBQWtCLHFCQUFxQixJQUFJLElBQUksUUFBUTtBQUM3RCxhQUFXLE9BQU8sV0FBVztBQUMzQixRQUFJO0FBQ0YsWUFBTSxjQUFjLHFCQUFxQixLQUFLLEdBQUc7QUFDakQsVUFBSSxhQUFhO0FBQ2YsMEJBQWtCLEtBQUssV0FBVztBQUNsQyxpQkFBUyxLQUFLLFlBQVksUUFBUTtBQUNsQyxjQUFNLElBQUksWUFBWSxRQUFRO0FBQzlCO0FBQUEsTUFDRjtBQUNBLFlBQU0sSUFBSSxXQUFXLEtBQUssR0FBRztBQUM3QixVQUFJLENBQUMsR0FBRztBQUNOLFlBQUksaUJBQWlCO0FBSW5CLGdCQUFNLFVBQVUsWUFBWSxHQUFHO0FBQy9CLGNBQUksUUFBUyxZQUFXLElBQUksUUFBUSxVQUFVLFFBQVEsV0FBVztBQUFBLFFBQ25FO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsZUFBUyxLQUFLLEVBQUUsUUFBUTtBQUN4QixZQUFNLElBQUksRUFBRSxRQUFRO0FBQ3BCLFVBQUksSUFBSSxlQUFlLFNBQVMsS0FBSyxJQUFJLGVBQWUsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEdBQUc7QUFDM0YsZUFBTyxLQUFLLENBQUM7QUFBQSxNQUNmO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFHQSxRQUFNLGNBQXVFLENBQUM7QUFDOUUsYUFBVyxDQUFDLElBQUksSUFBSSxLQUFLLFlBQVk7QUFDbkMsUUFBSSxNQUFNLElBQUksRUFBRSxFQUFHO0FBQ25CLGdCQUFZLEtBQUssRUFBRSxVQUFVLElBQUksYUFBYSxLQUFLLENBQUM7QUFBQSxFQUN0RDtBQUNBLFNBQU8sRUFBRSxRQUFRLGNBQWMsVUFBVSxvQkFBb0IsbUJBQW1CLFlBQVk7QUFDOUY7QUFFQSxTQUFTLHFCQUFxQixNQUFlLEtBQWdEO0FBQzNGLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFFOUMsUUFBTSxVQUNKLFVBQVUsRUFBRSxPQUFPLEtBQ25CLG9CQUFvQixJQUFJLE1BQ3ZCLElBQUksWUFBWSxvQkFBb0IsSUFBSSxTQUFTLElBQUk7QUFDeEQsTUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEtBQUssT0FBTyxFQUFHLFFBQU87QUFFbkQsUUFBTSxrQkFBa0Isa0JBQWtCLElBQUk7QUFDOUMsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsZ0JBQ0Usd0JBQXdCLE1BQU0sT0FBTyxNQUNwQyxJQUFJLFlBQVksbUJBQW1CLElBQUksV0FBVyxPQUFPLElBQUk7QUFBQSxJQUNoRSx5QkFBeUIsSUFBSTtBQUFBLElBQzdCLG9CQUFvQiwwQkFBMEIsZUFBZTtBQUFBLElBQzdELGtCQUFrQjtBQUFBLElBQ2xCLHdCQUF3QixJQUFJLGFBQWE7QUFBQSxFQUMzQztBQUNGO0FBRUEsU0FBUyxvQkFBb0IsTUFBOEI7QUFDekQsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sS0FBSyxvQkFBb0IsR0FBRztBQUNsQyxVQUFJLEdBQUksUUFBTztBQUNmO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLG9CQUFvQixRQUErQjtBQUMxRCxNQUFJO0FBQ0YsVUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLGdCQUFnQjtBQUM1QyxRQUFJLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxjQUFlLFFBQU87QUFDdkUsVUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLG9EQUFvRDtBQUNyRixXQUFPLFFBQVEsQ0FBQyxLQUFLO0FBQUEsRUFDdkIsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixNQUE4QjtBQUN2RCxRQUFNLFVBQW9CLENBQUM7QUFDM0IsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sVUFBVSxJQUFJLEtBQUs7QUFDekIsVUFDRSxRQUFRLFVBQVUsS0FDbEIsQ0FBQyxRQUFRLFdBQVcsU0FBUyxLQUM3QixDQUFDLFFBQVEsV0FBVyxVQUFVLEdBQzlCO0FBQ0EsZ0JBQVEsS0FBSyxPQUFPO0FBQUEsTUFDdEI7QUFDQTtBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVTtBQUM3QyxRQUFJLEtBQUssSUFBSSxHQUFhLEVBQUc7QUFDN0IsU0FBSyxJQUFJLEdBQWE7QUFDdEIsUUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQ3RCLGlCQUFXLEtBQUssSUFBSyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ25DLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxHQUE4QixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDN0U7QUFBQSxFQUNGO0FBQ0EsUUFBTSxZQUFZLFFBQVE7QUFBQSxJQUFLLENBQUMsTUFDOUIsOEVBQThFLEtBQUssQ0FBQztBQUFBLEVBQ3RGO0FBQ0EsU0FBTyxhQUFhLFFBQVEsQ0FBQyxLQUFLO0FBQ3BDO0FBRUEsU0FBUywwQkFBMEIsTUFBb0M7QUFDckUsTUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixNQUFJLHdCQUF3QixLQUFLLElBQUksRUFBRyxRQUFPO0FBQy9DLE1BQUksZ0JBQWdCLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDdkMsTUFBSSx1QkFBdUIsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUM5QyxNQUFJLGlCQUFpQixLQUFLLElBQUksRUFBRyxRQUFPO0FBQ3hDLE1BQUksaUNBQWlDLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDeEQsU0FBTztBQUNUO0FBRUEsU0FBUyxZQUFZLE1BQXdFO0FBQzNGLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBR1YsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFHOUMsUUFBTSxLQUFLLEVBQUU7QUFDYixNQUFJLE9BQU8sV0FBVyxPQUFPLGdDQUFnQyxDQUFDLElBQUksRUFBRSxNQUFNLEdBQUc7QUFDM0UsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLFNBQ0gsT0FBTyxFQUFFLFlBQVksWUFBWSxFQUFFLFdBQ25DLE9BQU8sSUFBSSxFQUFFLFlBQVksR0FBRyxXQUFXLFlBQ3JDLElBQUksSUFBSSxFQUFFLFlBQVksR0FBRyxNQUFNLEdBQUc7QUFDdkMsTUFBSSxPQUFPLFdBQVcsWUFBWSxDQUFDLFlBQVksS0FBSyxNQUFNLEVBQUcsUUFBTztBQUNwRSxRQUFNLGFBQWEsZUFBZSxNQUFNLE1BQU07QUFDOUMsTUFBSSxDQUFDLFdBQVksUUFBTztBQUN4QixTQUFPLEVBQUUsVUFBVSxRQUFRLGFBQWEsV0FBVztBQUNyRDtBQUVBLFNBQVMsZUFBZSxNQUFlLFNBQWdDO0FBQ3JFLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsUUFBTSxhQUFhLElBQUksSUFBSSxJQUFJLEVBQUUsSUFBSSxHQUFHLFlBQVksR0FBRyxNQUFNO0FBQzdELFNBQ0UsVUFBVSxJQUFJLFlBQVksSUFBSSxHQUFHLFdBQVcsS0FDNUMsVUFBVSxJQUFJLFlBQVksTUFBTSxHQUFHLFdBQVcsS0FDOUMsVUFBVSxJQUFJLEVBQUUsTUFBTSxHQUFHLFdBQVcsS0FDcEMsd0JBQXdCLE1BQU0sT0FBTztBQUV6QztBQUVBLFNBQVMsd0JBQXdCLE1BQWUsU0FBZ0M7QUFDOUUsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sU0FBUyxtQkFBbUIsS0FBSyxPQUFPO0FBQzlDLFVBQUksT0FBUSxRQUFPO0FBQ25CO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLG1CQUFtQixRQUFnQixTQUFnQztBQUMxRSxNQUFJO0FBQ0YsVUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLGdCQUFnQjtBQUM1QyxRQUFJLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxjQUFlLFFBQU87QUFDdkUsVUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLHNEQUFzRDtBQUN2RixRQUFJLENBQUMsU0FBUyxNQUFNLENBQUMsTUFBTSxRQUFTLFFBQU87QUFDM0MsV0FBTyxNQUFNLENBQUMsS0FBSztBQUFBLEVBQ3JCLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxjQUFjQyxNQUF5QjtBQUs5QyxRQUFNLE1BQWlCLENBQUM7QUFDeEIsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQ0EsSUFBRztBQUM3QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sT0FBTyxNQUFNLElBQUk7QUFDdkIsUUFBSSxTQUFTLFFBQVEsU0FBUyxPQUFXO0FBQ3pDLFFBQUksT0FBTyxTQUFTLFNBQVU7QUFDOUIsUUFBSSxLQUFLLElBQUksSUFBYyxFQUFHO0FBQzlCLFNBQUssSUFBSSxJQUFjO0FBRXZCLFFBQUksZUFBZSxJQUFJLEdBQUc7QUFDeEIsVUFBSSxLQUFLLFlBQVksSUFBSSxDQUFDO0FBQUEsSUFDNUI7QUFDQSxRQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDdkIsaUJBQVcsS0FBSyxLQUFNLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDcEMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLElBQStCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM5RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGVBQWUsTUFBZ0Q7QUFDdEUsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLFdBQVcsRUFBRTtBQUNuQixNQUNFLGFBQWEsV0FDYixhQUFhLGdDQUNiLGFBQWEsa0JBQ2I7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQU8sT0FBTyxFQUFFLFlBQVksWUFBWSxPQUFPLEVBQUUsV0FBVyxZQUFZLEVBQUUsV0FBVztBQUN2RjtBQUVBLFNBQVMsWUFBWSxNQUF3RDtBQUMzRSxNQUFJLEtBQUssZUFBZSxnQ0FBZ0MsT0FBTyxLQUFLLFVBQVUsVUFBVTtBQUN0RixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLEtBQWMsS0FBOEM7QUFDOUUsTUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLEtBQU0sUUFBTztBQUNwRCxRQUFNLElBQUk7QUFFVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUU5QyxRQUFNLFNBQVMsVUFBVSxFQUFFLE9BQU87QUFLbEMsUUFBTSxTQUFTLElBQUksRUFBRSxNQUFNLEtBQUssQ0FBQztBQUNqQyxNQUFJLENBQUMsT0FBUSxRQUFPO0FBRXBCLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxJQUFJLE1BQU0sWUFBWSxHQUFHLE1BQU07QUFHdEQsUUFBTSxjQUFjLElBQUksWUFBWSxJQUFJO0FBQ3hDLFFBQU0sYUFBYSxJQUFJLFlBQVksTUFBTTtBQUN6QyxRQUFNLGdCQUFnQixJQUFJLFlBQVksTUFBTTtBQUM1QyxRQUFNLFNBQ0osVUFBVSxhQUFhLFdBQVcsS0FDbEMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxPQUFPLFdBQVc7QUFDOUIsUUFBTSxZQUNKLFVBQVUsWUFBWSxPQUFPLEtBQzdCLFVBQVUsWUFBWSxNQUFNLEtBQzVCLFVBQVUsT0FBTyxXQUFXO0FBQzlCLE1BQUksQ0FBQyxVQUFVLENBQUMsVUFBVyxRQUFPO0FBTWxDLFFBQU0sU0FBUyxvQkFBb0IsWUFBWSxhQUFhLFlBQVksYUFBYTtBQUVyRixRQUFNLFlBQVksSUFBSSxJQUFJLElBQUksRUFBRSxVQUFVLEdBQUcsa0JBQWtCLEdBQUcsTUFBTTtBQUN4RSxRQUFNLGVBQWUsVUFBVSxXQUFXLElBQUk7QUFDOUMsUUFBTSxpQkFBaUIsVUFBVSxPQUFPLFNBQVMsS0FBSztBQUN0RCxRQUFNLE9BQU8sZ0JBQWdCO0FBQzdCLFFBQU0sY0FBYyxpQkFBaUIsV0FBVyxRQUFRLGNBQWM7QUFDdEUsUUFBTSxnQkFBZ0IscUJBQXFCLEdBQUcsUUFBUSxJQUFJLFVBQVU7QUFFcEUsUUFBTSxXQUFXLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQztBQUMxQyxRQUFNLG1CQUFtQixJQUFJLFdBQVcsVUFBVTtBQUNsRCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxPQUFPLFlBQVksb0JBQW9CLFFBQVE7QUFDckQsUUFBTSxRQUFRLGFBQWEsTUFBTTtBQUVqQyxRQUFNLFlBQVksa0JBQWtCLEdBQUcsTUFBTTtBQUk3QyxRQUFNLFdBQ0osaUJBQWlCLFVBQVUsT0FBTyxVQUFVLENBQUMsS0FBSyxpQkFBaUIsVUFBVSxFQUFFLFVBQVUsQ0FBQztBQUM1RixNQUFJLENBQUMsU0FBVSxRQUFPO0FBRXRCLFFBQU0sUUFBUSxJQUFJLEVBQUUsS0FBSztBQUN6QixRQUFNLFlBQVksVUFBVSxPQUFPLEtBQUssS0FBSyxVQUFVLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFFOUUsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUMxQixRQUFNLFFBQVEsSUFBSSxPQUFPLEtBQUs7QUFFOUIsUUFBTSxRQUF3QjtBQUFBLElBQzVCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLFdBQVc7QUFBQSxJQUNYLG1CQUFtQixJQUFJO0FBQUEsSUFDdkIsY0FBYyxJQUFJO0FBQUEsSUFDbEIsc0JBQXNCO0FBQUEsSUFDdEIseUJBQXlCO0FBQUEsSUFDekIsb0JBQW9CO0FBQUEsSUFDcEIsa0JBQWtCO0FBQUEsSUFDbEIsd0JBQXdCO0FBQUEsSUFDeEIsV0FBVyxHQUFHLGdCQUFnQixJQUFJLE1BQU0sV0FBVyxNQUFNO0FBQUEsSUFDekQsWUFBWTtBQUFBLElBQ1osaUJBQWlCLFVBQVUsT0FBTyxtQkFBbUI7QUFBQSxJQUNyRCxtQkFBbUIsVUFBVSxPQUFPLHlCQUF5QjtBQUFBLElBQzdELGtCQUFrQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDMUQscUJBQXFCLFVBQVUsT0FBTyx1QkFBdUI7QUFBQSxJQUM3RCxpQkFBaUIsVUFBVSxPQUFPLG9CQUFvQjtBQUFBLElBQ3RELG9CQUFvQjtBQUFBLE1BQ2xCLElBQUksSUFBSSxPQUFPLHVCQUF1QixHQUFHLE1BQU0sR0FBRyxXQUMvQyxPQUFtQztBQUFBLElBQ3hDO0FBQUEsSUFDQTtBQUFBLElBQ0EsZUFBZSxpQkFBaUIsTUFBTSxJQUFJO0FBQUEsSUFDMUMsTUFBTSxVQUFVLE9BQU8sSUFBSTtBQUFBLElBQzNCLG9CQUFvQixXQUFXLE9BQU8sa0JBQWtCO0FBQUEsSUFDeEQsUUFBUSxVQUFVLE9BQU8sTUFBTSxLQUFLLFVBQVUsRUFBRSxNQUFNO0FBQUEsSUFDdEQsaUJBQWlCLFVBQVUsT0FBTyxTQUFTO0FBQUEsSUFDM0M7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDM0MsZUFBZSxVQUFVLE9BQU8sYUFBYTtBQUFBLElBQzdDLGFBQWEsVUFBVSxPQUFPLFdBQVc7QUFBQSxJQUN6QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsWUFBWTtBQUFBLElBQ1osZ0JBQWdCLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDL0Msb0JBQW9CO0FBQUEsTUFDbEI7QUFBQSxRQUNFLGFBQWEsSUFBSTtBQUFBLFFBQ2pCLE9BQU8sVUFBVSxPQUFPLGNBQWM7QUFBQSxRQUN0QyxVQUFVLFVBQVUsT0FBTyxhQUFhO0FBQUEsUUFDeEMsU0FBUyxVQUFVLE9BQU8sV0FBVztBQUFBLFFBQ3JDLFFBQVEsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNwQyxPQUFPO0FBQUEsUUFDUCxXQUFXLFVBQVUsT0FBTyxjQUFjO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLElBQ0EsZ0JBQWdCO0FBQUEsSUFDaEIsY0FBYztBQUFBLElBQ2QsYUFBYTtBQUFBLElBQ2Isc0JBQXNCO0FBQUEsSUFDdEIsZ0JBQWdCO0FBQUEsSUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxJQUNwQixnQkFBZ0I7QUFBQSxFQUNsQjtBQUVBLFNBQU87QUFDVDtBQUVBLFNBQVMsa0JBQWtCLEdBQTRCLFFBQTRDO0FBQ2pHLE1BQUksT0FBTywyQkFBMkIsT0FBTyx3QkFBeUIsUUFBTztBQUM3RSxNQUFJLE9BQU8sMEJBQTJCLFFBQU87QUFDN0MsTUFBSSxPQUFPLG9CQUFvQixRQUFRLE9BQU8scUJBQXNCLFFBQU87QUFDM0UsTUFBSSxFQUFFLGVBQWUsOEJBQThCO0FBQUEsRUFFbkQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxVQUFVLElBQUksT0FBUSxFQUF3QixJQUFJLElBQUk7QUFBQSxFQUN0RixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixJQUMzQyxPQUFRLEVBQStCLFdBQVcsSUFDbEQ7QUFBQSxFQUNOLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxZQUFZLFVBQWdEO0FBQ25FLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxRQUFNLE1BQW1CLENBQUM7QUFDMUIsYUFBVyxLQUFLLEtBQUs7QUFDbkIsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU07QUFDekMsVUFBTSxJQUFJO0FBQ1YsVUFBTSxRQUFRLFVBQVUsRUFBRSxHQUFHO0FBQzdCLFVBQU0sV0FBVyxVQUFVLEVBQUUsWUFBWTtBQUN6QyxVQUFNLFVBQVUsVUFBVSxFQUFFLFdBQVc7QUFDdkMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFVO0FBQ3pCLFFBQUksS0FBSyxFQUFFLE9BQU8sVUFBVSxTQUFTLFdBQVcsU0FBUyxDQUFDO0FBQUEsRUFDNUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGFBQWEsUUFBOEM7QUFDbEUsUUFBTSxXQUFXLElBQUksT0FBTyxpQkFBaUI7QUFDN0MsUUFBTSxVQUFVLFdBQVcsUUFBUSxTQUFTLEtBQUssSUFBSSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxRQUFRLElBQUksT0FBTyxRQUFRLEdBQUcsS0FBSztBQUNuRCxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFNBQVMsQ0FBQyxHQUFHLFNBQVMsR0FBRyxPQUFPLEVBQUUsT0FBTyxDQUFDLE1BQU07QUFDcEQsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU0sUUFBTztBQUNoRCxVQUFNLEtBQ0osVUFBVyxFQUE4QixTQUFTLEtBQ2xELFVBQVcsRUFBOEIsTUFBTTtBQUNqRCxRQUFJLENBQUMsR0FBSSxRQUFPO0FBQ2hCLFFBQUksS0FBSyxJQUFJLEVBQUUsRUFBRyxRQUFPO0FBQ3pCLFNBQUssSUFBSSxFQUFFO0FBQ1gsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNELFNBQU8sT0FBTyxJQUFJLENBQUMsUUFBUSxXQUFXLEdBQThCLENBQUM7QUFDdkU7QUFFQSxTQUFTLFdBQVcsR0FBdUM7QUFDekQsUUFBTSxPQUFPLFVBQVUsRUFBRSxJQUFJO0FBQzdCLFFBQU0sV0FBVyxnQkFBZ0IsR0FBRyxJQUFJO0FBQ3hDLFFBQU1DLFFBQU8sSUFBSSxFQUFFLGFBQWE7QUFDaEMsUUFBTSxZQUFZLElBQUksRUFBRSxVQUFVO0FBQ2xDLFFBQU0sYUFBYSxVQUFVLFdBQVcsZUFBZTtBQUN2RCxRQUFNLFVBQVUsVUFBVSxFQUFFLFlBQVk7QUFDeEMsUUFBTSxVQUNKLFVBQVUsRUFBRSxTQUFTLEtBQ3JCLFVBQVUsRUFBRSxNQUFNLEtBQ2xCLEdBQUcsUUFBUSxPQUFPLElBQUksS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDM0QsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsWUFBYSxRQUFRO0FBQUEsSUFDckIsY0FBYyxZQUFZO0FBQUEsSUFDMUIsbUJBQW1CO0FBQUEsSUFDbkIsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsY0FBYyxlQUFlLE9BQU8sYUFBYSxNQUFPO0FBQUEsSUFDeEQsT0FBTyxVQUFVQSxPQUFNLEtBQUs7QUFBQSxJQUM1QixRQUFRLFVBQVVBLE9BQU0sTUFBTTtBQUFBLElBQzlCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLGtCQUFrQjtBQUFBLElBQ2xCLGlCQUFpQjtBQUFBLEVBQ25CO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixHQUE0QixNQUFvQztBQUN2RixNQUFJLFNBQVMsUUFBUyxRQUFPLFVBQVUsRUFBRSxlQUFlLEtBQUssVUFBVSxFQUFFLFNBQVM7QUFDbEYsUUFBTSxXQUFXLFFBQVEsSUFBSSxFQUFFLFVBQVUsR0FBRyxRQUFRO0FBQ3BELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxVQUFVLEVBQUUsZUFBZTtBQUU3RCxNQUFJLE9BQWdEO0FBQ3BELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sS0FBSyxVQUFVLEVBQUUsWUFBWTtBQUNuQyxVQUFNLE1BQU0sVUFBVSxFQUFFLEdBQUc7QUFDM0IsUUFBSSxDQUFDLElBQUs7QUFDVixRQUFJLE9BQU8sYUFBYTtBQUN0QixZQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sS0FBSztBQUNuQyxVQUFJLENBQUMsUUFBUSxLQUFLLEtBQUssUUFBUyxRQUFPLEVBQUUsS0FBSyxTQUFTLEdBQUc7QUFBQSxJQUM1RCxXQUFXLENBQUMsTUFBTTtBQUVoQixhQUFPLEVBQUUsS0FBSyxTQUFTLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLE1BQU0sT0FBTztBQUN0QjtBQUVBLFNBQVMsaUJBQWlCLE1BQWMsTUFBMkI7QUFDakUsTUFBSSxLQUFLLFdBQVcsRUFBRyxRQUFPO0FBQzlCLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLE9BQU0sSUFBSSxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRO0FBQzlELFNBQU87QUFDVDtBQUVBLFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELE1BQUksQ0FBQyxFQUFHLFFBQU87QUFFZixRQUFNLElBQUksSUFBSSxLQUFLLENBQUM7QUFDcEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPO0FBQ3RDLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLFNBQU8sT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLElBQUksSUFBSTtBQUNyRDtBQUNBLFNBQVMsV0FBVyxHQUE0QjtBQUM5QyxTQUFPLE9BQU8sTUFBTSxZQUFZLElBQUk7QUFDdEM7QUFDQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFDeEQsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxVQUFNLElBQUksT0FBTyxDQUFDO0FBQ2xCLFFBQUksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQUEsRUFDakM7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFVBQVUsR0FBb0I7QUFDckMsU0FBTyxVQUFVLENBQUMsS0FBSztBQUN6QjtBQUNBLFNBQVMsSUFBSSxHQUE0QztBQUN2RCxTQUFPLE9BQU8sTUFBTSxZQUFZLE1BQU0sUUFBUSxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQ3pELElBQ0Q7QUFDTjtBQUNBLFNBQVMsUUFBUSxHQUF1QjtBQUN0QyxTQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDO0FBQ2pDO0FBd0JBLFNBQVMsaUJBQ1AsV0FDQSxRQUNBLFVBQ1M7QUFDVCxNQUFJLFVBQVcsUUFBTztBQUN0QixNQUFJLENBQUMsU0FBVSxRQUFPO0FBQ3RCLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUTtBQUNwQyxRQUFNLE9BQU8sV0FBVyxTQUFTLE9BQU87QUFDeEMsTUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGVBQVcsS0FBSyxNQUFNO0FBQ3BCLFVBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFlBQU0sTUFBTyxFQUE4QjtBQUkzQyxVQUFJLE9BQU8sUUFBUSxZQUFZLHdCQUF3QixLQUFLLEdBQUcsR0FBRztBQUNoRSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBd0JPLFNBQVMsY0FDZCxRQUNBLFVBQ0EsY0FBbUMsb0JBQUksSUFBSSxHQUN6QjtBQUNsQixNQUFJLFNBQVMsU0FBUyxLQUFLLFlBQVksU0FBUyxFQUFHLFFBQU87QUFLMUQsUUFBTSxnQkFBZ0Isb0JBQUksSUFBWTtBQUN0QyxRQUFNLG1CQUFtQixvQkFBSSxJQUFZO0FBQ3pDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxFQUFHO0FBQ25ELHFCQUFpQixJQUFJLEVBQUUsUUFBUTtBQUMvQixRQUFJLEVBQUUsZ0JBQWlCLGVBQWMsSUFBSSxFQUFFLGVBQWU7QUFDMUQsUUFBSSxFQUFFLG1CQUFvQixlQUFjLElBQUksRUFBRSxrQkFBa0I7QUFDaEUsUUFBSSxFQUFFLGtCQUFtQixlQUFjLElBQUksRUFBRSxpQkFBaUI7QUFBQSxFQUNoRTtBQUNBLFNBQU8sT0FBTyxPQUFPLENBQUMsTUFBTTtBQUMxQixVQUFNLElBQUksRUFBRSxlQUFlLFlBQVk7QUFDdkMsUUFBSSxTQUFTLElBQUksQ0FBQyxFQUFHLFFBQU87QUFDNUIsUUFBSSxZQUFZLElBQUksQ0FBQyxFQUFHLFFBQU87QUFFL0IsUUFBSSxjQUFjLElBQUksRUFBRSxRQUFRLEVBQUcsUUFBTztBQUkxQyxRQUFJLEVBQUUsbUJBQW1CLGlCQUFpQixJQUFJLEVBQUUsZUFBZSxFQUFHLFFBQU87QUFDekUsUUFBSSxFQUFFLHFCQUFxQixpQkFBaUIsSUFBSSxFQUFFLGlCQUFpQixFQUFHLFFBQU87QUFFN0UsUUFBSSxFQUFFLG9CQUFvQixTQUFTLElBQUksRUFBRSxpQkFBaUIsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUNqRixlQUFXLEtBQUssRUFBRSxVQUFVO0FBQzFCLFVBQUksU0FBUyxJQUFJLEVBQUUsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUFBLElBQzVDO0FBQ0EsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNIO0FBU0EsU0FBUyxxQkFDUCxHQUNBLFFBQ0EsWUFDc0I7QUFDdEIsUUFBTSxRQUFRLElBQUksRUFBRSxlQUFlLEtBQUssSUFBSSxPQUFPLGVBQWU7QUFDbEUsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixRQUFNLFdBQVcsSUFBSSxNQUFNLFFBQVE7QUFDbkMsUUFBTSxPQUFPLElBQUksTUFBTSxJQUFJO0FBQzNCLFFBQU0sVUFBVSxVQUFVLFVBQVUsSUFBSTtBQUN4QyxRQUFNLFFBQVEsVUFBVSxNQUFNLEtBQUs7QUFDbkMsUUFBTSxhQUFhLFVBQVUsTUFBTSxVQUFVO0FBQzdDLFFBQU0saUJBQWlCLFVBQVUsTUFBTSxjQUFjO0FBQ3JELFFBQU0sU0FBUyxVQUFVLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPO0FBRWpFLE1BQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQVEsUUFBTztBQUMxQyxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVDtBQUFBLElBQ0EsYUFBYTtBQUFBLElBQ2I7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLElBQ2pCLGFBQWE7QUFBQSxFQUNmO0FBQ0Y7QUFPQSxTQUFTLG9CQUNQLFlBQ0EsYUFDQSxZQUNBLGVBQ2M7QUFDZCxRQUFNLGVBQWUsSUFBSSxZQUFZLFlBQVk7QUFDakQsU0FBTztBQUFBLElBQ0wsY0FDRSxVQUFVLGFBQWEsSUFBSSxLQUFLLFVBQVUsWUFBWSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUk7QUFBQSxJQUMzRixZQUNFLFVBQVUsZUFBZSxTQUFTLEtBQ2xDLFVBQVUsWUFBWSx1QkFBdUIsS0FDN0MsVUFBVSxZQUFZLHVCQUF1QjtBQUFBLElBQy9DLFVBQVUsV0FBVyxjQUFjLFFBQVEsS0FBSyxXQUFXLFlBQVksUUFBUTtBQUFBLElBQy9FLGtCQUFrQixXQUFXLFlBQVksZ0JBQWdCO0FBQUEsSUFDekQsZUFBZSxVQUFVLGNBQWMsYUFBYSxLQUFLLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDNUYsYUFBYSxVQUFVLFlBQVksV0FBVztBQUFBLElBQzlDLFVBQVUsVUFBVSxJQUFJLFlBQVksUUFBUSxHQUFHLFFBQVEsS0FBSyxVQUFVLFlBQVksUUFBUTtBQUFBLElBQzFGLEtBQUssVUFBVSxZQUFZLEdBQUc7QUFBQSxJQUM5QixpQkFBaUIsVUFBVSxZQUFZLGVBQWU7QUFBQSxJQUN0RCxlQUFlLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDbEQsZ0JBQWdCLFVBQVUsWUFBWSxjQUFjO0FBQUEsSUFDcEQsb0JBQ0UsaUJBQWlCLFVBQVUsYUFBYSxVQUFVLENBQUMsS0FDbkQsaUJBQWlCLFVBQVUsWUFBWSxVQUFVLENBQUM7QUFBQSxJQUNwRCxXQUFXLFdBQVcsWUFBWSxTQUFTO0FBQUEsRUFDN0M7QUFDRjtBQU9BLFNBQVMsWUFBWSxHQUE4QztBQUNqRSxRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksTUFBTSxNQUFNO0FBQ25DLE1BQUksQ0FBQyxXQUFZLFFBQU87QUFDeEIsUUFBTSxXQUFXLFdBQVc7QUFDNUIsUUFBTSxRQUFpQyxDQUFDO0FBQ3hDLE1BQUksTUFBTSxRQUFRLFFBQVEsR0FBRztBQUMzQixlQUFXLE1BQU0sVUFBVTtBQUN6QixVQUFJLE9BQU8sT0FBTyxZQUFZLE9BQU8sS0FBTTtBQUMzQyxZQUFNLElBQUk7QUFDVixZQUFNLElBQUksVUFBVSxFQUFFLEdBQUc7QUFDekIsWUFBTSxJQUFJLElBQUksRUFBRSxLQUFLO0FBQ3JCLFVBQUksQ0FBQyxLQUFLLENBQUMsRUFBRztBQUNkLFlBQU0sQ0FBQyxJQUNMLFVBQVUsRUFBRSxZQUFZLEtBQ3hCLFVBQVUsSUFBSSxFQUFFLFdBQVcsR0FBRyxHQUFHLEtBQ2pDLFVBQVUsSUFBSSxFQUFFLGlCQUFpQixHQUFHLE9BQU87QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sVUFBVSxXQUFXLElBQUk7QUFDdEMsUUFBTSxVQUFVLFVBQVUsV0FBVyxHQUFHO0FBQ3hDLFFBQU0sWUFDSixPQUFPLE1BQU0sWUFBWSxNQUFNLFdBQVksTUFBTSxZQUFZLElBQWU7QUFDOUUsUUFBTSxRQUFRLE9BQU8sTUFBTSxPQUFPLE1BQU0sV0FBWSxNQUFNLE9BQU8sSUFBZTtBQUNoRixRQUFNLGNBQ0osT0FBTyxNQUFNLGFBQWEsTUFBTSxXQUFZLE1BQU0sYUFBYSxJQUFlO0FBQ2hGLFFBQU0sWUFDSCxPQUFPLE1BQU0sZ0NBQWdDLE1BQU0sV0FDL0MsTUFBTSxnQ0FBZ0MsSUFDdkMsVUFDSCxPQUFPLE1BQU0sMEJBQTBCLE1BQU0sV0FDekMsTUFBTSwwQkFBMEIsSUFDakMsVUFDSCxPQUFPLE1BQU0sOEJBQThCLE1BQU0sV0FDN0MsTUFBTSw4QkFBOEIsSUFDckM7QUFDTixNQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsU0FBVSxRQUFPO0FBQ3pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiO0FBQ0Y7OztBQzl6QkEsSUFBTSxXQUFXO0FBRVYsU0FBUyxXQUFtQjtBQUNqQyxRQUFNLEtBQUssS0FBSyxJQUFJO0FBQ3BCLE1BQUksU0FBUztBQUNiLE1BQUksSUFBSTtBQUNSLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLGNBQVUsU0FBUyxJQUFJLEVBQUUsS0FBSyxPQUFPO0FBQ3JDLFFBQUksS0FBSyxNQUFNLElBQUksRUFBRTtBQUFBLEVBQ3ZCO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLEtBQU0sYUFBWSxTQUFTLElBQUksRUFBRSxLQUFLO0FBQ3RELFNBQU8sU0FBUztBQUNsQjtBQUVPLFNBQVMsV0FBVyxJQUFvQjtBQUM3QyxTQUFPLEdBQUcsTUFBTSxFQUFFO0FBQ3BCOzs7QUNQQSxJQUFNLG1CQUFpRCxvQkFBSSxJQUFJO0FBQUEsRUFDN0Q7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVNLFNBQVMsa0JBQWtCLE1BQStCO0FBQy9ELFFBQU0sV0FBNEIsQ0FBQztBQUNuQyxNQUFJLFVBQWtDLENBQUM7QUFDdkMsTUFBSSxhQUFhO0FBQ2pCLFFBQU0sUUFBUSxNQUFNO0FBQ2xCLFFBQUksUUFBUSxVQUFVLFFBQVEsT0FBTztBQUNuQyxVQUFJLENBQUMsUUFBUSxTQUFVLFNBQVEsV0FBVztBQUMxQyxlQUFTLEtBQUssT0FBd0I7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFDQSxhQUFXLFdBQVcsS0FBSyxNQUFNLElBQUksR0FBRztBQUN0QyxVQUFNLE9BQU8sY0FBYyxPQUFPO0FBQ2xDLFFBQUksS0FBSyxLQUFLLE1BQU0sR0FBSTtBQUN4QixRQUFJLGdCQUFnQixLQUFLLElBQUksR0FBRztBQUM5QixtQkFBYTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxXQUFZO0FBRWpCLFVBQU0sWUFBWSxLQUFLLE1BQU0sNEJBQTRCO0FBQ3pELFFBQUksV0FBVztBQUNiLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxVQUFVLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDaEQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx3QkFBd0I7QUFDdEQsUUFBSSxjQUFjLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUNyQyxZQUFNO0FBQ04sZ0JBQVUsRUFBRSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2pEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sdUJBQXVCO0FBQ3JELFFBQUksY0FBYyxRQUFRLFFBQVE7QUFDaEMsY0FBUSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRTtBQUMzQztBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixLQUFLLE1BQU0sMEJBQTBCO0FBQzNELFFBQUksaUJBQWlCLFFBQVEsUUFBUTtBQUNuQyxZQUFNLE1BQU0sUUFBUSxjQUFjLENBQUMsS0FBSyxFQUFFO0FBQzFDLGNBQVEsV0FBVyxpQkFBaUIsSUFBSSxHQUFzQixJQUN6RCxNQUNEO0FBQ0o7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU07QUFDTixTQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUNuRDtBQUVBLFNBQVMsY0FBYyxNQUFzQjtBQUczQyxRQUFNLE1BQU0sS0FBSyxRQUFRLEdBQUc7QUFDNUIsU0FBTyxRQUFRLEtBQUssT0FBTyxLQUFLLE1BQU0sR0FBRyxHQUFHO0FBQzlDO0FBRUEsU0FBUyxRQUFRLEdBQW1CO0FBQ2xDLFFBQU0sVUFBVSxFQUFFLEtBQUs7QUFDdkIsTUFDRyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQy9DLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsR0FDaEQ7QUFDQSxXQUFPLFFBQVEsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUM1QjtBQUNBLFNBQU87QUFDVDs7O0FDV0EsSUFBTSxjQUFjLFFBQVEsUUFBUSxZQUFZLEVBQUU7QUFDbEQsSUFBTSwyQkFBMkI7QUFDakMsSUFBTSx3QkFBd0I7QUFDOUIsSUFBTSwrQkFBK0IsQ0FBQyxTQUFTLFNBQVMsTUFBTTtBQUM5RCxJQUFJLHVCQUF1QjtBQXFCM0IsZUFBZSxDQUFDLE9BQWlCO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxhQUFhLE9BQU8sR0FBRyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFLENBQUM7QUFFRCxTQUFTLDJCQUFpQztBQUN4Qyx5QkFBdUIsS0FBSyxJQUFJLElBQUk7QUFDdEM7QUFJQSxRQUFRLFFBQVEsWUFBWSxZQUFZLFlBQVk7QUFDbEQsUUFBTSxLQUFLLHVCQUF1QixFQUFFLFNBQVMsWUFBWSxDQUFDO0FBQzFELFFBQU0sT0FBTyxTQUFTO0FBQ3hCLENBQUM7QUFFRCxRQUFRLFFBQVEsVUFBVSxZQUFZLE1BQU07QUFDMUMsT0FBSyxPQUFPLFNBQVM7QUFDdkIsQ0FBQztBQUdELEtBQUssT0FBTyxhQUFhO0FBRXpCLGVBQWUsT0FBTyxRQUErQjtBQUNuRCxNQUFJO0FBQ0YsVUFBTSxhQUFhO0FBQ25CLFVBQU0sc0JBQXNCO0FBQzVCLFVBQU0sc0JBQXNCLEVBQUUsUUFBUSxRQUFRLE1BQU0sSUFBSSxLQUFLLE1BQU0sQ0FBQztBQUNwRSxVQUFNLDRCQUE0QjtBQUNsQyxVQUFNLHFCQUFxQjtBQUczQixVQUFNLFNBQVMsTUFBTSxvQkFBb0IsS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFJO0FBQ2pFLFFBQUksU0FBUyxFQUFHLE9BQU0sS0FBSywwQkFBMEIsRUFBRSxPQUFPLENBQUM7QUFDL0QsVUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFJLFNBQVMsT0FBTyxTQUFTLFNBQVMsU0FBUyxNQUFNO0FBQ25ELFlBQU0saUJBQWlCLEtBQUs7QUFDNUIsWUFBTSxvQkFBb0IsS0FBSztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTztBQUFBLFFBQ1AsZUFBZTtBQUFBLFFBQ2Ysd0JBQXdCO0FBQUEsUUFDeEIsa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUNELFlBQU0sS0FBSyx3Q0FBd0MsRUFBRSxPQUFPLENBQUM7QUFBQSxJQUMvRDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFPLGVBQWUsRUFBRSxRQUFRLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQy9EO0FBQ0Y7QUFFQSxTQUFTLFNBQTBDO0FBQ2pELFFBQU0sZUFBZTtBQUdyQixTQUFPLGFBQWEseUJBQXlCO0FBQy9DO0FBRUEsZUFBZSxpQkFBb0M7QUFDakQsUUFBTSxPQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFDM0YsU0FBTyxLQUFLLFFBQVEsQ0FBQyxRQUFTLE9BQU8sSUFBSSxPQUFPLFdBQVcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUU7QUFDM0U7QUFFQSxlQUFlLHNCQUFzQjtBQUFBLEVBQ25DO0FBQUEsRUFDQTtBQUNGLEdBR2tCO0FBQ2hCLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxNQUFNLE9BQU87QUFDbkIsTUFBSSxDQUFDLEtBQUs7QUFDUixRQUFJLFNBQVMsd0JBQXdCLEtBQUs7QUFDeEMsWUFBTSxLQUFLLHlFQUF5RTtBQUFBLFFBQ2xGO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUNBO0FBQUEsRUFDRjtBQUVBLFFBQU0sU0FBUyxTQUFTLHVCQUF1QixNQUFNLGVBQWUsSUFBSSxDQUFDO0FBQ3pFLFFBQU0sV0FDSixPQUFPLFNBQVMsSUFDWjtBQUFBLElBQ0U7QUFBQSxNQUNFLElBQUk7QUFBQSxNQUNKLFVBQVU7QUFBQSxNQUNWLFFBQVEsRUFBRSxNQUFNLFFBQVE7QUFBQSxNQUN4QixXQUFXO0FBQUEsUUFDVDtBQUFBLFFBQ0EsZUFBZSxDQUFDLEdBQUcsNEJBQTRCO0FBQUEsTUFDakQ7QUFBQSxJQUNGO0FBQUEsRUFDRixJQUNBLENBQUM7QUFDUCxRQUFNLElBQUksbUJBQW1CO0FBQUEsSUFDM0IsZUFBZSxDQUFDLHFCQUFxQjtBQUFBLElBQ3JDO0FBQUEsRUFDRixDQUFDO0FBRUQsTUFBSSxLQUFLO0FBQ1AsVUFBTSxLQUFLLHdDQUF3QztBQUFBLE1BQ2pELFNBQVMsU0FBUztBQUFBLE1BQ2xCLFdBQVcsT0FBTztBQUFBLE1BQ2xCLHdCQUF3Qiw2QkFBNkIsS0FBSyxHQUFHO0FBQUEsTUFDN0Q7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxRQUFRLEtBQUssVUFBVSxZQUFZLENBQUMsUUFBUSxlQUFlO0FBQ3pELE1BQUksV0FBVyxPQUFPLFdBQVcsV0FBVyxZQUFZO0FBQ3RELFNBQUssc0JBQXNCLEVBQUUsUUFBUSxlQUFlLEtBQUssTUFBTSxDQUFDLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDL0UsV0FBSyxLQUFLLHFDQUFxQyxjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ25FLENBQUM7QUFBQSxFQUNIO0FBQ0YsQ0FBQztBQUVELFFBQVEsS0FBSyxVQUFVLFlBQVksTUFBTTtBQUN2QyxPQUFLLHNCQUFzQixFQUFFLFFBQVEsZUFBZSxLQUFLLE1BQU0sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQy9FLFNBQUssS0FBSyxxQ0FBcUMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUNuRSxDQUFDO0FBQ0gsQ0FBQztBQVlELGVBQWUsdUJBQXNDO0FBQ25ELE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsRUFDdkYsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDZCQUE2QixjQUFjLEdBQUcsQ0FBQztBQUMxRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJO0FBQ0YsWUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJdEIsT0FBTztBQUFBLE1BQ1QsQ0FBQztBQUNELFlBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLE1BQ3RCLENBQUM7QUFDRCxZQUFNLEtBQUsscUNBQXFDO0FBQUEsUUFDOUMsT0FBTyxJQUFJO0FBQUEsUUFDWCxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUU7QUFBQSxNQUMvQixDQUFDO0FBQUEsSUFDSCxTQUFTLEtBQUs7QUFJWixZQUFNLEtBQUssd0NBQXdDO0FBQUEsUUFDakQsT0FBTyxJQUFJO0FBQUEsUUFDWCxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUU7QUFBQSxRQUM3QixHQUFHLGNBQWMsR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxRQUFNLFFBQVEsT0FBTyxNQUFNLGFBQWE7QUFDeEMsUUFBTSxRQUFRLE9BQU8sTUFBTSxtQkFBbUI7QUFDOUMsUUFBTSxRQUFRLE9BQU8sT0FBTyxlQUFlLEVBQUUsaUJBQWlCLG9CQUFvQixDQUFDO0FBQ25GLFFBQU0sUUFBUSxPQUFPLE9BQU8scUJBQXFCO0FBQUEsSUFDL0MsaUJBQWlCLGdDQUFnQztBQUFBLEVBQ25ELENBQUM7QUFDSDtBQU1BLElBQUksa0JBQXlEO0FBQzdELElBQU0sNkJBQTZCLEtBQUssS0FBSztBQU03QyxJQUFNLDhCQUE4QixvQkFBSSxJQUErQjtBQUt2RSxJQUFNLGlCQUFpQjtBQUV2QixlQUFlLHdCQUF1QztBQUVwRCxRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixNQUFJLFNBQVMsUUFBUSxFQUFFLFlBQVksT0FBTztBQUN4Qyx1QkFBbUIsRUFBRSxxQkFBcUI7QUFBQSxFQUM1QyxPQUFPO0FBQ0wseUJBQXFCO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsdUJBQTZCO0FBQ3BDLE1BQUksb0JBQW9CLE1BQU07QUFDNUIsa0JBQWMsZUFBZTtBQUM3QixzQkFBa0I7QUFBQSxFQUNwQjtBQUNGO0FBRUEsU0FBUyxtQkFBbUIsYUFBMkI7QUFDckQsdUJBQXFCO0FBQ3JCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLFdBQVcsQ0FBQztBQUFBLEVBQ3ZEO0FBQ0Esb0JBQWtCLFlBQVksTUFBTTtBQUNsQyxTQUFLLGVBQWUsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNuQyxXQUFLLEtBQUssMkJBQTJCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDekQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxlQUFlLHNCQUFxQztBQUNsRCwyQkFBeUI7QUFDekIsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLHFCQUFxQjtBQUFBLElBQ3pCLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxhQUFhO0FBQUEsSUFDYixlQUFlO0FBQUEsSUFDZixrQkFBa0I7QUFBQSxJQUNsQix1QkFBdUI7QUFBQSxJQUN2QixpQkFBaUI7QUFBQSxJQUNqQixlQUFlO0FBQUEsRUFDakIsQ0FBQztBQUNELHFCQUFtQixFQUFFLHFCQUFxQjtBQUMxQyxRQUFNLEtBQUssNEJBQTRCLEVBQUUsY0FBYyxFQUFFLHNCQUFzQixDQUFDO0FBRWhGLE9BQUssZUFBZTtBQUNwQixRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLHVCQUFzQztBQUNuRCx1QkFBcUI7QUFDckIsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxLQUFLLDhCQUE4QjtBQUFBLElBQ3ZDLFNBQVMsTUFBTSxlQUFlO0FBQUEsSUFDOUIsVUFBVSxNQUFNLGlCQUFpQjtBQUFBLElBQ2pDLFVBQVUsTUFBTSxpQkFBaUI7QUFBQSxFQUNuQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxpQkFBZ0M7QUFDN0MsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFBQSxFQUN2RixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaUNBQWlDLGNBQWMsR0FBRyxDQUFDO0FBQzlEO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsTUFBSSxjQUFjO0FBQ2xCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJLElBQUksVUFBVztBQUNuQixRQUFJO0FBQ0YsWUFBTSxVQUFXLE1BQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNyRCxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPO0FBQUEsUUFDUCxNQUFPLE1BQU07QUFJWCxnQkFBTSxPQUEwQjtBQUFBLFlBQzlCLEtBQUs7QUFBQSxZQUNMLE1BQU07QUFBQSxZQUNOLFNBQVM7QUFBQSxZQUNULE9BQU87QUFBQSxZQUNQLFNBQVM7QUFBQSxZQUNULFlBQVk7QUFBQSxVQUNkO0FBQ0EsZ0JBQU0sUUFBUyxTQUFTLGlCQUF3QyxTQUFTO0FBQ3pFLGdCQUFNLGNBQWMsSUFBSSxjQUFjLFdBQVcsSUFBSSxDQUFDO0FBQ3RELGdCQUFNLGNBQWMsSUFBSSxjQUFjLFNBQVMsSUFBSSxDQUFDO0FBQ3BELGlCQUFPLFNBQVM7QUFBQSxZQUNkLEtBQUssU0FBUyxnQkFBZ0I7QUFBQSxZQUM5QixVQUFVO0FBQUEsVUFDWixDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0YsQ0FBQztBQUNELHFCQUFlO0FBQUEsSUFFakIsUUFBUTtBQUFBLElBR1I7QUFBQSxFQUNGO0FBQ0EsTUFBSSxjQUFjLEdBQUc7QUFDbkIsVUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQUksU0FBUyxNQUFNO0FBQ2pCLFdBQUssZUFBZTtBQUNwQixZQUFNLHFCQUFxQixJQUFJO0FBQUEsSUFFakM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHlCQUErQjtBQUN0QyxRQUFNLFNBQVMsS0FBSyxJQUFJLElBQUk7QUFDNUIsYUFBVyxDQUFDLE9BQU8sS0FBSyxLQUFLLDZCQUE2QjtBQUN4RCxRQUFJLE1BQU0sWUFBWSxPQUFRLDZCQUE0QixPQUFPLEtBQUs7QUFBQSxFQUN4RTtBQUNGO0FBRUEsU0FBUywrQkFDUCxPQUNBLFNBQ0EsUUFDQSxhQUNNO0FBQ04sTUFBSSxVQUFVLFFBQVEsT0FBTyxXQUFXLEtBQUssWUFBWSxTQUFTLEVBQUc7QUFDckUsUUFBTSxlQUFlLG9CQUFJLElBQVk7QUFDckMsYUFBVyxLQUFLLFFBQVE7QUFDdEIsUUFBSSxZQUFZLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxFQUFHLGNBQWEsSUFBSSxFQUFFLFFBQVE7QUFBQSxFQUNsRjtBQUNBLFFBQU0sV0FBVyw0QkFBNEIsSUFBSSxLQUFLO0FBQ3RELFFBQU0sV0FBVyxVQUFVLFlBQVksb0JBQUksSUFBWTtBQUN2RCxhQUFXLEtBQUssUUFBUTtBQUN0QixVQUFNLFNBQVMsRUFBRSxlQUFlLFlBQVk7QUFDNUMsVUFBTSxjQUFjLEVBQUUsa0JBQWtCLFlBQVksS0FBSztBQUN6RCxRQUNFLFlBQVksSUFBSSxNQUFNLEtBQ3JCLGdCQUFnQixRQUFRLFlBQVksSUFBSSxXQUFXLEtBQ25ELEVBQUUsc0JBQXNCLFFBQVEsYUFBYSxJQUFJLEVBQUUsaUJBQWlCLEtBQ3BFLEVBQUUsb0JBQW9CLFFBQVEsYUFBYSxJQUFJLEVBQUUsZUFBZSxLQUNoRSxFQUFFLHVCQUF1QixRQUFRLGFBQWEsSUFBSSxFQUFFLGtCQUFrQixHQUN2RTtBQUNBLGVBQVMsSUFBSSxFQUFFLFFBQVE7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFDQSw4QkFBNEIsSUFBSSxPQUFPO0FBQUEsSUFDckMsV0FBVyxLQUFLLElBQUk7QUFBQSxJQUNwQjtBQUFBLElBQ0E7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUVBLFFBQVEsT0FBTyxRQUFRLFlBQVksQ0FBQyxVQUFVO0FBQzVDLE1BQUksTUFBTSxTQUFTLGVBQWU7QUFDaEMsU0FBSyxpQkFBaUI7QUFBQSxFQUN4QixXQUFXLE1BQU0sU0FBUyxxQkFBcUI7QUFDN0MsU0FBSyxpQkFBaUIsS0FBSztBQUFBLEVBQzdCO0FBSUYsQ0FBQztBQUlELElBQUksUUFBUSxRQUFRLFdBQVc7QUFDN0IsVUFBUSxPQUFPLFVBQVUsWUFBWSxZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNLFFBQVEsY0FBYyxPQUFPO0FBQUEsSUFDckMsU0FBUyxLQUFLO0FBRVosWUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUN2RSxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFBQSxJQUN4QztBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBSUEsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLEtBQWMsV0FBVztBQUM5RCxNQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRyxRQUFPO0FBQ25DLFNBQU8sY0FBYyxLQUFLLE1BQU0sRUFBRSxNQUFNLENBQUMsUUFBUTtBQUMvQyxTQUFLLE1BQU8sMEJBQTBCLEVBQUUsTUFBTSxJQUFJLE1BQU0sR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQy9FLFVBQU07QUFBQSxFQUNSLENBQUM7QUFDSCxDQUFDO0FBRUQsU0FBUyxpQkFBaUIsR0FBaUM7QUFDekQsU0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFBWSxPQUFRLEVBQXlCLFNBQVM7QUFDbkY7QUFJQSxJQUFNLDRCQUE0QixvQkFBSSxJQUE0QjtBQUFBLEVBQ2hFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVELGVBQWUsWUFBOEI7QUFDM0MsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixTQUFPLEVBQUUsWUFBWTtBQUN2QjtBQUVBLGVBQWUsY0FDYixLQUNBLFFBQ2tCO0FBS2xCLE1BQUksQ0FBRSxNQUFNLFVBQVUsS0FBTSwwQkFBMEIsSUFBSSxJQUFJLElBQUksR0FBRztBQUNuRSxXQUFPLEVBQUUsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUFBLEVBQ2xDO0FBQ0EsVUFBUSxJQUFJLE1BQU07QUFBQSxJQUNoQixLQUFLO0FBQ0gsWUFBTTtBQUFBLFFBQ0osSUFBSTtBQUFBLFFBQ0osSUFBSTtBQUFBLFFBQ0osSUFBSSxXQUFXO0FBQUEsUUFDZixJQUFJO0FBQUEsUUFDSixRQUFRLEtBQUssTUFBTTtBQUFBLE1BQ3JCO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdkUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssK0JBQStCLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdEUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxVQUFJLElBQUksVUFBVSxRQUFRO0FBQ3hCLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xELFdBQVcsSUFBSSxVQUFVLFNBQVM7QUFDaEMsY0FBTSxNQUFPLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDcEQsT0FBTztBQUNMLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xEO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssc0JBQXNCO0FBQ3pCLFlBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsVUFBSSxTQUFTLFlBQVksT0FBTztBQUM5QixlQUFPLEVBQUUsU0FBUyxPQUFPLGFBQWEsQ0FBQyxHQUFHLGtCQUFrQixDQUFDLEVBQUU7QUFBQSxNQUNqRTtBQUNBLDZCQUF1QjtBQUN2QixZQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFlBQU0sY0FBYyxTQUNqQixPQUFPLENBQUMsTUFBTSxFQUFFLGFBQWEsTUFBTSxFQUNuQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDO0FBQ3BDLFlBQU0sUUFBUSxRQUFRLEtBQUssTUFBTTtBQUNqQyxhQUFPO0FBQUEsUUFDTCxTQUFTO0FBQUEsUUFDVDtBQUFBLFFBQ0Esa0JBQ0UsVUFBVSxPQUFPLENBQUMsSUFBSSxNQUFNLEtBQUssNEJBQTRCLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxDQUFDO0FBQUEsTUFDM0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLHNCQUFzQjtBQUN6QixVQUFJLElBQUksUUFBUSxHQUFHO0FBQ2pCLGNBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxZQUFJLFdBQVcsTUFBTTtBQUNuQixpQkFBTyxpQkFBaUIsSUFBSTtBQUM1QixnQkFBTSxxQkFBcUIsTUFBTTtBQUFBLFFBQ25DO0FBQUEsTUFDRjtBQUNBLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFdBQVcsSUFBSSxNQUFNO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFdBQVc7QUFDakIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZ0JBQWdCO0FBQ3RCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFNBQVMsTUFBTTtBQUNyQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxZQUFZLElBQUksUUFBUSxNQUFNO0FBQ3BDLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGVBQWUsRUFBRSxhQUFhLElBQUksR0FBRyxDQUFDO0FBQzVDLFlBQU0sS0FBSyx3QkFBd0IsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQ2pELGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsSUFBSSxHQUFHLENBQUM7QUFDL0MsWUFBTSxLQUFLLDJCQUEyQixFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDcEQsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLHNCQUFzQixJQUFJLEdBQUcsQ0FBQztBQUNyRCxZQUFNLHNCQUFzQixFQUFFLFFBQVEsVUFBVSxLQUFLLEtBQUssQ0FBQztBQUMzRCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLGtCQUFrQjtBQUNyQixZQUFNLElBQUksTUFBTSxlQUFlLEVBQUUsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNsRCxVQUFJLENBQUMsSUFBSSxJQUFJO0FBR1gsNkJBQXFCO0FBQ3JCLDRCQUFvQjtBQUNwQiwrQkFBdUI7QUFDdkIsK0JBQXVCO0FBQ3ZCLGNBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxjQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUM3QyxjQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUFBLE1BQy9DLE9BQU87QUFFTCxjQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsWUFBSSxTQUFTLEtBQU0sb0JBQW1CLEVBQUUscUJBQXFCO0FBQUEsTUFDL0Q7QUFDQSxZQUFNLEtBQUssbUNBQW1DLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUM1RCxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0sb0JBQW9CO0FBQzFCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLHFCQUFxQjtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLDRCQUE0QjtBQUMvQixZQUFNLFVBQVUsS0FBSztBQUFBLFFBQ25CO0FBQUEsUUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxJQUFJLE9BQU8sQ0FBQztBQUFBLE1BQ3ZEO0FBQ0EsWUFBTSxlQUFlLEVBQUUsdUJBQXVCLFFBQVEsQ0FBQztBQUV2RCxZQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsVUFBSSxTQUFTLEtBQU0sb0JBQW1CLE9BQU87QUFDN0MsVUFBSSwwQkFBMEIsS0FBTSxzQkFBcUIsT0FBTztBQUNoRSxVQUFJLDZCQUE2QixLQUFNLHlCQUF3QixPQUFPO0FBQ3RFLFVBQUksNkJBQTZCLEtBQU0seUJBQXdCLE9BQU87QUFDdEUsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLGlCQUFpQjtBQUN2QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxrQkFBa0I7QUFDeEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sb0JBQW9CO0FBQzFCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLHFCQUFxQjtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssbUJBQW1CO0FBQ3RCLFlBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsWUFBTSxVQUFVLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUMvRCxZQUFNLFVBQVUsTUFBTSxvQkFBb0IsT0FBTztBQUNqRCxZQUFNLEtBQUssMEJBQTBCLE9BQU87QUFDNUMsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQixJQUFJO0FBQzlCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGNBQWM7QUFDcEIsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFDdEMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssZUFBZTtBQUNsQixZQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFlBQU0sTUFBTSxVQUFVLENBQUM7QUFDdkIsWUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLElBQUksQ0FBQztBQUNqQyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQ0UsYUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLHVCQUF1QjtBQUFBLEVBQ3REO0FBQ0Y7QUFJQSxlQUFlLGlCQUNiLFVBQ0EsS0FDQSxTQUNBLFVBQ0EsYUFDZTtBQUNmLE1BQUksa0JBQWtCLElBQUksUUFBUSxFQUFHO0FBQ3JDLE1BQUksQ0FBQyxnQkFBZ0IsSUFBSSxRQUFRLEVBQUc7QUFFcEMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLFNBQVMsWUFBWSxNQUFPO0FBQ2hDLE1BQUksU0FBUyxnQkFBZ0IsT0FBTztBQUNsQyxVQUFNLHdCQUNKLEtBQUssSUFBSSxJQUFJLHdCQUNaLE1BQU0scUJBQXFCLE1BQU8sUUFDbEMsTUFBTSxrQkFBa0IsTUFBTyxRQUMvQixNQUFNLHFCQUFxQixNQUFPO0FBQ3JDLFFBQUksQ0FBQyxzQkFBdUI7QUFBQSxFQUM5QjtBQUVBLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFnQm5DLFFBQU0sVUFBVSxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDbkUsUUFBTSxPQUFPLElBQUk7QUFBQSxJQUNmLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxhQUFhLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDO0FBQUEsRUFDakY7QUFDQSxRQUFNLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFFMUMsTUFBSTtBQUNKLE1BQUk7QUFDRixpQkFBYSxVQUFVLFVBQVU7QUFBQSxNQUMvQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1A7QUFBQSxNQUNBLGdCQUFnQixvQkFBSSxJQUFZO0FBQUEsTUFDaEMsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxXQUFXLG1CQUFtQixVQUFVLEtBQUssVUFBVSxHQUFHO0FBQ2hFO0FBQUEsRUFDRjtBQUNBLFFBQU0sZUFBZTtBQUFBLElBQ25CLFdBQVc7QUFBQSxJQUNYO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiO0FBUUEsUUFBTSxlQUFlLFdBQVcsT0FBTztBQUN2QyxhQUFXLFNBQVMsY0FBYyxXQUFXLFFBQVEsU0FBUyxJQUFJO0FBQ2xFLFFBQU0sbUJBQW1CLGVBQWUsV0FBVyxPQUFPO0FBQzFELE1BQUksbUJBQW1CLEdBQUc7QUFDeEIsVUFBTSxLQUFLLDRCQUE0QjtBQUFBLE1BQ3JDO0FBQUEsTUFDQSxTQUFTO0FBQUEsTUFDVCxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBQ0EsaUNBQStCLGFBQWEsU0FBUyxXQUFXLFFBQVEsSUFBSTtBQU81RSxNQUFJLFdBQVcsYUFBYSxXQUFXLEdBQUc7QUFDeEMsVUFBTSxLQUFLLDRDQUF1QztBQUFBLE1BQ2hEO0FBQUEsTUFDQSxXQUFXLGVBQWUsUUFBUSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsTUFDL0MsWUFBWSxvQkFBb0IsVUFBVSxPQUFPO0FBQUEsTUFDakQsaUJBQWlCLGlCQUFpQixVQUFVLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFBQSxNQUM3RCxtQkFBbUIsaUJBQWlCLFVBQVUsU0FBUyxDQUFDLFFBQVEsQ0FBQztBQUFBLE1BQ2pFLDBCQUEwQixpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDNUQ7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLE1BQ0QsK0JBQStCLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUNqRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLE1BQ0QsaUNBQWlDLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUNuRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0gsT0FBTztBQUNMLFVBQU0sS0FBSyx3QkFBd0I7QUFBQSxNQUNqQztBQUFBLE1BQ0EsVUFBVSxXQUFXLGFBQWE7QUFBQSxNQUNsQyxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBRUEsTUFBSSxXQUFXLG1CQUFtQixTQUFTLEdBQUc7QUFDNUMsVUFBTTtBQUFBLE1BQ0osV0FBVztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLE1BQUksV0FBVyxPQUFPLFdBQVcsR0FBRztBQUNsQyxVQUFNLGdCQUFnQixNQUFNO0FBQUEsTUFDMUI7QUFBQSxNQUNBO0FBQUEsTUFDQSxXQUFXO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFDQSxRQUFJLGdCQUFnQixFQUFHLE9BQU0sZUFBZTtBQUM1QztBQUFBLEVBQ0Y7QUFXQSxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsYUFBVyxLQUFLLFdBQVcsUUFBUTtBQUNqQyxRQUFJLEVBQUUsY0FBYztBQUNsQixZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRO0FBQUEsSUFDbkQsT0FBTztBQUNMLFlBQU0sZUFBZSxFQUFFLGdCQUFnQixFQUFFLFFBQVE7QUFBQSxJQUNuRDtBQUdBLFVBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxRQUFJLGFBQWEsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNqRCxrQkFBWSxXQUFXO0FBQ3ZCLGtCQUFZLGFBQWE7QUFDekIsWUFBTSxrQkFBa0IsV0FBVztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxtQkFBbUIsRUFBRSxRQUFRO0FBQ25DLFlBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxZQUFNLHFCQUFxQixjQUFjO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBS0EsYUFBVyxXQUFXLFdBQVcsYUFBYTtBQUM1QyxRQUFJLE1BQU0sWUFBWSxRQUFRLFFBQVEsRUFBRztBQUN6QyxVQUFNLGtCQUFrQixRQUFRLGFBQWEsUUFBUSxRQUFRO0FBQUEsRUFDL0Q7QUFDQSxNQUFJLFdBQVcsWUFBWSxTQUFTLEdBQUc7QUFDckMsVUFBTSxLQUFLLDBDQUEwQztBQUFBLE1BQ25EO0FBQUEsTUFDQSxTQUFTLFdBQVcsWUFBWTtBQUFBLE1BQ2hDLGFBQWEsTUFBTSxxQkFBcUI7QUFBQSxJQUMxQyxDQUFDO0FBQUEsRUFDSDtBQWdCQSxRQUFNLGlCQUFpQixTQUFTLG1CQUFtQjtBQUNuRCxRQUFNLGVBQWUsTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxrQkFBa0IsTUFBTSxtQkFBbUI7QUFDakQsTUFBSSxpQkFBaUI7QUFDckIsTUFBSSx1QkFBdUI7QUFDM0IsTUFBSSwwQkFBMEI7QUFDOUIsTUFBSSxrQkFBa0I7QUFDdEIsTUFBSSxtQkFBbUI7QUFDdkIsUUFBTSxhQUF1QyxDQUFDO0FBQzlDLFFBQU0sZ0JBQWdCLG9CQUFJLElBQWdDO0FBQzFELFFBQU0sYUFBYSxvQkFBSSxJQUFxQztBQUM1RCxhQUFXLEtBQUssV0FBVyxRQUFRO0FBQ2pDLFVBQU0sT0FBTyxhQUFhLEVBQUUsY0FBYyxJQUFJLEVBQUUsUUFBUTtBQUN4RCxVQUFNLGdCQUFnQixDQUFDLFFBQVEsd0JBQXdCLEdBQUcsZUFBZTtBQUN6RSxVQUFNLHFCQUFxQixRQUFRLElBQUksS0FBSztBQUM1QyxrQkFBYyxJQUFJLEVBQUUsVUFBVSxxQkFBcUIsYUFBYSxLQUFLO0FBQ3JFLFFBQUksY0FBZSxvQkFBbUI7QUFDdEMsVUFBTSxNQUFNO0FBQUEsTUFDVixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsSUFDSjtBQUNBLFVBQU0sa0JBQWtCLFNBQVMsVUFBYSxrQkFBa0IsS0FBSyxHQUFHLEtBQUssQ0FBQyxFQUFFO0FBQ2hGLFFBQUksc0JBQXNCLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCO0FBQzdELFVBQUksS0FBTSx5QkFBd0I7QUFBQSxVQUM3Qiw0QkFBMkI7QUFDaEMsaUJBQVcsSUFBSSxFQUFFLFVBQVUsU0FBUztBQUNwQztBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsS0FBSyxRQUFRLEtBQUs7QUFDNUIsd0JBQWtCO0FBQ2xCLGlCQUFXLElBQUksRUFBRSxVQUFVLFdBQVc7QUFDdEM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxnQkFBaUIscUJBQW9CO0FBQ3pDLGVBQVcsSUFBSSxFQUFFLFVBQVUsVUFBVTtBQUNyQyxlQUFXLEtBQUssQ0FBQztBQUFBLEVBQ25CO0FBQ0EsTUFBSSxpQkFBaUIsR0FBRztBQUN0QixVQUFNLEtBQUssbUNBQW1DO0FBQUEsTUFDNUM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSx1QkFBdUIsMEJBQTBCLEdBQUc7QUFDdEQsVUFBTSxhQUFhLHVCQUF1QjtBQUMxQyxVQUFNLEtBQUssb0VBQW9FO0FBQUEsTUFDN0U7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULGFBQWE7QUFBQSxNQUNiLGtCQUFrQjtBQUFBLE1BQ2xCLFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFDRCxVQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsUUFBSSxXQUFXLE1BQU07QUFDbkIsYUFBTyxtQkFBbUIsT0FBTyxtQkFBbUIsS0FBSztBQUN6RCxZQUFNLHFCQUFxQixNQUFNO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBQ0EsTUFBSSxrQkFBa0IsS0FBSyxnQkFBZ0I7QUFDekMsVUFBTSxLQUFLLDBDQUEwQztBQUFBLE1BQ25EO0FBQUEsTUFDQSxLQUFLO0FBQUEsTUFDTCxRQUFRO0FBQUEsTUFDUix1QkFBdUIsaUJBQWlCLGdCQUFnQjtBQUFBLElBQzFELENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLEtBQUssdUNBQXVDO0FBQUEsTUFDaEQ7QUFBQSxNQUNBLFVBQVU7QUFBQSxNQUNWO0FBQUEsTUFDQSxXQUFXLFdBQVc7QUFBQSxJQUN4QixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU07QUFBQSxJQUNKLFdBQVcsT0FBTztBQUFBLE1BQUksQ0FBQyxNQUNyQjtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsY0FBYyxJQUFJLEVBQUUsUUFBUTtBQUFBLFFBQzVCLFdBQVcsSUFBSSxFQUFFLFFBQVE7QUFBQSxNQUMzQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBU0EsUUFBTSxzQkFBc0IsV0FBVyxRQUFRLFFBQVE7QUFDdkQsUUFBTSw0QkFBNEIsV0FBVyxRQUFRLE1BQU0sUUFBUTtBQUNuRSxRQUFNLHVCQUF1QixNQUFNO0FBQUEsSUFDakM7QUFBQSxJQUNBO0FBQUEsSUFDQSxXQUFXO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzNCLFFBQUksdUJBQXVCLEVBQUcsT0FBTSxlQUFlO0FBQ25EO0FBQUEsRUFDRjtBQUdBLFFBQU0sV0FBVyxvQkFBSSxJQUE4QjtBQUNuRCxhQUFXLEtBQUssWUFBWTtBQUMxQixVQUFNLE1BQU0sU0FBUyxJQUFJLEVBQUUsY0FBYyxLQUFLLENBQUM7QUFDL0MsUUFBSSxLQUFLLENBQUM7QUFDVixhQUFTLElBQUksRUFBRSxnQkFBZ0IsR0FBRztBQUFBLEVBQ3BDO0FBRUEsYUFBVyxDQUFDLFFBQVEsTUFBTSxLQUFLLFVBQVU7QUFDdkMsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxLQUFLLFFBQVE7QUFDbkUsUUFBSSxRQUFRO0FBQ1osUUFBSSxXQUFXO0FBQ2YsUUFBSSxnQkFBZ0I7QUFDcEIsUUFBSSxrQkFBa0I7QUFDdEIsZUFBVyxLQUFLLFFBQVE7QUFDdEIsWUFBTSxXQUFXLElBQUksYUFBYSxFQUFFLFFBQVE7QUFDNUMsVUFBSSxVQUFVO0FBR1osaUJBQVMsZUFBZTtBQUN4QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsZ0JBQWdCLEVBQUU7QUFDM0IsaUJBQVMsY0FBYyxFQUFFO0FBQ3pCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsaUJBQWlCLEVBQUU7QUFDNUIsY0FBTSxPQUFPLFNBQVMsbUJBQW1CLFNBQVMsbUJBQW1CLFNBQVMsQ0FBQztBQUMvRSxjQUFNLE9BQU8sRUFBRSxtQkFBbUIsQ0FBQztBQUNuQyxZQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssZ0JBQWdCLEtBQUssY0FBYztBQUM1RCxtQkFBUyxtQkFBbUIsS0FBSyxJQUFJO0FBQUEsUUFDdkM7QUFDQSwyQkFBbUI7QUFBQSxNQUNyQixPQUFPO0FBQ0wsY0FBTSxVQUEwQixFQUFFLEdBQUcsR0FBRyxnQkFBZ0IsSUFBSSxPQUFPO0FBQ25FLFlBQUksYUFBYSxFQUFFLFFBQVEsSUFBSTtBQUMvQixpQkFBUztBQUNULFlBQUksY0FBYyxJQUFJLEVBQUUsUUFBUSxNQUFNLFdBQVksa0JBQWlCO0FBQUEsWUFDOUQsYUFBWTtBQUFBLE1BQ25CO0FBQ0EsVUFBSSxDQUFDLElBQUksbUJBQW1CLFNBQVMsRUFBRSxRQUFRLEdBQUc7QUFDaEQsWUFBSSxtQkFBbUIsS0FBSyxFQUFFLFFBQVE7QUFBQSxNQUN4QztBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxlQUFlLFNBQVMsUUFBUSxFQUFHLEtBQUksZUFBZSxLQUFLLFFBQVE7QUFDNUUsUUFBSSxrQkFBa0I7QUFDdEIsVUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixVQUFNLGlCQUFpQixRQUFRLG1CQUFtQixHQUFHLENBQUM7QUFDdEQsUUFBSSxRQUFRLEtBQUssa0JBQWtCLEdBQUc7QUFDcEMsWUFBTSxLQUFLLG1CQUFtQjtBQUFBLFFBQzVCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMLFVBQVU7QUFBQSxRQUNWLGtCQUFrQjtBQUFBLFFBQ2xCLE9BQU8sT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFO0FBQUEsTUFDdkMsQ0FBQztBQUdELFlBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxVQUFJLFdBQVcsTUFBTTtBQUNuQixlQUFPLGlCQUFpQjtBQUN4QixlQUFPLG9CQUFvQixPQUFPLG9CQUFvQixLQUFLO0FBQzNELGVBQU8seUJBQXlCLE9BQU8seUJBQXlCLEtBQUs7QUFDckUsY0FBTSxxQkFBcUIsTUFBTTtBQUFBLE1BQ25DO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFVBQVUsdUJBQXVCO0FBQ2pFLFlBQU0sWUFBWSxRQUFRLFdBQVc7QUFBQSxJQUN2QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLHdCQUNiLG1CQUNBLFNBQ0EsWUFDQSxXQUNBLFVBQ2U7QUFDZixRQUFNLGVBQWUsTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELE1BQUksV0FBVztBQUNmLE1BQUksVUFBVTtBQUNkLE1BQUksZ0JBQWdCO0FBRXBCLGFBQVcsS0FBSyxtQkFBbUI7QUFDakMsVUFBTSxTQUFTLEVBQUU7QUFDakIsUUFBSSxDQUFDLFFBQVE7QUFDWCx1QkFBaUI7QUFDakIsWUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFlBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQztBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsT0FBTyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sWUFBWSxDQUFDLEdBQUc7QUFDMUQsaUJBQVc7QUFDWDtBQUFBLElBQ0Y7QUFFQSxVQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsVUFBTSxlQUFlLFFBQVEsRUFBRSxRQUFRO0FBQ3ZDLFVBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxRQUFJLGFBQWEsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNqRCxrQkFBWSxXQUFXO0FBQ3ZCLGtCQUFZLGFBQWE7QUFDekIsWUFBTSxrQkFBa0IsV0FBVztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxtQkFBbUIsRUFBRSxRQUFRO0FBQ25DLFlBQU0scUJBQXFCLGNBQWM7QUFBQSxJQUMzQztBQUVBLFVBQU0sTUFBTSxlQUFlLENBQUM7QUFDNUIsVUFBTSxPQUFPLGFBQWEsTUFBTSxJQUFJLEVBQUUsUUFBUTtBQUM5QyxRQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JCLGlCQUFXO0FBQ1g7QUFBQSxJQUNGO0FBRUEsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxXQUFXLFFBQVE7QUFDekUsVUFBTSxrQkFBa0IsSUFBSSxxQkFBcUIsQ0FBQztBQUNsRCxvQkFBZ0IsRUFBRSxRQUFRLElBQUk7QUFDOUIsUUFBSSxvQkFBb0I7QUFDeEIsUUFBSSxDQUFDLElBQUksbUJBQW1CLFNBQVMsRUFBRSxRQUFRLEdBQUc7QUFDaEQsVUFBSSxtQkFBbUIsS0FBSyxFQUFFLFFBQVE7QUFBQSxJQUN4QztBQUNBLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsbUJBQW1CLEdBQUcsQ0FBQztBQUN0RCxnQkFBWTtBQUFBLEVBQ2Q7QUFFQSxNQUFJLFdBQVcsS0FBSyxnQkFBZ0IsS0FBSyxVQUFVLEdBQUc7QUFDcEQsVUFBTSxLQUFLLCtCQUErQixFQUFFLFVBQVUsVUFBVSxTQUFTLGNBQWMsQ0FBQztBQUFBLEVBQzFGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsU0FBUyxlQUFlLEdBQTZCO0FBQ25ELFNBQU8sZUFBZSxFQUFFLHNCQUFzQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtBQUM5RTtBQUVBLFNBQVMsa0JBQWtCLEtBQXNCO0FBQy9DLFFBQU0sUUFBUSxJQUFJLE1BQU0sR0FBRztBQUMzQixTQUFPLE1BQU0sTUFBTSxTQUFTLENBQUMsTUFBTTtBQUNyQztBQUVBLFNBQVMsbUJBQW1CLEtBQXdCO0FBQ2xELFNBQ0UsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFNBQzlCLE9BQU8sS0FBSyxJQUFJLHFCQUFxQixDQUFDLENBQUMsRUFBRSxTQUN6QyxPQUFPLEtBQUssSUFBSSx3QkFBd0IsQ0FBQyxDQUFDLEVBQUU7QUFFaEQ7QUFFQSxTQUFTLGVBQWUsTUFBMkI7QUFDakQsU0FBTyxDQUFDLEtBQUssaUJBQWlCLFlBQVksR0FBRyxLQUFLLGtCQUFrQixLQUFLLGlCQUFpQixFQUFFO0FBQUEsSUFDMUY7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHFCQUFxQixNQUE2QjtBQUN6RCxRQUFNLFFBQVEsS0FBSyxNQUFNLGdDQUFnQztBQUN6RCxTQUFPLFFBQVEsQ0FBQyxLQUFLO0FBQ3ZCO0FBRUEsU0FBUyxrQkFDUCxRQUNBLFVBQ0EsWUFDQSxVQUNBLFdBQ2U7QUFDZixRQUFNLG1CQUFtQixJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsT0FBTyxZQUFZLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQztBQUMxRixRQUFNLE9BQU8sSUFBSSxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDdkQsUUFBTSxNQUFNLG9CQUFJLElBQXlCO0FBQ3pDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksRUFBRSxlQUFlLGFBQWEsQ0FBQyxFQUFFLG1CQUFvQjtBQUN6RCxVQUFNLG9CQUFvQixpQkFBaUIsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDO0FBQzdFLFFBQUksQ0FBQyxrQkFBbUI7QUFDeEIsVUFBTSxXQUFXLEtBQUssSUFBSSxFQUFFLGtCQUFrQjtBQUM5QyxVQUFNLGlCQUNKLFVBQVUsa0JBQWtCLHFCQUFxQixFQUFFLGlCQUFpQixFQUFFLElBQUk7QUFDNUUsVUFBTSxtQkFBbUIsaUJBQ3BCLGlCQUFpQixJQUFJLGVBQWUsWUFBWSxDQUFDLEtBQUssV0FDdkQ7QUFDSixVQUFNLE9BQW9CO0FBQUEsTUFDeEIsa0JBQWtCLEVBQUU7QUFBQSxNQUNwQixzQkFBc0IsRUFBRSxjQUFjO0FBQUEsTUFDdEMsb0JBQW9CO0FBQUEsTUFDcEIsa0JBQWtCLEVBQUU7QUFBQSxNQUNwQixhQUFhLEVBQUU7QUFBQSxNQUNmLG1CQUFtQixFQUFFO0FBQUEsTUFDckIsd0JBQXdCO0FBQUEsTUFDeEIsNEJBQTRCLFVBQVUsY0FBYztBQUFBLE1BQ3BELDBCQUEwQjtBQUFBLE1BQzFCLGFBQWE7QUFBQSxNQUNiLGdCQUFnQjtBQUFBLE1BQ2hCO0FBQUEsTUFDQSxZQUFZO0FBQUEsSUFDZDtBQUNBLFFBQUksSUFBSSxlQUFlLElBQUksR0FBRyxJQUFJO0FBQUEsRUFDcEM7QUFDQSxTQUFPLENBQUMsR0FBRyxJQUFJLE9BQU8sQ0FBQztBQUN6QjtBQUVBLGVBQWUsbUJBQ2IsT0FDQSxZQUNBLFdBQ0EsVUFDaUI7QUFDakIsTUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBQy9CLFFBQU0sV0FBVyxvQkFBSSxJQUEyQjtBQUNoRCxhQUFXLFFBQVEsT0FBTztBQUN4QixVQUFNLE1BQU0sU0FBUyxJQUFJLEtBQUssZ0JBQWdCLEtBQUssQ0FBQztBQUNwRCxRQUFJLEtBQUssSUFBSTtBQUNiLGFBQVMsSUFBSSxLQUFLLGtCQUFrQixHQUFHO0FBQUEsRUFDekM7QUFDQSxNQUFJLFFBQVE7QUFDWixhQUFXLENBQUMsUUFBUSxXQUFXLEtBQUssVUFBVTtBQUM1QyxVQUFNLE1BQU0sTUFBTSxnQkFBZ0IsUUFBUSxZQUFZLFdBQVcsUUFBUTtBQUN6RSxVQUFNLFVBQVUsSUFBSSx3QkFBd0IsQ0FBQztBQUM3QyxRQUFJLGlCQUFpQjtBQUNyQixlQUFXLFFBQVEsYUFBYTtBQUM5QixZQUFNLFVBQXVCLEVBQUUsR0FBRyxNQUFNLGdCQUFnQixJQUFJLE9BQU87QUFDbkUsWUFBTSxNQUFNLGVBQWUsT0FBTztBQUNsQyxVQUFJLENBQUMsUUFBUSxHQUFHLEVBQUcsbUJBQWtCO0FBQ3JDLGNBQVEsR0FBRyxJQUFJO0FBQ2YsVUFBSSxDQUFDLElBQUksbUJBQW1CLFNBQVMsUUFBUSxnQkFBZ0IsR0FBRztBQUM5RCxZQUFJLG1CQUFtQixLQUFLLFFBQVEsZ0JBQWdCO0FBQUEsTUFDdEQ7QUFDQSxVQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxRQUFRLGlCQUFpQixHQUFHO0FBQy9ELFlBQUksbUJBQW1CLEtBQUssUUFBUSxpQkFBaUI7QUFBQSxNQUN2RDtBQUFBLElBQ0Y7QUFDQSxRQUFJLG1CQUFtQixFQUFHO0FBQzFCLFFBQUksdUJBQXVCO0FBQzNCLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsbUJBQW1CLEdBQUcsQ0FBQztBQUN0RCxhQUFTO0FBQ1QsVUFBTSxLQUFLLDBCQUEwQjtBQUFBLE1BQ25DO0FBQUEsTUFDQTtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsT0FBTyxPQUFPLEtBQUssT0FBTyxFQUFFO0FBQUEsSUFDOUIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxTQUFPO0FBQ1Q7QUFzQkEsZUFBZSxzQkFDYixRQUNBLFVBQ2U7QUFDZixNQUFJLE9BQU8sV0FBVyxFQUFHO0FBR3pCLFFBQU0sZUFBZSxvQkFBSSxJQUFZO0FBQ3JDLGFBQVcsS0FBSyxPQUFRLGNBQWEsSUFBSSxFQUFFLFFBQVE7QUFFbkQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLFFBQVE7QUFDdEIsVUFBTSxVQUFzRCxDQUFDO0FBQzdELFFBQUksRUFBRSxtQkFBbUI7QUFDdkIsY0FBUSxLQUFLLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixNQUFNLEVBQUUsaUJBQWlCLENBQUM7QUFBQSxJQUNwRTtBQUNBLFFBQUksRUFBRSxnQkFBaUIsU0FBUSxLQUFLLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixNQUFNLEtBQUssQ0FBQztBQUN6RSxRQUFJLEVBQUUsbUJBQW9CLFNBQVEsS0FBSyxFQUFFLElBQUksRUFBRSxvQkFBb0IsTUFBTSxLQUFLLENBQUM7QUFDL0UsZUFBVyxLQUFLLFNBQVM7QUFDdkIsVUFBSSxhQUFhLElBQUksRUFBRSxFQUFFLEVBQUc7QUFDNUIsVUFBSSxNQUFNLFlBQVksRUFBRSxFQUFFLEVBQUc7QUFDN0IsWUFBTSxrQkFBa0IsRUFBRSxNQUFNLEVBQUUsRUFBRTtBQUNwQyxrQkFBWTtBQUFBLElBQ2Q7QUFBQSxFQUNGO0FBQ0EsTUFBSSxXQUFXLEdBQUc7QUFDaEIsVUFBTSxLQUFLLHNEQUFzRDtBQUFBLE1BQy9EO0FBQUEsTUFDQTtBQUFBLE1BQ0EsYUFBYSxNQUFNLHFCQUFxQjtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxlQUFlLDRCQUNiLFFBQ0EsYUFDQSxVQUNlO0FBQ2YsTUFBSSxPQUFPLFdBQVcsS0FBSyxZQUFZLFNBQVMsRUFBRztBQUNuRCxNQUFJLFNBQVMsU0FBUyxhQUFhLEtBQUssU0FBUyxTQUFTLHFCQUFxQixFQUFHO0FBRWxGLFFBQU0sYUFBYSxvQkFBSSxJQUFvQjtBQUMzQyxhQUFXLEtBQUssUUFBUTtBQUN0QixVQUFNLFNBQVMsRUFBRSxlQUFlLFlBQVk7QUFDNUMsUUFBSSxDQUFDLFlBQVksSUFBSSxNQUFNLEVBQUc7QUFFOUIsVUFBTSxTQUFTLEVBQUUsbUJBQW1CLEVBQUU7QUFDdEMsVUFBTSxTQUFTLFdBQVcsRUFBRSxZQUFZLEVBQUUsc0JBQXNCO0FBQ2hFLFVBQU0sY0FBYyxFQUFFLHNCQUFzQjtBQUM1QyxRQUFJLFVBQVUsRUFBRSxjQUFjLEdBQUc7QUFDL0IsaUJBQVcsSUFBSSxRQUFRLEVBQUUsY0FBYztBQUFBLElBQ3pDLFdBQVcsZUFBZSxRQUFRO0FBQ2hDLGlCQUFXLElBQUksUUFBUSxFQUFFLGNBQWM7QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxNQUFJLFdBQVc7QUFDZixhQUFXLENBQUMsU0FBUyxNQUFNLEtBQUssWUFBWTtBQUMxQyxVQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsVUFBTSxrQkFBa0IsUUFBUSxPQUFPO0FBQ3ZDLFVBQU0sUUFBUSxNQUFNLHFCQUFxQjtBQUN6QyxRQUFJLFFBQVEsT0FBUSxhQUFZO0FBQUEsRUFDbEM7QUFDQSxNQUFJLFdBQVcsR0FBRztBQUNoQixVQUFNLEtBQUssd0NBQXdDO0FBQUEsTUFDakQ7QUFBQSxNQUNBO0FBQUEsTUFDQSxhQUFhLE1BQU0scUJBQXFCO0FBQUEsSUFDMUMsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQUVBLGVBQWUsZ0JBQ2IsUUFDQSxJQUNBLFdBQ0EsVUFDb0I7QUFDcEIsUUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBQ3JDLE1BQUksSUFBSyxRQUFPO0FBQ2hCLFFBQU0sTUFBaUI7QUFBQSxJQUNyQixRQUFRLFNBQVM7QUFBQSxJQUNqQixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixpQkFBaUI7QUFBQSxJQUNqQixjQUFjLENBQUM7QUFBQSxJQUNmLG1CQUFtQixDQUFDO0FBQUEsSUFDcEIsb0JBQW9CLENBQUM7QUFBQSxJQUNyQixnQkFBZ0IsQ0FBQyxRQUFRO0FBQUEsSUFDekIsWUFBWTtBQUFBLEVBQ2Q7QUFDQSxRQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFFBQU0sS0FBSyxlQUFlLEVBQUUsUUFBUSxLQUFLLFdBQVcsSUFBSSxNQUFNLEVBQUUsQ0FBQztBQUNqRSxTQUFPO0FBQ1Q7QUFJQSxJQUFJLGFBQTRCLFFBQVEsUUFBUTtBQWdCaEQsZUFBZSxtQkFBa0M7QUFDL0MsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLFFBQU0sVUFBb0IsQ0FBQztBQUMzQixhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUMvQyxVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksZUFBZTtBQUMzQyxRQUFJLE9BQU8sU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLGVBQWU7QUFDeEQsY0FBUSxLQUFLLE1BQU07QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsU0FBUyxNQUFNO0FBQ3BDO0FBRUEsZUFBZSw4QkFBNkM7QUFPMUQsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxLQUFNO0FBQ3hELFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxNQUFNLEtBQUssSUFBSTtBQUNyQixRQUFNLFVBQW9CLENBQUM7QUFDM0IsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELGNBQVEsS0FBSyxNQUFNO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxhQUFhLFNBQVMsTUFBTTtBQUNwQztBQUVBLGVBQWUsU0FBUyxRQUErQjtBQUNyRCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sYUFBYSxPQUFPLEtBQUssR0FBRyxHQUFHLE1BQU07QUFDN0M7QUFFQSxlQUFlLFlBQVksUUFBZ0IsUUFBK0I7QUFDeEUsUUFBTSxhQUFhLENBQUMsTUFBTSxHQUFHLE1BQU07QUFDckM7QUFFQSxlQUFlLGFBQWEsU0FBbUIsUUFBK0I7QUFDNUUsUUFBTSxTQUFTLENBQUMsR0FBRyxJQUFJLElBQUksT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7QUFDL0QsTUFBSSxPQUFPLFdBQVcsRUFBRztBQUN6QixRQUFNLE1BQU0sV0FBVyxLQUFLLE1BQU0sbUJBQW1CLFFBQVEsTUFBTSxDQUFDO0FBQ3BFLGVBQWEsSUFBSSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDL0IsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUIsU0FBbUIsUUFBK0I7QUFDbEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLFFBQXFCLENBQUM7QUFDNUIsYUFBVyxVQUFVLFNBQVM7QUFDNUIsVUFBTSxNQUFNLElBQUksTUFBTTtBQUN0QixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sU0FBUyxPQUFPLE9BQU8sSUFBSSxZQUFZO0FBQzdDLFVBQU0sb0JBQW9CLE9BQU8sT0FBTyxJQUFJLHFCQUFxQixDQUFDLENBQUM7QUFDbkUsVUFBTSxlQUFlLE9BQU8sT0FBTyxJQUFJLHdCQUF3QixDQUFDLENBQUM7QUFDakUsUUFBSSxPQUFPLFdBQVcsS0FBSyxrQkFBa0IsV0FBVyxLQUFLLGFBQWEsV0FBVyxHQUFHO0FBQ3RGLFlBQU0sZUFBZSxNQUFNO0FBQzNCLFlBQU0saUJBQWlCLFFBQVEsQ0FBQztBQUNoQztBQUFBLElBQ0Y7QUFDQSxVQUFNLEtBQUssZUFBZSxRQUFRLEtBQUssUUFBUSxtQkFBbUIsWUFBWSxDQUFDO0FBQUEsRUFDakY7QUFDQSxNQUFJLE1BQU0sV0FBVyxFQUFHO0FBRXhCLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsTUFBTTtBQUN0RCxVQUFNLEtBQUssK0NBQStDO0FBQUEsTUFDeEQsT0FBTyxNQUFNO0FBQUEsTUFDYixTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxJQUN2RCxDQUFDO0FBQ0Q7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFFBQU0sUUFBUSxNQUFNLFFBQVEsQ0FBQyxTQUFTO0FBQUEsSUFDcEM7QUFBQSxNQUNFLE1BQU0sS0FBSztBQUFBLE1BQ1gsZUFBZUMsVUFBUyxLQUFLLFVBQVUsS0FBSyxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxJQUN0RTtBQUFBLElBQ0E7QUFBQSxNQUNFLE1BQU0sS0FBSztBQUFBLE1BQ1gsZUFBZUEsVUFBUyxLQUFLLFVBQVUsS0FBSyxNQUFNLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxJQUNuRTtBQUFBLEVBQ0YsQ0FBQztBQUNELFFBQU0sWUFBWSx3QkFBd0IsS0FBSztBQUUvQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLE1BQU0sT0FBTyxZQUFZO0FBQUEsTUFDdEM7QUFBQSxNQUNBLFNBQVM7QUFBQSxJQUNYLENBQUM7QUFDRCxVQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsZUFBVyxRQUFRLE9BQU87QUFDeEIsWUFBTSxpQkFBaUIsTUFBTSwrQkFBK0IsSUFBSTtBQUtoRSxZQUFNLFFBQVEsTUFBTSxZQUFZLEdBQUcsS0FBSyxNQUFNO0FBQzlDLFlBQU0sU0FBUSxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQ2xELFlBQU0sZUFBZSxRQUFRLEtBQUssY0FBYyxRQUFRLEtBQUssYUFBYTtBQUMxRSxZQUFNLFlBQVksS0FBSyxRQUFRO0FBQUEsUUFDN0IsWUFBWSxlQUFlLEtBQUssT0FBTyxTQUFTLEtBQUssa0JBQWtCO0FBQUEsUUFDdkUsV0FBVztBQUFBLFFBQ1gsZUFBZSxLQUFLLElBQUk7QUFBQSxRQUN4QixpQkFDRyxNQUFNLGtCQUFrQixLQUFLLEtBQUssT0FBTyxTQUFTLEtBQUssa0JBQWtCO0FBQUEsUUFDNUUsZUFBZTtBQUFBLE1BQ2pCLENBQUM7QUFHRCxZQUFNLFFBQVEsSUFBSSxLQUFLLE1BQU0sS0FBSyxDQUFDO0FBQ25DLFlBQU0sVUFBUyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUN0QyxpQkFBVyxLQUFLLEtBQUssUUFBUTtBQUMzQixjQUFNLEVBQUUsUUFBUSxJQUFJO0FBQUEsVUFDbEIsSUFBSTtBQUFBLFVBQ0osS0FBSztBQUFBLFlBQ0gsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFVBQ0o7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGlCQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdEMsY0FBTSxFQUFFLFFBQVEsSUFBSTtBQUFBLFVBQ2xCLElBQUk7QUFBQSxVQUNKLEtBQUssZUFBZSxDQUFDO0FBQUEsUUFDdkI7QUFBQSxNQUNGO0FBQ0EsVUFBSSxLQUFLLE1BQU0sSUFBSTtBQUNuQixZQUFNLEtBQUssMkJBQTJCO0FBQUEsUUFDcEMsUUFBUSxLQUFLO0FBQUEsUUFDYjtBQUFBLFFBQ0EsUUFBUSxLQUFLLE9BQU87QUFBQSxRQUNwQixhQUFhLEtBQUssa0JBQWtCO0FBQUEsUUFDcEMsZUFBZSxLQUFLLGFBQWE7QUFBQSxRQUNqQyxLQUFLLEtBQUs7QUFBQSxRQUNWLE1BQU0sS0FBSztBQUFBLFFBQ1gsY0FBYyxPQUFPO0FBQUEsTUFDdkIsQ0FBQztBQUFBLElBQ0g7QUFDQSxVQUFNLGtCQUFrQixHQUFHO0FBQzNCLFVBQU0sS0FBSyxpQ0FBaUM7QUFBQSxNQUMxQztBQUFBLE1BQ0EsTUFBTSxNQUFNO0FBQUEsTUFDWixPQUFPLE1BQU07QUFBQSxNQUNiLFFBQVEsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxPQUFPLFFBQVEsQ0FBQztBQUFBLE1BQ25FLGFBQWEsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxrQkFBa0IsUUFBUSxDQUFDO0FBQUEsTUFDbkYsZUFBZSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLGFBQWEsUUFBUSxDQUFDO0FBQUEsTUFDaEYsUUFBUSxPQUFPO0FBQUEsSUFDakIsQ0FBQztBQUNEO0FBQ0UsWUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLFFBQzdCLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixRQUFJLGVBQWUsYUFBYTtBQUM5QixZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sU0FDSixJQUFJLGFBQWEsU0FDYixlQUNBLElBQUksYUFBYSxlQUNmLGlCQUNBLElBQUksYUFBYSxZQUNmLGtCQUNBLEtBQUs7QUFDZixZQUFNLGNBQWM7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTyxJQUFJO0FBQUEsUUFDWCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLFFBQzdCLGtCQUNFLElBQUksYUFBYSxlQUFlLElBQUksbUJBQW1CLEtBQUs7QUFBQSxNQUNoRSxDQUFDO0FBQ0QsWUFBTSxNQUFPLHdCQUF3QjtBQUFBLFFBQ25DO0FBQUEsUUFDQSxTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNyRCxNQUFNLE1BQU07QUFBQSxRQUNaLE9BQU8sTUFBTTtBQUFBLFFBQ2IsVUFBVSxJQUFJO0FBQUEsUUFDZCxRQUFRLElBQUk7QUFBQSxRQUNaLFNBQVMsSUFBSTtBQUFBLFFBQ2Isa0JBQWtCLElBQUk7QUFBQSxNQUN4QixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0wsWUFBTSxNQUFPLHdCQUF3QjtBQUFBLFFBQ25DO0FBQUEsUUFDQSxTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNyRCxNQUFNLE1BQU07QUFBQSxRQUNaLE9BQU8sTUFBTTtBQUFBLFFBQ2IsR0FBRyxjQUFjLEdBQUc7QUFBQSxNQUN0QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBRUYsVUFBRTtBQUNBLFVBQU0sZUFBZTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLGVBQ1AsUUFDQSxLQUNBLFFBQ0EsbUJBQ0EsY0FDVztBQUNYLFFBQU0sS0FBSyxXQUFXLElBQUksVUFBVTtBQUNwQyxRQUFNLE1BQU0sSUFBSSxXQUFXLE1BQU0sR0FBRyxFQUFFO0FBQ3RDLFFBQU0sV0FBVyxXQUFXLElBQUksTUFBTTtBQUN0QyxRQUFNLFVBQVUsT0FBTyxNQUFNLElBQUksRUFBRSxJQUFJLFFBQVE7QUFDL0MsUUFBTSxXQUFXLFFBQVEsTUFBTSxJQUFJLEVBQUUsSUFBSSxRQUFRO0FBQ2pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNQLGdCQUFnQjtBQUFBLE1BQ2hCLGdCQUFnQixJQUFJO0FBQUEsTUFDcEIsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYSxJQUFJO0FBQUEsTUFDakIsVUFBVSxJQUFJLGVBQWUsS0FBSyxHQUFHO0FBQUEsTUFDckMsWUFBWSxVQUFVO0FBQUEsTUFDdEIsWUFBWSxJQUFJO0FBQUEsTUFDaEI7QUFBQSxNQUNBLG9CQUFvQjtBQUFBLE1BQ3BCLGVBQWU7QUFBQSxJQUNqQjtBQUFBLElBQ0EsTUFBTTtBQUFBLE1BQ0osZ0JBQWdCO0FBQUEsTUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxNQUNwQixnQkFBZ0I7QUFBQSxNQUNoQixhQUFhLElBQUk7QUFBQSxNQUNqQixvQkFBb0IsSUFBSTtBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyx3QkFBd0IsT0FBNEI7QUFDM0QsTUFBSSxNQUFNLFdBQVcsR0FBRztBQUN0QixVQUFNLE9BQU8sTUFBTSxDQUFDO0FBQ3BCLFVBQU1DLG9CQUFtQixLQUFLLGtCQUFrQjtBQUNoRCxVQUFNQyxhQUFZLEtBQUssYUFBYTtBQUNwQyxVQUFNQyxXQUNIRixvQkFBbUIsSUFBSSxLQUFLQSxpQkFBZ0IsaUJBQWlCLE9BQzdEQyxhQUFZLElBQUksS0FBS0EsVUFBUyxnQkFBZ0JBLGVBQWMsSUFBSSxLQUFLLEdBQUcsS0FBSztBQUNoRixXQUFPLFlBQVksS0FBSyxNQUFNLElBQUksS0FBSyxHQUFHLElBQUksS0FBSyxPQUFPLE1BQU0sU0FBUyxLQUFLLE9BQU8sV0FBVyxJQUFJLEtBQUssR0FBRyxHQUFHQyxPQUFNLFNBQVMsS0FBSyxRQUFRO0FBQUEsRUFDN0k7QUFDQSxRQUFNLE9BQU8sQ0FBQyxHQUFHLElBQUksSUFBSSxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLO0FBQzlELFFBQU0sV0FBVyxLQUFLLFdBQVcsSUFBSSxLQUFLLENBQUMsSUFBSyxHQUFHLEtBQUssQ0FBQyxDQUFDLEtBQUssS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDO0FBQ3BGLFFBQU0sYUFBYSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQzlFLFFBQU0sbUJBQW1CLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssa0JBQWtCLFFBQVEsQ0FBQztBQUMvRixRQUFNLFlBQVksTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxhQUFhLFFBQVEsQ0FBQztBQUNuRixRQUFNLFVBQ0gsbUJBQW1CLElBQUksS0FBSyxnQkFBZ0IsaUJBQWlCLE9BQzdELFlBQVksSUFBSSxLQUFLLFNBQVMsZ0JBQWdCLGNBQWMsSUFBSSxLQUFLLEdBQUcsS0FBSztBQUNoRixTQUFPLGtCQUFrQixNQUFNLE1BQU0sVUFBVSxVQUFVLFNBQVMsZUFBZSxJQUFJLEtBQUssR0FBRyxHQUFHLE1BQU0sS0FBSyxRQUFRO0FBQ3JIO0FBRUEsZUFBZSwrQkFBK0IsTUFBa0M7QUFDOUUsUUFBTSxVQUFVLE1BQU0sYUFBYSxLQUFLLE1BQU07QUFDOUMsTUFBSSxDQUFDLFFBQVMsUUFBTztBQUNyQixNQUFJLFFBQVEsV0FBVyxLQUFLLElBQUksT0FBUSxRQUFPLG1CQUFtQixPQUFPO0FBRXpFLFFBQU0sWUFBWSxJQUFJO0FBQUEsSUFDcEIsS0FBSyxPQUFPLElBQUksQ0FBQyxNQUFNO0FBQUEsTUFDckIsRUFBRTtBQUFBLE1BQ0YsY0FBYyxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRSxZQUFZO0FBQUEsSUFDM0YsQ0FBQztBQUFBLEVBQ0g7QUFDQSxhQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdEMsY0FBVSxJQUFJLEVBQUUsVUFBVSxlQUFlLENBQUMsQ0FBQztBQUFBLEVBQzdDO0FBQ0EsUUFBTSxrQkFBa0QsQ0FBQztBQUN6RCxhQUFXLENBQUMsU0FBUyxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ25FLFVBQU0sZUFBZSxVQUFVLElBQUksT0FBTztBQUMxQyxVQUFNLGFBQWE7QUFBQSxNQUNqQixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsSUFDUjtBQUNBLFFBQUksQ0FBQyxnQkFBZ0IsaUJBQWlCLFlBQVk7QUFDaEQsc0JBQWdCLE9BQU8sSUFBSSxFQUFFLEdBQUcsTUFBTTtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sdUJBQXlELENBQUM7QUFDaEUsYUFBVyxDQUFDLFNBQVMsV0FBVyxLQUFLLE9BQU8sUUFBUSxRQUFRLHFCQUFxQixDQUFDLENBQUMsR0FBRztBQUNwRixVQUFNLGVBQWUsVUFBVSxJQUFJLE9BQU87QUFDMUMsVUFBTSxhQUFhLGVBQWUsV0FBVztBQUM3QyxRQUFJLENBQUMsZ0JBQWdCLGlCQUFpQixZQUFZO0FBQ2hELDJCQUFxQixPQUFPLElBQUksRUFBRSxHQUFHLFlBQVk7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLHdCQUFxRCxDQUFDO0FBQzVELGFBQVcsQ0FBQyxLQUFLLElBQUksS0FBSyxPQUFPLFFBQVEsUUFBUSx3QkFBd0IsQ0FBQyxDQUFDLEdBQUc7QUFDNUUsUUFBSSxDQUFDLEtBQUssYUFBYSxLQUFLLENBQUMsa0JBQWtCLGVBQWUsYUFBYSxNQUFNLEdBQUcsR0FBRztBQUNyRiw0QkFBc0IsR0FBRyxJQUFJLEVBQUUsR0FBRyxLQUFLO0FBQUEsSUFDekM7QUFBQSxFQUNGO0FBRUEsUUFBTSxlQUFlLG9CQUFJLElBQUk7QUFBQSxJQUMzQixHQUFHLE9BQU8sS0FBSyxlQUFlO0FBQUEsSUFDOUIsR0FBRyxPQUFPLEtBQUssb0JBQW9CO0FBQUEsSUFDbkMsR0FBRyxPQUFPLE9BQU8scUJBQXFCLEVBQUUsUUFBUSxDQUFDLFNBQVM7QUFBQSxNQUN4RCxLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQUEsSUFDUCxDQUFDO0FBQUEsRUFDSCxDQUFDO0FBQ0QsUUFBTSxpQkFDSixPQUFPLEtBQUssZUFBZSxFQUFFLFNBQzdCLE9BQU8sS0FBSyxvQkFBb0IsRUFBRSxTQUNsQyxPQUFPLEtBQUsscUJBQXFCLEVBQUU7QUFDckMsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLGVBQWUsS0FBSyxNQUFNO0FBQ2hDLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTSxZQUFZLFNBQVM7QUFDM0IsYUFBVyxTQUFTLE9BQU8sT0FBTyxlQUFlLEdBQUc7QUFDbEQsVUFBTSxpQkFBaUI7QUFBQSxFQUN6QjtBQUNBLGFBQVcsUUFBUSxPQUFPLE9BQU8scUJBQXFCLEdBQUc7QUFDdkQsU0FBSyxpQkFBaUI7QUFBQSxFQUN4QjtBQUNBLFFBQU0sYUFBYSxLQUFLLFFBQVE7QUFBQSxJQUM5QixHQUFHO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDUixZQUFZLFFBQVE7QUFBQSxJQUNwQixjQUFjO0FBQUEsSUFDZCxtQkFBbUI7QUFBQSxJQUNuQixzQkFBc0I7QUFBQSxJQUN0QixvQkFBb0IsUUFBUSxtQkFBbUIsT0FBTyxDQUFDLE9BQU8sYUFBYSxJQUFJLEVBQUUsQ0FBQztBQUFBLEVBQ3BGLENBQUM7QUFDRCxRQUFNLEtBQUssbUNBQW1DO0FBQUEsSUFDNUMsUUFBUSxLQUFLO0FBQUEsSUFDYixlQUFlLEtBQUs7QUFBQSxJQUNwQixVQUFVLFdBQVcsU0FBUztBQUFBLElBQzlCLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFDRCxTQUFPO0FBQ1Q7QUFJQSxlQUFlLFdBQVcsUUFBK0I7QUFDdkQsMkJBQXlCO0FBTXpCLFFBQU0sWUFBWSxpQkFBaUIsTUFBTTtBQUN6QyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsUUFBUSxLQUFLLGVBQWUsQ0FBQztBQUNuRSxNQUFJLENBQUUsTUFBTSxhQUFhLE1BQU0sR0FBSTtBQUNqQyxVQUFNLE9BQU0sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDbkMsVUFBTSxhQUFhLFFBQVE7QUFBQSxNQUN6QixRQUFRLFNBQVM7QUFBQSxNQUNqQixnQkFBZ0I7QUFBQSxNQUNoQixZQUFZO0FBQUEsTUFDWixpQkFBaUI7QUFBQSxNQUNqQixjQUFjLENBQUM7QUFBQSxNQUNmLG1CQUFtQixDQUFDO0FBQUEsTUFDcEIsb0JBQW9CLENBQUM7QUFBQSxNQUNyQixnQkFBZ0IsQ0FBQztBQUFBLE1BQ2pCLFlBQVk7QUFBQSxJQUNkLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssV0FBVyxRQUFRLEtBQUssQ0FBQztBQUM1RDtBQUVBLGVBQWUsYUFBNEI7QUFDekMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsT0FBTyxTQUFTLE9BQU8sQ0FBQztBQUM5RCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLFdBQVcsRUFBRSxNQUFNO0FBQUEsRUFDM0I7QUFDRjtBQVdBLGVBQWUsa0JBQWlDO0FBQzlDLDJCQUF5QjtBQUN6QixNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUFBLEVBQ3ZFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFDOUU7QUFBQSxFQUNGO0FBQ0EsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixNQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxZQUFZLENBQUMsSUFBSSxLQUFLO0FBQ2xELFVBQU0sS0FBSyxrQ0FBa0M7QUFDN0M7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLGdDQUFnQyxLQUFLLElBQUksR0FBRyxHQUFHO0FBQ2xELFVBQU0sS0FBSywrREFBK0Q7QUFBQSxNQUN4RSxLQUFLLFdBQVcsSUFBSSxHQUFHO0FBQUEsSUFDekIsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUd0RSxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUEsTUFDdEIsT0FBTztBQUFBLElBQ1QsQ0FBQztBQUNELFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyx1Q0FBdUMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUN0RTtBQUdBLE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTztBQUFBLE1BQ1AsTUFBTSxNQUFNO0FBQ1YsY0FBTSxJQUFJLE9BQU87QUFDakIsZUFBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUM7QUFDcEQsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLEdBQUc7QUFDM0UsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFBQSxNQUM5RTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ3pFO0FBQ0Y7QUFhQSxJQUFNLGtCQUFrQjtBQUV4QixlQUFlLGtCQUEwQztBQUN2RCxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGVBQWU7QUFDOUQsUUFBTSxLQUFLLE9BQU8sZUFBZTtBQUNqQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLGdCQUFnQixJQUFrQztBQUMvRCxNQUFJLE9BQU8sTUFBTTtBQUNmLFVBQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxlQUFlO0FBQUEsRUFDcEQsT0FBTztBQUNMLFVBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZUFBZSxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQzNEO0FBQ0Y7QUFFQSxlQUFlLG1CQUFrQztBQUMvQywyQkFBeUI7QUFDekIsUUFBTSxRQUFRLE1BQU0sa0JBQWtCO0FBQ3RDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLHlCQUF5QjtBQUNwQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0sa0JBQWtCO0FBQUEsSUFDdEIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCx1QkFBcUIsT0FBTztBQUM1QixPQUFLLFlBQVk7QUFDakIsUUFBTSxLQUFLLHdCQUF3QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMzRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLHdCQUErRDtBQUVuRSxTQUFTLHFCQUFxQixTQUF1QjtBQUNuRCxNQUFJLDBCQUEwQixLQUFNLGVBQWMscUJBQXFCO0FBQ3ZFLDBCQUF3QixZQUFZLE1BQU07QUFDeEMsU0FBSyxZQUFZLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDaEMsV0FBSyxLQUFLLHVCQUF1QixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3JELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyxzQkFBNEI7QUFDbkMsTUFBSSwwQkFBMEIsTUFBTTtBQUNsQyxrQkFBYyxxQkFBcUI7QUFDbkMsNEJBQXdCO0FBQUEsRUFDMUI7QUFDRjtBQUVBLGVBQWUsb0JBQW1DO0FBQ2hELHNCQUFvQjtBQUNwQixRQUFNLFFBQVEsT0FBTyxNQUFNLGNBQWM7QUFDekMsUUFBTSxRQUFRLE1BQU0sZ0JBQWdCO0FBQ3BDLFFBQU0sZ0JBQWdCLElBQUk7QUFDMUIsUUFBTSxPQUFPLE1BQU0sa0JBQWtCO0FBQ3JDLFFBQU0sa0JBQWtCLElBQUk7QUFDNUIsUUFBTSxLQUFLLDBCQUEwQjtBQUFBLElBQ25DLFNBQVMsVUFBVTtBQUFBLElBQ25CLFdBQVcsTUFBTSxhQUFhO0FBQUEsRUFDaEMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsY0FBNkI7QUFDMUMsTUFBSSxPQUFPLE1BQU0sa0JBQWtCO0FBQ25DLE1BQUksU0FBUyxNQUFNO0FBRWpCLHdCQUFvQjtBQUNwQjtBQUFBLEVBQ0Y7QUFJQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGdCQUFnQjtBQUM1QjtBQUFBLElBQ0Y7QUFFQSxVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsVUFBVSxLQUFLLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsSUFDYixDQUFDO0FBRUQsVUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLGVBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFVBQUksSUFBSSxTQUFTLEtBQUssU0FBUyxPQUFPLEdBQUc7QUFDdkMsY0FBTSxlQUFlLFFBQVEsS0FBSyxTQUFTLE9BQU87QUFDbEQ7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBRUEsUUFBTSxTQUFTLE1BQU0sa0JBQWtCO0FBQ3ZDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsd0JBQW9CO0FBQ3BCLFVBQU0sZ0JBQWdCLElBQUk7QUFDMUIsVUFBTSxrQkFBa0IsSUFBSTtBQUM1QixVQUFNLEtBQUsseUJBQXlCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNqRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTSxNQUFNLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDbkUsTUFBSSxRQUFRLE1BQU0sZ0JBQWdCO0FBQ2xDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxnQkFBZ0IsSUFBSSxFQUFFO0FBQUEsSUFDOUQsT0FBTztBQUNMLFlBQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQztBQUFBLElBQzFDO0FBQ0EsV0FBUSxNQUFNLGtCQUFrQixLQUFNO0FBQ3RDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxrQkFBa0IsSUFBSTtBQUM1QixVQUFNLEtBQUssZ0JBQWdCO0FBQUEsTUFDekIsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixXQUFXLE1BQU0sa0JBQWtCO0FBQUEsTUFDbkMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssNENBQTRDO0FBQUEsTUFDckQsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNLGVBQWUsT0FBTyxRQUFRLE9BQU8sT0FBTztBQUNsRCxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0sa0JBQWtCLElBQUk7QUFBQSxFQUM5QjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQVdBLElBQU0sc0JBQXNCO0FBRTVCLGVBQWUscUJBQTZDO0FBQzFELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksbUJBQW1CO0FBQ2xFLFFBQU0sS0FBSyxPQUFPLG1CQUFtQjtBQUNyQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLG1CQUFtQixJQUFrQztBQUNsRSxNQUFJLE9BQU8sS0FBTSxPQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU8sbUJBQW1CO0FBQUEsTUFDbEUsT0FBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxtQkFBbUIsR0FBRyxHQUFHLENBQUM7QUFDcEU7QUFFQSxlQUFlLHNCQUFxQztBQUNsRCwyQkFBeUI7QUFDekIsUUFBTSxRQUFRLE1BQU0scUJBQXFCO0FBQ3pDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLDZCQUE2QjtBQUN4QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCwwQkFBd0IsT0FBTztBQUMvQixPQUFLLGVBQWU7QUFDcEIsUUFBTSxLQUFLLDRCQUE0QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMvRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLDJCQUFrRTtBQUV0RSxTQUFTLHdCQUF3QixTQUF1QjtBQUN0RCxNQUFJLDZCQUE2QixLQUFNLGVBQWMsd0JBQXdCO0FBQzdFLDZCQUEyQixZQUFZLE1BQU07QUFDM0MsU0FBSyxlQUFlLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDbkMsV0FBSyxLQUFLLDJCQUEyQixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3pELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyx5QkFBK0I7QUFDdEMsTUFBSSw2QkFBNkIsTUFBTTtBQUNyQyxrQkFBYyx3QkFBd0I7QUFDdEMsK0JBQTJCO0FBQUEsRUFDN0I7QUFDRjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHlCQUF1QjtBQUN2QixRQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLFFBQVEsTUFBTSxtQkFBbUI7QUFDdkMsUUFBTSxtQkFBbUIsSUFBSTtBQUM3QixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxpQkFBZ0M7QUFDN0MsTUFBSSxPQUFPLE1BQU0scUJBQXFCO0FBQ3RDLE1BQUksU0FBUyxNQUFNO0FBQ2pCLDJCQUF1QjtBQUN2QjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGdCQUFnQjtBQUM1QjtBQUFBLElBQ0Y7QUFDQSxVQUFNLEtBQUssb0RBQW9EO0FBQUEsTUFDN0QsVUFBVSxLQUFLLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsSUFDYixDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsS0FBSyxTQUFTLE9BQU87QUFDN0MsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQUEsRUFDakM7QUFFQSxRQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsTUFBSSxDQUFDLFFBQVE7QUFDWCwyQkFBdUI7QUFDdkIsVUFBTSxtQkFBbUIsSUFBSTtBQUM3QixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sS0FBSyw2QkFBNkIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ3JFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFHQSxNQUFJLE1BQU0sWUFBWSxPQUFPLE9BQU8sR0FBRztBQUNyQyxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFPQSxRQUFNLE1BQ0osT0FBTyxXQUFXLGFBQ2QsOEJBQThCLE9BQU8sT0FBTyxLQUM1QyxpQkFBaUIsT0FBTyxNQUFNLFdBQVcsT0FBTyxPQUFPO0FBQzdELE1BQUksUUFBUSxNQUFNLG1CQUFtQjtBQUNyQyxNQUFJLFVBQVUsTUFBTTtBQUNsQixRQUFJO0FBQ0YsWUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDOUIsUUFBUTtBQUNOLGNBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixRQUFJLFVBQVUsTUFBTTtBQUNsQixZQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDNUQsVUFBSSxPQUFPLElBQUksT0FBTyxTQUFVLE9BQU0sbUJBQW1CLElBQUksRUFBRTtBQUFBLElBQ2pFLE9BQU87QUFDTCxZQUFNLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUNBLFdBQVEsTUFBTSxxQkFBcUIsS0FBTTtBQUN6QyxTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVMsT0FBTztBQUFBLE1BQ2hCLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUN0QztBQUNBLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLG9CQUFvQjtBQUFBLE1BQzdCLFVBQVUsT0FBTztBQUFBLE1BQ2pCLGFBQWEsT0FBTyxXQUFXLGFBQWEsT0FBTyxPQUFPO0FBQUEsTUFDMUQsV0FBVyxNQUFNLHFCQUFxQjtBQUFBLE1BQ3RDLFdBQVcsS0FBSztBQUFBLE1BQ2hCLGdCQUFnQixLQUFLO0FBQUEsSUFDdkIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGdEQUFnRDtBQUFBLE1BQ3pELFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQVNBLElBQU0sc0JBQXNCO0FBRTVCLGVBQWUscUJBQTZDO0FBQzFELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksbUJBQW1CO0FBQ2xFLFFBQU0sS0FBSyxPQUFPLG1CQUFtQjtBQUNyQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLG1CQUFtQixJQUFrQztBQUNsRSxNQUFJLE9BQU8sS0FBTSxPQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU8sbUJBQW1CO0FBQUEsTUFDbEUsT0FBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxtQkFBbUIsR0FBRyxHQUFHLENBQUM7QUFDcEU7QUFFQSxlQUFlLHNCQUFxQztBQUNsRCwyQkFBeUI7QUFDekIsUUFBTSxRQUFRLE1BQU0scUJBQXFCO0FBQ3pDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLDZCQUE2QjtBQUN4QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCwwQkFBd0IsT0FBTztBQUMvQixPQUFLLGVBQWU7QUFDcEIsUUFBTSxLQUFLLDRCQUE0QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMvRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLDJCQUFrRTtBQUV0RSxTQUFTLHdCQUF3QixTQUF1QjtBQUN0RCxNQUFJLDZCQUE2QixLQUFNLGVBQWMsd0JBQXdCO0FBQzdFLDZCQUEyQixZQUFZLE1BQU07QUFDM0MsU0FBSyxlQUFlLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDbkMsV0FBSyxLQUFLLDJCQUEyQixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3pELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyx5QkFBK0I7QUFDdEMsTUFBSSw2QkFBNkIsTUFBTTtBQUNyQyxrQkFBYyx3QkFBd0I7QUFDdEMsK0JBQTJCO0FBQUEsRUFDN0I7QUFDRjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHlCQUF1QjtBQUN2QixRQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLFFBQVEsTUFBTSxtQkFBbUI7QUFDdkMsUUFBTSxtQkFBbUIsSUFBSTtBQUM3QixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxpQkFBZ0M7QUFDN0MsTUFBSSxPQUFPLE1BQU0scUJBQXFCO0FBQ3RDLE1BQUksU0FBUyxNQUFNO0FBQ2pCLDJCQUF1QjtBQUN2QjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGVBQWdCO0FBQzlCLFVBQU0sS0FBSyxvREFBb0Q7QUFBQSxNQUM3RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFDRCxVQUFNLG1CQUFtQixLQUFLLFNBQVMsT0FBTztBQUM5QyxVQUFNLGtCQUFrQixLQUFLLFNBQVMsT0FBTztBQUM3QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUVBLFFBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxNQUFJLENBQUMsUUFBUTtBQUNYLDJCQUF1QjtBQUN2QixVQUFNLG1CQUFtQixJQUFJO0FBQzdCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLDZCQUE2QixFQUFFLFdBQVcsS0FBSyxVQUFVLENBQUM7QUFDckUsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLE1BQUksTUFBTSxrQkFBa0IsT0FBTyxPQUFPLEdBQUc7QUFDM0MsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTSxNQUFNLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDbkUsTUFBSSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3JDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxJQUFJLE1BQU0sd0JBQXdCO0FBQ3hFLGNBQVEsSUFBSTtBQUNaLFlBQU0sbUJBQW1CLEtBQUs7QUFBQSxJQUNoQyxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxVQUFNLG1CQUFtQixPQUFPLE9BQU87QUFDdkMsV0FBUSxNQUFNLHFCQUFxQixLQUFNO0FBQ3pDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFJLFVBQVUsTUFBTTtBQUNsQixXQUFLLG1CQUFtQixLQUFLO0FBQUEsSUFDL0I7QUFDQSxVQUFNLEtBQUssb0JBQW9CO0FBQUEsTUFDN0IsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixXQUFXLE1BQU0scUJBQXFCO0FBQUEsTUFDdEMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNLG1CQUFtQixPQUFPLE9BQU87QUFDdkMsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxtQkFBbUIsT0FBOEI7QUFDOUQsUUFBTSxJQUFJLFFBQVEsQ0FBQyxZQUFZLFdBQVcsU0FBUyxJQUFJLENBQUM7QUFDeEQsTUFBSTtBQUNGLFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsTUFBTTtBQUFBLE1BQ2hCLE9BQU87QUFBQSxNQUNQLE1BQU0sTUFBTTtBQUNWLGNBQU0sSUFBSSxPQUFPO0FBQ2pCLGNBQU0sT0FBTyxNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDO0FBQ3ZFLGFBQUs7QUFDTCxtQkFBVyxNQUFNLElBQUk7QUFDckIsbUJBQVcsTUFBTSxJQUFJO0FBQUEsTUFDdkI7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxtQ0FBbUMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUNsRTtBQUNGO0FBSUEsZUFBZSxXQUNiLFFBQ0EsVUFDQSxLQUNBLEtBQ0EsS0FDZTtBQUNmLFFBQU0sTUFBTyx3QkFBd0IsRUFBRSxRQUFRLFVBQVUsS0FBSyxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDckYsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxLQUFNO0FBQ3hELFFBQU0sVUFBNkI7QUFBQSxJQUNqQyxnQkFBZ0I7QUFBQSxJQUNoQjtBQUFBLElBQ0E7QUFBQSxJQUNBLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNwQyxZQUFZO0FBQUEsSUFDWixPQUFPLGNBQWMsR0FBRztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUNBLFFBQU0sS0FBSyxXQUFXLFFBQVEsV0FBVztBQUN6QyxRQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUssVUFBVSxPQUFPLENBQUM7QUFDL0MsUUFBTSxPQUFPLG1CQUFtQixFQUFFLElBQUksSUFBSTtBQUMxQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxRQUFRO0FBQUEsTUFDbkI7QUFBQSxNQUNBLGVBQWVILFVBQVMsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLE1BQy9ELFNBQVMsZUFBZSxNQUFNLElBQUksUUFBUTtBQUFBLElBQzVDLENBQUM7QUFBQSxFQUNILFNBQVMsTUFBTTtBQUNiLFVBQU0sTUFBTyw0QkFBNEIsRUFBRSxHQUFHLGNBQWMsSUFBSSxFQUFFLENBQUM7QUFBQSxFQUNyRTtBQUNGO0FBRUEsZUFBZSxLQUFLLEdBQTRCO0FBQzlDLFFBQU0sTUFBTSxJQUFJLFlBQVksRUFBRSxPQUFPLENBQUM7QUFDdEMsUUFBTSxTQUFTLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxHQUFHO0FBQ3hELFFBQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxXQUFXLE1BQU0sQ0FBQyxFQUMxQyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFO0FBQ1YsU0FBTyxJQUFJLE1BQU0sR0FBRyxDQUFDO0FBQ3ZCO0FBSUEsZUFBZSxpQkFBaUIsT0FBK0I7QUFDN0QsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU87QUFBQSxNQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsTUFDUCxlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsTUFBSSxDQUFDLE9BQU87QUFJVixRQUFJLEtBQUssV0FBVyxrQkFBa0IsS0FBSyxxQkFBcUIsTUFBTTtBQUNwRSxZQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDM0MsVUFBSSxTQUFTLEtBQUssaUJBQWtCO0FBQUEsSUFDdEM7QUFLQSxRQUFJLEtBQUssV0FBVztBQUNsQixZQUFNLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUztBQUNsRCxVQUFJLE1BQU0sOEJBQStCO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLElBQUksTUFBTSxPQUFPLGlCQUFpQjtBQUl4QyxRQUFJLFdBQVc7QUFDZixRQUFJLFNBQVMsVUFBVSxTQUFTLFdBQVcsRUFBRSxnQkFBZ0I7QUFDM0QsaUJBQVcsTUFBTSxPQUFPLGFBQWEsU0FBUyxNQUFNO0FBQUEsSUFDdEQ7QUFDQSxVQUFNLGFBQWEsU0FBUyxpQkFBaUIsS0FBSyxLQUFLO0FBQ3ZELFFBQUksWUFBWSxZQUFZO0FBQzFCLFlBQU0sT0FBTyxrQkFBa0I7QUFBQSxJQUNqQztBQUNBLFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU8sRUFBRTtBQUFBLE1BQ1QsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU87QUFBQSxNQUNQLGVBQWUsRUFBRTtBQUFBLE1BQ2pCLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLEtBQUssdUJBQXVCO0FBQUEsTUFDaEMsT0FBTyxFQUFFO0FBQUEsTUFDVCxNQUFNLEVBQUU7QUFBQSxNQUNSLGdCQUFnQixFQUFFO0FBQUEsTUFDbEIsbUJBQW1CLFNBQVM7QUFBQSxNQUM1QiwwQkFBMEI7QUFBQSxNQUMxQixjQUFjLGFBQWEsWUFBWTtBQUFBLElBQ3pDLENBQUM7QUFDRCxRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sS0FBSyw4Q0FBOEM7QUFBQSxRQUN2RCxZQUFZLFNBQVM7QUFBQSxRQUNyQixnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLEtBQUssd0NBQXdDLEVBQUU7QUFBQSxNQUNqRCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFNLGVBQWUsY0FBYyxJQUFJLFdBQVc7QUFDeEQsVUFBTSxTQUNKLFFBQVEsU0FDSixlQUNBLFFBQVEsZUFDTixpQkFDQSxRQUFRLFlBQ04sa0JBQ0E7QUFDVixVQUFNLFVBQ0osZUFBZSxlQUFlLFFBQVEsZUFBZSxJQUFJLG1CQUFtQjtBQUM5RSxVQUFNLGNBQWM7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU8sY0FBYyxHQUFHLEVBQUU7QUFBQSxNQUMxQixlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxLQUFLLDJCQUEyQjtBQUFBLE1BQ3BDLFVBQVU7QUFBQSxNQUNWLGtCQUFrQjtBQUFBLE1BQ2xCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLG9CQUFvQixPQUErQjtBQUNoRSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLEtBQUs7QUFDakIsVUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsT0FBTztBQUlWLFVBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBSUEsVUFBTSxnQkFBZ0IsTUFBTSx1QkFBdUI7QUFDbkQsUUFBSSxlQUFlO0FBQ2pCLFlBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sYUFBYTtBQUNqRCxVQUFJLE9BQU8sU0FBUyxHQUFHLEtBQUssTUFBTSw4QkFBK0I7QUFBQSxJQUNuRTtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxNQUFNLE9BQU8sYUFBYSxzQkFBc0I7QUFDN0QsUUFBSSxDQUFDLE1BQU07QUFDVCxVQUFJLE1BQU8sT0FBTSxLQUFLLGlEQUFpRDtBQUN2RSxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFTLGtCQUFrQixJQUFJO0FBQ3JDLFFBQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsWUFBTSxLQUFLLDhDQUE4QztBQUN6RCxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxZQUFZLE1BQU07QUFDeEIsVUFBTSx1QkFBdUIsUUFBUSxLQUFLO0FBQzFDLFVBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQsUUFBSSxNQUFPLE9BQU0sS0FBSywyQkFBMkIsRUFBRSxPQUFPLE9BQU8sT0FBTyxDQUFDO0FBQUEsRUFDM0UsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlEQUFpRCxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ2hGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSx1QkFBdUIsUUFBc0IsT0FBK0I7QUFDekYsUUFBTSxPQUFPLE1BQU0sT0FBTyxhQUFhLG9CQUFvQjtBQUMzRCxNQUFJLENBQUMsTUFBTTtBQUNULFVBQU0sbUJBQW1CLElBQUk7QUFDN0IsUUFBSSxNQUFPLE9BQU0sS0FBSywwREFBMEQ7QUFDaEY7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sV0FBVyxxQkFBcUIsS0FBSyxNQUFNLElBQUksQ0FBWTtBQUNqRSxVQUFNLG1CQUFtQixRQUFRO0FBQ2pDLFFBQUksT0FBTztBQUNULFlBQU0sS0FBSyw4QkFBOEI7QUFBQSxRQUN2QyxVQUFVLE9BQU8sS0FBSyxTQUFTLFFBQVEsRUFBRTtBQUFBLFFBQ3pDLGNBQWMsU0FBUztBQUFBLE1BQ3pCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssK0RBQStELGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDOUY7QUFDRjtBQUlBLGVBQWUsaUJBQWdDO0FBQzdDLFFBQU0sUUFBUSxNQUFNLFdBQVc7QUFDL0IsVUFBUSxRQUFRLFlBQVksRUFBRSxNQUFNLGlCQUFpQixNQUFNLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDOUU7QUFFQSxlQUFlLGFBQXNDO0FBQ25ELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxXQUFXO0FBQ2YsTUFBSTtBQUNGLFVBQU0sT0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQzNGLGVBQVcsS0FBSztBQUFBLEVBQ2xCLFFBQVE7QUFBQSxFQUdSO0FBQ0EsUUFBTSxnQkFBZ0IsTUFBTSxrQkFBa0I7QUFDOUMsUUFBTSxtQkFBbUIsTUFBTSxxQkFBcUI7QUFDcEQsUUFBTSxtQkFBbUIsTUFBTSxxQkFBcUI7QUFDcEQsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0sdUJBQXVCLE1BQU0sd0JBQXdCO0FBQzNELFNBQU87QUFBQSxJQUNMLFNBQVM7QUFBQSxJQUNULFVBQVUsZUFBZSxRQUFRO0FBQUEsSUFDakMsWUFBWTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZO0FBQUEsTUFDVixRQUFRLG1CQUFtQixRQUFRLG9CQUFvQjtBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxhQUFhLGdCQUFnQixlQUFlO0FBQUEsTUFDNUMsZUFBZSxnQkFBZ0IsaUJBQWlCO0FBQUEsTUFDaEQsa0JBQWtCLGdCQUFnQixvQkFBb0I7QUFBQSxNQUN0RCx1QkFBdUIsZ0JBQWdCLHlCQUF5QjtBQUFBLE1BQ2hFLGlCQUFpQixnQkFBZ0IsbUJBQW1CO0FBQUEsTUFDcEQsZUFBZSxnQkFBZ0IsaUJBQWlCO0FBQUEsSUFDbEQ7QUFBQSxJQUNBLGNBQWM7QUFBQSxNQUNaLE9BQU87QUFBQSxNQUNQLFNBQVMsMEJBQTBCO0FBQUEsTUFDbkMsV0FBVyxhQUFhLGFBQWE7QUFBQSxNQUNyQyxnQkFBZ0IsYUFBYSxnQkFBZ0I7QUFBQSxJQUMvQztBQUFBLElBQ0EsaUJBQWlCO0FBQUEsTUFDZixPQUFPO0FBQUEsTUFDUCxTQUFTLDZCQUE2QjtBQUFBLE1BQ3RDLFdBQVcsZ0JBQWdCLGFBQWE7QUFBQSxNQUN4QyxnQkFBZ0IsZ0JBQWdCLGdCQUFnQjtBQUFBLElBQ2xEO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxNQUNmLE9BQU87QUFBQSxNQUNQLFNBQVMsNkJBQTZCO0FBQUEsTUFDdEMsV0FBVyxnQkFBZ0IsYUFBYTtBQUFBLE1BQ3hDLGdCQUFnQixnQkFBZ0IsZ0JBQWdCO0FBQUEsSUFDbEQ7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyxlQUFlLEdBQXlDO0FBQy9ELFNBQU87QUFBQSxJQUNMLE9BQU8sRUFBRTtBQUFBLElBQ1QsTUFBTSxFQUFFO0FBQUEsSUFDUixRQUFRLEVBQUU7QUFBQSxJQUNWLFNBQVMsRUFBRTtBQUFBLElBQ1gsYUFBYSxFQUFFO0FBQUEsSUFDZixjQUFjLEVBQUU7QUFBQSxJQUNoQix1QkFBdUIsRUFBRTtBQUFBLElBQ3pCLGdCQUFnQixFQUFFO0FBQUEsSUFDbEIsc0JBQXNCLEVBQUU7QUFBQSxJQUN4QixRQUFRLEVBQUUsSUFBSSxTQUFTO0FBQUEsSUFDdkIsV0FBVyxFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSTtBQUFBLEVBQ25EO0FBQ0Y7QUFFQSxTQUFTLHFCQUFxQixLQUErQjtBQUMzRCxNQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsU0FBVSxPQUFNLElBQUksTUFBTSwyQkFBMkI7QUFDaEYsUUFBTSxXQUFXO0FBQ2pCLE1BQUksQ0FBQyxNQUFNLFFBQVEsU0FBUyxRQUFRLEVBQUcsT0FBTSxJQUFJLE1BQU0sbUNBQW1DO0FBQzFGLFFBQU0sV0FBd0MsQ0FBQztBQUMvQyxhQUFXLFNBQVMsU0FBUyxVQUFVO0FBQ3JDLFFBQUksQ0FBQyxTQUFTLE9BQU8sVUFBVSxTQUFVO0FBQ3pDLFVBQU0sTUFBTTtBQUNaLFVBQU0sU0FBUyxPQUFPLElBQUksV0FBVyxXQUFXLElBQUksU0FBUztBQUM3RCxRQUFJLENBQUMsVUFBVSxXQUFXLFFBQVM7QUFDbkMsYUFBUyxPQUFPLFlBQVksQ0FBQyxJQUFJO0FBQUEsTUFDL0I7QUFBQSxNQUNBLGdCQUFnQixPQUFPLElBQUksbUJBQW1CLFdBQVcsSUFBSSxpQkFBaUI7QUFBQSxNQUM5RSxtQkFBbUIsT0FBTyxJQUFJLHNCQUFzQixXQUFXLElBQUksb0JBQW9CO0FBQUEsTUFDdkYsV0FBVyxPQUFPLElBQUksY0FBYyxXQUFXLElBQUksWUFBWTtBQUFBLElBQ2pFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMLGNBQWMsT0FBTyxTQUFTLGlCQUFpQixXQUFXLFNBQVMsZUFBZTtBQUFBLElBQ2xGLGFBQVksb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsd0JBQXdCLEdBQW1CLFVBQTJDO0FBQzdGLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFDdEIsUUFBTSxRQUFRLFNBQVMsU0FBUyxFQUFFLGVBQWUsWUFBWSxDQUFDO0FBQzlELE1BQUksQ0FBQyxPQUFPLGVBQWdCLFFBQU87QUFDbkMsUUFBTSxTQUFTLEtBQUssTUFBTSxFQUFFLFNBQVM7QUFDckMsUUFBTSxTQUFTLEtBQUssTUFBTSxNQUFNLGNBQWM7QUFDOUMsU0FBTyxPQUFPLFNBQVMsTUFBTSxLQUFLLE9BQU8sU0FBUyxNQUFNLEtBQUssVUFBVTtBQUN6RTtBQUVBLFNBQVMsbUJBQ1AsR0FDQSxVQUNBLFFBQ0EsWUFBZ0MsT0FDaEMsU0FBa0MsWUFDbkI7QUFDZixTQUFPO0FBQUEsSUFDTCxVQUFVLEVBQUU7QUFBQSxJQUNaLGdCQUFnQixFQUFFO0FBQUEsSUFDbEIsV0FBVyxFQUFFO0FBQUEsSUFDYixNQUFNLEVBQUUsaUJBQWlCLEVBQUU7QUFBQSxJQUMzQixZQUFZLEVBQUU7QUFBQSxJQUNkLFdBQVcsRUFBRTtBQUFBLElBQ2IsU0FBUztBQUFBLElBQ1Q7QUFBQSxJQUNBLGdCQUFnQixjQUFjLGFBQWEsVUFBVTtBQUFBLElBQ3JEO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyxpQkFBaUIsU0FBaUM7QUFDekQsU0FDRSxPQUFPLFlBQVksWUFDbkIsNkVBQTZFLEtBQUssT0FBTztBQUU3RjtBQUVBLFNBQVMsV0FBVyxLQUFxQjtBQUV2QyxRQUFNLElBQUksSUFBSSxLQUFLLEdBQUc7QUFDdEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPLElBQUksUUFBUSxTQUFTLEVBQUU7QUFDN0QsUUFBTSxNQUFNLENBQUMsR0FBVyxJQUFJLE1BQU0sT0FBTyxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUc7QUFDM0QsU0FDRSxHQUFHLEVBQUUsZUFBZSxDQUFDLElBQUksSUFBSSxFQUFFLFlBQVksSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFDcEUsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDO0FBRTlFO0FBRUEsU0FBUyxVQUFVLEdBQXFCO0FBQ3RDLFNBQU8sV0FBVyxFQUFFLEtBQUssY0FBYyxFQUFFLElBQUk7QUFDL0M7QUFTQSxTQUFTLGVBQWUsTUFBeUI7QUFDL0MsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNSSxPQUFNO0FBQ1osVUFBSSxPQUFPQSxLQUFJLGVBQWUsU0FBVSxNQUFLLElBQUlBLEtBQUksVUFBVTtBQUMvRCxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsU0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLEtBQUs7QUFDeEI7QUFPQSxTQUFTLG9CQUFvQixNQUFlLFVBQW1DO0FBQzdFLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUEsT0FBTTtBQUNaLFVBQUlBLEtBQUksZUFBZSxVQUFVO0FBQy9CLGVBQU8sT0FBTyxLQUFLQSxJQUFHLEVBQUUsS0FBSztBQUFBLE1BQy9CO0FBQ0EsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQVFBLFNBQVMsaUJBQWlCLE1BQWUsVUFBa0IsTUFBeUI7QUFDbEYsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLE1BQUksUUFBd0M7QUFDNUMsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1BLE9BQU07QUFDWixVQUFJQSxLQUFJLGVBQWUsVUFBVTtBQUMvQixnQkFBUUE7QUFDUjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixNQUFJLE1BQWU7QUFDbkIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVUsUUFBTyxJQUFJLFFBQVEsT0FBTyxTQUFTLE9BQU8sR0FBRztBQUMxRixVQUFPLElBQWdDLEdBQUc7QUFBQSxFQUM1QztBQUNBLE1BQUksUUFBUSxPQUFXLFFBQU87QUFDOUIsTUFBSSxRQUFRLEtBQU0sUUFBTztBQUN6QixNQUFJLE9BQU8sUUFBUSxTQUFVLFFBQU8sSUFBSSxPQUFPLEdBQUc7QUFDbEQsTUFBSSxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sY0FBYyxJQUFJLE1BQU07QUFDdkQsU0FBTyxPQUFPLEtBQUssR0FBOEIsRUFBRSxLQUFLO0FBQzFEO0FBRUEsU0FBUyxXQUFXLEdBQW1CO0FBR3JDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFDeEIsVUFBTSxPQUFPLE9BQU8sWUFBWSxPQUFPLFNBQVMsWUFBTztBQUN2RCxXQUFPLE9BQU8sU0FBUyxXQUFXLE9BQU8sU0FBUyxnQkFDOUMsT0FDQSxHQUFHLE9BQU8sSUFBSSxHQUFHLElBQUk7QUFBQSxFQUMzQixRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQ7QUFDRjtBQUtDLFdBQXVDLGVBQWU7QUFBQSxFQUNyRDtBQUFBLEVBQ0EsVUFBVTtBQUFBLEVBQ1YsVUFBVTtBQUFBLEVBQ1YsU0FBUztBQUFBLEVBQ1QsVUFBVSxNQUFNLFNBQVMsVUFBVTtBQUFBLEVBQ25DLE9BQU87QUFBQSxFQUNQLGNBQWM7QUFBQSxFQUNkLGNBQWM7QUFBQSxFQUNkLGVBQWU7QUFBQSxFQUNmLGlCQUFpQjtBQUFBLEVBQ2pCLGlCQUFpQjtBQUFBLEVBQ2pCLGtCQUFrQjtBQUFBLEVBQ2xCLGlCQUFpQjtBQUFBLEVBQ2pCLGlCQUFpQjtBQUFBLEVBQ2pCLGtCQUFrQjtBQUNwQjsiLAogICJuYW1lcyI6IFsidG9CYXNlNjQiLCAib2JqIiwgImluZm8iLCAidG9CYXNlNjQiLCAidW5hdmFpbGFibGVDb3VudCIsICJlZGdlQ291bnQiLCAic3VmZml4IiwgIm9iaiJdCn0K
