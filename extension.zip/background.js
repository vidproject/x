// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  threadOpenQueue: {},
  threadOpenSeen: {},
  refetchSession: null,
  mediaCrawlSession: null,
  threadOpenSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function setArchiveSnapshot(snapshot) {
  await setRaw("archiveSnapshot", snapshot);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
var RECENT_TWEET_SIGHTINGS_MAX = 80;
async function getRecentTweetSightings() {
  return getRaw("recentTweetSightings");
}
async function prependRecentTweetSightings(rows) {
  if (rows.length === 0) return;
  const cur = await getRecentTweetSightings();
  const seen = /* @__PURE__ */ new Set();
  const next = [];
  for (const row of rows) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  for (const row of cur) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  next.length = Math.min(next.length, RECENT_TWEET_SIGHTINGS_MAX);
  await setRaw("recentTweetSightings", next);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function getThreadOpenQueue() {
  return getRaw("threadOpenQueue");
}
async function threadOpenQueueTotal() {
  const q = await getThreadOpenQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function hasThreadOpenSeen(tweetId) {
  const seen = await getRaw("threadOpenSeen");
  return tweetId in seen;
}
async function markThreadOpenSeen(tweetId) {
  const seen = await getRaw("threadOpenSeen");
  seen[tweetId] = (/* @__PURE__ */ new Date()).toISOString();
  await setRaw("threadOpenSeen", seen);
}
async function enqueueThreadOpen(handle, tweetId) {
  if (await hasThreadOpenSeen(tweetId)) return;
  const q = await getThreadOpenQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("threadOpenQueue", q);
  }
}
async function dequeueThreadOpen(tweetId) {
  const q = await getThreadOpenQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("threadOpenQueue", q);
}
async function nextThreadOpenTarget() {
  const q = await getThreadOpenQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getThreadOpenSession() {
  return getRaw("threadOpenSession");
}
async function setThreadOpenSession(s) {
  await setRaw("threadOpenSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  const tq = await getThreadOpenQueue();
  let threadOpenIdsRemoved = 0;
  for (const h of Object.keys(tq)) {
    if (!isTargeted(h)) {
      threadOpenIdsRemoved += (tq[h] ?? []).length;
      delete tq[h];
    }
  }
  await setRaw("threadOpenQueue", tq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved,
    threadOpenIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Verify the PAT can write to the configured branch without creating a
   * commit. Moving a ref to its current SHA is a no-op, but GitHub still
   * enforces the Contents: Write permission required by commitFiles().
   */
  async verifyWriteAccess() {
    const head = await this.getBranchHead();
    await this.fetchJson(
      "PATCH",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
      {
        sha: head.sha,
        force: false
      }
    );
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const unavailableTweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const unavailable = pickUnavailableTweet(raw, ctx);
      if (unavailable) {
        unavailableTweets.push(unavailable);
        observed.push(unavailable.tweet_id);
        built.add(unavailable.tweet_id);
        continue;
      }
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, unavailable_tweets: unavailableTweets, partial_ids };
}
function pickUnavailableTweet(node, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename !== "TweetTombstone") return null;
  const tweetId = strOrNull(n.rest_id) ?? pickTweetIdFromUrls(node) ?? (ctx.sourceUrl ? tweetIdFromTweetUrl(ctx.sourceUrl) : null);
  if (!tweetId || !TWEET_ID_RE.test(tweetId)) return null;
  const unavailableText = pickTombstoneText(node);
  return {
    tweet_id: tweetId,
    account_handle: pickHandleFromTweetUrls(node, tweetId) ?? (ctx.sourceUrl ? handleFromTweetUrl(ctx.sourceUrl, tweetId) : null),
    unavailable_detected_at: ctx.capturedAt,
    unavailable_reason: classifyUnavailableReason(unavailableText),
    unavailable_text: unavailableText,
    unavailable_source_url: ctx.sourceUrl ?? null
  };
}
function pickTweetIdFromUrls(node) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const id = tweetIdFromTweetUrl(cur);
      if (id) return id;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function tweetIdFromTweetUrl(rawUrl) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/[A-Za-z0-9_]{1,15}\/status\/(\d{15,20})(?:\/|$)/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
function pickTombstoneText(node) {
  const strings = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const trimmed = cur.trim();
      if (trimmed.length >= 4 && !trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
        strings.push(trimmed);
      }
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  const preferred = strings.find(
    (s) => /\b(copyright|dmca|unavailable|withheld|removed|deleted|violat|suspended)\b/i.test(s)
  );
  return preferred ?? strings[0] ?? null;
}
function classifyUnavailableReason(text) {
  if (!text) return null;
  if (/\b(copyright|dmca)\b/i.test(text)) return "copyright";
  if (/\bwithheld\b/i.test(text)) return "withheld";
  if (/\bdeleted|removed\b/i.test(text)) return "removed";
  if (/\bsuspended\b/i.test(text)) return "suspended";
  if (/\bunavailable|not available\b/i.test(text)) return "unavailable";
  return null;
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  const hintHandle = pickHintHandle(node, restId);
  if (!hintHandle) return null;
  return { tweet_id: restId, hint_handle: hintHandle };
}
function pickHintHandle(node, tweetId) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name) ?? pickHandleFromTweetUrls(node, tweetId);
}
function pickHandleFromTweetUrls(node, tweetId) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const handle = handleFromTweetUrl(cur, tweetId);
      if (handle) return handle;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function handleFromTweetUrl(rawUrl, tweetId) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d{15,20})(?:\/|$)/);
    if (!match || match[2] !== tweetId) return null;
    return match[1] ?? null;
  } catch {
    return null;
  }
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    unavailable_detected_at: null,
    unavailable_reason: null,
    unavailable_text: null,
    unavailable_source_url: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted, coreHandles = /* @__PURE__ */ new Set()) {
  if (targeted.size === 0 && coreHandles.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (coreHandles.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
var MANUAL_CAPTURE_WINDOW_MS = 9e4;
var manualCaptureUntilMs = 0;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
function allowManualCaptureWindow() {
  manualCaptureUntilMs = Date.now() + MANUAL_CAPTURE_WINDOW_MS;
}
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var SHOW_MORE_RELEVANCE_TTL_MS = 10 * 60 * 1e3;
var showMoreRelevantTweetsByTab = /* @__PURE__ */ new Map();
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  allowManualCaptureWindow();
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    ingestedNewCount: 0,
    ingestedExistingCount: 0,
    skippedOldCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: () => {
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
        }
      });
      scrollCount += 1;
    } catch {
    }
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      await setAutoScrollSession(sess);
    }
  }
}
function pruneShowMoreRelevance() {
  const cutoff = Date.now() - SHOW_MORE_RELEVANCE_TTL_MS;
  for (const [tabId, entry] of showMoreRelevantTweetsByTab) {
    if (entry.updatedAt < cutoff) showMoreRelevantTweetsByTab.delete(tabId);
  }
}
function rememberShowMoreRelevantTweets(tabId, pageUrl, tweets, coreHandles) {
  if (tabId === null || tweets.length === 0 || coreHandles.size === 0) return;
  const coreTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (coreHandles.has(t.account_handle.toLowerCase())) coreTweetIds.add(t.tweet_id);
  }
  const existing = showMoreRelevantTweetsByTab.get(tabId);
  const tweetIds = existing?.tweetIds ?? /* @__PURE__ */ new Set();
  for (const t of tweets) {
    const handle = t.account_handle.toLowerCase();
    const replyHandle = t.reply_to_account?.toLowerCase() ?? null;
    if (coreHandles.has(handle) || replyHandle !== null && coreHandles.has(replyHandle) || t.reply_to_tweet_id !== null && coreTweetIds.has(t.reply_to_tweet_id) || t.quoted_tweet_id !== null && coreTweetIds.has(t.quoted_tweet_id) || t.retweeted_tweet_id !== null && coreTweetIds.has(t.retweeted_tweet_id)) {
      tweetIds.add(t.tweet_id);
    }
  }
  showMoreRelevantTweetsByTab.set(tabId, {
    updatedAt: Date.now(),
    pageUrl,
    tweetIds
  });
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg, sender).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-thread-open",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg, sender) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(
        msg.endpoint,
        msg.url,
        msg.pageUrl ?? null,
        msg.response,
        sender?.tab?.id ?? null
      );
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-unfold-targets": {
      const settings = await getSettings();
      if (settings.enabled === false) {
        return { enabled: false, coreHandles: [], relevantTweetIds: [] };
      }
      pruneShowMoreRelevance();
      const accounts = await getAccounts();
      const coreHandles = accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase());
      const tabId = sender?.tab?.id ?? null;
      return {
        enabled: true,
        coreHandles,
        relevantTweetIds: tabId === null ? [] : Array.from(showMoreRelevantTweetsByTab.get(tabId)?.tweetIds ?? [])
      };
    }
    case "show-more-unfolded": {
      if (msg.count > 0) {
        const asSess = await getAutoScrollSession();
        if (asSess !== null) {
          asSess.expandedCount += msg.count;
          await setAutoScrollSession(asSess);
        }
      }
      return { ok: true };
    }
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-update-existing":
      await updateSettings({ updateExisting: msg.on });
      await info("update-existing toggled", { on: msg.on });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        stopThreadOpenInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
        await browser.alarms.clear("thread-open-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      if (threadOpenIntervalHandle !== null) startThreadOpenInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "start-thread-open":
      await startThreadOpenLoop();
      return buildState();
    case "cancel-thread-open":
      await cancelThreadOpenLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, pageUrl, response, senderTabId) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const settings = await getSettings();
  if (settings.enabled === false) return;
  if (settings.autoCapture === false) {
    const explicitCaptureActive = Date.now() < manualCaptureUntilMs || await getAutoScrollSession() !== null || await getRefetchSession() !== null || await getMediaCrawlSession() !== null;
    if (!explicitCaptureActive) return;
  }
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const core = new Set(
    accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase())
  );
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set(),
      sourceUrl: pageUrl
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const retweetEdges = buildRetweetEdges(
    normalized.tweets,
    accounts,
    capturedAt,
    endpoint,
    pageUrl ?? url
  );
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked, core);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  rememberShowMoreRelevantTweets(senderTabId, pageUrl, normalized.tweets, core);
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.unavailable_tweets.length > 0) {
    await recordUnavailableTweets(
      normalized.unavailable_tweets,
      tracked,
      capturedAt,
      url,
      endpoint
    );
  }
  if (normalized.tweets.length === 0) {
    const bufferedEdges = await bufferRetweetEdges(retweetEdges, capturedAt, pageUrl ?? url, endpoint);
    if (bufferedEdges > 0) await broadcastState();
    return;
  }
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    if (threadOpenSess?.inflight?.tweetId === t.tweet_id) {
      threadOpenSess.inflight = null;
      threadOpenSess.processed += 1;
      await markThreadOpenSeen(t.tweet_id);
      await dequeueThreadOpen(t.tweet_id);
      await setThreadOpenSession(threadOpenSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const updateExisting = settings.updateExisting !== false;
  const committedIdx = await getCommittedIndex();
  const archiveSnapshot = await getArchiveSnapshot();
  let dedupedSkipped = 0;
  let skippedNoUpdateLocal = 0;
  let skippedNoUpdateSnapshot = 0;
  let oldFromSnapshot = 0;
  let fullTextUpgrades = 0;
  const liveTweets = [];
  const freshnessById = /* @__PURE__ */ new Map();
  const actionById = /* @__PURE__ */ new Map();
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const oldBySnapshot = !prev && archiveSnapshotHasTweet(t, archiveSnapshot);
    const previouslyArchived = Boolean(prev) || oldBySnapshot;
    freshnessById.set(t.tweet_id, previouslyArchived ? "existing" : "new");
    if (oldBySnapshot) oldFromSnapshot += 1;
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    const fullTextUpgrade = prev !== void 0 && sigMarksTruncated(prev.sig) && !t.is_truncated;
    if (previouslyArchived && !updateExisting && !fullTextUpgrade) {
      if (prev) skippedNoUpdateLocal += 1;
      else skippedNoUpdateSnapshot += 1;
      actionById.set(t.tweet_id, "skipped");
      continue;
    }
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      actionById.set(t.tweet_id, "unchanged");
      continue;
    }
    if (fullTextUpgrade) fullTextUpgrades += 1;
    actionById.set(t.tweet_id, "buffered");
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (skippedNoUpdateLocal + skippedNoUpdateSnapshot > 0) {
    const skippedOld = skippedNoUpdateLocal + skippedNoUpdateSnapshot;
    await info("dedup: skipped previously archived tweets (updateExisting=false)", {
      endpoint,
      skipped: skippedOld,
      local_index: skippedNoUpdateLocal,
      archive_snapshot: skippedNoUpdateSnapshot,
      remaining: liveTweets.length
    });
    const asSess = await getAutoScrollSession();
    if (asSess !== null) {
      asSess.skippedOldCount = (asSess.skippedOldCount ?? 0) + skippedOld;
      await setAutoScrollSession(asSess);
    }
  }
  if (oldFromSnapshot > 0 && updateExisting) {
    await info("archive snapshot recognized old tweets", {
      endpoint,
      old: oldFromSnapshot,
      action: "buffering because updateExisting=true",
      snapshot_generated_at: archiveSnapshot?.generated_at ?? null
    });
  }
  if (fullTextUpgrades > 0) {
    await info("dedup: buffering full-text upgrades", {
      endpoint,
      upgrades: fullTextUpgrades,
      updateExisting,
      remaining: liveTweets.length
    });
  }
  await prependRecentTweetSightings(
    normalized.tweets.map(
      (t) => buildTweetSighting(t, endpoint, capturedAt, freshnessById.get(t.tweet_id), actionById.get(t.tweet_id))
    )
  );
  await enqueueMissingParents(normalized.tweets, endpoint);
  await enqueueThreadOpenCandidates(normalized.tweets, core, endpoint);
  const bufferedRetweetEdges = await bufferRetweetEdges(
    retweetEdges,
    capturedAt,
    pageUrl ?? url,
    endpoint
  );
  if (liveTweets.length === 0) {
    if (bufferedRetweetEdges > 0) await broadcastState();
    return;
  }
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    let addedNew = 0;
    let addedExisting = 0;
    let updatedBuffered = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
        updatedBuffered += 1;
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
        if (freshnessById.get(t.tweet_id) === "existing") addedExisting += 1;
        else addedNew += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    if (added > 0 || updatedBuffered > 0) {
      await info("buffered tweets", {
        handle,
        endpoint,
        added,
        new: addedNew,
        existing: addedExisting,
        updated_buffered: updatedBuffered,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        asSess.ingestedNewCount = (asSess.ingestedNewCount ?? 0) + addedNew;
        asSess.ingestedExistingCount = (asSess.ingestedExistingCount ?? 0) + addedExisting;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function recordUnavailableTweets(unavailableTweets, tracked, capturedAt, sourceUrl, endpoint) {
  const committedIdx = await getCommittedIndex();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  let recorded = 0;
  let skipped = 0;
  let missingHandle = 0;
  for (const u of unavailableTweets) {
    const handle = u.account_handle;
    if (!handle) {
      missingHandle += 1;
      await dequeueMediaCrawl(u.tweet_id);
      await dequeueThreadOpen(u.tweet_id);
      continue;
    }
    if (tracked.size > 0 && !tracked.has(handle.toLowerCase())) {
      skipped += 1;
      continue;
    }
    await dequeueMediaCrawl(u.tweet_id);
    await dequeueRefetch(handle, u.tweet_id);
    await dequeueThreadOpen(u.tweet_id);
    if (refetchSess?.inflight?.tweetId === u.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === u.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    if (threadOpenSess?.inflight?.tweetId === u.tweet_id) {
      threadOpenSess.inflight = null;
      threadOpenSess.processed += 1;
      await markThreadOpenSeen(u.tweet_id);
      await setThreadOpenSession(threadOpenSess);
    }
    const sig = unavailableSig(u);
    const prev = committedIdx[handle]?.[u.tweet_id];
    if (prev?.sig === sig) {
      skipped += 1;
      continue;
    }
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const unavailableById = buf.unavailable_by_id ?? {};
    unavailableById[u.tweet_id] = u;
    buf.unavailable_by_id = unavailableById;
    if (!buf.tweet_ids_observed.includes(u.tweet_id)) {
      buf.tweet_ids_observed.push(u.tweet_id);
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    recorded += 1;
  }
  if (recorded > 0 || missingHandle > 0 || skipped > 0) {
    await info("unavailable tweets observed", { endpoint, recorded, skipped, missingHandle });
  }
  await broadcastState();
}
function unavailableSig(u) {
  return `unavailable|${u.unavailable_reason ?? ""}|${u.unavailable_text ?? ""}`;
}
function sigMarksTruncated(sig) {
  const parts = sig.split("|");
  return parts[parts.length - 1] === "t";
}
function runBufferItemCount(buf) {
  return Object.keys(buf.tweets_by_id).length + Object.keys(buf.unavailable_by_id ?? {}).length + Object.keys(buf.retweet_edges_by_key ?? {}).length;
}
function retweetEdgeKey(edge) {
  return [
    edge.retweeter_handle.toLowerCase(),
    edge.retweet_tweet_id,
    edge.original_tweet_id
  ].join("|");
}
function inferRetweetedHandle(text) {
  const match = text.match(/^RT\s+@([A-Za-z0-9_]{1,15})\b/i);
  return match?.[1] ?? null;
}
function buildRetweetEdges(tweets, accounts, capturedAt, endpoint, sourceUrl) {
  const categoryByHandle = new Map(accounts.map((a) => [a.handle.toLowerCase(), a.category]));
  const byId = new Map(tweets.map((t) => [t.tweet_id, t]));
  const out = /* @__PURE__ */ new Map();
  for (const t of tweets) {
    if (t.tweet_type !== "retweet" || !t.retweeted_tweet_id) continue;
    const retweeterCategory = categoryByHandle.get(t.account_handle.toLowerCase());
    if (!retweeterCategory) continue;
    const original = byId.get(t.retweeted_tweet_id);
    const originalHandle = original?.account_handle ?? inferRetweetedHandle(t.text_resolved || t.text);
    const originalCategory = originalHandle ? categoryByHandle.get(originalHandle.toLowerCase()) ?? "public" : null;
    const edge = {
      retweeter_handle: t.account_handle,
      retweeter_account_id: t.account_id ?? null,
      retweeter_category: retweeterCategory,
      retweet_tweet_id: t.tweet_id,
      retweet_url: t.tweet_url,
      original_tweet_id: t.retweeted_tweet_id,
      original_author_handle: originalHandle,
      original_author_account_id: original?.account_id ?? null,
      original_author_category: originalCategory,
      captured_at: capturedAt,
      capture_run_id: "pending",
      endpoint,
      source_url: sourceUrl
    };
    out.set(retweetEdgeKey(edge), edge);
  }
  return [...out.values()];
}
async function bufferRetweetEdges(edges, capturedAt, sourceUrl, endpoint) {
  if (edges.length === 0) return 0;
  const byHandle = /* @__PURE__ */ new Map();
  for (const edge of edges) {
    const arr = byHandle.get(edge.retweeter_handle) ?? [];
    arr.push(edge);
    byHandle.set(edge.retweeter_handle, arr);
  }
  let added = 0;
  for (const [handle, handleEdges] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const edgeMap = buf.retweet_edges_by_key ?? {};
    let addedForHandle = 0;
    for (const edge of handleEdges) {
      const stamped = { ...edge, capture_run_id: buf.run_id };
      const key = retweetEdgeKey(stamped);
      if (!edgeMap[key]) addedForHandle += 1;
      edgeMap[key] = stamped;
      if (!buf.tweet_ids_observed.includes(stamped.retweet_tweet_id)) {
        buf.tweet_ids_observed.push(stamped.retweet_tweet_id);
      }
      if (!buf.tweet_ids_observed.includes(stamped.original_tweet_id)) {
        buf.tweet_ids_observed.push(stamped.original_tweet_id);
      }
    }
    if (addedForHandle === 0) continue;
    buf.retweet_edges_by_key = edgeMap;
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    added += addedForHandle;
    await info("buffered retweet edges", {
      handle,
      endpoint,
      added: addedForHandle,
      total: Object.keys(edgeMap).length
    });
  }
  return added;
}
async function enqueueMissingParents(tweets, endpoint) {
  if (tweets.length === 0) return;
  const sameBatchIds = /* @__PURE__ */ new Set();
  for (const t of tweets) sameBatchIds.add(t.tweet_id);
  let enqueued = 0;
  for (const t of tweets) {
    const parents = [];
    if (t.reply_to_tweet_id) {
      parents.push({ id: t.reply_to_tweet_id, hint: t.reply_to_account });
    }
    if (t.quoted_tweet_id) parents.push({ id: t.quoted_tweet_id, hint: null });
    if (t.retweeted_tweet_id) parents.push({ id: t.retweeted_tweet_id, hint: null });
    for (const p of parents) {
      if (sameBatchIds.has(p.id)) continue;
      if (await isCommitted(p.id)) continue;
      await enqueueMediaCrawl(p.hint, p.id);
      enqueued += 1;
    }
  }
  if (enqueued > 0) {
    await info("queued missing parent tweets for detail-page crawl", {
      endpoint,
      enqueued,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
}
async function enqueueThreadOpenCandidates(tweets, coreHandles, endpoint) {
  if (tweets.length === 0 || coreHandles.size === 0) return;
  if (endpoint.includes("TweetDetail") || endpoint.includes("TweetResultByRestId")) return;
  const candidates = /* @__PURE__ */ new Map();
  for (const t of tweets) {
    const handle = t.account_handle.toLowerCase();
    if (!coreHandles.has(handle)) continue;
    const rootId = t.conversation_id ?? t.tweet_id;
    const isRoot = rootId === t.tweet_id || t.reply_to_tweet_id === null;
    const isCoreReply = t.reply_to_tweet_id !== null;
    if (isRoot && t.reply_count > 0) {
      candidates.set(rootId, t.account_handle);
    } else if (isCoreReply && rootId) {
      candidates.set(rootId, t.account_handle);
    }
  }
  let enqueued = 0;
  for (const [tweetId, handle] of candidates) {
    const before = await threadOpenQueueTotal();
    await enqueueThreadOpen(handle, tweetId);
    const after = await threadOpenQueueTotal();
    if (after > before) enqueued += 1;
  }
  if (enqueued > 0) {
    await info("queued core thread roots for opening", {
      endpoint,
      enqueued,
      queue_total: await threadOpenQueueTotal()
    });
  }
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    unavailable_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    const unavailableTweets = Object.values(buf.unavailable_by_id ?? {});
    const retweetEdges = Object.values(buf.retweet_edges_by_key ?? {});
    if (tweets.length === 0 && unavailableTweets.length === 0 && retweetEdges.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets, unavailableTweets, retweetEdges));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("upload buffer deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length + item.unavailableTweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length + item.unavailableTweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      for (const u of item.unavailableTweets) {
        inner[u.tweet_id] = {
          ts: nowIso,
          sig: unavailableSig(u)
        };
      }
      idx[item.handle] = inner;
      await info("upload buffer committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        unavailable: item.unavailableTweets.length,
        retweet_edges: item.retweetEdges.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("upload buffer batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      unavailable: items.reduce((total, item) => total + item.unavailableTweets.length, 0),
      retweet_edges: items.reduce((total, item) => total + item.retweetEdges.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("upload buffer failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("upload buffer failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets, unavailableTweets, retweetEdges) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    unavailableTweets,
    retweetEdges,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets,
      unavailable_tweets: unavailableTweets,
      retweet_edges: retweetEdges
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    const unavailableCount2 = item.unavailableTweets.length;
    const edgeCount2 = item.retweetEdges.length;
    const suffix2 = (unavailableCount2 > 0 ? `, ${unavailableCount2} unavailable` : "") + (edgeCount2 > 0 ? `, ${edgeCount2} retweet edge${edgeCount2 === 1 ? "" : "s"}` : "");
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"}${suffix2} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  const unavailableCount = items.reduce((total, item) => total + item.unavailableTweets.length, 0);
  const edgeCount = items.reduce((total, item) => total + item.retweetEdges.length, 0);
  const suffix = (unavailableCount > 0 ? `, ${unavailableCount} unavailable` : "") + (edgeCount > 0 ? `, ${edgeCount} retweet edge${edgeCount === 1 ? "" : "s"}` : "");
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"}${suffix} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return runBufferItemCount(current);
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  for (const u of item.unavailableTweets) {
    committed.set(u.tweet_id, unavailableSig(u));
  }
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingUnavailable = {};
  for (const [tweetId, unavailable] of Object.entries(current.unavailable_by_id ?? {})) {
    const committedSig = committed.get(tweetId);
    const currentSig = unavailableSig(unavailable);
    if (!committedSig || committedSig !== currentSig) {
      remainingUnavailable[tweetId] = { ...unavailable };
    }
  }
  const remainingRetweetEdges = {};
  for (const [key, edge] of Object.entries(current.retweet_edges_by_key ?? {})) {
    if (!item.retweetEdges.some((committedEdge) => retweetEdgeKey(committedEdge) === key)) {
      remainingRetweetEdges[key] = { ...edge };
    }
  }
  const remainingIds = /* @__PURE__ */ new Set([
    ...Object.keys(remainingTweets),
    ...Object.keys(remainingUnavailable),
    ...Object.values(remainingRetweetEdges).flatMap((edge) => [
      edge.retweet_tweet_id,
      edge.original_tweet_id
    ])
  ]);
  const remainingCount = Object.keys(remainingTweets).length + Object.keys(remainingUnavailable).length + Object.keys(remainingRetweetEdges).length;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  for (const edge of Object.values(remainingRetweetEdges)) {
    edge.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    unavailable_by_id: remainingUnavailable,
    retweet_edges_by_key: remainingRetweetEdges,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => remainingIds.has(id))
  });
  await info("upload buffer kept newer tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  allowManualCaptureWindow();
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      unavailable_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  allowManualCaptureWindow();
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  allowManualCaptureWindow();
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  allowManualCaptureWindow();
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = target.bucket === "_unknown" ? `https://x.com/i/web/status/${target.tweetId}` : `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
var THREAD_OPEN_TAB_KEY = "__imm_archive_thread_open_tab_id__";
async function getThreadOpenTabId() {
  const stored = await browser.storage.local.get(THREAD_OPEN_TAB_KEY);
  const id = stored[THREAD_OPEN_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setThreadOpenTabId(id) {
  if (id === null) await browser.storage.local.remove(THREAD_OPEN_TAB_KEY);
  else await browser.storage.local.set({ [THREAD_OPEN_TAB_KEY]: id });
}
async function startThreadOpenLoop() {
  allowManualCaptureWindow();
  const total = await threadOpenQueueTotal();
  if (total === 0) {
    await info("thread-open: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setThreadOpenSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startThreadOpenInterval(seconds);
  void threadOpenTick();
  await info("thread-open loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var threadOpenIntervalHandle = null;
function startThreadOpenInterval(seconds) {
  if (threadOpenIntervalHandle !== null) clearInterval(threadOpenIntervalHandle);
  threadOpenIntervalHandle = setInterval(() => {
    void threadOpenTick().catch((err) => {
      void warn("thread-open tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopThreadOpenInterval() {
  if (threadOpenIntervalHandle !== null) {
    clearInterval(threadOpenIntervalHandle);
    threadOpenIntervalHandle = null;
  }
}
async function cancelThreadOpenLoop() {
  stopThreadOpenInterval();
  await browser.alarms.clear("thread-open-tick");
  const tabId = await getThreadOpenTabId();
  await setThreadOpenTabId(null);
  const sess = await getThreadOpenSession();
  await setThreadOpenSession(null);
  await info("thread-open loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function threadOpenTick() {
  let sess = await getThreadOpenSession();
  if (sess === null) {
    stopThreadOpenInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) return;
    await warn("thread-open: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await markThreadOpenSeen(sess.inflight.tweetId);
    await dequeueThreadOpen(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
  }
  const target = await nextThreadOpenTarget();
  if (!target) {
    stopThreadOpenInterval();
    await setThreadOpenTabId(null);
    await setThreadOpenSession(null);
    await info("thread-open loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await hasThreadOpenSeen(target.tweetId)) {
    await dequeueThreadOpen(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getThreadOpenTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id !== "number") throw new Error("created tab without id");
      tabId = tab.id;
      await setThreadOpenTabId(tabId);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    await markThreadOpenSeen(target.tweetId);
    sess = await getThreadOpenSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setThreadOpenSession(sess);
    if (tabId !== null) {
      void nudgeThreadOpenTab(tabId);
    }
    await info("thread-open tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await threadOpenQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("thread-open navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await markThreadOpenSeen(target.tweetId);
    await dequeueThreadOpen(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
  }
  await broadcastState();
}
async function nudgeThreadOpenTab(tabId) {
  await new Promise((resolve) => setTimeout(resolve, 1500));
  try {
    await browser.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        const step = () => window.scrollBy({ top: h * 1.3, behavior: "smooth" });
        step();
        setTimeout(step, 1400);
        setTimeout(step, 2800);
      }
    });
  } catch (err) {
    await warn("thread-open scroll-nudge failed", describeError(err));
  }
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    const checkWrite = force || isWriteAuthError(conn.error);
    if (branchOk && checkWrite) {
      await client.verifyWriteAccess();
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk,
      write_access: checkWrite ? "checked" : "not_checked"
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await refreshArchiveSnapshot(client, force);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function refreshArchiveSnapshot(client, force) {
  const text = await client.fetchRawText("data/manifest.json");
  if (!text) {
    await setArchiveSnapshot(null);
    if (force) await warn("archive manifest not found; old-tweet detection disabled");
    return;
  }
  try {
    const snapshot = parseArchiveSnapshot(JSON.parse(text));
    await setArchiveSnapshot(snapshot);
    if (force) {
      await info("archive snapshot refreshed", {
        accounts: Object.keys(snapshot.accounts).length,
        generated_at: snapshot.generated_at
      });
    }
  } catch (err) {
    await warn("archive snapshot parse failed; old-tweet detection disabled", describeError(err));
  }
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const threadOpenQueued = await threadOpenQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  const autoScrollSess = await getAutoScrollSession();
  const recentTweetSightings = await getRecentTweetSightings();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      ingestedNewCount: autoScrollSess?.ingestedNewCount ?? 0,
      ingestedExistingCount: autoScrollSess?.ingestedExistingCount ?? 0,
      skippedOldCount: autoScrollSess?.skippedOldCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    },
    threadOpenQueue: {
      total: threadOpenQueued,
      running: threadOpenIntervalHandle !== null,
      processed: threadOpenSess?.processed ?? 0,
      total_at_start: threadOpenSess?.totalAtStart ?? 0
    },
    recentTweetSightings
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    updateExisting: s.updateExisting,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function parseArchiveSnapshot(raw) {
  if (!raw || typeof raw !== "object") throw new Error("manifest is not an object");
  const manifest = raw;
  if (!Array.isArray(manifest.accounts)) throw new Error("manifest.accounts is not an array");
  const accounts = {};
  for (const entry of manifest.accounts) {
    if (!entry || typeof entry !== "object") continue;
    const row = entry;
    const handle = typeof row.handle === "string" ? row.handle : "";
    if (!handle || handle === "_misc") continue;
    accounts[handle.toLowerCase()] = {
      handle,
      latest_post_at: typeof row.latest_post_at === "string" ? row.latest_post_at : null,
      latest_capture_at: typeof row.latest_capture_at === "string" ? row.latest_capture_at : null,
      row_count: typeof row.row_count === "number" ? row.row_count : null
    };
  }
  return {
    generated_at: typeof manifest.generated_at === "string" ? manifest.generated_at : null,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    accounts
  };
}
function archiveSnapshotHasTweet(t, snapshot) {
  if (!snapshot) return false;
  const entry = snapshot.accounts[t.account_handle.toLowerCase()];
  if (!entry?.latest_post_at) return false;
  const posted = Date.parse(t.posted_at);
  const latest = Date.parse(entry.latest_post_at);
  return Number.isFinite(posted) && Number.isFinite(latest) && posted <= latest;
}
function buildTweetSighting(t, endpoint, seenAt, freshness = "new", action = "buffered") {
  return {
    tweet_id: t.tweet_id,
    account_handle: t.account_handle,
    posted_at: t.posted_at,
    text: t.text_resolved || t.text,
    tweet_type: t.tweet_type,
    tweet_url: t.tweet_url,
    seen_at: seenAt,
    endpoint,
    archive_status: freshness === "existing" ? "saved" : "new",
    action
  };
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop,
  threadOpenQueue: getThreadOpenQueue,
  startThreadOpen: startThreadOpenLoop,
  cancelThreadOpen: cancelThreadOpenLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xyXG4gIHBhdDogJycsXHJcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcclxuICByZXBvOiAneCcsXHJcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxyXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXHJcbiAgYnJhbmNoOiAnbWFzdGVyJyxcclxuICBlbmFibGVkOiB0cnVlLFxyXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxyXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcclxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXHJcbiAgdXBkYXRlRXhpc3Rpbmc6IHRydWUsXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XHJcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XHJcblxyXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxyXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXHJcbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xyXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuXTtcclxuXHJcbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXHJcbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG4gICdMaWtlcycsXHJcbiAgJ0Jvb2ttYXJrcycsXHJcbiAgJ0hvbWVUaW1lbGluZScsXHJcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXHJcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcclxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcclxuXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XHJcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXHJcbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXHJcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxyXG5dKTtcclxuXHJcbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxyXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxyXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3JcclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxyXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcclxuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXHJcbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXHJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcclxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxyXG4vL1xyXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcclxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXHJcbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cclxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG5dKTtcclxuXHJcbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxyXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xyXG5cclxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcclxuXHJcbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XHJcblxyXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXHJcbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcclxuXHJcbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cclxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XHJcblxyXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcclxuIiwgIi8qKlxyXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cclxuICpcclxuICogVGhyZWF0IG1vZGVsOiBhbiBhdHRhY2tlciB3aG8gcmVhZHMgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgKGRldnRvb2xzLCBhXHJcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXHJcbiAqIEdpdEh1YiBQQVQgaW4gcGxhaW50ZXh0LiBBIGRldGVybWluZWQgYXR0YWNrZXIgd2l0aCB0aGUgZXh0ZW5zaW9uJ3Mgc291cmNlXHJcbiAqIGNhbiBzdGlsbCBkZXJpdmUgdGhlIGtleSBcdTIwMTQgd2UgbWFrZSBubyBjbGFpbSBvZiBcInJlYWxcIiBjcnlwdG9ncmFwaGljXHJcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxyXG4gKiBzdHJpbmcgc2l0dGluZyBuZXh0IHRvIGl0cyBrZXkgbmFtZSBpbiBleHRlbnNpb24gc3RvcmFnZS5cclxuICpcclxuICogU2NoZW1lOlxyXG4gKiAgIC0gT24gZmlyc3QgZW5jcnlwdGlvbiB3ZSBnZW5lcmF0ZSBhIDMyLWJ5dGUgc2FsdCBhbmQgcGVyc2lzdCBpdCBpblxyXG4gKiAgICAgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgdW5kZXIgYF9faW1tX2FyY2hpdmVfc2FsdF9fYC5cclxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cclxuICogICAgIHx8IFwiaW1tLWFyY2hpdmUtcGF0LXYxXCJgLiBUaGUgc2FsdCBiZWluZyBwZXItaW5zdGFsbCBtZWFucyB0d28gY29waWVzXHJcbiAqICAgICBvZiB0aGUgZXh0ZW5zaW9uIGRvbid0IHNoYXJlIGEga2V5LiBUaGUgcnVudGltZS5pZCBpcyB0aGUgZXh0ZW5zaW9uJ3NcclxuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxyXG4gKiAgIC0gUGxhaW50ZXh0IGlzIGVuY3J5cHRlZCB3aXRoIGEgZnJlc2ggMTItYnl0ZSBJVi4gVGhlIGVudmVsb3BlIGZvcm1hdCBpc1xyXG4gKiAgICAgYHYxOjxpdi1iNjQ+OjxjaXBoZXJ0ZXh0LWI2ND5gIGFuZCBpcyB3aGF0IGdldHMgc3RvcmVkLlxyXG4gKlxyXG4gKiBCYWNrd2FyZHMgY29tcGF0aWJpbGl0eTogYW4gdW5wcmVmaXhlZCB2YWx1ZSBpcyB0cmVhdGVkIGFzIGxlZ2FjeVxyXG4gKiBwbGFpbnRleHQsIGRlY3J5cHRlZCB0byBpdHNlbGYsIGFuZCByZS1lbmNyeXB0ZWQgb24gdGhlIG5leHQgd3JpdGUuXHJcbiAqL1xyXG5cclxuY29uc3QgU0FMVF9TVE9SQUdFX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3NhbHRfXyc7XHJcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xyXG5cclxubGV0IGRlcml2ZWRLZXlDYWNoZTogQ3J5cHRvS2V5IHwgbnVsbCA9IG51bGw7XHJcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHRvQmFzZTY0KGJ1ZjogVWludDhBcnJheSk6IHN0cmluZyB7XHJcbiAgbGV0IHMgPSAnJztcclxuICBmb3IgKGNvbnN0IGIgb2YgYnVmKSBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYik7XHJcbiAgcmV0dXJuIGJ0b2Eocyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZyb21CYXNlNjQoczogc3RyaW5nKTogVWludDhBcnJheSB7XHJcbiAgY29uc3QgYmluID0gYXRvYihzKTtcclxuICBjb25zdCBvdXQgPSBuZXcgVWludDhBcnJheShiaW4ubGVuZ3RoKTtcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IGJpbi5sZW5ndGg7IGkrKykgb3V0W2ldID0gYmluLmNoYXJDb2RlQXQoaSk7XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcclxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFNBTFRfU1RPUkFHRV9LRVkpO1xyXG4gIGNvbnN0IHYgPSBzdG9yZWRbU0FMVF9TVE9SQUdFX0tFWV07XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcclxuICAgIHJldHVybiB7IHNhbHRCNjQ6IHYsIHNhbHQ6IGZyb21CYXNlNjQodikgfTtcclxuICB9XHJcbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcclxuICBjb25zdCBzYWx0QjY0ID0gdG9CYXNlNjQoc2FsdCk7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtTQUxUX1NUT1JBR0VfS0VZXTogc2FsdEI2NCB9KTtcclxuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xyXG4gIGNvbnN0IHsgc2FsdEI2NCwgc2FsdCB9ID0gYXdhaXQgbG9hZE9yQ3JlYXRlU2FsdCgpO1xyXG4gIGlmIChkZXJpdmVkS2V5Q2FjaGUgIT09IG51bGwgJiYgZGVyaXZlZEtleUNhY2hlU2FsdCA9PT0gc2FsdEI2NCkge1xyXG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcclxuICB9XHJcbiAgY29uc3Qgc2VlZCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcclxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXHJcbiAgKTtcclxuICBjb25zdCBjb21iaW5lZCA9IG5ldyBVaW50OEFycmF5KHNlZWQubGVuZ3RoICsgc2FsdC5sZW5ndGgpO1xyXG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcclxuICBjb21iaW5lZC5zZXQoc2FsdCwgc2VlZC5sZW5ndGgpO1xyXG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGNvbWJpbmVkKTtcclxuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcclxuICAgICdlbmNyeXB0JyxcclxuICAgICdkZWNyeXB0JyxcclxuICBdKTtcclxuICBkZXJpdmVkS2V5Q2FjaGUgPSBrZXk7XHJcbiAgZGVyaXZlZEtleUNhY2hlU2FsdCA9IHNhbHRCNjQ7XHJcbiAgcmV0dXJuIGtleTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gIHJldHVybiB2LnN0YXJ0c1dpdGgoRU5WRUxPUEVfUFJFRklYKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVuY3J5cHRQYXQocGxhaW50ZXh0OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIGlmICghcGxhaW50ZXh0KSByZXR1cm4gJyc7XHJcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XHJcbiAgY29uc3QgaXYgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEyKSk7XHJcbiAgY29uc3QgY3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmVuY3J5cHQoXHJcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcclxuICAgIGtleSxcclxuICAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShwbGFpbnRleHQpXHJcbiAgKTtcclxuICByZXR1cm4gYCR7RU5WRUxPUEVfUFJFRklYfSR7dG9CYXNlNjQoaXYpfToke3RvQmFzZTY0KG5ldyBVaW50OEFycmF5KGN0KSl9YDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlY3J5cHRQYXQoZW52ZWxvcGU6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgaWYgKCFlbnZlbG9wZSkgcmV0dXJuICcnO1xyXG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXHJcbiAgLy8gcmUtZW5jcnlwdHMgaXQgdmlhIHRoZSBzdG9yYWdlIGxheWVyLlxyXG4gIGlmICghZW52ZWxvcGUuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpKSByZXR1cm4gZW52ZWxvcGU7XHJcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xyXG4gIGlmIChwYXJ0cy5sZW5ndGggIT09IDIpIHJldHVybiAnJztcclxuICBjb25zdCBbaXZCNjQsIGN0QjY0XSA9IHBhcnRzO1xyXG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGtleSA9IGF3YWl0IGRlcml2ZUtleSgpO1xyXG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcclxuICAgIGNvbnN0IGN0ID0gZnJvbUJhc2U2NChjdEI2NCk7XHJcbiAgICBjb25zdCBwdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGVjcnlwdChcclxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcclxuICAgICAga2V5LFxyXG4gICAgICBjdCBhcyBCdWZmZXJTb3VyY2VcclxuICAgICk7XHJcbiAgICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKHB0KTtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiAnJztcclxuICB9XHJcbn1cclxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcclxuaW1wb3J0IHsgZGVjcnlwdFBhdCwgZW5jcnlwdFBhdCwgaXNFbmNyeXB0ZWRQYXQgfSBmcm9tICcuL2NyeXB0by5qcyc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBBY2NvdW50Q29uZmlnLFxyXG4gIEFjY291bnRDb3VudGVyLFxyXG4gIEFyY2hpdmVTbmFwc2hvdCxcclxuICBDYW5vbmljYWxUd2VldCxcclxuICBDb25uZWN0aW9uU3RhdGUsXHJcbiAgTG9nRXZlbnQsXHJcbiAgUmV0d2VldEVkZ2UsXHJcbiAgU2V0dGluZ3MsXHJcbiAgVHdlZXRTaWdodGluZyxcclxuICBVbmF2YWlsYWJsZVR3ZWV0LFxyXG59IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuLyoqXHJcbiAqIEJ1ZmZlcmVkIHR3ZWV0cyBmb3IgYSBnaXZlbiBhY2NvdW50LCBhd2FpdGluZyBjb21taXQuIEEgXCJydW5cIiBpcyBvbmUgZW50cnlcclxuICogaW4gdGhpcyBtYXA7IGZsdXNoaW5nIGNsZWFycyB0aGUgZW50cnkuIFdlIHN0b3JlIGFzIFJlY29yZCBzbyB0aGUgc3RydWN0dXJlXHJcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgUnVuQnVmZmVyIHtcclxuICBydW5faWQ6IHN0cmluZztcclxuICBhY2NvdW50X2hhbmRsZTogc3RyaW5nO1xyXG4gIHN0YXJ0ZWRfYXQ6IHN0cmluZztcclxuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcclxuICB0d2VldHNfYnlfaWQ6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PjtcclxuICB1bmF2YWlsYWJsZV9ieV9pZD86IFJlY29yZDxzdHJpbmcsIFVuYXZhaWxhYmxlVHdlZXQ+O1xyXG4gIHJldHdlZXRfZWRnZXNfYnlfa2V5PzogUmVjb3JkPHN0cmluZywgUmV0d2VldEVkZ2U+O1xyXG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XHJcbiAgZW5kcG9pbnRzX3NlZW46IHN0cmluZ1tdO1xyXG4gIHNvdXJjZV91cmw6IHN0cmluZyB8IG51bGw7XHJcbn1cclxuXHJcbi8qKiBQZXItdHdlZXQgY29tbWl0dGVkLXN0YXRlIGluZGV4LCBrZXllZCBieSBoYW5kbGUgdGhlbiB0d2VldF9pZC5cclxuICogVXNlZCB0byBza2lwIHJlLWNhcHR1cmluZyB0d2VldHMgd2UndmUgYWxyZWFkeSBwdXNoZWQgd2l0aCBpZGVudGljYWxcclxuICogZW5nYWdlbWVudCBjb3VudHMgXHUyMDE0IGF2b2lkcyBnZW5lcmF0aW5nIG9uZSBuZXcgcmF3LyogZmlsZSBldmVyeSBicm93c2UuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0dGVkRW50cnkge1xyXG4gIHRzOiBzdHJpbmc7IC8vIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3QgY29tbWl0XHJcbiAgc2lnOiBzdHJpbmc7IC8vIGVuZ2FnZW1lbnQgc2lnbmF0dXJlOiBcImxpa2V8cnR8cmVwbHl8cXVvdGVcIlxyXG59XHJcblxyXG4vKiogUHJvZ3Jlc3MgKyBpbmZsaWdodCB0cmFja2luZyBmb3IgYSBxdWV1ZS1kcml2ZW4gbG9vcCAocmVmZXRjaCAvIG1lZGlhLWNyYXdsKS5cclxuICogVGhlIGxvb3AgcGVyc2lzdHMgdGhpcyBzbyBhIFNXIGV2aWN0aW9uIGluIHRoZSBtaWRkbGUgb2YgYSBydW4gcHJlc2VydmVzXHJcbiAqIFwiWCBvZiBZIHByb2Nlc3NlZFwiIFx1MjAxNCBhbmQgdGhlIHdhaXQtZm9yLWluZ2VzdCBndWFyZCBrbm93cyB3aGF0IHRvIGV4cGVjdC5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgTG9vcFNlc3Npb24ge1xyXG4gIC8qKiBJbml0aWFsIHF1ZXVlIHNpemUgd2hlbiB0aGUgdXNlciBjbGlja2VkIFwiU3RhcnRcIi4gKi9cclxuICB0b3RhbEF0U3RhcnQ6IG51bWJlcjtcclxuICAvKiogVHdlZXRzIHByb2Nlc3NlZCAoaW5nZXN0ZWQgT1IgZHJvcHBlZCBhZnRlciByZXRyaWVzKSBzbyBmYXIuICovXHJcbiAgcHJvY2Vzc2VkOiBudW1iZXI7XHJcbiAgLyoqIElTTyBvZiB3aGVuIHRoaXMgc2Vzc2lvbiBzdGFydGVkLiAqL1xyXG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xyXG4gIC8qKiBUd2VldCBjdXJyZW50bHkgaW5mbGlnaHQgXHUyMDE0IHdlIG5hdmlnYXRlZCB0byBpdCBhbmQgYXJlIHdhaXRpbmcgZm9yIHRoZVxyXG4gICAqIHBhZ2UtaG9vayB0byBjYXB0dXJlIHRoZSByZXNwb25zZSBiZWZvcmUgYWR2YW5jaW5nLiBudWxsIGJldHdlZW4gdGlja3NcclxuICAgKiAoYW5kIG9uY2UgYW4gaW5nZXN0IGhhcyBiZWVuIG9ic2VydmVkKS4gKi9cclxuICBpbmZsaWdodDogeyB0d2VldElkOiBzdHJpbmc7IG5hdmlnYXRlZEF0OiBzdHJpbmcgfSB8IG51bGw7XHJcbn1cclxuXHJcbi8qKiBBdXRvLXNjcm9sbCBzZXNzaW9uOiBjb3VudHMgb2YgdGlja3MgYW5kIHR3ZWV0cyBpbmdlc3RlZCBzaW5jZSB0aGUgdXNlclxyXG4gKiBjbGlja2VkIFN0YXJ0LiBQZXJzaXN0ZWQgc28gU1cgZXZpY3Rpb24gZHVyaW5nIGEgcnVuIGtlZXBzIHByb2dyZXNzLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIEF1dG9TY3JvbGxTZXNzaW9uIHtcclxuICBzdGFydGVkQXQ6IHN0cmluZztcclxuICBzY3JvbGxDb3VudDogbnVtYmVyO1xyXG4gIGluZ2VzdGVkQ291bnQ6IG51bWJlcjtcclxuICBpbmdlc3RlZE5ld0NvdW50OiBudW1iZXI7XHJcbiAgaW5nZXN0ZWRFeGlzdGluZ0NvdW50OiBudW1iZXI7XHJcbiAgc2tpcHBlZE9sZENvdW50OiBudW1iZXI7XHJcbiAgZXhwYW5kZWRDb3VudDogbnVtYmVyO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgU3RvcmFnZVNoYXBlIHtcclxuICBzZXR0aW5nczogU2V0dGluZ3M7XHJcbiAgYWNjb3VudHM6IEFjY291bnRDb25maWdbXTtcclxuICAvKiogSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBzdWNjZXNzZnVsIGFjY291bnRzLnlhbWwgZmV0Y2ggZnJvbSB0aGUgcmVwby5cclxuICAgKiBVc2VkIGJ5IGByZWZyZXNoQWNjb3VudHNMaXN0YCB0byBza2lwIHJlLWZldGNoaW5nIG9uIGV2ZXJ5IFNXIHdha2UgXHUyMDE0IHRoZVxyXG4gICAqIGZpbGUgY2hhbmdlcyByYXJlbHkgYW5kIGFuIGF1dGhlbnRpY2F0ZWQgcmF3IGZldGNoIGV2ZXJ5IHdha2UgYWRkcyB1cC4gKi9cclxuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBzdHJpbmcgfCBudWxsO1xyXG4gIGFyY2hpdmVTbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbDtcclxuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uU3RhdGU7XHJcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcclxuICBydW5CdWZmZXJzOiBSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+O1xyXG4gIGFjdGl2aXR5OiBMb2dFdmVudFtdO1xyXG4gIHJlY2VudFR3ZWV0U2lnaHRpbmdzOiBUd2VldFNpZ2h0aW5nW107XHJcbiAgY29tbWl0dGVkSW5kZXg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj47XHJcbiAgLyoqIFR3ZWV0cyB0aGUgbm9ybWFsaXplciBmbGFnZ2VkIGFzIHRydW5jYXRlZCBhbmQgdGhhdCB3ZSBoYXZlbid0IHNlZW4gYVxyXG4gICAqIGZ1bGwtdGV4dCB2ZXJzaW9uIG9mIHlldC4gS2V5ZWQgYnkgaGFuZGxlIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuICovXHJcbiAgcmVmZXRjaFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XHJcbiAgLyoqIFR3ZWV0IElEcyBzZWVuIHZpYSBNZWRpYS10YWIgLyBwYXJ0aWFsIGNhcHR1cmVzIHRoYXQgY291bGRuJ3QgYmVcclxuICAgKiBub3JtYWxpemVkIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gS2V5ZWQgYnkgaGludC1oYW5kbGUgKG9yXHJcbiAgICogXCJfdW5rbm93blwiKSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiBUaGUgdXNlciBjYW4gZHJpdmUgYSBjcmF3bCB0aGF0XHJcbiAgICogb3BlbnMgZWFjaCBkZXRhaWwgcGFnZSB0byBjYXB0dXJlIHRoZSByZWFsIHRoaW5nLiAqL1xyXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xyXG4gIC8qKiBDb3JlLWFjY291bnQgdGhyZWFkIHJvb3RzIHdvcnRoIG9wZW5pbmcgYmVjYXVzZSB0aW1lbGluZS9zZWFyY2ggdmlld3MgbWF5XHJcbiAgICogb21pdCBsYXRlciBzZWxmLXJlcGxpZXMuIEtleWVkIGJ5IGhpbnQtaGFuZGxlIC0+IHJvb3QgdHdlZXQgaWRzLiAqL1xyXG4gIHRocmVhZE9wZW5RdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xyXG4gIC8qKiBSb290IHR3ZWV0IGlkcyBhbHJlYWR5IGF0dGVtcHRlZCBieSB0aGUgdGhyZWFkLW9wZW5pbmcgdXRpbGl0eS4gKi9cclxuICB0aHJlYWRPcGVuU2VlbjogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcclxuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xyXG4gIG1lZGlhQ3Jhd2xTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XHJcbiAgdGhyZWFkT3BlblNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcclxuICBhdXRvU2Nyb2xsU2Vzc2lvbjogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsO1xyXG59XHJcblxyXG5jb25zdCBERUZBVUxUX0NPTk5FQ1RJT046IENvbm5lY3Rpb25TdGF0ZSA9IHtcclxuICBzdGF0dXM6ICd1bmtub3duJyxcclxuICBsb2dpbjogbnVsbCxcclxuICBjaGVja2VkQXQ6IG51bGwsXHJcbiAgZXJyb3I6IG51bGwsXHJcbiAgZGVmYXVsdEJyYW5jaDogbnVsbCxcclxuICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxyXG4gIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXHJcbn07XHJcblxyXG5jb25zdCBERUZBVUxUUzogU3RvcmFnZVNoYXBlID0ge1xyXG4gIHNldHRpbmdzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MgfSxcclxuICBhY2NvdW50czogWy4uLkZBTExCQUNLX0FDQ09VTlRTXSxcclxuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBudWxsLFxyXG4gIGFyY2hpdmVTbmFwc2hvdDogbnVsbCxcclxuICBjb25uZWN0aW9uOiB7IC4uLkRFRkFVTFRfQ09OTkVDVElPTiB9LFxyXG4gIGNvdW50ZXJzOiB7fSxcclxuICBydW5CdWZmZXJzOiB7fSxcclxuICBhY3Rpdml0eTogW10sXHJcbiAgcmVjZW50VHdlZXRTaWdodGluZ3M6IFtdLFxyXG4gIGNvbW1pdHRlZEluZGV4OiB7fSxcclxuICByZWZldGNoUXVldWU6IHt9LFxyXG4gIG1lZGlhQ3Jhd2xRdWV1ZToge30sXHJcbiAgdGhyZWFkT3BlblF1ZXVlOiB7fSxcclxuICB0aHJlYWRPcGVuU2Vlbjoge30sXHJcbiAgcmVmZXRjaFNlc3Npb246IG51bGwsXHJcbiAgbWVkaWFDcmF3bFNlc3Npb246IG51bGwsXHJcbiAgdGhyZWFkT3BlblNlc3Npb246IG51bGwsXHJcbiAgYXV0b1Njcm9sbFNlc3Npb246IG51bGwsXHJcbn07XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcclxuICBjb25zdCByZXN1bHQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KGtleSk7XHJcbiAgY29uc3QgdmFsdWUgPSByZXN1bHRba2V5XTtcclxuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgcmV0dXJuIHN0cnVjdHVyZWRDbG9uZShERUZBVUxUU1trZXldKTtcclxuICB9XHJcbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBba2V5XTogdmFsdWUgfSk7XHJcbn1cclxuXHJcbi8vIC0tLSBTZXR0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xyXG4gIC8vIEJhY2tmaWxsIGFueSBrZXlzIHRoZSB1c2VyJ3Mgc3RvcmVkIHNldHRpbmdzIHByZWRhdGUgXHUyMDE0IHJlYWRlcnMgY2FuIHJlbHlcclxuICAvLyBvbiBldmVyeSBTZXR0aW5ncyBmaWVsZCBiZWluZyBwcmVzZW50IHJhdGhlciB0aGFuIGA/PyBkZWZhdWx0aW5nYCBhdFxyXG4gIC8vIGV2ZXJ5IGNhbGxzaXRlLiBUaGUgUEFUIGlzIHN0b3JlZCBlbmNyeXB0ZWQtYXQtcmVzdCBhcyBvZiB2MC4yLjA7IHdlXHJcbiAgLy8gZGVjcnlwdCB0cmFuc3BhcmVudGx5IHNvIGNhbGxlcnMgY29udGludWUgdG8gc2VlIHBsYWludGV4dC5cclxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBnZXRSYXcoJ3NldHRpbmdzJyk7XHJcbiAgY29uc3QgbWVyZ2VkID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi5zdG9yZWQgfTtcclxuICBpZiAobWVyZ2VkLnBhdCAmJiBpc0VuY3J5cHRlZFBhdChtZXJnZWQucGF0KSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgbWVyZ2VkLnBhdCA9IGF3YWl0IGRlY3J5cHRQYXQobWVyZ2VkLnBhdCk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgbWVyZ2VkLnBhdCA9ICcnO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gbWVyZ2VkO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIC8vIEVuY3J5cHQgdGhlIFBBVCBiZWZvcmUgcGVyc2lzdGluZzsgbGVnYWN5IHBsYWludGV4dCBQQVRzIGdldCB1cGdyYWRlZFxyXG4gIC8vIG9uIHRoZSBuZXh0IHNhdmUuXHJcbiAgY29uc3QgdG9Xcml0ZTogU2V0dGluZ3MgPSB7IC4uLnMgfTtcclxuICBpZiAodG9Xcml0ZS5wYXQgJiYgIWlzRW5jcnlwdGVkUGF0KHRvV3JpdGUucGF0KSkge1xyXG4gICAgdG9Xcml0ZS5wYXQgPSBhd2FpdCBlbmNyeXB0UGF0KHRvV3JpdGUucGF0KTtcclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdzZXR0aW5ncycsIHRvV3JpdGUpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVTZXR0aW5ncyhwYXRjaDogUGFydGlhbDxTZXR0aW5ncz4pOiBQcm9taXNlPFNldHRpbmdzPiB7XHJcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBjb25zdCBuZXh0ID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XHJcbiAgYXdhaXQgc2V0U2V0dGluZ3MobmV4dCk7XHJcbiAgcmV0dXJuIG5leHQ7XHJcbn1cclxuXHJcbi8vIC0tLSBBY2NvdW50cyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHMoKTogUHJvbWlzZTxBY2NvdW50Q29uZmlnW10+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50cycpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50cyhhOiBBY2NvdW50Q29uZmlnW10pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzJywgYSk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzUmVmcmVzaGVkQXQoKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KGlzbzogc3RyaW5nIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcsIGlzbyk7XHJcbn1cclxuXHJcbi8vIC0tLSBBcmNoaXZlIHNuYXBzaG90IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBcmNoaXZlU25hcHNob3QoKTogUHJvbWlzZTxBcmNoaXZlU25hcHNob3QgfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYXJjaGl2ZVNuYXBzaG90Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBcmNoaXZlU25hcHNob3Qoc25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2FyY2hpdmVTbmFwc2hvdCcsIHNuYXBzaG90KTtcclxufVxyXG5cclxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb24oKTogUHJvbWlzZTxDb25uZWN0aW9uU3RhdGU+IHtcclxuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XHJcbiAgLy8gQmFja2ZpbGwgZmllbGRzIGFkZGVkIGFmdGVyIHRoZSB1c2VyJ3Mgc3RvcmFnZSB3YXMgd3JpdHRlbi5cclxuICBjb25zdCBvdXQ6IENvbm5lY3Rpb25TdGF0ZSA9IHtcclxuICAgIC4uLmMsXHJcbiAgICBkZWZhdWx0QnJhbmNoOiBjLmRlZmF1bHRCcmFuY2ggPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmRlZmF1bHRCcmFuY2gsXHJcbiAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOlxyXG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXHJcbiAgICByYXRlTGltaXRSZXNldEF0OiBjLnJhdGVMaW1pdFJlc2V0QXQgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLnJhdGVMaW1pdFJlc2V0QXQsXHJcbiAgfTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb25uZWN0aW9uKGM6IENvbm5lY3Rpb25TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xyXG59XHJcblxyXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZnVuY3Rpb24gdG9kYXlJU08oKTogc3RyaW5nIHtcclxuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnY291bnRlcnMnKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXHJcbiAgaGFuZGxlOiBzdHJpbmcsXHJcbiAgcGF0Y2g6IFBhcnRpYWw8QWNjb3VudENvdW50ZXI+XHJcbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRDb3VudGVycygpO1xyXG4gIGNvbnN0IGN1ciA9IGFsbFtoYW5kbGVdID8/IHtcclxuICAgIHRvZGF5Q291bnQ6IDAsXHJcbiAgICB0b2RheURhdGU6IHRvZGF5SVNPKCksXHJcbiAgICBsYXN0Q2FwdHVyZUF0OiBudWxsLFxyXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXHJcbiAgICBidWZmZXJlZENvdW50OiAwLFxyXG4gIH07XHJcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcclxuICAgIGN1ci50b2RheURhdGUgPSB0b2RheUlTTygpO1xyXG4gICAgY3VyLnRvZGF5Q291bnQgPSAwO1xyXG4gIH1cclxuICBjb25zdCBuZXh0OiBBY2NvdW50Q291bnRlciA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xyXG4gIGFsbFtoYW5kbGVdID0gbmV4dDtcclxuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcclxuICByZXR1cm4gbmV4dDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlOiBzdHJpbmcsIGNvdW50OiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHsgYnVmZmVyZWRDb3VudDogY291bnQgfSk7XHJcbn1cclxuXHJcbi8vIC0tLSBSdW4gYnVmZmVycyAodGhlIHBlbmRpbmcgY2FwdHVyZXMgYXdhaXRpbmcgY29tbWl0KSAtLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5CdWZmZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3J1bkJ1ZmZlcnMnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8UnVuQnVmZmVyIHwgbnVsbD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICByZXR1cm4gYWxsW2hhbmRsZV0gPz8gbnVsbDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZywgYnVmOiBSdW5CdWZmZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgYWxsW2hhbmRsZV0gPSBidWY7XHJcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyUnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcclxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xyXG59XHJcblxyXG4vLyAtLS0gQWN0aXZpdHkgdGFpbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjdGl2aXR5Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBlbmRBY3Rpdml0eShldjogTG9nRXZlbnQpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRBY3Rpdml0eSgpO1xyXG4gIGN1ci51bnNoaWZ0KGV2KTtcclxuICBpZiAoY3VyLmxlbmd0aCA+IEFDVElWSVRZX1RBSUxfTUFYKSBjdXIubGVuZ3RoID0gQUNUSVZJVFlfVEFJTF9NQVg7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIGN1cik7XHJcbiAgcmV0dXJuIGN1cjtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIFtdKTtcclxufVxyXG5cclxuLy8gLS0tIFJlY2VudCB0d2VldCBzaWdodGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5jb25zdCBSRUNFTlRfVFdFRVRfU0lHSFRJTkdTX01BWCA9IDgwO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk6IFByb21pc2U8VHdlZXRTaWdodGluZ1tdPiB7XHJcbiAgcmV0dXJuIGdldFJhdygncmVjZW50VHdlZXRTaWdodGluZ3MnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByZXBlbmRSZWNlbnRUd2VldFNpZ2h0aW5ncyhyb3dzOiBUd2VldFNpZ2h0aW5nW10pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBpZiAocm93cy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncygpO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBjb25zdCBuZXh0OiBUd2VldFNpZ2h0aW5nW10gPSBbXTtcclxuICBmb3IgKGNvbnN0IHJvdyBvZiByb3dzKSB7XHJcbiAgICBjb25zdCBrZXkgPSBgJHtyb3cuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKX06JHtyb3cudHdlZXRfaWR9YDtcclxuICAgIGlmIChzZWVuLmhhcyhrZXkpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKGtleSk7XHJcbiAgICBuZXh0LnB1c2gocm93KTtcclxuICB9XHJcbiAgZm9yIChjb25zdCByb3cgb2YgY3VyKSB7XHJcbiAgICBjb25zdCBrZXkgPSBgJHtyb3cuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKX06JHtyb3cudHdlZXRfaWR9YDtcclxuICAgIGlmIChzZWVuLmhhcyhrZXkpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKGtleSk7XHJcbiAgICBuZXh0LnB1c2gocm93KTtcclxuICB9XHJcbiAgbmV4dC5sZW5ndGggPSBNYXRoLm1pbihuZXh0Lmxlbmd0aCwgUkVDRU5UX1RXRUVUX1NJR0hUSU5HU19NQVgpO1xyXG4gIGF3YWl0IHNldFJhdygncmVjZW50VHdlZXRTaWdodGluZ3MnLCBuZXh0KTtcclxufVxyXG5cclxuLy8gLS0tIENvbW1pdHRlZC10d2VldHMgZGVkdXAgaW5kZXggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2NvbW1pdHRlZEluZGV4Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb21taXR0ZWRJbmRleChcclxuICBpZHg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj5cclxuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdjb21taXR0ZWRJbmRleCcsIGlkeCk7XHJcbn1cclxuXHJcbi8qKiBDb21wdXRlIHRoZSBlbmdhZ2VtZW50IHNpZ25hdHVyZSB3ZSB1c2UgdG8gZGVjaWRlIHdoZXRoZXIgYSByZS1jYXB0dXJlZFxyXG4gKiB0d2VldCBpcyBcIm1hdGVyaWFsbHkgZGlmZmVyZW50XCIgZnJvbSB3aGF0IHdlIGxhc3QgY29tbWl0dGVkLiBXZSBvbWl0XHJcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXHJcbiAqIGRlZmVhdCB0aGUgZGVkdXAuIExpa2VzIC8gUlRzIC8gcmVwbGllcyAvIHF1b3RlcyBjaGFuZ2UgcmFyZWx5IGVub3VnaCB0aGF0XHJcbiAqIGVhY2ggY2hhbmdlIGlzIHdvcnRoIGEgcmUtY29tbWl0IChhbmQgYW4gZW5nYWdlbWVudF9oaXN0b3J5IHNuYXBzaG90KS5cclxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxyXG4gKiB0aGUgZnVsbCBgbm90ZV90d2VldGAgYm9keSBieXBhc3NlcyB0aGUgZGVkdXAgZXZlbiB3aGVuIGVuZ2FnZW1lbnQgY291bnRzXHJcbiAqIGhhdmVuJ3QgbW92ZWQgXHUyMDE0IG90aGVyd2lzZSB0aGUgbmV3IGJvZHkgd291bGQgYmUgc2lsZW50bHkgZHJvcHBlZC4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXHJcbiAgbGlrZXM6IG51bWJlcixcclxuICByZXR3ZWV0czogbnVtYmVyLFxyXG4gIHJlcGxpZXM6IG51bWJlcixcclxuICBxdW90ZXM6IG51bWJlcixcclxuICBpc1RydW5jYXRlZDogYm9vbGVhbiA9IGZhbHNlXHJcbik6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGAke2xpa2VzfXwke3JldHdlZXRzfXwke3JlcGxpZXN9fCR7cXVvdGVzfXwke2lzVHJ1bmNhdGVkID8gJ3QnIDogJ2YnfWA7XHJcbn1cclxuXHJcbi8qKiBEcm9wIGVudHJpZXMgb2xkZXIgdGhhbiBgbWF4QWdlTXNgLiBSZXR1cm5zIHRoZSBudW1iZXIgcHJ1bmVkLiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJ1bmVDb21taXR0ZWRJbmRleChtYXhBZ2VNczogbnVtYmVyKTogUHJvbWlzZTxudW1iZXI+IHtcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGNvbnN0IGN1dG9mZiA9IG5ldyBEYXRlKERhdGUubm93KCkgLSBtYXhBZ2VNcykudG9JU09TdHJpbmcoKTtcclxuICBsZXQgcHJ1bmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XHJcbiAgICBjb25zdCBpbm5lciA9IGlkeFtoYW5kbGVdO1xyXG4gICAgaWYgKCFpbm5lcikgY29udGludWU7XHJcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcclxuICAgICAgY29uc3QgZSA9IGlubmVyW3RpZF07XHJcbiAgICAgIGlmIChlICYmIGUudHMgPCBjdXRvZmYpIHtcclxuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcclxuICAgICAgICBwcnVuZWQgKz0gMTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKE9iamVjdC5rZXlzKGlubmVyKS5sZW5ndGggPT09IDApIGRlbGV0ZSBpZHhbaGFuZGxlXTtcclxuICB9XHJcbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XHJcbiAgcmV0dXJuIHBydW5lZDtcclxufVxyXG5cclxuLy8gLS0tIFJlZmV0Y2ggcXVldWUgKHR3ZWV0cyBuZWVkaW5nIGZ1bGwtdGV4dCByZWNhcHR1cmUpIC0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFF1ZXVlJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWZldGNoUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBsZXQgdG90YWwgPSAwO1xyXG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XHJcbiAgcmV0dXJuIHRvdGFsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBjb25zdCBpZHMgPSBxW2hhbmRsZV0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtoYW5kbGVdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXTtcclxuICBpZiAoIWlkcykgcmV0dXJuO1xyXG4gIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcclxuICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtoYW5kbGVdO1xyXG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRSZWZldGNoVGFyZ2V0KCk6IFByb21pc2U8e1xyXG4gIGhhbmRsZTogc3RyaW5nO1xyXG4gIHR3ZWV0SWQ6IHN0cmluZztcclxufSB8IG51bGw+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XHJcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGhhbmRsZSwgdHdlZXRJZDogaWRzWzBdISB9O1xyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBsZXQgdG90YWwgPSAwO1xyXG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XHJcbiAgcmV0dXJuIHRvdGFsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZU1lZGlhQ3Jhd2woaGludEhhbmRsZTogc3RyaW5nIHwgbnVsbCwgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcclxuICBjb25zdCBpZHMgPSBxW2J1Y2tldF0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtidWNrZXRdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcclxuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xyXG4gICAgY29uc3QgaWRzID0gcVtidWNrZXRdO1xyXG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xyXG4gICAgaWYgKGZpbHRlcmVkLmxlbmd0aCAhPT0gaWRzLmxlbmd0aCkge1xyXG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcclxuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcclxuICAgICAgZWxzZSBxW2J1Y2tldF0gPSBmaWx0ZXJlZDtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKGNoYW5nZWQpIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgcSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0TWVkaWFDcmF3bFRhcmdldCgpOiBQcm9taXNlPHtcclxuICBidWNrZXQ6IHN0cmluZztcclxuICB0d2VldElkOiBzdHJpbmc7XHJcbn0gfCBudWxsPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xyXG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBidWNrZXQsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbi8vIC0tLSBUaHJlYWQtb3BlbmluZyBxdWV1ZSAoY29yZSBjb252ZXJzYXRpb24gcm9vdHMgdG8gdmlzaXQpIC0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUaHJlYWRPcGVuUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCd0aHJlYWRPcGVuUXVldWUnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRocmVhZE9wZW5RdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xyXG4gIGxldCB0b3RhbCA9IDA7XHJcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcclxuICByZXR1cm4gdG90YWw7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBoYXNUaHJlYWRPcGVuU2Vlbih0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcclxuICBjb25zdCBzZWVuID0gYXdhaXQgZ2V0UmF3KCd0aHJlYWRPcGVuU2VlbicpO1xyXG4gIHJldHVybiB0d2VldElkIGluIHNlZW47XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtYXJrVGhyZWFkT3BlblNlZW4odHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3Qgc2VlbiA9IGF3YWl0IGdldFJhdygndGhyZWFkT3BlblNlZW4nKTtcclxuICBzZWVuW3R3ZWV0SWRdID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xyXG4gIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblNlZW4nLCBzZWVuKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVUaHJlYWRPcGVuKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBpZiAoYXdhaXQgaGFzVGhyZWFkT3BlblNlZW4odHdlZXRJZCkpIHJldHVybjtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XHJcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xyXG4gIGlmICghaWRzLmluY2x1ZGVzKHR3ZWV0SWQpKSB7XHJcbiAgICBpZHMucHVzaCh0d2VldElkKTtcclxuICAgIHFbaGFuZGxlXSA9IGlkcztcclxuICAgIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblF1ZXVlJywgcSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZVRocmVhZE9wZW4odHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xyXG4gIGxldCBjaGFuZ2VkID0gZmFsc2U7XHJcbiAgZm9yIChjb25zdCBidWNrZXQgb2YgT2JqZWN0LmtleXMocSkpIHtcclxuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcclxuICAgIGlmICghaWRzKSBjb250aW51ZTtcclxuICAgIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcclxuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcclxuICAgICAgY2hhbmdlZCA9IHRydWU7XHJcbiAgICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2J1Y2tldF07XHJcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5RdWV1ZScsIHEpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dFRocmVhZE9wZW5UYXJnZXQoKTogUHJvbWlzZTx7XHJcbiAgaGFuZGxlOiBzdHJpbmc7XHJcbiAgdHdlZXRJZDogc3RyaW5nO1xyXG59IHwgbnVsbD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcclxuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcclxuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgaGFuZGxlLCB0d2VldElkOiBpZHNbMF0hIH07XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcblxyXG4vKiogSGFzIHRoaXMgdHdlZXQgaWQgYWxyZWFkeSBiZWVuIGNvbW1pdHRlZCAoYW55IGhhbmRsZSk/IFVzZWQgdG8gc2tpcFxyXG4gKiBlbnF1ZXVlaW5nIG1lZGlhLWNyYXdsIHRhcmdldHMgd2UndmUgYWxyZWFkeSBhcmNoaXZlZC4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGlzQ29tbWl0dGVkKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xyXG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgZm9yIChjb25zdCBpbm5lciBvZiBPYmplY3QudmFsdWVzKGlkeCkpIHtcclxuICAgIGlmIChpbm5lciAmJiB0d2VldElkIGluIGlubmVyKSByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbiAgcmV0dXJuIGZhbHNlO1xyXG59XHJcblxyXG4vLyAtLS0gTG9vcCBzZXNzaW9uIHN0YXRlIChwcm9ncmVzcyArIGluZmxpZ2h0IGdhdGluZykgLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoU2Vzc2lvbicpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSZWZldGNoU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJywgcyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicsIHMpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUaHJlYWRPcGVuU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3RocmVhZE9wZW5TZXNzaW9uJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFRocmVhZE9wZW5TZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblNlc3Npb24nLCBzKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTogUHJvbWlzZTxBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJywgcyk7XHJcbn1cclxuXHJcbi8vIC0tLSBQdXJnZTogdW5yZWxhdGVkIGJ1ZmZlcnMsIGNvdW50ZXJzLCBxdWV1ZSBlbnRyaWVzIC0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbi8qKlxyXG4gKiBEcm9wIGV2ZXJ5IHBlci1oYW5kbGUgYml0IG9mIHN0YXRlIChjb3VudGVycywgcnVuIGJ1ZmZlciwgY29tbWl0dGVkLWluZGV4XHJcbiAqIGVudHJpZXMsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyaWVzKSB0aGF0IGRvZXNuJ3QgY29ycmVzcG9uZCB0byBhXHJcbiAqIHRyYWNrZWQgYWNjb3VudC4gUmV0dXJucyBhIHN1bW1hcnkgZGVzY3JpYmluZyB3aGF0IHdhcyBjbGVhcmVkIHNvIHRoZVxyXG4gKiBjYWxsZXIgY2FuIGxvZyBpdC5cclxuICpcclxuICogVHJhY2tlZCBhY2NvdW50cyBhcmUgcGFzc2VkIGluIChjYWxsZXIgcmVzb2x2ZXMgZnJvbSB0aGUgbGl2ZSBjb25maWcpLlxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1cmdlVW5yZWxhdGVkU3RhdGUodGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4pOiBQcm9taXNlPHtcclxuICBjb3VudGVyc1JlbW92ZWQ6IG51bWJlcjtcclxuICBidWZmZXJzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XHJcbiAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XHJcbiAgbWVkaWFDcmF3bElkc1JlbW92ZWQ6IG51bWJlcjtcclxuICB0aHJlYWRPcGVuSWRzUmVtb3ZlZDogbnVtYmVyO1xyXG59PiB7XHJcbiAgY29uc3QgdGFyZ0xvd2VyID0gbmV3IFNldChbLi4udGFyZ2V0ZWRdLm1hcCgoaCkgPT4gaC50b0xvd2VyQ2FzZSgpKSk7XHJcbiAgY29uc3QgaXNUYXJnZXRlZCA9IChoOiBzdHJpbmcpOiBib29sZWFuID0+IHRhcmdMb3dlci5oYXMoaC50b0xvd2VyQ2FzZSgpKTtcclxuXHJcbiAgLy8gQ291bnRlcnNcclxuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XHJcbiAgbGV0IGNvdW50ZXJzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGNvdW50ZXJzKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIGRlbGV0ZSBjb3VudGVyc1toXTtcclxuICAgICAgY291bnRlcnNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygnY291bnRlcnMnLCBjb3VudGVycyk7XHJcblxyXG4gIC8vIFJ1biBidWZmZXJzXHJcbiAgY29uc3QgYnVmZmVycyA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBsZXQgYnVmZmVyc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhidWZmZXJzKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIGRlbGV0ZSBidWZmZXJzW2hdO1xyXG4gICAgICBidWZmZXJzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBidWZmZXJzKTtcclxuXHJcbiAgLy8gQ29tbWl0dGVkIGRlZHVwIGluZGV4XHJcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBsZXQgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGlkeFtoXTtcclxuICAgICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcclxuXHJcbiAgLy8gUmVmZXRjaCBxdWV1ZTogYnVja2V0cyBhcmUga2V5ZWQgYnkgaGFuZGxlLlxyXG4gIGNvbnN0IHJxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgbGV0IHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKHJxKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIGRlbGV0ZSBycVtoXTtcclxuICAgICAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcnEpO1xyXG5cclxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogYnVja2V0cyBhcmUgaGludC1oYW5kbGVzIChvciBcIl91bmtub3duXCIpLiBEcm9wXHJcbiAgLy8gZW50cmllcyB3aG9zZSBidWNrZXQgaXNuJ3QgdGFyZ2V0ZWQgXHUyMDE0IGluY2x1ZGluZyBcIl91bmtub3duXCIgc2luY2Ugd2VcclxuICAvLyBjYW4ndCB2ZXJpZnkgcmVsYXRpb24uXHJcbiAgY29uc3QgbXEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBsZXQgbWVkaWFDcmF3bElkc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhtcSkpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBtZWRpYUNyYXdsSWRzUmVtb3ZlZCArPSAobXFbaF0gPz8gW10pLmxlbmd0aDtcclxuICAgICAgZGVsZXRlIG1xW2hdO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIG1xKTtcclxuXHJcbiAgY29uc3QgdHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcclxuICBsZXQgdGhyZWFkT3Blbklkc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyh0cSkpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICB0aHJlYWRPcGVuSWRzUmVtb3ZlZCArPSAodHFbaF0gPz8gW10pLmxlbmd0aDtcclxuICAgICAgZGVsZXRlIHRxW2hdO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5RdWV1ZScsIHRxKTtcclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIGNvdW50ZXJzUmVtb3ZlZCxcclxuICAgIGJ1ZmZlcnNSZW1vdmVkLFxyXG4gICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQsXHJcbiAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQsXHJcbiAgICBtZWRpYUNyYXdsSWRzUmVtb3ZlZCxcclxuICAgIHRocmVhZE9wZW5JZHNSZW1vdmVkLFxyXG4gIH07XHJcbn1cclxuXHJcbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcclxufVxyXG4iLCAiaW1wb3J0IHsgYXBwZW5kQWN0aXZpdHkgfSBmcm9tICcuL3N0b3JhZ2UuanMnO1xyXG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxubGV0IGJyb2FkY2FzdDogKChldjogTG9nRXZlbnQpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc2V0QnJvYWRjYXN0ZXIoZm46IChldjogTG9nRXZlbnQpID0+IHZvaWQpOiB2b2lkIHtcclxuICBicm9hZGNhc3QgPSBmbjtcclxufVxyXG5cclxuZnVuY3Rpb24gbm93SVNPKCk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGV2OiBMb2dFdmVudCA9IHsgdHM6IG5vd0lTTygpLCBsZXZlbCwgbXNnLCBjb250ZXh0OiByZWRhY3QoY29udGV4dCkgfTtcclxuICAvLyBDb25zb2xlIGZvciBkZXZ0b29scy5cclxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xyXG4gIGlmIChsZXZlbCA9PT0gJ2Vycm9yJykgY29uc29sZS5lcnJvcihsaW5lLCBldi5jb250ZXh0KTtcclxuICBlbHNlIGlmIChsZXZlbCA9PT0gJ3dhcm4nKSBjb25zb2xlLndhcm4obGluZSwgZXYuY29udGV4dCk7XHJcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcclxuICAvLyBQZXJzaXN0ZW50IHRhaWwuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBmYWlsZWQgdG8gYXBwZW5kIGFjdGl2aXR5JywgZXJyKTtcclxuICB9XHJcbiAgLy8gTGl2ZSBicm9hZGNhc3QgKGUuZy4gdG8gc2lkZWJhcikuXHJcbiAgdHJ5IHtcclxuICAgIGJyb2FkY2FzdD8uKGV2KTtcclxuICB9IGNhdGNoIHtcclxuICAgIC8vIFNpZGViYXIgbWF5IG5vdCBiZSBvcGVuOyB0aGF0J3MgZmluZS5cclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIGVtaXQoJ2luZm8nLCBtc2csIGNvbnRleHQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIGVtaXQoJ3dhcm4nLCBtc2csIGNvbnRleHQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHJldHVybiBlbWl0KCdlcnJvcicsIG1zZywgY29udGV4dCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZUVycm9yKGVycjogdW5rbm93bik6IHsgbWVzc2FnZTogc3RyaW5nOyBzdGFjazogc3RyaW5nIHwgbnVsbCB9IHtcclxuICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcclxuICB9XHJcbiAgdHJ5IHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIHsgbWVzc2FnZTogJzx1bnByaW50YWJsZSBlcnJvcj4nLCBzdGFjazogbnVsbCB9O1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFN0cmlwIGFueXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIFBBVCBvciBvdGhlciBsb25nIHNlY3JldCBmcm9tIGEgY29udGV4dFxyXG4gKiBvYmplY3QgYmVmb3JlIHBlcnNpc3RpbmcgaXQuIERlZmVuc2l2ZTogY2FsbGVycyBzaG91bGQgbm90IGxvZyB0b2tlbnMsIGJ1dFxyXG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxyXG4gKi9cclxuZnVuY3Rpb24gcmVkYWN0KGN0eDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XHJcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xyXG4gIGZvciAoY29uc3QgW2ssIHZdIG9mIE9iamVjdC5lbnRyaWVzKGN0eCkpIHtcclxuICAgIGlmIChrLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ3Rva2VuJykgfHwgay50b0xvd2VyQ2FzZSgpID09PSAncGF0JyB8fCBrID09PSAnYXV0aG9yaXphdGlvbicpIHtcclxuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dezMwLH0vLnRlc3QodikpIHtcclxuICAgICAgb3V0W2tdID0gdi5yZXBsYWNlKC9naXRodWJfcGF0X1tBLVphLXowLTlfXSsvZywgJ2dpdGh1Yl9wYXRfPHJlZGFjdGVkPicpO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XHJcbiAgICAgIG91dFtrXSA9IGAke3Yuc2xpY2UoMCwgNDA5Nil9XHUyMDI2PHRydW5jYXRlZD5gO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgb3V0W2tdID0gdjtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG4iLCAiaW1wb3J0IHsgZGVzY3JpYmVFcnJvciB9IGZyb20gJy4vbG9nZ2VyLmpzJztcclxuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuY29uc3QgQVBJX0JBU0UgPSAnaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbSc7XHJcbmNvbnN0IFJBV19CQVNFID0gJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSc7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFB1dEZpbGVPcHRpb25zIHtcclxuICBwYXRoOiBzdHJpbmc7XHJcbiAgY29udGVudEJhc2U2NDogc3RyaW5nO1xyXG4gIG1lc3NhZ2U6IHN0cmluZztcclxuICBleHBlY3RlZFNoYT86IHN0cmluZyB8IG51bGw7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZVJlc3VsdCB7XHJcbiAgcGF0aDogc3RyaW5nO1xyXG4gIHNoYTogc3RyaW5nO1xyXG4gIHVybDogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVPcHRpb25zIHtcclxuICBwYXRoOiBzdHJpbmc7XHJcbiAgY29udGVudEJhc2U2NDogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVzT3B0aW9ucyB7XHJcbiAgZmlsZXM6IENvbW1pdEZpbGVPcHRpb25zW107XHJcbiAgbWVzc2FnZTogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVzUmVzdWx0IHtcclxuICBjb21taXRTaGE6IHN0cmluZztcclxuICB1cmw6IHN0cmluZztcclxuICBmaWxlczogc3RyaW5nW107XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBHaXRIdWJFcnJvciBleHRlbmRzIEVycm9yIHtcclxuICBzdGF0dXM6IG51bWJlcjtcclxuICBib2R5OiB1bmtub3duO1xyXG4gIHJldHJpYWJsZTogYm9vbGVhbjtcclxuICBjYXRlZ29yeTogJ2F1dGgnIHwgJ3JhdGUtbGltaXQnIHwgJ2NvbmZsaWN0JyB8ICdub3QtZm91bmQnIHwgJ3NlcnZlcicgfCAnbmV0d29yaycgfCAndW5rbm93bic7XHJcbiAgLyoqIFdoZW4gdGhlIEdpdEh1YiByYXRlLWxpbWl0IHdpbmRvdyBmb3IgdGhpcyB0b2tlbiByZXNldHMsIGFzIGEgVW5peFxyXG4gICAqIGVwb2NoIGluIHNlY29uZHMuIFBvcHVsYXRlZCBmcm9tIGBYLVJhdGVMaW1pdC1SZXNldGAgb24gNDAzLzQyOSwgb3JcclxuICAgKiBkZXJpdmVkIGZyb20gYFJldHJ5LUFmdGVyYCBmb3Igc2Vjb25kYXJ5IGxpbWl0cy4gbnVsbCB3aGVuIHVua25vd24uICovXHJcbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVtYmVyIHwgbnVsbDtcclxuXHJcbiAgY29uc3RydWN0b3Iob3B0czoge1xyXG4gICAgc3RhdHVzOiBudW1iZXI7XHJcbiAgICBib2R5OiB1bmtub3duO1xyXG4gICAgbWVzc2FnZTogc3RyaW5nO1xyXG4gICAgcmV0cmlhYmxlOiBib29sZWFuO1xyXG4gICAgY2F0ZWdvcnk6IEdpdEh1YkVycm9yWydjYXRlZ29yeSddO1xyXG4gICAgcmF0ZUxpbWl0UmVzZXRBdD86IG51bWJlciB8IG51bGw7XHJcbiAgfSkge1xyXG4gICAgc3VwZXIob3B0cy5tZXNzYWdlKTtcclxuICAgIHRoaXMubmFtZSA9ICdHaXRIdWJFcnJvcic7XHJcbiAgICB0aGlzLnN0YXR1cyA9IG9wdHMuc3RhdHVzO1xyXG4gICAgdGhpcy5ib2R5ID0gb3B0cy5ib2R5O1xyXG4gICAgdGhpcy5yZXRyaWFibGUgPSBvcHRzLnJldHJpYWJsZTtcclxuICAgIHRoaXMuY2F0ZWdvcnkgPSBvcHRzLmNhdGVnb3J5O1xyXG4gICAgdGhpcy5yYXRlTGltaXRSZXNldEF0ID0gb3B0cy5yYXRlTGltaXRSZXNldEF0ID8/IG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgR2l0SHViQ2xpZW50IHtcclxuICBwcml2YXRlIHJlYWRvbmx5IHNldHRpbmdzOiBTZXR0aW5ncztcclxuXHJcbiAgY29uc3RydWN0b3Ioc2V0dGluZ3M6IFNldHRpbmdzKSB7XHJcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XHJcbiAgfVxyXG5cclxuICAvKiogUmV0dXJucyB0aGUgYXV0aGVudGljYXRlZCB1c2VyJ3MgbG9naW4uIFRocm93cyBvbiBhdXRoIGZhaWx1cmUuICovXHJcbiAgYXN5bmMgd2hvYW1pKCk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgJy91c2VyJyk7XHJcbiAgICByZXR1cm4gKHJlcyBhcyB7IGxvZ2luPzogc3RyaW5nIH0pLmxvZ2luID8/ICc8dW5rbm93bj4nO1xyXG4gIH1cclxuXHJcbiAgLyoqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZ2l2ZW4gYnJhbmNoIGV4aXN0cyBvbiB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xyXG4gIGFzeW5jIGJyYW5jaEV4aXN0cyhicmFuY2g6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXHJcbiAgICAgICAgJ0dFVCcsXHJcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9icmFuY2hlcy8ke2VuY29kZVVSSUNvbXBvbmVudChicmFuY2gpfWBcclxuICAgICAgKTtcclxuICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBmYWxzZTtcclxuICAgICAgdGhyb3cgZXJyO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqIFZlcmlmaWVzIHRoZSBQQVQgY2FuIHNlZSB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xyXG4gIGFzeW5jIHZlcmlmeVJlcG9BY2Nlc3MoKTogUHJvbWlzZTx7IGxvZ2luOiBzdHJpbmc7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH0+IHtcbiAgICBjb25zdCBtZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICBjb25zdCByZXBvID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb31gKTtcbiAgICBjb25zdCByID0gcmVwbyBhcyB7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGxvZ2luOiAobWUgYXMgeyBsb2dpbjogc3RyaW5nIH0pLmxvZ2luLFxuICAgICAgZnVsbF9uYW1lOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogVmVyaWZ5IHRoZSBQQVQgY2FuIHdyaXRlIHRvIHRoZSBjb25maWd1cmVkIGJyYW5jaCB3aXRob3V0IGNyZWF0aW5nIGFcbiAgICogY29tbWl0LiBNb3ZpbmcgYSByZWYgdG8gaXRzIGN1cnJlbnQgU0hBIGlzIGEgbm8tb3AsIGJ1dCBHaXRIdWIgc3RpbGxcbiAgICogZW5mb3JjZXMgdGhlIENvbnRlbnRzOiBXcml0ZSBwZXJtaXNzaW9uIHJlcXVpcmVkIGJ5IGNvbW1pdEZpbGVzKCkuXG4gICAqL1xuICBhc3luYyB2ZXJpZnlXcml0ZUFjY2VzcygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XG4gICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAnUEFUQ0gnLFxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXG4gICAgICB7XG4gICAgICAgIHNoYTogaGVhZC5zaGEsXG4gICAgICAgIGZvcmNlOiBmYWxzZSxcbiAgICAgIH1cbiAgICApO1xuICB9XG5cclxuICAvKipcclxuICAgKiBGZXRjaCBhIHRleHQgZmlsZSBmcm9tIHJhdy5naXRodWJ1c2VyY29udGVudC5jb20gYXV0aGVudGljYXRlZCB3aXRoIHRoZVxyXG4gICAqIFBBVC4gUmV0dXJucyBudWxsIGlmIHRoZSBmaWxlIGRvZXNuJ3QgZXhpc3QuIFVzZWQgZm9yIGNvbmZpZy9hY2NvdW50cy55YW1sLlxyXG4gICAqL1xyXG4gIGFzeW5jIGZldGNoUmF3VGV4dChwYXRoSW5SZXBvOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICAgIGNvbnN0IHVybCA9IGAke1JBV19CQVNFfS8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS8ke3RoaXMuc2V0dGluZ3MuYnJhbmNofS8ke3BhdGhJblJlcG99YDtcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCwge1xyXG4gICAgICBtZXRob2Q6ICdHRVQnLFxyXG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLnNldHRpbmdzLnBhdH1gIH0sXHJcbiAgICB9KTtcclxuICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDQpIHJldHVybiBudWxsO1xyXG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yKHJlcywgYEdFVCByYXcgJHtwYXRoSW5SZXBvfWApO1xyXG4gICAgcmV0dXJuIHJlcy50ZXh0KCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBMb29rIHVwIGFuIGV4aXN0aW5nIGZpbGUncyBTSEEgdmlhIHRoZSBDb250ZW50cyBBUEksIG9yIG51bGwgaWYgbm90IGZvdW5kLlxyXG4gICAqIFVzZWQgd2hlbiByZXRyeWluZyBhIFBVVCBhZnRlciBhIDQyMiBzaGEgbWlzbWF0Y2guXHJcbiAgICovXHJcbiAgYXN5bmMgZ2V0RmlsZVNoYShwYXRoOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICdHRVQnLFxyXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vY29udGVudHMvJHtlbmNvZGVQYXRoKHBhdGgpfT9yZWY9JHtlbmNvZGVVUklDb21wb25lbnQodGhpcy5zZXR0aW5ncy5icmFuY2gpfWBcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgciA9IHJlcyBhcyB7IHNoYT86IHN0cmluZyB9O1xyXG4gICAgICByZXR1cm4gci5zaGEgPz8gbnVsbDtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBpZiAoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgZXJyLmNhdGVnb3J5ID09PSAnbm90LWZvdW5kJykgcmV0dXJuIG51bGw7XHJcbiAgICAgIHRocm93IGVycjtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFBVVCBhIGZpbGUgdG8gdGhlIHJlcG8uIEhhbmRsZXMgNDIyIChzaGEgcmVxdWlyZWQpIGJ5IHJlLWZldGNoaW5nIHRoZVxyXG4gICAqIGV4aXN0aW5nIHNoYSBhbmQgcmV0cnlpbmcgb25jZS4gUmV0cmllcyBuZXR3b3JrIC8gNXh4IC8gcmF0ZS1saW1pdCBlcnJvcnNcclxuICAgKiB3aXRoIGV4cG9uZW50aWFsIGJhY2tvZmYgdXAgdG8gbWF4QXR0ZW1wdHMuXHJcbiAgICovXHJcbiAgYXN5bmMgcHV0RmlsZShvcHRzOiBQdXRGaWxlT3B0aW9ucyk6IFByb21pc2U8UHV0RmlsZVJlc3VsdD4ge1xyXG4gICAgY29uc3QgcGF0aCA9IG9wdHMucGF0aDtcclxuICAgIGNvbnN0IHVybCA9IGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vY29udGVudHMvJHtlbmNvZGVQYXRoKHBhdGgpfWA7XHJcbiAgICBsZXQgc2hhOiBzdHJpbmcgfCBudWxsID0gb3B0cy5leHBlY3RlZFNoYSA/PyBudWxsO1xyXG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xyXG5cclxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcclxuICAgICAgY29uc3QgYm9keTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XHJcbiAgICAgICAgbWVzc2FnZTogb3B0cy5tZXNzYWdlLFxyXG4gICAgICAgIGNvbnRlbnQ6IG9wdHMuY29udGVudEJhc2U2NCxcclxuICAgICAgICBicmFuY2g6IHRoaXMuc2V0dGluZ3MuYnJhbmNoLFxyXG4gICAgICB9O1xyXG4gICAgICBpZiAoc2hhKSBib2R5LnNoYSA9IHNoYTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignUFVUJywgdXJsLCBib2R5KTtcclxuICAgICAgICBjb25zdCBvdXQgPSByZXMgYXMgeyBjb250ZW50OiB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nOyBwYXRoOiBzdHJpbmcgfSB9O1xyXG4gICAgICAgIHJldHVybiB7IHBhdGg6IG91dC5jb250ZW50LnBhdGgsIHNoYTogb3V0LmNvbnRlbnQuc2hhLCB1cmw6IG91dC5jb250ZW50Lmh0bWxfdXJsIH07XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xyXG4gICAgICAgIGlmIChlcnIuc3RhdHVzID09PSA0MjIgJiYgIXNoYSkge1xyXG4gICAgICAgICAgLy8gRmlsZSBhbHJlYWR5IGV4aXN0czsgZmV0Y2ggaXRzIHNoYSBhbmQgcmV0cnkgb25jZS5cclxuICAgICAgICAgIHNoYSA9IGF3YWl0IHRoaXMuZ2V0RmlsZVNoYShwYXRoKTtcclxuICAgICAgICAgIGlmICghc2hhKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCFlcnIucmV0cmlhYmxlIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoYHB1dEZpbGU6IGV4aGF1c3RlZCBhdHRlbXB0cyBmb3IgJHtwYXRofWApO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogQ29tbWl0IHNldmVyYWwgZmlsZXMgd2l0aCBvbmUgYnJhbmNoIHVwZGF0ZS4gVGhlIENvbnRlbnRzIEFQSSBjcmVhdGVzIG9uZVxyXG4gICAqIGNvbW1pdCBwZXIgUFVULCBzbyByYXBpZCBmbHVzaGVzIHJhY2UgZWFjaCBvdGhlciBvbiB0aGUgYnJhbmNoIGhlYWQuIFRoaXNcclxuICAgKiB1c2VzIHRoZSBsb3dlci1sZXZlbCBHaXQgRGF0YSBBUEkgaW5zdGVhZDogdXBsb2FkIGJsb2JzLCBidWlsZCBhIHRyZWUsXHJcbiAgICogY3JlYXRlIG9uZSBjb21taXQsIHRoZW4gbW92ZSB0aGUgYnJhbmNoIHJlZiBvbmNlLiBJZiBhbm90aGVyIHdyaXRlciBtb3Zlc1xyXG4gICAqIHRoZSBicmFuY2ggZmlyc3QsIHJlYmFzZSB0aGlzIHRyZWUgcGF0Y2ggb250byB0aGUgbGF0ZXN0IGhlYWQgYW5kIHJldHJ5LlxyXG4gICAqL1xyXG4gIGFzeW5jIGNvbW1pdEZpbGVzKG9wdHM6IENvbW1pdEZpbGVzT3B0aW9ucyk6IFByb21pc2U8Q29tbWl0RmlsZXNSZXN1bHQ+IHtcclxuICAgIGlmIChvcHRzLmZpbGVzLmxlbmd0aCA9PT0gMCkgdGhyb3cgbmV3IEVycm9yKCdjb21taXRGaWxlczogbm8gZmlsZXMgdG8gY29tbWl0Jyk7XHJcbiAgICBjb25zdCBtYXhBdHRlbXB0cyA9IDU7XHJcbiAgICBsZXQgbGFzdEVycjogdW5rbm93biA9IG51bGw7XHJcblxyXG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDE7IGF0dGVtcHQgPD0gbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGJsb2JzID0gYXdhaXQgUHJvbWlzZS5hbGwoXHJcbiAgICAgICAgICBvcHRzLmZpbGVzLm1hcChhc3luYyAoZmlsZSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBvdXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcclxuICAgICAgICAgICAgICAnUE9TVCcsXHJcbiAgICAgICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvYmxvYnNgLFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGZpbGUuY29udGVudEJhc2U2NCxcclxuICAgICAgICAgICAgICAgIGVuY29kaW5nOiAnYmFzZTY0JyxcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgcGF0aDogZmlsZS5wYXRoLFxyXG4gICAgICAgICAgICAgIHNoYTogKG91dCBhcyB7IHNoYTogc3RyaW5nIH0pLnNoYSxcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgY29uc3QgaGVhZCA9IGF3YWl0IHRoaXMuZ2V0QnJhbmNoSGVhZCgpO1xyXG4gICAgICAgIGNvbnN0IHRyZWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcclxuICAgICAgICAgICdQT1NUJyxcclxuICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L3RyZWVzYCxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgYmFzZV90cmVlOiBoZWFkLnRyZWVTaGEsXHJcbiAgICAgICAgICAgIHRyZWU6IGJsb2JzLm1hcCgoYmxvYikgPT4gKHtcclxuICAgICAgICAgICAgICBwYXRoOiBibG9iLnBhdGgsXHJcbiAgICAgICAgICAgICAgbW9kZTogJzEwMDY0NCcsXHJcbiAgICAgICAgICAgICAgdHlwZTogJ2Jsb2InLFxyXG4gICAgICAgICAgICAgIHNoYTogYmxvYi5zaGEsXHJcbiAgICAgICAgICAgIH0pKSxcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IHRyZWVTaGEgPSAodHJlZSBhcyB7IHNoYTogc3RyaW5nIH0pLnNoYTtcclxuICAgICAgICBjb25zdCBjb21taXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcclxuICAgICAgICAgICdQT1NUJyxcclxuICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L2NvbW1pdHNgLFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXHJcbiAgICAgICAgICAgIHRyZWU6IHRyZWVTaGEsXHJcbiAgICAgICAgICAgIHBhcmVudHM6IFtoZWFkLnNoYV0sXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgICAgICBjb25zdCBjb21taXRPdXQgPSBjb21taXQgYXMgeyBzaGE6IHN0cmluZzsgaHRtbF91cmw6IHN0cmluZyB9O1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCB0aGlzLmZldGNoSnNvbihcclxuICAgICAgICAgICAgJ1BBVENIJyxcclxuICAgICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBzaGE6IGNvbW1pdE91dC5zaGEsXHJcbiAgICAgICAgICAgICAgZm9yY2U6IGZhbHNlLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgaWYgKGlzQ29uZmxpY3QoZXJyKSAmJiBhdHRlbXB0IDwgbWF4QXR0ZW1wdHMpIHtcclxuICAgICAgICAgICAgbGFzdEVyciA9IGVycjtcclxuICAgICAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xyXG4gICAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHRocm93IGVycjtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGNvbW1pdFNoYTogY29tbWl0T3V0LnNoYSxcclxuICAgICAgICAgIHVybDogY29tbWl0T3V0Lmh0bWxfdXJsLFxyXG4gICAgICAgICAgZmlsZXM6IG9wdHMuZmlsZXMubWFwKChmaWxlKSA9PiBmaWxlLnBhdGgpLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGxhc3RFcnIgPSBlcnI7XHJcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgaWYgKCghZXJyLnJldHJpYWJsZSAmJiAhaXNDb25mbGljdChlcnIpKSB8fCBhdHRlbXB0ID09PSBtYXhBdHRlbXB0cykgdGhyb3cgZXJyO1xyXG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhyb3cgbGFzdEVyciBpbnN0YW5jZW9mIEVycm9yID8gbGFzdEVyciA6IG5ldyBFcnJvcignY29tbWl0RmlsZXM6IGV4aGF1c3RlZCBhdHRlbXB0cycpO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhc3luYyBnZXRCcmFuY2hIZWFkKCk6IFByb21pc2U8eyBzaGE6IHN0cmluZzsgdHJlZVNoYTogc3RyaW5nIH0+IHtcclxuICAgIGNvbnN0IHJlZiA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAnR0VUJyxcclxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmL2hlYWRzLyR7ZW5jb2RlUGF0aCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxyXG4gICAgKTtcclxuICAgIGNvbnN0IGhlYWRTaGEgPSAocmVmIGFzIHsgb2JqZWN0OiB7IHNoYTogc3RyaW5nIH0gfSkub2JqZWN0LnNoYTtcclxuICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAnR0VUJyxcclxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvY29tbWl0cy8ke2hlYWRTaGF9YFxyXG4gICAgKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHNoYTogaGVhZFNoYSxcclxuICAgICAgdHJlZVNoYTogKGNvbW1pdCBhcyB7IHRyZWU6IHsgc2hhOiBzdHJpbmcgfSB9KS50cmVlLnNoYSxcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGFzeW5jIGZldGNoSnNvbihtZXRob2Q6IHN0cmluZywgcGF0aDogc3RyaW5nLCBib2R5PzogdW5rbm93bik6IFByb21pc2U8dW5rbm93bj4ge1xyXG4gICAgY29uc3QgdXJsID0gcGF0aC5zdGFydHNXaXRoKCdodHRwJykgPyBwYXRoIDogYCR7QVBJX0JBU0V9JHtwYXRofWA7XHJcbiAgICBjb25zdCBpbml0OiBSZXF1ZXN0SW5pdCA9IHtcclxuICAgICAgbWV0aG9kLFxyXG4gICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAsXHJcbiAgICAgICAgQWNjZXB0OiAnYXBwbGljYXRpb24vdm5kLmdpdGh1Yitqc29uJyxcclxuICAgICAgICAnWC1HaXRIdWItQXBpLVZlcnNpb24nOiAnMjAyMi0xMS0yOCcsXHJcbiAgICAgICAgLi4uKGJvZHkgPyB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSA6IHt9KSxcclxuICAgICAgfSxcclxuICAgICAgLi4uKGJvZHkgPyB7IGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpIH0gOiB7fSksXHJcbiAgICB9O1xyXG4gICAgbGV0IHJlczogUmVzcG9uc2U7XHJcbiAgICB0cnkge1xyXG4gICAgICByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIGluaXQpO1xyXG4gICAgfSBjYXRjaCAobmV0RXJyKSB7XHJcbiAgICAgIHRocm93IG5ldyBHaXRIdWJFcnJvcih7XHJcbiAgICAgICAgc3RhdHVzOiAwLFxyXG4gICAgICAgIGJvZHk6IG51bGwsXHJcbiAgICAgICAgbWVzc2FnZTogYG5ldHdvcms6ICR7ZGVzY3JpYmVFcnJvcihuZXRFcnIpLm1lc3NhZ2V9YCxcclxuICAgICAgICByZXRyaWFibGU6IHRydWUsXHJcbiAgICAgICAgY2F0ZWdvcnk6ICduZXR3b3JrJyxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gMjA0KSByZXR1cm4gbnVsbDtcclxuICAgIGxldCBwYXJzZWQ6IHVua25vd24gPSBudWxsO1xyXG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XHJcbiAgICBpZiAodGV4dCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XHJcbiAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgIHBhcnNlZCA9IHRleHQ7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICghcmVzLm9rKSB0aHJvdyBhd2FpdCB0aGlzLm1ha2VFcnJvckZyb21QYXJzZWQocmVzLCBwYXJzZWQsIGAke21ldGhvZH0gJHtwYXRofWApO1xyXG4gICAgcmV0dXJuIHBhcnNlZDtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgYXN5bmMgbWFrZUVycm9yKHJlczogUmVzcG9uc2UsIGxhYmVsOiBzdHJpbmcpOiBQcm9taXNlPEdpdEh1YkVycm9yPiB7XHJcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xyXG4gICAgICBpZiAodGV4dCkgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBpZ25vcmVcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLm1ha2VFcnJvckZyb21QYXJzZWQocmVzLCBwYXJzZWQsIGxhYmVsKTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgbWFrZUVycm9yRnJvbVBhcnNlZChyZXM6IFJlc3BvbnNlLCBib2R5OiB1bmtub3duLCBsYWJlbDogc3RyaW5nKTogR2l0SHViRXJyb3Ige1xyXG4gICAgY29uc3QgbXNnID1cclxuICAgICAgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmIGJvZHkgJiYgJ21lc3NhZ2UnIGluIGJvZHlcclxuICAgICAgICA/IFN0cmluZygoYm9keSBhcyB7IG1lc3NhZ2U6IHVua25vd24gfSkubWVzc2FnZSlcclxuICAgICAgICA6IHJlcy5zdGF0dXNUZXh0O1xyXG4gICAgbGV0IGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXSA9ICd1bmtub3duJztcclxuICAgIGxldCByZXRyaWFibGUgPSBmYWxzZTtcclxuICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDEgfHwgcmVzLnN0YXR1cyA9PT0gNDAzKSB7XHJcbiAgICAgIC8vIDQwMyBjYW4gYmUgZWl0aGVyIGF1dGggb3IgcmF0ZSBsaW1pdDsgY2hlY2sgaGVhZGVycy5cclxuICAgICAgY29uc3QgcmF0ZSA9IHJlcy5oZWFkZXJzLmdldCgneC1yYXRlbGltaXQtcmVtYWluaW5nJyk7XHJcbiAgICAgIGlmIChyYXRlID09PSAnMCcgfHwgL3JhdGUgbGltaXQvaS50ZXN0KG1zZykpIHtcclxuICAgICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcclxuICAgICAgICByZXRyaWFibGUgPSB0cnVlO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNhdGVnb3J5ID0gJ2F1dGgnO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkge1xyXG4gICAgICBjYXRlZ29yeSA9ICdub3QtZm91bmQnO1xyXG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID09PSA0MDkgfHwgcmVzLnN0YXR1cyA9PT0gNDIyKSB7XHJcbiAgICAgIGNhdGVnb3J5ID0gJ2NvbmZsaWN0JztcclxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA+PSA1MDApIHtcclxuICAgICAgY2F0ZWdvcnkgPSAnc2VydmVyJztcclxuICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcclxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDI5KSB7XHJcbiAgICAgIGNhdGVnb3J5ID0gJ3JhdGUtbGltaXQnO1xyXG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIG5ldyBHaXRIdWJFcnJvcih7XHJcbiAgICAgIHN0YXR1czogcmVzLnN0YXR1cyxcclxuICAgICAgYm9keSxcclxuICAgICAgbWVzc2FnZTogYCR7bGFiZWx9IFx1MjE5MiAke3Jlcy5zdGF0dXN9OiAke21zZ31gLFxyXG4gICAgICByZXRyaWFibGUsXHJcbiAgICAgIGNhdGVnb3J5LFxyXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBjYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnID8gcGFyc2VSYXRlTGltaXRSZXNldChyZXMuaGVhZGVycykgOiBudWxsLFxyXG4gICAgfSk7XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogQmVzdC1lZmZvcnQgcGFyc2Ugb2Ygd2hlbiB0aGUgY3VycmVudCByYXRlLWxpbWl0IHdpbmRvdyBlbmRzLiBHaXRIdWInc1xyXG4gKiBwcmltYXJ5IGxpbWl0IHJlcG9ydHMgYFgtUmF0ZUxpbWl0LVJlc2V0YCBhcyBhIFVuaXggZXBvY2ggaW4gc2Vjb25kcy5cclxuICogU2Vjb25kYXJ5IC8gYWJ1c2UgbGltaXRzIHVzZSBgUmV0cnktQWZ0ZXJgLCB3aGljaCBpcyBlaXRoZXIgYW4gSFRUUC1kYXRlXHJcbiAqIG9yIGEgZGVsdGEgaW4gc2Vjb25kcyBcdTIwMTQgd2Ugbm9ybWFsaXplIGJvdGggdG8gZXBvY2ggc2Vjb25kcy5cclxuICovXHJcbmZ1bmN0aW9uIHBhcnNlUmF0ZUxpbWl0UmVzZXQoaGVhZGVyczogSGVhZGVycyk6IG51bWJlciB8IG51bGwge1xyXG4gIGNvbnN0IHJlc2V0ID0gaGVhZGVycy5nZXQoJ3gtcmF0ZWxpbWl0LXJlc2V0Jyk7XHJcbiAgaWYgKHJlc2V0KSB7XHJcbiAgICBjb25zdCBuID0gTnVtYmVyLnBhcnNlSW50KHJlc2V0LCAxMCk7XHJcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKG4pICYmIG4gPiAwKSByZXR1cm4gbjtcclxuICB9XHJcbiAgY29uc3QgcmV0cnlBZnRlciA9IGhlYWRlcnMuZ2V0KCdyZXRyeS1hZnRlcicpO1xyXG4gIGlmIChyZXRyeUFmdGVyKSB7XHJcbiAgICBjb25zdCBkZWx0YSA9IE51bWJlci5wYXJzZUludChyZXRyeUFmdGVyLCAxMCk7XHJcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGRlbHRhKSAmJiBkZWx0YSA+PSAwKSB7XHJcbiAgICAgIHJldHVybiBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKSArIGRlbHRhO1xyXG4gICAgfVxyXG4gICAgY29uc3QgYXNEYXRlID0gRGF0ZS5wYXJzZShyZXRyeUFmdGVyKTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYXNEYXRlKSkgcmV0dXJuIE1hdGguZmxvb3IoYXNEYXRlIC8gMTAwMCk7XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcblxyXG5mdW5jdGlvbiBlbmNvZGVQYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgLy8gRW5jb2RlIHNlZ21lbnRzIGluZGl2aWR1YWxseSBzbyBzbGFzaGVzIHJlbWFpbi5cclxuICByZXR1cm4gcGF0aC5zcGxpdCgnLycpLm1hcChlbmNvZGVVUklDb21wb25lbnQpLmpvaW4oJy8nKTtcclxufVxyXG5cclxuZnVuY3Rpb24gYmFja29mZk1zKGF0dGVtcHQ6IG51bWJlciwgZXJyOiBHaXRIdWJFcnJvcik6IG51bWJlciB7XHJcbiAgLy8gRXhwb25lbnRpYWwgd2l0aCBqaXR0ZXI7IGJ1bXAgaGlnaGVyIGZvciByYXRlLWxpbWl0IHJlc3BvbnNlcy5cclxuICBjb25zdCBiYXNlID0gZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyA1MDAwIDogNTAwO1xyXG4gIGNvbnN0IGppdHRlciA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDQwMCk7XHJcbiAgcmV0dXJuIE1hdGgubWluKDYwXzAwMCwgYmFzZSAqIDIgKiogKGF0dGVtcHQgLSAxKSArIGppdHRlcik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGlzQ29uZmxpY3QoZXJyOiB1bmtub3duKTogZXJyIGlzIEdpdEh1YkVycm9yIHtcclxuICByZXR1cm4gZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgZXJyLmNhdGVnb3J5ID09PSAnY29uZmxpY3QnO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzbGVlcChtczogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB0b0Jhc2U2NChieXRlczogc3RyaW5nKTogc3RyaW5nIHtcclxuICAvLyBieXRlcyBpcyBhIFVURi04IHN0cmluZyBvZiBKU09OOyBlbmNvZGUgdG8gYmFzZTY0IHRoZSBzYWZlIHdheS5cclxuICBjb25zdCB1dGY4ID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKGJ5dGVzKTtcclxuICBsZXQgYmluID0gJyc7XHJcbiAgZm9yIChjb25zdCBiIG9mIHV0ZjgpIGJpbiArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xyXG4gIHJldHVybiBidG9hKGJpbik7XHJcbn1cclxuIiwgImltcG9ydCB7IFRXRUVUX1VSTF9QUkVGSVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBDYW5vbmljYWxUd2VldCxcclxuICBDb21tdW5pdHlOb3RlLFxyXG4gIE1lZGlhSXRlbSxcclxuICBUd2VldENhcmQsXHJcbiAgVHdlZXRUeXBlLFxyXG4gIFVuYXZhaWxhYmxlVHdlZXQsXHJcbiAgVXJsRW50aXR5LFxyXG4gIFVzZXJTbmFwc2hvdCxcclxufSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbi8qKlxyXG4gKiBOb3JtYWxpemUgR3JhcGhRTCByZXNwb25zZSBwYXlsb2FkcyBmcm9tIFgncyBpbnRlcm5hbCBBUEkgaW50b1xyXG4gKiBgQ2Fub25pY2FsVHdlZXRgcy4gTWFueSBlbmRwb2ludHMgc2hhcmUgYSBzaW1pbGFyIHR3ZWV0IHNoYXBlIGJ1dCB3cmFwIGl0IGluXHJcbiAqIGRpZmZlcmVudCBlbnZlbG9wZXM7IHRoaXMgbW9kdWxlIHdhbGtzIHRoZSBzdHJ1Y3R1cmUgZGVmZW5zaXZlbHkuXHJcbiAqXHJcbiAqIFRoZSBwYXJzZXIgaXMgaW50ZW50aW9uYWxseSBwZXJtaXNzaXZlOiBpdCB3aWxsIHNpbGVudGx5IHNraXAgZW50cmllcyBpdFxyXG4gKiBjYW4ndCByZWNvZ25pemUgYXMgdHdlZXRzIChjdXJzb3JzLCBhZHMsIGdhcCBlbnRyaWVzLCBtb2R1bGVzIG9mIG90aGVyXHJcbiAqIHR3ZWV0cywgdG9tYnN0b25lcykuIEl0IHRocm93cyAqb25seSogd2hlbiBnaXZlbiBhIHBheWxvYWQgaXQgZG9lc24ndCBrbm93XHJcbiAqIGhvdyB0byB3YWxrIGF0IGFsbCBcdTIwMTQgdGhvc2UgY2FzZXMgYXJlIGNhdWdodCBhbmQgcXVhcmFudGluZWQgdXBzdHJlYW0uXHJcbiAqL1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBOb3JtYWxpemVDb250ZXh0IHtcclxuICBjYXB0dXJlZEF0OiBzdHJpbmc7XHJcbiAgcnVuSWQ6IHN0cmluZztcclxuICBlbmRwb2ludDogc3RyaW5nO1xyXG4gIGFsbG93ZWRIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+O1xyXG4gIHNvdXJjZVVybD86IHN0cmluZyB8IG51bGw7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgTm9ybWFsaXplUmVzdWx0IHtcclxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W107XHJcbiAgb2JzZXJ2ZWRfaWRzOiBzdHJpbmdbXTtcclxuICB1bmF2YWlsYWJsZV90d2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXTtcclxuICAvKipcclxuICAgKiBUd2VldC1zaGFwZWQgbm9kZXMgdGhlIHdhbGtlciBzYXcgKGhhZCBhIGByZXN0X2lkYCkgYnV0IGNvdWxkbid0IHR1cm5cclxuICAgKiBpbnRvIGEgZnVsbCBgQ2Fub25pY2FsVHdlZXRgIFx1MjAxNCB0eXBpY2FsbHkgYmVjYXVzZSB0aGUgZW1iZWRkZWQgdXNlclxyXG4gICAqIGluZm8gd2FzIG1pc3Npbmcgb3IgdGhlIGVudHJ5IHdhcyBhIG1lZGlhLW9ubHkgdGh1bWJuYWlsIGNhcmQgZnJvbVxyXG4gICAqIHRoZSBVc2VyTWVkaWEgZW5kcG9pbnQuIE9ubHkgSURzIHdpdGggYSB0cnVzdHdvcnRoeSBoYW5kbGUgZnJvbSB0aGVcclxuICAgKiB0d2VldCBub2RlIGl0c2VsZiBhcmUgcmV0dXJuZWQ7IG90aGVyd2lzZSB0aGUgYmFja2dyb3VuZCBjYW5ub3QgYnVpbGRcclxuICAgKiBhIHJlbGlhYmxlIC88aGFuZGxlPi9zdGF0dXMvPGlkPiBkZXRhaWwgVVJMLlxyXG4gICAqL1xyXG4gIHBhcnRpYWxfaWRzOiBBcnJheTx7IHR3ZWV0X2lkOiBzdHJpbmc7IGhpbnRfaGFuZGxlOiBzdHJpbmcgfCBudWxsIH0+O1xyXG59XHJcblxyXG4vLyBYIHR3ZWV0IElEcyBhcmUgNjQtYml0IHBvc2l0aXZlIGludGVnZXJzIHNlcmlhbGl6ZWQgYXMgZGVjaW1hbCBzdHJpbmdzLlxyXG4vLyBUaGV5J3ZlIGdyb3duIHRvIDE5IGNoYXJzICh+MS41ZTE4KSBieSAyMDI2LiBSZWplY3QgYW55dGhpbmcgdGhhdCBkb2Vzbid0XHJcbi8vIG1hdGNoIHRoaXMgc2hhcGUgXHUyMDE0IG90aGVyd2lzZSBzcHVyaW91cyBjYXJkIElEcywgY3Vyc29yIHN0cmluZ3MsIGFkIHNsb3RcclxuLy8gSURzLCBldGMuIGVuZCB1cCBpbiB0aGUgcGFydGlhbC1jYXB0dXJlIHF1ZXVlIGFuZCB0aGUgY3Jhd2wgbG9vcFxyXG4vLyBuYXZpZ2F0ZXMgdG8gaW52YWxpZCBVUkxzIHRoYXQgc2hvdyBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXHJcbmNvbnN0IFRXRUVUX0lEX1JFID0gL15cXGR7MTUsMjB9JC87XHJcblxyXG4vLyBPbmx5IG9uZSBlbmRwb2ludCBhY3R1YWxseSBleHBvc2VzIHRoZSBmYWlsdXJlIG1vZGUgdGhlIHBhcnRpYWwtY2FwdHVyZVxyXG4vLyBxdWV1ZSBleGlzdHMgZm9yIFx1MjAxNCB0aGUgTWVkaWEgdGFiJ3MgYFVzZXJNZWRpYWAgcXVlcnkgcmV0dXJuaW5nXHJcbi8vIHRodW1ibmFpbC1vbmx5IGVudHJpZXMgd2l0aG91dCBhIHBvcHVsYXRlZCBhdXRob3IgYmxvY2suIEV2ZXJ5IG90aGVyXHJcbi8vIGVuZHBvaW50IHRoYXQgaGFuZHMgdXMgYSBgVHdlZXRgIHNoYXBlIGdpdmVzIHVzIHRoZSBmdWxsIGVudHJ5OyBpZlxyXG4vLyBgYnVpbGRUd2VldGAgZmFpbHMgdGhlcmUgaXQncyBhIHJlYWwgZXJyb3IsIG5vdCBcImdvIHJlLWZldGNoIHRoaXNcIi5cclxuLy8gUmVzdHJpY3RpbmcgcGFydGlhbC1pZCBlbWlzc2lvbiB0byBVc2VyTWVkaWEgc3RvcHMgdGhlIGZsb29kcyBvZlxyXG4vLyBmYWxzZSBwb3NpdGl2ZXMgcmVwb3J0ZWQgb24gUmVwbGllcyAvIFR3ZWV0RGV0YWlsIC8gU2VhcmNoVGltZWxpbmUuXHJcbmNvbnN0IFBBUlRJQUxfT0tfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJNZWRpYSddKTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemUocGF5bG9hZDogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogTm9ybWFsaXplUmVzdWx0IHtcclxuICBjb25zdCByYXdUd2VldHMgPSBjb2xsZWN0VHdlZXRzKHBheWxvYWQpO1xyXG4gIGNvbnN0IHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSA9IFtdO1xyXG4gIGNvbnN0IHVuYXZhaWxhYmxlVHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W10gPSBbXTtcclxuICBjb25zdCBvYnNlcnZlZDogc3RyaW5nW10gPSBbXTtcclxuICBjb25zdCBidWlsdCA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGNvbnN0IHBhcnRpYWxNYXAgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nIHwgbnVsbD4oKTtcclxuICBjb25zdCBjb2xsZWN0UGFydGlhbHMgPSBQQVJUSUFMX09LX0VORFBPSU5UUy5oYXMoY3R4LmVuZHBvaW50KTtcclxuICBmb3IgKGNvbnN0IHJhdyBvZiByYXdUd2VldHMpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHVuYXZhaWxhYmxlID0gcGlja1VuYXZhaWxhYmxlVHdlZXQocmF3LCBjdHgpO1xyXG4gICAgICBpZiAodW5hdmFpbGFibGUpIHtcclxuICAgICAgICB1bmF2YWlsYWJsZVR3ZWV0cy5wdXNoKHVuYXZhaWxhYmxlKTtcclxuICAgICAgICBvYnNlcnZlZC5wdXNoKHVuYXZhaWxhYmxlLnR3ZWV0X2lkKTtcclxuICAgICAgICBidWlsdC5hZGQodW5hdmFpbGFibGUudHdlZXRfaWQpO1xyXG4gICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IHQgPSBidWlsZFR3ZWV0KHJhdywgY3R4KTtcclxuICAgICAgaWYgKCF0KSB7XHJcbiAgICAgICAgaWYgKGNvbGxlY3RQYXJ0aWFscykge1xyXG4gICAgICAgICAgLy8gT25seSBlbnF1ZXVlIHJlYWwtdHdlZXQgc2hlbGxzIHdpdGggYSB0cnVzdHdvcnRoeSBoYW5kbGUgKG5vdFxyXG4gICAgICAgICAgLy8gdG9tYnN0b25lcywgc3RyaXBwZWQgbm9kZXMgbGFja2luZyBhIGxlZ2FjeSBibG9jaywgZ2FyYmFnZSBJRHMsXHJcbiAgICAgICAgICAvLyBvciBJRHMgdGhhdCB3b3VsZCByZXF1aXJlIGd1ZXNzaW5nIHRoZSBhdXRob3IgZnJvbSB0aGUgcGFnZSkuXHJcbiAgICAgICAgICBjb25zdCBwYXJ0aWFsID0gcGlja1BhcnRpYWwocmF3KTtcclxuICAgICAgICAgIGlmIChwYXJ0aWFsKSBwYXJ0aWFsTWFwLnNldChwYXJ0aWFsLnR3ZWV0X2lkLCBwYXJ0aWFsLmhpbnRfaGFuZGxlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29udGludWU7XHJcbiAgICAgIH1cclxuICAgICAgb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcclxuICAgICAgYnVpbHQuYWRkKHQudHdlZXRfaWQpO1xyXG4gICAgICBpZiAoY3R4LmFsbG93ZWRIYW5kbGVzLnNpemUgPT09IDAgfHwgY3R4LmFsbG93ZWRIYW5kbGVzLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSB7XHJcbiAgICAgICAgdHdlZXRzLnB1c2godCk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBPbmUgYmFkIGVudHJ5IHNob3VsZG4ndCB0YWtlIGRvd24gdGhlIHdob2xlIGJhdGNoLlxyXG4gICAgfVxyXG4gIH1cclxuICAvLyBBbnl0aGluZyB0aGF0IGVuZGVkIHVwIGluIHBhcnRpYWxNYXAgYnV0IEFMU08gY2FtZSBiYWNrIGFzIGEgYnVpbHRcclxuICAvLyB0d2VldCAoZGlmZmVyZW50IHdhbGtlciBwYXNzLCBzYW1lIGlkKSBpc24ndCBhY3R1YWxseSBwYXJ0aWFsLlxyXG4gIGNvbnN0IHBhcnRpYWxfaWRzOiBBcnJheTx7IHR3ZWV0X2lkOiBzdHJpbmc7IGhpbnRfaGFuZGxlOiBzdHJpbmcgfCBudWxsIH0+ID0gW107XHJcbiAgZm9yIChjb25zdCBbaWQsIGhpbnRdIG9mIHBhcnRpYWxNYXApIHtcclxuICAgIGlmIChidWlsdC5oYXMoaWQpKSBjb250aW51ZTtcclxuICAgIHBhcnRpYWxfaWRzLnB1c2goeyB0d2VldF9pZDogaWQsIGhpbnRfaGFuZGxlOiBoaW50IH0pO1xyXG4gIH1cclxuICByZXR1cm4geyB0d2VldHMsIG9ic2VydmVkX2lkczogb2JzZXJ2ZWQsIHVuYXZhaWxhYmxlX3R3ZWV0czogdW5hdmFpbGFibGVUd2VldHMsIHBhcnRpYWxfaWRzIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tVbmF2YWlsYWJsZVR3ZWV0KG5vZGU6IHVua25vd24sIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IFVuYXZhaWxhYmxlVHdlZXQgfCBudWxsIHtcclxuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIGlmIChuLl9fdHlwZW5hbWUgIT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCB0d2VldElkID1cclxuICAgIHN0ck9yTnVsbChuLnJlc3RfaWQpID8/XHJcbiAgICBwaWNrVHdlZXRJZEZyb21VcmxzKG5vZGUpID8/XHJcbiAgICAoY3R4LnNvdXJjZVVybCA/IHR3ZWV0SWRGcm9tVHdlZXRVcmwoY3R4LnNvdXJjZVVybCkgOiBudWxsKTtcclxuICBpZiAoIXR3ZWV0SWQgfHwgIVRXRUVUX0lEX1JFLnRlc3QodHdlZXRJZCkpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCB1bmF2YWlsYWJsZVRleHQgPSBwaWNrVG9tYnN0b25lVGV4dChub2RlKTtcclxuICByZXR1cm4ge1xyXG4gICAgdHdlZXRfaWQ6IHR3ZWV0SWQsXHJcbiAgICBhY2NvdW50X2hhbmRsZTpcclxuICAgICAgcGlja0hhbmRsZUZyb21Ud2VldFVybHMobm9kZSwgdHdlZXRJZCkgPz9cclxuICAgICAgKGN0eC5zb3VyY2VVcmwgPyBoYW5kbGVGcm9tVHdlZXRVcmwoY3R4LnNvdXJjZVVybCwgdHdlZXRJZCkgOiBudWxsKSxcclxuICAgIHVuYXZhaWxhYmxlX2RldGVjdGVkX2F0OiBjdHguY2FwdHVyZWRBdCxcclxuICAgIHVuYXZhaWxhYmxlX3JlYXNvbjogY2xhc3NpZnlVbmF2YWlsYWJsZVJlYXNvbih1bmF2YWlsYWJsZVRleHQpLFxyXG4gICAgdW5hdmFpbGFibGVfdGV4dDogdW5hdmFpbGFibGVUZXh0LFxyXG4gICAgdW5hdmFpbGFibGVfc291cmNlX3VybDogY3R4LnNvdXJjZVVybCA/PyBudWxsLFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tUd2VldElkRnJvbVVybHMobm9kZTogdW5rbm93bik6IHN0cmluZyB8IG51bGwge1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgY3VyID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgY29uc3QgaWQgPSB0d2VldElkRnJvbVR3ZWV0VXJsKGN1cik7XHJcbiAgICAgIGlmIChpZCkgcmV0dXJuIGlkO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHNlZW4uaGFzKGN1ciBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgY3VyKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHR3ZWV0SWRGcm9tVHdlZXRVcmwocmF3VXJsOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChyYXdVcmwsIFRXRUVUX1VSTF9QUkVGSVgpO1xyXG4gICAgaWYgKHVybC5ob3N0bmFtZSAhPT0gJ3guY29tJyAmJiB1cmwuaG9zdG5hbWUgIT09ICd0d2l0dGVyLmNvbScpIHJldHVybiBudWxsO1xyXG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC9bQS1aYS16MC05X117MSwxNX1cXC9zdGF0dXNcXC8oXFxkezE1LDIwfSkoPzpcXC98JCkvKTtcclxuICAgIHJldHVybiBtYXRjaD8uWzFdID8/IG51bGw7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tUb21ic3RvbmVUZXh0KG5vZGU6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcclxuICBjb25zdCBzdHJpbmdzOiBzdHJpbmdbXSA9IFtdO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgY3VyID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgY29uc3QgdHJpbW1lZCA9IGN1ci50cmltKCk7XHJcbiAgICAgIGlmIChcclxuICAgICAgICB0cmltbWVkLmxlbmd0aCA+PSA0ICYmXHJcbiAgICAgICAgIXRyaW1tZWQuc3RhcnRzV2l0aCgnaHR0cDovLycpICYmXHJcbiAgICAgICAgIXRyaW1tZWQuc3RhcnRzV2l0aCgnaHR0cHM6Ly8nKVxyXG4gICAgICApIHtcclxuICAgICAgICBzdHJpbmdzLnB1c2godHJpbW1lZCk7XHJcbiAgICAgIH1cclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAoY3VyID09PSBudWxsIHx8IHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSBjb250aW51ZTtcclxuICAgIGlmIChzZWVuLmhhcyhjdXIgYXMgb2JqZWN0KSkgY29udGludWU7XHJcbiAgICBzZWVuLmFkZChjdXIgYXMgb2JqZWN0KTtcclxuICAgIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIGN1cikgc3RhY2sucHVzaCh2KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IHByZWZlcnJlZCA9IHN0cmluZ3MuZmluZCgocykgPT5cclxuICAgIC9cXGIoY29weXJpZ2h0fGRtY2F8dW5hdmFpbGFibGV8d2l0aGhlbGR8cmVtb3ZlZHxkZWxldGVkfHZpb2xhdHxzdXNwZW5kZWQpXFxiL2kudGVzdChzKVxyXG4gICk7XHJcbiAgcmV0dXJuIHByZWZlcnJlZCA/PyBzdHJpbmdzWzBdID8/IG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNsYXNzaWZ5VW5hdmFpbGFibGVSZWFzb24odGV4dDogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xyXG4gIGlmICghdGV4dCkgcmV0dXJuIG51bGw7XHJcbiAgaWYgKC9cXGIoY29weXJpZ2h0fGRtY2EpXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICdjb3B5cmlnaHQnO1xyXG4gIGlmICgvXFxid2l0aGhlbGRcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3dpdGhoZWxkJztcclxuICBpZiAoL1xcYmRlbGV0ZWR8cmVtb3ZlZFxcYi9pLnRlc3QodGV4dCkpIHJldHVybiAncmVtb3ZlZCc7XHJcbiAgaWYgKC9cXGJzdXNwZW5kZWRcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3N1c3BlbmRlZCc7XHJcbiAgaWYgKC9cXGJ1bmF2YWlsYWJsZXxub3QgYXZhaWxhYmxlXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICd1bmF2YWlsYWJsZSc7XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tQYXJ0aWFsKG5vZGU6IHVua25vd24pOiB7IHR3ZWV0X2lkOiBzdHJpbmc7IGhpbnRfaGFuZGxlOiBzdHJpbmcgfCBudWxsIH0gfCBudWxsIHtcclxuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIC8vIERlbGV0ZWQgdHdlZXRzIHN1cmZhY2UgYXMgVHdlZXRUb21ic3RvbmUgXHUyMDE0IHRoZXJlJ3Mgbm90aGluZyB0byByZWZldGNoLFxyXG4gIC8vIHNraXAgdGhlbSBvciB0aGUgY3Jhd2wgbG9vcCB3aWxsIHNwaW4gb24gXCJ0aGlzIHBhZ2UgZG9lc24ndCBleGlzdFwiLlxyXG4gIGlmIChuLl9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xyXG4gIC8vIFJlcXVpcmUgYSByZWNvZ25pemVkIFR3ZWV0IHR5cGVuYW1lIE9SIGEgbGVnYWN5IGJsb2NrLiBDdXJzb3JzLCBhZHMsXHJcbiAgLy8gbW9kdWxlIGhlYWRlcnMsIGFuZCB0aGUgbGlrZSBnZXQgcmVqZWN0ZWQgaGVyZS5cclxuICBjb25zdCB0biA9IG4uX190eXBlbmFtZTtcclxuICBpZiAodG4gIT09ICdUd2VldCcgJiYgdG4gIT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgJiYgIW9iaihuLmxlZ2FjeSkpIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxuICBjb25zdCByZXN0SWQgPVxyXG4gICAgKHR5cGVvZiBuLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIG4ucmVzdF9pZCkgfHxcclxuICAgICh0eXBlb2Ygb2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0ID09PSAnb2JqZWN0JyAmJlxyXG4gICAgICAob2JqKG9iaihuLnR3ZWV0X3Jlc3VsdCk/LnJlc3VsdCk/LnJlc3RfaWQgYXMgc3RyaW5nKSk7XHJcbiAgaWYgKHR5cGVvZiByZXN0SWQgIT09ICdzdHJpbmcnIHx8ICFUV0VFVF9JRF9SRS50ZXN0KHJlc3RJZCkpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IGhpbnRIYW5kbGUgPSBwaWNrSGludEhhbmRsZShub2RlLCByZXN0SWQpO1xyXG4gIGlmICghaGludEhhbmRsZSkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIHsgdHdlZXRfaWQ6IHJlc3RJZCwgaGludF9oYW5kbGU6IGhpbnRIYW5kbGUgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gcGlja0hpbnRIYW5kbGUobm9kZTogdW5rbm93biwgdHdlZXRJZDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JyB8fCBub2RlID09PSBudWxsKSByZXR1cm4gbnVsbDtcclxuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihvYmoobi5jb3JlKT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcclxuICByZXR1cm4gKFxyXG4gICAgc3RyT3JOdWxsKG9iaih1c2VyUmVzdWx0Py5jb3JlKT8uc2NyZWVuX25hbWUpID8/XHJcbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKG9iaihuLmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgcGlja0hhbmRsZUZyb21Ud2VldFVybHMobm9kZSwgdHdlZXRJZClcclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlOiB1bmtub3duLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xyXG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XHJcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IGN1ciA9IHN0YWNrLnBvcCgpO1xyXG4gICAgaWYgKHR5cGVvZiBjdXIgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgIGNvbnN0IGhhbmRsZSA9IGhhbmRsZUZyb21Ud2VldFVybChjdXIsIHR3ZWV0SWQpO1xyXG4gICAgICBpZiAoaGFuZGxlKSByZXR1cm4gaGFuZGxlO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHNlZW4uaGFzKGN1ciBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgY3VyKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGhhbmRsZUZyb21Ud2VldFVybChyYXdVcmw6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmF3VXJsLCBUV0VFVF9VUkxfUFJFRklYKTtcclxuICAgIGlmICh1cmwuaG9zdG5hbWUgIT09ICd4LmNvbScgJiYgdXJsLmhvc3RuYW1lICE9PSAndHdpdHRlci5jb20nKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IG1hdGNoID0gdXJsLnBhdGhuYW1lLm1hdGNoKC9eXFwvKFtBLVphLXowLTlfXXsxLDE1fSlcXC9zdGF0dXNcXC8oXFxkezE1LDIwfSkoPzpcXC98JCkvKTtcclxuICAgIGlmICghbWF0Y2ggfHwgbWF0Y2hbMl0gIT09IHR3ZWV0SWQpIHJldHVybiBudWxsO1xyXG4gICAgcmV0dXJuIG1hdGNoWzFdID8/IG51bGw7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNvbGxlY3RUd2VldHMob2JqOiB1bmtub3duKTogdW5rbm93bltdIHtcclxuICAvLyBXYWxrIHRoZSByZXNwb25zZSB0cmVlIGdhdGhlcmluZyBldmVyeXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIHR3ZWV0XHJcbiAgLy8gcmVzdWx0LiBXZSBsb29rIGZvciBub2RlcyBzaGFwZWQgbGlrZTpcclxuICAvLyAgIHsgX190eXBlbmFtZT86ICdUd2VldCd8J1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJywgcmVzdF9pZCwgbGVnYWN5IH1cclxuICAvLyBhbmQgdW53cmFwIHZpc2liaWxpdHkgd3JhcHBlcnMuXHJcbiAgY29uc3Qgb3V0OiB1bmtub3duW10gPSBbXTtcclxuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xyXG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbb2JqXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3Qgbm9kZSA9IHN0YWNrLnBvcCgpO1xyXG4gICAgaWYgKG5vZGUgPT09IG51bGwgfHwgbm9kZSA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcclxuICAgIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHNlZW4uaGFzKG5vZGUgYXMgb2JqZWN0KSkgY29udGludWU7XHJcbiAgICBzZWVuLmFkZChub2RlIGFzIG9iamVjdCk7XHJcblxyXG4gICAgaWYgKGxvb2tzTGlrZVR3ZWV0KG5vZGUpKSB7XHJcbiAgICAgIG91dC5wdXNoKHVud3JhcFR3ZWV0KG5vZGUpKTtcclxuICAgIH1cclxuICAgIGlmIChBcnJheS5pc0FycmF5KG5vZGUpKSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBub2RlKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMobm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBvdXQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGxvb2tzTGlrZVR3ZWV0KG5vZGU6IHVua25vd24pOiBub2RlIGlzIFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcclxuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICBjb25zdCB0eXBlbmFtZSA9IG4uX190eXBlbmFtZTtcclxuICBpZiAoXHJcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0JyB8fFxyXG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgfHxcclxuICAgIHR5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnXHJcbiAgKSB7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbiAgLy8gU29tZSBlbnRyaWVzIGxhY2sgX190eXBlbmFtZSBidXQgc3RpbGwgY2FycnkgbGVnYWN5ICsgcmVzdF9pZCArIGNvcmUuXHJcbiAgcmV0dXJuIHR5cGVvZiBuLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBuLmxlZ2FjeSA9PT0gJ29iamVjdCcgJiYgbi5sZWdhY3kgIT09IG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHVud3JhcFR3ZWV0KG5vZGU6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xyXG4gIGlmIChub2RlLl9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgJiYgdHlwZW9mIG5vZGUudHdlZXQgPT09ICdvYmplY3QnKSB7XHJcbiAgICByZXR1cm4gbm9kZS50d2VldCBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICB9XHJcbiAgcmV0dXJuIG5vZGU7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGJ1aWxkVHdlZXQocmF3OiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBDYW5vbmljYWxUd2VldCB8IG51bGwge1xyXG4gIGlmICh0eXBlb2YgcmF3ICE9PSAnb2JqZWN0JyB8fCByYXcgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IHQgPSByYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcblxyXG4gIGlmICh0Ll9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCByZXN0SWQgPSBzdHJPck51bGwodC5yZXN0X2lkKTtcclxuICAvLyBgbGVnYWN5YCBpcyBzdGlsbCB3aGVyZSBtb3N0IGVuZ2FnZW1lbnQgLyBlbnRpdGllcyBsaXZlIGluIDIwMjYtZXJhIFhcclxuICAvLyBwYXlsb2FkcywgYnV0IGFzIG9mIHJlY2VudCBzY2hlbWEgbWlncmF0aW9ucyBzZXZlcmFsIGZpZWxkcyBwcmV2aW91c2x5XHJcbiAgLy8gdGhlcmUgKG5vdGFibHkgdGhlIGF1dGhvciBoYW5kbGUpIGhhdmUgbW92ZWQgdG8gc2libGluZyBsb2NhdGlvbnMuIFdlXHJcbiAgLy8gdG9sZXJhdGUgYSBtaXNzaW5nIGxlZ2FjeSBoZXJlIGFuZCBsb29rIHVwIGV2ZXJ5dGhpbmcgdmlhIGZhbGxiYWNrcy5cclxuICBjb25zdCBsZWdhY3kgPSBvYmoodC5sZWdhY3kpID8/IHt9O1xyXG4gIGlmICghcmVzdElkKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3QgY29yZSA9IG9iaih0LmNvcmUpO1xyXG4gIGNvbnN0IHVzZXJSZXN1bHQgPSBvYmoob2JqKGNvcmU/LnVzZXJfcmVzdWx0cyk/LnJlc3VsdCk7XHJcbiAgLy8gQXV0aG9yIGhhbmRsZTogdHJ5IHRoZSBuZXcgYGNvcmVgIHN1YnN0cnVjdHVyZSBmaXJzdCAoY3VycmVudCBYIHNoYXBlKSxcclxuICAvLyB0aGVuIHRoZSBsZWdhY3kgYGxlZ2FjeS5zY3JlZW5fbmFtZWAsIHRoZW4gYSBjb3VwbGUgb2Ygb2xkZXIgdmFyaWFudHMuXHJcbiAgY29uc3QgdXNlckNvcmVOZXcgPSBvYmoodXNlclJlc3VsdD8uY29yZSk7XHJcbiAgY29uc3QgdXNlckxlZ2FjeSA9IG9iaih1c2VyUmVzdWx0Py5sZWdhY3kpO1xyXG4gIGNvbnN0IHVzZXJBdmF0YXJPYmogPSBvYmoodXNlclJlc3VsdD8uYXZhdGFyKTtcclxuICBjb25zdCBoYW5kbGUgPVxyXG4gICAgc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5zY3JlZW5fbmFtZSkgPz9cclxuICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5zY3JlZW5fbmFtZSkgPz9cclxuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5zY3JlZW5fbmFtZSkgPz9cclxuICAgIHN0ck9yTnVsbChsZWdhY3kuc2NyZWVuX25hbWUpO1xyXG4gIGNvbnN0IGFjY291bnRJZCA9XHJcbiAgICBzdHJPck51bGwodXNlclJlc3VsdD8ucmVzdF9pZCkgPz9cclxuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5pZF9zdHIpID8/XHJcbiAgICBzdHJPck51bGwobGVnYWN5LnVzZXJfaWRfc3RyKTtcclxuICBpZiAoIWhhbmRsZSB8fCAhYWNjb3VudElkKSByZXR1cm4gbnVsbDtcclxuICAvLyBBdXRob3Igc25hcHNob3QuIERpc3BsYXkgbmFtZSArIGF2YXRhciBtb3ZlZCBiZXR3ZWVuIGBsZWdhY3lgIGFuZCB0aGVcclxuICAvLyBuZXcgYGNvcmVgIHN1YnN0cnVjdHVyZSBvdmVyIHRpbWU7IHRoZSByZXN0ICh2ZXJpZmljYXRpb24sIGZvbGxvd2VyXHJcbiAgLy8gY291bnRzLCBhY2NvdW50X2NyZWF0ZWRfYXQpIGlzIHN0aWxsIGluIGBsZWdhY3lgLiBXZSBzbmFwc2hvdCB0aGVcclxuICAvLyB3aG9sZSBVc2VyU25hcHNob3QgcGVyIHR3ZWV0IGJlY2F1c2UgdGhlc2UgdmFsdWVzIGRyaWZ0IG92ZXIgdGltZVxyXG4gIC8vIGFuZCB0aGUgYXQtY2FwdHVyZSBzdGF0ZSBpcyB0aGUgb25seSByZWxpYWJsZSByZWNvcmQuXHJcbiAgY29uc3QgYXV0aG9yID0gZXh0cmFjdFVzZXJTbmFwc2hvdCh1c2VyUmVzdWx0LCB1c2VyQ29yZU5ldywgdXNlckxlZ2FjeSwgdXNlckF2YXRhck9iaik7XHJcblxyXG4gIGNvbnN0IG5vdGVUd2VldCA9IG9iaihvYmoob2JqKHQubm90ZV90d2VldCk/Lm5vdGVfdHdlZXRfcmVzdWx0cyk/LnJlc3VsdCk7XHJcbiAgY29uc3QgdGV4dEZyb21Ob3RlID0gc3RyT3JOdWxsKG5vdGVUd2VldD8udGV4dCk7XHJcbiAgY29uc3QgdGV4dEZyb21MZWdhY3kgPSBzdHJPck51bGwobGVnYWN5LmZ1bGxfdGV4dCkgPz8gJyc7XHJcbiAgY29uc3QgdGV4dCA9IHRleHRGcm9tTm90ZSA/PyB0ZXh0RnJvbUxlZ2FjeTtcclxuICBjb25zdCBpc1RydW5jYXRlZCA9IGRldGVjdFRydW5jYXRpb24obm90ZVR3ZWV0LCBsZWdhY3ksIHRleHRGcm9tTGVnYWN5KTtcclxuICBjb25zdCBjb21tdW5pdHlOb3RlID0gZXh0cmFjdENvbW11bml0eU5vdGUodCwgbGVnYWN5LCBjdHguY2FwdHVyZWRBdCk7XHJcblxyXG4gIGNvbnN0IGVudGl0aWVzID0gb2JqKGxlZ2FjeS5lbnRpdGllcykgPz8ge307XHJcbiAgY29uc3QgZW50aXRpZXNGcm9tTm90ZSA9IG9iaihub3RlVHdlZXQ/LmVudGl0eV9zZXQpO1xyXG4gIGNvbnN0IGhhc2h0YWdzID0gZXh0cmFjdEhhc2h0YWdzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xyXG4gIGNvbnN0IG1lbnRpb25zID0gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xyXG4gIGNvbnN0IHVybHMgPSBleHRyYWN0VXJscyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcclxuICBjb25zdCBtZWRpYSA9IGV4dHJhY3RNZWRpYShsZWdhY3kpO1xyXG5cclxuICBjb25zdCB0d2VldFR5cGUgPSBjbGFzc2lmeVR3ZWV0VHlwZSh0LCBsZWdhY3kpO1xyXG5cclxuICAvLyBwb3N0ZWRfYXQ6IGxlZ2FjeS5jcmVhdGVkX2F0IHJlbWFpbnMgdGhlIGNhbm9uaWNhbCBsb2NhdGlvbjsgaWYgdGhhdCdzXHJcbiAgLy8gbWlzc2luZyBpbiBhIGZ1dHVyZSBzY2hlbWEgd2UgZmFsbCBiYWNrIHRvIHRvcC1sZXZlbCBjcmVhdGVkX2F0LlxyXG4gIGNvbnN0IHBvc3RlZEF0ID1cclxuICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKGxlZ2FjeS5jcmVhdGVkX2F0KSkgPz8gcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodC5jcmVhdGVkX2F0KSk7XHJcbiAgaWYgKCFwb3N0ZWRBdCkgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IHZpZXdzID0gb2JqKHQudmlld3MpO1xyXG4gIGNvbnN0IHZpZXdDb3VudCA9IG51bU9yTnVsbCh2aWV3cz8uY291bnQpID8/IG51bU9yTnVsbChzdHJPck51bGwodmlld3M/LmNvdW50KSk7XHJcblxyXG4gIGNvbnN0IGNhcmQgPSBleHRyYWN0Q2FyZCh0KTtcclxuICBjb25zdCBwbGFjZSA9IG9iaihsZWdhY3kucGxhY2UpO1xyXG5cclxuICBjb25zdCB0d2VldDogQ2Fub25pY2FsVHdlZXQgPSB7XHJcbiAgICB0d2VldF9pZDogcmVzdElkLFxyXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcclxuICAgIGFjY291bnRfaWQ6IGFjY291bnRJZCxcclxuICAgIHBvc3RlZF9hdDogcG9zdGVkQXQsXHJcbiAgICBmaXJzdF9jYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXHJcbiAgICBsYXN0X3NlZW5fYXQ6IGN0eC5jYXB0dXJlZEF0LFxyXG4gICAgZGVsZXRpb25fZGV0ZWN0ZWRfYXQ6IG51bGwsXHJcbiAgICB1bmF2YWlsYWJsZV9kZXRlY3RlZF9hdDogbnVsbCxcclxuICAgIHVuYXZhaWxhYmxlX3JlYXNvbjogbnVsbCxcclxuICAgIHVuYXZhaWxhYmxlX3RleHQ6IG51bGwsXHJcbiAgICB1bmF2YWlsYWJsZV9zb3VyY2VfdXJsOiBudWxsLFxyXG4gICAgdHdlZXRfdXJsOiBgJHtUV0VFVF9VUkxfUFJFRklYfS8ke2hhbmRsZX0vc3RhdHVzLyR7cmVzdElkfWAsXHJcbiAgICB0d2VldF90eXBlOiB0d2VldFR5cGUsXHJcbiAgICBjb252ZXJzYXRpb25faWQ6IHN0ck9yTnVsbChsZWdhY3kuY29udmVyc2F0aW9uX2lkX3N0ciksXHJcbiAgICByZXBseV90b190d2VldF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zdGF0dXNfaWRfc3RyKSxcclxuICAgIHJlcGx5X3RvX2FjY291bnQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc2NyZWVuX25hbWUpLFxyXG4gICAgcmVwbHlfdG9fYWNjb3VudF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b191c2VyX2lkX3N0ciksXHJcbiAgICBxdW90ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChsZWdhY3kucXVvdGVkX3N0YXR1c19pZF9zdHIpLFxyXG4gICAgcmV0d2VldGVkX3R3ZWV0X2lkOiBzdHJPck51bGwoXHJcbiAgICAgIG9iaihvYmoobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCA/P1xyXG4gICAgICAgIChsZWdhY3kgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLnJldHdlZXRlZF9zdGF0dXNfaWRfc3RyXHJcbiAgICApLFxyXG4gICAgdGV4dCxcclxuICAgIHRleHRfcmVzb2x2ZWQ6IHJlc29sdmVTaG9ydFVybHModGV4dCwgdXJscyksXHJcbiAgICBsYW5nOiBzdHJPck51bGwobGVnYWN5LmxhbmcpLFxyXG4gICAgcG9zc2libHlfc2Vuc2l0aXZlOiBib29sT3JOdWxsKGxlZ2FjeS5wb3NzaWJseV9zZW5zaXRpdmUpLFxyXG4gICAgc291cmNlOiBzdHJPck51bGwobGVnYWN5LnNvdXJjZSkgPz8gc3RyT3JOdWxsKHQuc291cmNlKSxcclxuICAgIHBsYWNlX2Z1bGxfbmFtZTogc3RyT3JOdWxsKHBsYWNlPy5mdWxsX25hbWUpLFxyXG4gICAgaGFzaHRhZ3MsXHJcbiAgICBtZW50aW9ucyxcclxuICAgIHVybHMsXHJcbiAgICBjYXJkLFxyXG4gICAgbWVkaWEsXHJcbiAgICBsaWtlX2NvdW50OiBudW1Pclplcm8obGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcclxuICAgIHJldHdlZXRfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXHJcbiAgICByZXBseV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXBseV9jb3VudCksXHJcbiAgICBxdW90ZV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5xdW90ZV9jb3VudCksXHJcbiAgICB2aWV3X2NvdW50OiB2aWV3Q291bnQsXHJcbiAgICBib29rbWFya19jb3VudDogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXHJcbiAgICBlbmdhZ2VtZW50X2hpc3Rvcnk6IFtcclxuICAgICAge1xyXG4gICAgICAgIGNhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcclxuICAgICAgICBsaWtlczogbnVtT3JaZXJvKGxlZ2FjeS5mYXZvcml0ZV9jb3VudCksXHJcbiAgICAgICAgcmV0d2VldHM6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXHJcbiAgICAgICAgcmVwbGllczogbnVtT3JaZXJvKGxlZ2FjeS5yZXBseV9jb3VudCksXHJcbiAgICAgICAgcXVvdGVzOiBudW1Pclplcm8obGVnYWN5LnF1b3RlX2NvdW50KSxcclxuICAgICAgICB2aWV3czogdmlld0NvdW50LFxyXG4gICAgICAgIGJvb2ttYXJrczogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXHJcbiAgICAgIH0sXHJcbiAgICBdLFxyXG4gICAgYXV0aG9yLFxyXG4gICAgY29tbXVuaXR5X25vdGU6IGNvbW11bml0eU5vdGUsXHJcbiAgICBpc190cnVuY2F0ZWQ6IGlzVHJ1bmNhdGVkLFxyXG4gICAgd2F5YmFja191cmw6IG51bGwsXHJcbiAgICB3YXliYWNrX3N1Ym1pdHRlZF9hdDogbnVsbCxcclxuICAgIGNhcHR1cmVfc291cmNlOiAnZXh0ZW5zaW9uJyxcclxuICAgIGNhcHR1cmVfcnVuX2lkOiBjdHgucnVuSWQsXHJcbiAgICBzY2hlbWFfdmVyc2lvbjogMSxcclxuICB9O1xyXG5cclxuICByZXR1cm4gdHdlZXQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNsYXNzaWZ5VHdlZXRUeXBlKHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVHdlZXRUeXBlIHtcclxuICBpZiAobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0IHx8IGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXR3ZWV0JztcclxuICBpZiAobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpIHJldHVybiAncmVwbHknO1xyXG4gIGlmIChsZWdhY3kuaXNfcXVvdGVfc3RhdHVzID09PSB0cnVlIHx8IGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdxdW90ZSc7XHJcbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJykge1xyXG4gICAgLy8gcGFzcyB0aHJvdWdoXHJcbiAgfVxyXG4gIHJldHVybiAnb3JpZ2luYWwnO1xyXG59XHJcblxyXG5mdW5jdGlvbiBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xyXG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLmhhc2h0YWdzO1xyXG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XHJcbiAgcmV0dXJuIGFyclxyXG4gICAgLm1hcCgoaCkgPT5cclxuICAgICAgdHlwZW9mIGggPT09ICdvYmplY3QnICYmIGggJiYgJ3RleHQnIGluIGggPyBTdHJpbmcoKGggYXMgeyB0ZXh0OiB1bmtub3duIH0pLnRleHQpIDogbnVsbFxyXG4gICAgKVxyXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBleHRyYWN0TWVudGlvbnMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xyXG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLnVzZXJfbWVudGlvbnM7XHJcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcclxuICByZXR1cm4gYXJyXHJcbiAgICAubWFwKCh1KSA9PlxyXG4gICAgICB0eXBlb2YgdSA9PT0gJ29iamVjdCcgJiYgdSAmJiAnc2NyZWVuX25hbWUnIGluIHVcclxuICAgICAgICA/IFN0cmluZygodSBhcyB7IHNjcmVlbl9uYW1lOiB1bmtub3duIH0pLnNjcmVlbl9uYW1lKVxyXG4gICAgICAgIDogbnVsbFxyXG4gICAgKVxyXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBleHRyYWN0VXJscyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBVcmxFbnRpdHlbXSB7XHJcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXJscztcclxuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xyXG4gIGNvbnN0IG91dDogVXJsRW50aXR5W10gPSBbXTtcclxuICBmb3IgKGNvbnN0IHUgb2YgYXJyKSB7XHJcbiAgICBpZiAodHlwZW9mIHUgIT09ICdvYmplY3QnIHx8IHUgPT09IG51bGwpIGNvbnRpbnVlO1xyXG4gICAgY29uc3QgbyA9IHUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcbiAgICBjb25zdCBzaG9ydCA9IHN0ck9yTnVsbChvLnVybCk7XHJcbiAgICBjb25zdCBleHBhbmRlZCA9IHN0ck9yTnVsbChvLmV4cGFuZGVkX3VybCk7XHJcbiAgICBjb25zdCBkaXNwbGF5ID0gc3RyT3JOdWxsKG8uZGlzcGxheV91cmwpO1xyXG4gICAgaWYgKCFzaG9ydCB8fCAhZXhwYW5kZWQpIGNvbnRpbnVlO1xyXG4gICAgb3V0LnB1c2goeyBzaG9ydCwgZXhwYW5kZWQsIGRpc3BsYXk6IGRpc3BsYXkgPz8gZXhwYW5kZWQgfSk7XHJcbiAgfVxyXG4gIHJldHVybiBvdXQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGV4dHJhY3RNZWRpYShsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogTWVkaWFJdGVtW10ge1xyXG4gIGNvbnN0IGV4dGVuZGVkID0gb2JqKGxlZ2FjeS5leHRlbmRlZF9lbnRpdGllcyk7XHJcbiAgY29uc3QgZnJvbUV4dCA9IGV4dGVuZGVkID8gdG9BcnJheShleHRlbmRlZC5tZWRpYSkgOiBbXTtcclxuICBjb25zdCBmcm9tRW50ID0gdG9BcnJheShvYmoobGVnYWN5LmVudGl0aWVzKT8ubWVkaWEpO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBjb25zdCBtZXJnZWQgPSBbLi4uZnJvbUV4dCwgLi4uZnJvbUVudF0uZmlsdGVyKChtKSA9PiB7XHJcbiAgICBpZiAodHlwZW9mIG0gIT09ICdvYmplY3QnIHx8IG0gPT09IG51bGwpIHJldHVybiBmYWxzZTtcclxuICAgIGNvbnN0IGlkID1cclxuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5tZWRpYV9rZXkpID8/XHJcbiAgICAgIHN0ck9yTnVsbCgobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuaWRfc3RyKTtcclxuICAgIGlmICghaWQpIHJldHVybiBmYWxzZTtcclxuICAgIGlmIChzZWVuLmhhcyhpZCkpIHJldHVybiBmYWxzZTtcclxuICAgIHNlZW4uYWRkKGlkKTtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH0pO1xyXG4gIHJldHVybiBtZXJnZWQubWFwKChyYXcpID0+IGJ1aWxkTWVkaWEocmF3IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGJ1aWxkTWVkaWEobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW0ge1xyXG4gIGNvbnN0IHR5cGUgPSBzdHJPck51bGwobS50eXBlKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXTtcclxuICBjb25zdCBvcmlnaW5hbCA9IHBpY2tPcmlnaW5hbFVybChtLCB0eXBlKTtcclxuICBjb25zdCBpbmZvID0gb2JqKG0ub3JpZ2luYWxfaW5mbyk7XHJcbiAgY29uc3QgdmlkZW9JbmZvID0gb2JqKG0udmlkZW9faW5mbyk7XHJcbiAgY29uc3QgZHVyYXRpb25NcyA9IG51bU9yTnVsbCh2aWRlb0luZm8/LmR1cmF0aW9uX21pbGxpcyk7XHJcbiAgY29uc3QgYWx0VGV4dCA9IHN0ck9yTnVsbChtLmV4dF9hbHRfdGV4dCk7XHJcbiAgY29uc3QgbWVkaWFJZCA9XHJcbiAgICBzdHJPck51bGwobS5tZWRpYV9rZXkpID8/XHJcbiAgICBzdHJPck51bGwobS5pZF9zdHIpID8/XHJcbiAgICBgJHt0eXBlID8/ICdtZWRpYSd9LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMil9YDtcclxuICByZXR1cm4ge1xyXG4gICAgbWVkaWFfaWQ6IG1lZGlhSWQsXHJcbiAgICBtZWRpYV90eXBlOiAodHlwZSA/PyAncGhvdG8nKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXSxcclxuICAgIG9yaWdpbmFsX3VybDogb3JpZ2luYWwgPz8gJycsXHJcbiAgICByZWxlYXNlX2Fzc2V0X3VybDogbnVsbCxcclxuICAgIHNoYTI1NjogbnVsbCxcclxuICAgIGJ5dGVzOiBudWxsLFxyXG4gICAgZHVyYXRpb25fc2VjOiBkdXJhdGlvbk1zICE9PSBudWxsID8gZHVyYXRpb25NcyAvIDEwMDAgOiBudWxsLFxyXG4gICAgd2lkdGg6IG51bU9yTnVsbChpbmZvPy53aWR0aCksXHJcbiAgICBoZWlnaHQ6IG51bU9yTnVsbChpbmZvPy5oZWlnaHQpLFxyXG4gICAgYWx0X3RleHQ6IGFsdFRleHQsXHJcbiAgICBhcmNoaXZlX3N0YXR1czogJ3BlbmRpbmcnLFxyXG4gICAgYXJjaGl2ZV9hdHRlbXB0czogMCxcclxuICAgIGxhc3RfYXR0ZW1wdF9hdDogbnVsbCxcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBwaWNrT3JpZ2luYWxVcmwobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHR5cGU6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAodHlwZSA9PT0gJ3Bob3RvJykgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcykgPz8gc3RyT3JOdWxsKG0ubWVkaWFfdXJsKTtcclxuICBjb25zdCB2YXJpYW50cyA9IHRvQXJyYXkob2JqKG0udmlkZW9faW5mbyk/LnZhcmlhbnRzKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPltdO1xyXG4gIGlmICh2YXJpYW50cy5sZW5ndGggPT09IDApIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpO1xyXG4gIC8vIEhpZ2hlc3QtYml0cmF0ZSBtcDQuXHJcbiAgbGV0IGJlc3Q6IHsgdXJsOiBzdHJpbmc7IGJpdHJhdGU6IG51bWJlciB9IHwgbnVsbCA9IG51bGw7XHJcbiAgZm9yIChjb25zdCB2IG9mIHZhcmlhbnRzKSB7XHJcbiAgICBjb25zdCBjdCA9IHN0ck9yTnVsbCh2LmNvbnRlbnRfdHlwZSk7XHJcbiAgICBjb25zdCB1cmwgPSBzdHJPck51bGwodi51cmwpO1xyXG4gICAgaWYgKCF1cmwpIGNvbnRpbnVlO1xyXG4gICAgaWYgKGN0ID09PSAndmlkZW8vbXA0Jykge1xyXG4gICAgICBjb25zdCBiciA9IG51bU9yTnVsbCh2LmJpdHJhdGUpID8/IDA7XHJcbiAgICAgIGlmICghYmVzdCB8fCBiciA+IGJlc3QuYml0cmF0ZSkgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiBiciB9O1xyXG4gICAgfSBlbHNlIGlmICghYmVzdCkge1xyXG4gICAgICAvLyBGYWxsYmFjayB0byBhbnkgdmFyaWFudCBpZiBubyBtcDQgZm91bmQuXHJcbiAgICAgIGJlc3QgPSB7IHVybCwgYml0cmF0ZTogMCB9O1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gYmVzdD8udXJsID8/IG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlc29sdmVTaG9ydFVybHModGV4dDogc3RyaW5nLCB1cmxzOiBVcmxFbnRpdHlbXSk6IHN0cmluZyB7XHJcbiAgaWYgKHVybHMubGVuZ3RoID09PSAwKSByZXR1cm4gdGV4dDtcclxuICBsZXQgb3V0ID0gdGV4dDtcclxuICBmb3IgKGNvbnN0IHUgb2YgdXJscykgb3V0ID0gb3V0LnNwbGl0KHUuc2hvcnQpLmpvaW4odS5leHBhbmRlZCk7XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuZnVuY3Rpb24gcGFyc2VUd2l0dGVyRGF0ZShzOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgaWYgKCFzKSByZXR1cm4gbnVsbDtcclxuICAvLyBUd2l0dGVyIHNoaXBzIGRhdGVzIGxpa2UgXCJNb24gQXByIDEyIDE0OjIzOjAxICswMDAwIDIwMjVcIi5cclxuICBjb25zdCBkID0gbmV3IERhdGUocyk7XHJcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBudWxsO1xyXG4gIHJldHVybiBkLnRvSVNPU3RyaW5nKCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHN0ck9yTnVsbCh2OiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDAgPyB2IDogbnVsbDtcclxufVxyXG5mdW5jdGlvbiBib29sT3JOdWxsKHY6IHVua25vd24pOiBib29sZWFuIHwgbnVsbCB7XHJcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnYm9vbGVhbicgPyB2IDogbnVsbDtcclxufVxyXG5mdW5jdGlvbiBudW1Pck51bGwodjogdW5rbm93bik6IG51bWJlciB8IG51bGwge1xyXG4gIGlmICh0eXBlb2YgdiA9PT0gJ251bWJlcicgJiYgTnVtYmVyLmlzRmluaXRlKHYpKSByZXR1cm4gdjtcclxuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgbiA9IE51bWJlcih2KTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikpIHJldHVybiBuO1xyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5mdW5jdGlvbiBudW1Pclplcm8odjogdW5rbm93bik6IG51bWJlciB7XHJcbiAgcmV0dXJuIG51bU9yTnVsbCh2KSA/PyAwO1xyXG59XHJcbmZ1bmN0aW9uIG9iaih2OiB1bmtub3duKTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsIHtcclxuICByZXR1cm4gdHlwZW9mIHYgPT09ICdvYmplY3QnICYmIHYgIT09IG51bGwgJiYgIUFycmF5LmlzQXJyYXkodilcclxuICAgID8gKHYgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pXHJcbiAgICA6IG51bGw7XHJcbn1cclxuZnVuY3Rpb24gdG9BcnJheSh2OiB1bmtub3duKTogdW5rbm93bltdIHtcclxuICByZXR1cm4gQXJyYXkuaXNBcnJheSh2KSA/IHYgOiBbXTtcclxufVxyXG5cclxuLyoqXHJcbiAqIERlY2lkZSB3aGV0aGVyIGEgdHdlZXQncyBhcmNoaXZlZCBgdGV4dGAgaXMgdGhlIHRydW5jYXRlZCBoZWFkIG9mIGEgbG9uZ2VyXHJcbiAqIGJvZHkuIEEgdHJ1bmNhdGVkIHR3ZWV0IGhhcyBYJ3MgXCJTaG93IG1vcmVcIiB0LmNvIFVSTCBhcHBlbmRlZCBcdTIwMTQgdGhhdCBVUkxcclxuICogc3BlY2lmaWNhbGx5IGV4cGFuZHMgdG8gdGhlIHR3ZWV0J3Mgb3duIC9pL3dlYi9zdGF0dXMvPGlkPiBwZXJtYWxpbmssIGFuZFxyXG4gKiBpcyB0aGUgb25seSByZWxpYWJsZSBkaXN0aW5ndWlzaGluZyBmZWF0dXJlLiBQbGVudHkgb2Ygbm9ybWFsIHR3ZWV0cyBoYXZlXHJcbiAqIHRyYWlsaW5nIHQuY28gVVJMcyAobWVkaWEsIHF1b3RlcywgcmVndWxhciBsaW5rcyksIGFuZCB0aGVpclxyXG4gKiBkaXNwbGF5X3RleHRfcmFuZ2UgYWxzbyB0cmltcyBwYXN0IGZ1bGxfdGV4dC5sZW5ndGgsIHNvIHRoZSBvbGRcclxuICogXCJkaXNwbGF5X3RleHRfcmFuZ2VbMV0gPCBmdWxsX3RleHQubGVuZ3RoXCIgaGV1cmlzdGljIHdhcyBvdmVyZmxhZ2dpbmdcclxuICogZXNzZW50aWFsbHkgZXZlcnkgdHdlZXQgd2l0aCBhIGxpbmsgaW4gaXQuXHJcbiAqXHJcbiAqIFJ1bGVzOlxyXG4gKiAgIC0gbm90ZV90d2VldCBwcmVzZW50ICBcdTIxOTIgbm90IHRydW5jYXRlZCAod2UgYWxyZWFkeSBoYXZlIHRoZSBmdWxsIGJvZHkpLlxyXG4gKiAgIC0gT25lIG9mIGxlZ2FjeS5lbnRpdGllcy51cmxzIGhhcyBhbiBleHBhbmRlZF91cmwgbGlrZVxyXG4gKiAgICAgXCIuLi4vaS93ZWIvc3RhdHVzLzxpZD5cIiAgXHUyMTkyICB0cnVuY2F0ZWQuXHJcbiAqICAgLSBPdGhlcndpc2UgXHUyMTkyIG5vdCB0cnVuY2F0ZWQuXHJcbiAqXHJcbiAqIFRoZSBwcmV2aW91cyBmYWxsYmFjayAoXCJ0cmFpbGluZyB0LmNvIFVSTCArIGxlbmd0aCBcdTIyNjUgMjcwXCIpIGZsYWdnZWQgZXZlcnlcclxuICogbWVkaWEgdHdlZXQgZXhhY3RseSBhdCB0aGUgMjgwLWNoYXIgbGltaXQuIFdlIGRyb3AgaXQgZW50aXJlbHk7IHRoZSBvbmx5XHJcbiAqIGNvc3QgaXMgbWlzc2luZyBnZW51aW5lbHktdHJ1bmNhdGVkIHR3ZWV0cyB3aG9zZSBwYXlsb2FkIHdhcyBzbyBkZWdyYWRlZFxyXG4gKiBpdCBsYWNrZWQgZW50aXRpZXMgXHUyMDE0IHdoaWNoIGlzIGFsc28gd2hlcmUgdGhlIHJlZmV0Y2ggbG9vcCB3b3VsZCBmYWlsXHJcbiAqIGFueXdheSwgc28gbm90aGluZyBpcyBhY3R1YWxseSBsb3N0LlxyXG4gKi9cclxuZnVuY3Rpb24gZGV0ZWN0VHJ1bmNhdGlvbihcclxuICBub3RlVHdlZXQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcclxuICBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxyXG4gIGZ1bGxUZXh0OiBzdHJpbmdcclxuKTogYm9vbGVhbiB7XHJcbiAgaWYgKG5vdGVUd2VldCkgcmV0dXJuIGZhbHNlO1xyXG4gIGlmICghZnVsbFRleHQpIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBlbnRpdGllcyA9IG9iaihsZWdhY3kuZW50aXRpZXMpO1xyXG4gIGNvbnN0IHVybHMgPSBlbnRpdGllcyA/IGVudGl0aWVzLnVybHMgOiBudWxsO1xyXG4gIGlmIChBcnJheS5pc0FycmF5KHVybHMpKSB7XHJcbiAgICBmb3IgKGNvbnN0IHUgb2YgdXJscykge1xyXG4gICAgICBpZiAodHlwZW9mIHUgIT09ICdvYmplY3QnIHx8IHUgPT09IG51bGwpIGNvbnRpbnVlO1xyXG4gICAgICBjb25zdCBleHAgPSAodSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuZXhwYW5kZWRfdXJsO1xyXG4gICAgICAvLyBUaGUgXCJTaG93IG1vcmVcIiBsaW5rIGV4cGFuZHMgdG8gZWl0aGVyIG9mIHRoZXNlIHNlbGYtcGVybWFsaW5rXHJcbiAgICAgIC8vIHNoYXBlczogIGh0dHBzOi8veC5jb20vaS93ZWIvc3RhdHVzLzxpZD5cclxuICAgICAgLy8gICAgICAgICAgaHR0cHM6Ly90d2l0dGVyLmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxyXG4gICAgICBpZiAodHlwZW9mIGV4cCA9PT0gJ3N0cmluZycgJiYgL1xcL2lcXC93ZWJcXC9zdGF0dXNcXC9cXGQrLy50ZXN0KGV4cCkpIHtcclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGaWx0ZXIgYHR3ZWV0c2AgZG93biB0byB0aG9zZSByZWxhdGVkIHRvIGEgdHJhY2tlZCBhY2NvdW50LiBBIHR3ZWV0IGlzXHJcbiAqIFwicmVsYXRlZFwiIGlmIGFueSBvZiB0aGUgZm9sbG93aW5nIGhvbGQ6XHJcbiAqXHJcbiAqICAgLSBpdHMgYXV0aG9yIGlzIHRyYWNrZWQgKGhhbmRsZSBpbiBgdGFyZ2V0ZWRgKSxcclxuICogICAtIGl0cyBhdXRob3IgaXMgY29yZSAoaGFuZGxlIGluIGBjb3JlSGFuZGxlc2ApLCByZWdhcmRsZXNzIG9mIHdoZXJlIFhcclxuICogICAgIHN1cmZhY2VkIGl0LFxyXG4gKiAgIC0gaXQgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZSxcclxuICogICAtIGl0IHJlcGxpZXMgdG8gYSB0cmFja2VkIGFjY291bnQsXHJcbiAqICAgLSBpdCBxdW90ZXMvcmVwbGllcy10byBhIHR3ZWV0IHRoYXQncyBhbHNvIHByZXNlbnQgaW4gdGhlXHJcbiAqICAgICBiYXRjaCAqYW5kKiBhdXRob3JlZCBieSBhIHRyYWNrZWQgYWNjb3VudCAodHJhbnNpdGl2ZWx5IHJlbGF0ZWQgXHUyMDE0XHJcbiAqICAgICBjYXB0dXJlcyBxdW90ZWQvcmVwbHkgY29udGV4dCB0aGF0IGFwcGVhcnMgYXMgYSBzaWJsaW5nIG5vZGUgaW4gdGhlXHJcbiAqICAgICBzYW1lIEdyYXBoUUwgcmVzcG9uc2UpLlxyXG4gKlxyXG4gKiBOb24tY29yZSByZXR3ZWV0IHdyYXBwZXJzIGFyZSBub3Qga2VwdCBtZXJlbHkgYmVjYXVzZSB0aGV5IHJldHdlZXRlZCBhXHJcbiAqIHRyYWNrZWQvY29yZSB0d2VldC4gVGhlIHVuZGVybHlpbmcgY29yZSB0d2VldCBpcyBrZXB0IGFzIGl0cyBvd24gcm93IHdoZW5cclxuICogcHJlc2VudCBpbiB0aGUgcGF5bG9hZC5cclxuICpcclxuICogQW55dGhpbmcgZWxzZSAocmFuZG9tIHJlcGxpZXMgdW5kZXIgYSB0cmFja2VkIGFjY291bnQncyB0d2VldCwgcmFuZG9tXHJcbiAqIGF1dGhvcnMgdGhhdCBoYXBwZW4gdG8gc3VyZmFjZSBpbiBhIHRyYWNrZWQgYWNjb3VudCdzIHRocmVhZCkgaXMgZHJvcHBlZC5cclxuICogUGFzcyBhbiBlbXB0eSBgdGFyZ2V0ZWRgIHNldCB0byBkaXNhYmxlIGZpbHRlcmluZyBlbnRpcmVseS5cclxuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBmaWx0ZXJSZWxhdGVkKFxyXG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSxcclxuICB0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPixcclxuICBjb3JlSGFuZGxlczogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxyXG4pOiBDYW5vbmljYWxUd2VldFtdIHtcclxuICBpZiAodGFyZ2V0ZWQuc2l6ZSA9PT0gMCAmJiBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm4gdHdlZXRzO1xyXG4gIC8vIEZpcnN0IHBhc3M6IHdoaWNoIHR3ZWV0IElEcyBkbyB0cmFja2VkLWF1dGhvciB0d2VldHMgcmVmZXJlbmNlICh0aGVcclxuICAvLyBcImZvcndhcmRcIiBkaXJlY3Rpb24gXHUyMDE0IHRyYWNrZWQgYWNjb3VudCBxdW90ZXMgLyBSVHMgLyByZXBsaWVzIHRvIFgpP1xyXG4gIC8vIEFuZCB3aGljaCB0d2VldCBJRHMgQVJFIHRyYWNrZWQtYXV0aG9yZWQgKHRoZSBcInJldmVyc2VcIiBkaXJlY3Rpb24gXHUyMDE0XHJcbiAgLy8gWCBxdW90ZXMgLyBSVHMgLyByZXBsaWVzIHRvIGEgdHJhY2tlZCB0d2VldCk/XHJcbiAgY29uc3QgcmVmZXJlbmNlZElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGNvbnN0IHRhcmdldGVkVHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XHJcbiAgICBpZiAoIXRhcmdldGVkLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSBjb250aW51ZTtcclxuICAgIHRhcmdldGVkVHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xyXG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnF1b3RlZF90d2VldF9pZCk7XHJcbiAgICBpZiAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucmV0d2VldGVkX3R3ZWV0X2lkKTtcclxuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnJlcGx5X3RvX3R3ZWV0X2lkKTtcclxuICB9XHJcbiAgcmV0dXJuIHR3ZWV0cy5maWx0ZXIoKHQpID0+IHtcclxuICAgIGNvbnN0IGggPSB0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCk7XHJcbiAgICBpZiAodGFyZ2V0ZWQuaGFzKGgpKSByZXR1cm4gdHJ1ZTtcclxuICAgIGlmIChjb3JlSGFuZGxlcy5oYXMoaCkpIHJldHVybiB0cnVlO1xyXG4gICAgLy8gRm9yd2FyZDogYSB0cmFja2VkLWF1dGhvciB0d2VldCBwb2ludGVkIGF0IHRoaXMgb25lLlxyXG4gICAgaWYgKHJlZmVyZW5jZWRJZHMuaGFzKHQudHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcclxuICAgIC8vIFJldmVyc2U6IHRoaXMgdHdlZXQgcXVvdGVzL3JlcGxpZXMgdG8gYSB0cmFja2VkLWF1dGhvciB0d2VldCBpbiB0aGVcclxuICAgIC8vIGJhdGNoLiBSZXZlcnNlIHJldHdlZXRzIGFyZSBqdXN0IFwibm9uLWNvcmUgYWNjb3VudCByZXR3ZWV0ZWQgY29yZVxyXG4gICAgLy8gdHdlZXRcIiB3cmFwcGVycywgYW5kIGRvIG5vdCBhZGQgY29yZSBhcmNoaXZlIHZhbHVlLlxyXG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucXVvdGVkX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XHJcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCAmJiB0YXJnZXRlZFR3ZWV0SWRzLmhhcyh0LnJlcGx5X3RvX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XHJcbiAgICAvLyBSZXBseS10by1hY2NvdW50IG9yIG1lbnRpb25zIGEgdHJhY2tlZCBoYW5kbGUuXHJcbiAgICBpZiAodC5yZXBseV90b19hY2NvdW50ICYmIHRhcmdldGVkLmhhcyh0LnJlcGx5X3RvX2FjY291bnQudG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xyXG4gICAgZm9yIChjb25zdCBtIG9mIHQubWVudGlvbnMpIHtcclxuICAgICAgaWYgKHRhcmdldGVkLmhhcyhtLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFB1bGwgdGhlIENvbW11bml0eSBOb3RlIChmb3JtZXJseSBCaXJkd2F0Y2gpIGJsb2NrIGF0dGFjaGVkIHRvIGEgdHdlZXQsIGlmXHJcbiAqIGFueS4gVGhlIHBpdm90IGNhbiBsaXZlIGF0IGB0d2VldC5sZWdhY3kuYmlyZHdhdGNoX3Bpdm90YCAob2xkZXIgc2hhcGUpIG9yXHJcbiAqIGB0d2VldC5iaXJkd2F0Y2hfcGl2b3RgIChjdXJyZW50IHNoYXBlKS4gVGhlIHN1bW1hcnkgdGV4dCBpcyB3aGF0IHJlYWRlcnNcclxuICogYWN0dWFsbHkgc2VlOyB3ZSBrZWVwIHRoZSBzdXJyb3VuZGluZyBtZXRhZGF0YSBzbyBkb3duc3RyZWFtIHRvb2xpbmcgY2FuXHJcbiAqIHRlbGwgZHJhZnRzIGFwYXJ0IGZyb20gcmF0ZWQtaGVscGZ1bCBub3Rlcy5cclxuICovXHJcbmZ1bmN0aW9uIGV4dHJhY3RDb21tdW5pdHlOb3RlKFxyXG4gIHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxyXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXHJcbiAgb2JzZXJ2ZWRBdDogc3RyaW5nXHJcbik6IENvbW11bml0eU5vdGUgfCBudWxsIHtcclxuICBjb25zdCBwaXZvdCA9IG9iaih0LmJpcmR3YXRjaF9waXZvdCkgPz8gb2JqKGxlZ2FjeS5iaXJkd2F0Y2hfcGl2b3QpO1xyXG4gIGlmICghcGl2b3QpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IHN1YnRpdGxlID0gb2JqKHBpdm90LnN1YnRpdGxlKTtcclxuICBjb25zdCBub3RlID0gb2JqKHBpdm90Lm5vdGUpO1xyXG4gIGNvbnN0IHN1bW1hcnkgPSBzdHJPck51bGwoc3VidGl0bGU/LnRleHQpO1xyXG4gIGNvbnN0IHRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnRpdGxlKTtcclxuICBjb25zdCBzaG9ydFRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnNob3J0VGl0bGUpO1xyXG4gIGNvbnN0IGRlc3RpbmF0aW9uVXJsID0gc3RyT3JOdWxsKHBpdm90LmRlc3RpbmF0aW9uVXJsKTtcclxuICBjb25zdCBub3RlSWQgPSBzdHJPck51bGwocGl2b3Qubm90ZUlkKSA/PyBzdHJPck51bGwobm90ZT8ucmVzdF9pZCk7XHJcbiAgLy8gU2tpcCBlbXB0eSBzaGVsbHMgdGhhdCBoYXZlIG5vIGFjdHVhbCBjb250ZW50LlxyXG4gIGlmICghc3VtbWFyeSAmJiAhdGl0bGUgJiYgIW5vdGVJZCkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIHtcclxuICAgIG5vdGVfaWQ6IG5vdGVJZCxcclxuICAgIHRpdGxlLFxyXG4gICAgc2hvcnRfdGl0bGU6IHNob3J0VGl0bGUsXHJcbiAgICBzdW1tYXJ5LFxyXG4gICAgZGVzdGluYXRpb25fdXJsOiBkZXN0aW5hdGlvblVybCxcclxuICAgIG9ic2VydmVkX2F0OiBvYnNlcnZlZEF0LFxyXG4gIH07XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBQdWxsIGEgcGVyLWF1dGhvciBVc2VyU25hcHNob3QgZnJvbSB0aGUgdHdlZXQncyB1c2VyX3Jlc3VsdHMgbm9kZS4gRXZlcnlcclxuICogZmllbGQgZGVmYXVsdHMgdG8gbnVsbCB3aGVuIG1pc3Npbmcgc28gdGhlIHNjaGVtYSBzdGF5cyBzdGFibGUgYWNyb3NzXHJcbiAqIHRoZSBsZWdhY3kgLyBjb3JlIHNoYXBlIG1pZ3JhdGlvbnMgWCBoYXMgYmVlbiBkb2luZy5cclxuICovXHJcbmZ1bmN0aW9uIGV4dHJhY3RVc2VyU25hcHNob3QoXHJcbiAgdXNlclJlc3VsdDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxyXG4gIHVzZXJDb3JlTmV3OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXHJcbiAgdXNlckxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxyXG4gIHVzZXJBdmF0YXJPYmo6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbFxyXG4pOiBVc2VyU25hcHNob3Qge1xyXG4gIGNvbnN0IHZlcmlmaWNhdGlvbiA9IG9iaih1c2VyUmVzdWx0Py52ZXJpZmljYXRpb24pO1xyXG4gIHJldHVybiB7XHJcbiAgICBkaXNwbGF5X25hbWU6XHJcbiAgICAgIHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8ubmFtZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/Lm5hbWUpID8/IHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5uYW1lKSxcclxuICAgIGF2YXRhcl91cmw6XHJcbiAgICAgIHN0ck9yTnVsbCh1c2VyQXZhdGFyT2JqPy5pbWFnZV91cmwpID8/XHJcbiAgICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5wcm9maWxlX2ltYWdlX3VybF9odHRwcykgPz9cclxuICAgICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzKSxcclxuICAgIHZlcmlmaWVkOiBib29sT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWQpID8/IGJvb2xPck51bGwodXNlckxlZ2FjeT8udmVyaWZpZWQpLFxyXG4gICAgaXNfYmx1ZV92ZXJpZmllZDogYm9vbE9yTnVsbCh1c2VyUmVzdWx0Py5pc19ibHVlX3ZlcmlmaWVkKSxcclxuICAgIHZlcmlmaWVkX3R5cGU6IHN0ck9yTnVsbCh2ZXJpZmljYXRpb24/LnZlcmlmaWVkX3R5cGUpID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py52ZXJpZmllZF90eXBlKSxcclxuICAgIGRlc2NyaXB0aW9uOiBzdHJPck51bGwodXNlckxlZ2FjeT8uZGVzY3JpcHRpb24pLFxyXG4gICAgbG9jYXRpb246IHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubG9jYXRpb24pPy5sb2NhdGlvbikgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmxvY2F0aW9uKSxcclxuICAgIHVybDogc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnVybCksXHJcbiAgICBmb2xsb3dlcnNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5mb2xsb3dlcnNfY291bnQpLFxyXG4gICAgZnJpZW5kc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZyaWVuZHNfY291bnQpLFxyXG4gICAgc3RhdHVzZXNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5zdGF0dXNlc19jb3VudCksXHJcbiAgICBhY2NvdW50X2NyZWF0ZWRfYXQ6XHJcbiAgICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5jcmVhdGVkX2F0KSkgPz9cclxuICAgICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodXNlckxlZ2FjeT8uY3JlYXRlZF9hdCkpLFxyXG4gICAgcHJvdGVjdGVkOiBib29sT3JOdWxsKHVzZXJMZWdhY3k/LnByb3RlY3RlZCksXHJcbiAgfTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFdhbGsgdGhlIHR3ZWV0J3MgYGNhcmQubGVnYWN5LmJpbmRpbmdfdmFsdWVzYCAoa2V5L3ZhbHVlIGFycmF5KSBpbnRvIGFcclxuICogZmxhdCBUd2VldENhcmQgd2l0aCB0aXRsZSwgZGVzY3JpcHRpb24sIGFuZCBhIHJlcHJlc2VudGF0aXZlIGltYWdlIFVSTC5cclxuICogUmV0dXJucyBudWxsIHdoZW4gdGhlIHR3ZWV0IGhhcyBubyBjYXJkLlxyXG4gKi9cclxuZnVuY3Rpb24gZXh0cmFjdENhcmQodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldENhcmQgfCBudWxsIHtcclxuICBjb25zdCBjYXJkID0gb2JqKHQuY2FyZCk7XHJcbiAgY29uc3QgY2FyZExlZ2FjeSA9IG9iaihjYXJkPy5sZWdhY3kpO1xyXG4gIGlmICghY2FyZExlZ2FjeSkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgYmluZGluZ3MgPSBjYXJkTGVnYWN5LmJpbmRpbmdfdmFsdWVzO1xyXG4gIGNvbnN0IGJ5S2V5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xyXG4gIGlmIChBcnJheS5pc0FycmF5KGJpbmRpbmdzKSkge1xyXG4gICAgZm9yIChjb25zdCBidiBvZiBiaW5kaW5ncykge1xyXG4gICAgICBpZiAodHlwZW9mIGJ2ICE9PSAnb2JqZWN0JyB8fCBidiA9PT0gbnVsbCkgY29udGludWU7XHJcbiAgICAgIGNvbnN0IG8gPSBidiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgICAgY29uc3QgayA9IHN0ck9yTnVsbChvLmtleSk7XHJcbiAgICAgIGNvbnN0IHYgPSBvYmooby52YWx1ZSk7XHJcbiAgICAgIGlmICghayB8fCAhdikgY29udGludWU7XHJcbiAgICAgIGJ5S2V5W2tdID1cclxuICAgICAgICBzdHJPck51bGwodi5zdHJpbmdfdmFsdWUpID8/XHJcbiAgICAgICAgc3RyT3JOdWxsKG9iaih2LmltYWdlX3ZhbHVlKT8udXJsKSA/P1xyXG4gICAgICAgIHN0ck9yTnVsbChvYmoodi5pbWFnZV9jb2xvcl92YWx1ZSk/LnBhbGV0dGUpO1xyXG4gICAgfVxyXG4gIH1cclxuICBjb25zdCBuYW1lID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kubmFtZSk7XHJcbiAgY29uc3QgY2FyZFVybCA9IHN0ck9yTnVsbChjYXJkTGVnYWN5LnVybCk7XHJcbiAgY29uc3QgdmVuZG9yVXJsID1cclxuICAgIHR5cGVvZiBieUtleVsndmFuaXR5X3VybCddID09PSAnc3RyaW5nJyA/IChieUtleVsndmFuaXR5X3VybCddIGFzIHN0cmluZykgOiBudWxsO1xyXG4gIGNvbnN0IHRpdGxlID0gdHlwZW9mIGJ5S2V5Wyd0aXRsZSddID09PSAnc3RyaW5nJyA/IChieUtleVsndGl0bGUnXSBhcyBzdHJpbmcpIDogbnVsbDtcclxuICBjb25zdCBkZXNjcmlwdGlvbiA9XHJcbiAgICB0eXBlb2YgYnlLZXlbJ2Rlc2NyaXB0aW9uJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5WydkZXNjcmlwdGlvbiddIGFzIHN0cmluZykgOiBudWxsO1xyXG4gIGNvbnN0IGltYWdlVXJsID1cclxuICAgICh0eXBlb2YgYnlLZXlbJ3Bob3RvX2ltYWdlX2Z1bGxfc2l6ZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xyXG4gICAgICA/IChieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxyXG4gICAgICA6IG51bGwpID8/XHJcbiAgICAodHlwZW9mIGJ5S2V5Wyd0aHVtYm5haWxfaW1hZ2Vfb3JpZ2luYWwnXSA9PT0gJ3N0cmluZydcclxuICAgICAgPyAoYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcclxuICAgICAgOiBudWxsKSA/P1xyXG4gICAgKHR5cGVvZiBieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xyXG4gICAgICA/IChieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcclxuICAgICAgOiBudWxsKTtcclxuICBpZiAoIW5hbWUgJiYgIXRpdGxlICYmICFkZXNjcmlwdGlvbiAmJiAhaW1hZ2VVcmwpIHJldHVybiBudWxsO1xyXG4gIHJldHVybiB7XHJcbiAgICBuYW1lLFxyXG4gICAgY2FyZF91cmw6IGNhcmRVcmwsXHJcbiAgICB2ZW5kb3JfdXJsOiB2ZW5kb3JVcmwsXHJcbiAgICB0aXRsZSxcclxuICAgIGRlc2NyaXB0aW9uLFxyXG4gICAgaW1hZ2VfdXJsOiBpbWFnZVVybCxcclxuICB9O1xyXG59XHJcbiIsICIvKipcclxuICogTGlnaHR3ZWlnaHQgVUxJRC1saWtlIGlkIGdlbmVyYXRvcjogMjYtY2hhcmFjdGVyIENyb2NrZm9yZCBiYXNlMzIgc3RyaW5nXHJcbiAqIG9mICh0aW1lc3RhbXBfbXMgfHwgcmFuZG9tbmVzcykuIEdvb2QgZW5vdWdoIGZvciBydW4gaWRlbnRpZmllcnMgd2l0aG91dFxyXG4gKiBwdWxsaW5nIGluIGEgcmVhbCBVTElEIGRlcGVuZGVuY3kuXHJcbiAqL1xyXG5cclxuY29uc3QgQUxQSEFCRVQgPSAnMDEyMzQ1Njc4OUFCQ0RFRkdISktNTlBRUlNUVldYWVonOyAvLyBDcm9ja2ZvcmRcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBuZXdSdW5JZCgpOiBzdHJpbmcge1xyXG4gIGNvbnN0IHRzID0gRGF0ZS5ub3coKTtcclxuICBsZXQgdHNQYXJ0ID0gJyc7XHJcbiAgbGV0IHQgPSB0cztcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IDEwOyBpKyspIHtcclxuICAgIHRzUGFydCA9IChBTFBIQUJFVFt0ICUgMzJdID8/ICcwJykgKyB0c1BhcnQ7XHJcbiAgICB0ID0gTWF0aC5mbG9vcih0IC8gMzIpO1xyXG4gIH1cclxuICBjb25zdCByYW5kID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMCkpO1xyXG4gIGxldCByYW5kUGFydCA9ICcnO1xyXG4gIGZvciAoY29uc3QgYiBvZiByYW5kKSByYW5kUGFydCArPSBBTFBIQUJFVFtiICUgMzJdID8/ICcwJztcclxuICByZXR1cm4gdHNQYXJ0ICsgcmFuZFBhcnQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzaG9ydFJ1bklkKGlkOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIHJldHVybiBpZC5zbGljZSgtOCk7XHJcbn1cclxuIiwgImltcG9ydCB0eXBlIHsgQWNjb3VudENhdGVnb3J5LCBBY2NvdW50Q29uZmlnIH0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG4vKipcclxuICogTWluaW1hbCBwYXJzZXIgZm9yIHRoZSBzdHJpY3Qgc2hhcGUgdXNlZCBieSBgY29uZmlnL2FjY291bnRzLnlhbWxgOlxyXG4gKlxyXG4gKiAgIGFjY291bnRzOlxyXG4gKiAgICAgLSBoYW5kbGU6IERIU2dvdlxyXG4gKiAgICAgICBsYWJlbDogRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eVxyXG4gKiAgICAgICBjYXRlZ29yeTogY29yZVxyXG4gKlxyXG4gKiBXZSBkZWxpYmVyYXRlbHkgZG9uJ3QgcHVsbCBpbiBhIGZ1bGwgWUFNTCBsaWJyYXJ5IFx1MjAxNCB3ZSBjb250cm9sIGJvdGggZW5kcyBvZlxyXG4gKiB0aGlzIGZpbGUsIGFuZCBhIHNtYWxsIHBhcnNlciBpcyBlYXNpZXIgdG8gYXVkaXQgdGhhbiB0aGUgYWx0ZXJuYXRpdmVzLlxyXG4gKiBVbmtub3duIGtleXMgYW5kIGNvbW1lbnRzIGFyZSB0b2xlcmF0ZWQ7IG1hbGZvcm1lZCBsaW5lcyBhcmUgc2tpcHBlZC5cclxuICpcclxuICogRW50cmllcyBtaXNzaW5nIGEgYGNhdGVnb3J5YCBkZWZhdWx0IHRvIGBjb3JlYCBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eVxyXG4gKiB3aXRoIHRoZSBwcmUtY2F0ZWdvcml6YXRpb24gZmlsZSBzaGFwZS5cclxuICovXHJcbmNvbnN0IFZBTElEX0NBVEVHT1JJRVM6IFJlYWRvbmx5U2V0PEFjY291bnRDYXRlZ29yeT4gPSBuZXcgU2V0KFtcclxuICAnY29yZScsXHJcbiAgJ2dvdmVybm1lbnQnLFxyXG4gICdvZmZpY2lhbHMnLFxyXG4gICdwdWJsaWNfZmlndXJlcycsXHJcbiAgJ3B1YmxpYycsXHJcbl0pO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQWNjb3VudHNZYW1sKHRleHQ6IHN0cmluZyk6IEFjY291bnRDb25maWdbXSB7XHJcbiAgY29uc3QgYWNjb3VudHM6IEFjY291bnRDb25maWdbXSA9IFtdO1xyXG4gIGxldCBjdXJyZW50OiBQYXJ0aWFsPEFjY291bnRDb25maWc+ID0ge307XHJcbiAgbGV0IGluQWNjb3VudHMgPSBmYWxzZTtcclxuICBjb25zdCBmbHVzaCA9ICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSB7XHJcbiAgICAgIGlmICghY3VycmVudC5jYXRlZ29yeSkgY3VycmVudC5jYXRlZ29yeSA9ICdjb3JlJztcclxuICAgICAgYWNjb3VudHMucHVzaChjdXJyZW50IGFzIEFjY291bnRDb25maWcpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgZm9yIChjb25zdCByYXdMaW5lIG9mIHRleHQuc3BsaXQoJ1xcbicpKSB7XHJcbiAgICBjb25zdCBsaW5lID0gc3RyaXBDb21tZW50cyhyYXdMaW5lKTtcclxuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gJycpIGNvbnRpbnVlO1xyXG4gICAgaWYgKC9eYWNjb3VudHNcXHMqOi8udGVzdChsaW5lKSkge1xyXG4gICAgICBpbkFjY291bnRzID0gdHJ1ZTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAoIWluQWNjb3VudHMpIGNvbnRpbnVlO1xyXG5cclxuICAgIGNvbnN0IGl0ZW1NYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqLVxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xyXG4gICAgaWYgKGl0ZW1NYXRjaCkge1xyXG4gICAgICBmbHVzaCgpO1xyXG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaXRlbU1hdGNoWzFdID8/ICcnKSB9O1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGhhbmRsZU9ubHkgPSBsaW5lLm1hdGNoKC9eXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XHJcbiAgICBpZiAoaGFuZGxlT25seSAmJiAhbGluZS5pbmNsdWRlcygnLScpKSB7XHJcbiAgICAgIGZsdXNoKCk7XHJcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShoYW5kbGVPbmx5WzFdID8/ICcnKSB9O1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGxhYmVsTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmxhYmVsXFxzKjpcXHMqKC4rKSQvKTtcclxuICAgIGlmIChsYWJlbE1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XHJcbiAgICAgIGN1cnJlbnQubGFiZWwgPSB1bnF1b3RlKGxhYmVsTWF0Y2hbMV0gPz8gJycpO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGNhdGVnb3J5TWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmNhdGVnb3J5XFxzKjpcXHMqKC4rKSQvKTtcclxuICAgIGlmIChjYXRlZ29yeU1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XHJcbiAgICAgIGNvbnN0IHJhdyA9IHVucXVvdGUoY2F0ZWdvcnlNYXRjaFsxXSA/PyAnJyk7XHJcbiAgICAgIGN1cnJlbnQuY2F0ZWdvcnkgPSBWQUxJRF9DQVRFR09SSUVTLmhhcyhyYXcgYXMgQWNjb3VudENhdGVnb3J5KVxyXG4gICAgICAgID8gKHJhdyBhcyBBY2NvdW50Q2F0ZWdvcnkpXHJcbiAgICAgICAgOiAnY29yZSc7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gIH1cclxuICBmbHVzaCgpO1xyXG4gIHJldHVybiBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuaGFuZGxlLmxlbmd0aCA+IDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdHJpcENvbW1lbnRzKGxpbmU6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgLy8gTmFpdmUgYnV0IGFkZXF1YXRlIGZvciBvdXIgZm9ybWF0OiBzdHJpcCBldmVyeXRoaW5nIGFmdGVyIGEgYCNgIHRoYXQgaXNuJ3RcclxuICAvLyBpbnNpZGUgcXVvdGVzLiBPdXIgY29uZmlnIG5ldmVyIHVzZXMgaW5saW5lIHN0cmluZ3Mgd2l0aCBgI2AuXHJcbiAgY29uc3QgaWR4ID0gbGluZS5pbmRleE9mKCcjJyk7XHJcbiAgcmV0dXJuIGlkeCA9PT0gLTEgPyBsaW5lIDogbGluZS5zbGljZSgwLCBpZHgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgY29uc3QgdHJpbW1lZCA9IHMudHJpbSgpO1xyXG4gIGlmIChcclxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoJ1wiJykgJiYgdHJpbW1lZC5lbmRzV2l0aCgnXCInKSkgfHxcclxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoXCInXCIpICYmIHRyaW1tZWQuZW5kc1dpdGgoXCInXCIpKVxyXG4gICkge1xyXG4gICAgcmV0dXJuIHRyaW1tZWQuc2xpY2UoMSwgLTEpO1xyXG4gIH1cclxuICByZXR1cm4gdHJpbW1lZDtcclxufVxyXG4iLCAiLyoqXHJcbiAqIGJhY2tncm91bmQudHMgXHUyMDE0IGV4dGVuc2lvbiBzZXJ2aWNlIHdvcmtlci5cclxuICpcclxuICogT3ducyB0aGUgY2FwdHVyZSBwaXBlbGluZTogcmVjZWl2ZXMgYGdyYXBocWwtY2FwdHVyZWAgbWVzc2FnZXMgZnJvbSB0aGVcclxuICogY29udGVudCBzY3JpcHQsIG5vcm1hbGl6ZXMgdGhlbSwgYWNjdW11bGF0ZXMgcGVyLWhhbmRsZSBydW4gYnVmZmVycyBpblxyXG4gKiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgYW5kIGNvbW1pdHMgdGhlbSB0byB0aGUgY29uZmlndXJlZCBHaXRIdWIgcmVwb1xyXG4gKiB2aWEgdGhlIEdpdCBEYXRhIEFQSS5cclxuICpcclxuICogU2VydmljZSB3b3JrZXJzIGluIE1WMyBtYXkgYmUgZXZpY3RlZCBhdCBhbnkgdGltZSwgc28gYWxsIGNyaXRpY2FsIHN0YXRlXHJcbiAqIGxpdmVzIGluIHN0b3JhZ2UgKG5ldmVyIG1vZHVsZS1zY29wZSkuIE9uIGV2ZXJ5IHdha2Ugd2UgcmUtZGVyaXZlIHdoYXQgd2VcclxuICogbmVlZDsgcGVuZGluZyBmbHVzaGVzIGFyZSBkcml2ZW4gYnkgYGJyb3dzZXIuYWxhcm1zYCByYXRoZXIgdGhhbiB0aW1lcnMuXHJcbiAqL1xyXG5cclxuaW1wb3J0IHtcclxuICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxyXG4gIEFVVE9fU0NST0xMX01JTl9TRUMsXHJcbiAgRkFMTEJBQ0tfQUNDT1VOVFMsXHJcbiAgRkxVU0hfQUxBUk1fTUlOVVRFUyxcclxuICBGTFVTSF9JRExFX01TLFxyXG4gIEZMVVNIX1RXRUVUX1RIUkVTSE9MRCxcclxuICBQUk9GSUxFX0VORFBPSU5UUyxcclxuICBUV0VFVF9FTkRQT0lOVFMsXHJcbiAgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMsXHJcbn0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcclxuaW1wb3J0IHsgR2l0SHViQ2xpZW50LCBHaXRIdWJFcnJvciwgdG9CYXNlNjQgfSBmcm9tICcuL2xpYi9naXRodWIuanMnO1xyXG5pbXBvcnQgeyBkZXNjcmliZUVycm9yLCBlcnJvciBhcyBsb2dFcnIsIGluZm8sIHNldEJyb2FkY2FzdGVyLCB3YXJuIH0gZnJvbSAnLi9saWIvbG9nZ2VyLmpzJztcclxuaW1wb3J0IHsgZmlsdGVyUmVsYXRlZCwgbm9ybWFsaXplIH0gZnJvbSAnLi9saWIvbm9ybWFsaXplLmpzJztcclxuaW1wb3J0IHsgbmV3UnVuSWQsIHNob3J0UnVuSWQgfSBmcm9tICcuL2xpYi9ydW5pZHMuanMnO1xyXG5pbXBvcnQge1xyXG4gIGJ1bXBDb3VudGVyLFxyXG4gIGNsZWFyQWN0aXZpdHksXHJcbiAgY2xlYXJBbGwsXHJcbiAgY2xlYXJSdW5CdWZmZXIsXHJcbiAgZGVxdWV1ZU1lZGlhQ3Jhd2wsXHJcbiAgZGVxdWV1ZVJlZmV0Y2gsXHJcbiAgZGVxdWV1ZVRocmVhZE9wZW4sXHJcbiAgZW5nYWdlbWVudFNpZyxcclxuICBlbnF1ZXVlTWVkaWFDcmF3bCxcclxuICBlbnF1ZXVlUmVmZXRjaCxcclxuICBlbnF1ZXVlVGhyZWFkT3BlbixcclxuICBnZXRBY2NvdW50cyxcclxuICBnZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxyXG4gIGdldEFjdGl2aXR5LFxyXG4gIGdldEFyY2hpdmVTbmFwc2hvdCxcclxuICBnZXRBdXRvU2Nyb2xsU2Vzc2lvbixcclxuICBnZXRDb21taXR0ZWRJbmRleCxcclxuICBnZXRDb25uZWN0aW9uLFxyXG4gIGdldENvdW50ZXJzLFxyXG4gIGdldE1lZGlhQ3Jhd2xRdWV1ZSxcclxuICBnZXRNZWRpYUNyYXdsU2Vzc2lvbixcclxuICBnZXRSZWZldGNoUXVldWUsXHJcbiAgZ2V0UmVmZXRjaFNlc3Npb24sXHJcbiAgZ2V0UmVjZW50VHdlZXRTaWdodGluZ3MsXHJcbiAgZ2V0UnVuQnVmZmVyLFxyXG4gIGdldFJ1bkJ1ZmZlcnMsXHJcbiAgZ2V0U2V0dGluZ3MsXHJcbiAgZ2V0VGhyZWFkT3BlblF1ZXVlLFxyXG4gIGdldFRocmVhZE9wZW5TZXNzaW9uLFxyXG4gIGhhc1RocmVhZE9wZW5TZWVuLFxyXG4gIGlzQ29tbWl0dGVkLFxyXG4gIG1hcmtUaHJlYWRPcGVuU2VlbixcclxuICBtZWRpYUNyYXdsUXVldWVUb3RhbCxcclxuICBuZXh0TWVkaWFDcmF3bFRhcmdldCxcclxuICBuZXh0UmVmZXRjaFRhcmdldCxcclxuICBuZXh0VGhyZWFkT3BlblRhcmdldCxcclxuICBwcnVuZUNvbW1pdHRlZEluZGV4LFxyXG4gIHB1cmdlVW5yZWxhdGVkU3RhdGUsXHJcbiAgcmVmZXRjaFF1ZXVlVG90YWwsXHJcbiAgcHJlcGVuZFJlY2VudFR3ZWV0U2lnaHRpbmdzLFxyXG4gIHNldEFjY291bnRzLFxyXG4gIHNldEFjY291bnRzUmVmcmVzaGVkQXQsXHJcbiAgc2V0QXJjaGl2ZVNuYXBzaG90LFxyXG4gIHNldEF1dG9TY3JvbGxTZXNzaW9uLFxyXG4gIHNldEJ1ZmZlcmVkQ291bnQsXHJcbiAgc2V0Q29tbWl0dGVkSW5kZXgsXHJcbiAgc2V0Q29ubmVjdGlvbixcclxuICBzZXRNZWRpYUNyYXdsU2Vzc2lvbixcclxuICBzZXRSZWZldGNoU2Vzc2lvbixcclxuICBzZXRSdW5CdWZmZXIsXHJcbiAgc2V0VGhyZWFkT3BlblNlc3Npb24sXHJcbiAgdGhyZWFkT3BlblF1ZXVlVG90YWwsXHJcbiAgdHlwZSBSdW5CdWZmZXIsXHJcbiAgdXBkYXRlU2V0dGluZ3MsXHJcbn0gZnJvbSAnLi9saWIvc3RvcmFnZS5qcyc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBDYW5vbmljYWxUd2VldCxcclxuICBDYXB0dXJlUGF5bG9hZCxcclxuICBBcmNoaXZlU25hcHNob3QsXHJcbiAgQ29ubmVjdGlvblN0YXRlLFxyXG4gIEV4dGVuc2lvblN0YXRlLFxyXG4gIExvZ0V2ZW50LFxyXG4gIFF1YXJhbnRpbmVQYXlsb2FkLFxyXG4gIFJldHdlZXRFZGdlLFxyXG4gIFJ1bnRpbWVNZXNzYWdlLFxyXG4gIFNlZW5QYXlsb2FkLFxyXG4gIFNldHRpbmdzLFxyXG4gIFR3ZWV0U2lnaHRpbmcsXHJcbiAgVW5hdmFpbGFibGVUd2VldCxcclxufSBmcm9tICcuL2xpYi90eXBlcy5qcyc7XHJcbmltcG9ydCB7IHBhcnNlQWNjb3VudHNZYW1sIH0gZnJvbSAnLi9saWIveWFtbC5qcyc7XHJcblxyXG5jb25zdCBFWFRfVkVSU0lPTiA9IGJyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb247XHJcbmNvbnN0IE1BTlVBTF9DQVBUVVJFX1dJTkRPV19NUyA9IDkwXzAwMDtcclxubGV0IG1hbnVhbENhcHR1cmVVbnRpbE1zID0gMDtcclxuXHJcbnNldEJyb2FkY2FzdGVyKChldjogTG9nRXZlbnQpID0+IHtcclxuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnbG9nLWV2ZW50JywgZXZlbnQ6IGV2IH0pLmNhdGNoKCgpID0+IHt9KTtcclxufSk7XHJcblxyXG5mdW5jdGlvbiBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTogdm9pZCB7XHJcbiAgbWFudWFsQ2FwdHVyZVVudGlsTXMgPSBEYXRlLm5vdygpICsgTUFOVUFMX0NBUFRVUkVfV0lORE9XX01TO1xyXG59XHJcblxyXG4vLyAtLS0gV2FrZSBoYW5kbGVycyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuYnJvd3Nlci5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcclxuICBhd2FpdCBpbmZvKCdleHRlbnNpb24gaW5zdGFsbGVkJywgeyB2ZXJzaW9uOiBFWFRfVkVSU0lPTiB9KTtcclxuICBhd2FpdCBvbldha2UoJ2luc3RhbGwnKTtcclxufSk7XHJcblxyXG5icm93c2VyLnJ1bnRpbWUub25TdGFydHVwLmFkZExpc3RlbmVyKCgpID0+IHtcclxuICB2b2lkIG9uV2FrZSgnc3RhcnR1cCcpO1xyXG59KTtcclxuXHJcbi8vIEZvcmNlIGF0IGxlYXN0IG9uZSB3YWtlIHRvIHJlZ2lzdGVyIGFsYXJtcyAvIHZlcmlmeSBjb25uZWN0aW9uLlxyXG52b2lkIG9uV2FrZSgnbW9kdWxlLWxvYWQnKTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIG9uV2FrZShyZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBlbnN1cmVBbGFybXMoKTtcclxuICAgIGF3YWl0IGVuc3VyZUF1dG9TY3JvbGxBbGFybSgpO1xyXG4gICAgYXdhaXQgZmx1c2hPcnBoYW5lZEJ1ZmZlcnNJZlN0YWxlKCk7XHJcbiAgICBhd2FpdCByZWluamVjdEludG9PcGVuVGFicygpO1xyXG4gICAgLy8gRHJvcCBkZWR1cC1pbmRleCBlbnRyaWVzIG9sZGVyIHRoYW4gMzAgZGF5cyBzbyB0aGUgc3RvcmUgZG9lc24ndFxyXG4gICAgLy8gZ3JvdyB1bmJvdW5kZWQgb3ZlciBtb250aHMgb2YgY2FwdHVyZSBzZXNzaW9ucy5cclxuICAgIGNvbnN0IHBydW5lZCA9IGF3YWl0IHBydW5lQ29tbWl0dGVkSW5kZXgoMzAgKiAyNCAqIDYwICogNjAgKiAxMDAwKTtcclxuICAgIGlmIChwcnVuZWQgPiAwKSBhd2FpdCBpbmZvKCdwcnVuZWQgY29tbWl0dGVkIGluZGV4JywgeyBwcnVuZWQgfSk7XHJcbiAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgICBpZiAoc2V0dGluZ3MucGF0ICYmIHNldHRpbmdzLm93bmVyICYmIHNldHRpbmdzLnJlcG8pIHtcclxuICAgICAgYXdhaXQgdmVyaWZ5Q29ubmVjdGlvbihmYWxzZSk7XHJcbiAgICAgIGF3YWl0IHJlZnJlc2hBY2NvdW50c0xpc3QoZmFsc2UpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxyXG4gICAgICAgIGxvZ2luOiBudWxsLFxyXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIGVycm9yOiBudWxsLFxyXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXHJcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcclxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxyXG4gICAgICB9KTtcclxuICAgICAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIGF3YWtlOyBzZXR0aW5ncyBpbmNvbXBsZXRlJywgeyByZWFzb24gfSk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCBsb2dFcnIoJ3dha2UgZmFpbGVkJywgeyByZWFzb24sIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBSZS1pbmplY3QgdGhlIE1BSU4td29ybGQgcGFnZS1ob29rICsgaXNvbGF0ZWQtd29ybGQgY29udGVudCBzY3JpcHQgaW50b1xyXG4gKiBldmVyeSBhbHJlYWR5LW9wZW4geC5jb20gLyB0d2l0dGVyLmNvbSB0YWIuXHJcbiAqXHJcbiAqIE1hbmlmZXN0IGNvbnRlbnRfc2NyaXB0cyBvbmx5IGluamVjdCBvbiBmcmVzaCBuYXZpZ2F0aW9uIChydW5fYXQ6XHJcbiAqIGRvY3VtZW50X3N0YXJ0KS4gV2hlbiB0aGUgdXNlciByZWxvYWRzIHRoZSBleHRlbnNpb24gd2hpbGUgWCB0YWJzIGFyZVxyXG4gKiBvcGVuLCB0aG9zZSB0YWJzIGtlZXAgdGhlaXIgY29udGVudCBzY3JpcHRzIGJ1dCBuZXZlciBnZXQgYSBuZXcgcGFnZS1ob29rXHJcbiAqIFx1MjAxNCBzbyBmZXRjaC9YSFIgc3RheXMgdW5wYXRjaGVkIGFuZCBjYXB0dXJlcyBzaWxlbnRseSBmYWlsLiBEb2luZyB0aGlzIG9uXHJcbiAqIGV2ZXJ5IHdha2UgaXMgaWRlbXBvdGVudCAocGFnZS1ob29rIGhhcyBhIFRBRyBndWFyZCkgYW5kIGNoZWFwLlxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gcmVpbmplY3RJbnRvT3BlblRhYnMoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcclxuICB0cnkge1xyXG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdjb3VsZCBub3QgcXVlcnkgb3BlbiB0YWJzJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgaWYgKHRhYnMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcbiAgZm9yIChjb25zdCB0YWIgb2YgdGFicykge1xyXG4gICAgaWYgKHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInKSBjb250aW51ZTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXHJcbiAgICAgICAgZmlsZXM6IFsncGFnZS1ob29rLmpzJ10sXHJcbiAgICAgICAgLy8gRmlyZWZveCAxMjgrIHN1cHBvcnRzIHRoZSBNQUlOIGV4ZWN1dGlvbiB3b3JsZCB2aWEgdGhpcyBBUEksIGJ1dFxyXG4gICAgICAgIC8vIHRoZSBAdHlwZXMvZmlyZWZveC13ZWJleHQtYnJvd3NlciBwYWNrYWdlIHdlJ3JlIG9uIHN0aWxsIG9ubHlcclxuICAgICAgICAvLyBkZWNsYXJlcyAnSVNPTEFURUQnLiBDYXN0IHRocm91Z2ggdGhlIGxpdGVyYWwgdW5pb24uXHJcbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxyXG4gICAgICB9KTtcclxuICAgICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XHJcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcclxuICAgICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXHJcbiAgICAgIH0pO1xyXG4gICAgICBhd2FpdCBpbmZvKCdyZS1pbmplY3RlZCBzY3JpcHRzIGludG8gb3BlbiB0YWInLCB7XHJcbiAgICAgICAgdGFiSWQ6IHRhYi5pZCxcclxuICAgICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCA/PyAnJyksXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIC8vIFNvbWUgdGFicyAoYWJvdXQ6IHBhZ2VzLCBkaXNjYXJkZWQgdGFicywgbWlkLW5hdmlnYXRpb24pIHJlamVjdFxyXG4gICAgICAvLyBleGVjdXRlU2NyaXB0LiBUaGF0J3MgZmluZSBcdTIwMTQgd2UnbGwgY2F0Y2ggdGhlbSBvbiB0aGUgbmV4dCB3YWtlIG9yXHJcbiAgICAgIC8vIHdoZW4gdGhlIHVzZXIgbmF2aWdhdGVzLlxyXG4gICAgICBhd2FpdCB3YXJuKCdyZS1pbmplY3QgZmFpbGVkIGZvciB0YWI7IGNvbnRpbnVpbmcnLCB7XHJcbiAgICAgICAgdGFiSWQ6IHRhYi5pZCxcclxuICAgICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCA/PyAnJyksXHJcbiAgICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUFsYXJtcygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignZmx1c2gtc3dlZXAnKTtcclxuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigndmVyaWZ5LWNvbm5lY3Rpb24nKTtcclxuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jcmVhdGUoJ2ZsdXNoLXN3ZWVwJywgeyBwZXJpb2RJbk1pbnV0ZXM6IEZMVVNIX0FMQVJNX01JTlVURVMgfSk7XHJcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY3JlYXRlKCd2ZXJpZnktY29ubmVjdGlvbicsIHtcclxuICAgIHBlcmlvZEluTWludXRlczogVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgLyA2MF8wMDAsXHJcbiAgfSk7XHJcbn1cclxuXHJcbi8vIEZpcmVmb3ggTVYzIGFsYXJtcyBoYXZlIGEgMzBzIG1pbmltdW0gcGVyaW9kLCBidXQgd2Ugd2FudCBzdWItbWludXRlXHJcbi8vIHNjcm9sbGluZy4gVGhlIGF1dG8tc2Nyb2xsIGxvb3AgdGhlcmVmb3JlIHJ1bnMgb24gYW4gaW4tU1cgaW50ZXJ2YWwuXHJcbi8vIGBhdXRvU2Nyb2xsU2Vzc2lvbmAgaW4gc3RvcmFnZSBpcyB0aGUgc291cmNlIG9mIHRydXRoIGZvciB3aGV0aGVyIHRoZSBsb29wXHJcbi8vIGlzIG1lYW50IHRvIGJlIHJ1bm5pbmcgXHUyMDE0IHRoZSB0aW1lciBpcyBqdXN0IHRoZSBsb2NhbCBleGVjdXRpb24gYXJtLlxyXG5sZXQgYXV0b1Njcm9sbFRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcclxuY29uc3QgU0hPV19NT1JFX1JFTEVWQU5DRV9UVExfTVMgPSAxMCAqIDYwICogMTAwMDtcclxuaW50ZXJmYWNlIFRhYlJlbGV2YW50VHdlZXRzIHtcclxuICB1cGRhdGVkQXQ6IG51bWJlcjtcclxuICBwYWdlVXJsOiBzdHJpbmcgfCBudWxsO1xyXG4gIHR3ZWV0SWRzOiBTZXQ8c3RyaW5nPjtcclxufVxyXG5jb25zdCBzaG93TW9yZVJlbGV2YW50VHdlZXRzQnlUYWIgPSBuZXcgTWFwPG51bWJlciwgVGFiUmVsZXZhbnRUd2VldHM+KCk7XHJcblxyXG4vLyBXYWl0LWZvci1pbmdlc3QgdGltZW91dDogaWYgYSByZWZldGNoIC8gbWVkaWEtY3Jhd2wgdGFiIG5hdmlnYXRpb24gZG9lc24ndFxyXG4vLyBwcm9kdWNlIGFuIGluZ2VzdGVkIGNhcHR1cmUgd2l0aGluIHRoaXMgbWFueSBtcywgYWR2YW5jZSBhbnl3YXkgc28gd2VcclxuLy8gZG9uJ3QgZGVhZGxvY2sgb24gZGVsZXRlZCAvIDQwNCAvIHBheXdhbGxlZCB0d2VldHMuXHJcbmNvbnN0IElOR0VTVF9XQUlUX01TID0gMjVfMDAwO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQXV0b1Njcm9sbEFsYXJtKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIC8vIFdhcyB0aGUgbG9vcCBydW5uaW5nIGJlZm9yZSB0aGUgU1cgZXZpY3Rpb24/IFJlLWFybSBpZiBzby5cclxuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoc2VzcyAhPT0gbnVsbCAmJiBzLmVuYWJsZWQgIT09IGZhbHNlKSB7XHJcbiAgICBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTogdm9pZCB7XHJcbiAgaWYgKGF1dG9TY3JvbGxUaW1lciAhPT0gbnVsbCkge1xyXG4gICAgY2xlYXJJbnRlcnZhbChhdXRvU2Nyb2xsVGltZXIpO1xyXG4gICAgYXV0b1Njcm9sbFRpbWVyID0gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFybUF1dG9TY3JvbGxUaW1lcihpbnRlcnZhbFNlYzogbnVtYmVyKTogdm9pZCB7XHJcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcclxuICBjb25zdCBjbGFtcGVkID0gTWF0aC5taW4oXHJcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxyXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChpbnRlcnZhbFNlYykpXHJcbiAgKTtcclxuICBhdXRvU2Nyb2xsVGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIGF1dG9TY3JvbGxUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ2F1dG8tc2Nyb2xsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIH0pO1xyXG4gIH0sIGNsYW1wZWQgKiAxMDAwKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc3RhcnRBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbih7XHJcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIHNjcm9sbENvdW50OiAwLFxyXG4gICAgaW5nZXN0ZWRDb3VudDogMCxcclxuICAgIGluZ2VzdGVkTmV3Q291bnQ6IDAsXHJcbiAgICBpbmdlc3RlZEV4aXN0aW5nQ291bnQ6IDAsXHJcbiAgICBza2lwcGVkT2xkQ291bnQ6IDAsXHJcbiAgICBleHBhbmRlZENvdW50OiAwLFxyXG4gIH0pO1xyXG4gIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XHJcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBzdGFydGVkJywgeyBpbnRlcnZhbF9zZWM6IHMuYXV0b1Njcm9sbEludGVydmFsU2VjIH0pO1xyXG4gIC8vIEZpcmUgb25lIGltbWVkaWF0ZSB0aWNrIHNvIHRoZSB1c2VyIHNlZXMgbW90aW9uIHJpZ2h0IGF3YXkuXHJcbiAgdm9pZCBhdXRvU2Nyb2xsVGljaygpO1xyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbEF1dG9TY3JvbGxMb29wKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24obnVsbCk7XHJcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBzY3JvbGxzOiBzZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxyXG4gICAgaW5nZXN0ZWQ6IHNlc3M/LmluZ2VzdGVkQ291bnQgPz8gMCxcclxuICAgIGV4cGFuZGVkOiBzZXNzPy5leHBhbmRlZENvdW50ID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gYXV0b1Njcm9sbFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcclxuICB0cnkge1xyXG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdhdXRvLXNjcm9sbDogdGFiIHF1ZXJ5IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gIGxldCBzY3JvbGxDb3VudCA9IDA7XHJcbiAgZm9yIChjb25zdCB0YWIgb2YgdGFicykge1xyXG4gICAgaWYgKHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInKSBjb250aW51ZTtcclxuICAgIGlmICh0YWIuZGlzY2FyZGVkKSBjb250aW51ZTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3VsdHMgPSAoYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XHJcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcclxuICAgICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXHJcbiAgICAgICAgZnVuYzogKCgpID0+IHtcclxuICAgICAgICAgIC8vIFNjcm9sbCB0aGUgcGFnZS4gRGlzcGF0Y2ggRW5kIGtleSBmaXJzdCBzaW5jZSBtYW55IFggc3VyZmFjZXNcclxuICAgICAgICAgIC8vICAgIChsaXN0cywgc2VhcmNoLCByZXBsaWVzKSBiaW5kIHBhZ2luYXRpb24gdHJpZ2dlcnMgdG8gaXQgdmlhXHJcbiAgICAgICAgICAvLyAgICBSZWFjdCBoYW5kbGVyczsgdGhlbiBleHBsaWNpdGx5IHNjcm9sbCB0aGUgZG9jdW1lbnQuXHJcbiAgICAgICAgICBjb25zdCBvcHRzOiBLZXlib2FyZEV2ZW50SW5pdCA9IHtcclxuICAgICAgICAgICAga2V5OiAnRW5kJyxcclxuICAgICAgICAgICAgY29kZTogJ0VuZCcsXHJcbiAgICAgICAgICAgIGtleUNvZGU6IDM1LFxyXG4gICAgICAgICAgICB3aGljaDogMzUsXHJcbiAgICAgICAgICAgIGJ1YmJsZXM6IHRydWUsXHJcbiAgICAgICAgICAgIGNhbmNlbGFibGU6IHRydWUsXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgY29uc3QgZm9jdXMgPSAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCB8IG51bGwpID8/IGRvY3VtZW50LmJvZHk7XHJcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXlkb3duJywgb3B0cykpO1xyXG4gICAgICAgICAgZm9jdXMuZGlzcGF0Y2hFdmVudChuZXcgS2V5Ym9hcmRFdmVudCgna2V5dXAnLCBvcHRzKSk7XHJcbiAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oe1xyXG4gICAgICAgICAgICB0b3A6IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxIZWlnaHQsXHJcbiAgICAgICAgICAgIGJlaGF2aW9yOiAnYXV0bycsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9KSBhcyAoKSA9PiB2b2lkLFxyXG4gICAgICB9KSkgYXMgQXJyYXk8eyByZXN1bHQ/OiB1bmtub3duIH0+O1xyXG4gICAgICBzY3JvbGxDb3VudCArPSAxO1xyXG4gICAgICB2b2lkIHJlc3VsdHM7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgLy8gVGFicyB0aGF0IGRpc2FsbG93IHNjcmlwdGluZyAoYWJvdXQ6LCBkaXNjYXJkZWQsIG1pZC1uYXZpZ2F0aW9uKVxyXG4gICAgICAvLyBqdXN0IGdldCBza2lwcGVkIFx1MjAxNCB0aGV5J2xsIGJlIGVsaWdpYmxlIG9uIGEgbGF0ZXIgdGljay5cclxuICAgIH1cclxuICB9XHJcbiAgaWYgKHNjcm9sbENvdW50ID4gMCkge1xyXG4gICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgICBpZiAoc2VzcyAhPT0gbnVsbCkge1xyXG4gICAgICBzZXNzLnNjcm9sbENvdW50ICs9IHNjcm9sbENvdW50O1xyXG4gICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzZXNzKTtcclxuICAgICAgLy8gTm8gYnJvYWRjYXN0IG9uIGV2ZXJ5IHRpY2sgXHUyMDE0IHRoZSAxNXMgc2lkZWJhciByZWZyZXNoIHBpY2tzIGl0IHVwLlxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcHJ1bmVTaG93TW9yZVJlbGV2YW5jZSgpOiB2b2lkIHtcclxuICBjb25zdCBjdXRvZmYgPSBEYXRlLm5vdygpIC0gU0hPV19NT1JFX1JFTEVWQU5DRV9UVExfTVM7XHJcbiAgZm9yIChjb25zdCBbdGFiSWQsIGVudHJ5XSBvZiBzaG93TW9yZVJlbGV2YW50VHdlZXRzQnlUYWIpIHtcclxuICAgIGlmIChlbnRyeS51cGRhdGVkQXQgPCBjdXRvZmYpIHNob3dNb3JlUmVsZXZhbnRUd2VldHNCeVRhYi5kZWxldGUodGFiSWQpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcmVtZW1iZXJTaG93TW9yZVJlbGV2YW50VHdlZXRzKFxyXG4gIHRhYklkOiBudW1iZXIgfCBudWxsLFxyXG4gIHBhZ2VVcmw6IHN0cmluZyB8IG51bGwsXHJcbiAgdHdlZXRzOiBSZWFkb25seUFycmF5PENhbm9uaWNhbFR3ZWV0PixcclxuICBjb3JlSGFuZGxlczogUmVhZG9ubHlTZXQ8c3RyaW5nPlxyXG4pOiB2b2lkIHtcclxuICBpZiAodGFiSWQgPT09IG51bGwgfHwgdHdlZXRzLmxlbmd0aCA9PT0gMCB8fCBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm47XHJcbiAgY29uc3QgY29yZVR3ZWV0SWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xyXG4gICAgaWYgKGNvcmVIYW5kbGVzLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSBjb3JlVHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xyXG4gIH1cclxuICBjb25zdCBleGlzdGluZyA9IHNob3dNb3JlUmVsZXZhbnRUd2VldHNCeVRhYi5nZXQodGFiSWQpO1xyXG4gIGNvbnN0IHR3ZWV0SWRzID0gZXhpc3Rpbmc/LnR3ZWV0SWRzID8/IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcclxuICAgIGNvbnN0IGhhbmRsZSA9IHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKTtcclxuICAgIGNvbnN0IHJlcGx5SGFuZGxlID0gdC5yZXBseV90b19hY2NvdW50Py50b0xvd2VyQ2FzZSgpID8/IG51bGw7XHJcbiAgICBpZiAoXHJcbiAgICAgIGNvcmVIYW5kbGVzLmhhcyhoYW5kbGUpIHx8XHJcbiAgICAgIChyZXBseUhhbmRsZSAhPT0gbnVsbCAmJiBjb3JlSGFuZGxlcy5oYXMocmVwbHlIYW5kbGUpKSB8fFxyXG4gICAgICAodC5yZXBseV90b190d2VldF9pZCAhPT0gbnVsbCAmJiBjb3JlVHdlZXRJZHMuaGFzKHQucmVwbHlfdG9fdHdlZXRfaWQpKSB8fFxyXG4gICAgICAodC5xdW90ZWRfdHdlZXRfaWQgIT09IG51bGwgJiYgY29yZVR3ZWV0SWRzLmhhcyh0LnF1b3RlZF90d2VldF9pZCkpIHx8XHJcbiAgICAgICh0LnJldHdlZXRlZF90d2VldF9pZCAhPT0gbnVsbCAmJiBjb3JlVHdlZXRJZHMuaGFzKHQucmV0d2VldGVkX3R3ZWV0X2lkKSlcclxuICAgICkge1xyXG4gICAgICB0d2VldElkcy5hZGQodC50d2VldF9pZCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHNob3dNb3JlUmVsZXZhbnRUd2VldHNCeVRhYi5zZXQodGFiSWQsIHtcclxuICAgIHVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcclxuICAgIHBhZ2VVcmwsXHJcbiAgICB0d2VldElkcyxcclxuICB9KTtcclxufVxyXG5cclxuYnJvd3Nlci5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcigoYWxhcm0pID0+IHtcclxuICBpZiAoYWxhcm0ubmFtZSA9PT0gJ2ZsdXNoLXN3ZWVwJykge1xyXG4gICAgdm9pZCBmbHVzaElkbGVCdWZmZXJzKCk7XHJcbiAgfSBlbHNlIGlmIChhbGFybS5uYW1lID09PSAndmVyaWZ5LWNvbm5lY3Rpb24nKSB7XHJcbiAgICB2b2lkIHZlcmlmeUNvbm5lY3Rpb24oZmFsc2UpO1xyXG4gIH1cclxuICAvLyByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcHJldmlvdXNseSByYW4gdmlhIGFsYXJtczsgdGhleSBub3cgdXNlXHJcbiAgLy8gc2V0SW50ZXJ2YWwgdG8gZXNjYXBlIHRoZSAzMHMgYWxhcm0gZmxvb3IuIExlYXZlIHRoZSBuYW1lcyBsaXN0ZWRcclxuICAvLyBub3doZXJlIHNvIGFueSBvcnBoYW5lZCBhbGFybXMgKGZyb20gb2xkZXIgYnVpbGRzKSBqdXN0IG5vLW9wLlxyXG59KTtcclxuXHJcbi8vIC0tLSBUb29sYmFyIGFjdGlvbjogdG9nZ2xlIHRoZSBzaWRlYmFyIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5pZiAoYnJvd3Nlci5hY3Rpb24/Lm9uQ2xpY2tlZCkge1xyXG4gIGJyb3dzZXIuYWN0aW9uLm9uQ2xpY2tlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBicm93c2VyLnNpZGViYXJBY3Rpb24udG9nZ2xlKCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgLy8gRmFsbGJhY2s6IG9wZW4gb3B0aW9ucyBpZiBzaWRlYmFyIGNhbid0IGJlIHRvZ2dsZWQuXHJcbiAgICAgIGF3YWl0IHdhcm4oJ3NpZGViYXIgdG9nZ2xlIGZhaWxlZDsgb3BlbmluZyBvcHRpb25zJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgICAgYXdhaXQgYnJvd3Nlci5ydW50aW1lLm9wZW5PcHRpb25zUGFnZSgpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG59XHJcblxyXG4vLyAtLS0gUnVudGltZSBtZXNzYWdlIGRpc3BhdGNoIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24sIHNlbmRlcikgPT4ge1xyXG4gIGlmICghaXNSdW50aW1lTWVzc2FnZShtc2cpKSByZXR1cm4gdW5kZWZpbmVkO1xyXG4gIHJldHVybiBoYW5kbGVNZXNzYWdlKG1zZywgc2VuZGVyKS5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICB2b2lkIGxvZ0VycignbWVzc2FnZSBoYW5kbGVyIGZhaWxlZCcsIHsgdHlwZTogbXNnLnR5cGUsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcclxuICAgIHRocm93IGVycjtcclxuICB9KTtcclxufSk7XHJcblxyXG5mdW5jdGlvbiBpc1J1bnRpbWVNZXNzYWdlKG06IHVua25vd24pOiBtIGlzIFJ1bnRpbWVNZXNzYWdlIHtcclxuICByZXR1cm4gISFtICYmIHR5cGVvZiBtID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgKG0gYXMgeyB0eXBlPzogdW5rbm93biB9KS50eXBlID09PSAnc3RyaW5nJztcclxufVxyXG5cclxuLyoqIE1lc3NhZ2VzIHRoYXQgZHJpdmUgdGhlIGNhcHR1cmUgcGlwZWxpbmUuIFdoZW4gdGhlIG1hc3RlciBzd2l0Y2ggaXMgT0ZGXHJcbiAqIHdlIGlnbm9yZSB0aGVzZSBidXQgc3RpbGwgcmVzcG9uZCB0byBzdGF0dXMgLyBjb25maWd1cmF0aW9uIHF1ZXJpZXMuICovXHJcbmNvbnN0IENBUFRVUkVfUElQRUxJTkVfTUVTU0FHRVMgPSBuZXcgU2V0PFJ1bnRpbWVNZXNzYWdlWyd0eXBlJ10+KFtcclxuICAnZ3JhcGhxbC1jYXB0dXJlJyxcclxuICAnY2FwdHVyZS1ub3cnLFxyXG4gICdjYXB0dXJlLWFsbCcsXHJcbiAgJ2NhcHR1cmUtdGhpcy1wYWdlJyxcclxuICAnZmx1c2gtYWxsJyxcclxuICAnZmx1c2gtaGFuZGxlJyxcclxuICAnc3RhcnQtcmVmZXRjaCcsXHJcbiAgJ3N0YXJ0LW1lZGlhLWNyYXdsJyxcclxuICAnc3RhcnQtdGhyZWFkLW9wZW4nLFxyXG4gICdzdGFydC1hdXRvLXNjcm9sbCcsXHJcbl0pO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gaXNFbmFibGVkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xyXG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIHJldHVybiBzLmVuYWJsZWQgIT09IGZhbHNlO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVNZXNzYWdlKFxyXG4gIG1zZzogUnVudGltZU1lc3NhZ2UsXHJcbiAgc2VuZGVyPzogYnJvd3Nlci5ydW50aW1lLk1lc3NhZ2VTZW5kZXJcclxuKTogUHJvbWlzZTx1bmtub3duPiB7XHJcbiAgLy8gTWFzdGVyIHN3aXRjaDogd2hlbiB0aGUgdXNlciBoYXMgcGF1c2VkIHRoZSBleHRlbnNpb24gd2Ugc3RpbGwgbmVlZFxyXG4gIC8vIHRoZSBtZXRhLWNoYW5uZWxzIChnZXQtc3RhdGUsIHRvZ2dsZS1lbmFibGVkLCBvcGVuLW9wdGlvbnMsIFx1MjAyNikgc28gdGhlXHJcbiAgLy8gc2lkZWJhciBzdGF5cyBmdW5jdGlvbmFsLCBidXQgYW55dGhpbmcgdGhhdCB3b3VsZCBhY3R1YWxseSBjYXB0dXJlLFxyXG4gIC8vIGNvbW1pdCwgb3IgZHJpdmUgYSB0YWIgaXMgYSBuby1vcC5cclxuICBpZiAoIShhd2FpdCBpc0VuYWJsZWQoKSkgJiYgQ0FQVFVSRV9QSVBFTElORV9NRVNTQUdFUy5oYXMobXNnLnR5cGUpKSB7XHJcbiAgICByZXR1cm4geyBvazogdHJ1ZSwgcGF1c2VkOiB0cnVlIH07XHJcbiAgfVxyXG4gIHN3aXRjaCAobXNnLnR5cGUpIHtcclxuICAgIGNhc2UgJ2dyYXBocWwtY2FwdHVyZSc6XHJcbiAgICAgIGF3YWl0IG9uR3JhcGhxbENhcHR1cmUoXHJcbiAgICAgICAgbXNnLmVuZHBvaW50LFxyXG4gICAgICAgIG1zZy51cmwsXHJcbiAgICAgICAgbXNnLnBhZ2VVcmwgPz8gbnVsbCxcclxuICAgICAgICBtc2cucmVzcG9uc2UsXHJcbiAgICAgICAgc2VuZGVyPy50YWI/LmlkID8/IG51bGxcclxuICAgICAgKTtcclxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgIGNhc2UgJ2NvbnRlbnQtYWxpdmUnOlxyXG4gICAgICBhd2FpdCBpbmZvKCdjb250ZW50IHNjcmlwdCBhbGl2ZSBvbiBwYWdlJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdwYWdlLWhvb2stYWN0aXZlJzpcclxuICAgICAgYXdhaXQgaW5mbygncGFnZSBob29rIHBhdGNoZWQgZmV0Y2gvWEhSJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdsb2ctY29udGVudC1ldmVudCc6XHJcbiAgICAgIGlmIChtc2cubGV2ZWwgPT09ICd3YXJuJykge1xyXG4gICAgICAgIGF3YWl0IHdhcm4obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAobXNnLmxldmVsID09PSAnZXJyb3InKSB7XHJcbiAgICAgICAgYXdhaXQgbG9nRXJyKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGF3YWl0IGluZm8obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgIGNhc2UgJ2dldC11bmZvbGQtdGFyZ2V0cyc6IHtcclxuICAgICAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gICAgICBpZiAoc2V0dGluZ3MuZW5hYmxlZCA9PT0gZmFsc2UpIHtcclxuICAgICAgICByZXR1cm4geyBlbmFibGVkOiBmYWxzZSwgY29yZUhhbmRsZXM6IFtdLCByZWxldmFudFR3ZWV0SWRzOiBbXSB9O1xyXG4gICAgICB9XHJcbiAgICAgIHBydW5lU2hvd01vcmVSZWxldmFuY2UoKTtcclxuICAgICAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gICAgICBjb25zdCBjb3JlSGFuZGxlcyA9IGFjY291bnRzXHJcbiAgICAgICAgLmZpbHRlcigoYSkgPT4gYS5jYXRlZ29yeSA9PT0gJ2NvcmUnKVxyXG4gICAgICAgIC5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICBjb25zdCB0YWJJZCA9IHNlbmRlcj8udGFiPy5pZCA/PyBudWxsO1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgY29yZUhhbmRsZXMsXHJcbiAgICAgICAgcmVsZXZhbnRUd2VldElkczpcclxuICAgICAgICAgIHRhYklkID09PSBudWxsID8gW10gOiBBcnJheS5mcm9tKHNob3dNb3JlUmVsZXZhbnRUd2VldHNCeVRhYi5nZXQodGFiSWQpPy50d2VldElkcyA/PyBbXSksXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICBjYXNlICdzaG93LW1vcmUtdW5mb2xkZWQnOiB7XHJcbiAgICAgIGlmIChtc2cuY291bnQgPiAwKSB7XHJcbiAgICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICAgICAgICBpZiAoYXNTZXNzICE9PSBudWxsKSB7XHJcbiAgICAgICAgICBhc1Nlc3MuZXhwYW5kZWRDb3VudCArPSBtc2cuY291bnQ7XHJcbiAgICAgICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihhc1Nlc3MpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xyXG4gICAgfVxyXG4gICAgY2FzZSAnZ2V0LXN0YXRlJzpcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NhcHR1cmUtbm93JzpcclxuICAgICAgYXdhaXQgY2FwdHVyZU5vdyhtc2cuaGFuZGxlKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NhcHR1cmUtYWxsJzpcclxuICAgICAgYXdhaXQgY2FwdHVyZUFsbCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2FwdHVyZS10aGlzLXBhZ2UnOlxyXG4gICAgICBhd2FpdCBjYXB0dXJlVGhpc1BhZ2UoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2ZsdXNoLWFsbCc6XHJcbiAgICAgIGF3YWl0IGZsdXNoQWxsKCd1c2VyJyk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdmbHVzaC1oYW5kbGUnOlxyXG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShtc2cuaGFuZGxlLCAndXNlcicpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAndG9nZ2xlLWF1dG8tY2FwdHVyZSc6XHJcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b0NhcHR1cmU6IG1zZy5vbiB9KTtcclxuICAgICAgYXdhaXQgaW5mbygnYXV0by1jYXB0dXJlIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICd0b2dnbGUtdXBkYXRlLWV4aXN0aW5nJzpcclxuICAgICAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyB1cGRhdGVFeGlzdGluZzogbXNnLm9uIH0pO1xyXG4gICAgICBhd2FpdCBpbmZvKCd1cGRhdGUtZXhpc3RpbmcgdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3RvZ2dsZS1lbmFibGVkJzoge1xyXG4gICAgICBjb25zdCBzID0gYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBlbmFibGVkOiBtc2cub24gfSk7XHJcbiAgICAgIGlmICghbXNnLm9uKSB7XHJcbiAgICAgICAgLy8gUGF1c2luZyBzdG9wcyBhbGwgaW4tZmxpZ2h0IGxvb3BzIHNvIHRoZSB1c2VyIGdldHMgaW1tZWRpYXRlXHJcbiAgICAgICAgLy8gcXVpZXQsIG5vdCBhIFwib25lIG1vcmUgdGlja1wiIHN1cnByaXNlLlxyXG4gICAgICAgIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XHJcbiAgICAgICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xyXG4gICAgICAgIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTtcclxuICAgICAgICBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk7XHJcbiAgICAgICAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxyXG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7XHJcbiAgICAgICAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3RocmVhZC1vcGVuLXRpY2snKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICAvLyBSZXN1bWluZyByZS1hcm1zIGFueSBsb29wcyB3aG9zZSBzZXNzaW9uIGlzIHN0aWxsIHNldC5cclxuICAgICAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICAgICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcclxuICAgICAgfVxyXG4gICAgICBhd2FpdCBpbmZvKCdleHRlbnNpb24gbWFzdGVyIHN3aXRjaCB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgfVxyXG4gICAgY2FzZSAnc3RhcnQtYXV0by1zY3JvbGwnOlxyXG4gICAgICBhd2FpdCBzdGFydEF1dG9TY3JvbGxMb29wKCk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdjYW5jZWwtYXV0by1zY3JvbGwnOlxyXG4gICAgICBhd2FpdCBjYW5jZWxBdXRvU2Nyb2xsTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnc2V0LWF1dG8tc2Nyb2xsLWludGVydmFsJzoge1xyXG4gICAgICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXHJcbiAgICAgICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcclxuICAgICAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKG1zZy5zZWNvbmRzKSlcclxuICAgICAgKTtcclxuICAgICAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IHNlY29uZHMgfSk7XHJcbiAgICAgIC8vIFJlLWFybSBhbnkgYWN0aXZlIGxvb3BzIHdpdGggdGhlIG5ldyBpbnRlcnZhbC5cclxuICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgICAgIGlmIChzZXNzICE9PSBudWxsKSBhcm1BdXRvU2Nyb2xsVGltZXIoc2Vjb25kcyk7XHJcbiAgICAgIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHMpO1xyXG4gICAgICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzKTtcclxuICAgICAgaWYgKHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgc3RhcnRUaHJlYWRPcGVuSW50ZXJ2YWwoc2Vjb25kcyk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICB9XHJcbiAgICBjYXNlICdzdGFydC1yZWZldGNoJzpcclxuICAgICAgYXdhaXQgc3RhcnRSZWZldGNoTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2FuY2VsLXJlZmV0Y2gnOlxyXG4gICAgICBhd2FpdCBjYW5jZWxSZWZldGNoTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnc3RhcnQtbWVkaWEtY3Jhd2wnOlxyXG4gICAgICBhd2FpdCBzdGFydE1lZGlhQ3Jhd2xMb29wKCk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdjYW5jZWwtbWVkaWEtY3Jhd2wnOlxyXG4gICAgICBhd2FpdCBjYW5jZWxNZWRpYUNyYXdsTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnc3RhcnQtdGhyZWFkLW9wZW4nOlxyXG4gICAgICBhd2FpdCBzdGFydFRocmVhZE9wZW5Mb29wKCk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdjYW5jZWwtdGhyZWFkLW9wZW4nOlxyXG4gICAgICBhd2FpdCBjYW5jZWxUaHJlYWRPcGVuTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAncHVyZ2UtdW5yZWxhdGVkJzoge1xyXG4gICAgICBjb25zdCBhY2NzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcclxuICAgICAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjcy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcclxuICAgICAgY29uc3Qgc3VtbWFyeSA9IGF3YWl0IHB1cmdlVW5yZWxhdGVkU3RhdGUodHJhY2tlZCk7XHJcbiAgICAgIGF3YWl0IGluZm8oJ3B1cmdlZCB1bnJlbGF0ZWQgc3RhdGUnLCBzdW1tYXJ5KTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIH1cclxuICAgIGNhc2UgJ3JlZnJlc2gtYWNjb3VudHMnOlxyXG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KHRydWUpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAndmVyaWZ5LWNvbm5lY3Rpb24nOlxyXG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKHRydWUpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2xlYXItYWN0aXZpdHknOlxyXG4gICAgICBhd2FpdCBjbGVhckFjdGl2aXR5KCk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdvcGVuLW9wdGlvbnMnOlxyXG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdvcGVuLXZpZXdlcic6IHtcclxuICAgICAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgICAgIGNvbnN0IHVybCA9IHZpZXdlclVybChzKTtcclxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCB9KTtcclxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgIH1cclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICd1bmtub3duIG1lc3NhZ2UgdHlwZScgfTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLSBDYXB0dXJlIHBpcGVsaW5lIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5hc3luYyBmdW5jdGlvbiBvbkdyYXBocWxDYXB0dXJlKFxyXG4gIGVuZHBvaW50OiBzdHJpbmcsXHJcbiAgdXJsOiBzdHJpbmcsXHJcbiAgcGFnZVVybDogc3RyaW5nIHwgbnVsbCxcclxuICByZXNwb25zZTogdW5rbm93bixcclxuICBzZW5kZXJUYWJJZDogbnVtYmVyIHwgbnVsbFxyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBpZiAoUFJPRklMRV9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuOyAvLyBub3QgdHdlZXQtYmVhcmluZ1xyXG4gIGlmICghVFdFRVRfRU5EUE9JTlRTLmhhcyhlbmRwb2ludCkpIHJldHVybjtcclxuXHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGlmIChzZXR0aW5ncy5lbmFibGVkID09PSBmYWxzZSkgcmV0dXJuO1xyXG4gIGlmIChzZXR0aW5ncy5hdXRvQ2FwdHVyZSA9PT0gZmFsc2UpIHtcclxuICAgIGNvbnN0IGV4cGxpY2l0Q2FwdHVyZUFjdGl2ZSA9XHJcbiAgICAgIERhdGUubm93KCkgPCBtYW51YWxDYXB0dXJlVW50aWxNcyB8fFxyXG4gICAgICAoYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKSkgIT09IG51bGwgfHxcclxuICAgICAgKGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCkpICE9PSBudWxsIHx8XHJcbiAgICAgIChhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpKSAhPT0gbnVsbDtcclxuICAgIGlmICghZXhwbGljaXRDYXB0dXJlQWN0aXZlKSByZXR1cm47XHJcbiAgfVxyXG5cclxuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XHJcbiAgLy8gV2UgZGVsaWJlcmF0ZWx5IGRvIE5PVCBzaG9ydC1jaXJjdWl0IHdoZW4gdGhlIFBBVCBpcyBtaXNzaW5nLiBUaGVcclxuICAvLyBub3JtYWxpemUgc3RlcCBpcyBjaGVhcCwgdGhlIGJ1ZmZlciBzdXJ2aXZlcyBzZXJ2aWNlLXdvcmtlciBldmljdGlvbixcclxuICAvLyBhbmQgb25jZSB0aGUgUEFUIGlzIHNldCB0aGUgbmV4dCBhbGFybSBvciB1c2VyLXRyaWdnZXJlZCBmbHVzaCBjb21taXRzXHJcbiAgLy8gZXZlcnl0aGluZyB3ZSd2ZSBzZWVuLiBEcm9wcGluZyBjYXB0dXJlcyBoZXJlIHdhcyBoaWRpbmcgdGhlIHVzZXInc1xyXG4gIC8vIGZpcnN0IGJyb3dzaW5nIHNlc3Npb24gZW50aXJlbHkuXHJcblxyXG4gIC8vIFR3by1zdGFnZSBmaWx0ZXI6XHJcbiAgLy8gICAxLiBCdWlsZCBFVkVSWSBjYW5vbmljYWwgdHdlZXQgd2UgY2FuIGZpbmQgaW4gdGhlIHJlc3BvbnNlIChubyBoYW5kbGVcclxuICAvLyAgICAgIGZpbHRlciBhdCB0aGUgbm9ybWFsaXplciBsZXZlbCBcdTIwMTQgd2Ugc3RpbGwgd2FudCBxdW90ZWQvUlQnZCBwYXJlbnRzXHJcbiAgLy8gICAgICB0aGF0IGFwcGVhciBhcyBzaWJsaW5nIG5vZGVzKS5cclxuICAvLyAgIDIuIEFwcGx5IGBmaWx0ZXJSZWxhdGVkYCBwb3N0LWhvYyB0byBkcm9wIGFueXRoaW5nIHRoYXQgaGFzIG5vXHJcbiAgLy8gICAgICByZWxhdGlvbnNoaXAgdG8gYSB0cmFja2VkIGFjY291bnQuIFRoZSBvbGQgYmVoYXZpb3VyIChcImVtcHR5XHJcbiAgLy8gICAgICBhbGxvd2VkLXNldCBvbiB1c2VyLXBhZ2UgZW5kcG9pbnRzLCBmdWxsIGZpbHRlciBvbiBob21lL3NlYXJjaFwiKVxyXG4gIC8vICAgICAgd2FzIHdheSB0b28gcGVybWlzc2l2ZSBvbiB0aGUgUmVwbGllcyB0YWI6IGV2ZXJ5IHJhbmRvbSByZXBsaWVyJ3NcclxuICAvLyAgICAgIHJlcGx5IGxhbmRlZCBpbiBhIHBlci1oYW5kbGUgYnVmZmVyIGtleWVkIGJ5IHRoZWlyIG93biBoYW5kbGUuXHJcbiAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjb3VudHMubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKSk7XHJcbiAgY29uc3QgY29yZSA9IG5ldyBTZXQoXHJcbiAgICBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuY2F0ZWdvcnkgPT09ICdjb3JlJykubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKVxyXG4gICk7XHJcbiAgY29uc3QgY2FwdHVyZWRBdCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxuXHJcbiAgbGV0IG5vcm1hbGl6ZWQ7XHJcbiAgdHJ5IHtcclxuICAgIG5vcm1hbGl6ZWQgPSBub3JtYWxpemUocmVzcG9uc2UsIHtcclxuICAgICAgY2FwdHVyZWRBdCxcclxuICAgICAgcnVuSWQ6ICdwZW5kaW5nJyxcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIGFsbG93ZWRIYW5kbGVzOiBuZXcgU2V0PHN0cmluZz4oKSxcclxuICAgICAgc291cmNlVXJsOiBwYWdlVXJsLFxyXG4gICAgfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCBxdWFyYW50aW5lKCdub3JtYWxpemUtdGhyZXcnLCBlbmRwb2ludCwgdXJsLCByZXNwb25zZSwgZXJyKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgY29uc3QgcmV0d2VldEVkZ2VzID0gYnVpbGRSZXR3ZWV0RWRnZXMoXHJcbiAgICBub3JtYWxpemVkLnR3ZWV0cyxcclxuICAgIGFjY291bnRzLFxyXG4gICAgY2FwdHVyZWRBdCxcclxuICAgIGVuZHBvaW50LFxyXG4gICAgcGFnZVVybCA/PyB1cmxcclxuICApO1xyXG4gIC8vIERyb3AgdW5yZWxhdGVkIHR3ZWV0cy4gVGhlIGZpbHRlciBpcyBlbmRwb2ludC1hd2FyZTpcclxuICAvLyAgIC0gT24gdGhlIGhvbWUgLyBzZWFyY2ggdGltZWxpbmVzIHdlJ2QgYWxyZWFkeSBiZWVuIGZpbHRlcmluZyB0b1xyXG4gIC8vICAgICB0cmFja2VkIGF1dGhvcnMgb25seSBcdTIwMTQga2VlcCB0aGF0IGJlaGF2aW91ciBidXQgZ28gdGhyb3VnaCB0aGUgc2FtZVxyXG4gIC8vICAgICBgZmlsdGVyUmVsYXRlZGAgaGVscGVyIHNvIHRoZSBydWxlcyBhcmUgdW5pZm9ybS5cclxuICAvLyAgIC0gT24gdXNlci1wYWdlIGVuZHBvaW50cyB3ZSBub3cgYWxzbyBkcm9wIGFueXRoaW5nIHRoYXQgaXNuJ3QgZWl0aGVyXHJcbiAgLy8gICAgIGF1dGhvcmVkLWJ5LCBtZW50aW9uaW5nLCByZXBseWluZy10bywgb3IgcmVmZXJlbmNlZC1ieSBhIHRyYWNrZWRcclxuICAvLyAgICAgYWNjb3VudC5cclxuICBjb25zdCBiZWZvcmVGaWx0ZXIgPSBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGg7XHJcbiAgbm9ybWFsaXplZC50d2VldHMgPSBmaWx0ZXJSZWxhdGVkKG5vcm1hbGl6ZWQudHdlZXRzLCB0cmFja2VkLCBjb3JlKTtcclxuICBjb25zdCBkcm9wcGVkVW5yZWxhdGVkID0gYmVmb3JlRmlsdGVyIC0gbm9ybWFsaXplZC50d2VldHMubGVuZ3RoO1xyXG4gIGlmIChkcm9wcGVkVW5yZWxhdGVkID4gMCkge1xyXG4gICAgYXdhaXQgaW5mbygnZHJvcHBlZCB1bnJlbGF0ZWQgdHdlZXRzJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgZHJvcHBlZDogZHJvcHBlZFVucmVsYXRlZCxcclxuICAgICAga2VwdDogbm9ybWFsaXplZC50d2VldHMubGVuZ3RoLFxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHJlbWVtYmVyU2hvd01vcmVSZWxldmFudFR3ZWV0cyhzZW5kZXJUYWJJZCwgcGFnZVVybCwgbm9ybWFsaXplZC50d2VldHMsIGNvcmUpO1xyXG5cclxuICAvLyBEaWFnbm9zdGljOiBldmVyeSB0d2VldC1lbmRwb2ludCBwYXlsb2FkIGdldHMgYSBsaW5lIGluIHRoZSBhY3Rpdml0eVxyXG4gIC8vIHRhaWwgd2l0aCB3aGF0IHdlIHNhdyB2cyBrZXB0LiBXaGVuIG9ic2VydmVkPTAgd2UgYWxzbyBlbWl0IGEgc2hhcGVcclxuICAvLyBwcm9iZSAoa2V5IHBhdGhzICsgdHlwZW5hbWVzKSBzbyB3ZSBjYW4gdGVsbCB3aGV0aGVyIFggcmV0dXJuZWQgYW5cclxuICAvLyBlbXB0eSBlbnZlbG9wZSwgYSBsb2dpbi13YWxsIHJlc3BvbnNlLCBvciBhIG5ldyBzaGFwZSB3ZSBkb24ndCBrbm93IGhvd1xyXG4gIC8vIHRvIHdhbGsgeWV0LlxyXG4gIGlmIChub3JtYWxpemVkLm9ic2VydmVkX2lkcy5sZW5ndGggPT09IDApIHtcclxuICAgIGF3YWl0IGluZm8oJ2dyYXBocWwgcGF5bG9hZCBlbXB0eSBcdTIwMTQgc2hhcGUgcHJvYmUnLCB7XHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICB0eXBlbmFtZXM6IHByb2JlVHlwZW5hbWVzKHJlc3BvbnNlKS5zbGljZSgwLCAzMCksXHJcbiAgICAgIHR3ZWV0X2tleXM6IHByb2JlRmlyc3RUeXBlU2hhcGUocmVzcG9uc2UsICdUd2VldCcpLFxyXG4gICAgICB0d2VldF9jb3JlX2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFsnY29yZSddKSxcclxuICAgICAgdHdlZXRfbGVnYWN5X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFsnbGVnYWN5J10pLFxyXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcclxuICAgICAgICAnY29yZScsXHJcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXHJcbiAgICAgICAgJ3Jlc3VsdCcsXHJcbiAgICAgIF0pLFxyXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2NvcmVfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xyXG4gICAgICAgICdjb3JlJyxcclxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcclxuICAgICAgICAncmVzdWx0JyxcclxuICAgICAgICAnY29yZScsXHJcbiAgICAgIF0pLFxyXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2xlZ2FjeV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXHJcbiAgICAgICAgJ2NvcmUnLFxyXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxyXG4gICAgICAgICdyZXN1bHQnLFxyXG4gICAgICAgICdsZWdhY3knLFxyXG4gICAgICBdKSxcclxuICAgIH0pO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBhd2FpdCBpbmZvKCdncmFwaHFsIHBheWxvYWQgc2VlbicsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIG9ic2VydmVkOiBub3JtYWxpemVkLm9ic2VydmVkX2lkcy5sZW5ndGgsXHJcbiAgICAgIGtlcHQ6IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCxcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgaWYgKG5vcm1hbGl6ZWQudW5hdmFpbGFibGVfdHdlZXRzLmxlbmd0aCA+IDApIHtcclxuICAgIGF3YWl0IHJlY29yZFVuYXZhaWxhYmxlVHdlZXRzKFxyXG4gICAgICBub3JtYWxpemVkLnVuYXZhaWxhYmxlX3R3ZWV0cyxcclxuICAgICAgdHJhY2tlZCxcclxuICAgICAgY2FwdHVyZWRBdCxcclxuICAgICAgdXJsLFxyXG4gICAgICBlbmRwb2ludFxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmIChub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGggPT09IDApIHtcclxuICAgIGNvbnN0IGJ1ZmZlcmVkRWRnZXMgPSBhd2FpdCBidWZmZXJSZXR3ZWV0RWRnZXMocmV0d2VldEVkZ2VzLCBjYXB0dXJlZEF0LCBwYWdlVXJsID8/IHVybCwgZW5kcG9pbnQpO1xyXG4gICAgaWYgKGJ1ZmZlcmVkRWRnZXMgPiAwKSBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgLy8gUmVmZXRjaCBxdWV1ZSBob3VzZWtlZXBpbmcgXHUyMDE0IHJ1bnMgQkVGT1JFIHRoZSBkZWR1cCBzaG9ydC1jaXJjdWl0LiBBXHJcbiAgLy8gcmVmZXRjaCBjYXB0dXJlIGNvbWVzIGJhY2sgd2l0aCB0aGUgc2FtZSBlbmdhZ2VtZW50IGNvdW50cyAod2UncmVcclxuICAvLyBvbmx5IGFmdGVyIHRoZSBmdWxsIHRleHQpLCBzbyB0aGUgZGVkdXAgYmVsb3cgd291bGQgc2lsZW50bHkgZHJvcFxyXG4gIC8vIGl0IGFuZCB0aGUgcXVldWUgd291bGQgbmV2ZXIgZHJhaW4uIEhvaXN0IHRoZSBlbnF1ZXVlL2RlcXVldWUgaGVyZVxyXG4gIC8vIHNvIHRoZSBsb29wIHJlbGlhYmx5IGFkdmFuY2VzIGV2ZW4gd2hlbiBubyBjb21taXQgaGFwcGVucy5cclxuICAvL1xyXG4gIC8vIEFsc286IGlmIGVpdGhlciBsb29wJ3MgaW5mbGlnaHQgdGFyZ2V0IGFwcGVhcnMgaGVyZSwgbWFyayB0aGUgbG9vcFxyXG4gIC8vIGFzIFwiaW5nZXN0ZWRcIiBzbyB0aGUgbmV4dCB0aWNrIGNhbiBhZHZhbmNlLiBUaGUgd2FpdC1mb3ItaW5nZXN0XHJcbiAgLy8gZ3VhcmQgb3RoZXJ3aXNlIGJsb2NrcyB1bnRpbCB0aGUgbmF2aWdhdGlvbi10aW1lb3V0IGZpcmVzLlxyXG4gIGNvbnN0IHJlZmV0Y2hTZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcclxuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XHJcbiAgY29uc3QgdGhyZWFkT3BlblNlc3MgPSBhd2FpdCBnZXRUaHJlYWRPcGVuU2Vzc2lvbigpO1xyXG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xyXG4gICAgaWYgKHQuaXNfdHJ1bmNhdGVkKSB7XHJcbiAgICAgIGF3YWl0IGVucXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2godC5hY2NvdW50X2hhbmRsZSwgdC50d2VldF9pZCk7XHJcbiAgICB9XHJcbiAgICAvLyBTdWNjZXNzZnVsbHkgYnVpbHQgdHdlZXRzIGFyZSBubyBsb25nZXIgXCJwYXJ0aWFsXCIgXHUyMDE0IGRyb3AgZnJvbSB0aGVcclxuICAgIC8vIG1lZGlhLWNyYXdsIHF1ZXVlIHJlZ2FyZGxlc3Mgb2Ygd2hpY2ggaGFuZGxlIHdlJ2QgaGludGVkIGVhcmxpZXIuXHJcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0LnR3ZWV0X2lkKTtcclxuICAgIGlmIChyZWZldGNoU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcclxuICAgICAgcmVmZXRjaFNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgICByZWZldGNoU2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24ocmVmZXRjaFNlc3MpO1xyXG4gICAgfVxyXG4gICAgaWYgKG1lZGlhQ3Jhd2xTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdC50d2VldF9pZCkge1xyXG4gICAgICBtZWRpYUNyYXdsU2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihtZWRpYUNyYXdsU2Vzcyk7XHJcbiAgICB9XHJcbiAgICBpZiAodGhyZWFkT3BlblNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XHJcbiAgICAgIHRocmVhZE9wZW5TZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgICAgdGhyZWFkT3BlblNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICAgIGF3YWl0IG1hcmtUaHJlYWRPcGVuU2Vlbih0LnR3ZWV0X2lkKTtcclxuICAgICAgYXdhaXQgZGVxdWV1ZVRocmVhZE9wZW4odC50d2VldF9pZCk7XHJcbiAgICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHRocmVhZE9wZW5TZXNzKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiB0d2VldC1zaGFwZWQgbm9kZXMgdGhlIHdhbGtlciBzYXcgYnV0IGNvdWxkbid0IHR1cm5cclxuICAvLyBpbnRvIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIEVucXVldWUgb25seSBJRHMgd2UgaGF2ZW4ndCBhbHJlYWR5XHJcbiAgLy8gY29tbWl0dGVkICh1c2VyLXJlcXVlc3RlZCBkZWR1cCBhZ2FpbnN0IHRoZSBhcmNoaXZlKS5cclxuICBmb3IgKGNvbnN0IHBhcnRpYWwgb2Ygbm9ybWFsaXplZC5wYXJ0aWFsX2lkcykge1xyXG4gICAgaWYgKGF3YWl0IGlzQ29tbWl0dGVkKHBhcnRpYWwudHdlZXRfaWQpKSBjb250aW51ZTtcclxuICAgIGF3YWl0IGVucXVldWVNZWRpYUNyYXdsKHBhcnRpYWwuaGludF9oYW5kbGUsIHBhcnRpYWwudHdlZXRfaWQpO1xyXG4gIH1cclxuICBpZiAobm9ybWFsaXplZC5wYXJ0aWFsX2lkcy5sZW5ndGggPiAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogZW5xdWV1ZWQgcGFydGlhbCBjYXB0dXJlcycsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIHBhcnRpYWw6IG5vcm1hbGl6ZWQucGFydGlhbF9pZHMubGVuZ3RoLFxyXG4gICAgICBxdWV1ZV90b3RhbDogYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKSxcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLy8gQ3Jvc3Mtc2Vzc2lvbiBkZWR1cDogZHJvcCB0d2VldHMgd2UndmUgYWxyZWFkeSBjb21taXR0ZWQgd2l0aCBpZGVudGljYWxcclxuICAvLyBlbmdhZ2VtZW50IGNvdW50cy4gTGlrZXMvUlRzL3JlcGxpZXMvcXVvdGVzIHN0aWxsIHRyaWdnZXIgYSByZWNhcHR1cmVcclxuICAvLyBzbyBlbmdhZ2VtZW50X2hpc3RvcnkgZ3Jvd3Mgb3ZlciB0aW1lLiB2aWV3X2NvdW50IGlzIGludGVudGlvbmFsbHlcclxuICAvLyBleGNsdWRlZCBcdTIwMTQgaXQgY2h1cm5zIHRvbyBmYXN0IHRvIGJlIHVzZWZ1bCBhcyBhIGZyZXNobmVzcyBzaWduYWwuXHJcbiAgLy8gYGlzX3RydW5jYXRlZGAgaXMgcGFydCBvZiB0aGUgc2lnbmF0dXJlIHNvIGEgcmVmZXRjaCB0aGF0IGZsaXBzXHJcbiAgLy8gdHJ1bmNhdGVkXHUyMTkyZnVsbCBpcyB0cmVhdGVkIGFzIGEgbWF0ZXJpYWwgY2hhbmdlIGFuZCBnZXRzIGNvbW1pdHRlZC5cclxuICAvL1xyXG4gIC8vIFdoZW4gdGhlIHVzZXIgaGFzIHR1cm5lZCBvZmYgXCJ1cGRhdGUgZXhpc3RpbmdcIiwgd2Ugc2tpcCB0aGUgZW5nYWdlbWVudFxyXG4gIC8vIGNvbXBhcmlzb24gZW50aXJlbHk6IGFueSB0d2VldCB0aGF0J3MgYWxyZWFkeSBjb21taXR0ZWQgdW5kZXIgYW55XHJcbiAgLy8gaGFuZGxlIGdldHMgZHJvcHBlZCBoZXJlLCBzbyB3ZSBkb24ndCBwYXkgR2l0SHViLUFQSSBvdmVyaGVhZCBqdXN0IHRvXHJcbiAgLy8gcmVmcmVzaCBsaWtlIC8gUlQgY291bnRzLiBOZXcgdHdlZXRzIGFuZCB0cnVuY2F0ZWRcdTIxOTJmdWxsIHJlZmV0Y2hlc1xyXG4gIC8vIHN0aWxsIGZsb3cgdGhyb3VnaCBub3JtYWxseSBiZWNhdXNlIHRoZXkgYXJlbid0IGluIHRoZSBpbmRleCB5ZXRcclxuICAvLyAob3IgY2FycnkgYW4gaXNfdHJ1bmNhdGVkIHRyYW5zaXRpb24gdGhhdCBmYWlscyB0aGUgc2lnIGNoZWNrKS5cclxuICAvLyBGdWxsLXRleHQgdXBncmFkZXMgYnlwYXNzIHRoaXMgc2tpcCBldmVuIHdpdGggdXBkYXRlRXhpc3Rpbmc9ZmFsc2UuXHJcbiAgY29uc3QgdXBkYXRlRXhpc3RpbmcgPSBzZXR0aW5ncy51cGRhdGVFeGlzdGluZyAhPT0gZmFsc2U7XHJcbiAgY29uc3QgY29tbWl0dGVkSWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBjb25zdCBhcmNoaXZlU25hcHNob3QgPSBhd2FpdCBnZXRBcmNoaXZlU25hcHNob3QoKTtcclxuICBsZXQgZGVkdXBlZFNraXBwZWQgPSAwO1xyXG4gIGxldCBza2lwcGVkTm9VcGRhdGVMb2NhbCA9IDA7XHJcbiAgbGV0IHNraXBwZWROb1VwZGF0ZVNuYXBzaG90ID0gMDtcclxuICBsZXQgb2xkRnJvbVNuYXBzaG90ID0gMDtcclxuICBsZXQgZnVsbFRleHRVcGdyYWRlcyA9IDA7XHJcbiAgY29uc3QgbGl2ZVR3ZWV0czogdHlwZW9mIG5vcm1hbGl6ZWQudHdlZXRzID0gW107XHJcbiAgY29uc3QgZnJlc2huZXNzQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCAnbmV3JyB8ICdleGlzdGluZyc+KCk7XHJcbiAgY29uc3QgYWN0aW9uQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCBUd2VldFNpZ2h0aW5nWydhY3Rpb24nXT4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2Ygbm9ybWFsaXplZC50d2VldHMpIHtcclxuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbdC5hY2NvdW50X2hhbmRsZV0/Llt0LnR3ZWV0X2lkXTtcclxuICAgIGNvbnN0IG9sZEJ5U25hcHNob3QgPSAhcHJldiAmJiBhcmNoaXZlU25hcHNob3RIYXNUd2VldCh0LCBhcmNoaXZlU25hcHNob3QpO1xyXG4gICAgY29uc3QgcHJldmlvdXNseUFyY2hpdmVkID0gQm9vbGVhbihwcmV2KSB8fCBvbGRCeVNuYXBzaG90O1xyXG4gICAgZnJlc2huZXNzQnlJZC5zZXQodC50d2VldF9pZCwgcHJldmlvdXNseUFyY2hpdmVkID8gJ2V4aXN0aW5nJyA6ICduZXcnKTtcclxuICAgIGlmIChvbGRCeVNuYXBzaG90KSBvbGRGcm9tU25hcHNob3QgKz0gMTtcclxuICAgIGNvbnN0IHNpZyA9IGVuZ2FnZW1lbnRTaWcoXHJcbiAgICAgIHQubGlrZV9jb3VudCxcclxuICAgICAgdC5yZXR3ZWV0X2NvdW50LFxyXG4gICAgICB0LnJlcGx5X2NvdW50LFxyXG4gICAgICB0LnF1b3RlX2NvdW50LFxyXG4gICAgICB0LmlzX3RydW5jYXRlZFxyXG4gICAgKTtcclxuICAgIGNvbnN0IGZ1bGxUZXh0VXBncmFkZSA9XHJcbiAgICAgIHByZXYgIT09IHVuZGVmaW5lZCAmJiBzaWdNYXJrc1RydW5jYXRlZChwcmV2LnNpZykgJiYgIXQuaXNfdHJ1bmNhdGVkO1xyXG4gICAgaWYgKHByZXZpb3VzbHlBcmNoaXZlZCAmJiAhdXBkYXRlRXhpc3RpbmcgJiYgIWZ1bGxUZXh0VXBncmFkZSkge1xyXG4gICAgICBpZiAocHJldikgc2tpcHBlZE5vVXBkYXRlTG9jYWwgKz0gMTtcclxuICAgICAgZWxzZSBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCArPSAxO1xyXG4gICAgICBhY3Rpb25CeUlkLnNldCh0LnR3ZWV0X2lkLCAnc2tpcHBlZCcpO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmIChwcmV2ICYmIHByZXYuc2lnID09PSBzaWcpIHtcclxuICAgICAgZGVkdXBlZFNraXBwZWQgKz0gMTtcclxuICAgICAgYWN0aW9uQnlJZC5zZXQodC50d2VldF9pZCwgJ3VuY2hhbmdlZCcpO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmIChmdWxsVGV4dFVwZ3JhZGUpIGZ1bGxUZXh0VXBncmFkZXMgKz0gMTtcclxuICAgIGFjdGlvbkJ5SWQuc2V0KHQudHdlZXRfaWQsICdidWZmZXJlZCcpO1xyXG4gICAgbGl2ZVR3ZWV0cy5wdXNoKHQpO1xyXG4gIH1cclxuICBpZiAoZGVkdXBlZFNraXBwZWQgPiAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdkZWR1cDogc2tpcHBlZCB1bmNoYW5nZWQgdHdlZXRzJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgc2tpcHBlZDogZGVkdXBlZFNraXBwZWQsXHJcbiAgICAgIHJlbWFpbmluZzogbGl2ZVR3ZWV0cy5sZW5ndGgsXHJcbiAgICB9KTtcclxuICB9XHJcbiAgaWYgKHNraXBwZWROb1VwZGF0ZUxvY2FsICsgc2tpcHBlZE5vVXBkYXRlU25hcHNob3QgPiAwKSB7XHJcbiAgICBjb25zdCBza2lwcGVkT2xkID0gc2tpcHBlZE5vVXBkYXRlTG9jYWwgKyBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdDtcclxuICAgIGF3YWl0IGluZm8oJ2RlZHVwOiBza2lwcGVkIHByZXZpb3VzbHkgYXJjaGl2ZWQgdHdlZXRzICh1cGRhdGVFeGlzdGluZz1mYWxzZSknLCB7XHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICBza2lwcGVkOiBza2lwcGVkT2xkLFxyXG4gICAgICBsb2NhbF9pbmRleDogc2tpcHBlZE5vVXBkYXRlTG9jYWwsXHJcbiAgICAgIGFyY2hpdmVfc25hcHNob3Q6IHNraXBwZWROb1VwZGF0ZVNuYXBzaG90LFxyXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxyXG4gICAgfSk7XHJcbiAgICBjb25zdCBhc1Nlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xyXG4gICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xyXG4gICAgICBhc1Nlc3Muc2tpcHBlZE9sZENvdW50ID0gKGFzU2Vzcy5za2lwcGVkT2xkQ291bnQgPz8gMCkgKyBza2lwcGVkT2xkO1xyXG4gICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihhc1Nlc3MpO1xyXG4gICAgfVxyXG4gIH1cclxuICBpZiAob2xkRnJvbVNuYXBzaG90ID4gMCAmJiB1cGRhdGVFeGlzdGluZykge1xyXG4gICAgYXdhaXQgaW5mbygnYXJjaGl2ZSBzbmFwc2hvdCByZWNvZ25pemVkIG9sZCB0d2VldHMnLCB7XHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICBvbGQ6IG9sZEZyb21TbmFwc2hvdCxcclxuICAgICAgYWN0aW9uOiAnYnVmZmVyaW5nIGJlY2F1c2UgdXBkYXRlRXhpc3Rpbmc9dHJ1ZScsXHJcbiAgICAgIHNuYXBzaG90X2dlbmVyYXRlZF9hdDogYXJjaGl2ZVNuYXBzaG90Py5nZW5lcmF0ZWRfYXQgPz8gbnVsbCxcclxuICAgIH0pO1xyXG4gIH1cclxuICBpZiAoZnVsbFRleHRVcGdyYWRlcyA+IDApIHtcclxuICAgIGF3YWl0IGluZm8oJ2RlZHVwOiBidWZmZXJpbmcgZnVsbC10ZXh0IHVwZ3JhZGVzJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgdXBncmFkZXM6IGZ1bGxUZXh0VXBncmFkZXMsXHJcbiAgICAgIHVwZGF0ZUV4aXN0aW5nLFxyXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGF3YWl0IHByZXBlbmRSZWNlbnRUd2VldFNpZ2h0aW5ncyhcclxuICAgIG5vcm1hbGl6ZWQudHdlZXRzLm1hcCgodCkgPT5cclxuICAgICAgYnVpbGRUd2VldFNpZ2h0aW5nKHQsIGVuZHBvaW50LCBjYXB0dXJlZEF0LCBmcmVzaG5lc3NCeUlkLmdldCh0LnR3ZWV0X2lkKSwgYWN0aW9uQnlJZC5nZXQodC50d2VldF9pZCkpXHJcbiAgICApXHJcbiAgKTtcclxuICAvLyAtLS0gTWlzc2luZy1wYXJlbnQgcmVjb3ZlcnkgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gIC8vIFgncyBVc2VyVHdlZXRzQW5kUmVwbGllcyBlbmRwb2ludCBzb21ldGltZXMgc2VydmVzIGEgcmVwbHkgd2l0aG91dCB0aGVcclxuICAvLyBwYXJlbnQgdHdlZXQgaXQgcG9pbnRzIGF0IFx1MjAxNCBvbmx5IGFuIGluX3JlcGx5X3RvX3NjcmVlbl9uYW1lIGFuY2hvci4gV2VcclxuICAvLyBuZXZlciBzZWUgdGhhdCBwYXJlbnQsIHNvIGl0IG5ldmVyIGxhbmRzIGluIHRoZSBhcmNoaXZlLiBTYW1lIGZvclxyXG4gIC8vIHF1b3RlZF90d2VldF9pZCAvIHJldHdlZXRlZF90d2VldF9pZCB3aGVuIFggc3RyaXBzIHRoZSByZWZlcmVuY2VkXHJcbiAgLy8gbm9kZS4gV2FsayB0aGUgdHdlZXRzIHdlIGp1c3Qgc2F3LCBmaW5kIGFueSBwYXJlbnQgSUQgd2UgZG9uJ3QgaGF2ZSxcclxuICAvLyBhbmQgZW5xdWV1ZSBpdCBvbiB0aGUgbWVkaWEtY3Jhd2wgbG9vcCBzbyBpdHMgZGV0YWlsIHBhZ2UgZ2V0c1xyXG4gIC8vIHZpc2l0ZWQgYW5kIGluZ2VzdGVkIG5leHQgdGltZSB0aGUgdXNlciBzdGFydHMgdGhlIGNyYXdsLlxyXG4gIGF3YWl0IGVucXVldWVNaXNzaW5nUGFyZW50cyhub3JtYWxpemVkLnR3ZWV0cywgZW5kcG9pbnQpO1xyXG4gIGF3YWl0IGVucXVldWVUaHJlYWRPcGVuQ2FuZGlkYXRlcyhub3JtYWxpemVkLnR3ZWV0cywgY29yZSwgZW5kcG9pbnQpO1xyXG4gIGNvbnN0IGJ1ZmZlcmVkUmV0d2VldEVkZ2VzID0gYXdhaXQgYnVmZmVyUmV0d2VldEVkZ2VzKFxyXG4gICAgcmV0d2VldEVkZ2VzLFxyXG4gICAgY2FwdHVyZWRBdCxcclxuICAgIHBhZ2VVcmwgPz8gdXJsLFxyXG4gICAgZW5kcG9pbnRcclxuICApO1xyXG4gIGlmIChsaXZlVHdlZXRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgaWYgKGJ1ZmZlcmVkUmV0d2VldEVkZ2VzID4gMCkgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIC8vIEdyb3VwIHN1cnZpdmluZyB0d2VldHMgYnkgYXV0aG9yIGhhbmRsZS5cclxuICBjb25zdCBieUhhbmRsZSA9IG5ldyBNYXA8c3RyaW5nLCBDYW5vbmljYWxUd2VldFtdPigpO1xyXG4gIGZvciAoY29uc3QgdCBvZiBsaXZlVHdlZXRzKSB7XHJcbiAgICBjb25zdCBhcnIgPSBieUhhbmRsZS5nZXQodC5hY2NvdW50X2hhbmRsZSkgPz8gW107XHJcbiAgICBhcnIucHVzaCh0KTtcclxuICAgIGJ5SGFuZGxlLnNldCh0LmFjY291bnRfaGFuZGxlLCBhcnIpO1xyXG4gIH1cclxuXHJcbiAgZm9yIChjb25zdCBbaGFuZGxlLCB0d2VldHNdIG9mIGJ5SGFuZGxlKSB7XHJcbiAgICBjb25zdCBidWYgPSBhd2FpdCBlbnN1cmVSdW5CdWZmZXIoaGFuZGxlLCBjYXB0dXJlZEF0LCB1cmwsIGVuZHBvaW50KTtcclxuICAgIGxldCBhZGRlZCA9IDA7XHJcbiAgICBsZXQgYWRkZWROZXcgPSAwO1xyXG4gICAgbGV0IGFkZGVkRXhpc3RpbmcgPSAwO1xyXG4gICAgbGV0IHVwZGF0ZWRCdWZmZXJlZCA9IDA7XHJcbiAgICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XHJcbiAgICAgIGNvbnN0IGV4aXN0aW5nID0gYnVmLnR3ZWV0c19ieV9pZFt0LnR3ZWV0X2lkXTtcclxuICAgICAgaWYgKGV4aXN0aW5nKSB7XHJcbiAgICAgICAgLy8gUHJlc2VydmUgZmlyc3RfY2FwdHVyZWRfYXQsIGFwcGVuZCBlbmdhZ2VtZW50IHNuYXBzaG90LCByZWZyZXNoXHJcbiAgICAgICAgLy8gbGFzdF9zZWVuX2F0ICsgY291bnRzICh0aGUgbGF0ZXN0IHNjcmFwZSB3aW5zIGZvciBjb3VudHMpLlxyXG4gICAgICAgIGV4aXN0aW5nLmxhc3Rfc2Vlbl9hdCA9IGNhcHR1cmVkQXQ7XHJcbiAgICAgICAgZXhpc3RpbmcubGlrZV9jb3VudCA9IHQubGlrZV9jb3VudDtcclxuICAgICAgICBleGlzdGluZy5yZXR3ZWV0X2NvdW50ID0gdC5yZXR3ZWV0X2NvdW50O1xyXG4gICAgICAgIGV4aXN0aW5nLnJlcGx5X2NvdW50ID0gdC5yZXBseV9jb3VudDtcclxuICAgICAgICBleGlzdGluZy5xdW90ZV9jb3VudCA9IHQucXVvdGVfY291bnQ7XHJcbiAgICAgICAgZXhpc3Rpbmcudmlld19jb3VudCA9IHQudmlld19jb3VudDtcclxuICAgICAgICBleGlzdGluZy5ib29rbWFya19jb3VudCA9IHQuYm9va21hcmtfY291bnQ7XHJcbiAgICAgICAgY29uc3QgbGFzdCA9IGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeVtleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnkubGVuZ3RoIC0gMV07XHJcbiAgICAgICAgY29uc3Qgc25hcCA9IHQuZW5nYWdlbWVudF9oaXN0b3J5WzBdO1xyXG4gICAgICAgIGlmIChzbmFwICYmICghbGFzdCB8fCBsYXN0LmNhcHR1cmVkX2F0ICE9PSBzbmFwLmNhcHR1cmVkX2F0KSkge1xyXG4gICAgICAgICAgZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5LnB1c2goc25hcCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHVwZGF0ZWRCdWZmZXJlZCArPSAxO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnN0IHN0YW1wZWQ6IENhbm9uaWNhbFR3ZWV0ID0geyAuLi50LCBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCB9O1xyXG4gICAgICAgIGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF0gPSBzdGFtcGVkO1xyXG4gICAgICAgIGFkZGVkICs9IDE7XHJcbiAgICAgICAgaWYgKGZyZXNobmVzc0J5SWQuZ2V0KHQudHdlZXRfaWQpID09PSAnZXhpc3RpbmcnKSBhZGRlZEV4aXN0aW5nICs9IDE7XHJcbiAgICAgICAgZWxzZSBhZGRlZE5ldyArPSAxO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyh0LnR3ZWV0X2lkKSkge1xyXG4gICAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKCFidWYuZW5kcG9pbnRzX3NlZW4uaW5jbHVkZXMoZW5kcG9pbnQpKSBidWYuZW5kcG9pbnRzX3NlZW4ucHVzaChlbmRwb2ludCk7XHJcbiAgICBidWYubGFzdF9jYXB0dXJlX2F0ID0gY2FwdHVyZWRBdDtcclxuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XHJcbiAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgcnVuQnVmZmVySXRlbUNvdW50KGJ1ZikpO1xyXG4gICAgaWYgKGFkZGVkID4gMCB8fCB1cGRhdGVkQnVmZmVyZWQgPiAwKSB7XHJcbiAgICAgIGF3YWl0IGluZm8oJ2J1ZmZlcmVkIHR3ZWV0cycsIHtcclxuICAgICAgICBoYW5kbGUsXHJcbiAgICAgICAgZW5kcG9pbnQsXHJcbiAgICAgICAgYWRkZWQsXHJcbiAgICAgICAgbmV3OiBhZGRlZE5ldyxcclxuICAgICAgICBleGlzdGluZzogYWRkZWRFeGlzdGluZyxcclxuICAgICAgICB1cGRhdGVkX2J1ZmZlcmVkOiB1cGRhdGVkQnVmZmVyZWQsXHJcbiAgICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCxcclxuICAgICAgfSk7XHJcbiAgICAgIC8vIEJ1bXAgdGhlIGF1dG8tc2Nyb2xsIHByb2dyZXNzIHNvIHRoZSB1c2VyIHNlZXMgXCJYIGluZ2VzdGVkXCIgdGljayB1cFxyXG4gICAgICAvLyBpbiByZWFsIHRpbWUuIFdlIGNvdW50IGFjdHVhbGx5LW5ldyB0d2VldHMsIG5vdCBkdXBsaWNhdGVzLlxyXG4gICAgICBjb25zdCBhc1Nlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xyXG4gICAgICBpZiAoYXNTZXNzICE9PSBudWxsKSB7XHJcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkQ291bnQgKz0gYWRkZWQ7XHJcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkTmV3Q291bnQgPSAoYXNTZXNzLmluZ2VzdGVkTmV3Q291bnQgPz8gMCkgKyBhZGRlZE5ldztcclxuICAgICAgICBhc1Nlc3MuaW5nZXN0ZWRFeGlzdGluZ0NvdW50ID1cclxuICAgICAgICAgIChhc1Nlc3MuaW5nZXN0ZWRFeGlzdGluZ0NvdW50ID8/IDApICsgYWRkZWRFeGlzdGluZztcclxuICAgICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihhc1Nlc3MpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoID49IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCkge1xyXG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICd0aHJlc2hvbGQnKTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVjb3JkVW5hdmFpbGFibGVUd2VldHMoXHJcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXSxcclxuICB0cmFja2VkOiBSZWFkb25seVNldDxzdHJpbmc+LFxyXG4gIGNhcHR1cmVkQXQ6IHN0cmluZyxcclxuICBzb3VyY2VVcmw6IHN0cmluZyxcclxuICBlbmRwb2ludDogc3RyaW5nXHJcbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGNvbW1pdHRlZElkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xyXG4gIGNvbnN0IG1lZGlhQ3Jhd2xTZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcclxuICBjb25zdCB0aHJlYWRPcGVuU2VzcyA9IGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCk7XHJcbiAgbGV0IHJlY29yZGVkID0gMDtcclxuICBsZXQgc2tpcHBlZCA9IDA7XHJcbiAgbGV0IG1pc3NpbmdIYW5kbGUgPSAwO1xyXG5cclxuICBmb3IgKGNvbnN0IHUgb2YgdW5hdmFpbGFibGVUd2VldHMpIHtcclxuICAgIGNvbnN0IGhhbmRsZSA9IHUuYWNjb3VudF9oYW5kbGU7XHJcbiAgICBpZiAoIWhhbmRsZSkge1xyXG4gICAgICBtaXNzaW5nSGFuZGxlICs9IDE7XHJcbiAgICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHUudHdlZXRfaWQpO1xyXG4gICAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih1LnR3ZWV0X2lkKTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAodHJhY2tlZC5zaXplID4gMCAmJiAhdHJhY2tlZC5oYXMoaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSB7XHJcbiAgICAgIHNraXBwZWQgKz0gMTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodS50d2VldF9pZCk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaChoYW5kbGUsIHUudHdlZXRfaWQpO1xyXG4gICAgYXdhaXQgZGVxdWV1ZVRocmVhZE9wZW4odS50d2VldF9pZCk7XHJcbiAgICBpZiAocmVmZXRjaFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB1LnR3ZWV0X2lkKSB7XHJcbiAgICAgIHJlZmV0Y2hTZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgICAgcmVmZXRjaFNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHJlZmV0Y2hTZXNzKTtcclxuICAgIH1cclxuICAgIGlmIChtZWRpYUNyYXdsU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHUudHdlZXRfaWQpIHtcclxuICAgICAgbWVkaWFDcmF3bFNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgICBtZWRpYUNyYXdsU2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obWVkaWFDcmF3bFNlc3MpO1xyXG4gICAgfVxyXG4gICAgaWYgKHRocmVhZE9wZW5TZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdS50d2VldF9pZCkge1xyXG4gICAgICB0aHJlYWRPcGVuU2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICAgIHRocmVhZE9wZW5TZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgICBhd2FpdCBtYXJrVGhyZWFkT3BlblNlZW4odS50d2VldF9pZCk7XHJcbiAgICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHRocmVhZE9wZW5TZXNzKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzaWcgPSB1bmF2YWlsYWJsZVNpZyh1KTtcclxuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbaGFuZGxlXT8uW3UudHdlZXRfaWRdO1xyXG4gICAgaWYgKHByZXY/LnNpZyA9PT0gc2lnKSB7XHJcbiAgICAgIHNraXBwZWQgKz0gMTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgc291cmNlVXJsLCBlbmRwb2ludCk7XHJcbiAgICBjb25zdCB1bmF2YWlsYWJsZUJ5SWQgPSBidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge307XHJcbiAgICB1bmF2YWlsYWJsZUJ5SWRbdS50d2VldF9pZF0gPSB1O1xyXG4gICAgYnVmLnVuYXZhaWxhYmxlX2J5X2lkID0gdW5hdmFpbGFibGVCeUlkO1xyXG4gICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHUudHdlZXRfaWQpKSB7XHJcbiAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh1LnR3ZWV0X2lkKTtcclxuICAgIH1cclxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xyXG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XHJcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xyXG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIHJ1bkJ1ZmZlckl0ZW1Db3VudChidWYpKTtcclxuICAgIHJlY29yZGVkICs9IDE7XHJcbiAgfVxyXG5cclxuICBpZiAocmVjb3JkZWQgPiAwIHx8IG1pc3NpbmdIYW5kbGUgPiAwIHx8IHNraXBwZWQgPiAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCd1bmF2YWlsYWJsZSB0d2VldHMgb2JzZXJ2ZWQnLCB7IGVuZHBvaW50LCByZWNvcmRlZCwgc2tpcHBlZCwgbWlzc2luZ0hhbmRsZSB9KTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gdW5hdmFpbGFibGVTaWcodTogVW5hdmFpbGFibGVUd2VldCk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGB1bmF2YWlsYWJsZXwke3UudW5hdmFpbGFibGVfcmVhc29uID8/ICcnfXwke3UudW5hdmFpbGFibGVfdGV4dCA/PyAnJ31gO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzaWdNYXJrc1RydW5jYXRlZChzaWc6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gIGNvbnN0IHBhcnRzID0gc2lnLnNwbGl0KCd8Jyk7XHJcbiAgcmV0dXJuIHBhcnRzW3BhcnRzLmxlbmd0aCAtIDFdID09PSAndCc7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJ1bkJ1ZmZlckl0ZW1Db3VudChidWY6IFJ1bkJ1ZmZlcik6IG51bWJlciB7XHJcbiAgcmV0dXJuIChcclxuICAgIE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCArXHJcbiAgICBPYmplY3Qua2V5cyhidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge30pLmxlbmd0aCArXHJcbiAgICBPYmplY3Qua2V5cyhidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge30pLmxlbmd0aFxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJldHdlZXRFZGdlS2V5KGVkZ2U6IFJldHdlZXRFZGdlKTogc3RyaW5nIHtcclxuICByZXR1cm4gW1xyXG4gICAgZWRnZS5yZXR3ZWV0ZXJfaGFuZGxlLnRvTG93ZXJDYXNlKCksXHJcbiAgICBlZGdlLnJldHdlZXRfdHdlZXRfaWQsXHJcbiAgICBlZGdlLm9yaWdpbmFsX3R3ZWV0X2lkLFxyXG4gIF0uam9pbignfCcpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBpbmZlclJldHdlZXRlZEhhbmRsZSh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICBjb25zdCBtYXRjaCA9IHRleHQubWF0Y2goL15SVFxccytAKFtBLVphLXowLTlfXXsxLDE1fSlcXGIvaSk7XHJcbiAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gYnVpbGRSZXR3ZWV0RWRnZXMoXHJcbiAgdHdlZXRzOiBSZWFkb25seUFycmF5PENhbm9uaWNhbFR3ZWV0PixcclxuICBhY2NvdW50czogUmVhZG9ubHlBcnJheTx7IGhhbmRsZTogc3RyaW5nOyBjYXRlZ29yeTogc3RyaW5nIH0+LFxyXG4gIGNhcHR1cmVkQXQ6IHN0cmluZyxcclxuICBlbmRwb2ludDogc3RyaW5nLFxyXG4gIHNvdXJjZVVybDogc3RyaW5nIHwgbnVsbFxyXG4pOiBSZXR3ZWV0RWRnZVtdIHtcclxuICBjb25zdCBjYXRlZ29yeUJ5SGFuZGxlID0gbmV3IE1hcChhY2NvdW50cy5tYXAoKGEpID0+IFthLmhhbmRsZS50b0xvd2VyQ2FzZSgpLCBhLmNhdGVnb3J5XSkpO1xyXG4gIGNvbnN0IGJ5SWQgPSBuZXcgTWFwKHR3ZWV0cy5tYXAoKHQpID0+IFt0LnR3ZWV0X2lkLCB0XSkpO1xyXG4gIGNvbnN0IG91dCA9IG5ldyBNYXA8c3RyaW5nLCBSZXR3ZWV0RWRnZT4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XHJcbiAgICBpZiAodC50d2VldF90eXBlICE9PSAncmV0d2VldCcgfHwgIXQucmV0d2VldGVkX3R3ZWV0X2lkKSBjb250aW51ZTtcclxuICAgIGNvbnN0IHJldHdlZXRlckNhdGVnb3J5ID0gY2F0ZWdvcnlCeUhhbmRsZS5nZXQodC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpKTtcclxuICAgIGlmICghcmV0d2VldGVyQ2F0ZWdvcnkpIGNvbnRpbnVlO1xyXG4gICAgY29uc3Qgb3JpZ2luYWwgPSBieUlkLmdldCh0LnJldHdlZXRlZF90d2VldF9pZCk7XHJcbiAgICBjb25zdCBvcmlnaW5hbEhhbmRsZSA9IG9yaWdpbmFsPy5hY2NvdW50X2hhbmRsZSA/PyBpbmZlclJldHdlZXRlZEhhbmRsZSh0LnRleHRfcmVzb2x2ZWQgfHwgdC50ZXh0KTtcclxuICAgIGNvbnN0IG9yaWdpbmFsQ2F0ZWdvcnkgPSBvcmlnaW5hbEhhbmRsZVxyXG4gICAgICA/IChjYXRlZ29yeUJ5SGFuZGxlLmdldChvcmlnaW5hbEhhbmRsZS50b0xvd2VyQ2FzZSgpKSA/PyAncHVibGljJylcclxuICAgICAgOiBudWxsO1xyXG4gICAgY29uc3QgZWRnZTogUmV0d2VldEVkZ2UgPSB7XHJcbiAgICAgIHJldHdlZXRlcl9oYW5kbGU6IHQuYWNjb3VudF9oYW5kbGUsXHJcbiAgICAgIHJldHdlZXRlcl9hY2NvdW50X2lkOiB0LmFjY291bnRfaWQgPz8gbnVsbCxcclxuICAgICAgcmV0d2VldGVyX2NhdGVnb3J5OiByZXR3ZWV0ZXJDYXRlZ29yeSxcclxuICAgICAgcmV0d2VldF90d2VldF9pZDogdC50d2VldF9pZCxcclxuICAgICAgcmV0d2VldF91cmw6IHQudHdlZXRfdXJsLFxyXG4gICAgICBvcmlnaW5hbF90d2VldF9pZDogdC5yZXR3ZWV0ZWRfdHdlZXRfaWQsXHJcbiAgICAgIG9yaWdpbmFsX2F1dGhvcl9oYW5kbGU6IG9yaWdpbmFsSGFuZGxlLFxyXG4gICAgICBvcmlnaW5hbF9hdXRob3JfYWNjb3VudF9pZDogb3JpZ2luYWw/LmFjY291bnRfaWQgPz8gbnVsbCxcclxuICAgICAgb3JpZ2luYWxfYXV0aG9yX2NhdGVnb3J5OiBvcmlnaW5hbENhdGVnb3J5LFxyXG4gICAgICBjYXB0dXJlZF9hdDogY2FwdHVyZWRBdCxcclxuICAgICAgY2FwdHVyZV9ydW5faWQ6ICdwZW5kaW5nJyxcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIHNvdXJjZV91cmw6IHNvdXJjZVVybCxcclxuICAgIH07XHJcbiAgICBvdXQuc2V0KHJldHdlZXRFZGdlS2V5KGVkZ2UpLCBlZGdlKTtcclxuICB9XHJcbiAgcmV0dXJuIFsuLi5vdXQudmFsdWVzKCldO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBidWZmZXJSZXR3ZWV0RWRnZXMoXHJcbiAgZWRnZXM6IFJlYWRvbmx5QXJyYXk8UmV0d2VldEVkZ2U+LFxyXG4gIGNhcHR1cmVkQXQ6IHN0cmluZyxcclxuICBzb3VyY2VVcmw6IHN0cmluZyxcclxuICBlbmRwb2ludDogc3RyaW5nXHJcbik6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgaWYgKGVkZ2VzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIDA7XHJcbiAgY29uc3QgYnlIYW5kbGUgPSBuZXcgTWFwPHN0cmluZywgUmV0d2VldEVkZ2VbXT4oKTtcclxuICBmb3IgKGNvbnN0IGVkZ2Ugb2YgZWRnZXMpIHtcclxuICAgIGNvbnN0IGFyciA9IGJ5SGFuZGxlLmdldChlZGdlLnJldHdlZXRlcl9oYW5kbGUpID8/IFtdO1xyXG4gICAgYXJyLnB1c2goZWRnZSk7XHJcbiAgICBieUhhbmRsZS5zZXQoZWRnZS5yZXR3ZWV0ZXJfaGFuZGxlLCBhcnIpO1xyXG4gIH1cclxuICBsZXQgYWRkZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgaGFuZGxlRWRnZXNdIG9mIGJ5SGFuZGxlKSB7XHJcbiAgICBjb25zdCBidWYgPSBhd2FpdCBlbnN1cmVSdW5CdWZmZXIoaGFuZGxlLCBjYXB0dXJlZEF0LCBzb3VyY2VVcmwsIGVuZHBvaW50KTtcclxuICAgIGNvbnN0IGVkZ2VNYXAgPSBidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge307XHJcbiAgICBsZXQgYWRkZWRGb3JIYW5kbGUgPSAwO1xyXG4gICAgZm9yIChjb25zdCBlZGdlIG9mIGhhbmRsZUVkZ2VzKSB7XHJcbiAgICAgIGNvbnN0IHN0YW1wZWQ6IFJldHdlZXRFZGdlID0geyAuLi5lZGdlLCBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCB9O1xyXG4gICAgICBjb25zdCBrZXkgPSByZXR3ZWV0RWRnZUtleShzdGFtcGVkKTtcclxuICAgICAgaWYgKCFlZGdlTWFwW2tleV0pIGFkZGVkRm9ySGFuZGxlICs9IDE7XHJcbiAgICAgIGVkZ2VNYXBba2V5XSA9IHN0YW1wZWQ7XHJcbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyhzdGFtcGVkLnJldHdlZXRfdHdlZXRfaWQpKSB7XHJcbiAgICAgICAgYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5wdXNoKHN0YW1wZWQucmV0d2VldF90d2VldF9pZCk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHN0YW1wZWQub3JpZ2luYWxfdHdlZXRfaWQpKSB7XHJcbiAgICAgICAgYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5wdXNoKHN0YW1wZWQub3JpZ2luYWxfdHdlZXRfaWQpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoYWRkZWRGb3JIYW5kbGUgPT09IDApIGNvbnRpbnVlO1xyXG4gICAgYnVmLnJldHdlZXRfZWRnZXNfYnlfa2V5ID0gZWRnZU1hcDtcclxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xyXG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XHJcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xyXG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIHJ1bkJ1ZmZlckl0ZW1Db3VudChidWYpKTtcclxuICAgIGFkZGVkICs9IGFkZGVkRm9ySGFuZGxlO1xyXG4gICAgYXdhaXQgaW5mbygnYnVmZmVyZWQgcmV0d2VldCBlZGdlcycsIHtcclxuICAgICAgaGFuZGxlLFxyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgYWRkZWQ6IGFkZGVkRm9ySGFuZGxlLFxyXG4gICAgICB0b3RhbDogT2JqZWN0LmtleXMoZWRnZU1hcCkubGVuZ3RoLFxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHJldHVybiBhZGRlZDtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZpbmQgZXZlcnkgcGFyZW50IHR3ZWV0IHJlZmVyZW5jZWQgYnkgdGhlIGNhcHR1cmVzIHdlIGp1c3QgaW5nZXN0ZWRcclxuICogKGByZXBseV90b190d2VldF9pZGAsIGBxdW90ZWRfdHdlZXRfaWRgLCBgcmV0d2VldGVkX3R3ZWV0X2lkYCkgdGhhdCB3ZVxyXG4gKiBkb24ndCB5ZXQgaGF2ZSBpbiB0aGUgYXJjaGl2ZSwgYW5kIGVucXVldWUgaXQgb24gdGhlIG1lZGlhLWNyYXdsIGxvb3AuXHJcbiAqXHJcbiAqIFdoeTogWCdzIFVzZXJUd2VldHNBbmRSZXBsaWVzIGVuZHBvaW50IHNvbWV0aW1lcyByZXR1cm5zIGEgdHJhY2tlZFxyXG4gKiBhY2NvdW50J3MgcmVwbHkgKndpdGhvdXQqIHRoZSBwYXJlbnQgaXQgcG9pbnRzIGF0LiBUaGUgYHJlcGx5X3RvXypgXHJcbiAqIGZpZWxkcyBvbiB0aGUgcmVwbHkgc3RpbGwgZ2V0IHNldCBmcm9tIGBpbl9yZXBseV90b19zdGF0dXNfaWRfc3RyYCwgYnV0XHJcbiAqIGBmaWx0ZXJSZWxhdGVkYCBoYXMgbm90aGluZyB0byBrZWVwIFx1MjAxNCB0aGVyZSBpcyBubyBwYXJlbnQgbm9kZSBpbiB0aGVcclxuICogYmF0Y2ggdG8ga2VlcC4gUmVzdWx0OiB0aGUgYXJjaGl2ZSBzaG93cyBESFNnb3YncyByZXBseSBidXQgbm90IHRoZVxyXG4gKiBvcmlnaW5hbCBpdCdzIHJlcGx5aW5nIHRvLiBTeW1tZXRyaWMgcHJvYmxlbSBmb3Igb3JwaGFuZWQgcXVvdGUgLyBSVFxyXG4gKiBwb2ludGVycy5cclxuICpcclxuICogUmV1c2luZyB0aGUgbWVkaWEtY3Jhd2wgcXVldWUgKyBsb29wIG1lYW5zIG5vIG5ldyBVSTsgdGhlIHVzZXIgYWxyZWFkeVxyXG4gKiBzdGFydHMgaXQgbWFudWFsbHkgd2hlbiB0aGV5IHdhbnQgdG8gZmV0Y2ggcGFydGlhbC1jYXB0dXJlZCB0d2VldHMuXHJcbiAqIFNhbWUgZGVkdXAgcnVsZXMgYXBwbHkgKGNvbW1pdHRlZCBcdTIxOTIgc2tpcDsgYWxyZWFkeSBxdWV1ZWQgXHUyMTkyIG5vLW9wKS5cclxuICpcclxuICogV2Ugb25seSB3YWxrIHRoZSB0d2VldHMgdGhhdCBzdXJ2aXZlZCBgZmlsdGVyUmVsYXRlZGAgc28gd2UgZG9uJ3QgY3Jhd2xcclxuICogcGFyZW50cyBvZiByYW5kb20gcmVwbGllcyB0aGF0IHdvdWxkbid0IGhhdmUgYmVlbiBrZXB0IGFueXdheS5cclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGVucXVldWVNaXNzaW5nUGFyZW50cyhcclxuICB0d2VldHM6IFJlYWRvbmx5QXJyYXk8Q2Fub25pY2FsVHdlZXQ+LFxyXG4gIGVuZHBvaW50OiBzdHJpbmdcclxuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICAvLyBCdWlsZCBhIHNhbWUtYmF0Y2ggSUQgc2V0IHNvIHdlIGRvbid0IGVucXVldWUgYSBwYXJlbnQgdGhhdCBhbHJlYWR5XHJcbiAgLy8gYXJyaXZlZCBpbiB0aGlzIHZlcnkgcmVzcG9uc2UuXHJcbiAgY29uc3Qgc2FtZUJhdGNoSWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykgc2FtZUJhdGNoSWRzLmFkZCh0LnR3ZWV0X2lkKTtcclxuXHJcbiAgbGV0IGVucXVldWVkID0gMDtcclxuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XHJcbiAgICBjb25zdCBwYXJlbnRzOiBBcnJheTx7IGlkOiBzdHJpbmc7IGhpbnQ6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcclxuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkKSB7XHJcbiAgICAgIHBhcmVudHMucHVzaCh7IGlkOiB0LnJlcGx5X3RvX3R3ZWV0X2lkLCBoaW50OiB0LnJlcGx5X3RvX2FjY291bnQgfSk7XHJcbiAgICB9XHJcbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQpIHBhcmVudHMucHVzaCh7IGlkOiB0LnF1b3RlZF90d2VldF9pZCwgaGludDogbnVsbCB9KTtcclxuICAgIGlmICh0LnJldHdlZXRlZF90d2VldF9pZCkgcGFyZW50cy5wdXNoKHsgaWQ6IHQucmV0d2VldGVkX3R3ZWV0X2lkLCBoaW50OiBudWxsIH0pO1xyXG4gICAgZm9yIChjb25zdCBwIG9mIHBhcmVudHMpIHtcclxuICAgICAgaWYgKHNhbWVCYXRjaElkcy5oYXMocC5pZCkpIGNvbnRpbnVlO1xyXG4gICAgICBpZiAoYXdhaXQgaXNDb21taXR0ZWQocC5pZCkpIGNvbnRpbnVlO1xyXG4gICAgICBhd2FpdCBlbnF1ZXVlTWVkaWFDcmF3bChwLmhpbnQsIHAuaWQpO1xyXG4gICAgICBlbnF1ZXVlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBpZiAoZW5xdWV1ZWQgPiAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdxdWV1ZWQgbWlzc2luZyBwYXJlbnQgdHdlZXRzIGZvciBkZXRhaWwtcGFnZSBjcmF3bCcsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIGVucXVldWVkLFxyXG4gICAgICBxdWV1ZV90b3RhbDogYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKSxcclxuICAgIH0pO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVRocmVhZE9wZW5DYW5kaWRhdGVzKFxyXG4gIHR3ZWV0czogUmVhZG9ubHlBcnJheTxDYW5vbmljYWxUd2VldD4sXHJcbiAgY29yZUhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz4sXHJcbiAgZW5kcG9pbnQ6IHN0cmluZ1xyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBpZiAodHdlZXRzLmxlbmd0aCA9PT0gMCB8fCBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm47XHJcbiAgaWYgKGVuZHBvaW50LmluY2x1ZGVzKCdUd2VldERldGFpbCcpIHx8IGVuZHBvaW50LmluY2x1ZGVzKCdUd2VldFJlc3VsdEJ5UmVzdElkJykpIHJldHVybjtcclxuXHJcbiAgY29uc3QgY2FuZGlkYXRlcyA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XHJcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xyXG4gICAgY29uc3QgaGFuZGxlID0gdC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgaWYgKCFjb3JlSGFuZGxlcy5oYXMoaGFuZGxlKSkgY29udGludWU7XHJcblxyXG4gICAgY29uc3Qgcm9vdElkID0gdC5jb252ZXJzYXRpb25faWQgPz8gdC50d2VldF9pZDtcclxuICAgIGNvbnN0IGlzUm9vdCA9IHJvb3RJZCA9PT0gdC50d2VldF9pZCB8fCB0LnJlcGx5X3RvX3R3ZWV0X2lkID09PSBudWxsO1xyXG4gICAgY29uc3QgaXNDb3JlUmVwbHkgPSB0LnJlcGx5X3RvX3R3ZWV0X2lkICE9PSBudWxsO1xyXG4gICAgaWYgKGlzUm9vdCAmJiB0LnJlcGx5X2NvdW50ID4gMCkge1xyXG4gICAgICBjYW5kaWRhdGVzLnNldChyb290SWQsIHQuYWNjb3VudF9oYW5kbGUpO1xyXG4gICAgfSBlbHNlIGlmIChpc0NvcmVSZXBseSAmJiByb290SWQpIHtcclxuICAgICAgY2FuZGlkYXRlcy5zZXQocm9vdElkLCB0LmFjY291bnRfaGFuZGxlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGxldCBlbnF1ZXVlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBbdHdlZXRJZCwgaGFuZGxlXSBvZiBjYW5kaWRhdGVzKSB7XHJcbiAgICBjb25zdCBiZWZvcmUgPSBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpO1xyXG4gICAgYXdhaXQgZW5xdWV1ZVRocmVhZE9wZW4oaGFuZGxlLCB0d2VldElkKTtcclxuICAgIGNvbnN0IGFmdGVyID0gYXdhaXQgdGhyZWFkT3BlblF1ZXVlVG90YWwoKTtcclxuICAgIGlmIChhZnRlciA+IGJlZm9yZSkgZW5xdWV1ZWQgKz0gMTtcclxuICB9XHJcbiAgaWYgKGVucXVldWVkID4gMCkge1xyXG4gICAgYXdhaXQgaW5mbygncXVldWVkIGNvcmUgdGhyZWFkIHJvb3RzIGZvciBvcGVuaW5nJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgZW5xdWV1ZWQsXHJcbiAgICAgIHF1ZXVlX3RvdGFsOiBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpLFxyXG4gICAgfSk7XHJcbiAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVSdW5CdWZmZXIoXHJcbiAgaGFuZGxlOiBzdHJpbmcsXHJcbiAgdHM6IHN0cmluZyxcclxuICBzb3VyY2VVcmw6IHN0cmluZyxcclxuICBlbmRwb2ludDogc3RyaW5nXHJcbik6IFByb21pc2U8UnVuQnVmZmVyPiB7XHJcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSk7XHJcbiAgaWYgKGN1cikgcmV0dXJuIGN1cjtcclxuICBjb25zdCBidWY6IFJ1bkJ1ZmZlciA9IHtcclxuICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcclxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXHJcbiAgICBzdGFydGVkX2F0OiB0cyxcclxuICAgIGxhc3RfY2FwdHVyZV9hdDogdHMsXHJcbiAgICB0d2VldHNfYnlfaWQ6IHt9LFxyXG4gICAgdW5hdmFpbGFibGVfYnlfaWQ6IHt9LFxyXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcclxuICAgIGVuZHBvaW50c19zZWVuOiBbZW5kcG9pbnRdLFxyXG4gICAgc291cmNlX3VybDogc291cmNlVXJsLFxyXG4gIH07XHJcbiAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcclxuICBhd2FpdCBpbmZvKCdydW4gc3RhcnRlZCcsIHsgaGFuZGxlLCBydW46IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCkgfSk7XHJcbiAgcmV0dXJuIGJ1ZjtcclxufVxyXG5cclxuLy8gLS0tIEZsdXNoIGxvZ2ljIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmxldCBmbHVzaENoYWluOiBQcm9taXNlPHZvaWQ+ID0gUHJvbWlzZS5yZXNvbHZlKCk7XHJcblxyXG5pbnRlcmZhY2UgRmx1c2hJdGVtIHtcclxuICBoYW5kbGU6IHN0cmluZztcclxuICBidWY6IFJ1bkJ1ZmZlcjtcclxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W107XHJcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXTtcclxuICByZXR3ZWV0RWRnZXM6IFJldHdlZXRFZGdlW107XHJcbiAgcmF3UGF0aDogc3RyaW5nO1xyXG4gIHNlZW5QYXRoOiBzdHJpbmc7XHJcbiAgY2FwdHVyZTogQ2FwdHVyZVBheWxvYWQ7XHJcbiAgc2VlbjogU2VlblBheWxvYWQ7XHJcbiAgZGF5OiBzdHJpbmc7XHJcbiAgcnVuU2hvcnQ6IHN0cmluZztcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZmx1c2hJZGxlQnVmZmVycygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcclxuICBjb25zdCBoYW5kbGVzOiBzdHJpbmdbXSA9IFtdO1xyXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgYnVmXSBvZiBPYmplY3QuZW50cmllcyhhbGwpKSB7XHJcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XHJcbiAgICAgIGhhbmRsZXMucHVzaChoYW5kbGUpO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBmbHVzaEhhbmRsZXMoaGFuZGxlcywgJ2lkbGUnKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZmx1c2hPcnBoYW5lZEJ1ZmZlcnNJZlN0YWxlKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIC8vIE9uIHdvcmtlciB3YWtlLCBhbnkgYnVmZmVyIG9sZGVyIHRoYW4gdGhlIGlkbGUgdGhyZXNob2xkIGdldHMgYSBjaGFuY2UgdG9cclxuICAvLyBjb21taXQgaW1tZWRpYXRlbHkgXHUyMDE0IHVzZWZ1bCB3aGVuIHRoZSB3b3JrZXIgd2FzIGV2aWN0ZWQgYmVmb3JlIGlkbGUtZmx1c2guXHJcbiAgLy8gSWYgdGhlIFBBVC9vd25lci9yZXBvIGFyZW4ndCBzZXQgd2UnZCBqdXN0IGVtaXQgXCJmbHVzaCBkZWZlcnJlZFwiIGZvciBldmVyeVxyXG4gIC8vIHNpbmdsZSBoYW5kbGUgaW4gc3RvcmFnZSAodGhlIGRpYWdub3N0aWMgc2hvd2VkIHRoaXMgZmlyaW5nIDMwMCsgdGltZXMgaW5cclxuICAvLyBhIHJvdyB3aGVuIHRoZSBleHRlbnNpb24gd29rZSBiZWZvcmUgc2V0dGluZ3MgbG9hZCksIHNvIHNob3J0LWNpcmN1aXRcclxuICAvLyBoZXJlIGluc3RlYWQuXHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykgcmV0dXJuO1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xyXG4gIGNvbnN0IGhhbmRsZXM6IHN0cmluZ1tdID0gW107XHJcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcclxuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xyXG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShsYXN0KSAmJiBub3cgLSBsYXN0ID49IEZMVVNIX0lETEVfTVMpIHtcclxuICAgICAgaGFuZGxlcy5wdXNoKGhhbmRsZSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhoYW5kbGVzLCAnd2FrZScpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmbHVzaEFsbChyZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBhd2FpdCBmbHVzaEhhbmRsZXMoT2JqZWN0LmtleXMoYWxsKSwgcmVhc29uKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGUoaGFuZGxlOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKFtoYW5kbGVdLCByZWFzb24pO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmbHVzaEhhbmRsZXMoaGFuZGxlczogc3RyaW5nW10sIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgdW5pcXVlID0gWy4uLm5ldyBTZXQoaGFuZGxlcyldLmZpbHRlcigoaCkgPT4gaC5sZW5ndGggPiAwKTtcclxuICBpZiAodW5pcXVlLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gIGNvbnN0IHJ1biA9IGZsdXNoQ2hhaW4udGhlbigoKSA9PiBmbHVzaEhhbmRsZXNMb2NrZWQodW5pcXVlLCByZWFzb24pKTtcclxuICBmbHVzaENoYWluID0gcnVuLmNhdGNoKCgpID0+IHt9KTtcclxuICByZXR1cm4gcnVuO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmbHVzaEhhbmRsZXNMb2NrZWQoaGFuZGxlczogc3RyaW5nW10sIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGNvbnN0IGl0ZW1zOiBGbHVzaEl0ZW1bXSA9IFtdO1xyXG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIGhhbmRsZXMpIHtcclxuICAgIGNvbnN0IGJ1ZiA9IGFsbFtoYW5kbGVdO1xyXG4gICAgaWYgKCFidWYpIGNvbnRpbnVlO1xyXG4gICAgY29uc3QgdHdlZXRzID0gT2JqZWN0LnZhbHVlcyhidWYudHdlZXRzX2J5X2lkKTtcclxuICAgIGNvbnN0IHVuYXZhaWxhYmxlVHdlZXRzID0gT2JqZWN0LnZhbHVlcyhidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge30pO1xyXG4gICAgY29uc3QgcmV0d2VldEVkZ2VzID0gT2JqZWN0LnZhbHVlcyhidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge30pO1xyXG4gICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDAgJiYgdW5hdmFpbGFibGVUd2VldHMubGVuZ3RoID09PSAwICYmIHJldHdlZXRFZGdlcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgYXdhaXQgY2xlYXJSdW5CdWZmZXIoaGFuZGxlKTtcclxuICAgICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIDApO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGl0ZW1zLnB1c2goYnVpbGRGbHVzaEl0ZW0oaGFuZGxlLCBidWYsIHR3ZWV0cywgdW5hdmFpbGFibGVUd2VldHMsIHJldHdlZXRFZGdlcykpO1xyXG4gIH1cclxuICBpZiAoaXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHtcclxuICAgIGF3YWl0IHdhcm4oJ3VwbG9hZCBidWZmZXIgZGVmZXJyZWQ6IHNldHRpbmdzIGluY29tcGxldGUnLCB7XHJcbiAgICAgIGNvdW50OiBpdGVtcy5sZW5ndGgsXHJcbiAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcclxuICBjb25zdCBmaWxlcyA9IGl0ZW1zLmZsYXRNYXAoKGl0ZW0pID0+IFtcclxuICAgIHtcclxuICAgICAgcGF0aDogaXRlbS5yYXdQYXRoLFxyXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShpdGVtLmNhcHR1cmUsIG51bGwsIDIpICsgJ1xcbicpLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcGF0aDogaXRlbS5zZWVuUGF0aCxcclxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkoaXRlbS5zZWVuLCBudWxsLCAyKSArICdcXG4nKSxcclxuICAgIH0sXHJcbiAgXSk7XHJcbiAgY29uc3QgY29tbWl0TXNnID0gYnVpbGRCYXRjaENvbW1pdE1lc3NhZ2UoaXRlbXMpO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2xpZW50LmNvbW1pdEZpbGVzKHtcclxuICAgICAgZmlsZXMsXHJcbiAgICAgIG1lc3NhZ2U6IGNvbW1pdE1zZyxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xyXG4gICAgICBjb25zdCByZW1haW5pbmdDb3VudCA9IGF3YWl0IGNsZWFyQ29tbWl0dGVkVHdlZXRzRnJvbUJ1ZmZlcihpdGVtKTtcclxuICAgICAgLy8gQ291bnRlciBidW1wOiBhY3R1YWxseSBJTkNSRU1FTlQgdG9kYXlDb3VudCBhbmQgdG90YWxDb21taXR0ZWQgYnlcclxuICAgICAgLy8gdGhlIG51bWJlciBvZiB0d2VldHMgd2UganVzdCBwZXJzaXN0ZWQgKHRoZSBwcmV2aW91cyBjb2RlIHJlYWQgdGhlXHJcbiAgICAgIC8vIGV4aXN0aW5nIHZhbHVlcyBhbmQgd3JvdGUgdGhlbSBiYWNrLCBsZWF2aW5nIHRoZSBjb3VudGVyIHBlZ2dlZCBhdFxyXG4gICAgICAvLyB6ZXJvKS5cclxuICAgICAgY29uc3QgcHJldiA9IChhd2FpdCBnZXRDb3VudGVycygpKVtpdGVtLmhhbmRsZV07XHJcbiAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcclxuICAgICAgY29uc3QgY2FycmllZFRvZGF5ID0gcHJldiAmJiBwcmV2LnRvZGF5RGF0ZSA9PT0gdG9kYXkgPyBwcmV2LnRvZGF5Q291bnQgOiAwO1xyXG4gICAgICBhd2FpdCBidW1wQ291bnRlcihpdGVtLmhhbmRsZSwge1xyXG4gICAgICAgIHRvZGF5Q291bnQ6IGNhcnJpZWRUb2RheSArIGl0ZW0udHdlZXRzLmxlbmd0aCArIGl0ZW0udW5hdmFpbGFibGVUd2VldHMubGVuZ3RoLFxyXG4gICAgICAgIHRvZGF5RGF0ZTogdG9kYXksXHJcbiAgICAgICAgbGFzdENhcHR1cmVBdDogaXRlbS5idWYubGFzdF9jYXB0dXJlX2F0LFxyXG4gICAgICAgIHRvdGFsQ29tbWl0dGVkOlxyXG4gICAgICAgICAgKHByZXY/LnRvdGFsQ29tbWl0dGVkID8/IDApICsgaXRlbS50d2VldHMubGVuZ3RoICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXHJcbiAgICAgICAgYnVmZmVyZWRDb3VudDogcmVtYWluaW5nQ291bnQsXHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyBSZWNvcmQgY29tbWl0cyBpbiB0aGUgZGVkdXAgaW5kZXggc28gd2UgZG9uJ3QgcmUtY29tbWl0IHRoZW0gbmV4dFxyXG4gICAgICAvLyBicm93c2Ugd2l0aCB1bmNoYW5nZWQgZW5nYWdlbWVudC5cclxuICAgICAgY29uc3QgaW5uZXIgPSBpZHhbaXRlbS5oYW5kbGVdID8/IHt9O1xyXG4gICAgICBjb25zdCBub3dJc28gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XHJcbiAgICAgIGZvciAoY29uc3QgdCBvZiBpdGVtLnR3ZWV0cykge1xyXG4gICAgICAgIGlubmVyW3QudHdlZXRfaWRdID0ge1xyXG4gICAgICAgICAgdHM6IG5vd0lzbyxcclxuICAgICAgICAgIHNpZzogZW5nYWdlbWVudFNpZyhcclxuICAgICAgICAgICAgdC5saWtlX2NvdW50LFxyXG4gICAgICAgICAgICB0LnJldHdlZXRfY291bnQsXHJcbiAgICAgICAgICAgIHQucmVwbHlfY291bnQsXHJcbiAgICAgICAgICAgIHQucXVvdGVfY291bnQsXHJcbiAgICAgICAgICAgIHQuaXNfdHJ1bmNhdGVkXHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH1cclxuICAgICAgZm9yIChjb25zdCB1IG9mIGl0ZW0udW5hdmFpbGFibGVUd2VldHMpIHtcclxuICAgICAgICBpbm5lclt1LnR3ZWV0X2lkXSA9IHtcclxuICAgICAgICAgIHRzOiBub3dJc28sXHJcbiAgICAgICAgICBzaWc6IHVuYXZhaWxhYmxlU2lnKHUpLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH1cclxuICAgICAgaWR4W2l0ZW0uaGFuZGxlXSA9IGlubmVyO1xyXG4gICAgICBhd2FpdCBpbmZvKCd1cGxvYWQgYnVmZmVyIGNvbW1pdHRlZCcsIHtcclxuICAgICAgICBoYW5kbGU6IGl0ZW0uaGFuZGxlLFxyXG4gICAgICAgIHJlYXNvbixcclxuICAgICAgICB0d2VldHM6IGl0ZW0udHdlZXRzLmxlbmd0aCxcclxuICAgICAgICB1bmF2YWlsYWJsZTogaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXHJcbiAgICAgICAgcmV0d2VldF9lZGdlczogaXRlbS5yZXR3ZWV0RWRnZXMubGVuZ3RoLFxyXG4gICAgICAgIHJ1bjogaXRlbS5ydW5TaG9ydCxcclxuICAgICAgICBwYXRoOiBpdGVtLnJhd1BhdGgsXHJcbiAgICAgICAgYmF0Y2hfY29tbWl0OiByZXN1bHQuY29tbWl0U2hhLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICAgIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XHJcbiAgICBhd2FpdCBpbmZvKCd1cGxvYWQgYnVmZmVyIGJhdGNoIGNvbW1pdHRlZCcsIHtcclxuICAgICAgcmVhc29uLFxyXG4gICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXHJcbiAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXHJcbiAgICAgIHR3ZWV0czogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApLFxyXG4gICAgICB1bmF2YWlsYWJsZTogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCwgMCksXHJcbiAgICAgIHJldHdlZXRfZWRnZXM6IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS5yZXR3ZWV0RWRnZXMubGVuZ3RoLCAwKSxcclxuICAgICAgY29tbWl0OiByZXN1bHQuY29tbWl0U2hhLFxyXG4gICAgfSk7XHJcbiAgICB7XHJcbiAgICAgIGNvbnN0IHByZXYgPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xyXG4gICAgICAgIHN0YXR1czogJ29rJyxcclxuICAgICAgICBsb2dpbjogcHJldi5sb2dpbixcclxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBwcmV2LmRlZmF1bHRCcmFuY2gsXHJcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogcHJldi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxyXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSB7XHJcbiAgICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XHJcbiAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAnYXV0aCdcclxuICAgICAgICAgID8gJ2F1dGgtZXJyb3InXHJcbiAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnXHJcbiAgICAgICAgICAgID8gJ3JhdGUtbGltaXRlZCdcclxuICAgICAgICAgICAgOiBlcnIuY2F0ZWdvcnkgPT09ICduZXR3b3JrJ1xyXG4gICAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXHJcbiAgICAgICAgICAgICAgOiBjb25uLnN0YXR1cztcclxuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgICAgc3RhdHVzLFxyXG4gICAgICAgIGxvZ2luOiBjb25uLmxvZ2luLFxyXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIGVycm9yOiBlcnIubWVzc2FnZSxcclxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBjb25uLmRlZmF1bHRCcmFuY2gsXHJcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogY29ubi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxyXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6XHJcbiAgICAgICAgICBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IGVyci5yYXRlTGltaXRSZXNldEF0IDogY29ubi5yYXRlTGltaXRSZXNldEF0LFxyXG4gICAgICB9KTtcclxuICAgICAgYXdhaXQgbG9nRXJyKCd1cGxvYWQgYnVmZmVyIGZhaWxlZCcsIHtcclxuICAgICAgICByZWFzb24sXHJcbiAgICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxyXG4gICAgICAgIHJ1bnM6IGl0ZW1zLmxlbmd0aCxcclxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxyXG4gICAgICAgIGNhdGVnb3J5OiBlcnIuY2F0ZWdvcnksXHJcbiAgICAgICAgc3RhdHVzOiBlcnIuc3RhdHVzLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVyci5tZXNzYWdlLFxyXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGVyci5yYXRlTGltaXRSZXNldEF0LFxyXG4gICAgICB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGF3YWl0IGxvZ0VycigndXBsb2FkIGJ1ZmZlciBmYWlsZWQnLCB7XHJcbiAgICAgICAgcmVhc29uLFxyXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcclxuICAgICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXHJcbiAgICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcclxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgLy8gTGVhdmUgYnVmZmVyIGludGFjdCBmb3IgcmV0cnkuXHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBidWlsZEZsdXNoSXRlbShcclxuICBoYW5kbGU6IHN0cmluZyxcclxuICBidWY6IFJ1bkJ1ZmZlcixcclxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10sXHJcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXSxcclxuICByZXR3ZWV0RWRnZXM6IFJldHdlZXRFZGdlW11cclxuKTogRmx1c2hJdGVtIHtcclxuICBjb25zdCB0cyA9IGlzb0NvbXBhY3QoYnVmLnN0YXJ0ZWRfYXQpO1xyXG4gIGNvbnN0IGRheSA9IGJ1Zi5zdGFydGVkX2F0LnNsaWNlKDAsIDEwKTtcclxuICBjb25zdCBydW5TaG9ydCA9IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCk7XHJcbiAgY29uc3QgcmF3UGF0aCA9IGByYXcvJHtoYW5kbGV9LyR7dHN9LSR7cnVuU2hvcnR9Lmpzb25gO1xyXG4gIGNvbnN0IHNlZW5QYXRoID0gYHNlZW4vJHtoYW5kbGV9LyR7dHN9LSR7cnVuU2hvcnR9Lmpzb25gO1xyXG4gIHJldHVybiB7XHJcbiAgICBoYW5kbGUsXHJcbiAgICBidWYsXHJcbiAgICB0d2VldHMsXHJcbiAgICB1bmF2YWlsYWJsZVR3ZWV0cyxcclxuICAgIHJldHdlZXRFZGdlcyxcclxuICAgIHJhd1BhdGgsXHJcbiAgICBzZWVuUGF0aCxcclxuICAgIGRheSxcclxuICAgIHJ1blNob3J0LFxyXG4gICAgY2FwdHVyZToge1xyXG4gICAgICBzY2hlbWFfdmVyc2lvbjogMSxcclxuICAgICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXHJcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXHJcbiAgICAgIGNhcHR1cmVkX2F0OiBidWYubGFzdF9jYXB0dXJlX2F0LFxyXG4gICAgICBlbmRwb2ludDogYnVmLmVuZHBvaW50c19zZWVuLmpvaW4oJywnKSxcclxuICAgICAgdXNlcl9hZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcclxuICAgICAgc291cmNlX3VybDogYnVmLnNvdXJjZV91cmwsXHJcbiAgICAgIHR3ZWV0cyxcclxuICAgICAgdW5hdmFpbGFibGVfdHdlZXRzOiB1bmF2YWlsYWJsZVR3ZWV0cyxcclxuICAgICAgcmV0d2VldF9lZGdlczogcmV0d2VldEVkZ2VzLFxyXG4gICAgfSxcclxuICAgIHNlZW46IHtcclxuICAgICAgc2NoZW1hX3ZlcnNpb246IDEsXHJcbiAgICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxyXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxyXG4gICAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcclxuICAgICAgdHdlZXRfaWRzX29ic2VydmVkOiBidWYudHdlZXRfaWRzX29ic2VydmVkLFxyXG4gICAgfSxcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBidWlsZEJhdGNoQ29tbWl0TWVzc2FnZShpdGVtczogRmx1c2hJdGVtW10pOiBzdHJpbmcge1xyXG4gIGlmIChpdGVtcy5sZW5ndGggPT09IDEpIHtcclxuICAgIGNvbnN0IGl0ZW0gPSBpdGVtc1swXSE7XHJcbiAgICBjb25zdCB1bmF2YWlsYWJsZUNvdW50ID0gaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGg7XHJcbiAgICBjb25zdCBlZGdlQ291bnQgPSBpdGVtLnJldHdlZXRFZGdlcy5sZW5ndGg7XHJcbiAgICBjb25zdCBzdWZmaXggPVxyXG4gICAgICAodW5hdmFpbGFibGVDb3VudCA+IDAgPyBgLCAke3VuYXZhaWxhYmxlQ291bnR9IHVuYXZhaWxhYmxlYCA6ICcnKSArXHJcbiAgICAgIChlZGdlQ291bnQgPiAwID8gYCwgJHtlZGdlQ291bnR9IHJldHdlZXQgZWRnZSR7ZWRnZUNvdW50ID09PSAxID8gJycgOiAncyd9YCA6ICcnKTtcclxuICAgIHJldHVybiBgY2FwdHVyZTogJHtpdGVtLmhhbmRsZX0gJHtpdGVtLmRheX0gJHtpdGVtLnR3ZWV0cy5sZW5ndGh9IHR3ZWV0JHtpdGVtLnR3ZWV0cy5sZW5ndGggPT09IDEgPyAnJyA6ICdzJ30ke3N1ZmZpeH0gKHJ1biAke2l0ZW0ucnVuU2hvcnR9KWA7XHJcbiAgfVxyXG4gIGNvbnN0IGRheXMgPSBbLi4ubmV3IFNldChpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uZGF5KSldLnNvcnQoKTtcclxuICBjb25zdCBkYXlMYWJlbCA9IGRheXMubGVuZ3RoID09PSAxID8gZGF5c1swXSEgOiBgJHtkYXlzWzBdfS4uJHtkYXlzW2RheXMubGVuZ3RoIC0gMV19YDtcclxuICBjb25zdCB0d2VldENvdW50ID0gaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApO1xyXG4gIGNvbnN0IHVuYXZhaWxhYmxlQ291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udW5hdmFpbGFibGVUd2VldHMubGVuZ3RoLCAwKTtcclxuICBjb25zdCBlZGdlQ291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0ucmV0d2VldEVkZ2VzLmxlbmd0aCwgMCk7XHJcbiAgY29uc3Qgc3VmZml4ID1cclxuICAgICh1bmF2YWlsYWJsZUNvdW50ID4gMCA/IGAsICR7dW5hdmFpbGFibGVDb3VudH0gdW5hdmFpbGFibGVgIDogJycpICtcclxuICAgIChlZGdlQ291bnQgPiAwID8gYCwgJHtlZGdlQ291bnR9IHJldHdlZXQgZWRnZSR7ZWRnZUNvdW50ID09PSAxID8gJycgOiAncyd9YCA6ICcnKTtcclxuICByZXR1cm4gYGNhcHR1cmUgYmF0Y2g6ICR7aXRlbXMubGVuZ3RofSBydW5zLCAke3R3ZWV0Q291bnR9IHR3ZWV0JHt0d2VldENvdW50ID09PSAxID8gJycgOiAncyd9JHtzdWZmaXh9ICgke2RheUxhYmVsfSlgO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBjbGVhckNvbW1pdHRlZFR3ZWV0c0Zyb21CdWZmZXIoaXRlbTogRmx1c2hJdGVtKTogUHJvbWlzZTxudW1iZXI+IHtcclxuICBjb25zdCBjdXJyZW50ID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcclxuICBpZiAoIWN1cnJlbnQpIHJldHVybiAwO1xyXG4gIGlmIChjdXJyZW50LnJ1bl9pZCAhPT0gaXRlbS5idWYucnVuX2lkKSByZXR1cm4gcnVuQnVmZmVySXRlbUNvdW50KGN1cnJlbnQpO1xyXG5cclxuICBjb25zdCBjb21taXR0ZWQgPSBuZXcgTWFwKFxyXG4gICAgaXRlbS50d2VldHMubWFwKCh0KSA9PiBbXHJcbiAgICAgIHQudHdlZXRfaWQsXHJcbiAgICAgIGVuZ2FnZW1lbnRTaWcodC5saWtlX2NvdW50LCB0LnJldHdlZXRfY291bnQsIHQucmVwbHlfY291bnQsIHQucXVvdGVfY291bnQsIHQuaXNfdHJ1bmNhdGVkKSxcclxuICAgIF0pXHJcbiAgKTtcclxuICBmb3IgKGNvbnN0IHUgb2YgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cykge1xyXG4gICAgY29tbWl0dGVkLnNldCh1LnR3ZWV0X2lkLCB1bmF2YWlsYWJsZVNpZyh1KSk7XHJcbiAgfVxyXG4gIGNvbnN0IHJlbWFpbmluZ1R3ZWV0czogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+ID0ge307XHJcbiAgZm9yIChjb25zdCBbdHdlZXRJZCwgdHdlZXRdIG9mIE9iamVjdC5lbnRyaWVzKGN1cnJlbnQudHdlZXRzX2J5X2lkKSkge1xyXG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcclxuICAgIGNvbnN0IGN1cnJlbnRTaWcgPSBlbmdhZ2VtZW50U2lnKFxyXG4gICAgICB0d2VldC5saWtlX2NvdW50LFxyXG4gICAgICB0d2VldC5yZXR3ZWV0X2NvdW50LFxyXG4gICAgICB0d2VldC5yZXBseV9jb3VudCxcclxuICAgICAgdHdlZXQucXVvdGVfY291bnQsXHJcbiAgICAgIHR3ZWV0LmlzX3RydW5jYXRlZFxyXG4gICAgKTtcclxuICAgIGlmICghY29tbWl0dGVkU2lnIHx8IGNvbW1pdHRlZFNpZyAhPT0gY3VycmVudFNpZykge1xyXG4gICAgICByZW1haW5pbmdUd2VldHNbdHdlZXRJZF0gPSB7IC4uLnR3ZWV0IH07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IHJlbWFpbmluZ1VuYXZhaWxhYmxlOiBSZWNvcmQ8c3RyaW5nLCBVbmF2YWlsYWJsZVR3ZWV0PiA9IHt9O1xyXG4gIGZvciAoY29uc3QgW3R3ZWV0SWQsIHVuYXZhaWxhYmxlXSBvZiBPYmplY3QuZW50cmllcyhjdXJyZW50LnVuYXZhaWxhYmxlX2J5X2lkID8/IHt9KSkge1xyXG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcclxuICAgIGNvbnN0IGN1cnJlbnRTaWcgPSB1bmF2YWlsYWJsZVNpZyh1bmF2YWlsYWJsZSk7XHJcbiAgICBpZiAoIWNvbW1pdHRlZFNpZyB8fCBjb21taXR0ZWRTaWcgIT09IGN1cnJlbnRTaWcpIHtcclxuICAgICAgcmVtYWluaW5nVW5hdmFpbGFibGVbdHdlZXRJZF0gPSB7IC4uLnVuYXZhaWxhYmxlIH07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IHJlbWFpbmluZ1JldHdlZXRFZGdlczogUmVjb3JkPHN0cmluZywgUmV0d2VldEVkZ2U+ID0ge307XHJcbiAgZm9yIChjb25zdCBba2V5LCBlZGdlXSBvZiBPYmplY3QuZW50cmllcyhjdXJyZW50LnJldHdlZXRfZWRnZXNfYnlfa2V5ID8/IHt9KSkge1xyXG4gICAgaWYgKCFpdGVtLnJldHdlZXRFZGdlcy5zb21lKChjb21taXR0ZWRFZGdlKSA9PiByZXR3ZWV0RWRnZUtleShjb21taXR0ZWRFZGdlKSA9PT0ga2V5KSkge1xyXG4gICAgICByZW1haW5pbmdSZXR3ZWV0RWRnZXNba2V5XSA9IHsgLi4uZWRnZSB9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgcmVtYWluaW5nSWRzID0gbmV3IFNldChbXHJcbiAgICAuLi5PYmplY3Qua2V5cyhyZW1haW5pbmdUd2VldHMpLFxyXG4gICAgLi4uT2JqZWN0LmtleXMocmVtYWluaW5nVW5hdmFpbGFibGUpLFxyXG4gICAgLi4uT2JqZWN0LnZhbHVlcyhyZW1haW5pbmdSZXR3ZWV0RWRnZXMpLmZsYXRNYXAoKGVkZ2UpID0+IFtcclxuICAgICAgZWRnZS5yZXR3ZWV0X3R3ZWV0X2lkLFxyXG4gICAgICBlZGdlLm9yaWdpbmFsX3R3ZWV0X2lkLFxyXG4gICAgXSksXHJcbiAgXSk7XHJcbiAgY29uc3QgcmVtYWluaW5nQ291bnQgPVxyXG4gICAgT2JqZWN0LmtleXMocmVtYWluaW5nVHdlZXRzKS5sZW5ndGggK1xyXG4gICAgT2JqZWN0LmtleXMocmVtYWluaW5nVW5hdmFpbGFibGUpLmxlbmd0aCArXHJcbiAgICBPYmplY3Qua2V5cyhyZW1haW5pbmdSZXR3ZWV0RWRnZXMpLmxlbmd0aDtcclxuICBpZiAocmVtYWluaW5nQ291bnQgPT09IDApIHtcclxuICAgIGF3YWl0IGNsZWFyUnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcclxuICAgIHJldHVybiAwO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgbmV4dFJ1bklkID0gbmV3UnVuSWQoKTtcclxuICBmb3IgKGNvbnN0IHR3ZWV0IG9mIE9iamVjdC52YWx1ZXMocmVtYWluaW5nVHdlZXRzKSkge1xyXG4gICAgdHdlZXQuY2FwdHVyZV9ydW5faWQgPSBuZXh0UnVuSWQ7XHJcbiAgfVxyXG4gIGZvciAoY29uc3QgZWRnZSBvZiBPYmplY3QudmFsdWVzKHJlbWFpbmluZ1JldHdlZXRFZGdlcykpIHtcclxuICAgIGVkZ2UuY2FwdHVyZV9ydW5faWQgPSBuZXh0UnVuSWQ7XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSwge1xyXG4gICAgLi4uY3VycmVudCxcclxuICAgIHJ1bl9pZDogbmV4dFJ1bklkLFxyXG4gICAgc3RhcnRlZF9hdDogY3VycmVudC5sYXN0X2NhcHR1cmVfYXQsXHJcbiAgICB0d2VldHNfYnlfaWQ6IHJlbWFpbmluZ1R3ZWV0cyxcclxuICAgIHVuYXZhaWxhYmxlX2J5X2lkOiByZW1haW5pbmdVbmF2YWlsYWJsZSxcclxuICAgIHJldHdlZXRfZWRnZXNfYnlfa2V5OiByZW1haW5pbmdSZXR3ZWV0RWRnZXMsXHJcbiAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IGN1cnJlbnQudHdlZXRfaWRzX29ic2VydmVkLmZpbHRlcigoaWQpID0+IHJlbWFpbmluZ0lkcy5oYXMoaWQpKSxcclxuICB9KTtcclxuICBhd2FpdCBpbmZvKCd1cGxvYWQgYnVmZmVyIGtlcHQgbmV3ZXIgdHdlZXRzJywge1xyXG4gICAgaGFuZGxlOiBpdGVtLmhhbmRsZSxcclxuICAgIGNvbW1pdHRlZF9ydW46IGl0ZW0ucnVuU2hvcnQsXHJcbiAgICBuZXh0X3J1bjogc2hvcnRSdW5JZChuZXh0UnVuSWQpLFxyXG4gICAgcmVtYWluaW5nOiByZW1haW5pbmdDb3VudCxcclxuICB9KTtcclxuICByZXR1cm4gcmVtYWluaW5nQ291bnQ7XHJcbn1cclxuXHJcbi8vIC0tLSBDYXB0dXJlLW5vdyAvIGNhcHR1cmUtYWxsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVOb3coaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcclxuICAvLyBMYW5kIG9uIHRoZSBSZXBsaWVzIHRhYiBzbyBYIGZldGNoZXMgdmlhIFVzZXJUd2VldHNBbmRSZXBsaWVzIFx1MjAxNCB0aGF0XHJcbiAgLy8gZW5kcG9pbnQgcmV0dXJucyBib3RoIHRvcC1sZXZlbCBwb3N0cyBhbmQgcmVwbGllcywgd2hpY2ggaXMgdGhlIHN1cGVyc2V0XHJcbiAgLy8gd2Ugd2FudCBmb3IgdGhlIGFyY2hpdmUuIFRoZSBwbGFpbiBgLzxoYW5kbGU+YCBVUkwgaGl0cyBVc2VyVHdlZXRzLFxyXG4gIC8vIHdoaWNoIG9taXRzIHJlcGxpZXMuIFRoZSBwYWdlLWhvb2sgaW50ZXJjZXB0cyBlaXRoZXIgZW5kcG9pbnQsIGJ1dFxyXG4gIC8vIGZvcmNpbmcgdGhlIGJyb2FkZXIgdGFiIG9uIHVzZXItaW5pdGlhdGVkIGNhcHR1cmVzIGlzIHRoZSByaWdodCBkZWZhdWx0LlxyXG4gIGNvbnN0IHRhcmdldFVybCA9IGBodHRwczovL3guY29tLyR7aGFuZGxlfS93aXRoX3JlcGxpZXNgO1xyXG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtbm93IHJlcXVlc3RlZCcsIHsgaGFuZGxlLCB0YWI6ICd3aXRoX3JlcGxpZXMnIH0pO1xyXG4gIGlmICghKGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpKSkge1xyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xyXG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwge1xyXG4gICAgICBydW5faWQ6IG5ld1J1bklkKCksXHJcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXHJcbiAgICAgIHN0YXJ0ZWRfYXQ6IG5vdyxcclxuICAgICAgbGFzdF9jYXB0dXJlX2F0OiBub3csXHJcbiAgICAgIHR3ZWV0c19ieV9pZDoge30sXHJcbiAgICAgIHVuYXZhaWxhYmxlX2J5X2lkOiB7fSxcclxuICAgICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcclxuICAgICAgZW5kcG9pbnRzX3NlZW46IFtdLFxyXG4gICAgICBzb3VyY2VfdXJsOiB0YXJnZXRVcmwsXHJcbiAgICB9KTtcclxuICB9XHJcbiAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogdGFyZ2V0VXJsLCBhY3RpdmU6IHRydWUgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVBbGwoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtYWxsIHJlcXVlc3RlZCcsIHsgY291bnQ6IGFjY291bnRzLmxlbmd0aCB9KTtcclxuICBmb3IgKGNvbnN0IGEgb2YgYWNjb3VudHMpIHtcclxuICAgIGF3YWl0IGNhcHR1cmVOb3coYS5oYW5kbGUpO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIENhcHR1cmUgd2hhdGV2ZXIgdGhlIHVzZXIgaXMgY3VycmVudGx5IGxvb2tpbmcgYXQ6IGVuc3VyZXMgcGFnZS1ob29rIGlzXHJcbiAqIHBhdGNoZWQgaW50byB0aGUgYWN0aXZlIHRhYiwgdGhlbiBudWRnZXMgdGhlIHBhZ2Ugd2l0aCBhIHByb2dyYW1tYXRpY1xyXG4gKiBzY3JvbGwgc28gWCBmaXJlcyBhbm90aGVyIGJhdGNoIG9mIEdyYXBoUUwgcmVxdWVzdHMgd2UgY2FuIGludGVyY2VwdC5cclxuICpcclxuICogTGVzcyBkaXNydXB0aXZlIHRoYW4gYENhcHR1cmUgbm93YCAobm8gbmV3IHRhYiwgbm8gbmF2aWdhdGlvbikgYW5kIHdvcmtzXHJcbiAqIGZvciBhcmJpdHJhcnkgWCBVUkxzIChzcGVjaWZpYyB0d2VldCB0aHJlYWRzLCBzZWFyY2ggcmVzdWx0cywgbGlzdHMpXHJcbiAqIHRoYXQgZG9uJ3QgbWFwIGNsZWFubHkgdG8gb25lIG9mIHRoZSBjb25maWd1cmVkIGhhbmRsZXMuXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlVGhpc1BhZ2UoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XHJcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcclxuICB0cnkge1xyXG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBjb3VsZCBub3QgcXVlcnkgYWN0aXZlIHRhYicsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IHRhYiA9IHRhYnNbMF07XHJcbiAgaWYgKCF0YWIgfHwgdHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicgfHwgIXRhYi51cmwpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBubyBhY3RpdmUgdGFiJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmICghL15odHRwczpcXC9cXC8oeHx0d2l0dGVyKVxcLmNvbVxcLy8udGVzdCh0YWIudXJsKSkge1xyXG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGFjdGl2ZSB0YWIgaXMgbm90IG9uIHguY29tIC8gdHdpdHRlci5jb20nLCB7XHJcbiAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsKSxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBhd2FpdCBpbmZvKCdjYXB0dXJlLXRoaXMtcGFnZSByZXF1ZXN0ZWQnLCB7IHVybDogc2hvcnRlblVybCh0YWIudXJsKSB9KTtcclxuICAvLyAoUmUtKWluamVjdCB0aGUgcGFnZS1ob29rICsgaXNvbGF0ZWQgY29udGVudCBzY3JpcHQgc28gZmV0Y2gvWEhSIGFyZVxyXG4gIC8vIHBhdGNoZWQgZXZlbiBvbiB0YWJzIG9wZW5lZCBiZWZvcmUgdGhlIGV4dGVuc2lvbiByZWxvYWRlZC5cclxuICB0cnkge1xyXG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XHJcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXHJcbiAgICAgIGZpbGVzOiBbJ3BhZ2UtaG9vay5qcyddLFxyXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXHJcbiAgICB9KTtcclxuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxyXG4gICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiByZS1pbmplY3QgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICB9XHJcbiAgLy8gTnVkZ2UgWCB0byBmaXJlIG1vcmUgR3JhcGhRTCByZXF1ZXN0cyBieSBzY3JvbGxpbmcuIE1vc3QgdGltZWxpbmUgL1xyXG4gIC8vIGNvbnZlcnNhdGlvbiB2aWV3cyBmZXRjaCBvbiBpbnRlcnNlY3Rpb24tb2JzZXJ2ZXIgdHJpZ2dlcnMuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxyXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXHJcbiAgICAgIGZ1bmM6ICgpID0+IHtcclxuICAgICAgICBjb25zdCBoID0gd2luZG93LmlubmVySGVpZ2h0O1xyXG4gICAgICAgIHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuNSwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSksIDYwMCk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgMTIwMCk7XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBzY3JvbGwtbnVkZ2UgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLSBSZWZldGNoIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vXHJcbi8vIFggdHJ1bmNhdGVzIGxvbmcgdHdlZXRzIGluIHRpbWVsaW5lIHBheWxvYWRzIFx1MjAxNCBgbm90ZV90d2VldGAgaXMgb25seVxyXG4vLyBpbmxpbmVkIGZvciBzb21lIGVuZHBvaW50cy4gUmUtb3BlbmluZyBlYWNoIHRydW5jYXRlZCB0d2VldCdzIGRldGFpbCBwYWdlXHJcbi8vIGNhdXNlcyB0aGUgcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkuIFRoZSBsb29wXHJcbi8vIGRyaXZlcyB0aGF0IGJ5IG5hdmlnYXRpbmcgYSBzaW5nbGUgZGVkaWNhdGVkIHRhYiB0aHJvdWdoIHRoZSBxdWV1ZSwgb25lXHJcbi8vIHR3ZWV0IGF0IGEgdGltZSwgZ2F0ZWQgb24gdGhlIHBhZ2UtaG9vayBhY3R1YWxseSBpbmdlc3RpbmcgYSByZXNwb25zZSBmb3JcclxuLy8gdGhlIHR3ZWV0IHdlIGp1c3QgbmF2aWdhdGVkIHRvIChzbyBkZWxldGVkIC8gcGF5d2FsbGVkIC8gNDA0J2QgdHdlZXRzXHJcbi8vIGRvbid0IG1ha2UgdXMgc3BpbiBhbmQgc28gd2UgZG9uJ3Qgc2xhbSBYIHdpdGggcmVmcmVzaGVzIGZhc3RlciB0aGFuIHRoZVxyXG4vLyB0YWIgY2FuIGxvYWQpLlxyXG5cclxuY29uc3QgUkVGRVRDSF9UQUJfS0VZID0gJ19faW1tX2FyY2hpdmVfcmVmZXRjaF90YWJfaWRfXyc7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChSRUZFVENIX1RBQl9LRVkpO1xyXG4gIGNvbnN0IGlkID0gc3RvcmVkW1JFRkVUQ0hfVEFCX0tFWV07XHJcbiAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ251bWJlcicgPyBpZCA6IG51bGw7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hUYWJJZChpZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGlmIChpZCA9PT0gbnVsbCkge1xyXG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnJlbW92ZShSRUZFVENIX1RBQl9LRVkpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1JFRkVUQ0hfVEFCX0tFWV06IGlkIH0pO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcclxuICBjb25zdCB0b3RhbCA9IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCk7XHJcbiAgaWYgKHRvdGFsID09PSAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoOiBub3RoaW5nIHF1ZXVlZCcpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXHJcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxyXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYykpXHJcbiAgKTtcclxuICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbih7XHJcbiAgICB0b3RhbEF0U3RhcnQ6IHRvdGFsLFxyXG4gICAgcHJvY2Vzc2VkOiAwLFxyXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICBpbmZsaWdodDogbnVsbCxcclxuICB9KTtcclxuICBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcclxuICB2b2lkIHJlZmV0Y2hUaWNrKCk7XHJcbiAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5sZXQgcmVmZXRjaEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xyXG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcclxuICByZWZldGNoSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIHJlZmV0Y2hUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ3JlZmV0Y2ggdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gICAgfSk7XHJcbiAgfSwgc2Vjb25kcyAqIDEwMDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdG9wUmVmZXRjaEludGVydmFsKCk6IHZvaWQge1xyXG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcclxuICAgIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcclxuICAgIHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSA9IG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBzdG9wUmVmZXRjaEludGVydmFsKCk7XHJcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxyXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XHJcbiAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xyXG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xyXG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xyXG4gIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcclxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xyXG4gIGlmIChzZXNzID09PSBudWxsKSB7XHJcbiAgICAvLyBMb29wIHdhcyBjYW5jZWxsZWQgb3IgbmV2ZXIgc3RhcnRlZDsgbm90aGluZyB0byBkby5cclxuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgLy8gV2FpdC1mb3ItaW5nZXN0IGd1YXJkOiBpZiB3ZSdyZSBzdGlsbCBleHBlY3RpbmcgYSBjYXB0dXJlIGZvciB0aGVcclxuICAvLyBwcmV2aW91c2x5LW5hdmlnYXRlZCB0YXJnZXQsIG9ubHkgYWR2YW5jZSBvbmNlIHdlJ3ZlIGVpdGhlciBzZWVuIHRoZVxyXG4gIC8vIGNhcHR1cmUgKG9uR3JhcGhxbENhcHR1cmUgY2xlYXJzIGBpbmZsaWdodGApIG9yIGhpdCB0aGUgdGltZW91dC5cclxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xyXG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xyXG4gICAgaWYgKGVsYXBzZWQgPCBJTkdFU1RfV0FJVF9NUykge1xyXG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgXHUyMDE0IHBhZ2UtaG9vayBtYXkgeWV0IGNhcHR1cmUgdGhlIHJlc3BvbnNlLlxyXG4gICAgfVxyXG4gICAgLy8gVGltZWQgb3V0LiBUcmVhdCBhcyBcInRoaXMgdGFyZ2V0IHdvbid0IGluZ2VzdFwiIGFuZCBkcm9wIGl0LlxyXG4gICAgYXdhaXQgd2FybigncmVmZXRjaDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXHJcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcclxuICAgIH0pO1xyXG4gICAgLy8gRmluZCB3aGljaCBoYW5kbGUgdGhpcyBpZCBpcyBxdWV1ZWQgdW5kZXIgc28gd2UgY2FuIGRlcXVldWUgaXQuXHJcbiAgICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcclxuICAgICAgaWYgKGlkcy5pbmNsdWRlcyhzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpKSB7XHJcbiAgICAgICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2goaGFuZGxlLCBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRSZWZldGNoVGFyZ2V0KCk7XHJcbiAgaWYgKCF0YXJnZXQpIHtcclxuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcclxuICAgIGF3YWl0IHNldFJlZmV0Y2hUYWJJZChudWxsKTtcclxuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xyXG4gICAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIGNvbnN0IHVybCA9IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmhhbmRsZX0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcclxuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRSZWZldGNoVGFiSWQoKTtcclxuICBpZiAodGFiSWQgIT09IG51bGwpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHRhYklkID0gbnVsbDtcclxuICAgIH1cclxuICB9XHJcbiAgdHJ5IHtcclxuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xyXG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xyXG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicpIGF3YWl0IHNldFJlZmV0Y2hUYWJJZCh0YWIuaWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XHJcbiAgICB9XHJcbiAgICBzZXNzID0gKGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCkpID8/IHNlc3M7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xyXG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIH07XHJcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcclxuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2ggdGljaycsIHtcclxuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxyXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXHJcbiAgICAgIHJlbWFpbmluZzogYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKSxcclxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcclxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxyXG4gICAgfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xyXG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaCh0YXJnZXQuaGFuZGxlLCB0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuLy8gLS0tIE1lZGlhLWNyYXdsIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy9cclxuLy8gTWlycm9ycyB0aGUgcmVmZXRjaCBsb29wIGJ1dCB0YXJnZXRzIHRoZSBtZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXRzIHRoYXRcclxuLy8gdGhlIG5vcm1hbGl6ZXIgb2JzZXJ2ZWQgdmlhIHRoZSBNZWRpYSB0YWIgLyBVc2VyTWVkaWEgZW5kcG9pbnQgd2l0aFxyXG4vLyBpbnN1ZmZpY2llbnQgZGF0YSB0byBidWlsZCBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBUaGUgY3Jhd2wgbG9vcCB3YWxrc1xyXG4vLyBhIGRlZGljYXRlZCB0YWIgdGhyb3VnaCBlYWNoIHR3ZWV0J3MgZGV0YWlsIHBhZ2UgKGhhbmRsZS1sZXNzIFVSTCBmb3JtXHJcbi8vIHdoZW4gdGhlIGhpbnQtaGFuZGxlIGlzIG1pc3NpbmcpLCBhdCB0aGUgYXV0by1zY3JvbGwgY2FkZW5jZSwgc28gdGhlXHJcbi8vIHBhZ2UtaG9vayBjYW4gY2FwdHVyZSB0aGUgcmVhbCB0d2VldCBzaGFwZS5cclxuXHJcbmNvbnN0IE1FRElBX0NSQVdMX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV9tZWRpYV9jcmF3bF90YWJfaWRfXyc7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChNRURJQV9DUkFXTF9UQUJfS0VZKTtcclxuICBjb25zdCBpZCA9IHN0b3JlZFtNRURJQV9DUkFXTF9UQUJfS0VZXTtcclxuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgaWYgKGlkID09PSBudWxsKSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKE1FRElBX0NSQVdMX1RBQl9LRVkpO1xyXG4gIGVsc2UgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtNRURJQV9DUkFXTF9UQUJfS0VZXTogaWQgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XHJcbiAgY29uc3QgdG90YWwgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xyXG4gIGlmICh0b3RhbCA9PT0gMCkge1xyXG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IG5vdGhpbmcgcXVldWVkJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcclxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXHJcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcclxuICApO1xyXG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHtcclxuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXHJcbiAgICBwcm9jZXNzZWQ6IDAsXHJcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIGluZmxpZ2h0OiBudWxsLFxyXG4gIH0pO1xyXG4gIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHMpO1xyXG4gIHZvaWQgbWVkaWFDcmF3bFRpY2soKTtcclxuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5sZXQgbWVkaWFDcmF3bEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xyXG4gIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwobWVkaWFDcmF3bEludGVydmFsSGFuZGxlKTtcclxuICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIG1lZGlhQ3Jhd2xUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ21lZGlhLWNyYXdsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIH0pO1xyXG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpOiB2b2lkIHtcclxuICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSB7XHJcbiAgICBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XHJcbiAgICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsTWVkaWFDcmF3bExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xyXG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXHJcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRNZWRpYUNyYXdsVGFiSWQoKTtcclxuICBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQobnVsbCk7XHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XHJcbiAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obnVsbCk7XHJcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcclxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xyXG4gIGlmIChzZXNzID09PSBudWxsKSB7XHJcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XHJcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2Uoc2Vzcy5pbmZsaWdodC5uYXZpZ2F0ZWRBdCk7XHJcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XHJcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBvbiB0aGUgcGFnZS1ob29rXHJcbiAgICB9XHJcbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXHJcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2woc2Vzcy5pbmZsaWdodC50d2VldElkKTtcclxuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTtcclxuICBpZiAoIXRhcmdldCkge1xyXG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xyXG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKG51bGwpO1xyXG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obnVsbCk7XHJcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgLy8gU2tpcCBpZiBhbHJlYWR5IGluIHRoZSBhcmNoaXZlIFx1MjAxNCBwYXJ0aWFsIGNhcHR1cmVzIGNhbiBvdXRsaXZlIGFcclxuICAvLyBzZXBhcmF0ZSBmdWxsIGNhcHR1cmUgcGF0aC5cclxuICBpZiAoYXdhaXQgaXNDb21taXR0ZWQodGFyZ2V0LnR3ZWV0SWQpKSB7XHJcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcclxuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICAvLyBXaGVuIHdlIGRvbid0IGtub3cgdGhlIHBhcmVudCdzIGF1dGhvciBoYW5kbGUgKHF1b3RlL1JUIG9mIGEgdHdlZXRcclxuICAvLyBYIHN0cmlwcGVkLCBvciBhIFVzZXJNZWRpYSB0aHVtYm5haWwgdGhhdCBsYWNrZWQgdGhlIGF1dGhvciBibG9jayksXHJcbiAgLy8gZmFsbCBiYWNrIHRvIGAvaS93ZWIvc3RhdHVzLzxpZD5gLiBYIHJlc29sdmVzIGl0IHRvIHRoZSBjb3JyZWN0XHJcbiAgLy8gZGV0YWlsIHBhZ2UsIHdoaWNoIGlzIGVub3VnaCBmb3IgdGhlIHBhZ2UtaG9vayB0byBpbmdlc3QgYVxyXG4gIC8vIFR3ZWV0RGV0YWlsIHJlc3BvbnNlLlxyXG4gIGNvbnN0IHVybCA9XHJcbiAgICB0YXJnZXQuYnVja2V0ID09PSAnX3Vua25vd24nXHJcbiAgICAgID8gYGh0dHBzOi8veC5jb20vaS93ZWIvc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YFxyXG4gICAgICA6IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmJ1Y2tldH0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcclxuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRNZWRpYUNyYXdsVGFiSWQoKTtcclxuICBpZiAodGFiSWQgIT09IG51bGwpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHRhYklkID0gbnVsbDtcclxuICAgIH1cclxuICB9XHJcbiAgdHJ5IHtcclxuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xyXG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xyXG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicpIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZCh0YWIuaWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XHJcbiAgICB9XHJcbiAgICBzZXNzID0gKGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCkpID8/IHNlc3M7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xyXG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIH07XHJcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcclxuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIHRpY2snLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgaGludF9oYW5kbGU6IHRhcmdldC5idWNrZXQgPT09ICdfdW5rbm93bicgPyBudWxsIDogdGFyZ2V0LmJ1Y2tldCxcclxuICAgICAgcmVtYWluaW5nOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxyXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxyXG4gICAgICB0b3RhbF9hdF9zdGFydDogc2Vzcy50b3RhbEF0U3RhcnQsXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ21lZGlhLWNyYXdsIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xyXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXHJcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xyXG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XHJcbiAgfVxyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbi8vIC0tLSBUaHJlYWQtb3BlbmluZyBsb29wIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy9cclxuLy8gVGltZWxpbmVzIG9mdGVuIHNob3cgYSBjb3JlIGFjY291bnQncyByb290IHR3ZWV0IHdpdGhvdXQgZXZlcnkgbGF0ZXJcclxuLy8gc2VsZi1yZXBseSBpbiB0aGUgY29udmVyc2F0aW9uLiBUaGlzIHV0aWxpdHkgd2Fsa3MgYSBkZWRpY2F0ZWQgdGFiIHRocm91Z2hcclxuLy8gcXVldWVkIGNvcmUgdGhyZWFkIHJvb3RzIGFuZCBudWRnZXMgdGhlIGRldGFpbCBwYWdlIHNvIFR3ZWV0RGV0YWlsIHBheWxvYWRzXHJcbi8vIGxvYWQgdGhlIHJlc3Qgb2YgdGhlIGNvbnZlcnNhdGlvbi5cclxuXHJcbmNvbnN0IFRIUkVBRF9PUEVOX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV90aHJlYWRfb3Blbl90YWJfaWRfXyc7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRUaHJlYWRPcGVuVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChUSFJFQURfT1BFTl9UQUJfS0VZKTtcclxuICBjb25zdCBpZCA9IHN0b3JlZFtUSFJFQURfT1BFTl9UQUJfS0VZXTtcclxuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2V0VGhyZWFkT3BlblRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgaWYgKGlkID09PSBudWxsKSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFRIUkVBRF9PUEVOX1RBQl9LRVkpO1xyXG4gIGVsc2UgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtUSFJFQURfT1BFTl9UQUJfS0VZXTogaWQgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0VGhyZWFkT3Blbkxvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XHJcbiAgY29uc3QgdG90YWwgPSBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpO1xyXG4gIGlmICh0b3RhbCA9PT0gMCkge1xyXG4gICAgYXdhaXQgaW5mbygndGhyZWFkLW9wZW46IG5vdGhpbmcgcXVldWVkJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcclxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXHJcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcclxuICApO1xyXG4gIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHtcclxuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXHJcbiAgICBwcm9jZXNzZWQ6IDAsXHJcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIGluZmxpZ2h0OiBudWxsLFxyXG4gIH0pO1xyXG4gIHN0YXJ0VGhyZWFkT3BlbkludGVydmFsKHNlY29uZHMpO1xyXG4gIHZvaWQgdGhyZWFkT3BlblRpY2soKTtcclxuICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5sZXQgdGhyZWFkT3BlbkludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0VGhyZWFkT3BlbkludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xyXG4gIGlmICh0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwodGhyZWFkT3BlbkludGVydmFsSGFuZGxlKTtcclxuICB0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIHRocmVhZE9wZW5UaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ3RocmVhZC1vcGVuIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIH0pO1xyXG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc3RvcFRocmVhZE9wZW5JbnRlcnZhbCgpOiB2b2lkIHtcclxuICBpZiAodGhyZWFkT3BlbkludGVydmFsSGFuZGxlICE9PSBudWxsKSB7XHJcbiAgICBjbGVhckludGVydmFsKHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSk7XHJcbiAgICB0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsVGhyZWFkT3Blbkxvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgc3RvcFRocmVhZE9wZW5JbnRlcnZhbCgpO1xyXG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd0aHJlYWQtb3Blbi10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXHJcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRUaHJlYWRPcGVuVGFiSWQoKTtcclxuICBhd2FpdCBzZXRUaHJlYWRPcGVuVGFiSWQobnVsbCk7XHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCk7XHJcbiAgYXdhaXQgc2V0VGhyZWFkT3BlblNlc3Npb24obnVsbCk7XHJcbiAgYXdhaXQgaW5mbygndGhyZWFkLW9wZW4gbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcclxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gdGhyZWFkT3BlblRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRUaHJlYWRPcGVuU2Vzc2lvbigpO1xyXG4gIGlmIChzZXNzID09PSBudWxsKSB7XHJcbiAgICBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XHJcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2Uoc2Vzcy5pbmZsaWdodC5uYXZpZ2F0ZWRBdCk7XHJcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSByZXR1cm47XHJcbiAgICBhd2FpdCB3YXJuKCd0aHJlYWQtb3BlbjogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXHJcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgbWFya1RocmVhZE9wZW5TZWVuKHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3BlbihzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xyXG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgYXdhaXQgc2V0VGhyZWFkT3BlblNlc3Npb24oc2Vzcyk7XHJcbiAgfVxyXG5cclxuICBjb25zdCB0YXJnZXQgPSBhd2FpdCBuZXh0VGhyZWFkT3BlblRhcmdldCgpO1xyXG4gIGlmICghdGFyZ2V0KSB7XHJcbiAgICBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk7XHJcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuVGFiSWQobnVsbCk7XHJcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihudWxsKTtcclxuICAgIGF3YWl0IGluZm8oJ3RocmVhZC1vcGVuIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XHJcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBpZiAoYXdhaXQgaGFzVGhyZWFkT3BlblNlZW4odGFyZ2V0LnR3ZWV0SWQpKSB7XHJcbiAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzZXNzKTtcclxuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICBjb25zdCB1cmwgPSBgaHR0cHM6Ly94LmNvbS8ke3RhcmdldC5oYW5kbGV9L3N0YXR1cy8ke3RhcmdldC50d2VldElkfWA7XHJcbiAgbGV0IHRhYklkID0gYXdhaXQgZ2V0VGhyZWFkT3BlblRhYklkKCk7XHJcbiAgaWYgKHRhYklkICE9PSBudWxsKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICB0YWJJZCA9IG51bGw7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHRyeSB7XHJcbiAgICBpZiAodGFiSWQgPT09IG51bGwpIHtcclxuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiBmYWxzZSB9KTtcclxuICAgICAgaWYgKHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInKSB0aHJvdyBuZXcgRXJyb3IoJ2NyZWF0ZWQgdGFiIHdpdGhvdXQgaWQnKTtcclxuICAgICAgdGFiSWQgPSB0YWIuaWQ7XHJcbiAgICAgIGF3YWl0IHNldFRocmVhZE9wZW5UYWJJZCh0YWJJZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcclxuICAgIH1cclxuICAgIGF3YWl0IG1hcmtUaHJlYWRPcGVuU2Vlbih0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzID0gKGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCkpID8/IHNlc3M7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xyXG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIH07XHJcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzZXNzKTtcclxuICAgIGlmICh0YWJJZCAhPT0gbnVsbCkge1xyXG4gICAgICB2b2lkIG51ZGdlVGhyZWFkT3BlblRhYih0YWJJZCk7XHJcbiAgICB9XHJcbiAgICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiB0aWNrJywge1xyXG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgcmVtYWluaW5nOiBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpLFxyXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxyXG4gICAgICB0b3RhbF9hdF9zdGFydDogc2Vzcy50b3RhbEF0U3RhcnQsXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ3RocmVhZC1vcGVuIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xyXG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBtYXJrVGhyZWFkT3BlblNlZW4odGFyZ2V0LnR3ZWV0SWQpO1xyXG4gICAgYXdhaXQgZGVxdWV1ZVRocmVhZE9wZW4odGFyZ2V0LnR3ZWV0SWQpO1xyXG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgYXdhaXQgc2V0VGhyZWFkT3BlblNlc3Npb24oc2Vzcyk7XHJcbiAgfVxyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIG51ZGdlVGhyZWFkT3BlblRhYih0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgMTUwMCkpO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcclxuICAgICAgdGFyZ2V0OiB7IHRhYklkIH0sXHJcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcclxuICAgICAgZnVuYzogKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGggPSB3aW5kb3cuaW5uZXJIZWlnaHQ7XHJcbiAgICAgICAgY29uc3Qgc3RlcCA9ICgpID0+IHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuMywgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xyXG4gICAgICAgIHN0ZXAoKTtcclxuICAgICAgICBzZXRUaW1lb3V0KHN0ZXAsIDE0MDApO1xyXG4gICAgICAgIHNldFRpbWVvdXQoc3RlcCwgMjgwMCk7XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ3RocmVhZC1vcGVuIHNjcm9sbC1udWRnZSBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tIFF1YXJhbnRpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHF1YXJhbnRpbmUoXHJcbiAgcmVhc29uOiBzdHJpbmcsXHJcbiAgZW5kcG9pbnQ6IHN0cmluZyxcclxuICB1cmw6IHN0cmluZyxcclxuICByYXc6IHVua25vd24sXHJcbiAgZXJyOiB1bmtub3duXHJcbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGxvZ0VycigncXVhcmFudGluaW5nIGNhcHR1cmUnLCB7IHJlYXNvbiwgZW5kcG9pbnQsIHVybCwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcclxuICBjb25zdCBwYXlsb2FkOiBRdWFyYW50aW5lUGF5bG9hZCA9IHtcclxuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxyXG4gICAgcmVhc29uLFxyXG4gICAgZW5kcG9pbnQsXHJcbiAgICBjYXB0dXJlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgc291cmNlX3VybDogdXJsLFxyXG4gICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKSxcclxuICAgIHJhdyxcclxuICB9O1xyXG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChwYXlsb2FkLmNhcHR1cmVkX2F0KTtcclxuICBjb25zdCBoYXNoID0gYXdhaXQgc2hhOChKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XHJcbiAgY29uc3QgcGF0aCA9IGByYXcvX3F1YXJhbnRpbmUvJHt0c30tJHtoYXNofS5qc29uYDtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XHJcbiAgICBhd2FpdCBjbGllbnQucHV0RmlsZSh7XHJcbiAgICAgIHBhdGgsXHJcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHBheWxvYWQsIG51bGwsIDIpICsgJ1xcbicpLFxyXG4gICAgICBtZXNzYWdlOiBgcXVhcmFudGluZTogJHtyZWFzb259ICR7ZW5kcG9pbnR9YCxcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKHFlcnIpIHtcclxuICAgIGF3YWl0IGxvZ0VycigncXVhcmFudGluZSBjb21taXQgZmFpbGVkJywgeyAuLi5kZXNjcmliZUVycm9yKHFlcnIpIH0pO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2hhOChzOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIGNvbnN0IGJ1ZiA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcclxuICBjb25zdCBkaWdlc3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGJ1Zik7XHJcbiAgY29uc3QgaGV4ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShkaWdlc3QpKVxyXG4gICAgLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcclxuICAgIC5qb2luKCcnKTtcclxuICByZXR1cm4gaGV4LnNsaWNlKDAsIDgpO1xyXG59XHJcblxyXG4vLyAtLS0gQ29ubmVjdGlvbiB2ZXJpZmljYXRpb24gJiBhY2NvdW50cyBsaXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5hc3luYyBmdW5jdGlvbiB2ZXJpZnlDb25uZWN0aW9uKGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xyXG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcclxuICAgICAgbG9naW46IG51bGwsXHJcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcclxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcclxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcclxuICBpZiAoIWZvcmNlKSB7XHJcbiAgICAvLyBTa2lwIGlmIHdlJ3JlIGluc2lkZSB0aGUgcmVwb3J0ZWQgcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IHJlLWNoZWNraW5nXHJcbiAgICAvLyBiZWZvcmUgcmVzZXQganVzdCB3YXN0ZXMgbW9yZSBvZiB0aGUgc2FtZSBleGhhdXN0ZWQgcXVvdGEgYW5kIGtlZXBzXHJcbiAgICAvLyB0aGUgNDAzcyBjb21pbmcuXHJcbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xyXG4gICAgICBjb25zdCBub3dTZWMgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcclxuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgLy8gQXBwbHkgdGhlIHBlcmlvZGljLWNoZWNrIGdhdGUgdG8gZXZlcnkgc3RhdHVzLCBub3QganVzdCAnb2snLiBUaGVcclxuICAgIC8vIHByZXZpb3VzIGJlaGF2aW9yIHJlLXZlcmlmaWVkIG9uIGV2ZXJ5IHdha2Ugd2hlbmV2ZXIgdGhlIGNvbm5lY3Rpb25cclxuICAgIC8vIHdhc24ndCAnb2snLCB3aGljaCBkdXJpbmcgYSByYXRlLWxpbWl0IHdpbmRvdyBtZWFudCAyIEFQSSBjYWxscyBwZXJcclxuICAgIC8vIFNXIHdha2UgKHZlcmlmeVJlcG9BY2Nlc3MgZG9lcyBHRVQgL3VzZXIgKyBHRVQgL3JlcG9zL3tvfS97cn0pLlxyXG4gICAgaWYgKGNvbm4uY2hlY2tlZEF0KSB7XHJcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGNvbm4uY2hlY2tlZEF0KTtcclxuICAgICAgaWYgKGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XHJcbiAgICB9XHJcbiAgfVxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcclxuICAgIGNvbnN0IHIgPSBhd2FpdCBjbGllbnQudmVyaWZ5UmVwb0FjY2VzcygpO1xyXG4gICAgLy8gUHJvYmUgdGhlIGNvbmZpZ3VyZWQgYnJhbmNoLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCBpcyBmaW5lIFx1MjAxNCBpdCdzXHJcbiAgICAvLyByb3V0aW5lIHRvIGNhcHR1cmUgaW50byBhIHdvcmtpbmcgYnJhbmNoIFx1MjAxNCBidXQgYSAqbWlzc2luZyogYnJhbmNoXHJcbiAgICAvLyB3b3VsZCA0MjIgZXZlcnkgY29tbWl0LlxyXG4gICAgbGV0IGJyYW5jaE9rID0gdHJ1ZTtcclxuICAgIGlmIChzZXR0aW5ncy5icmFuY2ggJiYgc2V0dGluZ3MuYnJhbmNoICE9PSByLmRlZmF1bHRfYnJhbmNoKSB7XHJcbiAgICAgIGJyYW5jaE9rID0gYXdhaXQgY2xpZW50LmJyYW5jaEV4aXN0cyhzZXR0aW5ncy5icmFuY2gpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgY2hlY2tXcml0ZSA9IGZvcmNlIHx8IGlzV3JpdGVBdXRoRXJyb3IoY29ubi5lcnJvcik7XHJcbiAgICBpZiAoYnJhbmNoT2sgJiYgY2hlY2tXcml0ZSkge1xyXG4gICAgICBhd2FpdCBjbGllbnQudmVyaWZ5V3JpdGVBY2Nlc3MoKTtcclxuICAgIH1cclxuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xyXG4gICAgICBzdGF0dXM6ICdvaycsXHJcbiAgICAgIGxvZ2luOiByLmxvZ2luLFxyXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgZXJyb3I6IG51bGwsXHJcbiAgICAgIGRlZmF1bHRCcmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXHJcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGJyYW5jaE9rLFxyXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBpbmZvKCdjb25uZWN0aW9uIHZlcmlmaWVkJywge1xyXG4gICAgICBsb2dpbjogci5sb2dpbixcclxuICAgICAgcmVwbzogci5mdWxsX25hbWUsXHJcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxyXG4gICAgICBjb25maWd1cmVkX2JyYW5jaDogc2V0dGluZ3MuYnJhbmNoLFxyXG4gICAgICBjb25maWd1cmVkX2JyYW5jaF9leGlzdHM6IGJyYW5jaE9rLFxyXG4gICAgICB3cml0ZV9hY2Nlc3M6IGNoZWNrV3JpdGUgPyAnY2hlY2tlZCcgOiAnbm90X2NoZWNrZWQnLFxyXG4gICAgfSk7XHJcbiAgICBpZiAoIWJyYW5jaE9rKSB7XHJcbiAgICAgIGF3YWl0IHdhcm4oJ2NvbmZpZ3VyZWQgYnJhbmNoIGRvZXMgbm90IGV4aXN0IG9uIHJlbW90ZScsIHtcclxuICAgICAgICBjb25maWd1cmVkOiBzZXR0aW5ncy5icmFuY2gsXHJcbiAgICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXHJcbiAgICAgICAgZml4OiAnb3BlbiBTZXR0aW5ncyBhbmQgY2hhbmdlIGJyYW5jaCB0byAnICsgci5kZWZhdWx0X2JyYW5jaCxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zdCBjYXQgPSBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciA/IGVyci5jYXRlZ29yeSA6ICd1bmtub3duJztcclxuICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XHJcbiAgICAgIGNhdCA9PT0gJ2F1dGgnXHJcbiAgICAgICAgPyAnYXV0aC1lcnJvcidcclxuICAgICAgICA6IGNhdCA9PT0gJ3JhdGUtbGltaXQnXHJcbiAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXHJcbiAgICAgICAgICA6IGNhdCA9PT0gJ25ldHdvcmsnXHJcbiAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXHJcbiAgICAgICAgICAgIDogJ2F1dGgtZXJyb3InO1xyXG4gICAgY29uc3QgcmVzZXRBdCA9XHJcbiAgICAgIGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGNhdCA9PT0gJ3JhdGUtbGltaXQnID8gZXJyLnJhdGVMaW1pdFJlc2V0QXQgOiBudWxsO1xyXG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgIHN0YXR1cyxcclxuICAgICAgbG9naW46IG51bGwsXHJcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLm1lc3NhZ2UsXHJcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXHJcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXHJcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXHJcbiAgICB9KTtcclxuICAgIGF3YWl0IHdhcm4oJ2Nvbm5lY3Rpb24gY2hlY2sgZmFpbGVkJywge1xyXG4gICAgICBjYXRlZ29yeTogY2F0LFxyXG4gICAgICByYXRlTGltaXRSZXNldEF0OiByZXNldEF0LFxyXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXHJcbiAgICB9KTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjY291bnRzTGlzdChmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCkge1xyXG4gICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmICghZm9yY2UpIHtcclxuICAgIC8vIFNraXAgd2hpbGUgaW5zaWRlIGEga25vd24gcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IGFjY291bnRzLnlhbWwgaXMgZmV0Y2hlZFxyXG4gICAgLy8gdmlhIGF1dGhlbnRpY2F0ZWQgcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSwgd2hpY2ggY291bnRzIGFnYWluc3QgdGhlXHJcbiAgICAvLyBzYW1lIHF1b3RhLlxyXG4gICAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcclxuICAgIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcgJiYgY29ubi5yYXRlTGltaXRSZXNldEF0ICE9PSBudWxsKSB7XHJcbiAgICAgIGNvbnN0IG5vd1NlYyA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xyXG4gICAgICBpZiAobm93U2VjIDwgY29ubi5yYXRlTGltaXRSZXNldEF0KSByZXR1cm47XHJcbiAgICB9XHJcbiAgICAvLyBTa2lwIGlmIHdlIHJlZnJlc2hlZCByZWNlbnRseS4gYWNjb3VudHMueWFtbCBjaGFuZ2VzIHJhcmVseSBcdTIwMTQgdGhlIG9sZFxyXG4gICAgLy8gY29kZSByZS1mZXRjaGVkIGl0IG9uIGV2ZXJ5IFNXIHdha2UsIHdoaWNoIGR1cmluZyBoZWF2eSBicm93c2luZyBtZWFudFxyXG4gICAgLy8gYSBHaXRIdWIgY2FsbCBldmVyeSBmZXcgc2Vjb25kcyBldmVuIHdoZW4gbm90aGluZyB3YXMgYmVpbmcgY2FwdHVyZWQuXHJcbiAgICBjb25zdCBsYXN0UmVmcmVzaGVkID0gYXdhaXQgZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpO1xyXG4gICAgaWYgKGxhc3RSZWZyZXNoZWQpIHtcclxuICAgICAgY29uc3QgYWdlID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2UobGFzdFJlZnJlc2hlZCk7XHJcbiAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYWdlKSAmJiBhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xyXG4gICAgfVxyXG4gIH1cclxuICB0cnkge1xyXG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XHJcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgY2xpZW50LmZldGNoUmF3VGV4dCgnY29uZmlnL2FjY291bnRzLnlhbWwnKTtcclxuICAgIGlmICghdGV4dCkge1xyXG4gICAgICBpZiAoZm9yY2UpIGF3YWl0IHdhcm4oJ2FjY291bnRzLnlhbWwgbm90IGZvdW5kIGluIHJlcG87IHVzaW5nIGZhbGxiYWNrJyk7XHJcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xyXG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlQWNjb3VudHNZYW1sKHRleHQpO1xyXG4gICAgaWYgKHBhcnNlZC5sZW5ndGggPT09IDApIHtcclxuICAgICAgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBwYXJzZWQgZW1wdHk7IGtlZXBpbmcgZmFsbGJhY2snKTtcclxuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XHJcbiAgICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgYXdhaXQgc2V0QWNjb3VudHMocGFyc2VkKTtcclxuICAgIGF3YWl0IHJlZnJlc2hBcmNoaXZlU25hcHNob3QoY2xpZW50LCBmb3JjZSk7XHJcbiAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XHJcbiAgICBpZiAoZm9yY2UpIGF3YWl0IGluZm8oJ2FjY291bnRzIGxpc3QgcmVmcmVzaGVkJywgeyBjb3VudDogcGFyc2VkLmxlbmd0aCB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ3JlZnJlc2ggYWNjb3VudHMgZmFpbGVkOyBrZWVwaW5nIGN1cnJlbnQgbGlzdCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgfVxyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hBcmNoaXZlU25hcHNob3QoY2xpZW50OiBHaXRIdWJDbGllbnQsIGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgdGV4dCA9IGF3YWl0IGNsaWVudC5mZXRjaFJhd1RleHQoJ2RhdGEvbWFuaWZlc3QuanNvbicpO1xyXG4gIGlmICghdGV4dCkge1xyXG4gICAgYXdhaXQgc2V0QXJjaGl2ZVNuYXBzaG90KG51bGwpO1xyXG4gICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhcmNoaXZlIG1hbmlmZXN0IG5vdCBmb3VuZDsgb2xkLXR3ZWV0IGRldGVjdGlvbiBkaXNhYmxlZCcpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICB0cnkge1xyXG4gICAgY29uc3Qgc25hcHNob3QgPSBwYXJzZUFyY2hpdmVTbmFwc2hvdChKU09OLnBhcnNlKHRleHQpIGFzIHVua25vd24pO1xyXG4gICAgYXdhaXQgc2V0QXJjaGl2ZVNuYXBzaG90KHNuYXBzaG90KTtcclxuICAgIGlmIChmb3JjZSkge1xyXG4gICAgICBhd2FpdCBpbmZvKCdhcmNoaXZlIHNuYXBzaG90IHJlZnJlc2hlZCcsIHtcclxuICAgICAgICBhY2NvdW50czogT2JqZWN0LmtleXMoc25hcHNob3QuYWNjb3VudHMpLmxlbmd0aCxcclxuICAgICAgICBnZW5lcmF0ZWRfYXQ6IHNuYXBzaG90LmdlbmVyYXRlZF9hdCxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdhcmNoaXZlIHNuYXBzaG90IHBhcnNlIGZhaWxlZDsgb2xkLXR3ZWV0IGRldGVjdGlvbiBkaXNhYmxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0gU3RhdGUgYnJvYWRjYXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5hc3luYyBmdW5jdGlvbiBicm9hZGNhc3RTdGF0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBzdGF0ZSA9IGF3YWl0IGJ1aWxkU3RhdGUoKTtcclxuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcclxuICBsZXQgdGFiQ291bnQgPSAwO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcclxuICAgIHRhYkNvdW50ID0gdGFicy5sZW5ndGg7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyB0YWJzLnF1ZXJ5IGlzIGFsbG93ZWQgYnkgdGhlIG1hbmlmZXN0IGJ1dCBjYW4gdHJhbnNpZW50bHkgZmFpbFxyXG4gICAgLy8gYXJvdW5kIGV4dGVuc2lvbiBzdGFydHVwOyBzdXJmYWNpbmcgMCBpcyBmaW5lLlxyXG4gIH1cclxuICBjb25zdCByZWZldGNoUXVldWVkID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcclxuICBjb25zdCBtZWRpYUNyYXdsUXVldWVkID0gYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTtcclxuICBjb25zdCB0aHJlYWRPcGVuUXVldWVkID0gYXdhaXQgdGhyZWFkT3BlblF1ZXVlVG90YWwoKTtcclxuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XHJcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xyXG4gIGNvbnN0IHRocmVhZE9wZW5TZXNzID0gYXdhaXQgZ2V0VGhyZWFkT3BlblNlc3Npb24oKTtcclxuICBjb25zdCBhdXRvU2Nyb2xsU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgY29uc3QgcmVjZW50VHdlZXRTaWdodGluZ3MgPSBhd2FpdCBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncygpO1xyXG4gIHJldHVybiB7XHJcbiAgICB2ZXJzaW9uOiBFWFRfVkVSU0lPTixcclxuICAgIHNldHRpbmdzOiByZWRhY3RTZXR0aW5ncyhzZXR0aW5ncyksXHJcbiAgICBjb25uZWN0aW9uOiBjb25uLFxyXG4gICAgYWNjb3VudHMsXHJcbiAgICBjb3VudGVycyxcclxuICAgIGF1dG9TY3JvbGw6IHtcclxuICAgICAgYWN0aXZlOiBhdXRvU2Nyb2xsU2VzcyAhPT0gbnVsbCAmJiBhdXRvU2Nyb2xsVGltZXIgIT09IG51bGwsXHJcbiAgICAgIHRhYkNvdW50LFxyXG4gICAgICBzY3JvbGxDb3VudDogYXV0b1Njcm9sbFNlc3M/LnNjcm9sbENvdW50ID8/IDAsXHJcbiAgICAgIGluZ2VzdGVkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5pbmdlc3RlZENvdW50ID8/IDAsXHJcbiAgICAgIGluZ2VzdGVkTmV3Q291bnQ6IGF1dG9TY3JvbGxTZXNzPy5pbmdlc3RlZE5ld0NvdW50ID8/IDAsXHJcbiAgICAgIGluZ2VzdGVkRXhpc3RpbmdDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkRXhpc3RpbmdDb3VudCA/PyAwLFxyXG4gICAgICBza2lwcGVkT2xkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5za2lwcGVkT2xkQ291bnQgPz8gMCxcclxuICAgICAgZXhwYW5kZWRDb3VudDogYXV0b1Njcm9sbFNlc3M/LmV4cGFuZGVkQ291bnQgPz8gMCxcclxuICAgIH0sXHJcbiAgICByZWZldGNoUXVldWU6IHtcclxuICAgICAgdG90YWw6IHJlZmV0Y2hRdWV1ZWQsXHJcbiAgICAgIHJ1bm5pbmc6IHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcclxuICAgICAgcHJvY2Vzc2VkOiByZWZldGNoU2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiByZWZldGNoU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXHJcbiAgICB9LFxyXG4gICAgbWVkaWFDcmF3bFF1ZXVlOiB7XHJcbiAgICAgIHRvdGFsOiBtZWRpYUNyYXdsUXVldWVkLFxyXG4gICAgICBydW5uaW5nOiBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwsXHJcbiAgICAgIHByb2Nlc3NlZDogbWVkaWFDcmF3bFNlc3M/LnByb2Nlc3NlZCA/PyAwLFxyXG4gICAgICB0b3RhbF9hdF9zdGFydDogbWVkaWFDcmF3bFNlc3M/LnRvdGFsQXRTdGFydCA/PyAwLFxyXG4gICAgfSxcclxuICAgIHRocmVhZE9wZW5RdWV1ZToge1xyXG4gICAgICB0b3RhbDogdGhyZWFkT3BlblF1ZXVlZCxcclxuICAgICAgcnVubmluZzogdGhyZWFkT3BlbkludGVydmFsSGFuZGxlICE9PSBudWxsLFxyXG4gICAgICBwcm9jZXNzZWQ6IHRocmVhZE9wZW5TZXNzPy5wcm9jZXNzZWQgPz8gMCxcclxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHRocmVhZE9wZW5TZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcclxuICAgIH0sXHJcbiAgICByZWNlbnRUd2VldFNpZ2h0aW5ncyxcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiByZWRhY3RTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IEV4dGVuc2lvblN0YXRlWydzZXR0aW5ncyddIHtcclxuICByZXR1cm4ge1xyXG4gICAgb3duZXI6IHMub3duZXIsXHJcbiAgICByZXBvOiBzLnJlcG8sXHJcbiAgICBicmFuY2g6IHMuYnJhbmNoLFxyXG4gICAgZW5hYmxlZDogcy5lbmFibGVkLFxyXG4gICAgYXV0b0NhcHR1cmU6IHMuYXV0b0NhcHR1cmUsXHJcbiAgICBjb25maWd1cmVkQXQ6IHMuY29uZmlndXJlZEF0LFxyXG4gICAgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyxcclxuICAgIHVwZGF0ZUV4aXN0aW5nOiBzLnVwZGF0ZUV4aXN0aW5nLFxyXG4gICAgcGF0U2V0OiBzLnBhdC5sZW5ndGggPiAwLFxyXG4gICAgcGF0U3VmZml4OiBzLnBhdC5sZW5ndGggPj0gNCA/IHMucGF0LnNsaWNlKC00KSA6ICcnLFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhcnNlQXJjaGl2ZVNuYXBzaG90KHJhdzogdW5rbm93bik6IEFyY2hpdmVTbmFwc2hvdCB7XHJcbiAgaWYgKCFyYXcgfHwgdHlwZW9mIHJhdyAhPT0gJ29iamVjdCcpIHRocm93IG5ldyBFcnJvcignbWFuaWZlc3QgaXMgbm90IGFuIG9iamVjdCcpO1xyXG4gIGNvbnN0IG1hbmlmZXN0ID0gcmF3IGFzIHsgZ2VuZXJhdGVkX2F0PzogdW5rbm93bjsgYWNjb3VudHM/OiB1bmtub3duIH07XHJcbiAgaWYgKCFBcnJheS5pc0FycmF5KG1hbmlmZXN0LmFjY291bnRzKSkgdGhyb3cgbmV3IEVycm9yKCdtYW5pZmVzdC5hY2NvdW50cyBpcyBub3QgYW4gYXJyYXknKTtcclxuICBjb25zdCBhY2NvdW50czogQXJjaGl2ZVNuYXBzaG90WydhY2NvdW50cyddID0ge307XHJcbiAgZm9yIChjb25zdCBlbnRyeSBvZiBtYW5pZmVzdC5hY2NvdW50cykge1xyXG4gICAgaWYgKCFlbnRyeSB8fCB0eXBlb2YgZW50cnkgIT09ICdvYmplY3QnKSBjb250aW51ZTtcclxuICAgIGNvbnN0IHJvdyA9IGVudHJ5IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gICAgY29uc3QgaGFuZGxlID0gdHlwZW9mIHJvdy5oYW5kbGUgPT09ICdzdHJpbmcnID8gcm93LmhhbmRsZSA6ICcnO1xyXG4gICAgaWYgKCFoYW5kbGUgfHwgaGFuZGxlID09PSAnX21pc2MnKSBjb250aW51ZTtcclxuICAgIGFjY291bnRzW2hhbmRsZS50b0xvd2VyQ2FzZSgpXSA9IHtcclxuICAgICAgaGFuZGxlLFxyXG4gICAgICBsYXRlc3RfcG9zdF9hdDogdHlwZW9mIHJvdy5sYXRlc3RfcG9zdF9hdCA9PT0gJ3N0cmluZycgPyByb3cubGF0ZXN0X3Bvc3RfYXQgOiBudWxsLFxyXG4gICAgICBsYXRlc3RfY2FwdHVyZV9hdDogdHlwZW9mIHJvdy5sYXRlc3RfY2FwdHVyZV9hdCA9PT0gJ3N0cmluZycgPyByb3cubGF0ZXN0X2NhcHR1cmVfYXQgOiBudWxsLFxyXG4gICAgICByb3dfY291bnQ6IHR5cGVvZiByb3cucm93X2NvdW50ID09PSAnbnVtYmVyJyA/IHJvdy5yb3dfY291bnQgOiBudWxsLFxyXG4gICAgfTtcclxuICB9XHJcbiAgcmV0dXJuIHtcclxuICAgIGdlbmVyYXRlZF9hdDogdHlwZW9mIG1hbmlmZXN0LmdlbmVyYXRlZF9hdCA9PT0gJ3N0cmluZycgPyBtYW5pZmVzdC5nZW5lcmF0ZWRfYXQgOiBudWxsLFxyXG4gICAgZmV0Y2hlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgYWNjb3VudHMsXHJcbiAgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gYXJjaGl2ZVNuYXBzaG90SGFzVHdlZXQodDogQ2Fub25pY2FsVHdlZXQsIHNuYXBzaG90OiBBcmNoaXZlU25hcHNob3QgfCBudWxsKTogYm9vbGVhbiB7XHJcbiAgaWYgKCFzbmFwc2hvdCkgcmV0dXJuIGZhbHNlO1xyXG4gIGNvbnN0IGVudHJ5ID0gc25hcHNob3QuYWNjb3VudHNbdC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpXTtcclxuICBpZiAoIWVudHJ5Py5sYXRlc3RfcG9zdF9hdCkgcmV0dXJuIGZhbHNlO1xyXG4gIGNvbnN0IHBvc3RlZCA9IERhdGUucGFyc2UodC5wb3N0ZWRfYXQpO1xyXG4gIGNvbnN0IGxhdGVzdCA9IERhdGUucGFyc2UoZW50cnkubGF0ZXN0X3Bvc3RfYXQpO1xyXG4gIHJldHVybiBOdW1iZXIuaXNGaW5pdGUocG9zdGVkKSAmJiBOdW1iZXIuaXNGaW5pdGUobGF0ZXN0KSAmJiBwb3N0ZWQgPD0gbGF0ZXN0O1xyXG59XHJcblxyXG5mdW5jdGlvbiBidWlsZFR3ZWV0U2lnaHRpbmcoXHJcbiAgdDogQ2Fub25pY2FsVHdlZXQsXHJcbiAgZW5kcG9pbnQ6IHN0cmluZyxcclxuICBzZWVuQXQ6IHN0cmluZyxcclxuICBmcmVzaG5lc3M6ICduZXcnIHwgJ2V4aXN0aW5nJyA9ICduZXcnLFxyXG4gIGFjdGlvbjogVHdlZXRTaWdodGluZ1snYWN0aW9uJ10gPSAnYnVmZmVyZWQnXHJcbik6IFR3ZWV0U2lnaHRpbmcge1xyXG4gIHJldHVybiB7XHJcbiAgICB0d2VldF9pZDogdC50d2VldF9pZCxcclxuICAgIGFjY291bnRfaGFuZGxlOiB0LmFjY291bnRfaGFuZGxlLFxyXG4gICAgcG9zdGVkX2F0OiB0LnBvc3RlZF9hdCxcclxuICAgIHRleHQ6IHQudGV4dF9yZXNvbHZlZCB8fCB0LnRleHQsXHJcbiAgICB0d2VldF90eXBlOiB0LnR3ZWV0X3R5cGUsXHJcbiAgICB0d2VldF91cmw6IHQudHdlZXRfdXJsLFxyXG4gICAgc2Vlbl9hdDogc2VlbkF0LFxyXG4gICAgZW5kcG9pbnQsXHJcbiAgICBhcmNoaXZlX3N0YXR1czogZnJlc2huZXNzID09PSAnZXhpc3RpbmcnID8gJ3NhdmVkJyA6ICduZXcnLFxyXG4gICAgYWN0aW9uLFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGlzV3JpdGVBdXRoRXJyb3IobWVzc2FnZTogc3RyaW5nIHwgbnVsbCk6IGJvb2xlYW4ge1xyXG4gIHJldHVybiAoXHJcbiAgICB0eXBlb2YgbWVzc2FnZSA9PT0gJ3N0cmluZycgJiZcclxuICAgIC9SZXNvdXJjZSBub3QgYWNjZXNzaWJsZSBieSBwZXJzb25hbCBhY2Nlc3MgdG9rZW58XFwvZ2l0XFwvYmxvYnN8XFwvZ2l0XFwvcmVmcy9pLnRlc3QobWVzc2FnZSlcclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBpc29Db21wYWN0KGlzbzogc3RyaW5nKTogc3RyaW5nIHtcclxuICAvLyAyMDI1LTA0LTEyVDE0OjIzOjAxLjAwMFogXHUyMTkyIDIwMjUtMDQtMTJUMTQyMzAxWlxyXG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShpc28pO1xyXG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gaXNvLnJlcGxhY2UoL1s6Ll0vZywgJycpO1xyXG4gIGNvbnN0IHBhZCA9IChuOiBudW1iZXIsIHcgPSAyKSA9PiBTdHJpbmcobikucGFkU3RhcnQodywgJzAnKTtcclxuICByZXR1cm4gKFxyXG4gICAgYCR7ZC5nZXRVVENGdWxsWWVhcigpfS0ke3BhZChkLmdldFVUQ01vbnRoKCkgKyAxKX0tJHtwYWQoZC5nZXRVVENEYXRlKCkpfWAgK1xyXG4gICAgYFQke3BhZChkLmdldFVUQ0hvdXJzKCkpfSR7cGFkKGQuZ2V0VVRDTWludXRlcygpKX0ke3BhZChkLmdldFVUQ1NlY29uZHMoKSl9WmBcclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiB2aWV3ZXJVcmwoczogU2V0dGluZ3MpOiBzdHJpbmcge1xyXG4gIHJldHVybiBgaHR0cHM6Ly8ke3Mub3duZXJ9LmdpdGh1Yi5pby8ke3MucmVwb30vYDtcclxufVxyXG5cclxuLyoqXHJcbiAqIFdhbGsgYG5vZGVgIGNvbGxlY3RpbmcgZG90dGVkIGtleSBwYXRocyB1cCB0byBgbWF4RGVwdGhgIGRlZXAuIEFycmF5XHJcbiAqIGluZGljZXMgY29sbGFwc2UgdG8gYFswXWAgKHdlIG9ubHkgZGVzY2VuZCBpbnRvIHRoZSBmaXJzdCBlbGVtZW50KS4gVXNlZFxyXG4gKiB0byBzdXJmYWNlIHRoZSBzdHJ1Y3R1cmFsIHNrZWxldG9uIG9mIGFuIHVuZmFtaWxpYXIgR3JhcGhRTCByZXNwb25zZVxyXG4gKiB3aXRob3V0IGluY2x1ZGluZyBhbnkgZGF0YSB2YWx1ZXMuXHJcbiAqL1xyXG4vKiogQ29sbGVjdCBldmVyeSBkaXN0aW5jdCBgX190eXBlbmFtZWAgdmFsdWUgZm91bmQgYW55d2hlcmUgaW4gdGhlIHRyZWUuICovXHJcbmZ1bmN0aW9uIHByb2JlVHlwZW5hbWVzKG5vZGU6IHVua25vd24pOiBzdHJpbmdbXSB7XHJcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xyXG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcclxuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xyXG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gICAgICBpZiAodHlwZW9mIG9iai5fX3R5cGVuYW1lID09PSAnc3RyaW5nJykgc2Vlbi5hZGQob2JqLl9fdHlwZW5hbWUpO1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gWy4uLnNlZW5dLnNvcnQoKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZpbmQgdGhlIGZpcnN0IG5vZGUgYW55d2hlcmUgaW4gdGhlIHRyZWUgd2hvc2UgYF9fdHlwZW5hbWVgIG1hdGNoZXMgYW5kXHJcbiAqIHJldHVybiBpdHMgdG9wLWxldmVsIGtleSBsaXN0IChzb3J0ZWQpLiBVc2VmdWwgZm9yIGRpc2NvdmVyaW5nIHdoYXQgZmllbGRzXHJcbiAqIFggaXMgYWN0dWFsbHkgc2hpcHBpbmcgZm9yIGEgZ2l2ZW4gbm9kZSB0eXBlIGFmdGVyIGEgc2NoZW1hIGNoYW5nZS5cclxuICovXHJcbmZ1bmN0aW9uIHByb2JlRmlyc3RUeXBlU2hhcGUobm9kZTogdW5rbm93biwgdHlwZW5hbWU6IHN0cmluZyk6IHN0cmluZ1tdIHwgbnVsbCB7XHJcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcclxuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xyXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAobiA9PT0gbnVsbCB8fCB0eXBlb2YgbiAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XHJcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheShuKSkge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IG9iaiA9IG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcbiAgICAgIGlmIChvYmouX190eXBlbmFtZSA9PT0gdHlwZW5hbWUpIHtcclxuICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMob2JqKS5zb3J0KCk7XHJcbiAgICAgIH1cclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIHdpdGggYF9fdHlwZW5hbWUgPT09IHR5cGVuYW1lYCwgdGhlbiBkZXNjZW5kIHRocm91Z2hcclxuICogdGhlIGdpdmVuIGtleSBwYXRoLCBhbmQgcmV0dXJuIHRoZSB0b3AtbGV2ZWwga2V5cyBvZiB3aGF0ZXZlciBpcyBhdCB0aGVcclxuICogZW5kLiBSZXR1cm5zIGEgbWFya2VyIHN0cmluZyB3aGVuIHRoZSBwYXRoIGxlYWRzIHNvbWV3aGVyZSBub24tb2JqZWN0IHNvXHJcbiAqIHdlIGNhbiB0ZWxsIGFwYXJ0IFwiYWJzZW50XCIgZnJvbSBcInByZXNlbnQgYnV0IG5vdCBhbiBvYmplY3RcIi5cclxuICovXHJcbmZ1bmN0aW9uIHByb2JlVHlwZWROZXN0ZWQobm9kZTogdW5rbm93biwgdHlwZW5hbWU6IHN0cmluZywgcGF0aDogc3RyaW5nW10pOiB1bmtub3duIHtcclxuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xyXG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XHJcbiAgbGV0IGZvdW5kOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwgPSBudWxsO1xyXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAobiA9PT0gbnVsbCB8fCB0eXBlb2YgbiAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XHJcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheShuKSkge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IG9iaiA9IG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcbiAgICAgIGlmIChvYmouX190eXBlbmFtZSA9PT0gdHlwZW5hbWUpIHtcclxuICAgICAgICBmb3VuZCA9IG9iajtcclxuICAgICAgICBicmVhaztcclxuICAgICAgfVxyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfVxyXG4gIH1cclxuICBpZiAoIWZvdW5kKSByZXR1cm4gbnVsbDtcclxuICBsZXQgY3VyOiB1bmtub3duID0gZm91bmQ7XHJcbiAgZm9yIChjb25zdCBzZWcgb2YgcGF0aCkge1xyXG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgcmV0dXJuIGA8JHtjdXIgPT09IG51bGwgPyAnbnVsbCcgOiB0eXBlb2YgY3VyfT5gO1xyXG4gICAgY3VyID0gKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilbc2VnXTtcclxuICB9XHJcbiAgaWYgKGN1ciA9PT0gdW5kZWZpbmVkKSByZXR1cm4gJzxtaXNzaW5nPic7XHJcbiAgaWYgKGN1ciA9PT0gbnVsbCkgcmV0dXJuICc8bnVsbD4nO1xyXG4gIGlmICh0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgcmV0dXJuIGA8JHt0eXBlb2YgY3VyfT5gO1xyXG4gIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHJldHVybiBgPGFycmF5IGxlbj0ke2N1ci5sZW5ndGh9PmA7XHJcbiAgcmV0dXJuIE9iamVjdC5rZXlzKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuc29ydCgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzaG9ydGVuVXJsKHU6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgLy8gQWN0aXZpdHktdGFpbCBjb250ZXh0IGlzIG1vcmUgdXNlZnVsIHdpdGgganVzdCB0aGUgcGF0aDsgZnVsbCBVUkxzIGJlY29tZVxyXG4gIC8vIGhhcmQgdG8gcmVhZCBhdCB0aGUgc2lkZWJhcidzIHdpZHRoLlxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBwYXJzZWQgPSBuZXcgVVJMKHUpO1xyXG4gICAgY29uc3QgcGF0aCA9IHBhcnNlZC5wYXRobmFtZSArIChwYXJzZWQuc2VhcmNoID8gJz9cdTIwMjYnIDogJycpO1xyXG4gICAgcmV0dXJuIHBhcnNlZC5ob3N0ID09PSAneC5jb20nIHx8IHBhcnNlZC5ob3N0ID09PSAndHdpdHRlci5jb20nXHJcbiAgICAgID8gcGF0aFxyXG4gICAgICA6IGAke3BhcnNlZC5ob3N0fSR7cGF0aH1gO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIHUubGVuZ3RoID4gODAgPyBgJHt1LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLSBEZXYgaGVscGVycyBleHBvc2VkIG9uIGdsb2JhbFRoaXMgZm9yIHRoZSBkZXZ0b29scyBjb25zb2xlIC0tLS0tLS0tLS1cclxuLy8gKGUuZy4gYF9faW1tQXJjaGl2ZS5jbGVhckFsbCgpYCBpbiB0aGUgYmFja2dyb3VuZCB3b3JrZXIncyBkZXZ0b29scykuXHJcblxyXG4oZ2xvYmFsVGhpcyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuX19pbW1BcmNoaXZlID0ge1xyXG4gIGNsZWFyQWxsLFxyXG4gIGFjdGl2aXR5OiBnZXRBY3Rpdml0eSxcclxuICBhY2NvdW50czogZ2V0QWNjb3VudHMsXHJcbiAgYnVmZmVyczogZ2V0UnVuQnVmZmVycyxcclxuICBmbHVzaEFsbDogKCkgPT4gZmx1c2hBbGwoJ2RldnRvb2xzJyksXHJcbiAgc3RhdGU6IGJ1aWxkU3RhdGUsXHJcbiAgcmVmZXRjaFF1ZXVlOiBnZXRSZWZldGNoUXVldWUsXHJcbiAgc3RhcnRSZWZldGNoOiBzdGFydFJlZmV0Y2hMb29wLFxyXG4gIGNhbmNlbFJlZmV0Y2g6IGNhbmNlbFJlZmV0Y2hMb29wLFxyXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogZ2V0TWVkaWFDcmF3bFF1ZXVlLFxyXG4gIHN0YXJ0TWVkaWFDcmF3bDogc3RhcnRNZWRpYUNyYXdsTG9vcCxcclxuICBjYW5jZWxNZWRpYUNyYXdsOiBjYW5jZWxNZWRpYUNyYXdsTG9vcCxcclxuICB0aHJlYWRPcGVuUXVldWU6IGdldFRocmVhZE9wZW5RdWV1ZSxcclxuICBzdGFydFRocmVhZE9wZW46IHN0YXJ0VGhyZWFkT3Blbkxvb3AsXHJcbiAgY2FuY2VsVGhyZWFkT3BlbjogY2FuY2VsVGhyZWFkT3Blbkxvb3AsXHJcbn07XHJcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFBQSxFQUNQLE1BQU07QUFBQTtBQUFBO0FBQUEsRUFHTixRQUFRO0FBQUEsRUFDUixTQUFTO0FBQUEsRUFDVCxhQUFhO0FBQUEsRUFDYixjQUFjO0FBQUEsRUFDZCx1QkFBdUI7QUFBQSxFQUN2QixnQkFBZ0I7QUFDbEI7QUFFTyxJQUFNLHNCQUFzQjtBQUM1QixJQUFNLHNCQUFzQjtBQUk1QixJQUFNLG9CQUFxQztBQUFBLEVBQ2hELEVBQUUsUUFBUSxVQUFVLE9BQU8sbUNBQW1DLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxVQUFVLE9BQU8sNENBQTRDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxPQUFPLE9BQU8sc0NBQXNDLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxTQUFTLE9BQU8sNkNBQTZDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxjQUFjLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUFBLEVBQ25FLEVBQUUsUUFBUSxZQUFZLE9BQU8sK0JBQStCLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sa0NBQWtDLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sNEJBQTRCLFVBQVUsT0FBTztBQUFBLEVBQ3ZFLEVBQUUsUUFBUSxtQkFBbUIsT0FBTyxxQkFBcUIsVUFBVSxPQUFPO0FBQzVFO0FBR08sSUFBTSxrQkFBdUMsb0JBQUksSUFBSTtBQUFBLEVBQzFEO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBV00sSUFBTSxvQkFBeUMsb0JBQUksSUFBSSxDQUFDLG9CQUFvQixjQUFjLENBQUM7QUF1QjNGLElBQU0sd0JBQXdCO0FBRzlCLElBQU0sZ0JBQWdCO0FBR3RCLElBQU0sc0JBQXNCO0FBRzVCLElBQU0sb0JBQW9CO0FBRzFCLElBQU0sZ0NBQWdDLEtBQUssS0FBSztBQUVoRCxJQUFNLG1CQUFtQjs7O0FDdkVoQyxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGtCQUFrQjtBQUV4QixJQUFJLGtCQUFvQztBQUN4QyxJQUFJLHNCQUFxQztBQUV6QyxTQUFTLFNBQVMsS0FBeUI7QUFDekMsTUFBSSxJQUFJO0FBQ1IsYUFBVyxLQUFLLElBQUssTUFBSyxPQUFPLGFBQWEsQ0FBQztBQUMvQyxTQUFPLEtBQUssQ0FBQztBQUNmO0FBRUEsU0FBUyxXQUFXLEdBQXVCO0FBQ3pDLFFBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsUUFBTSxNQUFNLElBQUksV0FBVyxJQUFJLE1BQU07QUFDckMsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsSUFBSyxLQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQztBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxlQUFlLG1CQUFtRTtBQUNoRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUMvRCxRQUFNLElBQUksT0FBTyxnQkFBZ0I7QUFDakMsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxXQUFPLEVBQUUsU0FBUyxHQUFHLE1BQU0sV0FBVyxDQUFDLEVBQUU7QUFBQSxFQUMzQztBQUNBLFFBQU0sT0FBTyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxTQUFTLElBQUk7QUFDN0IsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUM7QUFDL0QsU0FBTyxFQUFFLFNBQVMsS0FBSztBQUN6QjtBQUVBLGVBQWUsWUFBZ0M7QUFDN0MsUUFBTSxFQUFFLFNBQVMsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBQ2pELE1BQUksb0JBQW9CLFFBQVEsd0JBQXdCLFNBQVM7QUFDL0QsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUU7QUFBQSxJQUM3QixHQUFHLFFBQVEsUUFBUSxFQUFFLElBQUksUUFBUSxRQUFRLFlBQVksRUFBRSxPQUFPO0FBQUEsRUFDaEU7QUFDQSxRQUFNLFdBQVcsSUFBSSxXQUFXLEtBQUssU0FBUyxLQUFLLE1BQU07QUFDekQsV0FBUyxJQUFJLE1BQU0sQ0FBQztBQUNwQixXQUFTLElBQUksTUFBTSxLQUFLLE1BQU07QUFDOUIsUUFBTSxPQUFPLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxRQUFRO0FBQzNELFFBQU0sTUFBTSxNQUFNLE9BQU8sT0FBTyxVQUFVLE9BQU8sTUFBTSxFQUFFLE1BQU0sVUFBVSxHQUFHLE9BQU87QUFBQSxJQUNqRjtBQUFBLElBQ0E7QUFBQSxFQUNGLENBQUM7QUFDRCxvQkFBa0I7QUFDbEIsd0JBQXNCO0FBQ3RCLFNBQU87QUFDVDtBQUVPLFNBQVMsZUFBZSxHQUFvQjtBQUNqRCxTQUFPLEVBQUUsV0FBVyxlQUFlO0FBQ3JDO0FBRUEsZUFBc0IsV0FBVyxXQUFvQztBQUNuRSxNQUFJLENBQUMsVUFBVyxRQUFPO0FBQ3ZCLFFBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsUUFBTSxLQUFLLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDcEQsUUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsSUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBRztBQUFBLElBQ3RCO0FBQUEsSUFDQSxJQUFJLFlBQVksRUFBRSxPQUFPLFNBQVM7QUFBQSxFQUNwQztBQUNBLFNBQU8sR0FBRyxlQUFlLEdBQUcsU0FBUyxFQUFFLENBQUMsSUFBSSxTQUFTLElBQUksV0FBVyxFQUFFLENBQUMsQ0FBQztBQUMxRTtBQUVBLGVBQXNCLFdBQVcsVUFBbUM7QUFDbEUsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUd0QixNQUFJLENBQUMsU0FBUyxXQUFXLGVBQWUsRUFBRyxRQUFPO0FBQ2xELFFBQU0sUUFBUSxTQUFTLE1BQU0sZ0JBQWdCLE1BQU0sRUFBRSxNQUFNLEdBQUc7QUFDOUQsTUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBQy9CLFFBQU0sQ0FBQyxPQUFPLEtBQUssSUFBSTtBQUN2QixNQUFJLENBQUMsU0FBUyxDQUFDLE1BQU8sUUFBTztBQUM3QixNQUFJO0FBQ0YsVUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsTUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBdUI7QUFBQSxNQUMxQztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsV0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEVBQUU7QUFBQSxFQUNwQyxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjs7O0FDWEEsSUFBTSxxQkFBc0M7QUFBQSxFQUMxQyxRQUFRO0FBQUEsRUFDUixPQUFPO0FBQUEsRUFDUCxXQUFXO0FBQUEsRUFDWCxPQUFPO0FBQUEsRUFDUCxlQUFlO0FBQUEsRUFDZix3QkFBd0I7QUFBQSxFQUN4QixrQkFBa0I7QUFDcEI7QUFFQSxJQUFNLFdBQXlCO0FBQUEsRUFDN0IsVUFBVSxFQUFFLEdBQUcsaUJBQWlCO0FBQUEsRUFDaEMsVUFBVSxDQUFDLEdBQUcsaUJBQWlCO0FBQUEsRUFDL0IscUJBQXFCO0FBQUEsRUFDckIsaUJBQWlCO0FBQUEsRUFDakIsWUFBWSxFQUFFLEdBQUcsbUJBQW1CO0FBQUEsRUFDcEMsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLENBQUM7QUFBQSxFQUNiLFVBQVUsQ0FBQztBQUFBLEVBQ1gsc0JBQXNCLENBQUM7QUFBQSxFQUN2QixnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGNBQWMsQ0FBQztBQUFBLEVBQ2YsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixpQkFBaUIsQ0FBQztBQUFBLEVBQ2xCLGdCQUFnQixDQUFDO0FBQUEsRUFDakIsZ0JBQWdCO0FBQUEsRUFDaEIsbUJBQW1CO0FBQUEsRUFDbkIsbUJBQW1CO0FBQUEsRUFDbkIsbUJBQW1CO0FBQ3JCO0FBRUEsZUFBZSxPQUFxQyxLQUFrQztBQUNwRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDbEQsUUFBTSxRQUFRLE9BQU8sR0FBRztBQUN4QixNQUFJLFVBQVUsUUFBVztBQUN2QixXQUFPLGdCQUFnQixTQUFTLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBQ0EsU0FBTztBQUNUO0FBRUEsZUFBZSxPQUFxQyxLQUFRLE9BQXVDO0FBQ2pHLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQztBQUNsRDtBQUlBLGVBQXNCLGNBQWlDO0FBS3JELFFBQU0sU0FBUyxNQUFNLE9BQU8sVUFBVTtBQUN0QyxRQUFNLFNBQVMsRUFBRSxHQUFHLGtCQUFrQixHQUFHLE9BQU87QUFDaEQsTUFBSSxPQUFPLE9BQU8sZUFBZSxPQUFPLEdBQUcsR0FBRztBQUM1QyxRQUFJO0FBQ0YsYUFBTyxNQUFNLE1BQU0sV0FBVyxPQUFPLEdBQUc7QUFBQSxJQUMxQyxRQUFRO0FBQ04sYUFBTyxNQUFNO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixZQUFZLEdBQTRCO0FBRzVELFFBQU0sVUFBb0IsRUFBRSxHQUFHLEVBQUU7QUFDakMsTUFBSSxRQUFRLE9BQU8sQ0FBQyxlQUFlLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFlBQVEsTUFBTSxNQUFNLFdBQVcsUUFBUSxHQUFHO0FBQUEsRUFDNUM7QUFDQSxRQUFNLE9BQU8sWUFBWSxPQUFPO0FBQ2xDO0FBQ0EsZUFBc0IsZUFBZSxPQUE2QztBQUNoRixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEMsUUFBTSxZQUFZLElBQUk7QUFDdEIsU0FBTztBQUNUO0FBSUEsZUFBc0IsY0FBd0M7QUFDNUQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUFZLEdBQW1DO0FBQ25FLFFBQU0sT0FBTyxZQUFZLENBQUM7QUFDNUI7QUFDQSxlQUFzQix5QkFBaUQ7QUFDckUsU0FBTyxPQUFPLHFCQUFxQjtBQUNyQztBQUNBLGVBQXNCLHVCQUF1QixLQUFtQztBQUM5RSxRQUFNLE9BQU8sdUJBQXVCLEdBQUc7QUFDekM7QUFJQSxlQUFzQixxQkFBc0Q7QUFDMUUsU0FBTyxPQUFPLGlCQUFpQjtBQUNqQztBQUVBLGVBQXNCLG1CQUFtQixVQUFpRDtBQUN4RixRQUFNLE9BQU8sbUJBQW1CLFFBQVE7QUFDMUM7QUFJQSxlQUFzQixnQkFBMEM7QUFDOUQsUUFBTSxJQUFJLE1BQU0sT0FBTyxZQUFZO0FBRW5DLFFBQU0sTUFBdUI7QUFBQSxJQUMzQixHQUFHO0FBQUEsSUFDSCxlQUFlLEVBQUUsa0JBQWtCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDeEQsd0JBQ0UsRUFBRSwyQkFBMkIsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUNwRCxrQkFBa0IsRUFBRSxxQkFBcUIsU0FBWSxPQUFPLEVBQUU7QUFBQSxFQUNoRTtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLGNBQWMsR0FBbUM7QUFDckUsUUFBTSxPQUFPLGNBQWMsQ0FBQztBQUM5QjtBQUlBLFNBQVMsV0FBbUI7QUFDMUIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQzdDO0FBRUEsZUFBc0IsY0FBdUQ7QUFDM0UsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUNwQixRQUNBLE9BQ3lCO0FBQ3pCLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxNQUFNLElBQUksTUFBTSxLQUFLO0FBQUEsSUFDekIsWUFBWTtBQUFBLElBQ1osV0FBVyxTQUFTO0FBQUEsSUFDcEIsZUFBZTtBQUFBLElBQ2YsZ0JBQWdCO0FBQUEsSUFDaEIsZUFBZTtBQUFBLEVBQ2pCO0FBQ0EsTUFBSSxJQUFJLGNBQWMsU0FBUyxHQUFHO0FBQ2hDLFFBQUksWUFBWSxTQUFTO0FBQ3pCLFFBQUksYUFBYTtBQUFBLEVBQ25CO0FBQ0EsUUFBTSxPQUF1QixFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEQsTUFBSSxNQUFNLElBQUk7QUFDZCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGlCQUFpQixRQUFnQixPQUE4QjtBQUNuRixRQUFNLFlBQVksUUFBUSxFQUFFLGVBQWUsTUFBTSxDQUFDO0FBQ3BEO0FBSUEsZUFBc0IsZ0JBQW9EO0FBQ3hFLFNBQU8sT0FBTyxZQUFZO0FBQzVCO0FBRUEsZUFBc0IsYUFBYSxRQUEyQztBQUM1RSxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFNBQU8sSUFBSSxNQUFNLEtBQUs7QUFDeEI7QUFFQSxlQUFzQixhQUFhLFFBQWdCLEtBQStCO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsTUFBSSxNQUFNLElBQUk7QUFDZCxRQUFNLE9BQU8sY0FBYyxHQUFHO0FBQ2hDO0FBRUEsZUFBc0IsZUFBZSxRQUErQjtBQUNsRSxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFNBQU8sSUFBSSxNQUFNO0FBQ2pCLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFJQSxlQUFzQixjQUFtQztBQUN2RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUVBLGVBQXNCLGVBQWUsSUFBbUM7QUFDdEUsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixNQUFJLFFBQVEsRUFBRTtBQUNkLE1BQUksSUFBSSxTQUFTLGtCQUFtQixLQUFJLFNBQVM7QUFDakQsUUFBTSxPQUFPLFlBQVksR0FBRztBQUM1QixTQUFPO0FBQ1Q7QUFFQSxlQUFzQixnQkFBK0I7QUFDbkQsUUFBTSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQzdCO0FBSUEsSUFBTSw2QkFBNkI7QUFFbkMsZUFBc0IsMEJBQW9EO0FBQ3hFLFNBQU8sT0FBTyxzQkFBc0I7QUFDdEM7QUFFQSxlQUFzQiw0QkFBNEIsTUFBc0M7QUFDdEYsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixRQUFNLE1BQU0sTUFBTSx3QkFBd0I7QUFDMUMsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxPQUF3QixDQUFDO0FBQy9CLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFVBQU0sTUFBTSxHQUFHLElBQUksZUFBZSxZQUFZLENBQUMsSUFBSSxJQUFJLFFBQVE7QUFDL0QsUUFBSSxLQUFLLElBQUksR0FBRyxFQUFHO0FBQ25CLFNBQUssSUFBSSxHQUFHO0FBQ1osU0FBSyxLQUFLLEdBQUc7QUFBQSxFQUNmO0FBQ0EsYUFBVyxPQUFPLEtBQUs7QUFDckIsVUFBTSxNQUFNLEdBQUcsSUFBSSxlQUFlLFlBQVksQ0FBQyxJQUFJLElBQUksUUFBUTtBQUMvRCxRQUFJLEtBQUssSUFBSSxHQUFHLEVBQUc7QUFDbkIsU0FBSyxJQUFJLEdBQUc7QUFDWixTQUFLLEtBQUssR0FBRztBQUFBLEVBQ2Y7QUFDQSxPQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssUUFBUSwwQkFBMEI7QUFDOUQsUUFBTSxPQUFPLHdCQUF3QixJQUFJO0FBQzNDO0FBSUEsZUFBc0Isb0JBQTZFO0FBQ2pHLFNBQU8sT0FBTyxnQkFBZ0I7QUFDaEM7QUFFQSxlQUFzQixrQkFDcEIsS0FDZTtBQUNmLFFBQU0sT0FBTyxrQkFBa0IsR0FBRztBQUNwQztBQVVPLFNBQVMsY0FDZCxPQUNBLFVBQ0EsU0FDQSxRQUNBLGNBQXVCLE9BQ2Y7QUFDUixTQUFPLEdBQUcsS0FBSyxJQUFJLFFBQVEsSUFBSSxPQUFPLElBQUksTUFBTSxJQUFJLGNBQWMsTUFBTSxHQUFHO0FBQzdFO0FBR0EsZUFBc0Isb0JBQW9CLFVBQW1DO0FBQzNFLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxRQUFNLFNBQVMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLFFBQVEsRUFBRSxZQUFZO0FBQzNELE1BQUksU0FBUztBQUNiLGFBQVcsVUFBVSxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ3JDLFVBQU0sUUFBUSxJQUFJLE1BQU07QUFDeEIsUUFBSSxDQUFDLE1BQU87QUFDWixlQUFXLE9BQU8sT0FBTyxLQUFLLEtBQUssR0FBRztBQUNwQyxZQUFNLElBQUksTUFBTSxHQUFHO0FBQ25CLFVBQUksS0FBSyxFQUFFLEtBQUssUUFBUTtBQUN0QixlQUFPLE1BQU0sR0FBRztBQUNoQixrQkFBVTtBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLEtBQUssS0FBSyxFQUFFLFdBQVcsRUFBRyxRQUFPLElBQUksTUFBTTtBQUFBLEVBQ3hEO0FBQ0EsTUFBSSxTQUFTLEVBQUcsT0FBTSxrQkFBa0IsR0FBRztBQUMzQyxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixrQkFBcUQ7QUFDekUsU0FBTyxPQUFPLGNBQWM7QUFDOUI7QUFFQSxlQUFzQixvQkFBcUM7QUFDekQsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixlQUFlLFFBQWdCLFNBQWdDO0FBQ25GLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUFBLEVBQ2hDO0FBQ0Y7QUFFQSxlQUFzQixlQUFlLFFBQWdCLFNBQWdDO0FBQ25GLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxRQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLE1BQUksQ0FBQyxJQUFLO0FBQ1YsUUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxNQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUNqQixRQUFNLE9BQU8sZ0JBQWdCLENBQUM7QUFDaEM7QUFFQSxlQUFzQixvQkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLHFCQUF3RDtBQUM1RSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBRUEsZUFBc0IsdUJBQXdDO0FBQzVELFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0Isa0JBQWtCLFlBQTJCLFNBQWdDO0FBQ2pHLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxRQUFNLFNBQVMsY0FBYztBQUM3QixRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUFBLEVBQ25DO0FBQ0Y7QUFFQSxlQUFzQixrQkFBa0IsU0FBZ0M7QUFDdEUsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksVUFBVTtBQUNkLGFBQVcsVUFBVSxPQUFPLEtBQUssQ0FBQyxHQUFHO0FBQ25DLFVBQU0sTUFBTSxFQUFFLE1BQU07QUFDcEIsUUFBSSxDQUFDLElBQUs7QUFDVixVQUFNLFdBQVcsSUFBSSxPQUFPLENBQUMsT0FBTyxPQUFPLE9BQU87QUFDbEQsUUFBSSxTQUFTLFdBQVcsSUFBSSxRQUFRO0FBQ2xDLGdCQUFVO0FBQ1YsVUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLEVBQUUsTUFBTTtBQUFBLFVBQ3JDLEdBQUUsTUFBTSxJQUFJO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxRQUFTLE9BQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUNoRDtBQUVBLGVBQXNCLHVCQUdaO0FBQ1IsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFFBQUksSUFBSSxTQUFTLEVBQUcsUUFBTyxFQUFFLFFBQVEsU0FBUyxJQUFJLENBQUMsRUFBRztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0IscUJBQXdEO0FBQzVFLFNBQU8sT0FBTyxpQkFBaUI7QUFDakM7QUFFQSxlQUFzQix1QkFBd0M7QUFDNUQsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixrQkFBa0IsU0FBbUM7QUFDekUsUUFBTSxPQUFPLE1BQU0sT0FBTyxnQkFBZ0I7QUFDMUMsU0FBTyxXQUFXO0FBQ3BCO0FBRUEsZUFBc0IsbUJBQW1CLFNBQWdDO0FBQ3ZFLFFBQU0sT0FBTyxNQUFNLE9BQU8sZ0JBQWdCO0FBQzFDLE9BQUssT0FBTyxLQUFJLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ3ZDLFFBQU0sT0FBTyxrQkFBa0IsSUFBSTtBQUNyQztBQUVBLGVBQXNCLGtCQUFrQixRQUFnQixTQUFnQztBQUN0RixNQUFJLE1BQU0sa0JBQWtCLE9BQU8sRUFBRztBQUN0QyxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsUUFBTSxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDMUIsTUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUc7QUFDMUIsUUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBRSxNQUFNLElBQUk7QUFDWixVQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFBQSxFQUNuQztBQUNGO0FBRUEsZUFBc0Isa0JBQWtCLFNBQWdDO0FBQ3RFLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFVBQVU7QUFDZCxhQUFXLFVBQVUsT0FBTyxLQUFLLENBQUMsR0FBRztBQUNuQyxVQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsVUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELFFBQUksU0FBUyxXQUFXLElBQUksUUFBUTtBQUNsQyxnQkFBVTtBQUNWLFVBQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxVQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLE1BQUksUUFBUyxPQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFDaEQ7QUFFQSxlQUFzQix1QkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLFlBQVksU0FBbUM7QUFDbkUsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLGFBQVcsU0FBUyxPQUFPLE9BQU8sR0FBRyxHQUFHO0FBQ3RDLFFBQUksU0FBUyxXQUFXLE1BQU8sUUFBTztBQUFBLEVBQ3hDO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0Isb0JBQWlEO0FBQ3JFLFNBQU8sT0FBTyxnQkFBZ0I7QUFDaEM7QUFDQSxlQUFzQixrQkFBa0IsR0FBc0M7QUFDNUUsUUFBTSxPQUFPLGtCQUFrQixDQUFDO0FBQ2xDO0FBQ0EsZUFBc0IsdUJBQW9EO0FBQ3hFLFNBQU8sT0FBTyxtQkFBbUI7QUFDbkM7QUFDQSxlQUFzQixxQkFBcUIsR0FBc0M7QUFDL0UsUUFBTSxPQUFPLHFCQUFxQixDQUFDO0FBQ3JDO0FBQ0EsZUFBc0IsdUJBQW9EO0FBQ3hFLFNBQU8sT0FBTyxtQkFBbUI7QUFDbkM7QUFDQSxlQUFzQixxQkFBcUIsR0FBc0M7QUFDL0UsUUFBTSxPQUFPLHFCQUFxQixDQUFDO0FBQ3JDO0FBQ0EsZUFBc0IsdUJBQTBEO0FBQzlFLFNBQU8sT0FBTyxtQkFBbUI7QUFDbkM7QUFDQSxlQUFzQixxQkFBcUIsR0FBNEM7QUFDckYsUUFBTSxPQUFPLHFCQUFxQixDQUFDO0FBQ3JDO0FBWUEsZUFBc0Isb0JBQW9CLFVBT3ZDO0FBQ0QsUUFBTSxZQUFZLElBQUksSUFBSSxDQUFDLEdBQUcsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDbkUsUUFBTSxhQUFhLENBQUMsTUFBdUIsVUFBVSxJQUFJLEVBQUUsWUFBWSxDQUFDO0FBR3hFLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxrQkFBa0I7QUFDdEIsYUFBVyxLQUFLLE9BQU8sS0FBSyxRQUFRLEdBQUc7QUFDckMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sU0FBUyxDQUFDO0FBQ2pCLHlCQUFtQjtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxZQUFZLFFBQVE7QUFHakMsUUFBTSxVQUFVLE1BQU0sY0FBYztBQUNwQyxNQUFJLGlCQUFpQjtBQUNyQixhQUFXLEtBQUssT0FBTyxLQUFLLE9BQU8sR0FBRztBQUNwQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxRQUFRLENBQUM7QUFDaEIsd0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLGNBQWMsT0FBTztBQUdsQyxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsTUFBSSwwQkFBMEI7QUFDOUIsYUFBVyxLQUFLLE9BQU8sS0FBSyxHQUFHLEdBQUc7QUFDaEMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sSUFBSSxDQUFDO0FBQ1osaUNBQTJCO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxrQkFBa0IsR0FBRztBQUczQixRQUFNLEtBQUssTUFBTSxnQkFBZ0I7QUFDakMsTUFBSSx3QkFBd0I7QUFDNUIsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sR0FBRyxDQUFDO0FBQ1gsK0JBQXlCO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLGdCQUFnQixFQUFFO0FBSy9CLFFBQU0sS0FBSyxNQUFNLG1CQUFtQjtBQUNwQyxNQUFJLHVCQUF1QjtBQUMzQixhQUFXLEtBQUssT0FBTyxLQUFLLEVBQUUsR0FBRztBQUMvQixRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsK0JBQXlCLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRztBQUN0QyxhQUFPLEdBQUcsQ0FBQztBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLG1CQUFtQixFQUFFO0FBRWxDLFFBQU0sS0FBSyxNQUFNLG1CQUFtQjtBQUNwQyxNQUFJLHVCQUF1QjtBQUMzQixhQUFXLEtBQUssT0FBTyxLQUFLLEVBQUUsR0FBRztBQUMvQixRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsK0JBQXlCLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRztBQUN0QyxhQUFPLEdBQUcsQ0FBQztBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLG1CQUFtQixFQUFFO0FBRWxDLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFJQSxlQUFzQixXQUEwQjtBQUM5QyxRQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU07QUFDcEM7OztBQ2pxQkEsSUFBSSxZQUE2QztBQUUxQyxTQUFTLGVBQWUsSUFBa0M7QUFDL0QsY0FBWTtBQUNkO0FBRUEsU0FBUyxTQUFpQjtBQUN4QixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ2hDO0FBRUEsZUFBZSxLQUFLLE9BQWlCLEtBQWEsU0FBaUQ7QUFDakcsUUFBTSxLQUFlLEVBQUUsSUFBSSxPQUFPLEdBQUcsT0FBTyxLQUFLLFNBQVMsT0FBTyxPQUFPLEVBQUU7QUFFMUUsUUFBTSxPQUFPLGlCQUFpQixNQUFNLFlBQVksQ0FBQyxJQUFJLEdBQUc7QUFDeEQsTUFBSSxVQUFVLFFBQVMsU0FBUSxNQUFNLE1BQU0sR0FBRyxPQUFPO0FBQUEsV0FDNUMsVUFBVSxPQUFRLFNBQVEsS0FBSyxNQUFNLEdBQUcsT0FBTztBQUFBLE1BQ25ELFNBQVEsSUFBSSxNQUFNLEdBQUcsT0FBTztBQUVqQyxNQUFJO0FBQ0YsVUFBTSxlQUFlLEVBQUU7QUFBQSxFQUN6QixTQUFTLEtBQUs7QUFDWixZQUFRLEtBQUssMkNBQTJDLEdBQUc7QUFBQSxFQUM3RDtBQUVBLE1BQUk7QUFDRixnQkFBWSxFQUFFO0FBQUEsRUFDaEIsUUFBUTtBQUFBLEVBRVI7QUFDRjtBQUVPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxLQUFLLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN0RixTQUFPLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDbEM7QUFDTyxTQUFTLE1BQU0sS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3ZGLFNBQU8sS0FBSyxTQUFTLEtBQUssT0FBTztBQUNuQztBQUVPLFNBQVMsY0FBYyxLQUF5RDtBQUNyRixNQUFJLGVBQWUsT0FBTztBQUN4QixXQUFPLEVBQUUsU0FBUyxJQUFJLFNBQVMsT0FBTyxJQUFJLFNBQVMsS0FBSztBQUFBLEVBQzFEO0FBQ0EsTUFBSTtBQUNGLFdBQU8sRUFBRSxTQUFTLE9BQU8sR0FBRyxHQUFHLE9BQU8sS0FBSztBQUFBLEVBQzdDLFFBQVE7QUFDTixXQUFPLEVBQUUsU0FBUyx1QkFBdUIsT0FBTyxLQUFLO0FBQUEsRUFDdkQ7QUFDRjtBQU9BLFNBQVMsT0FBTyxLQUF1RDtBQUNyRSxRQUFNLE1BQStCLENBQUM7QUFDdEMsYUFBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDeEMsUUFBSSxFQUFFLFlBQVksRUFBRSxTQUFTLE9BQU8sS0FBSyxFQUFFLFlBQVksTUFBTSxTQUFTLE1BQU0saUJBQWlCO0FBQzNGLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWCxXQUFXLE9BQU8sTUFBTSxZQUFZLCtCQUErQixLQUFLLENBQUMsR0FBRztBQUMxRSxVQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsNkJBQTZCLHVCQUF1QjtBQUFBLElBQ3pFLFdBQVcsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLE1BQU07QUFDbkQsVUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLE1BQU0sR0FBRyxJQUFJLENBQUM7QUFBQSxJQUM5QixPQUFPO0FBQ0wsVUFBSSxDQUFDLElBQUk7QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDs7O0FDdkVBLElBQU0sV0FBVztBQUNqQixJQUFNLFdBQVc7QUErQlYsSUFBTSxjQUFOLGNBQTBCLE1BQU07QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUE7QUFBQSxFQUVBLFlBQVksTUFPVDtBQUNELFVBQU0sS0FBSyxPQUFPO0FBQ2xCLFNBQUssT0FBTztBQUNaLFNBQUssU0FBUyxLQUFLO0FBQ25CLFNBQUssT0FBTyxLQUFLO0FBQ2pCLFNBQUssWUFBWSxLQUFLO0FBQ3RCLFNBQUssV0FBVyxLQUFLO0FBQ3JCLFNBQUssbUJBQW1CLEtBQUssb0JBQW9CO0FBQUEsRUFDbkQ7QUFDRjtBQUVPLElBQU0sZUFBTixNQUFtQjtBQUFBLEVBQ1A7QUFBQSxFQUVqQixZQUFZLFVBQW9CO0FBQzlCLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUE7QUFBQSxFQUdBLE1BQU0sU0FBMEI7QUFDOUIsVUFBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTztBQUMvQyxXQUFRLElBQTJCLFNBQVM7QUFBQSxFQUM5QztBQUFBO0FBQUEsRUFHQSxNQUFNLGFBQWEsUUFBa0M7QUFDbkQsUUFBSTtBQUNGLFlBQU0sS0FBSztBQUFBLFFBQ1Q7QUFBQSxRQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLG1CQUFtQixNQUFNLENBQUM7QUFBQSxNQUM1RjtBQUNBLGFBQU87QUFBQSxJQUNULFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLE1BQU0sbUJBQTBGO0FBQzlGLFVBQU0sS0FBSyxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDOUMsVUFBTSxPQUFPLE1BQU0sS0FBSyxVQUFVLE9BQU8sVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLEVBQUU7QUFDOUYsVUFBTSxJQUFJO0FBQ1YsV0FBTztBQUFBLE1BQ0wsT0FBUSxHQUF5QjtBQUFBLE1BQ2pDLFdBQVcsRUFBRTtBQUFBLE1BQ2IsZ0JBQWdCLEVBQUU7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxNQUFNLG9CQUFtQztBQUN2QyxVQUFNLE9BQU8sTUFBTSxLQUFLLGNBQWM7QUFDdEMsVUFBTSxLQUFLO0FBQUEsTUFDVDtBQUFBLE1BQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLG1CQUFtQixXQUFXLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxNQUN0RztBQUFBLFFBQ0UsS0FBSyxLQUFLO0FBQUEsUUFDVixPQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sYUFBYSxZQUE0QztBQUM3RCxVQUFNLE1BQU0sR0FBRyxRQUFRLElBQUksS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssU0FBUyxNQUFNLElBQUksVUFBVTtBQUMxRyxVQUFNLE1BQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxNQUMzQixRQUFRO0FBQUEsTUFDUixTQUFTLEVBQUUsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFBQSxJQUMxRCxDQUFDO0FBQ0QsUUFBSSxJQUFJLFdBQVcsSUFBSyxRQUFPO0FBQy9CLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxNQUFNLEtBQUssVUFBVSxLQUFLLFdBQVcsVUFBVSxFQUFFO0FBQ3BFLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxXQUFXLE1BQXNDO0FBQ3JELFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsUUFDckI7QUFBQSxRQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDLFFBQVEsbUJBQW1CLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxNQUNsSTtBQUNBLFlBQU0sSUFBSTtBQUNWLGFBQU8sRUFBRSxPQUFPO0FBQUEsSUFDbEIsU0FBUyxLQUFLO0FBQ1osVUFBSSxlQUFlLGVBQWUsSUFBSSxhQUFhLFlBQWEsUUFBTztBQUN2RSxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxNQUFNLFFBQVEsTUFBOEM7QUFDMUQsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxNQUFNLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDO0FBQzVGLFFBQUksTUFBcUIsS0FBSyxlQUFlO0FBQzdDLFVBQU0sY0FBYztBQUVwQixhQUFTLFVBQVUsR0FBRyxXQUFXLGFBQWEsV0FBVztBQUN2RCxZQUFNLE9BQWdDO0FBQUEsUUFDcEMsU0FBUyxLQUFLO0FBQUEsUUFDZCxTQUFTLEtBQUs7QUFBQSxRQUNkLFFBQVEsS0FBSyxTQUFTO0FBQUEsTUFDeEI7QUFDQSxVQUFJLElBQUssTUFBSyxNQUFNO0FBQ3BCLFVBQUk7QUFDRixjQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxLQUFLLElBQUk7QUFDakQsY0FBTSxNQUFNO0FBQ1osZUFBTyxFQUFFLE1BQU0sSUFBSSxRQUFRLE1BQU0sS0FBSyxJQUFJLFFBQVEsS0FBSyxLQUFLLElBQUksUUFBUSxTQUFTO0FBQUEsTUFDbkYsU0FBUyxLQUFLO0FBQ1osWUFBSSxFQUFFLGVBQWUsYUFBYyxPQUFNO0FBQ3pDLFlBQUksSUFBSSxXQUFXLE9BQU8sQ0FBQyxLQUFLO0FBRTlCLGdCQUFNLE1BQU0sS0FBSyxXQUFXLElBQUk7QUFDaEMsY0FBSSxDQUFDLElBQUssT0FBTTtBQUNoQjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLENBQUMsSUFBSSxhQUFhLFlBQVksWUFBYSxPQUFNO0FBQ3JELGNBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxJQUFJLE1BQU0sbUNBQW1DLElBQUksRUFBRTtBQUFBLEVBQzNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBLE1BQU0sWUFBWSxNQUFzRDtBQUN0RSxRQUFJLEtBQUssTUFBTSxXQUFXLEVBQUcsT0FBTSxJQUFJLE1BQU0saUNBQWlDO0FBQzlFLFVBQU0sY0FBYztBQUNwQixRQUFJLFVBQW1CO0FBRXZCLGFBQVMsVUFBVSxHQUFHLFdBQVcsYUFBYSxXQUFXO0FBQ3ZELFVBQUk7QUFDRixjQUFNLFFBQVEsTUFBTSxRQUFRO0FBQUEsVUFDMUIsS0FBSyxNQUFNLElBQUksT0FBTyxTQUFTO0FBQzdCLGtCQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsY0FDckI7QUFBQSxjQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLGNBQ25EO0FBQUEsZ0JBQ0UsU0FBUyxLQUFLO0FBQUEsZ0JBQ2QsVUFBVTtBQUFBLGNBQ1o7QUFBQSxZQUNGO0FBQ0EsbUJBQU87QUFBQSxjQUNMLE1BQU0sS0FBSztBQUFBLGNBQ1gsS0FBTSxJQUF3QjtBQUFBLFlBQ2hDO0FBQUEsVUFDRixDQUFDO0FBQUEsUUFDSDtBQUVBLGNBQU0sT0FBTyxNQUFNLEtBQUssY0FBYztBQUN0QyxjQUFNLE9BQU8sTUFBTSxLQUFLO0FBQUEsVUFDdEI7QUFBQSxVQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLFVBQ25EO0FBQUEsWUFDRSxXQUFXLEtBQUs7QUFBQSxZQUNoQixNQUFNLE1BQU0sSUFBSSxDQUFDLFVBQVU7QUFBQSxjQUN6QixNQUFNLEtBQUs7QUFBQSxjQUNYLE1BQU07QUFBQSxjQUNOLE1BQU07QUFBQSxjQUNOLEtBQUssS0FBSztBQUFBLFlBQ1osRUFBRTtBQUFBLFVBQ0o7QUFBQSxRQUNGO0FBQ0EsY0FBTSxVQUFXLEtBQXlCO0FBQzFDLGNBQU0sU0FBUyxNQUFNLEtBQUs7QUFBQSxVQUN4QjtBQUFBLFVBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsVUFDbkQ7QUFBQSxZQUNFLFNBQVMsS0FBSztBQUFBLFlBQ2QsTUFBTTtBQUFBLFlBQ04sU0FBUyxDQUFDLEtBQUssR0FBRztBQUFBLFVBQ3BCO0FBQUEsUUFDRjtBQUNBLGNBQU0sWUFBWTtBQUNsQixZQUFJO0FBQ0YsZ0JBQU0sS0FBSztBQUFBLFlBQ1Q7QUFBQSxZQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxtQkFBbUIsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsWUFDdEc7QUFBQSxjQUNFLEtBQUssVUFBVTtBQUFBLGNBQ2YsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRixTQUFTLEtBQUs7QUFDWixjQUFJLFdBQVcsR0FBRyxLQUFLLFVBQVUsYUFBYTtBQUM1QyxzQkFBVTtBQUNWLGtCQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUNuQztBQUFBLFVBQ0Y7QUFDQSxnQkFBTTtBQUFBLFFBQ1I7QUFDQSxlQUFPO0FBQUEsVUFDTCxXQUFXLFVBQVU7QUFBQSxVQUNyQixLQUFLLFVBQVU7QUFBQSxVQUNmLE9BQU8sS0FBSyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSTtBQUFBLFFBQzNDO0FBQUEsTUFDRixTQUFTLEtBQUs7QUFDWixrQkFBVTtBQUNWLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFLLENBQUMsSUFBSSxhQUFhLENBQUMsV0FBVyxHQUFHLEtBQU0sWUFBWSxZQUFhLE9BQU07QUFDM0UsY0FBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLG1CQUFtQixRQUFRLFVBQVUsSUFBSSxNQUFNLGlDQUFpQztBQUFBLEVBQ3hGO0FBQUEsRUFFQSxNQUFjLGdCQUEyRDtBQUN2RSxVQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDckI7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxrQkFBa0IsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsSUFDdkc7QUFDQSxVQUFNLFVBQVcsSUFBb0MsT0FBTztBQUM1RCxVQUFNLFNBQVMsTUFBTSxLQUFLO0FBQUEsTUFDeEI7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxnQkFBZ0IsT0FBTztBQUFBLElBQzVFO0FBQ0EsV0FBTztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsU0FBVSxPQUFxQyxLQUFLO0FBQUEsSUFDdEQ7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFjLFVBQVUsUUFBZ0IsTUFBYyxNQUFrQztBQUN0RixVQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU0sSUFBSSxPQUFPLEdBQUcsUUFBUSxHQUFHLElBQUk7QUFDL0QsVUFBTSxPQUFvQjtBQUFBLE1BQ3hCO0FBQUEsTUFDQSxTQUFTO0FBQUEsUUFDUCxlQUFlLFVBQVUsS0FBSyxTQUFTLEdBQUc7QUFBQSxRQUMxQyxRQUFRO0FBQUEsUUFDUix3QkFBd0I7QUFBQSxRQUN4QixHQUFJLE9BQU8sRUFBRSxnQkFBZ0IsbUJBQW1CLElBQUksQ0FBQztBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxHQUFJLE9BQU8sRUFBRSxNQUFNLEtBQUssVUFBVSxJQUFJLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDL0M7QUFDQSxRQUFJO0FBQ0osUUFBSTtBQUNGLFlBQU0sTUFBTSxNQUFNLEtBQUssSUFBSTtBQUFBLElBQzdCLFNBQVMsUUFBUTtBQUNmLFlBQU0sSUFBSSxZQUFZO0FBQUEsUUFDcEIsUUFBUTtBQUFBLFFBQ1IsTUFBTTtBQUFBLFFBQ04sU0FBUyxZQUFZLGNBQWMsTUFBTSxFQUFFLE9BQU87QUFBQSxRQUNsRCxXQUFXO0FBQUEsUUFDWCxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLFNBQWtCO0FBQ3RCLFVBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixRQUFJLE1BQU07QUFDUixVQUFJO0FBQ0YsaUJBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxNQUMxQixRQUFRO0FBQ04saUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxNQUFNLEtBQUssb0JBQW9CLEtBQUssUUFBUSxHQUFHLE1BQU0sSUFBSSxJQUFJLEVBQUU7QUFDbEYsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE1BQWMsVUFBVSxLQUFlLE9BQXFDO0FBQzFFLFFBQUksU0FBa0I7QUFDdEIsUUFBSTtBQUNGLFlBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixVQUFJLEtBQU0sVUFBUyxLQUFLLE1BQU0sSUFBSTtBQUFBLElBQ3BDLFFBQVE7QUFBQSxJQUVSO0FBQ0EsV0FBTyxLQUFLLG9CQUFvQixLQUFLLFFBQVEsS0FBSztBQUFBLEVBQ3BEO0FBQUEsRUFFUSxvQkFBb0IsS0FBZSxNQUFlLE9BQTRCO0FBQ3BGLFVBQU0sTUFDSixPQUFPLFNBQVMsWUFBWSxRQUFRLGFBQWEsT0FDN0MsT0FBUSxLQUE4QixPQUFPLElBQzdDLElBQUk7QUFDVixRQUFJLFdBQW9DO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0FBRTVDLFlBQU0sT0FBTyxJQUFJLFFBQVEsSUFBSSx1QkFBdUI7QUFDcEQsVUFBSSxTQUFTLE9BQU8sY0FBYyxLQUFLLEdBQUcsR0FBRztBQUMzQyxtQkFBVztBQUNYLG9CQUFZO0FBQUEsTUFDZCxPQUFPO0FBQ0wsbUJBQVc7QUFBQSxNQUNiO0FBQUEsSUFDRixXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQUEsSUFDYixXQUFXLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0FBQ25ELGlCQUFXO0FBQUEsSUFDYixXQUFXLElBQUksVUFBVSxLQUFLO0FBQzVCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkLFdBQVcsSUFBSSxXQUFXLEtBQUs7QUFDN0IsaUJBQVc7QUFDWCxrQkFBWTtBQUFBLElBQ2Q7QUFDQSxXQUFPLElBQUksWUFBWTtBQUFBLE1BQ3JCLFFBQVEsSUFBSTtBQUFBLE1BQ1o7QUFBQSxNQUNBLFNBQVMsR0FBRyxLQUFLLFdBQU0sSUFBSSxNQUFNLEtBQUssR0FBRztBQUFBLE1BQ3pDO0FBQUEsTUFDQTtBQUFBLE1BQ0Esa0JBQWtCLGFBQWEsZUFBZSxvQkFBb0IsSUFBSSxPQUFPLElBQUk7QUFBQSxJQUNuRixDQUFDO0FBQUEsRUFDSDtBQUNGO0FBUUEsU0FBUyxvQkFBb0IsU0FBaUM7QUFDNUQsUUFBTSxRQUFRLFFBQVEsSUFBSSxtQkFBbUI7QUFDN0MsTUFBSSxPQUFPO0FBQ1QsVUFBTSxJQUFJLE9BQU8sU0FBUyxPQUFPLEVBQUU7QUFDbkMsUUFBSSxPQUFPLFNBQVMsQ0FBQyxLQUFLLElBQUksRUFBRyxRQUFPO0FBQUEsRUFDMUM7QUFDQSxRQUFNLGFBQWEsUUFBUSxJQUFJLGFBQWE7QUFDNUMsTUFBSSxZQUFZO0FBQ2QsVUFBTSxRQUFRLE9BQU8sU0FBUyxZQUFZLEVBQUU7QUFDNUMsUUFBSSxPQUFPLFNBQVMsS0FBSyxLQUFLLFNBQVMsR0FBRztBQUN4QyxhQUFPLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJLElBQUk7QUFBQSxJQUN6QztBQUNBLFVBQU0sU0FBUyxLQUFLLE1BQU0sVUFBVTtBQUNwQyxRQUFJLE9BQU8sU0FBUyxNQUFNLEVBQUcsUUFBTyxLQUFLLE1BQU0sU0FBUyxHQUFJO0FBQUEsRUFDOUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFdBQVcsTUFBc0I7QUFFeEMsU0FBTyxLQUFLLE1BQU0sR0FBRyxFQUFFLElBQUksa0JBQWtCLEVBQUUsS0FBSyxHQUFHO0FBQ3pEO0FBRUEsU0FBUyxVQUFVLFNBQWlCLEtBQTBCO0FBRTVELFFBQU0sT0FBTyxJQUFJLGFBQWEsZUFBZSxNQUFPO0FBQ3BELFFBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksR0FBRztBQUM3QyxTQUFPLEtBQUssSUFBSSxLQUFRLE9BQU8sTUFBTSxVQUFVLEtBQUssTUFBTTtBQUM1RDtBQUVBLFNBQVMsV0FBVyxLQUFrQztBQUNwRCxTQUFPLGVBQWUsZUFBZSxJQUFJLGFBQWE7QUFDeEQ7QUFFQSxTQUFTLE1BQU0sSUFBMkI7QUFDeEMsU0FBTyxJQUFJLFFBQVEsQ0FBQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUM7QUFDN0M7QUFFTyxTQUFTQSxVQUFTLE9BQXVCO0FBRTlDLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEtBQUs7QUFDM0MsTUFBSSxNQUFNO0FBQ1YsYUFBVyxLQUFLLEtBQU0sUUFBTyxPQUFPLGFBQWEsQ0FBQztBQUNsRCxTQUFPLEtBQUssR0FBRztBQUNqQjs7O0FDM1hBLElBQU0sY0FBYztBQVNwQixJQUFNLHVCQUE0QyxvQkFBSSxJQUFJLENBQUMsV0FBVyxDQUFDO0FBRWhFLFNBQVMsVUFBVSxTQUFrQixLQUF3QztBQUNsRixRQUFNLFlBQVksY0FBYyxPQUFPO0FBQ3ZDLFFBQU0sU0FBMkIsQ0FBQztBQUNsQyxRQUFNLG9CQUF3QyxDQUFDO0FBQy9DLFFBQU0sV0FBcUIsQ0FBQztBQUM1QixRQUFNLFFBQVEsb0JBQUksSUFBWTtBQUM5QixRQUFNLGFBQWEsb0JBQUksSUFBMkI7QUFDbEQsUUFBTSxrQkFBa0IscUJBQXFCLElBQUksSUFBSSxRQUFRO0FBQzdELGFBQVcsT0FBTyxXQUFXO0FBQzNCLFFBQUk7QUFDRixZQUFNLGNBQWMscUJBQXFCLEtBQUssR0FBRztBQUNqRCxVQUFJLGFBQWE7QUFDZiwwQkFBa0IsS0FBSyxXQUFXO0FBQ2xDLGlCQUFTLEtBQUssWUFBWSxRQUFRO0FBQ2xDLGNBQU0sSUFBSSxZQUFZLFFBQVE7QUFDOUI7QUFBQSxNQUNGO0FBQ0EsWUFBTSxJQUFJLFdBQVcsS0FBSyxHQUFHO0FBQzdCLFVBQUksQ0FBQyxHQUFHO0FBQ04sWUFBSSxpQkFBaUI7QUFJbkIsZ0JBQU0sVUFBVSxZQUFZLEdBQUc7QUFDL0IsY0FBSSxRQUFTLFlBQVcsSUFBSSxRQUFRLFVBQVUsUUFBUSxXQUFXO0FBQUEsUUFDbkU7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxlQUFTLEtBQUssRUFBRSxRQUFRO0FBQ3hCLFlBQU0sSUFBSSxFQUFFLFFBQVE7QUFDcEIsVUFBSSxJQUFJLGVBQWUsU0FBUyxLQUFLLElBQUksZUFBZSxJQUFJLEVBQUUsZUFBZSxZQUFZLENBQUMsR0FBRztBQUMzRixlQUFPLEtBQUssQ0FBQztBQUFBLE1BQ2Y7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUVSO0FBQUEsRUFDRjtBQUdBLFFBQU0sY0FBdUUsQ0FBQztBQUM5RSxhQUFXLENBQUMsSUFBSSxJQUFJLEtBQUssWUFBWTtBQUNuQyxRQUFJLE1BQU0sSUFBSSxFQUFFLEVBQUc7QUFDbkIsZ0JBQVksS0FBSyxFQUFFLFVBQVUsSUFBSSxhQUFhLEtBQUssQ0FBQztBQUFBLEVBQ3REO0FBQ0EsU0FBTyxFQUFFLFFBQVEsY0FBYyxVQUFVLG9CQUFvQixtQkFBbUIsWUFBWTtBQUM5RjtBQUVBLFNBQVMscUJBQXFCLE1BQWUsS0FBZ0Q7QUFDM0YsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUU5QyxRQUFNLFVBQ0osVUFBVSxFQUFFLE9BQU8sS0FDbkIsb0JBQW9CLElBQUksTUFDdkIsSUFBSSxZQUFZLG9CQUFvQixJQUFJLFNBQVMsSUFBSTtBQUN4RCxNQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksS0FBSyxPQUFPLEVBQUcsUUFBTztBQUVuRCxRQUFNLGtCQUFrQixrQkFBa0IsSUFBSTtBQUM5QyxTQUFPO0FBQUEsSUFDTCxVQUFVO0FBQUEsSUFDVixnQkFDRSx3QkFBd0IsTUFBTSxPQUFPLE1BQ3BDLElBQUksWUFBWSxtQkFBbUIsSUFBSSxXQUFXLE9BQU8sSUFBSTtBQUFBLElBQ2hFLHlCQUF5QixJQUFJO0FBQUEsSUFDN0Isb0JBQW9CLDBCQUEwQixlQUFlO0FBQUEsSUFDN0Qsa0JBQWtCO0FBQUEsSUFDbEIsd0JBQXdCLElBQUksYUFBYTtBQUFBLEVBQzNDO0FBQ0Y7QUFFQSxTQUFTLG9CQUFvQixNQUE4QjtBQUN6RCxRQUFNLE9BQU8sb0JBQUksUUFBZ0I7QUFDakMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE1BQU0sTUFBTSxJQUFJO0FBQ3RCLFFBQUksT0FBTyxRQUFRLFVBQVU7QUFDM0IsWUFBTSxLQUFLLG9CQUFvQixHQUFHO0FBQ2xDLFVBQUksR0FBSSxRQUFPO0FBQ2Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVU7QUFDN0MsUUFBSSxLQUFLLElBQUksR0FBYSxFQUFHO0FBQzdCLFNBQUssSUFBSSxHQUFhO0FBQ3RCLFFBQUksTUFBTSxRQUFRLEdBQUcsR0FBRztBQUN0QixpQkFBVyxLQUFLLElBQUssT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNuQyxPQUFPO0FBQ0wsaUJBQVcsS0FBSyxPQUFPLE9BQU8sR0FBOEIsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQzdFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsb0JBQW9CLFFBQStCO0FBQzFELE1BQUk7QUFDRixVQUFNLE1BQU0sSUFBSSxJQUFJLFFBQVEsZ0JBQWdCO0FBQzVDLFFBQUksSUFBSSxhQUFhLFdBQVcsSUFBSSxhQUFhLGNBQWUsUUFBTztBQUN2RSxVQUFNLFFBQVEsSUFBSSxTQUFTLE1BQU0sb0RBQW9EO0FBQ3JGLFdBQU8sUUFBUSxDQUFDLEtBQUs7QUFBQSxFQUN2QixRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsa0JBQWtCLE1BQThCO0FBQ3ZELFFBQU0sVUFBb0IsQ0FBQztBQUMzQixRQUFNLE9BQU8sb0JBQUksUUFBZ0I7QUFDakMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE1BQU0sTUFBTSxJQUFJO0FBQ3RCLFFBQUksT0FBTyxRQUFRLFVBQVU7QUFDM0IsWUFBTSxVQUFVLElBQUksS0FBSztBQUN6QixVQUNFLFFBQVEsVUFBVSxLQUNsQixDQUFDLFFBQVEsV0FBVyxTQUFTLEtBQzdCLENBQUMsUUFBUSxXQUFXLFVBQVUsR0FDOUI7QUFDQSxnQkFBUSxLQUFLLE9BQU87QUFBQSxNQUN0QjtBQUNBO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFlBQVksUUFBUTtBQUFBLElBQUssQ0FBQyxNQUM5Qiw4RUFBOEUsS0FBSyxDQUFDO0FBQUEsRUFDdEY7QUFDQSxTQUFPLGFBQWEsUUFBUSxDQUFDLEtBQUs7QUFDcEM7QUFFQSxTQUFTLDBCQUEwQixNQUFvQztBQUNyRSxNQUFJLENBQUMsS0FBTSxRQUFPO0FBQ2xCLE1BQUksd0JBQXdCLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDL0MsTUFBSSxnQkFBZ0IsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUN2QyxNQUFJLHVCQUF1QixLQUFLLElBQUksRUFBRyxRQUFPO0FBQzlDLE1BQUksaUJBQWlCLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDeEMsTUFBSSxpQ0FBaUMsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUN4RCxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFlBQVksTUFBd0U7QUFDM0YsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFHVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUc5QyxRQUFNLEtBQUssRUFBRTtBQUNiLE1BQUksT0FBTyxXQUFXLE9BQU8sZ0NBQWdDLENBQUMsSUFBSSxFQUFFLE1BQU0sR0FBRztBQUMzRSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sU0FDSCxPQUFPLEVBQUUsWUFBWSxZQUFZLEVBQUUsV0FDbkMsT0FBTyxJQUFJLEVBQUUsWUFBWSxHQUFHLFdBQVcsWUFDckMsSUFBSSxJQUFJLEVBQUUsWUFBWSxHQUFHLE1BQU0sR0FBRztBQUN2QyxNQUFJLE9BQU8sV0FBVyxZQUFZLENBQUMsWUFBWSxLQUFLLE1BQU0sRUFBRyxRQUFPO0FBQ3BFLFFBQU0sYUFBYSxlQUFlLE1BQU0sTUFBTTtBQUM5QyxNQUFJLENBQUMsV0FBWSxRQUFPO0FBQ3hCLFNBQU8sRUFBRSxVQUFVLFFBQVEsYUFBYSxXQUFXO0FBQ3JEO0FBRUEsU0FBUyxlQUFlLE1BQWUsU0FBZ0M7QUFDckUsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLGFBQWEsSUFBSSxJQUFJLElBQUksRUFBRSxJQUFJLEdBQUcsWUFBWSxHQUFHLE1BQU07QUFDN0QsU0FDRSxVQUFVLElBQUksWUFBWSxJQUFJLEdBQUcsV0FBVyxLQUM1QyxVQUFVLElBQUksWUFBWSxNQUFNLEdBQUcsV0FBVyxLQUM5QyxVQUFVLElBQUksRUFBRSxNQUFNLEdBQUcsV0FBVyxLQUNwQyx3QkFBd0IsTUFBTSxPQUFPO0FBRXpDO0FBRUEsU0FBUyx3QkFBd0IsTUFBZSxTQUFnQztBQUM5RSxRQUFNLE9BQU8sb0JBQUksUUFBZ0I7QUFDakMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE1BQU0sTUFBTSxJQUFJO0FBQ3RCLFFBQUksT0FBTyxRQUFRLFVBQVU7QUFDM0IsWUFBTSxTQUFTLG1CQUFtQixLQUFLLE9BQU87QUFDOUMsVUFBSSxPQUFRLFFBQU87QUFDbkI7QUFBQSxJQUNGO0FBQ0EsUUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVU7QUFDN0MsUUFBSSxLQUFLLElBQUksR0FBYSxFQUFHO0FBQzdCLFNBQUssSUFBSSxHQUFhO0FBQ3RCLFFBQUksTUFBTSxRQUFRLEdBQUcsR0FBRztBQUN0QixpQkFBVyxLQUFLLElBQUssT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNuQyxPQUFPO0FBQ0wsaUJBQVcsS0FBSyxPQUFPLE9BQU8sR0FBOEIsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQzdFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsbUJBQW1CLFFBQWdCLFNBQWdDO0FBQzFFLE1BQUk7QUFDRixVQUFNLE1BQU0sSUFBSSxJQUFJLFFBQVEsZ0JBQWdCO0FBQzVDLFFBQUksSUFBSSxhQUFhLFdBQVcsSUFBSSxhQUFhLGNBQWUsUUFBTztBQUN2RSxVQUFNLFFBQVEsSUFBSSxTQUFTLE1BQU0sc0RBQXNEO0FBQ3ZGLFFBQUksQ0FBQyxTQUFTLE1BQU0sQ0FBQyxNQUFNLFFBQVMsUUFBTztBQUMzQyxXQUFPLE1BQU0sQ0FBQyxLQUFLO0FBQUEsRUFDckIsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLGNBQWNDLE1BQXlCO0FBSzlDLFFBQU0sTUFBaUIsQ0FBQztBQUN4QixRQUFNLE9BQU8sb0JBQUksUUFBZ0I7QUFDakMsUUFBTSxRQUFtQixDQUFDQSxJQUFHO0FBQzdCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxPQUFPLE1BQU0sSUFBSTtBQUN2QixRQUFJLFNBQVMsUUFBUSxTQUFTLE9BQVc7QUFDekMsUUFBSSxPQUFPLFNBQVMsU0FBVTtBQUM5QixRQUFJLEtBQUssSUFBSSxJQUFjLEVBQUc7QUFDOUIsU0FBSyxJQUFJLElBQWM7QUFFdkIsUUFBSSxlQUFlLElBQUksR0FBRztBQUN4QixVQUFJLEtBQUssWUFBWSxJQUFJLENBQUM7QUFBQSxJQUM1QjtBQUNBLFFBQUksTUFBTSxRQUFRLElBQUksR0FBRztBQUN2QixpQkFBVyxLQUFLLEtBQU0sT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNwQyxPQUFPO0FBQ0wsaUJBQVcsS0FBSyxPQUFPLE9BQU8sSUFBK0IsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQzlFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsZUFBZSxNQUFnRDtBQUN0RSxNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLFFBQU0sV0FBVyxFQUFFO0FBQ25CLE1BQ0UsYUFBYSxXQUNiLGFBQWEsZ0NBQ2IsYUFBYSxrQkFDYjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FBTyxPQUFPLEVBQUUsWUFBWSxZQUFZLE9BQU8sRUFBRSxXQUFXLFlBQVksRUFBRSxXQUFXO0FBQ3ZGO0FBRUEsU0FBUyxZQUFZLE1BQXdEO0FBQzNFLE1BQUksS0FBSyxlQUFlLGdDQUFnQyxPQUFPLEtBQUssVUFBVSxVQUFVO0FBQ3RGLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFdBQVcsS0FBYyxLQUE4QztBQUM5RSxNQUFJLE9BQU8sUUFBUSxZQUFZLFFBQVEsS0FBTSxRQUFPO0FBQ3BELFFBQU0sSUFBSTtBQUVWLE1BQUksRUFBRSxlQUFlLGlCQUFrQixRQUFPO0FBRTlDLFFBQU0sU0FBUyxVQUFVLEVBQUUsT0FBTztBQUtsQyxRQUFNLFNBQVMsSUFBSSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQ2pDLE1BQUksQ0FBQyxPQUFRLFFBQU87QUFFcEIsUUFBTSxPQUFPLElBQUksRUFBRSxJQUFJO0FBQ3ZCLFFBQU0sYUFBYSxJQUFJLElBQUksTUFBTSxZQUFZLEdBQUcsTUFBTTtBQUd0RCxRQUFNLGNBQWMsSUFBSSxZQUFZLElBQUk7QUFDeEMsUUFBTSxhQUFhLElBQUksWUFBWSxNQUFNO0FBQ3pDLFFBQU0sZ0JBQWdCLElBQUksWUFBWSxNQUFNO0FBQzVDLFFBQU0sU0FDSixVQUFVLGFBQWEsV0FBVyxLQUNsQyxVQUFVLFlBQVksV0FBVyxLQUNqQyxVQUFVLFlBQVksV0FBVyxLQUNqQyxVQUFVLE9BQU8sV0FBVztBQUM5QixRQUFNLFlBQ0osVUFBVSxZQUFZLE9BQU8sS0FDN0IsVUFBVSxZQUFZLE1BQU0sS0FDNUIsVUFBVSxPQUFPLFdBQVc7QUFDOUIsTUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFXLFFBQU87QUFNbEMsUUFBTSxTQUFTLG9CQUFvQixZQUFZLGFBQWEsWUFBWSxhQUFhO0FBRXJGLFFBQU0sWUFBWSxJQUFJLElBQUksSUFBSSxFQUFFLFVBQVUsR0FBRyxrQkFBa0IsR0FBRyxNQUFNO0FBQ3hFLFFBQU0sZUFBZSxVQUFVLFdBQVcsSUFBSTtBQUM5QyxRQUFNLGlCQUFpQixVQUFVLE9BQU8sU0FBUyxLQUFLO0FBQ3RELFFBQU0sT0FBTyxnQkFBZ0I7QUFDN0IsUUFBTSxjQUFjLGlCQUFpQixXQUFXLFFBQVEsY0FBYztBQUN0RSxRQUFNLGdCQUFnQixxQkFBcUIsR0FBRyxRQUFRLElBQUksVUFBVTtBQUVwRSxRQUFNLFdBQVcsSUFBSSxPQUFPLFFBQVEsS0FBSyxDQUFDO0FBQzFDLFFBQU0sbUJBQW1CLElBQUksV0FBVyxVQUFVO0FBQ2xELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxXQUFXLGdCQUFnQixvQkFBb0IsUUFBUTtBQUM3RCxRQUFNLE9BQU8sWUFBWSxvQkFBb0IsUUFBUTtBQUNyRCxRQUFNLFFBQVEsYUFBYSxNQUFNO0FBRWpDLFFBQU0sWUFBWSxrQkFBa0IsR0FBRyxNQUFNO0FBSTdDLFFBQU0sV0FDSixpQkFBaUIsVUFBVSxPQUFPLFVBQVUsQ0FBQyxLQUFLLGlCQUFpQixVQUFVLEVBQUUsVUFBVSxDQUFDO0FBQzVGLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFFdEIsUUFBTSxRQUFRLElBQUksRUFBRSxLQUFLO0FBQ3pCLFFBQU0sWUFBWSxVQUFVLE9BQU8sS0FBSyxLQUFLLFVBQVUsVUFBVSxPQUFPLEtBQUssQ0FBQztBQUU5RSxRQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzFCLFFBQU0sUUFBUSxJQUFJLE9BQU8sS0FBSztBQUU5QixRQUFNLFFBQXdCO0FBQUEsSUFDNUIsVUFBVTtBQUFBLElBQ1YsZ0JBQWdCO0FBQUEsSUFDaEIsWUFBWTtBQUFBLElBQ1osV0FBVztBQUFBLElBQ1gsbUJBQW1CLElBQUk7QUFBQSxJQUN2QixjQUFjLElBQUk7QUFBQSxJQUNsQixzQkFBc0I7QUFBQSxJQUN0Qix5QkFBeUI7QUFBQSxJQUN6QixvQkFBb0I7QUFBQSxJQUNwQixrQkFBa0I7QUFBQSxJQUNsQix3QkFBd0I7QUFBQSxJQUN4QixXQUFXLEdBQUcsZ0JBQWdCLElBQUksTUFBTSxXQUFXLE1BQU07QUFBQSxJQUN6RCxZQUFZO0FBQUEsSUFDWixpQkFBaUIsVUFBVSxPQUFPLG1CQUFtQjtBQUFBLElBQ3JELG1CQUFtQixVQUFVLE9BQU8seUJBQXlCO0FBQUEsSUFDN0Qsa0JBQWtCLFVBQVUsT0FBTyx1QkFBdUI7QUFBQSxJQUMxRCxxQkFBcUIsVUFBVSxPQUFPLHVCQUF1QjtBQUFBLElBQzdELGlCQUFpQixVQUFVLE9BQU8sb0JBQW9CO0FBQUEsSUFDdEQsb0JBQW9CO0FBQUEsTUFDbEIsSUFBSSxJQUFJLE9BQU8sdUJBQXVCLEdBQUcsTUFBTSxHQUFHLFdBQy9DLE9BQW1DO0FBQUEsSUFDeEM7QUFBQSxJQUNBO0FBQUEsSUFDQSxlQUFlLGlCQUFpQixNQUFNLElBQUk7QUFBQSxJQUMxQyxNQUFNLFVBQVUsT0FBTyxJQUFJO0FBQUEsSUFDM0Isb0JBQW9CLFdBQVcsT0FBTyxrQkFBa0I7QUFBQSxJQUN4RCxRQUFRLFVBQVUsT0FBTyxNQUFNLEtBQUssVUFBVSxFQUFFLE1BQU07QUFBQSxJQUN0RCxpQkFBaUIsVUFBVSxPQUFPLFNBQVM7QUFBQSxJQUMzQztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVksVUFBVSxPQUFPLGNBQWM7QUFBQSxJQUMzQyxlQUFlLFVBQVUsT0FBTyxhQUFhO0FBQUEsSUFDN0MsYUFBYSxVQUFVLE9BQU8sV0FBVztBQUFBLElBQ3pDLGFBQWEsVUFBVSxPQUFPLFdBQVc7QUFBQSxJQUN6QyxZQUFZO0FBQUEsSUFDWixnQkFBZ0IsVUFBVSxPQUFPLGNBQWM7QUFBQSxJQUMvQyxvQkFBb0I7QUFBQSxNQUNsQjtBQUFBLFFBQ0UsYUFBYSxJQUFJO0FBQUEsUUFDakIsT0FBTyxVQUFVLE9BQU8sY0FBYztBQUFBLFFBQ3RDLFVBQVUsVUFBVSxPQUFPLGFBQWE7QUFBQSxRQUN4QyxTQUFTLFVBQVUsT0FBTyxXQUFXO0FBQUEsUUFDckMsUUFBUSxVQUFVLE9BQU8sV0FBVztBQUFBLFFBQ3BDLE9BQU87QUFBQSxRQUNQLFdBQVcsVUFBVSxPQUFPLGNBQWM7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFBQSxJQUNBO0FBQUEsSUFDQSxnQkFBZ0I7QUFBQSxJQUNoQixjQUFjO0FBQUEsSUFDZCxhQUFhO0FBQUEsSUFDYixzQkFBc0I7QUFBQSxJQUN0QixnQkFBZ0I7QUFBQSxJQUNoQixnQkFBZ0IsSUFBSTtBQUFBLElBQ3BCLGdCQUFnQjtBQUFBLEVBQ2xCO0FBRUEsU0FBTztBQUNUO0FBRUEsU0FBUyxrQkFBa0IsR0FBNEIsUUFBNEM7QUFDakcsTUFBSSxPQUFPLDJCQUEyQixPQUFPLHdCQUF5QixRQUFPO0FBQzdFLE1BQUksT0FBTywwQkFBMkIsUUFBTztBQUM3QyxNQUFJLE9BQU8sb0JBQW9CLFFBQVEsT0FBTyxxQkFBc0IsUUFBTztBQUMzRSxNQUFJLEVBQUUsZUFBZSw4QkFBOEI7QUFBQSxFQUVuRDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLFVBQVUsSUFBSSxPQUFRLEVBQXdCLElBQUksSUFBSTtBQUFBLEVBQ3RGLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxnQkFBZ0IsVUFBNkM7QUFDcEUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFNBQU8sSUFDSjtBQUFBLElBQUksQ0FBQyxNQUNKLE9BQU8sTUFBTSxZQUFZLEtBQUssaUJBQWlCLElBQzNDLE9BQVEsRUFBK0IsV0FBVyxJQUNsRDtBQUFBLEVBQ04sRUFDQyxPQUFPLENBQUMsTUFBbUIsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLENBQUM7QUFDckU7QUFFQSxTQUFTLFlBQVksVUFBZ0Q7QUFDbkUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFFBQU0sTUFBbUIsQ0FBQztBQUMxQixhQUFXLEtBQUssS0FBSztBQUNuQixRQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTTtBQUN6QyxVQUFNLElBQUk7QUFDVixVQUFNLFFBQVEsVUFBVSxFQUFFLEdBQUc7QUFDN0IsVUFBTSxXQUFXLFVBQVUsRUFBRSxZQUFZO0FBQ3pDLFVBQU0sVUFBVSxVQUFVLEVBQUUsV0FBVztBQUN2QyxRQUFJLENBQUMsU0FBUyxDQUFDLFNBQVU7QUFDekIsUUFBSSxLQUFLLEVBQUUsT0FBTyxVQUFVLFNBQVMsV0FBVyxTQUFTLENBQUM7QUFBQSxFQUM1RDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsYUFBYSxRQUE4QztBQUNsRSxRQUFNLFdBQVcsSUFBSSxPQUFPLGlCQUFpQjtBQUM3QyxRQUFNLFVBQVUsV0FBVyxRQUFRLFNBQVMsS0FBSyxJQUFJLENBQUM7QUFDdEQsUUFBTSxVQUFVLFFBQVEsSUFBSSxPQUFPLFFBQVEsR0FBRyxLQUFLO0FBQ25ELFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sU0FBUyxDQUFDLEdBQUcsU0FBUyxHQUFHLE9BQU8sRUFBRSxPQUFPLENBQUMsTUFBTTtBQUNwRCxRQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTSxRQUFPO0FBQ2hELFVBQU0sS0FDSixVQUFXLEVBQThCLFNBQVMsS0FDbEQsVUFBVyxFQUE4QixNQUFNO0FBQ2pELFFBQUksQ0FBQyxHQUFJLFFBQU87QUFDaEIsUUFBSSxLQUFLLElBQUksRUFBRSxFQUFHLFFBQU87QUFDekIsU0FBSyxJQUFJLEVBQUU7QUFDWCxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0QsU0FBTyxPQUFPLElBQUksQ0FBQyxRQUFRLFdBQVcsR0FBOEIsQ0FBQztBQUN2RTtBQUVBLFNBQVMsV0FBVyxHQUF1QztBQUN6RCxRQUFNLE9BQU8sVUFBVSxFQUFFLElBQUk7QUFDN0IsUUFBTSxXQUFXLGdCQUFnQixHQUFHLElBQUk7QUFDeEMsUUFBTUMsUUFBTyxJQUFJLEVBQUUsYUFBYTtBQUNoQyxRQUFNLFlBQVksSUFBSSxFQUFFLFVBQVU7QUFDbEMsUUFBTSxhQUFhLFVBQVUsV0FBVyxlQUFlO0FBQ3ZELFFBQU0sVUFBVSxVQUFVLEVBQUUsWUFBWTtBQUN4QyxRQUFNLFVBQ0osVUFBVSxFQUFFLFNBQVMsS0FDckIsVUFBVSxFQUFFLE1BQU0sS0FDbEIsR0FBRyxRQUFRLE9BQU8sSUFBSSxLQUFLLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUMzRCxTQUFPO0FBQUEsSUFDTCxVQUFVO0FBQUEsSUFDVixZQUFhLFFBQVE7QUFBQSxJQUNyQixjQUFjLFlBQVk7QUFBQSxJQUMxQixtQkFBbUI7QUFBQSxJQUNuQixRQUFRO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxjQUFjLGVBQWUsT0FBTyxhQUFhLE1BQU87QUFBQSxJQUN4RCxPQUFPLFVBQVVBLE9BQU0sS0FBSztBQUFBLElBQzVCLFFBQVEsVUFBVUEsT0FBTSxNQUFNO0FBQUEsSUFDOUIsVUFBVTtBQUFBLElBQ1YsZ0JBQWdCO0FBQUEsSUFDaEIsa0JBQWtCO0FBQUEsSUFDbEIsaUJBQWlCO0FBQUEsRUFDbkI7QUFDRjtBQUVBLFNBQVMsZ0JBQWdCLEdBQTRCLE1BQW9DO0FBQ3ZGLE1BQUksU0FBUyxRQUFTLFFBQU8sVUFBVSxFQUFFLGVBQWUsS0FBSyxVQUFVLEVBQUUsU0FBUztBQUNsRixRQUFNLFdBQVcsUUFBUSxJQUFJLEVBQUUsVUFBVSxHQUFHLFFBQVE7QUFDcEQsTUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLFVBQVUsRUFBRSxlQUFlO0FBRTdELE1BQUksT0FBZ0Q7QUFDcEQsYUFBVyxLQUFLLFVBQVU7QUFDeEIsVUFBTSxLQUFLLFVBQVUsRUFBRSxZQUFZO0FBQ25DLFVBQU0sTUFBTSxVQUFVLEVBQUUsR0FBRztBQUMzQixRQUFJLENBQUMsSUFBSztBQUNWLFFBQUksT0FBTyxhQUFhO0FBQ3RCLFlBQU0sS0FBSyxVQUFVLEVBQUUsT0FBTyxLQUFLO0FBQ25DLFVBQUksQ0FBQyxRQUFRLEtBQUssS0FBSyxRQUFTLFFBQU8sRUFBRSxLQUFLLFNBQVMsR0FBRztBQUFBLElBQzVELFdBQVcsQ0FBQyxNQUFNO0FBRWhCLGFBQU8sRUFBRSxLQUFLLFNBQVMsRUFBRTtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNBLFNBQU8sTUFBTSxPQUFPO0FBQ3RCO0FBRUEsU0FBUyxpQkFBaUIsTUFBYyxNQUEyQjtBQUNqRSxNQUFJLEtBQUssV0FBVyxFQUFHLFFBQU87QUFDOUIsTUFBSSxNQUFNO0FBQ1YsYUFBVyxLQUFLLEtBQU0sT0FBTSxJQUFJLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVE7QUFDOUQsU0FBTztBQUNUO0FBRUEsU0FBUyxpQkFBaUIsR0FBaUM7QUFDekQsTUFBSSxDQUFDLEVBQUcsUUFBTztBQUVmLFFBQU0sSUFBSSxJQUFJLEtBQUssQ0FBQztBQUNwQixNQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU87QUFDdEMsU0FBTyxFQUFFLFlBQVk7QUFDdkI7QUFFQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsU0FBTyxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsSUFBSSxJQUFJO0FBQ3JEO0FBQ0EsU0FBUyxXQUFXLEdBQTRCO0FBQzlDLFNBQU8sT0FBTyxNQUFNLFlBQVksSUFBSTtBQUN0QztBQUNBLFNBQVMsVUFBVSxHQUEyQjtBQUM1QyxNQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUN4RCxNQUFJLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxHQUFHO0FBQ3pDLFVBQU0sSUFBSSxPQUFPLENBQUM7QUFDbEIsUUFBSSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFBQSxFQUNqQztBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsVUFBVSxHQUFvQjtBQUNyQyxTQUFPLFVBQVUsQ0FBQyxLQUFLO0FBQ3pCO0FBQ0EsU0FBUyxJQUFJLEdBQTRDO0FBQ3ZELFNBQU8sT0FBTyxNQUFNLFlBQVksTUFBTSxRQUFRLENBQUMsTUFBTSxRQUFRLENBQUMsSUFDekQsSUFDRDtBQUNOO0FBQ0EsU0FBUyxRQUFRLEdBQXVCO0FBQ3RDLFNBQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUM7QUFDakM7QUF3QkEsU0FBUyxpQkFDUCxXQUNBLFFBQ0EsVUFDUztBQUNULE1BQUksVUFBVyxRQUFPO0FBQ3RCLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFDdEIsUUFBTSxXQUFXLElBQUksT0FBTyxRQUFRO0FBQ3BDLFFBQU0sT0FBTyxXQUFXLFNBQVMsT0FBTztBQUN4QyxNQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDdkIsZUFBVyxLQUFLLE1BQU07QUFDcEIsVUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU07QUFDekMsWUFBTSxNQUFPLEVBQThCO0FBSTNDLFVBQUksT0FBTyxRQUFRLFlBQVksd0JBQXdCLEtBQUssR0FBRyxHQUFHO0FBQ2hFLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUF3Qk8sU0FBUyxjQUNkLFFBQ0EsVUFDQSxjQUFtQyxvQkFBSSxJQUFJLEdBQ3pCO0FBQ2xCLE1BQUksU0FBUyxTQUFTLEtBQUssWUFBWSxTQUFTLEVBQUcsUUFBTztBQUsxRCxRQUFNLGdCQUFnQixvQkFBSSxJQUFZO0FBQ3RDLFFBQU0sbUJBQW1CLG9CQUFJLElBQVk7QUFDekMsYUFBVyxLQUFLLFFBQVE7QUFDdEIsUUFBSSxDQUFDLFNBQVMsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEVBQUc7QUFDbkQscUJBQWlCLElBQUksRUFBRSxRQUFRO0FBQy9CLFFBQUksRUFBRSxnQkFBaUIsZUFBYyxJQUFJLEVBQUUsZUFBZTtBQUMxRCxRQUFJLEVBQUUsbUJBQW9CLGVBQWMsSUFBSSxFQUFFLGtCQUFrQjtBQUNoRSxRQUFJLEVBQUUsa0JBQW1CLGVBQWMsSUFBSSxFQUFFLGlCQUFpQjtBQUFBLEVBQ2hFO0FBQ0EsU0FBTyxPQUFPLE9BQU8sQ0FBQyxNQUFNO0FBQzFCLFVBQU0sSUFBSSxFQUFFLGVBQWUsWUFBWTtBQUN2QyxRQUFJLFNBQVMsSUFBSSxDQUFDLEVBQUcsUUFBTztBQUM1QixRQUFJLFlBQVksSUFBSSxDQUFDLEVBQUcsUUFBTztBQUUvQixRQUFJLGNBQWMsSUFBSSxFQUFFLFFBQVEsRUFBRyxRQUFPO0FBSTFDLFFBQUksRUFBRSxtQkFBbUIsaUJBQWlCLElBQUksRUFBRSxlQUFlLEVBQUcsUUFBTztBQUN6RSxRQUFJLEVBQUUscUJBQXFCLGlCQUFpQixJQUFJLEVBQUUsaUJBQWlCLEVBQUcsUUFBTztBQUU3RSxRQUFJLEVBQUUsb0JBQW9CLFNBQVMsSUFBSSxFQUFFLGlCQUFpQixZQUFZLENBQUMsRUFBRyxRQUFPO0FBQ2pGLGVBQVcsS0FBSyxFQUFFLFVBQVU7QUFDMUIsVUFBSSxTQUFTLElBQUksRUFBRSxZQUFZLENBQUMsRUFBRyxRQUFPO0FBQUEsSUFDNUM7QUFDQSxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0g7QUFTQSxTQUFTLHFCQUNQLEdBQ0EsUUFDQSxZQUNzQjtBQUN0QixRQUFNLFFBQVEsSUFBSSxFQUFFLGVBQWUsS0FBSyxJQUFJLE9BQU8sZUFBZTtBQUNsRSxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLFFBQU0sV0FBVyxJQUFJLE1BQU0sUUFBUTtBQUNuQyxRQUFNLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDM0IsUUFBTSxVQUFVLFVBQVUsVUFBVSxJQUFJO0FBQ3hDLFFBQU0sUUFBUSxVQUFVLE1BQU0sS0FBSztBQUNuQyxRQUFNLGFBQWEsVUFBVSxNQUFNLFVBQVU7QUFDN0MsUUFBTSxpQkFBaUIsVUFBVSxNQUFNLGNBQWM7QUFDckQsUUFBTSxTQUFTLFVBQVUsTUFBTSxNQUFNLEtBQUssVUFBVSxNQUFNLE9BQU87QUFFakUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBUSxRQUFPO0FBQzFDLFNBQU87QUFBQSxJQUNMLFNBQVM7QUFBQSxJQUNUO0FBQUEsSUFDQSxhQUFhO0FBQUEsSUFDYjtBQUFBLElBQ0EsaUJBQWlCO0FBQUEsSUFDakIsYUFBYTtBQUFBLEVBQ2Y7QUFDRjtBQU9BLFNBQVMsb0JBQ1AsWUFDQSxhQUNBLFlBQ0EsZUFDYztBQUNkLFFBQU0sZUFBZSxJQUFJLFlBQVksWUFBWTtBQUNqRCxTQUFPO0FBQUEsSUFDTCxjQUNFLFVBQVUsYUFBYSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUksS0FBSyxVQUFVLFlBQVksSUFBSTtBQUFBLElBQzNGLFlBQ0UsVUFBVSxlQUFlLFNBQVMsS0FDbEMsVUFBVSxZQUFZLHVCQUF1QixLQUM3QyxVQUFVLFlBQVksdUJBQXVCO0FBQUEsSUFDL0MsVUFBVSxXQUFXLGNBQWMsUUFBUSxLQUFLLFdBQVcsWUFBWSxRQUFRO0FBQUEsSUFDL0Usa0JBQWtCLFdBQVcsWUFBWSxnQkFBZ0I7QUFBQSxJQUN6RCxlQUFlLFVBQVUsY0FBYyxhQUFhLEtBQUssVUFBVSxZQUFZLGFBQWE7QUFBQSxJQUM1RixhQUFhLFVBQVUsWUFBWSxXQUFXO0FBQUEsSUFDOUMsVUFBVSxVQUFVLElBQUksWUFBWSxRQUFRLEdBQUcsUUFBUSxLQUFLLFVBQVUsWUFBWSxRQUFRO0FBQUEsSUFDMUYsS0FBSyxVQUFVLFlBQVksR0FBRztBQUFBLElBQzlCLGlCQUFpQixVQUFVLFlBQVksZUFBZTtBQUFBLElBQ3RELGVBQWUsVUFBVSxZQUFZLGFBQWE7QUFBQSxJQUNsRCxnQkFBZ0IsVUFBVSxZQUFZLGNBQWM7QUFBQSxJQUNwRCxvQkFDRSxpQkFBaUIsVUFBVSxhQUFhLFVBQVUsQ0FBQyxLQUNuRCxpQkFBaUIsVUFBVSxZQUFZLFVBQVUsQ0FBQztBQUFBLElBQ3BELFdBQVcsV0FBVyxZQUFZLFNBQVM7QUFBQSxFQUM3QztBQUNGO0FBT0EsU0FBUyxZQUFZLEdBQThDO0FBQ2pFLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxNQUFNLE1BQU07QUFDbkMsTUFBSSxDQUFDLFdBQVksUUFBTztBQUN4QixRQUFNLFdBQVcsV0FBVztBQUM1QixRQUFNLFFBQWlDLENBQUM7QUFDeEMsTUFBSSxNQUFNLFFBQVEsUUFBUSxHQUFHO0FBQzNCLGVBQVcsTUFBTSxVQUFVO0FBQ3pCLFVBQUksT0FBTyxPQUFPLFlBQVksT0FBTyxLQUFNO0FBQzNDLFlBQU0sSUFBSTtBQUNWLFlBQU0sSUFBSSxVQUFVLEVBQUUsR0FBRztBQUN6QixZQUFNLElBQUksSUFBSSxFQUFFLEtBQUs7QUFDckIsVUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFHO0FBQ2QsWUFBTSxDQUFDLElBQ0wsVUFBVSxFQUFFLFlBQVksS0FDeEIsVUFBVSxJQUFJLEVBQUUsV0FBVyxHQUFHLEdBQUcsS0FDakMsVUFBVSxJQUFJLEVBQUUsaUJBQWlCLEdBQUcsT0FBTztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxVQUFVLFdBQVcsSUFBSTtBQUN0QyxRQUFNLFVBQVUsVUFBVSxXQUFXLEdBQUc7QUFDeEMsUUFBTSxZQUNKLE9BQU8sTUFBTSxZQUFZLE1BQU0sV0FBWSxNQUFNLFlBQVksSUFBZTtBQUM5RSxRQUFNLFFBQVEsT0FBTyxNQUFNLE9BQU8sTUFBTSxXQUFZLE1BQU0sT0FBTyxJQUFlO0FBQ2hGLFFBQU0sY0FDSixPQUFPLE1BQU0sYUFBYSxNQUFNLFdBQVksTUFBTSxhQUFhLElBQWU7QUFDaEYsUUFBTSxZQUNILE9BQU8sTUFBTSxnQ0FBZ0MsTUFBTSxXQUMvQyxNQUFNLGdDQUFnQyxJQUN2QyxVQUNILE9BQU8sTUFBTSwwQkFBMEIsTUFBTSxXQUN6QyxNQUFNLDBCQUEwQixJQUNqQyxVQUNILE9BQU8sTUFBTSw4QkFBOEIsTUFBTSxXQUM3QyxNQUFNLDhCQUE4QixJQUNyQztBQUNOLE1BQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxTQUFVLFFBQU87QUFDekQsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBLFVBQVU7QUFBQSxJQUNWLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsV0FBVztBQUFBLEVBQ2I7QUFDRjs7O0FDOXpCQSxJQUFNLFdBQVc7QUFFVixTQUFTLFdBQW1CO0FBQ2pDLFFBQU0sS0FBSyxLQUFLLElBQUk7QUFDcEIsTUFBSSxTQUFTO0FBQ2IsTUFBSSxJQUFJO0FBQ1IsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7QUFDM0IsY0FBVSxTQUFTLElBQUksRUFBRSxLQUFLLE9BQU87QUFDckMsUUFBSSxLQUFLLE1BQU0sSUFBSSxFQUFFO0FBQUEsRUFDdkI7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxNQUFJLFdBQVc7QUFDZixhQUFXLEtBQUssS0FBTSxhQUFZLFNBQVMsSUFBSSxFQUFFLEtBQUs7QUFDdEQsU0FBTyxTQUFTO0FBQ2xCO0FBRU8sU0FBUyxXQUFXLElBQW9CO0FBQzdDLFNBQU8sR0FBRyxNQUFNLEVBQUU7QUFDcEI7OztBQ1BBLElBQU0sbUJBQWlELG9CQUFJLElBQUk7QUFBQSxFQUM3RDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBRU0sU0FBUyxrQkFBa0IsTUFBK0I7QUFDL0QsUUFBTSxXQUE0QixDQUFDO0FBQ25DLE1BQUksVUFBa0MsQ0FBQztBQUN2QyxNQUFJLGFBQWE7QUFDakIsUUFBTSxRQUFRLE1BQU07QUFDbEIsUUFBSSxRQUFRLFVBQVUsUUFBUSxPQUFPO0FBQ25DLFVBQUksQ0FBQyxRQUFRLFNBQVUsU0FBUSxXQUFXO0FBQzFDLGVBQVMsS0FBSyxPQUF3QjtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNBLGFBQVcsV0FBVyxLQUFLLE1BQU0sSUFBSSxHQUFHO0FBQ3RDLFVBQU0sT0FBTyxjQUFjLE9BQU87QUFDbEMsUUFBSSxLQUFLLEtBQUssTUFBTSxHQUFJO0FBQ3hCLFFBQUksZ0JBQWdCLEtBQUssSUFBSSxHQUFHO0FBQzlCLG1CQUFhO0FBQ2I7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLFdBQVk7QUFFakIsVUFBTSxZQUFZLEtBQUssTUFBTSw0QkFBNEI7QUFDekQsUUFBSSxXQUFXO0FBQ2IsWUFBTTtBQUNOLGdCQUFVLEVBQUUsUUFBUSxRQUFRLFVBQVUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtBQUNoRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGFBQWEsS0FBSyxNQUFNLHdCQUF3QjtBQUN0RCxRQUFJLGNBQWMsQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQ3JDLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxXQUFXLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDakQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx1QkFBdUI7QUFDckQsUUFBSSxjQUFjLFFBQVEsUUFBUTtBQUNoQyxjQUFRLFFBQVEsUUFBUSxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQzNDO0FBQUEsSUFDRjtBQUNBLFVBQU0sZ0JBQWdCLEtBQUssTUFBTSwwQkFBMEI7QUFDM0QsUUFBSSxpQkFBaUIsUUFBUSxRQUFRO0FBQ25DLFlBQU0sTUFBTSxRQUFRLGNBQWMsQ0FBQyxLQUFLLEVBQUU7QUFDMUMsY0FBUSxXQUFXLGlCQUFpQixJQUFJLEdBQXNCLElBQ3pELE1BQ0Q7QUFDSjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTTtBQUNOLFNBQU8sU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sU0FBUyxDQUFDO0FBQ25EO0FBRUEsU0FBUyxjQUFjLE1BQXNCO0FBRzNDLFFBQU0sTUFBTSxLQUFLLFFBQVEsR0FBRztBQUM1QixTQUFPLFFBQVEsS0FBSyxPQUFPLEtBQUssTUFBTSxHQUFHLEdBQUc7QUFDOUM7QUFFQSxTQUFTLFFBQVEsR0FBbUI7QUFDbEMsUUFBTSxVQUFVLEVBQUUsS0FBSztBQUN2QixNQUNHLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsS0FDL0MsUUFBUSxXQUFXLEdBQUcsS0FBSyxRQUFRLFNBQVMsR0FBRyxHQUNoRDtBQUNBLFdBQU8sUUFBUSxNQUFNLEdBQUcsRUFBRTtBQUFBLEVBQzVCO0FBQ0EsU0FBTztBQUNUOzs7QUNXQSxJQUFNLGNBQWMsUUFBUSxRQUFRLFlBQVksRUFBRTtBQUNsRCxJQUFNLDJCQUEyQjtBQUNqQyxJQUFJLHVCQUF1QjtBQUUzQixlQUFlLENBQUMsT0FBaUI7QUFDL0IsVUFBUSxRQUFRLFlBQVksRUFBRSxNQUFNLGFBQWEsT0FBTyxHQUFHLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDOUUsQ0FBQztBQUVELFNBQVMsMkJBQWlDO0FBQ3hDLHlCQUF1QixLQUFLLElBQUksSUFBSTtBQUN0QztBQUlBLFFBQVEsUUFBUSxZQUFZLFlBQVksWUFBWTtBQUNsRCxRQUFNLEtBQUssdUJBQXVCLEVBQUUsU0FBUyxZQUFZLENBQUM7QUFDMUQsUUFBTSxPQUFPLFNBQVM7QUFDeEIsQ0FBQztBQUVELFFBQVEsUUFBUSxVQUFVLFlBQVksTUFBTTtBQUMxQyxPQUFLLE9BQU8sU0FBUztBQUN2QixDQUFDO0FBR0QsS0FBSyxPQUFPLGFBQWE7QUFFekIsZUFBZSxPQUFPLFFBQStCO0FBQ25ELE1BQUk7QUFDRixVQUFNLGFBQWE7QUFDbkIsVUFBTSxzQkFBc0I7QUFDNUIsVUFBTSw0QkFBNEI7QUFDbEMsVUFBTSxxQkFBcUI7QUFHM0IsVUFBTSxTQUFTLE1BQU0sb0JBQW9CLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBSTtBQUNqRSxRQUFJLFNBQVMsRUFBRyxPQUFNLEtBQUssMEJBQTBCLEVBQUUsT0FBTyxDQUFDO0FBQy9ELFVBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBSSxTQUFTLE9BQU8sU0FBUyxTQUFTLFNBQVMsTUFBTTtBQUNuRCxZQUFNLGlCQUFpQixLQUFLO0FBQzVCLFlBQU0sb0JBQW9CLEtBQUs7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTSxjQUFjO0FBQUEsUUFDbEIsUUFBUTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWU7QUFBQSxRQUNmLHdCQUF3QjtBQUFBLFFBQ3hCLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFDRCxZQUFNLEtBQUssd0NBQXdDLEVBQUUsT0FBTyxDQUFDO0FBQUEsSUFDL0Q7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sTUFBTyxlQUFlLEVBQUUsUUFBUSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFBQSxFQUMvRDtBQUNGO0FBWUEsZUFBZSx1QkFBc0M7QUFDbkQsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFBQSxFQUN2RixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssNkJBQTZCLGNBQWMsR0FBRyxDQUFDO0FBQzFEO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxPQUFPLElBQUksT0FBTyxTQUFVO0FBQ2hDLFFBQUk7QUFDRixZQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTyxDQUFDLGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl0QixPQUFPO0FBQUEsTUFDVCxDQUFDO0FBQ0QsWUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU8sQ0FBQyxZQUFZO0FBQUEsTUFDdEIsQ0FBQztBQUNELFlBQU0sS0FBSyxxQ0FBcUM7QUFBQSxRQUM5QyxPQUFPLElBQUk7QUFBQSxRQUNYLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRTtBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNILFNBQVMsS0FBSztBQUlaLFlBQU0sS0FBSyx3Q0FBd0M7QUFBQSxRQUNqRCxPQUFPLElBQUk7QUFBQSxRQUNYLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRTtBQUFBLFFBQzdCLEdBQUcsY0FBYyxHQUFHO0FBQUEsTUFDdEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLFFBQU0sUUFBUSxPQUFPLE1BQU0sYUFBYTtBQUN4QyxRQUFNLFFBQVEsT0FBTyxNQUFNLG1CQUFtQjtBQUM5QyxRQUFNLFFBQVEsT0FBTyxPQUFPLGVBQWUsRUFBRSxpQkFBaUIsb0JBQW9CLENBQUM7QUFDbkYsUUFBTSxRQUFRLE9BQU8sT0FBTyxxQkFBcUI7QUFBQSxJQUMvQyxpQkFBaUIsZ0NBQWdDO0FBQUEsRUFDbkQsQ0FBQztBQUNIO0FBTUEsSUFBSSxrQkFBeUQ7QUFDN0QsSUFBTSw2QkFBNkIsS0FBSyxLQUFLO0FBTTdDLElBQU0sOEJBQThCLG9CQUFJLElBQStCO0FBS3ZFLElBQU0saUJBQWlCO0FBRXZCLGVBQWUsd0JBQXVDO0FBRXBELFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLE1BQUksU0FBUyxRQUFRLEVBQUUsWUFBWSxPQUFPO0FBQ3hDLHVCQUFtQixFQUFFLHFCQUFxQjtBQUFBLEVBQzVDLE9BQU87QUFDTCx5QkFBcUI7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyx1QkFBNkI7QUFDcEMsTUFBSSxvQkFBb0IsTUFBTTtBQUM1QixrQkFBYyxlQUFlO0FBQzdCLHNCQUFrQjtBQUFBLEVBQ3BCO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixhQUEyQjtBQUNyRCx1QkFBcUI7QUFDckIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sV0FBVyxDQUFDO0FBQUEsRUFDdkQ7QUFDQSxvQkFBa0IsWUFBWSxNQUFNO0FBQ2xDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELDJCQUF5QjtBQUN6QixRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLGFBQWE7QUFBQSxJQUNiLGVBQWU7QUFBQSxJQUNmLGtCQUFrQjtBQUFBLElBQ2xCLHVCQUF1QjtBQUFBLElBQ3ZCLGlCQUFpQjtBQUFBLElBQ2pCLGVBQWU7QUFBQSxFQUNqQixDQUFDO0FBQ0QscUJBQW1CLEVBQUUscUJBQXFCO0FBQzFDLFFBQU0sS0FBSyw0QkFBNEIsRUFBRSxjQUFjLEVBQUUsc0JBQXNCLENBQUM7QUFFaEYsT0FBSyxlQUFlO0FBQ3BCLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHVCQUFxQjtBQUNyQixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxNQUFNLGVBQWU7QUFBQSxJQUM5QixVQUFVLE1BQU0saUJBQWlCO0FBQUEsSUFDakMsVUFBVSxNQUFNLGlCQUFpQjtBQUFBLEVBQ25DLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUFBLEVBQ3ZGLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpQ0FBaUMsY0FBYyxHQUFHLENBQUM7QUFDOUQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixNQUFJLGNBQWM7QUFDbEIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxPQUFPLElBQUksT0FBTyxTQUFVO0FBQ2hDLFFBQUksSUFBSSxVQUFXO0FBQ25CLFFBQUk7QUFDRixZQUFNLFVBQVcsTUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3JELFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU87QUFBQSxRQUNQLE1BQU8sTUFBTTtBQUlYLGdCQUFNLE9BQTBCO0FBQUEsWUFDOUIsS0FBSztBQUFBLFlBQ0wsTUFBTTtBQUFBLFlBQ04sU0FBUztBQUFBLFlBQ1QsT0FBTztBQUFBLFlBQ1AsU0FBUztBQUFBLFlBQ1QsWUFBWTtBQUFBLFVBQ2Q7QUFDQSxnQkFBTSxRQUFTLFNBQVMsaUJBQXdDLFNBQVM7QUFDekUsZ0JBQU0sY0FBYyxJQUFJLGNBQWMsV0FBVyxJQUFJLENBQUM7QUFDdEQsZ0JBQU0sY0FBYyxJQUFJLGNBQWMsU0FBUyxJQUFJLENBQUM7QUFDcEQsaUJBQU8sU0FBUztBQUFBLFlBQ2QsS0FBSyxTQUFTLGdCQUFnQjtBQUFBLFlBQzlCLFVBQVU7QUFBQSxVQUNaLENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRixDQUFDO0FBQ0QscUJBQWU7QUFBQSxJQUVqQixRQUFRO0FBQUEsSUFHUjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGNBQWMsR0FBRztBQUNuQixVQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBSSxTQUFTLE1BQU07QUFDakIsV0FBSyxlQUFlO0FBQ3BCLFlBQU0scUJBQXFCLElBQUk7QUFBQSxJQUVqQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMseUJBQStCO0FBQ3RDLFFBQU0sU0FBUyxLQUFLLElBQUksSUFBSTtBQUM1QixhQUFXLENBQUMsT0FBTyxLQUFLLEtBQUssNkJBQTZCO0FBQ3hELFFBQUksTUFBTSxZQUFZLE9BQVEsNkJBQTRCLE9BQU8sS0FBSztBQUFBLEVBQ3hFO0FBQ0Y7QUFFQSxTQUFTLCtCQUNQLE9BQ0EsU0FDQSxRQUNBLGFBQ007QUFDTixNQUFJLFVBQVUsUUFBUSxPQUFPLFdBQVcsS0FBSyxZQUFZLFNBQVMsRUFBRztBQUNyRSxRQUFNLGVBQWUsb0JBQUksSUFBWTtBQUNyQyxhQUFXLEtBQUssUUFBUTtBQUN0QixRQUFJLFlBQVksSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEVBQUcsY0FBYSxJQUFJLEVBQUUsUUFBUTtBQUFBLEVBQ2xGO0FBQ0EsUUFBTSxXQUFXLDRCQUE0QixJQUFJLEtBQUs7QUFDdEQsUUFBTSxXQUFXLFVBQVUsWUFBWSxvQkFBSSxJQUFZO0FBQ3ZELGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFVBQU0sU0FBUyxFQUFFLGVBQWUsWUFBWTtBQUM1QyxVQUFNLGNBQWMsRUFBRSxrQkFBa0IsWUFBWSxLQUFLO0FBQ3pELFFBQ0UsWUFBWSxJQUFJLE1BQU0sS0FDckIsZ0JBQWdCLFFBQVEsWUFBWSxJQUFJLFdBQVcsS0FDbkQsRUFBRSxzQkFBc0IsUUFBUSxhQUFhLElBQUksRUFBRSxpQkFBaUIsS0FDcEUsRUFBRSxvQkFBb0IsUUFBUSxhQUFhLElBQUksRUFBRSxlQUFlLEtBQ2hFLEVBQUUsdUJBQXVCLFFBQVEsYUFBYSxJQUFJLEVBQUUsa0JBQWtCLEdBQ3ZFO0FBQ0EsZUFBUyxJQUFJLEVBQUUsUUFBUTtBQUFBLElBQ3pCO0FBQUEsRUFDRjtBQUNBLDhCQUE0QixJQUFJLE9BQU87QUFBQSxJQUNyQyxXQUFXLEtBQUssSUFBSTtBQUFBLElBQ3BCO0FBQUEsSUFDQTtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRUEsUUFBUSxPQUFPLFFBQVEsWUFBWSxDQUFDLFVBQVU7QUFDNUMsTUFBSSxNQUFNLFNBQVMsZUFBZTtBQUNoQyxTQUFLLGlCQUFpQjtBQUFBLEVBQ3hCLFdBQVcsTUFBTSxTQUFTLHFCQUFxQjtBQUM3QyxTQUFLLGlCQUFpQixLQUFLO0FBQUEsRUFDN0I7QUFJRixDQUFDO0FBSUQsSUFBSSxRQUFRLFFBQVEsV0FBVztBQUM3QixVQUFRLE9BQU8sVUFBVSxZQUFZLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU0sUUFBUSxjQUFjLE9BQU87QUFBQSxJQUNyQyxTQUFTLEtBQUs7QUFFWixZQUFNLEtBQUssMENBQTBDLGNBQWMsR0FBRyxDQUFDO0FBQ3ZFLFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUFBLElBQ3hDO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFJQSxRQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsS0FBYyxXQUFXO0FBQzlELE1BQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFHLFFBQU87QUFDbkMsU0FBTyxjQUFjLEtBQUssTUFBTSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQy9DLFNBQUssTUFBTywwQkFBMEIsRUFBRSxNQUFNLElBQUksTUFBTSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDL0UsVUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNILENBQUM7QUFFRCxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxTQUFPLENBQUMsQ0FBQyxLQUFLLE9BQU8sTUFBTSxZQUFZLE9BQVEsRUFBeUIsU0FBUztBQUNuRjtBQUlBLElBQU0sNEJBQTRCLG9CQUFJLElBQTRCO0FBQUEsRUFDaEU7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBRUQsZUFBZSxZQUE4QjtBQUMzQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsZUFBZSxjQUNiLEtBQ0EsUUFDa0I7QUFLbEIsTUFBSSxDQUFFLE1BQU0sVUFBVSxLQUFNLDBCQUEwQixJQUFJLElBQUksSUFBSSxHQUFHO0FBQ25FLFdBQU8sRUFBRSxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUEsRUFDbEM7QUFDQSxVQUFRLElBQUksTUFBTTtBQUFBLElBQ2hCLEtBQUs7QUFDSCxZQUFNO0FBQUEsUUFDSixJQUFJO0FBQUEsUUFDSixJQUFJO0FBQUEsUUFDSixJQUFJLFdBQVc7QUFBQSxRQUNmLElBQUk7QUFBQSxRQUNKLFFBQVEsS0FBSyxNQUFNO0FBQUEsTUFDckI7QUFDQSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN2RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN0RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFVBQUksSUFBSSxVQUFVLFFBQVE7QUFDeEIsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQsV0FBVyxJQUFJLFVBQVUsU0FBUztBQUNoQyxjQUFNLE1BQU8sSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNwRCxPQUFPO0FBQ0wsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQ7QUFDQSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSyxzQkFBc0I7QUFDekIsWUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxVQUFJLFNBQVMsWUFBWSxPQUFPO0FBQzlCLGVBQU8sRUFBRSxTQUFTLE9BQU8sYUFBYSxDQUFDLEdBQUcsa0JBQWtCLENBQUMsRUFBRTtBQUFBLE1BQ2pFO0FBQ0EsNkJBQXVCO0FBQ3ZCLFlBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsWUFBTSxjQUFjLFNBQ2pCLE9BQU8sQ0FBQyxNQUFNLEVBQUUsYUFBYSxNQUFNLEVBQ25DLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUM7QUFDcEMsWUFBTSxRQUFRLFFBQVEsS0FBSyxNQUFNO0FBQ2pDLGFBQU87QUFBQSxRQUNMLFNBQVM7QUFBQSxRQUNUO0FBQUEsUUFDQSxrQkFDRSxVQUFVLE9BQU8sQ0FBQyxJQUFJLE1BQU0sS0FBSyw0QkFBNEIsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLENBQUM7QUFBQSxNQUMzRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLEtBQUssc0JBQXNCO0FBQ3pCLFVBQUksSUFBSSxRQUFRLEdBQUc7QUFDakIsY0FBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFlBQUksV0FBVyxNQUFNO0FBQ25CLGlCQUFPLGlCQUFpQixJQUFJO0FBQzVCLGdCQUFNLHFCQUFxQixNQUFNO0FBQUEsUUFDbkM7QUFBQSxNQUNGO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVyxJQUFJLE1BQU07QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVztBQUNqQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxnQkFBZ0I7QUFDdEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sU0FBUyxNQUFNO0FBQ3JCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFlBQVksSUFBSSxRQUFRLE1BQU07QUFDcEMsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLGFBQWEsSUFBSSxHQUFHLENBQUM7QUFDNUMsWUFBTSxLQUFLLHdCQUF3QixFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDakQsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLGdCQUFnQixJQUFJLEdBQUcsQ0FBQztBQUMvQyxZQUFNLEtBQUssMkJBQTJCLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUNwRCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLGtCQUFrQjtBQUNyQixZQUFNLElBQUksTUFBTSxlQUFlLEVBQUUsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNsRCxVQUFJLENBQUMsSUFBSSxJQUFJO0FBR1gsNkJBQXFCO0FBQ3JCLDRCQUFvQjtBQUNwQiwrQkFBdUI7QUFDdkIsK0JBQXVCO0FBQ3ZCLGNBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxjQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUM3QyxjQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUFBLE1BQy9DLE9BQU87QUFFTCxjQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsWUFBSSxTQUFTLEtBQU0sb0JBQW1CLEVBQUUscUJBQXFCO0FBQUEsTUFDL0Q7QUFDQSxZQUFNLEtBQUssbUNBQW1DLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUM1RCxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0sb0JBQW9CO0FBQzFCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLHFCQUFxQjtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLDRCQUE0QjtBQUMvQixZQUFNLFVBQVUsS0FBSztBQUFBLFFBQ25CO0FBQUEsUUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxJQUFJLE9BQU8sQ0FBQztBQUFBLE1BQ3ZEO0FBQ0EsWUFBTSxlQUFlLEVBQUUsdUJBQXVCLFFBQVEsQ0FBQztBQUV2RCxZQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsVUFBSSxTQUFTLEtBQU0sb0JBQW1CLE9BQU87QUFDN0MsVUFBSSwwQkFBMEIsS0FBTSxzQkFBcUIsT0FBTztBQUNoRSxVQUFJLDZCQUE2QixLQUFNLHlCQUF3QixPQUFPO0FBQ3RFLFVBQUksNkJBQTZCLEtBQU0seUJBQXdCLE9BQU87QUFDdEUsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLGlCQUFpQjtBQUN2QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxrQkFBa0I7QUFDeEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sb0JBQW9CO0FBQzFCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLHFCQUFxQjtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssbUJBQW1CO0FBQ3RCLFlBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsWUFBTSxVQUFVLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUMvRCxZQUFNLFVBQVUsTUFBTSxvQkFBb0IsT0FBTztBQUNqRCxZQUFNLEtBQUssMEJBQTBCLE9BQU87QUFDNUMsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQixJQUFJO0FBQzlCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGNBQWM7QUFDcEIsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFDdEMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssZUFBZTtBQUNsQixZQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFlBQU0sTUFBTSxVQUFVLENBQUM7QUFDdkIsWUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLElBQUksQ0FBQztBQUNqQyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQ0UsYUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLHVCQUF1QjtBQUFBLEVBQ3REO0FBQ0Y7QUFJQSxlQUFlLGlCQUNiLFVBQ0EsS0FDQSxTQUNBLFVBQ0EsYUFDZTtBQUNmLE1BQUksa0JBQWtCLElBQUksUUFBUSxFQUFHO0FBQ3JDLE1BQUksQ0FBQyxnQkFBZ0IsSUFBSSxRQUFRLEVBQUc7QUFFcEMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLFNBQVMsWUFBWSxNQUFPO0FBQ2hDLE1BQUksU0FBUyxnQkFBZ0IsT0FBTztBQUNsQyxVQUFNLHdCQUNKLEtBQUssSUFBSSxJQUFJLHdCQUNaLE1BQU0scUJBQXFCLE1BQU8sUUFDbEMsTUFBTSxrQkFBa0IsTUFBTyxRQUMvQixNQUFNLHFCQUFxQixNQUFPO0FBQ3JDLFFBQUksQ0FBQyxzQkFBdUI7QUFBQSxFQUM5QjtBQUVBLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFnQm5DLFFBQU0sVUFBVSxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDbkUsUUFBTSxPQUFPLElBQUk7QUFBQSxJQUNmLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxhQUFhLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDO0FBQUEsRUFDakY7QUFDQSxRQUFNLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFFMUMsTUFBSTtBQUNKLE1BQUk7QUFDRixpQkFBYSxVQUFVLFVBQVU7QUFBQSxNQUMvQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1A7QUFBQSxNQUNBLGdCQUFnQixvQkFBSSxJQUFZO0FBQUEsTUFDaEMsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxXQUFXLG1CQUFtQixVQUFVLEtBQUssVUFBVSxHQUFHO0FBQ2hFO0FBQUEsRUFDRjtBQUNBLFFBQU0sZUFBZTtBQUFBLElBQ25CLFdBQVc7QUFBQSxJQUNYO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiO0FBUUEsUUFBTSxlQUFlLFdBQVcsT0FBTztBQUN2QyxhQUFXLFNBQVMsY0FBYyxXQUFXLFFBQVEsU0FBUyxJQUFJO0FBQ2xFLFFBQU0sbUJBQW1CLGVBQWUsV0FBVyxPQUFPO0FBQzFELE1BQUksbUJBQW1CLEdBQUc7QUFDeEIsVUFBTSxLQUFLLDRCQUE0QjtBQUFBLE1BQ3JDO0FBQUEsTUFDQSxTQUFTO0FBQUEsTUFDVCxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBQ0EsaUNBQStCLGFBQWEsU0FBUyxXQUFXLFFBQVEsSUFBSTtBQU81RSxNQUFJLFdBQVcsYUFBYSxXQUFXLEdBQUc7QUFDeEMsVUFBTSxLQUFLLDRDQUF1QztBQUFBLE1BQ2hEO0FBQUEsTUFDQSxXQUFXLGVBQWUsUUFBUSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsTUFDL0MsWUFBWSxvQkFBb0IsVUFBVSxPQUFPO0FBQUEsTUFDakQsaUJBQWlCLGlCQUFpQixVQUFVLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFBQSxNQUM3RCxtQkFBbUIsaUJBQWlCLFVBQVUsU0FBUyxDQUFDLFFBQVEsQ0FBQztBQUFBLE1BQ2pFLDBCQUEwQixpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDNUQ7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLE1BQ0QsK0JBQStCLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUNqRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLE1BQ0QsaUNBQWlDLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUNuRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0gsT0FBTztBQUNMLFVBQU0sS0FBSyx3QkFBd0I7QUFBQSxNQUNqQztBQUFBLE1BQ0EsVUFBVSxXQUFXLGFBQWE7QUFBQSxNQUNsQyxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBRUEsTUFBSSxXQUFXLG1CQUFtQixTQUFTLEdBQUc7QUFDNUMsVUFBTTtBQUFBLE1BQ0osV0FBVztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLE1BQUksV0FBVyxPQUFPLFdBQVcsR0FBRztBQUNsQyxVQUFNLGdCQUFnQixNQUFNLG1CQUFtQixjQUFjLFlBQVksV0FBVyxLQUFLLFFBQVE7QUFDakcsUUFBSSxnQkFBZ0IsRUFBRyxPQUFNLGVBQWU7QUFDNUM7QUFBQSxFQUNGO0FBV0EsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELGFBQVcsS0FBSyxXQUFXLFFBQVE7QUFDakMsUUFBSSxFQUFFLGNBQWM7QUFDbEIsWUFBTSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUTtBQUFBLElBQ25ELE9BQU87QUFDTCxZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRO0FBQUEsSUFDbkQ7QUFHQSxVQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsUUFBSSxhQUFhLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDakQsa0JBQVksV0FBVztBQUN2QixrQkFBWSxhQUFhO0FBQ3pCLFlBQU0sa0JBQWtCLFdBQVc7QUFBQSxJQUNyQztBQUNBLFFBQUksZ0JBQWdCLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDcEQscUJBQWUsV0FBVztBQUMxQixxQkFBZSxhQUFhO0FBQzVCLFlBQU0scUJBQXFCLGNBQWM7QUFBQSxJQUMzQztBQUNBLFFBQUksZ0JBQWdCLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDcEQscUJBQWUsV0FBVztBQUMxQixxQkFBZSxhQUFhO0FBQzVCLFlBQU0sbUJBQW1CLEVBQUUsUUFBUTtBQUNuQyxZQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUtBLGFBQVcsV0FBVyxXQUFXLGFBQWE7QUFDNUMsUUFBSSxNQUFNLFlBQVksUUFBUSxRQUFRLEVBQUc7QUFDekMsVUFBTSxrQkFBa0IsUUFBUSxhQUFhLFFBQVEsUUFBUTtBQUFBLEVBQy9EO0FBQ0EsTUFBSSxXQUFXLFlBQVksU0FBUyxHQUFHO0FBQ3JDLFVBQU0sS0FBSywwQ0FBMEM7QUFBQSxNQUNuRDtBQUFBLE1BQ0EsU0FBUyxXQUFXLFlBQVk7QUFBQSxNQUNoQyxhQUFhLE1BQU0scUJBQXFCO0FBQUEsSUFDMUMsQ0FBQztBQUFBLEVBQ0g7QUFnQkEsUUFBTSxpQkFBaUIsU0FBUyxtQkFBbUI7QUFDbkQsUUFBTSxlQUFlLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sa0JBQWtCLE1BQU0sbUJBQW1CO0FBQ2pELE1BQUksaUJBQWlCO0FBQ3JCLE1BQUksdUJBQXVCO0FBQzNCLE1BQUksMEJBQTBCO0FBQzlCLE1BQUksa0JBQWtCO0FBQ3RCLE1BQUksbUJBQW1CO0FBQ3ZCLFFBQU0sYUFBdUMsQ0FBQztBQUM5QyxRQUFNLGdCQUFnQixvQkFBSSxJQUFnQztBQUMxRCxRQUFNLGFBQWEsb0JBQUksSUFBcUM7QUFDNUQsYUFBVyxLQUFLLFdBQVcsUUFBUTtBQUNqQyxVQUFNLE9BQU8sYUFBYSxFQUFFLGNBQWMsSUFBSSxFQUFFLFFBQVE7QUFDeEQsVUFBTSxnQkFBZ0IsQ0FBQyxRQUFRLHdCQUF3QixHQUFHLGVBQWU7QUFDekUsVUFBTSxxQkFBcUIsUUFBUSxJQUFJLEtBQUs7QUFDNUMsa0JBQWMsSUFBSSxFQUFFLFVBQVUscUJBQXFCLGFBQWEsS0FBSztBQUNyRSxRQUFJLGNBQWUsb0JBQW1CO0FBQ3RDLFVBQU0sTUFBTTtBQUFBLE1BQ1YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0o7QUFDQSxVQUFNLGtCQUNKLFNBQVMsVUFBYSxrQkFBa0IsS0FBSyxHQUFHLEtBQUssQ0FBQyxFQUFFO0FBQzFELFFBQUksc0JBQXNCLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCO0FBQzdELFVBQUksS0FBTSx5QkFBd0I7QUFBQSxVQUM3Qiw0QkFBMkI7QUFDaEMsaUJBQVcsSUFBSSxFQUFFLFVBQVUsU0FBUztBQUNwQztBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsS0FBSyxRQUFRLEtBQUs7QUFDNUIsd0JBQWtCO0FBQ2xCLGlCQUFXLElBQUksRUFBRSxVQUFVLFdBQVc7QUFDdEM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxnQkFBaUIscUJBQW9CO0FBQ3pDLGVBQVcsSUFBSSxFQUFFLFVBQVUsVUFBVTtBQUNyQyxlQUFXLEtBQUssQ0FBQztBQUFBLEVBQ25CO0FBQ0EsTUFBSSxpQkFBaUIsR0FBRztBQUN0QixVQUFNLEtBQUssbUNBQW1DO0FBQUEsTUFDNUM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSx1QkFBdUIsMEJBQTBCLEdBQUc7QUFDdEQsVUFBTSxhQUFhLHVCQUF1QjtBQUMxQyxVQUFNLEtBQUssb0VBQW9FO0FBQUEsTUFDN0U7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULGFBQWE7QUFBQSxNQUNiLGtCQUFrQjtBQUFBLE1BQ2xCLFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFDRCxVQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsUUFBSSxXQUFXLE1BQU07QUFDbkIsYUFBTyxtQkFBbUIsT0FBTyxtQkFBbUIsS0FBSztBQUN6RCxZQUFNLHFCQUFxQixNQUFNO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBQ0EsTUFBSSxrQkFBa0IsS0FBSyxnQkFBZ0I7QUFDekMsVUFBTSxLQUFLLDBDQUEwQztBQUFBLE1BQ25EO0FBQUEsTUFDQSxLQUFLO0FBQUEsTUFDTCxRQUFRO0FBQUEsTUFDUix1QkFBdUIsaUJBQWlCLGdCQUFnQjtBQUFBLElBQzFELENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLEtBQUssdUNBQXVDO0FBQUEsTUFDaEQ7QUFBQSxNQUNBLFVBQVU7QUFBQSxNQUNWO0FBQUEsTUFDQSxXQUFXLFdBQVc7QUFBQSxJQUN4QixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU07QUFBQSxJQUNKLFdBQVcsT0FBTztBQUFBLE1BQUksQ0FBQyxNQUNyQixtQkFBbUIsR0FBRyxVQUFVLFlBQVksY0FBYyxJQUFJLEVBQUUsUUFBUSxHQUFHLFdBQVcsSUFBSSxFQUFFLFFBQVEsQ0FBQztBQUFBLElBQ3ZHO0FBQUEsRUFDRjtBQVNBLFFBQU0sc0JBQXNCLFdBQVcsUUFBUSxRQUFRO0FBQ3ZELFFBQU0sNEJBQTRCLFdBQVcsUUFBUSxNQUFNLFFBQVE7QUFDbkUsUUFBTSx1QkFBdUIsTUFBTTtBQUFBLElBQ2pDO0FBQUEsSUFDQTtBQUFBLElBQ0EsV0FBVztBQUFBLElBQ1g7QUFBQSxFQUNGO0FBQ0EsTUFBSSxXQUFXLFdBQVcsR0FBRztBQUMzQixRQUFJLHVCQUF1QixFQUFHLE9BQU0sZUFBZTtBQUNuRDtBQUFBLEVBQ0Y7QUFHQSxRQUFNLFdBQVcsb0JBQUksSUFBOEI7QUFDbkQsYUFBVyxLQUFLLFlBQVk7QUFDMUIsVUFBTSxNQUFNLFNBQVMsSUFBSSxFQUFFLGNBQWMsS0FBSyxDQUFDO0FBQy9DLFFBQUksS0FBSyxDQUFDO0FBQ1YsYUFBUyxJQUFJLEVBQUUsZ0JBQWdCLEdBQUc7QUFBQSxFQUNwQztBQUVBLGFBQVcsQ0FBQyxRQUFRLE1BQU0sS0FBSyxVQUFVO0FBQ3ZDLFVBQU0sTUFBTSxNQUFNLGdCQUFnQixRQUFRLFlBQVksS0FBSyxRQUFRO0FBQ25FLFFBQUksUUFBUTtBQUNaLFFBQUksV0FBVztBQUNmLFFBQUksZ0JBQWdCO0FBQ3BCLFFBQUksa0JBQWtCO0FBQ3RCLGVBQVcsS0FBSyxRQUFRO0FBQ3RCLFlBQU0sV0FBVyxJQUFJLGFBQWEsRUFBRSxRQUFRO0FBQzVDLFVBQUksVUFBVTtBQUdaLGlCQUFTLGVBQWU7QUFDeEIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGdCQUFnQixFQUFFO0FBQzNCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxjQUFjLEVBQUU7QUFDekIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGlCQUFpQixFQUFFO0FBQzVCLGNBQU0sT0FBTyxTQUFTLG1CQUFtQixTQUFTLG1CQUFtQixTQUFTLENBQUM7QUFDL0UsY0FBTSxPQUFPLEVBQUUsbUJBQW1CLENBQUM7QUFDbkMsWUFBSSxTQUFTLENBQUMsUUFBUSxLQUFLLGdCQUFnQixLQUFLLGNBQWM7QUFDNUQsbUJBQVMsbUJBQW1CLEtBQUssSUFBSTtBQUFBLFFBQ3ZDO0FBQ0EsMkJBQW1CO0FBQUEsTUFDckIsT0FBTztBQUNMLGNBQU0sVUFBMEIsRUFBRSxHQUFHLEdBQUcsZ0JBQWdCLElBQUksT0FBTztBQUNuRSxZQUFJLGFBQWEsRUFBRSxRQUFRLElBQUk7QUFDL0IsaUJBQVM7QUFDVCxZQUFJLGNBQWMsSUFBSSxFQUFFLFFBQVEsTUFBTSxXQUFZLGtCQUFpQjtBQUFBLFlBQzlELGFBQVk7QUFBQSxNQUNuQjtBQUNBLFVBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQ2hELFlBQUksbUJBQW1CLEtBQUssRUFBRSxRQUFRO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTSxpQkFBaUIsUUFBUSxtQkFBbUIsR0FBRyxDQUFDO0FBQ3RELFFBQUksUUFBUSxLQUFLLGtCQUFrQixHQUFHO0FBQ3BDLFlBQU0sS0FBSyxtQkFBbUI7QUFBQSxRQUM1QjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxLQUFLO0FBQUEsUUFDTCxVQUFVO0FBQUEsUUFDVixrQkFBa0I7QUFBQSxRQUNsQixPQUFPLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRTtBQUFBLE1BQ3ZDLENBQUM7QUFHRCxZQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsVUFBSSxXQUFXLE1BQU07QUFDbkIsZUFBTyxpQkFBaUI7QUFDeEIsZUFBTyxvQkFBb0IsT0FBTyxvQkFBb0IsS0FBSztBQUMzRCxlQUFPLHlCQUNKLE9BQU8seUJBQXlCLEtBQUs7QUFDeEMsY0FBTSxxQkFBcUIsTUFBTTtBQUFBLE1BQ25DO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFVBQVUsdUJBQXVCO0FBQ2pFLFlBQU0sWUFBWSxRQUFRLFdBQVc7QUFBQSxJQUN2QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLHdCQUNiLG1CQUNBLFNBQ0EsWUFDQSxXQUNBLFVBQ2U7QUFDZixRQUFNLGVBQWUsTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELE1BQUksV0FBVztBQUNmLE1BQUksVUFBVTtBQUNkLE1BQUksZ0JBQWdCO0FBRXBCLGFBQVcsS0FBSyxtQkFBbUI7QUFDakMsVUFBTSxTQUFTLEVBQUU7QUFDakIsUUFBSSxDQUFDLFFBQVE7QUFDWCx1QkFBaUI7QUFDakIsWUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFlBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQztBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsT0FBTyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sWUFBWSxDQUFDLEdBQUc7QUFDMUQsaUJBQVc7QUFDWDtBQUFBLElBQ0Y7QUFFQSxVQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsVUFBTSxlQUFlLFFBQVEsRUFBRSxRQUFRO0FBQ3ZDLFVBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxRQUFJLGFBQWEsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNqRCxrQkFBWSxXQUFXO0FBQ3ZCLGtCQUFZLGFBQWE7QUFDekIsWUFBTSxrQkFBa0IsV0FBVztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxtQkFBbUIsRUFBRSxRQUFRO0FBQ25DLFlBQU0scUJBQXFCLGNBQWM7QUFBQSxJQUMzQztBQUVBLFVBQU0sTUFBTSxlQUFlLENBQUM7QUFDNUIsVUFBTSxPQUFPLGFBQWEsTUFBTSxJQUFJLEVBQUUsUUFBUTtBQUM5QyxRQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JCLGlCQUFXO0FBQ1g7QUFBQSxJQUNGO0FBRUEsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxXQUFXLFFBQVE7QUFDekUsVUFBTSxrQkFBa0IsSUFBSSxxQkFBcUIsQ0FBQztBQUNsRCxvQkFBZ0IsRUFBRSxRQUFRLElBQUk7QUFDOUIsUUFBSSxvQkFBb0I7QUFDeEIsUUFBSSxDQUFDLElBQUksbUJBQW1CLFNBQVMsRUFBRSxRQUFRLEdBQUc7QUFDaEQsVUFBSSxtQkFBbUIsS0FBSyxFQUFFLFFBQVE7QUFBQSxJQUN4QztBQUNBLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsbUJBQW1CLEdBQUcsQ0FBQztBQUN0RCxnQkFBWTtBQUFBLEVBQ2Q7QUFFQSxNQUFJLFdBQVcsS0FBSyxnQkFBZ0IsS0FBSyxVQUFVLEdBQUc7QUFDcEQsVUFBTSxLQUFLLCtCQUErQixFQUFFLFVBQVUsVUFBVSxTQUFTLGNBQWMsQ0FBQztBQUFBLEVBQzFGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsU0FBUyxlQUFlLEdBQTZCO0FBQ25ELFNBQU8sZUFBZSxFQUFFLHNCQUFzQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtBQUM5RTtBQUVBLFNBQVMsa0JBQWtCLEtBQXNCO0FBQy9DLFFBQU0sUUFBUSxJQUFJLE1BQU0sR0FBRztBQUMzQixTQUFPLE1BQU0sTUFBTSxTQUFTLENBQUMsTUFBTTtBQUNyQztBQUVBLFNBQVMsbUJBQW1CLEtBQXdCO0FBQ2xELFNBQ0UsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFNBQzlCLE9BQU8sS0FBSyxJQUFJLHFCQUFxQixDQUFDLENBQUMsRUFBRSxTQUN6QyxPQUFPLEtBQUssSUFBSSx3QkFBd0IsQ0FBQyxDQUFDLEVBQUU7QUFFaEQ7QUFFQSxTQUFTLGVBQWUsTUFBMkI7QUFDakQsU0FBTztBQUFBLElBQ0wsS0FBSyxpQkFBaUIsWUFBWTtBQUFBLElBQ2xDLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxFQUNQLEVBQUUsS0FBSyxHQUFHO0FBQ1o7QUFFQSxTQUFTLHFCQUFxQixNQUE2QjtBQUN6RCxRQUFNLFFBQVEsS0FBSyxNQUFNLGdDQUFnQztBQUN6RCxTQUFPLFFBQVEsQ0FBQyxLQUFLO0FBQ3ZCO0FBRUEsU0FBUyxrQkFDUCxRQUNBLFVBQ0EsWUFDQSxVQUNBLFdBQ2U7QUFDZixRQUFNLG1CQUFtQixJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsT0FBTyxZQUFZLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQztBQUMxRixRQUFNLE9BQU8sSUFBSSxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDdkQsUUFBTSxNQUFNLG9CQUFJLElBQXlCO0FBQ3pDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksRUFBRSxlQUFlLGFBQWEsQ0FBQyxFQUFFLG1CQUFvQjtBQUN6RCxVQUFNLG9CQUFvQixpQkFBaUIsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDO0FBQzdFLFFBQUksQ0FBQyxrQkFBbUI7QUFDeEIsVUFBTSxXQUFXLEtBQUssSUFBSSxFQUFFLGtCQUFrQjtBQUM5QyxVQUFNLGlCQUFpQixVQUFVLGtCQUFrQixxQkFBcUIsRUFBRSxpQkFBaUIsRUFBRSxJQUFJO0FBQ2pHLFVBQU0sbUJBQW1CLGlCQUNwQixpQkFBaUIsSUFBSSxlQUFlLFlBQVksQ0FBQyxLQUFLLFdBQ3ZEO0FBQ0osVUFBTSxPQUFvQjtBQUFBLE1BQ3hCLGtCQUFrQixFQUFFO0FBQUEsTUFDcEIsc0JBQXNCLEVBQUUsY0FBYztBQUFBLE1BQ3RDLG9CQUFvQjtBQUFBLE1BQ3BCLGtCQUFrQixFQUFFO0FBQUEsTUFDcEIsYUFBYSxFQUFFO0FBQUEsTUFDZixtQkFBbUIsRUFBRTtBQUFBLE1BQ3JCLHdCQUF3QjtBQUFBLE1BQ3hCLDRCQUE0QixVQUFVLGNBQWM7QUFBQSxNQUNwRCwwQkFBMEI7QUFBQSxNQUMxQixhQUFhO0FBQUEsTUFDYixnQkFBZ0I7QUFBQSxNQUNoQjtBQUFBLE1BQ0EsWUFBWTtBQUFBLElBQ2Q7QUFDQSxRQUFJLElBQUksZUFBZSxJQUFJLEdBQUcsSUFBSTtBQUFBLEVBQ3BDO0FBQ0EsU0FBTyxDQUFDLEdBQUcsSUFBSSxPQUFPLENBQUM7QUFDekI7QUFFQSxlQUFlLG1CQUNiLE9BQ0EsWUFDQSxXQUNBLFVBQ2lCO0FBQ2pCLE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUMvQixRQUFNLFdBQVcsb0JBQUksSUFBMkI7QUFDaEQsYUFBVyxRQUFRLE9BQU87QUFDeEIsVUFBTSxNQUFNLFNBQVMsSUFBSSxLQUFLLGdCQUFnQixLQUFLLENBQUM7QUFDcEQsUUFBSSxLQUFLLElBQUk7QUFDYixhQUFTLElBQUksS0FBSyxrQkFBa0IsR0FBRztBQUFBLEVBQ3pDO0FBQ0EsTUFBSSxRQUFRO0FBQ1osYUFBVyxDQUFDLFFBQVEsV0FBVyxLQUFLLFVBQVU7QUFDNUMsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxXQUFXLFFBQVE7QUFDekUsVUFBTSxVQUFVLElBQUksd0JBQXdCLENBQUM7QUFDN0MsUUFBSSxpQkFBaUI7QUFDckIsZUFBVyxRQUFRLGFBQWE7QUFDOUIsWUFBTSxVQUF1QixFQUFFLEdBQUcsTUFBTSxnQkFBZ0IsSUFBSSxPQUFPO0FBQ25FLFlBQU0sTUFBTSxlQUFlLE9BQU87QUFDbEMsVUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFHLG1CQUFrQjtBQUNyQyxjQUFRLEdBQUcsSUFBSTtBQUNmLFVBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLFFBQVEsZ0JBQWdCLEdBQUc7QUFDOUQsWUFBSSxtQkFBbUIsS0FBSyxRQUFRLGdCQUFnQjtBQUFBLE1BQ3REO0FBQ0EsVUFBSSxDQUFDLElBQUksbUJBQW1CLFNBQVMsUUFBUSxpQkFBaUIsR0FBRztBQUMvRCxZQUFJLG1CQUFtQixLQUFLLFFBQVEsaUJBQWlCO0FBQUEsTUFDdkQ7QUFBQSxJQUNGO0FBQ0EsUUFBSSxtQkFBbUIsRUFBRztBQUMxQixRQUFJLHVCQUF1QjtBQUMzQixRQUFJLENBQUMsSUFBSSxlQUFlLFNBQVMsUUFBUSxFQUFHLEtBQUksZUFBZSxLQUFLLFFBQVE7QUFDNUUsUUFBSSxrQkFBa0I7QUFDdEIsVUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixVQUFNLGlCQUFpQixRQUFRLG1CQUFtQixHQUFHLENBQUM7QUFDdEQsYUFBUztBQUNULFVBQU0sS0FBSywwQkFBMEI7QUFBQSxNQUNuQztBQUFBLE1BQ0E7QUFBQSxNQUNBLE9BQU87QUFBQSxNQUNQLE9BQU8sT0FBTyxLQUFLLE9BQU8sRUFBRTtBQUFBLElBQzlCLENBQUM7QUFBQSxFQUNIO0FBQ0EsU0FBTztBQUNUO0FBc0JBLGVBQWUsc0JBQ2IsUUFDQSxVQUNlO0FBQ2YsTUFBSSxPQUFPLFdBQVcsRUFBRztBQUd6QixRQUFNLGVBQWUsb0JBQUksSUFBWTtBQUNyQyxhQUFXLEtBQUssT0FBUSxjQUFhLElBQUksRUFBRSxRQUFRO0FBRW5ELE1BQUksV0FBVztBQUNmLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFVBQU0sVUFBc0QsQ0FBQztBQUM3RCxRQUFJLEVBQUUsbUJBQW1CO0FBQ3ZCLGNBQVEsS0FBSyxFQUFFLElBQUksRUFBRSxtQkFBbUIsTUFBTSxFQUFFLGlCQUFpQixDQUFDO0FBQUEsSUFDcEU7QUFDQSxRQUFJLEVBQUUsZ0JBQWlCLFNBQVEsS0FBSyxFQUFFLElBQUksRUFBRSxpQkFBaUIsTUFBTSxLQUFLLENBQUM7QUFDekUsUUFBSSxFQUFFLG1CQUFvQixTQUFRLEtBQUssRUFBRSxJQUFJLEVBQUUsb0JBQW9CLE1BQU0sS0FBSyxDQUFDO0FBQy9FLGVBQVcsS0FBSyxTQUFTO0FBQ3ZCLFVBQUksYUFBYSxJQUFJLEVBQUUsRUFBRSxFQUFHO0FBQzVCLFVBQUksTUFBTSxZQUFZLEVBQUUsRUFBRSxFQUFHO0FBQzdCLFlBQU0sa0JBQWtCLEVBQUUsTUFBTSxFQUFFLEVBQUU7QUFDcEMsa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRjtBQUNBLE1BQUksV0FBVyxHQUFHO0FBQ2hCLFVBQU0sS0FBSyxzREFBc0Q7QUFBQSxNQUMvRDtBQUFBLE1BQ0E7QUFBQSxNQUNBLGFBQWEsTUFBTSxxQkFBcUI7QUFBQSxJQUMxQyxDQUFDO0FBQUEsRUFDSDtBQUNGO0FBRUEsZUFBZSw0QkFDYixRQUNBLGFBQ0EsVUFDZTtBQUNmLE1BQUksT0FBTyxXQUFXLEtBQUssWUFBWSxTQUFTLEVBQUc7QUFDbkQsTUFBSSxTQUFTLFNBQVMsYUFBYSxLQUFLLFNBQVMsU0FBUyxxQkFBcUIsRUFBRztBQUVsRixRQUFNLGFBQWEsb0JBQUksSUFBb0I7QUFDM0MsYUFBVyxLQUFLLFFBQVE7QUFDdEIsVUFBTSxTQUFTLEVBQUUsZUFBZSxZQUFZO0FBQzVDLFFBQUksQ0FBQyxZQUFZLElBQUksTUFBTSxFQUFHO0FBRTlCLFVBQU0sU0FBUyxFQUFFLG1CQUFtQixFQUFFO0FBQ3RDLFVBQU0sU0FBUyxXQUFXLEVBQUUsWUFBWSxFQUFFLHNCQUFzQjtBQUNoRSxVQUFNLGNBQWMsRUFBRSxzQkFBc0I7QUFDNUMsUUFBSSxVQUFVLEVBQUUsY0FBYyxHQUFHO0FBQy9CLGlCQUFXLElBQUksUUFBUSxFQUFFLGNBQWM7QUFBQSxJQUN6QyxXQUFXLGVBQWUsUUFBUTtBQUNoQyxpQkFBVyxJQUFJLFFBQVEsRUFBRSxjQUFjO0FBQUEsSUFDekM7QUFBQSxFQUNGO0FBRUEsTUFBSSxXQUFXO0FBQ2YsYUFBVyxDQUFDLFNBQVMsTUFBTSxLQUFLLFlBQVk7QUFDMUMsVUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFVBQU0sa0JBQWtCLFFBQVEsT0FBTztBQUN2QyxVQUFNLFFBQVEsTUFBTSxxQkFBcUI7QUFDekMsUUFBSSxRQUFRLE9BQVEsYUFBWTtBQUFBLEVBQ2xDO0FBQ0EsTUFBSSxXQUFXLEdBQUc7QUFDaEIsVUFBTSxLQUFLLHdDQUF3QztBQUFBLE1BQ2pEO0FBQUEsTUFDQTtBQUFBLE1BQ0EsYUFBYSxNQUFNLHFCQUFxQjtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxlQUFlLGdCQUNiLFFBQ0EsSUFDQSxXQUNBLFVBQ29CO0FBQ3BCLFFBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUNyQyxNQUFJLElBQUssUUFBTztBQUNoQixRQUFNLE1BQWlCO0FBQUEsSUFDckIsUUFBUSxTQUFTO0FBQUEsSUFDakIsZ0JBQWdCO0FBQUEsSUFDaEIsWUFBWTtBQUFBLElBQ1osaUJBQWlCO0FBQUEsSUFDakIsY0FBYyxDQUFDO0FBQUEsSUFDZixtQkFBbUIsQ0FBQztBQUFBLElBQ3BCLG9CQUFvQixDQUFDO0FBQUEsSUFDckIsZ0JBQWdCLENBQUMsUUFBUTtBQUFBLElBQ3pCLFlBQVk7QUFBQSxFQUNkO0FBQ0EsUUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixRQUFNLEtBQUssZUFBZSxFQUFFLFFBQVEsS0FBSyxXQUFXLElBQUksTUFBTSxFQUFFLENBQUM7QUFDakUsU0FBTztBQUNUO0FBSUEsSUFBSSxhQUE0QixRQUFRLFFBQVE7QUFnQmhELGVBQWUsbUJBQWtDO0FBQy9DLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxNQUFNLEtBQUssSUFBSTtBQUNyQixRQUFNLFVBQW9CLENBQUM7QUFDM0IsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELGNBQVEsS0FBSyxNQUFNO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxhQUFhLFNBQVMsTUFBTTtBQUNwQztBQUVBLGVBQWUsOEJBQTZDO0FBTzFELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsUUFBTSxVQUFvQixDQUFDO0FBQzNCLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFVBQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxlQUFlO0FBQzNDLFFBQUksT0FBTyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsZUFBZTtBQUN4RCxjQUFRLEtBQUssTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sYUFBYSxTQUFTLE1BQU07QUFDcEM7QUFFQSxlQUFlLFNBQVMsUUFBK0I7QUFDckQsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLGFBQWEsT0FBTyxLQUFLLEdBQUcsR0FBRyxNQUFNO0FBQzdDO0FBRUEsZUFBZSxZQUFZLFFBQWdCLFFBQStCO0FBQ3hFLFFBQU0sYUFBYSxDQUFDLE1BQU0sR0FBRyxNQUFNO0FBQ3JDO0FBRUEsZUFBZSxhQUFhLFNBQW1CLFFBQStCO0FBQzVFLFFBQU0sU0FBUyxDQUFDLEdBQUcsSUFBSSxJQUFJLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDO0FBQy9ELE1BQUksT0FBTyxXQUFXLEVBQUc7QUFDekIsUUFBTSxNQUFNLFdBQVcsS0FBSyxNQUFNLG1CQUFtQixRQUFRLE1BQU0sQ0FBQztBQUNwRSxlQUFhLElBQUksTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQy9CLFNBQU87QUFDVDtBQUVBLGVBQWUsbUJBQW1CLFNBQW1CLFFBQStCO0FBQ2xGLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxRQUFxQixDQUFDO0FBQzVCLGFBQVcsVUFBVSxTQUFTO0FBQzVCLFVBQU0sTUFBTSxJQUFJLE1BQU07QUFDdEIsUUFBSSxDQUFDLElBQUs7QUFDVixVQUFNLFNBQVMsT0FBTyxPQUFPLElBQUksWUFBWTtBQUM3QyxVQUFNLG9CQUFvQixPQUFPLE9BQU8sSUFBSSxxQkFBcUIsQ0FBQyxDQUFDO0FBQ25FLFVBQU0sZUFBZSxPQUFPLE9BQU8sSUFBSSx3QkFBd0IsQ0FBQyxDQUFDO0FBQ2pFLFFBQUksT0FBTyxXQUFXLEtBQUssa0JBQWtCLFdBQVcsS0FBSyxhQUFhLFdBQVcsR0FBRztBQUN0RixZQUFNLGVBQWUsTUFBTTtBQUMzQixZQUFNLGlCQUFpQixRQUFRLENBQUM7QUFDaEM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLGVBQWUsUUFBUSxLQUFLLFFBQVEsbUJBQW1CLFlBQVksQ0FBQztBQUFBLEVBQ2pGO0FBQ0EsTUFBSSxNQUFNLFdBQVcsRUFBRztBQUV4QixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLE1BQU07QUFDdEQsVUFBTSxLQUFLLCtDQUErQztBQUFBLE1BQ3hELE9BQU8sTUFBTTtBQUFBLE1BQ2IsU0FBUyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsSUFDdkQsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxRQUFNLFFBQVEsTUFBTSxRQUFRLENBQUMsU0FBUztBQUFBLElBQ3BDO0FBQUEsTUFDRSxNQUFNLEtBQUs7QUFBQSxNQUNYLGVBQWVDLFVBQVMsS0FBSyxVQUFVLEtBQUssU0FBUyxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsSUFDdEU7QUFBQSxJQUNBO0FBQUEsTUFDRSxNQUFNLEtBQUs7QUFBQSxNQUNYLGVBQWVBLFVBQVMsS0FBSyxVQUFVLEtBQUssTUFBTSxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsSUFDbkU7QUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNLFlBQVksd0JBQXdCLEtBQUs7QUFFL0MsTUFBSTtBQUNGLFVBQU0sU0FBUyxNQUFNLE9BQU8sWUFBWTtBQUFBLE1BQ3RDO0FBQUEsTUFDQSxTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQ0QsVUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLGVBQVcsUUFBUSxPQUFPO0FBQ3hCLFlBQU0saUJBQWlCLE1BQU0sK0JBQStCLElBQUk7QUFLaEUsWUFBTSxRQUFRLE1BQU0sWUFBWSxHQUFHLEtBQUssTUFBTTtBQUM5QyxZQUFNLFNBQVEsb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUNsRCxZQUFNLGVBQWUsUUFBUSxLQUFLLGNBQWMsUUFBUSxLQUFLLGFBQWE7QUFDMUUsWUFBTSxZQUFZLEtBQUssUUFBUTtBQUFBLFFBQzdCLFlBQVksZUFBZSxLQUFLLE9BQU8sU0FBUyxLQUFLLGtCQUFrQjtBQUFBLFFBQ3ZFLFdBQVc7QUFBQSxRQUNYLGVBQWUsS0FBSyxJQUFJO0FBQUEsUUFDeEIsaUJBQ0csTUFBTSxrQkFBa0IsS0FBSyxLQUFLLE9BQU8sU0FBUyxLQUFLLGtCQUFrQjtBQUFBLFFBQzVFLGVBQWU7QUFBQSxNQUNqQixDQUFDO0FBR0QsWUFBTSxRQUFRLElBQUksS0FBSyxNQUFNLEtBQUssQ0FBQztBQUNuQyxZQUFNLFVBQVMsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDdEMsaUJBQVcsS0FBSyxLQUFLLFFBQVE7QUFDM0IsY0FBTSxFQUFFLFFBQVEsSUFBSTtBQUFBLFVBQ2xCLElBQUk7QUFBQSxVQUNKLEtBQUs7QUFBQSxZQUNILEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3RDLGNBQU0sRUFBRSxRQUFRLElBQUk7QUFBQSxVQUNsQixJQUFJO0FBQUEsVUFDSixLQUFLLGVBQWUsQ0FBQztBQUFBLFFBQ3ZCO0FBQUEsTUFDRjtBQUNBLFVBQUksS0FBSyxNQUFNLElBQUk7QUFDbkIsWUFBTSxLQUFLLDJCQUEyQjtBQUFBLFFBQ3BDLFFBQVEsS0FBSztBQUFBLFFBQ2I7QUFBQSxRQUNBLFFBQVEsS0FBSyxPQUFPO0FBQUEsUUFDcEIsYUFBYSxLQUFLLGtCQUFrQjtBQUFBLFFBQ3BDLGVBQWUsS0FBSyxhQUFhO0FBQUEsUUFDakMsS0FBSyxLQUFLO0FBQUEsUUFDVixNQUFNLEtBQUs7QUFBQSxRQUNYLGNBQWMsT0FBTztBQUFBLE1BQ3ZCLENBQUM7QUFBQSxJQUNIO0FBQ0EsVUFBTSxrQkFBa0IsR0FBRztBQUMzQixVQUFNLEtBQUssaUNBQWlDO0FBQUEsTUFDMUM7QUFBQSxNQUNBLE1BQU0sTUFBTTtBQUFBLE1BQ1osT0FBTyxNQUFNO0FBQUEsTUFDYixRQUFRLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssT0FBTyxRQUFRLENBQUM7QUFBQSxNQUNuRSxhQUFhLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssa0JBQWtCLFFBQVEsQ0FBQztBQUFBLE1BQ25GLGVBQWUsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxhQUFhLFFBQVEsQ0FBQztBQUFBLE1BQ2hGLFFBQVEsT0FBTztBQUFBLElBQ2pCLENBQUM7QUFDRDtBQUNFLFlBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsWUFBTSxjQUFjO0FBQUEsUUFDbEIsUUFBUTtBQUFBLFFBQ1IsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTztBQUFBLFFBQ1AsZUFBZSxLQUFLO0FBQUEsUUFDcEIsd0JBQXdCLEtBQUs7QUFBQSxRQUM3QixrQkFBa0I7QUFBQSxNQUNwQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osUUFBSSxlQUFlLGFBQWE7QUFDOUIsWUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxZQUFNLFNBQ0osSUFBSSxhQUFhLFNBQ2IsZUFDQSxJQUFJLGFBQWEsZUFDZixpQkFDQSxJQUFJLGFBQWEsWUFDZixrQkFDQSxLQUFLO0FBQ2YsWUFBTSxjQUFjO0FBQUEsUUFDbEI7QUFBQSxRQUNBLE9BQU8sS0FBSztBQUFBLFFBQ1osWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU8sSUFBSTtBQUFBLFFBQ1gsZUFBZSxLQUFLO0FBQUEsUUFDcEIsd0JBQXdCLEtBQUs7QUFBQSxRQUM3QixrQkFDRSxJQUFJLGFBQWEsZUFBZSxJQUFJLG1CQUFtQixLQUFLO0FBQUEsTUFDaEUsQ0FBQztBQUNELFlBQU0sTUFBTyx3QkFBd0I7QUFBQSxRQUNuQztBQUFBLFFBQ0EsU0FBUyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsUUFDckQsTUFBTSxNQUFNO0FBQUEsUUFDWixPQUFPLE1BQU07QUFBQSxRQUNiLFVBQVUsSUFBSTtBQUFBLFFBQ2QsUUFBUSxJQUFJO0FBQUEsUUFDWixTQUFTLElBQUk7QUFBQSxRQUNiLGtCQUFrQixJQUFJO0FBQUEsTUFDeEIsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMLFlBQU0sTUFBTyx3QkFBd0I7QUFBQSxRQUNuQztBQUFBLFFBQ0EsU0FBUyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsUUFDckQsTUFBTSxNQUFNO0FBQUEsUUFDWixPQUFPLE1BQU07QUFBQSxRQUNiLEdBQUcsY0FBYyxHQUFHO0FBQUEsTUFDdEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUVGLFVBQUU7QUFDQSxVQUFNLGVBQWU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyxlQUNQLFFBQ0EsS0FDQSxRQUNBLG1CQUNBLGNBQ1c7QUFDWCxRQUFNLEtBQUssV0FBVyxJQUFJLFVBQVU7QUFDcEMsUUFBTSxNQUFNLElBQUksV0FBVyxNQUFNLEdBQUcsRUFBRTtBQUN0QyxRQUFNLFdBQVcsV0FBVyxJQUFJLE1BQU07QUFDdEMsUUFBTSxVQUFVLE9BQU8sTUFBTSxJQUFJLEVBQUUsSUFBSSxRQUFRO0FBQy9DLFFBQU0sV0FBVyxRQUFRLE1BQU0sSUFBSSxFQUFFLElBQUksUUFBUTtBQUNqRCxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxTQUFTO0FBQUEsTUFDUCxnQkFBZ0I7QUFBQSxNQUNoQixnQkFBZ0IsSUFBSTtBQUFBLE1BQ3BCLGdCQUFnQjtBQUFBLE1BQ2hCLGFBQWEsSUFBSTtBQUFBLE1BQ2pCLFVBQVUsSUFBSSxlQUFlLEtBQUssR0FBRztBQUFBLE1BQ3JDLFlBQVksVUFBVTtBQUFBLE1BQ3RCLFlBQVksSUFBSTtBQUFBLE1BQ2hCO0FBQUEsTUFDQSxvQkFBb0I7QUFBQSxNQUNwQixlQUFlO0FBQUEsSUFDakI7QUFBQSxJQUNBLE1BQU07QUFBQSxNQUNKLGdCQUFnQjtBQUFBLE1BQ2hCLGdCQUFnQixJQUFJO0FBQUEsTUFDcEIsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYSxJQUFJO0FBQUEsTUFDakIsb0JBQW9CLElBQUk7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsd0JBQXdCLE9BQTRCO0FBQzNELE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdEIsVUFBTSxPQUFPLE1BQU0sQ0FBQztBQUNwQixVQUFNQyxvQkFBbUIsS0FBSyxrQkFBa0I7QUFDaEQsVUFBTUMsYUFBWSxLQUFLLGFBQWE7QUFDcEMsVUFBTUMsV0FDSEYsb0JBQW1CLElBQUksS0FBS0EsaUJBQWdCLGlCQUFpQixPQUM3REMsYUFBWSxJQUFJLEtBQUtBLFVBQVMsZ0JBQWdCQSxlQUFjLElBQUksS0FBSyxHQUFHLEtBQUs7QUFDaEYsV0FBTyxZQUFZLEtBQUssTUFBTSxJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssT0FBTyxNQUFNLFNBQVMsS0FBSyxPQUFPLFdBQVcsSUFBSSxLQUFLLEdBQUcsR0FBR0MsT0FBTSxTQUFTLEtBQUssUUFBUTtBQUFBLEVBQzdJO0FBQ0EsUUFBTSxPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUUsS0FBSztBQUM5RCxRQUFNLFdBQVcsS0FBSyxXQUFXLElBQUksS0FBSyxDQUFDLElBQUssR0FBRyxLQUFLLENBQUMsQ0FBQyxLQUFLLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQztBQUNwRixRQUFNLGFBQWEsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxPQUFPLFFBQVEsQ0FBQztBQUM5RSxRQUFNLG1CQUFtQixNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLGtCQUFrQixRQUFRLENBQUM7QUFDL0YsUUFBTSxZQUFZLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssYUFBYSxRQUFRLENBQUM7QUFDbkYsUUFBTSxVQUNILG1CQUFtQixJQUFJLEtBQUssZ0JBQWdCLGlCQUFpQixPQUM3RCxZQUFZLElBQUksS0FBSyxTQUFTLGdCQUFnQixjQUFjLElBQUksS0FBSyxHQUFHLEtBQUs7QUFDaEYsU0FBTyxrQkFBa0IsTUFBTSxNQUFNLFVBQVUsVUFBVSxTQUFTLGVBQWUsSUFBSSxLQUFLLEdBQUcsR0FBRyxNQUFNLEtBQUssUUFBUTtBQUNySDtBQUVBLGVBQWUsK0JBQStCLE1BQWtDO0FBQzlFLFFBQU0sVUFBVSxNQUFNLGFBQWEsS0FBSyxNQUFNO0FBQzlDLE1BQUksQ0FBQyxRQUFTLFFBQU87QUFDckIsTUFBSSxRQUFRLFdBQVcsS0FBSyxJQUFJLE9BQVEsUUFBTyxtQkFBbUIsT0FBTztBQUV6RSxRQUFNLFlBQVksSUFBSTtBQUFBLElBQ3BCLEtBQUssT0FBTyxJQUFJLENBQUMsTUFBTTtBQUFBLE1BQ3JCLEVBQUU7QUFBQSxNQUNGLGNBQWMsRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLGFBQWEsRUFBRSxhQUFhLEVBQUUsWUFBWTtBQUFBLElBQzNGLENBQUM7QUFBQSxFQUNIO0FBQ0EsYUFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3RDLGNBQVUsSUFBSSxFQUFFLFVBQVUsZUFBZSxDQUFDLENBQUM7QUFBQSxFQUM3QztBQUNBLFFBQU0sa0JBQWtELENBQUM7QUFDekQsYUFBVyxDQUFDLFNBQVMsS0FBSyxLQUFLLE9BQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUNuRSxVQUFNLGVBQWUsVUFBVSxJQUFJLE9BQU87QUFDMUMsVUFBTSxhQUFhO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLElBQ1I7QUFDQSxRQUFJLENBQUMsZ0JBQWdCLGlCQUFpQixZQUFZO0FBQ2hELHNCQUFnQixPQUFPLElBQUksRUFBRSxHQUFHLE1BQU07QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLHVCQUF5RCxDQUFDO0FBQ2hFLGFBQVcsQ0FBQyxTQUFTLFdBQVcsS0FBSyxPQUFPLFFBQVEsUUFBUSxxQkFBcUIsQ0FBQyxDQUFDLEdBQUc7QUFDcEYsVUFBTSxlQUFlLFVBQVUsSUFBSSxPQUFPO0FBQzFDLFVBQU0sYUFBYSxlQUFlLFdBQVc7QUFDN0MsUUFBSSxDQUFDLGdCQUFnQixpQkFBaUIsWUFBWTtBQUNoRCwyQkFBcUIsT0FBTyxJQUFJLEVBQUUsR0FBRyxZQUFZO0FBQUEsSUFDbkQ7QUFBQSxFQUNGO0FBQ0EsUUFBTSx3QkFBcUQsQ0FBQztBQUM1RCxhQUFXLENBQUMsS0FBSyxJQUFJLEtBQUssT0FBTyxRQUFRLFFBQVEsd0JBQXdCLENBQUMsQ0FBQyxHQUFHO0FBQzVFLFFBQUksQ0FBQyxLQUFLLGFBQWEsS0FBSyxDQUFDLGtCQUFrQixlQUFlLGFBQWEsTUFBTSxHQUFHLEdBQUc7QUFDckYsNEJBQXNCLEdBQUcsSUFBSSxFQUFFLEdBQUcsS0FBSztBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUVBLFFBQU0sZUFBZSxvQkFBSSxJQUFJO0FBQUEsSUFDM0IsR0FBRyxPQUFPLEtBQUssZUFBZTtBQUFBLElBQzlCLEdBQUcsT0FBTyxLQUFLLG9CQUFvQjtBQUFBLElBQ25DLEdBQUcsT0FBTyxPQUFPLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxTQUFTO0FBQUEsTUFDeEQsS0FBSztBQUFBLE1BQ0wsS0FBSztBQUFBLElBQ1AsQ0FBQztBQUFBLEVBQ0gsQ0FBQztBQUNELFFBQU0saUJBQ0osT0FBTyxLQUFLLGVBQWUsRUFBRSxTQUM3QixPQUFPLEtBQUssb0JBQW9CLEVBQUUsU0FDbEMsT0FBTyxLQUFLLHFCQUFxQixFQUFFO0FBQ3JDLE1BQUksbUJBQW1CLEdBQUc7QUFDeEIsVUFBTSxlQUFlLEtBQUssTUFBTTtBQUNoQyxXQUFPO0FBQUEsRUFDVDtBQUVBLFFBQU0sWUFBWSxTQUFTO0FBQzNCLGFBQVcsU0FBUyxPQUFPLE9BQU8sZUFBZSxHQUFHO0FBQ2xELFVBQU0saUJBQWlCO0FBQUEsRUFDekI7QUFDQSxhQUFXLFFBQVEsT0FBTyxPQUFPLHFCQUFxQixHQUFHO0FBQ3ZELFNBQUssaUJBQWlCO0FBQUEsRUFDeEI7QUFDQSxRQUFNLGFBQWEsS0FBSyxRQUFRO0FBQUEsSUFDOUIsR0FBRztBQUFBLElBQ0gsUUFBUTtBQUFBLElBQ1IsWUFBWSxRQUFRO0FBQUEsSUFDcEIsY0FBYztBQUFBLElBQ2QsbUJBQW1CO0FBQUEsSUFDbkIsc0JBQXNCO0FBQUEsSUFDdEIsb0JBQW9CLFFBQVEsbUJBQW1CLE9BQU8sQ0FBQyxPQUFPLGFBQWEsSUFBSSxFQUFFLENBQUM7QUFBQSxFQUNwRixDQUFDO0FBQ0QsUUFBTSxLQUFLLG1DQUFtQztBQUFBLElBQzVDLFFBQVEsS0FBSztBQUFBLElBQ2IsZUFBZSxLQUFLO0FBQUEsSUFDcEIsVUFBVSxXQUFXLFNBQVM7QUFBQSxJQUM5QixXQUFXO0FBQUEsRUFDYixDQUFDO0FBQ0QsU0FBTztBQUNUO0FBSUEsZUFBZSxXQUFXLFFBQStCO0FBQ3ZELDJCQUF5QjtBQU16QixRQUFNLFlBQVksaUJBQWlCLE1BQU07QUFDekMsUUFBTSxLQUFLLHlCQUF5QixFQUFFLFFBQVEsS0FBSyxlQUFlLENBQUM7QUFDbkUsTUFBSSxDQUFFLE1BQU0sYUFBYSxNQUFNLEdBQUk7QUFDakMsVUFBTSxPQUFNLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ25DLFVBQU0sYUFBYSxRQUFRO0FBQUEsTUFDekIsUUFBUSxTQUFTO0FBQUEsTUFDakIsZ0JBQWdCO0FBQUEsTUFDaEIsWUFBWTtBQUFBLE1BQ1osaUJBQWlCO0FBQUEsTUFDakIsY0FBYyxDQUFDO0FBQUEsTUFDZixtQkFBbUIsQ0FBQztBQUFBLE1BQ3BCLG9CQUFvQixDQUFDO0FBQUEsTUFDckIsZ0JBQWdCLENBQUM7QUFBQSxNQUNqQixZQUFZO0FBQUEsSUFDZCxDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFdBQVcsUUFBUSxLQUFLLENBQUM7QUFDNUQ7QUFFQSxlQUFlLGFBQTRCO0FBQ3pDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxLQUFLLHlCQUF5QixFQUFFLE9BQU8sU0FBUyxPQUFPLENBQUM7QUFDOUQsYUFBVyxLQUFLLFVBQVU7QUFDeEIsVUFBTSxXQUFXLEVBQUUsTUFBTTtBQUFBLEVBQzNCO0FBQ0Y7QUFXQSxlQUFlLGtCQUFpQztBQUM5QywyQkFBeUI7QUFDekIsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxRQUFRLE1BQU0sZUFBZSxLQUFLLENBQUM7QUFBQSxFQUN2RSxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaURBQWlELGNBQWMsR0FBRyxDQUFDO0FBQzlFO0FBQUEsRUFDRjtBQUNBLFFBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsTUFBSSxDQUFDLE9BQU8sT0FBTyxJQUFJLE9BQU8sWUFBWSxDQUFDLElBQUksS0FBSztBQUNsRCxVQUFNLEtBQUssa0NBQWtDO0FBQzdDO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxnQ0FBZ0MsS0FBSyxJQUFJLEdBQUcsR0FBRztBQUNsRCxVQUFNLEtBQUssK0RBQStEO0FBQUEsTUFDeEUsS0FBSyxXQUFXLElBQUksR0FBRztBQUFBLElBQ3pCLENBQUM7QUFDRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssK0JBQStCLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFHdEUsTUFBSTtBQUNGLFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPLENBQUMsY0FBYztBQUFBLE1BQ3RCLE9BQU87QUFBQSxJQUNULENBQUM7QUFDRCxVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTyxDQUFDLFlBQVk7QUFBQSxJQUN0QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssdUNBQXVDLGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDdEU7QUFHQSxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU87QUFBQSxNQUNQLE1BQU0sTUFBTTtBQUNWLGNBQU0sSUFBSSxPQUFPO0FBQ2pCLGVBQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDO0FBQ3BELG1CQUFXLE1BQU0sT0FBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUMsR0FBRyxHQUFHO0FBQzNFLG1CQUFXLE1BQU0sT0FBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUMsR0FBRyxJQUFJO0FBQUEsTUFDOUU7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSywwQ0FBMEMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUN6RTtBQUNGO0FBYUEsSUFBTSxrQkFBa0I7QUFFeEIsZUFBZSxrQkFBMEM7QUFDdkQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxlQUFlO0FBQzlELFFBQU0sS0FBSyxPQUFPLGVBQWU7QUFDakMsU0FBTyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQ3ZDO0FBRUEsZUFBZSxnQkFBZ0IsSUFBa0M7QUFDL0QsTUFBSSxPQUFPLE1BQU07QUFDZixVQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU8sZUFBZTtBQUFBLEVBQ3BELE9BQU87QUFDTCxVQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGVBQWUsR0FBRyxHQUFHLENBQUM7QUFBQSxFQUMzRDtBQUNGO0FBRUEsZUFBZSxtQkFBa0M7QUFDL0MsMkJBQXlCO0FBQ3pCLFFBQU0sUUFBUSxNQUFNLGtCQUFrQjtBQUN0QyxNQUFJLFVBQVUsR0FBRztBQUNmLFVBQU0sS0FBSyx5QkFBeUI7QUFDcEM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFVBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsSUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxFQUFFLHFCQUFxQixDQUFDO0FBQUEsRUFDbkU7QUFDQSxRQUFNLGtCQUFrQjtBQUFBLElBQ3RCLGNBQWM7QUFBQSxJQUNkLFdBQVc7QUFBQSxJQUNYLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsdUJBQXFCLE9BQU87QUFDNUIsT0FBSyxZQUFZO0FBQ2pCLFFBQU0sS0FBSyx3QkFBd0IsRUFBRSxRQUFRLE9BQU8sY0FBYyxRQUFRLENBQUM7QUFDM0UsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsSUFBSSx3QkFBK0Q7QUFFbkUsU0FBUyxxQkFBcUIsU0FBdUI7QUFDbkQsTUFBSSwwQkFBMEIsS0FBTSxlQUFjLHFCQUFxQjtBQUN2RSwwQkFBd0IsWUFBWSxNQUFNO0FBQ3hDLFNBQUssWUFBWSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ2hDLFdBQUssS0FBSyx1QkFBdUIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUNyRCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLFNBQVMsc0JBQTRCO0FBQ25DLE1BQUksMEJBQTBCLE1BQU07QUFDbEMsa0JBQWMscUJBQXFCO0FBQ25DLDRCQUF3QjtBQUFBLEVBQzFCO0FBQ0Y7QUFFQSxlQUFlLG9CQUFtQztBQUNoRCxzQkFBb0I7QUFDcEIsUUFBTSxRQUFRLE9BQU8sTUFBTSxjQUFjO0FBQ3pDLFFBQU0sUUFBUSxNQUFNLGdCQUFnQjtBQUNwQyxRQUFNLGdCQUFnQixJQUFJO0FBQzFCLFFBQU0sT0FBTyxNQUFNLGtCQUFrQjtBQUNyQyxRQUFNLGtCQUFrQixJQUFJO0FBQzVCLFFBQU0sS0FBSywwQkFBMEI7QUFBQSxJQUNuQyxTQUFTLFVBQVU7QUFBQSxJQUNuQixXQUFXLE1BQU0sYUFBYTtBQUFBLEVBQ2hDLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGNBQTZCO0FBQzFDLE1BQUksT0FBTyxNQUFNLGtCQUFrQjtBQUNuQyxNQUFJLFNBQVMsTUFBTTtBQUVqQix3QkFBb0I7QUFDcEI7QUFBQSxFQUNGO0FBSUEsTUFBSSxLQUFLLGFBQWEsTUFBTTtBQUMxQixVQUFNLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUyxXQUFXO0FBQ2pFLFFBQUksVUFBVSxnQkFBZ0I7QUFDNUI7QUFBQSxJQUNGO0FBRUEsVUFBTSxLQUFLLGdEQUFnRDtBQUFBLE1BQ3pELFVBQVUsS0FBSyxTQUFTO0FBQUEsTUFDeEIsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUVELFVBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxlQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxVQUFJLElBQUksU0FBUyxLQUFLLFNBQVMsT0FBTyxHQUFHO0FBQ3ZDLGNBQU0sZUFBZSxRQUFRLEtBQUssU0FBUyxPQUFPO0FBQ2xEO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0sa0JBQWtCLElBQUk7QUFBQSxFQUM5QjtBQUVBLFFBQU0sU0FBUyxNQUFNLGtCQUFrQjtBQUN2QyxNQUFJLENBQUMsUUFBUTtBQUNYLHdCQUFvQjtBQUNwQixVQUFNLGdCQUFnQixJQUFJO0FBQzFCLFVBQU0sa0JBQWtCLElBQUk7QUFDNUIsVUFBTSxLQUFLLHlCQUF5QixFQUFFLFdBQVcsS0FBSyxVQUFVLENBQUM7QUFDakUsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU0sTUFBTSxpQkFBaUIsT0FBTyxNQUFNLFdBQVcsT0FBTyxPQUFPO0FBQ25FLE1BQUksUUFBUSxNQUFNLGdCQUFnQjtBQUNsQyxNQUFJLFVBQVUsTUFBTTtBQUNsQixRQUFJO0FBQ0YsWUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDOUIsUUFBUTtBQUNOLGNBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixRQUFJLFVBQVUsTUFBTTtBQUNsQixZQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDNUQsVUFBSSxPQUFPLElBQUksT0FBTyxTQUFVLE9BQU0sZ0JBQWdCLElBQUksRUFBRTtBQUFBLElBQzlELE9BQU87QUFDTCxZQUFNLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUNBLFdBQVEsTUFBTSxrQkFBa0IsS0FBTTtBQUN0QyxTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVMsT0FBTztBQUFBLE1BQ2hCLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUN0QztBQUNBLFVBQU0sa0JBQWtCLElBQUk7QUFDNUIsVUFBTSxLQUFLLGdCQUFnQjtBQUFBLE1BQ3pCLFFBQVEsT0FBTztBQUFBLE1BQ2YsVUFBVSxPQUFPO0FBQUEsTUFDakIsV0FBVyxNQUFNLGtCQUFrQjtBQUFBLE1BQ25DLFdBQVcsS0FBSztBQUFBLE1BQ2hCLGdCQUFnQixLQUFLO0FBQUEsSUFDdkIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDRDQUE0QztBQUFBLE1BQ3JELFFBQVEsT0FBTztBQUFBLE1BQ2YsVUFBVSxPQUFPO0FBQUEsTUFDakIsR0FBRyxjQUFjLEdBQUc7QUFBQSxJQUN0QixDQUFDO0FBQ0QsVUFBTSxlQUFlLE9BQU8sUUFBUSxPQUFPLE9BQU87QUFDbEQsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLGtCQUFrQixJQUFJO0FBQUEsRUFDOUI7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFXQSxJQUFNLHNCQUFzQjtBQUU1QixlQUFlLHFCQUE2QztBQUMxRCxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLG1CQUFtQjtBQUNsRSxRQUFNLEtBQUssT0FBTyxtQkFBbUI7QUFDckMsU0FBTyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQ3ZDO0FBRUEsZUFBZSxtQkFBbUIsSUFBa0M7QUFDbEUsTUFBSSxPQUFPLEtBQU0sT0FBTSxRQUFRLFFBQVEsTUFBTSxPQUFPLG1CQUFtQjtBQUFBLE1BQ2xFLE9BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsbUJBQW1CLEdBQUcsR0FBRyxDQUFDO0FBQ3BFO0FBRUEsZUFBZSxzQkFBcUM7QUFDbEQsMkJBQXlCO0FBQ3pCLFFBQU0sUUFBUSxNQUFNLHFCQUFxQjtBQUN6QyxNQUFJLFVBQVUsR0FBRztBQUNmLFVBQU0sS0FBSyw2QkFBNkI7QUFDeEM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFVBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsSUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxFQUFFLHFCQUFxQixDQUFDO0FBQUEsRUFDbkU7QUFDQSxRQUFNLHFCQUFxQjtBQUFBLElBQ3pCLGNBQWM7QUFBQSxJQUNkLFdBQVc7QUFBQSxJQUNYLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsMEJBQXdCLE9BQU87QUFDL0IsT0FBSyxlQUFlO0FBQ3BCLFFBQU0sS0FBSyw0QkFBNEIsRUFBRSxRQUFRLE9BQU8sY0FBYyxRQUFRLENBQUM7QUFDL0UsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsSUFBSSwyQkFBa0U7QUFFdEUsU0FBUyx3QkFBd0IsU0FBdUI7QUFDdEQsTUFBSSw2QkFBNkIsS0FBTSxlQUFjLHdCQUF3QjtBQUM3RSw2QkFBMkIsWUFBWSxNQUFNO0FBQzNDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLFNBQVMseUJBQStCO0FBQ3RDLE1BQUksNkJBQTZCLE1BQU07QUFDckMsa0JBQWMsd0JBQXdCO0FBQ3RDLCtCQUEyQjtBQUFBLEVBQzdCO0FBQ0Y7QUFFQSxlQUFlLHVCQUFzQztBQUNuRCx5QkFBdUI7QUFDdkIsUUFBTSxRQUFRLE9BQU8sTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3ZDLFFBQU0sbUJBQW1CLElBQUk7QUFDN0IsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxLQUFLLDhCQUE4QjtBQUFBLElBQ3ZDLFNBQVMsVUFBVTtBQUFBLElBQ25CLFdBQVcsTUFBTSxhQUFhO0FBQUEsRUFDaEMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsaUJBQWdDO0FBQzdDLE1BQUksT0FBTyxNQUFNLHFCQUFxQjtBQUN0QyxNQUFJLFNBQVMsTUFBTTtBQUNqQiwyQkFBdUI7QUFDdkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLGFBQWEsTUFBTTtBQUMxQixVQUFNLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUyxXQUFXO0FBQ2pFLFFBQUksVUFBVSxnQkFBZ0I7QUFDNUI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLG9EQUFvRDtBQUFBLE1BQzdELFVBQVUsS0FBSyxTQUFTO0FBQUEsTUFDeEIsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUNELFVBQU0sa0JBQWtCLEtBQUssU0FBUyxPQUFPO0FBQzdDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBRUEsUUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsMkJBQXVCO0FBQ3ZCLFVBQU0sbUJBQW1CLElBQUk7QUFDN0IsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLEtBQUssNkJBQTZCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNyRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBR0EsTUFBSSxNQUFNLFlBQVksT0FBTyxPQUFPLEdBQUc7QUFDckMsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBT0EsUUFBTSxNQUNKLE9BQU8sV0FBVyxhQUNkLDhCQUE4QixPQUFPLE9BQU8sS0FDNUMsaUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUM3RCxNQUFJLFFBQVEsTUFBTSxtQkFBbUI7QUFDckMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLG1CQUFtQixJQUFJLEVBQUU7QUFBQSxJQUNqRSxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxXQUFRLE1BQU0scUJBQXFCLEtBQU07QUFDekMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sS0FBSyxvQkFBb0I7QUFBQSxNQUM3QixVQUFVLE9BQU87QUFBQSxNQUNqQixhQUFhLE9BQU8sV0FBVyxhQUFhLE9BQU8sT0FBTztBQUFBLE1BQzFELFdBQVcsTUFBTSxxQkFBcUI7QUFBQSxNQUN0QyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxVQUFVLE9BQU87QUFBQSxNQUNqQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQUEsRUFDakM7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFTQSxJQUFNLHNCQUFzQjtBQUU1QixlQUFlLHFCQUE2QztBQUMxRCxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLG1CQUFtQjtBQUNsRSxRQUFNLEtBQUssT0FBTyxtQkFBbUI7QUFDckMsU0FBTyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQ3ZDO0FBRUEsZUFBZSxtQkFBbUIsSUFBa0M7QUFDbEUsTUFBSSxPQUFPLEtBQU0sT0FBTSxRQUFRLFFBQVEsTUFBTSxPQUFPLG1CQUFtQjtBQUFBLE1BQ2xFLE9BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsbUJBQW1CLEdBQUcsR0FBRyxDQUFDO0FBQ3BFO0FBRUEsZUFBZSxzQkFBcUM7QUFDbEQsMkJBQXlCO0FBQ3pCLFFBQU0sUUFBUSxNQUFNLHFCQUFxQjtBQUN6QyxNQUFJLFVBQVUsR0FBRztBQUNmLFVBQU0sS0FBSyw2QkFBNkI7QUFDeEM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFVBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsSUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxFQUFFLHFCQUFxQixDQUFDO0FBQUEsRUFDbkU7QUFDQSxRQUFNLHFCQUFxQjtBQUFBLElBQ3pCLGNBQWM7QUFBQSxJQUNkLFdBQVc7QUFBQSxJQUNYLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsMEJBQXdCLE9BQU87QUFDL0IsT0FBSyxlQUFlO0FBQ3BCLFFBQU0sS0FBSyw0QkFBNEIsRUFBRSxRQUFRLE9BQU8sY0FBYyxRQUFRLENBQUM7QUFDL0UsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsSUFBSSwyQkFBa0U7QUFFdEUsU0FBUyx3QkFBd0IsU0FBdUI7QUFDdEQsTUFBSSw2QkFBNkIsS0FBTSxlQUFjLHdCQUF3QjtBQUM3RSw2QkFBMkIsWUFBWSxNQUFNO0FBQzNDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLFNBQVMseUJBQStCO0FBQ3RDLE1BQUksNkJBQTZCLE1BQU07QUFDckMsa0JBQWMsd0JBQXdCO0FBQ3RDLCtCQUEyQjtBQUFBLEVBQzdCO0FBQ0Y7QUFFQSxlQUFlLHVCQUFzQztBQUNuRCx5QkFBdUI7QUFDdkIsUUFBTSxRQUFRLE9BQU8sTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3ZDLFFBQU0sbUJBQW1CLElBQUk7QUFDN0IsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxLQUFLLDhCQUE4QjtBQUFBLElBQ3ZDLFNBQVMsVUFBVTtBQUFBLElBQ25CLFdBQVcsTUFBTSxhQUFhO0FBQUEsRUFDaEMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsaUJBQWdDO0FBQzdDLE1BQUksT0FBTyxNQUFNLHFCQUFxQjtBQUN0QyxNQUFJLFNBQVMsTUFBTTtBQUNqQiwyQkFBdUI7QUFDdkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLGFBQWEsTUFBTTtBQUMxQixVQUFNLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUyxXQUFXO0FBQ2pFLFFBQUksVUFBVSxlQUFnQjtBQUM5QixVQUFNLEtBQUssb0RBQW9EO0FBQUEsTUFDN0QsVUFBVSxLQUFLLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsSUFDYixDQUFDO0FBQ0QsVUFBTSxtQkFBbUIsS0FBSyxTQUFTLE9BQU87QUFDOUMsVUFBTSxrQkFBa0IsS0FBSyxTQUFTLE9BQU87QUFDN0MsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQUEsRUFDakM7QUFFQSxRQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsTUFBSSxDQUFDLFFBQVE7QUFDWCwyQkFBdUI7QUFDdkIsVUFBTSxtQkFBbUIsSUFBSTtBQUM3QixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sS0FBSyw2QkFBNkIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ3JFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLE1BQU0sa0JBQWtCLE9BQU8sT0FBTyxHQUFHO0FBQzNDLFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU0sTUFBTSxpQkFBaUIsT0FBTyxNQUFNLFdBQVcsT0FBTyxPQUFPO0FBQ25FLE1BQUksUUFBUSxNQUFNLG1CQUFtQjtBQUNyQyxNQUFJLFVBQVUsTUFBTTtBQUNsQixRQUFJO0FBQ0YsWUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDOUIsUUFBUTtBQUNOLGNBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixRQUFJLFVBQVUsTUFBTTtBQUNsQixZQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDNUQsVUFBSSxPQUFPLElBQUksT0FBTyxTQUFVLE9BQU0sSUFBSSxNQUFNLHdCQUF3QjtBQUN4RSxjQUFRLElBQUk7QUFDWixZQUFNLG1CQUFtQixLQUFLO0FBQUEsSUFDaEMsT0FBTztBQUNMLFlBQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQztBQUFBLElBQzFDO0FBQ0EsVUFBTSxtQkFBbUIsT0FBTyxPQUFPO0FBQ3ZDLFdBQVEsTUFBTSxxQkFBcUIsS0FBTTtBQUN6QyxTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVMsT0FBTztBQUFBLE1BQ2hCLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUN0QztBQUNBLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBSSxVQUFVLE1BQU07QUFDbEIsV0FBSyxtQkFBbUIsS0FBSztBQUFBLElBQy9CO0FBQ0EsVUFBTSxLQUFLLG9CQUFvQjtBQUFBLE1BQzdCLFFBQVEsT0FBTztBQUFBLE1BQ2YsVUFBVSxPQUFPO0FBQUEsTUFDakIsV0FBVyxNQUFNLHFCQUFxQjtBQUFBLE1BQ3RDLFdBQVcsS0FBSztBQUFBLE1BQ2hCLGdCQUFnQixLQUFLO0FBQUEsSUFDdkIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGdEQUFnRDtBQUFBLE1BQ3pELFFBQVEsT0FBTztBQUFBLE1BQ2YsVUFBVSxPQUFPO0FBQUEsTUFDakIsR0FBRyxjQUFjLEdBQUc7QUFBQSxJQUN0QixDQUFDO0FBQ0QsVUFBTSxtQkFBbUIsT0FBTyxPQUFPO0FBQ3ZDLFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsbUJBQW1CLE9BQThCO0FBQzlELFFBQU0sSUFBSSxRQUFRLENBQUMsWUFBWSxXQUFXLFNBQVMsSUFBSSxDQUFDO0FBQ3hELE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE1BQU07QUFBQSxNQUNoQixPQUFPO0FBQUEsTUFDUCxNQUFNLE1BQU07QUFDVixjQUFNLElBQUksT0FBTztBQUNqQixjQUFNLE9BQU8sTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQztBQUN2RSxhQUFLO0FBQ0wsbUJBQVcsTUFBTSxJQUFJO0FBQ3JCLG1CQUFXLE1BQU0sSUFBSTtBQUFBLE1BQ3ZCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssbUNBQW1DLGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDbEU7QUFDRjtBQUlBLGVBQWUsV0FDYixRQUNBLFVBQ0EsS0FDQSxLQUNBLEtBQ2U7QUFDZixRQUFNLE1BQU8sd0JBQXdCLEVBQUUsUUFBUSxVQUFVLEtBQUssR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQ3JGLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLFVBQTZCO0FBQUEsSUFDakMsZ0JBQWdCO0FBQUEsSUFDaEI7QUFBQSxJQUNBO0FBQUEsSUFDQSxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDcEMsWUFBWTtBQUFBLElBQ1osT0FBTyxjQUFjLEdBQUc7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssV0FBVyxRQUFRLFdBQVc7QUFDekMsUUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxDQUFDO0FBQy9DLFFBQU0sT0FBTyxtQkFBbUIsRUFBRSxJQUFJLElBQUk7QUFDMUMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ25CO0FBQUEsTUFDQSxlQUFlSCxVQUFTLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUMvRCxTQUFTLGVBQWUsTUFBTSxJQUFJLFFBQVE7QUFBQSxJQUM1QyxDQUFDO0FBQUEsRUFDSCxTQUFTLE1BQU07QUFDYixVQUFNLE1BQU8sNEJBQTRCLEVBQUUsR0FBRyxjQUFjLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDckU7QUFDRjtBQUVBLGVBQWUsS0FBSyxHQUE0QjtBQUM5QyxRQUFNLE1BQU0sSUFBSSxZQUFZLEVBQUUsT0FBTyxDQUFDO0FBQ3RDLFFBQU0sU0FBUyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsR0FBRztBQUN4RCxRQUFNLE1BQU0sTUFBTSxLQUFLLElBQUksV0FBVyxNQUFNLENBQUMsRUFDMUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRTtBQUNWLFNBQU8sSUFBSSxNQUFNLEdBQUcsQ0FBQztBQUN2QjtBQUlBLGVBQWUsaUJBQWlCLE9BQStCO0FBQzdELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsTUFBTTtBQUN0RCxVQUFNLGNBQWM7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUixPQUFPO0FBQUEsTUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZTtBQUFBLE1BQ2Ysd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLE1BQUksQ0FBQyxPQUFPO0FBSVYsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBS0EsUUFBSSxLQUFLLFdBQVc7QUFDbEIsWUFBTSxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVM7QUFDbEQsVUFBSSxNQUFNLDhCQUErQjtBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxJQUFJLE1BQU0sT0FBTyxpQkFBaUI7QUFJeEMsUUFBSSxXQUFXO0FBQ2YsUUFBSSxTQUFTLFVBQVUsU0FBUyxXQUFXLEVBQUUsZ0JBQWdCO0FBQzNELGlCQUFXLE1BQU0sT0FBTyxhQUFhLFNBQVMsTUFBTTtBQUFBLElBQ3REO0FBQ0EsVUFBTSxhQUFhLFNBQVMsaUJBQWlCLEtBQUssS0FBSztBQUN2RCxRQUFJLFlBQVksWUFBWTtBQUMxQixZQUFNLE9BQU8sa0JBQWtCO0FBQUEsSUFDakM7QUFDQSxVQUFNLGNBQWM7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUixPQUFPLEVBQUU7QUFBQSxNQUNULFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsTUFDUCxlQUFlLEVBQUU7QUFBQSxNQUNqQix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxLQUFLLHVCQUF1QjtBQUFBLE1BQ2hDLE9BQU8sRUFBRTtBQUFBLE1BQ1QsTUFBTSxFQUFFO0FBQUEsTUFDUixnQkFBZ0IsRUFBRTtBQUFBLE1BQ2xCLG1CQUFtQixTQUFTO0FBQUEsTUFDNUIsMEJBQTBCO0FBQUEsTUFDMUIsY0FBYyxhQUFhLFlBQVk7QUFBQSxJQUN6QyxDQUFDO0FBQ0QsUUFBSSxDQUFDLFVBQVU7QUFDYixZQUFNLEtBQUssOENBQThDO0FBQUEsUUFDdkQsWUFBWSxTQUFTO0FBQUEsUUFDckIsZ0JBQWdCLEVBQUU7QUFBQSxRQUNsQixLQUFLLHdDQUF3QyxFQUFFO0FBQUEsTUFDakQsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sTUFBTSxlQUFlLGNBQWMsSUFBSSxXQUFXO0FBQ3hELFVBQU0sU0FDSixRQUFRLFNBQ0osZUFDQSxRQUFRLGVBQ04saUJBQ0EsUUFBUSxZQUNOLGtCQUNBO0FBQ1YsVUFBTSxVQUNKLGVBQWUsZUFBZSxRQUFRLGVBQWUsSUFBSSxtQkFBbUI7QUFDOUUsVUFBTSxjQUFjO0FBQUEsTUFDbEI7QUFBQSxNQUNBLE9BQU87QUFBQSxNQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPLGNBQWMsR0FBRyxFQUFFO0FBQUEsTUFDMUIsZUFBZTtBQUFBLE1BQ2Ysd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sS0FBSywyQkFBMkI7QUFBQSxNQUNwQyxVQUFVO0FBQUEsTUFDVixrQkFBa0I7QUFBQSxNQUNsQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxvQkFBb0IsT0FBK0I7QUFDaEUsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxLQUFLO0FBQ2pCLFVBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEM7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLE9BQU87QUFJVixVQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFlBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUMzQyxVQUFJLFNBQVMsS0FBSyxpQkFBa0I7QUFBQSxJQUN0QztBQUlBLFVBQU0sZ0JBQWdCLE1BQU0sdUJBQXVCO0FBQ25ELFFBQUksZUFBZTtBQUNqQixZQUFNLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLGFBQWE7QUFDakQsVUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLLE1BQU0sOEJBQStCO0FBQUEsSUFDbkU7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sTUFBTSxPQUFPLGFBQWEsc0JBQXNCO0FBQzdELFFBQUksQ0FBQyxNQUFNO0FBQ1QsVUFBSSxNQUFPLE9BQU0sS0FBSyxpREFBaUQ7QUFDdkUsWUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QyxZQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JEO0FBQUEsSUFDRjtBQUNBLFVBQU0sU0FBUyxrQkFBa0IsSUFBSTtBQUNyQyxRQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFlBQU0sS0FBSyw4Q0FBOEM7QUFDekQsWUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QyxZQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JEO0FBQUEsSUFDRjtBQUNBLFVBQU0sWUFBWSxNQUFNO0FBQ3hCLFVBQU0sdUJBQXVCLFFBQVEsS0FBSztBQUMxQyxVQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JELFFBQUksTUFBTyxPQUFNLEtBQUssMkJBQTJCLEVBQUUsT0FBTyxPQUFPLE9BQU8sQ0FBQztBQUFBLEVBQzNFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUNoRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsdUJBQXVCLFFBQXNCLE9BQStCO0FBQ3pGLFFBQU0sT0FBTyxNQUFNLE9BQU8sYUFBYSxvQkFBb0I7QUFDM0QsTUFBSSxDQUFDLE1BQU07QUFDVCxVQUFNLG1CQUFtQixJQUFJO0FBQzdCLFFBQUksTUFBTyxPQUFNLEtBQUssMERBQTBEO0FBQ2hGO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFdBQVcscUJBQXFCLEtBQUssTUFBTSxJQUFJLENBQVk7QUFDakUsVUFBTSxtQkFBbUIsUUFBUTtBQUNqQyxRQUFJLE9BQU87QUFDVCxZQUFNLEtBQUssOEJBQThCO0FBQUEsUUFDdkMsVUFBVSxPQUFPLEtBQUssU0FBUyxRQUFRLEVBQUU7QUFBQSxRQUN6QyxjQUFjLFNBQVM7QUFBQSxNQUN6QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLCtEQUErRCxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQzlGO0FBQ0Y7QUFJQSxlQUFlLGlCQUFnQztBQUM3QyxRQUFNLFFBQVEsTUFBTSxXQUFXO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsTUFBTSxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFO0FBRUEsZUFBZSxhQUFzQztBQUNuRCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksV0FBVztBQUNmLE1BQUk7QUFDRixVQUFNLE9BQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUMzRixlQUFXLEtBQUs7QUFBQSxFQUNsQixRQUFRO0FBQUEsRUFHUjtBQUNBLFFBQU0sZ0JBQWdCLE1BQU0sa0JBQWtCO0FBQzlDLFFBQU0sbUJBQW1CLE1BQU0scUJBQXFCO0FBQ3BELFFBQU0sbUJBQW1CLE1BQU0scUJBQXFCO0FBQ3BELFFBQU0sY0FBYyxNQUFNLGtCQUFrQjtBQUM1QyxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxRQUFNLHVCQUF1QixNQUFNLHdCQUF3QjtBQUMzRCxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVCxVQUFVLGVBQWUsUUFBUTtBQUFBLElBQ2pDLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWTtBQUFBLE1BQ1YsUUFBUSxtQkFBbUIsUUFBUSxvQkFBb0I7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsYUFBYSxnQkFBZ0IsZUFBZTtBQUFBLE1BQzVDLGVBQWUsZ0JBQWdCLGlCQUFpQjtBQUFBLE1BQ2hELGtCQUFrQixnQkFBZ0Isb0JBQW9CO0FBQUEsTUFDdEQsdUJBQXVCLGdCQUFnQix5QkFBeUI7QUFBQSxNQUNoRSxpQkFBaUIsZ0JBQWdCLG1CQUFtQjtBQUFBLE1BQ3BELGVBQWUsZ0JBQWdCLGlCQUFpQjtBQUFBLElBQ2xEO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixPQUFPO0FBQUEsTUFDUCxTQUFTLDBCQUEwQjtBQUFBLE1BQ25DLFdBQVcsYUFBYSxhQUFhO0FBQUEsTUFDckMsZ0JBQWdCLGFBQWEsZ0JBQWdCO0FBQUEsSUFDL0M7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLE1BQ2YsT0FBTztBQUFBLE1BQ1AsU0FBUyw2QkFBNkI7QUFBQSxNQUN0QyxXQUFXLGdCQUFnQixhQUFhO0FBQUEsTUFDeEMsZ0JBQWdCLGdCQUFnQixnQkFBZ0I7QUFBQSxJQUNsRDtBQUFBLElBQ0EsaUJBQWlCO0FBQUEsTUFDZixPQUFPO0FBQUEsTUFDUCxTQUFTLDZCQUE2QjtBQUFBLE1BQ3RDLFdBQVcsZ0JBQWdCLGFBQWE7QUFBQSxNQUN4QyxnQkFBZ0IsZ0JBQWdCLGdCQUFnQjtBQUFBLElBQ2xEO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUF5QztBQUMvRCxTQUFPO0FBQUEsSUFDTCxPQUFPLEVBQUU7QUFBQSxJQUNULE1BQU0sRUFBRTtBQUFBLElBQ1IsUUFBUSxFQUFFO0FBQUEsSUFDVixTQUFTLEVBQUU7QUFBQSxJQUNYLGFBQWEsRUFBRTtBQUFBLElBQ2YsY0FBYyxFQUFFO0FBQUEsSUFDaEIsdUJBQXVCLEVBQUU7QUFBQSxJQUN6QixnQkFBZ0IsRUFBRTtBQUFBLElBQ2xCLFFBQVEsRUFBRSxJQUFJLFNBQVM7QUFBQSxJQUN2QixXQUFXLEVBQUUsSUFBSSxVQUFVLElBQUksRUFBRSxJQUFJLE1BQU0sRUFBRSxJQUFJO0FBQUEsRUFDbkQ7QUFDRjtBQUVBLFNBQVMscUJBQXFCLEtBQStCO0FBQzNELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVLE9BQU0sSUFBSSxNQUFNLDJCQUEyQjtBQUNoRixRQUFNLFdBQVc7QUFDakIsTUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTLFFBQVEsRUFBRyxPQUFNLElBQUksTUFBTSxtQ0FBbUM7QUFDMUYsUUFBTSxXQUF3QyxDQUFDO0FBQy9DLGFBQVcsU0FBUyxTQUFTLFVBQVU7QUFDckMsUUFBSSxDQUFDLFNBQVMsT0FBTyxVQUFVLFNBQVU7QUFDekMsVUFBTSxNQUFNO0FBQ1osVUFBTSxTQUFTLE9BQU8sSUFBSSxXQUFXLFdBQVcsSUFBSSxTQUFTO0FBQzdELFFBQUksQ0FBQyxVQUFVLFdBQVcsUUFBUztBQUNuQyxhQUFTLE9BQU8sWUFBWSxDQUFDLElBQUk7QUFBQSxNQUMvQjtBQUFBLE1BQ0EsZ0JBQWdCLE9BQU8sSUFBSSxtQkFBbUIsV0FBVyxJQUFJLGlCQUFpQjtBQUFBLE1BQzlFLG1CQUFtQixPQUFPLElBQUksc0JBQXNCLFdBQVcsSUFBSSxvQkFBb0I7QUFBQSxNQUN2RixXQUFXLE9BQU8sSUFBSSxjQUFjLFdBQVcsSUFBSSxZQUFZO0FBQUEsSUFDakU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0wsY0FBYyxPQUFPLFNBQVMsaUJBQWlCLFdBQVcsU0FBUyxlQUFlO0FBQUEsSUFDbEYsYUFBWSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ25DO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyx3QkFBd0IsR0FBbUIsVUFBMkM7QUFDN0YsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUN0QixRQUFNLFFBQVEsU0FBUyxTQUFTLEVBQUUsZUFBZSxZQUFZLENBQUM7QUFDOUQsTUFBSSxDQUFDLE9BQU8sZUFBZ0IsUUFBTztBQUNuQyxRQUFNLFNBQVMsS0FBSyxNQUFNLEVBQUUsU0FBUztBQUNyQyxRQUFNLFNBQVMsS0FBSyxNQUFNLE1BQU0sY0FBYztBQUM5QyxTQUFPLE9BQU8sU0FBUyxNQUFNLEtBQUssT0FBTyxTQUFTLE1BQU0sS0FBSyxVQUFVO0FBQ3pFO0FBRUEsU0FBUyxtQkFDUCxHQUNBLFVBQ0EsUUFDQSxZQUFnQyxPQUNoQyxTQUFrQyxZQUNuQjtBQUNmLFNBQU87QUFBQSxJQUNMLFVBQVUsRUFBRTtBQUFBLElBQ1osZ0JBQWdCLEVBQUU7QUFBQSxJQUNsQixXQUFXLEVBQUU7QUFBQSxJQUNiLE1BQU0sRUFBRSxpQkFBaUIsRUFBRTtBQUFBLElBQzNCLFlBQVksRUFBRTtBQUFBLElBQ2QsV0FBVyxFQUFFO0FBQUEsSUFDYixTQUFTO0FBQUEsSUFDVDtBQUFBLElBQ0EsZ0JBQWdCLGNBQWMsYUFBYSxVQUFVO0FBQUEsSUFDckQ7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGlCQUFpQixTQUFpQztBQUN6RCxTQUNFLE9BQU8sWUFBWSxZQUNuQiw2RUFBNkUsS0FBSyxPQUFPO0FBRTdGO0FBRUEsU0FBUyxXQUFXLEtBQXFCO0FBRXZDLFFBQU0sSUFBSSxJQUFJLEtBQUssR0FBRztBQUN0QixNQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU8sSUFBSSxRQUFRLFNBQVMsRUFBRTtBQUM3RCxRQUFNLE1BQU0sQ0FBQyxHQUFXLElBQUksTUFBTSxPQUFPLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUMzRCxTQUNFLEdBQUcsRUFBRSxlQUFlLENBQUMsSUFBSSxJQUFJLEVBQUUsWUFBWSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUNwRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7QUFFOUU7QUFFQSxTQUFTLFVBQVUsR0FBcUI7QUFDdEMsU0FBTyxXQUFXLEVBQUUsS0FBSyxjQUFjLEVBQUUsSUFBSTtBQUMvQztBQVNBLFNBQVMsZUFBZSxNQUF5QjtBQUMvQyxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1JLE9BQU07QUFDWixVQUFJLE9BQU9BLEtBQUksZUFBZSxTQUFVLE1BQUssSUFBSUEsS0FBSSxVQUFVO0FBQy9ELGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsS0FBSztBQUN4QjtBQU9BLFNBQVMsb0JBQW9CLE1BQWUsVUFBbUM7QUFDN0UsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNQSxPQUFNO0FBQ1osVUFBSUEsS0FBSSxlQUFlLFVBQVU7QUFDL0IsZUFBTyxPQUFPLEtBQUtBLElBQUcsRUFBRSxLQUFLO0FBQUEsTUFDL0I7QUFDQSxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBUUEsU0FBUyxpQkFBaUIsTUFBZSxVQUFrQixNQUF5QjtBQUNsRixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsTUFBSSxRQUF3QztBQUM1QyxTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUEsT0FBTTtBQUNaLFVBQUlBLEtBQUksZUFBZSxVQUFVO0FBQy9CLGdCQUFRQTtBQUNSO0FBQUEsTUFDRjtBQUNBLGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLE1BQUksTUFBZTtBQUNuQixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVSxRQUFPLElBQUksUUFBUSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzFGLFVBQU8sSUFBZ0MsR0FBRztBQUFBLEVBQzVDO0FBQ0EsTUFBSSxRQUFRLE9BQVcsUUFBTztBQUM5QixNQUFJLFFBQVEsS0FBTSxRQUFPO0FBQ3pCLE1BQUksT0FBTyxRQUFRLFNBQVUsUUFBTyxJQUFJLE9BQU8sR0FBRztBQUNsRCxNQUFJLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxjQUFjLElBQUksTUFBTTtBQUN2RCxTQUFPLE9BQU8sS0FBSyxHQUE4QixFQUFFLEtBQUs7QUFDMUQ7QUFFQSxTQUFTLFdBQVcsR0FBbUI7QUFHckMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLElBQUksQ0FBQztBQUN4QixVQUFNLE9BQU8sT0FBTyxZQUFZLE9BQU8sU0FBUyxZQUFPO0FBQ3ZELFdBQU8sT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTLGdCQUM5QyxPQUNBLEdBQUcsT0FBTyxJQUFJLEdBQUcsSUFBSTtBQUFBLEVBQzNCLFFBQVE7QUFDTixXQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFBQSxFQUNoRDtBQUNGO0FBS0MsV0FBdUMsZUFBZTtBQUFBLEVBQ3JEO0FBQUEsRUFDQSxVQUFVO0FBQUEsRUFDVixVQUFVO0FBQUEsRUFDVixTQUFTO0FBQUEsRUFDVCxVQUFVLE1BQU0sU0FBUyxVQUFVO0FBQUEsRUFDbkMsT0FBTztBQUFBLEVBQ1AsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsZUFBZTtBQUFBLEVBQ2YsaUJBQWlCO0FBQUEsRUFDakIsaUJBQWlCO0FBQUEsRUFDakIsa0JBQWtCO0FBQUEsRUFDbEIsaUJBQWlCO0FBQUEsRUFDakIsaUJBQWlCO0FBQUEsRUFDakIsa0JBQWtCO0FBQ3BCOyIsCiAgIm5hbWVzIjogWyJ0b0Jhc2U2NCIsICJvYmoiLCAiaW5mbyIsICJ0b0Jhc2U2NCIsICJ1bmF2YWlsYWJsZUNvdW50IiwgImVkZ2VDb3VudCIsICJzdWZmaXgiLCAib2JqIl0KfQo=
