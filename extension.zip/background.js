// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, partial_ids };
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  return { tweet_id: restId, hint_handle: pickHintHandle(node) };
}
function pickHintHandle(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name);
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted) {
  if (targeted.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.retweeted_tweet_id && targetedTweetIds.has(t.retweeted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let expandedCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        // Cast: the @types/firefox-webext-browser type signature insists
        // `func` returns void, but the API actually surfaces the return
        // value via `result[0].result`. We use that for the expand count.
        func: () => {
          const SHOW_MORE_SELECTORS = [
            '[data-testid="tweet-text-show-more-link"]',
            'button[data-testid="tweet-text-show-more-link"]',
            'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
          ];
          const clicked = /* @__PURE__ */ new Set();
          let expanded = 0;
          for (const sel of SHOW_MORE_SELECTORS) {
            for (const el of Array.from(document.querySelectorAll(sel))) {
              if (clicked.has(el)) continue;
              const t = (el.textContent || "").trim().toLowerCase();
              if (t !== "show more" && t !== "show this thread") continue;
              const rect = el.getBoundingClientRect();
              if (rect.width === 0 || rect.height === 0) continue;
              clicked.add(el);
              try {
                el.click();
                expanded += 1;
              } catch {
              }
            }
          }
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { expanded };
        }
      });
      scrollCount += 1;
      const r = results[0]?.result;
      if (r && typeof r.expanded === "number") expandedCount += r.expanded;
    } catch {
    }
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      sess.expandedCount += expandedCount;
      await setAutoScrollSession(sess);
    }
  }
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set()
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.tweets.length === 0) return;
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const committedIdx = await getCommittedIndex();
  let dedupedSkipped = 0;
  const liveTweets = [];
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      continue;
    }
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (liveTweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, Object.keys(buf.tweets_by_id).length);
    if (added > 0) {
      await info("captured tweets", {
        handle,
        endpoint,
        added,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      await flushHandle(handle, "idle");
    }
  }
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      await flushHandle(handle, "wake");
    }
  }
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  for (const handle of Object.keys(all)) {
    await flushHandle(handle, reason);
  }
}
async function flushHandle(handle, reason) {
  const buf = await getRunBuffer(handle);
  if (!buf) return;
  const tweets = Object.values(buf.tweets_by_id);
  if (tweets.length === 0) {
    await clearRunBuffer(handle);
    return;
  }
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", { handle });
    return;
  }
  const client = new GitHubClient(settings);
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const rawPath = `raw/${handle}/${ts}-${shortRunId(buf.run_id)}.json`;
  const seenPath = `seen/${handle}/${ts}-${shortRunId(buf.run_id)}.json`;
  const capture = {
    schema_version: 1,
    capture_run_id: buf.run_id,
    account_handle: handle,
    captured_at: buf.last_capture_at,
    endpoint: buf.endpoints_seen.join(","),
    user_agent: navigator.userAgent,
    source_url: buf.source_url,
    tweets
  };
  const seen = {
    schema_version: 1,
    capture_run_id: buf.run_id,
    account_handle: handle,
    captured_at: buf.last_capture_at,
    tweet_ids_observed: buf.tweet_ids_observed
  };
  const commitMsg = `capture: ${handle} ${day} ${tweets.length} tweet${tweets.length === 1 ? "" : "s"} (run ${shortRunId(buf.run_id)})`;
  try {
    await client.putFile({
      path: rawPath,
      contentBase64: toBase642(JSON.stringify(capture, null, 2) + "\n"),
      message: commitMsg
    });
    await client.putFile({
      path: seenPath,
      contentBase64: toBase642(JSON.stringify(seen, null, 2) + "\n"),
      message: `seen: ${handle} ${day} ${seen.tweet_ids_observed.length} ids (run ${shortRunId(buf.run_id)})`
    });
    await clearRunBuffer(handle);
    {
      const prev = (await getCounters())[handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(handle, {
        todayCount: carriedToday + tweets.length,
        todayDate: today,
        lastCaptureAt: buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + tweets.length,
        bufferedCount: 0
      });
    }
    {
      const idx = await getCommittedIndex();
      const inner = idx[handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      idx[handle] = inner;
      await setCommittedIndex(idx);
    }
    await info("flush committed", {
      handle,
      reason,
      tweets: tweets.length,
      run: shortRunId(buf.run_id),
      path: rawPath
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("flush failed", {
        handle,
        reason,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("flush failed", { handle, reason, ...describeError(err) });
    }
  } finally {
    await broadcastState();
  }
}
async function captureNow(handle) {
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = target.bucket === "_unknown" ? `https://x.com/i/status/${target.tweetId}` : `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const autoScrollSess = await getAutoScrollSession();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    }
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHBhdDogJycsXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXG4gIHJlcG86ICd4JyxcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxuICBicmFuY2g6ICdtYXN0ZXInLFxuICBlbmFibGVkOiB0cnVlLFxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcbiAgY29uZmlndXJlZEF0OiBudWxsLFxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXG59O1xuXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xuXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cbiAqXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXG4gKiBHaXRIdWIgUEFUIGluIHBsYWludGV4dC4gQSBkZXRlcm1pbmVkIGF0dGFja2VyIHdpdGggdGhlIGV4dGVuc2lvbidzIHNvdXJjZVxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxuICogc3RyaW5nIHNpdHRpbmcgbmV4dCB0byBpdHMga2V5IG5hbWUgaW4gZXh0ZW5zaW9uIHN0b3JhZ2UuXG4gKlxuICogU2NoZW1lOlxuICogICAtIE9uIGZpcnN0IGVuY3J5cHRpb24gd2UgZ2VuZXJhdGUgYSAzMi1ieXRlIHNhbHQgYW5kIHBlcnNpc3QgaXQgaW5cbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cbiAqICAgICB8fCBcImltbS1hcmNoaXZlLXBhdC12MVwiYC4gVGhlIHNhbHQgYmVpbmcgcGVyLWluc3RhbGwgbWVhbnMgdHdvIGNvcGllc1xuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxuICogICAtIFBsYWludGV4dCBpcyBlbmNyeXB0ZWQgd2l0aCBhIGZyZXNoIDEyLWJ5dGUgSVYuIFRoZSBlbnZlbG9wZSBmb3JtYXQgaXNcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXG4gKlxuICogQmFja3dhcmRzIGNvbXBhdGliaWxpdHk6IGFuIHVucHJlZml4ZWQgdmFsdWUgaXMgdHJlYXRlZCBhcyBsZWdhY3lcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cbiAqL1xuXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xuXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcbiAgbGV0IHMgPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIGJ1ZikgcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShzKTtcbn1cblxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcbiAgY29uc3QgYmluID0gYXRvYihzKTtcbiAgY29uc3Qgb3V0ID0gbmV3IFVpbnQ4QXJyYXkoYmluLmxlbmd0aCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChTQUxUX1NUT1JBR0VfS0VZKTtcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4geyBzYWx0QjY0OiB2LCBzYWx0OiBmcm9tQmFzZTY0KHYpIH07XG4gIH1cbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcbiAgY29uc3Qgc2FsdEI2NCA9IHRvQmFzZTY0KHNhbHQpO1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICBjb25zdCB7IHNhbHRCNjQsIHNhbHQgfSA9IGF3YWl0IGxvYWRPckNyZWF0ZVNhbHQoKTtcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcbiAgfVxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXG4gICk7XG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcbiAgY29tYmluZWQuc2V0KHNhbHQsIHNlZWQubGVuZ3RoKTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcbiAgICAnZW5jcnlwdCcsXG4gICAgJ2RlY3J5cHQnLFxuICBdKTtcbiAgZGVyaXZlZEtleUNhY2hlID0ga2V5O1xuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcbiAgcmV0dXJuIGtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdi5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbmNyeXB0UGF0KHBsYWludGV4dDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gIGNvbnN0IGl2ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMikpO1xuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcbiAgICBrZXksXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcbiAgKTtcbiAgcmV0dXJuIGAke0VOVkVMT1BFX1BSRUZJWH0ke3RvQmFzZTY0KGl2KX06JHt0b0Jhc2U2NChuZXcgVWludDhBcnJheShjdCkpfWA7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWNyeXB0UGF0KGVudmVsb3BlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXG4gIC8vIHJlLWVuY3J5cHRzIGl0IHZpYSB0aGUgc3RvcmFnZSBsYXllci5cbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xuICBpZiAocGFydHMubGVuZ3RoICE9PSAyKSByZXR1cm4gJyc7XG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XG4gIHRyeSB7XG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcbiAgICBjb25zdCBjdCA9IGZyb21CYXNlNjQoY3RCNjQpO1xuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcbiAgICAgIGtleSxcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShwdCk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnJztcbiAgfVxufVxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB7IGRlY3J5cHRQYXQsIGVuY3J5cHRQYXQsIGlzRW5jcnlwdGVkUGF0IH0gZnJvbSAnLi9jcnlwdG8uanMnO1xuaW1wb3J0IHR5cGUge1xuICBBY2NvdW50Q29uZmlnLFxuICBBY2NvdW50Q291bnRlcixcbiAgQ2Fub25pY2FsVHdlZXQsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFNldHRpbmdzLFxufSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBCdWZmZXJlZCB0d2VldHMgZm9yIGEgZ2l2ZW4gYWNjb3VudCwgYXdhaXRpbmcgY29tbWl0LiBBIFwicnVuXCIgaXMgb25lIGVudHJ5XG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xuICBydW5faWQ6IHN0cmluZztcbiAgYWNjb3VudF9oYW5kbGU6IHN0cmluZztcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcbiAgdHdlZXRzX2J5X2lkOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD47XG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XG4gIGVuZHBvaW50c19zZWVuOiBzdHJpbmdbXTtcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcbn1cblxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxuICogVXNlZCB0byBza2lwIHJlLWNhcHR1cmluZyB0d2VldHMgd2UndmUgYWxyZWFkeSBwdXNoZWQgd2l0aCBpZGVudGljYWxcbiAqIGVuZ2FnZW1lbnQgY291bnRzIFx1MjAxNCBhdm9pZHMgZ2VuZXJhdGluZyBvbmUgbmV3IHJhdy8qIGZpbGUgZXZlcnkgYnJvd3NlLiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XG4gIHRzOiBzdHJpbmc7IC8vIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3QgY29tbWl0XG4gIHNpZzogc3RyaW5nOyAvLyBlbmdhZ2VtZW50IHNpZ25hdHVyZTogXCJsaWtlfHJ0fHJlcGx5fHF1b3RlXCJcbn1cblxuLyoqIFByb2dyZXNzICsgaW5mbGlnaHQgdHJhY2tpbmcgZm9yIGEgcXVldWUtZHJpdmVuIGxvb3AgKHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCkuXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcbiAqIFwiWCBvZiBZIHByb2Nlc3NlZFwiIFx1MjAxNCBhbmQgdGhlIHdhaXQtZm9yLWluZ2VzdCBndWFyZCBrbm93cyB3aGF0IHRvIGV4cGVjdC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XG4gIC8qKiBJbml0aWFsIHF1ZXVlIHNpemUgd2hlbiB0aGUgdXNlciBjbGlja2VkIFwiU3RhcnRcIi4gKi9cbiAgdG90YWxBdFN0YXJ0OiBudW1iZXI7XG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cbiAgcHJvY2Vzc2VkOiBudW1iZXI7XG4gIC8qKiBJU08gb2Ygd2hlbiB0aGlzIHNlc3Npb24gc3RhcnRlZC4gKi9cbiAgc3RhcnRlZEF0OiBzdHJpbmc7XG4gIC8qKiBUd2VldCBjdXJyZW50bHkgaW5mbGlnaHQgXHUyMDE0IHdlIG5hdmlnYXRlZCB0byBpdCBhbmQgYXJlIHdhaXRpbmcgZm9yIHRoZVxuICAgKiBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgcmVzcG9uc2UgYmVmb3JlIGFkdmFuY2luZy4gbnVsbCBiZXR3ZWVuIHRpY2tzXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xuICBpbmZsaWdodDogeyB0d2VldElkOiBzdHJpbmc7IG5hdmlnYXRlZEF0OiBzdHJpbmcgfSB8IG51bGw7XG59XG5cbi8qKiBBdXRvLXNjcm9sbCBzZXNzaW9uOiBjb3VudHMgb2YgdGlja3MgYW5kIHR3ZWV0cyBpbmdlc3RlZCBzaW5jZSB0aGUgdXNlclxuICogY2xpY2tlZCBTdGFydC4gUGVyc2lzdGVkIHNvIFNXIGV2aWN0aW9uIGR1cmluZyBhIHJ1biBrZWVwcyBwcm9ncmVzcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xuICBzdGFydGVkQXQ6IHN0cmluZztcbiAgc2Nyb2xsQ291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xuICBleHBhbmRlZENvdW50OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xuICBzZXR0aW5nczogU2V0dGluZ3M7XG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XG4gIC8qKiBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IHN1Y2Nlc3NmdWwgYWNjb3VudHMueWFtbCBmZXRjaCBmcm9tIHRoZSByZXBvLlxuICAgKiBVc2VkIGJ5IGByZWZyZXNoQWNjb3VudHNMaXN0YCB0byBza2lwIHJlLWZldGNoaW5nIG9uIGV2ZXJ5IFNXIHdha2UgXHUyMDE0IHRoZVxuICAgKiBmaWxlIGNoYW5nZXMgcmFyZWx5IGFuZCBhbiBhdXRoZW50aWNhdGVkIHJhdyBmZXRjaCBldmVyeSB3YWtlIGFkZHMgdXAuICovXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IHN0cmluZyB8IG51bGw7XG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcbiAgcnVuQnVmZmVyczogUmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPjtcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XG4gIGNvbW1pdHRlZEluZGV4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+O1xuICAvKiogVHdlZXRzIHRoZSBub3JtYWxpemVyIGZsYWdnZWQgYXMgdHJ1bmNhdGVkIGFuZCB0aGF0IHdlIGhhdmVuJ3Qgc2VlbiBhXG4gICAqIGZ1bGwtdGV4dCB2ZXJzaW9uIG9mIHlldC4gS2V5ZWQgYnkgaGFuZGxlIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuICovXG4gIHJlZmV0Y2hRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogVHdlZXQgSURzIHNlZW4gdmlhIE1lZGlhLXRhYiAvIHBhcnRpYWwgY2FwdHVyZXMgdGhhdCBjb3VsZG4ndCBiZVxuICAgKiBub3JtYWxpemVkIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gS2V5ZWQgYnkgaGludC1oYW5kbGUgKG9yXG4gICAqIFwiX3Vua25vd25cIikgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gVGhlIHVzZXIgY2FuIGRyaXZlIGEgY3Jhd2wgdGhhdFxuICAgKiBvcGVucyBlYWNoIGRldGFpbCBwYWdlIHRvIGNhcHR1cmUgdGhlIHJlYWwgdGhpbmcuICovXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBtZWRpYUNyYXdsU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBhdXRvU2Nyb2xsU2Vzc2lvbjogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsO1xufVxuXG5jb25zdCBERUZBVUxUX0NPTk5FQ1RJT046IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgc3RhdHVzOiAndW5rbm93bicsXG4gIGxvZ2luOiBudWxsLFxuICBjaGVja2VkQXQ6IG51bGwsXG4gIGVycm9yOiBudWxsLFxuICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxufTtcblxuY29uc3QgREVGQVVMVFM6IFN0b3JhZ2VTaGFwZSA9IHtcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9LFxuICBhY2NvdW50czogWy4uLkZBTExCQUNLX0FDQ09VTlRTXSxcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogbnVsbCxcbiAgY29ubmVjdGlvbjogeyAuLi5ERUZBVUxUX0NPTk5FQ1RJT04gfSxcbiAgY291bnRlcnM6IHt9LFxuICBydW5CdWZmZXJzOiB7fSxcbiAgYWN0aXZpdHk6IFtdLFxuICBjb21taXR0ZWRJbmRleDoge30sXG4gIHJlZmV0Y2hRdWV1ZToge30sXG4gIG1lZGlhQ3Jhd2xRdWV1ZToge30sXG4gIHJlZmV0Y2hTZXNzaW9uOiBudWxsLFxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcbiAgYXV0b1Njcm9sbFNlc3Npb246IG51bGwsXG59O1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChrZXkpO1xuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUoREVGQVVMVFNba2V5XSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW2tleV06IHZhbHVlIH0pO1xufVxuXG4vLyAtLS0gU2V0dGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICAvLyBCYWNrZmlsbCBhbnkga2V5cyB0aGUgdXNlcidzIHN0b3JlZCBzZXR0aW5ncyBwcmVkYXRlIFx1MjAxNCByZWFkZXJzIGNhbiByZWx5XG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XG4gIC8vIGV2ZXJ5IGNhbGxzaXRlLiBUaGUgUEFUIGlzIHN0b3JlZCBlbmNyeXB0ZWQtYXQtcmVzdCBhcyBvZiB2MC4yLjA7IHdlXG4gIC8vIGRlY3J5cHQgdHJhbnNwYXJlbnRseSBzbyBjYWxsZXJzIGNvbnRpbnVlIHRvIHNlZSBwbGFpbnRleHQuXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcbiAgY29uc3QgbWVyZ2VkID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi5zdG9yZWQgfTtcbiAgaWYgKG1lcmdlZC5wYXQgJiYgaXNFbmNyeXB0ZWRQYXQobWVyZ2VkLnBhdCkpIHtcbiAgICB0cnkge1xuICAgICAgbWVyZ2VkLnBhdCA9IGF3YWl0IGRlY3J5cHRQYXQobWVyZ2VkLnBhdCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBtZXJnZWQucGF0ID0gJyc7XG4gICAgfVxuICB9XG4gIHJldHVybiBtZXJnZWQ7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXG4gIC8vIG9uIHRoZSBuZXh0IHNhdmUuXG4gIGNvbnN0IHRvV3JpdGU6IFNldHRpbmdzID0geyAuLi5zIH07XG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XG4gICAgdG9Xcml0ZS5wYXQgPSBhd2FpdCBlbmNyeXB0UGF0KHRvV3JpdGUucGF0KTtcbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2V0dGluZ3MocGF0Y2g6IFBhcnRpYWw8U2V0dGluZ3M+KTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBuZXh0ID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGF3YWl0IHNldFNldHRpbmdzKG5leHQpO1xuICByZXR1cm4gbmV4dDtcbn1cblxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzKCk6IFByb21pc2U8QWNjb3VudENvbmZpZ1tdPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHMoYTogQWNjb3VudENvbmZpZ1tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50c1JlZnJlc2hlZEF0KCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHNSZWZyZXNoZWRBdChpc286IHN0cmluZyB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcbn1cblxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29ubmVjdGlvbigpOiBQcm9taXNlPENvbm5lY3Rpb25TdGF0ZT4ge1xuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XG4gIC8vIEJhY2tmaWxsIGZpZWxkcyBhZGRlZCBhZnRlciB0aGUgdXNlcidzIHN0b3JhZ2Ugd2FzIHdyaXR0ZW4uXG4gIGNvbnN0IG91dDogQ29ubmVjdGlvblN0YXRlID0ge1xuICAgIC4uLmMsXG4gICAgZGVmYXVsdEJyYW5jaDogYy5kZWZhdWx0QnJhbmNoID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5kZWZhdWx0QnJhbmNoLFxuICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6XG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgcmF0ZUxpbWl0UmVzZXRBdDogYy5yYXRlTGltaXRSZXNldEF0ID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5yYXRlTGltaXRSZXNldEF0LFxuICB9O1xuICByZXR1cm4gb3V0O1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xufVxuXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ2NvdW50ZXJzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xuICAgIHRvZGF5Q291bnQ6IDAsXG4gICAgdG9kYXlEYXRlOiB0b2RheUlTTygpLFxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXG4gICAgYnVmZmVyZWRDb3VudDogMCxcbiAgfTtcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcbiAgICBjdXIudG9kYXlEYXRlID0gdG9kYXlJU08oKTtcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XG4gIH1cbiAgY29uc3QgbmV4dDogQWNjb3VudENvdW50ZXIgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRCdWZmZXJlZENvdW50KGhhbmRsZTogc3RyaW5nLCBjb3VudDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcbn1cblxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj4+IHtcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgcmV0dXJuIGFsbFtoYW5kbGVdID8/IG51bGw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcsIGJ1ZjogUnVuQnVmZmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYWxsW2hhbmRsZV0gPSBidWY7XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcbn1cblxuLy8gLS0tIEFjdGl2aXR5IHRhaWwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY3Rpdml0eScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwZW5kQWN0aXZpdHkoZXY6IExvZ0V2ZW50KTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XG4gIGN1ci51bnNoaWZ0KGV2KTtcbiAgaWYgKGN1ci5sZW5ndGggPiBBQ1RJVklUWV9UQUlMX01BWCkgY3VyLmxlbmd0aCA9IEFDVElWSVRZX1RBSUxfTUFYO1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcbiAgcmV0dXJuIGN1cjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBbXSk7XG59XG5cbi8vIC0tLSBDb21taXR0ZWQtdHdlZXRzIGRlZHVwIGluZGV4IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb21taXR0ZWRJbmRleCcpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29tbWl0dGVkSW5kZXgoXG4gIGlkeDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PlxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29tbWl0dGVkSW5kZXgnLCBpZHgpO1xufVxuXG4vKiogQ29tcHV0ZSB0aGUgZW5nYWdlbWVudCBzaWduYXR1cmUgd2UgdXNlIHRvIGRlY2lkZSB3aGV0aGVyIGEgcmUtY2FwdHVyZWRcbiAqIHR3ZWV0IGlzIFwibWF0ZXJpYWxseSBkaWZmZXJlbnRcIiBmcm9tIHdoYXQgd2UgbGFzdCBjb21taXR0ZWQuIFdlIG9taXRcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXG4gKiBkZWZlYXQgdGhlIGRlZHVwLiBMaWtlcyAvIFJUcyAvIHJlcGxpZXMgLyBxdW90ZXMgY2hhbmdlIHJhcmVseSBlbm91Z2ggdGhhdFxuICogZWFjaCBjaGFuZ2UgaXMgd29ydGggYSByZS1jb21taXQgKGFuZCBhbiBlbmdhZ2VtZW50X2hpc3Rvcnkgc25hcHNob3QpLlxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxuICogdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkgYnlwYXNzZXMgdGhlIGRlZHVwIGV2ZW4gd2hlbiBlbmdhZ2VtZW50IGNvdW50c1xuICogaGF2ZW4ndCBtb3ZlZCBcdTIwMTQgb3RoZXJ3aXNlIHRoZSBuZXcgYm9keSB3b3VsZCBiZSBzaWxlbnRseSBkcm9wcGVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXG4gIGxpa2VzOiBudW1iZXIsXG4gIHJldHdlZXRzOiBudW1iZXIsXG4gIHJlcGxpZXM6IG51bWJlcixcbiAgcXVvdGVzOiBudW1iZXIsXG4gIGlzVHJ1bmNhdGVkOiBib29sZWFuID0gZmFsc2Vcbik6IHN0cmluZyB7XG4gIHJldHVybiBgJHtsaWtlc318JHtyZXR3ZWV0c318JHtyZXBsaWVzfXwke3F1b3Rlc318JHtpc1RydW5jYXRlZCA/ICd0JyA6ICdmJ31gO1xufVxuXG4vKiogRHJvcCBlbnRyaWVzIG9sZGVyIHRoYW4gYG1heEFnZU1zYC4gUmV0dXJucyB0aGUgbnVtYmVyIHBydW5lZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcnVuZUNvbW1pdHRlZEluZGV4KG1heEFnZU1zOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBjb25zdCBjdXRvZmYgPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gbWF4QWdlTXMpLnRvSVNPU3RyaW5nKCk7XG4gIGxldCBwcnVuZWQgPSAwO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgY29uc3QgaW5uZXIgPSBpZHhbaGFuZGxlXTtcbiAgICBpZiAoIWlubmVyKSBjb250aW51ZTtcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcbiAgICAgIGNvbnN0IGUgPSBpbm5lclt0aWRdO1xuICAgICAgaWYgKGUgJiYgZS50cyA8IGN1dG9mZikge1xuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcbiAgICAgICAgcHJ1bmVkICs9IDE7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhpbm5lcikubGVuZ3RoID09PSAwKSBkZWxldGUgaWR4W2hhbmRsZV07XG4gIH1cbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG4gIHJldHVybiBwcnVuZWQ7XG59XG5cbi8vIC0tLSBSZWZldGNoIHF1ZXVlICh0d2VldHMgbmVlZGluZyBmdWxsLXRleHQgcmVjYXB0dXJlKSAtLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hRdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbaGFuZGxlXSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdO1xuICBpZiAoIWlkcykgcmV0dXJuO1xuICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2hhbmRsZV07XG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0UmVmZXRjaFRhcmdldCgpOiBQcm9taXNlPHtcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIHR3ZWV0SWQ6IHN0cmluZztcbn0gfCBudWxsPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBoYW5kbGUsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVNZWRpYUNyYXdsKGhpbnRIYW5kbGU6IHN0cmluZyB8IG51bGwsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcbiAgY29uc3QgaWRzID0gcVtidWNrZXRdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbYnVja2V0XSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcbiAgICBpZiAoIWlkcykgY29udGludWU7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XG4gICAgfVxuICB9XG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTogUHJvbWlzZTx7XG4gIGJ1Y2tldDogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgYnVja2V0LCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXG4gKiBlbnF1ZXVlaW5nIG1lZGlhLWNyYXdsIHRhcmdldHMgd2UndmUgYWxyZWFkeSBhcmNoaXZlZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpc0NvbW1pdHRlZCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgZm9yIChjb25zdCBpbm5lciBvZiBPYmplY3QudmFsdWVzKGlkeCkpIHtcbiAgICBpZiAoaW5uZXIgJiYgdHdlZXRJZCBpbiBpbm5lcikgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyAtLS0gTG9vcCBzZXNzaW9uIHN0YXRlIChwcm9ncmVzcyArIGluZmxpZ2h0IGdhdGluZykgLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEF1dG9TY3JvbGxTZXNzaW9uKCk6IFByb21pc2U8QXV0b1Njcm9sbFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXV0b1Njcm9sbFNlc3Npb24oczogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nLCBzKTtcbn1cblxuLy8gLS0tIFB1cmdlOiB1bnJlbGF0ZWQgYnVmZmVycywgY291bnRlcnMsIHF1ZXVlIGVudHJpZXMgLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vKipcbiAqIERyb3AgZXZlcnkgcGVyLWhhbmRsZSBiaXQgb2Ygc3RhdGUgKGNvdW50ZXJzLCBydW4gYnVmZmVyLCBjb21taXR0ZWQtaW5kZXhcbiAqIGVudHJpZXMsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyaWVzKSB0aGF0IGRvZXNuJ3QgY29ycmVzcG9uZCB0byBhXG4gKiB0cmFja2VkIGFjY291bnQuIFJldHVybnMgYSBzdW1tYXJ5IGRlc2NyaWJpbmcgd2hhdCB3YXMgY2xlYXJlZCBzbyB0aGVcbiAqIGNhbGxlciBjYW4gbG9nIGl0LlxuICpcbiAqIFRyYWNrZWQgYWNjb3VudHMgYXJlIHBhc3NlZCBpbiAoY2FsbGVyIHJlc29sdmVzIGZyb20gdGhlIGxpdmUgY29uZmlnKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1cmdlVW5yZWxhdGVkU3RhdGUodGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4pOiBQcm9taXNlPHtcbiAgY291bnRlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGJ1ZmZlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XG4gIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xuICBtZWRpYUNyYXdsSWRzUmVtb3ZlZDogbnVtYmVyO1xufT4ge1xuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcbiAgY29uc3QgaXNUYXJnZXRlZCA9IChoOiBzdHJpbmcpOiBib29sZWFuID0+IHRhcmdMb3dlci5oYXMoaC50b0xvd2VyQ2FzZSgpKTtcblxuICAvLyBDb3VudGVyc1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCBjb3VudGVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgY291bnRlcnNbaF07XG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcblxuICAvLyBSdW4gYnVmZmVyc1xuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBsZXQgYnVmZmVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoYnVmZmVycykpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBidWZmZXJzW2hdO1xuICAgICAgYnVmZmVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYnVmZmVycyk7XG5cbiAgLy8gQ29tbWl0dGVkIGRlZHVwIGluZGV4XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgaWR4W2hdO1xuICAgICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcblxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXG4gIGNvbnN0IHJxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGxldCByZWZldGNoSGFuZGxlc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgcnFbaF07XG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XG5cbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IGJ1Y2tldHMgYXJlIGhpbnQtaGFuZGxlcyAob3IgXCJfdW5rbm93blwiKS4gRHJvcFxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCBcdTIwMTQgaW5jbHVkaW5nIFwiX3Vua25vd25cIiBzaW5jZSB3ZVxuICAvLyBjYW4ndCB2ZXJpZnkgcmVsYXRpb24uXG4gIGNvbnN0IG1xID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhtcSkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xuICAgICAgZGVsZXRlIG1xW2hdO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIG1xKTtcblxuICByZXR1cm4ge1xuICAgIGNvdW50ZXJzUmVtb3ZlZCxcbiAgICBidWZmZXJzUmVtb3ZlZCxcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcbiAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQsXG4gICAgbWVkaWFDcmF3bElkc1JlbW92ZWQsXG4gIH07XG59XG5cbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbn1cbiIsICJpbXBvcnQgeyBhcHBlbmRBY3Rpdml0eSB9IGZyb20gJy4vc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5sZXQgYnJvYWRjYXN0OiAoKGV2OiBMb2dFdmVudCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldEJyb2FkY2FzdGVyKGZuOiAoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKTogdm9pZCB7XG4gIGJyb2FkY2FzdCA9IGZuO1xufVxuXG5mdW5jdGlvbiBub3dJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBldjogTG9nRXZlbnQgPSB7IHRzOiBub3dJU08oKSwgbGV2ZWwsIG1zZywgY29udGV4dDogcmVkYWN0KGNvbnRleHQpIH07XG4gIC8vIENvbnNvbGUgZm9yIGRldnRvb2xzLlxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xuICBpZiAobGV2ZWwgPT09ICdlcnJvcicpIGNvbnNvbGUuZXJyb3IobGluZSwgZXYuY29udGV4dCk7XG4gIGVsc2UgaWYgKGxldmVsID09PSAnd2FybicpIGNvbnNvbGUud2FybihsaW5lLCBldi5jb250ZXh0KTtcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcbiAgLy8gUGVyc2lzdGVudCB0YWlsLlxuICB0cnkge1xuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGZhaWxlZCB0byBhcHBlbmQgYWN0aXZpdHknLCBlcnIpO1xuICB9XG4gIC8vIExpdmUgYnJvYWRjYXN0IChlLmcuIHRvIHNpZGViYXIpLlxuICB0cnkge1xuICAgIGJyb2FkY2FzdD8uKGV2KTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gU2lkZWJhciBtYXkgbm90IGJlIG9wZW47IHRoYXQncyBmaW5lLlxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCdpbmZvJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCd3YXJuJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gZW1pdCgnZXJyb3InLCBtc2csIGNvbnRleHQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmVFcnJvcihlcnI6IHVua25vd24pOiB7IG1lc3NhZ2U6IHN0cmluZzsgc3RhY2s6IHN0cmluZyB8IG51bGwgfSB7XG4gIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcbiAgfVxuICB0cnkge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4geyBtZXNzYWdlOiAnPHVucHJpbnRhYmxlIGVycm9yPicsIHN0YWNrOiBudWxsIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTdHJpcCBhbnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSBQQVQgb3Igb3RoZXIgbG9uZyBzZWNyZXQgZnJvbSBhIGNvbnRleHRcbiAqIG9iamVjdCBiZWZvcmUgcGVyc2lzdGluZyBpdC4gRGVmZW5zaXZlOiBjYWxsZXJzIHNob3VsZCBub3QgbG9nIHRva2VucywgYnV0XG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxuICovXG5mdW5jdGlvbiByZWRhY3QoY3R4OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhjdHgpKSB7XG4gICAgaWYgKGsudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygndG9rZW4nKSB8fCBrLnRvTG93ZXJDYXNlKCkgPT09ICdwYXQnIHx8IGsgPT09ICdhdXRob3JpemF0aW9uJykge1xuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIC9naXRodWJfcGF0X1tBLVphLXowLTlfXXszMCx9Ly50ZXN0KHYpKSB7XG4gICAgICBvdXRba10gPSB2LnJlcGxhY2UoL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dKy9nLCAnZ2l0aHViX3BhdF88cmVkYWN0ZWQ+Jyk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XG4gICAgICBvdXRba10gPSBgJHt2LnNsaWNlKDAsIDQwOTYpfVx1MjAyNjx0cnVuY2F0ZWQ+YDtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0W2tdID0gdjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cbiIsICJpbXBvcnQgeyBkZXNjcmliZUVycm9yIH0gZnJvbSAnLi9sb2dnZXIuanMnO1xuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5jb25zdCBBUElfQkFTRSA9ICdodHRwczovL2FwaS5naXRodWIuY29tJztcbmNvbnN0IFJBV19CQVNFID0gJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZU9wdGlvbnMge1xuICBwYXRoOiBzdHJpbmc7XG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBleHBlY3RlZFNoYT86IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZVJlc3VsdCB7XG4gIHBhdGg6IHN0cmluZztcbiAgc2hhOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xufVxuXG5leHBvcnQgY2xhc3MgR2l0SHViRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIHN0YXR1czogbnVtYmVyO1xuICBib2R5OiB1bmtub3duO1xuICByZXRyaWFibGU6IGJvb2xlYW47XG4gIGNhdGVnb3J5OiAnYXV0aCcgfCAncmF0ZS1saW1pdCcgfCAnY29uZmxpY3QnIHwgJ25vdC1mb3VuZCcgfCAnc2VydmVyJyB8ICduZXR3b3JrJyB8ICd1bmtub3duJztcbiAgLyoqIFdoZW4gdGhlIEdpdEh1YiByYXRlLWxpbWl0IHdpbmRvdyBmb3IgdGhpcyB0b2tlbiByZXNldHMsIGFzIGEgVW5peFxuICAgKiBlcG9jaCBpbiBzZWNvbmRzLiBQb3B1bGF0ZWQgZnJvbSBgWC1SYXRlTGltaXQtUmVzZXRgIG9uIDQwMy80MjksIG9yXG4gICAqIGRlcml2ZWQgZnJvbSBgUmV0cnktQWZ0ZXJgIGZvciBzZWNvbmRhcnkgbGltaXRzLiBudWxsIHdoZW4gdW5rbm93bi4gKi9cbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVtYmVyIHwgbnVsbDtcblxuICBjb25zdHJ1Y3RvcihvcHRzOiB7XG4gICAgc3RhdHVzOiBudW1iZXI7XG4gICAgYm9keTogdW5rbm93bjtcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgcmV0cmlhYmxlOiBib29sZWFuO1xuICAgIGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXTtcbiAgICByYXRlTGltaXRSZXNldEF0PzogbnVtYmVyIHwgbnVsbDtcbiAgfSkge1xuICAgIHN1cGVyKG9wdHMubWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0dpdEh1YkVycm9yJztcbiAgICB0aGlzLnN0YXR1cyA9IG9wdHMuc3RhdHVzO1xuICAgIHRoaXMuYm9keSA9IG9wdHMuYm9keTtcbiAgICB0aGlzLnJldHJpYWJsZSA9IG9wdHMucmV0cmlhYmxlO1xuICAgIHRoaXMuY2F0ZWdvcnkgPSBvcHRzLmNhdGVnb3J5O1xuICAgIHRoaXMucmF0ZUxpbWl0UmVzZXRBdCA9IG9wdHMucmF0ZUxpbWl0UmVzZXRBdCA/PyBudWxsO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBHaXRIdWJDbGllbnQge1xuICBwcml2YXRlIHJlYWRvbmx5IHNldHRpbmdzOiBTZXR0aW5ncztcblxuICBjb25zdHJ1Y3RvcihzZXR0aW5nczogU2V0dGluZ3MpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gIH1cblxuICAvKiogUmV0dXJucyB0aGUgYXV0aGVudGljYXRlZCB1c2VyJ3MgbG9naW4uIFRocm93cyBvbiBhdXRoIGZhaWx1cmUuICovXG4gIGFzeW5jIHdob2FtaSgpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICByZXR1cm4gKHJlcyBhcyB7IGxvZ2luPzogc3RyaW5nIH0pLmxvZ2luID8/ICc8dW5rbm93bj4nO1xuICB9XG5cbiAgLyoqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZ2l2ZW4gYnJhbmNoIGV4aXN0cyBvbiB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xuICBhc3luYyBicmFuY2hFeGlzdHMoYnJhbmNoOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICdHRVQnLFxuICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2JyYW5jaGVzLyR7ZW5jb2RlVVJJQ29tcG9uZW50KGJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBmYWxzZTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKiogVmVyaWZpZXMgdGhlIFBBVCBjYW4gc2VlIHRoZSBjb25maWd1cmVkIHJlcG8uICovXG4gIGFzeW5jIHZlcmlmeVJlcG9BY2Nlc3MoKTogUHJvbWlzZTx7IGxvZ2luOiBzdHJpbmc7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH0+IHtcbiAgICBjb25zdCBtZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICBjb25zdCByZXBvID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb31gKTtcbiAgICBjb25zdCByID0gcmVwbyBhcyB7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGxvZ2luOiAobWUgYXMgeyBsb2dpbjogc3RyaW5nIH0pLmxvZ2luLFxuICAgICAgZnVsbF9uYW1lOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRmV0Y2ggYSB0ZXh0IGZpbGUgZnJvbSByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tIGF1dGhlbnRpY2F0ZWQgd2l0aCB0aGVcbiAgICogUEFULiBSZXR1cm5zIG51bGwgaWYgdGhlIGZpbGUgZG9lc24ndCBleGlzdC4gVXNlZCBmb3IgY29uZmlnL2FjY291bnRzLnlhbWwuXG4gICAqL1xuICBhc3luYyBmZXRjaFJhd1RleHQocGF0aEluUmVwbzogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgdXJsID0gYCR7UkFXX0JBU0V9LyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99LyR7dGhpcy5zZXR0aW5ncy5icmFuY2h9LyR7cGF0aEluUmVwb31gO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAgfSxcbiAgICB9KTtcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSByZXR1cm4gbnVsbDtcbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3IocmVzLCBgR0VUIHJhdyAke3BhdGhJblJlcG99YCk7XG4gICAgcmV0dXJuIHJlcy50ZXh0KCk7XG4gIH1cblxuICAvKipcbiAgICogTG9vayB1cCBhbiBleGlzdGluZyBmaWxlJ3MgU0hBIHZpYSB0aGUgQ29udGVudHMgQVBJLCBvciBudWxsIGlmIG5vdCBmb3VuZC5cbiAgICogVXNlZCB3aGVuIHJldHJ5aW5nIGEgUFVUIGFmdGVyIGEgNDIyIHNoYSBtaXNtYXRjaC5cbiAgICovXG4gIGFzeW5jIGdldEZpbGVTaGEocGF0aDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9P3JlZj0ke2VuY29kZVVSSUNvbXBvbmVudCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHIgPSByZXMgYXMgeyBzaGE/OiBzdHJpbmcgfTtcbiAgICAgIHJldHVybiByLnNoYSA/PyBudWxsO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBudWxsO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBQVVQgYSBmaWxlIHRvIHRoZSByZXBvLiBIYW5kbGVzIDQyMiAoc2hhIHJlcXVpcmVkKSBieSByZS1mZXRjaGluZyB0aGVcbiAgICogZXhpc3Rpbmcgc2hhIGFuZCByZXRyeWluZyBvbmNlLiBSZXRyaWVzIG5ldHdvcmsgLyA1eHggLyByYXRlLWxpbWl0IGVycm9yc1xuICAgKiB3aXRoIGV4cG9uZW50aWFsIGJhY2tvZmYgdXAgdG8gbWF4QXR0ZW1wdHMuXG4gICAqL1xuICBhc3luYyBwdXRGaWxlKG9wdHM6IFB1dEZpbGVPcHRpb25zKTogUHJvbWlzZTxQdXRGaWxlUmVzdWx0PiB7XG4gICAgY29uc3QgcGF0aCA9IG9wdHMucGF0aDtcbiAgICBjb25zdCB1cmwgPSBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2NvbnRlbnRzLyR7ZW5jb2RlUGF0aChwYXRoKX1gO1xuICAgIGxldCBzaGE6IHN0cmluZyB8IG51bGwgPSBvcHRzLmV4cGVjdGVkU2hhID8/IG51bGw7XG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xuXG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDE7IGF0dGVtcHQgPD0gbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xuICAgICAgY29uc3QgYm9keTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICAgIG1lc3NhZ2U6IG9wdHMubWVzc2FnZSxcbiAgICAgICAgY29udGVudDogb3B0cy5jb250ZW50QmFzZTY0LFxuICAgICAgICBicmFuY2g6IHRoaXMuc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgfTtcbiAgICAgIGlmIChzaGEpIGJvZHkuc2hhID0gc2hhO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ1BVVCcsIHVybCwgYm9keSk7XG4gICAgICAgIGNvbnN0IG91dCA9IHJlcyBhcyB7IGNvbnRlbnQ6IHsgc2hhOiBzdHJpbmc7IGh0bWxfdXJsOiBzdHJpbmc7IHBhdGg6IHN0cmluZyB9IH07XG4gICAgICAgIHJldHVybiB7IHBhdGg6IG91dC5jb250ZW50LnBhdGgsIHNoYTogb3V0LmNvbnRlbnQuc2hhLCB1cmw6IG91dC5jb250ZW50Lmh0bWxfdXJsIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XG4gICAgICAgIGlmIChlcnIuc3RhdHVzID09PSA0MjIgJiYgIXNoYSkge1xuICAgICAgICAgIC8vIEZpbGUgYWxyZWFkeSBleGlzdHM7IGZldGNoIGl0cyBzaGEgYW5kIHJldHJ5IG9uY2UuXG4gICAgICAgICAgc2hhID0gYXdhaXQgdGhpcy5nZXRGaWxlU2hhKHBhdGgpO1xuICAgICAgICAgIGlmICghc2hhKSB0aHJvdyBlcnI7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFlcnIucmV0cmlhYmxlIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGBwdXRGaWxlOiBleGhhdXN0ZWQgYXR0ZW1wdHMgZm9yICR7cGF0aH1gKTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZmV0Y2hKc29uKG1ldGhvZDogc3RyaW5nLCBwYXRoOiBzdHJpbmcsIGJvZHk/OiB1bmtub3duKTogUHJvbWlzZTx1bmtub3duPiB7XG4gICAgY29uc3QgdXJsID0gcGF0aC5zdGFydHNXaXRoKCdodHRwJykgPyBwYXRoIDogYCR7QVBJX0JBU0V9JHtwYXRofWA7XG4gICAgY29uc3QgaW5pdDogUmVxdWVzdEluaXQgPSB7XG4gICAgICBtZXRob2QsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLnNldHRpbmdzLnBhdH1gLFxuICAgICAgICBBY2NlcHQ6ICdhcHBsaWNhdGlvbi92bmQuZ2l0aHViK2pzb24nLFxuICAgICAgICAnWC1HaXRIdWItQXBpLVZlcnNpb24nOiAnMjAyMi0xMS0yOCcsXG4gICAgICAgIC4uLihib2R5ID8geyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gOiB7fSksXG4gICAgICB9LFxuICAgICAgLi4uKGJvZHkgPyB7IGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpIH0gOiB7fSksXG4gICAgfTtcbiAgICBsZXQgcmVzOiBSZXNwb25zZTtcbiAgICB0cnkge1xuICAgICAgcmVzID0gYXdhaXQgZmV0Y2godXJsLCBpbml0KTtcbiAgICB9IGNhdGNoIChuZXRFcnIpIHtcbiAgICAgIHRocm93IG5ldyBHaXRIdWJFcnJvcih7XG4gICAgICAgIHN0YXR1czogMCxcbiAgICAgICAgYm9keTogbnVsbCxcbiAgICAgICAgbWVzc2FnZTogYG5ldHdvcms6ICR7ZGVzY3JpYmVFcnJvcihuZXRFcnIpLm1lc3NhZ2V9YCxcbiAgICAgICAgcmV0cmlhYmxlOiB0cnVlLFxuICAgICAgICBjYXRlZ29yeTogJ25ldHdvcmsnLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChyZXMuc3RhdHVzID09PSAyMDQpIHJldHVybiBudWxsO1xuICAgIGxldCBwYXJzZWQ6IHVua25vd24gPSBudWxsO1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgIGlmICh0ZXh0KSB7XG4gICAgICB0cnkge1xuICAgICAgICBwYXJzZWQgPSBKU09OLnBhcnNlKHRleHQpO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIHBhcnNlZCA9IHRleHQ7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghcmVzLm9rKSB0aHJvdyBhd2FpdCB0aGlzLm1ha2VFcnJvckZyb21QYXJzZWQocmVzLCBwYXJzZWQsIGAke21ldGhvZH0gJHtwYXRofWApO1xuICAgIHJldHVybiBwYXJzZWQ7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIG1ha2VFcnJvcihyZXM6IFJlc3BvbnNlLCBsYWJlbDogc3RyaW5nKTogUHJvbWlzZTxHaXRIdWJFcnJvcj4ge1xuICAgIGxldCBwYXJzZWQ6IHVua25vd24gPSBudWxsO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICAgIGlmICh0ZXh0KSBwYXJzZWQgPSBKU09OLnBhcnNlKHRleHQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gaWdub3JlXG4gICAgfVxuICAgIHJldHVybiB0aGlzLm1ha2VFcnJvckZyb21QYXJzZWQocmVzLCBwYXJzZWQsIGxhYmVsKTtcbiAgfVxuXG4gIHByaXZhdGUgbWFrZUVycm9yRnJvbVBhcnNlZChyZXM6IFJlc3BvbnNlLCBib2R5OiB1bmtub3duLCBsYWJlbDogc3RyaW5nKTogR2l0SHViRXJyb3Ige1xuICAgIGNvbnN0IG1zZyA9XG4gICAgICB0eXBlb2YgYm9keSA9PT0gJ29iamVjdCcgJiYgYm9keSAmJiAnbWVzc2FnZScgaW4gYm9keVxuICAgICAgICA/IFN0cmluZygoYm9keSBhcyB7IG1lc3NhZ2U6IHVua25vd24gfSkubWVzc2FnZSlcbiAgICAgICAgOiByZXMuc3RhdHVzVGV4dDtcbiAgICBsZXQgY2F0ZWdvcnk6IEdpdEh1YkVycm9yWydjYXRlZ29yeSddID0gJ3Vua25vd24nO1xuICAgIGxldCByZXRyaWFibGUgPSBmYWxzZTtcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDAxIHx8IHJlcy5zdGF0dXMgPT09IDQwMykge1xuICAgICAgLy8gNDAzIGNhbiBiZSBlaXRoZXIgYXV0aCBvciByYXRlIGxpbWl0OyBjaGVjayBoZWFkZXJzLlxuICAgICAgY29uc3QgcmF0ZSA9IHJlcy5oZWFkZXJzLmdldCgneC1yYXRlbGltaXQtcmVtYWluaW5nJyk7XG4gICAgICBpZiAocmF0ZSA9PT0gJzAnIHx8IC9yYXRlIGxpbWl0L2kudGVzdChtc2cpKSB7XG4gICAgICAgIGNhdGVnb3J5ID0gJ3JhdGUtbGltaXQnO1xuICAgICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2F0ZWdvcnkgPSAnYXV0aCc7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID09PSA0MDQpIHtcbiAgICAgIGNhdGVnb3J5ID0gJ25vdC1mb3VuZCc7XG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID09PSA0MDkgfHwgcmVzLnN0YXR1cyA9PT0gNDIyKSB7XG4gICAgICBjYXRlZ29yeSA9ICdjb25mbGljdCc7XG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID49IDUwMCkge1xuICAgICAgY2F0ZWdvcnkgPSAnc2VydmVyJztcbiAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID09PSA0MjkpIHtcbiAgICAgIGNhdGVnb3J5ID0gJ3JhdGUtbGltaXQnO1xuICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBHaXRIdWJFcnJvcih7XG4gICAgICBzdGF0dXM6IHJlcy5zdGF0dXMsXG4gICAgICBib2R5LFxuICAgICAgbWVzc2FnZTogYCR7bGFiZWx9IFx1MjE5MiAke3Jlcy5zdGF0dXN9OiAke21zZ31gLFxuICAgICAgcmV0cmlhYmxlLFxuICAgICAgY2F0ZWdvcnksXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBjYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnID8gcGFyc2VSYXRlTGltaXRSZXNldChyZXMuaGVhZGVycykgOiBudWxsLFxuICAgIH0pO1xuICB9XG59XG5cbi8qKlxuICogQmVzdC1lZmZvcnQgcGFyc2Ugb2Ygd2hlbiB0aGUgY3VycmVudCByYXRlLWxpbWl0IHdpbmRvdyBlbmRzLiBHaXRIdWInc1xuICogcHJpbWFyeSBsaW1pdCByZXBvcnRzIGBYLVJhdGVMaW1pdC1SZXNldGAgYXMgYSBVbml4IGVwb2NoIGluIHNlY29uZHMuXG4gKiBTZWNvbmRhcnkgLyBhYnVzZSBsaW1pdHMgdXNlIGBSZXRyeS1BZnRlcmAsIHdoaWNoIGlzIGVpdGhlciBhbiBIVFRQLWRhdGVcbiAqIG9yIGEgZGVsdGEgaW4gc2Vjb25kcyBcdTIwMTQgd2Ugbm9ybWFsaXplIGJvdGggdG8gZXBvY2ggc2Vjb25kcy5cbiAqL1xuZnVuY3Rpb24gcGFyc2VSYXRlTGltaXRSZXNldChoZWFkZXJzOiBIZWFkZXJzKTogbnVtYmVyIHwgbnVsbCB7XG4gIGNvbnN0IHJlc2V0ID0gaGVhZGVycy5nZXQoJ3gtcmF0ZWxpbWl0LXJlc2V0Jyk7XG4gIGlmIChyZXNldCkge1xuICAgIGNvbnN0IG4gPSBOdW1iZXIucGFyc2VJbnQocmVzZXQsIDEwKTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKG4pICYmIG4gPiAwKSByZXR1cm4gbjtcbiAgfVxuICBjb25zdCByZXRyeUFmdGVyID0gaGVhZGVycy5nZXQoJ3JldHJ5LWFmdGVyJyk7XG4gIGlmIChyZXRyeUFmdGVyKSB7XG4gICAgY29uc3QgZGVsdGEgPSBOdW1iZXIucGFyc2VJbnQocmV0cnlBZnRlciwgMTApO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoZGVsdGEpICYmIGRlbHRhID49IDApIHtcbiAgICAgIHJldHVybiBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKSArIGRlbHRhO1xuICAgIH1cbiAgICBjb25zdCBhc0RhdGUgPSBEYXRlLnBhcnNlKHJldHJ5QWZ0ZXIpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYXNEYXRlKSkgcmV0dXJuIE1hdGguZmxvb3IoYXNEYXRlIC8gMTAwMCk7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmZ1bmN0aW9uIGVuY29kZVBhdGgocGF0aDogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gRW5jb2RlIHNlZ21lbnRzIGluZGl2aWR1YWxseSBzbyBzbGFzaGVzIHJlbWFpbi5cbiAgcmV0dXJuIHBhdGguc3BsaXQoJy8nKS5tYXAoZW5jb2RlVVJJQ29tcG9uZW50KS5qb2luKCcvJyk7XG59XG5cbmZ1bmN0aW9uIGJhY2tvZmZNcyhhdHRlbXB0OiBudW1iZXIsIGVycjogR2l0SHViRXJyb3IpOiBudW1iZXIge1xuICAvLyBFeHBvbmVudGlhbCB3aXRoIGppdHRlcjsgYnVtcCBoaWdoZXIgZm9yIHJhdGUtbGltaXQgcmVzcG9uc2VzLlxuICBjb25zdCBiYXNlID0gZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyA1MDAwIDogNTAwO1xuICBjb25zdCBqaXR0ZXIgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiA0MDApO1xuICByZXR1cm4gTWF0aC5taW4oNjBfMDAwLCBiYXNlICogMiAqKiAoYXR0ZW1wdCAtIDEpICsgaml0dGVyKTtcbn1cblxuZnVuY3Rpb24gc2xlZXAobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBieXRlcyBpcyBhIFVURi04IHN0cmluZyBvZiBKU09OOyBlbmNvZGUgdG8gYmFzZTY0IHRoZSBzYWZlIHdheS5cbiAgY29uc3QgdXRmOCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShieXRlcyk7XG4gIGxldCBiaW4gPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIHV0ZjgpIGJpbiArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShiaW4pO1xufVxuIiwgImltcG9ydCB7IFRXRUVUX1VSTF9QUkVGSVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDb21tdW5pdHlOb3RlLFxuICBNZWRpYUl0ZW0sXG4gIFR3ZWV0Q2FyZCxcbiAgVHdlZXRUeXBlLFxuICBVcmxFbnRpdHksXG4gIFVzZXJTbmFwc2hvdCxcbn0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTm9ybWFsaXplIEdyYXBoUUwgcmVzcG9uc2UgcGF5bG9hZHMgZnJvbSBYJ3MgaW50ZXJuYWwgQVBJIGludG9cbiAqIGBDYW5vbmljYWxUd2VldGBzLiBNYW55IGVuZHBvaW50cyBzaGFyZSBhIHNpbWlsYXIgdHdlZXQgc2hhcGUgYnV0IHdyYXAgaXQgaW5cbiAqIGRpZmZlcmVudCBlbnZlbG9wZXM7IHRoaXMgbW9kdWxlIHdhbGtzIHRoZSBzdHJ1Y3R1cmUgZGVmZW5zaXZlbHkuXG4gKlxuICogVGhlIHBhcnNlciBpcyBpbnRlbnRpb25hbGx5IHBlcm1pc3NpdmU6IGl0IHdpbGwgc2lsZW50bHkgc2tpcCBlbnRyaWVzIGl0XG4gKiBjYW4ndCByZWNvZ25pemUgYXMgdHdlZXRzIChjdXJzb3JzLCBhZHMsIGdhcCBlbnRyaWVzLCBtb2R1bGVzIG9mIG90aGVyXG4gKiB0d2VldHMsIHRvbWJzdG9uZXMpLiBJdCB0aHJvd3MgKm9ubHkqIHdoZW4gZ2l2ZW4gYSBwYXlsb2FkIGl0IGRvZXNuJ3Qga25vd1xuICogaG93IHRvIHdhbGsgYXQgYWxsIFx1MjAxNCB0aG9zZSBjYXNlcyBhcmUgY2F1Z2h0IGFuZCBxdWFyYW50aW5lZCB1cHN0cmVhbS5cbiAqL1xuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZUNvbnRleHQge1xuICBjYXB0dXJlZEF0OiBzdHJpbmc7XG4gIHJ1bklkOiBzdHJpbmc7XG4gIGVuZHBvaW50OiBzdHJpbmc7XG4gIGFsbG93ZWRIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZVJlc3VsdCB7XG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcbiAgb2JzZXJ2ZWRfaWRzOiBzdHJpbmdbXTtcbiAgLyoqXG4gICAqIFR3ZWV0LXNoYXBlZCBub2RlcyB0aGUgd2Fsa2VyIHNhdyAoaGFkIGEgYHJlc3RfaWRgKSBidXQgY291bGRuJ3QgdHVyblxuICAgKiBpbnRvIGEgZnVsbCBgQ2Fub25pY2FsVHdlZXRgIFx1MjAxNCB0eXBpY2FsbHkgYmVjYXVzZSB0aGUgZW1iZWRkZWQgdXNlclxuICAgKiBpbmZvIHdhcyBtaXNzaW5nIG9yIHRoZSBlbnRyeSB3YXMgYSBtZWRpYS1vbmx5IHRodW1ibmFpbCBjYXJkIGZyb21cbiAgICogdGhlIFVzZXJNZWRpYSBlbmRwb2ludC4gVGhlIGJhY2tncm91bmQgcXVldWVzIHRoZXNlIGZvciBhbiBleHBsaWNpdFxuICAgKiBcImdvIGZldGNoIHRoZSBkZXRhaWwgcGFnZVwiIGNyYXdsIHNvIHdlIGRvbid0IGRyb3AgdGhlbSBvbiB0aGUgZmxvb3IuXG4gICAqL1xuICBwYXJ0aWFsX2lkczogQXJyYXk8eyB0d2VldF9pZDogc3RyaW5nOyBoaW50X2hhbmRsZTogc3RyaW5nIHwgbnVsbCB9Pjtcbn1cblxuLy8gWCB0d2VldCBJRHMgYXJlIDY0LWJpdCBwb3NpdGl2ZSBpbnRlZ2VycyBzZXJpYWxpemVkIGFzIGRlY2ltYWwgc3RyaW5ncy5cbi8vIFRoZXkndmUgZ3Jvd24gdG8gMTkgY2hhcnMgKH4xLjVlMTgpIGJ5IDIwMjYuIFJlamVjdCBhbnl0aGluZyB0aGF0IGRvZXNuJ3Rcbi8vIG1hdGNoIHRoaXMgc2hhcGUgXHUyMDE0IG90aGVyd2lzZSBzcHVyaW91cyBjYXJkIElEcywgY3Vyc29yIHN0cmluZ3MsIGFkIHNsb3Rcbi8vIElEcywgZXRjLiBlbmQgdXAgaW4gdGhlIHBhcnRpYWwtY2FwdHVyZSBxdWV1ZSBhbmQgdGhlIGNyYXdsIGxvb3Bcbi8vIG5hdmlnYXRlcyB0byBpbnZhbGlkIFVSTHMgdGhhdCBzaG93IFwidGhpcyBwYWdlIGRvZXNuJ3QgZXhpc3RcIi5cbmNvbnN0IFRXRUVUX0lEX1JFID0gL15cXGR7MTUsMjB9JC87XG5cbi8vIE9ubHkgb25lIGVuZHBvaW50IGFjdHVhbGx5IGV4cG9zZXMgdGhlIGZhaWx1cmUgbW9kZSB0aGUgcGFydGlhbC1jYXB0dXJlXG4vLyBxdWV1ZSBleGlzdHMgZm9yIFx1MjAxNCB0aGUgTWVkaWEgdGFiJ3MgYFVzZXJNZWRpYWAgcXVlcnkgcmV0dXJuaW5nXG4vLyB0aHVtYm5haWwtb25seSBlbnRyaWVzIHdpdGhvdXQgYSBwb3B1bGF0ZWQgYXV0aG9yIGJsb2NrLiBFdmVyeSBvdGhlclxuLy8gZW5kcG9pbnQgdGhhdCBoYW5kcyB1cyBhIGBUd2VldGAgc2hhcGUgZ2l2ZXMgdXMgdGhlIGZ1bGwgZW50cnk7IGlmXG4vLyBgYnVpbGRUd2VldGAgZmFpbHMgdGhlcmUgaXQncyBhIHJlYWwgZXJyb3IsIG5vdCBcImdvIHJlLWZldGNoIHRoaXNcIi5cbi8vIFJlc3RyaWN0aW5nIHBhcnRpYWwtaWQgZW1pc3Npb24gdG8gVXNlck1lZGlhIHN0b3BzIHRoZSBmbG9vZHMgb2Zcbi8vIGZhbHNlIHBvc2l0aXZlcyByZXBvcnRlZCBvbiBSZXBsaWVzIC8gVHdlZXREZXRhaWwgLyBTZWFyY2hUaW1lbGluZS5cbmNvbnN0IFBBUlRJQUxfT0tfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJNZWRpYSddKTtcblxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShwYXlsb2FkOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBOb3JtYWxpemVSZXN1bHQge1xuICBjb25zdCByYXdUd2VldHMgPSBjb2xsZWN0VHdlZXRzKHBheWxvYWQpO1xuICBjb25zdCB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10gPSBbXTtcbiAgY29uc3Qgb2JzZXJ2ZWQ6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IGJ1aWx0ID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHBhcnRpYWxNYXAgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nIHwgbnVsbD4oKTtcbiAgY29uc3QgY29sbGVjdFBhcnRpYWxzID0gUEFSVElBTF9PS19FTkRQT0lOVFMuaGFzKGN0eC5lbmRwb2ludCk7XG4gIGZvciAoY29uc3QgcmF3IG9mIHJhd1R3ZWV0cykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0ID0gYnVpbGRUd2VldChyYXcsIGN0eCk7XG4gICAgICBpZiAoIXQpIHtcbiAgICAgICAgaWYgKGNvbGxlY3RQYXJ0aWFscykge1xuICAgICAgICAgIC8vIE9ubHkgZW5xdWV1ZSByZWFsLXR3ZWV0IHNoZWxscyAobm90IHRvbWJzdG9uZXMsIG5vdCBzdHJpcHBlZFxuICAgICAgICAgIC8vIG5vZGVzIGxhY2tpbmcgYSBsZWdhY3kgYmxvY2ssIG5vdCBnYXJiYWdlIElEcykuXG4gICAgICAgICAgY29uc3QgcGFydGlhbCA9IHBpY2tQYXJ0aWFsKHJhdyk7XG4gICAgICAgICAgaWYgKHBhcnRpYWwpIHBhcnRpYWxNYXAuc2V0KHBhcnRpYWwudHdlZXRfaWQsIHBhcnRpYWwuaGludF9oYW5kbGUpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIGJ1aWx0LmFkZCh0LnR3ZWV0X2lkKTtcbiAgICAgIGlmIChjdHguYWxsb3dlZEhhbmRsZXMuc2l6ZSA9PT0gMCB8fCBjdHguYWxsb3dlZEhhbmRsZXMuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgdHdlZXRzLnB1c2godCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBPbmUgYmFkIGVudHJ5IHNob3VsZG4ndCB0YWtlIGRvd24gdGhlIHdob2xlIGJhdGNoLlxuICAgIH1cbiAgfVxuICAvLyBBbnl0aGluZyB0aGF0IGVuZGVkIHVwIGluIHBhcnRpYWxNYXAgYnV0IEFMU08gY2FtZSBiYWNrIGFzIGEgYnVpbHRcbiAgLy8gdHdlZXQgKGRpZmZlcmVudCB3YWxrZXIgcGFzcywgc2FtZSBpZCkgaXNuJ3QgYWN0dWFsbHkgcGFydGlhbC5cbiAgY29uc3QgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcbiAgZm9yIChjb25zdCBbaWQsIGhpbnRdIG9mIHBhcnRpYWxNYXApIHtcbiAgICBpZiAoYnVpbHQuaGFzKGlkKSkgY29udGludWU7XG4gICAgcGFydGlhbF9pZHMucHVzaCh7IHR3ZWV0X2lkOiBpZCwgaGludF9oYW5kbGU6IGhpbnQgfSk7XG4gIH1cbiAgcmV0dXJuIHsgdHdlZXRzLCBvYnNlcnZlZF9pZHM6IG9ic2VydmVkLCBwYXJ0aWFsX2lkcyB9O1xufVxuXG5mdW5jdGlvbiBwaWNrUGFydGlhbChub2RlOiB1bmtub3duKTogeyB0d2VldF9pZDogc3RyaW5nOyBoaW50X2hhbmRsZTogc3RyaW5nIHwgbnVsbCB9IHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAvLyBEZWxldGVkIHR3ZWV0cyBzdXJmYWNlIGFzIFR3ZWV0VG9tYnN0b25lIFx1MjAxNCB0aGVyZSdzIG5vdGhpbmcgdG8gcmVmZXRjaCxcbiAgLy8gc2tpcCB0aGVtIG9yIHRoZSBjcmF3bCBsb29wIHdpbGwgc3BpbiBvbiBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXG4gIGlmIChuLl9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xuICAvLyBSZXF1aXJlIGEgcmVjb2duaXplZCBUd2VldCB0eXBlbmFtZSBPUiBhIGxlZ2FjeSBibG9jay4gQ3Vyc29ycywgYWRzLFxuICAvLyBtb2R1bGUgaGVhZGVycywgYW5kIHRoZSBsaWtlIGdldCByZWplY3RlZCBoZXJlLlxuICBjb25zdCB0biA9IG4uX190eXBlbmFtZTtcbiAgaWYgKHRuICE9PSAnVHdlZXQnICYmIHRuICE9PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnICYmICFvYmoobi5sZWdhY3kpKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgcmVzdElkID1cbiAgICAodHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgbi5yZXN0X2lkKSB8fFxuICAgICh0eXBlb2Ygb2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0ID09PSAnb2JqZWN0JyAmJlxuICAgICAgKG9iaihvYmoobi50d2VldF9yZXN1bHQpPy5yZXN1bHQpPy5yZXN0X2lkIGFzIHN0cmluZykpO1xuICBpZiAodHlwZW9mIHJlc3RJZCAhPT0gJ3N0cmluZycgfHwgIVRXRUVUX0lEX1JFLnRlc3QocmVzdElkKSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiB7IHR3ZWV0X2lkOiByZXN0SWQsIGhpbnRfaGFuZGxlOiBwaWNrSGludEhhbmRsZShub2RlKSB9O1xufVxuXG5mdW5jdGlvbiBwaWNrSGludEhhbmRsZShub2RlOiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihvYmoobi5jb3JlKT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgcmV0dXJuIChcbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmNvcmUpPy5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbChvYmoobi5sZWdhY3kpPy5zY3JlZW5fbmFtZSlcbiAgKTtcbn1cblxuZnVuY3Rpb24gY29sbGVjdFR3ZWV0cyhvYmo6IHVua25vd24pOiB1bmtub3duW10ge1xuICAvLyBXYWxrIHRoZSByZXNwb25zZSB0cmVlIGdhdGhlcmluZyBldmVyeXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIHR3ZWV0XG4gIC8vIHJlc3VsdC4gV2UgbG9vayBmb3Igbm9kZXMgc2hhcGVkIGxpa2U6XG4gIC8vICAgeyBfX3R5cGVuYW1lPzogJ1R3ZWV0J3wnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnLCByZXN0X2lkLCBsZWdhY3kgfVxuICAvLyBhbmQgdW53cmFwIHZpc2liaWxpdHkgd3JhcHBlcnMuXG4gIGNvbnN0IG91dDogdW5rbm93bltdID0gW107XG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbb2JqXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBub2RlID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG5vZGUgPT09IG51bGwgfHwgbm9kZSA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcbiAgICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAoc2Vlbi5oYXMobm9kZSBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChub2RlIGFzIG9iamVjdCk7XG5cbiAgICBpZiAobG9va3NMaWtlVHdlZXQobm9kZSkpIHtcbiAgICAgIG91dC5wdXNoKHVud3JhcFR3ZWV0KG5vZGUpKTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobm9kZSkpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBub2RlKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gbG9va3NMaWtlVHdlZXQobm9kZTogdW5rbm93bik6IG5vZGUgaXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIGNvbnN0IHR5cGVuYW1lID0gbi5fX3R5cGVuYW1lO1xuICBpZiAoXG4gICAgdHlwZW5hbWUgPT09ICdUd2VldCcgfHxcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyB8fFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnXG4gICkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIC8vIFNvbWUgZW50cmllcyBsYWNrIF9fdHlwZW5hbWUgYnV0IHN0aWxsIGNhcnJ5IGxlZ2FjeSArIHJlc3RfaWQgKyBjb3JlLlxuICByZXR1cm4gdHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgdHlwZW9mIG4ubGVnYWN5ID09PSAnb2JqZWN0JyAmJiBuLmxlZ2FjeSAhPT0gbnVsbDtcbn1cblxuZnVuY3Rpb24gdW53cmFwVHdlZXQobm9kZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XG4gIGlmIChub2RlLl9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgJiYgdHlwZW9mIG5vZGUudHdlZXQgPT09ICdvYmplY3QnKSB7XG4gICAgcmV0dXJuIG5vZGUudHdlZXQgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIH1cbiAgcmV0dXJuIG5vZGU7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkVHdlZXQocmF3OiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBDYW5vbmljYWxUd2VldCB8IG51bGwge1xuICBpZiAodHlwZW9mIHJhdyAhPT0gJ29iamVjdCcgfHwgcmF3ID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgdCA9IHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcblxuICBpZiAodC5fX3R5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCByZXN0SWQgPSBzdHJPck51bGwodC5yZXN0X2lkKTtcbiAgLy8gYGxlZ2FjeWAgaXMgc3RpbGwgd2hlcmUgbW9zdCBlbmdhZ2VtZW50IC8gZW50aXRpZXMgbGl2ZSBpbiAyMDI2LWVyYSBYXG4gIC8vIHBheWxvYWRzLCBidXQgYXMgb2YgcmVjZW50IHNjaGVtYSBtaWdyYXRpb25zIHNldmVyYWwgZmllbGRzIHByZXZpb3VzbHlcbiAgLy8gdGhlcmUgKG5vdGFibHkgdGhlIGF1dGhvciBoYW5kbGUpIGhhdmUgbW92ZWQgdG8gc2libGluZyBsb2NhdGlvbnMuIFdlXG4gIC8vIHRvbGVyYXRlIGEgbWlzc2luZyBsZWdhY3kgaGVyZSBhbmQgbG9vayB1cCBldmVyeXRoaW5nIHZpYSBmYWxsYmFja3MuXG4gIGNvbnN0IGxlZ2FjeSA9IG9iaih0LmxlZ2FjeSkgPz8ge307XG4gIGlmICghcmVzdElkKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBjb3JlID0gb2JqKHQuY29yZSk7XG4gIGNvbnN0IHVzZXJSZXN1bHQgPSBvYmoob2JqKGNvcmU/LnVzZXJfcmVzdWx0cyk/LnJlc3VsdCk7XG4gIC8vIEF1dGhvciBoYW5kbGU6IHRyeSB0aGUgbmV3IGBjb3JlYCBzdWJzdHJ1Y3R1cmUgZmlyc3QgKGN1cnJlbnQgWCBzaGFwZSksXG4gIC8vIHRoZW4gdGhlIGxlZ2FjeSBgbGVnYWN5LnNjcmVlbl9uYW1lYCwgdGhlbiBhIGNvdXBsZSBvZiBvbGRlciB2YXJpYW50cy5cbiAgY29uc3QgdXNlckNvcmVOZXcgPSBvYmoodXNlclJlc3VsdD8uY29yZSk7XG4gIGNvbnN0IHVzZXJMZWdhY3kgPSBvYmoodXNlclJlc3VsdD8ubGVnYWN5KTtcbiAgY29uc3QgdXNlckF2YXRhck9iaiA9IG9iaih1c2VyUmVzdWx0Py5hdmF0YXIpO1xuICBjb25zdCBoYW5kbGUgPVxuICAgIHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwobGVnYWN5LnNjcmVlbl9uYW1lKTtcbiAgY29uc3QgYWNjb3VudElkID1cbiAgICBzdHJPck51bGwodXNlclJlc3VsdD8ucmVzdF9pZCkgPz9cbiAgICBzdHJPck51bGwodXNlclJlc3VsdD8uaWRfc3RyKSA/P1xuICAgIHN0ck9yTnVsbChsZWdhY3kudXNlcl9pZF9zdHIpO1xuICBpZiAoIWhhbmRsZSB8fCAhYWNjb3VudElkKSByZXR1cm4gbnVsbDtcbiAgLy8gQXV0aG9yIHNuYXBzaG90LiBEaXNwbGF5IG5hbWUgKyBhdmF0YXIgbW92ZWQgYmV0d2VlbiBgbGVnYWN5YCBhbmQgdGhlXG4gIC8vIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIG92ZXIgdGltZTsgdGhlIHJlc3QgKHZlcmlmaWNhdGlvbiwgZm9sbG93ZXJcbiAgLy8gY291bnRzLCBhY2NvdW50X2NyZWF0ZWRfYXQpIGlzIHN0aWxsIGluIGBsZWdhY3lgLiBXZSBzbmFwc2hvdCB0aGVcbiAgLy8gd2hvbGUgVXNlclNuYXBzaG90IHBlciB0d2VldCBiZWNhdXNlIHRoZXNlIHZhbHVlcyBkcmlmdCBvdmVyIHRpbWVcbiAgLy8gYW5kIHRoZSBhdC1jYXB0dXJlIHN0YXRlIGlzIHRoZSBvbmx5IHJlbGlhYmxlIHJlY29yZC5cbiAgY29uc3QgYXV0aG9yID0gZXh0cmFjdFVzZXJTbmFwc2hvdCh1c2VyUmVzdWx0LCB1c2VyQ29yZU5ldywgdXNlckxlZ2FjeSwgdXNlckF2YXRhck9iaik7XG5cbiAgY29uc3Qgbm90ZVR3ZWV0ID0gb2JqKG9iaihvYmoodC5ub3RlX3R3ZWV0KT8ubm90ZV90d2VldF9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgY29uc3QgdGV4dEZyb21Ob3RlID0gc3RyT3JOdWxsKG5vdGVUd2VldD8udGV4dCk7XG4gIGNvbnN0IHRleHRGcm9tTGVnYWN5ID0gc3RyT3JOdWxsKGxlZ2FjeS5mdWxsX3RleHQpID8/ICcnO1xuICBjb25zdCB0ZXh0ID0gdGV4dEZyb21Ob3RlID8/IHRleHRGcm9tTGVnYWN5O1xuICBjb25zdCBpc1RydW5jYXRlZCA9IGRldGVjdFRydW5jYXRpb24obm90ZVR3ZWV0LCBsZWdhY3ksIHRleHRGcm9tTGVnYWN5KTtcbiAgY29uc3QgY29tbXVuaXR5Tm90ZSA9IGV4dHJhY3RDb21tdW5pdHlOb3RlKHQsIGxlZ2FjeSwgY3R4LmNhcHR1cmVkQXQpO1xuXG4gIGNvbnN0IGVudGl0aWVzID0gb2JqKGxlZ2FjeS5lbnRpdGllcykgPz8ge307XG4gIGNvbnN0IGVudGl0aWVzRnJvbU5vdGUgPSBvYmoobm90ZVR3ZWV0Py5lbnRpdHlfc2V0KTtcbiAgY29uc3QgaGFzaHRhZ3MgPSBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IG1lbnRpb25zID0gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xuICBjb25zdCB1cmxzID0gZXh0cmFjdFVybHMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IG1lZGlhID0gZXh0cmFjdE1lZGlhKGxlZ2FjeSk7XG5cbiAgY29uc3QgdHdlZXRUeXBlID0gY2xhc3NpZnlUd2VldFR5cGUodCwgbGVnYWN5KTtcblxuICAvLyBwb3N0ZWRfYXQ6IGxlZ2FjeS5jcmVhdGVkX2F0IHJlbWFpbnMgdGhlIGNhbm9uaWNhbCBsb2NhdGlvbjsgaWYgdGhhdCdzXG4gIC8vIG1pc3NpbmcgaW4gYSBmdXR1cmUgc2NoZW1hIHdlIGZhbGwgYmFjayB0byB0b3AtbGV2ZWwgY3JlYXRlZF9hdC5cbiAgY29uc3QgcG9zdGVkQXQgPVxuICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKGxlZ2FjeS5jcmVhdGVkX2F0KSkgPz8gcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodC5jcmVhdGVkX2F0KSk7XG4gIGlmICghcG9zdGVkQXQpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHZpZXdzID0gb2JqKHQudmlld3MpO1xuICBjb25zdCB2aWV3Q291bnQgPSBudW1Pck51bGwodmlld3M/LmNvdW50KSA/PyBudW1Pck51bGwoc3RyT3JOdWxsKHZpZXdzPy5jb3VudCkpO1xuXG4gIGNvbnN0IGNhcmQgPSBleHRyYWN0Q2FyZCh0KTtcbiAgY29uc3QgcGxhY2UgPSBvYmoobGVnYWN5LnBsYWNlKTtcblxuICBjb25zdCB0d2VldDogQ2Fub25pY2FsVHdlZXQgPSB7XG4gICAgdHdlZXRfaWQ6IHJlc3RJZCxcbiAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgIGFjY291bnRfaWQ6IGFjY291bnRJZCxcbiAgICBwb3N0ZWRfYXQ6IHBvc3RlZEF0LFxuICAgIGZpcnN0X2NhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICBsYXN0X3NlZW5fYXQ6IGN0eC5jYXB0dXJlZEF0LFxuICAgIGRlbGV0aW9uX2RldGVjdGVkX2F0OiBudWxsLFxuICAgIHR3ZWV0X3VybDogYCR7VFdFRVRfVVJMX1BSRUZJWH0vJHtoYW5kbGV9L3N0YXR1cy8ke3Jlc3RJZH1gLFxuICAgIHR3ZWV0X3R5cGU6IHR3ZWV0VHlwZSxcbiAgICBjb252ZXJzYXRpb25faWQ6IHN0ck9yTnVsbChsZWdhY3kuY29udmVyc2F0aW9uX2lkX3N0ciksXG4gICAgcmVwbHlfdG9fdHdlZXRfaWQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0ciksXG4gICAgcmVwbHlfdG9fYWNjb3VudDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zY3JlZW5fbmFtZSksXG4gICAgcmVwbHlfdG9fYWNjb3VudF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b191c2VyX2lkX3N0ciksXG4gICAgcXVvdGVkX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSxcbiAgICByZXR3ZWV0ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChcbiAgICAgIG9iaihvYmoobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCA/P1xuICAgICAgICAobGVnYWN5IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0clxuICAgICksXG4gICAgdGV4dCxcbiAgICB0ZXh0X3Jlc29sdmVkOiByZXNvbHZlU2hvcnRVcmxzKHRleHQsIHVybHMpLFxuICAgIGxhbmc6IHN0ck9yTnVsbChsZWdhY3kubGFuZyksXG4gICAgcG9zc2libHlfc2Vuc2l0aXZlOiBib29sT3JOdWxsKGxlZ2FjeS5wb3NzaWJseV9zZW5zaXRpdmUpLFxuICAgIHNvdXJjZTogc3RyT3JOdWxsKGxlZ2FjeS5zb3VyY2UpID8/IHN0ck9yTnVsbCh0LnNvdXJjZSksXG4gICAgcGxhY2VfZnVsbF9uYW1lOiBzdHJPck51bGwocGxhY2U/LmZ1bGxfbmFtZSksXG4gICAgaGFzaHRhZ3MsXG4gICAgbWVudGlvbnMsXG4gICAgdXJscyxcbiAgICBjYXJkLFxuICAgIG1lZGlhLFxuICAgIGxpa2VfY291bnQ6IG51bU9yWmVybyhsZWdhY3kuZmF2b3JpdGVfY291bnQpLFxuICAgIHJldHdlZXRfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXG4gICAgcmVwbHlfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucmVwbHlfY291bnQpLFxuICAgIHF1b3RlX2NvdW50OiBudW1Pclplcm8obGVnYWN5LnF1b3RlX2NvdW50KSxcbiAgICB2aWV3X2NvdW50OiB2aWV3Q291bnQsXG4gICAgYm9va21hcmtfY291bnQ6IG51bU9yTnVsbChsZWdhY3kuYm9va21hcmtfY291bnQpLFxuICAgIGVuZ2FnZW1lbnRfaGlzdG9yeTogW1xuICAgICAge1xuICAgICAgICBjYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgICAgIGxpa2VzOiBudW1Pclplcm8obGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcbiAgICAgICAgcmV0d2VldHM6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXG4gICAgICAgIHJlcGxpZXM6IG51bU9yWmVybyhsZWdhY3kucmVwbHlfY291bnQpLFxuICAgICAgICBxdW90ZXM6IG51bU9yWmVybyhsZWdhY3kucXVvdGVfY291bnQpLFxuICAgICAgICB2aWV3czogdmlld0NvdW50LFxuICAgICAgICBib29rbWFya3M6IG51bU9yTnVsbChsZWdhY3kuYm9va21hcmtfY291bnQpLFxuICAgICAgfSxcbiAgICBdLFxuICAgIGF1dGhvcixcbiAgICBjb21tdW5pdHlfbm90ZTogY29tbXVuaXR5Tm90ZSxcbiAgICBpc190cnVuY2F0ZWQ6IGlzVHJ1bmNhdGVkLFxuICAgIHdheWJhY2tfdXJsOiBudWxsLFxuICAgIHdheWJhY2tfc3VibWl0dGVkX2F0OiBudWxsLFxuICAgIGNhcHR1cmVfc291cmNlOiAnZXh0ZW5zaW9uJyxcbiAgICBjYXB0dXJlX3J1bl9pZDogY3R4LnJ1bklkLFxuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICB9O1xuXG4gIHJldHVybiB0d2VldDtcbn1cblxuZnVuY3Rpb24gY2xhc3NpZnlUd2VldFR5cGUodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldFR5cGUge1xuICBpZiAobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0IHx8IGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXR3ZWV0JztcbiAgaWYgKGxlZ2FjeS5pbl9yZXBseV90b19zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JlcGx5JztcbiAgaWYgKGxlZ2FjeS5pc19xdW90ZV9zdGF0dXMgPT09IHRydWUgfHwgbGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3F1b3RlJztcbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJykge1xuICAgIC8vIHBhc3MgdGhyb3VnaFxuICB9XG4gIHJldHVybiAnb3JpZ2luYWwnO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy5oYXNodGFncztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgcmV0dXJuIGFyclxuICAgIC5tYXAoKGgpID0+XG4gICAgICB0eXBlb2YgaCA9PT0gJ29iamVjdCcgJiYgaCAmJiAndGV4dCcgaW4gaCA/IFN0cmluZygoaCBhcyB7IHRleHQ6IHVua25vd24gfSkudGV4dCkgOiBudWxsXG4gICAgKVxuICAgIC5maWx0ZXIoKHMpOiBzIGlzIHN0cmluZyA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZ1tdIHtcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXNlcl9tZW50aW9ucztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgcmV0dXJuIGFyclxuICAgIC5tYXAoKHUpID0+XG4gICAgICB0eXBlb2YgdSA9PT0gJ29iamVjdCcgJiYgdSAmJiAnc2NyZWVuX25hbWUnIGluIHVcbiAgICAgICAgPyBTdHJpbmcoKHUgYXMgeyBzY3JlZW5fbmFtZTogdW5rbm93biB9KS5zY3JlZW5fbmFtZSlcbiAgICAgICAgOiBudWxsXG4gICAgKVxuICAgIC5maWx0ZXIoKHMpOiBzIGlzIHN0cmluZyA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdFVybHMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVXJsRW50aXR5W10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy51cmxzO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICBjb25zdCBvdXQ6IFVybEVudGl0eVtdID0gW107XG4gIGZvciAoY29uc3QgdSBvZiBhcnIpIHtcbiAgICBpZiAodHlwZW9mIHUgIT09ICdvYmplY3QnIHx8IHUgPT09IG51bGwpIGNvbnRpbnVlO1xuICAgIGNvbnN0IG8gPSB1IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIGNvbnN0IHNob3J0ID0gc3RyT3JOdWxsKG8udXJsKTtcbiAgICBjb25zdCBleHBhbmRlZCA9IHN0ck9yTnVsbChvLmV4cGFuZGVkX3VybCk7XG4gICAgY29uc3QgZGlzcGxheSA9IHN0ck9yTnVsbChvLmRpc3BsYXlfdXJsKTtcbiAgICBpZiAoIXNob3J0IHx8ICFleHBhbmRlZCkgY29udGludWU7XG4gICAgb3V0LnB1c2goeyBzaG9ydCwgZXhwYW5kZWQsIGRpc3BsYXk6IGRpc3BsYXkgPz8gZXhwYW5kZWQgfSk7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdE1lZGlhKGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW1bXSB7XG4gIGNvbnN0IGV4dGVuZGVkID0gb2JqKGxlZ2FjeS5leHRlbmRlZF9lbnRpdGllcyk7XG4gIGNvbnN0IGZyb21FeHQgPSBleHRlbmRlZCA/IHRvQXJyYXkoZXh0ZW5kZWQubWVkaWEpIDogW107XG4gIGNvbnN0IGZyb21FbnQgPSB0b0FycmF5KG9iaihsZWdhY3kuZW50aXRpZXMpPy5tZWRpYSk7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgbWVyZ2VkID0gWy4uLmZyb21FeHQsIC4uLmZyb21FbnRdLmZpbHRlcigobSkgPT4ge1xuICAgIGlmICh0eXBlb2YgbSAhPT0gJ29iamVjdCcgfHwgbSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGlkID1cbiAgICAgIHN0ck9yTnVsbCgobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikubWVkaWFfa2V5KSA/P1xuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5pZF9zdHIpO1xuICAgIGlmICghaWQpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoc2Vlbi5oYXMoaWQpKSByZXR1cm4gZmFsc2U7XG4gICAgc2Vlbi5hZGQoaWQpO1xuICAgIHJldHVybiB0cnVlO1xuICB9KTtcbiAgcmV0dXJuIG1lcmdlZC5tYXAoKHJhdykgPT4gYnVpbGRNZWRpYShyYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKTtcbn1cblxuZnVuY3Rpb24gYnVpbGRNZWRpYShtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbSB7XG4gIGNvbnN0IHR5cGUgPSBzdHJPck51bGwobS50eXBlKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXTtcbiAgY29uc3Qgb3JpZ2luYWwgPSBwaWNrT3JpZ2luYWxVcmwobSwgdHlwZSk7XG4gIGNvbnN0IGluZm8gPSBvYmoobS5vcmlnaW5hbF9pbmZvKTtcbiAgY29uc3QgdmlkZW9JbmZvID0gb2JqKG0udmlkZW9faW5mbyk7XG4gIGNvbnN0IGR1cmF0aW9uTXMgPSBudW1Pck51bGwodmlkZW9JbmZvPy5kdXJhdGlvbl9taWxsaXMpO1xuICBjb25zdCBhbHRUZXh0ID0gc3RyT3JOdWxsKG0uZXh0X2FsdF90ZXh0KTtcbiAgY29uc3QgbWVkaWFJZCA9XG4gICAgc3RyT3JOdWxsKG0ubWVkaWFfa2V5KSA/P1xuICAgIHN0ck9yTnVsbChtLmlkX3N0cikgPz9cbiAgICBgJHt0eXBlID8/ICdtZWRpYSd9LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMil9YDtcbiAgcmV0dXJuIHtcbiAgICBtZWRpYV9pZDogbWVkaWFJZCxcbiAgICBtZWRpYV90eXBlOiAodHlwZSA/PyAncGhvdG8nKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXSxcbiAgICBvcmlnaW5hbF91cmw6IG9yaWdpbmFsID8/ICcnLFxuICAgIHJlbGVhc2VfYXNzZXRfdXJsOiBudWxsLFxuICAgIHNoYTI1NjogbnVsbCxcbiAgICBieXRlczogbnVsbCxcbiAgICBkdXJhdGlvbl9zZWM6IGR1cmF0aW9uTXMgIT09IG51bGwgPyBkdXJhdGlvbk1zIC8gMTAwMCA6IG51bGwsXG4gICAgd2lkdGg6IG51bU9yTnVsbChpbmZvPy53aWR0aCksXG4gICAgaGVpZ2h0OiBudW1Pck51bGwoaW5mbz8uaGVpZ2h0KSxcbiAgICBhbHRfdGV4dDogYWx0VGV4dCxcbiAgICBhcmNoaXZlX3N0YXR1czogJ3BlbmRpbmcnLFxuICAgIGFyY2hpdmVfYXR0ZW1wdHM6IDAsXG4gICAgbGFzdF9hdHRlbXB0X2F0OiBudWxsLFxuICB9O1xufVxuXG5mdW5jdGlvbiBwaWNrT3JpZ2luYWxVcmwobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHR5cGU6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKHR5cGUgPT09ICdwaG90bycpIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpID8/IHN0ck9yTnVsbChtLm1lZGlhX3VybCk7XG4gIGNvbnN0IHZhcmlhbnRzID0gdG9BcnJheShvYmoobS52aWRlb19pbmZvKT8udmFyaWFudHMpIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+W107XG4gIGlmICh2YXJpYW50cy5sZW5ndGggPT09IDApIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpO1xuICAvLyBIaWdoZXN0LWJpdHJhdGUgbXA0LlxuICBsZXQgYmVzdDogeyB1cmw6IHN0cmluZzsgYml0cmF0ZTogbnVtYmVyIH0gfCBudWxsID0gbnVsbDtcbiAgZm9yIChjb25zdCB2IG9mIHZhcmlhbnRzKSB7XG4gICAgY29uc3QgY3QgPSBzdHJPck51bGwodi5jb250ZW50X3R5cGUpO1xuICAgIGNvbnN0IHVybCA9IHN0ck9yTnVsbCh2LnVybCk7XG4gICAgaWYgKCF1cmwpIGNvbnRpbnVlO1xuICAgIGlmIChjdCA9PT0gJ3ZpZGVvL21wNCcpIHtcbiAgICAgIGNvbnN0IGJyID0gbnVtT3JOdWxsKHYuYml0cmF0ZSkgPz8gMDtcbiAgICAgIGlmICghYmVzdCB8fCBiciA+IGJlc3QuYml0cmF0ZSkgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiBiciB9O1xuICAgIH0gZWxzZSBpZiAoIWJlc3QpIHtcbiAgICAgIC8vIEZhbGxiYWNrIHRvIGFueSB2YXJpYW50IGlmIG5vIG1wNCBmb3VuZC5cbiAgICAgIGJlc3QgPSB7IHVybCwgYml0cmF0ZTogMCB9O1xuICAgIH1cbiAgfVxuICByZXR1cm4gYmVzdD8udXJsID8/IG51bGw7XG59XG5cbmZ1bmN0aW9uIHJlc29sdmVTaG9ydFVybHModGV4dDogc3RyaW5nLCB1cmxzOiBVcmxFbnRpdHlbXSk6IHN0cmluZyB7XG4gIGlmICh1cmxzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHRleHQ7XG4gIGxldCBvdXQgPSB0ZXh0O1xuICBmb3IgKGNvbnN0IHUgb2YgdXJscykgb3V0ID0gb3V0LnNwbGl0KHUuc2hvcnQpLmpvaW4odS5leHBhbmRlZCk7XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIHBhcnNlVHdpdHRlckRhdGUoczogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAoIXMpIHJldHVybiBudWxsO1xuICAvLyBUd2l0dGVyIHNoaXBzIGRhdGVzIGxpa2UgXCJNb24gQXByIDEyIDE0OjIzOjAxICswMDAwIDIwMjVcIi5cbiAgY29uc3QgZCA9IG5ldyBEYXRlKHMpO1xuICBpZiAoTnVtYmVyLmlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiBkLnRvSVNPU3RyaW5nKCk7XG59XG5cbmZ1bmN0aW9uIHN0ck9yTnVsbCh2OiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwID8gdiA6IG51bGw7XG59XG5mdW5jdGlvbiBib29sT3JOdWxsKHY6IHVua25vd24pOiBib29sZWFuIHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nID8gdiA6IG51bGw7XG59XG5mdW5jdGlvbiBudW1Pck51bGwodjogdW5rbm93bik6IG51bWJlciB8IG51bGwge1xuICBpZiAodHlwZW9mIHYgPT09ICdudW1iZXInICYmIE51bWJlci5pc0Zpbml0ZSh2KSkgcmV0dXJuIHY7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IE51bWJlcih2KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKG4pKSByZXR1cm4gbjtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIG51bU9yWmVybyh2OiB1bmtub3duKTogbnVtYmVyIHtcbiAgcmV0dXJuIG51bU9yTnVsbCh2KSA/PyAwO1xufVxuZnVuY3Rpb24gb2JqKHY6IHVua25vd24pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwge1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdvYmplY3QnICYmIHYgIT09IG51bGwgJiYgIUFycmF5LmlzQXJyYXkodilcbiAgICA/ICh2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVxuICAgIDogbnVsbDtcbn1cbmZ1bmN0aW9uIHRvQXJyYXkodjogdW5rbm93bik6IHVua25vd25bXSB7XG4gIHJldHVybiBBcnJheS5pc0FycmF5KHYpID8gdiA6IFtdO1xufVxuXG4vKipcbiAqIERlY2lkZSB3aGV0aGVyIGEgdHdlZXQncyBhcmNoaXZlZCBgdGV4dGAgaXMgdGhlIHRydW5jYXRlZCBoZWFkIG9mIGEgbG9uZ2VyXG4gKiBib2R5LiBBIHRydW5jYXRlZCB0d2VldCBoYXMgWCdzIFwiU2hvdyBtb3JlXCIgdC5jbyBVUkwgYXBwZW5kZWQgXHUyMDE0IHRoYXQgVVJMXG4gKiBzcGVjaWZpY2FsbHkgZXhwYW5kcyB0byB0aGUgdHdlZXQncyBvd24gL2kvd2ViL3N0YXR1cy88aWQ+IHBlcm1hbGluaywgYW5kXG4gKiBpcyB0aGUgb25seSByZWxpYWJsZSBkaXN0aW5ndWlzaGluZyBmZWF0dXJlLiBQbGVudHkgb2Ygbm9ybWFsIHR3ZWV0cyBoYXZlXG4gKiB0cmFpbGluZyB0LmNvIFVSTHMgKG1lZGlhLCBxdW90ZXMsIHJlZ3VsYXIgbGlua3MpLCBhbmQgdGhlaXJcbiAqIGRpc3BsYXlfdGV4dF9yYW5nZSBhbHNvIHRyaW1zIHBhc3QgZnVsbF90ZXh0Lmxlbmd0aCwgc28gdGhlIG9sZFxuICogXCJkaXNwbGF5X3RleHRfcmFuZ2VbMV0gPCBmdWxsX3RleHQubGVuZ3RoXCIgaGV1cmlzdGljIHdhcyBvdmVyZmxhZ2dpbmdcbiAqIGVzc2VudGlhbGx5IGV2ZXJ5IHR3ZWV0IHdpdGggYSBsaW5rIGluIGl0LlxuICpcbiAqIFJ1bGVzOlxuICogICAtIG5vdGVfdHdlZXQgcHJlc2VudCAgXHUyMTkyIG5vdCB0cnVuY2F0ZWQgKHdlIGFscmVhZHkgaGF2ZSB0aGUgZnVsbCBib2R5KS5cbiAqICAgLSBPbmUgb2YgbGVnYWN5LmVudGl0aWVzLnVybHMgaGFzIGFuIGV4cGFuZGVkX3VybCBsaWtlXG4gKiAgICAgXCIuLi4vaS93ZWIvc3RhdHVzLzxpZD5cIiAgXHUyMTkyICB0cnVuY2F0ZWQuXG4gKiAgIC0gT3RoZXJ3aXNlIFx1MjE5MiBub3QgdHJ1bmNhdGVkLlxuICpcbiAqIFRoZSBwcmV2aW91cyBmYWxsYmFjayAoXCJ0cmFpbGluZyB0LmNvIFVSTCArIGxlbmd0aCBcdTIyNjUgMjcwXCIpIGZsYWdnZWQgZXZlcnlcbiAqIG1lZGlhIHR3ZWV0IGV4YWN0bHkgYXQgdGhlIDI4MC1jaGFyIGxpbWl0LiBXZSBkcm9wIGl0IGVudGlyZWx5OyB0aGUgb25seVxuICogY29zdCBpcyBtaXNzaW5nIGdlbnVpbmVseS10cnVuY2F0ZWQgdHdlZXRzIHdob3NlIHBheWxvYWQgd2FzIHNvIGRlZ3JhZGVkXG4gKiBpdCBsYWNrZWQgZW50aXRpZXMgXHUyMDE0IHdoaWNoIGlzIGFsc28gd2hlcmUgdGhlIHJlZmV0Y2ggbG9vcCB3b3VsZCBmYWlsXG4gKiBhbnl3YXksIHNvIG5vdGhpbmcgaXMgYWN0dWFsbHkgbG9zdC5cbiAqL1xuZnVuY3Rpb24gZGV0ZWN0VHJ1bmNhdGlvbihcbiAgbm90ZVR3ZWV0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gIGZ1bGxUZXh0OiBzdHJpbmdcbik6IGJvb2xlYW4ge1xuICBpZiAobm90ZVR3ZWV0KSByZXR1cm4gZmFsc2U7XG4gIGlmICghZnVsbFRleHQpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKTtcbiAgY29uc3QgdXJscyA9IGVudGl0aWVzID8gZW50aXRpZXMudXJscyA6IG51bGw7XG4gIGlmIChBcnJheS5pc0FycmF5KHVybHMpKSB7XG4gICAgZm9yIChjb25zdCB1IG9mIHVybHMpIHtcbiAgICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XG4gICAgICBjb25zdCBleHAgPSAodSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuZXhwYW5kZWRfdXJsO1xuICAgICAgLy8gVGhlIFwiU2hvdyBtb3JlXCIgbGluayBleHBhbmRzIHRvIGVpdGhlciBvZiB0aGVzZSBzZWxmLXBlcm1hbGlua1xuICAgICAgLy8gc2hhcGVzOiAgaHR0cHM6Ly94LmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxuICAgICAgLy8gICAgICAgICAgaHR0cHM6Ly90d2l0dGVyLmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxuICAgICAgaWYgKHR5cGVvZiBleHAgPT09ICdzdHJpbmcnICYmIC9cXC9pXFwvd2ViXFwvc3RhdHVzXFwvXFxkKy8udGVzdChleHApKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbi8qKlxuICogRmlsdGVyIGB0d2VldHNgIGRvd24gdG8gdGhvc2UgcmVsYXRlZCB0byBhIHRyYWNrZWQgYWNjb3VudC4gQSB0d2VldCBpc1xuICogXCJyZWxhdGVkXCIgaWYgYW55IG9mIHRoZSBmb2xsb3dpbmcgaG9sZDpcbiAqXG4gKiAgIC0gaXRzIGF1dGhvciBpcyB0cmFja2VkIChoYW5kbGUgaW4gYHRhcmdldGVkYCksXG4gKiAgIC0gaXQgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZSxcbiAqICAgLSBpdCByZXBsaWVzIHRvIGEgdHJhY2tlZCBhY2NvdW50LFxuICogICAtIGl0IHF1b3Rlcy9yZXR3ZWV0cy9yZXBsaWVzLXRvIGEgdHdlZXQgdGhhdCdzIGFsc28gcHJlc2VudCBpbiB0aGVcbiAqICAgICBiYXRjaCAqYW5kKiBhdXRob3JlZCBieSBhIHRyYWNrZWQgYWNjb3VudCAodHJhbnNpdGl2ZWx5IHJlbGF0ZWQgXHUyMDE0XG4gKiAgICAgY2FwdHVyZXMgdGhlIHF1b3RlZC9SVCdkIGNvbnRlbnQgdGhhdCBhcHBlYXJzIGFzIGEgc2libGluZyBub2RlIGluXG4gKiAgICAgdGhlIHNhbWUgR3JhcGhRTCByZXNwb25zZSkuXG4gKlxuICogQW55dGhpbmcgZWxzZSAocmFuZG9tIHJlcGxpZXMgdW5kZXIgYSB0cmFja2VkIGFjY291bnQncyB0d2VldCwgcmFuZG9tXG4gKiBhdXRob3JzIHRoYXQgaGFwcGVuIHRvIHN1cmZhY2UgaW4gYSB0cmFja2VkIGFjY291bnQncyB0aHJlYWQpIGlzIGRyb3BwZWQuXG4gKiBQYXNzIGFuIGVtcHR5IGB0YXJnZXRlZGAgc2V0IHRvIGRpc2FibGUgZmlsdGVyaW5nIGVudGlyZWx5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyUmVsYXRlZChcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdLFxuICB0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPlxuKTogQ2Fub25pY2FsVHdlZXRbXSB7XG4gIGlmICh0YXJnZXRlZC5zaXplID09PSAwKSByZXR1cm4gdHdlZXRzO1xuICAvLyBGaXJzdCBwYXNzOiB3aGljaCB0d2VldCBJRHMgZG8gdHJhY2tlZC1hdXRob3IgdHdlZXRzIHJlZmVyZW5jZSAodGhlXG4gIC8vIFwiZm9yd2FyZFwiIGRpcmVjdGlvbiBcdTIwMTQgdHJhY2tlZCBhY2NvdW50IHF1b3RlcyAvIFJUcyAvIHJlcGxpZXMgdG8gWCk/XG4gIC8vIEFuZCB3aGljaCB0d2VldCBJRHMgQVJFIHRyYWNrZWQtYXV0aG9yZWQgKHRoZSBcInJldmVyc2VcIiBkaXJlY3Rpb24gXHUyMDE0XG4gIC8vIFggcXVvdGVzIC8gUlRzIC8gcmVwbGllcyB0byBhIHRyYWNrZWQgdHdlZXQpP1xuICBjb25zdCByZWZlcmVuY2VkSWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHRhcmdldGVkVHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgIGlmICghdGFyZ2V0ZWQuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIGNvbnRpbnVlO1xuICAgIHRhcmdldGVkVHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xuICAgIGlmICh0LnF1b3RlZF90d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5xdW90ZWRfdHdlZXRfaWQpO1xuICAgIGlmICh0LnJldHdlZXRlZF90d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpO1xuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnJlcGx5X3RvX3R3ZWV0X2lkKTtcbiAgfVxuICByZXR1cm4gdHdlZXRzLmZpbHRlcigodCkgPT4ge1xuICAgIGNvbnN0IGggPSB0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKHRhcmdldGVkLmhhcyhoKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gRm9yd2FyZDogYSB0cmFja2VkLWF1dGhvciB0d2VldCBwb2ludGVkIGF0IHRoaXMgb25lLlxuICAgIGlmIChyZWZlcmVuY2VkSWRzLmhhcyh0LnR3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gUmV2ZXJzZTogdGhpcyB0d2VldCBwb2ludHMgYXQgYSB0cmFja2VkLWF1dGhvciB0d2VldCBpbiB0aGUgYmF0Y2guXG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucXVvdGVkX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKHQucmV0d2VldGVkX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucmV0d2VldGVkX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKHQucmVwbHlfdG9fdHdlZXRfaWQgJiYgdGFyZ2V0ZWRUd2VldElkcy5oYXModC5yZXBseV90b190d2VldF9pZCkpIHJldHVybiB0cnVlO1xuICAgIC8vIFJlcGx5LXRvLWFjY291bnQgb3IgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZS5cbiAgICBpZiAodC5yZXBseV90b19hY2NvdW50ICYmIHRhcmdldGVkLmhhcyh0LnJlcGx5X3RvX2FjY291bnQudG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xuICAgIGZvciAoY29uc3QgbSBvZiB0Lm1lbnRpb25zKSB7XG4gICAgICBpZiAodGFyZ2V0ZWQuaGFzKG0udG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH0pO1xufVxuXG4vKipcbiAqIFB1bGwgdGhlIENvbW11bml0eSBOb3RlIChmb3JtZXJseSBCaXJkd2F0Y2gpIGJsb2NrIGF0dGFjaGVkIHRvIGEgdHdlZXQsIGlmXG4gKiBhbnkuIFRoZSBwaXZvdCBjYW4gbGl2ZSBhdCBgdHdlZXQubGVnYWN5LmJpcmR3YXRjaF9waXZvdGAgKG9sZGVyIHNoYXBlKSBvclxuICogYHR3ZWV0LmJpcmR3YXRjaF9waXZvdGAgKGN1cnJlbnQgc2hhcGUpLiBUaGUgc3VtbWFyeSB0ZXh0IGlzIHdoYXQgcmVhZGVyc1xuICogYWN0dWFsbHkgc2VlOyB3ZSBrZWVwIHRoZSBzdXJyb3VuZGluZyBtZXRhZGF0YSBzbyBkb3duc3RyZWFtIHRvb2xpbmcgY2FuXG4gKiB0ZWxsIGRyYWZ0cyBhcGFydCBmcm9tIHJhdGVkLWhlbHBmdWwgbm90ZXMuXG4gKi9cbmZ1bmN0aW9uIGV4dHJhY3RDb21tdW5pdHlOb3RlKFxuICB0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAgb2JzZXJ2ZWRBdDogc3RyaW5nXG4pOiBDb21tdW5pdHlOb3RlIHwgbnVsbCB7XG4gIGNvbnN0IHBpdm90ID0gb2JqKHQuYmlyZHdhdGNoX3Bpdm90KSA/PyBvYmoobGVnYWN5LmJpcmR3YXRjaF9waXZvdCk7XG4gIGlmICghcGl2b3QpIHJldHVybiBudWxsO1xuICBjb25zdCBzdWJ0aXRsZSA9IG9iaihwaXZvdC5zdWJ0aXRsZSk7XG4gIGNvbnN0IG5vdGUgPSBvYmoocGl2b3Qubm90ZSk7XG4gIGNvbnN0IHN1bW1hcnkgPSBzdHJPck51bGwoc3VidGl0bGU/LnRleHQpO1xuICBjb25zdCB0aXRsZSA9IHN0ck9yTnVsbChwaXZvdC50aXRsZSk7XG4gIGNvbnN0IHNob3J0VGl0bGUgPSBzdHJPck51bGwocGl2b3Quc2hvcnRUaXRsZSk7XG4gIGNvbnN0IGRlc3RpbmF0aW9uVXJsID0gc3RyT3JOdWxsKHBpdm90LmRlc3RpbmF0aW9uVXJsKTtcbiAgY29uc3Qgbm90ZUlkID0gc3RyT3JOdWxsKHBpdm90Lm5vdGVJZCkgPz8gc3RyT3JOdWxsKG5vdGU/LnJlc3RfaWQpO1xuICAvLyBTa2lwIGVtcHR5IHNoZWxscyB0aGF0IGhhdmUgbm8gYWN0dWFsIGNvbnRlbnQuXG4gIGlmICghc3VtbWFyeSAmJiAhdGl0bGUgJiYgIW5vdGVJZCkgcmV0dXJuIG51bGw7XG4gIHJldHVybiB7XG4gICAgbm90ZV9pZDogbm90ZUlkLFxuICAgIHRpdGxlLFxuICAgIHNob3J0X3RpdGxlOiBzaG9ydFRpdGxlLFxuICAgIHN1bW1hcnksXG4gICAgZGVzdGluYXRpb25fdXJsOiBkZXN0aW5hdGlvblVybCxcbiAgICBvYnNlcnZlZF9hdDogb2JzZXJ2ZWRBdCxcbiAgfTtcbn1cblxuLyoqXG4gKiBQdWxsIGEgcGVyLWF1dGhvciBVc2VyU25hcHNob3QgZnJvbSB0aGUgdHdlZXQncyB1c2VyX3Jlc3VsdHMgbm9kZS4gRXZlcnlcbiAqIGZpZWxkIGRlZmF1bHRzIHRvIG51bGwgd2hlbiBtaXNzaW5nIHNvIHRoZSBzY2hlbWEgc3RheXMgc3RhYmxlIGFjcm9zc1xuICogdGhlIGxlZ2FjeSAvIGNvcmUgc2hhcGUgbWlncmF0aW9ucyBYIGhhcyBiZWVuIGRvaW5nLlxuICovXG5mdW5jdGlvbiBleHRyYWN0VXNlclNuYXBzaG90KFxuICB1c2VyUmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIHVzZXJDb3JlTmV3OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIHVzZXJMZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgdXNlckF2YXRhck9iajogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsXG4pOiBVc2VyU25hcHNob3Qge1xuICBjb25zdCB2ZXJpZmljYXRpb24gPSBvYmoodXNlclJlc3VsdD8udmVyaWZpY2F0aW9uKTtcbiAgcmV0dXJuIHtcbiAgICBkaXNwbGF5X25hbWU6XG4gICAgICBzdHJPck51bGwodXNlckNvcmVOZXc/Lm5hbWUpID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5uYW1lKSA/PyBzdHJPck51bGwodXNlclJlc3VsdD8ubmFtZSksXG4gICAgYXZhdGFyX3VybDpcbiAgICAgIHN0ck9yTnVsbCh1c2VyQXZhdGFyT2JqPy5pbWFnZV91cmwpID8/XG4gICAgICBzdHJPck51bGwodXNlckxlZ2FjeT8ucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMpID8/XG4gICAgICBzdHJPck51bGwodXNlclJlc3VsdD8ucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMpLFxuICAgIHZlcmlmaWVkOiBib29sT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWQpID8/IGJvb2xPck51bGwodXNlckxlZ2FjeT8udmVyaWZpZWQpLFxuICAgIGlzX2JsdWVfdmVyaWZpZWQ6IGJvb2xPck51bGwodXNlclJlc3VsdD8uaXNfYmx1ZV92ZXJpZmllZCksXG4gICAgdmVyaWZpZWRfdHlwZTogc3RyT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWRfdHlwZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnZlcmlmaWVkX3R5cGUpLFxuICAgIGRlc2NyaXB0aW9uOiBzdHJPck51bGwodXNlckxlZ2FjeT8uZGVzY3JpcHRpb24pLFxuICAgIGxvY2F0aW9uOiBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmxvY2F0aW9uKT8ubG9jYXRpb24pID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5sb2NhdGlvbiksXG4gICAgdXJsOiBzdHJPck51bGwodXNlckxlZ2FjeT8udXJsKSxcbiAgICBmb2xsb3dlcnNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5mb2xsb3dlcnNfY291bnQpLFxuICAgIGZyaWVuZHNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5mcmllbmRzX2NvdW50KSxcbiAgICBzdGF0dXNlc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LnN0YXR1c2VzX2NvdW50KSxcbiAgICBhY2NvdW50X2NyZWF0ZWRfYXQ6XG4gICAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8uY3JlYXRlZF9hdCkpID8/XG4gICAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5jcmVhdGVkX2F0KSksXG4gICAgcHJvdGVjdGVkOiBib29sT3JOdWxsKHVzZXJMZWdhY3k/LnByb3RlY3RlZCksXG4gIH07XG59XG5cbi8qKlxuICogV2FsayB0aGUgdHdlZXQncyBgY2FyZC5sZWdhY3kuYmluZGluZ192YWx1ZXNgIChrZXkvdmFsdWUgYXJyYXkpIGludG8gYVxuICogZmxhdCBUd2VldENhcmQgd2l0aCB0aXRsZSwgZGVzY3JpcHRpb24sIGFuZCBhIHJlcHJlc2VudGF0aXZlIGltYWdlIFVSTC5cbiAqIFJldHVybnMgbnVsbCB3aGVuIHRoZSB0d2VldCBoYXMgbm8gY2FyZC5cbiAqL1xuZnVuY3Rpb24gZXh0cmFjdENhcmQodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldENhcmQgfCBudWxsIHtcbiAgY29uc3QgY2FyZCA9IG9iaih0LmNhcmQpO1xuICBjb25zdCBjYXJkTGVnYWN5ID0gb2JqKGNhcmQ/LmxlZ2FjeSk7XG4gIGlmICghY2FyZExlZ2FjeSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGJpbmRpbmdzID0gY2FyZExlZ2FjeS5iaW5kaW5nX3ZhbHVlcztcbiAgY29uc3QgYnlLZXk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XG4gIGlmIChBcnJheS5pc0FycmF5KGJpbmRpbmdzKSkge1xuICAgIGZvciAoY29uc3QgYnYgb2YgYmluZGluZ3MpIHtcbiAgICAgIGlmICh0eXBlb2YgYnYgIT09ICdvYmplY3QnIHx8IGJ2ID09PSBudWxsKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IG8gPSBidiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGNvbnN0IGsgPSBzdHJPck51bGwoby5rZXkpO1xuICAgICAgY29uc3QgdiA9IG9iaihvLnZhbHVlKTtcbiAgICAgIGlmICghayB8fCAhdikgY29udGludWU7XG4gICAgICBieUtleVtrXSA9XG4gICAgICAgIHN0ck9yTnVsbCh2LnN0cmluZ192YWx1ZSkgPz9cbiAgICAgICAgc3RyT3JOdWxsKG9iaih2LmltYWdlX3ZhbHVlKT8udXJsKSA/P1xuICAgICAgICBzdHJPck51bGwob2JqKHYuaW1hZ2VfY29sb3JfdmFsdWUpPy5wYWxldHRlKTtcbiAgICB9XG4gIH1cbiAgY29uc3QgbmFtZSA9IHN0ck9yTnVsbChjYXJkTGVnYWN5Lm5hbWUpO1xuICBjb25zdCBjYXJkVXJsID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kudXJsKTtcbiAgY29uc3QgdmVuZG9yVXJsID1cbiAgICB0eXBlb2YgYnlLZXlbJ3Zhbml0eV91cmwnXSA9PT0gJ3N0cmluZycgPyAoYnlLZXlbJ3Zhbml0eV91cmwnXSBhcyBzdHJpbmcpIDogbnVsbDtcbiAgY29uc3QgdGl0bGUgPSB0eXBlb2YgYnlLZXlbJ3RpdGxlJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5Wyd0aXRsZSddIGFzIHN0cmluZykgOiBudWxsO1xuICBjb25zdCBkZXNjcmlwdGlvbiA9XG4gICAgdHlwZW9mIGJ5S2V5WydkZXNjcmlwdGlvbiddID09PSAnc3RyaW5nJyA/IChieUtleVsnZGVzY3JpcHRpb24nXSBhcyBzdHJpbmcpIDogbnVsbDtcbiAgY29uc3QgaW1hZ2VVcmwgPVxuICAgICh0eXBlb2YgYnlLZXlbJ3Bob3RvX2ltYWdlX2Z1bGxfc2l6ZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xuICAgICAgPyAoYnlLZXlbJ3Bob3RvX2ltYWdlX2Z1bGxfc2l6ZV9vcmlnaW5hbCddIGFzIHN0cmluZylcbiAgICAgIDogbnVsbCkgPz9cbiAgICAodHlwZW9mIGJ5S2V5Wyd0aHVtYm5haWxfaW1hZ2Vfb3JpZ2luYWwnXSA9PT0gJ3N0cmluZydcbiAgICAgID8gKGJ5S2V5Wyd0aHVtYm5haWxfaW1hZ2Vfb3JpZ2luYWwnXSBhcyBzdHJpbmcpXG4gICAgICA6IG51bGwpID8/XG4gICAgKHR5cGVvZiBieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xuICAgICAgPyAoYnlLZXlbJ3N1bW1hcnlfcGhvdG9faW1hZ2Vfb3JpZ2luYWwnXSBhcyBzdHJpbmcpXG4gICAgICA6IG51bGwpO1xuICBpZiAoIW5hbWUgJiYgIXRpdGxlICYmICFkZXNjcmlwdGlvbiAmJiAhaW1hZ2VVcmwpIHJldHVybiBudWxsO1xuICByZXR1cm4ge1xuICAgIG5hbWUsXG4gICAgY2FyZF91cmw6IGNhcmRVcmwsXG4gICAgdmVuZG9yX3VybDogdmVuZG9yVXJsLFxuICAgIHRpdGxlLFxuICAgIGRlc2NyaXB0aW9uLFxuICAgIGltYWdlX3VybDogaW1hZ2VVcmwsXG4gIH07XG59XG4iLCAiLyoqXG4gKiBMaWdodHdlaWdodCBVTElELWxpa2UgaWQgZ2VuZXJhdG9yOiAyNi1jaGFyYWN0ZXIgQ3JvY2tmb3JkIGJhc2UzMiBzdHJpbmdcbiAqIG9mICh0aW1lc3RhbXBfbXMgfHwgcmFuZG9tbmVzcykuIEdvb2QgZW5vdWdoIGZvciBydW4gaWRlbnRpZmllcnMgd2l0aG91dFxuICogcHVsbGluZyBpbiBhIHJlYWwgVUxJRCBkZXBlbmRlbmN5LlxuICovXG5cbmNvbnN0IEFMUEhBQkVUID0gJzAxMjM0NTY3ODlBQkNERUZHSEpLTU5QUVJTVFZXWFlaJzsgLy8gQ3JvY2tmb3JkXG5cbmV4cG9ydCBmdW5jdGlvbiBuZXdSdW5JZCgpOiBzdHJpbmcge1xuICBjb25zdCB0cyA9IERhdGUubm93KCk7XG4gIGxldCB0c1BhcnQgPSAnJztcbiAgbGV0IHQgPSB0cztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDsgaSsrKSB7XG4gICAgdHNQYXJ0ID0gKEFMUEhBQkVUW3QgJSAzMl0gPz8gJzAnKSArIHRzUGFydDtcbiAgICB0ID0gTWF0aC5mbG9vcih0IC8gMzIpO1xuICB9XG4gIGNvbnN0IHJhbmQgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEwKSk7XG4gIGxldCByYW5kUGFydCA9ICcnO1xuICBmb3IgKGNvbnN0IGIgb2YgcmFuZCkgcmFuZFBhcnQgKz0gQUxQSEFCRVRbYiAlIDMyXSA/PyAnMCc7XG4gIHJldHVybiB0c1BhcnQgKyByYW5kUGFydDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNob3J0UnVuSWQoaWQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBpZC5zbGljZSgtOCk7XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q2F0ZWdvcnksIEFjY291bnRDb25maWcgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBNaW5pbWFsIHBhcnNlciBmb3IgdGhlIHN0cmljdCBzaGFwZSB1c2VkIGJ5IGBjb25maWcvYWNjb3VudHMueWFtbGA6XG4gKlxuICogICBhY2NvdW50czpcbiAqICAgICAtIGhhbmRsZTogREhTZ292XG4gKiAgICAgICBsYWJlbDogRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eVxuICogICAgICAgY2F0ZWdvcnk6IGNvcmVcbiAqXG4gKiBXZSBkZWxpYmVyYXRlbHkgZG9uJ3QgcHVsbCBpbiBhIGZ1bGwgWUFNTCBsaWJyYXJ5IFx1MjAxNCB3ZSBjb250cm9sIGJvdGggZW5kcyBvZlxuICogdGhpcyBmaWxlLCBhbmQgYSBzbWFsbCBwYXJzZXIgaXMgZWFzaWVyIHRvIGF1ZGl0IHRoYW4gdGhlIGFsdGVybmF0aXZlcy5cbiAqIFVua25vd24ga2V5cyBhbmQgY29tbWVudHMgYXJlIHRvbGVyYXRlZDsgbWFsZm9ybWVkIGxpbmVzIGFyZSBza2lwcGVkLlxuICpcbiAqIEVudHJpZXMgbWlzc2luZyBhIGBjYXRlZ29yeWAgZGVmYXVsdCB0byBgY29yZWAgZm9yIGJhY2t3YXJkIGNvbXBhdGliaWxpdHlcbiAqIHdpdGggdGhlIHByZS1jYXRlZ29yaXphdGlvbiBmaWxlIHNoYXBlLlxuICovXG5jb25zdCBWQUxJRF9DQVRFR09SSUVTOiBSZWFkb25seVNldDxBY2NvdW50Q2F0ZWdvcnk+ID0gbmV3IFNldChbXG4gICdjb3JlJyxcbiAgJ2dvdmVybm1lbnQnLFxuICAnb2ZmaWNpYWxzJyxcbiAgJ3B1YmxpY19maWd1cmVzJyxcbiAgJ3B1YmxpYycsXG5dKTtcblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQWNjb3VudHNZYW1sKHRleHQ6IHN0cmluZyk6IEFjY291bnRDb25maWdbXSB7XG4gIGNvbnN0IGFjY291bnRzOiBBY2NvdW50Q29uZmlnW10gPSBbXTtcbiAgbGV0IGN1cnJlbnQ6IFBhcnRpYWw8QWNjb3VudENvbmZpZz4gPSB7fTtcbiAgbGV0IGluQWNjb3VudHMgPSBmYWxzZTtcbiAgY29uc3QgZmx1c2ggPSAoKSA9PiB7XG4gICAgaWYgKGN1cnJlbnQuaGFuZGxlICYmIGN1cnJlbnQubGFiZWwpIHtcbiAgICAgIGlmICghY3VycmVudC5jYXRlZ29yeSkgY3VycmVudC5jYXRlZ29yeSA9ICdjb3JlJztcbiAgICAgIGFjY291bnRzLnB1c2goY3VycmVudCBhcyBBY2NvdW50Q29uZmlnKTtcbiAgICB9XG4gIH07XG4gIGZvciAoY29uc3QgcmF3TGluZSBvZiB0ZXh0LnNwbGl0KCdcXG4nKSkge1xuICAgIGNvbnN0IGxpbmUgPSBzdHJpcENvbW1lbnRzKHJhd0xpbmUpO1xuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gJycpIGNvbnRpbnVlO1xuICAgIGlmICgvXmFjY291bnRzXFxzKjovLnRlc3QobGluZSkpIHtcbiAgICAgIGluQWNjb3VudHMgPSB0cnVlO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICghaW5BY2NvdW50cykgY29udGludWU7XG5cbiAgICBjb25zdCBpdGVtTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKi1cXHMqaGFuZGxlXFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoaXRlbU1hdGNoKSB7XG4gICAgICBmbHVzaCgpO1xuICAgICAgY3VycmVudCA9IHsgaGFuZGxlOiB1bnF1b3RlKGl0ZW1NYXRjaFsxXSA/PyAnJykgfTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBoYW5kbGVPbmx5ID0gbGluZS5tYXRjaCgvXlxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChoYW5kbGVPbmx5ICYmICFsaW5lLmluY2x1ZGVzKCctJykpIHtcbiAgICAgIGZsdXNoKCk7XG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaGFuZGxlT25seVsxXSA/PyAnJykgfTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBsYWJlbE1hdGNoID0gbGluZS5tYXRjaCgvXlxccypsYWJlbFxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGxhYmVsTWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcbiAgICAgIGN1cnJlbnQubGFiZWwgPSB1bnF1b3RlKGxhYmVsTWF0Y2hbMV0gPz8gJycpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IGNhdGVnb3J5TWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmNhdGVnb3J5XFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoY2F0ZWdvcnlNYXRjaCAmJiBjdXJyZW50LmhhbmRsZSkge1xuICAgICAgY29uc3QgcmF3ID0gdW5xdW90ZShjYXRlZ29yeU1hdGNoWzFdID8/ICcnKTtcbiAgICAgIGN1cnJlbnQuY2F0ZWdvcnkgPSBWQUxJRF9DQVRFR09SSUVTLmhhcyhyYXcgYXMgQWNjb3VudENhdGVnb3J5KVxuICAgICAgICA/IChyYXcgYXMgQWNjb3VudENhdGVnb3J5KVxuICAgICAgICA6ICdjb3JlJztcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgfVxuICBmbHVzaCgpO1xuICByZXR1cm4gYWNjb3VudHMuZmlsdGVyKChhKSA9PiBhLmhhbmRsZS5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gc3RyaXBDb21tZW50cyhsaW5lOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBOYWl2ZSBidXQgYWRlcXVhdGUgZm9yIG91ciBmb3JtYXQ6IHN0cmlwIGV2ZXJ5dGhpbmcgYWZ0ZXIgYSBgI2AgdGhhdCBpc24ndFxuICAvLyBpbnNpZGUgcXVvdGVzLiBPdXIgY29uZmlnIG5ldmVyIHVzZXMgaW5saW5lIHN0cmluZ3Mgd2l0aCBgI2AuXG4gIGNvbnN0IGlkeCA9IGxpbmUuaW5kZXhPZignIycpO1xuICByZXR1cm4gaWR4ID09PSAtMSA/IGxpbmUgOiBsaW5lLnNsaWNlKDAsIGlkeCk7XG59XG5cbmZ1bmN0aW9uIHVucXVvdGUoczogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgdHJpbW1lZCA9IHMudHJpbSgpO1xuICBpZiAoXG4gICAgKHRyaW1tZWQuc3RhcnRzV2l0aCgnXCInKSAmJiB0cmltbWVkLmVuZHNXaXRoKCdcIicpKSB8fFxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoXCInXCIpICYmIHRyaW1tZWQuZW5kc1dpdGgoXCInXCIpKVxuICApIHtcbiAgICByZXR1cm4gdHJpbW1lZC5zbGljZSgxLCAtMSk7XG4gIH1cbiAgcmV0dXJuIHRyaW1tZWQ7XG59XG4iLCAiLyoqXG4gKiBiYWNrZ3JvdW5kLnRzIFx1MjAxNCBleHRlbnNpb24gc2VydmljZSB3b3JrZXIuXG4gKlxuICogT3ducyB0aGUgY2FwdHVyZSBwaXBlbGluZTogcmVjZWl2ZXMgYGdyYXBocWwtY2FwdHVyZWAgbWVzc2FnZXMgZnJvbSB0aGVcbiAqIGNvbnRlbnQgc2NyaXB0LCBub3JtYWxpemVzIHRoZW0sIGFjY3VtdWxhdGVzIHBlci1oYW5kbGUgcnVuIGJ1ZmZlcnMgaW5cbiAqIGBicm93c2VyLnN0b3JhZ2UubG9jYWxgLCBhbmQgY29tbWl0cyB0aGVtIHRvIHRoZSBjb25maWd1cmVkIEdpdEh1YiByZXBvXG4gKiB2aWEgdGhlIENvbnRlbnRzIEFQSS5cbiAqXG4gKiBTZXJ2aWNlIHdvcmtlcnMgaW4gTVYzIG1heSBiZSBldmljdGVkIGF0IGFueSB0aW1lLCBzbyBhbGwgY3JpdGljYWwgc3RhdGVcbiAqIGxpdmVzIGluIHN0b3JhZ2UgKG5ldmVyIG1vZHVsZS1zY29wZSkuIE9uIGV2ZXJ5IHdha2Ugd2UgcmUtZGVyaXZlIHdoYXQgd2VcbiAqIG5lZWQ7IHBlbmRpbmcgZmx1c2hlcyBhcmUgZHJpdmVuIGJ5IGBicm93c2VyLmFsYXJtc2AgcmF0aGVyIHRoYW4gdGltZXJzLlxuICovXG5cbmltcG9ydCB7XG4gIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gIEFVVE9fU0NST0xMX01JTl9TRUMsXG4gIEZBTExCQUNLX0FDQ09VTlRTLFxuICBGTFVTSF9BTEFSTV9NSU5VVEVTLFxuICBGTFVTSF9JRExFX01TLFxuICBGTFVTSF9UV0VFVF9USFJFU0hPTEQsXG4gIFBST0ZJTEVfRU5EUE9JTlRTLFxuICBUV0VFVF9FTkRQT0lOVFMsXG4gIFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TLFxufSBmcm9tICcuL2xpYi9jb25maWcuanMnO1xuaW1wb3J0IHsgR2l0SHViQ2xpZW50LCBHaXRIdWJFcnJvciwgdG9CYXNlNjQgfSBmcm9tICcuL2xpYi9naXRodWIuanMnO1xuaW1wb3J0IHsgZGVzY3JpYmVFcnJvciwgZXJyb3IgYXMgbG9nRXJyLCBpbmZvLCBzZXRCcm9hZGNhc3Rlciwgd2FybiB9IGZyb20gJy4vbGliL2xvZ2dlci5qcyc7XG5pbXBvcnQgeyBmaWx0ZXJSZWxhdGVkLCBub3JtYWxpemUgfSBmcm9tICcuL2xpYi9ub3JtYWxpemUuanMnO1xuaW1wb3J0IHsgbmV3UnVuSWQsIHNob3J0UnVuSWQgfSBmcm9tICcuL2xpYi9ydW5pZHMuanMnO1xuaW1wb3J0IHtcbiAgYnVtcENvdW50ZXIsXG4gIGNsZWFyQWN0aXZpdHksXG4gIGNsZWFyQWxsLFxuICBjbGVhclJ1bkJ1ZmZlcixcbiAgZGVxdWV1ZU1lZGlhQ3Jhd2wsXG4gIGRlcXVldWVSZWZldGNoLFxuICBlbmdhZ2VtZW50U2lnLFxuICBlbnF1ZXVlTWVkaWFDcmF3bCxcbiAgZW5xdWV1ZVJlZmV0Y2gsXG4gIGdldEFjY291bnRzLFxuICBnZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxuICBnZXRBY3Rpdml0eSxcbiAgZ2V0QXV0b1Njcm9sbFNlc3Npb24sXG4gIGdldENvbW1pdHRlZEluZGV4LFxuICBnZXRDb25uZWN0aW9uLFxuICBnZXRDb3VudGVycyxcbiAgZ2V0TWVkaWFDcmF3bFF1ZXVlLFxuICBnZXRNZWRpYUNyYXdsU2Vzc2lvbixcbiAgZ2V0UmVmZXRjaFF1ZXVlLFxuICBnZXRSZWZldGNoU2Vzc2lvbixcbiAgZ2V0UnVuQnVmZmVyLFxuICBnZXRSdW5CdWZmZXJzLFxuICBnZXRTZXR0aW5ncyxcbiAgaXNDb21taXR0ZWQsXG4gIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsLFxuICBuZXh0TWVkaWFDcmF3bFRhcmdldCxcbiAgbmV4dFJlZmV0Y2hUYXJnZXQsXG4gIHBydW5lQ29tbWl0dGVkSW5kZXgsXG4gIHB1cmdlVW5yZWxhdGVkU3RhdGUsXG4gIHJlZmV0Y2hRdWV1ZVRvdGFsLFxuICBzZXRBY2NvdW50cyxcbiAgc2V0QWNjb3VudHNSZWZyZXNoZWRBdCxcbiAgc2V0QXV0b1Njcm9sbFNlc3Npb24sXG4gIHNldEJ1ZmZlcmVkQ291bnQsXG4gIHNldENvbW1pdHRlZEluZGV4LFxuICBzZXRDb25uZWN0aW9uLFxuICBzZXRNZWRpYUNyYXdsU2Vzc2lvbixcbiAgc2V0UmVmZXRjaFNlc3Npb24sXG4gIHNldFJ1bkJ1ZmZlcixcbiAgdHlwZSBSdW5CdWZmZXIsXG4gIHVwZGF0ZVNldHRpbmdzLFxufSBmcm9tICcuL2xpYi9zdG9yYWdlLmpzJztcbmltcG9ydCB0eXBlIHtcbiAgQ2Fub25pY2FsVHdlZXQsXG4gIENhcHR1cmVQYXlsb2FkLFxuICBDb25uZWN0aW9uU3RhdGUsXG4gIEV4dGVuc2lvblN0YXRlLFxuICBMb2dFdmVudCxcbiAgUXVhcmFudGluZVBheWxvYWQsXG4gIFJ1bnRpbWVNZXNzYWdlLFxuICBTZWVuUGF5bG9hZCxcbiAgU2V0dGluZ3MsXG59IGZyb20gJy4vbGliL3R5cGVzLmpzJztcbmltcG9ydCB7IHBhcnNlQWNjb3VudHNZYW1sIH0gZnJvbSAnLi9saWIveWFtbC5qcyc7XG5cbmNvbnN0IEVYVF9WRVJTSU9OID0gYnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbjtcblxuc2V0QnJvYWRjYXN0ZXIoKGV2OiBMb2dFdmVudCkgPT4ge1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnbG9nLWV2ZW50JywgZXZlbnQ6IGV2IH0pLmNhdGNoKCgpID0+IHt9KTtcbn0pO1xuXG4vLyAtLS0gV2FrZSBoYW5kbGVycyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5icm93c2VyLnJ1bnRpbWUub25JbnN0YWxsZWQuYWRkTGlzdGVuZXIoYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBpbmZvKCdleHRlbnNpb24gaW5zdGFsbGVkJywgeyB2ZXJzaW9uOiBFWFRfVkVSU0lPTiB9KTtcbiAgYXdhaXQgb25XYWtlKCdpbnN0YWxsJyk7XG59KTtcblxuYnJvd3Nlci5ydW50aW1lLm9uU3RhcnR1cC5hZGRMaXN0ZW5lcigoKSA9PiB7XG4gIHZvaWQgb25XYWtlKCdzdGFydHVwJyk7XG59KTtcblxuLy8gRm9yY2UgYXQgbGVhc3Qgb25lIHdha2UgdG8gcmVnaXN0ZXIgYWxhcm1zIC8gdmVyaWZ5IGNvbm5lY3Rpb24uXG52b2lkIG9uV2FrZSgnbW9kdWxlLWxvYWQnKTtcblxuYXN5bmMgZnVuY3Rpb24gb25XYWtlKHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgYXdhaXQgZW5zdXJlQWxhcm1zKCk7XG4gICAgYXdhaXQgZW5zdXJlQXV0b1Njcm9sbEFsYXJtKCk7XG4gICAgYXdhaXQgZmx1c2hPcnBoYW5lZEJ1ZmZlcnNJZlN0YWxlKCk7XG4gICAgYXdhaXQgcmVpbmplY3RJbnRvT3BlblRhYnMoKTtcbiAgICAvLyBEcm9wIGRlZHVwLWluZGV4IGVudHJpZXMgb2xkZXIgdGhhbiAzMCBkYXlzIHNvIHRoZSBzdG9yZSBkb2Vzbid0XG4gICAgLy8gZ3JvdyB1bmJvdW5kZWQgb3ZlciBtb250aHMgb2YgY2FwdHVyZSBzZXNzaW9ucy5cbiAgICBjb25zdCBwcnVuZWQgPSBhd2FpdCBwcnVuZUNvbW1pdHRlZEluZGV4KDMwICogMjQgKiA2MCAqIDYwICogMTAwMCk7XG4gICAgaWYgKHBydW5lZCA+IDApIGF3YWl0IGluZm8oJ3BydW5lZCBjb21taXR0ZWQgaW5kZXgnLCB7IHBydW5lZCB9KTtcbiAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgaWYgKHNldHRpbmdzLnBhdCAmJiBzZXR0aW5ncy5vd25lciAmJiBzZXR0aW5ncy5yZXBvKSB7XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgICAgIGF3YWl0IHJlZnJlc2hBY2NvdW50c0xpc3QoZmFsc2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgICBsb2dpbjogbnVsbCxcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBpbmZvKCdleHRlbnNpb24gYXdha2U7IHNldHRpbmdzIGluY29tcGxldGUnLCB7IHJlYXNvbiB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IGxvZ0Vycignd2FrZSBmYWlsZWQnLCB7IHJlYXNvbiwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICB9XG59XG5cbi8qKlxuICogUmUtaW5qZWN0IHRoZSBNQUlOLXdvcmxkIHBhZ2UtaG9vayArIGlzb2xhdGVkLXdvcmxkIGNvbnRlbnQgc2NyaXB0IGludG9cbiAqIGV2ZXJ5IGFscmVhZHktb3BlbiB4LmNvbSAvIHR3aXR0ZXIuY29tIHRhYi5cbiAqXG4gKiBNYW5pZmVzdCBjb250ZW50X3NjcmlwdHMgb25seSBpbmplY3Qgb24gZnJlc2ggbmF2aWdhdGlvbiAocnVuX2F0OlxuICogZG9jdW1lbnRfc3RhcnQpLiBXaGVuIHRoZSB1c2VyIHJlbG9hZHMgdGhlIGV4dGVuc2lvbiB3aGlsZSBYIHRhYnMgYXJlXG4gKiBvcGVuLCB0aG9zZSB0YWJzIGtlZXAgdGhlaXIgY29udGVudCBzY3JpcHRzIGJ1dCBuZXZlciBnZXQgYSBuZXcgcGFnZS1ob29rXG4gKiBcdTIwMTQgc28gZmV0Y2gvWEhSIHN0YXlzIHVucGF0Y2hlZCBhbmQgY2FwdHVyZXMgc2lsZW50bHkgZmFpbC4gRG9pbmcgdGhpcyBvblxuICogZXZlcnkgd2FrZSBpcyBpZGVtcG90ZW50IChwYWdlLWhvb2sgaGFzIGEgVEFHIGd1YXJkKSBhbmQgY2hlYXAuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIHJlaW5qZWN0SW50b09wZW5UYWJzKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjb3VsZCBub3QgcXVlcnkgb3BlbiB0YWJzJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHRhYnMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcbiAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIGNvbnRpbnVlO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgZmlsZXM6IFsncGFnZS1ob29rLmpzJ10sXG4gICAgICAgIC8vIEZpcmVmb3ggMTI4KyBzdXBwb3J0cyB0aGUgTUFJTiBleGVjdXRpb24gd29ybGQgdmlhIHRoaXMgQVBJLCBidXRcbiAgICAgICAgLy8gdGhlIEB0eXBlcy9maXJlZm94LXdlYmV4dC1icm93c2VyIHBhY2thZ2Ugd2UncmUgb24gc3RpbGwgb25seVxuICAgICAgICAvLyBkZWNsYXJlcyAnSVNPTEFURUQnLiBDYXN0IHRocm91Z2ggdGhlIGxpdGVyYWwgdW5pb24uXG4gICAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICAgIGZpbGVzOiBbJ2NvbnRlbnQuanMnXSxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgaW5mbygncmUtaW5qZWN0ZWQgc2NyaXB0cyBpbnRvIG9wZW4gdGFiJywge1xuICAgICAgICB0YWJJZDogdGFiLmlkLFxuICAgICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCA/PyAnJyksXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIC8vIFNvbWUgdGFicyAoYWJvdXQ6IHBhZ2VzLCBkaXNjYXJkZWQgdGFicywgbWlkLW5hdmlnYXRpb24pIHJlamVjdFxuICAgICAgLy8gZXhlY3V0ZVNjcmlwdC4gVGhhdCdzIGZpbmUgXHUyMDE0IHdlJ2xsIGNhdGNoIHRoZW0gb24gdGhlIG5leHQgd2FrZSBvclxuICAgICAgLy8gd2hlbiB0aGUgdXNlciBuYXZpZ2F0ZXMuXG4gICAgICBhd2FpdCB3YXJuKCdyZS1pbmplY3QgZmFpbGVkIGZvciB0YWI7IGNvbnRpbnVpbmcnLCB7XG4gICAgICAgIHRhYklkOiB0YWIuaWQsXG4gICAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsID8/ICcnKSxcbiAgICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUFsYXJtcygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ2ZsdXNoLXN3ZWVwJyk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd2ZXJpZnktY29ubmVjdGlvbicpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jcmVhdGUoJ2ZsdXNoLXN3ZWVwJywgeyBwZXJpb2RJbk1pbnV0ZXM6IEZMVVNIX0FMQVJNX01JTlVURVMgfSk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgndmVyaWZ5LWNvbm5lY3Rpb24nLCB7XG4gICAgcGVyaW9kSW5NaW51dGVzOiBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyAvIDYwXzAwMCxcbiAgfSk7XG59XG5cbi8vIEZpcmVmb3ggTVYzIGFsYXJtcyBoYXZlIGEgMzBzIG1pbmltdW0gcGVyaW9kLCBidXQgd2Ugd2FudCBzdWItbWludXRlXG4vLyBzY3JvbGxpbmcuIFRoZSBhdXRvLXNjcm9sbCBsb29wIHRoZXJlZm9yZSBydW5zIG9uIGFuIGluLVNXIGludGVydmFsLlxuLy8gYGF1dG9TY3JvbGxTZXNzaW9uYCBpbiBzdG9yYWdlIGlzIHRoZSBzb3VyY2Ugb2YgdHJ1dGggZm9yIHdoZXRoZXIgdGhlIGxvb3Bcbi8vIGlzIG1lYW50IHRvIGJlIHJ1bm5pbmcgXHUyMDE0IHRoZSB0aW1lciBpcyBqdXN0IHRoZSBsb2NhbCBleGVjdXRpb24gYXJtLlxubGV0IGF1dG9TY3JvbGxUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbi8vIFdhaXQtZm9yLWluZ2VzdCB0aW1lb3V0OiBpZiBhIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCB0YWIgbmF2aWdhdGlvbiBkb2Vzbid0XG4vLyBwcm9kdWNlIGFuIGluZ2VzdGVkIGNhcHR1cmUgd2l0aGluIHRoaXMgbWFueSBtcywgYWR2YW5jZSBhbnl3YXkgc28gd2Vcbi8vIGRvbid0IGRlYWRsb2NrIG9uIGRlbGV0ZWQgLyA0MDQgLyBwYXl3YWxsZWQgdHdlZXRzLlxuY29uc3QgSU5HRVNUX1dBSVRfTVMgPSAyNV8wMDA7XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUF1dG9TY3JvbGxBbGFybSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gV2FzIHRoZSBsb29wIHJ1bm5pbmcgYmVmb3JlIHRoZSBTVyBldmljdGlvbj8gUmUtYXJtIGlmIHNvLlxuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmIChzZXNzICE9PSBudWxsICYmIHMuZW5hYmxlZCAhPT0gZmFsc2UpIHtcbiAgICBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xuICB9IGVsc2Uge1xuICAgIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTogdm9pZCB7XG4gIGlmIChhdXRvU2Nyb2xsVGltZXIgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKGF1dG9TY3JvbGxUaW1lcik7XG4gICAgYXV0b1Njcm9sbFRpbWVyID0gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBhcm1BdXRvU2Nyb2xsVGltZXIoaW50ZXJ2YWxTZWM6IG51bWJlcik6IHZvaWQge1xuICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICBjb25zdCBjbGFtcGVkID0gTWF0aC5taW4oXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKGludGVydmFsU2VjKSlcbiAgKTtcbiAgYXV0b1Njcm9sbFRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgYXV0b1Njcm9sbFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ2F1dG8tc2Nyb2xsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICB9KTtcbiAgfSwgY2xhbXBlZCAqIDEwMDApO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydEF1dG9TY3JvbGxMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oe1xuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNjcm9sbENvdW50OiAwLFxuICAgIGluZ2VzdGVkQ291bnQ6IDAsXG4gICAgZXhwYW5kZWRDb3VudDogMCxcbiAgfSk7XG4gIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XG4gIGF3YWl0IGluZm8oJ2F1dG8tc2Nyb2xsIGxvb3Agc3RhcnRlZCcsIHsgaW50ZXJ2YWxfc2VjOiBzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyB9KTtcbiAgLy8gRmlyZSBvbmUgaW1tZWRpYXRlIHRpY2sgc28gdGhlIHVzZXIgc2VlcyBtb3Rpb24gcmlnaHQgYXdheS5cbiAgdm9pZCBhdXRvU2Nyb2xsVGljaygpO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdhdXRvLXNjcm9sbCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBzY3JvbGxzOiBzZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxuICAgIGluZ2VzdGVkOiBzZXNzPy5pbmdlc3RlZENvdW50ID8/IDAsXG4gICAgZXhwYW5kZWQ6IHNlc3M/LmV4cGFuZGVkQ291bnQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGF1dG9TY3JvbGxUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdhdXRvLXNjcm9sbDogdGFiIHF1ZXJ5IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBsZXQgc2Nyb2xsQ291bnQgPSAwO1xuICBsZXQgZXhwYW5kZWRDb3VudCA9IDA7XG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcbiAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIGNvbnRpbnVlO1xuICAgIGlmICh0YWIuZGlzY2FyZGVkKSBjb250aW51ZTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0cyA9IChhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgICAvLyBDYXN0OiB0aGUgQHR5cGVzL2ZpcmVmb3gtd2ViZXh0LWJyb3dzZXIgdHlwZSBzaWduYXR1cmUgaW5zaXN0c1xuICAgICAgICAvLyBgZnVuY2AgcmV0dXJucyB2b2lkLCBidXQgdGhlIEFQSSBhY3R1YWxseSBzdXJmYWNlcyB0aGUgcmV0dXJuXG4gICAgICAgIC8vIHZhbHVlIHZpYSBgcmVzdWx0WzBdLnJlc3VsdGAuIFdlIHVzZSB0aGF0IGZvciB0aGUgZXhwYW5kIGNvdW50LlxuICAgICAgICBmdW5jOiAoKCkgPT4ge1xuICAgICAgICAgIC8vIDEuIENsaWNrIGFueSB2aXNpYmxlIFwiU2hvdyBtb3JlXCIgbGlua3MgaW4gbG9uZy10d2VldCBib2RpZXMgc28gWFxuICAgICAgICAgIC8vICAgIGlubGluZXMgdGhlIG5vdGVfdHdlZXQgYm9keSBhbmQgb3VyIHBhZ2UtaG9vayBjYXB0dXJlcyB0aGVcbiAgICAgICAgICAvLyAgICBmdWxsIHRleHQgd2l0aG91dCB0aGUgcmVmZXRjaCBkZXRvdXIuIFRyeSBzZXZlcmFsIHNlbGVjdG9yc1xuICAgICAgICAgIC8vICAgIGJlY2F1c2UgWCByb3RhdGVzIHRoZSB0ZXN0aWQgbGFiZWwgc2VtaS1yZWd1bGFybHkuXG4gICAgICAgICAgY29uc3QgU0hPV19NT1JFX1NFTEVDVE9SUyA9IFtcbiAgICAgICAgICAgICdbZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcbiAgICAgICAgICAgICdidXR0b25bZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcbiAgICAgICAgICAgICdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0gW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcbiAgICAgICAgICBdO1xuICAgICAgICAgIGNvbnN0IGNsaWNrZWQgPSBuZXcgU2V0PEVsZW1lbnQ+KCk7XG4gICAgICAgICAgbGV0IGV4cGFuZGVkID0gMDtcbiAgICAgICAgICBmb3IgKGNvbnN0IHNlbCBvZiBTSE9XX01PUkVfU0VMRUNUT1JTKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGVsIG9mIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWwpKSkge1xuICAgICAgICAgICAgICBpZiAoY2xpY2tlZC5oYXMoZWwpKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgLy8gQ29uZmlybSBpdCdzIGFjdHVhbGx5IHRoZSBzaG93LW1vcmUgYWZmb3JkYW5jZSBieSB0ZXh0LlxuICAgICAgICAgICAgICBjb25zdCB0ID0gKGVsLnRleHRDb250ZW50IHx8ICcnKS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgaWYgKHQgIT09ICdzaG93IG1vcmUnICYmIHQgIT09ICdzaG93IHRoaXMgdGhyZWFkJykgY29udGludWU7XG4gICAgICAgICAgICAgIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICAgICAgaWYgKHJlY3Qud2lkdGggPT09IDAgfHwgcmVjdC5oZWlnaHQgPT09IDApIGNvbnRpbnVlO1xuICAgICAgICAgICAgICBjbGlja2VkLmFkZChlbCk7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgICAgICAgICAgICAgIGV4cGFuZGVkICs9IDE7XG4gICAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgIC8vIGlnbm9yZVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIDIuIFNjcm9sbCB0aGUgcGFnZS4gRGlzcGF0Y2ggRW5kIGtleSBmaXJzdCBzaW5jZSBtYW55IFggc3VyZmFjZXNcbiAgICAgICAgICAvLyAgICAobGlzdHMsIHNlYXJjaCwgcmVwbGllcykgYmluZCBwYWdpbmF0aW9uIHRyaWdnZXJzIHRvIGl0IHZpYVxuICAgICAgICAgIC8vICAgIFJlYWN0IGhhbmRsZXJzOyB0aGVuIGV4cGxpY2l0bHkgc2Nyb2xsIHRoZSBkb2N1bWVudC5cbiAgICAgICAgICBjb25zdCBvcHRzOiBLZXlib2FyZEV2ZW50SW5pdCA9IHtcbiAgICAgICAgICAgIGtleTogJ0VuZCcsXG4gICAgICAgICAgICBjb2RlOiAnRW5kJyxcbiAgICAgICAgICAgIGtleUNvZGU6IDM1LFxuICAgICAgICAgICAgd2hpY2g6IDM1LFxuICAgICAgICAgICAgYnViYmxlczogdHJ1ZSxcbiAgICAgICAgICAgIGNhbmNlbGFibGU6IHRydWUsXG4gICAgICAgICAgfTtcbiAgICAgICAgICBjb25zdCBmb2N1cyA9IChkb2N1bWVudC5hY3RpdmVFbGVtZW50IGFzIEhUTUxFbGVtZW50IHwgbnVsbCkgPz8gZG9jdW1lbnQuYm9keTtcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXlkb3duJywgb3B0cykpO1xuICAgICAgICAgIGZvY3VzLmRpc3BhdGNoRXZlbnQobmV3IEtleWJvYXJkRXZlbnQoJ2tleXVwJywgb3B0cykpO1xuICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbyh7XG4gICAgICAgICAgICB0b3A6IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxIZWlnaHQsXG4gICAgICAgICAgICBiZWhhdmlvcjogJ2F1dG8nLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiB7IGV4cGFuZGVkIH07XG4gICAgICAgIH0pIGFzICgpID0+IHZvaWQsXG4gICAgICB9KSkgYXMgQXJyYXk8eyByZXN1bHQ/OiB1bmtub3duIH0+O1xuICAgICAgc2Nyb2xsQ291bnQgKz0gMTtcbiAgICAgIGNvbnN0IHIgPSByZXN1bHRzWzBdPy5yZXN1bHQgYXMgeyBleHBhbmRlZD86IG51bWJlciB9IHwgdW5kZWZpbmVkO1xuICAgICAgaWYgKHIgJiYgdHlwZW9mIHIuZXhwYW5kZWQgPT09ICdudW1iZXInKSBleHBhbmRlZENvdW50ICs9IHIuZXhwYW5kZWQ7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBUYWJzIHRoYXQgZGlzYWxsb3cgc2NyaXB0aW5nIChhYm91dDosIGRpc2NhcmRlZCwgbWlkLW5hdmlnYXRpb24pXG4gICAgICAvLyBqdXN0IGdldCBza2lwcGVkIFx1MjAxNCB0aGV5J2xsIGJlIGVsaWdpYmxlIG9uIGEgbGF0ZXIgdGljay5cbiAgICB9XG4gIH1cbiAgaWYgKHNjcm9sbENvdW50ID4gMCkge1xuICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgIGlmIChzZXNzICE9PSBudWxsKSB7XG4gICAgICBzZXNzLnNjcm9sbENvdW50ICs9IHNjcm9sbENvdW50O1xuICAgICAgc2Vzcy5leHBhbmRlZENvdW50ICs9IGV4cGFuZGVkQ291bnQ7XG4gICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzZXNzKTtcbiAgICAgIC8vIE5vIGJyb2FkY2FzdCBvbiBldmVyeSB0aWNrIFx1MjAxNCB0aGUgMTVzIHNpZGViYXIgcmVmcmVzaCBwaWNrcyBpdCB1cC5cbiAgICB9XG4gIH1cbn1cblxuYnJvd3Nlci5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcigoYWxhcm0pID0+IHtcbiAgaWYgKGFsYXJtLm5hbWUgPT09ICdmbHVzaC1zd2VlcCcpIHtcbiAgICB2b2lkIGZsdXNoSWRsZUJ1ZmZlcnMoKTtcbiAgfSBlbHNlIGlmIChhbGFybS5uYW1lID09PSAndmVyaWZ5LWNvbm5lY3Rpb24nKSB7XG4gICAgdm9pZCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgfVxuICAvLyByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcHJldmlvdXNseSByYW4gdmlhIGFsYXJtczsgdGhleSBub3cgdXNlXG4gIC8vIHNldEludGVydmFsIHRvIGVzY2FwZSB0aGUgMzBzIGFsYXJtIGZsb29yLiBMZWF2ZSB0aGUgbmFtZXMgbGlzdGVkXG4gIC8vIG5vd2hlcmUgc28gYW55IG9ycGhhbmVkIGFsYXJtcyAoZnJvbSBvbGRlciBidWlsZHMpIGp1c3Qgbm8tb3AuXG59KTtcblxuLy8gLS0tIFRvb2xiYXIgYWN0aW9uOiB0b2dnbGUgdGhlIHNpZGViYXIgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuaWYgKGJyb3dzZXIuYWN0aW9uPy5vbkNsaWNrZWQpIHtcbiAgYnJvd3Nlci5hY3Rpb24ub25DbGlja2VkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci5zaWRlYmFyQWN0aW9uLnRvZ2dsZSgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgLy8gRmFsbGJhY2s6IG9wZW4gb3B0aW9ucyBpZiBzaWRlYmFyIGNhbid0IGJlIHRvZ2dsZWQuXG4gICAgICBhd2FpdCB3YXJuKCdzaWRlYmFyIHRvZ2dsZSBmYWlsZWQ7IG9wZW5pbmcgb3B0aW9ucycsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgfVxuICB9KTtcbn1cblxuLy8gLS0tIFJ1bnRpbWUgbWVzc2FnZSBkaXNwYXRjaCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24sIF9zZW5kZXIpID0+IHtcbiAgaWYgKCFpc1J1bnRpbWVNZXNzYWdlKG1zZykpIHJldHVybiB1bmRlZmluZWQ7XG4gIHJldHVybiBoYW5kbGVNZXNzYWdlKG1zZykuY2F0Y2goKGVycikgPT4ge1xuICAgIHZvaWQgbG9nRXJyKCdtZXNzYWdlIGhhbmRsZXIgZmFpbGVkJywgeyB0eXBlOiBtc2cudHlwZSwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICAgIHRocm93IGVycjtcbiAgfSk7XG59KTtcblxuZnVuY3Rpb24gaXNSdW50aW1lTWVzc2FnZShtOiB1bmtub3duKTogbSBpcyBSdW50aW1lTWVzc2FnZSB7XG4gIHJldHVybiAhIW0gJiYgdHlwZW9mIG0gPT09ICdvYmplY3QnICYmIHR5cGVvZiAobSBhcyB7IHR5cGU/OiB1bmtub3duIH0pLnR5cGUgPT09ICdzdHJpbmcnO1xufVxuXG4vKiogTWVzc2FnZXMgdGhhdCBkcml2ZSB0aGUgY2FwdHVyZSBwaXBlbGluZS4gV2hlbiB0aGUgbWFzdGVyIHN3aXRjaCBpcyBPRkZcbiAqIHdlIGlnbm9yZSB0aGVzZSBidXQgc3RpbGwgcmVzcG9uZCB0byBzdGF0dXMgLyBjb25maWd1cmF0aW9uIHF1ZXJpZXMuICovXG5jb25zdCBDQVBUVVJFX1BJUEVMSU5FX01FU1NBR0VTID0gbmV3IFNldDxSdW50aW1lTWVzc2FnZVsndHlwZSddPihbXG4gICdncmFwaHFsLWNhcHR1cmUnLFxuICAnY2FwdHVyZS1ub3cnLFxuICAnY2FwdHVyZS1hbGwnLFxuICAnY2FwdHVyZS10aGlzLXBhZ2UnLFxuICAnZmx1c2gtYWxsJyxcbiAgJ2ZsdXNoLWhhbmRsZScsXG4gICdzdGFydC1yZWZldGNoJyxcbiAgJ3N0YXJ0LW1lZGlhLWNyYXdsJyxcbiAgJ3N0YXJ0LWF1dG8tc2Nyb2xsJyxcbl0pO1xuXG5hc3luYyBmdW5jdGlvbiBpc0VuYWJsZWQoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICByZXR1cm4gcy5lbmFibGVkICE9PSBmYWxzZTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlTWVzc2FnZShtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTx1bmtub3duPiB7XG4gIC8vIE1hc3RlciBzd2l0Y2g6IHdoZW4gdGhlIHVzZXIgaGFzIHBhdXNlZCB0aGUgZXh0ZW5zaW9uIHdlIHN0aWxsIG5lZWRcbiAgLy8gdGhlIG1ldGEtY2hhbm5lbHMgKGdldC1zdGF0ZSwgdG9nZ2xlLWVuYWJsZWQsIG9wZW4tb3B0aW9ucywgXHUyMDI2KSBzbyB0aGVcbiAgLy8gc2lkZWJhciBzdGF5cyBmdW5jdGlvbmFsLCBidXQgYW55dGhpbmcgdGhhdCB3b3VsZCBhY3R1YWxseSBjYXB0dXJlLFxuICAvLyBjb21taXQsIG9yIGRyaXZlIGEgdGFiIGlzIGEgbm8tb3AuXG4gIGlmICghKGF3YWl0IGlzRW5hYmxlZCgpKSAmJiBDQVBUVVJFX1BJUEVMSU5FX01FU1NBR0VTLmhhcyhtc2cudHlwZSkpIHtcbiAgICByZXR1cm4geyBvazogdHJ1ZSwgcGF1c2VkOiB0cnVlIH07XG4gIH1cbiAgc3dpdGNoIChtc2cudHlwZSkge1xuICAgIGNhc2UgJ2dyYXBocWwtY2FwdHVyZSc6XG4gICAgICBhd2FpdCBvbkdyYXBocWxDYXB0dXJlKG1zZy5lbmRwb2ludCwgbXNnLnVybCwgbXNnLnJlc3BvbnNlKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnY29udGVudC1hbGl2ZSc6XG4gICAgICBhd2FpdCBpbmZvKCdjb250ZW50IHNjcmlwdCBhbGl2ZSBvbiBwYWdlJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ3BhZ2UtaG9vay1hY3RpdmUnOlxuICAgICAgYXdhaXQgaW5mbygncGFnZSBob29rIHBhdGNoZWQgZmV0Y2gvWEhSJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2xvZy1jb250ZW50LWV2ZW50JzpcbiAgICAgIGlmIChtc2cubGV2ZWwgPT09ICd3YXJuJykge1xuICAgICAgICBhd2FpdCB3YXJuKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfSBlbHNlIGlmIChtc2cubGV2ZWwgPT09ICdlcnJvcicpIHtcbiAgICAgICAgYXdhaXQgbG9nRXJyKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgaW5mbyhtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnZ2V0LXN0YXRlJzpcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS1ub3cnOlxuICAgICAgYXdhaXQgY2FwdHVyZU5vdyhtc2cuaGFuZGxlKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS1hbGwnOlxuICAgICAgYXdhaXQgY2FwdHVyZUFsbCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLXRoaXMtcGFnZSc6XG4gICAgICBhd2FpdCBjYXB0dXJlVGhpc1BhZ2UoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnZmx1c2gtYWxsJzpcbiAgICAgIGF3YWl0IGZsdXNoQWxsKCd1c2VyJyk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2ZsdXNoLWhhbmRsZSc6XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShtc2cuaGFuZGxlLCAndXNlcicpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtYXV0by1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b0NhcHR1cmU6IG1zZy5vbiB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2F1dG8tY2FwdHVyZSB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtZW5hYmxlZCc6IHtcbiAgICAgIGNvbnN0IHMgPSBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGVuYWJsZWQ6IG1zZy5vbiB9KTtcbiAgICAgIGlmICghbXNnLm9uKSB7XG4gICAgICAgIC8vIFBhdXNpbmcgc3RvcHMgYWxsIGluLWZsaWdodCBsb29wcyBzbyB0aGUgdXNlciBnZXRzIGltbWVkaWF0ZVxuICAgICAgICAvLyBxdWlldCwgbm90IGEgXCJvbmUgbW9yZSB0aWNrXCIgc3VycHJpc2UuXG4gICAgICAgIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gICAgICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICAgICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigncmVmZXRjaC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBSZXN1bWluZyByZS1hcm1zIGFueSBsb29wcyB3aG9zZSBzZXNzaW9uIGlzIHN0aWxsIHNldC5cbiAgICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICAgIGlmIChzZXNzICE9PSBudWxsKSBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xuICAgICAgfVxuICAgICAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIG1hc3RlciBzd2l0Y2ggdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgfVxuICAgIGNhc2UgJ3N0YXJ0LWF1dG8tc2Nyb2xsJzpcbiAgICAgIGF3YWl0IHN0YXJ0QXV0b1Njcm9sbExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLWF1dG8tc2Nyb2xsJzpcbiAgICAgIGF3YWl0IGNhbmNlbEF1dG9TY3JvbGxMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCc6IHtcbiAgICAgIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICAgICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICAgICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChtc2cuc2Vjb25kcykpXG4gICAgICApO1xuICAgICAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IHNlY29uZHMgfSk7XG4gICAgICAvLyBSZS1hcm0gYW55IGFjdGl2ZSBsb29wcyB3aXRoIHRoZSBuZXcgaW50ZXJ2YWwuXG4gICAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgIGlmIChzZXNzICE9PSBudWxsKSBhcm1BdXRvU2Nyb2xsVGltZXIoc2Vjb25kcyk7XG4gICAgICBpZiAocmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcbiAgICAgIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHMpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAnc3RhcnQtcmVmZXRjaCc6XG4gICAgICBhd2FpdCBzdGFydFJlZmV0Y2hMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1yZWZldGNoJzpcbiAgICAgIGF3YWl0IGNhbmNlbFJlZmV0Y2hMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3N0YXJ0LW1lZGlhLWNyYXdsJzpcbiAgICAgIGF3YWl0IHN0YXJ0TWVkaWFDcmF3bExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLW1lZGlhLWNyYXdsJzpcbiAgICAgIGF3YWl0IGNhbmNlbE1lZGlhQ3Jhd2xMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3B1cmdlLXVucmVsYXRlZCc6IHtcbiAgICAgIGNvbnN0IGFjY3MgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICAgICAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjcy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcbiAgICAgIGNvbnN0IHN1bW1hcnkgPSBhd2FpdCBwdXJnZVVucmVsYXRlZFN0YXRlKHRyYWNrZWQpO1xuICAgICAgYXdhaXQgaW5mbygncHVyZ2VkIHVucmVsYXRlZCBzdGF0ZScsIHN1bW1hcnkpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAncmVmcmVzaC1hY2NvdW50cyc6XG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd2ZXJpZnktY29ubmVjdGlvbic6XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjbGVhci1hY3Rpdml0eSc6XG4gICAgICBhd2FpdCBjbGVhckFjdGl2aXR5KCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tb3B0aW9ucyc6XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tdmlld2VyJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgICBjb25zdCB1cmwgPSB2aWV3ZXJVcmwocyk7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICd1bmtub3duIG1lc3NhZ2UgdHlwZScgfTtcbiAgfVxufVxuXG4vLyAtLS0gQ2FwdHVyZSBwaXBlbGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBvbkdyYXBocWxDYXB0dXJlKGVuZHBvaW50OiBzdHJpbmcsIHVybDogc3RyaW5nLCByZXNwb25zZTogdW5rbm93bik6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoUFJPRklMRV9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuOyAvLyBub3QgdHdlZXQtYmVhcmluZ1xuICBpZiAoIVRXRUVUX0VORFBPSU5UUy5oYXMoZW5kcG9pbnQpKSByZXR1cm47XG5cbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICAvLyBXZSBkZWxpYmVyYXRlbHkgZG8gTk9UIHNob3J0LWNpcmN1aXQgd2hlbiB0aGUgUEFUIGlzIG1pc3NpbmcuIFRoZVxuICAvLyBub3JtYWxpemUgc3RlcCBpcyBjaGVhcCwgdGhlIGJ1ZmZlciBzdXJ2aXZlcyBzZXJ2aWNlLXdvcmtlciBldmljdGlvbixcbiAgLy8gYW5kIG9uY2UgdGhlIFBBVCBpcyBzZXQgdGhlIG5leHQgYWxhcm0gb3IgdXNlci10cmlnZ2VyZWQgZmx1c2ggY29tbWl0c1xuICAvLyBldmVyeXRoaW5nIHdlJ3ZlIHNlZW4uIERyb3BwaW5nIGNhcHR1cmVzIGhlcmUgd2FzIGhpZGluZyB0aGUgdXNlcidzXG4gIC8vIGZpcnN0IGJyb3dzaW5nIHNlc3Npb24gZW50aXJlbHkuXG5cbiAgLy8gVHdvLXN0YWdlIGZpbHRlcjpcbiAgLy8gICAxLiBCdWlsZCBFVkVSWSBjYW5vbmljYWwgdHdlZXQgd2UgY2FuIGZpbmQgaW4gdGhlIHJlc3BvbnNlIChubyBoYW5kbGVcbiAgLy8gICAgICBmaWx0ZXIgYXQgdGhlIG5vcm1hbGl6ZXIgbGV2ZWwgXHUyMDE0IHdlIHN0aWxsIHdhbnQgcXVvdGVkL1JUJ2QgcGFyZW50c1xuICAvLyAgICAgIHRoYXQgYXBwZWFyIGFzIHNpYmxpbmcgbm9kZXMpLlxuICAvLyAgIDIuIEFwcGx5IGBmaWx0ZXJSZWxhdGVkYCBwb3N0LWhvYyB0byBkcm9wIGFueXRoaW5nIHRoYXQgaGFzIG5vXG4gIC8vICAgICAgcmVsYXRpb25zaGlwIHRvIGEgdHJhY2tlZCBhY2NvdW50LiBUaGUgb2xkIGJlaGF2aW91ciAoXCJlbXB0eVxuICAvLyAgICAgIGFsbG93ZWQtc2V0IG9uIHVzZXItcGFnZSBlbmRwb2ludHMsIGZ1bGwgZmlsdGVyIG9uIGhvbWUvc2VhcmNoXCIpXG4gIC8vICAgICAgd2FzIHdheSB0b28gcGVybWlzc2l2ZSBvbiB0aGUgUmVwbGllcyB0YWI6IGV2ZXJ5IHJhbmRvbSByZXBsaWVyJ3NcbiAgLy8gICAgICByZXBseSBsYW5kZWQgaW4gYSBwZXItaGFuZGxlIGJ1ZmZlciBrZXllZCBieSB0aGVpciBvd24gaGFuZGxlLlxuICBjb25zdCB0cmFja2VkID0gbmV3IFNldChhY2NvdW50cy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcbiAgY29uc3QgY2FwdHVyZWRBdCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICBsZXQgbm9ybWFsaXplZDtcbiAgdHJ5IHtcbiAgICBub3JtYWxpemVkID0gbm9ybWFsaXplKHJlc3BvbnNlLCB7XG4gICAgICBjYXB0dXJlZEF0LFxuICAgICAgcnVuSWQ6ICdwZW5kaW5nJyxcbiAgICAgIGVuZHBvaW50LFxuICAgICAgYWxsb3dlZEhhbmRsZXM6IG5ldyBTZXQ8c3RyaW5nPigpLFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCBxdWFyYW50aW5lKCdub3JtYWxpemUtdGhyZXcnLCBlbmRwb2ludCwgdXJsLCByZXNwb25zZSwgZXJyKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gRHJvcCB1bnJlbGF0ZWQgdHdlZXRzLiBUaGUgZmlsdGVyIGlzIGVuZHBvaW50LWF3YXJlOlxuICAvLyAgIC0gT24gdGhlIGhvbWUgLyBzZWFyY2ggdGltZWxpbmVzIHdlJ2QgYWxyZWFkeSBiZWVuIGZpbHRlcmluZyB0b1xuICAvLyAgICAgdHJhY2tlZCBhdXRob3JzIG9ubHkgXHUyMDE0IGtlZXAgdGhhdCBiZWhhdmlvdXIgYnV0IGdvIHRocm91Z2ggdGhlIHNhbWVcbiAgLy8gICAgIGBmaWx0ZXJSZWxhdGVkYCBoZWxwZXIgc28gdGhlIHJ1bGVzIGFyZSB1bmlmb3JtLlxuICAvLyAgIC0gT24gdXNlci1wYWdlIGVuZHBvaW50cyB3ZSBub3cgYWxzbyBkcm9wIGFueXRoaW5nIHRoYXQgaXNuJ3QgZWl0aGVyXG4gIC8vICAgICBhdXRob3JlZC1ieSwgbWVudGlvbmluZywgcmVwbHlpbmctdG8sIG9yIHJlZmVyZW5jZWQtYnkgYSB0cmFja2VkXG4gIC8vICAgICBhY2NvdW50LlxuICBjb25zdCBiZWZvcmVGaWx0ZXIgPSBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGg7XG4gIG5vcm1hbGl6ZWQudHdlZXRzID0gZmlsdGVyUmVsYXRlZChub3JtYWxpemVkLnR3ZWV0cywgdHJhY2tlZCk7XG4gIGNvbnN0IGRyb3BwZWRVbnJlbGF0ZWQgPSBiZWZvcmVGaWx0ZXIgLSBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGg7XG4gIGlmIChkcm9wcGVkVW5yZWxhdGVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2Ryb3BwZWQgdW5yZWxhdGVkIHR3ZWV0cycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgZHJvcHBlZDogZHJvcHBlZFVucmVsYXRlZCxcbiAgICAgIGtlcHQ6IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIERpYWdub3N0aWM6IGV2ZXJ5IHR3ZWV0LWVuZHBvaW50IHBheWxvYWQgZ2V0cyBhIGxpbmUgaW4gdGhlIGFjdGl2aXR5XG4gIC8vIHRhaWwgd2l0aCB3aGF0IHdlIHNhdyB2cyBrZXB0LiBXaGVuIG9ic2VydmVkPTAgd2UgYWxzbyBlbWl0IGEgc2hhcGVcbiAgLy8gcHJvYmUgKGtleSBwYXRocyArIHR5cGVuYW1lcykgc28gd2UgY2FuIHRlbGwgd2hldGhlciBYIHJldHVybmVkIGFuXG4gIC8vIGVtcHR5IGVudmVsb3BlLCBhIGxvZ2luLXdhbGwgcmVzcG9uc2UsIG9yIGEgbmV3IHNoYXBlIHdlIGRvbid0IGtub3cgaG93XG4gIC8vIHRvIHdhbGsgeWV0LlxuICBpZiAobm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygnZ3JhcGhxbCBwYXlsb2FkIGVtcHR5IFx1MjAxNCBzaGFwZSBwcm9iZScsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgdHlwZW5hbWVzOiBwcm9iZVR5cGVuYW1lcyhyZXNwb25zZSkuc2xpY2UoMCwgMzApLFxuICAgICAgdHdlZXRfa2V5czogcHJvYmVGaXJzdFR5cGVTaGFwZShyZXNwb25zZSwgJ1R3ZWV0JyksXG4gICAgICB0d2VldF9jb3JlX2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFsnY29yZSddKSxcbiAgICAgIHR3ZWV0X2xlZ2FjeV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbJ2xlZ2FjeSddKSxcbiAgICAgIHVzZXJfcmVzdWx0c19yZXN1bHRfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xuICAgICAgICAnY29yZScsXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxuICAgICAgICAncmVzdWx0JyxcbiAgICAgIF0pLFxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9jb3JlX2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcbiAgICAgICAgJ3Jlc3VsdCcsXG4gICAgICAgICdjb3JlJyxcbiAgICAgIF0pLFxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9sZWdhY3lfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xuICAgICAgICAnY29yZScsXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxuICAgICAgICAncmVzdWx0JyxcbiAgICAgICAgJ2xlZ2FjeScsXG4gICAgICBdKSxcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBhd2FpdCBpbmZvKCdncmFwaHFsIHBheWxvYWQgc2VlbicsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgb2JzZXJ2ZWQ6IG5vcm1hbGl6ZWQub2JzZXJ2ZWRfaWRzLmxlbmd0aCxcbiAgICAgIGtlcHQ6IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuXG4gIGlmIChub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAvLyBSZWZldGNoIHF1ZXVlIGhvdXNla2VlcGluZyBcdTIwMTQgcnVucyBCRUZPUkUgdGhlIGRlZHVwIHNob3J0LWNpcmN1aXQuIEFcbiAgLy8gcmVmZXRjaCBjYXB0dXJlIGNvbWVzIGJhY2sgd2l0aCB0aGUgc2FtZSBlbmdhZ2VtZW50IGNvdW50cyAod2UncmVcbiAgLy8gb25seSBhZnRlciB0aGUgZnVsbCB0ZXh0KSwgc28gdGhlIGRlZHVwIGJlbG93IHdvdWxkIHNpbGVudGx5IGRyb3BcbiAgLy8gaXQgYW5kIHRoZSBxdWV1ZSB3b3VsZCBuZXZlciBkcmFpbi4gSG9pc3QgdGhlIGVucXVldWUvZGVxdWV1ZSBoZXJlXG4gIC8vIHNvIHRoZSBsb29wIHJlbGlhYmx5IGFkdmFuY2VzIGV2ZW4gd2hlbiBubyBjb21taXQgaGFwcGVucy5cbiAgLy9cbiAgLy8gQWxzbzogaWYgZWl0aGVyIGxvb3AncyBpbmZsaWdodCB0YXJnZXQgYXBwZWFycyBoZXJlLCBtYXJrIHRoZSBsb29wXG4gIC8vIGFzIFwiaW5nZXN0ZWRcIiBzbyB0aGUgbmV4dCB0aWNrIGNhbiBhZHZhbmNlLiBUaGUgd2FpdC1mb3ItaW5nZXN0XG4gIC8vIGd1YXJkIG90aGVyd2lzZSBibG9ja3MgdW50aWwgdGhlIG5hdmlnYXRpb24tdGltZW91dCBmaXJlcy5cbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGlmICh0LmlzX3RydW5jYXRlZCkge1xuICAgICAgYXdhaXQgZW5xdWV1ZVJlZmV0Y2godC5hY2NvdW50X2hhbmRsZSwgdC50d2VldF9pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xuICAgIH1cbiAgICAvLyBTdWNjZXNzZnVsbHkgYnVpbHQgdHdlZXRzIGFyZSBubyBsb25nZXIgXCJwYXJ0aWFsXCIgXHUyMDE0IGRyb3AgZnJvbSB0aGVcbiAgICAvLyBtZWRpYS1jcmF3bCBxdWV1ZSByZWdhcmRsZXNzIG9mIHdoaWNoIGhhbmRsZSB3ZSdkIGhpbnRlZCBlYXJsaWVyLlxuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHQudHdlZXRfaWQpO1xuICAgIGlmIChyZWZldGNoU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcbiAgICAgIHJlZmV0Y2hTZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIHJlZmV0Y2hTZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24ocmVmZXRjaFNlc3MpO1xuICAgIH1cbiAgICBpZiAobWVkaWFDcmF3bFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XG4gICAgICBtZWRpYUNyYXdsU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICBtZWRpYUNyYXdsU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG1lZGlhQ3Jhd2xTZXNzKTtcbiAgICB9XG4gIH1cblxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXQtc2hhcGVkIG5vZGVzIHRoZSB3YWxrZXIgc2F3IGJ1dCBjb3VsZG4ndCB0dXJuXG4gIC8vIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gRW5xdWV1ZSBvbmx5IElEcyB3ZSBoYXZlbid0IGFscmVhZHlcbiAgLy8gY29tbWl0dGVkICh1c2VyLXJlcXVlc3RlZCBkZWR1cCBhZ2FpbnN0IHRoZSBhcmNoaXZlKS5cbiAgZm9yIChjb25zdCBwYXJ0aWFsIG9mIG5vcm1hbGl6ZWQucGFydGlhbF9pZHMpIHtcbiAgICBpZiAoYXdhaXQgaXNDb21taXR0ZWQocGFydGlhbC50d2VldF9pZCkpIGNvbnRpbnVlO1xuICAgIGF3YWl0IGVucXVldWVNZWRpYUNyYXdsKHBhcnRpYWwuaGludF9oYW5kbGUsIHBhcnRpYWwudHdlZXRfaWQpO1xuICB9XG4gIGlmIChub3JtYWxpemVkLnBhcnRpYWxfaWRzLmxlbmd0aCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogZW5xdWV1ZWQgcGFydGlhbCBjYXB0dXJlcycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgcGFydGlhbDogbm9ybWFsaXplZC5wYXJ0aWFsX2lkcy5sZW5ndGgsXG4gICAgICBxdWV1ZV90b3RhbDogYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKSxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIENyb3NzLXNlc3Npb24gZGVkdXA6IGRyb3AgdHdlZXRzIHdlJ3ZlIGFscmVhZHkgY29tbWl0dGVkIHdpdGggaWRlbnRpY2FsXG4gIC8vIGVuZ2FnZW1lbnQgY291bnRzLiBMaWtlcy9SVHMvcmVwbGllcy9xdW90ZXMgc3RpbGwgdHJpZ2dlciBhIHJlY2FwdHVyZVxuICAvLyBzbyBlbmdhZ2VtZW50X2hpc3RvcnkgZ3Jvd3Mgb3ZlciB0aW1lLiB2aWV3X2NvdW50IGlzIGludGVudGlvbmFsbHlcbiAgLy8gZXhjbHVkZWQgXHUyMDE0IGl0IGNodXJucyB0b28gZmFzdCB0byBiZSB1c2VmdWwgYXMgYSBmcmVzaG5lc3Mgc2lnbmFsLlxuICAvLyBgaXNfdHJ1bmNhdGVkYCBpcyBwYXJ0IG9mIHRoZSBzaWduYXR1cmUgc28gYSByZWZldGNoIHRoYXQgZmxpcHNcbiAgLy8gdHJ1bmNhdGVkXHUyMTkyZnVsbCBpcyB0cmVhdGVkIGFzIGEgbWF0ZXJpYWwgY2hhbmdlIGFuZCBnZXRzIGNvbW1pdHRlZC5cbiAgY29uc3QgY29tbWl0dGVkSWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgbGV0IGRlZHVwZWRTa2lwcGVkID0gMDtcbiAgY29uc3QgbGl2ZVR3ZWV0czogdHlwZW9mIG5vcm1hbGl6ZWQudHdlZXRzID0gW107XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbdC5hY2NvdW50X2hhbmRsZV0/Llt0LnR3ZWV0X2lkXTtcbiAgICBjb25zdCBzaWcgPSBlbmdhZ2VtZW50U2lnKFxuICAgICAgdC5saWtlX2NvdW50LFxuICAgICAgdC5yZXR3ZWV0X2NvdW50LFxuICAgICAgdC5yZXBseV9jb3VudCxcbiAgICAgIHQucXVvdGVfY291bnQsXG4gICAgICB0LmlzX3RydW5jYXRlZFxuICAgICk7XG4gICAgaWYgKHByZXYgJiYgcHJldi5zaWcgPT09IHNpZykge1xuICAgICAgZGVkdXBlZFNraXBwZWQgKz0gMTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBsaXZlVHdlZXRzLnB1c2godCk7XG4gIH1cbiAgaWYgKGRlZHVwZWRTa2lwcGVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2RlZHVwOiBza2lwcGVkIHVuY2hhbmdlZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHNraXBwZWQ6IGRlZHVwZWRTa2lwcGVkLFxuICAgICAgcmVtYWluaW5nOiBsaXZlVHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuICBpZiAobGl2ZVR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAvLyBHcm91cCBzdXJ2aXZpbmcgdHdlZXRzIGJ5IGF1dGhvciBoYW5kbGUuXG4gIGNvbnN0IGJ5SGFuZGxlID0gbmV3IE1hcDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0W10+KCk7XG4gIGZvciAoY29uc3QgdCBvZiBsaXZlVHdlZXRzKSB7XG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUpID8/IFtdO1xuICAgIGFyci5wdXNoKHQpO1xuICAgIGJ5SGFuZGxlLnNldCh0LmFjY291bnRfaGFuZGxlLCBhcnIpO1xuICB9XG5cbiAgZm9yIChjb25zdCBbaGFuZGxlLCB0d2VldHNdIG9mIGJ5SGFuZGxlKSB7XG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgdXJsLCBlbmRwb2ludCk7XG4gICAgbGV0IGFkZGVkID0gMDtcbiAgICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgICBjb25zdCBleGlzdGluZyA9IGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF07XG4gICAgICBpZiAoZXhpc3RpbmcpIHtcbiAgICAgICAgLy8gUHJlc2VydmUgZmlyc3RfY2FwdHVyZWRfYXQsIGFwcGVuZCBlbmdhZ2VtZW50IHNuYXBzaG90LCByZWZyZXNoXG4gICAgICAgIC8vIGxhc3Rfc2Vlbl9hdCArIGNvdW50cyAodGhlIGxhdGVzdCBzY3JhcGUgd2lucyBmb3IgY291bnRzKS5cbiAgICAgICAgZXhpc3RpbmcubGFzdF9zZWVuX2F0ID0gY2FwdHVyZWRBdDtcbiAgICAgICAgZXhpc3RpbmcubGlrZV9jb3VudCA9IHQubGlrZV9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmV0d2VldF9jb3VudCA9IHQucmV0d2VldF9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmVwbHlfY291bnQgPSB0LnJlcGx5X2NvdW50O1xuICAgICAgICBleGlzdGluZy5xdW90ZV9jb3VudCA9IHQucXVvdGVfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnZpZXdfY291bnQgPSB0LnZpZXdfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLmJvb2ttYXJrX2NvdW50ID0gdC5ib29rbWFya19jb3VudDtcbiAgICAgICAgY29uc3QgbGFzdCA9IGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeVtleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnkubGVuZ3RoIC0gMV07XG4gICAgICAgIGNvbnN0IHNuYXAgPSB0LmVuZ2FnZW1lbnRfaGlzdG9yeVswXTtcbiAgICAgICAgaWYgKHNuYXAgJiYgKCFsYXN0IHx8IGxhc3QuY2FwdHVyZWRfYXQgIT09IHNuYXAuY2FwdHVyZWRfYXQpKSB7XG4gICAgICAgICAgZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5LnB1c2goc25hcCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHN0YW1wZWQ6IENhbm9uaWNhbFR3ZWV0ID0geyAuLi50LCBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCB9O1xuICAgICAgICBidWYudHdlZXRzX2J5X2lkW3QudHdlZXRfaWRdID0gc3RhbXBlZDtcbiAgICAgICAgYWRkZWQgKz0gMTtcbiAgICAgIH1cbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyh0LnR3ZWV0X2lkKSkge1xuICAgICAgICBidWYudHdlZXRfaWRzX29ic2VydmVkLnB1c2godC50d2VldF9pZCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xuICAgIGJ1Zi5sYXN0X2NhcHR1cmVfYXQgPSBjYXB0dXJlZEF0O1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCk7XG4gICAgaWYgKGFkZGVkID4gMCkge1xuICAgICAgYXdhaXQgaW5mbygnY2FwdHVyZWQgdHdlZXRzJywge1xuICAgICAgICBoYW5kbGUsXG4gICAgICAgIGVuZHBvaW50LFxuICAgICAgICBhZGRlZCxcbiAgICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCxcbiAgICAgIH0pO1xuICAgICAgLy8gQnVtcCB0aGUgYXV0by1zY3JvbGwgcHJvZ3Jlc3Mgc28gdGhlIHVzZXIgc2VlcyBcIlggaW5nZXN0ZWRcIiB0aWNrIHVwXG4gICAgICAvLyBpbiByZWFsIHRpbWUuIFdlIGNvdW50IGFjdHVhbGx5LW5ldyB0d2VldHMsIG5vdCBkdXBsaWNhdGVzLlxuICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgIGlmIChhc1Nlc3MgIT09IG51bGwpIHtcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkQ291bnQgKz0gYWRkZWQ7XG4gICAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKGFzU2Vzcyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggPj0gRkxVU0hfVFdFRVRfVEhSRVNIT0xEKSB7XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICd0aHJlc2hvbGQnKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlUnVuQnVmZmVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgdHM6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8UnVuQnVmZmVyPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpO1xuICBpZiAoY3VyKSByZXR1cm4gY3VyO1xuICBjb25zdCBidWY6IFJ1bkJ1ZmZlciA9IHtcbiAgICBydW5faWQ6IG5ld1J1bklkKCksXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBzdGFydGVkX2F0OiB0cyxcbiAgICBsYXN0X2NhcHR1cmVfYXQ6IHRzLFxuICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcbiAgICBlbmRwb2ludHNfc2VlbjogW2VuZHBvaW50XSxcbiAgICBzb3VyY2VfdXJsOiBzb3VyY2VVcmwsXG4gIH07XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gIGF3YWl0IGluZm8oJ3J1biBzdGFydGVkJywgeyBoYW5kbGUsIHJ1bjogc2hvcnRSdW5JZChidWYucnVuX2lkKSB9KTtcbiAgcmV0dXJuIGJ1Zjtcbn1cblxuLy8gLS0tIEZsdXNoIGxvZ2ljIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hJZGxlQnVmZmVycygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICdpZGxlJyk7XG4gICAgfVxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoT3JwaGFuZWRCdWZmZXJzSWZTdGFsZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gT24gd29ya2VyIHdha2UsIGFueSBidWZmZXIgb2xkZXIgdGhhbiB0aGUgaWRsZSB0aHJlc2hvbGQgZ2V0cyBhIGNoYW5jZSB0b1xuICAvLyBjb21taXQgaW1tZWRpYXRlbHkgXHUyMDE0IHVzZWZ1bCB3aGVuIHRoZSB3b3JrZXIgd2FzIGV2aWN0ZWQgYmVmb3JlIGlkbGUtZmx1c2guXG4gIC8vIElmIHRoZSBQQVQvb3duZXIvcmVwbyBhcmVuJ3Qgc2V0IHdlJ2QganVzdCBlbWl0IFwiZmx1c2ggZGVmZXJyZWRcIiBmb3IgZXZlcnlcbiAgLy8gc2luZ2xlIGhhbmRsZSBpbiBzdG9yYWdlICh0aGUgZGlhZ25vc3RpYyBzaG93ZWQgdGhpcyBmaXJpbmcgMzAwKyB0aW1lcyBpblxuICAvLyBhIHJvdyB3aGVuIHRoZSBleHRlbnNpb24gd29rZSBiZWZvcmUgc2V0dGluZ3MgbG9hZCksIHNvIHNob3J0LWNpcmN1aXRcbiAgLy8gaGVyZSBpbnN0ZWFkLlxuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykgcmV0dXJuO1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgYnVmXSBvZiBPYmplY3QuZW50cmllcyhhbGwpKSB7XG4gICAgY29uc3QgbGFzdCA9IERhdGUucGFyc2UoYnVmLmxhc3RfY2FwdHVyZV9hdCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShsYXN0KSAmJiBub3cgLSBsYXN0ID49IEZMVVNIX0lETEVfTVMpIHtcbiAgICAgIGF3YWl0IGZsdXNoSGFuZGxlKGhhbmRsZSwgJ3dha2UnKTtcbiAgICB9XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hBbGwocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhhbGwpKSB7XG4gICAgYXdhaXQgZmx1c2hIYW5kbGUoaGFuZGxlLCByZWFzb24pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlKGhhbmRsZTogc3RyaW5nLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBidWYgPSBhd2FpdCBnZXRSdW5CdWZmZXIoaGFuZGxlKTtcbiAgaWYgKCFidWYpIHJldHVybjtcbiAgY29uc3QgdHdlZXRzID0gT2JqZWN0LnZhbHVlcyhidWYudHdlZXRzX2J5X2lkKTtcbiAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApIHtcbiAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihoYW5kbGUpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHdhcm4oJ2ZsdXNoIGRlZmVycmVkOiBzZXR0aW5ncyBpbmNvbXBsZXRlJywgeyBoYW5kbGUgfSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICBjb25zdCB0cyA9IGlzb0NvbXBhY3QoYnVmLnN0YXJ0ZWRfYXQpO1xuICBjb25zdCBkYXkgPSBidWYuc3RhcnRlZF9hdC5zbGljZSgwLCAxMCk7XG4gIGNvbnN0IHJhd1BhdGggPSBgcmF3LyR7aGFuZGxlfS8ke3RzfS0ke3Nob3J0UnVuSWQoYnVmLnJ1bl9pZCl9Lmpzb25gO1xuICBjb25zdCBzZWVuUGF0aCA9IGBzZWVuLyR7aGFuZGxlfS8ke3RzfS0ke3Nob3J0UnVuSWQoYnVmLnJ1bl9pZCl9Lmpzb25gO1xuXG4gIGNvbnN0IGNhcHR1cmU6IENhcHR1cmVQYXlsb2FkID0ge1xuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgZW5kcG9pbnQ6IGJ1Zi5lbmRwb2ludHNfc2Vlbi5qb2luKCcsJyksXG4gICAgdXNlcl9hZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcbiAgICBzb3VyY2VfdXJsOiBidWYuc291cmNlX3VybCxcbiAgICB0d2VldHMsXG4gIH07XG4gIGNvbnN0IHNlZW46IFNlZW5QYXlsb2FkID0ge1xuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBidWYudHdlZXRfaWRzX29ic2VydmVkLFxuICB9O1xuXG4gIGNvbnN0IGNvbW1pdE1zZyA9IGBjYXB0dXJlOiAke2hhbmRsZX0gJHtkYXl9ICR7dHdlZXRzLmxlbmd0aH0gdHdlZXQke3R3ZWV0cy5sZW5ndGggPT09IDEgPyAnJyA6ICdzJ30gKHJ1biAke3Nob3J0UnVuSWQoYnVmLnJ1bl9pZCl9KWA7XG5cbiAgdHJ5IHtcbiAgICBhd2FpdCBjbGllbnQucHV0RmlsZSh7XG4gICAgICBwYXRoOiByYXdQYXRoLFxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkoY2FwdHVyZSwgbnVsbCwgMikgKyAnXFxuJyksXG4gICAgICBtZXNzYWdlOiBjb21taXRNc2csXG4gICAgfSk7XG4gICAgYXdhaXQgY2xpZW50LnB1dEZpbGUoe1xuICAgICAgcGF0aDogc2VlblBhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShzZWVuLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICAgIG1lc3NhZ2U6IGBzZWVuOiAke2hhbmRsZX0gJHtkYXl9ICR7c2Vlbi50d2VldF9pZHNfb2JzZXJ2ZWQubGVuZ3RofSBpZHMgKHJ1biAke3Nob3J0UnVuSWQoYnVmLnJ1bl9pZCl9KWAsXG4gICAgfSk7XG4gICAgYXdhaXQgY2xlYXJSdW5CdWZmZXIoaGFuZGxlKTtcbiAgICB7XG4gICAgICAvLyBDb3VudGVyIGJ1bXA6IGFjdHVhbGx5IElOQ1JFTUVOVCB0b2RheUNvdW50IGFuZCB0b3RhbENvbW1pdHRlZCBieVxuICAgICAgLy8gdGhlIG51bWJlciBvZiB0d2VldHMgd2UganVzdCBwZXJzaXN0ZWQgKHRoZSBwcmV2aW91cyBjb2RlIHJlYWQgdGhlXG4gICAgICAvLyBleGlzdGluZyB2YWx1ZXMgYW5kIHdyb3RlIHRoZW0gYmFjaywgbGVhdmluZyB0aGUgY291bnRlciBwZWdnZWQgYXRcbiAgICAgIC8vIHplcm8pLlxuICAgICAgY29uc3QgcHJldiA9IChhd2FpdCBnZXRDb3VudGVycygpKVtoYW5kbGVdO1xuICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuICAgICAgY29uc3QgY2FycmllZFRvZGF5ID0gcHJldiAmJiBwcmV2LnRvZGF5RGF0ZSA9PT0gdG9kYXkgPyBwcmV2LnRvZGF5Q291bnQgOiAwO1xuICAgICAgYXdhaXQgYnVtcENvdW50ZXIoaGFuZGxlLCB7XG4gICAgICAgIHRvZGF5Q291bnQ6IGNhcnJpZWRUb2RheSArIHR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIHRvZGF5RGF0ZTogdG9kYXksXG4gICAgICAgIGxhc3RDYXB0dXJlQXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICAgIHRvdGFsQ29tbWl0dGVkOiAocHJldj8udG90YWxDb21taXR0ZWQgPz8gMCkgKyB0d2VldHMubGVuZ3RoLFxuICAgICAgICBidWZmZXJlZENvdW50OiAwLFxuICAgICAgfSk7XG4gICAgfVxuICAgIC8vIFJlY29yZCBjb21taXRzIGluIHRoZSBkZWR1cCBpbmRleCBzbyB3ZSBkb24ndCByZS1jb21taXQgdGhlbSBuZXh0XG4gICAgLy8gYnJvd3NlIHdpdGggdW5jaGFuZ2VkIGVuZ2FnZW1lbnQuXG4gICAge1xuICAgICAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgICAgIGNvbnN0IGlubmVyID0gaWR4W2hhbmRsZV0gPz8ge307XG4gICAgICBjb25zdCBub3dJc28gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgICAgIGlubmVyW3QudHdlZXRfaWRdID0ge1xuICAgICAgICAgIHRzOiBub3dJc28sXG4gICAgICAgICAgc2lnOiBlbmdhZ2VtZW50U2lnKFxuICAgICAgICAgICAgdC5saWtlX2NvdW50LFxuICAgICAgICAgICAgdC5yZXR3ZWV0X2NvdW50LFxuICAgICAgICAgICAgdC5yZXBseV9jb3VudCxcbiAgICAgICAgICAgIHQucXVvdGVfY291bnQsXG4gICAgICAgICAgICB0LmlzX3RydW5jYXRlZFxuICAgICAgICAgICksXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBpZHhbaGFuZGxlXSA9IGlubmVyO1xuICAgICAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcbiAgICB9XG4gICAgYXdhaXQgaW5mbygnZmx1c2ggY29tbWl0dGVkJywge1xuICAgICAgaGFuZGxlLFxuICAgICAgcmVhc29uLFxuICAgICAgdHdlZXRzOiB0d2VldHMubGVuZ3RoLFxuICAgICAgcnVuOiBzaG9ydFJ1bklkKGJ1Zi5ydW5faWQpLFxuICAgICAgcGF0aDogcmF3UGF0aCxcbiAgICB9KTtcbiAgICB7XG4gICAgICBjb25zdCBwcmV2ID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICAgIHN0YXR1czogJ29rJyxcbiAgICAgICAgbG9naW46IHByZXYubG9naW4sXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogcHJldi5kZWZhdWx0QnJhbmNoLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBwcmV2LmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgICB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvcikge1xuICAgICAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XG4gICAgICAgIGVyci5jYXRlZ29yeSA9PT0gJ2F1dGgnXG4gICAgICAgICAgPyAnYXV0aC1lcnJvcidcbiAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnXG4gICAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ25ldHdvcmsnXG4gICAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXG4gICAgICAgICAgICAgIDogY29ubi5zdGF0dXM7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzLFxuICAgICAgICBsb2dpbjogY29ubi5sb2dpbixcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBlcnIubWVzc2FnZSxcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogY29ubi5kZWZhdWx0QnJhbmNoLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBjb25uLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6XG4gICAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyBlcnIucmF0ZUxpbWl0UmVzZXRBdCA6IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgbG9nRXJyKCdmbHVzaCBmYWlsZWQnLCB7XG4gICAgICAgIGhhbmRsZSxcbiAgICAgICAgcmVhc29uLFxuICAgICAgICBjYXRlZ29yeTogZXJyLmNhdGVnb3J5LFxuICAgICAgICBzdGF0dXM6IGVyci5zdGF0dXMsXG4gICAgICAgIG1lc3NhZ2U6IGVyci5tZXNzYWdlLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBlcnIucmF0ZUxpbWl0UmVzZXRBdCxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBsb2dFcnIoJ2ZsdXNoIGZhaWxlZCcsIHsgaGFuZGxlLCByZWFzb24sIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgICB9XG4gICAgLy8gTGVhdmUgYnVmZmVyIGludGFjdCBmb3IgcmV0cnkuXG4gIH0gZmluYWxseSB7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgfVxufVxuXG4vLyAtLS0gQ2FwdHVyZS1ub3cgLyBjYXB0dXJlLWFsbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVOb3coaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gTGFuZCBvbiB0aGUgUmVwbGllcyB0YWIgc28gWCBmZXRjaGVzIHZpYSBVc2VyVHdlZXRzQW5kUmVwbGllcyBcdTIwMTQgdGhhdFxuICAvLyBlbmRwb2ludCByZXR1cm5zIGJvdGggdG9wLWxldmVsIHBvc3RzIGFuZCByZXBsaWVzLCB3aGljaCBpcyB0aGUgc3VwZXJzZXRcbiAgLy8gd2Ugd2FudCBmb3IgdGhlIGFyY2hpdmUuIFRoZSBwbGFpbiBgLzxoYW5kbGU+YCBVUkwgaGl0cyBVc2VyVHdlZXRzLFxuICAvLyB3aGljaCBvbWl0cyByZXBsaWVzLiBUaGUgcGFnZS1ob29rIGludGVyY2VwdHMgZWl0aGVyIGVuZHBvaW50LCBidXRcbiAgLy8gZm9yY2luZyB0aGUgYnJvYWRlciB0YWIgb24gdXNlci1pbml0aWF0ZWQgY2FwdHVyZXMgaXMgdGhlIHJpZ2h0IGRlZmF1bHQuXG4gIGNvbnN0IHRhcmdldFVybCA9IGBodHRwczovL3guY29tLyR7aGFuZGxlfS93aXRoX3JlcGxpZXNgO1xuICBhd2FpdCBpbmZvKCdjYXB0dXJlLW5vdyByZXF1ZXN0ZWQnLCB7IGhhbmRsZSwgdGFiOiAnd2l0aF9yZXBsaWVzJyB9KTtcbiAgaWYgKCEoYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSkpKSB7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIHtcbiAgICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBzdGFydGVkX2F0OiBub3csXG4gICAgICBsYXN0X2NhcHR1cmVfYXQ6IG5vdyxcbiAgICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IFtdLFxuICAgICAgZW5kcG9pbnRzX3NlZW46IFtdLFxuICAgICAgc291cmNlX3VybDogdGFyZ2V0VXJsLFxuICAgIH0pO1xuICB9XG4gIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmw6IHRhcmdldFVybCwgYWN0aXZlOiB0cnVlIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtYWxsIHJlcXVlc3RlZCcsIHsgY291bnQ6IGFjY291bnRzLmxlbmd0aCB9KTtcbiAgZm9yIChjb25zdCBhIG9mIGFjY291bnRzKSB7XG4gICAgYXdhaXQgY2FwdHVyZU5vdyhhLmhhbmRsZSk7XG4gIH1cbn1cblxuLyoqXG4gKiBDYXB0dXJlIHdoYXRldmVyIHRoZSB1c2VyIGlzIGN1cnJlbnRseSBsb29raW5nIGF0OiBlbnN1cmVzIHBhZ2UtaG9vayBpc1xuICogcGF0Y2hlZCBpbnRvIHRoZSBhY3RpdmUgdGFiLCB0aGVuIG51ZGdlcyB0aGUgcGFnZSB3aXRoIGEgcHJvZ3JhbW1hdGljXG4gKiBzY3JvbGwgc28gWCBmaXJlcyBhbm90aGVyIGJhdGNoIG9mIEdyYXBoUUwgcmVxdWVzdHMgd2UgY2FuIGludGVyY2VwdC5cbiAqXG4gKiBMZXNzIGRpc3J1cHRpdmUgdGhhbiBgQ2FwdHVyZSBub3dgIChubyBuZXcgdGFiLCBubyBuYXZpZ2F0aW9uKSBhbmQgd29ya3NcbiAqIGZvciBhcmJpdHJhcnkgWCBVUkxzIChzcGVjaWZpYyB0d2VldCB0aHJlYWRzLCBzZWFyY2ggcmVzdWx0cywgbGlzdHMpXG4gKiB0aGF0IGRvbid0IG1hcCBjbGVhbmx5IHRvIG9uZSBvZiB0aGUgY29uZmlndXJlZCBoYW5kbGVzLlxuICovXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlVGhpc1BhZ2UoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XG4gIHRyeSB7XG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGNvdWxkIG5vdCBxdWVyeSBhY3RpdmUgdGFiJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgdGFiID0gdGFic1swXTtcbiAgaWYgKCF0YWIgfHwgdHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicgfHwgIXRhYi51cmwpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogbm8gYWN0aXZlIHRhYicpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIS9eaHR0cHM6XFwvXFwvKHh8dHdpdHRlcilcXC5jb21cXC8vLnRlc3QodGFiLnVybCkpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogYWN0aXZlIHRhYiBpcyBub3Qgb24geC5jb20gLyB0d2l0dGVyLmNvbScsIHtcbiAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsKSxcbiAgICB9KTtcbiAgICByZXR1cm47XG4gIH1cbiAgYXdhaXQgaW5mbygnY2FwdHVyZS10aGlzLXBhZ2UgcmVxdWVzdGVkJywgeyB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCkgfSk7XG4gIC8vIChSZS0paW5qZWN0IHRoZSBwYWdlLWhvb2sgKyBpc29sYXRlZCBjb250ZW50IHNjcmlwdCBzbyBmZXRjaC9YSFIgYXJlXG4gIC8vIHBhdGNoZWQgZXZlbiBvbiB0YWJzIG9wZW5lZCBiZWZvcmUgdGhlIGV4dGVuc2lvbiByZWxvYWRlZC5cbiAgdHJ5IHtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICBmaWxlczogWydwYWdlLWhvb2suanMnXSxcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICB9KTtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiByZS1pbmplY3QgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxuICAvLyBOdWRnZSBYIHRvIGZpcmUgbW9yZSBHcmFwaFFMIHJlcXVlc3RzIGJ5IHNjcm9sbGluZy4gTW9zdCB0aW1lbGluZSAvXG4gIC8vIGNvbnZlcnNhdGlvbiB2aWV3cyBmZXRjaCBvbiBpbnRlcnNlY3Rpb24tb2JzZXJ2ZXIgdHJpZ2dlcnMuXG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgZnVuYzogKCkgPT4ge1xuICAgICAgICBjb25zdCBoID0gd2luZG93LmlubmVySGVpZ2h0O1xuICAgICAgICB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgNjAwKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgMTIwMCk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogc2Nyb2xsLW51ZGdlIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbn1cblxuLy8gLS0tIFJlZmV0Y2ggbG9vcCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vXG4vLyBYIHRydW5jYXRlcyBsb25nIHR3ZWV0cyBpbiB0aW1lbGluZSBwYXlsb2FkcyBcdTIwMTQgYG5vdGVfdHdlZXRgIGlzIG9ubHlcbi8vIGlubGluZWQgZm9yIHNvbWUgZW5kcG9pbnRzLiBSZS1vcGVuaW5nIGVhY2ggdHJ1bmNhdGVkIHR3ZWV0J3MgZGV0YWlsIHBhZ2Vcbi8vIGNhdXNlcyB0aGUgcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkuIFRoZSBsb29wXG4vLyBkcml2ZXMgdGhhdCBieSBuYXZpZ2F0aW5nIGEgc2luZ2xlIGRlZGljYXRlZCB0YWIgdGhyb3VnaCB0aGUgcXVldWUsIG9uZVxuLy8gdHdlZXQgYXQgYSB0aW1lLCBnYXRlZCBvbiB0aGUgcGFnZS1ob29rIGFjdHVhbGx5IGluZ2VzdGluZyBhIHJlc3BvbnNlIGZvclxuLy8gdGhlIHR3ZWV0IHdlIGp1c3QgbmF2aWdhdGVkIHRvIChzbyBkZWxldGVkIC8gcGF5d2FsbGVkIC8gNDA0J2QgdHdlZXRzXG4vLyBkb24ndCBtYWtlIHVzIHNwaW4gYW5kIHNvIHdlIGRvbid0IHNsYW0gWCB3aXRoIHJlZnJlc2hlcyBmYXN0ZXIgdGhhbiB0aGVcbi8vIHRhYiBjYW4gbG9hZCkuXG5cbmNvbnN0IFJFRkVUQ0hfVEFCX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3JlZmV0Y2hfdGFiX2lkX18nO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoUkVGRVRDSF9UQUJfS0VZKTtcbiAgY29uc3QgaWQgPSBzdG9yZWRbUkVGRVRDSF9UQUJfS0VZXTtcbiAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ251bWJlcicgPyBpZCA6IG51bGw7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hUYWJJZChpZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoaWQgPT09IG51bGwpIHtcbiAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFJFRkVUQ0hfVEFCX0tFWSk7XG4gIH0gZWxzZSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtSRUZFVENIX1RBQl9LRVldOiBpZCB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydFJlZmV0Y2hMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCB0b3RhbCA9IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCk7XG4gIGlmICh0b3RhbCA9PT0gMCkge1xuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2g6IG5vdGhpbmcgcXVldWVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcbiAgKTtcbiAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24oe1xuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXG4gICAgcHJvY2Vzc2VkOiAwLFxuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIGluZmxpZ2h0OiBudWxsLFxuICB9KTtcbiAgc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kcyk7XG4gIHZvaWQgcmVmZXRjaFRpY2soKTtcbiAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxubGV0IHJlZmV0Y2hJbnRlcnZhbEhhbmRsZTogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xuICBpZiAocmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsKSBjbGVhckludGVydmFsKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSk7XG4gIHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIHJlZmV0Y2hUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCdyZWZldGNoIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICB9KTtcbiAgfSwgc2Vjb25kcyAqIDEwMDApO1xufVxuXG5mdW5jdGlvbiBzdG9wUmVmZXRjaEludGVydmFsKCk6IHZvaWQge1xuICBpZiAocmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsKSB7XG4gICAgY2xlYXJJbnRlcnZhbChyZWZldGNoSW50ZXJ2YWxIYW5kbGUpO1xuICAgIHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSA9IG51bGw7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsUmVmZXRjaExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxuICBjb25zdCB0YWJJZCA9IGF3YWl0IGdldFJlZmV0Y2hUYWJJZCgpO1xuICBhd2FpdCBzZXRSZWZldGNoVGFiSWQobnVsbCk7XG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihudWxsKTtcbiAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcbiAgICBwcm9jZXNzZWQ6IHNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBzZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgaWYgKHNlc3MgPT09IG51bGwpIHtcbiAgICAvLyBMb29wIHdhcyBjYW5jZWxsZWQgb3IgbmV2ZXIgc3RhcnRlZDsgbm90aGluZyB0byBkby5cbiAgICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIFdhaXQtZm9yLWluZ2VzdCBndWFyZDogaWYgd2UncmUgc3RpbGwgZXhwZWN0aW5nIGEgY2FwdHVyZSBmb3IgdGhlXG4gIC8vIHByZXZpb3VzbHktbmF2aWdhdGVkIHRhcmdldCwgb25seSBhZHZhbmNlIG9uY2Ugd2UndmUgZWl0aGVyIHNlZW4gdGhlXG4gIC8vIGNhcHR1cmUgKG9uR3JhcGhxbENhcHR1cmUgY2xlYXJzIGBpbmZsaWdodGApIG9yIGhpdCB0aGUgdGltZW91dC5cbiAgaWYgKHNlc3MuaW5mbGlnaHQgIT09IG51bGwpIHtcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2Uoc2Vzcy5pbmZsaWdodC5uYXZpZ2F0ZWRBdCk7XG4gICAgaWYgKGVsYXBzZWQgPCBJTkdFU1RfV0FJVF9NUykge1xuICAgICAgcmV0dXJuOyAvLyBzdGlsbCB3YWl0aW5nIFx1MjAxNCBwYWdlLWhvb2sgbWF5IHlldCBjYXB0dXJlIHRoZSByZXNwb25zZS5cbiAgICB9XG4gICAgLy8gVGltZWQgb3V0LiBUcmVhdCBhcyBcInRoaXMgdGFyZ2V0IHdvbid0IGluZ2VzdFwiIGFuZCBkcm9wIGl0LlxuICAgIGF3YWl0IHdhcm4oJ3JlZmV0Y2g6IHRhcmdldCB0aW1lZCBvdXQgd2FpdGluZyBmb3IgaW5nZXN0Jywge1xuICAgICAgdHdlZXRfaWQ6IHNlc3MuaW5mbGlnaHQudHdlZXRJZCxcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcbiAgICB9KTtcbiAgICAvLyBGaW5kIHdoaWNoIGhhbmRsZSB0aGlzIGlkIGlzIHF1ZXVlZCB1bmRlciBzbyB3ZSBjYW4gZGVxdWV1ZSBpdC5cbiAgICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gICAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgICBpZiAoaWRzLmluY2x1ZGVzKHNlc3MuaW5mbGlnaHQudHdlZXRJZCkpIHtcbiAgICAgICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2goaGFuZGxlLCBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcbiAgfVxuXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRSZWZldGNoVGFyZ2V0KCk7XG4gIGlmICghdGFyZ2V0KSB7XG4gICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hUYWJJZChudWxsKTtcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihudWxsKTtcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCB1cmwgPSBgaHR0cHM6Ly94LmNvbS8ke3RhcmdldC5oYW5kbGV9L3N0YXR1cy8ke3RhcmdldC50d2VldElkfWA7XG4gIGxldCB0YWJJZCA9IGF3YWl0IGdldFJlZmV0Y2hUYWJJZCgpO1xuICBpZiAodGFiSWQgIT09IG51bGwpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmdldCh0YWJJZCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICB0YWJJZCA9IG51bGw7XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgaWYgKHRhYklkID09PSBudWxsKSB7XG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xuICAgICAgaWYgKHR5cGVvZiB0YWIuaWQgPT09ICdudW1iZXInKSBhd2FpdCBzZXRSZWZldGNoVGFiSWQodGFiLmlkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XG4gICAgfVxuICAgIHNlc3MgPSAoYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKSkgPz8gc2VzcztcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xuICAgICAgdHdlZXRJZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBuYXZpZ2F0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgaW5mbygncmVmZXRjaCB0aWNrJywge1xuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgcmVtYWluaW5nOiBhd2FpdCByZWZldGNoUXVldWVUb3RhbCgpLFxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBzZXNzLnRvdGFsQXRTdGFydCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybigncmVmZXRjaCBuYXZpZ2F0ZSBmYWlsZWQ7IGRyb3BwaW5nIHRhcmdldCcsIHtcbiAgICAgIGhhbmRsZTogdGFyZ2V0LmhhbmRsZSxcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICB9KTtcbiAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaCh0YXJnZXQuaGFuZGxlLCB0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG4vLyAtLS0gTWVkaWEtY3Jhd2wgbG9vcCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy9cbi8vIE1pcnJvcnMgdGhlIHJlZmV0Y2ggbG9vcCBidXQgdGFyZ2V0cyB0aGUgbWVkaWEtY3Jhd2wgcXVldWU6IHR3ZWV0cyB0aGF0XG4vLyB0aGUgbm9ybWFsaXplciBvYnNlcnZlZCB2aWEgdGhlIE1lZGlhIHRhYiAvIFVzZXJNZWRpYSBlbmRwb2ludCB3aXRoXG4vLyBpbnN1ZmZpY2llbnQgZGF0YSB0byBidWlsZCBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBUaGUgY3Jhd2wgbG9vcCB3YWxrc1xuLy8gYSBkZWRpY2F0ZWQgdGFiIHRocm91Z2ggZWFjaCB0d2VldCdzIGRldGFpbCBwYWdlIChoYW5kbGUtbGVzcyBVUkwgZm9ybVxuLy8gd2hlbiB0aGUgaGludC1oYW5kbGUgaXMgbWlzc2luZyksIGF0IHRoZSBhdXRvLXNjcm9sbCBjYWRlbmNlLCBzbyB0aGVcbi8vIHBhZ2UtaG9vayBjYW4gY2FwdHVyZSB0aGUgcmVhbCB0d2VldCBzaGFwZS5cblxuY29uc3QgTUVESUFfQ1JBV0xfVEFCX0tFWSA9ICdfX2ltbV9hcmNoaXZlX21lZGlhX2NyYXdsX3RhYl9pZF9fJztcblxuYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFRhYklkKCk6IFByb21pc2U8bnVtYmVyIHwgbnVsbD4ge1xuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KE1FRElBX0NSQVdMX1RBQl9LRVkpO1xuICBjb25zdCBpZCA9IHN0b3JlZFtNRURJQV9DUkFXTF9UQUJfS0VZXTtcbiAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ251bWJlcicgPyBpZCA6IG51bGw7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldE1lZGlhQ3Jhd2xUYWJJZChpZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoaWQgPT09IG51bGwpIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5yZW1vdmUoTUVESUFfQ1JBV0xfVEFCX0tFWSk7XG4gIGVsc2UgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtNRURJQV9DUkFXTF9UQUJfS0VZXTogaWQgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHRvdGFsID0gYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTtcbiAgaWYgKHRvdGFsID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IG5vdGhpbmcgcXVldWVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcbiAgKTtcbiAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oe1xuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXG4gICAgcHJvY2Vzc2VkOiAwLFxuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIGluZmxpZ2h0OiBudWxsLFxuICB9KTtcbiAgc3RhcnRNZWRpYUNyYXdsSW50ZXJ2YWwoc2Vjb25kcyk7XG4gIHZvaWQgbWVkaWFDcmF3bFRpY2soKTtcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBzdGFydGVkJywgeyBxdWV1ZWQ6IHRvdGFsLCBpbnRlcnZhbF9zZWM6IHNlY29uZHMgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmxldCBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGU6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzOiBudW1iZXIpOiB2b2lkIHtcbiAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgY2xlYXJJbnRlcnZhbChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUpO1xuICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgdm9pZCBtZWRpYUNyYXdsVGljaygpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybignbWVkaWEtY3Jhd2wgdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIH0pO1xuICB9LCBzZWNvbmRzICogMTAwMCk7XG59XG5cbmZ1bmN0aW9uIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTogdm9pZCB7XG4gIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XG4gICAgbWVkaWFDcmF3bEludGVydmFsSGFuZGxlID0gbnVsbDtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxNZWRpYUNyYXdsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignbWVkaWEtY3Jhd2wtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxuICBjb25zdCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQobnVsbCk7XG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihudWxsKTtcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBjYW5jZWxsZWQnLCB7XG4gICAgaGFkX3RhYjogdGFiSWQgIT09IG51bGwsXG4gICAgcHJvY2Vzc2VkOiBzZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG1lZGlhQ3Jhd2xUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGlmIChzZXNzID09PSBudWxsKSB7XG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShzZXNzLmluZmxpZ2h0Lm5hdmlnYXRlZEF0KTtcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgb24gdGhlIHBhZ2UtaG9va1xuICAgIH1cbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XG4gICAgICB0d2VldF9pZDogc2Vzcy5pbmZsaWdodC50d2VldElkLFxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxuICAgIH0pO1xuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgfVxuXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRNZWRpYUNyYXdsVGFyZ2V0KCk7XG4gIGlmICghdGFyZ2V0KSB7XG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZChudWxsKTtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihudWxsKTtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIFNraXAgaWYgYWxyZWFkeSBpbiB0aGUgYXJjaGl2ZSBcdTIwMTQgcGFydGlhbCBjYXB0dXJlcyBjYW4gb3V0bGl2ZSBhXG4gIC8vIHNlcGFyYXRlIGZ1bGwgY2FwdHVyZSBwYXRoLlxuICBpZiAoYXdhaXQgaXNDb21taXR0ZWQodGFyZ2V0LnR3ZWV0SWQpKSB7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBBbHdheXMgdXNlIHRoZSBleHBsaWNpdCBoYW5kbGUgVVJMIHdoZW4gd2Uga25vdyBvbmUuIFRoZSBoYW5kbGUtbGVzc1xuICAvLyBgaS9zdGF0dXMvPGlkPmAgZm9ybSBoYXMgc3VyZmFjZWQgYXMgXCJ0aGlzIHBhZ2UgZG9lc24ndCBleGlzdFwiIGluXG4gIC8vIHByYWN0aWNlIChYJ3Mgcm91dGVyIGRvZXNuJ3QgYWx3YXlzIHJlc29sdmUgaXQgZm9yIHR3ZWV0cyB0aGF0IG5lZWQgYVxuICAvLyBsb2dpbiB3YWxsIG9yIGhhdmUgYXV0aG9yLWNvbnRleHQgcmVkaXJlY3RzKS5cbiAgY29uc3QgdXJsID1cbiAgICB0YXJnZXQuYnVja2V0ID09PSAnX3Vua25vd24nXG4gICAgICA/IGBodHRwczovL3guY29tL2kvc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YFxuICAgICAgOiBgaHR0cHM6Ly94LmNvbS8ke3RhcmdldC5idWNrZXR9L3N0YXR1cy8ke3RhcmdldC50d2VldElkfWA7XG4gIGxldCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xuICBpZiAodGFiSWQgIT09IG51bGwpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmdldCh0YWJJZCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICB0YWJJZCA9IG51bGw7XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgaWYgKHRhYklkID09PSBudWxsKSB7XG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xuICAgICAgaWYgKHR5cGVvZiB0YWIuaWQgPT09ICdudW1iZXInKSBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQodGFiLmlkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XG4gICAgfVxuICAgIHNlc3MgPSAoYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKSkgPz8gc2VzcztcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xuICAgICAgdHdlZXRJZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBuYXZpZ2F0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgdGljaycsIHtcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIGhpbnRfaGFuZGxlOiB0YXJnZXQuYnVja2V0ID09PSAnX3Vua25vd24nID8gbnVsbCA6IHRhcmdldC5idWNrZXQsXG4gICAgICByZW1haW5pbmc6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bCBuYXZpZ2F0ZSBmYWlsZWQ7IGRyb3BwaW5nIHRhcmdldCcsIHtcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICB9KTtcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG4vLyAtLS0gUXVhcmFudGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBxdWFyYW50aW5lKFxuICByZWFzb246IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgdXJsOiBzdHJpbmcsXG4gIHJhdzogdW5rbm93bixcbiAgZXJyOiB1bmtub3duXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgbG9nRXJyKCdxdWFyYW50aW5pbmcgY2FwdHVyZScsIHsgcmVhc29uLCBlbmRwb2ludCwgdXJsLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSByZXR1cm47XG4gIGNvbnN0IHBheWxvYWQ6IFF1YXJhbnRpbmVQYXlsb2FkID0ge1xuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgIHJlYXNvbixcbiAgICBlbmRwb2ludCxcbiAgICBjYXB0dXJlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNvdXJjZV91cmw6IHVybCxcbiAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIHJhdyxcbiAgfTtcbiAgY29uc3QgdHMgPSBpc29Db21wYWN0KHBheWxvYWQuY2FwdHVyZWRfYXQpO1xuICBjb25zdCBoYXNoID0gYXdhaXQgc2hhOChKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XG4gIGNvbnN0IHBhdGggPSBgcmF3L19xdWFyYW50aW5lLyR7dHN9LSR7aGFzaH0uanNvbmA7XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgYXdhaXQgY2xpZW50LnB1dEZpbGUoe1xuICAgICAgcGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHBheWxvYWQsIG51bGwsIDIpICsgJ1xcbicpLFxuICAgICAgbWVzc2FnZTogYHF1YXJhbnRpbmU6ICR7cmVhc29ufSAke2VuZHBvaW50fWAsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKHFlcnIpIHtcbiAgICBhd2FpdCBsb2dFcnIoJ3F1YXJhbnRpbmUgY29tbWl0IGZhaWxlZCcsIHsgLi4uZGVzY3JpYmVFcnJvcihxZXJyKSB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzaGE4KHM6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGJ1ZiA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcbiAgY29uc3QgZGlnZXN0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBidWYpO1xuICBjb25zdCBoZXggPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGRpZ2VzdCkpXG4gICAgLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcbiAgICAuam9pbignJyk7XG4gIHJldHVybiBoZXguc2xpY2UoMCwgOCk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHZlcmlmaWNhdGlvbiAmIGFjY291bnRzIGxpc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5Q29ubmVjdGlvbihmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgbG9naW46IG51bGwsXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGlmICghZm9yY2UpIHtcbiAgICAvLyBTa2lwIGlmIHdlJ3JlIGluc2lkZSB0aGUgcmVwb3J0ZWQgcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IHJlLWNoZWNraW5nXG4gICAgLy8gYmVmb3JlIHJlc2V0IGp1c3Qgd2FzdGVzIG1vcmUgb2YgdGhlIHNhbWUgZXhoYXVzdGVkIHF1b3RhIGFuZCBrZWVwc1xuICAgIC8vIHRoZSA0MDNzIGNvbWluZy5cbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xuICAgICAgY29uc3Qgbm93U2VjID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gICAgICBpZiAobm93U2VjIDwgY29ubi5yYXRlTGltaXRSZXNldEF0KSByZXR1cm47XG4gICAgfVxuICAgIC8vIEFwcGx5IHRoZSBwZXJpb2RpYy1jaGVjayBnYXRlIHRvIGV2ZXJ5IHN0YXR1cywgbm90IGp1c3QgJ29rJy4gVGhlXG4gICAgLy8gcHJldmlvdXMgYmVoYXZpb3IgcmUtdmVyaWZpZWQgb24gZXZlcnkgd2FrZSB3aGVuZXZlciB0aGUgY29ubmVjdGlvblxuICAgIC8vIHdhc24ndCAnb2snLCB3aGljaCBkdXJpbmcgYSByYXRlLWxpbWl0IHdpbmRvdyBtZWFudCAyIEFQSSBjYWxscyBwZXJcbiAgICAvLyBTVyB3YWtlICh2ZXJpZnlSZXBvQWNjZXNzIGRvZXMgR0VUIC91c2VyICsgR0VUIC9yZXBvcy97b30ve3J9KS5cbiAgICBpZiAoY29ubi5jaGVja2VkQXQpIHtcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGNvbm4uY2hlY2tlZEF0KTtcbiAgICAgIGlmIChhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHIgPSBhd2FpdCBjbGllbnQudmVyaWZ5UmVwb0FjY2VzcygpO1xuICAgIC8vIFByb2JlIHRoZSBjb25maWd1cmVkIGJyYW5jaC4gQSBub24tZGVmYXVsdCBicmFuY2ggaXMgZmluZSBcdTIwMTQgaXQnc1xuICAgIC8vIHJvdXRpbmUgdG8gY2FwdHVyZSBpbnRvIGEgd29ya2luZyBicmFuY2ggXHUyMDE0IGJ1dCBhICptaXNzaW5nKiBicmFuY2hcbiAgICAvLyB3b3VsZCA0MjIgZXZlcnkgY29tbWl0LlxuICAgIGxldCBicmFuY2hPayA9IHRydWU7XG4gICAgaWYgKHNldHRpbmdzLmJyYW5jaCAmJiBzZXR0aW5ncy5icmFuY2ggIT09IHIuZGVmYXVsdF9icmFuY2gpIHtcbiAgICAgIGJyYW5jaE9rID0gYXdhaXQgY2xpZW50LmJyYW5jaEV4aXN0cyhzZXR0aW5ncy5icmFuY2gpO1xuICAgIH1cbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1czogJ29rJyxcbiAgICAgIGxvZ2luOiByLmxvZ2luLFxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlcnJvcjogbnVsbCxcbiAgICAgIGRlZmF1bHRCcmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXG4gICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBicmFuY2hPayxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgfSk7XG4gICAgYXdhaXQgaW5mbygnY29ubmVjdGlvbiB2ZXJpZmllZCcsIHtcbiAgICAgIGxvZ2luOiByLmxvZ2luLFxuICAgICAgcmVwbzogci5mdWxsX25hbWUsXG4gICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRfYnJhbmNoOiBzZXR0aW5ncy5icmFuY2gsXG4gICAgICBjb25maWd1cmVkX2JyYW5jaF9leGlzdHM6IGJyYW5jaE9rLFxuICAgIH0pO1xuICAgIGlmICghYnJhbmNoT2spIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2NvbmZpZ3VyZWQgYnJhbmNoIGRvZXMgbm90IGV4aXN0IG9uIHJlbW90ZScsIHtcbiAgICAgICAgY29uZmlndXJlZDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgICAgZml4OiAnb3BlbiBTZXR0aW5ncyBhbmQgY2hhbmdlIGJyYW5jaCB0byAnICsgci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc3QgY2F0ID0gZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgPyBlcnIuY2F0ZWdvcnkgOiAndW5rbm93bic7XG4gICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgIGNhdCA9PT0gJ2F1dGgnXG4gICAgICAgID8gJ2F1dGgtZXJyb3InXG4gICAgICAgIDogY2F0ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgOiBjYXQgPT09ICduZXR3b3JrJ1xuICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgIDogJ2F1dGgtZXJyb3InO1xuICAgIGNvbnN0IHJlc2V0QXQgPVxuICAgICAgZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgY2F0ID09PSAncmF0ZS1saW1pdCcgPyBlcnIucmF0ZUxpbWl0UmVzZXRBdCA6IG51bGw7XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXMsXG4gICAgICBsb2dpbjogbnVsbCxcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKS5tZXNzYWdlLFxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiByZXNldEF0LFxuICAgIH0pO1xuICAgIGF3YWl0IHdhcm4oJ2Nvbm5lY3Rpb24gY2hlY2sgZmFpbGVkJywge1xuICAgICAgY2F0ZWdvcnk6IGNhdCxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjY291bnRzTGlzdChmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0KSB7XG4gICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICghZm9yY2UpIHtcbiAgICAvLyBTa2lwIHdoaWxlIGluc2lkZSBhIGtub3duIHJhdGUtbGltaXQgd2luZG93IFx1MjAxNCBhY2NvdW50cy55YW1sIGlzIGZldGNoZWRcbiAgICAvLyB2aWEgYXV0aGVudGljYXRlZCByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLCB3aGljaCBjb3VudHMgYWdhaW5zdCB0aGVcbiAgICAvLyBzYW1lIHF1b3RhLlxuICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcbiAgICAgIGNvbnN0IG5vd1NlYyA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBTa2lwIGlmIHdlIHJlZnJlc2hlZCByZWNlbnRseS4gYWNjb3VudHMueWFtbCBjaGFuZ2VzIHJhcmVseSBcdTIwMTQgdGhlIG9sZFxuICAgIC8vIGNvZGUgcmUtZmV0Y2hlZCBpdCBvbiBldmVyeSBTVyB3YWtlLCB3aGljaCBkdXJpbmcgaGVhdnkgYnJvd3NpbmcgbWVhbnRcbiAgICAvLyBhIEdpdEh1YiBjYWxsIGV2ZXJ5IGZldyBzZWNvbmRzIGV2ZW4gd2hlbiBub3RoaW5nIHdhcyBiZWluZyBjYXB0dXJlZC5cbiAgICBjb25zdCBsYXN0UmVmcmVzaGVkID0gYXdhaXQgZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpO1xuICAgIGlmIChsYXN0UmVmcmVzaGVkKSB7XG4gICAgICBjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShsYXN0UmVmcmVzaGVkKTtcbiAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYWdlKSAmJiBhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCBjbGllbnQuZmV0Y2hSYXdUZXh0KCdjb25maWcvYWNjb3VudHMueWFtbCcpO1xuICAgIGlmICghdGV4dCkge1xuICAgICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIG5vdCBmb3VuZCBpbiByZXBvOyB1c2luZyBmYWxsYmFjaycpO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlQWNjb3VudHNZYW1sKHRleHQpO1xuICAgIGlmIChwYXJzZWQubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIHBhcnNlZCBlbXB0eTsga2VlcGluZyBmYWxsYmFjaycpO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGF3YWl0IHNldEFjY291bnRzKHBhcnNlZCk7XG4gICAgYXdhaXQgc2V0QWNjb3VudHNSZWZyZXNoZWRBdChuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xuICAgIGlmIChmb3JjZSkgYXdhaXQgaW5mbygnYWNjb3VudHMgbGlzdCByZWZyZXNoZWQnLCB7IGNvdW50OiBwYXJzZWQubGVuZ3RoIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdyZWZyZXNoIGFjY291bnRzIGZhaWxlZDsga2VlcGluZyBjdXJyZW50IGxpc3QnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbi8vIC0tLSBTdGF0ZSBicm9hZGNhc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gYnJvYWRjYXN0U3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgYnVpbGRTdGF0ZSgpO1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCB0YWJDb3VudCA9IDA7XG4gIHRyeSB7XG4gICAgY29uc3QgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gICAgdGFiQ291bnQgPSB0YWJzLmxlbmd0aDtcbiAgfSBjYXRjaCB7XG4gICAgLy8gdGFicy5xdWVyeSBpcyBhbGxvd2VkIGJ5IHRoZSBtYW5pZmVzdCBidXQgY2FuIHRyYW5zaWVudGx5IGZhaWxcbiAgICAvLyBhcm91bmQgZXh0ZW5zaW9uIHN0YXJ0dXA7IHN1cmZhY2luZyAwIGlzIGZpbmUuXG4gIH1cbiAgY29uc3QgcmVmZXRjaFF1ZXVlZCA9IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xRdWV1ZWQgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xTZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgY29uc3QgYXV0b1Njcm9sbFNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICByZXR1cm4ge1xuICAgIHZlcnNpb246IEVYVF9WRVJTSU9OLFxuICAgIHNldHRpbmdzOiByZWRhY3RTZXR0aW5ncyhzZXR0aW5ncyksXG4gICAgY29ubmVjdGlvbjogY29ubixcbiAgICBhY2NvdW50cyxcbiAgICBjb3VudGVycyxcbiAgICBhdXRvU2Nyb2xsOiB7XG4gICAgICBhY3RpdmU6IGF1dG9TY3JvbGxTZXNzICE9PSBudWxsICYmIGF1dG9TY3JvbGxUaW1lciAhPT0gbnVsbCxcbiAgICAgIHRhYkNvdW50LFxuICAgICAgc2Nyb2xsQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxuICAgICAgaW5nZXN0ZWRDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkQ291bnQgPz8gMCxcbiAgICAgIGV4cGFuZGVkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5leHBhbmRlZENvdW50ID8/IDAsXG4gICAgfSxcbiAgICByZWZldGNoUXVldWU6IHtcbiAgICAgIHRvdGFsOiByZWZldGNoUXVldWVkLFxuICAgICAgcnVubmluZzogcmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsLFxuICAgICAgcHJvY2Vzc2VkOiByZWZldGNoU2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gICAgICB0b3RhbF9hdF9zdGFydDogcmVmZXRjaFNlc3M/LnRvdGFsQXRTdGFydCA/PyAwLFxuICAgIH0sXG4gICAgbWVkaWFDcmF3bFF1ZXVlOiB7XG4gICAgICB0b3RhbDogbWVkaWFDcmF3bFF1ZXVlZCxcbiAgICAgIHJ1bm5pbmc6IG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcbiAgICAgIHByb2Nlc3NlZDogbWVkaWFDcmF3bFNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IG1lZGlhQ3Jhd2xTZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcbiAgICB9LFxuICB9O1xufVxuXG5mdW5jdGlvbiByZWRhY3RTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IEV4dGVuc2lvblN0YXRlWydzZXR0aW5ncyddIHtcbiAgcmV0dXJuIHtcbiAgICBvd25lcjogcy5vd25lcixcbiAgICByZXBvOiBzLnJlcG8sXG4gICAgYnJhbmNoOiBzLmJyYW5jaCxcbiAgICBlbmFibGVkOiBzLmVuYWJsZWQsXG4gICAgYXV0b0NhcHR1cmU6IHMuYXV0b0NhcHR1cmUsXG4gICAgY29uZmlndXJlZEF0OiBzLmNvbmZpZ3VyZWRBdCxcbiAgICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IHMuYXV0b1Njcm9sbEludGVydmFsU2VjLFxuICAgIHBhdFNldDogcy5wYXQubGVuZ3RoID4gMCxcbiAgICBwYXRTdWZmaXg6IHMucGF0Lmxlbmd0aCA+PSA0ID8gcy5wYXQuc2xpY2UoLTQpIDogJycsXG4gIH07XG59XG5cbmZ1bmN0aW9uIGlzb0NvbXBhY3QoaXNvOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyAyMDI1LTA0LTEyVDE0OjIzOjAxLjAwMFogXHUyMTkyIDIwMjUtMDQtMTJUMTQyMzAxWlxuICBjb25zdCBkID0gbmV3IERhdGUoaXNvKTtcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBpc28ucmVwbGFjZSgvWzouXS9nLCAnJyk7XG4gIGNvbnN0IHBhZCA9IChuOiBudW1iZXIsIHcgPSAyKSA9PiBTdHJpbmcobikucGFkU3RhcnQodywgJzAnKTtcbiAgcmV0dXJuIChcbiAgICBgJHtkLmdldFVUQ0Z1bGxZZWFyKCl9LSR7cGFkKGQuZ2V0VVRDTW9udGgoKSArIDEpfS0ke3BhZChkLmdldFVUQ0RhdGUoKSl9YCArXG4gICAgYFQke3BhZChkLmdldFVUQ0hvdXJzKCkpfSR7cGFkKGQuZ2V0VVRDTWludXRlcygpKX0ke3BhZChkLmdldFVUQ1NlY29uZHMoKSl9WmBcbiAgKTtcbn1cblxuZnVuY3Rpb24gdmlld2VyVXJsKHM6IFNldHRpbmdzKTogc3RyaW5nIHtcbiAgcmV0dXJuIGBodHRwczovLyR7cy5vd25lcn0uZ2l0aHViLmlvLyR7cy5yZXBvfS9gO1xufVxuXG4vKipcbiAqIFdhbGsgYG5vZGVgIGNvbGxlY3RpbmcgZG90dGVkIGtleSBwYXRocyB1cCB0byBgbWF4RGVwdGhgIGRlZXAuIEFycmF5XG4gKiBpbmRpY2VzIGNvbGxhcHNlIHRvIGBbMF1gICh3ZSBvbmx5IGRlc2NlbmQgaW50byB0aGUgZmlyc3QgZWxlbWVudCkuIFVzZWRcbiAqIHRvIHN1cmZhY2UgdGhlIHN0cnVjdHVyYWwgc2tlbGV0b24gb2YgYW4gdW5mYW1pbGlhciBHcmFwaFFMIHJlc3BvbnNlXG4gKiB3aXRob3V0IGluY2x1ZGluZyBhbnkgZGF0YSB2YWx1ZXMuXG4gKi9cbi8qKiBDb2xsZWN0IGV2ZXJ5IGRpc3RpbmN0IGBfX3R5cGVuYW1lYCB2YWx1ZSBmb3VuZCBhbnl3aGVyZSBpbiB0aGUgdHJlZS4gKi9cbmZ1bmN0aW9uIHByb2JlVHlwZW5hbWVzKG5vZGU6IHVua25vd24pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKHR5cGVvZiBvYmouX190eXBlbmFtZSA9PT0gJ3N0cmluZycpIHNlZW4uYWRkKG9iai5fX3R5cGVuYW1lKTtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBbLi4uc2Vlbl0uc29ydCgpO1xufVxuXG4vKipcbiAqIEZpbmQgdGhlIGZpcnN0IG5vZGUgYW55d2hlcmUgaW4gdGhlIHRyZWUgd2hvc2UgYF9fdHlwZW5hbWVgIG1hdGNoZXMgYW5kXG4gKiByZXR1cm4gaXRzIHRvcC1sZXZlbCBrZXkgbGlzdCAoc29ydGVkKS4gVXNlZnVsIGZvciBkaXNjb3ZlcmluZyB3aGF0IGZpZWxkc1xuICogWCBpcyBhY3R1YWxseSBzaGlwcGluZyBmb3IgYSBnaXZlbiBub2RlIHR5cGUgYWZ0ZXIgYSBzY2hlbWEgY2hhbmdlLlxuICovXG5mdW5jdGlvbiBwcm9iZUZpcnN0VHlwZVNoYXBlKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcpOiBzdHJpbmdbXSB8IG51bGwge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobiA9PT0gbnVsbCB8fCB0eXBlb2YgbiAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShuKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG9iaiA9IG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBpZiAob2JqLl9fdHlwZW5hbWUgPT09IHR5cGVuYW1lKSB7XG4gICAgICAgIHJldHVybiBPYmplY3Qua2V5cyhvYmopLnNvcnQoKTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vKipcbiAqIEZpbmQgdGhlIGZpcnN0IG5vZGUgd2l0aCBgX190eXBlbmFtZSA9PT0gdHlwZW5hbWVgLCB0aGVuIGRlc2NlbmQgdGhyb3VnaFxuICogdGhlIGdpdmVuIGtleSBwYXRoLCBhbmQgcmV0dXJuIHRoZSB0b3AtbGV2ZWwga2V5cyBvZiB3aGF0ZXZlciBpcyBhdCB0aGVcbiAqIGVuZC4gUmV0dXJucyBhIG1hcmtlciBzdHJpbmcgd2hlbiB0aGUgcGF0aCBsZWFkcyBzb21ld2hlcmUgbm9uLW9iamVjdCBzb1xuICogd2UgY2FuIHRlbGwgYXBhcnQgXCJhYnNlbnRcIiBmcm9tIFwicHJlc2VudCBidXQgbm90IGFuIG9iamVjdFwiLlxuICovXG5mdW5jdGlvbiBwcm9iZVR5cGVkTmVzdGVkKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcsIHBhdGg6IHN0cmluZ1tdKTogdW5rbm93biB7XG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIGxldCBmb3VuZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsID0gbnVsbDtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSB0eXBlbmFtZSkge1xuICAgICAgICBmb3VuZCA9IG9iajtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICBpZiAoIWZvdW5kKSByZXR1cm4gbnVsbDtcbiAgbGV0IGN1cjogdW5rbm93biA9IGZvdW5kO1xuICBmb3IgKGNvbnN0IHNlZyBvZiBwYXRoKSB7XG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgcmV0dXJuIGA8JHtjdXIgPT09IG51bGwgPyAnbnVsbCcgOiB0eXBlb2YgY3VyfT5gO1xuICAgIGN1ciA9IChjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW3NlZ107XG4gIH1cbiAgaWYgKGN1ciA9PT0gdW5kZWZpbmVkKSByZXR1cm4gJzxtaXNzaW5nPic7XG4gIGlmIChjdXIgPT09IG51bGwpIHJldHVybiAnPG51bGw+JztcbiAgaWYgKHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSByZXR1cm4gYDwke3R5cGVvZiBjdXJ9PmA7XG4gIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHJldHVybiBgPGFycmF5IGxlbj0ke2N1ci5sZW5ndGh9PmA7XG4gIHJldHVybiBPYmplY3Qua2V5cyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLnNvcnQoKTtcbn1cblxuZnVuY3Rpb24gc2hvcnRlblVybCh1OiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBBY3Rpdml0eS10YWlsIGNvbnRleHQgaXMgbW9yZSB1c2VmdWwgd2l0aCBqdXN0IHRoZSBwYXRoOyBmdWxsIFVSTHMgYmVjb21lXG4gIC8vIGhhcmQgdG8gcmVhZCBhdCB0aGUgc2lkZWJhcidzIHdpZHRoLlxuICB0cnkge1xuICAgIGNvbnN0IHBhcnNlZCA9IG5ldyBVUkwodSk7XG4gICAgY29uc3QgcGF0aCA9IHBhcnNlZC5wYXRobmFtZSArIChwYXJzZWQuc2VhcmNoID8gJz9cdTIwMjYnIDogJycpO1xuICAgIHJldHVybiBwYXJzZWQuaG9zdCA9PT0gJ3guY29tJyB8fCBwYXJzZWQuaG9zdCA9PT0gJ3R3aXR0ZXIuY29tJ1xuICAgICAgPyBwYXRoXG4gICAgICA6IGAke3BhcnNlZC5ob3N0fSR7cGF0aH1gO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gdS5sZW5ndGggPiA4MCA/IGAke3Uuc2xpY2UoMCwgODApfVx1MjAyNmAgOiB1O1xuICB9XG59XG5cbi8vIC0tLSBEZXYgaGVscGVycyBleHBvc2VkIG9uIGdsb2JhbFRoaXMgZm9yIHRoZSBkZXZ0b29scyBjb25zb2xlIC0tLS0tLS0tLS1cbi8vIChlLmcuIGBfX2ltbUFyY2hpdmUuY2xlYXJBbGwoKWAgaW4gdGhlIGJhY2tncm91bmQgd29ya2VyJ3MgZGV2dG9vbHMpLlxuXG4oZ2xvYmFsVGhpcyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuX19pbW1BcmNoaXZlID0ge1xuICBjbGVhckFsbCxcbiAgYWN0aXZpdHk6IGdldEFjdGl2aXR5LFxuICBhY2NvdW50czogZ2V0QWNjb3VudHMsXG4gIGJ1ZmZlcnM6IGdldFJ1bkJ1ZmZlcnMsXG4gIGZsdXNoQWxsOiAoKSA9PiBmbHVzaEFsbCgnZGV2dG9vbHMnKSxcbiAgc3RhdGU6IGJ1aWxkU3RhdGUsXG4gIHJlZmV0Y2hRdWV1ZTogZ2V0UmVmZXRjaFF1ZXVlLFxuICBzdGFydFJlZmV0Y2g6IHN0YXJ0UmVmZXRjaExvb3AsXG4gIGNhbmNlbFJlZmV0Y2g6IGNhbmNlbFJlZmV0Y2hMb29wLFxuICBtZWRpYUNyYXdsUXVldWU6IGdldE1lZGlhQ3Jhd2xRdWV1ZSxcbiAgc3RhcnRNZWRpYUNyYXdsOiBzdGFydE1lZGlhQ3Jhd2xMb29wLFxuICBjYW5jZWxNZWRpYUNyYXdsOiBjYW5jZWxNZWRpYUNyYXdsTG9vcCxcbn07XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRU8sSUFBTSxtQkFBNkI7QUFBQSxFQUN4QyxLQUFLO0FBQUEsRUFDTCxPQUFPO0FBQUEsRUFDUCxNQUFNO0FBQUE7QUFBQTtBQUFBLEVBR04sUUFBUTtBQUFBLEVBQ1IsU0FBUztBQUFBLEVBQ1QsYUFBYTtBQUFBLEVBQ2IsY0FBYztBQUFBLEVBQ2QsdUJBQXVCO0FBQ3pCO0FBRU8sSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxzQkFBc0I7QUFJNUIsSUFBTSxvQkFBcUM7QUFBQSxFQUNoRCxFQUFFLFFBQVEsVUFBVSxPQUFPLG1DQUFtQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsVUFBVSxPQUFPLDRDQUE0QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsT0FBTyxPQUFPLHNDQUFzQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsU0FBUyxPQUFPLDZDQUE2QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsY0FBYyxPQUFPLG1CQUFtQixVQUFVLE9BQU87QUFBQSxFQUNuRSxFQUFFLFFBQVEsWUFBWSxPQUFPLCtCQUErQixVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLGtDQUFrQyxVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLDRCQUE0QixVQUFVLE9BQU87QUFBQSxFQUN2RSxFQUFFLFFBQVEsbUJBQW1CLE9BQU8scUJBQXFCLFVBQVUsT0FBTztBQUM1RTtBQUdPLElBQU0sa0JBQXVDLG9CQUFJLElBQUk7QUFBQSxFQUMxRDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQVdNLElBQU0sb0JBQXlDLG9CQUFJLElBQUksQ0FBQyxvQkFBb0IsY0FBYyxDQUFDO0FBdUIzRixJQUFNLHdCQUF3QjtBQUc5QixJQUFNLGdCQUFnQjtBQUd0QixJQUFNLHNCQUFzQjtBQUc1QixJQUFNLG9CQUFvQjtBQUcxQixJQUFNLGdDQUFnQyxLQUFLLEtBQUs7QUFFaEQsSUFBTSxtQkFBbUI7OztBQ3RFaEMsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0I7QUFFeEIsSUFBSSxrQkFBb0M7QUFDeEMsSUFBSSxzQkFBcUM7QUFFekMsU0FBUyxTQUFTLEtBQXlCO0FBQ3pDLE1BQUksSUFBSTtBQUNSLGFBQVcsS0FBSyxJQUFLLE1BQUssT0FBTyxhQUFhLENBQUM7QUFDL0MsU0FBTyxLQUFLLENBQUM7QUFDZjtBQUVBLFNBQVMsV0FBVyxHQUF1QjtBQUN6QyxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFFBQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxNQUFNO0FBQ3JDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUssS0FBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFDOUQsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUU7QUFDaEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDL0QsUUFBTSxJQUFJLE9BQU8sZ0JBQWdCO0FBQ2pDLE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsV0FBTyxFQUFFLFNBQVMsR0FBRyxNQUFNLFdBQVcsQ0FBQyxFQUFFO0FBQUEsRUFDM0M7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxRQUFNLFVBQVUsU0FBUyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0FBQy9ELFNBQU8sRUFBRSxTQUFTLEtBQUs7QUFDekI7QUFFQSxlQUFlLFlBQWdDO0FBQzdDLFFBQU0sRUFBRSxTQUFTLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUNqRCxNQUFJLG9CQUFvQixRQUFRLHdCQUF3QixTQUFTO0FBQy9ELFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFO0FBQUEsSUFDN0IsR0FBRyxRQUFRLFFBQVEsRUFBRSxJQUFJLFFBQVEsUUFBUSxZQUFZLEVBQUUsT0FBTztBQUFBLEVBQ2hFO0FBQ0EsUUFBTSxXQUFXLElBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNO0FBQ3pELFdBQVMsSUFBSSxNQUFNLENBQUM7QUFDcEIsV0FBUyxJQUFJLE1BQU0sS0FBSyxNQUFNO0FBQzlCLFFBQU0sT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUTtBQUMzRCxRQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLE1BQU0sRUFBRSxNQUFNLFVBQVUsR0FBRyxPQUFPO0FBQUEsSUFDakY7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBQ0Qsb0JBQWtCO0FBQ2xCLHdCQUFzQjtBQUN0QixTQUFPO0FBQ1Q7QUFFTyxTQUFTLGVBQWUsR0FBb0I7QUFDakQsU0FBTyxFQUFFLFdBQVcsZUFBZTtBQUNyQztBQUVBLGVBQXNCLFdBQVcsV0FBb0M7QUFDbkUsTUFBSSxDQUFDLFVBQVcsUUFBTztBQUN2QixRQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFFBQU0sS0FBSyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3BELFFBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLElBQzdCLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxJQUN0QjtBQUFBLElBQ0EsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTO0FBQUEsRUFDcEM7QUFDQSxTQUFPLEdBQUcsZUFBZSxHQUFHLFNBQVMsRUFBRSxDQUFDLElBQUksU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMUU7QUFFQSxlQUFzQixXQUFXLFVBQW1DO0FBQ2xFLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFHdEIsTUFBSSxDQUFDLFNBQVMsV0FBVyxlQUFlLEVBQUcsUUFBTztBQUNsRCxRQUFNLFFBQVEsU0FBUyxNQUFNLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxHQUFHO0FBQzlELE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUMvQixRQUFNLENBQUMsT0FBTyxLQUFLLElBQUk7QUFDdkIsTUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFPLFFBQU87QUFDN0IsTUFBSTtBQUNGLFVBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQzdCLEVBQUUsTUFBTSxXQUFXLEdBQXVCO0FBQUEsTUFDMUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDcEMsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7OztBQzVCQSxJQUFNLHFCQUFzQztBQUFBLEVBQzFDLFFBQVE7QUFBQSxFQUNSLE9BQU87QUFBQSxFQUNQLFdBQVc7QUFBQSxFQUNYLE9BQU87QUFBQSxFQUNQLGVBQWU7QUFBQSxFQUNmLHdCQUF3QjtBQUFBLEVBQ3hCLGtCQUFrQjtBQUNwQjtBQUVBLElBQU0sV0FBeUI7QUFBQSxFQUM3QixVQUFVLEVBQUUsR0FBRyxpQkFBaUI7QUFBQSxFQUNoQyxVQUFVLENBQUMsR0FBRyxpQkFBaUI7QUFBQSxFQUMvQixxQkFBcUI7QUFBQSxFQUNyQixZQUFZLEVBQUUsR0FBRyxtQkFBbUI7QUFBQSxFQUNwQyxVQUFVLENBQUM7QUFBQSxFQUNYLFlBQVksQ0FBQztBQUFBLEVBQ2IsVUFBVSxDQUFDO0FBQUEsRUFDWCxnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGNBQWMsQ0FBQztBQUFBLEVBQ2YsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixnQkFBZ0I7QUFBQSxFQUNoQixtQkFBbUI7QUFBQSxFQUNuQixtQkFBbUI7QUFDckI7QUFFQSxlQUFlLE9BQXFDLEtBQWtDO0FBQ3BGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksR0FBRztBQUNsRCxRQUFNLFFBQVEsT0FBTyxHQUFHO0FBQ3hCLE1BQUksVUFBVSxRQUFXO0FBQ3ZCLFdBQU8sZ0JBQWdCLFNBQVMsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxlQUFlLE9BQXFDLEtBQVEsT0FBdUM7QUFDakcsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDO0FBQ2xEO0FBSUEsZUFBc0IsY0FBaUM7QUFLckQsUUFBTSxTQUFTLE1BQU0sT0FBTyxVQUFVO0FBQ3RDLFFBQU0sU0FBUyxFQUFFLEdBQUcsa0JBQWtCLEdBQUcsT0FBTztBQUNoRCxNQUFJLE9BQU8sT0FBTyxlQUFlLE9BQU8sR0FBRyxHQUFHO0FBQzVDLFFBQUk7QUFDRixhQUFPLE1BQU0sTUFBTSxXQUFXLE9BQU8sR0FBRztBQUFBLElBQzFDLFFBQVE7QUFDTixhQUFPLE1BQU07QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLFlBQVksR0FBNEI7QUFHNUQsUUFBTSxVQUFvQixFQUFFLEdBQUcsRUFBRTtBQUNqQyxNQUFJLFFBQVEsT0FBTyxDQUFDLGVBQWUsUUFBUSxHQUFHLEdBQUc7QUFDL0MsWUFBUSxNQUFNLE1BQU0sV0FBVyxRQUFRLEdBQUc7QUFBQSxFQUM1QztBQUNBLFFBQU0sT0FBTyxZQUFZLE9BQU87QUFDbEM7QUFDQSxlQUFzQixlQUFlLE9BQTZDO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxPQUFPLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoQyxRQUFNLFlBQVksSUFBSTtBQUN0QixTQUFPO0FBQ1Q7QUFJQSxlQUFzQixjQUF3QztBQUM1RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQVksR0FBbUM7QUFDbkUsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUM1QjtBQUNBLGVBQXNCLHlCQUFpRDtBQUNyRSxTQUFPLE9BQU8scUJBQXFCO0FBQ3JDO0FBQ0EsZUFBc0IsdUJBQXVCLEtBQW1DO0FBQzlFLFFBQU0sT0FBTyx1QkFBdUIsR0FBRztBQUN6QztBQUlBLGVBQXNCLGdCQUEwQztBQUM5RCxRQUFNLElBQUksTUFBTSxPQUFPLFlBQVk7QUFFbkMsUUFBTSxNQUF1QjtBQUFBLElBQzNCLEdBQUc7QUFBQSxJQUNILGVBQWUsRUFBRSxrQkFBa0IsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUN4RCx3QkFDRSxFQUFFLDJCQUEyQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3BELGtCQUFrQixFQUFFLHFCQUFxQixTQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ2hFO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsY0FBYyxHQUFtQztBQUNyRSxRQUFNLE9BQU8sY0FBYyxDQUFDO0FBQzlCO0FBSUEsU0FBUyxXQUFtQjtBQUMxQixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDN0M7QUFFQSxlQUFzQixjQUF1RDtBQUMzRSxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQ3BCLFFBQ0EsT0FDeUI7QUFDekIsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUs7QUFBQSxJQUN6QixZQUFZO0FBQUEsSUFDWixXQUFXLFNBQVM7QUFBQSxJQUNwQixlQUFlO0FBQUEsSUFDZixnQkFBZ0I7QUFBQSxJQUNoQixlQUFlO0FBQUEsRUFDakI7QUFDQSxNQUFJLElBQUksY0FBYyxTQUFTLEdBQUc7QUFDaEMsUUFBSSxZQUFZLFNBQVM7QUFDekIsUUFBSSxhQUFhO0FBQUEsRUFDbkI7QUFDQSxRQUFNLE9BQXVCLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoRCxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsaUJBQWlCLFFBQWdCLE9BQThCO0FBQ25GLFFBQU0sWUFBWSxRQUFRLEVBQUUsZUFBZSxNQUFNLENBQUM7QUFDcEQ7QUFJQSxlQUFzQixnQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLFlBQVk7QUFDNUI7QUFFQSxlQUFzQixhQUFhLFFBQTJDO0FBQzVFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU0sS0FBSztBQUN4QjtBQUVBLGVBQXNCLGFBQWEsUUFBZ0IsS0FBK0I7QUFDaEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFFQSxlQUFzQixlQUFlLFFBQStCO0FBQ2xFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU07QUFDakIsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUlBLGVBQXNCLGNBQW1DO0FBQ3ZELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBRUEsZUFBc0IsZUFBZSxJQUFtQztBQUN0RSxRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLE1BQUksUUFBUSxFQUFFO0FBQ2QsTUFBSSxJQUFJLFNBQVMsa0JBQW1CLEtBQUksU0FBUztBQUNqRCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGdCQUErQjtBQUNuRCxRQUFNLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDN0I7QUFJQSxlQUFzQixvQkFBNkU7QUFDakcsU0FBTyxPQUFPLGdCQUFnQjtBQUNoQztBQUVBLGVBQXNCLGtCQUNwQixLQUNlO0FBQ2YsUUFBTSxPQUFPLGtCQUFrQixHQUFHO0FBQ3BDO0FBVU8sU0FBUyxjQUNkLE9BQ0EsVUFDQSxTQUNBLFFBQ0EsY0FBdUIsT0FDZjtBQUNSLFNBQU8sR0FBRyxLQUFLLElBQUksUUFBUSxJQUFJLE9BQU8sSUFBSSxNQUFNLElBQUksY0FBYyxNQUFNLEdBQUc7QUFDN0U7QUFHQSxlQUFzQixvQkFBb0IsVUFBbUM7QUFDM0UsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLFFBQU0sU0FBUyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksUUFBUSxFQUFFLFlBQVk7QUFDM0QsTUFBSSxTQUFTO0FBQ2IsYUFBVyxVQUFVLE9BQU8sS0FBSyxHQUFHLEdBQUc7QUFDckMsVUFBTSxRQUFRLElBQUksTUFBTTtBQUN4QixRQUFJLENBQUMsTUFBTztBQUNaLGVBQVcsT0FBTyxPQUFPLEtBQUssS0FBSyxHQUFHO0FBQ3BDLFlBQU0sSUFBSSxNQUFNLEdBQUc7QUFDbkIsVUFBSSxLQUFLLEVBQUUsS0FBSyxRQUFRO0FBQ3RCLGVBQU8sTUFBTSxHQUFHO0FBQ2hCLGtCQUFVO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sS0FBSyxLQUFLLEVBQUUsV0FBVyxFQUFHLFFBQU8sSUFBSSxNQUFNO0FBQUEsRUFDeEQ7QUFDQSxNQUFJLFNBQVMsRUFBRyxPQUFNLGtCQUFrQixHQUFHO0FBQzNDLFNBQU87QUFDVDtBQUlBLGVBQXNCLGtCQUFxRDtBQUN6RSxTQUFPLE9BQU8sY0FBYztBQUM5QjtBQUVBLGVBQXNCLG9CQUFxQztBQUN6RCxRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsTUFBSSxRQUFRO0FBQ1osYUFBVyxPQUFPLE9BQU8sT0FBTyxDQUFDLEVBQUcsVUFBUyxJQUFJO0FBQ2pELFNBQU87QUFDVDtBQUVBLGVBQXNCLGVBQWUsUUFBZ0IsU0FBZ0M7QUFDbkYsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLFFBQU0sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzFCLE1BQUksQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHO0FBQzFCLFFBQUksS0FBSyxPQUFPO0FBQ2hCLE1BQUUsTUFBTSxJQUFJO0FBQ1osVUFBTSxPQUFPLGdCQUFnQixDQUFDO0FBQUEsRUFDaEM7QUFDRjtBQUVBLGVBQXNCLGVBQWUsUUFBZ0IsU0FBZ0M7QUFDbkYsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLFFBQU0sTUFBTSxFQUFFLE1BQU07QUFDcEIsTUFBSSxDQUFDLElBQUs7QUFDVixRQUFNLFdBQVcsSUFBSSxPQUFPLENBQUMsT0FBTyxPQUFPLE9BQU87QUFDbEQsTUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLEVBQUUsTUFBTTtBQUFBLE1BQ3JDLEdBQUUsTUFBTSxJQUFJO0FBQ2pCLFFBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUNoQztBQUVBLGVBQXNCLG9CQUdaO0FBQ1IsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFFBQUksSUFBSSxTQUFTLEVBQUcsUUFBTyxFQUFFLFFBQVEsU0FBUyxJQUFJLENBQUMsRUFBRztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0IscUJBQXdEO0FBQzVFLFNBQU8sT0FBTyxpQkFBaUI7QUFDakM7QUFFQSxlQUFzQix1QkFBd0M7QUFDNUQsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixrQkFBa0IsWUFBMkIsU0FBZ0M7QUFDakcsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLFFBQU0sU0FBUyxjQUFjO0FBQzdCLFFBQU0sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzFCLE1BQUksQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHO0FBQzFCLFFBQUksS0FBSyxPQUFPO0FBQ2hCLE1BQUUsTUFBTSxJQUFJO0FBQ1osVUFBTSxPQUFPLG1CQUFtQixDQUFDO0FBQUEsRUFDbkM7QUFDRjtBQUVBLGVBQXNCLGtCQUFrQixTQUFnQztBQUN0RSxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxVQUFVO0FBQ2QsYUFBVyxVQUFVLE9BQU8sS0FBSyxDQUFDLEdBQUc7QUFDbkMsVUFBTSxNQUFNLEVBQUUsTUFBTTtBQUNwQixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sV0FBVyxJQUFJLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTztBQUNsRCxRQUFJLFNBQVMsV0FBVyxJQUFJLFFBQVE7QUFDbEMsZ0JBQVU7QUFDVixVQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNO0FBQUEsVUFDckMsR0FBRSxNQUFNLElBQUk7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFFBQVMsT0FBTSxPQUFPLG1CQUFtQixDQUFDO0FBQ2hEO0FBRUEsZUFBc0IsdUJBR1o7QUFDUixRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFHO0FBQUEsRUFDeEQ7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixZQUFZLFNBQW1DO0FBQ25FLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxhQUFXLFNBQVMsT0FBTyxPQUFPLEdBQUcsR0FBRztBQUN0QyxRQUFJLFNBQVMsV0FBVyxNQUFPLFFBQU87QUFBQSxFQUN4QztBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLG9CQUFpRDtBQUNyRSxTQUFPLE9BQU8sZ0JBQWdCO0FBQ2hDO0FBQ0EsZUFBc0Isa0JBQWtCLEdBQXNDO0FBQzVFLFFBQU0sT0FBTyxrQkFBa0IsQ0FBQztBQUNsQztBQUNBLGVBQXNCLHVCQUFvRDtBQUN4RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQXNDO0FBQy9FLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQUNBLGVBQXNCLHVCQUEwRDtBQUM5RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQTRDO0FBQ3JGLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQVlBLGVBQXNCLG9CQUFvQixVQU12QztBQUNELFFBQU0sWUFBWSxJQUFJLElBQUksQ0FBQyxHQUFHLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sYUFBYSxDQUFDLE1BQXVCLFVBQVUsSUFBSSxFQUFFLFlBQVksQ0FBQztBQUd4RSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksa0JBQWtCO0FBQ3RCLGFBQVcsS0FBSyxPQUFPLEtBQUssUUFBUSxHQUFHO0FBQ3JDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLFNBQVMsQ0FBQztBQUNqQix5QkFBbUI7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sWUFBWSxRQUFRO0FBR2pDLFFBQU0sVUFBVSxNQUFNLGNBQWM7QUFDcEMsTUFBSSxpQkFBaUI7QUFDckIsYUFBVyxLQUFLLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDcEMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sUUFBUSxDQUFDO0FBQ2hCLHdCQUFrQjtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxjQUFjLE9BQU87QUFHbEMsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLE1BQUksMEJBQTBCO0FBQzlCLGFBQVcsS0FBSyxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ2hDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLElBQUksQ0FBQztBQUNaLGlDQUEyQjtBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUNBLFFBQU0sa0JBQWtCLEdBQUc7QUFHM0IsUUFBTSxLQUFLLE1BQU0sZ0JBQWdCO0FBQ2pDLE1BQUksd0JBQXdCO0FBQzVCLGFBQVcsS0FBSyxPQUFPLEtBQUssRUFBRSxHQUFHO0FBQy9CLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLEdBQUcsQ0FBQztBQUNYLCtCQUF5QjtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxnQkFBZ0IsRUFBRTtBQUsvQixRQUFNLEtBQUssTUFBTSxtQkFBbUI7QUFDcEMsTUFBSSx1QkFBdUI7QUFDM0IsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLCtCQUF5QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDdEMsYUFBTyxHQUFHLENBQUM7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxtQkFBbUIsRUFBRTtBQUVsQyxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFJQSxlQUFzQixXQUEwQjtBQUM5QyxRQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU07QUFDcEM7OztBQ3BoQkEsSUFBSSxZQUE2QztBQUUxQyxTQUFTLGVBQWUsSUFBa0M7QUFDL0QsY0FBWTtBQUNkO0FBRUEsU0FBUyxTQUFpQjtBQUN4QixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ2hDO0FBRUEsZUFBZSxLQUFLLE9BQWlCLEtBQWEsU0FBaUQ7QUFDakcsUUFBTSxLQUFlLEVBQUUsSUFBSSxPQUFPLEdBQUcsT0FBTyxLQUFLLFNBQVMsT0FBTyxPQUFPLEVBQUU7QUFFMUUsUUFBTSxPQUFPLGlCQUFpQixNQUFNLFlBQVksQ0FBQyxJQUFJLEdBQUc7QUFDeEQsTUFBSSxVQUFVLFFBQVMsU0FBUSxNQUFNLE1BQU0sR0FBRyxPQUFPO0FBQUEsV0FDNUMsVUFBVSxPQUFRLFNBQVEsS0FBSyxNQUFNLEdBQUcsT0FBTztBQUFBLE1BQ25ELFNBQVEsSUFBSSxNQUFNLEdBQUcsT0FBTztBQUVqQyxNQUFJO0FBQ0YsVUFBTSxlQUFlLEVBQUU7QUFBQSxFQUN6QixTQUFTLEtBQUs7QUFDWixZQUFRLEtBQUssMkNBQTJDLEdBQUc7QUFBQSxFQUM3RDtBQUVBLE1BQUk7QUFDRixnQkFBWSxFQUFFO0FBQUEsRUFDaEIsUUFBUTtBQUFBLEVBRVI7QUFDRjtBQUVPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxLQUFLLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN0RixTQUFPLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDbEM7QUFDTyxTQUFTLE1BQU0sS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3ZGLFNBQU8sS0FBSyxTQUFTLEtBQUssT0FBTztBQUNuQztBQUVPLFNBQVMsY0FBYyxLQUF5RDtBQUNyRixNQUFJLGVBQWUsT0FBTztBQUN4QixXQUFPLEVBQUUsU0FBUyxJQUFJLFNBQVMsT0FBTyxJQUFJLFNBQVMsS0FBSztBQUFBLEVBQzFEO0FBQ0EsTUFBSTtBQUNGLFdBQU8sRUFBRSxTQUFTLE9BQU8sR0FBRyxHQUFHLE9BQU8sS0FBSztBQUFBLEVBQzdDLFFBQVE7QUFDTixXQUFPLEVBQUUsU0FBUyx1QkFBdUIsT0FBTyxLQUFLO0FBQUEsRUFDdkQ7QUFDRjtBQU9BLFNBQVMsT0FBTyxLQUF1RDtBQUNyRSxRQUFNLE1BQStCLENBQUM7QUFDdEMsYUFBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDeEMsUUFBSSxFQUFFLFlBQVksRUFBRSxTQUFTLE9BQU8sS0FBSyxFQUFFLFlBQVksTUFBTSxTQUFTLE1BQU0saUJBQWlCO0FBQzNGLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWCxXQUFXLE9BQU8sTUFBTSxZQUFZLCtCQUErQixLQUFLLENBQUMsR0FBRztBQUMxRSxVQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsNkJBQTZCLHVCQUF1QjtBQUFBLElBQ3pFLFdBQVcsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLE1BQU07QUFDbkQsVUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLE1BQU0sR0FBRyxJQUFJLENBQUM7QUFBQSxJQUM5QixPQUFPO0FBQ0wsVUFBSSxDQUFDLElBQUk7QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDs7O0FDdkVBLElBQU0sV0FBVztBQUNqQixJQUFNLFdBQVc7QUFlVixJQUFNLGNBQU4sY0FBMEIsTUFBTTtBQUFBLEVBQ3JDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQTtBQUFBLEVBRUEsWUFBWSxNQU9UO0FBQ0QsVUFBTSxLQUFLLE9BQU87QUFDbEIsU0FBSyxPQUFPO0FBQ1osU0FBSyxTQUFTLEtBQUs7QUFDbkIsU0FBSyxPQUFPLEtBQUs7QUFDakIsU0FBSyxZQUFZLEtBQUs7QUFDdEIsU0FBSyxXQUFXLEtBQUs7QUFDckIsU0FBSyxtQkFBbUIsS0FBSyxvQkFBb0I7QUFBQSxFQUNuRDtBQUNGO0FBRU8sSUFBTSxlQUFOLE1BQW1CO0FBQUEsRUFDUDtBQUFBLEVBRWpCLFlBQVksVUFBb0I7QUFDOUIsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFBQTtBQUFBLEVBR0EsTUFBTSxTQUEwQjtBQUM5QixVQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQy9DLFdBQVEsSUFBMkIsU0FBUztBQUFBLEVBQzlDO0FBQUE7QUFBQSxFQUdBLE1BQU0sYUFBYSxRQUFrQztBQUNuRCxRQUFJO0FBQ0YsWUFBTSxLQUFLO0FBQUEsUUFDVDtBQUFBLFFBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsbUJBQW1CLE1BQU0sQ0FBQztBQUFBLE1BQzVGO0FBQ0EsYUFBTztBQUFBLElBQ1QsU0FBUyxLQUFLO0FBQ1osVUFBSSxlQUFlLGVBQWUsSUFBSSxhQUFhLFlBQWEsUUFBTztBQUN2RSxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQTtBQUFBLEVBR0EsTUFBTSxtQkFBMEY7QUFDOUYsVUFBTSxLQUFLLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTztBQUM5QyxVQUFNLE9BQU8sTUFBTSxLQUFLLFVBQVUsT0FBTyxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksRUFBRTtBQUM5RixVQUFNLElBQUk7QUFDVixXQUFPO0FBQUEsTUFDTCxPQUFRLEdBQXlCO0FBQUEsTUFDakMsV0FBVyxFQUFFO0FBQUEsTUFDYixnQkFBZ0IsRUFBRTtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLGFBQWEsWUFBNEM7QUFDN0QsVUFBTSxNQUFNLEdBQUcsUUFBUSxJQUFJLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFNBQVMsTUFBTSxJQUFJLFVBQVU7QUFDMUcsVUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDM0IsUUFBUTtBQUFBLE1BQ1IsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQUEsSUFDMUQsQ0FBQztBQUNELFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLFVBQVUsS0FBSyxXQUFXLFVBQVUsRUFBRTtBQUNwRSxXQUFPLElBQUksS0FBSztBQUFBLEVBQ2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sV0FBVyxNQUFzQztBQUNyRCxRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLFFBQ3JCO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQyxRQUFRLG1CQUFtQixLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDbEk7QUFDQSxZQUFNLElBQUk7QUFDVixhQUFPLEVBQUUsT0FBTztBQUFBLElBQ2xCLFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxRQUFRLE1BQThDO0FBQzFELFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sTUFBTSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQztBQUM1RixRQUFJLE1BQXFCLEtBQUssZUFBZTtBQUM3QyxVQUFNLGNBQWM7QUFFcEIsYUFBUyxVQUFVLEdBQUcsV0FBVyxhQUFhLFdBQVc7QUFDdkQsWUFBTSxPQUFnQztBQUFBLFFBQ3BDLFNBQVMsS0FBSztBQUFBLFFBQ2QsU0FBUyxLQUFLO0FBQUEsUUFDZCxRQUFRLEtBQUssU0FBUztBQUFBLE1BQ3hCO0FBQ0EsVUFBSSxJQUFLLE1BQUssTUFBTTtBQUNwQixVQUFJO0FBQ0YsY0FBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sS0FBSyxJQUFJO0FBQ2pELGNBQU0sTUFBTTtBQUNaLGVBQU8sRUFBRSxNQUFNLElBQUksUUFBUSxNQUFNLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLFFBQVEsU0FBUztBQUFBLE1BQ25GLFNBQVMsS0FBSztBQUNaLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFJLElBQUksV0FBVyxPQUFPLENBQUMsS0FBSztBQUU5QixnQkFBTSxNQUFNLEtBQUssV0FBVyxJQUFJO0FBQ2hDLGNBQUksQ0FBQyxJQUFLLE9BQU07QUFDaEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxDQUFDLElBQUksYUFBYSxZQUFZLFlBQWEsT0FBTTtBQUNyRCxjQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sSUFBSSxNQUFNLG1DQUFtQyxJQUFJLEVBQUU7QUFBQSxFQUMzRDtBQUFBLEVBRUEsTUFBYyxVQUFVLFFBQWdCLE1BQWMsTUFBa0M7QUFDdEYsVUFBTSxNQUFNLEtBQUssV0FBVyxNQUFNLElBQUksT0FBTyxHQUFHLFFBQVEsR0FBRyxJQUFJO0FBQy9ELFVBQU0sT0FBb0I7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsU0FBUztBQUFBLFFBQ1AsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHO0FBQUEsUUFDMUMsUUFBUTtBQUFBLFFBQ1Isd0JBQXdCO0FBQUEsUUFDeEIsR0FBSSxPQUFPLEVBQUUsZ0JBQWdCLG1CQUFtQixJQUFJLENBQUM7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsR0FBSSxPQUFPLEVBQUUsTUFBTSxLQUFLLFVBQVUsSUFBSSxFQUFFLElBQUksQ0FBQztBQUFBLElBQy9DO0FBQ0EsUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLLElBQUk7QUFBQSxJQUM3QixTQUFTLFFBQVE7QUFDZixZQUFNLElBQUksWUFBWTtBQUFBLFFBQ3BCLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxRQUNOLFNBQVMsWUFBWSxjQUFjLE1BQU0sRUFBRSxPQUFPO0FBQUEsUUFDbEQsV0FBVztBQUFBLFFBQ1gsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFDQSxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxTQUFrQjtBQUN0QixVQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsUUFBSSxNQUFNO0FBQ1IsVUFBSTtBQUNGLGlCQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsTUFDMUIsUUFBUTtBQUNOLGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLG9CQUFvQixLQUFLLFFBQVEsR0FBRyxNQUFNLElBQUksSUFBSSxFQUFFO0FBQ2xGLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLFVBQVUsS0FBZSxPQUFxQztBQUMxRSxRQUFJLFNBQWtCO0FBQ3RCLFFBQUk7QUFDRixZQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsVUFBSSxLQUFNLFVBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxJQUNwQyxRQUFRO0FBQUEsSUFFUjtBQUNBLFdBQU8sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEtBQUs7QUFBQSxFQUNwRDtBQUFBLEVBRVEsb0JBQW9CLEtBQWUsTUFBZSxPQUE0QjtBQUNwRixVQUFNLE1BQ0osT0FBTyxTQUFTLFlBQVksUUFBUSxhQUFhLE9BQzdDLE9BQVEsS0FBOEIsT0FBTyxJQUM3QyxJQUFJO0FBQ1YsUUFBSSxXQUFvQztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUU1QyxZQUFNLE9BQU8sSUFBSSxRQUFRLElBQUksdUJBQXVCO0FBQ3BELFVBQUksU0FBUyxPQUFPLGNBQWMsS0FBSyxHQUFHLEdBQUc7QUFDM0MsbUJBQVc7QUFDWCxvQkFBWTtBQUFBLE1BQ2QsT0FBTztBQUNMLG1CQUFXO0FBQUEsTUFDYjtBQUFBLElBQ0YsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUNuRCxpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFVBQVUsS0FBSztBQUM1QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZCxXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkO0FBQ0EsV0FBTyxJQUFJLFlBQVk7QUFBQSxNQUNyQixRQUFRLElBQUk7QUFBQSxNQUNaO0FBQUEsTUFDQSxTQUFTLEdBQUcsS0FBSyxXQUFNLElBQUksTUFBTSxLQUFLLEdBQUc7QUFBQSxNQUN6QztBQUFBLE1BQ0E7QUFBQSxNQUNBLGtCQUFrQixhQUFhLGVBQWUsb0JBQW9CLElBQUksT0FBTyxJQUFJO0FBQUEsSUFDbkYsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQVFBLFNBQVMsb0JBQW9CLFNBQWlDO0FBQzVELFFBQU0sUUFBUSxRQUFRLElBQUksbUJBQW1CO0FBQzdDLE1BQUksT0FBTztBQUNULFVBQU0sSUFBSSxPQUFPLFNBQVMsT0FBTyxFQUFFO0FBQ25DLFFBQUksT0FBTyxTQUFTLENBQUMsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUFBLEVBQzFDO0FBQ0EsUUFBTSxhQUFhLFFBQVEsSUFBSSxhQUFhO0FBQzVDLE1BQUksWUFBWTtBQUNkLFVBQU0sUUFBUSxPQUFPLFNBQVMsWUFBWSxFQUFFO0FBQzVDLFFBQUksT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLEdBQUc7QUFDeEMsYUFBTyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSSxJQUFJO0FBQUEsSUFDekM7QUFDQSxVQUFNLFNBQVMsS0FBSyxNQUFNLFVBQVU7QUFDcEMsUUFBSSxPQUFPLFNBQVMsTUFBTSxFQUFHLFFBQU8sS0FBSyxNQUFNLFNBQVMsR0FBSTtBQUFBLEVBQzlEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLE1BQXNCO0FBRXhDLFNBQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJLGtCQUFrQixFQUFFLEtBQUssR0FBRztBQUN6RDtBQUVBLFNBQVMsVUFBVSxTQUFpQixLQUEwQjtBQUU1RCxRQUFNLE9BQU8sSUFBSSxhQUFhLGVBQWUsTUFBTztBQUNwRCxRQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQUc7QUFDN0MsU0FBTyxLQUFLLElBQUksS0FBUSxPQUFPLE1BQU0sVUFBVSxLQUFLLE1BQU07QUFDNUQ7QUFFQSxTQUFTLE1BQU0sSUFBMkI7QUFDeEMsU0FBTyxJQUFJLFFBQVEsQ0FBQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUM7QUFDN0M7QUFFTyxTQUFTQSxVQUFTLE9BQXVCO0FBRTlDLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEtBQUs7QUFDM0MsTUFBSSxNQUFNO0FBQ1YsYUFBVyxLQUFLLEtBQU0sUUFBTyxPQUFPLGFBQWEsQ0FBQztBQUNsRCxTQUFPLEtBQUssR0FBRztBQUNqQjs7O0FDbFBBLElBQU0sY0FBYztBQVNwQixJQUFNLHVCQUE0QyxvQkFBSSxJQUFJLENBQUMsV0FBVyxDQUFDO0FBRWhFLFNBQVMsVUFBVSxTQUFrQixLQUF3QztBQUNsRixRQUFNLFlBQVksY0FBYyxPQUFPO0FBQ3ZDLFFBQU0sU0FBMkIsQ0FBQztBQUNsQyxRQUFNLFdBQXFCLENBQUM7QUFDNUIsUUFBTSxRQUFRLG9CQUFJLElBQVk7QUFDOUIsUUFBTSxhQUFhLG9CQUFJLElBQTJCO0FBQ2xELFFBQU0sa0JBQWtCLHFCQUFxQixJQUFJLElBQUksUUFBUTtBQUM3RCxhQUFXLE9BQU8sV0FBVztBQUMzQixRQUFJO0FBQ0YsWUFBTSxJQUFJLFdBQVcsS0FBSyxHQUFHO0FBQzdCLFVBQUksQ0FBQyxHQUFHO0FBQ04sWUFBSSxpQkFBaUI7QUFHbkIsZ0JBQU0sVUFBVSxZQUFZLEdBQUc7QUFDL0IsY0FBSSxRQUFTLFlBQVcsSUFBSSxRQUFRLFVBQVUsUUFBUSxXQUFXO0FBQUEsUUFDbkU7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxlQUFTLEtBQUssRUFBRSxRQUFRO0FBQ3hCLFlBQU0sSUFBSSxFQUFFLFFBQVE7QUFDcEIsVUFBSSxJQUFJLGVBQWUsU0FBUyxLQUFLLElBQUksZUFBZSxJQUFJLEVBQUUsZUFBZSxZQUFZLENBQUMsR0FBRztBQUMzRixlQUFPLEtBQUssQ0FBQztBQUFBLE1BQ2Y7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUVSO0FBQUEsRUFDRjtBQUdBLFFBQU0sY0FBdUUsQ0FBQztBQUM5RSxhQUFXLENBQUMsSUFBSSxJQUFJLEtBQUssWUFBWTtBQUNuQyxRQUFJLE1BQU0sSUFBSSxFQUFFLEVBQUc7QUFDbkIsZ0JBQVksS0FBSyxFQUFFLFVBQVUsSUFBSSxhQUFhLEtBQUssQ0FBQztBQUFBLEVBQ3REO0FBQ0EsU0FBTyxFQUFFLFFBQVEsY0FBYyxVQUFVLFlBQVk7QUFDdkQ7QUFFQSxTQUFTLFlBQVksTUFBd0U7QUFDM0YsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFHVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUc5QyxRQUFNLEtBQUssRUFBRTtBQUNiLE1BQUksT0FBTyxXQUFXLE9BQU8sZ0NBQWdDLENBQUMsSUFBSSxFQUFFLE1BQU0sR0FBRztBQUMzRSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sU0FDSCxPQUFPLEVBQUUsWUFBWSxZQUFZLEVBQUUsV0FDbkMsT0FBTyxJQUFJLEVBQUUsWUFBWSxHQUFHLFdBQVcsWUFDckMsSUFBSSxJQUFJLEVBQUUsWUFBWSxHQUFHLE1BQU0sR0FBRztBQUN2QyxNQUFJLE9BQU8sV0FBVyxZQUFZLENBQUMsWUFBWSxLQUFLLE1BQU0sRUFBRyxRQUFPO0FBQ3BFLFNBQU8sRUFBRSxVQUFVLFFBQVEsYUFBYSxlQUFlLElBQUksRUFBRTtBQUMvRDtBQUVBLFNBQVMsZUFBZSxNQUE4QjtBQUNwRCxNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLFFBQU0sYUFBYSxJQUFJLElBQUksSUFBSSxFQUFFLElBQUksR0FBRyxZQUFZLEdBQUcsTUFBTTtBQUM3RCxTQUNFLFVBQVUsSUFBSSxZQUFZLElBQUksR0FBRyxXQUFXLEtBQzVDLFVBQVUsSUFBSSxZQUFZLE1BQU0sR0FBRyxXQUFXLEtBQzlDLFVBQVUsSUFBSSxFQUFFLE1BQU0sR0FBRyxXQUFXO0FBRXhDO0FBRUEsU0FBUyxjQUFjQyxNQUF5QjtBQUs5QyxRQUFNLE1BQWlCLENBQUM7QUFDeEIsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQ0EsSUFBRztBQUM3QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sT0FBTyxNQUFNLElBQUk7QUFDdkIsUUFBSSxTQUFTLFFBQVEsU0FBUyxPQUFXO0FBQ3pDLFFBQUksT0FBTyxTQUFTLFNBQVU7QUFDOUIsUUFBSSxLQUFLLElBQUksSUFBYyxFQUFHO0FBQzlCLFNBQUssSUFBSSxJQUFjO0FBRXZCLFFBQUksZUFBZSxJQUFJLEdBQUc7QUFDeEIsVUFBSSxLQUFLLFlBQVksSUFBSSxDQUFDO0FBQUEsSUFDNUI7QUFDQSxRQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDdkIsaUJBQVcsS0FBSyxLQUFNLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDcEMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLElBQStCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM5RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGVBQWUsTUFBZ0Q7QUFDdEUsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLFdBQVcsRUFBRTtBQUNuQixNQUNFLGFBQWEsV0FDYixhQUFhLGdDQUNiLGFBQWEsa0JBQ2I7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQU8sT0FBTyxFQUFFLFlBQVksWUFBWSxPQUFPLEVBQUUsV0FBVyxZQUFZLEVBQUUsV0FBVztBQUN2RjtBQUVBLFNBQVMsWUFBWSxNQUF3RDtBQUMzRSxNQUFJLEtBQUssZUFBZSxnQ0FBZ0MsT0FBTyxLQUFLLFVBQVUsVUFBVTtBQUN0RixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLEtBQWMsS0FBOEM7QUFDOUUsTUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLEtBQU0sUUFBTztBQUNwRCxRQUFNLElBQUk7QUFFVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUU5QyxRQUFNLFNBQVMsVUFBVSxFQUFFLE9BQU87QUFLbEMsUUFBTSxTQUFTLElBQUksRUFBRSxNQUFNLEtBQUssQ0FBQztBQUNqQyxNQUFJLENBQUMsT0FBUSxRQUFPO0FBRXBCLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxJQUFJLE1BQU0sWUFBWSxHQUFHLE1BQU07QUFHdEQsUUFBTSxjQUFjLElBQUksWUFBWSxJQUFJO0FBQ3hDLFFBQU0sYUFBYSxJQUFJLFlBQVksTUFBTTtBQUN6QyxRQUFNLGdCQUFnQixJQUFJLFlBQVksTUFBTTtBQUM1QyxRQUFNLFNBQ0osVUFBVSxhQUFhLFdBQVcsS0FDbEMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxPQUFPLFdBQVc7QUFDOUIsUUFBTSxZQUNKLFVBQVUsWUFBWSxPQUFPLEtBQzdCLFVBQVUsWUFBWSxNQUFNLEtBQzVCLFVBQVUsT0FBTyxXQUFXO0FBQzlCLE1BQUksQ0FBQyxVQUFVLENBQUMsVUFBVyxRQUFPO0FBTWxDLFFBQU0sU0FBUyxvQkFBb0IsWUFBWSxhQUFhLFlBQVksYUFBYTtBQUVyRixRQUFNLFlBQVksSUFBSSxJQUFJLElBQUksRUFBRSxVQUFVLEdBQUcsa0JBQWtCLEdBQUcsTUFBTTtBQUN4RSxRQUFNLGVBQWUsVUFBVSxXQUFXLElBQUk7QUFDOUMsUUFBTSxpQkFBaUIsVUFBVSxPQUFPLFNBQVMsS0FBSztBQUN0RCxRQUFNLE9BQU8sZ0JBQWdCO0FBQzdCLFFBQU0sY0FBYyxpQkFBaUIsV0FBVyxRQUFRLGNBQWM7QUFDdEUsUUFBTSxnQkFBZ0IscUJBQXFCLEdBQUcsUUFBUSxJQUFJLFVBQVU7QUFFcEUsUUFBTSxXQUFXLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQztBQUMxQyxRQUFNLG1CQUFtQixJQUFJLFdBQVcsVUFBVTtBQUNsRCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxPQUFPLFlBQVksb0JBQW9CLFFBQVE7QUFDckQsUUFBTSxRQUFRLGFBQWEsTUFBTTtBQUVqQyxRQUFNLFlBQVksa0JBQWtCLEdBQUcsTUFBTTtBQUk3QyxRQUFNLFdBQ0osaUJBQWlCLFVBQVUsT0FBTyxVQUFVLENBQUMsS0FBSyxpQkFBaUIsVUFBVSxFQUFFLFVBQVUsQ0FBQztBQUM1RixNQUFJLENBQUMsU0FBVSxRQUFPO0FBRXRCLFFBQU0sUUFBUSxJQUFJLEVBQUUsS0FBSztBQUN6QixRQUFNLFlBQVksVUFBVSxPQUFPLEtBQUssS0FBSyxVQUFVLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFFOUUsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUMxQixRQUFNLFFBQVEsSUFBSSxPQUFPLEtBQUs7QUFFOUIsUUFBTSxRQUF3QjtBQUFBLElBQzVCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLFdBQVc7QUFBQSxJQUNYLG1CQUFtQixJQUFJO0FBQUEsSUFDdkIsY0FBYyxJQUFJO0FBQUEsSUFDbEIsc0JBQXNCO0FBQUEsSUFDdEIsV0FBVyxHQUFHLGdCQUFnQixJQUFJLE1BQU0sV0FBVyxNQUFNO0FBQUEsSUFDekQsWUFBWTtBQUFBLElBQ1osaUJBQWlCLFVBQVUsT0FBTyxtQkFBbUI7QUFBQSxJQUNyRCxtQkFBbUIsVUFBVSxPQUFPLHlCQUF5QjtBQUFBLElBQzdELGtCQUFrQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDMUQscUJBQXFCLFVBQVUsT0FBTyx1QkFBdUI7QUFBQSxJQUM3RCxpQkFBaUIsVUFBVSxPQUFPLG9CQUFvQjtBQUFBLElBQ3RELG9CQUFvQjtBQUFBLE1BQ2xCLElBQUksSUFBSSxPQUFPLHVCQUF1QixHQUFHLE1BQU0sR0FBRyxXQUMvQyxPQUFtQztBQUFBLElBQ3hDO0FBQUEsSUFDQTtBQUFBLElBQ0EsZUFBZSxpQkFBaUIsTUFBTSxJQUFJO0FBQUEsSUFDMUMsTUFBTSxVQUFVLE9BQU8sSUFBSTtBQUFBLElBQzNCLG9CQUFvQixXQUFXLE9BQU8sa0JBQWtCO0FBQUEsSUFDeEQsUUFBUSxVQUFVLE9BQU8sTUFBTSxLQUFLLFVBQVUsRUFBRSxNQUFNO0FBQUEsSUFDdEQsaUJBQWlCLFVBQVUsT0FBTyxTQUFTO0FBQUEsSUFDM0M7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDM0MsZUFBZSxVQUFVLE9BQU8sYUFBYTtBQUFBLElBQzdDLGFBQWEsVUFBVSxPQUFPLFdBQVc7QUFBQSxJQUN6QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsWUFBWTtBQUFBLElBQ1osZ0JBQWdCLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDL0Msb0JBQW9CO0FBQUEsTUFDbEI7QUFBQSxRQUNFLGFBQWEsSUFBSTtBQUFBLFFBQ2pCLE9BQU8sVUFBVSxPQUFPLGNBQWM7QUFBQSxRQUN0QyxVQUFVLFVBQVUsT0FBTyxhQUFhO0FBQUEsUUFDeEMsU0FBUyxVQUFVLE9BQU8sV0FBVztBQUFBLFFBQ3JDLFFBQVEsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNwQyxPQUFPO0FBQUEsUUFDUCxXQUFXLFVBQVUsT0FBTyxjQUFjO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLElBQ0EsZ0JBQWdCO0FBQUEsSUFDaEIsY0FBYztBQUFBLElBQ2QsYUFBYTtBQUFBLElBQ2Isc0JBQXNCO0FBQUEsSUFDdEIsZ0JBQWdCO0FBQUEsSUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxJQUNwQixnQkFBZ0I7QUFBQSxFQUNsQjtBQUVBLFNBQU87QUFDVDtBQUVBLFNBQVMsa0JBQWtCLEdBQTRCLFFBQTRDO0FBQ2pHLE1BQUksT0FBTywyQkFBMkIsT0FBTyx3QkFBeUIsUUFBTztBQUM3RSxNQUFJLE9BQU8sMEJBQTJCLFFBQU87QUFDN0MsTUFBSSxPQUFPLG9CQUFvQixRQUFRLE9BQU8scUJBQXNCLFFBQU87QUFDM0UsTUFBSSxFQUFFLGVBQWUsOEJBQThCO0FBQUEsRUFFbkQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxVQUFVLElBQUksT0FBUSxFQUF3QixJQUFJLElBQUk7QUFBQSxFQUN0RixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixJQUMzQyxPQUFRLEVBQStCLFdBQVcsSUFDbEQ7QUFBQSxFQUNOLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxZQUFZLFVBQWdEO0FBQ25FLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxRQUFNLE1BQW1CLENBQUM7QUFDMUIsYUFBVyxLQUFLLEtBQUs7QUFDbkIsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU07QUFDekMsVUFBTSxJQUFJO0FBQ1YsVUFBTSxRQUFRLFVBQVUsRUFBRSxHQUFHO0FBQzdCLFVBQU0sV0FBVyxVQUFVLEVBQUUsWUFBWTtBQUN6QyxVQUFNLFVBQVUsVUFBVSxFQUFFLFdBQVc7QUFDdkMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFVO0FBQ3pCLFFBQUksS0FBSyxFQUFFLE9BQU8sVUFBVSxTQUFTLFdBQVcsU0FBUyxDQUFDO0FBQUEsRUFDNUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGFBQWEsUUFBOEM7QUFDbEUsUUFBTSxXQUFXLElBQUksT0FBTyxpQkFBaUI7QUFDN0MsUUFBTSxVQUFVLFdBQVcsUUFBUSxTQUFTLEtBQUssSUFBSSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxRQUFRLElBQUksT0FBTyxRQUFRLEdBQUcsS0FBSztBQUNuRCxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFNBQVMsQ0FBQyxHQUFHLFNBQVMsR0FBRyxPQUFPLEVBQUUsT0FBTyxDQUFDLE1BQU07QUFDcEQsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU0sUUFBTztBQUNoRCxVQUFNLEtBQ0osVUFBVyxFQUE4QixTQUFTLEtBQ2xELFVBQVcsRUFBOEIsTUFBTTtBQUNqRCxRQUFJLENBQUMsR0FBSSxRQUFPO0FBQ2hCLFFBQUksS0FBSyxJQUFJLEVBQUUsRUFBRyxRQUFPO0FBQ3pCLFNBQUssSUFBSSxFQUFFO0FBQ1gsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNELFNBQU8sT0FBTyxJQUFJLENBQUMsUUFBUSxXQUFXLEdBQThCLENBQUM7QUFDdkU7QUFFQSxTQUFTLFdBQVcsR0FBdUM7QUFDekQsUUFBTSxPQUFPLFVBQVUsRUFBRSxJQUFJO0FBQzdCLFFBQU0sV0FBVyxnQkFBZ0IsR0FBRyxJQUFJO0FBQ3hDLFFBQU1DLFFBQU8sSUFBSSxFQUFFLGFBQWE7QUFDaEMsUUFBTSxZQUFZLElBQUksRUFBRSxVQUFVO0FBQ2xDLFFBQU0sYUFBYSxVQUFVLFdBQVcsZUFBZTtBQUN2RCxRQUFNLFVBQVUsVUFBVSxFQUFFLFlBQVk7QUFDeEMsUUFBTSxVQUNKLFVBQVUsRUFBRSxTQUFTLEtBQ3JCLFVBQVUsRUFBRSxNQUFNLEtBQ2xCLEdBQUcsUUFBUSxPQUFPLElBQUksS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDM0QsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsWUFBYSxRQUFRO0FBQUEsSUFDckIsY0FBYyxZQUFZO0FBQUEsSUFDMUIsbUJBQW1CO0FBQUEsSUFDbkIsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsY0FBYyxlQUFlLE9BQU8sYUFBYSxNQUFPO0FBQUEsSUFDeEQsT0FBTyxVQUFVQSxPQUFNLEtBQUs7QUFBQSxJQUM1QixRQUFRLFVBQVVBLE9BQU0sTUFBTTtBQUFBLElBQzlCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLGtCQUFrQjtBQUFBLElBQ2xCLGlCQUFpQjtBQUFBLEVBQ25CO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixHQUE0QixNQUFvQztBQUN2RixNQUFJLFNBQVMsUUFBUyxRQUFPLFVBQVUsRUFBRSxlQUFlLEtBQUssVUFBVSxFQUFFLFNBQVM7QUFDbEYsUUFBTSxXQUFXLFFBQVEsSUFBSSxFQUFFLFVBQVUsR0FBRyxRQUFRO0FBQ3BELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxVQUFVLEVBQUUsZUFBZTtBQUU3RCxNQUFJLE9BQWdEO0FBQ3BELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sS0FBSyxVQUFVLEVBQUUsWUFBWTtBQUNuQyxVQUFNLE1BQU0sVUFBVSxFQUFFLEdBQUc7QUFDM0IsUUFBSSxDQUFDLElBQUs7QUFDVixRQUFJLE9BQU8sYUFBYTtBQUN0QixZQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sS0FBSztBQUNuQyxVQUFJLENBQUMsUUFBUSxLQUFLLEtBQUssUUFBUyxRQUFPLEVBQUUsS0FBSyxTQUFTLEdBQUc7QUFBQSxJQUM1RCxXQUFXLENBQUMsTUFBTTtBQUVoQixhQUFPLEVBQUUsS0FBSyxTQUFTLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLE1BQU0sT0FBTztBQUN0QjtBQUVBLFNBQVMsaUJBQWlCLE1BQWMsTUFBMkI7QUFDakUsTUFBSSxLQUFLLFdBQVcsRUFBRyxRQUFPO0FBQzlCLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLE9BQU0sSUFBSSxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRO0FBQzlELFNBQU87QUFDVDtBQUVBLFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELE1BQUksQ0FBQyxFQUFHLFFBQU87QUFFZixRQUFNLElBQUksSUFBSSxLQUFLLENBQUM7QUFDcEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPO0FBQ3RDLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLFNBQU8sT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLElBQUksSUFBSTtBQUNyRDtBQUNBLFNBQVMsV0FBVyxHQUE0QjtBQUM5QyxTQUFPLE9BQU8sTUFBTSxZQUFZLElBQUk7QUFDdEM7QUFDQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFDeEQsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxVQUFNLElBQUksT0FBTyxDQUFDO0FBQ2xCLFFBQUksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQUEsRUFDakM7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFVBQVUsR0FBb0I7QUFDckMsU0FBTyxVQUFVLENBQUMsS0FBSztBQUN6QjtBQUNBLFNBQVMsSUFBSSxHQUE0QztBQUN2RCxTQUFPLE9BQU8sTUFBTSxZQUFZLE1BQU0sUUFBUSxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQ3pELElBQ0Q7QUFDTjtBQUNBLFNBQVMsUUFBUSxHQUF1QjtBQUN0QyxTQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDO0FBQ2pDO0FBd0JBLFNBQVMsaUJBQ1AsV0FDQSxRQUNBLFVBQ1M7QUFDVCxNQUFJLFVBQVcsUUFBTztBQUN0QixNQUFJLENBQUMsU0FBVSxRQUFPO0FBQ3RCLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUTtBQUNwQyxRQUFNLE9BQU8sV0FBVyxTQUFTLE9BQU87QUFDeEMsTUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGVBQVcsS0FBSyxNQUFNO0FBQ3BCLFVBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFlBQU0sTUFBTyxFQUE4QjtBQUkzQyxVQUFJLE9BQU8sUUFBUSxZQUFZLHdCQUF3QixLQUFLLEdBQUcsR0FBRztBQUNoRSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBa0JPLFNBQVMsY0FDZCxRQUNBLFVBQ2tCO0FBQ2xCLE1BQUksU0FBUyxTQUFTLEVBQUcsUUFBTztBQUtoQyxRQUFNLGdCQUFnQixvQkFBSSxJQUFZO0FBQ3RDLFFBQU0sbUJBQW1CLG9CQUFJLElBQVk7QUFDekMsYUFBVyxLQUFLLFFBQVE7QUFDdEIsUUFBSSxDQUFDLFNBQVMsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEVBQUc7QUFDbkQscUJBQWlCLElBQUksRUFBRSxRQUFRO0FBQy9CLFFBQUksRUFBRSxnQkFBaUIsZUFBYyxJQUFJLEVBQUUsZUFBZTtBQUMxRCxRQUFJLEVBQUUsbUJBQW9CLGVBQWMsSUFBSSxFQUFFLGtCQUFrQjtBQUNoRSxRQUFJLEVBQUUsa0JBQW1CLGVBQWMsSUFBSSxFQUFFLGlCQUFpQjtBQUFBLEVBQ2hFO0FBQ0EsU0FBTyxPQUFPLE9BQU8sQ0FBQyxNQUFNO0FBQzFCLFVBQU0sSUFBSSxFQUFFLGVBQWUsWUFBWTtBQUN2QyxRQUFJLFNBQVMsSUFBSSxDQUFDLEVBQUcsUUFBTztBQUU1QixRQUFJLGNBQWMsSUFBSSxFQUFFLFFBQVEsRUFBRyxRQUFPO0FBRTFDLFFBQUksRUFBRSxtQkFBbUIsaUJBQWlCLElBQUksRUFBRSxlQUFlLEVBQUcsUUFBTztBQUN6RSxRQUFJLEVBQUUsc0JBQXNCLGlCQUFpQixJQUFJLEVBQUUsa0JBQWtCLEVBQUcsUUFBTztBQUMvRSxRQUFJLEVBQUUscUJBQXFCLGlCQUFpQixJQUFJLEVBQUUsaUJBQWlCLEVBQUcsUUFBTztBQUU3RSxRQUFJLEVBQUUsb0JBQW9CLFNBQVMsSUFBSSxFQUFFLGlCQUFpQixZQUFZLENBQUMsRUFBRyxRQUFPO0FBQ2pGLGVBQVcsS0FBSyxFQUFFLFVBQVU7QUFDMUIsVUFBSSxTQUFTLElBQUksRUFBRSxZQUFZLENBQUMsRUFBRyxRQUFPO0FBQUEsSUFDNUM7QUFDQSxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0g7QUFTQSxTQUFTLHFCQUNQLEdBQ0EsUUFDQSxZQUNzQjtBQUN0QixRQUFNLFFBQVEsSUFBSSxFQUFFLGVBQWUsS0FBSyxJQUFJLE9BQU8sZUFBZTtBQUNsRSxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLFFBQU0sV0FBVyxJQUFJLE1BQU0sUUFBUTtBQUNuQyxRQUFNLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDM0IsUUFBTSxVQUFVLFVBQVUsVUFBVSxJQUFJO0FBQ3hDLFFBQU0sUUFBUSxVQUFVLE1BQU0sS0FBSztBQUNuQyxRQUFNLGFBQWEsVUFBVSxNQUFNLFVBQVU7QUFDN0MsUUFBTSxpQkFBaUIsVUFBVSxNQUFNLGNBQWM7QUFDckQsUUFBTSxTQUFTLFVBQVUsTUFBTSxNQUFNLEtBQUssVUFBVSxNQUFNLE9BQU87QUFFakUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBUSxRQUFPO0FBQzFDLFNBQU87QUFBQSxJQUNMLFNBQVM7QUFBQSxJQUNUO0FBQUEsSUFDQSxhQUFhO0FBQUEsSUFDYjtBQUFBLElBQ0EsaUJBQWlCO0FBQUEsSUFDakIsYUFBYTtBQUFBLEVBQ2Y7QUFDRjtBQU9BLFNBQVMsb0JBQ1AsWUFDQSxhQUNBLFlBQ0EsZUFDYztBQUNkLFFBQU0sZUFBZSxJQUFJLFlBQVksWUFBWTtBQUNqRCxTQUFPO0FBQUEsSUFDTCxjQUNFLFVBQVUsYUFBYSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUksS0FBSyxVQUFVLFlBQVksSUFBSTtBQUFBLElBQzNGLFlBQ0UsVUFBVSxlQUFlLFNBQVMsS0FDbEMsVUFBVSxZQUFZLHVCQUF1QixLQUM3QyxVQUFVLFlBQVksdUJBQXVCO0FBQUEsSUFDL0MsVUFBVSxXQUFXLGNBQWMsUUFBUSxLQUFLLFdBQVcsWUFBWSxRQUFRO0FBQUEsSUFDL0Usa0JBQWtCLFdBQVcsWUFBWSxnQkFBZ0I7QUFBQSxJQUN6RCxlQUFlLFVBQVUsY0FBYyxhQUFhLEtBQUssVUFBVSxZQUFZLGFBQWE7QUFBQSxJQUM1RixhQUFhLFVBQVUsWUFBWSxXQUFXO0FBQUEsSUFDOUMsVUFBVSxVQUFVLElBQUksWUFBWSxRQUFRLEdBQUcsUUFBUSxLQUFLLFVBQVUsWUFBWSxRQUFRO0FBQUEsSUFDMUYsS0FBSyxVQUFVLFlBQVksR0FBRztBQUFBLElBQzlCLGlCQUFpQixVQUFVLFlBQVksZUFBZTtBQUFBLElBQ3RELGVBQWUsVUFBVSxZQUFZLGFBQWE7QUFBQSxJQUNsRCxnQkFBZ0IsVUFBVSxZQUFZLGNBQWM7QUFBQSxJQUNwRCxvQkFDRSxpQkFBaUIsVUFBVSxhQUFhLFVBQVUsQ0FBQyxLQUNuRCxpQkFBaUIsVUFBVSxZQUFZLFVBQVUsQ0FBQztBQUFBLElBQ3BELFdBQVcsV0FBVyxZQUFZLFNBQVM7QUFBQSxFQUM3QztBQUNGO0FBT0EsU0FBUyxZQUFZLEdBQThDO0FBQ2pFLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxNQUFNLE1BQU07QUFDbkMsTUFBSSxDQUFDLFdBQVksUUFBTztBQUN4QixRQUFNLFdBQVcsV0FBVztBQUM1QixRQUFNLFFBQWlDLENBQUM7QUFDeEMsTUFBSSxNQUFNLFFBQVEsUUFBUSxHQUFHO0FBQzNCLGVBQVcsTUFBTSxVQUFVO0FBQ3pCLFVBQUksT0FBTyxPQUFPLFlBQVksT0FBTyxLQUFNO0FBQzNDLFlBQU0sSUFBSTtBQUNWLFlBQU0sSUFBSSxVQUFVLEVBQUUsR0FBRztBQUN6QixZQUFNLElBQUksSUFBSSxFQUFFLEtBQUs7QUFDckIsVUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFHO0FBQ2QsWUFBTSxDQUFDLElBQ0wsVUFBVSxFQUFFLFlBQVksS0FDeEIsVUFBVSxJQUFJLEVBQUUsV0FBVyxHQUFHLEdBQUcsS0FDakMsVUFBVSxJQUFJLEVBQUUsaUJBQWlCLEdBQUcsT0FBTztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxVQUFVLFdBQVcsSUFBSTtBQUN0QyxRQUFNLFVBQVUsVUFBVSxXQUFXLEdBQUc7QUFDeEMsUUFBTSxZQUNKLE9BQU8sTUFBTSxZQUFZLE1BQU0sV0FBWSxNQUFNLFlBQVksSUFBZTtBQUM5RSxRQUFNLFFBQVEsT0FBTyxNQUFNLE9BQU8sTUFBTSxXQUFZLE1BQU0sT0FBTyxJQUFlO0FBQ2hGLFFBQU0sY0FDSixPQUFPLE1BQU0sYUFBYSxNQUFNLFdBQVksTUFBTSxhQUFhLElBQWU7QUFDaEYsUUFBTSxZQUNILE9BQU8sTUFBTSxnQ0FBZ0MsTUFBTSxXQUMvQyxNQUFNLGdDQUFnQyxJQUN2QyxVQUNILE9BQU8sTUFBTSwwQkFBMEIsTUFBTSxXQUN6QyxNQUFNLDBCQUEwQixJQUNqQyxVQUNILE9BQU8sTUFBTSw4QkFBOEIsTUFBTSxXQUM3QyxNQUFNLDhCQUE4QixJQUNyQztBQUNOLE1BQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxTQUFVLFFBQU87QUFDekQsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBLFVBQVU7QUFBQSxJQUNWLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsV0FBVztBQUFBLEVBQ2I7QUFDRjs7O0FDNXBCQSxJQUFNLFdBQVc7QUFFVixTQUFTLFdBQW1CO0FBQ2pDLFFBQU0sS0FBSyxLQUFLLElBQUk7QUFDcEIsTUFBSSxTQUFTO0FBQ2IsTUFBSSxJQUFJO0FBQ1IsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7QUFDM0IsY0FBVSxTQUFTLElBQUksRUFBRSxLQUFLLE9BQU87QUFDckMsUUFBSSxLQUFLLE1BQU0sSUFBSSxFQUFFO0FBQUEsRUFDdkI7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxNQUFJLFdBQVc7QUFDZixhQUFXLEtBQUssS0FBTSxhQUFZLFNBQVMsSUFBSSxFQUFFLEtBQUs7QUFDdEQsU0FBTyxTQUFTO0FBQ2xCO0FBRU8sU0FBUyxXQUFXLElBQW9CO0FBQzdDLFNBQU8sR0FBRyxNQUFNLEVBQUU7QUFDcEI7OztBQ1BBLElBQU0sbUJBQWlELG9CQUFJLElBQUk7QUFBQSxFQUM3RDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBRU0sU0FBUyxrQkFBa0IsTUFBK0I7QUFDL0QsUUFBTSxXQUE0QixDQUFDO0FBQ25DLE1BQUksVUFBa0MsQ0FBQztBQUN2QyxNQUFJLGFBQWE7QUFDakIsUUFBTSxRQUFRLE1BQU07QUFDbEIsUUFBSSxRQUFRLFVBQVUsUUFBUSxPQUFPO0FBQ25DLFVBQUksQ0FBQyxRQUFRLFNBQVUsU0FBUSxXQUFXO0FBQzFDLGVBQVMsS0FBSyxPQUF3QjtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNBLGFBQVcsV0FBVyxLQUFLLE1BQU0sSUFBSSxHQUFHO0FBQ3RDLFVBQU0sT0FBTyxjQUFjLE9BQU87QUFDbEMsUUFBSSxLQUFLLEtBQUssTUFBTSxHQUFJO0FBQ3hCLFFBQUksZ0JBQWdCLEtBQUssSUFBSSxHQUFHO0FBQzlCLG1CQUFhO0FBQ2I7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLFdBQVk7QUFFakIsVUFBTSxZQUFZLEtBQUssTUFBTSw0QkFBNEI7QUFDekQsUUFBSSxXQUFXO0FBQ2IsWUFBTTtBQUNOLGdCQUFVLEVBQUUsUUFBUSxRQUFRLFVBQVUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtBQUNoRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGFBQWEsS0FBSyxNQUFNLHdCQUF3QjtBQUN0RCxRQUFJLGNBQWMsQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQ3JDLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxXQUFXLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDakQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx1QkFBdUI7QUFDckQsUUFBSSxjQUFjLFFBQVEsUUFBUTtBQUNoQyxjQUFRLFFBQVEsUUFBUSxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQzNDO0FBQUEsSUFDRjtBQUNBLFVBQU0sZ0JBQWdCLEtBQUssTUFBTSwwQkFBMEI7QUFDM0QsUUFBSSxpQkFBaUIsUUFBUSxRQUFRO0FBQ25DLFlBQU0sTUFBTSxRQUFRLGNBQWMsQ0FBQyxLQUFLLEVBQUU7QUFDMUMsY0FBUSxXQUFXLGlCQUFpQixJQUFJLEdBQXNCLElBQ3pELE1BQ0Q7QUFDSjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTTtBQUNOLFNBQU8sU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sU0FBUyxDQUFDO0FBQ25EO0FBRUEsU0FBUyxjQUFjLE1BQXNCO0FBRzNDLFFBQU0sTUFBTSxLQUFLLFFBQVEsR0FBRztBQUM1QixTQUFPLFFBQVEsS0FBSyxPQUFPLEtBQUssTUFBTSxHQUFHLEdBQUc7QUFDOUM7QUFFQSxTQUFTLFFBQVEsR0FBbUI7QUFDbEMsUUFBTSxVQUFVLEVBQUUsS0FBSztBQUN2QixNQUNHLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsS0FDL0MsUUFBUSxXQUFXLEdBQUcsS0FBSyxRQUFRLFNBQVMsR0FBRyxHQUNoRDtBQUNBLFdBQU8sUUFBUSxNQUFNLEdBQUcsRUFBRTtBQUFBLEVBQzVCO0FBQ0EsU0FBTztBQUNUOzs7QUNOQSxJQUFNLGNBQWMsUUFBUSxRQUFRLFlBQVksRUFBRTtBQUVsRCxlQUFlLENBQUMsT0FBaUI7QUFDL0IsVUFBUSxRQUFRLFlBQVksRUFBRSxNQUFNLGFBQWEsT0FBTyxHQUFHLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDOUUsQ0FBQztBQUlELFFBQVEsUUFBUSxZQUFZLFlBQVksWUFBWTtBQUNsRCxRQUFNLEtBQUssdUJBQXVCLEVBQUUsU0FBUyxZQUFZLENBQUM7QUFDMUQsUUFBTSxPQUFPLFNBQVM7QUFDeEIsQ0FBQztBQUVELFFBQVEsUUFBUSxVQUFVLFlBQVksTUFBTTtBQUMxQyxPQUFLLE9BQU8sU0FBUztBQUN2QixDQUFDO0FBR0QsS0FBSyxPQUFPLGFBQWE7QUFFekIsZUFBZSxPQUFPLFFBQStCO0FBQ25ELE1BQUk7QUFDRixVQUFNLGFBQWE7QUFDbkIsVUFBTSxzQkFBc0I7QUFDNUIsVUFBTSw0QkFBNEI7QUFDbEMsVUFBTSxxQkFBcUI7QUFHM0IsVUFBTSxTQUFTLE1BQU0sb0JBQW9CLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBSTtBQUNqRSxRQUFJLFNBQVMsRUFBRyxPQUFNLEtBQUssMEJBQTBCLEVBQUUsT0FBTyxDQUFDO0FBQy9ELFVBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBSSxTQUFTLE9BQU8sU0FBUyxTQUFTLFNBQVMsTUFBTTtBQUNuRCxZQUFNLGlCQUFpQixLQUFLO0FBQzVCLFlBQU0sb0JBQW9CLEtBQUs7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTSxjQUFjO0FBQUEsUUFDbEIsUUFBUTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWU7QUFBQSxRQUNmLHdCQUF3QjtBQUFBLFFBQ3hCLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFDRCxZQUFNLEtBQUssd0NBQXdDLEVBQUUsT0FBTyxDQUFDO0FBQUEsSUFDL0Q7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sTUFBTyxlQUFlLEVBQUUsUUFBUSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFBQSxFQUMvRDtBQUNGO0FBWUEsZUFBZSx1QkFBc0M7QUFDbkQsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFBQSxFQUN2RixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssNkJBQTZCLGNBQWMsR0FBRyxDQUFDO0FBQzFEO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxPQUFPLElBQUksT0FBTyxTQUFVO0FBQ2hDLFFBQUk7QUFDRixZQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTyxDQUFDLGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl0QixPQUFPO0FBQUEsTUFDVCxDQUFDO0FBQ0QsWUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU8sQ0FBQyxZQUFZO0FBQUEsTUFDdEIsQ0FBQztBQUNELFlBQU0sS0FBSyxxQ0FBcUM7QUFBQSxRQUM5QyxPQUFPLElBQUk7QUFBQSxRQUNYLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRTtBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNILFNBQVMsS0FBSztBQUlaLFlBQU0sS0FBSyx3Q0FBd0M7QUFBQSxRQUNqRCxPQUFPLElBQUk7QUFBQSxRQUNYLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRTtBQUFBLFFBQzdCLEdBQUcsY0FBYyxHQUFHO0FBQUEsTUFDdEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLFFBQU0sUUFBUSxPQUFPLE1BQU0sYUFBYTtBQUN4QyxRQUFNLFFBQVEsT0FBTyxNQUFNLG1CQUFtQjtBQUM5QyxRQUFNLFFBQVEsT0FBTyxPQUFPLGVBQWUsRUFBRSxpQkFBaUIsb0JBQW9CLENBQUM7QUFDbkYsUUFBTSxRQUFRLE9BQU8sT0FBTyxxQkFBcUI7QUFBQSxJQUMvQyxpQkFBaUIsZ0NBQWdDO0FBQUEsRUFDbkQsQ0FBQztBQUNIO0FBTUEsSUFBSSxrQkFBeUQ7QUFLN0QsSUFBTSxpQkFBaUI7QUFFdkIsZUFBZSx3QkFBdUM7QUFFcEQsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsTUFBSSxTQUFTLFFBQVEsRUFBRSxZQUFZLE9BQU87QUFDeEMsdUJBQW1CLEVBQUUscUJBQXFCO0FBQUEsRUFDNUMsT0FBTztBQUNMLHlCQUFxQjtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLHVCQUE2QjtBQUNwQyxNQUFJLG9CQUFvQixNQUFNO0FBQzVCLGtCQUFjLGVBQWU7QUFDN0Isc0JBQWtCO0FBQUEsRUFDcEI7QUFDRjtBQUVBLFNBQVMsbUJBQW1CLGFBQTJCO0FBQ3JELHVCQUFxQjtBQUNyQixRQUFNLFVBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsSUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxXQUFXLENBQUM7QUFBQSxFQUN2RDtBQUNBLG9CQUFrQixZQUFZLE1BQU07QUFDbEMsU0FBSyxlQUFlLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDbkMsV0FBSyxLQUFLLDJCQUEyQixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3pELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsZUFBZSxzQkFBcUM7QUFDbEQsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLHFCQUFxQjtBQUFBLElBQ3pCLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxhQUFhO0FBQUEsSUFDYixlQUFlO0FBQUEsSUFDZixlQUFlO0FBQUEsRUFDakIsQ0FBQztBQUNELHFCQUFtQixFQUFFLHFCQUFxQjtBQUMxQyxRQUFNLEtBQUssNEJBQTRCLEVBQUUsY0FBYyxFQUFFLHNCQUFzQixDQUFDO0FBRWhGLE9BQUssZUFBZTtBQUNwQixRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLHVCQUFzQztBQUNuRCx1QkFBcUI7QUFDckIsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxLQUFLLDhCQUE4QjtBQUFBLElBQ3ZDLFNBQVMsTUFBTSxlQUFlO0FBQUEsSUFDOUIsVUFBVSxNQUFNLGlCQUFpQjtBQUFBLElBQ2pDLFVBQVUsTUFBTSxpQkFBaUI7QUFBQSxFQUNuQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxpQkFBZ0M7QUFDN0MsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFBQSxFQUN2RixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaUNBQWlDLGNBQWMsR0FBRyxDQUFDO0FBQzlEO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksZ0JBQWdCO0FBQ3BCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJLElBQUksVUFBVztBQUNuQixRQUFJO0FBQ0YsWUFBTSxVQUFXLE1BQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNyRCxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJUCxNQUFPLE1BQU07QUFLWCxnQkFBTSxzQkFBc0I7QUFBQSxZQUMxQjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUNBLGdCQUFNLFVBQVUsb0JBQUksSUFBYTtBQUNqQyxjQUFJLFdBQVc7QUFDZixxQkFBVyxPQUFPLHFCQUFxQjtBQUNyQyx1QkFBVyxNQUFNLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixHQUFHLENBQUMsR0FBRztBQUMzRCxrQkFBSSxRQUFRLElBQUksRUFBRSxFQUFHO0FBRXJCLG9CQUFNLEtBQUssR0FBRyxlQUFlLElBQUksS0FBSyxFQUFFLFlBQVk7QUFDcEQsa0JBQUksTUFBTSxlQUFlLE1BQU0sbUJBQW9CO0FBQ25ELG9CQUFNLE9BQU8sR0FBRyxzQkFBc0I7QUFDdEMsa0JBQUksS0FBSyxVQUFVLEtBQUssS0FBSyxXQUFXLEVBQUc7QUFDM0Msc0JBQVEsSUFBSSxFQUFFO0FBQ2Qsa0JBQUk7QUFDRixnQkFBQyxHQUFtQixNQUFNO0FBQzFCLDRCQUFZO0FBQUEsY0FDZCxRQUFRO0FBQUEsY0FFUjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBSUEsZ0JBQU0sT0FBMEI7QUFBQSxZQUM5QixLQUFLO0FBQUEsWUFDTCxNQUFNO0FBQUEsWUFDTixTQUFTO0FBQUEsWUFDVCxPQUFPO0FBQUEsWUFDUCxTQUFTO0FBQUEsWUFDVCxZQUFZO0FBQUEsVUFDZDtBQUNBLGdCQUFNLFFBQVMsU0FBUyxpQkFBd0MsU0FBUztBQUN6RSxnQkFBTSxjQUFjLElBQUksY0FBYyxXQUFXLElBQUksQ0FBQztBQUN0RCxnQkFBTSxjQUFjLElBQUksY0FBYyxTQUFTLElBQUksQ0FBQztBQUNwRCxpQkFBTyxTQUFTO0FBQUEsWUFDZCxLQUFLLFNBQVMsZ0JBQWdCO0FBQUEsWUFDOUIsVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUNELGlCQUFPLEVBQUUsU0FBUztBQUFBLFFBQ3BCO0FBQUEsTUFDRixDQUFDO0FBQ0QscUJBQWU7QUFDZixZQUFNLElBQUksUUFBUSxDQUFDLEdBQUc7QUFDdEIsVUFBSSxLQUFLLE9BQU8sRUFBRSxhQUFhLFNBQVUsa0JBQWlCLEVBQUU7QUFBQSxJQUM5RCxRQUFRO0FBQUEsSUFHUjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGNBQWMsR0FBRztBQUNuQixVQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBSSxTQUFTLE1BQU07QUFDakIsV0FBSyxlQUFlO0FBQ3BCLFdBQUssaUJBQWlCO0FBQ3RCLFlBQU0scUJBQXFCLElBQUk7QUFBQSxJQUVqQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLFFBQVEsT0FBTyxRQUFRLFlBQVksQ0FBQyxVQUFVO0FBQzVDLE1BQUksTUFBTSxTQUFTLGVBQWU7QUFDaEMsU0FBSyxpQkFBaUI7QUFBQSxFQUN4QixXQUFXLE1BQU0sU0FBUyxxQkFBcUI7QUFDN0MsU0FBSyxpQkFBaUIsS0FBSztBQUFBLEVBQzdCO0FBSUYsQ0FBQztBQUlELElBQUksUUFBUSxRQUFRLFdBQVc7QUFDN0IsVUFBUSxPQUFPLFVBQVUsWUFBWSxZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNLFFBQVEsY0FBYyxPQUFPO0FBQUEsSUFDckMsU0FBUyxLQUFLO0FBRVosWUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUN2RSxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFBQSxJQUN4QztBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBSUEsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLEtBQWMsWUFBWTtBQUMvRCxNQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRyxRQUFPO0FBQ25DLFNBQU8sY0FBYyxHQUFHLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDdkMsU0FBSyxNQUFPLDBCQUEwQixFQUFFLE1BQU0sSUFBSSxNQUFNLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUMvRSxVQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0gsQ0FBQztBQUVELFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELFNBQU8sQ0FBQyxDQUFDLEtBQUssT0FBTyxNQUFNLFlBQVksT0FBUSxFQUF5QixTQUFTO0FBQ25GO0FBSUEsSUFBTSw0QkFBNEIsb0JBQUksSUFBNEI7QUFBQSxFQUNoRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVELGVBQWUsWUFBOEI7QUFDM0MsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixTQUFPLEVBQUUsWUFBWTtBQUN2QjtBQUVBLGVBQWUsY0FBYyxLQUF1QztBQUtsRSxNQUFJLENBQUUsTUFBTSxVQUFVLEtBQU0sMEJBQTBCLElBQUksSUFBSSxJQUFJLEdBQUc7QUFDbkUsV0FBTyxFQUFFLElBQUksTUFBTSxRQUFRLEtBQUs7QUFBQSxFQUNsQztBQUNBLFVBQVEsSUFBSSxNQUFNO0FBQUEsSUFDaEIsS0FBSztBQUNILFlBQU0saUJBQWlCLElBQUksVUFBVSxJQUFJLEtBQUssSUFBSSxRQUFRO0FBQzFELGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxLQUFLLGdDQUFnQyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ3ZFLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxLQUFLLCtCQUErQixFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ3RFLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsVUFBSSxJQUFJLFVBQVUsUUFBUTtBQUN4QixjQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNsRCxXQUFXLElBQUksVUFBVSxTQUFTO0FBQ2hDLGNBQU0sTUFBTyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ3BELE9BQU87QUFDTCxjQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNsRDtBQUNBLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVyxJQUFJLE1BQU07QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVztBQUNqQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxnQkFBZ0I7QUFDdEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sU0FBUyxNQUFNO0FBQ3JCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFlBQVksSUFBSSxRQUFRLE1BQU07QUFDcEMsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLGFBQWEsSUFBSSxHQUFHLENBQUM7QUFDNUMsWUFBTSxLQUFLLHdCQUF3QixFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDakQsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSyxrQkFBa0I7QUFDckIsWUFBTSxJQUFJLE1BQU0sZUFBZSxFQUFFLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbEQsVUFBSSxDQUFDLElBQUksSUFBSTtBQUdYLDZCQUFxQjtBQUNyQiw0QkFBb0I7QUFDcEIsK0JBQXVCO0FBQ3ZCLGNBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxjQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUFBLE1BQy9DLE9BQU87QUFFTCxjQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsWUFBSSxTQUFTLEtBQU0sb0JBQW1CLEVBQUUscUJBQXFCO0FBQUEsTUFDL0Q7QUFDQSxZQUFNLEtBQUssbUNBQW1DLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUM1RCxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0sb0JBQW9CO0FBQzFCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLHFCQUFxQjtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLDRCQUE0QjtBQUMvQixZQUFNLFVBQVUsS0FBSztBQUFBLFFBQ25CO0FBQUEsUUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxJQUFJLE9BQU8sQ0FBQztBQUFBLE1BQ3ZEO0FBQ0EsWUFBTSxlQUFlLEVBQUUsdUJBQXVCLFFBQVEsQ0FBQztBQUV2RCxZQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsVUFBSSxTQUFTLEtBQU0sb0JBQW1CLE9BQU87QUFDN0MsVUFBSSwwQkFBMEIsS0FBTSxzQkFBcUIsT0FBTztBQUNoRSxVQUFJLDZCQUE2QixLQUFNLHlCQUF3QixPQUFPO0FBQ3RFLGFBQU8sV0FBVztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsWUFBTSxpQkFBaUI7QUFDdkIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sa0JBQWtCO0FBQ3hCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLG9CQUFvQjtBQUMxQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxxQkFBcUI7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSyxtQkFBbUI7QUFDdEIsWUFBTSxPQUFPLE1BQU0sWUFBWTtBQUMvQixZQUFNLFVBQVUsSUFBSSxJQUFJLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQy9ELFlBQU0sVUFBVSxNQUFNLG9CQUFvQixPQUFPO0FBQ2pELFlBQU0sS0FBSywwQkFBMEIsT0FBTztBQUM1QyxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0sb0JBQW9CLElBQUk7QUFDOUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0saUJBQWlCLElBQUk7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sY0FBYztBQUNwQixhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUN0QyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSyxlQUFlO0FBQ2xCLFlBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsWUFBTSxNQUFNLFVBQVUsQ0FBQztBQUN2QixZQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQ2pDLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQjtBQUFBLElBQ0E7QUFDRSxhQUFPLEVBQUUsSUFBSSxPQUFPLE9BQU8sdUJBQXVCO0FBQUEsRUFDdEQ7QUFDRjtBQUlBLGVBQWUsaUJBQWlCLFVBQWtCLEtBQWEsVUFBa0M7QUFDL0YsTUFBSSxrQkFBa0IsSUFBSSxRQUFRLEVBQUc7QUFDckMsTUFBSSxDQUFDLGdCQUFnQixJQUFJLFFBQVEsRUFBRztBQUVwQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBZ0JuQyxRQUFNLFVBQVUsSUFBSSxJQUFJLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUUxQyxNQUFJO0FBQ0osTUFBSTtBQUNGLGlCQUFhLFVBQVUsVUFBVTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsZ0JBQWdCLG9CQUFJLElBQVk7QUFBQSxJQUNsQyxDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLFdBQVcsbUJBQW1CLFVBQVUsS0FBSyxVQUFVLEdBQUc7QUFDaEU7QUFBQSxFQUNGO0FBUUEsUUFBTSxlQUFlLFdBQVcsT0FBTztBQUN2QyxhQUFXLFNBQVMsY0FBYyxXQUFXLFFBQVEsT0FBTztBQUM1RCxRQUFNLG1CQUFtQixlQUFlLFdBQVcsT0FBTztBQUMxRCxNQUFJLG1CQUFtQixHQUFHO0FBQ3hCLFVBQU0sS0FBSyw0QkFBNEI7QUFBQSxNQUNyQztBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsTUFBTSxXQUFXLE9BQU87QUFBQSxJQUMxQixDQUFDO0FBQUEsRUFDSDtBQU9BLE1BQUksV0FBVyxhQUFhLFdBQVcsR0FBRztBQUN4QyxVQUFNLEtBQUssNENBQXVDO0FBQUEsTUFDaEQ7QUFBQSxNQUNBLFdBQVcsZUFBZSxRQUFRLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxNQUMvQyxZQUFZLG9CQUFvQixVQUFVLE9BQU87QUFBQSxNQUNqRCxpQkFBaUIsaUJBQWlCLFVBQVUsU0FBUyxDQUFDLE1BQU0sQ0FBQztBQUFBLE1BQzdELG1CQUFtQixpQkFBaUIsVUFBVSxTQUFTLENBQUMsUUFBUSxDQUFDO0FBQUEsTUFDakUsMEJBQTBCLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUM1RDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsTUFDRCwrQkFBK0IsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQ2pFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsTUFDRCxpQ0FBaUMsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQ25FO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSCxPQUFPO0FBQ0wsVUFBTSxLQUFLLHdCQUF3QjtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxVQUFVLFdBQVcsYUFBYTtBQUFBLE1BQ2xDLE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDMUIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxNQUFJLFdBQVcsT0FBTyxXQUFXLEVBQUc7QUFXcEMsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELGFBQVcsS0FBSyxXQUFXLFFBQVE7QUFDakMsUUFBSSxFQUFFLGNBQWM7QUFDbEIsWUFBTSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUTtBQUFBLElBQ25ELE9BQU87QUFDTCxZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRO0FBQUEsSUFDbkQ7QUFHQSxVQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsUUFBSSxhQUFhLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDakQsa0JBQVksV0FBVztBQUN2QixrQkFBWSxhQUFhO0FBQ3pCLFlBQU0sa0JBQWtCLFdBQVc7QUFBQSxJQUNyQztBQUNBLFFBQUksZ0JBQWdCLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDcEQscUJBQWUsV0FBVztBQUMxQixxQkFBZSxhQUFhO0FBQzVCLFlBQU0scUJBQXFCLGNBQWM7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFLQSxhQUFXLFdBQVcsV0FBVyxhQUFhO0FBQzVDLFFBQUksTUFBTSxZQUFZLFFBQVEsUUFBUSxFQUFHO0FBQ3pDLFVBQU0sa0JBQWtCLFFBQVEsYUFBYSxRQUFRLFFBQVE7QUFBQSxFQUMvRDtBQUNBLE1BQUksV0FBVyxZQUFZLFNBQVMsR0FBRztBQUNyQyxVQUFNLEtBQUssMENBQTBDO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLFNBQVMsV0FBVyxZQUFZO0FBQUEsTUFDaEMsYUFBYSxNQUFNLHFCQUFxQjtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNIO0FBUUEsUUFBTSxlQUFlLE1BQU0sa0JBQWtCO0FBQzdDLE1BQUksaUJBQWlCO0FBQ3JCLFFBQU0sYUFBdUMsQ0FBQztBQUM5QyxhQUFXLEtBQUssV0FBVyxRQUFRO0FBQ2pDLFVBQU0sT0FBTyxhQUFhLEVBQUUsY0FBYyxJQUFJLEVBQUUsUUFBUTtBQUN4RCxVQUFNLE1BQU07QUFBQSxNQUNWLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxJQUNKO0FBQ0EsUUFBSSxRQUFRLEtBQUssUUFBUSxLQUFLO0FBQzVCLHdCQUFrQjtBQUNsQjtBQUFBLElBQ0Y7QUFDQSxlQUFXLEtBQUssQ0FBQztBQUFBLEVBQ25CO0FBQ0EsTUFBSSxpQkFBaUIsR0FBRztBQUN0QixVQUFNLEtBQUssbUNBQW1DO0FBQUEsTUFDNUM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSxXQUFXLFdBQVcsRUFBRztBQUc3QixRQUFNLFdBQVcsb0JBQUksSUFBOEI7QUFDbkQsYUFBVyxLQUFLLFlBQVk7QUFDMUIsVUFBTSxNQUFNLFNBQVMsSUFBSSxFQUFFLGNBQWMsS0FBSyxDQUFDO0FBQy9DLFFBQUksS0FBSyxDQUFDO0FBQ1YsYUFBUyxJQUFJLEVBQUUsZ0JBQWdCLEdBQUc7QUFBQSxFQUNwQztBQUVBLGFBQVcsQ0FBQyxRQUFRLE1BQU0sS0FBSyxVQUFVO0FBQ3ZDLFVBQU0sTUFBTSxNQUFNLGdCQUFnQixRQUFRLFlBQVksS0FBSyxRQUFRO0FBQ25FLFFBQUksUUFBUTtBQUNaLGVBQVcsS0FBSyxRQUFRO0FBQ3RCLFlBQU0sV0FBVyxJQUFJLGFBQWEsRUFBRSxRQUFRO0FBQzVDLFVBQUksVUFBVTtBQUdaLGlCQUFTLGVBQWU7QUFDeEIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGdCQUFnQixFQUFFO0FBQzNCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxjQUFjLEVBQUU7QUFDekIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGlCQUFpQixFQUFFO0FBQzVCLGNBQU0sT0FBTyxTQUFTLG1CQUFtQixTQUFTLG1CQUFtQixTQUFTLENBQUM7QUFDL0UsY0FBTSxPQUFPLEVBQUUsbUJBQW1CLENBQUM7QUFDbkMsWUFBSSxTQUFTLENBQUMsUUFBUSxLQUFLLGdCQUFnQixLQUFLLGNBQWM7QUFDNUQsbUJBQVMsbUJBQW1CLEtBQUssSUFBSTtBQUFBLFFBQ3ZDO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxVQUEwQixFQUFFLEdBQUcsR0FBRyxnQkFBZ0IsSUFBSSxPQUFPO0FBQ25FLFlBQUksYUFBYSxFQUFFLFFBQVEsSUFBSTtBQUMvQixpQkFBUztBQUFBLE1BQ1g7QUFDQSxVQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsR0FBRztBQUNoRCxZQUFJLG1CQUFtQixLQUFLLEVBQUUsUUFBUTtBQUFBLE1BQ3hDO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLE1BQU07QUFDbkUsUUFBSSxRQUFRLEdBQUc7QUFDYixZQUFNLEtBQUssbUJBQW1CO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsT0FBTyxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUU7QUFBQSxNQUN2QyxDQUFDO0FBR0QsWUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8saUJBQWlCO0FBQ3hCLGNBQU0scUJBQXFCLE1BQU07QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRSxVQUFVLHVCQUF1QjtBQUNqRSxZQUFNLFlBQVksUUFBUSxXQUFXO0FBQUEsSUFDdkM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxnQkFDYixRQUNBLElBQ0EsV0FDQSxVQUNvQjtBQUNwQixRQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFDckMsTUFBSSxJQUFLLFFBQU87QUFDaEIsUUFBTSxNQUFpQjtBQUFBLElBQ3JCLFFBQVEsU0FBUztBQUFBLElBQ2pCLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLGlCQUFpQjtBQUFBLElBQ2pCLGNBQWMsQ0FBQztBQUFBLElBQ2Ysb0JBQW9CLENBQUM7QUFBQSxJQUNyQixnQkFBZ0IsQ0FBQyxRQUFRO0FBQUEsSUFDekIsWUFBWTtBQUFBLEVBQ2Q7QUFDQSxRQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFFBQU0sS0FBSyxlQUFlLEVBQUUsUUFBUSxLQUFLLFdBQVcsSUFBSSxNQUFNLEVBQUUsQ0FBQztBQUNqRSxTQUFPO0FBQ1Q7QUFJQSxlQUFlLG1CQUFrQztBQUMvQyxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELFlBQU0sWUFBWSxRQUFRLE1BQU07QUFBQSxJQUNsQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWUsOEJBQTZDO0FBTzFELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELFlBQU0sWUFBWSxRQUFRLE1BQU07QUFBQSxJQUNsQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWUsU0FBUyxRQUErQjtBQUNyRCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLGFBQVcsVUFBVSxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ3JDLFVBQU0sWUFBWSxRQUFRLE1BQU07QUFBQSxFQUNsQztBQUNGO0FBRUEsZUFBZSxZQUFZLFFBQWdCLFFBQStCO0FBQ3hFLFFBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUNyQyxNQUFJLENBQUMsSUFBSztBQUNWLFFBQU0sU0FBUyxPQUFPLE9BQU8sSUFBSSxZQUFZO0FBQzdDLE1BQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsVUFBTSxlQUFlLE1BQU07QUFDM0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sS0FBSyx1Q0FBdUMsRUFBRSxPQUFPLENBQUM7QUFDNUQ7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFFBQU0sS0FBSyxXQUFXLElBQUksVUFBVTtBQUNwQyxRQUFNLE1BQU0sSUFBSSxXQUFXLE1BQU0sR0FBRyxFQUFFO0FBQ3RDLFFBQU0sVUFBVSxPQUFPLE1BQU0sSUFBSSxFQUFFLElBQUksV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUM3RCxRQUFNLFdBQVcsUUFBUSxNQUFNLElBQUksRUFBRSxJQUFJLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFFL0QsUUFBTSxVQUEwQjtBQUFBLElBQzlCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsSUFDaEIsYUFBYSxJQUFJO0FBQUEsSUFDakIsVUFBVSxJQUFJLGVBQWUsS0FBSyxHQUFHO0FBQUEsSUFDckMsWUFBWSxVQUFVO0FBQUEsSUFDdEIsWUFBWSxJQUFJO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFvQjtBQUFBLElBQ3hCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsSUFDaEIsYUFBYSxJQUFJO0FBQUEsSUFDakIsb0JBQW9CLElBQUk7QUFBQSxFQUMxQjtBQUVBLFFBQU0sWUFBWSxZQUFZLE1BQU0sSUFBSSxHQUFHLElBQUksT0FBTyxNQUFNLFNBQVMsT0FBTyxXQUFXLElBQUksS0FBSyxHQUFHLFNBQVMsV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUVsSSxNQUFJO0FBQ0YsVUFBTSxPQUFPLFFBQVE7QUFBQSxNQUNuQixNQUFNO0FBQUEsTUFDTixlQUFlQyxVQUFTLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUMvRCxTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQ0QsVUFBTSxPQUFPLFFBQVE7QUFBQSxNQUNuQixNQUFNO0FBQUEsTUFDTixlQUFlQSxVQUFTLEtBQUssVUFBVSxNQUFNLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUM1RCxTQUFTLFNBQVMsTUFBTSxJQUFJLEdBQUcsSUFBSSxLQUFLLG1CQUFtQixNQUFNLGFBQWEsV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUFBLElBQ3RHLENBQUM7QUFDRCxVQUFNLGVBQWUsTUFBTTtBQUMzQjtBQUtFLFlBQU0sUUFBUSxNQUFNLFlBQVksR0FBRyxNQUFNO0FBQ3pDLFlBQU0sU0FBUSxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQ2xELFlBQU0sZUFBZSxRQUFRLEtBQUssY0FBYyxRQUFRLEtBQUssYUFBYTtBQUMxRSxZQUFNLFlBQVksUUFBUTtBQUFBLFFBQ3hCLFlBQVksZUFBZSxPQUFPO0FBQUEsUUFDbEMsV0FBVztBQUFBLFFBQ1gsZUFBZSxJQUFJO0FBQUEsUUFDbkIsaUJBQWlCLE1BQU0sa0JBQWtCLEtBQUssT0FBTztBQUFBLFFBQ3JELGVBQWU7QUFBQSxNQUNqQixDQUFDO0FBQUEsSUFDSDtBQUdBO0FBQ0UsWUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLFlBQU0sUUFBUSxJQUFJLE1BQU0sS0FBSyxDQUFDO0FBQzlCLFlBQU0sVUFBUyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUN0QyxpQkFBVyxLQUFLLFFBQVE7QUFDdEIsY0FBTSxFQUFFLFFBQVEsSUFBSTtBQUFBLFVBQ2xCLElBQUk7QUFBQSxVQUNKLEtBQUs7QUFBQSxZQUNILEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLE1BQU0sSUFBSTtBQUNkLFlBQU0sa0JBQWtCLEdBQUc7QUFBQSxJQUM3QjtBQUNBLFVBQU0sS0FBSyxtQkFBbUI7QUFBQSxNQUM1QjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFFBQVEsT0FBTztBQUFBLE1BQ2YsS0FBSyxXQUFXLElBQUksTUFBTTtBQUFBLE1BQzFCLE1BQU07QUFBQSxJQUNSLENBQUM7QUFDRDtBQUNFLFlBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsWUFBTSxjQUFjO0FBQUEsUUFDbEIsUUFBUTtBQUFBLFFBQ1IsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTztBQUFBLFFBQ1AsZUFBZSxLQUFLO0FBQUEsUUFDcEIsd0JBQXdCLEtBQUs7QUFBQSxRQUM3QixrQkFBa0I7QUFBQSxNQUNwQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osUUFBSSxlQUFlLGFBQWE7QUFDOUIsWUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxZQUFNLFNBQ0osSUFBSSxhQUFhLFNBQ2IsZUFDQSxJQUFJLGFBQWEsZUFDZixpQkFDQSxJQUFJLGFBQWEsWUFDZixrQkFDQSxLQUFLO0FBQ2YsWUFBTSxjQUFjO0FBQUEsUUFDbEI7QUFBQSxRQUNBLE9BQU8sS0FBSztBQUFBLFFBQ1osWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU8sSUFBSTtBQUFBLFFBQ1gsZUFBZSxLQUFLO0FBQUEsUUFDcEIsd0JBQXdCLEtBQUs7QUFBQSxRQUM3QixrQkFDRSxJQUFJLGFBQWEsZUFBZSxJQUFJLG1CQUFtQixLQUFLO0FBQUEsTUFDaEUsQ0FBQztBQUNELFlBQU0sTUFBTyxnQkFBZ0I7QUFBQSxRQUMzQjtBQUFBLFFBQ0E7QUFBQSxRQUNBLFVBQVUsSUFBSTtBQUFBLFFBQ2QsUUFBUSxJQUFJO0FBQUEsUUFDWixTQUFTLElBQUk7QUFBQSxRQUNiLGtCQUFrQixJQUFJO0FBQUEsTUFDeEIsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMLFlBQU0sTUFBTyxnQkFBZ0IsRUFBRSxRQUFRLFFBQVEsR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDeEU7QUFBQSxFQUVGLFVBQUU7QUFDQSxVQUFNLGVBQWU7QUFBQSxFQUN2QjtBQUNGO0FBSUEsZUFBZSxXQUFXLFFBQStCO0FBTXZELFFBQU0sWUFBWSxpQkFBaUIsTUFBTTtBQUN6QyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsUUFBUSxLQUFLLGVBQWUsQ0FBQztBQUNuRSxNQUFJLENBQUUsTUFBTSxhQUFhLE1BQU0sR0FBSTtBQUNqQyxVQUFNLE9BQU0sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDbkMsVUFBTSxhQUFhLFFBQVE7QUFBQSxNQUN6QixRQUFRLFNBQVM7QUFBQSxNQUNqQixnQkFBZ0I7QUFBQSxNQUNoQixZQUFZO0FBQUEsTUFDWixpQkFBaUI7QUFBQSxNQUNqQixjQUFjLENBQUM7QUFBQSxNQUNmLG9CQUFvQixDQUFDO0FBQUEsTUFDckIsZ0JBQWdCLENBQUM7QUFBQSxNQUNqQixZQUFZO0FBQUEsSUFDZCxDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFdBQVcsUUFBUSxLQUFLLENBQUM7QUFDNUQ7QUFFQSxlQUFlLGFBQTRCO0FBQ3pDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxLQUFLLHlCQUF5QixFQUFFLE9BQU8sU0FBUyxPQUFPLENBQUM7QUFDOUQsYUFBVyxLQUFLLFVBQVU7QUFDeEIsVUFBTSxXQUFXLEVBQUUsTUFBTTtBQUFBLEVBQzNCO0FBQ0Y7QUFXQSxlQUFlLGtCQUFpQztBQUM5QyxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUFBLEVBQ3ZFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFDOUU7QUFBQSxFQUNGO0FBQ0EsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixNQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxZQUFZLENBQUMsSUFBSSxLQUFLO0FBQ2xELFVBQU0sS0FBSyxrQ0FBa0M7QUFDN0M7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLGdDQUFnQyxLQUFLLElBQUksR0FBRyxHQUFHO0FBQ2xELFVBQU0sS0FBSywrREFBK0Q7QUFBQSxNQUN4RSxLQUFLLFdBQVcsSUFBSSxHQUFHO0FBQUEsSUFDekIsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUd0RSxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUEsTUFDdEIsT0FBTztBQUFBLElBQ1QsQ0FBQztBQUNELFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyx1Q0FBdUMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUN0RTtBQUdBLE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTztBQUFBLE1BQ1AsTUFBTSxNQUFNO0FBQ1YsY0FBTSxJQUFJLE9BQU87QUFDakIsZUFBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUM7QUFDcEQsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLEdBQUc7QUFDM0UsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFBQSxNQUM5RTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ3pFO0FBQ0Y7QUFhQSxJQUFNLGtCQUFrQjtBQUV4QixlQUFlLGtCQUEwQztBQUN2RCxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGVBQWU7QUFDOUQsUUFBTSxLQUFLLE9BQU8sZUFBZTtBQUNqQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLGdCQUFnQixJQUFrQztBQUMvRCxNQUFJLE9BQU8sTUFBTTtBQUNmLFVBQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxlQUFlO0FBQUEsRUFDcEQsT0FBTztBQUNMLFVBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZUFBZSxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQzNEO0FBQ0Y7QUFFQSxlQUFlLG1CQUFrQztBQUMvQyxRQUFNLFFBQVEsTUFBTSxrQkFBa0I7QUFDdEMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUsseUJBQXlCO0FBQ3BDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxrQkFBa0I7QUFBQSxJQUN0QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELHVCQUFxQixPQUFPO0FBQzVCLE9BQUssWUFBWTtBQUNqQixRQUFNLEtBQUssd0JBQXdCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQzNFLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksd0JBQStEO0FBRW5FLFNBQVMscUJBQXFCLFNBQXVCO0FBQ25ELE1BQUksMEJBQTBCLEtBQU0sZUFBYyxxQkFBcUI7QUFDdkUsMEJBQXdCLFlBQVksTUFBTTtBQUN4QyxTQUFLLFlBQVksRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNoQyxXQUFLLEtBQUssdUJBQXVCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDckQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHNCQUE0QjtBQUNuQyxNQUFJLDBCQUEwQixNQUFNO0FBQ2xDLGtCQUFjLHFCQUFxQjtBQUNuQyw0QkFBd0I7QUFBQSxFQUMxQjtBQUNGO0FBRUEsZUFBZSxvQkFBbUM7QUFDaEQsc0JBQW9CO0FBQ3BCLFFBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxRQUFNLFFBQVEsTUFBTSxnQkFBZ0I7QUFDcEMsUUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixRQUFNLE9BQU8sTUFBTSxrQkFBa0I7QUFDckMsUUFBTSxrQkFBa0IsSUFBSTtBQUM1QixRQUFNLEtBQUssMEJBQTBCO0FBQUEsSUFDbkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxjQUE2QjtBQUMxQyxNQUFJLE9BQU8sTUFBTSxrQkFBa0I7QUFDbkMsTUFBSSxTQUFTLE1BQU07QUFFakIsd0JBQW9CO0FBQ3BCO0FBQUEsRUFDRjtBQUlBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUVBLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFFRCxVQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsZUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsVUFBSSxJQUFJLFNBQVMsS0FBSyxTQUFTLE9BQU8sR0FBRztBQUN2QyxjQUFNLGVBQWUsUUFBUSxLQUFLLFNBQVMsT0FBTztBQUNsRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLGtCQUFrQixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNLFNBQVMsTUFBTSxrQkFBa0I7QUFDdkMsTUFBSSxDQUFDLFFBQVE7QUFDWCx3QkFBb0I7QUFDcEIsVUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyx5QkFBeUIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ2pFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLE1BQU0saUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUNuRSxNQUFJLFFBQVEsTUFBTSxnQkFBZ0I7QUFDbEMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLGdCQUFnQixJQUFJLEVBQUU7QUFBQSxJQUM5RCxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxXQUFRLE1BQU0sa0JBQWtCLEtBQU07QUFDdEMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyxnQkFBZ0I7QUFBQSxNQUN6QixRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLFdBQVcsTUFBTSxrQkFBa0I7QUFBQSxNQUNuQyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyw0Q0FBNEM7QUFBQSxNQUNyRCxRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sZUFBZSxPQUFPLFFBQVEsT0FBTyxPQUFPO0FBQ2xELFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBV0EsSUFBTSxzQkFBc0I7QUFFNUIsZUFBZSxxQkFBNkM7QUFDMUQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxtQkFBbUI7QUFDbEUsUUFBTSxLQUFLLE9BQU8sbUJBQW1CO0FBQ3JDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsbUJBQW1CLElBQWtDO0FBQ2xFLE1BQUksT0FBTyxLQUFNLE9BQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxtQkFBbUI7QUFBQSxNQUNsRSxPQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUNwRTtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELFFBQU0sUUFBUSxNQUFNLHFCQUFxQjtBQUN6QyxNQUFJLFVBQVUsR0FBRztBQUNmLFVBQU0sS0FBSyw2QkFBNkI7QUFDeEM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFVBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsSUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxFQUFFLHFCQUFxQixDQUFDO0FBQUEsRUFDbkU7QUFDQSxRQUFNLHFCQUFxQjtBQUFBLElBQ3pCLGNBQWM7QUFBQSxJQUNkLFdBQVc7QUFBQSxJQUNYLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsMEJBQXdCLE9BQU87QUFDL0IsT0FBSyxlQUFlO0FBQ3BCLFFBQU0sS0FBSyw0QkFBNEIsRUFBRSxRQUFRLE9BQU8sY0FBYyxRQUFRLENBQUM7QUFDL0UsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsSUFBSSwyQkFBa0U7QUFFdEUsU0FBUyx3QkFBd0IsU0FBdUI7QUFDdEQsTUFBSSw2QkFBNkIsS0FBTSxlQUFjLHdCQUF3QjtBQUM3RSw2QkFBMkIsWUFBWSxNQUFNO0FBQzNDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLFNBQVMseUJBQStCO0FBQ3RDLE1BQUksNkJBQTZCLE1BQU07QUFDckMsa0JBQWMsd0JBQXdCO0FBQ3RDLCtCQUEyQjtBQUFBLEVBQzdCO0FBQ0Y7QUFFQSxlQUFlLHVCQUFzQztBQUNuRCx5QkFBdUI7QUFDdkIsUUFBTSxRQUFRLE9BQU8sTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3ZDLFFBQU0sbUJBQW1CLElBQUk7QUFDN0IsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxLQUFLLDhCQUE4QjtBQUFBLElBQ3ZDLFNBQVMsVUFBVTtBQUFBLElBQ25CLFdBQVcsTUFBTSxhQUFhO0FBQUEsRUFDaEMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsaUJBQWdDO0FBQzdDLE1BQUksT0FBTyxNQUFNLHFCQUFxQjtBQUN0QyxNQUFJLFNBQVMsTUFBTTtBQUNqQiwyQkFBdUI7QUFDdkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLGFBQWEsTUFBTTtBQUMxQixVQUFNLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUyxXQUFXO0FBQ2pFLFFBQUksVUFBVSxnQkFBZ0I7QUFDNUI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLG9EQUFvRDtBQUFBLE1BQzdELFVBQVUsS0FBSyxTQUFTO0FBQUEsTUFDeEIsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUNELFVBQU0sa0JBQWtCLEtBQUssU0FBUyxPQUFPO0FBQzdDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBRUEsUUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsMkJBQXVCO0FBQ3ZCLFVBQU0sbUJBQW1CLElBQUk7QUFDN0IsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLEtBQUssNkJBQTZCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNyRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBR0EsTUFBSSxNQUFNLFlBQVksT0FBTyxPQUFPLEdBQUc7QUFDckMsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBTUEsUUFBTSxNQUNKLE9BQU8sV0FBVyxhQUNkLDBCQUEwQixPQUFPLE9BQU8sS0FDeEMsaUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUM3RCxNQUFJLFFBQVEsTUFBTSxtQkFBbUI7QUFDckMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLG1CQUFtQixJQUFJLEVBQUU7QUFBQSxJQUNqRSxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxXQUFRLE1BQU0scUJBQXFCLEtBQU07QUFDekMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sS0FBSyxvQkFBb0I7QUFBQSxNQUM3QixVQUFVLE9BQU87QUFBQSxNQUNqQixhQUFhLE9BQU8sV0FBVyxhQUFhLE9BQU8sT0FBTztBQUFBLE1BQzFELFdBQVcsTUFBTSxxQkFBcUI7QUFBQSxNQUN0QyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxVQUFVLE9BQU87QUFBQSxNQUNqQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQUEsRUFDakM7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFJQSxlQUFlLFdBQ2IsUUFDQSxVQUNBLEtBQ0EsS0FDQSxLQUNlO0FBQ2YsUUFBTSxNQUFPLHdCQUF3QixFQUFFLFFBQVEsVUFBVSxLQUFLLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUNyRixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLEtBQU07QUFDeEQsUUFBTSxVQUE2QjtBQUFBLElBQ2pDLGdCQUFnQjtBQUFBLElBQ2hCO0FBQUEsSUFDQTtBQUFBLElBQ0EsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3BDLFlBQVk7QUFBQSxJQUNaLE9BQU8sY0FBYyxHQUFHO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxLQUFLLFdBQVcsUUFBUSxXQUFXO0FBQ3pDLFFBQU0sT0FBTyxNQUFNLEtBQUssS0FBSyxVQUFVLE9BQU8sQ0FBQztBQUMvQyxRQUFNLE9BQU8sbUJBQW1CLEVBQUUsSUFBSSxJQUFJO0FBQzFDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxPQUFPLFFBQVE7QUFBQSxNQUNuQjtBQUFBLE1BQ0EsZUFBZUEsVUFBUyxLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsTUFDL0QsU0FBUyxlQUFlLE1BQU0sSUFBSSxRQUFRO0FBQUEsSUFDNUMsQ0FBQztBQUFBLEVBQ0gsU0FBUyxNQUFNO0FBQ2IsVUFBTSxNQUFPLDRCQUE0QixFQUFFLEdBQUcsY0FBYyxJQUFJLEVBQUUsQ0FBQztBQUFBLEVBQ3JFO0FBQ0Y7QUFFQSxlQUFlLEtBQUssR0FBNEI7QUFDOUMsUUFBTSxNQUFNLElBQUksWUFBWSxFQUFFLE9BQU8sQ0FBQztBQUN0QyxRQUFNLFNBQVMsTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLEdBQUc7QUFDeEQsUUFBTSxNQUFNLE1BQU0sS0FBSyxJQUFJLFdBQVcsTUFBTSxDQUFDLEVBQzFDLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUU7QUFDVixTQUFPLElBQUksTUFBTSxHQUFHLENBQUM7QUFDdkI7QUFJQSxlQUFlLGlCQUFpQixPQUErQjtBQUM3RCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLE1BQU07QUFDdEQsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU87QUFBQSxNQUNQLGVBQWU7QUFBQSxNQUNmLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxNQUFJLENBQUMsT0FBTztBQUlWLFFBQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFlBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUMzQyxVQUFJLFNBQVMsS0FBSyxpQkFBa0I7QUFBQSxJQUN0QztBQUtBLFFBQUksS0FBSyxXQUFXO0FBQ2xCLFlBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTO0FBQ2xELFVBQUksTUFBTSw4QkFBK0I7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sSUFBSSxNQUFNLE9BQU8saUJBQWlCO0FBSXhDLFFBQUksV0FBVztBQUNmLFFBQUksU0FBUyxVQUFVLFNBQVMsV0FBVyxFQUFFLGdCQUFnQjtBQUMzRCxpQkFBVyxNQUFNLE9BQU8sYUFBYSxTQUFTLE1BQU07QUFBQSxJQUN0RDtBQUNBLFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU8sRUFBRTtBQUFBLE1BQ1QsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU87QUFBQSxNQUNQLGVBQWUsRUFBRTtBQUFBLE1BQ2pCLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLEtBQUssdUJBQXVCO0FBQUEsTUFDaEMsT0FBTyxFQUFFO0FBQUEsTUFDVCxNQUFNLEVBQUU7QUFBQSxNQUNSLGdCQUFnQixFQUFFO0FBQUEsTUFDbEIsbUJBQW1CLFNBQVM7QUFBQSxNQUM1QiwwQkFBMEI7QUFBQSxJQUM1QixDQUFDO0FBQ0QsUUFBSSxDQUFDLFVBQVU7QUFDYixZQUFNLEtBQUssOENBQThDO0FBQUEsUUFDdkQsWUFBWSxTQUFTO0FBQUEsUUFDckIsZ0JBQWdCLEVBQUU7QUFBQSxRQUNsQixLQUFLLHdDQUF3QyxFQUFFO0FBQUEsTUFDakQsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sTUFBTSxlQUFlLGNBQWMsSUFBSSxXQUFXO0FBQ3hELFVBQU0sU0FDSixRQUFRLFNBQ0osZUFDQSxRQUFRLGVBQ04saUJBQ0EsUUFBUSxZQUNOLGtCQUNBO0FBQ1YsVUFBTSxVQUNKLGVBQWUsZUFBZSxRQUFRLGVBQWUsSUFBSSxtQkFBbUI7QUFDOUUsVUFBTSxjQUFjO0FBQUEsTUFDbEI7QUFBQSxNQUNBLE9BQU87QUFBQSxNQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPLGNBQWMsR0FBRyxFQUFFO0FBQUEsTUFDMUIsZUFBZTtBQUFBLE1BQ2Ysd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sS0FBSywyQkFBMkI7QUFBQSxNQUNwQyxVQUFVO0FBQUEsTUFDVixrQkFBa0I7QUFBQSxNQUNsQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxvQkFBb0IsT0FBK0I7QUFDaEUsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxLQUFLO0FBQ2pCLFVBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEM7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLE9BQU87QUFJVixVQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFlBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUMzQyxVQUFJLFNBQVMsS0FBSyxpQkFBa0I7QUFBQSxJQUN0QztBQUlBLFVBQU0sZ0JBQWdCLE1BQU0sdUJBQXVCO0FBQ25ELFFBQUksZUFBZTtBQUNqQixZQUFNLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLGFBQWE7QUFDakQsVUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLLE1BQU0sOEJBQStCO0FBQUEsSUFDbkU7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sTUFBTSxPQUFPLGFBQWEsc0JBQXNCO0FBQzdELFFBQUksQ0FBQyxNQUFNO0FBQ1QsVUFBSSxNQUFPLE9BQU0sS0FBSyxpREFBaUQ7QUFDdkUsWUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QyxZQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JEO0FBQUEsSUFDRjtBQUNBLFVBQU0sU0FBUyxrQkFBa0IsSUFBSTtBQUNyQyxRQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFlBQU0sS0FBSyw4Q0FBOEM7QUFDekQsWUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QyxZQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JEO0FBQUEsSUFDRjtBQUNBLFVBQU0sWUFBWSxNQUFNO0FBQ3hCLFVBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQsUUFBSSxNQUFPLE9BQU0sS0FBSywyQkFBMkIsRUFBRSxPQUFPLE9BQU8sT0FBTyxDQUFDO0FBQUEsRUFDM0UsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlEQUFpRCxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ2hGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBSUEsZUFBZSxpQkFBZ0M7QUFDN0MsUUFBTSxRQUFRLE1BQU0sV0FBVztBQUMvQixVQUFRLFFBQVEsWUFBWSxFQUFFLE1BQU0saUJBQWlCLE1BQU0sQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUM5RTtBQUVBLGVBQWUsYUFBc0M7QUFDbkQsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLFdBQVc7QUFDZixNQUFJO0FBQ0YsVUFBTSxPQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFDM0YsZUFBVyxLQUFLO0FBQUEsRUFDbEIsUUFBUTtBQUFBLEVBR1I7QUFDQSxRQUFNLGdCQUFnQixNQUFNLGtCQUFrQjtBQUM5QyxRQUFNLG1CQUFtQixNQUFNLHFCQUFxQjtBQUNwRCxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsU0FBTztBQUFBLElBQ0wsU0FBUztBQUFBLElBQ1QsVUFBVSxlQUFlLFFBQVE7QUFBQSxJQUNqQyxZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVk7QUFBQSxNQUNWLFFBQVEsbUJBQW1CLFFBQVEsb0JBQW9CO0FBQUEsTUFDdkQ7QUFBQSxNQUNBLGFBQWEsZ0JBQWdCLGVBQWU7QUFBQSxNQUM1QyxlQUFlLGdCQUFnQixpQkFBaUI7QUFBQSxNQUNoRCxlQUFlLGdCQUFnQixpQkFBaUI7QUFBQSxJQUNsRDtBQUFBLElBQ0EsY0FBYztBQUFBLE1BQ1osT0FBTztBQUFBLE1BQ1AsU0FBUywwQkFBMEI7QUFBQSxNQUNuQyxXQUFXLGFBQWEsYUFBYTtBQUFBLE1BQ3JDLGdCQUFnQixhQUFhLGdCQUFnQjtBQUFBLElBQy9DO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxNQUNmLE9BQU87QUFBQSxNQUNQLFNBQVMsNkJBQTZCO0FBQUEsTUFDdEMsV0FBVyxnQkFBZ0IsYUFBYTtBQUFBLE1BQ3hDLGdCQUFnQixnQkFBZ0IsZ0JBQWdCO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBeUM7QUFDL0QsU0FBTztBQUFBLElBQ0wsT0FBTyxFQUFFO0FBQUEsSUFDVCxNQUFNLEVBQUU7QUFBQSxJQUNSLFFBQVEsRUFBRTtBQUFBLElBQ1YsU0FBUyxFQUFFO0FBQUEsSUFDWCxhQUFhLEVBQUU7QUFBQSxJQUNmLGNBQWMsRUFBRTtBQUFBLElBQ2hCLHVCQUF1QixFQUFFO0FBQUEsSUFDekIsUUFBUSxFQUFFLElBQUksU0FBUztBQUFBLElBQ3ZCLFdBQVcsRUFBRSxJQUFJLFVBQVUsSUFBSSxFQUFFLElBQUksTUFBTSxFQUFFLElBQUk7QUFBQSxFQUNuRDtBQUNGO0FBRUEsU0FBUyxXQUFXLEtBQXFCO0FBRXZDLFFBQU0sSUFBSSxJQUFJLEtBQUssR0FBRztBQUN0QixNQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU8sSUFBSSxRQUFRLFNBQVMsRUFBRTtBQUM3RCxRQUFNLE1BQU0sQ0FBQyxHQUFXLElBQUksTUFBTSxPQUFPLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUMzRCxTQUNFLEdBQUcsRUFBRSxlQUFlLENBQUMsSUFBSSxJQUFJLEVBQUUsWUFBWSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUNwRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7QUFFOUU7QUFFQSxTQUFTLFVBQVUsR0FBcUI7QUFDdEMsU0FBTyxXQUFXLEVBQUUsS0FBSyxjQUFjLEVBQUUsSUFBSTtBQUMvQztBQVNBLFNBQVMsZUFBZSxNQUF5QjtBQUMvQyxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1DLE9BQU07QUFDWixVQUFJLE9BQU9BLEtBQUksZUFBZSxTQUFVLE1BQUssSUFBSUEsS0FBSSxVQUFVO0FBQy9ELGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsS0FBSztBQUN4QjtBQU9BLFNBQVMsb0JBQW9CLE1BQWUsVUFBbUM7QUFDN0UsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNQSxPQUFNO0FBQ1osVUFBSUEsS0FBSSxlQUFlLFVBQVU7QUFDL0IsZUFBTyxPQUFPLEtBQUtBLElBQUcsRUFBRSxLQUFLO0FBQUEsTUFDL0I7QUFDQSxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBUUEsU0FBUyxpQkFBaUIsTUFBZSxVQUFrQixNQUF5QjtBQUNsRixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsTUFBSSxRQUF3QztBQUM1QyxTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUEsT0FBTTtBQUNaLFVBQUlBLEtBQUksZUFBZSxVQUFVO0FBQy9CLGdCQUFRQTtBQUNSO0FBQUEsTUFDRjtBQUNBLGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLE1BQUksTUFBZTtBQUNuQixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVSxRQUFPLElBQUksUUFBUSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzFGLFVBQU8sSUFBZ0MsR0FBRztBQUFBLEVBQzVDO0FBQ0EsTUFBSSxRQUFRLE9BQVcsUUFBTztBQUM5QixNQUFJLFFBQVEsS0FBTSxRQUFPO0FBQ3pCLE1BQUksT0FBTyxRQUFRLFNBQVUsUUFBTyxJQUFJLE9BQU8sR0FBRztBQUNsRCxNQUFJLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxjQUFjLElBQUksTUFBTTtBQUN2RCxTQUFPLE9BQU8sS0FBSyxHQUE4QixFQUFFLEtBQUs7QUFDMUQ7QUFFQSxTQUFTLFdBQVcsR0FBbUI7QUFHckMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLElBQUksQ0FBQztBQUN4QixVQUFNLE9BQU8sT0FBTyxZQUFZLE9BQU8sU0FBUyxZQUFPO0FBQ3ZELFdBQU8sT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTLGdCQUM5QyxPQUNBLEdBQUcsT0FBTyxJQUFJLEdBQUcsSUFBSTtBQUFBLEVBQzNCLFFBQVE7QUFDTixXQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFBQSxFQUNoRDtBQUNGO0FBS0MsV0FBdUMsZUFBZTtBQUFBLEVBQ3JEO0FBQUEsRUFDQSxVQUFVO0FBQUEsRUFDVixVQUFVO0FBQUEsRUFDVixTQUFTO0FBQUEsRUFDVCxVQUFVLE1BQU0sU0FBUyxVQUFVO0FBQUEsRUFDbkMsT0FBTztBQUFBLEVBQ1AsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsZUFBZTtBQUFBLEVBQ2YsaUJBQWlCO0FBQUEsRUFDakIsaUJBQWlCO0FBQUEsRUFDakIsa0JBQWtCO0FBQ3BCOyIsCiAgIm5hbWVzIjogWyJ0b0Jhc2U2NCIsICJvYmoiLCAiaW5mbyIsICJ0b0Jhc2U2NCIsICJvYmoiXQp9Cg==
