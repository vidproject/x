// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function setArchiveSnapshot(snapshot) {
  await setRaw("archiveSnapshot", snapshot);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
var RECENT_TWEET_SIGHTINGS_MAX = 80;
async function getRecentTweetSightings() {
  return getRaw("recentTweetSightings");
}
async function prependRecentTweetSightings(rows) {
  if (rows.length === 0) return;
  const cur = await getRecentTweetSightings();
  const seen = /* @__PURE__ */ new Set();
  const next = [];
  for (const row of rows) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  for (const row of cur) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  next.length = Math.min(next.length, RECENT_TWEET_SIGHTINGS_MAX);
  await setRaw("recentTweetSightings", next);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Verify the PAT can write to the configured branch without creating a
   * commit. Moving a ref to its current SHA is a no-op, but GitHub still
   * enforces the Contents: Write permission required by commitFiles().
   */
  async verifyWriteAccess() {
    const head = await this.getBranchHead();
    await this.fetchJson(
      "PATCH",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
      {
        sha: head.sha,
        force: false
      }
    );
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const unavailableTweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const unavailable = pickUnavailableTweet(raw, ctx);
      if (unavailable) {
        unavailableTweets.push(unavailable);
        observed.push(unavailable.tweet_id);
        built.add(unavailable.tweet_id);
        continue;
      }
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, unavailable_tweets: unavailableTweets, partial_ids };
}
function pickUnavailableTweet(node, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename !== "TweetTombstone") return null;
  const tweetId = strOrNull(n.rest_id) ?? pickTweetIdFromUrls(node) ?? (ctx.sourceUrl ? tweetIdFromTweetUrl(ctx.sourceUrl) : null);
  if (!tweetId || !TWEET_ID_RE.test(tweetId)) return null;
  const unavailableText = pickTombstoneText(node);
  return {
    tweet_id: tweetId,
    account_handle: pickHandleFromTweetUrls(node, tweetId) ?? (ctx.sourceUrl ? handleFromTweetUrl(ctx.sourceUrl, tweetId) : null),
    unavailable_detected_at: ctx.capturedAt,
    unavailable_reason: classifyUnavailableReason(unavailableText),
    unavailable_text: unavailableText,
    unavailable_source_url: ctx.sourceUrl ?? null
  };
}
function pickTweetIdFromUrls(node) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const id = tweetIdFromTweetUrl(cur);
      if (id) return id;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function tweetIdFromTweetUrl(rawUrl) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/[A-Za-z0-9_]{1,15}\/status\/(\d{15,20})(?:\/|$)/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
function pickTombstoneText(node) {
  const strings = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const trimmed = cur.trim();
      if (trimmed.length >= 4 && !trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
        strings.push(trimmed);
      }
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  const preferred = strings.find(
    (s) => /\b(copyright|dmca|unavailable|withheld|removed|deleted|violat|suspended)\b/i.test(s)
  );
  return preferred ?? strings[0] ?? null;
}
function classifyUnavailableReason(text) {
  if (!text) return null;
  if (/\b(copyright|dmca)\b/i.test(text)) return "copyright";
  if (/\bwithheld\b/i.test(text)) return "withheld";
  if (/\bdeleted|removed\b/i.test(text)) return "removed";
  if (/\bsuspended\b/i.test(text)) return "suspended";
  if (/\bunavailable|not available\b/i.test(text)) return "unavailable";
  return null;
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  const hintHandle = pickHintHandle(node, restId);
  if (!hintHandle) return null;
  return { tweet_id: restId, hint_handle: hintHandle };
}
function pickHintHandle(node, tweetId) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name) ?? pickHandleFromTweetUrls(node, tweetId);
}
function pickHandleFromTweetUrls(node, tweetId) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const handle = handleFromTweetUrl(cur, tweetId);
      if (handle) return handle;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function handleFromTweetUrl(rawUrl, tweetId) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d{15,20})(?:\/|$)/);
    if (!match || match[2] !== tweetId) return null;
    return match[1] ?? null;
  } catch {
    return null;
  }
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    unavailable_detected_at: null,
    unavailable_reason: null,
    unavailable_text: null,
    unavailable_source_url: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted, coreHandles = /* @__PURE__ */ new Set()) {
  if (targeted.size === 0 && coreHandles.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (coreHandles.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
var MANUAL_CAPTURE_WINDOW_MS = 9e4;
var manualCaptureUntilMs = 0;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
function allowManualCaptureWindow() {
  manualCaptureUntilMs = Date.now() + MANUAL_CAPTURE_WINDOW_MS;
}
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  allowManualCaptureWindow();
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    ingestedNewCount: 0,
    ingestedExistingCount: 0,
    skippedOldCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let expandedCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        // Cast: the @types/firefox-webext-browser type signature insists
        // `func` returns void, but the API actually surfaces the return
        // value via `result[0].result`. We use that for the expand count.
        func: () => {
          const SHOW_MORE_SELECTORS = [
            '[data-testid="tweet-text-show-more-link"]',
            'button[data-testid="tweet-text-show-more-link"]',
            'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
          ];
          const clicked = /* @__PURE__ */ new Set();
          let expanded = 0;
          for (const sel of SHOW_MORE_SELECTORS) {
            for (const el of Array.from(document.querySelectorAll(sel))) {
              if (clicked.has(el)) continue;
              const t = (el.textContent || "").trim().toLowerCase();
              if (t !== "show more" && t !== "show this thread") continue;
              const rect = el.getBoundingClientRect();
              if (rect.width === 0 || rect.height === 0) continue;
              clicked.add(el);
              try {
                el.click();
                expanded += 1;
              } catch {
              }
            }
          }
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { expanded };
        }
      });
      scrollCount += 1;
      const r = results[0]?.result;
      if (r && typeof r.expanded === "number") expandedCount += r.expanded;
    } catch {
    }
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      sess.expandedCount += expandedCount;
      await setAutoScrollSession(sess);
    }
  }
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.pageUrl ?? null, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-update-existing":
      await updateSettings({ updateExisting: msg.on });
      await info("update-existing toggled", { on: msg.on });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, pageUrl, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const settings = await getSettings();
  if (settings.enabled === false) return;
  if (settings.autoCapture === false) {
    const explicitCaptureActive = Date.now() < manualCaptureUntilMs || await getAutoScrollSession() !== null || await getRefetchSession() !== null || await getMediaCrawlSession() !== null;
    if (!explicitCaptureActive) return;
  }
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const core = new Set(
    accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase())
  );
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set(),
      sourceUrl: pageUrl
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked, core);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.unavailable_tweets.length > 0) {
    await recordUnavailableTweets(
      normalized.unavailable_tweets,
      tracked,
      capturedAt,
      url,
      endpoint
    );
  }
  if (normalized.tweets.length === 0) return;
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const updateExisting = settings.updateExisting !== false;
  const committedIdx = await getCommittedIndex();
  const archiveSnapshot = await getArchiveSnapshot();
  let dedupedSkipped = 0;
  let skippedNoUpdateLocal = 0;
  let skippedNoUpdateSnapshot = 0;
  let oldFromSnapshot = 0;
  const liveTweets = [];
  const freshnessById = /* @__PURE__ */ new Map();
  const actionById = /* @__PURE__ */ new Map();
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const oldBySnapshot = !prev && archiveSnapshotHasTweet(t, archiveSnapshot);
    const previouslyArchived = Boolean(prev) || oldBySnapshot;
    freshnessById.set(t.tweet_id, previouslyArchived ? "existing" : "new");
    if (oldBySnapshot) oldFromSnapshot += 1;
    if (previouslyArchived && !updateExisting) {
      if (prev) skippedNoUpdateLocal += 1;
      else skippedNoUpdateSnapshot += 1;
      actionById.set(t.tweet_id, "skipped");
      continue;
    }
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      actionById.set(t.tweet_id, "unchanged");
      continue;
    }
    actionById.set(t.tweet_id, "buffered");
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (skippedNoUpdateLocal + skippedNoUpdateSnapshot > 0) {
    const skippedOld = skippedNoUpdateLocal + skippedNoUpdateSnapshot;
    await info("dedup: skipped previously archived tweets (updateExisting=false)", {
      endpoint,
      skipped: skippedOld,
      local_index: skippedNoUpdateLocal,
      archive_snapshot: skippedNoUpdateSnapshot,
      remaining: liveTweets.length
    });
    const asSess = await getAutoScrollSession();
    if (asSess !== null) {
      asSess.skippedOldCount = (asSess.skippedOldCount ?? 0) + skippedOld;
      await setAutoScrollSession(asSess);
    }
  }
  if (oldFromSnapshot > 0 && updateExisting) {
    await info("archive snapshot recognized old tweets", {
      endpoint,
      old: oldFromSnapshot,
      action: "buffering because updateExisting=true",
      snapshot_generated_at: archiveSnapshot?.generated_at ?? null
    });
  }
  await prependRecentTweetSightings(
    normalized.tweets.map(
      (t) => buildTweetSighting(t, endpoint, capturedAt, freshnessById.get(t.tweet_id), actionById.get(t.tweet_id))
    )
  );
  await enqueueMissingParents(normalized.tweets, endpoint);
  if (liveTweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    let addedNew = 0;
    let addedExisting = 0;
    let updatedBuffered = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
        updatedBuffered += 1;
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
        if (freshnessById.get(t.tweet_id) === "existing") addedExisting += 1;
        else addedNew += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(
      handle,
      Object.keys(buf.tweets_by_id).length + Object.keys(buf.unavailable_by_id ?? {}).length
    );
    if (added > 0 || updatedBuffered > 0) {
      await info("buffered tweets", {
        handle,
        endpoint,
        added,
        new: addedNew,
        existing: addedExisting,
        updated_buffered: updatedBuffered,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        asSess.ingestedNewCount = (asSess.ingestedNewCount ?? 0) + addedNew;
        asSess.ingestedExistingCount = (asSess.ingestedExistingCount ?? 0) + addedExisting;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function recordUnavailableTweets(unavailableTweets, tracked, capturedAt, sourceUrl, endpoint) {
  const committedIdx = await getCommittedIndex();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  let recorded = 0;
  let skipped = 0;
  let missingHandle = 0;
  for (const u of unavailableTweets) {
    const handle = u.account_handle;
    if (!handle) {
      missingHandle += 1;
      await dequeueMediaCrawl(u.tweet_id);
      continue;
    }
    if (tracked.size > 0 && !tracked.has(handle.toLowerCase())) {
      skipped += 1;
      continue;
    }
    await dequeueMediaCrawl(u.tweet_id);
    await dequeueRefetch(handle, u.tweet_id);
    if (refetchSess?.inflight?.tweetId === u.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === u.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    const sig = unavailableSig(u);
    const prev = committedIdx[handle]?.[u.tweet_id];
    if (prev?.sig === sig) {
      skipped += 1;
      continue;
    }
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const unavailableById = buf.unavailable_by_id ?? {};
    unavailableById[u.tweet_id] = u;
    buf.unavailable_by_id = unavailableById;
    if (!buf.tweet_ids_observed.includes(u.tweet_id)) {
      buf.tweet_ids_observed.push(u.tweet_id);
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(
      handle,
      Object.keys(buf.tweets_by_id).length + Object.keys(unavailableById).length
    );
    recorded += 1;
  }
  if (recorded > 0 || missingHandle > 0 || skipped > 0) {
    await info("unavailable tweets observed", { endpoint, recorded, skipped, missingHandle });
  }
  await broadcastState();
}
function unavailableSig(u) {
  return `unavailable|${u.unavailable_reason ?? ""}|${u.unavailable_text ?? ""}`;
}
async function enqueueMissingParents(tweets, endpoint) {
  if (tweets.length === 0) return;
  const sameBatchIds = /* @__PURE__ */ new Set();
  for (const t of tweets) sameBatchIds.add(t.tweet_id);
  let enqueued = 0;
  for (const t of tweets) {
    const parents = [];
    if (t.reply_to_tweet_id) {
      parents.push({ id: t.reply_to_tweet_id, hint: t.reply_to_account });
    }
    if (t.quoted_tweet_id) parents.push({ id: t.quoted_tweet_id, hint: null });
    if (t.retweeted_tweet_id) parents.push({ id: t.retweeted_tweet_id, hint: null });
    for (const p of parents) {
      if (sameBatchIds.has(p.id)) continue;
      if (await isCommitted(p.id)) continue;
      await enqueueMediaCrawl(p.hint, p.id);
      enqueued += 1;
    }
  }
  if (enqueued > 0) {
    await info("queued missing parent tweets for detail-page crawl", {
      endpoint,
      enqueued,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    unavailable_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    const unavailableTweets = Object.values(buf.unavailable_by_id ?? {});
    if (tweets.length === 0 && unavailableTweets.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets, unavailableTweets));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length + item.unavailableTweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length + item.unavailableTweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      for (const u of item.unavailableTweets) {
        inner[u.tweet_id] = {
          ts: nowIso,
          sig: unavailableSig(u)
        };
      }
      idx[item.handle] = inner;
      await info("flush committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        unavailable: item.unavailableTweets.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("flush batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      unavailable: items.reduce((total, item) => total + item.unavailableTweets.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets, unavailableTweets) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    unavailableTweets,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets,
      unavailable_tweets: unavailableTweets
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    const unavailableCount2 = item.unavailableTweets.length;
    const suffix2 = unavailableCount2 > 0 ? `, ${unavailableCount2} unavailable` : "";
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"}${suffix2} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  const unavailableCount = items.reduce((total, item) => total + item.unavailableTweets.length, 0);
  const suffix = unavailableCount > 0 ? `, ${unavailableCount} unavailable` : "";
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"}${suffix} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return Object.keys(current.tweets_by_id).length;
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  for (const u of item.unavailableTweets) {
    committed.set(u.tweet_id, unavailableSig(u));
  }
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingUnavailable = {};
  for (const [tweetId, unavailable] of Object.entries(current.unavailable_by_id ?? {})) {
    const committedSig = committed.get(tweetId);
    const currentSig = unavailableSig(unavailable);
    if (!committedSig || committedSig !== currentSig) {
      remainingUnavailable[tweetId] = { ...unavailable };
    }
  }
  const remainingIds = /* @__PURE__ */ new Set([
    ...Object.keys(remainingTweets),
    ...Object.keys(remainingUnavailable)
  ]);
  const remainingCount = remainingIds.size;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    unavailable_by_id: remainingUnavailable,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => remainingIds.has(id))
  });
  await info("flush kept newer buffered tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  allowManualCaptureWindow();
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      unavailable_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  allowManualCaptureWindow();
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  allowManualCaptureWindow();
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  allowManualCaptureWindow();
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = target.bucket === "_unknown" ? `https://x.com/i/web/status/${target.tweetId}` : `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    const checkWrite = force || isWriteAuthError(conn.error);
    if (branchOk && checkWrite) {
      await client.verifyWriteAccess();
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk,
      write_access: checkWrite ? "checked" : "not_checked"
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await refreshArchiveSnapshot(client, force);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function refreshArchiveSnapshot(client, force) {
  const text = await client.fetchRawText("data/manifest.json");
  if (!text) {
    await setArchiveSnapshot(null);
    if (force) await warn("archive manifest not found; old-tweet detection disabled");
    return;
  }
  try {
    const snapshot = parseArchiveSnapshot(JSON.parse(text));
    await setArchiveSnapshot(snapshot);
    if (force) {
      await info("archive snapshot refreshed", {
        accounts: Object.keys(snapshot.accounts).length,
        generated_at: snapshot.generated_at
      });
    }
  } catch (err) {
    await warn("archive snapshot parse failed; old-tweet detection disabled", describeError(err));
  }
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const autoScrollSess = await getAutoScrollSession();
  const recentTweetSightings = await getRecentTweetSightings();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      ingestedNewCount: autoScrollSess?.ingestedNewCount ?? 0,
      ingestedExistingCount: autoScrollSess?.ingestedExistingCount ?? 0,
      skippedOldCount: autoScrollSess?.skippedOldCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    },
    recentTweetSightings
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    updateExisting: s.updateExisting,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function parseArchiveSnapshot(raw) {
  if (!raw || typeof raw !== "object") throw new Error("manifest is not an object");
  const manifest = raw;
  if (!Array.isArray(manifest.accounts)) throw new Error("manifest.accounts is not an array");
  const accounts = {};
  for (const entry of manifest.accounts) {
    if (!entry || typeof entry !== "object") continue;
    const row = entry;
    const handle = typeof row.handle === "string" ? row.handle : "";
    if (!handle || handle === "_misc") continue;
    accounts[handle.toLowerCase()] = {
      handle,
      latest_post_at: typeof row.latest_post_at === "string" ? row.latest_post_at : null,
      latest_capture_at: typeof row.latest_capture_at === "string" ? row.latest_capture_at : null,
      row_count: typeof row.row_count === "number" ? row.row_count : null
    };
  }
  return {
    generated_at: typeof manifest.generated_at === "string" ? manifest.generated_at : null,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    accounts
  };
}
function archiveSnapshotHasTweet(t, snapshot) {
  if (!snapshot) return false;
  const entry = snapshot.accounts[t.account_handle.toLowerCase()];
  if (!entry?.latest_post_at) return false;
  const posted = Date.parse(t.posted_at);
  const latest = Date.parse(entry.latest_post_at);
  return Number.isFinite(posted) && Number.isFinite(latest) && posted <= latest;
}
function buildTweetSighting(t, endpoint, seenAt, freshness = "new", action = "buffered") {
  return {
    tweet_id: t.tweet_id,
    account_handle: t.account_handle,
    posted_at: t.posted_at,
    text: t.text_resolved || t.text,
    tweet_type: t.tweet_type,
    tweet_url: t.tweet_url,
    seen_at: seenAt,
    endpoint,
    archive_status: freshness === "existing" ? "saved" : "new",
    action
  };
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHBhdDogJycsXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXG4gIHJlcG86ICd4JyxcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxuICBicmFuY2g6ICdtYXN0ZXInLFxuICBlbmFibGVkOiB0cnVlLFxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcbiAgY29uZmlndXJlZEF0OiBudWxsLFxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXG4gIHVwZGF0ZUV4aXN0aW5nOiB0cnVlLFxufTtcblxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01JTl9TRUMgPSAzO1xuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01BWF9TRUMgPSA2MDtcblxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcbi8vIHJlcG8gaGFzIGJlZW4gaW5pdGlhbGl6ZWQgb3IgUEFUIG1pc2NvbmZpZ3VyZWQpLiBLZXB0IGluIHN5bmMgd2l0aCB0aGUgZmlsZS5cbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdJQ0Vnb3YnLCBsYWJlbDogJ1UuUy4gSW1taWdyYXRpb24gYW5kIEN1c3RvbXMgRW5mb3JjZW1lbnQnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdXaGl0ZUhvdXNlJywgbGFiZWw6ICdUaGUgV2hpdGUgSG91c2UnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1VTRE9MJywgbGFiZWw6ICdVLlMuIERlcGFydG1lbnQgb2YgTGFib3InLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycsIGNhdGVnb3J5OiAnY29yZScgfSxcbl07XG5cbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXG5leHBvcnQgY29uc3QgVFdFRVRfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbiAgJ0xpa2VzJyxcbiAgJ0Jvb2ttYXJrcycsXG4gICdIb21lVGltZWxpbmUnLFxuICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcbiAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXG5dKTtcblxuLy8gRW5kcG9pbnRzIHRoYXQgY2FycnkgQ29tbXVuaXR5IE5vdGUgYm9kaWVzIFx1MjAxNCBjYXB0dXJlZCBmb3IgY29tcGxldGVuZXNzIGJ1dFxuLy8gdGhleSBkb24ndCBpbnRyb2R1Y2UgbmV3IHR3ZWV0cywgc28gdGhleSBkb24ndCBuZWVkIHRvIGJlIGluIFRXRUVUX0VORFBPSU5UUy5cbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdCaXJkd2F0Y2hGZXRjaE9uZU5vdGUnLFxuICAnQmlyZHdhdGNoRmV0Y2hOb3RlcycsXG5dKTtcblxuLy8gQXV4aWxpYXJ5IGVuZHBvaW50cyB3ZSBkb24ndCBleHRyYWN0IHR3ZWV0cyBmcm9tIGJ1dCB1c2UgZm9yIGNvbnRleHQgKGUuZy4sXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxuZXhwb3J0IGNvbnN0IFBST0ZJTEVfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJCeVNjcmVlbk5hbWUnLCAnVXNlckJ5UmVzdElkJ10pO1xuXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3Jcbi8vIGNvbnZlcnNhdGlvbiBcdTIwMTQgaS5lLiB2aXNpdGluZyBgLzxoYW5kbGU+YCAvIGAvPGhhbmRsZT4vd2l0aF9yZXBsaWVzYCxcbi8vIGxvb2tpbmcgYXQgb25lIHR3ZWV0LCBldGMuIEV2ZXJ5IHR3ZWV0IHJldHVybmVkIGJ5IHRoZXNlIGVuZHBvaW50cyBpc1xuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXG4vLyAocmV0d2VldGVkLCBxdW90ZWQsIHJlcGxpZWQgdG8pLCBzbyB3ZSBrZWVwIGV2ZXJ5dGhpbmcgd2Ugc2VlIHJhdGhlclxuLy8gdGhhbiBkcm9wcGluZyBub24tdHJhY2tlZCBhdXRob3JzLiBUaGF0IHdheSBhIHJldHdlZXQgb2YgYSBub24tdHJhY2tlZFxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxuLy9cbi8vIEVuZHBvaW50cyBOT1QgaW4gdGhpcyBzZXQgKEhvbWVUaW1lbGluZSwgU2VhcmNoVGltZWxpbmUsIExpa2VzLCBldGMuKVxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXG4vLyBcIkJyb3dzaW5nIG15IGhvbWUgdGltZWxpbmUgaXMgaWdub3JlZFwiIHJ1bGUuXG5leHBvcnQgY29uc3QgVVNFUl9QQUdFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG5dKTtcblxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xuXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcblxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XG5cbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcblxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XG5cbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xuIiwgIi8qKlxuICogY3J5cHRvLnRzIFx1MjAxNCBhdC1yZXN0IGVuY3J5cHRpb24gZm9yIHNlbnNpdGl2ZSBzZXR0aW5ncyAodGhlIFBBVCkuXG4gKlxuICogVGhyZWF0IG1vZGVsOiBhbiBhdHRhY2tlciB3aG8gcmVhZHMgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgKGRldnRvb2xzLCBhXG4gKiBmb3Jnb3R0ZW4gYmFja3VwLCBhIG1pc2NvbmZpZ3VyZWQgcHJvZmlsZSBzeW5jKSBzaG91bGQgbm90IHNlZSBhIHVzYWJsZVxuICogR2l0SHViIFBBVCBpbiBwbGFpbnRleHQuIEEgZGV0ZXJtaW5lZCBhdHRhY2tlciB3aXRoIHRoZSBleHRlbnNpb24ncyBzb3VyY2VcbiAqIGNhbiBzdGlsbCBkZXJpdmUgdGhlIGtleSBcdTIwMTQgd2UgbWFrZSBubyBjbGFpbSBvZiBcInJlYWxcIiBjcnlwdG9ncmFwaGljXG4gKiBjb25maWRlbnRpYWxpdHkuIFRoZSBhaW0gaXMgdG8gcmFpc2UgdGhlIGJhciBzbyB0aGUgUEFUIGlzbid0IGEgY29weWFibGVcbiAqIHN0cmluZyBzaXR0aW5nIG5leHQgdG8gaXRzIGtleSBuYW1lIGluIGV4dGVuc2lvbiBzdG9yYWdlLlxuICpcbiAqIFNjaGVtZTpcbiAqICAgLSBPbiBmaXJzdCBlbmNyeXB0aW9uIHdlIGdlbmVyYXRlIGEgMzItYnl0ZSBzYWx0IGFuZCBwZXJzaXN0IGl0IGluXG4gKiAgICAgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgdW5kZXIgYF9faW1tX2FyY2hpdmVfc2FsdF9fYC5cbiAqICAgLSBXZSBkZXJpdmUgYW4gQUVTLUdDTSBrZXkgYnkgU0hBLTI1NidpbmcgYHNhbHQgfHwgcnVudGltZS5pZCB8fCB2ZXJzaW9uXG4gKiAgICAgfHwgXCJpbW0tYXJjaGl2ZS1wYXQtdjFcImAuIFRoZSBzYWx0IGJlaW5nIHBlci1pbnN0YWxsIG1lYW5zIHR3byBjb3BpZXNcbiAqICAgICBvZiB0aGUgZXh0ZW5zaW9uIGRvbid0IHNoYXJlIGEga2V5LiBUaGUgcnVudGltZS5pZCBpcyB0aGUgZXh0ZW5zaW9uJ3NcbiAqICAgICBVVUlEIFx1MjAxNCBzdGFibGUgZm9yIGEgZ2l2ZW4gaW5zdGFsbCBidXQgdW5rbm93biB0byBhIHJlbW90ZSBhdHRhY2tlci5cbiAqICAgLSBQbGFpbnRleHQgaXMgZW5jcnlwdGVkIHdpdGggYSBmcmVzaCAxMi1ieXRlIElWLiBUaGUgZW52ZWxvcGUgZm9ybWF0IGlzXG4gKiAgICAgYHYxOjxpdi1iNjQ+OjxjaXBoZXJ0ZXh0LWI2ND5gIGFuZCBpcyB3aGF0IGdldHMgc3RvcmVkLlxuICpcbiAqIEJhY2t3YXJkcyBjb21wYXRpYmlsaXR5OiBhbiB1bnByZWZpeGVkIHZhbHVlIGlzIHRyZWF0ZWQgYXMgbGVnYWN5XG4gKiBwbGFpbnRleHQsIGRlY3J5cHRlZCB0byBpdHNlbGYsIGFuZCByZS1lbmNyeXB0ZWQgb24gdGhlIG5leHQgd3JpdGUuXG4gKi9cblxuY29uc3QgU0FMVF9TVE9SQUdFX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3NhbHRfXyc7XG5jb25zdCBFTlZFTE9QRV9QUkVGSVggPSAndjE6JztcblxubGV0IGRlcml2ZWRLZXlDYWNoZTogQ3J5cHRvS2V5IHwgbnVsbCA9IG51bGw7XG5sZXQgZGVyaXZlZEtleUNhY2hlU2FsdDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIHRvQmFzZTY0KGJ1ZjogVWludDhBcnJheSk6IHN0cmluZyB7XG4gIGxldCBzID0gJyc7XG4gIGZvciAoY29uc3QgYiBvZiBidWYpIHMgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShiKTtcbiAgcmV0dXJuIGJ0b2Eocyk7XG59XG5cbmZ1bmN0aW9uIGZyb21CYXNlNjQoczogc3RyaW5nKTogVWludDhBcnJheSB7XG4gIGNvbnN0IGJpbiA9IGF0b2Iocyk7XG4gIGNvbnN0IG91dCA9IG5ldyBVaW50OEFycmF5KGJpbi5sZW5ndGgpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGJpbi5sZW5ndGg7IGkrKykgb3V0W2ldID0gYmluLmNoYXJDb2RlQXQoaSk7XG4gIHJldHVybiBvdXQ7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWRPckNyZWF0ZVNhbHQoKTogUHJvbWlzZTx7IHNhbHRCNjQ6IHN0cmluZzsgc2FsdDogVWludDhBcnJheSB9PiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoU0FMVF9TVE9SQUdFX0tFWSk7XG4gIGNvbnN0IHYgPSBzdG9yZWRbU0FMVF9TVE9SQUdFX0tFWV07XG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwKSB7XG4gICAgcmV0dXJuIHsgc2FsdEI2NDogdiwgc2FsdDogZnJvbUJhc2U2NCh2KSB9O1xuICB9XG4gIGNvbnN0IHNhbHQgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDMyKSk7XG4gIGNvbnN0IHNhbHRCNjQgPSB0b0Jhc2U2NChzYWx0KTtcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtTQUxUX1NUT1JBR0VfS0VZXTogc2FsdEI2NCB9KTtcbiAgcmV0dXJuIHsgc2FsdEI2NCwgc2FsdCB9O1xufVxuXG5hc3luYyBmdW5jdGlvbiBkZXJpdmVLZXkoKTogUHJvbWlzZTxDcnlwdG9LZXk+IHtcbiAgY29uc3QgeyBzYWx0QjY0LCBzYWx0IH0gPSBhd2FpdCBsb2FkT3JDcmVhdGVTYWx0KCk7XG4gIGlmIChkZXJpdmVkS2V5Q2FjaGUgIT09IG51bGwgJiYgZGVyaXZlZEtleUNhY2hlU2FsdCA9PT0gc2FsdEI2NCkge1xuICAgIHJldHVybiBkZXJpdmVkS2V5Q2FjaGU7XG4gIH1cbiAgY29uc3Qgc2VlZCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcbiAgICBgJHticm93c2VyLnJ1bnRpbWUuaWR9fCR7YnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbn18aW1tLWFyY2hpdmUtcGF0LXYxYFxuICApO1xuICBjb25zdCBjb21iaW5lZCA9IG5ldyBVaW50OEFycmF5KHNlZWQubGVuZ3RoICsgc2FsdC5sZW5ndGgpO1xuICBjb21iaW5lZC5zZXQoc2VlZCwgMCk7XG4gIGNvbWJpbmVkLnNldChzYWx0LCBzZWVkLmxlbmd0aCk7XG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGNvbWJpbmVkKTtcbiAgY29uc3Qga2V5ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoJ3JhdycsIGhhc2gsIHsgbmFtZTogJ0FFUy1HQ00nIH0sIGZhbHNlLCBbXG4gICAgJ2VuY3J5cHQnLFxuICAgICdkZWNyeXB0JyxcbiAgXSk7XG4gIGRlcml2ZWRLZXlDYWNoZSA9IGtleTtcbiAgZGVyaXZlZEtleUNhY2hlU2FsdCA9IHNhbHRCNjQ7XG4gIHJldHVybiBrZXk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0VuY3J5cHRlZFBhdCh2OiBzdHJpbmcpOiBib29sZWFuIHtcbiAgcmV0dXJuIHYuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5jcnlwdFBhdChwbGFpbnRleHQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGlmICghcGxhaW50ZXh0KSByZXR1cm4gJyc7XG4gIGNvbnN0IGtleSA9IGF3YWl0IGRlcml2ZUtleSgpO1xuICBjb25zdCBpdiA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTIpKTtcbiAgY29uc3QgY3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmVuY3J5cHQoXG4gICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2IH0sXG4gICAga2V5LFxuICAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShwbGFpbnRleHQpXG4gICk7XG4gIHJldHVybiBgJHtFTlZFTE9QRV9QUkVGSVh9JHt0b0Jhc2U2NChpdil9OiR7dG9CYXNlNjQobmV3IFVpbnQ4QXJyYXkoY3QpKX1gO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVjcnlwdFBhdChlbnZlbG9wZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgaWYgKCFlbnZlbG9wZSkgcmV0dXJuICcnO1xuICAvLyBMZWdhY3kgcGxhaW50ZXh0IChwcmUtZW5jcnlwdGlvbiBpbnN0YWxscyk6IHBhc3MgdGhyb3VnaC4gVGhlIG5leHQgc2F2ZVxuICAvLyByZS1lbmNyeXB0cyBpdCB2aWEgdGhlIHN0b3JhZ2UgbGF5ZXIuXG4gIGlmICghZW52ZWxvcGUuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpKSByZXR1cm4gZW52ZWxvcGU7XG4gIGNvbnN0IHBhcnRzID0gZW52ZWxvcGUuc2xpY2UoRU5WRUxPUEVfUFJFRklYLmxlbmd0aCkuc3BsaXQoJzonKTtcbiAgaWYgKHBhcnRzLmxlbmd0aCAhPT0gMikgcmV0dXJuICcnO1xuICBjb25zdCBbaXZCNjQsIGN0QjY0XSA9IHBhcnRzO1xuICBpZiAoIWl2QjY0IHx8ICFjdEI2NCkgcmV0dXJuICcnO1xuICB0cnkge1xuICAgIGNvbnN0IGtleSA9IGF3YWl0IGRlcml2ZUtleSgpO1xuICAgIGNvbnN0IGl2ID0gZnJvbUJhc2U2NChpdkI2NCk7XG4gICAgY29uc3QgY3QgPSBmcm9tQmFzZTY0KGN0QjY0KTtcbiAgICBjb25zdCBwdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGVjcnlwdChcbiAgICAgIHsgbmFtZTogJ0FFUy1HQ00nLCBpdjogaXYgYXMgQnVmZmVyU291cmNlIH0sXG4gICAgICBrZXksXG4gICAgICBjdCBhcyBCdWZmZXJTb3VyY2VcbiAgICApO1xuICAgIHJldHVybiBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUocHQpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gJyc7XG4gIH1cbn1cbiIsICJpbXBvcnQgeyBERUZBVUxUX1NFVFRJTkdTLCBGQUxMQkFDS19BQ0NPVU5UUywgQUNUSVZJVFlfVEFJTF9NQVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XG5pbXBvcnQgeyBkZWNyeXB0UGF0LCBlbmNyeXB0UGF0LCBpc0VuY3J5cHRlZFBhdCB9IGZyb20gJy4vY3J5cHRvLmpzJztcbmltcG9ydCB0eXBlIHtcbiAgQWNjb3VudENvbmZpZyxcbiAgQWNjb3VudENvdW50ZXIsXG4gIEFyY2hpdmVTbmFwc2hvdCxcbiAgQ2Fub25pY2FsVHdlZXQsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFNldHRpbmdzLFxuICBUd2VldFNpZ2h0aW5nLFxuICBVbmF2YWlsYWJsZVR3ZWV0LFxufSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBCdWZmZXJlZCB0d2VldHMgZm9yIGEgZ2l2ZW4gYWNjb3VudCwgYXdhaXRpbmcgY29tbWl0LiBBIFwicnVuXCIgaXMgb25lIGVudHJ5XG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xuICBydW5faWQ6IHN0cmluZztcbiAgYWNjb3VudF9oYW5kbGU6IHN0cmluZztcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcbiAgdHdlZXRzX2J5X2lkOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD47XG4gIHVuYXZhaWxhYmxlX2J5X2lkPzogUmVjb3JkPHN0cmluZywgVW5hdmFpbGFibGVUd2VldD47XG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XG4gIGVuZHBvaW50c19zZWVuOiBzdHJpbmdbXTtcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcbn1cblxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxuICogVXNlZCB0byBza2lwIHJlLWNhcHR1cmluZyB0d2VldHMgd2UndmUgYWxyZWFkeSBwdXNoZWQgd2l0aCBpZGVudGljYWxcbiAqIGVuZ2FnZW1lbnQgY291bnRzIFx1MjAxNCBhdm9pZHMgZ2VuZXJhdGluZyBvbmUgbmV3IHJhdy8qIGZpbGUgZXZlcnkgYnJvd3NlLiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XG4gIHRzOiBzdHJpbmc7IC8vIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3QgY29tbWl0XG4gIHNpZzogc3RyaW5nOyAvLyBlbmdhZ2VtZW50IHNpZ25hdHVyZTogXCJsaWtlfHJ0fHJlcGx5fHF1b3RlXCJcbn1cblxuLyoqIFByb2dyZXNzICsgaW5mbGlnaHQgdHJhY2tpbmcgZm9yIGEgcXVldWUtZHJpdmVuIGxvb3AgKHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCkuXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcbiAqIFwiWCBvZiBZIHByb2Nlc3NlZFwiIFx1MjAxNCBhbmQgdGhlIHdhaXQtZm9yLWluZ2VzdCBndWFyZCBrbm93cyB3aGF0IHRvIGV4cGVjdC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XG4gIC8qKiBJbml0aWFsIHF1ZXVlIHNpemUgd2hlbiB0aGUgdXNlciBjbGlja2VkIFwiU3RhcnRcIi4gKi9cbiAgdG90YWxBdFN0YXJ0OiBudW1iZXI7XG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cbiAgcHJvY2Vzc2VkOiBudW1iZXI7XG4gIC8qKiBJU08gb2Ygd2hlbiB0aGlzIHNlc3Npb24gc3RhcnRlZC4gKi9cbiAgc3RhcnRlZEF0OiBzdHJpbmc7XG4gIC8qKiBUd2VldCBjdXJyZW50bHkgaW5mbGlnaHQgXHUyMDE0IHdlIG5hdmlnYXRlZCB0byBpdCBhbmQgYXJlIHdhaXRpbmcgZm9yIHRoZVxuICAgKiBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgcmVzcG9uc2UgYmVmb3JlIGFkdmFuY2luZy4gbnVsbCBiZXR3ZWVuIHRpY2tzXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xuICBpbmZsaWdodDogeyB0d2VldElkOiBzdHJpbmc7IG5hdmlnYXRlZEF0OiBzdHJpbmcgfSB8IG51bGw7XG59XG5cbi8qKiBBdXRvLXNjcm9sbCBzZXNzaW9uOiBjb3VudHMgb2YgdGlja3MgYW5kIHR3ZWV0cyBpbmdlc3RlZCBzaW5jZSB0aGUgdXNlclxuICogY2xpY2tlZCBTdGFydC4gUGVyc2lzdGVkIHNvIFNXIGV2aWN0aW9uIGR1cmluZyBhIHJ1biBrZWVwcyBwcm9ncmVzcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xuICBzdGFydGVkQXQ6IHN0cmluZztcbiAgc2Nyb2xsQ291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xuICBpbmdlc3RlZE5ld0NvdW50OiBudW1iZXI7XG4gIGluZ2VzdGVkRXhpc3RpbmdDb3VudDogbnVtYmVyO1xuICBza2lwcGVkT2xkQ291bnQ6IG51bWJlcjtcbiAgZXhwYW5kZWRDb3VudDogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgU3RvcmFnZVNoYXBlIHtcbiAgc2V0dGluZ3M6IFNldHRpbmdzO1xuICBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdO1xuICAvKiogSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBzdWNjZXNzZnVsIGFjY291bnRzLnlhbWwgZmV0Y2ggZnJvbSB0aGUgcmVwby5cbiAgICogVXNlZCBieSBgcmVmcmVzaEFjY291bnRzTGlzdGAgdG8gc2tpcCByZS1mZXRjaGluZyBvbiBldmVyeSBTVyB3YWtlIFx1MjAxNCB0aGVcbiAgICogZmlsZSBjaGFuZ2VzIHJhcmVseSBhbmQgYW4gYXV0aGVudGljYXRlZCByYXcgZmV0Y2ggZXZlcnkgd2FrZSBhZGRzIHVwLiAqL1xuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBzdHJpbmcgfCBudWxsO1xuICBhcmNoaXZlU25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGw7XG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcbiAgcnVuQnVmZmVyczogUmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPjtcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XG4gIHJlY2VudFR3ZWV0U2lnaHRpbmdzOiBUd2VldFNpZ2h0aW5nW107XG4gIGNvbW1pdHRlZEluZGV4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+O1xuICAvKiogVHdlZXRzIHRoZSBub3JtYWxpemVyIGZsYWdnZWQgYXMgdHJ1bmNhdGVkIGFuZCB0aGF0IHdlIGhhdmVuJ3Qgc2VlbiBhXG4gICAqIGZ1bGwtdGV4dCB2ZXJzaW9uIG9mIHlldC4gS2V5ZWQgYnkgaGFuZGxlIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuICovXG4gIHJlZmV0Y2hRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogVHdlZXQgSURzIHNlZW4gdmlhIE1lZGlhLXRhYiAvIHBhcnRpYWwgY2FwdHVyZXMgdGhhdCBjb3VsZG4ndCBiZVxuICAgKiBub3JtYWxpemVkIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gS2V5ZWQgYnkgaGludC1oYW5kbGUgKG9yXG4gICAqIFwiX3Vua25vd25cIikgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gVGhlIHVzZXIgY2FuIGRyaXZlIGEgY3Jhd2wgdGhhdFxuICAgKiBvcGVucyBlYWNoIGRldGFpbCBwYWdlIHRvIGNhcHR1cmUgdGhlIHJlYWwgdGhpbmcuICovXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBtZWRpYUNyYXdsU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBhdXRvU2Nyb2xsU2Vzc2lvbjogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsO1xufVxuXG5jb25zdCBERUZBVUxUX0NPTk5FQ1RJT046IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgc3RhdHVzOiAndW5rbm93bicsXG4gIGxvZ2luOiBudWxsLFxuICBjaGVja2VkQXQ6IG51bGwsXG4gIGVycm9yOiBudWxsLFxuICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxufTtcblxuY29uc3QgREVGQVVMVFM6IFN0b3JhZ2VTaGFwZSA9IHtcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9LFxuICBhY2NvdW50czogWy4uLkZBTExCQUNLX0FDQ09VTlRTXSxcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogbnVsbCxcbiAgYXJjaGl2ZVNuYXBzaG90OiBudWxsLFxuICBjb25uZWN0aW9uOiB7IC4uLkRFRkFVTFRfQ09OTkVDVElPTiB9LFxuICBjb3VudGVyczoge30sXG4gIHJ1bkJ1ZmZlcnM6IHt9LFxuICBhY3Rpdml0eTogW10sXG4gIHJlY2VudFR3ZWV0U2lnaHRpbmdzOiBbXSxcbiAgY29tbWl0dGVkSW5kZXg6IHt9LFxuICByZWZldGNoUXVldWU6IHt9LFxuICBtZWRpYUNyYXdsUXVldWU6IHt9LFxuICByZWZldGNoU2Vzc2lvbjogbnVsbCxcbiAgbWVkaWFDcmF3bFNlc3Npb246IG51bGwsXG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBudWxsLFxufTtcblxuYXN5bmMgZnVuY3Rpb24gZ2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSyk6IFByb21pc2U8U3RvcmFnZVNoYXBlW0tdPiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoa2V5KTtcbiAgY29uc3QgdmFsdWUgPSByZXN1bHRba2V5XTtcbiAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gc3RydWN0dXJlZENsb25lKERFRkFVTFRTW2tleV0pO1xuICB9XG4gIHJldHVybiB2YWx1ZSBhcyBTdG9yYWdlU2hhcGVbS107XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEssIHZhbHVlOiBTdG9yYWdlU2hhcGVbS10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtrZXldOiB2YWx1ZSB9KTtcbn1cblxuLy8gLS0tIFNldHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNldHRpbmdzKCk6IFByb21pc2U8U2V0dGluZ3M+IHtcbiAgLy8gQmFja2ZpbGwgYW55IGtleXMgdGhlIHVzZXIncyBzdG9yZWQgc2V0dGluZ3MgcHJlZGF0ZSBcdTIwMTQgcmVhZGVycyBjYW4gcmVseVxuICAvLyBvbiBldmVyeSBTZXR0aW5ncyBmaWVsZCBiZWluZyBwcmVzZW50IHJhdGhlciB0aGFuIGA/PyBkZWZhdWx0aW5nYCBhdFxuICAvLyBldmVyeSBjYWxsc2l0ZS4gVGhlIFBBVCBpcyBzdG9yZWQgZW5jcnlwdGVkLWF0LXJlc3QgYXMgb2YgdjAuMi4wOyB3ZVxuICAvLyBkZWNyeXB0IHRyYW5zcGFyZW50bHkgc28gY2FsbGVycyBjb250aW51ZSB0byBzZWUgcGxhaW50ZXh0LlxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBnZXRSYXcoJ3NldHRpbmdzJyk7XG4gIGNvbnN0IG1lcmdlZCA9IHsgLi4uREVGQVVMVF9TRVRUSU5HUywgLi4uc3RvcmVkIH07XG4gIGlmIChtZXJnZWQucGF0ICYmIGlzRW5jcnlwdGVkUGF0KG1lcmdlZC5wYXQpKSB7XG4gICAgdHJ5IHtcbiAgICAgIG1lcmdlZC5wYXQgPSBhd2FpdCBkZWNyeXB0UGF0KG1lcmdlZC5wYXQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgbWVyZ2VkLnBhdCA9ICcnO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbWVyZ2VkO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIEVuY3J5cHQgdGhlIFBBVCBiZWZvcmUgcGVyc2lzdGluZzsgbGVnYWN5IHBsYWludGV4dCBQQVRzIGdldCB1cGdyYWRlZFxuICAvLyBvbiB0aGUgbmV4dCBzYXZlLlxuICBjb25zdCB0b1dyaXRlOiBTZXR0aW5ncyA9IHsgLi4ucyB9O1xuICBpZiAodG9Xcml0ZS5wYXQgJiYgIWlzRW5jcnlwdGVkUGF0KHRvV3JpdGUucGF0KSkge1xuICAgIHRvV3JpdGUucGF0ID0gYXdhaXQgZW5jcnlwdFBhdCh0b1dyaXRlLnBhdCk7XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdzZXR0aW5ncycsIHRvV3JpdGUpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHBhdGNoOiBQYXJ0aWFsPFNldHRpbmdzPik6IFByb21pc2U8U2V0dGluZ3M+IHtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgbmV4dCA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xuICBhd2FpdCBzZXRTZXR0aW5ncyhuZXh0KTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbi8vIC0tLSBBY2NvdW50cyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50cygpOiBQcm9taXNlPEFjY291bnRDb25maWdbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50cycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzKGE6IEFjY291bnRDb25maWdbXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzJywgYSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzUmVmcmVzaGVkQXQoaXNvOiBzdHJpbmcgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcsIGlzbyk7XG59XG5cbi8vIC0tLSBBcmNoaXZlIHNuYXBzaG90IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFyY2hpdmVTbmFwc2hvdCgpOiBQcm9taXNlPEFyY2hpdmVTbmFwc2hvdCB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYXJjaGl2ZVNuYXBzaG90Jyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBcmNoaXZlU25hcHNob3Qoc25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhcmNoaXZlU25hcHNob3QnLCBzbmFwc2hvdCk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHN0YXRlIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb24oKTogUHJvbWlzZTxDb25uZWN0aW9uU3RhdGU+IHtcbiAgY29uc3QgYyA9IGF3YWl0IGdldFJhdygnY29ubmVjdGlvbicpO1xuICAvLyBCYWNrZmlsbCBmaWVsZHMgYWRkZWQgYWZ0ZXIgdGhlIHVzZXIncyBzdG9yYWdlIHdhcyB3cml0dGVuLlxuICBjb25zdCBvdXQ6IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgICAuLi5jLFxuICAgIGRlZmF1bHRCcmFuY2g6IGMuZGVmYXVsdEJyYW5jaCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuZGVmYXVsdEJyYW5jaCxcbiAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOlxuICAgICAgYy5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxuICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGMucmF0ZUxpbWl0UmVzZXRBdCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMucmF0ZUxpbWl0UmVzZXRBdCxcbiAgfTtcbiAgcmV0dXJuIG91dDtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb25uZWN0aW9uKGM6IENvbm5lY3Rpb25TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2Nvbm5lY3Rpb24nLCBjKTtcbn1cblxuLy8gLS0tIENvdW50ZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZnVuY3Rpb24gdG9kYXlJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3VudGVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb3VudGVycycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGJ1bXBDb3VudGVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgcGF0Y2g6IFBhcnRpYWw8QWNjb3VudENvdW50ZXI+XG4pOiBQcm9taXNlPEFjY291bnRDb3VudGVyPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGNvbnN0IGN1ciA9IGFsbFtoYW5kbGVdID8/IHtcbiAgICB0b2RheUNvdW50OiAwLFxuICAgIHRvZGF5RGF0ZTogdG9kYXlJU08oKSxcbiAgICBsYXN0Q2FwdHVyZUF0OiBudWxsLFxuICAgIHRvdGFsQ29tbWl0dGVkOiAwLFxuICAgIGJ1ZmZlcmVkQ291bnQ6IDAsXG4gIH07XG4gIGlmIChjdXIudG9kYXlEYXRlICE9PSB0b2RheUlTTygpKSB7XG4gICAgY3VyLnRvZGF5RGF0ZSA9IHRvZGF5SVNPKCk7XG4gICAgY3VyLnRvZGF5Q291bnQgPSAwO1xuICB9XG4gIGNvbnN0IG5leHQ6IEFjY291bnRDb3VudGVyID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGFsbFtoYW5kbGVdID0gbmV4dDtcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGFsbCk7XG4gIHJldHVybiBuZXh0O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QnVmZmVyZWRDb3VudChoYW5kbGU6IHN0cmluZywgY291bnQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHsgYnVmZmVyZWRDb3VudDogY291bnQgfSk7XG59XG5cbi8vIC0tLSBSdW4gYnVmZmVycyAodGhlIHBlbmRpbmcgY2FwdHVyZXMgYXdhaXRpbmcgY29tbWl0KSAtLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3J1bkJ1ZmZlcnMnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8UnVuQnVmZmVyIHwgbnVsbD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIHJldHVybiBhbGxbaGFuZGxlXSA/PyBudWxsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nLCBidWY6IFJ1bkJ1ZmZlcik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGFsbFtoYW5kbGVdID0gYnVmO1xuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBkZWxldGUgYWxsW2hhbmRsZV07XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbi8vIC0tLSBBY3Rpdml0eSB0YWlsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY3Rpdml0eSgpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcbiAgcmV0dXJuIGdldFJhdygnYWN0aXZpdHknKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGVuZEFjdGl2aXR5KGV2OiBMb2dFdmVudCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRBY3Rpdml0eSgpO1xuICBjdXIudW5zaGlmdChldik7XG4gIGlmIChjdXIubGVuZ3RoID4gQUNUSVZJVFlfVEFJTF9NQVgpIGN1ci5sZW5ndGggPSBBQ1RJVklUWV9UQUlMX01BWDtcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIGN1cik7XG4gIHJldHVybiBjdXI7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgW10pO1xufVxuXG4vLyAtLS0gUmVjZW50IHR3ZWV0IHNpZ2h0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuY29uc3QgUkVDRU5UX1RXRUVUX1NJR0hUSU5HU19NQVggPSA4MDtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk6IFByb21pc2U8VHdlZXRTaWdodGluZ1tdPiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlY2VudFR3ZWV0U2lnaHRpbmdzJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVwZW5kUmVjZW50VHdlZXRTaWdodGluZ3Mocm93czogVHdlZXRTaWdodGluZ1tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncygpO1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IG5leHQ6IFR3ZWV0U2lnaHRpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHJvdyBvZiByb3dzKSB7XG4gICAgY29uc3Qga2V5ID0gYCR7cm93LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCl9OiR7cm93LnR3ZWV0X2lkfWA7XG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGtleSk7XG4gICAgbmV4dC5wdXNoKHJvdyk7XG4gIH1cbiAgZm9yIChjb25zdCByb3cgb2YgY3VyKSB7XG4gICAgY29uc3Qga2V5ID0gYCR7cm93LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCl9OiR7cm93LnR3ZWV0X2lkfWA7XG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGtleSk7XG4gICAgbmV4dC5wdXNoKHJvdyk7XG4gIH1cbiAgbmV4dC5sZW5ndGggPSBNYXRoLm1pbihuZXh0Lmxlbmd0aCwgUkVDRU5UX1RXRUVUX1NJR0hUSU5HU19NQVgpO1xuICBhd2FpdCBzZXRSYXcoJ3JlY2VudFR3ZWV0U2lnaHRpbmdzJywgbmV4dCk7XG59XG5cbi8vIC0tLSBDb21taXR0ZWQtdHdlZXRzIGRlZHVwIGluZGV4IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb21taXR0ZWRJbmRleCcpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29tbWl0dGVkSW5kZXgoXG4gIGlkeDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PlxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29tbWl0dGVkSW5kZXgnLCBpZHgpO1xufVxuXG4vKiogQ29tcHV0ZSB0aGUgZW5nYWdlbWVudCBzaWduYXR1cmUgd2UgdXNlIHRvIGRlY2lkZSB3aGV0aGVyIGEgcmUtY2FwdHVyZWRcbiAqIHR3ZWV0IGlzIFwibWF0ZXJpYWxseSBkaWZmZXJlbnRcIiBmcm9tIHdoYXQgd2UgbGFzdCBjb21taXR0ZWQuIFdlIG9taXRcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXG4gKiBkZWZlYXQgdGhlIGRlZHVwLiBMaWtlcyAvIFJUcyAvIHJlcGxpZXMgLyBxdW90ZXMgY2hhbmdlIHJhcmVseSBlbm91Z2ggdGhhdFxuICogZWFjaCBjaGFuZ2UgaXMgd29ydGggYSByZS1jb21taXQgKGFuZCBhbiBlbmdhZ2VtZW50X2hpc3Rvcnkgc25hcHNob3QpLlxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxuICogdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkgYnlwYXNzZXMgdGhlIGRlZHVwIGV2ZW4gd2hlbiBlbmdhZ2VtZW50IGNvdW50c1xuICogaGF2ZW4ndCBtb3ZlZCBcdTIwMTQgb3RoZXJ3aXNlIHRoZSBuZXcgYm9keSB3b3VsZCBiZSBzaWxlbnRseSBkcm9wcGVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXG4gIGxpa2VzOiBudW1iZXIsXG4gIHJldHdlZXRzOiBudW1iZXIsXG4gIHJlcGxpZXM6IG51bWJlcixcbiAgcXVvdGVzOiBudW1iZXIsXG4gIGlzVHJ1bmNhdGVkOiBib29sZWFuID0gZmFsc2Vcbik6IHN0cmluZyB7XG4gIHJldHVybiBgJHtsaWtlc318JHtyZXR3ZWV0c318JHtyZXBsaWVzfXwke3F1b3Rlc318JHtpc1RydW5jYXRlZCA/ICd0JyA6ICdmJ31gO1xufVxuXG4vKiogRHJvcCBlbnRyaWVzIG9sZGVyIHRoYW4gYG1heEFnZU1zYC4gUmV0dXJucyB0aGUgbnVtYmVyIHBydW5lZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcnVuZUNvbW1pdHRlZEluZGV4KG1heEFnZU1zOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBjb25zdCBjdXRvZmYgPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gbWF4QWdlTXMpLnRvSVNPU3RyaW5nKCk7XG4gIGxldCBwcnVuZWQgPSAwO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgY29uc3QgaW5uZXIgPSBpZHhbaGFuZGxlXTtcbiAgICBpZiAoIWlubmVyKSBjb250aW51ZTtcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcbiAgICAgIGNvbnN0IGUgPSBpbm5lclt0aWRdO1xuICAgICAgaWYgKGUgJiYgZS50cyA8IGN1dG9mZikge1xuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcbiAgICAgICAgcHJ1bmVkICs9IDE7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhpbm5lcikubGVuZ3RoID09PSAwKSBkZWxldGUgaWR4W2hhbmRsZV07XG4gIH1cbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG4gIHJldHVybiBwcnVuZWQ7XG59XG5cbi8vIC0tLSBSZWZldGNoIHF1ZXVlICh0d2VldHMgbmVlZGluZyBmdWxsLXRleHQgcmVjYXB0dXJlKSAtLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hRdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbaGFuZGxlXSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdO1xuICBpZiAoIWlkcykgcmV0dXJuO1xuICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2hhbmRsZV07XG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0UmVmZXRjaFRhcmdldCgpOiBQcm9taXNlPHtcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIHR3ZWV0SWQ6IHN0cmluZztcbn0gfCBudWxsPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBoYW5kbGUsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVNZWRpYUNyYXdsKGhpbnRIYW5kbGU6IHN0cmluZyB8IG51bGwsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcbiAgY29uc3QgaWRzID0gcVtidWNrZXRdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbYnVja2V0XSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcbiAgICBpZiAoIWlkcykgY29udGludWU7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XG4gICAgfVxuICB9XG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTogUHJvbWlzZTx7XG4gIGJ1Y2tldDogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgYnVja2V0LCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXG4gKiBlbnF1ZXVlaW5nIG1lZGlhLWNyYXdsIHRhcmdldHMgd2UndmUgYWxyZWFkeSBhcmNoaXZlZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpc0NvbW1pdHRlZCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgZm9yIChjb25zdCBpbm5lciBvZiBPYmplY3QudmFsdWVzKGlkeCkpIHtcbiAgICBpZiAoaW5uZXIgJiYgdHdlZXRJZCBpbiBpbm5lcikgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyAtLS0gTG9vcCBzZXNzaW9uIHN0YXRlIChwcm9ncmVzcyArIGluZmxpZ2h0IGdhdGluZykgLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEF1dG9TY3JvbGxTZXNzaW9uKCk6IFByb21pc2U8QXV0b1Njcm9sbFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXV0b1Njcm9sbFNlc3Npb24oczogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nLCBzKTtcbn1cblxuLy8gLS0tIFB1cmdlOiB1bnJlbGF0ZWQgYnVmZmVycywgY291bnRlcnMsIHF1ZXVlIGVudHJpZXMgLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vKipcbiAqIERyb3AgZXZlcnkgcGVyLWhhbmRsZSBiaXQgb2Ygc3RhdGUgKGNvdW50ZXJzLCBydW4gYnVmZmVyLCBjb21taXR0ZWQtaW5kZXhcbiAqIGVudHJpZXMsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyaWVzKSB0aGF0IGRvZXNuJ3QgY29ycmVzcG9uZCB0byBhXG4gKiB0cmFja2VkIGFjY291bnQuIFJldHVybnMgYSBzdW1tYXJ5IGRlc2NyaWJpbmcgd2hhdCB3YXMgY2xlYXJlZCBzbyB0aGVcbiAqIGNhbGxlciBjYW4gbG9nIGl0LlxuICpcbiAqIFRyYWNrZWQgYWNjb3VudHMgYXJlIHBhc3NlZCBpbiAoY2FsbGVyIHJlc29sdmVzIGZyb20gdGhlIGxpdmUgY29uZmlnKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1cmdlVW5yZWxhdGVkU3RhdGUodGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4pOiBQcm9taXNlPHtcbiAgY291bnRlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGJ1ZmZlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XG4gIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xuICBtZWRpYUNyYXdsSWRzUmVtb3ZlZDogbnVtYmVyO1xufT4ge1xuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcbiAgY29uc3QgaXNUYXJnZXRlZCA9IChoOiBzdHJpbmcpOiBib29sZWFuID0+IHRhcmdMb3dlci5oYXMoaC50b0xvd2VyQ2FzZSgpKTtcblxuICAvLyBDb3VudGVyc1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCBjb3VudGVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgY291bnRlcnNbaF07XG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcblxuICAvLyBSdW4gYnVmZmVyc1xuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBsZXQgYnVmZmVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoYnVmZmVycykpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBidWZmZXJzW2hdO1xuICAgICAgYnVmZmVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYnVmZmVycyk7XG5cbiAgLy8gQ29tbWl0dGVkIGRlZHVwIGluZGV4XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgaWR4W2hdO1xuICAgICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcblxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXG4gIGNvbnN0IHJxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGxldCByZWZldGNoSGFuZGxlc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgcnFbaF07XG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XG5cbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IGJ1Y2tldHMgYXJlIGhpbnQtaGFuZGxlcyAob3IgXCJfdW5rbm93blwiKS4gRHJvcFxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCBcdTIwMTQgaW5jbHVkaW5nIFwiX3Vua25vd25cIiBzaW5jZSB3ZVxuICAvLyBjYW4ndCB2ZXJpZnkgcmVsYXRpb24uXG4gIGNvbnN0IG1xID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhtcSkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xuICAgICAgZGVsZXRlIG1xW2hdO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIG1xKTtcblxuICByZXR1cm4ge1xuICAgIGNvdW50ZXJzUmVtb3ZlZCxcbiAgICBidWZmZXJzUmVtb3ZlZCxcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcbiAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQsXG4gICAgbWVkaWFDcmF3bElkc1JlbW92ZWQsXG4gIH07XG59XG5cbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbn1cbiIsICJpbXBvcnQgeyBhcHBlbmRBY3Rpdml0eSB9IGZyb20gJy4vc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5sZXQgYnJvYWRjYXN0OiAoKGV2OiBMb2dFdmVudCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldEJyb2FkY2FzdGVyKGZuOiAoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKTogdm9pZCB7XG4gIGJyb2FkY2FzdCA9IGZuO1xufVxuXG5mdW5jdGlvbiBub3dJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBldjogTG9nRXZlbnQgPSB7IHRzOiBub3dJU08oKSwgbGV2ZWwsIG1zZywgY29udGV4dDogcmVkYWN0KGNvbnRleHQpIH07XG4gIC8vIENvbnNvbGUgZm9yIGRldnRvb2xzLlxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xuICBpZiAobGV2ZWwgPT09ICdlcnJvcicpIGNvbnNvbGUuZXJyb3IobGluZSwgZXYuY29udGV4dCk7XG4gIGVsc2UgaWYgKGxldmVsID09PSAnd2FybicpIGNvbnNvbGUud2FybihsaW5lLCBldi5jb250ZXh0KTtcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcbiAgLy8gUGVyc2lzdGVudCB0YWlsLlxuICB0cnkge1xuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGZhaWxlZCB0byBhcHBlbmQgYWN0aXZpdHknLCBlcnIpO1xuICB9XG4gIC8vIExpdmUgYnJvYWRjYXN0IChlLmcuIHRvIHNpZGViYXIpLlxuICB0cnkge1xuICAgIGJyb2FkY2FzdD8uKGV2KTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gU2lkZWJhciBtYXkgbm90IGJlIG9wZW47IHRoYXQncyBmaW5lLlxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCdpbmZvJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCd3YXJuJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gZW1pdCgnZXJyb3InLCBtc2csIGNvbnRleHQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmVFcnJvcihlcnI6IHVua25vd24pOiB7IG1lc3NhZ2U6IHN0cmluZzsgc3RhY2s6IHN0cmluZyB8IG51bGwgfSB7XG4gIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcbiAgfVxuICB0cnkge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4geyBtZXNzYWdlOiAnPHVucHJpbnRhYmxlIGVycm9yPicsIHN0YWNrOiBudWxsIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTdHJpcCBhbnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSBQQVQgb3Igb3RoZXIgbG9uZyBzZWNyZXQgZnJvbSBhIGNvbnRleHRcbiAqIG9iamVjdCBiZWZvcmUgcGVyc2lzdGluZyBpdC4gRGVmZW5zaXZlOiBjYWxsZXJzIHNob3VsZCBub3QgbG9nIHRva2VucywgYnV0XG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxuICovXG5mdW5jdGlvbiByZWRhY3QoY3R4OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhjdHgpKSB7XG4gICAgaWYgKGsudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygndG9rZW4nKSB8fCBrLnRvTG93ZXJDYXNlKCkgPT09ICdwYXQnIHx8IGsgPT09ICdhdXRob3JpemF0aW9uJykge1xuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIC9naXRodWJfcGF0X1tBLVphLXowLTlfXXszMCx9Ly50ZXN0KHYpKSB7XG4gICAgICBvdXRba10gPSB2LnJlcGxhY2UoL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dKy9nLCAnZ2l0aHViX3BhdF88cmVkYWN0ZWQ+Jyk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XG4gICAgICBvdXRba10gPSBgJHt2LnNsaWNlKDAsIDQwOTYpfVx1MjAyNjx0cnVuY2F0ZWQ+YDtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0W2tdID0gdjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cbiIsICJpbXBvcnQgeyBkZXNjcmliZUVycm9yIH0gZnJvbSAnLi9sb2dnZXIuanMnO1xuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5jb25zdCBBUElfQkFTRSA9ICdodHRwczovL2FwaS5naXRodWIuY29tJztcbmNvbnN0IFJBV19CQVNFID0gJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZU9wdGlvbnMge1xuICBwYXRoOiBzdHJpbmc7XG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBleHBlY3RlZFNoYT86IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZVJlc3VsdCB7XG4gIHBhdGg6IHN0cmluZztcbiAgc2hhOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVPcHRpb25zIHtcbiAgcGF0aDogc3RyaW5nO1xuICBjb250ZW50QmFzZTY0OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZXNPcHRpb25zIHtcbiAgZmlsZXM6IENvbW1pdEZpbGVPcHRpb25zW107XG4gIG1lc3NhZ2U6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlc1Jlc3VsdCB7XG4gIGNvbW1pdFNoYTogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbiAgZmlsZXM6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgY2xhc3MgR2l0SHViRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIHN0YXR1czogbnVtYmVyO1xuICBib2R5OiB1bmtub3duO1xuICByZXRyaWFibGU6IGJvb2xlYW47XG4gIGNhdGVnb3J5OiAnYXV0aCcgfCAncmF0ZS1saW1pdCcgfCAnY29uZmxpY3QnIHwgJ25vdC1mb3VuZCcgfCAnc2VydmVyJyB8ICduZXR3b3JrJyB8ICd1bmtub3duJztcbiAgLyoqIFdoZW4gdGhlIEdpdEh1YiByYXRlLWxpbWl0IHdpbmRvdyBmb3IgdGhpcyB0b2tlbiByZXNldHMsIGFzIGEgVW5peFxuICAgKiBlcG9jaCBpbiBzZWNvbmRzLiBQb3B1bGF0ZWQgZnJvbSBgWC1SYXRlTGltaXQtUmVzZXRgIG9uIDQwMy80MjksIG9yXG4gICAqIGRlcml2ZWQgZnJvbSBgUmV0cnktQWZ0ZXJgIGZvciBzZWNvbmRhcnkgbGltaXRzLiBudWxsIHdoZW4gdW5rbm93bi4gKi9cbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVtYmVyIHwgbnVsbDtcblxuICBjb25zdHJ1Y3RvcihvcHRzOiB7XG4gICAgc3RhdHVzOiBudW1iZXI7XG4gICAgYm9keTogdW5rbm93bjtcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgcmV0cmlhYmxlOiBib29sZWFuO1xuICAgIGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXTtcbiAgICByYXRlTGltaXRSZXNldEF0PzogbnVtYmVyIHwgbnVsbDtcbiAgfSkge1xuICAgIHN1cGVyKG9wdHMubWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0dpdEh1YkVycm9yJztcbiAgICB0aGlzLnN0YXR1cyA9IG9wdHMuc3RhdHVzO1xuICAgIHRoaXMuYm9keSA9IG9wdHMuYm9keTtcbiAgICB0aGlzLnJldHJpYWJsZSA9IG9wdHMucmV0cmlhYmxlO1xuICAgIHRoaXMuY2F0ZWdvcnkgPSBvcHRzLmNhdGVnb3J5O1xuICAgIHRoaXMucmF0ZUxpbWl0UmVzZXRBdCA9IG9wdHMucmF0ZUxpbWl0UmVzZXRBdCA/PyBudWxsO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBHaXRIdWJDbGllbnQge1xuICBwcml2YXRlIHJlYWRvbmx5IHNldHRpbmdzOiBTZXR0aW5ncztcblxuICBjb25zdHJ1Y3RvcihzZXR0aW5nczogU2V0dGluZ3MpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gIH1cblxuICAvKiogUmV0dXJucyB0aGUgYXV0aGVudGljYXRlZCB1c2VyJ3MgbG9naW4uIFRocm93cyBvbiBhdXRoIGZhaWx1cmUuICovXG4gIGFzeW5jIHdob2FtaSgpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICByZXR1cm4gKHJlcyBhcyB7IGxvZ2luPzogc3RyaW5nIH0pLmxvZ2luID8/ICc8dW5rbm93bj4nO1xuICB9XG5cbiAgLyoqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZ2l2ZW4gYnJhbmNoIGV4aXN0cyBvbiB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xuICBhc3luYyBicmFuY2hFeGlzdHMoYnJhbmNoOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICdHRVQnLFxuICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2JyYW5jaGVzLyR7ZW5jb2RlVVJJQ29tcG9uZW50KGJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBmYWxzZTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKiogVmVyaWZpZXMgdGhlIFBBVCBjYW4gc2VlIHRoZSBjb25maWd1cmVkIHJlcG8uICovXG4gIGFzeW5jIHZlcmlmeVJlcG9BY2Nlc3MoKTogUHJvbWlzZTx7IGxvZ2luOiBzdHJpbmc7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH0+IHtcbiAgICBjb25zdCBtZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICBjb25zdCByZXBvID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb31gKTtcbiAgICBjb25zdCByID0gcmVwbyBhcyB7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGxvZ2luOiAobWUgYXMgeyBsb2dpbjogc3RyaW5nIH0pLmxvZ2luLFxuICAgICAgZnVsbF9uYW1lOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogVmVyaWZ5IHRoZSBQQVQgY2FuIHdyaXRlIHRvIHRoZSBjb25maWd1cmVkIGJyYW5jaCB3aXRob3V0IGNyZWF0aW5nIGFcbiAgICogY29tbWl0LiBNb3ZpbmcgYSByZWYgdG8gaXRzIGN1cnJlbnQgU0hBIGlzIGEgbm8tb3AsIGJ1dCBHaXRIdWIgc3RpbGxcbiAgICogZW5mb3JjZXMgdGhlIENvbnRlbnRzOiBXcml0ZSBwZXJtaXNzaW9uIHJlcXVpcmVkIGJ5IGNvbW1pdEZpbGVzKCkuXG4gICAqL1xuICBhc3luYyB2ZXJpZnlXcml0ZUFjY2VzcygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XG4gICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAnUEFUQ0gnLFxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXG4gICAgICB7XG4gICAgICAgIHNoYTogaGVhZC5zaGEsXG4gICAgICAgIGZvcmNlOiBmYWxzZSxcbiAgICAgIH1cbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIEZldGNoIGEgdGV4dCBmaWxlIGZyb20gcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSBhdXRoZW50aWNhdGVkIHdpdGggdGhlXG4gICAqIFBBVC4gUmV0dXJucyBudWxsIGlmIHRoZSBmaWxlIGRvZXNuJ3QgZXhpc3QuIFVzZWQgZm9yIGNvbmZpZy9hY2NvdW50cy55YW1sLlxuICAgKi9cbiAgYXN5bmMgZmV0Y2hSYXdUZXh0KHBhdGhJblJlcG86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IHVybCA9IGAke1JBV19CQVNFfS8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS8ke3RoaXMuc2V0dGluZ3MuYnJhbmNofS8ke3BhdGhJblJlcG99YDtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLnNldHRpbmdzLnBhdH1gIH0sXG4gICAgfSk7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkgcmV0dXJuIG51bGw7XG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yKHJlcywgYEdFVCByYXcgJHtwYXRoSW5SZXBvfWApO1xuICAgIHJldHVybiByZXMudGV4dCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvb2sgdXAgYW4gZXhpc3RpbmcgZmlsZSdzIFNIQSB2aWEgdGhlIENvbnRlbnRzIEFQSSwgb3IgbnVsbCBpZiBub3QgZm91bmQuXG4gICAqIFVzZWQgd2hlbiByZXRyeWluZyBhIFBVVCBhZnRlciBhIDQyMiBzaGEgbWlzbWF0Y2guXG4gICAqL1xuICBhc3luYyBnZXRGaWxlU2hhKHBhdGg6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vY29udGVudHMvJHtlbmNvZGVQYXRoKHBhdGgpfT9yZWY9JHtlbmNvZGVVUklDb21wb25lbnQodGhpcy5zZXR0aW5ncy5icmFuY2gpfWBcbiAgICAgICk7XG4gICAgICBjb25zdCByID0gcmVzIGFzIHsgc2hhPzogc3RyaW5nIH07XG4gICAgICByZXR1cm4gci5zaGEgPz8gbnVsbDtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gbnVsbDtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUFVUIGEgZmlsZSB0byB0aGUgcmVwby4gSGFuZGxlcyA0MjIgKHNoYSByZXF1aXJlZCkgYnkgcmUtZmV0Y2hpbmcgdGhlXG4gICAqIGV4aXN0aW5nIHNoYSBhbmQgcmV0cnlpbmcgb25jZS4gUmV0cmllcyBuZXR3b3JrIC8gNXh4IC8gcmF0ZS1saW1pdCBlcnJvcnNcbiAgICogd2l0aCBleHBvbmVudGlhbCBiYWNrb2ZmIHVwIHRvIG1heEF0dGVtcHRzLlxuICAgKi9cbiAgYXN5bmMgcHV0RmlsZShvcHRzOiBQdXRGaWxlT3B0aW9ucyk6IFByb21pc2U8UHV0RmlsZVJlc3VsdD4ge1xuICAgIGNvbnN0IHBhdGggPSBvcHRzLnBhdGg7XG4gICAgY29uc3QgdXJsID0gYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9YDtcbiAgICBsZXQgc2hhOiBzdHJpbmcgfCBudWxsID0gb3B0cy5leHBlY3RlZFNoYSA/PyBudWxsO1xuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcbiAgICAgIGNvbnN0IGJvZHk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXG4gICAgICAgIGNvbnRlbnQ6IG9wdHMuY29udGVudEJhc2U2NCxcbiAgICAgICAgYnJhbmNoOiB0aGlzLnNldHRpbmdzLmJyYW5jaCxcbiAgICAgIH07XG4gICAgICBpZiAoc2hhKSBib2R5LnNoYSA9IHNoYTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdQVVQnLCB1cmwsIGJvZHkpO1xuICAgICAgICBjb25zdCBvdXQgPSByZXMgYXMgeyBjb250ZW50OiB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nOyBwYXRoOiBzdHJpbmcgfSB9O1xuICAgICAgICByZXR1cm4geyBwYXRoOiBvdXQuY29udGVudC5wYXRoLCBzaGE6IG91dC5jb250ZW50LnNoYSwgdXJsOiBvdXQuY29udGVudC5odG1sX3VybCB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xuICAgICAgICBpZiAoZXJyLnN0YXR1cyA9PT0gNDIyICYmICFzaGEpIHtcbiAgICAgICAgICAvLyBGaWxlIGFscmVhZHkgZXhpc3RzOyBmZXRjaCBpdHMgc2hhIGFuZCByZXRyeSBvbmNlLlxuICAgICAgICAgIHNoYSA9IGF3YWl0IHRoaXMuZ2V0RmlsZVNoYShwYXRoKTtcbiAgICAgICAgICBpZiAoIXNoYSkgdGhyb3cgZXJyO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZXJyLnJldHJpYWJsZSB8fCBhdHRlbXB0ID09PSBtYXhBdHRlbXB0cykgdGhyb3cgZXJyO1xuICAgICAgICBhd2FpdCBzbGVlcChiYWNrb2ZmTXMoYXR0ZW1wdCwgZXJyKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihgcHV0RmlsZTogZXhoYXVzdGVkIGF0dGVtcHRzIGZvciAke3BhdGh9YCk7XG4gIH1cblxuICAvKipcbiAgICogQ29tbWl0IHNldmVyYWwgZmlsZXMgd2l0aCBvbmUgYnJhbmNoIHVwZGF0ZS4gVGhlIENvbnRlbnRzIEFQSSBjcmVhdGVzIG9uZVxuICAgKiBjb21taXQgcGVyIFBVVCwgc28gcmFwaWQgZmx1c2hlcyByYWNlIGVhY2ggb3RoZXIgb24gdGhlIGJyYW5jaCBoZWFkLiBUaGlzXG4gICAqIHVzZXMgdGhlIGxvd2VyLWxldmVsIEdpdCBEYXRhIEFQSSBpbnN0ZWFkOiB1cGxvYWQgYmxvYnMsIGJ1aWxkIGEgdHJlZSxcbiAgICogY3JlYXRlIG9uZSBjb21taXQsIHRoZW4gbW92ZSB0aGUgYnJhbmNoIHJlZiBvbmNlLiBJZiBhbm90aGVyIHdyaXRlciBtb3Zlc1xuICAgKiB0aGUgYnJhbmNoIGZpcnN0LCByZWJhc2UgdGhpcyB0cmVlIHBhdGNoIG9udG8gdGhlIGxhdGVzdCBoZWFkIGFuZCByZXRyeS5cbiAgICovXG4gIGFzeW5jIGNvbW1pdEZpbGVzKG9wdHM6IENvbW1pdEZpbGVzT3B0aW9ucyk6IFByb21pc2U8Q29tbWl0RmlsZXNSZXN1bHQ+IHtcbiAgICBpZiAob3B0cy5maWxlcy5sZW5ndGggPT09IDApIHRocm93IG5ldyBFcnJvcignY29tbWl0RmlsZXM6IG5vIGZpbGVzIHRvIGNvbW1pdCcpO1xuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcbiAgICBsZXQgbGFzdEVycjogdW5rbm93biA9IG51bGw7XG5cbiAgICBmb3IgKGxldCBhdHRlbXB0ID0gMTsgYXR0ZW1wdCA8PSBtYXhBdHRlbXB0czsgYXR0ZW1wdCsrKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBibG9icyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICAgIG9wdHMuZmlsZXMubWFwKGFzeW5jIChmaWxlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBvdXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9ibG9ic2AsXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBjb250ZW50OiBmaWxlLmNvbnRlbnRCYXNlNjQsXG4gICAgICAgICAgICAgICAgZW5jb2Rpbmc6ICdiYXNlNjQnLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgcGF0aDogZmlsZS5wYXRoLFxuICAgICAgICAgICAgICBzaGE6IChvdXQgYXMgeyBzaGE6IHN0cmluZyB9KS5zaGEsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0pXG4gICAgICAgICk7XG5cbiAgICAgICAgY29uc3QgaGVhZCA9IGF3YWl0IHRoaXMuZ2V0QnJhbmNoSGVhZCgpO1xuICAgICAgICBjb25zdCB0cmVlID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L3RyZWVzYCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBiYXNlX3RyZWU6IGhlYWQudHJlZVNoYSxcbiAgICAgICAgICAgIHRyZWU6IGJsb2JzLm1hcCgoYmxvYikgPT4gKHtcbiAgICAgICAgICAgICAgcGF0aDogYmxvYi5wYXRoLFxuICAgICAgICAgICAgICBtb2RlOiAnMTAwNjQ0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ2Jsb2InLFxuICAgICAgICAgICAgICBzaGE6IGJsb2Iuc2hhLFxuICAgICAgICAgICAgfSkpLFxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgdHJlZVNoYSA9ICh0cmVlIGFzIHsgc2hhOiBzdHJpbmcgfSkuc2hhO1xuICAgICAgICBjb25zdCBjb21taXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvY29tbWl0c2AsXG4gICAgICAgICAge1xuICAgICAgICAgICAgbWVzc2FnZTogb3B0cy5tZXNzYWdlLFxuICAgICAgICAgICAgdHJlZTogdHJlZVNoYSxcbiAgICAgICAgICAgIHBhcmVudHM6IFtoZWFkLnNoYV0sXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICBjb25zdCBjb21taXRPdXQgPSBjb21taXQgYXMgeyBzaGE6IHN0cmluZzsgaHRtbF91cmw6IHN0cmluZyB9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICAgJ1BBVENIJyxcbiAgICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L3JlZnMvaGVhZHMvJHtlbmNvZGVQYXRoKHRoaXMuc2V0dGluZ3MuYnJhbmNoKX1gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaGE6IGNvbW1pdE91dC5zaGEsXG4gICAgICAgICAgICAgIGZvcmNlOiBmYWxzZSxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBpZiAoaXNDb25mbGljdChlcnIpICYmIGF0dGVtcHQgPCBtYXhBdHRlbXB0cykge1xuICAgICAgICAgICAgbGFzdEVyciA9IGVycjtcbiAgICAgICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBjb21taXRTaGE6IGNvbW1pdE91dC5zaGEsXG4gICAgICAgICAgdXJsOiBjb21taXRPdXQuaHRtbF91cmwsXG4gICAgICAgICAgZmlsZXM6IG9wdHMuZmlsZXMubWFwKChmaWxlKSA9PiBmaWxlLnBhdGgpLFxuICAgICAgICB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGxhc3RFcnIgPSBlcnI7XG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xuICAgICAgICBpZiAoKCFlcnIucmV0cmlhYmxlICYmICFpc0NvbmZsaWN0KGVycikpIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbGFzdEVyciBpbnN0YW5jZW9mIEVycm9yID8gbGFzdEVyciA6IG5ldyBFcnJvcignY29tbWl0RmlsZXM6IGV4aGF1c3RlZCBhdHRlbXB0cycpO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBnZXRCcmFuY2hIZWFkKCk6IFByb21pc2U8eyBzaGE6IHN0cmluZzsgdHJlZVNoYTogc3RyaW5nIH0+IHtcbiAgICBjb25zdCByZWYgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICdHRVQnLFxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmL2hlYWRzLyR7ZW5jb2RlUGF0aCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxuICAgICk7XG4gICAgY29uc3QgaGVhZFNoYSA9IChyZWYgYXMgeyBvYmplY3Q6IHsgc2hhOiBzdHJpbmcgfSB9KS5vYmplY3Quc2hhO1xuICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgJ0dFVCcsXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9jb21taXRzLyR7aGVhZFNoYX1gXG4gICAgKTtcbiAgICByZXR1cm4ge1xuICAgICAgc2hhOiBoZWFkU2hhLFxuICAgICAgdHJlZVNoYTogKGNvbW1pdCBhcyB7IHRyZWU6IHsgc2hhOiBzdHJpbmcgfSB9KS50cmVlLnNoYSxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmZXRjaEpzb24obWV0aG9kOiBzdHJpbmcsIHBhdGg6IHN0cmluZywgYm9keT86IHVua25vd24pOiBQcm9taXNlPHVua25vd24+IHtcbiAgICBjb25zdCB1cmwgPSBwYXRoLnN0YXJ0c1dpdGgoJ2h0dHAnKSA/IHBhdGggOiBgJHtBUElfQkFTRX0ke3BhdGh9YDtcbiAgICBjb25zdCBpbml0OiBSZXF1ZXN0SW5pdCA9IHtcbiAgICAgIG1ldGhvZCxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAsXG4gICAgICAgIEFjY2VwdDogJ2FwcGxpY2F0aW9uL3ZuZC5naXRodWIranNvbicsXG4gICAgICAgICdYLUdpdEh1Yi1BcGktVmVyc2lvbic6ICcyMDIyLTExLTI4JyxcbiAgICAgICAgLi4uKGJvZHkgPyB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSA6IHt9KSxcbiAgICAgIH0sXG4gICAgICAuLi4oYm9keSA/IHsgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSkgfSA6IHt9KSxcbiAgICB9O1xuICAgIGxldCByZXM6IFJlc3BvbnNlO1xuICAgIHRyeSB7XG4gICAgICByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIGluaXQpO1xuICAgIH0gY2F0Y2ggKG5ldEVycikge1xuICAgICAgdGhyb3cgbmV3IEdpdEh1YkVycm9yKHtcbiAgICAgICAgc3RhdHVzOiAwLFxuICAgICAgICBib2R5OiBudWxsLFxuICAgICAgICBtZXNzYWdlOiBgbmV0d29yazogJHtkZXNjcmliZUVycm9yKG5ldEVycikubWVzc2FnZX1gLFxuICAgICAgICByZXRyaWFibGU6IHRydWUsXG4gICAgICAgIGNhdGVnb3J5OiAnbmV0d29yaycsXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDIwNCkgcmV0dXJuIG51bGw7XG4gICAgbGV0IHBhcnNlZDogdW5rbm93biA9IG51bGw7XG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgaWYgKHRleHQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgcGFyc2VkID0gdGV4dDtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgYCR7bWV0aG9kfSAke3BhdGh9YCk7XG4gICAgcmV0dXJuIHBhcnNlZDtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbWFrZUVycm9yKHJlczogUmVzcG9uc2UsIGxhYmVsOiBzdHJpbmcpOiBQcm9taXNlPEdpdEh1YkVycm9yPiB7XG4gICAgbGV0IHBhcnNlZDogdW5rbm93biA9IG51bGw7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgICAgaWYgKHRleHQpIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBpZ25vcmVcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgbGFiZWwpO1xuICB9XG5cbiAgcHJpdmF0ZSBtYWtlRXJyb3JGcm9tUGFyc2VkKHJlczogUmVzcG9uc2UsIGJvZHk6IHVua25vd24sIGxhYmVsOiBzdHJpbmcpOiBHaXRIdWJFcnJvciB7XG4gICAgY29uc3QgbXNnID1cbiAgICAgIHR5cGVvZiBib2R5ID09PSAnb2JqZWN0JyAmJiBib2R5ICYmICdtZXNzYWdlJyBpbiBib2R5XG4gICAgICAgID8gU3RyaW5nKChib2R5IGFzIHsgbWVzc2FnZTogdW5rbm93biB9KS5tZXNzYWdlKVxuICAgICAgICA6IHJlcy5zdGF0dXNUZXh0O1xuICAgIGxldCBjYXRlZ29yeTogR2l0SHViRXJyb3JbJ2NhdGVnb3J5J10gPSAndW5rbm93bic7XG4gICAgbGV0IHJldHJpYWJsZSA9IGZhbHNlO1xuICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDEgfHwgcmVzLnN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAvLyA0MDMgY2FuIGJlIGVpdGhlciBhdXRoIG9yIHJhdGUgbGltaXQ7IGNoZWNrIGhlYWRlcnMuXG4gICAgICBjb25zdCByYXRlID0gcmVzLmhlYWRlcnMuZ2V0KCd4LXJhdGVsaW1pdC1yZW1haW5pbmcnKTtcbiAgICAgIGlmIChyYXRlID09PSAnMCcgfHwgL3JhdGUgbGltaXQvaS50ZXN0KG1zZykpIHtcbiAgICAgICAgY2F0ZWdvcnkgPSAncmF0ZS1saW1pdCc7XG4gICAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjYXRlZ29yeSA9ICdhdXRoJztcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkge1xuICAgICAgY2F0ZWdvcnkgPSAnbm90LWZvdW5kJztcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwOSB8fCByZXMuc3RhdHVzID09PSA0MjIpIHtcbiAgICAgIGNhdGVnb3J5ID0gJ2NvbmZsaWN0JztcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPj0gNTAwKSB7XG4gICAgICBjYXRlZ29yeSA9ICdzZXJ2ZXInO1xuICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQyOSkge1xuICAgICAgY2F0ZWdvcnkgPSAncmF0ZS1saW1pdCc7XG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IEdpdEh1YkVycm9yKHtcbiAgICAgIHN0YXR1czogcmVzLnN0YXR1cyxcbiAgICAgIGJvZHksXG4gICAgICBtZXNzYWdlOiBgJHtsYWJlbH0gXHUyMTkyICR7cmVzLnN0YXR1c306ICR7bXNnfWAsXG4gICAgICByZXRyaWFibGUsXG4gICAgICBjYXRlZ29yeSxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyBwYXJzZVJhdGVMaW1pdFJlc2V0KHJlcy5oZWFkZXJzKSA6IG51bGwsXG4gICAgfSk7XG4gIH1cbn1cblxuLyoqXG4gKiBCZXN0LWVmZm9ydCBwYXJzZSBvZiB3aGVuIHRoZSBjdXJyZW50IHJhdGUtbGltaXQgd2luZG93IGVuZHMuIEdpdEh1YidzXG4gKiBwcmltYXJ5IGxpbWl0IHJlcG9ydHMgYFgtUmF0ZUxpbWl0LVJlc2V0YCBhcyBhIFVuaXggZXBvY2ggaW4gc2Vjb25kcy5cbiAqIFNlY29uZGFyeSAvIGFidXNlIGxpbWl0cyB1c2UgYFJldHJ5LUFmdGVyYCwgd2hpY2ggaXMgZWl0aGVyIGFuIEhUVFAtZGF0ZVxuICogb3IgYSBkZWx0YSBpbiBzZWNvbmRzIFx1MjAxNCB3ZSBub3JtYWxpemUgYm90aCB0byBlcG9jaCBzZWNvbmRzLlxuICovXG5mdW5jdGlvbiBwYXJzZVJhdGVMaW1pdFJlc2V0KGhlYWRlcnM6IEhlYWRlcnMpOiBudW1iZXIgfCBudWxsIHtcbiAgY29uc3QgcmVzZXQgPSBoZWFkZXJzLmdldCgneC1yYXRlbGltaXQtcmVzZXQnKTtcbiAgaWYgKHJlc2V0KSB7XG4gICAgY29uc3QgbiA9IE51bWJlci5wYXJzZUludChyZXNldCwgMTApO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikgJiYgbiA+IDApIHJldHVybiBuO1xuICB9XG4gIGNvbnN0IHJldHJ5QWZ0ZXIgPSBoZWFkZXJzLmdldCgncmV0cnktYWZ0ZXInKTtcbiAgaWYgKHJldHJ5QWZ0ZXIpIHtcbiAgICBjb25zdCBkZWx0YSA9IE51bWJlci5wYXJzZUludChyZXRyeUFmdGVyLCAxMCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShkZWx0YSkgJiYgZGVsdGEgPj0gMCkge1xuICAgICAgcmV0dXJuIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApICsgZGVsdGE7XG4gICAgfVxuICAgIGNvbnN0IGFzRGF0ZSA9IERhdGUucGFyc2UocmV0cnlBZnRlcik7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShhc0RhdGUpKSByZXR1cm4gTWF0aC5mbG9vcihhc0RhdGUgLyAxMDAwKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gZW5jb2RlUGF0aChwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBFbmNvZGUgc2VnbWVudHMgaW5kaXZpZHVhbGx5IHNvIHNsYXNoZXMgcmVtYWluLlxuICByZXR1cm4gcGF0aC5zcGxpdCgnLycpLm1hcChlbmNvZGVVUklDb21wb25lbnQpLmpvaW4oJy8nKTtcbn1cblxuZnVuY3Rpb24gYmFja29mZk1zKGF0dGVtcHQ6IG51bWJlciwgZXJyOiBHaXRIdWJFcnJvcik6IG51bWJlciB7XG4gIC8vIEV4cG9uZW50aWFsIHdpdGggaml0dGVyOyBidW1wIGhpZ2hlciBmb3IgcmF0ZS1saW1pdCByZXNwb25zZXMuXG4gIGNvbnN0IGJhc2UgPSBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IDUwMDAgOiA1MDA7XG4gIGNvbnN0IGppdHRlciA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDQwMCk7XG4gIHJldHVybiBNYXRoLm1pbig2MF8wMDAsIGJhc2UgKiAyICoqIChhdHRlbXB0IC0gMSkgKyBqaXR0ZXIpO1xufVxuXG5mdW5jdGlvbiBpc0NvbmZsaWN0KGVycjogdW5rbm93bik6IGVyciBpcyBHaXRIdWJFcnJvciB7XG4gIHJldHVybiBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdjb25mbGljdCc7XG59XG5cbmZ1bmN0aW9uIHNsZWVwKG1zOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0b0Jhc2U2NChieXRlczogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gYnl0ZXMgaXMgYSBVVEYtOCBzdHJpbmcgb2YgSlNPTjsgZW5jb2RlIHRvIGJhc2U2NCB0aGUgc2FmZSB3YXkuXG4gIGNvbnN0IHV0ZjggPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoYnl0ZXMpO1xuICBsZXQgYmluID0gJyc7XG4gIGZvciAoY29uc3QgYiBvZiB1dGY4KSBiaW4gKz0gU3RyaW5nLmZyb21DaGFyQ29kZShiKTtcbiAgcmV0dXJuIGJ0b2EoYmluKTtcbn1cbiIsICJpbXBvcnQgeyBUV0VFVF9VUkxfUFJFRklYIH0gZnJvbSAnLi9jb25maWcuanMnO1xuaW1wb3J0IHR5cGUge1xuICBDYW5vbmljYWxUd2VldCxcbiAgQ29tbXVuaXR5Tm90ZSxcbiAgTWVkaWFJdGVtLFxuICBUd2VldENhcmQsXG4gIFR3ZWV0VHlwZSxcbiAgVW5hdmFpbGFibGVUd2VldCxcbiAgVXJsRW50aXR5LFxuICBVc2VyU25hcHNob3QsXG59IGZyb20gJy4vdHlwZXMuanMnO1xuXG4vKipcbiAqIE5vcm1hbGl6ZSBHcmFwaFFMIHJlc3BvbnNlIHBheWxvYWRzIGZyb20gWCdzIGludGVybmFsIEFQSSBpbnRvXG4gKiBgQ2Fub25pY2FsVHdlZXRgcy4gTWFueSBlbmRwb2ludHMgc2hhcmUgYSBzaW1pbGFyIHR3ZWV0IHNoYXBlIGJ1dCB3cmFwIGl0IGluXG4gKiBkaWZmZXJlbnQgZW52ZWxvcGVzOyB0aGlzIG1vZHVsZSB3YWxrcyB0aGUgc3RydWN0dXJlIGRlZmVuc2l2ZWx5LlxuICpcbiAqIFRoZSBwYXJzZXIgaXMgaW50ZW50aW9uYWxseSBwZXJtaXNzaXZlOiBpdCB3aWxsIHNpbGVudGx5IHNraXAgZW50cmllcyBpdFxuICogY2FuJ3QgcmVjb2duaXplIGFzIHR3ZWV0cyAoY3Vyc29ycywgYWRzLCBnYXAgZW50cmllcywgbW9kdWxlcyBvZiBvdGhlclxuICogdHdlZXRzLCB0b21ic3RvbmVzKS4gSXQgdGhyb3dzICpvbmx5KiB3aGVuIGdpdmVuIGEgcGF5bG9hZCBpdCBkb2Vzbid0IGtub3dcbiAqIGhvdyB0byB3YWxrIGF0IGFsbCBcdTIwMTQgdGhvc2UgY2FzZXMgYXJlIGNhdWdodCBhbmQgcXVhcmFudGluZWQgdXBzdHJlYW0uXG4gKi9cblxuZXhwb3J0IGludGVyZmFjZSBOb3JtYWxpemVDb250ZXh0IHtcbiAgY2FwdHVyZWRBdDogc3RyaW5nO1xuICBydW5JZDogc3RyaW5nO1xuICBlbmRwb2ludDogc3RyaW5nO1xuICBhbGxvd2VkSGFuZGxlczogUmVhZG9ubHlTZXQ8c3RyaW5nPjtcbiAgc291cmNlVXJsPzogc3RyaW5nIHwgbnVsbDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBOb3JtYWxpemVSZXN1bHQge1xuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W107XG4gIG9ic2VydmVkX2lkczogc3RyaW5nW107XG4gIHVuYXZhaWxhYmxlX3R3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdO1xuICAvKipcbiAgICogVHdlZXQtc2hhcGVkIG5vZGVzIHRoZSB3YWxrZXIgc2F3IChoYWQgYSBgcmVzdF9pZGApIGJ1dCBjb3VsZG4ndCB0dXJuXG4gICAqIGludG8gYSBmdWxsIGBDYW5vbmljYWxUd2VldGAgXHUyMDE0IHR5cGljYWxseSBiZWNhdXNlIHRoZSBlbWJlZGRlZCB1c2VyXG4gICAqIGluZm8gd2FzIG1pc3Npbmcgb3IgdGhlIGVudHJ5IHdhcyBhIG1lZGlhLW9ubHkgdGh1bWJuYWlsIGNhcmQgZnJvbVxuICAgKiB0aGUgVXNlck1lZGlhIGVuZHBvaW50LiBPbmx5IElEcyB3aXRoIGEgdHJ1c3R3b3J0aHkgaGFuZGxlIGZyb20gdGhlXG4gICAqIHR3ZWV0IG5vZGUgaXRzZWxmIGFyZSByZXR1cm5lZDsgb3RoZXJ3aXNlIHRoZSBiYWNrZ3JvdW5kIGNhbm5vdCBidWlsZFxuICAgKiBhIHJlbGlhYmxlIC88aGFuZGxlPi9zdGF0dXMvPGlkPiBkZXRhaWwgVVJMLlxuICAgKi9cbiAgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT47XG59XG5cbi8vIFggdHdlZXQgSURzIGFyZSA2NC1iaXQgcG9zaXRpdmUgaW50ZWdlcnMgc2VyaWFsaXplZCBhcyBkZWNpbWFsIHN0cmluZ3MuXG4vLyBUaGV5J3ZlIGdyb3duIHRvIDE5IGNoYXJzICh+MS41ZTE4KSBieSAyMDI2LiBSZWplY3QgYW55dGhpbmcgdGhhdCBkb2Vzbid0XG4vLyBtYXRjaCB0aGlzIHNoYXBlIFx1MjAxNCBvdGhlcndpc2Ugc3B1cmlvdXMgY2FyZCBJRHMsIGN1cnNvciBzdHJpbmdzLCBhZCBzbG90XG4vLyBJRHMsIGV0Yy4gZW5kIHVwIGluIHRoZSBwYXJ0aWFsLWNhcHR1cmUgcXVldWUgYW5kIHRoZSBjcmF3bCBsb29wXG4vLyBuYXZpZ2F0ZXMgdG8gaW52YWxpZCBVUkxzIHRoYXQgc2hvdyBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXG5jb25zdCBUV0VFVF9JRF9SRSA9IC9eXFxkezE1LDIwfSQvO1xuXG4vLyBPbmx5IG9uZSBlbmRwb2ludCBhY3R1YWxseSBleHBvc2VzIHRoZSBmYWlsdXJlIG1vZGUgdGhlIHBhcnRpYWwtY2FwdHVyZVxuLy8gcXVldWUgZXhpc3RzIGZvciBcdTIwMTQgdGhlIE1lZGlhIHRhYidzIGBVc2VyTWVkaWFgIHF1ZXJ5IHJldHVybmluZ1xuLy8gdGh1bWJuYWlsLW9ubHkgZW50cmllcyB3aXRob3V0IGEgcG9wdWxhdGVkIGF1dGhvciBibG9jay4gRXZlcnkgb3RoZXJcbi8vIGVuZHBvaW50IHRoYXQgaGFuZHMgdXMgYSBgVHdlZXRgIHNoYXBlIGdpdmVzIHVzIHRoZSBmdWxsIGVudHJ5OyBpZlxuLy8gYGJ1aWxkVHdlZXRgIGZhaWxzIHRoZXJlIGl0J3MgYSByZWFsIGVycm9yLCBub3QgXCJnbyByZS1mZXRjaCB0aGlzXCIuXG4vLyBSZXN0cmljdGluZyBwYXJ0aWFsLWlkIGVtaXNzaW9uIHRvIFVzZXJNZWRpYSBzdG9wcyB0aGUgZmxvb2RzIG9mXG4vLyBmYWxzZSBwb3NpdGl2ZXMgcmVwb3J0ZWQgb24gUmVwbGllcyAvIFR3ZWV0RGV0YWlsIC8gU2VhcmNoVGltZWxpbmUuXG5jb25zdCBQQVJUSUFMX09LX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyTWVkaWEnXSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemUocGF5bG9hZDogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogTm9ybWFsaXplUmVzdWx0IHtcbiAgY29uc3QgcmF3VHdlZXRzID0gY29sbGVjdFR3ZWV0cyhwYXlsb2FkKTtcbiAgY29uc3QgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdID0gW107XG4gIGNvbnN0IHVuYXZhaWxhYmxlVHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W10gPSBbXTtcbiAgY29uc3Qgb2JzZXJ2ZWQ6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IGJ1aWx0ID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHBhcnRpYWxNYXAgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nIHwgbnVsbD4oKTtcbiAgY29uc3QgY29sbGVjdFBhcnRpYWxzID0gUEFSVElBTF9PS19FTkRQT0lOVFMuaGFzKGN0eC5lbmRwb2ludCk7XG4gIGZvciAoY29uc3QgcmF3IG9mIHJhd1R3ZWV0cykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB1bmF2YWlsYWJsZSA9IHBpY2tVbmF2YWlsYWJsZVR3ZWV0KHJhdywgY3R4KTtcbiAgICAgIGlmICh1bmF2YWlsYWJsZSkge1xuICAgICAgICB1bmF2YWlsYWJsZVR3ZWV0cy5wdXNoKHVuYXZhaWxhYmxlKTtcbiAgICAgICAgb2JzZXJ2ZWQucHVzaCh1bmF2YWlsYWJsZS50d2VldF9pZCk7XG4gICAgICAgIGJ1aWx0LmFkZCh1bmF2YWlsYWJsZS50d2VldF9pZCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgY29uc3QgdCA9IGJ1aWxkVHdlZXQocmF3LCBjdHgpO1xuICAgICAgaWYgKCF0KSB7XG4gICAgICAgIGlmIChjb2xsZWN0UGFydGlhbHMpIHtcbiAgICAgICAgICAvLyBPbmx5IGVucXVldWUgcmVhbC10d2VldCBzaGVsbHMgd2l0aCBhIHRydXN0d29ydGh5IGhhbmRsZSAobm90XG4gICAgICAgICAgLy8gdG9tYnN0b25lcywgc3RyaXBwZWQgbm9kZXMgbGFja2luZyBhIGxlZ2FjeSBibG9jaywgZ2FyYmFnZSBJRHMsXG4gICAgICAgICAgLy8gb3IgSURzIHRoYXQgd291bGQgcmVxdWlyZSBndWVzc2luZyB0aGUgYXV0aG9yIGZyb20gdGhlIHBhZ2UpLlxuICAgICAgICAgIGNvbnN0IHBhcnRpYWwgPSBwaWNrUGFydGlhbChyYXcpO1xuICAgICAgICAgIGlmIChwYXJ0aWFsKSBwYXJ0aWFsTWFwLnNldChwYXJ0aWFsLnR3ZWV0X2lkLCBwYXJ0aWFsLmhpbnRfaGFuZGxlKTtcbiAgICAgICAgfVxuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIG9ic2VydmVkLnB1c2godC50d2VldF9pZCk7XG4gICAgICBidWlsdC5hZGQodC50d2VldF9pZCk7XG4gICAgICBpZiAoY3R4LmFsbG93ZWRIYW5kbGVzLnNpemUgPT09IDAgfHwgY3R4LmFsbG93ZWRIYW5kbGVzLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSB7XG4gICAgICAgIHR3ZWV0cy5wdXNoKHQpO1xuICAgICAgfVxuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gT25lIGJhZCBlbnRyeSBzaG91bGRuJ3QgdGFrZSBkb3duIHRoZSB3aG9sZSBiYXRjaC5cbiAgICB9XG4gIH1cbiAgLy8gQW55dGhpbmcgdGhhdCBlbmRlZCB1cCBpbiBwYXJ0aWFsTWFwIGJ1dCBBTFNPIGNhbWUgYmFjayBhcyBhIGJ1aWx0XG4gIC8vIHR3ZWV0IChkaWZmZXJlbnQgd2Fsa2VyIHBhc3MsIHNhbWUgaWQpIGlzbid0IGFjdHVhbGx5IHBhcnRpYWwuXG4gIGNvbnN0IHBhcnRpYWxfaWRzOiBBcnJheTx7IHR3ZWV0X2lkOiBzdHJpbmc7IGhpbnRfaGFuZGxlOiBzdHJpbmcgfCBudWxsIH0+ID0gW107XG4gIGZvciAoY29uc3QgW2lkLCBoaW50XSBvZiBwYXJ0aWFsTWFwKSB7XG4gICAgaWYgKGJ1aWx0LmhhcyhpZCkpIGNvbnRpbnVlO1xuICAgIHBhcnRpYWxfaWRzLnB1c2goeyB0d2VldF9pZDogaWQsIGhpbnRfaGFuZGxlOiBoaW50IH0pO1xuICB9XG4gIHJldHVybiB7IHR3ZWV0cywgb2JzZXJ2ZWRfaWRzOiBvYnNlcnZlZCwgdW5hdmFpbGFibGVfdHdlZXRzOiB1bmF2YWlsYWJsZVR3ZWV0cywgcGFydGlhbF9pZHMgfTtcbn1cblxuZnVuY3Rpb24gcGlja1VuYXZhaWxhYmxlVHdlZXQobm9kZTogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogVW5hdmFpbGFibGVUd2VldCB8IG51bGwge1xuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgaWYgKG4uX190eXBlbmFtZSAhPT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgdHdlZXRJZCA9XG4gICAgc3RyT3JOdWxsKG4ucmVzdF9pZCkgPz9cbiAgICBwaWNrVHdlZXRJZEZyb21VcmxzKG5vZGUpID8/XG4gICAgKGN0eC5zb3VyY2VVcmwgPyB0d2VldElkRnJvbVR3ZWV0VXJsKGN0eC5zb3VyY2VVcmwpIDogbnVsbCk7XG4gIGlmICghdHdlZXRJZCB8fCAhVFdFRVRfSURfUkUudGVzdCh0d2VldElkKSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgdW5hdmFpbGFibGVUZXh0ID0gcGlja1RvbWJzdG9uZVRleHQobm9kZSk7XG4gIHJldHVybiB7XG4gICAgdHdlZXRfaWQ6IHR3ZWV0SWQsXG4gICAgYWNjb3VudF9oYW5kbGU6XG4gICAgICBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlLCB0d2VldElkKSA/P1xuICAgICAgKGN0eC5zb3VyY2VVcmwgPyBoYW5kbGVGcm9tVHdlZXRVcmwoY3R4LnNvdXJjZVVybCwgdHdlZXRJZCkgOiBudWxsKSxcbiAgICB1bmF2YWlsYWJsZV9kZXRlY3RlZF9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgdW5hdmFpbGFibGVfcmVhc29uOiBjbGFzc2lmeVVuYXZhaWxhYmxlUmVhc29uKHVuYXZhaWxhYmxlVGV4dCksXG4gICAgdW5hdmFpbGFibGVfdGV4dDogdW5hdmFpbGFibGVUZXh0LFxuICAgIHVuYXZhaWxhYmxlX3NvdXJjZV91cmw6IGN0eC5zb3VyY2VVcmwgPz8gbnVsbCxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcGlja1R3ZWV0SWRGcm9tVXJscyhub2RlOiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgY3VyID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKHR5cGVvZiBjdXIgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25zdCBpZCA9IHR3ZWV0SWRGcm9tVHdlZXRVcmwoY3VyKTtcbiAgICAgIGlmIChpZCkgcmV0dXJuIGlkO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmIChzZWVuLmhhcyhjdXIgYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQoY3VyIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIGN1cikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmZ1bmN0aW9uIHR3ZWV0SWRGcm9tVHdlZXRVcmwocmF3VXJsOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHJhd1VybCwgVFdFRVRfVVJMX1BSRUZJWCk7XG4gICAgaWYgKHVybC5ob3N0bmFtZSAhPT0gJ3guY29tJyAmJiB1cmwuaG9zdG5hbWUgIT09ICd0d2l0dGVyLmNvbScpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IG1hdGNoID0gdXJsLnBhdGhuYW1lLm1hdGNoKC9eXFwvW0EtWmEtejAtOV9dezEsMTV9XFwvc3RhdHVzXFwvKFxcZHsxNSwyMH0pKD86XFwvfCQpLyk7XG4gICAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gbnVsbDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGlja1RvbWJzdG9uZVRleHQobm9kZTogdW5rbm93bik6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBzdHJpbmdzOiBzdHJpbmdbXSA9IFtdO1xuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGN1ciA9IHN0YWNrLnBvcCgpO1xuICAgIGlmICh0eXBlb2YgY3VyID09PSAnc3RyaW5nJykge1xuICAgICAgY29uc3QgdHJpbW1lZCA9IGN1ci50cmltKCk7XG4gICAgICBpZiAoXG4gICAgICAgIHRyaW1tZWQubGVuZ3RoID49IDQgJiZcbiAgICAgICAgIXRyaW1tZWQuc3RhcnRzV2l0aCgnaHR0cDovLycpICYmXG4gICAgICAgICF0cmltbWVkLnN0YXJ0c1dpdGgoJ2h0dHBzOi8vJylcbiAgICAgICkge1xuICAgICAgICBzdHJpbmdzLnB1c2godHJpbW1lZCk7XG4gICAgICB9XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHNlZW4uaGFzKGN1ciBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChjdXIgYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgY3VyKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICBjb25zdCBwcmVmZXJyZWQgPSBzdHJpbmdzLmZpbmQoKHMpID0+XG4gICAgL1xcYihjb3B5cmlnaHR8ZG1jYXx1bmF2YWlsYWJsZXx3aXRoaGVsZHxyZW1vdmVkfGRlbGV0ZWR8dmlvbGF0fHN1c3BlbmRlZClcXGIvaS50ZXN0KHMpXG4gICk7XG4gIHJldHVybiBwcmVmZXJyZWQgPz8gc3RyaW5nc1swXSA/PyBudWxsO1xufVxuXG5mdW5jdGlvbiBjbGFzc2lmeVVuYXZhaWxhYmxlUmVhc29uKHRleHQ6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKCF0ZXh0KSByZXR1cm4gbnVsbDtcbiAgaWYgKC9cXGIoY29weXJpZ2h0fGRtY2EpXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICdjb3B5cmlnaHQnO1xuICBpZiAoL1xcYndpdGhoZWxkXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICd3aXRoaGVsZCc7XG4gIGlmICgvXFxiZGVsZXRlZHxyZW1vdmVkXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICdyZW1vdmVkJztcbiAgaWYgKC9cXGJzdXNwZW5kZWRcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3N1c3BlbmRlZCc7XG4gIGlmICgvXFxidW5hdmFpbGFibGV8bm90IGF2YWlsYWJsZVxcYi9pLnRlc3QodGV4dCkpIHJldHVybiAndW5hdmFpbGFibGUnO1xuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gcGlja1BhcnRpYWwobm9kZTogdW5rbm93bik6IHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfSB8IG51bGwge1xuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgLy8gRGVsZXRlZCB0d2VldHMgc3VyZmFjZSBhcyBUd2VldFRvbWJzdG9uZSBcdTIwMTQgdGhlcmUncyBub3RoaW5nIHRvIHJlZmV0Y2gsXG4gIC8vIHNraXAgdGhlbSBvciB0aGUgY3Jhd2wgbG9vcCB3aWxsIHNwaW4gb24gXCJ0aGlzIHBhZ2UgZG9lc24ndCBleGlzdFwiLlxuICBpZiAobi5fX3R5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnKSByZXR1cm4gbnVsbDtcbiAgLy8gUmVxdWlyZSBhIHJlY29nbml6ZWQgVHdlZXQgdHlwZW5hbWUgT1IgYSBsZWdhY3kgYmxvY2suIEN1cnNvcnMsIGFkcyxcbiAgLy8gbW9kdWxlIGhlYWRlcnMsIGFuZCB0aGUgbGlrZSBnZXQgcmVqZWN0ZWQgaGVyZS5cbiAgY29uc3QgdG4gPSBuLl9fdHlwZW5hbWU7XG4gIGlmICh0biAhPT0gJ1R3ZWV0JyAmJiB0biAhPT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiAhb2JqKG4ubGVnYWN5KSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IHJlc3RJZCA9XG4gICAgKHR5cGVvZiBuLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIG4ucmVzdF9pZCkgfHxcbiAgICAodHlwZW9mIG9iaihuLnR3ZWV0X3Jlc3VsdCk/LnJlc3VsdCA9PT0gJ29iamVjdCcgJiZcbiAgICAgIChvYmoob2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCBhcyBzdHJpbmcpKTtcbiAgaWYgKHR5cGVvZiByZXN0SWQgIT09ICdzdHJpbmcnIHx8ICFUV0VFVF9JRF9SRS50ZXN0KHJlc3RJZCkpIHJldHVybiBudWxsO1xuICBjb25zdCBoaW50SGFuZGxlID0gcGlja0hpbnRIYW5kbGUobm9kZSwgcmVzdElkKTtcbiAgaWYgKCFoaW50SGFuZGxlKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHsgdHdlZXRfaWQ6IHJlc3RJZCwgaGludF9oYW5kbGU6IGhpbnRIYW5kbGUgfTtcbn1cblxuZnVuY3Rpb24gcGlja0hpbnRIYW5kbGUobm9kZTogdW5rbm93biwgdHdlZXRJZDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihvYmoobi5jb3JlKT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgcmV0dXJuIChcbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmNvcmUpPy5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbChvYmoobi5sZWdhY3kpPy5zY3JlZW5fbmFtZSkgPz9cbiAgICBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlLCB0d2VldElkKVxuICApO1xufVxuXG5mdW5jdGlvbiBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlOiB1bmtub3duLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBjdXIgPSBzdGFjay5wb3AoKTtcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGNvbnN0IGhhbmRsZSA9IGhhbmRsZUZyb21Ud2VldFVybChjdXIsIHR3ZWV0SWQpO1xuICAgICAgaWYgKGhhbmRsZSkgcmV0dXJuIGhhbmRsZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY3VyID09PSBudWxsIHx8IHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAoc2Vlbi5oYXMoY3VyIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBjdXIpIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBoYW5kbGVGcm9tVHdlZXRVcmwocmF3VXJsOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICB0cnkge1xuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmF3VXJsLCBUV0VFVF9VUkxfUFJFRklYKTtcbiAgICBpZiAodXJsLmhvc3RuYW1lICE9PSAneC5jb20nICYmIHVybC5ob3N0bmFtZSAhPT0gJ3R3aXR0ZXIuY29tJykgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC8oW0EtWmEtejAtOV9dezEsMTV9KVxcL3N0YXR1c1xcLyhcXGR7MTUsMjB9KSg/OlxcL3wkKS8pO1xuICAgIGlmICghbWF0Y2ggfHwgbWF0Y2hbMl0gIT09IHR3ZWV0SWQpIHJldHVybiBudWxsO1xuICAgIHJldHVybiBtYXRjaFsxXSA/PyBudWxsO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBjb2xsZWN0VHdlZXRzKG9iajogdW5rbm93bik6IHVua25vd25bXSB7XG4gIC8vIFdhbGsgdGhlIHJlc3BvbnNlIHRyZWUgZ2F0aGVyaW5nIGV2ZXJ5dGhpbmcgdGhhdCBsb29rcyBsaWtlIGEgdHdlZXRcbiAgLy8gcmVzdWx0LiBXZSBsb29rIGZvciBub2RlcyBzaGFwZWQgbGlrZTpcbiAgLy8gICB7IF9fdHlwZW5hbWU/OiAnVHdlZXQnfCdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycsIHJlc3RfaWQsIGxlZ2FjeSB9XG4gIC8vIGFuZCB1bndyYXAgdmlzaWJpbGl0eSB3cmFwcGVycy5cbiAgY29uc3Qgb3V0OiB1bmtub3duW10gPSBbXTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtvYmpdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG5vZGUgPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobm9kZSA9PT0gbnVsbCB8fCBub2RlID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xuICAgIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmIChzZWVuLmhhcyhub2RlIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKG5vZGUgYXMgb2JqZWN0KTtcblxuICAgIGlmIChsb29rc0xpa2VUd2VldChub2RlKSkge1xuICAgICAgb3V0LnB1c2godW53cmFwVHdlZXQobm9kZSkpO1xuICAgIH1cbiAgICBpZiAoQXJyYXkuaXNBcnJheShub2RlKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG5vZGUpIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBsb29rc0xpa2VUd2VldChub2RlOiB1bmtub3duKTogbm9kZSBpcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgY29uc3QgdHlwZW5hbWUgPSBuLl9fdHlwZW5hbWU7XG4gIGlmIChcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0JyB8fFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnIHx8XG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZSdcbiAgKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgLy8gU29tZSBlbnRyaWVzIGxhY2sgX190eXBlbmFtZSBidXQgc3RpbGwgY2FycnkgbGVnYWN5ICsgcmVzdF9pZCArIGNvcmUuXG4gIHJldHVybiB0eXBlb2Ygbi5yZXN0X2lkID09PSAnc3RyaW5nJyAmJiB0eXBlb2Ygbi5sZWdhY3kgPT09ICdvYmplY3QnICYmIG4ubGVnYWN5ICE9PSBudWxsO1xufVxuXG5mdW5jdGlvbiB1bndyYXBUd2VldChub2RlOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgaWYgKG5vZGUuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiB0eXBlb2Ygbm9kZS50d2VldCA9PT0gJ29iamVjdCcpIHtcbiAgICByZXR1cm4gbm9kZS50d2VldCBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgfVxuICByZXR1cm4gbm9kZTtcbn1cblxuZnVuY3Rpb24gYnVpbGRUd2VldChyYXc6IHVua25vd24sIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IENhbm9uaWNhbFR3ZWV0IHwgbnVsbCB7XG4gIGlmICh0eXBlb2YgcmF3ICE9PSAnb2JqZWN0JyB8fCByYXcgPT09IG51bGwpIHJldHVybiBudWxsO1xuICBjb25zdCB0ID0gcmF3IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuXG4gIGlmICh0Ll9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHJlc3RJZCA9IHN0ck9yTnVsbCh0LnJlc3RfaWQpO1xuICAvLyBgbGVnYWN5YCBpcyBzdGlsbCB3aGVyZSBtb3N0IGVuZ2FnZW1lbnQgLyBlbnRpdGllcyBsaXZlIGluIDIwMjYtZXJhIFhcbiAgLy8gcGF5bG9hZHMsIGJ1dCBhcyBvZiByZWNlbnQgc2NoZW1hIG1pZ3JhdGlvbnMgc2V2ZXJhbCBmaWVsZHMgcHJldmlvdXNseVxuICAvLyB0aGVyZSAobm90YWJseSB0aGUgYXV0aG9yIGhhbmRsZSkgaGF2ZSBtb3ZlZCB0byBzaWJsaW5nIGxvY2F0aW9ucy4gV2VcbiAgLy8gdG9sZXJhdGUgYSBtaXNzaW5nIGxlZ2FjeSBoZXJlIGFuZCBsb29rIHVwIGV2ZXJ5dGhpbmcgdmlhIGZhbGxiYWNrcy5cbiAgY29uc3QgbGVnYWN5ID0gb2JqKHQubGVnYWN5KSA/PyB7fTtcbiAgaWYgKCFyZXN0SWQpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGNvcmUgPSBvYmoodC5jb3JlKTtcbiAgY29uc3QgdXNlclJlc3VsdCA9IG9iaihvYmooY29yZT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgLy8gQXV0aG9yIGhhbmRsZTogdHJ5IHRoZSBuZXcgYGNvcmVgIHN1YnN0cnVjdHVyZSBmaXJzdCAoY3VycmVudCBYIHNoYXBlKSxcbiAgLy8gdGhlbiB0aGUgbGVnYWN5IGBsZWdhY3kuc2NyZWVuX25hbWVgLCB0aGVuIGEgY291cGxlIG9mIG9sZGVyIHZhcmlhbnRzLlxuICBjb25zdCB1c2VyQ29yZU5ldyA9IG9iaih1c2VyUmVzdWx0Py5jb3JlKTtcbiAgY29uc3QgdXNlckxlZ2FjeSA9IG9iaih1c2VyUmVzdWx0Py5sZWdhY3kpO1xuICBjb25zdCB1c2VyQXZhdGFyT2JqID0gb2JqKHVzZXJSZXN1bHQ/LmF2YXRhcik7XG4gIGNvbnN0IGhhbmRsZSA9XG4gICAgc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwodXNlckxlZ2FjeT8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbChsZWdhY3kuc2NyZWVuX25hbWUpO1xuICBjb25zdCBhY2NvdW50SWQgPVxuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5yZXN0X2lkKSA/P1xuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5pZF9zdHIpID8/XG4gICAgc3RyT3JOdWxsKGxlZ2FjeS51c2VyX2lkX3N0cik7XG4gIGlmICghaGFuZGxlIHx8ICFhY2NvdW50SWQpIHJldHVybiBudWxsO1xuICAvLyBBdXRob3Igc25hcHNob3QuIERpc3BsYXkgbmFtZSArIGF2YXRhciBtb3ZlZCBiZXR3ZWVuIGBsZWdhY3lgIGFuZCB0aGVcbiAgLy8gbmV3IGBjb3JlYCBzdWJzdHJ1Y3R1cmUgb3ZlciB0aW1lOyB0aGUgcmVzdCAodmVyaWZpY2F0aW9uLCBmb2xsb3dlclxuICAvLyBjb3VudHMsIGFjY291bnRfY3JlYXRlZF9hdCkgaXMgc3RpbGwgaW4gYGxlZ2FjeWAuIFdlIHNuYXBzaG90IHRoZVxuICAvLyB3aG9sZSBVc2VyU25hcHNob3QgcGVyIHR3ZWV0IGJlY2F1c2UgdGhlc2UgdmFsdWVzIGRyaWZ0IG92ZXIgdGltZVxuICAvLyBhbmQgdGhlIGF0LWNhcHR1cmUgc3RhdGUgaXMgdGhlIG9ubHkgcmVsaWFibGUgcmVjb3JkLlxuICBjb25zdCBhdXRob3IgPSBleHRyYWN0VXNlclNuYXBzaG90KHVzZXJSZXN1bHQsIHVzZXJDb3JlTmV3LCB1c2VyTGVnYWN5LCB1c2VyQXZhdGFyT2JqKTtcblxuICBjb25zdCBub3RlVHdlZXQgPSBvYmoob2JqKG9iaih0Lm5vdGVfdHdlZXQpPy5ub3RlX3R3ZWV0X3Jlc3VsdHMpPy5yZXN1bHQpO1xuICBjb25zdCB0ZXh0RnJvbU5vdGUgPSBzdHJPck51bGwobm90ZVR3ZWV0Py50ZXh0KTtcbiAgY29uc3QgdGV4dEZyb21MZWdhY3kgPSBzdHJPck51bGwobGVnYWN5LmZ1bGxfdGV4dCkgPz8gJyc7XG4gIGNvbnN0IHRleHQgPSB0ZXh0RnJvbU5vdGUgPz8gdGV4dEZyb21MZWdhY3k7XG4gIGNvbnN0IGlzVHJ1bmNhdGVkID0gZGV0ZWN0VHJ1bmNhdGlvbihub3RlVHdlZXQsIGxlZ2FjeSwgdGV4dEZyb21MZWdhY3kpO1xuICBjb25zdCBjb21tdW5pdHlOb3RlID0gZXh0cmFjdENvbW11bml0eU5vdGUodCwgbGVnYWN5LCBjdHguY2FwdHVyZWRBdCk7XG5cbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKSA/PyB7fTtcbiAgY29uc3QgZW50aXRpZXNGcm9tTm90ZSA9IG9iaihub3RlVHdlZXQ/LmVudGl0eV9zZXQpO1xuICBjb25zdCBoYXNodGFncyA9IGV4dHJhY3RIYXNodGFncyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgbWVudGlvbnMgPSBleHRyYWN0TWVudGlvbnMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IHVybHMgPSBleHRyYWN0VXJscyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgbWVkaWEgPSBleHRyYWN0TWVkaWEobGVnYWN5KTtcblxuICBjb25zdCB0d2VldFR5cGUgPSBjbGFzc2lmeVR3ZWV0VHlwZSh0LCBsZWdhY3kpO1xuXG4gIC8vIHBvc3RlZF9hdDogbGVnYWN5LmNyZWF0ZWRfYXQgcmVtYWlucyB0aGUgY2Fub25pY2FsIGxvY2F0aW9uOyBpZiB0aGF0J3NcbiAgLy8gbWlzc2luZyBpbiBhIGZ1dHVyZSBzY2hlbWEgd2UgZmFsbCBiYWNrIHRvIHRvcC1sZXZlbCBjcmVhdGVkX2F0LlxuICBjb25zdCBwb3N0ZWRBdCA9XG4gICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwobGVnYWN5LmNyZWF0ZWRfYXQpKSA/PyBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh0LmNyZWF0ZWRfYXQpKTtcbiAgaWYgKCFwb3N0ZWRBdCkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgdmlld3MgPSBvYmoodC52aWV3cyk7XG4gIGNvbnN0IHZpZXdDb3VudCA9IG51bU9yTnVsbCh2aWV3cz8uY291bnQpID8/IG51bU9yTnVsbChzdHJPck51bGwodmlld3M/LmNvdW50KSk7XG5cbiAgY29uc3QgY2FyZCA9IGV4dHJhY3RDYXJkKHQpO1xuICBjb25zdCBwbGFjZSA9IG9iaihsZWdhY3kucGxhY2UpO1xuXG4gIGNvbnN0IHR3ZWV0OiBDYW5vbmljYWxUd2VldCA9IHtcbiAgICB0d2VldF9pZDogcmVzdElkLFxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgYWNjb3VudF9pZDogYWNjb3VudElkLFxuICAgIHBvc3RlZF9hdDogcG9zdGVkQXQsXG4gICAgZmlyc3RfY2FwdHVyZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxuICAgIGxhc3Rfc2Vlbl9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgZGVsZXRpb25fZGV0ZWN0ZWRfYXQ6IG51bGwsXG4gICAgdW5hdmFpbGFibGVfZGV0ZWN0ZWRfYXQ6IG51bGwsXG4gICAgdW5hdmFpbGFibGVfcmVhc29uOiBudWxsLFxuICAgIHVuYXZhaWxhYmxlX3RleHQ6IG51bGwsXG4gICAgdW5hdmFpbGFibGVfc291cmNlX3VybDogbnVsbCxcbiAgICB0d2VldF91cmw6IGAke1RXRUVUX1VSTF9QUkVGSVh9LyR7aGFuZGxlfS9zdGF0dXMvJHtyZXN0SWR9YCxcbiAgICB0d2VldF90eXBlOiB0d2VldFR5cGUsXG4gICAgY29udmVyc2F0aW9uX2lkOiBzdHJPck51bGwobGVnYWN5LmNvbnZlcnNhdGlvbl9pZF9zdHIpLFxuICAgIHJlcGx5X3RvX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpLFxuICAgIHJlcGx5X3RvX2FjY291bnQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc2NyZWVuX25hbWUpLFxuICAgIHJlcGx5X3RvX2FjY291bnRfaWQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fdXNlcl9pZF9zdHIpLFxuICAgIHF1b3RlZF90d2VldF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0ciksXG4gICAgcmV0d2VldGVkX3R3ZWV0X2lkOiBzdHJPck51bGwoXG4gICAgICBvYmoob2JqKGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX3Jlc3VsdCk/LnJlc3VsdCk/LnJlc3RfaWQgPz9cbiAgICAgICAgKGxlZ2FjeSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikucmV0d2VldGVkX3N0YXR1c19pZF9zdHJcbiAgICApLFxuICAgIHRleHQsXG4gICAgdGV4dF9yZXNvbHZlZDogcmVzb2x2ZVNob3J0VXJscyh0ZXh0LCB1cmxzKSxcbiAgICBsYW5nOiBzdHJPck51bGwobGVnYWN5LmxhbmcpLFxuICAgIHBvc3NpYmx5X3NlbnNpdGl2ZTogYm9vbE9yTnVsbChsZWdhY3kucG9zc2libHlfc2Vuc2l0aXZlKSxcbiAgICBzb3VyY2U6IHN0ck9yTnVsbChsZWdhY3kuc291cmNlKSA/PyBzdHJPck51bGwodC5zb3VyY2UpLFxuICAgIHBsYWNlX2Z1bGxfbmFtZTogc3RyT3JOdWxsKHBsYWNlPy5mdWxsX25hbWUpLFxuICAgIGhhc2h0YWdzLFxuICAgIG1lbnRpb25zLFxuICAgIHVybHMsXG4gICAgY2FyZCxcbiAgICBtZWRpYSxcbiAgICBsaWtlX2NvdW50OiBudW1Pclplcm8obGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcbiAgICByZXR3ZWV0X2NvdW50OiBudW1Pclplcm8obGVnYWN5LnJldHdlZXRfY291bnQpLFxuICAgIHJlcGx5X2NvdW50OiBudW1Pclplcm8obGVnYWN5LnJlcGx5X2NvdW50KSxcbiAgICBxdW90ZV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5xdW90ZV9jb3VudCksXG4gICAgdmlld19jb3VudDogdmlld0NvdW50LFxuICAgIGJvb2ttYXJrX2NvdW50OiBudW1Pck51bGwobGVnYWN5LmJvb2ttYXJrX2NvdW50KSxcbiAgICBlbmdhZ2VtZW50X2hpc3Rvcnk6IFtcbiAgICAgIHtcbiAgICAgICAgY2FwdHVyZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxuICAgICAgICBsaWtlczogbnVtT3JaZXJvKGxlZ2FjeS5mYXZvcml0ZV9jb3VudCksXG4gICAgICAgIHJldHdlZXRzOiBudW1Pclplcm8obGVnYWN5LnJldHdlZXRfY291bnQpLFxuICAgICAgICByZXBsaWVzOiBudW1Pclplcm8obGVnYWN5LnJlcGx5X2NvdW50KSxcbiAgICAgICAgcXVvdGVzOiBudW1Pclplcm8obGVnYWN5LnF1b3RlX2NvdW50KSxcbiAgICAgICAgdmlld3M6IHZpZXdDb3VudCxcbiAgICAgICAgYm9va21hcmtzOiBudW1Pck51bGwobGVnYWN5LmJvb2ttYXJrX2NvdW50KSxcbiAgICAgIH0sXG4gICAgXSxcbiAgICBhdXRob3IsXG4gICAgY29tbXVuaXR5X25vdGU6IGNvbW11bml0eU5vdGUsXG4gICAgaXNfdHJ1bmNhdGVkOiBpc1RydW5jYXRlZCxcbiAgICB3YXliYWNrX3VybDogbnVsbCxcbiAgICB3YXliYWNrX3N1Ym1pdHRlZF9hdDogbnVsbCxcbiAgICBjYXB0dXJlX3NvdXJjZTogJ2V4dGVuc2lvbicsXG4gICAgY2FwdHVyZV9ydW5faWQ6IGN0eC5ydW5JZCxcbiAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgfTtcblxuICByZXR1cm4gdHdlZXQ7XG59XG5cbmZ1bmN0aW9uIGNsYXNzaWZ5VHdlZXRUeXBlKHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVHdlZXRUeXBlIHtcbiAgaWYgKGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX3Jlc3VsdCB8fCBsZWdhY3kucmV0d2VldGVkX3N0YXR1c19pZF9zdHIpIHJldHVybiAncmV0d2VldCc7XG4gIGlmIChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXBseSc7XG4gIGlmIChsZWdhY3kuaXNfcXVvdGVfc3RhdHVzID09PSB0cnVlIHx8IGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdxdW90ZSc7XG4gIGlmICh0Ll9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycpIHtcbiAgICAvLyBwYXNzIHRocm91Z2hcbiAgfVxuICByZXR1cm4gJ29yaWdpbmFsJztcbn1cblxuZnVuY3Rpb24gZXh0cmFjdEhhc2h0YWdzKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZ1tdIHtcbiAgY29uc3QgYXJyID0gZW50aXRpZXMuaGFzaHRhZ3M7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XG4gIHJldHVybiBhcnJcbiAgICAubWFwKChoKSA9PlxuICAgICAgdHlwZW9mIGggPT09ICdvYmplY3QnICYmIGggJiYgJ3RleHQnIGluIGggPyBTdHJpbmcoKGggYXMgeyB0ZXh0OiB1bmtub3duIH0pLnRleHQpIDogbnVsbFxuICAgIClcbiAgICAuZmlsdGVyKChzKTogcyBpcyBzdHJpbmcgPT4gdHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHMubGVuZ3RoID4gMCk7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RNZW50aW9ucyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLnVzZXJfbWVudGlvbnM7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XG4gIHJldHVybiBhcnJcbiAgICAubWFwKCh1KSA9PlxuICAgICAgdHlwZW9mIHUgPT09ICdvYmplY3QnICYmIHUgJiYgJ3NjcmVlbl9uYW1lJyBpbiB1XG4gICAgICAgID8gU3RyaW5nKCh1IGFzIHsgc2NyZWVuX25hbWU6IHVua25vd24gfSkuc2NyZWVuX25hbWUpXG4gICAgICAgIDogbnVsbFxuICAgIClcbiAgICAuZmlsdGVyKChzKTogcyBpcyBzdHJpbmcgPT4gdHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHMubGVuZ3RoID4gMCk7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RVcmxzKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFVybEVudGl0eVtdIHtcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXJscztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgY29uc3Qgb3V0OiBVcmxFbnRpdHlbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHUgb2YgYXJyKSB7XG4gICAgaWYgKHR5cGVvZiB1ICE9PSAnb2JqZWN0JyB8fCB1ID09PSBudWxsKSBjb250aW51ZTtcbiAgICBjb25zdCBvID0gdSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICBjb25zdCBzaG9ydCA9IHN0ck9yTnVsbChvLnVybCk7XG4gICAgY29uc3QgZXhwYW5kZWQgPSBzdHJPck51bGwoby5leHBhbmRlZF91cmwpO1xuICAgIGNvbnN0IGRpc3BsYXkgPSBzdHJPck51bGwoby5kaXNwbGF5X3VybCk7XG4gICAgaWYgKCFzaG9ydCB8fCAhZXhwYW5kZWQpIGNvbnRpbnVlO1xuICAgIG91dC5wdXNoKHsgc2hvcnQsIGV4cGFuZGVkLCBkaXNwbGF5OiBkaXNwbGF5ID8/IGV4cGFuZGVkIH0pO1xuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RNZWRpYShsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogTWVkaWFJdGVtW10ge1xuICBjb25zdCBleHRlbmRlZCA9IG9iaihsZWdhY3kuZXh0ZW5kZWRfZW50aXRpZXMpO1xuICBjb25zdCBmcm9tRXh0ID0gZXh0ZW5kZWQgPyB0b0FycmF5KGV4dGVuZGVkLm1lZGlhKSA6IFtdO1xuICBjb25zdCBmcm9tRW50ID0gdG9BcnJheShvYmoobGVnYWN5LmVudGl0aWVzKT8ubWVkaWEpO1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IG1lcmdlZCA9IFsuLi5mcm9tRXh0LCAuLi5mcm9tRW50XS5maWx0ZXIoKG0pID0+IHtcbiAgICBpZiAodHlwZW9mIG0gIT09ICdvYmplY3QnIHx8IG0gPT09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBpZCA9XG4gICAgICBzdHJPck51bGwoKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLm1lZGlhX2tleSkgPz9cbiAgICAgIHN0ck9yTnVsbCgobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuaWRfc3RyKTtcbiAgICBpZiAoIWlkKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKHNlZW4uaGFzKGlkKSkgcmV0dXJuIGZhbHNlO1xuICAgIHNlZW4uYWRkKGlkKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSk7XG4gIHJldHVybiBtZXJnZWQubWFwKChyYXcpID0+IGJ1aWxkTWVkaWEocmF3IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSk7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkTWVkaWEobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW0ge1xuICBjb25zdCB0eXBlID0gc3RyT3JOdWxsKG0udHlwZSkgYXMgTWVkaWFJdGVtWydtZWRpYV90eXBlJ107XG4gIGNvbnN0IG9yaWdpbmFsID0gcGlja09yaWdpbmFsVXJsKG0sIHR5cGUpO1xuICBjb25zdCBpbmZvID0gb2JqKG0ub3JpZ2luYWxfaW5mbyk7XG4gIGNvbnN0IHZpZGVvSW5mbyA9IG9iaihtLnZpZGVvX2luZm8pO1xuICBjb25zdCBkdXJhdGlvbk1zID0gbnVtT3JOdWxsKHZpZGVvSW5mbz8uZHVyYXRpb25fbWlsbGlzKTtcbiAgY29uc3QgYWx0VGV4dCA9IHN0ck9yTnVsbChtLmV4dF9hbHRfdGV4dCk7XG4gIGNvbnN0IG1lZGlhSWQgPVxuICAgIHN0ck9yTnVsbChtLm1lZGlhX2tleSkgPz9cbiAgICBzdHJPck51bGwobS5pZF9zdHIpID8/XG4gICAgYCR7dHlwZSA/PyAnbWVkaWEnfS0ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIpfWA7XG4gIHJldHVybiB7XG4gICAgbWVkaWFfaWQ6IG1lZGlhSWQsXG4gICAgbWVkaWFfdHlwZTogKHR5cGUgPz8gJ3Bob3RvJykgYXMgTWVkaWFJdGVtWydtZWRpYV90eXBlJ10sXG4gICAgb3JpZ2luYWxfdXJsOiBvcmlnaW5hbCA/PyAnJyxcbiAgICByZWxlYXNlX2Fzc2V0X3VybDogbnVsbCxcbiAgICBzaGEyNTY6IG51bGwsXG4gICAgYnl0ZXM6IG51bGwsXG4gICAgZHVyYXRpb25fc2VjOiBkdXJhdGlvbk1zICE9PSBudWxsID8gZHVyYXRpb25NcyAvIDEwMDAgOiBudWxsLFxuICAgIHdpZHRoOiBudW1Pck51bGwoaW5mbz8ud2lkdGgpLFxuICAgIGhlaWdodDogbnVtT3JOdWxsKGluZm8/LmhlaWdodCksXG4gICAgYWx0X3RleHQ6IGFsdFRleHQsXG4gICAgYXJjaGl2ZV9zdGF0dXM6ICdwZW5kaW5nJyxcbiAgICBhcmNoaXZlX2F0dGVtcHRzOiAwLFxuICAgIGxhc3RfYXR0ZW1wdF9hdDogbnVsbCxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcGlja09yaWdpbmFsVXJsKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCB0eXBlOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICh0eXBlID09PSAncGhvdG8nKSByZXR1cm4gc3RyT3JOdWxsKG0ubWVkaWFfdXJsX2h0dHBzKSA/PyBzdHJPck51bGwobS5tZWRpYV91cmwpO1xuICBjb25zdCB2YXJpYW50cyA9IHRvQXJyYXkob2JqKG0udmlkZW9faW5mbyk/LnZhcmlhbnRzKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPltdO1xuICBpZiAodmFyaWFudHMubGVuZ3RoID09PSAwKSByZXR1cm4gc3RyT3JOdWxsKG0ubWVkaWFfdXJsX2h0dHBzKTtcbiAgLy8gSGlnaGVzdC1iaXRyYXRlIG1wNC5cbiAgbGV0IGJlc3Q6IHsgdXJsOiBzdHJpbmc7IGJpdHJhdGU6IG51bWJlciB9IHwgbnVsbCA9IG51bGw7XG4gIGZvciAoY29uc3QgdiBvZiB2YXJpYW50cykge1xuICAgIGNvbnN0IGN0ID0gc3RyT3JOdWxsKHYuY29udGVudF90eXBlKTtcbiAgICBjb25zdCB1cmwgPSBzdHJPck51bGwodi51cmwpO1xuICAgIGlmICghdXJsKSBjb250aW51ZTtcbiAgICBpZiAoY3QgPT09ICd2aWRlby9tcDQnKSB7XG4gICAgICBjb25zdCBiciA9IG51bU9yTnVsbCh2LmJpdHJhdGUpID8/IDA7XG4gICAgICBpZiAoIWJlc3QgfHwgYnIgPiBiZXN0LmJpdHJhdGUpIGJlc3QgPSB7IHVybCwgYml0cmF0ZTogYnIgfTtcbiAgICB9IGVsc2UgaWYgKCFiZXN0KSB7XG4gICAgICAvLyBGYWxsYmFjayB0byBhbnkgdmFyaWFudCBpZiBubyBtcDQgZm91bmQuXG4gICAgICBiZXN0ID0geyB1cmwsIGJpdHJhdGU6IDAgfTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGJlc3Q/LnVybCA/PyBudWxsO1xufVxuXG5mdW5jdGlvbiByZXNvbHZlU2hvcnRVcmxzKHRleHQ6IHN0cmluZywgdXJsczogVXJsRW50aXR5W10pOiBzdHJpbmcge1xuICBpZiAodXJscy5sZW5ndGggPT09IDApIHJldHVybiB0ZXh0O1xuICBsZXQgb3V0ID0gdGV4dDtcbiAgZm9yIChjb25zdCB1IG9mIHVybHMpIG91dCA9IG91dC5zcGxpdCh1LnNob3J0KS5qb2luKHUuZXhwYW5kZWQpO1xuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBwYXJzZVR3aXR0ZXJEYXRlKHM6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKCFzKSByZXR1cm4gbnVsbDtcbiAgLy8gVHdpdHRlciBzaGlwcyBkYXRlcyBsaWtlIFwiTW9uIEFwciAxMiAxNDoyMzowMSArMDAwMCAyMDI1XCIuXG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShzKTtcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBudWxsO1xuICByZXR1cm4gZC50b0lTT1N0cmluZygpO1xufVxuXG5mdW5jdGlvbiBzdHJPck51bGwodjogdW5rbm93bik6IHN0cmluZyB8IG51bGwge1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCA/IHYgOiBudWxsO1xufVxuZnVuY3Rpb24gYm9vbE9yTnVsbCh2OiB1bmtub3duKTogYm9vbGVhbiB8IG51bGwge1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdib29sZWFuJyA/IHYgOiBudWxsO1xufVxuZnVuY3Rpb24gbnVtT3JOdWxsKHY6IHVua25vd24pOiBudW1iZXIgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyAmJiBOdW1iZXIuaXNGaW5pdGUodikpIHJldHVybiB2O1xuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG4gPSBOdW1iZXIodik7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShuKSkgcmV0dXJuIG47XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBudW1Pclplcm8odjogdW5rbm93bik6IG51bWJlciB7XG4gIHJldHVybiBudW1Pck51bGwodikgPz8gMDtcbn1cbmZ1bmN0aW9uIG9iaih2OiB1bmtub3duKTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsIHtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnb2JqZWN0JyAmJiB2ICE9PSBudWxsICYmICFBcnJheS5pc0FycmF5KHYpXG4gICAgPyAodiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilcbiAgICA6IG51bGw7XG59XG5mdW5jdGlvbiB0b0FycmF5KHY6IHVua25vd24pOiB1bmtub3duW10ge1xuICByZXR1cm4gQXJyYXkuaXNBcnJheSh2KSA/IHYgOiBbXTtcbn1cblxuLyoqXG4gKiBEZWNpZGUgd2hldGhlciBhIHR3ZWV0J3MgYXJjaGl2ZWQgYHRleHRgIGlzIHRoZSB0cnVuY2F0ZWQgaGVhZCBvZiBhIGxvbmdlclxuICogYm9keS4gQSB0cnVuY2F0ZWQgdHdlZXQgaGFzIFgncyBcIlNob3cgbW9yZVwiIHQuY28gVVJMIGFwcGVuZGVkIFx1MjAxNCB0aGF0IFVSTFxuICogc3BlY2lmaWNhbGx5IGV4cGFuZHMgdG8gdGhlIHR3ZWV0J3Mgb3duIC9pL3dlYi9zdGF0dXMvPGlkPiBwZXJtYWxpbmssIGFuZFxuICogaXMgdGhlIG9ubHkgcmVsaWFibGUgZGlzdGluZ3Vpc2hpbmcgZmVhdHVyZS4gUGxlbnR5IG9mIG5vcm1hbCB0d2VldHMgaGF2ZVxuICogdHJhaWxpbmcgdC5jbyBVUkxzIChtZWRpYSwgcXVvdGVzLCByZWd1bGFyIGxpbmtzKSwgYW5kIHRoZWlyXG4gKiBkaXNwbGF5X3RleHRfcmFuZ2UgYWxzbyB0cmltcyBwYXN0IGZ1bGxfdGV4dC5sZW5ndGgsIHNvIHRoZSBvbGRcbiAqIFwiZGlzcGxheV90ZXh0X3JhbmdlWzFdIDwgZnVsbF90ZXh0Lmxlbmd0aFwiIGhldXJpc3RpYyB3YXMgb3ZlcmZsYWdnaW5nXG4gKiBlc3NlbnRpYWxseSBldmVyeSB0d2VldCB3aXRoIGEgbGluayBpbiBpdC5cbiAqXG4gKiBSdWxlczpcbiAqICAgLSBub3RlX3R3ZWV0IHByZXNlbnQgIFx1MjE5MiBub3QgdHJ1bmNhdGVkICh3ZSBhbHJlYWR5IGhhdmUgdGhlIGZ1bGwgYm9keSkuXG4gKiAgIC0gT25lIG9mIGxlZ2FjeS5lbnRpdGllcy51cmxzIGhhcyBhbiBleHBhbmRlZF91cmwgbGlrZVxuICogICAgIFwiLi4uL2kvd2ViL3N0YXR1cy88aWQ+XCIgIFx1MjE5MiAgdHJ1bmNhdGVkLlxuICogICAtIE90aGVyd2lzZSBcdTIxOTIgbm90IHRydW5jYXRlZC5cbiAqXG4gKiBUaGUgcHJldmlvdXMgZmFsbGJhY2sgKFwidHJhaWxpbmcgdC5jbyBVUkwgKyBsZW5ndGggXHUyMjY1IDI3MFwiKSBmbGFnZ2VkIGV2ZXJ5XG4gKiBtZWRpYSB0d2VldCBleGFjdGx5IGF0IHRoZSAyODAtY2hhciBsaW1pdC4gV2UgZHJvcCBpdCBlbnRpcmVseTsgdGhlIG9ubHlcbiAqIGNvc3QgaXMgbWlzc2luZyBnZW51aW5lbHktdHJ1bmNhdGVkIHR3ZWV0cyB3aG9zZSBwYXlsb2FkIHdhcyBzbyBkZWdyYWRlZFxuICogaXQgbGFja2VkIGVudGl0aWVzIFx1MjAxNCB3aGljaCBpcyBhbHNvIHdoZXJlIHRoZSByZWZldGNoIGxvb3Agd291bGQgZmFpbFxuICogYW55d2F5LCBzbyBub3RoaW5nIGlzIGFjdHVhbGx5IGxvc3QuXG4gKi9cbmZ1bmN0aW9uIGRldGVjdFRydW5jYXRpb24oXG4gIG5vdGVUd2VldDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxuICBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICBmdWxsVGV4dDogc3RyaW5nXG4pOiBib29sZWFuIHtcbiAgaWYgKG5vdGVUd2VldCkgcmV0dXJuIGZhbHNlO1xuICBpZiAoIWZ1bGxUZXh0KSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGVudGl0aWVzID0gb2JqKGxlZ2FjeS5lbnRpdGllcyk7XG4gIGNvbnN0IHVybHMgPSBlbnRpdGllcyA/IGVudGl0aWVzLnVybHMgOiBudWxsO1xuICBpZiAoQXJyYXkuaXNBcnJheSh1cmxzKSkge1xuICAgIGZvciAoY29uc3QgdSBvZiB1cmxzKSB7XG4gICAgICBpZiAodHlwZW9mIHUgIT09ICdvYmplY3QnIHx8IHUgPT09IG51bGwpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgZXhwID0gKHUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLmV4cGFuZGVkX3VybDtcbiAgICAgIC8vIFRoZSBcIlNob3cgbW9yZVwiIGxpbmsgZXhwYW5kcyB0byBlaXRoZXIgb2YgdGhlc2Ugc2VsZi1wZXJtYWxpbmtcbiAgICAgIC8vIHNoYXBlczogIGh0dHBzOi8veC5jb20vaS93ZWIvc3RhdHVzLzxpZD5cbiAgICAgIC8vICAgICAgICAgIGh0dHBzOi8vdHdpdHRlci5jb20vaS93ZWIvc3RhdHVzLzxpZD5cbiAgICAgIGlmICh0eXBlb2YgZXhwID09PSAnc3RyaW5nJyAmJiAvXFwvaVxcL3dlYlxcL3N0YXR1c1xcL1xcZCsvLnRlc3QoZXhwKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vKipcbiAqIEZpbHRlciBgdHdlZXRzYCBkb3duIHRvIHRob3NlIHJlbGF0ZWQgdG8gYSB0cmFja2VkIGFjY291bnQuIEEgdHdlZXQgaXNcbiAqIFwicmVsYXRlZFwiIGlmIGFueSBvZiB0aGUgZm9sbG93aW5nIGhvbGQ6XG4gKlxuICogICAtIGl0cyBhdXRob3IgaXMgdHJhY2tlZCAoaGFuZGxlIGluIGB0YXJnZXRlZGApLFxuICogICAtIGl0cyBhdXRob3IgaXMgY29yZSAoaGFuZGxlIGluIGBjb3JlSGFuZGxlc2ApLCByZWdhcmRsZXNzIG9mIHdoZXJlIFhcbiAqICAgICBzdXJmYWNlZCBpdCxcbiAqICAgLSBpdCBtZW50aW9ucyBhIHRyYWNrZWQgaGFuZGxlLFxuICogICAtIGl0IHJlcGxpZXMgdG8gYSB0cmFja2VkIGFjY291bnQsXG4gKiAgIC0gaXQgcXVvdGVzL3JlcGxpZXMtdG8gYSB0d2VldCB0aGF0J3MgYWxzbyBwcmVzZW50IGluIHRoZVxuICogICAgIGJhdGNoICphbmQqIGF1dGhvcmVkIGJ5IGEgdHJhY2tlZCBhY2NvdW50ICh0cmFuc2l0aXZlbHkgcmVsYXRlZCBcdTIwMTRcbiAqICAgICBjYXB0dXJlcyBxdW90ZWQvcmVwbHkgY29udGV4dCB0aGF0IGFwcGVhcnMgYXMgYSBzaWJsaW5nIG5vZGUgaW4gdGhlXG4gKiAgICAgc2FtZSBHcmFwaFFMIHJlc3BvbnNlKS5cbiAqXG4gKiBOb24tY29yZSByZXR3ZWV0IHdyYXBwZXJzIGFyZSBub3Qga2VwdCBtZXJlbHkgYmVjYXVzZSB0aGV5IHJldHdlZXRlZCBhXG4gKiB0cmFja2VkL2NvcmUgdHdlZXQuIFRoZSB1bmRlcmx5aW5nIGNvcmUgdHdlZXQgaXMga2VwdCBhcyBpdHMgb3duIHJvdyB3aGVuXG4gKiBwcmVzZW50IGluIHRoZSBwYXlsb2FkLlxuICpcbiAqIEFueXRoaW5nIGVsc2UgKHJhbmRvbSByZXBsaWVzIHVuZGVyIGEgdHJhY2tlZCBhY2NvdW50J3MgdHdlZXQsIHJhbmRvbVxuICogYXV0aG9ycyB0aGF0IGhhcHBlbiB0byBzdXJmYWNlIGluIGEgdHJhY2tlZCBhY2NvdW50J3MgdGhyZWFkKSBpcyBkcm9wcGVkLlxuICogUGFzcyBhbiBlbXB0eSBgdGFyZ2V0ZWRgIHNldCB0byBkaXNhYmxlIGZpbHRlcmluZyBlbnRpcmVseS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbHRlclJlbGF0ZWQoXG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSxcbiAgdGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4sXG4gIGNvcmVIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldCgpXG4pOiBDYW5vbmljYWxUd2VldFtdIHtcbiAgaWYgKHRhcmdldGVkLnNpemUgPT09IDAgJiYgY29yZUhhbmRsZXMuc2l6ZSA9PT0gMCkgcmV0dXJuIHR3ZWV0cztcbiAgLy8gRmlyc3QgcGFzczogd2hpY2ggdHdlZXQgSURzIGRvIHRyYWNrZWQtYXV0aG9yIHR3ZWV0cyByZWZlcmVuY2UgKHRoZVxuICAvLyBcImZvcndhcmRcIiBkaXJlY3Rpb24gXHUyMDE0IHRyYWNrZWQgYWNjb3VudCBxdW90ZXMgLyBSVHMgLyByZXBsaWVzIHRvIFgpP1xuICAvLyBBbmQgd2hpY2ggdHdlZXQgSURzIEFSRSB0cmFja2VkLWF1dGhvcmVkICh0aGUgXCJyZXZlcnNlXCIgZGlyZWN0aW9uIFx1MjAxNFxuICAvLyBYIHF1b3RlcyAvIFJUcyAvIHJlcGxpZXMgdG8gYSB0cmFja2VkIHR3ZWV0KT9cbiAgY29uc3QgcmVmZXJlbmNlZElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCB0YXJnZXRlZFR3ZWV0SWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICBpZiAoIXRhcmdldGVkLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSBjb250aW51ZTtcbiAgICB0YXJnZXRlZFR3ZWV0SWRzLmFkZCh0LnR3ZWV0X2lkKTtcbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucXVvdGVkX3R3ZWV0X2lkKTtcbiAgICBpZiAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucmV0d2VldGVkX3R3ZWV0X2lkKTtcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5yZXBseV90b190d2VldF9pZCk7XG4gIH1cbiAgcmV0dXJuIHR3ZWV0cy5maWx0ZXIoKHQpID0+IHtcbiAgICBjb25zdCBoID0gdC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmICh0YXJnZXRlZC5oYXMoaCkpIHJldHVybiB0cnVlO1xuICAgIGlmIChjb3JlSGFuZGxlcy5oYXMoaCkpIHJldHVybiB0cnVlO1xuICAgIC8vIEZvcndhcmQ6IGEgdHJhY2tlZC1hdXRob3IgdHdlZXQgcG9pbnRlZCBhdCB0aGlzIG9uZS5cbiAgICBpZiAocmVmZXJlbmNlZElkcy5oYXModC50d2VldF9pZCkpIHJldHVybiB0cnVlO1xuICAgIC8vIFJldmVyc2U6IHRoaXMgdHdlZXQgcXVvdGVzL3JlcGxpZXMgdG8gYSB0cmFja2VkLWF1dGhvciB0d2VldCBpbiB0aGVcbiAgICAvLyBiYXRjaC4gUmV2ZXJzZSByZXR3ZWV0cyBhcmUganVzdCBcIm5vbi1jb3JlIGFjY291bnQgcmV0d2VldGVkIGNvcmVcbiAgICAvLyB0d2VldFwiIHdyYXBwZXJzLCBhbmQgZG8gbm90IGFkZCBjb3JlIGFyY2hpdmUgdmFsdWUuXG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucXVvdGVkX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKHQucmVwbHlfdG9fdHdlZXRfaWQgJiYgdGFyZ2V0ZWRUd2VldElkcy5oYXModC5yZXBseV90b190d2VldF9pZCkpIHJldHVybiB0cnVlO1xuICAgIC8vIFJlcGx5LXRvLWFjY291bnQgb3IgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZS5cbiAgICBpZiAodC5yZXBseV90b19hY2NvdW50ICYmIHRhcmdldGVkLmhhcyh0LnJlcGx5X3RvX2FjY291bnQudG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xuICAgIGZvciAoY29uc3QgbSBvZiB0Lm1lbnRpb25zKSB7XG4gICAgICBpZiAodGFyZ2V0ZWQuaGFzKG0udG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH0pO1xufVxuXG4vKipcbiAqIFB1bGwgdGhlIENvbW11bml0eSBOb3RlIChmb3JtZXJseSBCaXJkd2F0Y2gpIGJsb2NrIGF0dGFjaGVkIHRvIGEgdHdlZXQsIGlmXG4gKiBhbnkuIFRoZSBwaXZvdCBjYW4gbGl2ZSBhdCBgdHdlZXQubGVnYWN5LmJpcmR3YXRjaF9waXZvdGAgKG9sZGVyIHNoYXBlKSBvclxuICogYHR3ZWV0LmJpcmR3YXRjaF9waXZvdGAgKGN1cnJlbnQgc2hhcGUpLiBUaGUgc3VtbWFyeSB0ZXh0IGlzIHdoYXQgcmVhZGVyc1xuICogYWN0dWFsbHkgc2VlOyB3ZSBrZWVwIHRoZSBzdXJyb3VuZGluZyBtZXRhZGF0YSBzbyBkb3duc3RyZWFtIHRvb2xpbmcgY2FuXG4gKiB0ZWxsIGRyYWZ0cyBhcGFydCBmcm9tIHJhdGVkLWhlbHBmdWwgbm90ZXMuXG4gKi9cbmZ1bmN0aW9uIGV4dHJhY3RDb21tdW5pdHlOb3RlKFxuICB0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAgb2JzZXJ2ZWRBdDogc3RyaW5nXG4pOiBDb21tdW5pdHlOb3RlIHwgbnVsbCB7XG4gIGNvbnN0IHBpdm90ID0gb2JqKHQuYmlyZHdhdGNoX3Bpdm90KSA/PyBvYmoobGVnYWN5LmJpcmR3YXRjaF9waXZvdCk7XG4gIGlmICghcGl2b3QpIHJldHVybiBudWxsO1xuICBjb25zdCBzdWJ0aXRsZSA9IG9iaihwaXZvdC5zdWJ0aXRsZSk7XG4gIGNvbnN0IG5vdGUgPSBvYmoocGl2b3Qubm90ZSk7XG4gIGNvbnN0IHN1bW1hcnkgPSBzdHJPck51bGwoc3VidGl0bGU/LnRleHQpO1xuICBjb25zdCB0aXRsZSA9IHN0ck9yTnVsbChwaXZvdC50aXRsZSk7XG4gIGNvbnN0IHNob3J0VGl0bGUgPSBzdHJPck51bGwocGl2b3Quc2hvcnRUaXRsZSk7XG4gIGNvbnN0IGRlc3RpbmF0aW9uVXJsID0gc3RyT3JOdWxsKHBpdm90LmRlc3RpbmF0aW9uVXJsKTtcbiAgY29uc3Qgbm90ZUlkID0gc3RyT3JOdWxsKHBpdm90Lm5vdGVJZCkgPz8gc3RyT3JOdWxsKG5vdGU/LnJlc3RfaWQpO1xuICAvLyBTa2lwIGVtcHR5IHNoZWxscyB0aGF0IGhhdmUgbm8gYWN0dWFsIGNvbnRlbnQuXG4gIGlmICghc3VtbWFyeSAmJiAhdGl0bGUgJiYgIW5vdGVJZCkgcmV0dXJuIG51bGw7XG4gIHJldHVybiB7XG4gICAgbm90ZV9pZDogbm90ZUlkLFxuICAgIHRpdGxlLFxuICAgIHNob3J0X3RpdGxlOiBzaG9ydFRpdGxlLFxuICAgIHN1bW1hcnksXG4gICAgZGVzdGluYXRpb25fdXJsOiBkZXN0aW5hdGlvblVybCxcbiAgICBvYnNlcnZlZF9hdDogb2JzZXJ2ZWRBdCxcbiAgfTtcbn1cblxuLyoqXG4gKiBQdWxsIGEgcGVyLWF1dGhvciBVc2VyU25hcHNob3QgZnJvbSB0aGUgdHdlZXQncyB1c2VyX3Jlc3VsdHMgbm9kZS4gRXZlcnlcbiAqIGZpZWxkIGRlZmF1bHRzIHRvIG51bGwgd2hlbiBtaXNzaW5nIHNvIHRoZSBzY2hlbWEgc3RheXMgc3RhYmxlIGFjcm9zc1xuICogdGhlIGxlZ2FjeSAvIGNvcmUgc2hhcGUgbWlncmF0aW9ucyBYIGhhcyBiZWVuIGRvaW5nLlxuICovXG5mdW5jdGlvbiBleHRyYWN0VXNlclNuYXBzaG90KFxuICB1c2VyUmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIHVzZXJDb3JlTmV3OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIHVzZXJMZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgdXNlckF2YXRhck9iajogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsXG4pOiBVc2VyU25hcHNob3Qge1xuICBjb25zdCB2ZXJpZmljYXRpb24gPSBvYmoodXNlclJlc3VsdD8udmVyaWZpY2F0aW9uKTtcbiAgcmV0dXJuIHtcbiAgICBkaXNwbGF5X25hbWU6XG4gICAgICBzdHJPck51bGwodXNlckNvcmVOZXc/Lm5hbWUpID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5uYW1lKSA/PyBzdHJPck51bGwodXNlclJlc3VsdD8ubmFtZSksXG4gICAgYXZhdGFyX3VybDpcbiAgICAgIHN0ck9yTnVsbCh1c2VyQXZhdGFyT2JqPy5pbWFnZV91cmwpID8/XG4gICAgICBzdHJPck51bGwodXNlckxlZ2FjeT8ucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMpID8/XG4gICAgICBzdHJPck51bGwodXNlclJlc3VsdD8ucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMpLFxuICAgIHZlcmlmaWVkOiBib29sT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWQpID8/IGJvb2xPck51bGwodXNlckxlZ2FjeT8udmVyaWZpZWQpLFxuICAgIGlzX2JsdWVfdmVyaWZpZWQ6IGJvb2xPck51bGwodXNlclJlc3VsdD8uaXNfYmx1ZV92ZXJpZmllZCksXG4gICAgdmVyaWZpZWRfdHlwZTogc3RyT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWRfdHlwZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnZlcmlmaWVkX3R5cGUpLFxuICAgIGRlc2NyaXB0aW9uOiBzdHJPck51bGwodXNlckxlZ2FjeT8uZGVzY3JpcHRpb24pLFxuICAgIGxvY2F0aW9uOiBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmxvY2F0aW9uKT8ubG9jYXRpb24pID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5sb2NhdGlvbiksXG4gICAgdXJsOiBzdHJPck51bGwodXNlckxlZ2FjeT8udXJsKSxcbiAgICBmb2xsb3dlcnNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5mb2xsb3dlcnNfY291bnQpLFxuICAgIGZyaWVuZHNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5mcmllbmRzX2NvdW50KSxcbiAgICBzdGF0dXNlc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LnN0YXR1c2VzX2NvdW50KSxcbiAgICBhY2NvdW50X2NyZWF0ZWRfYXQ6XG4gICAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8uY3JlYXRlZF9hdCkpID8/XG4gICAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5jcmVhdGVkX2F0KSksXG4gICAgcHJvdGVjdGVkOiBib29sT3JOdWxsKHVzZXJMZWdhY3k/LnByb3RlY3RlZCksXG4gIH07XG59XG5cbi8qKlxuICogV2FsayB0aGUgdHdlZXQncyBgY2FyZC5sZWdhY3kuYmluZGluZ192YWx1ZXNgIChrZXkvdmFsdWUgYXJyYXkpIGludG8gYVxuICogZmxhdCBUd2VldENhcmQgd2l0aCB0aXRsZSwgZGVzY3JpcHRpb24sIGFuZCBhIHJlcHJlc2VudGF0aXZlIGltYWdlIFVSTC5cbiAqIFJldHVybnMgbnVsbCB3aGVuIHRoZSB0d2VldCBoYXMgbm8gY2FyZC5cbiAqL1xuZnVuY3Rpb24gZXh0cmFjdENhcmQodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldENhcmQgfCBudWxsIHtcbiAgY29uc3QgY2FyZCA9IG9iaih0LmNhcmQpO1xuICBjb25zdCBjYXJkTGVnYWN5ID0gb2JqKGNhcmQ/LmxlZ2FjeSk7XG4gIGlmICghY2FyZExlZ2FjeSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGJpbmRpbmdzID0gY2FyZExlZ2FjeS5iaW5kaW5nX3ZhbHVlcztcbiAgY29uc3QgYnlLZXk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XG4gIGlmIChBcnJheS5pc0FycmF5KGJpbmRpbmdzKSkge1xuICAgIGZvciAoY29uc3QgYnYgb2YgYmluZGluZ3MpIHtcbiAgICAgIGlmICh0eXBlb2YgYnYgIT09ICdvYmplY3QnIHx8IGJ2ID09PSBudWxsKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IG8gPSBidiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGNvbnN0IGsgPSBzdHJPck51bGwoby5rZXkpO1xuICAgICAgY29uc3QgdiA9IG9iaihvLnZhbHVlKTtcbiAgICAgIGlmICghayB8fCAhdikgY29udGludWU7XG4gICAgICBieUtleVtrXSA9XG4gICAgICAgIHN0ck9yTnVsbCh2LnN0cmluZ192YWx1ZSkgPz9cbiAgICAgICAgc3RyT3JOdWxsKG9iaih2LmltYWdlX3ZhbHVlKT8udXJsKSA/P1xuICAgICAgICBzdHJPck51bGwob2JqKHYuaW1hZ2VfY29sb3JfdmFsdWUpPy5wYWxldHRlKTtcbiAgICB9XG4gIH1cbiAgY29uc3QgbmFtZSA9IHN0ck9yTnVsbChjYXJkTGVnYWN5Lm5hbWUpO1xuICBjb25zdCBjYXJkVXJsID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kudXJsKTtcbiAgY29uc3QgdmVuZG9yVXJsID1cbiAgICB0eXBlb2YgYnlLZXlbJ3Zhbml0eV91cmwnXSA9PT0gJ3N0cmluZycgPyAoYnlLZXlbJ3Zhbml0eV91cmwnXSBhcyBzdHJpbmcpIDogbnVsbDtcbiAgY29uc3QgdGl0bGUgPSB0eXBlb2YgYnlLZXlbJ3RpdGxlJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5Wyd0aXRsZSddIGFzIHN0cmluZykgOiBudWxsO1xuICBjb25zdCBkZXNjcmlwdGlvbiA9XG4gICAgdHlwZW9mIGJ5S2V5WydkZXNjcmlwdGlvbiddID09PSAnc3RyaW5nJyA/IChieUtleVsnZGVzY3JpcHRpb24nXSBhcyBzdHJpbmcpIDogbnVsbDtcbiAgY29uc3QgaW1hZ2VVcmwgPVxuICAgICh0eXBlb2YgYnlLZXlbJ3Bob3RvX2ltYWdlX2Z1bGxfc2l6ZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xuICAgICAgPyAoYnlLZXlbJ3Bob3RvX2ltYWdlX2Z1bGxfc2l6ZV9vcmlnaW5hbCddIGFzIHN0cmluZylcbiAgICAgIDogbnVsbCkgPz9cbiAgICAodHlwZW9mIGJ5S2V5Wyd0aHVtYm5haWxfaW1hZ2Vfb3JpZ2luYWwnXSA9PT0gJ3N0cmluZydcbiAgICAgID8gKGJ5S2V5Wyd0aHVtYm5haWxfaW1hZ2Vfb3JpZ2luYWwnXSBhcyBzdHJpbmcpXG4gICAgICA6IG51bGwpID8/XG4gICAgKHR5cGVvZiBieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xuICAgICAgPyAoYnlLZXlbJ3N1bW1hcnlfcGhvdG9faW1hZ2Vfb3JpZ2luYWwnXSBhcyBzdHJpbmcpXG4gICAgICA6IG51bGwpO1xuICBpZiAoIW5hbWUgJiYgIXRpdGxlICYmICFkZXNjcmlwdGlvbiAmJiAhaW1hZ2VVcmwpIHJldHVybiBudWxsO1xuICByZXR1cm4ge1xuICAgIG5hbWUsXG4gICAgY2FyZF91cmw6IGNhcmRVcmwsXG4gICAgdmVuZG9yX3VybDogdmVuZG9yVXJsLFxuICAgIHRpdGxlLFxuICAgIGRlc2NyaXB0aW9uLFxuICAgIGltYWdlX3VybDogaW1hZ2VVcmwsXG4gIH07XG59XG4iLCAiLyoqXG4gKiBMaWdodHdlaWdodCBVTElELWxpa2UgaWQgZ2VuZXJhdG9yOiAyNi1jaGFyYWN0ZXIgQ3JvY2tmb3JkIGJhc2UzMiBzdHJpbmdcbiAqIG9mICh0aW1lc3RhbXBfbXMgfHwgcmFuZG9tbmVzcykuIEdvb2QgZW5vdWdoIGZvciBydW4gaWRlbnRpZmllcnMgd2l0aG91dFxuICogcHVsbGluZyBpbiBhIHJlYWwgVUxJRCBkZXBlbmRlbmN5LlxuICovXG5cbmNvbnN0IEFMUEhBQkVUID0gJzAxMjM0NTY3ODlBQkNERUZHSEpLTU5QUVJTVFZXWFlaJzsgLy8gQ3JvY2tmb3JkXG5cbmV4cG9ydCBmdW5jdGlvbiBuZXdSdW5JZCgpOiBzdHJpbmcge1xuICBjb25zdCB0cyA9IERhdGUubm93KCk7XG4gIGxldCB0c1BhcnQgPSAnJztcbiAgbGV0IHQgPSB0cztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDsgaSsrKSB7XG4gICAgdHNQYXJ0ID0gKEFMUEhBQkVUW3QgJSAzMl0gPz8gJzAnKSArIHRzUGFydDtcbiAgICB0ID0gTWF0aC5mbG9vcih0IC8gMzIpO1xuICB9XG4gIGNvbnN0IHJhbmQgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEwKSk7XG4gIGxldCByYW5kUGFydCA9ICcnO1xuICBmb3IgKGNvbnN0IGIgb2YgcmFuZCkgcmFuZFBhcnQgKz0gQUxQSEFCRVRbYiAlIDMyXSA/PyAnMCc7XG4gIHJldHVybiB0c1BhcnQgKyByYW5kUGFydDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNob3J0UnVuSWQoaWQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBpZC5zbGljZSgtOCk7XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q2F0ZWdvcnksIEFjY291bnRDb25maWcgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBNaW5pbWFsIHBhcnNlciBmb3IgdGhlIHN0cmljdCBzaGFwZSB1c2VkIGJ5IGBjb25maWcvYWNjb3VudHMueWFtbGA6XG4gKlxuICogICBhY2NvdW50czpcbiAqICAgICAtIGhhbmRsZTogREhTZ292XG4gKiAgICAgICBsYWJlbDogRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eVxuICogICAgICAgY2F0ZWdvcnk6IGNvcmVcbiAqXG4gKiBXZSBkZWxpYmVyYXRlbHkgZG9uJ3QgcHVsbCBpbiBhIGZ1bGwgWUFNTCBsaWJyYXJ5IFx1MjAxNCB3ZSBjb250cm9sIGJvdGggZW5kcyBvZlxuICogdGhpcyBmaWxlLCBhbmQgYSBzbWFsbCBwYXJzZXIgaXMgZWFzaWVyIHRvIGF1ZGl0IHRoYW4gdGhlIGFsdGVybmF0aXZlcy5cbiAqIFVua25vd24ga2V5cyBhbmQgY29tbWVudHMgYXJlIHRvbGVyYXRlZDsgbWFsZm9ybWVkIGxpbmVzIGFyZSBza2lwcGVkLlxuICpcbiAqIEVudHJpZXMgbWlzc2luZyBhIGBjYXRlZ29yeWAgZGVmYXVsdCB0byBgY29yZWAgZm9yIGJhY2t3YXJkIGNvbXBhdGliaWxpdHlcbiAqIHdpdGggdGhlIHByZS1jYXRlZ29yaXphdGlvbiBmaWxlIHNoYXBlLlxuICovXG5jb25zdCBWQUxJRF9DQVRFR09SSUVTOiBSZWFkb25seVNldDxBY2NvdW50Q2F0ZWdvcnk+ID0gbmV3IFNldChbXG4gICdjb3JlJyxcbiAgJ2dvdmVybm1lbnQnLFxuICAnb2ZmaWNpYWxzJyxcbiAgJ3B1YmxpY19maWd1cmVzJyxcbiAgJ3B1YmxpYycsXG5dKTtcblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQWNjb3VudHNZYW1sKHRleHQ6IHN0cmluZyk6IEFjY291bnRDb25maWdbXSB7XG4gIGNvbnN0IGFjY291bnRzOiBBY2NvdW50Q29uZmlnW10gPSBbXTtcbiAgbGV0IGN1cnJlbnQ6IFBhcnRpYWw8QWNjb3VudENvbmZpZz4gPSB7fTtcbiAgbGV0IGluQWNjb3VudHMgPSBmYWxzZTtcbiAgY29uc3QgZmx1c2ggPSAoKSA9PiB7XG4gICAgaWYgKGN1cnJlbnQuaGFuZGxlICYmIGN1cnJlbnQubGFiZWwpIHtcbiAgICAgIGlmICghY3VycmVudC5jYXRlZ29yeSkgY3VycmVudC5jYXRlZ29yeSA9ICdjb3JlJztcbiAgICAgIGFjY291bnRzLnB1c2goY3VycmVudCBhcyBBY2NvdW50Q29uZmlnKTtcbiAgICB9XG4gIH07XG4gIGZvciAoY29uc3QgcmF3TGluZSBvZiB0ZXh0LnNwbGl0KCdcXG4nKSkge1xuICAgIGNvbnN0IGxpbmUgPSBzdHJpcENvbW1lbnRzKHJhd0xpbmUpO1xuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gJycpIGNvbnRpbnVlO1xuICAgIGlmICgvXmFjY291bnRzXFxzKjovLnRlc3QobGluZSkpIHtcbiAgICAgIGluQWNjb3VudHMgPSB0cnVlO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICghaW5BY2NvdW50cykgY29udGludWU7XG5cbiAgICBjb25zdCBpdGVtTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKi1cXHMqaGFuZGxlXFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoaXRlbU1hdGNoKSB7XG4gICAgICBmbHVzaCgpO1xuICAgICAgY3VycmVudCA9IHsgaGFuZGxlOiB1bnF1b3RlKGl0ZW1NYXRjaFsxXSA/PyAnJykgfTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBoYW5kbGVPbmx5ID0gbGluZS5tYXRjaCgvXlxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChoYW5kbGVPbmx5ICYmICFsaW5lLmluY2x1ZGVzKCctJykpIHtcbiAgICAgIGZsdXNoKCk7XG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaGFuZGxlT25seVsxXSA/PyAnJykgfTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBsYWJlbE1hdGNoID0gbGluZS5tYXRjaCgvXlxccypsYWJlbFxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGxhYmVsTWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcbiAgICAgIGN1cnJlbnQubGFiZWwgPSB1bnF1b3RlKGxhYmVsTWF0Y2hbMV0gPz8gJycpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IGNhdGVnb3J5TWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmNhdGVnb3J5XFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoY2F0ZWdvcnlNYXRjaCAmJiBjdXJyZW50LmhhbmRsZSkge1xuICAgICAgY29uc3QgcmF3ID0gdW5xdW90ZShjYXRlZ29yeU1hdGNoWzFdID8/ICcnKTtcbiAgICAgIGN1cnJlbnQuY2F0ZWdvcnkgPSBWQUxJRF9DQVRFR09SSUVTLmhhcyhyYXcgYXMgQWNjb3VudENhdGVnb3J5KVxuICAgICAgICA/IChyYXcgYXMgQWNjb3VudENhdGVnb3J5KVxuICAgICAgICA6ICdjb3JlJztcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgfVxuICBmbHVzaCgpO1xuICByZXR1cm4gYWNjb3VudHMuZmlsdGVyKChhKSA9PiBhLmhhbmRsZS5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gc3RyaXBDb21tZW50cyhsaW5lOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBOYWl2ZSBidXQgYWRlcXVhdGUgZm9yIG91ciBmb3JtYXQ6IHN0cmlwIGV2ZXJ5dGhpbmcgYWZ0ZXIgYSBgI2AgdGhhdCBpc24ndFxuICAvLyBpbnNpZGUgcXVvdGVzLiBPdXIgY29uZmlnIG5ldmVyIHVzZXMgaW5saW5lIHN0cmluZ3Mgd2l0aCBgI2AuXG4gIGNvbnN0IGlkeCA9IGxpbmUuaW5kZXhPZignIycpO1xuICByZXR1cm4gaWR4ID09PSAtMSA/IGxpbmUgOiBsaW5lLnNsaWNlKDAsIGlkeCk7XG59XG5cbmZ1bmN0aW9uIHVucXVvdGUoczogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgdHJpbW1lZCA9IHMudHJpbSgpO1xuICBpZiAoXG4gICAgKHRyaW1tZWQuc3RhcnRzV2l0aCgnXCInKSAmJiB0cmltbWVkLmVuZHNXaXRoKCdcIicpKSB8fFxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoXCInXCIpICYmIHRyaW1tZWQuZW5kc1dpdGgoXCInXCIpKVxuICApIHtcbiAgICByZXR1cm4gdHJpbW1lZC5zbGljZSgxLCAtMSk7XG4gIH1cbiAgcmV0dXJuIHRyaW1tZWQ7XG59XG4iLCAiLyoqXG4gKiBiYWNrZ3JvdW5kLnRzIFx1MjAxNCBleHRlbnNpb24gc2VydmljZSB3b3JrZXIuXG4gKlxuICogT3ducyB0aGUgY2FwdHVyZSBwaXBlbGluZTogcmVjZWl2ZXMgYGdyYXBocWwtY2FwdHVyZWAgbWVzc2FnZXMgZnJvbSB0aGVcbiAqIGNvbnRlbnQgc2NyaXB0LCBub3JtYWxpemVzIHRoZW0sIGFjY3VtdWxhdGVzIHBlci1oYW5kbGUgcnVuIGJ1ZmZlcnMgaW5cbiAqIGBicm93c2VyLnN0b3JhZ2UubG9jYWxgLCBhbmQgY29tbWl0cyB0aGVtIHRvIHRoZSBjb25maWd1cmVkIEdpdEh1YiByZXBvXG4gKiB2aWEgdGhlIEdpdCBEYXRhIEFQSS5cbiAqXG4gKiBTZXJ2aWNlIHdvcmtlcnMgaW4gTVYzIG1heSBiZSBldmljdGVkIGF0IGFueSB0aW1lLCBzbyBhbGwgY3JpdGljYWwgc3RhdGVcbiAqIGxpdmVzIGluIHN0b3JhZ2UgKG5ldmVyIG1vZHVsZS1zY29wZSkuIE9uIGV2ZXJ5IHdha2Ugd2UgcmUtZGVyaXZlIHdoYXQgd2VcbiAqIG5lZWQ7IHBlbmRpbmcgZmx1c2hlcyBhcmUgZHJpdmVuIGJ5IGBicm93c2VyLmFsYXJtc2AgcmF0aGVyIHRoYW4gdGltZXJzLlxuICovXG5cbmltcG9ydCB7XG4gIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gIEFVVE9fU0NST0xMX01JTl9TRUMsXG4gIEZBTExCQUNLX0FDQ09VTlRTLFxuICBGTFVTSF9BTEFSTV9NSU5VVEVTLFxuICBGTFVTSF9JRExFX01TLFxuICBGTFVTSF9UV0VFVF9USFJFU0hPTEQsXG4gIFBST0ZJTEVfRU5EUE9JTlRTLFxuICBUV0VFVF9FTkRQT0lOVFMsXG4gIFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TLFxufSBmcm9tICcuL2xpYi9jb25maWcuanMnO1xuaW1wb3J0IHsgR2l0SHViQ2xpZW50LCBHaXRIdWJFcnJvciwgdG9CYXNlNjQgfSBmcm9tICcuL2xpYi9naXRodWIuanMnO1xuaW1wb3J0IHsgZGVzY3JpYmVFcnJvciwgZXJyb3IgYXMgbG9nRXJyLCBpbmZvLCBzZXRCcm9hZGNhc3Rlciwgd2FybiB9IGZyb20gJy4vbGliL2xvZ2dlci5qcyc7XG5pbXBvcnQgeyBmaWx0ZXJSZWxhdGVkLCBub3JtYWxpemUgfSBmcm9tICcuL2xpYi9ub3JtYWxpemUuanMnO1xuaW1wb3J0IHsgbmV3UnVuSWQsIHNob3J0UnVuSWQgfSBmcm9tICcuL2xpYi9ydW5pZHMuanMnO1xuaW1wb3J0IHtcbiAgYnVtcENvdW50ZXIsXG4gIGNsZWFyQWN0aXZpdHksXG4gIGNsZWFyQWxsLFxuICBjbGVhclJ1bkJ1ZmZlcixcbiAgZGVxdWV1ZU1lZGlhQ3Jhd2wsXG4gIGRlcXVldWVSZWZldGNoLFxuICBlbmdhZ2VtZW50U2lnLFxuICBlbnF1ZXVlTWVkaWFDcmF3bCxcbiAgZW5xdWV1ZVJlZmV0Y2gsXG4gIGdldEFjY291bnRzLFxuICBnZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxuICBnZXRBY3Rpdml0eSxcbiAgZ2V0QXJjaGl2ZVNuYXBzaG90LFxuICBnZXRBdXRvU2Nyb2xsU2Vzc2lvbixcbiAgZ2V0Q29tbWl0dGVkSW5kZXgsXG4gIGdldENvbm5lY3Rpb24sXG4gIGdldENvdW50ZXJzLFxuICBnZXRNZWRpYUNyYXdsUXVldWUsXG4gIGdldE1lZGlhQ3Jhd2xTZXNzaW9uLFxuICBnZXRSZWZldGNoUXVldWUsXG4gIGdldFJlZmV0Y2hTZXNzaW9uLFxuICBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncyxcbiAgZ2V0UnVuQnVmZmVyLFxuICBnZXRSdW5CdWZmZXJzLFxuICBnZXRTZXR0aW5ncyxcbiAgaXNDb21taXR0ZWQsXG4gIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsLFxuICBuZXh0TWVkaWFDcmF3bFRhcmdldCxcbiAgbmV4dFJlZmV0Y2hUYXJnZXQsXG4gIHBydW5lQ29tbWl0dGVkSW5kZXgsXG4gIHB1cmdlVW5yZWxhdGVkU3RhdGUsXG4gIHJlZmV0Y2hRdWV1ZVRvdGFsLFxuICBwcmVwZW5kUmVjZW50VHdlZXRTaWdodGluZ3MsXG4gIHNldEFjY291bnRzLFxuICBzZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxuICBzZXRBcmNoaXZlU25hcHNob3QsXG4gIHNldEF1dG9TY3JvbGxTZXNzaW9uLFxuICBzZXRCdWZmZXJlZENvdW50LFxuICBzZXRDb21taXR0ZWRJbmRleCxcbiAgc2V0Q29ubmVjdGlvbixcbiAgc2V0TWVkaWFDcmF3bFNlc3Npb24sXG4gIHNldFJlZmV0Y2hTZXNzaW9uLFxuICBzZXRSdW5CdWZmZXIsXG4gIHR5cGUgUnVuQnVmZmVyLFxuICB1cGRhdGVTZXR0aW5ncyxcbn0gZnJvbSAnLi9saWIvc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDYXB0dXJlUGF5bG9hZCxcbiAgQXJjaGl2ZVNuYXBzaG90LFxuICBDb25uZWN0aW9uU3RhdGUsXG4gIEV4dGVuc2lvblN0YXRlLFxuICBMb2dFdmVudCxcbiAgUXVhcmFudGluZVBheWxvYWQsXG4gIFJ1bnRpbWVNZXNzYWdlLFxuICBTZWVuUGF5bG9hZCxcbiAgU2V0dGluZ3MsXG4gIFR3ZWV0U2lnaHRpbmcsXG4gIFVuYXZhaWxhYmxlVHdlZXQsXG59IGZyb20gJy4vbGliL3R5cGVzLmpzJztcbmltcG9ydCB7IHBhcnNlQWNjb3VudHNZYW1sIH0gZnJvbSAnLi9saWIveWFtbC5qcyc7XG5cbmNvbnN0IEVYVF9WRVJTSU9OID0gYnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbjtcbmNvbnN0IE1BTlVBTF9DQVBUVVJFX1dJTkRPV19NUyA9IDkwXzAwMDtcbmxldCBtYW51YWxDYXB0dXJlVW50aWxNcyA9IDA7XG5cbnNldEJyb2FkY2FzdGVyKChldjogTG9nRXZlbnQpID0+IHtcbiAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2xvZy1ldmVudCcsIGV2ZW50OiBldiB9KS5jYXRjaCgoKSA9PiB7fSk7XG59KTtcblxuZnVuY3Rpb24gYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk6IHZvaWQge1xuICBtYW51YWxDYXB0dXJlVW50aWxNcyA9IERhdGUubm93KCkgKyBNQU5VQUxfQ0FQVFVSRV9XSU5ET1dfTVM7XG59XG5cbi8vIC0tLSBXYWtlIGhhbmRsZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmJyb3dzZXIucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XG4gIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBpbnN0YWxsZWQnLCB7IHZlcnNpb246IEVYVF9WRVJTSU9OIH0pO1xuICBhd2FpdCBvbldha2UoJ2luc3RhbGwnKTtcbn0pO1xuXG5icm93c2VyLnJ1bnRpbWUub25TdGFydHVwLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgdm9pZCBvbldha2UoJ3N0YXJ0dXAnKTtcbn0pO1xuXG4vLyBGb3JjZSBhdCBsZWFzdCBvbmUgd2FrZSB0byByZWdpc3RlciBhbGFybXMgLyB2ZXJpZnkgY29ubmVjdGlvbi5cbnZvaWQgb25XYWtlKCdtb2R1bGUtbG9hZCcpO1xuXG5hc3luYyBmdW5jdGlvbiBvbldha2UocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBlbnN1cmVBbGFybXMoKTtcbiAgICBhd2FpdCBlbnN1cmVBdXRvU2Nyb2xsQWxhcm0oKTtcbiAgICBhd2FpdCBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTtcbiAgICBhd2FpdCByZWluamVjdEludG9PcGVuVGFicygpO1xuICAgIC8vIERyb3AgZGVkdXAtaW5kZXggZW50cmllcyBvbGRlciB0aGFuIDMwIGRheXMgc28gdGhlIHN0b3JlIGRvZXNuJ3RcbiAgICAvLyBncm93IHVuYm91bmRlZCBvdmVyIG1vbnRocyBvZiBjYXB0dXJlIHNlc3Npb25zLlxuICAgIGNvbnN0IHBydW5lZCA9IGF3YWl0IHBydW5lQ29tbWl0dGVkSW5kZXgoMzAgKiAyNCAqIDYwICogNjAgKiAxMDAwKTtcbiAgICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgaW5mbygncHJ1bmVkIGNvbW1pdHRlZCBpbmRleCcsIHsgcHJ1bmVkIH0pO1xuICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgICBpZiAoc2V0dGluZ3MucGF0ICYmIHNldHRpbmdzLm93bmVyICYmIHNldHRpbmdzLnJlcG8pIHtcbiAgICAgIGF3YWl0IHZlcmlmeUNvbm5lY3Rpb24oZmFsc2UpO1xuICAgICAgYXdhaXQgcmVmcmVzaEFjY291bnRzTGlzdChmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXM6ICdub3QtY29uZmlndXJlZCcsXG4gICAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBhd2FrZTsgc2V0dGluZ3MgaW5jb21wbGV0ZScsIHsgcmVhc29uIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgbG9nRXJyKCd3YWtlIGZhaWxlZCcsIHsgcmVhc29uLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIH1cbn1cblxuLyoqXG4gKiBSZS1pbmplY3QgdGhlIE1BSU4td29ybGQgcGFnZS1ob29rICsgaXNvbGF0ZWQtd29ybGQgY29udGVudCBzY3JpcHQgaW50b1xuICogZXZlcnkgYWxyZWFkeS1vcGVuIHguY29tIC8gdHdpdHRlci5jb20gdGFiLlxuICpcbiAqIE1hbmlmZXN0IGNvbnRlbnRfc2NyaXB0cyBvbmx5IGluamVjdCBvbiBmcmVzaCBuYXZpZ2F0aW9uIChydW5fYXQ6XG4gKiBkb2N1bWVudF9zdGFydCkuIFdoZW4gdGhlIHVzZXIgcmVsb2FkcyB0aGUgZXh0ZW5zaW9uIHdoaWxlIFggdGFicyBhcmVcbiAqIG9wZW4sIHRob3NlIHRhYnMga2VlcCB0aGVpciBjb250ZW50IHNjcmlwdHMgYnV0IG5ldmVyIGdldCBhIG5ldyBwYWdlLWhvb2tcbiAqIFx1MjAxNCBzbyBmZXRjaC9YSFIgc3RheXMgdW5wYXRjaGVkIGFuZCBjYXB0dXJlcyBzaWxlbnRseSBmYWlsLiBEb2luZyB0aGlzIG9uXG4gKiBldmVyeSB3YWtlIGlzIGlkZW1wb3RlbnQgKHBhZ2UtaG9vayBoYXMgYSBUQUcgZ3VhcmQpIGFuZCBjaGVhcC5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gcmVpbmplY3RJbnRvT3BlblRhYnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XG4gIHRyeSB7XG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NvdWxkIG5vdCBxdWVyeSBvcGVuIHRhYnMnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodGFicy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgZm9yIChjb25zdCB0YWIgb2YgdGFicykge1xuICAgIGlmICh0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJykgY29udGludWU7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICBmaWxlczogWydwYWdlLWhvb2suanMnXSxcbiAgICAgICAgLy8gRmlyZWZveCAxMjgrIHN1cHBvcnRzIHRoZSBNQUlOIGV4ZWN1dGlvbiB3b3JsZCB2aWEgdGhpcyBBUEksIGJ1dFxuICAgICAgICAvLyB0aGUgQHR5cGVzL2ZpcmVmb3gtd2ViZXh0LWJyb3dzZXIgcGFja2FnZSB3ZSdyZSBvbiBzdGlsbCBvbmx5XG4gICAgICAgIC8vIGRlY2xhcmVzICdJU09MQVRFRCcuIENhc3QgdGhyb3VnaCB0aGUgbGl0ZXJhbCB1bmlvbi5cbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgZmlsZXM6IFsnY29udGVudC5qcyddLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBpbmZvKCdyZS1pbmplY3RlZCBzY3JpcHRzIGludG8gb3BlbiB0YWInLCB7XG4gICAgICAgIHRhYklkOiB0YWIuaWQsXG4gICAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsID8/ICcnKSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgLy8gU29tZSB0YWJzIChhYm91dDogcGFnZXMsIGRpc2NhcmRlZCB0YWJzLCBtaWQtbmF2aWdhdGlvbikgcmVqZWN0XG4gICAgICAvLyBleGVjdXRlU2NyaXB0LiBUaGF0J3MgZmluZSBcdTIwMTQgd2UnbGwgY2F0Y2ggdGhlbSBvbiB0aGUgbmV4dCB3YWtlIG9yXG4gICAgICAvLyB3aGVuIHRoZSB1c2VyIG5hdmlnYXRlcy5cbiAgICAgIGF3YWl0IHdhcm4oJ3JlLWluamVjdCBmYWlsZWQgZm9yIHRhYjsgY29udGludWluZycsIHtcbiAgICAgICAgdGFiSWQ6IHRhYi5pZCxcbiAgICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwgPz8gJycpLFxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQWxhcm1zKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignZmx1c2gtc3dlZXAnKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3ZlcmlmeS1jb25uZWN0aW9uJyk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgnZmx1c2gtc3dlZXAnLCB7IHBlcmlvZEluTWludXRlczogRkxVU0hfQUxBUk1fTUlOVVRFUyB9KTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY3JlYXRlKCd2ZXJpZnktY29ubmVjdGlvbicsIHtcbiAgICBwZXJpb2RJbk1pbnV0ZXM6IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TIC8gNjBfMDAwLFxuICB9KTtcbn1cblxuLy8gRmlyZWZveCBNVjMgYWxhcm1zIGhhdmUgYSAzMHMgbWluaW11bSBwZXJpb2QsIGJ1dCB3ZSB3YW50IHN1Yi1taW51dGVcbi8vIHNjcm9sbGluZy4gVGhlIGF1dG8tc2Nyb2xsIGxvb3AgdGhlcmVmb3JlIHJ1bnMgb24gYW4gaW4tU1cgaW50ZXJ2YWwuXG4vLyBgYXV0b1Njcm9sbFNlc3Npb25gIGluIHN0b3JhZ2UgaXMgdGhlIHNvdXJjZSBvZiB0cnV0aCBmb3Igd2hldGhlciB0aGUgbG9vcFxuLy8gaXMgbWVhbnQgdG8gYmUgcnVubmluZyBcdTIwMTQgdGhlIHRpbWVyIGlzIGp1c3QgdGhlIGxvY2FsIGV4ZWN1dGlvbiBhcm0uXG5sZXQgYXV0b1Njcm9sbFRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcblxuLy8gV2FpdC1mb3ItaW5nZXN0IHRpbWVvdXQ6IGlmIGEgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHRhYiBuYXZpZ2F0aW9uIGRvZXNuJ3Rcbi8vIHByb2R1Y2UgYW4gaW5nZXN0ZWQgY2FwdHVyZSB3aXRoaW4gdGhpcyBtYW55IG1zLCBhZHZhbmNlIGFueXdheSBzbyB3ZVxuLy8gZG9uJ3QgZGVhZGxvY2sgb24gZGVsZXRlZCAvIDQwNCAvIHBheXdhbGxlZCB0d2VldHMuXG5jb25zdCBJTkdFU1RfV0FJVF9NUyA9IDI1XzAwMDtcblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQXV0b1Njcm9sbEFsYXJtKCk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBXYXMgdGhlIGxvb3AgcnVubmluZyBiZWZvcmUgdGhlIFNXIGV2aWN0aW9uPyBSZS1hcm0gaWYgc28uXG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKHNlc3MgIT09IG51bGwgJiYgcy5lbmFibGVkICE9PSBmYWxzZSkge1xuICAgIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XG4gIH0gZWxzZSB7XG4gICAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBjbGVhckF1dG9TY3JvbGxUaW1lcigpOiB2b2lkIHtcbiAgaWYgKGF1dG9TY3JvbGxUaW1lciAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwoYXV0b1Njcm9sbFRpbWVyKTtcbiAgICBhdXRvU2Nyb2xsVGltZXIgPSBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIGFybUF1dG9TY3JvbGxUaW1lcihpbnRlcnZhbFNlYzogbnVtYmVyKTogdm9pZCB7XG4gIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gIGNvbnN0IGNsYW1wZWQgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQoaW50ZXJ2YWxTZWMpKVxuICApO1xuICBhdXRvU2Nyb2xsVGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgdm9pZCBhdXRvU2Nyb2xsVGljaygpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybignYXV0by1zY3JvbGwgdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIH0pO1xuICB9LCBjbGFtcGVkICogMTAwMCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0QXV0b1Njcm9sbExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGFsbG93TWFudWFsQ2FwdHVyZVdpbmRvdygpO1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oe1xuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNjcm9sbENvdW50OiAwLFxuICAgIGluZ2VzdGVkQ291bnQ6IDAsXG4gICAgaW5nZXN0ZWROZXdDb3VudDogMCxcbiAgICBpbmdlc3RlZEV4aXN0aW5nQ291bnQ6IDAsXG4gICAgc2tpcHBlZE9sZENvdW50OiAwLFxuICAgIGV4cGFuZGVkQ291bnQ6IDAsXG4gIH0pO1xuICBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xuICBhd2FpdCBpbmZvKCdhdXRvLXNjcm9sbCBsb29wIHN0YXJ0ZWQnLCB7IGludGVydmFsX3NlYzogcy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMgfSk7XG4gIC8vIEZpcmUgb25lIGltbWVkaWF0ZSB0aWNrIHNvIHRoZSB1c2VyIHNlZXMgbW90aW9uIHJpZ2h0IGF3YXkuXG4gIHZvaWQgYXV0b1Njcm9sbFRpY2soKTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsQXV0b1Njcm9sbExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihudWxsKTtcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBjYW5jZWxsZWQnLCB7XG4gICAgc2Nyb2xsczogc2Vzcz8uc2Nyb2xsQ291bnQgPz8gMCxcbiAgICBpbmdlc3RlZDogc2Vzcz8uaW5nZXN0ZWRDb3VudCA/PyAwLFxuICAgIGV4cGFuZGVkOiBzZXNzPy5leHBhbmRlZENvdW50ID8/IDAsXG4gIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBhdXRvU2Nyb2xsVGljaygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcbiAgdHJ5IHtcbiAgICB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignYXV0by1zY3JvbGw6IHRhYiBxdWVyeSBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodGFicy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgbGV0IHNjcm9sbENvdW50ID0gMDtcbiAgbGV0IGV4cGFuZGVkQ291bnQgPSAwO1xuICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XG4gICAgaWYgKHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInKSBjb250aW51ZTtcbiAgICBpZiAodGFiLmRpc2NhcmRlZCkgY29udGludWU7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdHMgPSAoYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgICAgLy8gQ2FzdDogdGhlIEB0eXBlcy9maXJlZm94LXdlYmV4dC1icm93c2VyIHR5cGUgc2lnbmF0dXJlIGluc2lzdHNcbiAgICAgICAgLy8gYGZ1bmNgIHJldHVybnMgdm9pZCwgYnV0IHRoZSBBUEkgYWN0dWFsbHkgc3VyZmFjZXMgdGhlIHJldHVyblxuICAgICAgICAvLyB2YWx1ZSB2aWEgYHJlc3VsdFswXS5yZXN1bHRgLiBXZSB1c2UgdGhhdCBmb3IgdGhlIGV4cGFuZCBjb3VudC5cbiAgICAgICAgZnVuYzogKCgpID0+IHtcbiAgICAgICAgICAvLyAxLiBDbGljayBhbnkgdmlzaWJsZSBcIlNob3cgbW9yZVwiIGxpbmtzIGluIGxvbmctdHdlZXQgYm9kaWVzIHNvIFhcbiAgICAgICAgICAvLyAgICBpbmxpbmVzIHRoZSBub3RlX3R3ZWV0IGJvZHkgYW5kIG91ciBwYWdlLWhvb2sgY2FwdHVyZXMgdGhlXG4gICAgICAgICAgLy8gICAgZnVsbCB0ZXh0IHdpdGhvdXQgdGhlIHJlZmV0Y2ggZGV0b3VyLiBUcnkgc2V2ZXJhbCBzZWxlY3RvcnNcbiAgICAgICAgICAvLyAgICBiZWNhdXNlIFggcm90YXRlcyB0aGUgdGVzdGlkIGxhYmVsIHNlbWktcmVndWxhcmx5LlxuICAgICAgICAgIGNvbnN0IFNIT1dfTU9SRV9TRUxFQ1RPUlMgPSBbXG4gICAgICAgICAgICAnW2RhdGEtdGVzdGlkPVwidHdlZXQtdGV4dC1zaG93LW1vcmUtbGlua1wiXScsXG4gICAgICAgICAgICAnYnV0dG9uW2RhdGEtdGVzdGlkPVwidHdlZXQtdGV4dC1zaG93LW1vcmUtbGlua1wiXScsXG4gICAgICAgICAgICAnZGl2W2RhdGEtdGVzdGlkPVwiY2VsbElubmVyRGl2XCJdIFtyb2xlPVwiYnV0dG9uXCJdW3RhYmluZGV4PVwiMFwiXScsXG4gICAgICAgICAgXTtcbiAgICAgICAgICBjb25zdCBjbGlja2VkID0gbmV3IFNldDxFbGVtZW50PigpO1xuICAgICAgICAgIGxldCBleHBhbmRlZCA9IDA7XG4gICAgICAgICAgZm9yIChjb25zdCBzZWwgb2YgU0hPV19NT1JFX1NFTEVDVE9SUykge1xuICAgICAgICAgICAgZm9yIChjb25zdCBlbCBvZiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsKSkpIHtcbiAgICAgICAgICAgICAgaWYgKGNsaWNrZWQuaGFzKGVsKSkgY29udGludWU7XG4gICAgICAgICAgICAgIC8vIENvbmZpcm0gaXQncyBhY3R1YWxseSB0aGUgc2hvdy1tb3JlIGFmZm9yZGFuY2UgYnkgdGV4dC5cbiAgICAgICAgICAgICAgY29uc3QgdCA9IChlbC50ZXh0Q29udGVudCB8fCAnJykudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICAgIGlmICh0ICE9PSAnc2hvdyBtb3JlJyAmJiB0ICE9PSAnc2hvdyB0aGlzIHRocmVhZCcpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICBjb25zdCByZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgICAgICAgIGlmIChyZWN0LndpZHRoID09PSAwIHx8IHJlY3QuaGVpZ2h0ID09PSAwKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgY2xpY2tlZC5hZGQoZWwpO1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIChlbCBhcyBIVE1MRWxlbWVudCkuY2xpY2soKTtcbiAgICAgICAgICAgICAgICBleHBhbmRlZCArPSAxO1xuICAgICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICAvLyBpZ25vcmVcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICAvLyAyLiBTY3JvbGwgdGhlIHBhZ2UuIERpc3BhdGNoIEVuZCBrZXkgZmlyc3Qgc2luY2UgbWFueSBYIHN1cmZhY2VzXG4gICAgICAgICAgLy8gICAgKGxpc3RzLCBzZWFyY2gsIHJlcGxpZXMpIGJpbmQgcGFnaW5hdGlvbiB0cmlnZ2VycyB0byBpdCB2aWFcbiAgICAgICAgICAvLyAgICBSZWFjdCBoYW5kbGVyczsgdGhlbiBleHBsaWNpdGx5IHNjcm9sbCB0aGUgZG9jdW1lbnQuXG4gICAgICAgICAgY29uc3Qgb3B0czogS2V5Ym9hcmRFdmVudEluaXQgPSB7XG4gICAgICAgICAgICBrZXk6ICdFbmQnLFxuICAgICAgICAgICAgY29kZTogJ0VuZCcsXG4gICAgICAgICAgICBrZXlDb2RlOiAzNSxcbiAgICAgICAgICAgIHdoaWNoOiAzNSxcbiAgICAgICAgICAgIGJ1YmJsZXM6IHRydWUsXG4gICAgICAgICAgICBjYW5jZWxhYmxlOiB0cnVlLFxuICAgICAgICAgIH07XG4gICAgICAgICAgY29uc3QgZm9jdXMgPSAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCB8IG51bGwpID8/IGRvY3VtZW50LmJvZHk7XG4gICAgICAgICAgZm9jdXMuZGlzcGF0Y2hFdmVudChuZXcgS2V5Ym9hcmRFdmVudCgna2V5ZG93bicsIG9wdHMpKTtcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXl1cCcsIG9wdHMpKTtcbiAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oe1xuICAgICAgICAgICAgdG9wOiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsSGVpZ2h0LFxuICAgICAgICAgICAgYmVoYXZpb3I6ICdhdXRvJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4geyBleHBhbmRlZCB9O1xuICAgICAgICB9KSBhcyAoKSA9PiB2b2lkLFxuICAgICAgfSkpIGFzIEFycmF5PHsgcmVzdWx0PzogdW5rbm93biB9PjtcbiAgICAgIHNjcm9sbENvdW50ICs9IDE7XG4gICAgICBjb25zdCByID0gcmVzdWx0c1swXT8ucmVzdWx0IGFzIHsgZXhwYW5kZWQ/OiBudW1iZXIgfSB8IHVuZGVmaW5lZDtcbiAgICAgIGlmIChyICYmIHR5cGVvZiByLmV4cGFuZGVkID09PSAnbnVtYmVyJykgZXhwYW5kZWRDb3VudCArPSByLmV4cGFuZGVkO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gVGFicyB0aGF0IGRpc2FsbG93IHNjcmlwdGluZyAoYWJvdXQ6LCBkaXNjYXJkZWQsIG1pZC1uYXZpZ2F0aW9uKVxuICAgICAgLy8ganVzdCBnZXQgc2tpcHBlZCBcdTIwMTQgdGhleSdsbCBiZSBlbGlnaWJsZSBvbiBhIGxhdGVyIHRpY2suXG4gICAgfVxuICB9XG4gIGlmIChzY3JvbGxDb3VudCA+IDApIHtcbiAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICBpZiAoc2VzcyAhPT0gbnVsbCkge1xuICAgICAgc2Vzcy5zY3JvbGxDb3VudCArPSBzY3JvbGxDb3VudDtcbiAgICAgIHNlc3MuZXhwYW5kZWRDb3VudCArPSBleHBhbmRlZENvdW50O1xuICAgICAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oc2Vzcyk7XG4gICAgICAvLyBObyBicm9hZGNhc3Qgb24gZXZlcnkgdGljayBcdTIwMTQgdGhlIDE1cyBzaWRlYmFyIHJlZnJlc2ggcGlja3MgaXQgdXAuXG4gICAgfVxuICB9XG59XG5cbmJyb3dzZXIuYWxhcm1zLm9uQWxhcm0uYWRkTGlzdGVuZXIoKGFsYXJtKSA9PiB7XG4gIGlmIChhbGFybS5uYW1lID09PSAnZmx1c2gtc3dlZXAnKSB7XG4gICAgdm9pZCBmbHVzaElkbGVCdWZmZXJzKCk7XG4gIH0gZWxzZSBpZiAoYWxhcm0ubmFtZSA9PT0gJ3ZlcmlmeS1jb25uZWN0aW9uJykge1xuICAgIHZvaWQgdmVyaWZ5Q29ubmVjdGlvbihmYWxzZSk7XG4gIH1cbiAgLy8gcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHByZXZpb3VzbHkgcmFuIHZpYSBhbGFybXM7IHRoZXkgbm93IHVzZVxuICAvLyBzZXRJbnRlcnZhbCB0byBlc2NhcGUgdGhlIDMwcyBhbGFybSBmbG9vci4gTGVhdmUgdGhlIG5hbWVzIGxpc3RlZFxuICAvLyBub3doZXJlIHNvIGFueSBvcnBoYW5lZCBhbGFybXMgKGZyb20gb2xkZXIgYnVpbGRzKSBqdXN0IG5vLW9wLlxufSk7XG5cbi8vIC0tLSBUb29sYmFyIGFjdGlvbjogdG9nZ2xlIHRoZSBzaWRlYmFyIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmlmIChicm93c2VyLmFjdGlvbj8ub25DbGlja2VkKSB7XG4gIGJyb3dzZXIuYWN0aW9uLm9uQ2xpY2tlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2lkZWJhckFjdGlvbi50b2dnbGUoKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIC8vIEZhbGxiYWNrOiBvcGVuIG9wdGlvbnMgaWYgc2lkZWJhciBjYW4ndCBiZSB0b2dnbGVkLlxuICAgICAgYXdhaXQgd2Fybignc2lkZWJhciB0b2dnbGUgZmFpbGVkOyBvcGVuaW5nIG9wdGlvbnMnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgICAgYXdhaXQgYnJvd3Nlci5ydW50aW1lLm9wZW5PcHRpb25zUGFnZSgpO1xuICAgIH1cbiAgfSk7XG59XG5cbi8vIC0tLSBSdW50aW1lIG1lc3NhZ2UgZGlzcGF0Y2ggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiB1bmtub3duLCBfc2VuZGVyKSA9PiB7XG4gIGlmICghaXNSdW50aW1lTWVzc2FnZShtc2cpKSByZXR1cm4gdW5kZWZpbmVkO1xuICByZXR1cm4gaGFuZGxlTWVzc2FnZShtc2cpLmNhdGNoKChlcnIpID0+IHtcbiAgICB2b2lkIGxvZ0VycignbWVzc2FnZSBoYW5kbGVyIGZhaWxlZCcsIHsgdHlwZTogbXNnLnR5cGUsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgICB0aHJvdyBlcnI7XG4gIH0pO1xufSk7XG5cbmZ1bmN0aW9uIGlzUnVudGltZU1lc3NhZ2UobTogdW5rbm93bik6IG0gaXMgUnVudGltZU1lc3NhZ2Uge1xuICByZXR1cm4gISFtICYmIHR5cGVvZiBtID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgKG0gYXMgeyB0eXBlPzogdW5rbm93biB9KS50eXBlID09PSAnc3RyaW5nJztcbn1cblxuLyoqIE1lc3NhZ2VzIHRoYXQgZHJpdmUgdGhlIGNhcHR1cmUgcGlwZWxpbmUuIFdoZW4gdGhlIG1hc3RlciBzd2l0Y2ggaXMgT0ZGXG4gKiB3ZSBpZ25vcmUgdGhlc2UgYnV0IHN0aWxsIHJlc3BvbmQgdG8gc3RhdHVzIC8gY29uZmlndXJhdGlvbiBxdWVyaWVzLiAqL1xuY29uc3QgQ0FQVFVSRV9QSVBFTElORV9NRVNTQUdFUyA9IG5ldyBTZXQ8UnVudGltZU1lc3NhZ2VbJ3R5cGUnXT4oW1xuICAnZ3JhcGhxbC1jYXB0dXJlJyxcbiAgJ2NhcHR1cmUtbm93JyxcbiAgJ2NhcHR1cmUtYWxsJyxcbiAgJ2NhcHR1cmUtdGhpcy1wYWdlJyxcbiAgJ2ZsdXNoLWFsbCcsXG4gICdmbHVzaC1oYW5kbGUnLFxuICAnc3RhcnQtcmVmZXRjaCcsXG4gICdzdGFydC1tZWRpYS1jcmF3bCcsXG4gICdzdGFydC1hdXRvLXNjcm9sbCcsXG5dKTtcblxuYXN5bmMgZnVuY3Rpb24gaXNFbmFibGVkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgcmV0dXJuIHMuZW5hYmxlZCAhPT0gZmFsc2U7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UobXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8dW5rbm93bj4ge1xuICAvLyBNYXN0ZXIgc3dpdGNoOiB3aGVuIHRoZSB1c2VyIGhhcyBwYXVzZWQgdGhlIGV4dGVuc2lvbiB3ZSBzdGlsbCBuZWVkXG4gIC8vIHRoZSBtZXRhLWNoYW5uZWxzIChnZXQtc3RhdGUsIHRvZ2dsZS1lbmFibGVkLCBvcGVuLW9wdGlvbnMsIFx1MjAyNikgc28gdGhlXG4gIC8vIHNpZGViYXIgc3RheXMgZnVuY3Rpb25hbCwgYnV0IGFueXRoaW5nIHRoYXQgd291bGQgYWN0dWFsbHkgY2FwdHVyZSxcbiAgLy8gY29tbWl0LCBvciBkcml2ZSBhIHRhYiBpcyBhIG5vLW9wLlxuICBpZiAoIShhd2FpdCBpc0VuYWJsZWQoKSkgJiYgQ0FQVFVSRV9QSVBFTElORV9NRVNTQUdFUy5oYXMobXNnLnR5cGUpKSB7XG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHBhdXNlZDogdHJ1ZSB9O1xuICB9XG4gIHN3aXRjaCAobXNnLnR5cGUpIHtcbiAgICBjYXNlICdncmFwaHFsLWNhcHR1cmUnOlxuICAgICAgYXdhaXQgb25HcmFwaHFsQ2FwdHVyZShtc2cuZW5kcG9pbnQsIG1zZy51cmwsIG1zZy5wYWdlVXJsID8/IG51bGwsIG1zZy5yZXNwb25zZSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2NvbnRlbnQtYWxpdmUnOlxuICAgICAgYXdhaXQgaW5mbygnY29udGVudCBzY3JpcHQgYWxpdmUgb24gcGFnZScsIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdwYWdlLWhvb2stYWN0aXZlJzpcbiAgICAgIGF3YWl0IGluZm8oJ3BhZ2UgaG9vayBwYXRjaGVkIGZldGNoL1hIUicsIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdsb2ctY29udGVudC1ldmVudCc6XG4gICAgICBpZiAobXNnLmxldmVsID09PSAnd2FybicpIHtcbiAgICAgICAgYXdhaXQgd2Fybihtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH0gZWxzZSBpZiAobXNnLmxldmVsID09PSAnZXJyb3InKSB7XG4gICAgICAgIGF3YWl0IGxvZ0Vycihtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGF3YWl0IGluZm8obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2dldC1zdGF0ZSc6XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhcHR1cmUtbm93JzpcbiAgICAgIGF3YWl0IGNhcHR1cmVOb3cobXNnLmhhbmRsZSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhcHR1cmUtYWxsJzpcbiAgICAgIGF3YWl0IGNhcHR1cmVBbGwoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS10aGlzLXBhZ2UnOlxuICAgICAgYXdhaXQgY2FwdHVyZVRoaXNQYWdlKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2ZsdXNoLWFsbCc6XG4gICAgICBhd2FpdCBmbHVzaEFsbCgndXNlcicpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdmbHVzaC1oYW5kbGUnOlxuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUobXNnLmhhbmRsZSwgJ3VzZXInKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAndG9nZ2xlLWF1dG8tY2FwdHVyZSc6XG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGF1dG9DYXB0dXJlOiBtc2cub24gfSk7XG4gICAgICBhd2FpdCBpbmZvKCdhdXRvLWNhcHR1cmUgdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAndG9nZ2xlLXVwZGF0ZS1leGlzdGluZyc6XG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IHVwZGF0ZUV4aXN0aW5nOiBtc2cub24gfSk7XG4gICAgICBhd2FpdCBpbmZvKCd1cGRhdGUtZXhpc3RpbmcgdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAndG9nZ2xlLWVuYWJsZWQnOiB7XG4gICAgICBjb25zdCBzID0gYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBlbmFibGVkOiBtc2cub24gfSk7XG4gICAgICBpZiAoIW1zZy5vbikge1xuICAgICAgICAvLyBQYXVzaW5nIHN0b3BzIGFsbCBpbi1mbGlnaHQgbG9vcHMgc28gdGhlIHVzZXIgZ2V0cyBpbW1lZGlhdGVcbiAgICAgICAgLy8gcXVpZXQsIG5vdCBhIFwib25lIG1vcmUgdGlja1wiIHN1cnByaXNlLlxuICAgICAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICAgICAgICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gICAgICAgIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTtcbiAgICAgICAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignbWVkaWEtY3Jhd2wtdGljaycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gUmVzdW1pbmcgcmUtYXJtcyBhbnkgbG9vcHMgd2hvc2Ugc2Vzc2lvbiBpcyBzdGlsbCBzZXQuXG4gICAgICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBtYXN0ZXIgc3dpdGNoIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIH1cbiAgICBjYXNlICdzdGFydC1hdXRvLXNjcm9sbCc6XG4gICAgICBhd2FpdCBzdGFydEF1dG9TY3JvbGxMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1hdXRvLXNjcm9sbCc6XG4gICAgICBhd2FpdCBjYW5jZWxBdXRvU2Nyb2xsTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdzZXQtYXV0by1zY3JvbGwtaW50ZXJ2YWwnOiB7XG4gICAgICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXG4gICAgICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQobXNnLnNlY29uZHMpKVxuICAgICAgKTtcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzZWNvbmRzIH0pO1xuICAgICAgLy8gUmUtYXJtIGFueSBhY3RpdmUgbG9vcHMgd2l0aCB0aGUgbmV3IGludGVydmFsLlxuICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHNlY29uZHMpO1xuICAgICAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kcyk7XG4gICAgICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgfVxuICAgIGNhc2UgJ3N0YXJ0LXJlZmV0Y2gnOlxuICAgICAgYXdhaXQgc3RhcnRSZWZldGNoTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYW5jZWwtcmVmZXRjaCc6XG4gICAgICBhd2FpdCBjYW5jZWxSZWZldGNoTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdzdGFydC1tZWRpYS1jcmF3bCc6XG4gICAgICBhd2FpdCBzdGFydE1lZGlhQ3Jhd2xMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1tZWRpYS1jcmF3bCc6XG4gICAgICBhd2FpdCBjYW5jZWxNZWRpYUNyYXdsTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdwdXJnZS11bnJlbGF0ZWQnOiB7XG4gICAgICBjb25zdCBhY2NzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgICAgIGNvbnN0IHRyYWNrZWQgPSBuZXcgU2V0KGFjY3MubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKSk7XG4gICAgICBjb25zdCBzdW1tYXJ5ID0gYXdhaXQgcHVyZ2VVbnJlbGF0ZWRTdGF0ZSh0cmFja2VkKTtcbiAgICAgIGF3YWl0IGluZm8oJ3B1cmdlZCB1bnJlbGF0ZWQgc3RhdGUnLCBzdW1tYXJ5KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgfVxuICAgIGNhc2UgJ3JlZnJlc2gtYWNjb3VudHMnOlxuICAgICAgYXdhaXQgcmVmcmVzaEFjY291bnRzTGlzdCh0cnVlKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAndmVyaWZ5LWNvbm5lY3Rpb24nOlxuICAgICAgYXdhaXQgdmVyaWZ5Q29ubmVjdGlvbih0cnVlKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2xlYXItYWN0aXZpdHknOlxuICAgICAgYXdhaXQgY2xlYXJBY3Rpdml0eSgpO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdvcGVuLW9wdGlvbnMnOlxuICAgICAgYXdhaXQgYnJvd3Nlci5ydW50aW1lLm9wZW5PcHRpb25zUGFnZSgpO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdvcGVuLXZpZXdlcic6IHtcbiAgICAgIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICAgICAgY29uc3QgdXJsID0gdmlld2VyVXJsKHMpO1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCB9KTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgfVxuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAndW5rbm93biBtZXNzYWdlIHR5cGUnIH07XG4gIH1cbn1cblxuLy8gLS0tIENhcHR1cmUgcGlwZWxpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gb25HcmFwaHFsQ2FwdHVyZShcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgdXJsOiBzdHJpbmcsXG4gIHBhZ2VVcmw6IHN0cmluZyB8IG51bGwsXG4gIHJlc3BvbnNlOiB1bmtub3duXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKFBST0ZJTEVfRU5EUE9JTlRTLmhhcyhlbmRwb2ludCkpIHJldHVybjsgLy8gbm90IHR3ZWV0LWJlYXJpbmdcbiAgaWYgKCFUV0VFVF9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuO1xuXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKHNldHRpbmdzLmVuYWJsZWQgPT09IGZhbHNlKSByZXR1cm47XG4gIGlmIChzZXR0aW5ncy5hdXRvQ2FwdHVyZSA9PT0gZmFsc2UpIHtcbiAgICBjb25zdCBleHBsaWNpdENhcHR1cmVBY3RpdmUgPVxuICAgICAgRGF0ZS5ub3coKSA8IG1hbnVhbENhcHR1cmVVbnRpbE1zIHx8XG4gICAgICAoYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKSkgIT09IG51bGwgfHxcbiAgICAgIChhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpKSAhPT0gbnVsbCB8fFxuICAgICAgKGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCkpICE9PSBudWxsO1xuICAgIGlmICghZXhwbGljaXRDYXB0dXJlQWN0aXZlKSByZXR1cm47XG4gIH1cblxuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIC8vIFdlIGRlbGliZXJhdGVseSBkbyBOT1Qgc2hvcnQtY2lyY3VpdCB3aGVuIHRoZSBQQVQgaXMgbWlzc2luZy4gVGhlXG4gIC8vIG5vcm1hbGl6ZSBzdGVwIGlzIGNoZWFwLCB0aGUgYnVmZmVyIHN1cnZpdmVzIHNlcnZpY2Utd29ya2VyIGV2aWN0aW9uLFxuICAvLyBhbmQgb25jZSB0aGUgUEFUIGlzIHNldCB0aGUgbmV4dCBhbGFybSBvciB1c2VyLXRyaWdnZXJlZCBmbHVzaCBjb21taXRzXG4gIC8vIGV2ZXJ5dGhpbmcgd2UndmUgc2Vlbi4gRHJvcHBpbmcgY2FwdHVyZXMgaGVyZSB3YXMgaGlkaW5nIHRoZSB1c2VyJ3NcbiAgLy8gZmlyc3QgYnJvd3Npbmcgc2Vzc2lvbiBlbnRpcmVseS5cblxuICAvLyBUd28tc3RhZ2UgZmlsdGVyOlxuICAvLyAgIDEuIEJ1aWxkIEVWRVJZIGNhbm9uaWNhbCB0d2VldCB3ZSBjYW4gZmluZCBpbiB0aGUgcmVzcG9uc2UgKG5vIGhhbmRsZVxuICAvLyAgICAgIGZpbHRlciBhdCB0aGUgbm9ybWFsaXplciBsZXZlbCBcdTIwMTQgd2Ugc3RpbGwgd2FudCBxdW90ZWQvUlQnZCBwYXJlbnRzXG4gIC8vICAgICAgdGhhdCBhcHBlYXIgYXMgc2libGluZyBub2RlcykuXG4gIC8vICAgMi4gQXBwbHkgYGZpbHRlclJlbGF0ZWRgIHBvc3QtaG9jIHRvIGRyb3AgYW55dGhpbmcgdGhhdCBoYXMgbm9cbiAgLy8gICAgICByZWxhdGlvbnNoaXAgdG8gYSB0cmFja2VkIGFjY291bnQuIFRoZSBvbGQgYmVoYXZpb3VyIChcImVtcHR5XG4gIC8vICAgICAgYWxsb3dlZC1zZXQgb24gdXNlci1wYWdlIGVuZHBvaW50cywgZnVsbCBmaWx0ZXIgb24gaG9tZS9zZWFyY2hcIilcbiAgLy8gICAgICB3YXMgd2F5IHRvbyBwZXJtaXNzaXZlIG9uIHRoZSBSZXBsaWVzIHRhYjogZXZlcnkgcmFuZG9tIHJlcGxpZXInc1xuICAvLyAgICAgIHJlcGx5IGxhbmRlZCBpbiBhIHBlci1oYW5kbGUgYnVmZmVyIGtleWVkIGJ5IHRoZWlyIG93biBoYW5kbGUuXG4gIGNvbnN0IHRyYWNrZWQgPSBuZXcgU2V0KGFjY291bnRzLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBjb3JlID0gbmV3IFNldChcbiAgICBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuY2F0ZWdvcnkgPT09ICdjb3JlJykubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKVxuICApO1xuICBjb25zdCBjYXB0dXJlZEF0ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuXG4gIGxldCBub3JtYWxpemVkO1xuICB0cnkge1xuICAgIG5vcm1hbGl6ZWQgPSBub3JtYWxpemUocmVzcG9uc2UsIHtcbiAgICAgIGNhcHR1cmVkQXQsXG4gICAgICBydW5JZDogJ3BlbmRpbmcnLFxuICAgICAgZW5kcG9pbnQsXG4gICAgICBhbGxvd2VkSGFuZGxlczogbmV3IFNldDxzdHJpbmc+KCksXG4gICAgICBzb3VyY2VVcmw6IHBhZ2VVcmwsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHF1YXJhbnRpbmUoJ25vcm1hbGl6ZS10aHJldycsIGVuZHBvaW50LCB1cmwsIHJlc3BvbnNlLCBlcnIpO1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBEcm9wIHVucmVsYXRlZCB0d2VldHMuIFRoZSBmaWx0ZXIgaXMgZW5kcG9pbnQtYXdhcmU6XG4gIC8vICAgLSBPbiB0aGUgaG9tZSAvIHNlYXJjaCB0aW1lbGluZXMgd2UnZCBhbHJlYWR5IGJlZW4gZmlsdGVyaW5nIHRvXG4gIC8vICAgICB0cmFja2VkIGF1dGhvcnMgb25seSBcdTIwMTQga2VlcCB0aGF0IGJlaGF2aW91ciBidXQgZ28gdGhyb3VnaCB0aGUgc2FtZVxuICAvLyAgICAgYGZpbHRlclJlbGF0ZWRgIGhlbHBlciBzbyB0aGUgcnVsZXMgYXJlIHVuaWZvcm0uXG4gIC8vICAgLSBPbiB1c2VyLXBhZ2UgZW5kcG9pbnRzIHdlIG5vdyBhbHNvIGRyb3AgYW55dGhpbmcgdGhhdCBpc24ndCBlaXRoZXJcbiAgLy8gICAgIGF1dGhvcmVkLWJ5LCBtZW50aW9uaW5nLCByZXBseWluZy10bywgb3IgcmVmZXJlbmNlZC1ieSBhIHRyYWNrZWRcbiAgLy8gICAgIGFjY291bnQuXG4gIGNvbnN0IGJlZm9yZUZpbHRlciA9IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aDtcbiAgbm9ybWFsaXplZC50d2VldHMgPSBmaWx0ZXJSZWxhdGVkKG5vcm1hbGl6ZWQudHdlZXRzLCB0cmFja2VkLCBjb3JlKTtcbiAgY29uc3QgZHJvcHBlZFVucmVsYXRlZCA9IGJlZm9yZUZpbHRlciAtIG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aDtcbiAgaWYgKGRyb3BwZWRVbnJlbGF0ZWQgPiAwKSB7XG4gICAgYXdhaXQgaW5mbygnZHJvcHBlZCB1bnJlbGF0ZWQgdHdlZXRzJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBkcm9wcGVkOiBkcm9wcGVkVW5yZWxhdGVkLFxuICAgICAga2VwdDogbm9ybWFsaXplZC50d2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG5cbiAgLy8gRGlhZ25vc3RpYzogZXZlcnkgdHdlZXQtZW5kcG9pbnQgcGF5bG9hZCBnZXRzIGEgbGluZSBpbiB0aGUgYWN0aXZpdHlcbiAgLy8gdGFpbCB3aXRoIHdoYXQgd2Ugc2F3IHZzIGtlcHQuIFdoZW4gb2JzZXJ2ZWQ9MCB3ZSBhbHNvIGVtaXQgYSBzaGFwZVxuICAvLyBwcm9iZSAoa2V5IHBhdGhzICsgdHlwZW5hbWVzKSBzbyB3ZSBjYW4gdGVsbCB3aGV0aGVyIFggcmV0dXJuZWQgYW5cbiAgLy8gZW1wdHkgZW52ZWxvcGUsIGEgbG9naW4td2FsbCByZXNwb25zZSwgb3IgYSBuZXcgc2hhcGUgd2UgZG9uJ3Qga25vdyBob3dcbiAgLy8gdG8gd2FsayB5ZXQuXG4gIGlmIChub3JtYWxpemVkLm9ic2VydmVkX2lkcy5sZW5ndGggPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdncmFwaHFsIHBheWxvYWQgZW1wdHkgXHUyMDE0IHNoYXBlIHByb2JlJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICB0eXBlbmFtZXM6IHByb2JlVHlwZW5hbWVzKHJlc3BvbnNlKS5zbGljZSgwLCAzMCksXG4gICAgICB0d2VldF9rZXlzOiBwcm9iZUZpcnN0VHlwZVNoYXBlKHJlc3BvbnNlLCAnVHdlZXQnKSxcbiAgICAgIHR3ZWV0X2NvcmVfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgWydjb3JlJ10pLFxuICAgICAgdHdlZXRfbGVnYWN5X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFsnbGVnYWN5J10pLFxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXG4gICAgICAgICdjb3JlJyxcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXG4gICAgICAgICdyZXN1bHQnLFxuICAgICAgXSksXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2NvcmVfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xuICAgICAgICAnY29yZScsXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxuICAgICAgICAncmVzdWx0JyxcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgXSksXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2xlZ2FjeV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXG4gICAgICAgICdjb3JlJyxcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXG4gICAgICAgICdyZXN1bHQnLFxuICAgICAgICAnbGVnYWN5JyxcbiAgICAgIF0pLFxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGF3YWl0IGluZm8oJ2dyYXBocWwgcGF5bG9hZCBzZWVuJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBvYnNlcnZlZDogbm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoLFxuICAgICAga2VwdDogbm9ybWFsaXplZC50d2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG5cbiAgaWYgKG5vcm1hbGl6ZWQudW5hdmFpbGFibGVfdHdlZXRzLmxlbmd0aCA+IDApIHtcbiAgICBhd2FpdCByZWNvcmRVbmF2YWlsYWJsZVR3ZWV0cyhcbiAgICAgIG5vcm1hbGl6ZWQudW5hdmFpbGFibGVfdHdlZXRzLFxuICAgICAgdHJhY2tlZCxcbiAgICAgIGNhcHR1cmVkQXQsXG4gICAgICB1cmwsXG4gICAgICBlbmRwb2ludFxuICAgICk7XG4gIH1cblxuICBpZiAobm9ybWFsaXplZC50d2VldHMubGVuZ3RoID09PSAwKSByZXR1cm47XG5cbiAgLy8gUmVmZXRjaCBxdWV1ZSBob3VzZWtlZXBpbmcgXHUyMDE0IHJ1bnMgQkVGT1JFIHRoZSBkZWR1cCBzaG9ydC1jaXJjdWl0LiBBXG4gIC8vIHJlZmV0Y2ggY2FwdHVyZSBjb21lcyBiYWNrIHdpdGggdGhlIHNhbWUgZW5nYWdlbWVudCBjb3VudHMgKHdlJ3JlXG4gIC8vIG9ubHkgYWZ0ZXIgdGhlIGZ1bGwgdGV4dCksIHNvIHRoZSBkZWR1cCBiZWxvdyB3b3VsZCBzaWxlbnRseSBkcm9wXG4gIC8vIGl0IGFuZCB0aGUgcXVldWUgd291bGQgbmV2ZXIgZHJhaW4uIEhvaXN0IHRoZSBlbnF1ZXVlL2RlcXVldWUgaGVyZVxuICAvLyBzbyB0aGUgbG9vcCByZWxpYWJseSBhZHZhbmNlcyBldmVuIHdoZW4gbm8gY29tbWl0IGhhcHBlbnMuXG4gIC8vXG4gIC8vIEFsc286IGlmIGVpdGhlciBsb29wJ3MgaW5mbGlnaHQgdGFyZ2V0IGFwcGVhcnMgaGVyZSwgbWFyayB0aGUgbG9vcFxuICAvLyBhcyBcImluZ2VzdGVkXCIgc28gdGhlIG5leHQgdGljayBjYW4gYWR2YW5jZS4gVGhlIHdhaXQtZm9yLWluZ2VzdFxuICAvLyBndWFyZCBvdGhlcndpc2UgYmxvY2tzIHVudGlsIHRoZSBuYXZpZ2F0aW9uLXRpbWVvdXQgZmlyZXMuXG4gIGNvbnN0IHJlZmV0Y2hTZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBmb3IgKGNvbnN0IHQgb2Ygbm9ybWFsaXplZC50d2VldHMpIHtcbiAgICBpZiAodC5pc190cnVuY2F0ZWQpIHtcbiAgICAgIGF3YWl0IGVucXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaCh0LmFjY291bnRfaGFuZGxlLCB0LnR3ZWV0X2lkKTtcbiAgICB9XG4gICAgLy8gU3VjY2Vzc2Z1bGx5IGJ1aWx0IHR3ZWV0cyBhcmUgbm8gbG9uZ2VyIFwicGFydGlhbFwiIFx1MjAxNCBkcm9wIGZyb20gdGhlXG4gICAgLy8gbWVkaWEtY3Jhd2wgcXVldWUgcmVnYXJkbGVzcyBvZiB3aGljaCBoYW5kbGUgd2UnZCBoaW50ZWQgZWFybGllci5cbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0LnR3ZWV0X2lkKTtcbiAgICBpZiAocmVmZXRjaFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XG4gICAgICByZWZldGNoU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICByZWZldGNoU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHJlZmV0Y2hTZXNzKTtcbiAgICB9XG4gICAgaWYgKG1lZGlhQ3Jhd2xTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdC50d2VldF9pZCkge1xuICAgICAgbWVkaWFDcmF3bFNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgICAgbWVkaWFDcmF3bFNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihtZWRpYUNyYXdsU2Vzcyk7XG4gICAgfVxuICB9XG5cbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IHR3ZWV0LXNoYXBlZCBub2RlcyB0aGUgd2Fsa2VyIHNhdyBidXQgY291bGRuJ3QgdHVyblxuICAvLyBpbnRvIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIEVucXVldWUgb25seSBJRHMgd2UgaGF2ZW4ndCBhbHJlYWR5XG4gIC8vIGNvbW1pdHRlZCAodXNlci1yZXF1ZXN0ZWQgZGVkdXAgYWdhaW5zdCB0aGUgYXJjaGl2ZSkuXG4gIGZvciAoY29uc3QgcGFydGlhbCBvZiBub3JtYWxpemVkLnBhcnRpYWxfaWRzKSB7XG4gICAgaWYgKGF3YWl0IGlzQ29tbWl0dGVkKHBhcnRpYWwudHdlZXRfaWQpKSBjb250aW51ZTtcbiAgICBhd2FpdCBlbnF1ZXVlTWVkaWFDcmF3bChwYXJ0aWFsLmhpbnRfaGFuZGxlLCBwYXJ0aWFsLnR3ZWV0X2lkKTtcbiAgfVxuICBpZiAobm9ybWFsaXplZC5wYXJ0aWFsX2lkcy5sZW5ndGggPiAwKSB7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IGVucXVldWVkIHBhcnRpYWwgY2FwdHVyZXMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHBhcnRpYWw6IG5vcm1hbGl6ZWQucGFydGlhbF9pZHMubGVuZ3RoLFxuICAgICAgcXVldWVfdG90YWw6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXG4gICAgfSk7XG4gIH1cblxuICAvLyBDcm9zcy1zZXNzaW9uIGRlZHVwOiBkcm9wIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IGNvbW1pdHRlZCB3aXRoIGlkZW50aWNhbFxuICAvLyBlbmdhZ2VtZW50IGNvdW50cy4gTGlrZXMvUlRzL3JlcGxpZXMvcXVvdGVzIHN0aWxsIHRyaWdnZXIgYSByZWNhcHR1cmVcbiAgLy8gc28gZW5nYWdlbWVudF9oaXN0b3J5IGdyb3dzIG92ZXIgdGltZS4gdmlld19jb3VudCBpcyBpbnRlbnRpb25hbGx5XG4gIC8vIGV4Y2x1ZGVkIFx1MjAxNCBpdCBjaHVybnMgdG9vIGZhc3QgdG8gYmUgdXNlZnVsIGFzIGEgZnJlc2huZXNzIHNpZ25hbC5cbiAgLy8gYGlzX3RydW5jYXRlZGAgaXMgcGFydCBvZiB0aGUgc2lnbmF0dXJlIHNvIGEgcmVmZXRjaCB0aGF0IGZsaXBzXG4gIC8vIHRydW5jYXRlZFx1MjE5MmZ1bGwgaXMgdHJlYXRlZCBhcyBhIG1hdGVyaWFsIGNoYW5nZSBhbmQgZ2V0cyBjb21taXR0ZWQuXG4gIC8vXG4gIC8vIFdoZW4gdGhlIHVzZXIgaGFzIHR1cm5lZCBvZmYgXCJ1cGRhdGUgZXhpc3RpbmdcIiwgd2Ugc2tpcCB0aGUgZW5nYWdlbWVudFxuICAvLyBjb21wYXJpc29uIGVudGlyZWx5OiBhbnkgdHdlZXQgdGhhdCdzIGFscmVhZHkgY29tbWl0dGVkIHVuZGVyIGFueVxuICAvLyBoYW5kbGUgZ2V0cyBkcm9wcGVkIGhlcmUsIHNvIHdlIGRvbid0IHBheSBHaXRIdWItQVBJIG92ZXJoZWFkIGp1c3QgdG9cbiAgLy8gcmVmcmVzaCBsaWtlIC8gUlQgY291bnRzLiBOZXcgdHdlZXRzIGFuZCB0cnVuY2F0ZWRcdTIxOTJmdWxsIHJlZmV0Y2hlc1xuICAvLyBzdGlsbCBmbG93IHRocm91Z2ggbm9ybWFsbHkgYmVjYXVzZSB0aGV5IGFyZW4ndCBpbiB0aGUgaW5kZXggeWV0XG4gIC8vIChvciBjYXJyeSBhbiBpc190cnVuY2F0ZWQgdHJhbnNpdGlvbiB0aGF0IGZhaWxzIHRoZSBzaWcgY2hlY2spLlxuICBjb25zdCB1cGRhdGVFeGlzdGluZyA9IHNldHRpbmdzLnVwZGF0ZUV4aXN0aW5nICE9PSBmYWxzZTtcbiAgY29uc3QgY29tbWl0dGVkSWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgY29uc3QgYXJjaGl2ZVNuYXBzaG90ID0gYXdhaXQgZ2V0QXJjaGl2ZVNuYXBzaG90KCk7XG4gIGxldCBkZWR1cGVkU2tpcHBlZCA9IDA7XG4gIGxldCBza2lwcGVkTm9VcGRhdGVMb2NhbCA9IDA7XG4gIGxldCBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCA9IDA7XG4gIGxldCBvbGRGcm9tU25hcHNob3QgPSAwO1xuICBjb25zdCBsaXZlVHdlZXRzOiB0eXBlb2Ygbm9ybWFsaXplZC50d2VldHMgPSBbXTtcbiAgY29uc3QgZnJlc2huZXNzQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCAnbmV3JyB8ICdleGlzdGluZyc+KCk7XG4gIGNvbnN0IGFjdGlvbkJ5SWQgPSBuZXcgTWFwPHN0cmluZywgVHdlZXRTaWdodGluZ1snYWN0aW9uJ10+KCk7XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbdC5hY2NvdW50X2hhbmRsZV0/Llt0LnR3ZWV0X2lkXTtcbiAgICBjb25zdCBvbGRCeVNuYXBzaG90ID0gIXByZXYgJiYgYXJjaGl2ZVNuYXBzaG90SGFzVHdlZXQodCwgYXJjaGl2ZVNuYXBzaG90KTtcbiAgICBjb25zdCBwcmV2aW91c2x5QXJjaGl2ZWQgPSBCb29sZWFuKHByZXYpIHx8IG9sZEJ5U25hcHNob3Q7XG4gICAgZnJlc2huZXNzQnlJZC5zZXQodC50d2VldF9pZCwgcHJldmlvdXNseUFyY2hpdmVkID8gJ2V4aXN0aW5nJyA6ICduZXcnKTtcbiAgICBpZiAob2xkQnlTbmFwc2hvdCkgb2xkRnJvbVNuYXBzaG90ICs9IDE7XG4gICAgaWYgKHByZXZpb3VzbHlBcmNoaXZlZCAmJiAhdXBkYXRlRXhpc3RpbmcpIHtcbiAgICAgIGlmIChwcmV2KSBza2lwcGVkTm9VcGRhdGVMb2NhbCArPSAxO1xuICAgICAgZWxzZSBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCArPSAxO1xuICAgICAgYWN0aW9uQnlJZC5zZXQodC50d2VldF9pZCwgJ3NraXBwZWQnKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBzaWcgPSBlbmdhZ2VtZW50U2lnKFxuICAgICAgdC5saWtlX2NvdW50LFxuICAgICAgdC5yZXR3ZWV0X2NvdW50LFxuICAgICAgdC5yZXBseV9jb3VudCxcbiAgICAgIHQucXVvdGVfY291bnQsXG4gICAgICB0LmlzX3RydW5jYXRlZFxuICAgICk7XG4gICAgaWYgKHByZXYgJiYgcHJldi5zaWcgPT09IHNpZykge1xuICAgICAgZGVkdXBlZFNraXBwZWQgKz0gMTtcbiAgICAgIGFjdGlvbkJ5SWQuc2V0KHQudHdlZXRfaWQsICd1bmNoYW5nZWQnKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBhY3Rpb25CeUlkLnNldCh0LnR3ZWV0X2lkLCAnYnVmZmVyZWQnKTtcbiAgICBsaXZlVHdlZXRzLnB1c2godCk7XG4gIH1cbiAgaWYgKGRlZHVwZWRTa2lwcGVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2RlZHVwOiBza2lwcGVkIHVuY2hhbmdlZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHNraXBwZWQ6IGRlZHVwZWRTa2lwcGVkLFxuICAgICAgcmVtYWluaW5nOiBsaXZlVHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuICBpZiAoc2tpcHBlZE5vVXBkYXRlTG9jYWwgKyBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCA+IDApIHtcbiAgICBjb25zdCBza2lwcGVkT2xkID0gc2tpcHBlZE5vVXBkYXRlTG9jYWwgKyBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdDtcbiAgICBhd2FpdCBpbmZvKCdkZWR1cDogc2tpcHBlZCBwcmV2aW91c2x5IGFyY2hpdmVkIHR3ZWV0cyAodXBkYXRlRXhpc3Rpbmc9ZmFsc2UpJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBza2lwcGVkOiBza2lwcGVkT2xkLFxuICAgICAgbG9jYWxfaW5kZXg6IHNraXBwZWROb1VwZGF0ZUxvY2FsLFxuICAgICAgYXJjaGl2ZV9zbmFwc2hvdDogc2tpcHBlZE5vVXBkYXRlU25hcHNob3QsXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICAgIGNvbnN0IGFzU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xuICAgICAgYXNTZXNzLnNraXBwZWRPbGRDb3VudCA9IChhc1Nlc3Muc2tpcHBlZE9sZENvdW50ID8/IDApICsgc2tpcHBlZE9sZDtcbiAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKGFzU2Vzcyk7XG4gICAgfVxuICB9XG4gIGlmIChvbGRGcm9tU25hcHNob3QgPiAwICYmIHVwZGF0ZUV4aXN0aW5nKSB7XG4gICAgYXdhaXQgaW5mbygnYXJjaGl2ZSBzbmFwc2hvdCByZWNvZ25pemVkIG9sZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIG9sZDogb2xkRnJvbVNuYXBzaG90LFxuICAgICAgYWN0aW9uOiAnYnVmZmVyaW5nIGJlY2F1c2UgdXBkYXRlRXhpc3Rpbmc9dHJ1ZScsXG4gICAgICBzbmFwc2hvdF9nZW5lcmF0ZWRfYXQ6IGFyY2hpdmVTbmFwc2hvdD8uZ2VuZXJhdGVkX2F0ID8/IG51bGwsXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgcHJlcGVuZFJlY2VudFR3ZWV0U2lnaHRpbmdzKFxuICAgIG5vcm1hbGl6ZWQudHdlZXRzLm1hcCgodCkgPT5cbiAgICAgIGJ1aWxkVHdlZXRTaWdodGluZyh0LCBlbmRwb2ludCwgY2FwdHVyZWRBdCwgZnJlc2huZXNzQnlJZC5nZXQodC50d2VldF9pZCksIGFjdGlvbkJ5SWQuZ2V0KHQudHdlZXRfaWQpKVxuICAgIClcbiAgKTtcbiAgLy8gLS0tIE1pc3NpbmctcGFyZW50IHJlY292ZXJ5IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gWCdzIFVzZXJUd2VldHNBbmRSZXBsaWVzIGVuZHBvaW50IHNvbWV0aW1lcyBzZXJ2ZXMgYSByZXBseSB3aXRob3V0IHRoZVxuICAvLyBwYXJlbnQgdHdlZXQgaXQgcG9pbnRzIGF0IFx1MjAxNCBvbmx5IGFuIGluX3JlcGx5X3RvX3NjcmVlbl9uYW1lIGFuY2hvci4gV2VcbiAgLy8gbmV2ZXIgc2VlIHRoYXQgcGFyZW50LCBzbyBpdCBuZXZlciBsYW5kcyBpbiB0aGUgYXJjaGl2ZS4gU2FtZSBmb3JcbiAgLy8gcXVvdGVkX3R3ZWV0X2lkIC8gcmV0d2VldGVkX3R3ZWV0X2lkIHdoZW4gWCBzdHJpcHMgdGhlIHJlZmVyZW5jZWRcbiAgLy8gbm9kZS4gV2FsayB0aGUgdHdlZXRzIHdlIGp1c3Qgc2F3LCBmaW5kIGFueSBwYXJlbnQgSUQgd2UgZG9uJ3QgaGF2ZSxcbiAgLy8gYW5kIGVucXVldWUgaXQgb24gdGhlIG1lZGlhLWNyYXdsIGxvb3Agc28gaXRzIGRldGFpbCBwYWdlIGdldHNcbiAgLy8gdmlzaXRlZCBhbmQgaW5nZXN0ZWQgbmV4dCB0aW1lIHRoZSB1c2VyIHN0YXJ0cyB0aGUgY3Jhd2wuXG4gIGF3YWl0IGVucXVldWVNaXNzaW5nUGFyZW50cyhub3JtYWxpemVkLnR3ZWV0cywgZW5kcG9pbnQpO1xuICBpZiAobGl2ZVR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAvLyBHcm91cCBzdXJ2aXZpbmcgdHdlZXRzIGJ5IGF1dGhvciBoYW5kbGUuXG4gIGNvbnN0IGJ5SGFuZGxlID0gbmV3IE1hcDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0W10+KCk7XG4gIGZvciAoY29uc3QgdCBvZiBsaXZlVHdlZXRzKSB7XG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUpID8/IFtdO1xuICAgIGFyci5wdXNoKHQpO1xuICAgIGJ5SGFuZGxlLnNldCh0LmFjY291bnRfaGFuZGxlLCBhcnIpO1xuICB9XG5cbiAgZm9yIChjb25zdCBbaGFuZGxlLCB0d2VldHNdIG9mIGJ5SGFuZGxlKSB7XG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgdXJsLCBlbmRwb2ludCk7XG4gICAgbGV0IGFkZGVkID0gMDtcbiAgICBsZXQgYWRkZWROZXcgPSAwO1xuICAgIGxldCBhZGRlZEV4aXN0aW5nID0gMDtcbiAgICBsZXQgdXBkYXRlZEJ1ZmZlcmVkID0gMDtcbiAgICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgICBjb25zdCBleGlzdGluZyA9IGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF07XG4gICAgICBpZiAoZXhpc3RpbmcpIHtcbiAgICAgICAgLy8gUHJlc2VydmUgZmlyc3RfY2FwdHVyZWRfYXQsIGFwcGVuZCBlbmdhZ2VtZW50IHNuYXBzaG90LCByZWZyZXNoXG4gICAgICAgIC8vIGxhc3Rfc2Vlbl9hdCArIGNvdW50cyAodGhlIGxhdGVzdCBzY3JhcGUgd2lucyBmb3IgY291bnRzKS5cbiAgICAgICAgZXhpc3RpbmcubGFzdF9zZWVuX2F0ID0gY2FwdHVyZWRBdDtcbiAgICAgICAgZXhpc3RpbmcubGlrZV9jb3VudCA9IHQubGlrZV9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmV0d2VldF9jb3VudCA9IHQucmV0d2VldF9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmVwbHlfY291bnQgPSB0LnJlcGx5X2NvdW50O1xuICAgICAgICBleGlzdGluZy5xdW90ZV9jb3VudCA9IHQucXVvdGVfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnZpZXdfY291bnQgPSB0LnZpZXdfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLmJvb2ttYXJrX2NvdW50ID0gdC5ib29rbWFya19jb3VudDtcbiAgICAgICAgY29uc3QgbGFzdCA9IGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeVtleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnkubGVuZ3RoIC0gMV07XG4gICAgICAgIGNvbnN0IHNuYXAgPSB0LmVuZ2FnZW1lbnRfaGlzdG9yeVswXTtcbiAgICAgICAgaWYgKHNuYXAgJiYgKCFsYXN0IHx8IGxhc3QuY2FwdHVyZWRfYXQgIT09IHNuYXAuY2FwdHVyZWRfYXQpKSB7XG4gICAgICAgICAgZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5LnB1c2goc25hcCk7XG4gICAgICAgIH1cbiAgICAgICAgdXBkYXRlZEJ1ZmZlcmVkICs9IDE7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBzdGFtcGVkOiBDYW5vbmljYWxUd2VldCA9IHsgLi4udCwgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQgfTtcbiAgICAgICAgYnVmLnR3ZWV0c19ieV9pZFt0LnR3ZWV0X2lkXSA9IHN0YW1wZWQ7XG4gICAgICAgIGFkZGVkICs9IDE7XG4gICAgICAgIGlmIChmcmVzaG5lc3NCeUlkLmdldCh0LnR3ZWV0X2lkKSA9PT0gJ2V4aXN0aW5nJykgYWRkZWRFeGlzdGluZyArPSAxO1xuICAgICAgICBlbHNlIGFkZGVkTmV3ICs9IDE7XG4gICAgICB9XG4gICAgICBpZiAoIWJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQuaW5jbHVkZXModC50d2VldF9pZCkpIHtcbiAgICAgICAgYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5wdXNoKHQudHdlZXRfaWQpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIWJ1Zi5lbmRwb2ludHNfc2Vlbi5pbmNsdWRlcyhlbmRwb2ludCkpIGJ1Zi5lbmRwb2ludHNfc2Vlbi5wdXNoKGVuZHBvaW50KTtcbiAgICBidWYubGFzdF9jYXB0dXJlX2F0ID0gY2FwdHVyZWRBdDtcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICAgIGF3YWl0IHNldEJ1ZmZlcmVkQ291bnQoXG4gICAgICBoYW5kbGUsXG4gICAgICBPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggKyBPYmplY3Qua2V5cyhidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge30pLmxlbmd0aFxuICAgICk7XG4gICAgaWYgKGFkZGVkID4gMCB8fCB1cGRhdGVkQnVmZmVyZWQgPiAwKSB7XG4gICAgICBhd2FpdCBpbmZvKCdidWZmZXJlZCB0d2VldHMnLCB7XG4gICAgICAgIGhhbmRsZSxcbiAgICAgICAgZW5kcG9pbnQsXG4gICAgICAgIGFkZGVkLFxuICAgICAgICBuZXc6IGFkZGVkTmV3LFxuICAgICAgICBleGlzdGluZzogYWRkZWRFeGlzdGluZyxcbiAgICAgICAgdXBkYXRlZF9idWZmZXJlZDogdXBkYXRlZEJ1ZmZlcmVkLFxuICAgICAgICB0b3RhbDogT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoLFxuICAgICAgfSk7XG4gICAgICAvLyBCdW1wIHRoZSBhdXRvLXNjcm9sbCBwcm9ncmVzcyBzbyB0aGUgdXNlciBzZWVzIFwiWCBpbmdlc3RlZFwiIHRpY2sgdXBcbiAgICAgIC8vIGluIHJlYWwgdGltZS4gV2UgY291bnQgYWN0dWFsbHktbmV3IHR3ZWV0cywgbm90IGR1cGxpY2F0ZXMuXG4gICAgICBjb25zdCBhc1Nlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xuICAgICAgICBhc1Nlc3MuaW5nZXN0ZWRDb3VudCArPSBhZGRlZDtcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkTmV3Q291bnQgPSAoYXNTZXNzLmluZ2VzdGVkTmV3Q291bnQgPz8gMCkgKyBhZGRlZE5ldztcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkRXhpc3RpbmdDb3VudCA9XG4gICAgICAgICAgKGFzU2Vzcy5pbmdlc3RlZEV4aXN0aW5nQ291bnQgPz8gMCkgKyBhZGRlZEV4aXN0aW5nO1xuICAgICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihhc1Nlc3MpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoID49IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCkge1xuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUoaGFuZGxlLCAndGhyZXNob2xkJyk7XG4gICAgfVxuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlY29yZFVuYXZhaWxhYmxlVHdlZXRzKFxuICB1bmF2YWlsYWJsZVR3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdLFxuICB0cmFja2VkOiBSZWFkb25seVNldDxzdHJpbmc+LFxuICBjYXB0dXJlZEF0OiBzdHJpbmcsXG4gIHNvdXJjZVVybDogc3RyaW5nLFxuICBlbmRwb2ludDogc3RyaW5nXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgY29tbWl0dGVkSWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGxldCByZWNvcmRlZCA9IDA7XG4gIGxldCBza2lwcGVkID0gMDtcbiAgbGV0IG1pc3NpbmdIYW5kbGUgPSAwO1xuXG4gIGZvciAoY29uc3QgdSBvZiB1bmF2YWlsYWJsZVR3ZWV0cykge1xuICAgIGNvbnN0IGhhbmRsZSA9IHUuYWNjb3VudF9oYW5kbGU7XG4gICAgaWYgKCFoYW5kbGUpIHtcbiAgICAgIG1pc3NpbmdIYW5kbGUgKz0gMTtcbiAgICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHUudHdlZXRfaWQpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICh0cmFja2VkLnNpemUgPiAwICYmICF0cmFja2VkLmhhcyhoYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgIHNraXBwZWQgKz0gMTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHUudHdlZXRfaWQpO1xuICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKGhhbmRsZSwgdS50d2VldF9pZCk7XG4gICAgaWYgKHJlZmV0Y2hTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdS50d2VldF9pZCkge1xuICAgICAgcmVmZXRjaFNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgICAgcmVmZXRjaFNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihyZWZldGNoU2Vzcyk7XG4gICAgfVxuICAgIGlmIChtZWRpYUNyYXdsU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHUudHdlZXRfaWQpIHtcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obWVkaWFDcmF3bFNlc3MpO1xuICAgIH1cblxuICAgIGNvbnN0IHNpZyA9IHVuYXZhaWxhYmxlU2lnKHUpO1xuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbaGFuZGxlXT8uW3UudHdlZXRfaWRdO1xuICAgIGlmIChwcmV2Py5zaWcgPT09IHNpZykge1xuICAgICAgc2tpcHBlZCArPSAxO1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgc291cmNlVXJsLCBlbmRwb2ludCk7XG4gICAgY29uc3QgdW5hdmFpbGFibGVCeUlkID0gYnVmLnVuYXZhaWxhYmxlX2J5X2lkID8/IHt9O1xuICAgIHVuYXZhaWxhYmxlQnlJZFt1LnR3ZWV0X2lkXSA9IHU7XG4gICAgYnVmLnVuYXZhaWxhYmxlX2J5X2lkID0gdW5hdmFpbGFibGVCeUlkO1xuICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyh1LnR3ZWV0X2lkKSkge1xuICAgICAgYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5wdXNoKHUudHdlZXRfaWQpO1xuICAgIH1cbiAgICBpZiAoIWJ1Zi5lbmRwb2ludHNfc2Vlbi5pbmNsdWRlcyhlbmRwb2ludCkpIGJ1Zi5lbmRwb2ludHNfc2Vlbi5wdXNoKGVuZHBvaW50KTtcbiAgICBidWYubGFzdF9jYXB0dXJlX2F0ID0gY2FwdHVyZWRBdDtcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICAgIGF3YWl0IHNldEJ1ZmZlcmVkQ291bnQoXG4gICAgICBoYW5kbGUsXG4gICAgICBPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggKyBPYmplY3Qua2V5cyh1bmF2YWlsYWJsZUJ5SWQpLmxlbmd0aFxuICAgICk7XG4gICAgcmVjb3JkZWQgKz0gMTtcbiAgfVxuXG4gIGlmIChyZWNvcmRlZCA+IDAgfHwgbWlzc2luZ0hhbmRsZSA+IDAgfHwgc2tpcHBlZCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCd1bmF2YWlsYWJsZSB0d2VldHMgb2JzZXJ2ZWQnLCB7IGVuZHBvaW50LCByZWNvcmRlZCwgc2tpcHBlZCwgbWlzc2luZ0hhbmRsZSB9KTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5mdW5jdGlvbiB1bmF2YWlsYWJsZVNpZyh1OiBVbmF2YWlsYWJsZVR3ZWV0KTogc3RyaW5nIHtcbiAgcmV0dXJuIGB1bmF2YWlsYWJsZXwke3UudW5hdmFpbGFibGVfcmVhc29uID8/ICcnfXwke3UudW5hdmFpbGFibGVfdGV4dCA/PyAnJ31gO1xufVxuXG4vKipcbiAqIEZpbmQgZXZlcnkgcGFyZW50IHR3ZWV0IHJlZmVyZW5jZWQgYnkgdGhlIGNhcHR1cmVzIHdlIGp1c3QgaW5nZXN0ZWRcbiAqIChgcmVwbHlfdG9fdHdlZXRfaWRgLCBgcXVvdGVkX3R3ZWV0X2lkYCwgYHJldHdlZXRlZF90d2VldF9pZGApIHRoYXQgd2VcbiAqIGRvbid0IHlldCBoYXZlIGluIHRoZSBhcmNoaXZlLCBhbmQgZW5xdWV1ZSBpdCBvbiB0aGUgbWVkaWEtY3Jhd2wgbG9vcC5cbiAqXG4gKiBXaHk6IFgncyBVc2VyVHdlZXRzQW5kUmVwbGllcyBlbmRwb2ludCBzb21ldGltZXMgcmV0dXJucyBhIHRyYWNrZWRcbiAqIGFjY291bnQncyByZXBseSAqd2l0aG91dCogdGhlIHBhcmVudCBpdCBwb2ludHMgYXQuIFRoZSBgcmVwbHlfdG9fKmBcbiAqIGZpZWxkcyBvbiB0aGUgcmVwbHkgc3RpbGwgZ2V0IHNldCBmcm9tIGBpbl9yZXBseV90b19zdGF0dXNfaWRfc3RyYCwgYnV0XG4gKiBgZmlsdGVyUmVsYXRlZGAgaGFzIG5vdGhpbmcgdG8ga2VlcCBcdTIwMTQgdGhlcmUgaXMgbm8gcGFyZW50IG5vZGUgaW4gdGhlXG4gKiBiYXRjaCB0byBrZWVwLiBSZXN1bHQ6IHRoZSBhcmNoaXZlIHNob3dzIERIU2dvdidzIHJlcGx5IGJ1dCBub3QgdGhlXG4gKiBvcmlnaW5hbCBpdCdzIHJlcGx5aW5nIHRvLiBTeW1tZXRyaWMgcHJvYmxlbSBmb3Igb3JwaGFuZWQgcXVvdGUgLyBSVFxuICogcG9pbnRlcnMuXG4gKlxuICogUmV1c2luZyB0aGUgbWVkaWEtY3Jhd2wgcXVldWUgKyBsb29wIG1lYW5zIG5vIG5ldyBVSTsgdGhlIHVzZXIgYWxyZWFkeVxuICogc3RhcnRzIGl0IG1hbnVhbGx5IHdoZW4gdGhleSB3YW50IHRvIGZldGNoIHBhcnRpYWwtY2FwdHVyZWQgdHdlZXRzLlxuICogU2FtZSBkZWR1cCBydWxlcyBhcHBseSAoY29tbWl0dGVkIFx1MjE5MiBza2lwOyBhbHJlYWR5IHF1ZXVlZCBcdTIxOTIgbm8tb3ApLlxuICpcbiAqIFdlIG9ubHkgd2FsayB0aGUgdHdlZXRzIHRoYXQgc3Vydml2ZWQgYGZpbHRlclJlbGF0ZWRgIHNvIHdlIGRvbid0IGNyYXdsXG4gKiBwYXJlbnRzIG9mIHJhbmRvbSByZXBsaWVzIHRoYXQgd291bGRuJ3QgaGF2ZSBiZWVuIGtlcHQgYW55d2F5LlxuICovXG5hc3luYyBmdW5jdGlvbiBlbnF1ZXVlTWlzc2luZ1BhcmVudHMoXG4gIHR3ZWV0czogUmVhZG9ubHlBcnJheTxDYW5vbmljYWxUd2VldD4sXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8dm9pZD4ge1xuICBpZiAodHdlZXRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICAvLyBCdWlsZCBhIHNhbWUtYmF0Y2ggSUQgc2V0IHNvIHdlIGRvbid0IGVucXVldWUgYSBwYXJlbnQgdGhhdCBhbHJlYWR5XG4gIC8vIGFycml2ZWQgaW4gdGhpcyB2ZXJ5IHJlc3BvbnNlLlxuICBjb25zdCBzYW1lQmF0Y2hJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykgc2FtZUJhdGNoSWRzLmFkZCh0LnR3ZWV0X2lkKTtcblxuICBsZXQgZW5xdWV1ZWQgPSAwO1xuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgY29uc3QgcGFyZW50czogQXJyYXk8eyBpZDogc3RyaW5nOyBoaW50OiBzdHJpbmcgfCBudWxsIH0+ID0gW107XG4gICAgaWYgKHQucmVwbHlfdG9fdHdlZXRfaWQpIHtcbiAgICAgIHBhcmVudHMucHVzaCh7IGlkOiB0LnJlcGx5X3RvX3R3ZWV0X2lkLCBoaW50OiB0LnJlcGx5X3RvX2FjY291bnQgfSk7XG4gICAgfVxuICAgIGlmICh0LnF1b3RlZF90d2VldF9pZCkgcGFyZW50cy5wdXNoKHsgaWQ6IHQucXVvdGVkX3R3ZWV0X2lkLCBoaW50OiBudWxsIH0pO1xuICAgIGlmICh0LnJldHdlZXRlZF90d2VldF9pZCkgcGFyZW50cy5wdXNoKHsgaWQ6IHQucmV0d2VldGVkX3R3ZWV0X2lkLCBoaW50OiBudWxsIH0pO1xuICAgIGZvciAoY29uc3QgcCBvZiBwYXJlbnRzKSB7XG4gICAgICBpZiAoc2FtZUJhdGNoSWRzLmhhcyhwLmlkKSkgY29udGludWU7XG4gICAgICBpZiAoYXdhaXQgaXNDb21taXR0ZWQocC5pZCkpIGNvbnRpbnVlO1xuICAgICAgYXdhaXQgZW5xdWV1ZU1lZGlhQ3Jhd2wocC5oaW50LCBwLmlkKTtcbiAgICAgIGVucXVldWVkICs9IDE7XG4gICAgfVxuICB9XG4gIGlmIChlbnF1ZXVlZCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdxdWV1ZWQgbWlzc2luZyBwYXJlbnQgdHdlZXRzIGZvciBkZXRhaWwtcGFnZSBjcmF3bCcsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgZW5xdWV1ZWQsXG4gICAgICBxdWV1ZV90b3RhbDogYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKSxcbiAgICB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVSdW5CdWZmZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICB0czogc3RyaW5nLFxuICBzb3VyY2VVcmw6IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZ1xuKTogUHJvbWlzZTxSdW5CdWZmZXI+IHtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSk7XG4gIGlmIChjdXIpIHJldHVybiBjdXI7XG4gIGNvbnN0IGJ1ZjogUnVuQnVmZmVyID0ge1xuICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcbiAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgIHN0YXJ0ZWRfYXQ6IHRzLFxuICAgIGxhc3RfY2FwdHVyZV9hdDogdHMsXG4gICAgdHdlZXRzX2J5X2lkOiB7fSxcbiAgICB1bmF2YWlsYWJsZV9ieV9pZDoge30sXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcbiAgICBlbmRwb2ludHNfc2VlbjogW2VuZHBvaW50XSxcbiAgICBzb3VyY2VfdXJsOiBzb3VyY2VVcmwsXG4gIH07XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gIGF3YWl0IGluZm8oJ3J1biBzdGFydGVkJywgeyBoYW5kbGUsIHJ1bjogc2hvcnRSdW5JZChidWYucnVuX2lkKSB9KTtcbiAgcmV0dXJuIGJ1Zjtcbn1cblxuLy8gLS0tIEZsdXNoIGxvZ2ljIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxubGV0IGZsdXNoQ2hhaW46IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKTtcblxuaW50ZXJmYWNlIEZsdXNoSXRlbSB7XG4gIGhhbmRsZTogc3RyaW5nO1xuICBidWY6IFJ1bkJ1ZmZlcjtcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdO1xuICB1bmF2YWlsYWJsZVR3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdO1xuICByYXdQYXRoOiBzdHJpbmc7XG4gIHNlZW5QYXRoOiBzdHJpbmc7XG4gIGNhcHR1cmU6IENhcHR1cmVQYXlsb2FkO1xuICBzZWVuOiBTZWVuUGF5bG9hZDtcbiAgZGF5OiBzdHJpbmc7XG4gIHJ1blNob3J0OiBzdHJpbmc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSWRsZUJ1ZmZlcnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgY29uc3QgaGFuZGxlczogc3RyaW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xuICAgICAgaGFuZGxlcy5wdXNoKGhhbmRsZSk7XG4gICAgfVxuICB9XG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhoYW5kbGVzLCAnaWRsZScpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIE9uIHdvcmtlciB3YWtlLCBhbnkgYnVmZmVyIG9sZGVyIHRoYW4gdGhlIGlkbGUgdGhyZXNob2xkIGdldHMgYSBjaGFuY2UgdG9cbiAgLy8gY29tbWl0IGltbWVkaWF0ZWx5IFx1MjAxNCB1c2VmdWwgd2hlbiB0aGUgd29ya2VyIHdhcyBldmljdGVkIGJlZm9yZSBpZGxlLWZsdXNoLlxuICAvLyBJZiB0aGUgUEFUL293bmVyL3JlcG8gYXJlbid0IHNldCB3ZSdkIGp1c3QgZW1pdCBcImZsdXNoIGRlZmVycmVkXCIgZm9yIGV2ZXJ5XG4gIC8vIHNpbmdsZSBoYW5kbGUgaW4gc3RvcmFnZSAodGhlIGRpYWdub3N0aWMgc2hvd2VkIHRoaXMgZmlyaW5nIDMwMCsgdGltZXMgaW5cbiAgLy8gYSByb3cgd2hlbiB0aGUgZXh0ZW5zaW9uIHdva2UgYmVmb3JlIHNldHRpbmdzIGxvYWQpLCBzbyBzaG9ydC1jaXJjdWl0XG4gIC8vIGhlcmUgaW5zdGVhZC5cbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBjb25zdCBoYW5kbGVzOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XG4gICAgICBoYW5kbGVzLnB1c2goaGFuZGxlKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgZmx1c2hIYW5kbGVzKGhhbmRsZXMsICd3YWtlJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoQWxsKHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKE9iamVjdC5rZXlzKGFsbCksIHJlYXNvbik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlKGhhbmRsZTogc3RyaW5nLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBmbHVzaEhhbmRsZXMoW2hhbmRsZV0sIHJlYXNvbik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlcyhoYW5kbGVzOiBzdHJpbmdbXSwgcmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdW5pcXVlID0gWy4uLm5ldyBTZXQoaGFuZGxlcyldLmZpbHRlcigoaCkgPT4gaC5sZW5ndGggPiAwKTtcbiAgaWYgKHVuaXF1ZS5sZW5ndGggPT09IDApIHJldHVybjtcbiAgY29uc3QgcnVuID0gZmx1c2hDaGFpbi50aGVuKCgpID0+IGZsdXNoSGFuZGxlc0xvY2tlZCh1bmlxdWUsIHJlYXNvbikpO1xuICBmbHVzaENoYWluID0gcnVuLmNhdGNoKCgpID0+IHt9KTtcbiAgcmV0dXJuIHJ1bjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGVzTG9ja2VkKGhhbmRsZXM6IHN0cmluZ1tdLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGNvbnN0IGl0ZW1zOiBGbHVzaEl0ZW1bXSA9IFtdO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBoYW5kbGVzKSB7XG4gICAgY29uc3QgYnVmID0gYWxsW2hhbmRsZV07XG4gICAgaWYgKCFidWYpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHR3ZWV0cyA9IE9iamVjdC52YWx1ZXMoYnVmLnR3ZWV0c19ieV9pZCk7XG4gICAgY29uc3QgdW5hdmFpbGFibGVUd2VldHMgPSBPYmplY3QudmFsdWVzKGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fSk7XG4gICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDAgJiYgdW5hdmFpbGFibGVUd2VldHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihoYW5kbGUpO1xuICAgICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIDApO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGl0ZW1zLnB1c2goYnVpbGRGbHVzaEl0ZW0oaGFuZGxlLCBidWYsIHR3ZWV0cywgdW5hdmFpbGFibGVUd2VldHMpKTtcbiAgfVxuICBpZiAoaXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm47XG5cbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHtcbiAgICBhd2FpdCB3YXJuKCdmbHVzaCBkZWZlcnJlZDogc2V0dGluZ3MgaW5jb21wbGV0ZScsIHtcbiAgICAgIGNvdW50OiBpdGVtcy5sZW5ndGgsXG4gICAgICBoYW5kbGVzOiBpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uaGFuZGxlKS5zbGljZSgwLCAyMCksXG4gICAgfSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICBjb25zdCBmaWxlcyA9IGl0ZW1zLmZsYXRNYXAoKGl0ZW0pID0+IFtcbiAgICB7XG4gICAgICBwYXRoOiBpdGVtLnJhd1BhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShpdGVtLmNhcHR1cmUsIG51bGwsIDIpICsgJ1xcbicpLFxuICAgIH0sXG4gICAge1xuICAgICAgcGF0aDogaXRlbS5zZWVuUGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KGl0ZW0uc2VlbiwgbnVsbCwgMikgKyAnXFxuJyksXG4gICAgfSxcbiAgXSk7XG4gIGNvbnN0IGNvbW1pdE1zZyA9IGJ1aWxkQmF0Y2hDb21taXRNZXNzYWdlKGl0ZW1zKTtcblxuICB0cnkge1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNsaWVudC5jb21taXRGaWxlcyh7XG4gICAgICBmaWxlcyxcbiAgICAgIG1lc3NhZ2U6IGNvbW1pdE1zZyxcbiAgICB9KTtcbiAgICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xuICAgICAgY29uc3QgcmVtYWluaW5nQ291bnQgPSBhd2FpdCBjbGVhckNvbW1pdHRlZFR3ZWV0c0Zyb21CdWZmZXIoaXRlbSk7XG4gICAgICAvLyBDb3VudGVyIGJ1bXA6IGFjdHVhbGx5IElOQ1JFTUVOVCB0b2RheUNvdW50IGFuZCB0b3RhbENvbW1pdHRlZCBieVxuICAgICAgLy8gdGhlIG51bWJlciBvZiB0d2VldHMgd2UganVzdCBwZXJzaXN0ZWQgKHRoZSBwcmV2aW91cyBjb2RlIHJlYWQgdGhlXG4gICAgICAvLyBleGlzdGluZyB2YWx1ZXMgYW5kIHdyb3RlIHRoZW0gYmFjaywgbGVhdmluZyB0aGUgY291bnRlciBwZWdnZWQgYXRcbiAgICAgIC8vIHplcm8pLlxuICAgICAgY29uc3QgcHJldiA9IChhd2FpdCBnZXRDb3VudGVycygpKVtpdGVtLmhhbmRsZV07XG4gICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG4gICAgICBjb25zdCBjYXJyaWVkVG9kYXkgPSBwcmV2ICYmIHByZXYudG9kYXlEYXRlID09PSB0b2RheSA/IHByZXYudG9kYXlDb3VudCA6IDA7XG4gICAgICBhd2FpdCBidW1wQ291bnRlcihpdGVtLmhhbmRsZSwge1xuICAgICAgICB0b2RheUNvdW50OiBjYXJyaWVkVG9kYXkgKyBpdGVtLnR3ZWV0cy5sZW5ndGggKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCxcbiAgICAgICAgdG9kYXlEYXRlOiB0b2RheSxcbiAgICAgICAgbGFzdENhcHR1cmVBdDogaXRlbS5idWYubGFzdF9jYXB0dXJlX2F0LFxuICAgICAgICB0b3RhbENvbW1pdHRlZDpcbiAgICAgICAgICAocHJldj8udG90YWxDb21taXR0ZWQgPz8gMCkgKyBpdGVtLnR3ZWV0cy5sZW5ndGggKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCxcbiAgICAgICAgYnVmZmVyZWRDb3VudDogcmVtYWluaW5nQ291bnQsXG4gICAgICB9KTtcbiAgICAgIC8vIFJlY29yZCBjb21taXRzIGluIHRoZSBkZWR1cCBpbmRleCBzbyB3ZSBkb24ndCByZS1jb21taXQgdGhlbSBuZXh0XG4gICAgICAvLyBicm93c2Ugd2l0aCB1bmNoYW5nZWQgZW5nYWdlbWVudC5cbiAgICAgIGNvbnN0IGlubmVyID0gaWR4W2l0ZW0uaGFuZGxlXSA/PyB7fTtcbiAgICAgIGNvbnN0IG5vd0lzbyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICAgIGZvciAoY29uc3QgdCBvZiBpdGVtLnR3ZWV0cykge1xuICAgICAgICBpbm5lclt0LnR3ZWV0X2lkXSA9IHtcbiAgICAgICAgICB0czogbm93SXNvLFxuICAgICAgICAgIHNpZzogZW5nYWdlbWVudFNpZyhcbiAgICAgICAgICAgIHQubGlrZV9jb3VudCxcbiAgICAgICAgICAgIHQucmV0d2VldF9jb3VudCxcbiAgICAgICAgICAgIHQucmVwbHlfY291bnQsXG4gICAgICAgICAgICB0LnF1b3RlX2NvdW50LFxuICAgICAgICAgICAgdC5pc190cnVuY2F0ZWRcbiAgICAgICAgICApLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCB1IG9mIGl0ZW0udW5hdmFpbGFibGVUd2VldHMpIHtcbiAgICAgICAgaW5uZXJbdS50d2VldF9pZF0gPSB7XG4gICAgICAgICAgdHM6IG5vd0lzbyxcbiAgICAgICAgICBzaWc6IHVuYXZhaWxhYmxlU2lnKHUpLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWR4W2l0ZW0uaGFuZGxlXSA9IGlubmVyO1xuICAgICAgYXdhaXQgaW5mbygnZmx1c2ggY29tbWl0dGVkJywge1xuICAgICAgICBoYW5kbGU6IGl0ZW0uaGFuZGxlLFxuICAgICAgICByZWFzb24sXG4gICAgICAgIHR3ZWV0czogaXRlbS50d2VldHMubGVuZ3RoLFxuICAgICAgICB1bmF2YWlsYWJsZTogaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIHJ1bjogaXRlbS5ydW5TaG9ydCxcbiAgICAgICAgcGF0aDogaXRlbS5yYXdQYXRoLFxuICAgICAgICBiYXRjaF9jb21taXQ6IHJlc3VsdC5jb21taXRTaGEsXG4gICAgICB9KTtcbiAgICB9XG4gICAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcbiAgICBhd2FpdCBpbmZvKCdmbHVzaCBiYXRjaCBjb21taXR0ZWQnLCB7XG4gICAgICByZWFzb24sXG4gICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXG4gICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgdHdlZXRzOiBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udHdlZXRzLmxlbmd0aCwgMCksXG4gICAgICB1bmF2YWlsYWJsZTogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCwgMCksXG4gICAgICBjb21taXQ6IHJlc3VsdC5jb21taXRTaGEsXG4gICAgfSk7XG4gICAge1xuICAgICAgY29uc3QgcHJldiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXM6ICdvaycsXG4gICAgICAgIGxvZ2luOiBwcmV2LmxvZ2luLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IHByZXYuZGVmYXVsdEJyYW5jaCxcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogcHJldi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgICAgfSk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBpZiAoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpIHtcbiAgICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgICBjb25zdCBzdGF0dXM6IENvbm5lY3Rpb25TdGF0ZVsnc3RhdHVzJ10gPVxuICAgICAgICBlcnIuY2F0ZWdvcnkgPT09ICdhdXRoJ1xuICAgICAgICAgID8gJ2F1dGgtZXJyb3InXG4gICAgICAgICAgOiBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0J1xuICAgICAgICAgICAgPyAncmF0ZS1saW1pdGVkJ1xuICAgICAgICAgICAgOiBlcnIuY2F0ZWdvcnkgPT09ICduZXR3b3JrJ1xuICAgICAgICAgICAgICA/ICduZXR3b3JrLWVycm9yJ1xuICAgICAgICAgICAgICA6IGNvbm4uc3RhdHVzO1xuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICAgIHN0YXR1cyxcbiAgICAgICAgbG9naW46IGNvbm4ubG9naW4sXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBlcnJvcjogZXJyLm1lc3NhZ2UsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IGNvbm4uZGVmYXVsdEJyYW5jaCxcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogY29ubi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OlxuICAgICAgICAgIGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnID8gZXJyLnJhdGVMaW1pdFJlc2V0QXQgOiBjb25uLnJhdGVMaW1pdFJlc2V0QXQsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGxvZ0VycignZmx1c2ggZmFpbGVkJywge1xuICAgICAgICByZWFzb24sXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcbiAgICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgICBjYXRlZ29yeTogZXJyLmNhdGVnb3J5LFxuICAgICAgICBzdGF0dXM6IGVyci5zdGF0dXMsXG4gICAgICAgIG1lc3NhZ2U6IGVyci5tZXNzYWdlLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBlcnIucmF0ZUxpbWl0UmVzZXRBdCxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBsb2dFcnIoJ2ZsdXNoIGZhaWxlZCcsIHtcbiAgICAgICAgcmVhc29uLFxuICAgICAgICBoYW5kbGVzOiBpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uaGFuZGxlKS5zbGljZSgwLCAyMCksXG4gICAgICAgIHJ1bnM6IGl0ZW1zLmxlbmd0aCxcbiAgICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcbiAgICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgICAgfSk7XG4gICAgfVxuICAgIC8vIExlYXZlIGJ1ZmZlciBpbnRhY3QgZm9yIHJldHJ5LlxuICB9IGZpbmFsbHkge1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gYnVpbGRGbHVzaEl0ZW0oXG4gIGhhbmRsZTogc3RyaW5nLFxuICBidWY6IFJ1bkJ1ZmZlcixcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdLFxuICB1bmF2YWlsYWJsZVR3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdXG4pOiBGbHVzaEl0ZW0ge1xuICBjb25zdCB0cyA9IGlzb0NvbXBhY3QoYnVmLnN0YXJ0ZWRfYXQpO1xuICBjb25zdCBkYXkgPSBidWYuc3RhcnRlZF9hdC5zbGljZSgwLCAxMCk7XG4gIGNvbnN0IHJ1blNob3J0ID0gc2hvcnRSdW5JZChidWYucnVuX2lkKTtcbiAgY29uc3QgcmF3UGF0aCA9IGByYXcvJHtoYW5kbGV9LyR7dHN9LSR7cnVuU2hvcnR9Lmpzb25gO1xuICBjb25zdCBzZWVuUGF0aCA9IGBzZWVuLyR7aGFuZGxlfS8ke3RzfS0ke3J1blNob3J0fS5qc29uYDtcbiAgcmV0dXJuIHtcbiAgICBoYW5kbGUsXG4gICAgYnVmLFxuICAgIHR3ZWV0cyxcbiAgICB1bmF2YWlsYWJsZVR3ZWV0cyxcbiAgICByYXdQYXRoLFxuICAgIHNlZW5QYXRoLFxuICAgIGRheSxcbiAgICBydW5TaG9ydCxcbiAgICBjYXB0dXJlOiB7XG4gICAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICAgIGNhcHR1cmVkX2F0OiBidWYubGFzdF9jYXB0dXJlX2F0LFxuICAgICAgZW5kcG9pbnQ6IGJ1Zi5lbmRwb2ludHNfc2Vlbi5qb2luKCcsJyksXG4gICAgICB1c2VyX2FnZW50OiBuYXZpZ2F0b3IudXNlckFnZW50LFxuICAgICAgc291cmNlX3VybDogYnVmLnNvdXJjZV91cmwsXG4gICAgICB0d2VldHMsXG4gICAgICB1bmF2YWlsYWJsZV90d2VldHM6IHVuYXZhaWxhYmxlVHdlZXRzLFxuICAgIH0sXG4gICAgc2Vlbjoge1xuICAgICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gICAgICBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogYnVmLnR3ZWV0X2lkc19vYnNlcnZlZCxcbiAgICB9LFxuICB9O1xufVxuXG5mdW5jdGlvbiBidWlsZEJhdGNoQ29tbWl0TWVzc2FnZShpdGVtczogRmx1c2hJdGVtW10pOiBzdHJpbmcge1xuICBpZiAoaXRlbXMubGVuZ3RoID09PSAxKSB7XG4gICAgY29uc3QgaXRlbSA9IGl0ZW1zWzBdITtcbiAgICBjb25zdCB1bmF2YWlsYWJsZUNvdW50ID0gaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGg7XG4gICAgY29uc3Qgc3VmZml4ID0gdW5hdmFpbGFibGVDb3VudCA+IDAgPyBgLCAke3VuYXZhaWxhYmxlQ291bnR9IHVuYXZhaWxhYmxlYCA6ICcnO1xuICAgIHJldHVybiBgY2FwdHVyZTogJHtpdGVtLmhhbmRsZX0gJHtpdGVtLmRheX0gJHtpdGVtLnR3ZWV0cy5sZW5ndGh9IHR3ZWV0JHtpdGVtLnR3ZWV0cy5sZW5ndGggPT09IDEgPyAnJyA6ICdzJ30ke3N1ZmZpeH0gKHJ1biAke2l0ZW0ucnVuU2hvcnR9KWA7XG4gIH1cbiAgY29uc3QgZGF5cyA9IFsuLi5uZXcgU2V0KGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5kYXkpKV0uc29ydCgpO1xuICBjb25zdCBkYXlMYWJlbCA9IGRheXMubGVuZ3RoID09PSAxID8gZGF5c1swXSEgOiBgJHtkYXlzWzBdfS4uJHtkYXlzW2RheXMubGVuZ3RoIC0gMV19YDtcbiAgY29uc3QgdHdlZXRDb3VudCA9IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS50d2VldHMubGVuZ3RoLCAwKTtcbiAgY29uc3QgdW5hdmFpbGFibGVDb3VudCA9IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsIDApO1xuICBjb25zdCBzdWZmaXggPSB1bmF2YWlsYWJsZUNvdW50ID4gMCA/IGAsICR7dW5hdmFpbGFibGVDb3VudH0gdW5hdmFpbGFibGVgIDogJyc7XG4gIHJldHVybiBgY2FwdHVyZSBiYXRjaDogJHtpdGVtcy5sZW5ndGh9IHJ1bnMsICR7dHdlZXRDb3VudH0gdHdlZXQke3R3ZWV0Q291bnQgPT09IDEgPyAnJyA6ICdzJ30ke3N1ZmZpeH0gKCR7ZGF5TGFiZWx9KWA7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNsZWFyQ29tbWl0dGVkVHdlZXRzRnJvbUJ1ZmZlcihpdGVtOiBGbHVzaEl0ZW0pOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBjdXJyZW50ID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcbiAgaWYgKCFjdXJyZW50KSByZXR1cm4gMDtcbiAgaWYgKGN1cnJlbnQucnVuX2lkICE9PSBpdGVtLmJ1Zi5ydW5faWQpIHJldHVybiBPYmplY3Qua2V5cyhjdXJyZW50LnR3ZWV0c19ieV9pZCkubGVuZ3RoO1xuXG4gIGNvbnN0IGNvbW1pdHRlZCA9IG5ldyBNYXAoXG4gICAgaXRlbS50d2VldHMubWFwKCh0KSA9PiBbXG4gICAgICB0LnR3ZWV0X2lkLFxuICAgICAgZW5nYWdlbWVudFNpZyh0Lmxpa2VfY291bnQsIHQucmV0d2VldF9jb3VudCwgdC5yZXBseV9jb3VudCwgdC5xdW90ZV9jb3VudCwgdC5pc190cnVuY2F0ZWQpLFxuICAgIF0pXG4gICk7XG4gIGZvciAoY29uc3QgdSBvZiBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzKSB7XG4gICAgY29tbWl0dGVkLnNldCh1LnR3ZWV0X2lkLCB1bmF2YWlsYWJsZVNpZyh1KSk7XG4gIH1cbiAgY29uc3QgcmVtYWluaW5nVHdlZXRzOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD4gPSB7fTtcbiAgZm9yIChjb25zdCBbdHdlZXRJZCwgdHdlZXRdIG9mIE9iamVjdC5lbnRyaWVzKGN1cnJlbnQudHdlZXRzX2J5X2lkKSkge1xuICAgIGNvbnN0IGNvbW1pdHRlZFNpZyA9IGNvbW1pdHRlZC5nZXQodHdlZXRJZCk7XG4gICAgY29uc3QgY3VycmVudFNpZyA9IGVuZ2FnZW1lbnRTaWcoXG4gICAgICB0d2VldC5saWtlX2NvdW50LFxuICAgICAgdHdlZXQucmV0d2VldF9jb3VudCxcbiAgICAgIHR3ZWV0LnJlcGx5X2NvdW50LFxuICAgICAgdHdlZXQucXVvdGVfY291bnQsXG4gICAgICB0d2VldC5pc190cnVuY2F0ZWRcbiAgICApO1xuICAgIGlmICghY29tbWl0dGVkU2lnIHx8IGNvbW1pdHRlZFNpZyAhPT0gY3VycmVudFNpZykge1xuICAgICAgcmVtYWluaW5nVHdlZXRzW3R3ZWV0SWRdID0geyAuLi50d2VldCB9O1xuICAgIH1cbiAgfVxuICBjb25zdCByZW1haW5pbmdVbmF2YWlsYWJsZTogUmVjb3JkPHN0cmluZywgVW5hdmFpbGFibGVUd2VldD4gPSB7fTtcbiAgZm9yIChjb25zdCBbdHdlZXRJZCwgdW5hdmFpbGFibGVdIG9mIE9iamVjdC5lbnRyaWVzKGN1cnJlbnQudW5hdmFpbGFibGVfYnlfaWQgPz8ge30pKSB7XG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcbiAgICBjb25zdCBjdXJyZW50U2lnID0gdW5hdmFpbGFibGVTaWcodW5hdmFpbGFibGUpO1xuICAgIGlmICghY29tbWl0dGVkU2lnIHx8IGNvbW1pdHRlZFNpZyAhPT0gY3VycmVudFNpZykge1xuICAgICAgcmVtYWluaW5nVW5hdmFpbGFibGVbdHdlZXRJZF0gPSB7IC4uLnVuYXZhaWxhYmxlIH07XG4gICAgfVxuICB9XG5cbiAgY29uc3QgcmVtYWluaW5nSWRzID0gbmV3IFNldChbXG4gICAgLi4uT2JqZWN0LmtleXMocmVtYWluaW5nVHdlZXRzKSxcbiAgICAuLi5PYmplY3Qua2V5cyhyZW1haW5pbmdVbmF2YWlsYWJsZSksXG4gIF0pO1xuICBjb25zdCByZW1haW5pbmdDb3VudCA9IHJlbWFpbmluZ0lkcy5zaXplO1xuICBpZiAocmVtYWluaW5nQ291bnQgPT09IDApIHtcbiAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSk7XG4gICAgcmV0dXJuIDA7XG4gIH1cblxuICBjb25zdCBuZXh0UnVuSWQgPSBuZXdSdW5JZCgpO1xuICBmb3IgKGNvbnN0IHR3ZWV0IG9mIE9iamVjdC52YWx1ZXMocmVtYWluaW5nVHdlZXRzKSkge1xuICAgIHR3ZWV0LmNhcHR1cmVfcnVuX2lkID0gbmV4dFJ1bklkO1xuICB9XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSwge1xuICAgIC4uLmN1cnJlbnQsXG4gICAgcnVuX2lkOiBuZXh0UnVuSWQsXG4gICAgc3RhcnRlZF9hdDogY3VycmVudC5sYXN0X2NhcHR1cmVfYXQsXG4gICAgdHdlZXRzX2J5X2lkOiByZW1haW5pbmdUd2VldHMsXG4gICAgdW5hdmFpbGFibGVfYnlfaWQ6IHJlbWFpbmluZ1VuYXZhaWxhYmxlLFxuICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogY3VycmVudC50d2VldF9pZHNfb2JzZXJ2ZWQuZmlsdGVyKChpZCkgPT4gcmVtYWluaW5nSWRzLmhhcyhpZCkpLFxuICB9KTtcbiAgYXdhaXQgaW5mbygnZmx1c2gga2VwdCBuZXdlciBidWZmZXJlZCB0d2VldHMnLCB7XG4gICAgaGFuZGxlOiBpdGVtLmhhbmRsZSxcbiAgICBjb21taXR0ZWRfcnVuOiBpdGVtLnJ1blNob3J0LFxuICAgIG5leHRfcnVuOiBzaG9ydFJ1bklkKG5leHRSdW5JZCksXG4gICAgcmVtYWluaW5nOiByZW1haW5pbmdDb3VudCxcbiAgfSk7XG4gIHJldHVybiByZW1haW5pbmdDb3VudDtcbn1cblxuLy8gLS0tIENhcHR1cmUtbm93IC8gY2FwdHVyZS1hbGwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlTm93KGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGFsbG93TWFudWFsQ2FwdHVyZVdpbmRvdygpO1xuICAvLyBMYW5kIG9uIHRoZSBSZXBsaWVzIHRhYiBzbyBYIGZldGNoZXMgdmlhIFVzZXJUd2VldHNBbmRSZXBsaWVzIFx1MjAxNCB0aGF0XG4gIC8vIGVuZHBvaW50IHJldHVybnMgYm90aCB0b3AtbGV2ZWwgcG9zdHMgYW5kIHJlcGxpZXMsIHdoaWNoIGlzIHRoZSBzdXBlcnNldFxuICAvLyB3ZSB3YW50IGZvciB0aGUgYXJjaGl2ZS4gVGhlIHBsYWluIGAvPGhhbmRsZT5gIFVSTCBoaXRzIFVzZXJUd2VldHMsXG4gIC8vIHdoaWNoIG9taXRzIHJlcGxpZXMuIFRoZSBwYWdlLWhvb2sgaW50ZXJjZXB0cyBlaXRoZXIgZW5kcG9pbnQsIGJ1dFxuICAvLyBmb3JjaW5nIHRoZSBicm9hZGVyIHRhYiBvbiB1c2VyLWluaXRpYXRlZCBjYXB0dXJlcyBpcyB0aGUgcmlnaHQgZGVmYXVsdC5cbiAgY29uc3QgdGFyZ2V0VXJsID0gYGh0dHBzOi8veC5jb20vJHtoYW5kbGV9L3dpdGhfcmVwbGllc2A7XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtbm93IHJlcXVlc3RlZCcsIHsgaGFuZGxlLCB0YWI6ICd3aXRoX3JlcGxpZXMnIH0pO1xuICBpZiAoIShhd2FpdCBnZXRSdW5CdWZmZXIoaGFuZGxlKSkpIHtcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwge1xuICAgICAgcnVuX2lkOiBuZXdSdW5JZCgpLFxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICAgIHN0YXJ0ZWRfYXQ6IG5vdyxcbiAgICAgIGxhc3RfY2FwdHVyZV9hdDogbm93LFxuICAgICAgdHdlZXRzX2J5X2lkOiB7fSxcbiAgICAgIHVuYXZhaWxhYmxlX2J5X2lkOiB7fSxcbiAgICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogW10sXG4gICAgICBlbmRwb2ludHNfc2VlbjogW10sXG4gICAgICBzb3VyY2VfdXJsOiB0YXJnZXRVcmwsXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogdGFyZ2V0VXJsLCBhY3RpdmU6IHRydWUgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVBbGwoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgYXdhaXQgaW5mbygnY2FwdHVyZS1hbGwgcmVxdWVzdGVkJywgeyBjb3VudDogYWNjb3VudHMubGVuZ3RoIH0pO1xuICBmb3IgKGNvbnN0IGEgb2YgYWNjb3VudHMpIHtcbiAgICBhd2FpdCBjYXB0dXJlTm93KGEuaGFuZGxlKTtcbiAgfVxufVxuXG4vKipcbiAqIENhcHR1cmUgd2hhdGV2ZXIgdGhlIHVzZXIgaXMgY3VycmVudGx5IGxvb2tpbmcgYXQ6IGVuc3VyZXMgcGFnZS1ob29rIGlzXG4gKiBwYXRjaGVkIGludG8gdGhlIGFjdGl2ZSB0YWIsIHRoZW4gbnVkZ2VzIHRoZSBwYWdlIHdpdGggYSBwcm9ncmFtbWF0aWNcbiAqIHNjcm9sbCBzbyBYIGZpcmVzIGFub3RoZXIgYmF0Y2ggb2YgR3JhcGhRTCByZXF1ZXN0cyB3ZSBjYW4gaW50ZXJjZXB0LlxuICpcbiAqIExlc3MgZGlzcnVwdGl2ZSB0aGFuIGBDYXB0dXJlIG5vd2AgKG5vIG5ldyB0YWIsIG5vIG5hdmlnYXRpb24pIGFuZCB3b3Jrc1xuICogZm9yIGFyYml0cmFyeSBYIFVSTHMgKHNwZWNpZmljIHR3ZWV0IHRocmVhZHMsIHNlYXJjaCByZXN1bHRzLCBsaXN0cylcbiAqIHRoYXQgZG9uJ3QgbWFwIGNsZWFubHkgdG8gb25lIG9mIHRoZSBjb25maWd1cmVkIGhhbmRsZXMuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVUaGlzUGFnZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XG4gIHRyeSB7XG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGNvdWxkIG5vdCBxdWVyeSBhY3RpdmUgdGFiJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgdGFiID0gdGFic1swXTtcbiAgaWYgKCF0YWIgfHwgdHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicgfHwgIXRhYi51cmwpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogbm8gYWN0aXZlIHRhYicpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIS9eaHR0cHM6XFwvXFwvKHh8dHdpdHRlcilcXC5jb21cXC8vLnRlc3QodGFiLnVybCkpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogYWN0aXZlIHRhYiBpcyBub3Qgb24geC5jb20gLyB0d2l0dGVyLmNvbScsIHtcbiAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsKSxcbiAgICB9KTtcbiAgICByZXR1cm47XG4gIH1cbiAgYXdhaXQgaW5mbygnY2FwdHVyZS10aGlzLXBhZ2UgcmVxdWVzdGVkJywgeyB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCkgfSk7XG4gIC8vIChSZS0paW5qZWN0IHRoZSBwYWdlLWhvb2sgKyBpc29sYXRlZCBjb250ZW50IHNjcmlwdCBzbyBmZXRjaC9YSFIgYXJlXG4gIC8vIHBhdGNoZWQgZXZlbiBvbiB0YWJzIG9wZW5lZCBiZWZvcmUgdGhlIGV4dGVuc2lvbiByZWxvYWRlZC5cbiAgdHJ5IHtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICBmaWxlczogWydwYWdlLWhvb2suanMnXSxcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICB9KTtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiByZS1pbmplY3QgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxuICAvLyBOdWRnZSBYIHRvIGZpcmUgbW9yZSBHcmFwaFFMIHJlcXVlc3RzIGJ5IHNjcm9sbGluZy4gTW9zdCB0aW1lbGluZSAvXG4gIC8vIGNvbnZlcnNhdGlvbiB2aWV3cyBmZXRjaCBvbiBpbnRlcnNlY3Rpb24tb2JzZXJ2ZXIgdHJpZ2dlcnMuXG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgZnVuYzogKCkgPT4ge1xuICAgICAgICBjb25zdCBoID0gd2luZG93LmlubmVySGVpZ2h0O1xuICAgICAgICB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgNjAwKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgMTIwMCk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogc2Nyb2xsLW51ZGdlIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbn1cblxuLy8gLS0tIFJlZmV0Y2ggbG9vcCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vXG4vLyBYIHRydW5jYXRlcyBsb25nIHR3ZWV0cyBpbiB0aW1lbGluZSBwYXlsb2FkcyBcdTIwMTQgYG5vdGVfdHdlZXRgIGlzIG9ubHlcbi8vIGlubGluZWQgZm9yIHNvbWUgZW5kcG9pbnRzLiBSZS1vcGVuaW5nIGVhY2ggdHJ1bmNhdGVkIHR3ZWV0J3MgZGV0YWlsIHBhZ2Vcbi8vIGNhdXNlcyB0aGUgcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkuIFRoZSBsb29wXG4vLyBkcml2ZXMgdGhhdCBieSBuYXZpZ2F0aW5nIGEgc2luZ2xlIGRlZGljYXRlZCB0YWIgdGhyb3VnaCB0aGUgcXVldWUsIG9uZVxuLy8gdHdlZXQgYXQgYSB0aW1lLCBnYXRlZCBvbiB0aGUgcGFnZS1ob29rIGFjdHVhbGx5IGluZ2VzdGluZyBhIHJlc3BvbnNlIGZvclxuLy8gdGhlIHR3ZWV0IHdlIGp1c3QgbmF2aWdhdGVkIHRvIChzbyBkZWxldGVkIC8gcGF5d2FsbGVkIC8gNDA0J2QgdHdlZXRzXG4vLyBkb24ndCBtYWtlIHVzIHNwaW4gYW5kIHNvIHdlIGRvbid0IHNsYW0gWCB3aXRoIHJlZnJlc2hlcyBmYXN0ZXIgdGhhbiB0aGVcbi8vIHRhYiBjYW4gbG9hZCkuXG5cbmNvbnN0IFJFRkVUQ0hfVEFCX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3JlZmV0Y2hfdGFiX2lkX18nO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoUkVGRVRDSF9UQUJfS0VZKTtcbiAgY29uc3QgaWQgPSBzdG9yZWRbUkVGRVRDSF9UQUJfS0VZXTtcbiAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ251bWJlcicgPyBpZCA6IG51bGw7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hUYWJJZChpZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoaWQgPT09IG51bGwpIHtcbiAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFJFRkVUQ0hfVEFCX0tFWSk7XG4gIH0gZWxzZSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtSRUZFVENIX1RBQl9LRVldOiBpZCB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydFJlZmV0Y2hMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcbiAgY29uc3QgdG90YWwgPSBhd2FpdCByZWZldGNoUXVldWVUb3RhbCgpO1xuICBpZiAodG90YWwgPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoOiBub3RoaW5nIHF1ZXVlZCcpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3Qgc2Vjb25kcyA9IE1hdGgubWluKFxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYykpXG4gICk7XG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHtcbiAgICB0b3RhbEF0U3RhcnQ6IHRvdGFsLFxuICAgIHByb2Nlc3NlZDogMCxcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBpbmZsaWdodDogbnVsbCxcbiAgfSk7XG4gIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHMpO1xuICB2b2lkIHJlZmV0Y2hUaWNrKCk7XG4gIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBzdGFydGVkJywgeyBxdWV1ZWQ6IHRvdGFsLCBpbnRlcnZhbF9zZWM6IHNlY29uZHMgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmxldCByZWZldGNoSW50ZXJ2YWxIYW5kbGU6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzOiBudW1iZXIpOiB2b2lkIHtcbiAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgY2xlYXJJbnRlcnZhbChyZWZldGNoSW50ZXJ2YWxIYW5kbGUpO1xuICByZWZldGNoSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgdm9pZCByZWZldGNoVGljaygpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybigncmVmZXRjaCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcbn1cblxuZnVuY3Rpb24gc3RvcFJlZmV0Y2hJbnRlcnZhbCgpOiB2b2lkIHtcbiAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcbiAgICByZWZldGNoSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbFJlZmV0Y2hMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdyZWZldGNoLXRpY2snKTsgLy8gbGVnYWN5IGNsZWFudXBcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRSZWZldGNoVGFiSWQoKTtcbiAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24obnVsbCk7XG4gIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBjYW5jZWxsZWQnLCB7XG4gICAgaGFkX3RhYjogdGFiSWQgIT09IG51bGwsXG4gICAgcHJvY2Vzc2VkOiBzZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZmV0Y2hUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgc2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGlmIChzZXNzID09PSBudWxsKSB7XG4gICAgLy8gTG9vcCB3YXMgY2FuY2VsbGVkIG9yIG5ldmVyIHN0YXJ0ZWQ7IG5vdGhpbmcgdG8gZG8uXG4gICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBXYWl0LWZvci1pbmdlc3QgZ3VhcmQ6IGlmIHdlJ3JlIHN0aWxsIGV4cGVjdGluZyBhIGNhcHR1cmUgZm9yIHRoZVxuICAvLyBwcmV2aW91c2x5LW5hdmlnYXRlZCB0YXJnZXQsIG9ubHkgYWR2YW5jZSBvbmNlIHdlJ3ZlIGVpdGhlciBzZWVuIHRoZVxuICAvLyBjYXB0dXJlIChvbkdyYXBocWxDYXB0dXJlIGNsZWFycyBgaW5mbGlnaHRgKSBvciBoaXQgdGhlIHRpbWVvdXQuXG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xuICAgIGlmIChlbGFwc2VkIDwgSU5HRVNUX1dBSVRfTVMpIHtcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBcdTIwMTQgcGFnZS1ob29rIG1heSB5ZXQgY2FwdHVyZSB0aGUgcmVzcG9uc2UuXG4gICAgfVxuICAgIC8vIFRpbWVkIG91dC4gVHJlYXQgYXMgXCJ0aGlzIHRhcmdldCB3b24ndCBpbmdlc3RcIiBhbmQgZHJvcCBpdC5cbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoOiB0YXJnZXQgdGltZWQgb3V0IHdhaXRpbmcgZm9yIGluZ2VzdCcsIHtcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXG4gICAgICB3YWl0ZWRfbXM6IGVsYXBzZWQsXG4gICAgfSk7XG4gICAgLy8gRmluZCB3aGljaCBoYW5kbGUgdGhpcyBpZCBpcyBxdWV1ZWQgdW5kZXIgc28gd2UgY2FuIGRlcXVldWUgaXQuXG4gICAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICAgIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgICAgaWYgKGlkcy5pbmNsdWRlcyhzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpKSB7XG4gICAgICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKGhhbmRsZSwgc2Vzcy5pbmZsaWdodC50d2VldElkKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24oc2Vzcyk7XG4gIH1cblxuICBjb25zdCB0YXJnZXQgPSBhd2FpdCBuZXh0UmVmZXRjaFRhcmdldCgpO1xuICBpZiAoIXRhcmdldCkge1xuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICBhd2FpdCBzZXRSZWZldGNoVGFiSWQobnVsbCk7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24obnVsbCk7XG4gICAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuaGFuZGxlfS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRSZWZldGNoVGFiSWQoKTtcbiAgaWYgKHRhYklkICE9PSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdGFiSWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiBmYWxzZSB9KTtcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkID09PSAnbnVtYmVyJykgYXdhaXQgc2V0UmVmZXRjaFRhYklkKHRhYi5pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy51cGRhdGUodGFiSWQsIHsgdXJsIH0pO1xuICAgIH1cbiAgICBzZXNzID0gKGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCkpID8/IHNlc3M7XG4gICAgc2Vzcy5pbmZsaWdodCA9IHtcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2ggdGljaycsIHtcbiAgICAgIGhhbmRsZTogdGFyZ2V0LmhhbmRsZSxcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIHJlbWFpbmluZzogYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKSxcbiAgICAgIHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQsXG4gICAgICB0b3RhbF9hdF9zdGFydDogc2Vzcy50b3RhbEF0U3RhcnQsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ3JlZmV0Y2ggbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2godGFyZ2V0LmhhbmRsZSwgdGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24oc2Vzcyk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuLy8gLS0tIE1lZGlhLWNyYXdsIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vXG4vLyBNaXJyb3JzIHRoZSByZWZldGNoIGxvb3AgYnV0IHRhcmdldHMgdGhlIG1lZGlhLWNyYXdsIHF1ZXVlOiB0d2VldHMgdGhhdFxuLy8gdGhlIG5vcm1hbGl6ZXIgb2JzZXJ2ZWQgdmlhIHRoZSBNZWRpYSB0YWIgLyBVc2VyTWVkaWEgZW5kcG9pbnQgd2l0aFxuLy8gaW5zdWZmaWNpZW50IGRhdGEgdG8gYnVpbGQgYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gVGhlIGNyYXdsIGxvb3Agd2Fsa3Ncbi8vIGEgZGVkaWNhdGVkIHRhYiB0aHJvdWdoIGVhY2ggdHdlZXQncyBkZXRhaWwgcGFnZSAoaGFuZGxlLWxlc3MgVVJMIGZvcm1cbi8vIHdoZW4gdGhlIGhpbnQtaGFuZGxlIGlzIG1pc3NpbmcpLCBhdCB0aGUgYXV0by1zY3JvbGwgY2FkZW5jZSwgc28gdGhlXG4vLyBwYWdlLWhvb2sgY2FuIGNhcHR1cmUgdGhlIHJlYWwgdHdlZXQgc2hhcGUuXG5cbmNvbnN0IE1FRElBX0NSQVdMX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV9tZWRpYV9jcmF3bF90YWJfaWRfXyc7XG5cbmFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xUYWJJZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChNRURJQV9DUkFXTF9UQUJfS0VZKTtcbiAgY29uc3QgaWQgPSBzdG9yZWRbTUVESUFfQ1JBV0xfVEFCX0tFWV07XG4gIHJldHVybiB0eXBlb2YgaWQgPT09ICdudW1iZXInID8gaWQgOiBudWxsO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsVGFiSWQoaWQ6IG51bWJlciB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGlkID09PSBudWxsKSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKE1FRElBX0NSQVdMX1RBQl9LRVkpO1xuICBlbHNlIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbTUVESUFfQ1JBV0xfVEFCX0tFWV06IGlkIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydE1lZGlhQ3Jhd2xMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcbiAgY29uc3QgdG90YWwgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xuICBpZiAodG90YWwgPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogbm90aGluZyBxdWV1ZWQnKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxuICApO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbih7XG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcbiAgICBwcm9jZXNzZWQ6IDAsXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgaW5mbGlnaHQ6IG51bGwsXG4gIH0pO1xuICBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzKTtcbiAgdm9pZCBtZWRpYUNyYXdsVGljaygpO1xuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxubGV0IG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZTogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xuICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XG4gIG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIG1lZGlhQ3Jhd2xUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCdtZWRpYS1jcmF3bCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcbn1cblxuZnVuY3Rpb24gc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpOiB2b2lkIHtcbiAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwobWVkaWFDcmF3bEludGVydmFsSGFuZGxlKTtcbiAgICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbE1lZGlhQ3Jhd2xMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFRhYklkKCk7XG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZChudWxsKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcbiAgICBwcm9jZXNzZWQ6IHNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBzZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgaWYgKHNlc3MgPT09IG51bGwpIHtcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xuICAgIGlmIChlbGFwc2VkIDwgSU5HRVNUX1dBSVRfTVMpIHtcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBvbiB0aGUgcGFnZS1ob29rXG4gICAgfVxuICAgIGF3YWl0IHdhcm4oJ21lZGlhLWNyYXdsOiB0YXJnZXQgdGltZWQgb3V0IHdhaXRpbmcgZm9yIGluZ2VzdCcsIHtcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXG4gICAgICB3YWl0ZWRfbXM6IGVsYXBzZWQsXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2woc2Vzcy5pbmZsaWdodC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xuICB9XG5cbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKG51bGwpO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG51bGwpO1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gU2tpcCBpZiBhbHJlYWR5IGluIHRoZSBhcmNoaXZlIFx1MjAxNCBwYXJ0aWFsIGNhcHR1cmVzIGNhbiBvdXRsaXZlIGFcbiAgLy8gc2VwYXJhdGUgZnVsbCBjYXB0dXJlIHBhdGguXG4gIGlmIChhd2FpdCBpc0NvbW1pdHRlZCh0YXJnZXQudHdlZXRJZCkpIHtcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8vIFdoZW4gd2UgZG9uJ3Qga25vdyB0aGUgcGFyZW50J3MgYXV0aG9yIGhhbmRsZSAocXVvdGUvUlQgb2YgYSB0d2VldFxuICAvLyBYIHN0cmlwcGVkLCBvciBhIFVzZXJNZWRpYSB0aHVtYm5haWwgdGhhdCBsYWNrZWQgdGhlIGF1dGhvciBibG9jayksXG4gIC8vIGZhbGwgYmFjayB0byBgL2kvd2ViL3N0YXR1cy88aWQ+YC4gWCByZXNvbHZlcyBpdCB0byB0aGUgY29ycmVjdFxuICAvLyBkZXRhaWwgcGFnZSwgd2hpY2ggaXMgZW5vdWdoIGZvciB0aGUgcGFnZS1ob29rIHRvIGluZ2VzdCBhXG4gIC8vIFR3ZWV0RGV0YWlsIHJlc3BvbnNlLlxuICBjb25zdCB1cmwgPVxuICAgIHRhcmdldC5idWNrZXQgPT09ICdfdW5rbm93bidcbiAgICAgID8gYGh0dHBzOi8veC5jb20vaS93ZWIvc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YFxuICAgICAgOiBgaHR0cHM6Ly94LmNvbS8ke3RhcmdldC5idWNrZXR9L3N0YXR1cy8ke3RhcmdldC50d2VldElkfWA7XG4gIGxldCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xuICBpZiAodGFiSWQgIT09IG51bGwpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmdldCh0YWJJZCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICB0YWJJZCA9IG51bGw7XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgaWYgKHRhYklkID09PSBudWxsKSB7XG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xuICAgICAgaWYgKHR5cGVvZiB0YWIuaWQgPT09ICdudW1iZXInKSBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQodGFiLmlkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XG4gICAgfVxuICAgIHNlc3MgPSAoYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKSkgPz8gc2VzcztcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xuICAgICAgdHdlZXRJZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBuYXZpZ2F0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgdGljaycsIHtcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIGhpbnRfaGFuZGxlOiB0YXJnZXQuYnVja2V0ID09PSAnX3Vua25vd24nID8gbnVsbCA6IHRhcmdldC5idWNrZXQsXG4gICAgICByZW1haW5pbmc6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bCBuYXZpZ2F0ZSBmYWlsZWQ7IGRyb3BwaW5nIHRhcmdldCcsIHtcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICB9KTtcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG4vLyAtLS0gUXVhcmFudGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBxdWFyYW50aW5lKFxuICByZWFzb246IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgdXJsOiBzdHJpbmcsXG4gIHJhdzogdW5rbm93bixcbiAgZXJyOiB1bmtub3duXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgbG9nRXJyKCdxdWFyYW50aW5pbmcgY2FwdHVyZScsIHsgcmVhc29uLCBlbmRwb2ludCwgdXJsLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSByZXR1cm47XG4gIGNvbnN0IHBheWxvYWQ6IFF1YXJhbnRpbmVQYXlsb2FkID0ge1xuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgIHJlYXNvbixcbiAgICBlbmRwb2ludCxcbiAgICBjYXB0dXJlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNvdXJjZV91cmw6IHVybCxcbiAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIHJhdyxcbiAgfTtcbiAgY29uc3QgdHMgPSBpc29Db21wYWN0KHBheWxvYWQuY2FwdHVyZWRfYXQpO1xuICBjb25zdCBoYXNoID0gYXdhaXQgc2hhOChKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XG4gIGNvbnN0IHBhdGggPSBgcmF3L19xdWFyYW50aW5lLyR7dHN9LSR7aGFzaH0uanNvbmA7XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgYXdhaXQgY2xpZW50LnB1dEZpbGUoe1xuICAgICAgcGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHBheWxvYWQsIG51bGwsIDIpICsgJ1xcbicpLFxuICAgICAgbWVzc2FnZTogYHF1YXJhbnRpbmU6ICR7cmVhc29ufSAke2VuZHBvaW50fWAsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKHFlcnIpIHtcbiAgICBhd2FpdCBsb2dFcnIoJ3F1YXJhbnRpbmUgY29tbWl0IGZhaWxlZCcsIHsgLi4uZGVzY3JpYmVFcnJvcihxZXJyKSB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzaGE4KHM6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGJ1ZiA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcbiAgY29uc3QgZGlnZXN0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBidWYpO1xuICBjb25zdCBoZXggPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGRpZ2VzdCkpXG4gICAgLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcbiAgICAuam9pbignJyk7XG4gIHJldHVybiBoZXguc2xpY2UoMCwgOCk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHZlcmlmaWNhdGlvbiAmIGFjY291bnRzIGxpc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5Q29ubmVjdGlvbihmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgbG9naW46IG51bGwsXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGlmICghZm9yY2UpIHtcbiAgICAvLyBTa2lwIGlmIHdlJ3JlIGluc2lkZSB0aGUgcmVwb3J0ZWQgcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IHJlLWNoZWNraW5nXG4gICAgLy8gYmVmb3JlIHJlc2V0IGp1c3Qgd2FzdGVzIG1vcmUgb2YgdGhlIHNhbWUgZXhoYXVzdGVkIHF1b3RhIGFuZCBrZWVwc1xuICAgIC8vIHRoZSA0MDNzIGNvbWluZy5cbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xuICAgICAgY29uc3Qgbm93U2VjID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gICAgICBpZiAobm93U2VjIDwgY29ubi5yYXRlTGltaXRSZXNldEF0KSByZXR1cm47XG4gICAgfVxuICAgIC8vIEFwcGx5IHRoZSBwZXJpb2RpYy1jaGVjayBnYXRlIHRvIGV2ZXJ5IHN0YXR1cywgbm90IGp1c3QgJ29rJy4gVGhlXG4gICAgLy8gcHJldmlvdXMgYmVoYXZpb3IgcmUtdmVyaWZpZWQgb24gZXZlcnkgd2FrZSB3aGVuZXZlciB0aGUgY29ubmVjdGlvblxuICAgIC8vIHdhc24ndCAnb2snLCB3aGljaCBkdXJpbmcgYSByYXRlLWxpbWl0IHdpbmRvdyBtZWFudCAyIEFQSSBjYWxscyBwZXJcbiAgICAvLyBTVyB3YWtlICh2ZXJpZnlSZXBvQWNjZXNzIGRvZXMgR0VUIC91c2VyICsgR0VUIC9yZXBvcy97b30ve3J9KS5cbiAgICBpZiAoY29ubi5jaGVja2VkQXQpIHtcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGNvbm4uY2hlY2tlZEF0KTtcbiAgICAgIGlmIChhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHIgPSBhd2FpdCBjbGllbnQudmVyaWZ5UmVwb0FjY2VzcygpO1xuICAgIC8vIFByb2JlIHRoZSBjb25maWd1cmVkIGJyYW5jaC4gQSBub24tZGVmYXVsdCBicmFuY2ggaXMgZmluZSBcdTIwMTQgaXQnc1xuICAgIC8vIHJvdXRpbmUgdG8gY2FwdHVyZSBpbnRvIGEgd29ya2luZyBicmFuY2ggXHUyMDE0IGJ1dCBhICptaXNzaW5nKiBicmFuY2hcbiAgICAvLyB3b3VsZCA0MjIgZXZlcnkgY29tbWl0LlxuICAgIGxldCBicmFuY2hPayA9IHRydWU7XG4gICAgaWYgKHNldHRpbmdzLmJyYW5jaCAmJiBzZXR0aW5ncy5icmFuY2ggIT09IHIuZGVmYXVsdF9icmFuY2gpIHtcbiAgICAgIGJyYW5jaE9rID0gYXdhaXQgY2xpZW50LmJyYW5jaEV4aXN0cyhzZXR0aW5ncy5icmFuY2gpO1xuICAgIH1cbiAgICBjb25zdCBjaGVja1dyaXRlID0gZm9yY2UgfHwgaXNXcml0ZUF1dGhFcnJvcihjb25uLmVycm9yKTtcbiAgICBpZiAoYnJhbmNoT2sgJiYgY2hlY2tXcml0ZSkge1xuICAgICAgYXdhaXQgY2xpZW50LnZlcmlmeVdyaXRlQWNjZXNzKCk7XG4gICAgfVxuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnb2snLFxuICAgICAgbG9naW46IHIubG9naW4sXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgZGVmYXVsdEJyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGJyYW5jaE9rLFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbiAgICB9KTtcbiAgICBhd2FpdCBpbmZvKCdjb25uZWN0aW9uIHZlcmlmaWVkJywge1xuICAgICAgbG9naW46IHIubG9naW4sXG4gICAgICByZXBvOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgY29uZmlndXJlZF9icmFuY2g6IHNldHRpbmdzLmJyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRfYnJhbmNoX2V4aXN0czogYnJhbmNoT2ssXG4gICAgICB3cml0ZV9hY2Nlc3M6IGNoZWNrV3JpdGUgPyAnY2hlY2tlZCcgOiAnbm90X2NoZWNrZWQnLFxuICAgIH0pO1xuICAgIGlmICghYnJhbmNoT2spIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2NvbmZpZ3VyZWQgYnJhbmNoIGRvZXMgbm90IGV4aXN0IG9uIHJlbW90ZScsIHtcbiAgICAgICAgY29uZmlndXJlZDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgICAgZml4OiAnb3BlbiBTZXR0aW5ncyBhbmQgY2hhbmdlIGJyYW5jaCB0byAnICsgci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc3QgY2F0ID0gZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgPyBlcnIuY2F0ZWdvcnkgOiAndW5rbm93bic7XG4gICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgIGNhdCA9PT0gJ2F1dGgnXG4gICAgICAgID8gJ2F1dGgtZXJyb3InXG4gICAgICAgIDogY2F0ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgOiBjYXQgPT09ICduZXR3b3JrJ1xuICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgIDogJ2F1dGgtZXJyb3InO1xuICAgIGNvbnN0IHJlc2V0QXQgPVxuICAgICAgZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgY2F0ID09PSAncmF0ZS1saW1pdCcgPyBlcnIucmF0ZUxpbWl0UmVzZXRBdCA6IG51bGw7XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXMsXG4gICAgICBsb2dpbjogbnVsbCxcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKS5tZXNzYWdlLFxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiByZXNldEF0LFxuICAgIH0pO1xuICAgIGF3YWl0IHdhcm4oJ2Nvbm5lY3Rpb24gY2hlY2sgZmFpbGVkJywge1xuICAgICAgY2F0ZWdvcnk6IGNhdCxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjY291bnRzTGlzdChmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0KSB7XG4gICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICghZm9yY2UpIHtcbiAgICAvLyBTa2lwIHdoaWxlIGluc2lkZSBhIGtub3duIHJhdGUtbGltaXQgd2luZG93IFx1MjAxNCBhY2NvdW50cy55YW1sIGlzIGZldGNoZWRcbiAgICAvLyB2aWEgYXV0aGVudGljYXRlZCByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLCB3aGljaCBjb3VudHMgYWdhaW5zdCB0aGVcbiAgICAvLyBzYW1lIHF1b3RhLlxuICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcbiAgICAgIGNvbnN0IG5vd1NlYyA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBTa2lwIGlmIHdlIHJlZnJlc2hlZCByZWNlbnRseS4gYWNjb3VudHMueWFtbCBjaGFuZ2VzIHJhcmVseSBcdTIwMTQgdGhlIG9sZFxuICAgIC8vIGNvZGUgcmUtZmV0Y2hlZCBpdCBvbiBldmVyeSBTVyB3YWtlLCB3aGljaCBkdXJpbmcgaGVhdnkgYnJvd3NpbmcgbWVhbnRcbiAgICAvLyBhIEdpdEh1YiBjYWxsIGV2ZXJ5IGZldyBzZWNvbmRzIGV2ZW4gd2hlbiBub3RoaW5nIHdhcyBiZWluZyBjYXB0dXJlZC5cbiAgICBjb25zdCBsYXN0UmVmcmVzaGVkID0gYXdhaXQgZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpO1xuICAgIGlmIChsYXN0UmVmcmVzaGVkKSB7XG4gICAgICBjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShsYXN0UmVmcmVzaGVkKTtcbiAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYWdlKSAmJiBhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCBjbGllbnQuZmV0Y2hSYXdUZXh0KCdjb25maWcvYWNjb3VudHMueWFtbCcpO1xuICAgIGlmICghdGV4dCkge1xuICAgICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIG5vdCBmb3VuZCBpbiByZXBvOyB1c2luZyBmYWxsYmFjaycpO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlQWNjb3VudHNZYW1sKHRleHQpO1xuICAgIGlmIChwYXJzZWQubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIHBhcnNlZCBlbXB0eTsga2VlcGluZyBmYWxsYmFjaycpO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGF3YWl0IHNldEFjY291bnRzKHBhcnNlZCk7XG4gICAgYXdhaXQgcmVmcmVzaEFyY2hpdmVTbmFwc2hvdChjbGllbnQsIGZvcmNlKTtcbiAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgaWYgKGZvcmNlKSBhd2FpdCBpbmZvKCdhY2NvdW50cyBsaXN0IHJlZnJlc2hlZCcsIHsgY291bnQ6IHBhcnNlZC5sZW5ndGggfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ3JlZnJlc2ggYWNjb3VudHMgZmFpbGVkOyBrZWVwaW5nIGN1cnJlbnQgbGlzdCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFyY2hpdmVTbmFwc2hvdChjbGllbnQ6IEdpdEh1YkNsaWVudCwgZm9yY2U6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdGV4dCA9IGF3YWl0IGNsaWVudC5mZXRjaFJhd1RleHQoJ2RhdGEvbWFuaWZlc3QuanNvbicpO1xuICBpZiAoIXRleHQpIHtcbiAgICBhd2FpdCBzZXRBcmNoaXZlU25hcHNob3QobnVsbCk7XG4gICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhcmNoaXZlIG1hbmlmZXN0IG5vdCBmb3VuZDsgb2xkLXR3ZWV0IGRldGVjdGlvbiBkaXNhYmxlZCcpO1xuICAgIHJldHVybjtcbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IHNuYXBzaG90ID0gcGFyc2VBcmNoaXZlU25hcHNob3QoSlNPTi5wYXJzZSh0ZXh0KSBhcyB1bmtub3duKTtcbiAgICBhd2FpdCBzZXRBcmNoaXZlU25hcHNob3Qoc25hcHNob3QpO1xuICAgIGlmIChmb3JjZSkge1xuICAgICAgYXdhaXQgaW5mbygnYXJjaGl2ZSBzbmFwc2hvdCByZWZyZXNoZWQnLCB7XG4gICAgICAgIGFjY291bnRzOiBPYmplY3Qua2V5cyhzbmFwc2hvdC5hY2NvdW50cykubGVuZ3RoLFxuICAgICAgICBnZW5lcmF0ZWRfYXQ6IHNuYXBzaG90LmdlbmVyYXRlZF9hdCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignYXJjaGl2ZSBzbmFwc2hvdCBwYXJzZSBmYWlsZWQ7IG9sZC10d2VldCBkZXRlY3Rpb24gZGlzYWJsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG59XG5cbi8vIC0tLSBTdGF0ZSBicm9hZGNhc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gYnJvYWRjYXN0U3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgYnVpbGRTdGF0ZSgpO1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCB0YWJDb3VudCA9IDA7XG4gIHRyeSB7XG4gICAgY29uc3QgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gICAgdGFiQ291bnQgPSB0YWJzLmxlbmd0aDtcbiAgfSBjYXRjaCB7XG4gICAgLy8gdGFicy5xdWVyeSBpcyBhbGxvd2VkIGJ5IHRoZSBtYW5pZmVzdCBidXQgY2FuIHRyYW5zaWVudGx5IGZhaWxcbiAgICAvLyBhcm91bmQgZXh0ZW5zaW9uIHN0YXJ0dXA7IHN1cmZhY2luZyAwIGlzIGZpbmUuXG4gIH1cbiAgY29uc3QgcmVmZXRjaFF1ZXVlZCA9IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xRdWV1ZWQgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xTZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgY29uc3QgYXV0b1Njcm9sbFNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICBjb25zdCByZWNlbnRUd2VldFNpZ2h0aW5ncyA9IGF3YWl0IGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk7XG4gIHJldHVybiB7XG4gICAgdmVyc2lvbjogRVhUX1ZFUlNJT04sXG4gICAgc2V0dGluZ3M6IHJlZGFjdFNldHRpbmdzKHNldHRpbmdzKSxcbiAgICBjb25uZWN0aW9uOiBjb25uLFxuICAgIGFjY291bnRzLFxuICAgIGNvdW50ZXJzLFxuICAgIGF1dG9TY3JvbGw6IHtcbiAgICAgIGFjdGl2ZTogYXV0b1Njcm9sbFNlc3MgIT09IG51bGwgJiYgYXV0b1Njcm9sbFRpbWVyICE9PSBudWxsLFxuICAgICAgdGFiQ291bnQsXG4gICAgICBzY3JvbGxDb3VudDogYXV0b1Njcm9sbFNlc3M/LnNjcm9sbENvdW50ID8/IDAsXG4gICAgICBpbmdlc3RlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uaW5nZXN0ZWRDb3VudCA/PyAwLFxuICAgICAgaW5nZXN0ZWROZXdDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkTmV3Q291bnQgPz8gMCxcbiAgICAgIGluZ2VzdGVkRXhpc3RpbmdDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkRXhpc3RpbmdDb3VudCA/PyAwLFxuICAgICAgc2tpcHBlZE9sZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uc2tpcHBlZE9sZENvdW50ID8/IDAsXG4gICAgICBleHBhbmRlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uZXhwYW5kZWRDb3VudCA/PyAwLFxuICAgIH0sXG4gICAgcmVmZXRjaFF1ZXVlOiB7XG4gICAgICB0b3RhbDogcmVmZXRjaFF1ZXVlZCxcbiAgICAgIHJ1bm5pbmc6IHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcbiAgICAgIHByb2Nlc3NlZDogcmVmZXRjaFNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHJlZmV0Y2hTZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcbiAgICB9LFxuICAgIG1lZGlhQ3Jhd2xRdWV1ZToge1xuICAgICAgdG90YWw6IG1lZGlhQ3Jhd2xRdWV1ZWQsXG4gICAgICBydW5uaW5nOiBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwsXG4gICAgICBwcm9jZXNzZWQ6IG1lZGlhQ3Jhd2xTZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBtZWRpYUNyYXdsU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXG4gICAgfSxcbiAgICByZWNlbnRUd2VldFNpZ2h0aW5ncyxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcmVkYWN0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBFeHRlbnNpb25TdGF0ZVsnc2V0dGluZ3MnXSB7XG4gIHJldHVybiB7XG4gICAgb3duZXI6IHMub3duZXIsXG4gICAgcmVwbzogcy5yZXBvLFxuICAgIGJyYW5jaDogcy5icmFuY2gsXG4gICAgZW5hYmxlZDogcy5lbmFibGVkLFxuICAgIGF1dG9DYXB0dXJlOiBzLmF1dG9DYXB0dXJlLFxuICAgIGNvbmZpZ3VyZWRBdDogcy5jb25maWd1cmVkQXQsXG4gICAgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyxcbiAgICB1cGRhdGVFeGlzdGluZzogcy51cGRhdGVFeGlzdGluZyxcbiAgICBwYXRTZXQ6IHMucGF0Lmxlbmd0aCA+IDAsXG4gICAgcGF0U3VmZml4OiBzLnBhdC5sZW5ndGggPj0gNCA/IHMucGF0LnNsaWNlKC00KSA6ICcnLFxuICB9O1xufVxuXG5mdW5jdGlvbiBwYXJzZUFyY2hpdmVTbmFwc2hvdChyYXc6IHVua25vd24pOiBBcmNoaXZlU25hcHNob3Qge1xuICBpZiAoIXJhdyB8fCB0eXBlb2YgcmF3ICE9PSAnb2JqZWN0JykgdGhyb3cgbmV3IEVycm9yKCdtYW5pZmVzdCBpcyBub3QgYW4gb2JqZWN0Jyk7XG4gIGNvbnN0IG1hbmlmZXN0ID0gcmF3IGFzIHsgZ2VuZXJhdGVkX2F0PzogdW5rbm93bjsgYWNjb3VudHM/OiB1bmtub3duIH07XG4gIGlmICghQXJyYXkuaXNBcnJheShtYW5pZmVzdC5hY2NvdW50cykpIHRocm93IG5ldyBFcnJvcignbWFuaWZlc3QuYWNjb3VudHMgaXMgbm90IGFuIGFycmF5Jyk7XG4gIGNvbnN0IGFjY291bnRzOiBBcmNoaXZlU25hcHNob3RbJ2FjY291bnRzJ10gPSB7fTtcbiAgZm9yIChjb25zdCBlbnRyeSBvZiBtYW5pZmVzdC5hY2NvdW50cykge1xuICAgIGlmICghZW50cnkgfHwgdHlwZW9mIGVudHJ5ICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgY29uc3Qgcm93ID0gZW50cnkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgY29uc3QgaGFuZGxlID0gdHlwZW9mIHJvdy5oYW5kbGUgPT09ICdzdHJpbmcnID8gcm93LmhhbmRsZSA6ICcnO1xuICAgIGlmICghaGFuZGxlIHx8IGhhbmRsZSA9PT0gJ19taXNjJykgY29udGludWU7XG4gICAgYWNjb3VudHNbaGFuZGxlLnRvTG93ZXJDYXNlKCldID0ge1xuICAgICAgaGFuZGxlLFxuICAgICAgbGF0ZXN0X3Bvc3RfYXQ6IHR5cGVvZiByb3cubGF0ZXN0X3Bvc3RfYXQgPT09ICdzdHJpbmcnID8gcm93LmxhdGVzdF9wb3N0X2F0IDogbnVsbCxcbiAgICAgIGxhdGVzdF9jYXB0dXJlX2F0OiB0eXBlb2Ygcm93LmxhdGVzdF9jYXB0dXJlX2F0ID09PSAnc3RyaW5nJyA/IHJvdy5sYXRlc3RfY2FwdHVyZV9hdCA6IG51bGwsXG4gICAgICByb3dfY291bnQ6IHR5cGVvZiByb3cucm93X2NvdW50ID09PSAnbnVtYmVyJyA/IHJvdy5yb3dfY291bnQgOiBudWxsLFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBnZW5lcmF0ZWRfYXQ6IHR5cGVvZiBtYW5pZmVzdC5nZW5lcmF0ZWRfYXQgPT09ICdzdHJpbmcnID8gbWFuaWZlc3QuZ2VuZXJhdGVkX2F0IDogbnVsbCxcbiAgICBmZXRjaGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgYWNjb3VudHMsXG4gIH07XG59XG5cbmZ1bmN0aW9uIGFyY2hpdmVTbmFwc2hvdEhhc1R3ZWV0KHQ6IENhbm9uaWNhbFR3ZWV0LCBzbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbCk6IGJvb2xlYW4ge1xuICBpZiAoIXNuYXBzaG90KSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGVudHJ5ID0gc25hcHNob3QuYWNjb3VudHNbdC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpXTtcbiAgaWYgKCFlbnRyeT8ubGF0ZXN0X3Bvc3RfYXQpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgcG9zdGVkID0gRGF0ZS5wYXJzZSh0LnBvc3RlZF9hdCk7XG4gIGNvbnN0IGxhdGVzdCA9IERhdGUucGFyc2UoZW50cnkubGF0ZXN0X3Bvc3RfYXQpO1xuICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHBvc3RlZCkgJiYgTnVtYmVyLmlzRmluaXRlKGxhdGVzdCkgJiYgcG9zdGVkIDw9IGxhdGVzdDtcbn1cblxuZnVuY3Rpb24gYnVpbGRUd2VldFNpZ2h0aW5nKFxuICB0OiBDYW5vbmljYWxUd2VldCxcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgc2VlbkF0OiBzdHJpbmcsXG4gIGZyZXNobmVzczogJ25ldycgfCAnZXhpc3RpbmcnID0gJ25ldycsXG4gIGFjdGlvbjogVHdlZXRTaWdodGluZ1snYWN0aW9uJ10gPSAnYnVmZmVyZWQnXG4pOiBUd2VldFNpZ2h0aW5nIHtcbiAgcmV0dXJuIHtcbiAgICB0d2VldF9pZDogdC50d2VldF9pZCxcbiAgICBhY2NvdW50X2hhbmRsZTogdC5hY2NvdW50X2hhbmRsZSxcbiAgICBwb3N0ZWRfYXQ6IHQucG9zdGVkX2F0LFxuICAgIHRleHQ6IHQudGV4dF9yZXNvbHZlZCB8fCB0LnRleHQsXG4gICAgdHdlZXRfdHlwZTogdC50d2VldF90eXBlLFxuICAgIHR3ZWV0X3VybDogdC50d2VldF91cmwsXG4gICAgc2Vlbl9hdDogc2VlbkF0LFxuICAgIGVuZHBvaW50LFxuICAgIGFyY2hpdmVfc3RhdHVzOiBmcmVzaG5lc3MgPT09ICdleGlzdGluZycgPyAnc2F2ZWQnIDogJ25ldycsXG4gICAgYWN0aW9uLFxuICB9O1xufVxuXG5mdW5jdGlvbiBpc1dyaXRlQXV0aEVycm9yKG1lc3NhZ2U6IHN0cmluZyB8IG51bGwpOiBib29sZWFuIHtcbiAgcmV0dXJuIChcbiAgICB0eXBlb2YgbWVzc2FnZSA9PT0gJ3N0cmluZycgJiZcbiAgICAvUmVzb3VyY2Ugbm90IGFjY2Vzc2libGUgYnkgcGVyc29uYWwgYWNjZXNzIHRva2VufFxcL2dpdFxcL2Jsb2JzfFxcL2dpdFxcL3JlZnMvaS50ZXN0KG1lc3NhZ2UpXG4gICk7XG59XG5cbmZ1bmN0aW9uIGlzb0NvbXBhY3QoaXNvOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyAyMDI1LTA0LTEyVDE0OjIzOjAxLjAwMFogXHUyMTkyIDIwMjUtMDQtMTJUMTQyMzAxWlxuICBjb25zdCBkID0gbmV3IERhdGUoaXNvKTtcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBpc28ucmVwbGFjZSgvWzouXS9nLCAnJyk7XG4gIGNvbnN0IHBhZCA9IChuOiBudW1iZXIsIHcgPSAyKSA9PiBTdHJpbmcobikucGFkU3RhcnQodywgJzAnKTtcbiAgcmV0dXJuIChcbiAgICBgJHtkLmdldFVUQ0Z1bGxZZWFyKCl9LSR7cGFkKGQuZ2V0VVRDTW9udGgoKSArIDEpfS0ke3BhZChkLmdldFVUQ0RhdGUoKSl9YCArXG4gICAgYFQke3BhZChkLmdldFVUQ0hvdXJzKCkpfSR7cGFkKGQuZ2V0VVRDTWludXRlcygpKX0ke3BhZChkLmdldFVUQ1NlY29uZHMoKSl9WmBcbiAgKTtcbn1cblxuZnVuY3Rpb24gdmlld2VyVXJsKHM6IFNldHRpbmdzKTogc3RyaW5nIHtcbiAgcmV0dXJuIGBodHRwczovLyR7cy5vd25lcn0uZ2l0aHViLmlvLyR7cy5yZXBvfS9gO1xufVxuXG4vKipcbiAqIFdhbGsgYG5vZGVgIGNvbGxlY3RpbmcgZG90dGVkIGtleSBwYXRocyB1cCB0byBgbWF4RGVwdGhgIGRlZXAuIEFycmF5XG4gKiBpbmRpY2VzIGNvbGxhcHNlIHRvIGBbMF1gICh3ZSBvbmx5IGRlc2NlbmQgaW50byB0aGUgZmlyc3QgZWxlbWVudCkuIFVzZWRcbiAqIHRvIHN1cmZhY2UgdGhlIHN0cnVjdHVyYWwgc2tlbGV0b24gb2YgYW4gdW5mYW1pbGlhciBHcmFwaFFMIHJlc3BvbnNlXG4gKiB3aXRob3V0IGluY2x1ZGluZyBhbnkgZGF0YSB2YWx1ZXMuXG4gKi9cbi8qKiBDb2xsZWN0IGV2ZXJ5IGRpc3RpbmN0IGBfX3R5cGVuYW1lYCB2YWx1ZSBmb3VuZCBhbnl3aGVyZSBpbiB0aGUgdHJlZS4gKi9cbmZ1bmN0aW9uIHByb2JlVHlwZW5hbWVzKG5vZGU6IHVua25vd24pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKHR5cGVvZiBvYmouX190eXBlbmFtZSA9PT0gJ3N0cmluZycpIHNlZW4uYWRkKG9iai5fX3R5cGVuYW1lKTtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBbLi4uc2Vlbl0uc29ydCgpO1xufVxuXG4vKipcbiAqIEZpbmQgdGhlIGZpcnN0IG5vZGUgYW55d2hlcmUgaW4gdGhlIHRyZWUgd2hvc2UgYF9fdHlwZW5hbWVgIG1hdGNoZXMgYW5kXG4gKiByZXR1cm4gaXRzIHRvcC1sZXZlbCBrZXkgbGlzdCAoc29ydGVkKS4gVXNlZnVsIGZvciBkaXNjb3ZlcmluZyB3aGF0IGZpZWxkc1xuICogWCBpcyBhY3R1YWxseSBzaGlwcGluZyBmb3IgYSBnaXZlbiBub2RlIHR5cGUgYWZ0ZXIgYSBzY2hlbWEgY2hhbmdlLlxuICovXG5mdW5jdGlvbiBwcm9iZUZpcnN0VHlwZVNoYXBlKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcpOiBzdHJpbmdbXSB8IG51bGwge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobiA9PT0gbnVsbCB8fCB0eXBlb2YgbiAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShuKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG9iaiA9IG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBpZiAob2JqLl9fdHlwZW5hbWUgPT09IHR5cGVuYW1lKSB7XG4gICAgICAgIHJldHVybiBPYmplY3Qua2V5cyhvYmopLnNvcnQoKTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vKipcbiAqIEZpbmQgdGhlIGZpcnN0IG5vZGUgd2l0aCBgX190eXBlbmFtZSA9PT0gdHlwZW5hbWVgLCB0aGVuIGRlc2NlbmQgdGhyb3VnaFxuICogdGhlIGdpdmVuIGtleSBwYXRoLCBhbmQgcmV0dXJuIHRoZSB0b3AtbGV2ZWwga2V5cyBvZiB3aGF0ZXZlciBpcyBhdCB0aGVcbiAqIGVuZC4gUmV0dXJucyBhIG1hcmtlciBzdHJpbmcgd2hlbiB0aGUgcGF0aCBsZWFkcyBzb21ld2hlcmUgbm9uLW9iamVjdCBzb1xuICogd2UgY2FuIHRlbGwgYXBhcnQgXCJhYnNlbnRcIiBmcm9tIFwicHJlc2VudCBidXQgbm90IGFuIG9iamVjdFwiLlxuICovXG5mdW5jdGlvbiBwcm9iZVR5cGVkTmVzdGVkKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcsIHBhdGg6IHN0cmluZ1tdKTogdW5rbm93biB7XG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIGxldCBmb3VuZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsID0gbnVsbDtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSB0eXBlbmFtZSkge1xuICAgICAgICBmb3VuZCA9IG9iajtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICBpZiAoIWZvdW5kKSByZXR1cm4gbnVsbDtcbiAgbGV0IGN1cjogdW5rbm93biA9IGZvdW5kO1xuICBmb3IgKGNvbnN0IHNlZyBvZiBwYXRoKSB7XG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgcmV0dXJuIGA8JHtjdXIgPT09IG51bGwgPyAnbnVsbCcgOiB0eXBlb2YgY3VyfT5gO1xuICAgIGN1ciA9IChjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW3NlZ107XG4gIH1cbiAgaWYgKGN1ciA9PT0gdW5kZWZpbmVkKSByZXR1cm4gJzxtaXNzaW5nPic7XG4gIGlmIChjdXIgPT09IG51bGwpIHJldHVybiAnPG51bGw+JztcbiAgaWYgKHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSByZXR1cm4gYDwke3R5cGVvZiBjdXJ9PmA7XG4gIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHJldHVybiBgPGFycmF5IGxlbj0ke2N1ci5sZW5ndGh9PmA7XG4gIHJldHVybiBPYmplY3Qua2V5cyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLnNvcnQoKTtcbn1cblxuZnVuY3Rpb24gc2hvcnRlblVybCh1OiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBBY3Rpdml0eS10YWlsIGNvbnRleHQgaXMgbW9yZSB1c2VmdWwgd2l0aCBqdXN0IHRoZSBwYXRoOyBmdWxsIFVSTHMgYmVjb21lXG4gIC8vIGhhcmQgdG8gcmVhZCBhdCB0aGUgc2lkZWJhcidzIHdpZHRoLlxuICB0cnkge1xuICAgIGNvbnN0IHBhcnNlZCA9IG5ldyBVUkwodSk7XG4gICAgY29uc3QgcGF0aCA9IHBhcnNlZC5wYXRobmFtZSArIChwYXJzZWQuc2VhcmNoID8gJz9cdTIwMjYnIDogJycpO1xuICAgIHJldHVybiBwYXJzZWQuaG9zdCA9PT0gJ3guY29tJyB8fCBwYXJzZWQuaG9zdCA9PT0gJ3R3aXR0ZXIuY29tJ1xuICAgICAgPyBwYXRoXG4gICAgICA6IGAke3BhcnNlZC5ob3N0fSR7cGF0aH1gO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gdS5sZW5ndGggPiA4MCA/IGAke3Uuc2xpY2UoMCwgODApfVx1MjAyNmAgOiB1O1xuICB9XG59XG5cbi8vIC0tLSBEZXYgaGVscGVycyBleHBvc2VkIG9uIGdsb2JhbFRoaXMgZm9yIHRoZSBkZXZ0b29scyBjb25zb2xlIC0tLS0tLS0tLS1cbi8vIChlLmcuIGBfX2ltbUFyY2hpdmUuY2xlYXJBbGwoKWAgaW4gdGhlIGJhY2tncm91bmQgd29ya2VyJ3MgZGV2dG9vbHMpLlxuXG4oZ2xvYmFsVGhpcyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuX19pbW1BcmNoaXZlID0ge1xuICBjbGVhckFsbCxcbiAgYWN0aXZpdHk6IGdldEFjdGl2aXR5LFxuICBhY2NvdW50czogZ2V0QWNjb3VudHMsXG4gIGJ1ZmZlcnM6IGdldFJ1bkJ1ZmZlcnMsXG4gIGZsdXNoQWxsOiAoKSA9PiBmbHVzaEFsbCgnZGV2dG9vbHMnKSxcbiAgc3RhdGU6IGJ1aWxkU3RhdGUsXG4gIHJlZmV0Y2hRdWV1ZTogZ2V0UmVmZXRjaFF1ZXVlLFxuICBzdGFydFJlZmV0Y2g6IHN0YXJ0UmVmZXRjaExvb3AsXG4gIGNhbmNlbFJlZmV0Y2g6IGNhbmNlbFJlZmV0Y2hMb29wLFxuICBtZWRpYUNyYXdsUXVldWU6IGdldE1lZGlhQ3Jhd2xRdWV1ZSxcbiAgc3RhcnRNZWRpYUNyYXdsOiBzdGFydE1lZGlhQ3Jhd2xMb29wLFxuICBjYW5jZWxNZWRpYUNyYXdsOiBjYW5jZWxNZWRpYUNyYXdsTG9vcCxcbn07XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRU8sSUFBTSxtQkFBNkI7QUFBQSxFQUN4QyxLQUFLO0FBQUEsRUFDTCxPQUFPO0FBQUEsRUFDUCxNQUFNO0FBQUE7QUFBQTtBQUFBLEVBR04sUUFBUTtBQUFBLEVBQ1IsU0FBUztBQUFBLEVBQ1QsYUFBYTtBQUFBLEVBQ2IsY0FBYztBQUFBLEVBQ2QsdUJBQXVCO0FBQUEsRUFDdkIsZ0JBQWdCO0FBQ2xCO0FBRU8sSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxzQkFBc0I7QUFJNUIsSUFBTSxvQkFBcUM7QUFBQSxFQUNoRCxFQUFFLFFBQVEsVUFBVSxPQUFPLG1DQUFtQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsVUFBVSxPQUFPLDRDQUE0QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsT0FBTyxPQUFPLHNDQUFzQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsU0FBUyxPQUFPLDZDQUE2QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsY0FBYyxPQUFPLG1CQUFtQixVQUFVLE9BQU87QUFBQSxFQUNuRSxFQUFFLFFBQVEsWUFBWSxPQUFPLCtCQUErQixVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLGtDQUFrQyxVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLDRCQUE0QixVQUFVLE9BQU87QUFBQSxFQUN2RSxFQUFFLFFBQVEsbUJBQW1CLE9BQU8scUJBQXFCLFVBQVUsT0FBTztBQUM1RTtBQUdPLElBQU0sa0JBQXVDLG9CQUFJLElBQUk7QUFBQSxFQUMxRDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQVdNLElBQU0sb0JBQXlDLG9CQUFJLElBQUksQ0FBQyxvQkFBb0IsY0FBYyxDQUFDO0FBdUIzRixJQUFNLHdCQUF3QjtBQUc5QixJQUFNLGdCQUFnQjtBQUd0QixJQUFNLHNCQUFzQjtBQUc1QixJQUFNLG9CQUFvQjtBQUcxQixJQUFNLGdDQUFnQyxLQUFLLEtBQUs7QUFFaEQsSUFBTSxtQkFBbUI7OztBQ3ZFaEMsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0I7QUFFeEIsSUFBSSxrQkFBb0M7QUFDeEMsSUFBSSxzQkFBcUM7QUFFekMsU0FBUyxTQUFTLEtBQXlCO0FBQ3pDLE1BQUksSUFBSTtBQUNSLGFBQVcsS0FBSyxJQUFLLE1BQUssT0FBTyxhQUFhLENBQUM7QUFDL0MsU0FBTyxLQUFLLENBQUM7QUFDZjtBQUVBLFNBQVMsV0FBVyxHQUF1QjtBQUN6QyxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFFBQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxNQUFNO0FBQ3JDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUssS0FBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFDOUQsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUU7QUFDaEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDL0QsUUFBTSxJQUFJLE9BQU8sZ0JBQWdCO0FBQ2pDLE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsV0FBTyxFQUFFLFNBQVMsR0FBRyxNQUFNLFdBQVcsQ0FBQyxFQUFFO0FBQUEsRUFDM0M7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxRQUFNLFVBQVUsU0FBUyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0FBQy9ELFNBQU8sRUFBRSxTQUFTLEtBQUs7QUFDekI7QUFFQSxlQUFlLFlBQWdDO0FBQzdDLFFBQU0sRUFBRSxTQUFTLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUNqRCxNQUFJLG9CQUFvQixRQUFRLHdCQUF3QixTQUFTO0FBQy9ELFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFO0FBQUEsSUFDN0IsR0FBRyxRQUFRLFFBQVEsRUFBRSxJQUFJLFFBQVEsUUFBUSxZQUFZLEVBQUUsT0FBTztBQUFBLEVBQ2hFO0FBQ0EsUUFBTSxXQUFXLElBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNO0FBQ3pELFdBQVMsSUFBSSxNQUFNLENBQUM7QUFDcEIsV0FBUyxJQUFJLE1BQU0sS0FBSyxNQUFNO0FBQzlCLFFBQU0sT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUTtBQUMzRCxRQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLE1BQU0sRUFBRSxNQUFNLFVBQVUsR0FBRyxPQUFPO0FBQUEsSUFDakY7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBQ0Qsb0JBQWtCO0FBQ2xCLHdCQUFzQjtBQUN0QixTQUFPO0FBQ1Q7QUFFTyxTQUFTLGVBQWUsR0FBb0I7QUFDakQsU0FBTyxFQUFFLFdBQVcsZUFBZTtBQUNyQztBQUVBLGVBQXNCLFdBQVcsV0FBb0M7QUFDbkUsTUFBSSxDQUFDLFVBQVcsUUFBTztBQUN2QixRQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFFBQU0sS0FBSyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3BELFFBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLElBQzdCLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxJQUN0QjtBQUFBLElBQ0EsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTO0FBQUEsRUFDcEM7QUFDQSxTQUFPLEdBQUcsZUFBZSxHQUFHLFNBQVMsRUFBRSxDQUFDLElBQUksU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMUU7QUFFQSxlQUFzQixXQUFXLFVBQW1DO0FBQ2xFLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFHdEIsTUFBSSxDQUFDLFNBQVMsV0FBVyxlQUFlLEVBQUcsUUFBTztBQUNsRCxRQUFNLFFBQVEsU0FBUyxNQUFNLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxHQUFHO0FBQzlELE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUMvQixRQUFNLENBQUMsT0FBTyxLQUFLLElBQUk7QUFDdkIsTUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFPLFFBQU87QUFDN0IsTUFBSTtBQUNGLFVBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQzdCLEVBQUUsTUFBTSxXQUFXLEdBQXVCO0FBQUEsTUFDMUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDcEMsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7OztBQ25CQSxJQUFNLHFCQUFzQztBQUFBLEVBQzFDLFFBQVE7QUFBQSxFQUNSLE9BQU87QUFBQSxFQUNQLFdBQVc7QUFBQSxFQUNYLE9BQU87QUFBQSxFQUNQLGVBQWU7QUFBQSxFQUNmLHdCQUF3QjtBQUFBLEVBQ3hCLGtCQUFrQjtBQUNwQjtBQUVBLElBQU0sV0FBeUI7QUFBQSxFQUM3QixVQUFVLEVBQUUsR0FBRyxpQkFBaUI7QUFBQSxFQUNoQyxVQUFVLENBQUMsR0FBRyxpQkFBaUI7QUFBQSxFQUMvQixxQkFBcUI7QUFBQSxFQUNyQixpQkFBaUI7QUFBQSxFQUNqQixZQUFZLEVBQUUsR0FBRyxtQkFBbUI7QUFBQSxFQUNwQyxVQUFVLENBQUM7QUFBQSxFQUNYLFlBQVksQ0FBQztBQUFBLEVBQ2IsVUFBVSxDQUFDO0FBQUEsRUFDWCxzQkFBc0IsQ0FBQztBQUFBLEVBQ3ZCLGdCQUFnQixDQUFDO0FBQUEsRUFDakIsY0FBYyxDQUFDO0FBQUEsRUFDZixpQkFBaUIsQ0FBQztBQUFBLEVBQ2xCLGdCQUFnQjtBQUFBLEVBQ2hCLG1CQUFtQjtBQUFBLEVBQ25CLG1CQUFtQjtBQUNyQjtBQUVBLGVBQWUsT0FBcUMsS0FBa0M7QUFDcEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxHQUFHO0FBQ2xELFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsTUFBSSxVQUFVLFFBQVc7QUFDdkIsV0FBTyxnQkFBZ0IsU0FBUyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUNBLFNBQU87QUFDVDtBQUVBLGVBQWUsT0FBcUMsS0FBUSxPQUF1QztBQUNqRyxRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUM7QUFDbEQ7QUFJQSxlQUFzQixjQUFpQztBQUtyRCxRQUFNLFNBQVMsTUFBTSxPQUFPLFVBQVU7QUFDdEMsUUFBTSxTQUFTLEVBQUUsR0FBRyxrQkFBa0IsR0FBRyxPQUFPO0FBQ2hELE1BQUksT0FBTyxPQUFPLGVBQWUsT0FBTyxHQUFHLEdBQUc7QUFDNUMsUUFBSTtBQUNGLGFBQU8sTUFBTSxNQUFNLFdBQVcsT0FBTyxHQUFHO0FBQUEsSUFDMUMsUUFBUTtBQUNOLGFBQU8sTUFBTTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsWUFBWSxHQUE0QjtBQUc1RCxRQUFNLFVBQW9CLEVBQUUsR0FBRyxFQUFFO0FBQ2pDLE1BQUksUUFBUSxPQUFPLENBQUMsZUFBZSxRQUFRLEdBQUcsR0FBRztBQUMvQyxZQUFRLE1BQU0sTUFBTSxXQUFXLFFBQVEsR0FBRztBQUFBLEVBQzVDO0FBQ0EsUUFBTSxPQUFPLFlBQVksT0FBTztBQUNsQztBQUNBLGVBQXNCLGVBQWUsT0FBNkM7QUFDaEYsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE9BQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hDLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFNBQU87QUFDVDtBQUlBLGVBQXNCLGNBQXdDO0FBQzVELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFBWSxHQUFtQztBQUNuRSxRQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzVCO0FBQ0EsZUFBc0IseUJBQWlEO0FBQ3JFLFNBQU8sT0FBTyxxQkFBcUI7QUFDckM7QUFDQSxlQUFzQix1QkFBdUIsS0FBbUM7QUFDOUUsUUFBTSxPQUFPLHVCQUF1QixHQUFHO0FBQ3pDO0FBSUEsZUFBc0IscUJBQXNEO0FBQzFFLFNBQU8sT0FBTyxpQkFBaUI7QUFDakM7QUFFQSxlQUFzQixtQkFBbUIsVUFBaUQ7QUFDeEYsUUFBTSxPQUFPLG1CQUFtQixRQUFRO0FBQzFDO0FBSUEsZUFBc0IsZ0JBQTBDO0FBQzlELFFBQU0sSUFBSSxNQUFNLE9BQU8sWUFBWTtBQUVuQyxRQUFNLE1BQXVCO0FBQUEsSUFDM0IsR0FBRztBQUFBLElBQ0gsZUFBZSxFQUFFLGtCQUFrQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3hELHdCQUNFLEVBQUUsMkJBQTJCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDcEQsa0JBQWtCLEVBQUUscUJBQXFCLFNBQVksT0FBTyxFQUFFO0FBQUEsRUFDaEU7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixjQUFjLEdBQW1DO0FBQ3JFLFFBQU0sT0FBTyxjQUFjLENBQUM7QUFDOUI7QUFJQSxTQUFTLFdBQW1CO0FBQzFCLFVBQU8sb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUM3QztBQUVBLGVBQXNCLGNBQXVEO0FBQzNFLFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFDcEIsUUFDQSxPQUN5QjtBQUN6QixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sTUFBTSxJQUFJLE1BQU0sS0FBSztBQUFBLElBQ3pCLFlBQVk7QUFBQSxJQUNaLFdBQVcsU0FBUztBQUFBLElBQ3BCLGVBQWU7QUFBQSxJQUNmLGdCQUFnQjtBQUFBLElBQ2hCLGVBQWU7QUFBQSxFQUNqQjtBQUNBLE1BQUksSUFBSSxjQUFjLFNBQVMsR0FBRztBQUNoQyxRQUFJLFlBQVksU0FBUztBQUN6QixRQUFJLGFBQWE7QUFBQSxFQUNuQjtBQUNBLFFBQU0sT0FBdUIsRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hELE1BQUksTUFBTSxJQUFJO0FBQ2QsUUFBTSxPQUFPLFlBQVksR0FBRztBQUM1QixTQUFPO0FBQ1Q7QUFFQSxlQUFzQixpQkFBaUIsUUFBZ0IsT0FBOEI7QUFDbkYsUUFBTSxZQUFZLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztBQUNwRDtBQUlBLGVBQXNCLGdCQUFvRDtBQUN4RSxTQUFPLE9BQU8sWUFBWTtBQUM1QjtBQUVBLGVBQXNCLGFBQWEsUUFBMkM7QUFDNUUsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxTQUFPLElBQUksTUFBTSxLQUFLO0FBQ3hCO0FBRUEsZUFBc0IsYUFBYSxRQUFnQixLQUErQjtBQUNoRixRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLE1BQUksTUFBTSxJQUFJO0FBQ2QsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUVBLGVBQXNCLGVBQWUsUUFBK0I7QUFDbEUsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxTQUFPLElBQUksTUFBTTtBQUNqQixRQUFNLE9BQU8sY0FBYyxHQUFHO0FBQ2hDO0FBSUEsZUFBc0IsY0FBbUM7QUFDdkQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFFQSxlQUFzQixlQUFlLElBQW1DO0FBQ3RFLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsTUFBSSxRQUFRLEVBQUU7QUFDZCxNQUFJLElBQUksU0FBUyxrQkFBbUIsS0FBSSxTQUFTO0FBQ2pELFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsZ0JBQStCO0FBQ25ELFFBQU0sT0FBTyxZQUFZLENBQUMsQ0FBQztBQUM3QjtBQUlBLElBQU0sNkJBQTZCO0FBRW5DLGVBQXNCLDBCQUFvRDtBQUN4RSxTQUFPLE9BQU8sc0JBQXNCO0FBQ3RDO0FBRUEsZUFBc0IsNEJBQTRCLE1BQXNDO0FBQ3RGLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsUUFBTSxNQUFNLE1BQU0sd0JBQXdCO0FBQzFDLFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sT0FBd0IsQ0FBQztBQUMvQixhQUFXLE9BQU8sTUFBTTtBQUN0QixVQUFNLE1BQU0sR0FBRyxJQUFJLGVBQWUsWUFBWSxDQUFDLElBQUksSUFBSSxRQUFRO0FBQy9ELFFBQUksS0FBSyxJQUFJLEdBQUcsRUFBRztBQUNuQixTQUFLLElBQUksR0FBRztBQUNaLFNBQUssS0FBSyxHQUFHO0FBQUEsRUFDZjtBQUNBLGFBQVcsT0FBTyxLQUFLO0FBQ3JCLFVBQU0sTUFBTSxHQUFHLElBQUksZUFBZSxZQUFZLENBQUMsSUFBSSxJQUFJLFFBQVE7QUFDL0QsUUFBSSxLQUFLLElBQUksR0FBRyxFQUFHO0FBQ25CLFNBQUssSUFBSSxHQUFHO0FBQ1osU0FBSyxLQUFLLEdBQUc7QUFBQSxFQUNmO0FBQ0EsT0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFFBQVEsMEJBQTBCO0FBQzlELFFBQU0sT0FBTyx3QkFBd0IsSUFBSTtBQUMzQztBQUlBLGVBQXNCLG9CQUE2RTtBQUNqRyxTQUFPLE9BQU8sZ0JBQWdCO0FBQ2hDO0FBRUEsZUFBc0Isa0JBQ3BCLEtBQ2U7QUFDZixRQUFNLE9BQU8sa0JBQWtCLEdBQUc7QUFDcEM7QUFVTyxTQUFTLGNBQ2QsT0FDQSxVQUNBLFNBQ0EsUUFDQSxjQUF1QixPQUNmO0FBQ1IsU0FBTyxHQUFHLEtBQUssSUFBSSxRQUFRLElBQUksT0FBTyxJQUFJLE1BQU0sSUFBSSxjQUFjLE1BQU0sR0FBRztBQUM3RTtBQUdBLGVBQXNCLG9CQUFvQixVQUFtQztBQUMzRSxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsUUFBTSxTQUFTLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxRQUFRLEVBQUUsWUFBWTtBQUMzRCxNQUFJLFNBQVM7QUFDYixhQUFXLFVBQVUsT0FBTyxLQUFLLEdBQUcsR0FBRztBQUNyQyxVQUFNLFFBQVEsSUFBSSxNQUFNO0FBQ3hCLFFBQUksQ0FBQyxNQUFPO0FBQ1osZUFBVyxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDcEMsWUFBTSxJQUFJLE1BQU0sR0FBRztBQUNuQixVQUFJLEtBQUssRUFBRSxLQUFLLFFBQVE7QUFDdEIsZUFBTyxNQUFNLEdBQUc7QUFDaEIsa0JBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxLQUFLLEtBQUssRUFBRSxXQUFXLEVBQUcsUUFBTyxJQUFJLE1BQU07QUFBQSxFQUN4RDtBQUNBLE1BQUksU0FBUyxFQUFHLE9BQU0sa0JBQWtCLEdBQUc7QUFDM0MsU0FBTztBQUNUO0FBSUEsZUFBc0Isa0JBQXFEO0FBQ3pFLFNBQU8sT0FBTyxjQUFjO0FBQzlCO0FBRUEsZUFBc0Isb0JBQXFDO0FBQ3pELFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0IsZUFBZSxRQUFnQixTQUFnQztBQUNuRixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsUUFBTSxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDMUIsTUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUc7QUFDMUIsUUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBRSxNQUFNLElBQUk7QUFDWixVQUFNLE9BQU8sZ0JBQWdCLENBQUM7QUFBQSxFQUNoQztBQUNGO0FBRUEsZUFBc0IsZUFBZSxRQUFnQixTQUFnQztBQUNuRixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsUUFBTSxNQUFNLEVBQUUsTUFBTTtBQUNwQixNQUFJLENBQUMsSUFBSztBQUNWLFFBQU0sV0FBVyxJQUFJLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTztBQUNsRCxNQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNO0FBQUEsTUFDckMsR0FBRSxNQUFNLElBQUk7QUFDakIsUUFBTSxPQUFPLGdCQUFnQixDQUFDO0FBQ2hDO0FBRUEsZUFBc0Isb0JBR1o7QUFDUixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFHO0FBQUEsRUFDeEQ7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixxQkFBd0Q7QUFDNUUsU0FBTyxPQUFPLGlCQUFpQjtBQUNqQztBQUVBLGVBQXNCLHVCQUF3QztBQUM1RCxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxRQUFRO0FBQ1osYUFBVyxPQUFPLE9BQU8sT0FBTyxDQUFDLEVBQUcsVUFBUyxJQUFJO0FBQ2pELFNBQU87QUFDVDtBQUVBLGVBQXNCLGtCQUFrQixZQUEyQixTQUFnQztBQUNqRyxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsUUFBTSxTQUFTLGNBQWM7QUFDN0IsUUFBTSxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDMUIsTUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUc7QUFDMUIsUUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBRSxNQUFNLElBQUk7QUFDWixVQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFBQSxFQUNuQztBQUNGO0FBRUEsZUFBc0Isa0JBQWtCLFNBQWdDO0FBQ3RFLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFVBQVU7QUFDZCxhQUFXLFVBQVUsT0FBTyxLQUFLLENBQUMsR0FBRztBQUNuQyxVQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsVUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELFFBQUksU0FBUyxXQUFXLElBQUksUUFBUTtBQUNsQyxnQkFBVTtBQUNWLFVBQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxVQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLE1BQUksUUFBUyxPQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFDaEQ7QUFFQSxlQUFzQix1QkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLFlBQVksU0FBbUM7QUFDbkUsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLGFBQVcsU0FBUyxPQUFPLE9BQU8sR0FBRyxHQUFHO0FBQ3RDLFFBQUksU0FBUyxXQUFXLE1BQU8sUUFBTztBQUFBLEVBQ3hDO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0Isb0JBQWlEO0FBQ3JFLFNBQU8sT0FBTyxnQkFBZ0I7QUFDaEM7QUFDQSxlQUFzQixrQkFBa0IsR0FBc0M7QUFDNUUsUUFBTSxPQUFPLGtCQUFrQixDQUFDO0FBQ2xDO0FBQ0EsZUFBc0IsdUJBQW9EO0FBQ3hFLFNBQU8sT0FBTyxtQkFBbUI7QUFDbkM7QUFDQSxlQUFzQixxQkFBcUIsR0FBc0M7QUFDL0UsUUFBTSxPQUFPLHFCQUFxQixDQUFDO0FBQ3JDO0FBQ0EsZUFBc0IsdUJBQTBEO0FBQzlFLFNBQU8sT0FBTyxtQkFBbUI7QUFDbkM7QUFDQSxlQUFzQixxQkFBcUIsR0FBNEM7QUFDckYsUUFBTSxPQUFPLHFCQUFxQixDQUFDO0FBQ3JDO0FBWUEsZUFBc0Isb0JBQW9CLFVBTXZDO0FBQ0QsUUFBTSxZQUFZLElBQUksSUFBSSxDQUFDLEdBQUcsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDbkUsUUFBTSxhQUFhLENBQUMsTUFBdUIsVUFBVSxJQUFJLEVBQUUsWUFBWSxDQUFDO0FBR3hFLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxrQkFBa0I7QUFDdEIsYUFBVyxLQUFLLE9BQU8sS0FBSyxRQUFRLEdBQUc7QUFDckMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sU0FBUyxDQUFDO0FBQ2pCLHlCQUFtQjtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxZQUFZLFFBQVE7QUFHakMsUUFBTSxVQUFVLE1BQU0sY0FBYztBQUNwQyxNQUFJLGlCQUFpQjtBQUNyQixhQUFXLEtBQUssT0FBTyxLQUFLLE9BQU8sR0FBRztBQUNwQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxRQUFRLENBQUM7QUFDaEIsd0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLGNBQWMsT0FBTztBQUdsQyxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsTUFBSSwwQkFBMEI7QUFDOUIsYUFBVyxLQUFLLE9BQU8sS0FBSyxHQUFHLEdBQUc7QUFDaEMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sSUFBSSxDQUFDO0FBQ1osaUNBQTJCO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxrQkFBa0IsR0FBRztBQUczQixRQUFNLEtBQUssTUFBTSxnQkFBZ0I7QUFDakMsTUFBSSx3QkFBd0I7QUFDNUIsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sR0FBRyxDQUFDO0FBQ1gsK0JBQXlCO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLGdCQUFnQixFQUFFO0FBSy9CLFFBQU0sS0FBSyxNQUFNLG1CQUFtQjtBQUNwQyxNQUFJLHVCQUF1QjtBQUMzQixhQUFXLEtBQUssT0FBTyxLQUFLLEVBQUUsR0FBRztBQUMvQixRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsK0JBQXlCLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRztBQUN0QyxhQUFPLEdBQUcsQ0FBQztBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLG1CQUFtQixFQUFFO0FBRWxDLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUlBLGVBQXNCLFdBQTBCO0FBQzlDLFFBQU0sUUFBUSxRQUFRLE1BQU0sTUFBTTtBQUNwQzs7O0FDdGtCQSxJQUFJLFlBQTZDO0FBRTFDLFNBQVMsZUFBZSxJQUFrQztBQUMvRCxjQUFZO0FBQ2Q7QUFFQSxTQUFTLFNBQWlCO0FBQ3hCLFVBQU8sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDaEM7QUFFQSxlQUFlLEtBQUssT0FBaUIsS0FBYSxTQUFpRDtBQUNqRyxRQUFNLEtBQWUsRUFBRSxJQUFJLE9BQU8sR0FBRyxPQUFPLEtBQUssU0FBUyxPQUFPLE9BQU8sRUFBRTtBQUUxRSxRQUFNLE9BQU8saUJBQWlCLE1BQU0sWUFBWSxDQUFDLElBQUksR0FBRztBQUN4RCxNQUFJLFVBQVUsUUFBUyxTQUFRLE1BQU0sTUFBTSxHQUFHLE9BQU87QUFBQSxXQUM1QyxVQUFVLE9BQVEsU0FBUSxLQUFLLE1BQU0sR0FBRyxPQUFPO0FBQUEsTUFDbkQsU0FBUSxJQUFJLE1BQU0sR0FBRyxPQUFPO0FBRWpDLE1BQUk7QUFDRixVQUFNLGVBQWUsRUFBRTtBQUFBLEVBQ3pCLFNBQVMsS0FBSztBQUNaLFlBQVEsS0FBSywyQ0FBMkMsR0FBRztBQUFBLEVBQzdEO0FBRUEsTUFBSTtBQUNGLGdCQUFZLEVBQUU7QUFBQSxFQUNoQixRQUFRO0FBQUEsRUFFUjtBQUNGO0FBRU8sU0FBUyxLQUFLLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN0RixTQUFPLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDbEM7QUFDTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsTUFBTSxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdkYsU0FBTyxLQUFLLFNBQVMsS0FBSyxPQUFPO0FBQ25DO0FBRU8sU0FBUyxjQUFjLEtBQXlEO0FBQ3JGLE1BQUksZUFBZSxPQUFPO0FBQ3hCLFdBQU8sRUFBRSxTQUFTLElBQUksU0FBUyxPQUFPLElBQUksU0FBUyxLQUFLO0FBQUEsRUFDMUQ7QUFDQSxNQUFJO0FBQ0YsV0FBTyxFQUFFLFNBQVMsT0FBTyxHQUFHLEdBQUcsT0FBTyxLQUFLO0FBQUEsRUFDN0MsUUFBUTtBQUNOLFdBQU8sRUFBRSxTQUFTLHVCQUF1QixPQUFPLEtBQUs7QUFBQSxFQUN2RDtBQUNGO0FBT0EsU0FBUyxPQUFPLEtBQXVEO0FBQ3JFLFFBQU0sTUFBK0IsQ0FBQztBQUN0QyxhQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUN4QyxRQUFJLEVBQUUsWUFBWSxFQUFFLFNBQVMsT0FBTyxLQUFLLEVBQUUsWUFBWSxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7QUFDM0YsVUFBSSxDQUFDLElBQUk7QUFBQSxJQUNYLFdBQVcsT0FBTyxNQUFNLFlBQVksK0JBQStCLEtBQUssQ0FBQyxHQUFHO0FBQzFFLFVBQUksQ0FBQyxJQUFJLEVBQUUsUUFBUSw2QkFBNkIsdUJBQXVCO0FBQUEsSUFDekUsV0FBVyxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsTUFBTTtBQUNuRCxVQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsTUFBTSxHQUFHLElBQUksQ0FBQztBQUFBLElBQzlCLE9BQU87QUFDTCxVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1g7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUOzs7QUN2RUEsSUFBTSxXQUFXO0FBQ2pCLElBQU0sV0FBVztBQStCVixJQUFNLGNBQU4sY0FBMEIsTUFBTTtBQUFBLEVBQ3JDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQTtBQUFBLEVBRUEsWUFBWSxNQU9UO0FBQ0QsVUFBTSxLQUFLLE9BQU87QUFDbEIsU0FBSyxPQUFPO0FBQ1osU0FBSyxTQUFTLEtBQUs7QUFDbkIsU0FBSyxPQUFPLEtBQUs7QUFDakIsU0FBSyxZQUFZLEtBQUs7QUFDdEIsU0FBSyxXQUFXLEtBQUs7QUFDckIsU0FBSyxtQkFBbUIsS0FBSyxvQkFBb0I7QUFBQSxFQUNuRDtBQUNGO0FBRU8sSUFBTSxlQUFOLE1BQW1CO0FBQUEsRUFDUDtBQUFBLEVBRWpCLFlBQVksVUFBb0I7QUFDOUIsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFBQTtBQUFBLEVBR0EsTUFBTSxTQUEwQjtBQUM5QixVQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQy9DLFdBQVEsSUFBMkIsU0FBUztBQUFBLEVBQzlDO0FBQUE7QUFBQSxFQUdBLE1BQU0sYUFBYSxRQUFrQztBQUNuRCxRQUFJO0FBQ0YsWUFBTSxLQUFLO0FBQUEsUUFDVDtBQUFBLFFBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsbUJBQW1CLE1BQU0sQ0FBQztBQUFBLE1BQzVGO0FBQ0EsYUFBTztBQUFBLElBQ1QsU0FBUyxLQUFLO0FBQ1osVUFBSSxlQUFlLGVBQWUsSUFBSSxhQUFhLFlBQWEsUUFBTztBQUN2RSxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQTtBQUFBLEVBR0EsTUFBTSxtQkFBMEY7QUFDOUYsVUFBTSxLQUFLLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTztBQUM5QyxVQUFNLE9BQU8sTUFBTSxLQUFLLFVBQVUsT0FBTyxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksRUFBRTtBQUM5RixVQUFNLElBQUk7QUFDVixXQUFPO0FBQUEsTUFDTCxPQUFRLEdBQXlCO0FBQUEsTUFDakMsV0FBVyxFQUFFO0FBQUEsTUFDYixnQkFBZ0IsRUFBRTtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE1BQU0sb0JBQW1DO0FBQ3ZDLFVBQU0sT0FBTyxNQUFNLEtBQUssY0FBYztBQUN0QyxVQUFNLEtBQUs7QUFBQSxNQUNUO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksbUJBQW1CLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLE1BQ3RHO0FBQUEsUUFDRSxLQUFLLEtBQUs7QUFBQSxRQUNWLE9BQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxhQUFhLFlBQTRDO0FBQzdELFVBQU0sTUFBTSxHQUFHLFFBQVEsSUFBSSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLElBQUksS0FBSyxTQUFTLE1BQU0sSUFBSSxVQUFVO0FBQzFHLFVBQU0sTUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLE1BQzNCLFFBQVE7QUFBQSxNQUNSLFNBQVMsRUFBRSxlQUFlLFVBQVUsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUFBLElBQzFELENBQUM7QUFDRCxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxDQUFDLElBQUksR0FBSSxPQUFNLE1BQU0sS0FBSyxVQUFVLEtBQUssV0FBVyxVQUFVLEVBQUU7QUFDcEUsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLFdBQVcsTUFBc0M7QUFDckQsUUFBSTtBQUNGLFlBQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxRQUNyQjtBQUFBLFFBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUMsUUFBUSxtQkFBbUIsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLE1BQ2xJO0FBQ0EsWUFBTSxJQUFJO0FBQ1YsYUFBTyxFQUFFLE9BQU87QUFBQSxJQUNsQixTQUFTLEtBQUs7QUFDWixVQUFJLGVBQWUsZUFBZSxJQUFJLGFBQWEsWUFBYSxRQUFPO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE1BQU0sUUFBUSxNQUE4QztBQUMxRCxVQUFNLE9BQU8sS0FBSztBQUNsQixVQUFNLE1BQU0sVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUM7QUFDNUYsUUFBSSxNQUFxQixLQUFLLGVBQWU7QUFDN0MsVUFBTSxjQUFjO0FBRXBCLGFBQVMsVUFBVSxHQUFHLFdBQVcsYUFBYSxXQUFXO0FBQ3ZELFlBQU0sT0FBZ0M7QUFBQSxRQUNwQyxTQUFTLEtBQUs7QUFBQSxRQUNkLFNBQVMsS0FBSztBQUFBLFFBQ2QsUUFBUSxLQUFLLFNBQVM7QUFBQSxNQUN4QjtBQUNBLFVBQUksSUFBSyxNQUFLLE1BQU07QUFDcEIsVUFBSTtBQUNGLGNBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxPQUFPLEtBQUssSUFBSTtBQUNqRCxjQUFNLE1BQU07QUFDWixlQUFPLEVBQUUsTUFBTSxJQUFJLFFBQVEsTUFBTSxLQUFLLElBQUksUUFBUSxLQUFLLEtBQUssSUFBSSxRQUFRLFNBQVM7QUFBQSxNQUNuRixTQUFTLEtBQUs7QUFDWixZQUFJLEVBQUUsZUFBZSxhQUFjLE9BQU07QUFDekMsWUFBSSxJQUFJLFdBQVcsT0FBTyxDQUFDLEtBQUs7QUFFOUIsZ0JBQU0sTUFBTSxLQUFLLFdBQVcsSUFBSTtBQUNoQyxjQUFJLENBQUMsSUFBSyxPQUFNO0FBQ2hCO0FBQUEsUUFDRjtBQUNBLFlBQUksQ0FBQyxJQUFJLGFBQWEsWUFBWSxZQUFhLE9BQU07QUFDckQsY0FBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLElBQUksTUFBTSxtQ0FBbUMsSUFBSSxFQUFFO0FBQUEsRUFDM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU0EsTUFBTSxZQUFZLE1BQXNEO0FBQ3RFLFFBQUksS0FBSyxNQUFNLFdBQVcsRUFBRyxPQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFDOUUsVUFBTSxjQUFjO0FBQ3BCLFFBQUksVUFBbUI7QUFFdkIsYUFBUyxVQUFVLEdBQUcsV0FBVyxhQUFhLFdBQVc7QUFDdkQsVUFBSTtBQUNGLGNBQU0sUUFBUSxNQUFNLFFBQVE7QUFBQSxVQUMxQixLQUFLLE1BQU0sSUFBSSxPQUFPLFNBQVM7QUFDN0Isa0JBQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxjQUNyQjtBQUFBLGNBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsY0FDbkQ7QUFBQSxnQkFDRSxTQUFTLEtBQUs7QUFBQSxnQkFDZCxVQUFVO0FBQUEsY0FDWjtBQUFBLFlBQ0Y7QUFDQSxtQkFBTztBQUFBLGNBQ0wsTUFBTSxLQUFLO0FBQUEsY0FDWCxLQUFNLElBQXdCO0FBQUEsWUFDaEM7QUFBQSxVQUNGLENBQUM7QUFBQSxRQUNIO0FBRUEsY0FBTSxPQUFPLE1BQU0sS0FBSyxjQUFjO0FBQ3RDLGNBQU0sT0FBTyxNQUFNLEtBQUs7QUFBQSxVQUN0QjtBQUFBLFVBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsVUFDbkQ7QUFBQSxZQUNFLFdBQVcsS0FBSztBQUFBLFlBQ2hCLE1BQU0sTUFBTSxJQUFJLENBQUMsVUFBVTtBQUFBLGNBQ3pCLE1BQU0sS0FBSztBQUFBLGNBQ1gsTUFBTTtBQUFBLGNBQ04sTUFBTTtBQUFBLGNBQ04sS0FBSyxLQUFLO0FBQUEsWUFDWixFQUFFO0FBQUEsVUFDSjtBQUFBLFFBQ0Y7QUFDQSxjQUFNLFVBQVcsS0FBeUI7QUFDMUMsY0FBTSxTQUFTLE1BQU0sS0FBSztBQUFBLFVBQ3hCO0FBQUEsVUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxVQUNuRDtBQUFBLFlBQ0UsU0FBUyxLQUFLO0FBQUEsWUFDZCxNQUFNO0FBQUEsWUFDTixTQUFTLENBQUMsS0FBSyxHQUFHO0FBQUEsVUFDcEI7QUFBQSxRQUNGO0FBQ0EsY0FBTSxZQUFZO0FBQ2xCLFlBQUk7QUFDRixnQkFBTSxLQUFLO0FBQUEsWUFDVDtBQUFBLFlBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLG1CQUFtQixXQUFXLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxZQUN0RztBQUFBLGNBQ0UsS0FBSyxVQUFVO0FBQUEsY0FDZixPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFNBQVMsS0FBSztBQUNaLGNBQUksV0FBVyxHQUFHLEtBQUssVUFBVSxhQUFhO0FBQzVDLHNCQUFVO0FBQ1Ysa0JBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQ25DO0FBQUEsVUFDRjtBQUNBLGdCQUFNO0FBQUEsUUFDUjtBQUNBLGVBQU87QUFBQSxVQUNMLFdBQVcsVUFBVTtBQUFBLFVBQ3JCLEtBQUssVUFBVTtBQUFBLFVBQ2YsT0FBTyxLQUFLLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxJQUFJO0FBQUEsUUFDM0M7QUFBQSxNQUNGLFNBQVMsS0FBSztBQUNaLGtCQUFVO0FBQ1YsWUFBSSxFQUFFLGVBQWUsYUFBYyxPQUFNO0FBQ3pDLFlBQUssQ0FBQyxJQUFJLGFBQWEsQ0FBQyxXQUFXLEdBQUcsS0FBTSxZQUFZLFlBQWEsT0FBTTtBQUMzRSxjQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sbUJBQW1CLFFBQVEsVUFBVSxJQUFJLE1BQU0saUNBQWlDO0FBQUEsRUFDeEY7QUFBQSxFQUVBLE1BQWMsZ0JBQTJEO0FBQ3ZFLFVBQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxNQUNyQjtBQUFBLE1BQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGtCQUFrQixXQUFXLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxJQUN2RztBQUNBLFVBQU0sVUFBVyxJQUFvQyxPQUFPO0FBQzVELFVBQU0sU0FBUyxNQUFNLEtBQUs7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGdCQUFnQixPQUFPO0FBQUEsSUFDNUU7QUFDQSxXQUFPO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTCxTQUFVLE9BQXFDLEtBQUs7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQWMsVUFBVSxRQUFnQixNQUFjLE1BQWtDO0FBQ3RGLFVBQU0sTUFBTSxLQUFLLFdBQVcsTUFBTSxJQUFJLE9BQU8sR0FBRyxRQUFRLEdBQUcsSUFBSTtBQUMvRCxVQUFNLE9BQW9CO0FBQUEsTUFDeEI7QUFBQSxNQUNBLFNBQVM7QUFBQSxRQUNQLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRztBQUFBLFFBQzFDLFFBQVE7QUFBQSxRQUNSLHdCQUF3QjtBQUFBLFFBQ3hCLEdBQUksT0FBTyxFQUFFLGdCQUFnQixtQkFBbUIsSUFBSSxDQUFDO0FBQUEsTUFDdkQ7QUFBQSxNQUNBLEdBQUksT0FBTyxFQUFFLE1BQU0sS0FBSyxVQUFVLElBQUksRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMvQztBQUNBLFFBQUk7QUFDSixRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSyxJQUFJO0FBQUEsSUFDN0IsU0FBUyxRQUFRO0FBQ2YsWUFBTSxJQUFJLFlBQVk7QUFBQSxRQUNwQixRQUFRO0FBQUEsUUFDUixNQUFNO0FBQUEsUUFDTixTQUFTLFlBQVksY0FBYyxNQUFNLEVBQUUsT0FBTztBQUFBLFFBQ2xELFdBQVc7QUFBQSxRQUNYLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSSxJQUFJLFdBQVcsSUFBSyxRQUFPO0FBQy9CLFFBQUksU0FBa0I7QUFDdEIsVUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0FBQzVCLFFBQUksTUFBTTtBQUNSLFVBQUk7QUFDRixpQkFBUyxLQUFLLE1BQU0sSUFBSTtBQUFBLE1BQzFCLFFBQVE7QUFDTixpQkFBUztBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLElBQUksR0FBSSxPQUFNLE1BQU0sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEdBQUcsTUFBTSxJQUFJLElBQUksRUFBRTtBQUNsRixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUEsTUFBYyxVQUFVLEtBQWUsT0FBcUM7QUFDMUUsUUFBSSxTQUFrQjtBQUN0QixRQUFJO0FBQ0YsWUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0FBQzVCLFVBQUksS0FBTSxVQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsSUFDcEMsUUFBUTtBQUFBLElBRVI7QUFDQSxXQUFPLEtBQUssb0JBQW9CLEtBQUssUUFBUSxLQUFLO0FBQUEsRUFDcEQ7QUFBQSxFQUVRLG9CQUFvQixLQUFlLE1BQWUsT0FBNEI7QUFDcEYsVUFBTSxNQUNKLE9BQU8sU0FBUyxZQUFZLFFBQVEsYUFBYSxPQUM3QyxPQUFRLEtBQThCLE9BQU8sSUFDN0MsSUFBSTtBQUNWLFFBQUksV0FBb0M7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7QUFFNUMsWUFBTSxPQUFPLElBQUksUUFBUSxJQUFJLHVCQUF1QjtBQUNwRCxVQUFJLFNBQVMsT0FBTyxjQUFjLEtBQUssR0FBRyxHQUFHO0FBQzNDLG1CQUFXO0FBQ1gsb0JBQVk7QUFBQSxNQUNkLE9BQU87QUFDTCxtQkFBVztBQUFBLE1BQ2I7QUFBQSxJQUNGLFdBQVcsSUFBSSxXQUFXLEtBQUs7QUFDN0IsaUJBQVc7QUFBQSxJQUNiLFdBQVcsSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7QUFDbkQsaUJBQVc7QUFBQSxJQUNiLFdBQVcsSUFBSSxVQUFVLEtBQUs7QUFDNUIsaUJBQVc7QUFDWCxrQkFBWTtBQUFBLElBQ2QsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZDtBQUNBLFdBQU8sSUFBSSxZQUFZO0FBQUEsTUFDckIsUUFBUSxJQUFJO0FBQUEsTUFDWjtBQUFBLE1BQ0EsU0FBUyxHQUFHLEtBQUssV0FBTSxJQUFJLE1BQU0sS0FBSyxHQUFHO0FBQUEsTUFDekM7QUFBQSxNQUNBO0FBQUEsTUFDQSxrQkFBa0IsYUFBYSxlQUFlLG9CQUFvQixJQUFJLE9BQU8sSUFBSTtBQUFBLElBQ25GLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFRQSxTQUFTLG9CQUFvQixTQUFpQztBQUM1RCxRQUFNLFFBQVEsUUFBUSxJQUFJLG1CQUFtQjtBQUM3QyxNQUFJLE9BQU87QUFDVCxVQUFNLElBQUksT0FBTyxTQUFTLE9BQU8sRUFBRTtBQUNuQyxRQUFJLE9BQU8sU0FBUyxDQUFDLEtBQUssSUFBSSxFQUFHLFFBQU87QUFBQSxFQUMxQztBQUNBLFFBQU0sYUFBYSxRQUFRLElBQUksYUFBYTtBQUM1QyxNQUFJLFlBQVk7QUFDZCxVQUFNLFFBQVEsT0FBTyxTQUFTLFlBQVksRUFBRTtBQUM1QyxRQUFJLE9BQU8sU0FBUyxLQUFLLEtBQUssU0FBUyxHQUFHO0FBQ3hDLGFBQU8sS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUksSUFBSTtBQUFBLElBQ3pDO0FBQ0EsVUFBTSxTQUFTLEtBQUssTUFBTSxVQUFVO0FBQ3BDLFFBQUksT0FBTyxTQUFTLE1BQU0sRUFBRyxRQUFPLEtBQUssTUFBTSxTQUFTLEdBQUk7QUFBQSxFQUM5RDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxNQUFzQjtBQUV4QyxTQUFPLEtBQUssTUFBTSxHQUFHLEVBQUUsSUFBSSxrQkFBa0IsRUFBRSxLQUFLLEdBQUc7QUFDekQ7QUFFQSxTQUFTLFVBQVUsU0FBaUIsS0FBMEI7QUFFNUQsUUFBTSxPQUFPLElBQUksYUFBYSxlQUFlLE1BQU87QUFDcEQsUUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFHO0FBQzdDLFNBQU8sS0FBSyxJQUFJLEtBQVEsT0FBTyxNQUFNLFVBQVUsS0FBSyxNQUFNO0FBQzVEO0FBRUEsU0FBUyxXQUFXLEtBQWtDO0FBQ3BELFNBQU8sZUFBZSxlQUFlLElBQUksYUFBYTtBQUN4RDtBQUVBLFNBQVMsTUFBTSxJQUEyQjtBQUN4QyxTQUFPLElBQUksUUFBUSxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQztBQUM3QztBQUVPLFNBQVNBLFVBQVMsT0FBdUI7QUFFOUMsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFLE9BQU8sS0FBSztBQUMzQyxNQUFJLE1BQU07QUFDVixhQUFXLEtBQUssS0FBTSxRQUFPLE9BQU8sYUFBYSxDQUFDO0FBQ2xELFNBQU8sS0FBSyxHQUFHO0FBQ2pCOzs7QUMzWEEsSUFBTSxjQUFjO0FBU3BCLElBQU0sdUJBQTRDLG9CQUFJLElBQUksQ0FBQyxXQUFXLENBQUM7QUFFaEUsU0FBUyxVQUFVLFNBQWtCLEtBQXdDO0FBQ2xGLFFBQU0sWUFBWSxjQUFjLE9BQU87QUFDdkMsUUFBTSxTQUEyQixDQUFDO0FBQ2xDLFFBQU0sb0JBQXdDLENBQUM7QUFDL0MsUUFBTSxXQUFxQixDQUFDO0FBQzVCLFFBQU0sUUFBUSxvQkFBSSxJQUFZO0FBQzlCLFFBQU0sYUFBYSxvQkFBSSxJQUEyQjtBQUNsRCxRQUFNLGtCQUFrQixxQkFBcUIsSUFBSSxJQUFJLFFBQVE7QUFDN0QsYUFBVyxPQUFPLFdBQVc7QUFDM0IsUUFBSTtBQUNGLFlBQU0sY0FBYyxxQkFBcUIsS0FBSyxHQUFHO0FBQ2pELFVBQUksYUFBYTtBQUNmLDBCQUFrQixLQUFLLFdBQVc7QUFDbEMsaUJBQVMsS0FBSyxZQUFZLFFBQVE7QUFDbEMsY0FBTSxJQUFJLFlBQVksUUFBUTtBQUM5QjtBQUFBLE1BQ0Y7QUFDQSxZQUFNLElBQUksV0FBVyxLQUFLLEdBQUc7QUFDN0IsVUFBSSxDQUFDLEdBQUc7QUFDTixZQUFJLGlCQUFpQjtBQUluQixnQkFBTSxVQUFVLFlBQVksR0FBRztBQUMvQixjQUFJLFFBQVMsWUFBVyxJQUFJLFFBQVEsVUFBVSxRQUFRLFdBQVc7QUFBQSxRQUNuRTtBQUNBO0FBQUEsTUFDRjtBQUNBLGVBQVMsS0FBSyxFQUFFLFFBQVE7QUFDeEIsWUFBTSxJQUFJLEVBQUUsUUFBUTtBQUNwQixVQUFJLElBQUksZUFBZSxTQUFTLEtBQUssSUFBSSxlQUFlLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxHQUFHO0FBQzNGLGVBQU8sS0FBSyxDQUFDO0FBQUEsTUFDZjtBQUFBLElBQ0YsUUFBUTtBQUFBLElBRVI7QUFBQSxFQUNGO0FBR0EsUUFBTSxjQUF1RSxDQUFDO0FBQzlFLGFBQVcsQ0FBQyxJQUFJLElBQUksS0FBSyxZQUFZO0FBQ25DLFFBQUksTUFBTSxJQUFJLEVBQUUsRUFBRztBQUNuQixnQkFBWSxLQUFLLEVBQUUsVUFBVSxJQUFJLGFBQWEsS0FBSyxDQUFDO0FBQUEsRUFDdEQ7QUFDQSxTQUFPLEVBQUUsUUFBUSxjQUFjLFVBQVUsb0JBQW9CLG1CQUFtQixZQUFZO0FBQzlGO0FBRUEsU0FBUyxxQkFBcUIsTUFBZSxLQUFnRDtBQUMzRixNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLE1BQUksRUFBRSxlQUFlLGlCQUFrQixRQUFPO0FBRTlDLFFBQU0sVUFDSixVQUFVLEVBQUUsT0FBTyxLQUNuQixvQkFBb0IsSUFBSSxNQUN2QixJQUFJLFlBQVksb0JBQW9CLElBQUksU0FBUyxJQUFJO0FBQ3hELE1BQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxLQUFLLE9BQU8sRUFBRyxRQUFPO0FBRW5ELFFBQU0sa0JBQWtCLGtCQUFrQixJQUFJO0FBQzlDLFNBQU87QUFBQSxJQUNMLFVBQVU7QUFBQSxJQUNWLGdCQUNFLHdCQUF3QixNQUFNLE9BQU8sTUFDcEMsSUFBSSxZQUFZLG1CQUFtQixJQUFJLFdBQVcsT0FBTyxJQUFJO0FBQUEsSUFDaEUseUJBQXlCLElBQUk7QUFBQSxJQUM3QixvQkFBb0IsMEJBQTBCLGVBQWU7QUFBQSxJQUM3RCxrQkFBa0I7QUFBQSxJQUNsQix3QkFBd0IsSUFBSSxhQUFhO0FBQUEsRUFDM0M7QUFDRjtBQUVBLFNBQVMsb0JBQW9CLE1BQThCO0FBQ3pELFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sTUFBTSxNQUFNLElBQUk7QUFDdEIsUUFBSSxPQUFPLFFBQVEsVUFBVTtBQUMzQixZQUFNLEtBQUssb0JBQW9CLEdBQUc7QUFDbEMsVUFBSSxHQUFJLFFBQU87QUFDZjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVTtBQUM3QyxRQUFJLEtBQUssSUFBSSxHQUFhLEVBQUc7QUFDN0IsU0FBSyxJQUFJLEdBQWE7QUFDdEIsUUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQ3RCLGlCQUFXLEtBQUssSUFBSyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ25DLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxHQUE4QixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDN0U7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxvQkFBb0IsUUFBK0I7QUFDMUQsTUFBSTtBQUNGLFVBQU0sTUFBTSxJQUFJLElBQUksUUFBUSxnQkFBZ0I7QUFDNUMsUUFBSSxJQUFJLGFBQWEsV0FBVyxJQUFJLGFBQWEsY0FBZSxRQUFPO0FBQ3ZFLFVBQU0sUUFBUSxJQUFJLFNBQVMsTUFBTSxvREFBb0Q7QUFDckYsV0FBTyxRQUFRLENBQUMsS0FBSztBQUFBLEVBQ3ZCLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxrQkFBa0IsTUFBOEI7QUFDdkQsUUFBTSxVQUFvQixDQUFDO0FBQzNCLFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sTUFBTSxNQUFNLElBQUk7QUFDdEIsUUFBSSxPQUFPLFFBQVEsVUFBVTtBQUMzQixZQUFNLFVBQVUsSUFBSSxLQUFLO0FBQ3pCLFVBQ0UsUUFBUSxVQUFVLEtBQ2xCLENBQUMsUUFBUSxXQUFXLFNBQVMsS0FDN0IsQ0FBQyxRQUFRLFdBQVcsVUFBVSxHQUM5QjtBQUNBLGdCQUFRLEtBQUssT0FBTztBQUFBLE1BQ3RCO0FBQ0E7QUFBQSxJQUNGO0FBQ0EsUUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVU7QUFDN0MsUUFBSSxLQUFLLElBQUksR0FBYSxFQUFHO0FBQzdCLFNBQUssSUFBSSxHQUFhO0FBQ3RCLFFBQUksTUFBTSxRQUFRLEdBQUcsR0FBRztBQUN0QixpQkFBVyxLQUFLLElBQUssT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNuQyxPQUFPO0FBQ0wsaUJBQVcsS0FBSyxPQUFPLE9BQU8sR0FBOEIsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQzdFO0FBQUEsRUFDRjtBQUNBLFFBQU0sWUFBWSxRQUFRO0FBQUEsSUFBSyxDQUFDLE1BQzlCLDhFQUE4RSxLQUFLLENBQUM7QUFBQSxFQUN0RjtBQUNBLFNBQU8sYUFBYSxRQUFRLENBQUMsS0FBSztBQUNwQztBQUVBLFNBQVMsMEJBQTBCLE1BQW9DO0FBQ3JFLE1BQUksQ0FBQyxLQUFNLFFBQU87QUFDbEIsTUFBSSx3QkFBd0IsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUMvQyxNQUFJLGdCQUFnQixLQUFLLElBQUksRUFBRyxRQUFPO0FBQ3ZDLE1BQUksdUJBQXVCLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDOUMsTUFBSSxpQkFBaUIsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUN4QyxNQUFJLGlDQUFpQyxLQUFLLElBQUksRUFBRyxRQUFPO0FBQ3hELFNBQU87QUFDVDtBQUVBLFNBQVMsWUFBWSxNQUF3RTtBQUMzRixNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUdWLE1BQUksRUFBRSxlQUFlLGlCQUFrQixRQUFPO0FBRzlDLFFBQU0sS0FBSyxFQUFFO0FBQ2IsTUFBSSxPQUFPLFdBQVcsT0FBTyxnQ0FBZ0MsQ0FBQyxJQUFJLEVBQUUsTUFBTSxHQUFHO0FBQzNFLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxTQUNILE9BQU8sRUFBRSxZQUFZLFlBQVksRUFBRSxXQUNuQyxPQUFPLElBQUksRUFBRSxZQUFZLEdBQUcsV0FBVyxZQUNyQyxJQUFJLElBQUksRUFBRSxZQUFZLEdBQUcsTUFBTSxHQUFHO0FBQ3ZDLE1BQUksT0FBTyxXQUFXLFlBQVksQ0FBQyxZQUFZLEtBQUssTUFBTSxFQUFHLFFBQU87QUFDcEUsUUFBTSxhQUFhLGVBQWUsTUFBTSxNQUFNO0FBQzlDLE1BQUksQ0FBQyxXQUFZLFFBQU87QUFDeEIsU0FBTyxFQUFFLFVBQVUsUUFBUSxhQUFhLFdBQVc7QUFDckQ7QUFFQSxTQUFTLGVBQWUsTUFBZSxTQUFnQztBQUNyRSxNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLFFBQU0sYUFBYSxJQUFJLElBQUksSUFBSSxFQUFFLElBQUksR0FBRyxZQUFZLEdBQUcsTUFBTTtBQUM3RCxTQUNFLFVBQVUsSUFBSSxZQUFZLElBQUksR0FBRyxXQUFXLEtBQzVDLFVBQVUsSUFBSSxZQUFZLE1BQU0sR0FBRyxXQUFXLEtBQzlDLFVBQVUsSUFBSSxFQUFFLE1BQU0sR0FBRyxXQUFXLEtBQ3BDLHdCQUF3QixNQUFNLE9BQU87QUFFekM7QUFFQSxTQUFTLHdCQUF3QixNQUFlLFNBQWdDO0FBQzlFLFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sTUFBTSxNQUFNLElBQUk7QUFDdEIsUUFBSSxPQUFPLFFBQVEsVUFBVTtBQUMzQixZQUFNLFNBQVMsbUJBQW1CLEtBQUssT0FBTztBQUM5QyxVQUFJLE9BQVEsUUFBTztBQUNuQjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVTtBQUM3QyxRQUFJLEtBQUssSUFBSSxHQUFhLEVBQUc7QUFDN0IsU0FBSyxJQUFJLEdBQWE7QUFDdEIsUUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQ3RCLGlCQUFXLEtBQUssSUFBSyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ25DLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxHQUE4QixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDN0U7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxtQkFBbUIsUUFBZ0IsU0FBZ0M7QUFDMUUsTUFBSTtBQUNGLFVBQU0sTUFBTSxJQUFJLElBQUksUUFBUSxnQkFBZ0I7QUFDNUMsUUFBSSxJQUFJLGFBQWEsV0FBVyxJQUFJLGFBQWEsY0FBZSxRQUFPO0FBQ3ZFLFVBQU0sUUFBUSxJQUFJLFNBQVMsTUFBTSxzREFBc0Q7QUFDdkYsUUFBSSxDQUFDLFNBQVMsTUFBTSxDQUFDLE1BQU0sUUFBUyxRQUFPO0FBQzNDLFdBQU8sTUFBTSxDQUFDLEtBQUs7QUFBQSxFQUNyQixRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsY0FBY0MsTUFBeUI7QUFLOUMsUUFBTSxNQUFpQixDQUFDO0FBQ3hCLFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUNBLElBQUc7QUFDN0IsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE9BQU8sTUFBTSxJQUFJO0FBQ3ZCLFFBQUksU0FBUyxRQUFRLFNBQVMsT0FBVztBQUN6QyxRQUFJLE9BQU8sU0FBUyxTQUFVO0FBQzlCLFFBQUksS0FBSyxJQUFJLElBQWMsRUFBRztBQUM5QixTQUFLLElBQUksSUFBYztBQUV2QixRQUFJLGVBQWUsSUFBSSxHQUFHO0FBQ3hCLFVBQUksS0FBSyxZQUFZLElBQUksQ0FBQztBQUFBLElBQzVCO0FBQ0EsUUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGlCQUFXLEtBQUssS0FBTSxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ3BDLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxJQUErQixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDOUU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxlQUFlLE1BQWdEO0FBQ3RFLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsUUFBTSxXQUFXLEVBQUU7QUFDbkIsTUFDRSxhQUFhLFdBQ2IsYUFBYSxnQ0FDYixhQUFhLGtCQUNiO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUFPLE9BQU8sRUFBRSxZQUFZLFlBQVksT0FBTyxFQUFFLFdBQVcsWUFBWSxFQUFFLFdBQVc7QUFDdkY7QUFFQSxTQUFTLFlBQVksTUFBd0Q7QUFDM0UsTUFBSSxLQUFLLGVBQWUsZ0NBQWdDLE9BQU8sS0FBSyxVQUFVLFVBQVU7QUFDdEYsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxLQUFjLEtBQThDO0FBQzlFLE1BQUksT0FBTyxRQUFRLFlBQVksUUFBUSxLQUFNLFFBQU87QUFDcEQsUUFBTSxJQUFJO0FBRVYsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFFOUMsUUFBTSxTQUFTLFVBQVUsRUFBRSxPQUFPO0FBS2xDLFFBQU0sU0FBUyxJQUFJLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDakMsTUFBSSxDQUFDLE9BQVEsUUFBTztBQUVwQixRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksSUFBSSxNQUFNLFlBQVksR0FBRyxNQUFNO0FBR3RELFFBQU0sY0FBYyxJQUFJLFlBQVksSUFBSTtBQUN4QyxRQUFNLGFBQWEsSUFBSSxZQUFZLE1BQU07QUFDekMsUUFBTSxnQkFBZ0IsSUFBSSxZQUFZLE1BQU07QUFDNUMsUUFBTSxTQUNKLFVBQVUsYUFBYSxXQUFXLEtBQ2xDLFVBQVUsWUFBWSxXQUFXLEtBQ2pDLFVBQVUsWUFBWSxXQUFXLEtBQ2pDLFVBQVUsT0FBTyxXQUFXO0FBQzlCLFFBQU0sWUFDSixVQUFVLFlBQVksT0FBTyxLQUM3QixVQUFVLFlBQVksTUFBTSxLQUM1QixVQUFVLE9BQU8sV0FBVztBQUM5QixNQUFJLENBQUMsVUFBVSxDQUFDLFVBQVcsUUFBTztBQU1sQyxRQUFNLFNBQVMsb0JBQW9CLFlBQVksYUFBYSxZQUFZLGFBQWE7QUFFckYsUUFBTSxZQUFZLElBQUksSUFBSSxJQUFJLEVBQUUsVUFBVSxHQUFHLGtCQUFrQixHQUFHLE1BQU07QUFDeEUsUUFBTSxlQUFlLFVBQVUsV0FBVyxJQUFJO0FBQzlDLFFBQU0saUJBQWlCLFVBQVUsT0FBTyxTQUFTLEtBQUs7QUFDdEQsUUFBTSxPQUFPLGdCQUFnQjtBQUM3QixRQUFNLGNBQWMsaUJBQWlCLFdBQVcsUUFBUSxjQUFjO0FBQ3RFLFFBQU0sZ0JBQWdCLHFCQUFxQixHQUFHLFFBQVEsSUFBSSxVQUFVO0FBRXBFLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUSxLQUFLLENBQUM7QUFDMUMsUUFBTSxtQkFBbUIsSUFBSSxXQUFXLFVBQVU7QUFDbEQsUUFBTSxXQUFXLGdCQUFnQixvQkFBb0IsUUFBUTtBQUM3RCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sT0FBTyxZQUFZLG9CQUFvQixRQUFRO0FBQ3JELFFBQU0sUUFBUSxhQUFhLE1BQU07QUFFakMsUUFBTSxZQUFZLGtCQUFrQixHQUFHLE1BQU07QUFJN0MsUUFBTSxXQUNKLGlCQUFpQixVQUFVLE9BQU8sVUFBVSxDQUFDLEtBQUssaUJBQWlCLFVBQVUsRUFBRSxVQUFVLENBQUM7QUFDNUYsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUV0QixRQUFNLFFBQVEsSUFBSSxFQUFFLEtBQUs7QUFDekIsUUFBTSxZQUFZLFVBQVUsT0FBTyxLQUFLLEtBQUssVUFBVSxVQUFVLE9BQU8sS0FBSyxDQUFDO0FBRTlFLFFBQU0sT0FBTyxZQUFZLENBQUM7QUFDMUIsUUFBTSxRQUFRLElBQUksT0FBTyxLQUFLO0FBRTlCLFFBQU0sUUFBd0I7QUFBQSxJQUM1QixVQUFVO0FBQUEsSUFDVixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixXQUFXO0FBQUEsSUFDWCxtQkFBbUIsSUFBSTtBQUFBLElBQ3ZCLGNBQWMsSUFBSTtBQUFBLElBQ2xCLHNCQUFzQjtBQUFBLElBQ3RCLHlCQUF5QjtBQUFBLElBQ3pCLG9CQUFvQjtBQUFBLElBQ3BCLGtCQUFrQjtBQUFBLElBQ2xCLHdCQUF3QjtBQUFBLElBQ3hCLFdBQVcsR0FBRyxnQkFBZ0IsSUFBSSxNQUFNLFdBQVcsTUFBTTtBQUFBLElBQ3pELFlBQVk7QUFBQSxJQUNaLGlCQUFpQixVQUFVLE9BQU8sbUJBQW1CO0FBQUEsSUFDckQsbUJBQW1CLFVBQVUsT0FBTyx5QkFBeUI7QUFBQSxJQUM3RCxrQkFBa0IsVUFBVSxPQUFPLHVCQUF1QjtBQUFBLElBQzFELHFCQUFxQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDN0QsaUJBQWlCLFVBQVUsT0FBTyxvQkFBb0I7QUFBQSxJQUN0RCxvQkFBb0I7QUFBQSxNQUNsQixJQUFJLElBQUksT0FBTyx1QkFBdUIsR0FBRyxNQUFNLEdBQUcsV0FDL0MsT0FBbUM7QUFBQSxJQUN4QztBQUFBLElBQ0E7QUFBQSxJQUNBLGVBQWUsaUJBQWlCLE1BQU0sSUFBSTtBQUFBLElBQzFDLE1BQU0sVUFBVSxPQUFPLElBQUk7QUFBQSxJQUMzQixvQkFBb0IsV0FBVyxPQUFPLGtCQUFrQjtBQUFBLElBQ3hELFFBQVEsVUFBVSxPQUFPLE1BQU0sS0FBSyxVQUFVLEVBQUUsTUFBTTtBQUFBLElBQ3RELGlCQUFpQixVQUFVLE9BQU8sU0FBUztBQUFBLElBQzNDO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWSxVQUFVLE9BQU8sY0FBYztBQUFBLElBQzNDLGVBQWUsVUFBVSxPQUFPLGFBQWE7QUFBQSxJQUM3QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsYUFBYSxVQUFVLE9BQU8sV0FBVztBQUFBLElBQ3pDLFlBQVk7QUFBQSxJQUNaLGdCQUFnQixVQUFVLE9BQU8sY0FBYztBQUFBLElBQy9DLG9CQUFvQjtBQUFBLE1BQ2xCO0FBQUEsUUFDRSxhQUFhLElBQUk7QUFBQSxRQUNqQixPQUFPLFVBQVUsT0FBTyxjQUFjO0FBQUEsUUFDdEMsVUFBVSxVQUFVLE9BQU8sYUFBYTtBQUFBLFFBQ3hDLFNBQVMsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNyQyxRQUFRLFVBQVUsT0FBTyxXQUFXO0FBQUEsUUFDcEMsT0FBTztBQUFBLFFBQ1AsV0FBVyxVQUFVLE9BQU8sY0FBYztBQUFBLE1BQzVDO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFBQSxJQUNBLGdCQUFnQjtBQUFBLElBQ2hCLGNBQWM7QUFBQSxJQUNkLGFBQWE7QUFBQSxJQUNiLHNCQUFzQjtBQUFBLElBQ3RCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsRUFDbEI7QUFFQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGtCQUFrQixHQUE0QixRQUE0QztBQUNqRyxNQUFJLE9BQU8sMkJBQTJCLE9BQU8sd0JBQXlCLFFBQU87QUFDN0UsTUFBSSxPQUFPLDBCQUEyQixRQUFPO0FBQzdDLE1BQUksT0FBTyxvQkFBb0IsUUFBUSxPQUFPLHFCQUFzQixRQUFPO0FBQzNFLE1BQUksRUFBRSxlQUFlLDhCQUE4QjtBQUFBLEVBRW5EO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxnQkFBZ0IsVUFBNkM7QUFDcEUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFNBQU8sSUFDSjtBQUFBLElBQUksQ0FBQyxNQUNKLE9BQU8sTUFBTSxZQUFZLEtBQUssVUFBVSxJQUFJLE9BQVEsRUFBd0IsSUFBSSxJQUFJO0FBQUEsRUFDdEYsRUFDQyxPQUFPLENBQUMsTUFBbUIsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLENBQUM7QUFDckU7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsSUFDM0MsT0FBUSxFQUErQixXQUFXLElBQ2xEO0FBQUEsRUFDTixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsWUFBWSxVQUFnRDtBQUNuRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsUUFBTSxNQUFtQixDQUFDO0FBQzFCLGFBQVcsS0FBSyxLQUFLO0FBQ25CLFFBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFVBQU0sSUFBSTtBQUNWLFVBQU0sUUFBUSxVQUFVLEVBQUUsR0FBRztBQUM3QixVQUFNLFdBQVcsVUFBVSxFQUFFLFlBQVk7QUFDekMsVUFBTSxVQUFVLFVBQVUsRUFBRSxXQUFXO0FBQ3ZDLFFBQUksQ0FBQyxTQUFTLENBQUMsU0FBVTtBQUN6QixRQUFJLEtBQUssRUFBRSxPQUFPLFVBQVUsU0FBUyxXQUFXLFNBQVMsQ0FBQztBQUFBLEVBQzVEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLFFBQThDO0FBQ2xFLFFBQU0sV0FBVyxJQUFJLE9BQU8saUJBQWlCO0FBQzdDLFFBQU0sVUFBVSxXQUFXLFFBQVEsU0FBUyxLQUFLLElBQUksQ0FBQztBQUN0RCxRQUFNLFVBQVUsUUFBUSxJQUFJLE9BQU8sUUFBUSxHQUFHLEtBQUs7QUFDbkQsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxTQUFTLENBQUMsR0FBRyxTQUFTLEdBQUcsT0FBTyxFQUFFLE9BQU8sQ0FBQyxNQUFNO0FBQ3BELFFBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNLFFBQU87QUFDaEQsVUFBTSxLQUNKLFVBQVcsRUFBOEIsU0FBUyxLQUNsRCxVQUFXLEVBQThCLE1BQU07QUFDakQsUUFBSSxDQUFDLEdBQUksUUFBTztBQUNoQixRQUFJLEtBQUssSUFBSSxFQUFFLEVBQUcsUUFBTztBQUN6QixTQUFLLElBQUksRUFBRTtBQUNYLFdBQU87QUFBQSxFQUNULENBQUM7QUFDRCxTQUFPLE9BQU8sSUFBSSxDQUFDLFFBQVEsV0FBVyxHQUE4QixDQUFDO0FBQ3ZFO0FBRUEsU0FBUyxXQUFXLEdBQXVDO0FBQ3pELFFBQU0sT0FBTyxVQUFVLEVBQUUsSUFBSTtBQUM3QixRQUFNLFdBQVcsZ0JBQWdCLEdBQUcsSUFBSTtBQUN4QyxRQUFNQyxRQUFPLElBQUksRUFBRSxhQUFhO0FBQ2hDLFFBQU0sWUFBWSxJQUFJLEVBQUUsVUFBVTtBQUNsQyxRQUFNLGFBQWEsVUFBVSxXQUFXLGVBQWU7QUFDdkQsUUFBTSxVQUFVLFVBQVUsRUFBRSxZQUFZO0FBQ3hDLFFBQU0sVUFDSixVQUFVLEVBQUUsU0FBUyxLQUNyQixVQUFVLEVBQUUsTUFBTSxLQUNsQixHQUFHLFFBQVEsT0FBTyxJQUFJLEtBQUssT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQzNELFNBQU87QUFBQSxJQUNMLFVBQVU7QUFBQSxJQUNWLFlBQWEsUUFBUTtBQUFBLElBQ3JCLGNBQWMsWUFBWTtBQUFBLElBQzFCLG1CQUFtQjtBQUFBLElBQ25CLFFBQVE7QUFBQSxJQUNSLE9BQU87QUFBQSxJQUNQLGNBQWMsZUFBZSxPQUFPLGFBQWEsTUFBTztBQUFBLElBQ3hELE9BQU8sVUFBVUEsT0FBTSxLQUFLO0FBQUEsSUFDNUIsUUFBUSxVQUFVQSxPQUFNLE1BQU07QUFBQSxJQUM5QixVQUFVO0FBQUEsSUFDVixnQkFBZ0I7QUFBQSxJQUNoQixrQkFBa0I7QUFBQSxJQUNsQixpQkFBaUI7QUFBQSxFQUNuQjtBQUNGO0FBRUEsU0FBUyxnQkFBZ0IsR0FBNEIsTUFBb0M7QUFDdkYsTUFBSSxTQUFTLFFBQVMsUUFBTyxVQUFVLEVBQUUsZUFBZSxLQUFLLFVBQVUsRUFBRSxTQUFTO0FBQ2xGLFFBQU0sV0FBVyxRQUFRLElBQUksRUFBRSxVQUFVLEdBQUcsUUFBUTtBQUNwRCxNQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sVUFBVSxFQUFFLGVBQWU7QUFFN0QsTUFBSSxPQUFnRDtBQUNwRCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLEtBQUssVUFBVSxFQUFFLFlBQVk7QUFDbkMsVUFBTSxNQUFNLFVBQVUsRUFBRSxHQUFHO0FBQzNCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsUUFBSSxPQUFPLGFBQWE7QUFDdEIsWUFBTSxLQUFLLFVBQVUsRUFBRSxPQUFPLEtBQUs7QUFDbkMsVUFBSSxDQUFDLFFBQVEsS0FBSyxLQUFLLFFBQVMsUUFBTyxFQUFFLEtBQUssU0FBUyxHQUFHO0FBQUEsSUFDNUQsV0FBVyxDQUFDLE1BQU07QUFFaEIsYUFBTyxFQUFFLEtBQUssU0FBUyxFQUFFO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0EsU0FBTyxNQUFNLE9BQU87QUFDdEI7QUFFQSxTQUFTLGlCQUFpQixNQUFjLE1BQTJCO0FBQ2pFLE1BQUksS0FBSyxXQUFXLEVBQUcsUUFBTztBQUM5QixNQUFJLE1BQU07QUFDVixhQUFXLEtBQUssS0FBTSxPQUFNLElBQUksTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUTtBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxNQUFJLENBQUMsRUFBRyxRQUFPO0FBRWYsUUFBTSxJQUFJLElBQUksS0FBSyxDQUFDO0FBQ3BCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTztBQUN0QyxTQUFPLEVBQUUsWUFBWTtBQUN2QjtBQUVBLFNBQVMsVUFBVSxHQUEyQjtBQUM1QyxTQUFPLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxJQUFJLElBQUk7QUFDckQ7QUFDQSxTQUFTLFdBQVcsR0FBNEI7QUFDOUMsU0FBTyxPQUFPLE1BQU0sWUFBWSxJQUFJO0FBQ3RDO0FBQ0EsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ3hELE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsVUFBTSxJQUFJLE9BQU8sQ0FBQztBQUNsQixRQUFJLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUFBLEVBQ2pDO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLEdBQW9CO0FBQ3JDLFNBQU8sVUFBVSxDQUFDLEtBQUs7QUFDekI7QUFDQSxTQUFTLElBQUksR0FBNEM7QUFDdkQsU0FBTyxPQUFPLE1BQU0sWUFBWSxNQUFNLFFBQVEsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUN6RCxJQUNEO0FBQ047QUFDQSxTQUFTLFFBQVEsR0FBdUI7QUFDdEMsU0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQztBQUNqQztBQXdCQSxTQUFTLGlCQUNQLFdBQ0EsUUFDQSxVQUNTO0FBQ1QsTUFBSSxVQUFXLFFBQU87QUFDdEIsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUN0QixRQUFNLFdBQVcsSUFBSSxPQUFPLFFBQVE7QUFDcEMsUUFBTSxPQUFPLFdBQVcsU0FBUyxPQUFPO0FBQ3hDLE1BQUksTUFBTSxRQUFRLElBQUksR0FBRztBQUN2QixlQUFXLEtBQUssTUFBTTtBQUNwQixVQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTTtBQUN6QyxZQUFNLE1BQU8sRUFBOEI7QUFJM0MsVUFBSSxPQUFPLFFBQVEsWUFBWSx3QkFBd0IsS0FBSyxHQUFHLEdBQUc7QUFDaEUsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQXdCTyxTQUFTLGNBQ2QsUUFDQSxVQUNBLGNBQW1DLG9CQUFJLElBQUksR0FDekI7QUFDbEIsTUFBSSxTQUFTLFNBQVMsS0FBSyxZQUFZLFNBQVMsRUFBRyxRQUFPO0FBSzFELFFBQU0sZ0JBQWdCLG9CQUFJLElBQVk7QUFDdEMsUUFBTSxtQkFBbUIsb0JBQUksSUFBWTtBQUN6QyxhQUFXLEtBQUssUUFBUTtBQUN0QixRQUFJLENBQUMsU0FBUyxJQUFJLEVBQUUsZUFBZSxZQUFZLENBQUMsRUFBRztBQUNuRCxxQkFBaUIsSUFBSSxFQUFFLFFBQVE7QUFDL0IsUUFBSSxFQUFFLGdCQUFpQixlQUFjLElBQUksRUFBRSxlQUFlO0FBQzFELFFBQUksRUFBRSxtQkFBb0IsZUFBYyxJQUFJLEVBQUUsa0JBQWtCO0FBQ2hFLFFBQUksRUFBRSxrQkFBbUIsZUFBYyxJQUFJLEVBQUUsaUJBQWlCO0FBQUEsRUFDaEU7QUFDQSxTQUFPLE9BQU8sT0FBTyxDQUFDLE1BQU07QUFDMUIsVUFBTSxJQUFJLEVBQUUsZUFBZSxZQUFZO0FBQ3ZDLFFBQUksU0FBUyxJQUFJLENBQUMsRUFBRyxRQUFPO0FBQzVCLFFBQUksWUFBWSxJQUFJLENBQUMsRUFBRyxRQUFPO0FBRS9CLFFBQUksY0FBYyxJQUFJLEVBQUUsUUFBUSxFQUFHLFFBQU87QUFJMUMsUUFBSSxFQUFFLG1CQUFtQixpQkFBaUIsSUFBSSxFQUFFLGVBQWUsRUFBRyxRQUFPO0FBQ3pFLFFBQUksRUFBRSxxQkFBcUIsaUJBQWlCLElBQUksRUFBRSxpQkFBaUIsRUFBRyxRQUFPO0FBRTdFLFFBQUksRUFBRSxvQkFBb0IsU0FBUyxJQUFJLEVBQUUsaUJBQWlCLFlBQVksQ0FBQyxFQUFHLFFBQU87QUFDakYsZUFBVyxLQUFLLEVBQUUsVUFBVTtBQUMxQixVQUFJLFNBQVMsSUFBSSxFQUFFLFlBQVksQ0FBQyxFQUFHLFFBQU87QUFBQSxJQUM1QztBQUNBLFdBQU87QUFBQSxFQUNULENBQUM7QUFDSDtBQVNBLFNBQVMscUJBQ1AsR0FDQSxRQUNBLFlBQ3NCO0FBQ3RCLFFBQU0sUUFBUSxJQUFJLEVBQUUsZUFBZSxLQUFLLElBQUksT0FBTyxlQUFlO0FBQ2xFLE1BQUksQ0FBQyxNQUFPLFFBQU87QUFDbkIsUUFBTSxXQUFXLElBQUksTUFBTSxRQUFRO0FBQ25DLFFBQU0sT0FBTyxJQUFJLE1BQU0sSUFBSTtBQUMzQixRQUFNLFVBQVUsVUFBVSxVQUFVLElBQUk7QUFDeEMsUUFBTSxRQUFRLFVBQVUsTUFBTSxLQUFLO0FBQ25DLFFBQU0sYUFBYSxVQUFVLE1BQU0sVUFBVTtBQUM3QyxRQUFNLGlCQUFpQixVQUFVLE1BQU0sY0FBYztBQUNyRCxRQUFNLFNBQVMsVUFBVSxNQUFNLE1BQU0sS0FBSyxVQUFVLE1BQU0sT0FBTztBQUVqRSxNQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxPQUFRLFFBQU87QUFDMUMsU0FBTztBQUFBLElBQ0wsU0FBUztBQUFBLElBQ1Q7QUFBQSxJQUNBLGFBQWE7QUFBQSxJQUNiO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxJQUNqQixhQUFhO0FBQUEsRUFDZjtBQUNGO0FBT0EsU0FBUyxvQkFDUCxZQUNBLGFBQ0EsWUFDQSxlQUNjO0FBQ2QsUUFBTSxlQUFlLElBQUksWUFBWSxZQUFZO0FBQ2pELFNBQU87QUFBQSxJQUNMLGNBQ0UsVUFBVSxhQUFhLElBQUksS0FBSyxVQUFVLFlBQVksSUFBSSxLQUFLLFVBQVUsWUFBWSxJQUFJO0FBQUEsSUFDM0YsWUFDRSxVQUFVLGVBQWUsU0FBUyxLQUNsQyxVQUFVLFlBQVksdUJBQXVCLEtBQzdDLFVBQVUsWUFBWSx1QkFBdUI7QUFBQSxJQUMvQyxVQUFVLFdBQVcsY0FBYyxRQUFRLEtBQUssV0FBVyxZQUFZLFFBQVE7QUFBQSxJQUMvRSxrQkFBa0IsV0FBVyxZQUFZLGdCQUFnQjtBQUFBLElBQ3pELGVBQWUsVUFBVSxjQUFjLGFBQWEsS0FBSyxVQUFVLFlBQVksYUFBYTtBQUFBLElBQzVGLGFBQWEsVUFBVSxZQUFZLFdBQVc7QUFBQSxJQUM5QyxVQUFVLFVBQVUsSUFBSSxZQUFZLFFBQVEsR0FBRyxRQUFRLEtBQUssVUFBVSxZQUFZLFFBQVE7QUFBQSxJQUMxRixLQUFLLFVBQVUsWUFBWSxHQUFHO0FBQUEsSUFDOUIsaUJBQWlCLFVBQVUsWUFBWSxlQUFlO0FBQUEsSUFDdEQsZUFBZSxVQUFVLFlBQVksYUFBYTtBQUFBLElBQ2xELGdCQUFnQixVQUFVLFlBQVksY0FBYztBQUFBLElBQ3BELG9CQUNFLGlCQUFpQixVQUFVLGFBQWEsVUFBVSxDQUFDLEtBQ25ELGlCQUFpQixVQUFVLFlBQVksVUFBVSxDQUFDO0FBQUEsSUFDcEQsV0FBVyxXQUFXLFlBQVksU0FBUztBQUFBLEVBQzdDO0FBQ0Y7QUFPQSxTQUFTLFlBQVksR0FBOEM7QUFDakUsUUFBTSxPQUFPLElBQUksRUFBRSxJQUFJO0FBQ3ZCLFFBQU0sYUFBYSxJQUFJLE1BQU0sTUFBTTtBQUNuQyxNQUFJLENBQUMsV0FBWSxRQUFPO0FBQ3hCLFFBQU0sV0FBVyxXQUFXO0FBQzVCLFFBQU0sUUFBaUMsQ0FBQztBQUN4QyxNQUFJLE1BQU0sUUFBUSxRQUFRLEdBQUc7QUFDM0IsZUFBVyxNQUFNLFVBQVU7QUFDekIsVUFBSSxPQUFPLE9BQU8sWUFBWSxPQUFPLEtBQU07QUFDM0MsWUFBTSxJQUFJO0FBQ1YsWUFBTSxJQUFJLFVBQVUsRUFBRSxHQUFHO0FBQ3pCLFlBQU0sSUFBSSxJQUFJLEVBQUUsS0FBSztBQUNyQixVQUFJLENBQUMsS0FBSyxDQUFDLEVBQUc7QUFDZCxZQUFNLENBQUMsSUFDTCxVQUFVLEVBQUUsWUFBWSxLQUN4QixVQUFVLElBQUksRUFBRSxXQUFXLEdBQUcsR0FBRyxLQUNqQyxVQUFVLElBQUksRUFBRSxpQkFBaUIsR0FBRyxPQUFPO0FBQUEsSUFDL0M7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLFVBQVUsV0FBVyxJQUFJO0FBQ3RDLFFBQU0sVUFBVSxVQUFVLFdBQVcsR0FBRztBQUN4QyxRQUFNLFlBQ0osT0FBTyxNQUFNLFlBQVksTUFBTSxXQUFZLE1BQU0sWUFBWSxJQUFlO0FBQzlFLFFBQU0sUUFBUSxPQUFPLE1BQU0sT0FBTyxNQUFNLFdBQVksTUFBTSxPQUFPLElBQWU7QUFDaEYsUUFBTSxjQUNKLE9BQU8sTUFBTSxhQUFhLE1BQU0sV0FBWSxNQUFNLGFBQWEsSUFBZTtBQUNoRixRQUFNLFlBQ0gsT0FBTyxNQUFNLGdDQUFnQyxNQUFNLFdBQy9DLE1BQU0sZ0NBQWdDLElBQ3ZDLFVBQ0gsT0FBTyxNQUFNLDBCQUEwQixNQUFNLFdBQ3pDLE1BQU0sMEJBQTBCLElBQ2pDLFVBQ0gsT0FBTyxNQUFNLDhCQUE4QixNQUFNLFdBQzdDLE1BQU0sOEJBQThCLElBQ3JDO0FBQ04sTUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFNBQVUsUUFBTztBQUN6RCxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0EsVUFBVTtBQUFBLElBQ1YsWUFBWTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsSUFDQSxXQUFXO0FBQUEsRUFDYjtBQUNGOzs7QUM5ekJBLElBQU0sV0FBVztBQUVWLFNBQVMsV0FBbUI7QUFDakMsUUFBTSxLQUFLLEtBQUssSUFBSTtBQUNwQixNQUFJLFNBQVM7QUFDYixNQUFJLElBQUk7QUFDUixXQUFTLElBQUksR0FBRyxJQUFJLElBQUksS0FBSztBQUMzQixjQUFVLFNBQVMsSUFBSSxFQUFFLEtBQUssT0FBTztBQUNyQyxRQUFJLEtBQUssTUFBTSxJQUFJLEVBQUU7QUFBQSxFQUN2QjtBQUNBLFFBQU0sT0FBTyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3RELE1BQUksV0FBVztBQUNmLGFBQVcsS0FBSyxLQUFNLGFBQVksU0FBUyxJQUFJLEVBQUUsS0FBSztBQUN0RCxTQUFPLFNBQVM7QUFDbEI7QUFFTyxTQUFTLFdBQVcsSUFBb0I7QUFDN0MsU0FBTyxHQUFHLE1BQU0sRUFBRTtBQUNwQjs7O0FDUEEsSUFBTSxtQkFBaUQsb0JBQUksSUFBSTtBQUFBLEVBQzdEO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFFTSxTQUFTLGtCQUFrQixNQUErQjtBQUMvRCxRQUFNLFdBQTRCLENBQUM7QUFDbkMsTUFBSSxVQUFrQyxDQUFDO0FBQ3ZDLE1BQUksYUFBYTtBQUNqQixRQUFNLFFBQVEsTUFBTTtBQUNsQixRQUFJLFFBQVEsVUFBVSxRQUFRLE9BQU87QUFDbkMsVUFBSSxDQUFDLFFBQVEsU0FBVSxTQUFRLFdBQVc7QUFDMUMsZUFBUyxLQUFLLE9BQXdCO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBQ0EsYUFBVyxXQUFXLEtBQUssTUFBTSxJQUFJLEdBQUc7QUFDdEMsVUFBTSxPQUFPLGNBQWMsT0FBTztBQUNsQyxRQUFJLEtBQUssS0FBSyxNQUFNLEdBQUk7QUFDeEIsUUFBSSxnQkFBZ0IsS0FBSyxJQUFJLEdBQUc7QUFDOUIsbUJBQWE7QUFDYjtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsV0FBWTtBQUVqQixVQUFNLFlBQVksS0FBSyxNQUFNLDRCQUE0QjtBQUN6RCxRQUFJLFdBQVc7QUFDYixZQUFNO0FBQ04sZ0JBQVUsRUFBRSxRQUFRLFFBQVEsVUFBVSxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2hEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sd0JBQXdCO0FBQ3RELFFBQUksY0FBYyxDQUFDLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFDckMsWUFBTTtBQUNOLGdCQUFVLEVBQUUsUUFBUSxRQUFRLFdBQVcsQ0FBQyxLQUFLLEVBQUUsRUFBRTtBQUNqRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGFBQWEsS0FBSyxNQUFNLHVCQUF1QjtBQUNyRCxRQUFJLGNBQWMsUUFBUSxRQUFRO0FBQ2hDLGNBQVEsUUFBUSxRQUFRLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDM0M7QUFBQSxJQUNGO0FBQ0EsVUFBTSxnQkFBZ0IsS0FBSyxNQUFNLDBCQUEwQjtBQUMzRCxRQUFJLGlCQUFpQixRQUFRLFFBQVE7QUFDbkMsWUFBTSxNQUFNLFFBQVEsY0FBYyxDQUFDLEtBQUssRUFBRTtBQUMxQyxjQUFRLFdBQVcsaUJBQWlCLElBQUksR0FBc0IsSUFDekQsTUFDRDtBQUNKO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNO0FBQ04sU0FBTyxTQUFTLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxTQUFTLENBQUM7QUFDbkQ7QUFFQSxTQUFTLGNBQWMsTUFBc0I7QUFHM0MsUUFBTSxNQUFNLEtBQUssUUFBUSxHQUFHO0FBQzVCLFNBQU8sUUFBUSxLQUFLLE9BQU8sS0FBSyxNQUFNLEdBQUcsR0FBRztBQUM5QztBQUVBLFNBQVMsUUFBUSxHQUFtQjtBQUNsQyxRQUFNLFVBQVUsRUFBRSxLQUFLO0FBQ3ZCLE1BQ0csUUFBUSxXQUFXLEdBQUcsS0FBSyxRQUFRLFNBQVMsR0FBRyxLQUMvQyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEdBQ2hEO0FBQ0EsV0FBTyxRQUFRLE1BQU0sR0FBRyxFQUFFO0FBQUEsRUFDNUI7QUFDQSxTQUFPO0FBQ1Q7OztBQ0NBLElBQU0sY0FBYyxRQUFRLFFBQVEsWUFBWSxFQUFFO0FBQ2xELElBQU0sMkJBQTJCO0FBQ2pDLElBQUksdUJBQXVCO0FBRTNCLGVBQWUsQ0FBQyxPQUFpQjtBQUMvQixVQUFRLFFBQVEsWUFBWSxFQUFFLE1BQU0sYUFBYSxPQUFPLEdBQUcsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUM5RSxDQUFDO0FBRUQsU0FBUywyQkFBaUM7QUFDeEMseUJBQXVCLEtBQUssSUFBSSxJQUFJO0FBQ3RDO0FBSUEsUUFBUSxRQUFRLFlBQVksWUFBWSxZQUFZO0FBQ2xELFFBQU0sS0FBSyx1QkFBdUIsRUFBRSxTQUFTLFlBQVksQ0FBQztBQUMxRCxRQUFNLE9BQU8sU0FBUztBQUN4QixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxNQUFNO0FBQzFDLE9BQUssT0FBTyxTQUFTO0FBQ3ZCLENBQUM7QUFHRCxLQUFLLE9BQU8sYUFBYTtBQUV6QixlQUFlLE9BQU8sUUFBK0I7QUFDbkQsTUFBSTtBQUNGLFVBQU0sYUFBYTtBQUNuQixVQUFNLHNCQUFzQjtBQUM1QixVQUFNLDRCQUE0QjtBQUNsQyxVQUFNLHFCQUFxQjtBQUczQixVQUFNLFNBQVMsTUFBTSxvQkFBb0IsS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFJO0FBQ2pFLFFBQUksU0FBUyxFQUFHLE9BQU0sS0FBSywwQkFBMEIsRUFBRSxPQUFPLENBQUM7QUFDL0QsVUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFJLFNBQVMsT0FBTyxTQUFTLFNBQVMsU0FBUyxNQUFNO0FBQ25ELFlBQU0saUJBQWlCLEtBQUs7QUFDNUIsWUFBTSxvQkFBb0IsS0FBSztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTztBQUFBLFFBQ1AsZUFBZTtBQUFBLFFBQ2Ysd0JBQXdCO0FBQUEsUUFDeEIsa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUNELFlBQU0sS0FBSyx3Q0FBd0MsRUFBRSxPQUFPLENBQUM7QUFBQSxJQUMvRDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFPLGVBQWUsRUFBRSxRQUFRLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQy9EO0FBQ0Y7QUFZQSxlQUFlLHVCQUFzQztBQUNuRCxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUFBLEVBQ3ZGLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyw2QkFBNkIsY0FBYyxHQUFHLENBQUM7QUFDMUQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVU7QUFDaEMsUUFBSTtBQUNGLFlBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPLENBQUMsY0FBYztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXRCLE9BQU87QUFBQSxNQUNULENBQUM7QUFDRCxZQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTyxDQUFDLFlBQVk7QUFBQSxNQUN0QixDQUFDO0FBQ0QsWUFBTSxLQUFLLHFDQUFxQztBQUFBLFFBQzlDLE9BQU8sSUFBSTtBQUFBLFFBQ1gsS0FBSyxXQUFXLElBQUksT0FBTyxFQUFFO0FBQUEsTUFDL0IsQ0FBQztBQUFBLElBQ0gsU0FBUyxLQUFLO0FBSVosWUFBTSxLQUFLLHdDQUF3QztBQUFBLFFBQ2pELE9BQU8sSUFBSTtBQUFBLFFBQ1gsS0FBSyxXQUFXLElBQUksT0FBTyxFQUFFO0FBQUEsUUFDN0IsR0FBRyxjQUFjLEdBQUc7QUFBQSxNQUN0QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWUsZUFBOEI7QUFDM0MsUUFBTSxRQUFRLE9BQU8sTUFBTSxhQUFhO0FBQ3hDLFFBQU0sUUFBUSxPQUFPLE1BQU0sbUJBQW1CO0FBQzlDLFFBQU0sUUFBUSxPQUFPLE9BQU8sZUFBZSxFQUFFLGlCQUFpQixvQkFBb0IsQ0FBQztBQUNuRixRQUFNLFFBQVEsT0FBTyxPQUFPLHFCQUFxQjtBQUFBLElBQy9DLGlCQUFpQixnQ0FBZ0M7QUFBQSxFQUNuRCxDQUFDO0FBQ0g7QUFNQSxJQUFJLGtCQUF5RDtBQUs3RCxJQUFNLGlCQUFpQjtBQUV2QixlQUFlLHdCQUF1QztBQUVwRCxRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixNQUFJLFNBQVMsUUFBUSxFQUFFLFlBQVksT0FBTztBQUN4Qyx1QkFBbUIsRUFBRSxxQkFBcUI7QUFBQSxFQUM1QyxPQUFPO0FBQ0wseUJBQXFCO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsdUJBQTZCO0FBQ3BDLE1BQUksb0JBQW9CLE1BQU07QUFDNUIsa0JBQWMsZUFBZTtBQUM3QixzQkFBa0I7QUFBQSxFQUNwQjtBQUNGO0FBRUEsU0FBUyxtQkFBbUIsYUFBMkI7QUFDckQsdUJBQXFCO0FBQ3JCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLFdBQVcsQ0FBQztBQUFBLEVBQ3ZEO0FBQ0Esb0JBQWtCLFlBQVksTUFBTTtBQUNsQyxTQUFLLGVBQWUsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNuQyxXQUFLLEtBQUssMkJBQTJCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDekQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxlQUFlLHNCQUFxQztBQUNsRCwyQkFBeUI7QUFDekIsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLHFCQUFxQjtBQUFBLElBQ3pCLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxhQUFhO0FBQUEsSUFDYixlQUFlO0FBQUEsSUFDZixrQkFBa0I7QUFBQSxJQUNsQix1QkFBdUI7QUFBQSxJQUN2QixpQkFBaUI7QUFBQSxJQUNqQixlQUFlO0FBQUEsRUFDakIsQ0FBQztBQUNELHFCQUFtQixFQUFFLHFCQUFxQjtBQUMxQyxRQUFNLEtBQUssNEJBQTRCLEVBQUUsY0FBYyxFQUFFLHNCQUFzQixDQUFDO0FBRWhGLE9BQUssZUFBZTtBQUNwQixRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLHVCQUFzQztBQUNuRCx1QkFBcUI7QUFDckIsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxLQUFLLDhCQUE4QjtBQUFBLElBQ3ZDLFNBQVMsTUFBTSxlQUFlO0FBQUEsSUFDOUIsVUFBVSxNQUFNLGlCQUFpQjtBQUFBLElBQ2pDLFVBQVUsTUFBTSxpQkFBaUI7QUFBQSxFQUNuQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxpQkFBZ0M7QUFDN0MsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFBQSxFQUN2RixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaUNBQWlDLGNBQWMsR0FBRyxDQUFDO0FBQzlEO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksZ0JBQWdCO0FBQ3BCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJLElBQUksVUFBVztBQUNuQixRQUFJO0FBQ0YsWUFBTSxVQUFXLE1BQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNyRCxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJUCxNQUFPLE1BQU07QUFLWCxnQkFBTSxzQkFBc0I7QUFBQSxZQUMxQjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUNBLGdCQUFNLFVBQVUsb0JBQUksSUFBYTtBQUNqQyxjQUFJLFdBQVc7QUFDZixxQkFBVyxPQUFPLHFCQUFxQjtBQUNyQyx1QkFBVyxNQUFNLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixHQUFHLENBQUMsR0FBRztBQUMzRCxrQkFBSSxRQUFRLElBQUksRUFBRSxFQUFHO0FBRXJCLG9CQUFNLEtBQUssR0FBRyxlQUFlLElBQUksS0FBSyxFQUFFLFlBQVk7QUFDcEQsa0JBQUksTUFBTSxlQUFlLE1BQU0sbUJBQW9CO0FBQ25ELG9CQUFNLE9BQU8sR0FBRyxzQkFBc0I7QUFDdEMsa0JBQUksS0FBSyxVQUFVLEtBQUssS0FBSyxXQUFXLEVBQUc7QUFDM0Msc0JBQVEsSUFBSSxFQUFFO0FBQ2Qsa0JBQUk7QUFDRixnQkFBQyxHQUFtQixNQUFNO0FBQzFCLDRCQUFZO0FBQUEsY0FDZCxRQUFRO0FBQUEsY0FFUjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBSUEsZ0JBQU0sT0FBMEI7QUFBQSxZQUM5QixLQUFLO0FBQUEsWUFDTCxNQUFNO0FBQUEsWUFDTixTQUFTO0FBQUEsWUFDVCxPQUFPO0FBQUEsWUFDUCxTQUFTO0FBQUEsWUFDVCxZQUFZO0FBQUEsVUFDZDtBQUNBLGdCQUFNLFFBQVMsU0FBUyxpQkFBd0MsU0FBUztBQUN6RSxnQkFBTSxjQUFjLElBQUksY0FBYyxXQUFXLElBQUksQ0FBQztBQUN0RCxnQkFBTSxjQUFjLElBQUksY0FBYyxTQUFTLElBQUksQ0FBQztBQUNwRCxpQkFBTyxTQUFTO0FBQUEsWUFDZCxLQUFLLFNBQVMsZ0JBQWdCO0FBQUEsWUFDOUIsVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUNELGlCQUFPLEVBQUUsU0FBUztBQUFBLFFBQ3BCO0FBQUEsTUFDRixDQUFDO0FBQ0QscUJBQWU7QUFDZixZQUFNLElBQUksUUFBUSxDQUFDLEdBQUc7QUFDdEIsVUFBSSxLQUFLLE9BQU8sRUFBRSxhQUFhLFNBQVUsa0JBQWlCLEVBQUU7QUFBQSxJQUM5RCxRQUFRO0FBQUEsSUFHUjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGNBQWMsR0FBRztBQUNuQixVQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBSSxTQUFTLE1BQU07QUFDakIsV0FBSyxlQUFlO0FBQ3BCLFdBQUssaUJBQWlCO0FBQ3RCLFlBQU0scUJBQXFCLElBQUk7QUFBQSxJQUVqQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLFFBQVEsT0FBTyxRQUFRLFlBQVksQ0FBQyxVQUFVO0FBQzVDLE1BQUksTUFBTSxTQUFTLGVBQWU7QUFDaEMsU0FBSyxpQkFBaUI7QUFBQSxFQUN4QixXQUFXLE1BQU0sU0FBUyxxQkFBcUI7QUFDN0MsU0FBSyxpQkFBaUIsS0FBSztBQUFBLEVBQzdCO0FBSUYsQ0FBQztBQUlELElBQUksUUFBUSxRQUFRLFdBQVc7QUFDN0IsVUFBUSxPQUFPLFVBQVUsWUFBWSxZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNLFFBQVEsY0FBYyxPQUFPO0FBQUEsSUFDckMsU0FBUyxLQUFLO0FBRVosWUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUN2RSxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFBQSxJQUN4QztBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBSUEsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLEtBQWMsWUFBWTtBQUMvRCxNQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRyxRQUFPO0FBQ25DLFNBQU8sY0FBYyxHQUFHLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDdkMsU0FBSyxNQUFPLDBCQUEwQixFQUFFLE1BQU0sSUFBSSxNQUFNLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUMvRSxVQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0gsQ0FBQztBQUVELFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELFNBQU8sQ0FBQyxDQUFDLEtBQUssT0FBTyxNQUFNLFlBQVksT0FBUSxFQUF5QixTQUFTO0FBQ25GO0FBSUEsSUFBTSw0QkFBNEIsb0JBQUksSUFBNEI7QUFBQSxFQUNoRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVELGVBQWUsWUFBOEI7QUFDM0MsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixTQUFPLEVBQUUsWUFBWTtBQUN2QjtBQUVBLGVBQWUsY0FBYyxLQUF1QztBQUtsRSxNQUFJLENBQUUsTUFBTSxVQUFVLEtBQU0sMEJBQTBCLElBQUksSUFBSSxJQUFJLEdBQUc7QUFDbkUsV0FBTyxFQUFFLElBQUksTUFBTSxRQUFRLEtBQUs7QUFBQSxFQUNsQztBQUNBLFVBQVEsSUFBSSxNQUFNO0FBQUEsSUFDaEIsS0FBSztBQUNILFlBQU0saUJBQWlCLElBQUksVUFBVSxJQUFJLEtBQUssSUFBSSxXQUFXLE1BQU0sSUFBSSxRQUFRO0FBQy9FLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxLQUFLLGdDQUFnQyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ3ZFLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxLQUFLLCtCQUErQixFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ3RFLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsVUFBSSxJQUFJLFVBQVUsUUFBUTtBQUN4QixjQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNsRCxXQUFXLElBQUksVUFBVSxTQUFTO0FBQ2hDLGNBQU0sTUFBTyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ3BELE9BQU87QUFDTCxjQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNsRDtBQUNBLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVyxJQUFJLE1BQU07QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVztBQUNqQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxnQkFBZ0I7QUFDdEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sU0FBUyxNQUFNO0FBQ3JCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFlBQVksSUFBSSxRQUFRLE1BQU07QUFDcEMsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLGFBQWEsSUFBSSxHQUFHLENBQUM7QUFDNUMsWUFBTSxLQUFLLHdCQUF3QixFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDakQsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLGdCQUFnQixJQUFJLEdBQUcsQ0FBQztBQUMvQyxZQUFNLEtBQUssMkJBQTJCLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUNwRCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLGtCQUFrQjtBQUNyQixZQUFNLElBQUksTUFBTSxlQUFlLEVBQUUsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNsRCxVQUFJLENBQUMsSUFBSSxJQUFJO0FBR1gsNkJBQXFCO0FBQ3JCLDRCQUFvQjtBQUNwQiwrQkFBdUI7QUFDdkIsY0FBTSxRQUFRLE9BQU8sTUFBTSxjQUFjO0FBQ3pDLGNBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQUEsTUFDL0MsT0FBTztBQUVMLGNBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxZQUFJLFNBQVMsS0FBTSxvQkFBbUIsRUFBRSxxQkFBcUI7QUFBQSxNQUMvRDtBQUNBLFlBQU0sS0FBSyxtQ0FBbUMsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQzVELGFBQU8sV0FBVztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssNEJBQTRCO0FBQy9CLFlBQU0sVUFBVSxLQUFLO0FBQUEsUUFDbkI7QUFBQSxRQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLElBQUksT0FBTyxDQUFDO0FBQUEsTUFDdkQ7QUFDQSxZQUFNLGVBQWUsRUFBRSx1QkFBdUIsUUFBUSxDQUFDO0FBRXZELFlBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxVQUFJLFNBQVMsS0FBTSxvQkFBbUIsT0FBTztBQUM3QyxVQUFJLDBCQUEwQixLQUFNLHNCQUFxQixPQUFPO0FBQ2hFLFVBQUksNkJBQTZCLEtBQU0seUJBQXdCLE9BQU87QUFDdEUsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLGlCQUFpQjtBQUN2QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxrQkFBa0I7QUFDeEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sb0JBQW9CO0FBQzFCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLHFCQUFxQjtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLG1CQUFtQjtBQUN0QixZQUFNLE9BQU8sTUFBTSxZQUFZO0FBQy9CLFlBQU0sVUFBVSxJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDL0QsWUFBTSxVQUFVLE1BQU0sb0JBQW9CLE9BQU87QUFDakQsWUFBTSxLQUFLLDBCQUEwQixPQUFPO0FBQzVDLGFBQU8sV0FBVztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsWUFBTSxvQkFBb0IsSUFBSTtBQUM5QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxpQkFBaUIsSUFBSTtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxjQUFjO0FBQ3BCLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxRQUFRLFFBQVEsZ0JBQWdCO0FBQ3RDLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLLGVBQWU7QUFDbEIsWUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixZQUFNLE1BQU0sVUFBVSxDQUFDO0FBQ3ZCLFlBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFDakMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCO0FBQUEsSUFDQTtBQUNFLGFBQU8sRUFBRSxJQUFJLE9BQU8sT0FBTyx1QkFBdUI7QUFBQSxFQUN0RDtBQUNGO0FBSUEsZUFBZSxpQkFDYixVQUNBLEtBQ0EsU0FDQSxVQUNlO0FBQ2YsTUFBSSxrQkFBa0IsSUFBSSxRQUFRLEVBQUc7QUFDckMsTUFBSSxDQUFDLGdCQUFnQixJQUFJLFFBQVEsRUFBRztBQUVwQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksU0FBUyxZQUFZLE1BQU87QUFDaEMsTUFBSSxTQUFTLGdCQUFnQixPQUFPO0FBQ2xDLFVBQU0sd0JBQ0osS0FBSyxJQUFJLElBQUksd0JBQ1osTUFBTSxxQkFBcUIsTUFBTyxRQUNsQyxNQUFNLGtCQUFrQixNQUFPLFFBQy9CLE1BQU0scUJBQXFCLE1BQU87QUFDckMsUUFBSSxDQUFDLHNCQUF1QjtBQUFBLEVBQzlCO0FBRUEsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQWdCbkMsUUFBTSxVQUFVLElBQUksSUFBSSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUNuRSxRQUFNLE9BQU8sSUFBSTtBQUFBLElBQ2YsU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLGFBQWEsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUM7QUFBQSxFQUNqRjtBQUNBLFFBQU0sY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUUxQyxNQUFJO0FBQ0osTUFBSTtBQUNGLGlCQUFhLFVBQVUsVUFBVTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsZ0JBQWdCLG9CQUFJLElBQVk7QUFBQSxNQUNoQyxXQUFXO0FBQUEsSUFDYixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLFdBQVcsbUJBQW1CLFVBQVUsS0FBSyxVQUFVLEdBQUc7QUFDaEU7QUFBQSxFQUNGO0FBUUEsUUFBTSxlQUFlLFdBQVcsT0FBTztBQUN2QyxhQUFXLFNBQVMsY0FBYyxXQUFXLFFBQVEsU0FBUyxJQUFJO0FBQ2xFLFFBQU0sbUJBQW1CLGVBQWUsV0FBVyxPQUFPO0FBQzFELE1BQUksbUJBQW1CLEdBQUc7QUFDeEIsVUFBTSxLQUFLLDRCQUE0QjtBQUFBLE1BQ3JDO0FBQUEsTUFDQSxTQUFTO0FBQUEsTUFDVCxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBT0EsTUFBSSxXQUFXLGFBQWEsV0FBVyxHQUFHO0FBQ3hDLFVBQU0sS0FBSyw0Q0FBdUM7QUFBQSxNQUNoRDtBQUFBLE1BQ0EsV0FBVyxlQUFlLFFBQVEsRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLE1BQy9DLFlBQVksb0JBQW9CLFVBQVUsT0FBTztBQUFBLE1BQ2pELGlCQUFpQixpQkFBaUIsVUFBVSxTQUFTLENBQUMsTUFBTSxDQUFDO0FBQUEsTUFDN0QsbUJBQW1CLGlCQUFpQixVQUFVLFNBQVMsQ0FBQyxRQUFRLENBQUM7QUFBQSxNQUNqRSwwQkFBMEIsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQzVEO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxNQUNELCtCQUErQixpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDakU7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxNQUNELGlDQUFpQyxpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDbkU7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNILE9BQU87QUFDTCxVQUFNLEtBQUssd0JBQXdCO0FBQUEsTUFDakM7QUFBQSxNQUNBLFVBQVUsV0FBVyxhQUFhO0FBQUEsTUFDbEMsTUFBTSxXQUFXLE9BQU87QUFBQSxJQUMxQixDQUFDO0FBQUEsRUFDSDtBQUVBLE1BQUksV0FBVyxtQkFBbUIsU0FBUyxHQUFHO0FBQzVDLFVBQU07QUFBQSxNQUNKLFdBQVc7QUFBQSxNQUNYO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxNQUFJLFdBQVcsT0FBTyxXQUFXLEVBQUc7QUFXcEMsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELGFBQVcsS0FBSyxXQUFXLFFBQVE7QUFDakMsUUFBSSxFQUFFLGNBQWM7QUFDbEIsWUFBTSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUTtBQUFBLElBQ25ELE9BQU87QUFDTCxZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRO0FBQUEsSUFDbkQ7QUFHQSxVQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsUUFBSSxhQUFhLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDakQsa0JBQVksV0FBVztBQUN2QixrQkFBWSxhQUFhO0FBQ3pCLFlBQU0sa0JBQWtCLFdBQVc7QUFBQSxJQUNyQztBQUNBLFFBQUksZ0JBQWdCLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDcEQscUJBQWUsV0FBVztBQUMxQixxQkFBZSxhQUFhO0FBQzVCLFlBQU0scUJBQXFCLGNBQWM7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFLQSxhQUFXLFdBQVcsV0FBVyxhQUFhO0FBQzVDLFFBQUksTUFBTSxZQUFZLFFBQVEsUUFBUSxFQUFHO0FBQ3pDLFVBQU0sa0JBQWtCLFFBQVEsYUFBYSxRQUFRLFFBQVE7QUFBQSxFQUMvRDtBQUNBLE1BQUksV0FBVyxZQUFZLFNBQVMsR0FBRztBQUNyQyxVQUFNLEtBQUssMENBQTBDO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLFNBQVMsV0FBVyxZQUFZO0FBQUEsTUFDaEMsYUFBYSxNQUFNLHFCQUFxQjtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNIO0FBZUEsUUFBTSxpQkFBaUIsU0FBUyxtQkFBbUI7QUFDbkQsUUFBTSxlQUFlLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sa0JBQWtCLE1BQU0sbUJBQW1CO0FBQ2pELE1BQUksaUJBQWlCO0FBQ3JCLE1BQUksdUJBQXVCO0FBQzNCLE1BQUksMEJBQTBCO0FBQzlCLE1BQUksa0JBQWtCO0FBQ3RCLFFBQU0sYUFBdUMsQ0FBQztBQUM5QyxRQUFNLGdCQUFnQixvQkFBSSxJQUFnQztBQUMxRCxRQUFNLGFBQWEsb0JBQUksSUFBcUM7QUFDNUQsYUFBVyxLQUFLLFdBQVcsUUFBUTtBQUNqQyxVQUFNLE9BQU8sYUFBYSxFQUFFLGNBQWMsSUFBSSxFQUFFLFFBQVE7QUFDeEQsVUFBTSxnQkFBZ0IsQ0FBQyxRQUFRLHdCQUF3QixHQUFHLGVBQWU7QUFDekUsVUFBTSxxQkFBcUIsUUFBUSxJQUFJLEtBQUs7QUFDNUMsa0JBQWMsSUFBSSxFQUFFLFVBQVUscUJBQXFCLGFBQWEsS0FBSztBQUNyRSxRQUFJLGNBQWUsb0JBQW1CO0FBQ3RDLFFBQUksc0JBQXNCLENBQUMsZ0JBQWdCO0FBQ3pDLFVBQUksS0FBTSx5QkFBd0I7QUFBQSxVQUM3Qiw0QkFBMkI7QUFDaEMsaUJBQVcsSUFBSSxFQUFFLFVBQVUsU0FBUztBQUNwQztBQUFBLElBQ0Y7QUFDQSxVQUFNLE1BQU07QUFBQSxNQUNWLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxJQUNKO0FBQ0EsUUFBSSxRQUFRLEtBQUssUUFBUSxLQUFLO0FBQzVCLHdCQUFrQjtBQUNsQixpQkFBVyxJQUFJLEVBQUUsVUFBVSxXQUFXO0FBQ3RDO0FBQUEsSUFDRjtBQUNBLGVBQVcsSUFBSSxFQUFFLFVBQVUsVUFBVTtBQUNyQyxlQUFXLEtBQUssQ0FBQztBQUFBLEVBQ25CO0FBQ0EsTUFBSSxpQkFBaUIsR0FBRztBQUN0QixVQUFNLEtBQUssbUNBQW1DO0FBQUEsTUFDNUM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSx1QkFBdUIsMEJBQTBCLEdBQUc7QUFDdEQsVUFBTSxhQUFhLHVCQUF1QjtBQUMxQyxVQUFNLEtBQUssb0VBQW9FO0FBQUEsTUFDN0U7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULGFBQWE7QUFBQSxNQUNiLGtCQUFrQjtBQUFBLE1BQ2xCLFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFDRCxVQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsUUFBSSxXQUFXLE1BQU07QUFDbkIsYUFBTyxtQkFBbUIsT0FBTyxtQkFBbUIsS0FBSztBQUN6RCxZQUFNLHFCQUFxQixNQUFNO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBQ0EsTUFBSSxrQkFBa0IsS0FBSyxnQkFBZ0I7QUFDekMsVUFBTSxLQUFLLDBDQUEwQztBQUFBLE1BQ25EO0FBQUEsTUFDQSxLQUFLO0FBQUEsTUFDTCxRQUFRO0FBQUEsTUFDUix1QkFBdUIsaUJBQWlCLGdCQUFnQjtBQUFBLElBQzFELENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTTtBQUFBLElBQ0osV0FBVyxPQUFPO0FBQUEsTUFBSSxDQUFDLE1BQ3JCLG1CQUFtQixHQUFHLFVBQVUsWUFBWSxjQUFjLElBQUksRUFBRSxRQUFRLEdBQUcsV0FBVyxJQUFJLEVBQUUsUUFBUSxDQUFDO0FBQUEsSUFDdkc7QUFBQSxFQUNGO0FBU0EsUUFBTSxzQkFBc0IsV0FBVyxRQUFRLFFBQVE7QUFDdkQsTUFBSSxXQUFXLFdBQVcsRUFBRztBQUc3QixRQUFNLFdBQVcsb0JBQUksSUFBOEI7QUFDbkQsYUFBVyxLQUFLLFlBQVk7QUFDMUIsVUFBTSxNQUFNLFNBQVMsSUFBSSxFQUFFLGNBQWMsS0FBSyxDQUFDO0FBQy9DLFFBQUksS0FBSyxDQUFDO0FBQ1YsYUFBUyxJQUFJLEVBQUUsZ0JBQWdCLEdBQUc7QUFBQSxFQUNwQztBQUVBLGFBQVcsQ0FBQyxRQUFRLE1BQU0sS0FBSyxVQUFVO0FBQ3ZDLFVBQU0sTUFBTSxNQUFNLGdCQUFnQixRQUFRLFlBQVksS0FBSyxRQUFRO0FBQ25FLFFBQUksUUFBUTtBQUNaLFFBQUksV0FBVztBQUNmLFFBQUksZ0JBQWdCO0FBQ3BCLFFBQUksa0JBQWtCO0FBQ3RCLGVBQVcsS0FBSyxRQUFRO0FBQ3RCLFlBQU0sV0FBVyxJQUFJLGFBQWEsRUFBRSxRQUFRO0FBQzVDLFVBQUksVUFBVTtBQUdaLGlCQUFTLGVBQWU7QUFDeEIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGdCQUFnQixFQUFFO0FBQzNCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxjQUFjLEVBQUU7QUFDekIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGlCQUFpQixFQUFFO0FBQzVCLGNBQU0sT0FBTyxTQUFTLG1CQUFtQixTQUFTLG1CQUFtQixTQUFTLENBQUM7QUFDL0UsY0FBTSxPQUFPLEVBQUUsbUJBQW1CLENBQUM7QUFDbkMsWUFBSSxTQUFTLENBQUMsUUFBUSxLQUFLLGdCQUFnQixLQUFLLGNBQWM7QUFDNUQsbUJBQVMsbUJBQW1CLEtBQUssSUFBSTtBQUFBLFFBQ3ZDO0FBQ0EsMkJBQW1CO0FBQUEsTUFDckIsT0FBTztBQUNMLGNBQU0sVUFBMEIsRUFBRSxHQUFHLEdBQUcsZ0JBQWdCLElBQUksT0FBTztBQUNuRSxZQUFJLGFBQWEsRUFBRSxRQUFRLElBQUk7QUFDL0IsaUJBQVM7QUFDVCxZQUFJLGNBQWMsSUFBSSxFQUFFLFFBQVEsTUFBTSxXQUFZLGtCQUFpQjtBQUFBLFlBQzlELGFBQVk7QUFBQSxNQUNuQjtBQUNBLFVBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQ2hELFlBQUksbUJBQW1CLEtBQUssRUFBRSxRQUFRO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTTtBQUFBLE1BQ0o7QUFBQSxNQUNBLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRSxTQUFTLE9BQU8sS0FBSyxJQUFJLHFCQUFxQixDQUFDLENBQUMsRUFBRTtBQUFBLElBQ2xGO0FBQ0EsUUFBSSxRQUFRLEtBQUssa0JBQWtCLEdBQUc7QUFDcEMsWUFBTSxLQUFLLG1CQUFtQjtBQUFBLFFBQzVCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMLFVBQVU7QUFBQSxRQUNWLGtCQUFrQjtBQUFBLFFBQ2xCLE9BQU8sT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFO0FBQUEsTUFDdkMsQ0FBQztBQUdELFlBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxVQUFJLFdBQVcsTUFBTTtBQUNuQixlQUFPLGlCQUFpQjtBQUN4QixlQUFPLG9CQUFvQixPQUFPLG9CQUFvQixLQUFLO0FBQzNELGVBQU8seUJBQ0osT0FBTyx5QkFBeUIsS0FBSztBQUN4QyxjQUFNLHFCQUFxQixNQUFNO0FBQUEsTUFDbkM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsVUFBVSx1QkFBdUI7QUFDakUsWUFBTSxZQUFZLFFBQVEsV0FBVztBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsd0JBQ2IsbUJBQ0EsU0FDQSxZQUNBLFdBQ0EsVUFDZTtBQUNmLFFBQU0sZUFBZSxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsTUFBSSxXQUFXO0FBQ2YsTUFBSSxVQUFVO0FBQ2QsTUFBSSxnQkFBZ0I7QUFFcEIsYUFBVyxLQUFLLG1CQUFtQjtBQUNqQyxVQUFNLFNBQVMsRUFBRTtBQUNqQixRQUFJLENBQUMsUUFBUTtBQUNYLHVCQUFpQjtBQUNqQixZQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxRQUFRLE9BQU8sS0FBSyxDQUFDLFFBQVEsSUFBSSxPQUFPLFlBQVksQ0FBQyxHQUFHO0FBQzFELGlCQUFXO0FBQ1g7QUFBQSxJQUNGO0FBRUEsVUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFVBQU0sZUFBZSxRQUFRLEVBQUUsUUFBUTtBQUN2QyxRQUFJLGFBQWEsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNqRCxrQkFBWSxXQUFXO0FBQ3ZCLGtCQUFZLGFBQWE7QUFDekIsWUFBTSxrQkFBa0IsV0FBVztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBRUEsVUFBTSxNQUFNLGVBQWUsQ0FBQztBQUM1QixVQUFNLE9BQU8sYUFBYSxNQUFNLElBQUksRUFBRSxRQUFRO0FBQzlDLFFBQUksTUFBTSxRQUFRLEtBQUs7QUFDckIsaUJBQVc7QUFDWDtBQUFBLElBQ0Y7QUFFQSxVQUFNLE1BQU0sTUFBTSxnQkFBZ0IsUUFBUSxZQUFZLFdBQVcsUUFBUTtBQUN6RSxVQUFNLGtCQUFrQixJQUFJLHFCQUFxQixDQUFDO0FBQ2xELG9CQUFnQixFQUFFLFFBQVEsSUFBSTtBQUM5QixRQUFJLG9CQUFvQjtBQUN4QixRQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsR0FBRztBQUNoRCxVQUFJLG1CQUFtQixLQUFLLEVBQUUsUUFBUTtBQUFBLElBQ3hDO0FBQ0EsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTTtBQUFBLE1BQ0o7QUFBQSxNQUNBLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRSxTQUFTLE9BQU8sS0FBSyxlQUFlLEVBQUU7QUFBQSxJQUN0RTtBQUNBLGdCQUFZO0FBQUEsRUFDZDtBQUVBLE1BQUksV0FBVyxLQUFLLGdCQUFnQixLQUFLLFVBQVUsR0FBRztBQUNwRCxVQUFNLEtBQUssK0JBQStCLEVBQUUsVUFBVSxVQUFVLFNBQVMsY0FBYyxDQUFDO0FBQUEsRUFDMUY7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxTQUFTLGVBQWUsR0FBNkI7QUFDbkQsU0FBTyxlQUFlLEVBQUUsc0JBQXNCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO0FBQzlFO0FBc0JBLGVBQWUsc0JBQ2IsUUFDQSxVQUNlO0FBQ2YsTUFBSSxPQUFPLFdBQVcsRUFBRztBQUd6QixRQUFNLGVBQWUsb0JBQUksSUFBWTtBQUNyQyxhQUFXLEtBQUssT0FBUSxjQUFhLElBQUksRUFBRSxRQUFRO0FBRW5ELE1BQUksV0FBVztBQUNmLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFVBQU0sVUFBc0QsQ0FBQztBQUM3RCxRQUFJLEVBQUUsbUJBQW1CO0FBQ3ZCLGNBQVEsS0FBSyxFQUFFLElBQUksRUFBRSxtQkFBbUIsTUFBTSxFQUFFLGlCQUFpQixDQUFDO0FBQUEsSUFDcEU7QUFDQSxRQUFJLEVBQUUsZ0JBQWlCLFNBQVEsS0FBSyxFQUFFLElBQUksRUFBRSxpQkFBaUIsTUFBTSxLQUFLLENBQUM7QUFDekUsUUFBSSxFQUFFLG1CQUFvQixTQUFRLEtBQUssRUFBRSxJQUFJLEVBQUUsb0JBQW9CLE1BQU0sS0FBSyxDQUFDO0FBQy9FLGVBQVcsS0FBSyxTQUFTO0FBQ3ZCLFVBQUksYUFBYSxJQUFJLEVBQUUsRUFBRSxFQUFHO0FBQzVCLFVBQUksTUFBTSxZQUFZLEVBQUUsRUFBRSxFQUFHO0FBQzdCLFlBQU0sa0JBQWtCLEVBQUUsTUFBTSxFQUFFLEVBQUU7QUFDcEMsa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRjtBQUNBLE1BQUksV0FBVyxHQUFHO0FBQ2hCLFVBQU0sS0FBSyxzREFBc0Q7QUFBQSxNQUMvRDtBQUFBLE1BQ0E7QUFBQSxNQUNBLGFBQWEsTUFBTSxxQkFBcUI7QUFBQSxJQUMxQyxDQUFDO0FBQUEsRUFDSDtBQUNGO0FBRUEsZUFBZSxnQkFDYixRQUNBLElBQ0EsV0FDQSxVQUNvQjtBQUNwQixRQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFDckMsTUFBSSxJQUFLLFFBQU87QUFDaEIsUUFBTSxNQUFpQjtBQUFBLElBQ3JCLFFBQVEsU0FBUztBQUFBLElBQ2pCLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLGlCQUFpQjtBQUFBLElBQ2pCLGNBQWMsQ0FBQztBQUFBLElBQ2YsbUJBQW1CLENBQUM7QUFBQSxJQUNwQixvQkFBb0IsQ0FBQztBQUFBLElBQ3JCLGdCQUFnQixDQUFDLFFBQVE7QUFBQSxJQUN6QixZQUFZO0FBQUEsRUFDZDtBQUNBLFFBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsUUFBTSxLQUFLLGVBQWUsRUFBRSxRQUFRLEtBQUssV0FBVyxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQ2pFLFNBQU87QUFDVDtBQUlBLElBQUksYUFBNEIsUUFBUSxRQUFRO0FBZWhELGVBQWUsbUJBQWtDO0FBQy9DLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxNQUFNLEtBQUssSUFBSTtBQUNyQixRQUFNLFVBQW9CLENBQUM7QUFDM0IsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELGNBQVEsS0FBSyxNQUFNO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxhQUFhLFNBQVMsTUFBTTtBQUNwQztBQUVBLGVBQWUsOEJBQTZDO0FBTzFELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsUUFBTSxVQUFvQixDQUFDO0FBQzNCLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFVBQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxlQUFlO0FBQzNDLFFBQUksT0FBTyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsZUFBZTtBQUN4RCxjQUFRLEtBQUssTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sYUFBYSxTQUFTLE1BQU07QUFDcEM7QUFFQSxlQUFlLFNBQVMsUUFBK0I7QUFDckQsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLGFBQWEsT0FBTyxLQUFLLEdBQUcsR0FBRyxNQUFNO0FBQzdDO0FBRUEsZUFBZSxZQUFZLFFBQWdCLFFBQStCO0FBQ3hFLFFBQU0sYUFBYSxDQUFDLE1BQU0sR0FBRyxNQUFNO0FBQ3JDO0FBRUEsZUFBZSxhQUFhLFNBQW1CLFFBQStCO0FBQzVFLFFBQU0sU0FBUyxDQUFDLEdBQUcsSUFBSSxJQUFJLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDO0FBQy9ELE1BQUksT0FBTyxXQUFXLEVBQUc7QUFDekIsUUFBTSxNQUFNLFdBQVcsS0FBSyxNQUFNLG1CQUFtQixRQUFRLE1BQU0sQ0FBQztBQUNwRSxlQUFhLElBQUksTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQy9CLFNBQU87QUFDVDtBQUVBLGVBQWUsbUJBQW1CLFNBQW1CLFFBQStCO0FBQ2xGLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxRQUFxQixDQUFDO0FBQzVCLGFBQVcsVUFBVSxTQUFTO0FBQzVCLFVBQU0sTUFBTSxJQUFJLE1BQU07QUFDdEIsUUFBSSxDQUFDLElBQUs7QUFDVixVQUFNLFNBQVMsT0FBTyxPQUFPLElBQUksWUFBWTtBQUM3QyxVQUFNLG9CQUFvQixPQUFPLE9BQU8sSUFBSSxxQkFBcUIsQ0FBQyxDQUFDO0FBQ25FLFFBQUksT0FBTyxXQUFXLEtBQUssa0JBQWtCLFdBQVcsR0FBRztBQUN6RCxZQUFNLGVBQWUsTUFBTTtBQUMzQixZQUFNLGlCQUFpQixRQUFRLENBQUM7QUFDaEM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLGVBQWUsUUFBUSxLQUFLLFFBQVEsaUJBQWlCLENBQUM7QUFBQSxFQUNuRTtBQUNBLE1BQUksTUFBTSxXQUFXLEVBQUc7QUFFeEIsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sS0FBSyx1Q0FBdUM7QUFBQSxNQUNoRCxPQUFPLE1BQU07QUFBQSxNQUNiLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLElBQ3ZELENBQUM7QUFDRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsUUFBTSxRQUFRLE1BQU0sUUFBUSxDQUFDLFNBQVM7QUFBQSxJQUNwQztBQUFBLE1BQ0UsTUFBTSxLQUFLO0FBQUEsTUFDWCxlQUFlQyxVQUFTLEtBQUssVUFBVSxLQUFLLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLElBQ3RFO0FBQUEsSUFDQTtBQUFBLE1BQ0UsTUFBTSxLQUFLO0FBQUEsTUFDWCxlQUFlQSxVQUFTLEtBQUssVUFBVSxLQUFLLE1BQU0sTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLElBQ25FO0FBQUEsRUFDRixDQUFDO0FBQ0QsUUFBTSxZQUFZLHdCQUF3QixLQUFLO0FBRS9DLE1BQUk7QUFDRixVQUFNLFNBQVMsTUFBTSxPQUFPLFlBQVk7QUFBQSxNQUN0QztBQUFBLE1BQ0EsU0FBUztBQUFBLElBQ1gsQ0FBQztBQUNELFVBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxlQUFXLFFBQVEsT0FBTztBQUN4QixZQUFNLGlCQUFpQixNQUFNLCtCQUErQixJQUFJO0FBS2hFLFlBQU0sUUFBUSxNQUFNLFlBQVksR0FBRyxLQUFLLE1BQU07QUFDOUMsWUFBTSxTQUFRLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDbEQsWUFBTSxlQUFlLFFBQVEsS0FBSyxjQUFjLFFBQVEsS0FBSyxhQUFhO0FBQzFFLFlBQU0sWUFBWSxLQUFLLFFBQVE7QUFBQSxRQUM3QixZQUFZLGVBQWUsS0FBSyxPQUFPLFNBQVMsS0FBSyxrQkFBa0I7QUFBQSxRQUN2RSxXQUFXO0FBQUEsUUFDWCxlQUFlLEtBQUssSUFBSTtBQUFBLFFBQ3hCLGlCQUNHLE1BQU0sa0JBQWtCLEtBQUssS0FBSyxPQUFPLFNBQVMsS0FBSyxrQkFBa0I7QUFBQSxRQUM1RSxlQUFlO0FBQUEsTUFDakIsQ0FBQztBQUdELFlBQU0sUUFBUSxJQUFJLEtBQUssTUFBTSxLQUFLLENBQUM7QUFDbkMsWUFBTSxVQUFTLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ3RDLGlCQUFXLEtBQUssS0FBSyxRQUFRO0FBQzNCLGNBQU0sRUFBRSxRQUFRLElBQUk7QUFBQSxVQUNsQixJQUFJO0FBQUEsVUFDSixLQUFLO0FBQUEsWUFDSCxFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsVUFDSjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsaUJBQVcsS0FBSyxLQUFLLG1CQUFtQjtBQUN0QyxjQUFNLEVBQUUsUUFBUSxJQUFJO0FBQUEsVUFDbEIsSUFBSTtBQUFBLFVBQ0osS0FBSyxlQUFlLENBQUM7QUFBQSxRQUN2QjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLEtBQUssTUFBTSxJQUFJO0FBQ25CLFlBQU0sS0FBSyxtQkFBbUI7QUFBQSxRQUM1QixRQUFRLEtBQUs7QUFBQSxRQUNiO0FBQUEsUUFDQSxRQUFRLEtBQUssT0FBTztBQUFBLFFBQ3BCLGFBQWEsS0FBSyxrQkFBa0I7QUFBQSxRQUNwQyxLQUFLLEtBQUs7QUFBQSxRQUNWLE1BQU0sS0FBSztBQUFBLFFBQ1gsY0FBYyxPQUFPO0FBQUEsTUFDdkIsQ0FBQztBQUFBLElBQ0g7QUFDQSxVQUFNLGtCQUFrQixHQUFHO0FBQzNCLFVBQU0sS0FBSyx5QkFBeUI7QUFBQSxNQUNsQztBQUFBLE1BQ0EsTUFBTSxNQUFNO0FBQUEsTUFDWixPQUFPLE1BQU07QUFBQSxNQUNiLFFBQVEsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxPQUFPLFFBQVEsQ0FBQztBQUFBLE1BQ25FLGFBQWEsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxrQkFBa0IsUUFBUSxDQUFDO0FBQUEsTUFDbkYsUUFBUSxPQUFPO0FBQUEsSUFDakIsQ0FBQztBQUNEO0FBQ0UsWUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLFFBQzdCLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixRQUFJLGVBQWUsYUFBYTtBQUM5QixZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sU0FDSixJQUFJLGFBQWEsU0FDYixlQUNBLElBQUksYUFBYSxlQUNmLGlCQUNBLElBQUksYUFBYSxZQUNmLGtCQUNBLEtBQUs7QUFDZixZQUFNLGNBQWM7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTyxJQUFJO0FBQUEsUUFDWCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLFFBQzdCLGtCQUNFLElBQUksYUFBYSxlQUFlLElBQUksbUJBQW1CLEtBQUs7QUFBQSxNQUNoRSxDQUFDO0FBQ0QsWUFBTSxNQUFPLGdCQUFnQjtBQUFBLFFBQzNCO0FBQUEsUUFDQSxTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNyRCxNQUFNLE1BQU07QUFBQSxRQUNaLE9BQU8sTUFBTTtBQUFBLFFBQ2IsVUFBVSxJQUFJO0FBQUEsUUFDZCxRQUFRLElBQUk7QUFBQSxRQUNaLFNBQVMsSUFBSTtBQUFBLFFBQ2Isa0JBQWtCLElBQUk7QUFBQSxNQUN4QixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0wsWUFBTSxNQUFPLGdCQUFnQjtBQUFBLFFBQzNCO0FBQUEsUUFDQSxTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNyRCxNQUFNLE1BQU07QUFBQSxRQUNaLE9BQU8sTUFBTTtBQUFBLFFBQ2IsR0FBRyxjQUFjLEdBQUc7QUFBQSxNQUN0QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBRUYsVUFBRTtBQUNBLFVBQU0sZUFBZTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLGVBQ1AsUUFDQSxLQUNBLFFBQ0EsbUJBQ1c7QUFDWCxRQUFNLEtBQUssV0FBVyxJQUFJLFVBQVU7QUFDcEMsUUFBTSxNQUFNLElBQUksV0FBVyxNQUFNLEdBQUcsRUFBRTtBQUN0QyxRQUFNLFdBQVcsV0FBVyxJQUFJLE1BQU07QUFDdEMsUUFBTSxVQUFVLE9BQU8sTUFBTSxJQUFJLEVBQUUsSUFBSSxRQUFRO0FBQy9DLFFBQU0sV0FBVyxRQUFRLE1BQU0sSUFBSSxFQUFFLElBQUksUUFBUTtBQUNqRCxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNQLGdCQUFnQjtBQUFBLE1BQ2hCLGdCQUFnQixJQUFJO0FBQUEsTUFDcEIsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYSxJQUFJO0FBQUEsTUFDakIsVUFBVSxJQUFJLGVBQWUsS0FBSyxHQUFHO0FBQUEsTUFDckMsWUFBWSxVQUFVO0FBQUEsTUFDdEIsWUFBWSxJQUFJO0FBQUEsTUFDaEI7QUFBQSxNQUNBLG9CQUFvQjtBQUFBLElBQ3RCO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixnQkFBZ0I7QUFBQSxNQUNoQixnQkFBZ0IsSUFBSTtBQUFBLE1BQ3BCLGdCQUFnQjtBQUFBLE1BQ2hCLGFBQWEsSUFBSTtBQUFBLE1BQ2pCLG9CQUFvQixJQUFJO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHdCQUF3QixPQUE0QjtBQUMzRCxNQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLFVBQU0sT0FBTyxNQUFNLENBQUM7QUFDcEIsVUFBTUMsb0JBQW1CLEtBQUssa0JBQWtCO0FBQ2hELFVBQU1DLFVBQVNELG9CQUFtQixJQUFJLEtBQUtBLGlCQUFnQixpQkFBaUI7QUFDNUUsV0FBTyxZQUFZLEtBQUssTUFBTSxJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssT0FBTyxNQUFNLFNBQVMsS0FBSyxPQUFPLFdBQVcsSUFBSSxLQUFLLEdBQUcsR0FBR0MsT0FBTSxTQUFTLEtBQUssUUFBUTtBQUFBLEVBQzdJO0FBQ0EsUUFBTSxPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUUsS0FBSztBQUM5RCxRQUFNLFdBQVcsS0FBSyxXQUFXLElBQUksS0FBSyxDQUFDLElBQUssR0FBRyxLQUFLLENBQUMsQ0FBQyxLQUFLLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQztBQUNwRixRQUFNLGFBQWEsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxPQUFPLFFBQVEsQ0FBQztBQUM5RSxRQUFNLG1CQUFtQixNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLGtCQUFrQixRQUFRLENBQUM7QUFDL0YsUUFBTSxTQUFTLG1CQUFtQixJQUFJLEtBQUssZ0JBQWdCLGlCQUFpQjtBQUM1RSxTQUFPLGtCQUFrQixNQUFNLE1BQU0sVUFBVSxVQUFVLFNBQVMsZUFBZSxJQUFJLEtBQUssR0FBRyxHQUFHLE1BQU0sS0FBSyxRQUFRO0FBQ3JIO0FBRUEsZUFBZSwrQkFBK0IsTUFBa0M7QUFDOUUsUUFBTSxVQUFVLE1BQU0sYUFBYSxLQUFLLE1BQU07QUFDOUMsTUFBSSxDQUFDLFFBQVMsUUFBTztBQUNyQixNQUFJLFFBQVEsV0FBVyxLQUFLLElBQUksT0FBUSxRQUFPLE9BQU8sS0FBSyxRQUFRLFlBQVksRUFBRTtBQUVqRixRQUFNLFlBQVksSUFBSTtBQUFBLElBQ3BCLEtBQUssT0FBTyxJQUFJLENBQUMsTUFBTTtBQUFBLE1BQ3JCLEVBQUU7QUFBQSxNQUNGLGNBQWMsRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLGFBQWEsRUFBRSxhQUFhLEVBQUUsWUFBWTtBQUFBLElBQzNGLENBQUM7QUFBQSxFQUNIO0FBQ0EsYUFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3RDLGNBQVUsSUFBSSxFQUFFLFVBQVUsZUFBZSxDQUFDLENBQUM7QUFBQSxFQUM3QztBQUNBLFFBQU0sa0JBQWtELENBQUM7QUFDekQsYUFBVyxDQUFDLFNBQVMsS0FBSyxLQUFLLE9BQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUNuRSxVQUFNLGVBQWUsVUFBVSxJQUFJLE9BQU87QUFDMUMsVUFBTSxhQUFhO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLElBQ1I7QUFDQSxRQUFJLENBQUMsZ0JBQWdCLGlCQUFpQixZQUFZO0FBQ2hELHNCQUFnQixPQUFPLElBQUksRUFBRSxHQUFHLE1BQU07QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLHVCQUF5RCxDQUFDO0FBQ2hFLGFBQVcsQ0FBQyxTQUFTLFdBQVcsS0FBSyxPQUFPLFFBQVEsUUFBUSxxQkFBcUIsQ0FBQyxDQUFDLEdBQUc7QUFDcEYsVUFBTSxlQUFlLFVBQVUsSUFBSSxPQUFPO0FBQzFDLFVBQU0sYUFBYSxlQUFlLFdBQVc7QUFDN0MsUUFBSSxDQUFDLGdCQUFnQixpQkFBaUIsWUFBWTtBQUNoRCwyQkFBcUIsT0FBTyxJQUFJLEVBQUUsR0FBRyxZQUFZO0FBQUEsSUFDbkQ7QUFBQSxFQUNGO0FBRUEsUUFBTSxlQUFlLG9CQUFJLElBQUk7QUFBQSxJQUMzQixHQUFHLE9BQU8sS0FBSyxlQUFlO0FBQUEsSUFDOUIsR0FBRyxPQUFPLEtBQUssb0JBQW9CO0FBQUEsRUFDckMsQ0FBQztBQUNELFFBQU0saUJBQWlCLGFBQWE7QUFDcEMsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLGVBQWUsS0FBSyxNQUFNO0FBQ2hDLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTSxZQUFZLFNBQVM7QUFDM0IsYUFBVyxTQUFTLE9BQU8sT0FBTyxlQUFlLEdBQUc7QUFDbEQsVUFBTSxpQkFBaUI7QUFBQSxFQUN6QjtBQUNBLFFBQU0sYUFBYSxLQUFLLFFBQVE7QUFBQSxJQUM5QixHQUFHO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDUixZQUFZLFFBQVE7QUFBQSxJQUNwQixjQUFjO0FBQUEsSUFDZCxtQkFBbUI7QUFBQSxJQUNuQixvQkFBb0IsUUFBUSxtQkFBbUIsT0FBTyxDQUFDLE9BQU8sYUFBYSxJQUFJLEVBQUUsQ0FBQztBQUFBLEVBQ3BGLENBQUM7QUFDRCxRQUFNLEtBQUssb0NBQW9DO0FBQUEsSUFDN0MsUUFBUSxLQUFLO0FBQUEsSUFDYixlQUFlLEtBQUs7QUFBQSxJQUNwQixVQUFVLFdBQVcsU0FBUztBQUFBLElBQzlCLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFDRCxTQUFPO0FBQ1Q7QUFJQSxlQUFlLFdBQVcsUUFBK0I7QUFDdkQsMkJBQXlCO0FBTXpCLFFBQU0sWUFBWSxpQkFBaUIsTUFBTTtBQUN6QyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsUUFBUSxLQUFLLGVBQWUsQ0FBQztBQUNuRSxNQUFJLENBQUUsTUFBTSxhQUFhLE1BQU0sR0FBSTtBQUNqQyxVQUFNLE9BQU0sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDbkMsVUFBTSxhQUFhLFFBQVE7QUFBQSxNQUN6QixRQUFRLFNBQVM7QUFBQSxNQUNqQixnQkFBZ0I7QUFBQSxNQUNoQixZQUFZO0FBQUEsTUFDWixpQkFBaUI7QUFBQSxNQUNqQixjQUFjLENBQUM7QUFBQSxNQUNmLG1CQUFtQixDQUFDO0FBQUEsTUFDcEIsb0JBQW9CLENBQUM7QUFBQSxNQUNyQixnQkFBZ0IsQ0FBQztBQUFBLE1BQ2pCLFlBQVk7QUFBQSxJQUNkLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssV0FBVyxRQUFRLEtBQUssQ0FBQztBQUM1RDtBQUVBLGVBQWUsYUFBNEI7QUFDekMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsT0FBTyxTQUFTLE9BQU8sQ0FBQztBQUM5RCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLFdBQVcsRUFBRSxNQUFNO0FBQUEsRUFDM0I7QUFDRjtBQVdBLGVBQWUsa0JBQWlDO0FBQzlDLDJCQUF5QjtBQUN6QixNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUFBLEVBQ3ZFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFDOUU7QUFBQSxFQUNGO0FBQ0EsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixNQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxZQUFZLENBQUMsSUFBSSxLQUFLO0FBQ2xELFVBQU0sS0FBSyxrQ0FBa0M7QUFDN0M7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLGdDQUFnQyxLQUFLLElBQUksR0FBRyxHQUFHO0FBQ2xELFVBQU0sS0FBSywrREFBK0Q7QUFBQSxNQUN4RSxLQUFLLFdBQVcsSUFBSSxHQUFHO0FBQUEsSUFDekIsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUd0RSxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUEsTUFDdEIsT0FBTztBQUFBLElBQ1QsQ0FBQztBQUNELFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyx1Q0FBdUMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUN0RTtBQUdBLE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTztBQUFBLE1BQ1AsTUFBTSxNQUFNO0FBQ1YsY0FBTSxJQUFJLE9BQU87QUFDakIsZUFBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUM7QUFDcEQsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLEdBQUc7QUFDM0UsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFBQSxNQUM5RTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ3pFO0FBQ0Y7QUFhQSxJQUFNLGtCQUFrQjtBQUV4QixlQUFlLGtCQUEwQztBQUN2RCxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGVBQWU7QUFDOUQsUUFBTSxLQUFLLE9BQU8sZUFBZTtBQUNqQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLGdCQUFnQixJQUFrQztBQUMvRCxNQUFJLE9BQU8sTUFBTTtBQUNmLFVBQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxlQUFlO0FBQUEsRUFDcEQsT0FBTztBQUNMLFVBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZUFBZSxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQzNEO0FBQ0Y7QUFFQSxlQUFlLG1CQUFrQztBQUMvQywyQkFBeUI7QUFDekIsUUFBTSxRQUFRLE1BQU0sa0JBQWtCO0FBQ3RDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLHlCQUF5QjtBQUNwQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0sa0JBQWtCO0FBQUEsSUFDdEIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCx1QkFBcUIsT0FBTztBQUM1QixPQUFLLFlBQVk7QUFDakIsUUFBTSxLQUFLLHdCQUF3QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMzRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLHdCQUErRDtBQUVuRSxTQUFTLHFCQUFxQixTQUF1QjtBQUNuRCxNQUFJLDBCQUEwQixLQUFNLGVBQWMscUJBQXFCO0FBQ3ZFLDBCQUF3QixZQUFZLE1BQU07QUFDeEMsU0FBSyxZQUFZLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDaEMsV0FBSyxLQUFLLHVCQUF1QixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3JELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyxzQkFBNEI7QUFDbkMsTUFBSSwwQkFBMEIsTUFBTTtBQUNsQyxrQkFBYyxxQkFBcUI7QUFDbkMsNEJBQXdCO0FBQUEsRUFDMUI7QUFDRjtBQUVBLGVBQWUsb0JBQW1DO0FBQ2hELHNCQUFvQjtBQUNwQixRQUFNLFFBQVEsT0FBTyxNQUFNLGNBQWM7QUFDekMsUUFBTSxRQUFRLE1BQU0sZ0JBQWdCO0FBQ3BDLFFBQU0sZ0JBQWdCLElBQUk7QUFDMUIsUUFBTSxPQUFPLE1BQU0sa0JBQWtCO0FBQ3JDLFFBQU0sa0JBQWtCLElBQUk7QUFDNUIsUUFBTSxLQUFLLDBCQUEwQjtBQUFBLElBQ25DLFNBQVMsVUFBVTtBQUFBLElBQ25CLFdBQVcsTUFBTSxhQUFhO0FBQUEsRUFDaEMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsY0FBNkI7QUFDMUMsTUFBSSxPQUFPLE1BQU0sa0JBQWtCO0FBQ25DLE1BQUksU0FBUyxNQUFNO0FBRWpCLHdCQUFvQjtBQUNwQjtBQUFBLEVBQ0Y7QUFJQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGdCQUFnQjtBQUM1QjtBQUFBLElBQ0Y7QUFFQSxVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsVUFBVSxLQUFLLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsSUFDYixDQUFDO0FBRUQsVUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLGVBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFVBQUksSUFBSSxTQUFTLEtBQUssU0FBUyxPQUFPLEdBQUc7QUFDdkMsY0FBTSxlQUFlLFFBQVEsS0FBSyxTQUFTLE9BQU87QUFDbEQ7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBRUEsUUFBTSxTQUFTLE1BQU0sa0JBQWtCO0FBQ3ZDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsd0JBQW9CO0FBQ3BCLFVBQU0sZ0JBQWdCLElBQUk7QUFDMUIsVUFBTSxrQkFBa0IsSUFBSTtBQUM1QixVQUFNLEtBQUsseUJBQXlCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNqRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTSxNQUFNLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDbkUsTUFBSSxRQUFRLE1BQU0sZ0JBQWdCO0FBQ2xDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxnQkFBZ0IsSUFBSSxFQUFFO0FBQUEsSUFDOUQsT0FBTztBQUNMLFlBQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQztBQUFBLElBQzFDO0FBQ0EsV0FBUSxNQUFNLGtCQUFrQixLQUFNO0FBQ3RDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxrQkFBa0IsSUFBSTtBQUM1QixVQUFNLEtBQUssZ0JBQWdCO0FBQUEsTUFDekIsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixXQUFXLE1BQU0sa0JBQWtCO0FBQUEsTUFDbkMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssNENBQTRDO0FBQUEsTUFDckQsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNLGVBQWUsT0FBTyxRQUFRLE9BQU8sT0FBTztBQUNsRCxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0sa0JBQWtCLElBQUk7QUFBQSxFQUM5QjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQVdBLElBQU0sc0JBQXNCO0FBRTVCLGVBQWUscUJBQTZDO0FBQzFELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksbUJBQW1CO0FBQ2xFLFFBQU0sS0FBSyxPQUFPLG1CQUFtQjtBQUNyQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLG1CQUFtQixJQUFrQztBQUNsRSxNQUFJLE9BQU8sS0FBTSxPQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU8sbUJBQW1CO0FBQUEsTUFDbEUsT0FBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxtQkFBbUIsR0FBRyxHQUFHLENBQUM7QUFDcEU7QUFFQSxlQUFlLHNCQUFxQztBQUNsRCwyQkFBeUI7QUFDekIsUUFBTSxRQUFRLE1BQU0scUJBQXFCO0FBQ3pDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLDZCQUE2QjtBQUN4QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCwwQkFBd0IsT0FBTztBQUMvQixPQUFLLGVBQWU7QUFDcEIsUUFBTSxLQUFLLDRCQUE0QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMvRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLDJCQUFrRTtBQUV0RSxTQUFTLHdCQUF3QixTQUF1QjtBQUN0RCxNQUFJLDZCQUE2QixLQUFNLGVBQWMsd0JBQXdCO0FBQzdFLDZCQUEyQixZQUFZLE1BQU07QUFDM0MsU0FBSyxlQUFlLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDbkMsV0FBSyxLQUFLLDJCQUEyQixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3pELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyx5QkFBK0I7QUFDdEMsTUFBSSw2QkFBNkIsTUFBTTtBQUNyQyxrQkFBYyx3QkFBd0I7QUFDdEMsK0JBQTJCO0FBQUEsRUFDN0I7QUFDRjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHlCQUF1QjtBQUN2QixRQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLFFBQVEsTUFBTSxtQkFBbUI7QUFDdkMsUUFBTSxtQkFBbUIsSUFBSTtBQUM3QixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxpQkFBZ0M7QUFDN0MsTUFBSSxPQUFPLE1BQU0scUJBQXFCO0FBQ3RDLE1BQUksU0FBUyxNQUFNO0FBQ2pCLDJCQUF1QjtBQUN2QjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGdCQUFnQjtBQUM1QjtBQUFBLElBQ0Y7QUFDQSxVQUFNLEtBQUssb0RBQW9EO0FBQUEsTUFDN0QsVUFBVSxLQUFLLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsSUFDYixDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsS0FBSyxTQUFTLE9BQU87QUFDN0MsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQUEsRUFDakM7QUFFQSxRQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsTUFBSSxDQUFDLFFBQVE7QUFDWCwyQkFBdUI7QUFDdkIsVUFBTSxtQkFBbUIsSUFBSTtBQUM3QixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sS0FBSyw2QkFBNkIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ3JFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFHQSxNQUFJLE1BQU0sWUFBWSxPQUFPLE9BQU8sR0FBRztBQUNyQyxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFPQSxRQUFNLE1BQ0osT0FBTyxXQUFXLGFBQ2QsOEJBQThCLE9BQU8sT0FBTyxLQUM1QyxpQkFBaUIsT0FBTyxNQUFNLFdBQVcsT0FBTyxPQUFPO0FBQzdELE1BQUksUUFBUSxNQUFNLG1CQUFtQjtBQUNyQyxNQUFJLFVBQVUsTUFBTTtBQUNsQixRQUFJO0FBQ0YsWUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDOUIsUUFBUTtBQUNOLGNBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixRQUFJLFVBQVUsTUFBTTtBQUNsQixZQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDNUQsVUFBSSxPQUFPLElBQUksT0FBTyxTQUFVLE9BQU0sbUJBQW1CLElBQUksRUFBRTtBQUFBLElBQ2pFLE9BQU87QUFDTCxZQUFNLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUNBLFdBQVEsTUFBTSxxQkFBcUIsS0FBTTtBQUN6QyxTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVMsT0FBTztBQUFBLE1BQ2hCLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUN0QztBQUNBLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLG9CQUFvQjtBQUFBLE1BQzdCLFVBQVUsT0FBTztBQUFBLE1BQ2pCLGFBQWEsT0FBTyxXQUFXLGFBQWEsT0FBTyxPQUFPO0FBQUEsTUFDMUQsV0FBVyxNQUFNLHFCQUFxQjtBQUFBLE1BQ3RDLFdBQVcsS0FBSztBQUFBLE1BQ2hCLGdCQUFnQixLQUFLO0FBQUEsSUFDdkIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGdEQUFnRDtBQUFBLE1BQ3pELFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUlBLGVBQWUsV0FDYixRQUNBLFVBQ0EsS0FDQSxLQUNBLEtBQ2U7QUFDZixRQUFNLE1BQU8sd0JBQXdCLEVBQUUsUUFBUSxVQUFVLEtBQUssR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQ3JGLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLFVBQTZCO0FBQUEsSUFDakMsZ0JBQWdCO0FBQUEsSUFDaEI7QUFBQSxJQUNBO0FBQUEsSUFDQSxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDcEMsWUFBWTtBQUFBLElBQ1osT0FBTyxjQUFjLEdBQUc7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssV0FBVyxRQUFRLFdBQVc7QUFDekMsUUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxDQUFDO0FBQy9DLFFBQU0sT0FBTyxtQkFBbUIsRUFBRSxJQUFJLElBQUk7QUFDMUMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ25CO0FBQUEsTUFDQSxlQUFlRixVQUFTLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUMvRCxTQUFTLGVBQWUsTUFBTSxJQUFJLFFBQVE7QUFBQSxJQUM1QyxDQUFDO0FBQUEsRUFDSCxTQUFTLE1BQU07QUFDYixVQUFNLE1BQU8sNEJBQTRCLEVBQUUsR0FBRyxjQUFjLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDckU7QUFDRjtBQUVBLGVBQWUsS0FBSyxHQUE0QjtBQUM5QyxRQUFNLE1BQU0sSUFBSSxZQUFZLEVBQUUsT0FBTyxDQUFDO0FBQ3RDLFFBQU0sU0FBUyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsR0FBRztBQUN4RCxRQUFNLE1BQU0sTUFBTSxLQUFLLElBQUksV0FBVyxNQUFNLENBQUMsRUFDMUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRTtBQUNWLFNBQU8sSUFBSSxNQUFNLEdBQUcsQ0FBQztBQUN2QjtBQUlBLGVBQWUsaUJBQWlCLE9BQStCO0FBQzdELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsTUFBTTtBQUN0RCxVQUFNLGNBQWM7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUixPQUFPO0FBQUEsTUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZTtBQUFBLE1BQ2Ysd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLE1BQUksQ0FBQyxPQUFPO0FBSVYsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBS0EsUUFBSSxLQUFLLFdBQVc7QUFDbEIsWUFBTSxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVM7QUFDbEQsVUFBSSxNQUFNLDhCQUErQjtBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxJQUFJLE1BQU0sT0FBTyxpQkFBaUI7QUFJeEMsUUFBSSxXQUFXO0FBQ2YsUUFBSSxTQUFTLFVBQVUsU0FBUyxXQUFXLEVBQUUsZ0JBQWdCO0FBQzNELGlCQUFXLE1BQU0sT0FBTyxhQUFhLFNBQVMsTUFBTTtBQUFBLElBQ3REO0FBQ0EsVUFBTSxhQUFhLFNBQVMsaUJBQWlCLEtBQUssS0FBSztBQUN2RCxRQUFJLFlBQVksWUFBWTtBQUMxQixZQUFNLE9BQU8sa0JBQWtCO0FBQUEsSUFDakM7QUFDQSxVQUFNLGNBQWM7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUixPQUFPLEVBQUU7QUFBQSxNQUNULFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsTUFDUCxlQUFlLEVBQUU7QUFBQSxNQUNqQix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxLQUFLLHVCQUF1QjtBQUFBLE1BQ2hDLE9BQU8sRUFBRTtBQUFBLE1BQ1QsTUFBTSxFQUFFO0FBQUEsTUFDUixnQkFBZ0IsRUFBRTtBQUFBLE1BQ2xCLG1CQUFtQixTQUFTO0FBQUEsTUFDNUIsMEJBQTBCO0FBQUEsTUFDMUIsY0FBYyxhQUFhLFlBQVk7QUFBQSxJQUN6QyxDQUFDO0FBQ0QsUUFBSSxDQUFDLFVBQVU7QUFDYixZQUFNLEtBQUssOENBQThDO0FBQUEsUUFDdkQsWUFBWSxTQUFTO0FBQUEsUUFDckIsZ0JBQWdCLEVBQUU7QUFBQSxRQUNsQixLQUFLLHdDQUF3QyxFQUFFO0FBQUEsTUFDakQsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sTUFBTSxlQUFlLGNBQWMsSUFBSSxXQUFXO0FBQ3hELFVBQU0sU0FDSixRQUFRLFNBQ0osZUFDQSxRQUFRLGVBQ04saUJBQ0EsUUFBUSxZQUNOLGtCQUNBO0FBQ1YsVUFBTSxVQUNKLGVBQWUsZUFBZSxRQUFRLGVBQWUsSUFBSSxtQkFBbUI7QUFDOUUsVUFBTSxjQUFjO0FBQUEsTUFDbEI7QUFBQSxNQUNBLE9BQU87QUFBQSxNQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPLGNBQWMsR0FBRyxFQUFFO0FBQUEsTUFDMUIsZUFBZTtBQUFBLE1BQ2Ysd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sS0FBSywyQkFBMkI7QUFBQSxNQUNwQyxVQUFVO0FBQUEsTUFDVixrQkFBa0I7QUFBQSxNQUNsQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxvQkFBb0IsT0FBK0I7QUFDaEUsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxLQUFLO0FBQ2pCLFVBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEM7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLE9BQU87QUFJVixVQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFlBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUMzQyxVQUFJLFNBQVMsS0FBSyxpQkFBa0I7QUFBQSxJQUN0QztBQUlBLFVBQU0sZ0JBQWdCLE1BQU0sdUJBQXVCO0FBQ25ELFFBQUksZUFBZTtBQUNqQixZQUFNLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLGFBQWE7QUFDakQsVUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLLE1BQU0sOEJBQStCO0FBQUEsSUFDbkU7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sTUFBTSxPQUFPLGFBQWEsc0JBQXNCO0FBQzdELFFBQUksQ0FBQyxNQUFNO0FBQ1QsVUFBSSxNQUFPLE9BQU0sS0FBSyxpREFBaUQ7QUFDdkUsWUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QyxZQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JEO0FBQUEsSUFDRjtBQUNBLFVBQU0sU0FBUyxrQkFBa0IsSUFBSTtBQUNyQyxRQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFlBQU0sS0FBSyw4Q0FBOEM7QUFDekQsWUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QyxZQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JEO0FBQUEsSUFDRjtBQUNBLFVBQU0sWUFBWSxNQUFNO0FBQ3hCLFVBQU0sdUJBQXVCLFFBQVEsS0FBSztBQUMxQyxVQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JELFFBQUksTUFBTyxPQUFNLEtBQUssMkJBQTJCLEVBQUUsT0FBTyxPQUFPLE9BQU8sQ0FBQztBQUFBLEVBQzNFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUNoRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsdUJBQXVCLFFBQXNCLE9BQStCO0FBQ3pGLFFBQU0sT0FBTyxNQUFNLE9BQU8sYUFBYSxvQkFBb0I7QUFDM0QsTUFBSSxDQUFDLE1BQU07QUFDVCxVQUFNLG1CQUFtQixJQUFJO0FBQzdCLFFBQUksTUFBTyxPQUFNLEtBQUssMERBQTBEO0FBQ2hGO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFdBQVcscUJBQXFCLEtBQUssTUFBTSxJQUFJLENBQVk7QUFDakUsVUFBTSxtQkFBbUIsUUFBUTtBQUNqQyxRQUFJLE9BQU87QUFDVCxZQUFNLEtBQUssOEJBQThCO0FBQUEsUUFDdkMsVUFBVSxPQUFPLEtBQUssU0FBUyxRQUFRLEVBQUU7QUFBQSxRQUN6QyxjQUFjLFNBQVM7QUFBQSxNQUN6QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLCtEQUErRCxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQzlGO0FBQ0Y7QUFJQSxlQUFlLGlCQUFnQztBQUM3QyxRQUFNLFFBQVEsTUFBTSxXQUFXO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsTUFBTSxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFO0FBRUEsZUFBZSxhQUFzQztBQUNuRCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksV0FBVztBQUNmLE1BQUk7QUFDRixVQUFNLE9BQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUMzRixlQUFXLEtBQUs7QUFBQSxFQUNsQixRQUFRO0FBQUEsRUFHUjtBQUNBLFFBQU0sZ0JBQWdCLE1BQU0sa0JBQWtCO0FBQzlDLFFBQU0sbUJBQW1CLE1BQU0scUJBQXFCO0FBQ3BELFFBQU0sY0FBYyxNQUFNLGtCQUFrQjtBQUM1QyxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxRQUFNLHVCQUF1QixNQUFNLHdCQUF3QjtBQUMzRCxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVCxVQUFVLGVBQWUsUUFBUTtBQUFBLElBQ2pDLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWTtBQUFBLE1BQ1YsUUFBUSxtQkFBbUIsUUFBUSxvQkFBb0I7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsYUFBYSxnQkFBZ0IsZUFBZTtBQUFBLE1BQzVDLGVBQWUsZ0JBQWdCLGlCQUFpQjtBQUFBLE1BQ2hELGtCQUFrQixnQkFBZ0Isb0JBQW9CO0FBQUEsTUFDdEQsdUJBQXVCLGdCQUFnQix5QkFBeUI7QUFBQSxNQUNoRSxpQkFBaUIsZ0JBQWdCLG1CQUFtQjtBQUFBLE1BQ3BELGVBQWUsZ0JBQWdCLGlCQUFpQjtBQUFBLElBQ2xEO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixPQUFPO0FBQUEsTUFDUCxTQUFTLDBCQUEwQjtBQUFBLE1BQ25DLFdBQVcsYUFBYSxhQUFhO0FBQUEsTUFDckMsZ0JBQWdCLGFBQWEsZ0JBQWdCO0FBQUEsSUFDL0M7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLE1BQ2YsT0FBTztBQUFBLE1BQ1AsU0FBUyw2QkFBNkI7QUFBQSxNQUN0QyxXQUFXLGdCQUFnQixhQUFhO0FBQUEsTUFDeEMsZ0JBQWdCLGdCQUFnQixnQkFBZ0I7QUFBQSxJQUNsRDtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBeUM7QUFDL0QsU0FBTztBQUFBLElBQ0wsT0FBTyxFQUFFO0FBQUEsSUFDVCxNQUFNLEVBQUU7QUFBQSxJQUNSLFFBQVEsRUFBRTtBQUFBLElBQ1YsU0FBUyxFQUFFO0FBQUEsSUFDWCxhQUFhLEVBQUU7QUFBQSxJQUNmLGNBQWMsRUFBRTtBQUFBLElBQ2hCLHVCQUF1QixFQUFFO0FBQUEsSUFDekIsZ0JBQWdCLEVBQUU7QUFBQSxJQUNsQixRQUFRLEVBQUUsSUFBSSxTQUFTO0FBQUEsSUFDdkIsV0FBVyxFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSTtBQUFBLEVBQ25EO0FBQ0Y7QUFFQSxTQUFTLHFCQUFxQixLQUErQjtBQUMzRCxNQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsU0FBVSxPQUFNLElBQUksTUFBTSwyQkFBMkI7QUFDaEYsUUFBTSxXQUFXO0FBQ2pCLE1BQUksQ0FBQyxNQUFNLFFBQVEsU0FBUyxRQUFRLEVBQUcsT0FBTSxJQUFJLE1BQU0sbUNBQW1DO0FBQzFGLFFBQU0sV0FBd0MsQ0FBQztBQUMvQyxhQUFXLFNBQVMsU0FBUyxVQUFVO0FBQ3JDLFFBQUksQ0FBQyxTQUFTLE9BQU8sVUFBVSxTQUFVO0FBQ3pDLFVBQU0sTUFBTTtBQUNaLFVBQU0sU0FBUyxPQUFPLElBQUksV0FBVyxXQUFXLElBQUksU0FBUztBQUM3RCxRQUFJLENBQUMsVUFBVSxXQUFXLFFBQVM7QUFDbkMsYUFBUyxPQUFPLFlBQVksQ0FBQyxJQUFJO0FBQUEsTUFDL0I7QUFBQSxNQUNBLGdCQUFnQixPQUFPLElBQUksbUJBQW1CLFdBQVcsSUFBSSxpQkFBaUI7QUFBQSxNQUM5RSxtQkFBbUIsT0FBTyxJQUFJLHNCQUFzQixXQUFXLElBQUksb0JBQW9CO0FBQUEsTUFDdkYsV0FBVyxPQUFPLElBQUksY0FBYyxXQUFXLElBQUksWUFBWTtBQUFBLElBQ2pFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMLGNBQWMsT0FBTyxTQUFTLGlCQUFpQixXQUFXLFNBQVMsZUFBZTtBQUFBLElBQ2xGLGFBQVksb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsd0JBQXdCLEdBQW1CLFVBQTJDO0FBQzdGLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFDdEIsUUFBTSxRQUFRLFNBQVMsU0FBUyxFQUFFLGVBQWUsWUFBWSxDQUFDO0FBQzlELE1BQUksQ0FBQyxPQUFPLGVBQWdCLFFBQU87QUFDbkMsUUFBTSxTQUFTLEtBQUssTUFBTSxFQUFFLFNBQVM7QUFDckMsUUFBTSxTQUFTLEtBQUssTUFBTSxNQUFNLGNBQWM7QUFDOUMsU0FBTyxPQUFPLFNBQVMsTUFBTSxLQUFLLE9BQU8sU0FBUyxNQUFNLEtBQUssVUFBVTtBQUN6RTtBQUVBLFNBQVMsbUJBQ1AsR0FDQSxVQUNBLFFBQ0EsWUFBZ0MsT0FDaEMsU0FBa0MsWUFDbkI7QUFDZixTQUFPO0FBQUEsSUFDTCxVQUFVLEVBQUU7QUFBQSxJQUNaLGdCQUFnQixFQUFFO0FBQUEsSUFDbEIsV0FBVyxFQUFFO0FBQUEsSUFDYixNQUFNLEVBQUUsaUJBQWlCLEVBQUU7QUFBQSxJQUMzQixZQUFZLEVBQUU7QUFBQSxJQUNkLFdBQVcsRUFBRTtBQUFBLElBQ2IsU0FBUztBQUFBLElBQ1Q7QUFBQSxJQUNBLGdCQUFnQixjQUFjLGFBQWEsVUFBVTtBQUFBLElBQ3JEO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyxpQkFBaUIsU0FBaUM7QUFDekQsU0FDRSxPQUFPLFlBQVksWUFDbkIsNkVBQTZFLEtBQUssT0FBTztBQUU3RjtBQUVBLFNBQVMsV0FBVyxLQUFxQjtBQUV2QyxRQUFNLElBQUksSUFBSSxLQUFLLEdBQUc7QUFDdEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPLElBQUksUUFBUSxTQUFTLEVBQUU7QUFDN0QsUUFBTSxNQUFNLENBQUMsR0FBVyxJQUFJLE1BQU0sT0FBTyxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUc7QUFDM0QsU0FDRSxHQUFHLEVBQUUsZUFBZSxDQUFDLElBQUksSUFBSSxFQUFFLFlBQVksSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFDcEUsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDO0FBRTlFO0FBRUEsU0FBUyxVQUFVLEdBQXFCO0FBQ3RDLFNBQU8sV0FBVyxFQUFFLEtBQUssY0FBYyxFQUFFLElBQUk7QUFDL0M7QUFTQSxTQUFTLGVBQWUsTUFBeUI7QUFDL0MsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNRyxPQUFNO0FBQ1osVUFBSSxPQUFPQSxLQUFJLGVBQWUsU0FBVSxNQUFLLElBQUlBLEtBQUksVUFBVTtBQUMvRCxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsU0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLEtBQUs7QUFDeEI7QUFPQSxTQUFTLG9CQUFvQixNQUFlLFVBQW1DO0FBQzdFLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUEsT0FBTTtBQUNaLFVBQUlBLEtBQUksZUFBZSxVQUFVO0FBQy9CLGVBQU8sT0FBTyxLQUFLQSxJQUFHLEVBQUUsS0FBSztBQUFBLE1BQy9CO0FBQ0EsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQVFBLFNBQVMsaUJBQWlCLE1BQWUsVUFBa0IsTUFBeUI7QUFDbEYsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLE1BQUksUUFBd0M7QUFDNUMsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1BLE9BQU07QUFDWixVQUFJQSxLQUFJLGVBQWUsVUFBVTtBQUMvQixnQkFBUUE7QUFDUjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixNQUFJLE1BQWU7QUFDbkIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVUsUUFBTyxJQUFJLFFBQVEsT0FBTyxTQUFTLE9BQU8sR0FBRztBQUMxRixVQUFPLElBQWdDLEdBQUc7QUFBQSxFQUM1QztBQUNBLE1BQUksUUFBUSxPQUFXLFFBQU87QUFDOUIsTUFBSSxRQUFRLEtBQU0sUUFBTztBQUN6QixNQUFJLE9BQU8sUUFBUSxTQUFVLFFBQU8sSUFBSSxPQUFPLEdBQUc7QUFDbEQsTUFBSSxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sY0FBYyxJQUFJLE1BQU07QUFDdkQsU0FBTyxPQUFPLEtBQUssR0FBOEIsRUFBRSxLQUFLO0FBQzFEO0FBRUEsU0FBUyxXQUFXLEdBQW1CO0FBR3JDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFDeEIsVUFBTSxPQUFPLE9BQU8sWUFBWSxPQUFPLFNBQVMsWUFBTztBQUN2RCxXQUFPLE9BQU8sU0FBUyxXQUFXLE9BQU8sU0FBUyxnQkFDOUMsT0FDQSxHQUFHLE9BQU8sSUFBSSxHQUFHLElBQUk7QUFBQSxFQUMzQixRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQ7QUFDRjtBQUtDLFdBQXVDLGVBQWU7QUFBQSxFQUNyRDtBQUFBLEVBQ0EsVUFBVTtBQUFBLEVBQ1YsVUFBVTtBQUFBLEVBQ1YsU0FBUztBQUFBLEVBQ1QsVUFBVSxNQUFNLFNBQVMsVUFBVTtBQUFBLEVBQ25DLE9BQU87QUFBQSxFQUNQLGNBQWM7QUFBQSxFQUNkLGNBQWM7QUFBQSxFQUNkLGVBQWU7QUFBQSxFQUNmLGlCQUFpQjtBQUFBLEVBQ2pCLGlCQUFpQjtBQUFBLEVBQ2pCLGtCQUFrQjtBQUNwQjsiLAogICJuYW1lcyI6IFsidG9CYXNlNjQiLCAib2JqIiwgImluZm8iLCAidG9CYXNlNjQiLCAidW5hdmFpbGFibGVDb3VudCIsICJzdWZmaXgiLCAib2JqIl0KfQo=
