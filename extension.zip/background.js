// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  autoCapture: true,
  configuredAt: null
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement" },
  { handle: "CBP", label: "U.S. Customs and Border Protection" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services" },
  { handle: "WhiteHouse", label: "The White House" },
  { handle: "PressSec", label: "White House Press Secretary" },
  { handle: "POTUS", label: "President of the United States" },
  { handle: "USDOL", label: "U.S. Department of Labor" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: []
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  return getRaw("settings");
}
async function setSettings(s) {
  await setRaw("settings", s);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getConnection() {
  const c = await getRaw("connection");
  if (c.defaultBranch === void 0) {
    return { ...c, defaultBranch: null };
  }
  return c;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category
    });
  }
};
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase64(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const observed = [];
  for (const raw of rawTweets) {
    try {
      const t = buildTweet(raw, ctx);
      if (!t) continue;
      observed.push(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  return { tweets, observed_ids: observed };
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy);
  if (!restId || !legacy) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userLegacy = obj(userResult?.legacy);
  const handle = strOrNull(userLegacy?.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    hashtags,
    mentions,
    urls,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      if (current.handle && current.label) accounts.push(current);
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      if (current.handle && current.label) accounts.push(current);
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
  }
  if (current.handle && current.label) accounts.push(current);
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await flushOrphanedBuffersIfStale();
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
async function handleMessage(msg) {
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const accounts = await getAccounts();
  const allowed = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: allowed
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  if (normalized.tweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of normalized.tweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, Object.keys(buf.tweets_by_id).length);
    if (added > 0) {
      await info("captured tweets", {
        handle,
        endpoint,
        added,
        total: Object.keys(buf.tweets_by_id).length
      });
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      await flushHandle(handle, "idle");
    }
  }
}
async function flushOrphanedBuffersIfStale() {
  const all = await getRunBuffers();
  const now = Date.now();
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      await flushHandle(handle, "wake");
    }
  }
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  for (const handle of Object.keys(all)) {
    await flushHandle(handle, reason);
  }
}
async function flushHandle(handle, reason) {
  const buf = await getRunBuffer(handle);
  if (!buf) return;
  const tweets = Object.values(buf.tweets_by_id);
  if (tweets.length === 0) {
    await clearRunBuffer(handle);
    return;
  }
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", { handle });
    return;
  }
  const client = new GitHubClient(settings);
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const rawPath = `raw/${handle}/${ts}-${shortRunId(buf.run_id)}.json`;
  const seenPath = `seen/${handle}/${ts}-${shortRunId(buf.run_id)}.json`;
  const capture = {
    schema_version: 1,
    capture_run_id: buf.run_id,
    account_handle: handle,
    captured_at: buf.last_capture_at,
    endpoint: buf.endpoints_seen.join(","),
    user_agent: navigator.userAgent,
    source_url: buf.source_url,
    tweets
  };
  const seen = {
    schema_version: 1,
    capture_run_id: buf.run_id,
    account_handle: handle,
    captured_at: buf.last_capture_at,
    tweet_ids_observed: buf.tweet_ids_observed
  };
  const commitMsg = `capture: ${handle} ${day} ${tweets.length} tweet${tweets.length === 1 ? "" : "s"} (run ${shortRunId(buf.run_id)})`;
  try {
    await client.putFile({
      path: rawPath,
      contentBase64: toBase64(JSON.stringify(capture, null, 2) + "\n"),
      message: commitMsg
    });
    await client.putFile({
      path: seenPath,
      contentBase64: toBase64(JSON.stringify(seen, null, 2) + "\n"),
      message: `seen: ${handle} ${day} ${seen.tweet_ids_observed.length} ids (run ${shortRunId(buf.run_id)})`
    });
    await clearRunBuffer(handle);
    await bumpCounter(handle, {
      todayCount: (await getCounters())[handle]?.todayCount ?? 0,
      todayDate: day,
      lastCaptureAt: buf.last_capture_at,
      totalCommitted: ((await getCounters())[handle]?.totalCommitted ?? 0) + tweets.length,
      bufferedCount: 0
    });
    await info("flush committed", {
      handle,
      reason,
      tweets: tweets.length,
      run: shortRunId(buf.run_id),
      path: rawPath
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch
      });
      await error("flush failed", {
        handle,
        reason,
        category: err.category,
        status: err.status,
        message: err.message
      });
    } else {
      await error("flush failed", { handle, reason, ...describeError(err) });
    }
  } finally {
    await broadcastState();
  }
}
async function captureNow(handle) {
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase64(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force && conn.status === "ok" && conn.checkedAt) {
    const age = Date.now() - Date.parse(conn.checkedAt);
    if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch
    });
    if (settings.branch && settings.branch !== r.default_branch) {
      const branchOk = await client.branchExists(settings.branch);
      if (!branchOk) {
        await warn("configured branch does not exist on remote", {
          configured: settings.branch,
          default_branch: r.default_branch,
          fix: "open Settings and change branch to " + r.default_branch
        });
      }
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null
    });
    await warn("connection check failed", { category: cat, ...describeError(err) });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      return;
    }
    await setAccounts(parsed);
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHBhdDogJycsXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXG4gIHJlcG86ICd4JyxcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxuICBicmFuY2g6ICdtYXN0ZXInLFxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcbiAgY29uZmlndXJlZEF0OiBudWxsLFxufTtcblxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcbi8vIHJlcG8gaGFzIGJlZW4gaW5pdGlhbGl6ZWQgb3IgUEFUIG1pc2NvbmZpZ3VyZWQpLiBLZXB0IGluIHN5bmMgd2l0aCB0aGUgZmlsZS5cbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScgfSxcbiAgeyBoYW5kbGU6ICdJQ0Vnb3YnLCBsYWJlbDogJ1UuUy4gSW1taWdyYXRpb24gYW5kIEN1c3RvbXMgRW5mb3JjZW1lbnQnIH0sXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJyB9LFxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycgfSxcbiAgeyBoYW5kbGU6ICdXaGl0ZUhvdXNlJywgbGFiZWw6ICdUaGUgV2hpdGUgSG91c2UnIH0sXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScgfSxcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJyB9LFxuICB7IGhhbmRsZTogJ1VTRE9MJywgbGFiZWw6ICdVLlMuIERlcGFydG1lbnQgb2YgTGFib3InIH0sXG5dO1xuXG4vLyBHcmFwaFFMIGVuZHBvaW50IG5hbWVzIHdlIGNhcmUgYWJvdXQgKG1hdGNoZWQgYnkgc3Vic3RyaW5nIGFnYWluc3QgVVJMIHBhdGgpLlxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG4gICdMaWtlcycsXG4gICdCb29rbWFya3MnLFxuICAnSG9tZVRpbWVsaW5lJyxcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXG4gICdTZWFyY2hUaW1lbGluZScsXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxuXSk7XG5cbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxuLy8gdG8gbGVhcm4gYWNjb3VudF9pZCA8LT4gaGFuZGxlIGJpbmRpbmdzKS5cbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcblxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xuXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcblxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XG5cbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcblxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XG5cbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB0eXBlIHtcbiAgQWNjb3VudENvbmZpZyxcbiAgQWNjb3VudENvdW50ZXIsXG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDb25uZWN0aW9uU3RhdGUsXG4gIExvZ0V2ZW50LFxuICBTZXR0aW5ncyxcbn0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogQnVmZmVyZWQgdHdlZXRzIGZvciBhIGdpdmVuIGFjY291bnQsIGF3YWl0aW5nIGNvbW1pdC4gQSBcInJ1blwiIGlzIG9uZSBlbnRyeVxuICogaW4gdGhpcyBtYXA7IGZsdXNoaW5nIGNsZWFycyB0aGUgZW50cnkuIFdlIHN0b3JlIGFzIFJlY29yZCBzbyB0aGUgc3RydWN0dXJlXG4gKiBzdXJ2aXZlcyBKU09OIHNlcmlhbGl6YXRpb24gdGhyb3VnaCBicm93c2VyLnN0b3JhZ2UuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUnVuQnVmZmVyIHtcbiAgcnVuX2lkOiBzdHJpbmc7XG4gIGFjY291bnRfaGFuZGxlOiBzdHJpbmc7XG4gIHN0YXJ0ZWRfYXQ6IHN0cmluZztcbiAgbGFzdF9jYXB0dXJlX2F0OiBzdHJpbmc7XG4gIHR3ZWV0c19ieV9pZDogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+O1xuICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IHN0cmluZ1tdO1xuICBlbmRwb2ludHNfc2Vlbjogc3RyaW5nW107XG4gIHNvdXJjZV91cmw6IHN0cmluZyB8IG51bGw7XG59XG5cbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xuICBzZXR0aW5nczogU2V0dGluZ3M7XG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcbiAgcnVuQnVmZmVyczogUmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPjtcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XG59XG5cbmNvbnN0IERFRkFVTFRfQ09OTkVDVElPTjogQ29ubmVjdGlvblN0YXRlID0ge1xuICBzdGF0dXM6ICd1bmtub3duJyxcbiAgbG9naW46IG51bGwsXG4gIGNoZWNrZWRBdDogbnVsbCxcbiAgZXJyb3I6IG51bGwsXG4gIGRlZmF1bHRCcmFuY2g6IG51bGwsXG59O1xuXG5jb25zdCBERUZBVUxUUzogU3RvcmFnZVNoYXBlID0ge1xuICBzZXR0aW5nczogeyAuLi5ERUZBVUxUX1NFVFRJTkdTIH0sXG4gIGFjY291bnRzOiBbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdLFxuICBjb25uZWN0aW9uOiB7IC4uLkRFRkFVTFRfQ09OTkVDVElPTiB9LFxuICBjb3VudGVyczoge30sXG4gIHJ1bkJ1ZmZlcnM6IHt9LFxuICBhY3Rpdml0eTogW10sXG59O1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChrZXkpO1xuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUoREVGQVVMVFNba2V5XSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW2tleV06IHZhbHVlIH0pO1xufVxuXG4vLyAtLS0gU2V0dGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICByZXR1cm4gZ2V0UmF3KCdzZXR0aW5ncycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnc2V0dGluZ3MnLCBzKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVTZXR0aW5ncyhwYXRjaDogUGFydGlhbDxTZXR0aW5ncz4pOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IG5leHQgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYXdhaXQgc2V0U2V0dGluZ3MobmV4dCk7XG4gIHJldHVybiBuZXh0O1xufVxuXG4vLyAtLS0gQWNjb3VudHMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHMoKTogUHJvbWlzZTxBY2NvdW50Q29uZmlnW10+IHtcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHMnKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50cyhhOiBBY2NvdW50Q29uZmlnW10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50cycsIGEpO1xufVxuXG4vLyAtLS0gQ29ubmVjdGlvbiBzdGF0ZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25uZWN0aW9uKCk6IFByb21pc2U8Q29ubmVjdGlvblN0YXRlPiB7XG4gIGNvbnN0IGMgPSBhd2FpdCBnZXRSYXcoJ2Nvbm5lY3Rpb24nKTtcbiAgLy8gQmFja2ZpbGwgZmllbGRzIGFkZGVkIGFmdGVyIHRoZSB1c2VyJ3Mgc3RvcmFnZSB3YXMgd3JpdHRlbi5cbiAgaWYgKGMuZGVmYXVsdEJyYW5jaCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIHsgLi4uYywgZGVmYXVsdEJyYW5jaDogbnVsbCB9O1xuICB9XG4gIHJldHVybiBjO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xufVxuXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ2NvdW50ZXJzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xuICAgIHRvZGF5Q291bnQ6IDAsXG4gICAgdG9kYXlEYXRlOiB0b2RheUlTTygpLFxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXG4gICAgYnVmZmVyZWRDb3VudDogMCxcbiAgfTtcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcbiAgICBjdXIudG9kYXlEYXRlID0gdG9kYXlJU08oKTtcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XG4gIH1cbiAgY29uc3QgbmV4dDogQWNjb3VudENvdW50ZXIgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRCdWZmZXJlZENvdW50KGhhbmRsZTogc3RyaW5nLCBjb3VudDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcbn1cblxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj4+IHtcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgcmV0dXJuIGFsbFtoYW5kbGVdID8/IG51bGw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcsIGJ1ZjogUnVuQnVmZmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYWxsW2hhbmRsZV0gPSBidWY7XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcbn1cblxuLy8gLS0tIEFjdGl2aXR5IHRhaWwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY3Rpdml0eScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwZW5kQWN0aXZpdHkoZXY6IExvZ0V2ZW50KTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XG4gIGN1ci51bnNoaWZ0KGV2KTtcbiAgaWYgKGN1ci5sZW5ndGggPiBBQ1RJVklUWV9UQUlMX01BWCkgY3VyLmxlbmd0aCA9IEFDVElWSVRZX1RBSUxfTUFYO1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcbiAgcmV0dXJuIGN1cjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBbXSk7XG59XG5cbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbn1cbiIsICJpbXBvcnQgeyBhcHBlbmRBY3Rpdml0eSB9IGZyb20gJy4vc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5sZXQgYnJvYWRjYXN0OiAoKGV2OiBMb2dFdmVudCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldEJyb2FkY2FzdGVyKGZuOiAoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKTogdm9pZCB7XG4gIGJyb2FkY2FzdCA9IGZuO1xufVxuXG5mdW5jdGlvbiBub3dJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBldjogTG9nRXZlbnQgPSB7IHRzOiBub3dJU08oKSwgbGV2ZWwsIG1zZywgY29udGV4dDogcmVkYWN0KGNvbnRleHQpIH07XG4gIC8vIENvbnNvbGUgZm9yIGRldnRvb2xzLlxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xuICBpZiAobGV2ZWwgPT09ICdlcnJvcicpIGNvbnNvbGUuZXJyb3IobGluZSwgZXYuY29udGV4dCk7XG4gIGVsc2UgaWYgKGxldmVsID09PSAnd2FybicpIGNvbnNvbGUud2FybihsaW5lLCBldi5jb250ZXh0KTtcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcbiAgLy8gUGVyc2lzdGVudCB0YWlsLlxuICB0cnkge1xuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGZhaWxlZCB0byBhcHBlbmQgYWN0aXZpdHknLCBlcnIpO1xuICB9XG4gIC8vIExpdmUgYnJvYWRjYXN0IChlLmcuIHRvIHNpZGViYXIpLlxuICB0cnkge1xuICAgIGJyb2FkY2FzdD8uKGV2KTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gU2lkZWJhciBtYXkgbm90IGJlIG9wZW47IHRoYXQncyBmaW5lLlxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCdpbmZvJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCd3YXJuJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gZW1pdCgnZXJyb3InLCBtc2csIGNvbnRleHQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmVFcnJvcihlcnI6IHVua25vd24pOiB7IG1lc3NhZ2U6IHN0cmluZzsgc3RhY2s6IHN0cmluZyB8IG51bGwgfSB7XG4gIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcbiAgfVxuICB0cnkge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4geyBtZXNzYWdlOiAnPHVucHJpbnRhYmxlIGVycm9yPicsIHN0YWNrOiBudWxsIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTdHJpcCBhbnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSBQQVQgb3Igb3RoZXIgbG9uZyBzZWNyZXQgZnJvbSBhIGNvbnRleHRcbiAqIG9iamVjdCBiZWZvcmUgcGVyc2lzdGluZyBpdC4gRGVmZW5zaXZlOiBjYWxsZXJzIHNob3VsZCBub3QgbG9nIHRva2VucywgYnV0XG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxuICovXG5mdW5jdGlvbiByZWRhY3QoY3R4OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhjdHgpKSB7XG4gICAgaWYgKGsudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygndG9rZW4nKSB8fCBrLnRvTG93ZXJDYXNlKCkgPT09ICdwYXQnIHx8IGsgPT09ICdhdXRob3JpemF0aW9uJykge1xuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIC9naXRodWJfcGF0X1tBLVphLXowLTlfXXszMCx9Ly50ZXN0KHYpKSB7XG4gICAgICBvdXRba10gPSB2LnJlcGxhY2UoL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dKy9nLCAnZ2l0aHViX3BhdF88cmVkYWN0ZWQ+Jyk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XG4gICAgICBvdXRba10gPSBgJHt2LnNsaWNlKDAsIDQwOTYpfVx1MjAyNjx0cnVuY2F0ZWQ+YDtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0W2tdID0gdjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cbiIsICJpbXBvcnQgeyBkZXNjcmliZUVycm9yIH0gZnJvbSAnLi9sb2dnZXIuanMnO1xuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5jb25zdCBBUElfQkFTRSA9ICdodHRwczovL2FwaS5naXRodWIuY29tJztcbmNvbnN0IFJBV19CQVNFID0gJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZU9wdGlvbnMge1xuICBwYXRoOiBzdHJpbmc7XG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBleHBlY3RlZFNoYT86IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZVJlc3VsdCB7XG4gIHBhdGg6IHN0cmluZztcbiAgc2hhOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xufVxuXG5leHBvcnQgY2xhc3MgR2l0SHViRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIHN0YXR1czogbnVtYmVyO1xuICBib2R5OiB1bmtub3duO1xuICByZXRyaWFibGU6IGJvb2xlYW47XG4gIGNhdGVnb3J5OiAnYXV0aCcgfCAncmF0ZS1saW1pdCcgfCAnY29uZmxpY3QnIHwgJ25vdC1mb3VuZCcgfCAnc2VydmVyJyB8ICduZXR3b3JrJyB8ICd1bmtub3duJztcblxuICBjb25zdHJ1Y3RvcihvcHRzOiB7XG4gICAgc3RhdHVzOiBudW1iZXI7XG4gICAgYm9keTogdW5rbm93bjtcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgcmV0cmlhYmxlOiBib29sZWFuO1xuICAgIGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXTtcbiAgfSkge1xuICAgIHN1cGVyKG9wdHMubWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0dpdEh1YkVycm9yJztcbiAgICB0aGlzLnN0YXR1cyA9IG9wdHMuc3RhdHVzO1xuICAgIHRoaXMuYm9keSA9IG9wdHMuYm9keTtcbiAgICB0aGlzLnJldHJpYWJsZSA9IG9wdHMucmV0cmlhYmxlO1xuICAgIHRoaXMuY2F0ZWdvcnkgPSBvcHRzLmNhdGVnb3J5O1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBHaXRIdWJDbGllbnQge1xuICBwcml2YXRlIHJlYWRvbmx5IHNldHRpbmdzOiBTZXR0aW5ncztcblxuICBjb25zdHJ1Y3RvcihzZXR0aW5nczogU2V0dGluZ3MpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gIH1cblxuICAvKiogUmV0dXJucyB0aGUgYXV0aGVudGljYXRlZCB1c2VyJ3MgbG9naW4uIFRocm93cyBvbiBhdXRoIGZhaWx1cmUuICovXG4gIGFzeW5jIHdob2FtaSgpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICByZXR1cm4gKHJlcyBhcyB7IGxvZ2luPzogc3RyaW5nIH0pLmxvZ2luID8/ICc8dW5rbm93bj4nO1xuICB9XG5cbiAgLyoqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZ2l2ZW4gYnJhbmNoIGV4aXN0cyBvbiB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xuICBhc3luYyBicmFuY2hFeGlzdHMoYnJhbmNoOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICdHRVQnLFxuICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2JyYW5jaGVzLyR7ZW5jb2RlVVJJQ29tcG9uZW50KGJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBmYWxzZTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKiogVmVyaWZpZXMgdGhlIFBBVCBjYW4gc2VlIHRoZSBjb25maWd1cmVkIHJlcG8uICovXG4gIGFzeW5jIHZlcmlmeVJlcG9BY2Nlc3MoKTogUHJvbWlzZTx7IGxvZ2luOiBzdHJpbmc7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH0+IHtcbiAgICBjb25zdCBtZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICBjb25zdCByZXBvID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb31gKTtcbiAgICBjb25zdCByID0gcmVwbyBhcyB7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGxvZ2luOiAobWUgYXMgeyBsb2dpbjogc3RyaW5nIH0pLmxvZ2luLFxuICAgICAgZnVsbF9uYW1lOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRmV0Y2ggYSB0ZXh0IGZpbGUgZnJvbSByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tIGF1dGhlbnRpY2F0ZWQgd2l0aCB0aGVcbiAgICogUEFULiBSZXR1cm5zIG51bGwgaWYgdGhlIGZpbGUgZG9lc24ndCBleGlzdC4gVXNlZCBmb3IgY29uZmlnL2FjY291bnRzLnlhbWwuXG4gICAqL1xuICBhc3luYyBmZXRjaFJhd1RleHQocGF0aEluUmVwbzogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgdXJsID0gYCR7UkFXX0JBU0V9LyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99LyR7dGhpcy5zZXR0aW5ncy5icmFuY2h9LyR7cGF0aEluUmVwb31gO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAgfSxcbiAgICB9KTtcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSByZXR1cm4gbnVsbDtcbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3IocmVzLCBgR0VUIHJhdyAke3BhdGhJblJlcG99YCk7XG4gICAgcmV0dXJuIHJlcy50ZXh0KCk7XG4gIH1cblxuICAvKipcbiAgICogTG9vayB1cCBhbiBleGlzdGluZyBmaWxlJ3MgU0hBIHZpYSB0aGUgQ29udGVudHMgQVBJLCBvciBudWxsIGlmIG5vdCBmb3VuZC5cbiAgICogVXNlZCB3aGVuIHJldHJ5aW5nIGEgUFVUIGFmdGVyIGEgNDIyIHNoYSBtaXNtYXRjaC5cbiAgICovXG4gIGFzeW5jIGdldEZpbGVTaGEocGF0aDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9P3JlZj0ke2VuY29kZVVSSUNvbXBvbmVudCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHIgPSByZXMgYXMgeyBzaGE/OiBzdHJpbmcgfTtcbiAgICAgIHJldHVybiByLnNoYSA/PyBudWxsO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBudWxsO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBQVVQgYSBmaWxlIHRvIHRoZSByZXBvLiBIYW5kbGVzIDQyMiAoc2hhIHJlcXVpcmVkKSBieSByZS1mZXRjaGluZyB0aGVcbiAgICogZXhpc3Rpbmcgc2hhIGFuZCByZXRyeWluZyBvbmNlLiBSZXRyaWVzIG5ldHdvcmsgLyA1eHggLyByYXRlLWxpbWl0IGVycm9yc1xuICAgKiB3aXRoIGV4cG9uZW50aWFsIGJhY2tvZmYgdXAgdG8gbWF4QXR0ZW1wdHMuXG4gICAqL1xuICBhc3luYyBwdXRGaWxlKG9wdHM6IFB1dEZpbGVPcHRpb25zKTogUHJvbWlzZTxQdXRGaWxlUmVzdWx0PiB7XG4gICAgY29uc3QgcGF0aCA9IG9wdHMucGF0aDtcbiAgICBjb25zdCB1cmwgPSBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2NvbnRlbnRzLyR7ZW5jb2RlUGF0aChwYXRoKX1gO1xuICAgIGxldCBzaGE6IHN0cmluZyB8IG51bGwgPSBvcHRzLmV4cGVjdGVkU2hhID8/IG51bGw7XG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xuXG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDE7IGF0dGVtcHQgPD0gbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xuICAgICAgY29uc3QgYm9keTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICAgIG1lc3NhZ2U6IG9wdHMubWVzc2FnZSxcbiAgICAgICAgY29udGVudDogb3B0cy5jb250ZW50QmFzZTY0LFxuICAgICAgICBicmFuY2g6IHRoaXMuc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgfTtcbiAgICAgIGlmIChzaGEpIGJvZHkuc2hhID0gc2hhO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ1BVVCcsIHVybCwgYm9keSk7XG4gICAgICAgIGNvbnN0IG91dCA9IHJlcyBhcyB7IGNvbnRlbnQ6IHsgc2hhOiBzdHJpbmc7IGh0bWxfdXJsOiBzdHJpbmc7IHBhdGg6IHN0cmluZyB9IH07XG4gICAgICAgIHJldHVybiB7IHBhdGg6IG91dC5jb250ZW50LnBhdGgsIHNoYTogb3V0LmNvbnRlbnQuc2hhLCB1cmw6IG91dC5jb250ZW50Lmh0bWxfdXJsIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XG4gICAgICAgIGlmIChlcnIuc3RhdHVzID09PSA0MjIgJiYgIXNoYSkge1xuICAgICAgICAgIC8vIEZpbGUgYWxyZWFkeSBleGlzdHM7IGZldGNoIGl0cyBzaGEgYW5kIHJldHJ5IG9uY2UuXG4gICAgICAgICAgc2hhID0gYXdhaXQgdGhpcy5nZXRGaWxlU2hhKHBhdGgpO1xuICAgICAgICAgIGlmICghc2hhKSB0aHJvdyBlcnI7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFlcnIucmV0cmlhYmxlIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGBwdXRGaWxlOiBleGhhdXN0ZWQgYXR0ZW1wdHMgZm9yICR7cGF0aH1gKTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZmV0Y2hKc29uKG1ldGhvZDogc3RyaW5nLCBwYXRoOiBzdHJpbmcsIGJvZHk/OiB1bmtub3duKTogUHJvbWlzZTx1bmtub3duPiB7XG4gICAgY29uc3QgdXJsID0gcGF0aC5zdGFydHNXaXRoKCdodHRwJykgPyBwYXRoIDogYCR7QVBJX0JBU0V9JHtwYXRofWA7XG4gICAgY29uc3QgaW5pdDogUmVxdWVzdEluaXQgPSB7XG4gICAgICBtZXRob2QsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLnNldHRpbmdzLnBhdH1gLFxuICAgICAgICBBY2NlcHQ6ICdhcHBsaWNhdGlvbi92bmQuZ2l0aHViK2pzb24nLFxuICAgICAgICAnWC1HaXRIdWItQXBpLVZlcnNpb24nOiAnMjAyMi0xMS0yOCcsXG4gICAgICAgIC4uLihib2R5ID8geyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0gOiB7fSksXG4gICAgICB9LFxuICAgICAgLi4uKGJvZHkgPyB7IGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpIH0gOiB7fSksXG4gICAgfTtcbiAgICBsZXQgcmVzOiBSZXNwb25zZTtcbiAgICB0cnkge1xuICAgICAgcmVzID0gYXdhaXQgZmV0Y2godXJsLCBpbml0KTtcbiAgICB9IGNhdGNoIChuZXRFcnIpIHtcbiAgICAgIHRocm93IG5ldyBHaXRIdWJFcnJvcih7XG4gICAgICAgIHN0YXR1czogMCxcbiAgICAgICAgYm9keTogbnVsbCxcbiAgICAgICAgbWVzc2FnZTogYG5ldHdvcms6ICR7ZGVzY3JpYmVFcnJvcihuZXRFcnIpLm1lc3NhZ2V9YCxcbiAgICAgICAgcmV0cmlhYmxlOiB0cnVlLFxuICAgICAgICBjYXRlZ29yeTogJ25ldHdvcmsnLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChyZXMuc3RhdHVzID09PSAyMDQpIHJldHVybiBudWxsO1xuICAgIGxldCBwYXJzZWQ6IHVua25vd24gPSBudWxsO1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgIGlmICh0ZXh0KSB7XG4gICAgICB0cnkge1xuICAgICAgICBwYXJzZWQgPSBKU09OLnBhcnNlKHRleHQpO1xuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIHBhcnNlZCA9IHRleHQ7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghcmVzLm9rKSB0aHJvdyBhd2FpdCB0aGlzLm1ha2VFcnJvckZyb21QYXJzZWQocmVzLCBwYXJzZWQsIGAke21ldGhvZH0gJHtwYXRofWApO1xuICAgIHJldHVybiBwYXJzZWQ7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIG1ha2VFcnJvcihyZXM6IFJlc3BvbnNlLCBsYWJlbDogc3RyaW5nKTogUHJvbWlzZTxHaXRIdWJFcnJvcj4ge1xuICAgIGxldCBwYXJzZWQ6IHVua25vd24gPSBudWxsO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICAgIGlmICh0ZXh0KSBwYXJzZWQgPSBKU09OLnBhcnNlKHRleHQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gaWdub3JlXG4gICAgfVxuICAgIHJldHVybiB0aGlzLm1ha2VFcnJvckZyb21QYXJzZWQocmVzLCBwYXJzZWQsIGxhYmVsKTtcbiAgfVxuXG4gIHByaXZhdGUgbWFrZUVycm9yRnJvbVBhcnNlZChyZXM6IFJlc3BvbnNlLCBib2R5OiB1bmtub3duLCBsYWJlbDogc3RyaW5nKTogR2l0SHViRXJyb3Ige1xuICAgIGNvbnN0IG1zZyA9XG4gICAgICB0eXBlb2YgYm9keSA9PT0gJ29iamVjdCcgJiYgYm9keSAmJiAnbWVzc2FnZScgaW4gYm9keVxuICAgICAgICA/IFN0cmluZygoYm9keSBhcyB7IG1lc3NhZ2U6IHVua25vd24gfSkubWVzc2FnZSlcbiAgICAgICAgOiByZXMuc3RhdHVzVGV4dDtcbiAgICBsZXQgY2F0ZWdvcnk6IEdpdEh1YkVycm9yWydjYXRlZ29yeSddID0gJ3Vua25vd24nO1xuICAgIGxldCByZXRyaWFibGUgPSBmYWxzZTtcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDAxIHx8IHJlcy5zdGF0dXMgPT09IDQwMykge1xuICAgICAgLy8gNDAzIGNhbiBiZSBlaXRoZXIgYXV0aCBvciByYXRlIGxpbWl0OyBjaGVjayBoZWFkZXJzLlxuICAgICAgY29uc3QgcmF0ZSA9IHJlcy5oZWFkZXJzLmdldCgneC1yYXRlbGltaXQtcmVtYWluaW5nJyk7XG4gICAgICBpZiAocmF0ZSA9PT0gJzAnIHx8IC9yYXRlIGxpbWl0L2kudGVzdChtc2cpKSB7XG4gICAgICAgIGNhdGVnb3J5ID0gJ3JhdGUtbGltaXQnO1xuICAgICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2F0ZWdvcnkgPSAnYXV0aCc7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID09PSA0MDQpIHtcbiAgICAgIGNhdGVnb3J5ID0gJ25vdC1mb3VuZCc7XG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID09PSA0MDkgfHwgcmVzLnN0YXR1cyA9PT0gNDIyKSB7XG4gICAgICBjYXRlZ29yeSA9ICdjb25mbGljdCc7XG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID49IDUwMCkge1xuICAgICAgY2F0ZWdvcnkgPSAnc2VydmVyJztcbiAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID09PSA0MjkpIHtcbiAgICAgIGNhdGVnb3J5ID0gJ3JhdGUtbGltaXQnO1xuICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBHaXRIdWJFcnJvcih7XG4gICAgICBzdGF0dXM6IHJlcy5zdGF0dXMsXG4gICAgICBib2R5LFxuICAgICAgbWVzc2FnZTogYCR7bGFiZWx9IFx1MjE5MiAke3Jlcy5zdGF0dXN9OiAke21zZ31gLFxuICAgICAgcmV0cmlhYmxlLFxuICAgICAgY2F0ZWdvcnksXG4gICAgfSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZW5jb2RlUGF0aChwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBFbmNvZGUgc2VnbWVudHMgaW5kaXZpZHVhbGx5IHNvIHNsYXNoZXMgcmVtYWluLlxuICByZXR1cm4gcGF0aC5zcGxpdCgnLycpLm1hcChlbmNvZGVVUklDb21wb25lbnQpLmpvaW4oJy8nKTtcbn1cblxuZnVuY3Rpb24gYmFja29mZk1zKGF0dGVtcHQ6IG51bWJlciwgZXJyOiBHaXRIdWJFcnJvcik6IG51bWJlciB7XG4gIC8vIEV4cG9uZW50aWFsIHdpdGggaml0dGVyOyBidW1wIGhpZ2hlciBmb3IgcmF0ZS1saW1pdCByZXNwb25zZXMuXG4gIGNvbnN0IGJhc2UgPSBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IDUwMDAgOiA1MDA7XG4gIGNvbnN0IGppdHRlciA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDQwMCk7XG4gIHJldHVybiBNYXRoLm1pbig2MF8wMDAsIGJhc2UgKiAyICoqIChhdHRlbXB0IC0gMSkgKyBqaXR0ZXIpO1xufVxuXG5mdW5jdGlvbiBzbGVlcChtczogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocikgPT4gc2V0VGltZW91dChyLCBtcykpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdG9CYXNlNjQoYnl0ZXM6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIGJ5dGVzIGlzIGEgVVRGLTggc3RyaW5nIG9mIEpTT047IGVuY29kZSB0byBiYXNlNjQgdGhlIHNhZmUgd2F5LlxuICBjb25zdCB1dGY4ID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKGJ5dGVzKTtcbiAgbGV0IGJpbiA9ICcnO1xuICBmb3IgKGNvbnN0IGIgb2YgdXRmOCkgYmluICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYik7XG4gIHJldHVybiBidG9hKGJpbik7XG59XG4iLCAiaW1wb3J0IHsgVFdFRVRfVVJMX1BSRUZJWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB0eXBlIHsgQ2Fub25pY2FsVHdlZXQsIE1lZGlhSXRlbSwgVHdlZXRUeXBlLCBVcmxFbnRpdHkgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBOb3JtYWxpemUgR3JhcGhRTCByZXNwb25zZSBwYXlsb2FkcyBmcm9tIFgncyBpbnRlcm5hbCBBUEkgaW50b1xuICogYENhbm9uaWNhbFR3ZWV0YHMuIE1hbnkgZW5kcG9pbnRzIHNoYXJlIGEgc2ltaWxhciB0d2VldCBzaGFwZSBidXQgd3JhcCBpdCBpblxuICogZGlmZmVyZW50IGVudmVsb3BlczsgdGhpcyBtb2R1bGUgd2Fsa3MgdGhlIHN0cnVjdHVyZSBkZWZlbnNpdmVseS5cbiAqXG4gKiBUaGUgcGFyc2VyIGlzIGludGVudGlvbmFsbHkgcGVybWlzc2l2ZTogaXQgd2lsbCBzaWxlbnRseSBza2lwIGVudHJpZXMgaXRcbiAqIGNhbid0IHJlY29nbml6ZSBhcyB0d2VldHMgKGN1cnNvcnMsIGFkcywgZ2FwIGVudHJpZXMsIG1vZHVsZXMgb2Ygb3RoZXJcbiAqIHR3ZWV0cywgdG9tYnN0b25lcykuIEl0IHRocm93cyAqb25seSogd2hlbiBnaXZlbiBhIHBheWxvYWQgaXQgZG9lc24ndCBrbm93XG4gKiBob3cgdG8gd2FsayBhdCBhbGwgXHUyMDE0IHRob3NlIGNhc2VzIGFyZSBjYXVnaHQgYW5kIHF1YXJhbnRpbmVkIHVwc3RyZWFtLlxuICovXG5cbmV4cG9ydCBpbnRlcmZhY2UgTm9ybWFsaXplQ29udGV4dCB7XG4gIGNhcHR1cmVkQXQ6IHN0cmluZztcbiAgcnVuSWQ6IHN0cmluZztcbiAgZW5kcG9pbnQ6IHN0cmluZztcbiAgYWxsb3dlZEhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTm9ybWFsaXplUmVzdWx0IHtcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdO1xuICBvYnNlcnZlZF9pZHM6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplKHBheWxvYWQ6IHVua25vd24sIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IE5vcm1hbGl6ZVJlc3VsdCB7XG4gIGNvbnN0IHJhd1R3ZWV0cyA9IGNvbGxlY3RUd2VldHMocGF5bG9hZCk7XG4gIGNvbnN0IHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSA9IFtdO1xuICBjb25zdCBvYnNlcnZlZDogc3RyaW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCByYXcgb2YgcmF3VHdlZXRzKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHQgPSBidWlsZFR3ZWV0KHJhdywgY3R4KTtcbiAgICAgIGlmICghdCkgY29udGludWU7XG4gICAgICBvYnNlcnZlZC5wdXNoKHQudHdlZXRfaWQpO1xuICAgICAgaWYgKGN0eC5hbGxvd2VkSGFuZGxlcy5zaXplID09PSAwIHx8IGN0eC5hbGxvd2VkSGFuZGxlcy5oYXModC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpKSkge1xuICAgICAgICB0d2VldHMucHVzaCh0KTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIE9uZSBiYWQgZW50cnkgc2hvdWxkbid0IHRha2UgZG93biB0aGUgd2hvbGUgYmF0Y2guXG4gICAgfVxuICB9XG4gIHJldHVybiB7IHR3ZWV0cywgb2JzZXJ2ZWRfaWRzOiBvYnNlcnZlZCB9O1xufVxuXG5mdW5jdGlvbiBjb2xsZWN0VHdlZXRzKG9iajogdW5rbm93bik6IHVua25vd25bXSB7XG4gIC8vIFdhbGsgdGhlIHJlc3BvbnNlIHRyZWUgZ2F0aGVyaW5nIGV2ZXJ5dGhpbmcgdGhhdCBsb29rcyBsaWtlIGEgdHdlZXRcbiAgLy8gcmVzdWx0LiBXZSBsb29rIGZvciBub2RlcyBzaGFwZWQgbGlrZTpcbiAgLy8gICB7IF9fdHlwZW5hbWU/OiAnVHdlZXQnfCdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycsIHJlc3RfaWQsIGxlZ2FjeSB9XG4gIC8vIGFuZCB1bndyYXAgdmlzaWJpbGl0eSB3cmFwcGVycy5cbiAgY29uc3Qgb3V0OiB1bmtub3duW10gPSBbXTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtvYmpdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG5vZGUgPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobm9kZSA9PT0gbnVsbCB8fCBub2RlID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xuICAgIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmIChzZWVuLmhhcyhub2RlIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKG5vZGUgYXMgb2JqZWN0KTtcblxuICAgIGlmIChsb29rc0xpa2VUd2VldChub2RlKSkge1xuICAgICAgb3V0LnB1c2godW53cmFwVHdlZXQobm9kZSkpO1xuICAgIH1cbiAgICBpZiAoQXJyYXkuaXNBcnJheShub2RlKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG5vZGUpIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBsb29rc0xpa2VUd2VldChub2RlOiB1bmtub3duKTogbm9kZSBpcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgY29uc3QgdHlwZW5hbWUgPSBuLl9fdHlwZW5hbWU7XG4gIGlmIChcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0JyB8fFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnIHx8XG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZSdcbiAgKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgLy8gU29tZSBlbnRyaWVzIGxhY2sgX190eXBlbmFtZSBidXQgc3RpbGwgY2FycnkgbGVnYWN5ICsgcmVzdF9pZCArIGNvcmUuXG4gIHJldHVybiB0eXBlb2Ygbi5yZXN0X2lkID09PSAnc3RyaW5nJyAmJiB0eXBlb2Ygbi5sZWdhY3kgPT09ICdvYmplY3QnICYmIG4ubGVnYWN5ICE9PSBudWxsO1xufVxuXG5mdW5jdGlvbiB1bndyYXBUd2VldChub2RlOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgaWYgKG5vZGUuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiB0eXBlb2Ygbm9kZS50d2VldCA9PT0gJ29iamVjdCcpIHtcbiAgICByZXR1cm4gbm9kZS50d2VldCBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgfVxuICByZXR1cm4gbm9kZTtcbn1cblxuZnVuY3Rpb24gYnVpbGRUd2VldChyYXc6IHVua25vd24sIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IENhbm9uaWNhbFR3ZWV0IHwgbnVsbCB7XG4gIGlmICh0eXBlb2YgcmF3ICE9PSAnb2JqZWN0JyB8fCByYXcgPT09IG51bGwpIHJldHVybiBudWxsO1xuICBjb25zdCB0ID0gcmF3IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuXG4gIGlmICh0Ll9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHJlc3RJZCA9IHN0ck9yTnVsbCh0LnJlc3RfaWQpO1xuICBjb25zdCBsZWdhY3kgPSBvYmoodC5sZWdhY3kpO1xuICBpZiAoIXJlc3RJZCB8fCAhbGVnYWN5KSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBjb3JlID0gb2JqKHQuY29yZSk7XG4gIGNvbnN0IHVzZXJSZXN1bHQgPSBvYmoob2JqKGNvcmU/LnVzZXJfcmVzdWx0cyk/LnJlc3VsdCk7XG4gIGNvbnN0IHVzZXJMZWdhY3kgPSBvYmoodXNlclJlc3VsdD8ubGVnYWN5KTtcbiAgY29uc3QgaGFuZGxlID0gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnNjcmVlbl9uYW1lKTtcbiAgY29uc3QgYWNjb3VudElkID0gc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnJlc3RfaWQpID8/IHN0ck9yTnVsbChsZWdhY3kudXNlcl9pZF9zdHIpO1xuICBpZiAoIWhhbmRsZSB8fCAhYWNjb3VudElkKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBub3RlVHdlZXQgPSBvYmoob2JqKG9iaih0Lm5vdGVfdHdlZXQpPy5ub3RlX3R3ZWV0X3Jlc3VsdHMpPy5yZXN1bHQpO1xuICBjb25zdCB0ZXh0RnJvbU5vdGUgPSBzdHJPck51bGwobm90ZVR3ZWV0Py50ZXh0KTtcbiAgY29uc3QgdGV4dEZyb21MZWdhY3kgPSBzdHJPck51bGwobGVnYWN5LmZ1bGxfdGV4dCkgPz8gJyc7XG4gIGNvbnN0IHRleHQgPSB0ZXh0RnJvbU5vdGUgPz8gdGV4dEZyb21MZWdhY3k7XG5cbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKSA/PyB7fTtcbiAgY29uc3QgZW50aXRpZXNGcm9tTm90ZSA9IG9iaihub3RlVHdlZXQ/LmVudGl0eV9zZXQpO1xuICBjb25zdCBoYXNodGFncyA9IGV4dHJhY3RIYXNodGFncyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgbWVudGlvbnMgPSBleHRyYWN0TWVudGlvbnMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IHVybHMgPSBleHRyYWN0VXJscyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgbWVkaWEgPSBleHRyYWN0TWVkaWEobGVnYWN5KTtcblxuICBjb25zdCB0d2VldFR5cGUgPSBjbGFzc2lmeVR3ZWV0VHlwZSh0LCBsZWdhY3kpO1xuXG4gIGNvbnN0IHBvc3RlZEF0ID0gcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwobGVnYWN5LmNyZWF0ZWRfYXQpKTtcbiAgaWYgKCFwb3N0ZWRBdCkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgdmlld3MgPSBvYmoodC52aWV3cyk7XG4gIGNvbnN0IHZpZXdDb3VudCA9IG51bU9yTnVsbCh2aWV3cz8uY291bnQpID8/IG51bU9yTnVsbChzdHJPck51bGwodmlld3M/LmNvdW50KSk7XG5cbiAgY29uc3QgdHdlZXQ6IENhbm9uaWNhbFR3ZWV0ID0ge1xuICAgIHR3ZWV0X2lkOiByZXN0SWQsXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBhY2NvdW50X2lkOiBhY2NvdW50SWQsXG4gICAgcG9zdGVkX2F0OiBwb3N0ZWRBdCxcbiAgICBmaXJzdF9jYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgbGFzdF9zZWVuX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICBkZWxldGlvbl9kZXRlY3RlZF9hdDogbnVsbCxcbiAgICB0d2VldF91cmw6IGAke1RXRUVUX1VSTF9QUkVGSVh9LyR7aGFuZGxlfS9zdGF0dXMvJHtyZXN0SWR9YCxcbiAgICB0d2VldF90eXBlOiB0d2VldFR5cGUsXG4gICAgcmVwbHlfdG9fdHdlZXRfaWQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0ciksXG4gICAgcmVwbHlfdG9fYWNjb3VudDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zY3JlZW5fbmFtZSksXG4gICAgcXVvdGVkX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSxcbiAgICByZXR3ZWV0ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChcbiAgICAgIG9iaihvYmoobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCA/P1xuICAgICAgICAobGVnYWN5IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0clxuICAgICksXG4gICAgdGV4dCxcbiAgICB0ZXh0X3Jlc29sdmVkOiByZXNvbHZlU2hvcnRVcmxzKHRleHQsIHVybHMpLFxuICAgIGxhbmc6IHN0ck9yTnVsbChsZWdhY3kubGFuZyksXG4gICAgaGFzaHRhZ3MsXG4gICAgbWVudGlvbnMsXG4gICAgdXJscyxcbiAgICBtZWRpYSxcbiAgICBsaWtlX2NvdW50OiBudW1Pclplcm8obGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcbiAgICByZXR3ZWV0X2NvdW50OiBudW1Pclplcm8obGVnYWN5LnJldHdlZXRfY291bnQpLFxuICAgIHJlcGx5X2NvdW50OiBudW1Pclplcm8obGVnYWN5LnJlcGx5X2NvdW50KSxcbiAgICBxdW90ZV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5xdW90ZV9jb3VudCksXG4gICAgdmlld19jb3VudDogdmlld0NvdW50LFxuICAgIGJvb2ttYXJrX2NvdW50OiBudW1Pck51bGwobGVnYWN5LmJvb2ttYXJrX2NvdW50KSxcbiAgICBlbmdhZ2VtZW50X2hpc3Rvcnk6IFtcbiAgICAgIHtcbiAgICAgICAgY2FwdHVyZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxuICAgICAgICBsaWtlczogbnVtT3JaZXJvKGxlZ2FjeS5mYXZvcml0ZV9jb3VudCksXG4gICAgICAgIHJldHdlZXRzOiBudW1Pclplcm8obGVnYWN5LnJldHdlZXRfY291bnQpLFxuICAgICAgICByZXBsaWVzOiBudW1Pclplcm8obGVnYWN5LnJlcGx5X2NvdW50KSxcbiAgICAgICAgcXVvdGVzOiBudW1Pclplcm8obGVnYWN5LnF1b3RlX2NvdW50KSxcbiAgICAgICAgdmlld3M6IHZpZXdDb3VudCxcbiAgICAgICAgYm9va21hcmtzOiBudW1Pck51bGwobGVnYWN5LmJvb2ttYXJrX2NvdW50KSxcbiAgICAgIH0sXG4gICAgXSxcbiAgICB3YXliYWNrX3VybDogbnVsbCxcbiAgICB3YXliYWNrX3N1Ym1pdHRlZF9hdDogbnVsbCxcbiAgICBjYXB0dXJlX3NvdXJjZTogJ2V4dGVuc2lvbicsXG4gICAgY2FwdHVyZV9ydW5faWQ6IGN0eC5ydW5JZCxcbiAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgfTtcblxuICByZXR1cm4gdHdlZXQ7XG59XG5cbmZ1bmN0aW9uIGNsYXNzaWZ5VHdlZXRUeXBlKHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVHdlZXRUeXBlIHtcbiAgaWYgKGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX3Jlc3VsdCB8fCBsZWdhY3kucmV0d2VldGVkX3N0YXR1c19pZF9zdHIpIHJldHVybiAncmV0d2VldCc7XG4gIGlmIChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXBseSc7XG4gIGlmIChsZWdhY3kuaXNfcXVvdGVfc3RhdHVzID09PSB0cnVlIHx8IGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdxdW90ZSc7XG4gIGlmICh0Ll9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycpIHtcbiAgICAvLyBwYXNzIHRocm91Z2hcbiAgfVxuICByZXR1cm4gJ29yaWdpbmFsJztcbn1cblxuZnVuY3Rpb24gZXh0cmFjdEhhc2h0YWdzKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZ1tdIHtcbiAgY29uc3QgYXJyID0gZW50aXRpZXMuaGFzaHRhZ3M7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XG4gIHJldHVybiBhcnJcbiAgICAubWFwKChoKSA9PlxuICAgICAgdHlwZW9mIGggPT09ICdvYmplY3QnICYmIGggJiYgJ3RleHQnIGluIGggPyBTdHJpbmcoKGggYXMgeyB0ZXh0OiB1bmtub3duIH0pLnRleHQpIDogbnVsbFxuICAgIClcbiAgICAuZmlsdGVyKChzKTogcyBpcyBzdHJpbmcgPT4gdHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHMubGVuZ3RoID4gMCk7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RNZW50aW9ucyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLnVzZXJfbWVudGlvbnM7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XG4gIHJldHVybiBhcnJcbiAgICAubWFwKCh1KSA9PlxuICAgICAgdHlwZW9mIHUgPT09ICdvYmplY3QnICYmIHUgJiYgJ3NjcmVlbl9uYW1lJyBpbiB1XG4gICAgICAgID8gU3RyaW5nKCh1IGFzIHsgc2NyZWVuX25hbWU6IHVua25vd24gfSkuc2NyZWVuX25hbWUpXG4gICAgICAgIDogbnVsbFxuICAgIClcbiAgICAuZmlsdGVyKChzKTogcyBpcyBzdHJpbmcgPT4gdHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHMubGVuZ3RoID4gMCk7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RVcmxzKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFVybEVudGl0eVtdIHtcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXJscztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgY29uc3Qgb3V0OiBVcmxFbnRpdHlbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHUgb2YgYXJyKSB7XG4gICAgaWYgKHR5cGVvZiB1ICE9PSAnb2JqZWN0JyB8fCB1ID09PSBudWxsKSBjb250aW51ZTtcbiAgICBjb25zdCBvID0gdSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICBjb25zdCBzaG9ydCA9IHN0ck9yTnVsbChvLnVybCk7XG4gICAgY29uc3QgZXhwYW5kZWQgPSBzdHJPck51bGwoby5leHBhbmRlZF91cmwpO1xuICAgIGNvbnN0IGRpc3BsYXkgPSBzdHJPck51bGwoby5kaXNwbGF5X3VybCk7XG4gICAgaWYgKCFzaG9ydCB8fCAhZXhwYW5kZWQpIGNvbnRpbnVlO1xuICAgIG91dC5wdXNoKHsgc2hvcnQsIGV4cGFuZGVkLCBkaXNwbGF5OiBkaXNwbGF5ID8/IGV4cGFuZGVkIH0pO1xuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RNZWRpYShsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogTWVkaWFJdGVtW10ge1xuICBjb25zdCBleHRlbmRlZCA9IG9iaihsZWdhY3kuZXh0ZW5kZWRfZW50aXRpZXMpO1xuICBjb25zdCBmcm9tRXh0ID0gZXh0ZW5kZWQgPyB0b0FycmF5KGV4dGVuZGVkLm1lZGlhKSA6IFtdO1xuICBjb25zdCBmcm9tRW50ID0gdG9BcnJheShvYmoobGVnYWN5LmVudGl0aWVzKT8ubWVkaWEpO1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IG1lcmdlZCA9IFsuLi5mcm9tRXh0LCAuLi5mcm9tRW50XS5maWx0ZXIoKG0pID0+IHtcbiAgICBpZiAodHlwZW9mIG0gIT09ICdvYmplY3QnIHx8IG0gPT09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBpZCA9XG4gICAgICBzdHJPck51bGwoKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLm1lZGlhX2tleSkgPz9cbiAgICAgIHN0ck9yTnVsbCgobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuaWRfc3RyKTtcbiAgICBpZiAoIWlkKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKHNlZW4uaGFzKGlkKSkgcmV0dXJuIGZhbHNlO1xuICAgIHNlZW4uYWRkKGlkKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSk7XG4gIHJldHVybiBtZXJnZWQubWFwKChyYXcpID0+IGJ1aWxkTWVkaWEocmF3IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSk7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkTWVkaWEobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW0ge1xuICBjb25zdCB0eXBlID0gc3RyT3JOdWxsKG0udHlwZSkgYXMgTWVkaWFJdGVtWydtZWRpYV90eXBlJ107XG4gIGNvbnN0IG9yaWdpbmFsID0gcGlja09yaWdpbmFsVXJsKG0sIHR5cGUpO1xuICBjb25zdCBpbmZvID0gb2JqKG0ub3JpZ2luYWxfaW5mbyk7XG4gIGNvbnN0IHZpZGVvSW5mbyA9IG9iaihtLnZpZGVvX2luZm8pO1xuICBjb25zdCBkdXJhdGlvbk1zID0gbnVtT3JOdWxsKHZpZGVvSW5mbz8uZHVyYXRpb25fbWlsbGlzKTtcbiAgY29uc3QgYWx0VGV4dCA9IHN0ck9yTnVsbChtLmV4dF9hbHRfdGV4dCk7XG4gIGNvbnN0IG1lZGlhSWQgPVxuICAgIHN0ck9yTnVsbChtLm1lZGlhX2tleSkgPz9cbiAgICBzdHJPck51bGwobS5pZF9zdHIpID8/XG4gICAgYCR7dHlwZSA/PyAnbWVkaWEnfS0ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIpfWA7XG4gIHJldHVybiB7XG4gICAgbWVkaWFfaWQ6IG1lZGlhSWQsXG4gICAgbWVkaWFfdHlwZTogKHR5cGUgPz8gJ3Bob3RvJykgYXMgTWVkaWFJdGVtWydtZWRpYV90eXBlJ10sXG4gICAgb3JpZ2luYWxfdXJsOiBvcmlnaW5hbCA/PyAnJyxcbiAgICByZWxlYXNlX2Fzc2V0X3VybDogbnVsbCxcbiAgICBzaGEyNTY6IG51bGwsXG4gICAgYnl0ZXM6IG51bGwsXG4gICAgZHVyYXRpb25fc2VjOiBkdXJhdGlvbk1zICE9PSBudWxsID8gZHVyYXRpb25NcyAvIDEwMDAgOiBudWxsLFxuICAgIHdpZHRoOiBudW1Pck51bGwoaW5mbz8ud2lkdGgpLFxuICAgIGhlaWdodDogbnVtT3JOdWxsKGluZm8/LmhlaWdodCksXG4gICAgYWx0X3RleHQ6IGFsdFRleHQsXG4gICAgYXJjaGl2ZV9zdGF0dXM6ICdwZW5kaW5nJyxcbiAgICBhcmNoaXZlX2F0dGVtcHRzOiAwLFxuICAgIGxhc3RfYXR0ZW1wdF9hdDogbnVsbCxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcGlja09yaWdpbmFsVXJsKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCB0eXBlOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICh0eXBlID09PSAncGhvdG8nKSByZXR1cm4gc3RyT3JOdWxsKG0ubWVkaWFfdXJsX2h0dHBzKSA/PyBzdHJPck51bGwobS5tZWRpYV91cmwpO1xuICBjb25zdCB2YXJpYW50cyA9IHRvQXJyYXkob2JqKG0udmlkZW9faW5mbyk/LnZhcmlhbnRzKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPltdO1xuICBpZiAodmFyaWFudHMubGVuZ3RoID09PSAwKSByZXR1cm4gc3RyT3JOdWxsKG0ubWVkaWFfdXJsX2h0dHBzKTtcbiAgLy8gSGlnaGVzdC1iaXRyYXRlIG1wNC5cbiAgbGV0IGJlc3Q6IHsgdXJsOiBzdHJpbmc7IGJpdHJhdGU6IG51bWJlciB9IHwgbnVsbCA9IG51bGw7XG4gIGZvciAoY29uc3QgdiBvZiB2YXJpYW50cykge1xuICAgIGNvbnN0IGN0ID0gc3RyT3JOdWxsKHYuY29udGVudF90eXBlKTtcbiAgICBjb25zdCB1cmwgPSBzdHJPck51bGwodi51cmwpO1xuICAgIGlmICghdXJsKSBjb250aW51ZTtcbiAgICBpZiAoY3QgPT09ICd2aWRlby9tcDQnKSB7XG4gICAgICBjb25zdCBiciA9IG51bU9yTnVsbCh2LmJpdHJhdGUpID8/IDA7XG4gICAgICBpZiAoIWJlc3QgfHwgYnIgPiBiZXN0LmJpdHJhdGUpIGJlc3QgPSB7IHVybCwgYml0cmF0ZTogYnIgfTtcbiAgICB9IGVsc2UgaWYgKCFiZXN0KSB7XG4gICAgICAvLyBGYWxsYmFjayB0byBhbnkgdmFyaWFudCBpZiBubyBtcDQgZm91bmQuXG4gICAgICBiZXN0ID0geyB1cmwsIGJpdHJhdGU6IDAgfTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGJlc3Q/LnVybCA/PyBudWxsO1xufVxuXG5mdW5jdGlvbiByZXNvbHZlU2hvcnRVcmxzKHRleHQ6IHN0cmluZywgdXJsczogVXJsRW50aXR5W10pOiBzdHJpbmcge1xuICBpZiAodXJscy5sZW5ndGggPT09IDApIHJldHVybiB0ZXh0O1xuICBsZXQgb3V0ID0gdGV4dDtcbiAgZm9yIChjb25zdCB1IG9mIHVybHMpIG91dCA9IG91dC5zcGxpdCh1LnNob3J0KS5qb2luKHUuZXhwYW5kZWQpO1xuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBwYXJzZVR3aXR0ZXJEYXRlKHM6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKCFzKSByZXR1cm4gbnVsbDtcbiAgLy8gVHdpdHRlciBzaGlwcyBkYXRlcyBsaWtlIFwiTW9uIEFwciAxMiAxNDoyMzowMSArMDAwMCAyMDI1XCIuXG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShzKTtcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBudWxsO1xuICByZXR1cm4gZC50b0lTT1N0cmluZygpO1xufVxuXG5mdW5jdGlvbiBzdHJPck51bGwodjogdW5rbm93bik6IHN0cmluZyB8IG51bGwge1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCA/IHYgOiBudWxsO1xufVxuZnVuY3Rpb24gbnVtT3JOdWxsKHY6IHVua25vd24pOiBudW1iZXIgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyAmJiBOdW1iZXIuaXNGaW5pdGUodikpIHJldHVybiB2O1xuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG4gPSBOdW1iZXIodik7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShuKSkgcmV0dXJuIG47XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBudW1Pclplcm8odjogdW5rbm93bik6IG51bWJlciB7XG4gIHJldHVybiBudW1Pck51bGwodikgPz8gMDtcbn1cbmZ1bmN0aW9uIG9iaih2OiB1bmtub3duKTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsIHtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnb2JqZWN0JyAmJiB2ICE9PSBudWxsICYmICFBcnJheS5pc0FycmF5KHYpXG4gICAgPyAodiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilcbiAgICA6IG51bGw7XG59XG5mdW5jdGlvbiB0b0FycmF5KHY6IHVua25vd24pOiB1bmtub3duW10ge1xuICByZXR1cm4gQXJyYXkuaXNBcnJheSh2KSA/IHYgOiBbXTtcbn1cbiIsICIvKipcbiAqIExpZ2h0d2VpZ2h0IFVMSUQtbGlrZSBpZCBnZW5lcmF0b3I6IDI2LWNoYXJhY3RlciBDcm9ja2ZvcmQgYmFzZTMyIHN0cmluZ1xuICogb2YgKHRpbWVzdGFtcF9tcyB8fCByYW5kb21uZXNzKS4gR29vZCBlbm91Z2ggZm9yIHJ1biBpZGVudGlmaWVycyB3aXRob3V0XG4gKiBwdWxsaW5nIGluIGEgcmVhbCBVTElEIGRlcGVuZGVuY3kuXG4gKi9cblxuY29uc3QgQUxQSEFCRVQgPSAnMDEyMzQ1Njc4OUFCQ0RFRkdISktNTlBRUlNUVldYWVonOyAvLyBDcm9ja2ZvcmRcblxuZXhwb3J0IGZ1bmN0aW9uIG5ld1J1bklkKCk6IHN0cmluZyB7XG4gIGNvbnN0IHRzID0gRGF0ZS5ub3coKTtcbiAgbGV0IHRzUGFydCA9ICcnO1xuICBsZXQgdCA9IHRzO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDEwOyBpKyspIHtcbiAgICB0c1BhcnQgPSAoQUxQSEFCRVRbdCAlIDMyXSA/PyAnMCcpICsgdHNQYXJ0O1xuICAgIHQgPSBNYXRoLmZsb29yKHQgLyAzMik7XG4gIH1cbiAgY29uc3QgcmFuZCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTApKTtcbiAgbGV0IHJhbmRQYXJ0ID0gJyc7XG4gIGZvciAoY29uc3QgYiBvZiByYW5kKSByYW5kUGFydCArPSBBTFBIQUJFVFtiICUgMzJdID8/ICcwJztcbiAgcmV0dXJuIHRzUGFydCArIHJhbmRQYXJ0O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2hvcnRSdW5JZChpZDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIGlkLnNsaWNlKC04KTtcbn1cbiIsICJpbXBvcnQgdHlwZSB7IEFjY291bnRDb25maWcgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBNaW5pbWFsIHBhcnNlciBmb3IgdGhlIHN0cmljdCBzaGFwZSB1c2VkIGJ5IGBjb25maWcvYWNjb3VudHMueWFtbGA6XG4gKlxuICogICBhY2NvdW50czpcbiAqICAgICAtIGhhbmRsZTogREhTZ292XG4gKiAgICAgICBsYWJlbDogRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eVxuICpcbiAqIFdlIGRlbGliZXJhdGVseSBkb24ndCBwdWxsIGluIGEgZnVsbCBZQU1MIGxpYnJhcnkgXHUyMDE0IHdlIGNvbnRyb2wgYm90aCBlbmRzIG9mXG4gKiB0aGlzIGZpbGUsIGFuZCBhIDUwLWxpbmUgcGFyc2VyIGlzIGVhc2llciB0byBhdWRpdCB0aGFuIHRoZSBhbHRlcm5hdGl2ZXMuXG4gKiBVbmtub3duIGtleXMgYW5kIGNvbW1lbnRzIGFyZSB0b2xlcmF0ZWQ7IG1hbGZvcm1lZCBsaW5lcyBhcmUgc2tpcHBlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQWNjb3VudHNZYW1sKHRleHQ6IHN0cmluZyk6IEFjY291bnRDb25maWdbXSB7XG4gIGNvbnN0IGFjY291bnRzOiBBY2NvdW50Q29uZmlnW10gPSBbXTtcbiAgbGV0IGN1cnJlbnQ6IFBhcnRpYWw8QWNjb3VudENvbmZpZz4gPSB7fTtcbiAgbGV0IGluQWNjb3VudHMgPSBmYWxzZTtcbiAgZm9yIChjb25zdCByYXdMaW5lIG9mIHRleHQuc3BsaXQoJ1xcbicpKSB7XG4gICAgY29uc3QgbGluZSA9IHN0cmlwQ29tbWVudHMocmF3TGluZSk7XG4gICAgaWYgKGxpbmUudHJpbSgpID09PSAnJykgY29udGludWU7XG4gICAgaWYgKC9eYWNjb3VudHNcXHMqOi8udGVzdChsaW5lKSkge1xuICAgICAgaW5BY2NvdW50cyA9IHRydWU7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKCFpbkFjY291bnRzKSBjb250aW51ZTtcblxuICAgIGNvbnN0IGl0ZW1NYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqLVxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChpdGVtTWF0Y2gpIHtcbiAgICAgIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSBhY2NvdW50cy5wdXNoKGN1cnJlbnQgYXMgQWNjb3VudENvbmZpZyk7XG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaXRlbU1hdGNoWzFdID8/ICcnKSB9O1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IGhhbmRsZU9ubHkgPSBsaW5lLm1hdGNoKC9eXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGhhbmRsZU9ubHkgJiYgIWxpbmUuaW5jbHVkZXMoJy0nKSkge1xuICAgICAgaWYgKGN1cnJlbnQuaGFuZGxlICYmIGN1cnJlbnQubGFiZWwpIGFjY291bnRzLnB1c2goY3VycmVudCBhcyBBY2NvdW50Q29uZmlnKTtcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShoYW5kbGVPbmx5WzFdID8/ICcnKSB9O1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IGxhYmVsTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmxhYmVsXFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAobGFiZWxNYXRjaCAmJiBjdXJyZW50LmhhbmRsZSkge1xuICAgICAgY3VycmVudC5sYWJlbCA9IHVucXVvdGUobGFiZWxNYXRjaFsxXSA/PyAnJyk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gIH1cbiAgaWYgKGN1cnJlbnQuaGFuZGxlICYmIGN1cnJlbnQubGFiZWwpIGFjY291bnRzLnB1c2goY3VycmVudCBhcyBBY2NvdW50Q29uZmlnKTtcbiAgcmV0dXJuIGFjY291bnRzLmZpbHRlcigoYSkgPT4gYS5oYW5kbGUubGVuZ3RoID4gMCk7XG59XG5cbmZ1bmN0aW9uIHN0cmlwQ29tbWVudHMobGluZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gTmFpdmUgYnV0IGFkZXF1YXRlIGZvciBvdXIgZm9ybWF0OiBzdHJpcCBldmVyeXRoaW5nIGFmdGVyIGEgYCNgIHRoYXQgaXNuJ3RcbiAgLy8gaW5zaWRlIHF1b3Rlcy4gT3VyIGNvbmZpZyBuZXZlciB1c2VzIGlubGluZSBzdHJpbmdzIHdpdGggYCNgLlxuICBjb25zdCBpZHggPSBsaW5lLmluZGV4T2YoJyMnKTtcbiAgcmV0dXJuIGlkeCA9PT0gLTEgPyBsaW5lIDogbGluZS5zbGljZSgwLCBpZHgpO1xufVxuXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IHRyaW1tZWQgPSBzLnRyaW0oKTtcbiAgaWYgKFxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoJ1wiJykgJiYgdHJpbW1lZC5lbmRzV2l0aCgnXCInKSkgfHxcbiAgICAodHJpbW1lZC5zdGFydHNXaXRoKFwiJ1wiKSAmJiB0cmltbWVkLmVuZHNXaXRoKFwiJ1wiKSlcbiAgKSB7XG4gICAgcmV0dXJuIHRyaW1tZWQuc2xpY2UoMSwgLTEpO1xuICB9XG4gIHJldHVybiB0cmltbWVkO1xufVxuIiwgIi8qKlxuICogYmFja2dyb3VuZC50cyBcdTIwMTQgZXh0ZW5zaW9uIHNlcnZpY2Ugd29ya2VyLlxuICpcbiAqIE93bnMgdGhlIGNhcHR1cmUgcGlwZWxpbmU6IHJlY2VpdmVzIGBncmFwaHFsLWNhcHR1cmVgIG1lc3NhZ2VzIGZyb20gdGhlXG4gKiBjb250ZW50IHNjcmlwdCwgbm9ybWFsaXplcyB0aGVtLCBhY2N1bXVsYXRlcyBwZXItaGFuZGxlIHJ1biBidWZmZXJzIGluXG4gKiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgYW5kIGNvbW1pdHMgdGhlbSB0byB0aGUgY29uZmlndXJlZCBHaXRIdWIgcmVwb1xuICogdmlhIHRoZSBDb250ZW50cyBBUEkuXG4gKlxuICogU2VydmljZSB3b3JrZXJzIGluIE1WMyBtYXkgYmUgZXZpY3RlZCBhdCBhbnkgdGltZSwgc28gYWxsIGNyaXRpY2FsIHN0YXRlXG4gKiBsaXZlcyBpbiBzdG9yYWdlIChuZXZlciBtb2R1bGUtc2NvcGUpLiBPbiBldmVyeSB3YWtlIHdlIHJlLWRlcml2ZSB3aGF0IHdlXG4gKiBuZWVkOyBwZW5kaW5nIGZsdXNoZXMgYXJlIGRyaXZlbiBieSBgYnJvd3Nlci5hbGFybXNgIHJhdGhlciB0aGFuIHRpbWVycy5cbiAqL1xuXG5pbXBvcnQge1xuICBGQUxMQkFDS19BQ0NPVU5UUyxcbiAgRkxVU0hfQUxBUk1fTUlOVVRFUyxcbiAgRkxVU0hfSURMRV9NUyxcbiAgRkxVU0hfVFdFRVRfVEhSRVNIT0xELFxuICBQUk9GSUxFX0VORFBPSU5UUyxcbiAgVFdFRVRfRU5EUE9JTlRTLFxuICBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyxcbn0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcbmltcG9ydCB7IEdpdEh1YkNsaWVudCwgR2l0SHViRXJyb3IsIHRvQmFzZTY0IH0gZnJvbSAnLi9saWIvZ2l0aHViLmpzJztcbmltcG9ydCB7IGRlc2NyaWJlRXJyb3IsIGVycm9yIGFzIGxvZ0VyciwgaW5mbywgc2V0QnJvYWRjYXN0ZXIsIHdhcm4gfSBmcm9tICcuL2xpYi9sb2dnZXIuanMnO1xuaW1wb3J0IHsgbm9ybWFsaXplIH0gZnJvbSAnLi9saWIvbm9ybWFsaXplLmpzJztcbmltcG9ydCB7IG5ld1J1bklkLCBzaG9ydFJ1bklkIH0gZnJvbSAnLi9saWIvcnVuaWRzLmpzJztcbmltcG9ydCB7XG4gIGJ1bXBDb3VudGVyLFxuICBjbGVhckFjdGl2aXR5LFxuICBjbGVhckFsbCxcbiAgY2xlYXJSdW5CdWZmZXIsXG4gIGdldEFjY291bnRzLFxuICBnZXRBY3Rpdml0eSxcbiAgZ2V0Q29ubmVjdGlvbixcbiAgZ2V0Q291bnRlcnMsXG4gIGdldFJ1bkJ1ZmZlcixcbiAgZ2V0UnVuQnVmZmVycyxcbiAgZ2V0U2V0dGluZ3MsXG4gIHNldEFjY291bnRzLFxuICBzZXRCdWZmZXJlZENvdW50LFxuICBzZXRDb25uZWN0aW9uLFxuICBzZXRSdW5CdWZmZXIsXG4gIHR5cGUgUnVuQnVmZmVyLFxuICB1cGRhdGVTZXR0aW5ncyxcbn0gZnJvbSAnLi9saWIvc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDYXB0dXJlUGF5bG9hZCxcbiAgQ29ubmVjdGlvblN0YXRlLFxuICBFeHRlbnNpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFF1YXJhbnRpbmVQYXlsb2FkLFxuICBSdW50aW1lTWVzc2FnZSxcbiAgU2VlblBheWxvYWQsXG4gIFNldHRpbmdzLFxufSBmcm9tICcuL2xpYi90eXBlcy5qcyc7XG5pbXBvcnQgeyBwYXJzZUFjY291bnRzWWFtbCB9IGZyb20gJy4vbGliL3lhbWwuanMnO1xuXG5jb25zdCBFWFRfVkVSU0lPTiA9IGJyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb247XG5cbnNldEJyb2FkY2FzdGVyKChldjogTG9nRXZlbnQpID0+IHtcbiAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2xvZy1ldmVudCcsIGV2ZW50OiBldiB9KS5jYXRjaCgoKSA9PiB7fSk7XG59KTtcblxuLy8gLS0tIFdha2UgaGFuZGxlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYnJvd3Nlci5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIGluc3RhbGxlZCcsIHsgdmVyc2lvbjogRVhUX1ZFUlNJT04gfSk7XG4gIGF3YWl0IG9uV2FrZSgnaW5zdGFsbCcpO1xufSk7XG5cbmJyb3dzZXIucnVudGltZS5vblN0YXJ0dXAuYWRkTGlzdGVuZXIoKCkgPT4ge1xuICB2b2lkIG9uV2FrZSgnc3RhcnR1cCcpO1xufSk7XG5cbi8vIEZvcmNlIGF0IGxlYXN0IG9uZSB3YWtlIHRvIHJlZ2lzdGVyIGFsYXJtcyAvIHZlcmlmeSBjb25uZWN0aW9uLlxudm9pZCBvbldha2UoJ21vZHVsZS1sb2FkJyk7XG5cbmFzeW5jIGZ1bmN0aW9uIG9uV2FrZShyZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGF3YWl0IGVuc3VyZUFsYXJtcygpO1xuICAgIGF3YWl0IGZsdXNoT3JwaGFuZWRCdWZmZXJzSWZTdGFsZSgpO1xuICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgICBpZiAoc2V0dGluZ3MucGF0ICYmIHNldHRpbmdzLm93bmVyICYmIHNldHRpbmdzLnJlcG8pIHtcbiAgICAgIGF3YWl0IHZlcmlmeUNvbm5lY3Rpb24oZmFsc2UpO1xuICAgICAgYXdhaXQgcmVmcmVzaEFjY291bnRzTGlzdChmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXM6ICdub3QtY29uZmlndXJlZCcsXG4gICAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBhd2FrZTsgc2V0dGluZ3MgaW5jb21wbGV0ZScsIHsgcmVhc29uIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgbG9nRXJyKCd3YWtlIGZhaWxlZCcsIHsgcmVhc29uLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQWxhcm1zKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignZmx1c2gtc3dlZXAnKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3ZlcmlmeS1jb25uZWN0aW9uJyk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgnZmx1c2gtc3dlZXAnLCB7IHBlcmlvZEluTWludXRlczogRkxVU0hfQUxBUk1fTUlOVVRFUyB9KTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY3JlYXRlKCd2ZXJpZnktY29ubmVjdGlvbicsIHtcbiAgICBwZXJpb2RJbk1pbnV0ZXM6IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TIC8gNjBfMDAwLFxuICB9KTtcbn1cblxuYnJvd3Nlci5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcigoYWxhcm0pID0+IHtcbiAgaWYgKGFsYXJtLm5hbWUgPT09ICdmbHVzaC1zd2VlcCcpIHtcbiAgICB2b2lkIGZsdXNoSWRsZUJ1ZmZlcnMoKTtcbiAgfSBlbHNlIGlmIChhbGFybS5uYW1lID09PSAndmVyaWZ5LWNvbm5lY3Rpb24nKSB7XG4gICAgdm9pZCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgfVxufSk7XG5cbi8vIC0tLSBUb29sYmFyIGFjdGlvbjogdG9nZ2xlIHRoZSBzaWRlYmFyIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmlmIChicm93c2VyLmFjdGlvbj8ub25DbGlja2VkKSB7XG4gIGJyb3dzZXIuYWN0aW9uLm9uQ2xpY2tlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2lkZWJhckFjdGlvbi50b2dnbGUoKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIC8vIEZhbGxiYWNrOiBvcGVuIG9wdGlvbnMgaWYgc2lkZWJhciBjYW4ndCBiZSB0b2dnbGVkLlxuICAgICAgYXdhaXQgd2Fybignc2lkZWJhciB0b2dnbGUgZmFpbGVkOyBvcGVuaW5nIG9wdGlvbnMnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgICAgYXdhaXQgYnJvd3Nlci5ydW50aW1lLm9wZW5PcHRpb25zUGFnZSgpO1xuICAgIH1cbiAgfSk7XG59XG5cbi8vIC0tLSBSdW50aW1lIG1lc3NhZ2UgZGlzcGF0Y2ggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiB1bmtub3duLCBfc2VuZGVyKSA9PiB7XG4gIGlmICghaXNSdW50aW1lTWVzc2FnZShtc2cpKSByZXR1cm4gdW5kZWZpbmVkO1xuICByZXR1cm4gaGFuZGxlTWVzc2FnZShtc2cpLmNhdGNoKChlcnIpID0+IHtcbiAgICB2b2lkIGxvZ0VycignbWVzc2FnZSBoYW5kbGVyIGZhaWxlZCcsIHsgdHlwZTogbXNnLnR5cGUsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgICB0aHJvdyBlcnI7XG4gIH0pO1xufSk7XG5cbmZ1bmN0aW9uIGlzUnVudGltZU1lc3NhZ2UobTogdW5rbm93bik6IG0gaXMgUnVudGltZU1lc3NhZ2Uge1xuICByZXR1cm4gISFtICYmIHR5cGVvZiBtID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgKG0gYXMgeyB0eXBlPzogdW5rbm93biB9KS50eXBlID09PSAnc3RyaW5nJztcbn1cblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlTWVzc2FnZShtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTx1bmtub3duPiB7XG4gIHN3aXRjaCAobXNnLnR5cGUpIHtcbiAgICBjYXNlICdncmFwaHFsLWNhcHR1cmUnOlxuICAgICAgYXdhaXQgb25HcmFwaHFsQ2FwdHVyZShtc2cuZW5kcG9pbnQsIG1zZy51cmwsIG1zZy5yZXNwb25zZSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2NvbnRlbnQtYWxpdmUnOlxuICAgICAgYXdhaXQgaW5mbygnY29udGVudCBzY3JpcHQgYWxpdmUgb24gcGFnZScsIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdwYWdlLWhvb2stYWN0aXZlJzpcbiAgICAgIGF3YWl0IGluZm8oJ3BhZ2UgaG9vayBwYXRjaGVkIGZldGNoL1hIUicsIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdsb2ctY29udGVudC1ldmVudCc6XG4gICAgICBpZiAobXNnLmxldmVsID09PSAnd2FybicpIHtcbiAgICAgICAgYXdhaXQgd2Fybihtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH0gZWxzZSBpZiAobXNnLmxldmVsID09PSAnZXJyb3InKSB7XG4gICAgICAgIGF3YWl0IGxvZ0Vycihtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGF3YWl0IGluZm8obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2dldC1zdGF0ZSc6XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhcHR1cmUtbm93JzpcbiAgICAgIGF3YWl0IGNhcHR1cmVOb3cobXNnLmhhbmRsZSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhcHR1cmUtYWxsJzpcbiAgICAgIGF3YWl0IGNhcHR1cmVBbGwoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnZmx1c2gtYWxsJzpcbiAgICAgIGF3YWl0IGZsdXNoQWxsKCd1c2VyJyk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2ZsdXNoLWhhbmRsZSc6XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShtc2cuaGFuZGxlLCAndXNlcicpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtYXV0by1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b0NhcHR1cmU6IG1zZy5vbiB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2F1dG8tY2FwdHVyZSB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdyZWZyZXNoLWFjY291bnRzJzpcbiAgICAgIGF3YWl0IHJlZnJlc2hBY2NvdW50c0xpc3QodHJ1ZSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3ZlcmlmeS1jb25uZWN0aW9uJzpcbiAgICAgIGF3YWl0IHZlcmlmeUNvbm5lY3Rpb24odHJ1ZSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NsZWFyLWFjdGl2aXR5JzpcbiAgICAgIGF3YWl0IGNsZWFyQWN0aXZpdHkoKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnb3Blbi1vcHRpb25zJzpcbiAgICAgIGF3YWl0IGJyb3dzZXIucnVudGltZS5vcGVuT3B0aW9uc1BhZ2UoKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnb3Blbi12aWV3ZXInOiB7XG4gICAgICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgICAgIGNvbnN0IHVybCA9IHZpZXdlclVybChzKTtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ3Vua25vd24gbWVzc2FnZSB0eXBlJyB9O1xuICB9XG59XG5cbi8vIC0tLSBDYXB0dXJlIHBpcGVsaW5lIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIG9uR3JhcGhxbENhcHR1cmUoZW5kcG9pbnQ6IHN0cmluZywgdXJsOiBzdHJpbmcsIHJlc3BvbnNlOiB1bmtub3duKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChQUk9GSUxFX0VORFBPSU5UUy5oYXMoZW5kcG9pbnQpKSByZXR1cm47IC8vIG5vdCB0d2VldC1iZWFyaW5nXG4gIGlmICghVFdFRVRfRU5EUE9JTlRTLmhhcyhlbmRwb2ludCkpIHJldHVybjtcblxuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIC8vIFdlIGRlbGliZXJhdGVseSBkbyBOT1Qgc2hvcnQtY2lyY3VpdCB3aGVuIHRoZSBQQVQgaXMgbWlzc2luZy4gVGhlXG4gIC8vIG5vcm1hbGl6ZSBzdGVwIGlzIGNoZWFwLCB0aGUgYnVmZmVyIHN1cnZpdmVzIHNlcnZpY2Utd29ya2VyIGV2aWN0aW9uLFxuICAvLyBhbmQgb25jZSB0aGUgUEFUIGlzIHNldCB0aGUgbmV4dCBhbGFybSBvciB1c2VyLXRyaWdnZXJlZCBmbHVzaCBjb21taXRzXG4gIC8vIGV2ZXJ5dGhpbmcgd2UndmUgc2Vlbi4gRHJvcHBpbmcgY2FwdHVyZXMgaGVyZSB3YXMgaGlkaW5nIHRoZSB1c2VyJ3NcbiAgLy8gZmlyc3QgYnJvd3Npbmcgc2Vzc2lvbiBlbnRpcmVseS5cblxuICBjb25zdCBhbGxvd2VkID0gbmV3IFNldChhY2NvdW50cy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcbiAgY29uc3QgY2FwdHVyZWRBdCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICBsZXQgbm9ybWFsaXplZDtcbiAgdHJ5IHtcbiAgICBub3JtYWxpemVkID0gbm9ybWFsaXplKHJlc3BvbnNlLCB7XG4gICAgICBjYXB0dXJlZEF0LFxuICAgICAgcnVuSWQ6ICdwZW5kaW5nJyxcbiAgICAgIGVuZHBvaW50LFxuICAgICAgYWxsb3dlZEhhbmRsZXM6IGFsbG93ZWQsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHF1YXJhbnRpbmUoJ25vcm1hbGl6ZS10aHJldycsIGVuZHBvaW50LCB1cmwsIHJlc3BvbnNlLCBlcnIpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAvLyBHcm91cCB0d2VldHMgYnkgYXV0aG9yIGhhbmRsZS5cbiAgY29uc3QgYnlIYW5kbGUgPSBuZXcgTWFwPHN0cmluZywgQ2Fub25pY2FsVHdlZXRbXT4oKTtcbiAgZm9yIChjb25zdCB0IG9mIG5vcm1hbGl6ZWQudHdlZXRzKSB7XG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUpID8/IFtdO1xuICAgIGFyci5wdXNoKHQpO1xuICAgIGJ5SGFuZGxlLnNldCh0LmFjY291bnRfaGFuZGxlLCBhcnIpO1xuICB9XG5cbiAgZm9yIChjb25zdCBbaGFuZGxlLCB0d2VldHNdIG9mIGJ5SGFuZGxlKSB7XG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgdXJsLCBlbmRwb2ludCk7XG4gICAgbGV0IGFkZGVkID0gMDtcbiAgICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgICBjb25zdCBleGlzdGluZyA9IGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF07XG4gICAgICBpZiAoZXhpc3RpbmcpIHtcbiAgICAgICAgLy8gUHJlc2VydmUgZmlyc3RfY2FwdHVyZWRfYXQsIGFwcGVuZCBlbmdhZ2VtZW50IHNuYXBzaG90LCByZWZyZXNoXG4gICAgICAgIC8vIGxhc3Rfc2Vlbl9hdCArIGNvdW50cyAodGhlIGxhdGVzdCBzY3JhcGUgd2lucyBmb3IgY291bnRzKS5cbiAgICAgICAgZXhpc3RpbmcubGFzdF9zZWVuX2F0ID0gY2FwdHVyZWRBdDtcbiAgICAgICAgZXhpc3RpbmcubGlrZV9jb3VudCA9IHQubGlrZV9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmV0d2VldF9jb3VudCA9IHQucmV0d2VldF9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmVwbHlfY291bnQgPSB0LnJlcGx5X2NvdW50O1xuICAgICAgICBleGlzdGluZy5xdW90ZV9jb3VudCA9IHQucXVvdGVfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnZpZXdfY291bnQgPSB0LnZpZXdfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLmJvb2ttYXJrX2NvdW50ID0gdC5ib29rbWFya19jb3VudDtcbiAgICAgICAgY29uc3QgbGFzdCA9IGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeVtleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnkubGVuZ3RoIC0gMV07XG4gICAgICAgIGNvbnN0IHNuYXAgPSB0LmVuZ2FnZW1lbnRfaGlzdG9yeVswXTtcbiAgICAgICAgaWYgKHNuYXAgJiYgKCFsYXN0IHx8IGxhc3QuY2FwdHVyZWRfYXQgIT09IHNuYXAuY2FwdHVyZWRfYXQpKSB7XG4gICAgICAgICAgZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5LnB1c2goc25hcCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHN0YW1wZWQ6IENhbm9uaWNhbFR3ZWV0ID0geyAuLi50LCBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCB9O1xuICAgICAgICBidWYudHdlZXRzX2J5X2lkW3QudHdlZXRfaWRdID0gc3RhbXBlZDtcbiAgICAgICAgYWRkZWQgKz0gMTtcbiAgICAgIH1cbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyh0LnR3ZWV0X2lkKSkge1xuICAgICAgICBidWYudHdlZXRfaWRzX29ic2VydmVkLnB1c2godC50d2VldF9pZCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xuICAgIGJ1Zi5sYXN0X2NhcHR1cmVfYXQgPSBjYXB0dXJlZEF0O1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCk7XG4gICAgaWYgKGFkZGVkID4gMCkge1xuICAgICAgYXdhaXQgaW5mbygnY2FwdHVyZWQgdHdlZXRzJywge1xuICAgICAgICBoYW5kbGUsXG4gICAgICAgIGVuZHBvaW50LFxuICAgICAgICBhZGRlZCxcbiAgICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoID49IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCkge1xuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUoaGFuZGxlLCAndGhyZXNob2xkJyk7XG4gICAgfVxuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZVJ1bkJ1ZmZlcihcbiAgaGFuZGxlOiBzdHJpbmcsXG4gIHRzOiBzdHJpbmcsXG4gIHNvdXJjZVVybDogc3RyaW5nLFxuICBlbmRwb2ludDogc3RyaW5nXG4pOiBQcm9taXNlPFJ1bkJ1ZmZlcj4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRSdW5CdWZmZXIoaGFuZGxlKTtcbiAgaWYgKGN1cikgcmV0dXJuIGN1cjtcbiAgY29uc3QgYnVmOiBSdW5CdWZmZXIgPSB7XG4gICAgcnVuX2lkOiBuZXdSdW5JZCgpLFxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgc3RhcnRlZF9hdDogdHMsXG4gICAgbGFzdF9jYXB0dXJlX2F0OiB0cyxcbiAgICB0d2VldHNfYnlfaWQ6IHt9LFxuICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogW10sXG4gICAgZW5kcG9pbnRzX3NlZW46IFtlbmRwb2ludF0sXG4gICAgc291cmNlX3VybDogc291cmNlVXJsLFxuICB9O1xuICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICBhd2FpdCBpbmZvKCdydW4gc3RhcnRlZCcsIHsgaGFuZGxlLCBydW46IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCkgfSk7XG4gIHJldHVybiBidWY7XG59XG5cbi8vIC0tLSBGbHVzaCBsb2dpYyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSWRsZUJ1ZmZlcnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUoaGFuZGxlLCAnaWRsZScpO1xuICAgIH1cbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIE9uIHdvcmtlciB3YWtlLCBhbnkgYnVmZmVyIG9sZGVyIHRoYW4gdGhlIGlkbGUgdGhyZXNob2xkIGdldHMgYSBjaGFuY2UgdG9cbiAgLy8gY29tbWl0IGltbWVkaWF0ZWx5IFx1MjAxNCB1c2VmdWwgd2hlbiB0aGUgd29ya2VyIHdhcyBldmljdGVkIGJlZm9yZSBpZGxlLWZsdXNoLlxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgYnVmXSBvZiBPYmplY3QuZW50cmllcyhhbGwpKSB7XG4gICAgY29uc3QgbGFzdCA9IERhdGUucGFyc2UoYnVmLmxhc3RfY2FwdHVyZV9hdCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShsYXN0KSAmJiBub3cgLSBsYXN0ID49IEZMVVNIX0lETEVfTVMpIHtcbiAgICAgIGF3YWl0IGZsdXNoSGFuZGxlKGhhbmRsZSwgJ3dha2UnKTtcbiAgICB9XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hBbGwocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhhbGwpKSB7XG4gICAgYXdhaXQgZmx1c2hIYW5kbGUoaGFuZGxlLCByZWFzb24pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlKGhhbmRsZTogc3RyaW5nLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBidWYgPSBhd2FpdCBnZXRSdW5CdWZmZXIoaGFuZGxlKTtcbiAgaWYgKCFidWYpIHJldHVybjtcbiAgY29uc3QgdHdlZXRzID0gT2JqZWN0LnZhbHVlcyhidWYudHdlZXRzX2J5X2lkKTtcbiAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApIHtcbiAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihoYW5kbGUpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHdhcm4oJ2ZsdXNoIGRlZmVycmVkOiBzZXR0aW5ncyBpbmNvbXBsZXRlJywgeyBoYW5kbGUgfSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICBjb25zdCB0cyA9IGlzb0NvbXBhY3QoYnVmLnN0YXJ0ZWRfYXQpO1xuICBjb25zdCBkYXkgPSBidWYuc3RhcnRlZF9hdC5zbGljZSgwLCAxMCk7XG4gIGNvbnN0IHJhd1BhdGggPSBgcmF3LyR7aGFuZGxlfS8ke3RzfS0ke3Nob3J0UnVuSWQoYnVmLnJ1bl9pZCl9Lmpzb25gO1xuICBjb25zdCBzZWVuUGF0aCA9IGBzZWVuLyR7aGFuZGxlfS8ke3RzfS0ke3Nob3J0UnVuSWQoYnVmLnJ1bl9pZCl9Lmpzb25gO1xuXG4gIGNvbnN0IGNhcHR1cmU6IENhcHR1cmVQYXlsb2FkID0ge1xuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgZW5kcG9pbnQ6IGJ1Zi5lbmRwb2ludHNfc2Vlbi5qb2luKCcsJyksXG4gICAgdXNlcl9hZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcbiAgICBzb3VyY2VfdXJsOiBidWYuc291cmNlX3VybCxcbiAgICB0d2VldHMsXG4gIH07XG4gIGNvbnN0IHNlZW46IFNlZW5QYXlsb2FkID0ge1xuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBidWYudHdlZXRfaWRzX29ic2VydmVkLFxuICB9O1xuXG4gIGNvbnN0IGNvbW1pdE1zZyA9IGBjYXB0dXJlOiAke2hhbmRsZX0gJHtkYXl9ICR7dHdlZXRzLmxlbmd0aH0gdHdlZXQke3R3ZWV0cy5sZW5ndGggPT09IDEgPyAnJyA6ICdzJ30gKHJ1biAke3Nob3J0UnVuSWQoYnVmLnJ1bl9pZCl9KWA7XG5cbiAgdHJ5IHtcbiAgICBhd2FpdCBjbGllbnQucHV0RmlsZSh7XG4gICAgICBwYXRoOiByYXdQYXRoLFxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkoY2FwdHVyZSwgbnVsbCwgMikgKyAnXFxuJyksXG4gICAgICBtZXNzYWdlOiBjb21taXRNc2csXG4gICAgfSk7XG4gICAgYXdhaXQgY2xpZW50LnB1dEZpbGUoe1xuICAgICAgcGF0aDogc2VlblBhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShzZWVuLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICAgIG1lc3NhZ2U6IGBzZWVuOiAke2hhbmRsZX0gJHtkYXl9ICR7c2Vlbi50d2VldF9pZHNfb2JzZXJ2ZWQubGVuZ3RofSBpZHMgKHJ1biAke3Nob3J0UnVuSWQoYnVmLnJ1bl9pZCl9KWAsXG4gICAgfSk7XG4gICAgYXdhaXQgY2xlYXJSdW5CdWZmZXIoaGFuZGxlKTtcbiAgICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHtcbiAgICAgIHRvZGF5Q291bnQ6IChhd2FpdCBnZXRDb3VudGVycygpKVtoYW5kbGVdPy50b2RheUNvdW50ID8/IDAsXG4gICAgICB0b2RheURhdGU6IGRheSxcbiAgICAgIGxhc3RDYXB0dXJlQXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICB0b3RhbENvbW1pdHRlZDogKChhd2FpdCBnZXRDb3VudGVycygpKVtoYW5kbGVdPy50b3RhbENvbW1pdHRlZCA/PyAwKSArIHR3ZWV0cy5sZW5ndGgsXG4gICAgICBidWZmZXJlZENvdW50OiAwLFxuICAgIH0pO1xuICAgIGF3YWl0IGluZm8oJ2ZsdXNoIGNvbW1pdHRlZCcsIHtcbiAgICAgIGhhbmRsZSxcbiAgICAgIHJlYXNvbixcbiAgICAgIHR3ZWV0czogdHdlZXRzLmxlbmd0aCxcbiAgICAgIHJ1bjogc2hvcnRSdW5JZChidWYucnVuX2lkKSxcbiAgICAgIHBhdGg6IHJhd1BhdGgsXG4gICAgfSk7XG4gICAge1xuICAgICAgY29uc3QgcHJldiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXM6ICdvaycsXG4gICAgICAgIGxvZ2luOiBwcmV2LmxvZ2luLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IHByZXYuZGVmYXVsdEJyYW5jaCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSB7XG4gICAgICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICAgICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAnYXV0aCdcbiAgICAgICAgICA/ICdhdXRoLWVycm9yJ1xuICAgICAgICAgIDogZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICAgID8gJ3JhdGUtbGltaXRlZCdcbiAgICAgICAgICAgIDogZXJyLmNhdGVnb3J5ID09PSAnbmV0d29yaydcbiAgICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgICAgOiBjb25uLnN0YXR1cztcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXMsXG4gICAgICAgIGxvZ2luOiBjb25uLmxvZ2luLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IGVyci5tZXNzYWdlLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBjb25uLmRlZmF1bHRCcmFuY2gsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGxvZ0VycignZmx1c2ggZmFpbGVkJywge1xuICAgICAgICBoYW5kbGUsXG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgY2F0ZWdvcnk6IGVyci5jYXRlZ29yeSxcbiAgICAgICAgc3RhdHVzOiBlcnIuc3RhdHVzLFxuICAgICAgICBtZXNzYWdlOiBlcnIubWVzc2FnZSxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBsb2dFcnIoJ2ZsdXNoIGZhaWxlZCcsIHsgaGFuZGxlLCByZWFzb24sIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgICB9XG4gICAgLy8gTGVhdmUgYnVmZmVyIGludGFjdCBmb3IgcmV0cnkuXG4gIH0gZmluYWxseSB7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgfVxufVxuXG4vLyAtLS0gQ2FwdHVyZS1ub3cgLyBjYXB0dXJlLWFsbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVOb3coaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gTGFuZCBvbiB0aGUgUmVwbGllcyB0YWIgc28gWCBmZXRjaGVzIHZpYSBVc2VyVHdlZXRzQW5kUmVwbGllcyBcdTIwMTQgdGhhdFxuICAvLyBlbmRwb2ludCByZXR1cm5zIGJvdGggdG9wLWxldmVsIHBvc3RzIGFuZCByZXBsaWVzLCB3aGljaCBpcyB0aGUgc3VwZXJzZXRcbiAgLy8gd2Ugd2FudCBmb3IgdGhlIGFyY2hpdmUuIFRoZSBwbGFpbiBgLzxoYW5kbGU+YCBVUkwgaGl0cyBVc2VyVHdlZXRzLFxuICAvLyB3aGljaCBvbWl0cyByZXBsaWVzLiBUaGUgcGFnZS1ob29rIGludGVyY2VwdHMgZWl0aGVyIGVuZHBvaW50LCBidXRcbiAgLy8gZm9yY2luZyB0aGUgYnJvYWRlciB0YWIgb24gdXNlci1pbml0aWF0ZWQgY2FwdHVyZXMgaXMgdGhlIHJpZ2h0IGRlZmF1bHQuXG4gIGNvbnN0IHRhcmdldFVybCA9IGBodHRwczovL3guY29tLyR7aGFuZGxlfS93aXRoX3JlcGxpZXNgO1xuICBhd2FpdCBpbmZvKCdjYXB0dXJlLW5vdyByZXF1ZXN0ZWQnLCB7IGhhbmRsZSwgdGFiOiAnd2l0aF9yZXBsaWVzJyB9KTtcbiAgaWYgKCEoYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSkpKSB7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIHtcbiAgICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBzdGFydGVkX2F0OiBub3csXG4gICAgICBsYXN0X2NhcHR1cmVfYXQ6IG5vdyxcbiAgICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IFtdLFxuICAgICAgZW5kcG9pbnRzX3NlZW46IFtdLFxuICAgICAgc291cmNlX3VybDogdGFyZ2V0VXJsLFxuICAgIH0pO1xuICB9XG4gIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmw6IHRhcmdldFVybCwgYWN0aXZlOiB0cnVlIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtYWxsIHJlcXVlc3RlZCcsIHsgY291bnQ6IGFjY291bnRzLmxlbmd0aCB9KTtcbiAgZm9yIChjb25zdCBhIG9mIGFjY291bnRzKSB7XG4gICAgYXdhaXQgY2FwdHVyZU5vdyhhLmhhbmRsZSk7XG4gIH1cbn1cblxuLy8gLS0tIFF1YXJhbnRpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gcXVhcmFudGluZShcbiAgcmVhc29uOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHVybDogc3RyaW5nLFxuICByYXc6IHVua25vd24sXG4gIGVycjogdW5rbm93blxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGxvZ0VycigncXVhcmFudGluaW5nIGNhcHR1cmUnLCB7IHJlYXNvbiwgZW5kcG9pbnQsIHVybCwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykgcmV0dXJuO1xuICBjb25zdCBwYXlsb2FkOiBRdWFyYW50aW5lUGF5bG9hZCA9IHtcbiAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgICByZWFzb24sXG4gICAgZW5kcG9pbnQsXG4gICAgY2FwdHVyZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBzb3VyY2VfdXJsOiB1cmwsXG4gICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICByYXcsXG4gIH07XG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChwYXlsb2FkLmNhcHR1cmVkX2F0KTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IHNoYTgoSlNPTi5zdHJpbmdpZnkocGF5bG9hZCkpO1xuICBjb25zdCBwYXRoID0gYHJhdy9fcXVhcmFudGluZS8ke3RzfS0ke2hhc2h9Lmpzb25gO1xuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGF3YWl0IGNsaWVudC5wdXRGaWxlKHtcbiAgICAgIHBhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShwYXlsb2FkLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICAgIG1lc3NhZ2U6IGBxdWFyYW50aW5lOiAke3JlYXNvbn0gJHtlbmRwb2ludH1gLFxuICAgIH0pO1xuICB9IGNhdGNoIChxZXJyKSB7XG4gICAgYXdhaXQgbG9nRXJyKCdxdWFyYW50aW5lIGNvbW1pdCBmYWlsZWQnLCB7IC4uLmRlc2NyaWJlRXJyb3IocWVycikgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gc2hhOChzOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBidWYgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUocyk7XG4gIGNvbnN0IGRpZ2VzdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgYnVmKTtcbiAgY29uc3QgaGV4ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShkaWdlc3QpKVxuICAgIC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG4gICAgLmpvaW4oJycpO1xuICByZXR1cm4gaGV4LnNsaWNlKDAsIDgpO1xufVxuXG4vLyAtLS0gQ29ubmVjdGlvbiB2ZXJpZmljYXRpb24gJiBhY2NvdW50cyBsaXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIHZlcmlmeUNvbm5lY3Rpb24oZm9yY2U6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHtcbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcbiAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlcnJvcjogbnVsbCxcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgfSk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgaWYgKCFmb3JjZSAmJiBjb25uLnN0YXR1cyA9PT0gJ29rJyAmJiBjb25uLmNoZWNrZWRBdCkge1xuICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGNvbm4uY2hlY2tlZEF0KTtcbiAgICBpZiAoYWdlIDwgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMpIHJldHVybjtcbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHIgPSBhd2FpdCBjbGllbnQudmVyaWZ5UmVwb0FjY2VzcygpO1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnb2snLFxuICAgICAgbG9naW46IHIubG9naW4sXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgZGVmYXVsdEJyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICB9KTtcbiAgICBhd2FpdCBpbmZvKCdjb25uZWN0aW9uIHZlcmlmaWVkJywge1xuICAgICAgbG9naW46IHIubG9naW4sXG4gICAgICByZXBvOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgY29uZmlndXJlZF9icmFuY2g6IHNldHRpbmdzLmJyYW5jaCxcbiAgICB9KTtcbiAgICBpZiAoc2V0dGluZ3MuYnJhbmNoICYmIHNldHRpbmdzLmJyYW5jaCAhPT0gci5kZWZhdWx0X2JyYW5jaCkge1xuICAgICAgLy8gVGhlIHVzZXIgbWF5IGhhdmUgaW50ZW50aW9uYWxseSBjaG9zZW4gYSBub24tZGVmYXVsdCBicmFuY2ggKGUuZy5cbiAgICAgIC8vIGZvciB0ZXN0aW5nKSwgYnV0IGlmIHRoZWlyIHBpY2sgZG9lc24ndCBleGlzdCBHaXRIdWIgd2lsbCA0MjIgZXZlcnlcbiAgICAgIC8vIGNvbW1pdC4gUHJvYmUgdGhlIGJyYW5jaCBhbmQgd2FybiBsb3VkbHkgd2hlbiBpdCdzIG1pc3NpbmcgXHUyMDE0IHRoZVxuICAgICAgLy8gdXNlciBjYW4gZWl0aGVyIGNyZWF0ZSBpdCBvciBzd2l0Y2ggYmFjayB0byB0aGUgZGVmYXVsdCBpbiBTZXR0aW5ncy5cbiAgICAgIGNvbnN0IGJyYW5jaE9rID0gYXdhaXQgY2xpZW50LmJyYW5jaEV4aXN0cyhzZXR0aW5ncy5icmFuY2gpO1xuICAgICAgaWYgKCFicmFuY2hPaykge1xuICAgICAgICBhd2FpdCB3YXJuKCdjb25maWd1cmVkIGJyYW5jaCBkb2VzIG5vdCBleGlzdCBvbiByZW1vdGUnLCB7XG4gICAgICAgICAgY29uZmlndXJlZDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgICAgIGZpeDogJ29wZW4gU2V0dGluZ3MgYW5kIGNoYW5nZSBicmFuY2ggdG8gJyArIHIuZGVmYXVsdF9icmFuY2gsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc3QgY2F0ID0gZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgPyBlcnIuY2F0ZWdvcnkgOiAndW5rbm93bic7XG4gICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgIGNhdCA9PT0gJ2F1dGgnXG4gICAgICAgID8gJ2F1dGgtZXJyb3InXG4gICAgICAgIDogY2F0ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgOiBjYXQgPT09ICduZXR3b3JrJ1xuICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgIDogJ2F1dGgtZXJyb3InO1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzLFxuICAgICAgbG9naW46IG51bGwsXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBkZXNjcmliZUVycm9yKGVycikubWVzc2FnZSxcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgfSk7XG4gICAgYXdhaXQgd2FybignY29ubmVjdGlvbiBjaGVjayBmYWlsZWQnLCB7IGNhdGVnb3J5OiBjYXQsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQWNjb3VudHNMaXN0KGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQpIHtcbiAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcbiAgICByZXR1cm47XG4gIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgY2xpZW50LmZldGNoUmF3VGV4dCgnY29uZmlnL2FjY291bnRzLnlhbWwnKTtcbiAgICBpZiAoIXRleHQpIHtcbiAgICAgIGlmIChmb3JjZSkgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBub3QgZm91bmQgaW4gcmVwbzsgdXNpbmcgZmFsbGJhY2snKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBwYXJzZWQgPSBwYXJzZUFjY291bnRzWWFtbCh0ZXh0KTtcbiAgICBpZiAocGFyc2VkLmxlbmd0aCA9PT0gMCkge1xuICAgICAgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBwYXJzZWQgZW1wdHk7IGtlZXBpbmcgZmFsbGJhY2snKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhd2FpdCBzZXRBY2NvdW50cyhwYXJzZWQpO1xuICAgIGlmIChmb3JjZSkgYXdhaXQgaW5mbygnYWNjb3VudHMgbGlzdCByZWZyZXNoZWQnLCB7IGNvdW50OiBwYXJzZWQubGVuZ3RoIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdyZWZyZXNoIGFjY291bnRzIGZhaWxlZDsga2VlcGluZyBjdXJyZW50IGxpc3QnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbi8vIC0tLSBTdGF0ZSBicm9hZGNhc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gYnJvYWRjYXN0U3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgYnVpbGRTdGF0ZSgpO1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIHJldHVybiB7XG4gICAgdmVyc2lvbjogRVhUX1ZFUlNJT04sXG4gICAgc2V0dGluZ3M6IHJlZGFjdFNldHRpbmdzKHNldHRpbmdzKSxcbiAgICBjb25uZWN0aW9uOiBjb25uLFxuICAgIGFjY291bnRzLFxuICAgIGNvdW50ZXJzLFxuICB9O1xufVxuXG5mdW5jdGlvbiByZWRhY3RTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IEV4dGVuc2lvblN0YXRlWydzZXR0aW5ncyddIHtcbiAgcmV0dXJuIHtcbiAgICBvd25lcjogcy5vd25lcixcbiAgICByZXBvOiBzLnJlcG8sXG4gICAgYnJhbmNoOiBzLmJyYW5jaCxcbiAgICBhdXRvQ2FwdHVyZTogcy5hdXRvQ2FwdHVyZSxcbiAgICBjb25maWd1cmVkQXQ6IHMuY29uZmlndXJlZEF0LFxuICAgIHBhdFNldDogcy5wYXQubGVuZ3RoID4gMCxcbiAgICBwYXRTdWZmaXg6IHMucGF0Lmxlbmd0aCA+PSA0ID8gcy5wYXQuc2xpY2UoLTQpIDogJycsXG4gIH07XG59XG5cbmZ1bmN0aW9uIGlzb0NvbXBhY3QoaXNvOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyAyMDI1LTA0LTEyVDE0OjIzOjAxLjAwMFogXHUyMTkyIDIwMjUtMDQtMTJUMTQyMzAxWlxuICBjb25zdCBkID0gbmV3IERhdGUoaXNvKTtcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBpc28ucmVwbGFjZSgvWzouXS9nLCAnJyk7XG4gIGNvbnN0IHBhZCA9IChuOiBudW1iZXIsIHcgPSAyKSA9PiBTdHJpbmcobikucGFkU3RhcnQodywgJzAnKTtcbiAgcmV0dXJuIChcbiAgICBgJHtkLmdldFVUQ0Z1bGxZZWFyKCl9LSR7cGFkKGQuZ2V0VVRDTW9udGgoKSArIDEpfS0ke3BhZChkLmdldFVUQ0RhdGUoKSl9YCArXG4gICAgYFQke3BhZChkLmdldFVUQ0hvdXJzKCkpfSR7cGFkKGQuZ2V0VVRDTWludXRlcygpKX0ke3BhZChkLmdldFVUQ1NlY29uZHMoKSl9WmBcbiAgKTtcbn1cblxuZnVuY3Rpb24gdmlld2VyVXJsKHM6IFNldHRpbmdzKTogc3RyaW5nIHtcbiAgcmV0dXJuIGBodHRwczovLyR7cy5vd25lcn0uZ2l0aHViLmlvLyR7cy5yZXBvfS9gO1xufVxuXG5mdW5jdGlvbiBzaG9ydGVuVXJsKHU6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIEFjdGl2aXR5LXRhaWwgY29udGV4dCBpcyBtb3JlIHVzZWZ1bCB3aXRoIGp1c3QgdGhlIHBhdGg7IGZ1bGwgVVJMcyBiZWNvbWVcbiAgLy8gaGFyZCB0byByZWFkIGF0IHRoZSBzaWRlYmFyJ3Mgd2lkdGguXG4gIHRyeSB7XG4gICAgY29uc3QgcGFyc2VkID0gbmV3IFVSTCh1KTtcbiAgICBjb25zdCBwYXRoID0gcGFyc2VkLnBhdGhuYW1lICsgKHBhcnNlZC5zZWFyY2ggPyAnP1x1MjAyNicgOiAnJyk7XG4gICAgcmV0dXJuIHBhcnNlZC5ob3N0ID09PSAneC5jb20nIHx8IHBhcnNlZC5ob3N0ID09PSAndHdpdHRlci5jb20nXG4gICAgICA/IHBhdGhcbiAgICAgIDogYCR7cGFyc2VkLmhvc3R9JHtwYXRofWA7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiB1Lmxlbmd0aCA+IDgwID8gYCR7dS5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHU7XG4gIH1cbn1cblxuLy8gLS0tIERldiBoZWxwZXJzIGV4cG9zZWQgb24gZ2xvYmFsVGhpcyBmb3IgdGhlIGRldnRvb2xzIGNvbnNvbGUgLS0tLS0tLS0tLVxuLy8gKGUuZy4gYF9faW1tQXJjaGl2ZS5jbGVhckFsbCgpYCBpbiB0aGUgYmFja2dyb3VuZCB3b3JrZXIncyBkZXZ0b29scykuXG5cbihnbG9iYWxUaGlzIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5fX2ltbUFyY2hpdmUgPSB7XG4gIGNsZWFyQWxsLFxuICBhY3Rpdml0eTogZ2V0QWN0aXZpdHksXG4gIGFjY291bnRzOiBnZXRBY2NvdW50cyxcbiAgYnVmZmVyczogZ2V0UnVuQnVmZmVycyxcbiAgZmx1c2hBbGw6ICgpID0+IGZsdXNoQWxsKCdkZXZ0b29scycpLFxuICBzdGF0ZTogYnVpbGRTdGF0ZSxcbn07XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRU8sSUFBTSxtQkFBNkI7QUFBQSxFQUN4QyxLQUFLO0FBQUEsRUFDTCxPQUFPO0FBQUEsRUFDUCxNQUFNO0FBQUE7QUFBQTtBQUFBLEVBR04sUUFBUTtBQUFBLEVBQ1IsYUFBYTtBQUFBLEVBQ2IsY0FBYztBQUNoQjtBQUlPLElBQU0sb0JBQXFDO0FBQUEsRUFDaEQsRUFBRSxRQUFRLFVBQVUsT0FBTyxrQ0FBa0M7QUFBQSxFQUM3RCxFQUFFLFFBQVEsVUFBVSxPQUFPLDJDQUEyQztBQUFBLEVBQ3RFLEVBQUUsUUFBUSxPQUFPLE9BQU8scUNBQXFDO0FBQUEsRUFDN0QsRUFBRSxRQUFRLFNBQVMsT0FBTyw0Q0FBNEM7QUFBQSxFQUN0RSxFQUFFLFFBQVEsY0FBYyxPQUFPLGtCQUFrQjtBQUFBLEVBQ2pELEVBQUUsUUFBUSxZQUFZLE9BQU8sOEJBQThCO0FBQUEsRUFDM0QsRUFBRSxRQUFRLFNBQVMsT0FBTyxpQ0FBaUM7QUFBQSxFQUMzRCxFQUFFLFFBQVEsU0FBUyxPQUFPLDJCQUEyQjtBQUN2RDtBQUdPLElBQU0sa0JBQXVDLG9CQUFJLElBQUk7QUFBQSxFQUMxRDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUlNLElBQU0sb0JBQXlDLG9CQUFJLElBQUksQ0FBQyxvQkFBb0IsY0FBYyxDQUFDO0FBRzNGLElBQU0sd0JBQXdCO0FBRzlCLElBQU0sZ0JBQWdCO0FBR3RCLElBQU0sc0JBQXNCO0FBRzVCLElBQU0sb0JBQW9CO0FBRzFCLElBQU0sZ0NBQWdDLEtBQUssS0FBSztBQUVoRCxJQUFNLG1CQUFtQjs7O0FDMUJoQyxJQUFNLHFCQUFzQztBQUFBLEVBQzFDLFFBQVE7QUFBQSxFQUNSLE9BQU87QUFBQSxFQUNQLFdBQVc7QUFBQSxFQUNYLE9BQU87QUFBQSxFQUNQLGVBQWU7QUFDakI7QUFFQSxJQUFNLFdBQXlCO0FBQUEsRUFDN0IsVUFBVSxFQUFFLEdBQUcsaUJBQWlCO0FBQUEsRUFDaEMsVUFBVSxDQUFDLEdBQUcsaUJBQWlCO0FBQUEsRUFDL0IsWUFBWSxFQUFFLEdBQUcsbUJBQW1CO0FBQUEsRUFDcEMsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLENBQUM7QUFBQSxFQUNiLFVBQVUsQ0FBQztBQUNiO0FBRUEsZUFBZSxPQUFxQyxLQUFrQztBQUNwRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDbEQsUUFBTSxRQUFRLE9BQU8sR0FBRztBQUN4QixNQUFJLFVBQVUsUUFBVztBQUN2QixXQUFPLGdCQUFnQixTQUFTLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBQ0EsU0FBTztBQUNUO0FBRUEsZUFBZSxPQUFxQyxLQUFRLE9BQXVDO0FBQ2pHLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQztBQUNsRDtBQUlBLGVBQXNCLGNBQWlDO0FBQ3JELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFBWSxHQUE0QjtBQUM1RCxRQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzVCO0FBQ0EsZUFBc0IsZUFBZSxPQUE2QztBQUNoRixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEMsUUFBTSxZQUFZLElBQUk7QUFDdEIsU0FBTztBQUNUO0FBSUEsZUFBc0IsY0FBd0M7QUFDNUQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUFZLEdBQW1DO0FBQ25FLFFBQU0sT0FBTyxZQUFZLENBQUM7QUFDNUI7QUFJQSxlQUFzQixnQkFBMEM7QUFDOUQsUUFBTSxJQUFJLE1BQU0sT0FBTyxZQUFZO0FBRW5DLE1BQUksRUFBRSxrQkFBa0IsUUFBVztBQUNqQyxXQUFPLEVBQUUsR0FBRyxHQUFHLGVBQWUsS0FBSztBQUFBLEVBQ3JDO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsY0FBYyxHQUFtQztBQUNyRSxRQUFNLE9BQU8sY0FBYyxDQUFDO0FBQzlCO0FBSUEsU0FBUyxXQUFtQjtBQUMxQixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDN0M7QUFFQSxlQUFzQixjQUF1RDtBQUMzRSxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQ3BCLFFBQ0EsT0FDeUI7QUFDekIsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUs7QUFBQSxJQUN6QixZQUFZO0FBQUEsSUFDWixXQUFXLFNBQVM7QUFBQSxJQUNwQixlQUFlO0FBQUEsSUFDZixnQkFBZ0I7QUFBQSxJQUNoQixlQUFlO0FBQUEsRUFDakI7QUFDQSxNQUFJLElBQUksY0FBYyxTQUFTLEdBQUc7QUFDaEMsUUFBSSxZQUFZLFNBQVM7QUFDekIsUUFBSSxhQUFhO0FBQUEsRUFDbkI7QUFDQSxRQUFNLE9BQXVCLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoRCxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsaUJBQWlCLFFBQWdCLE9BQThCO0FBQ25GLFFBQU0sWUFBWSxRQUFRLEVBQUUsZUFBZSxNQUFNLENBQUM7QUFDcEQ7QUFJQSxlQUFzQixnQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLFlBQVk7QUFDNUI7QUFFQSxlQUFzQixhQUFhLFFBQTJDO0FBQzVFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU0sS0FBSztBQUN4QjtBQUVBLGVBQXNCLGFBQWEsUUFBZ0IsS0FBK0I7QUFDaEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFFQSxlQUFzQixlQUFlLFFBQStCO0FBQ2xFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU07QUFDakIsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUlBLGVBQXNCLGNBQW1DO0FBQ3ZELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBRUEsZUFBc0IsZUFBZSxJQUFtQztBQUN0RSxRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLE1BQUksUUFBUSxFQUFFO0FBQ2QsTUFBSSxJQUFJLFNBQVMsa0JBQW1CLEtBQUksU0FBUztBQUNqRCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGdCQUErQjtBQUNuRCxRQUFNLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDN0I7QUFJQSxlQUFzQixXQUEwQjtBQUM5QyxRQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU07QUFDcEM7OztBQ3BMQSxJQUFJLFlBQTZDO0FBRTFDLFNBQVMsZUFBZSxJQUFrQztBQUMvRCxjQUFZO0FBQ2Q7QUFFQSxTQUFTLFNBQWlCO0FBQ3hCLFVBQU8sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDaEM7QUFFQSxlQUFlLEtBQUssT0FBaUIsS0FBYSxTQUFpRDtBQUNqRyxRQUFNLEtBQWUsRUFBRSxJQUFJLE9BQU8sR0FBRyxPQUFPLEtBQUssU0FBUyxPQUFPLE9BQU8sRUFBRTtBQUUxRSxRQUFNLE9BQU8saUJBQWlCLE1BQU0sWUFBWSxDQUFDLElBQUksR0FBRztBQUN4RCxNQUFJLFVBQVUsUUFBUyxTQUFRLE1BQU0sTUFBTSxHQUFHLE9BQU87QUFBQSxXQUM1QyxVQUFVLE9BQVEsU0FBUSxLQUFLLE1BQU0sR0FBRyxPQUFPO0FBQUEsTUFDbkQsU0FBUSxJQUFJLE1BQU0sR0FBRyxPQUFPO0FBRWpDLE1BQUk7QUFDRixVQUFNLGVBQWUsRUFBRTtBQUFBLEVBQ3pCLFNBQVMsS0FBSztBQUNaLFlBQVEsS0FBSywyQ0FBMkMsR0FBRztBQUFBLEVBQzdEO0FBRUEsTUFBSTtBQUNGLGdCQUFZLEVBQUU7QUFBQSxFQUNoQixRQUFRO0FBQUEsRUFFUjtBQUNGO0FBRU8sU0FBUyxLQUFLLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN0RixTQUFPLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDbEM7QUFDTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsTUFBTSxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdkYsU0FBTyxLQUFLLFNBQVMsS0FBSyxPQUFPO0FBQ25DO0FBRU8sU0FBUyxjQUFjLEtBQXlEO0FBQ3JGLE1BQUksZUFBZSxPQUFPO0FBQ3hCLFdBQU8sRUFBRSxTQUFTLElBQUksU0FBUyxPQUFPLElBQUksU0FBUyxLQUFLO0FBQUEsRUFDMUQ7QUFDQSxNQUFJO0FBQ0YsV0FBTyxFQUFFLFNBQVMsT0FBTyxHQUFHLEdBQUcsT0FBTyxLQUFLO0FBQUEsRUFDN0MsUUFBUTtBQUNOLFdBQU8sRUFBRSxTQUFTLHVCQUF1QixPQUFPLEtBQUs7QUFBQSxFQUN2RDtBQUNGO0FBT0EsU0FBUyxPQUFPLEtBQXVEO0FBQ3JFLFFBQU0sTUFBK0IsQ0FBQztBQUN0QyxhQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUN4QyxRQUFJLEVBQUUsWUFBWSxFQUFFLFNBQVMsT0FBTyxLQUFLLEVBQUUsWUFBWSxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7QUFDM0YsVUFBSSxDQUFDLElBQUk7QUFBQSxJQUNYLFdBQVcsT0FBTyxNQUFNLFlBQVksK0JBQStCLEtBQUssQ0FBQyxHQUFHO0FBQzFFLFVBQUksQ0FBQyxJQUFJLEVBQUUsUUFBUSw2QkFBNkIsdUJBQXVCO0FBQUEsSUFDekUsV0FBVyxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsTUFBTTtBQUNuRCxVQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsTUFBTSxHQUFHLElBQUksQ0FBQztBQUFBLElBQzlCLE9BQU87QUFDTCxVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1g7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUOzs7QUN2RUEsSUFBTSxXQUFXO0FBQ2pCLElBQU0sV0FBVztBQWVWLElBQU0sY0FBTixjQUEwQixNQUFNO0FBQUEsRUFDckM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUVBLFlBQVksTUFNVDtBQUNELFVBQU0sS0FBSyxPQUFPO0FBQ2xCLFNBQUssT0FBTztBQUNaLFNBQUssU0FBUyxLQUFLO0FBQ25CLFNBQUssT0FBTyxLQUFLO0FBQ2pCLFNBQUssWUFBWSxLQUFLO0FBQ3RCLFNBQUssV0FBVyxLQUFLO0FBQUEsRUFDdkI7QUFDRjtBQUVPLElBQU0sZUFBTixNQUFtQjtBQUFBLEVBQ1A7QUFBQSxFQUVqQixZQUFZLFVBQW9CO0FBQzlCLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUE7QUFBQSxFQUdBLE1BQU0sU0FBMEI7QUFDOUIsVUFBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTztBQUMvQyxXQUFRLElBQTJCLFNBQVM7QUFBQSxFQUM5QztBQUFBO0FBQUEsRUFHQSxNQUFNLGFBQWEsUUFBa0M7QUFDbkQsUUFBSTtBQUNGLFlBQU0sS0FBSztBQUFBLFFBQ1Q7QUFBQSxRQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLG1CQUFtQixNQUFNLENBQUM7QUFBQSxNQUM1RjtBQUNBLGFBQU87QUFBQSxJQUNULFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLE1BQU0sbUJBQTBGO0FBQzlGLFVBQU0sS0FBSyxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDOUMsVUFBTSxPQUFPLE1BQU0sS0FBSyxVQUFVLE9BQU8sVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLEVBQUU7QUFDOUYsVUFBTSxJQUFJO0FBQ1YsV0FBTztBQUFBLE1BQ0wsT0FBUSxHQUF5QjtBQUFBLE1BQ2pDLFdBQVcsRUFBRTtBQUFBLE1BQ2IsZ0JBQWdCLEVBQUU7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxhQUFhLFlBQTRDO0FBQzdELFVBQU0sTUFBTSxHQUFHLFFBQVEsSUFBSSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLElBQUksS0FBSyxTQUFTLE1BQU0sSUFBSSxVQUFVO0FBQzFHLFVBQU0sTUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLE1BQzNCLFFBQVE7QUFBQSxNQUNSLFNBQVMsRUFBRSxlQUFlLFVBQVUsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUFBLElBQzFELENBQUM7QUFDRCxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxDQUFDLElBQUksR0FBSSxPQUFNLE1BQU0sS0FBSyxVQUFVLEtBQUssV0FBVyxVQUFVLEVBQUU7QUFDcEUsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLFdBQVcsTUFBc0M7QUFDckQsUUFBSTtBQUNGLFlBQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxRQUNyQjtBQUFBLFFBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUMsUUFBUSxtQkFBbUIsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLE1BQ2xJO0FBQ0EsWUFBTSxJQUFJO0FBQ1YsYUFBTyxFQUFFLE9BQU87QUFBQSxJQUNsQixTQUFTLEtBQUs7QUFDWixVQUFJLGVBQWUsZUFBZSxJQUFJLGFBQWEsWUFBYSxRQUFPO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE1BQU0sUUFBUSxNQUE4QztBQUMxRCxVQUFNLE9BQU8sS0FBSztBQUNsQixVQUFNLE1BQU0sVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUM7QUFDNUYsUUFBSSxNQUFxQixLQUFLLGVBQWU7QUFDN0MsVUFBTSxjQUFjO0FBRXBCLGFBQVMsVUFBVSxHQUFHLFdBQVcsYUFBYSxXQUFXO0FBQ3ZELFlBQU0sT0FBZ0M7QUFBQSxRQUNwQyxTQUFTLEtBQUs7QUFBQSxRQUNkLFNBQVMsS0FBSztBQUFBLFFBQ2QsUUFBUSxLQUFLLFNBQVM7QUFBQSxNQUN4QjtBQUNBLFVBQUksSUFBSyxNQUFLLE1BQU07QUFDcEIsVUFBSTtBQUNGLGNBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxPQUFPLEtBQUssSUFBSTtBQUNqRCxjQUFNLE1BQU07QUFDWixlQUFPLEVBQUUsTUFBTSxJQUFJLFFBQVEsTUFBTSxLQUFLLElBQUksUUFBUSxLQUFLLEtBQUssSUFBSSxRQUFRLFNBQVM7QUFBQSxNQUNuRixTQUFTLEtBQUs7QUFDWixZQUFJLEVBQUUsZUFBZSxhQUFjLE9BQU07QUFDekMsWUFBSSxJQUFJLFdBQVcsT0FBTyxDQUFDLEtBQUs7QUFFOUIsZ0JBQU0sTUFBTSxLQUFLLFdBQVcsSUFBSTtBQUNoQyxjQUFJLENBQUMsSUFBSyxPQUFNO0FBQ2hCO0FBQUEsUUFDRjtBQUNBLFlBQUksQ0FBQyxJQUFJLGFBQWEsWUFBWSxZQUFhLE9BQU07QUFDckQsY0FBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLElBQUksTUFBTSxtQ0FBbUMsSUFBSSxFQUFFO0FBQUEsRUFDM0Q7QUFBQSxFQUVBLE1BQWMsVUFBVSxRQUFnQixNQUFjLE1BQWtDO0FBQ3RGLFVBQU0sTUFBTSxLQUFLLFdBQVcsTUFBTSxJQUFJLE9BQU8sR0FBRyxRQUFRLEdBQUcsSUFBSTtBQUMvRCxVQUFNLE9BQW9CO0FBQUEsTUFDeEI7QUFBQSxNQUNBLFNBQVM7QUFBQSxRQUNQLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRztBQUFBLFFBQzFDLFFBQVE7QUFBQSxRQUNSLHdCQUF3QjtBQUFBLFFBQ3hCLEdBQUksT0FBTyxFQUFFLGdCQUFnQixtQkFBbUIsSUFBSSxDQUFDO0FBQUEsTUFDdkQ7QUFBQSxNQUNBLEdBQUksT0FBTyxFQUFFLE1BQU0sS0FBSyxVQUFVLElBQUksRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMvQztBQUNBLFFBQUk7QUFDSixRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSyxJQUFJO0FBQUEsSUFDN0IsU0FBUyxRQUFRO0FBQ2YsWUFBTSxJQUFJLFlBQVk7QUFBQSxRQUNwQixRQUFRO0FBQUEsUUFDUixNQUFNO0FBQUEsUUFDTixTQUFTLFlBQVksY0FBYyxNQUFNLEVBQUUsT0FBTztBQUFBLFFBQ2xELFdBQVc7QUFBQSxRQUNYLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSSxJQUFJLFdBQVcsSUFBSyxRQUFPO0FBQy9CLFFBQUksU0FBa0I7QUFDdEIsVUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0FBQzVCLFFBQUksTUFBTTtBQUNSLFVBQUk7QUFDRixpQkFBUyxLQUFLLE1BQU0sSUFBSTtBQUFBLE1BQzFCLFFBQVE7QUFDTixpQkFBUztBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLElBQUksR0FBSSxPQUFNLE1BQU0sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEdBQUcsTUFBTSxJQUFJLElBQUksRUFBRTtBQUNsRixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUEsTUFBYyxVQUFVLEtBQWUsT0FBcUM7QUFDMUUsUUFBSSxTQUFrQjtBQUN0QixRQUFJO0FBQ0YsWUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0FBQzVCLFVBQUksS0FBTSxVQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsSUFDcEMsUUFBUTtBQUFBLElBRVI7QUFDQSxXQUFPLEtBQUssb0JBQW9CLEtBQUssUUFBUSxLQUFLO0FBQUEsRUFDcEQ7QUFBQSxFQUVRLG9CQUFvQixLQUFlLE1BQWUsT0FBNEI7QUFDcEYsVUFBTSxNQUNKLE9BQU8sU0FBUyxZQUFZLFFBQVEsYUFBYSxPQUM3QyxPQUFRLEtBQThCLE9BQU8sSUFDN0MsSUFBSTtBQUNWLFFBQUksV0FBb0M7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7QUFFNUMsWUFBTSxPQUFPLElBQUksUUFBUSxJQUFJLHVCQUF1QjtBQUNwRCxVQUFJLFNBQVMsT0FBTyxjQUFjLEtBQUssR0FBRyxHQUFHO0FBQzNDLG1CQUFXO0FBQ1gsb0JBQVk7QUFBQSxNQUNkLE9BQU87QUFDTCxtQkFBVztBQUFBLE1BQ2I7QUFBQSxJQUNGLFdBQVcsSUFBSSxXQUFXLEtBQUs7QUFDN0IsaUJBQVc7QUFBQSxJQUNiLFdBQVcsSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7QUFDbkQsaUJBQVc7QUFBQSxJQUNiLFdBQVcsSUFBSSxVQUFVLEtBQUs7QUFDNUIsaUJBQVc7QUFDWCxrQkFBWTtBQUFBLElBQ2QsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZDtBQUNBLFdBQU8sSUFBSSxZQUFZO0FBQUEsTUFDckIsUUFBUSxJQUFJO0FBQUEsTUFDWjtBQUFBLE1BQ0EsU0FBUyxHQUFHLEtBQUssV0FBTSxJQUFJLE1BQU0sS0FBSyxHQUFHO0FBQUEsTUFDekM7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNGO0FBRUEsU0FBUyxXQUFXLE1BQXNCO0FBRXhDLFNBQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJLGtCQUFrQixFQUFFLEtBQUssR0FBRztBQUN6RDtBQUVBLFNBQVMsVUFBVSxTQUFpQixLQUEwQjtBQUU1RCxRQUFNLE9BQU8sSUFBSSxhQUFhLGVBQWUsTUFBTztBQUNwRCxRQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQUc7QUFDN0MsU0FBTyxLQUFLLElBQUksS0FBUSxPQUFPLE1BQU0sVUFBVSxLQUFLLE1BQU07QUFDNUQ7QUFFQSxTQUFTLE1BQU0sSUFBMkI7QUFDeEMsU0FBTyxJQUFJLFFBQVEsQ0FBQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUM7QUFDN0M7QUFFTyxTQUFTLFNBQVMsT0FBdUI7QUFFOUMsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFLE9BQU8sS0FBSztBQUMzQyxNQUFJLE1BQU07QUFDVixhQUFXLEtBQUssS0FBTSxRQUFPLE9BQU8sYUFBYSxDQUFDO0FBQ2xELFNBQU8sS0FBSyxHQUFHO0FBQ2pCOzs7QUN4T08sU0FBUyxVQUFVLFNBQWtCLEtBQXdDO0FBQ2xGLFFBQU0sWUFBWSxjQUFjLE9BQU87QUFDdkMsUUFBTSxTQUEyQixDQUFDO0FBQ2xDLFFBQU0sV0FBcUIsQ0FBQztBQUM1QixhQUFXLE9BQU8sV0FBVztBQUMzQixRQUFJO0FBQ0YsWUFBTSxJQUFJLFdBQVcsS0FBSyxHQUFHO0FBQzdCLFVBQUksQ0FBQyxFQUFHO0FBQ1IsZUFBUyxLQUFLLEVBQUUsUUFBUTtBQUN4QixVQUFJLElBQUksZUFBZSxTQUFTLEtBQUssSUFBSSxlQUFlLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxHQUFHO0FBQzNGLGVBQU8sS0FBSyxDQUFDO0FBQUEsTUFDZjtBQUFBLElBQ0YsUUFBUTtBQUFBLElBRVI7QUFBQSxFQUNGO0FBQ0EsU0FBTyxFQUFFLFFBQVEsY0FBYyxTQUFTO0FBQzFDO0FBRUEsU0FBUyxjQUFjQSxNQUF5QjtBQUs5QyxRQUFNLE1BQWlCLENBQUM7QUFDeEIsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQ0EsSUFBRztBQUM3QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sT0FBTyxNQUFNLElBQUk7QUFDdkIsUUFBSSxTQUFTLFFBQVEsU0FBUyxPQUFXO0FBQ3pDLFFBQUksT0FBTyxTQUFTLFNBQVU7QUFDOUIsUUFBSSxLQUFLLElBQUksSUFBYyxFQUFHO0FBQzlCLFNBQUssSUFBSSxJQUFjO0FBRXZCLFFBQUksZUFBZSxJQUFJLEdBQUc7QUFDeEIsVUFBSSxLQUFLLFlBQVksSUFBSSxDQUFDO0FBQUEsSUFDNUI7QUFDQSxRQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDdkIsaUJBQVcsS0FBSyxLQUFNLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDcEMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLElBQStCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM5RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGVBQWUsTUFBZ0Q7QUFDdEUsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLFdBQVcsRUFBRTtBQUNuQixNQUNFLGFBQWEsV0FDYixhQUFhLGdDQUNiLGFBQWEsa0JBQ2I7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQU8sT0FBTyxFQUFFLFlBQVksWUFBWSxPQUFPLEVBQUUsV0FBVyxZQUFZLEVBQUUsV0FBVztBQUN2RjtBQUVBLFNBQVMsWUFBWSxNQUF3RDtBQUMzRSxNQUFJLEtBQUssZUFBZSxnQ0FBZ0MsT0FBTyxLQUFLLFVBQVUsVUFBVTtBQUN0RixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLEtBQWMsS0FBOEM7QUFDOUUsTUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLEtBQU0sUUFBTztBQUNwRCxRQUFNLElBQUk7QUFFVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUU5QyxRQUFNLFNBQVMsVUFBVSxFQUFFLE9BQU87QUFDbEMsUUFBTSxTQUFTLElBQUksRUFBRSxNQUFNO0FBQzNCLE1BQUksQ0FBQyxVQUFVLENBQUMsT0FBUSxRQUFPO0FBRS9CLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxJQUFJLE1BQU0sWUFBWSxHQUFHLE1BQU07QUFDdEQsUUFBTSxhQUFhLElBQUksWUFBWSxNQUFNO0FBQ3pDLFFBQU0sU0FBUyxVQUFVLFlBQVksV0FBVztBQUNoRCxRQUFNLFlBQVksVUFBVSxZQUFZLE9BQU8sS0FBSyxVQUFVLE9BQU8sV0FBVztBQUNoRixNQUFJLENBQUMsVUFBVSxDQUFDLFVBQVcsUUFBTztBQUVsQyxRQUFNLFlBQVksSUFBSSxJQUFJLElBQUksRUFBRSxVQUFVLEdBQUcsa0JBQWtCLEdBQUcsTUFBTTtBQUN4RSxRQUFNLGVBQWUsVUFBVSxXQUFXLElBQUk7QUFDOUMsUUFBTSxpQkFBaUIsVUFBVSxPQUFPLFNBQVMsS0FBSztBQUN0RCxRQUFNLE9BQU8sZ0JBQWdCO0FBRTdCLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUSxLQUFLLENBQUM7QUFDMUMsUUFBTSxtQkFBbUIsSUFBSSxXQUFXLFVBQVU7QUFDbEQsUUFBTSxXQUFXLGdCQUFnQixvQkFBb0IsUUFBUTtBQUM3RCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sT0FBTyxZQUFZLG9CQUFvQixRQUFRO0FBQ3JELFFBQU0sUUFBUSxhQUFhLE1BQU07QUFFakMsUUFBTSxZQUFZLGtCQUFrQixHQUFHLE1BQU07QUFFN0MsUUFBTSxXQUFXLGlCQUFpQixVQUFVLE9BQU8sVUFBVSxDQUFDO0FBQzlELE1BQUksQ0FBQyxTQUFVLFFBQU87QUFFdEIsUUFBTSxRQUFRLElBQUksRUFBRSxLQUFLO0FBQ3pCLFFBQU0sWUFBWSxVQUFVLE9BQU8sS0FBSyxLQUFLLFVBQVUsVUFBVSxPQUFPLEtBQUssQ0FBQztBQUU5RSxRQUFNLFFBQXdCO0FBQUEsSUFDNUIsVUFBVTtBQUFBLElBQ1YsZ0JBQWdCO0FBQUEsSUFDaEIsWUFBWTtBQUFBLElBQ1osV0FBVztBQUFBLElBQ1gsbUJBQW1CLElBQUk7QUFBQSxJQUN2QixjQUFjLElBQUk7QUFBQSxJQUNsQixzQkFBc0I7QUFBQSxJQUN0QixXQUFXLEdBQUcsZ0JBQWdCLElBQUksTUFBTSxXQUFXLE1BQU07QUFBQSxJQUN6RCxZQUFZO0FBQUEsSUFDWixtQkFBbUIsVUFBVSxPQUFPLHlCQUF5QjtBQUFBLElBQzdELGtCQUFrQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDMUQsaUJBQWlCLFVBQVUsT0FBTyxvQkFBb0I7QUFBQSxJQUN0RCxvQkFBb0I7QUFBQSxNQUNsQixJQUFJLElBQUksT0FBTyx1QkFBdUIsR0FBRyxNQUFNLEdBQUcsV0FDL0MsT0FBbUM7QUFBQSxJQUN4QztBQUFBLElBQ0E7QUFBQSxJQUNBLGVBQWUsaUJBQWlCLE1BQU0sSUFBSTtBQUFBLElBQzFDLE1BQU0sVUFBVSxPQUFPLElBQUk7QUFBQSxJQUMzQjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWSxVQUFVLE9BQU8sY0FBYztBQUFBLElBQzNDLGVBQWUsVUFBVSxPQUFPLGFBQWE7QUFBQSxJQUM3QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsYUFBYSxVQUFVLE9BQU8sV0FBVztBQUFBLElBQ3pDLFlBQVk7QUFBQSxJQUNaLGdCQUFnQixVQUFVLE9BQU8sY0FBYztBQUFBLElBQy9DLG9CQUFvQjtBQUFBLE1BQ2xCO0FBQUEsUUFDRSxhQUFhLElBQUk7QUFBQSxRQUNqQixPQUFPLFVBQVUsT0FBTyxjQUFjO0FBQUEsUUFDdEMsVUFBVSxVQUFVLE9BQU8sYUFBYTtBQUFBLFFBQ3hDLFNBQVMsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNyQyxRQUFRLFVBQVUsT0FBTyxXQUFXO0FBQUEsUUFDcEMsT0FBTztBQUFBLFFBQ1AsV0FBVyxVQUFVLE9BQU8sY0FBYztBQUFBLE1BQzVDO0FBQUEsSUFDRjtBQUFBLElBQ0EsYUFBYTtBQUFBLElBQ2Isc0JBQXNCO0FBQUEsSUFDdEIsZ0JBQWdCO0FBQUEsSUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxJQUNwQixnQkFBZ0I7QUFBQSxFQUNsQjtBQUVBLFNBQU87QUFDVDtBQUVBLFNBQVMsa0JBQWtCLEdBQTRCLFFBQTRDO0FBQ2pHLE1BQUksT0FBTywyQkFBMkIsT0FBTyx3QkFBeUIsUUFBTztBQUM3RSxNQUFJLE9BQU8sMEJBQTJCLFFBQU87QUFDN0MsTUFBSSxPQUFPLG9CQUFvQixRQUFRLE9BQU8scUJBQXNCLFFBQU87QUFDM0UsTUFBSSxFQUFFLGVBQWUsOEJBQThCO0FBQUEsRUFFbkQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxVQUFVLElBQUksT0FBUSxFQUF3QixJQUFJLElBQUk7QUFBQSxFQUN0RixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixJQUMzQyxPQUFRLEVBQStCLFdBQVcsSUFDbEQ7QUFBQSxFQUNOLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxZQUFZLFVBQWdEO0FBQ25FLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxRQUFNLE1BQW1CLENBQUM7QUFDMUIsYUFBVyxLQUFLLEtBQUs7QUFDbkIsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU07QUFDekMsVUFBTSxJQUFJO0FBQ1YsVUFBTSxRQUFRLFVBQVUsRUFBRSxHQUFHO0FBQzdCLFVBQU0sV0FBVyxVQUFVLEVBQUUsWUFBWTtBQUN6QyxVQUFNLFVBQVUsVUFBVSxFQUFFLFdBQVc7QUFDdkMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFVO0FBQ3pCLFFBQUksS0FBSyxFQUFFLE9BQU8sVUFBVSxTQUFTLFdBQVcsU0FBUyxDQUFDO0FBQUEsRUFDNUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGFBQWEsUUFBOEM7QUFDbEUsUUFBTSxXQUFXLElBQUksT0FBTyxpQkFBaUI7QUFDN0MsUUFBTSxVQUFVLFdBQVcsUUFBUSxTQUFTLEtBQUssSUFBSSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxRQUFRLElBQUksT0FBTyxRQUFRLEdBQUcsS0FBSztBQUNuRCxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFNBQVMsQ0FBQyxHQUFHLFNBQVMsR0FBRyxPQUFPLEVBQUUsT0FBTyxDQUFDLE1BQU07QUFDcEQsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU0sUUFBTztBQUNoRCxVQUFNLEtBQ0osVUFBVyxFQUE4QixTQUFTLEtBQ2xELFVBQVcsRUFBOEIsTUFBTTtBQUNqRCxRQUFJLENBQUMsR0FBSSxRQUFPO0FBQ2hCLFFBQUksS0FBSyxJQUFJLEVBQUUsRUFBRyxRQUFPO0FBQ3pCLFNBQUssSUFBSSxFQUFFO0FBQ1gsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNELFNBQU8sT0FBTyxJQUFJLENBQUMsUUFBUSxXQUFXLEdBQThCLENBQUM7QUFDdkU7QUFFQSxTQUFTLFdBQVcsR0FBdUM7QUFDekQsUUFBTSxPQUFPLFVBQVUsRUFBRSxJQUFJO0FBQzdCLFFBQU0sV0FBVyxnQkFBZ0IsR0FBRyxJQUFJO0FBQ3hDLFFBQU1DLFFBQU8sSUFBSSxFQUFFLGFBQWE7QUFDaEMsUUFBTSxZQUFZLElBQUksRUFBRSxVQUFVO0FBQ2xDLFFBQU0sYUFBYSxVQUFVLFdBQVcsZUFBZTtBQUN2RCxRQUFNLFVBQVUsVUFBVSxFQUFFLFlBQVk7QUFDeEMsUUFBTSxVQUNKLFVBQVUsRUFBRSxTQUFTLEtBQ3JCLFVBQVUsRUFBRSxNQUFNLEtBQ2xCLEdBQUcsUUFBUSxPQUFPLElBQUksS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDM0QsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsWUFBYSxRQUFRO0FBQUEsSUFDckIsY0FBYyxZQUFZO0FBQUEsSUFDMUIsbUJBQW1CO0FBQUEsSUFDbkIsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsY0FBYyxlQUFlLE9BQU8sYUFBYSxNQUFPO0FBQUEsSUFDeEQsT0FBTyxVQUFVQSxPQUFNLEtBQUs7QUFBQSxJQUM1QixRQUFRLFVBQVVBLE9BQU0sTUFBTTtBQUFBLElBQzlCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLGtCQUFrQjtBQUFBLElBQ2xCLGlCQUFpQjtBQUFBLEVBQ25CO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixHQUE0QixNQUFvQztBQUN2RixNQUFJLFNBQVMsUUFBUyxRQUFPLFVBQVUsRUFBRSxlQUFlLEtBQUssVUFBVSxFQUFFLFNBQVM7QUFDbEYsUUFBTSxXQUFXLFFBQVEsSUFBSSxFQUFFLFVBQVUsR0FBRyxRQUFRO0FBQ3BELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxVQUFVLEVBQUUsZUFBZTtBQUU3RCxNQUFJLE9BQWdEO0FBQ3BELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sS0FBSyxVQUFVLEVBQUUsWUFBWTtBQUNuQyxVQUFNLE1BQU0sVUFBVSxFQUFFLEdBQUc7QUFDM0IsUUFBSSxDQUFDLElBQUs7QUFDVixRQUFJLE9BQU8sYUFBYTtBQUN0QixZQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sS0FBSztBQUNuQyxVQUFJLENBQUMsUUFBUSxLQUFLLEtBQUssUUFBUyxRQUFPLEVBQUUsS0FBSyxTQUFTLEdBQUc7QUFBQSxJQUM1RCxXQUFXLENBQUMsTUFBTTtBQUVoQixhQUFPLEVBQUUsS0FBSyxTQUFTLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLE1BQU0sT0FBTztBQUN0QjtBQUVBLFNBQVMsaUJBQWlCLE1BQWMsTUFBMkI7QUFDakUsTUFBSSxLQUFLLFdBQVcsRUFBRyxRQUFPO0FBQzlCLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLE9BQU0sSUFBSSxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRO0FBQzlELFNBQU87QUFDVDtBQUVBLFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELE1BQUksQ0FBQyxFQUFHLFFBQU87QUFFZixRQUFNLElBQUksSUFBSSxLQUFLLENBQUM7QUFDcEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPO0FBQ3RDLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLFNBQU8sT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLElBQUksSUFBSTtBQUNyRDtBQUNBLFNBQVMsVUFBVSxHQUEyQjtBQUM1QyxNQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUN4RCxNQUFJLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxHQUFHO0FBQ3pDLFVBQU0sSUFBSSxPQUFPLENBQUM7QUFDbEIsUUFBSSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFBQSxFQUNqQztBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsVUFBVSxHQUFvQjtBQUNyQyxTQUFPLFVBQVUsQ0FBQyxLQUFLO0FBQ3pCO0FBQ0EsU0FBUyxJQUFJLEdBQTRDO0FBQ3ZELFNBQU8sT0FBTyxNQUFNLFlBQVksTUFBTSxRQUFRLENBQUMsTUFBTSxRQUFRLENBQUMsSUFDekQsSUFDRDtBQUNOO0FBQ0EsU0FBUyxRQUFRLEdBQXVCO0FBQ3RDLFNBQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUM7QUFDakM7OztBQ3ZVQSxJQUFNLFdBQVc7QUFFVixTQUFTLFdBQW1CO0FBQ2pDLFFBQU0sS0FBSyxLQUFLLElBQUk7QUFDcEIsTUFBSSxTQUFTO0FBQ2IsTUFBSSxJQUFJO0FBQ1IsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7QUFDM0IsY0FBVSxTQUFTLElBQUksRUFBRSxLQUFLLE9BQU87QUFDckMsUUFBSSxLQUFLLE1BQU0sSUFBSSxFQUFFO0FBQUEsRUFDdkI7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxNQUFJLFdBQVc7QUFDZixhQUFXLEtBQUssS0FBTSxhQUFZLFNBQVMsSUFBSSxFQUFFLEtBQUs7QUFDdEQsU0FBTyxTQUFTO0FBQ2xCO0FBRU8sU0FBUyxXQUFXLElBQW9CO0FBQzdDLFNBQU8sR0FBRyxNQUFNLEVBQUU7QUFDcEI7OztBQ1hPLFNBQVMsa0JBQWtCLE1BQStCO0FBQy9ELFFBQU0sV0FBNEIsQ0FBQztBQUNuQyxNQUFJLFVBQWtDLENBQUM7QUFDdkMsTUFBSSxhQUFhO0FBQ2pCLGFBQVcsV0FBVyxLQUFLLE1BQU0sSUFBSSxHQUFHO0FBQ3RDLFVBQU0sT0FBTyxjQUFjLE9BQU87QUFDbEMsUUFBSSxLQUFLLEtBQUssTUFBTSxHQUFJO0FBQ3hCLFFBQUksZ0JBQWdCLEtBQUssSUFBSSxHQUFHO0FBQzlCLG1CQUFhO0FBQ2I7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLFdBQVk7QUFFakIsVUFBTSxZQUFZLEtBQUssTUFBTSw0QkFBNEI7QUFDekQsUUFBSSxXQUFXO0FBQ2IsVUFBSSxRQUFRLFVBQVUsUUFBUSxNQUFPLFVBQVMsS0FBSyxPQUF3QjtBQUMzRSxnQkFBVSxFQUFFLFFBQVEsUUFBUSxVQUFVLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDaEQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx3QkFBd0I7QUFDdEQsUUFBSSxjQUFjLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUNyQyxVQUFJLFFBQVEsVUFBVSxRQUFRLE1BQU8sVUFBUyxLQUFLLE9BQXdCO0FBQzNFLGdCQUFVLEVBQUUsUUFBUSxRQUFRLFdBQVcsQ0FBQyxLQUFLLEVBQUUsRUFBRTtBQUNqRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGFBQWEsS0FBSyxNQUFNLHVCQUF1QjtBQUNyRCxRQUFJLGNBQWMsUUFBUSxRQUFRO0FBQ2hDLGNBQVEsUUFBUSxRQUFRLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDM0M7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLE1BQUksUUFBUSxVQUFVLFFBQVEsTUFBTyxVQUFTLEtBQUssT0FBd0I7QUFDM0UsU0FBTyxTQUFTLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxTQUFTLENBQUM7QUFDbkQ7QUFFQSxTQUFTLGNBQWMsTUFBc0I7QUFHM0MsUUFBTSxNQUFNLEtBQUssUUFBUSxHQUFHO0FBQzVCLFNBQU8sUUFBUSxLQUFLLE9BQU8sS0FBSyxNQUFNLEdBQUcsR0FBRztBQUM5QztBQUVBLFNBQVMsUUFBUSxHQUFtQjtBQUNsQyxRQUFNLFVBQVUsRUFBRSxLQUFLO0FBQ3ZCLE1BQ0csUUFBUSxXQUFXLEdBQUcsS0FBSyxRQUFRLFNBQVMsR0FBRyxLQUMvQyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEdBQ2hEO0FBQ0EsV0FBTyxRQUFRLE1BQU0sR0FBRyxFQUFFO0FBQUEsRUFDNUI7QUFDQSxTQUFPO0FBQ1Q7OztBQ05BLElBQU0sY0FBYyxRQUFRLFFBQVEsWUFBWSxFQUFFO0FBRWxELGVBQWUsQ0FBQyxPQUFpQjtBQUMvQixVQUFRLFFBQVEsWUFBWSxFQUFFLE1BQU0sYUFBYSxPQUFPLEdBQUcsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUM5RSxDQUFDO0FBSUQsUUFBUSxRQUFRLFlBQVksWUFBWSxZQUFZO0FBQ2xELFFBQU0sS0FBSyx1QkFBdUIsRUFBRSxTQUFTLFlBQVksQ0FBQztBQUMxRCxRQUFNLE9BQU8sU0FBUztBQUN4QixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxNQUFNO0FBQzFDLE9BQUssT0FBTyxTQUFTO0FBQ3ZCLENBQUM7QUFHRCxLQUFLLE9BQU8sYUFBYTtBQUV6QixlQUFlLE9BQU8sUUFBK0I7QUFDbkQsTUFBSTtBQUNGLFVBQU0sYUFBYTtBQUNuQixVQUFNLDRCQUE0QjtBQUNsQyxVQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQUksU0FBUyxPQUFPLFNBQVMsU0FBUyxTQUFTLE1BQU07QUFDbkQsWUFBTSxpQkFBaUIsS0FBSztBQUM1QixZQUFNLG9CQUFvQixLQUFLO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU87QUFBQSxRQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlO0FBQUEsTUFDakIsQ0FBQztBQUNELFlBQU0sS0FBSyx3Q0FBd0MsRUFBRSxPQUFPLENBQUM7QUFBQSxJQUMvRDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFPLGVBQWUsRUFBRSxRQUFRLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQy9EO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLFFBQU0sUUFBUSxPQUFPLE1BQU0sYUFBYTtBQUN4QyxRQUFNLFFBQVEsT0FBTyxNQUFNLG1CQUFtQjtBQUM5QyxRQUFNLFFBQVEsT0FBTyxPQUFPLGVBQWUsRUFBRSxpQkFBaUIsb0JBQW9CLENBQUM7QUFDbkYsUUFBTSxRQUFRLE9BQU8sT0FBTyxxQkFBcUI7QUFBQSxJQUMvQyxpQkFBaUIsZ0NBQWdDO0FBQUEsRUFDbkQsQ0FBQztBQUNIO0FBRUEsUUFBUSxPQUFPLFFBQVEsWUFBWSxDQUFDLFVBQVU7QUFDNUMsTUFBSSxNQUFNLFNBQVMsZUFBZTtBQUNoQyxTQUFLLGlCQUFpQjtBQUFBLEVBQ3hCLFdBQVcsTUFBTSxTQUFTLHFCQUFxQjtBQUM3QyxTQUFLLGlCQUFpQixLQUFLO0FBQUEsRUFDN0I7QUFDRixDQUFDO0FBSUQsSUFBSSxRQUFRLFFBQVEsV0FBVztBQUM3QixVQUFRLE9BQU8sVUFBVSxZQUFZLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU0sUUFBUSxjQUFjLE9BQU87QUFBQSxJQUNyQyxTQUFTLEtBQUs7QUFFWixZQUFNLEtBQUssMENBQTBDLGNBQWMsR0FBRyxDQUFDO0FBQ3ZFLFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUFBLElBQ3hDO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFJQSxRQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsS0FBYyxZQUFZO0FBQy9ELE1BQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFHLFFBQU87QUFDbkMsU0FBTyxjQUFjLEdBQUcsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUN2QyxTQUFLLE1BQU8sMEJBQTBCLEVBQUUsTUFBTSxJQUFJLE1BQU0sR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQy9FLFVBQU07QUFBQSxFQUNSLENBQUM7QUFDSCxDQUFDO0FBRUQsU0FBUyxpQkFBaUIsR0FBaUM7QUFDekQsU0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFBWSxPQUFRLEVBQXlCLFNBQVM7QUFDbkY7QUFFQSxlQUFlLGNBQWMsS0FBdUM7QUFDbEUsVUFBUSxJQUFJLE1BQU07QUFBQSxJQUNoQixLQUFLO0FBQ0gsWUFBTSxpQkFBaUIsSUFBSSxVQUFVLElBQUksS0FBSyxJQUFJLFFBQVE7QUFDMUQsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdkUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssK0JBQStCLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdEUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxVQUFJLElBQUksVUFBVSxRQUFRO0FBQ3hCLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xELFdBQVcsSUFBSSxVQUFVLFNBQVM7QUFDaEMsY0FBTSxNQUFPLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDcEQsT0FBTztBQUNMLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xEO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxXQUFXLElBQUksTUFBTTtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxXQUFXO0FBQ2pCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFNBQVMsTUFBTTtBQUNyQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxZQUFZLElBQUksUUFBUSxNQUFNO0FBQ3BDLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGVBQWUsRUFBRSxhQUFhLElBQUksR0FBRyxDQUFDO0FBQzVDLFlBQU0sS0FBSyx3QkFBd0IsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQ2pELGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLG9CQUFvQixJQUFJO0FBQzlCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGNBQWM7QUFDcEIsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFDdEMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssZUFBZTtBQUNsQixZQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFlBQU0sTUFBTSxVQUFVLENBQUM7QUFDdkIsWUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLElBQUksQ0FBQztBQUNqQyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQ0UsYUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLHVCQUF1QjtBQUFBLEVBQ3REO0FBQ0Y7QUFJQSxlQUFlLGlCQUFpQixVQUFrQixLQUFhLFVBQWtDO0FBQy9GLE1BQUksa0JBQWtCLElBQUksUUFBUSxFQUFHO0FBQ3JDLE1BQUksQ0FBQyxnQkFBZ0IsSUFBSSxRQUFRLEVBQUc7QUFFcEMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQU9uQyxRQUFNLFVBQVUsSUFBSSxJQUFJLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUUxQyxNQUFJO0FBQ0osTUFBSTtBQUNGLGlCQUFhLFVBQVUsVUFBVTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsZ0JBQWdCO0FBQUEsSUFDbEIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxXQUFXLG1CQUFtQixVQUFVLEtBQUssVUFBVSxHQUFHO0FBQ2hFO0FBQUEsRUFDRjtBQUVBLE1BQUksV0FBVyxPQUFPLFdBQVcsRUFBRztBQUdwQyxRQUFNLFdBQVcsb0JBQUksSUFBOEI7QUFDbkQsYUFBVyxLQUFLLFdBQVcsUUFBUTtBQUNqQyxVQUFNLE1BQU0sU0FBUyxJQUFJLEVBQUUsY0FBYyxLQUFLLENBQUM7QUFDL0MsUUFBSSxLQUFLLENBQUM7QUFDVixhQUFTLElBQUksRUFBRSxnQkFBZ0IsR0FBRztBQUFBLEVBQ3BDO0FBRUEsYUFBVyxDQUFDLFFBQVEsTUFBTSxLQUFLLFVBQVU7QUFDdkMsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxLQUFLLFFBQVE7QUFDbkUsUUFBSSxRQUFRO0FBQ1osZUFBVyxLQUFLLFFBQVE7QUFDdEIsWUFBTSxXQUFXLElBQUksYUFBYSxFQUFFLFFBQVE7QUFDNUMsVUFBSSxVQUFVO0FBR1osaUJBQVMsZUFBZTtBQUN4QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsZ0JBQWdCLEVBQUU7QUFDM0IsaUJBQVMsY0FBYyxFQUFFO0FBQ3pCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsaUJBQWlCLEVBQUU7QUFDNUIsY0FBTSxPQUFPLFNBQVMsbUJBQW1CLFNBQVMsbUJBQW1CLFNBQVMsQ0FBQztBQUMvRSxjQUFNLE9BQU8sRUFBRSxtQkFBbUIsQ0FBQztBQUNuQyxZQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssZ0JBQWdCLEtBQUssY0FBYztBQUM1RCxtQkFBUyxtQkFBbUIsS0FBSyxJQUFJO0FBQUEsUUFDdkM7QUFBQSxNQUNGLE9BQU87QUFDTCxjQUFNLFVBQTBCLEVBQUUsR0FBRyxHQUFHLGdCQUFnQixJQUFJLE9BQU87QUFDbkUsWUFBSSxhQUFhLEVBQUUsUUFBUSxJQUFJO0FBQy9CLGlCQUFTO0FBQUEsTUFDWDtBQUNBLFVBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQ2hELFlBQUksbUJBQW1CLEtBQUssRUFBRSxRQUFRO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTSxpQkFBaUIsUUFBUSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsTUFBTTtBQUNuRSxRQUFJLFFBQVEsR0FBRztBQUNiLFlBQU0sS0FBSyxtQkFBbUI7QUFBQSxRQUM1QjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxPQUFPLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRTtBQUFBLE1BQ3ZDLENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsVUFBVSx1QkFBdUI7QUFDakUsWUFBTSxZQUFZLFFBQVEsV0FBVztBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsZ0JBQ2IsUUFDQSxJQUNBLFdBQ0EsVUFDb0I7QUFDcEIsUUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBQ3JDLE1BQUksSUFBSyxRQUFPO0FBQ2hCLFFBQU0sTUFBaUI7QUFBQSxJQUNyQixRQUFRLFNBQVM7QUFBQSxJQUNqQixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixpQkFBaUI7QUFBQSxJQUNqQixjQUFjLENBQUM7QUFBQSxJQUNmLG9CQUFvQixDQUFDO0FBQUEsSUFDckIsZ0JBQWdCLENBQUMsUUFBUTtBQUFBLElBQ3pCLFlBQVk7QUFBQSxFQUNkO0FBQ0EsUUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixRQUFNLEtBQUssZUFBZSxFQUFFLFFBQVEsS0FBSyxXQUFXLElBQUksTUFBTSxFQUFFLENBQUM7QUFDakUsU0FBTztBQUNUO0FBSUEsZUFBZSxtQkFBa0M7QUFDL0MsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFVBQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxlQUFlO0FBQzNDLFFBQUksT0FBTyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsZUFBZTtBQUN4RCxZQUFNLFlBQVksUUFBUSxNQUFNO0FBQUEsSUFDbEM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlLDhCQUE2QztBQUcxRCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELFlBQU0sWUFBWSxRQUFRLE1BQU07QUFBQSxJQUNsQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWUsU0FBUyxRQUErQjtBQUNyRCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLGFBQVcsVUFBVSxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ3JDLFVBQU0sWUFBWSxRQUFRLE1BQU07QUFBQSxFQUNsQztBQUNGO0FBRUEsZUFBZSxZQUFZLFFBQWdCLFFBQStCO0FBQ3hFLFFBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUNyQyxNQUFJLENBQUMsSUFBSztBQUNWLFFBQU0sU0FBUyxPQUFPLE9BQU8sSUFBSSxZQUFZO0FBQzdDLE1BQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsVUFBTSxlQUFlLE1BQU07QUFDM0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sS0FBSyx1Q0FBdUMsRUFBRSxPQUFPLENBQUM7QUFDNUQ7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFFBQU0sS0FBSyxXQUFXLElBQUksVUFBVTtBQUNwQyxRQUFNLE1BQU0sSUFBSSxXQUFXLE1BQU0sR0FBRyxFQUFFO0FBQ3RDLFFBQU0sVUFBVSxPQUFPLE1BQU0sSUFBSSxFQUFFLElBQUksV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUM3RCxRQUFNLFdBQVcsUUFBUSxNQUFNLElBQUksRUFBRSxJQUFJLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFFL0QsUUFBTSxVQUEwQjtBQUFBLElBQzlCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsSUFDaEIsYUFBYSxJQUFJO0FBQUEsSUFDakIsVUFBVSxJQUFJLGVBQWUsS0FBSyxHQUFHO0FBQUEsSUFDckMsWUFBWSxVQUFVO0FBQUEsSUFDdEIsWUFBWSxJQUFJO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFvQjtBQUFBLElBQ3hCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsSUFDaEIsYUFBYSxJQUFJO0FBQUEsSUFDakIsb0JBQW9CLElBQUk7QUFBQSxFQUMxQjtBQUVBLFFBQU0sWUFBWSxZQUFZLE1BQU0sSUFBSSxHQUFHLElBQUksT0FBTyxNQUFNLFNBQVMsT0FBTyxXQUFXLElBQUksS0FBSyxHQUFHLFNBQVMsV0FBVyxJQUFJLE1BQU0sQ0FBQztBQUVsSSxNQUFJO0FBQ0YsVUFBTSxPQUFPLFFBQVE7QUFBQSxNQUNuQixNQUFNO0FBQUEsTUFDTixlQUFlLFNBQVMsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLE1BQy9ELFNBQVM7QUFBQSxJQUNYLENBQUM7QUFDRCxVQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ25CLE1BQU07QUFBQSxNQUNOLGVBQWUsU0FBUyxLQUFLLFVBQVUsTUFBTSxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsTUFDNUQsU0FBUyxTQUFTLE1BQU0sSUFBSSxHQUFHLElBQUksS0FBSyxtQkFBbUIsTUFBTSxhQUFhLFdBQVcsSUFBSSxNQUFNLENBQUM7QUFBQSxJQUN0RyxDQUFDO0FBQ0QsVUFBTSxlQUFlLE1BQU07QUFDM0IsVUFBTSxZQUFZLFFBQVE7QUFBQSxNQUN4QixhQUFhLE1BQU0sWUFBWSxHQUFHLE1BQU0sR0FBRyxjQUFjO0FBQUEsTUFDekQsV0FBVztBQUFBLE1BQ1gsZUFBZSxJQUFJO0FBQUEsTUFDbkIsa0JBQWtCLE1BQU0sWUFBWSxHQUFHLE1BQU0sR0FBRyxrQkFBa0IsS0FBSyxPQUFPO0FBQUEsTUFDOUUsZUFBZTtBQUFBLElBQ2pCLENBQUM7QUFDRCxVQUFNLEtBQUssbUJBQW1CO0FBQUEsTUFDNUI7QUFBQSxNQUNBO0FBQUEsTUFDQSxRQUFRLE9BQU87QUFBQSxNQUNmLEtBQUssV0FBVyxJQUFJLE1BQU07QUFBQSxNQUMxQixNQUFNO0FBQUEsSUFDUixDQUFDO0FBQ0Q7QUFDRSxZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU8sS0FBSztBQUFBLFFBQ1osWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWUsS0FBSztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixRQUFJLGVBQWUsYUFBYTtBQUM5QixZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sU0FDSixJQUFJLGFBQWEsU0FDYixlQUNBLElBQUksYUFBYSxlQUNmLGlCQUNBLElBQUksYUFBYSxZQUNmLGtCQUNBLEtBQUs7QUFDZixZQUFNLGNBQWM7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTyxJQUFJO0FBQUEsUUFDWCxlQUFlLEtBQUs7QUFBQSxNQUN0QixDQUFDO0FBQ0QsWUFBTSxNQUFPLGdCQUFnQjtBQUFBLFFBQzNCO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVSxJQUFJO0FBQUEsUUFDZCxRQUFRLElBQUk7QUFBQSxRQUNaLFNBQVMsSUFBSTtBQUFBLE1BQ2YsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMLFlBQU0sTUFBTyxnQkFBZ0IsRUFBRSxRQUFRLFFBQVEsR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDeEU7QUFBQSxFQUVGLFVBQUU7QUFDQSxVQUFNLGVBQWU7QUFBQSxFQUN2QjtBQUNGO0FBSUEsZUFBZSxXQUFXLFFBQStCO0FBTXZELFFBQU0sWUFBWSxpQkFBaUIsTUFBTTtBQUN6QyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsUUFBUSxLQUFLLGVBQWUsQ0FBQztBQUNuRSxNQUFJLENBQUUsTUFBTSxhQUFhLE1BQU0sR0FBSTtBQUNqQyxVQUFNLE9BQU0sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDbkMsVUFBTSxhQUFhLFFBQVE7QUFBQSxNQUN6QixRQUFRLFNBQVM7QUFBQSxNQUNqQixnQkFBZ0I7QUFBQSxNQUNoQixZQUFZO0FBQUEsTUFDWixpQkFBaUI7QUFBQSxNQUNqQixjQUFjLENBQUM7QUFBQSxNQUNmLG9CQUFvQixDQUFDO0FBQUEsTUFDckIsZ0JBQWdCLENBQUM7QUFBQSxNQUNqQixZQUFZO0FBQUEsSUFDZCxDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFdBQVcsUUFBUSxLQUFLLENBQUM7QUFDNUQ7QUFFQSxlQUFlLGFBQTRCO0FBQ3pDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxLQUFLLHlCQUF5QixFQUFFLE9BQU8sU0FBUyxPQUFPLENBQUM7QUFDOUQsYUFBVyxLQUFLLFVBQVU7QUFDeEIsVUFBTSxXQUFXLEVBQUUsTUFBTTtBQUFBLEVBQzNCO0FBQ0Y7QUFJQSxlQUFlLFdBQ2IsUUFDQSxVQUNBLEtBQ0EsS0FDQSxLQUNlO0FBQ2YsUUFBTSxNQUFPLHdCQUF3QixFQUFFLFFBQVEsVUFBVSxLQUFLLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUNyRixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLEtBQU07QUFDeEQsUUFBTSxVQUE2QjtBQUFBLElBQ2pDLGdCQUFnQjtBQUFBLElBQ2hCO0FBQUEsSUFDQTtBQUFBLElBQ0EsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3BDLFlBQVk7QUFBQSxJQUNaLE9BQU8sY0FBYyxHQUFHO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxLQUFLLFdBQVcsUUFBUSxXQUFXO0FBQ3pDLFFBQU0sT0FBTyxNQUFNLEtBQUssS0FBSyxVQUFVLE9BQU8sQ0FBQztBQUMvQyxRQUFNLE9BQU8sbUJBQW1CLEVBQUUsSUFBSSxJQUFJO0FBQzFDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxPQUFPLFFBQVE7QUFBQSxNQUNuQjtBQUFBLE1BQ0EsZUFBZSxTQUFTLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUMvRCxTQUFTLGVBQWUsTUFBTSxJQUFJLFFBQVE7QUFBQSxJQUM1QyxDQUFDO0FBQUEsRUFDSCxTQUFTLE1BQU07QUFDYixVQUFNLE1BQU8sNEJBQTRCLEVBQUUsR0FBRyxjQUFjLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDckU7QUFDRjtBQUVBLGVBQWUsS0FBSyxHQUE0QjtBQUM5QyxRQUFNLE1BQU0sSUFBSSxZQUFZLEVBQUUsT0FBTyxDQUFDO0FBQ3RDLFFBQU0sU0FBUyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsR0FBRztBQUN4RCxRQUFNLE1BQU0sTUFBTSxLQUFLLElBQUksV0FBVyxNQUFNLENBQUMsRUFDMUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRTtBQUNWLFNBQU8sSUFBSSxNQUFNLEdBQUcsQ0FBQztBQUN2QjtBQUlBLGVBQWUsaUJBQWlCLE9BQStCO0FBQzdELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsTUFBTTtBQUN0RCxVQUFNLGNBQWM7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUixPQUFPO0FBQUEsTUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZTtBQUFBLElBQ2pCLENBQUM7QUFDRCxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxNQUFJLENBQUMsU0FBUyxLQUFLLFdBQVcsUUFBUSxLQUFLLFdBQVc7QUFDcEQsVUFBTSxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVM7QUFDbEQsUUFBSSxNQUFNLDhCQUErQjtBQUFBLEVBQzNDO0FBQ0EsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLElBQUksTUFBTSxPQUFPLGlCQUFpQjtBQUN4QyxVQUFNLGNBQWM7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUixPQUFPLEVBQUU7QUFBQSxNQUNULFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsTUFDUCxlQUFlLEVBQUU7QUFBQSxJQUNuQixDQUFDO0FBQ0QsVUFBTSxLQUFLLHVCQUF1QjtBQUFBLE1BQ2hDLE9BQU8sRUFBRTtBQUFBLE1BQ1QsTUFBTSxFQUFFO0FBQUEsTUFDUixnQkFBZ0IsRUFBRTtBQUFBLE1BQ2xCLG1CQUFtQixTQUFTO0FBQUEsSUFDOUIsQ0FBQztBQUNELFFBQUksU0FBUyxVQUFVLFNBQVMsV0FBVyxFQUFFLGdCQUFnQjtBQUszRCxZQUFNLFdBQVcsTUFBTSxPQUFPLGFBQWEsU0FBUyxNQUFNO0FBQzFELFVBQUksQ0FBQyxVQUFVO0FBQ2IsY0FBTSxLQUFLLDhDQUE4QztBQUFBLFVBQ3ZELFlBQVksU0FBUztBQUFBLFVBQ3JCLGdCQUFnQixFQUFFO0FBQUEsVUFDbEIsS0FBSyx3Q0FBd0MsRUFBRTtBQUFBLFFBQ2pELENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFNLGVBQWUsY0FBYyxJQUFJLFdBQVc7QUFDeEQsVUFBTSxTQUNKLFFBQVEsU0FDSixlQUNBLFFBQVEsZUFDTixpQkFDQSxRQUFRLFlBQ04sa0JBQ0E7QUFDVixVQUFNLGNBQWM7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU8sY0FBYyxHQUFHLEVBQUU7QUFBQSxNQUMxQixlQUFlO0FBQUEsSUFDakIsQ0FBQztBQUNELFVBQU0sS0FBSywyQkFBMkIsRUFBRSxVQUFVLEtBQUssR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDaEY7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLG9CQUFvQixPQUErQjtBQUNoRSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLEtBQUs7QUFDakIsVUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QztBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxNQUFNLE9BQU8sYUFBYSxzQkFBc0I7QUFDN0QsUUFBSSxDQUFDLE1BQU07QUFDVCxVQUFJLE1BQU8sT0FBTSxLQUFLLGlEQUFpRDtBQUN2RSxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDO0FBQUEsSUFDRjtBQUNBLFVBQU0sU0FBUyxrQkFBa0IsSUFBSTtBQUNyQyxRQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFlBQU0sS0FBSyw4Q0FBOEM7QUFDekQsWUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QztBQUFBLElBQ0Y7QUFDQSxVQUFNLFlBQVksTUFBTTtBQUN4QixRQUFJLE1BQU8sT0FBTSxLQUFLLDJCQUEyQixFQUFFLE9BQU8sT0FBTyxPQUFPLENBQUM7QUFBQSxFQUMzRSxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaURBQWlELGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDaEY7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFJQSxlQUFlLGlCQUFnQztBQUM3QyxRQUFNLFFBQVEsTUFBTSxXQUFXO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsTUFBTSxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFO0FBRUEsZUFBZSxhQUFzQztBQUNuRCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFNBQU87QUFBQSxJQUNMLFNBQVM7QUFBQSxJQUNULFVBQVUsZUFBZSxRQUFRO0FBQUEsSUFDakMsWUFBWTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyxlQUFlLEdBQXlDO0FBQy9ELFNBQU87QUFBQSxJQUNMLE9BQU8sRUFBRTtBQUFBLElBQ1QsTUFBTSxFQUFFO0FBQUEsSUFDUixRQUFRLEVBQUU7QUFBQSxJQUNWLGFBQWEsRUFBRTtBQUFBLElBQ2YsY0FBYyxFQUFFO0FBQUEsSUFDaEIsUUFBUSxFQUFFLElBQUksU0FBUztBQUFBLElBQ3ZCLFdBQVcsRUFBRSxJQUFJLFVBQVUsSUFBSSxFQUFFLElBQUksTUFBTSxFQUFFLElBQUk7QUFBQSxFQUNuRDtBQUNGO0FBRUEsU0FBUyxXQUFXLEtBQXFCO0FBRXZDLFFBQU0sSUFBSSxJQUFJLEtBQUssR0FBRztBQUN0QixNQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU8sSUFBSSxRQUFRLFNBQVMsRUFBRTtBQUM3RCxRQUFNLE1BQU0sQ0FBQyxHQUFXLElBQUksTUFBTSxPQUFPLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUMzRCxTQUNFLEdBQUcsRUFBRSxlQUFlLENBQUMsSUFBSSxJQUFJLEVBQUUsWUFBWSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUNwRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7QUFFOUU7QUFFQSxTQUFTLFVBQVUsR0FBcUI7QUFDdEMsU0FBTyxXQUFXLEVBQUUsS0FBSyxjQUFjLEVBQUUsSUFBSTtBQUMvQztBQUVBLFNBQVMsV0FBVyxHQUFtQjtBQUdyQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksSUFBSSxDQUFDO0FBQ3hCLFVBQU0sT0FBTyxPQUFPLFlBQVksT0FBTyxTQUFTLFlBQU87QUFDdkQsV0FBTyxPQUFPLFNBQVMsV0FBVyxPQUFPLFNBQVMsZ0JBQzlDLE9BQ0EsR0FBRyxPQUFPLElBQUksR0FBRyxJQUFJO0FBQUEsRUFDM0IsUUFBUTtBQUNOLFdBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUFBLEVBQ2hEO0FBQ0Y7QUFLQyxXQUF1QyxlQUFlO0FBQUEsRUFDckQ7QUFBQSxFQUNBLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFNBQVM7QUFBQSxFQUNULFVBQVUsTUFBTSxTQUFTLFVBQVU7QUFBQSxFQUNuQyxPQUFPO0FBQ1Q7IiwKICAibmFtZXMiOiBbIm9iaiIsICJpbmZvIl0KfQo=
