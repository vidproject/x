// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, partial_ids };
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  return { tweet_id: restId, hint_handle: pickHintHandle(node) };
}
function pickHintHandle(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name);
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted) {
  if (targeted.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.retweeted_tweet_id && targetedTweetIds.has(t.retweeted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let expandedCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        // Cast: the @types/firefox-webext-browser type signature insists
        // `func` returns void, but the API actually surfaces the return
        // value via `result[0].result`. We use that for the expand count.
        func: () => {
          const SHOW_MORE_SELECTORS = [
            '[data-testid="tweet-text-show-more-link"]',
            'button[data-testid="tweet-text-show-more-link"]',
            'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
          ];
          const clicked = /* @__PURE__ */ new Set();
          let expanded = 0;
          for (const sel of SHOW_MORE_SELECTORS) {
            for (const el of Array.from(document.querySelectorAll(sel))) {
              if (clicked.has(el)) continue;
              const t = (el.textContent || "").trim().toLowerCase();
              if (t !== "show more" && t !== "show this thread") continue;
              const rect = el.getBoundingClientRect();
              if (rect.width === 0 || rect.height === 0) continue;
              clicked.add(el);
              try {
                el.click();
                expanded += 1;
              } catch {
              }
            }
          }
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { expanded };
        }
      });
      scrollCount += 1;
      const r = results[0]?.result;
      if (r && typeof r.expanded === "number") expandedCount += r.expanded;
    } catch {
    }
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      sess.expandedCount += expandedCount;
      await setAutoScrollSession(sess);
    }
  }
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set()
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.tweets.length === 0) return;
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const committedIdx = await getCommittedIndex();
  let dedupedSkipped = 0;
  const liveTweets = [];
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      continue;
    }
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (liveTweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, Object.keys(buf.tweets_by_id).length);
    if (added > 0) {
      await info("captured tweets", {
        handle,
        endpoint,
        added,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    if (tweets.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      idx[item.handle] = inner;
      await info("flush committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("flush batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return Object.keys(current.tweets_by_id).length;
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingCount = Object.keys(remainingTweets).length;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => id in remainingTweets)
  });
  await info("flush kept newer buffered tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = target.bucket === "_unknown" ? `https://x.com/i/status/${target.tweetId}` : `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const autoScrollSess = await getAutoScrollSession();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    }
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xyXG4gIHBhdDogJycsXHJcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcclxuICByZXBvOiAneCcsXHJcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxyXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXHJcbiAgYnJhbmNoOiAnbWFzdGVyJyxcclxuICBlbmFibGVkOiB0cnVlLFxyXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxyXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcclxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XHJcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XHJcblxyXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxyXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXHJcbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xyXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuXTtcclxuXHJcbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXHJcbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG4gICdMaWtlcycsXHJcbiAgJ0Jvb2ttYXJrcycsXHJcbiAgJ0hvbWVUaW1lbGluZScsXHJcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXHJcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcclxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcclxuXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XHJcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXHJcbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXHJcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxyXG5dKTtcclxuXHJcbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxyXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxyXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3JcclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxyXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcclxuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXHJcbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXHJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcclxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxyXG4vL1xyXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcclxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXHJcbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cclxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG5dKTtcclxuXHJcbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxyXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xyXG5cclxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcclxuXHJcbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XHJcblxyXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXHJcbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcclxuXHJcbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cclxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XHJcblxyXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcclxuIiwgIi8qKlxyXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cclxuICpcclxuICogVGhyZWF0IG1vZGVsOiBhbiBhdHRhY2tlciB3aG8gcmVhZHMgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgKGRldnRvb2xzLCBhXHJcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXHJcbiAqIEdpdEh1YiBQQVQgaW4gcGxhaW50ZXh0LiBBIGRldGVybWluZWQgYXR0YWNrZXIgd2l0aCB0aGUgZXh0ZW5zaW9uJ3Mgc291cmNlXHJcbiAqIGNhbiBzdGlsbCBkZXJpdmUgdGhlIGtleSBcdTIwMTQgd2UgbWFrZSBubyBjbGFpbSBvZiBcInJlYWxcIiBjcnlwdG9ncmFwaGljXHJcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxyXG4gKiBzdHJpbmcgc2l0dGluZyBuZXh0IHRvIGl0cyBrZXkgbmFtZSBpbiBleHRlbnNpb24gc3RvcmFnZS5cclxuICpcclxuICogU2NoZW1lOlxyXG4gKiAgIC0gT24gZmlyc3QgZW5jcnlwdGlvbiB3ZSBnZW5lcmF0ZSBhIDMyLWJ5dGUgc2FsdCBhbmQgcGVyc2lzdCBpdCBpblxyXG4gKiAgICAgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgdW5kZXIgYF9faW1tX2FyY2hpdmVfc2FsdF9fYC5cclxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cclxuICogICAgIHx8IFwiaW1tLWFyY2hpdmUtcGF0LXYxXCJgLiBUaGUgc2FsdCBiZWluZyBwZXItaW5zdGFsbCBtZWFucyB0d28gY29waWVzXHJcbiAqICAgICBvZiB0aGUgZXh0ZW5zaW9uIGRvbid0IHNoYXJlIGEga2V5LiBUaGUgcnVudGltZS5pZCBpcyB0aGUgZXh0ZW5zaW9uJ3NcclxuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxyXG4gKiAgIC0gUGxhaW50ZXh0IGlzIGVuY3J5cHRlZCB3aXRoIGEgZnJlc2ggMTItYnl0ZSBJVi4gVGhlIGVudmVsb3BlIGZvcm1hdCBpc1xyXG4gKiAgICAgYHYxOjxpdi1iNjQ+OjxjaXBoZXJ0ZXh0LWI2ND5gIGFuZCBpcyB3aGF0IGdldHMgc3RvcmVkLlxyXG4gKlxyXG4gKiBCYWNrd2FyZHMgY29tcGF0aWJpbGl0eTogYW4gdW5wcmVmaXhlZCB2YWx1ZSBpcyB0cmVhdGVkIGFzIGxlZ2FjeVxyXG4gKiBwbGFpbnRleHQsIGRlY3J5cHRlZCB0byBpdHNlbGYsIGFuZCByZS1lbmNyeXB0ZWQgb24gdGhlIG5leHQgd3JpdGUuXHJcbiAqL1xyXG5cclxuY29uc3QgU0FMVF9TVE9SQUdFX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3NhbHRfXyc7XHJcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xyXG5cclxubGV0IGRlcml2ZWRLZXlDYWNoZTogQ3J5cHRvS2V5IHwgbnVsbCA9IG51bGw7XHJcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHRvQmFzZTY0KGJ1ZjogVWludDhBcnJheSk6IHN0cmluZyB7XHJcbiAgbGV0IHMgPSAnJztcclxuICBmb3IgKGNvbnN0IGIgb2YgYnVmKSBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYik7XHJcbiAgcmV0dXJuIGJ0b2Eocyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZyb21CYXNlNjQoczogc3RyaW5nKTogVWludDhBcnJheSB7XHJcbiAgY29uc3QgYmluID0gYXRvYihzKTtcclxuICBjb25zdCBvdXQgPSBuZXcgVWludDhBcnJheShiaW4ubGVuZ3RoKTtcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IGJpbi5sZW5ndGg7IGkrKykgb3V0W2ldID0gYmluLmNoYXJDb2RlQXQoaSk7XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcclxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFNBTFRfU1RPUkFHRV9LRVkpO1xyXG4gIGNvbnN0IHYgPSBzdG9yZWRbU0FMVF9TVE9SQUdFX0tFWV07XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcclxuICAgIHJldHVybiB7IHNhbHRCNjQ6IHYsIHNhbHQ6IGZyb21CYXNlNjQodikgfTtcclxuICB9XHJcbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcclxuICBjb25zdCBzYWx0QjY0ID0gdG9CYXNlNjQoc2FsdCk7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtTQUxUX1NUT1JBR0VfS0VZXTogc2FsdEI2NCB9KTtcclxuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xyXG4gIGNvbnN0IHsgc2FsdEI2NCwgc2FsdCB9ID0gYXdhaXQgbG9hZE9yQ3JlYXRlU2FsdCgpO1xyXG4gIGlmIChkZXJpdmVkS2V5Q2FjaGUgIT09IG51bGwgJiYgZGVyaXZlZEtleUNhY2hlU2FsdCA9PT0gc2FsdEI2NCkge1xyXG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcclxuICB9XHJcbiAgY29uc3Qgc2VlZCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcclxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXHJcbiAgKTtcclxuICBjb25zdCBjb21iaW5lZCA9IG5ldyBVaW50OEFycmF5KHNlZWQubGVuZ3RoICsgc2FsdC5sZW5ndGgpO1xyXG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcclxuICBjb21iaW5lZC5zZXQoc2FsdCwgc2VlZC5sZW5ndGgpO1xyXG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGNvbWJpbmVkKTtcclxuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcclxuICAgICdlbmNyeXB0JyxcclxuICAgICdkZWNyeXB0JyxcclxuICBdKTtcclxuICBkZXJpdmVkS2V5Q2FjaGUgPSBrZXk7XHJcbiAgZGVyaXZlZEtleUNhY2hlU2FsdCA9IHNhbHRCNjQ7XHJcbiAgcmV0dXJuIGtleTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gIHJldHVybiB2LnN0YXJ0c1dpdGgoRU5WRUxPUEVfUFJFRklYKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVuY3J5cHRQYXQocGxhaW50ZXh0OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIGlmICghcGxhaW50ZXh0KSByZXR1cm4gJyc7XHJcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XHJcbiAgY29uc3QgaXYgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEyKSk7XHJcbiAgY29uc3QgY3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmVuY3J5cHQoXHJcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcclxuICAgIGtleSxcclxuICAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShwbGFpbnRleHQpXHJcbiAgKTtcclxuICByZXR1cm4gYCR7RU5WRUxPUEVfUFJFRklYfSR7dG9CYXNlNjQoaXYpfToke3RvQmFzZTY0KG5ldyBVaW50OEFycmF5KGN0KSl9YDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlY3J5cHRQYXQoZW52ZWxvcGU6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgaWYgKCFlbnZlbG9wZSkgcmV0dXJuICcnO1xyXG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXHJcbiAgLy8gcmUtZW5jcnlwdHMgaXQgdmlhIHRoZSBzdG9yYWdlIGxheWVyLlxyXG4gIGlmICghZW52ZWxvcGUuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpKSByZXR1cm4gZW52ZWxvcGU7XHJcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xyXG4gIGlmIChwYXJ0cy5sZW5ndGggIT09IDIpIHJldHVybiAnJztcclxuICBjb25zdCBbaXZCNjQsIGN0QjY0XSA9IHBhcnRzO1xyXG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGtleSA9IGF3YWl0IGRlcml2ZUtleSgpO1xyXG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcclxuICAgIGNvbnN0IGN0ID0gZnJvbUJhc2U2NChjdEI2NCk7XHJcbiAgICBjb25zdCBwdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGVjcnlwdChcclxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcclxuICAgICAga2V5LFxyXG4gICAgICBjdCBhcyBCdWZmZXJTb3VyY2VcclxuICAgICk7XHJcbiAgICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKHB0KTtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiAnJztcclxuICB9XHJcbn1cclxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcclxuaW1wb3J0IHsgZGVjcnlwdFBhdCwgZW5jcnlwdFBhdCwgaXNFbmNyeXB0ZWRQYXQgfSBmcm9tICcuL2NyeXB0by5qcyc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBBY2NvdW50Q29uZmlnLFxyXG4gIEFjY291bnRDb3VudGVyLFxyXG4gIENhbm9uaWNhbFR3ZWV0LFxyXG4gIENvbm5lY3Rpb25TdGF0ZSxcclxuICBMb2dFdmVudCxcclxuICBTZXR0aW5ncyxcclxufSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbi8qKlxyXG4gKiBCdWZmZXJlZCB0d2VldHMgZm9yIGEgZ2l2ZW4gYWNjb3VudCwgYXdhaXRpbmcgY29tbWl0LiBBIFwicnVuXCIgaXMgb25lIGVudHJ5XHJcbiAqIGluIHRoaXMgbWFwOyBmbHVzaGluZyBjbGVhcnMgdGhlIGVudHJ5LiBXZSBzdG9yZSBhcyBSZWNvcmQgc28gdGhlIHN0cnVjdHVyZVxyXG4gKiBzdXJ2aXZlcyBKU09OIHNlcmlhbGl6YXRpb24gdGhyb3VnaCBicm93c2VyLnN0b3JhZ2UuXHJcbiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIFJ1bkJ1ZmZlciB7XHJcbiAgcnVuX2lkOiBzdHJpbmc7XHJcbiAgYWNjb3VudF9oYW5kbGU6IHN0cmluZztcclxuICBzdGFydGVkX2F0OiBzdHJpbmc7XHJcbiAgbGFzdF9jYXB0dXJlX2F0OiBzdHJpbmc7XHJcbiAgdHdlZXRzX2J5X2lkOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD47XHJcbiAgdHdlZXRfaWRzX29ic2VydmVkOiBzdHJpbmdbXTtcclxuICBlbmRwb2ludHNfc2Vlbjogc3RyaW5nW107XHJcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcclxufVxyXG5cclxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxyXG4gKiBVc2VkIHRvIHNraXAgcmUtY2FwdHVyaW5nIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IHB1c2hlZCB3aXRoIGlkZW50aWNhbFxyXG4gKiBlbmdhZ2VtZW50IGNvdW50cyBcdTIwMTQgYXZvaWRzIGdlbmVyYXRpbmcgb25lIG5ldyByYXcvKiBmaWxlIGV2ZXJ5IGJyb3dzZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XHJcbiAgdHM6IHN0cmluZzsgLy8gSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBjb21taXRcclxuICBzaWc6IHN0cmluZzsgLy8gZW5nYWdlbWVudCBzaWduYXR1cmU6IFwibGlrZXxydHxyZXBseXxxdW90ZVwiXHJcbn1cclxuXHJcbi8qKiBQcm9ncmVzcyArIGluZmxpZ2h0IHRyYWNraW5nIGZvciBhIHF1ZXVlLWRyaXZlbiBsb29wIChyZWZldGNoIC8gbWVkaWEtY3Jhd2wpLlxyXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcclxuICogXCJYIG9mIFkgcHJvY2Vzc2VkXCIgXHUyMDE0IGFuZCB0aGUgd2FpdC1mb3ItaW5nZXN0IGd1YXJkIGtub3dzIHdoYXQgdG8gZXhwZWN0LlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XHJcbiAgLyoqIEluaXRpYWwgcXVldWUgc2l6ZSB3aGVuIHRoZSB1c2VyIGNsaWNrZWQgXCJTdGFydFwiLiAqL1xyXG4gIHRvdGFsQXRTdGFydDogbnVtYmVyO1xyXG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cclxuICBwcm9jZXNzZWQ6IG51bWJlcjtcclxuICAvKiogSVNPIG9mIHdoZW4gdGhpcyBzZXNzaW9uIHN0YXJ0ZWQuICovXHJcbiAgc3RhcnRlZEF0OiBzdHJpbmc7XHJcbiAgLyoqIFR3ZWV0IGN1cnJlbnRseSBpbmZsaWdodCBcdTIwMTQgd2UgbmF2aWdhdGVkIHRvIGl0IGFuZCBhcmUgd2FpdGluZyBmb3IgdGhlXHJcbiAgICogcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIHJlc3BvbnNlIGJlZm9yZSBhZHZhbmNpbmcuIG51bGwgYmV0d2VlbiB0aWNrc1xyXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xyXG4gIGluZmxpZ2h0OiB7IHR3ZWV0SWQ6IHN0cmluZzsgbmF2aWdhdGVkQXQ6IHN0cmluZyB9IHwgbnVsbDtcclxufVxyXG5cclxuLyoqIEF1dG8tc2Nyb2xsIHNlc3Npb246IGNvdW50cyBvZiB0aWNrcyBhbmQgdHdlZXRzIGluZ2VzdGVkIHNpbmNlIHRoZSB1c2VyXHJcbiAqIGNsaWNrZWQgU3RhcnQuIFBlcnNpc3RlZCBzbyBTVyBldmljdGlvbiBkdXJpbmcgYSBydW4ga2VlcHMgcHJvZ3Jlc3MuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xyXG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xyXG4gIHNjcm9sbENvdW50OiBudW1iZXI7XHJcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xyXG4gIGV4cGFuZGVkQ291bnQ6IG51bWJlcjtcclxufVxyXG5cclxuaW50ZXJmYWNlIFN0b3JhZ2VTaGFwZSB7XHJcbiAgc2V0dGluZ3M6IFNldHRpbmdzO1xyXG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XHJcbiAgLyoqIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3Qgc3VjY2Vzc2Z1bCBhY2NvdW50cy55YW1sIGZldGNoIGZyb20gdGhlIHJlcG8uXHJcbiAgICogVXNlZCBieSBgcmVmcmVzaEFjY291bnRzTGlzdGAgdG8gc2tpcCByZS1mZXRjaGluZyBvbiBldmVyeSBTVyB3YWtlIFx1MjAxNCB0aGVcclxuICAgKiBmaWxlIGNoYW5nZXMgcmFyZWx5IGFuZCBhbiBhdXRoZW50aWNhdGVkIHJhdyBmZXRjaCBldmVyeSB3YWtlIGFkZHMgdXAuICovXHJcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogc3RyaW5nIHwgbnVsbDtcclxuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uU3RhdGU7XHJcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcclxuICBydW5CdWZmZXJzOiBSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+O1xyXG4gIGFjdGl2aXR5OiBMb2dFdmVudFtdO1xyXG4gIGNvbW1pdHRlZEluZGV4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+O1xyXG4gIC8qKiBUd2VldHMgdGhlIG5vcm1hbGl6ZXIgZmxhZ2dlZCBhcyB0cnVuY2F0ZWQgYW5kIHRoYXQgd2UgaGF2ZW4ndCBzZWVuIGFcclxuICAgKiBmdWxsLXRleHQgdmVyc2lvbiBvZiB5ZXQuIEtleWVkIGJ5IGhhbmRsZSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiAqL1xyXG4gIHJlZmV0Y2hRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xyXG4gIC8qKiBUd2VldCBJRHMgc2VlbiB2aWEgTWVkaWEtdGFiIC8gcGFydGlhbCBjYXB0dXJlcyB0aGF0IGNvdWxkbid0IGJlXHJcbiAgICogbm9ybWFsaXplZCBpbnRvIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIEtleWVkIGJ5IGhpbnQtaGFuZGxlIChvclxyXG4gICAqIFwiX3Vua25vd25cIikgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gVGhlIHVzZXIgY2FuIGRyaXZlIGEgY3Jhd2wgdGhhdFxyXG4gICAqIG9wZW5zIGVhY2ggZGV0YWlsIHBhZ2UgdG8gY2FwdHVyZSB0aGUgcmVhbCB0aGluZy4gKi9cclxuICBtZWRpYUNyYXdsUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcclxuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xyXG4gIG1lZGlhQ3Jhd2xTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XHJcbiAgYXV0b1Njcm9sbFNlc3Npb246IEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbDtcclxufVxyXG5cclxuY29uc3QgREVGQVVMVF9DT05ORUNUSU9OOiBDb25uZWN0aW9uU3RhdGUgPSB7XHJcbiAgc3RhdHVzOiAndW5rbm93bicsXHJcbiAgbG9naW46IG51bGwsXHJcbiAgY2hlY2tlZEF0OiBudWxsLFxyXG4gIGVycm9yOiBudWxsLFxyXG4gIGRlZmF1bHRCcmFuY2g6IG51bGwsXHJcbiAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcclxuICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxyXG59O1xyXG5cclxuY29uc3QgREVGQVVMVFM6IFN0b3JhZ2VTaGFwZSA9IHtcclxuICBzZXR0aW5nczogeyAuLi5ERUZBVUxUX1NFVFRJTkdTIH0sXHJcbiAgYWNjb3VudHM6IFsuLi5GQUxMQkFDS19BQ0NPVU5UU10sXHJcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogbnVsbCxcclxuICBjb25uZWN0aW9uOiB7IC4uLkRFRkFVTFRfQ09OTkVDVElPTiB9LFxyXG4gIGNvdW50ZXJzOiB7fSxcclxuICBydW5CdWZmZXJzOiB7fSxcclxuICBhY3Rpdml0eTogW10sXHJcbiAgY29tbWl0dGVkSW5kZXg6IHt9LFxyXG4gIHJlZmV0Y2hRdWV1ZToge30sXHJcbiAgbWVkaWFDcmF3bFF1ZXVlOiB7fSxcclxuICByZWZldGNoU2Vzc2lvbjogbnVsbCxcclxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcclxuICBhdXRvU2Nyb2xsU2Vzc2lvbjogbnVsbCxcclxufTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEspOiBQcm9taXNlPFN0b3JhZ2VTaGFwZVtLXT4ge1xyXG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoa2V5KTtcclxuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xyXG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICByZXR1cm4gc3RydWN0dXJlZENsb25lKERFRkFVTFRTW2tleV0pO1xyXG4gIH1cclxuICByZXR1cm4gdmFsdWUgYXMgU3RvcmFnZVNoYXBlW0tdO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLLCB2YWx1ZTogU3RvcmFnZVNoYXBlW0tdKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtrZXldOiB2YWx1ZSB9KTtcclxufVxyXG5cclxuLy8gLS0tIFNldHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XHJcbiAgLy8gQmFja2ZpbGwgYW55IGtleXMgdGhlIHVzZXIncyBzdG9yZWQgc2V0dGluZ3MgcHJlZGF0ZSBcdTIwMTQgcmVhZGVycyBjYW4gcmVseVxyXG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XHJcbiAgLy8gZXZlcnkgY2FsbHNpdGUuIFRoZSBQQVQgaXMgc3RvcmVkIGVuY3J5cHRlZC1hdC1yZXN0IGFzIG9mIHYwLjIuMDsgd2VcclxuICAvLyBkZWNyeXB0IHRyYW5zcGFyZW50bHkgc28gY2FsbGVycyBjb250aW51ZSB0byBzZWUgcGxhaW50ZXh0LlxyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcclxuICBjb25zdCBtZXJnZWQgPSB7IC4uLkRFRkFVTFRfU0VUVElOR1MsIC4uLnN0b3JlZCB9O1xyXG4gIGlmIChtZXJnZWQucGF0ICYmIGlzRW5jcnlwdGVkUGF0KG1lcmdlZC5wYXQpKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBtZXJnZWQucGF0ID0gYXdhaXQgZGVjcnlwdFBhdChtZXJnZWQucGF0KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBtZXJnZWQucGF0ID0gJyc7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBtZXJnZWQ7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXHJcbiAgLy8gb24gdGhlIG5leHQgc2F2ZS5cclxuICBjb25zdCB0b1dyaXRlOiBTZXR0aW5ncyA9IHsgLi4ucyB9O1xyXG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XHJcbiAgICB0b1dyaXRlLnBhdCA9IGF3YWl0IGVuY3J5cHRQYXQodG9Xcml0ZS5wYXQpO1xyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHBhdGNoOiBQYXJ0aWFsPFNldHRpbmdzPik6IFByb21pc2U8U2V0dGluZ3M+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IG5leHQgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcclxuICBhd2FpdCBzZXRTZXR0aW5ncyhuZXh0KTtcclxuICByZXR1cm4gbmV4dDtcclxufVxyXG5cclxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50cygpOiBQcm9taXNlPEFjY291bnRDb25maWdbXT4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzKGE6IEFjY291bnRDb25maWdbXSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzUmVmcmVzaGVkQXQoaXNvOiBzdHJpbmcgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcclxufVxyXG5cclxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb24oKTogUHJvbWlzZTxDb25uZWN0aW9uU3RhdGU+IHtcclxuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XHJcbiAgLy8gQmFja2ZpbGwgZmllbGRzIGFkZGVkIGFmdGVyIHRoZSB1c2VyJ3Mgc3RvcmFnZSB3YXMgd3JpdHRlbi5cclxuICBjb25zdCBvdXQ6IENvbm5lY3Rpb25TdGF0ZSA9IHtcclxuICAgIC4uLmMsXHJcbiAgICBkZWZhdWx0QnJhbmNoOiBjLmRlZmF1bHRCcmFuY2ggPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmRlZmF1bHRCcmFuY2gsXHJcbiAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOlxyXG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXHJcbiAgICByYXRlTGltaXRSZXNldEF0OiBjLnJhdGVMaW1pdFJlc2V0QXQgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLnJhdGVMaW1pdFJlc2V0QXQsXHJcbiAgfTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb25uZWN0aW9uKGM6IENvbm5lY3Rpb25TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xyXG59XHJcblxyXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZnVuY3Rpb24gdG9kYXlJU08oKTogc3RyaW5nIHtcclxuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnY291bnRlcnMnKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXHJcbiAgaGFuZGxlOiBzdHJpbmcsXHJcbiAgcGF0Y2g6IFBhcnRpYWw8QWNjb3VudENvdW50ZXI+XHJcbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRDb3VudGVycygpO1xyXG4gIGNvbnN0IGN1ciA9IGFsbFtoYW5kbGVdID8/IHtcclxuICAgIHRvZGF5Q291bnQ6IDAsXHJcbiAgICB0b2RheURhdGU6IHRvZGF5SVNPKCksXHJcbiAgICBsYXN0Q2FwdHVyZUF0OiBudWxsLFxyXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXHJcbiAgICBidWZmZXJlZENvdW50OiAwLFxyXG4gIH07XHJcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcclxuICAgIGN1ci50b2RheURhdGUgPSB0b2RheUlTTygpO1xyXG4gICAgY3VyLnRvZGF5Q291bnQgPSAwO1xyXG4gIH1cclxuICBjb25zdCBuZXh0OiBBY2NvdW50Q291bnRlciA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xyXG4gIGFsbFtoYW5kbGVdID0gbmV4dDtcclxuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcclxuICByZXR1cm4gbmV4dDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlOiBzdHJpbmcsIGNvdW50OiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHsgYnVmZmVyZWRDb3VudDogY291bnQgfSk7XHJcbn1cclxuXHJcbi8vIC0tLSBSdW4gYnVmZmVycyAodGhlIHBlbmRpbmcgY2FwdHVyZXMgYXdhaXRpbmcgY29tbWl0KSAtLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5CdWZmZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3J1bkJ1ZmZlcnMnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8UnVuQnVmZmVyIHwgbnVsbD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICByZXR1cm4gYWxsW2hhbmRsZV0gPz8gbnVsbDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZywgYnVmOiBSdW5CdWZmZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgYWxsW2hhbmRsZV0gPSBidWY7XHJcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyUnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcclxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xyXG59XHJcblxyXG4vLyAtLS0gQWN0aXZpdHkgdGFpbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjdGl2aXR5Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBlbmRBY3Rpdml0eShldjogTG9nRXZlbnQpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRBY3Rpdml0eSgpO1xyXG4gIGN1ci51bnNoaWZ0KGV2KTtcclxuICBpZiAoY3VyLmxlbmd0aCA+IEFDVElWSVRZX1RBSUxfTUFYKSBjdXIubGVuZ3RoID0gQUNUSVZJVFlfVEFJTF9NQVg7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIGN1cik7XHJcbiAgcmV0dXJuIGN1cjtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIFtdKTtcclxufVxyXG5cclxuLy8gLS0tIENvbW1pdHRlZC10d2VldHMgZGVkdXAgaW5kZXggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2NvbW1pdHRlZEluZGV4Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb21taXR0ZWRJbmRleChcclxuICBpZHg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj5cclxuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdjb21taXR0ZWRJbmRleCcsIGlkeCk7XHJcbn1cclxuXHJcbi8qKiBDb21wdXRlIHRoZSBlbmdhZ2VtZW50IHNpZ25hdHVyZSB3ZSB1c2UgdG8gZGVjaWRlIHdoZXRoZXIgYSByZS1jYXB0dXJlZFxyXG4gKiB0d2VldCBpcyBcIm1hdGVyaWFsbHkgZGlmZmVyZW50XCIgZnJvbSB3aGF0IHdlIGxhc3QgY29tbWl0dGVkLiBXZSBvbWl0XHJcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXHJcbiAqIGRlZmVhdCB0aGUgZGVkdXAuIExpa2VzIC8gUlRzIC8gcmVwbGllcyAvIHF1b3RlcyBjaGFuZ2UgcmFyZWx5IGVub3VnaCB0aGF0XHJcbiAqIGVhY2ggY2hhbmdlIGlzIHdvcnRoIGEgcmUtY29tbWl0IChhbmQgYW4gZW5nYWdlbWVudF9oaXN0b3J5IHNuYXBzaG90KS5cclxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxyXG4gKiB0aGUgZnVsbCBgbm90ZV90d2VldGAgYm9keSBieXBhc3NlcyB0aGUgZGVkdXAgZXZlbiB3aGVuIGVuZ2FnZW1lbnQgY291bnRzXHJcbiAqIGhhdmVuJ3QgbW92ZWQgXHUyMDE0IG90aGVyd2lzZSB0aGUgbmV3IGJvZHkgd291bGQgYmUgc2lsZW50bHkgZHJvcHBlZC4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXHJcbiAgbGlrZXM6IG51bWJlcixcclxuICByZXR3ZWV0czogbnVtYmVyLFxyXG4gIHJlcGxpZXM6IG51bWJlcixcclxuICBxdW90ZXM6IG51bWJlcixcclxuICBpc1RydW5jYXRlZDogYm9vbGVhbiA9IGZhbHNlXHJcbik6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGAke2xpa2VzfXwke3JldHdlZXRzfXwke3JlcGxpZXN9fCR7cXVvdGVzfXwke2lzVHJ1bmNhdGVkID8gJ3QnIDogJ2YnfWA7XHJcbn1cclxuXHJcbi8qKiBEcm9wIGVudHJpZXMgb2xkZXIgdGhhbiBgbWF4QWdlTXNgLiBSZXR1cm5zIHRoZSBudW1iZXIgcHJ1bmVkLiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJ1bmVDb21taXR0ZWRJbmRleChtYXhBZ2VNczogbnVtYmVyKTogUHJvbWlzZTxudW1iZXI+IHtcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGNvbnN0IGN1dG9mZiA9IG5ldyBEYXRlKERhdGUubm93KCkgLSBtYXhBZ2VNcykudG9JU09TdHJpbmcoKTtcclxuICBsZXQgcHJ1bmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XHJcbiAgICBjb25zdCBpbm5lciA9IGlkeFtoYW5kbGVdO1xyXG4gICAgaWYgKCFpbm5lcikgY29udGludWU7XHJcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcclxuICAgICAgY29uc3QgZSA9IGlubmVyW3RpZF07XHJcbiAgICAgIGlmIChlICYmIGUudHMgPCBjdXRvZmYpIHtcclxuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcclxuICAgICAgICBwcnVuZWQgKz0gMTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKE9iamVjdC5rZXlzKGlubmVyKS5sZW5ndGggPT09IDApIGRlbGV0ZSBpZHhbaGFuZGxlXTtcclxuICB9XHJcbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XHJcbiAgcmV0dXJuIHBydW5lZDtcclxufVxyXG5cclxuLy8gLS0tIFJlZmV0Y2ggcXVldWUgKHR3ZWV0cyBuZWVkaW5nIGZ1bGwtdGV4dCByZWNhcHR1cmUpIC0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFF1ZXVlJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWZldGNoUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBsZXQgdG90YWwgPSAwO1xyXG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XHJcbiAgcmV0dXJuIHRvdGFsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBjb25zdCBpZHMgPSBxW2hhbmRsZV0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtoYW5kbGVdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXTtcclxuICBpZiAoIWlkcykgcmV0dXJuO1xyXG4gIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcclxuICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtoYW5kbGVdO1xyXG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRSZWZldGNoVGFyZ2V0KCk6IFByb21pc2U8e1xyXG4gIGhhbmRsZTogc3RyaW5nO1xyXG4gIHR3ZWV0SWQ6IHN0cmluZztcclxufSB8IG51bGw+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XHJcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGhhbmRsZSwgdHdlZXRJZDogaWRzWzBdISB9O1xyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBsZXQgdG90YWwgPSAwO1xyXG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XHJcbiAgcmV0dXJuIHRvdGFsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZU1lZGlhQ3Jhd2woaGludEhhbmRsZTogc3RyaW5nIHwgbnVsbCwgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcclxuICBjb25zdCBpZHMgPSBxW2J1Y2tldF0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtidWNrZXRdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcclxuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xyXG4gICAgY29uc3QgaWRzID0gcVtidWNrZXRdO1xyXG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xyXG4gICAgaWYgKGZpbHRlcmVkLmxlbmd0aCAhPT0gaWRzLmxlbmd0aCkge1xyXG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcclxuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcclxuICAgICAgZWxzZSBxW2J1Y2tldF0gPSBmaWx0ZXJlZDtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKGNoYW5nZWQpIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgcSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0TWVkaWFDcmF3bFRhcmdldCgpOiBQcm9taXNlPHtcclxuICBidWNrZXQ6IHN0cmluZztcclxuICB0d2VldElkOiBzdHJpbmc7XHJcbn0gfCBudWxsPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xyXG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBidWNrZXQsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXHJcbiAqIGVucXVldWVpbmcgbWVkaWEtY3Jhd2wgdGFyZ2V0cyB3ZSd2ZSBhbHJlYWR5IGFyY2hpdmVkLiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNDb21taXR0ZWQodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBmb3IgKGNvbnN0IGlubmVyIG9mIE9iamVjdC52YWx1ZXMoaWR4KSkge1xyXG4gICAgaWYgKGlubmVyICYmIHR3ZWV0SWQgaW4gaW5uZXIpIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbi8vIC0tLSBMb29wIHNlc3Npb24gc3RhdGUgKHByb2dyZXNzICsgaW5mbGlnaHQgZ2F0aW5nKSAtLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFNlc3Npb24nLCBzKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJywgcyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEF1dG9TY3JvbGxTZXNzaW9uKCk6IFByb21pc2U8QXV0b1Njcm9sbFNlc3Npb24gfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXV0b1Njcm9sbFNlc3Npb24oczogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicsIHMpO1xyXG59XHJcblxyXG4vLyAtLS0gUHVyZ2U6IHVucmVsYXRlZCBidWZmZXJzLCBjb3VudGVycywgcXVldWUgZW50cmllcyAtLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4vKipcclxuICogRHJvcCBldmVyeSBwZXItaGFuZGxlIGJpdCBvZiBzdGF0ZSAoY291bnRlcnMsIHJ1biBidWZmZXIsIGNvbW1pdHRlZC1pbmRleFxyXG4gKiBlbnRyaWVzLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcXVldWUgZW50cmllcykgdGhhdCBkb2Vzbid0IGNvcnJlc3BvbmQgdG8gYVxyXG4gKiB0cmFja2VkIGFjY291bnQuIFJldHVybnMgYSBzdW1tYXJ5IGRlc2NyaWJpbmcgd2hhdCB3YXMgY2xlYXJlZCBzbyB0aGVcclxuICogY2FsbGVyIGNhbiBsb2cgaXQuXHJcbiAqXHJcbiAqIFRyYWNrZWQgYWNjb3VudHMgYXJlIHBhc3NlZCBpbiAoY2FsbGVyIHJlc29sdmVzIGZyb20gdGhlIGxpdmUgY29uZmlnKS5cclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwdXJnZVVucmVsYXRlZFN0YXRlKHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+KTogUHJvbWlzZTx7XHJcbiAgY291bnRlcnNSZW1vdmVkOiBudW1iZXI7XHJcbiAgYnVmZmVyc1JlbW92ZWQ6IG51bWJlcjtcclxuICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkOiBudW1iZXI7XHJcbn0+IHtcclxuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcclxuICBjb25zdCBpc1RhcmdldGVkID0gKGg6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGFyZ0xvd2VyLmhhcyhoLnRvTG93ZXJDYXNlKCkpO1xyXG5cclxuICAvLyBDb3VudGVyc1xyXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcclxuICBsZXQgY291bnRlcnNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGNvdW50ZXJzW2hdO1xyXG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcclxuXHJcbiAgLy8gUnVuIGJ1ZmZlcnNcclxuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGxldCBidWZmZXJzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGJ1ZmZlcnMpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGJ1ZmZlcnNbaF07XHJcbiAgICAgIGJ1ZmZlcnNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGJ1ZmZlcnMpO1xyXG5cclxuICAvLyBDb21taXR0ZWQgZGVkdXAgaW5kZXhcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgaWR4W2hdO1xyXG4gICAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xyXG5cclxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXHJcbiAgY29uc3QgcnEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBsZXQgcmVmZXRjaEhhbmRsZXNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIHJxW2hdO1xyXG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XHJcblxyXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiBidWNrZXRzIGFyZSBoaW50LWhhbmRsZXMgKG9yIFwiX3Vua25vd25cIikuIERyb3BcclxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCBcdTIwMTQgaW5jbHVkaW5nIFwiX3Vua25vd25cIiBzaW5jZSB3ZVxyXG4gIC8vIGNhbid0IHZlcmlmeSByZWxhdGlvbi5cclxuICBjb25zdCBtcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKG1xKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xyXG4gICAgICBkZWxldGUgbXFbaF07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgbXEpO1xyXG5cclxuICByZXR1cm4ge1xyXG4gICAgY291bnRlcnNSZW1vdmVkLFxyXG4gICAgYnVmZmVyc1JlbW92ZWQsXHJcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcclxuICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCxcclxuICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkLFxyXG4gIH07XHJcbn1cclxuXHJcbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcclxufVxyXG4iLCAiaW1wb3J0IHsgYXBwZW5kQWN0aXZpdHkgfSBmcm9tICcuL3N0b3JhZ2UuanMnO1xyXG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxubGV0IGJyb2FkY2FzdDogKChldjogTG9nRXZlbnQpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc2V0QnJvYWRjYXN0ZXIoZm46IChldjogTG9nRXZlbnQpID0+IHZvaWQpOiB2b2lkIHtcclxuICBicm9hZGNhc3QgPSBmbjtcclxufVxyXG5cclxuZnVuY3Rpb24gbm93SVNPKCk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGV2OiBMb2dFdmVudCA9IHsgdHM6IG5vd0lTTygpLCBsZXZlbCwgbXNnLCBjb250ZXh0OiByZWRhY3QoY29udGV4dCkgfTtcclxuICAvLyBDb25zb2xlIGZvciBkZXZ0b29scy5cclxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xyXG4gIGlmIChsZXZlbCA9PT0gJ2Vycm9yJykgY29uc29sZS5lcnJvcihsaW5lLCBldi5jb250ZXh0KTtcclxuICBlbHNlIGlmIChsZXZlbCA9PT0gJ3dhcm4nKSBjb25zb2xlLndhcm4obGluZSwgZXYuY29udGV4dCk7XHJcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcclxuICAvLyBQZXJzaXN0ZW50IHRhaWwuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBmYWlsZWQgdG8gYXBwZW5kIGFjdGl2aXR5JywgZXJyKTtcclxuICB9XHJcbiAgLy8gTGl2ZSBicm9hZGNhc3QgKGUuZy4gdG8gc2lkZWJhcikuXHJcbiAgdHJ5IHtcclxuICAgIGJyb2FkY2FzdD8uKGV2KTtcclxuICB9IGNhdGNoIHtcclxuICAgIC8vIFNpZGViYXIgbWF5IG5vdCBiZSBvcGVuOyB0aGF0J3MgZmluZS5cclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIGVtaXQoJ2luZm8nLCBtc2csIGNvbnRleHQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIGVtaXQoJ3dhcm4nLCBtc2csIGNvbnRleHQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHJldHVybiBlbWl0KCdlcnJvcicsIG1zZywgY29udGV4dCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZUVycm9yKGVycjogdW5rbm93bik6IHsgbWVzc2FnZTogc3RyaW5nOyBzdGFjazogc3RyaW5nIHwgbnVsbCB9IHtcclxuICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcclxuICB9XHJcbiAgdHJ5IHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIHsgbWVzc2FnZTogJzx1bnByaW50YWJsZSBlcnJvcj4nLCBzdGFjazogbnVsbCB9O1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFN0cmlwIGFueXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIFBBVCBvciBvdGhlciBsb25nIHNlY3JldCBmcm9tIGEgY29udGV4dFxyXG4gKiBvYmplY3QgYmVmb3JlIHBlcnNpc3RpbmcgaXQuIERlZmVuc2l2ZTogY2FsbGVycyBzaG91bGQgbm90IGxvZyB0b2tlbnMsIGJ1dFxyXG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxyXG4gKi9cclxuZnVuY3Rpb24gcmVkYWN0KGN0eDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XHJcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xyXG4gIGZvciAoY29uc3QgW2ssIHZdIG9mIE9iamVjdC5lbnRyaWVzKGN0eCkpIHtcclxuICAgIGlmIChrLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ3Rva2VuJykgfHwgay50b0xvd2VyQ2FzZSgpID09PSAncGF0JyB8fCBrID09PSAnYXV0aG9yaXphdGlvbicpIHtcclxuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dezMwLH0vLnRlc3QodikpIHtcclxuICAgICAgb3V0W2tdID0gdi5yZXBsYWNlKC9naXRodWJfcGF0X1tBLVphLXowLTlfXSsvZywgJ2dpdGh1Yl9wYXRfPHJlZGFjdGVkPicpO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XHJcbiAgICAgIG91dFtrXSA9IGAke3Yuc2xpY2UoMCwgNDA5Nil9XHUyMDI2PHRydW5jYXRlZD5gO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgb3V0W2tdID0gdjtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG4iLCAiaW1wb3J0IHsgZGVzY3JpYmVFcnJvciB9IGZyb20gJy4vbG9nZ2VyLmpzJztcbmltcG9ydCB0eXBlIHsgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuY29uc3QgQVBJX0JBU0UgPSAnaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbSc7XG5jb25zdCBSQVdfQkFTRSA9ICdodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20nO1xuXG5leHBvcnQgaW50ZXJmYWNlIFB1dEZpbGVPcHRpb25zIHtcbiAgcGF0aDogc3RyaW5nO1xuICBjb250ZW50QmFzZTY0OiBzdHJpbmc7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgZXhwZWN0ZWRTaGE/OiBzdHJpbmcgfCBudWxsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFB1dEZpbGVSZXN1bHQge1xuICBwYXRoOiBzdHJpbmc7XG4gIHNoYTogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlT3B0aW9ucyB7XG4gIHBhdGg6IHN0cmluZztcbiAgY29udGVudEJhc2U2NDogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVzT3B0aW9ucyB7XG4gIGZpbGVzOiBDb21taXRGaWxlT3B0aW9uc1tdO1xuICBtZXNzYWdlOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZXNSZXN1bHQge1xuICBjb21taXRTaGE6IHN0cmluZztcbiAgdXJsOiBzdHJpbmc7XG4gIGZpbGVzOiBzdHJpbmdbXTtcbn1cblxuZXhwb3J0IGNsYXNzIEdpdEh1YkVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBzdGF0dXM6IG51bWJlcjtcbiAgYm9keTogdW5rbm93bjtcbiAgcmV0cmlhYmxlOiBib29sZWFuO1xuICBjYXRlZ29yeTogJ2F1dGgnIHwgJ3JhdGUtbGltaXQnIHwgJ2NvbmZsaWN0JyB8ICdub3QtZm91bmQnIHwgJ3NlcnZlcicgfCAnbmV0d29yaycgfCAndW5rbm93bic7XG4gIC8qKiBXaGVuIHRoZSBHaXRIdWIgcmF0ZS1saW1pdCB3aW5kb3cgZm9yIHRoaXMgdG9rZW4gcmVzZXRzLCBhcyBhIFVuaXhcbiAgICogZXBvY2ggaW4gc2Vjb25kcy4gUG9wdWxhdGVkIGZyb20gYFgtUmF0ZUxpbWl0LVJlc2V0YCBvbiA0MDMvNDI5LCBvclxuICAgKiBkZXJpdmVkIGZyb20gYFJldHJ5LUFmdGVyYCBmb3Igc2Vjb25kYXJ5IGxpbWl0cy4gbnVsbCB3aGVuIHVua25vd24uICovXG4gIHJhdGVMaW1pdFJlc2V0QXQ6IG51bWJlciB8IG51bGw7XG5cbiAgY29uc3RydWN0b3Iob3B0czoge1xuICAgIHN0YXR1czogbnVtYmVyO1xuICAgIGJvZHk6IHVua25vd247XG4gICAgbWVzc2FnZTogc3RyaW5nO1xuICAgIHJldHJpYWJsZTogYm9vbGVhbjtcbiAgICBjYXRlZ29yeTogR2l0SHViRXJyb3JbJ2NhdGVnb3J5J107XG4gICAgcmF0ZUxpbWl0UmVzZXRBdD86IG51bWJlciB8IG51bGw7XG4gIH0pIHtcbiAgICBzdXBlcihvcHRzLm1lc3NhZ2UpO1xuICAgIHRoaXMubmFtZSA9ICdHaXRIdWJFcnJvcic7XG4gICAgdGhpcy5zdGF0dXMgPSBvcHRzLnN0YXR1cztcbiAgICB0aGlzLmJvZHkgPSBvcHRzLmJvZHk7XG4gICAgdGhpcy5yZXRyaWFibGUgPSBvcHRzLnJldHJpYWJsZTtcbiAgICB0aGlzLmNhdGVnb3J5ID0gb3B0cy5jYXRlZ29yeTtcbiAgICB0aGlzLnJhdGVMaW1pdFJlc2V0QXQgPSBvcHRzLnJhdGVMaW1pdFJlc2V0QXQgPz8gbnVsbDtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgR2l0SHViQ2xpZW50IHtcbiAgcHJpdmF0ZSByZWFkb25seSBzZXR0aW5nczogU2V0dGluZ3M7XG5cbiAgY29uc3RydWN0b3Ioc2V0dGluZ3M6IFNldHRpbmdzKSB7XG4gICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzO1xuICB9XG5cbiAgLyoqIFJldHVybnMgdGhlIGF1dGhlbnRpY2F0ZWQgdXNlcidzIGxvZ2luLiBUaHJvd3Mgb24gYXV0aCBmYWlsdXJlLiAqL1xuICBhc3luYyB3aG9hbWkoKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgJy91c2VyJyk7XG4gICAgcmV0dXJuIChyZXMgYXMgeyBsb2dpbj86IHN0cmluZyB9KS5sb2dpbiA/PyAnPHVua25vd24+JztcbiAgfVxuXG4gIC8qKiBSZXR1cm5zIHRydWUgaWYgdGhlIGdpdmVuIGJyYW5jaCBleGlzdHMgb24gdGhlIGNvbmZpZ3VyZWQgcmVwby4gKi9cbiAgYXN5bmMgYnJhbmNoRXhpc3RzKGJyYW5jaDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9icmFuY2hlcy8ke2VuY29kZVVSSUNvbXBvbmVudChicmFuY2gpfWBcbiAgICAgICk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gZmFsc2U7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgLyoqIFZlcmlmaWVzIHRoZSBQQVQgY2FuIHNlZSB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xuICBhc3luYyB2ZXJpZnlSZXBvQWNjZXNzKCk6IFByb21pc2U8eyBsb2dpbjogc3RyaW5nOyBmdWxsX25hbWU6IHN0cmluZzsgZGVmYXVsdF9icmFuY2g6IHN0cmluZyB9PiB7XG4gICAgY29uc3QgbWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgJy91c2VyJyk7XG4gICAgY29uc3QgcmVwbyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99YCk7XG4gICAgY29uc3QgciA9IHJlcG8gYXMgeyBmdWxsX25hbWU6IHN0cmluZzsgZGVmYXVsdF9icmFuY2g6IHN0cmluZyB9O1xuICAgIHJldHVybiB7XG4gICAgICBsb2dpbjogKG1lIGFzIHsgbG9naW46IHN0cmluZyB9KS5sb2dpbixcbiAgICAgIGZ1bGxfbmFtZTogci5mdWxsX25hbWUsXG4gICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIEZldGNoIGEgdGV4dCBmaWxlIGZyb20gcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSBhdXRoZW50aWNhdGVkIHdpdGggdGhlXG4gICAqIFBBVC4gUmV0dXJucyBudWxsIGlmIHRoZSBmaWxlIGRvZXNuJ3QgZXhpc3QuIFVzZWQgZm9yIGNvbmZpZy9hY2NvdW50cy55YW1sLlxuICAgKi9cbiAgYXN5bmMgZmV0Y2hSYXdUZXh0KHBhdGhJblJlcG86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IHVybCA9IGAke1JBV19CQVNFfS8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS8ke3RoaXMuc2V0dGluZ3MuYnJhbmNofS8ke3BhdGhJblJlcG99YDtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLnNldHRpbmdzLnBhdH1gIH0sXG4gICAgfSk7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkgcmV0dXJuIG51bGw7XG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yKHJlcywgYEdFVCByYXcgJHtwYXRoSW5SZXBvfWApO1xuICAgIHJldHVybiByZXMudGV4dCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvb2sgdXAgYW4gZXhpc3RpbmcgZmlsZSdzIFNIQSB2aWEgdGhlIENvbnRlbnRzIEFQSSwgb3IgbnVsbCBpZiBub3QgZm91bmQuXG4gICAqIFVzZWQgd2hlbiByZXRyeWluZyBhIFBVVCBhZnRlciBhIDQyMiBzaGEgbWlzbWF0Y2guXG4gICAqL1xuICBhc3luYyBnZXRGaWxlU2hhKHBhdGg6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vY29udGVudHMvJHtlbmNvZGVQYXRoKHBhdGgpfT9yZWY9JHtlbmNvZGVVUklDb21wb25lbnQodGhpcy5zZXR0aW5ncy5icmFuY2gpfWBcbiAgICAgICk7XG4gICAgICBjb25zdCByID0gcmVzIGFzIHsgc2hhPzogc3RyaW5nIH07XG4gICAgICByZXR1cm4gci5zaGEgPz8gbnVsbDtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gbnVsbDtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUFVUIGEgZmlsZSB0byB0aGUgcmVwby4gSGFuZGxlcyA0MjIgKHNoYSByZXF1aXJlZCkgYnkgcmUtZmV0Y2hpbmcgdGhlXG4gICAqIGV4aXN0aW5nIHNoYSBhbmQgcmV0cnlpbmcgb25jZS4gUmV0cmllcyBuZXR3b3JrIC8gNXh4IC8gcmF0ZS1saW1pdCBlcnJvcnNcbiAgICogd2l0aCBleHBvbmVudGlhbCBiYWNrb2ZmIHVwIHRvIG1heEF0dGVtcHRzLlxuICAgKi9cbiAgYXN5bmMgcHV0RmlsZShvcHRzOiBQdXRGaWxlT3B0aW9ucyk6IFByb21pc2U8UHV0RmlsZVJlc3VsdD4ge1xuICAgIGNvbnN0IHBhdGggPSBvcHRzLnBhdGg7XG4gICAgY29uc3QgdXJsID0gYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9YDtcbiAgICBsZXQgc2hhOiBzdHJpbmcgfCBudWxsID0gb3B0cy5leHBlY3RlZFNoYSA/PyBudWxsO1xuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcbiAgICAgIGNvbnN0IGJvZHk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXG4gICAgICAgIGNvbnRlbnQ6IG9wdHMuY29udGVudEJhc2U2NCxcbiAgICAgICAgYnJhbmNoOiB0aGlzLnNldHRpbmdzLmJyYW5jaCxcbiAgICAgIH07XG4gICAgICBpZiAoc2hhKSBib2R5LnNoYSA9IHNoYTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdQVVQnLCB1cmwsIGJvZHkpO1xuICAgICAgICBjb25zdCBvdXQgPSByZXMgYXMgeyBjb250ZW50OiB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nOyBwYXRoOiBzdHJpbmcgfSB9O1xuICAgICAgICByZXR1cm4geyBwYXRoOiBvdXQuY29udGVudC5wYXRoLCBzaGE6IG91dC5jb250ZW50LnNoYSwgdXJsOiBvdXQuY29udGVudC5odG1sX3VybCB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xuICAgICAgICBpZiAoZXJyLnN0YXR1cyA9PT0gNDIyICYmICFzaGEpIHtcbiAgICAgICAgICAvLyBGaWxlIGFscmVhZHkgZXhpc3RzOyBmZXRjaCBpdHMgc2hhIGFuZCByZXRyeSBvbmNlLlxuICAgICAgICAgIHNoYSA9IGF3YWl0IHRoaXMuZ2V0RmlsZVNoYShwYXRoKTtcbiAgICAgICAgICBpZiAoIXNoYSkgdGhyb3cgZXJyO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZXJyLnJldHJpYWJsZSB8fCBhdHRlbXB0ID09PSBtYXhBdHRlbXB0cykgdGhyb3cgZXJyO1xuICAgICAgICBhd2FpdCBzbGVlcChiYWNrb2ZmTXMoYXR0ZW1wdCwgZXJyKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihgcHV0RmlsZTogZXhoYXVzdGVkIGF0dGVtcHRzIGZvciAke3BhdGh9YCk7XG4gIH1cblxuICAvKipcbiAgICogQ29tbWl0IHNldmVyYWwgZmlsZXMgd2l0aCBvbmUgYnJhbmNoIHVwZGF0ZS4gVGhlIENvbnRlbnRzIEFQSSBjcmVhdGVzIG9uZVxuICAgKiBjb21taXQgcGVyIFBVVCwgc28gcmFwaWQgZmx1c2hlcyByYWNlIGVhY2ggb3RoZXIgb24gdGhlIGJyYW5jaCBoZWFkLiBUaGlzXG4gICAqIHVzZXMgdGhlIGxvd2VyLWxldmVsIEdpdCBEYXRhIEFQSSBpbnN0ZWFkOiB1cGxvYWQgYmxvYnMsIGJ1aWxkIGEgdHJlZSxcbiAgICogY3JlYXRlIG9uZSBjb21taXQsIHRoZW4gbW92ZSB0aGUgYnJhbmNoIHJlZiBvbmNlLiBJZiBhbm90aGVyIHdyaXRlciBtb3Zlc1xuICAgKiB0aGUgYnJhbmNoIGZpcnN0LCByZWJhc2UgdGhpcyB0cmVlIHBhdGNoIG9udG8gdGhlIGxhdGVzdCBoZWFkIGFuZCByZXRyeS5cbiAgICovXG4gIGFzeW5jIGNvbW1pdEZpbGVzKG9wdHM6IENvbW1pdEZpbGVzT3B0aW9ucyk6IFByb21pc2U8Q29tbWl0RmlsZXNSZXN1bHQ+IHtcbiAgICBpZiAob3B0cy5maWxlcy5sZW5ndGggPT09IDApIHRocm93IG5ldyBFcnJvcignY29tbWl0RmlsZXM6IG5vIGZpbGVzIHRvIGNvbW1pdCcpO1xuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcbiAgICBsZXQgbGFzdEVycjogdW5rbm93biA9IG51bGw7XG5cbiAgICBmb3IgKGxldCBhdHRlbXB0ID0gMTsgYXR0ZW1wdCA8PSBtYXhBdHRlbXB0czsgYXR0ZW1wdCsrKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBibG9icyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICAgIG9wdHMuZmlsZXMubWFwKGFzeW5jIChmaWxlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBvdXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9ibG9ic2AsXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBjb250ZW50OiBmaWxlLmNvbnRlbnRCYXNlNjQsXG4gICAgICAgICAgICAgICAgZW5jb2Rpbmc6ICdiYXNlNjQnLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgcGF0aDogZmlsZS5wYXRoLFxuICAgICAgICAgICAgICBzaGE6IChvdXQgYXMgeyBzaGE6IHN0cmluZyB9KS5zaGEsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0pXG4gICAgICAgICk7XG5cbiAgICAgICAgY29uc3QgaGVhZCA9IGF3YWl0IHRoaXMuZ2V0QnJhbmNoSGVhZCgpO1xuICAgICAgICBjb25zdCB0cmVlID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L3RyZWVzYCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBiYXNlX3RyZWU6IGhlYWQudHJlZVNoYSxcbiAgICAgICAgICAgIHRyZWU6IGJsb2JzLm1hcCgoYmxvYikgPT4gKHtcbiAgICAgICAgICAgICAgcGF0aDogYmxvYi5wYXRoLFxuICAgICAgICAgICAgICBtb2RlOiAnMTAwNjQ0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ2Jsb2InLFxuICAgICAgICAgICAgICBzaGE6IGJsb2Iuc2hhLFxuICAgICAgICAgICAgfSkpLFxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgdHJlZVNoYSA9ICh0cmVlIGFzIHsgc2hhOiBzdHJpbmcgfSkuc2hhO1xuICAgICAgICBjb25zdCBjb21taXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvY29tbWl0c2AsXG4gICAgICAgICAge1xuICAgICAgICAgICAgbWVzc2FnZTogb3B0cy5tZXNzYWdlLFxuICAgICAgICAgICAgdHJlZTogdHJlZVNoYSxcbiAgICAgICAgICAgIHBhcmVudHM6IFtoZWFkLnNoYV0sXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICBjb25zdCBjb21taXRPdXQgPSBjb21taXQgYXMgeyBzaGE6IHN0cmluZzsgaHRtbF91cmw6IHN0cmluZyB9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICAgJ1BBVENIJyxcbiAgICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L3JlZnMvaGVhZHMvJHtlbmNvZGVQYXRoKHRoaXMuc2V0dGluZ3MuYnJhbmNoKX1gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaGE6IGNvbW1pdE91dC5zaGEsXG4gICAgICAgICAgICAgIGZvcmNlOiBmYWxzZSxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBpZiAoaXNDb25mbGljdChlcnIpICYmIGF0dGVtcHQgPCBtYXhBdHRlbXB0cykge1xuICAgICAgICAgICAgbGFzdEVyciA9IGVycjtcbiAgICAgICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBjb21taXRTaGE6IGNvbW1pdE91dC5zaGEsXG4gICAgICAgICAgdXJsOiBjb21taXRPdXQuaHRtbF91cmwsXG4gICAgICAgICAgZmlsZXM6IG9wdHMuZmlsZXMubWFwKChmaWxlKSA9PiBmaWxlLnBhdGgpLFxuICAgICAgICB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGxhc3RFcnIgPSBlcnI7XG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xuICAgICAgICBpZiAoKCFlcnIucmV0cmlhYmxlICYmICFpc0NvbmZsaWN0KGVycikpIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbGFzdEVyciBpbnN0YW5jZW9mIEVycm9yID8gbGFzdEVyciA6IG5ldyBFcnJvcignY29tbWl0RmlsZXM6IGV4aGF1c3RlZCBhdHRlbXB0cycpO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBnZXRCcmFuY2hIZWFkKCk6IFByb21pc2U8eyBzaGE6IHN0cmluZzsgdHJlZVNoYTogc3RyaW5nIH0+IHtcbiAgICBjb25zdCByZWYgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICdHRVQnLFxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmL2hlYWRzLyR7ZW5jb2RlUGF0aCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxuICAgICk7XG4gICAgY29uc3QgaGVhZFNoYSA9IChyZWYgYXMgeyBvYmplY3Q6IHsgc2hhOiBzdHJpbmcgfSB9KS5vYmplY3Quc2hhO1xuICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgJ0dFVCcsXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9jb21taXRzLyR7aGVhZFNoYX1gXG4gICAgKTtcbiAgICByZXR1cm4ge1xuICAgICAgc2hhOiBoZWFkU2hhLFxuICAgICAgdHJlZVNoYTogKGNvbW1pdCBhcyB7IHRyZWU6IHsgc2hhOiBzdHJpbmcgfSB9KS50cmVlLnNoYSxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmZXRjaEpzb24obWV0aG9kOiBzdHJpbmcsIHBhdGg6IHN0cmluZywgYm9keT86IHVua25vd24pOiBQcm9taXNlPHVua25vd24+IHtcbiAgICBjb25zdCB1cmwgPSBwYXRoLnN0YXJ0c1dpdGgoJ2h0dHAnKSA/IHBhdGggOiBgJHtBUElfQkFTRX0ke3BhdGh9YDtcbiAgICBjb25zdCBpbml0OiBSZXF1ZXN0SW5pdCA9IHtcbiAgICAgIG1ldGhvZCxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAsXG4gICAgICAgIEFjY2VwdDogJ2FwcGxpY2F0aW9uL3ZuZC5naXRodWIranNvbicsXG4gICAgICAgICdYLUdpdEh1Yi1BcGktVmVyc2lvbic6ICcyMDIyLTExLTI4JyxcbiAgICAgICAgLi4uKGJvZHkgPyB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSA6IHt9KSxcbiAgICAgIH0sXG4gICAgICAuLi4oYm9keSA/IHsgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSkgfSA6IHt9KSxcbiAgICB9O1xuICAgIGxldCByZXM6IFJlc3BvbnNlO1xuICAgIHRyeSB7XG4gICAgICByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIGluaXQpO1xuICAgIH0gY2F0Y2ggKG5ldEVycikge1xuICAgICAgdGhyb3cgbmV3IEdpdEh1YkVycm9yKHtcbiAgICAgICAgc3RhdHVzOiAwLFxuICAgICAgICBib2R5OiBudWxsLFxuICAgICAgICBtZXNzYWdlOiBgbmV0d29yazogJHtkZXNjcmliZUVycm9yKG5ldEVycikubWVzc2FnZX1gLFxuICAgICAgICByZXRyaWFibGU6IHRydWUsXG4gICAgICAgIGNhdGVnb3J5OiAnbmV0d29yaycsXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDIwNCkgcmV0dXJuIG51bGw7XG4gICAgbGV0IHBhcnNlZDogdW5rbm93biA9IG51bGw7XG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgaWYgKHRleHQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgcGFyc2VkID0gdGV4dDtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgYCR7bWV0aG9kfSAke3BhdGh9YCk7XG4gICAgcmV0dXJuIHBhcnNlZDtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbWFrZUVycm9yKHJlczogUmVzcG9uc2UsIGxhYmVsOiBzdHJpbmcpOiBQcm9taXNlPEdpdEh1YkVycm9yPiB7XG4gICAgbGV0IHBhcnNlZDogdW5rbm93biA9IG51bGw7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgICAgaWYgKHRleHQpIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBpZ25vcmVcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgbGFiZWwpO1xuICB9XG5cbiAgcHJpdmF0ZSBtYWtlRXJyb3JGcm9tUGFyc2VkKHJlczogUmVzcG9uc2UsIGJvZHk6IHVua25vd24sIGxhYmVsOiBzdHJpbmcpOiBHaXRIdWJFcnJvciB7XG4gICAgY29uc3QgbXNnID1cbiAgICAgIHR5cGVvZiBib2R5ID09PSAnb2JqZWN0JyAmJiBib2R5ICYmICdtZXNzYWdlJyBpbiBib2R5XG4gICAgICAgID8gU3RyaW5nKChib2R5IGFzIHsgbWVzc2FnZTogdW5rbm93biB9KS5tZXNzYWdlKVxuICAgICAgICA6IHJlcy5zdGF0dXNUZXh0O1xuICAgIGxldCBjYXRlZ29yeTogR2l0SHViRXJyb3JbJ2NhdGVnb3J5J10gPSAndW5rbm93bic7XG4gICAgbGV0IHJldHJpYWJsZSA9IGZhbHNlO1xuICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDEgfHwgcmVzLnN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAvLyA0MDMgY2FuIGJlIGVpdGhlciBhdXRoIG9yIHJhdGUgbGltaXQ7IGNoZWNrIGhlYWRlcnMuXG4gICAgICBjb25zdCByYXRlID0gcmVzLmhlYWRlcnMuZ2V0KCd4LXJhdGVsaW1pdC1yZW1haW5pbmcnKTtcbiAgICAgIGlmIChyYXRlID09PSAnMCcgfHwgL3JhdGUgbGltaXQvaS50ZXN0KG1zZykpIHtcbiAgICAgICAgY2F0ZWdvcnkgPSAncmF0ZS1saW1pdCc7XG4gICAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjYXRlZ29yeSA9ICdhdXRoJztcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkge1xuICAgICAgY2F0ZWdvcnkgPSAnbm90LWZvdW5kJztcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwOSB8fCByZXMuc3RhdHVzID09PSA0MjIpIHtcbiAgICAgIGNhdGVnb3J5ID0gJ2NvbmZsaWN0JztcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPj0gNTAwKSB7XG4gICAgICBjYXRlZ29yeSA9ICdzZXJ2ZXInO1xuICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQyOSkge1xuICAgICAgY2F0ZWdvcnkgPSAncmF0ZS1saW1pdCc7XG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IEdpdEh1YkVycm9yKHtcbiAgICAgIHN0YXR1czogcmVzLnN0YXR1cyxcbiAgICAgIGJvZHksXG4gICAgICBtZXNzYWdlOiBgJHtsYWJlbH0gXHUyMTkyICR7cmVzLnN0YXR1c306ICR7bXNnfWAsXG4gICAgICByZXRyaWFibGUsXG4gICAgICBjYXRlZ29yeSxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyBwYXJzZVJhdGVMaW1pdFJlc2V0KHJlcy5oZWFkZXJzKSA6IG51bGwsXG4gICAgfSk7XG4gIH1cbn1cblxuLyoqXG4gKiBCZXN0LWVmZm9ydCBwYXJzZSBvZiB3aGVuIHRoZSBjdXJyZW50IHJhdGUtbGltaXQgd2luZG93IGVuZHMuIEdpdEh1YidzXG4gKiBwcmltYXJ5IGxpbWl0IHJlcG9ydHMgYFgtUmF0ZUxpbWl0LVJlc2V0YCBhcyBhIFVuaXggZXBvY2ggaW4gc2Vjb25kcy5cbiAqIFNlY29uZGFyeSAvIGFidXNlIGxpbWl0cyB1c2UgYFJldHJ5LUFmdGVyYCwgd2hpY2ggaXMgZWl0aGVyIGFuIEhUVFAtZGF0ZVxuICogb3IgYSBkZWx0YSBpbiBzZWNvbmRzIFx1MjAxNCB3ZSBub3JtYWxpemUgYm90aCB0byBlcG9jaCBzZWNvbmRzLlxuICovXG5mdW5jdGlvbiBwYXJzZVJhdGVMaW1pdFJlc2V0KGhlYWRlcnM6IEhlYWRlcnMpOiBudW1iZXIgfCBudWxsIHtcbiAgY29uc3QgcmVzZXQgPSBoZWFkZXJzLmdldCgneC1yYXRlbGltaXQtcmVzZXQnKTtcbiAgaWYgKHJlc2V0KSB7XG4gICAgY29uc3QgbiA9IE51bWJlci5wYXJzZUludChyZXNldCwgMTApO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikgJiYgbiA+IDApIHJldHVybiBuO1xuICB9XG4gIGNvbnN0IHJldHJ5QWZ0ZXIgPSBoZWFkZXJzLmdldCgncmV0cnktYWZ0ZXInKTtcbiAgaWYgKHJldHJ5QWZ0ZXIpIHtcbiAgICBjb25zdCBkZWx0YSA9IE51bWJlci5wYXJzZUludChyZXRyeUFmdGVyLCAxMCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShkZWx0YSkgJiYgZGVsdGEgPj0gMCkge1xuICAgICAgcmV0dXJuIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApICsgZGVsdGE7XG4gICAgfVxuICAgIGNvbnN0IGFzRGF0ZSA9IERhdGUucGFyc2UocmV0cnlBZnRlcik7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShhc0RhdGUpKSByZXR1cm4gTWF0aC5mbG9vcihhc0RhdGUgLyAxMDAwKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gZW5jb2RlUGF0aChwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBFbmNvZGUgc2VnbWVudHMgaW5kaXZpZHVhbGx5IHNvIHNsYXNoZXMgcmVtYWluLlxuICByZXR1cm4gcGF0aC5zcGxpdCgnLycpLm1hcChlbmNvZGVVUklDb21wb25lbnQpLmpvaW4oJy8nKTtcbn1cblxuZnVuY3Rpb24gYmFja29mZk1zKGF0dGVtcHQ6IG51bWJlciwgZXJyOiBHaXRIdWJFcnJvcik6IG51bWJlciB7XG4gIC8vIEV4cG9uZW50aWFsIHdpdGggaml0dGVyOyBidW1wIGhpZ2hlciBmb3IgcmF0ZS1saW1pdCByZXNwb25zZXMuXG4gIGNvbnN0IGJhc2UgPSBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IDUwMDAgOiA1MDA7XG4gIGNvbnN0IGppdHRlciA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDQwMCk7XG4gIHJldHVybiBNYXRoLm1pbig2MF8wMDAsIGJhc2UgKiAyICoqIChhdHRlbXB0IC0gMSkgKyBqaXR0ZXIpO1xufVxuXG5mdW5jdGlvbiBpc0NvbmZsaWN0KGVycjogdW5rbm93bik6IGVyciBpcyBHaXRIdWJFcnJvciB7XG4gIHJldHVybiBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdjb25mbGljdCc7XG59XG5cbmZ1bmN0aW9uIHNsZWVwKG1zOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0b0Jhc2U2NChieXRlczogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gYnl0ZXMgaXMgYSBVVEYtOCBzdHJpbmcgb2YgSlNPTjsgZW5jb2RlIHRvIGJhc2U2NCB0aGUgc2FmZSB3YXkuXG4gIGNvbnN0IHV0ZjggPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoYnl0ZXMpO1xuICBsZXQgYmluID0gJyc7XG4gIGZvciAoY29uc3QgYiBvZiB1dGY4KSBiaW4gKz0gU3RyaW5nLmZyb21DaGFyQ29kZShiKTtcbiAgcmV0dXJuIGJ0b2EoYmluKTtcbn1cbiIsICJpbXBvcnQgeyBUV0VFVF9VUkxfUFJFRklYIH0gZnJvbSAnLi9jb25maWcuanMnO1xyXG5pbXBvcnQgdHlwZSB7XHJcbiAgQ2Fub25pY2FsVHdlZXQsXHJcbiAgQ29tbXVuaXR5Tm90ZSxcclxuICBNZWRpYUl0ZW0sXHJcbiAgVHdlZXRDYXJkLFxyXG4gIFR3ZWV0VHlwZSxcclxuICBVcmxFbnRpdHksXHJcbiAgVXNlclNuYXBzaG90LFxyXG59IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuLyoqXHJcbiAqIE5vcm1hbGl6ZSBHcmFwaFFMIHJlc3BvbnNlIHBheWxvYWRzIGZyb20gWCdzIGludGVybmFsIEFQSSBpbnRvXHJcbiAqIGBDYW5vbmljYWxUd2VldGBzLiBNYW55IGVuZHBvaW50cyBzaGFyZSBhIHNpbWlsYXIgdHdlZXQgc2hhcGUgYnV0IHdyYXAgaXQgaW5cclxuICogZGlmZmVyZW50IGVudmVsb3BlczsgdGhpcyBtb2R1bGUgd2Fsa3MgdGhlIHN0cnVjdHVyZSBkZWZlbnNpdmVseS5cclxuICpcclxuICogVGhlIHBhcnNlciBpcyBpbnRlbnRpb25hbGx5IHBlcm1pc3NpdmU6IGl0IHdpbGwgc2lsZW50bHkgc2tpcCBlbnRyaWVzIGl0XHJcbiAqIGNhbid0IHJlY29nbml6ZSBhcyB0d2VldHMgKGN1cnNvcnMsIGFkcywgZ2FwIGVudHJpZXMsIG1vZHVsZXMgb2Ygb3RoZXJcclxuICogdHdlZXRzLCB0b21ic3RvbmVzKS4gSXQgdGhyb3dzICpvbmx5KiB3aGVuIGdpdmVuIGEgcGF5bG9hZCBpdCBkb2Vzbid0IGtub3dcclxuICogaG93IHRvIHdhbGsgYXQgYWxsIFx1MjAxNCB0aG9zZSBjYXNlcyBhcmUgY2F1Z2h0IGFuZCBxdWFyYW50aW5lZCB1cHN0cmVhbS5cclxuICovXHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZUNvbnRleHQge1xyXG4gIGNhcHR1cmVkQXQ6IHN0cmluZztcclxuICBydW5JZDogc3RyaW5nO1xyXG4gIGVuZHBvaW50OiBzdHJpbmc7XHJcbiAgYWxsb3dlZEhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz47XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgTm9ybWFsaXplUmVzdWx0IHtcclxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W107XHJcbiAgb2JzZXJ2ZWRfaWRzOiBzdHJpbmdbXTtcclxuICAvKipcclxuICAgKiBUd2VldC1zaGFwZWQgbm9kZXMgdGhlIHdhbGtlciBzYXcgKGhhZCBhIGByZXN0X2lkYCkgYnV0IGNvdWxkbid0IHR1cm5cclxuICAgKiBpbnRvIGEgZnVsbCBgQ2Fub25pY2FsVHdlZXRgIFx1MjAxNCB0eXBpY2FsbHkgYmVjYXVzZSB0aGUgZW1iZWRkZWQgdXNlclxyXG4gICAqIGluZm8gd2FzIG1pc3Npbmcgb3IgdGhlIGVudHJ5IHdhcyBhIG1lZGlhLW9ubHkgdGh1bWJuYWlsIGNhcmQgZnJvbVxyXG4gICAqIHRoZSBVc2VyTWVkaWEgZW5kcG9pbnQuIFRoZSBiYWNrZ3JvdW5kIHF1ZXVlcyB0aGVzZSBmb3IgYW4gZXhwbGljaXRcclxuICAgKiBcImdvIGZldGNoIHRoZSBkZXRhaWwgcGFnZVwiIGNyYXdsIHNvIHdlIGRvbid0IGRyb3AgdGhlbSBvbiB0aGUgZmxvb3IuXHJcbiAgICovXHJcbiAgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT47XHJcbn1cclxuXHJcbi8vIFggdHdlZXQgSURzIGFyZSA2NC1iaXQgcG9zaXRpdmUgaW50ZWdlcnMgc2VyaWFsaXplZCBhcyBkZWNpbWFsIHN0cmluZ3MuXHJcbi8vIFRoZXkndmUgZ3Jvd24gdG8gMTkgY2hhcnMgKH4xLjVlMTgpIGJ5IDIwMjYuIFJlamVjdCBhbnl0aGluZyB0aGF0IGRvZXNuJ3RcclxuLy8gbWF0Y2ggdGhpcyBzaGFwZSBcdTIwMTQgb3RoZXJ3aXNlIHNwdXJpb3VzIGNhcmQgSURzLCBjdXJzb3Igc3RyaW5ncywgYWQgc2xvdFxyXG4vLyBJRHMsIGV0Yy4gZW5kIHVwIGluIHRoZSBwYXJ0aWFsLWNhcHR1cmUgcXVldWUgYW5kIHRoZSBjcmF3bCBsb29wXHJcbi8vIG5hdmlnYXRlcyB0byBpbnZhbGlkIFVSTHMgdGhhdCBzaG93IFwidGhpcyBwYWdlIGRvZXNuJ3QgZXhpc3RcIi5cclxuY29uc3QgVFdFRVRfSURfUkUgPSAvXlxcZHsxNSwyMH0kLztcclxuXHJcbi8vIE9ubHkgb25lIGVuZHBvaW50IGFjdHVhbGx5IGV4cG9zZXMgdGhlIGZhaWx1cmUgbW9kZSB0aGUgcGFydGlhbC1jYXB0dXJlXHJcbi8vIHF1ZXVlIGV4aXN0cyBmb3IgXHUyMDE0IHRoZSBNZWRpYSB0YWIncyBgVXNlck1lZGlhYCBxdWVyeSByZXR1cm5pbmdcclxuLy8gdGh1bWJuYWlsLW9ubHkgZW50cmllcyB3aXRob3V0IGEgcG9wdWxhdGVkIGF1dGhvciBibG9jay4gRXZlcnkgb3RoZXJcclxuLy8gZW5kcG9pbnQgdGhhdCBoYW5kcyB1cyBhIGBUd2VldGAgc2hhcGUgZ2l2ZXMgdXMgdGhlIGZ1bGwgZW50cnk7IGlmXHJcbi8vIGBidWlsZFR3ZWV0YCBmYWlscyB0aGVyZSBpdCdzIGEgcmVhbCBlcnJvciwgbm90IFwiZ28gcmUtZmV0Y2ggdGhpc1wiLlxyXG4vLyBSZXN0cmljdGluZyBwYXJ0aWFsLWlkIGVtaXNzaW9uIHRvIFVzZXJNZWRpYSBzdG9wcyB0aGUgZmxvb2RzIG9mXHJcbi8vIGZhbHNlIHBvc2l0aXZlcyByZXBvcnRlZCBvbiBSZXBsaWVzIC8gVHdlZXREZXRhaWwgLyBTZWFyY2hUaW1lbGluZS5cclxuY29uc3QgUEFSVElBTF9PS19FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlck1lZGlhJ10pO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShwYXlsb2FkOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBOb3JtYWxpemVSZXN1bHQge1xyXG4gIGNvbnN0IHJhd1R3ZWV0cyA9IGNvbGxlY3RUd2VldHMocGF5bG9hZCk7XHJcbiAgY29uc3QgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdID0gW107XHJcbiAgY29uc3Qgb2JzZXJ2ZWQ6IHN0cmluZ1tdID0gW107XHJcbiAgY29uc3QgYnVpbHQgPSBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBjb25zdCBwYXJ0aWFsTWFwID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZyB8IG51bGw+KCk7XHJcbiAgY29uc3QgY29sbGVjdFBhcnRpYWxzID0gUEFSVElBTF9PS19FTkRQT0lOVFMuaGFzKGN0eC5lbmRwb2ludCk7XHJcbiAgZm9yIChjb25zdCByYXcgb2YgcmF3VHdlZXRzKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB0ID0gYnVpbGRUd2VldChyYXcsIGN0eCk7XHJcbiAgICAgIGlmICghdCkge1xyXG4gICAgICAgIGlmIChjb2xsZWN0UGFydGlhbHMpIHtcclxuICAgICAgICAgIC8vIE9ubHkgZW5xdWV1ZSByZWFsLXR3ZWV0IHNoZWxscyAobm90IHRvbWJzdG9uZXMsIG5vdCBzdHJpcHBlZFxyXG4gICAgICAgICAgLy8gbm9kZXMgbGFja2luZyBhIGxlZ2FjeSBibG9jaywgbm90IGdhcmJhZ2UgSURzKS5cclxuICAgICAgICAgIGNvbnN0IHBhcnRpYWwgPSBwaWNrUGFydGlhbChyYXcpO1xyXG4gICAgICAgICAgaWYgKHBhcnRpYWwpIHBhcnRpYWxNYXAuc2V0KHBhcnRpYWwudHdlZXRfaWQsIHBhcnRpYWwuaGludF9oYW5kbGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb250aW51ZTtcclxuICAgICAgfVxyXG4gICAgICBvYnNlcnZlZC5wdXNoKHQudHdlZXRfaWQpO1xyXG4gICAgICBidWlsdC5hZGQodC50d2VldF9pZCk7XHJcbiAgICAgIGlmIChjdHguYWxsb3dlZEhhbmRsZXMuc2l6ZSA9PT0gMCB8fCBjdHguYWxsb3dlZEhhbmRsZXMuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcclxuICAgICAgICB0d2VldHMucHVzaCh0KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIE9uZSBiYWQgZW50cnkgc2hvdWxkbid0IHRha2UgZG93biB0aGUgd2hvbGUgYmF0Y2guXHJcbiAgICB9XHJcbiAgfVxyXG4gIC8vIEFueXRoaW5nIHRoYXQgZW5kZWQgdXAgaW4gcGFydGlhbE1hcCBidXQgQUxTTyBjYW1lIGJhY2sgYXMgYSBidWlsdFxyXG4gIC8vIHR3ZWV0IChkaWZmZXJlbnQgd2Fsa2VyIHBhc3MsIHNhbWUgaWQpIGlzbid0IGFjdHVhbGx5IHBhcnRpYWwuXHJcbiAgY29uc3QgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcclxuICBmb3IgKGNvbnN0IFtpZCwgaGludF0gb2YgcGFydGlhbE1hcCkge1xyXG4gICAgaWYgKGJ1aWx0LmhhcyhpZCkpIGNvbnRpbnVlO1xyXG4gICAgcGFydGlhbF9pZHMucHVzaCh7IHR3ZWV0X2lkOiBpZCwgaGludF9oYW5kbGU6IGhpbnQgfSk7XHJcbiAgfVxyXG4gIHJldHVybiB7IHR3ZWV0cywgb2JzZXJ2ZWRfaWRzOiBvYnNlcnZlZCwgcGFydGlhbF9pZHMgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gcGlja1BhcnRpYWwobm9kZTogdW5rbm93bik6IHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfSB8IG51bGwge1xyXG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcbiAgLy8gRGVsZXRlZCB0d2VldHMgc3VyZmFjZSBhcyBUd2VldFRvbWJzdG9uZSBcdTIwMTQgdGhlcmUncyBub3RoaW5nIHRvIHJlZmV0Y2gsXHJcbiAgLy8gc2tpcCB0aGVtIG9yIHRoZSBjcmF3bCBsb29wIHdpbGwgc3BpbiBvbiBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXHJcbiAgaWYgKG4uX190eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XHJcbiAgLy8gUmVxdWlyZSBhIHJlY29nbml6ZWQgVHdlZXQgdHlwZW5hbWUgT1IgYSBsZWdhY3kgYmxvY2suIEN1cnNvcnMsIGFkcyxcclxuICAvLyBtb2R1bGUgaGVhZGVycywgYW5kIHRoZSBsaWtlIGdldCByZWplY3RlZCBoZXJlLlxyXG4gIGNvbnN0IHRuID0gbi5fX3R5cGVuYW1lO1xyXG4gIGlmICh0biAhPT0gJ1R3ZWV0JyAmJiB0biAhPT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiAhb2JqKG4ubGVnYWN5KSkge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG4gIGNvbnN0IHJlc3RJZCA9XHJcbiAgICAodHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgbi5yZXN0X2lkKSB8fFxyXG4gICAgKHR5cGVvZiBvYmoobi50d2VldF9yZXN1bHQpPy5yZXN1bHQgPT09ICdvYmplY3QnICYmXHJcbiAgICAgIChvYmoob2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCBhcyBzdHJpbmcpKTtcclxuICBpZiAodHlwZW9mIHJlc3RJZCAhPT0gJ3N0cmluZycgfHwgIVRXRUVUX0lEX1JFLnRlc3QocmVzdElkKSkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIHsgdHdlZXRfaWQ6IHJlc3RJZCwgaGludF9oYW5kbGU6IHBpY2tIaW50SGFuZGxlKG5vZGUpIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tIaW50SGFuZGxlKG5vZGU6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIGNvbnN0IHVzZXJSZXN1bHQgPSBvYmoob2JqKG9iaihuLmNvcmUpPy51c2VyX3Jlc3VsdHMpPy5yZXN1bHQpO1xyXG4gIHJldHVybiAoXHJcbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmNvcmUpPy5zY3JlZW5fbmFtZSkgPz9cclxuICAgIHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubGVnYWN5KT8uc2NyZWVuX25hbWUpID8/XHJcbiAgICBzdHJPck51bGwob2JqKG4ubGVnYWN5KT8uc2NyZWVuX25hbWUpXHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gY29sbGVjdFR3ZWV0cyhvYmo6IHVua25vd24pOiB1bmtub3duW10ge1xyXG4gIC8vIFdhbGsgdGhlIHJlc3BvbnNlIHRyZWUgZ2F0aGVyaW5nIGV2ZXJ5dGhpbmcgdGhhdCBsb29rcyBsaWtlIGEgdHdlZXRcclxuICAvLyByZXN1bHQuIFdlIGxvb2sgZm9yIG5vZGVzIHNoYXBlZCBsaWtlOlxyXG4gIC8vICAgeyBfX3R5cGVuYW1lPzogJ1R3ZWV0J3wnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnLCByZXN0X2lkLCBsZWdhY3kgfVxyXG4gIC8vIGFuZCB1bndyYXAgdmlzaWJpbGl0eSB3cmFwcGVycy5cclxuICBjb25zdCBvdXQ6IHVua25vd25bXSA9IFtdO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtvYmpdO1xyXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBub2RlID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAobm9kZSA9PT0gbnVsbCB8fCBub2RlID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAoc2Vlbi5oYXMobm9kZSBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKG5vZGUgYXMgb2JqZWN0KTtcclxuXHJcbiAgICBpZiAobG9va3NMaWtlVHdlZXQobm9kZSkpIHtcclxuICAgICAgb3V0LnB1c2godW53cmFwVHdlZXQobm9kZSkpO1xyXG4gICAgfVxyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkobm9kZSkpIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIG5vZGUpIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuZnVuY3Rpb24gbG9va3NMaWtlVHdlZXQobm9kZTogdW5rbm93bik6IG5vZGUgaXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xyXG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xyXG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIGNvbnN0IHR5cGVuYW1lID0gbi5fX3R5cGVuYW1lO1xyXG4gIGlmIChcclxuICAgIHR5cGVuYW1lID09PSAnVHdlZXQnIHx8XHJcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyB8fFxyXG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZSdcclxuICApIHtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICAvLyBTb21lIGVudHJpZXMgbGFjayBfX3R5cGVuYW1lIGJ1dCBzdGlsbCBjYXJyeSBsZWdhY3kgKyByZXN0X2lkICsgY29yZS5cclxuICByZXR1cm4gdHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgdHlwZW9mIG4ubGVnYWN5ID09PSAnb2JqZWN0JyAmJiBuLmxlZ2FjeSAhPT0gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gdW53cmFwVHdlZXQobm9kZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XHJcbiAgaWYgKG5vZGUuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiB0eXBlb2Ygbm9kZS50d2VldCA9PT0gJ29iamVjdCcpIHtcclxuICAgIHJldHVybiBub2RlLnR3ZWV0IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIH1cclxuICByZXR1cm4gbm9kZTtcclxufVxyXG5cclxuZnVuY3Rpb24gYnVpbGRUd2VldChyYXc6IHVua25vd24sIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IENhbm9uaWNhbFR3ZWV0IHwgbnVsbCB7XHJcbiAgaWYgKHR5cGVvZiByYXcgIT09ICdvYmplY3QnIHx8IHJhdyA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgdCA9IHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuXHJcbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IHJlc3RJZCA9IHN0ck9yTnVsbCh0LnJlc3RfaWQpO1xyXG4gIC8vIGBsZWdhY3lgIGlzIHN0aWxsIHdoZXJlIG1vc3QgZW5nYWdlbWVudCAvIGVudGl0aWVzIGxpdmUgaW4gMjAyNi1lcmEgWFxyXG4gIC8vIHBheWxvYWRzLCBidXQgYXMgb2YgcmVjZW50IHNjaGVtYSBtaWdyYXRpb25zIHNldmVyYWwgZmllbGRzIHByZXZpb3VzbHlcclxuICAvLyB0aGVyZSAobm90YWJseSB0aGUgYXV0aG9yIGhhbmRsZSkgaGF2ZSBtb3ZlZCB0byBzaWJsaW5nIGxvY2F0aW9ucy4gV2VcclxuICAvLyB0b2xlcmF0ZSBhIG1pc3NpbmcgbGVnYWN5IGhlcmUgYW5kIGxvb2sgdXAgZXZlcnl0aGluZyB2aWEgZmFsbGJhY2tzLlxyXG4gIGNvbnN0IGxlZ2FjeSA9IG9iaih0LmxlZ2FjeSkgPz8ge307XHJcbiAgaWYgKCFyZXN0SWQpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCBjb3JlID0gb2JqKHQuY29yZSk7XHJcbiAgY29uc3QgdXNlclJlc3VsdCA9IG9iaihvYmooY29yZT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcclxuICAvLyBBdXRob3IgaGFuZGxlOiB0cnkgdGhlIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIGZpcnN0IChjdXJyZW50IFggc2hhcGUpLFxyXG4gIC8vIHRoZW4gdGhlIGxlZ2FjeSBgbGVnYWN5LnNjcmVlbl9uYW1lYCwgdGhlbiBhIGNvdXBsZSBvZiBvbGRlciB2YXJpYW50cy5cclxuICBjb25zdCB1c2VyQ29yZU5ldyA9IG9iaih1c2VyUmVzdWx0Py5jb3JlKTtcclxuICBjb25zdCB1c2VyTGVnYWN5ID0gb2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk7XHJcbiAgY29uc3QgdXNlckF2YXRhck9iaiA9IG9iaih1c2VyUmVzdWx0Py5hdmF0YXIpO1xyXG4gIGNvbnN0IGhhbmRsZSA9XHJcbiAgICBzdHJPck51bGwodXNlckNvcmVOZXc/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKGxlZ2FjeS5zY3JlZW5fbmFtZSk7XHJcbiAgY29uc3QgYWNjb3VudElkID1cclxuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5yZXN0X2lkKSA/P1xyXG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LmlkX3N0cikgPz9cclxuICAgIHN0ck9yTnVsbChsZWdhY3kudXNlcl9pZF9zdHIpO1xyXG4gIGlmICghaGFuZGxlIHx8ICFhY2NvdW50SWQpIHJldHVybiBudWxsO1xyXG4gIC8vIEF1dGhvciBzbmFwc2hvdC4gRGlzcGxheSBuYW1lICsgYXZhdGFyIG1vdmVkIGJldHdlZW4gYGxlZ2FjeWAgYW5kIHRoZVxyXG4gIC8vIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIG92ZXIgdGltZTsgdGhlIHJlc3QgKHZlcmlmaWNhdGlvbiwgZm9sbG93ZXJcclxuICAvLyBjb3VudHMsIGFjY291bnRfY3JlYXRlZF9hdCkgaXMgc3RpbGwgaW4gYGxlZ2FjeWAuIFdlIHNuYXBzaG90IHRoZVxyXG4gIC8vIHdob2xlIFVzZXJTbmFwc2hvdCBwZXIgdHdlZXQgYmVjYXVzZSB0aGVzZSB2YWx1ZXMgZHJpZnQgb3ZlciB0aW1lXHJcbiAgLy8gYW5kIHRoZSBhdC1jYXB0dXJlIHN0YXRlIGlzIHRoZSBvbmx5IHJlbGlhYmxlIHJlY29yZC5cclxuICBjb25zdCBhdXRob3IgPSBleHRyYWN0VXNlclNuYXBzaG90KHVzZXJSZXN1bHQsIHVzZXJDb3JlTmV3LCB1c2VyTGVnYWN5LCB1c2VyQXZhdGFyT2JqKTtcclxuXHJcbiAgY29uc3Qgbm90ZVR3ZWV0ID0gb2JqKG9iaihvYmoodC5ub3RlX3R3ZWV0KT8ubm90ZV90d2VldF9yZXN1bHRzKT8ucmVzdWx0KTtcclxuICBjb25zdCB0ZXh0RnJvbU5vdGUgPSBzdHJPck51bGwobm90ZVR3ZWV0Py50ZXh0KTtcclxuICBjb25zdCB0ZXh0RnJvbUxlZ2FjeSA9IHN0ck9yTnVsbChsZWdhY3kuZnVsbF90ZXh0KSA/PyAnJztcclxuICBjb25zdCB0ZXh0ID0gdGV4dEZyb21Ob3RlID8/IHRleHRGcm9tTGVnYWN5O1xyXG4gIGNvbnN0IGlzVHJ1bmNhdGVkID0gZGV0ZWN0VHJ1bmNhdGlvbihub3RlVHdlZXQsIGxlZ2FjeSwgdGV4dEZyb21MZWdhY3kpO1xyXG4gIGNvbnN0IGNvbW11bml0eU5vdGUgPSBleHRyYWN0Q29tbXVuaXR5Tm90ZSh0LCBsZWdhY3ksIGN0eC5jYXB0dXJlZEF0KTtcclxuXHJcbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKSA/PyB7fTtcclxuICBjb25zdCBlbnRpdGllc0Zyb21Ob3RlID0gb2JqKG5vdGVUd2VldD8uZW50aXR5X3NldCk7XHJcbiAgY29uc3QgaGFzaHRhZ3MgPSBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XHJcbiAgY29uc3QgbWVudGlvbnMgPSBleHRyYWN0TWVudGlvbnMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XHJcbiAgY29uc3QgdXJscyA9IGV4dHJhY3RVcmxzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xyXG4gIGNvbnN0IG1lZGlhID0gZXh0cmFjdE1lZGlhKGxlZ2FjeSk7XHJcblxyXG4gIGNvbnN0IHR3ZWV0VHlwZSA9IGNsYXNzaWZ5VHdlZXRUeXBlKHQsIGxlZ2FjeSk7XHJcblxyXG4gIC8vIHBvc3RlZF9hdDogbGVnYWN5LmNyZWF0ZWRfYXQgcmVtYWlucyB0aGUgY2Fub25pY2FsIGxvY2F0aW9uOyBpZiB0aGF0J3NcclxuICAvLyBtaXNzaW5nIGluIGEgZnV0dXJlIHNjaGVtYSB3ZSBmYWxsIGJhY2sgdG8gdG9wLWxldmVsIGNyZWF0ZWRfYXQuXHJcbiAgY29uc3QgcG9zdGVkQXQgPVxyXG4gICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwobGVnYWN5LmNyZWF0ZWRfYXQpKSA/PyBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh0LmNyZWF0ZWRfYXQpKTtcclxuICBpZiAoIXBvc3RlZEF0KSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3Qgdmlld3MgPSBvYmoodC52aWV3cyk7XHJcbiAgY29uc3Qgdmlld0NvdW50ID0gbnVtT3JOdWxsKHZpZXdzPy5jb3VudCkgPz8gbnVtT3JOdWxsKHN0ck9yTnVsbCh2aWV3cz8uY291bnQpKTtcclxuXHJcbiAgY29uc3QgY2FyZCA9IGV4dHJhY3RDYXJkKHQpO1xyXG4gIGNvbnN0IHBsYWNlID0gb2JqKGxlZ2FjeS5wbGFjZSk7XHJcblxyXG4gIGNvbnN0IHR3ZWV0OiBDYW5vbmljYWxUd2VldCA9IHtcclxuICAgIHR3ZWV0X2lkOiByZXN0SWQsXHJcbiAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxyXG4gICAgYWNjb3VudF9pZDogYWNjb3VudElkLFxyXG4gICAgcG9zdGVkX2F0OiBwb3N0ZWRBdCxcclxuICAgIGZpcnN0X2NhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcclxuICAgIGxhc3Rfc2Vlbl9hdDogY3R4LmNhcHR1cmVkQXQsXHJcbiAgICBkZWxldGlvbl9kZXRlY3RlZF9hdDogbnVsbCxcclxuICAgIHR3ZWV0X3VybDogYCR7VFdFRVRfVVJMX1BSRUZJWH0vJHtoYW5kbGV9L3N0YXR1cy8ke3Jlc3RJZH1gLFxyXG4gICAgdHdlZXRfdHlwZTogdHdlZXRUeXBlLFxyXG4gICAgY29udmVyc2F0aW9uX2lkOiBzdHJPck51bGwobGVnYWN5LmNvbnZlcnNhdGlvbl9pZF9zdHIpLFxyXG4gICAgcmVwbHlfdG9fdHdlZXRfaWQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0ciksXHJcbiAgICByZXBseV90b19hY2NvdW50OiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3NjcmVlbl9uYW1lKSxcclxuICAgIHJlcGx5X3RvX2FjY291bnRfaWQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fdXNlcl9pZF9zdHIpLFxyXG4gICAgcXVvdGVkX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSxcclxuICAgIHJldHdlZXRlZF90d2VldF9pZDogc3RyT3JOdWxsKFxyXG4gICAgICBvYmoob2JqKGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX3Jlc3VsdCk/LnJlc3VsdCk/LnJlc3RfaWQgPz9cclxuICAgICAgICAobGVnYWN5IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0clxyXG4gICAgKSxcclxuICAgIHRleHQsXHJcbiAgICB0ZXh0X3Jlc29sdmVkOiByZXNvbHZlU2hvcnRVcmxzKHRleHQsIHVybHMpLFxyXG4gICAgbGFuZzogc3RyT3JOdWxsKGxlZ2FjeS5sYW5nKSxcclxuICAgIHBvc3NpYmx5X3NlbnNpdGl2ZTogYm9vbE9yTnVsbChsZWdhY3kucG9zc2libHlfc2Vuc2l0aXZlKSxcclxuICAgIHNvdXJjZTogc3RyT3JOdWxsKGxlZ2FjeS5zb3VyY2UpID8/IHN0ck9yTnVsbCh0LnNvdXJjZSksXHJcbiAgICBwbGFjZV9mdWxsX25hbWU6IHN0ck9yTnVsbChwbGFjZT8uZnVsbF9uYW1lKSxcclxuICAgIGhhc2h0YWdzLFxyXG4gICAgbWVudGlvbnMsXHJcbiAgICB1cmxzLFxyXG4gICAgY2FyZCxcclxuICAgIG1lZGlhLFxyXG4gICAgbGlrZV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5mYXZvcml0ZV9jb3VudCksXHJcbiAgICByZXR3ZWV0X2NvdW50OiBudW1Pclplcm8obGVnYWN5LnJldHdlZXRfY291bnQpLFxyXG4gICAgcmVwbHlfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucmVwbHlfY291bnQpLFxyXG4gICAgcXVvdGVfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucXVvdGVfY291bnQpLFxyXG4gICAgdmlld19jb3VudDogdmlld0NvdW50LFxyXG4gICAgYm9va21hcmtfY291bnQ6IG51bU9yTnVsbChsZWdhY3kuYm9va21hcmtfY291bnQpLFxyXG4gICAgZW5nYWdlbWVudF9oaXN0b3J5OiBbXHJcbiAgICAgIHtcclxuICAgICAgICBjYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXHJcbiAgICAgICAgbGlrZXM6IG51bU9yWmVybyhsZWdhY3kuZmF2b3JpdGVfY291bnQpLFxyXG4gICAgICAgIHJldHdlZXRzOiBudW1Pclplcm8obGVnYWN5LnJldHdlZXRfY291bnQpLFxyXG4gICAgICAgIHJlcGxpZXM6IG51bU9yWmVybyhsZWdhY3kucmVwbHlfY291bnQpLFxyXG4gICAgICAgIHF1b3RlczogbnVtT3JaZXJvKGxlZ2FjeS5xdW90ZV9jb3VudCksXHJcbiAgICAgICAgdmlld3M6IHZpZXdDb3VudCxcclxuICAgICAgICBib29rbWFya3M6IG51bU9yTnVsbChsZWdhY3kuYm9va21hcmtfY291bnQpLFxyXG4gICAgICB9LFxyXG4gICAgXSxcclxuICAgIGF1dGhvcixcclxuICAgIGNvbW11bml0eV9ub3RlOiBjb21tdW5pdHlOb3RlLFxyXG4gICAgaXNfdHJ1bmNhdGVkOiBpc1RydW5jYXRlZCxcclxuICAgIHdheWJhY2tfdXJsOiBudWxsLFxyXG4gICAgd2F5YmFja19zdWJtaXR0ZWRfYXQ6IG51bGwsXHJcbiAgICBjYXB0dXJlX3NvdXJjZTogJ2V4dGVuc2lvbicsXHJcbiAgICBjYXB0dXJlX3J1bl9pZDogY3R4LnJ1bklkLFxyXG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIHR3ZWV0O1xyXG59XHJcblxyXG5mdW5jdGlvbiBjbGFzc2lmeVR3ZWV0VHlwZSh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFR3ZWV0VHlwZSB7XHJcbiAgaWYgKGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX3Jlc3VsdCB8fCBsZWdhY3kucmV0d2VldGVkX3N0YXR1c19pZF9zdHIpIHJldHVybiAncmV0d2VldCc7XHJcbiAgaWYgKGxlZ2FjeS5pbl9yZXBseV90b19zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JlcGx5JztcclxuICBpZiAobGVnYWN5LmlzX3F1b3RlX3N0YXR1cyA9PT0gdHJ1ZSB8fCBsZWdhY3kucXVvdGVkX3N0YXR1c19pZF9zdHIpIHJldHVybiAncXVvdGUnO1xyXG4gIGlmICh0Ll9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycpIHtcclxuICAgIC8vIHBhc3MgdGhyb3VnaFxyXG4gIH1cclxuICByZXR1cm4gJ29yaWdpbmFsJztcclxufVxyXG5cclxuZnVuY3Rpb24gZXh0cmFjdEhhc2h0YWdzKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZ1tdIHtcclxuICBjb25zdCBhcnIgPSBlbnRpdGllcy5oYXNodGFncztcclxuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xyXG4gIHJldHVybiBhcnJcclxuICAgIC5tYXAoKGgpID0+XHJcbiAgICAgIHR5cGVvZiBoID09PSAnb2JqZWN0JyAmJiBoICYmICd0ZXh0JyBpbiBoID8gU3RyaW5nKChoIGFzIHsgdGV4dDogdW5rbm93biB9KS50ZXh0KSA6IG51bGxcclxuICAgIClcclxuICAgIC5maWx0ZXIoKHMpOiBzIGlzIHN0cmluZyA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5sZW5ndGggPiAwKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZ1tdIHtcclxuICBjb25zdCBhcnIgPSBlbnRpdGllcy51c2VyX21lbnRpb25zO1xyXG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XHJcbiAgcmV0dXJuIGFyclxyXG4gICAgLm1hcCgodSkgPT5cclxuICAgICAgdHlwZW9mIHUgPT09ICdvYmplY3QnICYmIHUgJiYgJ3NjcmVlbl9uYW1lJyBpbiB1XHJcbiAgICAgICAgPyBTdHJpbmcoKHUgYXMgeyBzY3JlZW5fbmFtZTogdW5rbm93biB9KS5zY3JlZW5fbmFtZSlcclxuICAgICAgICA6IG51bGxcclxuICAgIClcclxuICAgIC5maWx0ZXIoKHMpOiBzIGlzIHN0cmluZyA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5sZW5ndGggPiAwKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZXh0cmFjdFVybHMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVXJsRW50aXR5W10ge1xyXG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLnVybHM7XHJcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcclxuICBjb25zdCBvdXQ6IFVybEVudGl0eVtdID0gW107XHJcbiAgZm9yIChjb25zdCB1IG9mIGFycikge1xyXG4gICAgaWYgKHR5cGVvZiB1ICE9PSAnb2JqZWN0JyB8fCB1ID09PSBudWxsKSBjb250aW51ZTtcclxuICAgIGNvbnN0IG8gPSB1IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gICAgY29uc3Qgc2hvcnQgPSBzdHJPck51bGwoby51cmwpO1xyXG4gICAgY29uc3QgZXhwYW5kZWQgPSBzdHJPck51bGwoby5leHBhbmRlZF91cmwpO1xyXG4gICAgY29uc3QgZGlzcGxheSA9IHN0ck9yTnVsbChvLmRpc3BsYXlfdXJsKTtcclxuICAgIGlmICghc2hvcnQgfHwgIWV4cGFuZGVkKSBjb250aW51ZTtcclxuICAgIG91dC5wdXNoKHsgc2hvcnQsIGV4cGFuZGVkLCBkaXNwbGF5OiBkaXNwbGF5ID8/IGV4cGFuZGVkIH0pO1xyXG4gIH1cclxuICByZXR1cm4gb3V0O1xyXG59XHJcblxyXG5mdW5jdGlvbiBleHRyYWN0TWVkaWEobGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbVtdIHtcclxuICBjb25zdCBleHRlbmRlZCA9IG9iaihsZWdhY3kuZXh0ZW5kZWRfZW50aXRpZXMpO1xyXG4gIGNvbnN0IGZyb21FeHQgPSBleHRlbmRlZCA/IHRvQXJyYXkoZXh0ZW5kZWQubWVkaWEpIDogW107XHJcbiAgY29uc3QgZnJvbUVudCA9IHRvQXJyYXkob2JqKGxlZ2FjeS5lbnRpdGllcyk/Lm1lZGlhKTtcclxuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbiAgY29uc3QgbWVyZ2VkID0gWy4uLmZyb21FeHQsIC4uLmZyb21FbnRdLmZpbHRlcigobSkgPT4ge1xyXG4gICAgaWYgKHR5cGVvZiBtICE9PSAnb2JqZWN0JyB8fCBtID09PSBudWxsKSByZXR1cm4gZmFsc2U7XHJcbiAgICBjb25zdCBpZCA9XHJcbiAgICAgIHN0ck9yTnVsbCgobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikubWVkaWFfa2V5KSA/P1xyXG4gICAgICBzdHJPck51bGwoKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLmlkX3N0cik7XHJcbiAgICBpZiAoIWlkKSByZXR1cm4gZmFsc2U7XHJcbiAgICBpZiAoc2Vlbi5oYXMoaWQpKSByZXR1cm4gZmFsc2U7XHJcbiAgICBzZWVuLmFkZChpZCk7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9KTtcclxuICByZXR1cm4gbWVyZ2VkLm1hcCgocmF3KSA9PiBidWlsZE1lZGlhKHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBidWlsZE1lZGlhKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogTWVkaWFJdGVtIHtcclxuICBjb25zdCB0eXBlID0gc3RyT3JOdWxsKG0udHlwZSkgYXMgTWVkaWFJdGVtWydtZWRpYV90eXBlJ107XHJcbiAgY29uc3Qgb3JpZ2luYWwgPSBwaWNrT3JpZ2luYWxVcmwobSwgdHlwZSk7XHJcbiAgY29uc3QgaW5mbyA9IG9iaihtLm9yaWdpbmFsX2luZm8pO1xyXG4gIGNvbnN0IHZpZGVvSW5mbyA9IG9iaihtLnZpZGVvX2luZm8pO1xyXG4gIGNvbnN0IGR1cmF0aW9uTXMgPSBudW1Pck51bGwodmlkZW9JbmZvPy5kdXJhdGlvbl9taWxsaXMpO1xyXG4gIGNvbnN0IGFsdFRleHQgPSBzdHJPck51bGwobS5leHRfYWx0X3RleHQpO1xyXG4gIGNvbnN0IG1lZGlhSWQgPVxyXG4gICAgc3RyT3JOdWxsKG0ubWVkaWFfa2V5KSA/P1xyXG4gICAgc3RyT3JOdWxsKG0uaWRfc3RyKSA/P1xyXG4gICAgYCR7dHlwZSA/PyAnbWVkaWEnfS0ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIpfWA7XHJcbiAgcmV0dXJuIHtcclxuICAgIG1lZGlhX2lkOiBtZWRpYUlkLFxyXG4gICAgbWVkaWFfdHlwZTogKHR5cGUgPz8gJ3Bob3RvJykgYXMgTWVkaWFJdGVtWydtZWRpYV90eXBlJ10sXHJcbiAgICBvcmlnaW5hbF91cmw6IG9yaWdpbmFsID8/ICcnLFxyXG4gICAgcmVsZWFzZV9hc3NldF91cmw6IG51bGwsXHJcbiAgICBzaGEyNTY6IG51bGwsXHJcbiAgICBieXRlczogbnVsbCxcclxuICAgIGR1cmF0aW9uX3NlYzogZHVyYXRpb25NcyAhPT0gbnVsbCA/IGR1cmF0aW9uTXMgLyAxMDAwIDogbnVsbCxcclxuICAgIHdpZHRoOiBudW1Pck51bGwoaW5mbz8ud2lkdGgpLFxyXG4gICAgaGVpZ2h0OiBudW1Pck51bGwoaW5mbz8uaGVpZ2h0KSxcclxuICAgIGFsdF90ZXh0OiBhbHRUZXh0LFxyXG4gICAgYXJjaGl2ZV9zdGF0dXM6ICdwZW5kaW5nJyxcclxuICAgIGFyY2hpdmVfYXR0ZW1wdHM6IDAsXHJcbiAgICBsYXN0X2F0dGVtcHRfYXQ6IG51bGwsXHJcbiAgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gcGlja09yaWdpbmFsVXJsKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCB0eXBlOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgaWYgKHR5cGUgPT09ICdwaG90bycpIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpID8/IHN0ck9yTnVsbChtLm1lZGlhX3VybCk7XHJcbiAgY29uc3QgdmFyaWFudHMgPSB0b0FycmF5KG9iaihtLnZpZGVvX2luZm8pPy52YXJpYW50cykgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj5bXTtcclxuICBpZiAodmFyaWFudHMubGVuZ3RoID09PSAwKSByZXR1cm4gc3RyT3JOdWxsKG0ubWVkaWFfdXJsX2h0dHBzKTtcclxuICAvLyBIaWdoZXN0LWJpdHJhdGUgbXA0LlxyXG4gIGxldCBiZXN0OiB7IHVybDogc3RyaW5nOyBiaXRyYXRlOiBudW1iZXIgfSB8IG51bGwgPSBudWxsO1xyXG4gIGZvciAoY29uc3QgdiBvZiB2YXJpYW50cykge1xyXG4gICAgY29uc3QgY3QgPSBzdHJPck51bGwodi5jb250ZW50X3R5cGUpO1xyXG4gICAgY29uc3QgdXJsID0gc3RyT3JOdWxsKHYudXJsKTtcclxuICAgIGlmICghdXJsKSBjb250aW51ZTtcclxuICAgIGlmIChjdCA9PT0gJ3ZpZGVvL21wNCcpIHtcclxuICAgICAgY29uc3QgYnIgPSBudW1Pck51bGwodi5iaXRyYXRlKSA/PyAwO1xyXG4gICAgICBpZiAoIWJlc3QgfHwgYnIgPiBiZXN0LmJpdHJhdGUpIGJlc3QgPSB7IHVybCwgYml0cmF0ZTogYnIgfTtcclxuICAgIH0gZWxzZSBpZiAoIWJlc3QpIHtcclxuICAgICAgLy8gRmFsbGJhY2sgdG8gYW55IHZhcmlhbnQgaWYgbm8gbXA0IGZvdW5kLlxyXG4gICAgICBiZXN0ID0geyB1cmwsIGJpdHJhdGU6IDAgfTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIGJlc3Q/LnVybCA/PyBudWxsO1xyXG59XHJcblxyXG5mdW5jdGlvbiByZXNvbHZlU2hvcnRVcmxzKHRleHQ6IHN0cmluZywgdXJsczogVXJsRW50aXR5W10pOiBzdHJpbmcge1xyXG4gIGlmICh1cmxzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHRleHQ7XHJcbiAgbGV0IG91dCA9IHRleHQ7XHJcbiAgZm9yIChjb25zdCB1IG9mIHVybHMpIG91dCA9IG91dC5zcGxpdCh1LnNob3J0KS5qb2luKHUuZXhwYW5kZWQpO1xyXG4gIHJldHVybiBvdXQ7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhcnNlVHdpdHRlckRhdGUoczogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xyXG4gIGlmICghcykgcmV0dXJuIG51bGw7XHJcbiAgLy8gVHdpdHRlciBzaGlwcyBkYXRlcyBsaWtlIFwiTW9uIEFwciAxMiAxNDoyMzowMSArMDAwMCAyMDI1XCIuXHJcbiAgY29uc3QgZCA9IG5ldyBEYXRlKHMpO1xyXG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4gZC50b0lTT1N0cmluZygpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdHJPck51bGwodjogdW5rbm93bik6IHN0cmluZyB8IG51bGwge1xyXG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwID8gdiA6IG51bGw7XHJcbn1cclxuZnVuY3Rpb24gYm9vbE9yTnVsbCh2OiB1bmtub3duKTogYm9vbGVhbiB8IG51bGwge1xyXG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nID8gdiA6IG51bGw7XHJcbn1cclxuZnVuY3Rpb24gbnVtT3JOdWxsKHY6IHVua25vd24pOiBudW1iZXIgfCBudWxsIHtcclxuICBpZiAodHlwZW9mIHYgPT09ICdudW1iZXInICYmIE51bWJlci5pc0Zpbml0ZSh2KSkgcmV0dXJuIHY7XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IG4gPSBOdW1iZXIodik7XHJcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKG4pKSByZXR1cm4gbjtcclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuZnVuY3Rpb24gbnVtT3JaZXJvKHY6IHVua25vd24pOiBudW1iZXIge1xyXG4gIHJldHVybiBudW1Pck51bGwodikgPz8gMDtcclxufVxyXG5mdW5jdGlvbiBvYmoodjogdW5rbm93bik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCB7XHJcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnb2JqZWN0JyAmJiB2ICE9PSBudWxsICYmICFBcnJheS5pc0FycmF5KHYpXHJcbiAgICA/ICh2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVxyXG4gICAgOiBudWxsO1xyXG59XHJcbmZ1bmN0aW9uIHRvQXJyYXkodjogdW5rbm93bik6IHVua25vd25bXSB7XHJcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkodikgPyB2IDogW107XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBEZWNpZGUgd2hldGhlciBhIHR3ZWV0J3MgYXJjaGl2ZWQgYHRleHRgIGlzIHRoZSB0cnVuY2F0ZWQgaGVhZCBvZiBhIGxvbmdlclxyXG4gKiBib2R5LiBBIHRydW5jYXRlZCB0d2VldCBoYXMgWCdzIFwiU2hvdyBtb3JlXCIgdC5jbyBVUkwgYXBwZW5kZWQgXHUyMDE0IHRoYXQgVVJMXHJcbiAqIHNwZWNpZmljYWxseSBleHBhbmRzIHRvIHRoZSB0d2VldCdzIG93biAvaS93ZWIvc3RhdHVzLzxpZD4gcGVybWFsaW5rLCBhbmRcclxuICogaXMgdGhlIG9ubHkgcmVsaWFibGUgZGlzdGluZ3Vpc2hpbmcgZmVhdHVyZS4gUGxlbnR5IG9mIG5vcm1hbCB0d2VldHMgaGF2ZVxyXG4gKiB0cmFpbGluZyB0LmNvIFVSTHMgKG1lZGlhLCBxdW90ZXMsIHJlZ3VsYXIgbGlua3MpLCBhbmQgdGhlaXJcclxuICogZGlzcGxheV90ZXh0X3JhbmdlIGFsc28gdHJpbXMgcGFzdCBmdWxsX3RleHQubGVuZ3RoLCBzbyB0aGUgb2xkXHJcbiAqIFwiZGlzcGxheV90ZXh0X3JhbmdlWzFdIDwgZnVsbF90ZXh0Lmxlbmd0aFwiIGhldXJpc3RpYyB3YXMgb3ZlcmZsYWdnaW5nXHJcbiAqIGVzc2VudGlhbGx5IGV2ZXJ5IHR3ZWV0IHdpdGggYSBsaW5rIGluIGl0LlxyXG4gKlxyXG4gKiBSdWxlczpcclxuICogICAtIG5vdGVfdHdlZXQgcHJlc2VudCAgXHUyMTkyIG5vdCB0cnVuY2F0ZWQgKHdlIGFscmVhZHkgaGF2ZSB0aGUgZnVsbCBib2R5KS5cclxuICogICAtIE9uZSBvZiBsZWdhY3kuZW50aXRpZXMudXJscyBoYXMgYW4gZXhwYW5kZWRfdXJsIGxpa2VcclxuICogICAgIFwiLi4uL2kvd2ViL3N0YXR1cy88aWQ+XCIgIFx1MjE5MiAgdHJ1bmNhdGVkLlxyXG4gKiAgIC0gT3RoZXJ3aXNlIFx1MjE5MiBub3QgdHJ1bmNhdGVkLlxyXG4gKlxyXG4gKiBUaGUgcHJldmlvdXMgZmFsbGJhY2sgKFwidHJhaWxpbmcgdC5jbyBVUkwgKyBsZW5ndGggXHUyMjY1IDI3MFwiKSBmbGFnZ2VkIGV2ZXJ5XHJcbiAqIG1lZGlhIHR3ZWV0IGV4YWN0bHkgYXQgdGhlIDI4MC1jaGFyIGxpbWl0LiBXZSBkcm9wIGl0IGVudGlyZWx5OyB0aGUgb25seVxyXG4gKiBjb3N0IGlzIG1pc3NpbmcgZ2VudWluZWx5LXRydW5jYXRlZCB0d2VldHMgd2hvc2UgcGF5bG9hZCB3YXMgc28gZGVncmFkZWRcclxuICogaXQgbGFja2VkIGVudGl0aWVzIFx1MjAxNCB3aGljaCBpcyBhbHNvIHdoZXJlIHRoZSByZWZldGNoIGxvb3Agd291bGQgZmFpbFxyXG4gKiBhbnl3YXksIHNvIG5vdGhpbmcgaXMgYWN0dWFsbHkgbG9zdC5cclxuICovXHJcbmZ1bmN0aW9uIGRldGVjdFRydW5jYXRpb24oXHJcbiAgbm90ZVR3ZWV0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXHJcbiAgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcclxuICBmdWxsVGV4dDogc3RyaW5nXHJcbik6IGJvb2xlYW4ge1xyXG4gIGlmIChub3RlVHdlZXQpIHJldHVybiBmYWxzZTtcclxuICBpZiAoIWZ1bGxUZXh0KSByZXR1cm4gZmFsc2U7XHJcbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKTtcclxuICBjb25zdCB1cmxzID0gZW50aXRpZXMgPyBlbnRpdGllcy51cmxzIDogbnVsbDtcclxuICBpZiAoQXJyYXkuaXNBcnJheSh1cmxzKSkge1xyXG4gICAgZm9yIChjb25zdCB1IG9mIHVybHMpIHtcclxuICAgICAgaWYgKHR5cGVvZiB1ICE9PSAnb2JqZWN0JyB8fCB1ID09PSBudWxsKSBjb250aW51ZTtcclxuICAgICAgY29uc3QgZXhwID0gKHUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLmV4cGFuZGVkX3VybDtcclxuICAgICAgLy8gVGhlIFwiU2hvdyBtb3JlXCIgbGluayBleHBhbmRzIHRvIGVpdGhlciBvZiB0aGVzZSBzZWxmLXBlcm1hbGlua1xyXG4gICAgICAvLyBzaGFwZXM6ICBodHRwczovL3guY29tL2kvd2ViL3N0YXR1cy88aWQ+XHJcbiAgICAgIC8vICAgICAgICAgIGh0dHBzOi8vdHdpdHRlci5jb20vaS93ZWIvc3RhdHVzLzxpZD5cclxuICAgICAgaWYgKHR5cGVvZiBleHAgPT09ICdzdHJpbmcnICYmIC9cXC9pXFwvd2ViXFwvc3RhdHVzXFwvXFxkKy8udGVzdChleHApKSB7XHJcbiAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIGZhbHNlO1xyXG59XHJcblxyXG4vKipcclxuICogRmlsdGVyIGB0d2VldHNgIGRvd24gdG8gdGhvc2UgcmVsYXRlZCB0byBhIHRyYWNrZWQgYWNjb3VudC4gQSB0d2VldCBpc1xyXG4gKiBcInJlbGF0ZWRcIiBpZiBhbnkgb2YgdGhlIGZvbGxvd2luZyBob2xkOlxyXG4gKlxyXG4gKiAgIC0gaXRzIGF1dGhvciBpcyB0cmFja2VkIChoYW5kbGUgaW4gYHRhcmdldGVkYCksXHJcbiAqICAgLSBpdCBtZW50aW9ucyBhIHRyYWNrZWQgaGFuZGxlLFxyXG4gKiAgIC0gaXQgcmVwbGllcyB0byBhIHRyYWNrZWQgYWNjb3VudCxcclxuICogICAtIGl0IHF1b3Rlcy9yZXR3ZWV0cy9yZXBsaWVzLXRvIGEgdHdlZXQgdGhhdCdzIGFsc28gcHJlc2VudCBpbiB0aGVcclxuICogICAgIGJhdGNoICphbmQqIGF1dGhvcmVkIGJ5IGEgdHJhY2tlZCBhY2NvdW50ICh0cmFuc2l0aXZlbHkgcmVsYXRlZCBcdTIwMTRcclxuICogICAgIGNhcHR1cmVzIHRoZSBxdW90ZWQvUlQnZCBjb250ZW50IHRoYXQgYXBwZWFycyBhcyBhIHNpYmxpbmcgbm9kZSBpblxyXG4gKiAgICAgdGhlIHNhbWUgR3JhcGhRTCByZXNwb25zZSkuXHJcbiAqXHJcbiAqIEFueXRoaW5nIGVsc2UgKHJhbmRvbSByZXBsaWVzIHVuZGVyIGEgdHJhY2tlZCBhY2NvdW50J3MgdHdlZXQsIHJhbmRvbVxyXG4gKiBhdXRob3JzIHRoYXQgaGFwcGVuIHRvIHN1cmZhY2UgaW4gYSB0cmFja2VkIGFjY291bnQncyB0aHJlYWQpIGlzIGRyb3BwZWQuXHJcbiAqIFBhc3MgYW4gZW1wdHkgYHRhcmdldGVkYCBzZXQgdG8gZGlzYWJsZSBmaWx0ZXJpbmcgZW50aXJlbHkuXHJcbiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyUmVsYXRlZChcclxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10sXHJcbiAgdGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz5cclxuKTogQ2Fub25pY2FsVHdlZXRbXSB7XHJcbiAgaWYgKHRhcmdldGVkLnNpemUgPT09IDApIHJldHVybiB0d2VldHM7XHJcbiAgLy8gRmlyc3QgcGFzczogd2hpY2ggdHdlZXQgSURzIGRvIHRyYWNrZWQtYXV0aG9yIHR3ZWV0cyByZWZlcmVuY2UgKHRoZVxyXG4gIC8vIFwiZm9yd2FyZFwiIGRpcmVjdGlvbiBcdTIwMTQgdHJhY2tlZCBhY2NvdW50IHF1b3RlcyAvIFJUcyAvIHJlcGxpZXMgdG8gWCk/XHJcbiAgLy8gQW5kIHdoaWNoIHR3ZWV0IElEcyBBUkUgdHJhY2tlZC1hdXRob3JlZCAodGhlIFwicmV2ZXJzZVwiIGRpcmVjdGlvbiBcdTIwMTRcclxuICAvLyBYIHF1b3RlcyAvIFJUcyAvIHJlcGxpZXMgdG8gYSB0cmFja2VkIHR3ZWV0KT9cclxuICBjb25zdCByZWZlcmVuY2VkSWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbiAgY29uc3QgdGFyZ2V0ZWRUd2VldElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcclxuICAgIGlmICghdGFyZ2V0ZWQuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIGNvbnRpbnVlO1xyXG4gICAgdGFyZ2V0ZWRUd2VldElkcy5hZGQodC50d2VldF9pZCk7XHJcbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucXVvdGVkX3R3ZWV0X2lkKTtcclxuICAgIGlmICh0LnJldHdlZXRlZF90d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpO1xyXG4gICAgaWYgKHQucmVwbHlfdG9fdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucmVwbHlfdG9fdHdlZXRfaWQpO1xyXG4gIH1cclxuICByZXR1cm4gdHdlZXRzLmZpbHRlcigodCkgPT4ge1xyXG4gICAgY29uc3QgaCA9IHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKTtcclxuICAgIGlmICh0YXJnZXRlZC5oYXMoaCkpIHJldHVybiB0cnVlO1xyXG4gICAgLy8gRm9yd2FyZDogYSB0cmFja2VkLWF1dGhvciB0d2VldCBwb2ludGVkIGF0IHRoaXMgb25lLlxyXG4gICAgaWYgKHJlZmVyZW5jZWRJZHMuaGFzKHQudHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcclxuICAgIC8vIFJldmVyc2U6IHRoaXMgdHdlZXQgcG9pbnRzIGF0IGEgdHJhY2tlZC1hdXRob3IgdHdlZXQgaW4gdGhlIGJhdGNoLlxyXG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucXVvdGVkX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XHJcbiAgICBpZiAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQgJiYgdGFyZ2V0ZWRUd2VldElkcy5oYXModC5yZXR3ZWV0ZWRfdHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcclxuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucmVwbHlfdG9fdHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcclxuICAgIC8vIFJlcGx5LXRvLWFjY291bnQgb3IgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZS5cclxuICAgIGlmICh0LnJlcGx5X3RvX2FjY291bnQgJiYgdGFyZ2V0ZWQuaGFzKHQucmVwbHlfdG9fYWNjb3VudC50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIHRydWU7XHJcbiAgICBmb3IgKGNvbnN0IG0gb2YgdC5tZW50aW9ucykge1xyXG4gICAgICBpZiAodGFyZ2V0ZWQuaGFzKG0udG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogUHVsbCB0aGUgQ29tbXVuaXR5IE5vdGUgKGZvcm1lcmx5IEJpcmR3YXRjaCkgYmxvY2sgYXR0YWNoZWQgdG8gYSB0d2VldCwgaWZcclxuICogYW55LiBUaGUgcGl2b3QgY2FuIGxpdmUgYXQgYHR3ZWV0LmxlZ2FjeS5iaXJkd2F0Y2hfcGl2b3RgIChvbGRlciBzaGFwZSkgb3JcclxuICogYHR3ZWV0LmJpcmR3YXRjaF9waXZvdGAgKGN1cnJlbnQgc2hhcGUpLiBUaGUgc3VtbWFyeSB0ZXh0IGlzIHdoYXQgcmVhZGVyc1xyXG4gKiBhY3R1YWxseSBzZWU7IHdlIGtlZXAgdGhlIHN1cnJvdW5kaW5nIG1ldGFkYXRhIHNvIGRvd25zdHJlYW0gdG9vbGluZyBjYW5cclxuICogdGVsbCBkcmFmdHMgYXBhcnQgZnJvbSByYXRlZC1oZWxwZnVsIG5vdGVzLlxyXG4gKi9cclxuZnVuY3Rpb24gZXh0cmFjdENvbW11bml0eU5vdGUoXHJcbiAgdDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXHJcbiAgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcclxuICBvYnNlcnZlZEF0OiBzdHJpbmdcclxuKTogQ29tbXVuaXR5Tm90ZSB8IG51bGwge1xyXG4gIGNvbnN0IHBpdm90ID0gb2JqKHQuYmlyZHdhdGNoX3Bpdm90KSA/PyBvYmoobGVnYWN5LmJpcmR3YXRjaF9waXZvdCk7XHJcbiAgaWYgKCFwaXZvdCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3Qgc3VidGl0bGUgPSBvYmoocGl2b3Quc3VidGl0bGUpO1xyXG4gIGNvbnN0IG5vdGUgPSBvYmoocGl2b3Qubm90ZSk7XHJcbiAgY29uc3Qgc3VtbWFyeSA9IHN0ck9yTnVsbChzdWJ0aXRsZT8udGV4dCk7XHJcbiAgY29uc3QgdGl0bGUgPSBzdHJPck51bGwocGl2b3QudGl0bGUpO1xyXG4gIGNvbnN0IHNob3J0VGl0bGUgPSBzdHJPck51bGwocGl2b3Quc2hvcnRUaXRsZSk7XHJcbiAgY29uc3QgZGVzdGluYXRpb25VcmwgPSBzdHJPck51bGwocGl2b3QuZGVzdGluYXRpb25VcmwpO1xyXG4gIGNvbnN0IG5vdGVJZCA9IHN0ck9yTnVsbChwaXZvdC5ub3RlSWQpID8/IHN0ck9yTnVsbChub3RlPy5yZXN0X2lkKTtcclxuICAvLyBTa2lwIGVtcHR5IHNoZWxscyB0aGF0IGhhdmUgbm8gYWN0dWFsIGNvbnRlbnQuXHJcbiAgaWYgKCFzdW1tYXJ5ICYmICF0aXRsZSAmJiAhbm90ZUlkKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4ge1xyXG4gICAgbm90ZV9pZDogbm90ZUlkLFxyXG4gICAgdGl0bGUsXHJcbiAgICBzaG9ydF90aXRsZTogc2hvcnRUaXRsZSxcclxuICAgIHN1bW1hcnksXHJcbiAgICBkZXN0aW5hdGlvbl91cmw6IGRlc3RpbmF0aW9uVXJsLFxyXG4gICAgb2JzZXJ2ZWRfYXQ6IG9ic2VydmVkQXQsXHJcbiAgfTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFB1bGwgYSBwZXItYXV0aG9yIFVzZXJTbmFwc2hvdCBmcm9tIHRoZSB0d2VldCdzIHVzZXJfcmVzdWx0cyBub2RlLiBFdmVyeVxyXG4gKiBmaWVsZCBkZWZhdWx0cyB0byBudWxsIHdoZW4gbWlzc2luZyBzbyB0aGUgc2NoZW1hIHN0YXlzIHN0YWJsZSBhY3Jvc3NcclxuICogdGhlIGxlZ2FjeSAvIGNvcmUgc2hhcGUgbWlncmF0aW9ucyBYIGhhcyBiZWVuIGRvaW5nLlxyXG4gKi9cclxuZnVuY3Rpb24gZXh0cmFjdFVzZXJTbmFwc2hvdChcclxuICB1c2VyUmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXHJcbiAgdXNlckNvcmVOZXc6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcclxuICB1c2VyTGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXHJcbiAgdXNlckF2YXRhck9iajogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsXHJcbik6IFVzZXJTbmFwc2hvdCB7XHJcbiAgY29uc3QgdmVyaWZpY2F0aW9uID0gb2JqKHVzZXJSZXN1bHQ/LnZlcmlmaWNhdGlvbik7XHJcbiAgcmV0dXJuIHtcclxuICAgIGRpc3BsYXlfbmFtZTpcclxuICAgICAgc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5uYW1lKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8ubmFtZSkgPz8gc3RyT3JOdWxsKHVzZXJSZXN1bHQ/Lm5hbWUpLFxyXG4gICAgYXZhdGFyX3VybDpcclxuICAgICAgc3RyT3JOdWxsKHVzZXJBdmF0YXJPYmo/LmltYWdlX3VybCkgPz9cclxuICAgICAgc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzKSA/P1xyXG4gICAgICBzdHJPck51bGwodXNlclJlc3VsdD8ucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMpLFxyXG4gICAgdmVyaWZpZWQ6IGJvb2xPck51bGwodmVyaWZpY2F0aW9uPy52ZXJpZmllZCkgPz8gYm9vbE9yTnVsbCh1c2VyTGVnYWN5Py52ZXJpZmllZCksXHJcbiAgICBpc19ibHVlX3ZlcmlmaWVkOiBib29sT3JOdWxsKHVzZXJSZXN1bHQ/LmlzX2JsdWVfdmVyaWZpZWQpLFxyXG4gICAgdmVyaWZpZWRfdHlwZTogc3RyT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWRfdHlwZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnZlcmlmaWVkX3R5cGUpLFxyXG4gICAgZGVzY3JpcHRpb246IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5kZXNjcmlwdGlvbiksXHJcbiAgICBsb2NhdGlvbjogc3RyT3JOdWxsKG9iaih1c2VyUmVzdWx0Py5sb2NhdGlvbik/LmxvY2F0aW9uKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8ubG9jYXRpb24pLFxyXG4gICAgdXJsOiBzdHJPck51bGwodXNlckxlZ2FjeT8udXJsKSxcclxuICAgIGZvbGxvd2Vyc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZvbGxvd2Vyc19jb3VudCksXHJcbiAgICBmcmllbmRzX2NvdW50OiBudW1Pck51bGwodXNlckxlZ2FjeT8uZnJpZW5kc19jb3VudCksXHJcbiAgICBzdGF0dXNlc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LnN0YXR1c2VzX2NvdW50KSxcclxuICAgIGFjY291bnRfY3JlYXRlZF9hdDpcclxuICAgICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodXNlckNvcmVOZXc/LmNyZWF0ZWRfYXQpKSA/P1xyXG4gICAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5jcmVhdGVkX2F0KSksXHJcbiAgICBwcm90ZWN0ZWQ6IGJvb2xPck51bGwodXNlckxlZ2FjeT8ucHJvdGVjdGVkKSxcclxuICB9O1xyXG59XHJcblxyXG4vKipcclxuICogV2FsayB0aGUgdHdlZXQncyBgY2FyZC5sZWdhY3kuYmluZGluZ192YWx1ZXNgIChrZXkvdmFsdWUgYXJyYXkpIGludG8gYVxyXG4gKiBmbGF0IFR3ZWV0Q2FyZCB3aXRoIHRpdGxlLCBkZXNjcmlwdGlvbiwgYW5kIGEgcmVwcmVzZW50YXRpdmUgaW1hZ2UgVVJMLlxyXG4gKiBSZXR1cm5zIG51bGwgd2hlbiB0aGUgdHdlZXQgaGFzIG5vIGNhcmQuXHJcbiAqL1xyXG5mdW5jdGlvbiBleHRyYWN0Q2FyZCh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFR3ZWV0Q2FyZCB8IG51bGwge1xyXG4gIGNvbnN0IGNhcmQgPSBvYmoodC5jYXJkKTtcclxuICBjb25zdCBjYXJkTGVnYWN5ID0gb2JqKGNhcmQ/LmxlZ2FjeSk7XHJcbiAgaWYgKCFjYXJkTGVnYWN5KSByZXR1cm4gbnVsbDtcclxuICBjb25zdCBiaW5kaW5ncyA9IGNhcmRMZWdhY3kuYmluZGluZ192YWx1ZXM7XHJcbiAgY29uc3QgYnlLZXk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XHJcbiAgaWYgKEFycmF5LmlzQXJyYXkoYmluZGluZ3MpKSB7XHJcbiAgICBmb3IgKGNvbnN0IGJ2IG9mIGJpbmRpbmdzKSB7XHJcbiAgICAgIGlmICh0eXBlb2YgYnYgIT09ICdvYmplY3QnIHx8IGJ2ID09PSBudWxsKSBjb250aW51ZTtcclxuICAgICAgY29uc3QgbyA9IGJ2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gICAgICBjb25zdCBrID0gc3RyT3JOdWxsKG8ua2V5KTtcclxuICAgICAgY29uc3QgdiA9IG9iaihvLnZhbHVlKTtcclxuICAgICAgaWYgKCFrIHx8ICF2KSBjb250aW51ZTtcclxuICAgICAgYnlLZXlba10gPVxyXG4gICAgICAgIHN0ck9yTnVsbCh2LnN0cmluZ192YWx1ZSkgPz9cclxuICAgICAgICBzdHJPck51bGwob2JqKHYuaW1hZ2VfdmFsdWUpPy51cmwpID8/XHJcbiAgICAgICAgc3RyT3JOdWxsKG9iaih2LmltYWdlX2NvbG9yX3ZhbHVlKT8ucGFsZXR0ZSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IG5hbWUgPSBzdHJPck51bGwoY2FyZExlZ2FjeS5uYW1lKTtcclxuICBjb25zdCBjYXJkVXJsID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kudXJsKTtcclxuICBjb25zdCB2ZW5kb3JVcmwgPVxyXG4gICAgdHlwZW9mIGJ5S2V5Wyd2YW5pdHlfdXJsJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5Wyd2YW5pdHlfdXJsJ10gYXMgc3RyaW5nKSA6IG51bGw7XHJcbiAgY29uc3QgdGl0bGUgPSB0eXBlb2YgYnlLZXlbJ3RpdGxlJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5Wyd0aXRsZSddIGFzIHN0cmluZykgOiBudWxsO1xyXG4gIGNvbnN0IGRlc2NyaXB0aW9uID1cclxuICAgIHR5cGVvZiBieUtleVsnZGVzY3JpcHRpb24nXSA9PT0gJ3N0cmluZycgPyAoYnlLZXlbJ2Rlc2NyaXB0aW9uJ10gYXMgc3RyaW5nKSA6IG51bGw7XHJcbiAgY29uc3QgaW1hZ2VVcmwgPVxyXG4gICAgKHR5cGVvZiBieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXHJcbiAgICAgID8gKGJ5S2V5WydwaG90b19pbWFnZV9mdWxsX3NpemVfb3JpZ2luYWwnXSBhcyBzdHJpbmcpXHJcbiAgICAgIDogbnVsbCkgPz9cclxuICAgICh0eXBlb2YgYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xyXG4gICAgICA/IChieUtleVsndGh1bWJuYWlsX2ltYWdlX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxyXG4gICAgICA6IG51bGwpID8/XHJcbiAgICAodHlwZW9mIGJ5S2V5WydzdW1tYXJ5X3Bob3RvX2ltYWdlX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXHJcbiAgICAgID8gKGJ5S2V5WydzdW1tYXJ5X3Bob3RvX2ltYWdlX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxyXG4gICAgICA6IG51bGwpO1xyXG4gIGlmICghbmFtZSAmJiAhdGl0bGUgJiYgIWRlc2NyaXB0aW9uICYmICFpbWFnZVVybCkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIHtcclxuICAgIG5hbWUsXHJcbiAgICBjYXJkX3VybDogY2FyZFVybCxcclxuICAgIHZlbmRvcl91cmw6IHZlbmRvclVybCxcclxuICAgIHRpdGxlLFxyXG4gICAgZGVzY3JpcHRpb24sXHJcbiAgICBpbWFnZV91cmw6IGltYWdlVXJsLFxyXG4gIH07XHJcbn1cclxuIiwgIi8qKlxyXG4gKiBMaWdodHdlaWdodCBVTElELWxpa2UgaWQgZ2VuZXJhdG9yOiAyNi1jaGFyYWN0ZXIgQ3JvY2tmb3JkIGJhc2UzMiBzdHJpbmdcclxuICogb2YgKHRpbWVzdGFtcF9tcyB8fCByYW5kb21uZXNzKS4gR29vZCBlbm91Z2ggZm9yIHJ1biBpZGVudGlmaWVycyB3aXRob3V0XHJcbiAqIHB1bGxpbmcgaW4gYSByZWFsIFVMSUQgZGVwZW5kZW5jeS5cclxuICovXHJcblxyXG5jb25zdCBBTFBIQUJFVCA9ICcwMTIzNDU2Nzg5QUJDREVGR0hKS01OUFFSU1RWV1hZWic7IC8vIENyb2NrZm9yZFxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5ld1J1bklkKCk6IHN0cmluZyB7XHJcbiAgY29uc3QgdHMgPSBEYXRlLm5vdygpO1xyXG4gIGxldCB0c1BhcnQgPSAnJztcclxuICBsZXQgdCA9IHRzO1xyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMTA7IGkrKykge1xyXG4gICAgdHNQYXJ0ID0gKEFMUEhBQkVUW3QgJSAzMl0gPz8gJzAnKSArIHRzUGFydDtcclxuICAgIHQgPSBNYXRoLmZsb29yKHQgLyAzMik7XHJcbiAgfVxyXG4gIGNvbnN0IHJhbmQgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEwKSk7XHJcbiAgbGV0IHJhbmRQYXJ0ID0gJyc7XHJcbiAgZm9yIChjb25zdCBiIG9mIHJhbmQpIHJhbmRQYXJ0ICs9IEFMUEhBQkVUW2IgJSAzMl0gPz8gJzAnO1xyXG4gIHJldHVybiB0c1BhcnQgKyByYW5kUGFydDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNob3J0UnVuSWQoaWQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGlkLnNsaWNlKC04KTtcclxufVxyXG4iLCAiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q2F0ZWdvcnksIEFjY291bnRDb25maWcgfSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbi8qKlxyXG4gKiBNaW5pbWFsIHBhcnNlciBmb3IgdGhlIHN0cmljdCBzaGFwZSB1c2VkIGJ5IGBjb25maWcvYWNjb3VudHMueWFtbGA6XHJcbiAqXHJcbiAqICAgYWNjb3VudHM6XHJcbiAqICAgICAtIGhhbmRsZTogREhTZ292XHJcbiAqICAgICAgIGxhYmVsOiBEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5XHJcbiAqICAgICAgIGNhdGVnb3J5OiBjb3JlXHJcbiAqXHJcbiAqIFdlIGRlbGliZXJhdGVseSBkb24ndCBwdWxsIGluIGEgZnVsbCBZQU1MIGxpYnJhcnkgXHUyMDE0IHdlIGNvbnRyb2wgYm90aCBlbmRzIG9mXHJcbiAqIHRoaXMgZmlsZSwgYW5kIGEgc21hbGwgcGFyc2VyIGlzIGVhc2llciB0byBhdWRpdCB0aGFuIHRoZSBhbHRlcm5hdGl2ZXMuXHJcbiAqIFVua25vd24ga2V5cyBhbmQgY29tbWVudHMgYXJlIHRvbGVyYXRlZDsgbWFsZm9ybWVkIGxpbmVzIGFyZSBza2lwcGVkLlxyXG4gKlxyXG4gKiBFbnRyaWVzIG1pc3NpbmcgYSBgY2F0ZWdvcnlgIGRlZmF1bHQgdG8gYGNvcmVgIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XHJcbiAqIHdpdGggdGhlIHByZS1jYXRlZ29yaXphdGlvbiBmaWxlIHNoYXBlLlxyXG4gKi9cclxuY29uc3QgVkFMSURfQ0FURUdPUklFUzogUmVhZG9ubHlTZXQ8QWNjb3VudENhdGVnb3J5PiA9IG5ldyBTZXQoW1xyXG4gICdjb3JlJyxcclxuICAnZ292ZXJubWVudCcsXHJcbiAgJ29mZmljaWFscycsXHJcbiAgJ3B1YmxpY19maWd1cmVzJyxcclxuICAncHVibGljJyxcclxuXSk7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VBY2NvdW50c1lhbWwodGV4dDogc3RyaW5nKTogQWNjb3VudENvbmZpZ1tdIHtcclxuICBjb25zdCBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdID0gW107XHJcbiAgbGV0IGN1cnJlbnQ6IFBhcnRpYWw8QWNjb3VudENvbmZpZz4gPSB7fTtcclxuICBsZXQgaW5BY2NvdW50cyA9IGZhbHNlO1xyXG4gIGNvbnN0IGZsdXNoID0gKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnQuaGFuZGxlICYmIGN1cnJlbnQubGFiZWwpIHtcclxuICAgICAgaWYgKCFjdXJyZW50LmNhdGVnb3J5KSBjdXJyZW50LmNhdGVnb3J5ID0gJ2NvcmUnO1xyXG4gICAgICBhY2NvdW50cy5wdXNoKGN1cnJlbnQgYXMgQWNjb3VudENvbmZpZyk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBmb3IgKGNvbnN0IHJhd0xpbmUgb2YgdGV4dC5zcGxpdCgnXFxuJykpIHtcclxuICAgIGNvbnN0IGxpbmUgPSBzdHJpcENvbW1lbnRzKHJhd0xpbmUpO1xyXG4gICAgaWYgKGxpbmUudHJpbSgpID09PSAnJykgY29udGludWU7XHJcbiAgICBpZiAoL15hY2NvdW50c1xccyo6Ly50ZXN0KGxpbmUpKSB7XHJcbiAgICAgIGluQWNjb3VudHMgPSB0cnVlO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmICghaW5BY2NvdW50cykgY29udGludWU7XHJcblxyXG4gICAgY29uc3QgaXRlbU1hdGNoID0gbGluZS5tYXRjaCgvXlxccyotXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XHJcbiAgICBpZiAoaXRlbU1hdGNoKSB7XHJcbiAgICAgIGZsdXNoKCk7XHJcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShpdGVtTWF0Y2hbMV0gPz8gJycpIH07XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgY29uc3QgaGFuZGxlT25seSA9IGxpbmUubWF0Y2goL15cXHMqaGFuZGxlXFxzKjpcXHMqKC4rKSQvKTtcclxuICAgIGlmIChoYW5kbGVPbmx5ICYmICFsaW5lLmluY2x1ZGVzKCctJykpIHtcclxuICAgICAgZmx1c2goKTtcclxuICAgICAgY3VycmVudCA9IHsgaGFuZGxlOiB1bnF1b3RlKGhhbmRsZU9ubHlbMV0gPz8gJycpIH07XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgY29uc3QgbGFiZWxNYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqbGFiZWxcXHMqOlxccyooLispJC8pO1xyXG4gICAgaWYgKGxhYmVsTWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcclxuICAgICAgY3VycmVudC5sYWJlbCA9IHVucXVvdGUobGFiZWxNYXRjaFsxXSA/PyAnJyk7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgY29uc3QgY2F0ZWdvcnlNYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqY2F0ZWdvcnlcXHMqOlxccyooLispJC8pO1xyXG4gICAgaWYgKGNhdGVnb3J5TWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcclxuICAgICAgY29uc3QgcmF3ID0gdW5xdW90ZShjYXRlZ29yeU1hdGNoWzFdID8/ICcnKTtcclxuICAgICAgY3VycmVudC5jYXRlZ29yeSA9IFZBTElEX0NBVEVHT1JJRVMuaGFzKHJhdyBhcyBBY2NvdW50Q2F0ZWdvcnkpXHJcbiAgICAgICAgPyAocmF3IGFzIEFjY291bnRDYXRlZ29yeSlcclxuICAgICAgICA6ICdjb3JlJztcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGZsdXNoKCk7XHJcbiAgcmV0dXJuIGFjY291bnRzLmZpbHRlcigoYSkgPT4gYS5oYW5kbGUubGVuZ3RoID4gMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHN0cmlwQ29tbWVudHMobGluZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAvLyBOYWl2ZSBidXQgYWRlcXVhdGUgZm9yIG91ciBmb3JtYXQ6IHN0cmlwIGV2ZXJ5dGhpbmcgYWZ0ZXIgYSBgI2AgdGhhdCBpc24ndFxyXG4gIC8vIGluc2lkZSBxdW90ZXMuIE91ciBjb25maWcgbmV2ZXIgdXNlcyBpbmxpbmUgc3RyaW5ncyB3aXRoIGAjYC5cclxuICBjb25zdCBpZHggPSBsaW5lLmluZGV4T2YoJyMnKTtcclxuICByZXR1cm4gaWR4ID09PSAtMSA/IGxpbmUgOiBsaW5lLnNsaWNlKDAsIGlkeCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHVucXVvdGUoczogc3RyaW5nKTogc3RyaW5nIHtcclxuICBjb25zdCB0cmltbWVkID0gcy50cmltKCk7XHJcbiAgaWYgKFxyXG4gICAgKHRyaW1tZWQuc3RhcnRzV2l0aCgnXCInKSAmJiB0cmltbWVkLmVuZHNXaXRoKCdcIicpKSB8fFxyXG4gICAgKHRyaW1tZWQuc3RhcnRzV2l0aChcIidcIikgJiYgdHJpbW1lZC5lbmRzV2l0aChcIidcIikpXHJcbiAgKSB7XHJcbiAgICByZXR1cm4gdHJpbW1lZC5zbGljZSgxLCAtMSk7XHJcbiAgfVxyXG4gIHJldHVybiB0cmltbWVkO1xyXG59XHJcbiIsICIvKipcbiAqIGJhY2tncm91bmQudHMgXHUyMDE0IGV4dGVuc2lvbiBzZXJ2aWNlIHdvcmtlci5cbiAqXG4gKiBPd25zIHRoZSBjYXB0dXJlIHBpcGVsaW5lOiByZWNlaXZlcyBgZ3JhcGhxbC1jYXB0dXJlYCBtZXNzYWdlcyBmcm9tIHRoZVxuICogY29udGVudCBzY3JpcHQsIG5vcm1hbGl6ZXMgdGhlbSwgYWNjdW11bGF0ZXMgcGVyLWhhbmRsZSBydW4gYnVmZmVycyBpblxuICogYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAsIGFuZCBjb21taXRzIHRoZW0gdG8gdGhlIGNvbmZpZ3VyZWQgR2l0SHViIHJlcG9cbiAqIHZpYSB0aGUgQ29udGVudHMgQVBJLlxuICpcbiAqIFNlcnZpY2Ugd29ya2VycyBpbiBNVjMgbWF5IGJlIGV2aWN0ZWQgYXQgYW55IHRpbWUsIHNvIGFsbCBjcml0aWNhbCBzdGF0ZVxuICogbGl2ZXMgaW4gc3RvcmFnZSAobmV2ZXIgbW9kdWxlLXNjb3BlKS4gT24gZXZlcnkgd2FrZSB3ZSByZS1kZXJpdmUgd2hhdCB3ZVxuICogbmVlZDsgcGVuZGluZyBmbHVzaGVzIGFyZSBkcml2ZW4gYnkgYGJyb3dzZXIuYWxhcm1zYCByYXRoZXIgdGhhbiB0aW1lcnMuXG4gKi9cblxuaW1wb3J0IHtcbiAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgQVVUT19TQ1JPTExfTUlOX1NFQyxcbiAgRkFMTEJBQ0tfQUNDT1VOVFMsXG4gIEZMVVNIX0FMQVJNX01JTlVURVMsXG4gIEZMVVNIX0lETEVfTVMsXG4gIEZMVVNIX1RXRUVUX1RIUkVTSE9MRCxcbiAgUFJPRklMRV9FTkRQT0lOVFMsXG4gIFRXRUVUX0VORFBPSU5UUyxcbiAgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMsXG59IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XG5pbXBvcnQgeyBHaXRIdWJDbGllbnQsIEdpdEh1YkVycm9yLCB0b0Jhc2U2NCB9IGZyb20gJy4vbGliL2dpdGh1Yi5qcyc7XG5pbXBvcnQgeyBkZXNjcmliZUVycm9yLCBlcnJvciBhcyBsb2dFcnIsIGluZm8sIHNldEJyb2FkY2FzdGVyLCB3YXJuIH0gZnJvbSAnLi9saWIvbG9nZ2VyLmpzJztcbmltcG9ydCB7IGZpbHRlclJlbGF0ZWQsIG5vcm1hbGl6ZSB9IGZyb20gJy4vbGliL25vcm1hbGl6ZS5qcyc7XG5pbXBvcnQgeyBuZXdSdW5JZCwgc2hvcnRSdW5JZCB9IGZyb20gJy4vbGliL3J1bmlkcy5qcyc7XG5pbXBvcnQge1xuICBidW1wQ291bnRlcixcbiAgY2xlYXJBY3Rpdml0eSxcbiAgY2xlYXJBbGwsXG4gIGNsZWFyUnVuQnVmZmVyLFxuICBkZXF1ZXVlTWVkaWFDcmF3bCxcbiAgZGVxdWV1ZVJlZmV0Y2gsXG4gIGVuZ2FnZW1lbnRTaWcsXG4gIGVucXVldWVNZWRpYUNyYXdsLFxuICBlbnF1ZXVlUmVmZXRjaCxcbiAgZ2V0QWNjb3VudHMsXG4gIGdldEFjY291bnRzUmVmcmVzaGVkQXQsXG4gIGdldEFjdGl2aXR5LFxuICBnZXRBdXRvU2Nyb2xsU2Vzc2lvbixcbiAgZ2V0Q29tbWl0dGVkSW5kZXgsXG4gIGdldENvbm5lY3Rpb24sXG4gIGdldENvdW50ZXJzLFxuICBnZXRNZWRpYUNyYXdsUXVldWUsXG4gIGdldE1lZGlhQ3Jhd2xTZXNzaW9uLFxuICBnZXRSZWZldGNoUXVldWUsXG4gIGdldFJlZmV0Y2hTZXNzaW9uLFxuICBnZXRSdW5CdWZmZXIsXG4gIGdldFJ1bkJ1ZmZlcnMsXG4gIGdldFNldHRpbmdzLFxuICBpc0NvbW1pdHRlZCxcbiAgbWVkaWFDcmF3bFF1ZXVlVG90YWwsXG4gIG5leHRNZWRpYUNyYXdsVGFyZ2V0LFxuICBuZXh0UmVmZXRjaFRhcmdldCxcbiAgcHJ1bmVDb21taXR0ZWRJbmRleCxcbiAgcHVyZ2VVbnJlbGF0ZWRTdGF0ZSxcbiAgcmVmZXRjaFF1ZXVlVG90YWwsXG4gIHNldEFjY291bnRzLFxuICBzZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxuICBzZXRBdXRvU2Nyb2xsU2Vzc2lvbixcbiAgc2V0QnVmZmVyZWRDb3VudCxcbiAgc2V0Q29tbWl0dGVkSW5kZXgsXG4gIHNldENvbm5lY3Rpb24sXG4gIHNldE1lZGlhQ3Jhd2xTZXNzaW9uLFxuICBzZXRSZWZldGNoU2Vzc2lvbixcbiAgc2V0UnVuQnVmZmVyLFxuICB0eXBlIFJ1bkJ1ZmZlcixcbiAgdXBkYXRlU2V0dGluZ3MsXG59IGZyb20gJy4vbGliL3N0b3JhZ2UuanMnO1xuaW1wb3J0IHR5cGUge1xuICBDYW5vbmljYWxUd2VldCxcbiAgQ2FwdHVyZVBheWxvYWQsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgRXh0ZW5zaW9uU3RhdGUsXG4gIExvZ0V2ZW50LFxuICBRdWFyYW50aW5lUGF5bG9hZCxcbiAgUnVudGltZU1lc3NhZ2UsXG4gIFNlZW5QYXlsb2FkLFxuICBTZXR0aW5ncyxcbn0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xuaW1wb3J0IHsgcGFyc2VBY2NvdW50c1lhbWwgfSBmcm9tICcuL2xpYi95YW1sLmpzJztcblxuY29uc3QgRVhUX1ZFUlNJT04gPSBicm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uO1xuXG5zZXRCcm9hZGNhc3RlcigoZXY6IExvZ0V2ZW50KSA9PiB7XG4gIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdsb2ctZXZlbnQnLCBldmVudDogZXYgfSkuY2F0Y2goKCkgPT4ge30pO1xufSk7XG5cbi8vIC0tLSBXYWtlIGhhbmRsZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmJyb3dzZXIucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XG4gIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBpbnN0YWxsZWQnLCB7IHZlcnNpb246IEVYVF9WRVJTSU9OIH0pO1xuICBhd2FpdCBvbldha2UoJ2luc3RhbGwnKTtcbn0pO1xuXG5icm93c2VyLnJ1bnRpbWUub25TdGFydHVwLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgdm9pZCBvbldha2UoJ3N0YXJ0dXAnKTtcbn0pO1xuXG4vLyBGb3JjZSBhdCBsZWFzdCBvbmUgd2FrZSB0byByZWdpc3RlciBhbGFybXMgLyB2ZXJpZnkgY29ubmVjdGlvbi5cbnZvaWQgb25XYWtlKCdtb2R1bGUtbG9hZCcpO1xuXG5hc3luYyBmdW5jdGlvbiBvbldha2UocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBlbnN1cmVBbGFybXMoKTtcbiAgICBhd2FpdCBlbnN1cmVBdXRvU2Nyb2xsQWxhcm0oKTtcbiAgICBhd2FpdCBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTtcbiAgICBhd2FpdCByZWluamVjdEludG9PcGVuVGFicygpO1xuICAgIC8vIERyb3AgZGVkdXAtaW5kZXggZW50cmllcyBvbGRlciB0aGFuIDMwIGRheXMgc28gdGhlIHN0b3JlIGRvZXNuJ3RcbiAgICAvLyBncm93IHVuYm91bmRlZCBvdmVyIG1vbnRocyBvZiBjYXB0dXJlIHNlc3Npb25zLlxuICAgIGNvbnN0IHBydW5lZCA9IGF3YWl0IHBydW5lQ29tbWl0dGVkSW5kZXgoMzAgKiAyNCAqIDYwICogNjAgKiAxMDAwKTtcbiAgICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgaW5mbygncHJ1bmVkIGNvbW1pdHRlZCBpbmRleCcsIHsgcHJ1bmVkIH0pO1xuICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgICBpZiAoc2V0dGluZ3MucGF0ICYmIHNldHRpbmdzLm93bmVyICYmIHNldHRpbmdzLnJlcG8pIHtcbiAgICAgIGF3YWl0IHZlcmlmeUNvbm5lY3Rpb24oZmFsc2UpO1xuICAgICAgYXdhaXQgcmVmcmVzaEFjY291bnRzTGlzdChmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXM6ICdub3QtY29uZmlndXJlZCcsXG4gICAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBhd2FrZTsgc2V0dGluZ3MgaW5jb21wbGV0ZScsIHsgcmVhc29uIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgbG9nRXJyKCd3YWtlIGZhaWxlZCcsIHsgcmVhc29uLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIH1cbn1cblxuLyoqXG4gKiBSZS1pbmplY3QgdGhlIE1BSU4td29ybGQgcGFnZS1ob29rICsgaXNvbGF0ZWQtd29ybGQgY29udGVudCBzY3JpcHQgaW50b1xuICogZXZlcnkgYWxyZWFkeS1vcGVuIHguY29tIC8gdHdpdHRlci5jb20gdGFiLlxuICpcbiAqIE1hbmlmZXN0IGNvbnRlbnRfc2NyaXB0cyBvbmx5IGluamVjdCBvbiBmcmVzaCBuYXZpZ2F0aW9uIChydW5fYXQ6XG4gKiBkb2N1bWVudF9zdGFydCkuIFdoZW4gdGhlIHVzZXIgcmVsb2FkcyB0aGUgZXh0ZW5zaW9uIHdoaWxlIFggdGFicyBhcmVcbiAqIG9wZW4sIHRob3NlIHRhYnMga2VlcCB0aGVpciBjb250ZW50IHNjcmlwdHMgYnV0IG5ldmVyIGdldCBhIG5ldyBwYWdlLWhvb2tcbiAqIFx1MjAxNCBzbyBmZXRjaC9YSFIgc3RheXMgdW5wYXRjaGVkIGFuZCBjYXB0dXJlcyBzaWxlbnRseSBmYWlsLiBEb2luZyB0aGlzIG9uXG4gKiBldmVyeSB3YWtlIGlzIGlkZW1wb3RlbnQgKHBhZ2UtaG9vayBoYXMgYSBUQUcgZ3VhcmQpIGFuZCBjaGVhcC5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gcmVpbmplY3RJbnRvT3BlblRhYnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XG4gIHRyeSB7XG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NvdWxkIG5vdCBxdWVyeSBvcGVuIHRhYnMnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodGFicy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgZm9yIChjb25zdCB0YWIgb2YgdGFicykge1xuICAgIGlmICh0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJykgY29udGludWU7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICBmaWxlczogWydwYWdlLWhvb2suanMnXSxcbiAgICAgICAgLy8gRmlyZWZveCAxMjgrIHN1cHBvcnRzIHRoZSBNQUlOIGV4ZWN1dGlvbiB3b3JsZCB2aWEgdGhpcyBBUEksIGJ1dFxuICAgICAgICAvLyB0aGUgQHR5cGVzL2ZpcmVmb3gtd2ViZXh0LWJyb3dzZXIgcGFja2FnZSB3ZSdyZSBvbiBzdGlsbCBvbmx5XG4gICAgICAgIC8vIGRlY2xhcmVzICdJU09MQVRFRCcuIENhc3QgdGhyb3VnaCB0aGUgbGl0ZXJhbCB1bmlvbi5cbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgZmlsZXM6IFsnY29udGVudC5qcyddLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBpbmZvKCdyZS1pbmplY3RlZCBzY3JpcHRzIGludG8gb3BlbiB0YWInLCB7XG4gICAgICAgIHRhYklkOiB0YWIuaWQsXG4gICAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsID8/ICcnKSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgLy8gU29tZSB0YWJzIChhYm91dDogcGFnZXMsIGRpc2NhcmRlZCB0YWJzLCBtaWQtbmF2aWdhdGlvbikgcmVqZWN0XG4gICAgICAvLyBleGVjdXRlU2NyaXB0LiBUaGF0J3MgZmluZSBcdTIwMTQgd2UnbGwgY2F0Y2ggdGhlbSBvbiB0aGUgbmV4dCB3YWtlIG9yXG4gICAgICAvLyB3aGVuIHRoZSB1c2VyIG5hdmlnYXRlcy5cbiAgICAgIGF3YWl0IHdhcm4oJ3JlLWluamVjdCBmYWlsZWQgZm9yIHRhYjsgY29udGludWluZycsIHtcbiAgICAgICAgdGFiSWQ6IHRhYi5pZCxcbiAgICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwgPz8gJycpLFxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQWxhcm1zKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignZmx1c2gtc3dlZXAnKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3ZlcmlmeS1jb25uZWN0aW9uJyk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgnZmx1c2gtc3dlZXAnLCB7IHBlcmlvZEluTWludXRlczogRkxVU0hfQUxBUk1fTUlOVVRFUyB9KTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY3JlYXRlKCd2ZXJpZnktY29ubmVjdGlvbicsIHtcbiAgICBwZXJpb2RJbk1pbnV0ZXM6IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TIC8gNjBfMDAwLFxuICB9KTtcbn1cblxuLy8gRmlyZWZveCBNVjMgYWxhcm1zIGhhdmUgYSAzMHMgbWluaW11bSBwZXJpb2QsIGJ1dCB3ZSB3YW50IHN1Yi1taW51dGVcbi8vIHNjcm9sbGluZy4gVGhlIGF1dG8tc2Nyb2xsIGxvb3AgdGhlcmVmb3JlIHJ1bnMgb24gYW4gaW4tU1cgaW50ZXJ2YWwuXG4vLyBgYXV0b1Njcm9sbFNlc3Npb25gIGluIHN0b3JhZ2UgaXMgdGhlIHNvdXJjZSBvZiB0cnV0aCBmb3Igd2hldGhlciB0aGUgbG9vcFxuLy8gaXMgbWVhbnQgdG8gYmUgcnVubmluZyBcdTIwMTQgdGhlIHRpbWVyIGlzIGp1c3QgdGhlIGxvY2FsIGV4ZWN1dGlvbiBhcm0uXG5sZXQgYXV0b1Njcm9sbFRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcblxuLy8gV2FpdC1mb3ItaW5nZXN0IHRpbWVvdXQ6IGlmIGEgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHRhYiBuYXZpZ2F0aW9uIGRvZXNuJ3Rcbi8vIHByb2R1Y2UgYW4gaW5nZXN0ZWQgY2FwdHVyZSB3aXRoaW4gdGhpcyBtYW55IG1zLCBhZHZhbmNlIGFueXdheSBzbyB3ZVxuLy8gZG9uJ3QgZGVhZGxvY2sgb24gZGVsZXRlZCAvIDQwNCAvIHBheXdhbGxlZCB0d2VldHMuXG5jb25zdCBJTkdFU1RfV0FJVF9NUyA9IDI1XzAwMDtcblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQXV0b1Njcm9sbEFsYXJtKCk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBXYXMgdGhlIGxvb3AgcnVubmluZyBiZWZvcmUgdGhlIFNXIGV2aWN0aW9uPyBSZS1hcm0gaWYgc28uXG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKHNlc3MgIT09IG51bGwgJiYgcy5lbmFibGVkICE9PSBmYWxzZSkge1xuICAgIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XG4gIH0gZWxzZSB7XG4gICAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBjbGVhckF1dG9TY3JvbGxUaW1lcigpOiB2b2lkIHtcbiAgaWYgKGF1dG9TY3JvbGxUaW1lciAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwoYXV0b1Njcm9sbFRpbWVyKTtcbiAgICBhdXRvU2Nyb2xsVGltZXIgPSBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIGFybUF1dG9TY3JvbGxUaW1lcihpbnRlcnZhbFNlYzogbnVtYmVyKTogdm9pZCB7XG4gIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gIGNvbnN0IGNsYW1wZWQgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQoaW50ZXJ2YWxTZWMpKVxuICApO1xuICBhdXRvU2Nyb2xsVGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgdm9pZCBhdXRvU2Nyb2xsVGljaygpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybignYXV0by1zY3JvbGwgdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIH0pO1xuICB9LCBjbGFtcGVkICogMTAwMCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0QXV0b1Njcm9sbExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbih7XG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgc2Nyb2xsQ291bnQ6IDAsXG4gICAgaW5nZXN0ZWRDb3VudDogMCxcbiAgICBleHBhbmRlZENvdW50OiAwLFxuICB9KTtcbiAgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBzdGFydGVkJywgeyBpbnRlcnZhbF9zZWM6IHMuYXV0b1Njcm9sbEludGVydmFsU2VjIH0pO1xuICAvLyBGaXJlIG9uZSBpbW1lZGlhdGUgdGljayBzbyB0aGUgdXNlciBzZWVzIG1vdGlvbiByaWdodCBhd2F5LlxuICB2b2lkIGF1dG9TY3JvbGxUaWNrKCk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbEF1dG9TY3JvbGxMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24obnVsbCk7XG4gIGF3YWl0IGluZm8oJ2F1dG8tc2Nyb2xsIGxvb3AgY2FuY2VsbGVkJywge1xuICAgIHNjcm9sbHM6IHNlc3M/LnNjcm9sbENvdW50ID8/IDAsXG4gICAgaW5nZXN0ZWQ6IHNlc3M/LmluZ2VzdGVkQ291bnQgPz8gMCxcbiAgICBleHBhbmRlZDogc2Vzcz8uZXhwYW5kZWRDb3VudCA/PyAwLFxuICB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYXV0b1Njcm9sbFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XG4gIHRyeSB7XG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2F1dG8tc2Nyb2xsOiB0YWIgcXVlcnkgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHRhYnMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGxldCBzY3JvbGxDb3VudCA9IDA7XG4gIGxldCBleHBhbmRlZENvdW50ID0gMDtcbiAgZm9yIChjb25zdCB0YWIgb2YgdGFicykge1xuICAgIGlmICh0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJykgY29udGludWU7XG4gICAgaWYgKHRhYi5kaXNjYXJkZWQpIGNvbnRpbnVlO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHRzID0gKGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXG4gICAgICAgIC8vIENhc3Q6IHRoZSBAdHlwZXMvZmlyZWZveC13ZWJleHQtYnJvd3NlciB0eXBlIHNpZ25hdHVyZSBpbnNpc3RzXG4gICAgICAgIC8vIGBmdW5jYCByZXR1cm5zIHZvaWQsIGJ1dCB0aGUgQVBJIGFjdHVhbGx5IHN1cmZhY2VzIHRoZSByZXR1cm5cbiAgICAgICAgLy8gdmFsdWUgdmlhIGByZXN1bHRbMF0ucmVzdWx0YC4gV2UgdXNlIHRoYXQgZm9yIHRoZSBleHBhbmQgY291bnQuXG4gICAgICAgIGZ1bmM6ICgoKSA9PiB7XG4gICAgICAgICAgLy8gMS4gQ2xpY2sgYW55IHZpc2libGUgXCJTaG93IG1vcmVcIiBsaW5rcyBpbiBsb25nLXR3ZWV0IGJvZGllcyBzbyBYXG4gICAgICAgICAgLy8gICAgaW5saW5lcyB0aGUgbm90ZV90d2VldCBib2R5IGFuZCBvdXIgcGFnZS1ob29rIGNhcHR1cmVzIHRoZVxuICAgICAgICAgIC8vICAgIGZ1bGwgdGV4dCB3aXRob3V0IHRoZSByZWZldGNoIGRldG91ci4gVHJ5IHNldmVyYWwgc2VsZWN0b3JzXG4gICAgICAgICAgLy8gICAgYmVjYXVzZSBYIHJvdGF0ZXMgdGhlIHRlc3RpZCBsYWJlbCBzZW1pLXJlZ3VsYXJseS5cbiAgICAgICAgICBjb25zdCBTSE9XX01PUkVfU0VMRUNUT1JTID0gW1xuICAgICAgICAgICAgJ1tkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxuICAgICAgICAgICAgJ2J1dHRvbltkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxuICAgICAgICAgICAgJ2RpdltkYXRhLXRlc3RpZD1cImNlbGxJbm5lckRpdlwiXSBbcm9sZT1cImJ1dHRvblwiXVt0YWJpbmRleD1cIjBcIl0nLFxuICAgICAgICAgIF07XG4gICAgICAgICAgY29uc3QgY2xpY2tlZCA9IG5ldyBTZXQ8RWxlbWVudD4oKTtcbiAgICAgICAgICBsZXQgZXhwYW5kZWQgPSAwO1xuICAgICAgICAgIGZvciAoY29uc3Qgc2VsIG9mIFNIT1dfTU9SRV9TRUxFQ1RPUlMpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgZWwgb2YgQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbCkpKSB7XG4gICAgICAgICAgICAgIGlmIChjbGlja2VkLmhhcyhlbCkpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAvLyBDb25maXJtIGl0J3MgYWN0dWFsbHkgdGhlIHNob3ctbW9yZSBhZmZvcmRhbmNlIGJ5IHRleHQuXG4gICAgICAgICAgICAgIGNvbnN0IHQgPSAoZWwudGV4dENvbnRlbnQgfHwgJycpLnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgICBpZiAodCAhPT0gJ3Nob3cgbW9yZScgJiYgdCAhPT0gJ3Nob3cgdGhpcyB0aHJlYWQnKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgY29uc3QgcmVjdCA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICAgICAgICBpZiAocmVjdC53aWR0aCA9PT0gMCB8fCByZWN0LmhlaWdodCA9PT0gMCkgY29udGludWU7XG4gICAgICAgICAgICAgIGNsaWNrZWQuYWRkKGVsKTtcbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAoZWwgYXMgSFRNTEVsZW1lbnQpLmNsaWNrKCk7XG4gICAgICAgICAgICAgICAgZXhwYW5kZWQgKz0gMTtcbiAgICAgICAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgICAgICAgLy8gaWdub3JlXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgLy8gMi4gU2Nyb2xsIHRoZSBwYWdlLiBEaXNwYXRjaCBFbmQga2V5IGZpcnN0IHNpbmNlIG1hbnkgWCBzdXJmYWNlc1xuICAgICAgICAgIC8vICAgIChsaXN0cywgc2VhcmNoLCByZXBsaWVzKSBiaW5kIHBhZ2luYXRpb24gdHJpZ2dlcnMgdG8gaXQgdmlhXG4gICAgICAgICAgLy8gICAgUmVhY3QgaGFuZGxlcnM7IHRoZW4gZXhwbGljaXRseSBzY3JvbGwgdGhlIGRvY3VtZW50LlxuICAgICAgICAgIGNvbnN0IG9wdHM6IEtleWJvYXJkRXZlbnRJbml0ID0ge1xuICAgICAgICAgICAga2V5OiAnRW5kJyxcbiAgICAgICAgICAgIGNvZGU6ICdFbmQnLFxuICAgICAgICAgICAga2V5Q29kZTogMzUsXG4gICAgICAgICAgICB3aGljaDogMzUsXG4gICAgICAgICAgICBidWJibGVzOiB0cnVlLFxuICAgICAgICAgICAgY2FuY2VsYWJsZTogdHJ1ZSxcbiAgICAgICAgICB9O1xuICAgICAgICAgIGNvbnN0IGZvY3VzID0gKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgYXMgSFRNTEVsZW1lbnQgfCBudWxsKSA/PyBkb2N1bWVudC5ib2R5O1xuICAgICAgICAgIGZvY3VzLmRpc3BhdGNoRXZlbnQobmV3IEtleWJvYXJkRXZlbnQoJ2tleWRvd24nLCBvcHRzKSk7XG4gICAgICAgICAgZm9jdXMuZGlzcGF0Y2hFdmVudChuZXcgS2V5Ym9hcmRFdmVudCgna2V5dXAnLCBvcHRzKSk7XG4gICAgICAgICAgd2luZG93LnNjcm9sbFRvKHtcbiAgICAgICAgICAgIHRvcDogZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNjcm9sbEhlaWdodCxcbiAgICAgICAgICAgIGJlaGF2aW9yOiAnYXV0bycsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIHsgZXhwYW5kZWQgfTtcbiAgICAgICAgfSkgYXMgKCkgPT4gdm9pZCxcbiAgICAgIH0pKSBhcyBBcnJheTx7IHJlc3VsdD86IHVua25vd24gfT47XG4gICAgICBzY3JvbGxDb3VudCArPSAxO1xuICAgICAgY29uc3QgciA9IHJlc3VsdHNbMF0/LnJlc3VsdCBhcyB7IGV4cGFuZGVkPzogbnVtYmVyIH0gfCB1bmRlZmluZWQ7XG4gICAgICBpZiAociAmJiB0eXBlb2Ygci5leHBhbmRlZCA9PT0gJ251bWJlcicpIGV4cGFuZGVkQ291bnQgKz0gci5leHBhbmRlZDtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIFRhYnMgdGhhdCBkaXNhbGxvdyBzY3JpcHRpbmcgKGFib3V0OiwgZGlzY2FyZGVkLCBtaWQtbmF2aWdhdGlvbilcbiAgICAgIC8vIGp1c3QgZ2V0IHNraXBwZWQgXHUyMDE0IHRoZXknbGwgYmUgZWxpZ2libGUgb24gYSBsYXRlciB0aWNrLlxuICAgIH1cbiAgfVxuICBpZiAoc2Nyb2xsQ291bnQgPiAwKSB7XG4gICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgaWYgKHNlc3MgIT09IG51bGwpIHtcbiAgICAgIHNlc3Muc2Nyb2xsQ291bnQgKz0gc2Nyb2xsQ291bnQ7XG4gICAgICBzZXNzLmV4cGFuZGVkQ291bnQgKz0gZXhwYW5kZWRDb3VudDtcbiAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKHNlc3MpO1xuICAgICAgLy8gTm8gYnJvYWRjYXN0IG9uIGV2ZXJ5IHRpY2sgXHUyMDE0IHRoZSAxNXMgc2lkZWJhciByZWZyZXNoIHBpY2tzIGl0IHVwLlxuICAgIH1cbiAgfVxufVxuXG5icm93c2VyLmFsYXJtcy5vbkFsYXJtLmFkZExpc3RlbmVyKChhbGFybSkgPT4ge1xuICBpZiAoYWxhcm0ubmFtZSA9PT0gJ2ZsdXNoLXN3ZWVwJykge1xuICAgIHZvaWQgZmx1c2hJZGxlQnVmZmVycygpO1xuICB9IGVsc2UgaWYgKGFsYXJtLm5hbWUgPT09ICd2ZXJpZnktY29ubmVjdGlvbicpIHtcbiAgICB2b2lkIHZlcmlmeUNvbm5lY3Rpb24oZmFsc2UpO1xuICB9XG4gIC8vIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBwcmV2aW91c2x5IHJhbiB2aWEgYWxhcm1zOyB0aGV5IG5vdyB1c2VcbiAgLy8gc2V0SW50ZXJ2YWwgdG8gZXNjYXBlIHRoZSAzMHMgYWxhcm0gZmxvb3IuIExlYXZlIHRoZSBuYW1lcyBsaXN0ZWRcbiAgLy8gbm93aGVyZSBzbyBhbnkgb3JwaGFuZWQgYWxhcm1zIChmcm9tIG9sZGVyIGJ1aWxkcykganVzdCBuby1vcC5cbn0pO1xuXG4vLyAtLS0gVG9vbGJhciBhY3Rpb246IHRvZ2dsZSB0aGUgc2lkZWJhciAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5pZiAoYnJvd3Nlci5hY3Rpb24/Lm9uQ2xpY2tlZCkge1xuICBicm93c2VyLmFjdGlvbi5vbkNsaWNrZWQuYWRkTGlzdGVuZXIoYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnNpZGViYXJBY3Rpb24udG9nZ2xlKCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAvLyBGYWxsYmFjazogb3BlbiBvcHRpb25zIGlmIHNpZGViYXIgY2FuJ3QgYmUgdG9nZ2xlZC5cbiAgICAgIGF3YWl0IHdhcm4oJ3NpZGViYXIgdG9nZ2xlIGZhaWxlZDsgb3BlbmluZyBvcHRpb25zJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICAgIGF3YWl0IGJyb3dzZXIucnVudGltZS5vcGVuT3B0aW9uc1BhZ2UoKTtcbiAgICB9XG4gIH0pO1xufVxuXG4vLyAtLS0gUnVudGltZSBtZXNzYWdlIGRpc3BhdGNoIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93biwgX3NlbmRlcikgPT4ge1xuICBpZiAoIWlzUnVudGltZU1lc3NhZ2UobXNnKSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgcmV0dXJuIGhhbmRsZU1lc3NhZ2UobXNnKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgdm9pZCBsb2dFcnIoJ21lc3NhZ2UgaGFuZGxlciBmYWlsZWQnLCB7IHR5cGU6IG1zZy50eXBlLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gICAgdGhyb3cgZXJyO1xuICB9KTtcbn0pO1xuXG5mdW5jdGlvbiBpc1J1bnRpbWVNZXNzYWdlKG06IHVua25vd24pOiBtIGlzIFJ1bnRpbWVNZXNzYWdlIHtcbiAgcmV0dXJuICEhbSAmJiB0eXBlb2YgbSA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIChtIGFzIHsgdHlwZT86IHVua25vd24gfSkudHlwZSA9PT0gJ3N0cmluZyc7XG59XG5cbi8qKiBNZXNzYWdlcyB0aGF0IGRyaXZlIHRoZSBjYXB0dXJlIHBpcGVsaW5lLiBXaGVuIHRoZSBtYXN0ZXIgc3dpdGNoIGlzIE9GRlxuICogd2UgaWdub3JlIHRoZXNlIGJ1dCBzdGlsbCByZXNwb25kIHRvIHN0YXR1cyAvIGNvbmZpZ3VyYXRpb24gcXVlcmllcy4gKi9cbmNvbnN0IENBUFRVUkVfUElQRUxJTkVfTUVTU0FHRVMgPSBuZXcgU2V0PFJ1bnRpbWVNZXNzYWdlWyd0eXBlJ10+KFtcbiAgJ2dyYXBocWwtY2FwdHVyZScsXG4gICdjYXB0dXJlLW5vdycsXG4gICdjYXB0dXJlLWFsbCcsXG4gICdjYXB0dXJlLXRoaXMtcGFnZScsXG4gICdmbHVzaC1hbGwnLFxuICAnZmx1c2gtaGFuZGxlJyxcbiAgJ3N0YXJ0LXJlZmV0Y2gnLFxuICAnc3RhcnQtbWVkaWEtY3Jhd2wnLFxuICAnc3RhcnQtYXV0by1zY3JvbGwnLFxuXSk7XG5cbmFzeW5jIGZ1bmN0aW9uIGlzRW5hYmxlZCgpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIHJldHVybiBzLmVuYWJsZWQgIT09IGZhbHNlO1xufVxuXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVNZXNzYWdlKG1zZzogUnVudGltZU1lc3NhZ2UpOiBQcm9taXNlPHVua25vd24+IHtcbiAgLy8gTWFzdGVyIHN3aXRjaDogd2hlbiB0aGUgdXNlciBoYXMgcGF1c2VkIHRoZSBleHRlbnNpb24gd2Ugc3RpbGwgbmVlZFxuICAvLyB0aGUgbWV0YS1jaGFubmVscyAoZ2V0LXN0YXRlLCB0b2dnbGUtZW5hYmxlZCwgb3Blbi1vcHRpb25zLCBcdTIwMjYpIHNvIHRoZVxuICAvLyBzaWRlYmFyIHN0YXlzIGZ1bmN0aW9uYWwsIGJ1dCBhbnl0aGluZyB0aGF0IHdvdWxkIGFjdHVhbGx5IGNhcHR1cmUsXG4gIC8vIGNvbW1pdCwgb3IgZHJpdmUgYSB0YWIgaXMgYSBuby1vcC5cbiAgaWYgKCEoYXdhaXQgaXNFbmFibGVkKCkpICYmIENBUFRVUkVfUElQRUxJTkVfTUVTU0FHRVMuaGFzKG1zZy50eXBlKSkge1xuICAgIHJldHVybiB7IG9rOiB0cnVlLCBwYXVzZWQ6IHRydWUgfTtcbiAgfVxuICBzd2l0Y2ggKG1zZy50eXBlKSB7XG4gICAgY2FzZSAnZ3JhcGhxbC1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IG9uR3JhcGhxbENhcHR1cmUobXNnLmVuZHBvaW50LCBtc2cudXJsLCBtc2cucmVzcG9uc2UpO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdjb250ZW50LWFsaXZlJzpcbiAgICAgIGF3YWl0IGluZm8oJ2NvbnRlbnQgc2NyaXB0IGFsaXZlIG9uIHBhZ2UnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAncGFnZS1ob29rLWFjdGl2ZSc6XG4gICAgICBhd2FpdCBpbmZvKCdwYWdlIGhvb2sgcGF0Y2hlZCBmZXRjaC9YSFInLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnbG9nLWNvbnRlbnQtZXZlbnQnOlxuICAgICAgaWYgKG1zZy5sZXZlbCA9PT0gJ3dhcm4nKSB7XG4gICAgICAgIGF3YWl0IHdhcm4obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9IGVsc2UgaWYgKG1zZy5sZXZlbCA9PT0gJ2Vycm9yJykge1xuICAgICAgICBhd2FpdCBsb2dFcnIobXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCBpbmZvKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdnZXQtc3RhdGUnOlxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLW5vdyc6XG4gICAgICBhd2FpdCBjYXB0dXJlTm93KG1zZy5oYW5kbGUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLWFsbCc6XG4gICAgICBhd2FpdCBjYXB0dXJlQWxsKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhcHR1cmUtdGhpcy1wYWdlJzpcbiAgICAgIGF3YWl0IGNhcHR1cmVUaGlzUGFnZSgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdmbHVzaC1hbGwnOlxuICAgICAgYXdhaXQgZmx1c2hBbGwoJ3VzZXInKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnZmx1c2gtaGFuZGxlJzpcbiAgICAgIGF3YWl0IGZsdXNoSGFuZGxlKG1zZy5oYW5kbGUsICd1c2VyJyk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3RvZ2dsZS1hdXRvLWNhcHR1cmUnOlxuICAgICAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBhdXRvQ2FwdHVyZTogbXNnLm9uIH0pO1xuICAgICAgYXdhaXQgaW5mbygnYXV0by1jYXB0dXJlIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3RvZ2dsZS1lbmFibGVkJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgZW5hYmxlZDogbXNnLm9uIH0pO1xuICAgICAgaWYgKCFtc2cub24pIHtcbiAgICAgICAgLy8gUGF1c2luZyBzdG9wcyBhbGwgaW4tZmxpZ2h0IGxvb3BzIHNvIHRoZSB1c2VyIGdldHMgaW1tZWRpYXRlXG4gICAgICAgIC8vIHF1aWV0LCBub3QgYSBcIm9uZSBtb3JlIHRpY2tcIiBzdXJwcmlzZS5cbiAgICAgICAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgICAgICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICAgICAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdyZWZldGNoLXRpY2snKTsgLy8gbGVnYWN5IGNsZWFudXBcbiAgICAgICAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ21lZGlhLWNyYXdsLXRpY2snKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFJlc3VtaW5nIHJlLWFybXMgYW55IGxvb3BzIHdob3NlIHNlc3Npb24gaXMgc3RpbGwgc2V0LlxuICAgICAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgICAgaWYgKHNlc3MgIT09IG51bGwpIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XG4gICAgICB9XG4gICAgICBhd2FpdCBpbmZvKCdleHRlbnNpb24gbWFzdGVyIHN3aXRjaCB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAnc3RhcnQtYXV0by1zY3JvbGwnOlxuICAgICAgYXdhaXQgc3RhcnRBdXRvU2Nyb2xsTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYW5jZWwtYXV0by1zY3JvbGwnOlxuICAgICAgYXdhaXQgY2FuY2VsQXV0b1Njcm9sbExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnc2V0LWF1dG8tc2Nyb2xsLWludGVydmFsJzoge1xuICAgICAgY29uc3Qgc2Vjb25kcyA9IE1hdGgubWluKFxuICAgICAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgICAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKG1zZy5zZWNvbmRzKSlcbiAgICAgICk7XG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogc2Vjb25kcyB9KTtcbiAgICAgIC8vIFJlLWFybSBhbnkgYWN0aXZlIGxvb3BzIHdpdGggdGhlIG5ldyBpbnRlcnZhbC5cbiAgICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgICAgaWYgKHNlc3MgIT09IG51bGwpIGFybUF1dG9TY3JvbGxUaW1lcihzZWNvbmRzKTtcbiAgICAgIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHMpO1xuICAgICAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgc3RhcnRNZWRpYUNyYXdsSW50ZXJ2YWwoc2Vjb25kcyk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIH1cbiAgICBjYXNlICdzdGFydC1yZWZldGNoJzpcbiAgICAgIGF3YWl0IHN0YXJ0UmVmZXRjaExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLXJlZmV0Y2gnOlxuICAgICAgYXdhaXQgY2FuY2VsUmVmZXRjaExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnc3RhcnQtbWVkaWEtY3Jhd2wnOlxuICAgICAgYXdhaXQgc3RhcnRNZWRpYUNyYXdsTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYW5jZWwtbWVkaWEtY3Jhd2wnOlxuICAgICAgYXdhaXQgY2FuY2VsTWVkaWFDcmF3bExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAncHVyZ2UtdW5yZWxhdGVkJzoge1xuICAgICAgY29uc3QgYWNjcyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gICAgICBjb25zdCB0cmFja2VkID0gbmV3IFNldChhY2NzLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSkpO1xuICAgICAgY29uc3Qgc3VtbWFyeSA9IGF3YWl0IHB1cmdlVW5yZWxhdGVkU3RhdGUodHJhY2tlZCk7XG4gICAgICBhd2FpdCBpbmZvKCdwdXJnZWQgdW5yZWxhdGVkIHN0YXRlJywgc3VtbWFyeSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIH1cbiAgICBjYXNlICdyZWZyZXNoLWFjY291bnRzJzpcbiAgICAgIGF3YWl0IHJlZnJlc2hBY2NvdW50c0xpc3QodHJ1ZSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3ZlcmlmeS1jb25uZWN0aW9uJzpcbiAgICAgIGF3YWl0IHZlcmlmeUNvbm5lY3Rpb24odHJ1ZSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NsZWFyLWFjdGl2aXR5JzpcbiAgICAgIGF3YWl0IGNsZWFyQWN0aXZpdHkoKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnb3Blbi1vcHRpb25zJzpcbiAgICAgIGF3YWl0IGJyb3dzZXIucnVudGltZS5vcGVuT3B0aW9uc1BhZ2UoKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnb3Blbi12aWV3ZXInOiB7XG4gICAgICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgICAgIGNvbnN0IHVybCA9IHZpZXdlclVybChzKTtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ3Vua25vd24gbWVzc2FnZSB0eXBlJyB9O1xuICB9XG59XG5cbi8vIC0tLSBDYXB0dXJlIHBpcGVsaW5lIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIG9uR3JhcGhxbENhcHR1cmUoZW5kcG9pbnQ6IHN0cmluZywgdXJsOiBzdHJpbmcsIHJlc3BvbnNlOiB1bmtub3duKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChQUk9GSUxFX0VORFBPSU5UUy5oYXMoZW5kcG9pbnQpKSByZXR1cm47IC8vIG5vdCB0d2VldC1iZWFyaW5nXG4gIGlmICghVFdFRVRfRU5EUE9JTlRTLmhhcyhlbmRwb2ludCkpIHJldHVybjtcblxuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIC8vIFdlIGRlbGliZXJhdGVseSBkbyBOT1Qgc2hvcnQtY2lyY3VpdCB3aGVuIHRoZSBQQVQgaXMgbWlzc2luZy4gVGhlXG4gIC8vIG5vcm1hbGl6ZSBzdGVwIGlzIGNoZWFwLCB0aGUgYnVmZmVyIHN1cnZpdmVzIHNlcnZpY2Utd29ya2VyIGV2aWN0aW9uLFxuICAvLyBhbmQgb25jZSB0aGUgUEFUIGlzIHNldCB0aGUgbmV4dCBhbGFybSBvciB1c2VyLXRyaWdnZXJlZCBmbHVzaCBjb21taXRzXG4gIC8vIGV2ZXJ5dGhpbmcgd2UndmUgc2Vlbi4gRHJvcHBpbmcgY2FwdHVyZXMgaGVyZSB3YXMgaGlkaW5nIHRoZSB1c2VyJ3NcbiAgLy8gZmlyc3QgYnJvd3Npbmcgc2Vzc2lvbiBlbnRpcmVseS5cblxuICAvLyBUd28tc3RhZ2UgZmlsdGVyOlxuICAvLyAgIDEuIEJ1aWxkIEVWRVJZIGNhbm9uaWNhbCB0d2VldCB3ZSBjYW4gZmluZCBpbiB0aGUgcmVzcG9uc2UgKG5vIGhhbmRsZVxuICAvLyAgICAgIGZpbHRlciBhdCB0aGUgbm9ybWFsaXplciBsZXZlbCBcdTIwMTQgd2Ugc3RpbGwgd2FudCBxdW90ZWQvUlQnZCBwYXJlbnRzXG4gIC8vICAgICAgdGhhdCBhcHBlYXIgYXMgc2libGluZyBub2RlcykuXG4gIC8vICAgMi4gQXBwbHkgYGZpbHRlclJlbGF0ZWRgIHBvc3QtaG9jIHRvIGRyb3AgYW55dGhpbmcgdGhhdCBoYXMgbm9cbiAgLy8gICAgICByZWxhdGlvbnNoaXAgdG8gYSB0cmFja2VkIGFjY291bnQuIFRoZSBvbGQgYmVoYXZpb3VyIChcImVtcHR5XG4gIC8vICAgICAgYWxsb3dlZC1zZXQgb24gdXNlci1wYWdlIGVuZHBvaW50cywgZnVsbCBmaWx0ZXIgb24gaG9tZS9zZWFyY2hcIilcbiAgLy8gICAgICB3YXMgd2F5IHRvbyBwZXJtaXNzaXZlIG9uIHRoZSBSZXBsaWVzIHRhYjogZXZlcnkgcmFuZG9tIHJlcGxpZXInc1xuICAvLyAgICAgIHJlcGx5IGxhbmRlZCBpbiBhIHBlci1oYW5kbGUgYnVmZmVyIGtleWVkIGJ5IHRoZWlyIG93biBoYW5kbGUuXG4gIGNvbnN0IHRyYWNrZWQgPSBuZXcgU2V0KGFjY291bnRzLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBjYXB0dXJlZEF0ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuXG4gIGxldCBub3JtYWxpemVkO1xuICB0cnkge1xuICAgIG5vcm1hbGl6ZWQgPSBub3JtYWxpemUocmVzcG9uc2UsIHtcbiAgICAgIGNhcHR1cmVkQXQsXG4gICAgICBydW5JZDogJ3BlbmRpbmcnLFxuICAgICAgZW5kcG9pbnQsXG4gICAgICBhbGxvd2VkSGFuZGxlczogbmV3IFNldDxzdHJpbmc+KCksXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHF1YXJhbnRpbmUoJ25vcm1hbGl6ZS10aHJldycsIGVuZHBvaW50LCB1cmwsIHJlc3BvbnNlLCBlcnIpO1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBEcm9wIHVucmVsYXRlZCB0d2VldHMuIFRoZSBmaWx0ZXIgaXMgZW5kcG9pbnQtYXdhcmU6XG4gIC8vICAgLSBPbiB0aGUgaG9tZSAvIHNlYXJjaCB0aW1lbGluZXMgd2UnZCBhbHJlYWR5IGJlZW4gZmlsdGVyaW5nIHRvXG4gIC8vICAgICB0cmFja2VkIGF1dGhvcnMgb25seSBcdTIwMTQga2VlcCB0aGF0IGJlaGF2aW91ciBidXQgZ28gdGhyb3VnaCB0aGUgc2FtZVxuICAvLyAgICAgYGZpbHRlclJlbGF0ZWRgIGhlbHBlciBzbyB0aGUgcnVsZXMgYXJlIHVuaWZvcm0uXG4gIC8vICAgLSBPbiB1c2VyLXBhZ2UgZW5kcG9pbnRzIHdlIG5vdyBhbHNvIGRyb3AgYW55dGhpbmcgdGhhdCBpc24ndCBlaXRoZXJcbiAgLy8gICAgIGF1dGhvcmVkLWJ5LCBtZW50aW9uaW5nLCByZXBseWluZy10bywgb3IgcmVmZXJlbmNlZC1ieSBhIHRyYWNrZWRcbiAgLy8gICAgIGFjY291bnQuXG4gIGNvbnN0IGJlZm9yZUZpbHRlciA9IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aDtcbiAgbm9ybWFsaXplZC50d2VldHMgPSBmaWx0ZXJSZWxhdGVkKG5vcm1hbGl6ZWQudHdlZXRzLCB0cmFja2VkKTtcbiAgY29uc3QgZHJvcHBlZFVucmVsYXRlZCA9IGJlZm9yZUZpbHRlciAtIG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aDtcbiAgaWYgKGRyb3BwZWRVbnJlbGF0ZWQgPiAwKSB7XG4gICAgYXdhaXQgaW5mbygnZHJvcHBlZCB1bnJlbGF0ZWQgdHdlZXRzJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBkcm9wcGVkOiBkcm9wcGVkVW5yZWxhdGVkLFxuICAgICAga2VwdDogbm9ybWFsaXplZC50d2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG5cbiAgLy8gRGlhZ25vc3RpYzogZXZlcnkgdHdlZXQtZW5kcG9pbnQgcGF5bG9hZCBnZXRzIGEgbGluZSBpbiB0aGUgYWN0aXZpdHlcbiAgLy8gdGFpbCB3aXRoIHdoYXQgd2Ugc2F3IHZzIGtlcHQuIFdoZW4gb2JzZXJ2ZWQ9MCB3ZSBhbHNvIGVtaXQgYSBzaGFwZVxuICAvLyBwcm9iZSAoa2V5IHBhdGhzICsgdHlwZW5hbWVzKSBzbyB3ZSBjYW4gdGVsbCB3aGV0aGVyIFggcmV0dXJuZWQgYW5cbiAgLy8gZW1wdHkgZW52ZWxvcGUsIGEgbG9naW4td2FsbCByZXNwb25zZSwgb3IgYSBuZXcgc2hhcGUgd2UgZG9uJ3Qga25vdyBob3dcbiAgLy8gdG8gd2FsayB5ZXQuXG4gIGlmIChub3JtYWxpemVkLm9ic2VydmVkX2lkcy5sZW5ndGggPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdncmFwaHFsIHBheWxvYWQgZW1wdHkgXHUyMDE0IHNoYXBlIHByb2JlJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICB0eXBlbmFtZXM6IHByb2JlVHlwZW5hbWVzKHJlc3BvbnNlKS5zbGljZSgwLCAzMCksXG4gICAgICB0d2VldF9rZXlzOiBwcm9iZUZpcnN0VHlwZVNoYXBlKHJlc3BvbnNlLCAnVHdlZXQnKSxcbiAgICAgIHR3ZWV0X2NvcmVfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgWydjb3JlJ10pLFxuICAgICAgdHdlZXRfbGVnYWN5X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFsnbGVnYWN5J10pLFxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXG4gICAgICAgICdjb3JlJyxcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXG4gICAgICAgICdyZXN1bHQnLFxuICAgICAgXSksXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2NvcmVfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xuICAgICAgICAnY29yZScsXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxuICAgICAgICAncmVzdWx0JyxcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgXSksXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2xlZ2FjeV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXG4gICAgICAgICdjb3JlJyxcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXG4gICAgICAgICdyZXN1bHQnLFxuICAgICAgICAnbGVnYWN5JyxcbiAgICAgIF0pLFxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGF3YWl0IGluZm8oJ2dyYXBocWwgcGF5bG9hZCBzZWVuJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBvYnNlcnZlZDogbm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoLFxuICAgICAga2VwdDogbm9ybWFsaXplZC50d2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG5cbiAgaWYgKG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gIC8vIFJlZmV0Y2ggcXVldWUgaG91c2VrZWVwaW5nIFx1MjAxNCBydW5zIEJFRk9SRSB0aGUgZGVkdXAgc2hvcnQtY2lyY3VpdC4gQVxuICAvLyByZWZldGNoIGNhcHR1cmUgY29tZXMgYmFjayB3aXRoIHRoZSBzYW1lIGVuZ2FnZW1lbnQgY291bnRzICh3ZSdyZVxuICAvLyBvbmx5IGFmdGVyIHRoZSBmdWxsIHRleHQpLCBzbyB0aGUgZGVkdXAgYmVsb3cgd291bGQgc2lsZW50bHkgZHJvcFxuICAvLyBpdCBhbmQgdGhlIHF1ZXVlIHdvdWxkIG5ldmVyIGRyYWluLiBIb2lzdCB0aGUgZW5xdWV1ZS9kZXF1ZXVlIGhlcmVcbiAgLy8gc28gdGhlIGxvb3AgcmVsaWFibHkgYWR2YW5jZXMgZXZlbiB3aGVuIG5vIGNvbW1pdCBoYXBwZW5zLlxuICAvL1xuICAvLyBBbHNvOiBpZiBlaXRoZXIgbG9vcCdzIGluZmxpZ2h0IHRhcmdldCBhcHBlYXJzIGhlcmUsIG1hcmsgdGhlIGxvb3BcbiAgLy8gYXMgXCJpbmdlc3RlZFwiIHNvIHRoZSBuZXh0IHRpY2sgY2FuIGFkdmFuY2UuIFRoZSB3YWl0LWZvci1pbmdlc3RcbiAgLy8gZ3VhcmQgb3RoZXJ3aXNlIGJsb2NrcyB1bnRpbCB0aGUgbmF2aWdhdGlvbi10aW1lb3V0IGZpcmVzLlxuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xTZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgZm9yIChjb25zdCB0IG9mIG5vcm1hbGl6ZWQudHdlZXRzKSB7XG4gICAgaWYgKHQuaXNfdHJ1bmNhdGVkKSB7XG4gICAgICBhd2FpdCBlbnF1ZXVlUmVmZXRjaCh0LmFjY291bnRfaGFuZGxlLCB0LnR3ZWV0X2lkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2godC5hY2NvdW50X2hhbmRsZSwgdC50d2VldF9pZCk7XG4gICAgfVxuICAgIC8vIFN1Y2Nlc3NmdWxseSBidWlsdCB0d2VldHMgYXJlIG5vIGxvbmdlciBcInBhcnRpYWxcIiBcdTIwMTQgZHJvcCBmcm9tIHRoZVxuICAgIC8vIG1lZGlhLWNyYXdsIHF1ZXVlIHJlZ2FyZGxlc3Mgb2Ygd2hpY2ggaGFuZGxlIHdlJ2QgaGludGVkIGVhcmxpZXIuXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodC50d2VldF9pZCk7XG4gICAgaWYgKHJlZmV0Y2hTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdC50d2VldF9pZCkge1xuICAgICAgcmVmZXRjaFNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgICAgcmVmZXRjaFNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihyZWZldGNoU2Vzcyk7XG4gICAgfVxuICAgIGlmIChtZWRpYUNyYXdsU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obWVkaWFDcmF3bFNlc3MpO1xuICAgIH1cbiAgfVxuXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiB0d2VldC1zaGFwZWQgbm9kZXMgdGhlIHdhbGtlciBzYXcgYnV0IGNvdWxkbid0IHR1cm5cbiAgLy8gaW50byBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBFbnF1ZXVlIG9ubHkgSURzIHdlIGhhdmVuJ3QgYWxyZWFkeVxuICAvLyBjb21taXR0ZWQgKHVzZXItcmVxdWVzdGVkIGRlZHVwIGFnYWluc3QgdGhlIGFyY2hpdmUpLlxuICBmb3IgKGNvbnN0IHBhcnRpYWwgb2Ygbm9ybWFsaXplZC5wYXJ0aWFsX2lkcykge1xuICAgIGlmIChhd2FpdCBpc0NvbW1pdHRlZChwYXJ0aWFsLnR3ZWV0X2lkKSkgY29udGludWU7XG4gICAgYXdhaXQgZW5xdWV1ZU1lZGlhQ3Jhd2wocGFydGlhbC5oaW50X2hhbmRsZSwgcGFydGlhbC50d2VldF9pZCk7XG4gIH1cbiAgaWYgKG5vcm1hbGl6ZWQucGFydGlhbF9pZHMubGVuZ3RoID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsOiBlbnF1ZXVlZCBwYXJ0aWFsIGNhcHR1cmVzJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBwYXJ0aWFsOiBub3JtYWxpemVkLnBhcnRpYWxfaWRzLmxlbmd0aCxcbiAgICAgIHF1ZXVlX3RvdGFsOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxuICAgIH0pO1xuICB9XG5cbiAgLy8gQ3Jvc3Mtc2Vzc2lvbiBkZWR1cDogZHJvcCB0d2VldHMgd2UndmUgYWxyZWFkeSBjb21taXR0ZWQgd2l0aCBpZGVudGljYWxcbiAgLy8gZW5nYWdlbWVudCBjb3VudHMuIExpa2VzL1JUcy9yZXBsaWVzL3F1b3RlcyBzdGlsbCB0cmlnZ2VyIGEgcmVjYXB0dXJlXG4gIC8vIHNvIGVuZ2FnZW1lbnRfaGlzdG9yeSBncm93cyBvdmVyIHRpbWUuIHZpZXdfY291bnQgaXMgaW50ZW50aW9uYWxseVxuICAvLyBleGNsdWRlZCBcdTIwMTQgaXQgY2h1cm5zIHRvbyBmYXN0IHRvIGJlIHVzZWZ1bCBhcyBhIGZyZXNobmVzcyBzaWduYWwuXG4gIC8vIGBpc190cnVuY2F0ZWRgIGlzIHBhcnQgb2YgdGhlIHNpZ25hdHVyZSBzbyBhIHJlZmV0Y2ggdGhhdCBmbGlwc1xuICAvLyB0cnVuY2F0ZWRcdTIxOTJmdWxsIGlzIHRyZWF0ZWQgYXMgYSBtYXRlcmlhbCBjaGFuZ2UgYW5kIGdldHMgY29tbWl0dGVkLlxuICBjb25zdCBjb21taXR0ZWRJZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBsZXQgZGVkdXBlZFNraXBwZWQgPSAwO1xuICBjb25zdCBsaXZlVHdlZXRzOiB0eXBlb2Ygbm9ybWFsaXplZC50d2VldHMgPSBbXTtcbiAgZm9yIChjb25zdCB0IG9mIG5vcm1hbGl6ZWQudHdlZXRzKSB7XG4gICAgY29uc3QgcHJldiA9IGNvbW1pdHRlZElkeFt0LmFjY291bnRfaGFuZGxlXT8uW3QudHdlZXRfaWRdO1xuICAgIGNvbnN0IHNpZyA9IGVuZ2FnZW1lbnRTaWcoXG4gICAgICB0Lmxpa2VfY291bnQsXG4gICAgICB0LnJldHdlZXRfY291bnQsXG4gICAgICB0LnJlcGx5X2NvdW50LFxuICAgICAgdC5xdW90ZV9jb3VudCxcbiAgICAgIHQuaXNfdHJ1bmNhdGVkXG4gICAgKTtcbiAgICBpZiAocHJldiAmJiBwcmV2LnNpZyA9PT0gc2lnKSB7XG4gICAgICBkZWR1cGVkU2tpcHBlZCArPSAxO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGxpdmVUd2VldHMucHVzaCh0KTtcbiAgfVxuICBpZiAoZGVkdXBlZFNraXBwZWQgPiAwKSB7XG4gICAgYXdhaXQgaW5mbygnZGVkdXA6IHNraXBwZWQgdW5jaGFuZ2VkIHR3ZWV0cycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgc2tpcHBlZDogZGVkdXBlZFNraXBwZWQsXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG4gIGlmIChsaXZlVHdlZXRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gIC8vIEdyb3VwIHN1cnZpdmluZyB0d2VldHMgYnkgYXV0aG9yIGhhbmRsZS5cbiAgY29uc3QgYnlIYW5kbGUgPSBuZXcgTWFwPHN0cmluZywgQ2Fub25pY2FsVHdlZXRbXT4oKTtcbiAgZm9yIChjb25zdCB0IG9mIGxpdmVUd2VldHMpIHtcbiAgICBjb25zdCBhcnIgPSBieUhhbmRsZS5nZXQodC5hY2NvdW50X2hhbmRsZSkgPz8gW107XG4gICAgYXJyLnB1c2godCk7XG4gICAgYnlIYW5kbGUuc2V0KHQuYWNjb3VudF9oYW5kbGUsIGFycik7XG4gIH1cblxuICBmb3IgKGNvbnN0IFtoYW5kbGUsIHR3ZWV0c10gb2YgYnlIYW5kbGUpIHtcbiAgICBjb25zdCBidWYgPSBhd2FpdCBlbnN1cmVSdW5CdWZmZXIoaGFuZGxlLCBjYXB0dXJlZEF0LCB1cmwsIGVuZHBvaW50KTtcbiAgICBsZXQgYWRkZWQgPSAwO1xuICAgIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICAgIGNvbnN0IGV4aXN0aW5nID0gYnVmLnR3ZWV0c19ieV9pZFt0LnR3ZWV0X2lkXTtcbiAgICAgIGlmIChleGlzdGluZykge1xuICAgICAgICAvLyBQcmVzZXJ2ZSBmaXJzdF9jYXB0dXJlZF9hdCwgYXBwZW5kIGVuZ2FnZW1lbnQgc25hcHNob3QsIHJlZnJlc2hcbiAgICAgICAgLy8gbGFzdF9zZWVuX2F0ICsgY291bnRzICh0aGUgbGF0ZXN0IHNjcmFwZSB3aW5zIGZvciBjb3VudHMpLlxuICAgICAgICBleGlzdGluZy5sYXN0X3NlZW5fYXQgPSBjYXB0dXJlZEF0O1xuICAgICAgICBleGlzdGluZy5saWtlX2NvdW50ID0gdC5saWtlX2NvdW50O1xuICAgICAgICBleGlzdGluZy5yZXR3ZWV0X2NvdW50ID0gdC5yZXR3ZWV0X2NvdW50O1xuICAgICAgICBleGlzdGluZy5yZXBseV9jb3VudCA9IHQucmVwbHlfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnF1b3RlX2NvdW50ID0gdC5xdW90ZV9jb3VudDtcbiAgICAgICAgZXhpc3Rpbmcudmlld19jb3VudCA9IHQudmlld19jb3VudDtcbiAgICAgICAgZXhpc3RpbmcuYm9va21hcmtfY291bnQgPSB0LmJvb2ttYXJrX2NvdW50O1xuICAgICAgICBjb25zdCBsYXN0ID0gZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5W2V4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeS5sZW5ndGggLSAxXTtcbiAgICAgICAgY29uc3Qgc25hcCA9IHQuZW5nYWdlbWVudF9oaXN0b3J5WzBdO1xuICAgICAgICBpZiAoc25hcCAmJiAoIWxhc3QgfHwgbGFzdC5jYXB0dXJlZF9hdCAhPT0gc25hcC5jYXB0dXJlZF9hdCkpIHtcbiAgICAgICAgICBleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnkucHVzaChzbmFwKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3Qgc3RhbXBlZDogQ2Fub25pY2FsVHdlZXQgPSB7IC4uLnQsIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkIH07XG4gICAgICAgIGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF0gPSBzdGFtcGVkO1xuICAgICAgICBhZGRlZCArPSAxO1xuICAgICAgfVxuICAgICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHQudHdlZXRfaWQpKSB7XG4gICAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFidWYuZW5kcG9pbnRzX3NlZW4uaW5jbHVkZXMoZW5kcG9pbnQpKSBidWYuZW5kcG9pbnRzX3NlZW4ucHVzaChlbmRwb2ludCk7XG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcbiAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoKTtcbiAgICBpZiAoYWRkZWQgPiAwKSB7XG4gICAgICBhd2FpdCBpbmZvKCdjYXB0dXJlZCB0d2VldHMnLCB7XG4gICAgICAgIGhhbmRsZSxcbiAgICAgICAgZW5kcG9pbnQsXG4gICAgICAgIGFkZGVkLFxuICAgICAgICB0b3RhbDogT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoLFxuICAgICAgfSk7XG4gICAgICAvLyBCdW1wIHRoZSBhdXRvLXNjcm9sbCBwcm9ncmVzcyBzbyB0aGUgdXNlciBzZWVzIFwiWCBpbmdlc3RlZFwiIHRpY2sgdXBcbiAgICAgIC8vIGluIHJlYWwgdGltZS4gV2UgY291bnQgYWN0dWFsbHktbmV3IHR3ZWV0cywgbm90IGR1cGxpY2F0ZXMuXG4gICAgICBjb25zdCBhc1Nlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xuICAgICAgICBhc1Nlc3MuaW5nZXN0ZWRDb3VudCArPSBhZGRlZDtcbiAgICAgICAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oYXNTZXNzKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCA+PSBGTFVTSF9UV0VFVF9USFJFU0hPTEQpIHtcbiAgICAgIGF3YWl0IGZsdXNoSGFuZGxlKGhhbmRsZSwgJ3RocmVzaG9sZCcpO1xuICAgIH1cbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVSdW5CdWZmZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICB0czogc3RyaW5nLFxuICBzb3VyY2VVcmw6IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZ1xuKTogUHJvbWlzZTxSdW5CdWZmZXI+IHtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSk7XG4gIGlmIChjdXIpIHJldHVybiBjdXI7XG4gIGNvbnN0IGJ1ZjogUnVuQnVmZmVyID0ge1xuICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcbiAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgIHN0YXJ0ZWRfYXQ6IHRzLFxuICAgIGxhc3RfY2FwdHVyZV9hdDogdHMsXG4gICAgdHdlZXRzX2J5X2lkOiB7fSxcbiAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IFtdLFxuICAgIGVuZHBvaW50c19zZWVuOiBbZW5kcG9pbnRdLFxuICAgIHNvdXJjZV91cmw6IHNvdXJjZVVybCxcbiAgfTtcbiAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcbiAgYXdhaXQgaW5mbygncnVuIHN0YXJ0ZWQnLCB7IGhhbmRsZSwgcnVuOiBzaG9ydFJ1bklkKGJ1Zi5ydW5faWQpIH0pO1xuICByZXR1cm4gYnVmO1xufVxuXG4vLyAtLS0gRmx1c2ggbG9naWMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5sZXQgZmx1c2hDaGFpbjogUHJvbWlzZTx2b2lkPiA9IFByb21pc2UucmVzb2x2ZSgpO1xuXG5pbnRlcmZhY2UgRmx1c2hJdGVtIHtcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIGJ1ZjogUnVuQnVmZmVyO1xuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W107XG4gIHJhd1BhdGg6IHN0cmluZztcbiAgc2VlblBhdGg6IHN0cmluZztcbiAgY2FwdHVyZTogQ2FwdHVyZVBheWxvYWQ7XG4gIHNlZW46IFNlZW5QYXlsb2FkO1xuICBkYXk6IHN0cmluZztcbiAgcnVuU2hvcnQ6IHN0cmluZztcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hJZGxlQnVmZmVycygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBjb25zdCBoYW5kbGVzOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XG4gICAgICBoYW5kbGVzLnB1c2goaGFuZGxlKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgZmx1c2hIYW5kbGVzKGhhbmRsZXMsICdpZGxlJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoT3JwaGFuZWRCdWZmZXJzSWZTdGFsZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gT24gd29ya2VyIHdha2UsIGFueSBidWZmZXIgb2xkZXIgdGhhbiB0aGUgaWRsZSB0aHJlc2hvbGQgZ2V0cyBhIGNoYW5jZSB0b1xuICAvLyBjb21taXQgaW1tZWRpYXRlbHkgXHUyMDE0IHVzZWZ1bCB3aGVuIHRoZSB3b3JrZXIgd2FzIGV2aWN0ZWQgYmVmb3JlIGlkbGUtZmx1c2guXG4gIC8vIElmIHRoZSBQQVQvb3duZXIvcmVwbyBhcmVuJ3Qgc2V0IHdlJ2QganVzdCBlbWl0IFwiZmx1c2ggZGVmZXJyZWRcIiBmb3IgZXZlcnlcbiAgLy8gc2luZ2xlIGhhbmRsZSBpbiBzdG9yYWdlICh0aGUgZGlhZ25vc3RpYyBzaG93ZWQgdGhpcyBmaXJpbmcgMzAwKyB0aW1lcyBpblxuICAvLyBhIHJvdyB3aGVuIHRoZSBleHRlbnNpb24gd29rZSBiZWZvcmUgc2V0dGluZ3MgbG9hZCksIHNvIHNob3J0LWNpcmN1aXRcbiAgLy8gaGVyZSBpbnN0ZWFkLlxuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykgcmV0dXJuO1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gIGNvbnN0IGhhbmRsZXM6IHN0cmluZ1tdID0gW107XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgYnVmXSBvZiBPYmplY3QuZW50cmllcyhhbGwpKSB7XG4gICAgY29uc3QgbGFzdCA9IERhdGUucGFyc2UoYnVmLmxhc3RfY2FwdHVyZV9hdCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShsYXN0KSAmJiBub3cgLSBsYXN0ID49IEZMVVNIX0lETEVfTVMpIHtcbiAgICAgIGhhbmRsZXMucHVzaChoYW5kbGUpO1xuICAgIH1cbiAgfVxuICBhd2FpdCBmbHVzaEhhbmRsZXMoaGFuZGxlcywgJ3dha2UnKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hBbGwocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBhd2FpdCBmbHVzaEhhbmRsZXMoT2JqZWN0LmtleXMoYWxsKSwgcmVhc29uKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGUoaGFuZGxlOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhbaGFuZGxlXSwgcmVhc29uKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGVzKGhhbmRsZXM6IHN0cmluZ1tdLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCB1bmlxdWUgPSBbLi4ubmV3IFNldChoYW5kbGVzKV0uZmlsdGVyKChoKSA9PiBoLmxlbmd0aCA+IDApO1xuICBpZiAodW5pcXVlLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBjb25zdCBydW4gPSBmbHVzaENoYWluLnRoZW4oKCkgPT4gZmx1c2hIYW5kbGVzTG9ja2VkKHVuaXF1ZSwgcmVhc29uKSk7XG4gIGZsdXNoQ2hhaW4gPSBydW4uY2F0Y2goKCkgPT4ge30pO1xuICByZXR1cm4gcnVuO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaEhhbmRsZXNMb2NrZWQoaGFuZGxlczogc3RyaW5nW10sIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3QgaXRlbXM6IEZsdXNoSXRlbVtdID0gW107XG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIGhhbmRsZXMpIHtcbiAgICBjb25zdCBidWYgPSBhbGxbaGFuZGxlXTtcbiAgICBpZiAoIWJ1ZikgY29udGludWU7XG4gICAgY29uc3QgdHdlZXRzID0gT2JqZWN0LnZhbHVlcyhidWYudHdlZXRzX2J5X2lkKTtcbiAgICBpZiAodHdlZXRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgYXdhaXQgY2xlYXJSdW5CdWZmZXIoaGFuZGxlKTtcbiAgICAgIGF3YWl0IHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlLCAwKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpdGVtcy5wdXNoKGJ1aWxkRmx1c2hJdGVtKGhhbmRsZSwgYnVmLCB0d2VldHMpKTtcbiAgfVxuICBpZiAoaXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm47XG5cbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHtcbiAgICBhd2FpdCB3YXJuKCdmbHVzaCBkZWZlcnJlZDogc2V0dGluZ3MgaW5jb21wbGV0ZScsIHtcbiAgICAgIGNvdW50OiBpdGVtcy5sZW5ndGgsXG4gICAgICBoYW5kbGVzOiBpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uaGFuZGxlKS5zbGljZSgwLCAyMCksXG4gICAgfSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICBjb25zdCBmaWxlcyA9IGl0ZW1zLmZsYXRNYXAoKGl0ZW0pID0+IFtcbiAgICB7XG4gICAgICBwYXRoOiBpdGVtLnJhd1BhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShpdGVtLmNhcHR1cmUsIG51bGwsIDIpICsgJ1xcbicpLFxuICAgIH0sXG4gICAge1xuICAgICAgcGF0aDogaXRlbS5zZWVuUGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KGl0ZW0uc2VlbiwgbnVsbCwgMikgKyAnXFxuJyksXG4gICAgfSxcbiAgXSk7XG4gIGNvbnN0IGNvbW1pdE1zZyA9IGJ1aWxkQmF0Y2hDb21taXRNZXNzYWdlKGl0ZW1zKTtcblxuICB0cnkge1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNsaWVudC5jb21taXRGaWxlcyh7XG4gICAgICBmaWxlcyxcbiAgICAgIG1lc3NhZ2U6IGNvbW1pdE1zZyxcbiAgICB9KTtcbiAgICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xuICAgICAgY29uc3QgcmVtYWluaW5nQ291bnQgPSBhd2FpdCBjbGVhckNvbW1pdHRlZFR3ZWV0c0Zyb21CdWZmZXIoaXRlbSk7XG4gICAgICAvLyBDb3VudGVyIGJ1bXA6IGFjdHVhbGx5IElOQ1JFTUVOVCB0b2RheUNvdW50IGFuZCB0b3RhbENvbW1pdHRlZCBieVxuICAgICAgLy8gdGhlIG51bWJlciBvZiB0d2VldHMgd2UganVzdCBwZXJzaXN0ZWQgKHRoZSBwcmV2aW91cyBjb2RlIHJlYWQgdGhlXG4gICAgICAvLyBleGlzdGluZyB2YWx1ZXMgYW5kIHdyb3RlIHRoZW0gYmFjaywgbGVhdmluZyB0aGUgY291bnRlciBwZWdnZWQgYXRcbiAgICAgIC8vIHplcm8pLlxuICAgICAgY29uc3QgcHJldiA9IChhd2FpdCBnZXRDb3VudGVycygpKVtpdGVtLmhhbmRsZV07XG4gICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG4gICAgICBjb25zdCBjYXJyaWVkVG9kYXkgPSBwcmV2ICYmIHByZXYudG9kYXlEYXRlID09PSB0b2RheSA/IHByZXYudG9kYXlDb3VudCA6IDA7XG4gICAgICBhd2FpdCBidW1wQ291bnRlcihpdGVtLmhhbmRsZSwge1xuICAgICAgICB0b2RheUNvdW50OiBjYXJyaWVkVG9kYXkgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIHRvZGF5RGF0ZTogdG9kYXksXG4gICAgICAgIGxhc3RDYXB0dXJlQXQ6IGl0ZW0uYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgICAgdG90YWxDb21taXR0ZWQ6IChwcmV2Py50b3RhbENvbW1pdHRlZCA/PyAwKSArIGl0ZW0udHdlZXRzLmxlbmd0aCxcbiAgICAgICAgYnVmZmVyZWRDb3VudDogcmVtYWluaW5nQ291bnQsXG4gICAgICB9KTtcbiAgICAgIC8vIFJlY29yZCBjb21taXRzIGluIHRoZSBkZWR1cCBpbmRleCBzbyB3ZSBkb24ndCByZS1jb21taXQgdGhlbSBuZXh0XG4gICAgICAvLyBicm93c2Ugd2l0aCB1bmNoYW5nZWQgZW5nYWdlbWVudC5cbiAgICAgIGNvbnN0IGlubmVyID0gaWR4W2l0ZW0uaGFuZGxlXSA/PyB7fTtcbiAgICAgIGNvbnN0IG5vd0lzbyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICAgIGZvciAoY29uc3QgdCBvZiBpdGVtLnR3ZWV0cykge1xuICAgICAgICBpbm5lclt0LnR3ZWV0X2lkXSA9IHtcbiAgICAgICAgICB0czogbm93SXNvLFxuICAgICAgICAgIHNpZzogZW5nYWdlbWVudFNpZyhcbiAgICAgICAgICAgIHQubGlrZV9jb3VudCxcbiAgICAgICAgICAgIHQucmV0d2VldF9jb3VudCxcbiAgICAgICAgICAgIHQucmVwbHlfY291bnQsXG4gICAgICAgICAgICB0LnF1b3RlX2NvdW50LFxuICAgICAgICAgICAgdC5pc190cnVuY2F0ZWRcbiAgICAgICAgICApLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWR4W2l0ZW0uaGFuZGxlXSA9IGlubmVyO1xuICAgICAgYXdhaXQgaW5mbygnZmx1c2ggY29tbWl0dGVkJywge1xuICAgICAgICBoYW5kbGU6IGl0ZW0uaGFuZGxlLFxuICAgICAgICByZWFzb24sXG4gICAgICAgIHR3ZWV0czogaXRlbS50d2VldHMubGVuZ3RoLFxuICAgICAgICBydW46IGl0ZW0ucnVuU2hvcnQsXG4gICAgICAgIHBhdGg6IGl0ZW0ucmF3UGF0aCxcbiAgICAgICAgYmF0Y2hfY29tbWl0OiByZXN1bHQuY29tbWl0U2hhLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG4gICAgYXdhaXQgaW5mbygnZmx1c2ggYmF0Y2ggY29tbWl0dGVkJywge1xuICAgICAgcmVhc29uLFxuICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcbiAgICAgIHR3ZWV0czogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApLFxuICAgICAgY29tbWl0OiByZXN1bHQuY29tbWl0U2hhLFxuICAgIH0pO1xuICAgIHtcbiAgICAgIGNvbnN0IHByZXYgPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzOiAnb2snLFxuICAgICAgICBsb2dpbjogcHJldi5sb2dpbixcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBwcmV2LmRlZmF1bHRCcmFuY2gsXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IHByZXYuY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSB7XG4gICAgICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICAgICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAnYXV0aCdcbiAgICAgICAgICA/ICdhdXRoLWVycm9yJ1xuICAgICAgICAgIDogZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICAgID8gJ3JhdGUtbGltaXRlZCdcbiAgICAgICAgICAgIDogZXJyLmNhdGVnb3J5ID09PSAnbmV0d29yaydcbiAgICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgICAgOiBjb25uLnN0YXR1cztcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXMsXG4gICAgICAgIGxvZ2luOiBjb25uLmxvZ2luLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IGVyci5tZXNzYWdlLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBjb25uLmRlZmF1bHRCcmFuY2gsXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGNvbm4uY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDpcbiAgICAgICAgICBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IGVyci5yYXRlTGltaXRSZXNldEF0IDogY29ubi5yYXRlTGltaXRSZXNldEF0LFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBsb2dFcnIoJ2ZsdXNoIGZhaWxlZCcsIHtcbiAgICAgICAgcmVhc29uLFxuICAgICAgICBoYW5kbGVzOiBpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uaGFuZGxlKS5zbGljZSgwLCAyMCksXG4gICAgICAgIHJ1bnM6IGl0ZW1zLmxlbmd0aCxcbiAgICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcbiAgICAgICAgY2F0ZWdvcnk6IGVyci5jYXRlZ29yeSxcbiAgICAgICAgc3RhdHVzOiBlcnIuc3RhdHVzLFxuICAgICAgICBtZXNzYWdlOiBlcnIubWVzc2FnZSxcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogZXJyLnJhdGVMaW1pdFJlc2V0QXQsXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgbG9nRXJyKCdmbHVzaCBmYWlsZWQnLCB7XG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxuICAgICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXG4gICAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXG4gICAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICAgIH0pO1xuICAgIH1cbiAgICAvLyBMZWF2ZSBidWZmZXIgaW50YWN0IGZvciByZXRyeS5cbiAgfSBmaW5hbGx5IHtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGJ1aWxkRmx1c2hJdGVtKGhhbmRsZTogc3RyaW5nLCBidWY6IFJ1bkJ1ZmZlciwgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdKTogRmx1c2hJdGVtIHtcbiAgY29uc3QgdHMgPSBpc29Db21wYWN0KGJ1Zi5zdGFydGVkX2F0KTtcbiAgY29uc3QgZGF5ID0gYnVmLnN0YXJ0ZWRfYXQuc2xpY2UoMCwgMTApO1xuICBjb25zdCBydW5TaG9ydCA9IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCk7XG4gIGNvbnN0IHJhd1BhdGggPSBgcmF3LyR7aGFuZGxlfS8ke3RzfS0ke3J1blNob3J0fS5qc29uYDtcbiAgY29uc3Qgc2VlblBhdGggPSBgc2Vlbi8ke2hhbmRsZX0vJHt0c30tJHtydW5TaG9ydH0uanNvbmA7XG4gIHJldHVybiB7XG4gICAgaGFuZGxlLFxuICAgIGJ1ZixcbiAgICB0d2VldHMsXG4gICAgcmF3UGF0aCxcbiAgICBzZWVuUGF0aCxcbiAgICBkYXksXG4gICAgcnVuU2hvcnQsXG4gICAgY2FwdHVyZToge1xuICAgICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gICAgICBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgIGVuZHBvaW50OiBidWYuZW5kcG9pbnRzX3NlZW4uam9pbignLCcpLFxuICAgICAgdXNlcl9hZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcbiAgICAgIHNvdXJjZV91cmw6IGJ1Zi5zb3VyY2VfdXJsLFxuICAgICAgdHdlZXRzLFxuICAgIH0sXG4gICAgc2Vlbjoge1xuICAgICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gICAgICBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogYnVmLnR3ZWV0X2lkc19vYnNlcnZlZCxcbiAgICB9LFxuICB9O1xufVxuXG5mdW5jdGlvbiBidWlsZEJhdGNoQ29tbWl0TWVzc2FnZShpdGVtczogRmx1c2hJdGVtW10pOiBzdHJpbmcge1xuICBpZiAoaXRlbXMubGVuZ3RoID09PSAxKSB7XG4gICAgY29uc3QgaXRlbSA9IGl0ZW1zWzBdITtcbiAgICByZXR1cm4gYGNhcHR1cmU6ICR7aXRlbS5oYW5kbGV9ICR7aXRlbS5kYXl9ICR7aXRlbS50d2VldHMubGVuZ3RofSB0d2VldCR7aXRlbS50d2VldHMubGVuZ3RoID09PSAxID8gJycgOiAncyd9IChydW4gJHtpdGVtLnJ1blNob3J0fSlgO1xuICB9XG4gIGNvbnN0IGRheXMgPSBbLi4ubmV3IFNldChpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uZGF5KSldLnNvcnQoKTtcbiAgY29uc3QgZGF5TGFiZWwgPSBkYXlzLmxlbmd0aCA9PT0gMSA/IGRheXNbMF0hIDogYCR7ZGF5c1swXX0uLiR7ZGF5c1tkYXlzLmxlbmd0aCAtIDFdfWA7XG4gIGNvbnN0IHR3ZWV0Q291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udHdlZXRzLmxlbmd0aCwgMCk7XG4gIHJldHVybiBgY2FwdHVyZSBiYXRjaDogJHtpdGVtcy5sZW5ndGh9IHJ1bnMsICR7dHdlZXRDb3VudH0gdHdlZXQke3R3ZWV0Q291bnQgPT09IDEgPyAnJyA6ICdzJ30gKCR7ZGF5TGFiZWx9KWA7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNsZWFyQ29tbWl0dGVkVHdlZXRzRnJvbUJ1ZmZlcihpdGVtOiBGbHVzaEl0ZW0pOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBjdXJyZW50ID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcbiAgaWYgKCFjdXJyZW50KSByZXR1cm4gMDtcbiAgaWYgKGN1cnJlbnQucnVuX2lkICE9PSBpdGVtLmJ1Zi5ydW5faWQpIHJldHVybiBPYmplY3Qua2V5cyhjdXJyZW50LnR3ZWV0c19ieV9pZCkubGVuZ3RoO1xuXG4gIGNvbnN0IGNvbW1pdHRlZCA9IG5ldyBNYXAoXG4gICAgaXRlbS50d2VldHMubWFwKCh0KSA9PiBbXG4gICAgICB0LnR3ZWV0X2lkLFxuICAgICAgZW5nYWdlbWVudFNpZyh0Lmxpa2VfY291bnQsIHQucmV0d2VldF9jb3VudCwgdC5yZXBseV9jb3VudCwgdC5xdW90ZV9jb3VudCwgdC5pc190cnVuY2F0ZWQpLFxuICAgIF0pXG4gICk7XG4gIGNvbnN0IHJlbWFpbmluZ1R3ZWV0czogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+ID0ge307XG4gIGZvciAoY29uc3QgW3R3ZWV0SWQsIHR3ZWV0XSBvZiBPYmplY3QuZW50cmllcyhjdXJyZW50LnR3ZWV0c19ieV9pZCkpIHtcbiAgICBjb25zdCBjb21taXR0ZWRTaWcgPSBjb21taXR0ZWQuZ2V0KHR3ZWV0SWQpO1xuICAgIGNvbnN0IGN1cnJlbnRTaWcgPSBlbmdhZ2VtZW50U2lnKFxuICAgICAgdHdlZXQubGlrZV9jb3VudCxcbiAgICAgIHR3ZWV0LnJldHdlZXRfY291bnQsXG4gICAgICB0d2VldC5yZXBseV9jb3VudCxcbiAgICAgIHR3ZWV0LnF1b3RlX2NvdW50LFxuICAgICAgdHdlZXQuaXNfdHJ1bmNhdGVkXG4gICAgKTtcbiAgICBpZiAoIWNvbW1pdHRlZFNpZyB8fCBjb21taXR0ZWRTaWcgIT09IGN1cnJlbnRTaWcpIHtcbiAgICAgIHJlbWFpbmluZ1R3ZWV0c1t0d2VldElkXSA9IHsgLi4udHdlZXQgfTtcbiAgICB9XG4gIH1cblxuICBjb25zdCByZW1haW5pbmdDb3VudCA9IE9iamVjdC5rZXlzKHJlbWFpbmluZ1R3ZWV0cykubGVuZ3RoO1xuICBpZiAocmVtYWluaW5nQ291bnQgPT09IDApIHtcbiAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSk7XG4gICAgcmV0dXJuIDA7XG4gIH1cblxuICBjb25zdCBuZXh0UnVuSWQgPSBuZXdSdW5JZCgpO1xuICBmb3IgKGNvbnN0IHR3ZWV0IG9mIE9iamVjdC52YWx1ZXMocmVtYWluaW5nVHdlZXRzKSkge1xuICAgIHR3ZWV0LmNhcHR1cmVfcnVuX2lkID0gbmV4dFJ1bklkO1xuICB9XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSwge1xuICAgIC4uLmN1cnJlbnQsXG4gICAgcnVuX2lkOiBuZXh0UnVuSWQsXG4gICAgc3RhcnRlZF9hdDogY3VycmVudC5sYXN0X2NhcHR1cmVfYXQsXG4gICAgdHdlZXRzX2J5X2lkOiByZW1haW5pbmdUd2VldHMsXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBjdXJyZW50LnR3ZWV0X2lkc19vYnNlcnZlZC5maWx0ZXIoKGlkKSA9PiBpZCBpbiByZW1haW5pbmdUd2VldHMpLFxuICB9KTtcbiAgYXdhaXQgaW5mbygnZmx1c2gga2VwdCBuZXdlciBidWZmZXJlZCB0d2VldHMnLCB7XG4gICAgaGFuZGxlOiBpdGVtLmhhbmRsZSxcbiAgICBjb21taXR0ZWRfcnVuOiBpdGVtLnJ1blNob3J0LFxuICAgIG5leHRfcnVuOiBzaG9ydFJ1bklkKG5leHRSdW5JZCksXG4gICAgcmVtYWluaW5nOiByZW1haW5pbmdDb3VudCxcbiAgfSk7XG4gIHJldHVybiByZW1haW5pbmdDb3VudDtcbn1cblxuLy8gLS0tIENhcHR1cmUtbm93IC8gY2FwdHVyZS1hbGwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlTm93KGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIExhbmQgb24gdGhlIFJlcGxpZXMgdGFiIHNvIFggZmV0Y2hlcyB2aWEgVXNlclR3ZWV0c0FuZFJlcGxpZXMgXHUyMDE0IHRoYXRcbiAgLy8gZW5kcG9pbnQgcmV0dXJucyBib3RoIHRvcC1sZXZlbCBwb3N0cyBhbmQgcmVwbGllcywgd2hpY2ggaXMgdGhlIHN1cGVyc2V0XG4gIC8vIHdlIHdhbnQgZm9yIHRoZSBhcmNoaXZlLiBUaGUgcGxhaW4gYC88aGFuZGxlPmAgVVJMIGhpdHMgVXNlclR3ZWV0cyxcbiAgLy8gd2hpY2ggb21pdHMgcmVwbGllcy4gVGhlIHBhZ2UtaG9vayBpbnRlcmNlcHRzIGVpdGhlciBlbmRwb2ludCwgYnV0XG4gIC8vIGZvcmNpbmcgdGhlIGJyb2FkZXIgdGFiIG9uIHVzZXItaW5pdGlhdGVkIGNhcHR1cmVzIGlzIHRoZSByaWdodCBkZWZhdWx0LlxuICBjb25zdCB0YXJnZXRVcmwgPSBgaHR0cHM6Ly94LmNvbS8ke2hhbmRsZX0vd2l0aF9yZXBsaWVzYDtcbiAgYXdhaXQgaW5mbygnY2FwdHVyZS1ub3cgcmVxdWVzdGVkJywgeyBoYW5kbGUsIHRhYjogJ3dpdGhfcmVwbGllcycgfSk7XG4gIGlmICghKGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpKSkge1xuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCB7XG4gICAgICBydW5faWQ6IG5ld1J1bklkKCksXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgICAgc3RhcnRlZF9hdDogbm93LFxuICAgICAgbGFzdF9jYXB0dXJlX2F0OiBub3csXG4gICAgICB0d2VldHNfYnlfaWQ6IHt9LFxuICAgICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcbiAgICAgIGVuZHBvaW50c19zZWVuOiBbXSxcbiAgICAgIHNvdXJjZV91cmw6IHRhcmdldFVybCxcbiAgICB9KTtcbiAgfVxuICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsOiB0YXJnZXRVcmwsIGFjdGl2ZTogdHJ1ZSB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2FwdHVyZUFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICBhd2FpdCBpbmZvKCdjYXB0dXJlLWFsbCByZXF1ZXN0ZWQnLCB7IGNvdW50OiBhY2NvdW50cy5sZW5ndGggfSk7XG4gIGZvciAoY29uc3QgYSBvZiBhY2NvdW50cykge1xuICAgIGF3YWl0IGNhcHR1cmVOb3coYS5oYW5kbGUpO1xuICB9XG59XG5cbi8qKlxuICogQ2FwdHVyZSB3aGF0ZXZlciB0aGUgdXNlciBpcyBjdXJyZW50bHkgbG9va2luZyBhdDogZW5zdXJlcyBwYWdlLWhvb2sgaXNcbiAqIHBhdGNoZWQgaW50byB0aGUgYWN0aXZlIHRhYiwgdGhlbiBudWRnZXMgdGhlIHBhZ2Ugd2l0aCBhIHByb2dyYW1tYXRpY1xuICogc2Nyb2xsIHNvIFggZmlyZXMgYW5vdGhlciBiYXRjaCBvZiBHcmFwaFFMIHJlcXVlc3RzIHdlIGNhbiBpbnRlcmNlcHQuXG4gKlxuICogTGVzcyBkaXNydXB0aXZlIHRoYW4gYENhcHR1cmUgbm93YCAobm8gbmV3IHRhYiwgbm8gbmF2aWdhdGlvbikgYW5kIHdvcmtzXG4gKiBmb3IgYXJiaXRyYXJ5IFggVVJMcyAoc3BlY2lmaWMgdHdlZXQgdGhyZWFkcywgc2VhcmNoIHJlc3VsdHMsIGxpc3RzKVxuICogdGhhdCBkb24ndCBtYXAgY2xlYW5seSB0byBvbmUgb2YgdGhlIGNvbmZpZ3VyZWQgaGFuZGxlcy5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gY2FwdHVyZVRoaXNQYWdlKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyBhY3RpdmU6IHRydWUsIGN1cnJlbnRXaW5kb3c6IHRydWUgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBjb3VsZCBub3QgcXVlcnkgYWN0aXZlIHRhYicsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHRhYiA9IHRhYnNbMF07XG4gIGlmICghdGFiIHx8IHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInIHx8ICF0YWIudXJsKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IG5vIGFjdGl2ZSB0YWInKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKCEvXmh0dHBzOlxcL1xcLyh4fHR3aXR0ZXIpXFwuY29tXFwvLy50ZXN0KHRhYi51cmwpKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGFjdGl2ZSB0YWIgaXMgbm90IG9uIHguY29tIC8gdHdpdHRlci5jb20nLCB7XG4gICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCksXG4gICAgfSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtdGhpcy1wYWdlIHJlcXVlc3RlZCcsIHsgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwpIH0pO1xuICAvLyAoUmUtKWluamVjdCB0aGUgcGFnZS1ob29rICsgaXNvbGF0ZWQgY29udGVudCBzY3JpcHQgc28gZmV0Y2gvWEhSIGFyZVxuICAvLyBwYXRjaGVkIGV2ZW4gb24gdGFicyBvcGVuZWQgYmVmb3JlIHRoZSBleHRlbnNpb24gcmVsb2FkZWQuXG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgZmlsZXM6IFsncGFnZS1ob29rLmpzJ10sXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXG4gICAgfSk7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgZmlsZXM6IFsnY29udGVudC5qcyddLFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogcmUtaW5qZWN0IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbiAgLy8gTnVkZ2UgWCB0byBmaXJlIG1vcmUgR3JhcGhRTCByZXF1ZXN0cyBieSBzY3JvbGxpbmcuIE1vc3QgdGltZWxpbmUgL1xuICAvLyBjb252ZXJzYXRpb24gdmlld3MgZmV0Y2ggb24gaW50ZXJzZWN0aW9uLW9ic2VydmVyIHRyaWdnZXJzLlxuICB0cnkge1xuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgIGZ1bmM6ICgpID0+IHtcbiAgICAgICAgY29uc3QgaCA9IHdpbmRvdy5pbm5lckhlaWdodDtcbiAgICAgICAgd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSksIDYwMCk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSksIDEyMDApO1xuICAgICAgfSxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IHNjcm9sbC1udWRnZSBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG59XG5cbi8vIC0tLSBSZWZldGNoIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vL1xuLy8gWCB0cnVuY2F0ZXMgbG9uZyB0d2VldHMgaW4gdGltZWxpbmUgcGF5bG9hZHMgXHUyMDE0IGBub3RlX3R3ZWV0YCBpcyBvbmx5XG4vLyBpbmxpbmVkIGZvciBzb21lIGVuZHBvaW50cy4gUmUtb3BlbmluZyBlYWNoIHRydW5jYXRlZCB0d2VldCdzIGRldGFpbCBwYWdlXG4vLyBjYXVzZXMgdGhlIHBhZ2UtaG9vayB0byBjYXB0dXJlIHRoZSBmdWxsIGBub3RlX3R3ZWV0YCBib2R5LiBUaGUgbG9vcFxuLy8gZHJpdmVzIHRoYXQgYnkgbmF2aWdhdGluZyBhIHNpbmdsZSBkZWRpY2F0ZWQgdGFiIHRocm91Z2ggdGhlIHF1ZXVlLCBvbmVcbi8vIHR3ZWV0IGF0IGEgdGltZSwgZ2F0ZWQgb24gdGhlIHBhZ2UtaG9vayBhY3R1YWxseSBpbmdlc3RpbmcgYSByZXNwb25zZSBmb3Jcbi8vIHRoZSB0d2VldCB3ZSBqdXN0IG5hdmlnYXRlZCB0byAoc28gZGVsZXRlZCAvIHBheXdhbGxlZCAvIDQwNCdkIHR3ZWV0c1xuLy8gZG9uJ3QgbWFrZSB1cyBzcGluIGFuZCBzbyB3ZSBkb24ndCBzbGFtIFggd2l0aCByZWZyZXNoZXMgZmFzdGVyIHRoYW4gdGhlXG4vLyB0YWIgY2FuIGxvYWQpLlxuXG5jb25zdCBSRUZFVENIX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV9yZWZldGNoX3RhYl9pZF9fJztcblxuYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFRhYklkKCk6IFByb21pc2U8bnVtYmVyIHwgbnVsbD4ge1xuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFJFRkVUQ0hfVEFCX0tFWSk7XG4gIGNvbnN0IGlkID0gc3RvcmVkW1JFRkVUQ0hfVEFCX0tFWV07XG4gIHJldHVybiB0eXBlb2YgaWQgPT09ICdudW1iZXInID8gaWQgOiBudWxsO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRSZWZldGNoVGFiSWQoaWQ6IG51bWJlciB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGlkID09PSBudWxsKSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnJlbW92ZShSRUZFVENIX1RBQl9LRVkpO1xuICB9IGVsc2Uge1xuICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbUkVGRVRDSF9UQUJfS0VZXTogaWQgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdG90YWwgPSBhd2FpdCByZWZldGNoUXVldWVUb3RhbCgpO1xuICBpZiAodG90YWwgPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoOiBub3RoaW5nIHF1ZXVlZCcpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3Qgc2Vjb25kcyA9IE1hdGgubWluKFxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYykpXG4gICk7XG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHtcbiAgICB0b3RhbEF0U3RhcnQ6IHRvdGFsLFxuICAgIHByb2Nlc3NlZDogMCxcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBpbmZsaWdodDogbnVsbCxcbiAgfSk7XG4gIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHMpO1xuICB2b2lkIHJlZmV0Y2hUaWNrKCk7XG4gIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBzdGFydGVkJywgeyBxdWV1ZWQ6IHRvdGFsLCBpbnRlcnZhbF9zZWM6IHNlY29uZHMgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmxldCByZWZldGNoSW50ZXJ2YWxIYW5kbGU6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzOiBudW1iZXIpOiB2b2lkIHtcbiAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgY2xlYXJJbnRlcnZhbChyZWZldGNoSW50ZXJ2YWxIYW5kbGUpO1xuICByZWZldGNoSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgdm9pZCByZWZldGNoVGljaygpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybigncmVmZXRjaCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcbn1cblxuZnVuY3Rpb24gc3RvcFJlZmV0Y2hJbnRlcnZhbCgpOiB2b2lkIHtcbiAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcbiAgICByZWZldGNoSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbFJlZmV0Y2hMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdyZWZldGNoLXRpY2snKTsgLy8gbGVnYWN5IGNsZWFudXBcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRSZWZldGNoVGFiSWQoKTtcbiAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24obnVsbCk7XG4gIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBjYW5jZWxsZWQnLCB7XG4gICAgaGFkX3RhYjogdGFiSWQgIT09IG51bGwsXG4gICAgcHJvY2Vzc2VkOiBzZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZmV0Y2hUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgc2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGlmIChzZXNzID09PSBudWxsKSB7XG4gICAgLy8gTG9vcCB3YXMgY2FuY2VsbGVkIG9yIG5ldmVyIHN0YXJ0ZWQ7IG5vdGhpbmcgdG8gZG8uXG4gICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBXYWl0LWZvci1pbmdlc3QgZ3VhcmQ6IGlmIHdlJ3JlIHN0aWxsIGV4cGVjdGluZyBhIGNhcHR1cmUgZm9yIHRoZVxuICAvLyBwcmV2aW91c2x5LW5hdmlnYXRlZCB0YXJnZXQsIG9ubHkgYWR2YW5jZSBvbmNlIHdlJ3ZlIGVpdGhlciBzZWVuIHRoZVxuICAvLyBjYXB0dXJlIChvbkdyYXBocWxDYXB0dXJlIGNsZWFycyBgaW5mbGlnaHRgKSBvciBoaXQgdGhlIHRpbWVvdXQuXG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xuICAgIGlmIChlbGFwc2VkIDwgSU5HRVNUX1dBSVRfTVMpIHtcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBcdTIwMTQgcGFnZS1ob29rIG1heSB5ZXQgY2FwdHVyZSB0aGUgcmVzcG9uc2UuXG4gICAgfVxuICAgIC8vIFRpbWVkIG91dC4gVHJlYXQgYXMgXCJ0aGlzIHRhcmdldCB3b24ndCBpbmdlc3RcIiBhbmQgZHJvcCBpdC5cbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoOiB0YXJnZXQgdGltZWQgb3V0IHdhaXRpbmcgZm9yIGluZ2VzdCcsIHtcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXG4gICAgICB3YWl0ZWRfbXM6IGVsYXBzZWQsXG4gICAgfSk7XG4gICAgLy8gRmluZCB3aGljaCBoYW5kbGUgdGhpcyBpZCBpcyBxdWV1ZWQgdW5kZXIgc28gd2UgY2FuIGRlcXVldWUgaXQuXG4gICAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICAgIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgICAgaWYgKGlkcy5pbmNsdWRlcyhzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpKSB7XG4gICAgICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKGhhbmRsZSwgc2Vzcy5pbmZsaWdodC50d2VldElkKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24oc2Vzcyk7XG4gIH1cblxuICBjb25zdCB0YXJnZXQgPSBhd2FpdCBuZXh0UmVmZXRjaFRhcmdldCgpO1xuICBpZiAoIXRhcmdldCkge1xuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICBhd2FpdCBzZXRSZWZldGNoVGFiSWQobnVsbCk7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24obnVsbCk7XG4gICAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuaGFuZGxlfS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRSZWZldGNoVGFiSWQoKTtcbiAgaWYgKHRhYklkICE9PSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdGFiSWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiBmYWxzZSB9KTtcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkID09PSAnbnVtYmVyJykgYXdhaXQgc2V0UmVmZXRjaFRhYklkKHRhYi5pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy51cGRhdGUodGFiSWQsIHsgdXJsIH0pO1xuICAgIH1cbiAgICBzZXNzID0gKGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCkpID8/IHNlc3M7XG4gICAgc2Vzcy5pbmZsaWdodCA9IHtcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2ggdGljaycsIHtcbiAgICAgIGhhbmRsZTogdGFyZ2V0LmhhbmRsZSxcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIHJlbWFpbmluZzogYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKSxcbiAgICAgIHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQsXG4gICAgICB0b3RhbF9hdF9zdGFydDogc2Vzcy50b3RhbEF0U3RhcnQsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ3JlZmV0Y2ggbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2godGFyZ2V0LmhhbmRsZSwgdGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24oc2Vzcyk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuLy8gLS0tIE1lZGlhLWNyYXdsIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vXG4vLyBNaXJyb3JzIHRoZSByZWZldGNoIGxvb3AgYnV0IHRhcmdldHMgdGhlIG1lZGlhLWNyYXdsIHF1ZXVlOiB0d2VldHMgdGhhdFxuLy8gdGhlIG5vcm1hbGl6ZXIgb2JzZXJ2ZWQgdmlhIHRoZSBNZWRpYSB0YWIgLyBVc2VyTWVkaWEgZW5kcG9pbnQgd2l0aFxuLy8gaW5zdWZmaWNpZW50IGRhdGEgdG8gYnVpbGQgYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gVGhlIGNyYXdsIGxvb3Agd2Fsa3Ncbi8vIGEgZGVkaWNhdGVkIHRhYiB0aHJvdWdoIGVhY2ggdHdlZXQncyBkZXRhaWwgcGFnZSAoaGFuZGxlLWxlc3MgVVJMIGZvcm1cbi8vIHdoZW4gdGhlIGhpbnQtaGFuZGxlIGlzIG1pc3NpbmcpLCBhdCB0aGUgYXV0by1zY3JvbGwgY2FkZW5jZSwgc28gdGhlXG4vLyBwYWdlLWhvb2sgY2FuIGNhcHR1cmUgdGhlIHJlYWwgdHdlZXQgc2hhcGUuXG5cbmNvbnN0IE1FRElBX0NSQVdMX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV9tZWRpYV9jcmF3bF90YWJfaWRfXyc7XG5cbmFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xUYWJJZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChNRURJQV9DUkFXTF9UQUJfS0VZKTtcbiAgY29uc3QgaWQgPSBzdG9yZWRbTUVESUFfQ1JBV0xfVEFCX0tFWV07XG4gIHJldHVybiB0eXBlb2YgaWQgPT09ICdudW1iZXInID8gaWQgOiBudWxsO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsVGFiSWQoaWQ6IG51bWJlciB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGlkID09PSBudWxsKSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKE1FRElBX0NSQVdMX1RBQl9LRVkpO1xuICBlbHNlIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbTUVESUFfQ1JBV0xfVEFCX0tFWV06IGlkIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydE1lZGlhQ3Jhd2xMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCB0b3RhbCA9IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCk7XG4gIGlmICh0b3RhbCA9PT0gMCkge1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsOiBub3RoaW5nIHF1ZXVlZCcpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3Qgc2Vjb25kcyA9IE1hdGgubWluKFxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYykpXG4gICk7XG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHtcbiAgICB0b3RhbEF0U3RhcnQ6IHRvdGFsLFxuICAgIHByb2Nlc3NlZDogMCxcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBpbmZsaWdodDogbnVsbCxcbiAgfSk7XG4gIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHMpO1xuICB2b2lkIG1lZGlhQ3Jhd2xUaWNrKCk7XG4gIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIGxvb3Agc3RhcnRlZCcsIHsgcXVldWVkOiB0b3RhbCwgaW50ZXJ2YWxfc2VjOiBzZWNvbmRzIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5sZXQgbWVkaWFDcmF3bEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gc3RhcnRNZWRpYUNyYXdsSW50ZXJ2YWwoc2Vjb25kczogbnVtYmVyKTogdm9pZCB7XG4gIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwobWVkaWFDcmF3bEludGVydmFsSGFuZGxlKTtcbiAgbWVkaWFDcmF3bEludGVydmFsSGFuZGxlID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgbWVkaWFDcmF3bFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ21lZGlhLWNyYXdsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICB9KTtcbiAgfSwgc2Vjb25kcyAqIDEwMDApO1xufVxuXG5mdW5jdGlvbiBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk6IHZvaWQge1xuICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSB7XG4gICAgY2xlYXJJbnRlcnZhbChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUpO1xuICAgIG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSA9IG51bGw7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsTWVkaWFDcmF3bExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ21lZGlhLWNyYXdsLXRpY2snKTsgLy8gbGVnYWN5IGNsZWFudXBcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRNZWRpYUNyYXdsVGFiSWQoKTtcbiAgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKG51bGwpO1xuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obnVsbCk7XG4gIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIGxvb3AgY2FuY2VsbGVkJywge1xuICAgIGhhZF90YWI6IHRhYklkICE9PSBudWxsLFxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsVGljaygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBpZiAoc2VzcyA9PT0gbnVsbCkge1xuICAgIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHNlc3MuaW5mbGlnaHQgIT09IG51bGwpIHtcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2Uoc2Vzcy5pbmZsaWdodC5uYXZpZ2F0ZWRBdCk7XG4gICAgaWYgKGVsYXBzZWQgPCBJTkdFU1RfV0FJVF9NUykge1xuICAgICAgcmV0dXJuOyAvLyBzdGlsbCB3YWl0aW5nIG9uIHRoZSBwYWdlLWhvb2tcbiAgICB9XG4gICAgYXdhaXQgd2FybignbWVkaWEtY3Jhd2w6IHRhcmdldCB0aW1lZCBvdXQgd2FpdGluZyBmb3IgaW5nZXN0Jywge1xuICAgICAgdHdlZXRfaWQ6IHNlc3MuaW5mbGlnaHQudHdlZXRJZCxcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcbiAgICB9KTtcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bChzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gIH1cblxuICBjb25zdCB0YXJnZXQgPSBhd2FpdCBuZXh0TWVkaWFDcmF3bFRhcmdldCgpO1xuICBpZiAoIXRhcmdldCkge1xuICAgIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQobnVsbCk7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obnVsbCk7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBjb21wbGV0ZScsIHsgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCB9KTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBTa2lwIGlmIGFscmVhZHkgaW4gdGhlIGFyY2hpdmUgXHUyMDE0IHBhcnRpYWwgY2FwdHVyZXMgY2FuIG91dGxpdmUgYVxuICAvLyBzZXBhcmF0ZSBmdWxsIGNhcHR1cmUgcGF0aC5cbiAgaWYgKGF3YWl0IGlzQ29tbWl0dGVkKHRhcmdldC50d2VldElkKSkge1xuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHRhcmdldC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gQWx3YXlzIHVzZSB0aGUgZXhwbGljaXQgaGFuZGxlIFVSTCB3aGVuIHdlIGtub3cgb25lLiBUaGUgaGFuZGxlLWxlc3NcbiAgLy8gYGkvc3RhdHVzLzxpZD5gIGZvcm0gaGFzIHN1cmZhY2VkIGFzIFwidGhpcyBwYWdlIGRvZXNuJ3QgZXhpc3RcIiBpblxuICAvLyBwcmFjdGljZSAoWCdzIHJvdXRlciBkb2Vzbid0IGFsd2F5cyByZXNvbHZlIGl0IGZvciB0d2VldHMgdGhhdCBuZWVkIGFcbiAgLy8gbG9naW4gd2FsbCBvciBoYXZlIGF1dGhvci1jb250ZXh0IHJlZGlyZWN0cykuXG4gIGNvbnN0IHVybCA9XG4gICAgdGFyZ2V0LmJ1Y2tldCA9PT0gJ191bmtub3duJ1xuICAgICAgPyBgaHR0cHM6Ly94LmNvbS9pL3N0YXR1cy8ke3RhcmdldC50d2VldElkfWBcbiAgICAgIDogYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuYnVja2V0fS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRNZWRpYUNyYXdsVGFiSWQoKTtcbiAgaWYgKHRhYklkICE9PSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdGFiSWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiBmYWxzZSB9KTtcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkID09PSAnbnVtYmVyJykgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKHRhYi5pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy51cGRhdGUodGFiSWQsIHsgdXJsIH0pO1xuICAgIH1cbiAgICBzZXNzID0gKGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCkpID8/IHNlc3M7XG4gICAgc2Vzcy5pbmZsaWdodCA9IHtcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIHRpY2snLCB7XG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBoaW50X2hhbmRsZTogdGFyZ2V0LmJ1Y2tldCA9PT0gJ191bmtub3duJyA/IG51bGwgOiB0YXJnZXQuYnVja2V0LFxuICAgICAgcmVtYWluaW5nOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBzZXNzLnRvdGFsQXRTdGFydCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignbWVkaWEtY3Jhd2wgbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuLy8gLS0tIFF1YXJhbnRpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gcXVhcmFudGluZShcbiAgcmVhc29uOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHVybDogc3RyaW5nLFxuICByYXc6IHVua25vd24sXG4gIGVycjogdW5rbm93blxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGxvZ0VycigncXVhcmFudGluaW5nIGNhcHR1cmUnLCB7IHJlYXNvbiwgZW5kcG9pbnQsIHVybCwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykgcmV0dXJuO1xuICBjb25zdCBwYXlsb2FkOiBRdWFyYW50aW5lUGF5bG9hZCA9IHtcbiAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgICByZWFzb24sXG4gICAgZW5kcG9pbnQsXG4gICAgY2FwdHVyZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBzb3VyY2VfdXJsOiB1cmwsXG4gICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICByYXcsXG4gIH07XG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChwYXlsb2FkLmNhcHR1cmVkX2F0KTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IHNoYTgoSlNPTi5zdHJpbmdpZnkocGF5bG9hZCkpO1xuICBjb25zdCBwYXRoID0gYHJhdy9fcXVhcmFudGluZS8ke3RzfS0ke2hhc2h9Lmpzb25gO1xuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGF3YWl0IGNsaWVudC5wdXRGaWxlKHtcbiAgICAgIHBhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShwYXlsb2FkLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICAgIG1lc3NhZ2U6IGBxdWFyYW50aW5lOiAke3JlYXNvbn0gJHtlbmRwb2ludH1gLFxuICAgIH0pO1xuICB9IGNhdGNoIChxZXJyKSB7XG4gICAgYXdhaXQgbG9nRXJyKCdxdWFyYW50aW5lIGNvbW1pdCBmYWlsZWQnLCB7IC4uLmRlc2NyaWJlRXJyb3IocWVycikgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gc2hhOChzOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBidWYgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUocyk7XG4gIGNvbnN0IGRpZ2VzdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgYnVmKTtcbiAgY29uc3QgaGV4ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShkaWdlc3QpKVxuICAgIC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG4gICAgLmpvaW4oJycpO1xuICByZXR1cm4gaGV4LnNsaWNlKDAsIDgpO1xufVxuXG4vLyAtLS0gQ29ubmVjdGlvbiB2ZXJpZmljYXRpb24gJiBhY2NvdW50cyBsaXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIHZlcmlmeUNvbm5lY3Rpb24oZm9yY2U6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHtcbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcbiAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlcnJvcjogbnVsbCxcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbiAgICB9KTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICBpZiAoIWZvcmNlKSB7XG4gICAgLy8gU2tpcCBpZiB3ZSdyZSBpbnNpZGUgdGhlIHJlcG9ydGVkIHJhdGUtbGltaXQgd2luZG93IFx1MjAxNCByZS1jaGVja2luZ1xuICAgIC8vIGJlZm9yZSByZXNldCBqdXN0IHdhc3RlcyBtb3JlIG9mIHRoZSBzYW1lIGV4aGF1c3RlZCBxdW90YSBhbmQga2VlcHNcbiAgICAvLyB0aGUgNDAzcyBjb21pbmcuXG4gICAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcbiAgICAgIGNvbnN0IG5vd1NlYyA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBBcHBseSB0aGUgcGVyaW9kaWMtY2hlY2sgZ2F0ZSB0byBldmVyeSBzdGF0dXMsIG5vdCBqdXN0ICdvaycuIFRoZVxuICAgIC8vIHByZXZpb3VzIGJlaGF2aW9yIHJlLXZlcmlmaWVkIG9uIGV2ZXJ5IHdha2Ugd2hlbmV2ZXIgdGhlIGNvbm5lY3Rpb25cbiAgICAvLyB3YXNuJ3QgJ29rJywgd2hpY2ggZHVyaW5nIGEgcmF0ZS1saW1pdCB3aW5kb3cgbWVhbnQgMiBBUEkgY2FsbHMgcGVyXG4gICAgLy8gU1cgd2FrZSAodmVyaWZ5UmVwb0FjY2VzcyBkb2VzIEdFVCAvdXNlciArIEdFVCAvcmVwb3Mve299L3tyfSkuXG4gICAgaWYgKGNvbm4uY2hlY2tlZEF0KSB7XG4gICAgICBjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShjb25uLmNoZWNrZWRBdCk7XG4gICAgICBpZiAoYWdlIDwgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMpIHJldHVybjtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgICBjb25zdCByID0gYXdhaXQgY2xpZW50LnZlcmlmeVJlcG9BY2Nlc3MoKTtcbiAgICAvLyBQcm9iZSB0aGUgY29uZmlndXJlZCBicmFuY2guIEEgbm9uLWRlZmF1bHQgYnJhbmNoIGlzIGZpbmUgXHUyMDE0IGl0J3NcbiAgICAvLyByb3V0aW5lIHRvIGNhcHR1cmUgaW50byBhIHdvcmtpbmcgYnJhbmNoIFx1MjAxNCBidXQgYSAqbWlzc2luZyogYnJhbmNoXG4gICAgLy8gd291bGQgNDIyIGV2ZXJ5IGNvbW1pdC5cbiAgICBsZXQgYnJhbmNoT2sgPSB0cnVlO1xuICAgIGlmIChzZXR0aW5ncy5icmFuY2ggJiYgc2V0dGluZ3MuYnJhbmNoICE9PSByLmRlZmF1bHRfYnJhbmNoKSB7XG4gICAgICBicmFuY2hPayA9IGF3YWl0IGNsaWVudC5icmFuY2hFeGlzdHMoc2V0dGluZ3MuYnJhbmNoKTtcbiAgICB9XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXM6ICdvaycsXG4gICAgICBsb2dpbjogci5sb2dpbixcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IG51bGwsXG4gICAgICBkZWZhdWx0QnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogYnJhbmNoT2ssXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IGluZm8oJ2Nvbm5lY3Rpb24gdmVyaWZpZWQnLCB7XG4gICAgICBsb2dpbjogci5sb2dpbixcbiAgICAgIHJlcG86IHIuZnVsbF9uYW1lLFxuICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXG4gICAgICBjb25maWd1cmVkX2JyYW5jaDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgY29uZmlndXJlZF9icmFuY2hfZXhpc3RzOiBicmFuY2hPayxcbiAgICB9KTtcbiAgICBpZiAoIWJyYW5jaE9rKSB7XG4gICAgICBhd2FpdCB3YXJuKCdjb25maWd1cmVkIGJyYW5jaCBkb2VzIG5vdCBleGlzdCBvbiByZW1vdGUnLCB7XG4gICAgICAgIGNvbmZpZ3VyZWQ6IHNldHRpbmdzLmJyYW5jaCxcbiAgICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXG4gICAgICAgIGZpeDogJ29wZW4gU2V0dGluZ3MgYW5kIGNoYW5nZSBicmFuY2ggdG8gJyArIHIuZGVmYXVsdF9icmFuY2gsXG4gICAgICB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnN0IGNhdCA9IGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yID8gZXJyLmNhdGVnb3J5IDogJ3Vua25vd24nO1xuICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XG4gICAgICBjYXQgPT09ICdhdXRoJ1xuICAgICAgICA/ICdhdXRoLWVycm9yJ1xuICAgICAgICA6IGNhdCA9PT0gJ3JhdGUtbGltaXQnXG4gICAgICAgICAgPyAncmF0ZS1saW1pdGVkJ1xuICAgICAgICAgIDogY2F0ID09PSAnbmV0d29yaydcbiAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXG4gICAgICAgICAgICA6ICdhdXRoLWVycm9yJztcbiAgICBjb25zdCByZXNldEF0ID1cbiAgICAgIGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGNhdCA9PT0gJ3JhdGUtbGltaXQnID8gZXJyLnJhdGVMaW1pdFJlc2V0QXQgOiBudWxsO1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzLFxuICAgICAgbG9naW46IG51bGwsXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBkZXNjcmliZUVycm9yKGVycikubWVzc2FnZSxcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogcmVzZXRBdCxcbiAgICB9KTtcbiAgICBhd2FpdCB3YXJuKCdjb25uZWN0aW9uIGNoZWNrIGZhaWxlZCcsIHtcbiAgICAgIGNhdGVnb3J5OiBjYXQsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiByZXNldEF0LFxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIH0pO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hBY2NvdW50c0xpc3QoZm9yY2U6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCkge1xuICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIWZvcmNlKSB7XG4gICAgLy8gU2tpcCB3aGlsZSBpbnNpZGUgYSBrbm93biByYXRlLWxpbWl0IHdpbmRvdyBcdTIwMTQgYWNjb3VudHMueWFtbCBpcyBmZXRjaGVkXG4gICAgLy8gdmlhIGF1dGhlbnRpY2F0ZWQgcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSwgd2hpY2ggY291bnRzIGFnYWluc3QgdGhlXG4gICAgLy8gc2FtZSBxdW90YS5cbiAgICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICAgIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcgJiYgY29ubi5yYXRlTGltaXRSZXNldEF0ICE9PSBudWxsKSB7XG4gICAgICBjb25zdCBub3dTZWMgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcbiAgICAgIGlmIChub3dTZWMgPCBjb25uLnJhdGVMaW1pdFJlc2V0QXQpIHJldHVybjtcbiAgICB9XG4gICAgLy8gU2tpcCBpZiB3ZSByZWZyZXNoZWQgcmVjZW50bHkuIGFjY291bnRzLnlhbWwgY2hhbmdlcyByYXJlbHkgXHUyMDE0IHRoZSBvbGRcbiAgICAvLyBjb2RlIHJlLWZldGNoZWQgaXQgb24gZXZlcnkgU1cgd2FrZSwgd2hpY2ggZHVyaW5nIGhlYXZ5IGJyb3dzaW5nIG1lYW50XG4gICAgLy8gYSBHaXRIdWIgY2FsbCBldmVyeSBmZXcgc2Vjb25kcyBldmVuIHdoZW4gbm90aGluZyB3YXMgYmVpbmcgY2FwdHVyZWQuXG4gICAgY29uc3QgbGFzdFJlZnJlc2hlZCA9IGF3YWl0IGdldEFjY291bnRzUmVmcmVzaGVkQXQoKTtcbiAgICBpZiAobGFzdFJlZnJlc2hlZCkge1xuICAgICAgY29uc3QgYWdlID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2UobGFzdFJlZnJlc2hlZCk7XG4gICAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGFnZSkgJiYgYWdlIDwgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMpIHJldHVybjtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgY2xpZW50LmZldGNoUmF3VGV4dCgnY29uZmlnL2FjY291bnRzLnlhbWwnKTtcbiAgICBpZiAoIXRleHQpIHtcbiAgICAgIGlmIChmb3JjZSkgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBub3QgZm91bmQgaW4gcmVwbzsgdXNpbmcgZmFsbGJhY2snKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHNSZWZyZXNoZWRBdChuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBwYXJzZWQgPSBwYXJzZUFjY291bnRzWWFtbCh0ZXh0KTtcbiAgICBpZiAocGFyc2VkLmxlbmd0aCA9PT0gMCkge1xuICAgICAgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBwYXJzZWQgZW1wdHk7IGtlZXBpbmcgZmFsbGJhY2snKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHNSZWZyZXNoZWRBdChuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhd2FpdCBzZXRBY2NvdW50cyhwYXJzZWQpO1xuICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcbiAgICBpZiAoZm9yY2UpIGF3YWl0IGluZm8oJ2FjY291bnRzIGxpc3QgcmVmcmVzaGVkJywgeyBjb3VudDogcGFyc2VkLmxlbmd0aCB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybigncmVmcmVzaCBhY2NvdW50cyBmYWlsZWQ7IGtlZXBpbmcgY3VycmVudCBsaXN0JywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG4vLyAtLS0gU3RhdGUgYnJvYWRjYXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIGJyb2FkY2FzdFN0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzdGF0ZSA9IGF3YWl0IGJ1aWxkU3RhdGUoKTtcbiAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ3N0YXRlLWNoYW5nZWQnLCBzdGF0ZSB9KS5jYXRjaCgoKSA9PiB7fSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGJ1aWxkU3RhdGUoKTogUHJvbWlzZTxFeHRlbnNpb25TdGF0ZT4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgY29uc3QgY291bnRlcnMgPSBhd2FpdCBnZXRDb3VudGVycygpO1xuICBsZXQgdGFiQ291bnQgPSAwO1xuICB0cnkge1xuICAgIGNvbnN0IHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICAgIHRhYkNvdW50ID0gdGFicy5sZW5ndGg7XG4gIH0gY2F0Y2gge1xuICAgIC8vIHRhYnMucXVlcnkgaXMgYWxsb3dlZCBieSB0aGUgbWFuaWZlc3QgYnV0IGNhbiB0cmFuc2llbnRseSBmYWlsXG4gICAgLy8gYXJvdW5kIGV4dGVuc2lvbiBzdGFydHVwOyBzdXJmYWNpbmcgMCBpcyBmaW5lLlxuICB9XG4gIGNvbnN0IHJlZmV0Y2hRdWV1ZWQgPSBhd2FpdCByZWZldGNoUXVldWVUb3RhbCgpO1xuICBjb25zdCBtZWRpYUNyYXdsUXVldWVkID0gYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTtcbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGNvbnN0IGF1dG9TY3JvbGxTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgcmV0dXJuIHtcbiAgICB2ZXJzaW9uOiBFWFRfVkVSU0lPTixcbiAgICBzZXR0aW5nczogcmVkYWN0U2V0dGluZ3Moc2V0dGluZ3MpLFxuICAgIGNvbm5lY3Rpb246IGNvbm4sXG4gICAgYWNjb3VudHMsXG4gICAgY291bnRlcnMsXG4gICAgYXV0b1Njcm9sbDoge1xuICAgICAgYWN0aXZlOiBhdXRvU2Nyb2xsU2VzcyAhPT0gbnVsbCAmJiBhdXRvU2Nyb2xsVGltZXIgIT09IG51bGwsXG4gICAgICB0YWJDb3VudCxcbiAgICAgIHNjcm9sbENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uc2Nyb2xsQ291bnQgPz8gMCxcbiAgICAgIGluZ2VzdGVkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5pbmdlc3RlZENvdW50ID8/IDAsXG4gICAgICBleHBhbmRlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uZXhwYW5kZWRDb3VudCA/PyAwLFxuICAgIH0sXG4gICAgcmVmZXRjaFF1ZXVlOiB7XG4gICAgICB0b3RhbDogcmVmZXRjaFF1ZXVlZCxcbiAgICAgIHJ1bm5pbmc6IHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcbiAgICAgIHByb2Nlc3NlZDogcmVmZXRjaFNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHJlZmV0Y2hTZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcbiAgICB9LFxuICAgIG1lZGlhQ3Jhd2xRdWV1ZToge1xuICAgICAgdG90YWw6IG1lZGlhQ3Jhd2xRdWV1ZWQsXG4gICAgICBydW5uaW5nOiBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwsXG4gICAgICBwcm9jZXNzZWQ6IG1lZGlhQ3Jhd2xTZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBtZWRpYUNyYXdsU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXG4gICAgfSxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcmVkYWN0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBFeHRlbnNpb25TdGF0ZVsnc2V0dGluZ3MnXSB7XG4gIHJldHVybiB7XG4gICAgb3duZXI6IHMub3duZXIsXG4gICAgcmVwbzogcy5yZXBvLFxuICAgIGJyYW5jaDogcy5icmFuY2gsXG4gICAgZW5hYmxlZDogcy5lbmFibGVkLFxuICAgIGF1dG9DYXB0dXJlOiBzLmF1dG9DYXB0dXJlLFxuICAgIGNvbmZpZ3VyZWRBdDogcy5jb25maWd1cmVkQXQsXG4gICAgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyxcbiAgICBwYXRTZXQ6IHMucGF0Lmxlbmd0aCA+IDAsXG4gICAgcGF0U3VmZml4OiBzLnBhdC5sZW5ndGggPj0gNCA/IHMucGF0LnNsaWNlKC00KSA6ICcnLFxuICB9O1xufVxuXG5mdW5jdGlvbiBpc29Db21wYWN0KGlzbzogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gMjAyNS0wNC0xMlQxNDoyMzowMS4wMDBaIFx1MjE5MiAyMDI1LTA0LTEyVDE0MjMwMVpcbiAgY29uc3QgZCA9IG5ldyBEYXRlKGlzbyk7XG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gaXNvLnJlcGxhY2UoL1s6Ll0vZywgJycpO1xuICBjb25zdCBwYWQgPSAobjogbnVtYmVyLCB3ID0gMikgPT4gU3RyaW5nKG4pLnBhZFN0YXJ0KHcsICcwJyk7XG4gIHJldHVybiAoXG4gICAgYCR7ZC5nZXRVVENGdWxsWWVhcigpfS0ke3BhZChkLmdldFVUQ01vbnRoKCkgKyAxKX0tJHtwYWQoZC5nZXRVVENEYXRlKCkpfWAgK1xuICAgIGBUJHtwYWQoZC5nZXRVVENIb3VycygpKX0ke3BhZChkLmdldFVUQ01pbnV0ZXMoKSl9JHtwYWQoZC5nZXRVVENTZWNvbmRzKCkpfVpgXG4gICk7XG59XG5cbmZ1bmN0aW9uIHZpZXdlclVybChzOiBTZXR0aW5ncyk6IHN0cmluZyB7XG4gIHJldHVybiBgaHR0cHM6Ly8ke3Mub3duZXJ9LmdpdGh1Yi5pby8ke3MucmVwb30vYDtcbn1cblxuLyoqXG4gKiBXYWxrIGBub2RlYCBjb2xsZWN0aW5nIGRvdHRlZCBrZXkgcGF0aHMgdXAgdG8gYG1heERlcHRoYCBkZWVwLiBBcnJheVxuICogaW5kaWNlcyBjb2xsYXBzZSB0byBgWzBdYCAod2Ugb25seSBkZXNjZW5kIGludG8gdGhlIGZpcnN0IGVsZW1lbnQpLiBVc2VkXG4gKiB0byBzdXJmYWNlIHRoZSBzdHJ1Y3R1cmFsIHNrZWxldG9uIG9mIGFuIHVuZmFtaWxpYXIgR3JhcGhRTCByZXNwb25zZVxuICogd2l0aG91dCBpbmNsdWRpbmcgYW55IGRhdGEgdmFsdWVzLlxuICovXG4vKiogQ29sbGVjdCBldmVyeSBkaXN0aW5jdCBgX190eXBlbmFtZWAgdmFsdWUgZm91bmQgYW55d2hlcmUgaW4gdGhlIHRyZWUuICovXG5mdW5jdGlvbiBwcm9iZVR5cGVuYW1lcyhub2RlOiB1bmtub3duKTogc3RyaW5nW10ge1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGlmICh0eXBlb2Ygb2JqLl9fdHlwZW5hbWUgPT09ICdzdHJpbmcnKSBzZWVuLmFkZChvYmouX190eXBlbmFtZSk7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gWy4uLnNlZW5dLnNvcnQoKTtcbn1cblxuLyoqXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIGFueXdoZXJlIGluIHRoZSB0cmVlIHdob3NlIGBfX3R5cGVuYW1lYCBtYXRjaGVzIGFuZFxuICogcmV0dXJuIGl0cyB0b3AtbGV2ZWwga2V5IGxpc3QgKHNvcnRlZCkuIFVzZWZ1bCBmb3IgZGlzY292ZXJpbmcgd2hhdCBmaWVsZHNcbiAqIFggaXMgYWN0dWFsbHkgc2hpcHBpbmcgZm9yIGEgZ2l2ZW4gbm9kZSB0eXBlIGFmdGVyIGEgc2NoZW1hIGNoYW5nZS5cbiAqL1xuZnVuY3Rpb24gcHJvYmVGaXJzdFR5cGVTaGFwZShub2RlOiB1bmtub3duLCB0eXBlbmFtZTogc3RyaW5nKTogc3RyaW5nW10gfCBudWxsIHtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSB0eXBlbmFtZSkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMob2JqKS5zb3J0KCk7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLyoqXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIHdpdGggYF9fdHlwZW5hbWUgPT09IHR5cGVuYW1lYCwgdGhlbiBkZXNjZW5kIHRocm91Z2hcbiAqIHRoZSBnaXZlbiBrZXkgcGF0aCwgYW5kIHJldHVybiB0aGUgdG9wLWxldmVsIGtleXMgb2Ygd2hhdGV2ZXIgaXMgYXQgdGhlXG4gKiBlbmQuIFJldHVybnMgYSBtYXJrZXIgc3RyaW5nIHdoZW4gdGhlIHBhdGggbGVhZHMgc29tZXdoZXJlIG5vbi1vYmplY3Qgc29cbiAqIHdlIGNhbiB0ZWxsIGFwYXJ0IFwiYWJzZW50XCIgZnJvbSBcInByZXNlbnQgYnV0IG5vdCBhbiBvYmplY3RcIi5cbiAqL1xuZnVuY3Rpb24gcHJvYmVUeXBlZE5lc3RlZChub2RlOiB1bmtub3duLCB0eXBlbmFtZTogc3RyaW5nLCBwYXRoOiBzdHJpbmdbXSk6IHVua25vd24ge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICBsZXQgZm91bmQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCA9IG51bGw7XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGlmIChvYmouX190eXBlbmFtZSA9PT0gdHlwZW5hbWUpIHtcbiAgICAgICAgZm91bmQgPSBvYmo7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgaWYgKCFmb3VuZCkgcmV0dXJuIG51bGw7XG4gIGxldCBjdXI6IHVua25vd24gPSBmb3VuZDtcbiAgZm9yIChjb25zdCBzZWcgb2YgcGF0aCkge1xuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIHJldHVybiBgPCR7Y3VyID09PSBudWxsID8gJ251bGwnIDogdHlwZW9mIGN1cn0+YDtcbiAgICBjdXIgPSAoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVtzZWddO1xuICB9XG4gIGlmIChjdXIgPT09IHVuZGVmaW5lZCkgcmV0dXJuICc8bWlzc2luZz4nO1xuICBpZiAoY3VyID09PSBudWxsKSByZXR1cm4gJzxudWxsPic7XG4gIGlmICh0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgcmV0dXJuIGA8JHt0eXBlb2YgY3VyfT5gO1xuICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSByZXR1cm4gYDxhcnJheSBsZW49JHtjdXIubGVuZ3RofT5gO1xuICByZXR1cm4gT2JqZWN0LmtleXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5zb3J0KCk7XG59XG5cbmZ1bmN0aW9uIHNob3J0ZW5VcmwodTogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gQWN0aXZpdHktdGFpbCBjb250ZXh0IGlzIG1vcmUgdXNlZnVsIHdpdGgganVzdCB0aGUgcGF0aDsgZnVsbCBVUkxzIGJlY29tZVxuICAvLyBoYXJkIHRvIHJlYWQgYXQgdGhlIHNpZGViYXIncyB3aWR0aC5cbiAgdHJ5IHtcbiAgICBjb25zdCBwYXJzZWQgPSBuZXcgVVJMKHUpO1xuICAgIGNvbnN0IHBhdGggPSBwYXJzZWQucGF0aG5hbWUgKyAocGFyc2VkLnNlYXJjaCA/ICc/XHUyMDI2JyA6ICcnKTtcbiAgICByZXR1cm4gcGFyc2VkLmhvc3QgPT09ICd4LmNvbScgfHwgcGFyc2VkLmhvc3QgPT09ICd0d2l0dGVyLmNvbSdcbiAgICAgID8gcGF0aFxuICAgICAgOiBgJHtwYXJzZWQuaG9zdH0ke3BhdGh9YDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHUubGVuZ3RoID4gODAgPyBgJHt1LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdTtcbiAgfVxufVxuXG4vLyAtLS0gRGV2IGhlbHBlcnMgZXhwb3NlZCBvbiBnbG9iYWxUaGlzIGZvciB0aGUgZGV2dG9vbHMgY29uc29sZSAtLS0tLS0tLS0tXG4vLyAoZS5nLiBgX19pbW1BcmNoaXZlLmNsZWFyQWxsKClgIGluIHRoZSBiYWNrZ3JvdW5kIHdvcmtlcidzIGRldnRvb2xzKS5cblxuKGdsb2JhbFRoaXMgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLl9faW1tQXJjaGl2ZSA9IHtcbiAgY2xlYXJBbGwsXG4gIGFjdGl2aXR5OiBnZXRBY3Rpdml0eSxcbiAgYWNjb3VudHM6IGdldEFjY291bnRzLFxuICBidWZmZXJzOiBnZXRSdW5CdWZmZXJzLFxuICBmbHVzaEFsbDogKCkgPT4gZmx1c2hBbGwoJ2RldnRvb2xzJyksXG4gIHN0YXRlOiBidWlsZFN0YXRlLFxuICByZWZldGNoUXVldWU6IGdldFJlZmV0Y2hRdWV1ZSxcbiAgc3RhcnRSZWZldGNoOiBzdGFydFJlZmV0Y2hMb29wLFxuICBjYW5jZWxSZWZldGNoOiBjYW5jZWxSZWZldGNoTG9vcCxcbiAgbWVkaWFDcmF3bFF1ZXVlOiBnZXRNZWRpYUNyYXdsUXVldWUsXG4gIHN0YXJ0TWVkaWFDcmF3bDogc3RhcnRNZWRpYUNyYXdsTG9vcCxcbiAgY2FuY2VsTWVkaWFDcmF3bDogY2FuY2VsTWVkaWFDcmF3bExvb3AsXG59O1xuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUVPLElBQU0sbUJBQTZCO0FBQUEsRUFDeEMsS0FBSztBQUFBLEVBQ0wsT0FBTztBQUFBLEVBQ1AsTUFBTTtBQUFBO0FBQUE7QUFBQSxFQUdOLFFBQVE7QUFBQSxFQUNSLFNBQVM7QUFBQSxFQUNULGFBQWE7QUFBQSxFQUNiLGNBQWM7QUFBQSxFQUNkLHVCQUF1QjtBQUN6QjtBQUVPLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sc0JBQXNCO0FBSTVCLElBQU0sb0JBQXFDO0FBQUEsRUFDaEQsRUFBRSxRQUFRLFVBQVUsT0FBTyxtQ0FBbUMsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFVBQVUsT0FBTyw0Q0FBNEMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLE9BQU8sT0FBTyxzQ0FBc0MsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw2Q0FBNkMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLGNBQWMsT0FBTyxtQkFBbUIsVUFBVSxPQUFPO0FBQUEsRUFDbkUsRUFBRSxRQUFRLFlBQVksT0FBTywrQkFBK0IsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyxrQ0FBa0MsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw0QkFBNEIsVUFBVSxPQUFPO0FBQUEsRUFDdkUsRUFBRSxRQUFRLG1CQUFtQixPQUFPLHFCQUFxQixVQUFVLE9BQU87QUFDNUU7QUFHTyxJQUFNLGtCQUF1QyxvQkFBSSxJQUFJO0FBQUEsRUFDMUQ7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFXTSxJQUFNLG9CQUF5QyxvQkFBSSxJQUFJLENBQUMsb0JBQW9CLGNBQWMsQ0FBQztBQXVCM0YsSUFBTSx3QkFBd0I7QUFHOUIsSUFBTSxnQkFBZ0I7QUFHdEIsSUFBTSxzQkFBc0I7QUFHNUIsSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLO0FBRWhELElBQU0sbUJBQW1COzs7QUN0RWhDLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sa0JBQWtCO0FBRXhCLElBQUksa0JBQW9DO0FBQ3hDLElBQUksc0JBQXFDO0FBRXpDLFNBQVMsU0FBUyxLQUF5QjtBQUN6QyxNQUFJLElBQUk7QUFDUixhQUFXLEtBQUssSUFBSyxNQUFLLE9BQU8sYUFBYSxDQUFDO0FBQy9DLFNBQU8sS0FBSyxDQUFDO0FBQ2Y7QUFFQSxTQUFTLFdBQVcsR0FBdUI7QUFDekMsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixRQUFNLE1BQU0sSUFBSSxXQUFXLElBQUksTUFBTTtBQUNyQyxXQUFTLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxJQUFLLEtBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDO0FBQzlELFNBQU87QUFDVDtBQUVBLGVBQWUsbUJBQW1FO0FBQ2hGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksZ0JBQWdCO0FBQy9ELFFBQU0sSUFBSSxPQUFPLGdCQUFnQjtBQUNqQyxNQUFJLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxHQUFHO0FBQ3pDLFdBQU8sRUFBRSxTQUFTLEdBQUcsTUFBTSxXQUFXLENBQUMsRUFBRTtBQUFBLEVBQzNDO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsUUFBTSxVQUFVLFNBQVMsSUFBSTtBQUM3QixRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGdCQUFnQixHQUFHLFFBQVEsQ0FBQztBQUMvRCxTQUFPLEVBQUUsU0FBUyxLQUFLO0FBQ3pCO0FBRUEsZUFBZSxZQUFnQztBQUM3QyxRQUFNLEVBQUUsU0FBUyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDakQsTUFBSSxvQkFBb0IsUUFBUSx3QkFBd0IsU0FBUztBQUMvRCxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRTtBQUFBLElBQzdCLEdBQUcsUUFBUSxRQUFRLEVBQUUsSUFBSSxRQUFRLFFBQVEsWUFBWSxFQUFFLE9BQU87QUFBQSxFQUNoRTtBQUNBLFFBQU0sV0FBVyxJQUFJLFdBQVcsS0FBSyxTQUFTLEtBQUssTUFBTTtBQUN6RCxXQUFTLElBQUksTUFBTSxDQUFDO0FBQ3BCLFdBQVMsSUFBSSxNQUFNLEtBQUssTUFBTTtBQUM5QixRQUFNLE9BQU8sTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLFFBQVE7QUFDM0QsUUFBTSxNQUFNLE1BQU0sT0FBTyxPQUFPLFVBQVUsT0FBTyxNQUFNLEVBQUUsTUFBTSxVQUFVLEdBQUcsT0FBTztBQUFBLElBQ2pGO0FBQUEsSUFDQTtBQUFBLEVBQ0YsQ0FBQztBQUNELG9CQUFrQjtBQUNsQix3QkFBc0I7QUFDdEIsU0FBTztBQUNUO0FBRU8sU0FBUyxlQUFlLEdBQW9CO0FBQ2pELFNBQU8sRUFBRSxXQUFXLGVBQWU7QUFDckM7QUFFQSxlQUFzQixXQUFXLFdBQW9DO0FBQ25FLE1BQUksQ0FBQyxVQUFXLFFBQU87QUFDdkIsUUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixRQUFNLEtBQUssT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUNwRCxRQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxJQUM3QixFQUFFLE1BQU0sV0FBVyxHQUFHO0FBQUEsSUFDdEI7QUFBQSxJQUNBLElBQUksWUFBWSxFQUFFLE9BQU8sU0FBUztBQUFBLEVBQ3BDO0FBQ0EsU0FBTyxHQUFHLGVBQWUsR0FBRyxTQUFTLEVBQUUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxXQUFXLEVBQUUsQ0FBQyxDQUFDO0FBQzFFO0FBRUEsZUFBc0IsV0FBVyxVQUFtQztBQUNsRSxNQUFJLENBQUMsU0FBVSxRQUFPO0FBR3RCLE1BQUksQ0FBQyxTQUFTLFdBQVcsZUFBZSxFQUFHLFFBQU87QUFDbEQsUUFBTSxRQUFRLFNBQVMsTUFBTSxnQkFBZ0IsTUFBTSxFQUFFLE1BQU0sR0FBRztBQUM5RCxNQUFJLE1BQU0sV0FBVyxFQUFHLFFBQU87QUFDL0IsUUFBTSxDQUFDLE9BQU8sS0FBSyxJQUFJO0FBQ3ZCLE1BQUksQ0FBQyxTQUFTLENBQUMsTUFBTyxRQUFPO0FBQzdCLE1BQUk7QUFDRixVQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxNQUM3QixFQUFFLE1BQU0sV0FBVyxHQUF1QjtBQUFBLE1BQzFDO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxXQUFPLElBQUksWUFBWSxFQUFFLE9BQU8sRUFBRTtBQUFBLEVBQ3BDLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGOzs7QUM1QkEsSUFBTSxxQkFBc0M7QUFBQSxFQUMxQyxRQUFRO0FBQUEsRUFDUixPQUFPO0FBQUEsRUFDUCxXQUFXO0FBQUEsRUFDWCxPQUFPO0FBQUEsRUFDUCxlQUFlO0FBQUEsRUFDZix3QkFBd0I7QUFBQSxFQUN4QixrQkFBa0I7QUFDcEI7QUFFQSxJQUFNLFdBQXlCO0FBQUEsRUFDN0IsVUFBVSxFQUFFLEdBQUcsaUJBQWlCO0FBQUEsRUFDaEMsVUFBVSxDQUFDLEdBQUcsaUJBQWlCO0FBQUEsRUFDL0IscUJBQXFCO0FBQUEsRUFDckIsWUFBWSxFQUFFLEdBQUcsbUJBQW1CO0FBQUEsRUFDcEMsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLENBQUM7QUFBQSxFQUNiLFVBQVUsQ0FBQztBQUFBLEVBQ1gsZ0JBQWdCLENBQUM7QUFBQSxFQUNqQixjQUFjLENBQUM7QUFBQSxFQUNmLGlCQUFpQixDQUFDO0FBQUEsRUFDbEIsZ0JBQWdCO0FBQUEsRUFDaEIsbUJBQW1CO0FBQUEsRUFDbkIsbUJBQW1CO0FBQ3JCO0FBRUEsZUFBZSxPQUFxQyxLQUFrQztBQUNwRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDbEQsUUFBTSxRQUFRLE9BQU8sR0FBRztBQUN4QixNQUFJLFVBQVUsUUFBVztBQUN2QixXQUFPLGdCQUFnQixTQUFTLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBQ0EsU0FBTztBQUNUO0FBRUEsZUFBZSxPQUFxQyxLQUFRLE9BQXVDO0FBQ2pHLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQztBQUNsRDtBQUlBLGVBQXNCLGNBQWlDO0FBS3JELFFBQU0sU0FBUyxNQUFNLE9BQU8sVUFBVTtBQUN0QyxRQUFNLFNBQVMsRUFBRSxHQUFHLGtCQUFrQixHQUFHLE9BQU87QUFDaEQsTUFBSSxPQUFPLE9BQU8sZUFBZSxPQUFPLEdBQUcsR0FBRztBQUM1QyxRQUFJO0FBQ0YsYUFBTyxNQUFNLE1BQU0sV0FBVyxPQUFPLEdBQUc7QUFBQSxJQUMxQyxRQUFRO0FBQ04sYUFBTyxNQUFNO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixZQUFZLEdBQTRCO0FBRzVELFFBQU0sVUFBb0IsRUFBRSxHQUFHLEVBQUU7QUFDakMsTUFBSSxRQUFRLE9BQU8sQ0FBQyxlQUFlLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFlBQVEsTUFBTSxNQUFNLFdBQVcsUUFBUSxHQUFHO0FBQUEsRUFDNUM7QUFDQSxRQUFNLE9BQU8sWUFBWSxPQUFPO0FBQ2xDO0FBQ0EsZUFBc0IsZUFBZSxPQUE2QztBQUNoRixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEMsUUFBTSxZQUFZLElBQUk7QUFDdEIsU0FBTztBQUNUO0FBSUEsZUFBc0IsY0FBd0M7QUFDNUQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUFZLEdBQW1DO0FBQ25FLFFBQU0sT0FBTyxZQUFZLENBQUM7QUFDNUI7QUFDQSxlQUFzQix5QkFBaUQ7QUFDckUsU0FBTyxPQUFPLHFCQUFxQjtBQUNyQztBQUNBLGVBQXNCLHVCQUF1QixLQUFtQztBQUM5RSxRQUFNLE9BQU8sdUJBQXVCLEdBQUc7QUFDekM7QUFJQSxlQUFzQixnQkFBMEM7QUFDOUQsUUFBTSxJQUFJLE1BQU0sT0FBTyxZQUFZO0FBRW5DLFFBQU0sTUFBdUI7QUFBQSxJQUMzQixHQUFHO0FBQUEsSUFDSCxlQUFlLEVBQUUsa0JBQWtCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDeEQsd0JBQ0UsRUFBRSwyQkFBMkIsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUNwRCxrQkFBa0IsRUFBRSxxQkFBcUIsU0FBWSxPQUFPLEVBQUU7QUFBQSxFQUNoRTtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLGNBQWMsR0FBbUM7QUFDckUsUUFBTSxPQUFPLGNBQWMsQ0FBQztBQUM5QjtBQUlBLFNBQVMsV0FBbUI7QUFDMUIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQzdDO0FBRUEsZUFBc0IsY0FBdUQ7QUFDM0UsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUNwQixRQUNBLE9BQ3lCO0FBQ3pCLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxNQUFNLElBQUksTUFBTSxLQUFLO0FBQUEsSUFDekIsWUFBWTtBQUFBLElBQ1osV0FBVyxTQUFTO0FBQUEsSUFDcEIsZUFBZTtBQUFBLElBQ2YsZ0JBQWdCO0FBQUEsSUFDaEIsZUFBZTtBQUFBLEVBQ2pCO0FBQ0EsTUFBSSxJQUFJLGNBQWMsU0FBUyxHQUFHO0FBQ2hDLFFBQUksWUFBWSxTQUFTO0FBQ3pCLFFBQUksYUFBYTtBQUFBLEVBQ25CO0FBQ0EsUUFBTSxPQUF1QixFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEQsTUFBSSxNQUFNLElBQUk7QUFDZCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGlCQUFpQixRQUFnQixPQUE4QjtBQUNuRixRQUFNLFlBQVksUUFBUSxFQUFFLGVBQWUsTUFBTSxDQUFDO0FBQ3BEO0FBSUEsZUFBc0IsZ0JBQW9EO0FBQ3hFLFNBQU8sT0FBTyxZQUFZO0FBQzVCO0FBRUEsZUFBc0IsYUFBYSxRQUEyQztBQUM1RSxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFNBQU8sSUFBSSxNQUFNLEtBQUs7QUFDeEI7QUFFQSxlQUFzQixhQUFhLFFBQWdCLEtBQStCO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsTUFBSSxNQUFNLElBQUk7QUFDZCxRQUFNLE9BQU8sY0FBYyxHQUFHO0FBQ2hDO0FBRUEsZUFBc0IsZUFBZSxRQUErQjtBQUNsRSxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFNBQU8sSUFBSSxNQUFNO0FBQ2pCLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFJQSxlQUFzQixjQUFtQztBQUN2RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUVBLGVBQXNCLGVBQWUsSUFBbUM7QUFDdEUsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixNQUFJLFFBQVEsRUFBRTtBQUNkLE1BQUksSUFBSSxTQUFTLGtCQUFtQixLQUFJLFNBQVM7QUFDakQsUUFBTSxPQUFPLFlBQVksR0FBRztBQUM1QixTQUFPO0FBQ1Q7QUFFQSxlQUFzQixnQkFBK0I7QUFDbkQsUUFBTSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQzdCO0FBSUEsZUFBc0Isb0JBQTZFO0FBQ2pHLFNBQU8sT0FBTyxnQkFBZ0I7QUFDaEM7QUFFQSxlQUFzQixrQkFDcEIsS0FDZTtBQUNmLFFBQU0sT0FBTyxrQkFBa0IsR0FBRztBQUNwQztBQVVPLFNBQVMsY0FDZCxPQUNBLFVBQ0EsU0FDQSxRQUNBLGNBQXVCLE9BQ2Y7QUFDUixTQUFPLEdBQUcsS0FBSyxJQUFJLFFBQVEsSUFBSSxPQUFPLElBQUksTUFBTSxJQUFJLGNBQWMsTUFBTSxHQUFHO0FBQzdFO0FBR0EsZUFBc0Isb0JBQW9CLFVBQW1DO0FBQzNFLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxRQUFNLFNBQVMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLFFBQVEsRUFBRSxZQUFZO0FBQzNELE1BQUksU0FBUztBQUNiLGFBQVcsVUFBVSxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ3JDLFVBQU0sUUFBUSxJQUFJLE1BQU07QUFDeEIsUUFBSSxDQUFDLE1BQU87QUFDWixlQUFXLE9BQU8sT0FBTyxLQUFLLEtBQUssR0FBRztBQUNwQyxZQUFNLElBQUksTUFBTSxHQUFHO0FBQ25CLFVBQUksS0FBSyxFQUFFLEtBQUssUUFBUTtBQUN0QixlQUFPLE1BQU0sR0FBRztBQUNoQixrQkFBVTtBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLEtBQUssS0FBSyxFQUFFLFdBQVcsRUFBRyxRQUFPLElBQUksTUFBTTtBQUFBLEVBQ3hEO0FBQ0EsTUFBSSxTQUFTLEVBQUcsT0FBTSxrQkFBa0IsR0FBRztBQUMzQyxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixrQkFBcUQ7QUFDekUsU0FBTyxPQUFPLGNBQWM7QUFDOUI7QUFFQSxlQUFzQixvQkFBcUM7QUFDekQsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixlQUFlLFFBQWdCLFNBQWdDO0FBQ25GLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUFBLEVBQ2hDO0FBQ0Y7QUFFQSxlQUFzQixlQUFlLFFBQWdCLFNBQWdDO0FBQ25GLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxRQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLE1BQUksQ0FBQyxJQUFLO0FBQ1YsUUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxNQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUNqQixRQUFNLE9BQU8sZ0JBQWdCLENBQUM7QUFDaEM7QUFFQSxlQUFzQixvQkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLHFCQUF3RDtBQUM1RSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBRUEsZUFBc0IsdUJBQXdDO0FBQzVELFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0Isa0JBQWtCLFlBQTJCLFNBQWdDO0FBQ2pHLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxRQUFNLFNBQVMsY0FBYztBQUM3QixRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUFBLEVBQ25DO0FBQ0Y7QUFFQSxlQUFzQixrQkFBa0IsU0FBZ0M7QUFDdEUsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksVUFBVTtBQUNkLGFBQVcsVUFBVSxPQUFPLEtBQUssQ0FBQyxHQUFHO0FBQ25DLFVBQU0sTUFBTSxFQUFFLE1BQU07QUFDcEIsUUFBSSxDQUFDLElBQUs7QUFDVixVQUFNLFdBQVcsSUFBSSxPQUFPLENBQUMsT0FBTyxPQUFPLE9BQU87QUFDbEQsUUFBSSxTQUFTLFdBQVcsSUFBSSxRQUFRO0FBQ2xDLGdCQUFVO0FBQ1YsVUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLEVBQUUsTUFBTTtBQUFBLFVBQ3JDLEdBQUUsTUFBTSxJQUFJO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxRQUFTLE9BQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUNoRDtBQUVBLGVBQXNCLHVCQUdaO0FBQ1IsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFFBQUksSUFBSSxTQUFTLEVBQUcsUUFBTyxFQUFFLFFBQVEsU0FBUyxJQUFJLENBQUMsRUFBRztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0IsWUFBWSxTQUFtQztBQUNuRSxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsYUFBVyxTQUFTLE9BQU8sT0FBTyxHQUFHLEdBQUc7QUFDdEMsUUFBSSxTQUFTLFdBQVcsTUFBTyxRQUFPO0FBQUEsRUFDeEM7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixvQkFBaUQ7QUFDckUsU0FBTyxPQUFPLGdCQUFnQjtBQUNoQztBQUNBLGVBQXNCLGtCQUFrQixHQUFzQztBQUM1RSxRQUFNLE9BQU8sa0JBQWtCLENBQUM7QUFDbEM7QUFDQSxlQUFzQix1QkFBb0Q7QUFDeEUsU0FBTyxPQUFPLG1CQUFtQjtBQUNuQztBQUNBLGVBQXNCLHFCQUFxQixHQUFzQztBQUMvRSxRQUFNLE9BQU8scUJBQXFCLENBQUM7QUFDckM7QUFDQSxlQUFzQix1QkFBMEQ7QUFDOUUsU0FBTyxPQUFPLG1CQUFtQjtBQUNuQztBQUNBLGVBQXNCLHFCQUFxQixHQUE0QztBQUNyRixRQUFNLE9BQU8scUJBQXFCLENBQUM7QUFDckM7QUFZQSxlQUFzQixvQkFBb0IsVUFNdkM7QUFDRCxRQUFNLFlBQVksSUFBSSxJQUFJLENBQUMsR0FBRyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsQ0FBQztBQUNuRSxRQUFNLGFBQWEsQ0FBQyxNQUF1QixVQUFVLElBQUksRUFBRSxZQUFZLENBQUM7QUFHeEUsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLGtCQUFrQjtBQUN0QixhQUFXLEtBQUssT0FBTyxLQUFLLFFBQVEsR0FBRztBQUNyQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxTQUFTLENBQUM7QUFDakIseUJBQW1CO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLFlBQVksUUFBUTtBQUdqQyxRQUFNLFVBQVUsTUFBTSxjQUFjO0FBQ3BDLE1BQUksaUJBQWlCO0FBQ3JCLGFBQVcsS0FBSyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3BDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLFFBQVEsQ0FBQztBQUNoQix3QkFBa0I7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sY0FBYyxPQUFPO0FBR2xDLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxNQUFJLDBCQUEwQjtBQUM5QixhQUFXLEtBQUssT0FBTyxLQUFLLEdBQUcsR0FBRztBQUNoQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxJQUFJLENBQUM7QUFDWixpQ0FBMkI7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGtCQUFrQixHQUFHO0FBRzNCLFFBQU0sS0FBSyxNQUFNLGdCQUFnQjtBQUNqQyxNQUFJLHdCQUF3QjtBQUM1QixhQUFXLEtBQUssT0FBTyxLQUFLLEVBQUUsR0FBRztBQUMvQixRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxHQUFHLENBQUM7QUFDWCwrQkFBeUI7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sZ0JBQWdCLEVBQUU7QUFLL0IsUUFBTSxLQUFLLE1BQU0sbUJBQW1CO0FBQ3BDLE1BQUksdUJBQXVCO0FBQzNCLGFBQVcsS0FBSyxPQUFPLEtBQUssRUFBRSxHQUFHO0FBQy9CLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQiwrQkFBeUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHO0FBQ3RDLGFBQU8sR0FBRyxDQUFDO0FBQUEsSUFDYjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sbUJBQW1CLEVBQUU7QUFFbEMsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBSUEsZUFBc0IsV0FBMEI7QUFDOUMsUUFBTSxRQUFRLFFBQVEsTUFBTSxNQUFNO0FBQ3BDOzs7QUNwaEJBLElBQUksWUFBNkM7QUFFMUMsU0FBUyxlQUFlLElBQWtDO0FBQy9ELGNBQVk7QUFDZDtBQUVBLFNBQVMsU0FBaUI7QUFDeEIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNoQztBQUVBLGVBQWUsS0FBSyxPQUFpQixLQUFhLFNBQWlEO0FBQ2pHLFFBQU0sS0FBZSxFQUFFLElBQUksT0FBTyxHQUFHLE9BQU8sS0FBSyxTQUFTLE9BQU8sT0FBTyxFQUFFO0FBRTFFLFFBQU0sT0FBTyxpQkFBaUIsTUFBTSxZQUFZLENBQUMsSUFBSSxHQUFHO0FBQ3hELE1BQUksVUFBVSxRQUFTLFNBQVEsTUFBTSxNQUFNLEdBQUcsT0FBTztBQUFBLFdBQzVDLFVBQVUsT0FBUSxTQUFRLEtBQUssTUFBTSxHQUFHLE9BQU87QUFBQSxNQUNuRCxTQUFRLElBQUksTUFBTSxHQUFHLE9BQU87QUFFakMsTUFBSTtBQUNGLFVBQU0sZUFBZSxFQUFFO0FBQUEsRUFDekIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDJDQUEyQyxHQUFHO0FBQUEsRUFDN0Q7QUFFQSxNQUFJO0FBQ0YsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCLFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUFFTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxNQUFNLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN2RixTQUFPLEtBQUssU0FBUyxLQUFLLE9BQU87QUFDbkM7QUFFTyxTQUFTLGNBQWMsS0FBeUQ7QUFDckYsTUFBSSxlQUFlLE9BQU87QUFDeEIsV0FBTyxFQUFFLFNBQVMsSUFBSSxTQUFTLE9BQU8sSUFBSSxTQUFTLEtBQUs7QUFBQSxFQUMxRDtBQUNBLE1BQUk7QUFDRixXQUFPLEVBQUUsU0FBUyxPQUFPLEdBQUcsR0FBRyxPQUFPLEtBQUs7QUFBQSxFQUM3QyxRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsdUJBQXVCLE9BQU8sS0FBSztBQUFBLEVBQ3ZEO0FBQ0Y7QUFPQSxTQUFTLE9BQU8sS0FBdUQ7QUFDckUsUUFBTSxNQUErQixDQUFDO0FBQ3RDLGFBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQ3hDLFFBQUksRUFBRSxZQUFZLEVBQUUsU0FBUyxPQUFPLEtBQUssRUFBRSxZQUFZLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtBQUMzRixVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1gsV0FBVyxPQUFPLE1BQU0sWUFBWSwrQkFBK0IsS0FBSyxDQUFDLEdBQUc7QUFDMUUsVUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLDZCQUE2Qix1QkFBdUI7QUFBQSxJQUN6RSxXQUFXLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxNQUFNO0FBQ25ELFVBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsSUFDOUIsT0FBTztBQUNMLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7OztBQ3ZFQSxJQUFNLFdBQVc7QUFDakIsSUFBTSxXQUFXO0FBK0JWLElBQU0sY0FBTixjQUEwQixNQUFNO0FBQUEsRUFDckM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBO0FBQUEsRUFFQSxZQUFZLE1BT1Q7QUFDRCxVQUFNLEtBQUssT0FBTztBQUNsQixTQUFLLE9BQU87QUFDWixTQUFLLFNBQVMsS0FBSztBQUNuQixTQUFLLE9BQU8sS0FBSztBQUNqQixTQUFLLFlBQVksS0FBSztBQUN0QixTQUFLLFdBQVcsS0FBSztBQUNyQixTQUFLLG1CQUFtQixLQUFLLG9CQUFvQjtBQUFBLEVBQ25EO0FBQ0Y7QUFFTyxJQUFNLGVBQU4sTUFBbUI7QUFBQSxFQUNQO0FBQUEsRUFFakIsWUFBWSxVQUFvQjtBQUM5QixTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBO0FBQUEsRUFHQSxNQUFNLFNBQTBCO0FBQzlCLFVBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDL0MsV0FBUSxJQUEyQixTQUFTO0FBQUEsRUFDOUM7QUFBQTtBQUFBLEVBR0EsTUFBTSxhQUFhLFFBQWtDO0FBQ25ELFFBQUk7QUFDRixZQUFNLEtBQUs7QUFBQSxRQUNUO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxtQkFBbUIsTUFBTSxDQUFDO0FBQUEsTUFDNUY7QUFDQSxhQUFPO0FBQUEsSUFDVCxTQUFTLEtBQUs7QUFDWixVQUFJLGVBQWUsZUFBZSxJQUFJLGFBQWEsWUFBYSxRQUFPO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFHQSxNQUFNLG1CQUEwRjtBQUM5RixVQUFNLEtBQUssTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQzlDLFVBQU0sT0FBTyxNQUFNLEtBQUssVUFBVSxPQUFPLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxFQUFFO0FBQzlGLFVBQU0sSUFBSTtBQUNWLFdBQU87QUFBQSxNQUNMLE9BQVEsR0FBeUI7QUFBQSxNQUNqQyxXQUFXLEVBQUU7QUFBQSxNQUNiLGdCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sYUFBYSxZQUE0QztBQUM3RCxVQUFNLE1BQU0sR0FBRyxRQUFRLElBQUksS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssU0FBUyxNQUFNLElBQUksVUFBVTtBQUMxRyxVQUFNLE1BQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxNQUMzQixRQUFRO0FBQUEsTUFDUixTQUFTLEVBQUUsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFBQSxJQUMxRCxDQUFDO0FBQ0QsUUFBSSxJQUFJLFdBQVcsSUFBSyxRQUFPO0FBQy9CLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxNQUFNLEtBQUssVUFBVSxLQUFLLFdBQVcsVUFBVSxFQUFFO0FBQ3BFLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxXQUFXLE1BQXNDO0FBQ3JELFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsUUFDckI7QUFBQSxRQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDLFFBQVEsbUJBQW1CLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxNQUNsSTtBQUNBLFlBQU0sSUFBSTtBQUNWLGFBQU8sRUFBRSxPQUFPO0FBQUEsSUFDbEIsU0FBUyxLQUFLO0FBQ1osVUFBSSxlQUFlLGVBQWUsSUFBSSxhQUFhLFlBQWEsUUFBTztBQUN2RSxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxNQUFNLFFBQVEsTUFBOEM7QUFDMUQsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxNQUFNLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDO0FBQzVGLFFBQUksTUFBcUIsS0FBSyxlQUFlO0FBQzdDLFVBQU0sY0FBYztBQUVwQixhQUFTLFVBQVUsR0FBRyxXQUFXLGFBQWEsV0FBVztBQUN2RCxZQUFNLE9BQWdDO0FBQUEsUUFDcEMsU0FBUyxLQUFLO0FBQUEsUUFDZCxTQUFTLEtBQUs7QUFBQSxRQUNkLFFBQVEsS0FBSyxTQUFTO0FBQUEsTUFDeEI7QUFDQSxVQUFJLElBQUssTUFBSyxNQUFNO0FBQ3BCLFVBQUk7QUFDRixjQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxLQUFLLElBQUk7QUFDakQsY0FBTSxNQUFNO0FBQ1osZUFBTyxFQUFFLE1BQU0sSUFBSSxRQUFRLE1BQU0sS0FBSyxJQUFJLFFBQVEsS0FBSyxLQUFLLElBQUksUUFBUSxTQUFTO0FBQUEsTUFDbkYsU0FBUyxLQUFLO0FBQ1osWUFBSSxFQUFFLGVBQWUsYUFBYyxPQUFNO0FBQ3pDLFlBQUksSUFBSSxXQUFXLE9BQU8sQ0FBQyxLQUFLO0FBRTlCLGdCQUFNLE1BQU0sS0FBSyxXQUFXLElBQUk7QUFDaEMsY0FBSSxDQUFDLElBQUssT0FBTTtBQUNoQjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLENBQUMsSUFBSSxhQUFhLFlBQVksWUFBYSxPQUFNO0FBQ3JELGNBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxJQUFJLE1BQU0sbUNBQW1DLElBQUksRUFBRTtBQUFBLEVBQzNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBLE1BQU0sWUFBWSxNQUFzRDtBQUN0RSxRQUFJLEtBQUssTUFBTSxXQUFXLEVBQUcsT0FBTSxJQUFJLE1BQU0saUNBQWlDO0FBQzlFLFVBQU0sY0FBYztBQUNwQixRQUFJLFVBQW1CO0FBRXZCLGFBQVMsVUFBVSxHQUFHLFdBQVcsYUFBYSxXQUFXO0FBQ3ZELFVBQUk7QUFDRixjQUFNLFFBQVEsTUFBTSxRQUFRO0FBQUEsVUFDMUIsS0FBSyxNQUFNLElBQUksT0FBTyxTQUFTO0FBQzdCLGtCQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsY0FDckI7QUFBQSxjQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLGNBQ25EO0FBQUEsZ0JBQ0UsU0FBUyxLQUFLO0FBQUEsZ0JBQ2QsVUFBVTtBQUFBLGNBQ1o7QUFBQSxZQUNGO0FBQ0EsbUJBQU87QUFBQSxjQUNMLE1BQU0sS0FBSztBQUFBLGNBQ1gsS0FBTSxJQUF3QjtBQUFBLFlBQ2hDO0FBQUEsVUFDRixDQUFDO0FBQUEsUUFDSDtBQUVBLGNBQU0sT0FBTyxNQUFNLEtBQUssY0FBYztBQUN0QyxjQUFNLE9BQU8sTUFBTSxLQUFLO0FBQUEsVUFDdEI7QUFBQSxVQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLFVBQ25EO0FBQUEsWUFDRSxXQUFXLEtBQUs7QUFBQSxZQUNoQixNQUFNLE1BQU0sSUFBSSxDQUFDLFVBQVU7QUFBQSxjQUN6QixNQUFNLEtBQUs7QUFBQSxjQUNYLE1BQU07QUFBQSxjQUNOLE1BQU07QUFBQSxjQUNOLEtBQUssS0FBSztBQUFBLFlBQ1osRUFBRTtBQUFBLFVBQ0o7QUFBQSxRQUNGO0FBQ0EsY0FBTSxVQUFXLEtBQXlCO0FBQzFDLGNBQU0sU0FBUyxNQUFNLEtBQUs7QUFBQSxVQUN4QjtBQUFBLFVBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsVUFDbkQ7QUFBQSxZQUNFLFNBQVMsS0FBSztBQUFBLFlBQ2QsTUFBTTtBQUFBLFlBQ04sU0FBUyxDQUFDLEtBQUssR0FBRztBQUFBLFVBQ3BCO0FBQUEsUUFDRjtBQUNBLGNBQU0sWUFBWTtBQUNsQixZQUFJO0FBQ0YsZ0JBQU0sS0FBSztBQUFBLFlBQ1Q7QUFBQSxZQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxtQkFBbUIsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsWUFDdEc7QUFBQSxjQUNFLEtBQUssVUFBVTtBQUFBLGNBQ2YsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRixTQUFTLEtBQUs7QUFDWixjQUFJLFdBQVcsR0FBRyxLQUFLLFVBQVUsYUFBYTtBQUM1QyxzQkFBVTtBQUNWLGtCQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUNuQztBQUFBLFVBQ0Y7QUFDQSxnQkFBTTtBQUFBLFFBQ1I7QUFDQSxlQUFPO0FBQUEsVUFDTCxXQUFXLFVBQVU7QUFBQSxVQUNyQixLQUFLLFVBQVU7QUFBQSxVQUNmLE9BQU8sS0FBSyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSTtBQUFBLFFBQzNDO0FBQUEsTUFDRixTQUFTLEtBQUs7QUFDWixrQkFBVTtBQUNWLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFLLENBQUMsSUFBSSxhQUFhLENBQUMsV0FBVyxHQUFHLEtBQU0sWUFBWSxZQUFhLE9BQU07QUFDM0UsY0FBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLG1CQUFtQixRQUFRLFVBQVUsSUFBSSxNQUFNLGlDQUFpQztBQUFBLEVBQ3hGO0FBQUEsRUFFQSxNQUFjLGdCQUEyRDtBQUN2RSxVQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDckI7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxrQkFBa0IsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsSUFDdkc7QUFDQSxVQUFNLFVBQVcsSUFBb0MsT0FBTztBQUM1RCxVQUFNLFNBQVMsTUFBTSxLQUFLO0FBQUEsTUFDeEI7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxnQkFBZ0IsT0FBTztBQUFBLElBQzVFO0FBQ0EsV0FBTztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsU0FBVSxPQUFxQyxLQUFLO0FBQUEsSUFDdEQ7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFjLFVBQVUsUUFBZ0IsTUFBYyxNQUFrQztBQUN0RixVQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU0sSUFBSSxPQUFPLEdBQUcsUUFBUSxHQUFHLElBQUk7QUFDL0QsVUFBTSxPQUFvQjtBQUFBLE1BQ3hCO0FBQUEsTUFDQSxTQUFTO0FBQUEsUUFDUCxlQUFlLFVBQVUsS0FBSyxTQUFTLEdBQUc7QUFBQSxRQUMxQyxRQUFRO0FBQUEsUUFDUix3QkFBd0I7QUFBQSxRQUN4QixHQUFJLE9BQU8sRUFBRSxnQkFBZ0IsbUJBQW1CLElBQUksQ0FBQztBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxHQUFJLE9BQU8sRUFBRSxNQUFNLEtBQUssVUFBVSxJQUFJLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDL0M7QUFDQSxRQUFJO0FBQ0osUUFBSTtBQUNGLFlBQU0sTUFBTSxNQUFNLEtBQUssSUFBSTtBQUFBLElBQzdCLFNBQVMsUUFBUTtBQUNmLFlBQU0sSUFBSSxZQUFZO0FBQUEsUUFDcEIsUUFBUTtBQUFBLFFBQ1IsTUFBTTtBQUFBLFFBQ04sU0FBUyxZQUFZLGNBQWMsTUFBTSxFQUFFLE9BQU87QUFBQSxRQUNsRCxXQUFXO0FBQUEsUUFDWCxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLFNBQWtCO0FBQ3RCLFVBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixRQUFJLE1BQU07QUFDUixVQUFJO0FBQ0YsaUJBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxNQUMxQixRQUFRO0FBQ04saUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxNQUFNLEtBQUssb0JBQW9CLEtBQUssUUFBUSxHQUFHLE1BQU0sSUFBSSxJQUFJLEVBQUU7QUFDbEYsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE1BQWMsVUFBVSxLQUFlLE9BQXFDO0FBQzFFLFFBQUksU0FBa0I7QUFDdEIsUUFBSTtBQUNGLFlBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixVQUFJLEtBQU0sVUFBUyxLQUFLLE1BQU0sSUFBSTtBQUFBLElBQ3BDLFFBQVE7QUFBQSxJQUVSO0FBQ0EsV0FBTyxLQUFLLG9CQUFvQixLQUFLLFFBQVEsS0FBSztBQUFBLEVBQ3BEO0FBQUEsRUFFUSxvQkFBb0IsS0FBZSxNQUFlLE9BQTRCO0FBQ3BGLFVBQU0sTUFDSixPQUFPLFNBQVMsWUFBWSxRQUFRLGFBQWEsT0FDN0MsT0FBUSxLQUE4QixPQUFPLElBQzdDLElBQUk7QUFDVixRQUFJLFdBQW9DO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0FBRTVDLFlBQU0sT0FBTyxJQUFJLFFBQVEsSUFBSSx1QkFBdUI7QUFDcEQsVUFBSSxTQUFTLE9BQU8sY0FBYyxLQUFLLEdBQUcsR0FBRztBQUMzQyxtQkFBVztBQUNYLG9CQUFZO0FBQUEsTUFDZCxPQUFPO0FBQ0wsbUJBQVc7QUFBQSxNQUNiO0FBQUEsSUFDRixXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQUEsSUFDYixXQUFXLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0FBQ25ELGlCQUFXO0FBQUEsSUFDYixXQUFXLElBQUksVUFBVSxLQUFLO0FBQzVCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkLFdBQVcsSUFBSSxXQUFXLEtBQUs7QUFDN0IsaUJBQVc7QUFDWCxrQkFBWTtBQUFBLElBQ2Q7QUFDQSxXQUFPLElBQUksWUFBWTtBQUFBLE1BQ3JCLFFBQVEsSUFBSTtBQUFBLE1BQ1o7QUFBQSxNQUNBLFNBQVMsR0FBRyxLQUFLLFdBQU0sSUFBSSxNQUFNLEtBQUssR0FBRztBQUFBLE1BQ3pDO0FBQUEsTUFDQTtBQUFBLE1BQ0Esa0JBQWtCLGFBQWEsZUFBZSxvQkFBb0IsSUFBSSxPQUFPLElBQUk7QUFBQSxJQUNuRixDQUFDO0FBQUEsRUFDSDtBQUNGO0FBUUEsU0FBUyxvQkFBb0IsU0FBaUM7QUFDNUQsUUFBTSxRQUFRLFFBQVEsSUFBSSxtQkFBbUI7QUFDN0MsTUFBSSxPQUFPO0FBQ1QsVUFBTSxJQUFJLE9BQU8sU0FBUyxPQUFPLEVBQUU7QUFDbkMsUUFBSSxPQUFPLFNBQVMsQ0FBQyxLQUFLLElBQUksRUFBRyxRQUFPO0FBQUEsRUFDMUM7QUFDQSxRQUFNLGFBQWEsUUFBUSxJQUFJLGFBQWE7QUFDNUMsTUFBSSxZQUFZO0FBQ2QsVUFBTSxRQUFRLE9BQU8sU0FBUyxZQUFZLEVBQUU7QUFDNUMsUUFBSSxPQUFPLFNBQVMsS0FBSyxLQUFLLFNBQVMsR0FBRztBQUN4QyxhQUFPLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJLElBQUk7QUFBQSxJQUN6QztBQUNBLFVBQU0sU0FBUyxLQUFLLE1BQU0sVUFBVTtBQUNwQyxRQUFJLE9BQU8sU0FBUyxNQUFNLEVBQUcsUUFBTyxLQUFLLE1BQU0sU0FBUyxHQUFJO0FBQUEsRUFDOUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFdBQVcsTUFBc0I7QUFFeEMsU0FBTyxLQUFLLE1BQU0sR0FBRyxFQUFFLElBQUksa0JBQWtCLEVBQUUsS0FBSyxHQUFHO0FBQ3pEO0FBRUEsU0FBUyxVQUFVLFNBQWlCLEtBQTBCO0FBRTVELFFBQU0sT0FBTyxJQUFJLGFBQWEsZUFBZSxNQUFPO0FBQ3BELFFBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksR0FBRztBQUM3QyxTQUFPLEtBQUssSUFBSSxLQUFRLE9BQU8sTUFBTSxVQUFVLEtBQUssTUFBTTtBQUM1RDtBQUVBLFNBQVMsV0FBVyxLQUFrQztBQUNwRCxTQUFPLGVBQWUsZUFBZSxJQUFJLGFBQWE7QUFDeEQ7QUFFQSxTQUFTLE1BQU0sSUFBMkI7QUFDeEMsU0FBTyxJQUFJLFFBQVEsQ0FBQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUM7QUFDN0M7QUFFTyxTQUFTQSxVQUFTLE9BQXVCO0FBRTlDLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEtBQUs7QUFDM0MsTUFBSSxNQUFNO0FBQ1YsYUFBVyxLQUFLLEtBQU0sUUFBTyxPQUFPLGFBQWEsQ0FBQztBQUNsRCxTQUFPLEtBQUssR0FBRztBQUNqQjs7O0FDOVdBLElBQU0sY0FBYztBQVNwQixJQUFNLHVCQUE0QyxvQkFBSSxJQUFJLENBQUMsV0FBVyxDQUFDO0FBRWhFLFNBQVMsVUFBVSxTQUFrQixLQUF3QztBQUNsRixRQUFNLFlBQVksY0FBYyxPQUFPO0FBQ3ZDLFFBQU0sU0FBMkIsQ0FBQztBQUNsQyxRQUFNLFdBQXFCLENBQUM7QUFDNUIsUUFBTSxRQUFRLG9CQUFJLElBQVk7QUFDOUIsUUFBTSxhQUFhLG9CQUFJLElBQTJCO0FBQ2xELFFBQU0sa0JBQWtCLHFCQUFxQixJQUFJLElBQUksUUFBUTtBQUM3RCxhQUFXLE9BQU8sV0FBVztBQUMzQixRQUFJO0FBQ0YsWUFBTSxJQUFJLFdBQVcsS0FBSyxHQUFHO0FBQzdCLFVBQUksQ0FBQyxHQUFHO0FBQ04sWUFBSSxpQkFBaUI7QUFHbkIsZ0JBQU0sVUFBVSxZQUFZLEdBQUc7QUFDL0IsY0FBSSxRQUFTLFlBQVcsSUFBSSxRQUFRLFVBQVUsUUFBUSxXQUFXO0FBQUEsUUFDbkU7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxlQUFTLEtBQUssRUFBRSxRQUFRO0FBQ3hCLFlBQU0sSUFBSSxFQUFFLFFBQVE7QUFDcEIsVUFBSSxJQUFJLGVBQWUsU0FBUyxLQUFLLElBQUksZUFBZSxJQUFJLEVBQUUsZUFBZSxZQUFZLENBQUMsR0FBRztBQUMzRixlQUFPLEtBQUssQ0FBQztBQUFBLE1BQ2Y7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUVSO0FBQUEsRUFDRjtBQUdBLFFBQU0sY0FBdUUsQ0FBQztBQUM5RSxhQUFXLENBQUMsSUFBSSxJQUFJLEtBQUssWUFBWTtBQUNuQyxRQUFJLE1BQU0sSUFBSSxFQUFFLEVBQUc7QUFDbkIsZ0JBQVksS0FBSyxFQUFFLFVBQVUsSUFBSSxhQUFhLEtBQUssQ0FBQztBQUFBLEVBQ3REO0FBQ0EsU0FBTyxFQUFFLFFBQVEsY0FBYyxVQUFVLFlBQVk7QUFDdkQ7QUFFQSxTQUFTLFlBQVksTUFBd0U7QUFDM0YsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFHVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUc5QyxRQUFNLEtBQUssRUFBRTtBQUNiLE1BQUksT0FBTyxXQUFXLE9BQU8sZ0NBQWdDLENBQUMsSUFBSSxFQUFFLE1BQU0sR0FBRztBQUMzRSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sU0FDSCxPQUFPLEVBQUUsWUFBWSxZQUFZLEVBQUUsV0FDbkMsT0FBTyxJQUFJLEVBQUUsWUFBWSxHQUFHLFdBQVcsWUFDckMsSUFBSSxJQUFJLEVBQUUsWUFBWSxHQUFHLE1BQU0sR0FBRztBQUN2QyxNQUFJLE9BQU8sV0FBVyxZQUFZLENBQUMsWUFBWSxLQUFLLE1BQU0sRUFBRyxRQUFPO0FBQ3BFLFNBQU8sRUFBRSxVQUFVLFFBQVEsYUFBYSxlQUFlLElBQUksRUFBRTtBQUMvRDtBQUVBLFNBQVMsZUFBZSxNQUE4QjtBQUNwRCxNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLFFBQU0sYUFBYSxJQUFJLElBQUksSUFBSSxFQUFFLElBQUksR0FBRyxZQUFZLEdBQUcsTUFBTTtBQUM3RCxTQUNFLFVBQVUsSUFBSSxZQUFZLElBQUksR0FBRyxXQUFXLEtBQzVDLFVBQVUsSUFBSSxZQUFZLE1BQU0sR0FBRyxXQUFXLEtBQzlDLFVBQVUsSUFBSSxFQUFFLE1BQU0sR0FBRyxXQUFXO0FBRXhDO0FBRUEsU0FBUyxjQUFjQyxNQUF5QjtBQUs5QyxRQUFNLE1BQWlCLENBQUM7QUFDeEIsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQ0EsSUFBRztBQUM3QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sT0FBTyxNQUFNLElBQUk7QUFDdkIsUUFBSSxTQUFTLFFBQVEsU0FBUyxPQUFXO0FBQ3pDLFFBQUksT0FBTyxTQUFTLFNBQVU7QUFDOUIsUUFBSSxLQUFLLElBQUksSUFBYyxFQUFHO0FBQzlCLFNBQUssSUFBSSxJQUFjO0FBRXZCLFFBQUksZUFBZSxJQUFJLEdBQUc7QUFDeEIsVUFBSSxLQUFLLFlBQVksSUFBSSxDQUFDO0FBQUEsSUFDNUI7QUFDQSxRQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDdkIsaUJBQVcsS0FBSyxLQUFNLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDcEMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLElBQStCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM5RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGVBQWUsTUFBZ0Q7QUFDdEUsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLFdBQVcsRUFBRTtBQUNuQixNQUNFLGFBQWEsV0FDYixhQUFhLGdDQUNiLGFBQWEsa0JBQ2I7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQU8sT0FBTyxFQUFFLFlBQVksWUFBWSxPQUFPLEVBQUUsV0FBVyxZQUFZLEVBQUUsV0FBVztBQUN2RjtBQUVBLFNBQVMsWUFBWSxNQUF3RDtBQUMzRSxNQUFJLEtBQUssZUFBZSxnQ0FBZ0MsT0FBTyxLQUFLLFVBQVUsVUFBVTtBQUN0RixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLEtBQWMsS0FBOEM7QUFDOUUsTUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLEtBQU0sUUFBTztBQUNwRCxRQUFNLElBQUk7QUFFVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUU5QyxRQUFNLFNBQVMsVUFBVSxFQUFFLE9BQU87QUFLbEMsUUFBTSxTQUFTLElBQUksRUFBRSxNQUFNLEtBQUssQ0FBQztBQUNqQyxNQUFJLENBQUMsT0FBUSxRQUFPO0FBRXBCLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxJQUFJLE1BQU0sWUFBWSxHQUFHLE1BQU07QUFHdEQsUUFBTSxjQUFjLElBQUksWUFBWSxJQUFJO0FBQ3hDLFFBQU0sYUFBYSxJQUFJLFlBQVksTUFBTTtBQUN6QyxRQUFNLGdCQUFnQixJQUFJLFlBQVksTUFBTTtBQUM1QyxRQUFNLFNBQ0osVUFBVSxhQUFhLFdBQVcsS0FDbEMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxPQUFPLFdBQVc7QUFDOUIsUUFBTSxZQUNKLFVBQVUsWUFBWSxPQUFPLEtBQzdCLFVBQVUsWUFBWSxNQUFNLEtBQzVCLFVBQVUsT0FBTyxXQUFXO0FBQzlCLE1BQUksQ0FBQyxVQUFVLENBQUMsVUFBVyxRQUFPO0FBTWxDLFFBQU0sU0FBUyxvQkFBb0IsWUFBWSxhQUFhLFlBQVksYUFBYTtBQUVyRixRQUFNLFlBQVksSUFBSSxJQUFJLElBQUksRUFBRSxVQUFVLEdBQUcsa0JBQWtCLEdBQUcsTUFBTTtBQUN4RSxRQUFNLGVBQWUsVUFBVSxXQUFXLElBQUk7QUFDOUMsUUFBTSxpQkFBaUIsVUFBVSxPQUFPLFNBQVMsS0FBSztBQUN0RCxRQUFNLE9BQU8sZ0JBQWdCO0FBQzdCLFFBQU0sY0FBYyxpQkFBaUIsV0FBVyxRQUFRLGNBQWM7QUFDdEUsUUFBTSxnQkFBZ0IscUJBQXFCLEdBQUcsUUFBUSxJQUFJLFVBQVU7QUFFcEUsUUFBTSxXQUFXLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQztBQUMxQyxRQUFNLG1CQUFtQixJQUFJLFdBQVcsVUFBVTtBQUNsRCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxPQUFPLFlBQVksb0JBQW9CLFFBQVE7QUFDckQsUUFBTSxRQUFRLGFBQWEsTUFBTTtBQUVqQyxRQUFNLFlBQVksa0JBQWtCLEdBQUcsTUFBTTtBQUk3QyxRQUFNLFdBQ0osaUJBQWlCLFVBQVUsT0FBTyxVQUFVLENBQUMsS0FBSyxpQkFBaUIsVUFBVSxFQUFFLFVBQVUsQ0FBQztBQUM1RixNQUFJLENBQUMsU0FBVSxRQUFPO0FBRXRCLFFBQU0sUUFBUSxJQUFJLEVBQUUsS0FBSztBQUN6QixRQUFNLFlBQVksVUFBVSxPQUFPLEtBQUssS0FBSyxVQUFVLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFFOUUsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUMxQixRQUFNLFFBQVEsSUFBSSxPQUFPLEtBQUs7QUFFOUIsUUFBTSxRQUF3QjtBQUFBLElBQzVCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLFdBQVc7QUFBQSxJQUNYLG1CQUFtQixJQUFJO0FBQUEsSUFDdkIsY0FBYyxJQUFJO0FBQUEsSUFDbEIsc0JBQXNCO0FBQUEsSUFDdEIsV0FBVyxHQUFHLGdCQUFnQixJQUFJLE1BQU0sV0FBVyxNQUFNO0FBQUEsSUFDekQsWUFBWTtBQUFBLElBQ1osaUJBQWlCLFVBQVUsT0FBTyxtQkFBbUI7QUFBQSxJQUNyRCxtQkFBbUIsVUFBVSxPQUFPLHlCQUF5QjtBQUFBLElBQzdELGtCQUFrQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDMUQscUJBQXFCLFVBQVUsT0FBTyx1QkFBdUI7QUFBQSxJQUM3RCxpQkFBaUIsVUFBVSxPQUFPLG9CQUFvQjtBQUFBLElBQ3RELG9CQUFvQjtBQUFBLE1BQ2xCLElBQUksSUFBSSxPQUFPLHVCQUF1QixHQUFHLE1BQU0sR0FBRyxXQUMvQyxPQUFtQztBQUFBLElBQ3hDO0FBQUEsSUFDQTtBQUFBLElBQ0EsZUFBZSxpQkFBaUIsTUFBTSxJQUFJO0FBQUEsSUFDMUMsTUFBTSxVQUFVLE9BQU8sSUFBSTtBQUFBLElBQzNCLG9CQUFvQixXQUFXLE9BQU8sa0JBQWtCO0FBQUEsSUFDeEQsUUFBUSxVQUFVLE9BQU8sTUFBTSxLQUFLLFVBQVUsRUFBRSxNQUFNO0FBQUEsSUFDdEQsaUJBQWlCLFVBQVUsT0FBTyxTQUFTO0FBQUEsSUFDM0M7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDM0MsZUFBZSxVQUFVLE9BQU8sYUFBYTtBQUFBLElBQzdDLGFBQWEsVUFBVSxPQUFPLFdBQVc7QUFBQSxJQUN6QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsWUFBWTtBQUFBLElBQ1osZ0JBQWdCLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDL0Msb0JBQW9CO0FBQUEsTUFDbEI7QUFBQSxRQUNFLGFBQWEsSUFBSTtBQUFBLFFBQ2pCLE9BQU8sVUFBVSxPQUFPLGNBQWM7QUFBQSxRQUN0QyxVQUFVLFVBQVUsT0FBTyxhQUFhO0FBQUEsUUFDeEMsU0FBUyxVQUFVLE9BQU8sV0FBVztBQUFBLFFBQ3JDLFFBQVEsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNwQyxPQUFPO0FBQUEsUUFDUCxXQUFXLFVBQVUsT0FBTyxjQUFjO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLElBQ0EsZ0JBQWdCO0FBQUEsSUFDaEIsY0FBYztBQUFBLElBQ2QsYUFBYTtBQUFBLElBQ2Isc0JBQXNCO0FBQUEsSUFDdEIsZ0JBQWdCO0FBQUEsSUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxJQUNwQixnQkFBZ0I7QUFBQSxFQUNsQjtBQUVBLFNBQU87QUFDVDtBQUVBLFNBQVMsa0JBQWtCLEdBQTRCLFFBQTRDO0FBQ2pHLE1BQUksT0FBTywyQkFBMkIsT0FBTyx3QkFBeUIsUUFBTztBQUM3RSxNQUFJLE9BQU8sMEJBQTJCLFFBQU87QUFDN0MsTUFBSSxPQUFPLG9CQUFvQixRQUFRLE9BQU8scUJBQXNCLFFBQU87QUFDM0UsTUFBSSxFQUFFLGVBQWUsOEJBQThCO0FBQUEsRUFFbkQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxVQUFVLElBQUksT0FBUSxFQUF3QixJQUFJLElBQUk7QUFBQSxFQUN0RixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixJQUMzQyxPQUFRLEVBQStCLFdBQVcsSUFDbEQ7QUFBQSxFQUNOLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxZQUFZLFVBQWdEO0FBQ25FLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxRQUFNLE1BQW1CLENBQUM7QUFDMUIsYUFBVyxLQUFLLEtBQUs7QUFDbkIsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU07QUFDekMsVUFBTSxJQUFJO0FBQ1YsVUFBTSxRQUFRLFVBQVUsRUFBRSxHQUFHO0FBQzdCLFVBQU0sV0FBVyxVQUFVLEVBQUUsWUFBWTtBQUN6QyxVQUFNLFVBQVUsVUFBVSxFQUFFLFdBQVc7QUFDdkMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFVO0FBQ3pCLFFBQUksS0FBSyxFQUFFLE9BQU8sVUFBVSxTQUFTLFdBQVcsU0FBUyxDQUFDO0FBQUEsRUFDNUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGFBQWEsUUFBOEM7QUFDbEUsUUFBTSxXQUFXLElBQUksT0FBTyxpQkFBaUI7QUFDN0MsUUFBTSxVQUFVLFdBQVcsUUFBUSxTQUFTLEtBQUssSUFBSSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxRQUFRLElBQUksT0FBTyxRQUFRLEdBQUcsS0FBSztBQUNuRCxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFNBQVMsQ0FBQyxHQUFHLFNBQVMsR0FBRyxPQUFPLEVBQUUsT0FBTyxDQUFDLE1BQU07QUFDcEQsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU0sUUFBTztBQUNoRCxVQUFNLEtBQ0osVUFBVyxFQUE4QixTQUFTLEtBQ2xELFVBQVcsRUFBOEIsTUFBTTtBQUNqRCxRQUFJLENBQUMsR0FBSSxRQUFPO0FBQ2hCLFFBQUksS0FBSyxJQUFJLEVBQUUsRUFBRyxRQUFPO0FBQ3pCLFNBQUssSUFBSSxFQUFFO0FBQ1gsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNELFNBQU8sT0FBTyxJQUFJLENBQUMsUUFBUSxXQUFXLEdBQThCLENBQUM7QUFDdkU7QUFFQSxTQUFTLFdBQVcsR0FBdUM7QUFDekQsUUFBTSxPQUFPLFVBQVUsRUFBRSxJQUFJO0FBQzdCLFFBQU0sV0FBVyxnQkFBZ0IsR0FBRyxJQUFJO0FBQ3hDLFFBQU1DLFFBQU8sSUFBSSxFQUFFLGFBQWE7QUFDaEMsUUFBTSxZQUFZLElBQUksRUFBRSxVQUFVO0FBQ2xDLFFBQU0sYUFBYSxVQUFVLFdBQVcsZUFBZTtBQUN2RCxRQUFNLFVBQVUsVUFBVSxFQUFFLFlBQVk7QUFDeEMsUUFBTSxVQUNKLFVBQVUsRUFBRSxTQUFTLEtBQ3JCLFVBQVUsRUFBRSxNQUFNLEtBQ2xCLEdBQUcsUUFBUSxPQUFPLElBQUksS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDM0QsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsWUFBYSxRQUFRO0FBQUEsSUFDckIsY0FBYyxZQUFZO0FBQUEsSUFDMUIsbUJBQW1CO0FBQUEsSUFDbkIsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsY0FBYyxlQUFlLE9BQU8sYUFBYSxNQUFPO0FBQUEsSUFDeEQsT0FBTyxVQUFVQSxPQUFNLEtBQUs7QUFBQSxJQUM1QixRQUFRLFVBQVVBLE9BQU0sTUFBTTtBQUFBLElBQzlCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLGtCQUFrQjtBQUFBLElBQ2xCLGlCQUFpQjtBQUFBLEVBQ25CO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixHQUE0QixNQUFvQztBQUN2RixNQUFJLFNBQVMsUUFBUyxRQUFPLFVBQVUsRUFBRSxlQUFlLEtBQUssVUFBVSxFQUFFLFNBQVM7QUFDbEYsUUFBTSxXQUFXLFFBQVEsSUFBSSxFQUFFLFVBQVUsR0FBRyxRQUFRO0FBQ3BELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxVQUFVLEVBQUUsZUFBZTtBQUU3RCxNQUFJLE9BQWdEO0FBQ3BELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sS0FBSyxVQUFVLEVBQUUsWUFBWTtBQUNuQyxVQUFNLE1BQU0sVUFBVSxFQUFFLEdBQUc7QUFDM0IsUUFBSSxDQUFDLElBQUs7QUFDVixRQUFJLE9BQU8sYUFBYTtBQUN0QixZQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sS0FBSztBQUNuQyxVQUFJLENBQUMsUUFBUSxLQUFLLEtBQUssUUFBUyxRQUFPLEVBQUUsS0FBSyxTQUFTLEdBQUc7QUFBQSxJQUM1RCxXQUFXLENBQUMsTUFBTTtBQUVoQixhQUFPLEVBQUUsS0FBSyxTQUFTLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLE1BQU0sT0FBTztBQUN0QjtBQUVBLFNBQVMsaUJBQWlCLE1BQWMsTUFBMkI7QUFDakUsTUFBSSxLQUFLLFdBQVcsRUFBRyxRQUFPO0FBQzlCLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLE9BQU0sSUFBSSxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRO0FBQzlELFNBQU87QUFDVDtBQUVBLFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELE1BQUksQ0FBQyxFQUFHLFFBQU87QUFFZixRQUFNLElBQUksSUFBSSxLQUFLLENBQUM7QUFDcEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPO0FBQ3RDLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLFNBQU8sT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLElBQUksSUFBSTtBQUNyRDtBQUNBLFNBQVMsV0FBVyxHQUE0QjtBQUM5QyxTQUFPLE9BQU8sTUFBTSxZQUFZLElBQUk7QUFDdEM7QUFDQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFDeEQsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxVQUFNLElBQUksT0FBTyxDQUFDO0FBQ2xCLFFBQUksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQUEsRUFDakM7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFVBQVUsR0FBb0I7QUFDckMsU0FBTyxVQUFVLENBQUMsS0FBSztBQUN6QjtBQUNBLFNBQVMsSUFBSSxHQUE0QztBQUN2RCxTQUFPLE9BQU8sTUFBTSxZQUFZLE1BQU0sUUFBUSxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQ3pELElBQ0Q7QUFDTjtBQUNBLFNBQVMsUUFBUSxHQUF1QjtBQUN0QyxTQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDO0FBQ2pDO0FBd0JBLFNBQVMsaUJBQ1AsV0FDQSxRQUNBLFVBQ1M7QUFDVCxNQUFJLFVBQVcsUUFBTztBQUN0QixNQUFJLENBQUMsU0FBVSxRQUFPO0FBQ3RCLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUTtBQUNwQyxRQUFNLE9BQU8sV0FBVyxTQUFTLE9BQU87QUFDeEMsTUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGVBQVcsS0FBSyxNQUFNO0FBQ3BCLFVBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFlBQU0sTUFBTyxFQUE4QjtBQUkzQyxVQUFJLE9BQU8sUUFBUSxZQUFZLHdCQUF3QixLQUFLLEdBQUcsR0FBRztBQUNoRSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBa0JPLFNBQVMsY0FDZCxRQUNBLFVBQ2tCO0FBQ2xCLE1BQUksU0FBUyxTQUFTLEVBQUcsUUFBTztBQUtoQyxRQUFNLGdCQUFnQixvQkFBSSxJQUFZO0FBQ3RDLFFBQU0sbUJBQW1CLG9CQUFJLElBQVk7QUFDekMsYUFBVyxLQUFLLFFBQVE7QUFDdEIsUUFBSSxDQUFDLFNBQVMsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEVBQUc7QUFDbkQscUJBQWlCLElBQUksRUFBRSxRQUFRO0FBQy9CLFFBQUksRUFBRSxnQkFBaUIsZUFBYyxJQUFJLEVBQUUsZUFBZTtBQUMxRCxRQUFJLEVBQUUsbUJBQW9CLGVBQWMsSUFBSSxFQUFFLGtCQUFrQjtBQUNoRSxRQUFJLEVBQUUsa0JBQW1CLGVBQWMsSUFBSSxFQUFFLGlCQUFpQjtBQUFBLEVBQ2hFO0FBQ0EsU0FBTyxPQUFPLE9BQU8sQ0FBQyxNQUFNO0FBQzFCLFVBQU0sSUFBSSxFQUFFLGVBQWUsWUFBWTtBQUN2QyxRQUFJLFNBQVMsSUFBSSxDQUFDLEVBQUcsUUFBTztBQUU1QixRQUFJLGNBQWMsSUFBSSxFQUFFLFFBQVEsRUFBRyxRQUFPO0FBRTFDLFFBQUksRUFBRSxtQkFBbUIsaUJBQWlCLElBQUksRUFBRSxlQUFlLEVBQUcsUUFBTztBQUN6RSxRQUFJLEVBQUUsc0JBQXNCLGlCQUFpQixJQUFJLEVBQUUsa0JBQWtCLEVBQUcsUUFBTztBQUMvRSxRQUFJLEVBQUUscUJBQXFCLGlCQUFpQixJQUFJLEVBQUUsaUJBQWlCLEVBQUcsUUFBTztBQUU3RSxRQUFJLEVBQUUsb0JBQW9CLFNBQVMsSUFBSSxFQUFFLGlCQUFpQixZQUFZLENBQUMsRUFBRyxRQUFPO0FBQ2pGLGVBQVcsS0FBSyxFQUFFLFVBQVU7QUFDMUIsVUFBSSxTQUFTLElBQUksRUFBRSxZQUFZLENBQUMsRUFBRyxRQUFPO0FBQUEsSUFDNUM7QUFDQSxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0g7QUFTQSxTQUFTLHFCQUNQLEdBQ0EsUUFDQSxZQUNzQjtBQUN0QixRQUFNLFFBQVEsSUFBSSxFQUFFLGVBQWUsS0FBSyxJQUFJLE9BQU8sZUFBZTtBQUNsRSxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLFFBQU0sV0FBVyxJQUFJLE1BQU0sUUFBUTtBQUNuQyxRQUFNLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDM0IsUUFBTSxVQUFVLFVBQVUsVUFBVSxJQUFJO0FBQ3hDLFFBQU0sUUFBUSxVQUFVLE1BQU0sS0FBSztBQUNuQyxRQUFNLGFBQWEsVUFBVSxNQUFNLFVBQVU7QUFDN0MsUUFBTSxpQkFBaUIsVUFBVSxNQUFNLGNBQWM7QUFDckQsUUFBTSxTQUFTLFVBQVUsTUFBTSxNQUFNLEtBQUssVUFBVSxNQUFNLE9BQU87QUFFakUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBUSxRQUFPO0FBQzFDLFNBQU87QUFBQSxJQUNMLFNBQVM7QUFBQSxJQUNUO0FBQUEsSUFDQSxhQUFhO0FBQUEsSUFDYjtBQUFBLElBQ0EsaUJBQWlCO0FBQUEsSUFDakIsYUFBYTtBQUFBLEVBQ2Y7QUFDRjtBQU9BLFNBQVMsb0JBQ1AsWUFDQSxhQUNBLFlBQ0EsZUFDYztBQUNkLFFBQU0sZUFBZSxJQUFJLFlBQVksWUFBWTtBQUNqRCxTQUFPO0FBQUEsSUFDTCxjQUNFLFVBQVUsYUFBYSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUksS0FBSyxVQUFVLFlBQVksSUFBSTtBQUFBLElBQzNGLFlBQ0UsVUFBVSxlQUFlLFNBQVMsS0FDbEMsVUFBVSxZQUFZLHVCQUF1QixLQUM3QyxVQUFVLFlBQVksdUJBQXVCO0FBQUEsSUFDL0MsVUFBVSxXQUFXLGNBQWMsUUFBUSxLQUFLLFdBQVcsWUFBWSxRQUFRO0FBQUEsSUFDL0Usa0JBQWtCLFdBQVcsWUFBWSxnQkFBZ0I7QUFBQSxJQUN6RCxlQUFlLFVBQVUsY0FBYyxhQUFhLEtBQUssVUFBVSxZQUFZLGFBQWE7QUFBQSxJQUM1RixhQUFhLFVBQVUsWUFBWSxXQUFXO0FBQUEsSUFDOUMsVUFBVSxVQUFVLElBQUksWUFBWSxRQUFRLEdBQUcsUUFBUSxLQUFLLFVBQVUsWUFBWSxRQUFRO0FBQUEsSUFDMUYsS0FBSyxVQUFVLFlBQVksR0FBRztBQUFBLElBQzlCLGlCQUFpQixVQUFVLFlBQVksZUFBZTtBQUFBLElBQ3RELGVBQWUsVUFBVSxZQUFZLGFBQWE7QUFBQSxJQUNsRCxnQkFBZ0IsVUFBVSxZQUFZLGNBQWM7QUFBQSxJQUNwRCxvQkFDRSxpQkFBaUIsVUFBVSxhQUFhLFVBQVUsQ0FBQyxLQUNuRCxpQkFBaUIsVUFBVSxZQUFZLFVBQVUsQ0FBQztBQUFBLElBQ3BELFdBQVcsV0FBVyxZQUFZLFNBQVM7QUFBQSxFQUM3QztBQUNGO0FBT0EsU0FBUyxZQUFZLEdBQThDO0FBQ2pFLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxNQUFNLE1BQU07QUFDbkMsTUFBSSxDQUFDLFdBQVksUUFBTztBQUN4QixRQUFNLFdBQVcsV0FBVztBQUM1QixRQUFNLFFBQWlDLENBQUM7QUFDeEMsTUFBSSxNQUFNLFFBQVEsUUFBUSxHQUFHO0FBQzNCLGVBQVcsTUFBTSxVQUFVO0FBQ3pCLFVBQUksT0FBTyxPQUFPLFlBQVksT0FBTyxLQUFNO0FBQzNDLFlBQU0sSUFBSTtBQUNWLFlBQU0sSUFBSSxVQUFVLEVBQUUsR0FBRztBQUN6QixZQUFNLElBQUksSUFBSSxFQUFFLEtBQUs7QUFDckIsVUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFHO0FBQ2QsWUFBTSxDQUFDLElBQ0wsVUFBVSxFQUFFLFlBQVksS0FDeEIsVUFBVSxJQUFJLEVBQUUsV0FBVyxHQUFHLEdBQUcsS0FDakMsVUFBVSxJQUFJLEVBQUUsaUJBQWlCLEdBQUcsT0FBTztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxVQUFVLFdBQVcsSUFBSTtBQUN0QyxRQUFNLFVBQVUsVUFBVSxXQUFXLEdBQUc7QUFDeEMsUUFBTSxZQUNKLE9BQU8sTUFBTSxZQUFZLE1BQU0sV0FBWSxNQUFNLFlBQVksSUFBZTtBQUM5RSxRQUFNLFFBQVEsT0FBTyxNQUFNLE9BQU8sTUFBTSxXQUFZLE1BQU0sT0FBTyxJQUFlO0FBQ2hGLFFBQU0sY0FDSixPQUFPLE1BQU0sYUFBYSxNQUFNLFdBQVksTUFBTSxhQUFhLElBQWU7QUFDaEYsUUFBTSxZQUNILE9BQU8sTUFBTSxnQ0FBZ0MsTUFBTSxXQUMvQyxNQUFNLGdDQUFnQyxJQUN2QyxVQUNILE9BQU8sTUFBTSwwQkFBMEIsTUFBTSxXQUN6QyxNQUFNLDBCQUEwQixJQUNqQyxVQUNILE9BQU8sTUFBTSw4QkFBOEIsTUFBTSxXQUM3QyxNQUFNLDhCQUE4QixJQUNyQztBQUNOLE1BQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxTQUFVLFFBQU87QUFDekQsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBLFVBQVU7QUFBQSxJQUNWLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsV0FBVztBQUFBLEVBQ2I7QUFDRjs7O0FDNXBCQSxJQUFNLFdBQVc7QUFFVixTQUFTLFdBQW1CO0FBQ2pDLFFBQU0sS0FBSyxLQUFLLElBQUk7QUFDcEIsTUFBSSxTQUFTO0FBQ2IsTUFBSSxJQUFJO0FBQ1IsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7QUFDM0IsY0FBVSxTQUFTLElBQUksRUFBRSxLQUFLLE9BQU87QUFDckMsUUFBSSxLQUFLLE1BQU0sSUFBSSxFQUFFO0FBQUEsRUFDdkI7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxNQUFJLFdBQVc7QUFDZixhQUFXLEtBQUssS0FBTSxhQUFZLFNBQVMsSUFBSSxFQUFFLEtBQUs7QUFDdEQsU0FBTyxTQUFTO0FBQ2xCO0FBRU8sU0FBUyxXQUFXLElBQW9CO0FBQzdDLFNBQU8sR0FBRyxNQUFNLEVBQUU7QUFDcEI7OztBQ1BBLElBQU0sbUJBQWlELG9CQUFJLElBQUk7QUFBQSxFQUM3RDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBRU0sU0FBUyxrQkFBa0IsTUFBK0I7QUFDL0QsUUFBTSxXQUE0QixDQUFDO0FBQ25DLE1BQUksVUFBa0MsQ0FBQztBQUN2QyxNQUFJLGFBQWE7QUFDakIsUUFBTSxRQUFRLE1BQU07QUFDbEIsUUFBSSxRQUFRLFVBQVUsUUFBUSxPQUFPO0FBQ25DLFVBQUksQ0FBQyxRQUFRLFNBQVUsU0FBUSxXQUFXO0FBQzFDLGVBQVMsS0FBSyxPQUF3QjtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNBLGFBQVcsV0FBVyxLQUFLLE1BQU0sSUFBSSxHQUFHO0FBQ3RDLFVBQU0sT0FBTyxjQUFjLE9BQU87QUFDbEMsUUFBSSxLQUFLLEtBQUssTUFBTSxHQUFJO0FBQ3hCLFFBQUksZ0JBQWdCLEtBQUssSUFBSSxHQUFHO0FBQzlCLG1CQUFhO0FBQ2I7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLFdBQVk7QUFFakIsVUFBTSxZQUFZLEtBQUssTUFBTSw0QkFBNEI7QUFDekQsUUFBSSxXQUFXO0FBQ2IsWUFBTTtBQUNOLGdCQUFVLEVBQUUsUUFBUSxRQUFRLFVBQVUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtBQUNoRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGFBQWEsS0FBSyxNQUFNLHdCQUF3QjtBQUN0RCxRQUFJLGNBQWMsQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQ3JDLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxXQUFXLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDakQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx1QkFBdUI7QUFDckQsUUFBSSxjQUFjLFFBQVEsUUFBUTtBQUNoQyxjQUFRLFFBQVEsUUFBUSxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQzNDO0FBQUEsSUFDRjtBQUNBLFVBQU0sZ0JBQWdCLEtBQUssTUFBTSwwQkFBMEI7QUFDM0QsUUFBSSxpQkFBaUIsUUFBUSxRQUFRO0FBQ25DLFlBQU0sTUFBTSxRQUFRLGNBQWMsQ0FBQyxLQUFLLEVBQUU7QUFDMUMsY0FBUSxXQUFXLGlCQUFpQixJQUFJLEdBQXNCLElBQ3pELE1BQ0Q7QUFDSjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTTtBQUNOLFNBQU8sU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sU0FBUyxDQUFDO0FBQ25EO0FBRUEsU0FBUyxjQUFjLE1BQXNCO0FBRzNDLFFBQU0sTUFBTSxLQUFLLFFBQVEsR0FBRztBQUM1QixTQUFPLFFBQVEsS0FBSyxPQUFPLEtBQUssTUFBTSxHQUFHLEdBQUc7QUFDOUM7QUFFQSxTQUFTLFFBQVEsR0FBbUI7QUFDbEMsUUFBTSxVQUFVLEVBQUUsS0FBSztBQUN2QixNQUNHLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsS0FDL0MsUUFBUSxXQUFXLEdBQUcsS0FBSyxRQUFRLFNBQVMsR0FBRyxHQUNoRDtBQUNBLFdBQU8sUUFBUSxNQUFNLEdBQUcsRUFBRTtBQUFBLEVBQzVCO0FBQ0EsU0FBTztBQUNUOzs7QUNOQSxJQUFNLGNBQWMsUUFBUSxRQUFRLFlBQVksRUFBRTtBQUVsRCxlQUFlLENBQUMsT0FBaUI7QUFDL0IsVUFBUSxRQUFRLFlBQVksRUFBRSxNQUFNLGFBQWEsT0FBTyxHQUFHLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDOUUsQ0FBQztBQUlELFFBQVEsUUFBUSxZQUFZLFlBQVksWUFBWTtBQUNsRCxRQUFNLEtBQUssdUJBQXVCLEVBQUUsU0FBUyxZQUFZLENBQUM7QUFDMUQsUUFBTSxPQUFPLFNBQVM7QUFDeEIsQ0FBQztBQUVELFFBQVEsUUFBUSxVQUFVLFlBQVksTUFBTTtBQUMxQyxPQUFLLE9BQU8sU0FBUztBQUN2QixDQUFDO0FBR0QsS0FBSyxPQUFPLGFBQWE7QUFFekIsZUFBZSxPQUFPLFFBQStCO0FBQ25ELE1BQUk7QUFDRixVQUFNLGFBQWE7QUFDbkIsVUFBTSxzQkFBc0I7QUFDNUIsVUFBTSw0QkFBNEI7QUFDbEMsVUFBTSxxQkFBcUI7QUFHM0IsVUFBTSxTQUFTLE1BQU0sb0JBQW9CLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBSTtBQUNqRSxRQUFJLFNBQVMsRUFBRyxPQUFNLEtBQUssMEJBQTBCLEVBQUUsT0FBTyxDQUFDO0FBQy9ELFVBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBSSxTQUFTLE9BQU8sU0FBUyxTQUFTLFNBQVMsTUFBTTtBQUNuRCxZQUFNLGlCQUFpQixLQUFLO0FBQzVCLFlBQU0sb0JBQW9CLEtBQUs7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTSxjQUFjO0FBQUEsUUFDbEIsUUFBUTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWU7QUFBQSxRQUNmLHdCQUF3QjtBQUFBLFFBQ3hCLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFDRCxZQUFNLEtBQUssd0NBQXdDLEVBQUUsT0FBTyxDQUFDO0FBQUEsSUFDL0Q7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sTUFBTyxlQUFlLEVBQUUsUUFBUSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFBQSxFQUMvRDtBQUNGO0FBWUEsZUFBZSx1QkFBc0M7QUFDbkQsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFBQSxFQUN2RixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssNkJBQTZCLGNBQWMsR0FBRyxDQUFDO0FBQzFEO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxPQUFPLElBQUksT0FBTyxTQUFVO0FBQ2hDLFFBQUk7QUFDRixZQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTyxDQUFDLGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl0QixPQUFPO0FBQUEsTUFDVCxDQUFDO0FBQ0QsWUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU8sQ0FBQyxZQUFZO0FBQUEsTUFDdEIsQ0FBQztBQUNELFlBQU0sS0FBSyxxQ0FBcUM7QUFBQSxRQUM5QyxPQUFPLElBQUk7QUFBQSxRQUNYLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRTtBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNILFNBQVMsS0FBSztBQUlaLFlBQU0sS0FBSyx3Q0FBd0M7QUFBQSxRQUNqRCxPQUFPLElBQUk7QUFBQSxRQUNYLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRTtBQUFBLFFBQzdCLEdBQUcsY0FBYyxHQUFHO0FBQUEsTUFDdEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLFFBQU0sUUFBUSxPQUFPLE1BQU0sYUFBYTtBQUN4QyxRQUFNLFFBQVEsT0FBTyxNQUFNLG1CQUFtQjtBQUM5QyxRQUFNLFFBQVEsT0FBTyxPQUFPLGVBQWUsRUFBRSxpQkFBaUIsb0JBQW9CLENBQUM7QUFDbkYsUUFBTSxRQUFRLE9BQU8sT0FBTyxxQkFBcUI7QUFBQSxJQUMvQyxpQkFBaUIsZ0NBQWdDO0FBQUEsRUFDbkQsQ0FBQztBQUNIO0FBTUEsSUFBSSxrQkFBeUQ7QUFLN0QsSUFBTSxpQkFBaUI7QUFFdkIsZUFBZSx3QkFBdUM7QUFFcEQsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsTUFBSSxTQUFTLFFBQVEsRUFBRSxZQUFZLE9BQU87QUFDeEMsdUJBQW1CLEVBQUUscUJBQXFCO0FBQUEsRUFDNUMsT0FBTztBQUNMLHlCQUFxQjtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLHVCQUE2QjtBQUNwQyxNQUFJLG9CQUFvQixNQUFNO0FBQzVCLGtCQUFjLGVBQWU7QUFDN0Isc0JBQWtCO0FBQUEsRUFDcEI7QUFDRjtBQUVBLFNBQVMsbUJBQW1CLGFBQTJCO0FBQ3JELHVCQUFxQjtBQUNyQixRQUFNLFVBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsSUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxXQUFXLENBQUM7QUFBQSxFQUN2RDtBQUNBLG9CQUFrQixZQUFZLE1BQU07QUFDbEMsU0FBSyxlQUFlLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDbkMsV0FBSyxLQUFLLDJCQUEyQixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3pELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsZUFBZSxzQkFBcUM7QUFDbEQsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLHFCQUFxQjtBQUFBLElBQ3pCLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxhQUFhO0FBQUEsSUFDYixlQUFlO0FBQUEsSUFDZixlQUFlO0FBQUEsRUFDakIsQ0FBQztBQUNELHFCQUFtQixFQUFFLHFCQUFxQjtBQUMxQyxRQUFNLEtBQUssNEJBQTRCLEVBQUUsY0FBYyxFQUFFLHNCQUFzQixDQUFDO0FBRWhGLE9BQUssZUFBZTtBQUNwQixRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLHVCQUFzQztBQUNuRCx1QkFBcUI7QUFDckIsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxLQUFLLDhCQUE4QjtBQUFBLElBQ3ZDLFNBQVMsTUFBTSxlQUFlO0FBQUEsSUFDOUIsVUFBVSxNQUFNLGlCQUFpQjtBQUFBLElBQ2pDLFVBQVUsTUFBTSxpQkFBaUI7QUFBQSxFQUNuQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxpQkFBZ0M7QUFDN0MsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFBQSxFQUN2RixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaUNBQWlDLGNBQWMsR0FBRyxDQUFDO0FBQzlEO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksZ0JBQWdCO0FBQ3BCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJLElBQUksVUFBVztBQUNuQixRQUFJO0FBQ0YsWUFBTSxVQUFXLE1BQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNyRCxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJUCxNQUFPLE1BQU07QUFLWCxnQkFBTSxzQkFBc0I7QUFBQSxZQUMxQjtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUNBLGdCQUFNLFVBQVUsb0JBQUksSUFBYTtBQUNqQyxjQUFJLFdBQVc7QUFDZixxQkFBVyxPQUFPLHFCQUFxQjtBQUNyQyx1QkFBVyxNQUFNLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixHQUFHLENBQUMsR0FBRztBQUMzRCxrQkFBSSxRQUFRLElBQUksRUFBRSxFQUFHO0FBRXJCLG9CQUFNLEtBQUssR0FBRyxlQUFlLElBQUksS0FBSyxFQUFFLFlBQVk7QUFDcEQsa0JBQUksTUFBTSxlQUFlLE1BQU0sbUJBQW9CO0FBQ25ELG9CQUFNLE9BQU8sR0FBRyxzQkFBc0I7QUFDdEMsa0JBQUksS0FBSyxVQUFVLEtBQUssS0FBSyxXQUFXLEVBQUc7QUFDM0Msc0JBQVEsSUFBSSxFQUFFO0FBQ2Qsa0JBQUk7QUFDRixnQkFBQyxHQUFtQixNQUFNO0FBQzFCLDRCQUFZO0FBQUEsY0FDZCxRQUFRO0FBQUEsY0FFUjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBSUEsZ0JBQU0sT0FBMEI7QUFBQSxZQUM5QixLQUFLO0FBQUEsWUFDTCxNQUFNO0FBQUEsWUFDTixTQUFTO0FBQUEsWUFDVCxPQUFPO0FBQUEsWUFDUCxTQUFTO0FBQUEsWUFDVCxZQUFZO0FBQUEsVUFDZDtBQUNBLGdCQUFNLFFBQVMsU0FBUyxpQkFBd0MsU0FBUztBQUN6RSxnQkFBTSxjQUFjLElBQUksY0FBYyxXQUFXLElBQUksQ0FBQztBQUN0RCxnQkFBTSxjQUFjLElBQUksY0FBYyxTQUFTLElBQUksQ0FBQztBQUNwRCxpQkFBTyxTQUFTO0FBQUEsWUFDZCxLQUFLLFNBQVMsZ0JBQWdCO0FBQUEsWUFDOUIsVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUNELGlCQUFPLEVBQUUsU0FBUztBQUFBLFFBQ3BCO0FBQUEsTUFDRixDQUFDO0FBQ0QscUJBQWU7QUFDZixZQUFNLElBQUksUUFBUSxDQUFDLEdBQUc7QUFDdEIsVUFBSSxLQUFLLE9BQU8sRUFBRSxhQUFhLFNBQVUsa0JBQWlCLEVBQUU7QUFBQSxJQUM5RCxRQUFRO0FBQUEsSUFHUjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGNBQWMsR0FBRztBQUNuQixVQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBSSxTQUFTLE1BQU07QUFDakIsV0FBSyxlQUFlO0FBQ3BCLFdBQUssaUJBQWlCO0FBQ3RCLFlBQU0scUJBQXFCLElBQUk7QUFBQSxJQUVqQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLFFBQVEsT0FBTyxRQUFRLFlBQVksQ0FBQyxVQUFVO0FBQzVDLE1BQUksTUFBTSxTQUFTLGVBQWU7QUFDaEMsU0FBSyxpQkFBaUI7QUFBQSxFQUN4QixXQUFXLE1BQU0sU0FBUyxxQkFBcUI7QUFDN0MsU0FBSyxpQkFBaUIsS0FBSztBQUFBLEVBQzdCO0FBSUYsQ0FBQztBQUlELElBQUksUUFBUSxRQUFRLFdBQVc7QUFDN0IsVUFBUSxPQUFPLFVBQVUsWUFBWSxZQUFZO0FBQy9DLFFBQUk7QUFDRixZQUFNLFFBQVEsY0FBYyxPQUFPO0FBQUEsSUFDckMsU0FBUyxLQUFLO0FBRVosWUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUN2RSxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFBQSxJQUN4QztBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBSUEsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLEtBQWMsWUFBWTtBQUMvRCxNQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRyxRQUFPO0FBQ25DLFNBQU8sY0FBYyxHQUFHLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDdkMsU0FBSyxNQUFPLDBCQUEwQixFQUFFLE1BQU0sSUFBSSxNQUFNLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUMvRSxVQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0gsQ0FBQztBQUVELFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELFNBQU8sQ0FBQyxDQUFDLEtBQUssT0FBTyxNQUFNLFlBQVksT0FBUSxFQUF5QixTQUFTO0FBQ25GO0FBSUEsSUFBTSw0QkFBNEIsb0JBQUksSUFBNEI7QUFBQSxFQUNoRTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVELGVBQWUsWUFBOEI7QUFDM0MsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixTQUFPLEVBQUUsWUFBWTtBQUN2QjtBQUVBLGVBQWUsY0FBYyxLQUF1QztBQUtsRSxNQUFJLENBQUUsTUFBTSxVQUFVLEtBQU0sMEJBQTBCLElBQUksSUFBSSxJQUFJLEdBQUc7QUFDbkUsV0FBTyxFQUFFLElBQUksTUFBTSxRQUFRLEtBQUs7QUFBQSxFQUNsQztBQUNBLFVBQVEsSUFBSSxNQUFNO0FBQUEsSUFDaEIsS0FBSztBQUNILFlBQU0saUJBQWlCLElBQUksVUFBVSxJQUFJLEtBQUssSUFBSSxRQUFRO0FBQzFELGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxLQUFLLGdDQUFnQyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ3ZFLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxLQUFLLCtCQUErQixFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ3RFLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsVUFBSSxJQUFJLFVBQVUsUUFBUTtBQUN4QixjQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNsRCxXQUFXLElBQUksVUFBVSxTQUFTO0FBQ2hDLGNBQU0sTUFBTyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ3BELE9BQU87QUFDTCxjQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNsRDtBQUNBLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVyxJQUFJLE1BQU07QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVztBQUNqQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxnQkFBZ0I7QUFDdEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sU0FBUyxNQUFNO0FBQ3JCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFlBQVksSUFBSSxRQUFRLE1BQU07QUFDcEMsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLGFBQWEsSUFBSSxHQUFHLENBQUM7QUFDNUMsWUFBTSxLQUFLLHdCQUF3QixFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDakQsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSyxrQkFBa0I7QUFDckIsWUFBTSxJQUFJLE1BQU0sZUFBZSxFQUFFLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbEQsVUFBSSxDQUFDLElBQUksSUFBSTtBQUdYLDZCQUFxQjtBQUNyQiw0QkFBb0I7QUFDcEIsK0JBQXVCO0FBQ3ZCLGNBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxjQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUFBLE1BQy9DLE9BQU87QUFFTCxjQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsWUFBSSxTQUFTLEtBQU0sb0JBQW1CLEVBQUUscUJBQXFCO0FBQUEsTUFDL0Q7QUFDQSxZQUFNLEtBQUssbUNBQW1DLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUM1RCxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0sb0JBQW9CO0FBQzFCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLHFCQUFxQjtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLDRCQUE0QjtBQUMvQixZQUFNLFVBQVUsS0FBSztBQUFBLFFBQ25CO0FBQUEsUUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxJQUFJLE9BQU8sQ0FBQztBQUFBLE1BQ3ZEO0FBQ0EsWUFBTSxlQUFlLEVBQUUsdUJBQXVCLFFBQVEsQ0FBQztBQUV2RCxZQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsVUFBSSxTQUFTLEtBQU0sb0JBQW1CLE9BQU87QUFDN0MsVUFBSSwwQkFBMEIsS0FBTSxzQkFBcUIsT0FBTztBQUNoRSxVQUFJLDZCQUE2QixLQUFNLHlCQUF3QixPQUFPO0FBQ3RFLGFBQU8sV0FBVztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsWUFBTSxpQkFBaUI7QUFDdkIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sa0JBQWtCO0FBQ3hCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLG9CQUFvQjtBQUMxQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxxQkFBcUI7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSyxtQkFBbUI7QUFDdEIsWUFBTSxPQUFPLE1BQU0sWUFBWTtBQUMvQixZQUFNLFVBQVUsSUFBSSxJQUFJLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQy9ELFlBQU0sVUFBVSxNQUFNLG9CQUFvQixPQUFPO0FBQ2pELFlBQU0sS0FBSywwQkFBMEIsT0FBTztBQUM1QyxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0sb0JBQW9CLElBQUk7QUFDOUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0saUJBQWlCLElBQUk7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sY0FBYztBQUNwQixhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUN0QyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSyxlQUFlO0FBQ2xCLFlBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsWUFBTSxNQUFNLFVBQVUsQ0FBQztBQUN2QixZQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQ2pDLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQjtBQUFBLElBQ0E7QUFDRSxhQUFPLEVBQUUsSUFBSSxPQUFPLE9BQU8sdUJBQXVCO0FBQUEsRUFDdEQ7QUFDRjtBQUlBLGVBQWUsaUJBQWlCLFVBQWtCLEtBQWEsVUFBa0M7QUFDL0YsTUFBSSxrQkFBa0IsSUFBSSxRQUFRLEVBQUc7QUFDckMsTUFBSSxDQUFDLGdCQUFnQixJQUFJLFFBQVEsRUFBRztBQUVwQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBZ0JuQyxRQUFNLFVBQVUsSUFBSSxJQUFJLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUUxQyxNQUFJO0FBQ0osTUFBSTtBQUNGLGlCQUFhLFVBQVUsVUFBVTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsZ0JBQWdCLG9CQUFJLElBQVk7QUFBQSxJQUNsQyxDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLFdBQVcsbUJBQW1CLFVBQVUsS0FBSyxVQUFVLEdBQUc7QUFDaEU7QUFBQSxFQUNGO0FBUUEsUUFBTSxlQUFlLFdBQVcsT0FBTztBQUN2QyxhQUFXLFNBQVMsY0FBYyxXQUFXLFFBQVEsT0FBTztBQUM1RCxRQUFNLG1CQUFtQixlQUFlLFdBQVcsT0FBTztBQUMxRCxNQUFJLG1CQUFtQixHQUFHO0FBQ3hCLFVBQU0sS0FBSyw0QkFBNEI7QUFBQSxNQUNyQztBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsTUFBTSxXQUFXLE9BQU87QUFBQSxJQUMxQixDQUFDO0FBQUEsRUFDSDtBQU9BLE1BQUksV0FBVyxhQUFhLFdBQVcsR0FBRztBQUN4QyxVQUFNLEtBQUssNENBQXVDO0FBQUEsTUFDaEQ7QUFBQSxNQUNBLFdBQVcsZUFBZSxRQUFRLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxNQUMvQyxZQUFZLG9CQUFvQixVQUFVLE9BQU87QUFBQSxNQUNqRCxpQkFBaUIsaUJBQWlCLFVBQVUsU0FBUyxDQUFDLE1BQU0sQ0FBQztBQUFBLE1BQzdELG1CQUFtQixpQkFBaUIsVUFBVSxTQUFTLENBQUMsUUFBUSxDQUFDO0FBQUEsTUFDakUsMEJBQTBCLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUM1RDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsTUFDRCwrQkFBK0IsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQ2pFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsTUFDRCxpQ0FBaUMsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQ25FO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSCxPQUFPO0FBQ0wsVUFBTSxLQUFLLHdCQUF3QjtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxVQUFVLFdBQVcsYUFBYTtBQUFBLE1BQ2xDLE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDMUIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxNQUFJLFdBQVcsT0FBTyxXQUFXLEVBQUc7QUFXcEMsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELGFBQVcsS0FBSyxXQUFXLFFBQVE7QUFDakMsUUFBSSxFQUFFLGNBQWM7QUFDbEIsWUFBTSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUTtBQUFBLElBQ25ELE9BQU87QUFDTCxZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRO0FBQUEsSUFDbkQ7QUFHQSxVQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsUUFBSSxhQUFhLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDakQsa0JBQVksV0FBVztBQUN2QixrQkFBWSxhQUFhO0FBQ3pCLFlBQU0sa0JBQWtCLFdBQVc7QUFBQSxJQUNyQztBQUNBLFFBQUksZ0JBQWdCLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDcEQscUJBQWUsV0FBVztBQUMxQixxQkFBZSxhQUFhO0FBQzVCLFlBQU0scUJBQXFCLGNBQWM7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFLQSxhQUFXLFdBQVcsV0FBVyxhQUFhO0FBQzVDLFFBQUksTUFBTSxZQUFZLFFBQVEsUUFBUSxFQUFHO0FBQ3pDLFVBQU0sa0JBQWtCLFFBQVEsYUFBYSxRQUFRLFFBQVE7QUFBQSxFQUMvRDtBQUNBLE1BQUksV0FBVyxZQUFZLFNBQVMsR0FBRztBQUNyQyxVQUFNLEtBQUssMENBQTBDO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLFNBQVMsV0FBVyxZQUFZO0FBQUEsTUFDaEMsYUFBYSxNQUFNLHFCQUFxQjtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNIO0FBUUEsUUFBTSxlQUFlLE1BQU0sa0JBQWtCO0FBQzdDLE1BQUksaUJBQWlCO0FBQ3JCLFFBQU0sYUFBdUMsQ0FBQztBQUM5QyxhQUFXLEtBQUssV0FBVyxRQUFRO0FBQ2pDLFVBQU0sT0FBTyxhQUFhLEVBQUUsY0FBYyxJQUFJLEVBQUUsUUFBUTtBQUN4RCxVQUFNLE1BQU07QUFBQSxNQUNWLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxJQUNKO0FBQ0EsUUFBSSxRQUFRLEtBQUssUUFBUSxLQUFLO0FBQzVCLHdCQUFrQjtBQUNsQjtBQUFBLElBQ0Y7QUFDQSxlQUFXLEtBQUssQ0FBQztBQUFBLEVBQ25CO0FBQ0EsTUFBSSxpQkFBaUIsR0FBRztBQUN0QixVQUFNLEtBQUssbUNBQW1DO0FBQUEsTUFDNUM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSxXQUFXLFdBQVcsRUFBRztBQUc3QixRQUFNLFdBQVcsb0JBQUksSUFBOEI7QUFDbkQsYUFBVyxLQUFLLFlBQVk7QUFDMUIsVUFBTSxNQUFNLFNBQVMsSUFBSSxFQUFFLGNBQWMsS0FBSyxDQUFDO0FBQy9DLFFBQUksS0FBSyxDQUFDO0FBQ1YsYUFBUyxJQUFJLEVBQUUsZ0JBQWdCLEdBQUc7QUFBQSxFQUNwQztBQUVBLGFBQVcsQ0FBQyxRQUFRLE1BQU0sS0FBSyxVQUFVO0FBQ3ZDLFVBQU0sTUFBTSxNQUFNLGdCQUFnQixRQUFRLFlBQVksS0FBSyxRQUFRO0FBQ25FLFFBQUksUUFBUTtBQUNaLGVBQVcsS0FBSyxRQUFRO0FBQ3RCLFlBQU0sV0FBVyxJQUFJLGFBQWEsRUFBRSxRQUFRO0FBQzVDLFVBQUksVUFBVTtBQUdaLGlCQUFTLGVBQWU7QUFDeEIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGdCQUFnQixFQUFFO0FBQzNCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxjQUFjLEVBQUU7QUFDekIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGlCQUFpQixFQUFFO0FBQzVCLGNBQU0sT0FBTyxTQUFTLG1CQUFtQixTQUFTLG1CQUFtQixTQUFTLENBQUM7QUFDL0UsY0FBTSxPQUFPLEVBQUUsbUJBQW1CLENBQUM7QUFDbkMsWUFBSSxTQUFTLENBQUMsUUFBUSxLQUFLLGdCQUFnQixLQUFLLGNBQWM7QUFDNUQsbUJBQVMsbUJBQW1CLEtBQUssSUFBSTtBQUFBLFFBQ3ZDO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxVQUEwQixFQUFFLEdBQUcsR0FBRyxnQkFBZ0IsSUFBSSxPQUFPO0FBQ25FLFlBQUksYUFBYSxFQUFFLFFBQVEsSUFBSTtBQUMvQixpQkFBUztBQUFBLE1BQ1g7QUFDQSxVQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsR0FBRztBQUNoRCxZQUFJLG1CQUFtQixLQUFLLEVBQUUsUUFBUTtBQUFBLE1BQ3hDO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLE1BQU07QUFDbkUsUUFBSSxRQUFRLEdBQUc7QUFDYixZQUFNLEtBQUssbUJBQW1CO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsT0FBTyxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUU7QUFBQSxNQUN2QyxDQUFDO0FBR0QsWUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8saUJBQWlCO0FBQ3hCLGNBQU0scUJBQXFCLE1BQU07QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRSxVQUFVLHVCQUF1QjtBQUNqRSxZQUFNLFlBQVksUUFBUSxXQUFXO0FBQUEsSUFDdkM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxnQkFDYixRQUNBLElBQ0EsV0FDQSxVQUNvQjtBQUNwQixRQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFDckMsTUFBSSxJQUFLLFFBQU87QUFDaEIsUUFBTSxNQUFpQjtBQUFBLElBQ3JCLFFBQVEsU0FBUztBQUFBLElBQ2pCLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLGlCQUFpQjtBQUFBLElBQ2pCLGNBQWMsQ0FBQztBQUFBLElBQ2Ysb0JBQW9CLENBQUM7QUFBQSxJQUNyQixnQkFBZ0IsQ0FBQyxRQUFRO0FBQUEsSUFDekIsWUFBWTtBQUFBLEVBQ2Q7QUFDQSxRQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFFBQU0sS0FBSyxlQUFlLEVBQUUsUUFBUSxLQUFLLFdBQVcsSUFBSSxNQUFNLEVBQUUsQ0FBQztBQUNqRSxTQUFPO0FBQ1Q7QUFJQSxJQUFJLGFBQTRCLFFBQVEsUUFBUTtBQWNoRCxlQUFlLG1CQUFrQztBQUMvQyxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsUUFBTSxVQUFvQixDQUFDO0FBQzNCLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFVBQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxlQUFlO0FBQzNDLFFBQUksT0FBTyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsZUFBZTtBQUN4RCxjQUFRLEtBQUssTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sYUFBYSxTQUFTLE1BQU07QUFDcEM7QUFFQSxlQUFlLDhCQUE2QztBQU8xRCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLEtBQU07QUFDeEQsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLFFBQU0sVUFBb0IsQ0FBQztBQUMzQixhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUMvQyxVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksZUFBZTtBQUMzQyxRQUFJLE9BQU8sU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLGVBQWU7QUFDeEQsY0FBUSxLQUFLLE1BQU07QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsU0FBUyxNQUFNO0FBQ3BDO0FBRUEsZUFBZSxTQUFTLFFBQStCO0FBQ3JELFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxhQUFhLE9BQU8sS0FBSyxHQUFHLEdBQUcsTUFBTTtBQUM3QztBQUVBLGVBQWUsWUFBWSxRQUFnQixRQUErQjtBQUN4RSxRQUFNLGFBQWEsQ0FBQyxNQUFNLEdBQUcsTUFBTTtBQUNyQztBQUVBLGVBQWUsYUFBYSxTQUFtQixRQUErQjtBQUM1RSxRQUFNLFNBQVMsQ0FBQyxHQUFHLElBQUksSUFBSSxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQztBQUMvRCxNQUFJLE9BQU8sV0FBVyxFQUFHO0FBQ3pCLFFBQU0sTUFBTSxXQUFXLEtBQUssTUFBTSxtQkFBbUIsUUFBUSxNQUFNLENBQUM7QUFDcEUsZUFBYSxJQUFJLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUMvQixTQUFPO0FBQ1Q7QUFFQSxlQUFlLG1CQUFtQixTQUFtQixRQUErQjtBQUNsRixRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sUUFBcUIsQ0FBQztBQUM1QixhQUFXLFVBQVUsU0FBUztBQUM1QixVQUFNLE1BQU0sSUFBSSxNQUFNO0FBQ3RCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsVUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJLFlBQVk7QUFDN0MsUUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QixZQUFNLGVBQWUsTUFBTTtBQUMzQixZQUFNLGlCQUFpQixRQUFRLENBQUM7QUFDaEM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLGVBQWUsUUFBUSxLQUFLLE1BQU0sQ0FBQztBQUFBLEVBQ2hEO0FBQ0EsTUFBSSxNQUFNLFdBQVcsRUFBRztBQUV4QixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLE1BQU07QUFDdEQsVUFBTSxLQUFLLHVDQUF1QztBQUFBLE1BQ2hELE9BQU8sTUFBTTtBQUFBLE1BQ2IsU0FBUyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsSUFDdkQsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxRQUFNLFFBQVEsTUFBTSxRQUFRLENBQUMsU0FBUztBQUFBLElBQ3BDO0FBQUEsTUFDRSxNQUFNLEtBQUs7QUFBQSxNQUNYLGVBQWVDLFVBQVMsS0FBSyxVQUFVLEtBQUssU0FBUyxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsSUFDdEU7QUFBQSxJQUNBO0FBQUEsTUFDRSxNQUFNLEtBQUs7QUFBQSxNQUNYLGVBQWVBLFVBQVMsS0FBSyxVQUFVLEtBQUssTUFBTSxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsSUFDbkU7QUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNLFlBQVksd0JBQXdCLEtBQUs7QUFFL0MsTUFBSTtBQUNGLFVBQU0sU0FBUyxNQUFNLE9BQU8sWUFBWTtBQUFBLE1BQ3RDO0FBQUEsTUFDQSxTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQ0QsVUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLGVBQVcsUUFBUSxPQUFPO0FBQ3hCLFlBQU0saUJBQWlCLE1BQU0sK0JBQStCLElBQUk7QUFLaEUsWUFBTSxRQUFRLE1BQU0sWUFBWSxHQUFHLEtBQUssTUFBTTtBQUM5QyxZQUFNLFNBQVEsb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUNsRCxZQUFNLGVBQWUsUUFBUSxLQUFLLGNBQWMsUUFBUSxLQUFLLGFBQWE7QUFDMUUsWUFBTSxZQUFZLEtBQUssUUFBUTtBQUFBLFFBQzdCLFlBQVksZUFBZSxLQUFLLE9BQU87QUFBQSxRQUN2QyxXQUFXO0FBQUEsUUFDWCxlQUFlLEtBQUssSUFBSTtBQUFBLFFBQ3hCLGlCQUFpQixNQUFNLGtCQUFrQixLQUFLLEtBQUssT0FBTztBQUFBLFFBQzFELGVBQWU7QUFBQSxNQUNqQixDQUFDO0FBR0QsWUFBTSxRQUFRLElBQUksS0FBSyxNQUFNLEtBQUssQ0FBQztBQUNuQyxZQUFNLFVBQVMsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDdEMsaUJBQVcsS0FBSyxLQUFLLFFBQVE7QUFDM0IsY0FBTSxFQUFFLFFBQVEsSUFBSTtBQUFBLFVBQ2xCLElBQUk7QUFBQSxVQUNKLEtBQUs7QUFBQSxZQUNILEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLEtBQUssTUFBTSxJQUFJO0FBQ25CLFlBQU0sS0FBSyxtQkFBbUI7QUFBQSxRQUM1QixRQUFRLEtBQUs7QUFBQSxRQUNiO0FBQUEsUUFDQSxRQUFRLEtBQUssT0FBTztBQUFBLFFBQ3BCLEtBQUssS0FBSztBQUFBLFFBQ1YsTUFBTSxLQUFLO0FBQUEsUUFDWCxjQUFjLE9BQU87QUFBQSxNQUN2QixDQUFDO0FBQUEsSUFDSDtBQUNBLFVBQU0sa0JBQWtCLEdBQUc7QUFDM0IsVUFBTSxLQUFLLHlCQUF5QjtBQUFBLE1BQ2xDO0FBQUEsTUFDQSxNQUFNLE1BQU07QUFBQSxNQUNaLE9BQU8sTUFBTTtBQUFBLE1BQ2IsUUFBUSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQUEsTUFDbkUsUUFBUSxPQUFPO0FBQUEsSUFDakIsQ0FBQztBQUNEO0FBQ0UsWUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLFFBQzdCLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixRQUFJLGVBQWUsYUFBYTtBQUM5QixZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sU0FDSixJQUFJLGFBQWEsU0FDYixlQUNBLElBQUksYUFBYSxlQUNmLGlCQUNBLElBQUksYUFBYSxZQUNmLGtCQUNBLEtBQUs7QUFDZixZQUFNLGNBQWM7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTyxJQUFJO0FBQUEsUUFDWCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLFFBQzdCLGtCQUNFLElBQUksYUFBYSxlQUFlLElBQUksbUJBQW1CLEtBQUs7QUFBQSxNQUNoRSxDQUFDO0FBQ0QsWUFBTSxNQUFPLGdCQUFnQjtBQUFBLFFBQzNCO0FBQUEsUUFDQSxTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNyRCxNQUFNLE1BQU07QUFBQSxRQUNaLE9BQU8sTUFBTTtBQUFBLFFBQ2IsVUFBVSxJQUFJO0FBQUEsUUFDZCxRQUFRLElBQUk7QUFBQSxRQUNaLFNBQVMsSUFBSTtBQUFBLFFBQ2Isa0JBQWtCLElBQUk7QUFBQSxNQUN4QixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0wsWUFBTSxNQUFPLGdCQUFnQjtBQUFBLFFBQzNCO0FBQUEsUUFDQSxTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNyRCxNQUFNLE1BQU07QUFBQSxRQUNaLE9BQU8sTUFBTTtBQUFBLFFBQ2IsR0FBRyxjQUFjLEdBQUc7QUFBQSxNQUN0QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBRUYsVUFBRTtBQUNBLFVBQU0sZUFBZTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsUUFBZ0IsS0FBZ0IsUUFBcUM7QUFDM0YsUUFBTSxLQUFLLFdBQVcsSUFBSSxVQUFVO0FBQ3BDLFFBQU0sTUFBTSxJQUFJLFdBQVcsTUFBTSxHQUFHLEVBQUU7QUFDdEMsUUFBTSxXQUFXLFdBQVcsSUFBSSxNQUFNO0FBQ3RDLFFBQU0sVUFBVSxPQUFPLE1BQU0sSUFBSSxFQUFFLElBQUksUUFBUTtBQUMvQyxRQUFNLFdBQVcsUUFBUSxNQUFNLElBQUksRUFBRSxJQUFJLFFBQVE7QUFDakQsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNQLGdCQUFnQjtBQUFBLE1BQ2hCLGdCQUFnQixJQUFJO0FBQUEsTUFDcEIsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYSxJQUFJO0FBQUEsTUFDakIsVUFBVSxJQUFJLGVBQWUsS0FBSyxHQUFHO0FBQUEsTUFDckMsWUFBWSxVQUFVO0FBQUEsTUFDdEIsWUFBWSxJQUFJO0FBQUEsTUFDaEI7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixnQkFBZ0I7QUFBQSxNQUNoQixnQkFBZ0IsSUFBSTtBQUFBLE1BQ3BCLGdCQUFnQjtBQUFBLE1BQ2hCLGFBQWEsSUFBSTtBQUFBLE1BQ2pCLG9CQUFvQixJQUFJO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHdCQUF3QixPQUE0QjtBQUMzRCxNQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLFVBQU0sT0FBTyxNQUFNLENBQUM7QUFDcEIsV0FBTyxZQUFZLEtBQUssTUFBTSxJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssT0FBTyxNQUFNLFNBQVMsS0FBSyxPQUFPLFdBQVcsSUFBSSxLQUFLLEdBQUcsU0FBUyxLQUFLLFFBQVE7QUFBQSxFQUNwSTtBQUNBLFFBQU0sT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFLEtBQUs7QUFDOUQsUUFBTSxXQUFXLEtBQUssV0FBVyxJQUFJLEtBQUssQ0FBQyxJQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsS0FBSyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUM7QUFDcEYsUUFBTSxhQUFhLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssT0FBTyxRQUFRLENBQUM7QUFDOUUsU0FBTyxrQkFBa0IsTUFBTSxNQUFNLFVBQVUsVUFBVSxTQUFTLGVBQWUsSUFBSSxLQUFLLEdBQUcsS0FBSyxRQUFRO0FBQzVHO0FBRUEsZUFBZSwrQkFBK0IsTUFBa0M7QUFDOUUsUUFBTSxVQUFVLE1BQU0sYUFBYSxLQUFLLE1BQU07QUFDOUMsTUFBSSxDQUFDLFFBQVMsUUFBTztBQUNyQixNQUFJLFFBQVEsV0FBVyxLQUFLLElBQUksT0FBUSxRQUFPLE9BQU8sS0FBSyxRQUFRLFlBQVksRUFBRTtBQUVqRixRQUFNLFlBQVksSUFBSTtBQUFBLElBQ3BCLEtBQUssT0FBTyxJQUFJLENBQUMsTUFBTTtBQUFBLE1BQ3JCLEVBQUU7QUFBQSxNQUNGLGNBQWMsRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLGFBQWEsRUFBRSxhQUFhLEVBQUUsWUFBWTtBQUFBLElBQzNGLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxrQkFBa0QsQ0FBQztBQUN6RCxhQUFXLENBQUMsU0FBUyxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ25FLFVBQU0sZUFBZSxVQUFVLElBQUksT0FBTztBQUMxQyxVQUFNLGFBQWE7QUFBQSxNQUNqQixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsSUFDUjtBQUNBLFFBQUksQ0FBQyxnQkFBZ0IsaUJBQWlCLFlBQVk7QUFDaEQsc0JBQWdCLE9BQU8sSUFBSSxFQUFFLEdBQUcsTUFBTTtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUVBLFFBQU0saUJBQWlCLE9BQU8sS0FBSyxlQUFlLEVBQUU7QUFDcEQsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLGVBQWUsS0FBSyxNQUFNO0FBQ2hDLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTSxZQUFZLFNBQVM7QUFDM0IsYUFBVyxTQUFTLE9BQU8sT0FBTyxlQUFlLEdBQUc7QUFDbEQsVUFBTSxpQkFBaUI7QUFBQSxFQUN6QjtBQUNBLFFBQU0sYUFBYSxLQUFLLFFBQVE7QUFBQSxJQUM5QixHQUFHO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDUixZQUFZLFFBQVE7QUFBQSxJQUNwQixjQUFjO0FBQUEsSUFDZCxvQkFBb0IsUUFBUSxtQkFBbUIsT0FBTyxDQUFDLE9BQU8sTUFBTSxlQUFlO0FBQUEsRUFDckYsQ0FBQztBQUNELFFBQU0sS0FBSyxvQ0FBb0M7QUFBQSxJQUM3QyxRQUFRLEtBQUs7QUFBQSxJQUNiLGVBQWUsS0FBSztBQUFBLElBQ3BCLFVBQVUsV0FBVyxTQUFTO0FBQUEsSUFDOUIsV0FBVztBQUFBLEVBQ2IsQ0FBQztBQUNELFNBQU87QUFDVDtBQUlBLGVBQWUsV0FBVyxRQUErQjtBQU12RCxRQUFNLFlBQVksaUJBQWlCLE1BQU07QUFDekMsUUFBTSxLQUFLLHlCQUF5QixFQUFFLFFBQVEsS0FBSyxlQUFlLENBQUM7QUFDbkUsTUFBSSxDQUFFLE1BQU0sYUFBYSxNQUFNLEdBQUk7QUFDakMsVUFBTSxPQUFNLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ25DLFVBQU0sYUFBYSxRQUFRO0FBQUEsTUFDekIsUUFBUSxTQUFTO0FBQUEsTUFDakIsZ0JBQWdCO0FBQUEsTUFDaEIsWUFBWTtBQUFBLE1BQ1osaUJBQWlCO0FBQUEsTUFDakIsY0FBYyxDQUFDO0FBQUEsTUFDZixvQkFBb0IsQ0FBQztBQUFBLE1BQ3JCLGdCQUFnQixDQUFDO0FBQUEsTUFDakIsWUFBWTtBQUFBLElBQ2QsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxXQUFXLFFBQVEsS0FBSyxDQUFDO0FBQzVEO0FBRUEsZUFBZSxhQUE0QjtBQUN6QyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxPQUFPLFNBQVMsT0FBTyxDQUFDO0FBQzlELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sV0FBVyxFQUFFLE1BQU07QUFBQSxFQUMzQjtBQUNGO0FBV0EsZUFBZSxrQkFBaUM7QUFDOUMsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxRQUFRLE1BQU0sZUFBZSxLQUFLLENBQUM7QUFBQSxFQUN2RSxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaURBQWlELGNBQWMsR0FBRyxDQUFDO0FBQzlFO0FBQUEsRUFDRjtBQUNBLFFBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsTUFBSSxDQUFDLE9BQU8sT0FBTyxJQUFJLE9BQU8sWUFBWSxDQUFDLElBQUksS0FBSztBQUNsRCxVQUFNLEtBQUssa0NBQWtDO0FBQzdDO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxnQ0FBZ0MsS0FBSyxJQUFJLEdBQUcsR0FBRztBQUNsRCxVQUFNLEtBQUssK0RBQStEO0FBQUEsTUFDeEUsS0FBSyxXQUFXLElBQUksR0FBRztBQUFBLElBQ3pCLENBQUM7QUFDRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssK0JBQStCLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFHdEUsTUFBSTtBQUNGLFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPLENBQUMsY0FBYztBQUFBLE1BQ3RCLE9BQU87QUFBQSxJQUNULENBQUM7QUFDRCxVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTyxDQUFDLFlBQVk7QUFBQSxJQUN0QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssdUNBQXVDLGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDdEU7QUFHQSxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU87QUFBQSxNQUNQLE1BQU0sTUFBTTtBQUNWLGNBQU0sSUFBSSxPQUFPO0FBQ2pCLGVBQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDO0FBQ3BELG1CQUFXLE1BQU0sT0FBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUMsR0FBRyxHQUFHO0FBQzNFLG1CQUFXLE1BQU0sT0FBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUMsR0FBRyxJQUFJO0FBQUEsTUFDOUU7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSywwQ0FBMEMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUN6RTtBQUNGO0FBYUEsSUFBTSxrQkFBa0I7QUFFeEIsZUFBZSxrQkFBMEM7QUFDdkQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxlQUFlO0FBQzlELFFBQU0sS0FBSyxPQUFPLGVBQWU7QUFDakMsU0FBTyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQ3ZDO0FBRUEsZUFBZSxnQkFBZ0IsSUFBa0M7QUFDL0QsTUFBSSxPQUFPLE1BQU07QUFDZixVQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU8sZUFBZTtBQUFBLEVBQ3BELE9BQU87QUFDTCxVQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGVBQWUsR0FBRyxHQUFHLENBQUM7QUFBQSxFQUMzRDtBQUNGO0FBRUEsZUFBZSxtQkFBa0M7QUFDL0MsUUFBTSxRQUFRLE1BQU0sa0JBQWtCO0FBQ3RDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLHlCQUF5QjtBQUNwQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0sa0JBQWtCO0FBQUEsSUFDdEIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCx1QkFBcUIsT0FBTztBQUM1QixPQUFLLFlBQVk7QUFDakIsUUFBTSxLQUFLLHdCQUF3QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMzRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLHdCQUErRDtBQUVuRSxTQUFTLHFCQUFxQixTQUF1QjtBQUNuRCxNQUFJLDBCQUEwQixLQUFNLGVBQWMscUJBQXFCO0FBQ3ZFLDBCQUF3QixZQUFZLE1BQU07QUFDeEMsU0FBSyxZQUFZLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDaEMsV0FBSyxLQUFLLHVCQUF1QixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3JELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyxzQkFBNEI7QUFDbkMsTUFBSSwwQkFBMEIsTUFBTTtBQUNsQyxrQkFBYyxxQkFBcUI7QUFDbkMsNEJBQXdCO0FBQUEsRUFDMUI7QUFDRjtBQUVBLGVBQWUsb0JBQW1DO0FBQ2hELHNCQUFvQjtBQUNwQixRQUFNLFFBQVEsT0FBTyxNQUFNLGNBQWM7QUFDekMsUUFBTSxRQUFRLE1BQU0sZ0JBQWdCO0FBQ3BDLFFBQU0sZ0JBQWdCLElBQUk7QUFDMUIsUUFBTSxPQUFPLE1BQU0sa0JBQWtCO0FBQ3JDLFFBQU0sa0JBQWtCLElBQUk7QUFDNUIsUUFBTSxLQUFLLDBCQUEwQjtBQUFBLElBQ25DLFNBQVMsVUFBVTtBQUFBLElBQ25CLFdBQVcsTUFBTSxhQUFhO0FBQUEsRUFDaEMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsY0FBNkI7QUFDMUMsTUFBSSxPQUFPLE1BQU0sa0JBQWtCO0FBQ25DLE1BQUksU0FBUyxNQUFNO0FBRWpCLHdCQUFvQjtBQUNwQjtBQUFBLEVBQ0Y7QUFJQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGdCQUFnQjtBQUM1QjtBQUFBLElBQ0Y7QUFFQSxVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsVUFBVSxLQUFLLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsSUFDYixDQUFDO0FBRUQsVUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLGVBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFVBQUksSUFBSSxTQUFTLEtBQUssU0FBUyxPQUFPLEdBQUc7QUFDdkMsY0FBTSxlQUFlLFFBQVEsS0FBSyxTQUFTLE9BQU87QUFDbEQ7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBRUEsUUFBTSxTQUFTLE1BQU0sa0JBQWtCO0FBQ3ZDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsd0JBQW9CO0FBQ3BCLFVBQU0sZ0JBQWdCLElBQUk7QUFDMUIsVUFBTSxrQkFBa0IsSUFBSTtBQUM1QixVQUFNLEtBQUsseUJBQXlCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNqRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTSxNQUFNLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDbkUsTUFBSSxRQUFRLE1BQU0sZ0JBQWdCO0FBQ2xDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxnQkFBZ0IsSUFBSSxFQUFFO0FBQUEsSUFDOUQsT0FBTztBQUNMLFlBQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQztBQUFBLElBQzFDO0FBQ0EsV0FBUSxNQUFNLGtCQUFrQixLQUFNO0FBQ3RDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxrQkFBa0IsSUFBSTtBQUM1QixVQUFNLEtBQUssZ0JBQWdCO0FBQUEsTUFDekIsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixXQUFXLE1BQU0sa0JBQWtCO0FBQUEsTUFDbkMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssNENBQTRDO0FBQUEsTUFDckQsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNLGVBQWUsT0FBTyxRQUFRLE9BQU8sT0FBTztBQUNsRCxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0sa0JBQWtCLElBQUk7QUFBQSxFQUM5QjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQVdBLElBQU0sc0JBQXNCO0FBRTVCLGVBQWUscUJBQTZDO0FBQzFELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksbUJBQW1CO0FBQ2xFLFFBQU0sS0FBSyxPQUFPLG1CQUFtQjtBQUNyQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLG1CQUFtQixJQUFrQztBQUNsRSxNQUFJLE9BQU8sS0FBTSxPQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU8sbUJBQW1CO0FBQUEsTUFDbEUsT0FBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxtQkFBbUIsR0FBRyxHQUFHLENBQUM7QUFDcEU7QUFFQSxlQUFlLHNCQUFxQztBQUNsRCxRQUFNLFFBQVEsTUFBTSxxQkFBcUI7QUFDekMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUssNkJBQTZCO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELDBCQUF3QixPQUFPO0FBQy9CLE9BQUssZUFBZTtBQUNwQixRQUFNLEtBQUssNEJBQTRCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQy9FLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksMkJBQWtFO0FBRXRFLFNBQVMsd0JBQXdCLFNBQXVCO0FBQ3RELE1BQUksNkJBQTZCLEtBQU0sZUFBYyx3QkFBd0I7QUFDN0UsNkJBQTJCLFlBQVksTUFBTTtBQUMzQyxTQUFLLGVBQWUsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNuQyxXQUFLLEtBQUssMkJBQTJCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDekQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHlCQUErQjtBQUN0QyxNQUFJLDZCQUE2QixNQUFNO0FBQ3JDLGtCQUFjLHdCQUF3QjtBQUN0QywrQkFBMkI7QUFBQSxFQUM3QjtBQUNGO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQseUJBQXVCO0FBQ3ZCLFFBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sUUFBUSxNQUFNLG1CQUFtQjtBQUN2QyxRQUFNLG1CQUFtQixJQUFJO0FBQzdCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLFVBQVU7QUFBQSxJQUNuQixXQUFXLE1BQU0sYUFBYTtBQUFBLEVBQ2hDLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJLE9BQU8sTUFBTSxxQkFBcUI7QUFDdEMsTUFBSSxTQUFTLE1BQU07QUFDakIsMkJBQXVCO0FBQ3ZCO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUNBLFVBQU0sS0FBSyxvREFBb0Q7QUFBQSxNQUM3RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFDRCxVQUFNLGtCQUFrQixLQUFLLFNBQVMsT0FBTztBQUM3QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUVBLFFBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxNQUFJLENBQUMsUUFBUTtBQUNYLDJCQUF1QjtBQUN2QixVQUFNLG1CQUFtQixJQUFJO0FBQzdCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLDZCQUE2QixFQUFFLFdBQVcsS0FBSyxVQUFVLENBQUM7QUFDckUsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUdBLE1BQUksTUFBTSxZQUFZLE9BQU8sT0FBTyxHQUFHO0FBQ3JDLFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQU1BLFFBQU0sTUFDSixPQUFPLFdBQVcsYUFDZCwwQkFBMEIsT0FBTyxPQUFPLEtBQ3hDLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDN0QsTUFBSSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3JDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxtQkFBbUIsSUFBSSxFQUFFO0FBQUEsSUFDakUsT0FBTztBQUNMLFlBQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQztBQUFBLElBQzFDO0FBQ0EsV0FBUSxNQUFNLHFCQUFxQixLQUFNO0FBQ3pDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLEtBQUssb0JBQW9CO0FBQUEsTUFDN0IsVUFBVSxPQUFPO0FBQUEsTUFDakIsYUFBYSxPQUFPLFdBQVcsYUFBYSxPQUFPLE9BQU87QUFBQSxNQUMxRCxXQUFXLE1BQU0scUJBQXFCO0FBQUEsTUFDdEMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsVUFBVSxPQUFPO0FBQUEsTUFDakIsR0FBRyxjQUFjLEdBQUc7QUFBQSxJQUN0QixDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBSUEsZUFBZSxXQUNiLFFBQ0EsVUFDQSxLQUNBLEtBQ0EsS0FDZTtBQUNmLFFBQU0sTUFBTyx3QkFBd0IsRUFBRSxRQUFRLFVBQVUsS0FBSyxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDckYsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxLQUFNO0FBQ3hELFFBQU0sVUFBNkI7QUFBQSxJQUNqQyxnQkFBZ0I7QUFBQSxJQUNoQjtBQUFBLElBQ0E7QUFBQSxJQUNBLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNwQyxZQUFZO0FBQUEsSUFDWixPQUFPLGNBQWMsR0FBRztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUNBLFFBQU0sS0FBSyxXQUFXLFFBQVEsV0FBVztBQUN6QyxRQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUssVUFBVSxPQUFPLENBQUM7QUFDL0MsUUFBTSxPQUFPLG1CQUFtQixFQUFFLElBQUksSUFBSTtBQUMxQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxRQUFRO0FBQUEsTUFDbkI7QUFBQSxNQUNBLGVBQWVBLFVBQVMsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLE1BQy9ELFNBQVMsZUFBZSxNQUFNLElBQUksUUFBUTtBQUFBLElBQzVDLENBQUM7QUFBQSxFQUNILFNBQVMsTUFBTTtBQUNiLFVBQU0sTUFBTyw0QkFBNEIsRUFBRSxHQUFHLGNBQWMsSUFBSSxFQUFFLENBQUM7QUFBQSxFQUNyRTtBQUNGO0FBRUEsZUFBZSxLQUFLLEdBQTRCO0FBQzlDLFFBQU0sTUFBTSxJQUFJLFlBQVksRUFBRSxPQUFPLENBQUM7QUFDdEMsUUFBTSxTQUFTLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxHQUFHO0FBQ3hELFFBQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxXQUFXLE1BQU0sQ0FBQyxFQUMxQyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFO0FBQ1YsU0FBTyxJQUFJLE1BQU0sR0FBRyxDQUFDO0FBQ3ZCO0FBSUEsZUFBZSxpQkFBaUIsT0FBK0I7QUFDN0QsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU87QUFBQSxNQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsTUFDUCxlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsTUFBSSxDQUFDLE9BQU87QUFJVixRQUFJLEtBQUssV0FBVyxrQkFBa0IsS0FBSyxxQkFBcUIsTUFBTTtBQUNwRSxZQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDM0MsVUFBSSxTQUFTLEtBQUssaUJBQWtCO0FBQUEsSUFDdEM7QUFLQSxRQUFJLEtBQUssV0FBVztBQUNsQixZQUFNLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUztBQUNsRCxVQUFJLE1BQU0sOEJBQStCO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLElBQUksTUFBTSxPQUFPLGlCQUFpQjtBQUl4QyxRQUFJLFdBQVc7QUFDZixRQUFJLFNBQVMsVUFBVSxTQUFTLFdBQVcsRUFBRSxnQkFBZ0I7QUFDM0QsaUJBQVcsTUFBTSxPQUFPLGFBQWEsU0FBUyxNQUFNO0FBQUEsSUFDdEQ7QUFDQSxVQUFNLGNBQWM7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUixPQUFPLEVBQUU7QUFBQSxNQUNULFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsTUFDUCxlQUFlLEVBQUU7QUFBQSxNQUNqQix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxLQUFLLHVCQUF1QjtBQUFBLE1BQ2hDLE9BQU8sRUFBRTtBQUFBLE1BQ1QsTUFBTSxFQUFFO0FBQUEsTUFDUixnQkFBZ0IsRUFBRTtBQUFBLE1BQ2xCLG1CQUFtQixTQUFTO0FBQUEsTUFDNUIsMEJBQTBCO0FBQUEsSUFDNUIsQ0FBQztBQUNELFFBQUksQ0FBQyxVQUFVO0FBQ2IsWUFBTSxLQUFLLDhDQUE4QztBQUFBLFFBQ3ZELFlBQVksU0FBUztBQUFBLFFBQ3JCLGdCQUFnQixFQUFFO0FBQUEsUUFDbEIsS0FBSyx3Q0FBd0MsRUFBRTtBQUFBLE1BQ2pELENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixVQUFNLE1BQU0sZUFBZSxjQUFjLElBQUksV0FBVztBQUN4RCxVQUFNLFNBQ0osUUFBUSxTQUNKLGVBQ0EsUUFBUSxlQUNOLGlCQUNBLFFBQVEsWUFDTixrQkFDQTtBQUNWLFVBQU0sVUFDSixlQUFlLGVBQWUsUUFBUSxlQUFlLElBQUksbUJBQW1CO0FBQzlFLFVBQU0sY0FBYztBQUFBLE1BQ2xCO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTyxjQUFjLEdBQUcsRUFBRTtBQUFBLE1BQzFCLGVBQWU7QUFBQSxNQUNmLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLEtBQUssMkJBQTJCO0FBQUEsTUFDcEMsVUFBVTtBQUFBLE1BQ1Ysa0JBQWtCO0FBQUEsTUFDbEIsR0FBRyxjQUFjLEdBQUc7QUFBQSxJQUN0QixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsb0JBQW9CLE9BQStCO0FBQ2hFLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsS0FBSztBQUNqQixVQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxPQUFPO0FBSVYsVUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFJLEtBQUssV0FBVyxrQkFBa0IsS0FBSyxxQkFBcUIsTUFBTTtBQUNwRSxZQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDM0MsVUFBSSxTQUFTLEtBQUssaUJBQWtCO0FBQUEsSUFDdEM7QUFJQSxVQUFNLGdCQUFnQixNQUFNLHVCQUF1QjtBQUNuRCxRQUFJLGVBQWU7QUFDakIsWUFBTSxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxhQUFhO0FBQ2pELFVBQUksT0FBTyxTQUFTLEdBQUcsS0FBSyxNQUFNLDhCQUErQjtBQUFBLElBQ25FO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxPQUFPLE1BQU0sT0FBTyxhQUFhLHNCQUFzQjtBQUM3RCxRQUFJLENBQUMsTUFBTTtBQUNULFVBQUksTUFBTyxPQUFNLEtBQUssaURBQWlEO0FBQ3ZFLFlBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEMsWUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLFNBQVMsa0JBQWtCLElBQUk7QUFDckMsUUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QixZQUFNLEtBQUssOENBQThDO0FBQ3pELFlBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEMsWUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLFlBQVksTUFBTTtBQUN4QixVQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JELFFBQUksTUFBTyxPQUFNLEtBQUssMkJBQTJCLEVBQUUsT0FBTyxPQUFPLE9BQU8sQ0FBQztBQUFBLEVBQzNFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUNoRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUlBLGVBQWUsaUJBQWdDO0FBQzdDLFFBQU0sUUFBUSxNQUFNLFdBQVc7QUFDL0IsVUFBUSxRQUFRLFlBQVksRUFBRSxNQUFNLGlCQUFpQixNQUFNLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDOUU7QUFFQSxlQUFlLGFBQXNDO0FBQ25ELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxXQUFXO0FBQ2YsTUFBSTtBQUNGLFVBQU0sT0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQzNGLGVBQVcsS0FBSztBQUFBLEVBQ2xCLFFBQVE7QUFBQSxFQUdSO0FBQ0EsUUFBTSxnQkFBZ0IsTUFBTSxrQkFBa0I7QUFDOUMsUUFBTSxtQkFBbUIsTUFBTSxxQkFBcUI7QUFDcEQsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFNBQU87QUFBQSxJQUNMLFNBQVM7QUFBQSxJQUNULFVBQVUsZUFBZSxRQUFRO0FBQUEsSUFDakMsWUFBWTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZO0FBQUEsTUFDVixRQUFRLG1CQUFtQixRQUFRLG9CQUFvQjtBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxhQUFhLGdCQUFnQixlQUFlO0FBQUEsTUFDNUMsZUFBZSxnQkFBZ0IsaUJBQWlCO0FBQUEsTUFDaEQsZUFBZSxnQkFBZ0IsaUJBQWlCO0FBQUEsSUFDbEQ7QUFBQSxJQUNBLGNBQWM7QUFBQSxNQUNaLE9BQU87QUFBQSxNQUNQLFNBQVMsMEJBQTBCO0FBQUEsTUFDbkMsV0FBVyxhQUFhLGFBQWE7QUFBQSxNQUNyQyxnQkFBZ0IsYUFBYSxnQkFBZ0I7QUFBQSxJQUMvQztBQUFBLElBQ0EsaUJBQWlCO0FBQUEsTUFDZixPQUFPO0FBQUEsTUFDUCxTQUFTLDZCQUE2QjtBQUFBLE1BQ3RDLFdBQVcsZ0JBQWdCLGFBQWE7QUFBQSxNQUN4QyxnQkFBZ0IsZ0JBQWdCLGdCQUFnQjtBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyxlQUFlLEdBQXlDO0FBQy9ELFNBQU87QUFBQSxJQUNMLE9BQU8sRUFBRTtBQUFBLElBQ1QsTUFBTSxFQUFFO0FBQUEsSUFDUixRQUFRLEVBQUU7QUFBQSxJQUNWLFNBQVMsRUFBRTtBQUFBLElBQ1gsYUFBYSxFQUFFO0FBQUEsSUFDZixjQUFjLEVBQUU7QUFBQSxJQUNoQix1QkFBdUIsRUFBRTtBQUFBLElBQ3pCLFFBQVEsRUFBRSxJQUFJLFNBQVM7QUFBQSxJQUN2QixXQUFXLEVBQUUsSUFBSSxVQUFVLElBQUksRUFBRSxJQUFJLE1BQU0sRUFBRSxJQUFJO0FBQUEsRUFDbkQ7QUFDRjtBQUVBLFNBQVMsV0FBVyxLQUFxQjtBQUV2QyxRQUFNLElBQUksSUFBSSxLQUFLLEdBQUc7QUFDdEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPLElBQUksUUFBUSxTQUFTLEVBQUU7QUFDN0QsUUFBTSxNQUFNLENBQUMsR0FBVyxJQUFJLE1BQU0sT0FBTyxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUc7QUFDM0QsU0FDRSxHQUFHLEVBQUUsZUFBZSxDQUFDLElBQUksSUFBSSxFQUFFLFlBQVksSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFDcEUsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDO0FBRTlFO0FBRUEsU0FBUyxVQUFVLEdBQXFCO0FBQ3RDLFNBQU8sV0FBVyxFQUFFLEtBQUssY0FBYyxFQUFFLElBQUk7QUFDL0M7QUFTQSxTQUFTLGVBQWUsTUFBeUI7QUFDL0MsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNQyxPQUFNO0FBQ1osVUFBSSxPQUFPQSxLQUFJLGVBQWUsU0FBVSxNQUFLLElBQUlBLEtBQUksVUFBVTtBQUMvRCxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsU0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLEtBQUs7QUFDeEI7QUFPQSxTQUFTLG9CQUFvQixNQUFlLFVBQW1DO0FBQzdFLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUEsT0FBTTtBQUNaLFVBQUlBLEtBQUksZUFBZSxVQUFVO0FBQy9CLGVBQU8sT0FBTyxLQUFLQSxJQUFHLEVBQUUsS0FBSztBQUFBLE1BQy9CO0FBQ0EsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQVFBLFNBQVMsaUJBQWlCLE1BQWUsVUFBa0IsTUFBeUI7QUFDbEYsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLE1BQUksUUFBd0M7QUFDNUMsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1BLE9BQU07QUFDWixVQUFJQSxLQUFJLGVBQWUsVUFBVTtBQUMvQixnQkFBUUE7QUFDUjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixNQUFJLE1BQWU7QUFDbkIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVUsUUFBTyxJQUFJLFFBQVEsT0FBTyxTQUFTLE9BQU8sR0FBRztBQUMxRixVQUFPLElBQWdDLEdBQUc7QUFBQSxFQUM1QztBQUNBLE1BQUksUUFBUSxPQUFXLFFBQU87QUFDOUIsTUFBSSxRQUFRLEtBQU0sUUFBTztBQUN6QixNQUFJLE9BQU8sUUFBUSxTQUFVLFFBQU8sSUFBSSxPQUFPLEdBQUc7QUFDbEQsTUFBSSxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sY0FBYyxJQUFJLE1BQU07QUFDdkQsU0FBTyxPQUFPLEtBQUssR0FBOEIsRUFBRSxLQUFLO0FBQzFEO0FBRUEsU0FBUyxXQUFXLEdBQW1CO0FBR3JDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFDeEIsVUFBTSxPQUFPLE9BQU8sWUFBWSxPQUFPLFNBQVMsWUFBTztBQUN2RCxXQUFPLE9BQU8sU0FBUyxXQUFXLE9BQU8sU0FBUyxnQkFDOUMsT0FDQSxHQUFHLE9BQU8sSUFBSSxHQUFHLElBQUk7QUFBQSxFQUMzQixRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQ7QUFDRjtBQUtDLFdBQXVDLGVBQWU7QUFBQSxFQUNyRDtBQUFBLEVBQ0EsVUFBVTtBQUFBLEVBQ1YsVUFBVTtBQUFBLEVBQ1YsU0FBUztBQUFBLEVBQ1QsVUFBVSxNQUFNLFNBQVMsVUFBVTtBQUFBLEVBQ25DLE9BQU87QUFBQSxFQUNQLGNBQWM7QUFBQSxFQUNkLGNBQWM7QUFBQSxFQUNkLGVBQWU7QUFBQSxFQUNmLGlCQUFpQjtBQUFBLEVBQ2pCLGlCQUFpQjtBQUFBLEVBQ2pCLGtCQUFrQjtBQUNwQjsiLAogICJuYW1lcyI6IFsidG9CYXNlNjQiLCAib2JqIiwgImluZm8iLCAidG9CYXNlNjQiLCAib2JqIl0KfQo=
