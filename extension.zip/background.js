// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw, ctx);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, partial_ids };
}
function pickPartial(node, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  return { tweet_id: restId, hint_handle: pickHintHandle(node, restId, ctx) };
}
function pickHintHandle(node, tweetId, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name) ?? pickHandleFromTweetUrls(node, tweetId) ?? pickHandleFromMediaPage(ctx.sourceUrl);
}
function pickHandleFromTweetUrls(node, tweetId) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const handle = handleFromTweetUrl(cur, tweetId);
      if (handle) return handle;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function handleFromTweetUrl(rawUrl, tweetId) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d{15,20})(?:\/|$)/);
    if (!match || match[2] !== tweetId) return null;
    return match[1] ?? null;
  } catch {
    return null;
  }
}
function pickHandleFromMediaPage(rawUrl) {
  if (!rawUrl) return null;
  try {
    const url = new URL(rawUrl);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/media\/?$/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted) {
  if (targeted.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.retweeted_tweet_id && targetedTweetIds.has(t.retweeted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let expandedCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        // Cast: the @types/firefox-webext-browser type signature insists
        // `func` returns void, but the API actually surfaces the return
        // value via `result[0].result`. We use that for the expand count.
        func: () => {
          const SHOW_MORE_SELECTORS = [
            '[data-testid="tweet-text-show-more-link"]',
            'button[data-testid="tweet-text-show-more-link"]',
            'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
          ];
          const clicked = /* @__PURE__ */ new Set();
          let expanded = 0;
          for (const sel of SHOW_MORE_SELECTORS) {
            for (const el of Array.from(document.querySelectorAll(sel))) {
              if (clicked.has(el)) continue;
              const t = (el.textContent || "").trim().toLowerCase();
              if (t !== "show more" && t !== "show this thread") continue;
              const rect = el.getBoundingClientRect();
              if (rect.width === 0 || rect.height === 0) continue;
              clicked.add(el);
              try {
                el.click();
                expanded += 1;
              } catch {
              }
            }
          }
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { expanded };
        }
      });
      scrollCount += 1;
      const r = results[0]?.result;
      if (r && typeof r.expanded === "number") expandedCount += r.expanded;
    } catch {
    }
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      sess.expandedCount += expandedCount;
      await setAutoScrollSession(sess);
    }
  }
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.pageUrl ?? null, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, pageUrl, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set(),
      sourceUrl: pageUrl
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.tweets.length === 0) return;
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const committedIdx = await getCommittedIndex();
  let dedupedSkipped = 0;
  const liveTweets = [];
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      continue;
    }
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (liveTweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, Object.keys(buf.tweets_by_id).length);
    if (added > 0) {
      await info("captured tweets", {
        handle,
        endpoint,
        added,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    if (tweets.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      idx[item.handle] = inner;
      await info("flush committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("flush batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return Object.keys(current.tweets_by_id).length;
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingCount = Object.keys(remainingTweets).length;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => id in remainingTweets)
  });
  await info("flush kept newer buffered tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  if (target.bucket === "_unknown") {
    await warn("media-crawl target missing handle; skipping broken status route", {
      tweet_id: target.tweetId
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const autoScrollSess = await getAutoScrollSession();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    }
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHBhdDogJycsXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXG4gIHJlcG86ICd4JyxcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxuICBicmFuY2g6ICdtYXN0ZXInLFxuICBlbmFibGVkOiB0cnVlLFxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcbiAgY29uZmlndXJlZEF0OiBudWxsLFxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXG59O1xuXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xuXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cbiAqXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXG4gKiBHaXRIdWIgUEFUIGluIHBsYWludGV4dC4gQSBkZXRlcm1pbmVkIGF0dGFja2VyIHdpdGggdGhlIGV4dGVuc2lvbidzIHNvdXJjZVxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxuICogc3RyaW5nIHNpdHRpbmcgbmV4dCB0byBpdHMga2V5IG5hbWUgaW4gZXh0ZW5zaW9uIHN0b3JhZ2UuXG4gKlxuICogU2NoZW1lOlxuICogICAtIE9uIGZpcnN0IGVuY3J5cHRpb24gd2UgZ2VuZXJhdGUgYSAzMi1ieXRlIHNhbHQgYW5kIHBlcnNpc3QgaXQgaW5cbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cbiAqICAgICB8fCBcImltbS1hcmNoaXZlLXBhdC12MVwiYC4gVGhlIHNhbHQgYmVpbmcgcGVyLWluc3RhbGwgbWVhbnMgdHdvIGNvcGllc1xuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxuICogICAtIFBsYWludGV4dCBpcyBlbmNyeXB0ZWQgd2l0aCBhIGZyZXNoIDEyLWJ5dGUgSVYuIFRoZSBlbnZlbG9wZSBmb3JtYXQgaXNcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXG4gKlxuICogQmFja3dhcmRzIGNvbXBhdGliaWxpdHk6IGFuIHVucHJlZml4ZWQgdmFsdWUgaXMgdHJlYXRlZCBhcyBsZWdhY3lcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cbiAqL1xuXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xuXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcbiAgbGV0IHMgPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIGJ1ZikgcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShzKTtcbn1cblxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcbiAgY29uc3QgYmluID0gYXRvYihzKTtcbiAgY29uc3Qgb3V0ID0gbmV3IFVpbnQ4QXJyYXkoYmluLmxlbmd0aCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChTQUxUX1NUT1JBR0VfS0VZKTtcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4geyBzYWx0QjY0OiB2LCBzYWx0OiBmcm9tQmFzZTY0KHYpIH07XG4gIH1cbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcbiAgY29uc3Qgc2FsdEI2NCA9IHRvQmFzZTY0KHNhbHQpO1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICBjb25zdCB7IHNhbHRCNjQsIHNhbHQgfSA9IGF3YWl0IGxvYWRPckNyZWF0ZVNhbHQoKTtcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcbiAgfVxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXG4gICk7XG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcbiAgY29tYmluZWQuc2V0KHNhbHQsIHNlZWQubGVuZ3RoKTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcbiAgICAnZW5jcnlwdCcsXG4gICAgJ2RlY3J5cHQnLFxuICBdKTtcbiAgZGVyaXZlZEtleUNhY2hlID0ga2V5O1xuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcbiAgcmV0dXJuIGtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdi5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbmNyeXB0UGF0KHBsYWludGV4dDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gIGNvbnN0IGl2ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMikpO1xuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcbiAgICBrZXksXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcbiAgKTtcbiAgcmV0dXJuIGAke0VOVkVMT1BFX1BSRUZJWH0ke3RvQmFzZTY0KGl2KX06JHt0b0Jhc2U2NChuZXcgVWludDhBcnJheShjdCkpfWA7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWNyeXB0UGF0KGVudmVsb3BlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXG4gIC8vIHJlLWVuY3J5cHRzIGl0IHZpYSB0aGUgc3RvcmFnZSBsYXllci5cbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xuICBpZiAocGFydHMubGVuZ3RoICE9PSAyKSByZXR1cm4gJyc7XG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XG4gIHRyeSB7XG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcbiAgICBjb25zdCBjdCA9IGZyb21CYXNlNjQoY3RCNjQpO1xuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcbiAgICAgIGtleSxcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShwdCk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnJztcbiAgfVxufVxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB7IGRlY3J5cHRQYXQsIGVuY3J5cHRQYXQsIGlzRW5jcnlwdGVkUGF0IH0gZnJvbSAnLi9jcnlwdG8uanMnO1xuaW1wb3J0IHR5cGUge1xuICBBY2NvdW50Q29uZmlnLFxuICBBY2NvdW50Q291bnRlcixcbiAgQ2Fub25pY2FsVHdlZXQsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFNldHRpbmdzLFxufSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBCdWZmZXJlZCB0d2VldHMgZm9yIGEgZ2l2ZW4gYWNjb3VudCwgYXdhaXRpbmcgY29tbWl0LiBBIFwicnVuXCIgaXMgb25lIGVudHJ5XG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xuICBydW5faWQ6IHN0cmluZztcbiAgYWNjb3VudF9oYW5kbGU6IHN0cmluZztcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcbiAgdHdlZXRzX2J5X2lkOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD47XG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XG4gIGVuZHBvaW50c19zZWVuOiBzdHJpbmdbXTtcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcbn1cblxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxuICogVXNlZCB0byBza2lwIHJlLWNhcHR1cmluZyB0d2VldHMgd2UndmUgYWxyZWFkeSBwdXNoZWQgd2l0aCBpZGVudGljYWxcbiAqIGVuZ2FnZW1lbnQgY291bnRzIFx1MjAxNCBhdm9pZHMgZ2VuZXJhdGluZyBvbmUgbmV3IHJhdy8qIGZpbGUgZXZlcnkgYnJvd3NlLiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XG4gIHRzOiBzdHJpbmc7IC8vIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3QgY29tbWl0XG4gIHNpZzogc3RyaW5nOyAvLyBlbmdhZ2VtZW50IHNpZ25hdHVyZTogXCJsaWtlfHJ0fHJlcGx5fHF1b3RlXCJcbn1cblxuLyoqIFByb2dyZXNzICsgaW5mbGlnaHQgdHJhY2tpbmcgZm9yIGEgcXVldWUtZHJpdmVuIGxvb3AgKHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCkuXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcbiAqIFwiWCBvZiBZIHByb2Nlc3NlZFwiIFx1MjAxNCBhbmQgdGhlIHdhaXQtZm9yLWluZ2VzdCBndWFyZCBrbm93cyB3aGF0IHRvIGV4cGVjdC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XG4gIC8qKiBJbml0aWFsIHF1ZXVlIHNpemUgd2hlbiB0aGUgdXNlciBjbGlja2VkIFwiU3RhcnRcIi4gKi9cbiAgdG90YWxBdFN0YXJ0OiBudW1iZXI7XG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cbiAgcHJvY2Vzc2VkOiBudW1iZXI7XG4gIC8qKiBJU08gb2Ygd2hlbiB0aGlzIHNlc3Npb24gc3RhcnRlZC4gKi9cbiAgc3RhcnRlZEF0OiBzdHJpbmc7XG4gIC8qKiBUd2VldCBjdXJyZW50bHkgaW5mbGlnaHQgXHUyMDE0IHdlIG5hdmlnYXRlZCB0byBpdCBhbmQgYXJlIHdhaXRpbmcgZm9yIHRoZVxuICAgKiBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgcmVzcG9uc2UgYmVmb3JlIGFkdmFuY2luZy4gbnVsbCBiZXR3ZWVuIHRpY2tzXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xuICBpbmZsaWdodDogeyB0d2VldElkOiBzdHJpbmc7IG5hdmlnYXRlZEF0OiBzdHJpbmcgfSB8IG51bGw7XG59XG5cbi8qKiBBdXRvLXNjcm9sbCBzZXNzaW9uOiBjb3VudHMgb2YgdGlja3MgYW5kIHR3ZWV0cyBpbmdlc3RlZCBzaW5jZSB0aGUgdXNlclxuICogY2xpY2tlZCBTdGFydC4gUGVyc2lzdGVkIHNvIFNXIGV2aWN0aW9uIGR1cmluZyBhIHJ1biBrZWVwcyBwcm9ncmVzcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xuICBzdGFydGVkQXQ6IHN0cmluZztcbiAgc2Nyb2xsQ291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xuICBleHBhbmRlZENvdW50OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xuICBzZXR0aW5nczogU2V0dGluZ3M7XG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XG4gIC8qKiBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IHN1Y2Nlc3NmdWwgYWNjb3VudHMueWFtbCBmZXRjaCBmcm9tIHRoZSByZXBvLlxuICAgKiBVc2VkIGJ5IGByZWZyZXNoQWNjb3VudHNMaXN0YCB0byBza2lwIHJlLWZldGNoaW5nIG9uIGV2ZXJ5IFNXIHdha2UgXHUyMDE0IHRoZVxuICAgKiBmaWxlIGNoYW5nZXMgcmFyZWx5IGFuZCBhbiBhdXRoZW50aWNhdGVkIHJhdyBmZXRjaCBldmVyeSB3YWtlIGFkZHMgdXAuICovXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IHN0cmluZyB8IG51bGw7XG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcbiAgcnVuQnVmZmVyczogUmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPjtcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XG4gIGNvbW1pdHRlZEluZGV4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+O1xuICAvKiogVHdlZXRzIHRoZSBub3JtYWxpemVyIGZsYWdnZWQgYXMgdHJ1bmNhdGVkIGFuZCB0aGF0IHdlIGhhdmVuJ3Qgc2VlbiBhXG4gICAqIGZ1bGwtdGV4dCB2ZXJzaW9uIG9mIHlldC4gS2V5ZWQgYnkgaGFuZGxlIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuICovXG4gIHJlZmV0Y2hRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogVHdlZXQgSURzIHNlZW4gdmlhIE1lZGlhLXRhYiAvIHBhcnRpYWwgY2FwdHVyZXMgdGhhdCBjb3VsZG4ndCBiZVxuICAgKiBub3JtYWxpemVkIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gS2V5ZWQgYnkgaGludC1oYW5kbGUgKG9yXG4gICAqIFwiX3Vua25vd25cIikgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gVGhlIHVzZXIgY2FuIGRyaXZlIGEgY3Jhd2wgdGhhdFxuICAgKiBvcGVucyBlYWNoIGRldGFpbCBwYWdlIHRvIGNhcHR1cmUgdGhlIHJlYWwgdGhpbmcuICovXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBtZWRpYUNyYXdsU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBhdXRvU2Nyb2xsU2Vzc2lvbjogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsO1xufVxuXG5jb25zdCBERUZBVUxUX0NPTk5FQ1RJT046IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgc3RhdHVzOiAndW5rbm93bicsXG4gIGxvZ2luOiBudWxsLFxuICBjaGVja2VkQXQ6IG51bGwsXG4gIGVycm9yOiBudWxsLFxuICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxufTtcblxuY29uc3QgREVGQVVMVFM6IFN0b3JhZ2VTaGFwZSA9IHtcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9LFxuICBhY2NvdW50czogWy4uLkZBTExCQUNLX0FDQ09VTlRTXSxcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogbnVsbCxcbiAgY29ubmVjdGlvbjogeyAuLi5ERUZBVUxUX0NPTk5FQ1RJT04gfSxcbiAgY291bnRlcnM6IHt9LFxuICBydW5CdWZmZXJzOiB7fSxcbiAgYWN0aXZpdHk6IFtdLFxuICBjb21taXR0ZWRJbmRleDoge30sXG4gIHJlZmV0Y2hRdWV1ZToge30sXG4gIG1lZGlhQ3Jhd2xRdWV1ZToge30sXG4gIHJlZmV0Y2hTZXNzaW9uOiBudWxsLFxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcbiAgYXV0b1Njcm9sbFNlc3Npb246IG51bGwsXG59O1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChrZXkpO1xuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUoREVGQVVMVFNba2V5XSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW2tleV06IHZhbHVlIH0pO1xufVxuXG4vLyAtLS0gU2V0dGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICAvLyBCYWNrZmlsbCBhbnkga2V5cyB0aGUgdXNlcidzIHN0b3JlZCBzZXR0aW5ncyBwcmVkYXRlIFx1MjAxNCByZWFkZXJzIGNhbiByZWx5XG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XG4gIC8vIGV2ZXJ5IGNhbGxzaXRlLiBUaGUgUEFUIGlzIHN0b3JlZCBlbmNyeXB0ZWQtYXQtcmVzdCBhcyBvZiB2MC4yLjA7IHdlXG4gIC8vIGRlY3J5cHQgdHJhbnNwYXJlbnRseSBzbyBjYWxsZXJzIGNvbnRpbnVlIHRvIHNlZSBwbGFpbnRleHQuXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcbiAgY29uc3QgbWVyZ2VkID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi5zdG9yZWQgfTtcbiAgaWYgKG1lcmdlZC5wYXQgJiYgaXNFbmNyeXB0ZWRQYXQobWVyZ2VkLnBhdCkpIHtcbiAgICB0cnkge1xuICAgICAgbWVyZ2VkLnBhdCA9IGF3YWl0IGRlY3J5cHRQYXQobWVyZ2VkLnBhdCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBtZXJnZWQucGF0ID0gJyc7XG4gICAgfVxuICB9XG4gIHJldHVybiBtZXJnZWQ7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXG4gIC8vIG9uIHRoZSBuZXh0IHNhdmUuXG4gIGNvbnN0IHRvV3JpdGU6IFNldHRpbmdzID0geyAuLi5zIH07XG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XG4gICAgdG9Xcml0ZS5wYXQgPSBhd2FpdCBlbmNyeXB0UGF0KHRvV3JpdGUucGF0KTtcbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2V0dGluZ3MocGF0Y2g6IFBhcnRpYWw8U2V0dGluZ3M+KTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBuZXh0ID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGF3YWl0IHNldFNldHRpbmdzKG5leHQpO1xuICByZXR1cm4gbmV4dDtcbn1cblxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzKCk6IFByb21pc2U8QWNjb3VudENvbmZpZ1tdPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHMoYTogQWNjb3VudENvbmZpZ1tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50c1JlZnJlc2hlZEF0KCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHNSZWZyZXNoZWRBdChpc286IHN0cmluZyB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcbn1cblxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29ubmVjdGlvbigpOiBQcm9taXNlPENvbm5lY3Rpb25TdGF0ZT4ge1xuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XG4gIC8vIEJhY2tmaWxsIGZpZWxkcyBhZGRlZCBhZnRlciB0aGUgdXNlcidzIHN0b3JhZ2Ugd2FzIHdyaXR0ZW4uXG4gIGNvbnN0IG91dDogQ29ubmVjdGlvblN0YXRlID0ge1xuICAgIC4uLmMsXG4gICAgZGVmYXVsdEJyYW5jaDogYy5kZWZhdWx0QnJhbmNoID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5kZWZhdWx0QnJhbmNoLFxuICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6XG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgcmF0ZUxpbWl0UmVzZXRBdDogYy5yYXRlTGltaXRSZXNldEF0ID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5yYXRlTGltaXRSZXNldEF0LFxuICB9O1xuICByZXR1cm4gb3V0O1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xufVxuXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ2NvdW50ZXJzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xuICAgIHRvZGF5Q291bnQ6IDAsXG4gICAgdG9kYXlEYXRlOiB0b2RheUlTTygpLFxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXG4gICAgYnVmZmVyZWRDb3VudDogMCxcbiAgfTtcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcbiAgICBjdXIudG9kYXlEYXRlID0gdG9kYXlJU08oKTtcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XG4gIH1cbiAgY29uc3QgbmV4dDogQWNjb3VudENvdW50ZXIgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRCdWZmZXJlZENvdW50KGhhbmRsZTogc3RyaW5nLCBjb3VudDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcbn1cblxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj4+IHtcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgcmV0dXJuIGFsbFtoYW5kbGVdID8/IG51bGw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcsIGJ1ZjogUnVuQnVmZmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYWxsW2hhbmRsZV0gPSBidWY7XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcbn1cblxuLy8gLS0tIEFjdGl2aXR5IHRhaWwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY3Rpdml0eScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwZW5kQWN0aXZpdHkoZXY6IExvZ0V2ZW50KTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XG4gIGN1ci51bnNoaWZ0KGV2KTtcbiAgaWYgKGN1ci5sZW5ndGggPiBBQ1RJVklUWV9UQUlMX01BWCkgY3VyLmxlbmd0aCA9IEFDVElWSVRZX1RBSUxfTUFYO1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcbiAgcmV0dXJuIGN1cjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBbXSk7XG59XG5cbi8vIC0tLSBDb21taXR0ZWQtdHdlZXRzIGRlZHVwIGluZGV4IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb21taXR0ZWRJbmRleCcpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29tbWl0dGVkSW5kZXgoXG4gIGlkeDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PlxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29tbWl0dGVkSW5kZXgnLCBpZHgpO1xufVxuXG4vKiogQ29tcHV0ZSB0aGUgZW5nYWdlbWVudCBzaWduYXR1cmUgd2UgdXNlIHRvIGRlY2lkZSB3aGV0aGVyIGEgcmUtY2FwdHVyZWRcbiAqIHR3ZWV0IGlzIFwibWF0ZXJpYWxseSBkaWZmZXJlbnRcIiBmcm9tIHdoYXQgd2UgbGFzdCBjb21taXR0ZWQuIFdlIG9taXRcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXG4gKiBkZWZlYXQgdGhlIGRlZHVwLiBMaWtlcyAvIFJUcyAvIHJlcGxpZXMgLyBxdW90ZXMgY2hhbmdlIHJhcmVseSBlbm91Z2ggdGhhdFxuICogZWFjaCBjaGFuZ2UgaXMgd29ydGggYSByZS1jb21taXQgKGFuZCBhbiBlbmdhZ2VtZW50X2hpc3Rvcnkgc25hcHNob3QpLlxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxuICogdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkgYnlwYXNzZXMgdGhlIGRlZHVwIGV2ZW4gd2hlbiBlbmdhZ2VtZW50IGNvdW50c1xuICogaGF2ZW4ndCBtb3ZlZCBcdTIwMTQgb3RoZXJ3aXNlIHRoZSBuZXcgYm9keSB3b3VsZCBiZSBzaWxlbnRseSBkcm9wcGVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXG4gIGxpa2VzOiBudW1iZXIsXG4gIHJldHdlZXRzOiBudW1iZXIsXG4gIHJlcGxpZXM6IG51bWJlcixcbiAgcXVvdGVzOiBudW1iZXIsXG4gIGlzVHJ1bmNhdGVkOiBib29sZWFuID0gZmFsc2Vcbik6IHN0cmluZyB7XG4gIHJldHVybiBgJHtsaWtlc318JHtyZXR3ZWV0c318JHtyZXBsaWVzfXwke3F1b3Rlc318JHtpc1RydW5jYXRlZCA/ICd0JyA6ICdmJ31gO1xufVxuXG4vKiogRHJvcCBlbnRyaWVzIG9sZGVyIHRoYW4gYG1heEFnZU1zYC4gUmV0dXJucyB0aGUgbnVtYmVyIHBydW5lZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcnVuZUNvbW1pdHRlZEluZGV4KG1heEFnZU1zOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBjb25zdCBjdXRvZmYgPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gbWF4QWdlTXMpLnRvSVNPU3RyaW5nKCk7XG4gIGxldCBwcnVuZWQgPSAwO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgY29uc3QgaW5uZXIgPSBpZHhbaGFuZGxlXTtcbiAgICBpZiAoIWlubmVyKSBjb250aW51ZTtcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcbiAgICAgIGNvbnN0IGUgPSBpbm5lclt0aWRdO1xuICAgICAgaWYgKGUgJiYgZS50cyA8IGN1dG9mZikge1xuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcbiAgICAgICAgcHJ1bmVkICs9IDE7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhpbm5lcikubGVuZ3RoID09PSAwKSBkZWxldGUgaWR4W2hhbmRsZV07XG4gIH1cbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG4gIHJldHVybiBwcnVuZWQ7XG59XG5cbi8vIC0tLSBSZWZldGNoIHF1ZXVlICh0d2VldHMgbmVlZGluZyBmdWxsLXRleHQgcmVjYXB0dXJlKSAtLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hRdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbaGFuZGxlXSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdO1xuICBpZiAoIWlkcykgcmV0dXJuO1xuICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2hhbmRsZV07XG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0UmVmZXRjaFRhcmdldCgpOiBQcm9taXNlPHtcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIHR3ZWV0SWQ6IHN0cmluZztcbn0gfCBudWxsPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBoYW5kbGUsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVNZWRpYUNyYXdsKGhpbnRIYW5kbGU6IHN0cmluZyB8IG51bGwsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcbiAgY29uc3QgaWRzID0gcVtidWNrZXRdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbYnVja2V0XSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcbiAgICBpZiAoIWlkcykgY29udGludWU7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XG4gICAgfVxuICB9XG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTogUHJvbWlzZTx7XG4gIGJ1Y2tldDogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgYnVja2V0LCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXG4gKiBlbnF1ZXVlaW5nIG1lZGlhLWNyYXdsIHRhcmdldHMgd2UndmUgYWxyZWFkeSBhcmNoaXZlZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpc0NvbW1pdHRlZCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgZm9yIChjb25zdCBpbm5lciBvZiBPYmplY3QudmFsdWVzKGlkeCkpIHtcbiAgICBpZiAoaW5uZXIgJiYgdHdlZXRJZCBpbiBpbm5lcikgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyAtLS0gTG9vcCBzZXNzaW9uIHN0YXRlIChwcm9ncmVzcyArIGluZmxpZ2h0IGdhdGluZykgLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEF1dG9TY3JvbGxTZXNzaW9uKCk6IFByb21pc2U8QXV0b1Njcm9sbFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXV0b1Njcm9sbFNlc3Npb24oczogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nLCBzKTtcbn1cblxuLy8gLS0tIFB1cmdlOiB1bnJlbGF0ZWQgYnVmZmVycywgY291bnRlcnMsIHF1ZXVlIGVudHJpZXMgLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vKipcbiAqIERyb3AgZXZlcnkgcGVyLWhhbmRsZSBiaXQgb2Ygc3RhdGUgKGNvdW50ZXJzLCBydW4gYnVmZmVyLCBjb21taXR0ZWQtaW5kZXhcbiAqIGVudHJpZXMsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyaWVzKSB0aGF0IGRvZXNuJ3QgY29ycmVzcG9uZCB0byBhXG4gKiB0cmFja2VkIGFjY291bnQuIFJldHVybnMgYSBzdW1tYXJ5IGRlc2NyaWJpbmcgd2hhdCB3YXMgY2xlYXJlZCBzbyB0aGVcbiAqIGNhbGxlciBjYW4gbG9nIGl0LlxuICpcbiAqIFRyYWNrZWQgYWNjb3VudHMgYXJlIHBhc3NlZCBpbiAoY2FsbGVyIHJlc29sdmVzIGZyb20gdGhlIGxpdmUgY29uZmlnKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1cmdlVW5yZWxhdGVkU3RhdGUodGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4pOiBQcm9taXNlPHtcbiAgY291bnRlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGJ1ZmZlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XG4gIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xuICBtZWRpYUNyYXdsSWRzUmVtb3ZlZDogbnVtYmVyO1xufT4ge1xuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcbiAgY29uc3QgaXNUYXJnZXRlZCA9IChoOiBzdHJpbmcpOiBib29sZWFuID0+IHRhcmdMb3dlci5oYXMoaC50b0xvd2VyQ2FzZSgpKTtcblxuICAvLyBDb3VudGVyc1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCBjb3VudGVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgY291bnRlcnNbaF07XG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcblxuICAvLyBSdW4gYnVmZmVyc1xuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBsZXQgYnVmZmVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoYnVmZmVycykpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBidWZmZXJzW2hdO1xuICAgICAgYnVmZmVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYnVmZmVycyk7XG5cbiAgLy8gQ29tbWl0dGVkIGRlZHVwIGluZGV4XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgaWR4W2hdO1xuICAgICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcblxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXG4gIGNvbnN0IHJxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGxldCByZWZldGNoSGFuZGxlc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgcnFbaF07XG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XG5cbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IGJ1Y2tldHMgYXJlIGhpbnQtaGFuZGxlcyAob3IgXCJfdW5rbm93blwiKS4gRHJvcFxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCBcdTIwMTQgaW5jbHVkaW5nIFwiX3Vua25vd25cIiBzaW5jZSB3ZVxuICAvLyBjYW4ndCB2ZXJpZnkgcmVsYXRpb24uXG4gIGNvbnN0IG1xID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhtcSkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xuICAgICAgZGVsZXRlIG1xW2hdO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIG1xKTtcblxuICByZXR1cm4ge1xuICAgIGNvdW50ZXJzUmVtb3ZlZCxcbiAgICBidWZmZXJzUmVtb3ZlZCxcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcbiAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQsXG4gICAgbWVkaWFDcmF3bElkc1JlbW92ZWQsXG4gIH07XG59XG5cbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbn1cbiIsICJpbXBvcnQgeyBhcHBlbmRBY3Rpdml0eSB9IGZyb20gJy4vc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5sZXQgYnJvYWRjYXN0OiAoKGV2OiBMb2dFdmVudCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldEJyb2FkY2FzdGVyKGZuOiAoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKTogdm9pZCB7XG4gIGJyb2FkY2FzdCA9IGZuO1xufVxuXG5mdW5jdGlvbiBub3dJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBldjogTG9nRXZlbnQgPSB7IHRzOiBub3dJU08oKSwgbGV2ZWwsIG1zZywgY29udGV4dDogcmVkYWN0KGNvbnRleHQpIH07XG4gIC8vIENvbnNvbGUgZm9yIGRldnRvb2xzLlxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xuICBpZiAobGV2ZWwgPT09ICdlcnJvcicpIGNvbnNvbGUuZXJyb3IobGluZSwgZXYuY29udGV4dCk7XG4gIGVsc2UgaWYgKGxldmVsID09PSAnd2FybicpIGNvbnNvbGUud2FybihsaW5lLCBldi5jb250ZXh0KTtcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcbiAgLy8gUGVyc2lzdGVudCB0YWlsLlxuICB0cnkge1xuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGZhaWxlZCB0byBhcHBlbmQgYWN0aXZpdHknLCBlcnIpO1xuICB9XG4gIC8vIExpdmUgYnJvYWRjYXN0IChlLmcuIHRvIHNpZGViYXIpLlxuICB0cnkge1xuICAgIGJyb2FkY2FzdD8uKGV2KTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gU2lkZWJhciBtYXkgbm90IGJlIG9wZW47IHRoYXQncyBmaW5lLlxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCdpbmZvJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCd3YXJuJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gZW1pdCgnZXJyb3InLCBtc2csIGNvbnRleHQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmVFcnJvcihlcnI6IHVua25vd24pOiB7IG1lc3NhZ2U6IHN0cmluZzsgc3RhY2s6IHN0cmluZyB8IG51bGwgfSB7XG4gIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcbiAgfVxuICB0cnkge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4geyBtZXNzYWdlOiAnPHVucHJpbnRhYmxlIGVycm9yPicsIHN0YWNrOiBudWxsIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTdHJpcCBhbnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSBQQVQgb3Igb3RoZXIgbG9uZyBzZWNyZXQgZnJvbSBhIGNvbnRleHRcbiAqIG9iamVjdCBiZWZvcmUgcGVyc2lzdGluZyBpdC4gRGVmZW5zaXZlOiBjYWxsZXJzIHNob3VsZCBub3QgbG9nIHRva2VucywgYnV0XG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxuICovXG5mdW5jdGlvbiByZWRhY3QoY3R4OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhjdHgpKSB7XG4gICAgaWYgKGsudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygndG9rZW4nKSB8fCBrLnRvTG93ZXJDYXNlKCkgPT09ICdwYXQnIHx8IGsgPT09ICdhdXRob3JpemF0aW9uJykge1xuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIC9naXRodWJfcGF0X1tBLVphLXowLTlfXXszMCx9Ly50ZXN0KHYpKSB7XG4gICAgICBvdXRba10gPSB2LnJlcGxhY2UoL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dKy9nLCAnZ2l0aHViX3BhdF88cmVkYWN0ZWQ+Jyk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XG4gICAgICBvdXRba10gPSBgJHt2LnNsaWNlKDAsIDQwOTYpfVx1MjAyNjx0cnVuY2F0ZWQ+YDtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0W2tdID0gdjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cbiIsICJpbXBvcnQgeyBkZXNjcmliZUVycm9yIH0gZnJvbSAnLi9sb2dnZXIuanMnO1xuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5jb25zdCBBUElfQkFTRSA9ICdodHRwczovL2FwaS5naXRodWIuY29tJztcbmNvbnN0IFJBV19CQVNFID0gJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZU9wdGlvbnMge1xuICBwYXRoOiBzdHJpbmc7XG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBleHBlY3RlZFNoYT86IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZVJlc3VsdCB7XG4gIHBhdGg6IHN0cmluZztcbiAgc2hhOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVPcHRpb25zIHtcbiAgcGF0aDogc3RyaW5nO1xuICBjb250ZW50QmFzZTY0OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZXNPcHRpb25zIHtcbiAgZmlsZXM6IENvbW1pdEZpbGVPcHRpb25zW107XG4gIG1lc3NhZ2U6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlc1Jlc3VsdCB7XG4gIGNvbW1pdFNoYTogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbiAgZmlsZXM6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgY2xhc3MgR2l0SHViRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIHN0YXR1czogbnVtYmVyO1xuICBib2R5OiB1bmtub3duO1xuICByZXRyaWFibGU6IGJvb2xlYW47XG4gIGNhdGVnb3J5OiAnYXV0aCcgfCAncmF0ZS1saW1pdCcgfCAnY29uZmxpY3QnIHwgJ25vdC1mb3VuZCcgfCAnc2VydmVyJyB8ICduZXR3b3JrJyB8ICd1bmtub3duJztcbiAgLyoqIFdoZW4gdGhlIEdpdEh1YiByYXRlLWxpbWl0IHdpbmRvdyBmb3IgdGhpcyB0b2tlbiByZXNldHMsIGFzIGEgVW5peFxuICAgKiBlcG9jaCBpbiBzZWNvbmRzLiBQb3B1bGF0ZWQgZnJvbSBgWC1SYXRlTGltaXQtUmVzZXRgIG9uIDQwMy80MjksIG9yXG4gICAqIGRlcml2ZWQgZnJvbSBgUmV0cnktQWZ0ZXJgIGZvciBzZWNvbmRhcnkgbGltaXRzLiBudWxsIHdoZW4gdW5rbm93bi4gKi9cbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVtYmVyIHwgbnVsbDtcblxuICBjb25zdHJ1Y3RvcihvcHRzOiB7XG4gICAgc3RhdHVzOiBudW1iZXI7XG4gICAgYm9keTogdW5rbm93bjtcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgcmV0cmlhYmxlOiBib29sZWFuO1xuICAgIGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXTtcbiAgICByYXRlTGltaXRSZXNldEF0PzogbnVtYmVyIHwgbnVsbDtcbiAgfSkge1xuICAgIHN1cGVyKG9wdHMubWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0dpdEh1YkVycm9yJztcbiAgICB0aGlzLnN0YXR1cyA9IG9wdHMuc3RhdHVzO1xuICAgIHRoaXMuYm9keSA9IG9wdHMuYm9keTtcbiAgICB0aGlzLnJldHJpYWJsZSA9IG9wdHMucmV0cmlhYmxlO1xuICAgIHRoaXMuY2F0ZWdvcnkgPSBvcHRzLmNhdGVnb3J5O1xuICAgIHRoaXMucmF0ZUxpbWl0UmVzZXRBdCA9IG9wdHMucmF0ZUxpbWl0UmVzZXRBdCA/PyBudWxsO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBHaXRIdWJDbGllbnQge1xuICBwcml2YXRlIHJlYWRvbmx5IHNldHRpbmdzOiBTZXR0aW5ncztcblxuICBjb25zdHJ1Y3RvcihzZXR0aW5nczogU2V0dGluZ3MpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gIH1cblxuICAvKiogUmV0dXJucyB0aGUgYXV0aGVudGljYXRlZCB1c2VyJ3MgbG9naW4uIFRocm93cyBvbiBhdXRoIGZhaWx1cmUuICovXG4gIGFzeW5jIHdob2FtaSgpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICByZXR1cm4gKHJlcyBhcyB7IGxvZ2luPzogc3RyaW5nIH0pLmxvZ2luID8/ICc8dW5rbm93bj4nO1xuICB9XG5cbiAgLyoqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZ2l2ZW4gYnJhbmNoIGV4aXN0cyBvbiB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xuICBhc3luYyBicmFuY2hFeGlzdHMoYnJhbmNoOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICdHRVQnLFxuICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2JyYW5jaGVzLyR7ZW5jb2RlVVJJQ29tcG9uZW50KGJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBmYWxzZTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKiogVmVyaWZpZXMgdGhlIFBBVCBjYW4gc2VlIHRoZSBjb25maWd1cmVkIHJlcG8uICovXG4gIGFzeW5jIHZlcmlmeVJlcG9BY2Nlc3MoKTogUHJvbWlzZTx7IGxvZ2luOiBzdHJpbmc7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH0+IHtcbiAgICBjb25zdCBtZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICBjb25zdCByZXBvID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb31gKTtcbiAgICBjb25zdCByID0gcmVwbyBhcyB7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGxvZ2luOiAobWUgYXMgeyBsb2dpbjogc3RyaW5nIH0pLmxvZ2luLFxuICAgICAgZnVsbF9uYW1lOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRmV0Y2ggYSB0ZXh0IGZpbGUgZnJvbSByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tIGF1dGhlbnRpY2F0ZWQgd2l0aCB0aGVcbiAgICogUEFULiBSZXR1cm5zIG51bGwgaWYgdGhlIGZpbGUgZG9lc24ndCBleGlzdC4gVXNlZCBmb3IgY29uZmlnL2FjY291bnRzLnlhbWwuXG4gICAqL1xuICBhc3luYyBmZXRjaFJhd1RleHQocGF0aEluUmVwbzogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgdXJsID0gYCR7UkFXX0JBU0V9LyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99LyR7dGhpcy5zZXR0aW5ncy5icmFuY2h9LyR7cGF0aEluUmVwb31gO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAgfSxcbiAgICB9KTtcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSByZXR1cm4gbnVsbDtcbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3IocmVzLCBgR0VUIHJhdyAke3BhdGhJblJlcG99YCk7XG4gICAgcmV0dXJuIHJlcy50ZXh0KCk7XG4gIH1cblxuICAvKipcbiAgICogTG9vayB1cCBhbiBleGlzdGluZyBmaWxlJ3MgU0hBIHZpYSB0aGUgQ29udGVudHMgQVBJLCBvciBudWxsIGlmIG5vdCBmb3VuZC5cbiAgICogVXNlZCB3aGVuIHJldHJ5aW5nIGEgUFVUIGFmdGVyIGEgNDIyIHNoYSBtaXNtYXRjaC5cbiAgICovXG4gIGFzeW5jIGdldEZpbGVTaGEocGF0aDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9P3JlZj0ke2VuY29kZVVSSUNvbXBvbmVudCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHIgPSByZXMgYXMgeyBzaGE/OiBzdHJpbmcgfTtcbiAgICAgIHJldHVybiByLnNoYSA/PyBudWxsO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBudWxsO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBQVVQgYSBmaWxlIHRvIHRoZSByZXBvLiBIYW5kbGVzIDQyMiAoc2hhIHJlcXVpcmVkKSBieSByZS1mZXRjaGluZyB0aGVcbiAgICogZXhpc3Rpbmcgc2hhIGFuZCByZXRyeWluZyBvbmNlLiBSZXRyaWVzIG5ldHdvcmsgLyA1eHggLyByYXRlLWxpbWl0IGVycm9yc1xuICAgKiB3aXRoIGV4cG9uZW50aWFsIGJhY2tvZmYgdXAgdG8gbWF4QXR0ZW1wdHMuXG4gICAqL1xuICBhc3luYyBwdXRGaWxlKG9wdHM6IFB1dEZpbGVPcHRpb25zKTogUHJvbWlzZTxQdXRGaWxlUmVzdWx0PiB7XG4gICAgY29uc3QgcGF0aCA9IG9wdHMucGF0aDtcbiAgICBjb25zdCB1cmwgPSBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2NvbnRlbnRzLyR7ZW5jb2RlUGF0aChwYXRoKX1gO1xuICAgIGxldCBzaGE6IHN0cmluZyB8IG51bGwgPSBvcHRzLmV4cGVjdGVkU2hhID8/IG51bGw7XG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xuXG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDE7IGF0dGVtcHQgPD0gbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xuICAgICAgY29uc3QgYm9keTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICAgIG1lc3NhZ2U6IG9wdHMubWVzc2FnZSxcbiAgICAgICAgY29udGVudDogb3B0cy5jb250ZW50QmFzZTY0LFxuICAgICAgICBicmFuY2g6IHRoaXMuc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgfTtcbiAgICAgIGlmIChzaGEpIGJvZHkuc2hhID0gc2hhO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ1BVVCcsIHVybCwgYm9keSk7XG4gICAgICAgIGNvbnN0IG91dCA9IHJlcyBhcyB7IGNvbnRlbnQ6IHsgc2hhOiBzdHJpbmc7IGh0bWxfdXJsOiBzdHJpbmc7IHBhdGg6IHN0cmluZyB9IH07XG4gICAgICAgIHJldHVybiB7IHBhdGg6IG91dC5jb250ZW50LnBhdGgsIHNoYTogb3V0LmNvbnRlbnQuc2hhLCB1cmw6IG91dC5jb250ZW50Lmh0bWxfdXJsIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XG4gICAgICAgIGlmIChlcnIuc3RhdHVzID09PSA0MjIgJiYgIXNoYSkge1xuICAgICAgICAgIC8vIEZpbGUgYWxyZWFkeSBleGlzdHM7IGZldGNoIGl0cyBzaGEgYW5kIHJldHJ5IG9uY2UuXG4gICAgICAgICAgc2hhID0gYXdhaXQgdGhpcy5nZXRGaWxlU2hhKHBhdGgpO1xuICAgICAgICAgIGlmICghc2hhKSB0aHJvdyBlcnI7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFlcnIucmV0cmlhYmxlIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGBwdXRGaWxlOiBleGhhdXN0ZWQgYXR0ZW1wdHMgZm9yICR7cGF0aH1gKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb21taXQgc2V2ZXJhbCBmaWxlcyB3aXRoIG9uZSBicmFuY2ggdXBkYXRlLiBUaGUgQ29udGVudHMgQVBJIGNyZWF0ZXMgb25lXG4gICAqIGNvbW1pdCBwZXIgUFVULCBzbyByYXBpZCBmbHVzaGVzIHJhY2UgZWFjaCBvdGhlciBvbiB0aGUgYnJhbmNoIGhlYWQuIFRoaXNcbiAgICogdXNlcyB0aGUgbG93ZXItbGV2ZWwgR2l0IERhdGEgQVBJIGluc3RlYWQ6IHVwbG9hZCBibG9icywgYnVpbGQgYSB0cmVlLFxuICAgKiBjcmVhdGUgb25lIGNvbW1pdCwgdGhlbiBtb3ZlIHRoZSBicmFuY2ggcmVmIG9uY2UuIElmIGFub3RoZXIgd3JpdGVyIG1vdmVzXG4gICAqIHRoZSBicmFuY2ggZmlyc3QsIHJlYmFzZSB0aGlzIHRyZWUgcGF0Y2ggb250byB0aGUgbGF0ZXN0IGhlYWQgYW5kIHJldHJ5LlxuICAgKi9cbiAgYXN5bmMgY29tbWl0RmlsZXMob3B0czogQ29tbWl0RmlsZXNPcHRpb25zKTogUHJvbWlzZTxDb21taXRGaWxlc1Jlc3VsdD4ge1xuICAgIGlmIChvcHRzLmZpbGVzLmxlbmd0aCA9PT0gMCkgdGhyb3cgbmV3IEVycm9yKCdjb21taXRGaWxlczogbm8gZmlsZXMgdG8gY29tbWl0Jyk7XG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xuICAgIGxldCBsYXN0RXJyOiB1bmtub3duID0gbnVsbDtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGJsb2JzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgICAgb3B0cy5maWxlcy5tYXAoYXN5bmMgKGZpbGUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG91dCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L2Jsb2JzYCxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGZpbGUuY29udGVudEJhc2U2NCxcbiAgICAgICAgICAgICAgICBlbmNvZGluZzogJ2Jhc2U2NCcsXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBwYXRoOiBmaWxlLnBhdGgsXG4gICAgICAgICAgICAgIHNoYTogKG91dCBhcyB7IHNoYTogc3RyaW5nIH0pLnNoYSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSlcbiAgICAgICAgKTtcblxuICAgICAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XG4gICAgICAgIGNvbnN0IHRyZWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvdHJlZXNgLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGJhc2VfdHJlZTogaGVhZC50cmVlU2hhLFxuICAgICAgICAgICAgdHJlZTogYmxvYnMubWFwKChibG9iKSA9PiAoe1xuICAgICAgICAgICAgICBwYXRoOiBibG9iLnBhdGgsXG4gICAgICAgICAgICAgIG1vZGU6ICcxMDA2NDQnLFxuICAgICAgICAgICAgICB0eXBlOiAnYmxvYicsXG4gICAgICAgICAgICAgIHNoYTogYmxvYi5zaGEsXG4gICAgICAgICAgICB9KSksXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICBjb25zdCB0cmVlU2hhID0gKHRyZWUgYXMgeyBzaGE6IHN0cmluZyB9KS5zaGE7XG4gICAgICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICdQT1NUJyxcbiAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9jb21taXRzYCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXG4gICAgICAgICAgICB0cmVlOiB0cmVlU2hhLFxuICAgICAgICAgICAgcGFyZW50czogW2hlYWQuc2hhXSxcbiAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGNvbW1pdE91dCA9IGNvbW1pdCBhcyB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nIH07XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICAgICAnUEFUQ0gnLFxuICAgICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNoYTogY29tbWl0T3V0LnNoYSxcbiAgICAgICAgICAgICAgZm9yY2U6IGZhbHNlLFxuICAgICAgICAgICAgfVxuICAgICAgICAgICk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGlmIChpc0NvbmZsaWN0KGVycikgJiYgYXR0ZW1wdCA8IG1heEF0dGVtcHRzKSB7XG4gICAgICAgICAgICBsYXN0RXJyID0gZXJyO1xuICAgICAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGNvbW1pdFNoYTogY29tbWl0T3V0LnNoYSxcbiAgICAgICAgICB1cmw6IGNvbW1pdE91dC5odG1sX3VybCxcbiAgICAgICAgICBmaWxlczogb3B0cy5maWxlcy5tYXAoKGZpbGUpID0+IGZpbGUucGF0aCksXG4gICAgICAgIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgbGFzdEVyciA9IGVycjtcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XG4gICAgICAgIGlmICgoIWVyci5yZXRyaWFibGUgJiYgIWlzQ29uZmxpY3QoZXJyKSkgfHwgYXR0ZW1wdCA9PT0gbWF4QXR0ZW1wdHMpIHRocm93IGVycjtcbiAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aHJvdyBsYXN0RXJyIGluc3RhbmNlb2YgRXJyb3IgPyBsYXN0RXJyIDogbmV3IEVycm9yKCdjb21taXRGaWxlczogZXhoYXVzdGVkIGF0dGVtcHRzJyk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGdldEJyYW5jaEhlYWQoKTogUHJvbWlzZTx7IHNoYTogc3RyaW5nOyB0cmVlU2hhOiBzdHJpbmcgfT4ge1xuICAgIGNvbnN0IHJlZiA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgJ0dFVCcsXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9yZWYvaGVhZHMvJHtlbmNvZGVQYXRoKHRoaXMuc2V0dGluZ3MuYnJhbmNoKX1gXG4gICAgKTtcbiAgICBjb25zdCBoZWFkU2hhID0gKHJlZiBhcyB7IG9iamVjdDogeyBzaGE6IHN0cmluZyB9IH0pLm9iamVjdC5zaGE7XG4gICAgY29uc3QgY29tbWl0ID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAnR0VUJyxcbiAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L2NvbW1pdHMvJHtoZWFkU2hhfWBcbiAgICApO1xuICAgIHJldHVybiB7XG4gICAgICBzaGE6IGhlYWRTaGEsXG4gICAgICB0cmVlU2hhOiAoY29tbWl0IGFzIHsgdHJlZTogeyBzaGE6IHN0cmluZyB9IH0pLnRyZWUuc2hhLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZldGNoSnNvbihtZXRob2Q6IHN0cmluZywgcGF0aDogc3RyaW5nLCBib2R5PzogdW5rbm93bik6IFByb21pc2U8dW5rbm93bj4ge1xuICAgIGNvbnN0IHVybCA9IHBhdGguc3RhcnRzV2l0aCgnaHR0cCcpID8gcGF0aCA6IGAke0FQSV9CQVNFfSR7cGF0aH1gO1xuICAgIGNvbnN0IGluaXQ6IFJlcXVlc3RJbml0ID0ge1xuICAgICAgbWV0aG9kLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dGhpcy5zZXR0aW5ncy5wYXR9YCxcbiAgICAgICAgQWNjZXB0OiAnYXBwbGljYXRpb24vdm5kLmdpdGh1Yitqc29uJyxcbiAgICAgICAgJ1gtR2l0SHViLUFwaS1WZXJzaW9uJzogJzIwMjItMTEtMjgnLFxuICAgICAgICAuLi4oYm9keSA/IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IDoge30pLFxuICAgICAgfSxcbiAgICAgIC4uLihib2R5ID8geyBib2R5OiBKU09OLnN0cmluZ2lmeShib2R5KSB9IDoge30pLFxuICAgIH07XG4gICAgbGV0IHJlczogUmVzcG9uc2U7XG4gICAgdHJ5IHtcbiAgICAgIHJlcyA9IGF3YWl0IGZldGNoKHVybCwgaW5pdCk7XG4gICAgfSBjYXRjaCAobmV0RXJyKSB7XG4gICAgICB0aHJvdyBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgICBzdGF0dXM6IDAsXG4gICAgICAgIGJvZHk6IG51bGwsXG4gICAgICAgIG1lc3NhZ2U6IGBuZXR3b3JrOiAke2Rlc2NyaWJlRXJyb3IobmV0RXJyKS5tZXNzYWdlfWAsXG4gICAgICAgIHJldHJpYWJsZTogdHJ1ZSxcbiAgICAgICAgY2F0ZWdvcnk6ICduZXR3b3JrJyxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gMjA0KSByZXR1cm4gbnVsbDtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICBpZiAodGV4dCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBwYXJzZWQgPSB0ZXh0O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBgJHttZXRob2R9ICR7cGF0aH1gKTtcbiAgICByZXR1cm4gcGFyc2VkO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBtYWtlRXJyb3IocmVzOiBSZXNwb25zZSwgbGFiZWw6IHN0cmluZyk6IFByb21pc2U8R2l0SHViRXJyb3I+IHtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICBpZiAodGV4dCkgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBsYWJlbCk7XG4gIH1cblxuICBwcml2YXRlIG1ha2VFcnJvckZyb21QYXJzZWQocmVzOiBSZXNwb25zZSwgYm9keTogdW5rbm93biwgbGFiZWw6IHN0cmluZyk6IEdpdEh1YkVycm9yIHtcbiAgICBjb25zdCBtc2cgPVxuICAgICAgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmIGJvZHkgJiYgJ21lc3NhZ2UnIGluIGJvZHlcbiAgICAgICAgPyBTdHJpbmcoKGJvZHkgYXMgeyBtZXNzYWdlOiB1bmtub3duIH0pLm1lc3NhZ2UpXG4gICAgICAgIDogcmVzLnN0YXR1c1RleHQ7XG4gICAgbGV0IGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXSA9ICd1bmtub3duJztcbiAgICBsZXQgcmV0cmlhYmxlID0gZmFsc2U7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSB8fCByZXMuc3RhdHVzID09PSA0MDMpIHtcbiAgICAgIC8vIDQwMyBjYW4gYmUgZWl0aGVyIGF1dGggb3IgcmF0ZSBsaW1pdDsgY2hlY2sgaGVhZGVycy5cbiAgICAgIGNvbnN0IHJhdGUgPSByZXMuaGVhZGVycy5nZXQoJ3gtcmF0ZWxpbWl0LXJlbWFpbmluZycpO1xuICAgICAgaWYgKHJhdGUgPT09ICcwJyB8fCAvcmF0ZSBsaW1pdC9pLnRlc3QobXNnKSkge1xuICAgICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNhdGVnb3J5ID0gJ2F1dGgnO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSB7XG4gICAgICBjYXRlZ29yeSA9ICdub3QtZm91bmQnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA5IHx8IHJlcy5zdGF0dXMgPT09IDQyMikge1xuICAgICAgY2F0ZWdvcnkgPSAnY29uZmxpY3QnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA+PSA1MDApIHtcbiAgICAgIGNhdGVnb3J5ID0gJ3NlcnZlcic7XG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDI5KSB7XG4gICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgc3RhdHVzOiByZXMuc3RhdHVzLFxuICAgICAgYm9keSxcbiAgICAgIG1lc3NhZ2U6IGAke2xhYmVsfSBcdTIxOTIgJHtyZXMuc3RhdHVzfTogJHttc2d9YCxcbiAgICAgIHJldHJpYWJsZSxcbiAgICAgIGNhdGVnb3J5LFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IHBhcnNlUmF0ZUxpbWl0UmVzZXQocmVzLmhlYWRlcnMpIDogbnVsbCxcbiAgICB9KTtcbiAgfVxufVxuXG4vKipcbiAqIEJlc3QtZWZmb3J0IHBhcnNlIG9mIHdoZW4gdGhlIGN1cnJlbnQgcmF0ZS1saW1pdCB3aW5kb3cgZW5kcy4gR2l0SHViJ3NcbiAqIHByaW1hcnkgbGltaXQgcmVwb3J0cyBgWC1SYXRlTGltaXQtUmVzZXRgIGFzIGEgVW5peCBlcG9jaCBpbiBzZWNvbmRzLlxuICogU2Vjb25kYXJ5IC8gYWJ1c2UgbGltaXRzIHVzZSBgUmV0cnktQWZ0ZXJgLCB3aGljaCBpcyBlaXRoZXIgYW4gSFRUUC1kYXRlXG4gKiBvciBhIGRlbHRhIGluIHNlY29uZHMgXHUyMDE0IHdlIG5vcm1hbGl6ZSBib3RoIHRvIGVwb2NoIHNlY29uZHMuXG4gKi9cbmZ1bmN0aW9uIHBhcnNlUmF0ZUxpbWl0UmVzZXQoaGVhZGVyczogSGVhZGVycyk6IG51bWJlciB8IG51bGwge1xuICBjb25zdCByZXNldCA9IGhlYWRlcnMuZ2V0KCd4LXJhdGVsaW1pdC1yZXNldCcpO1xuICBpZiAocmVzZXQpIHtcbiAgICBjb25zdCBuID0gTnVtYmVyLnBhcnNlSW50KHJlc2V0LCAxMCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShuKSAmJiBuID4gMCkgcmV0dXJuIG47XG4gIH1cbiAgY29uc3QgcmV0cnlBZnRlciA9IGhlYWRlcnMuZ2V0KCdyZXRyeS1hZnRlcicpO1xuICBpZiAocmV0cnlBZnRlcikge1xuICAgIGNvbnN0IGRlbHRhID0gTnVtYmVyLnBhcnNlSW50KHJldHJ5QWZ0ZXIsIDEwKTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGRlbHRhKSAmJiBkZWx0YSA+PSAwKSB7XG4gICAgICByZXR1cm4gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCkgKyBkZWx0YTtcbiAgICB9XG4gICAgY29uc3QgYXNEYXRlID0gRGF0ZS5wYXJzZShyZXRyeUFmdGVyKTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGFzRGF0ZSkpIHJldHVybiBNYXRoLmZsb29yKGFzRGF0ZSAvIDEwMDApO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBlbmNvZGVQYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIEVuY29kZSBzZWdtZW50cyBpbmRpdmlkdWFsbHkgc28gc2xhc2hlcyByZW1haW4uXG4gIHJldHVybiBwYXRoLnNwbGl0KCcvJykubWFwKGVuY29kZVVSSUNvbXBvbmVudCkuam9pbignLycpO1xufVxuXG5mdW5jdGlvbiBiYWNrb2ZmTXMoYXR0ZW1wdDogbnVtYmVyLCBlcnI6IEdpdEh1YkVycm9yKTogbnVtYmVyIHtcbiAgLy8gRXhwb25lbnRpYWwgd2l0aCBqaXR0ZXI7IGJ1bXAgaGlnaGVyIGZvciByYXRlLWxpbWl0IHJlc3BvbnNlcy5cbiAgY29uc3QgYmFzZSA9IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnID8gNTAwMCA6IDUwMDtcbiAgY29uc3Qgaml0dGVyID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNDAwKTtcbiAgcmV0dXJuIE1hdGgubWluKDYwXzAwMCwgYmFzZSAqIDIgKiogKGF0dGVtcHQgLSAxKSArIGppdHRlcik7XG59XG5cbmZ1bmN0aW9uIGlzQ29uZmxpY3QoZXJyOiB1bmtub3duKTogZXJyIGlzIEdpdEh1YkVycm9yIHtcbiAgcmV0dXJuIGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ2NvbmZsaWN0Jztcbn1cblxuZnVuY3Rpb24gc2xlZXAobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBieXRlcyBpcyBhIFVURi04IHN0cmluZyBvZiBKU09OOyBlbmNvZGUgdG8gYmFzZTY0IHRoZSBzYWZlIHdheS5cbiAgY29uc3QgdXRmOCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShieXRlcyk7XG4gIGxldCBiaW4gPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIHV0ZjgpIGJpbiArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShiaW4pO1xufVxuIiwgImltcG9ydCB7IFRXRUVUX1VSTF9QUkVGSVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDb21tdW5pdHlOb3RlLFxuICBNZWRpYUl0ZW0sXG4gIFR3ZWV0Q2FyZCxcbiAgVHdlZXRUeXBlLFxuICBVcmxFbnRpdHksXG4gIFVzZXJTbmFwc2hvdCxcbn0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTm9ybWFsaXplIEdyYXBoUUwgcmVzcG9uc2UgcGF5bG9hZHMgZnJvbSBYJ3MgaW50ZXJuYWwgQVBJIGludG9cbiAqIGBDYW5vbmljYWxUd2VldGBzLiBNYW55IGVuZHBvaW50cyBzaGFyZSBhIHNpbWlsYXIgdHdlZXQgc2hhcGUgYnV0IHdyYXAgaXQgaW5cbiAqIGRpZmZlcmVudCBlbnZlbG9wZXM7IHRoaXMgbW9kdWxlIHdhbGtzIHRoZSBzdHJ1Y3R1cmUgZGVmZW5zaXZlbHkuXG4gKlxuICogVGhlIHBhcnNlciBpcyBpbnRlbnRpb25hbGx5IHBlcm1pc3NpdmU6IGl0IHdpbGwgc2lsZW50bHkgc2tpcCBlbnRyaWVzIGl0XG4gKiBjYW4ndCByZWNvZ25pemUgYXMgdHdlZXRzIChjdXJzb3JzLCBhZHMsIGdhcCBlbnRyaWVzLCBtb2R1bGVzIG9mIG90aGVyXG4gKiB0d2VldHMsIHRvbWJzdG9uZXMpLiBJdCB0aHJvd3MgKm9ubHkqIHdoZW4gZ2l2ZW4gYSBwYXlsb2FkIGl0IGRvZXNuJ3Qga25vd1xuICogaG93IHRvIHdhbGsgYXQgYWxsIFx1MjAxNCB0aG9zZSBjYXNlcyBhcmUgY2F1Z2h0IGFuZCBxdWFyYW50aW5lZCB1cHN0cmVhbS5cbiAqL1xuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZUNvbnRleHQge1xuICBjYXB0dXJlZEF0OiBzdHJpbmc7XG4gIHJ1bklkOiBzdHJpbmc7XG4gIGVuZHBvaW50OiBzdHJpbmc7XG4gIGFsbG93ZWRIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+O1xuICBzb3VyY2VVcmw/OiBzdHJpbmcgfCBudWxsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZVJlc3VsdCB7XG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcbiAgb2JzZXJ2ZWRfaWRzOiBzdHJpbmdbXTtcbiAgLyoqXG4gICAqIFR3ZWV0LXNoYXBlZCBub2RlcyB0aGUgd2Fsa2VyIHNhdyAoaGFkIGEgYHJlc3RfaWRgKSBidXQgY291bGRuJ3QgdHVyblxuICAgKiBpbnRvIGEgZnVsbCBgQ2Fub25pY2FsVHdlZXRgIFx1MjAxNCB0eXBpY2FsbHkgYmVjYXVzZSB0aGUgZW1iZWRkZWQgdXNlclxuICAgKiBpbmZvIHdhcyBtaXNzaW5nIG9yIHRoZSBlbnRyeSB3YXMgYSBtZWRpYS1vbmx5IHRodW1ibmFpbCBjYXJkIGZyb21cbiAgICogdGhlIFVzZXJNZWRpYSBlbmRwb2ludC4gVGhlIGJhY2tncm91bmQgcXVldWVzIHRoZXNlIGZvciBhbiBleHBsaWNpdFxuICAgKiBcImdvIGZldGNoIHRoZSBkZXRhaWwgcGFnZVwiIGNyYXdsIHNvIHdlIGRvbid0IGRyb3AgdGhlbSBvbiB0aGUgZmxvb3IuXG4gICAqL1xuICBwYXJ0aWFsX2lkczogQXJyYXk8eyB0d2VldF9pZDogc3RyaW5nOyBoaW50X2hhbmRsZTogc3RyaW5nIHwgbnVsbCB9Pjtcbn1cblxuLy8gWCB0d2VldCBJRHMgYXJlIDY0LWJpdCBwb3NpdGl2ZSBpbnRlZ2VycyBzZXJpYWxpemVkIGFzIGRlY2ltYWwgc3RyaW5ncy5cbi8vIFRoZXkndmUgZ3Jvd24gdG8gMTkgY2hhcnMgKH4xLjVlMTgpIGJ5IDIwMjYuIFJlamVjdCBhbnl0aGluZyB0aGF0IGRvZXNuJ3Rcbi8vIG1hdGNoIHRoaXMgc2hhcGUgXHUyMDE0IG90aGVyd2lzZSBzcHVyaW91cyBjYXJkIElEcywgY3Vyc29yIHN0cmluZ3MsIGFkIHNsb3Rcbi8vIElEcywgZXRjLiBlbmQgdXAgaW4gdGhlIHBhcnRpYWwtY2FwdHVyZSBxdWV1ZSBhbmQgdGhlIGNyYXdsIGxvb3Bcbi8vIG5hdmlnYXRlcyB0byBpbnZhbGlkIFVSTHMgdGhhdCBzaG93IFwidGhpcyBwYWdlIGRvZXNuJ3QgZXhpc3RcIi5cbmNvbnN0IFRXRUVUX0lEX1JFID0gL15cXGR7MTUsMjB9JC87XG5cbi8vIE9ubHkgb25lIGVuZHBvaW50IGFjdHVhbGx5IGV4cG9zZXMgdGhlIGZhaWx1cmUgbW9kZSB0aGUgcGFydGlhbC1jYXB0dXJlXG4vLyBxdWV1ZSBleGlzdHMgZm9yIFx1MjAxNCB0aGUgTWVkaWEgdGFiJ3MgYFVzZXJNZWRpYWAgcXVlcnkgcmV0dXJuaW5nXG4vLyB0aHVtYm5haWwtb25seSBlbnRyaWVzIHdpdGhvdXQgYSBwb3B1bGF0ZWQgYXV0aG9yIGJsb2NrLiBFdmVyeSBvdGhlclxuLy8gZW5kcG9pbnQgdGhhdCBoYW5kcyB1cyBhIGBUd2VldGAgc2hhcGUgZ2l2ZXMgdXMgdGhlIGZ1bGwgZW50cnk7IGlmXG4vLyBgYnVpbGRUd2VldGAgZmFpbHMgdGhlcmUgaXQncyBhIHJlYWwgZXJyb3IsIG5vdCBcImdvIHJlLWZldGNoIHRoaXNcIi5cbi8vIFJlc3RyaWN0aW5nIHBhcnRpYWwtaWQgZW1pc3Npb24gdG8gVXNlck1lZGlhIHN0b3BzIHRoZSBmbG9vZHMgb2Zcbi8vIGZhbHNlIHBvc2l0aXZlcyByZXBvcnRlZCBvbiBSZXBsaWVzIC8gVHdlZXREZXRhaWwgLyBTZWFyY2hUaW1lbGluZS5cbmNvbnN0IFBBUlRJQUxfT0tfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJNZWRpYSddKTtcblxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShwYXlsb2FkOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBOb3JtYWxpemVSZXN1bHQge1xuICBjb25zdCByYXdUd2VldHMgPSBjb2xsZWN0VHdlZXRzKHBheWxvYWQpO1xuICBjb25zdCB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10gPSBbXTtcbiAgY29uc3Qgb2JzZXJ2ZWQ6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IGJ1aWx0ID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHBhcnRpYWxNYXAgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nIHwgbnVsbD4oKTtcbiAgY29uc3QgY29sbGVjdFBhcnRpYWxzID0gUEFSVElBTF9PS19FTkRQT0lOVFMuaGFzKGN0eC5lbmRwb2ludCk7XG4gIGZvciAoY29uc3QgcmF3IG9mIHJhd1R3ZWV0cykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0ID0gYnVpbGRUd2VldChyYXcsIGN0eCk7XG4gICAgICBpZiAoIXQpIHtcbiAgICAgICAgaWYgKGNvbGxlY3RQYXJ0aWFscykge1xuICAgICAgICAgIC8vIE9ubHkgZW5xdWV1ZSByZWFsLXR3ZWV0IHNoZWxscyAobm90IHRvbWJzdG9uZXMsIG5vdCBzdHJpcHBlZFxuICAgICAgICAgIC8vIG5vZGVzIGxhY2tpbmcgYSBsZWdhY3kgYmxvY2ssIG5vdCBnYXJiYWdlIElEcykuXG4gICAgICAgICAgY29uc3QgcGFydGlhbCA9IHBpY2tQYXJ0aWFsKHJhdywgY3R4KTtcbiAgICAgICAgICBpZiAocGFydGlhbCkgcGFydGlhbE1hcC5zZXQocGFydGlhbC50d2VldF9pZCwgcGFydGlhbC5oaW50X2hhbmRsZSk7XG4gICAgICAgIH1cbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBvYnNlcnZlZC5wdXNoKHQudHdlZXRfaWQpO1xuICAgICAgYnVpbHQuYWRkKHQudHdlZXRfaWQpO1xuICAgICAgaWYgKGN0eC5hbGxvd2VkSGFuZGxlcy5zaXplID09PSAwIHx8IGN0eC5hbGxvd2VkSGFuZGxlcy5oYXModC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpKSkge1xuICAgICAgICB0d2VldHMucHVzaCh0KTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIE9uZSBiYWQgZW50cnkgc2hvdWxkbid0IHRha2UgZG93biB0aGUgd2hvbGUgYmF0Y2guXG4gICAgfVxuICB9XG4gIC8vIEFueXRoaW5nIHRoYXQgZW5kZWQgdXAgaW4gcGFydGlhbE1hcCBidXQgQUxTTyBjYW1lIGJhY2sgYXMgYSBidWlsdFxuICAvLyB0d2VldCAoZGlmZmVyZW50IHdhbGtlciBwYXNzLCBzYW1lIGlkKSBpc24ndCBhY3R1YWxseSBwYXJ0aWFsLlxuICBjb25zdCBwYXJ0aWFsX2lkczogQXJyYXk8eyB0d2VldF9pZDogc3RyaW5nOyBoaW50X2hhbmRsZTogc3RyaW5nIHwgbnVsbCB9PiA9IFtdO1xuICBmb3IgKGNvbnN0IFtpZCwgaGludF0gb2YgcGFydGlhbE1hcCkge1xuICAgIGlmIChidWlsdC5oYXMoaWQpKSBjb250aW51ZTtcbiAgICBwYXJ0aWFsX2lkcy5wdXNoKHsgdHdlZXRfaWQ6IGlkLCBoaW50X2hhbmRsZTogaGludCB9KTtcbiAgfVxuICByZXR1cm4geyB0d2VldHMsIG9ic2VydmVkX2lkczogb2JzZXJ2ZWQsIHBhcnRpYWxfaWRzIH07XG59XG5cbmZ1bmN0aW9uIHBpY2tQYXJ0aWFsKFxuICBub2RlOiB1bmtub3duLFxuICBjdHg6IE5vcm1hbGl6ZUNvbnRleHRcbik6IHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfSB8IG51bGwge1xuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgLy8gRGVsZXRlZCB0d2VldHMgc3VyZmFjZSBhcyBUd2VldFRvbWJzdG9uZSBcdTIwMTQgdGhlcmUncyBub3RoaW5nIHRvIHJlZmV0Y2gsXG4gIC8vIHNraXAgdGhlbSBvciB0aGUgY3Jhd2wgbG9vcCB3aWxsIHNwaW4gb24gXCJ0aGlzIHBhZ2UgZG9lc24ndCBleGlzdFwiLlxuICBpZiAobi5fX3R5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnKSByZXR1cm4gbnVsbDtcbiAgLy8gUmVxdWlyZSBhIHJlY29nbml6ZWQgVHdlZXQgdHlwZW5hbWUgT1IgYSBsZWdhY3kgYmxvY2suIEN1cnNvcnMsIGFkcyxcbiAgLy8gbW9kdWxlIGhlYWRlcnMsIGFuZCB0aGUgbGlrZSBnZXQgcmVqZWN0ZWQgaGVyZS5cbiAgY29uc3QgdG4gPSBuLl9fdHlwZW5hbWU7XG4gIGlmICh0biAhPT0gJ1R3ZWV0JyAmJiB0biAhPT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiAhb2JqKG4ubGVnYWN5KSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IHJlc3RJZCA9XG4gICAgKHR5cGVvZiBuLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIG4ucmVzdF9pZCkgfHxcbiAgICAodHlwZW9mIG9iaihuLnR3ZWV0X3Jlc3VsdCk/LnJlc3VsdCA9PT0gJ29iamVjdCcgJiZcbiAgICAgIChvYmoob2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCBhcyBzdHJpbmcpKTtcbiAgaWYgKHR5cGVvZiByZXN0SWQgIT09ICdzdHJpbmcnIHx8ICFUV0VFVF9JRF9SRS50ZXN0KHJlc3RJZCkpIHJldHVybiBudWxsO1xuICByZXR1cm4geyB0d2VldF9pZDogcmVzdElkLCBoaW50X2hhbmRsZTogcGlja0hpbnRIYW5kbGUobm9kZSwgcmVzdElkLCBjdHgpIH07XG59XG5cbmZ1bmN0aW9uIHBpY2tIaW50SGFuZGxlKG5vZGU6IHVua25vd24sIHR3ZWV0SWQ6IHN0cmluZywgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihvYmoobi5jb3JlKT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgcmV0dXJuIChcbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmNvcmUpPy5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbChvYmoobi5sZWdhY3kpPy5zY3JlZW5fbmFtZSkgPz9cbiAgICBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlLCB0d2VldElkKSA/P1xuICAgIHBpY2tIYW5kbGVGcm9tTWVkaWFQYWdlKGN0eC5zb3VyY2VVcmwpXG4gICk7XG59XG5cbmZ1bmN0aW9uIHBpY2tIYW5kbGVGcm9tVHdlZXRVcmxzKG5vZGU6IHVua25vd24sIHR3ZWV0SWQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGN1ciA9IHN0YWNrLnBvcCgpO1xuICAgIGlmICh0eXBlb2YgY3VyID09PSAnc3RyaW5nJykge1xuICAgICAgY29uc3QgaGFuZGxlID0gaGFuZGxlRnJvbVR3ZWV0VXJsKGN1ciwgdHdlZXRJZCk7XG4gICAgICBpZiAoaGFuZGxlKSByZXR1cm4gaGFuZGxlO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmIChzZWVuLmhhcyhjdXIgYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQoY3VyIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIGN1cikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmZ1bmN0aW9uIGhhbmRsZUZyb21Ud2VldFVybChyYXdVcmw6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIHRyeSB7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChyYXdVcmwsIFRXRUVUX1VSTF9QUkVGSVgpO1xuICAgIGlmICh1cmwuaG9zdG5hbWUgIT09ICd4LmNvbScgJiYgdXJsLmhvc3RuYW1lICE9PSAndHdpdHRlci5jb20nKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBtYXRjaCA9IHVybC5wYXRobmFtZS5tYXRjaCgvXlxcLyhbQS1aYS16MC05X117MSwxNX0pXFwvc3RhdHVzXFwvKFxcZHsxNSwyMH0pKD86XFwvfCQpLyk7XG4gICAgaWYgKCFtYXRjaCB8fCBtYXRjaFsyXSAhPT0gdHdlZXRJZCkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIG1hdGNoWzFdID8/IG51bGw7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBpY2tIYW5kbGVGcm9tTWVkaWFQYWdlKHJhd1VybDogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAoIXJhd1VybCkgcmV0dXJuIG51bGw7XG4gIHRyeSB7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChyYXdVcmwpO1xuICAgIGlmICh1cmwuaG9zdG5hbWUgIT09ICd4LmNvbScgJiYgdXJsLmhvc3RuYW1lICE9PSAndHdpdHRlci5jb20nKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBtYXRjaCA9IHVybC5wYXRobmFtZS5tYXRjaCgvXlxcLyhbQS1aYS16MC05X117MSwxNX0pXFwvbWVkaWFcXC8/JC8pO1xuICAgIHJldHVybiBtYXRjaD8uWzFdID8/IG51bGw7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNvbGxlY3RUd2VldHMob2JqOiB1bmtub3duKTogdW5rbm93bltdIHtcbiAgLy8gV2FsayB0aGUgcmVzcG9uc2UgdHJlZSBnYXRoZXJpbmcgZXZlcnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSB0d2VldFxuICAvLyByZXN1bHQuIFdlIGxvb2sgZm9yIG5vZGVzIHNoYXBlZCBsaWtlOlxuICAvLyAgIHsgX190eXBlbmFtZT86ICdUd2VldCd8J1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJywgcmVzdF9pZCwgbGVnYWN5IH1cbiAgLy8gYW5kIHVud3JhcCB2aXNpYmlsaXR5IHdyYXBwZXJzLlxuICBjb25zdCBvdXQ6IHVua25vd25bXSA9IFtdO1xuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW29ial07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3Qgbm9kZSA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChub2RlID09PSBudWxsIHx8IG5vZGUgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHNlZW4uaGFzKG5vZGUgYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQobm9kZSBhcyBvYmplY3QpO1xuXG4gICAgaWYgKGxvb2tzTGlrZVR3ZWV0KG5vZGUpKSB7XG4gICAgICBvdXQucHVzaCh1bndyYXBUd2VldChub2RlKSk7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KG5vZGUpKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbm9kZSkgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMobm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIGxvb2tzTGlrZVR3ZWV0KG5vZGU6IHVua25vd24pOiBub2RlIGlzIFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JyB8fCBub2RlID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBjb25zdCB0eXBlbmFtZSA9IG4uX190eXBlbmFtZTtcbiAgaWYgKFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXQnIHx8XG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgfHxcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJ1xuICApIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICAvLyBTb21lIGVudHJpZXMgbGFjayBfX3R5cGVuYW1lIGJ1dCBzdGlsbCBjYXJyeSBsZWdhY3kgKyByZXN0X2lkICsgY29yZS5cbiAgcmV0dXJuIHR5cGVvZiBuLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBuLmxlZ2FjeSA9PT0gJ29iamVjdCcgJiYgbi5sZWdhY3kgIT09IG51bGw7XG59XG5cbmZ1bmN0aW9uIHVud3JhcFR3ZWV0KG5vZGU6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xuICBpZiAobm9kZS5fX3R5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnICYmIHR5cGVvZiBub2RlLnR3ZWV0ID09PSAnb2JqZWN0Jykge1xuICAgIHJldHVybiBub2RlLnR3ZWV0IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICB9XG4gIHJldHVybiBub2RlO1xufVxuXG5mdW5jdGlvbiBidWlsZFR3ZWV0KHJhdzogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogQ2Fub25pY2FsVHdlZXQgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiByYXcgIT09ICdvYmplY3QnIHx8IHJhdyA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHQgPSByYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG5cbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgcmVzdElkID0gc3RyT3JOdWxsKHQucmVzdF9pZCk7XG4gIC8vIGBsZWdhY3lgIGlzIHN0aWxsIHdoZXJlIG1vc3QgZW5nYWdlbWVudCAvIGVudGl0aWVzIGxpdmUgaW4gMjAyNi1lcmEgWFxuICAvLyBwYXlsb2FkcywgYnV0IGFzIG9mIHJlY2VudCBzY2hlbWEgbWlncmF0aW9ucyBzZXZlcmFsIGZpZWxkcyBwcmV2aW91c2x5XG4gIC8vIHRoZXJlIChub3RhYmx5IHRoZSBhdXRob3IgaGFuZGxlKSBoYXZlIG1vdmVkIHRvIHNpYmxpbmcgbG9jYXRpb25zLiBXZVxuICAvLyB0b2xlcmF0ZSBhIG1pc3NpbmcgbGVnYWN5IGhlcmUgYW5kIGxvb2sgdXAgZXZlcnl0aGluZyB2aWEgZmFsbGJhY2tzLlxuICBjb25zdCBsZWdhY3kgPSBvYmoodC5sZWdhY3kpID8/IHt9O1xuICBpZiAoIXJlc3RJZCkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgY29yZSA9IG9iaih0LmNvcmUpO1xuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihjb3JlPy51c2VyX3Jlc3VsdHMpPy5yZXN1bHQpO1xuICAvLyBBdXRob3IgaGFuZGxlOiB0cnkgdGhlIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIGZpcnN0IChjdXJyZW50IFggc2hhcGUpLFxuICAvLyB0aGVuIHRoZSBsZWdhY3kgYGxlZ2FjeS5zY3JlZW5fbmFtZWAsIHRoZW4gYSBjb3VwbGUgb2Ygb2xkZXIgdmFyaWFudHMuXG4gIGNvbnN0IHVzZXJDb3JlTmV3ID0gb2JqKHVzZXJSZXN1bHQ/LmNvcmUpO1xuICBjb25zdCB1c2VyTGVnYWN5ID0gb2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk7XG4gIGNvbnN0IHVzZXJBdmF0YXJPYmogPSBvYmoodXNlclJlc3VsdD8uYXZhdGFyKTtcbiAgY29uc3QgaGFuZGxlID1cbiAgICBzdHJPck51bGwodXNlckNvcmVOZXc/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwodXNlclJlc3VsdD8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKGxlZ2FjeS5zY3JlZW5fbmFtZSk7XG4gIGNvbnN0IGFjY291bnRJZCA9XG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnJlc3RfaWQpID8/XG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LmlkX3N0cikgPz9cbiAgICBzdHJPck51bGwobGVnYWN5LnVzZXJfaWRfc3RyKTtcbiAgaWYgKCFoYW5kbGUgfHwgIWFjY291bnRJZCkgcmV0dXJuIG51bGw7XG4gIC8vIEF1dGhvciBzbmFwc2hvdC4gRGlzcGxheSBuYW1lICsgYXZhdGFyIG1vdmVkIGJldHdlZW4gYGxlZ2FjeWAgYW5kIHRoZVxuICAvLyBuZXcgYGNvcmVgIHN1YnN0cnVjdHVyZSBvdmVyIHRpbWU7IHRoZSByZXN0ICh2ZXJpZmljYXRpb24sIGZvbGxvd2VyXG4gIC8vIGNvdW50cywgYWNjb3VudF9jcmVhdGVkX2F0KSBpcyBzdGlsbCBpbiBgbGVnYWN5YC4gV2Ugc25hcHNob3QgdGhlXG4gIC8vIHdob2xlIFVzZXJTbmFwc2hvdCBwZXIgdHdlZXQgYmVjYXVzZSB0aGVzZSB2YWx1ZXMgZHJpZnQgb3ZlciB0aW1lXG4gIC8vIGFuZCB0aGUgYXQtY2FwdHVyZSBzdGF0ZSBpcyB0aGUgb25seSByZWxpYWJsZSByZWNvcmQuXG4gIGNvbnN0IGF1dGhvciA9IGV4dHJhY3RVc2VyU25hcHNob3QodXNlclJlc3VsdCwgdXNlckNvcmVOZXcsIHVzZXJMZWdhY3ksIHVzZXJBdmF0YXJPYmopO1xuXG4gIGNvbnN0IG5vdGVUd2VldCA9IG9iaihvYmoob2JqKHQubm90ZV90d2VldCk/Lm5vdGVfdHdlZXRfcmVzdWx0cyk/LnJlc3VsdCk7XG4gIGNvbnN0IHRleHRGcm9tTm90ZSA9IHN0ck9yTnVsbChub3RlVHdlZXQ/LnRleHQpO1xuICBjb25zdCB0ZXh0RnJvbUxlZ2FjeSA9IHN0ck9yTnVsbChsZWdhY3kuZnVsbF90ZXh0KSA/PyAnJztcbiAgY29uc3QgdGV4dCA9IHRleHRGcm9tTm90ZSA/PyB0ZXh0RnJvbUxlZ2FjeTtcbiAgY29uc3QgaXNUcnVuY2F0ZWQgPSBkZXRlY3RUcnVuY2F0aW9uKG5vdGVUd2VldCwgbGVnYWN5LCB0ZXh0RnJvbUxlZ2FjeSk7XG4gIGNvbnN0IGNvbW11bml0eU5vdGUgPSBleHRyYWN0Q29tbXVuaXR5Tm90ZSh0LCBsZWdhY3ksIGN0eC5jYXB0dXJlZEF0KTtcblxuICBjb25zdCBlbnRpdGllcyA9IG9iaihsZWdhY3kuZW50aXRpZXMpID8/IHt9O1xuICBjb25zdCBlbnRpdGllc0Zyb21Ob3RlID0gb2JqKG5vdGVUd2VldD8uZW50aXR5X3NldCk7XG4gIGNvbnN0IGhhc2h0YWdzID0gZXh0cmFjdEhhc2h0YWdzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xuICBjb25zdCBtZW50aW9ucyA9IGV4dHJhY3RNZW50aW9ucyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgdXJscyA9IGV4dHJhY3RVcmxzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xuICBjb25zdCBtZWRpYSA9IGV4dHJhY3RNZWRpYShsZWdhY3kpO1xuXG4gIGNvbnN0IHR3ZWV0VHlwZSA9IGNsYXNzaWZ5VHdlZXRUeXBlKHQsIGxlZ2FjeSk7XG5cbiAgLy8gcG9zdGVkX2F0OiBsZWdhY3kuY3JlYXRlZF9hdCByZW1haW5zIHRoZSBjYW5vbmljYWwgbG9jYXRpb247IGlmIHRoYXQnc1xuICAvLyBtaXNzaW5nIGluIGEgZnV0dXJlIHNjaGVtYSB3ZSBmYWxsIGJhY2sgdG8gdG9wLWxldmVsIGNyZWF0ZWRfYXQuXG4gIGNvbnN0IHBvc3RlZEF0ID1cbiAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbChsZWdhY3kuY3JlYXRlZF9hdCkpID8/IHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHQuY3JlYXRlZF9hdCkpO1xuICBpZiAoIXBvc3RlZEF0KSByZXR1cm4gbnVsbDtcblxuICBjb25zdCB2aWV3cyA9IG9iaih0LnZpZXdzKTtcbiAgY29uc3Qgdmlld0NvdW50ID0gbnVtT3JOdWxsKHZpZXdzPy5jb3VudCkgPz8gbnVtT3JOdWxsKHN0ck9yTnVsbCh2aWV3cz8uY291bnQpKTtcblxuICBjb25zdCBjYXJkID0gZXh0cmFjdENhcmQodCk7XG4gIGNvbnN0IHBsYWNlID0gb2JqKGxlZ2FjeS5wbGFjZSk7XG5cbiAgY29uc3QgdHdlZXQ6IENhbm9uaWNhbFR3ZWV0ID0ge1xuICAgIHR3ZWV0X2lkOiByZXN0SWQsXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBhY2NvdW50X2lkOiBhY2NvdW50SWQsXG4gICAgcG9zdGVkX2F0OiBwb3N0ZWRBdCxcbiAgICBmaXJzdF9jYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgbGFzdF9zZWVuX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICBkZWxldGlvbl9kZXRlY3RlZF9hdDogbnVsbCxcbiAgICB0d2VldF91cmw6IGAke1RXRUVUX1VSTF9QUkVGSVh9LyR7aGFuZGxlfS9zdGF0dXMvJHtyZXN0SWR9YCxcbiAgICB0d2VldF90eXBlOiB0d2VldFR5cGUsXG4gICAgY29udmVyc2F0aW9uX2lkOiBzdHJPck51bGwobGVnYWN5LmNvbnZlcnNhdGlvbl9pZF9zdHIpLFxuICAgIHJlcGx5X3RvX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpLFxuICAgIHJlcGx5X3RvX2FjY291bnQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc2NyZWVuX25hbWUpLFxuICAgIHJlcGx5X3RvX2FjY291bnRfaWQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fdXNlcl9pZF9zdHIpLFxuICAgIHF1b3RlZF90d2VldF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0ciksXG4gICAgcmV0d2VldGVkX3R3ZWV0X2lkOiBzdHJPck51bGwoXG4gICAgICBvYmoob2JqKGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX3Jlc3VsdCk/LnJlc3VsdCk/LnJlc3RfaWQgPz9cbiAgICAgICAgKGxlZ2FjeSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikucmV0d2VldGVkX3N0YXR1c19pZF9zdHJcbiAgICApLFxuICAgIHRleHQsXG4gICAgdGV4dF9yZXNvbHZlZDogcmVzb2x2ZVNob3J0VXJscyh0ZXh0LCB1cmxzKSxcbiAgICBsYW5nOiBzdHJPck51bGwobGVnYWN5LmxhbmcpLFxuICAgIHBvc3NpYmx5X3NlbnNpdGl2ZTogYm9vbE9yTnVsbChsZWdhY3kucG9zc2libHlfc2Vuc2l0aXZlKSxcbiAgICBzb3VyY2U6IHN0ck9yTnVsbChsZWdhY3kuc291cmNlKSA/PyBzdHJPck51bGwodC5zb3VyY2UpLFxuICAgIHBsYWNlX2Z1bGxfbmFtZTogc3RyT3JOdWxsKHBsYWNlPy5mdWxsX25hbWUpLFxuICAgIGhhc2h0YWdzLFxuICAgIG1lbnRpb25zLFxuICAgIHVybHMsXG4gICAgY2FyZCxcbiAgICBtZWRpYSxcbiAgICBsaWtlX2NvdW50OiBudW1Pclplcm8obGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcbiAgICByZXR3ZWV0X2NvdW50OiBudW1Pclplcm8obGVnYWN5LnJldHdlZXRfY291bnQpLFxuICAgIHJlcGx5X2NvdW50OiBudW1Pclplcm8obGVnYWN5LnJlcGx5X2NvdW50KSxcbiAgICBxdW90ZV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5xdW90ZV9jb3VudCksXG4gICAgdmlld19jb3VudDogdmlld0NvdW50LFxuICAgIGJvb2ttYXJrX2NvdW50OiBudW1Pck51bGwobGVnYWN5LmJvb2ttYXJrX2NvdW50KSxcbiAgICBlbmdhZ2VtZW50X2hpc3Rvcnk6IFtcbiAgICAgIHtcbiAgICAgICAgY2FwdHVyZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxuICAgICAgICBsaWtlczogbnVtT3JaZXJvKGxlZ2FjeS5mYXZvcml0ZV9jb3VudCksXG4gICAgICAgIHJldHdlZXRzOiBudW1Pclplcm8obGVnYWN5LnJldHdlZXRfY291bnQpLFxuICAgICAgICByZXBsaWVzOiBudW1Pclplcm8obGVnYWN5LnJlcGx5X2NvdW50KSxcbiAgICAgICAgcXVvdGVzOiBudW1Pclplcm8obGVnYWN5LnF1b3RlX2NvdW50KSxcbiAgICAgICAgdmlld3M6IHZpZXdDb3VudCxcbiAgICAgICAgYm9va21hcmtzOiBudW1Pck51bGwobGVnYWN5LmJvb2ttYXJrX2NvdW50KSxcbiAgICAgIH0sXG4gICAgXSxcbiAgICBhdXRob3IsXG4gICAgY29tbXVuaXR5X25vdGU6IGNvbW11bml0eU5vdGUsXG4gICAgaXNfdHJ1bmNhdGVkOiBpc1RydW5jYXRlZCxcbiAgICB3YXliYWNrX3VybDogbnVsbCxcbiAgICB3YXliYWNrX3N1Ym1pdHRlZF9hdDogbnVsbCxcbiAgICBjYXB0dXJlX3NvdXJjZTogJ2V4dGVuc2lvbicsXG4gICAgY2FwdHVyZV9ydW5faWQ6IGN0eC5ydW5JZCxcbiAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgfTtcblxuICByZXR1cm4gdHdlZXQ7XG59XG5cbmZ1bmN0aW9uIGNsYXNzaWZ5VHdlZXRUeXBlKHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVHdlZXRUeXBlIHtcbiAgaWYgKGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX3Jlc3VsdCB8fCBsZWdhY3kucmV0d2VldGVkX3N0YXR1c19pZF9zdHIpIHJldHVybiAncmV0d2VldCc7XG4gIGlmIChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXBseSc7XG4gIGlmIChsZWdhY3kuaXNfcXVvdGVfc3RhdHVzID09PSB0cnVlIHx8IGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdxdW90ZSc7XG4gIGlmICh0Ll9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycpIHtcbiAgICAvLyBwYXNzIHRocm91Z2hcbiAgfVxuICByZXR1cm4gJ29yaWdpbmFsJztcbn1cblxuZnVuY3Rpb24gZXh0cmFjdEhhc2h0YWdzKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZ1tdIHtcbiAgY29uc3QgYXJyID0gZW50aXRpZXMuaGFzaHRhZ3M7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XG4gIHJldHVybiBhcnJcbiAgICAubWFwKChoKSA9PlxuICAgICAgdHlwZW9mIGggPT09ICdvYmplY3QnICYmIGggJiYgJ3RleHQnIGluIGggPyBTdHJpbmcoKGggYXMgeyB0ZXh0OiB1bmtub3duIH0pLnRleHQpIDogbnVsbFxuICAgIClcbiAgICAuZmlsdGVyKChzKTogcyBpcyBzdHJpbmcgPT4gdHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHMubGVuZ3RoID4gMCk7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RNZW50aW9ucyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLnVzZXJfbWVudGlvbnM7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XG4gIHJldHVybiBhcnJcbiAgICAubWFwKCh1KSA9PlxuICAgICAgdHlwZW9mIHUgPT09ICdvYmplY3QnICYmIHUgJiYgJ3NjcmVlbl9uYW1lJyBpbiB1XG4gICAgICAgID8gU3RyaW5nKCh1IGFzIHsgc2NyZWVuX25hbWU6IHVua25vd24gfSkuc2NyZWVuX25hbWUpXG4gICAgICAgIDogbnVsbFxuICAgIClcbiAgICAuZmlsdGVyKChzKTogcyBpcyBzdHJpbmcgPT4gdHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHMubGVuZ3RoID4gMCk7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RVcmxzKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFVybEVudGl0eVtdIHtcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXJscztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgY29uc3Qgb3V0OiBVcmxFbnRpdHlbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHUgb2YgYXJyKSB7XG4gICAgaWYgKHR5cGVvZiB1ICE9PSAnb2JqZWN0JyB8fCB1ID09PSBudWxsKSBjb250aW51ZTtcbiAgICBjb25zdCBvID0gdSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICBjb25zdCBzaG9ydCA9IHN0ck9yTnVsbChvLnVybCk7XG4gICAgY29uc3QgZXhwYW5kZWQgPSBzdHJPck51bGwoby5leHBhbmRlZF91cmwpO1xuICAgIGNvbnN0IGRpc3BsYXkgPSBzdHJPck51bGwoby5kaXNwbGF5X3VybCk7XG4gICAgaWYgKCFzaG9ydCB8fCAhZXhwYW5kZWQpIGNvbnRpbnVlO1xuICAgIG91dC5wdXNoKHsgc2hvcnQsIGV4cGFuZGVkLCBkaXNwbGF5OiBkaXNwbGF5ID8/IGV4cGFuZGVkIH0pO1xuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RNZWRpYShsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogTWVkaWFJdGVtW10ge1xuICBjb25zdCBleHRlbmRlZCA9IG9iaihsZWdhY3kuZXh0ZW5kZWRfZW50aXRpZXMpO1xuICBjb25zdCBmcm9tRXh0ID0gZXh0ZW5kZWQgPyB0b0FycmF5KGV4dGVuZGVkLm1lZGlhKSA6IFtdO1xuICBjb25zdCBmcm9tRW50ID0gdG9BcnJheShvYmoobGVnYWN5LmVudGl0aWVzKT8ubWVkaWEpO1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IG1lcmdlZCA9IFsuLi5mcm9tRXh0LCAuLi5mcm9tRW50XS5maWx0ZXIoKG0pID0+IHtcbiAgICBpZiAodHlwZW9mIG0gIT09ICdvYmplY3QnIHx8IG0gPT09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBpZCA9XG4gICAgICBzdHJPck51bGwoKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLm1lZGlhX2tleSkgPz9cbiAgICAgIHN0ck9yTnVsbCgobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuaWRfc3RyKTtcbiAgICBpZiAoIWlkKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKHNlZW4uaGFzKGlkKSkgcmV0dXJuIGZhbHNlO1xuICAgIHNlZW4uYWRkKGlkKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSk7XG4gIHJldHVybiBtZXJnZWQubWFwKChyYXcpID0+IGJ1aWxkTWVkaWEocmF3IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSk7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkTWVkaWEobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW0ge1xuICBjb25zdCB0eXBlID0gc3RyT3JOdWxsKG0udHlwZSkgYXMgTWVkaWFJdGVtWydtZWRpYV90eXBlJ107XG4gIGNvbnN0IG9yaWdpbmFsID0gcGlja09yaWdpbmFsVXJsKG0sIHR5cGUpO1xuICBjb25zdCBpbmZvID0gb2JqKG0ub3JpZ2luYWxfaW5mbyk7XG4gIGNvbnN0IHZpZGVvSW5mbyA9IG9iaihtLnZpZGVvX2luZm8pO1xuICBjb25zdCBkdXJhdGlvbk1zID0gbnVtT3JOdWxsKHZpZGVvSW5mbz8uZHVyYXRpb25fbWlsbGlzKTtcbiAgY29uc3QgYWx0VGV4dCA9IHN0ck9yTnVsbChtLmV4dF9hbHRfdGV4dCk7XG4gIGNvbnN0IG1lZGlhSWQgPVxuICAgIHN0ck9yTnVsbChtLm1lZGlhX2tleSkgPz9cbiAgICBzdHJPck51bGwobS5pZF9zdHIpID8/XG4gICAgYCR7dHlwZSA/PyAnbWVkaWEnfS0ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIpfWA7XG4gIHJldHVybiB7XG4gICAgbWVkaWFfaWQ6IG1lZGlhSWQsXG4gICAgbWVkaWFfdHlwZTogKHR5cGUgPz8gJ3Bob3RvJykgYXMgTWVkaWFJdGVtWydtZWRpYV90eXBlJ10sXG4gICAgb3JpZ2luYWxfdXJsOiBvcmlnaW5hbCA/PyAnJyxcbiAgICByZWxlYXNlX2Fzc2V0X3VybDogbnVsbCxcbiAgICBzaGEyNTY6IG51bGwsXG4gICAgYnl0ZXM6IG51bGwsXG4gICAgZHVyYXRpb25fc2VjOiBkdXJhdGlvbk1zICE9PSBudWxsID8gZHVyYXRpb25NcyAvIDEwMDAgOiBudWxsLFxuICAgIHdpZHRoOiBudW1Pck51bGwoaW5mbz8ud2lkdGgpLFxuICAgIGhlaWdodDogbnVtT3JOdWxsKGluZm8/LmhlaWdodCksXG4gICAgYWx0X3RleHQ6IGFsdFRleHQsXG4gICAgYXJjaGl2ZV9zdGF0dXM6ICdwZW5kaW5nJyxcbiAgICBhcmNoaXZlX2F0dGVtcHRzOiAwLFxuICAgIGxhc3RfYXR0ZW1wdF9hdDogbnVsbCxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcGlja09yaWdpbmFsVXJsKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+LCB0eXBlOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICh0eXBlID09PSAncGhvdG8nKSByZXR1cm4gc3RyT3JOdWxsKG0ubWVkaWFfdXJsX2h0dHBzKSA/PyBzdHJPck51bGwobS5tZWRpYV91cmwpO1xuICBjb25zdCB2YXJpYW50cyA9IHRvQXJyYXkob2JqKG0udmlkZW9faW5mbyk/LnZhcmlhbnRzKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPltdO1xuICBpZiAodmFyaWFudHMubGVuZ3RoID09PSAwKSByZXR1cm4gc3RyT3JOdWxsKG0ubWVkaWFfdXJsX2h0dHBzKTtcbiAgLy8gSGlnaGVzdC1iaXRyYXRlIG1wNC5cbiAgbGV0IGJlc3Q6IHsgdXJsOiBzdHJpbmc7IGJpdHJhdGU6IG51bWJlciB9IHwgbnVsbCA9IG51bGw7XG4gIGZvciAoY29uc3QgdiBvZiB2YXJpYW50cykge1xuICAgIGNvbnN0IGN0ID0gc3RyT3JOdWxsKHYuY29udGVudF90eXBlKTtcbiAgICBjb25zdCB1cmwgPSBzdHJPck51bGwodi51cmwpO1xuICAgIGlmICghdXJsKSBjb250aW51ZTtcbiAgICBpZiAoY3QgPT09ICd2aWRlby9tcDQnKSB7XG4gICAgICBjb25zdCBiciA9IG51bU9yTnVsbCh2LmJpdHJhdGUpID8/IDA7XG4gICAgICBpZiAoIWJlc3QgfHwgYnIgPiBiZXN0LmJpdHJhdGUpIGJlc3QgPSB7IHVybCwgYml0cmF0ZTogYnIgfTtcbiAgICB9IGVsc2UgaWYgKCFiZXN0KSB7XG4gICAgICAvLyBGYWxsYmFjayB0byBhbnkgdmFyaWFudCBpZiBubyBtcDQgZm91bmQuXG4gICAgICBiZXN0ID0geyB1cmwsIGJpdHJhdGU6IDAgfTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGJlc3Q/LnVybCA/PyBudWxsO1xufVxuXG5mdW5jdGlvbiByZXNvbHZlU2hvcnRVcmxzKHRleHQ6IHN0cmluZywgdXJsczogVXJsRW50aXR5W10pOiBzdHJpbmcge1xuICBpZiAodXJscy5sZW5ndGggPT09IDApIHJldHVybiB0ZXh0O1xuICBsZXQgb3V0ID0gdGV4dDtcbiAgZm9yIChjb25zdCB1IG9mIHVybHMpIG91dCA9IG91dC5zcGxpdCh1LnNob3J0KS5qb2luKHUuZXhwYW5kZWQpO1xuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBwYXJzZVR3aXR0ZXJEYXRlKHM6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKCFzKSByZXR1cm4gbnVsbDtcbiAgLy8gVHdpdHRlciBzaGlwcyBkYXRlcyBsaWtlIFwiTW9uIEFwciAxMiAxNDoyMzowMSArMDAwMCAyMDI1XCIuXG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShzKTtcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBudWxsO1xuICByZXR1cm4gZC50b0lTT1N0cmluZygpO1xufVxuXG5mdW5jdGlvbiBzdHJPck51bGwodjogdW5rbm93bik6IHN0cmluZyB8IG51bGwge1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCA/IHYgOiBudWxsO1xufVxuZnVuY3Rpb24gYm9vbE9yTnVsbCh2OiB1bmtub3duKTogYm9vbGVhbiB8IG51bGwge1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdib29sZWFuJyA/IHYgOiBudWxsO1xufVxuZnVuY3Rpb24gbnVtT3JOdWxsKHY6IHVua25vd24pOiBudW1iZXIgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyAmJiBOdW1iZXIuaXNGaW5pdGUodikpIHJldHVybiB2O1xuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG4gPSBOdW1iZXIodik7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShuKSkgcmV0dXJuIG47XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBudW1Pclplcm8odjogdW5rbm93bik6IG51bWJlciB7XG4gIHJldHVybiBudW1Pck51bGwodikgPz8gMDtcbn1cbmZ1bmN0aW9uIG9iaih2OiB1bmtub3duKTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsIHtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnb2JqZWN0JyAmJiB2ICE9PSBudWxsICYmICFBcnJheS5pc0FycmF5KHYpXG4gICAgPyAodiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilcbiAgICA6IG51bGw7XG59XG5mdW5jdGlvbiB0b0FycmF5KHY6IHVua25vd24pOiB1bmtub3duW10ge1xuICByZXR1cm4gQXJyYXkuaXNBcnJheSh2KSA/IHYgOiBbXTtcbn1cblxuLyoqXG4gKiBEZWNpZGUgd2hldGhlciBhIHR3ZWV0J3MgYXJjaGl2ZWQgYHRleHRgIGlzIHRoZSB0cnVuY2F0ZWQgaGVhZCBvZiBhIGxvbmdlclxuICogYm9keS4gQSB0cnVuY2F0ZWQgdHdlZXQgaGFzIFgncyBcIlNob3cgbW9yZVwiIHQuY28gVVJMIGFwcGVuZGVkIFx1MjAxNCB0aGF0IFVSTFxuICogc3BlY2lmaWNhbGx5IGV4cGFuZHMgdG8gdGhlIHR3ZWV0J3Mgb3duIC9pL3dlYi9zdGF0dXMvPGlkPiBwZXJtYWxpbmssIGFuZFxuICogaXMgdGhlIG9ubHkgcmVsaWFibGUgZGlzdGluZ3Vpc2hpbmcgZmVhdHVyZS4gUGxlbnR5IG9mIG5vcm1hbCB0d2VldHMgaGF2ZVxuICogdHJhaWxpbmcgdC5jbyBVUkxzIChtZWRpYSwgcXVvdGVzLCByZWd1bGFyIGxpbmtzKSwgYW5kIHRoZWlyXG4gKiBkaXNwbGF5X3RleHRfcmFuZ2UgYWxzbyB0cmltcyBwYXN0IGZ1bGxfdGV4dC5sZW5ndGgsIHNvIHRoZSBvbGRcbiAqIFwiZGlzcGxheV90ZXh0X3JhbmdlWzFdIDwgZnVsbF90ZXh0Lmxlbmd0aFwiIGhldXJpc3RpYyB3YXMgb3ZlcmZsYWdnaW5nXG4gKiBlc3NlbnRpYWxseSBldmVyeSB0d2VldCB3aXRoIGEgbGluayBpbiBpdC5cbiAqXG4gKiBSdWxlczpcbiAqICAgLSBub3RlX3R3ZWV0IHByZXNlbnQgIFx1MjE5MiBub3QgdHJ1bmNhdGVkICh3ZSBhbHJlYWR5IGhhdmUgdGhlIGZ1bGwgYm9keSkuXG4gKiAgIC0gT25lIG9mIGxlZ2FjeS5lbnRpdGllcy51cmxzIGhhcyBhbiBleHBhbmRlZF91cmwgbGlrZVxuICogICAgIFwiLi4uL2kvd2ViL3N0YXR1cy88aWQ+XCIgIFx1MjE5MiAgdHJ1bmNhdGVkLlxuICogICAtIE90aGVyd2lzZSBcdTIxOTIgbm90IHRydW5jYXRlZC5cbiAqXG4gKiBUaGUgcHJldmlvdXMgZmFsbGJhY2sgKFwidHJhaWxpbmcgdC5jbyBVUkwgKyBsZW5ndGggXHUyMjY1IDI3MFwiKSBmbGFnZ2VkIGV2ZXJ5XG4gKiBtZWRpYSB0d2VldCBleGFjdGx5IGF0IHRoZSAyODAtY2hhciBsaW1pdC4gV2UgZHJvcCBpdCBlbnRpcmVseTsgdGhlIG9ubHlcbiAqIGNvc3QgaXMgbWlzc2luZyBnZW51aW5lbHktdHJ1bmNhdGVkIHR3ZWV0cyB3aG9zZSBwYXlsb2FkIHdhcyBzbyBkZWdyYWRlZFxuICogaXQgbGFja2VkIGVudGl0aWVzIFx1MjAxNCB3aGljaCBpcyBhbHNvIHdoZXJlIHRoZSByZWZldGNoIGxvb3Agd291bGQgZmFpbFxuICogYW55d2F5LCBzbyBub3RoaW5nIGlzIGFjdHVhbGx5IGxvc3QuXG4gKi9cbmZ1bmN0aW9uIGRldGVjdFRydW5jYXRpb24oXG4gIG5vdGVUd2VldDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxuICBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICBmdWxsVGV4dDogc3RyaW5nXG4pOiBib29sZWFuIHtcbiAgaWYgKG5vdGVUd2VldCkgcmV0dXJuIGZhbHNlO1xuICBpZiAoIWZ1bGxUZXh0KSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGVudGl0aWVzID0gb2JqKGxlZ2FjeS5lbnRpdGllcyk7XG4gIGNvbnN0IHVybHMgPSBlbnRpdGllcyA/IGVudGl0aWVzLnVybHMgOiBudWxsO1xuICBpZiAoQXJyYXkuaXNBcnJheSh1cmxzKSkge1xuICAgIGZvciAoY29uc3QgdSBvZiB1cmxzKSB7XG4gICAgICBpZiAodHlwZW9mIHUgIT09ICdvYmplY3QnIHx8IHUgPT09IG51bGwpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgZXhwID0gKHUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLmV4cGFuZGVkX3VybDtcbiAgICAgIC8vIFRoZSBcIlNob3cgbW9yZVwiIGxpbmsgZXhwYW5kcyB0byBlaXRoZXIgb2YgdGhlc2Ugc2VsZi1wZXJtYWxpbmtcbiAgICAgIC8vIHNoYXBlczogIGh0dHBzOi8veC5jb20vaS93ZWIvc3RhdHVzLzxpZD5cbiAgICAgIC8vICAgICAgICAgIGh0dHBzOi8vdHdpdHRlci5jb20vaS93ZWIvc3RhdHVzLzxpZD5cbiAgICAgIGlmICh0eXBlb2YgZXhwID09PSAnc3RyaW5nJyAmJiAvXFwvaVxcL3dlYlxcL3N0YXR1c1xcL1xcZCsvLnRlc3QoZXhwKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vKipcbiAqIEZpbHRlciBgdHdlZXRzYCBkb3duIHRvIHRob3NlIHJlbGF0ZWQgdG8gYSB0cmFja2VkIGFjY291bnQuIEEgdHdlZXQgaXNcbiAqIFwicmVsYXRlZFwiIGlmIGFueSBvZiB0aGUgZm9sbG93aW5nIGhvbGQ6XG4gKlxuICogICAtIGl0cyBhdXRob3IgaXMgdHJhY2tlZCAoaGFuZGxlIGluIGB0YXJnZXRlZGApLFxuICogICAtIGl0IG1lbnRpb25zIGEgdHJhY2tlZCBoYW5kbGUsXG4gKiAgIC0gaXQgcmVwbGllcyB0byBhIHRyYWNrZWQgYWNjb3VudCxcbiAqICAgLSBpdCBxdW90ZXMvcmV0d2VldHMvcmVwbGllcy10byBhIHR3ZWV0IHRoYXQncyBhbHNvIHByZXNlbnQgaW4gdGhlXG4gKiAgICAgYmF0Y2ggKmFuZCogYXV0aG9yZWQgYnkgYSB0cmFja2VkIGFjY291bnQgKHRyYW5zaXRpdmVseSByZWxhdGVkIFx1MjAxNFxuICogICAgIGNhcHR1cmVzIHRoZSBxdW90ZWQvUlQnZCBjb250ZW50IHRoYXQgYXBwZWFycyBhcyBhIHNpYmxpbmcgbm9kZSBpblxuICogICAgIHRoZSBzYW1lIEdyYXBoUUwgcmVzcG9uc2UpLlxuICpcbiAqIEFueXRoaW5nIGVsc2UgKHJhbmRvbSByZXBsaWVzIHVuZGVyIGEgdHJhY2tlZCBhY2NvdW50J3MgdHdlZXQsIHJhbmRvbVxuICogYXV0aG9ycyB0aGF0IGhhcHBlbiB0byBzdXJmYWNlIGluIGEgdHJhY2tlZCBhY2NvdW50J3MgdGhyZWFkKSBpcyBkcm9wcGVkLlxuICogUGFzcyBhbiBlbXB0eSBgdGFyZ2V0ZWRgIHNldCB0byBkaXNhYmxlIGZpbHRlcmluZyBlbnRpcmVseS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZpbHRlclJlbGF0ZWQoXG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSxcbiAgdGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz5cbik6IENhbm9uaWNhbFR3ZWV0W10ge1xuICBpZiAodGFyZ2V0ZWQuc2l6ZSA9PT0gMCkgcmV0dXJuIHR3ZWV0cztcbiAgLy8gRmlyc3QgcGFzczogd2hpY2ggdHdlZXQgSURzIGRvIHRyYWNrZWQtYXV0aG9yIHR3ZWV0cyByZWZlcmVuY2UgKHRoZVxuICAvLyBcImZvcndhcmRcIiBkaXJlY3Rpb24gXHUyMDE0IHRyYWNrZWQgYWNjb3VudCBxdW90ZXMgLyBSVHMgLyByZXBsaWVzIHRvIFgpP1xuICAvLyBBbmQgd2hpY2ggdHdlZXQgSURzIEFSRSB0cmFja2VkLWF1dGhvcmVkICh0aGUgXCJyZXZlcnNlXCIgZGlyZWN0aW9uIFx1MjAxNFxuICAvLyBYIHF1b3RlcyAvIFJUcyAvIHJlcGxpZXMgdG8gYSB0cmFja2VkIHR3ZWV0KT9cbiAgY29uc3QgcmVmZXJlbmNlZElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCB0YXJnZXRlZFR3ZWV0SWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICBpZiAoIXRhcmdldGVkLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSBjb250aW51ZTtcbiAgICB0YXJnZXRlZFR3ZWV0SWRzLmFkZCh0LnR3ZWV0X2lkKTtcbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucXVvdGVkX3R3ZWV0X2lkKTtcbiAgICBpZiAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucmV0d2VldGVkX3R3ZWV0X2lkKTtcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5yZXBseV90b190d2VldF9pZCk7XG4gIH1cbiAgcmV0dXJuIHR3ZWV0cy5maWx0ZXIoKHQpID0+IHtcbiAgICBjb25zdCBoID0gdC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmICh0YXJnZXRlZC5oYXMoaCkpIHJldHVybiB0cnVlO1xuICAgIC8vIEZvcndhcmQ6IGEgdHJhY2tlZC1hdXRob3IgdHdlZXQgcG9pbnRlZCBhdCB0aGlzIG9uZS5cbiAgICBpZiAocmVmZXJlbmNlZElkcy5oYXModC50d2VldF9pZCkpIHJldHVybiB0cnVlO1xuICAgIC8vIFJldmVyc2U6IHRoaXMgdHdlZXQgcG9pbnRzIGF0IGEgdHJhY2tlZC1hdXRob3IgdHdlZXQgaW4gdGhlIGJhdGNoLlxuICAgIGlmICh0LnF1b3RlZF90d2VldF9pZCAmJiB0YXJnZXRlZFR3ZWV0SWRzLmhhcyh0LnF1b3RlZF90d2VldF9pZCkpIHJldHVybiB0cnVlO1xuICAgIGlmICh0LnJldHdlZXRlZF90d2VldF9pZCAmJiB0YXJnZXRlZFR3ZWV0SWRzLmhhcyh0LnJldHdlZXRlZF90d2VldF9pZCkpIHJldHVybiB0cnVlO1xuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucmVwbHlfdG9fdHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcbiAgICAvLyBSZXBseS10by1hY2NvdW50IG9yIG1lbnRpb25zIGEgdHJhY2tlZCBoYW5kbGUuXG4gICAgaWYgKHQucmVwbHlfdG9fYWNjb3VudCAmJiB0YXJnZXRlZC5oYXModC5yZXBseV90b19hY2NvdW50LnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gdHJ1ZTtcbiAgICBmb3IgKGNvbnN0IG0gb2YgdC5tZW50aW9ucykge1xuICAgICAgaWYgKHRhcmdldGVkLmhhcyhtLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9KTtcbn1cblxuLyoqXG4gKiBQdWxsIHRoZSBDb21tdW5pdHkgTm90ZSAoZm9ybWVybHkgQmlyZHdhdGNoKSBibG9jayBhdHRhY2hlZCB0byBhIHR3ZWV0LCBpZlxuICogYW55LiBUaGUgcGl2b3QgY2FuIGxpdmUgYXQgYHR3ZWV0LmxlZ2FjeS5iaXJkd2F0Y2hfcGl2b3RgIChvbGRlciBzaGFwZSkgb3JcbiAqIGB0d2VldC5iaXJkd2F0Y2hfcGl2b3RgIChjdXJyZW50IHNoYXBlKS4gVGhlIHN1bW1hcnkgdGV4dCBpcyB3aGF0IHJlYWRlcnNcbiAqIGFjdHVhbGx5IHNlZTsgd2Uga2VlcCB0aGUgc3Vycm91bmRpbmcgbWV0YWRhdGEgc28gZG93bnN0cmVhbSB0b29saW5nIGNhblxuICogdGVsbCBkcmFmdHMgYXBhcnQgZnJvbSByYXRlZC1oZWxwZnVsIG5vdGVzLlxuICovXG5mdW5jdGlvbiBleHRyYWN0Q29tbXVuaXR5Tm90ZShcbiAgdDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gIG9ic2VydmVkQXQ6IHN0cmluZ1xuKTogQ29tbXVuaXR5Tm90ZSB8IG51bGwge1xuICBjb25zdCBwaXZvdCA9IG9iaih0LmJpcmR3YXRjaF9waXZvdCkgPz8gb2JqKGxlZ2FjeS5iaXJkd2F0Y2hfcGl2b3QpO1xuICBpZiAoIXBpdm90KSByZXR1cm4gbnVsbDtcbiAgY29uc3Qgc3VidGl0bGUgPSBvYmoocGl2b3Quc3VidGl0bGUpO1xuICBjb25zdCBub3RlID0gb2JqKHBpdm90Lm5vdGUpO1xuICBjb25zdCBzdW1tYXJ5ID0gc3RyT3JOdWxsKHN1YnRpdGxlPy50ZXh0KTtcbiAgY29uc3QgdGl0bGUgPSBzdHJPck51bGwocGl2b3QudGl0bGUpO1xuICBjb25zdCBzaG9ydFRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnNob3J0VGl0bGUpO1xuICBjb25zdCBkZXN0aW5hdGlvblVybCA9IHN0ck9yTnVsbChwaXZvdC5kZXN0aW5hdGlvblVybCk7XG4gIGNvbnN0IG5vdGVJZCA9IHN0ck9yTnVsbChwaXZvdC5ub3RlSWQpID8/IHN0ck9yTnVsbChub3RlPy5yZXN0X2lkKTtcbiAgLy8gU2tpcCBlbXB0eSBzaGVsbHMgdGhhdCBoYXZlIG5vIGFjdHVhbCBjb250ZW50LlxuICBpZiAoIXN1bW1hcnkgJiYgIXRpdGxlICYmICFub3RlSWQpIHJldHVybiBudWxsO1xuICByZXR1cm4ge1xuICAgIG5vdGVfaWQ6IG5vdGVJZCxcbiAgICB0aXRsZSxcbiAgICBzaG9ydF90aXRsZTogc2hvcnRUaXRsZSxcbiAgICBzdW1tYXJ5LFxuICAgIGRlc3RpbmF0aW9uX3VybDogZGVzdGluYXRpb25VcmwsXG4gICAgb2JzZXJ2ZWRfYXQ6IG9ic2VydmVkQXQsXG4gIH07XG59XG5cbi8qKlxuICogUHVsbCBhIHBlci1hdXRob3IgVXNlclNuYXBzaG90IGZyb20gdGhlIHR3ZWV0J3MgdXNlcl9yZXN1bHRzIG5vZGUuIEV2ZXJ5XG4gKiBmaWVsZCBkZWZhdWx0cyB0byBudWxsIHdoZW4gbWlzc2luZyBzbyB0aGUgc2NoZW1hIHN0YXlzIHN0YWJsZSBhY3Jvc3NcbiAqIHRoZSBsZWdhY3kgLyBjb3JlIHNoYXBlIG1pZ3JhdGlvbnMgWCBoYXMgYmVlbiBkb2luZy5cbiAqL1xuZnVuY3Rpb24gZXh0cmFjdFVzZXJTbmFwc2hvdChcbiAgdXNlclJlc3VsdDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxuICB1c2VyQ29yZU5ldzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxuICB1c2VyTGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIHVzZXJBdmF0YXJPYmo6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbFxuKTogVXNlclNuYXBzaG90IHtcbiAgY29uc3QgdmVyaWZpY2F0aW9uID0gb2JqKHVzZXJSZXN1bHQ/LnZlcmlmaWNhdGlvbik7XG4gIHJldHVybiB7XG4gICAgZGlzcGxheV9uYW1lOlxuICAgICAgc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5uYW1lKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8ubmFtZSkgPz8gc3RyT3JOdWxsKHVzZXJSZXN1bHQ/Lm5hbWUpLFxuICAgIGF2YXRhcl91cmw6XG4gICAgICBzdHJPck51bGwodXNlckF2YXRhck9iaj8uaW1hZ2VfdXJsKSA/P1xuICAgICAgc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzKSA/P1xuICAgICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzKSxcbiAgICB2ZXJpZmllZDogYm9vbE9yTnVsbCh2ZXJpZmljYXRpb24/LnZlcmlmaWVkKSA/PyBib29sT3JOdWxsKHVzZXJMZWdhY3k/LnZlcmlmaWVkKSxcbiAgICBpc19ibHVlX3ZlcmlmaWVkOiBib29sT3JOdWxsKHVzZXJSZXN1bHQ/LmlzX2JsdWVfdmVyaWZpZWQpLFxuICAgIHZlcmlmaWVkX3R5cGU6IHN0ck9yTnVsbCh2ZXJpZmljYXRpb24/LnZlcmlmaWVkX3R5cGUpID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py52ZXJpZmllZF90eXBlKSxcbiAgICBkZXNjcmlwdGlvbjogc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmRlc2NyaXB0aW9uKSxcbiAgICBsb2NhdGlvbjogc3RyT3JOdWxsKG9iaih1c2VyUmVzdWx0Py5sb2NhdGlvbik/LmxvY2F0aW9uKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8ubG9jYXRpb24pLFxuICAgIHVybDogc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnVybCksXG4gICAgZm9sbG93ZXJzX2NvdW50OiBudW1Pck51bGwodXNlckxlZ2FjeT8uZm9sbG93ZXJzX2NvdW50KSxcbiAgICBmcmllbmRzX2NvdW50OiBudW1Pck51bGwodXNlckxlZ2FjeT8uZnJpZW5kc19jb3VudCksXG4gICAgc3RhdHVzZXNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5zdGF0dXNlc19jb3VudCksXG4gICAgYWNjb3VudF9jcmVhdGVkX2F0OlxuICAgICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodXNlckNvcmVOZXc/LmNyZWF0ZWRfYXQpKSA/P1xuICAgICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodXNlckxlZ2FjeT8uY3JlYXRlZF9hdCkpLFxuICAgIHByb3RlY3RlZDogYm9vbE9yTnVsbCh1c2VyTGVnYWN5Py5wcm90ZWN0ZWQpLFxuICB9O1xufVxuXG4vKipcbiAqIFdhbGsgdGhlIHR3ZWV0J3MgYGNhcmQubGVnYWN5LmJpbmRpbmdfdmFsdWVzYCAoa2V5L3ZhbHVlIGFycmF5KSBpbnRvIGFcbiAqIGZsYXQgVHdlZXRDYXJkIHdpdGggdGl0bGUsIGRlc2NyaXB0aW9uLCBhbmQgYSByZXByZXNlbnRhdGl2ZSBpbWFnZSBVUkwuXG4gKiBSZXR1cm5zIG51bGwgd2hlbiB0aGUgdHdlZXQgaGFzIG5vIGNhcmQuXG4gKi9cbmZ1bmN0aW9uIGV4dHJhY3RDYXJkKHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVHdlZXRDYXJkIHwgbnVsbCB7XG4gIGNvbnN0IGNhcmQgPSBvYmoodC5jYXJkKTtcbiAgY29uc3QgY2FyZExlZ2FjeSA9IG9iaihjYXJkPy5sZWdhY3kpO1xuICBpZiAoIWNhcmRMZWdhY3kpIHJldHVybiBudWxsO1xuICBjb25zdCBiaW5kaW5ncyA9IGNhcmRMZWdhY3kuYmluZGluZ192YWx1ZXM7XG4gIGNvbnN0IGJ5S2V5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBpZiAoQXJyYXkuaXNBcnJheShiaW5kaW5ncykpIHtcbiAgICBmb3IgKGNvbnN0IGJ2IG9mIGJpbmRpbmdzKSB7XG4gICAgICBpZiAodHlwZW9mIGJ2ICE9PSAnb2JqZWN0JyB8fCBidiA9PT0gbnVsbCkgY29udGludWU7XG4gICAgICBjb25zdCBvID0gYnYgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBjb25zdCBrID0gc3RyT3JOdWxsKG8ua2V5KTtcbiAgICAgIGNvbnN0IHYgPSBvYmooby52YWx1ZSk7XG4gICAgICBpZiAoIWsgfHwgIXYpIGNvbnRpbnVlO1xuICAgICAgYnlLZXlba10gPVxuICAgICAgICBzdHJPck51bGwodi5zdHJpbmdfdmFsdWUpID8/XG4gICAgICAgIHN0ck9yTnVsbChvYmoodi5pbWFnZV92YWx1ZSk/LnVybCkgPz9cbiAgICAgICAgc3RyT3JOdWxsKG9iaih2LmltYWdlX2NvbG9yX3ZhbHVlKT8ucGFsZXR0ZSk7XG4gICAgfVxuICB9XG4gIGNvbnN0IG5hbWUgPSBzdHJPck51bGwoY2FyZExlZ2FjeS5uYW1lKTtcbiAgY29uc3QgY2FyZFVybCA9IHN0ck9yTnVsbChjYXJkTGVnYWN5LnVybCk7XG4gIGNvbnN0IHZlbmRvclVybCA9XG4gICAgdHlwZW9mIGJ5S2V5Wyd2YW5pdHlfdXJsJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5Wyd2YW5pdHlfdXJsJ10gYXMgc3RyaW5nKSA6IG51bGw7XG4gIGNvbnN0IHRpdGxlID0gdHlwZW9mIGJ5S2V5Wyd0aXRsZSddID09PSAnc3RyaW5nJyA/IChieUtleVsndGl0bGUnXSBhcyBzdHJpbmcpIDogbnVsbDtcbiAgY29uc3QgZGVzY3JpcHRpb24gPVxuICAgIHR5cGVvZiBieUtleVsnZGVzY3JpcHRpb24nXSA9PT0gJ3N0cmluZycgPyAoYnlLZXlbJ2Rlc2NyaXB0aW9uJ10gYXMgc3RyaW5nKSA6IG51bGw7XG4gIGNvbnN0IGltYWdlVXJsID1cbiAgICAodHlwZW9mIGJ5S2V5WydwaG90b19pbWFnZV9mdWxsX3NpemVfb3JpZ2luYWwnXSA9PT0gJ3N0cmluZydcbiAgICAgID8gKGJ5S2V5WydwaG90b19pbWFnZV9mdWxsX3NpemVfb3JpZ2luYWwnXSBhcyBzdHJpbmcpXG4gICAgICA6IG51bGwpID8/XG4gICAgKHR5cGVvZiBieUtleVsndGh1bWJuYWlsX2ltYWdlX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXG4gICAgICA/IChieUtleVsndGh1bWJuYWlsX2ltYWdlX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxuICAgICAgOiBudWxsKSA/P1xuICAgICh0eXBlb2YgYnlLZXlbJ3N1bW1hcnlfcGhvdG9faW1hZ2Vfb3JpZ2luYWwnXSA9PT0gJ3N0cmluZydcbiAgICAgID8gKGJ5S2V5WydzdW1tYXJ5X3Bob3RvX2ltYWdlX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxuICAgICAgOiBudWxsKTtcbiAgaWYgKCFuYW1lICYmICF0aXRsZSAmJiAhZGVzY3JpcHRpb24gJiYgIWltYWdlVXJsKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHtcbiAgICBuYW1lLFxuICAgIGNhcmRfdXJsOiBjYXJkVXJsLFxuICAgIHZlbmRvcl91cmw6IHZlbmRvclVybCxcbiAgICB0aXRsZSxcbiAgICBkZXNjcmlwdGlvbixcbiAgICBpbWFnZV91cmw6IGltYWdlVXJsLFxuICB9O1xufVxuIiwgIi8qKlxuICogTGlnaHR3ZWlnaHQgVUxJRC1saWtlIGlkIGdlbmVyYXRvcjogMjYtY2hhcmFjdGVyIENyb2NrZm9yZCBiYXNlMzIgc3RyaW5nXG4gKiBvZiAodGltZXN0YW1wX21zIHx8IHJhbmRvbW5lc3MpLiBHb29kIGVub3VnaCBmb3IgcnVuIGlkZW50aWZpZXJzIHdpdGhvdXRcbiAqIHB1bGxpbmcgaW4gYSByZWFsIFVMSUQgZGVwZW5kZW5jeS5cbiAqL1xuXG5jb25zdCBBTFBIQUJFVCA9ICcwMTIzNDU2Nzg5QUJDREVGR0hKS01OUFFSU1RWV1hZWic7IC8vIENyb2NrZm9yZFxuXG5leHBvcnQgZnVuY3Rpb24gbmV3UnVuSWQoKTogc3RyaW5nIHtcbiAgY29uc3QgdHMgPSBEYXRlLm5vdygpO1xuICBsZXQgdHNQYXJ0ID0gJyc7XG4gIGxldCB0ID0gdHM7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMTA7IGkrKykge1xuICAgIHRzUGFydCA9IChBTFBIQUJFVFt0ICUgMzJdID8/ICcwJykgKyB0c1BhcnQ7XG4gICAgdCA9IE1hdGguZmxvb3IodCAvIDMyKTtcbiAgfVxuICBjb25zdCByYW5kID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMCkpO1xuICBsZXQgcmFuZFBhcnQgPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIHJhbmQpIHJhbmRQYXJ0ICs9IEFMUEhBQkVUW2IgJSAzMl0gPz8gJzAnO1xuICByZXR1cm4gdHNQYXJ0ICsgcmFuZFBhcnQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzaG9ydFJ1bklkKGlkOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gaWQuc2xpY2UoLTgpO1xufVxuIiwgImltcG9ydCB0eXBlIHsgQWNjb3VudENhdGVnb3J5LCBBY2NvdW50Q29uZmlnIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTWluaW1hbCBwYXJzZXIgZm9yIHRoZSBzdHJpY3Qgc2hhcGUgdXNlZCBieSBgY29uZmlnL2FjY291bnRzLnlhbWxgOlxuICpcbiAqICAgYWNjb3VudHM6XG4gKiAgICAgLSBoYW5kbGU6IERIU2dvdlxuICogICAgICAgbGFiZWw6IERlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHlcbiAqICAgICAgIGNhdGVnb3J5OiBjb3JlXG4gKlxuICogV2UgZGVsaWJlcmF0ZWx5IGRvbid0IHB1bGwgaW4gYSBmdWxsIFlBTUwgbGlicmFyeSBcdTIwMTQgd2UgY29udHJvbCBib3RoIGVuZHMgb2ZcbiAqIHRoaXMgZmlsZSwgYW5kIGEgc21hbGwgcGFyc2VyIGlzIGVhc2llciB0byBhdWRpdCB0aGFuIHRoZSBhbHRlcm5hdGl2ZXMuXG4gKiBVbmtub3duIGtleXMgYW5kIGNvbW1lbnRzIGFyZSB0b2xlcmF0ZWQ7IG1hbGZvcm1lZCBsaW5lcyBhcmUgc2tpcHBlZC5cbiAqXG4gKiBFbnRyaWVzIG1pc3NpbmcgYSBgY2F0ZWdvcnlgIGRlZmF1bHQgdG8gYGNvcmVgIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XG4gKiB3aXRoIHRoZSBwcmUtY2F0ZWdvcml6YXRpb24gZmlsZSBzaGFwZS5cbiAqL1xuY29uc3QgVkFMSURfQ0FURUdPUklFUzogUmVhZG9ubHlTZXQ8QWNjb3VudENhdGVnb3J5PiA9IG5ldyBTZXQoW1xuICAnY29yZScsXG4gICdnb3Zlcm5tZW50JyxcbiAgJ29mZmljaWFscycsXG4gICdwdWJsaWNfZmlndXJlcycsXG4gICdwdWJsaWMnLFxuXSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUFjY291bnRzWWFtbCh0ZXh0OiBzdHJpbmcpOiBBY2NvdW50Q29uZmlnW10ge1xuICBjb25zdCBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdID0gW107XG4gIGxldCBjdXJyZW50OiBQYXJ0aWFsPEFjY291bnRDb25maWc+ID0ge307XG4gIGxldCBpbkFjY291bnRzID0gZmFsc2U7XG4gIGNvbnN0IGZsdXNoID0gKCkgPT4ge1xuICAgIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSB7XG4gICAgICBpZiAoIWN1cnJlbnQuY2F0ZWdvcnkpIGN1cnJlbnQuY2F0ZWdvcnkgPSAnY29yZSc7XG4gICAgICBhY2NvdW50cy5wdXNoKGN1cnJlbnQgYXMgQWNjb3VudENvbmZpZyk7XG4gICAgfVxuICB9O1xuICBmb3IgKGNvbnN0IHJhd0xpbmUgb2YgdGV4dC5zcGxpdCgnXFxuJykpIHtcbiAgICBjb25zdCBsaW5lID0gc3RyaXBDb21tZW50cyhyYXdMaW5lKTtcbiAgICBpZiAobGluZS50cmltKCkgPT09ICcnKSBjb250aW51ZTtcbiAgICBpZiAoL15hY2NvdW50c1xccyo6Ly50ZXN0KGxpbmUpKSB7XG4gICAgICBpbkFjY291bnRzID0gdHJ1ZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoIWluQWNjb3VudHMpIGNvbnRpbnVlO1xuXG4gICAgY29uc3QgaXRlbU1hdGNoID0gbGluZS5tYXRjaCgvXlxccyotXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGl0ZW1NYXRjaCkge1xuICAgICAgZmx1c2goKTtcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShpdGVtTWF0Y2hbMV0gPz8gJycpIH07XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgaGFuZGxlT25seSA9IGxpbmUubWF0Y2goL15cXHMqaGFuZGxlXFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoaGFuZGxlT25seSAmJiAhbGluZS5pbmNsdWRlcygnLScpKSB7XG4gICAgICBmbHVzaCgpO1xuICAgICAgY3VycmVudCA9IHsgaGFuZGxlOiB1bnF1b3RlKGhhbmRsZU9ubHlbMV0gPz8gJycpIH07XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgbGFiZWxNYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqbGFiZWxcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChsYWJlbE1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XG4gICAgICBjdXJyZW50LmxhYmVsID0gdW5xdW90ZShsYWJlbE1hdGNoWzFdID8/ICcnKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBjYXRlZ29yeU1hdGNoID0gbGluZS5tYXRjaCgvXlxccypjYXRlZ29yeVxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGNhdGVnb3J5TWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcbiAgICAgIGNvbnN0IHJhdyA9IHVucXVvdGUoY2F0ZWdvcnlNYXRjaFsxXSA/PyAnJyk7XG4gICAgICBjdXJyZW50LmNhdGVnb3J5ID0gVkFMSURfQ0FURUdPUklFUy5oYXMocmF3IGFzIEFjY291bnRDYXRlZ29yeSlcbiAgICAgICAgPyAocmF3IGFzIEFjY291bnRDYXRlZ29yeSlcbiAgICAgICAgOiAnY29yZSc7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gIH1cbiAgZmx1c2goKTtcbiAgcmV0dXJuIGFjY291bnRzLmZpbHRlcigoYSkgPT4gYS5oYW5kbGUubGVuZ3RoID4gMCk7XG59XG5cbmZ1bmN0aW9uIHN0cmlwQ29tbWVudHMobGluZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gTmFpdmUgYnV0IGFkZXF1YXRlIGZvciBvdXIgZm9ybWF0OiBzdHJpcCBldmVyeXRoaW5nIGFmdGVyIGEgYCNgIHRoYXQgaXNuJ3RcbiAgLy8gaW5zaWRlIHF1b3Rlcy4gT3VyIGNvbmZpZyBuZXZlciB1c2VzIGlubGluZSBzdHJpbmdzIHdpdGggYCNgLlxuICBjb25zdCBpZHggPSBsaW5lLmluZGV4T2YoJyMnKTtcbiAgcmV0dXJuIGlkeCA9PT0gLTEgPyBsaW5lIDogbGluZS5zbGljZSgwLCBpZHgpO1xufVxuXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IHRyaW1tZWQgPSBzLnRyaW0oKTtcbiAgaWYgKFxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoJ1wiJykgJiYgdHJpbW1lZC5lbmRzV2l0aCgnXCInKSkgfHxcbiAgICAodHJpbW1lZC5zdGFydHNXaXRoKFwiJ1wiKSAmJiB0cmltbWVkLmVuZHNXaXRoKFwiJ1wiKSlcbiAgKSB7XG4gICAgcmV0dXJuIHRyaW1tZWQuc2xpY2UoMSwgLTEpO1xuICB9XG4gIHJldHVybiB0cmltbWVkO1xufVxuIiwgIi8qKlxuICogYmFja2dyb3VuZC50cyBcdTIwMTQgZXh0ZW5zaW9uIHNlcnZpY2Ugd29ya2VyLlxuICpcbiAqIE93bnMgdGhlIGNhcHR1cmUgcGlwZWxpbmU6IHJlY2VpdmVzIGBncmFwaHFsLWNhcHR1cmVgIG1lc3NhZ2VzIGZyb20gdGhlXG4gKiBjb250ZW50IHNjcmlwdCwgbm9ybWFsaXplcyB0aGVtLCBhY2N1bXVsYXRlcyBwZXItaGFuZGxlIHJ1biBidWZmZXJzIGluXG4gKiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgYW5kIGNvbW1pdHMgdGhlbSB0byB0aGUgY29uZmlndXJlZCBHaXRIdWIgcmVwb1xuICogdmlhIHRoZSBDb250ZW50cyBBUEkuXG4gKlxuICogU2VydmljZSB3b3JrZXJzIGluIE1WMyBtYXkgYmUgZXZpY3RlZCBhdCBhbnkgdGltZSwgc28gYWxsIGNyaXRpY2FsIHN0YXRlXG4gKiBsaXZlcyBpbiBzdG9yYWdlIChuZXZlciBtb2R1bGUtc2NvcGUpLiBPbiBldmVyeSB3YWtlIHdlIHJlLWRlcml2ZSB3aGF0IHdlXG4gKiBuZWVkOyBwZW5kaW5nIGZsdXNoZXMgYXJlIGRyaXZlbiBieSBgYnJvd3Nlci5hbGFybXNgIHJhdGhlciB0aGFuIHRpbWVycy5cbiAqL1xuXG5pbXBvcnQge1xuICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICBBVVRPX1NDUk9MTF9NSU5fU0VDLFxuICBGQUxMQkFDS19BQ0NPVU5UUyxcbiAgRkxVU0hfQUxBUk1fTUlOVVRFUyxcbiAgRkxVU0hfSURMRV9NUyxcbiAgRkxVU0hfVFdFRVRfVEhSRVNIT0xELFxuICBQUk9GSUxFX0VORFBPSU5UUyxcbiAgVFdFRVRfRU5EUE9JTlRTLFxuICBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyxcbn0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcbmltcG9ydCB7IEdpdEh1YkNsaWVudCwgR2l0SHViRXJyb3IsIHRvQmFzZTY0IH0gZnJvbSAnLi9saWIvZ2l0aHViLmpzJztcbmltcG9ydCB7IGRlc2NyaWJlRXJyb3IsIGVycm9yIGFzIGxvZ0VyciwgaW5mbywgc2V0QnJvYWRjYXN0ZXIsIHdhcm4gfSBmcm9tICcuL2xpYi9sb2dnZXIuanMnO1xuaW1wb3J0IHsgZmlsdGVyUmVsYXRlZCwgbm9ybWFsaXplIH0gZnJvbSAnLi9saWIvbm9ybWFsaXplLmpzJztcbmltcG9ydCB7IG5ld1J1bklkLCBzaG9ydFJ1bklkIH0gZnJvbSAnLi9saWIvcnVuaWRzLmpzJztcbmltcG9ydCB7XG4gIGJ1bXBDb3VudGVyLFxuICBjbGVhckFjdGl2aXR5LFxuICBjbGVhckFsbCxcbiAgY2xlYXJSdW5CdWZmZXIsXG4gIGRlcXVldWVNZWRpYUNyYXdsLFxuICBkZXF1ZXVlUmVmZXRjaCxcbiAgZW5nYWdlbWVudFNpZyxcbiAgZW5xdWV1ZU1lZGlhQ3Jhd2wsXG4gIGVucXVldWVSZWZldGNoLFxuICBnZXRBY2NvdW50cyxcbiAgZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCxcbiAgZ2V0QWN0aXZpdHksXG4gIGdldEF1dG9TY3JvbGxTZXNzaW9uLFxuICBnZXRDb21taXR0ZWRJbmRleCxcbiAgZ2V0Q29ubmVjdGlvbixcbiAgZ2V0Q291bnRlcnMsXG4gIGdldE1lZGlhQ3Jhd2xRdWV1ZSxcbiAgZ2V0TWVkaWFDcmF3bFNlc3Npb24sXG4gIGdldFJlZmV0Y2hRdWV1ZSxcbiAgZ2V0UmVmZXRjaFNlc3Npb24sXG4gIGdldFJ1bkJ1ZmZlcixcbiAgZ2V0UnVuQnVmZmVycyxcbiAgZ2V0U2V0dGluZ3MsXG4gIGlzQ29tbWl0dGVkLFxuICBtZWRpYUNyYXdsUXVldWVUb3RhbCxcbiAgbmV4dE1lZGlhQ3Jhd2xUYXJnZXQsXG4gIG5leHRSZWZldGNoVGFyZ2V0LFxuICBwcnVuZUNvbW1pdHRlZEluZGV4LFxuICBwdXJnZVVucmVsYXRlZFN0YXRlLFxuICByZWZldGNoUXVldWVUb3RhbCxcbiAgc2V0QWNjb3VudHMsXG4gIHNldEFjY291bnRzUmVmcmVzaGVkQXQsXG4gIHNldEF1dG9TY3JvbGxTZXNzaW9uLFxuICBzZXRCdWZmZXJlZENvdW50LFxuICBzZXRDb21taXR0ZWRJbmRleCxcbiAgc2V0Q29ubmVjdGlvbixcbiAgc2V0TWVkaWFDcmF3bFNlc3Npb24sXG4gIHNldFJlZmV0Y2hTZXNzaW9uLFxuICBzZXRSdW5CdWZmZXIsXG4gIHR5cGUgUnVuQnVmZmVyLFxuICB1cGRhdGVTZXR0aW5ncyxcbn0gZnJvbSAnLi9saWIvc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDYXB0dXJlUGF5bG9hZCxcbiAgQ29ubmVjdGlvblN0YXRlLFxuICBFeHRlbnNpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFF1YXJhbnRpbmVQYXlsb2FkLFxuICBSdW50aW1lTWVzc2FnZSxcbiAgU2VlblBheWxvYWQsXG4gIFNldHRpbmdzLFxufSBmcm9tICcuL2xpYi90eXBlcy5qcyc7XG5pbXBvcnQgeyBwYXJzZUFjY291bnRzWWFtbCB9IGZyb20gJy4vbGliL3lhbWwuanMnO1xuXG5jb25zdCBFWFRfVkVSU0lPTiA9IGJyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb247XG5cbnNldEJyb2FkY2FzdGVyKChldjogTG9nRXZlbnQpID0+IHtcbiAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2xvZy1ldmVudCcsIGV2ZW50OiBldiB9KS5jYXRjaCgoKSA9PiB7fSk7XG59KTtcblxuLy8gLS0tIFdha2UgaGFuZGxlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYnJvd3Nlci5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIGluc3RhbGxlZCcsIHsgdmVyc2lvbjogRVhUX1ZFUlNJT04gfSk7XG4gIGF3YWl0IG9uV2FrZSgnaW5zdGFsbCcpO1xufSk7XG5cbmJyb3dzZXIucnVudGltZS5vblN0YXJ0dXAuYWRkTGlzdGVuZXIoKCkgPT4ge1xuICB2b2lkIG9uV2FrZSgnc3RhcnR1cCcpO1xufSk7XG5cbi8vIEZvcmNlIGF0IGxlYXN0IG9uZSB3YWtlIHRvIHJlZ2lzdGVyIGFsYXJtcyAvIHZlcmlmeSBjb25uZWN0aW9uLlxudm9pZCBvbldha2UoJ21vZHVsZS1sb2FkJyk7XG5cbmFzeW5jIGZ1bmN0aW9uIG9uV2FrZShyZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGF3YWl0IGVuc3VyZUFsYXJtcygpO1xuICAgIGF3YWl0IGVuc3VyZUF1dG9TY3JvbGxBbGFybSgpO1xuICAgIGF3YWl0IGZsdXNoT3JwaGFuZWRCdWZmZXJzSWZTdGFsZSgpO1xuICAgIGF3YWl0IHJlaW5qZWN0SW50b09wZW5UYWJzKCk7XG4gICAgLy8gRHJvcCBkZWR1cC1pbmRleCBlbnRyaWVzIG9sZGVyIHRoYW4gMzAgZGF5cyBzbyB0aGUgc3RvcmUgZG9lc24ndFxuICAgIC8vIGdyb3cgdW5ib3VuZGVkIG92ZXIgbW9udGhzIG9mIGNhcHR1cmUgc2Vzc2lvbnMuXG4gICAgY29uc3QgcHJ1bmVkID0gYXdhaXQgcHJ1bmVDb21taXR0ZWRJbmRleCgzMCAqIDI0ICogNjAgKiA2MCAqIDEwMDApO1xuICAgIGlmIChwcnVuZWQgPiAwKSBhd2FpdCBpbmZvKCdwcnVuZWQgY29tbWl0dGVkIGluZGV4JywgeyBwcnVuZWQgfSk7XG4gICAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICAgIGlmIChzZXR0aW5ncy5wYXQgJiYgc2V0dGluZ3Mub3duZXIgJiYgc2V0dGluZ3MucmVwbykge1xuICAgICAgYXdhaXQgdmVyaWZ5Q29ubmVjdGlvbihmYWxzZSk7XG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KGZhbHNlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcbiAgICAgICAgbG9naW46IG51bGwsXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIGF3YWtlOyBzZXR0aW5ncyBpbmNvbXBsZXRlJywgeyByZWFzb24gfSk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCBsb2dFcnIoJ3dha2UgZmFpbGVkJywgeyByZWFzb24sIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgfVxufVxuXG4vKipcbiAqIFJlLWluamVjdCB0aGUgTUFJTi13b3JsZCBwYWdlLWhvb2sgKyBpc29sYXRlZC13b3JsZCBjb250ZW50IHNjcmlwdCBpbnRvXG4gKiBldmVyeSBhbHJlYWR5LW9wZW4geC5jb20gLyB0d2l0dGVyLmNvbSB0YWIuXG4gKlxuICogTWFuaWZlc3QgY29udGVudF9zY3JpcHRzIG9ubHkgaW5qZWN0IG9uIGZyZXNoIG5hdmlnYXRpb24gKHJ1bl9hdDpcbiAqIGRvY3VtZW50X3N0YXJ0KS4gV2hlbiB0aGUgdXNlciByZWxvYWRzIHRoZSBleHRlbnNpb24gd2hpbGUgWCB0YWJzIGFyZVxuICogb3BlbiwgdGhvc2UgdGFicyBrZWVwIHRoZWlyIGNvbnRlbnQgc2NyaXB0cyBidXQgbmV2ZXIgZ2V0IGEgbmV3IHBhZ2UtaG9va1xuICogXHUyMDE0IHNvIGZldGNoL1hIUiBzdGF5cyB1bnBhdGNoZWQgYW5kIGNhcHR1cmVzIHNpbGVudGx5IGZhaWwuIERvaW5nIHRoaXMgb25cbiAqIGV2ZXJ5IHdha2UgaXMgaWRlbXBvdGVudCAocGFnZS1ob29rIGhhcyBhIFRBRyBndWFyZCkgYW5kIGNoZWFwLlxuICovXG5hc3luYyBmdW5jdGlvbiByZWluamVjdEludG9PcGVuVGFicygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcbiAgdHJ5IHtcbiAgICB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY291bGQgbm90IHF1ZXJ5IG9wZW4gdGFicycsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XG4gICAgaWYgKHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInKSBjb250aW51ZTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICAgIGZpbGVzOiBbJ3BhZ2UtaG9vay5qcyddLFxuICAgICAgICAvLyBGaXJlZm94IDEyOCsgc3VwcG9ydHMgdGhlIE1BSU4gZXhlY3V0aW9uIHdvcmxkIHZpYSB0aGlzIEFQSSwgYnV0XG4gICAgICAgIC8vIHRoZSBAdHlwZXMvZmlyZWZveC13ZWJleHQtYnJvd3NlciBwYWNrYWdlIHdlJ3JlIG9uIHN0aWxsIG9ubHlcbiAgICAgICAgLy8gZGVjbGFyZXMgJ0lTT0xBVEVEJy4gQ2FzdCB0aHJvdWdoIHRoZSBsaXRlcmFsIHVuaW9uLlxuICAgICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ3JlLWluamVjdGVkIHNjcmlwdHMgaW50byBvcGVuIHRhYicsIHtcbiAgICAgICAgdGFiSWQ6IHRhYi5pZCxcbiAgICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwgPz8gJycpLFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAvLyBTb21lIHRhYnMgKGFib3V0OiBwYWdlcywgZGlzY2FyZGVkIHRhYnMsIG1pZC1uYXZpZ2F0aW9uKSByZWplY3RcbiAgICAgIC8vIGV4ZWN1dGVTY3JpcHQuIFRoYXQncyBmaW5lIFx1MjAxNCB3ZSdsbCBjYXRjaCB0aGVtIG9uIHRoZSBuZXh0IHdha2Ugb3JcbiAgICAgIC8vIHdoZW4gdGhlIHVzZXIgbmF2aWdhdGVzLlxuICAgICAgYXdhaXQgd2FybigncmUtaW5qZWN0IGZhaWxlZCBmb3IgdGFiOyBjb250aW51aW5nJywge1xuICAgICAgICB0YWJJZDogdGFiLmlkLFxuICAgICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCA/PyAnJyksXG4gICAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVBbGFybXMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdmbHVzaC1zd2VlcCcpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigndmVyaWZ5LWNvbm5lY3Rpb24nKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY3JlYXRlKCdmbHVzaC1zd2VlcCcsIHsgcGVyaW9kSW5NaW51dGVzOiBGTFVTSF9BTEFSTV9NSU5VVEVTIH0pO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jcmVhdGUoJ3ZlcmlmeS1jb25uZWN0aW9uJywge1xuICAgIHBlcmlvZEluTWludXRlczogVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgLyA2MF8wMDAsXG4gIH0pO1xufVxuXG4vLyBGaXJlZm94IE1WMyBhbGFybXMgaGF2ZSBhIDMwcyBtaW5pbXVtIHBlcmlvZCwgYnV0IHdlIHdhbnQgc3ViLW1pbnV0ZVxuLy8gc2Nyb2xsaW5nLiBUaGUgYXV0by1zY3JvbGwgbG9vcCB0aGVyZWZvcmUgcnVucyBvbiBhbiBpbi1TVyBpbnRlcnZhbC5cbi8vIGBhdXRvU2Nyb2xsU2Vzc2lvbmAgaW4gc3RvcmFnZSBpcyB0aGUgc291cmNlIG9mIHRydXRoIGZvciB3aGV0aGVyIHRoZSBsb29wXG4vLyBpcyBtZWFudCB0byBiZSBydW5uaW5nIFx1MjAxNCB0aGUgdGltZXIgaXMganVzdCB0aGUgbG9jYWwgZXhlY3V0aW9uIGFybS5cbmxldCBhdXRvU2Nyb2xsVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuXG4vLyBXYWl0LWZvci1pbmdlc3QgdGltZW91dDogaWYgYSByZWZldGNoIC8gbWVkaWEtY3Jhd2wgdGFiIG5hdmlnYXRpb24gZG9lc24ndFxuLy8gcHJvZHVjZSBhbiBpbmdlc3RlZCBjYXB0dXJlIHdpdGhpbiB0aGlzIG1hbnkgbXMsIGFkdmFuY2UgYW55d2F5IHNvIHdlXG4vLyBkb24ndCBkZWFkbG9jayBvbiBkZWxldGVkIC8gNDA0IC8gcGF5d2FsbGVkIHR3ZWV0cy5cbmNvbnN0IElOR0VTVF9XQUlUX01TID0gMjVfMDAwO1xuXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVBdXRvU2Nyb2xsQWxhcm0oKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIFdhcyB0aGUgbG9vcCBydW5uaW5nIGJlZm9yZSB0aGUgU1cgZXZpY3Rpb24/IFJlLWFybSBpZiBzby5cbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoc2VzcyAhPT0gbnVsbCAmJiBzLmVuYWJsZWQgIT09IGZhbHNlKSB7XG4gICAgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcbiAgfSBlbHNlIHtcbiAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk6IHZvaWQge1xuICBpZiAoYXV0b1Njcm9sbFRpbWVyICE9PSBudWxsKSB7XG4gICAgY2xlYXJJbnRlcnZhbChhdXRvU2Nyb2xsVGltZXIpO1xuICAgIGF1dG9TY3JvbGxUaW1lciA9IG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gYXJtQXV0b1Njcm9sbFRpbWVyKGludGVydmFsU2VjOiBudW1iZXIpOiB2b2lkIHtcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgY29uc3QgY2xhbXBlZCA9IE1hdGgubWluKFxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChpbnRlcnZhbFNlYykpXG4gICk7XG4gIGF1dG9TY3JvbGxUaW1lciA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIGF1dG9TY3JvbGxUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCdhdXRvLXNjcm9sbCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIGNsYW1wZWQgKiAxMDAwKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKHtcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBzY3JvbGxDb3VudDogMCxcbiAgICBpbmdlc3RlZENvdW50OiAwLFxuICAgIGV4cGFuZGVkQ291bnQ6IDAsXG4gIH0pO1xuICBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xuICBhd2FpdCBpbmZvKCdhdXRvLXNjcm9sbCBsb29wIHN0YXJ0ZWQnLCB7IGludGVydmFsX3NlYzogcy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMgfSk7XG4gIC8vIEZpcmUgb25lIGltbWVkaWF0ZSB0aWNrIHNvIHRoZSB1c2VyIHNlZXMgbW90aW9uIHJpZ2h0IGF3YXkuXG4gIHZvaWQgYXV0b1Njcm9sbFRpY2soKTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsQXV0b1Njcm9sbExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihudWxsKTtcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBjYW5jZWxsZWQnLCB7XG4gICAgc2Nyb2xsczogc2Vzcz8uc2Nyb2xsQ291bnQgPz8gMCxcbiAgICBpbmdlc3RlZDogc2Vzcz8uaW5nZXN0ZWRDb3VudCA/PyAwLFxuICAgIGV4cGFuZGVkOiBzZXNzPy5leHBhbmRlZENvdW50ID8/IDAsXG4gIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBhdXRvU2Nyb2xsVGljaygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcbiAgdHJ5IHtcbiAgICB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignYXV0by1zY3JvbGw6IHRhYiBxdWVyeSBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodGFicy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgbGV0IHNjcm9sbENvdW50ID0gMDtcbiAgbGV0IGV4cGFuZGVkQ291bnQgPSAwO1xuICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XG4gICAgaWYgKHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInKSBjb250aW51ZTtcbiAgICBpZiAodGFiLmRpc2NhcmRlZCkgY29udGludWU7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdHMgPSAoYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgICAgLy8gQ2FzdDogdGhlIEB0eXBlcy9maXJlZm94LXdlYmV4dC1icm93c2VyIHR5cGUgc2lnbmF0dXJlIGluc2lzdHNcbiAgICAgICAgLy8gYGZ1bmNgIHJldHVybnMgdm9pZCwgYnV0IHRoZSBBUEkgYWN0dWFsbHkgc3VyZmFjZXMgdGhlIHJldHVyblxuICAgICAgICAvLyB2YWx1ZSB2aWEgYHJlc3VsdFswXS5yZXN1bHRgLiBXZSB1c2UgdGhhdCBmb3IgdGhlIGV4cGFuZCBjb3VudC5cbiAgICAgICAgZnVuYzogKCgpID0+IHtcbiAgICAgICAgICAvLyAxLiBDbGljayBhbnkgdmlzaWJsZSBcIlNob3cgbW9yZVwiIGxpbmtzIGluIGxvbmctdHdlZXQgYm9kaWVzIHNvIFhcbiAgICAgICAgICAvLyAgICBpbmxpbmVzIHRoZSBub3RlX3R3ZWV0IGJvZHkgYW5kIG91ciBwYWdlLWhvb2sgY2FwdHVyZXMgdGhlXG4gICAgICAgICAgLy8gICAgZnVsbCB0ZXh0IHdpdGhvdXQgdGhlIHJlZmV0Y2ggZGV0b3VyLiBUcnkgc2V2ZXJhbCBzZWxlY3RvcnNcbiAgICAgICAgICAvLyAgICBiZWNhdXNlIFggcm90YXRlcyB0aGUgdGVzdGlkIGxhYmVsIHNlbWktcmVndWxhcmx5LlxuICAgICAgICAgIGNvbnN0IFNIT1dfTU9SRV9TRUxFQ1RPUlMgPSBbXG4gICAgICAgICAgICAnW2RhdGEtdGVzdGlkPVwidHdlZXQtdGV4dC1zaG93LW1vcmUtbGlua1wiXScsXG4gICAgICAgICAgICAnYnV0dG9uW2RhdGEtdGVzdGlkPVwidHdlZXQtdGV4dC1zaG93LW1vcmUtbGlua1wiXScsXG4gICAgICAgICAgICAnZGl2W2RhdGEtdGVzdGlkPVwiY2VsbElubmVyRGl2XCJdIFtyb2xlPVwiYnV0dG9uXCJdW3RhYmluZGV4PVwiMFwiXScsXG4gICAgICAgICAgXTtcbiAgICAgICAgICBjb25zdCBjbGlja2VkID0gbmV3IFNldDxFbGVtZW50PigpO1xuICAgICAgICAgIGxldCBleHBhbmRlZCA9IDA7XG4gICAgICAgICAgZm9yIChjb25zdCBzZWwgb2YgU0hPV19NT1JFX1NFTEVDVE9SUykge1xuICAgICAgICAgICAgZm9yIChjb25zdCBlbCBvZiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsKSkpIHtcbiAgICAgICAgICAgICAgaWYgKGNsaWNrZWQuaGFzKGVsKSkgY29udGludWU7XG4gICAgICAgICAgICAgIC8vIENvbmZpcm0gaXQncyBhY3R1YWxseSB0aGUgc2hvdy1tb3JlIGFmZm9yZGFuY2UgYnkgdGV4dC5cbiAgICAgICAgICAgICAgY29uc3QgdCA9IChlbC50ZXh0Q29udGVudCB8fCAnJykudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICAgIGlmICh0ICE9PSAnc2hvdyBtb3JlJyAmJiB0ICE9PSAnc2hvdyB0aGlzIHRocmVhZCcpIGNvbnRpbnVlO1xuICAgICAgICAgICAgICBjb25zdCByZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgICAgICAgIGlmIChyZWN0LndpZHRoID09PSAwIHx8IHJlY3QuaGVpZ2h0ID09PSAwKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgY2xpY2tlZC5hZGQoZWwpO1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIChlbCBhcyBIVE1MRWxlbWVudCkuY2xpY2soKTtcbiAgICAgICAgICAgICAgICBleHBhbmRlZCArPSAxO1xuICAgICAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgICAgICAvLyBpZ25vcmVcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICAvLyAyLiBTY3JvbGwgdGhlIHBhZ2UuIERpc3BhdGNoIEVuZCBrZXkgZmlyc3Qgc2luY2UgbWFueSBYIHN1cmZhY2VzXG4gICAgICAgICAgLy8gICAgKGxpc3RzLCBzZWFyY2gsIHJlcGxpZXMpIGJpbmQgcGFnaW5hdGlvbiB0cmlnZ2VycyB0byBpdCB2aWFcbiAgICAgICAgICAvLyAgICBSZWFjdCBoYW5kbGVyczsgdGhlbiBleHBsaWNpdGx5IHNjcm9sbCB0aGUgZG9jdW1lbnQuXG4gICAgICAgICAgY29uc3Qgb3B0czogS2V5Ym9hcmRFdmVudEluaXQgPSB7XG4gICAgICAgICAgICBrZXk6ICdFbmQnLFxuICAgICAgICAgICAgY29kZTogJ0VuZCcsXG4gICAgICAgICAgICBrZXlDb2RlOiAzNSxcbiAgICAgICAgICAgIHdoaWNoOiAzNSxcbiAgICAgICAgICAgIGJ1YmJsZXM6IHRydWUsXG4gICAgICAgICAgICBjYW5jZWxhYmxlOiB0cnVlLFxuICAgICAgICAgIH07XG4gICAgICAgICAgY29uc3QgZm9jdXMgPSAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCB8IG51bGwpID8/IGRvY3VtZW50LmJvZHk7XG4gICAgICAgICAgZm9jdXMuZGlzcGF0Y2hFdmVudChuZXcgS2V5Ym9hcmRFdmVudCgna2V5ZG93bicsIG9wdHMpKTtcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXl1cCcsIG9wdHMpKTtcbiAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oe1xuICAgICAgICAgICAgdG9wOiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsSGVpZ2h0LFxuICAgICAgICAgICAgYmVoYXZpb3I6ICdhdXRvJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4geyBleHBhbmRlZCB9O1xuICAgICAgICB9KSBhcyAoKSA9PiB2b2lkLFxuICAgICAgfSkpIGFzIEFycmF5PHsgcmVzdWx0PzogdW5rbm93biB9PjtcbiAgICAgIHNjcm9sbENvdW50ICs9IDE7XG4gICAgICBjb25zdCByID0gcmVzdWx0c1swXT8ucmVzdWx0IGFzIHsgZXhwYW5kZWQ/OiBudW1iZXIgfSB8IHVuZGVmaW5lZDtcbiAgICAgIGlmIChyICYmIHR5cGVvZiByLmV4cGFuZGVkID09PSAnbnVtYmVyJykgZXhwYW5kZWRDb3VudCArPSByLmV4cGFuZGVkO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gVGFicyB0aGF0IGRpc2FsbG93IHNjcmlwdGluZyAoYWJvdXQ6LCBkaXNjYXJkZWQsIG1pZC1uYXZpZ2F0aW9uKVxuICAgICAgLy8ganVzdCBnZXQgc2tpcHBlZCBcdTIwMTQgdGhleSdsbCBiZSBlbGlnaWJsZSBvbiBhIGxhdGVyIHRpY2suXG4gICAgfVxuICB9XG4gIGlmIChzY3JvbGxDb3VudCA+IDApIHtcbiAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICBpZiAoc2VzcyAhPT0gbnVsbCkge1xuICAgICAgc2Vzcy5zY3JvbGxDb3VudCArPSBzY3JvbGxDb3VudDtcbiAgICAgIHNlc3MuZXhwYW5kZWRDb3VudCArPSBleHBhbmRlZENvdW50O1xuICAgICAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oc2Vzcyk7XG4gICAgICAvLyBObyBicm9hZGNhc3Qgb24gZXZlcnkgdGljayBcdTIwMTQgdGhlIDE1cyBzaWRlYmFyIHJlZnJlc2ggcGlja3MgaXQgdXAuXG4gICAgfVxuICB9XG59XG5cbmJyb3dzZXIuYWxhcm1zLm9uQWxhcm0uYWRkTGlzdGVuZXIoKGFsYXJtKSA9PiB7XG4gIGlmIChhbGFybS5uYW1lID09PSAnZmx1c2gtc3dlZXAnKSB7XG4gICAgdm9pZCBmbHVzaElkbGVCdWZmZXJzKCk7XG4gIH0gZWxzZSBpZiAoYWxhcm0ubmFtZSA9PT0gJ3ZlcmlmeS1jb25uZWN0aW9uJykge1xuICAgIHZvaWQgdmVyaWZ5Q29ubmVjdGlvbihmYWxzZSk7XG4gIH1cbiAgLy8gcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHByZXZpb3VzbHkgcmFuIHZpYSBhbGFybXM7IHRoZXkgbm93IHVzZVxuICAvLyBzZXRJbnRlcnZhbCB0byBlc2NhcGUgdGhlIDMwcyBhbGFybSBmbG9vci4gTGVhdmUgdGhlIG5hbWVzIGxpc3RlZFxuICAvLyBub3doZXJlIHNvIGFueSBvcnBoYW5lZCBhbGFybXMgKGZyb20gb2xkZXIgYnVpbGRzKSBqdXN0IG5vLW9wLlxufSk7XG5cbi8vIC0tLSBUb29sYmFyIGFjdGlvbjogdG9nZ2xlIHRoZSBzaWRlYmFyIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmlmIChicm93c2VyLmFjdGlvbj8ub25DbGlja2VkKSB7XG4gIGJyb3dzZXIuYWN0aW9uLm9uQ2xpY2tlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2lkZWJhckFjdGlvbi50b2dnbGUoKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIC8vIEZhbGxiYWNrOiBvcGVuIG9wdGlvbnMgaWYgc2lkZWJhciBjYW4ndCBiZSB0b2dnbGVkLlxuICAgICAgYXdhaXQgd2Fybignc2lkZWJhciB0b2dnbGUgZmFpbGVkOyBvcGVuaW5nIG9wdGlvbnMnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgICAgYXdhaXQgYnJvd3Nlci5ydW50aW1lLm9wZW5PcHRpb25zUGFnZSgpO1xuICAgIH1cbiAgfSk7XG59XG5cbi8vIC0tLSBSdW50aW1lIG1lc3NhZ2UgZGlzcGF0Y2ggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiB1bmtub3duLCBfc2VuZGVyKSA9PiB7XG4gIGlmICghaXNSdW50aW1lTWVzc2FnZShtc2cpKSByZXR1cm4gdW5kZWZpbmVkO1xuICByZXR1cm4gaGFuZGxlTWVzc2FnZShtc2cpLmNhdGNoKChlcnIpID0+IHtcbiAgICB2b2lkIGxvZ0VycignbWVzc2FnZSBoYW5kbGVyIGZhaWxlZCcsIHsgdHlwZTogbXNnLnR5cGUsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgICB0aHJvdyBlcnI7XG4gIH0pO1xufSk7XG5cbmZ1bmN0aW9uIGlzUnVudGltZU1lc3NhZ2UobTogdW5rbm93bik6IG0gaXMgUnVudGltZU1lc3NhZ2Uge1xuICByZXR1cm4gISFtICYmIHR5cGVvZiBtID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgKG0gYXMgeyB0eXBlPzogdW5rbm93biB9KS50eXBlID09PSAnc3RyaW5nJztcbn1cblxuLyoqIE1lc3NhZ2VzIHRoYXQgZHJpdmUgdGhlIGNhcHR1cmUgcGlwZWxpbmUuIFdoZW4gdGhlIG1hc3RlciBzd2l0Y2ggaXMgT0ZGXG4gKiB3ZSBpZ25vcmUgdGhlc2UgYnV0IHN0aWxsIHJlc3BvbmQgdG8gc3RhdHVzIC8gY29uZmlndXJhdGlvbiBxdWVyaWVzLiAqL1xuY29uc3QgQ0FQVFVSRV9QSVBFTElORV9NRVNTQUdFUyA9IG5ldyBTZXQ8UnVudGltZU1lc3NhZ2VbJ3R5cGUnXT4oW1xuICAnZ3JhcGhxbC1jYXB0dXJlJyxcbiAgJ2NhcHR1cmUtbm93JyxcbiAgJ2NhcHR1cmUtYWxsJyxcbiAgJ2NhcHR1cmUtdGhpcy1wYWdlJyxcbiAgJ2ZsdXNoLWFsbCcsXG4gICdmbHVzaC1oYW5kbGUnLFxuICAnc3RhcnQtcmVmZXRjaCcsXG4gICdzdGFydC1tZWRpYS1jcmF3bCcsXG4gICdzdGFydC1hdXRvLXNjcm9sbCcsXG5dKTtcblxuYXN5bmMgZnVuY3Rpb24gaXNFbmFibGVkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgcmV0dXJuIHMuZW5hYmxlZCAhPT0gZmFsc2U7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UobXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8dW5rbm93bj4ge1xuICAvLyBNYXN0ZXIgc3dpdGNoOiB3aGVuIHRoZSB1c2VyIGhhcyBwYXVzZWQgdGhlIGV4dGVuc2lvbiB3ZSBzdGlsbCBuZWVkXG4gIC8vIHRoZSBtZXRhLWNoYW5uZWxzIChnZXQtc3RhdGUsIHRvZ2dsZS1lbmFibGVkLCBvcGVuLW9wdGlvbnMsIFx1MjAyNikgc28gdGhlXG4gIC8vIHNpZGViYXIgc3RheXMgZnVuY3Rpb25hbCwgYnV0IGFueXRoaW5nIHRoYXQgd291bGQgYWN0dWFsbHkgY2FwdHVyZSxcbiAgLy8gY29tbWl0LCBvciBkcml2ZSBhIHRhYiBpcyBhIG5vLW9wLlxuICBpZiAoIShhd2FpdCBpc0VuYWJsZWQoKSkgJiYgQ0FQVFVSRV9QSVBFTElORV9NRVNTQUdFUy5oYXMobXNnLnR5cGUpKSB7XG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHBhdXNlZDogdHJ1ZSB9O1xuICB9XG4gIHN3aXRjaCAobXNnLnR5cGUpIHtcbiAgICBjYXNlICdncmFwaHFsLWNhcHR1cmUnOlxuICAgICAgYXdhaXQgb25HcmFwaHFsQ2FwdHVyZShtc2cuZW5kcG9pbnQsIG1zZy51cmwsIG1zZy5wYWdlVXJsID8/IG51bGwsIG1zZy5yZXNwb25zZSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2NvbnRlbnQtYWxpdmUnOlxuICAgICAgYXdhaXQgaW5mbygnY29udGVudCBzY3JpcHQgYWxpdmUgb24gcGFnZScsIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdwYWdlLWhvb2stYWN0aXZlJzpcbiAgICAgIGF3YWl0IGluZm8oJ3BhZ2UgaG9vayBwYXRjaGVkIGZldGNoL1hIUicsIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdsb2ctY29udGVudC1ldmVudCc6XG4gICAgICBpZiAobXNnLmxldmVsID09PSAnd2FybicpIHtcbiAgICAgICAgYXdhaXQgd2Fybihtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH0gZWxzZSBpZiAobXNnLmxldmVsID09PSAnZXJyb3InKSB7XG4gICAgICAgIGF3YWl0IGxvZ0Vycihtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGF3YWl0IGluZm8obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2dldC1zdGF0ZSc6XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhcHR1cmUtbm93JzpcbiAgICAgIGF3YWl0IGNhcHR1cmVOb3cobXNnLmhhbmRsZSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhcHR1cmUtYWxsJzpcbiAgICAgIGF3YWl0IGNhcHR1cmVBbGwoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS10aGlzLXBhZ2UnOlxuICAgICAgYXdhaXQgY2FwdHVyZVRoaXNQYWdlKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2ZsdXNoLWFsbCc6XG4gICAgICBhd2FpdCBmbHVzaEFsbCgndXNlcicpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdmbHVzaC1oYW5kbGUnOlxuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUobXNnLmhhbmRsZSwgJ3VzZXInKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAndG9nZ2xlLWF1dG8tY2FwdHVyZSc6XG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGF1dG9DYXB0dXJlOiBtc2cub24gfSk7XG4gICAgICBhd2FpdCBpbmZvKCdhdXRvLWNhcHR1cmUgdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAndG9nZ2xlLWVuYWJsZWQnOiB7XG4gICAgICBjb25zdCBzID0gYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBlbmFibGVkOiBtc2cub24gfSk7XG4gICAgICBpZiAoIW1zZy5vbikge1xuICAgICAgICAvLyBQYXVzaW5nIHN0b3BzIGFsbCBpbi1mbGlnaHQgbG9vcHMgc28gdGhlIHVzZXIgZ2V0cyBpbW1lZGlhdGVcbiAgICAgICAgLy8gcXVpZXQsIG5vdCBhIFwib25lIG1vcmUgdGlja1wiIHN1cnByaXNlLlxuICAgICAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICAgICAgICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gICAgICAgIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTtcbiAgICAgICAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignbWVkaWEtY3Jhd2wtdGljaycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gUmVzdW1pbmcgcmUtYXJtcyBhbnkgbG9vcHMgd2hvc2Ugc2Vzc2lvbiBpcyBzdGlsbCBzZXQuXG4gICAgICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBtYXN0ZXIgc3dpdGNoIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIH1cbiAgICBjYXNlICdzdGFydC1hdXRvLXNjcm9sbCc6XG4gICAgICBhd2FpdCBzdGFydEF1dG9TY3JvbGxMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1hdXRvLXNjcm9sbCc6XG4gICAgICBhd2FpdCBjYW5jZWxBdXRvU2Nyb2xsTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdzZXQtYXV0by1zY3JvbGwtaW50ZXJ2YWwnOiB7XG4gICAgICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXG4gICAgICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQobXNnLnNlY29uZHMpKVxuICAgICAgKTtcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzZWNvbmRzIH0pO1xuICAgICAgLy8gUmUtYXJtIGFueSBhY3RpdmUgbG9vcHMgd2l0aCB0aGUgbmV3IGludGVydmFsLlxuICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHNlY29uZHMpO1xuICAgICAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kcyk7XG4gICAgICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgfVxuICAgIGNhc2UgJ3N0YXJ0LXJlZmV0Y2gnOlxuICAgICAgYXdhaXQgc3RhcnRSZWZldGNoTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYW5jZWwtcmVmZXRjaCc6XG4gICAgICBhd2FpdCBjYW5jZWxSZWZldGNoTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdzdGFydC1tZWRpYS1jcmF3bCc6XG4gICAgICBhd2FpdCBzdGFydE1lZGlhQ3Jhd2xMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1tZWRpYS1jcmF3bCc6XG4gICAgICBhd2FpdCBjYW5jZWxNZWRpYUNyYXdsTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdwdXJnZS11bnJlbGF0ZWQnOiB7XG4gICAgICBjb25zdCBhY2NzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgICAgIGNvbnN0IHRyYWNrZWQgPSBuZXcgU2V0KGFjY3MubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKSk7XG4gICAgICBjb25zdCBzdW1tYXJ5ID0gYXdhaXQgcHVyZ2VVbnJlbGF0ZWRTdGF0ZSh0cmFja2VkKTtcbiAgICAgIGF3YWl0IGluZm8oJ3B1cmdlZCB1bnJlbGF0ZWQgc3RhdGUnLCBzdW1tYXJ5KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgfVxuICAgIGNhc2UgJ3JlZnJlc2gtYWNjb3VudHMnOlxuICAgICAgYXdhaXQgcmVmcmVzaEFjY291bnRzTGlzdCh0cnVlKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAndmVyaWZ5LWNvbm5lY3Rpb24nOlxuICAgICAgYXdhaXQgdmVyaWZ5Q29ubmVjdGlvbih0cnVlKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2xlYXItYWN0aXZpdHknOlxuICAgICAgYXdhaXQgY2xlYXJBY3Rpdml0eSgpO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdvcGVuLW9wdGlvbnMnOlxuICAgICAgYXdhaXQgYnJvd3Nlci5ydW50aW1lLm9wZW5PcHRpb25zUGFnZSgpO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdvcGVuLXZpZXdlcic6IHtcbiAgICAgIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICAgICAgY29uc3QgdXJsID0gdmlld2VyVXJsKHMpO1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCB9KTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgfVxuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAndW5rbm93biBtZXNzYWdlIHR5cGUnIH07XG4gIH1cbn1cblxuLy8gLS0tIENhcHR1cmUgcGlwZWxpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gb25HcmFwaHFsQ2FwdHVyZShcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgdXJsOiBzdHJpbmcsXG4gIHBhZ2VVcmw6IHN0cmluZyB8IG51bGwsXG4gIHJlc3BvbnNlOiB1bmtub3duXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKFBST0ZJTEVfRU5EUE9JTlRTLmhhcyhlbmRwb2ludCkpIHJldHVybjsgLy8gbm90IHR3ZWV0LWJlYXJpbmdcbiAgaWYgKCFUV0VFVF9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuO1xuXG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgLy8gV2UgZGVsaWJlcmF0ZWx5IGRvIE5PVCBzaG9ydC1jaXJjdWl0IHdoZW4gdGhlIFBBVCBpcyBtaXNzaW5nLiBUaGVcbiAgLy8gbm9ybWFsaXplIHN0ZXAgaXMgY2hlYXAsIHRoZSBidWZmZXIgc3Vydml2ZXMgc2VydmljZS13b3JrZXIgZXZpY3Rpb24sXG4gIC8vIGFuZCBvbmNlIHRoZSBQQVQgaXMgc2V0IHRoZSBuZXh0IGFsYXJtIG9yIHVzZXItdHJpZ2dlcmVkIGZsdXNoIGNvbW1pdHNcbiAgLy8gZXZlcnl0aGluZyB3ZSd2ZSBzZWVuLiBEcm9wcGluZyBjYXB0dXJlcyBoZXJlIHdhcyBoaWRpbmcgdGhlIHVzZXInc1xuICAvLyBmaXJzdCBicm93c2luZyBzZXNzaW9uIGVudGlyZWx5LlxuXG4gIC8vIFR3by1zdGFnZSBmaWx0ZXI6XG4gIC8vICAgMS4gQnVpbGQgRVZFUlkgY2Fub25pY2FsIHR3ZWV0IHdlIGNhbiBmaW5kIGluIHRoZSByZXNwb25zZSAobm8gaGFuZGxlXG4gIC8vICAgICAgZmlsdGVyIGF0IHRoZSBub3JtYWxpemVyIGxldmVsIFx1MjAxNCB3ZSBzdGlsbCB3YW50IHF1b3RlZC9SVCdkIHBhcmVudHNcbiAgLy8gICAgICB0aGF0IGFwcGVhciBhcyBzaWJsaW5nIG5vZGVzKS5cbiAgLy8gICAyLiBBcHBseSBgZmlsdGVyUmVsYXRlZGAgcG9zdC1ob2MgdG8gZHJvcCBhbnl0aGluZyB0aGF0IGhhcyBub1xuICAvLyAgICAgIHJlbGF0aW9uc2hpcCB0byBhIHRyYWNrZWQgYWNjb3VudC4gVGhlIG9sZCBiZWhhdmlvdXIgKFwiZW1wdHlcbiAgLy8gICAgICBhbGxvd2VkLXNldCBvbiB1c2VyLXBhZ2UgZW5kcG9pbnRzLCBmdWxsIGZpbHRlciBvbiBob21lL3NlYXJjaFwiKVxuICAvLyAgICAgIHdhcyB3YXkgdG9vIHBlcm1pc3NpdmUgb24gdGhlIFJlcGxpZXMgdGFiOiBldmVyeSByYW5kb20gcmVwbGllcidzXG4gIC8vICAgICAgcmVwbHkgbGFuZGVkIGluIGEgcGVyLWhhbmRsZSBidWZmZXIga2V5ZWQgYnkgdGhlaXIgb3duIGhhbmRsZS5cbiAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjb3VudHMubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKSk7XG4gIGNvbnN0IGNhcHR1cmVkQXQgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG5cbiAgbGV0IG5vcm1hbGl6ZWQ7XG4gIHRyeSB7XG4gICAgbm9ybWFsaXplZCA9IG5vcm1hbGl6ZShyZXNwb25zZSwge1xuICAgICAgY2FwdHVyZWRBdCxcbiAgICAgIHJ1bklkOiAncGVuZGluZycsXG4gICAgICBlbmRwb2ludCxcbiAgICAgIGFsbG93ZWRIYW5kbGVzOiBuZXcgU2V0PHN0cmluZz4oKSxcbiAgICAgIHNvdXJjZVVybDogcGFnZVVybCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgcXVhcmFudGluZSgnbm9ybWFsaXplLXRocmV3JywgZW5kcG9pbnQsIHVybCwgcmVzcG9uc2UsIGVycik7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIERyb3AgdW5yZWxhdGVkIHR3ZWV0cy4gVGhlIGZpbHRlciBpcyBlbmRwb2ludC1hd2FyZTpcbiAgLy8gICAtIE9uIHRoZSBob21lIC8gc2VhcmNoIHRpbWVsaW5lcyB3ZSdkIGFscmVhZHkgYmVlbiBmaWx0ZXJpbmcgdG9cbiAgLy8gICAgIHRyYWNrZWQgYXV0aG9ycyBvbmx5IFx1MjAxNCBrZWVwIHRoYXQgYmVoYXZpb3VyIGJ1dCBnbyB0aHJvdWdoIHRoZSBzYW1lXG4gIC8vICAgICBgZmlsdGVyUmVsYXRlZGAgaGVscGVyIHNvIHRoZSBydWxlcyBhcmUgdW5pZm9ybS5cbiAgLy8gICAtIE9uIHVzZXItcGFnZSBlbmRwb2ludHMgd2Ugbm93IGFsc28gZHJvcCBhbnl0aGluZyB0aGF0IGlzbid0IGVpdGhlclxuICAvLyAgICAgYXV0aG9yZWQtYnksIG1lbnRpb25pbmcsIHJlcGx5aW5nLXRvLCBvciByZWZlcmVuY2VkLWJ5IGEgdHJhY2tlZFxuICAvLyAgICAgYWNjb3VudC5cbiAgY29uc3QgYmVmb3JlRmlsdGVyID0gbm9ybWFsaXplZC50d2VldHMubGVuZ3RoO1xuICBub3JtYWxpemVkLnR3ZWV0cyA9IGZpbHRlclJlbGF0ZWQobm9ybWFsaXplZC50d2VldHMsIHRyYWNrZWQpO1xuICBjb25zdCBkcm9wcGVkVW5yZWxhdGVkID0gYmVmb3JlRmlsdGVyIC0gbm9ybWFsaXplZC50d2VldHMubGVuZ3RoO1xuICBpZiAoZHJvcHBlZFVucmVsYXRlZCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdkcm9wcGVkIHVucmVsYXRlZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIGRyb3BwZWQ6IGRyb3BwZWRVbnJlbGF0ZWQsXG4gICAgICBrZXB0OiBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGgsXG4gICAgfSk7XG4gIH1cblxuICAvLyBEaWFnbm9zdGljOiBldmVyeSB0d2VldC1lbmRwb2ludCBwYXlsb2FkIGdldHMgYSBsaW5lIGluIHRoZSBhY3Rpdml0eVxuICAvLyB0YWlsIHdpdGggd2hhdCB3ZSBzYXcgdnMga2VwdC4gV2hlbiBvYnNlcnZlZD0wIHdlIGFsc28gZW1pdCBhIHNoYXBlXG4gIC8vIHByb2JlIChrZXkgcGF0aHMgKyB0eXBlbmFtZXMpIHNvIHdlIGNhbiB0ZWxsIHdoZXRoZXIgWCByZXR1cm5lZCBhblxuICAvLyBlbXB0eSBlbnZlbG9wZSwgYSBsb2dpbi13YWxsIHJlc3BvbnNlLCBvciBhIG5ldyBzaGFwZSB3ZSBkb24ndCBrbm93IGhvd1xuICAvLyB0byB3YWxrIHlldC5cbiAgaWYgKG5vcm1hbGl6ZWQub2JzZXJ2ZWRfaWRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGF3YWl0IGluZm8oJ2dyYXBocWwgcGF5bG9hZCBlbXB0eSBcdTIwMTQgc2hhcGUgcHJvYmUnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHR5cGVuYW1lczogcHJvYmVUeXBlbmFtZXMocmVzcG9uc2UpLnNsaWNlKDAsIDMwKSxcbiAgICAgIHR3ZWV0X2tleXM6IHByb2JlRmlyc3RUeXBlU2hhcGUocmVzcG9uc2UsICdUd2VldCcpLFxuICAgICAgdHdlZXRfY29yZV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbJ2NvcmUnXSksXG4gICAgICB0d2VldF9sZWdhY3lfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgWydsZWdhY3knXSksXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcbiAgICAgICAgJ3Jlc3VsdCcsXG4gICAgICBdKSxcbiAgICAgIHVzZXJfcmVzdWx0c19yZXN1bHRfY29yZV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXG4gICAgICAgICdjb3JlJyxcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXG4gICAgICAgICdyZXN1bHQnLFxuICAgICAgICAnY29yZScsXG4gICAgICBdKSxcbiAgICAgIHVzZXJfcmVzdWx0c19yZXN1bHRfbGVnYWN5X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcbiAgICAgICAgJ3Jlc3VsdCcsXG4gICAgICAgICdsZWdhY3knLFxuICAgICAgXSksXG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgYXdhaXQgaW5mbygnZ3JhcGhxbCBwYXlsb2FkIHNlZW4nLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIG9ic2VydmVkOiBub3JtYWxpemVkLm9ic2VydmVkX2lkcy5sZW5ndGgsXG4gICAgICBrZXB0OiBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGgsXG4gICAgfSk7XG4gIH1cblxuICBpZiAobm9ybWFsaXplZC50d2VldHMubGVuZ3RoID09PSAwKSByZXR1cm47XG5cbiAgLy8gUmVmZXRjaCBxdWV1ZSBob3VzZWtlZXBpbmcgXHUyMDE0IHJ1bnMgQkVGT1JFIHRoZSBkZWR1cCBzaG9ydC1jaXJjdWl0LiBBXG4gIC8vIHJlZmV0Y2ggY2FwdHVyZSBjb21lcyBiYWNrIHdpdGggdGhlIHNhbWUgZW5nYWdlbWVudCBjb3VudHMgKHdlJ3JlXG4gIC8vIG9ubHkgYWZ0ZXIgdGhlIGZ1bGwgdGV4dCksIHNvIHRoZSBkZWR1cCBiZWxvdyB3b3VsZCBzaWxlbnRseSBkcm9wXG4gIC8vIGl0IGFuZCB0aGUgcXVldWUgd291bGQgbmV2ZXIgZHJhaW4uIEhvaXN0IHRoZSBlbnF1ZXVlL2RlcXVldWUgaGVyZVxuICAvLyBzbyB0aGUgbG9vcCByZWxpYWJseSBhZHZhbmNlcyBldmVuIHdoZW4gbm8gY29tbWl0IGhhcHBlbnMuXG4gIC8vXG4gIC8vIEFsc286IGlmIGVpdGhlciBsb29wJ3MgaW5mbGlnaHQgdGFyZ2V0IGFwcGVhcnMgaGVyZSwgbWFyayB0aGUgbG9vcFxuICAvLyBhcyBcImluZ2VzdGVkXCIgc28gdGhlIG5leHQgdGljayBjYW4gYWR2YW5jZS4gVGhlIHdhaXQtZm9yLWluZ2VzdFxuICAvLyBndWFyZCBvdGhlcndpc2UgYmxvY2tzIHVudGlsIHRoZSBuYXZpZ2F0aW9uLXRpbWVvdXQgZmlyZXMuXG4gIGNvbnN0IHJlZmV0Y2hTZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBmb3IgKGNvbnN0IHQgb2Ygbm9ybWFsaXplZC50d2VldHMpIHtcbiAgICBpZiAodC5pc190cnVuY2F0ZWQpIHtcbiAgICAgIGF3YWl0IGVucXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaCh0LmFjY291bnRfaGFuZGxlLCB0LnR3ZWV0X2lkKTtcbiAgICB9XG4gICAgLy8gU3VjY2Vzc2Z1bGx5IGJ1aWx0IHR3ZWV0cyBhcmUgbm8gbG9uZ2VyIFwicGFydGlhbFwiIFx1MjAxNCBkcm9wIGZyb20gdGhlXG4gICAgLy8gbWVkaWEtY3Jhd2wgcXVldWUgcmVnYXJkbGVzcyBvZiB3aGljaCBoYW5kbGUgd2UnZCBoaW50ZWQgZWFybGllci5cbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0LnR3ZWV0X2lkKTtcbiAgICBpZiAocmVmZXRjaFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XG4gICAgICByZWZldGNoU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICByZWZldGNoU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHJlZmV0Y2hTZXNzKTtcbiAgICB9XG4gICAgaWYgKG1lZGlhQ3Jhd2xTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdC50d2VldF9pZCkge1xuICAgICAgbWVkaWFDcmF3bFNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgICAgbWVkaWFDcmF3bFNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihtZWRpYUNyYXdsU2Vzcyk7XG4gICAgfVxuICB9XG5cbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IHR3ZWV0LXNoYXBlZCBub2RlcyB0aGUgd2Fsa2VyIHNhdyBidXQgY291bGRuJ3QgdHVyblxuICAvLyBpbnRvIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIEVucXVldWUgb25seSBJRHMgd2UgaGF2ZW4ndCBhbHJlYWR5XG4gIC8vIGNvbW1pdHRlZCAodXNlci1yZXF1ZXN0ZWQgZGVkdXAgYWdhaW5zdCB0aGUgYXJjaGl2ZSkuXG4gIGZvciAoY29uc3QgcGFydGlhbCBvZiBub3JtYWxpemVkLnBhcnRpYWxfaWRzKSB7XG4gICAgaWYgKGF3YWl0IGlzQ29tbWl0dGVkKHBhcnRpYWwudHdlZXRfaWQpKSBjb250aW51ZTtcbiAgICBhd2FpdCBlbnF1ZXVlTWVkaWFDcmF3bChwYXJ0aWFsLmhpbnRfaGFuZGxlLCBwYXJ0aWFsLnR3ZWV0X2lkKTtcbiAgfVxuICBpZiAobm9ybWFsaXplZC5wYXJ0aWFsX2lkcy5sZW5ndGggPiAwKSB7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IGVucXVldWVkIHBhcnRpYWwgY2FwdHVyZXMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHBhcnRpYWw6IG5vcm1hbGl6ZWQucGFydGlhbF9pZHMubGVuZ3RoLFxuICAgICAgcXVldWVfdG90YWw6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXG4gICAgfSk7XG4gIH1cblxuICAvLyBDcm9zcy1zZXNzaW9uIGRlZHVwOiBkcm9wIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IGNvbW1pdHRlZCB3aXRoIGlkZW50aWNhbFxuICAvLyBlbmdhZ2VtZW50IGNvdW50cy4gTGlrZXMvUlRzL3JlcGxpZXMvcXVvdGVzIHN0aWxsIHRyaWdnZXIgYSByZWNhcHR1cmVcbiAgLy8gc28gZW5nYWdlbWVudF9oaXN0b3J5IGdyb3dzIG92ZXIgdGltZS4gdmlld19jb3VudCBpcyBpbnRlbnRpb25hbGx5XG4gIC8vIGV4Y2x1ZGVkIFx1MjAxNCBpdCBjaHVybnMgdG9vIGZhc3QgdG8gYmUgdXNlZnVsIGFzIGEgZnJlc2huZXNzIHNpZ25hbC5cbiAgLy8gYGlzX3RydW5jYXRlZGAgaXMgcGFydCBvZiB0aGUgc2lnbmF0dXJlIHNvIGEgcmVmZXRjaCB0aGF0IGZsaXBzXG4gIC8vIHRydW5jYXRlZFx1MjE5MmZ1bGwgaXMgdHJlYXRlZCBhcyBhIG1hdGVyaWFsIGNoYW5nZSBhbmQgZ2V0cyBjb21taXR0ZWQuXG4gIGNvbnN0IGNvbW1pdHRlZElkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGxldCBkZWR1cGVkU2tpcHBlZCA9IDA7XG4gIGNvbnN0IGxpdmVUd2VldHM6IHR5cGVvZiBub3JtYWxpemVkLnR3ZWV0cyA9IFtdO1xuICBmb3IgKGNvbnN0IHQgb2Ygbm9ybWFsaXplZC50d2VldHMpIHtcbiAgICBjb25zdCBwcmV2ID0gY29tbWl0dGVkSWR4W3QuYWNjb3VudF9oYW5kbGVdPy5bdC50d2VldF9pZF07XG4gICAgY29uc3Qgc2lnID0gZW5nYWdlbWVudFNpZyhcbiAgICAgIHQubGlrZV9jb3VudCxcbiAgICAgIHQucmV0d2VldF9jb3VudCxcbiAgICAgIHQucmVwbHlfY291bnQsXG4gICAgICB0LnF1b3RlX2NvdW50LFxuICAgICAgdC5pc190cnVuY2F0ZWRcbiAgICApO1xuICAgIGlmIChwcmV2ICYmIHByZXYuc2lnID09PSBzaWcpIHtcbiAgICAgIGRlZHVwZWRTa2lwcGVkICs9IDE7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgbGl2ZVR3ZWV0cy5wdXNoKHQpO1xuICB9XG4gIGlmIChkZWR1cGVkU2tpcHBlZCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdkZWR1cDogc2tpcHBlZCB1bmNoYW5nZWQgdHdlZXRzJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBza2lwcGVkOiBkZWR1cGVkU2tpcHBlZCxcbiAgICAgIHJlbWFpbmluZzogbGl2ZVR3ZWV0cy5sZW5ndGgsXG4gICAgfSk7XG4gIH1cbiAgaWYgKGxpdmVUd2VldHMubGVuZ3RoID09PSAwKSByZXR1cm47XG5cbiAgLy8gR3JvdXAgc3Vydml2aW5nIHR3ZWV0cyBieSBhdXRob3IgaGFuZGxlLlxuICBjb25zdCBieUhhbmRsZSA9IG5ldyBNYXA8c3RyaW5nLCBDYW5vbmljYWxUd2VldFtdPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgbGl2ZVR3ZWV0cykge1xuICAgIGNvbnN0IGFyciA9IGJ5SGFuZGxlLmdldCh0LmFjY291bnRfaGFuZGxlKSA/PyBbXTtcbiAgICBhcnIucHVzaCh0KTtcbiAgICBieUhhbmRsZS5zZXQodC5hY2NvdW50X2hhbmRsZSwgYXJyKTtcbiAgfVxuXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgdHdlZXRzXSBvZiBieUhhbmRsZSkge1xuICAgIGNvbnN0IGJ1ZiA9IGF3YWl0IGVuc3VyZVJ1bkJ1ZmZlcihoYW5kbGUsIGNhcHR1cmVkQXQsIHVybCwgZW5kcG9pbnQpO1xuICAgIGxldCBhZGRlZCA9IDA7XG4gICAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgICAgY29uc3QgZXhpc3RpbmcgPSBidWYudHdlZXRzX2J5X2lkW3QudHdlZXRfaWRdO1xuICAgICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICAgIC8vIFByZXNlcnZlIGZpcnN0X2NhcHR1cmVkX2F0LCBhcHBlbmQgZW5nYWdlbWVudCBzbmFwc2hvdCwgcmVmcmVzaFxuICAgICAgICAvLyBsYXN0X3NlZW5fYXQgKyBjb3VudHMgKHRoZSBsYXRlc3Qgc2NyYXBlIHdpbnMgZm9yIGNvdW50cykuXG4gICAgICAgIGV4aXN0aW5nLmxhc3Rfc2Vlbl9hdCA9IGNhcHR1cmVkQXQ7XG4gICAgICAgIGV4aXN0aW5nLmxpa2VfY291bnQgPSB0Lmxpa2VfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnJldHdlZXRfY291bnQgPSB0LnJldHdlZXRfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnJlcGx5X2NvdW50ID0gdC5yZXBseV9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucXVvdGVfY291bnQgPSB0LnF1b3RlX2NvdW50O1xuICAgICAgICBleGlzdGluZy52aWV3X2NvdW50ID0gdC52aWV3X2NvdW50O1xuICAgICAgICBleGlzdGluZy5ib29rbWFya19jb3VudCA9IHQuYm9va21hcmtfY291bnQ7XG4gICAgICAgIGNvbnN0IGxhc3QgPSBleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnlbZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5Lmxlbmd0aCAtIDFdO1xuICAgICAgICBjb25zdCBzbmFwID0gdC5lbmdhZ2VtZW50X2hpc3RvcnlbMF07XG4gICAgICAgIGlmIChzbmFwICYmICghbGFzdCB8fCBsYXN0LmNhcHR1cmVkX2F0ICE9PSBzbmFwLmNhcHR1cmVkX2F0KSkge1xuICAgICAgICAgIGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeS5wdXNoKHNuYXApO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBzdGFtcGVkOiBDYW5vbmljYWxUd2VldCA9IHsgLi4udCwgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQgfTtcbiAgICAgICAgYnVmLnR3ZWV0c19ieV9pZFt0LnR3ZWV0X2lkXSA9IHN0YW1wZWQ7XG4gICAgICAgIGFkZGVkICs9IDE7XG4gICAgICB9XG4gICAgICBpZiAoIWJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQuaW5jbHVkZXModC50d2VldF9pZCkpIHtcbiAgICAgICAgYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5wdXNoKHQudHdlZXRfaWQpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIWJ1Zi5lbmRwb2ludHNfc2Vlbi5pbmNsdWRlcyhlbmRwb2ludCkpIGJ1Zi5lbmRwb2ludHNfc2Vlbi5wdXNoKGVuZHBvaW50KTtcbiAgICBidWYubGFzdF9jYXB0dXJlX2F0ID0gY2FwdHVyZWRBdDtcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICAgIGF3YWl0IHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlLCBPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGgpO1xuICAgIGlmIChhZGRlZCA+IDApIHtcbiAgICAgIGF3YWl0IGluZm8oJ2NhcHR1cmVkIHR3ZWV0cycsIHtcbiAgICAgICAgaGFuZGxlLFxuICAgICAgICBlbmRwb2ludCxcbiAgICAgICAgYWRkZWQsXG4gICAgICAgIHRvdGFsOiBPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGgsXG4gICAgICB9KTtcbiAgICAgIC8vIEJ1bXAgdGhlIGF1dG8tc2Nyb2xsIHByb2dyZXNzIHNvIHRoZSB1c2VyIHNlZXMgXCJYIGluZ2VzdGVkXCIgdGljayB1cFxuICAgICAgLy8gaW4gcmVhbCB0aW1lLiBXZSBjb3VudCBhY3R1YWxseS1uZXcgdHdlZXRzLCBub3QgZHVwbGljYXRlcy5cbiAgICAgIGNvbnN0IGFzU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICBpZiAoYXNTZXNzICE9PSBudWxsKSB7XG4gICAgICAgIGFzU2Vzcy5pbmdlc3RlZENvdW50ICs9IGFkZGVkO1xuICAgICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihhc1Nlc3MpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoID49IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCkge1xuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUoaGFuZGxlLCAndGhyZXNob2xkJyk7XG4gICAgfVxuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZVJ1bkJ1ZmZlcihcbiAgaGFuZGxlOiBzdHJpbmcsXG4gIHRzOiBzdHJpbmcsXG4gIHNvdXJjZVVybDogc3RyaW5nLFxuICBlbmRwb2ludDogc3RyaW5nXG4pOiBQcm9taXNlPFJ1bkJ1ZmZlcj4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRSdW5CdWZmZXIoaGFuZGxlKTtcbiAgaWYgKGN1cikgcmV0dXJuIGN1cjtcbiAgY29uc3QgYnVmOiBSdW5CdWZmZXIgPSB7XG4gICAgcnVuX2lkOiBuZXdSdW5JZCgpLFxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgc3RhcnRlZF9hdDogdHMsXG4gICAgbGFzdF9jYXB0dXJlX2F0OiB0cyxcbiAgICB0d2VldHNfYnlfaWQ6IHt9LFxuICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogW10sXG4gICAgZW5kcG9pbnRzX3NlZW46IFtlbmRwb2ludF0sXG4gICAgc291cmNlX3VybDogc291cmNlVXJsLFxuICB9O1xuICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICBhd2FpdCBpbmZvKCdydW4gc3RhcnRlZCcsIHsgaGFuZGxlLCBydW46IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCkgfSk7XG4gIHJldHVybiBidWY7XG59XG5cbi8vIC0tLSBGbHVzaCBsb2dpYyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmxldCBmbHVzaENoYWluOiBQcm9taXNlPHZvaWQ+ID0gUHJvbWlzZS5yZXNvbHZlKCk7XG5cbmludGVyZmFjZSBGbHVzaEl0ZW0ge1xuICBoYW5kbGU6IHN0cmluZztcbiAgYnVmOiBSdW5CdWZmZXI7XG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcbiAgcmF3UGF0aDogc3RyaW5nO1xuICBzZWVuUGF0aDogc3RyaW5nO1xuICBjYXB0dXJlOiBDYXB0dXJlUGF5bG9hZDtcbiAgc2VlbjogU2VlblBheWxvYWQ7XG4gIGRheTogc3RyaW5nO1xuICBydW5TaG9ydDogc3RyaW5nO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaElkbGVCdWZmZXJzKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gIGNvbnN0IGhhbmRsZXM6IHN0cmluZ1tdID0gW107XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgYnVmXSBvZiBPYmplY3QuZW50cmllcyhhbGwpKSB7XG4gICAgY29uc3QgbGFzdCA9IERhdGUucGFyc2UoYnVmLmxhc3RfY2FwdHVyZV9hdCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShsYXN0KSAmJiBub3cgLSBsYXN0ID49IEZMVVNIX0lETEVfTVMpIHtcbiAgICAgIGhhbmRsZXMucHVzaChoYW5kbGUpO1xuICAgIH1cbiAgfVxuICBhd2FpdCBmbHVzaEhhbmRsZXMoaGFuZGxlcywgJ2lkbGUnKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hPcnBoYW5lZEJ1ZmZlcnNJZlN0YWxlKCk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBPbiB3b3JrZXIgd2FrZSwgYW55IGJ1ZmZlciBvbGRlciB0aGFuIHRoZSBpZGxlIHRocmVzaG9sZCBnZXRzIGEgY2hhbmNlIHRvXG4gIC8vIGNvbW1pdCBpbW1lZGlhdGVseSBcdTIwMTQgdXNlZnVsIHdoZW4gdGhlIHdvcmtlciB3YXMgZXZpY3RlZCBiZWZvcmUgaWRsZS1mbHVzaC5cbiAgLy8gSWYgdGhlIFBBVC9vd25lci9yZXBvIGFyZW4ndCBzZXQgd2UnZCBqdXN0IGVtaXQgXCJmbHVzaCBkZWZlcnJlZFwiIGZvciBldmVyeVxuICAvLyBzaW5nbGUgaGFuZGxlIGluIHN0b3JhZ2UgKHRoZSBkaWFnbm9zdGljIHNob3dlZCB0aGlzIGZpcmluZyAzMDArIHRpbWVzIGluXG4gIC8vIGEgcm93IHdoZW4gdGhlIGV4dGVuc2lvbiB3b2tlIGJlZm9yZSBzZXR0aW5ncyBsb2FkKSwgc28gc2hvcnQtY2lyY3VpdFxuICAvLyBoZXJlIGluc3RlYWQuXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSByZXR1cm47XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgY29uc3QgaGFuZGxlczogc3RyaW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xuICAgICAgaGFuZGxlcy5wdXNoKGhhbmRsZSk7XG4gICAgfVxuICB9XG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhoYW5kbGVzLCAnd2FrZScpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaEFsbChyZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhPYmplY3Qua2V5cyhhbGwpLCByZWFzb24pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaEhhbmRsZShoYW5kbGU6IHN0cmluZywgcmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKFtoYW5kbGVdLCByZWFzb24pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaEhhbmRsZXMoaGFuZGxlczogc3RyaW5nW10sIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHVuaXF1ZSA9IFsuLi5uZXcgU2V0KGhhbmRsZXMpXS5maWx0ZXIoKGgpID0+IGgubGVuZ3RoID4gMCk7XG4gIGlmICh1bmlxdWUubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGNvbnN0IHJ1biA9IGZsdXNoQ2hhaW4udGhlbigoKSA9PiBmbHVzaEhhbmRsZXNMb2NrZWQodW5pcXVlLCByZWFzb24pKTtcbiAgZmx1c2hDaGFpbiA9IHJ1bi5jYXRjaCgoKSA9PiB7fSk7XG4gIHJldHVybiBydW47XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlc0xvY2tlZChoYW5kbGVzOiBzdHJpbmdbXSwgcmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBpdGVtczogRmx1c2hJdGVtW10gPSBbXTtcbiAgZm9yIChjb25zdCBoYW5kbGUgb2YgaGFuZGxlcykge1xuICAgIGNvbnN0IGJ1ZiA9IGFsbFtoYW5kbGVdO1xuICAgIGlmICghYnVmKSBjb250aW51ZTtcbiAgICBjb25zdCB0d2VldHMgPSBPYmplY3QudmFsdWVzKGJ1Zi50d2VldHNfYnlfaWQpO1xuICAgIGlmICh0d2VldHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihoYW5kbGUpO1xuICAgICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIDApO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGl0ZW1zLnB1c2goYnVpbGRGbHVzaEl0ZW0oaGFuZGxlLCBidWYsIHR3ZWV0cykpO1xuICB9XG4gIGlmIChpdGVtcy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHdhcm4oJ2ZsdXNoIGRlZmVycmVkOiBzZXR0aW5ncyBpbmNvbXBsZXRlJywge1xuICAgICAgY291bnQ6IGl0ZW1zLmxlbmd0aCxcbiAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcbiAgICB9KTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gIGNvbnN0IGZpbGVzID0gaXRlbXMuZmxhdE1hcCgoaXRlbSkgPT4gW1xuICAgIHtcbiAgICAgIHBhdGg6IGl0ZW0ucmF3UGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KGl0ZW0uY2FwdHVyZSwgbnVsbCwgMikgKyAnXFxuJyksXG4gICAgfSxcbiAgICB7XG4gICAgICBwYXRoOiBpdGVtLnNlZW5QYXRoLFxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkoaXRlbS5zZWVuLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICB9LFxuICBdKTtcbiAgY29uc3QgY29tbWl0TXNnID0gYnVpbGRCYXRjaENvbW1pdE1lc3NhZ2UoaXRlbXMpO1xuXG4gIHRyeSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2xpZW50LmNvbW1pdEZpbGVzKHtcbiAgICAgIGZpbGVzLFxuICAgICAgbWVzc2FnZTogY29tbWl0TXNnLFxuICAgIH0pO1xuICAgIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gICAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7XG4gICAgICBjb25zdCByZW1haW5pbmdDb3VudCA9IGF3YWl0IGNsZWFyQ29tbWl0dGVkVHdlZXRzRnJvbUJ1ZmZlcihpdGVtKTtcbiAgICAgIC8vIENvdW50ZXIgYnVtcDogYWN0dWFsbHkgSU5DUkVNRU5UIHRvZGF5Q291bnQgYW5kIHRvdGFsQ29tbWl0dGVkIGJ5XG4gICAgICAvLyB0aGUgbnVtYmVyIG9mIHR3ZWV0cyB3ZSBqdXN0IHBlcnNpc3RlZCAodGhlIHByZXZpb3VzIGNvZGUgcmVhZCB0aGVcbiAgICAgIC8vIGV4aXN0aW5nIHZhbHVlcyBhbmQgd3JvdGUgdGhlbSBiYWNrLCBsZWF2aW5nIHRoZSBjb3VudGVyIHBlZ2dlZCBhdFxuICAgICAgLy8gemVybykuXG4gICAgICBjb25zdCBwcmV2ID0gKGF3YWl0IGdldENvdW50ZXJzKCkpW2l0ZW0uaGFuZGxlXTtcbiAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbiAgICAgIGNvbnN0IGNhcnJpZWRUb2RheSA9IHByZXYgJiYgcHJldi50b2RheURhdGUgPT09IHRvZGF5ID8gcHJldi50b2RheUNvdW50IDogMDtcbiAgICAgIGF3YWl0IGJ1bXBDb3VudGVyKGl0ZW0uaGFuZGxlLCB7XG4gICAgICAgIHRvZGF5Q291bnQ6IGNhcnJpZWRUb2RheSArIGl0ZW0udHdlZXRzLmxlbmd0aCxcbiAgICAgICAgdG9kYXlEYXRlOiB0b2RheSxcbiAgICAgICAgbGFzdENhcHR1cmVBdDogaXRlbS5idWYubGFzdF9jYXB0dXJlX2F0LFxuICAgICAgICB0b3RhbENvbW1pdHRlZDogKHByZXY/LnRvdGFsQ29tbWl0dGVkID8/IDApICsgaXRlbS50d2VldHMubGVuZ3RoLFxuICAgICAgICBidWZmZXJlZENvdW50OiByZW1haW5pbmdDb3VudCxcbiAgICAgIH0pO1xuICAgICAgLy8gUmVjb3JkIGNvbW1pdHMgaW4gdGhlIGRlZHVwIGluZGV4IHNvIHdlIGRvbid0IHJlLWNvbW1pdCB0aGVtIG5leHRcbiAgICAgIC8vIGJyb3dzZSB3aXRoIHVuY2hhbmdlZCBlbmdhZ2VtZW50LlxuICAgICAgY29uc3QgaW5uZXIgPSBpZHhbaXRlbS5oYW5kbGVdID8/IHt9O1xuICAgICAgY29uc3Qgbm93SXNvID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgICAgZm9yIChjb25zdCB0IG9mIGl0ZW0udHdlZXRzKSB7XG4gICAgICAgIGlubmVyW3QudHdlZXRfaWRdID0ge1xuICAgICAgICAgIHRzOiBub3dJc28sXG4gICAgICAgICAgc2lnOiBlbmdhZ2VtZW50U2lnKFxuICAgICAgICAgICAgdC5saWtlX2NvdW50LFxuICAgICAgICAgICAgdC5yZXR3ZWV0X2NvdW50LFxuICAgICAgICAgICAgdC5yZXBseV9jb3VudCxcbiAgICAgICAgICAgIHQucXVvdGVfY291bnQsXG4gICAgICAgICAgICB0LmlzX3RydW5jYXRlZFxuICAgICAgICAgICksXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBpZHhbaXRlbS5oYW5kbGVdID0gaW5uZXI7XG4gICAgICBhd2FpdCBpbmZvKCdmbHVzaCBjb21taXR0ZWQnLCB7XG4gICAgICAgIGhhbmRsZTogaXRlbS5oYW5kbGUsXG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgdHdlZXRzOiBpdGVtLnR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIHJ1bjogaXRlbS5ydW5TaG9ydCxcbiAgICAgICAgcGF0aDogaXRlbS5yYXdQYXRoLFxuICAgICAgICBiYXRjaF9jb21taXQ6IHJlc3VsdC5jb21taXRTaGEsXG4gICAgICB9KTtcbiAgICB9XG4gICAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcbiAgICBhd2FpdCBpbmZvKCdmbHVzaCBiYXRjaCBjb21taXR0ZWQnLCB7XG4gICAgICByZWFzb24sXG4gICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXG4gICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgdHdlZXRzOiBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udHdlZXRzLmxlbmd0aCwgMCksXG4gICAgICBjb21taXQ6IHJlc3VsdC5jb21taXRTaGEsXG4gICAgfSk7XG4gICAge1xuICAgICAgY29uc3QgcHJldiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXM6ICdvaycsXG4gICAgICAgIGxvZ2luOiBwcmV2LmxvZ2luLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IHByZXYuZGVmYXVsdEJyYW5jaCxcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogcHJldi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgICAgfSk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBpZiAoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpIHtcbiAgICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgICBjb25zdCBzdGF0dXM6IENvbm5lY3Rpb25TdGF0ZVsnc3RhdHVzJ10gPVxuICAgICAgICBlcnIuY2F0ZWdvcnkgPT09ICdhdXRoJ1xuICAgICAgICAgID8gJ2F1dGgtZXJyb3InXG4gICAgICAgICAgOiBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0J1xuICAgICAgICAgICAgPyAncmF0ZS1saW1pdGVkJ1xuICAgICAgICAgICAgOiBlcnIuY2F0ZWdvcnkgPT09ICduZXR3b3JrJ1xuICAgICAgICAgICAgICA/ICduZXR3b3JrLWVycm9yJ1xuICAgICAgICAgICAgICA6IGNvbm4uc3RhdHVzO1xuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICAgIHN0YXR1cyxcbiAgICAgICAgbG9naW46IGNvbm4ubG9naW4sXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBlcnJvcjogZXJyLm1lc3NhZ2UsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IGNvbm4uZGVmYXVsdEJyYW5jaCxcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogY29ubi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OlxuICAgICAgICAgIGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnID8gZXJyLnJhdGVMaW1pdFJlc2V0QXQgOiBjb25uLnJhdGVMaW1pdFJlc2V0QXQsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGxvZ0VycignZmx1c2ggZmFpbGVkJywge1xuICAgICAgICByZWFzb24sXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcbiAgICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgICBjYXRlZ29yeTogZXJyLmNhdGVnb3J5LFxuICAgICAgICBzdGF0dXM6IGVyci5zdGF0dXMsXG4gICAgICAgIG1lc3NhZ2U6IGVyci5tZXNzYWdlLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBlcnIucmF0ZUxpbWl0UmVzZXRBdCxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBsb2dFcnIoJ2ZsdXNoIGZhaWxlZCcsIHtcbiAgICAgICAgcmVhc29uLFxuICAgICAgICBoYW5kbGVzOiBpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uaGFuZGxlKS5zbGljZSgwLCAyMCksXG4gICAgICAgIHJ1bnM6IGl0ZW1zLmxlbmd0aCxcbiAgICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcbiAgICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgICAgfSk7XG4gICAgfVxuICAgIC8vIExlYXZlIGJ1ZmZlciBpbnRhY3QgZm9yIHJldHJ5LlxuICB9IGZpbmFsbHkge1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gYnVpbGRGbHVzaEl0ZW0oaGFuZGxlOiBzdHJpbmcsIGJ1ZjogUnVuQnVmZmVyLCB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10pOiBGbHVzaEl0ZW0ge1xuICBjb25zdCB0cyA9IGlzb0NvbXBhY3QoYnVmLnN0YXJ0ZWRfYXQpO1xuICBjb25zdCBkYXkgPSBidWYuc3RhcnRlZF9hdC5zbGljZSgwLCAxMCk7XG4gIGNvbnN0IHJ1blNob3J0ID0gc2hvcnRSdW5JZChidWYucnVuX2lkKTtcbiAgY29uc3QgcmF3UGF0aCA9IGByYXcvJHtoYW5kbGV9LyR7dHN9LSR7cnVuU2hvcnR9Lmpzb25gO1xuICBjb25zdCBzZWVuUGF0aCA9IGBzZWVuLyR7aGFuZGxlfS8ke3RzfS0ke3J1blNob3J0fS5qc29uYDtcbiAgcmV0dXJuIHtcbiAgICBoYW5kbGUsXG4gICAgYnVmLFxuICAgIHR3ZWV0cyxcbiAgICByYXdQYXRoLFxuICAgIHNlZW5QYXRoLFxuICAgIGRheSxcbiAgICBydW5TaG9ydCxcbiAgICBjYXB0dXJlOiB7XG4gICAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICAgIGNhcHR1cmVkX2F0OiBidWYubGFzdF9jYXB0dXJlX2F0LFxuICAgICAgZW5kcG9pbnQ6IGJ1Zi5lbmRwb2ludHNfc2Vlbi5qb2luKCcsJyksXG4gICAgICB1c2VyX2FnZW50OiBuYXZpZ2F0b3IudXNlckFnZW50LFxuICAgICAgc291cmNlX3VybDogYnVmLnNvdXJjZV91cmwsXG4gICAgICB0d2VldHMsXG4gICAgfSxcbiAgICBzZWVuOiB7XG4gICAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICAgIGNhcHR1cmVkX2F0OiBidWYubGFzdF9jYXB0dXJlX2F0LFxuICAgICAgdHdlZXRfaWRzX29ic2VydmVkOiBidWYudHdlZXRfaWRzX29ic2VydmVkLFxuICAgIH0sXG4gIH07XG59XG5cbmZ1bmN0aW9uIGJ1aWxkQmF0Y2hDb21taXRNZXNzYWdlKGl0ZW1zOiBGbHVzaEl0ZW1bXSk6IHN0cmluZyB7XG4gIGlmIChpdGVtcy5sZW5ndGggPT09IDEpIHtcbiAgICBjb25zdCBpdGVtID0gaXRlbXNbMF0hO1xuICAgIHJldHVybiBgY2FwdHVyZTogJHtpdGVtLmhhbmRsZX0gJHtpdGVtLmRheX0gJHtpdGVtLnR3ZWV0cy5sZW5ndGh9IHR3ZWV0JHtpdGVtLnR3ZWV0cy5sZW5ndGggPT09IDEgPyAnJyA6ICdzJ30gKHJ1biAke2l0ZW0ucnVuU2hvcnR9KWA7XG4gIH1cbiAgY29uc3QgZGF5cyA9IFsuLi5uZXcgU2V0KGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5kYXkpKV0uc29ydCgpO1xuICBjb25zdCBkYXlMYWJlbCA9IGRheXMubGVuZ3RoID09PSAxID8gZGF5c1swXSEgOiBgJHtkYXlzWzBdfS4uJHtkYXlzW2RheXMubGVuZ3RoIC0gMV19YDtcbiAgY29uc3QgdHdlZXRDb3VudCA9IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS50d2VldHMubGVuZ3RoLCAwKTtcbiAgcmV0dXJuIGBjYXB0dXJlIGJhdGNoOiAke2l0ZW1zLmxlbmd0aH0gcnVucywgJHt0d2VldENvdW50fSB0d2VldCR7dHdlZXRDb3VudCA9PT0gMSA/ICcnIDogJ3MnfSAoJHtkYXlMYWJlbH0pYDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2xlYXJDb21taXR0ZWRUd2VldHNGcm9tQnVmZmVyKGl0ZW06IEZsdXNoSXRlbSk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IGN1cnJlbnQgPSBhd2FpdCBnZXRSdW5CdWZmZXIoaXRlbS5oYW5kbGUpO1xuICBpZiAoIWN1cnJlbnQpIHJldHVybiAwO1xuICBpZiAoY3VycmVudC5ydW5faWQgIT09IGl0ZW0uYnVmLnJ1bl9pZCkgcmV0dXJuIE9iamVjdC5rZXlzKGN1cnJlbnQudHdlZXRzX2J5X2lkKS5sZW5ndGg7XG5cbiAgY29uc3QgY29tbWl0dGVkID0gbmV3IE1hcChcbiAgICBpdGVtLnR3ZWV0cy5tYXAoKHQpID0+IFtcbiAgICAgIHQudHdlZXRfaWQsXG4gICAgICBlbmdhZ2VtZW50U2lnKHQubGlrZV9jb3VudCwgdC5yZXR3ZWV0X2NvdW50LCB0LnJlcGx5X2NvdW50LCB0LnF1b3RlX2NvdW50LCB0LmlzX3RydW5jYXRlZCksXG4gICAgXSlcbiAgKTtcbiAgY29uc3QgcmVtYWluaW5nVHdlZXRzOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD4gPSB7fTtcbiAgZm9yIChjb25zdCBbdHdlZXRJZCwgdHdlZXRdIG9mIE9iamVjdC5lbnRyaWVzKGN1cnJlbnQudHdlZXRzX2J5X2lkKSkge1xuICAgIGNvbnN0IGNvbW1pdHRlZFNpZyA9IGNvbW1pdHRlZC5nZXQodHdlZXRJZCk7XG4gICAgY29uc3QgY3VycmVudFNpZyA9IGVuZ2FnZW1lbnRTaWcoXG4gICAgICB0d2VldC5saWtlX2NvdW50LFxuICAgICAgdHdlZXQucmV0d2VldF9jb3VudCxcbiAgICAgIHR3ZWV0LnJlcGx5X2NvdW50LFxuICAgICAgdHdlZXQucXVvdGVfY291bnQsXG4gICAgICB0d2VldC5pc190cnVuY2F0ZWRcbiAgICApO1xuICAgIGlmICghY29tbWl0dGVkU2lnIHx8IGNvbW1pdHRlZFNpZyAhPT0gY3VycmVudFNpZykge1xuICAgICAgcmVtYWluaW5nVHdlZXRzW3R3ZWV0SWRdID0geyAuLi50d2VldCB9O1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHJlbWFpbmluZ0NvdW50ID0gT2JqZWN0LmtleXMocmVtYWluaW5nVHdlZXRzKS5sZW5ndGg7XG4gIGlmIChyZW1haW5pbmdDb3VudCA9PT0gMCkge1xuICAgIGF3YWl0IGNsZWFyUnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcbiAgICByZXR1cm4gMDtcbiAgfVxuXG4gIGNvbnN0IG5leHRSdW5JZCA9IG5ld1J1bklkKCk7XG4gIGZvciAoY29uc3QgdHdlZXQgb2YgT2JqZWN0LnZhbHVlcyhyZW1haW5pbmdUd2VldHMpKSB7XG4gICAgdHdlZXQuY2FwdHVyZV9ydW5faWQgPSBuZXh0UnVuSWQ7XG4gIH1cbiAgYXdhaXQgc2V0UnVuQnVmZmVyKGl0ZW0uaGFuZGxlLCB7XG4gICAgLi4uY3VycmVudCxcbiAgICBydW5faWQ6IG5leHRSdW5JZCxcbiAgICBzdGFydGVkX2F0OiBjdXJyZW50Lmxhc3RfY2FwdHVyZV9hdCxcbiAgICB0d2VldHNfYnlfaWQ6IHJlbWFpbmluZ1R3ZWV0cyxcbiAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IGN1cnJlbnQudHdlZXRfaWRzX29ic2VydmVkLmZpbHRlcigoaWQpID0+IGlkIGluIHJlbWFpbmluZ1R3ZWV0cyksXG4gIH0pO1xuICBhd2FpdCBpbmZvKCdmbHVzaCBrZXB0IG5ld2VyIGJ1ZmZlcmVkIHR3ZWV0cycsIHtcbiAgICBoYW5kbGU6IGl0ZW0uaGFuZGxlLFxuICAgIGNvbW1pdHRlZF9ydW46IGl0ZW0ucnVuU2hvcnQsXG4gICAgbmV4dF9ydW46IHNob3J0UnVuSWQobmV4dFJ1bklkKSxcbiAgICByZW1haW5pbmc6IHJlbWFpbmluZ0NvdW50LFxuICB9KTtcbiAgcmV0dXJuIHJlbWFpbmluZ0NvdW50O1xufVxuXG4vLyAtLS0gQ2FwdHVyZS1ub3cgLyBjYXB0dXJlLWFsbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVOb3coaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gTGFuZCBvbiB0aGUgUmVwbGllcyB0YWIgc28gWCBmZXRjaGVzIHZpYSBVc2VyVHdlZXRzQW5kUmVwbGllcyBcdTIwMTQgdGhhdFxuICAvLyBlbmRwb2ludCByZXR1cm5zIGJvdGggdG9wLWxldmVsIHBvc3RzIGFuZCByZXBsaWVzLCB3aGljaCBpcyB0aGUgc3VwZXJzZXRcbiAgLy8gd2Ugd2FudCBmb3IgdGhlIGFyY2hpdmUuIFRoZSBwbGFpbiBgLzxoYW5kbGU+YCBVUkwgaGl0cyBVc2VyVHdlZXRzLFxuICAvLyB3aGljaCBvbWl0cyByZXBsaWVzLiBUaGUgcGFnZS1ob29rIGludGVyY2VwdHMgZWl0aGVyIGVuZHBvaW50LCBidXRcbiAgLy8gZm9yY2luZyB0aGUgYnJvYWRlciB0YWIgb24gdXNlci1pbml0aWF0ZWQgY2FwdHVyZXMgaXMgdGhlIHJpZ2h0IGRlZmF1bHQuXG4gIGNvbnN0IHRhcmdldFVybCA9IGBodHRwczovL3guY29tLyR7aGFuZGxlfS93aXRoX3JlcGxpZXNgO1xuICBhd2FpdCBpbmZvKCdjYXB0dXJlLW5vdyByZXF1ZXN0ZWQnLCB7IGhhbmRsZSwgdGFiOiAnd2l0aF9yZXBsaWVzJyB9KTtcbiAgaWYgKCEoYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSkpKSB7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIHtcbiAgICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBzdGFydGVkX2F0OiBub3csXG4gICAgICBsYXN0X2NhcHR1cmVfYXQ6IG5vdyxcbiAgICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IFtdLFxuICAgICAgZW5kcG9pbnRzX3NlZW46IFtdLFxuICAgICAgc291cmNlX3VybDogdGFyZ2V0VXJsLFxuICAgIH0pO1xuICB9XG4gIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmw6IHRhcmdldFVybCwgYWN0aXZlOiB0cnVlIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtYWxsIHJlcXVlc3RlZCcsIHsgY291bnQ6IGFjY291bnRzLmxlbmd0aCB9KTtcbiAgZm9yIChjb25zdCBhIG9mIGFjY291bnRzKSB7XG4gICAgYXdhaXQgY2FwdHVyZU5vdyhhLmhhbmRsZSk7XG4gIH1cbn1cblxuLyoqXG4gKiBDYXB0dXJlIHdoYXRldmVyIHRoZSB1c2VyIGlzIGN1cnJlbnRseSBsb29raW5nIGF0OiBlbnN1cmVzIHBhZ2UtaG9vayBpc1xuICogcGF0Y2hlZCBpbnRvIHRoZSBhY3RpdmUgdGFiLCB0aGVuIG51ZGdlcyB0aGUgcGFnZSB3aXRoIGEgcHJvZ3JhbW1hdGljXG4gKiBzY3JvbGwgc28gWCBmaXJlcyBhbm90aGVyIGJhdGNoIG9mIEdyYXBoUUwgcmVxdWVzdHMgd2UgY2FuIGludGVyY2VwdC5cbiAqXG4gKiBMZXNzIGRpc3J1cHRpdmUgdGhhbiBgQ2FwdHVyZSBub3dgIChubyBuZXcgdGFiLCBubyBuYXZpZ2F0aW9uKSBhbmQgd29ya3NcbiAqIGZvciBhcmJpdHJhcnkgWCBVUkxzIChzcGVjaWZpYyB0d2VldCB0aHJlYWRzLCBzZWFyY2ggcmVzdWx0cywgbGlzdHMpXG4gKiB0aGF0IGRvbid0IG1hcCBjbGVhbmx5IHRvIG9uZSBvZiB0aGUgY29uZmlndXJlZCBoYW5kbGVzLlxuICovXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlVGhpc1BhZ2UoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XG4gIHRyeSB7XG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGNvdWxkIG5vdCBxdWVyeSBhY3RpdmUgdGFiJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgdGFiID0gdGFic1swXTtcbiAgaWYgKCF0YWIgfHwgdHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicgfHwgIXRhYi51cmwpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogbm8gYWN0aXZlIHRhYicpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIS9eaHR0cHM6XFwvXFwvKHh8dHdpdHRlcilcXC5jb21cXC8vLnRlc3QodGFiLnVybCkpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogYWN0aXZlIHRhYiBpcyBub3Qgb24geC5jb20gLyB0d2l0dGVyLmNvbScsIHtcbiAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsKSxcbiAgICB9KTtcbiAgICByZXR1cm47XG4gIH1cbiAgYXdhaXQgaW5mbygnY2FwdHVyZS10aGlzLXBhZ2UgcmVxdWVzdGVkJywgeyB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCkgfSk7XG4gIC8vIChSZS0paW5qZWN0IHRoZSBwYWdlLWhvb2sgKyBpc29sYXRlZCBjb250ZW50IHNjcmlwdCBzbyBmZXRjaC9YSFIgYXJlXG4gIC8vIHBhdGNoZWQgZXZlbiBvbiB0YWJzIG9wZW5lZCBiZWZvcmUgdGhlIGV4dGVuc2lvbiByZWxvYWRlZC5cbiAgdHJ5IHtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICBmaWxlczogWydwYWdlLWhvb2suanMnXSxcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICB9KTtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiByZS1pbmplY3QgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxuICAvLyBOdWRnZSBYIHRvIGZpcmUgbW9yZSBHcmFwaFFMIHJlcXVlc3RzIGJ5IHNjcm9sbGluZy4gTW9zdCB0aW1lbGluZSAvXG4gIC8vIGNvbnZlcnNhdGlvbiB2aWV3cyBmZXRjaCBvbiBpbnRlcnNlY3Rpb24tb2JzZXJ2ZXIgdHJpZ2dlcnMuXG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgZnVuYzogKCkgPT4ge1xuICAgICAgICBjb25zdCBoID0gd2luZG93LmlubmVySGVpZ2h0O1xuICAgICAgICB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgNjAwKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgMTIwMCk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogc2Nyb2xsLW51ZGdlIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbn1cblxuLy8gLS0tIFJlZmV0Y2ggbG9vcCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vXG4vLyBYIHRydW5jYXRlcyBsb25nIHR3ZWV0cyBpbiB0aW1lbGluZSBwYXlsb2FkcyBcdTIwMTQgYG5vdGVfdHdlZXRgIGlzIG9ubHlcbi8vIGlubGluZWQgZm9yIHNvbWUgZW5kcG9pbnRzLiBSZS1vcGVuaW5nIGVhY2ggdHJ1bmNhdGVkIHR3ZWV0J3MgZGV0YWlsIHBhZ2Vcbi8vIGNhdXNlcyB0aGUgcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkuIFRoZSBsb29wXG4vLyBkcml2ZXMgdGhhdCBieSBuYXZpZ2F0aW5nIGEgc2luZ2xlIGRlZGljYXRlZCB0YWIgdGhyb3VnaCB0aGUgcXVldWUsIG9uZVxuLy8gdHdlZXQgYXQgYSB0aW1lLCBnYXRlZCBvbiB0aGUgcGFnZS1ob29rIGFjdHVhbGx5IGluZ2VzdGluZyBhIHJlc3BvbnNlIGZvclxuLy8gdGhlIHR3ZWV0IHdlIGp1c3QgbmF2aWdhdGVkIHRvIChzbyBkZWxldGVkIC8gcGF5d2FsbGVkIC8gNDA0J2QgdHdlZXRzXG4vLyBkb24ndCBtYWtlIHVzIHNwaW4gYW5kIHNvIHdlIGRvbid0IHNsYW0gWCB3aXRoIHJlZnJlc2hlcyBmYXN0ZXIgdGhhbiB0aGVcbi8vIHRhYiBjYW4gbG9hZCkuXG5cbmNvbnN0IFJFRkVUQ0hfVEFCX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3JlZmV0Y2hfdGFiX2lkX18nO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoUkVGRVRDSF9UQUJfS0VZKTtcbiAgY29uc3QgaWQgPSBzdG9yZWRbUkVGRVRDSF9UQUJfS0VZXTtcbiAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ251bWJlcicgPyBpZCA6IG51bGw7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hUYWJJZChpZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoaWQgPT09IG51bGwpIHtcbiAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFJFRkVUQ0hfVEFCX0tFWSk7XG4gIH0gZWxzZSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtSRUZFVENIX1RBQl9LRVldOiBpZCB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydFJlZmV0Y2hMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCB0b3RhbCA9IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCk7XG4gIGlmICh0b3RhbCA9PT0gMCkge1xuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2g6IG5vdGhpbmcgcXVldWVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcbiAgKTtcbiAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24oe1xuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXG4gICAgcHJvY2Vzc2VkOiAwLFxuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIGluZmxpZ2h0OiBudWxsLFxuICB9KTtcbiAgc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kcyk7XG4gIHZvaWQgcmVmZXRjaFRpY2soKTtcbiAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxubGV0IHJlZmV0Y2hJbnRlcnZhbEhhbmRsZTogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xuICBpZiAocmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsKSBjbGVhckludGVydmFsKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSk7XG4gIHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIHJlZmV0Y2hUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCdyZWZldGNoIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICB9KTtcbiAgfSwgc2Vjb25kcyAqIDEwMDApO1xufVxuXG5mdW5jdGlvbiBzdG9wUmVmZXRjaEludGVydmFsKCk6IHZvaWQge1xuICBpZiAocmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsKSB7XG4gICAgY2xlYXJJbnRlcnZhbChyZWZldGNoSW50ZXJ2YWxIYW5kbGUpO1xuICAgIHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSA9IG51bGw7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsUmVmZXRjaExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxuICBjb25zdCB0YWJJZCA9IGF3YWl0IGdldFJlZmV0Y2hUYWJJZCgpO1xuICBhd2FpdCBzZXRSZWZldGNoVGFiSWQobnVsbCk7XG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihudWxsKTtcbiAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcbiAgICBwcm9jZXNzZWQ6IHNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBzZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgaWYgKHNlc3MgPT09IG51bGwpIHtcbiAgICAvLyBMb29wIHdhcyBjYW5jZWxsZWQgb3IgbmV2ZXIgc3RhcnRlZDsgbm90aGluZyB0byBkby5cbiAgICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIFdhaXQtZm9yLWluZ2VzdCBndWFyZDogaWYgd2UncmUgc3RpbGwgZXhwZWN0aW5nIGEgY2FwdHVyZSBmb3IgdGhlXG4gIC8vIHByZXZpb3VzbHktbmF2aWdhdGVkIHRhcmdldCwgb25seSBhZHZhbmNlIG9uY2Ugd2UndmUgZWl0aGVyIHNlZW4gdGhlXG4gIC8vIGNhcHR1cmUgKG9uR3JhcGhxbENhcHR1cmUgY2xlYXJzIGBpbmZsaWdodGApIG9yIGhpdCB0aGUgdGltZW91dC5cbiAgaWYgKHNlc3MuaW5mbGlnaHQgIT09IG51bGwpIHtcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2Uoc2Vzcy5pbmZsaWdodC5uYXZpZ2F0ZWRBdCk7XG4gICAgaWYgKGVsYXBzZWQgPCBJTkdFU1RfV0FJVF9NUykge1xuICAgICAgcmV0dXJuOyAvLyBzdGlsbCB3YWl0aW5nIFx1MjAxNCBwYWdlLWhvb2sgbWF5IHlldCBjYXB0dXJlIHRoZSByZXNwb25zZS5cbiAgICB9XG4gICAgLy8gVGltZWQgb3V0LiBUcmVhdCBhcyBcInRoaXMgdGFyZ2V0IHdvbid0IGluZ2VzdFwiIGFuZCBkcm9wIGl0LlxuICAgIGF3YWl0IHdhcm4oJ3JlZmV0Y2g6IHRhcmdldCB0aW1lZCBvdXQgd2FpdGluZyBmb3IgaW5nZXN0Jywge1xuICAgICAgdHdlZXRfaWQ6IHNlc3MuaW5mbGlnaHQudHdlZXRJZCxcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcbiAgICB9KTtcbiAgICAvLyBGaW5kIHdoaWNoIGhhbmRsZSB0aGlzIGlkIGlzIHF1ZXVlZCB1bmRlciBzbyB3ZSBjYW4gZGVxdWV1ZSBpdC5cbiAgICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gICAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgICBpZiAoaWRzLmluY2x1ZGVzKHNlc3MuaW5mbGlnaHQudHdlZXRJZCkpIHtcbiAgICAgICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2goaGFuZGxlLCBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcbiAgfVxuXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRSZWZldGNoVGFyZ2V0KCk7XG4gIGlmICghdGFyZ2V0KSB7XG4gICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hUYWJJZChudWxsKTtcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihudWxsKTtcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCB1cmwgPSBgaHR0cHM6Ly94LmNvbS8ke3RhcmdldC5oYW5kbGV9L3N0YXR1cy8ke3RhcmdldC50d2VldElkfWA7XG4gIGxldCB0YWJJZCA9IGF3YWl0IGdldFJlZmV0Y2hUYWJJZCgpO1xuICBpZiAodGFiSWQgIT09IG51bGwpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmdldCh0YWJJZCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICB0YWJJZCA9IG51bGw7XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgaWYgKHRhYklkID09PSBudWxsKSB7XG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xuICAgICAgaWYgKHR5cGVvZiB0YWIuaWQgPT09ICdudW1iZXInKSBhd2FpdCBzZXRSZWZldGNoVGFiSWQodGFiLmlkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XG4gICAgfVxuICAgIHNlc3MgPSAoYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKSkgPz8gc2VzcztcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xuICAgICAgdHdlZXRJZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBuYXZpZ2F0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgaW5mbygncmVmZXRjaCB0aWNrJywge1xuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgcmVtYWluaW5nOiBhd2FpdCByZWZldGNoUXVldWVUb3RhbCgpLFxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBzZXNzLnRvdGFsQXRTdGFydCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybigncmVmZXRjaCBuYXZpZ2F0ZSBmYWlsZWQ7IGRyb3BwaW5nIHRhcmdldCcsIHtcbiAgICAgIGhhbmRsZTogdGFyZ2V0LmhhbmRsZSxcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICB9KTtcbiAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaCh0YXJnZXQuaGFuZGxlLCB0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG4vLyAtLS0gTWVkaWEtY3Jhd2wgbG9vcCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy9cbi8vIE1pcnJvcnMgdGhlIHJlZmV0Y2ggbG9vcCBidXQgdGFyZ2V0cyB0aGUgbWVkaWEtY3Jhd2wgcXVldWU6IHR3ZWV0cyB0aGF0XG4vLyB0aGUgbm9ybWFsaXplciBvYnNlcnZlZCB2aWEgdGhlIE1lZGlhIHRhYiAvIFVzZXJNZWRpYSBlbmRwb2ludCB3aXRoXG4vLyBpbnN1ZmZpY2llbnQgZGF0YSB0byBidWlsZCBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBUaGUgY3Jhd2wgbG9vcCB3YWxrc1xuLy8gYSBkZWRpY2F0ZWQgdGFiIHRocm91Z2ggZWFjaCB0d2VldCdzIGRldGFpbCBwYWdlIChoYW5kbGUtbGVzcyBVUkwgZm9ybVxuLy8gd2hlbiB0aGUgaGludC1oYW5kbGUgaXMgbWlzc2luZyksIGF0IHRoZSBhdXRvLXNjcm9sbCBjYWRlbmNlLCBzbyB0aGVcbi8vIHBhZ2UtaG9vayBjYW4gY2FwdHVyZSB0aGUgcmVhbCB0d2VldCBzaGFwZS5cblxuY29uc3QgTUVESUFfQ1JBV0xfVEFCX0tFWSA9ICdfX2ltbV9hcmNoaXZlX21lZGlhX2NyYXdsX3RhYl9pZF9fJztcblxuYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFRhYklkKCk6IFByb21pc2U8bnVtYmVyIHwgbnVsbD4ge1xuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KE1FRElBX0NSQVdMX1RBQl9LRVkpO1xuICBjb25zdCBpZCA9IHN0b3JlZFtNRURJQV9DUkFXTF9UQUJfS0VZXTtcbiAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ251bWJlcicgPyBpZCA6IG51bGw7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldE1lZGlhQ3Jhd2xUYWJJZChpZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoaWQgPT09IG51bGwpIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5yZW1vdmUoTUVESUFfQ1JBV0xfVEFCX0tFWSk7XG4gIGVsc2UgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtNRURJQV9DUkFXTF9UQUJfS0VZXTogaWQgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHRvdGFsID0gYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTtcbiAgaWYgKHRvdGFsID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IG5vdGhpbmcgcXVldWVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcbiAgKTtcbiAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oe1xuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXG4gICAgcHJvY2Vzc2VkOiAwLFxuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIGluZmxpZ2h0OiBudWxsLFxuICB9KTtcbiAgc3RhcnRNZWRpYUNyYXdsSW50ZXJ2YWwoc2Vjb25kcyk7XG4gIHZvaWQgbWVkaWFDcmF3bFRpY2soKTtcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBzdGFydGVkJywgeyBxdWV1ZWQ6IHRvdGFsLCBpbnRlcnZhbF9zZWM6IHNlY29uZHMgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmxldCBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGU6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzOiBudW1iZXIpOiB2b2lkIHtcbiAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgY2xlYXJJbnRlcnZhbChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUpO1xuICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgdm9pZCBtZWRpYUNyYXdsVGljaygpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybignbWVkaWEtY3Jhd2wgdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIH0pO1xuICB9LCBzZWNvbmRzICogMTAwMCk7XG59XG5cbmZ1bmN0aW9uIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTogdm9pZCB7XG4gIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XG4gICAgbWVkaWFDcmF3bEludGVydmFsSGFuZGxlID0gbnVsbDtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxNZWRpYUNyYXdsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignbWVkaWEtY3Jhd2wtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxuICBjb25zdCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQobnVsbCk7XG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihudWxsKTtcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBjYW5jZWxsZWQnLCB7XG4gICAgaGFkX3RhYjogdGFiSWQgIT09IG51bGwsXG4gICAgcHJvY2Vzc2VkOiBzZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG1lZGlhQ3Jhd2xUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGlmIChzZXNzID09PSBudWxsKSB7XG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShzZXNzLmluZmxpZ2h0Lm5hdmlnYXRlZEF0KTtcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgb24gdGhlIHBhZ2UtaG9va1xuICAgIH1cbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XG4gICAgICB0d2VldF9pZDogc2Vzcy5pbmZsaWdodC50d2VldElkLFxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxuICAgIH0pO1xuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgfVxuXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRNZWRpYUNyYXdsVGFyZ2V0KCk7XG4gIGlmICghdGFyZ2V0KSB7XG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZChudWxsKTtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihudWxsKTtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIFNraXAgaWYgYWxyZWFkeSBpbiB0aGUgYXJjaGl2ZSBcdTIwMTQgcGFydGlhbCBjYXB0dXJlcyBjYW4gb3V0bGl2ZSBhXG4gIC8vIHNlcGFyYXRlIGZ1bGwgY2FwdHVyZSBwYXRoLlxuICBpZiAoYXdhaXQgaXNDb21taXR0ZWQodGFyZ2V0LnR3ZWV0SWQpKSB7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBNZWRpYS10YWIgb3ZlcmxheS9zdGF0dXMgcm91dGVzIGxpa2UgYC9pL3N0YXR1cy88aWQ+YCBhcmUgbm90IHJlbGlhYmxlXG4gIC8vIGRldGFpbCBwYWdlcy4gVGhlIG5vcm1hbGl6ZXIgc2hvdWxkIHJlY292ZXIgdGhlIGF1dGhvciBoYW5kbGUgYmVmb3JlXG4gIC8vIHF1ZXVlaW5nOyBpZiBhbiBvbGQgb3IgZGVncmFkZWQgcXVldWUgZW50cnkgaGFzIG5vIGhhbmRsZSwgc2tpcCBpdFxuICAvLyBpbnN0ZWFkIG9mIHNlbmRpbmcgdGhlIHVzZXIgdG8gYW4gZW1wdHkgWCByb3V0ZS5cbiAgaWYgKHRhcmdldC5idWNrZXQgPT09ICdfdW5rbm93bicpIHtcbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bCB0YXJnZXQgbWlzc2luZyBoYW5kbGU7IHNraXBwaW5nIGJyb2tlbiBzdGF0dXMgcm91dGUnLCB7XG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuYnVja2V0fS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRNZWRpYUNyYXdsVGFiSWQoKTtcbiAgaWYgKHRhYklkICE9PSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdGFiSWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiBmYWxzZSB9KTtcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkID09PSAnbnVtYmVyJykgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKHRhYi5pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy51cGRhdGUodGFiSWQsIHsgdXJsIH0pO1xuICAgIH1cbiAgICBzZXNzID0gKGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCkpID8/IHNlc3M7XG4gICAgc2Vzcy5pbmZsaWdodCA9IHtcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIHRpY2snLCB7XG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBoaW50X2hhbmRsZTogdGFyZ2V0LmJ1Y2tldCA9PT0gJ191bmtub3duJyA/IG51bGwgOiB0YXJnZXQuYnVja2V0LFxuICAgICAgcmVtYWluaW5nOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBzZXNzLnRvdGFsQXRTdGFydCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignbWVkaWEtY3Jhd2wgbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuLy8gLS0tIFF1YXJhbnRpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gcXVhcmFudGluZShcbiAgcmVhc29uOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHVybDogc3RyaW5nLFxuICByYXc6IHVua25vd24sXG4gIGVycjogdW5rbm93blxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGxvZ0VycigncXVhcmFudGluaW5nIGNhcHR1cmUnLCB7IHJlYXNvbiwgZW5kcG9pbnQsIHVybCwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykgcmV0dXJuO1xuICBjb25zdCBwYXlsb2FkOiBRdWFyYW50aW5lUGF5bG9hZCA9IHtcbiAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgICByZWFzb24sXG4gICAgZW5kcG9pbnQsXG4gICAgY2FwdHVyZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBzb3VyY2VfdXJsOiB1cmwsXG4gICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICByYXcsXG4gIH07XG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChwYXlsb2FkLmNhcHR1cmVkX2F0KTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IHNoYTgoSlNPTi5zdHJpbmdpZnkocGF5bG9hZCkpO1xuICBjb25zdCBwYXRoID0gYHJhdy9fcXVhcmFudGluZS8ke3RzfS0ke2hhc2h9Lmpzb25gO1xuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGF3YWl0IGNsaWVudC5wdXRGaWxlKHtcbiAgICAgIHBhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShwYXlsb2FkLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICAgIG1lc3NhZ2U6IGBxdWFyYW50aW5lOiAke3JlYXNvbn0gJHtlbmRwb2ludH1gLFxuICAgIH0pO1xuICB9IGNhdGNoIChxZXJyKSB7XG4gICAgYXdhaXQgbG9nRXJyKCdxdWFyYW50aW5lIGNvbW1pdCBmYWlsZWQnLCB7IC4uLmRlc2NyaWJlRXJyb3IocWVycikgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gc2hhOChzOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBidWYgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUocyk7XG4gIGNvbnN0IGRpZ2VzdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgYnVmKTtcbiAgY29uc3QgaGV4ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShkaWdlc3QpKVxuICAgIC5tYXAoKGIpID0+IGIudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsICcwJykpXG4gICAgLmpvaW4oJycpO1xuICByZXR1cm4gaGV4LnNsaWNlKDAsIDgpO1xufVxuXG4vLyAtLS0gQ29ubmVjdGlvbiB2ZXJpZmljYXRpb24gJiBhY2NvdW50cyBsaXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIHZlcmlmeUNvbm5lY3Rpb24oZm9yY2U6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHtcbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcbiAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlcnJvcjogbnVsbCxcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbiAgICB9KTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICBpZiAoIWZvcmNlKSB7XG4gICAgLy8gU2tpcCBpZiB3ZSdyZSBpbnNpZGUgdGhlIHJlcG9ydGVkIHJhdGUtbGltaXQgd2luZG93IFx1MjAxNCByZS1jaGVja2luZ1xuICAgIC8vIGJlZm9yZSByZXNldCBqdXN0IHdhc3RlcyBtb3JlIG9mIHRoZSBzYW1lIGV4aGF1c3RlZCBxdW90YSBhbmQga2VlcHNcbiAgICAvLyB0aGUgNDAzcyBjb21pbmcuXG4gICAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcbiAgICAgIGNvbnN0IG5vd1NlYyA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBBcHBseSB0aGUgcGVyaW9kaWMtY2hlY2sgZ2F0ZSB0byBldmVyeSBzdGF0dXMsIG5vdCBqdXN0ICdvaycuIFRoZVxuICAgIC8vIHByZXZpb3VzIGJlaGF2aW9yIHJlLXZlcmlmaWVkIG9uIGV2ZXJ5IHdha2Ugd2hlbmV2ZXIgdGhlIGNvbm5lY3Rpb25cbiAgICAvLyB3YXNuJ3QgJ29rJywgd2hpY2ggZHVyaW5nIGEgcmF0ZS1saW1pdCB3aW5kb3cgbWVhbnQgMiBBUEkgY2FsbHMgcGVyXG4gICAgLy8gU1cgd2FrZSAodmVyaWZ5UmVwb0FjY2VzcyBkb2VzIEdFVCAvdXNlciArIEdFVCAvcmVwb3Mve299L3tyfSkuXG4gICAgaWYgKGNvbm4uY2hlY2tlZEF0KSB7XG4gICAgICBjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShjb25uLmNoZWNrZWRBdCk7XG4gICAgICBpZiAoYWdlIDwgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMpIHJldHVybjtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgICBjb25zdCByID0gYXdhaXQgY2xpZW50LnZlcmlmeVJlcG9BY2Nlc3MoKTtcbiAgICAvLyBQcm9iZSB0aGUgY29uZmlndXJlZCBicmFuY2guIEEgbm9uLWRlZmF1bHQgYnJhbmNoIGlzIGZpbmUgXHUyMDE0IGl0J3NcbiAgICAvLyByb3V0aW5lIHRvIGNhcHR1cmUgaW50byBhIHdvcmtpbmcgYnJhbmNoIFx1MjAxNCBidXQgYSAqbWlzc2luZyogYnJhbmNoXG4gICAgLy8gd291bGQgNDIyIGV2ZXJ5IGNvbW1pdC5cbiAgICBsZXQgYnJhbmNoT2sgPSB0cnVlO1xuICAgIGlmIChzZXR0aW5ncy5icmFuY2ggJiYgc2V0dGluZ3MuYnJhbmNoICE9PSByLmRlZmF1bHRfYnJhbmNoKSB7XG4gICAgICBicmFuY2hPayA9IGF3YWl0IGNsaWVudC5icmFuY2hFeGlzdHMoc2V0dGluZ3MuYnJhbmNoKTtcbiAgICB9XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXM6ICdvaycsXG4gICAgICBsb2dpbjogci5sb2dpbixcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IG51bGwsXG4gICAgICBkZWZhdWx0QnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogYnJhbmNoT2ssXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IGluZm8oJ2Nvbm5lY3Rpb24gdmVyaWZpZWQnLCB7XG4gICAgICBsb2dpbjogci5sb2dpbixcbiAgICAgIHJlcG86IHIuZnVsbF9uYW1lLFxuICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXG4gICAgICBjb25maWd1cmVkX2JyYW5jaDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgY29uZmlndXJlZF9icmFuY2hfZXhpc3RzOiBicmFuY2hPayxcbiAgICB9KTtcbiAgICBpZiAoIWJyYW5jaE9rKSB7XG4gICAgICBhd2FpdCB3YXJuKCdjb25maWd1cmVkIGJyYW5jaCBkb2VzIG5vdCBleGlzdCBvbiByZW1vdGUnLCB7XG4gICAgICAgIGNvbmZpZ3VyZWQ6IHNldHRpbmdzLmJyYW5jaCxcbiAgICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXG4gICAgICAgIGZpeDogJ29wZW4gU2V0dGluZ3MgYW5kIGNoYW5nZSBicmFuY2ggdG8gJyArIHIuZGVmYXVsdF9icmFuY2gsXG4gICAgICB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnN0IGNhdCA9IGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yID8gZXJyLmNhdGVnb3J5IDogJ3Vua25vd24nO1xuICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XG4gICAgICBjYXQgPT09ICdhdXRoJ1xuICAgICAgICA/ICdhdXRoLWVycm9yJ1xuICAgICAgICA6IGNhdCA9PT0gJ3JhdGUtbGltaXQnXG4gICAgICAgICAgPyAncmF0ZS1saW1pdGVkJ1xuICAgICAgICAgIDogY2F0ID09PSAnbmV0d29yaydcbiAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXG4gICAgICAgICAgICA6ICdhdXRoLWVycm9yJztcbiAgICBjb25zdCByZXNldEF0ID1cbiAgICAgIGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGNhdCA9PT0gJ3JhdGUtbGltaXQnID8gZXJyLnJhdGVMaW1pdFJlc2V0QXQgOiBudWxsO1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzLFxuICAgICAgbG9naW46IG51bGwsXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBkZXNjcmliZUVycm9yKGVycikubWVzc2FnZSxcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogcmVzZXRBdCxcbiAgICB9KTtcbiAgICBhd2FpdCB3YXJuKCdjb25uZWN0aW9uIGNoZWNrIGZhaWxlZCcsIHtcbiAgICAgIGNhdGVnb3J5OiBjYXQsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiByZXNldEF0LFxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIH0pO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hBY2NvdW50c0xpc3QoZm9yY2U6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCkge1xuICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIWZvcmNlKSB7XG4gICAgLy8gU2tpcCB3aGlsZSBpbnNpZGUgYSBrbm93biByYXRlLWxpbWl0IHdpbmRvdyBcdTIwMTQgYWNjb3VudHMueWFtbCBpcyBmZXRjaGVkXG4gICAgLy8gdmlhIGF1dGhlbnRpY2F0ZWQgcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSwgd2hpY2ggY291bnRzIGFnYWluc3QgdGhlXG4gICAgLy8gc2FtZSBxdW90YS5cbiAgICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICAgIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcgJiYgY29ubi5yYXRlTGltaXRSZXNldEF0ICE9PSBudWxsKSB7XG4gICAgICBjb25zdCBub3dTZWMgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcbiAgICAgIGlmIChub3dTZWMgPCBjb25uLnJhdGVMaW1pdFJlc2V0QXQpIHJldHVybjtcbiAgICB9XG4gICAgLy8gU2tpcCBpZiB3ZSByZWZyZXNoZWQgcmVjZW50bHkuIGFjY291bnRzLnlhbWwgY2hhbmdlcyByYXJlbHkgXHUyMDE0IHRoZSBvbGRcbiAgICAvLyBjb2RlIHJlLWZldGNoZWQgaXQgb24gZXZlcnkgU1cgd2FrZSwgd2hpY2ggZHVyaW5nIGhlYXZ5IGJyb3dzaW5nIG1lYW50XG4gICAgLy8gYSBHaXRIdWIgY2FsbCBldmVyeSBmZXcgc2Vjb25kcyBldmVuIHdoZW4gbm90aGluZyB3YXMgYmVpbmcgY2FwdHVyZWQuXG4gICAgY29uc3QgbGFzdFJlZnJlc2hlZCA9IGF3YWl0IGdldEFjY291bnRzUmVmcmVzaGVkQXQoKTtcbiAgICBpZiAobGFzdFJlZnJlc2hlZCkge1xuICAgICAgY29uc3QgYWdlID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2UobGFzdFJlZnJlc2hlZCk7XG4gICAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGFnZSkgJiYgYWdlIDwgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMpIHJldHVybjtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgY2xpZW50LmZldGNoUmF3VGV4dCgnY29uZmlnL2FjY291bnRzLnlhbWwnKTtcbiAgICBpZiAoIXRleHQpIHtcbiAgICAgIGlmIChmb3JjZSkgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBub3QgZm91bmQgaW4gcmVwbzsgdXNpbmcgZmFsbGJhY2snKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHNSZWZyZXNoZWRBdChuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBwYXJzZWQgPSBwYXJzZUFjY291bnRzWWFtbCh0ZXh0KTtcbiAgICBpZiAocGFyc2VkLmxlbmd0aCA9PT0gMCkge1xuICAgICAgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBwYXJzZWQgZW1wdHk7IGtlZXBpbmcgZmFsbGJhY2snKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHNSZWZyZXNoZWRBdChuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhd2FpdCBzZXRBY2NvdW50cyhwYXJzZWQpO1xuICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcbiAgICBpZiAoZm9yY2UpIGF3YWl0IGluZm8oJ2FjY291bnRzIGxpc3QgcmVmcmVzaGVkJywgeyBjb3VudDogcGFyc2VkLmxlbmd0aCB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybigncmVmcmVzaCBhY2NvdW50cyBmYWlsZWQ7IGtlZXBpbmcgY3VycmVudCBsaXN0JywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG4vLyAtLS0gU3RhdGUgYnJvYWRjYXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIGJyb2FkY2FzdFN0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzdGF0ZSA9IGF3YWl0IGJ1aWxkU3RhdGUoKTtcbiAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ3N0YXRlLWNoYW5nZWQnLCBzdGF0ZSB9KS5jYXRjaCgoKSA9PiB7fSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGJ1aWxkU3RhdGUoKTogUHJvbWlzZTxFeHRlbnNpb25TdGF0ZT4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgY29uc3QgY291bnRlcnMgPSBhd2FpdCBnZXRDb3VudGVycygpO1xuICBsZXQgdGFiQ291bnQgPSAwO1xuICB0cnkge1xuICAgIGNvbnN0IHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICAgIHRhYkNvdW50ID0gdGFicy5sZW5ndGg7XG4gIH0gY2F0Y2gge1xuICAgIC8vIHRhYnMucXVlcnkgaXMgYWxsb3dlZCBieSB0aGUgbWFuaWZlc3QgYnV0IGNhbiB0cmFuc2llbnRseSBmYWlsXG4gICAgLy8gYXJvdW5kIGV4dGVuc2lvbiBzdGFydHVwOyBzdXJmYWNpbmcgMCBpcyBmaW5lLlxuICB9XG4gIGNvbnN0IHJlZmV0Y2hRdWV1ZWQgPSBhd2FpdCByZWZldGNoUXVldWVUb3RhbCgpO1xuICBjb25zdCBtZWRpYUNyYXdsUXVldWVkID0gYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTtcbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGNvbnN0IGF1dG9TY3JvbGxTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgcmV0dXJuIHtcbiAgICB2ZXJzaW9uOiBFWFRfVkVSU0lPTixcbiAgICBzZXR0aW5nczogcmVkYWN0U2V0dGluZ3Moc2V0dGluZ3MpLFxuICAgIGNvbm5lY3Rpb246IGNvbm4sXG4gICAgYWNjb3VudHMsXG4gICAgY291bnRlcnMsXG4gICAgYXV0b1Njcm9sbDoge1xuICAgICAgYWN0aXZlOiBhdXRvU2Nyb2xsU2VzcyAhPT0gbnVsbCAmJiBhdXRvU2Nyb2xsVGltZXIgIT09IG51bGwsXG4gICAgICB0YWJDb3VudCxcbiAgICAgIHNjcm9sbENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uc2Nyb2xsQ291bnQgPz8gMCxcbiAgICAgIGluZ2VzdGVkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5pbmdlc3RlZENvdW50ID8/IDAsXG4gICAgICBleHBhbmRlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uZXhwYW5kZWRDb3VudCA/PyAwLFxuICAgIH0sXG4gICAgcmVmZXRjaFF1ZXVlOiB7XG4gICAgICB0b3RhbDogcmVmZXRjaFF1ZXVlZCxcbiAgICAgIHJ1bm5pbmc6IHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcbiAgICAgIHByb2Nlc3NlZDogcmVmZXRjaFNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHJlZmV0Y2hTZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcbiAgICB9LFxuICAgIG1lZGlhQ3Jhd2xRdWV1ZToge1xuICAgICAgdG90YWw6IG1lZGlhQ3Jhd2xRdWV1ZWQsXG4gICAgICBydW5uaW5nOiBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwsXG4gICAgICBwcm9jZXNzZWQ6IG1lZGlhQ3Jhd2xTZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBtZWRpYUNyYXdsU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXG4gICAgfSxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcmVkYWN0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBFeHRlbnNpb25TdGF0ZVsnc2V0dGluZ3MnXSB7XG4gIHJldHVybiB7XG4gICAgb3duZXI6IHMub3duZXIsXG4gICAgcmVwbzogcy5yZXBvLFxuICAgIGJyYW5jaDogcy5icmFuY2gsXG4gICAgZW5hYmxlZDogcy5lbmFibGVkLFxuICAgIGF1dG9DYXB0dXJlOiBzLmF1dG9DYXB0dXJlLFxuICAgIGNvbmZpZ3VyZWRBdDogcy5jb25maWd1cmVkQXQsXG4gICAgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyxcbiAgICBwYXRTZXQ6IHMucGF0Lmxlbmd0aCA+IDAsXG4gICAgcGF0U3VmZml4OiBzLnBhdC5sZW5ndGggPj0gNCA/IHMucGF0LnNsaWNlKC00KSA6ICcnLFxuICB9O1xufVxuXG5mdW5jdGlvbiBpc29Db21wYWN0KGlzbzogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gMjAyNS0wNC0xMlQxNDoyMzowMS4wMDBaIFx1MjE5MiAyMDI1LTA0LTEyVDE0MjMwMVpcbiAgY29uc3QgZCA9IG5ldyBEYXRlKGlzbyk7XG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gaXNvLnJlcGxhY2UoL1s6Ll0vZywgJycpO1xuICBjb25zdCBwYWQgPSAobjogbnVtYmVyLCB3ID0gMikgPT4gU3RyaW5nKG4pLnBhZFN0YXJ0KHcsICcwJyk7XG4gIHJldHVybiAoXG4gICAgYCR7ZC5nZXRVVENGdWxsWWVhcigpfS0ke3BhZChkLmdldFVUQ01vbnRoKCkgKyAxKX0tJHtwYWQoZC5nZXRVVENEYXRlKCkpfWAgK1xuICAgIGBUJHtwYWQoZC5nZXRVVENIb3VycygpKX0ke3BhZChkLmdldFVUQ01pbnV0ZXMoKSl9JHtwYWQoZC5nZXRVVENTZWNvbmRzKCkpfVpgXG4gICk7XG59XG5cbmZ1bmN0aW9uIHZpZXdlclVybChzOiBTZXR0aW5ncyk6IHN0cmluZyB7XG4gIHJldHVybiBgaHR0cHM6Ly8ke3Mub3duZXJ9LmdpdGh1Yi5pby8ke3MucmVwb30vYDtcbn1cblxuLyoqXG4gKiBXYWxrIGBub2RlYCBjb2xsZWN0aW5nIGRvdHRlZCBrZXkgcGF0aHMgdXAgdG8gYG1heERlcHRoYCBkZWVwLiBBcnJheVxuICogaW5kaWNlcyBjb2xsYXBzZSB0byBgWzBdYCAod2Ugb25seSBkZXNjZW5kIGludG8gdGhlIGZpcnN0IGVsZW1lbnQpLiBVc2VkXG4gKiB0byBzdXJmYWNlIHRoZSBzdHJ1Y3R1cmFsIHNrZWxldG9uIG9mIGFuIHVuZmFtaWxpYXIgR3JhcGhRTCByZXNwb25zZVxuICogd2l0aG91dCBpbmNsdWRpbmcgYW55IGRhdGEgdmFsdWVzLlxuICovXG4vKiogQ29sbGVjdCBldmVyeSBkaXN0aW5jdCBgX190eXBlbmFtZWAgdmFsdWUgZm91bmQgYW55d2hlcmUgaW4gdGhlIHRyZWUuICovXG5mdW5jdGlvbiBwcm9iZVR5cGVuYW1lcyhub2RlOiB1bmtub3duKTogc3RyaW5nW10ge1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGlmICh0eXBlb2Ygb2JqLl9fdHlwZW5hbWUgPT09ICdzdHJpbmcnKSBzZWVuLmFkZChvYmouX190eXBlbmFtZSk7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gWy4uLnNlZW5dLnNvcnQoKTtcbn1cblxuLyoqXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIGFueXdoZXJlIGluIHRoZSB0cmVlIHdob3NlIGBfX3R5cGVuYW1lYCBtYXRjaGVzIGFuZFxuICogcmV0dXJuIGl0cyB0b3AtbGV2ZWwga2V5IGxpc3QgKHNvcnRlZCkuIFVzZWZ1bCBmb3IgZGlzY292ZXJpbmcgd2hhdCBmaWVsZHNcbiAqIFggaXMgYWN0dWFsbHkgc2hpcHBpbmcgZm9yIGEgZ2l2ZW4gbm9kZSB0eXBlIGFmdGVyIGEgc2NoZW1hIGNoYW5nZS5cbiAqL1xuZnVuY3Rpb24gcHJvYmVGaXJzdFR5cGVTaGFwZShub2RlOiB1bmtub3duLCB0eXBlbmFtZTogc3RyaW5nKTogc3RyaW5nW10gfCBudWxsIHtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSB0eXBlbmFtZSkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMob2JqKS5zb3J0KCk7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLyoqXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIHdpdGggYF9fdHlwZW5hbWUgPT09IHR5cGVuYW1lYCwgdGhlbiBkZXNjZW5kIHRocm91Z2hcbiAqIHRoZSBnaXZlbiBrZXkgcGF0aCwgYW5kIHJldHVybiB0aGUgdG9wLWxldmVsIGtleXMgb2Ygd2hhdGV2ZXIgaXMgYXQgdGhlXG4gKiBlbmQuIFJldHVybnMgYSBtYXJrZXIgc3RyaW5nIHdoZW4gdGhlIHBhdGggbGVhZHMgc29tZXdoZXJlIG5vbi1vYmplY3Qgc29cbiAqIHdlIGNhbiB0ZWxsIGFwYXJ0IFwiYWJzZW50XCIgZnJvbSBcInByZXNlbnQgYnV0IG5vdCBhbiBvYmplY3RcIi5cbiAqL1xuZnVuY3Rpb24gcHJvYmVUeXBlZE5lc3RlZChub2RlOiB1bmtub3duLCB0eXBlbmFtZTogc3RyaW5nLCBwYXRoOiBzdHJpbmdbXSk6IHVua25vd24ge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICBsZXQgZm91bmQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCA9IG51bGw7XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGlmIChvYmouX190eXBlbmFtZSA9PT0gdHlwZW5hbWUpIHtcbiAgICAgICAgZm91bmQgPSBvYmo7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgaWYgKCFmb3VuZCkgcmV0dXJuIG51bGw7XG4gIGxldCBjdXI6IHVua25vd24gPSBmb3VuZDtcbiAgZm9yIChjb25zdCBzZWcgb2YgcGF0aCkge1xuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIHJldHVybiBgPCR7Y3VyID09PSBudWxsID8gJ251bGwnIDogdHlwZW9mIGN1cn0+YDtcbiAgICBjdXIgPSAoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVtzZWddO1xuICB9XG4gIGlmIChjdXIgPT09IHVuZGVmaW5lZCkgcmV0dXJuICc8bWlzc2luZz4nO1xuICBpZiAoY3VyID09PSBudWxsKSByZXR1cm4gJzxudWxsPic7XG4gIGlmICh0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgcmV0dXJuIGA8JHt0eXBlb2YgY3VyfT5gO1xuICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSByZXR1cm4gYDxhcnJheSBsZW49JHtjdXIubGVuZ3RofT5gO1xuICByZXR1cm4gT2JqZWN0LmtleXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5zb3J0KCk7XG59XG5cbmZ1bmN0aW9uIHNob3J0ZW5VcmwodTogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gQWN0aXZpdHktdGFpbCBjb250ZXh0IGlzIG1vcmUgdXNlZnVsIHdpdGgganVzdCB0aGUgcGF0aDsgZnVsbCBVUkxzIGJlY29tZVxuICAvLyBoYXJkIHRvIHJlYWQgYXQgdGhlIHNpZGViYXIncyB3aWR0aC5cbiAgdHJ5IHtcbiAgICBjb25zdCBwYXJzZWQgPSBuZXcgVVJMKHUpO1xuICAgIGNvbnN0IHBhdGggPSBwYXJzZWQucGF0aG5hbWUgKyAocGFyc2VkLnNlYXJjaCA/ICc/XHUyMDI2JyA6ICcnKTtcbiAgICByZXR1cm4gcGFyc2VkLmhvc3QgPT09ICd4LmNvbScgfHwgcGFyc2VkLmhvc3QgPT09ICd0d2l0dGVyLmNvbSdcbiAgICAgID8gcGF0aFxuICAgICAgOiBgJHtwYXJzZWQuaG9zdH0ke3BhdGh9YDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHUubGVuZ3RoID4gODAgPyBgJHt1LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdTtcbiAgfVxufVxuXG4vLyAtLS0gRGV2IGhlbHBlcnMgZXhwb3NlZCBvbiBnbG9iYWxUaGlzIGZvciB0aGUgZGV2dG9vbHMgY29uc29sZSAtLS0tLS0tLS0tXG4vLyAoZS5nLiBgX19pbW1BcmNoaXZlLmNsZWFyQWxsKClgIGluIHRoZSBiYWNrZ3JvdW5kIHdvcmtlcidzIGRldnRvb2xzKS5cblxuKGdsb2JhbFRoaXMgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLl9faW1tQXJjaGl2ZSA9IHtcbiAgY2xlYXJBbGwsXG4gIGFjdGl2aXR5OiBnZXRBY3Rpdml0eSxcbiAgYWNjb3VudHM6IGdldEFjY291bnRzLFxuICBidWZmZXJzOiBnZXRSdW5CdWZmZXJzLFxuICBmbHVzaEFsbDogKCkgPT4gZmx1c2hBbGwoJ2RldnRvb2xzJyksXG4gIHN0YXRlOiBidWlsZFN0YXRlLFxuICByZWZldGNoUXVldWU6IGdldFJlZmV0Y2hRdWV1ZSxcbiAgc3RhcnRSZWZldGNoOiBzdGFydFJlZmV0Y2hMb29wLFxuICBjYW5jZWxSZWZldGNoOiBjYW5jZWxSZWZldGNoTG9vcCxcbiAgbWVkaWFDcmF3bFF1ZXVlOiBnZXRNZWRpYUNyYXdsUXVldWUsXG4gIHN0YXJ0TWVkaWFDcmF3bDogc3RhcnRNZWRpYUNyYXdsTG9vcCxcbiAgY2FuY2VsTWVkaWFDcmF3bDogY2FuY2VsTWVkaWFDcmF3bExvb3AsXG59O1xuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUVPLElBQU0sbUJBQTZCO0FBQUEsRUFDeEMsS0FBSztBQUFBLEVBQ0wsT0FBTztBQUFBLEVBQ1AsTUFBTTtBQUFBO0FBQUE7QUFBQSxFQUdOLFFBQVE7QUFBQSxFQUNSLFNBQVM7QUFBQSxFQUNULGFBQWE7QUFBQSxFQUNiLGNBQWM7QUFBQSxFQUNkLHVCQUF1QjtBQUN6QjtBQUVPLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sc0JBQXNCO0FBSTVCLElBQU0sb0JBQXFDO0FBQUEsRUFDaEQsRUFBRSxRQUFRLFVBQVUsT0FBTyxtQ0FBbUMsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFVBQVUsT0FBTyw0Q0FBNEMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLE9BQU8sT0FBTyxzQ0FBc0MsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw2Q0FBNkMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLGNBQWMsT0FBTyxtQkFBbUIsVUFBVSxPQUFPO0FBQUEsRUFDbkUsRUFBRSxRQUFRLFlBQVksT0FBTywrQkFBK0IsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyxrQ0FBa0MsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw0QkFBNEIsVUFBVSxPQUFPO0FBQUEsRUFDdkUsRUFBRSxRQUFRLG1CQUFtQixPQUFPLHFCQUFxQixVQUFVLE9BQU87QUFDNUU7QUFHTyxJQUFNLGtCQUF1QyxvQkFBSSxJQUFJO0FBQUEsRUFDMUQ7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFXTSxJQUFNLG9CQUF5QyxvQkFBSSxJQUFJLENBQUMsb0JBQW9CLGNBQWMsQ0FBQztBQXVCM0YsSUFBTSx3QkFBd0I7QUFHOUIsSUFBTSxnQkFBZ0I7QUFHdEIsSUFBTSxzQkFBc0I7QUFHNUIsSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLO0FBRWhELElBQU0sbUJBQW1COzs7QUN0RWhDLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sa0JBQWtCO0FBRXhCLElBQUksa0JBQW9DO0FBQ3hDLElBQUksc0JBQXFDO0FBRXpDLFNBQVMsU0FBUyxLQUF5QjtBQUN6QyxNQUFJLElBQUk7QUFDUixhQUFXLEtBQUssSUFBSyxNQUFLLE9BQU8sYUFBYSxDQUFDO0FBQy9DLFNBQU8sS0FBSyxDQUFDO0FBQ2Y7QUFFQSxTQUFTLFdBQVcsR0FBdUI7QUFDekMsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixRQUFNLE1BQU0sSUFBSSxXQUFXLElBQUksTUFBTTtBQUNyQyxXQUFTLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxJQUFLLEtBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDO0FBQzlELFNBQU87QUFDVDtBQUVBLGVBQWUsbUJBQW1FO0FBQ2hGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksZ0JBQWdCO0FBQy9ELFFBQU0sSUFBSSxPQUFPLGdCQUFnQjtBQUNqQyxNQUFJLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxHQUFHO0FBQ3pDLFdBQU8sRUFBRSxTQUFTLEdBQUcsTUFBTSxXQUFXLENBQUMsRUFBRTtBQUFBLEVBQzNDO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsUUFBTSxVQUFVLFNBQVMsSUFBSTtBQUM3QixRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGdCQUFnQixHQUFHLFFBQVEsQ0FBQztBQUMvRCxTQUFPLEVBQUUsU0FBUyxLQUFLO0FBQ3pCO0FBRUEsZUFBZSxZQUFnQztBQUM3QyxRQUFNLEVBQUUsU0FBUyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDakQsTUFBSSxvQkFBb0IsUUFBUSx3QkFBd0IsU0FBUztBQUMvRCxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRTtBQUFBLElBQzdCLEdBQUcsUUFBUSxRQUFRLEVBQUUsSUFBSSxRQUFRLFFBQVEsWUFBWSxFQUFFLE9BQU87QUFBQSxFQUNoRTtBQUNBLFFBQU0sV0FBVyxJQUFJLFdBQVcsS0FBSyxTQUFTLEtBQUssTUFBTTtBQUN6RCxXQUFTLElBQUksTUFBTSxDQUFDO0FBQ3BCLFdBQVMsSUFBSSxNQUFNLEtBQUssTUFBTTtBQUM5QixRQUFNLE9BQU8sTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLFFBQVE7QUFDM0QsUUFBTSxNQUFNLE1BQU0sT0FBTyxPQUFPLFVBQVUsT0FBTyxNQUFNLEVBQUUsTUFBTSxVQUFVLEdBQUcsT0FBTztBQUFBLElBQ2pGO0FBQUEsSUFDQTtBQUFBLEVBQ0YsQ0FBQztBQUNELG9CQUFrQjtBQUNsQix3QkFBc0I7QUFDdEIsU0FBTztBQUNUO0FBRU8sU0FBUyxlQUFlLEdBQW9CO0FBQ2pELFNBQU8sRUFBRSxXQUFXLGVBQWU7QUFDckM7QUFFQSxlQUFzQixXQUFXLFdBQW9DO0FBQ25FLE1BQUksQ0FBQyxVQUFXLFFBQU87QUFDdkIsUUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixRQUFNLEtBQUssT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUNwRCxRQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxJQUM3QixFQUFFLE1BQU0sV0FBVyxHQUFHO0FBQUEsSUFDdEI7QUFBQSxJQUNBLElBQUksWUFBWSxFQUFFLE9BQU8sU0FBUztBQUFBLEVBQ3BDO0FBQ0EsU0FBTyxHQUFHLGVBQWUsR0FBRyxTQUFTLEVBQUUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxXQUFXLEVBQUUsQ0FBQyxDQUFDO0FBQzFFO0FBRUEsZUFBc0IsV0FBVyxVQUFtQztBQUNsRSxNQUFJLENBQUMsU0FBVSxRQUFPO0FBR3RCLE1BQUksQ0FBQyxTQUFTLFdBQVcsZUFBZSxFQUFHLFFBQU87QUFDbEQsUUFBTSxRQUFRLFNBQVMsTUFBTSxnQkFBZ0IsTUFBTSxFQUFFLE1BQU0sR0FBRztBQUM5RCxNQUFJLE1BQU0sV0FBVyxFQUFHLFFBQU87QUFDL0IsUUFBTSxDQUFDLE9BQU8sS0FBSyxJQUFJO0FBQ3ZCLE1BQUksQ0FBQyxTQUFTLENBQUMsTUFBTyxRQUFPO0FBQzdCLE1BQUk7QUFDRixVQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxNQUM3QixFQUFFLE1BQU0sV0FBVyxHQUF1QjtBQUFBLE1BQzFDO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxXQUFPLElBQUksWUFBWSxFQUFFLE9BQU8sRUFBRTtBQUFBLEVBQ3BDLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGOzs7QUM1QkEsSUFBTSxxQkFBc0M7QUFBQSxFQUMxQyxRQUFRO0FBQUEsRUFDUixPQUFPO0FBQUEsRUFDUCxXQUFXO0FBQUEsRUFDWCxPQUFPO0FBQUEsRUFDUCxlQUFlO0FBQUEsRUFDZix3QkFBd0I7QUFBQSxFQUN4QixrQkFBa0I7QUFDcEI7QUFFQSxJQUFNLFdBQXlCO0FBQUEsRUFDN0IsVUFBVSxFQUFFLEdBQUcsaUJBQWlCO0FBQUEsRUFDaEMsVUFBVSxDQUFDLEdBQUcsaUJBQWlCO0FBQUEsRUFDL0IscUJBQXFCO0FBQUEsRUFDckIsWUFBWSxFQUFFLEdBQUcsbUJBQW1CO0FBQUEsRUFDcEMsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLENBQUM7QUFBQSxFQUNiLFVBQVUsQ0FBQztBQUFBLEVBQ1gsZ0JBQWdCLENBQUM7QUFBQSxFQUNqQixjQUFjLENBQUM7QUFBQSxFQUNmLGlCQUFpQixDQUFDO0FBQUEsRUFDbEIsZ0JBQWdCO0FBQUEsRUFDaEIsbUJBQW1CO0FBQUEsRUFDbkIsbUJBQW1CO0FBQ3JCO0FBRUEsZUFBZSxPQUFxQyxLQUFrQztBQUNwRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDbEQsUUFBTSxRQUFRLE9BQU8sR0FBRztBQUN4QixNQUFJLFVBQVUsUUFBVztBQUN2QixXQUFPLGdCQUFnQixTQUFTLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBQ0EsU0FBTztBQUNUO0FBRUEsZUFBZSxPQUFxQyxLQUFRLE9BQXVDO0FBQ2pHLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQztBQUNsRDtBQUlBLGVBQXNCLGNBQWlDO0FBS3JELFFBQU0sU0FBUyxNQUFNLE9BQU8sVUFBVTtBQUN0QyxRQUFNLFNBQVMsRUFBRSxHQUFHLGtCQUFrQixHQUFHLE9BQU87QUFDaEQsTUFBSSxPQUFPLE9BQU8sZUFBZSxPQUFPLEdBQUcsR0FBRztBQUM1QyxRQUFJO0FBQ0YsYUFBTyxNQUFNLE1BQU0sV0FBVyxPQUFPLEdBQUc7QUFBQSxJQUMxQyxRQUFRO0FBQ04sYUFBTyxNQUFNO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixZQUFZLEdBQTRCO0FBRzVELFFBQU0sVUFBb0IsRUFBRSxHQUFHLEVBQUU7QUFDakMsTUFBSSxRQUFRLE9BQU8sQ0FBQyxlQUFlLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFlBQVEsTUFBTSxNQUFNLFdBQVcsUUFBUSxHQUFHO0FBQUEsRUFDNUM7QUFDQSxRQUFNLE9BQU8sWUFBWSxPQUFPO0FBQ2xDO0FBQ0EsZUFBc0IsZUFBZSxPQUE2QztBQUNoRixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEMsUUFBTSxZQUFZLElBQUk7QUFDdEIsU0FBTztBQUNUO0FBSUEsZUFBc0IsY0FBd0M7QUFDNUQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUFZLEdBQW1DO0FBQ25FLFFBQU0sT0FBTyxZQUFZLENBQUM7QUFDNUI7QUFDQSxlQUFzQix5QkFBaUQ7QUFDckUsU0FBTyxPQUFPLHFCQUFxQjtBQUNyQztBQUNBLGVBQXNCLHVCQUF1QixLQUFtQztBQUM5RSxRQUFNLE9BQU8sdUJBQXVCLEdBQUc7QUFDekM7QUFJQSxlQUFzQixnQkFBMEM7QUFDOUQsUUFBTSxJQUFJLE1BQU0sT0FBTyxZQUFZO0FBRW5DLFFBQU0sTUFBdUI7QUFBQSxJQUMzQixHQUFHO0FBQUEsSUFDSCxlQUFlLEVBQUUsa0JBQWtCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDeEQsd0JBQ0UsRUFBRSwyQkFBMkIsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUNwRCxrQkFBa0IsRUFBRSxxQkFBcUIsU0FBWSxPQUFPLEVBQUU7QUFBQSxFQUNoRTtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLGNBQWMsR0FBbUM7QUFDckUsUUFBTSxPQUFPLGNBQWMsQ0FBQztBQUM5QjtBQUlBLFNBQVMsV0FBbUI7QUFDMUIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQzdDO0FBRUEsZUFBc0IsY0FBdUQ7QUFDM0UsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUNwQixRQUNBLE9BQ3lCO0FBQ3pCLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxNQUFNLElBQUksTUFBTSxLQUFLO0FBQUEsSUFDekIsWUFBWTtBQUFBLElBQ1osV0FBVyxTQUFTO0FBQUEsSUFDcEIsZUFBZTtBQUFBLElBQ2YsZ0JBQWdCO0FBQUEsSUFDaEIsZUFBZTtBQUFBLEVBQ2pCO0FBQ0EsTUFBSSxJQUFJLGNBQWMsU0FBUyxHQUFHO0FBQ2hDLFFBQUksWUFBWSxTQUFTO0FBQ3pCLFFBQUksYUFBYTtBQUFBLEVBQ25CO0FBQ0EsUUFBTSxPQUF1QixFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEQsTUFBSSxNQUFNLElBQUk7QUFDZCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGlCQUFpQixRQUFnQixPQUE4QjtBQUNuRixRQUFNLFlBQVksUUFBUSxFQUFFLGVBQWUsTUFBTSxDQUFDO0FBQ3BEO0FBSUEsZUFBc0IsZ0JBQW9EO0FBQ3hFLFNBQU8sT0FBTyxZQUFZO0FBQzVCO0FBRUEsZUFBc0IsYUFBYSxRQUEyQztBQUM1RSxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFNBQU8sSUFBSSxNQUFNLEtBQUs7QUFDeEI7QUFFQSxlQUFzQixhQUFhLFFBQWdCLEtBQStCO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsTUFBSSxNQUFNLElBQUk7QUFDZCxRQUFNLE9BQU8sY0FBYyxHQUFHO0FBQ2hDO0FBRUEsZUFBc0IsZUFBZSxRQUErQjtBQUNsRSxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFNBQU8sSUFBSSxNQUFNO0FBQ2pCLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFJQSxlQUFzQixjQUFtQztBQUN2RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUVBLGVBQXNCLGVBQWUsSUFBbUM7QUFDdEUsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixNQUFJLFFBQVEsRUFBRTtBQUNkLE1BQUksSUFBSSxTQUFTLGtCQUFtQixLQUFJLFNBQVM7QUFDakQsUUFBTSxPQUFPLFlBQVksR0FBRztBQUM1QixTQUFPO0FBQ1Q7QUFFQSxlQUFzQixnQkFBK0I7QUFDbkQsUUFBTSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQzdCO0FBSUEsZUFBc0Isb0JBQTZFO0FBQ2pHLFNBQU8sT0FBTyxnQkFBZ0I7QUFDaEM7QUFFQSxlQUFzQixrQkFDcEIsS0FDZTtBQUNmLFFBQU0sT0FBTyxrQkFBa0IsR0FBRztBQUNwQztBQVVPLFNBQVMsY0FDZCxPQUNBLFVBQ0EsU0FDQSxRQUNBLGNBQXVCLE9BQ2Y7QUFDUixTQUFPLEdBQUcsS0FBSyxJQUFJLFFBQVEsSUFBSSxPQUFPLElBQUksTUFBTSxJQUFJLGNBQWMsTUFBTSxHQUFHO0FBQzdFO0FBR0EsZUFBc0Isb0JBQW9CLFVBQW1DO0FBQzNFLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxRQUFNLFNBQVMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLFFBQVEsRUFBRSxZQUFZO0FBQzNELE1BQUksU0FBUztBQUNiLGFBQVcsVUFBVSxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ3JDLFVBQU0sUUFBUSxJQUFJLE1BQU07QUFDeEIsUUFBSSxDQUFDLE1BQU87QUFDWixlQUFXLE9BQU8sT0FBTyxLQUFLLEtBQUssR0FBRztBQUNwQyxZQUFNLElBQUksTUFBTSxHQUFHO0FBQ25CLFVBQUksS0FBSyxFQUFFLEtBQUssUUFBUTtBQUN0QixlQUFPLE1BQU0sR0FBRztBQUNoQixrQkFBVTtBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLEtBQUssS0FBSyxFQUFFLFdBQVcsRUFBRyxRQUFPLElBQUksTUFBTTtBQUFBLEVBQ3hEO0FBQ0EsTUFBSSxTQUFTLEVBQUcsT0FBTSxrQkFBa0IsR0FBRztBQUMzQyxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixrQkFBcUQ7QUFDekUsU0FBTyxPQUFPLGNBQWM7QUFDOUI7QUFFQSxlQUFzQixvQkFBcUM7QUFDekQsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixlQUFlLFFBQWdCLFNBQWdDO0FBQ25GLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUFBLEVBQ2hDO0FBQ0Y7QUFFQSxlQUFzQixlQUFlLFFBQWdCLFNBQWdDO0FBQ25GLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxRQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLE1BQUksQ0FBQyxJQUFLO0FBQ1YsUUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxNQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUNqQixRQUFNLE9BQU8sZ0JBQWdCLENBQUM7QUFDaEM7QUFFQSxlQUFzQixvQkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLHFCQUF3RDtBQUM1RSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBRUEsZUFBc0IsdUJBQXdDO0FBQzVELFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0Isa0JBQWtCLFlBQTJCLFNBQWdDO0FBQ2pHLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxRQUFNLFNBQVMsY0FBYztBQUM3QixRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUFBLEVBQ25DO0FBQ0Y7QUFFQSxlQUFzQixrQkFBa0IsU0FBZ0M7QUFDdEUsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksVUFBVTtBQUNkLGFBQVcsVUFBVSxPQUFPLEtBQUssQ0FBQyxHQUFHO0FBQ25DLFVBQU0sTUFBTSxFQUFFLE1BQU07QUFDcEIsUUFBSSxDQUFDLElBQUs7QUFDVixVQUFNLFdBQVcsSUFBSSxPQUFPLENBQUMsT0FBTyxPQUFPLE9BQU87QUFDbEQsUUFBSSxTQUFTLFdBQVcsSUFBSSxRQUFRO0FBQ2xDLGdCQUFVO0FBQ1YsVUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLEVBQUUsTUFBTTtBQUFBLFVBQ3JDLEdBQUUsTUFBTSxJQUFJO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxRQUFTLE9BQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUNoRDtBQUVBLGVBQXNCLHVCQUdaO0FBQ1IsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFFBQUksSUFBSSxTQUFTLEVBQUcsUUFBTyxFQUFFLFFBQVEsU0FBUyxJQUFJLENBQUMsRUFBRztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0IsWUFBWSxTQUFtQztBQUNuRSxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsYUFBVyxTQUFTLE9BQU8sT0FBTyxHQUFHLEdBQUc7QUFDdEMsUUFBSSxTQUFTLFdBQVcsTUFBTyxRQUFPO0FBQUEsRUFDeEM7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixvQkFBaUQ7QUFDckUsU0FBTyxPQUFPLGdCQUFnQjtBQUNoQztBQUNBLGVBQXNCLGtCQUFrQixHQUFzQztBQUM1RSxRQUFNLE9BQU8sa0JBQWtCLENBQUM7QUFDbEM7QUFDQSxlQUFzQix1QkFBb0Q7QUFDeEUsU0FBTyxPQUFPLG1CQUFtQjtBQUNuQztBQUNBLGVBQXNCLHFCQUFxQixHQUFzQztBQUMvRSxRQUFNLE9BQU8scUJBQXFCLENBQUM7QUFDckM7QUFDQSxlQUFzQix1QkFBMEQ7QUFDOUUsU0FBTyxPQUFPLG1CQUFtQjtBQUNuQztBQUNBLGVBQXNCLHFCQUFxQixHQUE0QztBQUNyRixRQUFNLE9BQU8scUJBQXFCLENBQUM7QUFDckM7QUFZQSxlQUFzQixvQkFBb0IsVUFNdkM7QUFDRCxRQUFNLFlBQVksSUFBSSxJQUFJLENBQUMsR0FBRyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsQ0FBQztBQUNuRSxRQUFNLGFBQWEsQ0FBQyxNQUF1QixVQUFVLElBQUksRUFBRSxZQUFZLENBQUM7QUFHeEUsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLGtCQUFrQjtBQUN0QixhQUFXLEtBQUssT0FBTyxLQUFLLFFBQVEsR0FBRztBQUNyQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxTQUFTLENBQUM7QUFDakIseUJBQW1CO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLFlBQVksUUFBUTtBQUdqQyxRQUFNLFVBQVUsTUFBTSxjQUFjO0FBQ3BDLE1BQUksaUJBQWlCO0FBQ3JCLGFBQVcsS0FBSyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3BDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLFFBQVEsQ0FBQztBQUNoQix3QkFBa0I7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sY0FBYyxPQUFPO0FBR2xDLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxNQUFJLDBCQUEwQjtBQUM5QixhQUFXLEtBQUssT0FBTyxLQUFLLEdBQUcsR0FBRztBQUNoQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxJQUFJLENBQUM7QUFDWixpQ0FBMkI7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGtCQUFrQixHQUFHO0FBRzNCLFFBQU0sS0FBSyxNQUFNLGdCQUFnQjtBQUNqQyxNQUFJLHdCQUF3QjtBQUM1QixhQUFXLEtBQUssT0FBTyxLQUFLLEVBQUUsR0FBRztBQUMvQixRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxHQUFHLENBQUM7QUFDWCwrQkFBeUI7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sZ0JBQWdCLEVBQUU7QUFLL0IsUUFBTSxLQUFLLE1BQU0sbUJBQW1CO0FBQ3BDLE1BQUksdUJBQXVCO0FBQzNCLGFBQVcsS0FBSyxPQUFPLEtBQUssRUFBRSxHQUFHO0FBQy9CLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQiwrQkFBeUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHO0FBQ3RDLGFBQU8sR0FBRyxDQUFDO0FBQUEsSUFDYjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sbUJBQW1CLEVBQUU7QUFFbEMsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBSUEsZUFBc0IsV0FBMEI7QUFDOUMsUUFBTSxRQUFRLFFBQVEsTUFBTSxNQUFNO0FBQ3BDOzs7QUNwaEJBLElBQUksWUFBNkM7QUFFMUMsU0FBUyxlQUFlLElBQWtDO0FBQy9ELGNBQVk7QUFDZDtBQUVBLFNBQVMsU0FBaUI7QUFDeEIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNoQztBQUVBLGVBQWUsS0FBSyxPQUFpQixLQUFhLFNBQWlEO0FBQ2pHLFFBQU0sS0FBZSxFQUFFLElBQUksT0FBTyxHQUFHLE9BQU8sS0FBSyxTQUFTLE9BQU8sT0FBTyxFQUFFO0FBRTFFLFFBQU0sT0FBTyxpQkFBaUIsTUFBTSxZQUFZLENBQUMsSUFBSSxHQUFHO0FBQ3hELE1BQUksVUFBVSxRQUFTLFNBQVEsTUFBTSxNQUFNLEdBQUcsT0FBTztBQUFBLFdBQzVDLFVBQVUsT0FBUSxTQUFRLEtBQUssTUFBTSxHQUFHLE9BQU87QUFBQSxNQUNuRCxTQUFRLElBQUksTUFBTSxHQUFHLE9BQU87QUFFakMsTUFBSTtBQUNGLFVBQU0sZUFBZSxFQUFFO0FBQUEsRUFDekIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDJDQUEyQyxHQUFHO0FBQUEsRUFDN0Q7QUFFQSxNQUFJO0FBQ0YsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCLFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUFFTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxNQUFNLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN2RixTQUFPLEtBQUssU0FBUyxLQUFLLE9BQU87QUFDbkM7QUFFTyxTQUFTLGNBQWMsS0FBeUQ7QUFDckYsTUFBSSxlQUFlLE9BQU87QUFDeEIsV0FBTyxFQUFFLFNBQVMsSUFBSSxTQUFTLE9BQU8sSUFBSSxTQUFTLEtBQUs7QUFBQSxFQUMxRDtBQUNBLE1BQUk7QUFDRixXQUFPLEVBQUUsU0FBUyxPQUFPLEdBQUcsR0FBRyxPQUFPLEtBQUs7QUFBQSxFQUM3QyxRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsdUJBQXVCLE9BQU8sS0FBSztBQUFBLEVBQ3ZEO0FBQ0Y7QUFPQSxTQUFTLE9BQU8sS0FBdUQ7QUFDckUsUUFBTSxNQUErQixDQUFDO0FBQ3RDLGFBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQ3hDLFFBQUksRUFBRSxZQUFZLEVBQUUsU0FBUyxPQUFPLEtBQUssRUFBRSxZQUFZLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtBQUMzRixVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1gsV0FBVyxPQUFPLE1BQU0sWUFBWSwrQkFBK0IsS0FBSyxDQUFDLEdBQUc7QUFDMUUsVUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLDZCQUE2Qix1QkFBdUI7QUFBQSxJQUN6RSxXQUFXLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxNQUFNO0FBQ25ELFVBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsSUFDOUIsT0FBTztBQUNMLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7OztBQ3ZFQSxJQUFNLFdBQVc7QUFDakIsSUFBTSxXQUFXO0FBK0JWLElBQU0sY0FBTixjQUEwQixNQUFNO0FBQUEsRUFDckM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBO0FBQUEsRUFFQSxZQUFZLE1BT1Q7QUFDRCxVQUFNLEtBQUssT0FBTztBQUNsQixTQUFLLE9BQU87QUFDWixTQUFLLFNBQVMsS0FBSztBQUNuQixTQUFLLE9BQU8sS0FBSztBQUNqQixTQUFLLFlBQVksS0FBSztBQUN0QixTQUFLLFdBQVcsS0FBSztBQUNyQixTQUFLLG1CQUFtQixLQUFLLG9CQUFvQjtBQUFBLEVBQ25EO0FBQ0Y7QUFFTyxJQUFNLGVBQU4sTUFBbUI7QUFBQSxFQUNQO0FBQUEsRUFFakIsWUFBWSxVQUFvQjtBQUM5QixTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBO0FBQUEsRUFHQSxNQUFNLFNBQTBCO0FBQzlCLFVBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDL0MsV0FBUSxJQUEyQixTQUFTO0FBQUEsRUFDOUM7QUFBQTtBQUFBLEVBR0EsTUFBTSxhQUFhLFFBQWtDO0FBQ25ELFFBQUk7QUFDRixZQUFNLEtBQUs7QUFBQSxRQUNUO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxtQkFBbUIsTUFBTSxDQUFDO0FBQUEsTUFDNUY7QUFDQSxhQUFPO0FBQUEsSUFDVCxTQUFTLEtBQUs7QUFDWixVQUFJLGVBQWUsZUFBZSxJQUFJLGFBQWEsWUFBYSxRQUFPO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFHQSxNQUFNLG1CQUEwRjtBQUM5RixVQUFNLEtBQUssTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQzlDLFVBQU0sT0FBTyxNQUFNLEtBQUssVUFBVSxPQUFPLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxFQUFFO0FBQzlGLFVBQU0sSUFBSTtBQUNWLFdBQU87QUFBQSxNQUNMLE9BQVEsR0FBeUI7QUFBQSxNQUNqQyxXQUFXLEVBQUU7QUFBQSxNQUNiLGdCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sYUFBYSxZQUE0QztBQUM3RCxVQUFNLE1BQU0sR0FBRyxRQUFRLElBQUksS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssU0FBUyxNQUFNLElBQUksVUFBVTtBQUMxRyxVQUFNLE1BQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxNQUMzQixRQUFRO0FBQUEsTUFDUixTQUFTLEVBQUUsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFBQSxJQUMxRCxDQUFDO0FBQ0QsUUFBSSxJQUFJLFdBQVcsSUFBSyxRQUFPO0FBQy9CLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxNQUFNLEtBQUssVUFBVSxLQUFLLFdBQVcsVUFBVSxFQUFFO0FBQ3BFLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxXQUFXLE1BQXNDO0FBQ3JELFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsUUFDckI7QUFBQSxRQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDLFFBQVEsbUJBQW1CLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxNQUNsSTtBQUNBLFlBQU0sSUFBSTtBQUNWLGFBQU8sRUFBRSxPQUFPO0FBQUEsSUFDbEIsU0FBUyxLQUFLO0FBQ1osVUFBSSxlQUFlLGVBQWUsSUFBSSxhQUFhLFlBQWEsUUFBTztBQUN2RSxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxNQUFNLFFBQVEsTUFBOEM7QUFDMUQsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxNQUFNLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDO0FBQzVGLFFBQUksTUFBcUIsS0FBSyxlQUFlO0FBQzdDLFVBQU0sY0FBYztBQUVwQixhQUFTLFVBQVUsR0FBRyxXQUFXLGFBQWEsV0FBVztBQUN2RCxZQUFNLE9BQWdDO0FBQUEsUUFDcEMsU0FBUyxLQUFLO0FBQUEsUUFDZCxTQUFTLEtBQUs7QUFBQSxRQUNkLFFBQVEsS0FBSyxTQUFTO0FBQUEsTUFDeEI7QUFDQSxVQUFJLElBQUssTUFBSyxNQUFNO0FBQ3BCLFVBQUk7QUFDRixjQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxLQUFLLElBQUk7QUFDakQsY0FBTSxNQUFNO0FBQ1osZUFBTyxFQUFFLE1BQU0sSUFBSSxRQUFRLE1BQU0sS0FBSyxJQUFJLFFBQVEsS0FBSyxLQUFLLElBQUksUUFBUSxTQUFTO0FBQUEsTUFDbkYsU0FBUyxLQUFLO0FBQ1osWUFBSSxFQUFFLGVBQWUsYUFBYyxPQUFNO0FBQ3pDLFlBQUksSUFBSSxXQUFXLE9BQU8sQ0FBQyxLQUFLO0FBRTlCLGdCQUFNLE1BQU0sS0FBSyxXQUFXLElBQUk7QUFDaEMsY0FBSSxDQUFDLElBQUssT0FBTTtBQUNoQjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLENBQUMsSUFBSSxhQUFhLFlBQVksWUFBYSxPQUFNO0FBQ3JELGNBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxJQUFJLE1BQU0sbUNBQW1DLElBQUksRUFBRTtBQUFBLEVBQzNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBLE1BQU0sWUFBWSxNQUFzRDtBQUN0RSxRQUFJLEtBQUssTUFBTSxXQUFXLEVBQUcsT0FBTSxJQUFJLE1BQU0saUNBQWlDO0FBQzlFLFVBQU0sY0FBYztBQUNwQixRQUFJLFVBQW1CO0FBRXZCLGFBQVMsVUFBVSxHQUFHLFdBQVcsYUFBYSxXQUFXO0FBQ3ZELFVBQUk7QUFDRixjQUFNLFFBQVEsTUFBTSxRQUFRO0FBQUEsVUFDMUIsS0FBSyxNQUFNLElBQUksT0FBTyxTQUFTO0FBQzdCLGtCQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsY0FDckI7QUFBQSxjQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLGNBQ25EO0FBQUEsZ0JBQ0UsU0FBUyxLQUFLO0FBQUEsZ0JBQ2QsVUFBVTtBQUFBLGNBQ1o7QUFBQSxZQUNGO0FBQ0EsbUJBQU87QUFBQSxjQUNMLE1BQU0sS0FBSztBQUFBLGNBQ1gsS0FBTSxJQUF3QjtBQUFBLFlBQ2hDO0FBQUEsVUFDRixDQUFDO0FBQUEsUUFDSDtBQUVBLGNBQU0sT0FBTyxNQUFNLEtBQUssY0FBYztBQUN0QyxjQUFNLE9BQU8sTUFBTSxLQUFLO0FBQUEsVUFDdEI7QUFBQSxVQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLFVBQ25EO0FBQUEsWUFDRSxXQUFXLEtBQUs7QUFBQSxZQUNoQixNQUFNLE1BQU0sSUFBSSxDQUFDLFVBQVU7QUFBQSxjQUN6QixNQUFNLEtBQUs7QUFBQSxjQUNYLE1BQU07QUFBQSxjQUNOLE1BQU07QUFBQSxjQUNOLEtBQUssS0FBSztBQUFBLFlBQ1osRUFBRTtBQUFBLFVBQ0o7QUFBQSxRQUNGO0FBQ0EsY0FBTSxVQUFXLEtBQXlCO0FBQzFDLGNBQU0sU0FBUyxNQUFNLEtBQUs7QUFBQSxVQUN4QjtBQUFBLFVBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsVUFDbkQ7QUFBQSxZQUNFLFNBQVMsS0FBSztBQUFBLFlBQ2QsTUFBTTtBQUFBLFlBQ04sU0FBUyxDQUFDLEtBQUssR0FBRztBQUFBLFVBQ3BCO0FBQUEsUUFDRjtBQUNBLGNBQU0sWUFBWTtBQUNsQixZQUFJO0FBQ0YsZ0JBQU0sS0FBSztBQUFBLFlBQ1Q7QUFBQSxZQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxtQkFBbUIsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsWUFDdEc7QUFBQSxjQUNFLEtBQUssVUFBVTtBQUFBLGNBQ2YsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRixTQUFTLEtBQUs7QUFDWixjQUFJLFdBQVcsR0FBRyxLQUFLLFVBQVUsYUFBYTtBQUM1QyxzQkFBVTtBQUNWLGtCQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUNuQztBQUFBLFVBQ0Y7QUFDQSxnQkFBTTtBQUFBLFFBQ1I7QUFDQSxlQUFPO0FBQUEsVUFDTCxXQUFXLFVBQVU7QUFBQSxVQUNyQixLQUFLLFVBQVU7QUFBQSxVQUNmLE9BQU8sS0FBSyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSTtBQUFBLFFBQzNDO0FBQUEsTUFDRixTQUFTLEtBQUs7QUFDWixrQkFBVTtBQUNWLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFLLENBQUMsSUFBSSxhQUFhLENBQUMsV0FBVyxHQUFHLEtBQU0sWUFBWSxZQUFhLE9BQU07QUFDM0UsY0FBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLG1CQUFtQixRQUFRLFVBQVUsSUFBSSxNQUFNLGlDQUFpQztBQUFBLEVBQ3hGO0FBQUEsRUFFQSxNQUFjLGdCQUEyRDtBQUN2RSxVQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDckI7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxrQkFBa0IsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsSUFDdkc7QUFDQSxVQUFNLFVBQVcsSUFBb0MsT0FBTztBQUM1RCxVQUFNLFNBQVMsTUFBTSxLQUFLO0FBQUEsTUFDeEI7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxnQkFBZ0IsT0FBTztBQUFBLElBQzVFO0FBQ0EsV0FBTztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsU0FBVSxPQUFxQyxLQUFLO0FBQUEsSUFDdEQ7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFjLFVBQVUsUUFBZ0IsTUFBYyxNQUFrQztBQUN0RixVQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU0sSUFBSSxPQUFPLEdBQUcsUUFBUSxHQUFHLElBQUk7QUFDL0QsVUFBTSxPQUFvQjtBQUFBLE1BQ3hCO0FBQUEsTUFDQSxTQUFTO0FBQUEsUUFDUCxlQUFlLFVBQVUsS0FBSyxTQUFTLEdBQUc7QUFBQSxRQUMxQyxRQUFRO0FBQUEsUUFDUix3QkFBd0I7QUFBQSxRQUN4QixHQUFJLE9BQU8sRUFBRSxnQkFBZ0IsbUJBQW1CLElBQUksQ0FBQztBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxHQUFJLE9BQU8sRUFBRSxNQUFNLEtBQUssVUFBVSxJQUFJLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDL0M7QUFDQSxRQUFJO0FBQ0osUUFBSTtBQUNGLFlBQU0sTUFBTSxNQUFNLEtBQUssSUFBSTtBQUFBLElBQzdCLFNBQVMsUUFBUTtBQUNmLFlBQU0sSUFBSSxZQUFZO0FBQUEsUUFDcEIsUUFBUTtBQUFBLFFBQ1IsTUFBTTtBQUFBLFFBQ04sU0FBUyxZQUFZLGNBQWMsTUFBTSxFQUFFLE9BQU87QUFBQSxRQUNsRCxXQUFXO0FBQUEsUUFDWCxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLFNBQWtCO0FBQ3RCLFVBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixRQUFJLE1BQU07QUFDUixVQUFJO0FBQ0YsaUJBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxNQUMxQixRQUFRO0FBQ04saUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxNQUFNLEtBQUssb0JBQW9CLEtBQUssUUFBUSxHQUFHLE1BQU0sSUFBSSxJQUFJLEVBQUU7QUFDbEYsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE1BQWMsVUFBVSxLQUFlLE9BQXFDO0FBQzFFLFFBQUksU0FBa0I7QUFDdEIsUUFBSTtBQUNGLFlBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixVQUFJLEtBQU0sVUFBUyxLQUFLLE1BQU0sSUFBSTtBQUFBLElBQ3BDLFFBQVE7QUFBQSxJQUVSO0FBQ0EsV0FBTyxLQUFLLG9CQUFvQixLQUFLLFFBQVEsS0FBSztBQUFBLEVBQ3BEO0FBQUEsRUFFUSxvQkFBb0IsS0FBZSxNQUFlLE9BQTRCO0FBQ3BGLFVBQU0sTUFDSixPQUFPLFNBQVMsWUFBWSxRQUFRLGFBQWEsT0FDN0MsT0FBUSxLQUE4QixPQUFPLElBQzdDLElBQUk7QUFDVixRQUFJLFdBQW9DO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0FBRTVDLFlBQU0sT0FBTyxJQUFJLFFBQVEsSUFBSSx1QkFBdUI7QUFDcEQsVUFBSSxTQUFTLE9BQU8sY0FBYyxLQUFLLEdBQUcsR0FBRztBQUMzQyxtQkFBVztBQUNYLG9CQUFZO0FBQUEsTUFDZCxPQUFPO0FBQ0wsbUJBQVc7QUFBQSxNQUNiO0FBQUEsSUFDRixXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQUEsSUFDYixXQUFXLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0FBQ25ELGlCQUFXO0FBQUEsSUFDYixXQUFXLElBQUksVUFBVSxLQUFLO0FBQzVCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkLFdBQVcsSUFBSSxXQUFXLEtBQUs7QUFDN0IsaUJBQVc7QUFDWCxrQkFBWTtBQUFBLElBQ2Q7QUFDQSxXQUFPLElBQUksWUFBWTtBQUFBLE1BQ3JCLFFBQVEsSUFBSTtBQUFBLE1BQ1o7QUFBQSxNQUNBLFNBQVMsR0FBRyxLQUFLLFdBQU0sSUFBSSxNQUFNLEtBQUssR0FBRztBQUFBLE1BQ3pDO0FBQUEsTUFDQTtBQUFBLE1BQ0Esa0JBQWtCLGFBQWEsZUFBZSxvQkFBb0IsSUFBSSxPQUFPLElBQUk7QUFBQSxJQUNuRixDQUFDO0FBQUEsRUFDSDtBQUNGO0FBUUEsU0FBUyxvQkFBb0IsU0FBaUM7QUFDNUQsUUFBTSxRQUFRLFFBQVEsSUFBSSxtQkFBbUI7QUFDN0MsTUFBSSxPQUFPO0FBQ1QsVUFBTSxJQUFJLE9BQU8sU0FBUyxPQUFPLEVBQUU7QUFDbkMsUUFBSSxPQUFPLFNBQVMsQ0FBQyxLQUFLLElBQUksRUFBRyxRQUFPO0FBQUEsRUFDMUM7QUFDQSxRQUFNLGFBQWEsUUFBUSxJQUFJLGFBQWE7QUFDNUMsTUFBSSxZQUFZO0FBQ2QsVUFBTSxRQUFRLE9BQU8sU0FBUyxZQUFZLEVBQUU7QUFDNUMsUUFBSSxPQUFPLFNBQVMsS0FBSyxLQUFLLFNBQVMsR0FBRztBQUN4QyxhQUFPLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJLElBQUk7QUFBQSxJQUN6QztBQUNBLFVBQU0sU0FBUyxLQUFLLE1BQU0sVUFBVTtBQUNwQyxRQUFJLE9BQU8sU0FBUyxNQUFNLEVBQUcsUUFBTyxLQUFLLE1BQU0sU0FBUyxHQUFJO0FBQUEsRUFDOUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFdBQVcsTUFBc0I7QUFFeEMsU0FBTyxLQUFLLE1BQU0sR0FBRyxFQUFFLElBQUksa0JBQWtCLEVBQUUsS0FBSyxHQUFHO0FBQ3pEO0FBRUEsU0FBUyxVQUFVLFNBQWlCLEtBQTBCO0FBRTVELFFBQU0sT0FBTyxJQUFJLGFBQWEsZUFBZSxNQUFPO0FBQ3BELFFBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksR0FBRztBQUM3QyxTQUFPLEtBQUssSUFBSSxLQUFRLE9BQU8sTUFBTSxVQUFVLEtBQUssTUFBTTtBQUM1RDtBQUVBLFNBQVMsV0FBVyxLQUFrQztBQUNwRCxTQUFPLGVBQWUsZUFBZSxJQUFJLGFBQWE7QUFDeEQ7QUFFQSxTQUFTLE1BQU0sSUFBMkI7QUFDeEMsU0FBTyxJQUFJLFFBQVEsQ0FBQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUM7QUFDN0M7QUFFTyxTQUFTQSxVQUFTLE9BQXVCO0FBRTlDLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEtBQUs7QUFDM0MsTUFBSSxNQUFNO0FBQ1YsYUFBVyxLQUFLLEtBQU0sUUFBTyxPQUFPLGFBQWEsQ0FBQztBQUNsRCxTQUFPLEtBQUssR0FBRztBQUNqQjs7O0FDN1dBLElBQU0sY0FBYztBQVNwQixJQUFNLHVCQUE0QyxvQkFBSSxJQUFJLENBQUMsV0FBVyxDQUFDO0FBRWhFLFNBQVMsVUFBVSxTQUFrQixLQUF3QztBQUNsRixRQUFNLFlBQVksY0FBYyxPQUFPO0FBQ3ZDLFFBQU0sU0FBMkIsQ0FBQztBQUNsQyxRQUFNLFdBQXFCLENBQUM7QUFDNUIsUUFBTSxRQUFRLG9CQUFJLElBQVk7QUFDOUIsUUFBTSxhQUFhLG9CQUFJLElBQTJCO0FBQ2xELFFBQU0sa0JBQWtCLHFCQUFxQixJQUFJLElBQUksUUFBUTtBQUM3RCxhQUFXLE9BQU8sV0FBVztBQUMzQixRQUFJO0FBQ0YsWUFBTSxJQUFJLFdBQVcsS0FBSyxHQUFHO0FBQzdCLFVBQUksQ0FBQyxHQUFHO0FBQ04sWUFBSSxpQkFBaUI7QUFHbkIsZ0JBQU0sVUFBVSxZQUFZLEtBQUssR0FBRztBQUNwQyxjQUFJLFFBQVMsWUFBVyxJQUFJLFFBQVEsVUFBVSxRQUFRLFdBQVc7QUFBQSxRQUNuRTtBQUNBO0FBQUEsTUFDRjtBQUNBLGVBQVMsS0FBSyxFQUFFLFFBQVE7QUFDeEIsWUFBTSxJQUFJLEVBQUUsUUFBUTtBQUNwQixVQUFJLElBQUksZUFBZSxTQUFTLEtBQUssSUFBSSxlQUFlLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxHQUFHO0FBQzNGLGVBQU8sS0FBSyxDQUFDO0FBQUEsTUFDZjtBQUFBLElBQ0YsUUFBUTtBQUFBLElBRVI7QUFBQSxFQUNGO0FBR0EsUUFBTSxjQUF1RSxDQUFDO0FBQzlFLGFBQVcsQ0FBQyxJQUFJLElBQUksS0FBSyxZQUFZO0FBQ25DLFFBQUksTUFBTSxJQUFJLEVBQUUsRUFBRztBQUNuQixnQkFBWSxLQUFLLEVBQUUsVUFBVSxJQUFJLGFBQWEsS0FBSyxDQUFDO0FBQUEsRUFDdEQ7QUFDQSxTQUFPLEVBQUUsUUFBUSxjQUFjLFVBQVUsWUFBWTtBQUN2RDtBQUVBLFNBQVMsWUFDUCxNQUNBLEtBQ3lEO0FBQ3pELE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBR1YsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFHOUMsUUFBTSxLQUFLLEVBQUU7QUFDYixNQUFJLE9BQU8sV0FBVyxPQUFPLGdDQUFnQyxDQUFDLElBQUksRUFBRSxNQUFNLEdBQUc7QUFDM0UsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLFNBQ0gsT0FBTyxFQUFFLFlBQVksWUFBWSxFQUFFLFdBQ25DLE9BQU8sSUFBSSxFQUFFLFlBQVksR0FBRyxXQUFXLFlBQ3JDLElBQUksSUFBSSxFQUFFLFlBQVksR0FBRyxNQUFNLEdBQUc7QUFDdkMsTUFBSSxPQUFPLFdBQVcsWUFBWSxDQUFDLFlBQVksS0FBSyxNQUFNLEVBQUcsUUFBTztBQUNwRSxTQUFPLEVBQUUsVUFBVSxRQUFRLGFBQWEsZUFBZSxNQUFNLFFBQVEsR0FBRyxFQUFFO0FBQzVFO0FBRUEsU0FBUyxlQUFlLE1BQWUsU0FBaUIsS0FBc0M7QUFDNUYsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLGFBQWEsSUFBSSxJQUFJLElBQUksRUFBRSxJQUFJLEdBQUcsWUFBWSxHQUFHLE1BQU07QUFDN0QsU0FDRSxVQUFVLElBQUksWUFBWSxJQUFJLEdBQUcsV0FBVyxLQUM1QyxVQUFVLElBQUksWUFBWSxNQUFNLEdBQUcsV0FBVyxLQUM5QyxVQUFVLElBQUksRUFBRSxNQUFNLEdBQUcsV0FBVyxLQUNwQyx3QkFBd0IsTUFBTSxPQUFPLEtBQ3JDLHdCQUF3QixJQUFJLFNBQVM7QUFFekM7QUFFQSxTQUFTLHdCQUF3QixNQUFlLFNBQWdDO0FBQzlFLFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sTUFBTSxNQUFNLElBQUk7QUFDdEIsUUFBSSxPQUFPLFFBQVEsVUFBVTtBQUMzQixZQUFNLFNBQVMsbUJBQW1CLEtBQUssT0FBTztBQUM5QyxVQUFJLE9BQVEsUUFBTztBQUNuQjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVTtBQUM3QyxRQUFJLEtBQUssSUFBSSxHQUFhLEVBQUc7QUFDN0IsU0FBSyxJQUFJLEdBQWE7QUFDdEIsUUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQ3RCLGlCQUFXLEtBQUssSUFBSyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ25DLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxHQUE4QixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDN0U7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxtQkFBbUIsUUFBZ0IsU0FBZ0M7QUFDMUUsTUFBSTtBQUNGLFVBQU0sTUFBTSxJQUFJLElBQUksUUFBUSxnQkFBZ0I7QUFDNUMsUUFBSSxJQUFJLGFBQWEsV0FBVyxJQUFJLGFBQWEsY0FBZSxRQUFPO0FBQ3ZFLFVBQU0sUUFBUSxJQUFJLFNBQVMsTUFBTSxzREFBc0Q7QUFDdkYsUUFBSSxDQUFDLFNBQVMsTUFBTSxDQUFDLE1BQU0sUUFBUyxRQUFPO0FBQzNDLFdBQU8sTUFBTSxDQUFDLEtBQUs7QUFBQSxFQUNyQixRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsd0JBQXdCLFFBQWtEO0FBQ2pGLE1BQUksQ0FBQyxPQUFRLFFBQU87QUFDcEIsTUFBSTtBQUNGLFVBQU0sTUFBTSxJQUFJLElBQUksTUFBTTtBQUMxQixRQUFJLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxjQUFlLFFBQU87QUFDdkUsVUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLG9DQUFvQztBQUNyRSxXQUFPLFFBQVEsQ0FBQyxLQUFLO0FBQUEsRUFDdkIsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLGNBQWNDLE1BQXlCO0FBSzlDLFFBQU0sTUFBaUIsQ0FBQztBQUN4QixRQUFNLE9BQU8sb0JBQUksUUFBZ0I7QUFDakMsUUFBTSxRQUFtQixDQUFDQSxJQUFHO0FBQzdCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxPQUFPLE1BQU0sSUFBSTtBQUN2QixRQUFJLFNBQVMsUUFBUSxTQUFTLE9BQVc7QUFDekMsUUFBSSxPQUFPLFNBQVMsU0FBVTtBQUM5QixRQUFJLEtBQUssSUFBSSxJQUFjLEVBQUc7QUFDOUIsU0FBSyxJQUFJLElBQWM7QUFFdkIsUUFBSSxlQUFlLElBQUksR0FBRztBQUN4QixVQUFJLEtBQUssWUFBWSxJQUFJLENBQUM7QUFBQSxJQUM1QjtBQUNBLFFBQUksTUFBTSxRQUFRLElBQUksR0FBRztBQUN2QixpQkFBVyxLQUFLLEtBQU0sT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNwQyxPQUFPO0FBQ0wsaUJBQVcsS0FBSyxPQUFPLE9BQU8sSUFBK0IsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQzlFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsZUFBZSxNQUFnRDtBQUN0RSxNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLFFBQU0sV0FBVyxFQUFFO0FBQ25CLE1BQ0UsYUFBYSxXQUNiLGFBQWEsZ0NBQ2IsYUFBYSxrQkFDYjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FBTyxPQUFPLEVBQUUsWUFBWSxZQUFZLE9BQU8sRUFBRSxXQUFXLFlBQVksRUFBRSxXQUFXO0FBQ3ZGO0FBRUEsU0FBUyxZQUFZLE1BQXdEO0FBQzNFLE1BQUksS0FBSyxlQUFlLGdDQUFnQyxPQUFPLEtBQUssVUFBVSxVQUFVO0FBQ3RGLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFdBQVcsS0FBYyxLQUE4QztBQUM5RSxNQUFJLE9BQU8sUUFBUSxZQUFZLFFBQVEsS0FBTSxRQUFPO0FBQ3BELFFBQU0sSUFBSTtBQUVWLE1BQUksRUFBRSxlQUFlLGlCQUFrQixRQUFPO0FBRTlDLFFBQU0sU0FBUyxVQUFVLEVBQUUsT0FBTztBQUtsQyxRQUFNLFNBQVMsSUFBSSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQ2pDLE1BQUksQ0FBQyxPQUFRLFFBQU87QUFFcEIsUUFBTSxPQUFPLElBQUksRUFBRSxJQUFJO0FBQ3ZCLFFBQU0sYUFBYSxJQUFJLElBQUksTUFBTSxZQUFZLEdBQUcsTUFBTTtBQUd0RCxRQUFNLGNBQWMsSUFBSSxZQUFZLElBQUk7QUFDeEMsUUFBTSxhQUFhLElBQUksWUFBWSxNQUFNO0FBQ3pDLFFBQU0sZ0JBQWdCLElBQUksWUFBWSxNQUFNO0FBQzVDLFFBQU0sU0FDSixVQUFVLGFBQWEsV0FBVyxLQUNsQyxVQUFVLFlBQVksV0FBVyxLQUNqQyxVQUFVLFlBQVksV0FBVyxLQUNqQyxVQUFVLE9BQU8sV0FBVztBQUM5QixRQUFNLFlBQ0osVUFBVSxZQUFZLE9BQU8sS0FDN0IsVUFBVSxZQUFZLE1BQU0sS0FDNUIsVUFBVSxPQUFPLFdBQVc7QUFDOUIsTUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFXLFFBQU87QUFNbEMsUUFBTSxTQUFTLG9CQUFvQixZQUFZLGFBQWEsWUFBWSxhQUFhO0FBRXJGLFFBQU0sWUFBWSxJQUFJLElBQUksSUFBSSxFQUFFLFVBQVUsR0FBRyxrQkFBa0IsR0FBRyxNQUFNO0FBQ3hFLFFBQU0sZUFBZSxVQUFVLFdBQVcsSUFBSTtBQUM5QyxRQUFNLGlCQUFpQixVQUFVLE9BQU8sU0FBUyxLQUFLO0FBQ3RELFFBQU0sT0FBTyxnQkFBZ0I7QUFDN0IsUUFBTSxjQUFjLGlCQUFpQixXQUFXLFFBQVEsY0FBYztBQUN0RSxRQUFNLGdCQUFnQixxQkFBcUIsR0FBRyxRQUFRLElBQUksVUFBVTtBQUVwRSxRQUFNLFdBQVcsSUFBSSxPQUFPLFFBQVEsS0FBSyxDQUFDO0FBQzFDLFFBQU0sbUJBQW1CLElBQUksV0FBVyxVQUFVO0FBQ2xELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxXQUFXLGdCQUFnQixvQkFBb0IsUUFBUTtBQUM3RCxRQUFNLE9BQU8sWUFBWSxvQkFBb0IsUUFBUTtBQUNyRCxRQUFNLFFBQVEsYUFBYSxNQUFNO0FBRWpDLFFBQU0sWUFBWSxrQkFBa0IsR0FBRyxNQUFNO0FBSTdDLFFBQU0sV0FDSixpQkFBaUIsVUFBVSxPQUFPLFVBQVUsQ0FBQyxLQUFLLGlCQUFpQixVQUFVLEVBQUUsVUFBVSxDQUFDO0FBQzVGLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFFdEIsUUFBTSxRQUFRLElBQUksRUFBRSxLQUFLO0FBQ3pCLFFBQU0sWUFBWSxVQUFVLE9BQU8sS0FBSyxLQUFLLFVBQVUsVUFBVSxPQUFPLEtBQUssQ0FBQztBQUU5RSxRQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzFCLFFBQU0sUUFBUSxJQUFJLE9BQU8sS0FBSztBQUU5QixRQUFNLFFBQXdCO0FBQUEsSUFDNUIsVUFBVTtBQUFBLElBQ1YsZ0JBQWdCO0FBQUEsSUFDaEIsWUFBWTtBQUFBLElBQ1osV0FBVztBQUFBLElBQ1gsbUJBQW1CLElBQUk7QUFBQSxJQUN2QixjQUFjLElBQUk7QUFBQSxJQUNsQixzQkFBc0I7QUFBQSxJQUN0QixXQUFXLEdBQUcsZ0JBQWdCLElBQUksTUFBTSxXQUFXLE1BQU07QUFBQSxJQUN6RCxZQUFZO0FBQUEsSUFDWixpQkFBaUIsVUFBVSxPQUFPLG1CQUFtQjtBQUFBLElBQ3JELG1CQUFtQixVQUFVLE9BQU8seUJBQXlCO0FBQUEsSUFDN0Qsa0JBQWtCLFVBQVUsT0FBTyx1QkFBdUI7QUFBQSxJQUMxRCxxQkFBcUIsVUFBVSxPQUFPLHVCQUF1QjtBQUFBLElBQzdELGlCQUFpQixVQUFVLE9BQU8sb0JBQW9CO0FBQUEsSUFDdEQsb0JBQW9CO0FBQUEsTUFDbEIsSUFBSSxJQUFJLE9BQU8sdUJBQXVCLEdBQUcsTUFBTSxHQUFHLFdBQy9DLE9BQW1DO0FBQUEsSUFDeEM7QUFBQSxJQUNBO0FBQUEsSUFDQSxlQUFlLGlCQUFpQixNQUFNLElBQUk7QUFBQSxJQUMxQyxNQUFNLFVBQVUsT0FBTyxJQUFJO0FBQUEsSUFDM0Isb0JBQW9CLFdBQVcsT0FBTyxrQkFBa0I7QUFBQSxJQUN4RCxRQUFRLFVBQVUsT0FBTyxNQUFNLEtBQUssVUFBVSxFQUFFLE1BQU07QUFBQSxJQUN0RCxpQkFBaUIsVUFBVSxPQUFPLFNBQVM7QUFBQSxJQUMzQztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVksVUFBVSxPQUFPLGNBQWM7QUFBQSxJQUMzQyxlQUFlLFVBQVUsT0FBTyxhQUFhO0FBQUEsSUFDN0MsYUFBYSxVQUFVLE9BQU8sV0FBVztBQUFBLElBQ3pDLGFBQWEsVUFBVSxPQUFPLFdBQVc7QUFBQSxJQUN6QyxZQUFZO0FBQUEsSUFDWixnQkFBZ0IsVUFBVSxPQUFPLGNBQWM7QUFBQSxJQUMvQyxvQkFBb0I7QUFBQSxNQUNsQjtBQUFBLFFBQ0UsYUFBYSxJQUFJO0FBQUEsUUFDakIsT0FBTyxVQUFVLE9BQU8sY0FBYztBQUFBLFFBQ3RDLFVBQVUsVUFBVSxPQUFPLGFBQWE7QUFBQSxRQUN4QyxTQUFTLFVBQVUsT0FBTyxXQUFXO0FBQUEsUUFDckMsUUFBUSxVQUFVLE9BQU8sV0FBVztBQUFBLFFBQ3BDLE9BQU87QUFBQSxRQUNQLFdBQVcsVUFBVSxPQUFPLGNBQWM7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFBQSxJQUNBO0FBQUEsSUFDQSxnQkFBZ0I7QUFBQSxJQUNoQixjQUFjO0FBQUEsSUFDZCxhQUFhO0FBQUEsSUFDYixzQkFBc0I7QUFBQSxJQUN0QixnQkFBZ0I7QUFBQSxJQUNoQixnQkFBZ0IsSUFBSTtBQUFBLElBQ3BCLGdCQUFnQjtBQUFBLEVBQ2xCO0FBRUEsU0FBTztBQUNUO0FBRUEsU0FBUyxrQkFBa0IsR0FBNEIsUUFBNEM7QUFDakcsTUFBSSxPQUFPLDJCQUEyQixPQUFPLHdCQUF5QixRQUFPO0FBQzdFLE1BQUksT0FBTywwQkFBMkIsUUFBTztBQUM3QyxNQUFJLE9BQU8sb0JBQW9CLFFBQVEsT0FBTyxxQkFBc0IsUUFBTztBQUMzRSxNQUFJLEVBQUUsZUFBZSw4QkFBOEI7QUFBQSxFQUVuRDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLFVBQVUsSUFBSSxPQUFRLEVBQXdCLElBQUksSUFBSTtBQUFBLEVBQ3RGLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxnQkFBZ0IsVUFBNkM7QUFDcEUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFNBQU8sSUFDSjtBQUFBLElBQUksQ0FBQyxNQUNKLE9BQU8sTUFBTSxZQUFZLEtBQUssaUJBQWlCLElBQzNDLE9BQVEsRUFBK0IsV0FBVyxJQUNsRDtBQUFBLEVBQ04sRUFDQyxPQUFPLENBQUMsTUFBbUIsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLENBQUM7QUFDckU7QUFFQSxTQUFTLFlBQVksVUFBZ0Q7QUFDbkUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFFBQU0sTUFBbUIsQ0FBQztBQUMxQixhQUFXLEtBQUssS0FBSztBQUNuQixRQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTTtBQUN6QyxVQUFNLElBQUk7QUFDVixVQUFNLFFBQVEsVUFBVSxFQUFFLEdBQUc7QUFDN0IsVUFBTSxXQUFXLFVBQVUsRUFBRSxZQUFZO0FBQ3pDLFVBQU0sVUFBVSxVQUFVLEVBQUUsV0FBVztBQUN2QyxRQUFJLENBQUMsU0FBUyxDQUFDLFNBQVU7QUFDekIsUUFBSSxLQUFLLEVBQUUsT0FBTyxVQUFVLFNBQVMsV0FBVyxTQUFTLENBQUM7QUFBQSxFQUM1RDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsYUFBYSxRQUE4QztBQUNsRSxRQUFNLFdBQVcsSUFBSSxPQUFPLGlCQUFpQjtBQUM3QyxRQUFNLFVBQVUsV0FBVyxRQUFRLFNBQVMsS0FBSyxJQUFJLENBQUM7QUFDdEQsUUFBTSxVQUFVLFFBQVEsSUFBSSxPQUFPLFFBQVEsR0FBRyxLQUFLO0FBQ25ELFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sU0FBUyxDQUFDLEdBQUcsU0FBUyxHQUFHLE9BQU8sRUFBRSxPQUFPLENBQUMsTUFBTTtBQUNwRCxRQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTSxRQUFPO0FBQ2hELFVBQU0sS0FDSixVQUFXLEVBQThCLFNBQVMsS0FDbEQsVUFBVyxFQUE4QixNQUFNO0FBQ2pELFFBQUksQ0FBQyxHQUFJLFFBQU87QUFDaEIsUUFBSSxLQUFLLElBQUksRUFBRSxFQUFHLFFBQU87QUFDekIsU0FBSyxJQUFJLEVBQUU7QUFDWCxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0QsU0FBTyxPQUFPLElBQUksQ0FBQyxRQUFRLFdBQVcsR0FBOEIsQ0FBQztBQUN2RTtBQUVBLFNBQVMsV0FBVyxHQUF1QztBQUN6RCxRQUFNLE9BQU8sVUFBVSxFQUFFLElBQUk7QUFDN0IsUUFBTSxXQUFXLGdCQUFnQixHQUFHLElBQUk7QUFDeEMsUUFBTUMsUUFBTyxJQUFJLEVBQUUsYUFBYTtBQUNoQyxRQUFNLFlBQVksSUFBSSxFQUFFLFVBQVU7QUFDbEMsUUFBTSxhQUFhLFVBQVUsV0FBVyxlQUFlO0FBQ3ZELFFBQU0sVUFBVSxVQUFVLEVBQUUsWUFBWTtBQUN4QyxRQUFNLFVBQ0osVUFBVSxFQUFFLFNBQVMsS0FDckIsVUFBVSxFQUFFLE1BQU0sS0FDbEIsR0FBRyxRQUFRLE9BQU8sSUFBSSxLQUFLLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUMzRCxTQUFPO0FBQUEsSUFDTCxVQUFVO0FBQUEsSUFDVixZQUFhLFFBQVE7QUFBQSxJQUNyQixjQUFjLFlBQVk7QUFBQSxJQUMxQixtQkFBbUI7QUFBQSxJQUNuQixRQUFRO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxjQUFjLGVBQWUsT0FBTyxhQUFhLE1BQU87QUFBQSxJQUN4RCxPQUFPLFVBQVVBLE9BQU0sS0FBSztBQUFBLElBQzVCLFFBQVEsVUFBVUEsT0FBTSxNQUFNO0FBQUEsSUFDOUIsVUFBVTtBQUFBLElBQ1YsZ0JBQWdCO0FBQUEsSUFDaEIsa0JBQWtCO0FBQUEsSUFDbEIsaUJBQWlCO0FBQUEsRUFDbkI7QUFDRjtBQUVBLFNBQVMsZ0JBQWdCLEdBQTRCLE1BQW9DO0FBQ3ZGLE1BQUksU0FBUyxRQUFTLFFBQU8sVUFBVSxFQUFFLGVBQWUsS0FBSyxVQUFVLEVBQUUsU0FBUztBQUNsRixRQUFNLFdBQVcsUUFBUSxJQUFJLEVBQUUsVUFBVSxHQUFHLFFBQVE7QUFDcEQsTUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLFVBQVUsRUFBRSxlQUFlO0FBRTdELE1BQUksT0FBZ0Q7QUFDcEQsYUFBVyxLQUFLLFVBQVU7QUFDeEIsVUFBTSxLQUFLLFVBQVUsRUFBRSxZQUFZO0FBQ25DLFVBQU0sTUFBTSxVQUFVLEVBQUUsR0FBRztBQUMzQixRQUFJLENBQUMsSUFBSztBQUNWLFFBQUksT0FBTyxhQUFhO0FBQ3RCLFlBQU0sS0FBSyxVQUFVLEVBQUUsT0FBTyxLQUFLO0FBQ25DLFVBQUksQ0FBQyxRQUFRLEtBQUssS0FBSyxRQUFTLFFBQU8sRUFBRSxLQUFLLFNBQVMsR0FBRztBQUFBLElBQzVELFdBQVcsQ0FBQyxNQUFNO0FBRWhCLGFBQU8sRUFBRSxLQUFLLFNBQVMsRUFBRTtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNBLFNBQU8sTUFBTSxPQUFPO0FBQ3RCO0FBRUEsU0FBUyxpQkFBaUIsTUFBYyxNQUEyQjtBQUNqRSxNQUFJLEtBQUssV0FBVyxFQUFHLFFBQU87QUFDOUIsTUFBSSxNQUFNO0FBQ1YsYUFBVyxLQUFLLEtBQU0sT0FBTSxJQUFJLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVE7QUFDOUQsU0FBTztBQUNUO0FBRUEsU0FBUyxpQkFBaUIsR0FBaUM7QUFDekQsTUFBSSxDQUFDLEVBQUcsUUFBTztBQUVmLFFBQU0sSUFBSSxJQUFJLEtBQUssQ0FBQztBQUNwQixNQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU87QUFDdEMsU0FBTyxFQUFFLFlBQVk7QUFDdkI7QUFFQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsU0FBTyxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsSUFBSSxJQUFJO0FBQ3JEO0FBQ0EsU0FBUyxXQUFXLEdBQTRCO0FBQzlDLFNBQU8sT0FBTyxNQUFNLFlBQVksSUFBSTtBQUN0QztBQUNBLFNBQVMsVUFBVSxHQUEyQjtBQUM1QyxNQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUN4RCxNQUFJLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxHQUFHO0FBQ3pDLFVBQU0sSUFBSSxPQUFPLENBQUM7QUFDbEIsUUFBSSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFBQSxFQUNqQztBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsVUFBVSxHQUFvQjtBQUNyQyxTQUFPLFVBQVUsQ0FBQyxLQUFLO0FBQ3pCO0FBQ0EsU0FBUyxJQUFJLEdBQTRDO0FBQ3ZELFNBQU8sT0FBTyxNQUFNLFlBQVksTUFBTSxRQUFRLENBQUMsTUFBTSxRQUFRLENBQUMsSUFDekQsSUFDRDtBQUNOO0FBQ0EsU0FBUyxRQUFRLEdBQXVCO0FBQ3RDLFNBQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUM7QUFDakM7QUF3QkEsU0FBUyxpQkFDUCxXQUNBLFFBQ0EsVUFDUztBQUNULE1BQUksVUFBVyxRQUFPO0FBQ3RCLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFDdEIsUUFBTSxXQUFXLElBQUksT0FBTyxRQUFRO0FBQ3BDLFFBQU0sT0FBTyxXQUFXLFNBQVMsT0FBTztBQUN4QyxNQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDdkIsZUFBVyxLQUFLLE1BQU07QUFDcEIsVUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU07QUFDekMsWUFBTSxNQUFPLEVBQThCO0FBSTNDLFVBQUksT0FBTyxRQUFRLFlBQVksd0JBQXdCLEtBQUssR0FBRyxHQUFHO0FBQ2hFLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFrQk8sU0FBUyxjQUNkLFFBQ0EsVUFDa0I7QUFDbEIsTUFBSSxTQUFTLFNBQVMsRUFBRyxRQUFPO0FBS2hDLFFBQU0sZ0JBQWdCLG9CQUFJLElBQVk7QUFDdEMsUUFBTSxtQkFBbUIsb0JBQUksSUFBWTtBQUN6QyxhQUFXLEtBQUssUUFBUTtBQUN0QixRQUFJLENBQUMsU0FBUyxJQUFJLEVBQUUsZUFBZSxZQUFZLENBQUMsRUFBRztBQUNuRCxxQkFBaUIsSUFBSSxFQUFFLFFBQVE7QUFDL0IsUUFBSSxFQUFFLGdCQUFpQixlQUFjLElBQUksRUFBRSxlQUFlO0FBQzFELFFBQUksRUFBRSxtQkFBb0IsZUFBYyxJQUFJLEVBQUUsa0JBQWtCO0FBQ2hFLFFBQUksRUFBRSxrQkFBbUIsZUFBYyxJQUFJLEVBQUUsaUJBQWlCO0FBQUEsRUFDaEU7QUFDQSxTQUFPLE9BQU8sT0FBTyxDQUFDLE1BQU07QUFDMUIsVUFBTSxJQUFJLEVBQUUsZUFBZSxZQUFZO0FBQ3ZDLFFBQUksU0FBUyxJQUFJLENBQUMsRUFBRyxRQUFPO0FBRTVCLFFBQUksY0FBYyxJQUFJLEVBQUUsUUFBUSxFQUFHLFFBQU87QUFFMUMsUUFBSSxFQUFFLG1CQUFtQixpQkFBaUIsSUFBSSxFQUFFLGVBQWUsRUFBRyxRQUFPO0FBQ3pFLFFBQUksRUFBRSxzQkFBc0IsaUJBQWlCLElBQUksRUFBRSxrQkFBa0IsRUFBRyxRQUFPO0FBQy9FLFFBQUksRUFBRSxxQkFBcUIsaUJBQWlCLElBQUksRUFBRSxpQkFBaUIsRUFBRyxRQUFPO0FBRTdFLFFBQUksRUFBRSxvQkFBb0IsU0FBUyxJQUFJLEVBQUUsaUJBQWlCLFlBQVksQ0FBQyxFQUFHLFFBQU87QUFDakYsZUFBVyxLQUFLLEVBQUUsVUFBVTtBQUMxQixVQUFJLFNBQVMsSUFBSSxFQUFFLFlBQVksQ0FBQyxFQUFHLFFBQU87QUFBQSxJQUM1QztBQUNBLFdBQU87QUFBQSxFQUNULENBQUM7QUFDSDtBQVNBLFNBQVMscUJBQ1AsR0FDQSxRQUNBLFlBQ3NCO0FBQ3RCLFFBQU0sUUFBUSxJQUFJLEVBQUUsZUFBZSxLQUFLLElBQUksT0FBTyxlQUFlO0FBQ2xFLE1BQUksQ0FBQyxNQUFPLFFBQU87QUFDbkIsUUFBTSxXQUFXLElBQUksTUFBTSxRQUFRO0FBQ25DLFFBQU0sT0FBTyxJQUFJLE1BQU0sSUFBSTtBQUMzQixRQUFNLFVBQVUsVUFBVSxVQUFVLElBQUk7QUFDeEMsUUFBTSxRQUFRLFVBQVUsTUFBTSxLQUFLO0FBQ25DLFFBQU0sYUFBYSxVQUFVLE1BQU0sVUFBVTtBQUM3QyxRQUFNLGlCQUFpQixVQUFVLE1BQU0sY0FBYztBQUNyRCxRQUFNLFNBQVMsVUFBVSxNQUFNLE1BQU0sS0FBSyxVQUFVLE1BQU0sT0FBTztBQUVqRSxNQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxPQUFRLFFBQU87QUFDMUMsU0FBTztBQUFBLElBQ0wsU0FBUztBQUFBLElBQ1Q7QUFBQSxJQUNBLGFBQWE7QUFBQSxJQUNiO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxJQUNqQixhQUFhO0FBQUEsRUFDZjtBQUNGO0FBT0EsU0FBUyxvQkFDUCxZQUNBLGFBQ0EsWUFDQSxlQUNjO0FBQ2QsUUFBTSxlQUFlLElBQUksWUFBWSxZQUFZO0FBQ2pELFNBQU87QUFBQSxJQUNMLGNBQ0UsVUFBVSxhQUFhLElBQUksS0FBSyxVQUFVLFlBQVksSUFBSSxLQUFLLFVBQVUsWUFBWSxJQUFJO0FBQUEsSUFDM0YsWUFDRSxVQUFVLGVBQWUsU0FBUyxLQUNsQyxVQUFVLFlBQVksdUJBQXVCLEtBQzdDLFVBQVUsWUFBWSx1QkFBdUI7QUFBQSxJQUMvQyxVQUFVLFdBQVcsY0FBYyxRQUFRLEtBQUssV0FBVyxZQUFZLFFBQVE7QUFBQSxJQUMvRSxrQkFBa0IsV0FBVyxZQUFZLGdCQUFnQjtBQUFBLElBQ3pELGVBQWUsVUFBVSxjQUFjLGFBQWEsS0FBSyxVQUFVLFlBQVksYUFBYTtBQUFBLElBQzVGLGFBQWEsVUFBVSxZQUFZLFdBQVc7QUFBQSxJQUM5QyxVQUFVLFVBQVUsSUFBSSxZQUFZLFFBQVEsR0FBRyxRQUFRLEtBQUssVUFBVSxZQUFZLFFBQVE7QUFBQSxJQUMxRixLQUFLLFVBQVUsWUFBWSxHQUFHO0FBQUEsSUFDOUIsaUJBQWlCLFVBQVUsWUFBWSxlQUFlO0FBQUEsSUFDdEQsZUFBZSxVQUFVLFlBQVksYUFBYTtBQUFBLElBQ2xELGdCQUFnQixVQUFVLFlBQVksY0FBYztBQUFBLElBQ3BELG9CQUNFLGlCQUFpQixVQUFVLGFBQWEsVUFBVSxDQUFDLEtBQ25ELGlCQUFpQixVQUFVLFlBQVksVUFBVSxDQUFDO0FBQUEsSUFDcEQsV0FBVyxXQUFXLFlBQVksU0FBUztBQUFBLEVBQzdDO0FBQ0Y7QUFPQSxTQUFTLFlBQVksR0FBOEM7QUFDakUsUUFBTSxPQUFPLElBQUksRUFBRSxJQUFJO0FBQ3ZCLFFBQU0sYUFBYSxJQUFJLE1BQU0sTUFBTTtBQUNuQyxNQUFJLENBQUMsV0FBWSxRQUFPO0FBQ3hCLFFBQU0sV0FBVyxXQUFXO0FBQzVCLFFBQU0sUUFBaUMsQ0FBQztBQUN4QyxNQUFJLE1BQU0sUUFBUSxRQUFRLEdBQUc7QUFDM0IsZUFBVyxNQUFNLFVBQVU7QUFDekIsVUFBSSxPQUFPLE9BQU8sWUFBWSxPQUFPLEtBQU07QUFDM0MsWUFBTSxJQUFJO0FBQ1YsWUFBTSxJQUFJLFVBQVUsRUFBRSxHQUFHO0FBQ3pCLFlBQU0sSUFBSSxJQUFJLEVBQUUsS0FBSztBQUNyQixVQUFJLENBQUMsS0FBSyxDQUFDLEVBQUc7QUFDZCxZQUFNLENBQUMsSUFDTCxVQUFVLEVBQUUsWUFBWSxLQUN4QixVQUFVLElBQUksRUFBRSxXQUFXLEdBQUcsR0FBRyxLQUNqQyxVQUFVLElBQUksRUFBRSxpQkFBaUIsR0FBRyxPQUFPO0FBQUEsSUFDL0M7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLFVBQVUsV0FBVyxJQUFJO0FBQ3RDLFFBQU0sVUFBVSxVQUFVLFdBQVcsR0FBRztBQUN4QyxRQUFNLFlBQ0osT0FBTyxNQUFNLFlBQVksTUFBTSxXQUFZLE1BQU0sWUFBWSxJQUFlO0FBQzlFLFFBQU0sUUFBUSxPQUFPLE1BQU0sT0FBTyxNQUFNLFdBQVksTUFBTSxPQUFPLElBQWU7QUFDaEYsUUFBTSxjQUNKLE9BQU8sTUFBTSxhQUFhLE1BQU0sV0FBWSxNQUFNLGFBQWEsSUFBZTtBQUNoRixRQUFNLFlBQ0gsT0FBTyxNQUFNLGdDQUFnQyxNQUFNLFdBQy9DLE1BQU0sZ0NBQWdDLElBQ3ZDLFVBQ0gsT0FBTyxNQUFNLDBCQUEwQixNQUFNLFdBQ3pDLE1BQU0sMEJBQTBCLElBQ2pDLFVBQ0gsT0FBTyxNQUFNLDhCQUE4QixNQUFNLFdBQzdDLE1BQU0sOEJBQThCLElBQ3JDO0FBQ04sTUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLFNBQVUsUUFBTztBQUN6RCxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0EsVUFBVTtBQUFBLElBQ1YsWUFBWTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsSUFDQSxXQUFXO0FBQUEsRUFDYjtBQUNGOzs7QUNodEJBLElBQU0sV0FBVztBQUVWLFNBQVMsV0FBbUI7QUFDakMsUUFBTSxLQUFLLEtBQUssSUFBSTtBQUNwQixNQUFJLFNBQVM7QUFDYixNQUFJLElBQUk7QUFDUixXQUFTLElBQUksR0FBRyxJQUFJLElBQUksS0FBSztBQUMzQixjQUFVLFNBQVMsSUFBSSxFQUFFLEtBQUssT0FBTztBQUNyQyxRQUFJLEtBQUssTUFBTSxJQUFJLEVBQUU7QUFBQSxFQUN2QjtBQUNBLFFBQU0sT0FBTyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3RELE1BQUksV0FBVztBQUNmLGFBQVcsS0FBSyxLQUFNLGFBQVksU0FBUyxJQUFJLEVBQUUsS0FBSztBQUN0RCxTQUFPLFNBQVM7QUFDbEI7QUFFTyxTQUFTLFdBQVcsSUFBb0I7QUFDN0MsU0FBTyxHQUFHLE1BQU0sRUFBRTtBQUNwQjs7O0FDUEEsSUFBTSxtQkFBaUQsb0JBQUksSUFBSTtBQUFBLEVBQzdEO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFFTSxTQUFTLGtCQUFrQixNQUErQjtBQUMvRCxRQUFNLFdBQTRCLENBQUM7QUFDbkMsTUFBSSxVQUFrQyxDQUFDO0FBQ3ZDLE1BQUksYUFBYTtBQUNqQixRQUFNLFFBQVEsTUFBTTtBQUNsQixRQUFJLFFBQVEsVUFBVSxRQUFRLE9BQU87QUFDbkMsVUFBSSxDQUFDLFFBQVEsU0FBVSxTQUFRLFdBQVc7QUFDMUMsZUFBUyxLQUFLLE9BQXdCO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBQ0EsYUFBVyxXQUFXLEtBQUssTUFBTSxJQUFJLEdBQUc7QUFDdEMsVUFBTSxPQUFPLGNBQWMsT0FBTztBQUNsQyxRQUFJLEtBQUssS0FBSyxNQUFNLEdBQUk7QUFDeEIsUUFBSSxnQkFBZ0IsS0FBSyxJQUFJLEdBQUc7QUFDOUIsbUJBQWE7QUFDYjtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsV0FBWTtBQUVqQixVQUFNLFlBQVksS0FBSyxNQUFNLDRCQUE0QjtBQUN6RCxRQUFJLFdBQVc7QUFDYixZQUFNO0FBQ04sZ0JBQVUsRUFBRSxRQUFRLFFBQVEsVUFBVSxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2hEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sd0JBQXdCO0FBQ3RELFFBQUksY0FBYyxDQUFDLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFDckMsWUFBTTtBQUNOLGdCQUFVLEVBQUUsUUFBUSxRQUFRLFdBQVcsQ0FBQyxLQUFLLEVBQUUsRUFBRTtBQUNqRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGFBQWEsS0FBSyxNQUFNLHVCQUF1QjtBQUNyRCxRQUFJLGNBQWMsUUFBUSxRQUFRO0FBQ2hDLGNBQVEsUUFBUSxRQUFRLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDM0M7QUFBQSxJQUNGO0FBQ0EsVUFBTSxnQkFBZ0IsS0FBSyxNQUFNLDBCQUEwQjtBQUMzRCxRQUFJLGlCQUFpQixRQUFRLFFBQVE7QUFDbkMsWUFBTSxNQUFNLFFBQVEsY0FBYyxDQUFDLEtBQUssRUFBRTtBQUMxQyxjQUFRLFdBQVcsaUJBQWlCLElBQUksR0FBc0IsSUFDekQsTUFDRDtBQUNKO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxRQUFNO0FBQ04sU0FBTyxTQUFTLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxTQUFTLENBQUM7QUFDbkQ7QUFFQSxTQUFTLGNBQWMsTUFBc0I7QUFHM0MsUUFBTSxNQUFNLEtBQUssUUFBUSxHQUFHO0FBQzVCLFNBQU8sUUFBUSxLQUFLLE9BQU8sS0FBSyxNQUFNLEdBQUcsR0FBRztBQUM5QztBQUVBLFNBQVMsUUFBUSxHQUFtQjtBQUNsQyxRQUFNLFVBQVUsRUFBRSxLQUFLO0FBQ3ZCLE1BQ0csUUFBUSxXQUFXLEdBQUcsS0FBSyxRQUFRLFNBQVMsR0FBRyxLQUMvQyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEdBQ2hEO0FBQ0EsV0FBTyxRQUFRLE1BQU0sR0FBRyxFQUFFO0FBQUEsRUFDNUI7QUFDQSxTQUFPO0FBQ1Q7OztBQ05BLElBQU0sY0FBYyxRQUFRLFFBQVEsWUFBWSxFQUFFO0FBRWxELGVBQWUsQ0FBQyxPQUFpQjtBQUMvQixVQUFRLFFBQVEsWUFBWSxFQUFFLE1BQU0sYUFBYSxPQUFPLEdBQUcsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUM5RSxDQUFDO0FBSUQsUUFBUSxRQUFRLFlBQVksWUFBWSxZQUFZO0FBQ2xELFFBQU0sS0FBSyx1QkFBdUIsRUFBRSxTQUFTLFlBQVksQ0FBQztBQUMxRCxRQUFNLE9BQU8sU0FBUztBQUN4QixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxNQUFNO0FBQzFDLE9BQUssT0FBTyxTQUFTO0FBQ3ZCLENBQUM7QUFHRCxLQUFLLE9BQU8sYUFBYTtBQUV6QixlQUFlLE9BQU8sUUFBK0I7QUFDbkQsTUFBSTtBQUNGLFVBQU0sYUFBYTtBQUNuQixVQUFNLHNCQUFzQjtBQUM1QixVQUFNLDRCQUE0QjtBQUNsQyxVQUFNLHFCQUFxQjtBQUczQixVQUFNLFNBQVMsTUFBTSxvQkFBb0IsS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFJO0FBQ2pFLFFBQUksU0FBUyxFQUFHLE9BQU0sS0FBSywwQkFBMEIsRUFBRSxPQUFPLENBQUM7QUFDL0QsVUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFJLFNBQVMsT0FBTyxTQUFTLFNBQVMsU0FBUyxNQUFNO0FBQ25ELFlBQU0saUJBQWlCLEtBQUs7QUFDNUIsWUFBTSxvQkFBb0IsS0FBSztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTztBQUFBLFFBQ1AsZUFBZTtBQUFBLFFBQ2Ysd0JBQXdCO0FBQUEsUUFDeEIsa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUNELFlBQU0sS0FBSyx3Q0FBd0MsRUFBRSxPQUFPLENBQUM7QUFBQSxJQUMvRDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFPLGVBQWUsRUFBRSxRQUFRLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQy9EO0FBQ0Y7QUFZQSxlQUFlLHVCQUFzQztBQUNuRCxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUFBLEVBQ3ZGLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyw2QkFBNkIsY0FBYyxHQUFHLENBQUM7QUFDMUQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVU7QUFDaEMsUUFBSTtBQUNGLFlBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPLENBQUMsY0FBYztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXRCLE9BQU87QUFBQSxNQUNULENBQUM7QUFDRCxZQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTyxDQUFDLFlBQVk7QUFBQSxNQUN0QixDQUFDO0FBQ0QsWUFBTSxLQUFLLHFDQUFxQztBQUFBLFFBQzlDLE9BQU8sSUFBSTtBQUFBLFFBQ1gsS0FBSyxXQUFXLElBQUksT0FBTyxFQUFFO0FBQUEsTUFDL0IsQ0FBQztBQUFBLElBQ0gsU0FBUyxLQUFLO0FBSVosWUFBTSxLQUFLLHdDQUF3QztBQUFBLFFBQ2pELE9BQU8sSUFBSTtBQUFBLFFBQ1gsS0FBSyxXQUFXLElBQUksT0FBTyxFQUFFO0FBQUEsUUFDN0IsR0FBRyxjQUFjLEdBQUc7QUFBQSxNQUN0QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWUsZUFBOEI7QUFDM0MsUUFBTSxRQUFRLE9BQU8sTUFBTSxhQUFhO0FBQ3hDLFFBQU0sUUFBUSxPQUFPLE1BQU0sbUJBQW1CO0FBQzlDLFFBQU0sUUFBUSxPQUFPLE9BQU8sZUFBZSxFQUFFLGlCQUFpQixvQkFBb0IsQ0FBQztBQUNuRixRQUFNLFFBQVEsT0FBTyxPQUFPLHFCQUFxQjtBQUFBLElBQy9DLGlCQUFpQixnQ0FBZ0M7QUFBQSxFQUNuRCxDQUFDO0FBQ0g7QUFNQSxJQUFJLGtCQUF5RDtBQUs3RCxJQUFNLGlCQUFpQjtBQUV2QixlQUFlLHdCQUF1QztBQUVwRCxRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixNQUFJLFNBQVMsUUFBUSxFQUFFLFlBQVksT0FBTztBQUN4Qyx1QkFBbUIsRUFBRSxxQkFBcUI7QUFBQSxFQUM1QyxPQUFPO0FBQ0wseUJBQXFCO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsdUJBQTZCO0FBQ3BDLE1BQUksb0JBQW9CLE1BQU07QUFDNUIsa0JBQWMsZUFBZTtBQUM3QixzQkFBa0I7QUFBQSxFQUNwQjtBQUNGO0FBRUEsU0FBUyxtQkFBbUIsYUFBMkI7QUFDckQsdUJBQXFCO0FBQ3JCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLFdBQVcsQ0FBQztBQUFBLEVBQ3ZEO0FBQ0Esb0JBQWtCLFlBQVksTUFBTTtBQUNsQyxTQUFLLGVBQWUsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNuQyxXQUFLLEtBQUssMkJBQTJCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDekQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxlQUFlLHNCQUFxQztBQUNsRCxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLGFBQWE7QUFBQSxJQUNiLGVBQWU7QUFBQSxJQUNmLGVBQWU7QUFBQSxFQUNqQixDQUFDO0FBQ0QscUJBQW1CLEVBQUUscUJBQXFCO0FBQzFDLFFBQU0sS0FBSyw0QkFBNEIsRUFBRSxjQUFjLEVBQUUsc0JBQXNCLENBQUM7QUFFaEYsT0FBSyxlQUFlO0FBQ3BCLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHVCQUFxQjtBQUNyQixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxNQUFNLGVBQWU7QUFBQSxJQUM5QixVQUFVLE1BQU0saUJBQWlCO0FBQUEsSUFDakMsVUFBVSxNQUFNLGlCQUFpQjtBQUFBLEVBQ25DLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUFBLEVBQ3ZGLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpQ0FBaUMsY0FBYyxHQUFHLENBQUM7QUFDOUQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixNQUFJLGNBQWM7QUFDbEIsTUFBSSxnQkFBZ0I7QUFDcEIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxPQUFPLElBQUksT0FBTyxTQUFVO0FBQ2hDLFFBQUksSUFBSSxVQUFXO0FBQ25CLFFBQUk7QUFDRixZQUFNLFVBQVcsTUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3JELFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlQLE1BQU8sTUFBTTtBQUtYLGdCQUFNLHNCQUFzQjtBQUFBLFlBQzFCO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxVQUNGO0FBQ0EsZ0JBQU0sVUFBVSxvQkFBSSxJQUFhO0FBQ2pDLGNBQUksV0FBVztBQUNmLHFCQUFXLE9BQU8scUJBQXFCO0FBQ3JDLHVCQUFXLE1BQU0sTUFBTSxLQUFLLFNBQVMsaUJBQWlCLEdBQUcsQ0FBQyxHQUFHO0FBQzNELGtCQUFJLFFBQVEsSUFBSSxFQUFFLEVBQUc7QUFFckIsb0JBQU0sS0FBSyxHQUFHLGVBQWUsSUFBSSxLQUFLLEVBQUUsWUFBWTtBQUNwRCxrQkFBSSxNQUFNLGVBQWUsTUFBTSxtQkFBb0I7QUFDbkQsb0JBQU0sT0FBTyxHQUFHLHNCQUFzQjtBQUN0QyxrQkFBSSxLQUFLLFVBQVUsS0FBSyxLQUFLLFdBQVcsRUFBRztBQUMzQyxzQkFBUSxJQUFJLEVBQUU7QUFDZCxrQkFBSTtBQUNGLGdCQUFDLEdBQW1CLE1BQU07QUFDMUIsNEJBQVk7QUFBQSxjQUNkLFFBQVE7QUFBQSxjQUVSO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFJQSxnQkFBTSxPQUEwQjtBQUFBLFlBQzlCLEtBQUs7QUFBQSxZQUNMLE1BQU07QUFBQSxZQUNOLFNBQVM7QUFBQSxZQUNULE9BQU87QUFBQSxZQUNQLFNBQVM7QUFBQSxZQUNULFlBQVk7QUFBQSxVQUNkO0FBQ0EsZ0JBQU0sUUFBUyxTQUFTLGlCQUF3QyxTQUFTO0FBQ3pFLGdCQUFNLGNBQWMsSUFBSSxjQUFjLFdBQVcsSUFBSSxDQUFDO0FBQ3RELGdCQUFNLGNBQWMsSUFBSSxjQUFjLFNBQVMsSUFBSSxDQUFDO0FBQ3BELGlCQUFPLFNBQVM7QUFBQSxZQUNkLEtBQUssU0FBUyxnQkFBZ0I7QUFBQSxZQUM5QixVQUFVO0FBQUEsVUFDWixDQUFDO0FBQ0QsaUJBQU8sRUFBRSxTQUFTO0FBQUEsUUFDcEI7QUFBQSxNQUNGLENBQUM7QUFDRCxxQkFBZTtBQUNmLFlBQU0sSUFBSSxRQUFRLENBQUMsR0FBRztBQUN0QixVQUFJLEtBQUssT0FBTyxFQUFFLGFBQWEsU0FBVSxrQkFBaUIsRUFBRTtBQUFBLElBQzlELFFBQVE7QUFBQSxJQUdSO0FBQUEsRUFDRjtBQUNBLE1BQUksY0FBYyxHQUFHO0FBQ25CLFVBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFJLFNBQVMsTUFBTTtBQUNqQixXQUFLLGVBQWU7QUFDcEIsV0FBSyxpQkFBaUI7QUFDdEIsWUFBTSxxQkFBcUIsSUFBSTtBQUFBLElBRWpDO0FBQUEsRUFDRjtBQUNGO0FBRUEsUUFBUSxPQUFPLFFBQVEsWUFBWSxDQUFDLFVBQVU7QUFDNUMsTUFBSSxNQUFNLFNBQVMsZUFBZTtBQUNoQyxTQUFLLGlCQUFpQjtBQUFBLEVBQ3hCLFdBQVcsTUFBTSxTQUFTLHFCQUFxQjtBQUM3QyxTQUFLLGlCQUFpQixLQUFLO0FBQUEsRUFDN0I7QUFJRixDQUFDO0FBSUQsSUFBSSxRQUFRLFFBQVEsV0FBVztBQUM3QixVQUFRLE9BQU8sVUFBVSxZQUFZLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU0sUUFBUSxjQUFjLE9BQU87QUFBQSxJQUNyQyxTQUFTLEtBQUs7QUFFWixZQUFNLEtBQUssMENBQTBDLGNBQWMsR0FBRyxDQUFDO0FBQ3ZFLFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUFBLElBQ3hDO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFJQSxRQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsS0FBYyxZQUFZO0FBQy9ELE1BQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFHLFFBQU87QUFDbkMsU0FBTyxjQUFjLEdBQUcsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUN2QyxTQUFLLE1BQU8sMEJBQTBCLEVBQUUsTUFBTSxJQUFJLE1BQU0sR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQy9FLFVBQU07QUFBQSxFQUNSLENBQUM7QUFDSCxDQUFDO0FBRUQsU0FBUyxpQkFBaUIsR0FBaUM7QUFDekQsU0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFBWSxPQUFRLEVBQXlCLFNBQVM7QUFDbkY7QUFJQSxJQUFNLDRCQUE0QixvQkFBSSxJQUE0QjtBQUFBLEVBQ2hFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBRUQsZUFBZSxZQUE4QjtBQUMzQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsZUFBZSxjQUFjLEtBQXVDO0FBS2xFLE1BQUksQ0FBRSxNQUFNLFVBQVUsS0FBTSwwQkFBMEIsSUFBSSxJQUFJLElBQUksR0FBRztBQUNuRSxXQUFPLEVBQUUsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUFBLEVBQ2xDO0FBQ0EsVUFBUSxJQUFJLE1BQU07QUFBQSxJQUNoQixLQUFLO0FBQ0gsWUFBTSxpQkFBaUIsSUFBSSxVQUFVLElBQUksS0FBSyxJQUFJLFdBQVcsTUFBTSxJQUFJLFFBQVE7QUFDL0UsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdkUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssK0JBQStCLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdEUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxVQUFJLElBQUksVUFBVSxRQUFRO0FBQ3hCLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xELFdBQVcsSUFBSSxVQUFVLFNBQVM7QUFDaEMsY0FBTSxNQUFPLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDcEQsT0FBTztBQUNMLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xEO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxXQUFXLElBQUksTUFBTTtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxXQUFXO0FBQ2pCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGdCQUFnQjtBQUN0QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxTQUFTLE1BQU07QUFDckIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sWUFBWSxJQUFJLFFBQVEsTUFBTTtBQUNwQyxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxlQUFlLEVBQUUsYUFBYSxJQUFJLEdBQUcsQ0FBQztBQUM1QyxZQUFNLEtBQUssd0JBQXdCLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUNqRCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLGtCQUFrQjtBQUNyQixZQUFNLElBQUksTUFBTSxlQUFlLEVBQUUsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNsRCxVQUFJLENBQUMsSUFBSSxJQUFJO0FBR1gsNkJBQXFCO0FBQ3JCLDRCQUFvQjtBQUNwQiwrQkFBdUI7QUFDdkIsY0FBTSxRQUFRLE9BQU8sTUFBTSxjQUFjO0FBQ3pDLGNBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQUEsTUFDL0MsT0FBTztBQUVMLGNBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxZQUFJLFNBQVMsS0FBTSxvQkFBbUIsRUFBRSxxQkFBcUI7QUFBQSxNQUMvRDtBQUNBLFlBQU0sS0FBSyxtQ0FBbUMsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQzVELGFBQU8sV0FBVztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssNEJBQTRCO0FBQy9CLFlBQU0sVUFBVSxLQUFLO0FBQUEsUUFDbkI7QUFBQSxRQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLElBQUksT0FBTyxDQUFDO0FBQUEsTUFDdkQ7QUFDQSxZQUFNLGVBQWUsRUFBRSx1QkFBdUIsUUFBUSxDQUFDO0FBRXZELFlBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxVQUFJLFNBQVMsS0FBTSxvQkFBbUIsT0FBTztBQUM3QyxVQUFJLDBCQUEwQixLQUFNLHNCQUFxQixPQUFPO0FBQ2hFLFVBQUksNkJBQTZCLEtBQU0seUJBQXdCLE9BQU87QUFDdEUsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLGlCQUFpQjtBQUN2QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxrQkFBa0I7QUFDeEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sb0JBQW9CO0FBQzFCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLHFCQUFxQjtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLG1CQUFtQjtBQUN0QixZQUFNLE9BQU8sTUFBTSxZQUFZO0FBQy9CLFlBQU0sVUFBVSxJQUFJLElBQUksS0FBSyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDL0QsWUFBTSxVQUFVLE1BQU0sb0JBQW9CLE9BQU87QUFDakQsWUFBTSxLQUFLLDBCQUEwQixPQUFPO0FBQzVDLGFBQU8sV0FBVztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsWUFBTSxvQkFBb0IsSUFBSTtBQUM5QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxpQkFBaUIsSUFBSTtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxjQUFjO0FBQ3BCLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxRQUFRLFFBQVEsZ0JBQWdCO0FBQ3RDLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQixLQUFLLGVBQWU7QUFDbEIsWUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixZQUFNLE1BQU0sVUFBVSxDQUFDO0FBQ3ZCLFlBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFDakMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCO0FBQUEsSUFDQTtBQUNFLGFBQU8sRUFBRSxJQUFJLE9BQU8sT0FBTyx1QkFBdUI7QUFBQSxFQUN0RDtBQUNGO0FBSUEsZUFBZSxpQkFDYixVQUNBLEtBQ0EsU0FDQSxVQUNlO0FBQ2YsTUFBSSxrQkFBa0IsSUFBSSxRQUFRLEVBQUc7QUFDckMsTUFBSSxDQUFDLGdCQUFnQixJQUFJLFFBQVEsRUFBRztBQUVwQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBZ0JuQyxRQUFNLFVBQVUsSUFBSSxJQUFJLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUUxQyxNQUFJO0FBQ0osTUFBSTtBQUNGLGlCQUFhLFVBQVUsVUFBVTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsZ0JBQWdCLG9CQUFJLElBQVk7QUFBQSxNQUNoQyxXQUFXO0FBQUEsSUFDYixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLFdBQVcsbUJBQW1CLFVBQVUsS0FBSyxVQUFVLEdBQUc7QUFDaEU7QUFBQSxFQUNGO0FBUUEsUUFBTSxlQUFlLFdBQVcsT0FBTztBQUN2QyxhQUFXLFNBQVMsY0FBYyxXQUFXLFFBQVEsT0FBTztBQUM1RCxRQUFNLG1CQUFtQixlQUFlLFdBQVcsT0FBTztBQUMxRCxNQUFJLG1CQUFtQixHQUFHO0FBQ3hCLFVBQU0sS0FBSyw0QkFBNEI7QUFBQSxNQUNyQztBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsTUFBTSxXQUFXLE9BQU87QUFBQSxJQUMxQixDQUFDO0FBQUEsRUFDSDtBQU9BLE1BQUksV0FBVyxhQUFhLFdBQVcsR0FBRztBQUN4QyxVQUFNLEtBQUssNENBQXVDO0FBQUEsTUFDaEQ7QUFBQSxNQUNBLFdBQVcsZUFBZSxRQUFRLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxNQUMvQyxZQUFZLG9CQUFvQixVQUFVLE9BQU87QUFBQSxNQUNqRCxpQkFBaUIsaUJBQWlCLFVBQVUsU0FBUyxDQUFDLE1BQU0sQ0FBQztBQUFBLE1BQzdELG1CQUFtQixpQkFBaUIsVUFBVSxTQUFTLENBQUMsUUFBUSxDQUFDO0FBQUEsTUFDakUsMEJBQTBCLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUM1RDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsTUFDRCwrQkFBK0IsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQ2pFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsTUFDRCxpQ0FBaUMsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQ25FO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSCxPQUFPO0FBQ0wsVUFBTSxLQUFLLHdCQUF3QjtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxVQUFVLFdBQVcsYUFBYTtBQUFBLE1BQ2xDLE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDMUIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxNQUFJLFdBQVcsT0FBTyxXQUFXLEVBQUc7QUFXcEMsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELGFBQVcsS0FBSyxXQUFXLFFBQVE7QUFDakMsUUFBSSxFQUFFLGNBQWM7QUFDbEIsWUFBTSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUTtBQUFBLElBQ25ELE9BQU87QUFDTCxZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRO0FBQUEsSUFDbkQ7QUFHQSxVQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsUUFBSSxhQUFhLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDakQsa0JBQVksV0FBVztBQUN2QixrQkFBWSxhQUFhO0FBQ3pCLFlBQU0sa0JBQWtCLFdBQVc7QUFBQSxJQUNyQztBQUNBLFFBQUksZ0JBQWdCLFVBQVUsWUFBWSxFQUFFLFVBQVU7QUFDcEQscUJBQWUsV0FBVztBQUMxQixxQkFBZSxhQUFhO0FBQzVCLFlBQU0scUJBQXFCLGNBQWM7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFLQSxhQUFXLFdBQVcsV0FBVyxhQUFhO0FBQzVDLFFBQUksTUFBTSxZQUFZLFFBQVEsUUFBUSxFQUFHO0FBQ3pDLFVBQU0sa0JBQWtCLFFBQVEsYUFBYSxRQUFRLFFBQVE7QUFBQSxFQUMvRDtBQUNBLE1BQUksV0FBVyxZQUFZLFNBQVMsR0FBRztBQUNyQyxVQUFNLEtBQUssMENBQTBDO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLFNBQVMsV0FBVyxZQUFZO0FBQUEsTUFDaEMsYUFBYSxNQUFNLHFCQUFxQjtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNIO0FBUUEsUUFBTSxlQUFlLE1BQU0sa0JBQWtCO0FBQzdDLE1BQUksaUJBQWlCO0FBQ3JCLFFBQU0sYUFBdUMsQ0FBQztBQUM5QyxhQUFXLEtBQUssV0FBVyxRQUFRO0FBQ2pDLFVBQU0sT0FBTyxhQUFhLEVBQUUsY0FBYyxJQUFJLEVBQUUsUUFBUTtBQUN4RCxVQUFNLE1BQU07QUFBQSxNQUNWLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxJQUNKO0FBQ0EsUUFBSSxRQUFRLEtBQUssUUFBUSxLQUFLO0FBQzVCLHdCQUFrQjtBQUNsQjtBQUFBLElBQ0Y7QUFDQSxlQUFXLEtBQUssQ0FBQztBQUFBLEVBQ25CO0FBQ0EsTUFBSSxpQkFBaUIsR0FBRztBQUN0QixVQUFNLEtBQUssbUNBQW1DO0FBQUEsTUFDNUM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSxXQUFXLFdBQVcsRUFBRztBQUc3QixRQUFNLFdBQVcsb0JBQUksSUFBOEI7QUFDbkQsYUFBVyxLQUFLLFlBQVk7QUFDMUIsVUFBTSxNQUFNLFNBQVMsSUFBSSxFQUFFLGNBQWMsS0FBSyxDQUFDO0FBQy9DLFFBQUksS0FBSyxDQUFDO0FBQ1YsYUFBUyxJQUFJLEVBQUUsZ0JBQWdCLEdBQUc7QUFBQSxFQUNwQztBQUVBLGFBQVcsQ0FBQyxRQUFRLE1BQU0sS0FBSyxVQUFVO0FBQ3ZDLFVBQU0sTUFBTSxNQUFNLGdCQUFnQixRQUFRLFlBQVksS0FBSyxRQUFRO0FBQ25FLFFBQUksUUFBUTtBQUNaLGVBQVcsS0FBSyxRQUFRO0FBQ3RCLFlBQU0sV0FBVyxJQUFJLGFBQWEsRUFBRSxRQUFRO0FBQzVDLFVBQUksVUFBVTtBQUdaLGlCQUFTLGVBQWU7QUFDeEIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGdCQUFnQixFQUFFO0FBQzNCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxjQUFjLEVBQUU7QUFDekIsaUJBQVMsYUFBYSxFQUFFO0FBQ3hCLGlCQUFTLGlCQUFpQixFQUFFO0FBQzVCLGNBQU0sT0FBTyxTQUFTLG1CQUFtQixTQUFTLG1CQUFtQixTQUFTLENBQUM7QUFDL0UsY0FBTSxPQUFPLEVBQUUsbUJBQW1CLENBQUM7QUFDbkMsWUFBSSxTQUFTLENBQUMsUUFBUSxLQUFLLGdCQUFnQixLQUFLLGNBQWM7QUFDNUQsbUJBQVMsbUJBQW1CLEtBQUssSUFBSTtBQUFBLFFBQ3ZDO0FBQUEsTUFDRixPQUFPO0FBQ0wsY0FBTSxVQUEwQixFQUFFLEdBQUcsR0FBRyxnQkFBZ0IsSUFBSSxPQUFPO0FBQ25FLFlBQUksYUFBYSxFQUFFLFFBQVEsSUFBSTtBQUMvQixpQkFBUztBQUFBLE1BQ1g7QUFDQSxVQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsR0FBRztBQUNoRCxZQUFJLG1CQUFtQixLQUFLLEVBQUUsUUFBUTtBQUFBLE1BQ3hDO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLE1BQU07QUFDbkUsUUFBSSxRQUFRLEdBQUc7QUFDYixZQUFNLEtBQUssbUJBQW1CO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsT0FBTyxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUU7QUFBQSxNQUN2QyxDQUFDO0FBR0QsWUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8saUJBQWlCO0FBQ3hCLGNBQU0scUJBQXFCLE1BQU07QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRSxVQUFVLHVCQUF1QjtBQUNqRSxZQUFNLFlBQVksUUFBUSxXQUFXO0FBQUEsSUFDdkM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxnQkFDYixRQUNBLElBQ0EsV0FDQSxVQUNvQjtBQUNwQixRQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFDckMsTUFBSSxJQUFLLFFBQU87QUFDaEIsUUFBTSxNQUFpQjtBQUFBLElBQ3JCLFFBQVEsU0FBUztBQUFBLElBQ2pCLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLGlCQUFpQjtBQUFBLElBQ2pCLGNBQWMsQ0FBQztBQUFBLElBQ2Ysb0JBQW9CLENBQUM7QUFBQSxJQUNyQixnQkFBZ0IsQ0FBQyxRQUFRO0FBQUEsSUFDekIsWUFBWTtBQUFBLEVBQ2Q7QUFDQSxRQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFFBQU0sS0FBSyxlQUFlLEVBQUUsUUFBUSxLQUFLLFdBQVcsSUFBSSxNQUFNLEVBQUUsQ0FBQztBQUNqRSxTQUFPO0FBQ1Q7QUFJQSxJQUFJLGFBQTRCLFFBQVEsUUFBUTtBQWNoRCxlQUFlLG1CQUFrQztBQUMvQyxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsUUFBTSxVQUFvQixDQUFDO0FBQzNCLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFVBQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxlQUFlO0FBQzNDLFFBQUksT0FBTyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsZUFBZTtBQUN4RCxjQUFRLEtBQUssTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sYUFBYSxTQUFTLE1BQU07QUFDcEM7QUFFQSxlQUFlLDhCQUE2QztBQU8xRCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLEtBQU07QUFDeEQsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLFFBQU0sVUFBb0IsQ0FBQztBQUMzQixhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUMvQyxVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksZUFBZTtBQUMzQyxRQUFJLE9BQU8sU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLGVBQWU7QUFDeEQsY0FBUSxLQUFLLE1BQU07QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsU0FBUyxNQUFNO0FBQ3BDO0FBRUEsZUFBZSxTQUFTLFFBQStCO0FBQ3JELFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxhQUFhLE9BQU8sS0FBSyxHQUFHLEdBQUcsTUFBTTtBQUM3QztBQUVBLGVBQWUsWUFBWSxRQUFnQixRQUErQjtBQUN4RSxRQUFNLGFBQWEsQ0FBQyxNQUFNLEdBQUcsTUFBTTtBQUNyQztBQUVBLGVBQWUsYUFBYSxTQUFtQixRQUErQjtBQUM1RSxRQUFNLFNBQVMsQ0FBQyxHQUFHLElBQUksSUFBSSxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQztBQUMvRCxNQUFJLE9BQU8sV0FBVyxFQUFHO0FBQ3pCLFFBQU0sTUFBTSxXQUFXLEtBQUssTUFBTSxtQkFBbUIsUUFBUSxNQUFNLENBQUM7QUFDcEUsZUFBYSxJQUFJLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUMvQixTQUFPO0FBQ1Q7QUFFQSxlQUFlLG1CQUFtQixTQUFtQixRQUErQjtBQUNsRixRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sUUFBcUIsQ0FBQztBQUM1QixhQUFXLFVBQVUsU0FBUztBQUM1QixVQUFNLE1BQU0sSUFBSSxNQUFNO0FBQ3RCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsVUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJLFlBQVk7QUFDN0MsUUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QixZQUFNLGVBQWUsTUFBTTtBQUMzQixZQUFNLGlCQUFpQixRQUFRLENBQUM7QUFDaEM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLGVBQWUsUUFBUSxLQUFLLE1BQU0sQ0FBQztBQUFBLEVBQ2hEO0FBQ0EsTUFBSSxNQUFNLFdBQVcsRUFBRztBQUV4QixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLE1BQU07QUFDdEQsVUFBTSxLQUFLLHVDQUF1QztBQUFBLE1BQ2hELE9BQU8sTUFBTTtBQUFBLE1BQ2IsU0FBUyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsSUFDdkQsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxRQUFNLFFBQVEsTUFBTSxRQUFRLENBQUMsU0FBUztBQUFBLElBQ3BDO0FBQUEsTUFDRSxNQUFNLEtBQUs7QUFBQSxNQUNYLGVBQWVDLFVBQVMsS0FBSyxVQUFVLEtBQUssU0FBUyxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsSUFDdEU7QUFBQSxJQUNBO0FBQUEsTUFDRSxNQUFNLEtBQUs7QUFBQSxNQUNYLGVBQWVBLFVBQVMsS0FBSyxVQUFVLEtBQUssTUFBTSxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsSUFDbkU7QUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNLFlBQVksd0JBQXdCLEtBQUs7QUFFL0MsTUFBSTtBQUNGLFVBQU0sU0FBUyxNQUFNLE9BQU8sWUFBWTtBQUFBLE1BQ3RDO0FBQUEsTUFDQSxTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQ0QsVUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLGVBQVcsUUFBUSxPQUFPO0FBQ3hCLFlBQU0saUJBQWlCLE1BQU0sK0JBQStCLElBQUk7QUFLaEUsWUFBTSxRQUFRLE1BQU0sWUFBWSxHQUFHLEtBQUssTUFBTTtBQUM5QyxZQUFNLFNBQVEsb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUNsRCxZQUFNLGVBQWUsUUFBUSxLQUFLLGNBQWMsUUFBUSxLQUFLLGFBQWE7QUFDMUUsWUFBTSxZQUFZLEtBQUssUUFBUTtBQUFBLFFBQzdCLFlBQVksZUFBZSxLQUFLLE9BQU87QUFBQSxRQUN2QyxXQUFXO0FBQUEsUUFDWCxlQUFlLEtBQUssSUFBSTtBQUFBLFFBQ3hCLGlCQUFpQixNQUFNLGtCQUFrQixLQUFLLEtBQUssT0FBTztBQUFBLFFBQzFELGVBQWU7QUFBQSxNQUNqQixDQUFDO0FBR0QsWUFBTSxRQUFRLElBQUksS0FBSyxNQUFNLEtBQUssQ0FBQztBQUNuQyxZQUFNLFVBQVMsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDdEMsaUJBQVcsS0FBSyxLQUFLLFFBQVE7QUFDM0IsY0FBTSxFQUFFLFFBQVEsSUFBSTtBQUFBLFVBQ2xCLElBQUk7QUFBQSxVQUNKLEtBQUs7QUFBQSxZQUNILEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLEtBQUssTUFBTSxJQUFJO0FBQ25CLFlBQU0sS0FBSyxtQkFBbUI7QUFBQSxRQUM1QixRQUFRLEtBQUs7QUFBQSxRQUNiO0FBQUEsUUFDQSxRQUFRLEtBQUssT0FBTztBQUFBLFFBQ3BCLEtBQUssS0FBSztBQUFBLFFBQ1YsTUFBTSxLQUFLO0FBQUEsUUFDWCxjQUFjLE9BQU87QUFBQSxNQUN2QixDQUFDO0FBQUEsSUFDSDtBQUNBLFVBQU0sa0JBQWtCLEdBQUc7QUFDM0IsVUFBTSxLQUFLLHlCQUF5QjtBQUFBLE1BQ2xDO0FBQUEsTUFDQSxNQUFNLE1BQU07QUFBQSxNQUNaLE9BQU8sTUFBTTtBQUFBLE1BQ2IsUUFBUSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQUEsTUFDbkUsUUFBUSxPQUFPO0FBQUEsSUFDakIsQ0FBQztBQUNEO0FBQ0UsWUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLFFBQzdCLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixRQUFJLGVBQWUsYUFBYTtBQUM5QixZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sU0FDSixJQUFJLGFBQWEsU0FDYixlQUNBLElBQUksYUFBYSxlQUNmLGlCQUNBLElBQUksYUFBYSxZQUNmLGtCQUNBLEtBQUs7QUFDZixZQUFNLGNBQWM7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTyxJQUFJO0FBQUEsUUFDWCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLFFBQzdCLGtCQUNFLElBQUksYUFBYSxlQUFlLElBQUksbUJBQW1CLEtBQUs7QUFBQSxNQUNoRSxDQUFDO0FBQ0QsWUFBTSxNQUFPLGdCQUFnQjtBQUFBLFFBQzNCO0FBQUEsUUFDQSxTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNyRCxNQUFNLE1BQU07QUFBQSxRQUNaLE9BQU8sTUFBTTtBQUFBLFFBQ2IsVUFBVSxJQUFJO0FBQUEsUUFDZCxRQUFRLElBQUk7QUFBQSxRQUNaLFNBQVMsSUFBSTtBQUFBLFFBQ2Isa0JBQWtCLElBQUk7QUFBQSxNQUN4QixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0wsWUFBTSxNQUFPLGdCQUFnQjtBQUFBLFFBQzNCO0FBQUEsUUFDQSxTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNyRCxNQUFNLE1BQU07QUFBQSxRQUNaLE9BQU8sTUFBTTtBQUFBLFFBQ2IsR0FBRyxjQUFjLEdBQUc7QUFBQSxNQUN0QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBRUYsVUFBRTtBQUNBLFVBQU0sZUFBZTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsUUFBZ0IsS0FBZ0IsUUFBcUM7QUFDM0YsUUFBTSxLQUFLLFdBQVcsSUFBSSxVQUFVO0FBQ3BDLFFBQU0sTUFBTSxJQUFJLFdBQVcsTUFBTSxHQUFHLEVBQUU7QUFDdEMsUUFBTSxXQUFXLFdBQVcsSUFBSSxNQUFNO0FBQ3RDLFFBQU0sVUFBVSxPQUFPLE1BQU0sSUFBSSxFQUFFLElBQUksUUFBUTtBQUMvQyxRQUFNLFdBQVcsUUFBUSxNQUFNLElBQUksRUFBRSxJQUFJLFFBQVE7QUFDakQsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNQLGdCQUFnQjtBQUFBLE1BQ2hCLGdCQUFnQixJQUFJO0FBQUEsTUFDcEIsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYSxJQUFJO0FBQUEsTUFDakIsVUFBVSxJQUFJLGVBQWUsS0FBSyxHQUFHO0FBQUEsTUFDckMsWUFBWSxVQUFVO0FBQUEsTUFDdEIsWUFBWSxJQUFJO0FBQUEsTUFDaEI7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixnQkFBZ0I7QUFBQSxNQUNoQixnQkFBZ0IsSUFBSTtBQUFBLE1BQ3BCLGdCQUFnQjtBQUFBLE1BQ2hCLGFBQWEsSUFBSTtBQUFBLE1BQ2pCLG9CQUFvQixJQUFJO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHdCQUF3QixPQUE0QjtBQUMzRCxNQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLFVBQU0sT0FBTyxNQUFNLENBQUM7QUFDcEIsV0FBTyxZQUFZLEtBQUssTUFBTSxJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssT0FBTyxNQUFNLFNBQVMsS0FBSyxPQUFPLFdBQVcsSUFBSSxLQUFLLEdBQUcsU0FBUyxLQUFLLFFBQVE7QUFBQSxFQUNwSTtBQUNBLFFBQU0sT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFLEtBQUs7QUFDOUQsUUFBTSxXQUFXLEtBQUssV0FBVyxJQUFJLEtBQUssQ0FBQyxJQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsS0FBSyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUM7QUFDcEYsUUFBTSxhQUFhLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssT0FBTyxRQUFRLENBQUM7QUFDOUUsU0FBTyxrQkFBa0IsTUFBTSxNQUFNLFVBQVUsVUFBVSxTQUFTLGVBQWUsSUFBSSxLQUFLLEdBQUcsS0FBSyxRQUFRO0FBQzVHO0FBRUEsZUFBZSwrQkFBK0IsTUFBa0M7QUFDOUUsUUFBTSxVQUFVLE1BQU0sYUFBYSxLQUFLLE1BQU07QUFDOUMsTUFBSSxDQUFDLFFBQVMsUUFBTztBQUNyQixNQUFJLFFBQVEsV0FBVyxLQUFLLElBQUksT0FBUSxRQUFPLE9BQU8sS0FBSyxRQUFRLFlBQVksRUFBRTtBQUVqRixRQUFNLFlBQVksSUFBSTtBQUFBLElBQ3BCLEtBQUssT0FBTyxJQUFJLENBQUMsTUFBTTtBQUFBLE1BQ3JCLEVBQUU7QUFBQSxNQUNGLGNBQWMsRUFBRSxZQUFZLEVBQUUsZUFBZSxFQUFFLGFBQWEsRUFBRSxhQUFhLEVBQUUsWUFBWTtBQUFBLElBQzNGLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxrQkFBa0QsQ0FBQztBQUN6RCxhQUFXLENBQUMsU0FBUyxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ25FLFVBQU0sZUFBZSxVQUFVLElBQUksT0FBTztBQUMxQyxVQUFNLGFBQWE7QUFBQSxNQUNqQixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsSUFDUjtBQUNBLFFBQUksQ0FBQyxnQkFBZ0IsaUJBQWlCLFlBQVk7QUFDaEQsc0JBQWdCLE9BQU8sSUFBSSxFQUFFLEdBQUcsTUFBTTtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUVBLFFBQU0saUJBQWlCLE9BQU8sS0FBSyxlQUFlLEVBQUU7QUFDcEQsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLGVBQWUsS0FBSyxNQUFNO0FBQ2hDLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTSxZQUFZLFNBQVM7QUFDM0IsYUFBVyxTQUFTLE9BQU8sT0FBTyxlQUFlLEdBQUc7QUFDbEQsVUFBTSxpQkFBaUI7QUFBQSxFQUN6QjtBQUNBLFFBQU0sYUFBYSxLQUFLLFFBQVE7QUFBQSxJQUM5QixHQUFHO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDUixZQUFZLFFBQVE7QUFBQSxJQUNwQixjQUFjO0FBQUEsSUFDZCxvQkFBb0IsUUFBUSxtQkFBbUIsT0FBTyxDQUFDLE9BQU8sTUFBTSxlQUFlO0FBQUEsRUFDckYsQ0FBQztBQUNELFFBQU0sS0FBSyxvQ0FBb0M7QUFBQSxJQUM3QyxRQUFRLEtBQUs7QUFBQSxJQUNiLGVBQWUsS0FBSztBQUFBLElBQ3BCLFVBQVUsV0FBVyxTQUFTO0FBQUEsSUFDOUIsV0FBVztBQUFBLEVBQ2IsQ0FBQztBQUNELFNBQU87QUFDVDtBQUlBLGVBQWUsV0FBVyxRQUErQjtBQU12RCxRQUFNLFlBQVksaUJBQWlCLE1BQU07QUFDekMsUUFBTSxLQUFLLHlCQUF5QixFQUFFLFFBQVEsS0FBSyxlQUFlLENBQUM7QUFDbkUsTUFBSSxDQUFFLE1BQU0sYUFBYSxNQUFNLEdBQUk7QUFDakMsVUFBTSxPQUFNLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ25DLFVBQU0sYUFBYSxRQUFRO0FBQUEsTUFDekIsUUFBUSxTQUFTO0FBQUEsTUFDakIsZ0JBQWdCO0FBQUEsTUFDaEIsWUFBWTtBQUFBLE1BQ1osaUJBQWlCO0FBQUEsTUFDakIsY0FBYyxDQUFDO0FBQUEsTUFDZixvQkFBb0IsQ0FBQztBQUFBLE1BQ3JCLGdCQUFnQixDQUFDO0FBQUEsTUFDakIsWUFBWTtBQUFBLElBQ2QsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxXQUFXLFFBQVEsS0FBSyxDQUFDO0FBQzVEO0FBRUEsZUFBZSxhQUE0QjtBQUN6QyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxPQUFPLFNBQVMsT0FBTyxDQUFDO0FBQzlELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sV0FBVyxFQUFFLE1BQU07QUFBQSxFQUMzQjtBQUNGO0FBV0EsZUFBZSxrQkFBaUM7QUFDOUMsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxRQUFRLE1BQU0sZUFBZSxLQUFLLENBQUM7QUFBQSxFQUN2RSxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaURBQWlELGNBQWMsR0FBRyxDQUFDO0FBQzlFO0FBQUEsRUFDRjtBQUNBLFFBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsTUFBSSxDQUFDLE9BQU8sT0FBTyxJQUFJLE9BQU8sWUFBWSxDQUFDLElBQUksS0FBSztBQUNsRCxVQUFNLEtBQUssa0NBQWtDO0FBQzdDO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxnQ0FBZ0MsS0FBSyxJQUFJLEdBQUcsR0FBRztBQUNsRCxVQUFNLEtBQUssK0RBQStEO0FBQUEsTUFDeEUsS0FBSyxXQUFXLElBQUksR0FBRztBQUFBLElBQ3pCLENBQUM7QUFDRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssK0JBQStCLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFHdEUsTUFBSTtBQUNGLFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPLENBQUMsY0FBYztBQUFBLE1BQ3RCLE9BQU87QUFBQSxJQUNULENBQUM7QUFDRCxVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTyxDQUFDLFlBQVk7QUFBQSxJQUN0QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssdUNBQXVDLGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDdEU7QUFHQSxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU87QUFBQSxNQUNQLE1BQU0sTUFBTTtBQUNWLGNBQU0sSUFBSSxPQUFPO0FBQ2pCLGVBQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDO0FBQ3BELG1CQUFXLE1BQU0sT0FBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUMsR0FBRyxHQUFHO0FBQzNFLG1CQUFXLE1BQU0sT0FBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUMsR0FBRyxJQUFJO0FBQUEsTUFDOUU7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSywwQ0FBMEMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUN6RTtBQUNGO0FBYUEsSUFBTSxrQkFBa0I7QUFFeEIsZUFBZSxrQkFBMEM7QUFDdkQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxlQUFlO0FBQzlELFFBQU0sS0FBSyxPQUFPLGVBQWU7QUFDakMsU0FBTyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQ3ZDO0FBRUEsZUFBZSxnQkFBZ0IsSUFBa0M7QUFDL0QsTUFBSSxPQUFPLE1BQU07QUFDZixVQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU8sZUFBZTtBQUFBLEVBQ3BELE9BQU87QUFDTCxVQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGVBQWUsR0FBRyxHQUFHLENBQUM7QUFBQSxFQUMzRDtBQUNGO0FBRUEsZUFBZSxtQkFBa0M7QUFDL0MsUUFBTSxRQUFRLE1BQU0sa0JBQWtCO0FBQ3RDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLHlCQUF5QjtBQUNwQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0sa0JBQWtCO0FBQUEsSUFDdEIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCx1QkFBcUIsT0FBTztBQUM1QixPQUFLLFlBQVk7QUFDakIsUUFBTSxLQUFLLHdCQUF3QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMzRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLHdCQUErRDtBQUVuRSxTQUFTLHFCQUFxQixTQUF1QjtBQUNuRCxNQUFJLDBCQUEwQixLQUFNLGVBQWMscUJBQXFCO0FBQ3ZFLDBCQUF3QixZQUFZLE1BQU07QUFDeEMsU0FBSyxZQUFZLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDaEMsV0FBSyxLQUFLLHVCQUF1QixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3JELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyxzQkFBNEI7QUFDbkMsTUFBSSwwQkFBMEIsTUFBTTtBQUNsQyxrQkFBYyxxQkFBcUI7QUFDbkMsNEJBQXdCO0FBQUEsRUFDMUI7QUFDRjtBQUVBLGVBQWUsb0JBQW1DO0FBQ2hELHNCQUFvQjtBQUNwQixRQUFNLFFBQVEsT0FBTyxNQUFNLGNBQWM7QUFDekMsUUFBTSxRQUFRLE1BQU0sZ0JBQWdCO0FBQ3BDLFFBQU0sZ0JBQWdCLElBQUk7QUFDMUIsUUFBTSxPQUFPLE1BQU0sa0JBQWtCO0FBQ3JDLFFBQU0sa0JBQWtCLElBQUk7QUFDNUIsUUFBTSxLQUFLLDBCQUEwQjtBQUFBLElBQ25DLFNBQVMsVUFBVTtBQUFBLElBQ25CLFdBQVcsTUFBTSxhQUFhO0FBQUEsRUFDaEMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsY0FBNkI7QUFDMUMsTUFBSSxPQUFPLE1BQU0sa0JBQWtCO0FBQ25DLE1BQUksU0FBUyxNQUFNO0FBRWpCLHdCQUFvQjtBQUNwQjtBQUFBLEVBQ0Y7QUFJQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGdCQUFnQjtBQUM1QjtBQUFBLElBQ0Y7QUFFQSxVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsVUFBVSxLQUFLLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsSUFDYixDQUFDO0FBRUQsVUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLGVBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFVBQUksSUFBSSxTQUFTLEtBQUssU0FBUyxPQUFPLEdBQUc7QUFDdkMsY0FBTSxlQUFlLFFBQVEsS0FBSyxTQUFTLE9BQU87QUFDbEQ7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBRUEsUUFBTSxTQUFTLE1BQU0sa0JBQWtCO0FBQ3ZDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsd0JBQW9CO0FBQ3BCLFVBQU0sZ0JBQWdCLElBQUk7QUFDMUIsVUFBTSxrQkFBa0IsSUFBSTtBQUM1QixVQUFNLEtBQUsseUJBQXlCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNqRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTSxNQUFNLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDbkUsTUFBSSxRQUFRLE1BQU0sZ0JBQWdCO0FBQ2xDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxnQkFBZ0IsSUFBSSxFQUFFO0FBQUEsSUFDOUQsT0FBTztBQUNMLFlBQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQztBQUFBLElBQzFDO0FBQ0EsV0FBUSxNQUFNLGtCQUFrQixLQUFNO0FBQ3RDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxrQkFBa0IsSUFBSTtBQUM1QixVQUFNLEtBQUssZ0JBQWdCO0FBQUEsTUFDekIsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixXQUFXLE1BQU0sa0JBQWtCO0FBQUEsTUFDbkMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssNENBQTRDO0FBQUEsTUFDckQsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNLGVBQWUsT0FBTyxRQUFRLE9BQU8sT0FBTztBQUNsRCxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0sa0JBQWtCLElBQUk7QUFBQSxFQUM5QjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQVdBLElBQU0sc0JBQXNCO0FBRTVCLGVBQWUscUJBQTZDO0FBQzFELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksbUJBQW1CO0FBQ2xFLFFBQU0sS0FBSyxPQUFPLG1CQUFtQjtBQUNyQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLG1CQUFtQixJQUFrQztBQUNsRSxNQUFJLE9BQU8sS0FBTSxPQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU8sbUJBQW1CO0FBQUEsTUFDbEUsT0FBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxtQkFBbUIsR0FBRyxHQUFHLENBQUM7QUFDcEU7QUFFQSxlQUFlLHNCQUFxQztBQUNsRCxRQUFNLFFBQVEsTUFBTSxxQkFBcUI7QUFDekMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUssNkJBQTZCO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELDBCQUF3QixPQUFPO0FBQy9CLE9BQUssZUFBZTtBQUNwQixRQUFNLEtBQUssNEJBQTRCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQy9FLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksMkJBQWtFO0FBRXRFLFNBQVMsd0JBQXdCLFNBQXVCO0FBQ3RELE1BQUksNkJBQTZCLEtBQU0sZUFBYyx3QkFBd0I7QUFDN0UsNkJBQTJCLFlBQVksTUFBTTtBQUMzQyxTQUFLLGVBQWUsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNuQyxXQUFLLEtBQUssMkJBQTJCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDekQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHlCQUErQjtBQUN0QyxNQUFJLDZCQUE2QixNQUFNO0FBQ3JDLGtCQUFjLHdCQUF3QjtBQUN0QywrQkFBMkI7QUFBQSxFQUM3QjtBQUNGO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQseUJBQXVCO0FBQ3ZCLFFBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sUUFBUSxNQUFNLG1CQUFtQjtBQUN2QyxRQUFNLG1CQUFtQixJQUFJO0FBQzdCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLFVBQVU7QUFBQSxJQUNuQixXQUFXLE1BQU0sYUFBYTtBQUFBLEVBQ2hDLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJLE9BQU8sTUFBTSxxQkFBcUI7QUFDdEMsTUFBSSxTQUFTLE1BQU07QUFDakIsMkJBQXVCO0FBQ3ZCO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUNBLFVBQU0sS0FBSyxvREFBb0Q7QUFBQSxNQUM3RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFDRCxVQUFNLGtCQUFrQixLQUFLLFNBQVMsT0FBTztBQUM3QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUVBLFFBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxNQUFJLENBQUMsUUFBUTtBQUNYLDJCQUF1QjtBQUN2QixVQUFNLG1CQUFtQixJQUFJO0FBQzdCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLDZCQUE2QixFQUFFLFdBQVcsS0FBSyxVQUFVLENBQUM7QUFDckUsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUdBLE1BQUksTUFBTSxZQUFZLE9BQU8sT0FBTyxHQUFHO0FBQ3JDLFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQU1BLE1BQUksT0FBTyxXQUFXLFlBQVk7QUFDaEMsVUFBTSxLQUFLLG1FQUFtRTtBQUFBLE1BQzVFLFVBQVUsT0FBTztBQUFBLElBQ25CLENBQUM7QUFDRCxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE1BQU0saUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUNuRSxNQUFJLFFBQVEsTUFBTSxtQkFBbUI7QUFDckMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLG1CQUFtQixJQUFJLEVBQUU7QUFBQSxJQUNqRSxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxXQUFRLE1BQU0scUJBQXFCLEtBQU07QUFDekMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sS0FBSyxvQkFBb0I7QUFBQSxNQUM3QixVQUFVLE9BQU87QUFBQSxNQUNqQixhQUFhLE9BQU8sV0FBVyxhQUFhLE9BQU8sT0FBTztBQUFBLE1BQzFELFdBQVcsTUFBTSxxQkFBcUI7QUFBQSxNQUN0QyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxVQUFVLE9BQU87QUFBQSxNQUNqQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQUEsRUFDakM7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFJQSxlQUFlLFdBQ2IsUUFDQSxVQUNBLEtBQ0EsS0FDQSxLQUNlO0FBQ2YsUUFBTSxNQUFPLHdCQUF3QixFQUFFLFFBQVEsVUFBVSxLQUFLLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUNyRixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLEtBQU07QUFDeEQsUUFBTSxVQUE2QjtBQUFBLElBQ2pDLGdCQUFnQjtBQUFBLElBQ2hCO0FBQUEsSUFDQTtBQUFBLElBQ0EsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3BDLFlBQVk7QUFBQSxJQUNaLE9BQU8sY0FBYyxHQUFHO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxLQUFLLFdBQVcsUUFBUSxXQUFXO0FBQ3pDLFFBQU0sT0FBTyxNQUFNLEtBQUssS0FBSyxVQUFVLE9BQU8sQ0FBQztBQUMvQyxRQUFNLE9BQU8sbUJBQW1CLEVBQUUsSUFBSSxJQUFJO0FBQzFDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxPQUFPLFFBQVE7QUFBQSxNQUNuQjtBQUFBLE1BQ0EsZUFBZUEsVUFBUyxLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsTUFDL0QsU0FBUyxlQUFlLE1BQU0sSUFBSSxRQUFRO0FBQUEsSUFDNUMsQ0FBQztBQUFBLEVBQ0gsU0FBUyxNQUFNO0FBQ2IsVUFBTSxNQUFPLDRCQUE0QixFQUFFLEdBQUcsY0FBYyxJQUFJLEVBQUUsQ0FBQztBQUFBLEVBQ3JFO0FBQ0Y7QUFFQSxlQUFlLEtBQUssR0FBNEI7QUFDOUMsUUFBTSxNQUFNLElBQUksWUFBWSxFQUFFLE9BQU8sQ0FBQztBQUN0QyxRQUFNLFNBQVMsTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLEdBQUc7QUFDeEQsUUFBTSxNQUFNLE1BQU0sS0FBSyxJQUFJLFdBQVcsTUFBTSxDQUFDLEVBQzFDLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUU7QUFDVixTQUFPLElBQUksTUFBTSxHQUFHLENBQUM7QUFDdkI7QUFJQSxlQUFlLGlCQUFpQixPQUErQjtBQUM3RCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLE1BQU07QUFDdEQsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU87QUFBQSxNQUNQLGVBQWU7QUFBQSxNQUNmLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxNQUFJLENBQUMsT0FBTztBQUlWLFFBQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFlBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUMzQyxVQUFJLFNBQVMsS0FBSyxpQkFBa0I7QUFBQSxJQUN0QztBQUtBLFFBQUksS0FBSyxXQUFXO0FBQ2xCLFlBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTO0FBQ2xELFVBQUksTUFBTSw4QkFBK0I7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sSUFBSSxNQUFNLE9BQU8saUJBQWlCO0FBSXhDLFFBQUksV0FBVztBQUNmLFFBQUksU0FBUyxVQUFVLFNBQVMsV0FBVyxFQUFFLGdCQUFnQjtBQUMzRCxpQkFBVyxNQUFNLE9BQU8sYUFBYSxTQUFTLE1BQU07QUFBQSxJQUN0RDtBQUNBLFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU8sRUFBRTtBQUFBLE1BQ1QsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU87QUFBQSxNQUNQLGVBQWUsRUFBRTtBQUFBLE1BQ2pCLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLEtBQUssdUJBQXVCO0FBQUEsTUFDaEMsT0FBTyxFQUFFO0FBQUEsTUFDVCxNQUFNLEVBQUU7QUFBQSxNQUNSLGdCQUFnQixFQUFFO0FBQUEsTUFDbEIsbUJBQW1CLFNBQVM7QUFBQSxNQUM1QiwwQkFBMEI7QUFBQSxJQUM1QixDQUFDO0FBQ0QsUUFBSSxDQUFDLFVBQVU7QUFDYixZQUFNLEtBQUssOENBQThDO0FBQUEsUUFDdkQsWUFBWSxTQUFTO0FBQUEsUUFDckIsZ0JBQWdCLEVBQUU7QUFBQSxRQUNsQixLQUFLLHdDQUF3QyxFQUFFO0FBQUEsTUFDakQsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sTUFBTSxlQUFlLGNBQWMsSUFBSSxXQUFXO0FBQ3hELFVBQU0sU0FDSixRQUFRLFNBQ0osZUFDQSxRQUFRLGVBQ04saUJBQ0EsUUFBUSxZQUNOLGtCQUNBO0FBQ1YsVUFBTSxVQUNKLGVBQWUsZUFBZSxRQUFRLGVBQWUsSUFBSSxtQkFBbUI7QUFDOUUsVUFBTSxjQUFjO0FBQUEsTUFDbEI7QUFBQSxNQUNBLE9BQU87QUFBQSxNQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPLGNBQWMsR0FBRyxFQUFFO0FBQUEsTUFDMUIsZUFBZTtBQUFBLE1BQ2Ysd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sS0FBSywyQkFBMkI7QUFBQSxNQUNwQyxVQUFVO0FBQUEsTUFDVixrQkFBa0I7QUFBQSxNQUNsQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxvQkFBb0IsT0FBK0I7QUFDaEUsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxLQUFLO0FBQ2pCLFVBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEM7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLE9BQU87QUFJVixVQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFlBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUMzQyxVQUFJLFNBQVMsS0FBSyxpQkFBa0I7QUFBQSxJQUN0QztBQUlBLFVBQU0sZ0JBQWdCLE1BQU0sdUJBQXVCO0FBQ25ELFFBQUksZUFBZTtBQUNqQixZQUFNLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLGFBQWE7QUFDakQsVUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLLE1BQU0sOEJBQStCO0FBQUEsSUFDbkU7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sTUFBTSxPQUFPLGFBQWEsc0JBQXNCO0FBQzdELFFBQUksQ0FBQyxNQUFNO0FBQ1QsVUFBSSxNQUFPLE9BQU0sS0FBSyxpREFBaUQ7QUFDdkUsWUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QyxZQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JEO0FBQUEsSUFDRjtBQUNBLFVBQU0sU0FBUyxrQkFBa0IsSUFBSTtBQUNyQyxRQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFlBQU0sS0FBSyw4Q0FBOEM7QUFDekQsWUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QyxZQUFNLHdCQUF1QixvQkFBSSxLQUFLLEdBQUUsWUFBWSxDQUFDO0FBQ3JEO0FBQUEsSUFDRjtBQUNBLFVBQU0sWUFBWSxNQUFNO0FBQ3hCLFVBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQsUUFBSSxNQUFPLE9BQU0sS0FBSywyQkFBMkIsRUFBRSxPQUFPLE9BQU8sT0FBTyxDQUFDO0FBQUEsRUFDM0UsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlEQUFpRCxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ2hGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBSUEsZUFBZSxpQkFBZ0M7QUFDN0MsUUFBTSxRQUFRLE1BQU0sV0FBVztBQUMvQixVQUFRLFFBQVEsWUFBWSxFQUFFLE1BQU0saUJBQWlCLE1BQU0sQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUM5RTtBQUVBLGVBQWUsYUFBc0M7QUFDbkQsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLFdBQVc7QUFDZixNQUFJO0FBQ0YsVUFBTSxPQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFDM0YsZUFBVyxLQUFLO0FBQUEsRUFDbEIsUUFBUTtBQUFBLEVBR1I7QUFDQSxRQUFNLGdCQUFnQixNQUFNLGtCQUFrQjtBQUM5QyxRQUFNLG1CQUFtQixNQUFNLHFCQUFxQjtBQUNwRCxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsU0FBTztBQUFBLElBQ0wsU0FBUztBQUFBLElBQ1QsVUFBVSxlQUFlLFFBQVE7QUFBQSxJQUNqQyxZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVk7QUFBQSxNQUNWLFFBQVEsbUJBQW1CLFFBQVEsb0JBQW9CO0FBQUEsTUFDdkQ7QUFBQSxNQUNBLGFBQWEsZ0JBQWdCLGVBQWU7QUFBQSxNQUM1QyxlQUFlLGdCQUFnQixpQkFBaUI7QUFBQSxNQUNoRCxlQUFlLGdCQUFnQixpQkFBaUI7QUFBQSxJQUNsRDtBQUFBLElBQ0EsY0FBYztBQUFBLE1BQ1osT0FBTztBQUFBLE1BQ1AsU0FBUywwQkFBMEI7QUFBQSxNQUNuQyxXQUFXLGFBQWEsYUFBYTtBQUFBLE1BQ3JDLGdCQUFnQixhQUFhLGdCQUFnQjtBQUFBLElBQy9DO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxNQUNmLE9BQU87QUFBQSxNQUNQLFNBQVMsNkJBQTZCO0FBQUEsTUFDdEMsV0FBVyxnQkFBZ0IsYUFBYTtBQUFBLE1BQ3hDLGdCQUFnQixnQkFBZ0IsZ0JBQWdCO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBeUM7QUFDL0QsU0FBTztBQUFBLElBQ0wsT0FBTyxFQUFFO0FBQUEsSUFDVCxNQUFNLEVBQUU7QUFBQSxJQUNSLFFBQVEsRUFBRTtBQUFBLElBQ1YsU0FBUyxFQUFFO0FBQUEsSUFDWCxhQUFhLEVBQUU7QUFBQSxJQUNmLGNBQWMsRUFBRTtBQUFBLElBQ2hCLHVCQUF1QixFQUFFO0FBQUEsSUFDekIsUUFBUSxFQUFFLElBQUksU0FBUztBQUFBLElBQ3ZCLFdBQVcsRUFBRSxJQUFJLFVBQVUsSUFBSSxFQUFFLElBQUksTUFBTSxFQUFFLElBQUk7QUFBQSxFQUNuRDtBQUNGO0FBRUEsU0FBUyxXQUFXLEtBQXFCO0FBRXZDLFFBQU0sSUFBSSxJQUFJLEtBQUssR0FBRztBQUN0QixNQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU8sSUFBSSxRQUFRLFNBQVMsRUFBRTtBQUM3RCxRQUFNLE1BQU0sQ0FBQyxHQUFXLElBQUksTUFBTSxPQUFPLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUMzRCxTQUNFLEdBQUcsRUFBRSxlQUFlLENBQUMsSUFBSSxJQUFJLEVBQUUsWUFBWSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUNwRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7QUFFOUU7QUFFQSxTQUFTLFVBQVUsR0FBcUI7QUFDdEMsU0FBTyxXQUFXLEVBQUUsS0FBSyxjQUFjLEVBQUUsSUFBSTtBQUMvQztBQVNBLFNBQVMsZUFBZSxNQUF5QjtBQUMvQyxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1DLE9BQU07QUFDWixVQUFJLE9BQU9BLEtBQUksZUFBZSxTQUFVLE1BQUssSUFBSUEsS0FBSSxVQUFVO0FBQy9ELGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsS0FBSztBQUN4QjtBQU9BLFNBQVMsb0JBQW9CLE1BQWUsVUFBbUM7QUFDN0UsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNQSxPQUFNO0FBQ1osVUFBSUEsS0FBSSxlQUFlLFVBQVU7QUFDL0IsZUFBTyxPQUFPLEtBQUtBLElBQUcsRUFBRSxLQUFLO0FBQUEsTUFDL0I7QUFDQSxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBUUEsU0FBUyxpQkFBaUIsTUFBZSxVQUFrQixNQUF5QjtBQUNsRixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsTUFBSSxRQUF3QztBQUM1QyxTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUEsT0FBTTtBQUNaLFVBQUlBLEtBQUksZUFBZSxVQUFVO0FBQy9CLGdCQUFRQTtBQUNSO0FBQUEsTUFDRjtBQUNBLGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLE1BQUksTUFBZTtBQUNuQixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVSxRQUFPLElBQUksUUFBUSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzFGLFVBQU8sSUFBZ0MsR0FBRztBQUFBLEVBQzVDO0FBQ0EsTUFBSSxRQUFRLE9BQVcsUUFBTztBQUM5QixNQUFJLFFBQVEsS0FBTSxRQUFPO0FBQ3pCLE1BQUksT0FBTyxRQUFRLFNBQVUsUUFBTyxJQUFJLE9BQU8sR0FBRztBQUNsRCxNQUFJLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxjQUFjLElBQUksTUFBTTtBQUN2RCxTQUFPLE9BQU8sS0FBSyxHQUE4QixFQUFFLEtBQUs7QUFDMUQ7QUFFQSxTQUFTLFdBQVcsR0FBbUI7QUFHckMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLElBQUksQ0FBQztBQUN4QixVQUFNLE9BQU8sT0FBTyxZQUFZLE9BQU8sU0FBUyxZQUFPO0FBQ3ZELFdBQU8sT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTLGdCQUM5QyxPQUNBLEdBQUcsT0FBTyxJQUFJLEdBQUcsSUFBSTtBQUFBLEVBQzNCLFFBQVE7QUFDTixXQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFBQSxFQUNoRDtBQUNGO0FBS0MsV0FBdUMsZUFBZTtBQUFBLEVBQ3JEO0FBQUEsRUFDQSxVQUFVO0FBQUEsRUFDVixVQUFVO0FBQUEsRUFDVixTQUFTO0FBQUEsRUFDVCxVQUFVLE1BQU0sU0FBUyxVQUFVO0FBQUEsRUFDbkMsT0FBTztBQUFBLEVBQ1AsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsZUFBZTtBQUFBLEVBQ2YsaUJBQWlCO0FBQUEsRUFDakIsaUJBQWlCO0FBQUEsRUFDakIsa0JBQWtCO0FBQ3BCOyIsCiAgIm5hbWVzIjogWyJ0b0Jhc2U2NCIsICJvYmoiLCAiaW5mbyIsICJ0b0Jhc2U2NCIsICJvYmoiXQp9Cg==
