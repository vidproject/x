// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw, ctx);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, partial_ids };
}
function pickPartial(node, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  return { tweet_id: restId, hint_handle: pickHintHandle(node, restId, ctx) };
}
function pickHintHandle(node, tweetId, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name) ?? pickHandleFromTweetUrls(node, tweetId) ?? pickHandleFromMediaPage(ctx.sourceUrl);
}
function pickHandleFromTweetUrls(node, tweetId) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const handle = handleFromTweetUrl(cur, tweetId);
      if (handle) return handle;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function handleFromTweetUrl(rawUrl, tweetId) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d{15,20})(?:\/|$)/);
    if (!match || match[2] !== tweetId) return null;
    return match[1] ?? null;
  } catch {
    return null;
  }
}
function pickHandleFromMediaPage(rawUrl) {
  if (!rawUrl) return null;
  try {
    const url = new URL(rawUrl);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/media\/?$/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted) {
  if (targeted.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.retweeted_tweet_id && targetedTweetIds.has(t.retweeted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let expandedCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        // Cast: the @types/firefox-webext-browser type signature insists
        // `func` returns void, but the API actually surfaces the return
        // value via `result[0].result`. We use that for the expand count.
        func: () => {
          const SHOW_MORE_SELECTORS = [
            '[data-testid="tweet-text-show-more-link"]',
            'button[data-testid="tweet-text-show-more-link"]',
            'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
          ];
          const clicked = /* @__PURE__ */ new Set();
          let expanded = 0;
          for (const sel of SHOW_MORE_SELECTORS) {
            for (const el of Array.from(document.querySelectorAll(sel))) {
              if (clicked.has(el)) continue;
              const t = (el.textContent || "").trim().toLowerCase();
              if (t !== "show more" && t !== "show this thread") continue;
              const rect = el.getBoundingClientRect();
              if (rect.width === 0 || rect.height === 0) continue;
              clicked.add(el);
              try {
                el.click();
                expanded += 1;
              } catch {
              }
            }
          }
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { expanded };
        }
      });
      scrollCount += 1;
      const r = results[0]?.result;
      if (r && typeof r.expanded === "number") expandedCount += r.expanded;
    } catch {
    }
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      sess.expandedCount += expandedCount;
      await setAutoScrollSession(sess);
    }
  }
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.pageUrl ?? null, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, pageUrl, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set(),
      sourceUrl: pageUrl
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.tweets.length === 0) return;
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const committedIdx = await getCommittedIndex();
  let dedupedSkipped = 0;
  const liveTweets = [];
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      continue;
    }
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (liveTweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, Object.keys(buf.tweets_by_id).length);
    if (added > 0) {
      await info("captured tweets", {
        handle,
        endpoint,
        added,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    if (tweets.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      idx[item.handle] = inner;
      await info("flush committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("flush batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return Object.keys(current.tweets_by_id).length;
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingCount = Object.keys(remainingTweets).length;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => id in remainingTweets)
  });
  await info("flush kept newer buffered tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  if (target.bucket === "_unknown") {
    await warn("media-crawl target missing handle; skipping broken status route", {
      tweet_id: target.tweetId
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const autoScrollSess = await getAutoScrollSession();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    }
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xyXG4gIHBhdDogJycsXHJcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcclxuICByZXBvOiAneCcsXHJcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxyXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXHJcbiAgYnJhbmNoOiAnbWFzdGVyJyxcclxuICBlbmFibGVkOiB0cnVlLFxyXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxyXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcclxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XHJcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XHJcblxyXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxyXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXHJcbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xyXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuXTtcclxuXHJcbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXHJcbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG4gICdMaWtlcycsXHJcbiAgJ0Jvb2ttYXJrcycsXHJcbiAgJ0hvbWVUaW1lbGluZScsXHJcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXHJcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcclxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcclxuXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XHJcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXHJcbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXHJcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxyXG5dKTtcclxuXHJcbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxyXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxyXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3JcclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxyXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcclxuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXHJcbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXHJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcclxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxyXG4vL1xyXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcclxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXHJcbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cclxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG5dKTtcclxuXHJcbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxyXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xyXG5cclxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcclxuXHJcbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XHJcblxyXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXHJcbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcclxuXHJcbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cclxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XHJcblxyXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcclxuIiwgIi8qKlxyXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cclxuICpcclxuICogVGhyZWF0IG1vZGVsOiBhbiBhdHRhY2tlciB3aG8gcmVhZHMgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgKGRldnRvb2xzLCBhXHJcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXHJcbiAqIEdpdEh1YiBQQVQgaW4gcGxhaW50ZXh0LiBBIGRldGVybWluZWQgYXR0YWNrZXIgd2l0aCB0aGUgZXh0ZW5zaW9uJ3Mgc291cmNlXHJcbiAqIGNhbiBzdGlsbCBkZXJpdmUgdGhlIGtleSBcdTIwMTQgd2UgbWFrZSBubyBjbGFpbSBvZiBcInJlYWxcIiBjcnlwdG9ncmFwaGljXHJcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxyXG4gKiBzdHJpbmcgc2l0dGluZyBuZXh0IHRvIGl0cyBrZXkgbmFtZSBpbiBleHRlbnNpb24gc3RvcmFnZS5cclxuICpcclxuICogU2NoZW1lOlxyXG4gKiAgIC0gT24gZmlyc3QgZW5jcnlwdGlvbiB3ZSBnZW5lcmF0ZSBhIDMyLWJ5dGUgc2FsdCBhbmQgcGVyc2lzdCBpdCBpblxyXG4gKiAgICAgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgdW5kZXIgYF9faW1tX2FyY2hpdmVfc2FsdF9fYC5cclxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cclxuICogICAgIHx8IFwiaW1tLWFyY2hpdmUtcGF0LXYxXCJgLiBUaGUgc2FsdCBiZWluZyBwZXItaW5zdGFsbCBtZWFucyB0d28gY29waWVzXHJcbiAqICAgICBvZiB0aGUgZXh0ZW5zaW9uIGRvbid0IHNoYXJlIGEga2V5LiBUaGUgcnVudGltZS5pZCBpcyB0aGUgZXh0ZW5zaW9uJ3NcclxuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxyXG4gKiAgIC0gUGxhaW50ZXh0IGlzIGVuY3J5cHRlZCB3aXRoIGEgZnJlc2ggMTItYnl0ZSBJVi4gVGhlIGVudmVsb3BlIGZvcm1hdCBpc1xyXG4gKiAgICAgYHYxOjxpdi1iNjQ+OjxjaXBoZXJ0ZXh0LWI2ND5gIGFuZCBpcyB3aGF0IGdldHMgc3RvcmVkLlxyXG4gKlxyXG4gKiBCYWNrd2FyZHMgY29tcGF0aWJpbGl0eTogYW4gdW5wcmVmaXhlZCB2YWx1ZSBpcyB0cmVhdGVkIGFzIGxlZ2FjeVxyXG4gKiBwbGFpbnRleHQsIGRlY3J5cHRlZCB0byBpdHNlbGYsIGFuZCByZS1lbmNyeXB0ZWQgb24gdGhlIG5leHQgd3JpdGUuXHJcbiAqL1xyXG5cclxuY29uc3QgU0FMVF9TVE9SQUdFX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3NhbHRfXyc7XHJcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xyXG5cclxubGV0IGRlcml2ZWRLZXlDYWNoZTogQ3J5cHRvS2V5IHwgbnVsbCA9IG51bGw7XHJcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHRvQmFzZTY0KGJ1ZjogVWludDhBcnJheSk6IHN0cmluZyB7XHJcbiAgbGV0IHMgPSAnJztcclxuICBmb3IgKGNvbnN0IGIgb2YgYnVmKSBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYik7XHJcbiAgcmV0dXJuIGJ0b2Eocyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZyb21CYXNlNjQoczogc3RyaW5nKTogVWludDhBcnJheSB7XHJcbiAgY29uc3QgYmluID0gYXRvYihzKTtcclxuICBjb25zdCBvdXQgPSBuZXcgVWludDhBcnJheShiaW4ubGVuZ3RoKTtcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IGJpbi5sZW5ndGg7IGkrKykgb3V0W2ldID0gYmluLmNoYXJDb2RlQXQoaSk7XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcclxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFNBTFRfU1RPUkFHRV9LRVkpO1xyXG4gIGNvbnN0IHYgPSBzdG9yZWRbU0FMVF9TVE9SQUdFX0tFWV07XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcclxuICAgIHJldHVybiB7IHNhbHRCNjQ6IHYsIHNhbHQ6IGZyb21CYXNlNjQodikgfTtcclxuICB9XHJcbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcclxuICBjb25zdCBzYWx0QjY0ID0gdG9CYXNlNjQoc2FsdCk7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtTQUxUX1NUT1JBR0VfS0VZXTogc2FsdEI2NCB9KTtcclxuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xyXG4gIGNvbnN0IHsgc2FsdEI2NCwgc2FsdCB9ID0gYXdhaXQgbG9hZE9yQ3JlYXRlU2FsdCgpO1xyXG4gIGlmIChkZXJpdmVkS2V5Q2FjaGUgIT09IG51bGwgJiYgZGVyaXZlZEtleUNhY2hlU2FsdCA9PT0gc2FsdEI2NCkge1xyXG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcclxuICB9XHJcbiAgY29uc3Qgc2VlZCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcclxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXHJcbiAgKTtcclxuICBjb25zdCBjb21iaW5lZCA9IG5ldyBVaW50OEFycmF5KHNlZWQubGVuZ3RoICsgc2FsdC5sZW5ndGgpO1xyXG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcclxuICBjb21iaW5lZC5zZXQoc2FsdCwgc2VlZC5sZW5ndGgpO1xyXG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGNvbWJpbmVkKTtcclxuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcclxuICAgICdlbmNyeXB0JyxcclxuICAgICdkZWNyeXB0JyxcclxuICBdKTtcclxuICBkZXJpdmVkS2V5Q2FjaGUgPSBrZXk7XHJcbiAgZGVyaXZlZEtleUNhY2hlU2FsdCA9IHNhbHRCNjQ7XHJcbiAgcmV0dXJuIGtleTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gIHJldHVybiB2LnN0YXJ0c1dpdGgoRU5WRUxPUEVfUFJFRklYKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVuY3J5cHRQYXQocGxhaW50ZXh0OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIGlmICghcGxhaW50ZXh0KSByZXR1cm4gJyc7XHJcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XHJcbiAgY29uc3QgaXYgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEyKSk7XHJcbiAgY29uc3QgY3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmVuY3J5cHQoXHJcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcclxuICAgIGtleSxcclxuICAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShwbGFpbnRleHQpXHJcbiAgKTtcclxuICByZXR1cm4gYCR7RU5WRUxPUEVfUFJFRklYfSR7dG9CYXNlNjQoaXYpfToke3RvQmFzZTY0KG5ldyBVaW50OEFycmF5KGN0KSl9YDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlY3J5cHRQYXQoZW52ZWxvcGU6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgaWYgKCFlbnZlbG9wZSkgcmV0dXJuICcnO1xyXG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXHJcbiAgLy8gcmUtZW5jcnlwdHMgaXQgdmlhIHRoZSBzdG9yYWdlIGxheWVyLlxyXG4gIGlmICghZW52ZWxvcGUuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpKSByZXR1cm4gZW52ZWxvcGU7XHJcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xyXG4gIGlmIChwYXJ0cy5sZW5ndGggIT09IDIpIHJldHVybiAnJztcclxuICBjb25zdCBbaXZCNjQsIGN0QjY0XSA9IHBhcnRzO1xyXG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGtleSA9IGF3YWl0IGRlcml2ZUtleSgpO1xyXG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcclxuICAgIGNvbnN0IGN0ID0gZnJvbUJhc2U2NChjdEI2NCk7XHJcbiAgICBjb25zdCBwdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGVjcnlwdChcclxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcclxuICAgICAga2V5LFxyXG4gICAgICBjdCBhcyBCdWZmZXJTb3VyY2VcclxuICAgICk7XHJcbiAgICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKHB0KTtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiAnJztcclxuICB9XHJcbn1cclxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcclxuaW1wb3J0IHsgZGVjcnlwdFBhdCwgZW5jcnlwdFBhdCwgaXNFbmNyeXB0ZWRQYXQgfSBmcm9tICcuL2NyeXB0by5qcyc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBBY2NvdW50Q29uZmlnLFxyXG4gIEFjY291bnRDb3VudGVyLFxyXG4gIENhbm9uaWNhbFR3ZWV0LFxyXG4gIENvbm5lY3Rpb25TdGF0ZSxcclxuICBMb2dFdmVudCxcclxuICBTZXR0aW5ncyxcclxufSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbi8qKlxyXG4gKiBCdWZmZXJlZCB0d2VldHMgZm9yIGEgZ2l2ZW4gYWNjb3VudCwgYXdhaXRpbmcgY29tbWl0LiBBIFwicnVuXCIgaXMgb25lIGVudHJ5XHJcbiAqIGluIHRoaXMgbWFwOyBmbHVzaGluZyBjbGVhcnMgdGhlIGVudHJ5LiBXZSBzdG9yZSBhcyBSZWNvcmQgc28gdGhlIHN0cnVjdHVyZVxyXG4gKiBzdXJ2aXZlcyBKU09OIHNlcmlhbGl6YXRpb24gdGhyb3VnaCBicm93c2VyLnN0b3JhZ2UuXHJcbiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIFJ1bkJ1ZmZlciB7XHJcbiAgcnVuX2lkOiBzdHJpbmc7XHJcbiAgYWNjb3VudF9oYW5kbGU6IHN0cmluZztcclxuICBzdGFydGVkX2F0OiBzdHJpbmc7XHJcbiAgbGFzdF9jYXB0dXJlX2F0OiBzdHJpbmc7XHJcbiAgdHdlZXRzX2J5X2lkOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD47XHJcbiAgdHdlZXRfaWRzX29ic2VydmVkOiBzdHJpbmdbXTtcclxuICBlbmRwb2ludHNfc2Vlbjogc3RyaW5nW107XHJcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcclxufVxyXG5cclxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxyXG4gKiBVc2VkIHRvIHNraXAgcmUtY2FwdHVyaW5nIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IHB1c2hlZCB3aXRoIGlkZW50aWNhbFxyXG4gKiBlbmdhZ2VtZW50IGNvdW50cyBcdTIwMTQgYXZvaWRzIGdlbmVyYXRpbmcgb25lIG5ldyByYXcvKiBmaWxlIGV2ZXJ5IGJyb3dzZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XHJcbiAgdHM6IHN0cmluZzsgLy8gSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBjb21taXRcclxuICBzaWc6IHN0cmluZzsgLy8gZW5nYWdlbWVudCBzaWduYXR1cmU6IFwibGlrZXxydHxyZXBseXxxdW90ZVwiXHJcbn1cclxuXHJcbi8qKiBQcm9ncmVzcyArIGluZmxpZ2h0IHRyYWNraW5nIGZvciBhIHF1ZXVlLWRyaXZlbiBsb29wIChyZWZldGNoIC8gbWVkaWEtY3Jhd2wpLlxyXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcclxuICogXCJYIG9mIFkgcHJvY2Vzc2VkXCIgXHUyMDE0IGFuZCB0aGUgd2FpdC1mb3ItaW5nZXN0IGd1YXJkIGtub3dzIHdoYXQgdG8gZXhwZWN0LlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XHJcbiAgLyoqIEluaXRpYWwgcXVldWUgc2l6ZSB3aGVuIHRoZSB1c2VyIGNsaWNrZWQgXCJTdGFydFwiLiAqL1xyXG4gIHRvdGFsQXRTdGFydDogbnVtYmVyO1xyXG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cclxuICBwcm9jZXNzZWQ6IG51bWJlcjtcclxuICAvKiogSVNPIG9mIHdoZW4gdGhpcyBzZXNzaW9uIHN0YXJ0ZWQuICovXHJcbiAgc3RhcnRlZEF0OiBzdHJpbmc7XHJcbiAgLyoqIFR3ZWV0IGN1cnJlbnRseSBpbmZsaWdodCBcdTIwMTQgd2UgbmF2aWdhdGVkIHRvIGl0IGFuZCBhcmUgd2FpdGluZyBmb3IgdGhlXHJcbiAgICogcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIHJlc3BvbnNlIGJlZm9yZSBhZHZhbmNpbmcuIG51bGwgYmV0d2VlbiB0aWNrc1xyXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xyXG4gIGluZmxpZ2h0OiB7IHR3ZWV0SWQ6IHN0cmluZzsgbmF2aWdhdGVkQXQ6IHN0cmluZyB9IHwgbnVsbDtcclxufVxyXG5cclxuLyoqIEF1dG8tc2Nyb2xsIHNlc3Npb246IGNvdW50cyBvZiB0aWNrcyBhbmQgdHdlZXRzIGluZ2VzdGVkIHNpbmNlIHRoZSB1c2VyXHJcbiAqIGNsaWNrZWQgU3RhcnQuIFBlcnNpc3RlZCBzbyBTVyBldmljdGlvbiBkdXJpbmcgYSBydW4ga2VlcHMgcHJvZ3Jlc3MuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xyXG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xyXG4gIHNjcm9sbENvdW50OiBudW1iZXI7XHJcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xyXG4gIGV4cGFuZGVkQ291bnQ6IG51bWJlcjtcclxufVxyXG5cclxuaW50ZXJmYWNlIFN0b3JhZ2VTaGFwZSB7XHJcbiAgc2V0dGluZ3M6IFNldHRpbmdzO1xyXG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XHJcbiAgLyoqIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3Qgc3VjY2Vzc2Z1bCBhY2NvdW50cy55YW1sIGZldGNoIGZyb20gdGhlIHJlcG8uXHJcbiAgICogVXNlZCBieSBgcmVmcmVzaEFjY291bnRzTGlzdGAgdG8gc2tpcCByZS1mZXRjaGluZyBvbiBldmVyeSBTVyB3YWtlIFx1MjAxNCB0aGVcclxuICAgKiBmaWxlIGNoYW5nZXMgcmFyZWx5IGFuZCBhbiBhdXRoZW50aWNhdGVkIHJhdyBmZXRjaCBldmVyeSB3YWtlIGFkZHMgdXAuICovXHJcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogc3RyaW5nIHwgbnVsbDtcclxuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uU3RhdGU7XHJcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcclxuICBydW5CdWZmZXJzOiBSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+O1xyXG4gIGFjdGl2aXR5OiBMb2dFdmVudFtdO1xyXG4gIGNvbW1pdHRlZEluZGV4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+O1xyXG4gIC8qKiBUd2VldHMgdGhlIG5vcm1hbGl6ZXIgZmxhZ2dlZCBhcyB0cnVuY2F0ZWQgYW5kIHRoYXQgd2UgaGF2ZW4ndCBzZWVuIGFcclxuICAgKiBmdWxsLXRleHQgdmVyc2lvbiBvZiB5ZXQuIEtleWVkIGJ5IGhhbmRsZSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiAqL1xyXG4gIHJlZmV0Y2hRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xyXG4gIC8qKiBUd2VldCBJRHMgc2VlbiB2aWEgTWVkaWEtdGFiIC8gcGFydGlhbCBjYXB0dXJlcyB0aGF0IGNvdWxkbid0IGJlXHJcbiAgICogbm9ybWFsaXplZCBpbnRvIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIEtleWVkIGJ5IGhpbnQtaGFuZGxlIChvclxyXG4gICAqIFwiX3Vua25vd25cIikgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gVGhlIHVzZXIgY2FuIGRyaXZlIGEgY3Jhd2wgdGhhdFxyXG4gICAqIG9wZW5zIGVhY2ggZGV0YWlsIHBhZ2UgdG8gY2FwdHVyZSB0aGUgcmVhbCB0aGluZy4gKi9cclxuICBtZWRpYUNyYXdsUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcclxuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xyXG4gIG1lZGlhQ3Jhd2xTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XHJcbiAgYXV0b1Njcm9sbFNlc3Npb246IEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbDtcclxufVxyXG5cclxuY29uc3QgREVGQVVMVF9DT05ORUNUSU9OOiBDb25uZWN0aW9uU3RhdGUgPSB7XHJcbiAgc3RhdHVzOiAndW5rbm93bicsXHJcbiAgbG9naW46IG51bGwsXHJcbiAgY2hlY2tlZEF0OiBudWxsLFxyXG4gIGVycm9yOiBudWxsLFxyXG4gIGRlZmF1bHRCcmFuY2g6IG51bGwsXHJcbiAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcclxuICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxyXG59O1xyXG5cclxuY29uc3QgREVGQVVMVFM6IFN0b3JhZ2VTaGFwZSA9IHtcclxuICBzZXR0aW5nczogeyAuLi5ERUZBVUxUX1NFVFRJTkdTIH0sXHJcbiAgYWNjb3VudHM6IFsuLi5GQUxMQkFDS19BQ0NPVU5UU10sXHJcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogbnVsbCxcclxuICBjb25uZWN0aW9uOiB7IC4uLkRFRkFVTFRfQ09OTkVDVElPTiB9LFxyXG4gIGNvdW50ZXJzOiB7fSxcclxuICBydW5CdWZmZXJzOiB7fSxcclxuICBhY3Rpdml0eTogW10sXHJcbiAgY29tbWl0dGVkSW5kZXg6IHt9LFxyXG4gIHJlZmV0Y2hRdWV1ZToge30sXHJcbiAgbWVkaWFDcmF3bFF1ZXVlOiB7fSxcclxuICByZWZldGNoU2Vzc2lvbjogbnVsbCxcclxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcclxuICBhdXRvU2Nyb2xsU2Vzc2lvbjogbnVsbCxcclxufTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEspOiBQcm9taXNlPFN0b3JhZ2VTaGFwZVtLXT4ge1xyXG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoa2V5KTtcclxuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xyXG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICByZXR1cm4gc3RydWN0dXJlZENsb25lKERFRkFVTFRTW2tleV0pO1xyXG4gIH1cclxuICByZXR1cm4gdmFsdWUgYXMgU3RvcmFnZVNoYXBlW0tdO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLLCB2YWx1ZTogU3RvcmFnZVNoYXBlW0tdKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtrZXldOiB2YWx1ZSB9KTtcclxufVxyXG5cclxuLy8gLS0tIFNldHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XHJcbiAgLy8gQmFja2ZpbGwgYW55IGtleXMgdGhlIHVzZXIncyBzdG9yZWQgc2V0dGluZ3MgcHJlZGF0ZSBcdTIwMTQgcmVhZGVycyBjYW4gcmVseVxyXG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XHJcbiAgLy8gZXZlcnkgY2FsbHNpdGUuIFRoZSBQQVQgaXMgc3RvcmVkIGVuY3J5cHRlZC1hdC1yZXN0IGFzIG9mIHYwLjIuMDsgd2VcclxuICAvLyBkZWNyeXB0IHRyYW5zcGFyZW50bHkgc28gY2FsbGVycyBjb250aW51ZSB0byBzZWUgcGxhaW50ZXh0LlxyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcclxuICBjb25zdCBtZXJnZWQgPSB7IC4uLkRFRkFVTFRfU0VUVElOR1MsIC4uLnN0b3JlZCB9O1xyXG4gIGlmIChtZXJnZWQucGF0ICYmIGlzRW5jcnlwdGVkUGF0KG1lcmdlZC5wYXQpKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBtZXJnZWQucGF0ID0gYXdhaXQgZGVjcnlwdFBhdChtZXJnZWQucGF0KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBtZXJnZWQucGF0ID0gJyc7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBtZXJnZWQ7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXHJcbiAgLy8gb24gdGhlIG5leHQgc2F2ZS5cclxuICBjb25zdCB0b1dyaXRlOiBTZXR0aW5ncyA9IHsgLi4ucyB9O1xyXG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XHJcbiAgICB0b1dyaXRlLnBhdCA9IGF3YWl0IGVuY3J5cHRQYXQodG9Xcml0ZS5wYXQpO1xyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHBhdGNoOiBQYXJ0aWFsPFNldHRpbmdzPik6IFByb21pc2U8U2V0dGluZ3M+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IG5leHQgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcclxuICBhd2FpdCBzZXRTZXR0aW5ncyhuZXh0KTtcclxuICByZXR1cm4gbmV4dDtcclxufVxyXG5cclxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50cygpOiBQcm9taXNlPEFjY291bnRDb25maWdbXT4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzKGE6IEFjY291bnRDb25maWdbXSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzUmVmcmVzaGVkQXQoaXNvOiBzdHJpbmcgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcclxufVxyXG5cclxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb24oKTogUHJvbWlzZTxDb25uZWN0aW9uU3RhdGU+IHtcclxuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XHJcbiAgLy8gQmFja2ZpbGwgZmllbGRzIGFkZGVkIGFmdGVyIHRoZSB1c2VyJ3Mgc3RvcmFnZSB3YXMgd3JpdHRlbi5cclxuICBjb25zdCBvdXQ6IENvbm5lY3Rpb25TdGF0ZSA9IHtcclxuICAgIC4uLmMsXHJcbiAgICBkZWZhdWx0QnJhbmNoOiBjLmRlZmF1bHRCcmFuY2ggPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmRlZmF1bHRCcmFuY2gsXHJcbiAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOlxyXG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXHJcbiAgICByYXRlTGltaXRSZXNldEF0OiBjLnJhdGVMaW1pdFJlc2V0QXQgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLnJhdGVMaW1pdFJlc2V0QXQsXHJcbiAgfTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb25uZWN0aW9uKGM6IENvbm5lY3Rpb25TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xyXG59XHJcblxyXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZnVuY3Rpb24gdG9kYXlJU08oKTogc3RyaW5nIHtcclxuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnY291bnRlcnMnKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXHJcbiAgaGFuZGxlOiBzdHJpbmcsXHJcbiAgcGF0Y2g6IFBhcnRpYWw8QWNjb3VudENvdW50ZXI+XHJcbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRDb3VudGVycygpO1xyXG4gIGNvbnN0IGN1ciA9IGFsbFtoYW5kbGVdID8/IHtcclxuICAgIHRvZGF5Q291bnQ6IDAsXHJcbiAgICB0b2RheURhdGU6IHRvZGF5SVNPKCksXHJcbiAgICBsYXN0Q2FwdHVyZUF0OiBudWxsLFxyXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXHJcbiAgICBidWZmZXJlZENvdW50OiAwLFxyXG4gIH07XHJcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcclxuICAgIGN1ci50b2RheURhdGUgPSB0b2RheUlTTygpO1xyXG4gICAgY3VyLnRvZGF5Q291bnQgPSAwO1xyXG4gIH1cclxuICBjb25zdCBuZXh0OiBBY2NvdW50Q291bnRlciA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xyXG4gIGFsbFtoYW5kbGVdID0gbmV4dDtcclxuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcclxuICByZXR1cm4gbmV4dDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlOiBzdHJpbmcsIGNvdW50OiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHsgYnVmZmVyZWRDb3VudDogY291bnQgfSk7XHJcbn1cclxuXHJcbi8vIC0tLSBSdW4gYnVmZmVycyAodGhlIHBlbmRpbmcgY2FwdHVyZXMgYXdhaXRpbmcgY29tbWl0KSAtLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5CdWZmZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3J1bkJ1ZmZlcnMnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8UnVuQnVmZmVyIHwgbnVsbD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICByZXR1cm4gYWxsW2hhbmRsZV0gPz8gbnVsbDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZywgYnVmOiBSdW5CdWZmZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgYWxsW2hhbmRsZV0gPSBidWY7XHJcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyUnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcclxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xyXG59XHJcblxyXG4vLyAtLS0gQWN0aXZpdHkgdGFpbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjdGl2aXR5Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBlbmRBY3Rpdml0eShldjogTG9nRXZlbnQpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRBY3Rpdml0eSgpO1xyXG4gIGN1ci51bnNoaWZ0KGV2KTtcclxuICBpZiAoY3VyLmxlbmd0aCA+IEFDVElWSVRZX1RBSUxfTUFYKSBjdXIubGVuZ3RoID0gQUNUSVZJVFlfVEFJTF9NQVg7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIGN1cik7XHJcbiAgcmV0dXJuIGN1cjtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIFtdKTtcclxufVxyXG5cclxuLy8gLS0tIENvbW1pdHRlZC10d2VldHMgZGVkdXAgaW5kZXggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2NvbW1pdHRlZEluZGV4Jyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb21taXR0ZWRJbmRleChcclxuICBpZHg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj5cclxuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdjb21taXR0ZWRJbmRleCcsIGlkeCk7XHJcbn1cclxuXHJcbi8qKiBDb21wdXRlIHRoZSBlbmdhZ2VtZW50IHNpZ25hdHVyZSB3ZSB1c2UgdG8gZGVjaWRlIHdoZXRoZXIgYSByZS1jYXB0dXJlZFxyXG4gKiB0d2VldCBpcyBcIm1hdGVyaWFsbHkgZGlmZmVyZW50XCIgZnJvbSB3aGF0IHdlIGxhc3QgY29tbWl0dGVkLiBXZSBvbWl0XHJcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXHJcbiAqIGRlZmVhdCB0aGUgZGVkdXAuIExpa2VzIC8gUlRzIC8gcmVwbGllcyAvIHF1b3RlcyBjaGFuZ2UgcmFyZWx5IGVub3VnaCB0aGF0XHJcbiAqIGVhY2ggY2hhbmdlIGlzIHdvcnRoIGEgcmUtY29tbWl0IChhbmQgYW4gZW5nYWdlbWVudF9oaXN0b3J5IHNuYXBzaG90KS5cclxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxyXG4gKiB0aGUgZnVsbCBgbm90ZV90d2VldGAgYm9keSBieXBhc3NlcyB0aGUgZGVkdXAgZXZlbiB3aGVuIGVuZ2FnZW1lbnQgY291bnRzXHJcbiAqIGhhdmVuJ3QgbW92ZWQgXHUyMDE0IG90aGVyd2lzZSB0aGUgbmV3IGJvZHkgd291bGQgYmUgc2lsZW50bHkgZHJvcHBlZC4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXHJcbiAgbGlrZXM6IG51bWJlcixcclxuICByZXR3ZWV0czogbnVtYmVyLFxyXG4gIHJlcGxpZXM6IG51bWJlcixcclxuICBxdW90ZXM6IG51bWJlcixcclxuICBpc1RydW5jYXRlZDogYm9vbGVhbiA9IGZhbHNlXHJcbik6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGAke2xpa2VzfXwke3JldHdlZXRzfXwke3JlcGxpZXN9fCR7cXVvdGVzfXwke2lzVHJ1bmNhdGVkID8gJ3QnIDogJ2YnfWA7XHJcbn1cclxuXHJcbi8qKiBEcm9wIGVudHJpZXMgb2xkZXIgdGhhbiBgbWF4QWdlTXNgLiBSZXR1cm5zIHRoZSBudW1iZXIgcHJ1bmVkLiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJ1bmVDb21taXR0ZWRJbmRleChtYXhBZ2VNczogbnVtYmVyKTogUHJvbWlzZTxudW1iZXI+IHtcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGNvbnN0IGN1dG9mZiA9IG5ldyBEYXRlKERhdGUubm93KCkgLSBtYXhBZ2VNcykudG9JU09TdHJpbmcoKTtcclxuICBsZXQgcHJ1bmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XHJcbiAgICBjb25zdCBpbm5lciA9IGlkeFtoYW5kbGVdO1xyXG4gICAgaWYgKCFpbm5lcikgY29udGludWU7XHJcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcclxuICAgICAgY29uc3QgZSA9IGlubmVyW3RpZF07XHJcbiAgICAgIGlmIChlICYmIGUudHMgPCBjdXRvZmYpIHtcclxuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcclxuICAgICAgICBwcnVuZWQgKz0gMTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKE9iamVjdC5rZXlzKGlubmVyKS5sZW5ndGggPT09IDApIGRlbGV0ZSBpZHhbaGFuZGxlXTtcclxuICB9XHJcbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XHJcbiAgcmV0dXJuIHBydW5lZDtcclxufVxyXG5cclxuLy8gLS0tIFJlZmV0Y2ggcXVldWUgKHR3ZWV0cyBuZWVkaW5nIGZ1bGwtdGV4dCByZWNhcHR1cmUpIC0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFF1ZXVlJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWZldGNoUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBsZXQgdG90YWwgPSAwO1xyXG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XHJcbiAgcmV0dXJuIHRvdGFsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBjb25zdCBpZHMgPSBxW2hhbmRsZV0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtoYW5kbGVdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXTtcclxuICBpZiAoIWlkcykgcmV0dXJuO1xyXG4gIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcclxuICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtoYW5kbGVdO1xyXG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRSZWZldGNoVGFyZ2V0KCk6IFByb21pc2U8e1xyXG4gIGhhbmRsZTogc3RyaW5nO1xyXG4gIHR3ZWV0SWQ6IHN0cmluZztcclxufSB8IG51bGw+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XHJcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGhhbmRsZSwgdHdlZXRJZDogaWRzWzBdISB9O1xyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBsZXQgdG90YWwgPSAwO1xyXG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XHJcbiAgcmV0dXJuIHRvdGFsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZU1lZGlhQ3Jhd2woaGludEhhbmRsZTogc3RyaW5nIHwgbnVsbCwgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcclxuICBjb25zdCBpZHMgPSBxW2J1Y2tldF0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtidWNrZXRdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcclxuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xyXG4gICAgY29uc3QgaWRzID0gcVtidWNrZXRdO1xyXG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xyXG4gICAgaWYgKGZpbHRlcmVkLmxlbmd0aCAhPT0gaWRzLmxlbmd0aCkge1xyXG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcclxuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcclxuICAgICAgZWxzZSBxW2J1Y2tldF0gPSBmaWx0ZXJlZDtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKGNoYW5nZWQpIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgcSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0TWVkaWFDcmF3bFRhcmdldCgpOiBQcm9taXNlPHtcclxuICBidWNrZXQ6IHN0cmluZztcclxuICB0d2VldElkOiBzdHJpbmc7XHJcbn0gfCBudWxsPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xyXG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBidWNrZXQsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXHJcbiAqIGVucXVldWVpbmcgbWVkaWEtY3Jhd2wgdGFyZ2V0cyB3ZSd2ZSBhbHJlYWR5IGFyY2hpdmVkLiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNDb21taXR0ZWQodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBmb3IgKGNvbnN0IGlubmVyIG9mIE9iamVjdC52YWx1ZXMoaWR4KSkge1xyXG4gICAgaWYgKGlubmVyICYmIHR3ZWV0SWQgaW4gaW5uZXIpIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbi8vIC0tLSBMb29wIHNlc3Npb24gc3RhdGUgKHByb2dyZXNzICsgaW5mbGlnaHQgZ2F0aW5nKSAtLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFNlc3Npb24nLCBzKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJywgcyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEF1dG9TY3JvbGxTZXNzaW9uKCk6IFByb21pc2U8QXV0b1Njcm9sbFNlc3Npb24gfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXV0b1Njcm9sbFNlc3Npb24oczogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicsIHMpO1xyXG59XHJcblxyXG4vLyAtLS0gUHVyZ2U6IHVucmVsYXRlZCBidWZmZXJzLCBjb3VudGVycywgcXVldWUgZW50cmllcyAtLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4vKipcclxuICogRHJvcCBldmVyeSBwZXItaGFuZGxlIGJpdCBvZiBzdGF0ZSAoY291bnRlcnMsIHJ1biBidWZmZXIsIGNvbW1pdHRlZC1pbmRleFxyXG4gKiBlbnRyaWVzLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcXVldWUgZW50cmllcykgdGhhdCBkb2Vzbid0IGNvcnJlc3BvbmQgdG8gYVxyXG4gKiB0cmFja2VkIGFjY291bnQuIFJldHVybnMgYSBzdW1tYXJ5IGRlc2NyaWJpbmcgd2hhdCB3YXMgY2xlYXJlZCBzbyB0aGVcclxuICogY2FsbGVyIGNhbiBsb2cgaXQuXHJcbiAqXHJcbiAqIFRyYWNrZWQgYWNjb3VudHMgYXJlIHBhc3NlZCBpbiAoY2FsbGVyIHJlc29sdmVzIGZyb20gdGhlIGxpdmUgY29uZmlnKS5cclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwdXJnZVVucmVsYXRlZFN0YXRlKHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+KTogUHJvbWlzZTx7XHJcbiAgY291bnRlcnNSZW1vdmVkOiBudW1iZXI7XHJcbiAgYnVmZmVyc1JlbW92ZWQ6IG51bWJlcjtcclxuICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkOiBudW1iZXI7XHJcbn0+IHtcclxuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcclxuICBjb25zdCBpc1RhcmdldGVkID0gKGg6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGFyZ0xvd2VyLmhhcyhoLnRvTG93ZXJDYXNlKCkpO1xyXG5cclxuICAvLyBDb3VudGVyc1xyXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcclxuICBsZXQgY291bnRlcnNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGNvdW50ZXJzW2hdO1xyXG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcclxuXHJcbiAgLy8gUnVuIGJ1ZmZlcnNcclxuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGxldCBidWZmZXJzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGJ1ZmZlcnMpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGJ1ZmZlcnNbaF07XHJcbiAgICAgIGJ1ZmZlcnNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGJ1ZmZlcnMpO1xyXG5cclxuICAvLyBDb21taXR0ZWQgZGVkdXAgaW5kZXhcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgaWR4W2hdO1xyXG4gICAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xyXG5cclxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXHJcbiAgY29uc3QgcnEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBsZXQgcmVmZXRjaEhhbmRsZXNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIHJxW2hdO1xyXG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XHJcblxyXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiBidWNrZXRzIGFyZSBoaW50LWhhbmRsZXMgKG9yIFwiX3Vua25vd25cIikuIERyb3BcclxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCBcdTIwMTQgaW5jbHVkaW5nIFwiX3Vua25vd25cIiBzaW5jZSB3ZVxyXG4gIC8vIGNhbid0IHZlcmlmeSByZWxhdGlvbi5cclxuICBjb25zdCBtcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKG1xKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xyXG4gICAgICBkZWxldGUgbXFbaF07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgbXEpO1xyXG5cclxuICByZXR1cm4ge1xyXG4gICAgY291bnRlcnNSZW1vdmVkLFxyXG4gICAgYnVmZmVyc1JlbW92ZWQsXHJcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcclxuICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCxcclxuICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkLFxyXG4gIH07XHJcbn1cclxuXHJcbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcclxufVxyXG4iLCAiaW1wb3J0IHsgYXBwZW5kQWN0aXZpdHkgfSBmcm9tICcuL3N0b3JhZ2UuanMnO1xyXG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxubGV0IGJyb2FkY2FzdDogKChldjogTG9nRXZlbnQpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc2V0QnJvYWRjYXN0ZXIoZm46IChldjogTG9nRXZlbnQpID0+IHZvaWQpOiB2b2lkIHtcclxuICBicm9hZGNhc3QgPSBmbjtcclxufVxyXG5cclxuZnVuY3Rpb24gbm93SVNPKCk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGV2OiBMb2dFdmVudCA9IHsgdHM6IG5vd0lTTygpLCBsZXZlbCwgbXNnLCBjb250ZXh0OiByZWRhY3QoY29udGV4dCkgfTtcclxuICAvLyBDb25zb2xlIGZvciBkZXZ0b29scy5cclxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xyXG4gIGlmIChsZXZlbCA9PT0gJ2Vycm9yJykgY29uc29sZS5lcnJvcihsaW5lLCBldi5jb250ZXh0KTtcclxuICBlbHNlIGlmIChsZXZlbCA9PT0gJ3dhcm4nKSBjb25zb2xlLndhcm4obGluZSwgZXYuY29udGV4dCk7XHJcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcclxuICAvLyBQZXJzaXN0ZW50IHRhaWwuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBmYWlsZWQgdG8gYXBwZW5kIGFjdGl2aXR5JywgZXJyKTtcclxuICB9XHJcbiAgLy8gTGl2ZSBicm9hZGNhc3QgKGUuZy4gdG8gc2lkZWJhcikuXHJcbiAgdHJ5IHtcclxuICAgIGJyb2FkY2FzdD8uKGV2KTtcclxuICB9IGNhdGNoIHtcclxuICAgIC8vIFNpZGViYXIgbWF5IG5vdCBiZSBvcGVuOyB0aGF0J3MgZmluZS5cclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIGVtaXQoJ2luZm8nLCBtc2csIGNvbnRleHQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIGVtaXQoJ3dhcm4nLCBtc2csIGNvbnRleHQpO1xyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHJldHVybiBlbWl0KCdlcnJvcicsIG1zZywgY29udGV4dCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZUVycm9yKGVycjogdW5rbm93bik6IHsgbWVzc2FnZTogc3RyaW5nOyBzdGFjazogc3RyaW5nIHwgbnVsbCB9IHtcclxuICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcclxuICB9XHJcbiAgdHJ5IHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIHsgbWVzc2FnZTogJzx1bnByaW50YWJsZSBlcnJvcj4nLCBzdGFjazogbnVsbCB9O1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFN0cmlwIGFueXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIFBBVCBvciBvdGhlciBsb25nIHNlY3JldCBmcm9tIGEgY29udGV4dFxyXG4gKiBvYmplY3QgYmVmb3JlIHBlcnNpc3RpbmcgaXQuIERlZmVuc2l2ZTogY2FsbGVycyBzaG91bGQgbm90IGxvZyB0b2tlbnMsIGJ1dFxyXG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxyXG4gKi9cclxuZnVuY3Rpb24gcmVkYWN0KGN0eDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XHJcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xyXG4gIGZvciAoY29uc3QgW2ssIHZdIG9mIE9iamVjdC5lbnRyaWVzKGN0eCkpIHtcclxuICAgIGlmIChrLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ3Rva2VuJykgfHwgay50b0xvd2VyQ2FzZSgpID09PSAncGF0JyB8fCBrID09PSAnYXV0aG9yaXphdGlvbicpIHtcclxuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dezMwLH0vLnRlc3QodikpIHtcclxuICAgICAgb3V0W2tdID0gdi5yZXBsYWNlKC9naXRodWJfcGF0X1tBLVphLXowLTlfXSsvZywgJ2dpdGh1Yl9wYXRfPHJlZGFjdGVkPicpO1xyXG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XHJcbiAgICAgIG91dFtrXSA9IGAke3Yuc2xpY2UoMCwgNDA5Nil9XHUyMDI2PHRydW5jYXRlZD5gO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgb3V0W2tdID0gdjtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG4iLCAiaW1wb3J0IHsgZGVzY3JpYmVFcnJvciB9IGZyb20gJy4vbG9nZ2VyLmpzJztcbmltcG9ydCB0eXBlIHsgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuY29uc3QgQVBJX0JBU0UgPSAnaHR0cHM6Ly9hcGkuZ2l0aHViLmNvbSc7XG5jb25zdCBSQVdfQkFTRSA9ICdodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20nO1xuXG5leHBvcnQgaW50ZXJmYWNlIFB1dEZpbGVPcHRpb25zIHtcbiAgcGF0aDogc3RyaW5nO1xuICBjb250ZW50QmFzZTY0OiBzdHJpbmc7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgZXhwZWN0ZWRTaGE/OiBzdHJpbmcgfCBudWxsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFB1dEZpbGVSZXN1bHQge1xuICBwYXRoOiBzdHJpbmc7XG4gIHNoYTogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlT3B0aW9ucyB7XG4gIHBhdGg6IHN0cmluZztcbiAgY29udGVudEJhc2U2NDogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVzT3B0aW9ucyB7XG4gIGZpbGVzOiBDb21taXRGaWxlT3B0aW9uc1tdO1xuICBtZXNzYWdlOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZXNSZXN1bHQge1xuICBjb21taXRTaGE6IHN0cmluZztcbiAgdXJsOiBzdHJpbmc7XG4gIGZpbGVzOiBzdHJpbmdbXTtcbn1cblxuZXhwb3J0IGNsYXNzIEdpdEh1YkVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBzdGF0dXM6IG51bWJlcjtcbiAgYm9keTogdW5rbm93bjtcbiAgcmV0cmlhYmxlOiBib29sZWFuO1xuICBjYXRlZ29yeTogJ2F1dGgnIHwgJ3JhdGUtbGltaXQnIHwgJ2NvbmZsaWN0JyB8ICdub3QtZm91bmQnIHwgJ3NlcnZlcicgfCAnbmV0d29yaycgfCAndW5rbm93bic7XG4gIC8qKiBXaGVuIHRoZSBHaXRIdWIgcmF0ZS1saW1pdCB3aW5kb3cgZm9yIHRoaXMgdG9rZW4gcmVzZXRzLCBhcyBhIFVuaXhcbiAgICogZXBvY2ggaW4gc2Vjb25kcy4gUG9wdWxhdGVkIGZyb20gYFgtUmF0ZUxpbWl0LVJlc2V0YCBvbiA0MDMvNDI5LCBvclxuICAgKiBkZXJpdmVkIGZyb20gYFJldHJ5LUFmdGVyYCBmb3Igc2Vjb25kYXJ5IGxpbWl0cy4gbnVsbCB3aGVuIHVua25vd24uICovXG4gIHJhdGVMaW1pdFJlc2V0QXQ6IG51bWJlciB8IG51bGw7XG5cbiAgY29uc3RydWN0b3Iob3B0czoge1xuICAgIHN0YXR1czogbnVtYmVyO1xuICAgIGJvZHk6IHVua25vd247XG4gICAgbWVzc2FnZTogc3RyaW5nO1xuICAgIHJldHJpYWJsZTogYm9vbGVhbjtcbiAgICBjYXRlZ29yeTogR2l0SHViRXJyb3JbJ2NhdGVnb3J5J107XG4gICAgcmF0ZUxpbWl0UmVzZXRBdD86IG51bWJlciB8IG51bGw7XG4gIH0pIHtcbiAgICBzdXBlcihvcHRzLm1lc3NhZ2UpO1xuICAgIHRoaXMubmFtZSA9ICdHaXRIdWJFcnJvcic7XG4gICAgdGhpcy5zdGF0dXMgPSBvcHRzLnN0YXR1cztcbiAgICB0aGlzLmJvZHkgPSBvcHRzLmJvZHk7XG4gICAgdGhpcy5yZXRyaWFibGUgPSBvcHRzLnJldHJpYWJsZTtcbiAgICB0aGlzLmNhdGVnb3J5ID0gb3B0cy5jYXRlZ29yeTtcbiAgICB0aGlzLnJhdGVMaW1pdFJlc2V0QXQgPSBvcHRzLnJhdGVMaW1pdFJlc2V0QXQgPz8gbnVsbDtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgR2l0SHViQ2xpZW50IHtcbiAgcHJpdmF0ZSByZWFkb25seSBzZXR0aW5nczogU2V0dGluZ3M7XG5cbiAgY29uc3RydWN0b3Ioc2V0dGluZ3M6IFNldHRpbmdzKSB7XG4gICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzO1xuICB9XG5cbiAgLyoqIFJldHVybnMgdGhlIGF1dGhlbnRpY2F0ZWQgdXNlcidzIGxvZ2luLiBUaHJvd3Mgb24gYXV0aCBmYWlsdXJlLiAqL1xuICBhc3luYyB3aG9hbWkoKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgJy91c2VyJyk7XG4gICAgcmV0dXJuIChyZXMgYXMgeyBsb2dpbj86IHN0cmluZyB9KS5sb2dpbiA/PyAnPHVua25vd24+JztcbiAgfVxuXG4gIC8qKiBSZXR1cm5zIHRydWUgaWYgdGhlIGdpdmVuIGJyYW5jaCBleGlzdHMgb24gdGhlIGNvbmZpZ3VyZWQgcmVwby4gKi9cbiAgYXN5bmMgYnJhbmNoRXhpc3RzKGJyYW5jaDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9icmFuY2hlcy8ke2VuY29kZVVSSUNvbXBvbmVudChicmFuY2gpfWBcbiAgICAgICk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gZmFsc2U7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9XG5cbiAgLyoqIFZlcmlmaWVzIHRoZSBQQVQgY2FuIHNlZSB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xuICBhc3luYyB2ZXJpZnlSZXBvQWNjZXNzKCk6IFByb21pc2U8eyBsb2dpbjogc3RyaW5nOyBmdWxsX25hbWU6IHN0cmluZzsgZGVmYXVsdF9icmFuY2g6IHN0cmluZyB9PiB7XG4gICAgY29uc3QgbWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgJy91c2VyJyk7XG4gICAgY29uc3QgcmVwbyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99YCk7XG4gICAgY29uc3QgciA9IHJlcG8gYXMgeyBmdWxsX25hbWU6IHN0cmluZzsgZGVmYXVsdF9icmFuY2g6IHN0cmluZyB9O1xuICAgIHJldHVybiB7XG4gICAgICBsb2dpbjogKG1lIGFzIHsgbG9naW46IHN0cmluZyB9KS5sb2dpbixcbiAgICAgIGZ1bGxfbmFtZTogci5mdWxsX25hbWUsXG4gICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIEZldGNoIGEgdGV4dCBmaWxlIGZyb20gcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSBhdXRoZW50aWNhdGVkIHdpdGggdGhlXG4gICAqIFBBVC4gUmV0dXJucyBudWxsIGlmIHRoZSBmaWxlIGRvZXNuJ3QgZXhpc3QuIFVzZWQgZm9yIGNvbmZpZy9hY2NvdW50cy55YW1sLlxuICAgKi9cbiAgYXN5bmMgZmV0Y2hSYXdUZXh0KHBhdGhJblJlcG86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IHVybCA9IGAke1JBV19CQVNFfS8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS8ke3RoaXMuc2V0dGluZ3MuYnJhbmNofS8ke3BhdGhJblJlcG99YDtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLnNldHRpbmdzLnBhdH1gIH0sXG4gICAgfSk7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkgcmV0dXJuIG51bGw7XG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yKHJlcywgYEdFVCByYXcgJHtwYXRoSW5SZXBvfWApO1xuICAgIHJldHVybiByZXMudGV4dCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvb2sgdXAgYW4gZXhpc3RpbmcgZmlsZSdzIFNIQSB2aWEgdGhlIENvbnRlbnRzIEFQSSwgb3IgbnVsbCBpZiBub3QgZm91bmQuXG4gICAqIFVzZWQgd2hlbiByZXRyeWluZyBhIFBVVCBhZnRlciBhIDQyMiBzaGEgbWlzbWF0Y2guXG4gICAqL1xuICBhc3luYyBnZXRGaWxlU2hhKHBhdGg6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vY29udGVudHMvJHtlbmNvZGVQYXRoKHBhdGgpfT9yZWY9JHtlbmNvZGVVUklDb21wb25lbnQodGhpcy5zZXR0aW5ncy5icmFuY2gpfWBcbiAgICAgICk7XG4gICAgICBjb25zdCByID0gcmVzIGFzIHsgc2hhPzogc3RyaW5nIH07XG4gICAgICByZXR1cm4gci5zaGEgPz8gbnVsbDtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gbnVsbDtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUFVUIGEgZmlsZSB0byB0aGUgcmVwby4gSGFuZGxlcyA0MjIgKHNoYSByZXF1aXJlZCkgYnkgcmUtZmV0Y2hpbmcgdGhlXG4gICAqIGV4aXN0aW5nIHNoYSBhbmQgcmV0cnlpbmcgb25jZS4gUmV0cmllcyBuZXR3b3JrIC8gNXh4IC8gcmF0ZS1saW1pdCBlcnJvcnNcbiAgICogd2l0aCBleHBvbmVudGlhbCBiYWNrb2ZmIHVwIHRvIG1heEF0dGVtcHRzLlxuICAgKi9cbiAgYXN5bmMgcHV0RmlsZShvcHRzOiBQdXRGaWxlT3B0aW9ucyk6IFByb21pc2U8UHV0RmlsZVJlc3VsdD4ge1xuICAgIGNvbnN0IHBhdGggPSBvcHRzLnBhdGg7XG4gICAgY29uc3QgdXJsID0gYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9YDtcbiAgICBsZXQgc2hhOiBzdHJpbmcgfCBudWxsID0gb3B0cy5leHBlY3RlZFNoYSA/PyBudWxsO1xuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcbiAgICAgIGNvbnN0IGJvZHk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXG4gICAgICAgIGNvbnRlbnQ6IG9wdHMuY29udGVudEJhc2U2NCxcbiAgICAgICAgYnJhbmNoOiB0aGlzLnNldHRpbmdzLmJyYW5jaCxcbiAgICAgIH07XG4gICAgICBpZiAoc2hhKSBib2R5LnNoYSA9IHNoYTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdQVVQnLCB1cmwsIGJvZHkpO1xuICAgICAgICBjb25zdCBvdXQgPSByZXMgYXMgeyBjb250ZW50OiB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nOyBwYXRoOiBzdHJpbmcgfSB9O1xuICAgICAgICByZXR1cm4geyBwYXRoOiBvdXQuY29udGVudC5wYXRoLCBzaGE6IG91dC5jb250ZW50LnNoYSwgdXJsOiBvdXQuY29udGVudC5odG1sX3VybCB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xuICAgICAgICBpZiAoZXJyLnN0YXR1cyA9PT0gNDIyICYmICFzaGEpIHtcbiAgICAgICAgICAvLyBGaWxlIGFscmVhZHkgZXhpc3RzOyBmZXRjaCBpdHMgc2hhIGFuZCByZXRyeSBvbmNlLlxuICAgICAgICAgIHNoYSA9IGF3YWl0IHRoaXMuZ2V0RmlsZVNoYShwYXRoKTtcbiAgICAgICAgICBpZiAoIXNoYSkgdGhyb3cgZXJyO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZXJyLnJldHJpYWJsZSB8fCBhdHRlbXB0ID09PSBtYXhBdHRlbXB0cykgdGhyb3cgZXJyO1xuICAgICAgICBhd2FpdCBzbGVlcChiYWNrb2ZmTXMoYXR0ZW1wdCwgZXJyKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihgcHV0RmlsZTogZXhoYXVzdGVkIGF0dGVtcHRzIGZvciAke3BhdGh9YCk7XG4gIH1cblxuICAvKipcbiAgICogQ29tbWl0IHNldmVyYWwgZmlsZXMgd2l0aCBvbmUgYnJhbmNoIHVwZGF0ZS4gVGhlIENvbnRlbnRzIEFQSSBjcmVhdGVzIG9uZVxuICAgKiBjb21taXQgcGVyIFBVVCwgc28gcmFwaWQgZmx1c2hlcyByYWNlIGVhY2ggb3RoZXIgb24gdGhlIGJyYW5jaCBoZWFkLiBUaGlzXG4gICAqIHVzZXMgdGhlIGxvd2VyLWxldmVsIEdpdCBEYXRhIEFQSSBpbnN0ZWFkOiB1cGxvYWQgYmxvYnMsIGJ1aWxkIGEgdHJlZSxcbiAgICogY3JlYXRlIG9uZSBjb21taXQsIHRoZW4gbW92ZSB0aGUgYnJhbmNoIHJlZiBvbmNlLiBJZiBhbm90aGVyIHdyaXRlciBtb3Zlc1xuICAgKiB0aGUgYnJhbmNoIGZpcnN0LCByZWJhc2UgdGhpcyB0cmVlIHBhdGNoIG9udG8gdGhlIGxhdGVzdCBoZWFkIGFuZCByZXRyeS5cbiAgICovXG4gIGFzeW5jIGNvbW1pdEZpbGVzKG9wdHM6IENvbW1pdEZpbGVzT3B0aW9ucyk6IFByb21pc2U8Q29tbWl0RmlsZXNSZXN1bHQ+IHtcbiAgICBpZiAob3B0cy5maWxlcy5sZW5ndGggPT09IDApIHRocm93IG5ldyBFcnJvcignY29tbWl0RmlsZXM6IG5vIGZpbGVzIHRvIGNvbW1pdCcpO1xuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcbiAgICBsZXQgbGFzdEVycjogdW5rbm93biA9IG51bGw7XG5cbiAgICBmb3IgKGxldCBhdHRlbXB0ID0gMTsgYXR0ZW1wdCA8PSBtYXhBdHRlbXB0czsgYXR0ZW1wdCsrKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBibG9icyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICAgIG9wdHMuZmlsZXMubWFwKGFzeW5jIChmaWxlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBvdXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9ibG9ic2AsXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBjb250ZW50OiBmaWxlLmNvbnRlbnRCYXNlNjQsXG4gICAgICAgICAgICAgICAgZW5jb2Rpbmc6ICdiYXNlNjQnLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgcGF0aDogZmlsZS5wYXRoLFxuICAgICAgICAgICAgICBzaGE6IChvdXQgYXMgeyBzaGE6IHN0cmluZyB9KS5zaGEsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0pXG4gICAgICAgICk7XG5cbiAgICAgICAgY29uc3QgaGVhZCA9IGF3YWl0IHRoaXMuZ2V0QnJhbmNoSGVhZCgpO1xuICAgICAgICBjb25zdCB0cmVlID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L3RyZWVzYCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBiYXNlX3RyZWU6IGhlYWQudHJlZVNoYSxcbiAgICAgICAgICAgIHRyZWU6IGJsb2JzLm1hcCgoYmxvYikgPT4gKHtcbiAgICAgICAgICAgICAgcGF0aDogYmxvYi5wYXRoLFxuICAgICAgICAgICAgICBtb2RlOiAnMTAwNjQ0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ2Jsb2InLFxuICAgICAgICAgICAgICBzaGE6IGJsb2Iuc2hhLFxuICAgICAgICAgICAgfSkpLFxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgdHJlZVNoYSA9ICh0cmVlIGFzIHsgc2hhOiBzdHJpbmcgfSkuc2hhO1xuICAgICAgICBjb25zdCBjb21taXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvY29tbWl0c2AsXG4gICAgICAgICAge1xuICAgICAgICAgICAgbWVzc2FnZTogb3B0cy5tZXNzYWdlLFxuICAgICAgICAgICAgdHJlZTogdHJlZVNoYSxcbiAgICAgICAgICAgIHBhcmVudHM6IFtoZWFkLnNoYV0sXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICBjb25zdCBjb21taXRPdXQgPSBjb21taXQgYXMgeyBzaGE6IHN0cmluZzsgaHRtbF91cmw6IHN0cmluZyB9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICAgJ1BBVENIJyxcbiAgICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L3JlZnMvaGVhZHMvJHtlbmNvZGVQYXRoKHRoaXMuc2V0dGluZ3MuYnJhbmNoKX1gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaGE6IGNvbW1pdE91dC5zaGEsXG4gICAgICAgICAgICAgIGZvcmNlOiBmYWxzZSxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBpZiAoaXNDb25mbGljdChlcnIpICYmIGF0dGVtcHQgPCBtYXhBdHRlbXB0cykge1xuICAgICAgICAgICAgbGFzdEVyciA9IGVycjtcbiAgICAgICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBjb21taXRTaGE6IGNvbW1pdE91dC5zaGEsXG4gICAgICAgICAgdXJsOiBjb21taXRPdXQuaHRtbF91cmwsXG4gICAgICAgICAgZmlsZXM6IG9wdHMuZmlsZXMubWFwKChmaWxlKSA9PiBmaWxlLnBhdGgpLFxuICAgICAgICB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGxhc3RFcnIgPSBlcnI7XG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xuICAgICAgICBpZiAoKCFlcnIucmV0cmlhYmxlICYmICFpc0NvbmZsaWN0KGVycikpIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbGFzdEVyciBpbnN0YW5jZW9mIEVycm9yID8gbGFzdEVyciA6IG5ldyBFcnJvcignY29tbWl0RmlsZXM6IGV4aGF1c3RlZCBhdHRlbXB0cycpO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBnZXRCcmFuY2hIZWFkKCk6IFByb21pc2U8eyBzaGE6IHN0cmluZzsgdHJlZVNoYTogc3RyaW5nIH0+IHtcbiAgICBjb25zdCByZWYgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICdHRVQnLFxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmL2hlYWRzLyR7ZW5jb2RlUGF0aCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxuICAgICk7XG4gICAgY29uc3QgaGVhZFNoYSA9IChyZWYgYXMgeyBvYmplY3Q6IHsgc2hhOiBzdHJpbmcgfSB9KS5vYmplY3Quc2hhO1xuICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgJ0dFVCcsXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9jb21taXRzLyR7aGVhZFNoYX1gXG4gICAgKTtcbiAgICByZXR1cm4ge1xuICAgICAgc2hhOiBoZWFkU2hhLFxuICAgICAgdHJlZVNoYTogKGNvbW1pdCBhcyB7IHRyZWU6IHsgc2hhOiBzdHJpbmcgfSB9KS50cmVlLnNoYSxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmZXRjaEpzb24obWV0aG9kOiBzdHJpbmcsIHBhdGg6IHN0cmluZywgYm9keT86IHVua25vd24pOiBQcm9taXNlPHVua25vd24+IHtcbiAgICBjb25zdCB1cmwgPSBwYXRoLnN0YXJ0c1dpdGgoJ2h0dHAnKSA/IHBhdGggOiBgJHtBUElfQkFTRX0ke3BhdGh9YDtcbiAgICBjb25zdCBpbml0OiBSZXF1ZXN0SW5pdCA9IHtcbiAgICAgIG1ldGhvZCxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAsXG4gICAgICAgIEFjY2VwdDogJ2FwcGxpY2F0aW9uL3ZuZC5naXRodWIranNvbicsXG4gICAgICAgICdYLUdpdEh1Yi1BcGktVmVyc2lvbic6ICcyMDIyLTExLTI4JyxcbiAgICAgICAgLi4uKGJvZHkgPyB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSA6IHt9KSxcbiAgICAgIH0sXG4gICAgICAuLi4oYm9keSA/IHsgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSkgfSA6IHt9KSxcbiAgICB9O1xuICAgIGxldCByZXM6IFJlc3BvbnNlO1xuICAgIHRyeSB7XG4gICAgICByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIGluaXQpO1xuICAgIH0gY2F0Y2ggKG5ldEVycikge1xuICAgICAgdGhyb3cgbmV3IEdpdEh1YkVycm9yKHtcbiAgICAgICAgc3RhdHVzOiAwLFxuICAgICAgICBib2R5OiBudWxsLFxuICAgICAgICBtZXNzYWdlOiBgbmV0d29yazogJHtkZXNjcmliZUVycm9yKG5ldEVycikubWVzc2FnZX1gLFxuICAgICAgICByZXRyaWFibGU6IHRydWUsXG4gICAgICAgIGNhdGVnb3J5OiAnbmV0d29yaycsXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDIwNCkgcmV0dXJuIG51bGw7XG4gICAgbGV0IHBhcnNlZDogdW5rbm93biA9IG51bGw7XG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgaWYgKHRleHQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgcGFyc2VkID0gdGV4dDtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgYCR7bWV0aG9kfSAke3BhdGh9YCk7XG4gICAgcmV0dXJuIHBhcnNlZDtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbWFrZUVycm9yKHJlczogUmVzcG9uc2UsIGxhYmVsOiBzdHJpbmcpOiBQcm9taXNlPEdpdEh1YkVycm9yPiB7XG4gICAgbGV0IHBhcnNlZDogdW5rbm93biA9IG51bGw7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgICAgaWYgKHRleHQpIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBpZ25vcmVcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgbGFiZWwpO1xuICB9XG5cbiAgcHJpdmF0ZSBtYWtlRXJyb3JGcm9tUGFyc2VkKHJlczogUmVzcG9uc2UsIGJvZHk6IHVua25vd24sIGxhYmVsOiBzdHJpbmcpOiBHaXRIdWJFcnJvciB7XG4gICAgY29uc3QgbXNnID1cbiAgICAgIHR5cGVvZiBib2R5ID09PSAnb2JqZWN0JyAmJiBib2R5ICYmICdtZXNzYWdlJyBpbiBib2R5XG4gICAgICAgID8gU3RyaW5nKChib2R5IGFzIHsgbWVzc2FnZTogdW5rbm93biB9KS5tZXNzYWdlKVxuICAgICAgICA6IHJlcy5zdGF0dXNUZXh0O1xuICAgIGxldCBjYXRlZ29yeTogR2l0SHViRXJyb3JbJ2NhdGVnb3J5J10gPSAndW5rbm93bic7XG4gICAgbGV0IHJldHJpYWJsZSA9IGZhbHNlO1xuICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDEgfHwgcmVzLnN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAvLyA0MDMgY2FuIGJlIGVpdGhlciBhdXRoIG9yIHJhdGUgbGltaXQ7IGNoZWNrIGhlYWRlcnMuXG4gICAgICBjb25zdCByYXRlID0gcmVzLmhlYWRlcnMuZ2V0KCd4LXJhdGVsaW1pdC1yZW1haW5pbmcnKTtcbiAgICAgIGlmIChyYXRlID09PSAnMCcgfHwgL3JhdGUgbGltaXQvaS50ZXN0KG1zZykpIHtcbiAgICAgICAgY2F0ZWdvcnkgPSAncmF0ZS1saW1pdCc7XG4gICAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjYXRlZ29yeSA9ICdhdXRoJztcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkge1xuICAgICAgY2F0ZWdvcnkgPSAnbm90LWZvdW5kJztcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwOSB8fCByZXMuc3RhdHVzID09PSA0MjIpIHtcbiAgICAgIGNhdGVnb3J5ID0gJ2NvbmZsaWN0JztcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPj0gNTAwKSB7XG4gICAgICBjYXRlZ29yeSA9ICdzZXJ2ZXInO1xuICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQyOSkge1xuICAgICAgY2F0ZWdvcnkgPSAncmF0ZS1saW1pdCc7XG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IEdpdEh1YkVycm9yKHtcbiAgICAgIHN0YXR1czogcmVzLnN0YXR1cyxcbiAgICAgIGJvZHksXG4gICAgICBtZXNzYWdlOiBgJHtsYWJlbH0gXHUyMTkyICR7cmVzLnN0YXR1c306ICR7bXNnfWAsXG4gICAgICByZXRyaWFibGUsXG4gICAgICBjYXRlZ29yeSxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyBwYXJzZVJhdGVMaW1pdFJlc2V0KHJlcy5oZWFkZXJzKSA6IG51bGwsXG4gICAgfSk7XG4gIH1cbn1cblxuLyoqXG4gKiBCZXN0LWVmZm9ydCBwYXJzZSBvZiB3aGVuIHRoZSBjdXJyZW50IHJhdGUtbGltaXQgd2luZG93IGVuZHMuIEdpdEh1YidzXG4gKiBwcmltYXJ5IGxpbWl0IHJlcG9ydHMgYFgtUmF0ZUxpbWl0LVJlc2V0YCBhcyBhIFVuaXggZXBvY2ggaW4gc2Vjb25kcy5cbiAqIFNlY29uZGFyeSAvIGFidXNlIGxpbWl0cyB1c2UgYFJldHJ5LUFmdGVyYCwgd2hpY2ggaXMgZWl0aGVyIGFuIEhUVFAtZGF0ZVxuICogb3IgYSBkZWx0YSBpbiBzZWNvbmRzIFx1MjAxNCB3ZSBub3JtYWxpemUgYm90aCB0byBlcG9jaCBzZWNvbmRzLlxuICovXG5mdW5jdGlvbiBwYXJzZVJhdGVMaW1pdFJlc2V0KGhlYWRlcnM6IEhlYWRlcnMpOiBudW1iZXIgfCBudWxsIHtcbiAgY29uc3QgcmVzZXQgPSBoZWFkZXJzLmdldCgneC1yYXRlbGltaXQtcmVzZXQnKTtcbiAgaWYgKHJlc2V0KSB7XG4gICAgY29uc3QgbiA9IE51bWJlci5wYXJzZUludChyZXNldCwgMTApO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikgJiYgbiA+IDApIHJldHVybiBuO1xuICB9XG4gIGNvbnN0IHJldHJ5QWZ0ZXIgPSBoZWFkZXJzLmdldCgncmV0cnktYWZ0ZXInKTtcbiAgaWYgKHJldHJ5QWZ0ZXIpIHtcbiAgICBjb25zdCBkZWx0YSA9IE51bWJlci5wYXJzZUludChyZXRyeUFmdGVyLCAxMCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShkZWx0YSkgJiYgZGVsdGEgPj0gMCkge1xuICAgICAgcmV0dXJuIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApICsgZGVsdGE7XG4gICAgfVxuICAgIGNvbnN0IGFzRGF0ZSA9IERhdGUucGFyc2UocmV0cnlBZnRlcik7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShhc0RhdGUpKSByZXR1cm4gTWF0aC5mbG9vcihhc0RhdGUgLyAxMDAwKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gZW5jb2RlUGF0aChwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBFbmNvZGUgc2VnbWVudHMgaW5kaXZpZHVhbGx5IHNvIHNsYXNoZXMgcmVtYWluLlxuICByZXR1cm4gcGF0aC5zcGxpdCgnLycpLm1hcChlbmNvZGVVUklDb21wb25lbnQpLmpvaW4oJy8nKTtcbn1cblxuZnVuY3Rpb24gYmFja29mZk1zKGF0dGVtcHQ6IG51bWJlciwgZXJyOiBHaXRIdWJFcnJvcik6IG51bWJlciB7XG4gIC8vIEV4cG9uZW50aWFsIHdpdGggaml0dGVyOyBidW1wIGhpZ2hlciBmb3IgcmF0ZS1saW1pdCByZXNwb25zZXMuXG4gIGNvbnN0IGJhc2UgPSBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IDUwMDAgOiA1MDA7XG4gIGNvbnN0IGppdHRlciA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDQwMCk7XG4gIHJldHVybiBNYXRoLm1pbig2MF8wMDAsIGJhc2UgKiAyICoqIChhdHRlbXB0IC0gMSkgKyBqaXR0ZXIpO1xufVxuXG5mdW5jdGlvbiBpc0NvbmZsaWN0KGVycjogdW5rbm93bik6IGVyciBpcyBHaXRIdWJFcnJvciB7XG4gIHJldHVybiBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdjb25mbGljdCc7XG59XG5cbmZ1bmN0aW9uIHNsZWVwKG1zOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0b0Jhc2U2NChieXRlczogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gYnl0ZXMgaXMgYSBVVEYtOCBzdHJpbmcgb2YgSlNPTjsgZW5jb2RlIHRvIGJhc2U2NCB0aGUgc2FmZSB3YXkuXG4gIGNvbnN0IHV0ZjggPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoYnl0ZXMpO1xuICBsZXQgYmluID0gJyc7XG4gIGZvciAoY29uc3QgYiBvZiB1dGY4KSBiaW4gKz0gU3RyaW5nLmZyb21DaGFyQ29kZShiKTtcbiAgcmV0dXJuIGJ0b2EoYmluKTtcbn1cbiIsICJpbXBvcnQgeyBUV0VFVF9VUkxfUFJFRklYIH0gZnJvbSAnLi9jb25maWcuanMnO1xuaW1wb3J0IHR5cGUge1xuICBDYW5vbmljYWxUd2VldCxcbiAgQ29tbXVuaXR5Tm90ZSxcbiAgTWVkaWFJdGVtLFxuICBUd2VldENhcmQsXG4gIFR3ZWV0VHlwZSxcbiAgVXJsRW50aXR5LFxuICBVc2VyU25hcHNob3QsXG59IGZyb20gJy4vdHlwZXMuanMnO1xuXG4vKipcbiAqIE5vcm1hbGl6ZSBHcmFwaFFMIHJlc3BvbnNlIHBheWxvYWRzIGZyb20gWCdzIGludGVybmFsIEFQSSBpbnRvXG4gKiBgQ2Fub25pY2FsVHdlZXRgcy4gTWFueSBlbmRwb2ludHMgc2hhcmUgYSBzaW1pbGFyIHR3ZWV0IHNoYXBlIGJ1dCB3cmFwIGl0IGluXG4gKiBkaWZmZXJlbnQgZW52ZWxvcGVzOyB0aGlzIG1vZHVsZSB3YWxrcyB0aGUgc3RydWN0dXJlIGRlZmVuc2l2ZWx5LlxuICpcbiAqIFRoZSBwYXJzZXIgaXMgaW50ZW50aW9uYWxseSBwZXJtaXNzaXZlOiBpdCB3aWxsIHNpbGVudGx5IHNraXAgZW50cmllcyBpdFxuICogY2FuJ3QgcmVjb2duaXplIGFzIHR3ZWV0cyAoY3Vyc29ycywgYWRzLCBnYXAgZW50cmllcywgbW9kdWxlcyBvZiBvdGhlclxuICogdHdlZXRzLCB0b21ic3RvbmVzKS4gSXQgdGhyb3dzICpvbmx5KiB3aGVuIGdpdmVuIGEgcGF5bG9hZCBpdCBkb2Vzbid0IGtub3dcbiAqIGhvdyB0byB3YWxrIGF0IGFsbCBcdTIwMTQgdGhvc2UgY2FzZXMgYXJlIGNhdWdodCBhbmQgcXVhcmFudGluZWQgdXBzdHJlYW0uXG4gKi9cblxuZXhwb3J0IGludGVyZmFjZSBOb3JtYWxpemVDb250ZXh0IHtcbiAgY2FwdHVyZWRBdDogc3RyaW5nO1xuICBydW5JZDogc3RyaW5nO1xuICBlbmRwb2ludDogc3RyaW5nO1xuICBhbGxvd2VkSGFuZGxlczogUmVhZG9ubHlTZXQ8c3RyaW5nPjtcbiAgc291cmNlVXJsPzogc3RyaW5nIHwgbnVsbDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBOb3JtYWxpemVSZXN1bHQge1xuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W107XG4gIG9ic2VydmVkX2lkczogc3RyaW5nW107XG4gIC8qKlxuICAgKiBUd2VldC1zaGFwZWQgbm9kZXMgdGhlIHdhbGtlciBzYXcgKGhhZCBhIGByZXN0X2lkYCkgYnV0IGNvdWxkbid0IHR1cm5cbiAgICogaW50byBhIGZ1bGwgYENhbm9uaWNhbFR3ZWV0YCBcdTIwMTQgdHlwaWNhbGx5IGJlY2F1c2UgdGhlIGVtYmVkZGVkIHVzZXJcbiAgICogaW5mbyB3YXMgbWlzc2luZyBvciB0aGUgZW50cnkgd2FzIGEgbWVkaWEtb25seSB0aHVtYm5haWwgY2FyZCBmcm9tXG4gICAqIHRoZSBVc2VyTWVkaWEgZW5kcG9pbnQuIFRoZSBiYWNrZ3JvdW5kIHF1ZXVlcyB0aGVzZSBmb3IgYW4gZXhwbGljaXRcbiAgICogXCJnbyBmZXRjaCB0aGUgZGV0YWlsIHBhZ2VcIiBjcmF3bCBzbyB3ZSBkb24ndCBkcm9wIHRoZW0gb24gdGhlIGZsb29yLlxuICAgKi9cbiAgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT47XG59XG5cbi8vIFggdHdlZXQgSURzIGFyZSA2NC1iaXQgcG9zaXRpdmUgaW50ZWdlcnMgc2VyaWFsaXplZCBhcyBkZWNpbWFsIHN0cmluZ3MuXG4vLyBUaGV5J3ZlIGdyb3duIHRvIDE5IGNoYXJzICh+MS41ZTE4KSBieSAyMDI2LiBSZWplY3QgYW55dGhpbmcgdGhhdCBkb2Vzbid0XG4vLyBtYXRjaCB0aGlzIHNoYXBlIFx1MjAxNCBvdGhlcndpc2Ugc3B1cmlvdXMgY2FyZCBJRHMsIGN1cnNvciBzdHJpbmdzLCBhZCBzbG90XG4vLyBJRHMsIGV0Yy4gZW5kIHVwIGluIHRoZSBwYXJ0aWFsLWNhcHR1cmUgcXVldWUgYW5kIHRoZSBjcmF3bCBsb29wXG4vLyBuYXZpZ2F0ZXMgdG8gaW52YWxpZCBVUkxzIHRoYXQgc2hvdyBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXG5jb25zdCBUV0VFVF9JRF9SRSA9IC9eXFxkezE1LDIwfSQvO1xuXG4vLyBPbmx5IG9uZSBlbmRwb2ludCBhY3R1YWxseSBleHBvc2VzIHRoZSBmYWlsdXJlIG1vZGUgdGhlIHBhcnRpYWwtY2FwdHVyZVxuLy8gcXVldWUgZXhpc3RzIGZvciBcdTIwMTQgdGhlIE1lZGlhIHRhYidzIGBVc2VyTWVkaWFgIHF1ZXJ5IHJldHVybmluZ1xuLy8gdGh1bWJuYWlsLW9ubHkgZW50cmllcyB3aXRob3V0IGEgcG9wdWxhdGVkIGF1dGhvciBibG9jay4gRXZlcnkgb3RoZXJcbi8vIGVuZHBvaW50IHRoYXQgaGFuZHMgdXMgYSBgVHdlZXRgIHNoYXBlIGdpdmVzIHVzIHRoZSBmdWxsIGVudHJ5OyBpZlxuLy8gYGJ1aWxkVHdlZXRgIGZhaWxzIHRoZXJlIGl0J3MgYSByZWFsIGVycm9yLCBub3QgXCJnbyByZS1mZXRjaCB0aGlzXCIuXG4vLyBSZXN0cmljdGluZyBwYXJ0aWFsLWlkIGVtaXNzaW9uIHRvIFVzZXJNZWRpYSBzdG9wcyB0aGUgZmxvb2RzIG9mXG4vLyBmYWxzZSBwb3NpdGl2ZXMgcmVwb3J0ZWQgb24gUmVwbGllcyAvIFR3ZWV0RGV0YWlsIC8gU2VhcmNoVGltZWxpbmUuXG5jb25zdCBQQVJUSUFMX09LX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyTWVkaWEnXSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemUocGF5bG9hZDogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogTm9ybWFsaXplUmVzdWx0IHtcbiAgY29uc3QgcmF3VHdlZXRzID0gY29sbGVjdFR3ZWV0cyhwYXlsb2FkKTtcbiAgY29uc3QgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdID0gW107XG4gIGNvbnN0IG9ic2VydmVkOiBzdHJpbmdbXSA9IFtdO1xuICBjb25zdCBidWlsdCA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCBwYXJ0aWFsTWFwID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZyB8IG51bGw+KCk7XG4gIGNvbnN0IGNvbGxlY3RQYXJ0aWFscyA9IFBBUlRJQUxfT0tfRU5EUE9JTlRTLmhhcyhjdHguZW5kcG9pbnQpO1xuICBmb3IgKGNvbnN0IHJhdyBvZiByYXdUd2VldHMpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdCA9IGJ1aWxkVHdlZXQocmF3LCBjdHgpO1xuICAgICAgaWYgKCF0KSB7XG4gICAgICAgIGlmIChjb2xsZWN0UGFydGlhbHMpIHtcbiAgICAgICAgICAvLyBPbmx5IGVucXVldWUgcmVhbC10d2VldCBzaGVsbHMgKG5vdCB0b21ic3RvbmVzLCBub3Qgc3RyaXBwZWRcbiAgICAgICAgICAvLyBub2RlcyBsYWNraW5nIGEgbGVnYWN5IGJsb2NrLCBub3QgZ2FyYmFnZSBJRHMpLlxuICAgICAgICAgIGNvbnN0IHBhcnRpYWwgPSBwaWNrUGFydGlhbChyYXcsIGN0eCk7XG4gICAgICAgICAgaWYgKHBhcnRpYWwpIHBhcnRpYWxNYXAuc2V0KHBhcnRpYWwudHdlZXRfaWQsIHBhcnRpYWwuaGludF9oYW5kbGUpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIGJ1aWx0LmFkZCh0LnR3ZWV0X2lkKTtcbiAgICAgIGlmIChjdHguYWxsb3dlZEhhbmRsZXMuc2l6ZSA9PT0gMCB8fCBjdHguYWxsb3dlZEhhbmRsZXMuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgdHdlZXRzLnB1c2godCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBPbmUgYmFkIGVudHJ5IHNob3VsZG4ndCB0YWtlIGRvd24gdGhlIHdob2xlIGJhdGNoLlxuICAgIH1cbiAgfVxuICAvLyBBbnl0aGluZyB0aGF0IGVuZGVkIHVwIGluIHBhcnRpYWxNYXAgYnV0IEFMU08gY2FtZSBiYWNrIGFzIGEgYnVpbHRcbiAgLy8gdHdlZXQgKGRpZmZlcmVudCB3YWxrZXIgcGFzcywgc2FtZSBpZCkgaXNuJ3QgYWN0dWFsbHkgcGFydGlhbC5cbiAgY29uc3QgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcbiAgZm9yIChjb25zdCBbaWQsIGhpbnRdIG9mIHBhcnRpYWxNYXApIHtcbiAgICBpZiAoYnVpbHQuaGFzKGlkKSkgY29udGludWU7XG4gICAgcGFydGlhbF9pZHMucHVzaCh7IHR3ZWV0X2lkOiBpZCwgaGludF9oYW5kbGU6IGhpbnQgfSk7XG4gIH1cbiAgcmV0dXJuIHsgdHdlZXRzLCBvYnNlcnZlZF9pZHM6IG9ic2VydmVkLCBwYXJ0aWFsX2lkcyB9O1xufVxuXG5mdW5jdGlvbiBwaWNrUGFydGlhbChcbiAgbm9kZTogdW5rbm93bixcbiAgY3R4OiBOb3JtYWxpemVDb250ZXh0XG4pOiB7IHR3ZWV0X2lkOiBzdHJpbmc7IGhpbnRfaGFuZGxlOiBzdHJpbmcgfCBudWxsIH0gfCBudWxsIHtcbiAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JyB8fCBub2RlID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIC8vIERlbGV0ZWQgdHdlZXRzIHN1cmZhY2UgYXMgVHdlZXRUb21ic3RvbmUgXHUyMDE0IHRoZXJlJ3Mgbm90aGluZyB0byByZWZldGNoLFxuICAvLyBza2lwIHRoZW0gb3IgdGhlIGNyYXdsIGxvb3Agd2lsbCBzcGluIG9uIFwidGhpcyBwYWdlIGRvZXNuJ3QgZXhpc3RcIi5cbiAgaWYgKG4uX190eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XG4gIC8vIFJlcXVpcmUgYSByZWNvZ25pemVkIFR3ZWV0IHR5cGVuYW1lIE9SIGEgbGVnYWN5IGJsb2NrLiBDdXJzb3JzLCBhZHMsXG4gIC8vIG1vZHVsZSBoZWFkZXJzLCBhbmQgdGhlIGxpa2UgZ2V0IHJlamVjdGVkIGhlcmUuXG4gIGNvbnN0IHRuID0gbi5fX3R5cGVuYW1lO1xuICBpZiAodG4gIT09ICdUd2VldCcgJiYgdG4gIT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgJiYgIW9iaihuLmxlZ2FjeSkpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBjb25zdCByZXN0SWQgPVxuICAgICh0eXBlb2Ygbi5yZXN0X2lkID09PSAnc3RyaW5nJyAmJiBuLnJlc3RfaWQpIHx8XG4gICAgKHR5cGVvZiBvYmoobi50d2VldF9yZXN1bHQpPy5yZXN1bHQgPT09ICdvYmplY3QnICYmXG4gICAgICAob2JqKG9iaihuLnR3ZWV0X3Jlc3VsdCk/LnJlc3VsdCk/LnJlc3RfaWQgYXMgc3RyaW5nKSk7XG4gIGlmICh0eXBlb2YgcmVzdElkICE9PSAnc3RyaW5nJyB8fCAhVFdFRVRfSURfUkUudGVzdChyZXN0SWQpKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHsgdHdlZXRfaWQ6IHJlc3RJZCwgaGludF9oYW5kbGU6IHBpY2tIaW50SGFuZGxlKG5vZGUsIHJlc3RJZCwgY3R4KSB9O1xufVxuXG5mdW5jdGlvbiBwaWNrSGludEhhbmRsZShub2RlOiB1bmtub3duLCB0d2VldElkOiBzdHJpbmcsIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgY29uc3QgdXNlclJlc3VsdCA9IG9iaihvYmoob2JqKG4uY29yZSk/LnVzZXJfcmVzdWx0cyk/LnJlc3VsdCk7XG4gIHJldHVybiAoXG4gICAgc3RyT3JOdWxsKG9iaih1c2VyUmVzdWx0Py5jb3JlKT8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKG9iaih1c2VyUmVzdWx0Py5sZWdhY3kpPy5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwob2JqKG4ubGVnYWN5KT8uc2NyZWVuX25hbWUpID8/XG4gICAgcGlja0hhbmRsZUZyb21Ud2VldFVybHMobm9kZSwgdHdlZXRJZCkgPz9cbiAgICBwaWNrSGFuZGxlRnJvbU1lZGlhUGFnZShjdHguc291cmNlVXJsKVxuICApO1xufVxuXG5mdW5jdGlvbiBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlOiB1bmtub3duLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBjdXIgPSBzdGFjay5wb3AoKTtcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGNvbnN0IGhhbmRsZSA9IGhhbmRsZUZyb21Ud2VldFVybChjdXIsIHR3ZWV0SWQpO1xuICAgICAgaWYgKGhhbmRsZSkgcmV0dXJuIGhhbmRsZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY3VyID09PSBudWxsIHx8IHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAoc2Vlbi5oYXMoY3VyIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBjdXIpIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBoYW5kbGVGcm9tVHdlZXRVcmwocmF3VXJsOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICB0cnkge1xuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmF3VXJsLCBUV0VFVF9VUkxfUFJFRklYKTtcbiAgICBpZiAodXJsLmhvc3RuYW1lICE9PSAneC5jb20nICYmIHVybC5ob3N0bmFtZSAhPT0gJ3R3aXR0ZXIuY29tJykgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC8oW0EtWmEtejAtOV9dezEsMTV9KVxcL3N0YXR1c1xcLyhcXGR7MTUsMjB9KSg/OlxcL3wkKS8pO1xuICAgIGlmICghbWF0Y2ggfHwgbWF0Y2hbMl0gIT09IHR3ZWV0SWQpIHJldHVybiBudWxsO1xuICAgIHJldHVybiBtYXRjaFsxXSA/PyBudWxsO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBwaWNrSGFuZGxlRnJvbU1lZGlhUGFnZShyYXdVcmw6IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKCFyYXdVcmwpIHJldHVybiBudWxsO1xuICB0cnkge1xuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmF3VXJsKTtcbiAgICBpZiAodXJsLmhvc3RuYW1lICE9PSAneC5jb20nICYmIHVybC5ob3N0bmFtZSAhPT0gJ3R3aXR0ZXIuY29tJykgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC8oW0EtWmEtejAtOV9dezEsMTV9KVxcL21lZGlhXFwvPyQvKTtcbiAgICByZXR1cm4gbWF0Y2g/LlsxXSA/PyBudWxsO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBjb2xsZWN0VHdlZXRzKG9iajogdW5rbm93bik6IHVua25vd25bXSB7XG4gIC8vIFdhbGsgdGhlIHJlc3BvbnNlIHRyZWUgZ2F0aGVyaW5nIGV2ZXJ5dGhpbmcgdGhhdCBsb29rcyBsaWtlIGEgdHdlZXRcbiAgLy8gcmVzdWx0LiBXZSBsb29rIGZvciBub2RlcyBzaGFwZWQgbGlrZTpcbiAgLy8gICB7IF9fdHlwZW5hbWU/OiAnVHdlZXQnfCdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycsIHJlc3RfaWQsIGxlZ2FjeSB9XG4gIC8vIGFuZCB1bndyYXAgdmlzaWJpbGl0eSB3cmFwcGVycy5cbiAgY29uc3Qgb3V0OiB1bmtub3duW10gPSBbXTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtvYmpdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG5vZGUgPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobm9kZSA9PT0gbnVsbCB8fCBub2RlID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xuICAgIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmIChzZWVuLmhhcyhub2RlIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKG5vZGUgYXMgb2JqZWN0KTtcblxuICAgIGlmIChsb29rc0xpa2VUd2VldChub2RlKSkge1xuICAgICAgb3V0LnB1c2godW53cmFwVHdlZXQobm9kZSkpO1xuICAgIH1cbiAgICBpZiAoQXJyYXkuaXNBcnJheShub2RlKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG5vZGUpIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBsb29rc0xpa2VUd2VldChub2RlOiB1bmtub3duKTogbm9kZSBpcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgY29uc3QgdHlwZW5hbWUgPSBuLl9fdHlwZW5hbWU7XG4gIGlmIChcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0JyB8fFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnIHx8XG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZSdcbiAgKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgLy8gU29tZSBlbnRyaWVzIGxhY2sgX190eXBlbmFtZSBidXQgc3RpbGwgY2FycnkgbGVnYWN5ICsgcmVzdF9pZCArIGNvcmUuXG4gIHJldHVybiB0eXBlb2Ygbi5yZXN0X2lkID09PSAnc3RyaW5nJyAmJiB0eXBlb2Ygbi5sZWdhY3kgPT09ICdvYmplY3QnICYmIG4ubGVnYWN5ICE9PSBudWxsO1xufVxuXG5mdW5jdGlvbiB1bndyYXBUd2VldChub2RlOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgaWYgKG5vZGUuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiB0eXBlb2Ygbm9kZS50d2VldCA9PT0gJ29iamVjdCcpIHtcbiAgICByZXR1cm4gbm9kZS50d2VldCBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgfVxuICByZXR1cm4gbm9kZTtcbn1cblxuZnVuY3Rpb24gYnVpbGRUd2VldChyYXc6IHVua25vd24sIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IENhbm9uaWNhbFR3ZWV0IHwgbnVsbCB7XG4gIGlmICh0eXBlb2YgcmF3ICE9PSAnb2JqZWN0JyB8fCByYXcgPT09IG51bGwpIHJldHVybiBudWxsO1xuICBjb25zdCB0ID0gcmF3IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuXG4gIGlmICh0Ll9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHJlc3RJZCA9IHN0ck9yTnVsbCh0LnJlc3RfaWQpO1xuICAvLyBgbGVnYWN5YCBpcyBzdGlsbCB3aGVyZSBtb3N0IGVuZ2FnZW1lbnQgLyBlbnRpdGllcyBsaXZlIGluIDIwMjYtZXJhIFhcbiAgLy8gcGF5bG9hZHMsIGJ1dCBhcyBvZiByZWNlbnQgc2NoZW1hIG1pZ3JhdGlvbnMgc2V2ZXJhbCBmaWVsZHMgcHJldmlvdXNseVxuICAvLyB0aGVyZSAobm90YWJseSB0aGUgYXV0aG9yIGhhbmRsZSkgaGF2ZSBtb3ZlZCB0byBzaWJsaW5nIGxvY2F0aW9ucy4gV2VcbiAgLy8gdG9sZXJhdGUgYSBtaXNzaW5nIGxlZ2FjeSBoZXJlIGFuZCBsb29rIHVwIGV2ZXJ5dGhpbmcgdmlhIGZhbGxiYWNrcy5cbiAgY29uc3QgbGVnYWN5ID0gb2JqKHQubGVnYWN5KSA/PyB7fTtcbiAgaWYgKCFyZXN0SWQpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGNvcmUgPSBvYmoodC5jb3JlKTtcbiAgY29uc3QgdXNlclJlc3VsdCA9IG9iaihvYmooY29yZT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgLy8gQXV0aG9yIGhhbmRsZTogdHJ5IHRoZSBuZXcgYGNvcmVgIHN1YnN0cnVjdHVyZSBmaXJzdCAoY3VycmVudCBYIHNoYXBlKSxcbiAgLy8gdGhlbiB0aGUgbGVnYWN5IGBsZWdhY3kuc2NyZWVuX25hbWVgLCB0aGVuIGEgY291cGxlIG9mIG9sZGVyIHZhcmlhbnRzLlxuICBjb25zdCB1c2VyQ29yZU5ldyA9IG9iaih1c2VyUmVzdWx0Py5jb3JlKTtcbiAgY29uc3QgdXNlckxlZ2FjeSA9IG9iaih1c2VyUmVzdWx0Py5sZWdhY3kpO1xuICBjb25zdCB1c2VyQXZhdGFyT2JqID0gb2JqKHVzZXJSZXN1bHQ/LmF2YXRhcik7XG4gIGNvbnN0IGhhbmRsZSA9XG4gICAgc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwodXNlckxlZ2FjeT8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbChsZWdhY3kuc2NyZWVuX25hbWUpO1xuICBjb25zdCBhY2NvdW50SWQgPVxuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5yZXN0X2lkKSA/P1xuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5pZF9zdHIpID8/XG4gICAgc3RyT3JOdWxsKGxlZ2FjeS51c2VyX2lkX3N0cik7XG4gIGlmICghaGFuZGxlIHx8ICFhY2NvdW50SWQpIHJldHVybiBudWxsO1xuICAvLyBBdXRob3Igc25hcHNob3QuIERpc3BsYXkgbmFtZSArIGF2YXRhciBtb3ZlZCBiZXR3ZWVuIGBsZWdhY3lgIGFuZCB0aGVcbiAgLy8gbmV3IGBjb3JlYCBzdWJzdHJ1Y3R1cmUgb3ZlciB0aW1lOyB0aGUgcmVzdCAodmVyaWZpY2F0aW9uLCBmb2xsb3dlclxuICAvLyBjb3VudHMsIGFjY291bnRfY3JlYXRlZF9hdCkgaXMgc3RpbGwgaW4gYGxlZ2FjeWAuIFdlIHNuYXBzaG90IHRoZVxuICAvLyB3aG9sZSBVc2VyU25hcHNob3QgcGVyIHR3ZWV0IGJlY2F1c2UgdGhlc2UgdmFsdWVzIGRyaWZ0IG92ZXIgdGltZVxuICAvLyBhbmQgdGhlIGF0LWNhcHR1cmUgc3RhdGUgaXMgdGhlIG9ubHkgcmVsaWFibGUgcmVjb3JkLlxuICBjb25zdCBhdXRob3IgPSBleHRyYWN0VXNlclNuYXBzaG90KHVzZXJSZXN1bHQsIHVzZXJDb3JlTmV3LCB1c2VyTGVnYWN5LCB1c2VyQXZhdGFyT2JqKTtcblxuICBjb25zdCBub3RlVHdlZXQgPSBvYmoob2JqKG9iaih0Lm5vdGVfdHdlZXQpPy5ub3RlX3R3ZWV0X3Jlc3VsdHMpPy5yZXN1bHQpO1xuICBjb25zdCB0ZXh0RnJvbU5vdGUgPSBzdHJPck51bGwobm90ZVR3ZWV0Py50ZXh0KTtcbiAgY29uc3QgdGV4dEZyb21MZWdhY3kgPSBzdHJPck51bGwobGVnYWN5LmZ1bGxfdGV4dCkgPz8gJyc7XG4gIGNvbnN0IHRleHQgPSB0ZXh0RnJvbU5vdGUgPz8gdGV4dEZyb21MZWdhY3k7XG4gIGNvbnN0IGlzVHJ1bmNhdGVkID0gZGV0ZWN0VHJ1bmNhdGlvbihub3RlVHdlZXQsIGxlZ2FjeSwgdGV4dEZyb21MZWdhY3kpO1xuICBjb25zdCBjb21tdW5pdHlOb3RlID0gZXh0cmFjdENvbW11bml0eU5vdGUodCwgbGVnYWN5LCBjdHguY2FwdHVyZWRBdCk7XG5cbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKSA/PyB7fTtcbiAgY29uc3QgZW50aXRpZXNGcm9tTm90ZSA9IG9iaihub3RlVHdlZXQ/LmVudGl0eV9zZXQpO1xuICBjb25zdCBoYXNodGFncyA9IGV4dHJhY3RIYXNodGFncyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgbWVudGlvbnMgPSBleHRyYWN0TWVudGlvbnMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IHVybHMgPSBleHRyYWN0VXJscyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgbWVkaWEgPSBleHRyYWN0TWVkaWEobGVnYWN5KTtcblxuICBjb25zdCB0d2VldFR5cGUgPSBjbGFzc2lmeVR3ZWV0VHlwZSh0LCBsZWdhY3kpO1xuXG4gIC8vIHBvc3RlZF9hdDogbGVnYWN5LmNyZWF0ZWRfYXQgcmVtYWlucyB0aGUgY2Fub25pY2FsIGxvY2F0aW9uOyBpZiB0aGF0J3NcbiAgLy8gbWlzc2luZyBpbiBhIGZ1dHVyZSBzY2hlbWEgd2UgZmFsbCBiYWNrIHRvIHRvcC1sZXZlbCBjcmVhdGVkX2F0LlxuICBjb25zdCBwb3N0ZWRBdCA9XG4gICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwobGVnYWN5LmNyZWF0ZWRfYXQpKSA/PyBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh0LmNyZWF0ZWRfYXQpKTtcbiAgaWYgKCFwb3N0ZWRBdCkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3Qgdmlld3MgPSBvYmoodC52aWV3cyk7XG4gIGNvbnN0IHZpZXdDb3VudCA9IG51bU9yTnVsbCh2aWV3cz8uY291bnQpID8/IG51bU9yTnVsbChzdHJPck51bGwodmlld3M/LmNvdW50KSk7XG5cbiAgY29uc3QgY2FyZCA9IGV4dHJhY3RDYXJkKHQpO1xuICBjb25zdCBwbGFjZSA9IG9iaihsZWdhY3kucGxhY2UpO1xuXG4gIGNvbnN0IHR3ZWV0OiBDYW5vbmljYWxUd2VldCA9IHtcbiAgICB0d2VldF9pZDogcmVzdElkLFxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgYWNjb3VudF9pZDogYWNjb3VudElkLFxuICAgIHBvc3RlZF9hdDogcG9zdGVkQXQsXG4gICAgZmlyc3RfY2FwdHVyZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxuICAgIGxhc3Rfc2Vlbl9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgZGVsZXRpb25fZGV0ZWN0ZWRfYXQ6IG51bGwsXG4gICAgdHdlZXRfdXJsOiBgJHtUV0VFVF9VUkxfUFJFRklYfS8ke2hhbmRsZX0vc3RhdHVzLyR7cmVzdElkfWAsXG4gICAgdHdlZXRfdHlwZTogdHdlZXRUeXBlLFxuICAgIGNvbnZlcnNhdGlvbl9pZDogc3RyT3JOdWxsKGxlZ2FjeS5jb252ZXJzYXRpb25faWRfc3RyKSxcbiAgICByZXBseV90b190d2VldF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zdGF0dXNfaWRfc3RyKSxcbiAgICByZXBseV90b19hY2NvdW50OiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3NjcmVlbl9uYW1lKSxcbiAgICByZXBseV90b19hY2NvdW50X2lkOiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3VzZXJfaWRfc3RyKSxcbiAgICBxdW90ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChsZWdhY3kucXVvdGVkX3N0YXR1c19pZF9zdHIpLFxuICAgIHJldHdlZXRlZF90d2VldF9pZDogc3RyT3JOdWxsKFxuICAgICAgb2JqKG9iaihsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQpPy5yZXN1bHQpPy5yZXN0X2lkID8/XG4gICAgICAgIChsZWdhY3kgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLnJldHdlZXRlZF9zdGF0dXNfaWRfc3RyXG4gICAgKSxcbiAgICB0ZXh0LFxuICAgIHRleHRfcmVzb2x2ZWQ6IHJlc29sdmVTaG9ydFVybHModGV4dCwgdXJscyksXG4gICAgbGFuZzogc3RyT3JOdWxsKGxlZ2FjeS5sYW5nKSxcbiAgICBwb3NzaWJseV9zZW5zaXRpdmU6IGJvb2xPck51bGwobGVnYWN5LnBvc3NpYmx5X3NlbnNpdGl2ZSksXG4gICAgc291cmNlOiBzdHJPck51bGwobGVnYWN5LnNvdXJjZSkgPz8gc3RyT3JOdWxsKHQuc291cmNlKSxcbiAgICBwbGFjZV9mdWxsX25hbWU6IHN0ck9yTnVsbChwbGFjZT8uZnVsbF9uYW1lKSxcbiAgICBoYXNodGFncyxcbiAgICBtZW50aW9ucyxcbiAgICB1cmxzLFxuICAgIGNhcmQsXG4gICAgbWVkaWEsXG4gICAgbGlrZV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5mYXZvcml0ZV9jb3VudCksXG4gICAgcmV0d2VldF9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcbiAgICByZXBseV9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXBseV9jb3VudCksXG4gICAgcXVvdGVfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucXVvdGVfY291bnQpLFxuICAgIHZpZXdfY291bnQ6IHZpZXdDb3VudCxcbiAgICBib29rbWFya19jb3VudDogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXG4gICAgZW5nYWdlbWVudF9oaXN0b3J5OiBbXG4gICAgICB7XG4gICAgICAgIGNhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICAgICAgbGlrZXM6IG51bU9yWmVybyhsZWdhY3kuZmF2b3JpdGVfY291bnQpLFxuICAgICAgICByZXR3ZWV0czogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcbiAgICAgICAgcmVwbGllczogbnVtT3JaZXJvKGxlZ2FjeS5yZXBseV9jb3VudCksXG4gICAgICAgIHF1b3RlczogbnVtT3JaZXJvKGxlZ2FjeS5xdW90ZV9jb3VudCksXG4gICAgICAgIHZpZXdzOiB2aWV3Q291bnQsXG4gICAgICAgIGJvb2ttYXJrczogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXG4gICAgICB9LFxuICAgIF0sXG4gICAgYXV0aG9yLFxuICAgIGNvbW11bml0eV9ub3RlOiBjb21tdW5pdHlOb3RlLFxuICAgIGlzX3RydW5jYXRlZDogaXNUcnVuY2F0ZWQsXG4gICAgd2F5YmFja191cmw6IG51bGwsXG4gICAgd2F5YmFja19zdWJtaXR0ZWRfYXQ6IG51bGwsXG4gICAgY2FwdHVyZV9zb3VyY2U6ICdleHRlbnNpb24nLFxuICAgIGNhcHR1cmVfcnVuX2lkOiBjdHgucnVuSWQsXG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gIH07XG5cbiAgcmV0dXJuIHR3ZWV0O1xufVxuXG5mdW5jdGlvbiBjbGFzc2lmeVR3ZWV0VHlwZSh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFR3ZWV0VHlwZSB7XG4gIGlmIChsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQgfHwgbGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JldHdlZXQnO1xuICBpZiAobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpIHJldHVybiAncmVwbHknO1xuICBpZiAobGVnYWN5LmlzX3F1b3RlX3N0YXR1cyA9PT0gdHJ1ZSB8fCBsZWdhY3kucXVvdGVkX3N0YXR1c19pZF9zdHIpIHJldHVybiAncXVvdGUnO1xuICBpZiAodC5fX3R5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnKSB7XG4gICAgLy8gcGFzcyB0aHJvdWdoXG4gIH1cbiAgcmV0dXJuICdvcmlnaW5hbCc7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RIYXNodGFncyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLmhhc2h0YWdzO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICByZXR1cm4gYXJyXG4gICAgLm1hcCgoaCkgPT5cbiAgICAgIHR5cGVvZiBoID09PSAnb2JqZWN0JyAmJiBoICYmICd0ZXh0JyBpbiBoID8gU3RyaW5nKChoIGFzIHsgdGV4dDogdW5rbm93biB9KS50ZXh0KSA6IG51bGxcbiAgICApXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0TWVudGlvbnMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy51c2VyX21lbnRpb25zO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICByZXR1cm4gYXJyXG4gICAgLm1hcCgodSkgPT5cbiAgICAgIHR5cGVvZiB1ID09PSAnb2JqZWN0JyAmJiB1ICYmICdzY3JlZW5fbmFtZScgaW4gdVxuICAgICAgICA/IFN0cmluZygodSBhcyB7IHNjcmVlbl9uYW1lOiB1bmtub3duIH0pLnNjcmVlbl9uYW1lKVxuICAgICAgICA6IG51bGxcbiAgICApXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0VXJscyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBVcmxFbnRpdHlbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLnVybHM7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XG4gIGNvbnN0IG91dDogVXJsRW50aXR5W10gPSBbXTtcbiAgZm9yIChjb25zdCB1IG9mIGFycikge1xuICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XG4gICAgY29uc3QgbyA9IHUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgY29uc3Qgc2hvcnQgPSBzdHJPck51bGwoby51cmwpO1xuICAgIGNvbnN0IGV4cGFuZGVkID0gc3RyT3JOdWxsKG8uZXhwYW5kZWRfdXJsKTtcbiAgICBjb25zdCBkaXNwbGF5ID0gc3RyT3JOdWxsKG8uZGlzcGxheV91cmwpO1xuICAgIGlmICghc2hvcnQgfHwgIWV4cGFuZGVkKSBjb250aW51ZTtcbiAgICBvdXQucHVzaCh7IHNob3J0LCBleHBhbmRlZCwgZGlzcGxheTogZGlzcGxheSA/PyBleHBhbmRlZCB9KTtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBleHRyYWN0TWVkaWEobGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbVtdIHtcbiAgY29uc3QgZXh0ZW5kZWQgPSBvYmoobGVnYWN5LmV4dGVuZGVkX2VudGl0aWVzKTtcbiAgY29uc3QgZnJvbUV4dCA9IGV4dGVuZGVkID8gdG9BcnJheShleHRlbmRlZC5tZWRpYSkgOiBbXTtcbiAgY29uc3QgZnJvbUVudCA9IHRvQXJyYXkob2JqKGxlZ2FjeS5lbnRpdGllcyk/Lm1lZGlhKTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCBtZXJnZWQgPSBbLi4uZnJvbUV4dCwgLi4uZnJvbUVudF0uZmlsdGVyKChtKSA9PiB7XG4gICAgaWYgKHR5cGVvZiBtICE9PSAnb2JqZWN0JyB8fCBtID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgaWQgPVxuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5tZWRpYV9rZXkpID8/XG4gICAgICBzdHJPck51bGwoKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLmlkX3N0cik7XG4gICAgaWYgKCFpZCkgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChzZWVuLmhhcyhpZCkpIHJldHVybiBmYWxzZTtcbiAgICBzZWVuLmFkZChpZCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuICByZXR1cm4gbWVyZ2VkLm1hcCgocmF3KSA9PiBidWlsZE1lZGlhKHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpO1xufVxuXG5mdW5jdGlvbiBidWlsZE1lZGlhKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogTWVkaWFJdGVtIHtcbiAgY29uc3QgdHlwZSA9IHN0ck9yTnVsbChtLnR5cGUpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddO1xuICBjb25zdCBvcmlnaW5hbCA9IHBpY2tPcmlnaW5hbFVybChtLCB0eXBlKTtcbiAgY29uc3QgaW5mbyA9IG9iaihtLm9yaWdpbmFsX2luZm8pO1xuICBjb25zdCB2aWRlb0luZm8gPSBvYmoobS52aWRlb19pbmZvKTtcbiAgY29uc3QgZHVyYXRpb25NcyA9IG51bU9yTnVsbCh2aWRlb0luZm8/LmR1cmF0aW9uX21pbGxpcyk7XG4gIGNvbnN0IGFsdFRleHQgPSBzdHJPck51bGwobS5leHRfYWx0X3RleHQpO1xuICBjb25zdCBtZWRpYUlkID1cbiAgICBzdHJPck51bGwobS5tZWRpYV9rZXkpID8/XG4gICAgc3RyT3JOdWxsKG0uaWRfc3RyKSA/P1xuICAgIGAke3R5cGUgPz8gJ21lZGlhJ30tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKX1gO1xuICByZXR1cm4ge1xuICAgIG1lZGlhX2lkOiBtZWRpYUlkLFxuICAgIG1lZGlhX3R5cGU6ICh0eXBlID8/ICdwaG90bycpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddLFxuICAgIG9yaWdpbmFsX3VybDogb3JpZ2luYWwgPz8gJycsXG4gICAgcmVsZWFzZV9hc3NldF91cmw6IG51bGwsXG4gICAgc2hhMjU2OiBudWxsLFxuICAgIGJ5dGVzOiBudWxsLFxuICAgIGR1cmF0aW9uX3NlYzogZHVyYXRpb25NcyAhPT0gbnVsbCA/IGR1cmF0aW9uTXMgLyAxMDAwIDogbnVsbCxcbiAgICB3aWR0aDogbnVtT3JOdWxsKGluZm8/LndpZHRoKSxcbiAgICBoZWlnaHQ6IG51bU9yTnVsbChpbmZvPy5oZWlnaHQpLFxuICAgIGFsdF90ZXh0OiBhbHRUZXh0LFxuICAgIGFyY2hpdmVfc3RhdHVzOiAncGVuZGluZycsXG4gICAgYXJjaGl2ZV9hdHRlbXB0czogMCxcbiAgICBsYXN0X2F0dGVtcHRfYXQ6IG51bGwsXG4gIH07XG59XG5cbmZ1bmN0aW9uIHBpY2tPcmlnaW5hbFVybChtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdHlwZTogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAodHlwZSA9PT0gJ3Bob3RvJykgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcykgPz8gc3RyT3JOdWxsKG0ubWVkaWFfdXJsKTtcbiAgY29uc3QgdmFyaWFudHMgPSB0b0FycmF5KG9iaihtLnZpZGVvX2luZm8pPy52YXJpYW50cykgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj5bXTtcbiAgaWYgKHZhcmlhbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcyk7XG4gIC8vIEhpZ2hlc3QtYml0cmF0ZSBtcDQuXG4gIGxldCBiZXN0OiB7IHVybDogc3RyaW5nOyBiaXRyYXRlOiBudW1iZXIgfSB8IG51bGwgPSBudWxsO1xuICBmb3IgKGNvbnN0IHYgb2YgdmFyaWFudHMpIHtcbiAgICBjb25zdCBjdCA9IHN0ck9yTnVsbCh2LmNvbnRlbnRfdHlwZSk7XG4gICAgY29uc3QgdXJsID0gc3RyT3JOdWxsKHYudXJsKTtcbiAgICBpZiAoIXVybCkgY29udGludWU7XG4gICAgaWYgKGN0ID09PSAndmlkZW8vbXA0Jykge1xuICAgICAgY29uc3QgYnIgPSBudW1Pck51bGwodi5iaXRyYXRlKSA/PyAwO1xuICAgICAgaWYgKCFiZXN0IHx8IGJyID4gYmVzdC5iaXRyYXRlKSBiZXN0ID0geyB1cmwsIGJpdHJhdGU6IGJyIH07XG4gICAgfSBlbHNlIGlmICghYmVzdCkge1xuICAgICAgLy8gRmFsbGJhY2sgdG8gYW55IHZhcmlhbnQgaWYgbm8gbXA0IGZvdW5kLlxuICAgICAgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiAwIH07XG4gICAgfVxuICB9XG4gIHJldHVybiBiZXN0Py51cmwgPz8gbnVsbDtcbn1cblxuZnVuY3Rpb24gcmVzb2x2ZVNob3J0VXJscyh0ZXh0OiBzdHJpbmcsIHVybHM6IFVybEVudGl0eVtdKTogc3RyaW5nIHtcbiAgaWYgKHVybHMubGVuZ3RoID09PSAwKSByZXR1cm4gdGV4dDtcbiAgbGV0IG91dCA9IHRleHQ7XG4gIGZvciAoY29uc3QgdSBvZiB1cmxzKSBvdXQgPSBvdXQuc3BsaXQodS5zaG9ydCkuam9pbih1LmV4cGFuZGVkKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gcGFyc2VUd2l0dGVyRGF0ZShzOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICghcykgcmV0dXJuIG51bGw7XG4gIC8vIFR3aXR0ZXIgc2hpcHMgZGF0ZXMgbGlrZSBcIk1vbiBBcHIgMTIgMTQ6MjM6MDEgKzAwMDAgMjAyNVwiLlxuICBjb25zdCBkID0gbmV3IERhdGUocyk7XG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIGQudG9JU09TdHJpbmcoKTtcbn1cblxuZnVuY3Rpb24gc3RyT3JOdWxsKHY6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDAgPyB2IDogbnVsbDtcbn1cbmZ1bmN0aW9uIGJvb2xPck51bGwodjogdW5rbm93bik6IGJvb2xlYW4gfCBudWxsIHtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnYm9vbGVhbicgPyB2IDogbnVsbDtcbn1cbmZ1bmN0aW9uIG51bU9yTnVsbCh2OiB1bmtub3duKTogbnVtYmVyIHwgbnVsbCB7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ251bWJlcicgJiYgTnVtYmVyLmlzRmluaXRlKHYpKSByZXR1cm4gdjtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gTnVtYmVyKHYpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikpIHJldHVybiBuO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gbnVtT3JaZXJvKHY6IHVua25vd24pOiBudW1iZXIge1xuICByZXR1cm4gbnVtT3JOdWxsKHYpID8/IDA7XG59XG5mdW5jdGlvbiBvYmoodjogdW5rbm93bik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ29iamVjdCcgJiYgdiAhPT0gbnVsbCAmJiAhQXJyYXkuaXNBcnJheSh2KVxuICAgID8gKHYgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pXG4gICAgOiBudWxsO1xufVxuZnVuY3Rpb24gdG9BcnJheSh2OiB1bmtub3duKTogdW5rbm93bltdIHtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkodikgPyB2IDogW107XG59XG5cbi8qKlxuICogRGVjaWRlIHdoZXRoZXIgYSB0d2VldCdzIGFyY2hpdmVkIGB0ZXh0YCBpcyB0aGUgdHJ1bmNhdGVkIGhlYWQgb2YgYSBsb25nZXJcbiAqIGJvZHkuIEEgdHJ1bmNhdGVkIHR3ZWV0IGhhcyBYJ3MgXCJTaG93IG1vcmVcIiB0LmNvIFVSTCBhcHBlbmRlZCBcdTIwMTQgdGhhdCBVUkxcbiAqIHNwZWNpZmljYWxseSBleHBhbmRzIHRvIHRoZSB0d2VldCdzIG93biAvaS93ZWIvc3RhdHVzLzxpZD4gcGVybWFsaW5rLCBhbmRcbiAqIGlzIHRoZSBvbmx5IHJlbGlhYmxlIGRpc3Rpbmd1aXNoaW5nIGZlYXR1cmUuIFBsZW50eSBvZiBub3JtYWwgdHdlZXRzIGhhdmVcbiAqIHRyYWlsaW5nIHQuY28gVVJMcyAobWVkaWEsIHF1b3RlcywgcmVndWxhciBsaW5rcyksIGFuZCB0aGVpclxuICogZGlzcGxheV90ZXh0X3JhbmdlIGFsc28gdHJpbXMgcGFzdCBmdWxsX3RleHQubGVuZ3RoLCBzbyB0aGUgb2xkXG4gKiBcImRpc3BsYXlfdGV4dF9yYW5nZVsxXSA8IGZ1bGxfdGV4dC5sZW5ndGhcIiBoZXVyaXN0aWMgd2FzIG92ZXJmbGFnZ2luZ1xuICogZXNzZW50aWFsbHkgZXZlcnkgdHdlZXQgd2l0aCBhIGxpbmsgaW4gaXQuXG4gKlxuICogUnVsZXM6XG4gKiAgIC0gbm90ZV90d2VldCBwcmVzZW50ICBcdTIxOTIgbm90IHRydW5jYXRlZCAod2UgYWxyZWFkeSBoYXZlIHRoZSBmdWxsIGJvZHkpLlxuICogICAtIE9uZSBvZiBsZWdhY3kuZW50aXRpZXMudXJscyBoYXMgYW4gZXhwYW5kZWRfdXJsIGxpa2VcbiAqICAgICBcIi4uLi9pL3dlYi9zdGF0dXMvPGlkPlwiICBcdTIxOTIgIHRydW5jYXRlZC5cbiAqICAgLSBPdGhlcndpc2UgXHUyMTkyIG5vdCB0cnVuY2F0ZWQuXG4gKlxuICogVGhlIHByZXZpb3VzIGZhbGxiYWNrIChcInRyYWlsaW5nIHQuY28gVVJMICsgbGVuZ3RoIFx1MjI2NSAyNzBcIikgZmxhZ2dlZCBldmVyeVxuICogbWVkaWEgdHdlZXQgZXhhY3RseSBhdCB0aGUgMjgwLWNoYXIgbGltaXQuIFdlIGRyb3AgaXQgZW50aXJlbHk7IHRoZSBvbmx5XG4gKiBjb3N0IGlzIG1pc3NpbmcgZ2VudWluZWx5LXRydW5jYXRlZCB0d2VldHMgd2hvc2UgcGF5bG9hZCB3YXMgc28gZGVncmFkZWRcbiAqIGl0IGxhY2tlZCBlbnRpdGllcyBcdTIwMTQgd2hpY2ggaXMgYWxzbyB3aGVyZSB0aGUgcmVmZXRjaCBsb29wIHdvdWxkIGZhaWxcbiAqIGFueXdheSwgc28gbm90aGluZyBpcyBhY3R1YWxseSBsb3N0LlxuICovXG5mdW5jdGlvbiBkZXRlY3RUcnVuY2F0aW9uKFxuICBub3RlVHdlZXQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAgZnVsbFRleHQ6IHN0cmluZ1xuKTogYm9vbGVhbiB7XG4gIGlmIChub3RlVHdlZXQpIHJldHVybiBmYWxzZTtcbiAgaWYgKCFmdWxsVGV4dCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBlbnRpdGllcyA9IG9iaihsZWdhY3kuZW50aXRpZXMpO1xuICBjb25zdCB1cmxzID0gZW50aXRpZXMgPyBlbnRpdGllcy51cmxzIDogbnVsbDtcbiAgaWYgKEFycmF5LmlzQXJyYXkodXJscykpIHtcbiAgICBmb3IgKGNvbnN0IHUgb2YgdXJscykge1xuICAgICAgaWYgKHR5cGVvZiB1ICE9PSAnb2JqZWN0JyB8fCB1ID09PSBudWxsKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IGV4cCA9ICh1IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5leHBhbmRlZF91cmw7XG4gICAgICAvLyBUaGUgXCJTaG93IG1vcmVcIiBsaW5rIGV4cGFuZHMgdG8gZWl0aGVyIG9mIHRoZXNlIHNlbGYtcGVybWFsaW5rXG4gICAgICAvLyBzaGFwZXM6ICBodHRwczovL3guY29tL2kvd2ViL3N0YXR1cy88aWQ+XG4gICAgICAvLyAgICAgICAgICBodHRwczovL3R3aXR0ZXIuY29tL2kvd2ViL3N0YXR1cy88aWQ+XG4gICAgICBpZiAodHlwZW9mIGV4cCA9PT0gJ3N0cmluZycgJiYgL1xcL2lcXC93ZWJcXC9zdGF0dXNcXC9cXGQrLy50ZXN0KGV4cCkpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuLyoqXG4gKiBGaWx0ZXIgYHR3ZWV0c2AgZG93biB0byB0aG9zZSByZWxhdGVkIHRvIGEgdHJhY2tlZCBhY2NvdW50LiBBIHR3ZWV0IGlzXG4gKiBcInJlbGF0ZWRcIiBpZiBhbnkgb2YgdGhlIGZvbGxvd2luZyBob2xkOlxuICpcbiAqICAgLSBpdHMgYXV0aG9yIGlzIHRyYWNrZWQgKGhhbmRsZSBpbiBgdGFyZ2V0ZWRgKSxcbiAqICAgLSBpdCBtZW50aW9ucyBhIHRyYWNrZWQgaGFuZGxlLFxuICogICAtIGl0IHJlcGxpZXMgdG8gYSB0cmFja2VkIGFjY291bnQsXG4gKiAgIC0gaXQgcXVvdGVzL3JldHdlZXRzL3JlcGxpZXMtdG8gYSB0d2VldCB0aGF0J3MgYWxzbyBwcmVzZW50IGluIHRoZVxuICogICAgIGJhdGNoICphbmQqIGF1dGhvcmVkIGJ5IGEgdHJhY2tlZCBhY2NvdW50ICh0cmFuc2l0aXZlbHkgcmVsYXRlZCBcdTIwMTRcbiAqICAgICBjYXB0dXJlcyB0aGUgcXVvdGVkL1JUJ2QgY29udGVudCB0aGF0IGFwcGVhcnMgYXMgYSBzaWJsaW5nIG5vZGUgaW5cbiAqICAgICB0aGUgc2FtZSBHcmFwaFFMIHJlc3BvbnNlKS5cbiAqXG4gKiBBbnl0aGluZyBlbHNlIChyYW5kb20gcmVwbGllcyB1bmRlciBhIHRyYWNrZWQgYWNjb3VudCdzIHR3ZWV0LCByYW5kb21cbiAqIGF1dGhvcnMgdGhhdCBoYXBwZW4gdG8gc3VyZmFjZSBpbiBhIHRyYWNrZWQgYWNjb3VudCdzIHRocmVhZCkgaXMgZHJvcHBlZC5cbiAqIFBhc3MgYW4gZW1wdHkgYHRhcmdldGVkYCBzZXQgdG8gZGlzYWJsZSBmaWx0ZXJpbmcgZW50aXJlbHkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmaWx0ZXJSZWxhdGVkKFxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10sXG4gIHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+XG4pOiBDYW5vbmljYWxUd2VldFtdIHtcbiAgaWYgKHRhcmdldGVkLnNpemUgPT09IDApIHJldHVybiB0d2VldHM7XG4gIC8vIEZpcnN0IHBhc3M6IHdoaWNoIHR3ZWV0IElEcyBkbyB0cmFja2VkLWF1dGhvciB0d2VldHMgcmVmZXJlbmNlICh0aGVcbiAgLy8gXCJmb3J3YXJkXCIgZGlyZWN0aW9uIFx1MjAxNCB0cmFja2VkIGFjY291bnQgcXVvdGVzIC8gUlRzIC8gcmVwbGllcyB0byBYKT9cbiAgLy8gQW5kIHdoaWNoIHR3ZWV0IElEcyBBUkUgdHJhY2tlZC1hdXRob3JlZCAodGhlIFwicmV2ZXJzZVwiIGRpcmVjdGlvbiBcdTIwMTRcbiAgLy8gWCBxdW90ZXMgLyBSVHMgLyByZXBsaWVzIHRvIGEgdHJhY2tlZCB0d2VldCk/XG4gIGNvbnN0IHJlZmVyZW5jZWRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgdGFyZ2V0ZWRUd2VldElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgaWYgKCF0YXJnZXRlZC5oYXModC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpKSkgY29udGludWU7XG4gICAgdGFyZ2V0ZWRUd2VldElkcy5hZGQodC50d2VldF9pZCk7XG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnF1b3RlZF90d2VldF9pZCk7XG4gICAgaWYgKHQucmV0d2VldGVkX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnJldHdlZXRlZF90d2VldF9pZCk7XG4gICAgaWYgKHQucmVwbHlfdG9fdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucmVwbHlfdG9fdHdlZXRfaWQpO1xuICB9XG4gIHJldHVybiB0d2VldHMuZmlsdGVyKCh0KSA9PiB7XG4gICAgY29uc3QgaCA9IHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAodGFyZ2V0ZWQuaGFzKGgpKSByZXR1cm4gdHJ1ZTtcbiAgICAvLyBGb3J3YXJkOiBhIHRyYWNrZWQtYXV0aG9yIHR3ZWV0IHBvaW50ZWQgYXQgdGhpcyBvbmUuXG4gICAgaWYgKHJlZmVyZW5jZWRJZHMuaGFzKHQudHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcbiAgICAvLyBSZXZlcnNlOiB0aGlzIHR3ZWV0IHBvaW50cyBhdCBhIHRyYWNrZWQtYXV0aG9yIHR3ZWV0IGluIHRoZSBiYXRjaC5cbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQgJiYgdGFyZ2V0ZWRUd2VldElkcy5oYXModC5xdW90ZWRfdHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcbiAgICBpZiAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQgJiYgdGFyZ2V0ZWRUd2VldElkcy5oYXModC5yZXR3ZWV0ZWRfdHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCAmJiB0YXJnZXRlZFR3ZWV0SWRzLmhhcyh0LnJlcGx5X3RvX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gUmVwbHktdG8tYWNjb3VudCBvciBtZW50aW9ucyBhIHRyYWNrZWQgaGFuZGxlLlxuICAgIGlmICh0LnJlcGx5X3RvX2FjY291bnQgJiYgdGFyZ2V0ZWQuaGFzKHQucmVwbHlfdG9fYWNjb3VudC50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIHRydWU7XG4gICAgZm9yIChjb25zdCBtIG9mIHQubWVudGlvbnMpIHtcbiAgICAgIGlmICh0YXJnZXRlZC5oYXMobS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfSk7XG59XG5cbi8qKlxuICogUHVsbCB0aGUgQ29tbXVuaXR5IE5vdGUgKGZvcm1lcmx5IEJpcmR3YXRjaCkgYmxvY2sgYXR0YWNoZWQgdG8gYSB0d2VldCwgaWZcbiAqIGFueS4gVGhlIHBpdm90IGNhbiBsaXZlIGF0IGB0d2VldC5sZWdhY3kuYmlyZHdhdGNoX3Bpdm90YCAob2xkZXIgc2hhcGUpIG9yXG4gKiBgdHdlZXQuYmlyZHdhdGNoX3Bpdm90YCAoY3VycmVudCBzaGFwZSkuIFRoZSBzdW1tYXJ5IHRleHQgaXMgd2hhdCByZWFkZXJzXG4gKiBhY3R1YWxseSBzZWU7IHdlIGtlZXAgdGhlIHN1cnJvdW5kaW5nIG1ldGFkYXRhIHNvIGRvd25zdHJlYW0gdG9vbGluZyBjYW5cbiAqIHRlbGwgZHJhZnRzIGFwYXJ0IGZyb20gcmF0ZWQtaGVscGZ1bCBub3Rlcy5cbiAqL1xuZnVuY3Rpb24gZXh0cmFjdENvbW11bml0eU5vdGUoXG4gIHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICBvYnNlcnZlZEF0OiBzdHJpbmdcbik6IENvbW11bml0eU5vdGUgfCBudWxsIHtcbiAgY29uc3QgcGl2b3QgPSBvYmoodC5iaXJkd2F0Y2hfcGl2b3QpID8/IG9iaihsZWdhY3kuYmlyZHdhdGNoX3Bpdm90KTtcbiAgaWYgKCFwaXZvdCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHN1YnRpdGxlID0gb2JqKHBpdm90LnN1YnRpdGxlKTtcbiAgY29uc3Qgbm90ZSA9IG9iaihwaXZvdC5ub3RlKTtcbiAgY29uc3Qgc3VtbWFyeSA9IHN0ck9yTnVsbChzdWJ0aXRsZT8udGV4dCk7XG4gIGNvbnN0IHRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnRpdGxlKTtcbiAgY29uc3Qgc2hvcnRUaXRsZSA9IHN0ck9yTnVsbChwaXZvdC5zaG9ydFRpdGxlKTtcbiAgY29uc3QgZGVzdGluYXRpb25VcmwgPSBzdHJPck51bGwocGl2b3QuZGVzdGluYXRpb25VcmwpO1xuICBjb25zdCBub3RlSWQgPSBzdHJPck51bGwocGl2b3Qubm90ZUlkKSA/PyBzdHJPck51bGwobm90ZT8ucmVzdF9pZCk7XG4gIC8vIFNraXAgZW1wdHkgc2hlbGxzIHRoYXQgaGF2ZSBubyBhY3R1YWwgY29udGVudC5cbiAgaWYgKCFzdW1tYXJ5ICYmICF0aXRsZSAmJiAhbm90ZUlkKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHtcbiAgICBub3RlX2lkOiBub3RlSWQsXG4gICAgdGl0bGUsXG4gICAgc2hvcnRfdGl0bGU6IHNob3J0VGl0bGUsXG4gICAgc3VtbWFyeSxcbiAgICBkZXN0aW5hdGlvbl91cmw6IGRlc3RpbmF0aW9uVXJsLFxuICAgIG9ic2VydmVkX2F0OiBvYnNlcnZlZEF0LFxuICB9O1xufVxuXG4vKipcbiAqIFB1bGwgYSBwZXItYXV0aG9yIFVzZXJTbmFwc2hvdCBmcm9tIHRoZSB0d2VldCdzIHVzZXJfcmVzdWx0cyBub2RlLiBFdmVyeVxuICogZmllbGQgZGVmYXVsdHMgdG8gbnVsbCB3aGVuIG1pc3Npbmcgc28gdGhlIHNjaGVtYSBzdGF5cyBzdGFibGUgYWNyb3NzXG4gKiB0aGUgbGVnYWN5IC8gY29yZSBzaGFwZSBtaWdyYXRpb25zIFggaGFzIGJlZW4gZG9pbmcuXG4gKi9cbmZ1bmN0aW9uIGV4dHJhY3RVc2VyU25hcHNob3QoXG4gIHVzZXJSZXN1bHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgdXNlckNvcmVOZXc6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgdXNlckxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxuICB1c2VyQXZhdGFyT2JqOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGxcbik6IFVzZXJTbmFwc2hvdCB7XG4gIGNvbnN0IHZlcmlmaWNhdGlvbiA9IG9iaih1c2VyUmVzdWx0Py52ZXJpZmljYXRpb24pO1xuICByZXR1cm4ge1xuICAgIGRpc3BsYXlfbmFtZTpcbiAgICAgIHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8ubmFtZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/Lm5hbWUpID8/IHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5uYW1lKSxcbiAgICBhdmF0YXJfdXJsOlxuICAgICAgc3RyT3JOdWxsKHVzZXJBdmF0YXJPYmo/LmltYWdlX3VybCkgPz9cbiAgICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5wcm9maWxlX2ltYWdlX3VybF9odHRwcykgPz9cbiAgICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5wcm9maWxlX2ltYWdlX3VybF9odHRwcyksXG4gICAgdmVyaWZpZWQ6IGJvb2xPck51bGwodmVyaWZpY2F0aW9uPy52ZXJpZmllZCkgPz8gYm9vbE9yTnVsbCh1c2VyTGVnYWN5Py52ZXJpZmllZCksXG4gICAgaXNfYmx1ZV92ZXJpZmllZDogYm9vbE9yTnVsbCh1c2VyUmVzdWx0Py5pc19ibHVlX3ZlcmlmaWVkKSxcbiAgICB2ZXJpZmllZF90eXBlOiBzdHJPck51bGwodmVyaWZpY2F0aW9uPy52ZXJpZmllZF90eXBlKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8udmVyaWZpZWRfdHlwZSksXG4gICAgZGVzY3JpcHRpb246IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5kZXNjcmlwdGlvbiksXG4gICAgbG9jYXRpb246IHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubG9jYXRpb24pPy5sb2NhdGlvbikgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmxvY2F0aW9uKSxcbiAgICB1cmw6IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py51cmwpLFxuICAgIGZvbGxvd2Vyc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZvbGxvd2Vyc19jb3VudCksXG4gICAgZnJpZW5kc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZyaWVuZHNfY291bnQpLFxuICAgIHN0YXR1c2VzX2NvdW50OiBudW1Pck51bGwodXNlckxlZ2FjeT8uc3RhdHVzZXNfY291bnQpLFxuICAgIGFjY291bnRfY3JlYXRlZF9hdDpcbiAgICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5jcmVhdGVkX2F0KSkgPz9cbiAgICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmNyZWF0ZWRfYXQpKSxcbiAgICBwcm90ZWN0ZWQ6IGJvb2xPck51bGwodXNlckxlZ2FjeT8ucHJvdGVjdGVkKSxcbiAgfTtcbn1cblxuLyoqXG4gKiBXYWxrIHRoZSB0d2VldCdzIGBjYXJkLmxlZ2FjeS5iaW5kaW5nX3ZhbHVlc2AgKGtleS92YWx1ZSBhcnJheSkgaW50byBhXG4gKiBmbGF0IFR3ZWV0Q2FyZCB3aXRoIHRpdGxlLCBkZXNjcmlwdGlvbiwgYW5kIGEgcmVwcmVzZW50YXRpdmUgaW1hZ2UgVVJMLlxuICogUmV0dXJucyBudWxsIHdoZW4gdGhlIHR3ZWV0IGhhcyBubyBjYXJkLlxuICovXG5mdW5jdGlvbiBleHRyYWN0Q2FyZCh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFR3ZWV0Q2FyZCB8IG51bGwge1xuICBjb25zdCBjYXJkID0gb2JqKHQuY2FyZCk7XG4gIGNvbnN0IGNhcmRMZWdhY3kgPSBvYmooY2FyZD8ubGVnYWN5KTtcbiAgaWYgKCFjYXJkTGVnYWN5KSByZXR1cm4gbnVsbDtcbiAgY29uc3QgYmluZGluZ3MgPSBjYXJkTGVnYWN5LmJpbmRpbmdfdmFsdWVzO1xuICBjb25zdCBieUtleTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgaWYgKEFycmF5LmlzQXJyYXkoYmluZGluZ3MpKSB7XG4gICAgZm9yIChjb25zdCBidiBvZiBiaW5kaW5ncykge1xuICAgICAgaWYgKHR5cGVvZiBidiAhPT0gJ29iamVjdCcgfHwgYnYgPT09IG51bGwpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgbyA9IGJ2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgY29uc3QgayA9IHN0ck9yTnVsbChvLmtleSk7XG4gICAgICBjb25zdCB2ID0gb2JqKG8udmFsdWUpO1xuICAgICAgaWYgKCFrIHx8ICF2KSBjb250aW51ZTtcbiAgICAgIGJ5S2V5W2tdID1cbiAgICAgICAgc3RyT3JOdWxsKHYuc3RyaW5nX3ZhbHVlKSA/P1xuICAgICAgICBzdHJPck51bGwob2JqKHYuaW1hZ2VfdmFsdWUpPy51cmwpID8/XG4gICAgICAgIHN0ck9yTnVsbChvYmoodi5pbWFnZV9jb2xvcl92YWx1ZSk/LnBhbGV0dGUpO1xuICAgIH1cbiAgfVxuICBjb25zdCBuYW1lID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kubmFtZSk7XG4gIGNvbnN0IGNhcmRVcmwgPSBzdHJPck51bGwoY2FyZExlZ2FjeS51cmwpO1xuICBjb25zdCB2ZW5kb3JVcmwgPVxuICAgIHR5cGVvZiBieUtleVsndmFuaXR5X3VybCddID09PSAnc3RyaW5nJyA/IChieUtleVsndmFuaXR5X3VybCddIGFzIHN0cmluZykgOiBudWxsO1xuICBjb25zdCB0aXRsZSA9IHR5cGVvZiBieUtleVsndGl0bGUnXSA9PT0gJ3N0cmluZycgPyAoYnlLZXlbJ3RpdGxlJ10gYXMgc3RyaW5nKSA6IG51bGw7XG4gIGNvbnN0IGRlc2NyaXB0aW9uID1cbiAgICB0eXBlb2YgYnlLZXlbJ2Rlc2NyaXB0aW9uJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5WydkZXNjcmlwdGlvbiddIGFzIHN0cmluZykgOiBudWxsO1xuICBjb25zdCBpbWFnZVVybCA9XG4gICAgKHR5cGVvZiBieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXG4gICAgICA/IChieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxuICAgICAgOiBudWxsKSA/P1xuICAgICh0eXBlb2YgYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xuICAgICAgPyAoYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcbiAgICAgIDogbnVsbCkgPz9cbiAgICAodHlwZW9mIGJ5S2V5WydzdW1tYXJ5X3Bob3RvX2ltYWdlX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXG4gICAgICA/IChieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcbiAgICAgIDogbnVsbCk7XG4gIGlmICghbmFtZSAmJiAhdGl0bGUgJiYgIWRlc2NyaXB0aW9uICYmICFpbWFnZVVybCkgcmV0dXJuIG51bGw7XG4gIHJldHVybiB7XG4gICAgbmFtZSxcbiAgICBjYXJkX3VybDogY2FyZFVybCxcbiAgICB2ZW5kb3JfdXJsOiB2ZW5kb3JVcmwsXG4gICAgdGl0bGUsXG4gICAgZGVzY3JpcHRpb24sXG4gICAgaW1hZ2VfdXJsOiBpbWFnZVVybCxcbiAgfTtcbn1cbiIsICIvKipcclxuICogTGlnaHR3ZWlnaHQgVUxJRC1saWtlIGlkIGdlbmVyYXRvcjogMjYtY2hhcmFjdGVyIENyb2NrZm9yZCBiYXNlMzIgc3RyaW5nXHJcbiAqIG9mICh0aW1lc3RhbXBfbXMgfHwgcmFuZG9tbmVzcykuIEdvb2QgZW5vdWdoIGZvciBydW4gaWRlbnRpZmllcnMgd2l0aG91dFxyXG4gKiBwdWxsaW5nIGluIGEgcmVhbCBVTElEIGRlcGVuZGVuY3kuXHJcbiAqL1xyXG5cclxuY29uc3QgQUxQSEFCRVQgPSAnMDEyMzQ1Njc4OUFCQ0RFRkdISktNTlBRUlNUVldYWVonOyAvLyBDcm9ja2ZvcmRcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBuZXdSdW5JZCgpOiBzdHJpbmcge1xyXG4gIGNvbnN0IHRzID0gRGF0ZS5ub3coKTtcclxuICBsZXQgdHNQYXJ0ID0gJyc7XHJcbiAgbGV0IHQgPSB0cztcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IDEwOyBpKyspIHtcclxuICAgIHRzUGFydCA9IChBTFBIQUJFVFt0ICUgMzJdID8/ICcwJykgKyB0c1BhcnQ7XHJcbiAgICB0ID0gTWF0aC5mbG9vcih0IC8gMzIpO1xyXG4gIH1cclxuICBjb25zdCByYW5kID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMCkpO1xyXG4gIGxldCByYW5kUGFydCA9ICcnO1xyXG4gIGZvciAoY29uc3QgYiBvZiByYW5kKSByYW5kUGFydCArPSBBTFBIQUJFVFtiICUgMzJdID8/ICcwJztcclxuICByZXR1cm4gdHNQYXJ0ICsgcmFuZFBhcnQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzaG9ydFJ1bklkKGlkOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIHJldHVybiBpZC5zbGljZSgtOCk7XHJcbn1cclxuIiwgImltcG9ydCB0eXBlIHsgQWNjb3VudENhdGVnb3J5LCBBY2NvdW50Q29uZmlnIH0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG4vKipcclxuICogTWluaW1hbCBwYXJzZXIgZm9yIHRoZSBzdHJpY3Qgc2hhcGUgdXNlZCBieSBgY29uZmlnL2FjY291bnRzLnlhbWxgOlxyXG4gKlxyXG4gKiAgIGFjY291bnRzOlxyXG4gKiAgICAgLSBoYW5kbGU6IERIU2dvdlxyXG4gKiAgICAgICBsYWJlbDogRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eVxyXG4gKiAgICAgICBjYXRlZ29yeTogY29yZVxyXG4gKlxyXG4gKiBXZSBkZWxpYmVyYXRlbHkgZG9uJ3QgcHVsbCBpbiBhIGZ1bGwgWUFNTCBsaWJyYXJ5IFx1MjAxNCB3ZSBjb250cm9sIGJvdGggZW5kcyBvZlxyXG4gKiB0aGlzIGZpbGUsIGFuZCBhIHNtYWxsIHBhcnNlciBpcyBlYXNpZXIgdG8gYXVkaXQgdGhhbiB0aGUgYWx0ZXJuYXRpdmVzLlxyXG4gKiBVbmtub3duIGtleXMgYW5kIGNvbW1lbnRzIGFyZSB0b2xlcmF0ZWQ7IG1hbGZvcm1lZCBsaW5lcyBhcmUgc2tpcHBlZC5cclxuICpcclxuICogRW50cmllcyBtaXNzaW5nIGEgYGNhdGVnb3J5YCBkZWZhdWx0IHRvIGBjb3JlYCBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eVxyXG4gKiB3aXRoIHRoZSBwcmUtY2F0ZWdvcml6YXRpb24gZmlsZSBzaGFwZS5cclxuICovXHJcbmNvbnN0IFZBTElEX0NBVEVHT1JJRVM6IFJlYWRvbmx5U2V0PEFjY291bnRDYXRlZ29yeT4gPSBuZXcgU2V0KFtcclxuICAnY29yZScsXHJcbiAgJ2dvdmVybm1lbnQnLFxyXG4gICdvZmZpY2lhbHMnLFxyXG4gICdwdWJsaWNfZmlndXJlcycsXHJcbiAgJ3B1YmxpYycsXHJcbl0pO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQWNjb3VudHNZYW1sKHRleHQ6IHN0cmluZyk6IEFjY291bnRDb25maWdbXSB7XHJcbiAgY29uc3QgYWNjb3VudHM6IEFjY291bnRDb25maWdbXSA9IFtdO1xyXG4gIGxldCBjdXJyZW50OiBQYXJ0aWFsPEFjY291bnRDb25maWc+ID0ge307XHJcbiAgbGV0IGluQWNjb3VudHMgPSBmYWxzZTtcclxuICBjb25zdCBmbHVzaCA9ICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSB7XHJcbiAgICAgIGlmICghY3VycmVudC5jYXRlZ29yeSkgY3VycmVudC5jYXRlZ29yeSA9ICdjb3JlJztcclxuICAgICAgYWNjb3VudHMucHVzaChjdXJyZW50IGFzIEFjY291bnRDb25maWcpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgZm9yIChjb25zdCByYXdMaW5lIG9mIHRleHQuc3BsaXQoJ1xcbicpKSB7XHJcbiAgICBjb25zdCBsaW5lID0gc3RyaXBDb21tZW50cyhyYXdMaW5lKTtcclxuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gJycpIGNvbnRpbnVlO1xyXG4gICAgaWYgKC9eYWNjb3VudHNcXHMqOi8udGVzdChsaW5lKSkge1xyXG4gICAgICBpbkFjY291bnRzID0gdHJ1ZTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAoIWluQWNjb3VudHMpIGNvbnRpbnVlO1xyXG5cclxuICAgIGNvbnN0IGl0ZW1NYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqLVxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xyXG4gICAgaWYgKGl0ZW1NYXRjaCkge1xyXG4gICAgICBmbHVzaCgpO1xyXG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaXRlbU1hdGNoWzFdID8/ICcnKSB9O1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGhhbmRsZU9ubHkgPSBsaW5lLm1hdGNoKC9eXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XHJcbiAgICBpZiAoaGFuZGxlT25seSAmJiAhbGluZS5pbmNsdWRlcygnLScpKSB7XHJcbiAgICAgIGZsdXNoKCk7XHJcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShoYW5kbGVPbmx5WzFdID8/ICcnKSB9O1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGxhYmVsTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmxhYmVsXFxzKjpcXHMqKC4rKSQvKTtcclxuICAgIGlmIChsYWJlbE1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XHJcbiAgICAgIGN1cnJlbnQubGFiZWwgPSB1bnF1b3RlKGxhYmVsTWF0Y2hbMV0gPz8gJycpO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGNhdGVnb3J5TWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmNhdGVnb3J5XFxzKjpcXHMqKC4rKSQvKTtcclxuICAgIGlmIChjYXRlZ29yeU1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XHJcbiAgICAgIGNvbnN0IHJhdyA9IHVucXVvdGUoY2F0ZWdvcnlNYXRjaFsxXSA/PyAnJyk7XHJcbiAgICAgIGN1cnJlbnQuY2F0ZWdvcnkgPSBWQUxJRF9DQVRFR09SSUVTLmhhcyhyYXcgYXMgQWNjb3VudENhdGVnb3J5KVxyXG4gICAgICAgID8gKHJhdyBhcyBBY2NvdW50Q2F0ZWdvcnkpXHJcbiAgICAgICAgOiAnY29yZSc7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gIH1cclxuICBmbHVzaCgpO1xyXG4gIHJldHVybiBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuaGFuZGxlLmxlbmd0aCA+IDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdHJpcENvbW1lbnRzKGxpbmU6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgLy8gTmFpdmUgYnV0IGFkZXF1YXRlIGZvciBvdXIgZm9ybWF0OiBzdHJpcCBldmVyeXRoaW5nIGFmdGVyIGEgYCNgIHRoYXQgaXNuJ3RcclxuICAvLyBpbnNpZGUgcXVvdGVzLiBPdXIgY29uZmlnIG5ldmVyIHVzZXMgaW5saW5lIHN0cmluZ3Mgd2l0aCBgI2AuXHJcbiAgY29uc3QgaWR4ID0gbGluZS5pbmRleE9mKCcjJyk7XHJcbiAgcmV0dXJuIGlkeCA9PT0gLTEgPyBsaW5lIDogbGluZS5zbGljZSgwLCBpZHgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgY29uc3QgdHJpbW1lZCA9IHMudHJpbSgpO1xyXG4gIGlmIChcclxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoJ1wiJykgJiYgdHJpbW1lZC5lbmRzV2l0aCgnXCInKSkgfHxcclxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoXCInXCIpICYmIHRyaW1tZWQuZW5kc1dpdGgoXCInXCIpKVxyXG4gICkge1xyXG4gICAgcmV0dXJuIHRyaW1tZWQuc2xpY2UoMSwgLTEpO1xyXG4gIH1cclxuICByZXR1cm4gdHJpbW1lZDtcclxufVxyXG4iLCAiLyoqXG4gKiBiYWNrZ3JvdW5kLnRzIFx1MjAxNCBleHRlbnNpb24gc2VydmljZSB3b3JrZXIuXG4gKlxuICogT3ducyB0aGUgY2FwdHVyZSBwaXBlbGluZTogcmVjZWl2ZXMgYGdyYXBocWwtY2FwdHVyZWAgbWVzc2FnZXMgZnJvbSB0aGVcbiAqIGNvbnRlbnQgc2NyaXB0LCBub3JtYWxpemVzIHRoZW0sIGFjY3VtdWxhdGVzIHBlci1oYW5kbGUgcnVuIGJ1ZmZlcnMgaW5cbiAqIGBicm93c2VyLnN0b3JhZ2UubG9jYWxgLCBhbmQgY29tbWl0cyB0aGVtIHRvIHRoZSBjb25maWd1cmVkIEdpdEh1YiByZXBvXG4gKiB2aWEgdGhlIENvbnRlbnRzIEFQSS5cbiAqXG4gKiBTZXJ2aWNlIHdvcmtlcnMgaW4gTVYzIG1heSBiZSBldmljdGVkIGF0IGFueSB0aW1lLCBzbyBhbGwgY3JpdGljYWwgc3RhdGVcbiAqIGxpdmVzIGluIHN0b3JhZ2UgKG5ldmVyIG1vZHVsZS1zY29wZSkuIE9uIGV2ZXJ5IHdha2Ugd2UgcmUtZGVyaXZlIHdoYXQgd2VcbiAqIG5lZWQ7IHBlbmRpbmcgZmx1c2hlcyBhcmUgZHJpdmVuIGJ5IGBicm93c2VyLmFsYXJtc2AgcmF0aGVyIHRoYW4gdGltZXJzLlxuICovXG5cbmltcG9ydCB7XG4gIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gIEFVVE9fU0NST0xMX01JTl9TRUMsXG4gIEZBTExCQUNLX0FDQ09VTlRTLFxuICBGTFVTSF9BTEFSTV9NSU5VVEVTLFxuICBGTFVTSF9JRExFX01TLFxuICBGTFVTSF9UV0VFVF9USFJFU0hPTEQsXG4gIFBST0ZJTEVfRU5EUE9JTlRTLFxuICBUV0VFVF9FTkRQT0lOVFMsXG4gIFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TLFxufSBmcm9tICcuL2xpYi9jb25maWcuanMnO1xuaW1wb3J0IHsgR2l0SHViQ2xpZW50LCBHaXRIdWJFcnJvciwgdG9CYXNlNjQgfSBmcm9tICcuL2xpYi9naXRodWIuanMnO1xuaW1wb3J0IHsgZGVzY3JpYmVFcnJvciwgZXJyb3IgYXMgbG9nRXJyLCBpbmZvLCBzZXRCcm9hZGNhc3Rlciwgd2FybiB9IGZyb20gJy4vbGliL2xvZ2dlci5qcyc7XG5pbXBvcnQgeyBmaWx0ZXJSZWxhdGVkLCBub3JtYWxpemUgfSBmcm9tICcuL2xpYi9ub3JtYWxpemUuanMnO1xuaW1wb3J0IHsgbmV3UnVuSWQsIHNob3J0UnVuSWQgfSBmcm9tICcuL2xpYi9ydW5pZHMuanMnO1xuaW1wb3J0IHtcbiAgYnVtcENvdW50ZXIsXG4gIGNsZWFyQWN0aXZpdHksXG4gIGNsZWFyQWxsLFxuICBjbGVhclJ1bkJ1ZmZlcixcbiAgZGVxdWV1ZU1lZGlhQ3Jhd2wsXG4gIGRlcXVldWVSZWZldGNoLFxuICBlbmdhZ2VtZW50U2lnLFxuICBlbnF1ZXVlTWVkaWFDcmF3bCxcbiAgZW5xdWV1ZVJlZmV0Y2gsXG4gIGdldEFjY291bnRzLFxuICBnZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxuICBnZXRBY3Rpdml0eSxcbiAgZ2V0QXV0b1Njcm9sbFNlc3Npb24sXG4gIGdldENvbW1pdHRlZEluZGV4LFxuICBnZXRDb25uZWN0aW9uLFxuICBnZXRDb3VudGVycyxcbiAgZ2V0TWVkaWFDcmF3bFF1ZXVlLFxuICBnZXRNZWRpYUNyYXdsU2Vzc2lvbixcbiAgZ2V0UmVmZXRjaFF1ZXVlLFxuICBnZXRSZWZldGNoU2Vzc2lvbixcbiAgZ2V0UnVuQnVmZmVyLFxuICBnZXRSdW5CdWZmZXJzLFxuICBnZXRTZXR0aW5ncyxcbiAgaXNDb21taXR0ZWQsXG4gIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsLFxuICBuZXh0TWVkaWFDcmF3bFRhcmdldCxcbiAgbmV4dFJlZmV0Y2hUYXJnZXQsXG4gIHBydW5lQ29tbWl0dGVkSW5kZXgsXG4gIHB1cmdlVW5yZWxhdGVkU3RhdGUsXG4gIHJlZmV0Y2hRdWV1ZVRvdGFsLFxuICBzZXRBY2NvdW50cyxcbiAgc2V0QWNjb3VudHNSZWZyZXNoZWRBdCxcbiAgc2V0QXV0b1Njcm9sbFNlc3Npb24sXG4gIHNldEJ1ZmZlcmVkQ291bnQsXG4gIHNldENvbW1pdHRlZEluZGV4LFxuICBzZXRDb25uZWN0aW9uLFxuICBzZXRNZWRpYUNyYXdsU2Vzc2lvbixcbiAgc2V0UmVmZXRjaFNlc3Npb24sXG4gIHNldFJ1bkJ1ZmZlcixcbiAgdHlwZSBSdW5CdWZmZXIsXG4gIHVwZGF0ZVNldHRpbmdzLFxufSBmcm9tICcuL2xpYi9zdG9yYWdlLmpzJztcbmltcG9ydCB0eXBlIHtcbiAgQ2Fub25pY2FsVHdlZXQsXG4gIENhcHR1cmVQYXlsb2FkLFxuICBDb25uZWN0aW9uU3RhdGUsXG4gIEV4dGVuc2lvblN0YXRlLFxuICBMb2dFdmVudCxcbiAgUXVhcmFudGluZVBheWxvYWQsXG4gIFJ1bnRpbWVNZXNzYWdlLFxuICBTZWVuUGF5bG9hZCxcbiAgU2V0dGluZ3MsXG59IGZyb20gJy4vbGliL3R5cGVzLmpzJztcbmltcG9ydCB7IHBhcnNlQWNjb3VudHNZYW1sIH0gZnJvbSAnLi9saWIveWFtbC5qcyc7XG5cbmNvbnN0IEVYVF9WRVJTSU9OID0gYnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbjtcblxuc2V0QnJvYWRjYXN0ZXIoKGV2OiBMb2dFdmVudCkgPT4ge1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnbG9nLWV2ZW50JywgZXZlbnQ6IGV2IH0pLmNhdGNoKCgpID0+IHt9KTtcbn0pO1xuXG4vLyAtLS0gV2FrZSBoYW5kbGVycyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5icm93c2VyLnJ1bnRpbWUub25JbnN0YWxsZWQuYWRkTGlzdGVuZXIoYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBpbmZvKCdleHRlbnNpb24gaW5zdGFsbGVkJywgeyB2ZXJzaW9uOiBFWFRfVkVSU0lPTiB9KTtcbiAgYXdhaXQgb25XYWtlKCdpbnN0YWxsJyk7XG59KTtcblxuYnJvd3Nlci5ydW50aW1lLm9uU3RhcnR1cC5hZGRMaXN0ZW5lcigoKSA9PiB7XG4gIHZvaWQgb25XYWtlKCdzdGFydHVwJyk7XG59KTtcblxuLy8gRm9yY2UgYXQgbGVhc3Qgb25lIHdha2UgdG8gcmVnaXN0ZXIgYWxhcm1zIC8gdmVyaWZ5IGNvbm5lY3Rpb24uXG52b2lkIG9uV2FrZSgnbW9kdWxlLWxvYWQnKTtcblxuYXN5bmMgZnVuY3Rpb24gb25XYWtlKHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgYXdhaXQgZW5zdXJlQWxhcm1zKCk7XG4gICAgYXdhaXQgZW5zdXJlQXV0b1Njcm9sbEFsYXJtKCk7XG4gICAgYXdhaXQgZmx1c2hPcnBoYW5lZEJ1ZmZlcnNJZlN0YWxlKCk7XG4gICAgYXdhaXQgcmVpbmplY3RJbnRvT3BlblRhYnMoKTtcbiAgICAvLyBEcm9wIGRlZHVwLWluZGV4IGVudHJpZXMgb2xkZXIgdGhhbiAzMCBkYXlzIHNvIHRoZSBzdG9yZSBkb2Vzbid0XG4gICAgLy8gZ3JvdyB1bmJvdW5kZWQgb3ZlciBtb250aHMgb2YgY2FwdHVyZSBzZXNzaW9ucy5cbiAgICBjb25zdCBwcnVuZWQgPSBhd2FpdCBwcnVuZUNvbW1pdHRlZEluZGV4KDMwICogMjQgKiA2MCAqIDYwICogMTAwMCk7XG4gICAgaWYgKHBydW5lZCA+IDApIGF3YWl0IGluZm8oJ3BydW5lZCBjb21taXR0ZWQgaW5kZXgnLCB7IHBydW5lZCB9KTtcbiAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgaWYgKHNldHRpbmdzLnBhdCAmJiBzZXR0aW5ncy5vd25lciAmJiBzZXR0aW5ncy5yZXBvKSB7XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgICAgIGF3YWl0IHJlZnJlc2hBY2NvdW50c0xpc3QoZmFsc2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgICBsb2dpbjogbnVsbCxcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBpbmZvKCdleHRlbnNpb24gYXdha2U7IHNldHRpbmdzIGluY29tcGxldGUnLCB7IHJlYXNvbiB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IGxvZ0Vycignd2FrZSBmYWlsZWQnLCB7IHJlYXNvbiwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICB9XG59XG5cbi8qKlxuICogUmUtaW5qZWN0IHRoZSBNQUlOLXdvcmxkIHBhZ2UtaG9vayArIGlzb2xhdGVkLXdvcmxkIGNvbnRlbnQgc2NyaXB0IGludG9cbiAqIGV2ZXJ5IGFscmVhZHktb3BlbiB4LmNvbSAvIHR3aXR0ZXIuY29tIHRhYi5cbiAqXG4gKiBNYW5pZmVzdCBjb250ZW50X3NjcmlwdHMgb25seSBpbmplY3Qgb24gZnJlc2ggbmF2aWdhdGlvbiAocnVuX2F0OlxuICogZG9jdW1lbnRfc3RhcnQpLiBXaGVuIHRoZSB1c2VyIHJlbG9hZHMgdGhlIGV4dGVuc2lvbiB3aGlsZSBYIHRhYnMgYXJlXG4gKiBvcGVuLCB0aG9zZSB0YWJzIGtlZXAgdGhlaXIgY29udGVudCBzY3JpcHRzIGJ1dCBuZXZlciBnZXQgYSBuZXcgcGFnZS1ob29rXG4gKiBcdTIwMTQgc28gZmV0Y2gvWEhSIHN0YXlzIHVucGF0Y2hlZCBhbmQgY2FwdHVyZXMgc2lsZW50bHkgZmFpbC4gRG9pbmcgdGhpcyBvblxuICogZXZlcnkgd2FrZSBpcyBpZGVtcG90ZW50IChwYWdlLWhvb2sgaGFzIGEgVEFHIGd1YXJkKSBhbmQgY2hlYXAuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIHJlaW5qZWN0SW50b09wZW5UYWJzKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjb3VsZCBub3QgcXVlcnkgb3BlbiB0YWJzJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHRhYnMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcbiAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIGNvbnRpbnVlO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgZmlsZXM6IFsncGFnZS1ob29rLmpzJ10sXG4gICAgICAgIC8vIEZpcmVmb3ggMTI4KyBzdXBwb3J0cyB0aGUgTUFJTiBleGVjdXRpb24gd29ybGQgdmlhIHRoaXMgQVBJLCBidXRcbiAgICAgICAgLy8gdGhlIEB0eXBlcy9maXJlZm94LXdlYmV4dC1icm93c2VyIHBhY2thZ2Ugd2UncmUgb24gc3RpbGwgb25seVxuICAgICAgICAvLyBkZWNsYXJlcyAnSVNPTEFURUQnLiBDYXN0IHRocm91Z2ggdGhlIGxpdGVyYWwgdW5pb24uXG4gICAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICAgIGZpbGVzOiBbJ2NvbnRlbnQuanMnXSxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgaW5mbygncmUtaW5qZWN0ZWQgc2NyaXB0cyBpbnRvIG9wZW4gdGFiJywge1xuICAgICAgICB0YWJJZDogdGFiLmlkLFxuICAgICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCA/PyAnJyksXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIC8vIFNvbWUgdGFicyAoYWJvdXQ6IHBhZ2VzLCBkaXNjYXJkZWQgdGFicywgbWlkLW5hdmlnYXRpb24pIHJlamVjdFxuICAgICAgLy8gZXhlY3V0ZVNjcmlwdC4gVGhhdCdzIGZpbmUgXHUyMDE0IHdlJ2xsIGNhdGNoIHRoZW0gb24gdGhlIG5leHQgd2FrZSBvclxuICAgICAgLy8gd2hlbiB0aGUgdXNlciBuYXZpZ2F0ZXMuXG4gICAgICBhd2FpdCB3YXJuKCdyZS1pbmplY3QgZmFpbGVkIGZvciB0YWI7IGNvbnRpbnVpbmcnLCB7XG4gICAgICAgIHRhYklkOiB0YWIuaWQsXG4gICAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsID8/ICcnKSxcbiAgICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUFsYXJtcygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ2ZsdXNoLXN3ZWVwJyk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd2ZXJpZnktY29ubmVjdGlvbicpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jcmVhdGUoJ2ZsdXNoLXN3ZWVwJywgeyBwZXJpb2RJbk1pbnV0ZXM6IEZMVVNIX0FMQVJNX01JTlVURVMgfSk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgndmVyaWZ5LWNvbm5lY3Rpb24nLCB7XG4gICAgcGVyaW9kSW5NaW51dGVzOiBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyAvIDYwXzAwMCxcbiAgfSk7XG59XG5cbi8vIEZpcmVmb3ggTVYzIGFsYXJtcyBoYXZlIGEgMzBzIG1pbmltdW0gcGVyaW9kLCBidXQgd2Ugd2FudCBzdWItbWludXRlXG4vLyBzY3JvbGxpbmcuIFRoZSBhdXRvLXNjcm9sbCBsb29wIHRoZXJlZm9yZSBydW5zIG9uIGFuIGluLVNXIGludGVydmFsLlxuLy8gYGF1dG9TY3JvbGxTZXNzaW9uYCBpbiBzdG9yYWdlIGlzIHRoZSBzb3VyY2Ugb2YgdHJ1dGggZm9yIHdoZXRoZXIgdGhlIGxvb3Bcbi8vIGlzIG1lYW50IHRvIGJlIHJ1bm5pbmcgXHUyMDE0IHRoZSB0aW1lciBpcyBqdXN0IHRoZSBsb2NhbCBleGVjdXRpb24gYXJtLlxubGV0IGF1dG9TY3JvbGxUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbi8vIFdhaXQtZm9yLWluZ2VzdCB0aW1lb3V0OiBpZiBhIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCB0YWIgbmF2aWdhdGlvbiBkb2Vzbid0XG4vLyBwcm9kdWNlIGFuIGluZ2VzdGVkIGNhcHR1cmUgd2l0aGluIHRoaXMgbWFueSBtcywgYWR2YW5jZSBhbnl3YXkgc28gd2Vcbi8vIGRvbid0IGRlYWRsb2NrIG9uIGRlbGV0ZWQgLyA0MDQgLyBwYXl3YWxsZWQgdHdlZXRzLlxuY29uc3QgSU5HRVNUX1dBSVRfTVMgPSAyNV8wMDA7XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUF1dG9TY3JvbGxBbGFybSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gV2FzIHRoZSBsb29wIHJ1bm5pbmcgYmVmb3JlIHRoZSBTVyBldmljdGlvbj8gUmUtYXJtIGlmIHNvLlxuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmIChzZXNzICE9PSBudWxsICYmIHMuZW5hYmxlZCAhPT0gZmFsc2UpIHtcbiAgICBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xuICB9IGVsc2Uge1xuICAgIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTogdm9pZCB7XG4gIGlmIChhdXRvU2Nyb2xsVGltZXIgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKGF1dG9TY3JvbGxUaW1lcik7XG4gICAgYXV0b1Njcm9sbFRpbWVyID0gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBhcm1BdXRvU2Nyb2xsVGltZXIoaW50ZXJ2YWxTZWM6IG51bWJlcik6IHZvaWQge1xuICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICBjb25zdCBjbGFtcGVkID0gTWF0aC5taW4oXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKGludGVydmFsU2VjKSlcbiAgKTtcbiAgYXV0b1Njcm9sbFRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgYXV0b1Njcm9sbFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ2F1dG8tc2Nyb2xsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICB9KTtcbiAgfSwgY2xhbXBlZCAqIDEwMDApO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydEF1dG9TY3JvbGxMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oe1xuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNjcm9sbENvdW50OiAwLFxuICAgIGluZ2VzdGVkQ291bnQ6IDAsXG4gICAgZXhwYW5kZWRDb3VudDogMCxcbiAgfSk7XG4gIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XG4gIGF3YWl0IGluZm8oJ2F1dG8tc2Nyb2xsIGxvb3Agc3RhcnRlZCcsIHsgaW50ZXJ2YWxfc2VjOiBzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyB9KTtcbiAgLy8gRmlyZSBvbmUgaW1tZWRpYXRlIHRpY2sgc28gdGhlIHVzZXIgc2VlcyBtb3Rpb24gcmlnaHQgYXdheS5cbiAgdm9pZCBhdXRvU2Nyb2xsVGljaygpO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdhdXRvLXNjcm9sbCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBzY3JvbGxzOiBzZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxuICAgIGluZ2VzdGVkOiBzZXNzPy5pbmdlc3RlZENvdW50ID8/IDAsXG4gICAgZXhwYW5kZWQ6IHNlc3M/LmV4cGFuZGVkQ291bnQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGF1dG9TY3JvbGxUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdhdXRvLXNjcm9sbDogdGFiIHF1ZXJ5IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBsZXQgc2Nyb2xsQ291bnQgPSAwO1xuICBsZXQgZXhwYW5kZWRDb3VudCA9IDA7XG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcbiAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIGNvbnRpbnVlO1xuICAgIGlmICh0YWIuZGlzY2FyZGVkKSBjb250aW51ZTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0cyA9IChhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgICAvLyBDYXN0OiB0aGUgQHR5cGVzL2ZpcmVmb3gtd2ViZXh0LWJyb3dzZXIgdHlwZSBzaWduYXR1cmUgaW5zaXN0c1xuICAgICAgICAvLyBgZnVuY2AgcmV0dXJucyB2b2lkLCBidXQgdGhlIEFQSSBhY3R1YWxseSBzdXJmYWNlcyB0aGUgcmV0dXJuXG4gICAgICAgIC8vIHZhbHVlIHZpYSBgcmVzdWx0WzBdLnJlc3VsdGAuIFdlIHVzZSB0aGF0IGZvciB0aGUgZXhwYW5kIGNvdW50LlxuICAgICAgICBmdW5jOiAoKCkgPT4ge1xuICAgICAgICAgIC8vIDEuIENsaWNrIGFueSB2aXNpYmxlIFwiU2hvdyBtb3JlXCIgbGlua3MgaW4gbG9uZy10d2VldCBib2RpZXMgc28gWFxuICAgICAgICAgIC8vICAgIGlubGluZXMgdGhlIG5vdGVfdHdlZXQgYm9keSBhbmQgb3VyIHBhZ2UtaG9vayBjYXB0dXJlcyB0aGVcbiAgICAgICAgICAvLyAgICBmdWxsIHRleHQgd2l0aG91dCB0aGUgcmVmZXRjaCBkZXRvdXIuIFRyeSBzZXZlcmFsIHNlbGVjdG9yc1xuICAgICAgICAgIC8vICAgIGJlY2F1c2UgWCByb3RhdGVzIHRoZSB0ZXN0aWQgbGFiZWwgc2VtaS1yZWd1bGFybHkuXG4gICAgICAgICAgY29uc3QgU0hPV19NT1JFX1NFTEVDVE9SUyA9IFtcbiAgICAgICAgICAgICdbZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcbiAgICAgICAgICAgICdidXR0b25bZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcbiAgICAgICAgICAgICdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0gW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcbiAgICAgICAgICBdO1xuICAgICAgICAgIGNvbnN0IGNsaWNrZWQgPSBuZXcgU2V0PEVsZW1lbnQ+KCk7XG4gICAgICAgICAgbGV0IGV4cGFuZGVkID0gMDtcbiAgICAgICAgICBmb3IgKGNvbnN0IHNlbCBvZiBTSE9XX01PUkVfU0VMRUNUT1JTKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGVsIG9mIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWwpKSkge1xuICAgICAgICAgICAgICBpZiAoY2xpY2tlZC5oYXMoZWwpKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgLy8gQ29uZmlybSBpdCdzIGFjdHVhbGx5IHRoZSBzaG93LW1vcmUgYWZmb3JkYW5jZSBieSB0ZXh0LlxuICAgICAgICAgICAgICBjb25zdCB0ID0gKGVsLnRleHRDb250ZW50IHx8ICcnKS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgaWYgKHQgIT09ICdzaG93IG1vcmUnICYmIHQgIT09ICdzaG93IHRoaXMgdGhyZWFkJykgY29udGludWU7XG4gICAgICAgICAgICAgIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICAgICAgaWYgKHJlY3Qud2lkdGggPT09IDAgfHwgcmVjdC5oZWlnaHQgPT09IDApIGNvbnRpbnVlO1xuICAgICAgICAgICAgICBjbGlja2VkLmFkZChlbCk7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgICAgICAgICAgICAgIGV4cGFuZGVkICs9IDE7XG4gICAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgIC8vIGlnbm9yZVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIDIuIFNjcm9sbCB0aGUgcGFnZS4gRGlzcGF0Y2ggRW5kIGtleSBmaXJzdCBzaW5jZSBtYW55IFggc3VyZmFjZXNcbiAgICAgICAgICAvLyAgICAobGlzdHMsIHNlYXJjaCwgcmVwbGllcykgYmluZCBwYWdpbmF0aW9uIHRyaWdnZXJzIHRvIGl0IHZpYVxuICAgICAgICAgIC8vICAgIFJlYWN0IGhhbmRsZXJzOyB0aGVuIGV4cGxpY2l0bHkgc2Nyb2xsIHRoZSBkb2N1bWVudC5cbiAgICAgICAgICBjb25zdCBvcHRzOiBLZXlib2FyZEV2ZW50SW5pdCA9IHtcbiAgICAgICAgICAgIGtleTogJ0VuZCcsXG4gICAgICAgICAgICBjb2RlOiAnRW5kJyxcbiAgICAgICAgICAgIGtleUNvZGU6IDM1LFxuICAgICAgICAgICAgd2hpY2g6IDM1LFxuICAgICAgICAgICAgYnViYmxlczogdHJ1ZSxcbiAgICAgICAgICAgIGNhbmNlbGFibGU6IHRydWUsXG4gICAgICAgICAgfTtcbiAgICAgICAgICBjb25zdCBmb2N1cyA9IChkb2N1bWVudC5hY3RpdmVFbGVtZW50IGFzIEhUTUxFbGVtZW50IHwgbnVsbCkgPz8gZG9jdW1lbnQuYm9keTtcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXlkb3duJywgb3B0cykpO1xuICAgICAgICAgIGZvY3VzLmRpc3BhdGNoRXZlbnQobmV3IEtleWJvYXJkRXZlbnQoJ2tleXVwJywgb3B0cykpO1xuICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbyh7XG4gICAgICAgICAgICB0b3A6IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxIZWlnaHQsXG4gICAgICAgICAgICBiZWhhdmlvcjogJ2F1dG8nLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiB7IGV4cGFuZGVkIH07XG4gICAgICAgIH0pIGFzICgpID0+IHZvaWQsXG4gICAgICB9KSkgYXMgQXJyYXk8eyByZXN1bHQ/OiB1bmtub3duIH0+O1xuICAgICAgc2Nyb2xsQ291bnQgKz0gMTtcbiAgICAgIGNvbnN0IHIgPSByZXN1bHRzWzBdPy5yZXN1bHQgYXMgeyBleHBhbmRlZD86IG51bWJlciB9IHwgdW5kZWZpbmVkO1xuICAgICAgaWYgKHIgJiYgdHlwZW9mIHIuZXhwYW5kZWQgPT09ICdudW1iZXInKSBleHBhbmRlZENvdW50ICs9IHIuZXhwYW5kZWQ7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBUYWJzIHRoYXQgZGlzYWxsb3cgc2NyaXB0aW5nIChhYm91dDosIGRpc2NhcmRlZCwgbWlkLW5hdmlnYXRpb24pXG4gICAgICAvLyBqdXN0IGdldCBza2lwcGVkIFx1MjAxNCB0aGV5J2xsIGJlIGVsaWdpYmxlIG9uIGEgbGF0ZXIgdGljay5cbiAgICB9XG4gIH1cbiAgaWYgKHNjcm9sbENvdW50ID4gMCkge1xuICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgIGlmIChzZXNzICE9PSBudWxsKSB7XG4gICAgICBzZXNzLnNjcm9sbENvdW50ICs9IHNjcm9sbENvdW50O1xuICAgICAgc2Vzcy5leHBhbmRlZENvdW50ICs9IGV4cGFuZGVkQ291bnQ7XG4gICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzZXNzKTtcbiAgICAgIC8vIE5vIGJyb2FkY2FzdCBvbiBldmVyeSB0aWNrIFx1MjAxNCB0aGUgMTVzIHNpZGViYXIgcmVmcmVzaCBwaWNrcyBpdCB1cC5cbiAgICB9XG4gIH1cbn1cblxuYnJvd3Nlci5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcigoYWxhcm0pID0+IHtcbiAgaWYgKGFsYXJtLm5hbWUgPT09ICdmbHVzaC1zd2VlcCcpIHtcbiAgICB2b2lkIGZsdXNoSWRsZUJ1ZmZlcnMoKTtcbiAgfSBlbHNlIGlmIChhbGFybS5uYW1lID09PSAndmVyaWZ5LWNvbm5lY3Rpb24nKSB7XG4gICAgdm9pZCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgfVxuICAvLyByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcHJldmlvdXNseSByYW4gdmlhIGFsYXJtczsgdGhleSBub3cgdXNlXG4gIC8vIHNldEludGVydmFsIHRvIGVzY2FwZSB0aGUgMzBzIGFsYXJtIGZsb29yLiBMZWF2ZSB0aGUgbmFtZXMgbGlzdGVkXG4gIC8vIG5vd2hlcmUgc28gYW55IG9ycGhhbmVkIGFsYXJtcyAoZnJvbSBvbGRlciBidWlsZHMpIGp1c3Qgbm8tb3AuXG59KTtcblxuLy8gLS0tIFRvb2xiYXIgYWN0aW9uOiB0b2dnbGUgdGhlIHNpZGViYXIgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuaWYgKGJyb3dzZXIuYWN0aW9uPy5vbkNsaWNrZWQpIHtcbiAgYnJvd3Nlci5hY3Rpb24ub25DbGlja2VkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci5zaWRlYmFyQWN0aW9uLnRvZ2dsZSgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgLy8gRmFsbGJhY2s6IG9wZW4gb3B0aW9ucyBpZiBzaWRlYmFyIGNhbid0IGJlIHRvZ2dsZWQuXG4gICAgICBhd2FpdCB3YXJuKCdzaWRlYmFyIHRvZ2dsZSBmYWlsZWQ7IG9wZW5pbmcgb3B0aW9ucycsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgfVxuICB9KTtcbn1cblxuLy8gLS0tIFJ1bnRpbWUgbWVzc2FnZSBkaXNwYXRjaCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24sIF9zZW5kZXIpID0+IHtcbiAgaWYgKCFpc1J1bnRpbWVNZXNzYWdlKG1zZykpIHJldHVybiB1bmRlZmluZWQ7XG4gIHJldHVybiBoYW5kbGVNZXNzYWdlKG1zZykuY2F0Y2goKGVycikgPT4ge1xuICAgIHZvaWQgbG9nRXJyKCdtZXNzYWdlIGhhbmRsZXIgZmFpbGVkJywgeyB0eXBlOiBtc2cudHlwZSwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICAgIHRocm93IGVycjtcbiAgfSk7XG59KTtcblxuZnVuY3Rpb24gaXNSdW50aW1lTWVzc2FnZShtOiB1bmtub3duKTogbSBpcyBSdW50aW1lTWVzc2FnZSB7XG4gIHJldHVybiAhIW0gJiYgdHlwZW9mIG0gPT09ICdvYmplY3QnICYmIHR5cGVvZiAobSBhcyB7IHR5cGU/OiB1bmtub3duIH0pLnR5cGUgPT09ICdzdHJpbmcnO1xufVxuXG4vKiogTWVzc2FnZXMgdGhhdCBkcml2ZSB0aGUgY2FwdHVyZSBwaXBlbGluZS4gV2hlbiB0aGUgbWFzdGVyIHN3aXRjaCBpcyBPRkZcbiAqIHdlIGlnbm9yZSB0aGVzZSBidXQgc3RpbGwgcmVzcG9uZCB0byBzdGF0dXMgLyBjb25maWd1cmF0aW9uIHF1ZXJpZXMuICovXG5jb25zdCBDQVBUVVJFX1BJUEVMSU5FX01FU1NBR0VTID0gbmV3IFNldDxSdW50aW1lTWVzc2FnZVsndHlwZSddPihbXG4gICdncmFwaHFsLWNhcHR1cmUnLFxuICAnY2FwdHVyZS1ub3cnLFxuICAnY2FwdHVyZS1hbGwnLFxuICAnY2FwdHVyZS10aGlzLXBhZ2UnLFxuICAnZmx1c2gtYWxsJyxcbiAgJ2ZsdXNoLWhhbmRsZScsXG4gICdzdGFydC1yZWZldGNoJyxcbiAgJ3N0YXJ0LW1lZGlhLWNyYXdsJyxcbiAgJ3N0YXJ0LWF1dG8tc2Nyb2xsJyxcbl0pO1xuXG5hc3luYyBmdW5jdGlvbiBpc0VuYWJsZWQoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICByZXR1cm4gcy5lbmFibGVkICE9PSBmYWxzZTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlTWVzc2FnZShtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTx1bmtub3duPiB7XG4gIC8vIE1hc3RlciBzd2l0Y2g6IHdoZW4gdGhlIHVzZXIgaGFzIHBhdXNlZCB0aGUgZXh0ZW5zaW9uIHdlIHN0aWxsIG5lZWRcbiAgLy8gdGhlIG1ldGEtY2hhbm5lbHMgKGdldC1zdGF0ZSwgdG9nZ2xlLWVuYWJsZWQsIG9wZW4tb3B0aW9ucywgXHUyMDI2KSBzbyB0aGVcbiAgLy8gc2lkZWJhciBzdGF5cyBmdW5jdGlvbmFsLCBidXQgYW55dGhpbmcgdGhhdCB3b3VsZCBhY3R1YWxseSBjYXB0dXJlLFxuICAvLyBjb21taXQsIG9yIGRyaXZlIGEgdGFiIGlzIGEgbm8tb3AuXG4gIGlmICghKGF3YWl0IGlzRW5hYmxlZCgpKSAmJiBDQVBUVVJFX1BJUEVMSU5FX01FU1NBR0VTLmhhcyhtc2cudHlwZSkpIHtcbiAgICByZXR1cm4geyBvazogdHJ1ZSwgcGF1c2VkOiB0cnVlIH07XG4gIH1cbiAgc3dpdGNoIChtc2cudHlwZSkge1xuICAgIGNhc2UgJ2dyYXBocWwtY2FwdHVyZSc6XG4gICAgICBhd2FpdCBvbkdyYXBocWxDYXB0dXJlKG1zZy5lbmRwb2ludCwgbXNnLnVybCwgbXNnLnBhZ2VVcmwgPz8gbnVsbCwgbXNnLnJlc3BvbnNlKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnY29udGVudC1hbGl2ZSc6XG4gICAgICBhd2FpdCBpbmZvKCdjb250ZW50IHNjcmlwdCBhbGl2ZSBvbiBwYWdlJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ3BhZ2UtaG9vay1hY3RpdmUnOlxuICAgICAgYXdhaXQgaW5mbygncGFnZSBob29rIHBhdGNoZWQgZmV0Y2gvWEhSJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2xvZy1jb250ZW50LWV2ZW50JzpcbiAgICAgIGlmIChtc2cubGV2ZWwgPT09ICd3YXJuJykge1xuICAgICAgICBhd2FpdCB3YXJuKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfSBlbHNlIGlmIChtc2cubGV2ZWwgPT09ICdlcnJvcicpIHtcbiAgICAgICAgYXdhaXQgbG9nRXJyKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgaW5mbyhtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnZ2V0LXN0YXRlJzpcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS1ub3cnOlxuICAgICAgYXdhaXQgY2FwdHVyZU5vdyhtc2cuaGFuZGxlKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS1hbGwnOlxuICAgICAgYXdhaXQgY2FwdHVyZUFsbCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLXRoaXMtcGFnZSc6XG4gICAgICBhd2FpdCBjYXB0dXJlVGhpc1BhZ2UoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnZmx1c2gtYWxsJzpcbiAgICAgIGF3YWl0IGZsdXNoQWxsKCd1c2VyJyk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2ZsdXNoLWhhbmRsZSc6XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShtc2cuaGFuZGxlLCAndXNlcicpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtYXV0by1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b0NhcHR1cmU6IG1zZy5vbiB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2F1dG8tY2FwdHVyZSB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtZW5hYmxlZCc6IHtcbiAgICAgIGNvbnN0IHMgPSBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGVuYWJsZWQ6IG1zZy5vbiB9KTtcbiAgICAgIGlmICghbXNnLm9uKSB7XG4gICAgICAgIC8vIFBhdXNpbmcgc3RvcHMgYWxsIGluLWZsaWdodCBsb29wcyBzbyB0aGUgdXNlciBnZXRzIGltbWVkaWF0ZVxuICAgICAgICAvLyBxdWlldCwgbm90IGEgXCJvbmUgbW9yZSB0aWNrXCIgc3VycHJpc2UuXG4gICAgICAgIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gICAgICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICAgICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigncmVmZXRjaC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBSZXN1bWluZyByZS1hcm1zIGFueSBsb29wcyB3aG9zZSBzZXNzaW9uIGlzIHN0aWxsIHNldC5cbiAgICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICAgIGlmIChzZXNzICE9PSBudWxsKSBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xuICAgICAgfVxuICAgICAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIG1hc3RlciBzd2l0Y2ggdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgfVxuICAgIGNhc2UgJ3N0YXJ0LWF1dG8tc2Nyb2xsJzpcbiAgICAgIGF3YWl0IHN0YXJ0QXV0b1Njcm9sbExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLWF1dG8tc2Nyb2xsJzpcbiAgICAgIGF3YWl0IGNhbmNlbEF1dG9TY3JvbGxMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCc6IHtcbiAgICAgIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICAgICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICAgICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChtc2cuc2Vjb25kcykpXG4gICAgICApO1xuICAgICAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IHNlY29uZHMgfSk7XG4gICAgICAvLyBSZS1hcm0gYW55IGFjdGl2ZSBsb29wcyB3aXRoIHRoZSBuZXcgaW50ZXJ2YWwuXG4gICAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgIGlmIChzZXNzICE9PSBudWxsKSBhcm1BdXRvU2Nyb2xsVGltZXIoc2Vjb25kcyk7XG4gICAgICBpZiAocmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcbiAgICAgIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHMpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAnc3RhcnQtcmVmZXRjaCc6XG4gICAgICBhd2FpdCBzdGFydFJlZmV0Y2hMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1yZWZldGNoJzpcbiAgICAgIGF3YWl0IGNhbmNlbFJlZmV0Y2hMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3N0YXJ0LW1lZGlhLWNyYXdsJzpcbiAgICAgIGF3YWl0IHN0YXJ0TWVkaWFDcmF3bExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLW1lZGlhLWNyYXdsJzpcbiAgICAgIGF3YWl0IGNhbmNlbE1lZGlhQ3Jhd2xMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3B1cmdlLXVucmVsYXRlZCc6IHtcbiAgICAgIGNvbnN0IGFjY3MgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICAgICAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjcy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcbiAgICAgIGNvbnN0IHN1bW1hcnkgPSBhd2FpdCBwdXJnZVVucmVsYXRlZFN0YXRlKHRyYWNrZWQpO1xuICAgICAgYXdhaXQgaW5mbygncHVyZ2VkIHVucmVsYXRlZCBzdGF0ZScsIHN1bW1hcnkpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAncmVmcmVzaC1hY2NvdW50cyc6XG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd2ZXJpZnktY29ubmVjdGlvbic6XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjbGVhci1hY3Rpdml0eSc6XG4gICAgICBhd2FpdCBjbGVhckFjdGl2aXR5KCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tb3B0aW9ucyc6XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tdmlld2VyJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgICBjb25zdCB1cmwgPSB2aWV3ZXJVcmwocyk7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICd1bmtub3duIG1lc3NhZ2UgdHlwZScgfTtcbiAgfVxufVxuXG4vLyAtLS0gQ2FwdHVyZSBwaXBlbGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBvbkdyYXBocWxDYXB0dXJlKFxuICBlbmRwb2ludDogc3RyaW5nLFxuICB1cmw6IHN0cmluZyxcbiAgcGFnZVVybDogc3RyaW5nIHwgbnVsbCxcbiAgcmVzcG9uc2U6IHVua25vd25cbik6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoUFJPRklMRV9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuOyAvLyBub3QgdHdlZXQtYmVhcmluZ1xuICBpZiAoIVRXRUVUX0VORFBPSU5UUy5oYXMoZW5kcG9pbnQpKSByZXR1cm47XG5cbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICAvLyBXZSBkZWxpYmVyYXRlbHkgZG8gTk9UIHNob3J0LWNpcmN1aXQgd2hlbiB0aGUgUEFUIGlzIG1pc3NpbmcuIFRoZVxuICAvLyBub3JtYWxpemUgc3RlcCBpcyBjaGVhcCwgdGhlIGJ1ZmZlciBzdXJ2aXZlcyBzZXJ2aWNlLXdvcmtlciBldmljdGlvbixcbiAgLy8gYW5kIG9uY2UgdGhlIFBBVCBpcyBzZXQgdGhlIG5leHQgYWxhcm0gb3IgdXNlci10cmlnZ2VyZWQgZmx1c2ggY29tbWl0c1xuICAvLyBldmVyeXRoaW5nIHdlJ3ZlIHNlZW4uIERyb3BwaW5nIGNhcHR1cmVzIGhlcmUgd2FzIGhpZGluZyB0aGUgdXNlcidzXG4gIC8vIGZpcnN0IGJyb3dzaW5nIHNlc3Npb24gZW50aXJlbHkuXG5cbiAgLy8gVHdvLXN0YWdlIGZpbHRlcjpcbiAgLy8gICAxLiBCdWlsZCBFVkVSWSBjYW5vbmljYWwgdHdlZXQgd2UgY2FuIGZpbmQgaW4gdGhlIHJlc3BvbnNlIChubyBoYW5kbGVcbiAgLy8gICAgICBmaWx0ZXIgYXQgdGhlIG5vcm1hbGl6ZXIgbGV2ZWwgXHUyMDE0IHdlIHN0aWxsIHdhbnQgcXVvdGVkL1JUJ2QgcGFyZW50c1xuICAvLyAgICAgIHRoYXQgYXBwZWFyIGFzIHNpYmxpbmcgbm9kZXMpLlxuICAvLyAgIDIuIEFwcGx5IGBmaWx0ZXJSZWxhdGVkYCBwb3N0LWhvYyB0byBkcm9wIGFueXRoaW5nIHRoYXQgaGFzIG5vXG4gIC8vICAgICAgcmVsYXRpb25zaGlwIHRvIGEgdHJhY2tlZCBhY2NvdW50LiBUaGUgb2xkIGJlaGF2aW91ciAoXCJlbXB0eVxuICAvLyAgICAgIGFsbG93ZWQtc2V0IG9uIHVzZXItcGFnZSBlbmRwb2ludHMsIGZ1bGwgZmlsdGVyIG9uIGhvbWUvc2VhcmNoXCIpXG4gIC8vICAgICAgd2FzIHdheSB0b28gcGVybWlzc2l2ZSBvbiB0aGUgUmVwbGllcyB0YWI6IGV2ZXJ5IHJhbmRvbSByZXBsaWVyJ3NcbiAgLy8gICAgICByZXBseSBsYW5kZWQgaW4gYSBwZXItaGFuZGxlIGJ1ZmZlciBrZXllZCBieSB0aGVpciBvd24gaGFuZGxlLlxuICBjb25zdCB0cmFja2VkID0gbmV3IFNldChhY2NvdW50cy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcbiAgY29uc3QgY2FwdHVyZWRBdCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICBsZXQgbm9ybWFsaXplZDtcbiAgdHJ5IHtcbiAgICBub3JtYWxpemVkID0gbm9ybWFsaXplKHJlc3BvbnNlLCB7XG4gICAgICBjYXB0dXJlZEF0LFxuICAgICAgcnVuSWQ6ICdwZW5kaW5nJyxcbiAgICAgIGVuZHBvaW50LFxuICAgICAgYWxsb3dlZEhhbmRsZXM6IG5ldyBTZXQ8c3RyaW5nPigpLFxuICAgICAgc291cmNlVXJsOiBwYWdlVXJsLFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCBxdWFyYW50aW5lKCdub3JtYWxpemUtdGhyZXcnLCBlbmRwb2ludCwgdXJsLCByZXNwb25zZSwgZXJyKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gRHJvcCB1bnJlbGF0ZWQgdHdlZXRzLiBUaGUgZmlsdGVyIGlzIGVuZHBvaW50LWF3YXJlOlxuICAvLyAgIC0gT24gdGhlIGhvbWUgLyBzZWFyY2ggdGltZWxpbmVzIHdlJ2QgYWxyZWFkeSBiZWVuIGZpbHRlcmluZyB0b1xuICAvLyAgICAgdHJhY2tlZCBhdXRob3JzIG9ubHkgXHUyMDE0IGtlZXAgdGhhdCBiZWhhdmlvdXIgYnV0IGdvIHRocm91Z2ggdGhlIHNhbWVcbiAgLy8gICAgIGBmaWx0ZXJSZWxhdGVkYCBoZWxwZXIgc28gdGhlIHJ1bGVzIGFyZSB1bmlmb3JtLlxuICAvLyAgIC0gT24gdXNlci1wYWdlIGVuZHBvaW50cyB3ZSBub3cgYWxzbyBkcm9wIGFueXRoaW5nIHRoYXQgaXNuJ3QgZWl0aGVyXG4gIC8vICAgICBhdXRob3JlZC1ieSwgbWVudGlvbmluZywgcmVwbHlpbmctdG8sIG9yIHJlZmVyZW5jZWQtYnkgYSB0cmFja2VkXG4gIC8vICAgICBhY2NvdW50LlxuICBjb25zdCBiZWZvcmVGaWx0ZXIgPSBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGg7XG4gIG5vcm1hbGl6ZWQudHdlZXRzID0gZmlsdGVyUmVsYXRlZChub3JtYWxpemVkLnR3ZWV0cywgdHJhY2tlZCk7XG4gIGNvbnN0IGRyb3BwZWRVbnJlbGF0ZWQgPSBiZWZvcmVGaWx0ZXIgLSBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGg7XG4gIGlmIChkcm9wcGVkVW5yZWxhdGVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2Ryb3BwZWQgdW5yZWxhdGVkIHR3ZWV0cycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgZHJvcHBlZDogZHJvcHBlZFVucmVsYXRlZCxcbiAgICAgIGtlcHQ6IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIERpYWdub3N0aWM6IGV2ZXJ5IHR3ZWV0LWVuZHBvaW50IHBheWxvYWQgZ2V0cyBhIGxpbmUgaW4gdGhlIGFjdGl2aXR5XG4gIC8vIHRhaWwgd2l0aCB3aGF0IHdlIHNhdyB2cyBrZXB0LiBXaGVuIG9ic2VydmVkPTAgd2UgYWxzbyBlbWl0IGEgc2hhcGVcbiAgLy8gcHJvYmUgKGtleSBwYXRocyArIHR5cGVuYW1lcykgc28gd2UgY2FuIHRlbGwgd2hldGhlciBYIHJldHVybmVkIGFuXG4gIC8vIGVtcHR5IGVudmVsb3BlLCBhIGxvZ2luLXdhbGwgcmVzcG9uc2UsIG9yIGEgbmV3IHNoYXBlIHdlIGRvbid0IGtub3cgaG93XG4gIC8vIHRvIHdhbGsgeWV0LlxuICBpZiAobm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygnZ3JhcGhxbCBwYXlsb2FkIGVtcHR5IFx1MjAxNCBzaGFwZSBwcm9iZScsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgdHlwZW5hbWVzOiBwcm9iZVR5cGVuYW1lcyhyZXNwb25zZSkuc2xpY2UoMCwgMzApLFxuICAgICAgdHdlZXRfa2V5czogcHJvYmVGaXJzdFR5cGVTaGFwZShyZXNwb25zZSwgJ1R3ZWV0JyksXG4gICAgICB0d2VldF9jb3JlX2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFsnY29yZSddKSxcbiAgICAgIHR3ZWV0X2xlZ2FjeV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbJ2xlZ2FjeSddKSxcbiAgICAgIHVzZXJfcmVzdWx0c19yZXN1bHRfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xuICAgICAgICAnY29yZScsXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxuICAgICAgICAncmVzdWx0JyxcbiAgICAgIF0pLFxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9jb3JlX2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcbiAgICAgICAgJ3Jlc3VsdCcsXG4gICAgICAgICdjb3JlJyxcbiAgICAgIF0pLFxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9sZWdhY3lfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xuICAgICAgICAnY29yZScsXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxuICAgICAgICAncmVzdWx0JyxcbiAgICAgICAgJ2xlZ2FjeScsXG4gICAgICBdKSxcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBhd2FpdCBpbmZvKCdncmFwaHFsIHBheWxvYWQgc2VlbicsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgb2JzZXJ2ZWQ6IG5vcm1hbGl6ZWQub2JzZXJ2ZWRfaWRzLmxlbmd0aCxcbiAgICAgIGtlcHQ6IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuXG4gIGlmIChub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAvLyBSZWZldGNoIHF1ZXVlIGhvdXNla2VlcGluZyBcdTIwMTQgcnVucyBCRUZPUkUgdGhlIGRlZHVwIHNob3J0LWNpcmN1aXQuIEFcbiAgLy8gcmVmZXRjaCBjYXB0dXJlIGNvbWVzIGJhY2sgd2l0aCB0aGUgc2FtZSBlbmdhZ2VtZW50IGNvdW50cyAod2UncmVcbiAgLy8gb25seSBhZnRlciB0aGUgZnVsbCB0ZXh0KSwgc28gdGhlIGRlZHVwIGJlbG93IHdvdWxkIHNpbGVudGx5IGRyb3BcbiAgLy8gaXQgYW5kIHRoZSBxdWV1ZSB3b3VsZCBuZXZlciBkcmFpbi4gSG9pc3QgdGhlIGVucXVldWUvZGVxdWV1ZSBoZXJlXG4gIC8vIHNvIHRoZSBsb29wIHJlbGlhYmx5IGFkdmFuY2VzIGV2ZW4gd2hlbiBubyBjb21taXQgaGFwcGVucy5cbiAgLy9cbiAgLy8gQWxzbzogaWYgZWl0aGVyIGxvb3AncyBpbmZsaWdodCB0YXJnZXQgYXBwZWFycyBoZXJlLCBtYXJrIHRoZSBsb29wXG4gIC8vIGFzIFwiaW5nZXN0ZWRcIiBzbyB0aGUgbmV4dCB0aWNrIGNhbiBhZHZhbmNlLiBUaGUgd2FpdC1mb3ItaW5nZXN0XG4gIC8vIGd1YXJkIG90aGVyd2lzZSBibG9ja3MgdW50aWwgdGhlIG5hdmlnYXRpb24tdGltZW91dCBmaXJlcy5cbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGlmICh0LmlzX3RydW5jYXRlZCkge1xuICAgICAgYXdhaXQgZW5xdWV1ZVJlZmV0Y2godC5hY2NvdW50X2hhbmRsZSwgdC50d2VldF9pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xuICAgIH1cbiAgICAvLyBTdWNjZXNzZnVsbHkgYnVpbHQgdHdlZXRzIGFyZSBubyBsb25nZXIgXCJwYXJ0aWFsXCIgXHUyMDE0IGRyb3AgZnJvbSB0aGVcbiAgICAvLyBtZWRpYS1jcmF3bCBxdWV1ZSByZWdhcmRsZXNzIG9mIHdoaWNoIGhhbmRsZSB3ZSdkIGhpbnRlZCBlYXJsaWVyLlxuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHQudHdlZXRfaWQpO1xuICAgIGlmIChyZWZldGNoU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcbiAgICAgIHJlZmV0Y2hTZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIHJlZmV0Y2hTZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24ocmVmZXRjaFNlc3MpO1xuICAgIH1cbiAgICBpZiAobWVkaWFDcmF3bFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XG4gICAgICBtZWRpYUNyYXdsU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICBtZWRpYUNyYXdsU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG1lZGlhQ3Jhd2xTZXNzKTtcbiAgICB9XG4gIH1cblxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXQtc2hhcGVkIG5vZGVzIHRoZSB3YWxrZXIgc2F3IGJ1dCBjb3VsZG4ndCB0dXJuXG4gIC8vIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gRW5xdWV1ZSBvbmx5IElEcyB3ZSBoYXZlbid0IGFscmVhZHlcbiAgLy8gY29tbWl0dGVkICh1c2VyLXJlcXVlc3RlZCBkZWR1cCBhZ2FpbnN0IHRoZSBhcmNoaXZlKS5cbiAgZm9yIChjb25zdCBwYXJ0aWFsIG9mIG5vcm1hbGl6ZWQucGFydGlhbF9pZHMpIHtcbiAgICBpZiAoYXdhaXQgaXNDb21taXR0ZWQocGFydGlhbC50d2VldF9pZCkpIGNvbnRpbnVlO1xuICAgIGF3YWl0IGVucXVldWVNZWRpYUNyYXdsKHBhcnRpYWwuaGludF9oYW5kbGUsIHBhcnRpYWwudHdlZXRfaWQpO1xuICB9XG4gIGlmIChub3JtYWxpemVkLnBhcnRpYWxfaWRzLmxlbmd0aCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogZW5xdWV1ZWQgcGFydGlhbCBjYXB0dXJlcycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgcGFydGlhbDogbm9ybWFsaXplZC5wYXJ0aWFsX2lkcy5sZW5ndGgsXG4gICAgICBxdWV1ZV90b3RhbDogYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKSxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIENyb3NzLXNlc3Npb24gZGVkdXA6IGRyb3AgdHdlZXRzIHdlJ3ZlIGFscmVhZHkgY29tbWl0dGVkIHdpdGggaWRlbnRpY2FsXG4gIC8vIGVuZ2FnZW1lbnQgY291bnRzLiBMaWtlcy9SVHMvcmVwbGllcy9xdW90ZXMgc3RpbGwgdHJpZ2dlciBhIHJlY2FwdHVyZVxuICAvLyBzbyBlbmdhZ2VtZW50X2hpc3RvcnkgZ3Jvd3Mgb3ZlciB0aW1lLiB2aWV3X2NvdW50IGlzIGludGVudGlvbmFsbHlcbiAgLy8gZXhjbHVkZWQgXHUyMDE0IGl0IGNodXJucyB0b28gZmFzdCB0byBiZSB1c2VmdWwgYXMgYSBmcmVzaG5lc3Mgc2lnbmFsLlxuICAvLyBgaXNfdHJ1bmNhdGVkYCBpcyBwYXJ0IG9mIHRoZSBzaWduYXR1cmUgc28gYSByZWZldGNoIHRoYXQgZmxpcHNcbiAgLy8gdHJ1bmNhdGVkXHUyMTkyZnVsbCBpcyB0cmVhdGVkIGFzIGEgbWF0ZXJpYWwgY2hhbmdlIGFuZCBnZXRzIGNvbW1pdHRlZC5cbiAgY29uc3QgY29tbWl0dGVkSWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgbGV0IGRlZHVwZWRTa2lwcGVkID0gMDtcbiAgY29uc3QgbGl2ZVR3ZWV0czogdHlwZW9mIG5vcm1hbGl6ZWQudHdlZXRzID0gW107XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbdC5hY2NvdW50X2hhbmRsZV0/Llt0LnR3ZWV0X2lkXTtcbiAgICBjb25zdCBzaWcgPSBlbmdhZ2VtZW50U2lnKFxuICAgICAgdC5saWtlX2NvdW50LFxuICAgICAgdC5yZXR3ZWV0X2NvdW50LFxuICAgICAgdC5yZXBseV9jb3VudCxcbiAgICAgIHQucXVvdGVfY291bnQsXG4gICAgICB0LmlzX3RydW5jYXRlZFxuICAgICk7XG4gICAgaWYgKHByZXYgJiYgcHJldi5zaWcgPT09IHNpZykge1xuICAgICAgZGVkdXBlZFNraXBwZWQgKz0gMTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBsaXZlVHdlZXRzLnB1c2godCk7XG4gIH1cbiAgaWYgKGRlZHVwZWRTa2lwcGVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2RlZHVwOiBza2lwcGVkIHVuY2hhbmdlZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHNraXBwZWQ6IGRlZHVwZWRTa2lwcGVkLFxuICAgICAgcmVtYWluaW5nOiBsaXZlVHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuICBpZiAobGl2ZVR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAvLyBHcm91cCBzdXJ2aXZpbmcgdHdlZXRzIGJ5IGF1dGhvciBoYW5kbGUuXG4gIGNvbnN0IGJ5SGFuZGxlID0gbmV3IE1hcDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0W10+KCk7XG4gIGZvciAoY29uc3QgdCBvZiBsaXZlVHdlZXRzKSB7XG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUpID8/IFtdO1xuICAgIGFyci5wdXNoKHQpO1xuICAgIGJ5SGFuZGxlLnNldCh0LmFjY291bnRfaGFuZGxlLCBhcnIpO1xuICB9XG5cbiAgZm9yIChjb25zdCBbaGFuZGxlLCB0d2VldHNdIG9mIGJ5SGFuZGxlKSB7XG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgdXJsLCBlbmRwb2ludCk7XG4gICAgbGV0IGFkZGVkID0gMDtcbiAgICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgICBjb25zdCBleGlzdGluZyA9IGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF07XG4gICAgICBpZiAoZXhpc3RpbmcpIHtcbiAgICAgICAgLy8gUHJlc2VydmUgZmlyc3RfY2FwdHVyZWRfYXQsIGFwcGVuZCBlbmdhZ2VtZW50IHNuYXBzaG90LCByZWZyZXNoXG4gICAgICAgIC8vIGxhc3Rfc2Vlbl9hdCArIGNvdW50cyAodGhlIGxhdGVzdCBzY3JhcGUgd2lucyBmb3IgY291bnRzKS5cbiAgICAgICAgZXhpc3RpbmcubGFzdF9zZWVuX2F0ID0gY2FwdHVyZWRBdDtcbiAgICAgICAgZXhpc3RpbmcubGlrZV9jb3VudCA9IHQubGlrZV9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmV0d2VldF9jb3VudCA9IHQucmV0d2VldF9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmVwbHlfY291bnQgPSB0LnJlcGx5X2NvdW50O1xuICAgICAgICBleGlzdGluZy5xdW90ZV9jb3VudCA9IHQucXVvdGVfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnZpZXdfY291bnQgPSB0LnZpZXdfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLmJvb2ttYXJrX2NvdW50ID0gdC5ib29rbWFya19jb3VudDtcbiAgICAgICAgY29uc3QgbGFzdCA9IGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeVtleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnkubGVuZ3RoIC0gMV07XG4gICAgICAgIGNvbnN0IHNuYXAgPSB0LmVuZ2FnZW1lbnRfaGlzdG9yeVswXTtcbiAgICAgICAgaWYgKHNuYXAgJiYgKCFsYXN0IHx8IGxhc3QuY2FwdHVyZWRfYXQgIT09IHNuYXAuY2FwdHVyZWRfYXQpKSB7XG4gICAgICAgICAgZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5LnB1c2goc25hcCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHN0YW1wZWQ6IENhbm9uaWNhbFR3ZWV0ID0geyAuLi50LCBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCB9O1xuICAgICAgICBidWYudHdlZXRzX2J5X2lkW3QudHdlZXRfaWRdID0gc3RhbXBlZDtcbiAgICAgICAgYWRkZWQgKz0gMTtcbiAgICAgIH1cbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyh0LnR3ZWV0X2lkKSkge1xuICAgICAgICBidWYudHdlZXRfaWRzX29ic2VydmVkLnB1c2godC50d2VldF9pZCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xuICAgIGJ1Zi5sYXN0X2NhcHR1cmVfYXQgPSBjYXB0dXJlZEF0O1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCk7XG4gICAgaWYgKGFkZGVkID4gMCkge1xuICAgICAgYXdhaXQgaW5mbygnY2FwdHVyZWQgdHdlZXRzJywge1xuICAgICAgICBoYW5kbGUsXG4gICAgICAgIGVuZHBvaW50LFxuICAgICAgICBhZGRlZCxcbiAgICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCxcbiAgICAgIH0pO1xuICAgICAgLy8gQnVtcCB0aGUgYXV0by1zY3JvbGwgcHJvZ3Jlc3Mgc28gdGhlIHVzZXIgc2VlcyBcIlggaW5nZXN0ZWRcIiB0aWNrIHVwXG4gICAgICAvLyBpbiByZWFsIHRpbWUuIFdlIGNvdW50IGFjdHVhbGx5LW5ldyB0d2VldHMsIG5vdCBkdXBsaWNhdGVzLlxuICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgIGlmIChhc1Nlc3MgIT09IG51bGwpIHtcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkQ291bnQgKz0gYWRkZWQ7XG4gICAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKGFzU2Vzcyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggPj0gRkxVU0hfVFdFRVRfVEhSRVNIT0xEKSB7XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICd0aHJlc2hvbGQnKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlUnVuQnVmZmVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgdHM6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8UnVuQnVmZmVyPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpO1xuICBpZiAoY3VyKSByZXR1cm4gY3VyO1xuICBjb25zdCBidWY6IFJ1bkJ1ZmZlciA9IHtcbiAgICBydW5faWQ6IG5ld1J1bklkKCksXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBzdGFydGVkX2F0OiB0cyxcbiAgICBsYXN0X2NhcHR1cmVfYXQ6IHRzLFxuICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcbiAgICBlbmRwb2ludHNfc2VlbjogW2VuZHBvaW50XSxcbiAgICBzb3VyY2VfdXJsOiBzb3VyY2VVcmwsXG4gIH07XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gIGF3YWl0IGluZm8oJ3J1biBzdGFydGVkJywgeyBoYW5kbGUsIHJ1bjogc2hvcnRSdW5JZChidWYucnVuX2lkKSB9KTtcbiAgcmV0dXJuIGJ1Zjtcbn1cblxuLy8gLS0tIEZsdXNoIGxvZ2ljIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxubGV0IGZsdXNoQ2hhaW46IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKTtcblxuaW50ZXJmYWNlIEZsdXNoSXRlbSB7XG4gIGhhbmRsZTogc3RyaW5nO1xuICBidWY6IFJ1bkJ1ZmZlcjtcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdO1xuICByYXdQYXRoOiBzdHJpbmc7XG4gIHNlZW5QYXRoOiBzdHJpbmc7XG4gIGNhcHR1cmU6IENhcHR1cmVQYXlsb2FkO1xuICBzZWVuOiBTZWVuUGF5bG9hZDtcbiAgZGF5OiBzdHJpbmc7XG4gIHJ1blNob3J0OiBzdHJpbmc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSWRsZUJ1ZmZlcnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgY29uc3QgaGFuZGxlczogc3RyaW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xuICAgICAgaGFuZGxlcy5wdXNoKGhhbmRsZSk7XG4gICAgfVxuICB9XG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhoYW5kbGVzLCAnaWRsZScpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIE9uIHdvcmtlciB3YWtlLCBhbnkgYnVmZmVyIG9sZGVyIHRoYW4gdGhlIGlkbGUgdGhyZXNob2xkIGdldHMgYSBjaGFuY2UgdG9cbiAgLy8gY29tbWl0IGltbWVkaWF0ZWx5IFx1MjAxNCB1c2VmdWwgd2hlbiB0aGUgd29ya2VyIHdhcyBldmljdGVkIGJlZm9yZSBpZGxlLWZsdXNoLlxuICAvLyBJZiB0aGUgUEFUL293bmVyL3JlcG8gYXJlbid0IHNldCB3ZSdkIGp1c3QgZW1pdCBcImZsdXNoIGRlZmVycmVkXCIgZm9yIGV2ZXJ5XG4gIC8vIHNpbmdsZSBoYW5kbGUgaW4gc3RvcmFnZSAodGhlIGRpYWdub3N0aWMgc2hvd2VkIHRoaXMgZmlyaW5nIDMwMCsgdGltZXMgaW5cbiAgLy8gYSByb3cgd2hlbiB0aGUgZXh0ZW5zaW9uIHdva2UgYmVmb3JlIHNldHRpbmdzIGxvYWQpLCBzbyBzaG9ydC1jaXJjdWl0XG4gIC8vIGhlcmUgaW5zdGVhZC5cbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBjb25zdCBoYW5kbGVzOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XG4gICAgICBoYW5kbGVzLnB1c2goaGFuZGxlKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgZmx1c2hIYW5kbGVzKGhhbmRsZXMsICd3YWtlJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoQWxsKHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKE9iamVjdC5rZXlzKGFsbCksIHJlYXNvbik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlKGhhbmRsZTogc3RyaW5nLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBmbHVzaEhhbmRsZXMoW2hhbmRsZV0sIHJlYXNvbik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlcyhoYW5kbGVzOiBzdHJpbmdbXSwgcmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdW5pcXVlID0gWy4uLm5ldyBTZXQoaGFuZGxlcyldLmZpbHRlcigoaCkgPT4gaC5sZW5ndGggPiAwKTtcbiAgaWYgKHVuaXF1ZS5sZW5ndGggPT09IDApIHJldHVybjtcbiAgY29uc3QgcnVuID0gZmx1c2hDaGFpbi50aGVuKCgpID0+IGZsdXNoSGFuZGxlc0xvY2tlZCh1bmlxdWUsIHJlYXNvbikpO1xuICBmbHVzaENoYWluID0gcnVuLmNhdGNoKCgpID0+IHt9KTtcbiAgcmV0dXJuIHJ1bjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGVzTG9ja2VkKGhhbmRsZXM6IHN0cmluZ1tdLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGNvbnN0IGl0ZW1zOiBGbHVzaEl0ZW1bXSA9IFtdO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBoYW5kbGVzKSB7XG4gICAgY29uc3QgYnVmID0gYWxsW2hhbmRsZV07XG4gICAgaWYgKCFidWYpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHR3ZWV0cyA9IE9iamVjdC52YWx1ZXMoYnVmLnR3ZWV0c19ieV9pZCk7XG4gICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApIHtcbiAgICAgIGF3YWl0IGNsZWFyUnVuQnVmZmVyKGhhbmRsZSk7XG4gICAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgMCk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaXRlbXMucHVzaChidWlsZEZsdXNoSXRlbShoYW5kbGUsIGJ1ZiwgdHdlZXRzKSk7XG4gIH1cbiAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSB7XG4gICAgYXdhaXQgd2FybignZmx1c2ggZGVmZXJyZWQ6IHNldHRpbmdzIGluY29tcGxldGUnLCB7XG4gICAgICBjb3VudDogaXRlbXMubGVuZ3RoLFxuICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgY29uc3QgZmlsZXMgPSBpdGVtcy5mbGF0TWFwKChpdGVtKSA9PiBbXG4gICAge1xuICAgICAgcGF0aDogaXRlbS5yYXdQYXRoLFxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkoaXRlbS5jYXB0dXJlLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICB9LFxuICAgIHtcbiAgICAgIHBhdGg6IGl0ZW0uc2VlblBhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShpdGVtLnNlZW4sIG51bGwsIDIpICsgJ1xcbicpLFxuICAgIH0sXG4gIF0pO1xuICBjb25zdCBjb21taXRNc2cgPSBidWlsZEJhdGNoQ29tbWl0TWVzc2FnZShpdGVtcyk7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQuY29tbWl0RmlsZXMoe1xuICAgICAgZmlsZXMsXG4gICAgICBtZXNzYWdlOiBjb21taXRNc2csXG4gICAgfSk7XG4gICAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgaXRlbXMpIHtcbiAgICAgIGNvbnN0IHJlbWFpbmluZ0NvdW50ID0gYXdhaXQgY2xlYXJDb21taXR0ZWRUd2VldHNGcm9tQnVmZmVyKGl0ZW0pO1xuICAgICAgLy8gQ291bnRlciBidW1wOiBhY3R1YWxseSBJTkNSRU1FTlQgdG9kYXlDb3VudCBhbmQgdG90YWxDb21taXR0ZWQgYnlcbiAgICAgIC8vIHRoZSBudW1iZXIgb2YgdHdlZXRzIHdlIGp1c3QgcGVyc2lzdGVkICh0aGUgcHJldmlvdXMgY29kZSByZWFkIHRoZVxuICAgICAgLy8gZXhpc3RpbmcgdmFsdWVzIGFuZCB3cm90ZSB0aGVtIGJhY2ssIGxlYXZpbmcgdGhlIGNvdW50ZXIgcGVnZ2VkIGF0XG4gICAgICAvLyB6ZXJvKS5cbiAgICAgIGNvbnN0IHByZXYgPSAoYXdhaXQgZ2V0Q291bnRlcnMoKSlbaXRlbS5oYW5kbGVdO1xuICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuICAgICAgY29uc3QgY2FycmllZFRvZGF5ID0gcHJldiAmJiBwcmV2LnRvZGF5RGF0ZSA9PT0gdG9kYXkgPyBwcmV2LnRvZGF5Q291bnQgOiAwO1xuICAgICAgYXdhaXQgYnVtcENvdW50ZXIoaXRlbS5oYW5kbGUsIHtcbiAgICAgICAgdG9kYXlDb3VudDogY2FycmllZFRvZGF5ICsgaXRlbS50d2VldHMubGVuZ3RoLFxuICAgICAgICB0b2RheURhdGU6IHRvZGF5LFxuICAgICAgICBsYXN0Q2FwdHVyZUF0OiBpdGVtLmJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICAgIHRvdGFsQ29tbWl0dGVkOiAocHJldj8udG90YWxDb21taXR0ZWQgPz8gMCkgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIGJ1ZmZlcmVkQ291bnQ6IHJlbWFpbmluZ0NvdW50LFxuICAgICAgfSk7XG4gICAgICAvLyBSZWNvcmQgY29tbWl0cyBpbiB0aGUgZGVkdXAgaW5kZXggc28gd2UgZG9uJ3QgcmUtY29tbWl0IHRoZW0gbmV4dFxuICAgICAgLy8gYnJvd3NlIHdpdGggdW5jaGFuZ2VkIGVuZ2FnZW1lbnQuXG4gICAgICBjb25zdCBpbm5lciA9IGlkeFtpdGVtLmhhbmRsZV0gPz8ge307XG4gICAgICBjb25zdCBub3dJc28gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgICBmb3IgKGNvbnN0IHQgb2YgaXRlbS50d2VldHMpIHtcbiAgICAgICAgaW5uZXJbdC50d2VldF9pZF0gPSB7XG4gICAgICAgICAgdHM6IG5vd0lzbyxcbiAgICAgICAgICBzaWc6IGVuZ2FnZW1lbnRTaWcoXG4gICAgICAgICAgICB0Lmxpa2VfY291bnQsXG4gICAgICAgICAgICB0LnJldHdlZXRfY291bnQsXG4gICAgICAgICAgICB0LnJlcGx5X2NvdW50LFxuICAgICAgICAgICAgdC5xdW90ZV9jb3VudCxcbiAgICAgICAgICAgIHQuaXNfdHJ1bmNhdGVkXG4gICAgICAgICAgKSxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGlkeFtpdGVtLmhhbmRsZV0gPSBpbm5lcjtcbiAgICAgIGF3YWl0IGluZm8oJ2ZsdXNoIGNvbW1pdHRlZCcsIHtcbiAgICAgICAgaGFuZGxlOiBpdGVtLmhhbmRsZSxcbiAgICAgICAgcmVhc29uLFxuICAgICAgICB0d2VldHM6IGl0ZW0udHdlZXRzLmxlbmd0aCxcbiAgICAgICAgcnVuOiBpdGVtLnJ1blNob3J0LFxuICAgICAgICBwYXRoOiBpdGVtLnJhd1BhdGgsXG4gICAgICAgIGJhdGNoX2NvbW1pdDogcmVzdWx0LmNvbW1pdFNoYSxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xuICAgIGF3YWl0IGluZm8oJ2ZsdXNoIGJhdGNoIGNvbW1pdHRlZCcsIHtcbiAgICAgIHJlYXNvbixcbiAgICAgIHJ1bnM6IGl0ZW1zLmxlbmd0aCxcbiAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXG4gICAgICB0d2VldHM6IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS50d2VldHMubGVuZ3RoLCAwKSxcbiAgICAgIGNvbW1pdDogcmVzdWx0LmNvbW1pdFNoYSxcbiAgICB9KTtcbiAgICB7XG4gICAgICBjb25zdCBwcmV2ID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICAgIHN0YXR1czogJ29rJyxcbiAgICAgICAgbG9naW46IHByZXYubG9naW4sXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogcHJldi5kZWZhdWx0QnJhbmNoLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBwcmV2LmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgICB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvcikge1xuICAgICAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XG4gICAgICAgIGVyci5jYXRlZ29yeSA9PT0gJ2F1dGgnXG4gICAgICAgICAgPyAnYXV0aC1lcnJvcidcbiAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnXG4gICAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ25ldHdvcmsnXG4gICAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXG4gICAgICAgICAgICAgIDogY29ubi5zdGF0dXM7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzLFxuICAgICAgICBsb2dpbjogY29ubi5sb2dpbixcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBlcnIubWVzc2FnZSxcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogY29ubi5kZWZhdWx0QnJhbmNoLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBjb25uLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6XG4gICAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyBlcnIucmF0ZUxpbWl0UmVzZXRBdCA6IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgbG9nRXJyKCdmbHVzaCBmYWlsZWQnLCB7XG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxuICAgICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXG4gICAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXG4gICAgICAgIGNhdGVnb3J5OiBlcnIuY2F0ZWdvcnksXG4gICAgICAgIHN0YXR1czogZXJyLnN0YXR1cyxcbiAgICAgICAgbWVzc2FnZTogZXJyLm1lc3NhZ2UsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGVyci5yYXRlTGltaXRSZXNldEF0LFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGxvZ0VycignZmx1c2ggZmFpbGVkJywge1xuICAgICAgICByZWFzb24sXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcbiAgICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgICB9KTtcbiAgICB9XG4gICAgLy8gTGVhdmUgYnVmZmVyIGludGFjdCBmb3IgcmV0cnkuXG4gIH0gZmluYWxseSB7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBidWlsZEZsdXNoSXRlbShoYW5kbGU6IHN0cmluZywgYnVmOiBSdW5CdWZmZXIsIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSk6IEZsdXNoSXRlbSB7XG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChidWYuc3RhcnRlZF9hdCk7XG4gIGNvbnN0IGRheSA9IGJ1Zi5zdGFydGVkX2F0LnNsaWNlKDAsIDEwKTtcbiAgY29uc3QgcnVuU2hvcnQgPSBzaG9ydFJ1bklkKGJ1Zi5ydW5faWQpO1xuICBjb25zdCByYXdQYXRoID0gYHJhdy8ke2hhbmRsZX0vJHt0c30tJHtydW5TaG9ydH0uanNvbmA7XG4gIGNvbnN0IHNlZW5QYXRoID0gYHNlZW4vJHtoYW5kbGV9LyR7dHN9LSR7cnVuU2hvcnR9Lmpzb25gO1xuICByZXR1cm4ge1xuICAgIGhhbmRsZSxcbiAgICBidWYsXG4gICAgdHdlZXRzLFxuICAgIHJhd1BhdGgsXG4gICAgc2VlblBhdGgsXG4gICAgZGF5LFxuICAgIHJ1blNob3J0LFxuICAgIGNhcHR1cmU6IHtcbiAgICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICBlbmRwb2ludDogYnVmLmVuZHBvaW50c19zZWVuLmpvaW4oJywnKSxcbiAgICAgIHVzZXJfYWdlbnQ6IG5hdmlnYXRvci51c2VyQWdlbnQsXG4gICAgICBzb3VyY2VfdXJsOiBidWYuc291cmNlX3VybCxcbiAgICAgIHR3ZWV0cyxcbiAgICB9LFxuICAgIHNlZW46IHtcbiAgICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQsXG4gICAgfSxcbiAgfTtcbn1cblxuZnVuY3Rpb24gYnVpbGRCYXRjaENvbW1pdE1lc3NhZ2UoaXRlbXM6IEZsdXNoSXRlbVtdKTogc3RyaW5nIHtcbiAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMSkge1xuICAgIGNvbnN0IGl0ZW0gPSBpdGVtc1swXSE7XG4gICAgcmV0dXJuIGBjYXB0dXJlOiAke2l0ZW0uaGFuZGxlfSAke2l0ZW0uZGF5fSAke2l0ZW0udHdlZXRzLmxlbmd0aH0gdHdlZXQke2l0ZW0udHdlZXRzLmxlbmd0aCA9PT0gMSA/ICcnIDogJ3MnfSAocnVuICR7aXRlbS5ydW5TaG9ydH0pYDtcbiAgfVxuICBjb25zdCBkYXlzID0gWy4uLm5ldyBTZXQoaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmRheSkpXS5zb3J0KCk7XG4gIGNvbnN0IGRheUxhYmVsID0gZGF5cy5sZW5ndGggPT09IDEgPyBkYXlzWzBdISA6IGAke2RheXNbMF19Li4ke2RheXNbZGF5cy5sZW5ndGggLSAxXX1gO1xuICBjb25zdCB0d2VldENvdW50ID0gaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApO1xuICByZXR1cm4gYGNhcHR1cmUgYmF0Y2g6ICR7aXRlbXMubGVuZ3RofSBydW5zLCAke3R3ZWV0Q291bnR9IHR3ZWV0JHt0d2VldENvdW50ID09PSAxID8gJycgOiAncyd9ICgke2RheUxhYmVsfSlgO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjbGVhckNvbW1pdHRlZFR3ZWV0c0Zyb21CdWZmZXIoaXRlbTogRmx1c2hJdGVtKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgY3VycmVudCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSk7XG4gIGlmICghY3VycmVudCkgcmV0dXJuIDA7XG4gIGlmIChjdXJyZW50LnJ1bl9pZCAhPT0gaXRlbS5idWYucnVuX2lkKSByZXR1cm4gT2JqZWN0LmtleXMoY3VycmVudC50d2VldHNfYnlfaWQpLmxlbmd0aDtcblxuICBjb25zdCBjb21taXR0ZWQgPSBuZXcgTWFwKFxuICAgIGl0ZW0udHdlZXRzLm1hcCgodCkgPT4gW1xuICAgICAgdC50d2VldF9pZCxcbiAgICAgIGVuZ2FnZW1lbnRTaWcodC5saWtlX2NvdW50LCB0LnJldHdlZXRfY291bnQsIHQucmVwbHlfY291bnQsIHQucXVvdGVfY291bnQsIHQuaXNfdHJ1bmNhdGVkKSxcbiAgICBdKVxuICApO1xuICBjb25zdCByZW1haW5pbmdUd2VldHM6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PiA9IHt9O1xuICBmb3IgKGNvbnN0IFt0d2VldElkLCB0d2VldF0gb2YgT2JqZWN0LmVudHJpZXMoY3VycmVudC50d2VldHNfYnlfaWQpKSB7XG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcbiAgICBjb25zdCBjdXJyZW50U2lnID0gZW5nYWdlbWVudFNpZyhcbiAgICAgIHR3ZWV0Lmxpa2VfY291bnQsXG4gICAgICB0d2VldC5yZXR3ZWV0X2NvdW50LFxuICAgICAgdHdlZXQucmVwbHlfY291bnQsXG4gICAgICB0d2VldC5xdW90ZV9jb3VudCxcbiAgICAgIHR3ZWV0LmlzX3RydW5jYXRlZFxuICAgICk7XG4gICAgaWYgKCFjb21taXR0ZWRTaWcgfHwgY29tbWl0dGVkU2lnICE9PSBjdXJyZW50U2lnKSB7XG4gICAgICByZW1haW5pbmdUd2VldHNbdHdlZXRJZF0gPSB7IC4uLnR3ZWV0IH07XG4gICAgfVxuICB9XG5cbiAgY29uc3QgcmVtYWluaW5nQ291bnQgPSBPYmplY3Qua2V5cyhyZW1haW5pbmdUd2VldHMpLmxlbmd0aDtcbiAgaWYgKHJlbWFpbmluZ0NvdW50ID09PSAwKSB7XG4gICAgYXdhaXQgY2xlYXJSdW5CdWZmZXIoaXRlbS5oYW5kbGUpO1xuICAgIHJldHVybiAwO1xuICB9XG5cbiAgY29uc3QgbmV4dFJ1bklkID0gbmV3UnVuSWQoKTtcbiAgZm9yIChjb25zdCB0d2VldCBvZiBPYmplY3QudmFsdWVzKHJlbWFpbmluZ1R3ZWV0cykpIHtcbiAgICB0d2VldC5jYXB0dXJlX3J1bl9pZCA9IG5leHRSdW5JZDtcbiAgfVxuICBhd2FpdCBzZXRSdW5CdWZmZXIoaXRlbS5oYW5kbGUsIHtcbiAgICAuLi5jdXJyZW50LFxuICAgIHJ1bl9pZDogbmV4dFJ1bklkLFxuICAgIHN0YXJ0ZWRfYXQ6IGN1cnJlbnQubGFzdF9jYXB0dXJlX2F0LFxuICAgIHR3ZWV0c19ieV9pZDogcmVtYWluaW5nVHdlZXRzLFxuICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogY3VycmVudC50d2VldF9pZHNfb2JzZXJ2ZWQuZmlsdGVyKChpZCkgPT4gaWQgaW4gcmVtYWluaW5nVHdlZXRzKSxcbiAgfSk7XG4gIGF3YWl0IGluZm8oJ2ZsdXNoIGtlcHQgbmV3ZXIgYnVmZmVyZWQgdHdlZXRzJywge1xuICAgIGhhbmRsZTogaXRlbS5oYW5kbGUsXG4gICAgY29tbWl0dGVkX3J1bjogaXRlbS5ydW5TaG9ydCxcbiAgICBuZXh0X3J1bjogc2hvcnRSdW5JZChuZXh0UnVuSWQpLFxuICAgIHJlbWFpbmluZzogcmVtYWluaW5nQ291bnQsXG4gIH0pO1xuICByZXR1cm4gcmVtYWluaW5nQ291bnQ7XG59XG5cbi8vIC0tLSBDYXB0dXJlLW5vdyAvIGNhcHR1cmUtYWxsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gY2FwdHVyZU5vdyhoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBMYW5kIG9uIHRoZSBSZXBsaWVzIHRhYiBzbyBYIGZldGNoZXMgdmlhIFVzZXJUd2VldHNBbmRSZXBsaWVzIFx1MjAxNCB0aGF0XG4gIC8vIGVuZHBvaW50IHJldHVybnMgYm90aCB0b3AtbGV2ZWwgcG9zdHMgYW5kIHJlcGxpZXMsIHdoaWNoIGlzIHRoZSBzdXBlcnNldFxuICAvLyB3ZSB3YW50IGZvciB0aGUgYXJjaGl2ZS4gVGhlIHBsYWluIGAvPGhhbmRsZT5gIFVSTCBoaXRzIFVzZXJUd2VldHMsXG4gIC8vIHdoaWNoIG9taXRzIHJlcGxpZXMuIFRoZSBwYWdlLWhvb2sgaW50ZXJjZXB0cyBlaXRoZXIgZW5kcG9pbnQsIGJ1dFxuICAvLyBmb3JjaW5nIHRoZSBicm9hZGVyIHRhYiBvbiB1c2VyLWluaXRpYXRlZCBjYXB0dXJlcyBpcyB0aGUgcmlnaHQgZGVmYXVsdC5cbiAgY29uc3QgdGFyZ2V0VXJsID0gYGh0dHBzOi8veC5jb20vJHtoYW5kbGV9L3dpdGhfcmVwbGllc2A7XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtbm93IHJlcXVlc3RlZCcsIHsgaGFuZGxlLCB0YWI6ICd3aXRoX3JlcGxpZXMnIH0pO1xuICBpZiAoIShhd2FpdCBnZXRSdW5CdWZmZXIoaGFuZGxlKSkpIHtcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwge1xuICAgICAgcnVuX2lkOiBuZXdSdW5JZCgpLFxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICAgIHN0YXJ0ZWRfYXQ6IG5vdyxcbiAgICAgIGxhc3RfY2FwdHVyZV9hdDogbm93LFxuICAgICAgdHdlZXRzX2J5X2lkOiB7fSxcbiAgICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogW10sXG4gICAgICBlbmRwb2ludHNfc2VlbjogW10sXG4gICAgICBzb3VyY2VfdXJsOiB0YXJnZXRVcmwsXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogdGFyZ2V0VXJsLCBhY3RpdmU6IHRydWUgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVBbGwoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgYXdhaXQgaW5mbygnY2FwdHVyZS1hbGwgcmVxdWVzdGVkJywgeyBjb3VudDogYWNjb3VudHMubGVuZ3RoIH0pO1xuICBmb3IgKGNvbnN0IGEgb2YgYWNjb3VudHMpIHtcbiAgICBhd2FpdCBjYXB0dXJlTm93KGEuaGFuZGxlKTtcbiAgfVxufVxuXG4vKipcbiAqIENhcHR1cmUgd2hhdGV2ZXIgdGhlIHVzZXIgaXMgY3VycmVudGx5IGxvb2tpbmcgYXQ6IGVuc3VyZXMgcGFnZS1ob29rIGlzXG4gKiBwYXRjaGVkIGludG8gdGhlIGFjdGl2ZSB0YWIsIHRoZW4gbnVkZ2VzIHRoZSBwYWdlIHdpdGggYSBwcm9ncmFtbWF0aWNcbiAqIHNjcm9sbCBzbyBYIGZpcmVzIGFub3RoZXIgYmF0Y2ggb2YgR3JhcGhRTCByZXF1ZXN0cyB3ZSBjYW4gaW50ZXJjZXB0LlxuICpcbiAqIExlc3MgZGlzcnVwdGl2ZSB0aGFuIGBDYXB0dXJlIG5vd2AgKG5vIG5ldyB0YWIsIG5vIG5hdmlnYXRpb24pIGFuZCB3b3Jrc1xuICogZm9yIGFyYml0cmFyeSBYIFVSTHMgKHNwZWNpZmljIHR3ZWV0IHRocmVhZHMsIHNlYXJjaCByZXN1bHRzLCBsaXN0cylcbiAqIHRoYXQgZG9uJ3QgbWFwIGNsZWFubHkgdG8gb25lIG9mIHRoZSBjb25maWd1cmVkIGhhbmRsZXMuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVUaGlzUGFnZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcbiAgdHJ5IHtcbiAgICB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogY291bGQgbm90IHF1ZXJ5IGFjdGl2ZSB0YWInLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCB0YWIgPSB0YWJzWzBdO1xuICBpZiAoIXRhYiB8fCB0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJyB8fCAhdGFiLnVybCkge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBubyBhY3RpdmUgdGFiJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICghL15odHRwczpcXC9cXC8oeHx0d2l0dGVyKVxcLmNvbVxcLy8udGVzdCh0YWIudXJsKSkge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBhY3RpdmUgdGFiIGlzIG5vdCBvbiB4LmNvbSAvIHR3aXR0ZXIuY29tJywge1xuICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwpLFxuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuICBhd2FpdCBpbmZvKCdjYXB0dXJlLXRoaXMtcGFnZSByZXF1ZXN0ZWQnLCB7IHVybDogc2hvcnRlblVybCh0YWIudXJsKSB9KTtcbiAgLy8gKFJlLSlpbmplY3QgdGhlIHBhZ2UtaG9vayArIGlzb2xhdGVkIGNvbnRlbnQgc2NyaXB0IHNvIGZldGNoL1hIUiBhcmVcbiAgLy8gcGF0Y2hlZCBldmVuIG9uIHRhYnMgb3BlbmVkIGJlZm9yZSB0aGUgZXh0ZW5zaW9uIHJlbG9hZGVkLlxuICB0cnkge1xuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgIGZpbGVzOiBbJ3BhZ2UtaG9vay5qcyddLFxuICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgIH0pO1xuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgIGZpbGVzOiBbJ2NvbnRlbnQuanMnXSxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IHJlLWluamVjdCBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG4gIC8vIE51ZGdlIFggdG8gZmlyZSBtb3JlIEdyYXBoUUwgcmVxdWVzdHMgYnkgc2Nyb2xsaW5nLiBNb3N0IHRpbWVsaW5lIC9cbiAgLy8gY29udmVyc2F0aW9uIHZpZXdzIGZldGNoIG9uIGludGVyc2VjdGlvbi1vYnNlcnZlciB0cmlnZ2Vycy5cbiAgdHJ5IHtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXG4gICAgICBmdW5jOiAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGggPSB3aW5kb3cuaW5uZXJIZWlnaHQ7XG4gICAgICAgIHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuNSwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuNSwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pLCA2MDApO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuNSwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pLCAxMjAwKTtcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBzY3JvbGwtbnVkZ2UgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxufVxuXG4vLyAtLS0gUmVmZXRjaCBsb29wIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy9cbi8vIFggdHJ1bmNhdGVzIGxvbmcgdHdlZXRzIGluIHRpbWVsaW5lIHBheWxvYWRzIFx1MjAxNCBgbm90ZV90d2VldGAgaXMgb25seVxuLy8gaW5saW5lZCBmb3Igc29tZSBlbmRwb2ludHMuIFJlLW9wZW5pbmcgZWFjaCB0cnVuY2F0ZWQgdHdlZXQncyBkZXRhaWwgcGFnZVxuLy8gY2F1c2VzIHRoZSBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgZnVsbCBgbm90ZV90d2VldGAgYm9keS4gVGhlIGxvb3Bcbi8vIGRyaXZlcyB0aGF0IGJ5IG5hdmlnYXRpbmcgYSBzaW5nbGUgZGVkaWNhdGVkIHRhYiB0aHJvdWdoIHRoZSBxdWV1ZSwgb25lXG4vLyB0d2VldCBhdCBhIHRpbWUsIGdhdGVkIG9uIHRoZSBwYWdlLWhvb2sgYWN0dWFsbHkgaW5nZXN0aW5nIGEgcmVzcG9uc2UgZm9yXG4vLyB0aGUgdHdlZXQgd2UganVzdCBuYXZpZ2F0ZWQgdG8gKHNvIGRlbGV0ZWQgLyBwYXl3YWxsZWQgLyA0MDQnZCB0d2VldHNcbi8vIGRvbid0IG1ha2UgdXMgc3BpbiBhbmQgc28gd2UgZG9uJ3Qgc2xhbSBYIHdpdGggcmVmcmVzaGVzIGZhc3RlciB0aGFuIHRoZVxuLy8gdGFiIGNhbiBsb2FkKS5cblxuY29uc3QgUkVGRVRDSF9UQUJfS0VZID0gJ19faW1tX2FyY2hpdmVfcmVmZXRjaF90YWJfaWRfXyc7XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hUYWJJZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChSRUZFVENIX1RBQl9LRVkpO1xuICBjb25zdCBpZCA9IHN0b3JlZFtSRUZFVENIX1RBQl9LRVldO1xuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0UmVmZXRjaFRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChpZCA9PT0gbnVsbCkge1xuICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5yZW1vdmUoUkVGRVRDSF9UQUJfS0VZKTtcbiAgfSBlbHNlIHtcbiAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1JFRkVUQ0hfVEFCX0tFWV06IGlkIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0UmVmZXRjaExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHRvdGFsID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcbiAgaWYgKHRvdGFsID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygncmVmZXRjaDogbm90aGluZyBxdWV1ZWQnKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxuICApO1xuICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbih7XG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcbiAgICBwcm9jZXNzZWQ6IDAsXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgaW5mbGlnaHQ6IG51bGwsXG4gIH0pO1xuICBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcbiAgdm9pZCByZWZldGNoVGljaygpO1xuICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3Agc3RhcnRlZCcsIHsgcXVldWVkOiB0b3RhbCwgaW50ZXJ2YWxfc2VjOiBzZWNvbmRzIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5sZXQgcmVmZXRjaEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kczogbnVtYmVyKTogdm9pZCB7XG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcbiAgcmVmZXRjaEludGVydmFsSGFuZGxlID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgcmVmZXRjaFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ3JlZmV0Y2ggdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIH0pO1xuICB9LCBzZWNvbmRzICogMTAwMCk7XG59XG5cbmZ1bmN0aW9uIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTogdm9pZCB7XG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSk7XG4gICAgcmVmZXRjaEludGVydmFsSGFuZGxlID0gbnVsbDtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigncmVmZXRjaC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XG4gIGF3YWl0IHNldFJlZmV0Y2hUYWJJZChudWxsKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3AgY2FuY2VsbGVkJywge1xuICAgIGhhZF90YWI6IHRhYklkICE9PSBudWxsLFxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZldGNoVGljaygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBpZiAoc2VzcyA9PT0gbnVsbCkge1xuICAgIC8vIExvb3Agd2FzIGNhbmNlbGxlZCBvciBuZXZlciBzdGFydGVkOyBub3RoaW5nIHRvIGRvLlxuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gV2FpdC1mb3ItaW5nZXN0IGd1YXJkOiBpZiB3ZSdyZSBzdGlsbCBleHBlY3RpbmcgYSBjYXB0dXJlIGZvciB0aGVcbiAgLy8gcHJldmlvdXNseS1uYXZpZ2F0ZWQgdGFyZ2V0LCBvbmx5IGFkdmFuY2Ugb25jZSB3ZSd2ZSBlaXRoZXIgc2VlbiB0aGVcbiAgLy8gY2FwdHVyZSAob25HcmFwaHFsQ2FwdHVyZSBjbGVhcnMgYGluZmxpZ2h0YCkgb3IgaGl0IHRoZSB0aW1lb3V0LlxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShzZXNzLmluZmxpZ2h0Lm5hdmlnYXRlZEF0KTtcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgXHUyMDE0IHBhZ2UtaG9vayBtYXkgeWV0IGNhcHR1cmUgdGhlIHJlc3BvbnNlLlxuICAgIH1cbiAgICAvLyBUaW1lZCBvdXQuIFRyZWF0IGFzIFwidGhpcyB0YXJnZXQgd29uJ3QgaW5nZXN0XCIgYW5kIGRyb3AgaXQuXG4gICAgYXdhaXQgd2FybigncmVmZXRjaDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XG4gICAgICB0d2VldF9pZDogc2Vzcy5pbmZsaWdodC50d2VldElkLFxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxuICAgIH0pO1xuICAgIC8vIEZpbmQgd2hpY2ggaGFuZGxlIHRoaXMgaWQgaXMgcXVldWVkIHVuZGVyIHNvIHdlIGNhbiBkZXF1ZXVlIGl0LlxuICAgIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICAgIGlmIChpZHMuaW5jbHVkZXMoc2Vzcy5pbmZsaWdodC50d2VldElkKSkge1xuICAgICAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaChoYW5kbGUsIHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICB9XG5cbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dFJlZmV0Y2hUYXJnZXQoKTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBjb21wbGV0ZScsIHsgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCB9KTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHVybCA9IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmhhbmRsZX0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcbiAgbGV0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XG4gIGlmICh0YWJJZCAhPT0gbnVsbCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRhYklkID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBpZiAodGFiSWQgPT09IG51bGwpIHtcbiAgICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwsIGFjdGl2ZTogZmFsc2UgfSk7XG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicpIGF3YWl0IHNldFJlZmV0Y2hUYWJJZCh0YWIuaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcbiAgICB9XG4gICAgc2VzcyA9IChhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpKSA/PyBzZXNzO1xuICAgIHNlc3MuaW5mbGlnaHQgPSB7XG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIG5hdmlnYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoIHRpY2snLCB7XG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICByZW1haW5pbmc6IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCksXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIH0pO1xuICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHRhcmdldC5oYW5kbGUsIHRhcmdldC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbi8vIC0tLSBNZWRpYS1jcmF3bCBsb29wIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vL1xuLy8gTWlycm9ycyB0aGUgcmVmZXRjaCBsb29wIGJ1dCB0YXJnZXRzIHRoZSBtZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXRzIHRoYXRcbi8vIHRoZSBub3JtYWxpemVyIG9ic2VydmVkIHZpYSB0aGUgTWVkaWEgdGFiIC8gVXNlck1lZGlhIGVuZHBvaW50IHdpdGhcbi8vIGluc3VmZmljaWVudCBkYXRhIHRvIGJ1aWxkIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIFRoZSBjcmF3bCBsb29wIHdhbGtzXG4vLyBhIGRlZGljYXRlZCB0YWIgdGhyb3VnaCBlYWNoIHR3ZWV0J3MgZGV0YWlsIHBhZ2UgKGhhbmRsZS1sZXNzIFVSTCBmb3JtXG4vLyB3aGVuIHRoZSBoaW50LWhhbmRsZSBpcyBtaXNzaW5nKSwgYXQgdGhlIGF1dG8tc2Nyb2xsIGNhZGVuY2UsIHNvIHRoZVxuLy8gcGFnZS1ob29rIGNhbiBjYXB0dXJlIHRoZSByZWFsIHR3ZWV0IHNoYXBlLlxuXG5jb25zdCBNRURJQV9DUkFXTF9UQUJfS0VZID0gJ19faW1tX2FyY2hpdmVfbWVkaWFfY3Jhd2xfdGFiX2lkX18nO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoTUVESUFfQ1JBV0xfVEFCX0tFWSk7XG4gIGNvbnN0IGlkID0gc3RvcmVkW01FRElBX0NSQVdMX1RBQl9LRVldO1xuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChpZCA9PT0gbnVsbCkgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnJlbW92ZShNRURJQV9DUkFXTF9UQUJfS0VZKTtcbiAgZWxzZSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW01FRElBX0NSQVdMX1RBQl9LRVldOiBpZCB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRNZWRpYUNyYXdsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdG90YWwgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xuICBpZiAodG90YWwgPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogbm90aGluZyBxdWV1ZWQnKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxuICApO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbih7XG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcbiAgICBwcm9jZXNzZWQ6IDAsXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgaW5mbGlnaHQ6IG51bGwsXG4gIH0pO1xuICBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzKTtcbiAgdm9pZCBtZWRpYUNyYXdsVGljaygpO1xuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxubGV0IG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZTogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xuICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XG4gIG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIG1lZGlhQ3Jhd2xUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCdtZWRpYS1jcmF3bCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcbn1cblxuZnVuY3Rpb24gc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpOiB2b2lkIHtcbiAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwobWVkaWFDcmF3bEludGVydmFsSGFuZGxlKTtcbiAgICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbE1lZGlhQ3Jhd2xMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFRhYklkKCk7XG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZChudWxsKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcbiAgICBwcm9jZXNzZWQ6IHNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBzZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgaWYgKHNlc3MgPT09IG51bGwpIHtcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xuICAgIGlmIChlbGFwc2VkIDwgSU5HRVNUX1dBSVRfTVMpIHtcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBvbiB0aGUgcGFnZS1ob29rXG4gICAgfVxuICAgIGF3YWl0IHdhcm4oJ21lZGlhLWNyYXdsOiB0YXJnZXQgdGltZWQgb3V0IHdhaXRpbmcgZm9yIGluZ2VzdCcsIHtcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXG4gICAgICB3YWl0ZWRfbXM6IGVsYXBzZWQsXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2woc2Vzcy5pbmZsaWdodC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xuICB9XG5cbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKG51bGwpO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG51bGwpO1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gU2tpcCBpZiBhbHJlYWR5IGluIHRoZSBhcmNoaXZlIFx1MjAxNCBwYXJ0aWFsIGNhcHR1cmVzIGNhbiBvdXRsaXZlIGFcbiAgLy8gc2VwYXJhdGUgZnVsbCBjYXB0dXJlIHBhdGguXG4gIGlmIChhd2FpdCBpc0NvbW1pdHRlZCh0YXJnZXQudHdlZXRJZCkpIHtcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8vIE1lZGlhLXRhYiBvdmVybGF5L3N0YXR1cyByb3V0ZXMgbGlrZSBgL2kvc3RhdHVzLzxpZD5gIGFyZSBub3QgcmVsaWFibGVcbiAgLy8gZGV0YWlsIHBhZ2VzLiBUaGUgbm9ybWFsaXplciBzaG91bGQgcmVjb3ZlciB0aGUgYXV0aG9yIGhhbmRsZSBiZWZvcmVcbiAgLy8gcXVldWVpbmc7IGlmIGFuIG9sZCBvciBkZWdyYWRlZCBxdWV1ZSBlbnRyeSBoYXMgbm8gaGFuZGxlLCBza2lwIGl0XG4gIC8vIGluc3RlYWQgb2Ygc2VuZGluZyB0aGUgdXNlciB0byBhbiBlbXB0eSBYIHJvdXRlLlxuICBpZiAodGFyZ2V0LmJ1Y2tldCA9PT0gJ191bmtub3duJykge1xuICAgIGF3YWl0IHdhcm4oJ21lZGlhLWNyYXdsIHRhcmdldCBtaXNzaW5nIGhhbmRsZTsgc2tpcHBpbmcgYnJva2VuIHN0YXR1cyByb3V0ZScsIHtcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICB9KTtcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCB1cmwgPSBgaHR0cHM6Ly94LmNvbS8ke3RhcmdldC5idWNrZXR9L3N0YXR1cy8ke3RhcmdldC50d2VldElkfWA7XG4gIGxldCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xuICBpZiAodGFiSWQgIT09IG51bGwpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmdldCh0YWJJZCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICB0YWJJZCA9IG51bGw7XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgaWYgKHRhYklkID09PSBudWxsKSB7XG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xuICAgICAgaWYgKHR5cGVvZiB0YWIuaWQgPT09ICdudW1iZXInKSBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQodGFiLmlkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XG4gICAgfVxuICAgIHNlc3MgPSAoYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKSkgPz8gc2VzcztcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xuICAgICAgdHdlZXRJZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBuYXZpZ2F0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgdGljaycsIHtcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIGhpbnRfaGFuZGxlOiB0YXJnZXQuYnVja2V0ID09PSAnX3Vua25vd24nID8gbnVsbCA6IHRhcmdldC5idWNrZXQsXG4gICAgICByZW1haW5pbmc6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bCBuYXZpZ2F0ZSBmYWlsZWQ7IGRyb3BwaW5nIHRhcmdldCcsIHtcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICB9KTtcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG4vLyAtLS0gUXVhcmFudGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBxdWFyYW50aW5lKFxuICByZWFzb246IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgdXJsOiBzdHJpbmcsXG4gIHJhdzogdW5rbm93bixcbiAgZXJyOiB1bmtub3duXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgbG9nRXJyKCdxdWFyYW50aW5pbmcgY2FwdHVyZScsIHsgcmVhc29uLCBlbmRwb2ludCwgdXJsLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSByZXR1cm47XG4gIGNvbnN0IHBheWxvYWQ6IFF1YXJhbnRpbmVQYXlsb2FkID0ge1xuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgIHJlYXNvbixcbiAgICBlbmRwb2ludCxcbiAgICBjYXB0dXJlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNvdXJjZV91cmw6IHVybCxcbiAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIHJhdyxcbiAgfTtcbiAgY29uc3QgdHMgPSBpc29Db21wYWN0KHBheWxvYWQuY2FwdHVyZWRfYXQpO1xuICBjb25zdCBoYXNoID0gYXdhaXQgc2hhOChKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XG4gIGNvbnN0IHBhdGggPSBgcmF3L19xdWFyYW50aW5lLyR7dHN9LSR7aGFzaH0uanNvbmA7XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgYXdhaXQgY2xpZW50LnB1dEZpbGUoe1xuICAgICAgcGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHBheWxvYWQsIG51bGwsIDIpICsgJ1xcbicpLFxuICAgICAgbWVzc2FnZTogYHF1YXJhbnRpbmU6ICR7cmVhc29ufSAke2VuZHBvaW50fWAsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKHFlcnIpIHtcbiAgICBhd2FpdCBsb2dFcnIoJ3F1YXJhbnRpbmUgY29tbWl0IGZhaWxlZCcsIHsgLi4uZGVzY3JpYmVFcnJvcihxZXJyKSB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzaGE4KHM6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGJ1ZiA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcbiAgY29uc3QgZGlnZXN0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBidWYpO1xuICBjb25zdCBoZXggPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGRpZ2VzdCkpXG4gICAgLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcbiAgICAuam9pbignJyk7XG4gIHJldHVybiBoZXguc2xpY2UoMCwgOCk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHZlcmlmaWNhdGlvbiAmIGFjY291bnRzIGxpc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5Q29ubmVjdGlvbihmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgbG9naW46IG51bGwsXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGlmICghZm9yY2UpIHtcbiAgICAvLyBTa2lwIGlmIHdlJ3JlIGluc2lkZSB0aGUgcmVwb3J0ZWQgcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IHJlLWNoZWNraW5nXG4gICAgLy8gYmVmb3JlIHJlc2V0IGp1c3Qgd2FzdGVzIG1vcmUgb2YgdGhlIHNhbWUgZXhoYXVzdGVkIHF1b3RhIGFuZCBrZWVwc1xuICAgIC8vIHRoZSA0MDNzIGNvbWluZy5cbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xuICAgICAgY29uc3Qgbm93U2VjID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gICAgICBpZiAobm93U2VjIDwgY29ubi5yYXRlTGltaXRSZXNldEF0KSByZXR1cm47XG4gICAgfVxuICAgIC8vIEFwcGx5IHRoZSBwZXJpb2RpYy1jaGVjayBnYXRlIHRvIGV2ZXJ5IHN0YXR1cywgbm90IGp1c3QgJ29rJy4gVGhlXG4gICAgLy8gcHJldmlvdXMgYmVoYXZpb3IgcmUtdmVyaWZpZWQgb24gZXZlcnkgd2FrZSB3aGVuZXZlciB0aGUgY29ubmVjdGlvblxuICAgIC8vIHdhc24ndCAnb2snLCB3aGljaCBkdXJpbmcgYSByYXRlLWxpbWl0IHdpbmRvdyBtZWFudCAyIEFQSSBjYWxscyBwZXJcbiAgICAvLyBTVyB3YWtlICh2ZXJpZnlSZXBvQWNjZXNzIGRvZXMgR0VUIC91c2VyICsgR0VUIC9yZXBvcy97b30ve3J9KS5cbiAgICBpZiAoY29ubi5jaGVja2VkQXQpIHtcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGNvbm4uY2hlY2tlZEF0KTtcbiAgICAgIGlmIChhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHIgPSBhd2FpdCBjbGllbnQudmVyaWZ5UmVwb0FjY2VzcygpO1xuICAgIC8vIFByb2JlIHRoZSBjb25maWd1cmVkIGJyYW5jaC4gQSBub24tZGVmYXVsdCBicmFuY2ggaXMgZmluZSBcdTIwMTQgaXQnc1xuICAgIC8vIHJvdXRpbmUgdG8gY2FwdHVyZSBpbnRvIGEgd29ya2luZyBicmFuY2ggXHUyMDE0IGJ1dCBhICptaXNzaW5nKiBicmFuY2hcbiAgICAvLyB3b3VsZCA0MjIgZXZlcnkgY29tbWl0LlxuICAgIGxldCBicmFuY2hPayA9IHRydWU7XG4gICAgaWYgKHNldHRpbmdzLmJyYW5jaCAmJiBzZXR0aW5ncy5icmFuY2ggIT09IHIuZGVmYXVsdF9icmFuY2gpIHtcbiAgICAgIGJyYW5jaE9rID0gYXdhaXQgY2xpZW50LmJyYW5jaEV4aXN0cyhzZXR0aW5ncy5icmFuY2gpO1xuICAgIH1cbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1czogJ29rJyxcbiAgICAgIGxvZ2luOiByLmxvZ2luLFxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlcnJvcjogbnVsbCxcbiAgICAgIGRlZmF1bHRCcmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXG4gICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBicmFuY2hPayxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgfSk7XG4gICAgYXdhaXQgaW5mbygnY29ubmVjdGlvbiB2ZXJpZmllZCcsIHtcbiAgICAgIGxvZ2luOiByLmxvZ2luLFxuICAgICAgcmVwbzogci5mdWxsX25hbWUsXG4gICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRfYnJhbmNoOiBzZXR0aW5ncy5icmFuY2gsXG4gICAgICBjb25maWd1cmVkX2JyYW5jaF9leGlzdHM6IGJyYW5jaE9rLFxuICAgIH0pO1xuICAgIGlmICghYnJhbmNoT2spIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2NvbmZpZ3VyZWQgYnJhbmNoIGRvZXMgbm90IGV4aXN0IG9uIHJlbW90ZScsIHtcbiAgICAgICAgY29uZmlndXJlZDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgICAgZml4OiAnb3BlbiBTZXR0aW5ncyBhbmQgY2hhbmdlIGJyYW5jaCB0byAnICsgci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc3QgY2F0ID0gZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgPyBlcnIuY2F0ZWdvcnkgOiAndW5rbm93bic7XG4gICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgIGNhdCA9PT0gJ2F1dGgnXG4gICAgICAgID8gJ2F1dGgtZXJyb3InXG4gICAgICAgIDogY2F0ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgOiBjYXQgPT09ICduZXR3b3JrJ1xuICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgIDogJ2F1dGgtZXJyb3InO1xuICAgIGNvbnN0IHJlc2V0QXQgPVxuICAgICAgZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgY2F0ID09PSAncmF0ZS1saW1pdCcgPyBlcnIucmF0ZUxpbWl0UmVzZXRBdCA6IG51bGw7XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXMsXG4gICAgICBsb2dpbjogbnVsbCxcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKS5tZXNzYWdlLFxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiByZXNldEF0LFxuICAgIH0pO1xuICAgIGF3YWl0IHdhcm4oJ2Nvbm5lY3Rpb24gY2hlY2sgZmFpbGVkJywge1xuICAgICAgY2F0ZWdvcnk6IGNhdCxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjY291bnRzTGlzdChmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0KSB7XG4gICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICghZm9yY2UpIHtcbiAgICAvLyBTa2lwIHdoaWxlIGluc2lkZSBhIGtub3duIHJhdGUtbGltaXQgd2luZG93IFx1MjAxNCBhY2NvdW50cy55YW1sIGlzIGZldGNoZWRcbiAgICAvLyB2aWEgYXV0aGVudGljYXRlZCByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLCB3aGljaCBjb3VudHMgYWdhaW5zdCB0aGVcbiAgICAvLyBzYW1lIHF1b3RhLlxuICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcbiAgICAgIGNvbnN0IG5vd1NlYyA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBTa2lwIGlmIHdlIHJlZnJlc2hlZCByZWNlbnRseS4gYWNjb3VudHMueWFtbCBjaGFuZ2VzIHJhcmVseSBcdTIwMTQgdGhlIG9sZFxuICAgIC8vIGNvZGUgcmUtZmV0Y2hlZCBpdCBvbiBldmVyeSBTVyB3YWtlLCB3aGljaCBkdXJpbmcgaGVhdnkgYnJvd3NpbmcgbWVhbnRcbiAgICAvLyBhIEdpdEh1YiBjYWxsIGV2ZXJ5IGZldyBzZWNvbmRzIGV2ZW4gd2hlbiBub3RoaW5nIHdhcyBiZWluZyBjYXB0dXJlZC5cbiAgICBjb25zdCBsYXN0UmVmcmVzaGVkID0gYXdhaXQgZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpO1xuICAgIGlmIChsYXN0UmVmcmVzaGVkKSB7XG4gICAgICBjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShsYXN0UmVmcmVzaGVkKTtcbiAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYWdlKSAmJiBhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCBjbGllbnQuZmV0Y2hSYXdUZXh0KCdjb25maWcvYWNjb3VudHMueWFtbCcpO1xuICAgIGlmICghdGV4dCkge1xuICAgICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIG5vdCBmb3VuZCBpbiByZXBvOyB1c2luZyBmYWxsYmFjaycpO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlQWNjb3VudHNZYW1sKHRleHQpO1xuICAgIGlmIChwYXJzZWQubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIHBhcnNlZCBlbXB0eTsga2VlcGluZyBmYWxsYmFjaycpO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGF3YWl0IHNldEFjY291bnRzKHBhcnNlZCk7XG4gICAgYXdhaXQgc2V0QWNjb3VudHNSZWZyZXNoZWRBdChuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xuICAgIGlmIChmb3JjZSkgYXdhaXQgaW5mbygnYWNjb3VudHMgbGlzdCByZWZyZXNoZWQnLCB7IGNvdW50OiBwYXJzZWQubGVuZ3RoIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdyZWZyZXNoIGFjY291bnRzIGZhaWxlZDsga2VlcGluZyBjdXJyZW50IGxpc3QnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbi8vIC0tLSBTdGF0ZSBicm9hZGNhc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gYnJvYWRjYXN0U3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgYnVpbGRTdGF0ZSgpO1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCB0YWJDb3VudCA9IDA7XG4gIHRyeSB7XG4gICAgY29uc3QgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gICAgdGFiQ291bnQgPSB0YWJzLmxlbmd0aDtcbiAgfSBjYXRjaCB7XG4gICAgLy8gdGFicy5xdWVyeSBpcyBhbGxvd2VkIGJ5IHRoZSBtYW5pZmVzdCBidXQgY2FuIHRyYW5zaWVudGx5IGZhaWxcbiAgICAvLyBhcm91bmQgZXh0ZW5zaW9uIHN0YXJ0dXA7IHN1cmZhY2luZyAwIGlzIGZpbmUuXG4gIH1cbiAgY29uc3QgcmVmZXRjaFF1ZXVlZCA9IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xRdWV1ZWQgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xTZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgY29uc3QgYXV0b1Njcm9sbFNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICByZXR1cm4ge1xuICAgIHZlcnNpb246IEVYVF9WRVJTSU9OLFxuICAgIHNldHRpbmdzOiByZWRhY3RTZXR0aW5ncyhzZXR0aW5ncyksXG4gICAgY29ubmVjdGlvbjogY29ubixcbiAgICBhY2NvdW50cyxcbiAgICBjb3VudGVycyxcbiAgICBhdXRvU2Nyb2xsOiB7XG4gICAgICBhY3RpdmU6IGF1dG9TY3JvbGxTZXNzICE9PSBudWxsICYmIGF1dG9TY3JvbGxUaW1lciAhPT0gbnVsbCxcbiAgICAgIHRhYkNvdW50LFxuICAgICAgc2Nyb2xsQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxuICAgICAgaW5nZXN0ZWRDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkQ291bnQgPz8gMCxcbiAgICAgIGV4cGFuZGVkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5leHBhbmRlZENvdW50ID8/IDAsXG4gICAgfSxcbiAgICByZWZldGNoUXVldWU6IHtcbiAgICAgIHRvdGFsOiByZWZldGNoUXVldWVkLFxuICAgICAgcnVubmluZzogcmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsLFxuICAgICAgcHJvY2Vzc2VkOiByZWZldGNoU2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gICAgICB0b3RhbF9hdF9zdGFydDogcmVmZXRjaFNlc3M/LnRvdGFsQXRTdGFydCA/PyAwLFxuICAgIH0sXG4gICAgbWVkaWFDcmF3bFF1ZXVlOiB7XG4gICAgICB0b3RhbDogbWVkaWFDcmF3bFF1ZXVlZCxcbiAgICAgIHJ1bm5pbmc6IG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcbiAgICAgIHByb2Nlc3NlZDogbWVkaWFDcmF3bFNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IG1lZGlhQ3Jhd2xTZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcbiAgICB9LFxuICB9O1xufVxuXG5mdW5jdGlvbiByZWRhY3RTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IEV4dGVuc2lvblN0YXRlWydzZXR0aW5ncyddIHtcbiAgcmV0dXJuIHtcbiAgICBvd25lcjogcy5vd25lcixcbiAgICByZXBvOiBzLnJlcG8sXG4gICAgYnJhbmNoOiBzLmJyYW5jaCxcbiAgICBlbmFibGVkOiBzLmVuYWJsZWQsXG4gICAgYXV0b0NhcHR1cmU6IHMuYXV0b0NhcHR1cmUsXG4gICAgY29uZmlndXJlZEF0OiBzLmNvbmZpZ3VyZWRBdCxcbiAgICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IHMuYXV0b1Njcm9sbEludGVydmFsU2VjLFxuICAgIHBhdFNldDogcy5wYXQubGVuZ3RoID4gMCxcbiAgICBwYXRTdWZmaXg6IHMucGF0Lmxlbmd0aCA+PSA0ID8gcy5wYXQuc2xpY2UoLTQpIDogJycsXG4gIH07XG59XG5cbmZ1bmN0aW9uIGlzb0NvbXBhY3QoaXNvOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyAyMDI1LTA0LTEyVDE0OjIzOjAxLjAwMFogXHUyMTkyIDIwMjUtMDQtMTJUMTQyMzAxWlxuICBjb25zdCBkID0gbmV3IERhdGUoaXNvKTtcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBpc28ucmVwbGFjZSgvWzouXS9nLCAnJyk7XG4gIGNvbnN0IHBhZCA9IChuOiBudW1iZXIsIHcgPSAyKSA9PiBTdHJpbmcobikucGFkU3RhcnQodywgJzAnKTtcbiAgcmV0dXJuIChcbiAgICBgJHtkLmdldFVUQ0Z1bGxZZWFyKCl9LSR7cGFkKGQuZ2V0VVRDTW9udGgoKSArIDEpfS0ke3BhZChkLmdldFVUQ0RhdGUoKSl9YCArXG4gICAgYFQke3BhZChkLmdldFVUQ0hvdXJzKCkpfSR7cGFkKGQuZ2V0VVRDTWludXRlcygpKX0ke3BhZChkLmdldFVUQ1NlY29uZHMoKSl9WmBcbiAgKTtcbn1cblxuZnVuY3Rpb24gdmlld2VyVXJsKHM6IFNldHRpbmdzKTogc3RyaW5nIHtcbiAgcmV0dXJuIGBodHRwczovLyR7cy5vd25lcn0uZ2l0aHViLmlvLyR7cy5yZXBvfS9gO1xufVxuXG4vKipcbiAqIFdhbGsgYG5vZGVgIGNvbGxlY3RpbmcgZG90dGVkIGtleSBwYXRocyB1cCB0byBgbWF4RGVwdGhgIGRlZXAuIEFycmF5XG4gKiBpbmRpY2VzIGNvbGxhcHNlIHRvIGBbMF1gICh3ZSBvbmx5IGRlc2NlbmQgaW50byB0aGUgZmlyc3QgZWxlbWVudCkuIFVzZWRcbiAqIHRvIHN1cmZhY2UgdGhlIHN0cnVjdHVyYWwgc2tlbGV0b24gb2YgYW4gdW5mYW1pbGlhciBHcmFwaFFMIHJlc3BvbnNlXG4gKiB3aXRob3V0IGluY2x1ZGluZyBhbnkgZGF0YSB2YWx1ZXMuXG4gKi9cbi8qKiBDb2xsZWN0IGV2ZXJ5IGRpc3RpbmN0IGBfX3R5cGVuYW1lYCB2YWx1ZSBmb3VuZCBhbnl3aGVyZSBpbiB0aGUgdHJlZS4gKi9cbmZ1bmN0aW9uIHByb2JlVHlwZW5hbWVzKG5vZGU6IHVua25vd24pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKHR5cGVvZiBvYmouX190eXBlbmFtZSA9PT0gJ3N0cmluZycpIHNlZW4uYWRkKG9iai5fX3R5cGVuYW1lKTtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBbLi4uc2Vlbl0uc29ydCgpO1xufVxuXG4vKipcbiAqIEZpbmQgdGhlIGZpcnN0IG5vZGUgYW55d2hlcmUgaW4gdGhlIHRyZWUgd2hvc2UgYF9fdHlwZW5hbWVgIG1hdGNoZXMgYW5kXG4gKiByZXR1cm4gaXRzIHRvcC1sZXZlbCBrZXkgbGlzdCAoc29ydGVkKS4gVXNlZnVsIGZvciBkaXNjb3ZlcmluZyB3aGF0IGZpZWxkc1xuICogWCBpcyBhY3R1YWxseSBzaGlwcGluZyBmb3IgYSBnaXZlbiBub2RlIHR5cGUgYWZ0ZXIgYSBzY2hlbWEgY2hhbmdlLlxuICovXG5mdW5jdGlvbiBwcm9iZUZpcnN0VHlwZVNoYXBlKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcpOiBzdHJpbmdbXSB8IG51bGwge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobiA9PT0gbnVsbCB8fCB0eXBlb2YgbiAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShuKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG9iaiA9IG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBpZiAob2JqLl9fdHlwZW5hbWUgPT09IHR5cGVuYW1lKSB7XG4gICAgICAgIHJldHVybiBPYmplY3Qua2V5cyhvYmopLnNvcnQoKTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vKipcbiAqIEZpbmQgdGhlIGZpcnN0IG5vZGUgd2l0aCBgX190eXBlbmFtZSA9PT0gdHlwZW5hbWVgLCB0aGVuIGRlc2NlbmQgdGhyb3VnaFxuICogdGhlIGdpdmVuIGtleSBwYXRoLCBhbmQgcmV0dXJuIHRoZSB0b3AtbGV2ZWwga2V5cyBvZiB3aGF0ZXZlciBpcyBhdCB0aGVcbiAqIGVuZC4gUmV0dXJucyBhIG1hcmtlciBzdHJpbmcgd2hlbiB0aGUgcGF0aCBsZWFkcyBzb21ld2hlcmUgbm9uLW9iamVjdCBzb1xuICogd2UgY2FuIHRlbGwgYXBhcnQgXCJhYnNlbnRcIiBmcm9tIFwicHJlc2VudCBidXQgbm90IGFuIG9iamVjdFwiLlxuICovXG5mdW5jdGlvbiBwcm9iZVR5cGVkTmVzdGVkKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcsIHBhdGg6IHN0cmluZ1tdKTogdW5rbm93biB7XG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIGxldCBmb3VuZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsID0gbnVsbDtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSB0eXBlbmFtZSkge1xuICAgICAgICBmb3VuZCA9IG9iajtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICBpZiAoIWZvdW5kKSByZXR1cm4gbnVsbDtcbiAgbGV0IGN1cjogdW5rbm93biA9IGZvdW5kO1xuICBmb3IgKGNvbnN0IHNlZyBvZiBwYXRoKSB7XG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgcmV0dXJuIGA8JHtjdXIgPT09IG51bGwgPyAnbnVsbCcgOiB0eXBlb2YgY3VyfT5gO1xuICAgIGN1ciA9IChjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW3NlZ107XG4gIH1cbiAgaWYgKGN1ciA9PT0gdW5kZWZpbmVkKSByZXR1cm4gJzxtaXNzaW5nPic7XG4gIGlmIChjdXIgPT09IG51bGwpIHJldHVybiAnPG51bGw+JztcbiAgaWYgKHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSByZXR1cm4gYDwke3R5cGVvZiBjdXJ9PmA7XG4gIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHJldHVybiBgPGFycmF5IGxlbj0ke2N1ci5sZW5ndGh9PmA7XG4gIHJldHVybiBPYmplY3Qua2V5cyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLnNvcnQoKTtcbn1cblxuZnVuY3Rpb24gc2hvcnRlblVybCh1OiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBBY3Rpdml0eS10YWlsIGNvbnRleHQgaXMgbW9yZSB1c2VmdWwgd2l0aCBqdXN0IHRoZSBwYXRoOyBmdWxsIFVSTHMgYmVjb21lXG4gIC8vIGhhcmQgdG8gcmVhZCBhdCB0aGUgc2lkZWJhcidzIHdpZHRoLlxuICB0cnkge1xuICAgIGNvbnN0IHBhcnNlZCA9IG5ldyBVUkwodSk7XG4gICAgY29uc3QgcGF0aCA9IHBhcnNlZC5wYXRobmFtZSArIChwYXJzZWQuc2VhcmNoID8gJz9cdTIwMjYnIDogJycpO1xuICAgIHJldHVybiBwYXJzZWQuaG9zdCA9PT0gJ3guY29tJyB8fCBwYXJzZWQuaG9zdCA9PT0gJ3R3aXR0ZXIuY29tJ1xuICAgICAgPyBwYXRoXG4gICAgICA6IGAke3BhcnNlZC5ob3N0fSR7cGF0aH1gO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gdS5sZW5ndGggPiA4MCA/IGAke3Uuc2xpY2UoMCwgODApfVx1MjAyNmAgOiB1O1xuICB9XG59XG5cbi8vIC0tLSBEZXYgaGVscGVycyBleHBvc2VkIG9uIGdsb2JhbFRoaXMgZm9yIHRoZSBkZXZ0b29scyBjb25zb2xlIC0tLS0tLS0tLS1cbi8vIChlLmcuIGBfX2ltbUFyY2hpdmUuY2xlYXJBbGwoKWAgaW4gdGhlIGJhY2tncm91bmQgd29ya2VyJ3MgZGV2dG9vbHMpLlxuXG4oZ2xvYmFsVGhpcyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuX19pbW1BcmNoaXZlID0ge1xuICBjbGVhckFsbCxcbiAgYWN0aXZpdHk6IGdldEFjdGl2aXR5LFxuICBhY2NvdW50czogZ2V0QWNjb3VudHMsXG4gIGJ1ZmZlcnM6IGdldFJ1bkJ1ZmZlcnMsXG4gIGZsdXNoQWxsOiAoKSA9PiBmbHVzaEFsbCgnZGV2dG9vbHMnKSxcbiAgc3RhdGU6IGJ1aWxkU3RhdGUsXG4gIHJlZmV0Y2hRdWV1ZTogZ2V0UmVmZXRjaFF1ZXVlLFxuICBzdGFydFJlZmV0Y2g6IHN0YXJ0UmVmZXRjaExvb3AsXG4gIGNhbmNlbFJlZmV0Y2g6IGNhbmNlbFJlZmV0Y2hMb29wLFxuICBtZWRpYUNyYXdsUXVldWU6IGdldE1lZGlhQ3Jhd2xRdWV1ZSxcbiAgc3RhcnRNZWRpYUNyYXdsOiBzdGFydE1lZGlhQ3Jhd2xMb29wLFxuICBjYW5jZWxNZWRpYUNyYXdsOiBjYW5jZWxNZWRpYUNyYXdsTG9vcCxcbn07XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRU8sSUFBTSxtQkFBNkI7QUFBQSxFQUN4QyxLQUFLO0FBQUEsRUFDTCxPQUFPO0FBQUEsRUFDUCxNQUFNO0FBQUE7QUFBQTtBQUFBLEVBR04sUUFBUTtBQUFBLEVBQ1IsU0FBUztBQUFBLEVBQ1QsYUFBYTtBQUFBLEVBQ2IsY0FBYztBQUFBLEVBQ2QsdUJBQXVCO0FBQ3pCO0FBRU8sSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxzQkFBc0I7QUFJNUIsSUFBTSxvQkFBcUM7QUFBQSxFQUNoRCxFQUFFLFFBQVEsVUFBVSxPQUFPLG1DQUFtQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsVUFBVSxPQUFPLDRDQUE0QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsT0FBTyxPQUFPLHNDQUFzQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsU0FBUyxPQUFPLDZDQUE2QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsY0FBYyxPQUFPLG1CQUFtQixVQUFVLE9BQU87QUFBQSxFQUNuRSxFQUFFLFFBQVEsWUFBWSxPQUFPLCtCQUErQixVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLGtDQUFrQyxVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLDRCQUE0QixVQUFVLE9BQU87QUFBQSxFQUN2RSxFQUFFLFFBQVEsbUJBQW1CLE9BQU8scUJBQXFCLFVBQVUsT0FBTztBQUM1RTtBQUdPLElBQU0sa0JBQXVDLG9CQUFJLElBQUk7QUFBQSxFQUMxRDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQVdNLElBQU0sb0JBQXlDLG9CQUFJLElBQUksQ0FBQyxvQkFBb0IsY0FBYyxDQUFDO0FBdUIzRixJQUFNLHdCQUF3QjtBQUc5QixJQUFNLGdCQUFnQjtBQUd0QixJQUFNLHNCQUFzQjtBQUc1QixJQUFNLG9CQUFvQjtBQUcxQixJQUFNLGdDQUFnQyxLQUFLLEtBQUs7QUFFaEQsSUFBTSxtQkFBbUI7OztBQ3RFaEMsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0I7QUFFeEIsSUFBSSxrQkFBb0M7QUFDeEMsSUFBSSxzQkFBcUM7QUFFekMsU0FBUyxTQUFTLEtBQXlCO0FBQ3pDLE1BQUksSUFBSTtBQUNSLGFBQVcsS0FBSyxJQUFLLE1BQUssT0FBTyxhQUFhLENBQUM7QUFDL0MsU0FBTyxLQUFLLENBQUM7QUFDZjtBQUVBLFNBQVMsV0FBVyxHQUF1QjtBQUN6QyxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFFBQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxNQUFNO0FBQ3JDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUssS0FBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFDOUQsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUU7QUFDaEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDL0QsUUFBTSxJQUFJLE9BQU8sZ0JBQWdCO0FBQ2pDLE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsV0FBTyxFQUFFLFNBQVMsR0FBRyxNQUFNLFdBQVcsQ0FBQyxFQUFFO0FBQUEsRUFDM0M7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxRQUFNLFVBQVUsU0FBUyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0FBQy9ELFNBQU8sRUFBRSxTQUFTLEtBQUs7QUFDekI7QUFFQSxlQUFlLFlBQWdDO0FBQzdDLFFBQU0sRUFBRSxTQUFTLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUNqRCxNQUFJLG9CQUFvQixRQUFRLHdCQUF3QixTQUFTO0FBQy9ELFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFO0FBQUEsSUFDN0IsR0FBRyxRQUFRLFFBQVEsRUFBRSxJQUFJLFFBQVEsUUFBUSxZQUFZLEVBQUUsT0FBTztBQUFBLEVBQ2hFO0FBQ0EsUUFBTSxXQUFXLElBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNO0FBQ3pELFdBQVMsSUFBSSxNQUFNLENBQUM7QUFDcEIsV0FBUyxJQUFJLE1BQU0sS0FBSyxNQUFNO0FBQzlCLFFBQU0sT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUTtBQUMzRCxRQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLE1BQU0sRUFBRSxNQUFNLFVBQVUsR0FBRyxPQUFPO0FBQUEsSUFDakY7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBQ0Qsb0JBQWtCO0FBQ2xCLHdCQUFzQjtBQUN0QixTQUFPO0FBQ1Q7QUFFTyxTQUFTLGVBQWUsR0FBb0I7QUFDakQsU0FBTyxFQUFFLFdBQVcsZUFBZTtBQUNyQztBQUVBLGVBQXNCLFdBQVcsV0FBb0M7QUFDbkUsTUFBSSxDQUFDLFVBQVcsUUFBTztBQUN2QixRQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFFBQU0sS0FBSyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3BELFFBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLElBQzdCLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxJQUN0QjtBQUFBLElBQ0EsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTO0FBQUEsRUFDcEM7QUFDQSxTQUFPLEdBQUcsZUFBZSxHQUFHLFNBQVMsRUFBRSxDQUFDLElBQUksU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMUU7QUFFQSxlQUFzQixXQUFXLFVBQW1DO0FBQ2xFLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFHdEIsTUFBSSxDQUFDLFNBQVMsV0FBVyxlQUFlLEVBQUcsUUFBTztBQUNsRCxRQUFNLFFBQVEsU0FBUyxNQUFNLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxHQUFHO0FBQzlELE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUMvQixRQUFNLENBQUMsT0FBTyxLQUFLLElBQUk7QUFDdkIsTUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFPLFFBQU87QUFDN0IsTUFBSTtBQUNGLFVBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQzdCLEVBQUUsTUFBTSxXQUFXLEdBQXVCO0FBQUEsTUFDMUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDcEMsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7OztBQzVCQSxJQUFNLHFCQUFzQztBQUFBLEVBQzFDLFFBQVE7QUFBQSxFQUNSLE9BQU87QUFBQSxFQUNQLFdBQVc7QUFBQSxFQUNYLE9BQU87QUFBQSxFQUNQLGVBQWU7QUFBQSxFQUNmLHdCQUF3QjtBQUFBLEVBQ3hCLGtCQUFrQjtBQUNwQjtBQUVBLElBQU0sV0FBeUI7QUFBQSxFQUM3QixVQUFVLEVBQUUsR0FBRyxpQkFBaUI7QUFBQSxFQUNoQyxVQUFVLENBQUMsR0FBRyxpQkFBaUI7QUFBQSxFQUMvQixxQkFBcUI7QUFBQSxFQUNyQixZQUFZLEVBQUUsR0FBRyxtQkFBbUI7QUFBQSxFQUNwQyxVQUFVLENBQUM7QUFBQSxFQUNYLFlBQVksQ0FBQztBQUFBLEVBQ2IsVUFBVSxDQUFDO0FBQUEsRUFDWCxnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGNBQWMsQ0FBQztBQUFBLEVBQ2YsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixnQkFBZ0I7QUFBQSxFQUNoQixtQkFBbUI7QUFBQSxFQUNuQixtQkFBbUI7QUFDckI7QUFFQSxlQUFlLE9BQXFDLEtBQWtDO0FBQ3BGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksR0FBRztBQUNsRCxRQUFNLFFBQVEsT0FBTyxHQUFHO0FBQ3hCLE1BQUksVUFBVSxRQUFXO0FBQ3ZCLFdBQU8sZ0JBQWdCLFNBQVMsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxlQUFlLE9BQXFDLEtBQVEsT0FBdUM7QUFDakcsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDO0FBQ2xEO0FBSUEsZUFBc0IsY0FBaUM7QUFLckQsUUFBTSxTQUFTLE1BQU0sT0FBTyxVQUFVO0FBQ3RDLFFBQU0sU0FBUyxFQUFFLEdBQUcsa0JBQWtCLEdBQUcsT0FBTztBQUNoRCxNQUFJLE9BQU8sT0FBTyxlQUFlLE9BQU8sR0FBRyxHQUFHO0FBQzVDLFFBQUk7QUFDRixhQUFPLE1BQU0sTUFBTSxXQUFXLE9BQU8sR0FBRztBQUFBLElBQzFDLFFBQVE7QUFDTixhQUFPLE1BQU07QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLFlBQVksR0FBNEI7QUFHNUQsUUFBTSxVQUFvQixFQUFFLEdBQUcsRUFBRTtBQUNqQyxNQUFJLFFBQVEsT0FBTyxDQUFDLGVBQWUsUUFBUSxHQUFHLEdBQUc7QUFDL0MsWUFBUSxNQUFNLE1BQU0sV0FBVyxRQUFRLEdBQUc7QUFBQSxFQUM1QztBQUNBLFFBQU0sT0FBTyxZQUFZLE9BQU87QUFDbEM7QUFDQSxlQUFzQixlQUFlLE9BQTZDO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxPQUFPLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoQyxRQUFNLFlBQVksSUFBSTtBQUN0QixTQUFPO0FBQ1Q7QUFJQSxlQUFzQixjQUF3QztBQUM1RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQVksR0FBbUM7QUFDbkUsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUM1QjtBQUNBLGVBQXNCLHlCQUFpRDtBQUNyRSxTQUFPLE9BQU8scUJBQXFCO0FBQ3JDO0FBQ0EsZUFBc0IsdUJBQXVCLEtBQW1DO0FBQzlFLFFBQU0sT0FBTyx1QkFBdUIsR0FBRztBQUN6QztBQUlBLGVBQXNCLGdCQUEwQztBQUM5RCxRQUFNLElBQUksTUFBTSxPQUFPLFlBQVk7QUFFbkMsUUFBTSxNQUF1QjtBQUFBLElBQzNCLEdBQUc7QUFBQSxJQUNILGVBQWUsRUFBRSxrQkFBa0IsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUN4RCx3QkFDRSxFQUFFLDJCQUEyQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3BELGtCQUFrQixFQUFFLHFCQUFxQixTQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ2hFO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsY0FBYyxHQUFtQztBQUNyRSxRQUFNLE9BQU8sY0FBYyxDQUFDO0FBQzlCO0FBSUEsU0FBUyxXQUFtQjtBQUMxQixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDN0M7QUFFQSxlQUFzQixjQUF1RDtBQUMzRSxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQ3BCLFFBQ0EsT0FDeUI7QUFDekIsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUs7QUFBQSxJQUN6QixZQUFZO0FBQUEsSUFDWixXQUFXLFNBQVM7QUFBQSxJQUNwQixlQUFlO0FBQUEsSUFDZixnQkFBZ0I7QUFBQSxJQUNoQixlQUFlO0FBQUEsRUFDakI7QUFDQSxNQUFJLElBQUksY0FBYyxTQUFTLEdBQUc7QUFDaEMsUUFBSSxZQUFZLFNBQVM7QUFDekIsUUFBSSxhQUFhO0FBQUEsRUFDbkI7QUFDQSxRQUFNLE9BQXVCLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoRCxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsaUJBQWlCLFFBQWdCLE9BQThCO0FBQ25GLFFBQU0sWUFBWSxRQUFRLEVBQUUsZUFBZSxNQUFNLENBQUM7QUFDcEQ7QUFJQSxlQUFzQixnQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLFlBQVk7QUFDNUI7QUFFQSxlQUFzQixhQUFhLFFBQTJDO0FBQzVFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU0sS0FBSztBQUN4QjtBQUVBLGVBQXNCLGFBQWEsUUFBZ0IsS0FBK0I7QUFDaEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFFQSxlQUFzQixlQUFlLFFBQStCO0FBQ2xFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU07QUFDakIsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUlBLGVBQXNCLGNBQW1DO0FBQ3ZELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBRUEsZUFBc0IsZUFBZSxJQUFtQztBQUN0RSxRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLE1BQUksUUFBUSxFQUFFO0FBQ2QsTUFBSSxJQUFJLFNBQVMsa0JBQW1CLEtBQUksU0FBUztBQUNqRCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGdCQUErQjtBQUNuRCxRQUFNLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDN0I7QUFJQSxlQUFzQixvQkFBNkU7QUFDakcsU0FBTyxPQUFPLGdCQUFnQjtBQUNoQztBQUVBLGVBQXNCLGtCQUNwQixLQUNlO0FBQ2YsUUFBTSxPQUFPLGtCQUFrQixHQUFHO0FBQ3BDO0FBVU8sU0FBUyxjQUNkLE9BQ0EsVUFDQSxTQUNBLFFBQ0EsY0FBdUIsT0FDZjtBQUNSLFNBQU8sR0FBRyxLQUFLLElBQUksUUFBUSxJQUFJLE9BQU8sSUFBSSxNQUFNLElBQUksY0FBYyxNQUFNLEdBQUc7QUFDN0U7QUFHQSxlQUFzQixvQkFBb0IsVUFBbUM7QUFDM0UsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLFFBQU0sU0FBUyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksUUFBUSxFQUFFLFlBQVk7QUFDM0QsTUFBSSxTQUFTO0FBQ2IsYUFBVyxVQUFVLE9BQU8sS0FBSyxHQUFHLEdBQUc7QUFDckMsVUFBTSxRQUFRLElBQUksTUFBTTtBQUN4QixRQUFJLENBQUMsTUFBTztBQUNaLGVBQVcsT0FBTyxPQUFPLEtBQUssS0FBSyxHQUFHO0FBQ3BDLFlBQU0sSUFBSSxNQUFNLEdBQUc7QUFDbkIsVUFBSSxLQUFLLEVBQUUsS0FBSyxRQUFRO0FBQ3RCLGVBQU8sTUFBTSxHQUFHO0FBQ2hCLGtCQUFVO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sS0FBSyxLQUFLLEVBQUUsV0FBVyxFQUFHLFFBQU8sSUFBSSxNQUFNO0FBQUEsRUFDeEQ7QUFDQSxNQUFJLFNBQVMsRUFBRyxPQUFNLGtCQUFrQixHQUFHO0FBQzNDLFNBQU87QUFDVDtBQUlBLGVBQXNCLGtCQUFxRDtBQUN6RSxTQUFPLE9BQU8sY0FBYztBQUM5QjtBQUVBLGVBQXNCLG9CQUFxQztBQUN6RCxRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsTUFBSSxRQUFRO0FBQ1osYUFBVyxPQUFPLE9BQU8sT0FBTyxDQUFDLEVBQUcsVUFBUyxJQUFJO0FBQ2pELFNBQU87QUFDVDtBQUVBLGVBQXNCLGVBQWUsUUFBZ0IsU0FBZ0M7QUFDbkYsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLFFBQU0sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzFCLE1BQUksQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHO0FBQzFCLFFBQUksS0FBSyxPQUFPO0FBQ2hCLE1BQUUsTUFBTSxJQUFJO0FBQ1osVUFBTSxPQUFPLGdCQUFnQixDQUFDO0FBQUEsRUFDaEM7QUFDRjtBQUVBLGVBQXNCLGVBQWUsUUFBZ0IsU0FBZ0M7QUFDbkYsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLFFBQU0sTUFBTSxFQUFFLE1BQU07QUFDcEIsTUFBSSxDQUFDLElBQUs7QUFDVixRQUFNLFdBQVcsSUFBSSxPQUFPLENBQUMsT0FBTyxPQUFPLE9BQU87QUFDbEQsTUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLEVBQUUsTUFBTTtBQUFBLE1BQ3JDLEdBQUUsTUFBTSxJQUFJO0FBQ2pCLFFBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUNoQztBQUVBLGVBQXNCLG9CQUdaO0FBQ1IsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFFBQUksSUFBSSxTQUFTLEVBQUcsUUFBTyxFQUFFLFFBQVEsU0FBUyxJQUFJLENBQUMsRUFBRztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0IscUJBQXdEO0FBQzVFLFNBQU8sT0FBTyxpQkFBaUI7QUFDakM7QUFFQSxlQUFzQix1QkFBd0M7QUFDNUQsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixrQkFBa0IsWUFBMkIsU0FBZ0M7QUFDakcsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLFFBQU0sU0FBUyxjQUFjO0FBQzdCLFFBQU0sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzFCLE1BQUksQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHO0FBQzFCLFFBQUksS0FBSyxPQUFPO0FBQ2hCLE1BQUUsTUFBTSxJQUFJO0FBQ1osVUFBTSxPQUFPLG1CQUFtQixDQUFDO0FBQUEsRUFDbkM7QUFDRjtBQUVBLGVBQXNCLGtCQUFrQixTQUFnQztBQUN0RSxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxVQUFVO0FBQ2QsYUFBVyxVQUFVLE9BQU8sS0FBSyxDQUFDLEdBQUc7QUFDbkMsVUFBTSxNQUFNLEVBQUUsTUFBTTtBQUNwQixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sV0FBVyxJQUFJLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTztBQUNsRCxRQUFJLFNBQVMsV0FBVyxJQUFJLFFBQVE7QUFDbEMsZ0JBQVU7QUFDVixVQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNO0FBQUEsVUFDckMsR0FBRSxNQUFNLElBQUk7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFFBQVMsT0FBTSxPQUFPLG1CQUFtQixDQUFDO0FBQ2hEO0FBRUEsZUFBc0IsdUJBR1o7QUFDUixRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFHO0FBQUEsRUFDeEQ7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixZQUFZLFNBQW1DO0FBQ25FLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxhQUFXLFNBQVMsT0FBTyxPQUFPLEdBQUcsR0FBRztBQUN0QyxRQUFJLFNBQVMsV0FBVyxNQUFPLFFBQU87QUFBQSxFQUN4QztBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLG9CQUFpRDtBQUNyRSxTQUFPLE9BQU8sZ0JBQWdCO0FBQ2hDO0FBQ0EsZUFBc0Isa0JBQWtCLEdBQXNDO0FBQzVFLFFBQU0sT0FBTyxrQkFBa0IsQ0FBQztBQUNsQztBQUNBLGVBQXNCLHVCQUFvRDtBQUN4RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQXNDO0FBQy9FLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQUNBLGVBQXNCLHVCQUEwRDtBQUM5RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQTRDO0FBQ3JGLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQVlBLGVBQXNCLG9CQUFvQixVQU12QztBQUNELFFBQU0sWUFBWSxJQUFJLElBQUksQ0FBQyxHQUFHLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sYUFBYSxDQUFDLE1BQXVCLFVBQVUsSUFBSSxFQUFFLFlBQVksQ0FBQztBQUd4RSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksa0JBQWtCO0FBQ3RCLGFBQVcsS0FBSyxPQUFPLEtBQUssUUFBUSxHQUFHO0FBQ3JDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLFNBQVMsQ0FBQztBQUNqQix5QkFBbUI7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sWUFBWSxRQUFRO0FBR2pDLFFBQU0sVUFBVSxNQUFNLGNBQWM7QUFDcEMsTUFBSSxpQkFBaUI7QUFDckIsYUFBVyxLQUFLLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDcEMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sUUFBUSxDQUFDO0FBQ2hCLHdCQUFrQjtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxjQUFjLE9BQU87QUFHbEMsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLE1BQUksMEJBQTBCO0FBQzlCLGFBQVcsS0FBSyxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ2hDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLElBQUksQ0FBQztBQUNaLGlDQUEyQjtBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUNBLFFBQU0sa0JBQWtCLEdBQUc7QUFHM0IsUUFBTSxLQUFLLE1BQU0sZ0JBQWdCO0FBQ2pDLE1BQUksd0JBQXdCO0FBQzVCLGFBQVcsS0FBSyxPQUFPLEtBQUssRUFBRSxHQUFHO0FBQy9CLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLEdBQUcsQ0FBQztBQUNYLCtCQUF5QjtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxnQkFBZ0IsRUFBRTtBQUsvQixRQUFNLEtBQUssTUFBTSxtQkFBbUI7QUFDcEMsTUFBSSx1QkFBdUI7QUFDM0IsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLCtCQUF5QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDdEMsYUFBTyxHQUFHLENBQUM7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxtQkFBbUIsRUFBRTtBQUVsQyxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFJQSxlQUFzQixXQUEwQjtBQUM5QyxRQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU07QUFDcEM7OztBQ3BoQkEsSUFBSSxZQUE2QztBQUUxQyxTQUFTLGVBQWUsSUFBa0M7QUFDL0QsY0FBWTtBQUNkO0FBRUEsU0FBUyxTQUFpQjtBQUN4QixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ2hDO0FBRUEsZUFBZSxLQUFLLE9BQWlCLEtBQWEsU0FBaUQ7QUFDakcsUUFBTSxLQUFlLEVBQUUsSUFBSSxPQUFPLEdBQUcsT0FBTyxLQUFLLFNBQVMsT0FBTyxPQUFPLEVBQUU7QUFFMUUsUUFBTSxPQUFPLGlCQUFpQixNQUFNLFlBQVksQ0FBQyxJQUFJLEdBQUc7QUFDeEQsTUFBSSxVQUFVLFFBQVMsU0FBUSxNQUFNLE1BQU0sR0FBRyxPQUFPO0FBQUEsV0FDNUMsVUFBVSxPQUFRLFNBQVEsS0FBSyxNQUFNLEdBQUcsT0FBTztBQUFBLE1BQ25ELFNBQVEsSUFBSSxNQUFNLEdBQUcsT0FBTztBQUVqQyxNQUFJO0FBQ0YsVUFBTSxlQUFlLEVBQUU7QUFBQSxFQUN6QixTQUFTLEtBQUs7QUFDWixZQUFRLEtBQUssMkNBQTJDLEdBQUc7QUFBQSxFQUM3RDtBQUVBLE1BQUk7QUFDRixnQkFBWSxFQUFFO0FBQUEsRUFDaEIsUUFBUTtBQUFBLEVBRVI7QUFDRjtBQUVPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxLQUFLLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN0RixTQUFPLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDbEM7QUFDTyxTQUFTLE1BQU0sS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3ZGLFNBQU8sS0FBSyxTQUFTLEtBQUssT0FBTztBQUNuQztBQUVPLFNBQVMsY0FBYyxLQUF5RDtBQUNyRixNQUFJLGVBQWUsT0FBTztBQUN4QixXQUFPLEVBQUUsU0FBUyxJQUFJLFNBQVMsT0FBTyxJQUFJLFNBQVMsS0FBSztBQUFBLEVBQzFEO0FBQ0EsTUFBSTtBQUNGLFdBQU8sRUFBRSxTQUFTLE9BQU8sR0FBRyxHQUFHLE9BQU8sS0FBSztBQUFBLEVBQzdDLFFBQVE7QUFDTixXQUFPLEVBQUUsU0FBUyx1QkFBdUIsT0FBTyxLQUFLO0FBQUEsRUFDdkQ7QUFDRjtBQU9BLFNBQVMsT0FBTyxLQUF1RDtBQUNyRSxRQUFNLE1BQStCLENBQUM7QUFDdEMsYUFBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDeEMsUUFBSSxFQUFFLFlBQVksRUFBRSxTQUFTLE9BQU8sS0FBSyxFQUFFLFlBQVksTUFBTSxTQUFTLE1BQU0saUJBQWlCO0FBQzNGLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWCxXQUFXLE9BQU8sTUFBTSxZQUFZLCtCQUErQixLQUFLLENBQUMsR0FBRztBQUMxRSxVQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsNkJBQTZCLHVCQUF1QjtBQUFBLElBQ3pFLFdBQVcsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLE1BQU07QUFDbkQsVUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLE1BQU0sR0FBRyxJQUFJLENBQUM7QUFBQSxJQUM5QixPQUFPO0FBQ0wsVUFBSSxDQUFDLElBQUk7QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDs7O0FDdkVBLElBQU0sV0FBVztBQUNqQixJQUFNLFdBQVc7QUErQlYsSUFBTSxjQUFOLGNBQTBCLE1BQU07QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUE7QUFBQSxFQUVBLFlBQVksTUFPVDtBQUNELFVBQU0sS0FBSyxPQUFPO0FBQ2xCLFNBQUssT0FBTztBQUNaLFNBQUssU0FBUyxLQUFLO0FBQ25CLFNBQUssT0FBTyxLQUFLO0FBQ2pCLFNBQUssWUFBWSxLQUFLO0FBQ3RCLFNBQUssV0FBVyxLQUFLO0FBQ3JCLFNBQUssbUJBQW1CLEtBQUssb0JBQW9CO0FBQUEsRUFDbkQ7QUFDRjtBQUVPLElBQU0sZUFBTixNQUFtQjtBQUFBLEVBQ1A7QUFBQSxFQUVqQixZQUFZLFVBQW9CO0FBQzlCLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUE7QUFBQSxFQUdBLE1BQU0sU0FBMEI7QUFDOUIsVUFBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTztBQUMvQyxXQUFRLElBQTJCLFNBQVM7QUFBQSxFQUM5QztBQUFBO0FBQUEsRUFHQSxNQUFNLGFBQWEsUUFBa0M7QUFDbkQsUUFBSTtBQUNGLFlBQU0sS0FBSztBQUFBLFFBQ1Q7QUFBQSxRQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLG1CQUFtQixNQUFNLENBQUM7QUFBQSxNQUM1RjtBQUNBLGFBQU87QUFBQSxJQUNULFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLE1BQU0sbUJBQTBGO0FBQzlGLFVBQU0sS0FBSyxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDOUMsVUFBTSxPQUFPLE1BQU0sS0FBSyxVQUFVLE9BQU8sVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLEVBQUU7QUFDOUYsVUFBTSxJQUFJO0FBQ1YsV0FBTztBQUFBLE1BQ0wsT0FBUSxHQUF5QjtBQUFBLE1BQ2pDLFdBQVcsRUFBRTtBQUFBLE1BQ2IsZ0JBQWdCLEVBQUU7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxhQUFhLFlBQTRDO0FBQzdELFVBQU0sTUFBTSxHQUFHLFFBQVEsSUFBSSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLElBQUksS0FBSyxTQUFTLE1BQU0sSUFBSSxVQUFVO0FBQzFHLFVBQU0sTUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLE1BQzNCLFFBQVE7QUFBQSxNQUNSLFNBQVMsRUFBRSxlQUFlLFVBQVUsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUFBLElBQzFELENBQUM7QUFDRCxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxDQUFDLElBQUksR0FBSSxPQUFNLE1BQU0sS0FBSyxVQUFVLEtBQUssV0FBVyxVQUFVLEVBQUU7QUFDcEUsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLFdBQVcsTUFBc0M7QUFDckQsUUFBSTtBQUNGLFlBQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxRQUNyQjtBQUFBLFFBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUMsUUFBUSxtQkFBbUIsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLE1BQ2xJO0FBQ0EsWUFBTSxJQUFJO0FBQ1YsYUFBTyxFQUFFLE9BQU87QUFBQSxJQUNsQixTQUFTLEtBQUs7QUFDWixVQUFJLGVBQWUsZUFBZSxJQUFJLGFBQWEsWUFBYSxRQUFPO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE1BQU0sUUFBUSxNQUE4QztBQUMxRCxVQUFNLE9BQU8sS0FBSztBQUNsQixVQUFNLE1BQU0sVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUM7QUFDNUYsUUFBSSxNQUFxQixLQUFLLGVBQWU7QUFDN0MsVUFBTSxjQUFjO0FBRXBCLGFBQVMsVUFBVSxHQUFHLFdBQVcsYUFBYSxXQUFXO0FBQ3ZELFlBQU0sT0FBZ0M7QUFBQSxRQUNwQyxTQUFTLEtBQUs7QUFBQSxRQUNkLFNBQVMsS0FBSztBQUFBLFFBQ2QsUUFBUSxLQUFLLFNBQVM7QUFBQSxNQUN4QjtBQUNBLFVBQUksSUFBSyxNQUFLLE1BQU07QUFDcEIsVUFBSTtBQUNGLGNBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxPQUFPLEtBQUssSUFBSTtBQUNqRCxjQUFNLE1BQU07QUFDWixlQUFPLEVBQUUsTUFBTSxJQUFJLFFBQVEsTUFBTSxLQUFLLElBQUksUUFBUSxLQUFLLEtBQUssSUFBSSxRQUFRLFNBQVM7QUFBQSxNQUNuRixTQUFTLEtBQUs7QUFDWixZQUFJLEVBQUUsZUFBZSxhQUFjLE9BQU07QUFDekMsWUFBSSxJQUFJLFdBQVcsT0FBTyxDQUFDLEtBQUs7QUFFOUIsZ0JBQU0sTUFBTSxLQUFLLFdBQVcsSUFBSTtBQUNoQyxjQUFJLENBQUMsSUFBSyxPQUFNO0FBQ2hCO0FBQUEsUUFDRjtBQUNBLFlBQUksQ0FBQyxJQUFJLGFBQWEsWUFBWSxZQUFhLE9BQU07QUFDckQsY0FBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLElBQUksTUFBTSxtQ0FBbUMsSUFBSSxFQUFFO0FBQUEsRUFDM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU0EsTUFBTSxZQUFZLE1BQXNEO0FBQ3RFLFFBQUksS0FBSyxNQUFNLFdBQVcsRUFBRyxPQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFDOUUsVUFBTSxjQUFjO0FBQ3BCLFFBQUksVUFBbUI7QUFFdkIsYUFBUyxVQUFVLEdBQUcsV0FBVyxhQUFhLFdBQVc7QUFDdkQsVUFBSTtBQUNGLGNBQU0sUUFBUSxNQUFNLFFBQVE7QUFBQSxVQUMxQixLQUFLLE1BQU0sSUFBSSxPQUFPLFNBQVM7QUFDN0Isa0JBQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxjQUNyQjtBQUFBLGNBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsY0FDbkQ7QUFBQSxnQkFDRSxTQUFTLEtBQUs7QUFBQSxnQkFDZCxVQUFVO0FBQUEsY0FDWjtBQUFBLFlBQ0Y7QUFDQSxtQkFBTztBQUFBLGNBQ0wsTUFBTSxLQUFLO0FBQUEsY0FDWCxLQUFNLElBQXdCO0FBQUEsWUFDaEM7QUFBQSxVQUNGLENBQUM7QUFBQSxRQUNIO0FBRUEsY0FBTSxPQUFPLE1BQU0sS0FBSyxjQUFjO0FBQ3RDLGNBQU0sT0FBTyxNQUFNLEtBQUs7QUFBQSxVQUN0QjtBQUFBLFVBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsVUFDbkQ7QUFBQSxZQUNFLFdBQVcsS0FBSztBQUFBLFlBQ2hCLE1BQU0sTUFBTSxJQUFJLENBQUMsVUFBVTtBQUFBLGNBQ3pCLE1BQU0sS0FBSztBQUFBLGNBQ1gsTUFBTTtBQUFBLGNBQ04sTUFBTTtBQUFBLGNBQ04sS0FBSyxLQUFLO0FBQUEsWUFDWixFQUFFO0FBQUEsVUFDSjtBQUFBLFFBQ0Y7QUFDQSxjQUFNLFVBQVcsS0FBeUI7QUFDMUMsY0FBTSxTQUFTLE1BQU0sS0FBSztBQUFBLFVBQ3hCO0FBQUEsVUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxVQUNuRDtBQUFBLFlBQ0UsU0FBUyxLQUFLO0FBQUEsWUFDZCxNQUFNO0FBQUEsWUFDTixTQUFTLENBQUMsS0FBSyxHQUFHO0FBQUEsVUFDcEI7QUFBQSxRQUNGO0FBQ0EsY0FBTSxZQUFZO0FBQ2xCLFlBQUk7QUFDRixnQkFBTSxLQUFLO0FBQUEsWUFDVDtBQUFBLFlBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLG1CQUFtQixXQUFXLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxZQUN0RztBQUFBLGNBQ0UsS0FBSyxVQUFVO0FBQUEsY0FDZixPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFNBQVMsS0FBSztBQUNaLGNBQUksV0FBVyxHQUFHLEtBQUssVUFBVSxhQUFhO0FBQzVDLHNCQUFVO0FBQ1Ysa0JBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQ25DO0FBQUEsVUFDRjtBQUNBLGdCQUFNO0FBQUEsUUFDUjtBQUNBLGVBQU87QUFBQSxVQUNMLFdBQVcsVUFBVTtBQUFBLFVBQ3JCLEtBQUssVUFBVTtBQUFBLFVBQ2YsT0FBTyxLQUFLLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxJQUFJO0FBQUEsUUFDM0M7QUFBQSxNQUNGLFNBQVMsS0FBSztBQUNaLGtCQUFVO0FBQ1YsWUFBSSxFQUFFLGVBQWUsYUFBYyxPQUFNO0FBQ3pDLFlBQUssQ0FBQyxJQUFJLGFBQWEsQ0FBQyxXQUFXLEdBQUcsS0FBTSxZQUFZLFlBQWEsT0FBTTtBQUMzRSxjQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sbUJBQW1CLFFBQVEsVUFBVSxJQUFJLE1BQU0saUNBQWlDO0FBQUEsRUFDeEY7QUFBQSxFQUVBLE1BQWMsZ0JBQTJEO0FBQ3ZFLFVBQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxNQUNyQjtBQUFBLE1BQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGtCQUFrQixXQUFXLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxJQUN2RztBQUNBLFVBQU0sVUFBVyxJQUFvQyxPQUFPO0FBQzVELFVBQU0sU0FBUyxNQUFNLEtBQUs7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGdCQUFnQixPQUFPO0FBQUEsSUFDNUU7QUFDQSxXQUFPO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTCxTQUFVLE9BQXFDLEtBQUs7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQWMsVUFBVSxRQUFnQixNQUFjLE1BQWtDO0FBQ3RGLFVBQU0sTUFBTSxLQUFLLFdBQVcsTUFBTSxJQUFJLE9BQU8sR0FBRyxRQUFRLEdBQUcsSUFBSTtBQUMvRCxVQUFNLE9BQW9CO0FBQUEsTUFDeEI7QUFBQSxNQUNBLFNBQVM7QUFBQSxRQUNQLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRztBQUFBLFFBQzFDLFFBQVE7QUFBQSxRQUNSLHdCQUF3QjtBQUFBLFFBQ3hCLEdBQUksT0FBTyxFQUFFLGdCQUFnQixtQkFBbUIsSUFBSSxDQUFDO0FBQUEsTUFDdkQ7QUFBQSxNQUNBLEdBQUksT0FBTyxFQUFFLE1BQU0sS0FBSyxVQUFVLElBQUksRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMvQztBQUNBLFFBQUk7QUFDSixRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSyxJQUFJO0FBQUEsSUFDN0IsU0FBUyxRQUFRO0FBQ2YsWUFBTSxJQUFJLFlBQVk7QUFBQSxRQUNwQixRQUFRO0FBQUEsUUFDUixNQUFNO0FBQUEsUUFDTixTQUFTLFlBQVksY0FBYyxNQUFNLEVBQUUsT0FBTztBQUFBLFFBQ2xELFdBQVc7QUFBQSxRQUNYLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSSxJQUFJLFdBQVcsSUFBSyxRQUFPO0FBQy9CLFFBQUksU0FBa0I7QUFDdEIsVUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0FBQzVCLFFBQUksTUFBTTtBQUNSLFVBQUk7QUFDRixpQkFBUyxLQUFLLE1BQU0sSUFBSTtBQUFBLE1BQzFCLFFBQVE7QUFDTixpQkFBUztBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLElBQUksR0FBSSxPQUFNLE1BQU0sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEdBQUcsTUFBTSxJQUFJLElBQUksRUFBRTtBQUNsRixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUEsTUFBYyxVQUFVLEtBQWUsT0FBcUM7QUFDMUUsUUFBSSxTQUFrQjtBQUN0QixRQUFJO0FBQ0YsWUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0FBQzVCLFVBQUksS0FBTSxVQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsSUFDcEMsUUFBUTtBQUFBLElBRVI7QUFDQSxXQUFPLEtBQUssb0JBQW9CLEtBQUssUUFBUSxLQUFLO0FBQUEsRUFDcEQ7QUFBQSxFQUVRLG9CQUFvQixLQUFlLE1BQWUsT0FBNEI7QUFDcEYsVUFBTSxNQUNKLE9BQU8sU0FBUyxZQUFZLFFBQVEsYUFBYSxPQUM3QyxPQUFRLEtBQThCLE9BQU8sSUFDN0MsSUFBSTtBQUNWLFFBQUksV0FBb0M7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7QUFFNUMsWUFBTSxPQUFPLElBQUksUUFBUSxJQUFJLHVCQUF1QjtBQUNwRCxVQUFJLFNBQVMsT0FBTyxjQUFjLEtBQUssR0FBRyxHQUFHO0FBQzNDLG1CQUFXO0FBQ1gsb0JBQVk7QUFBQSxNQUNkLE9BQU87QUFDTCxtQkFBVztBQUFBLE1BQ2I7QUFBQSxJQUNGLFdBQVcsSUFBSSxXQUFXLEtBQUs7QUFDN0IsaUJBQVc7QUFBQSxJQUNiLFdBQVcsSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7QUFDbkQsaUJBQVc7QUFBQSxJQUNiLFdBQVcsSUFBSSxVQUFVLEtBQUs7QUFDNUIsaUJBQVc7QUFDWCxrQkFBWTtBQUFBLElBQ2QsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZDtBQUNBLFdBQU8sSUFBSSxZQUFZO0FBQUEsTUFDckIsUUFBUSxJQUFJO0FBQUEsTUFDWjtBQUFBLE1BQ0EsU0FBUyxHQUFHLEtBQUssV0FBTSxJQUFJLE1BQU0sS0FBSyxHQUFHO0FBQUEsTUFDekM7QUFBQSxNQUNBO0FBQUEsTUFDQSxrQkFBa0IsYUFBYSxlQUFlLG9CQUFvQixJQUFJLE9BQU8sSUFBSTtBQUFBLElBQ25GLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFRQSxTQUFTLG9CQUFvQixTQUFpQztBQUM1RCxRQUFNLFFBQVEsUUFBUSxJQUFJLG1CQUFtQjtBQUM3QyxNQUFJLE9BQU87QUFDVCxVQUFNLElBQUksT0FBTyxTQUFTLE9BQU8sRUFBRTtBQUNuQyxRQUFJLE9BQU8sU0FBUyxDQUFDLEtBQUssSUFBSSxFQUFHLFFBQU87QUFBQSxFQUMxQztBQUNBLFFBQU0sYUFBYSxRQUFRLElBQUksYUFBYTtBQUM1QyxNQUFJLFlBQVk7QUFDZCxVQUFNLFFBQVEsT0FBTyxTQUFTLFlBQVksRUFBRTtBQUM1QyxRQUFJLE9BQU8sU0FBUyxLQUFLLEtBQUssU0FBUyxHQUFHO0FBQ3hDLGFBQU8sS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUksSUFBSTtBQUFBLElBQ3pDO0FBQ0EsVUFBTSxTQUFTLEtBQUssTUFBTSxVQUFVO0FBQ3BDLFFBQUksT0FBTyxTQUFTLE1BQU0sRUFBRyxRQUFPLEtBQUssTUFBTSxTQUFTLEdBQUk7QUFBQSxFQUM5RDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxNQUFzQjtBQUV4QyxTQUFPLEtBQUssTUFBTSxHQUFHLEVBQUUsSUFBSSxrQkFBa0IsRUFBRSxLQUFLLEdBQUc7QUFDekQ7QUFFQSxTQUFTLFVBQVUsU0FBaUIsS0FBMEI7QUFFNUQsUUFBTSxPQUFPLElBQUksYUFBYSxlQUFlLE1BQU87QUFDcEQsUUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFHO0FBQzdDLFNBQU8sS0FBSyxJQUFJLEtBQVEsT0FBTyxNQUFNLFVBQVUsS0FBSyxNQUFNO0FBQzVEO0FBRUEsU0FBUyxXQUFXLEtBQWtDO0FBQ3BELFNBQU8sZUFBZSxlQUFlLElBQUksYUFBYTtBQUN4RDtBQUVBLFNBQVMsTUFBTSxJQUEyQjtBQUN4QyxTQUFPLElBQUksUUFBUSxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQztBQUM3QztBQUVPLFNBQVNBLFVBQVMsT0FBdUI7QUFFOUMsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFLE9BQU8sS0FBSztBQUMzQyxNQUFJLE1BQU07QUFDVixhQUFXLEtBQUssS0FBTSxRQUFPLE9BQU8sYUFBYSxDQUFDO0FBQ2xELFNBQU8sS0FBSyxHQUFHO0FBQ2pCOzs7QUM3V0EsSUFBTSxjQUFjO0FBU3BCLElBQU0sdUJBQTRDLG9CQUFJLElBQUksQ0FBQyxXQUFXLENBQUM7QUFFaEUsU0FBUyxVQUFVLFNBQWtCLEtBQXdDO0FBQ2xGLFFBQU0sWUFBWSxjQUFjLE9BQU87QUFDdkMsUUFBTSxTQUEyQixDQUFDO0FBQ2xDLFFBQU0sV0FBcUIsQ0FBQztBQUM1QixRQUFNLFFBQVEsb0JBQUksSUFBWTtBQUM5QixRQUFNLGFBQWEsb0JBQUksSUFBMkI7QUFDbEQsUUFBTSxrQkFBa0IscUJBQXFCLElBQUksSUFBSSxRQUFRO0FBQzdELGFBQVcsT0FBTyxXQUFXO0FBQzNCLFFBQUk7QUFDRixZQUFNLElBQUksV0FBVyxLQUFLLEdBQUc7QUFDN0IsVUFBSSxDQUFDLEdBQUc7QUFDTixZQUFJLGlCQUFpQjtBQUduQixnQkFBTSxVQUFVLFlBQVksS0FBSyxHQUFHO0FBQ3BDLGNBQUksUUFBUyxZQUFXLElBQUksUUFBUSxVQUFVLFFBQVEsV0FBVztBQUFBLFFBQ25FO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsZUFBUyxLQUFLLEVBQUUsUUFBUTtBQUN4QixZQUFNLElBQUksRUFBRSxRQUFRO0FBQ3BCLFVBQUksSUFBSSxlQUFlLFNBQVMsS0FBSyxJQUFJLGVBQWUsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEdBQUc7QUFDM0YsZUFBTyxLQUFLLENBQUM7QUFBQSxNQUNmO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFHQSxRQUFNLGNBQXVFLENBQUM7QUFDOUUsYUFBVyxDQUFDLElBQUksSUFBSSxLQUFLLFlBQVk7QUFDbkMsUUFBSSxNQUFNLElBQUksRUFBRSxFQUFHO0FBQ25CLGdCQUFZLEtBQUssRUFBRSxVQUFVLElBQUksYUFBYSxLQUFLLENBQUM7QUFBQSxFQUN0RDtBQUNBLFNBQU8sRUFBRSxRQUFRLGNBQWMsVUFBVSxZQUFZO0FBQ3ZEO0FBRUEsU0FBUyxZQUNQLE1BQ0EsS0FDeUQ7QUFDekQsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFHVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUc5QyxRQUFNLEtBQUssRUFBRTtBQUNiLE1BQUksT0FBTyxXQUFXLE9BQU8sZ0NBQWdDLENBQUMsSUFBSSxFQUFFLE1BQU0sR0FBRztBQUMzRSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sU0FDSCxPQUFPLEVBQUUsWUFBWSxZQUFZLEVBQUUsV0FDbkMsT0FBTyxJQUFJLEVBQUUsWUFBWSxHQUFHLFdBQVcsWUFDckMsSUFBSSxJQUFJLEVBQUUsWUFBWSxHQUFHLE1BQU0sR0FBRztBQUN2QyxNQUFJLE9BQU8sV0FBVyxZQUFZLENBQUMsWUFBWSxLQUFLLE1BQU0sRUFBRyxRQUFPO0FBQ3BFLFNBQU8sRUFBRSxVQUFVLFFBQVEsYUFBYSxlQUFlLE1BQU0sUUFBUSxHQUFHLEVBQUU7QUFDNUU7QUFFQSxTQUFTLGVBQWUsTUFBZSxTQUFpQixLQUFzQztBQUM1RixNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLFFBQU0sYUFBYSxJQUFJLElBQUksSUFBSSxFQUFFLElBQUksR0FBRyxZQUFZLEdBQUcsTUFBTTtBQUM3RCxTQUNFLFVBQVUsSUFBSSxZQUFZLElBQUksR0FBRyxXQUFXLEtBQzVDLFVBQVUsSUFBSSxZQUFZLE1BQU0sR0FBRyxXQUFXLEtBQzlDLFVBQVUsSUFBSSxFQUFFLE1BQU0sR0FBRyxXQUFXLEtBQ3BDLHdCQUF3QixNQUFNLE9BQU8sS0FDckMsd0JBQXdCLElBQUksU0FBUztBQUV6QztBQUVBLFNBQVMsd0JBQXdCLE1BQWUsU0FBZ0M7QUFDOUUsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sU0FBUyxtQkFBbUIsS0FBSyxPQUFPO0FBQzlDLFVBQUksT0FBUSxRQUFPO0FBQ25CO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLG1CQUFtQixRQUFnQixTQUFnQztBQUMxRSxNQUFJO0FBQ0YsVUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLGdCQUFnQjtBQUM1QyxRQUFJLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxjQUFlLFFBQU87QUFDdkUsVUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLHNEQUFzRDtBQUN2RixRQUFJLENBQUMsU0FBUyxNQUFNLENBQUMsTUFBTSxRQUFTLFFBQU87QUFDM0MsV0FBTyxNQUFNLENBQUMsS0FBSztBQUFBLEVBQ3JCLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyx3QkFBd0IsUUFBa0Q7QUFDakYsTUFBSSxDQUFDLE9BQVEsUUFBTztBQUNwQixNQUFJO0FBQ0YsVUFBTSxNQUFNLElBQUksSUFBSSxNQUFNO0FBQzFCLFFBQUksSUFBSSxhQUFhLFdBQVcsSUFBSSxhQUFhLGNBQWUsUUFBTztBQUN2RSxVQUFNLFFBQVEsSUFBSSxTQUFTLE1BQU0sb0NBQW9DO0FBQ3JFLFdBQU8sUUFBUSxDQUFDLEtBQUs7QUFBQSxFQUN2QixRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsY0FBY0MsTUFBeUI7QUFLOUMsUUFBTSxNQUFpQixDQUFDO0FBQ3hCLFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUNBLElBQUc7QUFDN0IsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE9BQU8sTUFBTSxJQUFJO0FBQ3ZCLFFBQUksU0FBUyxRQUFRLFNBQVMsT0FBVztBQUN6QyxRQUFJLE9BQU8sU0FBUyxTQUFVO0FBQzlCLFFBQUksS0FBSyxJQUFJLElBQWMsRUFBRztBQUM5QixTQUFLLElBQUksSUFBYztBQUV2QixRQUFJLGVBQWUsSUFBSSxHQUFHO0FBQ3hCLFVBQUksS0FBSyxZQUFZLElBQUksQ0FBQztBQUFBLElBQzVCO0FBQ0EsUUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGlCQUFXLEtBQUssS0FBTSxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ3BDLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxJQUErQixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDOUU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxlQUFlLE1BQWdEO0FBQ3RFLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsUUFBTSxXQUFXLEVBQUU7QUFDbkIsTUFDRSxhQUFhLFdBQ2IsYUFBYSxnQ0FDYixhQUFhLGtCQUNiO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUFPLE9BQU8sRUFBRSxZQUFZLFlBQVksT0FBTyxFQUFFLFdBQVcsWUFBWSxFQUFFLFdBQVc7QUFDdkY7QUFFQSxTQUFTLFlBQVksTUFBd0Q7QUFDM0UsTUFBSSxLQUFLLGVBQWUsZ0NBQWdDLE9BQU8sS0FBSyxVQUFVLFVBQVU7QUFDdEYsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxLQUFjLEtBQThDO0FBQzlFLE1BQUksT0FBTyxRQUFRLFlBQVksUUFBUSxLQUFNLFFBQU87QUFDcEQsUUFBTSxJQUFJO0FBRVYsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFFOUMsUUFBTSxTQUFTLFVBQVUsRUFBRSxPQUFPO0FBS2xDLFFBQU0sU0FBUyxJQUFJLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDakMsTUFBSSxDQUFDLE9BQVEsUUFBTztBQUVwQixRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksSUFBSSxNQUFNLFlBQVksR0FBRyxNQUFNO0FBR3RELFFBQU0sY0FBYyxJQUFJLFlBQVksSUFBSTtBQUN4QyxRQUFNLGFBQWEsSUFBSSxZQUFZLE1BQU07QUFDekMsUUFBTSxnQkFBZ0IsSUFBSSxZQUFZLE1BQU07QUFDNUMsUUFBTSxTQUNKLFVBQVUsYUFBYSxXQUFXLEtBQ2xDLFVBQVUsWUFBWSxXQUFXLEtBQ2pDLFVBQVUsWUFBWSxXQUFXLEtBQ2pDLFVBQVUsT0FBTyxXQUFXO0FBQzlCLFFBQU0sWUFDSixVQUFVLFlBQVksT0FBTyxLQUM3QixVQUFVLFlBQVksTUFBTSxLQUM1QixVQUFVLE9BQU8sV0FBVztBQUM5QixNQUFJLENBQUMsVUFBVSxDQUFDLFVBQVcsUUFBTztBQU1sQyxRQUFNLFNBQVMsb0JBQW9CLFlBQVksYUFBYSxZQUFZLGFBQWE7QUFFckYsUUFBTSxZQUFZLElBQUksSUFBSSxJQUFJLEVBQUUsVUFBVSxHQUFHLGtCQUFrQixHQUFHLE1BQU07QUFDeEUsUUFBTSxlQUFlLFVBQVUsV0FBVyxJQUFJO0FBQzlDLFFBQU0saUJBQWlCLFVBQVUsT0FBTyxTQUFTLEtBQUs7QUFDdEQsUUFBTSxPQUFPLGdCQUFnQjtBQUM3QixRQUFNLGNBQWMsaUJBQWlCLFdBQVcsUUFBUSxjQUFjO0FBQ3RFLFFBQU0sZ0JBQWdCLHFCQUFxQixHQUFHLFFBQVEsSUFBSSxVQUFVO0FBRXBFLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUSxLQUFLLENBQUM7QUFDMUMsUUFBTSxtQkFBbUIsSUFBSSxXQUFXLFVBQVU7QUFDbEQsUUFBTSxXQUFXLGdCQUFnQixvQkFBb0IsUUFBUTtBQUM3RCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sT0FBTyxZQUFZLG9CQUFvQixRQUFRO0FBQ3JELFFBQU0sUUFBUSxhQUFhLE1BQU07QUFFakMsUUFBTSxZQUFZLGtCQUFrQixHQUFHLE1BQU07QUFJN0MsUUFBTSxXQUNKLGlCQUFpQixVQUFVLE9BQU8sVUFBVSxDQUFDLEtBQUssaUJBQWlCLFVBQVUsRUFBRSxVQUFVLENBQUM7QUFDNUYsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUV0QixRQUFNLFFBQVEsSUFBSSxFQUFFLEtBQUs7QUFDekIsUUFBTSxZQUFZLFVBQVUsT0FBTyxLQUFLLEtBQUssVUFBVSxVQUFVLE9BQU8sS0FBSyxDQUFDO0FBRTlFLFFBQU0sT0FBTyxZQUFZLENBQUM7QUFDMUIsUUFBTSxRQUFRLElBQUksT0FBTyxLQUFLO0FBRTlCLFFBQU0sUUFBd0I7QUFBQSxJQUM1QixVQUFVO0FBQUEsSUFDVixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixXQUFXO0FBQUEsSUFDWCxtQkFBbUIsSUFBSTtBQUFBLElBQ3ZCLGNBQWMsSUFBSTtBQUFBLElBQ2xCLHNCQUFzQjtBQUFBLElBQ3RCLFdBQVcsR0FBRyxnQkFBZ0IsSUFBSSxNQUFNLFdBQVcsTUFBTTtBQUFBLElBQ3pELFlBQVk7QUFBQSxJQUNaLGlCQUFpQixVQUFVLE9BQU8sbUJBQW1CO0FBQUEsSUFDckQsbUJBQW1CLFVBQVUsT0FBTyx5QkFBeUI7QUFBQSxJQUM3RCxrQkFBa0IsVUFBVSxPQUFPLHVCQUF1QjtBQUFBLElBQzFELHFCQUFxQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDN0QsaUJBQWlCLFVBQVUsT0FBTyxvQkFBb0I7QUFBQSxJQUN0RCxvQkFBb0I7QUFBQSxNQUNsQixJQUFJLElBQUksT0FBTyx1QkFBdUIsR0FBRyxNQUFNLEdBQUcsV0FDL0MsT0FBbUM7QUFBQSxJQUN4QztBQUFBLElBQ0E7QUFBQSxJQUNBLGVBQWUsaUJBQWlCLE1BQU0sSUFBSTtBQUFBLElBQzFDLE1BQU0sVUFBVSxPQUFPLElBQUk7QUFBQSxJQUMzQixvQkFBb0IsV0FBVyxPQUFPLGtCQUFrQjtBQUFBLElBQ3hELFFBQVEsVUFBVSxPQUFPLE1BQU0sS0FBSyxVQUFVLEVBQUUsTUFBTTtBQUFBLElBQ3RELGlCQUFpQixVQUFVLE9BQU8sU0FBUztBQUFBLElBQzNDO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWSxVQUFVLE9BQU8sY0FBYztBQUFBLElBQzNDLGVBQWUsVUFBVSxPQUFPLGFBQWE7QUFBQSxJQUM3QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsYUFBYSxVQUFVLE9BQU8sV0FBVztBQUFBLElBQ3pDLFlBQVk7QUFBQSxJQUNaLGdCQUFnQixVQUFVLE9BQU8sY0FBYztBQUFBLElBQy9DLG9CQUFvQjtBQUFBLE1BQ2xCO0FBQUEsUUFDRSxhQUFhLElBQUk7QUFBQSxRQUNqQixPQUFPLFVBQVUsT0FBTyxjQUFjO0FBQUEsUUFDdEMsVUFBVSxVQUFVLE9BQU8sYUFBYTtBQUFBLFFBQ3hDLFNBQVMsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNyQyxRQUFRLFVBQVUsT0FBTyxXQUFXO0FBQUEsUUFDcEMsT0FBTztBQUFBLFFBQ1AsV0FBVyxVQUFVLE9BQU8sY0FBYztBQUFBLE1BQzVDO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFBQSxJQUNBLGdCQUFnQjtBQUFBLElBQ2hCLGNBQWM7QUFBQSxJQUNkLGFBQWE7QUFBQSxJQUNiLHNCQUFzQjtBQUFBLElBQ3RCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsRUFDbEI7QUFFQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGtCQUFrQixHQUE0QixRQUE0QztBQUNqRyxNQUFJLE9BQU8sMkJBQTJCLE9BQU8sd0JBQXlCLFFBQU87QUFDN0UsTUFBSSxPQUFPLDBCQUEyQixRQUFPO0FBQzdDLE1BQUksT0FBTyxvQkFBb0IsUUFBUSxPQUFPLHFCQUFzQixRQUFPO0FBQzNFLE1BQUksRUFBRSxlQUFlLDhCQUE4QjtBQUFBLEVBRW5EO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxnQkFBZ0IsVUFBNkM7QUFDcEUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFNBQU8sSUFDSjtBQUFBLElBQUksQ0FBQyxNQUNKLE9BQU8sTUFBTSxZQUFZLEtBQUssVUFBVSxJQUFJLE9BQVEsRUFBd0IsSUFBSSxJQUFJO0FBQUEsRUFDdEYsRUFDQyxPQUFPLENBQUMsTUFBbUIsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLENBQUM7QUFDckU7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsSUFDM0MsT0FBUSxFQUErQixXQUFXLElBQ2xEO0FBQUEsRUFDTixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsWUFBWSxVQUFnRDtBQUNuRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsUUFBTSxNQUFtQixDQUFDO0FBQzFCLGFBQVcsS0FBSyxLQUFLO0FBQ25CLFFBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFVBQU0sSUFBSTtBQUNWLFVBQU0sUUFBUSxVQUFVLEVBQUUsR0FBRztBQUM3QixVQUFNLFdBQVcsVUFBVSxFQUFFLFlBQVk7QUFDekMsVUFBTSxVQUFVLFVBQVUsRUFBRSxXQUFXO0FBQ3ZDLFFBQUksQ0FBQyxTQUFTLENBQUMsU0FBVTtBQUN6QixRQUFJLEtBQUssRUFBRSxPQUFPLFVBQVUsU0FBUyxXQUFXLFNBQVMsQ0FBQztBQUFBLEVBQzVEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLFFBQThDO0FBQ2xFLFFBQU0sV0FBVyxJQUFJLE9BQU8saUJBQWlCO0FBQzdDLFFBQU0sVUFBVSxXQUFXLFFBQVEsU0FBUyxLQUFLLElBQUksQ0FBQztBQUN0RCxRQUFNLFVBQVUsUUFBUSxJQUFJLE9BQU8sUUFBUSxHQUFHLEtBQUs7QUFDbkQsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxTQUFTLENBQUMsR0FBRyxTQUFTLEdBQUcsT0FBTyxFQUFFLE9BQU8sQ0FBQyxNQUFNO0FBQ3BELFFBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNLFFBQU87QUFDaEQsVUFBTSxLQUNKLFVBQVcsRUFBOEIsU0FBUyxLQUNsRCxVQUFXLEVBQThCLE1BQU07QUFDakQsUUFBSSxDQUFDLEdBQUksUUFBTztBQUNoQixRQUFJLEtBQUssSUFBSSxFQUFFLEVBQUcsUUFBTztBQUN6QixTQUFLLElBQUksRUFBRTtBQUNYLFdBQU87QUFBQSxFQUNULENBQUM7QUFDRCxTQUFPLE9BQU8sSUFBSSxDQUFDLFFBQVEsV0FBVyxHQUE4QixDQUFDO0FBQ3ZFO0FBRUEsU0FBUyxXQUFXLEdBQXVDO0FBQ3pELFFBQU0sT0FBTyxVQUFVLEVBQUUsSUFBSTtBQUM3QixRQUFNLFdBQVcsZ0JBQWdCLEdBQUcsSUFBSTtBQUN4QyxRQUFNQyxRQUFPLElBQUksRUFBRSxhQUFhO0FBQ2hDLFFBQU0sWUFBWSxJQUFJLEVBQUUsVUFBVTtBQUNsQyxRQUFNLGFBQWEsVUFBVSxXQUFXLGVBQWU7QUFDdkQsUUFBTSxVQUFVLFVBQVUsRUFBRSxZQUFZO0FBQ3hDLFFBQU0sVUFDSixVQUFVLEVBQUUsU0FBUyxLQUNyQixVQUFVLEVBQUUsTUFBTSxLQUNsQixHQUFHLFFBQVEsT0FBTyxJQUFJLEtBQUssT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQzNELFNBQU87QUFBQSxJQUNMLFVBQVU7QUFBQSxJQUNWLFlBQWEsUUFBUTtBQUFBLElBQ3JCLGNBQWMsWUFBWTtBQUFBLElBQzFCLG1CQUFtQjtBQUFBLElBQ25CLFFBQVE7QUFBQSxJQUNSLE9BQU87QUFBQSxJQUNQLGNBQWMsZUFBZSxPQUFPLGFBQWEsTUFBTztBQUFBLElBQ3hELE9BQU8sVUFBVUEsT0FBTSxLQUFLO0FBQUEsSUFDNUIsUUFBUSxVQUFVQSxPQUFNLE1BQU07QUFBQSxJQUM5QixVQUFVO0FBQUEsSUFDVixnQkFBZ0I7QUFBQSxJQUNoQixrQkFBa0I7QUFBQSxJQUNsQixpQkFBaUI7QUFBQSxFQUNuQjtBQUNGO0FBRUEsU0FBUyxnQkFBZ0IsR0FBNEIsTUFBb0M7QUFDdkYsTUFBSSxTQUFTLFFBQVMsUUFBTyxVQUFVLEVBQUUsZUFBZSxLQUFLLFVBQVUsRUFBRSxTQUFTO0FBQ2xGLFFBQU0sV0FBVyxRQUFRLElBQUksRUFBRSxVQUFVLEdBQUcsUUFBUTtBQUNwRCxNQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sVUFBVSxFQUFFLGVBQWU7QUFFN0QsTUFBSSxPQUFnRDtBQUNwRCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLEtBQUssVUFBVSxFQUFFLFlBQVk7QUFDbkMsVUFBTSxNQUFNLFVBQVUsRUFBRSxHQUFHO0FBQzNCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsUUFBSSxPQUFPLGFBQWE7QUFDdEIsWUFBTSxLQUFLLFVBQVUsRUFBRSxPQUFPLEtBQUs7QUFDbkMsVUFBSSxDQUFDLFFBQVEsS0FBSyxLQUFLLFFBQVMsUUFBTyxFQUFFLEtBQUssU0FBUyxHQUFHO0FBQUEsSUFDNUQsV0FBVyxDQUFDLE1BQU07QUFFaEIsYUFBTyxFQUFFLEtBQUssU0FBUyxFQUFFO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0EsU0FBTyxNQUFNLE9BQU87QUFDdEI7QUFFQSxTQUFTLGlCQUFpQixNQUFjLE1BQTJCO0FBQ2pFLE1BQUksS0FBSyxXQUFXLEVBQUcsUUFBTztBQUM5QixNQUFJLE1BQU07QUFDVixhQUFXLEtBQUssS0FBTSxPQUFNLElBQUksTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUTtBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxNQUFJLENBQUMsRUFBRyxRQUFPO0FBRWYsUUFBTSxJQUFJLElBQUksS0FBSyxDQUFDO0FBQ3BCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTztBQUN0QyxTQUFPLEVBQUUsWUFBWTtBQUN2QjtBQUVBLFNBQVMsVUFBVSxHQUEyQjtBQUM1QyxTQUFPLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxJQUFJLElBQUk7QUFDckQ7QUFDQSxTQUFTLFdBQVcsR0FBNEI7QUFDOUMsU0FBTyxPQUFPLE1BQU0sWUFBWSxJQUFJO0FBQ3RDO0FBQ0EsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ3hELE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsVUFBTSxJQUFJLE9BQU8sQ0FBQztBQUNsQixRQUFJLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUFBLEVBQ2pDO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLEdBQW9CO0FBQ3JDLFNBQU8sVUFBVSxDQUFDLEtBQUs7QUFDekI7QUFDQSxTQUFTLElBQUksR0FBNEM7QUFDdkQsU0FBTyxPQUFPLE1BQU0sWUFBWSxNQUFNLFFBQVEsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUN6RCxJQUNEO0FBQ047QUFDQSxTQUFTLFFBQVEsR0FBdUI7QUFDdEMsU0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQztBQUNqQztBQXdCQSxTQUFTLGlCQUNQLFdBQ0EsUUFDQSxVQUNTO0FBQ1QsTUFBSSxVQUFXLFFBQU87QUFDdEIsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUN0QixRQUFNLFdBQVcsSUFBSSxPQUFPLFFBQVE7QUFDcEMsUUFBTSxPQUFPLFdBQVcsU0FBUyxPQUFPO0FBQ3hDLE1BQUksTUFBTSxRQUFRLElBQUksR0FBRztBQUN2QixlQUFXLEtBQUssTUFBTTtBQUNwQixVQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTTtBQUN6QyxZQUFNLE1BQU8sRUFBOEI7QUFJM0MsVUFBSSxPQUFPLFFBQVEsWUFBWSx3QkFBd0IsS0FBSyxHQUFHLEdBQUc7QUFDaEUsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQWtCTyxTQUFTLGNBQ2QsUUFDQSxVQUNrQjtBQUNsQixNQUFJLFNBQVMsU0FBUyxFQUFHLFFBQU87QUFLaEMsUUFBTSxnQkFBZ0Isb0JBQUksSUFBWTtBQUN0QyxRQUFNLG1CQUFtQixvQkFBSSxJQUFZO0FBQ3pDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxFQUFHO0FBQ25ELHFCQUFpQixJQUFJLEVBQUUsUUFBUTtBQUMvQixRQUFJLEVBQUUsZ0JBQWlCLGVBQWMsSUFBSSxFQUFFLGVBQWU7QUFDMUQsUUFBSSxFQUFFLG1CQUFvQixlQUFjLElBQUksRUFBRSxrQkFBa0I7QUFDaEUsUUFBSSxFQUFFLGtCQUFtQixlQUFjLElBQUksRUFBRSxpQkFBaUI7QUFBQSxFQUNoRTtBQUNBLFNBQU8sT0FBTyxPQUFPLENBQUMsTUFBTTtBQUMxQixVQUFNLElBQUksRUFBRSxlQUFlLFlBQVk7QUFDdkMsUUFBSSxTQUFTLElBQUksQ0FBQyxFQUFHLFFBQU87QUFFNUIsUUFBSSxjQUFjLElBQUksRUFBRSxRQUFRLEVBQUcsUUFBTztBQUUxQyxRQUFJLEVBQUUsbUJBQW1CLGlCQUFpQixJQUFJLEVBQUUsZUFBZSxFQUFHLFFBQU87QUFDekUsUUFBSSxFQUFFLHNCQUFzQixpQkFBaUIsSUFBSSxFQUFFLGtCQUFrQixFQUFHLFFBQU87QUFDL0UsUUFBSSxFQUFFLHFCQUFxQixpQkFBaUIsSUFBSSxFQUFFLGlCQUFpQixFQUFHLFFBQU87QUFFN0UsUUFBSSxFQUFFLG9CQUFvQixTQUFTLElBQUksRUFBRSxpQkFBaUIsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUNqRixlQUFXLEtBQUssRUFBRSxVQUFVO0FBQzFCLFVBQUksU0FBUyxJQUFJLEVBQUUsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUFBLElBQzVDO0FBQ0EsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNIO0FBU0EsU0FBUyxxQkFDUCxHQUNBLFFBQ0EsWUFDc0I7QUFDdEIsUUFBTSxRQUFRLElBQUksRUFBRSxlQUFlLEtBQUssSUFBSSxPQUFPLGVBQWU7QUFDbEUsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixRQUFNLFdBQVcsSUFBSSxNQUFNLFFBQVE7QUFDbkMsUUFBTSxPQUFPLElBQUksTUFBTSxJQUFJO0FBQzNCLFFBQU0sVUFBVSxVQUFVLFVBQVUsSUFBSTtBQUN4QyxRQUFNLFFBQVEsVUFBVSxNQUFNLEtBQUs7QUFDbkMsUUFBTSxhQUFhLFVBQVUsTUFBTSxVQUFVO0FBQzdDLFFBQU0saUJBQWlCLFVBQVUsTUFBTSxjQUFjO0FBQ3JELFFBQU0sU0FBUyxVQUFVLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPO0FBRWpFLE1BQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQVEsUUFBTztBQUMxQyxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVDtBQUFBLElBQ0EsYUFBYTtBQUFBLElBQ2I7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLElBQ2pCLGFBQWE7QUFBQSxFQUNmO0FBQ0Y7QUFPQSxTQUFTLG9CQUNQLFlBQ0EsYUFDQSxZQUNBLGVBQ2M7QUFDZCxRQUFNLGVBQWUsSUFBSSxZQUFZLFlBQVk7QUFDakQsU0FBTztBQUFBLElBQ0wsY0FDRSxVQUFVLGFBQWEsSUFBSSxLQUFLLFVBQVUsWUFBWSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUk7QUFBQSxJQUMzRixZQUNFLFVBQVUsZUFBZSxTQUFTLEtBQ2xDLFVBQVUsWUFBWSx1QkFBdUIsS0FDN0MsVUFBVSxZQUFZLHVCQUF1QjtBQUFBLElBQy9DLFVBQVUsV0FBVyxjQUFjLFFBQVEsS0FBSyxXQUFXLFlBQVksUUFBUTtBQUFBLElBQy9FLGtCQUFrQixXQUFXLFlBQVksZ0JBQWdCO0FBQUEsSUFDekQsZUFBZSxVQUFVLGNBQWMsYUFBYSxLQUFLLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDNUYsYUFBYSxVQUFVLFlBQVksV0FBVztBQUFBLElBQzlDLFVBQVUsVUFBVSxJQUFJLFlBQVksUUFBUSxHQUFHLFFBQVEsS0FBSyxVQUFVLFlBQVksUUFBUTtBQUFBLElBQzFGLEtBQUssVUFBVSxZQUFZLEdBQUc7QUFBQSxJQUM5QixpQkFBaUIsVUFBVSxZQUFZLGVBQWU7QUFBQSxJQUN0RCxlQUFlLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDbEQsZ0JBQWdCLFVBQVUsWUFBWSxjQUFjO0FBQUEsSUFDcEQsb0JBQ0UsaUJBQWlCLFVBQVUsYUFBYSxVQUFVLENBQUMsS0FDbkQsaUJBQWlCLFVBQVUsWUFBWSxVQUFVLENBQUM7QUFBQSxJQUNwRCxXQUFXLFdBQVcsWUFBWSxTQUFTO0FBQUEsRUFDN0M7QUFDRjtBQU9BLFNBQVMsWUFBWSxHQUE4QztBQUNqRSxRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksTUFBTSxNQUFNO0FBQ25DLE1BQUksQ0FBQyxXQUFZLFFBQU87QUFDeEIsUUFBTSxXQUFXLFdBQVc7QUFDNUIsUUFBTSxRQUFpQyxDQUFDO0FBQ3hDLE1BQUksTUFBTSxRQUFRLFFBQVEsR0FBRztBQUMzQixlQUFXLE1BQU0sVUFBVTtBQUN6QixVQUFJLE9BQU8sT0FBTyxZQUFZLE9BQU8sS0FBTTtBQUMzQyxZQUFNLElBQUk7QUFDVixZQUFNLElBQUksVUFBVSxFQUFFLEdBQUc7QUFDekIsWUFBTSxJQUFJLElBQUksRUFBRSxLQUFLO0FBQ3JCLFVBQUksQ0FBQyxLQUFLLENBQUMsRUFBRztBQUNkLFlBQU0sQ0FBQyxJQUNMLFVBQVUsRUFBRSxZQUFZLEtBQ3hCLFVBQVUsSUFBSSxFQUFFLFdBQVcsR0FBRyxHQUFHLEtBQ2pDLFVBQVUsSUFBSSxFQUFFLGlCQUFpQixHQUFHLE9BQU87QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sVUFBVSxXQUFXLElBQUk7QUFDdEMsUUFBTSxVQUFVLFVBQVUsV0FBVyxHQUFHO0FBQ3hDLFFBQU0sWUFDSixPQUFPLE1BQU0sWUFBWSxNQUFNLFdBQVksTUFBTSxZQUFZLElBQWU7QUFDOUUsUUFBTSxRQUFRLE9BQU8sTUFBTSxPQUFPLE1BQU0sV0FBWSxNQUFNLE9BQU8sSUFBZTtBQUNoRixRQUFNLGNBQ0osT0FBTyxNQUFNLGFBQWEsTUFBTSxXQUFZLE1BQU0sYUFBYSxJQUFlO0FBQ2hGLFFBQU0sWUFDSCxPQUFPLE1BQU0sZ0NBQWdDLE1BQU0sV0FDL0MsTUFBTSxnQ0FBZ0MsSUFDdkMsVUFDSCxPQUFPLE1BQU0sMEJBQTBCLE1BQU0sV0FDekMsTUFBTSwwQkFBMEIsSUFDakMsVUFDSCxPQUFPLE1BQU0sOEJBQThCLE1BQU0sV0FDN0MsTUFBTSw4QkFBOEIsSUFDckM7QUFDTixNQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsU0FBVSxRQUFPO0FBQ3pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiO0FBQ0Y7OztBQ2h0QkEsSUFBTSxXQUFXO0FBRVYsU0FBUyxXQUFtQjtBQUNqQyxRQUFNLEtBQUssS0FBSyxJQUFJO0FBQ3BCLE1BQUksU0FBUztBQUNiLE1BQUksSUFBSTtBQUNSLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLGNBQVUsU0FBUyxJQUFJLEVBQUUsS0FBSyxPQUFPO0FBQ3JDLFFBQUksS0FBSyxNQUFNLElBQUksRUFBRTtBQUFBLEVBQ3ZCO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLEtBQU0sYUFBWSxTQUFTLElBQUksRUFBRSxLQUFLO0FBQ3RELFNBQU8sU0FBUztBQUNsQjtBQUVPLFNBQVMsV0FBVyxJQUFvQjtBQUM3QyxTQUFPLEdBQUcsTUFBTSxFQUFFO0FBQ3BCOzs7QUNQQSxJQUFNLG1CQUFpRCxvQkFBSSxJQUFJO0FBQUEsRUFDN0Q7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVNLFNBQVMsa0JBQWtCLE1BQStCO0FBQy9ELFFBQU0sV0FBNEIsQ0FBQztBQUNuQyxNQUFJLFVBQWtDLENBQUM7QUFDdkMsTUFBSSxhQUFhO0FBQ2pCLFFBQU0sUUFBUSxNQUFNO0FBQ2xCLFFBQUksUUFBUSxVQUFVLFFBQVEsT0FBTztBQUNuQyxVQUFJLENBQUMsUUFBUSxTQUFVLFNBQVEsV0FBVztBQUMxQyxlQUFTLEtBQUssT0FBd0I7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFDQSxhQUFXLFdBQVcsS0FBSyxNQUFNLElBQUksR0FBRztBQUN0QyxVQUFNLE9BQU8sY0FBYyxPQUFPO0FBQ2xDLFFBQUksS0FBSyxLQUFLLE1BQU0sR0FBSTtBQUN4QixRQUFJLGdCQUFnQixLQUFLLElBQUksR0FBRztBQUM5QixtQkFBYTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxXQUFZO0FBRWpCLFVBQU0sWUFBWSxLQUFLLE1BQU0sNEJBQTRCO0FBQ3pELFFBQUksV0FBVztBQUNiLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxVQUFVLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDaEQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx3QkFBd0I7QUFDdEQsUUFBSSxjQUFjLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUNyQyxZQUFNO0FBQ04sZ0JBQVUsRUFBRSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2pEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sdUJBQXVCO0FBQ3JELFFBQUksY0FBYyxRQUFRLFFBQVE7QUFDaEMsY0FBUSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRTtBQUMzQztBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixLQUFLLE1BQU0sMEJBQTBCO0FBQzNELFFBQUksaUJBQWlCLFFBQVEsUUFBUTtBQUNuQyxZQUFNLE1BQU0sUUFBUSxjQUFjLENBQUMsS0FBSyxFQUFFO0FBQzFDLGNBQVEsV0FBVyxpQkFBaUIsSUFBSSxHQUFzQixJQUN6RCxNQUNEO0FBQ0o7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU07QUFDTixTQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUNuRDtBQUVBLFNBQVMsY0FBYyxNQUFzQjtBQUczQyxRQUFNLE1BQU0sS0FBSyxRQUFRLEdBQUc7QUFDNUIsU0FBTyxRQUFRLEtBQUssT0FBTyxLQUFLLE1BQU0sR0FBRyxHQUFHO0FBQzlDO0FBRUEsU0FBUyxRQUFRLEdBQW1CO0FBQ2xDLFFBQU0sVUFBVSxFQUFFLEtBQUs7QUFDdkIsTUFDRyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQy9DLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsR0FDaEQ7QUFDQSxXQUFPLFFBQVEsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUM1QjtBQUNBLFNBQU87QUFDVDs7O0FDTkEsSUFBTSxjQUFjLFFBQVEsUUFBUSxZQUFZLEVBQUU7QUFFbEQsZUFBZSxDQUFDLE9BQWlCO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxhQUFhLE9BQU8sR0FBRyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFLENBQUM7QUFJRCxRQUFRLFFBQVEsWUFBWSxZQUFZLFlBQVk7QUFDbEQsUUFBTSxLQUFLLHVCQUF1QixFQUFFLFNBQVMsWUFBWSxDQUFDO0FBQzFELFFBQU0sT0FBTyxTQUFTO0FBQ3hCLENBQUM7QUFFRCxRQUFRLFFBQVEsVUFBVSxZQUFZLE1BQU07QUFDMUMsT0FBSyxPQUFPLFNBQVM7QUFDdkIsQ0FBQztBQUdELEtBQUssT0FBTyxhQUFhO0FBRXpCLGVBQWUsT0FBTyxRQUErQjtBQUNuRCxNQUFJO0FBQ0YsVUFBTSxhQUFhO0FBQ25CLFVBQU0sc0JBQXNCO0FBQzVCLFVBQU0sNEJBQTRCO0FBQ2xDLFVBQU0scUJBQXFCO0FBRzNCLFVBQU0sU0FBUyxNQUFNLG9CQUFvQixLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUk7QUFDakUsUUFBSSxTQUFTLEVBQUcsT0FBTSxLQUFLLDBCQUEwQixFQUFFLE9BQU8sQ0FBQztBQUMvRCxVQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQUksU0FBUyxPQUFPLFNBQVMsU0FBUyxTQUFTLE1BQU07QUFDbkQsWUFBTSxpQkFBaUIsS0FBSztBQUM1QixZQUFNLG9CQUFvQixLQUFLO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU87QUFBQSxRQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlO0FBQUEsUUFDZix3QkFBd0I7QUFBQSxRQUN4QixrQkFBa0I7QUFBQSxNQUNwQixDQUFDO0FBQ0QsWUFBTSxLQUFLLHdDQUF3QyxFQUFFLE9BQU8sQ0FBQztBQUFBLElBQy9EO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixVQUFNLE1BQU8sZUFBZSxFQUFFLFFBQVEsR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDL0Q7QUFDRjtBQVlBLGVBQWUsdUJBQXNDO0FBQ25ELE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsRUFDdkYsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDZCQUE2QixjQUFjLEdBQUcsQ0FBQztBQUMxRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJO0FBQ0YsWUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJdEIsT0FBTztBQUFBLE1BQ1QsQ0FBQztBQUNELFlBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLE1BQ3RCLENBQUM7QUFDRCxZQUFNLEtBQUsscUNBQXFDO0FBQUEsUUFDOUMsT0FBTyxJQUFJO0FBQUEsUUFDWCxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUU7QUFBQSxNQUMvQixDQUFDO0FBQUEsSUFDSCxTQUFTLEtBQUs7QUFJWixZQUFNLEtBQUssd0NBQXdDO0FBQUEsUUFDakQsT0FBTyxJQUFJO0FBQUEsUUFDWCxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUU7QUFBQSxRQUM3QixHQUFHLGNBQWMsR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxRQUFNLFFBQVEsT0FBTyxNQUFNLGFBQWE7QUFDeEMsUUFBTSxRQUFRLE9BQU8sTUFBTSxtQkFBbUI7QUFDOUMsUUFBTSxRQUFRLE9BQU8sT0FBTyxlQUFlLEVBQUUsaUJBQWlCLG9CQUFvQixDQUFDO0FBQ25GLFFBQU0sUUFBUSxPQUFPLE9BQU8scUJBQXFCO0FBQUEsSUFDL0MsaUJBQWlCLGdDQUFnQztBQUFBLEVBQ25ELENBQUM7QUFDSDtBQU1BLElBQUksa0JBQXlEO0FBSzdELElBQU0saUJBQWlCO0FBRXZCLGVBQWUsd0JBQXVDO0FBRXBELFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLE1BQUksU0FBUyxRQUFRLEVBQUUsWUFBWSxPQUFPO0FBQ3hDLHVCQUFtQixFQUFFLHFCQUFxQjtBQUFBLEVBQzVDLE9BQU87QUFDTCx5QkFBcUI7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyx1QkFBNkI7QUFDcEMsTUFBSSxvQkFBb0IsTUFBTTtBQUM1QixrQkFBYyxlQUFlO0FBQzdCLHNCQUFrQjtBQUFBLEVBQ3BCO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixhQUEyQjtBQUNyRCx1QkFBcUI7QUFDckIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sV0FBVyxDQUFDO0FBQUEsRUFDdkQ7QUFDQSxvQkFBa0IsWUFBWSxNQUFNO0FBQ2xDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsYUFBYTtBQUFBLElBQ2IsZUFBZTtBQUFBLElBQ2YsZUFBZTtBQUFBLEVBQ2pCLENBQUM7QUFDRCxxQkFBbUIsRUFBRSxxQkFBcUI7QUFDMUMsUUFBTSxLQUFLLDRCQUE0QixFQUFFLGNBQWMsRUFBRSxzQkFBc0IsQ0FBQztBQUVoRixPQUFLLGVBQWU7QUFDcEIsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQsdUJBQXFCO0FBQ3JCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLE1BQU0sZUFBZTtBQUFBLElBQzlCLFVBQVUsTUFBTSxpQkFBaUI7QUFBQSxJQUNqQyxVQUFVLE1BQU0saUJBQWlCO0FBQUEsRUFDbkMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsaUJBQWdDO0FBQzdDLE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsRUFDdkYsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlDQUFpQyxjQUFjLEdBQUcsQ0FBQztBQUM5RDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLE1BQUksY0FBYztBQUNsQixNQUFJLGdCQUFnQjtBQUNwQixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVU7QUFDaEMsUUFBSSxJQUFJLFVBQVc7QUFDbkIsUUFBSTtBQUNGLFlBQU0sVUFBVyxNQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDckQsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSVAsTUFBTyxNQUFNO0FBS1gsZ0JBQU0sc0JBQXNCO0FBQUEsWUFDMUI7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFDQSxnQkFBTSxVQUFVLG9CQUFJLElBQWE7QUFDakMsY0FBSSxXQUFXO0FBQ2YscUJBQVcsT0FBTyxxQkFBcUI7QUFDckMsdUJBQVcsTUFBTSxNQUFNLEtBQUssU0FBUyxpQkFBaUIsR0FBRyxDQUFDLEdBQUc7QUFDM0Qsa0JBQUksUUFBUSxJQUFJLEVBQUUsRUFBRztBQUVyQixvQkFBTSxLQUFLLEdBQUcsZUFBZSxJQUFJLEtBQUssRUFBRSxZQUFZO0FBQ3BELGtCQUFJLE1BQU0sZUFBZSxNQUFNLG1CQUFvQjtBQUNuRCxvQkFBTSxPQUFPLEdBQUcsc0JBQXNCO0FBQ3RDLGtCQUFJLEtBQUssVUFBVSxLQUFLLEtBQUssV0FBVyxFQUFHO0FBQzNDLHNCQUFRLElBQUksRUFBRTtBQUNkLGtCQUFJO0FBQ0YsZ0JBQUMsR0FBbUIsTUFBTTtBQUMxQiw0QkFBWTtBQUFBLGNBQ2QsUUFBUTtBQUFBLGNBRVI7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUlBLGdCQUFNLE9BQTBCO0FBQUEsWUFDOUIsS0FBSztBQUFBLFlBQ0wsTUFBTTtBQUFBLFlBQ04sU0FBUztBQUFBLFlBQ1QsT0FBTztBQUFBLFlBQ1AsU0FBUztBQUFBLFlBQ1QsWUFBWTtBQUFBLFVBQ2Q7QUFDQSxnQkFBTSxRQUFTLFNBQVMsaUJBQXdDLFNBQVM7QUFDekUsZ0JBQU0sY0FBYyxJQUFJLGNBQWMsV0FBVyxJQUFJLENBQUM7QUFDdEQsZ0JBQU0sY0FBYyxJQUFJLGNBQWMsU0FBUyxJQUFJLENBQUM7QUFDcEQsaUJBQU8sU0FBUztBQUFBLFlBQ2QsS0FBSyxTQUFTLGdCQUFnQjtBQUFBLFlBQzlCLFVBQVU7QUFBQSxVQUNaLENBQUM7QUFDRCxpQkFBTyxFQUFFLFNBQVM7QUFBQSxRQUNwQjtBQUFBLE1BQ0YsQ0FBQztBQUNELHFCQUFlO0FBQ2YsWUFBTSxJQUFJLFFBQVEsQ0FBQyxHQUFHO0FBQ3RCLFVBQUksS0FBSyxPQUFPLEVBQUUsYUFBYSxTQUFVLGtCQUFpQixFQUFFO0FBQUEsSUFDOUQsUUFBUTtBQUFBLElBR1I7QUFBQSxFQUNGO0FBQ0EsTUFBSSxjQUFjLEdBQUc7QUFDbkIsVUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQUksU0FBUyxNQUFNO0FBQ2pCLFdBQUssZUFBZTtBQUNwQixXQUFLLGlCQUFpQjtBQUN0QixZQUFNLHFCQUFxQixJQUFJO0FBQUEsSUFFakM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxRQUFRLE9BQU8sUUFBUSxZQUFZLENBQUMsVUFBVTtBQUM1QyxNQUFJLE1BQU0sU0FBUyxlQUFlO0FBQ2hDLFNBQUssaUJBQWlCO0FBQUEsRUFDeEIsV0FBVyxNQUFNLFNBQVMscUJBQXFCO0FBQzdDLFNBQUssaUJBQWlCLEtBQUs7QUFBQSxFQUM3QjtBQUlGLENBQUM7QUFJRCxJQUFJLFFBQVEsUUFBUSxXQUFXO0FBQzdCLFVBQVEsT0FBTyxVQUFVLFlBQVksWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTSxRQUFRLGNBQWMsT0FBTztBQUFBLElBQ3JDLFNBQVMsS0FBSztBQUVaLFlBQU0sS0FBSywwQ0FBMEMsY0FBYyxHQUFHLENBQUM7QUFDdkUsWUFBTSxRQUFRLFFBQVEsZ0JBQWdCO0FBQUEsSUFDeEM7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUlBLFFBQVEsUUFBUSxVQUFVLFlBQVksQ0FBQyxLQUFjLFlBQVk7QUFDL0QsTUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUcsUUFBTztBQUNuQyxTQUFPLGNBQWMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ3ZDLFNBQUssTUFBTywwQkFBMEIsRUFBRSxNQUFNLElBQUksTUFBTSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDL0UsVUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNILENBQUM7QUFFRCxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxTQUFPLENBQUMsQ0FBQyxLQUFLLE9BQU8sTUFBTSxZQUFZLE9BQVEsRUFBeUIsU0FBUztBQUNuRjtBQUlBLElBQU0sNEJBQTRCLG9CQUFJLElBQTRCO0FBQUEsRUFDaEU7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFFRCxlQUFlLFlBQThCO0FBQzNDLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsU0FBTyxFQUFFLFlBQVk7QUFDdkI7QUFFQSxlQUFlLGNBQWMsS0FBdUM7QUFLbEUsTUFBSSxDQUFFLE1BQU0sVUFBVSxLQUFNLDBCQUEwQixJQUFJLElBQUksSUFBSSxHQUFHO0FBQ25FLFdBQU8sRUFBRSxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUEsRUFDbEM7QUFDQSxVQUFRLElBQUksTUFBTTtBQUFBLElBQ2hCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJLFVBQVUsSUFBSSxLQUFLLElBQUksV0FBVyxNQUFNLElBQUksUUFBUTtBQUMvRSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN2RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN0RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFVBQUksSUFBSSxVQUFVLFFBQVE7QUFDeEIsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQsV0FBVyxJQUFJLFVBQVUsU0FBUztBQUNoQyxjQUFNLE1BQU8sSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNwRCxPQUFPO0FBQ0wsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQ7QUFDQSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFdBQVcsSUFBSSxNQUFNO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFdBQVc7QUFDakIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZ0JBQWdCO0FBQ3RCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFNBQVMsTUFBTTtBQUNyQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxZQUFZLElBQUksUUFBUSxNQUFNO0FBQ3BDLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGVBQWUsRUFBRSxhQUFhLElBQUksR0FBRyxDQUFDO0FBQzVDLFlBQU0sS0FBSyx3QkFBd0IsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQ2pELGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssa0JBQWtCO0FBQ3JCLFlBQU0sSUFBSSxNQUFNLGVBQWUsRUFBRSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2xELFVBQUksQ0FBQyxJQUFJLElBQUk7QUFHWCw2QkFBcUI7QUFDckIsNEJBQW9CO0FBQ3BCLCtCQUF1QjtBQUN2QixjQUFNLFFBQVEsT0FBTyxNQUFNLGNBQWM7QUFDekMsY0FBTSxRQUFRLE9BQU8sTUFBTSxrQkFBa0I7QUFBQSxNQUMvQyxPQUFPO0FBRUwsY0FBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFlBQUksU0FBUyxLQUFNLG9CQUFtQixFQUFFLHFCQUFxQjtBQUFBLE1BQy9EO0FBQ0EsWUFBTSxLQUFLLG1DQUFtQyxFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDNUQsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQjtBQUMxQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxxQkFBcUI7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSyw0QkFBNEI7QUFDL0IsWUFBTSxVQUFVLEtBQUs7QUFBQSxRQUNuQjtBQUFBLFFBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sSUFBSSxPQUFPLENBQUM7QUFBQSxNQUN2RDtBQUNBLFlBQU0sZUFBZSxFQUFFLHVCQUF1QixRQUFRLENBQUM7QUFFdkQsWUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFVBQUksU0FBUyxLQUFNLG9CQUFtQixPQUFPO0FBQzdDLFVBQUksMEJBQTBCLEtBQU0sc0JBQXFCLE9BQU87QUFDaEUsVUFBSSw2QkFBNkIsS0FBTSx5QkFBd0IsT0FBTztBQUN0RSxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0saUJBQWlCO0FBQ3ZCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGtCQUFrQjtBQUN4QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssbUJBQW1CO0FBQ3RCLFlBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsWUFBTSxVQUFVLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUMvRCxZQUFNLFVBQVUsTUFBTSxvQkFBb0IsT0FBTztBQUNqRCxZQUFNLEtBQUssMEJBQTBCLE9BQU87QUFDNUMsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQixJQUFJO0FBQzlCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGNBQWM7QUFDcEIsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFDdEMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssZUFBZTtBQUNsQixZQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFlBQU0sTUFBTSxVQUFVLENBQUM7QUFDdkIsWUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLElBQUksQ0FBQztBQUNqQyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQ0UsYUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLHVCQUF1QjtBQUFBLEVBQ3REO0FBQ0Y7QUFJQSxlQUFlLGlCQUNiLFVBQ0EsS0FDQSxTQUNBLFVBQ2U7QUFDZixNQUFJLGtCQUFrQixJQUFJLFFBQVEsRUFBRztBQUNyQyxNQUFJLENBQUMsZ0JBQWdCLElBQUksUUFBUSxFQUFHO0FBRXBDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFnQm5DLFFBQU0sVUFBVSxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDbkUsUUFBTSxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBRTFDLE1BQUk7QUFDSixNQUFJO0FBQ0YsaUJBQWEsVUFBVSxVQUFVO0FBQUEsTUFDL0I7QUFBQSxNQUNBLE9BQU87QUFBQSxNQUNQO0FBQUEsTUFDQSxnQkFBZ0Isb0JBQUksSUFBWTtBQUFBLE1BQ2hDLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sV0FBVyxtQkFBbUIsVUFBVSxLQUFLLFVBQVUsR0FBRztBQUNoRTtBQUFBLEVBQ0Y7QUFRQSxRQUFNLGVBQWUsV0FBVyxPQUFPO0FBQ3ZDLGFBQVcsU0FBUyxjQUFjLFdBQVcsUUFBUSxPQUFPO0FBQzVELFFBQU0sbUJBQW1CLGVBQWUsV0FBVyxPQUFPO0FBQzFELE1BQUksbUJBQW1CLEdBQUc7QUFDeEIsVUFBTSxLQUFLLDRCQUE0QjtBQUFBLE1BQ3JDO0FBQUEsTUFDQSxTQUFTO0FBQUEsTUFDVCxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBT0EsTUFBSSxXQUFXLGFBQWEsV0FBVyxHQUFHO0FBQ3hDLFVBQU0sS0FBSyw0Q0FBdUM7QUFBQSxNQUNoRDtBQUFBLE1BQ0EsV0FBVyxlQUFlLFFBQVEsRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLE1BQy9DLFlBQVksb0JBQW9CLFVBQVUsT0FBTztBQUFBLE1BQ2pELGlCQUFpQixpQkFBaUIsVUFBVSxTQUFTLENBQUMsTUFBTSxDQUFDO0FBQUEsTUFDN0QsbUJBQW1CLGlCQUFpQixVQUFVLFNBQVMsQ0FBQyxRQUFRLENBQUM7QUFBQSxNQUNqRSwwQkFBMEIsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQzVEO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxNQUNELCtCQUErQixpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDakU7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxNQUNELGlDQUFpQyxpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDbkU7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNILE9BQU87QUFDTCxVQUFNLEtBQUssd0JBQXdCO0FBQUEsTUFDakM7QUFBQSxNQUNBLFVBQVUsV0FBVyxhQUFhO0FBQUEsTUFDbEMsTUFBTSxXQUFXLE9BQU87QUFBQSxJQUMxQixDQUFDO0FBQUEsRUFDSDtBQUVBLE1BQUksV0FBVyxPQUFPLFdBQVcsRUFBRztBQVdwQyxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsYUFBVyxLQUFLLFdBQVcsUUFBUTtBQUNqQyxRQUFJLEVBQUUsY0FBYztBQUNsQixZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRO0FBQUEsSUFDbkQsT0FBTztBQUNMLFlBQU0sZUFBZSxFQUFFLGdCQUFnQixFQUFFLFFBQVE7QUFBQSxJQUNuRDtBQUdBLFVBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxRQUFJLGFBQWEsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNqRCxrQkFBWSxXQUFXO0FBQ3ZCLGtCQUFZLGFBQWE7QUFDekIsWUFBTSxrQkFBa0IsV0FBVztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUtBLGFBQVcsV0FBVyxXQUFXLGFBQWE7QUFDNUMsUUFBSSxNQUFNLFlBQVksUUFBUSxRQUFRLEVBQUc7QUFDekMsVUFBTSxrQkFBa0IsUUFBUSxhQUFhLFFBQVEsUUFBUTtBQUFBLEVBQy9EO0FBQ0EsTUFBSSxXQUFXLFlBQVksU0FBUyxHQUFHO0FBQ3JDLFVBQU0sS0FBSywwQ0FBMEM7QUFBQSxNQUNuRDtBQUFBLE1BQ0EsU0FBUyxXQUFXLFlBQVk7QUFBQSxNQUNoQyxhQUFhLE1BQU0scUJBQXFCO0FBQUEsSUFDMUMsQ0FBQztBQUFBLEVBQ0g7QUFRQSxRQUFNLGVBQWUsTUFBTSxrQkFBa0I7QUFDN0MsTUFBSSxpQkFBaUI7QUFDckIsUUFBTSxhQUF1QyxDQUFDO0FBQzlDLGFBQVcsS0FBSyxXQUFXLFFBQVE7QUFDakMsVUFBTSxPQUFPLGFBQWEsRUFBRSxjQUFjLElBQUksRUFBRSxRQUFRO0FBQ3hELFVBQU0sTUFBTTtBQUFBLE1BQ1YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0o7QUFDQSxRQUFJLFFBQVEsS0FBSyxRQUFRLEtBQUs7QUFDNUIsd0JBQWtCO0FBQ2xCO0FBQUEsSUFDRjtBQUNBLGVBQVcsS0FBSyxDQUFDO0FBQUEsRUFDbkI7QUFDQSxNQUFJLGlCQUFpQixHQUFHO0FBQ3RCLFVBQU0sS0FBSyxtQ0FBbUM7QUFBQSxNQUM1QztBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsV0FBVyxXQUFXO0FBQUEsSUFDeEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxNQUFJLFdBQVcsV0FBVyxFQUFHO0FBRzdCLFFBQU0sV0FBVyxvQkFBSSxJQUE4QjtBQUNuRCxhQUFXLEtBQUssWUFBWTtBQUMxQixVQUFNLE1BQU0sU0FBUyxJQUFJLEVBQUUsY0FBYyxLQUFLLENBQUM7QUFDL0MsUUFBSSxLQUFLLENBQUM7QUFDVixhQUFTLElBQUksRUFBRSxnQkFBZ0IsR0FBRztBQUFBLEVBQ3BDO0FBRUEsYUFBVyxDQUFDLFFBQVEsTUFBTSxLQUFLLFVBQVU7QUFDdkMsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxLQUFLLFFBQVE7QUFDbkUsUUFBSSxRQUFRO0FBQ1osZUFBVyxLQUFLLFFBQVE7QUFDdEIsWUFBTSxXQUFXLElBQUksYUFBYSxFQUFFLFFBQVE7QUFDNUMsVUFBSSxVQUFVO0FBR1osaUJBQVMsZUFBZTtBQUN4QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsZ0JBQWdCLEVBQUU7QUFDM0IsaUJBQVMsY0FBYyxFQUFFO0FBQ3pCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsaUJBQWlCLEVBQUU7QUFDNUIsY0FBTSxPQUFPLFNBQVMsbUJBQW1CLFNBQVMsbUJBQW1CLFNBQVMsQ0FBQztBQUMvRSxjQUFNLE9BQU8sRUFBRSxtQkFBbUIsQ0FBQztBQUNuQyxZQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssZ0JBQWdCLEtBQUssY0FBYztBQUM1RCxtQkFBUyxtQkFBbUIsS0FBSyxJQUFJO0FBQUEsUUFDdkM7QUFBQSxNQUNGLE9BQU87QUFDTCxjQUFNLFVBQTBCLEVBQUUsR0FBRyxHQUFHLGdCQUFnQixJQUFJLE9BQU87QUFDbkUsWUFBSSxhQUFhLEVBQUUsUUFBUSxJQUFJO0FBQy9CLGlCQUFTO0FBQUEsTUFDWDtBQUNBLFVBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQ2hELFlBQUksbUJBQW1CLEtBQUssRUFBRSxRQUFRO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTSxpQkFBaUIsUUFBUSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsTUFBTTtBQUNuRSxRQUFJLFFBQVEsR0FBRztBQUNiLFlBQU0sS0FBSyxtQkFBbUI7QUFBQSxRQUM1QjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxPQUFPLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRTtBQUFBLE1BQ3ZDLENBQUM7QUFHRCxZQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsVUFBSSxXQUFXLE1BQU07QUFDbkIsZUFBTyxpQkFBaUI7QUFDeEIsY0FBTSxxQkFBcUIsTUFBTTtBQUFBLE1BQ25DO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFVBQVUsdUJBQXVCO0FBQ2pFLFlBQU0sWUFBWSxRQUFRLFdBQVc7QUFBQSxJQUN2QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGdCQUNiLFFBQ0EsSUFDQSxXQUNBLFVBQ29CO0FBQ3BCLFFBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUNyQyxNQUFJLElBQUssUUFBTztBQUNoQixRQUFNLE1BQWlCO0FBQUEsSUFDckIsUUFBUSxTQUFTO0FBQUEsSUFDakIsZ0JBQWdCO0FBQUEsSUFDaEIsWUFBWTtBQUFBLElBQ1osaUJBQWlCO0FBQUEsSUFDakIsY0FBYyxDQUFDO0FBQUEsSUFDZixvQkFBb0IsQ0FBQztBQUFBLElBQ3JCLGdCQUFnQixDQUFDLFFBQVE7QUFBQSxJQUN6QixZQUFZO0FBQUEsRUFDZDtBQUNBLFFBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsUUFBTSxLQUFLLGVBQWUsRUFBRSxRQUFRLEtBQUssV0FBVyxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQ2pFLFNBQU87QUFDVDtBQUlBLElBQUksYUFBNEIsUUFBUSxRQUFRO0FBY2hELGVBQWUsbUJBQWtDO0FBQy9DLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxNQUFNLEtBQUssSUFBSTtBQUNyQixRQUFNLFVBQW9CLENBQUM7QUFDM0IsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELGNBQVEsS0FBSyxNQUFNO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxhQUFhLFNBQVMsTUFBTTtBQUNwQztBQUVBLGVBQWUsOEJBQTZDO0FBTzFELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsUUFBTSxVQUFvQixDQUFDO0FBQzNCLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFVBQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxlQUFlO0FBQzNDLFFBQUksT0FBTyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsZUFBZTtBQUN4RCxjQUFRLEtBQUssTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sYUFBYSxTQUFTLE1BQU07QUFDcEM7QUFFQSxlQUFlLFNBQVMsUUFBK0I7QUFDckQsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLGFBQWEsT0FBTyxLQUFLLEdBQUcsR0FBRyxNQUFNO0FBQzdDO0FBRUEsZUFBZSxZQUFZLFFBQWdCLFFBQStCO0FBQ3hFLFFBQU0sYUFBYSxDQUFDLE1BQU0sR0FBRyxNQUFNO0FBQ3JDO0FBRUEsZUFBZSxhQUFhLFNBQW1CLFFBQStCO0FBQzVFLFFBQU0sU0FBUyxDQUFDLEdBQUcsSUFBSSxJQUFJLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDO0FBQy9ELE1BQUksT0FBTyxXQUFXLEVBQUc7QUFDekIsUUFBTSxNQUFNLFdBQVcsS0FBSyxNQUFNLG1CQUFtQixRQUFRLE1BQU0sQ0FBQztBQUNwRSxlQUFhLElBQUksTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQy9CLFNBQU87QUFDVDtBQUVBLGVBQWUsbUJBQW1CLFNBQW1CLFFBQStCO0FBQ2xGLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxRQUFxQixDQUFDO0FBQzVCLGFBQVcsVUFBVSxTQUFTO0FBQzVCLFVBQU0sTUFBTSxJQUFJLE1BQU07QUFDdEIsUUFBSSxDQUFDLElBQUs7QUFDVixVQUFNLFNBQVMsT0FBTyxPQUFPLElBQUksWUFBWTtBQUM3QyxRQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFlBQU0sZUFBZSxNQUFNO0FBQzNCLFlBQU0saUJBQWlCLFFBQVEsQ0FBQztBQUNoQztBQUFBLElBQ0Y7QUFDQSxVQUFNLEtBQUssZUFBZSxRQUFRLEtBQUssTUFBTSxDQUFDO0FBQUEsRUFDaEQ7QUFDQSxNQUFJLE1BQU0sV0FBVyxFQUFHO0FBRXhCLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsTUFBTTtBQUN0RCxVQUFNLEtBQUssdUNBQXVDO0FBQUEsTUFDaEQsT0FBTyxNQUFNO0FBQUEsTUFDYixTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxJQUN2RCxDQUFDO0FBQ0Q7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFFBQU0sUUFBUSxNQUFNLFFBQVEsQ0FBQyxTQUFTO0FBQUEsSUFDcEM7QUFBQSxNQUNFLE1BQU0sS0FBSztBQUFBLE1BQ1gsZUFBZUMsVUFBUyxLQUFLLFVBQVUsS0FBSyxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxJQUN0RTtBQUFBLElBQ0E7QUFBQSxNQUNFLE1BQU0sS0FBSztBQUFBLE1BQ1gsZUFBZUEsVUFBUyxLQUFLLFVBQVUsS0FBSyxNQUFNLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxJQUNuRTtBQUFBLEVBQ0YsQ0FBQztBQUNELFFBQU0sWUFBWSx3QkFBd0IsS0FBSztBQUUvQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLE1BQU0sT0FBTyxZQUFZO0FBQUEsTUFDdEM7QUFBQSxNQUNBLFNBQVM7QUFBQSxJQUNYLENBQUM7QUFDRCxVQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsZUFBVyxRQUFRLE9BQU87QUFDeEIsWUFBTSxpQkFBaUIsTUFBTSwrQkFBK0IsSUFBSTtBQUtoRSxZQUFNLFFBQVEsTUFBTSxZQUFZLEdBQUcsS0FBSyxNQUFNO0FBQzlDLFlBQU0sU0FBUSxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQ2xELFlBQU0sZUFBZSxRQUFRLEtBQUssY0FBYyxRQUFRLEtBQUssYUFBYTtBQUMxRSxZQUFNLFlBQVksS0FBSyxRQUFRO0FBQUEsUUFDN0IsWUFBWSxlQUFlLEtBQUssT0FBTztBQUFBLFFBQ3ZDLFdBQVc7QUFBQSxRQUNYLGVBQWUsS0FBSyxJQUFJO0FBQUEsUUFDeEIsaUJBQWlCLE1BQU0sa0JBQWtCLEtBQUssS0FBSyxPQUFPO0FBQUEsUUFDMUQsZUFBZTtBQUFBLE1BQ2pCLENBQUM7QUFHRCxZQUFNLFFBQVEsSUFBSSxLQUFLLE1BQU0sS0FBSyxDQUFDO0FBQ25DLFlBQU0sVUFBUyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUN0QyxpQkFBVyxLQUFLLEtBQUssUUFBUTtBQUMzQixjQUFNLEVBQUUsUUFBUSxJQUFJO0FBQUEsVUFDbEIsSUFBSTtBQUFBLFVBQ0osS0FBSztBQUFBLFlBQ0gsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFVBQ0o7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFVBQUksS0FBSyxNQUFNLElBQUk7QUFDbkIsWUFBTSxLQUFLLG1CQUFtQjtBQUFBLFFBQzVCLFFBQVEsS0FBSztBQUFBLFFBQ2I7QUFBQSxRQUNBLFFBQVEsS0FBSyxPQUFPO0FBQUEsUUFDcEIsS0FBSyxLQUFLO0FBQUEsUUFDVixNQUFNLEtBQUs7QUFBQSxRQUNYLGNBQWMsT0FBTztBQUFBLE1BQ3ZCLENBQUM7QUFBQSxJQUNIO0FBQ0EsVUFBTSxrQkFBa0IsR0FBRztBQUMzQixVQUFNLEtBQUsseUJBQXlCO0FBQUEsTUFDbEM7QUFBQSxNQUNBLE1BQU0sTUFBTTtBQUFBLE1BQ1osT0FBTyxNQUFNO0FBQUEsTUFDYixRQUFRLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssT0FBTyxRQUFRLENBQUM7QUFBQSxNQUNuRSxRQUFRLE9BQU87QUFBQSxJQUNqQixDQUFDO0FBQ0Q7QUFDRSxZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU8sS0FBSztBQUFBLFFBQ1osWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWUsS0FBSztBQUFBLFFBQ3BCLHdCQUF3QixLQUFLO0FBQUEsUUFDN0Isa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFFBQUksZUFBZSxhQUFhO0FBQzlCLFlBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsWUFBTSxTQUNKLElBQUksYUFBYSxTQUNiLGVBQ0EsSUFBSSxhQUFhLGVBQ2YsaUJBQ0EsSUFBSSxhQUFhLFlBQ2Ysa0JBQ0EsS0FBSztBQUNmLFlBQU0sY0FBYztBQUFBLFFBQ2xCO0FBQUEsUUFDQSxPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPLElBQUk7QUFBQSxRQUNYLGVBQWUsS0FBSztBQUFBLFFBQ3BCLHdCQUF3QixLQUFLO0FBQUEsUUFDN0Isa0JBQ0UsSUFBSSxhQUFhLGVBQWUsSUFBSSxtQkFBbUIsS0FBSztBQUFBLE1BQ2hFLENBQUM7QUFDRCxZQUFNLE1BQU8sZ0JBQWdCO0FBQUEsUUFDM0I7QUFBQSxRQUNBLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3JELE1BQU0sTUFBTTtBQUFBLFFBQ1osT0FBTyxNQUFNO0FBQUEsUUFDYixVQUFVLElBQUk7QUFBQSxRQUNkLFFBQVEsSUFBSTtBQUFBLFFBQ1osU0FBUyxJQUFJO0FBQUEsUUFDYixrQkFBa0IsSUFBSTtBQUFBLE1BQ3hCLENBQUM7QUFBQSxJQUNILE9BQU87QUFDTCxZQUFNLE1BQU8sZ0JBQWdCO0FBQUEsUUFDM0I7QUFBQSxRQUNBLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3JELE1BQU0sTUFBTTtBQUFBLFFBQ1osT0FBTyxNQUFNO0FBQUEsUUFDYixHQUFHLGNBQWMsR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFFRixVQUFFO0FBQ0EsVUFBTSxlQUFlO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsZUFBZSxRQUFnQixLQUFnQixRQUFxQztBQUMzRixRQUFNLEtBQUssV0FBVyxJQUFJLFVBQVU7QUFDcEMsUUFBTSxNQUFNLElBQUksV0FBVyxNQUFNLEdBQUcsRUFBRTtBQUN0QyxRQUFNLFdBQVcsV0FBVyxJQUFJLE1BQU07QUFDdEMsUUFBTSxVQUFVLE9BQU8sTUFBTSxJQUFJLEVBQUUsSUFBSSxRQUFRO0FBQy9DLFFBQU0sV0FBVyxRQUFRLE1BQU0sSUFBSSxFQUFFLElBQUksUUFBUTtBQUNqRCxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsU0FBUztBQUFBLE1BQ1AsZ0JBQWdCO0FBQUEsTUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxNQUNwQixnQkFBZ0I7QUFBQSxNQUNoQixhQUFhLElBQUk7QUFBQSxNQUNqQixVQUFVLElBQUksZUFBZSxLQUFLLEdBQUc7QUFBQSxNQUNyQyxZQUFZLFVBQVU7QUFBQSxNQUN0QixZQUFZLElBQUk7QUFBQSxNQUNoQjtBQUFBLElBQ0Y7QUFBQSxJQUNBLE1BQU07QUFBQSxNQUNKLGdCQUFnQjtBQUFBLE1BQ2hCLGdCQUFnQixJQUFJO0FBQUEsTUFDcEIsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYSxJQUFJO0FBQUEsTUFDakIsb0JBQW9CLElBQUk7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsd0JBQXdCLE9BQTRCO0FBQzNELE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdEIsVUFBTSxPQUFPLE1BQU0sQ0FBQztBQUNwQixXQUFPLFlBQVksS0FBSyxNQUFNLElBQUksS0FBSyxHQUFHLElBQUksS0FBSyxPQUFPLE1BQU0sU0FBUyxLQUFLLE9BQU8sV0FBVyxJQUFJLEtBQUssR0FBRyxTQUFTLEtBQUssUUFBUTtBQUFBLEVBQ3BJO0FBQ0EsUUFBTSxPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUUsS0FBSztBQUM5RCxRQUFNLFdBQVcsS0FBSyxXQUFXLElBQUksS0FBSyxDQUFDLElBQUssR0FBRyxLQUFLLENBQUMsQ0FBQyxLQUFLLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQztBQUNwRixRQUFNLGFBQWEsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxPQUFPLFFBQVEsQ0FBQztBQUM5RSxTQUFPLGtCQUFrQixNQUFNLE1BQU0sVUFBVSxVQUFVLFNBQVMsZUFBZSxJQUFJLEtBQUssR0FBRyxLQUFLLFFBQVE7QUFDNUc7QUFFQSxlQUFlLCtCQUErQixNQUFrQztBQUM5RSxRQUFNLFVBQVUsTUFBTSxhQUFhLEtBQUssTUFBTTtBQUM5QyxNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLE1BQUksUUFBUSxXQUFXLEtBQUssSUFBSSxPQUFRLFFBQU8sT0FBTyxLQUFLLFFBQVEsWUFBWSxFQUFFO0FBRWpGLFFBQU0sWUFBWSxJQUFJO0FBQUEsSUFDcEIsS0FBSyxPQUFPLElBQUksQ0FBQyxNQUFNO0FBQUEsTUFDckIsRUFBRTtBQUFBLE1BQ0YsY0FBYyxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRSxZQUFZO0FBQUEsSUFDM0YsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLGtCQUFrRCxDQUFDO0FBQ3pELGFBQVcsQ0FBQyxTQUFTLEtBQUssS0FBSyxPQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDbkUsVUFBTSxlQUFlLFVBQVUsSUFBSSxPQUFPO0FBQzFDLFVBQU0sYUFBYTtBQUFBLE1BQ2pCLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxJQUNSO0FBQ0EsUUFBSSxDQUFDLGdCQUFnQixpQkFBaUIsWUFBWTtBQUNoRCxzQkFBZ0IsT0FBTyxJQUFJLEVBQUUsR0FBRyxNQUFNO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBRUEsUUFBTSxpQkFBaUIsT0FBTyxLQUFLLGVBQWUsRUFBRTtBQUNwRCxNQUFJLG1CQUFtQixHQUFHO0FBQ3hCLFVBQU0sZUFBZSxLQUFLLE1BQU07QUFDaEMsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNLFlBQVksU0FBUztBQUMzQixhQUFXLFNBQVMsT0FBTyxPQUFPLGVBQWUsR0FBRztBQUNsRCxVQUFNLGlCQUFpQjtBQUFBLEVBQ3pCO0FBQ0EsUUFBTSxhQUFhLEtBQUssUUFBUTtBQUFBLElBQzlCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVksUUFBUTtBQUFBLElBQ3BCLGNBQWM7QUFBQSxJQUNkLG9CQUFvQixRQUFRLG1CQUFtQixPQUFPLENBQUMsT0FBTyxNQUFNLGVBQWU7QUFBQSxFQUNyRixDQUFDO0FBQ0QsUUFBTSxLQUFLLG9DQUFvQztBQUFBLElBQzdDLFFBQVEsS0FBSztBQUFBLElBQ2IsZUFBZSxLQUFLO0FBQUEsSUFDcEIsVUFBVSxXQUFXLFNBQVM7QUFBQSxJQUM5QixXQUFXO0FBQUEsRUFDYixDQUFDO0FBQ0QsU0FBTztBQUNUO0FBSUEsZUFBZSxXQUFXLFFBQStCO0FBTXZELFFBQU0sWUFBWSxpQkFBaUIsTUFBTTtBQUN6QyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsUUFBUSxLQUFLLGVBQWUsQ0FBQztBQUNuRSxNQUFJLENBQUUsTUFBTSxhQUFhLE1BQU0sR0FBSTtBQUNqQyxVQUFNLE9BQU0sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDbkMsVUFBTSxhQUFhLFFBQVE7QUFBQSxNQUN6QixRQUFRLFNBQVM7QUFBQSxNQUNqQixnQkFBZ0I7QUFBQSxNQUNoQixZQUFZO0FBQUEsTUFDWixpQkFBaUI7QUFBQSxNQUNqQixjQUFjLENBQUM7QUFBQSxNQUNmLG9CQUFvQixDQUFDO0FBQUEsTUFDckIsZ0JBQWdCLENBQUM7QUFBQSxNQUNqQixZQUFZO0FBQUEsSUFDZCxDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFdBQVcsUUFBUSxLQUFLLENBQUM7QUFDNUQ7QUFFQSxlQUFlLGFBQTRCO0FBQ3pDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxLQUFLLHlCQUF5QixFQUFFLE9BQU8sU0FBUyxPQUFPLENBQUM7QUFDOUQsYUFBVyxLQUFLLFVBQVU7QUFDeEIsVUFBTSxXQUFXLEVBQUUsTUFBTTtBQUFBLEVBQzNCO0FBQ0Y7QUFXQSxlQUFlLGtCQUFpQztBQUM5QyxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUFBLEVBQ3ZFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFDOUU7QUFBQSxFQUNGO0FBQ0EsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixNQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxZQUFZLENBQUMsSUFBSSxLQUFLO0FBQ2xELFVBQU0sS0FBSyxrQ0FBa0M7QUFDN0M7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLGdDQUFnQyxLQUFLLElBQUksR0FBRyxHQUFHO0FBQ2xELFVBQU0sS0FBSywrREFBK0Q7QUFBQSxNQUN4RSxLQUFLLFdBQVcsSUFBSSxHQUFHO0FBQUEsSUFDekIsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUd0RSxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUEsTUFDdEIsT0FBTztBQUFBLElBQ1QsQ0FBQztBQUNELFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyx1Q0FBdUMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUN0RTtBQUdBLE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTztBQUFBLE1BQ1AsTUFBTSxNQUFNO0FBQ1YsY0FBTSxJQUFJLE9BQU87QUFDakIsZUFBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUM7QUFDcEQsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLEdBQUc7QUFDM0UsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFBQSxNQUM5RTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ3pFO0FBQ0Y7QUFhQSxJQUFNLGtCQUFrQjtBQUV4QixlQUFlLGtCQUEwQztBQUN2RCxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGVBQWU7QUFDOUQsUUFBTSxLQUFLLE9BQU8sZUFBZTtBQUNqQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLGdCQUFnQixJQUFrQztBQUMvRCxNQUFJLE9BQU8sTUFBTTtBQUNmLFVBQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxlQUFlO0FBQUEsRUFDcEQsT0FBTztBQUNMLFVBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZUFBZSxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQzNEO0FBQ0Y7QUFFQSxlQUFlLG1CQUFrQztBQUMvQyxRQUFNLFFBQVEsTUFBTSxrQkFBa0I7QUFDdEMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUsseUJBQXlCO0FBQ3BDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxrQkFBa0I7QUFBQSxJQUN0QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELHVCQUFxQixPQUFPO0FBQzVCLE9BQUssWUFBWTtBQUNqQixRQUFNLEtBQUssd0JBQXdCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQzNFLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksd0JBQStEO0FBRW5FLFNBQVMscUJBQXFCLFNBQXVCO0FBQ25ELE1BQUksMEJBQTBCLEtBQU0sZUFBYyxxQkFBcUI7QUFDdkUsMEJBQXdCLFlBQVksTUFBTTtBQUN4QyxTQUFLLFlBQVksRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNoQyxXQUFLLEtBQUssdUJBQXVCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDckQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHNCQUE0QjtBQUNuQyxNQUFJLDBCQUEwQixNQUFNO0FBQ2xDLGtCQUFjLHFCQUFxQjtBQUNuQyw0QkFBd0I7QUFBQSxFQUMxQjtBQUNGO0FBRUEsZUFBZSxvQkFBbUM7QUFDaEQsc0JBQW9CO0FBQ3BCLFFBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxRQUFNLFFBQVEsTUFBTSxnQkFBZ0I7QUFDcEMsUUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixRQUFNLE9BQU8sTUFBTSxrQkFBa0I7QUFDckMsUUFBTSxrQkFBa0IsSUFBSTtBQUM1QixRQUFNLEtBQUssMEJBQTBCO0FBQUEsSUFDbkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxjQUE2QjtBQUMxQyxNQUFJLE9BQU8sTUFBTSxrQkFBa0I7QUFDbkMsTUFBSSxTQUFTLE1BQU07QUFFakIsd0JBQW9CO0FBQ3BCO0FBQUEsRUFDRjtBQUlBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUVBLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFFRCxVQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsZUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsVUFBSSxJQUFJLFNBQVMsS0FBSyxTQUFTLE9BQU8sR0FBRztBQUN2QyxjQUFNLGVBQWUsUUFBUSxLQUFLLFNBQVMsT0FBTztBQUNsRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLGtCQUFrQixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNLFNBQVMsTUFBTSxrQkFBa0I7QUFDdkMsTUFBSSxDQUFDLFFBQVE7QUFDWCx3QkFBb0I7QUFDcEIsVUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyx5QkFBeUIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ2pFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLE1BQU0saUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUNuRSxNQUFJLFFBQVEsTUFBTSxnQkFBZ0I7QUFDbEMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLGdCQUFnQixJQUFJLEVBQUU7QUFBQSxJQUM5RCxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxXQUFRLE1BQU0sa0JBQWtCLEtBQU07QUFDdEMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyxnQkFBZ0I7QUFBQSxNQUN6QixRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLFdBQVcsTUFBTSxrQkFBa0I7QUFBQSxNQUNuQyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyw0Q0FBNEM7QUFBQSxNQUNyRCxRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sZUFBZSxPQUFPLFFBQVEsT0FBTyxPQUFPO0FBQ2xELFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBV0EsSUFBTSxzQkFBc0I7QUFFNUIsZUFBZSxxQkFBNkM7QUFDMUQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxtQkFBbUI7QUFDbEUsUUFBTSxLQUFLLE9BQU8sbUJBQW1CO0FBQ3JDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsbUJBQW1CLElBQWtDO0FBQ2xFLE1BQUksT0FBTyxLQUFNLE9BQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxtQkFBbUI7QUFBQSxNQUNsRSxPQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUNwRTtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELFFBQU0sUUFBUSxNQUFNLHFCQUFxQjtBQUN6QyxNQUFJLFVBQVUsR0FBRztBQUNmLFVBQU0sS0FBSyw2QkFBNkI7QUFDeEM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFVBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsSUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxFQUFFLHFCQUFxQixDQUFDO0FBQUEsRUFDbkU7QUFDQSxRQUFNLHFCQUFxQjtBQUFBLElBQ3pCLGNBQWM7QUFBQSxJQUNkLFdBQVc7QUFBQSxJQUNYLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsMEJBQXdCLE9BQU87QUFDL0IsT0FBSyxlQUFlO0FBQ3BCLFFBQU0sS0FBSyw0QkFBNEIsRUFBRSxRQUFRLE9BQU8sY0FBYyxRQUFRLENBQUM7QUFDL0UsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsSUFBSSwyQkFBa0U7QUFFdEUsU0FBUyx3QkFBd0IsU0FBdUI7QUFDdEQsTUFBSSw2QkFBNkIsS0FBTSxlQUFjLHdCQUF3QjtBQUM3RSw2QkFBMkIsWUFBWSxNQUFNO0FBQzNDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLFNBQVMseUJBQStCO0FBQ3RDLE1BQUksNkJBQTZCLE1BQU07QUFDckMsa0JBQWMsd0JBQXdCO0FBQ3RDLCtCQUEyQjtBQUFBLEVBQzdCO0FBQ0Y7QUFFQSxlQUFlLHVCQUFzQztBQUNuRCx5QkFBdUI7QUFDdkIsUUFBTSxRQUFRLE9BQU8sTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3ZDLFFBQU0sbUJBQW1CLElBQUk7QUFDN0IsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxLQUFLLDhCQUE4QjtBQUFBLElBQ3ZDLFNBQVMsVUFBVTtBQUFBLElBQ25CLFdBQVcsTUFBTSxhQUFhO0FBQUEsRUFDaEMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsaUJBQWdDO0FBQzdDLE1BQUksT0FBTyxNQUFNLHFCQUFxQjtBQUN0QyxNQUFJLFNBQVMsTUFBTTtBQUNqQiwyQkFBdUI7QUFDdkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLGFBQWEsTUFBTTtBQUMxQixVQUFNLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUyxXQUFXO0FBQ2pFLFFBQUksVUFBVSxnQkFBZ0I7QUFDNUI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLG9EQUFvRDtBQUFBLE1BQzdELFVBQVUsS0FBSyxTQUFTO0FBQUEsTUFDeEIsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUNELFVBQU0sa0JBQWtCLEtBQUssU0FBUyxPQUFPO0FBQzdDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBRUEsUUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsMkJBQXVCO0FBQ3ZCLFVBQU0sbUJBQW1CLElBQUk7QUFDN0IsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLEtBQUssNkJBQTZCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNyRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBR0EsTUFBSSxNQUFNLFlBQVksT0FBTyxPQUFPLEdBQUc7QUFDckMsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBTUEsTUFBSSxPQUFPLFdBQVcsWUFBWTtBQUNoQyxVQUFNLEtBQUssbUVBQW1FO0FBQUEsTUFDNUUsVUFBVSxPQUFPO0FBQUEsSUFDbkIsQ0FBQztBQUNELFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sTUFBTSxpQkFBaUIsT0FBTyxNQUFNLFdBQVcsT0FBTyxPQUFPO0FBQ25FLE1BQUksUUFBUSxNQUFNLG1CQUFtQjtBQUNyQyxNQUFJLFVBQVUsTUFBTTtBQUNsQixRQUFJO0FBQ0YsWUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDOUIsUUFBUTtBQUNOLGNBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixRQUFJLFVBQVUsTUFBTTtBQUNsQixZQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDNUQsVUFBSSxPQUFPLElBQUksT0FBTyxTQUFVLE9BQU0sbUJBQW1CLElBQUksRUFBRTtBQUFBLElBQ2pFLE9BQU87QUFDTCxZQUFNLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUNBLFdBQVEsTUFBTSxxQkFBcUIsS0FBTTtBQUN6QyxTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVMsT0FBTztBQUFBLE1BQ2hCLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUN0QztBQUNBLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLG9CQUFvQjtBQUFBLE1BQzdCLFVBQVUsT0FBTztBQUFBLE1BQ2pCLGFBQWEsT0FBTyxXQUFXLGFBQWEsT0FBTyxPQUFPO0FBQUEsTUFDMUQsV0FBVyxNQUFNLHFCQUFxQjtBQUFBLE1BQ3RDLFdBQVcsS0FBSztBQUFBLE1BQ2hCLGdCQUFnQixLQUFLO0FBQUEsSUFDdkIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGdEQUFnRDtBQUFBLE1BQ3pELFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUlBLGVBQWUsV0FDYixRQUNBLFVBQ0EsS0FDQSxLQUNBLEtBQ2U7QUFDZixRQUFNLE1BQU8sd0JBQXdCLEVBQUUsUUFBUSxVQUFVLEtBQUssR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQ3JGLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLFVBQTZCO0FBQUEsSUFDakMsZ0JBQWdCO0FBQUEsSUFDaEI7QUFBQSxJQUNBO0FBQUEsSUFDQSxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDcEMsWUFBWTtBQUFBLElBQ1osT0FBTyxjQUFjLEdBQUc7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssV0FBVyxRQUFRLFdBQVc7QUFDekMsUUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxDQUFDO0FBQy9DLFFBQU0sT0FBTyxtQkFBbUIsRUFBRSxJQUFJLElBQUk7QUFDMUMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ25CO0FBQUEsTUFDQSxlQUFlQSxVQUFTLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUMvRCxTQUFTLGVBQWUsTUFBTSxJQUFJLFFBQVE7QUFBQSxJQUM1QyxDQUFDO0FBQUEsRUFDSCxTQUFTLE1BQU07QUFDYixVQUFNLE1BQU8sNEJBQTRCLEVBQUUsR0FBRyxjQUFjLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDckU7QUFDRjtBQUVBLGVBQWUsS0FBSyxHQUE0QjtBQUM5QyxRQUFNLE1BQU0sSUFBSSxZQUFZLEVBQUUsT0FBTyxDQUFDO0FBQ3RDLFFBQU0sU0FBUyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsR0FBRztBQUN4RCxRQUFNLE1BQU0sTUFBTSxLQUFLLElBQUksV0FBVyxNQUFNLENBQUMsRUFDMUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRTtBQUNWLFNBQU8sSUFBSSxNQUFNLEdBQUcsQ0FBQztBQUN2QjtBQUlBLGVBQWUsaUJBQWlCLE9BQStCO0FBQzdELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsTUFBTTtBQUN0RCxVQUFNLGNBQWM7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUixPQUFPO0FBQUEsTUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZTtBQUFBLE1BQ2Ysd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLE1BQUksQ0FBQyxPQUFPO0FBSVYsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBS0EsUUFBSSxLQUFLLFdBQVc7QUFDbEIsWUFBTSxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVM7QUFDbEQsVUFBSSxNQUFNLDhCQUErQjtBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxJQUFJLE1BQU0sT0FBTyxpQkFBaUI7QUFJeEMsUUFBSSxXQUFXO0FBQ2YsUUFBSSxTQUFTLFVBQVUsU0FBUyxXQUFXLEVBQUUsZ0JBQWdCO0FBQzNELGlCQUFXLE1BQU0sT0FBTyxhQUFhLFNBQVMsTUFBTTtBQUFBLElBQ3REO0FBQ0EsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTyxFQUFFO0FBQUEsTUFDVCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZSxFQUFFO0FBQUEsTUFDakIsd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sS0FBSyx1QkFBdUI7QUFBQSxNQUNoQyxPQUFPLEVBQUU7QUFBQSxNQUNULE1BQU0sRUFBRTtBQUFBLE1BQ1IsZ0JBQWdCLEVBQUU7QUFBQSxNQUNsQixtQkFBbUIsU0FBUztBQUFBLE1BQzVCLDBCQUEwQjtBQUFBLElBQzVCLENBQUM7QUFDRCxRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sS0FBSyw4Q0FBOEM7QUFBQSxRQUN2RCxZQUFZLFNBQVM7QUFBQSxRQUNyQixnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLEtBQUssd0NBQXdDLEVBQUU7QUFBQSxNQUNqRCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFNLGVBQWUsY0FBYyxJQUFJLFdBQVc7QUFDeEQsVUFBTSxTQUNKLFFBQVEsU0FDSixlQUNBLFFBQVEsZUFDTixpQkFDQSxRQUFRLFlBQ04sa0JBQ0E7QUFDVixVQUFNLFVBQ0osZUFBZSxlQUFlLFFBQVEsZUFBZSxJQUFJLG1CQUFtQjtBQUM5RSxVQUFNLGNBQWM7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU8sY0FBYyxHQUFHLEVBQUU7QUFBQSxNQUMxQixlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxLQUFLLDJCQUEyQjtBQUFBLE1BQ3BDLFVBQVU7QUFBQSxNQUNWLGtCQUFrQjtBQUFBLE1BQ2xCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLG9CQUFvQixPQUErQjtBQUNoRSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLEtBQUs7QUFDakIsVUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsT0FBTztBQUlWLFVBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBSUEsVUFBTSxnQkFBZ0IsTUFBTSx1QkFBdUI7QUFDbkQsUUFBSSxlQUFlO0FBQ2pCLFlBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sYUFBYTtBQUNqRCxVQUFJLE9BQU8sU0FBUyxHQUFHLEtBQUssTUFBTSw4QkFBK0I7QUFBQSxJQUNuRTtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxNQUFNLE9BQU8sYUFBYSxzQkFBc0I7QUFDN0QsUUFBSSxDQUFDLE1BQU07QUFDVCxVQUFJLE1BQU8sT0FBTSxLQUFLLGlEQUFpRDtBQUN2RSxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFTLGtCQUFrQixJQUFJO0FBQ3JDLFFBQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsWUFBTSxLQUFLLDhDQUE4QztBQUN6RCxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxZQUFZLE1BQU07QUFDeEIsVUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRCxRQUFJLE1BQU8sT0FBTSxLQUFLLDJCQUEyQixFQUFFLE9BQU8sT0FBTyxPQUFPLENBQUM7QUFBQSxFQUMzRSxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaURBQWlELGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDaEY7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFJQSxlQUFlLGlCQUFnQztBQUM3QyxRQUFNLFFBQVEsTUFBTSxXQUFXO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsTUFBTSxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFO0FBRUEsZUFBZSxhQUFzQztBQUNuRCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksV0FBVztBQUNmLE1BQUk7QUFDRixVQUFNLE9BQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUMzRixlQUFXLEtBQUs7QUFBQSxFQUNsQixRQUFRO0FBQUEsRUFHUjtBQUNBLFFBQU0sZ0JBQWdCLE1BQU0sa0JBQWtCO0FBQzlDLFFBQU0sbUJBQW1CLE1BQU0scUJBQXFCO0FBQ3BELFFBQU0sY0FBYyxNQUFNLGtCQUFrQjtBQUM1QyxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVCxVQUFVLGVBQWUsUUFBUTtBQUFBLElBQ2pDLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWTtBQUFBLE1BQ1YsUUFBUSxtQkFBbUIsUUFBUSxvQkFBb0I7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsYUFBYSxnQkFBZ0IsZUFBZTtBQUFBLE1BQzVDLGVBQWUsZ0JBQWdCLGlCQUFpQjtBQUFBLE1BQ2hELGVBQWUsZ0JBQWdCLGlCQUFpQjtBQUFBLElBQ2xEO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixPQUFPO0FBQUEsTUFDUCxTQUFTLDBCQUEwQjtBQUFBLE1BQ25DLFdBQVcsYUFBYSxhQUFhO0FBQUEsTUFDckMsZ0JBQWdCLGFBQWEsZ0JBQWdCO0FBQUEsSUFDL0M7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLE1BQ2YsT0FBTztBQUFBLE1BQ1AsU0FBUyw2QkFBNkI7QUFBQSxNQUN0QyxXQUFXLGdCQUFnQixhQUFhO0FBQUEsTUFDeEMsZ0JBQWdCLGdCQUFnQixnQkFBZ0I7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUF5QztBQUMvRCxTQUFPO0FBQUEsSUFDTCxPQUFPLEVBQUU7QUFBQSxJQUNULE1BQU0sRUFBRTtBQUFBLElBQ1IsUUFBUSxFQUFFO0FBQUEsSUFDVixTQUFTLEVBQUU7QUFBQSxJQUNYLGFBQWEsRUFBRTtBQUFBLElBQ2YsY0FBYyxFQUFFO0FBQUEsSUFDaEIsdUJBQXVCLEVBQUU7QUFBQSxJQUN6QixRQUFRLEVBQUUsSUFBSSxTQUFTO0FBQUEsSUFDdkIsV0FBVyxFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSTtBQUFBLEVBQ25EO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsS0FBcUI7QUFFdkMsUUFBTSxJQUFJLElBQUksS0FBSyxHQUFHO0FBQ3RCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTyxJQUFJLFFBQVEsU0FBUyxFQUFFO0FBQzdELFFBQU0sTUFBTSxDQUFDLEdBQVcsSUFBSSxNQUFNLE9BQU8sQ0FBQyxFQUFFLFNBQVMsR0FBRyxHQUFHO0FBQzNELFNBQ0UsR0FBRyxFQUFFLGVBQWUsQ0FBQyxJQUFJLElBQUksRUFBRSxZQUFZLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQ3BFLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQztBQUU5RTtBQUVBLFNBQVMsVUFBVSxHQUFxQjtBQUN0QyxTQUFPLFdBQVcsRUFBRSxLQUFLLGNBQWMsRUFBRSxJQUFJO0FBQy9DO0FBU0EsU0FBUyxlQUFlLE1BQXlCO0FBQy9DLFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUMsT0FBTTtBQUNaLFVBQUksT0FBT0EsS0FBSSxlQUFlLFNBQVUsTUFBSyxJQUFJQSxLQUFJLFVBQVU7QUFDL0QsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLFNBQU8sQ0FBQyxHQUFHLElBQUksRUFBRSxLQUFLO0FBQ3hCO0FBT0EsU0FBUyxvQkFBb0IsTUFBZSxVQUFtQztBQUM3RSxRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1BLE9BQU07QUFDWixVQUFJQSxLQUFJLGVBQWUsVUFBVTtBQUMvQixlQUFPLE9BQU8sS0FBS0EsSUFBRyxFQUFFLEtBQUs7QUFBQSxNQUMvQjtBQUNBLGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFRQSxTQUFTLGlCQUFpQixNQUFlLFVBQWtCLE1BQXlCO0FBQ2xGLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixNQUFJLFFBQXdDO0FBQzVDLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNQSxPQUFNO0FBQ1osVUFBSUEsS0FBSSxlQUFlLFVBQVU7QUFDL0IsZ0JBQVFBO0FBQ1I7QUFBQSxNQUNGO0FBQ0EsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxNQUFPLFFBQU87QUFDbkIsTUFBSSxNQUFlO0FBQ25CLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVLFFBQU8sSUFBSSxRQUFRLE9BQU8sU0FBUyxPQUFPLEdBQUc7QUFDMUYsVUFBTyxJQUFnQyxHQUFHO0FBQUEsRUFDNUM7QUFDQSxNQUFJLFFBQVEsT0FBVyxRQUFPO0FBQzlCLE1BQUksUUFBUSxLQUFNLFFBQU87QUFDekIsTUFBSSxPQUFPLFFBQVEsU0FBVSxRQUFPLElBQUksT0FBTyxHQUFHO0FBQ2xELE1BQUksTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLGNBQWMsSUFBSSxNQUFNO0FBQ3ZELFNBQU8sT0FBTyxLQUFLLEdBQThCLEVBQUUsS0FBSztBQUMxRDtBQUVBLFNBQVMsV0FBVyxHQUFtQjtBQUdyQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksSUFBSSxDQUFDO0FBQ3hCLFVBQU0sT0FBTyxPQUFPLFlBQVksT0FBTyxTQUFTLFlBQU87QUFDdkQsV0FBTyxPQUFPLFNBQVMsV0FBVyxPQUFPLFNBQVMsZ0JBQzlDLE9BQ0EsR0FBRyxPQUFPLElBQUksR0FBRyxJQUFJO0FBQUEsRUFDM0IsUUFBUTtBQUNOLFdBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUFBLEVBQ2hEO0FBQ0Y7QUFLQyxXQUF1QyxlQUFlO0FBQUEsRUFDckQ7QUFBQSxFQUNBLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFNBQVM7QUFBQSxFQUNULFVBQVUsTUFBTSxTQUFTLFVBQVU7QUFBQSxFQUNuQyxPQUFPO0FBQUEsRUFDUCxjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxlQUFlO0FBQUEsRUFDZixpQkFBaUI7QUFBQSxFQUNqQixpQkFBaUI7QUFBQSxFQUNqQixrQkFBa0I7QUFDcEI7IiwKICAibmFtZXMiOiBbInRvQmFzZTY0IiwgIm9iaiIsICJpbmZvIiwgInRvQmFzZTY0IiwgIm9iaiJdCn0K
