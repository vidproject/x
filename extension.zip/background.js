// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const unavailableTweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const unavailable = pickUnavailableTweet(raw, ctx);
      if (unavailable) {
        unavailableTweets.push(unavailable);
        observed.push(unavailable.tweet_id);
        built.add(unavailable.tweet_id);
        continue;
      }
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, unavailable_tweets: unavailableTweets, partial_ids };
}
function pickUnavailableTweet(node, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename !== "TweetTombstone") return null;
  const tweetId = strOrNull(n.rest_id) ?? pickTweetIdFromUrls(node) ?? (ctx.sourceUrl ? tweetIdFromTweetUrl(ctx.sourceUrl) : null);
  if (!tweetId || !TWEET_ID_RE.test(tweetId)) return null;
  const unavailableText = pickTombstoneText(node);
  return {
    tweet_id: tweetId,
    account_handle: pickHandleFromTweetUrls(node, tweetId) ?? (ctx.sourceUrl ? handleFromTweetUrl(ctx.sourceUrl, tweetId) : null),
    unavailable_detected_at: ctx.capturedAt,
    unavailable_reason: classifyUnavailableReason(unavailableText),
    unavailable_text: unavailableText,
    unavailable_source_url: ctx.sourceUrl ?? null
  };
}
function pickTweetIdFromUrls(node) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const id = tweetIdFromTweetUrl(cur);
      if (id) return id;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function tweetIdFromTweetUrl(rawUrl) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/[A-Za-z0-9_]{1,15}\/status\/(\d{15,20})(?:\/|$)/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
function pickTombstoneText(node) {
  const strings = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const trimmed = cur.trim();
      if (trimmed.length >= 4 && !trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
        strings.push(trimmed);
      }
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  const preferred = strings.find(
    (s) => /\b(copyright|dmca|unavailable|withheld|removed|deleted|violat|suspended)\b/i.test(s)
  );
  return preferred ?? strings[0] ?? null;
}
function classifyUnavailableReason(text) {
  if (!text) return null;
  if (/\b(copyright|dmca)\b/i.test(text)) return "copyright";
  if (/\bwithheld\b/i.test(text)) return "withheld";
  if (/\bdeleted|removed\b/i.test(text)) return "removed";
  if (/\bsuspended\b/i.test(text)) return "suspended";
  if (/\bunavailable|not available\b/i.test(text)) return "unavailable";
  return null;
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  const hintHandle = pickHintHandle(node, restId);
  if (!hintHandle) return null;
  return { tweet_id: restId, hint_handle: hintHandle };
}
function pickHintHandle(node, tweetId) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name) ?? pickHandleFromTweetUrls(node, tweetId);
}
function pickHandleFromTweetUrls(node, tweetId) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const handle = handleFromTweetUrl(cur, tweetId);
      if (handle) return handle;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function handleFromTweetUrl(rawUrl, tweetId) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d{15,20})(?:\/|$)/);
    if (!match || match[2] !== tweetId) return null;
    return match[1] ?? null;
  } catch {
    return null;
  }
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    unavailable_detected_at: null,
    unavailable_reason: null,
    unavailable_text: null,
    unavailable_source_url: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted) {
  if (targeted.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.retweeted_tweet_id && targetedTweetIds.has(t.retweeted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let expandedCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        // Cast: the @types/firefox-webext-browser type signature insists
        // `func` returns void, but the API actually surfaces the return
        // value via `result[0].result`. We use that for the expand count.
        func: () => {
          const SHOW_MORE_SELECTORS = [
            '[data-testid="tweet-text-show-more-link"]',
            'button[data-testid="tweet-text-show-more-link"]',
            'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
          ];
          const clicked = /* @__PURE__ */ new Set();
          let expanded = 0;
          for (const sel of SHOW_MORE_SELECTORS) {
            for (const el of Array.from(document.querySelectorAll(sel))) {
              if (clicked.has(el)) continue;
              const t = (el.textContent || "").trim().toLowerCase();
              if (t !== "show more" && t !== "show this thread") continue;
              const rect = el.getBoundingClientRect();
              if (rect.width === 0 || rect.height === 0) continue;
              clicked.add(el);
              try {
                el.click();
                expanded += 1;
              } catch {
              }
            }
          }
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { expanded };
        }
      });
      scrollCount += 1;
      const r = results[0]?.result;
      if (r && typeof r.expanded === "number") expandedCount += r.expanded;
    } catch {
    }
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      sess.expandedCount += expandedCount;
      await setAutoScrollSession(sess);
    }
  }
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.pageUrl ?? null, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, pageUrl, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set(),
      sourceUrl: pageUrl
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.unavailable_tweets.length > 0) {
    await recordUnavailableTweets(normalized.unavailable_tweets, tracked, capturedAt, url, endpoint);
  }
  if (normalized.tweets.length === 0) return;
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const committedIdx = await getCommittedIndex();
  let dedupedSkipped = 0;
  const liveTweets = [];
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      continue;
    }
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (liveTweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(
      handle,
      Object.keys(buf.tweets_by_id).length + Object.keys(buf.unavailable_by_id ?? {}).length
    );
    if (added > 0) {
      await info("captured tweets", {
        handle,
        endpoint,
        added,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function recordUnavailableTweets(unavailableTweets, tracked, capturedAt, sourceUrl, endpoint) {
  const committedIdx = await getCommittedIndex();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  let recorded = 0;
  let skipped = 0;
  let missingHandle = 0;
  for (const u of unavailableTweets) {
    const handle = u.account_handle;
    if (!handle) {
      missingHandle += 1;
      await dequeueMediaCrawl(u.tweet_id);
      continue;
    }
    if (tracked.size > 0 && !tracked.has(handle.toLowerCase())) {
      skipped += 1;
      continue;
    }
    await dequeueMediaCrawl(u.tweet_id);
    await dequeueRefetch(handle, u.tweet_id);
    if (refetchSess?.inflight?.tweetId === u.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === u.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    const sig = unavailableSig(u);
    const prev = committedIdx[handle]?.[u.tweet_id];
    if (prev?.sig === sig) {
      skipped += 1;
      continue;
    }
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const unavailableById = buf.unavailable_by_id ?? {};
    unavailableById[u.tweet_id] = u;
    buf.unavailable_by_id = unavailableById;
    if (!buf.tweet_ids_observed.includes(u.tweet_id)) {
      buf.tweet_ids_observed.push(u.tweet_id);
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(
      handle,
      Object.keys(buf.tweets_by_id).length + Object.keys(unavailableById).length
    );
    recorded += 1;
  }
  if (recorded > 0 || missingHandle > 0 || skipped > 0) {
    await info("unavailable tweets observed", { endpoint, recorded, skipped, missingHandle });
  }
  await broadcastState();
}
function unavailableSig(u) {
  return `unavailable|${u.unavailable_reason ?? ""}|${u.unavailable_text ?? ""}`;
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    unavailable_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    const unavailableTweets = Object.values(buf.unavailable_by_id ?? {});
    if (tweets.length === 0 && unavailableTweets.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets, unavailableTweets));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length + item.unavailableTweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length + item.unavailableTweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      for (const u of item.unavailableTweets) {
        inner[u.tweet_id] = {
          ts: nowIso,
          sig: unavailableSig(u)
        };
      }
      idx[item.handle] = inner;
      await info("flush committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        unavailable: item.unavailableTweets.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("flush batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      unavailable: items.reduce((total, item) => total + item.unavailableTweets.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets, unavailableTweets) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    unavailableTweets,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets,
      unavailable_tweets: unavailableTweets
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    const unavailableCount2 = item.unavailableTweets.length;
    const suffix2 = unavailableCount2 > 0 ? `, ${unavailableCount2} unavailable` : "";
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"}${suffix2} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  const unavailableCount = items.reduce((total, item) => total + item.unavailableTweets.length, 0);
  const suffix = unavailableCount > 0 ? `, ${unavailableCount} unavailable` : "";
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"}${suffix} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return Object.keys(current.tweets_by_id).length;
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  for (const u of item.unavailableTweets) {
    committed.set(u.tweet_id, unavailableSig(u));
  }
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingUnavailable = {};
  for (const [tweetId, unavailable] of Object.entries(current.unavailable_by_id ?? {})) {
    const committedSig = committed.get(tweetId);
    const currentSig = unavailableSig(unavailable);
    if (!committedSig || committedSig !== currentSig) {
      remainingUnavailable[tweetId] = { ...unavailable };
    }
  }
  const remainingIds = /* @__PURE__ */ new Set([
    ...Object.keys(remainingTweets),
    ...Object.keys(remainingUnavailable)
  ]);
  const remainingCount = remainingIds.size;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    unavailable_by_id: remainingUnavailable,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => remainingIds.has(id))
  });
  await info("flush kept newer buffered tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      unavailable_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  if (target.bucket === "_unknown") {
    await warn("media-crawl target missing handle; skipping broken status route", {
      tweet_id: target.tweetId
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const autoScrollSess = await getAutoScrollSession();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    }
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xyXG4gIHBhdDogJycsXHJcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcclxuICByZXBvOiAneCcsXHJcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxyXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXHJcbiAgYnJhbmNoOiAnbWFzdGVyJyxcclxuICBlbmFibGVkOiB0cnVlLFxyXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxyXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcclxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XHJcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XHJcblxyXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxyXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXHJcbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xyXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuXTtcclxuXHJcbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXHJcbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG4gICdMaWtlcycsXHJcbiAgJ0Jvb2ttYXJrcycsXHJcbiAgJ0hvbWVUaW1lbGluZScsXHJcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXHJcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcclxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcclxuXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XHJcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXHJcbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXHJcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxyXG5dKTtcclxuXHJcbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxyXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxyXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3JcclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxyXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcclxuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXHJcbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXHJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcclxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxyXG4vL1xyXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcclxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXHJcbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cclxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG5dKTtcclxuXHJcbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxyXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xyXG5cclxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcclxuXHJcbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XHJcblxyXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXHJcbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcclxuXHJcbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cclxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XHJcblxyXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcclxuIiwgIi8qKlxyXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cclxuICpcclxuICogVGhyZWF0IG1vZGVsOiBhbiBhdHRhY2tlciB3aG8gcmVhZHMgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgKGRldnRvb2xzLCBhXHJcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXHJcbiAqIEdpdEh1YiBQQVQgaW4gcGxhaW50ZXh0LiBBIGRldGVybWluZWQgYXR0YWNrZXIgd2l0aCB0aGUgZXh0ZW5zaW9uJ3Mgc291cmNlXHJcbiAqIGNhbiBzdGlsbCBkZXJpdmUgdGhlIGtleSBcdTIwMTQgd2UgbWFrZSBubyBjbGFpbSBvZiBcInJlYWxcIiBjcnlwdG9ncmFwaGljXHJcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxyXG4gKiBzdHJpbmcgc2l0dGluZyBuZXh0IHRvIGl0cyBrZXkgbmFtZSBpbiBleHRlbnNpb24gc3RvcmFnZS5cclxuICpcclxuICogU2NoZW1lOlxyXG4gKiAgIC0gT24gZmlyc3QgZW5jcnlwdGlvbiB3ZSBnZW5lcmF0ZSBhIDMyLWJ5dGUgc2FsdCBhbmQgcGVyc2lzdCBpdCBpblxyXG4gKiAgICAgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgdW5kZXIgYF9faW1tX2FyY2hpdmVfc2FsdF9fYC5cclxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cclxuICogICAgIHx8IFwiaW1tLWFyY2hpdmUtcGF0LXYxXCJgLiBUaGUgc2FsdCBiZWluZyBwZXItaW5zdGFsbCBtZWFucyB0d28gY29waWVzXHJcbiAqICAgICBvZiB0aGUgZXh0ZW5zaW9uIGRvbid0IHNoYXJlIGEga2V5LiBUaGUgcnVudGltZS5pZCBpcyB0aGUgZXh0ZW5zaW9uJ3NcclxuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxyXG4gKiAgIC0gUGxhaW50ZXh0IGlzIGVuY3J5cHRlZCB3aXRoIGEgZnJlc2ggMTItYnl0ZSBJVi4gVGhlIGVudmVsb3BlIGZvcm1hdCBpc1xyXG4gKiAgICAgYHYxOjxpdi1iNjQ+OjxjaXBoZXJ0ZXh0LWI2ND5gIGFuZCBpcyB3aGF0IGdldHMgc3RvcmVkLlxyXG4gKlxyXG4gKiBCYWNrd2FyZHMgY29tcGF0aWJpbGl0eTogYW4gdW5wcmVmaXhlZCB2YWx1ZSBpcyB0cmVhdGVkIGFzIGxlZ2FjeVxyXG4gKiBwbGFpbnRleHQsIGRlY3J5cHRlZCB0byBpdHNlbGYsIGFuZCByZS1lbmNyeXB0ZWQgb24gdGhlIG5leHQgd3JpdGUuXHJcbiAqL1xyXG5cclxuY29uc3QgU0FMVF9TVE9SQUdFX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3NhbHRfXyc7XHJcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xyXG5cclxubGV0IGRlcml2ZWRLZXlDYWNoZTogQ3J5cHRvS2V5IHwgbnVsbCA9IG51bGw7XHJcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHRvQmFzZTY0KGJ1ZjogVWludDhBcnJheSk6IHN0cmluZyB7XHJcbiAgbGV0IHMgPSAnJztcclxuICBmb3IgKGNvbnN0IGIgb2YgYnVmKSBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYik7XHJcbiAgcmV0dXJuIGJ0b2Eocyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZyb21CYXNlNjQoczogc3RyaW5nKTogVWludDhBcnJheSB7XHJcbiAgY29uc3QgYmluID0gYXRvYihzKTtcclxuICBjb25zdCBvdXQgPSBuZXcgVWludDhBcnJheShiaW4ubGVuZ3RoKTtcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IGJpbi5sZW5ndGg7IGkrKykgb3V0W2ldID0gYmluLmNoYXJDb2RlQXQoaSk7XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcclxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFNBTFRfU1RPUkFHRV9LRVkpO1xyXG4gIGNvbnN0IHYgPSBzdG9yZWRbU0FMVF9TVE9SQUdFX0tFWV07XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcclxuICAgIHJldHVybiB7IHNhbHRCNjQ6IHYsIHNhbHQ6IGZyb21CYXNlNjQodikgfTtcclxuICB9XHJcbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcclxuICBjb25zdCBzYWx0QjY0ID0gdG9CYXNlNjQoc2FsdCk7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtTQUxUX1NUT1JBR0VfS0VZXTogc2FsdEI2NCB9KTtcclxuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xyXG4gIGNvbnN0IHsgc2FsdEI2NCwgc2FsdCB9ID0gYXdhaXQgbG9hZE9yQ3JlYXRlU2FsdCgpO1xyXG4gIGlmIChkZXJpdmVkS2V5Q2FjaGUgIT09IG51bGwgJiYgZGVyaXZlZEtleUNhY2hlU2FsdCA9PT0gc2FsdEI2NCkge1xyXG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcclxuICB9XHJcbiAgY29uc3Qgc2VlZCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcclxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXHJcbiAgKTtcclxuICBjb25zdCBjb21iaW5lZCA9IG5ldyBVaW50OEFycmF5KHNlZWQubGVuZ3RoICsgc2FsdC5sZW5ndGgpO1xyXG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcclxuICBjb21iaW5lZC5zZXQoc2FsdCwgc2VlZC5sZW5ndGgpO1xyXG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGNvbWJpbmVkKTtcclxuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcclxuICAgICdlbmNyeXB0JyxcclxuICAgICdkZWNyeXB0JyxcclxuICBdKTtcclxuICBkZXJpdmVkS2V5Q2FjaGUgPSBrZXk7XHJcbiAgZGVyaXZlZEtleUNhY2hlU2FsdCA9IHNhbHRCNjQ7XHJcbiAgcmV0dXJuIGtleTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gIHJldHVybiB2LnN0YXJ0c1dpdGgoRU5WRUxPUEVfUFJFRklYKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVuY3J5cHRQYXQocGxhaW50ZXh0OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIGlmICghcGxhaW50ZXh0KSByZXR1cm4gJyc7XHJcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XHJcbiAgY29uc3QgaXYgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEyKSk7XHJcbiAgY29uc3QgY3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmVuY3J5cHQoXHJcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcclxuICAgIGtleSxcclxuICAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShwbGFpbnRleHQpXHJcbiAgKTtcclxuICByZXR1cm4gYCR7RU5WRUxPUEVfUFJFRklYfSR7dG9CYXNlNjQoaXYpfToke3RvQmFzZTY0KG5ldyBVaW50OEFycmF5KGN0KSl9YDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlY3J5cHRQYXQoZW52ZWxvcGU6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgaWYgKCFlbnZlbG9wZSkgcmV0dXJuICcnO1xyXG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXHJcbiAgLy8gcmUtZW5jcnlwdHMgaXQgdmlhIHRoZSBzdG9yYWdlIGxheWVyLlxyXG4gIGlmICghZW52ZWxvcGUuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpKSByZXR1cm4gZW52ZWxvcGU7XHJcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xyXG4gIGlmIChwYXJ0cy5sZW5ndGggIT09IDIpIHJldHVybiAnJztcclxuICBjb25zdCBbaXZCNjQsIGN0QjY0XSA9IHBhcnRzO1xyXG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGtleSA9IGF3YWl0IGRlcml2ZUtleSgpO1xyXG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcclxuICAgIGNvbnN0IGN0ID0gZnJvbUJhc2U2NChjdEI2NCk7XHJcbiAgICBjb25zdCBwdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGVjcnlwdChcclxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcclxuICAgICAga2V5LFxyXG4gICAgICBjdCBhcyBCdWZmZXJTb3VyY2VcclxuICAgICk7XHJcbiAgICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKHB0KTtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiAnJztcclxuICB9XHJcbn1cclxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcclxuaW1wb3J0IHsgZGVjcnlwdFBhdCwgZW5jcnlwdFBhdCwgaXNFbmNyeXB0ZWRQYXQgfSBmcm9tICcuL2NyeXB0by5qcyc7XHJcbmltcG9ydCB0eXBlIHtcclxuICBBY2NvdW50Q29uZmlnLFxyXG4gIEFjY291bnRDb3VudGVyLFxyXG4gIENhbm9uaWNhbFR3ZWV0LFxyXG4gIENvbm5lY3Rpb25TdGF0ZSxcclxuICBMb2dFdmVudCxcclxuICBTZXR0aW5ncyxcclxuICBVbmF2YWlsYWJsZVR3ZWV0LFxyXG59IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuLyoqXHJcbiAqIEJ1ZmZlcmVkIHR3ZWV0cyBmb3IgYSBnaXZlbiBhY2NvdW50LCBhd2FpdGluZyBjb21taXQuIEEgXCJydW5cIiBpcyBvbmUgZW50cnlcclxuICogaW4gdGhpcyBtYXA7IGZsdXNoaW5nIGNsZWFycyB0aGUgZW50cnkuIFdlIHN0b3JlIGFzIFJlY29yZCBzbyB0aGUgc3RydWN0dXJlXHJcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgUnVuQnVmZmVyIHtcclxuICBydW5faWQ6IHN0cmluZztcclxuICBhY2NvdW50X2hhbmRsZTogc3RyaW5nO1xyXG4gIHN0YXJ0ZWRfYXQ6IHN0cmluZztcclxuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcclxuICB0d2VldHNfYnlfaWQ6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PjtcclxuICB1bmF2YWlsYWJsZV9ieV9pZD86IFJlY29yZDxzdHJpbmcsIFVuYXZhaWxhYmxlVHdlZXQ+O1xyXG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XHJcbiAgZW5kcG9pbnRzX3NlZW46IHN0cmluZ1tdO1xyXG4gIHNvdXJjZV91cmw6IHN0cmluZyB8IG51bGw7XHJcbn1cclxuXHJcbi8qKiBQZXItdHdlZXQgY29tbWl0dGVkLXN0YXRlIGluZGV4LCBrZXllZCBieSBoYW5kbGUgdGhlbiB0d2VldF9pZC5cclxuICogVXNlZCB0byBza2lwIHJlLWNhcHR1cmluZyB0d2VldHMgd2UndmUgYWxyZWFkeSBwdXNoZWQgd2l0aCBpZGVudGljYWxcclxuICogZW5nYWdlbWVudCBjb3VudHMgXHUyMDE0IGF2b2lkcyBnZW5lcmF0aW5nIG9uZSBuZXcgcmF3LyogZmlsZSBldmVyeSBicm93c2UuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0dGVkRW50cnkge1xyXG4gIHRzOiBzdHJpbmc7IC8vIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3QgY29tbWl0XHJcbiAgc2lnOiBzdHJpbmc7IC8vIGVuZ2FnZW1lbnQgc2lnbmF0dXJlOiBcImxpa2V8cnR8cmVwbHl8cXVvdGVcIlxyXG59XHJcblxyXG4vKiogUHJvZ3Jlc3MgKyBpbmZsaWdodCB0cmFja2luZyBmb3IgYSBxdWV1ZS1kcml2ZW4gbG9vcCAocmVmZXRjaCAvIG1lZGlhLWNyYXdsKS5cclxuICogVGhlIGxvb3AgcGVyc2lzdHMgdGhpcyBzbyBhIFNXIGV2aWN0aW9uIGluIHRoZSBtaWRkbGUgb2YgYSBydW4gcHJlc2VydmVzXHJcbiAqIFwiWCBvZiBZIHByb2Nlc3NlZFwiIFx1MjAxNCBhbmQgdGhlIHdhaXQtZm9yLWluZ2VzdCBndWFyZCBrbm93cyB3aGF0IHRvIGV4cGVjdC5cclxuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgTG9vcFNlc3Npb24ge1xyXG4gIC8qKiBJbml0aWFsIHF1ZXVlIHNpemUgd2hlbiB0aGUgdXNlciBjbGlja2VkIFwiU3RhcnRcIi4gKi9cclxuICB0b3RhbEF0U3RhcnQ6IG51bWJlcjtcclxuICAvKiogVHdlZXRzIHByb2Nlc3NlZCAoaW5nZXN0ZWQgT1IgZHJvcHBlZCBhZnRlciByZXRyaWVzKSBzbyBmYXIuICovXHJcbiAgcHJvY2Vzc2VkOiBudW1iZXI7XHJcbiAgLyoqIElTTyBvZiB3aGVuIHRoaXMgc2Vzc2lvbiBzdGFydGVkLiAqL1xyXG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xyXG4gIC8qKiBUd2VldCBjdXJyZW50bHkgaW5mbGlnaHQgXHUyMDE0IHdlIG5hdmlnYXRlZCB0byBpdCBhbmQgYXJlIHdhaXRpbmcgZm9yIHRoZVxyXG4gICAqIHBhZ2UtaG9vayB0byBjYXB0dXJlIHRoZSByZXNwb25zZSBiZWZvcmUgYWR2YW5jaW5nLiBudWxsIGJldHdlZW4gdGlja3NcclxuICAgKiAoYW5kIG9uY2UgYW4gaW5nZXN0IGhhcyBiZWVuIG9ic2VydmVkKS4gKi9cclxuICBpbmZsaWdodDogeyB0d2VldElkOiBzdHJpbmc7IG5hdmlnYXRlZEF0OiBzdHJpbmcgfSB8IG51bGw7XHJcbn1cclxuXHJcbi8qKiBBdXRvLXNjcm9sbCBzZXNzaW9uOiBjb3VudHMgb2YgdGlja3MgYW5kIHR3ZWV0cyBpbmdlc3RlZCBzaW5jZSB0aGUgdXNlclxyXG4gKiBjbGlja2VkIFN0YXJ0LiBQZXJzaXN0ZWQgc28gU1cgZXZpY3Rpb24gZHVyaW5nIGEgcnVuIGtlZXBzIHByb2dyZXNzLiAqL1xyXG5leHBvcnQgaW50ZXJmYWNlIEF1dG9TY3JvbGxTZXNzaW9uIHtcclxuICBzdGFydGVkQXQ6IHN0cmluZztcclxuICBzY3JvbGxDb3VudDogbnVtYmVyO1xyXG4gIGluZ2VzdGVkQ291bnQ6IG51bWJlcjtcclxuICBleHBhbmRlZENvdW50OiBudW1iZXI7XHJcbn1cclxuXHJcbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xyXG4gIHNldHRpbmdzOiBTZXR0aW5ncztcclxuICBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdO1xyXG4gIC8qKiBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IHN1Y2Nlc3NmdWwgYWNjb3VudHMueWFtbCBmZXRjaCBmcm9tIHRoZSByZXBvLlxyXG4gICAqIFVzZWQgYnkgYHJlZnJlc2hBY2NvdW50c0xpc3RgIHRvIHNraXAgcmUtZmV0Y2hpbmcgb24gZXZlcnkgU1cgd2FrZSBcdTIwMTQgdGhlXHJcbiAgICogZmlsZSBjaGFuZ2VzIHJhcmVseSBhbmQgYW4gYXV0aGVudGljYXRlZCByYXcgZmV0Y2ggZXZlcnkgd2FrZSBhZGRzIHVwLiAqL1xyXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IHN0cmluZyB8IG51bGw7XHJcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvblN0YXRlO1xyXG4gIGNvdW50ZXJzOiBSZWNvcmQ8c3RyaW5nLCBBY2NvdW50Q291bnRlcj47XHJcbiAgcnVuQnVmZmVyczogUmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPjtcclxuICBhY3Rpdml0eTogTG9nRXZlbnRbXTtcclxuICBjb21taXR0ZWRJbmRleDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PjtcclxuICAvKiogVHdlZXRzIHRoZSBub3JtYWxpemVyIGZsYWdnZWQgYXMgdHJ1bmNhdGVkIGFuZCB0aGF0IHdlIGhhdmVuJ3Qgc2VlbiBhXHJcbiAgICogZnVsbC10ZXh0IHZlcnNpb24gb2YgeWV0LiBLZXllZCBieSBoYW5kbGUgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gKi9cclxuICByZWZldGNoUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcclxuICAvKiogVHdlZXQgSURzIHNlZW4gdmlhIE1lZGlhLXRhYiAvIHBhcnRpYWwgY2FwdHVyZXMgdGhhdCBjb3VsZG4ndCBiZVxyXG4gICAqIG5vcm1hbGl6ZWQgaW50byBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBLZXllZCBieSBoaW50LWhhbmRsZSAob3JcclxuICAgKiBcIl91bmtub3duXCIpIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuIFRoZSB1c2VyIGNhbiBkcml2ZSBhIGNyYXdsIHRoYXRcclxuICAgKiBvcGVucyBlYWNoIGRldGFpbCBwYWdlIHRvIGNhcHR1cmUgdGhlIHJlYWwgdGhpbmcuICovXHJcbiAgbWVkaWFDcmF3bFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XHJcbiAgcmVmZXRjaFNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcclxuICBtZWRpYUNyYXdsU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xyXG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw7XHJcbn1cclxuXHJcbmNvbnN0IERFRkFVTFRfQ09OTkVDVElPTjogQ29ubmVjdGlvblN0YXRlID0ge1xyXG4gIHN0YXR1czogJ3Vua25vd24nLFxyXG4gIGxvZ2luOiBudWxsLFxyXG4gIGNoZWNrZWRBdDogbnVsbCxcclxuICBlcnJvcjogbnVsbCxcclxuICBkZWZhdWx0QnJhbmNoOiBudWxsLFxyXG4gIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXHJcbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcclxufTtcclxuXHJcbmNvbnN0IERFRkFVTFRTOiBTdG9yYWdlU2hhcGUgPSB7XHJcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9LFxyXG4gIGFjY291bnRzOiBbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdLFxyXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IG51bGwsXHJcbiAgY29ubmVjdGlvbjogeyAuLi5ERUZBVUxUX0NPTk5FQ1RJT04gfSxcclxuICBjb3VudGVyczoge30sXHJcbiAgcnVuQnVmZmVyczoge30sXHJcbiAgYWN0aXZpdHk6IFtdLFxyXG4gIGNvbW1pdHRlZEluZGV4OiB7fSxcclxuICByZWZldGNoUXVldWU6IHt9LFxyXG4gIG1lZGlhQ3Jhd2xRdWV1ZToge30sXHJcbiAgcmVmZXRjaFNlc3Npb246IG51bGwsXHJcbiAgbWVkaWFDcmF3bFNlc3Npb246IG51bGwsXHJcbiAgYXV0b1Njcm9sbFNlc3Npb246IG51bGwsXHJcbn07XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcclxuICBjb25zdCByZXN1bHQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KGtleSk7XHJcbiAgY29uc3QgdmFsdWUgPSByZXN1bHRba2V5XTtcclxuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xyXG4gICAgcmV0dXJuIHN0cnVjdHVyZWRDbG9uZShERUZBVUxUU1trZXldKTtcclxuICB9XHJcbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBba2V5XTogdmFsdWUgfSk7XHJcbn1cclxuXHJcbi8vIC0tLSBTZXR0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xyXG4gIC8vIEJhY2tmaWxsIGFueSBrZXlzIHRoZSB1c2VyJ3Mgc3RvcmVkIHNldHRpbmdzIHByZWRhdGUgXHUyMDE0IHJlYWRlcnMgY2FuIHJlbHlcclxuICAvLyBvbiBldmVyeSBTZXR0aW5ncyBmaWVsZCBiZWluZyBwcmVzZW50IHJhdGhlciB0aGFuIGA/PyBkZWZhdWx0aW5nYCBhdFxyXG4gIC8vIGV2ZXJ5IGNhbGxzaXRlLiBUaGUgUEFUIGlzIHN0b3JlZCBlbmNyeXB0ZWQtYXQtcmVzdCBhcyBvZiB2MC4yLjA7IHdlXHJcbiAgLy8gZGVjcnlwdCB0cmFuc3BhcmVudGx5IHNvIGNhbGxlcnMgY29udGludWUgdG8gc2VlIHBsYWludGV4dC5cclxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBnZXRSYXcoJ3NldHRpbmdzJyk7XHJcbiAgY29uc3QgbWVyZ2VkID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi5zdG9yZWQgfTtcclxuICBpZiAobWVyZ2VkLnBhdCAmJiBpc0VuY3J5cHRlZFBhdChtZXJnZWQucGF0KSkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgbWVyZ2VkLnBhdCA9IGF3YWl0IGRlY3J5cHRQYXQobWVyZ2VkLnBhdCk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgbWVyZ2VkLnBhdCA9ICcnO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gbWVyZ2VkO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIC8vIEVuY3J5cHQgdGhlIFBBVCBiZWZvcmUgcGVyc2lzdGluZzsgbGVnYWN5IHBsYWludGV4dCBQQVRzIGdldCB1cGdyYWRlZFxyXG4gIC8vIG9uIHRoZSBuZXh0IHNhdmUuXHJcbiAgY29uc3QgdG9Xcml0ZTogU2V0dGluZ3MgPSB7IC4uLnMgfTtcclxuICBpZiAodG9Xcml0ZS5wYXQgJiYgIWlzRW5jcnlwdGVkUGF0KHRvV3JpdGUucGF0KSkge1xyXG4gICAgdG9Xcml0ZS5wYXQgPSBhd2FpdCBlbmNyeXB0UGF0KHRvV3JpdGUucGF0KTtcclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdzZXR0aW5ncycsIHRvV3JpdGUpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVTZXR0aW5ncyhwYXRjaDogUGFydGlhbDxTZXR0aW5ncz4pOiBQcm9taXNlPFNldHRpbmdzPiB7XHJcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBjb25zdCBuZXh0ID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XHJcbiAgYXdhaXQgc2V0U2V0dGluZ3MobmV4dCk7XHJcbiAgcmV0dXJuIG5leHQ7XHJcbn1cclxuXHJcbi8vIC0tLSBBY2NvdW50cyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHMoKTogUHJvbWlzZTxBY2NvdW50Q29uZmlnW10+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50cycpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50cyhhOiBBY2NvdW50Q29uZmlnW10pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzJywgYSk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzUmVmcmVzaGVkQXQoKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KGlzbzogc3RyaW5nIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcsIGlzbyk7XHJcbn1cclxuXHJcbi8vIC0tLSBDb25uZWN0aW9uIHN0YXRlIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25uZWN0aW9uKCk6IFByb21pc2U8Q29ubmVjdGlvblN0YXRlPiB7XHJcbiAgY29uc3QgYyA9IGF3YWl0IGdldFJhdygnY29ubmVjdGlvbicpO1xyXG4gIC8vIEJhY2tmaWxsIGZpZWxkcyBhZGRlZCBhZnRlciB0aGUgdXNlcidzIHN0b3JhZ2Ugd2FzIHdyaXR0ZW4uXHJcbiAgY29uc3Qgb3V0OiBDb25uZWN0aW9uU3RhdGUgPSB7XHJcbiAgICAuLi5jLFxyXG4gICAgZGVmYXVsdEJyYW5jaDogYy5kZWZhdWx0QnJhbmNoID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5kZWZhdWx0QnJhbmNoLFxyXG4gICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czpcclxuICAgICAgYy5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxyXG4gICAgcmF0ZUxpbWl0UmVzZXRBdDogYy5yYXRlTGltaXRSZXNldEF0ID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5yYXRlTGltaXRSZXNldEF0LFxyXG4gIH07XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29ubmVjdGlvbihjOiBDb25uZWN0aW9uU3RhdGUpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2Nvbm5lY3Rpb24nLCBjKTtcclxufVxyXG5cclxuLy8gLS0tIENvdW50ZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmZ1bmN0aW9uIHRvZGF5SVNPKCk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3VudGVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2NvdW50ZXJzJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGJ1bXBDb3VudGVyKFxyXG4gIGhhbmRsZTogc3RyaW5nLFxyXG4gIHBhdGNoOiBQYXJ0aWFsPEFjY291bnRDb3VudGVyPlxyXG4pOiBQcm9taXNlPEFjY291bnRDb3VudGVyPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcclxuICBjb25zdCBjdXIgPSBhbGxbaGFuZGxlXSA/PyB7XHJcbiAgICB0b2RheUNvdW50OiAwLFxyXG4gICAgdG9kYXlEYXRlOiB0b2RheUlTTygpLFxyXG4gICAgbGFzdENhcHR1cmVBdDogbnVsbCxcclxuICAgIHRvdGFsQ29tbWl0dGVkOiAwLFxyXG4gICAgYnVmZmVyZWRDb3VudDogMCxcclxuICB9O1xyXG4gIGlmIChjdXIudG9kYXlEYXRlICE9PSB0b2RheUlTTygpKSB7XHJcbiAgICBjdXIudG9kYXlEYXRlID0gdG9kYXlJU08oKTtcclxuICAgIGN1ci50b2RheUNvdW50ID0gMDtcclxuICB9XHJcbiAgY29uc3QgbmV4dDogQWNjb3VudENvdW50ZXIgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcclxuICBhbGxbaGFuZGxlXSA9IG5leHQ7XHJcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGFsbCk7XHJcbiAgcmV0dXJuIG5leHQ7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRCdWZmZXJlZENvdW50KGhhbmRsZTogc3RyaW5nLCBjb3VudDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgYnVtcENvdW50ZXIoaGFuZGxlLCB7IGJ1ZmZlcmVkQ291bnQ6IGNvdW50IH0pO1xyXG59XHJcblxyXG4vLyAtLS0gUnVuIGJ1ZmZlcnMgKHRoZSBwZW5kaW5nIGNhcHR1cmVzIGF3YWl0aW5nIGNvbW1pdCkgLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdydW5CdWZmZXJzJyk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPFJ1bkJ1ZmZlciB8IG51bGw+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgcmV0dXJuIGFsbFtoYW5kbGVdID8/IG51bGw7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcsIGJ1ZjogUnVuQnVmZmVyKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGFsbFtoYW5kbGVdID0gYnVmO1xyXG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBkZWxldGUgYWxsW2hhbmRsZV07XHJcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcclxufVxyXG5cclxuLy8gLS0tIEFjdGl2aXR5IHRhaWwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY3Rpdml0eSgpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhY3Rpdml0eScpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwZW5kQWN0aXZpdHkoZXY6IExvZ0V2ZW50KTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XHJcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0QWN0aXZpdHkoKTtcclxuICBjdXIudW5zaGlmdChldik7XHJcbiAgaWYgKGN1ci5sZW5ndGggPiBBQ1RJVklUWV9UQUlMX01BWCkgY3VyLmxlbmd0aCA9IEFDVElWSVRZX1RBSUxfTUFYO1xyXG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBjdXIpO1xyXG4gIHJldHVybiBjdXI7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBbXSk7XHJcbn1cclxuXHJcbi8vIC0tLSBDb21taXR0ZWQtdHdlZXRzIGRlZHVwIGluZGV4IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb21taXR0ZWRJbmRleCgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdjb21taXR0ZWRJbmRleCcpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29tbWl0dGVkSW5kZXgoXHJcbiAgaWR4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+XHJcbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnY29tbWl0dGVkSW5kZXgnLCBpZHgpO1xyXG59XHJcblxyXG4vKiogQ29tcHV0ZSB0aGUgZW5nYWdlbWVudCBzaWduYXR1cmUgd2UgdXNlIHRvIGRlY2lkZSB3aGV0aGVyIGEgcmUtY2FwdHVyZWRcclxuICogdHdlZXQgaXMgXCJtYXRlcmlhbGx5IGRpZmZlcmVudFwiIGZyb20gd2hhdCB3ZSBsYXN0IGNvbW1pdHRlZC4gV2Ugb21pdFxyXG4gKiB2aWV3X2NvdW50IGJlY2F1c2UgaXQgdGlja3MgdXAgZnJlcXVlbnRseSBvbiBhY3RpdmUgdHdlZXRzIGFuZCB3b3VsZFxyXG4gKiBkZWZlYXQgdGhlIGRlZHVwLiBMaWtlcyAvIFJUcyAvIHJlcGxpZXMgLyBxdW90ZXMgY2hhbmdlIHJhcmVseSBlbm91Z2ggdGhhdFxyXG4gKiBlYWNoIGNoYW5nZSBpcyB3b3J0aCBhIHJlLWNvbW1pdCAoYW5kIGFuIGVuZ2FnZW1lbnRfaGlzdG9yeSBzbmFwc2hvdCkuXHJcbiAqIGBpc190cnVuY2F0ZWRgIGlzIGZvbGRlZCBpbiBzbyBhIHJlZmV0Y2ggdGhhdCBzd2FwcyB0aGUgMjgwLWNoYXIgaGVhZCBmb3JcclxuICogdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkgYnlwYXNzZXMgdGhlIGRlZHVwIGV2ZW4gd2hlbiBlbmdhZ2VtZW50IGNvdW50c1xyXG4gKiBoYXZlbid0IG1vdmVkIFx1MjAxNCBvdGhlcndpc2UgdGhlIG5ldyBib2R5IHdvdWxkIGJlIHNpbGVudGx5IGRyb3BwZWQuICovXHJcbmV4cG9ydCBmdW5jdGlvbiBlbmdhZ2VtZW50U2lnKFxyXG4gIGxpa2VzOiBudW1iZXIsXHJcbiAgcmV0d2VldHM6IG51bWJlcixcclxuICByZXBsaWVzOiBudW1iZXIsXHJcbiAgcXVvdGVzOiBudW1iZXIsXHJcbiAgaXNUcnVuY2F0ZWQ6IGJvb2xlYW4gPSBmYWxzZVxyXG4pOiBzdHJpbmcge1xyXG4gIHJldHVybiBgJHtsaWtlc318JHtyZXR3ZWV0c318JHtyZXBsaWVzfXwke3F1b3Rlc318JHtpc1RydW5jYXRlZCA/ICd0JyA6ICdmJ31gO1xyXG59XHJcblxyXG4vKiogRHJvcCBlbnRyaWVzIG9sZGVyIHRoYW4gYG1heEFnZU1zYC4gUmV0dXJucyB0aGUgbnVtYmVyIHBydW5lZC4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBydW5lQ29tbWl0dGVkSW5kZXgobWF4QWdlTXM6IG51bWJlcik6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBjb25zdCBjdXRvZmYgPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gbWF4QWdlTXMpLnRvSVNPU3RyaW5nKCk7XHJcbiAgbGV0IHBydW5lZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoYW5kbGUgb2YgT2JqZWN0LmtleXMoaWR4KSkge1xyXG4gICAgY29uc3QgaW5uZXIgPSBpZHhbaGFuZGxlXTtcclxuICAgIGlmICghaW5uZXIpIGNvbnRpbnVlO1xyXG4gICAgZm9yIChjb25zdCB0aWQgb2YgT2JqZWN0LmtleXMoaW5uZXIpKSB7XHJcbiAgICAgIGNvbnN0IGUgPSBpbm5lclt0aWRdO1xyXG4gICAgICBpZiAoZSAmJiBlLnRzIDwgY3V0b2ZmKSB7XHJcbiAgICAgICAgZGVsZXRlIGlubmVyW3RpZF07XHJcbiAgICAgICAgcHJ1bmVkICs9IDE7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmIChPYmplY3Qua2V5cyhpbm5lcikubGVuZ3RoID09PSAwKSBkZWxldGUgaWR4W2hhbmRsZV07XHJcbiAgfVxyXG4gIGlmIChwcnVuZWQgPiAwKSBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xyXG4gIHJldHVybiBwcnVuZWQ7XHJcbn1cclxuXHJcbi8vIC0tLSBSZWZldGNoIHF1ZXVlICh0d2VldHMgbmVlZGluZyBmdWxsLXRleHQgcmVjYXB0dXJlKSAtLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hRdWV1ZSgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hRdWV1ZScpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgbGV0IHRvdGFsID0gMDtcclxuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xyXG4gIHJldHVybiB0b3RhbDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVSZWZldGNoKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xyXG4gIGlmICghaWRzLmluY2x1ZGVzKHR3ZWV0SWQpKSB7XHJcbiAgICBpZHMucHVzaCh0d2VldElkKTtcclxuICAgIHFbaGFuZGxlXSA9IGlkcztcclxuICAgIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBjb25zdCBpZHMgPSBxW2hhbmRsZV07XHJcbiAgaWYgKCFpZHMpIHJldHVybjtcclxuICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XHJcbiAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbaGFuZGxlXTtcclxuICBlbHNlIHFbaGFuZGxlXSA9IGZpbHRlcmVkO1xyXG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0UmVmZXRjaFRhcmdldCgpOiBQcm9taXNlPHtcclxuICBoYW5kbGU6IHN0cmluZztcclxuICB0d2VldElkOiBzdHJpbmc7XHJcbn0gfCBudWxsPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xyXG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBoYW5kbGUsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbi8vIC0tLSBNZWRpYS1jcmF3bCBxdWV1ZSAocGFydGlhbCBjYXB0dXJlcyBhd2FpdGluZyBkZXRhaWwtcGFnZSBmZXRjaCkgLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xRdWV1ZSgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgbGV0IHRvdGFsID0gMDtcclxuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xyXG4gIHJldHVybiB0b3RhbDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVNZWRpYUNyYXdsKGhpbnRIYW5kbGU6IHN0cmluZyB8IG51bGwsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBjb25zdCBidWNrZXQgPSBoaW50SGFuZGxlID8/ICdfdW5rbm93bic7XHJcbiAgY29uc3QgaWRzID0gcVtidWNrZXRdID8/IFtdO1xyXG4gIGlmICghaWRzLmluY2x1ZGVzKHR3ZWV0SWQpKSB7XHJcbiAgICBpZHMucHVzaCh0d2VldElkKTtcclxuICAgIHFbYnVja2V0XSA9IGlkcztcclxuICAgIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgcSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZU1lZGlhQ3Jhd2wodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGxldCBjaGFuZ2VkID0gZmFsc2U7XHJcbiAgZm9yIChjb25zdCBidWNrZXQgb2YgT2JqZWN0LmtleXMocSkpIHtcclxuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcclxuICAgIGlmICghaWRzKSBjb250aW51ZTtcclxuICAgIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcclxuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcclxuICAgICAgY2hhbmdlZCA9IHRydWU7XHJcbiAgICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2J1Y2tldF07XHJcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTogUHJvbWlzZTx7XHJcbiAgYnVja2V0OiBzdHJpbmc7XHJcbiAgdHdlZXRJZDogc3RyaW5nO1xyXG59IHwgbnVsbD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBmb3IgKGNvbnN0IFtidWNrZXQsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcclxuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgYnVja2V0LCB0d2VldElkOiBpZHNbMF0hIH07XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcblxyXG4vKiogSGFzIHRoaXMgdHdlZXQgaWQgYWxyZWFkeSBiZWVuIGNvbW1pdHRlZCAoYW55IGhhbmRsZSk/IFVzZWQgdG8gc2tpcFxyXG4gKiBlbnF1ZXVlaW5nIG1lZGlhLWNyYXdsIHRhcmdldHMgd2UndmUgYWxyZWFkeSBhcmNoaXZlZC4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGlzQ29tbWl0dGVkKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xyXG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgZm9yIChjb25zdCBpbm5lciBvZiBPYmplY3QudmFsdWVzKGlkeCkpIHtcclxuICAgIGlmIChpbm5lciAmJiB0d2VldElkIGluIGlubmVyKSByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbiAgcmV0dXJuIGZhbHNlO1xyXG59XHJcblxyXG4vLyAtLS0gTG9vcCBzZXNzaW9uIHN0YXRlIChwcm9ncmVzcyArIGluZmxpZ2h0IGdhdGluZykgLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoU2Vzc2lvbicpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSZWZldGNoU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJywgcyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicsIHMpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpOiBQcm9taXNlPEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEF1dG9TY3JvbGxTZXNzaW9uKHM6IEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nLCBzKTtcclxufVxyXG5cclxuLy8gLS0tIFB1cmdlOiB1bnJlbGF0ZWQgYnVmZmVycywgY291bnRlcnMsIHF1ZXVlIGVudHJpZXMgLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuLyoqXHJcbiAqIERyb3AgZXZlcnkgcGVyLWhhbmRsZSBiaXQgb2Ygc3RhdGUgKGNvdW50ZXJzLCBydW4gYnVmZmVyLCBjb21taXR0ZWQtaW5kZXhcclxuICogZW50cmllcywgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHF1ZXVlIGVudHJpZXMpIHRoYXQgZG9lc24ndCBjb3JyZXNwb25kIHRvIGFcclxuICogdHJhY2tlZCBhY2NvdW50LiBSZXR1cm5zIGEgc3VtbWFyeSBkZXNjcmliaW5nIHdoYXQgd2FzIGNsZWFyZWQgc28gdGhlXHJcbiAqIGNhbGxlciBjYW4gbG9nIGl0LlxyXG4gKlxyXG4gKiBUcmFja2VkIGFjY291bnRzIGFyZSBwYXNzZWQgaW4gKGNhbGxlciByZXNvbHZlcyBmcm9tIHRoZSBsaXZlIGNvbmZpZykuXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHVyZ2VVbnJlbGF0ZWRTdGF0ZSh0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPik6IFByb21pc2U8e1xyXG4gIGNvdW50ZXJzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIGJ1ZmZlcnNSZW1vdmVkOiBudW1iZXI7XHJcbiAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQ6IG51bWJlcjtcclxuICByZWZldGNoSGFuZGxlc1JlbW92ZWQ6IG51bWJlcjtcclxuICBtZWRpYUNyYXdsSWRzUmVtb3ZlZDogbnVtYmVyO1xyXG59PiB7XHJcbiAgY29uc3QgdGFyZ0xvd2VyID0gbmV3IFNldChbLi4udGFyZ2V0ZWRdLm1hcCgoaCkgPT4gaC50b0xvd2VyQ2FzZSgpKSk7XHJcbiAgY29uc3QgaXNUYXJnZXRlZCA9IChoOiBzdHJpbmcpOiBib29sZWFuID0+IHRhcmdMb3dlci5oYXMoaC50b0xvd2VyQ2FzZSgpKTtcclxuXHJcbiAgLy8gQ291bnRlcnNcclxuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XHJcbiAgbGV0IGNvdW50ZXJzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGNvdW50ZXJzKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIGRlbGV0ZSBjb3VudGVyc1toXTtcclxuICAgICAgY291bnRlcnNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygnY291bnRlcnMnLCBjb3VudGVycyk7XHJcblxyXG4gIC8vIFJ1biBidWZmZXJzXHJcbiAgY29uc3QgYnVmZmVycyA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBsZXQgYnVmZmVyc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhidWZmZXJzKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIGRlbGV0ZSBidWZmZXJzW2hdO1xyXG4gICAgICBidWZmZXJzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBidWZmZXJzKTtcclxuXHJcbiAgLy8gQ29tbWl0dGVkIGRlZHVwIGluZGV4XHJcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBsZXQgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGlkeFtoXTtcclxuICAgICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcclxuXHJcbiAgLy8gUmVmZXRjaCBxdWV1ZTogYnVja2V0cyBhcmUga2V5ZWQgYnkgaGFuZGxlLlxyXG4gIGNvbnN0IHJxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgbGV0IHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKHJxKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIGRlbGV0ZSBycVtoXTtcclxuICAgICAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcnEpO1xyXG5cclxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogYnVja2V0cyBhcmUgaGludC1oYW5kbGVzIChvciBcIl91bmtub3duXCIpLiBEcm9wXHJcbiAgLy8gZW50cmllcyB3aG9zZSBidWNrZXQgaXNuJ3QgdGFyZ2V0ZWQgXHUyMDE0IGluY2x1ZGluZyBcIl91bmtub3duXCIgc2luY2Ugd2VcclxuICAvLyBjYW4ndCB2ZXJpZnkgcmVsYXRpb24uXHJcbiAgY29uc3QgbXEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBsZXQgbWVkaWFDcmF3bElkc1JlbW92ZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhtcSkpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBtZWRpYUNyYXdsSWRzUmVtb3ZlZCArPSAobXFbaF0gPz8gW10pLmxlbmd0aDtcclxuICAgICAgZGVsZXRlIG1xW2hdO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIG1xKTtcclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIGNvdW50ZXJzUmVtb3ZlZCxcclxuICAgIGJ1ZmZlcnNSZW1vdmVkLFxyXG4gICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQsXHJcbiAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQsXHJcbiAgICBtZWRpYUNyYXdsSWRzUmVtb3ZlZCxcclxuICB9O1xyXG59XHJcblxyXG4vLyAtLS0gRnVsbCByZXNldCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJBbGwoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmNsZWFyKCk7XHJcbn1cclxuIiwgImltcG9ydCB7IGFwcGVuZEFjdGl2aXR5IH0gZnJvbSAnLi9zdG9yYWdlLmpzJztcclxuaW1wb3J0IHR5cGUgeyBMb2dFdmVudCwgTG9nTGV2ZWwgfSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbmxldCBicm9hZGNhc3Q6ICgoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKSB8IG51bGwgPSBudWxsO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNldEJyb2FkY2FzdGVyKGZuOiAoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKTogdm9pZCB7XHJcbiAgYnJvYWRjYXN0ID0gZm47XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG5vd0lTTygpOiBzdHJpbmcge1xyXG4gIHJldHVybiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGVtaXQobGV2ZWw6IExvZ0xldmVsLCBtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBldjogTG9nRXZlbnQgPSB7IHRzOiBub3dJU08oKSwgbGV2ZWwsIG1zZywgY29udGV4dDogcmVkYWN0KGNvbnRleHQpIH07XHJcbiAgLy8gQ29uc29sZSBmb3IgZGV2dG9vbHMuXHJcbiAgY29uc3QgbGluZSA9IGBbaW1tLWFyY2hpdmVdICR7bGV2ZWwudG9VcHBlckNhc2UoKX0gJHttc2d9YDtcclxuICBpZiAobGV2ZWwgPT09ICdlcnJvcicpIGNvbnNvbGUuZXJyb3IobGluZSwgZXYuY29udGV4dCk7XHJcbiAgZWxzZSBpZiAobGV2ZWwgPT09ICd3YXJuJykgY29uc29sZS53YXJuKGxpbmUsIGV2LmNvbnRleHQpO1xyXG4gIGVsc2UgY29uc29sZS5sb2cobGluZSwgZXYuY29udGV4dCk7XHJcbiAgLy8gUGVyc2lzdGVudCB0YWlsLlxyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBhcHBlbmRBY3Rpdml0eShldik7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gZmFpbGVkIHRvIGFwcGVuZCBhY3Rpdml0eScsIGVycik7XHJcbiAgfVxyXG4gIC8vIExpdmUgYnJvYWRjYXN0IChlLmcuIHRvIHNpZGViYXIpLlxyXG4gIHRyeSB7XHJcbiAgICBicm9hZGNhc3Q/Lihldik7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyBTaWRlYmFyIG1heSBub3QgYmUgb3BlbjsgdGhhdCdzIGZpbmUuXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaW5mbyhtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHJldHVybiBlbWl0KCdpbmZvJywgbXNnLCBjb250ZXh0KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gd2Fybihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHJldHVybiBlbWl0KCd3YXJuJywgbXNnLCBjb250ZXh0KTtcclxufVxyXG5leHBvcnQgZnVuY3Rpb24gZXJyb3IobXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge30pOiBQcm9taXNlPHZvaWQ+IHtcclxuICByZXR1cm4gZW1pdCgnZXJyb3InLCBtc2csIGNvbnRleHQpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmVFcnJvcihlcnI6IHVua25vd24pOiB7IG1lc3NhZ2U6IHN0cmluZzsgc3RhY2s6IHN0cmluZyB8IG51bGwgfSB7XHJcbiAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XHJcbiAgICByZXR1cm4geyBtZXNzYWdlOiBlcnIubWVzc2FnZSwgc3RhY2s6IGVyci5zdGFjayA/PyBudWxsIH07XHJcbiAgfVxyXG4gIHRyeSB7XHJcbiAgICByZXR1cm4geyBtZXNzYWdlOiBTdHJpbmcoZXJyKSwgc3RhY2s6IG51bGwgfTtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiB7IG1lc3NhZ2U6ICc8dW5wcmludGFibGUgZXJyb3I+Jywgc3RhY2s6IG51bGwgfTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBTdHJpcCBhbnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSBQQVQgb3Igb3RoZXIgbG9uZyBzZWNyZXQgZnJvbSBhIGNvbnRleHRcclxuICogb2JqZWN0IGJlZm9yZSBwZXJzaXN0aW5nIGl0LiBEZWZlbnNpdmU6IGNhbGxlcnMgc2hvdWxkIG5vdCBsb2cgdG9rZW5zLCBidXRcclxuICogaWYgdGhleSBzbGlwIHRocm91Z2ggd2Ugd2FudCB0byByZWRhY3QgdGhlbS5cclxuICovXHJcbmZ1bmN0aW9uIHJlZGFjdChjdHg6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xyXG4gIGNvbnN0IG91dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcclxuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhjdHgpKSB7XHJcbiAgICBpZiAoay50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCd0b2tlbicpIHx8IGsudG9Mb3dlckNhc2UoKSA9PT0gJ3BhdCcgfHwgayA9PT0gJ2F1dGhvcml6YXRpb24nKSB7XHJcbiAgICAgIG91dFtrXSA9ICc8cmVkYWN0ZWQ+JztcclxuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIC9naXRodWJfcGF0X1tBLVphLXowLTlfXXszMCx9Ly50ZXN0KHYpKSB7XHJcbiAgICAgIG91dFtrXSA9IHYucmVwbGFjZSgvZ2l0aHViX3BhdF9bQS1aYS16MC05X10rL2csICdnaXRodWJfcGF0XzxyZWRhY3RlZD4nKTtcclxuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gNDA5Nikge1xyXG4gICAgICBvdXRba10gPSBgJHt2LnNsaWNlKDAsIDQwOTYpfVx1MjAyNjx0cnVuY2F0ZWQ+YDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG91dFtrXSA9IHY7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBvdXQ7XHJcbn1cclxuIiwgImltcG9ydCB7IGRlc2NyaWJlRXJyb3IgfSBmcm9tICcuL2xvZ2dlci5qcyc7XHJcbmltcG9ydCB0eXBlIHsgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbmNvbnN0IEFQSV9CQVNFID0gJ2h0dHBzOi8vYXBpLmdpdGh1Yi5jb20nO1xyXG5jb25zdCBSQVdfQkFTRSA9ICdodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20nO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBQdXRGaWxlT3B0aW9ucyB7XHJcbiAgcGF0aDogc3RyaW5nO1xyXG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcclxuICBtZXNzYWdlOiBzdHJpbmc7XHJcbiAgZXhwZWN0ZWRTaGE/OiBzdHJpbmcgfCBudWxsO1xyXG59XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFB1dEZpbGVSZXN1bHQge1xyXG4gIHBhdGg6IHN0cmluZztcclxuICBzaGE6IHN0cmluZztcclxuICB1cmw6IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlT3B0aW9ucyB7XHJcbiAgcGF0aDogc3RyaW5nO1xyXG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlc09wdGlvbnMge1xyXG4gIGZpbGVzOiBDb21taXRGaWxlT3B0aW9uc1tdO1xyXG4gIG1lc3NhZ2U6IHN0cmluZztcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlc1Jlc3VsdCB7XHJcbiAgY29tbWl0U2hhOiBzdHJpbmc7XHJcbiAgdXJsOiBzdHJpbmc7XHJcbiAgZmlsZXM6IHN0cmluZ1tdO1xyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgR2l0SHViRXJyb3IgZXh0ZW5kcyBFcnJvciB7XHJcbiAgc3RhdHVzOiBudW1iZXI7XHJcbiAgYm9keTogdW5rbm93bjtcclxuICByZXRyaWFibGU6IGJvb2xlYW47XHJcbiAgY2F0ZWdvcnk6ICdhdXRoJyB8ICdyYXRlLWxpbWl0JyB8ICdjb25mbGljdCcgfCAnbm90LWZvdW5kJyB8ICdzZXJ2ZXInIHwgJ25ldHdvcmsnIHwgJ3Vua25vd24nO1xyXG4gIC8qKiBXaGVuIHRoZSBHaXRIdWIgcmF0ZS1saW1pdCB3aW5kb3cgZm9yIHRoaXMgdG9rZW4gcmVzZXRzLCBhcyBhIFVuaXhcclxuICAgKiBlcG9jaCBpbiBzZWNvbmRzLiBQb3B1bGF0ZWQgZnJvbSBgWC1SYXRlTGltaXQtUmVzZXRgIG9uIDQwMy80MjksIG9yXHJcbiAgICogZGVyaXZlZCBmcm9tIGBSZXRyeS1BZnRlcmAgZm9yIHNlY29uZGFyeSBsaW1pdHMuIG51bGwgd2hlbiB1bmtub3duLiAqL1xyXG4gIHJhdGVMaW1pdFJlc2V0QXQ6IG51bWJlciB8IG51bGw7XHJcblxyXG4gIGNvbnN0cnVjdG9yKG9wdHM6IHtcclxuICAgIHN0YXR1czogbnVtYmVyO1xyXG4gICAgYm9keTogdW5rbm93bjtcclxuICAgIG1lc3NhZ2U6IHN0cmluZztcclxuICAgIHJldHJpYWJsZTogYm9vbGVhbjtcclxuICAgIGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXTtcclxuICAgIHJhdGVMaW1pdFJlc2V0QXQ/OiBudW1iZXIgfCBudWxsO1xyXG4gIH0pIHtcclxuICAgIHN1cGVyKG9wdHMubWVzc2FnZSk7XHJcbiAgICB0aGlzLm5hbWUgPSAnR2l0SHViRXJyb3InO1xyXG4gICAgdGhpcy5zdGF0dXMgPSBvcHRzLnN0YXR1cztcclxuICAgIHRoaXMuYm9keSA9IG9wdHMuYm9keTtcclxuICAgIHRoaXMucmV0cmlhYmxlID0gb3B0cy5yZXRyaWFibGU7XHJcbiAgICB0aGlzLmNhdGVnb3J5ID0gb3B0cy5jYXRlZ29yeTtcclxuICAgIHRoaXMucmF0ZUxpbWl0UmVzZXRBdCA9IG9wdHMucmF0ZUxpbWl0UmVzZXRBdCA/PyBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEdpdEh1YkNsaWVudCB7XHJcbiAgcHJpdmF0ZSByZWFkb25seSBzZXR0aW5nczogU2V0dGluZ3M7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHNldHRpbmdzOiBTZXR0aW5ncykge1xyXG4gICAgdGhpcy5zZXR0aW5ncyA9IHNldHRpbmdzO1xyXG4gIH1cclxuXHJcbiAgLyoqIFJldHVybnMgdGhlIGF1dGhlbnRpY2F0ZWQgdXNlcidzIGxvZ2luLiBUaHJvd3Mgb24gYXV0aCBmYWlsdXJlLiAqL1xyXG4gIGFzeW5jIHdob2FtaSgpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsICcvdXNlcicpO1xyXG4gICAgcmV0dXJuIChyZXMgYXMgeyBsb2dpbj86IHN0cmluZyB9KS5sb2dpbiA/PyAnPHVua25vd24+JztcclxuICB9XHJcblxyXG4gIC8qKiBSZXR1cm5zIHRydWUgaWYgdGhlIGdpdmVuIGJyYW5jaCBleGlzdHMgb24gdGhlIGNvbmZpZ3VyZWQgcmVwby4gKi9cclxuICBhc3luYyBicmFuY2hFeGlzdHMoYnJhbmNoOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICdHRVQnLFxyXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vYnJhbmNoZXMvJHtlbmNvZGVVUklDb21wb25lbnQoYnJhbmNoKX1gXHJcbiAgICAgICk7XHJcbiAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gZmFsc2U7XHJcbiAgICAgIHRocm93IGVycjtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKiBWZXJpZmllcyB0aGUgUEFUIGNhbiBzZWUgdGhlIGNvbmZpZ3VyZWQgcmVwby4gKi9cclxuICBhc3luYyB2ZXJpZnlSZXBvQWNjZXNzKCk6IFByb21pc2U8eyBsb2dpbjogc3RyaW5nOyBmdWxsX25hbWU6IHN0cmluZzsgZGVmYXVsdF9icmFuY2g6IHN0cmluZyB9PiB7XHJcbiAgICBjb25zdCBtZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcclxuICAgIGNvbnN0IHJlcG8gPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfWApO1xyXG4gICAgY29uc3QgciA9IHJlcG8gYXMgeyBmdWxsX25hbWU6IHN0cmluZzsgZGVmYXVsdF9icmFuY2g6IHN0cmluZyB9O1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgbG9naW46IChtZSBhcyB7IGxvZ2luOiBzdHJpbmcgfSkubG9naW4sXHJcbiAgICAgIGZ1bGxfbmFtZTogci5mdWxsX25hbWUsXHJcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEZldGNoIGEgdGV4dCBmaWxlIGZyb20gcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSBhdXRoZW50aWNhdGVkIHdpdGggdGhlXHJcbiAgICogUEFULiBSZXR1cm5zIG51bGwgaWYgdGhlIGZpbGUgZG9lc24ndCBleGlzdC4gVXNlZCBmb3IgY29uZmlnL2FjY291bnRzLnlhbWwuXHJcbiAgICovXHJcbiAgYXN5bmMgZmV0Y2hSYXdUZXh0KHBhdGhJblJlcG86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xyXG4gICAgY29uc3QgdXJsID0gYCR7UkFXX0JBU0V9LyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99LyR7dGhpcy5zZXR0aW5ncy5icmFuY2h9LyR7cGF0aEluUmVwb31gO1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsLCB7XHJcbiAgICAgIG1ldGhvZDogJ0dFVCcsXHJcbiAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAgfSxcclxuICAgIH0pO1xyXG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkgcmV0dXJuIG51bGw7XHJcbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3IocmVzLCBgR0VUIHJhdyAke3BhdGhJblJlcG99YCk7XHJcbiAgICByZXR1cm4gcmVzLnRleHQoKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIExvb2sgdXAgYW4gZXhpc3RpbmcgZmlsZSdzIFNIQSB2aWEgdGhlIENvbnRlbnRzIEFQSSwgb3IgbnVsbCBpZiBub3QgZm91bmQuXHJcbiAgICogVXNlZCB3aGVuIHJldHJ5aW5nIGEgUFVUIGFmdGVyIGEgNDIyIHNoYSBtaXNtYXRjaC5cclxuICAgKi9cclxuICBhc3luYyBnZXRGaWxlU2hhKHBhdGg6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXHJcbiAgICAgICAgJ0dFVCcsXHJcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9P3JlZj0ke2VuY29kZVVSSUNvbXBvbmVudCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCByID0gcmVzIGFzIHsgc2hhPzogc3RyaW5nIH07XHJcbiAgICAgIHJldHVybiByLnNoYSA/PyBudWxsO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gbnVsbDtcclxuICAgICAgdGhyb3cgZXJyO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUFVUIGEgZmlsZSB0byB0aGUgcmVwby4gSGFuZGxlcyA0MjIgKHNoYSByZXF1aXJlZCkgYnkgcmUtZmV0Y2hpbmcgdGhlXHJcbiAgICogZXhpc3Rpbmcgc2hhIGFuZCByZXRyeWluZyBvbmNlLiBSZXRyaWVzIG5ldHdvcmsgLyA1eHggLyByYXRlLWxpbWl0IGVycm9yc1xyXG4gICAqIHdpdGggZXhwb25lbnRpYWwgYmFja29mZiB1cCB0byBtYXhBdHRlbXB0cy5cclxuICAgKi9cclxuICBhc3luYyBwdXRGaWxlKG9wdHM6IFB1dEZpbGVPcHRpb25zKTogUHJvbWlzZTxQdXRGaWxlUmVzdWx0PiB7XHJcbiAgICBjb25zdCBwYXRoID0gb3B0cy5wYXRoO1xyXG4gICAgY29uc3QgdXJsID0gYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9YDtcclxuICAgIGxldCBzaGE6IHN0cmluZyB8IG51bGwgPSBvcHRzLmV4cGVjdGVkU2hhID8/IG51bGw7XHJcbiAgICBjb25zdCBtYXhBdHRlbXB0cyA9IDU7XHJcblxyXG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDE7IGF0dGVtcHQgPD0gbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xyXG4gICAgICBjb25zdCBib2R5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHtcclxuICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXHJcbiAgICAgICAgY29udGVudDogb3B0cy5jb250ZW50QmFzZTY0LFxyXG4gICAgICAgIGJyYW5jaDogdGhpcy5zZXR0aW5ncy5icmFuY2gsXHJcbiAgICAgIH07XHJcbiAgICAgIGlmIChzaGEpIGJvZHkuc2hhID0gc2hhO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdQVVQnLCB1cmwsIGJvZHkpO1xyXG4gICAgICAgIGNvbnN0IG91dCA9IHJlcyBhcyB7IGNvbnRlbnQ6IHsgc2hhOiBzdHJpbmc7IGh0bWxfdXJsOiBzdHJpbmc7IHBhdGg6IHN0cmluZyB9IH07XHJcbiAgICAgICAgcmV0dXJuIHsgcGF0aDogb3V0LmNvbnRlbnQucGF0aCwgc2hhOiBvdXQuY29udGVudC5zaGEsIHVybDogb3V0LmNvbnRlbnQuaHRtbF91cmwgfTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgaWYgKGVyci5zdGF0dXMgPT09IDQyMiAmJiAhc2hhKSB7XHJcbiAgICAgICAgICAvLyBGaWxlIGFscmVhZHkgZXhpc3RzOyBmZXRjaCBpdHMgc2hhIGFuZCByZXRyeSBvbmNlLlxyXG4gICAgICAgICAgc2hhID0gYXdhaXQgdGhpcy5nZXRGaWxlU2hhKHBhdGgpO1xyXG4gICAgICAgICAgaWYgKCFzaGEpIHRocm93IGVycjtcclxuICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIWVyci5yZXRyaWFibGUgfHwgYXR0ZW1wdCA9PT0gbWF4QXR0ZW1wdHMpIHRocm93IGVycjtcclxuICAgICAgICBhd2FpdCBzbGVlcChiYWNrb2ZmTXMoYXR0ZW1wdCwgZXJyKSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHRocm93IG5ldyBFcnJvcihgcHV0RmlsZTogZXhoYXVzdGVkIGF0dGVtcHRzIGZvciAke3BhdGh9YCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDb21taXQgc2V2ZXJhbCBmaWxlcyB3aXRoIG9uZSBicmFuY2ggdXBkYXRlLiBUaGUgQ29udGVudHMgQVBJIGNyZWF0ZXMgb25lXHJcbiAgICogY29tbWl0IHBlciBQVVQsIHNvIHJhcGlkIGZsdXNoZXMgcmFjZSBlYWNoIG90aGVyIG9uIHRoZSBicmFuY2ggaGVhZC4gVGhpc1xyXG4gICAqIHVzZXMgdGhlIGxvd2VyLWxldmVsIEdpdCBEYXRhIEFQSSBpbnN0ZWFkOiB1cGxvYWQgYmxvYnMsIGJ1aWxkIGEgdHJlZSxcclxuICAgKiBjcmVhdGUgb25lIGNvbW1pdCwgdGhlbiBtb3ZlIHRoZSBicmFuY2ggcmVmIG9uY2UuIElmIGFub3RoZXIgd3JpdGVyIG1vdmVzXHJcbiAgICogdGhlIGJyYW5jaCBmaXJzdCwgcmViYXNlIHRoaXMgdHJlZSBwYXRjaCBvbnRvIHRoZSBsYXRlc3QgaGVhZCBhbmQgcmV0cnkuXHJcbiAgICovXHJcbiAgYXN5bmMgY29tbWl0RmlsZXMob3B0czogQ29tbWl0RmlsZXNPcHRpb25zKTogUHJvbWlzZTxDb21taXRGaWxlc1Jlc3VsdD4ge1xyXG4gICAgaWYgKG9wdHMuZmlsZXMubGVuZ3RoID09PSAwKSB0aHJvdyBuZXcgRXJyb3IoJ2NvbW1pdEZpbGVzOiBubyBmaWxlcyB0byBjb21taXQnKTtcclxuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcclxuICAgIGxldCBsYXN0RXJyOiB1bmtub3duID0gbnVsbDtcclxuXHJcbiAgICBmb3IgKGxldCBhdHRlbXB0ID0gMTsgYXR0ZW1wdCA8PSBtYXhBdHRlbXB0czsgYXR0ZW1wdCsrKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgYmxvYnMgPSBhd2FpdCBQcm9taXNlLmFsbChcclxuICAgICAgICAgIG9wdHMuZmlsZXMubWFwKGFzeW5jIChmaWxlKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IG91dCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICAgICAgICdQT1NUJyxcclxuICAgICAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9ibG9ic2AsXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgY29udGVudDogZmlsZS5jb250ZW50QmFzZTY0LFxyXG4gICAgICAgICAgICAgICAgZW5jb2Rpbmc6ICdiYXNlNjQnLFxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBwYXRoOiBmaWxlLnBhdGgsXHJcbiAgICAgICAgICAgICAgc2hhOiAob3V0IGFzIHsgc2hhOiBzdHJpbmcgfSkuc2hhLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfSlcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XHJcbiAgICAgICAgY29uc3QgdHJlZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICAgJ1BPU1QnLFxyXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvdHJlZXNgLFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBiYXNlX3RyZWU6IGhlYWQudHJlZVNoYSxcclxuICAgICAgICAgICAgdHJlZTogYmxvYnMubWFwKChibG9iKSA9PiAoe1xyXG4gICAgICAgICAgICAgIHBhdGg6IGJsb2IucGF0aCxcclxuICAgICAgICAgICAgICBtb2RlOiAnMTAwNjQ0JyxcclxuICAgICAgICAgICAgICB0eXBlOiAnYmxvYicsXHJcbiAgICAgICAgICAgICAgc2hhOiBibG9iLnNoYSxcclxuICAgICAgICAgICAgfSkpLFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgY29uc3QgdHJlZVNoYSA9ICh0cmVlIGFzIHsgc2hhOiBzdHJpbmcgfSkuc2hhO1xyXG4gICAgICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICAgJ1BPU1QnLFxyXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvY29tbWl0c2AsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IG9wdHMubWVzc2FnZSxcclxuICAgICAgICAgICAgdHJlZTogdHJlZVNoYSxcclxuICAgICAgICAgICAgcGFyZW50czogW2hlYWQuc2hhXSxcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IGNvbW1pdE91dCA9IGNvbW1pdCBhcyB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nIH07XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICAgICAnUEFUQ0gnLFxyXG4gICAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9yZWZzL2hlYWRzLyR7ZW5jb2RlUGF0aCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIHNoYTogY29tbWl0T3V0LnNoYSxcclxuICAgICAgICAgICAgICBmb3JjZTogZmFsc2UsXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICBpZiAoaXNDb25mbGljdChlcnIpICYmIGF0dGVtcHQgPCBtYXhBdHRlbXB0cykge1xyXG4gICAgICAgICAgICBsYXN0RXJyID0gZXJyO1xyXG4gICAgICAgICAgICBhd2FpdCBzbGVlcChiYWNrb2ZmTXMoYXR0ZW1wdCwgZXJyKSk7XHJcbiAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGhyb3cgZXJyO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgY29tbWl0U2hhOiBjb21taXRPdXQuc2hhLFxyXG4gICAgICAgICAgdXJsOiBjb21taXRPdXQuaHRtbF91cmwsXHJcbiAgICAgICAgICBmaWxlczogb3B0cy5maWxlcy5tYXAoKGZpbGUpID0+IGZpbGUucGF0aCksXHJcbiAgICAgICAgfTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgbGFzdEVyciA9IGVycjtcclxuICAgICAgICBpZiAoIShlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvcikpIHRocm93IGVycjtcclxuICAgICAgICBpZiAoKCFlcnIucmV0cmlhYmxlICYmICFpc0NvbmZsaWN0KGVycikpIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB0aHJvdyBsYXN0RXJyIGluc3RhbmNlb2YgRXJyb3IgPyBsYXN0RXJyIDogbmV3IEVycm9yKCdjb21taXRGaWxlczogZXhoYXVzdGVkIGF0dGVtcHRzJyk7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGFzeW5jIGdldEJyYW5jaEhlYWQoKTogUHJvbWlzZTx7IHNoYTogc3RyaW5nOyB0cmVlU2hhOiBzdHJpbmcgfT4ge1xyXG4gICAgY29uc3QgcmVmID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXHJcbiAgICAgICdHRVQnLFxyXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9yZWYvaGVhZHMvJHtlbmNvZGVQYXRoKHRoaXMuc2V0dGluZ3MuYnJhbmNoKX1gXHJcbiAgICApO1xyXG4gICAgY29uc3QgaGVhZFNoYSA9IChyZWYgYXMgeyBvYmplY3Q6IHsgc2hhOiBzdHJpbmcgfSB9KS5vYmplY3Quc2hhO1xyXG4gICAgY29uc3QgY29tbWl0ID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXHJcbiAgICAgICdHRVQnLFxyXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9jb21taXRzLyR7aGVhZFNoYX1gXHJcbiAgICApO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc2hhOiBoZWFkU2hhLFxyXG4gICAgICB0cmVlU2hhOiAoY29tbWl0IGFzIHsgdHJlZTogeyBzaGE6IHN0cmluZyB9IH0pLnRyZWUuc2hhLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgYXN5bmMgZmV0Y2hKc29uKG1ldGhvZDogc3RyaW5nLCBwYXRoOiBzdHJpbmcsIGJvZHk/OiB1bmtub3duKTogUHJvbWlzZTx1bmtub3duPiB7XHJcbiAgICBjb25zdCB1cmwgPSBwYXRoLnN0YXJ0c1dpdGgoJ2h0dHAnKSA/IHBhdGggOiBgJHtBUElfQkFTRX0ke3BhdGh9YDtcclxuICAgIGNvbnN0IGluaXQ6IFJlcXVlc3RJbml0ID0ge1xyXG4gICAgICBtZXRob2QsXHJcbiAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dGhpcy5zZXR0aW5ncy5wYXR9YCxcclxuICAgICAgICBBY2NlcHQ6ICdhcHBsaWNhdGlvbi92bmQuZ2l0aHViK2pzb24nLFxyXG4gICAgICAgICdYLUdpdEh1Yi1BcGktVmVyc2lvbic6ICcyMDIyLTExLTI4JyxcclxuICAgICAgICAuLi4oYm9keSA/IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IDoge30pLFxyXG4gICAgICB9LFxyXG4gICAgICAuLi4oYm9keSA/IHsgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSkgfSA6IHt9KSxcclxuICAgIH07XHJcbiAgICBsZXQgcmVzOiBSZXNwb25zZTtcclxuICAgIHRyeSB7XHJcbiAgICAgIHJlcyA9IGF3YWl0IGZldGNoKHVybCwgaW5pdCk7XHJcbiAgICB9IGNhdGNoIChuZXRFcnIpIHtcclxuICAgICAgdGhyb3cgbmV3IEdpdEh1YkVycm9yKHtcclxuICAgICAgICBzdGF0dXM6IDAsXHJcbiAgICAgICAgYm9keTogbnVsbCxcclxuICAgICAgICBtZXNzYWdlOiBgbmV0d29yazogJHtkZXNjcmliZUVycm9yKG5ldEVycikubWVzc2FnZX1gLFxyXG4gICAgICAgIHJldHJpYWJsZTogdHJ1ZSxcclxuICAgICAgICBjYXRlZ29yeTogJ25ldHdvcmsnLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICAgIGlmIChyZXMuc3RhdHVzID09PSAyMDQpIHJldHVybiBudWxsO1xyXG4gICAgbGV0IHBhcnNlZDogdW5rbm93biA9IG51bGw7XHJcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcclxuICAgIGlmICh0ZXh0KSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcclxuICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgcGFyc2VkID0gdGV4dDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgYCR7bWV0aG9kfSAke3BhdGh9YCk7XHJcbiAgICByZXR1cm4gcGFyc2VkO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhc3luYyBtYWtlRXJyb3IocmVzOiBSZXNwb25zZSwgbGFiZWw6IHN0cmluZyk6IFByb21pc2U8R2l0SHViRXJyb3I+IHtcclxuICAgIGxldCBwYXJzZWQ6IHVua25vd24gPSBudWxsO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XHJcbiAgICAgIGlmICh0ZXh0KSBwYXJzZWQgPSBKU09OLnBhcnNlKHRleHQpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIGlnbm9yZVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgbGFiZWwpO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBtYWtlRXJyb3JGcm9tUGFyc2VkKHJlczogUmVzcG9uc2UsIGJvZHk6IHVua25vd24sIGxhYmVsOiBzdHJpbmcpOiBHaXRIdWJFcnJvciB7XHJcbiAgICBjb25zdCBtc2cgPVxyXG4gICAgICB0eXBlb2YgYm9keSA9PT0gJ29iamVjdCcgJiYgYm9keSAmJiAnbWVzc2FnZScgaW4gYm9keVxyXG4gICAgICAgID8gU3RyaW5nKChib2R5IGFzIHsgbWVzc2FnZTogdW5rbm93biB9KS5tZXNzYWdlKVxyXG4gICAgICAgIDogcmVzLnN0YXR1c1RleHQ7XHJcbiAgICBsZXQgY2F0ZWdvcnk6IEdpdEh1YkVycm9yWydjYXRlZ29yeSddID0gJ3Vua25vd24nO1xyXG4gICAgbGV0IHJldHJpYWJsZSA9IGZhbHNlO1xyXG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSB8fCByZXMuc3RhdHVzID09PSA0MDMpIHtcclxuICAgICAgLy8gNDAzIGNhbiBiZSBlaXRoZXIgYXV0aCBvciByYXRlIGxpbWl0OyBjaGVjayBoZWFkZXJzLlxyXG4gICAgICBjb25zdCByYXRlID0gcmVzLmhlYWRlcnMuZ2V0KCd4LXJhdGVsaW1pdC1yZW1haW5pbmcnKTtcclxuICAgICAgaWYgKHJhdGUgPT09ICcwJyB8fCAvcmF0ZSBsaW1pdC9pLnRlc3QobXNnKSkge1xyXG4gICAgICAgIGNhdGVnb3J5ID0gJ3JhdGUtbGltaXQnO1xyXG4gICAgICAgIHJldHJpYWJsZSA9IHRydWU7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY2F0ZWdvcnkgPSAnYXV0aCc7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSB7XHJcbiAgICAgIGNhdGVnb3J5ID0gJ25vdC1mb3VuZCc7XHJcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwOSB8fCByZXMuc3RhdHVzID09PSA0MjIpIHtcclxuICAgICAgY2F0ZWdvcnkgPSAnY29uZmxpY3QnO1xyXG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID49IDUwMCkge1xyXG4gICAgICBjYXRlZ29yeSA9ICdzZXJ2ZXInO1xyXG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xyXG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID09PSA0MjkpIHtcclxuICAgICAgY2F0ZWdvcnkgPSAncmF0ZS1saW1pdCc7XHJcbiAgICAgIHJldHJpYWJsZSA9IHRydWU7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbmV3IEdpdEh1YkVycm9yKHtcclxuICAgICAgc3RhdHVzOiByZXMuc3RhdHVzLFxyXG4gICAgICBib2R5LFxyXG4gICAgICBtZXNzYWdlOiBgJHtsYWJlbH0gXHUyMTkyICR7cmVzLnN0YXR1c306ICR7bXNnfWAsXHJcbiAgICAgIHJldHJpYWJsZSxcclxuICAgICAgY2F0ZWdvcnksXHJcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyBwYXJzZVJhdGVMaW1pdFJlc2V0KHJlcy5oZWFkZXJzKSA6IG51bGwsXHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBCZXN0LWVmZm9ydCBwYXJzZSBvZiB3aGVuIHRoZSBjdXJyZW50IHJhdGUtbGltaXQgd2luZG93IGVuZHMuIEdpdEh1YidzXHJcbiAqIHByaW1hcnkgbGltaXQgcmVwb3J0cyBgWC1SYXRlTGltaXQtUmVzZXRgIGFzIGEgVW5peCBlcG9jaCBpbiBzZWNvbmRzLlxyXG4gKiBTZWNvbmRhcnkgLyBhYnVzZSBsaW1pdHMgdXNlIGBSZXRyeS1BZnRlcmAsIHdoaWNoIGlzIGVpdGhlciBhbiBIVFRQLWRhdGVcclxuICogb3IgYSBkZWx0YSBpbiBzZWNvbmRzIFx1MjAxNCB3ZSBub3JtYWxpemUgYm90aCB0byBlcG9jaCBzZWNvbmRzLlxyXG4gKi9cclxuZnVuY3Rpb24gcGFyc2VSYXRlTGltaXRSZXNldChoZWFkZXJzOiBIZWFkZXJzKTogbnVtYmVyIHwgbnVsbCB7XHJcbiAgY29uc3QgcmVzZXQgPSBoZWFkZXJzLmdldCgneC1yYXRlbGltaXQtcmVzZXQnKTtcclxuICBpZiAocmVzZXQpIHtcclxuICAgIGNvbnN0IG4gPSBOdW1iZXIucGFyc2VJbnQocmVzZXQsIDEwKTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikgJiYgbiA+IDApIHJldHVybiBuO1xyXG4gIH1cclxuICBjb25zdCByZXRyeUFmdGVyID0gaGVhZGVycy5nZXQoJ3JldHJ5LWFmdGVyJyk7XHJcbiAgaWYgKHJldHJ5QWZ0ZXIpIHtcclxuICAgIGNvbnN0IGRlbHRhID0gTnVtYmVyLnBhcnNlSW50KHJldHJ5QWZ0ZXIsIDEwKTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoZGVsdGEpICYmIGRlbHRhID49IDApIHtcclxuICAgICAgcmV0dXJuIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApICsgZGVsdGE7XHJcbiAgICB9XHJcbiAgICBjb25zdCBhc0RhdGUgPSBEYXRlLnBhcnNlKHJldHJ5QWZ0ZXIpO1xyXG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShhc0RhdGUpKSByZXR1cm4gTWF0aC5mbG9vcihhc0RhdGUgLyAxMDAwKTtcclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGVuY29kZVBhdGgocGF0aDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAvLyBFbmNvZGUgc2VnbWVudHMgaW5kaXZpZHVhbGx5IHNvIHNsYXNoZXMgcmVtYWluLlxyXG4gIHJldHVybiBwYXRoLnNwbGl0KCcvJykubWFwKGVuY29kZVVSSUNvbXBvbmVudCkuam9pbignLycpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBiYWNrb2ZmTXMoYXR0ZW1wdDogbnVtYmVyLCBlcnI6IEdpdEh1YkVycm9yKTogbnVtYmVyIHtcclxuICAvLyBFeHBvbmVudGlhbCB3aXRoIGppdHRlcjsgYnVtcCBoaWdoZXIgZm9yIHJhdGUtbGltaXQgcmVzcG9uc2VzLlxyXG4gIGNvbnN0IGJhc2UgPSBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IDUwMDAgOiA1MDA7XHJcbiAgY29uc3Qgaml0dGVyID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNDAwKTtcclxuICByZXR1cm4gTWF0aC5taW4oNjBfMDAwLCBiYXNlICogMiAqKiAoYXR0ZW1wdCAtIDEpICsgaml0dGVyKTtcclxufVxyXG5cclxuZnVuY3Rpb24gaXNDb25mbGljdChlcnI6IHVua25vd24pOiBlcnIgaXMgR2l0SHViRXJyb3Ige1xyXG4gIHJldHVybiBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdjb25mbGljdCc7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNsZWVwKG1zOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIC8vIGJ5dGVzIGlzIGEgVVRGLTggc3RyaW5nIG9mIEpTT047IGVuY29kZSB0byBiYXNlNjQgdGhlIHNhZmUgd2F5LlxyXG4gIGNvbnN0IHV0ZjggPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoYnl0ZXMpO1xyXG4gIGxldCBiaW4gPSAnJztcclxuICBmb3IgKGNvbnN0IGIgb2YgdXRmOCkgYmluICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYik7XHJcbiAgcmV0dXJuIGJ0b2EoYmluKTtcclxufVxyXG4iLCAiaW1wb3J0IHsgVFdFRVRfVVJMX1BSRUZJWCB9IGZyb20gJy4vY29uZmlnLmpzJztcclxuaW1wb3J0IHR5cGUge1xyXG4gIENhbm9uaWNhbFR3ZWV0LFxyXG4gIENvbW11bml0eU5vdGUsXHJcbiAgTWVkaWFJdGVtLFxyXG4gIFR3ZWV0Q2FyZCxcclxuICBUd2VldFR5cGUsXHJcbiAgVW5hdmFpbGFibGVUd2VldCxcclxuICBVcmxFbnRpdHksXHJcbiAgVXNlclNuYXBzaG90LFxyXG59IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuLyoqXHJcbiAqIE5vcm1hbGl6ZSBHcmFwaFFMIHJlc3BvbnNlIHBheWxvYWRzIGZyb20gWCdzIGludGVybmFsIEFQSSBpbnRvXHJcbiAqIGBDYW5vbmljYWxUd2VldGBzLiBNYW55IGVuZHBvaW50cyBzaGFyZSBhIHNpbWlsYXIgdHdlZXQgc2hhcGUgYnV0IHdyYXAgaXQgaW5cclxuICogZGlmZmVyZW50IGVudmVsb3BlczsgdGhpcyBtb2R1bGUgd2Fsa3MgdGhlIHN0cnVjdHVyZSBkZWZlbnNpdmVseS5cclxuICpcclxuICogVGhlIHBhcnNlciBpcyBpbnRlbnRpb25hbGx5IHBlcm1pc3NpdmU6IGl0IHdpbGwgc2lsZW50bHkgc2tpcCBlbnRyaWVzIGl0XHJcbiAqIGNhbid0IHJlY29nbml6ZSBhcyB0d2VldHMgKGN1cnNvcnMsIGFkcywgZ2FwIGVudHJpZXMsIG1vZHVsZXMgb2Ygb3RoZXJcclxuICogdHdlZXRzLCB0b21ic3RvbmVzKS4gSXQgdGhyb3dzICpvbmx5KiB3aGVuIGdpdmVuIGEgcGF5bG9hZCBpdCBkb2Vzbid0IGtub3dcclxuICogaG93IHRvIHdhbGsgYXQgYWxsIFx1MjAxNCB0aG9zZSBjYXNlcyBhcmUgY2F1Z2h0IGFuZCBxdWFyYW50aW5lZCB1cHN0cmVhbS5cclxuICovXHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZUNvbnRleHQge1xyXG4gIGNhcHR1cmVkQXQ6IHN0cmluZztcclxuICBydW5JZDogc3RyaW5nO1xyXG4gIGVuZHBvaW50OiBzdHJpbmc7XHJcbiAgYWxsb3dlZEhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz47XHJcbiAgc291cmNlVXJsPzogc3RyaW5nIHwgbnVsbDtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBOb3JtYWxpemVSZXN1bHQge1xyXG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcclxuICBvYnNlcnZlZF9pZHM6IHN0cmluZ1tdO1xyXG4gIHVuYXZhaWxhYmxlX3R3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdO1xyXG4gIC8qKlxyXG4gICAqIFR3ZWV0LXNoYXBlZCBub2RlcyB0aGUgd2Fsa2VyIHNhdyAoaGFkIGEgYHJlc3RfaWRgKSBidXQgY291bGRuJ3QgdHVyblxyXG4gICAqIGludG8gYSBmdWxsIGBDYW5vbmljYWxUd2VldGAgXHUyMDE0IHR5cGljYWxseSBiZWNhdXNlIHRoZSBlbWJlZGRlZCB1c2VyXHJcbiAgICogaW5mbyB3YXMgbWlzc2luZyBvciB0aGUgZW50cnkgd2FzIGEgbWVkaWEtb25seSB0aHVtYm5haWwgY2FyZCBmcm9tXHJcbiAgICogdGhlIFVzZXJNZWRpYSBlbmRwb2ludC4gT25seSBJRHMgd2l0aCBhIHRydXN0d29ydGh5IGhhbmRsZSBmcm9tIHRoZVxyXG4gICAqIHR3ZWV0IG5vZGUgaXRzZWxmIGFyZSByZXR1cm5lZDsgb3RoZXJ3aXNlIHRoZSBiYWNrZ3JvdW5kIGNhbm5vdCBidWlsZFxyXG4gICAqIGEgcmVsaWFibGUgLzxoYW5kbGU+L3N0YXR1cy88aWQ+IGRldGFpbCBVUkwuXHJcbiAgICovXHJcbiAgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT47XHJcbn1cclxuXHJcbi8vIFggdHdlZXQgSURzIGFyZSA2NC1iaXQgcG9zaXRpdmUgaW50ZWdlcnMgc2VyaWFsaXplZCBhcyBkZWNpbWFsIHN0cmluZ3MuXHJcbi8vIFRoZXkndmUgZ3Jvd24gdG8gMTkgY2hhcnMgKH4xLjVlMTgpIGJ5IDIwMjYuIFJlamVjdCBhbnl0aGluZyB0aGF0IGRvZXNuJ3RcclxuLy8gbWF0Y2ggdGhpcyBzaGFwZSBcdTIwMTQgb3RoZXJ3aXNlIHNwdXJpb3VzIGNhcmQgSURzLCBjdXJzb3Igc3RyaW5ncywgYWQgc2xvdFxyXG4vLyBJRHMsIGV0Yy4gZW5kIHVwIGluIHRoZSBwYXJ0aWFsLWNhcHR1cmUgcXVldWUgYW5kIHRoZSBjcmF3bCBsb29wXHJcbi8vIG5hdmlnYXRlcyB0byBpbnZhbGlkIFVSTHMgdGhhdCBzaG93IFwidGhpcyBwYWdlIGRvZXNuJ3QgZXhpc3RcIi5cclxuY29uc3QgVFdFRVRfSURfUkUgPSAvXlxcZHsxNSwyMH0kLztcclxuXHJcbi8vIE9ubHkgb25lIGVuZHBvaW50IGFjdHVhbGx5IGV4cG9zZXMgdGhlIGZhaWx1cmUgbW9kZSB0aGUgcGFydGlhbC1jYXB0dXJlXHJcbi8vIHF1ZXVlIGV4aXN0cyBmb3IgXHUyMDE0IHRoZSBNZWRpYSB0YWIncyBgVXNlck1lZGlhYCBxdWVyeSByZXR1cm5pbmdcclxuLy8gdGh1bWJuYWlsLW9ubHkgZW50cmllcyB3aXRob3V0IGEgcG9wdWxhdGVkIGF1dGhvciBibG9jay4gRXZlcnkgb3RoZXJcclxuLy8gZW5kcG9pbnQgdGhhdCBoYW5kcyB1cyBhIGBUd2VldGAgc2hhcGUgZ2l2ZXMgdXMgdGhlIGZ1bGwgZW50cnk7IGlmXHJcbi8vIGBidWlsZFR3ZWV0YCBmYWlscyB0aGVyZSBpdCdzIGEgcmVhbCBlcnJvciwgbm90IFwiZ28gcmUtZmV0Y2ggdGhpc1wiLlxyXG4vLyBSZXN0cmljdGluZyBwYXJ0aWFsLWlkIGVtaXNzaW9uIHRvIFVzZXJNZWRpYSBzdG9wcyB0aGUgZmxvb2RzIG9mXHJcbi8vIGZhbHNlIHBvc2l0aXZlcyByZXBvcnRlZCBvbiBSZXBsaWVzIC8gVHdlZXREZXRhaWwgLyBTZWFyY2hUaW1lbGluZS5cclxuY29uc3QgUEFSVElBTF9PS19FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlck1lZGlhJ10pO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShwYXlsb2FkOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBOb3JtYWxpemVSZXN1bHQge1xyXG4gIGNvbnN0IHJhd1R3ZWV0cyA9IGNvbGxlY3RUd2VldHMocGF5bG9hZCk7XHJcbiAgY29uc3QgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdID0gW107XHJcbiAgY29uc3QgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXSA9IFtdO1xyXG4gIGNvbnN0IG9ic2VydmVkOiBzdHJpbmdbXSA9IFtdO1xyXG4gIGNvbnN0IGJ1aWx0ID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbiAgY29uc3QgcGFydGlhbE1hcCA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmcgfCBudWxsPigpO1xyXG4gIGNvbnN0IGNvbGxlY3RQYXJ0aWFscyA9IFBBUlRJQUxfT0tfRU5EUE9JTlRTLmhhcyhjdHguZW5kcG9pbnQpO1xyXG4gIGZvciAoY29uc3QgcmF3IG9mIHJhd1R3ZWV0cykge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdW5hdmFpbGFibGUgPSBwaWNrVW5hdmFpbGFibGVUd2VldChyYXcsIGN0eCk7XHJcbiAgICAgIGlmICh1bmF2YWlsYWJsZSkge1xyXG4gICAgICAgIHVuYXZhaWxhYmxlVHdlZXRzLnB1c2godW5hdmFpbGFibGUpO1xyXG4gICAgICAgIG9ic2VydmVkLnB1c2godW5hdmFpbGFibGUudHdlZXRfaWQpO1xyXG4gICAgICAgIGJ1aWx0LmFkZCh1bmF2YWlsYWJsZS50d2VldF9pZCk7XHJcbiAgICAgICAgY29udGludWU7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgdCA9IGJ1aWxkVHdlZXQocmF3LCBjdHgpO1xyXG4gICAgICBpZiAoIXQpIHtcclxuICAgICAgICBpZiAoY29sbGVjdFBhcnRpYWxzKSB7XHJcbiAgICAgICAgICAvLyBPbmx5IGVucXVldWUgcmVhbC10d2VldCBzaGVsbHMgd2l0aCBhIHRydXN0d29ydGh5IGhhbmRsZSAobm90XHJcbiAgICAgICAgICAvLyB0b21ic3RvbmVzLCBzdHJpcHBlZCBub2RlcyBsYWNraW5nIGEgbGVnYWN5IGJsb2NrLCBnYXJiYWdlIElEcyxcclxuICAgICAgICAgIC8vIG9yIElEcyB0aGF0IHdvdWxkIHJlcXVpcmUgZ3Vlc3NpbmcgdGhlIGF1dGhvciBmcm9tIHRoZSBwYWdlKS5cclxuICAgICAgICAgIGNvbnN0IHBhcnRpYWwgPSBwaWNrUGFydGlhbChyYXcpO1xyXG4gICAgICAgICAgaWYgKHBhcnRpYWwpIHBhcnRpYWxNYXAuc2V0KHBhcnRpYWwudHdlZXRfaWQsIHBhcnRpYWwuaGludF9oYW5kbGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb250aW51ZTtcclxuICAgICAgfVxyXG4gICAgICBvYnNlcnZlZC5wdXNoKHQudHdlZXRfaWQpO1xyXG4gICAgICBidWlsdC5hZGQodC50d2VldF9pZCk7XHJcbiAgICAgIGlmIChjdHguYWxsb3dlZEhhbmRsZXMuc2l6ZSA9PT0gMCB8fCBjdHguYWxsb3dlZEhhbmRsZXMuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcclxuICAgICAgICB0d2VldHMucHVzaCh0KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIE9uZSBiYWQgZW50cnkgc2hvdWxkbid0IHRha2UgZG93biB0aGUgd2hvbGUgYmF0Y2guXHJcbiAgICB9XHJcbiAgfVxyXG4gIC8vIEFueXRoaW5nIHRoYXQgZW5kZWQgdXAgaW4gcGFydGlhbE1hcCBidXQgQUxTTyBjYW1lIGJhY2sgYXMgYSBidWlsdFxyXG4gIC8vIHR3ZWV0IChkaWZmZXJlbnQgd2Fsa2VyIHBhc3MsIHNhbWUgaWQpIGlzbid0IGFjdHVhbGx5IHBhcnRpYWwuXHJcbiAgY29uc3QgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcclxuICBmb3IgKGNvbnN0IFtpZCwgaGludF0gb2YgcGFydGlhbE1hcCkge1xyXG4gICAgaWYgKGJ1aWx0LmhhcyhpZCkpIGNvbnRpbnVlO1xyXG4gICAgcGFydGlhbF9pZHMucHVzaCh7IHR3ZWV0X2lkOiBpZCwgaGludF9oYW5kbGU6IGhpbnQgfSk7XHJcbiAgfVxyXG4gIHJldHVybiB7IHR3ZWV0cywgb2JzZXJ2ZWRfaWRzOiBvYnNlcnZlZCwgdW5hdmFpbGFibGVfdHdlZXRzOiB1bmF2YWlsYWJsZVR3ZWV0cywgcGFydGlhbF9pZHMgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gcGlja1VuYXZhaWxhYmxlVHdlZXQobm9kZTogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogVW5hdmFpbGFibGVUd2VldCB8IG51bGwge1xyXG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcbiAgaWYgKG4uX190eXBlbmFtZSAhPT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IHR3ZWV0SWQgPVxyXG4gICAgc3RyT3JOdWxsKG4ucmVzdF9pZCkgPz9cclxuICAgIHBpY2tUd2VldElkRnJvbVVybHMobm9kZSkgPz9cclxuICAgIChjdHguc291cmNlVXJsID8gdHdlZXRJZEZyb21Ud2VldFVybChjdHguc291cmNlVXJsKSA6IG51bGwpO1xyXG4gIGlmICghdHdlZXRJZCB8fCAhVFdFRVRfSURfUkUudGVzdCh0d2VldElkKSkgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IHVuYXZhaWxhYmxlVGV4dCA9IHBpY2tUb21ic3RvbmVUZXh0KG5vZGUpO1xyXG4gIHJldHVybiB7XHJcbiAgICB0d2VldF9pZDogdHdlZXRJZCxcclxuICAgIGFjY291bnRfaGFuZGxlOlxyXG4gICAgICBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlLCB0d2VldElkKSA/P1xyXG4gICAgICAoY3R4LnNvdXJjZVVybCA/IGhhbmRsZUZyb21Ud2VldFVybChjdHguc291cmNlVXJsLCB0d2VldElkKSA6IG51bGwpLFxyXG4gICAgdW5hdmFpbGFibGVfZGV0ZWN0ZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxyXG4gICAgdW5hdmFpbGFibGVfcmVhc29uOiBjbGFzc2lmeVVuYXZhaWxhYmxlUmVhc29uKHVuYXZhaWxhYmxlVGV4dCksXHJcbiAgICB1bmF2YWlsYWJsZV90ZXh0OiB1bmF2YWlsYWJsZVRleHQsXHJcbiAgICB1bmF2YWlsYWJsZV9zb3VyY2VfdXJsOiBjdHguc291cmNlVXJsID8/IG51bGwsXHJcbiAgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gcGlja1R3ZWV0SWRGcm9tVXJscyhub2RlOiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcclxuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xyXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBjdXIgPSBzdGFjay5wb3AoKTtcclxuICAgIGlmICh0eXBlb2YgY3VyID09PSAnc3RyaW5nJykge1xyXG4gICAgICBjb25zdCBpZCA9IHR3ZWV0SWRGcm9tVHdlZXRVcmwoY3VyKTtcclxuICAgICAgaWYgKGlkKSByZXR1cm4gaWQ7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAoc2Vlbi5oYXMoY3VyIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xyXG4gICAgc2Vlbi5hZGQoY3VyIGFzIG9iamVjdCk7XHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBjdXIpIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gdHdlZXRJZEZyb21Ud2VldFVybChyYXdVcmw6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHJhd1VybCwgVFdFRVRfVVJMX1BSRUZJWCk7XHJcbiAgICBpZiAodXJsLmhvc3RuYW1lICE9PSAneC5jb20nICYmIHVybC5ob3N0bmFtZSAhPT0gJ3R3aXR0ZXIuY29tJykgcmV0dXJuIG51bGw7XHJcbiAgICBjb25zdCBtYXRjaCA9IHVybC5wYXRobmFtZS5tYXRjaCgvXlxcL1tBLVphLXowLTlfXXsxLDE1fVxcL3N0YXR1c1xcLyhcXGR7MTUsMjB9KSg/OlxcL3wkKS8pO1xyXG4gICAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gbnVsbDtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcGlja1RvbWJzdG9uZVRleHQobm9kZTogdW5rbm93bik6IHN0cmluZyB8IG51bGwge1xyXG4gIGNvbnN0IHN0cmluZ3M6IHN0cmluZ1tdID0gW107XHJcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcclxuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xyXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBjdXIgPSBzdGFjay5wb3AoKTtcclxuICAgIGlmICh0eXBlb2YgY3VyID09PSAnc3RyaW5nJykge1xyXG4gICAgICBjb25zdCB0cmltbWVkID0gY3VyLnRyaW0oKTtcclxuICAgICAgaWYgKFxyXG4gICAgICAgIHRyaW1tZWQubGVuZ3RoID49IDQgJiZcclxuICAgICAgICAhdHJpbW1lZC5zdGFydHNXaXRoKCdodHRwOi8vJykgJiZcclxuICAgICAgICAhdHJpbW1lZC5zdGFydHNXaXRoKCdodHRwczovLycpXHJcbiAgICAgICkge1xyXG4gICAgICAgIHN0cmluZ3MucHVzaCh0cmltbWVkKTtcclxuICAgICAgfVxyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHNlZW4uaGFzKGN1ciBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgY3VyKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgY29uc3QgcHJlZmVycmVkID0gc3RyaW5ncy5maW5kKChzKSA9PlxyXG4gICAgL1xcYihjb3B5cmlnaHR8ZG1jYXx1bmF2YWlsYWJsZXx3aXRoaGVsZHxyZW1vdmVkfGRlbGV0ZWR8dmlvbGF0fHN1c3BlbmRlZClcXGIvaS50ZXN0KHMpXHJcbiAgKTtcclxuICByZXR1cm4gcHJlZmVycmVkID8/IHN0cmluZ3NbMF0gPz8gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gY2xhc3NpZnlVbmF2YWlsYWJsZVJlYXNvbih0ZXh0OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgaWYgKCF0ZXh0KSByZXR1cm4gbnVsbDtcclxuICBpZiAoL1xcYihjb3B5cmlnaHR8ZG1jYSlcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ2NvcHlyaWdodCc7XHJcbiAgaWYgKC9cXGJ3aXRoaGVsZFxcYi9pLnRlc3QodGV4dCkpIHJldHVybiAnd2l0aGhlbGQnO1xyXG4gIGlmICgvXFxiZGVsZXRlZHxyZW1vdmVkXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICdyZW1vdmVkJztcclxuICBpZiAoL1xcYnN1c3BlbmRlZFxcYi9pLnRlc3QodGV4dCkpIHJldHVybiAnc3VzcGVuZGVkJztcclxuICBpZiAoL1xcYnVuYXZhaWxhYmxlfG5vdCBhdmFpbGFibGVcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3VuYXZhaWxhYmxlJztcclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gcGlja1BhcnRpYWwobm9kZTogdW5rbm93bik6IHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfSB8IG51bGwge1xyXG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcbiAgLy8gRGVsZXRlZCB0d2VldHMgc3VyZmFjZSBhcyBUd2VldFRvbWJzdG9uZSBcdTIwMTQgdGhlcmUncyBub3RoaW5nIHRvIHJlZmV0Y2gsXHJcbiAgLy8gc2tpcCB0aGVtIG9yIHRoZSBjcmF3bCBsb29wIHdpbGwgc3BpbiBvbiBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXHJcbiAgaWYgKG4uX190eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XHJcbiAgLy8gUmVxdWlyZSBhIHJlY29nbml6ZWQgVHdlZXQgdHlwZW5hbWUgT1IgYSBsZWdhY3kgYmxvY2suIEN1cnNvcnMsIGFkcyxcclxuICAvLyBtb2R1bGUgaGVhZGVycywgYW5kIHRoZSBsaWtlIGdldCByZWplY3RlZCBoZXJlLlxyXG4gIGNvbnN0IHRuID0gbi5fX3R5cGVuYW1lO1xyXG4gIGlmICh0biAhPT0gJ1R3ZWV0JyAmJiB0biAhPT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiAhb2JqKG4ubGVnYWN5KSkge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG4gIGNvbnN0IHJlc3RJZCA9XHJcbiAgICAodHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgbi5yZXN0X2lkKSB8fFxyXG4gICAgKHR5cGVvZiBvYmoobi50d2VldF9yZXN1bHQpPy5yZXN1bHQgPT09ICdvYmplY3QnICYmXHJcbiAgICAgIChvYmoob2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCBhcyBzdHJpbmcpKTtcclxuICBpZiAodHlwZW9mIHJlc3RJZCAhPT0gJ3N0cmluZycgfHwgIVRXRUVUX0lEX1JFLnRlc3QocmVzdElkKSkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgaGludEhhbmRsZSA9IHBpY2tIaW50SGFuZGxlKG5vZGUsIHJlc3RJZCk7XHJcbiAgaWYgKCFoaW50SGFuZGxlKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4geyB0d2VldF9pZDogcmVzdElkLCBoaW50X2hhbmRsZTogaGludEhhbmRsZSB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBwaWNrSGludEhhbmRsZShub2RlOiB1bmtub3duLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIGNvbnN0IHVzZXJSZXN1bHQgPSBvYmoob2JqKG9iaihuLmNvcmUpPy51c2VyX3Jlc3VsdHMpPy5yZXN1bHQpO1xyXG4gIHJldHVybiAoXHJcbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmNvcmUpPy5zY3JlZW5fbmFtZSkgPz9cclxuICAgIHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubGVnYWN5KT8uc2NyZWVuX25hbWUpID8/XHJcbiAgICBzdHJPck51bGwob2JqKG4ubGVnYWN5KT8uc2NyZWVuX25hbWUpID8/XHJcbiAgICBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlLCB0d2VldElkKVxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tIYW5kbGVGcm9tVHdlZXRVcmxzKG5vZGU6IHVua25vd24sIHR3ZWV0SWQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgY3VyID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgY29uc3QgaGFuZGxlID0gaGFuZGxlRnJvbVR3ZWV0VXJsKGN1ciwgdHdlZXRJZCk7XHJcbiAgICAgIGlmIChoYW5kbGUpIHJldHVybiBoYW5kbGU7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAoc2Vlbi5oYXMoY3VyIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xyXG4gICAgc2Vlbi5hZGQoY3VyIGFzIG9iamVjdCk7XHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBjdXIpIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gaGFuZGxlRnJvbVR3ZWV0VXJsKHJhd1VybDogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChyYXdVcmwsIFRXRUVUX1VSTF9QUkVGSVgpO1xyXG4gICAgaWYgKHVybC5ob3N0bmFtZSAhPT0gJ3guY29tJyAmJiB1cmwuaG9zdG5hbWUgIT09ICd0d2l0dGVyLmNvbScpIHJldHVybiBudWxsO1xyXG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC8oW0EtWmEtejAtOV9dezEsMTV9KVxcL3N0YXR1c1xcLyhcXGR7MTUsMjB9KSg/OlxcL3wkKS8pO1xyXG4gICAgaWYgKCFtYXRjaCB8fCBtYXRjaFsyXSAhPT0gdHdlZXRJZCkgcmV0dXJuIG51bGw7XHJcbiAgICByZXR1cm4gbWF0Y2hbMV0gPz8gbnVsbDtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gY29sbGVjdFR3ZWV0cyhvYmo6IHVua25vd24pOiB1bmtub3duW10ge1xyXG4gIC8vIFdhbGsgdGhlIHJlc3BvbnNlIHRyZWUgZ2F0aGVyaW5nIGV2ZXJ5dGhpbmcgdGhhdCBsb29rcyBsaWtlIGEgdHdlZXRcclxuICAvLyByZXN1bHQuIFdlIGxvb2sgZm9yIG5vZGVzIHNoYXBlZCBsaWtlOlxyXG4gIC8vICAgeyBfX3R5cGVuYW1lPzogJ1R3ZWV0J3wnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnLCByZXN0X2lkLCBsZWdhY3kgfVxyXG4gIC8vIGFuZCB1bndyYXAgdmlzaWJpbGl0eSB3cmFwcGVycy5cclxuICBjb25zdCBvdXQ6IHVua25vd25bXSA9IFtdO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtvYmpdO1xyXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBub2RlID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAobm9kZSA9PT0gbnVsbCB8fCBub2RlID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAoc2Vlbi5oYXMobm9kZSBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKG5vZGUgYXMgb2JqZWN0KTtcclxuXHJcbiAgICBpZiAobG9va3NMaWtlVHdlZXQobm9kZSkpIHtcclxuICAgICAgb3V0LnB1c2godW53cmFwVHdlZXQobm9kZSkpO1xyXG4gICAgfVxyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkobm9kZSkpIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIG5vZGUpIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuZnVuY3Rpb24gbG9va3NMaWtlVHdlZXQobm9kZTogdW5rbm93bik6IG5vZGUgaXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xyXG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xyXG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIGNvbnN0IHR5cGVuYW1lID0gbi5fX3R5cGVuYW1lO1xyXG4gIGlmIChcclxuICAgIHR5cGVuYW1lID09PSAnVHdlZXQnIHx8XHJcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyB8fFxyXG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZSdcclxuICApIHtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICAvLyBTb21lIGVudHJpZXMgbGFjayBfX3R5cGVuYW1lIGJ1dCBzdGlsbCBjYXJyeSBsZWdhY3kgKyByZXN0X2lkICsgY29yZS5cclxuICByZXR1cm4gdHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgdHlwZW9mIG4ubGVnYWN5ID09PSAnb2JqZWN0JyAmJiBuLmxlZ2FjeSAhPT0gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gdW53cmFwVHdlZXQobm9kZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XHJcbiAgaWYgKG5vZGUuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiB0eXBlb2Ygbm9kZS50d2VldCA9PT0gJ29iamVjdCcpIHtcclxuICAgIHJldHVybiBub2RlLnR3ZWV0IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIH1cclxuICByZXR1cm4gbm9kZTtcclxufVxyXG5cclxuZnVuY3Rpb24gYnVpbGRUd2VldChyYXc6IHVua25vd24sIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IENhbm9uaWNhbFR3ZWV0IHwgbnVsbCB7XHJcbiAgaWYgKHR5cGVvZiByYXcgIT09ICdvYmplY3QnIHx8IHJhdyA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgdCA9IHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuXHJcbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IHJlc3RJZCA9IHN0ck9yTnVsbCh0LnJlc3RfaWQpO1xyXG4gIC8vIGBsZWdhY3lgIGlzIHN0aWxsIHdoZXJlIG1vc3QgZW5nYWdlbWVudCAvIGVudGl0aWVzIGxpdmUgaW4gMjAyNi1lcmEgWFxyXG4gIC8vIHBheWxvYWRzLCBidXQgYXMgb2YgcmVjZW50IHNjaGVtYSBtaWdyYXRpb25zIHNldmVyYWwgZmllbGRzIHByZXZpb3VzbHlcclxuICAvLyB0aGVyZSAobm90YWJseSB0aGUgYXV0aG9yIGhhbmRsZSkgaGF2ZSBtb3ZlZCB0byBzaWJsaW5nIGxvY2F0aW9ucy4gV2VcclxuICAvLyB0b2xlcmF0ZSBhIG1pc3NpbmcgbGVnYWN5IGhlcmUgYW5kIGxvb2sgdXAgZXZlcnl0aGluZyB2aWEgZmFsbGJhY2tzLlxyXG4gIGNvbnN0IGxlZ2FjeSA9IG9iaih0LmxlZ2FjeSkgPz8ge307XHJcbiAgaWYgKCFyZXN0SWQpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCBjb3JlID0gb2JqKHQuY29yZSk7XHJcbiAgY29uc3QgdXNlclJlc3VsdCA9IG9iaihvYmooY29yZT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcclxuICAvLyBBdXRob3IgaGFuZGxlOiB0cnkgdGhlIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIGZpcnN0IChjdXJyZW50IFggc2hhcGUpLFxyXG4gIC8vIHRoZW4gdGhlIGxlZ2FjeSBgbGVnYWN5LnNjcmVlbl9uYW1lYCwgdGhlbiBhIGNvdXBsZSBvZiBvbGRlciB2YXJpYW50cy5cclxuICBjb25zdCB1c2VyQ29yZU5ldyA9IG9iaih1c2VyUmVzdWx0Py5jb3JlKTtcclxuICBjb25zdCB1c2VyTGVnYWN5ID0gb2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk7XHJcbiAgY29uc3QgdXNlckF2YXRhck9iaiA9IG9iaih1c2VyUmVzdWx0Py5hdmF0YXIpO1xyXG4gIGNvbnN0IGhhbmRsZSA9XHJcbiAgICBzdHJPck51bGwodXNlckNvcmVOZXc/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKGxlZ2FjeS5zY3JlZW5fbmFtZSk7XHJcbiAgY29uc3QgYWNjb3VudElkID1cclxuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5yZXN0X2lkKSA/P1xyXG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LmlkX3N0cikgPz9cclxuICAgIHN0ck9yTnVsbChsZWdhY3kudXNlcl9pZF9zdHIpO1xyXG4gIGlmICghaGFuZGxlIHx8ICFhY2NvdW50SWQpIHJldHVybiBudWxsO1xyXG4gIC8vIEF1dGhvciBzbmFwc2hvdC4gRGlzcGxheSBuYW1lICsgYXZhdGFyIG1vdmVkIGJldHdlZW4gYGxlZ2FjeWAgYW5kIHRoZVxyXG4gIC8vIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIG92ZXIgdGltZTsgdGhlIHJlc3QgKHZlcmlmaWNhdGlvbiwgZm9sbG93ZXJcclxuICAvLyBjb3VudHMsIGFjY291bnRfY3JlYXRlZF9hdCkgaXMgc3RpbGwgaW4gYGxlZ2FjeWAuIFdlIHNuYXBzaG90IHRoZVxyXG4gIC8vIHdob2xlIFVzZXJTbmFwc2hvdCBwZXIgdHdlZXQgYmVjYXVzZSB0aGVzZSB2YWx1ZXMgZHJpZnQgb3ZlciB0aW1lXHJcbiAgLy8gYW5kIHRoZSBhdC1jYXB0dXJlIHN0YXRlIGlzIHRoZSBvbmx5IHJlbGlhYmxlIHJlY29yZC5cclxuICBjb25zdCBhdXRob3IgPSBleHRyYWN0VXNlclNuYXBzaG90KHVzZXJSZXN1bHQsIHVzZXJDb3JlTmV3LCB1c2VyTGVnYWN5LCB1c2VyQXZhdGFyT2JqKTtcclxuXHJcbiAgY29uc3Qgbm90ZVR3ZWV0ID0gb2JqKG9iaihvYmoodC5ub3RlX3R3ZWV0KT8ubm90ZV90d2VldF9yZXN1bHRzKT8ucmVzdWx0KTtcclxuICBjb25zdCB0ZXh0RnJvbU5vdGUgPSBzdHJPck51bGwobm90ZVR3ZWV0Py50ZXh0KTtcclxuICBjb25zdCB0ZXh0RnJvbUxlZ2FjeSA9IHN0ck9yTnVsbChsZWdhY3kuZnVsbF90ZXh0KSA/PyAnJztcclxuICBjb25zdCB0ZXh0ID0gdGV4dEZyb21Ob3RlID8/IHRleHRGcm9tTGVnYWN5O1xyXG4gIGNvbnN0IGlzVHJ1bmNhdGVkID0gZGV0ZWN0VHJ1bmNhdGlvbihub3RlVHdlZXQsIGxlZ2FjeSwgdGV4dEZyb21MZWdhY3kpO1xyXG4gIGNvbnN0IGNvbW11bml0eU5vdGUgPSBleHRyYWN0Q29tbXVuaXR5Tm90ZSh0LCBsZWdhY3ksIGN0eC5jYXB0dXJlZEF0KTtcclxuXHJcbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKSA/PyB7fTtcclxuICBjb25zdCBlbnRpdGllc0Zyb21Ob3RlID0gb2JqKG5vdGVUd2VldD8uZW50aXR5X3NldCk7XHJcbiAgY29uc3QgaGFzaHRhZ3MgPSBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XHJcbiAgY29uc3QgbWVudGlvbnMgPSBleHRyYWN0TWVudGlvbnMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XHJcbiAgY29uc3QgdXJscyA9IGV4dHJhY3RVcmxzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xyXG4gIGNvbnN0IG1lZGlhID0gZXh0cmFjdE1lZGlhKGxlZ2FjeSk7XHJcblxyXG4gIGNvbnN0IHR3ZWV0VHlwZSA9IGNsYXNzaWZ5VHdlZXRUeXBlKHQsIGxlZ2FjeSk7XHJcblxyXG4gIC8vIHBvc3RlZF9hdDogbGVnYWN5LmNyZWF0ZWRfYXQgcmVtYWlucyB0aGUgY2Fub25pY2FsIGxvY2F0aW9uOyBpZiB0aGF0J3NcclxuICAvLyBtaXNzaW5nIGluIGEgZnV0dXJlIHNjaGVtYSB3ZSBmYWxsIGJhY2sgdG8gdG9wLWxldmVsIGNyZWF0ZWRfYXQuXHJcbiAgY29uc3QgcG9zdGVkQXQgPVxyXG4gICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwobGVnYWN5LmNyZWF0ZWRfYXQpKSA/PyBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh0LmNyZWF0ZWRfYXQpKTtcclxuICBpZiAoIXBvc3RlZEF0KSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3Qgdmlld3MgPSBvYmoodC52aWV3cyk7XHJcbiAgY29uc3Qgdmlld0NvdW50ID0gbnVtT3JOdWxsKHZpZXdzPy5jb3VudCkgPz8gbnVtT3JOdWxsKHN0ck9yTnVsbCh2aWV3cz8uY291bnQpKTtcclxuXHJcbiAgY29uc3QgY2FyZCA9IGV4dHJhY3RDYXJkKHQpO1xyXG4gIGNvbnN0IHBsYWNlID0gb2JqKGxlZ2FjeS5wbGFjZSk7XHJcblxyXG4gIGNvbnN0IHR3ZWV0OiBDYW5vbmljYWxUd2VldCA9IHtcclxuICAgIHR3ZWV0X2lkOiByZXN0SWQsXHJcbiAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxyXG4gICAgYWNjb3VudF9pZDogYWNjb3VudElkLFxyXG4gICAgcG9zdGVkX2F0OiBwb3N0ZWRBdCxcclxuICAgIGZpcnN0X2NhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcclxuICAgIGxhc3Rfc2Vlbl9hdDogY3R4LmNhcHR1cmVkQXQsXHJcbiAgICBkZWxldGlvbl9kZXRlY3RlZF9hdDogbnVsbCxcclxuICAgIHVuYXZhaWxhYmxlX2RldGVjdGVkX2F0OiBudWxsLFxyXG4gICAgdW5hdmFpbGFibGVfcmVhc29uOiBudWxsLFxyXG4gICAgdW5hdmFpbGFibGVfdGV4dDogbnVsbCxcclxuICAgIHVuYXZhaWxhYmxlX3NvdXJjZV91cmw6IG51bGwsXHJcbiAgICB0d2VldF91cmw6IGAke1RXRUVUX1VSTF9QUkVGSVh9LyR7aGFuZGxlfS9zdGF0dXMvJHtyZXN0SWR9YCxcclxuICAgIHR3ZWV0X3R5cGU6IHR3ZWV0VHlwZSxcclxuICAgIGNvbnZlcnNhdGlvbl9pZDogc3RyT3JOdWxsKGxlZ2FjeS5jb252ZXJzYXRpb25faWRfc3RyKSxcclxuICAgIHJlcGx5X3RvX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpLFxyXG4gICAgcmVwbHlfdG9fYWNjb3VudDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zY3JlZW5fbmFtZSksXHJcbiAgICByZXBseV90b19hY2NvdW50X2lkOiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3VzZXJfaWRfc3RyKSxcclxuICAgIHF1b3RlZF90d2VldF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0ciksXHJcbiAgICByZXR3ZWV0ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChcclxuICAgICAgb2JqKG9iaihsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQpPy5yZXN1bHQpPy5yZXN0X2lkID8/XHJcbiAgICAgICAgKGxlZ2FjeSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikucmV0d2VldGVkX3N0YXR1c19pZF9zdHJcclxuICAgICksXHJcbiAgICB0ZXh0LFxyXG4gICAgdGV4dF9yZXNvbHZlZDogcmVzb2x2ZVNob3J0VXJscyh0ZXh0LCB1cmxzKSxcclxuICAgIGxhbmc6IHN0ck9yTnVsbChsZWdhY3kubGFuZyksXHJcbiAgICBwb3NzaWJseV9zZW5zaXRpdmU6IGJvb2xPck51bGwobGVnYWN5LnBvc3NpYmx5X3NlbnNpdGl2ZSksXHJcbiAgICBzb3VyY2U6IHN0ck9yTnVsbChsZWdhY3kuc291cmNlKSA/PyBzdHJPck51bGwodC5zb3VyY2UpLFxyXG4gICAgcGxhY2VfZnVsbF9uYW1lOiBzdHJPck51bGwocGxhY2U/LmZ1bGxfbmFtZSksXHJcbiAgICBoYXNodGFncyxcclxuICAgIG1lbnRpb25zLFxyXG4gICAgdXJscyxcclxuICAgIGNhcmQsXHJcbiAgICBtZWRpYSxcclxuICAgIGxpa2VfY291bnQ6IG51bU9yWmVybyhsZWdhY3kuZmF2b3JpdGVfY291bnQpLFxyXG4gICAgcmV0d2VldF9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcclxuICAgIHJlcGx5X2NvdW50OiBudW1Pclplcm8obGVnYWN5LnJlcGx5X2NvdW50KSxcclxuICAgIHF1b3RlX2NvdW50OiBudW1Pclplcm8obGVnYWN5LnF1b3RlX2NvdW50KSxcclxuICAgIHZpZXdfY291bnQ6IHZpZXdDb3VudCxcclxuICAgIGJvb2ttYXJrX2NvdW50OiBudW1Pck51bGwobGVnYWN5LmJvb2ttYXJrX2NvdW50KSxcclxuICAgIGVuZ2FnZW1lbnRfaGlzdG9yeTogW1xyXG4gICAgICB7XHJcbiAgICAgICAgY2FwdHVyZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxyXG4gICAgICAgIGxpa2VzOiBudW1Pclplcm8obGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcclxuICAgICAgICByZXR3ZWV0czogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcclxuICAgICAgICByZXBsaWVzOiBudW1Pclplcm8obGVnYWN5LnJlcGx5X2NvdW50KSxcclxuICAgICAgICBxdW90ZXM6IG51bU9yWmVybyhsZWdhY3kucXVvdGVfY291bnQpLFxyXG4gICAgICAgIHZpZXdzOiB2aWV3Q291bnQsXHJcbiAgICAgICAgYm9va21hcmtzOiBudW1Pck51bGwobGVnYWN5LmJvb2ttYXJrX2NvdW50KSxcclxuICAgICAgfSxcclxuICAgIF0sXHJcbiAgICBhdXRob3IsXHJcbiAgICBjb21tdW5pdHlfbm90ZTogY29tbXVuaXR5Tm90ZSxcclxuICAgIGlzX3RydW5jYXRlZDogaXNUcnVuY2F0ZWQsXHJcbiAgICB3YXliYWNrX3VybDogbnVsbCxcclxuICAgIHdheWJhY2tfc3VibWl0dGVkX2F0OiBudWxsLFxyXG4gICAgY2FwdHVyZV9zb3VyY2U6ICdleHRlbnNpb24nLFxyXG4gICAgY2FwdHVyZV9ydW5faWQ6IGN0eC5ydW5JZCxcclxuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxyXG4gIH07XHJcblxyXG4gIHJldHVybiB0d2VldDtcclxufVxyXG5cclxuZnVuY3Rpb24gY2xhc3NpZnlUd2VldFR5cGUodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldFR5cGUge1xyXG4gIGlmIChsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQgfHwgbGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JldHdlZXQnO1xyXG4gIGlmIChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXBseSc7XHJcbiAgaWYgKGxlZ2FjeS5pc19xdW90ZV9zdGF0dXMgPT09IHRydWUgfHwgbGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3F1b3RlJztcclxuICBpZiAodC5fX3R5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnKSB7XHJcbiAgICAvLyBwYXNzIHRocm91Z2hcclxuICB9XHJcbiAgcmV0dXJuICdvcmlnaW5hbCc7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGV4dHJhY3RIYXNodGFncyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XHJcbiAgY29uc3QgYXJyID0gZW50aXRpZXMuaGFzaHRhZ3M7XHJcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcclxuICByZXR1cm4gYXJyXHJcbiAgICAubWFwKChoKSA9PlxyXG4gICAgICB0eXBlb2YgaCA9PT0gJ29iamVjdCcgJiYgaCAmJiAndGV4dCcgaW4gaCA/IFN0cmluZygoaCBhcyB7IHRleHQ6IHVua25vd24gfSkudGV4dCkgOiBudWxsXHJcbiAgICApXHJcbiAgICAuZmlsdGVyKChzKTogcyBpcyBzdHJpbmcgPT4gdHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHMubGVuZ3RoID4gMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGV4dHJhY3RNZW50aW9ucyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XHJcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXNlcl9tZW50aW9ucztcclxuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xyXG4gIHJldHVybiBhcnJcclxuICAgIC5tYXAoKHUpID0+XHJcbiAgICAgIHR5cGVvZiB1ID09PSAnb2JqZWN0JyAmJiB1ICYmICdzY3JlZW5fbmFtZScgaW4gdVxyXG4gICAgICAgID8gU3RyaW5nKCh1IGFzIHsgc2NyZWVuX25hbWU6IHVua25vd24gfSkuc2NyZWVuX25hbWUpXHJcbiAgICAgICAgOiBudWxsXHJcbiAgICApXHJcbiAgICAuZmlsdGVyKChzKTogcyBpcyBzdHJpbmcgPT4gdHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHMubGVuZ3RoID4gMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGV4dHJhY3RVcmxzKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFVybEVudGl0eVtdIHtcclxuICBjb25zdCBhcnIgPSBlbnRpdGllcy51cmxzO1xyXG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XHJcbiAgY29uc3Qgb3V0OiBVcmxFbnRpdHlbXSA9IFtdO1xyXG4gIGZvciAoY29uc3QgdSBvZiBhcnIpIHtcclxuICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XHJcbiAgICBjb25zdCBvID0gdSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgIGNvbnN0IHNob3J0ID0gc3RyT3JOdWxsKG8udXJsKTtcclxuICAgIGNvbnN0IGV4cGFuZGVkID0gc3RyT3JOdWxsKG8uZXhwYW5kZWRfdXJsKTtcclxuICAgIGNvbnN0IGRpc3BsYXkgPSBzdHJPck51bGwoby5kaXNwbGF5X3VybCk7XHJcbiAgICBpZiAoIXNob3J0IHx8ICFleHBhbmRlZCkgY29udGludWU7XHJcbiAgICBvdXQucHVzaCh7IHNob3J0LCBleHBhbmRlZCwgZGlzcGxheTogZGlzcGxheSA/PyBleHBhbmRlZCB9KTtcclxuICB9XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuZnVuY3Rpb24gZXh0cmFjdE1lZGlhKGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW1bXSB7XHJcbiAgY29uc3QgZXh0ZW5kZWQgPSBvYmoobGVnYWN5LmV4dGVuZGVkX2VudGl0aWVzKTtcclxuICBjb25zdCBmcm9tRXh0ID0gZXh0ZW5kZWQgPyB0b0FycmF5KGV4dGVuZGVkLm1lZGlhKSA6IFtdO1xyXG4gIGNvbnN0IGZyb21FbnQgPSB0b0FycmF5KG9iaihsZWdhY3kuZW50aXRpZXMpPy5tZWRpYSk7XHJcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGNvbnN0IG1lcmdlZCA9IFsuLi5mcm9tRXh0LCAuLi5mcm9tRW50XS5maWx0ZXIoKG0pID0+IHtcclxuICAgIGlmICh0eXBlb2YgbSAhPT0gJ29iamVjdCcgfHwgbSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgY29uc3QgaWQgPVxyXG4gICAgICBzdHJPck51bGwoKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLm1lZGlhX2tleSkgPz9cclxuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5pZF9zdHIpO1xyXG4gICAgaWYgKCFpZCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgaWYgKHNlZW4uaGFzKGlkKSkgcmV0dXJuIGZhbHNlO1xyXG4gICAgc2Vlbi5hZGQoaWQpO1xyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSk7XHJcbiAgcmV0dXJuIG1lcmdlZC5tYXAoKHJhdykgPT4gYnVpbGRNZWRpYShyYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKTtcclxufVxyXG5cclxuZnVuY3Rpb24gYnVpbGRNZWRpYShtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbSB7XHJcbiAgY29uc3QgdHlwZSA9IHN0ck9yTnVsbChtLnR5cGUpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddO1xyXG4gIGNvbnN0IG9yaWdpbmFsID0gcGlja09yaWdpbmFsVXJsKG0sIHR5cGUpO1xyXG4gIGNvbnN0IGluZm8gPSBvYmoobS5vcmlnaW5hbF9pbmZvKTtcclxuICBjb25zdCB2aWRlb0luZm8gPSBvYmoobS52aWRlb19pbmZvKTtcclxuICBjb25zdCBkdXJhdGlvbk1zID0gbnVtT3JOdWxsKHZpZGVvSW5mbz8uZHVyYXRpb25fbWlsbGlzKTtcclxuICBjb25zdCBhbHRUZXh0ID0gc3RyT3JOdWxsKG0uZXh0X2FsdF90ZXh0KTtcclxuICBjb25zdCBtZWRpYUlkID1cclxuICAgIHN0ck9yTnVsbChtLm1lZGlhX2tleSkgPz9cclxuICAgIHN0ck9yTnVsbChtLmlkX3N0cikgPz9cclxuICAgIGAke3R5cGUgPz8gJ21lZGlhJ30tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKX1gO1xyXG4gIHJldHVybiB7XHJcbiAgICBtZWRpYV9pZDogbWVkaWFJZCxcclxuICAgIG1lZGlhX3R5cGU6ICh0eXBlID8/ICdwaG90bycpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddLFxyXG4gICAgb3JpZ2luYWxfdXJsOiBvcmlnaW5hbCA/PyAnJyxcclxuICAgIHJlbGVhc2VfYXNzZXRfdXJsOiBudWxsLFxyXG4gICAgc2hhMjU2OiBudWxsLFxyXG4gICAgYnl0ZXM6IG51bGwsXHJcbiAgICBkdXJhdGlvbl9zZWM6IGR1cmF0aW9uTXMgIT09IG51bGwgPyBkdXJhdGlvbk1zIC8gMTAwMCA6IG51bGwsXHJcbiAgICB3aWR0aDogbnVtT3JOdWxsKGluZm8/LndpZHRoKSxcclxuICAgIGhlaWdodDogbnVtT3JOdWxsKGluZm8/LmhlaWdodCksXHJcbiAgICBhbHRfdGV4dDogYWx0VGV4dCxcclxuICAgIGFyY2hpdmVfc3RhdHVzOiAncGVuZGluZycsXHJcbiAgICBhcmNoaXZlX2F0dGVtcHRzOiAwLFxyXG4gICAgbGFzdF9hdHRlbXB0X2F0OiBudWxsLFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tPcmlnaW5hbFVybChtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdHlwZTogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xyXG4gIGlmICh0eXBlID09PSAncGhvdG8nKSByZXR1cm4gc3RyT3JOdWxsKG0ubWVkaWFfdXJsX2h0dHBzKSA/PyBzdHJPck51bGwobS5tZWRpYV91cmwpO1xyXG4gIGNvbnN0IHZhcmlhbnRzID0gdG9BcnJheShvYmoobS52aWRlb19pbmZvKT8udmFyaWFudHMpIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+W107XHJcbiAgaWYgKHZhcmlhbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcyk7XHJcbiAgLy8gSGlnaGVzdC1iaXRyYXRlIG1wNC5cclxuICBsZXQgYmVzdDogeyB1cmw6IHN0cmluZzsgYml0cmF0ZTogbnVtYmVyIH0gfCBudWxsID0gbnVsbDtcclxuICBmb3IgKGNvbnN0IHYgb2YgdmFyaWFudHMpIHtcclxuICAgIGNvbnN0IGN0ID0gc3RyT3JOdWxsKHYuY29udGVudF90eXBlKTtcclxuICAgIGNvbnN0IHVybCA9IHN0ck9yTnVsbCh2LnVybCk7XHJcbiAgICBpZiAoIXVybCkgY29udGludWU7XHJcbiAgICBpZiAoY3QgPT09ICd2aWRlby9tcDQnKSB7XHJcbiAgICAgIGNvbnN0IGJyID0gbnVtT3JOdWxsKHYuYml0cmF0ZSkgPz8gMDtcclxuICAgICAgaWYgKCFiZXN0IHx8IGJyID4gYmVzdC5iaXRyYXRlKSBiZXN0ID0geyB1cmwsIGJpdHJhdGU6IGJyIH07XHJcbiAgICB9IGVsc2UgaWYgKCFiZXN0KSB7XHJcbiAgICAgIC8vIEZhbGxiYWNrIHRvIGFueSB2YXJpYW50IGlmIG5vIG1wNCBmb3VuZC5cclxuICAgICAgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiAwIH07XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBiZXN0Py51cmwgPz8gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gcmVzb2x2ZVNob3J0VXJscyh0ZXh0OiBzdHJpbmcsIHVybHM6IFVybEVudGl0eVtdKTogc3RyaW5nIHtcclxuICBpZiAodXJscy5sZW5ndGggPT09IDApIHJldHVybiB0ZXh0O1xyXG4gIGxldCBvdXQgPSB0ZXh0O1xyXG4gIGZvciAoY29uc3QgdSBvZiB1cmxzKSBvdXQgPSBvdXQuc3BsaXQodS5zaG9ydCkuam9pbih1LmV4cGFuZGVkKTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYXJzZVR3aXR0ZXJEYXRlKHM6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAoIXMpIHJldHVybiBudWxsO1xyXG4gIC8vIFR3aXR0ZXIgc2hpcHMgZGF0ZXMgbGlrZSBcIk1vbiBBcHIgMTIgMTQ6MjM6MDEgKzAwMDAgMjAyNVwiLlxyXG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShzKTtcclxuICBpZiAoTnVtYmVyLmlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIGQudG9JU09TdHJpbmcoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc3RyT3JOdWxsKHY6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcclxuICByZXR1cm4gdHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCA/IHYgOiBudWxsO1xyXG59XHJcbmZ1bmN0aW9uIGJvb2xPck51bGwodjogdW5rbm93bik6IGJvb2xlYW4gfCBudWxsIHtcclxuICByZXR1cm4gdHlwZW9mIHYgPT09ICdib29sZWFuJyA/IHYgOiBudWxsO1xyXG59XHJcbmZ1bmN0aW9uIG51bU9yTnVsbCh2OiB1bmtub3duKTogbnVtYmVyIHwgbnVsbCB7XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyAmJiBOdW1iZXIuaXNGaW5pdGUodikpIHJldHVybiB2O1xyXG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBuID0gTnVtYmVyKHYpO1xyXG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShuKSkgcmV0dXJuIG47XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcbmZ1bmN0aW9uIG51bU9yWmVybyh2OiB1bmtub3duKTogbnVtYmVyIHtcclxuICByZXR1cm4gbnVtT3JOdWxsKHYpID8/IDA7XHJcbn1cclxuZnVuY3Rpb24gb2JqKHY6IHVua25vd24pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwge1xyXG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ29iamVjdCcgJiYgdiAhPT0gbnVsbCAmJiAhQXJyYXkuaXNBcnJheSh2KVxyXG4gICAgPyAodiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilcclxuICAgIDogbnVsbDtcclxufVxyXG5mdW5jdGlvbiB0b0FycmF5KHY6IHVua25vd24pOiB1bmtub3duW10ge1xyXG4gIHJldHVybiBBcnJheS5pc0FycmF5KHYpID8gdiA6IFtdO1xyXG59XHJcblxyXG4vKipcclxuICogRGVjaWRlIHdoZXRoZXIgYSB0d2VldCdzIGFyY2hpdmVkIGB0ZXh0YCBpcyB0aGUgdHJ1bmNhdGVkIGhlYWQgb2YgYSBsb25nZXJcclxuICogYm9keS4gQSB0cnVuY2F0ZWQgdHdlZXQgaGFzIFgncyBcIlNob3cgbW9yZVwiIHQuY28gVVJMIGFwcGVuZGVkIFx1MjAxNCB0aGF0IFVSTFxyXG4gKiBzcGVjaWZpY2FsbHkgZXhwYW5kcyB0byB0aGUgdHdlZXQncyBvd24gL2kvd2ViL3N0YXR1cy88aWQ+IHBlcm1hbGluaywgYW5kXHJcbiAqIGlzIHRoZSBvbmx5IHJlbGlhYmxlIGRpc3Rpbmd1aXNoaW5nIGZlYXR1cmUuIFBsZW50eSBvZiBub3JtYWwgdHdlZXRzIGhhdmVcclxuICogdHJhaWxpbmcgdC5jbyBVUkxzIChtZWRpYSwgcXVvdGVzLCByZWd1bGFyIGxpbmtzKSwgYW5kIHRoZWlyXHJcbiAqIGRpc3BsYXlfdGV4dF9yYW5nZSBhbHNvIHRyaW1zIHBhc3QgZnVsbF90ZXh0Lmxlbmd0aCwgc28gdGhlIG9sZFxyXG4gKiBcImRpc3BsYXlfdGV4dF9yYW5nZVsxXSA8IGZ1bGxfdGV4dC5sZW5ndGhcIiBoZXVyaXN0aWMgd2FzIG92ZXJmbGFnZ2luZ1xyXG4gKiBlc3NlbnRpYWxseSBldmVyeSB0d2VldCB3aXRoIGEgbGluayBpbiBpdC5cclxuICpcclxuICogUnVsZXM6XHJcbiAqICAgLSBub3RlX3R3ZWV0IHByZXNlbnQgIFx1MjE5MiBub3QgdHJ1bmNhdGVkICh3ZSBhbHJlYWR5IGhhdmUgdGhlIGZ1bGwgYm9keSkuXHJcbiAqICAgLSBPbmUgb2YgbGVnYWN5LmVudGl0aWVzLnVybHMgaGFzIGFuIGV4cGFuZGVkX3VybCBsaWtlXHJcbiAqICAgICBcIi4uLi9pL3dlYi9zdGF0dXMvPGlkPlwiICBcdTIxOTIgIHRydW5jYXRlZC5cclxuICogICAtIE90aGVyd2lzZSBcdTIxOTIgbm90IHRydW5jYXRlZC5cclxuICpcclxuICogVGhlIHByZXZpb3VzIGZhbGxiYWNrIChcInRyYWlsaW5nIHQuY28gVVJMICsgbGVuZ3RoIFx1MjI2NSAyNzBcIikgZmxhZ2dlZCBldmVyeVxyXG4gKiBtZWRpYSB0d2VldCBleGFjdGx5IGF0IHRoZSAyODAtY2hhciBsaW1pdC4gV2UgZHJvcCBpdCBlbnRpcmVseTsgdGhlIG9ubHlcclxuICogY29zdCBpcyBtaXNzaW5nIGdlbnVpbmVseS10cnVuY2F0ZWQgdHdlZXRzIHdob3NlIHBheWxvYWQgd2FzIHNvIGRlZ3JhZGVkXHJcbiAqIGl0IGxhY2tlZCBlbnRpdGllcyBcdTIwMTQgd2hpY2ggaXMgYWxzbyB3aGVyZSB0aGUgcmVmZXRjaCBsb29wIHdvdWxkIGZhaWxcclxuICogYW55d2F5LCBzbyBub3RoaW5nIGlzIGFjdHVhbGx5IGxvc3QuXHJcbiAqL1xyXG5mdW5jdGlvbiBkZXRlY3RUcnVuY2F0aW9uKFxyXG4gIG5vdGVUd2VldDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxyXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXHJcbiAgZnVsbFRleHQ6IHN0cmluZ1xyXG4pOiBib29sZWFuIHtcclxuICBpZiAobm90ZVR3ZWV0KSByZXR1cm4gZmFsc2U7XHJcbiAgaWYgKCFmdWxsVGV4dCkgcmV0dXJuIGZhbHNlO1xyXG4gIGNvbnN0IGVudGl0aWVzID0gb2JqKGxlZ2FjeS5lbnRpdGllcyk7XHJcbiAgY29uc3QgdXJscyA9IGVudGl0aWVzID8gZW50aXRpZXMudXJscyA6IG51bGw7XHJcbiAgaWYgKEFycmF5LmlzQXJyYXkodXJscykpIHtcclxuICAgIGZvciAoY29uc3QgdSBvZiB1cmxzKSB7XHJcbiAgICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XHJcbiAgICAgIGNvbnN0IGV4cCA9ICh1IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5leHBhbmRlZF91cmw7XHJcbiAgICAgIC8vIFRoZSBcIlNob3cgbW9yZVwiIGxpbmsgZXhwYW5kcyB0byBlaXRoZXIgb2YgdGhlc2Ugc2VsZi1wZXJtYWxpbmtcclxuICAgICAgLy8gc2hhcGVzOiAgaHR0cHM6Ly94LmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxyXG4gICAgICAvLyAgICAgICAgICBodHRwczovL3R3aXR0ZXIuY29tL2kvd2ViL3N0YXR1cy88aWQ+XHJcbiAgICAgIGlmICh0eXBlb2YgZXhwID09PSAnc3RyaW5nJyAmJiAvXFwvaVxcL3dlYlxcL3N0YXR1c1xcL1xcZCsvLnRlc3QoZXhwKSkge1xyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBmYWxzZTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZpbHRlciBgdHdlZXRzYCBkb3duIHRvIHRob3NlIHJlbGF0ZWQgdG8gYSB0cmFja2VkIGFjY291bnQuIEEgdHdlZXQgaXNcclxuICogXCJyZWxhdGVkXCIgaWYgYW55IG9mIHRoZSBmb2xsb3dpbmcgaG9sZDpcclxuICpcclxuICogICAtIGl0cyBhdXRob3IgaXMgdHJhY2tlZCAoaGFuZGxlIGluIGB0YXJnZXRlZGApLFxyXG4gKiAgIC0gaXQgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZSxcclxuICogICAtIGl0IHJlcGxpZXMgdG8gYSB0cmFja2VkIGFjY291bnQsXHJcbiAqICAgLSBpdCBxdW90ZXMvcmV0d2VldHMvcmVwbGllcy10byBhIHR3ZWV0IHRoYXQncyBhbHNvIHByZXNlbnQgaW4gdGhlXHJcbiAqICAgICBiYXRjaCAqYW5kKiBhdXRob3JlZCBieSBhIHRyYWNrZWQgYWNjb3VudCAodHJhbnNpdGl2ZWx5IHJlbGF0ZWQgXHUyMDE0XHJcbiAqICAgICBjYXB0dXJlcyB0aGUgcXVvdGVkL1JUJ2QgY29udGVudCB0aGF0IGFwcGVhcnMgYXMgYSBzaWJsaW5nIG5vZGUgaW5cclxuICogICAgIHRoZSBzYW1lIEdyYXBoUUwgcmVzcG9uc2UpLlxyXG4gKlxyXG4gKiBBbnl0aGluZyBlbHNlIChyYW5kb20gcmVwbGllcyB1bmRlciBhIHRyYWNrZWQgYWNjb3VudCdzIHR3ZWV0LCByYW5kb21cclxuICogYXV0aG9ycyB0aGF0IGhhcHBlbiB0byBzdXJmYWNlIGluIGEgdHJhY2tlZCBhY2NvdW50J3MgdGhyZWFkKSBpcyBkcm9wcGVkLlxyXG4gKiBQYXNzIGFuIGVtcHR5IGB0YXJnZXRlZGAgc2V0IHRvIGRpc2FibGUgZmlsdGVyaW5nIGVudGlyZWx5LlxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGZpbHRlclJlbGF0ZWQoXHJcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdLFxyXG4gIHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+XHJcbik6IENhbm9uaWNhbFR3ZWV0W10ge1xyXG4gIGlmICh0YXJnZXRlZC5zaXplID09PSAwKSByZXR1cm4gdHdlZXRzO1xyXG4gIC8vIEZpcnN0IHBhc3M6IHdoaWNoIHR3ZWV0IElEcyBkbyB0cmFja2VkLWF1dGhvciB0d2VldHMgcmVmZXJlbmNlICh0aGVcclxuICAvLyBcImZvcndhcmRcIiBkaXJlY3Rpb24gXHUyMDE0IHRyYWNrZWQgYWNjb3VudCBxdW90ZXMgLyBSVHMgLyByZXBsaWVzIHRvIFgpP1xyXG4gIC8vIEFuZCB3aGljaCB0d2VldCBJRHMgQVJFIHRyYWNrZWQtYXV0aG9yZWQgKHRoZSBcInJldmVyc2VcIiBkaXJlY3Rpb24gXHUyMDE0XHJcbiAgLy8gWCBxdW90ZXMgLyBSVHMgLyByZXBsaWVzIHRvIGEgdHJhY2tlZCB0d2VldCk/XHJcbiAgY29uc3QgcmVmZXJlbmNlZElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGNvbnN0IHRhcmdldGVkVHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XHJcbiAgICBpZiAoIXRhcmdldGVkLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSBjb250aW51ZTtcclxuICAgIHRhcmdldGVkVHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xyXG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnF1b3RlZF90d2VldF9pZCk7XHJcbiAgICBpZiAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucmV0d2VldGVkX3R3ZWV0X2lkKTtcclxuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnJlcGx5X3RvX3R3ZWV0X2lkKTtcclxuICB9XHJcbiAgcmV0dXJuIHR3ZWV0cy5maWx0ZXIoKHQpID0+IHtcclxuICAgIGNvbnN0IGggPSB0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCk7XHJcbiAgICBpZiAodGFyZ2V0ZWQuaGFzKGgpKSByZXR1cm4gdHJ1ZTtcclxuICAgIC8vIEZvcndhcmQ6IGEgdHJhY2tlZC1hdXRob3IgdHdlZXQgcG9pbnRlZCBhdCB0aGlzIG9uZS5cclxuICAgIGlmIChyZWZlcmVuY2VkSWRzLmhhcyh0LnR3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XHJcbiAgICAvLyBSZXZlcnNlOiB0aGlzIHR3ZWV0IHBvaW50cyBhdCBhIHRyYWNrZWQtYXV0aG9yIHR3ZWV0IGluIHRoZSBiYXRjaC5cclxuICAgIGlmICh0LnF1b3RlZF90d2VldF9pZCAmJiB0YXJnZXRlZFR3ZWV0SWRzLmhhcyh0LnF1b3RlZF90d2VldF9pZCkpIHJldHVybiB0cnVlO1xyXG4gICAgaWYgKHQucmV0d2VldGVkX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucmV0d2VldGVkX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XHJcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCAmJiB0YXJnZXRlZFR3ZWV0SWRzLmhhcyh0LnJlcGx5X3RvX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XHJcbiAgICAvLyBSZXBseS10by1hY2NvdW50IG9yIG1lbnRpb25zIGEgdHJhY2tlZCBoYW5kbGUuXHJcbiAgICBpZiAodC5yZXBseV90b19hY2NvdW50ICYmIHRhcmdldGVkLmhhcyh0LnJlcGx5X3RvX2FjY291bnQudG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xyXG4gICAgZm9yIChjb25zdCBtIG9mIHQubWVudGlvbnMpIHtcclxuICAgICAgaWYgKHRhcmdldGVkLmhhcyhtLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gdHJ1ZTtcclxuICAgIH1cclxuICAgIHJldHVybiBmYWxzZTtcclxuICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFB1bGwgdGhlIENvbW11bml0eSBOb3RlIChmb3JtZXJseSBCaXJkd2F0Y2gpIGJsb2NrIGF0dGFjaGVkIHRvIGEgdHdlZXQsIGlmXHJcbiAqIGFueS4gVGhlIHBpdm90IGNhbiBsaXZlIGF0IGB0d2VldC5sZWdhY3kuYmlyZHdhdGNoX3Bpdm90YCAob2xkZXIgc2hhcGUpIG9yXHJcbiAqIGB0d2VldC5iaXJkd2F0Y2hfcGl2b3RgIChjdXJyZW50IHNoYXBlKS4gVGhlIHN1bW1hcnkgdGV4dCBpcyB3aGF0IHJlYWRlcnNcclxuICogYWN0dWFsbHkgc2VlOyB3ZSBrZWVwIHRoZSBzdXJyb3VuZGluZyBtZXRhZGF0YSBzbyBkb3duc3RyZWFtIHRvb2xpbmcgY2FuXHJcbiAqIHRlbGwgZHJhZnRzIGFwYXJ0IGZyb20gcmF0ZWQtaGVscGZ1bCBub3Rlcy5cclxuICovXHJcbmZ1bmN0aW9uIGV4dHJhY3RDb21tdW5pdHlOb3RlKFxyXG4gIHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxyXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXHJcbiAgb2JzZXJ2ZWRBdDogc3RyaW5nXHJcbik6IENvbW11bml0eU5vdGUgfCBudWxsIHtcclxuICBjb25zdCBwaXZvdCA9IG9iaih0LmJpcmR3YXRjaF9waXZvdCkgPz8gb2JqKGxlZ2FjeS5iaXJkd2F0Y2hfcGl2b3QpO1xyXG4gIGlmICghcGl2b3QpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IHN1YnRpdGxlID0gb2JqKHBpdm90LnN1YnRpdGxlKTtcclxuICBjb25zdCBub3RlID0gb2JqKHBpdm90Lm5vdGUpO1xyXG4gIGNvbnN0IHN1bW1hcnkgPSBzdHJPck51bGwoc3VidGl0bGU/LnRleHQpO1xyXG4gIGNvbnN0IHRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnRpdGxlKTtcclxuICBjb25zdCBzaG9ydFRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnNob3J0VGl0bGUpO1xyXG4gIGNvbnN0IGRlc3RpbmF0aW9uVXJsID0gc3RyT3JOdWxsKHBpdm90LmRlc3RpbmF0aW9uVXJsKTtcclxuICBjb25zdCBub3RlSWQgPSBzdHJPck51bGwocGl2b3Qubm90ZUlkKSA/PyBzdHJPck51bGwobm90ZT8ucmVzdF9pZCk7XHJcbiAgLy8gU2tpcCBlbXB0eSBzaGVsbHMgdGhhdCBoYXZlIG5vIGFjdHVhbCBjb250ZW50LlxyXG4gIGlmICghc3VtbWFyeSAmJiAhdGl0bGUgJiYgIW5vdGVJZCkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIHtcclxuICAgIG5vdGVfaWQ6IG5vdGVJZCxcclxuICAgIHRpdGxlLFxyXG4gICAgc2hvcnRfdGl0bGU6IHNob3J0VGl0bGUsXHJcbiAgICBzdW1tYXJ5LFxyXG4gICAgZGVzdGluYXRpb25fdXJsOiBkZXN0aW5hdGlvblVybCxcclxuICAgIG9ic2VydmVkX2F0OiBvYnNlcnZlZEF0LFxyXG4gIH07XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBQdWxsIGEgcGVyLWF1dGhvciBVc2VyU25hcHNob3QgZnJvbSB0aGUgdHdlZXQncyB1c2VyX3Jlc3VsdHMgbm9kZS4gRXZlcnlcclxuICogZmllbGQgZGVmYXVsdHMgdG8gbnVsbCB3aGVuIG1pc3Npbmcgc28gdGhlIHNjaGVtYSBzdGF5cyBzdGFibGUgYWNyb3NzXHJcbiAqIHRoZSBsZWdhY3kgLyBjb3JlIHNoYXBlIG1pZ3JhdGlvbnMgWCBoYXMgYmVlbiBkb2luZy5cclxuICovXHJcbmZ1bmN0aW9uIGV4dHJhY3RVc2VyU25hcHNob3QoXHJcbiAgdXNlclJlc3VsdDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxyXG4gIHVzZXJDb3JlTmV3OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXHJcbiAgdXNlckxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxyXG4gIHVzZXJBdmF0YXJPYmo6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbFxyXG4pOiBVc2VyU25hcHNob3Qge1xyXG4gIGNvbnN0IHZlcmlmaWNhdGlvbiA9IG9iaih1c2VyUmVzdWx0Py52ZXJpZmljYXRpb24pO1xyXG4gIHJldHVybiB7XHJcbiAgICBkaXNwbGF5X25hbWU6XHJcbiAgICAgIHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8ubmFtZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/Lm5hbWUpID8/IHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5uYW1lKSxcclxuICAgIGF2YXRhcl91cmw6XHJcbiAgICAgIHN0ck9yTnVsbCh1c2VyQXZhdGFyT2JqPy5pbWFnZV91cmwpID8/XHJcbiAgICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5wcm9maWxlX2ltYWdlX3VybF9odHRwcykgPz9cclxuICAgICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzKSxcclxuICAgIHZlcmlmaWVkOiBib29sT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWQpID8/IGJvb2xPck51bGwodXNlckxlZ2FjeT8udmVyaWZpZWQpLFxyXG4gICAgaXNfYmx1ZV92ZXJpZmllZDogYm9vbE9yTnVsbCh1c2VyUmVzdWx0Py5pc19ibHVlX3ZlcmlmaWVkKSxcclxuICAgIHZlcmlmaWVkX3R5cGU6IHN0ck9yTnVsbCh2ZXJpZmljYXRpb24/LnZlcmlmaWVkX3R5cGUpID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py52ZXJpZmllZF90eXBlKSxcclxuICAgIGRlc2NyaXB0aW9uOiBzdHJPck51bGwodXNlckxlZ2FjeT8uZGVzY3JpcHRpb24pLFxyXG4gICAgbG9jYXRpb246IHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubG9jYXRpb24pPy5sb2NhdGlvbikgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmxvY2F0aW9uKSxcclxuICAgIHVybDogc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnVybCksXHJcbiAgICBmb2xsb3dlcnNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5mb2xsb3dlcnNfY291bnQpLFxyXG4gICAgZnJpZW5kc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZyaWVuZHNfY291bnQpLFxyXG4gICAgc3RhdHVzZXNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5zdGF0dXNlc19jb3VudCksXHJcbiAgICBhY2NvdW50X2NyZWF0ZWRfYXQ6XHJcbiAgICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5jcmVhdGVkX2F0KSkgPz9cclxuICAgICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodXNlckxlZ2FjeT8uY3JlYXRlZF9hdCkpLFxyXG4gICAgcHJvdGVjdGVkOiBib29sT3JOdWxsKHVzZXJMZWdhY3k/LnByb3RlY3RlZCksXHJcbiAgfTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFdhbGsgdGhlIHR3ZWV0J3MgYGNhcmQubGVnYWN5LmJpbmRpbmdfdmFsdWVzYCAoa2V5L3ZhbHVlIGFycmF5KSBpbnRvIGFcclxuICogZmxhdCBUd2VldENhcmQgd2l0aCB0aXRsZSwgZGVzY3JpcHRpb24sIGFuZCBhIHJlcHJlc2VudGF0aXZlIGltYWdlIFVSTC5cclxuICogUmV0dXJucyBudWxsIHdoZW4gdGhlIHR3ZWV0IGhhcyBubyBjYXJkLlxyXG4gKi9cclxuZnVuY3Rpb24gZXh0cmFjdENhcmQodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldENhcmQgfCBudWxsIHtcclxuICBjb25zdCBjYXJkID0gb2JqKHQuY2FyZCk7XHJcbiAgY29uc3QgY2FyZExlZ2FjeSA9IG9iaihjYXJkPy5sZWdhY3kpO1xyXG4gIGlmICghY2FyZExlZ2FjeSkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgYmluZGluZ3MgPSBjYXJkTGVnYWN5LmJpbmRpbmdfdmFsdWVzO1xyXG4gIGNvbnN0IGJ5S2V5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xyXG4gIGlmIChBcnJheS5pc0FycmF5KGJpbmRpbmdzKSkge1xyXG4gICAgZm9yIChjb25zdCBidiBvZiBiaW5kaW5ncykge1xyXG4gICAgICBpZiAodHlwZW9mIGJ2ICE9PSAnb2JqZWN0JyB8fCBidiA9PT0gbnVsbCkgY29udGludWU7XHJcbiAgICAgIGNvbnN0IG8gPSBidiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgICAgY29uc3QgayA9IHN0ck9yTnVsbChvLmtleSk7XHJcbiAgICAgIGNvbnN0IHYgPSBvYmooby52YWx1ZSk7XHJcbiAgICAgIGlmICghayB8fCAhdikgY29udGludWU7XHJcbiAgICAgIGJ5S2V5W2tdID1cclxuICAgICAgICBzdHJPck51bGwodi5zdHJpbmdfdmFsdWUpID8/XHJcbiAgICAgICAgc3RyT3JOdWxsKG9iaih2LmltYWdlX3ZhbHVlKT8udXJsKSA/P1xyXG4gICAgICAgIHN0ck9yTnVsbChvYmoodi5pbWFnZV9jb2xvcl92YWx1ZSk/LnBhbGV0dGUpO1xyXG4gICAgfVxyXG4gIH1cclxuICBjb25zdCBuYW1lID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kubmFtZSk7XHJcbiAgY29uc3QgY2FyZFVybCA9IHN0ck9yTnVsbChjYXJkTGVnYWN5LnVybCk7XHJcbiAgY29uc3QgdmVuZG9yVXJsID1cclxuICAgIHR5cGVvZiBieUtleVsndmFuaXR5X3VybCddID09PSAnc3RyaW5nJyA/IChieUtleVsndmFuaXR5X3VybCddIGFzIHN0cmluZykgOiBudWxsO1xyXG4gIGNvbnN0IHRpdGxlID0gdHlwZW9mIGJ5S2V5Wyd0aXRsZSddID09PSAnc3RyaW5nJyA/IChieUtleVsndGl0bGUnXSBhcyBzdHJpbmcpIDogbnVsbDtcclxuICBjb25zdCBkZXNjcmlwdGlvbiA9XHJcbiAgICB0eXBlb2YgYnlLZXlbJ2Rlc2NyaXB0aW9uJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5WydkZXNjcmlwdGlvbiddIGFzIHN0cmluZykgOiBudWxsO1xyXG4gIGNvbnN0IGltYWdlVXJsID1cclxuICAgICh0eXBlb2YgYnlLZXlbJ3Bob3RvX2ltYWdlX2Z1bGxfc2l6ZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xyXG4gICAgICA/IChieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxyXG4gICAgICA6IG51bGwpID8/XHJcbiAgICAodHlwZW9mIGJ5S2V5Wyd0aHVtYm5haWxfaW1hZ2Vfb3JpZ2luYWwnXSA9PT0gJ3N0cmluZydcclxuICAgICAgPyAoYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcclxuICAgICAgOiBudWxsKSA/P1xyXG4gICAgKHR5cGVvZiBieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xyXG4gICAgICA/IChieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcclxuICAgICAgOiBudWxsKTtcclxuICBpZiAoIW5hbWUgJiYgIXRpdGxlICYmICFkZXNjcmlwdGlvbiAmJiAhaW1hZ2VVcmwpIHJldHVybiBudWxsO1xyXG4gIHJldHVybiB7XHJcbiAgICBuYW1lLFxyXG4gICAgY2FyZF91cmw6IGNhcmRVcmwsXHJcbiAgICB2ZW5kb3JfdXJsOiB2ZW5kb3JVcmwsXHJcbiAgICB0aXRsZSxcclxuICAgIGRlc2NyaXB0aW9uLFxyXG4gICAgaW1hZ2VfdXJsOiBpbWFnZVVybCxcclxuICB9O1xyXG59XHJcbiIsICIvKipcclxuICogTGlnaHR3ZWlnaHQgVUxJRC1saWtlIGlkIGdlbmVyYXRvcjogMjYtY2hhcmFjdGVyIENyb2NrZm9yZCBiYXNlMzIgc3RyaW5nXHJcbiAqIG9mICh0aW1lc3RhbXBfbXMgfHwgcmFuZG9tbmVzcykuIEdvb2QgZW5vdWdoIGZvciBydW4gaWRlbnRpZmllcnMgd2l0aG91dFxyXG4gKiBwdWxsaW5nIGluIGEgcmVhbCBVTElEIGRlcGVuZGVuY3kuXHJcbiAqL1xyXG5cclxuY29uc3QgQUxQSEFCRVQgPSAnMDEyMzQ1Njc4OUFCQ0RFRkdISktNTlBRUlNUVldYWVonOyAvLyBDcm9ja2ZvcmRcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBuZXdSdW5JZCgpOiBzdHJpbmcge1xyXG4gIGNvbnN0IHRzID0gRGF0ZS5ub3coKTtcclxuICBsZXQgdHNQYXJ0ID0gJyc7XHJcbiAgbGV0IHQgPSB0cztcclxuICBmb3IgKGxldCBpID0gMDsgaSA8IDEwOyBpKyspIHtcclxuICAgIHRzUGFydCA9IChBTFBIQUJFVFt0ICUgMzJdID8/ICcwJykgKyB0c1BhcnQ7XHJcbiAgICB0ID0gTWF0aC5mbG9vcih0IC8gMzIpO1xyXG4gIH1cclxuICBjb25zdCByYW5kID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMCkpO1xyXG4gIGxldCByYW5kUGFydCA9ICcnO1xyXG4gIGZvciAoY29uc3QgYiBvZiByYW5kKSByYW5kUGFydCArPSBBTFBIQUJFVFtiICUgMzJdID8/ICcwJztcclxuICByZXR1cm4gdHNQYXJ0ICsgcmFuZFBhcnQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzaG9ydFJ1bklkKGlkOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIHJldHVybiBpZC5zbGljZSgtOCk7XHJcbn1cclxuIiwgImltcG9ydCB0eXBlIHsgQWNjb3VudENhdGVnb3J5LCBBY2NvdW50Q29uZmlnIH0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG4vKipcclxuICogTWluaW1hbCBwYXJzZXIgZm9yIHRoZSBzdHJpY3Qgc2hhcGUgdXNlZCBieSBgY29uZmlnL2FjY291bnRzLnlhbWxgOlxyXG4gKlxyXG4gKiAgIGFjY291bnRzOlxyXG4gKiAgICAgLSBoYW5kbGU6IERIU2dvdlxyXG4gKiAgICAgICBsYWJlbDogRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eVxyXG4gKiAgICAgICBjYXRlZ29yeTogY29yZVxyXG4gKlxyXG4gKiBXZSBkZWxpYmVyYXRlbHkgZG9uJ3QgcHVsbCBpbiBhIGZ1bGwgWUFNTCBsaWJyYXJ5IFx1MjAxNCB3ZSBjb250cm9sIGJvdGggZW5kcyBvZlxyXG4gKiB0aGlzIGZpbGUsIGFuZCBhIHNtYWxsIHBhcnNlciBpcyBlYXNpZXIgdG8gYXVkaXQgdGhhbiB0aGUgYWx0ZXJuYXRpdmVzLlxyXG4gKiBVbmtub3duIGtleXMgYW5kIGNvbW1lbnRzIGFyZSB0b2xlcmF0ZWQ7IG1hbGZvcm1lZCBsaW5lcyBhcmUgc2tpcHBlZC5cclxuICpcclxuICogRW50cmllcyBtaXNzaW5nIGEgYGNhdGVnb3J5YCBkZWZhdWx0IHRvIGBjb3JlYCBmb3IgYmFja3dhcmQgY29tcGF0aWJpbGl0eVxyXG4gKiB3aXRoIHRoZSBwcmUtY2F0ZWdvcml6YXRpb24gZmlsZSBzaGFwZS5cclxuICovXHJcbmNvbnN0IFZBTElEX0NBVEVHT1JJRVM6IFJlYWRvbmx5U2V0PEFjY291bnRDYXRlZ29yeT4gPSBuZXcgU2V0KFtcclxuICAnY29yZScsXHJcbiAgJ2dvdmVybm1lbnQnLFxyXG4gICdvZmZpY2lhbHMnLFxyXG4gICdwdWJsaWNfZmlndXJlcycsXHJcbiAgJ3B1YmxpYycsXHJcbl0pO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQWNjb3VudHNZYW1sKHRleHQ6IHN0cmluZyk6IEFjY291bnRDb25maWdbXSB7XHJcbiAgY29uc3QgYWNjb3VudHM6IEFjY291bnRDb25maWdbXSA9IFtdO1xyXG4gIGxldCBjdXJyZW50OiBQYXJ0aWFsPEFjY291bnRDb25maWc+ID0ge307XHJcbiAgbGV0IGluQWNjb3VudHMgPSBmYWxzZTtcclxuICBjb25zdCBmbHVzaCA9ICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSB7XHJcbiAgICAgIGlmICghY3VycmVudC5jYXRlZ29yeSkgY3VycmVudC5jYXRlZ29yeSA9ICdjb3JlJztcclxuICAgICAgYWNjb3VudHMucHVzaChjdXJyZW50IGFzIEFjY291bnRDb25maWcpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgZm9yIChjb25zdCByYXdMaW5lIG9mIHRleHQuc3BsaXQoJ1xcbicpKSB7XHJcbiAgICBjb25zdCBsaW5lID0gc3RyaXBDb21tZW50cyhyYXdMaW5lKTtcclxuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gJycpIGNvbnRpbnVlO1xyXG4gICAgaWYgKC9eYWNjb3VudHNcXHMqOi8udGVzdChsaW5lKSkge1xyXG4gICAgICBpbkFjY291bnRzID0gdHJ1ZTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAoIWluQWNjb3VudHMpIGNvbnRpbnVlO1xyXG5cclxuICAgIGNvbnN0IGl0ZW1NYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqLVxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xyXG4gICAgaWYgKGl0ZW1NYXRjaCkge1xyXG4gICAgICBmbHVzaCgpO1xyXG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaXRlbU1hdGNoWzFdID8/ICcnKSB9O1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGhhbmRsZU9ubHkgPSBsaW5lLm1hdGNoKC9eXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XHJcbiAgICBpZiAoaGFuZGxlT25seSAmJiAhbGluZS5pbmNsdWRlcygnLScpKSB7XHJcbiAgICAgIGZsdXNoKCk7XHJcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShoYW5kbGVPbmx5WzFdID8/ICcnKSB9O1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGxhYmVsTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmxhYmVsXFxzKjpcXHMqKC4rKSQvKTtcclxuICAgIGlmIChsYWJlbE1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XHJcbiAgICAgIGN1cnJlbnQubGFiZWwgPSB1bnF1b3RlKGxhYmVsTWF0Y2hbMV0gPz8gJycpO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGNvbnN0IGNhdGVnb3J5TWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmNhdGVnb3J5XFxzKjpcXHMqKC4rKSQvKTtcclxuICAgIGlmIChjYXRlZ29yeU1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XHJcbiAgICAgIGNvbnN0IHJhdyA9IHVucXVvdGUoY2F0ZWdvcnlNYXRjaFsxXSA/PyAnJyk7XHJcbiAgICAgIGN1cnJlbnQuY2F0ZWdvcnkgPSBWQUxJRF9DQVRFR09SSUVTLmhhcyhyYXcgYXMgQWNjb3VudENhdGVnb3J5KVxyXG4gICAgICAgID8gKHJhdyBhcyBBY2NvdW50Q2F0ZWdvcnkpXHJcbiAgICAgICAgOiAnY29yZSc7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gIH1cclxuICBmbHVzaCgpO1xyXG4gIHJldHVybiBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuaGFuZGxlLmxlbmd0aCA+IDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdHJpcENvbW1lbnRzKGxpbmU6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgLy8gTmFpdmUgYnV0IGFkZXF1YXRlIGZvciBvdXIgZm9ybWF0OiBzdHJpcCBldmVyeXRoaW5nIGFmdGVyIGEgYCNgIHRoYXQgaXNuJ3RcclxuICAvLyBpbnNpZGUgcXVvdGVzLiBPdXIgY29uZmlnIG5ldmVyIHVzZXMgaW5saW5lIHN0cmluZ3Mgd2l0aCBgI2AuXHJcbiAgY29uc3QgaWR4ID0gbGluZS5pbmRleE9mKCcjJyk7XHJcbiAgcmV0dXJuIGlkeCA9PT0gLTEgPyBsaW5lIDogbGluZS5zbGljZSgwLCBpZHgpO1xyXG59XHJcblxyXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgY29uc3QgdHJpbW1lZCA9IHMudHJpbSgpO1xyXG4gIGlmIChcclxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoJ1wiJykgJiYgdHJpbW1lZC5lbmRzV2l0aCgnXCInKSkgfHxcclxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoXCInXCIpICYmIHRyaW1tZWQuZW5kc1dpdGgoXCInXCIpKVxyXG4gICkge1xyXG4gICAgcmV0dXJuIHRyaW1tZWQuc2xpY2UoMSwgLTEpO1xyXG4gIH1cclxuICByZXR1cm4gdHJpbW1lZDtcclxufVxyXG4iLCAiLyoqXHJcbiAqIGJhY2tncm91bmQudHMgXHUyMDE0IGV4dGVuc2lvbiBzZXJ2aWNlIHdvcmtlci5cclxuICpcclxuICogT3ducyB0aGUgY2FwdHVyZSBwaXBlbGluZTogcmVjZWl2ZXMgYGdyYXBocWwtY2FwdHVyZWAgbWVzc2FnZXMgZnJvbSB0aGVcclxuICogY29udGVudCBzY3JpcHQsIG5vcm1hbGl6ZXMgdGhlbSwgYWNjdW11bGF0ZXMgcGVyLWhhbmRsZSBydW4gYnVmZmVycyBpblxyXG4gKiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgYW5kIGNvbW1pdHMgdGhlbSB0byB0aGUgY29uZmlndXJlZCBHaXRIdWIgcmVwb1xyXG4gKiB2aWEgdGhlIENvbnRlbnRzIEFQSS5cclxuICpcclxuICogU2VydmljZSB3b3JrZXJzIGluIE1WMyBtYXkgYmUgZXZpY3RlZCBhdCBhbnkgdGltZSwgc28gYWxsIGNyaXRpY2FsIHN0YXRlXHJcbiAqIGxpdmVzIGluIHN0b3JhZ2UgKG5ldmVyIG1vZHVsZS1zY29wZSkuIE9uIGV2ZXJ5IHdha2Ugd2UgcmUtZGVyaXZlIHdoYXQgd2VcclxuICogbmVlZDsgcGVuZGluZyBmbHVzaGVzIGFyZSBkcml2ZW4gYnkgYGJyb3dzZXIuYWxhcm1zYCByYXRoZXIgdGhhbiB0aW1lcnMuXHJcbiAqL1xyXG5cclxuaW1wb3J0IHtcclxuICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxyXG4gIEFVVE9fU0NST0xMX01JTl9TRUMsXHJcbiAgRkFMTEJBQ0tfQUNDT1VOVFMsXHJcbiAgRkxVU0hfQUxBUk1fTUlOVVRFUyxcclxuICBGTFVTSF9JRExFX01TLFxyXG4gIEZMVVNIX1RXRUVUX1RIUkVTSE9MRCxcclxuICBQUk9GSUxFX0VORFBPSU5UUyxcclxuICBUV0VFVF9FTkRQT0lOVFMsXHJcbiAgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMsXHJcbn0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcclxuaW1wb3J0IHsgR2l0SHViQ2xpZW50LCBHaXRIdWJFcnJvciwgdG9CYXNlNjQgfSBmcm9tICcuL2xpYi9naXRodWIuanMnO1xyXG5pbXBvcnQgeyBkZXNjcmliZUVycm9yLCBlcnJvciBhcyBsb2dFcnIsIGluZm8sIHNldEJyb2FkY2FzdGVyLCB3YXJuIH0gZnJvbSAnLi9saWIvbG9nZ2VyLmpzJztcclxuaW1wb3J0IHsgZmlsdGVyUmVsYXRlZCwgbm9ybWFsaXplIH0gZnJvbSAnLi9saWIvbm9ybWFsaXplLmpzJztcclxuaW1wb3J0IHsgbmV3UnVuSWQsIHNob3J0UnVuSWQgfSBmcm9tICcuL2xpYi9ydW5pZHMuanMnO1xyXG5pbXBvcnQge1xyXG4gIGJ1bXBDb3VudGVyLFxyXG4gIGNsZWFyQWN0aXZpdHksXHJcbiAgY2xlYXJBbGwsXHJcbiAgY2xlYXJSdW5CdWZmZXIsXHJcbiAgZGVxdWV1ZU1lZGlhQ3Jhd2wsXHJcbiAgZGVxdWV1ZVJlZmV0Y2gsXHJcbiAgZW5nYWdlbWVudFNpZyxcclxuICBlbnF1ZXVlTWVkaWFDcmF3bCxcclxuICBlbnF1ZXVlUmVmZXRjaCxcclxuICBnZXRBY2NvdW50cyxcclxuICBnZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxyXG4gIGdldEFjdGl2aXR5LFxyXG4gIGdldEF1dG9TY3JvbGxTZXNzaW9uLFxyXG4gIGdldENvbW1pdHRlZEluZGV4LFxyXG4gIGdldENvbm5lY3Rpb24sXHJcbiAgZ2V0Q291bnRlcnMsXHJcbiAgZ2V0TWVkaWFDcmF3bFF1ZXVlLFxyXG4gIGdldE1lZGlhQ3Jhd2xTZXNzaW9uLFxyXG4gIGdldFJlZmV0Y2hRdWV1ZSxcclxuICBnZXRSZWZldGNoU2Vzc2lvbixcclxuICBnZXRSdW5CdWZmZXIsXHJcbiAgZ2V0UnVuQnVmZmVycyxcclxuICBnZXRTZXR0aW5ncyxcclxuICBpc0NvbW1pdHRlZCxcclxuICBtZWRpYUNyYXdsUXVldWVUb3RhbCxcclxuICBuZXh0TWVkaWFDcmF3bFRhcmdldCxcclxuICBuZXh0UmVmZXRjaFRhcmdldCxcclxuICBwcnVuZUNvbW1pdHRlZEluZGV4LFxyXG4gIHB1cmdlVW5yZWxhdGVkU3RhdGUsXHJcbiAgcmVmZXRjaFF1ZXVlVG90YWwsXHJcbiAgc2V0QWNjb3VudHMsXHJcbiAgc2V0QWNjb3VudHNSZWZyZXNoZWRBdCxcclxuICBzZXRBdXRvU2Nyb2xsU2Vzc2lvbixcclxuICBzZXRCdWZmZXJlZENvdW50LFxyXG4gIHNldENvbW1pdHRlZEluZGV4LFxyXG4gIHNldENvbm5lY3Rpb24sXHJcbiAgc2V0TWVkaWFDcmF3bFNlc3Npb24sXHJcbiAgc2V0UmVmZXRjaFNlc3Npb24sXHJcbiAgc2V0UnVuQnVmZmVyLFxyXG4gIHR5cGUgUnVuQnVmZmVyLFxyXG4gIHVwZGF0ZVNldHRpbmdzLFxyXG59IGZyb20gJy4vbGliL3N0b3JhZ2UuanMnO1xyXG5pbXBvcnQgdHlwZSB7XHJcbiAgQ2Fub25pY2FsVHdlZXQsXHJcbiAgQ2FwdHVyZVBheWxvYWQsXHJcbiAgQ29ubmVjdGlvblN0YXRlLFxyXG4gIEV4dGVuc2lvblN0YXRlLFxyXG4gIExvZ0V2ZW50LFxyXG4gIFF1YXJhbnRpbmVQYXlsb2FkLFxyXG4gIFJ1bnRpbWVNZXNzYWdlLFxyXG4gIFNlZW5QYXlsb2FkLFxyXG4gIFNldHRpbmdzLFxyXG4gIFVuYXZhaWxhYmxlVHdlZXQsXHJcbn0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xyXG5pbXBvcnQgeyBwYXJzZUFjY291bnRzWWFtbCB9IGZyb20gJy4vbGliL3lhbWwuanMnO1xyXG5cclxuY29uc3QgRVhUX1ZFUlNJT04gPSBicm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9uO1xyXG5cclxuc2V0QnJvYWRjYXN0ZXIoKGV2OiBMb2dFdmVudCkgPT4ge1xyXG4gIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdsb2ctZXZlbnQnLCBldmVudDogZXYgfSkuY2F0Y2goKCkgPT4ge30pO1xyXG59KTtcclxuXHJcbi8vIC0tLSBXYWtlIGhhbmRsZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5icm93c2VyLnJ1bnRpbWUub25JbnN0YWxsZWQuYWRkTGlzdGVuZXIoYXN5bmMgKCkgPT4ge1xyXG4gIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBpbnN0YWxsZWQnLCB7IHZlcnNpb246IEVYVF9WRVJTSU9OIH0pO1xyXG4gIGF3YWl0IG9uV2FrZSgnaW5zdGFsbCcpO1xyXG59KTtcclxuXHJcbmJyb3dzZXIucnVudGltZS5vblN0YXJ0dXAuYWRkTGlzdGVuZXIoKCkgPT4ge1xyXG4gIHZvaWQgb25XYWtlKCdzdGFydHVwJyk7XHJcbn0pO1xyXG5cclxuLy8gRm9yY2UgYXQgbGVhc3Qgb25lIHdha2UgdG8gcmVnaXN0ZXIgYWxhcm1zIC8gdmVyaWZ5IGNvbm5lY3Rpb24uXHJcbnZvaWQgb25XYWtlKCdtb2R1bGUtbG9hZCcpO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gb25XYWtlKHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGVuc3VyZUFsYXJtcygpO1xyXG4gICAgYXdhaXQgZW5zdXJlQXV0b1Njcm9sbEFsYXJtKCk7XHJcbiAgICBhd2FpdCBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTtcclxuICAgIGF3YWl0IHJlaW5qZWN0SW50b09wZW5UYWJzKCk7XHJcbiAgICAvLyBEcm9wIGRlZHVwLWluZGV4IGVudHJpZXMgb2xkZXIgdGhhbiAzMCBkYXlzIHNvIHRoZSBzdG9yZSBkb2Vzbid0XHJcbiAgICAvLyBncm93IHVuYm91bmRlZCBvdmVyIG1vbnRocyBvZiBjYXB0dXJlIHNlc3Npb25zLlxyXG4gICAgY29uc3QgcHJ1bmVkID0gYXdhaXQgcHJ1bmVDb21taXR0ZWRJbmRleCgzMCAqIDI0ICogNjAgKiA2MCAqIDEwMDApO1xyXG4gICAgaWYgKHBydW5lZCA+IDApIGF3YWl0IGluZm8oJ3BydW5lZCBjb21taXR0ZWQgaW5kZXgnLCB7IHBydW5lZCB9KTtcclxuICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICAgIGlmIChzZXR0aW5ncy5wYXQgJiYgc2V0dGluZ3Mub3duZXIgJiYgc2V0dGluZ3MucmVwbykge1xyXG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcclxuICAgICAgYXdhaXQgcmVmcmVzaEFjY291bnRzTGlzdChmYWxzZSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcclxuICAgICAgICBzdGF0dXM6ICdub3QtY29uZmlndXJlZCcsXHJcbiAgICAgICAgbG9naW46IG51bGwsXHJcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgZXJyb3I6IG51bGwsXHJcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcclxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxyXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXHJcbiAgICAgIH0pO1xyXG4gICAgICBhd2FpdCBpbmZvKCdleHRlbnNpb24gYXdha2U7IHNldHRpbmdzIGluY29tcGxldGUnLCB7IHJlYXNvbiB9KTtcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IGxvZ0Vycignd2FrZSBmYWlsZWQnLCB7IHJlYXNvbiwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFJlLWluamVjdCB0aGUgTUFJTi13b3JsZCBwYWdlLWhvb2sgKyBpc29sYXRlZC13b3JsZCBjb250ZW50IHNjcmlwdCBpbnRvXHJcbiAqIGV2ZXJ5IGFscmVhZHktb3BlbiB4LmNvbSAvIHR3aXR0ZXIuY29tIHRhYi5cclxuICpcclxuICogTWFuaWZlc3QgY29udGVudF9zY3JpcHRzIG9ubHkgaW5qZWN0IG9uIGZyZXNoIG5hdmlnYXRpb24gKHJ1bl9hdDpcclxuICogZG9jdW1lbnRfc3RhcnQpLiBXaGVuIHRoZSB1c2VyIHJlbG9hZHMgdGhlIGV4dGVuc2lvbiB3aGlsZSBYIHRhYnMgYXJlXHJcbiAqIG9wZW4sIHRob3NlIHRhYnMga2VlcCB0aGVpciBjb250ZW50IHNjcmlwdHMgYnV0IG5ldmVyIGdldCBhIG5ldyBwYWdlLWhvb2tcclxuICogXHUyMDE0IHNvIGZldGNoL1hIUiBzdGF5cyB1bnBhdGNoZWQgYW5kIGNhcHR1cmVzIHNpbGVudGx5IGZhaWwuIERvaW5nIHRoaXMgb25cclxuICogZXZlcnkgd2FrZSBpcyBpZGVtcG90ZW50IChwYWdlLWhvb2sgaGFzIGEgVEFHIGd1YXJkKSBhbmQgY2hlYXAuXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiByZWluamVjdEludG9PcGVuVGFicygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xyXG4gIHRyeSB7XHJcbiAgICB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NvdWxkIG5vdCBxdWVyeSBvcGVuIHRhYnMnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBpZiAodGFicy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XHJcbiAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIGNvbnRpbnVlO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XHJcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcclxuICAgICAgICBmaWxlczogWydwYWdlLWhvb2suanMnXSxcclxuICAgICAgICAvLyBGaXJlZm94IDEyOCsgc3VwcG9ydHMgdGhlIE1BSU4gZXhlY3V0aW9uIHdvcmxkIHZpYSB0aGlzIEFQSSwgYnV0XHJcbiAgICAgICAgLy8gdGhlIEB0eXBlcy9maXJlZm94LXdlYmV4dC1icm93c2VyIHBhY2thZ2Ugd2UncmUgb24gc3RpbGwgb25seVxyXG4gICAgICAgIC8vIGRlY2xhcmVzICdJU09MQVRFRCcuIENhc3QgdGhyb3VnaCB0aGUgbGl0ZXJhbCB1bmlvbi5cclxuICAgICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXHJcbiAgICAgIH0pO1xyXG4gICAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcclxuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxyXG4gICAgICAgIGZpbGVzOiBbJ2NvbnRlbnQuanMnXSxcclxuICAgICAgfSk7XHJcbiAgICAgIGF3YWl0IGluZm8oJ3JlLWluamVjdGVkIHNjcmlwdHMgaW50byBvcGVuIHRhYicsIHtcclxuICAgICAgICB0YWJJZDogdGFiLmlkLFxyXG4gICAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsID8/ICcnKSxcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgLy8gU29tZSB0YWJzIChhYm91dDogcGFnZXMsIGRpc2NhcmRlZCB0YWJzLCBtaWQtbmF2aWdhdGlvbikgcmVqZWN0XHJcbiAgICAgIC8vIGV4ZWN1dGVTY3JpcHQuIFRoYXQncyBmaW5lIFx1MjAxNCB3ZSdsbCBjYXRjaCB0aGVtIG9uIHRoZSBuZXh0IHdha2Ugb3JcclxuICAgICAgLy8gd2hlbiB0aGUgdXNlciBuYXZpZ2F0ZXMuXHJcbiAgICAgIGF3YWl0IHdhcm4oJ3JlLWluamVjdCBmYWlsZWQgZm9yIHRhYjsgY29udGludWluZycsIHtcclxuICAgICAgICB0YWJJZDogdGFiLmlkLFxyXG4gICAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsID8/ICcnKSxcclxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQWxhcm1zKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdmbHVzaC1zd2VlcCcpO1xyXG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd2ZXJpZnktY29ubmVjdGlvbicpO1xyXG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgnZmx1c2gtc3dlZXAnLCB7IHBlcmlvZEluTWludXRlczogRkxVU0hfQUxBUk1fTUlOVVRFUyB9KTtcclxuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jcmVhdGUoJ3ZlcmlmeS1jb25uZWN0aW9uJywge1xyXG4gICAgcGVyaW9kSW5NaW51dGVzOiBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyAvIDYwXzAwMCxcclxuICB9KTtcclxufVxyXG5cclxuLy8gRmlyZWZveCBNVjMgYWxhcm1zIGhhdmUgYSAzMHMgbWluaW11bSBwZXJpb2QsIGJ1dCB3ZSB3YW50IHN1Yi1taW51dGVcclxuLy8gc2Nyb2xsaW5nLiBUaGUgYXV0by1zY3JvbGwgbG9vcCB0aGVyZWZvcmUgcnVucyBvbiBhbiBpbi1TVyBpbnRlcnZhbC5cclxuLy8gYGF1dG9TY3JvbGxTZXNzaW9uYCBpbiBzdG9yYWdlIGlzIHRoZSBzb3VyY2Ugb2YgdHJ1dGggZm9yIHdoZXRoZXIgdGhlIGxvb3BcclxuLy8gaXMgbWVhbnQgdG8gYmUgcnVubmluZyBcdTIwMTQgdGhlIHRpbWVyIGlzIGp1c3QgdGhlIGxvY2FsIGV4ZWN1dGlvbiBhcm0uXHJcbmxldCBhdXRvU2Nyb2xsVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xyXG5cclxuLy8gV2FpdC1mb3ItaW5nZXN0IHRpbWVvdXQ6IGlmIGEgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHRhYiBuYXZpZ2F0aW9uIGRvZXNuJ3RcclxuLy8gcHJvZHVjZSBhbiBpbmdlc3RlZCBjYXB0dXJlIHdpdGhpbiB0aGlzIG1hbnkgbXMsIGFkdmFuY2UgYW55d2F5IHNvIHdlXHJcbi8vIGRvbid0IGRlYWRsb2NrIG9uIGRlbGV0ZWQgLyA0MDQgLyBwYXl3YWxsZWQgdHdlZXRzLlxyXG5jb25zdCBJTkdFU1RfV0FJVF9NUyA9IDI1XzAwMDtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUF1dG9TY3JvbGxBbGFybSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAvLyBXYXMgdGhlIGxvb3AgcnVubmluZyBiZWZvcmUgdGhlIFNXIGV2aWN0aW9uPyBSZS1hcm0gaWYgc28uXHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgaWYgKHNlc3MgIT09IG51bGwgJiYgcy5lbmFibGVkICE9PSBmYWxzZSkge1xyXG4gICAgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcclxuICB9IGVsc2Uge1xyXG4gICAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk6IHZvaWQge1xyXG4gIGlmIChhdXRvU2Nyb2xsVGltZXIgIT09IG51bGwpIHtcclxuICAgIGNsZWFySW50ZXJ2YWwoYXV0b1Njcm9sbFRpbWVyKTtcclxuICAgIGF1dG9TY3JvbGxUaW1lciA9IG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBhcm1BdXRvU2Nyb2xsVGltZXIoaW50ZXJ2YWxTZWM6IG51bWJlcik6IHZvaWQge1xyXG4gIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XHJcbiAgY29uc3QgY2xhbXBlZCA9IE1hdGgubWluKFxyXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcclxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQoaW50ZXJ2YWxTZWMpKVxyXG4gICk7XHJcbiAgYXV0b1Njcm9sbFRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgdm9pZCBhdXRvU2Nyb2xsVGljaygpLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgdm9pZCB3YXJuKCdhdXRvLXNjcm9sbCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgICB9KTtcclxuICB9LCBjbGFtcGVkICogMTAwMCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0QXV0b1Njcm9sbExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oe1xyXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICBzY3JvbGxDb3VudDogMCxcclxuICAgIGluZ2VzdGVkQ291bnQ6IDAsXHJcbiAgICBleHBhbmRlZENvdW50OiAwLFxyXG4gIH0pO1xyXG4gIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XHJcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBzdGFydGVkJywgeyBpbnRlcnZhbF9zZWM6IHMuYXV0b1Njcm9sbEludGVydmFsU2VjIH0pO1xyXG4gIC8vIEZpcmUgb25lIGltbWVkaWF0ZSB0aWNrIHNvIHRoZSB1c2VyIHNlZXMgbW90aW9uIHJpZ2h0IGF3YXkuXHJcbiAgdm9pZCBhdXRvU2Nyb2xsVGljaygpO1xyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbEF1dG9TY3JvbGxMb29wKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24obnVsbCk7XHJcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBzY3JvbGxzOiBzZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxyXG4gICAgaW5nZXN0ZWQ6IHNlc3M/LmluZ2VzdGVkQ291bnQgPz8gMCxcclxuICAgIGV4cGFuZGVkOiBzZXNzPy5leHBhbmRlZENvdW50ID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gYXV0b1Njcm9sbFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcclxuICB0cnkge1xyXG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdhdXRvLXNjcm9sbDogdGFiIHF1ZXJ5IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gIGxldCBzY3JvbGxDb3VudCA9IDA7XHJcbiAgbGV0IGV4cGFuZGVkQ291bnQgPSAwO1xyXG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcclxuICAgIGlmICh0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJykgY29udGludWU7XHJcbiAgICBpZiAodGFiLmRpc2NhcmRlZCkgY29udGludWU7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXN1bHRzID0gKGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXHJcbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxyXG4gICAgICAgIC8vIENhc3Q6IHRoZSBAdHlwZXMvZmlyZWZveC13ZWJleHQtYnJvd3NlciB0eXBlIHNpZ25hdHVyZSBpbnNpc3RzXHJcbiAgICAgICAgLy8gYGZ1bmNgIHJldHVybnMgdm9pZCwgYnV0IHRoZSBBUEkgYWN0dWFsbHkgc3VyZmFjZXMgdGhlIHJldHVyblxyXG4gICAgICAgIC8vIHZhbHVlIHZpYSBgcmVzdWx0WzBdLnJlc3VsdGAuIFdlIHVzZSB0aGF0IGZvciB0aGUgZXhwYW5kIGNvdW50LlxyXG4gICAgICAgIGZ1bmM6ICgoKSA9PiB7XHJcbiAgICAgICAgICAvLyAxLiBDbGljayBhbnkgdmlzaWJsZSBcIlNob3cgbW9yZVwiIGxpbmtzIGluIGxvbmctdHdlZXQgYm9kaWVzIHNvIFhcclxuICAgICAgICAgIC8vICAgIGlubGluZXMgdGhlIG5vdGVfdHdlZXQgYm9keSBhbmQgb3VyIHBhZ2UtaG9vayBjYXB0dXJlcyB0aGVcclxuICAgICAgICAgIC8vICAgIGZ1bGwgdGV4dCB3aXRob3V0IHRoZSByZWZldGNoIGRldG91ci4gVHJ5IHNldmVyYWwgc2VsZWN0b3JzXHJcbiAgICAgICAgICAvLyAgICBiZWNhdXNlIFggcm90YXRlcyB0aGUgdGVzdGlkIGxhYmVsIHNlbWktcmVndWxhcmx5LlxyXG4gICAgICAgICAgY29uc3QgU0hPV19NT1JFX1NFTEVDVE9SUyA9IFtcclxuICAgICAgICAgICAgJ1tkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxyXG4gICAgICAgICAgICAnYnV0dG9uW2RhdGEtdGVzdGlkPVwidHdlZXQtdGV4dC1zaG93LW1vcmUtbGlua1wiXScsXHJcbiAgICAgICAgICAgICdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0gW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcclxuICAgICAgICAgIF07XHJcbiAgICAgICAgICBjb25zdCBjbGlja2VkID0gbmV3IFNldDxFbGVtZW50PigpO1xyXG4gICAgICAgICAgbGV0IGV4cGFuZGVkID0gMDtcclxuICAgICAgICAgIGZvciAoY29uc3Qgc2VsIG9mIFNIT1dfTU9SRV9TRUxFQ1RPUlMpIHtcclxuICAgICAgICAgICAgZm9yIChjb25zdCBlbCBvZiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsKSkpIHtcclxuICAgICAgICAgICAgICBpZiAoY2xpY2tlZC5oYXMoZWwpKSBjb250aW51ZTtcclxuICAgICAgICAgICAgICAvLyBDb25maXJtIGl0J3MgYWN0dWFsbHkgdGhlIHNob3ctbW9yZSBhZmZvcmRhbmNlIGJ5IHRleHQuXHJcbiAgICAgICAgICAgICAgY29uc3QgdCA9IChlbC50ZXh0Q29udGVudCB8fCAnJykudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgICAgICAgICAgaWYgKHQgIT09ICdzaG93IG1vcmUnICYmIHQgIT09ICdzaG93IHRoaXMgdGhyZWFkJykgY29udGludWU7XHJcbiAgICAgICAgICAgICAgY29uc3QgcmVjdCA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gICAgICAgICAgICAgIGlmIChyZWN0LndpZHRoID09PSAwIHx8IHJlY3QuaGVpZ2h0ID09PSAwKSBjb250aW51ZTtcclxuICAgICAgICAgICAgICBjbGlja2VkLmFkZChlbCk7XHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIChlbCBhcyBIVE1MRWxlbWVudCkuY2xpY2soKTtcclxuICAgICAgICAgICAgICAgIGV4cGFuZGVkICs9IDE7XHJcbiAgICAgICAgICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgICAgICAgICAvLyBpZ25vcmVcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC8vIDIuIFNjcm9sbCB0aGUgcGFnZS4gRGlzcGF0Y2ggRW5kIGtleSBmaXJzdCBzaW5jZSBtYW55IFggc3VyZmFjZXNcclxuICAgICAgICAgIC8vICAgIChsaXN0cywgc2VhcmNoLCByZXBsaWVzKSBiaW5kIHBhZ2luYXRpb24gdHJpZ2dlcnMgdG8gaXQgdmlhXHJcbiAgICAgICAgICAvLyAgICBSZWFjdCBoYW5kbGVyczsgdGhlbiBleHBsaWNpdGx5IHNjcm9sbCB0aGUgZG9jdW1lbnQuXHJcbiAgICAgICAgICBjb25zdCBvcHRzOiBLZXlib2FyZEV2ZW50SW5pdCA9IHtcclxuICAgICAgICAgICAga2V5OiAnRW5kJyxcclxuICAgICAgICAgICAgY29kZTogJ0VuZCcsXHJcbiAgICAgICAgICAgIGtleUNvZGU6IDM1LFxyXG4gICAgICAgICAgICB3aGljaDogMzUsXHJcbiAgICAgICAgICAgIGJ1YmJsZXM6IHRydWUsXHJcbiAgICAgICAgICAgIGNhbmNlbGFibGU6IHRydWUsXHJcbiAgICAgICAgICB9O1xyXG4gICAgICAgICAgY29uc3QgZm9jdXMgPSAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCB8IG51bGwpID8/IGRvY3VtZW50LmJvZHk7XHJcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXlkb3duJywgb3B0cykpO1xyXG4gICAgICAgICAgZm9jdXMuZGlzcGF0Y2hFdmVudChuZXcgS2V5Ym9hcmRFdmVudCgna2V5dXAnLCBvcHRzKSk7XHJcbiAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oe1xyXG4gICAgICAgICAgICB0b3A6IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxIZWlnaHQsXHJcbiAgICAgICAgICAgIGJlaGF2aW9yOiAnYXV0bycsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHJldHVybiB7IGV4cGFuZGVkIH07XHJcbiAgICAgICAgfSkgYXMgKCkgPT4gdm9pZCxcclxuICAgICAgfSkpIGFzIEFycmF5PHsgcmVzdWx0PzogdW5rbm93biB9PjtcclxuICAgICAgc2Nyb2xsQ291bnQgKz0gMTtcclxuICAgICAgY29uc3QgciA9IHJlc3VsdHNbMF0/LnJlc3VsdCBhcyB7IGV4cGFuZGVkPzogbnVtYmVyIH0gfCB1bmRlZmluZWQ7XHJcbiAgICAgIGlmIChyICYmIHR5cGVvZiByLmV4cGFuZGVkID09PSAnbnVtYmVyJykgZXhwYW5kZWRDb3VudCArPSByLmV4cGFuZGVkO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIFRhYnMgdGhhdCBkaXNhbGxvdyBzY3JpcHRpbmcgKGFib3V0OiwgZGlzY2FyZGVkLCBtaWQtbmF2aWdhdGlvbilcclxuICAgICAgLy8ganVzdCBnZXQgc2tpcHBlZCBcdTIwMTQgdGhleSdsbCBiZSBlbGlnaWJsZSBvbiBhIGxhdGVyIHRpY2suXHJcbiAgICB9XHJcbiAgfVxyXG4gIGlmIChzY3JvbGxDb3VudCA+IDApIHtcclxuICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xyXG4gICAgaWYgKHNlc3MgIT09IG51bGwpIHtcclxuICAgICAgc2Vzcy5zY3JvbGxDb3VudCArPSBzY3JvbGxDb3VudDtcclxuICAgICAgc2Vzcy5leHBhbmRlZENvdW50ICs9IGV4cGFuZGVkQ291bnQ7XHJcbiAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKHNlc3MpO1xyXG4gICAgICAvLyBObyBicm9hZGNhc3Qgb24gZXZlcnkgdGljayBcdTIwMTQgdGhlIDE1cyBzaWRlYmFyIHJlZnJlc2ggcGlja3MgaXQgdXAuXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5icm93c2VyLmFsYXJtcy5vbkFsYXJtLmFkZExpc3RlbmVyKChhbGFybSkgPT4ge1xyXG4gIGlmIChhbGFybS5uYW1lID09PSAnZmx1c2gtc3dlZXAnKSB7XHJcbiAgICB2b2lkIGZsdXNoSWRsZUJ1ZmZlcnMoKTtcclxuICB9IGVsc2UgaWYgKGFsYXJtLm5hbWUgPT09ICd2ZXJpZnktY29ubmVjdGlvbicpIHtcclxuICAgIHZvaWQgdmVyaWZ5Q29ubmVjdGlvbihmYWxzZSk7XHJcbiAgfVxyXG4gIC8vIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBwcmV2aW91c2x5IHJhbiB2aWEgYWxhcm1zOyB0aGV5IG5vdyB1c2VcclxuICAvLyBzZXRJbnRlcnZhbCB0byBlc2NhcGUgdGhlIDMwcyBhbGFybSBmbG9vci4gTGVhdmUgdGhlIG5hbWVzIGxpc3RlZFxyXG4gIC8vIG5vd2hlcmUgc28gYW55IG9ycGhhbmVkIGFsYXJtcyAoZnJvbSBvbGRlciBidWlsZHMpIGp1c3Qgbm8tb3AuXHJcbn0pO1xyXG5cclxuLy8gLS0tIFRvb2xiYXIgYWN0aW9uOiB0b2dnbGUgdGhlIHNpZGViYXIgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmlmIChicm93c2VyLmFjdGlvbj8ub25DbGlja2VkKSB7XHJcbiAgYnJvd3Nlci5hY3Rpb24ub25DbGlja2VkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2lkZWJhckFjdGlvbi50b2dnbGUoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAvLyBGYWxsYmFjazogb3BlbiBvcHRpb25zIGlmIHNpZGViYXIgY2FuJ3QgYmUgdG9nZ2xlZC5cclxuICAgICAgYXdhaXQgd2Fybignc2lkZWJhciB0b2dnbGUgZmFpbGVkOyBvcGVuaW5nIG9wdGlvbnMnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XHJcbiAgICB9XHJcbiAgfSk7XHJcbn1cclxuXHJcbi8vIC0tLSBSdW50aW1lIG1lc3NhZ2UgZGlzcGF0Y2ggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93biwgX3NlbmRlcikgPT4ge1xyXG4gIGlmICghaXNSdW50aW1lTWVzc2FnZShtc2cpKSByZXR1cm4gdW5kZWZpbmVkO1xyXG4gIHJldHVybiBoYW5kbGVNZXNzYWdlKG1zZykuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgdm9pZCBsb2dFcnIoJ21lc3NhZ2UgaGFuZGxlciBmYWlsZWQnLCB7IHR5cGU6IG1zZy50eXBlLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XHJcbiAgICB0aHJvdyBlcnI7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gaXNSdW50aW1lTWVzc2FnZShtOiB1bmtub3duKTogbSBpcyBSdW50aW1lTWVzc2FnZSB7XHJcbiAgcmV0dXJuICEhbSAmJiB0eXBlb2YgbSA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIChtIGFzIHsgdHlwZT86IHVua25vd24gfSkudHlwZSA9PT0gJ3N0cmluZyc7XHJcbn1cclxuXHJcbi8qKiBNZXNzYWdlcyB0aGF0IGRyaXZlIHRoZSBjYXB0dXJlIHBpcGVsaW5lLiBXaGVuIHRoZSBtYXN0ZXIgc3dpdGNoIGlzIE9GRlxyXG4gKiB3ZSBpZ25vcmUgdGhlc2UgYnV0IHN0aWxsIHJlc3BvbmQgdG8gc3RhdHVzIC8gY29uZmlndXJhdGlvbiBxdWVyaWVzLiAqL1xyXG5jb25zdCBDQVBUVVJFX1BJUEVMSU5FX01FU1NBR0VTID0gbmV3IFNldDxSdW50aW1lTWVzc2FnZVsndHlwZSddPihbXHJcbiAgJ2dyYXBocWwtY2FwdHVyZScsXHJcbiAgJ2NhcHR1cmUtbm93JyxcclxuICAnY2FwdHVyZS1hbGwnLFxyXG4gICdjYXB0dXJlLXRoaXMtcGFnZScsXHJcbiAgJ2ZsdXNoLWFsbCcsXHJcbiAgJ2ZsdXNoLWhhbmRsZScsXHJcbiAgJ3N0YXJ0LXJlZmV0Y2gnLFxyXG4gICdzdGFydC1tZWRpYS1jcmF3bCcsXHJcbiAgJ3N0YXJ0LWF1dG8tc2Nyb2xsJyxcclxuXSk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBpc0VuYWJsZWQoKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgcmV0dXJuIHMuZW5hYmxlZCAhPT0gZmFsc2U7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UobXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8dW5rbm93bj4ge1xyXG4gIC8vIE1hc3RlciBzd2l0Y2g6IHdoZW4gdGhlIHVzZXIgaGFzIHBhdXNlZCB0aGUgZXh0ZW5zaW9uIHdlIHN0aWxsIG5lZWRcclxuICAvLyB0aGUgbWV0YS1jaGFubmVscyAoZ2V0LXN0YXRlLCB0b2dnbGUtZW5hYmxlZCwgb3Blbi1vcHRpb25zLCBcdTIwMjYpIHNvIHRoZVxyXG4gIC8vIHNpZGViYXIgc3RheXMgZnVuY3Rpb25hbCwgYnV0IGFueXRoaW5nIHRoYXQgd291bGQgYWN0dWFsbHkgY2FwdHVyZSxcclxuICAvLyBjb21taXQsIG9yIGRyaXZlIGEgdGFiIGlzIGEgbm8tb3AuXHJcbiAgaWYgKCEoYXdhaXQgaXNFbmFibGVkKCkpICYmIENBUFRVUkVfUElQRUxJTkVfTUVTU0FHRVMuaGFzKG1zZy50eXBlKSkge1xyXG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHBhdXNlZDogdHJ1ZSB9O1xyXG4gIH1cclxuICBzd2l0Y2ggKG1zZy50eXBlKSB7XHJcbiAgICBjYXNlICdncmFwaHFsLWNhcHR1cmUnOlxyXG4gICAgICBhd2FpdCBvbkdyYXBocWxDYXB0dXJlKG1zZy5lbmRwb2ludCwgbXNnLnVybCwgbXNnLnBhZ2VVcmwgPz8gbnVsbCwgbXNnLnJlc3BvbnNlKTtcclxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgIGNhc2UgJ2NvbnRlbnQtYWxpdmUnOlxyXG4gICAgICBhd2FpdCBpbmZvKCdjb250ZW50IHNjcmlwdCBhbGl2ZSBvbiBwYWdlJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdwYWdlLWhvb2stYWN0aXZlJzpcclxuICAgICAgYXdhaXQgaW5mbygncGFnZSBob29rIHBhdGNoZWQgZmV0Y2gvWEhSJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdsb2ctY29udGVudC1ldmVudCc6XHJcbiAgICAgIGlmIChtc2cubGV2ZWwgPT09ICd3YXJuJykge1xyXG4gICAgICAgIGF3YWl0IHdhcm4obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAobXNnLmxldmVsID09PSAnZXJyb3InKSB7XHJcbiAgICAgICAgYXdhaXQgbG9nRXJyKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGF3YWl0IGluZm8obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgIGNhc2UgJ2dldC1zdGF0ZSc6XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdjYXB0dXJlLW5vdyc6XHJcbiAgICAgIGF3YWl0IGNhcHR1cmVOb3cobXNnLmhhbmRsZSk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdjYXB0dXJlLWFsbCc6XHJcbiAgICAgIGF3YWl0IGNhcHR1cmVBbGwoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NhcHR1cmUtdGhpcy1wYWdlJzpcclxuICAgICAgYXdhaXQgY2FwdHVyZVRoaXNQYWdlKCk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdmbHVzaC1hbGwnOlxyXG4gICAgICBhd2FpdCBmbHVzaEFsbCgndXNlcicpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnZmx1c2gtaGFuZGxlJzpcclxuICAgICAgYXdhaXQgZmx1c2hIYW5kbGUobXNnLmhhbmRsZSwgJ3VzZXInKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3RvZ2dsZS1hdXRvLWNhcHR1cmUnOlxyXG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGF1dG9DYXB0dXJlOiBtc2cub24gfSk7XHJcbiAgICAgIGF3YWl0IGluZm8oJ2F1dG8tY2FwdHVyZSB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAndG9nZ2xlLWVuYWJsZWQnOiB7XHJcbiAgICAgIGNvbnN0IHMgPSBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGVuYWJsZWQ6IG1zZy5vbiB9KTtcclxuICAgICAgaWYgKCFtc2cub24pIHtcclxuICAgICAgICAvLyBQYXVzaW5nIHN0b3BzIGFsbCBpbi1mbGlnaHQgbG9vcHMgc28gdGhlIHVzZXIgZ2V0cyBpbW1lZGlhdGVcclxuICAgICAgICAvLyBxdWlldCwgbm90IGEgXCJvbmUgbW9yZSB0aWNrXCIgc3VycHJpc2UuXHJcbiAgICAgICAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcclxuICAgICAgICBzdG9wUmVmZXRjaEludGVydmFsKCk7XHJcbiAgICAgICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xyXG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdyZWZldGNoLXRpY2snKTsgLy8gbGVnYWN5IGNsZWFudXBcclxuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignbWVkaWEtY3Jhd2wtdGljaycpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIFJlc3VtaW5nIHJlLWFybXMgYW55IGxvb3BzIHdob3NlIHNlc3Npb24gaXMgc3RpbGwgc2V0LlxyXG4gICAgICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xyXG4gICAgICAgIGlmIChzZXNzICE9PSBudWxsKSBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xyXG4gICAgICB9XHJcbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBtYXN0ZXIgc3dpdGNoIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICB9XHJcbiAgICBjYXNlICdzdGFydC1hdXRvLXNjcm9sbCc6XHJcbiAgICAgIGF3YWl0IHN0YXJ0QXV0b1Njcm9sbExvb3AoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NhbmNlbC1hdXRvLXNjcm9sbCc6XHJcbiAgICAgIGF3YWl0IGNhbmNlbEF1dG9TY3JvbGxMb29wKCk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdzZXQtYXV0by1zY3JvbGwtaW50ZXJ2YWwnOiB7XHJcbiAgICAgIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcclxuICAgICAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxyXG4gICAgICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQobXNnLnNlY29uZHMpKVxyXG4gICAgICApO1xyXG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogc2Vjb25kcyB9KTtcclxuICAgICAgLy8gUmUtYXJtIGFueSBhY3RpdmUgbG9vcHMgd2l0aCB0aGUgbmV3IGludGVydmFsLlxyXG4gICAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICAgICAgaWYgKHNlc3MgIT09IG51bGwpIGFybUF1dG9TY3JvbGxUaW1lcihzZWNvbmRzKTtcclxuICAgICAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kcyk7XHJcbiAgICAgIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHMpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgfVxyXG4gICAgY2FzZSAnc3RhcnQtcmVmZXRjaCc6XHJcbiAgICAgIGF3YWl0IHN0YXJ0UmVmZXRjaExvb3AoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NhbmNlbC1yZWZldGNoJzpcclxuICAgICAgYXdhaXQgY2FuY2VsUmVmZXRjaExvb3AoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3N0YXJ0LW1lZGlhLWNyYXdsJzpcclxuICAgICAgYXdhaXQgc3RhcnRNZWRpYUNyYXdsTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2FuY2VsLW1lZGlhLWNyYXdsJzpcclxuICAgICAgYXdhaXQgY2FuY2VsTWVkaWFDcmF3bExvb3AoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3B1cmdlLXVucmVsYXRlZCc6IHtcclxuICAgICAgY29uc3QgYWNjcyA9IGF3YWl0IGdldEFjY291bnRzKCk7XHJcbiAgICAgIGNvbnN0IHRyYWNrZWQgPSBuZXcgU2V0KGFjY3MubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKSk7XHJcbiAgICAgIGNvbnN0IHN1bW1hcnkgPSBhd2FpdCBwdXJnZVVucmVsYXRlZFN0YXRlKHRyYWNrZWQpO1xyXG4gICAgICBhd2FpdCBpbmZvKCdwdXJnZWQgdW5yZWxhdGVkIHN0YXRlJywgc3VtbWFyeSk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICB9XHJcbiAgICBjYXNlICdyZWZyZXNoLWFjY291bnRzJzpcclxuICAgICAgYXdhaXQgcmVmcmVzaEFjY291bnRzTGlzdCh0cnVlKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3ZlcmlmeS1jb25uZWN0aW9uJzpcclxuICAgICAgYXdhaXQgdmVyaWZ5Q29ubmVjdGlvbih0cnVlKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NsZWFyLWFjdGl2aXR5JzpcclxuICAgICAgYXdhaXQgY2xlYXJBY3Rpdml0eSgpO1xyXG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xyXG4gICAgY2FzZSAnb3Blbi1vcHRpb25zJzpcclxuICAgICAgYXdhaXQgYnJvd3Nlci5ydW50aW1lLm9wZW5PcHRpb25zUGFnZSgpO1xyXG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xyXG4gICAgY2FzZSAnb3Blbi12aWV3ZXInOiB7XHJcbiAgICAgIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gICAgICBjb25zdCB1cmwgPSB2aWV3ZXJVcmwocyk7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwgfSk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICB9XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAndW5rbm93biBtZXNzYWdlIHR5cGUnIH07XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0gQ2FwdHVyZSBwaXBlbGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gb25HcmFwaHFsQ2FwdHVyZShcclxuICBlbmRwb2ludDogc3RyaW5nLFxyXG4gIHVybDogc3RyaW5nLFxyXG4gIHBhZ2VVcmw6IHN0cmluZyB8IG51bGwsXHJcbiAgcmVzcG9uc2U6IHVua25vd25cclxuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgaWYgKFBST0ZJTEVfRU5EUE9JTlRTLmhhcyhlbmRwb2ludCkpIHJldHVybjsgLy8gbm90IHR3ZWV0LWJlYXJpbmdcclxuICBpZiAoIVRXRUVUX0VORFBPSU5UUy5oYXMoZW5kcG9pbnQpKSByZXR1cm47XHJcblxyXG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcclxuICAvLyBXZSBkZWxpYmVyYXRlbHkgZG8gTk9UIHNob3J0LWNpcmN1aXQgd2hlbiB0aGUgUEFUIGlzIG1pc3NpbmcuIFRoZVxyXG4gIC8vIG5vcm1hbGl6ZSBzdGVwIGlzIGNoZWFwLCB0aGUgYnVmZmVyIHN1cnZpdmVzIHNlcnZpY2Utd29ya2VyIGV2aWN0aW9uLFxyXG4gIC8vIGFuZCBvbmNlIHRoZSBQQVQgaXMgc2V0IHRoZSBuZXh0IGFsYXJtIG9yIHVzZXItdHJpZ2dlcmVkIGZsdXNoIGNvbW1pdHNcclxuICAvLyBldmVyeXRoaW5nIHdlJ3ZlIHNlZW4uIERyb3BwaW5nIGNhcHR1cmVzIGhlcmUgd2FzIGhpZGluZyB0aGUgdXNlcidzXHJcbiAgLy8gZmlyc3QgYnJvd3Npbmcgc2Vzc2lvbiBlbnRpcmVseS5cclxuXHJcbiAgLy8gVHdvLXN0YWdlIGZpbHRlcjpcclxuICAvLyAgIDEuIEJ1aWxkIEVWRVJZIGNhbm9uaWNhbCB0d2VldCB3ZSBjYW4gZmluZCBpbiB0aGUgcmVzcG9uc2UgKG5vIGhhbmRsZVxyXG4gIC8vICAgICAgZmlsdGVyIGF0IHRoZSBub3JtYWxpemVyIGxldmVsIFx1MjAxNCB3ZSBzdGlsbCB3YW50IHF1b3RlZC9SVCdkIHBhcmVudHNcclxuICAvLyAgICAgIHRoYXQgYXBwZWFyIGFzIHNpYmxpbmcgbm9kZXMpLlxyXG4gIC8vICAgMi4gQXBwbHkgYGZpbHRlclJlbGF0ZWRgIHBvc3QtaG9jIHRvIGRyb3AgYW55dGhpbmcgdGhhdCBoYXMgbm9cclxuICAvLyAgICAgIHJlbGF0aW9uc2hpcCB0byBhIHRyYWNrZWQgYWNjb3VudC4gVGhlIG9sZCBiZWhhdmlvdXIgKFwiZW1wdHlcclxuICAvLyAgICAgIGFsbG93ZWQtc2V0IG9uIHVzZXItcGFnZSBlbmRwb2ludHMsIGZ1bGwgZmlsdGVyIG9uIGhvbWUvc2VhcmNoXCIpXHJcbiAgLy8gICAgICB3YXMgd2F5IHRvbyBwZXJtaXNzaXZlIG9uIHRoZSBSZXBsaWVzIHRhYjogZXZlcnkgcmFuZG9tIHJlcGxpZXInc1xyXG4gIC8vICAgICAgcmVwbHkgbGFuZGVkIGluIGEgcGVyLWhhbmRsZSBidWZmZXIga2V5ZWQgYnkgdGhlaXIgb3duIGhhbmRsZS5cclxuICBjb25zdCB0cmFja2VkID0gbmV3IFNldChhY2NvdW50cy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcclxuICBjb25zdCBjYXB0dXJlZEF0ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xyXG5cclxuICBsZXQgbm9ybWFsaXplZDtcclxuICB0cnkge1xyXG4gICAgbm9ybWFsaXplZCA9IG5vcm1hbGl6ZShyZXNwb25zZSwge1xyXG4gICAgICBjYXB0dXJlZEF0LFxyXG4gICAgICBydW5JZDogJ3BlbmRpbmcnLFxyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgYWxsb3dlZEhhbmRsZXM6IG5ldyBTZXQ8c3RyaW5nPigpLFxyXG4gICAgICBzb3VyY2VVcmw6IHBhZ2VVcmwsXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHF1YXJhbnRpbmUoJ25vcm1hbGl6ZS10aHJldycsIGVuZHBvaW50LCB1cmwsIHJlc3BvbnNlLCBlcnIpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICAvLyBEcm9wIHVucmVsYXRlZCB0d2VldHMuIFRoZSBmaWx0ZXIgaXMgZW5kcG9pbnQtYXdhcmU6XHJcbiAgLy8gICAtIE9uIHRoZSBob21lIC8gc2VhcmNoIHRpbWVsaW5lcyB3ZSdkIGFscmVhZHkgYmVlbiBmaWx0ZXJpbmcgdG9cclxuICAvLyAgICAgdHJhY2tlZCBhdXRob3JzIG9ubHkgXHUyMDE0IGtlZXAgdGhhdCBiZWhhdmlvdXIgYnV0IGdvIHRocm91Z2ggdGhlIHNhbWVcclxuICAvLyAgICAgYGZpbHRlclJlbGF0ZWRgIGhlbHBlciBzbyB0aGUgcnVsZXMgYXJlIHVuaWZvcm0uXHJcbiAgLy8gICAtIE9uIHVzZXItcGFnZSBlbmRwb2ludHMgd2Ugbm93IGFsc28gZHJvcCBhbnl0aGluZyB0aGF0IGlzbid0IGVpdGhlclxyXG4gIC8vICAgICBhdXRob3JlZC1ieSwgbWVudGlvbmluZywgcmVwbHlpbmctdG8sIG9yIHJlZmVyZW5jZWQtYnkgYSB0cmFja2VkXHJcbiAgLy8gICAgIGFjY291bnQuXHJcbiAgY29uc3QgYmVmb3JlRmlsdGVyID0gbm9ybWFsaXplZC50d2VldHMubGVuZ3RoO1xyXG4gIG5vcm1hbGl6ZWQudHdlZXRzID0gZmlsdGVyUmVsYXRlZChub3JtYWxpemVkLnR3ZWV0cywgdHJhY2tlZCk7XHJcbiAgY29uc3QgZHJvcHBlZFVucmVsYXRlZCA9IGJlZm9yZUZpbHRlciAtIG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aDtcclxuICBpZiAoZHJvcHBlZFVucmVsYXRlZCA+IDApIHtcclxuICAgIGF3YWl0IGluZm8oJ2Ryb3BwZWQgdW5yZWxhdGVkIHR3ZWV0cycsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIGRyb3BwZWQ6IGRyb3BwZWRVbnJlbGF0ZWQsXHJcbiAgICAgIGtlcHQ6IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCxcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLy8gRGlhZ25vc3RpYzogZXZlcnkgdHdlZXQtZW5kcG9pbnQgcGF5bG9hZCBnZXRzIGEgbGluZSBpbiB0aGUgYWN0aXZpdHlcclxuICAvLyB0YWlsIHdpdGggd2hhdCB3ZSBzYXcgdnMga2VwdC4gV2hlbiBvYnNlcnZlZD0wIHdlIGFsc28gZW1pdCBhIHNoYXBlXHJcbiAgLy8gcHJvYmUgKGtleSBwYXRocyArIHR5cGVuYW1lcykgc28gd2UgY2FuIHRlbGwgd2hldGhlciBYIHJldHVybmVkIGFuXHJcbiAgLy8gZW1wdHkgZW52ZWxvcGUsIGEgbG9naW4td2FsbCByZXNwb25zZSwgb3IgYSBuZXcgc2hhcGUgd2UgZG9uJ3Qga25vdyBob3dcclxuICAvLyB0byB3YWxrIHlldC5cclxuICBpZiAobm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdncmFwaHFsIHBheWxvYWQgZW1wdHkgXHUyMDE0IHNoYXBlIHByb2JlJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgdHlwZW5hbWVzOiBwcm9iZVR5cGVuYW1lcyhyZXNwb25zZSkuc2xpY2UoMCwgMzApLFxyXG4gICAgICB0d2VldF9rZXlzOiBwcm9iZUZpcnN0VHlwZVNoYXBlKHJlc3BvbnNlLCAnVHdlZXQnKSxcclxuICAgICAgdHdlZXRfY29yZV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbJ2NvcmUnXSksXHJcbiAgICAgIHR3ZWV0X2xlZ2FjeV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbJ2xlZ2FjeSddKSxcclxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXHJcbiAgICAgICAgJ2NvcmUnLFxyXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxyXG4gICAgICAgICdyZXN1bHQnLFxyXG4gICAgICBdKSxcclxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9jb3JlX2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcclxuICAgICAgICAnY29yZScsXHJcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXHJcbiAgICAgICAgJ3Jlc3VsdCcsXHJcbiAgICAgICAgJ2NvcmUnLFxyXG4gICAgICBdKSxcclxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9sZWdhY3lfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xyXG4gICAgICAgICdjb3JlJyxcclxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcclxuICAgICAgICAncmVzdWx0JyxcclxuICAgICAgICAnbGVnYWN5JyxcclxuICAgICAgXSksXHJcbiAgICB9KTtcclxuICB9IGVsc2Uge1xyXG4gICAgYXdhaXQgaW5mbygnZ3JhcGhxbCBwYXlsb2FkIHNlZW4nLCB7XHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICBvYnNlcnZlZDogbm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoLFxyXG4gICAgICBrZXB0OiBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGgsXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGlmIChub3JtYWxpemVkLnVuYXZhaWxhYmxlX3R3ZWV0cy5sZW5ndGggPiAwKSB7XHJcbiAgICBhd2FpdCByZWNvcmRVbmF2YWlsYWJsZVR3ZWV0cyhub3JtYWxpemVkLnVuYXZhaWxhYmxlX3R3ZWV0cywgdHJhY2tlZCwgY2FwdHVyZWRBdCwgdXJsLCBlbmRwb2ludCk7XHJcbiAgfVxyXG5cclxuICBpZiAobm9ybWFsaXplZC50d2VldHMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gIC8vIFJlZmV0Y2ggcXVldWUgaG91c2VrZWVwaW5nIFx1MjAxNCBydW5zIEJFRk9SRSB0aGUgZGVkdXAgc2hvcnQtY2lyY3VpdC4gQVxyXG4gIC8vIHJlZmV0Y2ggY2FwdHVyZSBjb21lcyBiYWNrIHdpdGggdGhlIHNhbWUgZW5nYWdlbWVudCBjb3VudHMgKHdlJ3JlXHJcbiAgLy8gb25seSBhZnRlciB0aGUgZnVsbCB0ZXh0KSwgc28gdGhlIGRlZHVwIGJlbG93IHdvdWxkIHNpbGVudGx5IGRyb3BcclxuICAvLyBpdCBhbmQgdGhlIHF1ZXVlIHdvdWxkIG5ldmVyIGRyYWluLiBIb2lzdCB0aGUgZW5xdWV1ZS9kZXF1ZXVlIGhlcmVcclxuICAvLyBzbyB0aGUgbG9vcCByZWxpYWJseSBhZHZhbmNlcyBldmVuIHdoZW4gbm8gY29tbWl0IGhhcHBlbnMuXHJcbiAgLy9cclxuICAvLyBBbHNvOiBpZiBlaXRoZXIgbG9vcCdzIGluZmxpZ2h0IHRhcmdldCBhcHBlYXJzIGhlcmUsIG1hcmsgdGhlIGxvb3BcclxuICAvLyBhcyBcImluZ2VzdGVkXCIgc28gdGhlIG5leHQgdGljayBjYW4gYWR2YW5jZS4gVGhlIHdhaXQtZm9yLWluZ2VzdFxyXG4gIC8vIGd1YXJkIG90aGVyd2lzZSBibG9ja3MgdW50aWwgdGhlIG5hdmlnYXRpb24tdGltZW91dCBmaXJlcy5cclxuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XHJcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xyXG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xyXG4gICAgaWYgKHQuaXNfdHJ1bmNhdGVkKSB7XHJcbiAgICAgIGF3YWl0IGVucXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2godC5hY2NvdW50X2hhbmRsZSwgdC50d2VldF9pZCk7XHJcbiAgICB9XHJcbiAgICAvLyBTdWNjZXNzZnVsbHkgYnVpbHQgdHdlZXRzIGFyZSBubyBsb25nZXIgXCJwYXJ0aWFsXCIgXHUyMDE0IGRyb3AgZnJvbSB0aGVcclxuICAgIC8vIG1lZGlhLWNyYXdsIHF1ZXVlIHJlZ2FyZGxlc3Mgb2Ygd2hpY2ggaGFuZGxlIHdlJ2QgaGludGVkIGVhcmxpZXIuXHJcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0LnR3ZWV0X2lkKTtcclxuICAgIGlmIChyZWZldGNoU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcclxuICAgICAgcmVmZXRjaFNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgICByZWZldGNoU2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24ocmVmZXRjaFNlc3MpO1xyXG4gICAgfVxyXG4gICAgaWYgKG1lZGlhQ3Jhd2xTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdC50d2VldF9pZCkge1xyXG4gICAgICBtZWRpYUNyYXdsU2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihtZWRpYUNyYXdsU2Vzcyk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXQtc2hhcGVkIG5vZGVzIHRoZSB3YWxrZXIgc2F3IGJ1dCBjb3VsZG4ndCB0dXJuXHJcbiAgLy8gaW50byBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBFbnF1ZXVlIG9ubHkgSURzIHdlIGhhdmVuJ3QgYWxyZWFkeVxyXG4gIC8vIGNvbW1pdHRlZCAodXNlci1yZXF1ZXN0ZWQgZGVkdXAgYWdhaW5zdCB0aGUgYXJjaGl2ZSkuXHJcbiAgZm9yIChjb25zdCBwYXJ0aWFsIG9mIG5vcm1hbGl6ZWQucGFydGlhbF9pZHMpIHtcclxuICAgIGlmIChhd2FpdCBpc0NvbW1pdHRlZChwYXJ0aWFsLnR3ZWV0X2lkKSkgY29udGludWU7XHJcbiAgICBhd2FpdCBlbnF1ZXVlTWVkaWFDcmF3bChwYXJ0aWFsLmhpbnRfaGFuZGxlLCBwYXJ0aWFsLnR3ZWV0X2lkKTtcclxuICB9XHJcbiAgaWYgKG5vcm1hbGl6ZWQucGFydGlhbF9pZHMubGVuZ3RoID4gMCkge1xyXG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IGVucXVldWVkIHBhcnRpYWwgY2FwdHVyZXMnLCB7XHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICBwYXJ0aWFsOiBub3JtYWxpemVkLnBhcnRpYWxfaWRzLmxlbmd0aCxcclxuICAgICAgcXVldWVfdG90YWw6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8vIENyb3NzLXNlc3Npb24gZGVkdXA6IGRyb3AgdHdlZXRzIHdlJ3ZlIGFscmVhZHkgY29tbWl0dGVkIHdpdGggaWRlbnRpY2FsXHJcbiAgLy8gZW5nYWdlbWVudCBjb3VudHMuIExpa2VzL1JUcy9yZXBsaWVzL3F1b3RlcyBzdGlsbCB0cmlnZ2VyIGEgcmVjYXB0dXJlXHJcbiAgLy8gc28gZW5nYWdlbWVudF9oaXN0b3J5IGdyb3dzIG92ZXIgdGltZS4gdmlld19jb3VudCBpcyBpbnRlbnRpb25hbGx5XHJcbiAgLy8gZXhjbHVkZWQgXHUyMDE0IGl0IGNodXJucyB0b28gZmFzdCB0byBiZSB1c2VmdWwgYXMgYSBmcmVzaG5lc3Mgc2lnbmFsLlxyXG4gIC8vIGBpc190cnVuY2F0ZWRgIGlzIHBhcnQgb2YgdGhlIHNpZ25hdHVyZSBzbyBhIHJlZmV0Y2ggdGhhdCBmbGlwc1xyXG4gIC8vIHRydW5jYXRlZFx1MjE5MmZ1bGwgaXMgdHJlYXRlZCBhcyBhIG1hdGVyaWFsIGNoYW5nZSBhbmQgZ2V0cyBjb21taXR0ZWQuXHJcbiAgY29uc3QgY29tbWl0dGVkSWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBsZXQgZGVkdXBlZFNraXBwZWQgPSAwO1xyXG4gIGNvbnN0IGxpdmVUd2VldHM6IHR5cGVvZiBub3JtYWxpemVkLnR3ZWV0cyA9IFtdO1xyXG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xyXG4gICAgY29uc3QgcHJldiA9IGNvbW1pdHRlZElkeFt0LmFjY291bnRfaGFuZGxlXT8uW3QudHdlZXRfaWRdO1xyXG4gICAgY29uc3Qgc2lnID0gZW5nYWdlbWVudFNpZyhcclxuICAgICAgdC5saWtlX2NvdW50LFxyXG4gICAgICB0LnJldHdlZXRfY291bnQsXHJcbiAgICAgIHQucmVwbHlfY291bnQsXHJcbiAgICAgIHQucXVvdGVfY291bnQsXHJcbiAgICAgIHQuaXNfdHJ1bmNhdGVkXHJcbiAgICApO1xyXG4gICAgaWYgKHByZXYgJiYgcHJldi5zaWcgPT09IHNpZykge1xyXG4gICAgICBkZWR1cGVkU2tpcHBlZCArPSAxO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGxpdmVUd2VldHMucHVzaCh0KTtcclxuICB9XHJcbiAgaWYgKGRlZHVwZWRTa2lwcGVkID4gMCkge1xyXG4gICAgYXdhaXQgaW5mbygnZGVkdXA6IHNraXBwZWQgdW5jaGFuZ2VkIHR3ZWV0cycsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIHNraXBwZWQ6IGRlZHVwZWRTa2lwcGVkLFxyXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGlmIChsaXZlVHdlZXRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG5cclxuICAvLyBHcm91cCBzdXJ2aXZpbmcgdHdlZXRzIGJ5IGF1dGhvciBoYW5kbGUuXHJcbiAgY29uc3QgYnlIYW5kbGUgPSBuZXcgTWFwPHN0cmluZywgQ2Fub25pY2FsVHdlZXRbXT4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2YgbGl2ZVR3ZWV0cykge1xyXG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUpID8/IFtdO1xyXG4gICAgYXJyLnB1c2godCk7XHJcbiAgICBieUhhbmRsZS5zZXQodC5hY2NvdW50X2hhbmRsZSwgYXJyKTtcclxuICB9XHJcblxyXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgdHdlZXRzXSBvZiBieUhhbmRsZSkge1xyXG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgdXJsLCBlbmRwb2ludCk7XHJcbiAgICBsZXQgYWRkZWQgPSAwO1xyXG4gICAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xyXG4gICAgICBjb25zdCBleGlzdGluZyA9IGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF07XHJcbiAgICAgIGlmIChleGlzdGluZykge1xyXG4gICAgICAgIC8vIFByZXNlcnZlIGZpcnN0X2NhcHR1cmVkX2F0LCBhcHBlbmQgZW5nYWdlbWVudCBzbmFwc2hvdCwgcmVmcmVzaFxyXG4gICAgICAgIC8vIGxhc3Rfc2Vlbl9hdCArIGNvdW50cyAodGhlIGxhdGVzdCBzY3JhcGUgd2lucyBmb3IgY291bnRzKS5cclxuICAgICAgICBleGlzdGluZy5sYXN0X3NlZW5fYXQgPSBjYXB0dXJlZEF0O1xyXG4gICAgICAgIGV4aXN0aW5nLmxpa2VfY291bnQgPSB0Lmxpa2VfY291bnQ7XHJcbiAgICAgICAgZXhpc3RpbmcucmV0d2VldF9jb3VudCA9IHQucmV0d2VldF9jb3VudDtcclxuICAgICAgICBleGlzdGluZy5yZXBseV9jb3VudCA9IHQucmVwbHlfY291bnQ7XHJcbiAgICAgICAgZXhpc3RpbmcucXVvdGVfY291bnQgPSB0LnF1b3RlX2NvdW50O1xyXG4gICAgICAgIGV4aXN0aW5nLnZpZXdfY291bnQgPSB0LnZpZXdfY291bnQ7XHJcbiAgICAgICAgZXhpc3RpbmcuYm9va21hcmtfY291bnQgPSB0LmJvb2ttYXJrX2NvdW50O1xyXG4gICAgICAgIGNvbnN0IGxhc3QgPSBleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnlbZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5Lmxlbmd0aCAtIDFdO1xyXG4gICAgICAgIGNvbnN0IHNuYXAgPSB0LmVuZ2FnZW1lbnRfaGlzdG9yeVswXTtcclxuICAgICAgICBpZiAoc25hcCAmJiAoIWxhc3QgfHwgbGFzdC5jYXB0dXJlZF9hdCAhPT0gc25hcC5jYXB0dXJlZF9hdCkpIHtcclxuICAgICAgICAgIGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeS5wdXNoKHNuYXApO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zdCBzdGFtcGVkOiBDYW5vbmljYWxUd2VldCA9IHsgLi4udCwgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQgfTtcclxuICAgICAgICBidWYudHdlZXRzX2J5X2lkW3QudHdlZXRfaWRdID0gc3RhbXBlZDtcclxuICAgICAgICBhZGRlZCArPSAxO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyh0LnR3ZWV0X2lkKSkge1xyXG4gICAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKCFidWYuZW5kcG9pbnRzX3NlZW4uaW5jbHVkZXMoZW5kcG9pbnQpKSBidWYuZW5kcG9pbnRzX3NlZW4ucHVzaChlbmRwb2ludCk7XHJcbiAgICBidWYubGFzdF9jYXB0dXJlX2F0ID0gY2FwdHVyZWRBdDtcclxuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XHJcbiAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KFxyXG4gICAgICBoYW5kbGUsXHJcbiAgICAgIE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCArIE9iamVjdC5rZXlzKGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fSkubGVuZ3RoXHJcbiAgICApO1xyXG4gICAgaWYgKGFkZGVkID4gMCkge1xyXG4gICAgICBhd2FpdCBpbmZvKCdjYXB0dXJlZCB0d2VldHMnLCB7XHJcbiAgICAgICAgaGFuZGxlLFxyXG4gICAgICAgIGVuZHBvaW50LFxyXG4gICAgICAgIGFkZGVkLFxyXG4gICAgICAgIHRvdGFsOiBPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGgsXHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyBCdW1wIHRoZSBhdXRvLXNjcm9sbCBwcm9ncmVzcyBzbyB0aGUgdXNlciBzZWVzIFwiWCBpbmdlc3RlZFwiIHRpY2sgdXBcclxuICAgICAgLy8gaW4gcmVhbCB0aW1lLiBXZSBjb3VudCBhY3R1YWxseS1uZXcgdHdlZXRzLCBub3QgZHVwbGljYXRlcy5cclxuICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICAgICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xyXG4gICAgICAgIGFzU2Vzcy5pbmdlc3RlZENvdW50ICs9IGFkZGVkO1xyXG4gICAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKGFzU2Vzcyk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmIChPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggPj0gRkxVU0hfVFdFRVRfVEhSRVNIT0xEKSB7XHJcbiAgICAgIGF3YWl0IGZsdXNoSGFuZGxlKGhhbmRsZSwgJ3RocmVzaG9sZCcpO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiByZWNvcmRVbmF2YWlsYWJsZVR3ZWV0cyhcclxuICB1bmF2YWlsYWJsZVR3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdLFxyXG4gIHRyYWNrZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4sXHJcbiAgY2FwdHVyZWRBdDogc3RyaW5nLFxyXG4gIHNvdXJjZVVybDogc3RyaW5nLFxyXG4gIGVuZHBvaW50OiBzdHJpbmdcclxuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgY29tbWl0dGVkSWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XHJcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xyXG4gIGxldCByZWNvcmRlZCA9IDA7XHJcbiAgbGV0IHNraXBwZWQgPSAwO1xyXG4gIGxldCBtaXNzaW5nSGFuZGxlID0gMDtcclxuXHJcbiAgZm9yIChjb25zdCB1IG9mIHVuYXZhaWxhYmxlVHdlZXRzKSB7XHJcbiAgICBjb25zdCBoYW5kbGUgPSB1LmFjY291bnRfaGFuZGxlO1xyXG4gICAgaWYgKCFoYW5kbGUpIHtcclxuICAgICAgbWlzc2luZ0hhbmRsZSArPSAxO1xyXG4gICAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh1LnR3ZWV0X2lkKTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAodHJhY2tlZC5zaXplID4gMCAmJiAhdHJhY2tlZC5oYXMoaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSB7XHJcbiAgICAgIHNraXBwZWQgKz0gMTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodS50d2VldF9pZCk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaChoYW5kbGUsIHUudHdlZXRfaWQpO1xyXG4gICAgaWYgKHJlZmV0Y2hTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdS50d2VldF9pZCkge1xyXG4gICAgICByZWZldGNoU2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICAgIHJlZmV0Y2hTZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihyZWZldGNoU2Vzcyk7XHJcbiAgICB9XHJcbiAgICBpZiAobWVkaWFDcmF3bFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB1LnR3ZWV0X2lkKSB7XHJcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgICAgbWVkaWFDcmF3bFNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG1lZGlhQ3Jhd2xTZXNzKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzaWcgPSB1bmF2YWlsYWJsZVNpZyh1KTtcclxuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbaGFuZGxlXT8uW3UudHdlZXRfaWRdO1xyXG4gICAgaWYgKHByZXY/LnNpZyA9PT0gc2lnKSB7XHJcbiAgICAgIHNraXBwZWQgKz0gMTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgc291cmNlVXJsLCBlbmRwb2ludCk7XHJcbiAgICBjb25zdCB1bmF2YWlsYWJsZUJ5SWQgPSBidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge307XHJcbiAgICB1bmF2YWlsYWJsZUJ5SWRbdS50d2VldF9pZF0gPSB1O1xyXG4gICAgYnVmLnVuYXZhaWxhYmxlX2J5X2lkID0gdW5hdmFpbGFibGVCeUlkO1xyXG4gICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHUudHdlZXRfaWQpKSB7XHJcbiAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh1LnR3ZWV0X2lkKTtcclxuICAgIH1cclxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xyXG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XHJcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xyXG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChcclxuICAgICAgaGFuZGxlLFxyXG4gICAgICBPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggKyBPYmplY3Qua2V5cyh1bmF2YWlsYWJsZUJ5SWQpLmxlbmd0aFxyXG4gICAgKTtcclxuICAgIHJlY29yZGVkICs9IDE7XHJcbiAgfVxyXG5cclxuICBpZiAocmVjb3JkZWQgPiAwIHx8IG1pc3NpbmdIYW5kbGUgPiAwIHx8IHNraXBwZWQgPiAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCd1bmF2YWlsYWJsZSB0d2VldHMgb2JzZXJ2ZWQnLCB7IGVuZHBvaW50LCByZWNvcmRlZCwgc2tpcHBlZCwgbWlzc2luZ0hhbmRsZSB9KTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gdW5hdmFpbGFibGVTaWcodTogVW5hdmFpbGFibGVUd2VldCk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGB1bmF2YWlsYWJsZXwke3UudW5hdmFpbGFibGVfcmVhc29uID8/ICcnfXwke3UudW5hdmFpbGFibGVfdGV4dCA/PyAnJ31gO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVSdW5CdWZmZXIoXHJcbiAgaGFuZGxlOiBzdHJpbmcsXHJcbiAgdHM6IHN0cmluZyxcclxuICBzb3VyY2VVcmw6IHN0cmluZyxcclxuICBlbmRwb2ludDogc3RyaW5nXHJcbik6IFByb21pc2U8UnVuQnVmZmVyPiB7XHJcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSk7XHJcbiAgaWYgKGN1cikgcmV0dXJuIGN1cjtcclxuICBjb25zdCBidWY6IFJ1bkJ1ZmZlciA9IHtcclxuICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcclxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXHJcbiAgICBzdGFydGVkX2F0OiB0cyxcclxuICAgIGxhc3RfY2FwdHVyZV9hdDogdHMsXHJcbiAgICB0d2VldHNfYnlfaWQ6IHt9LFxyXG4gICAgdW5hdmFpbGFibGVfYnlfaWQ6IHt9LFxyXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcclxuICAgIGVuZHBvaW50c19zZWVuOiBbZW5kcG9pbnRdLFxyXG4gICAgc291cmNlX3VybDogc291cmNlVXJsLFxyXG4gIH07XHJcbiAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcclxuICBhd2FpdCBpbmZvKCdydW4gc3RhcnRlZCcsIHsgaGFuZGxlLCBydW46IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCkgfSk7XHJcbiAgcmV0dXJuIGJ1ZjtcclxufVxyXG5cclxuLy8gLS0tIEZsdXNoIGxvZ2ljIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmxldCBmbHVzaENoYWluOiBQcm9taXNlPHZvaWQ+ID0gUHJvbWlzZS5yZXNvbHZlKCk7XHJcblxyXG5pbnRlcmZhY2UgRmx1c2hJdGVtIHtcclxuICBoYW5kbGU6IHN0cmluZztcclxuICBidWY6IFJ1bkJ1ZmZlcjtcclxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W107XHJcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXTtcclxuICByYXdQYXRoOiBzdHJpbmc7XHJcbiAgc2VlblBhdGg6IHN0cmluZztcclxuICBjYXB0dXJlOiBDYXB0dXJlUGF5bG9hZDtcclxuICBzZWVuOiBTZWVuUGF5bG9hZDtcclxuICBkYXk6IHN0cmluZztcclxuICBydW5TaG9ydDogc3RyaW5nO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmbHVzaElkbGVCdWZmZXJzKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xyXG4gIGNvbnN0IGhhbmRsZXM6IHN0cmluZ1tdID0gW107XHJcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcclxuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xyXG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShsYXN0KSAmJiBub3cgLSBsYXN0ID49IEZMVVNIX0lETEVfTVMpIHtcclxuICAgICAgaGFuZGxlcy5wdXNoKGhhbmRsZSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhoYW5kbGVzLCAnaWRsZScpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgLy8gT24gd29ya2VyIHdha2UsIGFueSBidWZmZXIgb2xkZXIgdGhhbiB0aGUgaWRsZSB0aHJlc2hvbGQgZ2V0cyBhIGNoYW5jZSB0b1xyXG4gIC8vIGNvbW1pdCBpbW1lZGlhdGVseSBcdTIwMTQgdXNlZnVsIHdoZW4gdGhlIHdvcmtlciB3YXMgZXZpY3RlZCBiZWZvcmUgaWRsZS1mbHVzaC5cclxuICAvLyBJZiB0aGUgUEFUL293bmVyL3JlcG8gYXJlbid0IHNldCB3ZSdkIGp1c3QgZW1pdCBcImZsdXNoIGRlZmVycmVkXCIgZm9yIGV2ZXJ5XHJcbiAgLy8gc2luZ2xlIGhhbmRsZSBpbiBzdG9yYWdlICh0aGUgZGlhZ25vc3RpYyBzaG93ZWQgdGhpcyBmaXJpbmcgMzAwKyB0aW1lcyBpblxyXG4gIC8vIGEgcm93IHdoZW4gdGhlIGV4dGVuc2lvbiB3b2tlIGJlZm9yZSBzZXR0aW5ncyBsb2FkKSwgc28gc2hvcnQtY2lyY3VpdFxyXG4gIC8vIGhlcmUgaW5zdGVhZC5cclxuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSByZXR1cm47XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XHJcbiAgY29uc3QgaGFuZGxlczogc3RyaW5nW10gPSBbXTtcclxuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xyXG4gICAgY29uc3QgbGFzdCA9IERhdGUucGFyc2UoYnVmLmxhc3RfY2FwdHVyZV9hdCk7XHJcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xyXG4gICAgICBoYW5kbGVzLnB1c2goaGFuZGxlKTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKGhhbmRsZXMsICd3YWtlJyk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGZsdXNoQWxsKHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhPYmplY3Qua2V5cyhhbGwpLCByZWFzb24pO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmbHVzaEhhbmRsZShoYW5kbGU6IHN0cmluZywgcmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBmbHVzaEhhbmRsZXMoW2hhbmRsZV0sIHJlYXNvbik7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlcyhoYW5kbGVzOiBzdHJpbmdbXSwgcmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCB1bmlxdWUgPSBbLi4ubmV3IFNldChoYW5kbGVzKV0uZmlsdGVyKChoKSA9PiBoLmxlbmd0aCA+IDApO1xyXG4gIGlmICh1bmlxdWUubGVuZ3RoID09PSAwKSByZXR1cm47XHJcbiAgY29uc3QgcnVuID0gZmx1c2hDaGFpbi50aGVuKCgpID0+IGZsdXNoSGFuZGxlc0xvY2tlZCh1bmlxdWUsIHJlYXNvbikpO1xyXG4gIGZsdXNoQ2hhaW4gPSBydW4uY2F0Y2goKCkgPT4ge30pO1xyXG4gIHJldHVybiBydW47XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlc0xvY2tlZChoYW5kbGVzOiBzdHJpbmdbXSwgcmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgY29uc3QgaXRlbXM6IEZsdXNoSXRlbVtdID0gW107XHJcbiAgZm9yIChjb25zdCBoYW5kbGUgb2YgaGFuZGxlcykge1xyXG4gICAgY29uc3QgYnVmID0gYWxsW2hhbmRsZV07XHJcbiAgICBpZiAoIWJ1ZikgY29udGludWU7XHJcbiAgICBjb25zdCB0d2VldHMgPSBPYmplY3QudmFsdWVzKGJ1Zi50d2VldHNfYnlfaWQpO1xyXG4gICAgY29uc3QgdW5hdmFpbGFibGVUd2VldHMgPSBPYmplY3QudmFsdWVzKGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fSk7XHJcbiAgICBpZiAodHdlZXRzLmxlbmd0aCA9PT0gMCAmJiB1bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGggPT09IDApIHtcclxuICAgICAgYXdhaXQgY2xlYXJSdW5CdWZmZXIoaGFuZGxlKTtcclxuICAgICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIDApO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGl0ZW1zLnB1c2goYnVpbGRGbHVzaEl0ZW0oaGFuZGxlLCBidWYsIHR3ZWV0cywgdW5hdmFpbGFibGVUd2VldHMpKTtcclxuICB9XHJcbiAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG5cclxuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XHJcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdmbHVzaCBkZWZlcnJlZDogc2V0dGluZ3MgaW5jb21wbGV0ZScsIHtcclxuICAgICAgY291bnQ6IGl0ZW1zLmxlbmd0aCxcclxuICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxyXG4gICAgfSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xyXG4gIGNvbnN0IGZpbGVzID0gaXRlbXMuZmxhdE1hcCgoaXRlbSkgPT4gW1xyXG4gICAge1xyXG4gICAgICBwYXRoOiBpdGVtLnJhd1BhdGgsXHJcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KGl0ZW0uY2FwdHVyZSwgbnVsbCwgMikgKyAnXFxuJyksXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBwYXRoOiBpdGVtLnNlZW5QYXRoLFxyXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShpdGVtLnNlZW4sIG51bGwsIDIpICsgJ1xcbicpLFxyXG4gICAgfSxcclxuICBdKTtcclxuICBjb25zdCBjb21taXRNc2cgPSBidWlsZEJhdGNoQ29tbWl0TWVzc2FnZShpdGVtcyk7XHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQuY29tbWl0RmlsZXMoe1xyXG4gICAgICBmaWxlcyxcclxuICAgICAgbWVzc2FnZTogY29tbWl0TXNnLFxyXG4gICAgfSk7XHJcbiAgICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gICAgZm9yIChjb25zdCBpdGVtIG9mIGl0ZW1zKSB7XHJcbiAgICAgIGNvbnN0IHJlbWFpbmluZ0NvdW50ID0gYXdhaXQgY2xlYXJDb21taXR0ZWRUd2VldHNGcm9tQnVmZmVyKGl0ZW0pO1xyXG4gICAgICAvLyBDb3VudGVyIGJ1bXA6IGFjdHVhbGx5IElOQ1JFTUVOVCB0b2RheUNvdW50IGFuZCB0b3RhbENvbW1pdHRlZCBieVxyXG4gICAgICAvLyB0aGUgbnVtYmVyIG9mIHR3ZWV0cyB3ZSBqdXN0IHBlcnNpc3RlZCAodGhlIHByZXZpb3VzIGNvZGUgcmVhZCB0aGVcclxuICAgICAgLy8gZXhpc3RpbmcgdmFsdWVzIGFuZCB3cm90ZSB0aGVtIGJhY2ssIGxlYXZpbmcgdGhlIGNvdW50ZXIgcGVnZ2VkIGF0XHJcbiAgICAgIC8vIHplcm8pLlxyXG4gICAgICBjb25zdCBwcmV2ID0gKGF3YWl0IGdldENvdW50ZXJzKCkpW2l0ZW0uaGFuZGxlXTtcclxuICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xyXG4gICAgICBjb25zdCBjYXJyaWVkVG9kYXkgPSBwcmV2ICYmIHByZXYudG9kYXlEYXRlID09PSB0b2RheSA/IHByZXYudG9kYXlDb3VudCA6IDA7XHJcbiAgICAgIGF3YWl0IGJ1bXBDb3VudGVyKGl0ZW0uaGFuZGxlLCB7XHJcbiAgICAgICAgdG9kYXlDb3VudDogY2FycmllZFRvZGF5ICsgaXRlbS50d2VldHMubGVuZ3RoICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXHJcbiAgICAgICAgdG9kYXlEYXRlOiB0b2RheSxcclxuICAgICAgICBsYXN0Q2FwdHVyZUF0OiBpdGVtLmJ1Zi5sYXN0X2NhcHR1cmVfYXQsXHJcbiAgICAgICAgdG90YWxDb21taXR0ZWQ6XHJcbiAgICAgICAgICAocHJldj8udG90YWxDb21taXR0ZWQgPz8gMCkgKyBpdGVtLnR3ZWV0cy5sZW5ndGggKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCxcclxuICAgICAgICBidWZmZXJlZENvdW50OiByZW1haW5pbmdDb3VudCxcclxuICAgICAgfSk7XHJcbiAgICAgIC8vIFJlY29yZCBjb21taXRzIGluIHRoZSBkZWR1cCBpbmRleCBzbyB3ZSBkb24ndCByZS1jb21taXQgdGhlbSBuZXh0XHJcbiAgICAgIC8vIGJyb3dzZSB3aXRoIHVuY2hhbmdlZCBlbmdhZ2VtZW50LlxyXG4gICAgICBjb25zdCBpbm5lciA9IGlkeFtpdGVtLmhhbmRsZV0gPz8ge307XHJcbiAgICAgIGNvbnN0IG5vd0lzbyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxuICAgICAgZm9yIChjb25zdCB0IG9mIGl0ZW0udHdlZXRzKSB7XHJcbiAgICAgICAgaW5uZXJbdC50d2VldF9pZF0gPSB7XHJcbiAgICAgICAgICB0czogbm93SXNvLFxyXG4gICAgICAgICAgc2lnOiBlbmdhZ2VtZW50U2lnKFxyXG4gICAgICAgICAgICB0Lmxpa2VfY291bnQsXHJcbiAgICAgICAgICAgIHQucmV0d2VldF9jb3VudCxcclxuICAgICAgICAgICAgdC5yZXBseV9jb3VudCxcclxuICAgICAgICAgICAgdC5xdW90ZV9jb3VudCxcclxuICAgICAgICAgICAgdC5pc190cnVuY2F0ZWRcclxuICAgICAgICAgICksXHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG4gICAgICBmb3IgKGNvbnN0IHUgb2YgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cykge1xyXG4gICAgICAgIGlubmVyW3UudHdlZXRfaWRdID0ge1xyXG4gICAgICAgICAgdHM6IG5vd0lzbyxcclxuICAgICAgICAgIHNpZzogdW5hdmFpbGFibGVTaWcodSksXHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG4gICAgICBpZHhbaXRlbS5oYW5kbGVdID0gaW5uZXI7XHJcbiAgICAgIGF3YWl0IGluZm8oJ2ZsdXNoIGNvbW1pdHRlZCcsIHtcclxuICAgICAgICBoYW5kbGU6IGl0ZW0uaGFuZGxlLFxyXG4gICAgICAgIHJlYXNvbixcclxuICAgICAgICB0d2VldHM6IGl0ZW0udHdlZXRzLmxlbmd0aCxcclxuICAgICAgICB1bmF2YWlsYWJsZTogaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXHJcbiAgICAgICAgcnVuOiBpdGVtLnJ1blNob3J0LFxyXG4gICAgICAgIHBhdGg6IGl0ZW0ucmF3UGF0aCxcclxuICAgICAgICBiYXRjaF9jb21taXQ6IHJlc3VsdC5jb21taXRTaGEsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcclxuICAgIGF3YWl0IGluZm8oJ2ZsdXNoIGJhdGNoIGNvbW1pdHRlZCcsIHtcclxuICAgICAgcmVhc29uLFxyXG4gICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXHJcbiAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXHJcbiAgICAgIHR3ZWV0czogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApLFxyXG4gICAgICB1bmF2YWlsYWJsZTogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCwgMCksXHJcbiAgICAgIGNvbW1pdDogcmVzdWx0LmNvbW1pdFNoYSxcclxuICAgIH0pO1xyXG4gICAge1xyXG4gICAgICBjb25zdCBwcmV2ID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xyXG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcclxuICAgICAgICBzdGF0dXM6ICdvaycsXHJcbiAgICAgICAgbG9naW46IHByZXYubG9naW4sXHJcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgZXJyb3I6IG51bGwsXHJcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogcHJldi5kZWZhdWx0QnJhbmNoLFxyXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IHByZXYuY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcclxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvcikge1xyXG4gICAgICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xyXG4gICAgICBjb25zdCBzdGF0dXM6IENvbm5lY3Rpb25TdGF0ZVsnc3RhdHVzJ10gPVxyXG4gICAgICAgIGVyci5jYXRlZ29yeSA9PT0gJ2F1dGgnXHJcbiAgICAgICAgICA/ICdhdXRoLWVycm9yJ1xyXG4gICAgICAgICAgOiBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0J1xyXG4gICAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXHJcbiAgICAgICAgICAgIDogZXJyLmNhdGVnb3J5ID09PSAnbmV0d29yaydcclxuICAgICAgICAgICAgICA/ICduZXR3b3JrLWVycm9yJ1xyXG4gICAgICAgICAgICAgIDogY29ubi5zdGF0dXM7XHJcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xyXG4gICAgICAgIHN0YXR1cyxcclxuICAgICAgICBsb2dpbjogY29ubi5sb2dpbixcclxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICBlcnJvcjogZXJyLm1lc3NhZ2UsXHJcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogY29ubi5kZWZhdWx0QnJhbmNoLFxyXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGNvbm4uY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcclxuICAgICAgICByYXRlTGltaXRSZXNldEF0OlxyXG4gICAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyBlcnIucmF0ZUxpbWl0UmVzZXRBdCA6IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCxcclxuICAgICAgfSk7XHJcbiAgICAgIGF3YWl0IGxvZ0VycignZmx1c2ggZmFpbGVkJywge1xyXG4gICAgICAgIHJlYXNvbixcclxuICAgICAgICBoYW5kbGVzOiBpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uaGFuZGxlKS5zbGljZSgwLCAyMCksXHJcbiAgICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxyXG4gICAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXHJcbiAgICAgICAgY2F0ZWdvcnk6IGVyci5jYXRlZ29yeSxcclxuICAgICAgICBzdGF0dXM6IGVyci5zdGF0dXMsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyLm1lc3NhZ2UsXHJcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogZXJyLnJhdGVMaW1pdFJlc2V0QXQsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYXdhaXQgbG9nRXJyKCdmbHVzaCBmYWlsZWQnLCB7XHJcbiAgICAgICAgcmVhc29uLFxyXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcclxuICAgICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXHJcbiAgICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcclxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgLy8gTGVhdmUgYnVmZmVyIGludGFjdCBmb3IgcmV0cnkuXHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBidWlsZEZsdXNoSXRlbShcclxuICBoYW5kbGU6IHN0cmluZyxcclxuICBidWY6IFJ1bkJ1ZmZlcixcclxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10sXHJcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXVxyXG4pOiBGbHVzaEl0ZW0ge1xyXG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChidWYuc3RhcnRlZF9hdCk7XHJcbiAgY29uc3QgZGF5ID0gYnVmLnN0YXJ0ZWRfYXQuc2xpY2UoMCwgMTApO1xyXG4gIGNvbnN0IHJ1blNob3J0ID0gc2hvcnRSdW5JZChidWYucnVuX2lkKTtcclxuICBjb25zdCByYXdQYXRoID0gYHJhdy8ke2hhbmRsZX0vJHt0c30tJHtydW5TaG9ydH0uanNvbmA7XHJcbiAgY29uc3Qgc2VlblBhdGggPSBgc2Vlbi8ke2hhbmRsZX0vJHt0c30tJHtydW5TaG9ydH0uanNvbmA7XHJcbiAgcmV0dXJuIHtcclxuICAgIGhhbmRsZSxcclxuICAgIGJ1ZixcclxuICAgIHR3ZWV0cyxcclxuICAgIHVuYXZhaWxhYmxlVHdlZXRzLFxyXG4gICAgcmF3UGF0aCxcclxuICAgIHNlZW5QYXRoLFxyXG4gICAgZGF5LFxyXG4gICAgcnVuU2hvcnQsXHJcbiAgICBjYXB0dXJlOiB7XHJcbiAgICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxyXG4gICAgICBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCxcclxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcclxuICAgICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXHJcbiAgICAgIGVuZHBvaW50OiBidWYuZW5kcG9pbnRzX3NlZW4uam9pbignLCcpLFxyXG4gICAgICB1c2VyX2FnZW50OiBuYXZpZ2F0b3IudXNlckFnZW50LFxyXG4gICAgICBzb3VyY2VfdXJsOiBidWYuc291cmNlX3VybCxcclxuICAgICAgdHdlZXRzLFxyXG4gICAgICB1bmF2YWlsYWJsZV90d2VldHM6IHVuYXZhaWxhYmxlVHdlZXRzLFxyXG4gICAgfSxcclxuICAgIHNlZW46IHtcclxuICAgICAgc2NoZW1hX3ZlcnNpb246IDEsXHJcbiAgICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxyXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxyXG4gICAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcclxuICAgICAgdHdlZXRfaWRzX29ic2VydmVkOiBidWYudHdlZXRfaWRzX29ic2VydmVkLFxyXG4gICAgfSxcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBidWlsZEJhdGNoQ29tbWl0TWVzc2FnZShpdGVtczogRmx1c2hJdGVtW10pOiBzdHJpbmcge1xyXG4gIGlmIChpdGVtcy5sZW5ndGggPT09IDEpIHtcclxuICAgIGNvbnN0IGl0ZW0gPSBpdGVtc1swXSE7XHJcbiAgICBjb25zdCB1bmF2YWlsYWJsZUNvdW50ID0gaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGg7XHJcbiAgICBjb25zdCBzdWZmaXggPSB1bmF2YWlsYWJsZUNvdW50ID4gMCA/IGAsICR7dW5hdmFpbGFibGVDb3VudH0gdW5hdmFpbGFibGVgIDogJyc7XHJcbiAgICByZXR1cm4gYGNhcHR1cmU6ICR7aXRlbS5oYW5kbGV9ICR7aXRlbS5kYXl9ICR7aXRlbS50d2VldHMubGVuZ3RofSB0d2VldCR7aXRlbS50d2VldHMubGVuZ3RoID09PSAxID8gJycgOiAncyd9JHtzdWZmaXh9IChydW4gJHtpdGVtLnJ1blNob3J0fSlgO1xyXG4gIH1cclxuICBjb25zdCBkYXlzID0gWy4uLm5ldyBTZXQoaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmRheSkpXS5zb3J0KCk7XHJcbiAgY29uc3QgZGF5TGFiZWwgPSBkYXlzLmxlbmd0aCA9PT0gMSA/IGRheXNbMF0hIDogYCR7ZGF5c1swXX0uLiR7ZGF5c1tkYXlzLmxlbmd0aCAtIDFdfWA7XHJcbiAgY29uc3QgdHdlZXRDb3VudCA9IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS50d2VldHMubGVuZ3RoLCAwKTtcclxuICBjb25zdCB1bmF2YWlsYWJsZUNvdW50ID0gaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCwgMCk7XHJcbiAgY29uc3Qgc3VmZml4ID0gdW5hdmFpbGFibGVDb3VudCA+IDAgPyBgLCAke3VuYXZhaWxhYmxlQ291bnR9IHVuYXZhaWxhYmxlYCA6ICcnO1xyXG4gIHJldHVybiBgY2FwdHVyZSBiYXRjaDogJHtpdGVtcy5sZW5ndGh9IHJ1bnMsICR7dHdlZXRDb3VudH0gdHdlZXQke3R3ZWV0Q291bnQgPT09IDEgPyAnJyA6ICdzJ30ke3N1ZmZpeH0gKCR7ZGF5TGFiZWx9KWA7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNsZWFyQ29tbWl0dGVkVHdlZXRzRnJvbUJ1ZmZlcihpdGVtOiBGbHVzaEl0ZW0pOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IGN1cnJlbnQgPSBhd2FpdCBnZXRSdW5CdWZmZXIoaXRlbS5oYW5kbGUpO1xyXG4gIGlmICghY3VycmVudCkgcmV0dXJuIDA7XHJcbiAgaWYgKGN1cnJlbnQucnVuX2lkICE9PSBpdGVtLmJ1Zi5ydW5faWQpIHJldHVybiBPYmplY3Qua2V5cyhjdXJyZW50LnR3ZWV0c19ieV9pZCkubGVuZ3RoO1xyXG5cclxuICBjb25zdCBjb21taXR0ZWQgPSBuZXcgTWFwKFxyXG4gICAgaXRlbS50d2VldHMubWFwKCh0KSA9PiBbXHJcbiAgICAgIHQudHdlZXRfaWQsXHJcbiAgICAgIGVuZ2FnZW1lbnRTaWcodC5saWtlX2NvdW50LCB0LnJldHdlZXRfY291bnQsIHQucmVwbHlfY291bnQsIHQucXVvdGVfY291bnQsIHQuaXNfdHJ1bmNhdGVkKSxcclxuICAgIF0pXHJcbiAgKTtcclxuICBmb3IgKGNvbnN0IHUgb2YgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cykge1xyXG4gICAgY29tbWl0dGVkLnNldCh1LnR3ZWV0X2lkLCB1bmF2YWlsYWJsZVNpZyh1KSk7XHJcbiAgfVxyXG4gIGNvbnN0IHJlbWFpbmluZ1R3ZWV0czogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+ID0ge307XHJcbiAgZm9yIChjb25zdCBbdHdlZXRJZCwgdHdlZXRdIG9mIE9iamVjdC5lbnRyaWVzKGN1cnJlbnQudHdlZXRzX2J5X2lkKSkge1xyXG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcclxuICAgIGNvbnN0IGN1cnJlbnRTaWcgPSBlbmdhZ2VtZW50U2lnKFxyXG4gICAgICB0d2VldC5saWtlX2NvdW50LFxyXG4gICAgICB0d2VldC5yZXR3ZWV0X2NvdW50LFxyXG4gICAgICB0d2VldC5yZXBseV9jb3VudCxcclxuICAgICAgdHdlZXQucXVvdGVfY291bnQsXHJcbiAgICAgIHR3ZWV0LmlzX3RydW5jYXRlZFxyXG4gICAgKTtcclxuICAgIGlmICghY29tbWl0dGVkU2lnIHx8IGNvbW1pdHRlZFNpZyAhPT0gY3VycmVudFNpZykge1xyXG4gICAgICByZW1haW5pbmdUd2VldHNbdHdlZXRJZF0gPSB7IC4uLnR3ZWV0IH07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IHJlbWFpbmluZ1VuYXZhaWxhYmxlOiBSZWNvcmQ8c3RyaW5nLCBVbmF2YWlsYWJsZVR3ZWV0PiA9IHt9O1xyXG4gIGZvciAoY29uc3QgW3R3ZWV0SWQsIHVuYXZhaWxhYmxlXSBvZiBPYmplY3QuZW50cmllcyhjdXJyZW50LnVuYXZhaWxhYmxlX2J5X2lkID8/IHt9KSkge1xyXG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcclxuICAgIGNvbnN0IGN1cnJlbnRTaWcgPSB1bmF2YWlsYWJsZVNpZyh1bmF2YWlsYWJsZSk7XHJcbiAgICBpZiAoIWNvbW1pdHRlZFNpZyB8fCBjb21taXR0ZWRTaWcgIT09IGN1cnJlbnRTaWcpIHtcclxuICAgICAgcmVtYWluaW5nVW5hdmFpbGFibGVbdHdlZXRJZF0gPSB7IC4uLnVuYXZhaWxhYmxlIH07XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCByZW1haW5pbmdJZHMgPSBuZXcgU2V0KFtcclxuICAgIC4uLk9iamVjdC5rZXlzKHJlbWFpbmluZ1R3ZWV0cyksXHJcbiAgICAuLi5PYmplY3Qua2V5cyhyZW1haW5pbmdVbmF2YWlsYWJsZSksXHJcbiAgXSk7XHJcbiAgY29uc3QgcmVtYWluaW5nQ291bnQgPSByZW1haW5pbmdJZHMuc2l6ZTtcclxuICBpZiAocmVtYWluaW5nQ291bnQgPT09IDApIHtcclxuICAgIGF3YWl0IGNsZWFyUnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcclxuICAgIHJldHVybiAwO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgbmV4dFJ1bklkID0gbmV3UnVuSWQoKTtcclxuICBmb3IgKGNvbnN0IHR3ZWV0IG9mIE9iamVjdC52YWx1ZXMocmVtYWluaW5nVHdlZXRzKSkge1xyXG4gICAgdHdlZXQuY2FwdHVyZV9ydW5faWQgPSBuZXh0UnVuSWQ7XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSwge1xyXG4gICAgLi4uY3VycmVudCxcclxuICAgIHJ1bl9pZDogbmV4dFJ1bklkLFxyXG4gICAgc3RhcnRlZF9hdDogY3VycmVudC5sYXN0X2NhcHR1cmVfYXQsXHJcbiAgICB0d2VldHNfYnlfaWQ6IHJlbWFpbmluZ1R3ZWV0cyxcclxuICAgIHVuYXZhaWxhYmxlX2J5X2lkOiByZW1haW5pbmdVbmF2YWlsYWJsZSxcclxuICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogY3VycmVudC50d2VldF9pZHNfb2JzZXJ2ZWQuZmlsdGVyKChpZCkgPT4gcmVtYWluaW5nSWRzLmhhcyhpZCkpLFxyXG4gIH0pO1xyXG4gIGF3YWl0IGluZm8oJ2ZsdXNoIGtlcHQgbmV3ZXIgYnVmZmVyZWQgdHdlZXRzJywge1xyXG4gICAgaGFuZGxlOiBpdGVtLmhhbmRsZSxcclxuICAgIGNvbW1pdHRlZF9ydW46IGl0ZW0ucnVuU2hvcnQsXHJcbiAgICBuZXh0X3J1bjogc2hvcnRSdW5JZChuZXh0UnVuSWQpLFxyXG4gICAgcmVtYWluaW5nOiByZW1haW5pbmdDb3VudCxcclxuICB9KTtcclxuICByZXR1cm4gcmVtYWluaW5nQ291bnQ7XHJcbn1cclxuXHJcbi8vIC0tLSBDYXB0dXJlLW5vdyAvIGNhcHR1cmUtYWxsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVOb3coaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAvLyBMYW5kIG9uIHRoZSBSZXBsaWVzIHRhYiBzbyBYIGZldGNoZXMgdmlhIFVzZXJUd2VldHNBbmRSZXBsaWVzIFx1MjAxNCB0aGF0XHJcbiAgLy8gZW5kcG9pbnQgcmV0dXJucyBib3RoIHRvcC1sZXZlbCBwb3N0cyBhbmQgcmVwbGllcywgd2hpY2ggaXMgdGhlIHN1cGVyc2V0XHJcbiAgLy8gd2Ugd2FudCBmb3IgdGhlIGFyY2hpdmUuIFRoZSBwbGFpbiBgLzxoYW5kbGU+YCBVUkwgaGl0cyBVc2VyVHdlZXRzLFxyXG4gIC8vIHdoaWNoIG9taXRzIHJlcGxpZXMuIFRoZSBwYWdlLWhvb2sgaW50ZXJjZXB0cyBlaXRoZXIgZW5kcG9pbnQsIGJ1dFxyXG4gIC8vIGZvcmNpbmcgdGhlIGJyb2FkZXIgdGFiIG9uIHVzZXItaW5pdGlhdGVkIGNhcHR1cmVzIGlzIHRoZSByaWdodCBkZWZhdWx0LlxyXG4gIGNvbnN0IHRhcmdldFVybCA9IGBodHRwczovL3guY29tLyR7aGFuZGxlfS93aXRoX3JlcGxpZXNgO1xyXG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtbm93IHJlcXVlc3RlZCcsIHsgaGFuZGxlLCB0YWI6ICd3aXRoX3JlcGxpZXMnIH0pO1xyXG4gIGlmICghKGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpKSkge1xyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xyXG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwge1xyXG4gICAgICBydW5faWQ6IG5ld1J1bklkKCksXHJcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXHJcbiAgICAgIHN0YXJ0ZWRfYXQ6IG5vdyxcclxuICAgICAgbGFzdF9jYXB0dXJlX2F0OiBub3csXHJcbiAgICAgIHR3ZWV0c19ieV9pZDoge30sXHJcbiAgICAgIHVuYXZhaWxhYmxlX2J5X2lkOiB7fSxcclxuICAgICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcclxuICAgICAgZW5kcG9pbnRzX3NlZW46IFtdLFxyXG4gICAgICBzb3VyY2VfdXJsOiB0YXJnZXRVcmwsXHJcbiAgICB9KTtcclxuICB9XHJcbiAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogdGFyZ2V0VXJsLCBhY3RpdmU6IHRydWUgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVBbGwoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtYWxsIHJlcXVlc3RlZCcsIHsgY291bnQ6IGFjY291bnRzLmxlbmd0aCB9KTtcclxuICBmb3IgKGNvbnN0IGEgb2YgYWNjb3VudHMpIHtcclxuICAgIGF3YWl0IGNhcHR1cmVOb3coYS5oYW5kbGUpO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIENhcHR1cmUgd2hhdGV2ZXIgdGhlIHVzZXIgaXMgY3VycmVudGx5IGxvb2tpbmcgYXQ6IGVuc3VyZXMgcGFnZS1ob29rIGlzXHJcbiAqIHBhdGNoZWQgaW50byB0aGUgYWN0aXZlIHRhYiwgdGhlbiBudWRnZXMgdGhlIHBhZ2Ugd2l0aCBhIHByb2dyYW1tYXRpY1xyXG4gKiBzY3JvbGwgc28gWCBmaXJlcyBhbm90aGVyIGJhdGNoIG9mIEdyYXBoUUwgcmVxdWVzdHMgd2UgY2FuIGludGVyY2VwdC5cclxuICpcclxuICogTGVzcyBkaXNydXB0aXZlIHRoYW4gYENhcHR1cmUgbm93YCAobm8gbmV3IHRhYiwgbm8gbmF2aWdhdGlvbikgYW5kIHdvcmtzXHJcbiAqIGZvciBhcmJpdHJhcnkgWCBVUkxzIChzcGVjaWZpYyB0d2VldCB0aHJlYWRzLCBzZWFyY2ggcmVzdWx0cywgbGlzdHMpXHJcbiAqIHRoYXQgZG9uJ3QgbWFwIGNsZWFubHkgdG8gb25lIG9mIHRoZSBjb25maWd1cmVkIGhhbmRsZXMuXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlVGhpc1BhZ2UoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcclxuICB0cnkge1xyXG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBjb3VsZCBub3QgcXVlcnkgYWN0aXZlIHRhYicsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IHRhYiA9IHRhYnNbMF07XHJcbiAgaWYgKCF0YWIgfHwgdHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicgfHwgIXRhYi51cmwpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBubyBhY3RpdmUgdGFiJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmICghL15odHRwczpcXC9cXC8oeHx0d2l0dGVyKVxcLmNvbVxcLy8udGVzdCh0YWIudXJsKSkge1xyXG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGFjdGl2ZSB0YWIgaXMgbm90IG9uIHguY29tIC8gdHdpdHRlci5jb20nLCB7XHJcbiAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsKSxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBhd2FpdCBpbmZvKCdjYXB0dXJlLXRoaXMtcGFnZSByZXF1ZXN0ZWQnLCB7IHVybDogc2hvcnRlblVybCh0YWIudXJsKSB9KTtcclxuICAvLyAoUmUtKWluamVjdCB0aGUgcGFnZS1ob29rICsgaXNvbGF0ZWQgY29udGVudCBzY3JpcHQgc28gZmV0Y2gvWEhSIGFyZVxyXG4gIC8vIHBhdGNoZWQgZXZlbiBvbiB0YWJzIG9wZW5lZCBiZWZvcmUgdGhlIGV4dGVuc2lvbiByZWxvYWRlZC5cclxuICB0cnkge1xyXG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XHJcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXHJcbiAgICAgIGZpbGVzOiBbJ3BhZ2UtaG9vay5qcyddLFxyXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXHJcbiAgICB9KTtcclxuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxyXG4gICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiByZS1pbmplY3QgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICB9XHJcbiAgLy8gTnVkZ2UgWCB0byBmaXJlIG1vcmUgR3JhcGhRTCByZXF1ZXN0cyBieSBzY3JvbGxpbmcuIE1vc3QgdGltZWxpbmUgL1xyXG4gIC8vIGNvbnZlcnNhdGlvbiB2aWV3cyBmZXRjaCBvbiBpbnRlcnNlY3Rpb24tb2JzZXJ2ZXIgdHJpZ2dlcnMuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxyXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXHJcbiAgICAgIGZ1bmM6ICgpID0+IHtcclxuICAgICAgICBjb25zdCBoID0gd2luZG93LmlubmVySGVpZ2h0O1xyXG4gICAgICAgIHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuNSwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSksIDYwMCk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgMTIwMCk7XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBzY3JvbGwtbnVkZ2UgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLSBSZWZldGNoIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vXHJcbi8vIFggdHJ1bmNhdGVzIGxvbmcgdHdlZXRzIGluIHRpbWVsaW5lIHBheWxvYWRzIFx1MjAxNCBgbm90ZV90d2VldGAgaXMgb25seVxyXG4vLyBpbmxpbmVkIGZvciBzb21lIGVuZHBvaW50cy4gUmUtb3BlbmluZyBlYWNoIHRydW5jYXRlZCB0d2VldCdzIGRldGFpbCBwYWdlXHJcbi8vIGNhdXNlcyB0aGUgcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkuIFRoZSBsb29wXHJcbi8vIGRyaXZlcyB0aGF0IGJ5IG5hdmlnYXRpbmcgYSBzaW5nbGUgZGVkaWNhdGVkIHRhYiB0aHJvdWdoIHRoZSBxdWV1ZSwgb25lXHJcbi8vIHR3ZWV0IGF0IGEgdGltZSwgZ2F0ZWQgb24gdGhlIHBhZ2UtaG9vayBhY3R1YWxseSBpbmdlc3RpbmcgYSByZXNwb25zZSBmb3JcclxuLy8gdGhlIHR3ZWV0IHdlIGp1c3QgbmF2aWdhdGVkIHRvIChzbyBkZWxldGVkIC8gcGF5d2FsbGVkIC8gNDA0J2QgdHdlZXRzXHJcbi8vIGRvbid0IG1ha2UgdXMgc3BpbiBhbmQgc28gd2UgZG9uJ3Qgc2xhbSBYIHdpdGggcmVmcmVzaGVzIGZhc3RlciB0aGFuIHRoZVxyXG4vLyB0YWIgY2FuIGxvYWQpLlxyXG5cclxuY29uc3QgUkVGRVRDSF9UQUJfS0VZID0gJ19faW1tX2FyY2hpdmVfcmVmZXRjaF90YWJfaWRfXyc7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChSRUZFVENIX1RBQl9LRVkpO1xyXG4gIGNvbnN0IGlkID0gc3RvcmVkW1JFRkVUQ0hfVEFCX0tFWV07XHJcbiAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ251bWJlcicgPyBpZCA6IG51bGw7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hUYWJJZChpZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGlmIChpZCA9PT0gbnVsbCkge1xyXG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnJlbW92ZShSRUZFVENIX1RBQl9LRVkpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1JFRkVUQ0hfVEFCX0tFWV06IGlkIH0pO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCB0b3RhbCA9IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCk7XHJcbiAgaWYgKHRvdGFsID09PSAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoOiBub3RoaW5nIHF1ZXVlZCcpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXHJcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxyXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYykpXHJcbiAgKTtcclxuICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbih7XHJcbiAgICB0b3RhbEF0U3RhcnQ6IHRvdGFsLFxyXG4gICAgcHJvY2Vzc2VkOiAwLFxyXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICBpbmZsaWdodDogbnVsbCxcclxuICB9KTtcclxuICBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcclxuICB2b2lkIHJlZmV0Y2hUaWNrKCk7XHJcbiAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5sZXQgcmVmZXRjaEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xyXG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcclxuICByZWZldGNoSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIHJlZmV0Y2hUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ3JlZmV0Y2ggdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gICAgfSk7XHJcbiAgfSwgc2Vjb25kcyAqIDEwMDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdG9wUmVmZXRjaEludGVydmFsKCk6IHZvaWQge1xyXG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcclxuICAgIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcclxuICAgIHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSA9IG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBzdG9wUmVmZXRjaEludGVydmFsKCk7XHJcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxyXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XHJcbiAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xyXG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xyXG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xyXG4gIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcclxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xyXG4gIGlmIChzZXNzID09PSBudWxsKSB7XHJcbiAgICAvLyBMb29wIHdhcyBjYW5jZWxsZWQgb3IgbmV2ZXIgc3RhcnRlZDsgbm90aGluZyB0byBkby5cclxuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgLy8gV2FpdC1mb3ItaW5nZXN0IGd1YXJkOiBpZiB3ZSdyZSBzdGlsbCBleHBlY3RpbmcgYSBjYXB0dXJlIGZvciB0aGVcclxuICAvLyBwcmV2aW91c2x5LW5hdmlnYXRlZCB0YXJnZXQsIG9ubHkgYWR2YW5jZSBvbmNlIHdlJ3ZlIGVpdGhlciBzZWVuIHRoZVxyXG4gIC8vIGNhcHR1cmUgKG9uR3JhcGhxbENhcHR1cmUgY2xlYXJzIGBpbmZsaWdodGApIG9yIGhpdCB0aGUgdGltZW91dC5cclxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xyXG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xyXG4gICAgaWYgKGVsYXBzZWQgPCBJTkdFU1RfV0FJVF9NUykge1xyXG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgXHUyMDE0IHBhZ2UtaG9vayBtYXkgeWV0IGNhcHR1cmUgdGhlIHJlc3BvbnNlLlxyXG4gICAgfVxyXG4gICAgLy8gVGltZWQgb3V0LiBUcmVhdCBhcyBcInRoaXMgdGFyZ2V0IHdvbid0IGluZ2VzdFwiIGFuZCBkcm9wIGl0LlxyXG4gICAgYXdhaXQgd2FybigncmVmZXRjaDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXHJcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcclxuICAgIH0pO1xyXG4gICAgLy8gRmluZCB3aGljaCBoYW5kbGUgdGhpcyBpZCBpcyBxdWV1ZWQgdW5kZXIgc28gd2UgY2FuIGRlcXVldWUgaXQuXHJcbiAgICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcclxuICAgICAgaWYgKGlkcy5pbmNsdWRlcyhzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpKSB7XHJcbiAgICAgICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2goaGFuZGxlLCBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRSZWZldGNoVGFyZ2V0KCk7XHJcbiAgaWYgKCF0YXJnZXQpIHtcclxuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcclxuICAgIGF3YWl0IHNldFJlZmV0Y2hUYWJJZChudWxsKTtcclxuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xyXG4gICAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIGNvbnN0IHVybCA9IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmhhbmRsZX0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcclxuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRSZWZldGNoVGFiSWQoKTtcclxuICBpZiAodGFiSWQgIT09IG51bGwpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHRhYklkID0gbnVsbDtcclxuICAgIH1cclxuICB9XHJcbiAgdHJ5IHtcclxuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xyXG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xyXG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicpIGF3YWl0IHNldFJlZmV0Y2hUYWJJZCh0YWIuaWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XHJcbiAgICB9XHJcbiAgICBzZXNzID0gKGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCkpID8/IHNlc3M7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xyXG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIH07XHJcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcclxuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2ggdGljaycsIHtcclxuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxyXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXHJcbiAgICAgIHJlbWFpbmluZzogYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKSxcclxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcclxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxyXG4gICAgfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xyXG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaCh0YXJnZXQuaGFuZGxlLCB0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuLy8gLS0tIE1lZGlhLWNyYXdsIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy9cclxuLy8gTWlycm9ycyB0aGUgcmVmZXRjaCBsb29wIGJ1dCB0YXJnZXRzIHRoZSBtZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXRzIHRoYXRcclxuLy8gdGhlIG5vcm1hbGl6ZXIgb2JzZXJ2ZWQgdmlhIHRoZSBNZWRpYSB0YWIgLyBVc2VyTWVkaWEgZW5kcG9pbnQgd2l0aFxyXG4vLyBpbnN1ZmZpY2llbnQgZGF0YSB0byBidWlsZCBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBUaGUgY3Jhd2wgbG9vcCB3YWxrc1xyXG4vLyBhIGRlZGljYXRlZCB0YWIgdGhyb3VnaCBlYWNoIHR3ZWV0J3MgZGV0YWlsIHBhZ2UgKGhhbmRsZS1sZXNzIFVSTCBmb3JtXHJcbi8vIHdoZW4gdGhlIGhpbnQtaGFuZGxlIGlzIG1pc3NpbmcpLCBhdCB0aGUgYXV0by1zY3JvbGwgY2FkZW5jZSwgc28gdGhlXHJcbi8vIHBhZ2UtaG9vayBjYW4gY2FwdHVyZSB0aGUgcmVhbCB0d2VldCBzaGFwZS5cclxuXHJcbmNvbnN0IE1FRElBX0NSQVdMX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV9tZWRpYV9jcmF3bF90YWJfaWRfXyc7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChNRURJQV9DUkFXTF9UQUJfS0VZKTtcclxuICBjb25zdCBpZCA9IHN0b3JlZFtNRURJQV9DUkFXTF9UQUJfS0VZXTtcclxuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgaWYgKGlkID09PSBudWxsKSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKE1FRElBX0NSQVdMX1RBQl9LRVkpO1xyXG4gIGVsc2UgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtNRURJQV9DUkFXTF9UQUJfS0VZXTogaWQgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgdG90YWwgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xyXG4gIGlmICh0b3RhbCA9PT0gMCkge1xyXG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IG5vdGhpbmcgcXVldWVkJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcclxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXHJcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcclxuICApO1xyXG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHtcclxuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXHJcbiAgICBwcm9jZXNzZWQ6IDAsXHJcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIGluZmxpZ2h0OiBudWxsLFxyXG4gIH0pO1xyXG4gIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHMpO1xyXG4gIHZvaWQgbWVkaWFDcmF3bFRpY2soKTtcclxuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5sZXQgbWVkaWFDcmF3bEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xyXG4gIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwobWVkaWFDcmF3bEludGVydmFsSGFuZGxlKTtcclxuICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIG1lZGlhQ3Jhd2xUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ21lZGlhLWNyYXdsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIH0pO1xyXG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpOiB2b2lkIHtcclxuICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSB7XHJcbiAgICBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XHJcbiAgICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsTWVkaWFDcmF3bExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xyXG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXHJcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRNZWRpYUNyYXdsVGFiSWQoKTtcclxuICBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQobnVsbCk7XHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XHJcbiAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obnVsbCk7XHJcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcclxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xyXG4gIGlmIChzZXNzID09PSBudWxsKSB7XHJcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XHJcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2Uoc2Vzcy5pbmZsaWdodC5uYXZpZ2F0ZWRBdCk7XHJcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XHJcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBvbiB0aGUgcGFnZS1ob29rXHJcbiAgICB9XHJcbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXHJcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2woc2Vzcy5pbmZsaWdodC50d2VldElkKTtcclxuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTtcclxuICBpZiAoIXRhcmdldCkge1xyXG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xyXG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKG51bGwpO1xyXG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obnVsbCk7XHJcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgLy8gU2tpcCBpZiBhbHJlYWR5IGluIHRoZSBhcmNoaXZlIFx1MjAxNCBwYXJ0aWFsIGNhcHR1cmVzIGNhbiBvdXRsaXZlIGFcclxuICAvLyBzZXBhcmF0ZSBmdWxsIGNhcHR1cmUgcGF0aC5cclxuICBpZiAoYXdhaXQgaXNDb21taXR0ZWQodGFyZ2V0LnR3ZWV0SWQpKSB7XHJcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcclxuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICAvLyBNZWRpYS10YWIgb3ZlcmxheS9zdGF0dXMgcm91dGVzIGxpa2UgYC9pL3N0YXR1cy88aWQ+YCBhcmUgbm90IHJlbGlhYmxlXHJcbiAgLy8gZGV0YWlsIHBhZ2VzLiBUaGUgbm9ybWFsaXplciBzaG91bGQgcmVjb3ZlciB0aGUgYXV0aG9yIGhhbmRsZSBiZWZvcmVcclxuICAvLyBxdWV1ZWluZzsgaWYgYW4gb2xkIG9yIGRlZ3JhZGVkIHF1ZXVlIGVudHJ5IGhhcyBubyBoYW5kbGUsIHNraXAgaXRcclxuICAvLyBpbnN0ZWFkIG9mIHNlbmRpbmcgdGhlIHVzZXIgdG8gYW4gZW1wdHkgWCByb3V0ZS5cclxuICBpZiAodGFyZ2V0LmJ1Y2tldCA9PT0gJ191bmtub3duJykge1xyXG4gICAgYXdhaXQgd2FybignbWVkaWEtY3Jhd2wgdGFyZ2V0IG1pc3NpbmcgaGFuZGxlOyBza2lwcGluZyBicm9rZW4gc3RhdHVzIHJvdXRlJywge1xyXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXHJcbiAgICB9KTtcclxuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHRhcmdldC50d2VldElkKTtcclxuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuYnVja2V0fS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xyXG4gIGxldCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xyXG4gIGlmICh0YWJJZCAhPT0gbnVsbCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmdldCh0YWJJZCk7XHJcbiAgICB9IGNhdGNoIHtcclxuICAgICAgdGFiSWQgPSBudWxsO1xyXG4gICAgfVxyXG4gIH1cclxuICB0cnkge1xyXG4gICAgaWYgKHRhYklkID09PSBudWxsKSB7XHJcbiAgICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwsIGFjdGl2ZTogZmFsc2UgfSk7XHJcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkID09PSAnbnVtYmVyJykgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKHRhYi5pZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcclxuICAgIH1cclxuICAgIHNlc3MgPSAoYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKSkgPz8gc2VzcztcclxuICAgIHNlc3MuaW5mbGlnaHQgPSB7XHJcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxyXG4gICAgICBuYXZpZ2F0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgfTtcclxuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xyXG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgdGljaycsIHtcclxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxyXG4gICAgICBoaW50X2hhbmRsZTogdGFyZ2V0LmJ1Y2tldCA9PT0gJ191bmtub3duJyA/IG51bGwgOiB0YXJnZXQuYnVja2V0LFxyXG4gICAgICByZW1haW5pbmc6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXHJcbiAgICAgIHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQsXHJcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBzZXNzLnRvdGFsQXRTdGFydCxcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgYXdhaXQgd2FybignbWVkaWEtY3Jhd2wgbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuLy8gLS0tIFF1YXJhbnRpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHF1YXJhbnRpbmUoXHJcbiAgcmVhc29uOiBzdHJpbmcsXHJcbiAgZW5kcG9pbnQ6IHN0cmluZyxcclxuICB1cmw6IHN0cmluZyxcclxuICByYXc6IHVua25vd24sXHJcbiAgZXJyOiB1bmtub3duXHJcbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGxvZ0VycigncXVhcmFudGluaW5nIGNhcHR1cmUnLCB7IHJlYXNvbiwgZW5kcG9pbnQsIHVybCwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcclxuICBjb25zdCBwYXlsb2FkOiBRdWFyYW50aW5lUGF5bG9hZCA9IHtcclxuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxyXG4gICAgcmVhc29uLFxyXG4gICAgZW5kcG9pbnQsXHJcbiAgICBjYXB0dXJlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgc291cmNlX3VybDogdXJsLFxyXG4gICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKSxcclxuICAgIHJhdyxcclxuICB9O1xyXG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChwYXlsb2FkLmNhcHR1cmVkX2F0KTtcclxuICBjb25zdCBoYXNoID0gYXdhaXQgc2hhOChKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XHJcbiAgY29uc3QgcGF0aCA9IGByYXcvX3F1YXJhbnRpbmUvJHt0c30tJHtoYXNofS5qc29uYDtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XHJcbiAgICBhd2FpdCBjbGllbnQucHV0RmlsZSh7XHJcbiAgICAgIHBhdGgsXHJcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHBheWxvYWQsIG51bGwsIDIpICsgJ1xcbicpLFxyXG4gICAgICBtZXNzYWdlOiBgcXVhcmFudGluZTogJHtyZWFzb259ICR7ZW5kcG9pbnR9YCxcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKHFlcnIpIHtcclxuICAgIGF3YWl0IGxvZ0VycigncXVhcmFudGluZSBjb21taXQgZmFpbGVkJywgeyAuLi5kZXNjcmliZUVycm9yKHFlcnIpIH0pO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2hhOChzOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIGNvbnN0IGJ1ZiA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcclxuICBjb25zdCBkaWdlc3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGJ1Zik7XHJcbiAgY29uc3QgaGV4ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShkaWdlc3QpKVxyXG4gICAgLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcclxuICAgIC5qb2luKCcnKTtcclxuICByZXR1cm4gaGV4LnNsaWNlKDAsIDgpO1xyXG59XHJcblxyXG4vLyAtLS0gQ29ubmVjdGlvbiB2ZXJpZmljYXRpb24gJiBhY2NvdW50cyBsaXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5hc3luYyBmdW5jdGlvbiB2ZXJpZnlDb25uZWN0aW9uKGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xyXG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcclxuICAgICAgbG9naW46IG51bGwsXHJcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcclxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcclxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcclxuICBpZiAoIWZvcmNlKSB7XHJcbiAgICAvLyBTa2lwIGlmIHdlJ3JlIGluc2lkZSB0aGUgcmVwb3J0ZWQgcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IHJlLWNoZWNraW5nXHJcbiAgICAvLyBiZWZvcmUgcmVzZXQganVzdCB3YXN0ZXMgbW9yZSBvZiB0aGUgc2FtZSBleGhhdXN0ZWQgcXVvdGEgYW5kIGtlZXBzXHJcbiAgICAvLyB0aGUgNDAzcyBjb21pbmcuXHJcbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xyXG4gICAgICBjb25zdCBub3dTZWMgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcclxuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgLy8gQXBwbHkgdGhlIHBlcmlvZGljLWNoZWNrIGdhdGUgdG8gZXZlcnkgc3RhdHVzLCBub3QganVzdCAnb2snLiBUaGVcclxuICAgIC8vIHByZXZpb3VzIGJlaGF2aW9yIHJlLXZlcmlmaWVkIG9uIGV2ZXJ5IHdha2Ugd2hlbmV2ZXIgdGhlIGNvbm5lY3Rpb25cclxuICAgIC8vIHdhc24ndCAnb2snLCB3aGljaCBkdXJpbmcgYSByYXRlLWxpbWl0IHdpbmRvdyBtZWFudCAyIEFQSSBjYWxscyBwZXJcclxuICAgIC8vIFNXIHdha2UgKHZlcmlmeVJlcG9BY2Nlc3MgZG9lcyBHRVQgL3VzZXIgKyBHRVQgL3JlcG9zL3tvfS97cn0pLlxyXG4gICAgaWYgKGNvbm4uY2hlY2tlZEF0KSB7XHJcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGNvbm4uY2hlY2tlZEF0KTtcclxuICAgICAgaWYgKGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XHJcbiAgICB9XHJcbiAgfVxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcclxuICAgIGNvbnN0IHIgPSBhd2FpdCBjbGllbnQudmVyaWZ5UmVwb0FjY2VzcygpO1xyXG4gICAgLy8gUHJvYmUgdGhlIGNvbmZpZ3VyZWQgYnJhbmNoLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCBpcyBmaW5lIFx1MjAxNCBpdCdzXHJcbiAgICAvLyByb3V0aW5lIHRvIGNhcHR1cmUgaW50byBhIHdvcmtpbmcgYnJhbmNoIFx1MjAxNCBidXQgYSAqbWlzc2luZyogYnJhbmNoXHJcbiAgICAvLyB3b3VsZCA0MjIgZXZlcnkgY29tbWl0LlxyXG4gICAgbGV0IGJyYW5jaE9rID0gdHJ1ZTtcclxuICAgIGlmIChzZXR0aW5ncy5icmFuY2ggJiYgc2V0dGluZ3MuYnJhbmNoICE9PSByLmRlZmF1bHRfYnJhbmNoKSB7XHJcbiAgICAgIGJyYW5jaE9rID0gYXdhaXQgY2xpZW50LmJyYW5jaEV4aXN0cyhzZXR0aW5ncy5icmFuY2gpO1xyXG4gICAgfVxyXG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgIHN0YXR1czogJ29rJyxcclxuICAgICAgbG9naW46IHIubG9naW4sXHJcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgZGVmYXVsdEJyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcclxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogYnJhbmNoT2ssXHJcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXHJcbiAgICB9KTtcclxuICAgIGF3YWl0IGluZm8oJ2Nvbm5lY3Rpb24gdmVyaWZpZWQnLCB7XHJcbiAgICAgIGxvZ2luOiByLmxvZ2luLFxyXG4gICAgICByZXBvOiByLmZ1bGxfbmFtZSxcclxuICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXHJcbiAgICAgIGNvbmZpZ3VyZWRfYnJhbmNoOiBzZXR0aW5ncy5icmFuY2gsXHJcbiAgICAgIGNvbmZpZ3VyZWRfYnJhbmNoX2V4aXN0czogYnJhbmNoT2ssXHJcbiAgICB9KTtcclxuICAgIGlmICghYnJhbmNoT2spIHtcclxuICAgICAgYXdhaXQgd2FybignY29uZmlndXJlZCBicmFuY2ggZG9lcyBub3QgZXhpc3Qgb24gcmVtb3RlJywge1xyXG4gICAgICAgIGNvbmZpZ3VyZWQ6IHNldHRpbmdzLmJyYW5jaCxcclxuICAgICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcclxuICAgICAgICBmaXg6ICdvcGVuIFNldHRpbmdzIGFuZCBjaGFuZ2UgYnJhbmNoIHRvICcgKyByLmRlZmF1bHRfYnJhbmNoLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnN0IGNhdCA9IGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yID8gZXJyLmNhdGVnb3J5IDogJ3Vua25vd24nO1xyXG4gICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cclxuICAgICAgY2F0ID09PSAnYXV0aCdcclxuICAgICAgICA/ICdhdXRoLWVycm9yJ1xyXG4gICAgICAgIDogY2F0ID09PSAncmF0ZS1saW1pdCdcclxuICAgICAgICAgID8gJ3JhdGUtbGltaXRlZCdcclxuICAgICAgICAgIDogY2F0ID09PSAnbmV0d29yaydcclxuICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcclxuICAgICAgICAgICAgOiAnYXV0aC1lcnJvcic7XHJcbiAgICBjb25zdCByZXNldEF0ID1cclxuICAgICAgZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgY2F0ID09PSAncmF0ZS1saW1pdCcgPyBlcnIucmF0ZUxpbWl0UmVzZXRBdCA6IG51bGw7XHJcbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcclxuICAgICAgc3RhdHVzLFxyXG4gICAgICBsb2dpbjogbnVsbCxcclxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgIGVycm9yOiBkZXNjcmliZUVycm9yKGVycikubWVzc2FnZSxcclxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcclxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcclxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogcmVzZXRBdCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgd2FybignY29ubmVjdGlvbiBjaGVjayBmYWlsZWQnLCB7XHJcbiAgICAgIGNhdGVnb3J5OiBjYXQsXHJcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXHJcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcclxuICAgIH0pO1xyXG4gIH1cclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQWNjb3VudHNMaXN0KGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGlmICghc2V0dGluZ3MucGF0KSB7XHJcbiAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgaWYgKCFmb3JjZSkge1xyXG4gICAgLy8gU2tpcCB3aGlsZSBpbnNpZGUgYSBrbm93biByYXRlLWxpbWl0IHdpbmRvdyBcdTIwMTQgYWNjb3VudHMueWFtbCBpcyBmZXRjaGVkXHJcbiAgICAvLyB2aWEgYXV0aGVudGljYXRlZCByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLCB3aGljaCBjb3VudHMgYWdhaW5zdCB0aGVcclxuICAgIC8vIHNhbWUgcXVvdGEuXHJcbiAgICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xyXG4gICAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcclxuICAgICAgY29uc3Qgbm93U2VjID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XHJcbiAgICAgIGlmIChub3dTZWMgPCBjb25uLnJhdGVMaW1pdFJlc2V0QXQpIHJldHVybjtcclxuICAgIH1cclxuICAgIC8vIFNraXAgaWYgd2UgcmVmcmVzaGVkIHJlY2VudGx5LiBhY2NvdW50cy55YW1sIGNoYW5nZXMgcmFyZWx5IFx1MjAxNCB0aGUgb2xkXHJcbiAgICAvLyBjb2RlIHJlLWZldGNoZWQgaXQgb24gZXZlcnkgU1cgd2FrZSwgd2hpY2ggZHVyaW5nIGhlYXZ5IGJyb3dzaW5nIG1lYW50XHJcbiAgICAvLyBhIEdpdEh1YiBjYWxsIGV2ZXJ5IGZldyBzZWNvbmRzIGV2ZW4gd2hlbiBub3RoaW5nIHdhcyBiZWluZyBjYXB0dXJlZC5cclxuICAgIGNvbnN0IGxhc3RSZWZyZXNoZWQgPSBhd2FpdCBnZXRBY2NvdW50c1JlZnJlc2hlZEF0KCk7XHJcbiAgICBpZiAobGFzdFJlZnJlc2hlZCkge1xyXG4gICAgICBjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShsYXN0UmVmcmVzaGVkKTtcclxuICAgICAgaWYgKE51bWJlci5pc0Zpbml0ZShhZ2UpICYmIGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XHJcbiAgICB9XHJcbiAgfVxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcclxuICAgIGNvbnN0IHRleHQgPSBhd2FpdCBjbGllbnQuZmV0Y2hSYXdUZXh0KCdjb25maWcvYWNjb3VudHMueWFtbCcpO1xyXG4gICAgaWYgKCF0ZXh0KSB7XHJcbiAgICAgIGlmIChmb3JjZSkgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBub3QgZm91bmQgaW4gcmVwbzsgdXNpbmcgZmFsbGJhY2snKTtcclxuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XHJcbiAgICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgY29uc3QgcGFyc2VkID0gcGFyc2VBY2NvdW50c1lhbWwodGV4dCk7XHJcbiAgICBpZiAocGFyc2VkLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIHBhcnNlZCBlbXB0eTsga2VlcGluZyBmYWxsYmFjaycpO1xyXG4gICAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcclxuICAgICAgYXdhaXQgc2V0QWNjb3VudHNSZWZyZXNoZWRBdChuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcbiAgICBhd2FpdCBzZXRBY2NvdW50cyhwYXJzZWQpO1xyXG4gICAgYXdhaXQgc2V0QWNjb3VudHNSZWZyZXNoZWRBdChuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkpO1xyXG4gICAgaWYgKGZvcmNlKSBhd2FpdCBpbmZvKCdhY2NvdW50cyBsaXN0IHJlZnJlc2hlZCcsIHsgY291bnQ6IHBhcnNlZC5sZW5ndGggfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdyZWZyZXNoIGFjY291bnRzIGZhaWxlZDsga2VlcGluZyBjdXJyZW50IGxpc3QnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gIH1cclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG4vLyAtLS0gU3RhdGUgYnJvYWRjYXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5hc3luYyBmdW5jdGlvbiBicm9hZGNhc3RTdGF0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBzdGF0ZSA9IGF3YWl0IGJ1aWxkU3RhdGUoKTtcclxuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcclxuICBsZXQgdGFiQ291bnQgPSAwO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcclxuICAgIHRhYkNvdW50ID0gdGFicy5sZW5ndGg7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyB0YWJzLnF1ZXJ5IGlzIGFsbG93ZWQgYnkgdGhlIG1hbmlmZXN0IGJ1dCBjYW4gdHJhbnNpZW50bHkgZmFpbFxyXG4gICAgLy8gYXJvdW5kIGV4dGVuc2lvbiBzdGFydHVwOyBzdXJmYWNpbmcgMCBpcyBmaW5lLlxyXG4gIH1cclxuICBjb25zdCByZWZldGNoUXVldWVkID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcclxuICBjb25zdCBtZWRpYUNyYXdsUXVldWVkID0gYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTtcclxuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XHJcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xyXG4gIGNvbnN0IGF1dG9TY3JvbGxTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICByZXR1cm4ge1xyXG4gICAgdmVyc2lvbjogRVhUX1ZFUlNJT04sXHJcbiAgICBzZXR0aW5nczogcmVkYWN0U2V0dGluZ3Moc2V0dGluZ3MpLFxyXG4gICAgY29ubmVjdGlvbjogY29ubixcclxuICAgIGFjY291bnRzLFxyXG4gICAgY291bnRlcnMsXHJcbiAgICBhdXRvU2Nyb2xsOiB7XHJcbiAgICAgIGFjdGl2ZTogYXV0b1Njcm9sbFNlc3MgIT09IG51bGwgJiYgYXV0b1Njcm9sbFRpbWVyICE9PSBudWxsLFxyXG4gICAgICB0YWJDb3VudCxcclxuICAgICAgc2Nyb2xsQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxyXG4gICAgICBpbmdlc3RlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uaW5nZXN0ZWRDb3VudCA/PyAwLFxyXG4gICAgICBleHBhbmRlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uZXhwYW5kZWRDb3VudCA/PyAwLFxyXG4gICAgfSxcclxuICAgIHJlZmV0Y2hRdWV1ZToge1xyXG4gICAgICB0b3RhbDogcmVmZXRjaFF1ZXVlZCxcclxuICAgICAgcnVubmluZzogcmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsLFxyXG4gICAgICBwcm9jZXNzZWQ6IHJlZmV0Y2hTZXNzPy5wcm9jZXNzZWQgPz8gMCxcclxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHJlZmV0Y2hTZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcclxuICAgIH0sXHJcbiAgICBtZWRpYUNyYXdsUXVldWU6IHtcclxuICAgICAgdG90YWw6IG1lZGlhQ3Jhd2xRdWV1ZWQsXHJcbiAgICAgIHJ1bm5pbmc6IG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcclxuICAgICAgcHJvY2Vzc2VkOiBtZWRpYUNyYXdsU2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBtZWRpYUNyYXdsU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXHJcbiAgICB9LFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlZGFjdFNldHRpbmdzKHM6IFNldHRpbmdzKTogRXh0ZW5zaW9uU3RhdGVbJ3NldHRpbmdzJ10ge1xyXG4gIHJldHVybiB7XHJcbiAgICBvd25lcjogcy5vd25lcixcclxuICAgIHJlcG86IHMucmVwbyxcclxuICAgIGJyYW5jaDogcy5icmFuY2gsXHJcbiAgICBlbmFibGVkOiBzLmVuYWJsZWQsXHJcbiAgICBhdXRvQ2FwdHVyZTogcy5hdXRvQ2FwdHVyZSxcclxuICAgIGNvbmZpZ3VyZWRBdDogcy5jb25maWd1cmVkQXQsXHJcbiAgICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IHMuYXV0b1Njcm9sbEludGVydmFsU2VjLFxyXG4gICAgcGF0U2V0OiBzLnBhdC5sZW5ndGggPiAwLFxyXG4gICAgcGF0U3VmZml4OiBzLnBhdC5sZW5ndGggPj0gNCA/IHMucGF0LnNsaWNlKC00KSA6ICcnLFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGlzb0NvbXBhY3QoaXNvOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIC8vIDIwMjUtMDQtMTJUMTQ6MjM6MDEuMDAwWiBcdTIxOTIgMjAyNS0wNC0xMlQxNDIzMDFaXHJcbiAgY29uc3QgZCA9IG5ldyBEYXRlKGlzbyk7XHJcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBpc28ucmVwbGFjZSgvWzouXS9nLCAnJyk7XHJcbiAgY29uc3QgcGFkID0gKG46IG51bWJlciwgdyA9IDIpID0+IFN0cmluZyhuKS5wYWRTdGFydCh3LCAnMCcpO1xyXG4gIHJldHVybiAoXHJcbiAgICBgJHtkLmdldFVUQ0Z1bGxZZWFyKCl9LSR7cGFkKGQuZ2V0VVRDTW9udGgoKSArIDEpfS0ke3BhZChkLmdldFVUQ0RhdGUoKSl9YCArXHJcbiAgICBgVCR7cGFkKGQuZ2V0VVRDSG91cnMoKSl9JHtwYWQoZC5nZXRVVENNaW51dGVzKCkpfSR7cGFkKGQuZ2V0VVRDU2Vjb25kcygpKX1aYFxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHZpZXdlclVybChzOiBTZXR0aW5ncyk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGBodHRwczovLyR7cy5vd25lcn0uZ2l0aHViLmlvLyR7cy5yZXBvfS9gO1xyXG59XHJcblxyXG4vKipcclxuICogV2FsayBgbm9kZWAgY29sbGVjdGluZyBkb3R0ZWQga2V5IHBhdGhzIHVwIHRvIGBtYXhEZXB0aGAgZGVlcC4gQXJyYXlcclxuICogaW5kaWNlcyBjb2xsYXBzZSB0byBgWzBdYCAod2Ugb25seSBkZXNjZW5kIGludG8gdGhlIGZpcnN0IGVsZW1lbnQpLiBVc2VkXHJcbiAqIHRvIHN1cmZhY2UgdGhlIHN0cnVjdHVyYWwgc2tlbGV0b24gb2YgYW4gdW5mYW1pbGlhciBHcmFwaFFMIHJlc3BvbnNlXHJcbiAqIHdpdGhvdXQgaW5jbHVkaW5nIGFueSBkYXRhIHZhbHVlcy5cclxuICovXHJcbi8qKiBDb2xsZWN0IGV2ZXJ5IGRpc3RpbmN0IGBfX3R5cGVuYW1lYCB2YWx1ZSBmb3VuZCBhbnl3aGVyZSBpbiB0aGUgdHJlZS4gKi9cclxuZnVuY3Rpb24gcHJvYmVUeXBlbmFtZXMobm9kZTogdW5rbm93bik6IHN0cmluZ1tdIHtcclxuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcclxuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xyXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAobiA9PT0gbnVsbCB8fCB0eXBlb2YgbiAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XHJcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheShuKSkge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IG9iaiA9IG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcbiAgICAgIGlmICh0eXBlb2Ygb2JqLl9fdHlwZW5hbWUgPT09ICdzdHJpbmcnKSBzZWVuLmFkZChvYmouX190eXBlbmFtZSk7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBbLi4uc2Vlbl0uc29ydCgpO1xyXG59XHJcblxyXG4vKipcclxuICogRmluZCB0aGUgZmlyc3Qgbm9kZSBhbnl3aGVyZSBpbiB0aGUgdHJlZSB3aG9zZSBgX190eXBlbmFtZWAgbWF0Y2hlcyBhbmRcclxuICogcmV0dXJuIGl0cyB0b3AtbGV2ZWwga2V5IGxpc3QgKHNvcnRlZCkuIFVzZWZ1bCBmb3IgZGlzY292ZXJpbmcgd2hhdCBmaWVsZHNcclxuICogWCBpcyBhY3R1YWxseSBzaGlwcGluZyBmb3IgYSBnaXZlbiBub2RlIHR5cGUgYWZ0ZXIgYSBzY2hlbWEgY2hhbmdlLlxyXG4gKi9cclxuZnVuY3Rpb24gcHJvYmVGaXJzdFR5cGVTaGFwZShub2RlOiB1bmtub3duLCB0eXBlbmFtZTogc3RyaW5nKTogc3RyaW5nW10gfCBudWxsIHtcclxuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xyXG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XHJcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcclxuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcclxuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSB0eXBlbmFtZSkge1xyXG4gICAgICAgIHJldHVybiBPYmplY3Qua2V5cyhvYmopLnNvcnQoKTtcclxuICAgICAgfVxyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZpbmQgdGhlIGZpcnN0IG5vZGUgd2l0aCBgX190eXBlbmFtZSA9PT0gdHlwZW5hbWVgLCB0aGVuIGRlc2NlbmQgdGhyb3VnaFxyXG4gKiB0aGUgZ2l2ZW4ga2V5IHBhdGgsIGFuZCByZXR1cm4gdGhlIHRvcC1sZXZlbCBrZXlzIG9mIHdoYXRldmVyIGlzIGF0IHRoZVxyXG4gKiBlbmQuIFJldHVybnMgYSBtYXJrZXIgc3RyaW5nIHdoZW4gdGhlIHBhdGggbGVhZHMgc29tZXdoZXJlIG5vbi1vYmplY3Qgc29cclxuICogd2UgY2FuIHRlbGwgYXBhcnQgXCJhYnNlbnRcIiBmcm9tIFwicHJlc2VudCBidXQgbm90IGFuIG9iamVjdFwiLlxyXG4gKi9cclxuZnVuY3Rpb24gcHJvYmVUeXBlZE5lc3RlZChub2RlOiB1bmtub3duLCB0eXBlbmFtZTogc3RyaW5nLCBwYXRoOiBzdHJpbmdbXSk6IHVua25vd24ge1xyXG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcclxuICBsZXQgZm91bmQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCA9IG51bGw7XHJcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcclxuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcclxuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSB0eXBlbmFtZSkge1xyXG4gICAgICAgIGZvdW5kID0gb2JqO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGlmICghZm91bmQpIHJldHVybiBudWxsO1xyXG4gIGxldCBjdXI6IHVua25vd24gPSBmb3VuZDtcclxuICBmb3IgKGNvbnN0IHNlZyBvZiBwYXRoKSB7XHJcbiAgICBpZiAoY3VyID09PSBudWxsIHx8IHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSByZXR1cm4gYDwke2N1ciA9PT0gbnVsbCA/ICdudWxsJyA6IHR5cGVvZiBjdXJ9PmA7XHJcbiAgICBjdXIgPSAoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVtzZWddO1xyXG4gIH1cclxuICBpZiAoY3VyID09PSB1bmRlZmluZWQpIHJldHVybiAnPG1pc3Npbmc+JztcclxuICBpZiAoY3VyID09PSBudWxsKSByZXR1cm4gJzxudWxsPic7XHJcbiAgaWYgKHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSByZXR1cm4gYDwke3R5cGVvZiBjdXJ9PmA7XHJcbiAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkgcmV0dXJuIGA8YXJyYXkgbGVuPSR7Y3VyLmxlbmd0aH0+YDtcclxuICByZXR1cm4gT2JqZWN0LmtleXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5zb3J0KCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNob3J0ZW5VcmwodTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAvLyBBY3Rpdml0eS10YWlsIGNvbnRleHQgaXMgbW9yZSB1c2VmdWwgd2l0aCBqdXN0IHRoZSBwYXRoOyBmdWxsIFVSTHMgYmVjb21lXHJcbiAgLy8gaGFyZCB0byByZWFkIGF0IHRoZSBzaWRlYmFyJ3Mgd2lkdGguXHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHBhcnNlZCA9IG5ldyBVUkwodSk7XHJcbiAgICBjb25zdCBwYXRoID0gcGFyc2VkLnBhdGhuYW1lICsgKHBhcnNlZC5zZWFyY2ggPyAnP1x1MjAyNicgOiAnJyk7XHJcbiAgICByZXR1cm4gcGFyc2VkLmhvc3QgPT09ICd4LmNvbScgfHwgcGFyc2VkLmhvc3QgPT09ICd0d2l0dGVyLmNvbSdcclxuICAgICAgPyBwYXRoXHJcbiAgICAgIDogYCR7cGFyc2VkLmhvc3R9JHtwYXRofWA7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICByZXR1cm4gdS5sZW5ndGggPiA4MCA/IGAke3Uuc2xpY2UoMCwgODApfVx1MjAyNmAgOiB1O1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tIERldiBoZWxwZXJzIGV4cG9zZWQgb24gZ2xvYmFsVGhpcyBmb3IgdGhlIGRldnRvb2xzIGNvbnNvbGUgLS0tLS0tLS0tLVxyXG4vLyAoZS5nLiBgX19pbW1BcmNoaXZlLmNsZWFyQWxsKClgIGluIHRoZSBiYWNrZ3JvdW5kIHdvcmtlcidzIGRldnRvb2xzKS5cclxuXHJcbihnbG9iYWxUaGlzIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5fX2ltbUFyY2hpdmUgPSB7XHJcbiAgY2xlYXJBbGwsXHJcbiAgYWN0aXZpdHk6IGdldEFjdGl2aXR5LFxyXG4gIGFjY291bnRzOiBnZXRBY2NvdW50cyxcclxuICBidWZmZXJzOiBnZXRSdW5CdWZmZXJzLFxyXG4gIGZsdXNoQWxsOiAoKSA9PiBmbHVzaEFsbCgnZGV2dG9vbHMnKSxcclxuICBzdGF0ZTogYnVpbGRTdGF0ZSxcclxuICByZWZldGNoUXVldWU6IGdldFJlZmV0Y2hRdWV1ZSxcclxuICBzdGFydFJlZmV0Y2g6IHN0YXJ0UmVmZXRjaExvb3AsXHJcbiAgY2FuY2VsUmVmZXRjaDogY2FuY2VsUmVmZXRjaExvb3AsXHJcbiAgbWVkaWFDcmF3bFF1ZXVlOiBnZXRNZWRpYUNyYXdsUXVldWUsXHJcbiAgc3RhcnRNZWRpYUNyYXdsOiBzdGFydE1lZGlhQ3Jhd2xMb29wLFxyXG4gIGNhbmNlbE1lZGlhQ3Jhd2w6IGNhbmNlbE1lZGlhQ3Jhd2xMb29wLFxyXG59O1xyXG4iXSwKICAibWFwcGluZ3MiOiAiO0FBRU8sSUFBTSxtQkFBNkI7QUFBQSxFQUN4QyxLQUFLO0FBQUEsRUFDTCxPQUFPO0FBQUEsRUFDUCxNQUFNO0FBQUE7QUFBQTtBQUFBLEVBR04sUUFBUTtBQUFBLEVBQ1IsU0FBUztBQUFBLEVBQ1QsYUFBYTtBQUFBLEVBQ2IsY0FBYztBQUFBLEVBQ2QsdUJBQXVCO0FBQ3pCO0FBRU8sSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxzQkFBc0I7QUFJNUIsSUFBTSxvQkFBcUM7QUFBQSxFQUNoRCxFQUFFLFFBQVEsVUFBVSxPQUFPLG1DQUFtQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsVUFBVSxPQUFPLDRDQUE0QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsT0FBTyxPQUFPLHNDQUFzQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsU0FBUyxPQUFPLDZDQUE2QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsY0FBYyxPQUFPLG1CQUFtQixVQUFVLE9BQU87QUFBQSxFQUNuRSxFQUFFLFFBQVEsWUFBWSxPQUFPLCtCQUErQixVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLGtDQUFrQyxVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLDRCQUE0QixVQUFVLE9BQU87QUFBQSxFQUN2RSxFQUFFLFFBQVEsbUJBQW1CLE9BQU8scUJBQXFCLFVBQVUsT0FBTztBQUM1RTtBQUdPLElBQU0sa0JBQXVDLG9CQUFJLElBQUk7QUFBQSxFQUMxRDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQVdNLElBQU0sb0JBQXlDLG9CQUFJLElBQUksQ0FBQyxvQkFBb0IsY0FBYyxDQUFDO0FBdUIzRixJQUFNLHdCQUF3QjtBQUc5QixJQUFNLGdCQUFnQjtBQUd0QixJQUFNLHNCQUFzQjtBQUc1QixJQUFNLG9CQUFvQjtBQUcxQixJQUFNLGdDQUFnQyxLQUFLLEtBQUs7QUFFaEQsSUFBTSxtQkFBbUI7OztBQ3RFaEMsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0I7QUFFeEIsSUFBSSxrQkFBb0M7QUFDeEMsSUFBSSxzQkFBcUM7QUFFekMsU0FBUyxTQUFTLEtBQXlCO0FBQ3pDLE1BQUksSUFBSTtBQUNSLGFBQVcsS0FBSyxJQUFLLE1BQUssT0FBTyxhQUFhLENBQUM7QUFDL0MsU0FBTyxLQUFLLENBQUM7QUFDZjtBQUVBLFNBQVMsV0FBVyxHQUF1QjtBQUN6QyxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFFBQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxNQUFNO0FBQ3JDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUssS0FBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFDOUQsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUU7QUFDaEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDL0QsUUFBTSxJQUFJLE9BQU8sZ0JBQWdCO0FBQ2pDLE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsV0FBTyxFQUFFLFNBQVMsR0FBRyxNQUFNLFdBQVcsQ0FBQyxFQUFFO0FBQUEsRUFDM0M7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxRQUFNLFVBQVUsU0FBUyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0FBQy9ELFNBQU8sRUFBRSxTQUFTLEtBQUs7QUFDekI7QUFFQSxlQUFlLFlBQWdDO0FBQzdDLFFBQU0sRUFBRSxTQUFTLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUNqRCxNQUFJLG9CQUFvQixRQUFRLHdCQUF3QixTQUFTO0FBQy9ELFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFO0FBQUEsSUFDN0IsR0FBRyxRQUFRLFFBQVEsRUFBRSxJQUFJLFFBQVEsUUFBUSxZQUFZLEVBQUUsT0FBTztBQUFBLEVBQ2hFO0FBQ0EsUUFBTSxXQUFXLElBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNO0FBQ3pELFdBQVMsSUFBSSxNQUFNLENBQUM7QUFDcEIsV0FBUyxJQUFJLE1BQU0sS0FBSyxNQUFNO0FBQzlCLFFBQU0sT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUTtBQUMzRCxRQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLE1BQU0sRUFBRSxNQUFNLFVBQVUsR0FBRyxPQUFPO0FBQUEsSUFDakY7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBQ0Qsb0JBQWtCO0FBQ2xCLHdCQUFzQjtBQUN0QixTQUFPO0FBQ1Q7QUFFTyxTQUFTLGVBQWUsR0FBb0I7QUFDakQsU0FBTyxFQUFFLFdBQVcsZUFBZTtBQUNyQztBQUVBLGVBQXNCLFdBQVcsV0FBb0M7QUFDbkUsTUFBSSxDQUFDLFVBQVcsUUFBTztBQUN2QixRQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFFBQU0sS0FBSyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3BELFFBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLElBQzdCLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxJQUN0QjtBQUFBLElBQ0EsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTO0FBQUEsRUFDcEM7QUFDQSxTQUFPLEdBQUcsZUFBZSxHQUFHLFNBQVMsRUFBRSxDQUFDLElBQUksU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMUU7QUFFQSxlQUFzQixXQUFXLFVBQW1DO0FBQ2xFLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFHdEIsTUFBSSxDQUFDLFNBQVMsV0FBVyxlQUFlLEVBQUcsUUFBTztBQUNsRCxRQUFNLFFBQVEsU0FBUyxNQUFNLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxHQUFHO0FBQzlELE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUMvQixRQUFNLENBQUMsT0FBTyxLQUFLLElBQUk7QUFDdkIsTUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFPLFFBQU87QUFDN0IsTUFBSTtBQUNGLFVBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQzdCLEVBQUUsTUFBTSxXQUFXLEdBQXVCO0FBQUEsTUFDMUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDcEMsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7OztBQzFCQSxJQUFNLHFCQUFzQztBQUFBLEVBQzFDLFFBQVE7QUFBQSxFQUNSLE9BQU87QUFBQSxFQUNQLFdBQVc7QUFBQSxFQUNYLE9BQU87QUFBQSxFQUNQLGVBQWU7QUFBQSxFQUNmLHdCQUF3QjtBQUFBLEVBQ3hCLGtCQUFrQjtBQUNwQjtBQUVBLElBQU0sV0FBeUI7QUFBQSxFQUM3QixVQUFVLEVBQUUsR0FBRyxpQkFBaUI7QUFBQSxFQUNoQyxVQUFVLENBQUMsR0FBRyxpQkFBaUI7QUFBQSxFQUMvQixxQkFBcUI7QUFBQSxFQUNyQixZQUFZLEVBQUUsR0FBRyxtQkFBbUI7QUFBQSxFQUNwQyxVQUFVLENBQUM7QUFBQSxFQUNYLFlBQVksQ0FBQztBQUFBLEVBQ2IsVUFBVSxDQUFDO0FBQUEsRUFDWCxnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGNBQWMsQ0FBQztBQUFBLEVBQ2YsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixnQkFBZ0I7QUFBQSxFQUNoQixtQkFBbUI7QUFBQSxFQUNuQixtQkFBbUI7QUFDckI7QUFFQSxlQUFlLE9BQXFDLEtBQWtDO0FBQ3BGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksR0FBRztBQUNsRCxRQUFNLFFBQVEsT0FBTyxHQUFHO0FBQ3hCLE1BQUksVUFBVSxRQUFXO0FBQ3ZCLFdBQU8sZ0JBQWdCLFNBQVMsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxlQUFlLE9BQXFDLEtBQVEsT0FBdUM7QUFDakcsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDO0FBQ2xEO0FBSUEsZUFBc0IsY0FBaUM7QUFLckQsUUFBTSxTQUFTLE1BQU0sT0FBTyxVQUFVO0FBQ3RDLFFBQU0sU0FBUyxFQUFFLEdBQUcsa0JBQWtCLEdBQUcsT0FBTztBQUNoRCxNQUFJLE9BQU8sT0FBTyxlQUFlLE9BQU8sR0FBRyxHQUFHO0FBQzVDLFFBQUk7QUFDRixhQUFPLE1BQU0sTUFBTSxXQUFXLE9BQU8sR0FBRztBQUFBLElBQzFDLFFBQVE7QUFDTixhQUFPLE1BQU07QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLFlBQVksR0FBNEI7QUFHNUQsUUFBTSxVQUFvQixFQUFFLEdBQUcsRUFBRTtBQUNqQyxNQUFJLFFBQVEsT0FBTyxDQUFDLGVBQWUsUUFBUSxHQUFHLEdBQUc7QUFDL0MsWUFBUSxNQUFNLE1BQU0sV0FBVyxRQUFRLEdBQUc7QUFBQSxFQUM1QztBQUNBLFFBQU0sT0FBTyxZQUFZLE9BQU87QUFDbEM7QUFDQSxlQUFzQixlQUFlLE9BQTZDO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxPQUFPLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoQyxRQUFNLFlBQVksSUFBSTtBQUN0QixTQUFPO0FBQ1Q7QUFJQSxlQUFzQixjQUF3QztBQUM1RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQVksR0FBbUM7QUFDbkUsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUM1QjtBQUNBLGVBQXNCLHlCQUFpRDtBQUNyRSxTQUFPLE9BQU8scUJBQXFCO0FBQ3JDO0FBQ0EsZUFBc0IsdUJBQXVCLEtBQW1DO0FBQzlFLFFBQU0sT0FBTyx1QkFBdUIsR0FBRztBQUN6QztBQUlBLGVBQXNCLGdCQUEwQztBQUM5RCxRQUFNLElBQUksTUFBTSxPQUFPLFlBQVk7QUFFbkMsUUFBTSxNQUF1QjtBQUFBLElBQzNCLEdBQUc7QUFBQSxJQUNILGVBQWUsRUFBRSxrQkFBa0IsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUN4RCx3QkFDRSxFQUFFLDJCQUEyQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3BELGtCQUFrQixFQUFFLHFCQUFxQixTQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ2hFO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsY0FBYyxHQUFtQztBQUNyRSxRQUFNLE9BQU8sY0FBYyxDQUFDO0FBQzlCO0FBSUEsU0FBUyxXQUFtQjtBQUMxQixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDN0M7QUFFQSxlQUFzQixjQUF1RDtBQUMzRSxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQ3BCLFFBQ0EsT0FDeUI7QUFDekIsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUs7QUFBQSxJQUN6QixZQUFZO0FBQUEsSUFDWixXQUFXLFNBQVM7QUFBQSxJQUNwQixlQUFlO0FBQUEsSUFDZixnQkFBZ0I7QUFBQSxJQUNoQixlQUFlO0FBQUEsRUFDakI7QUFDQSxNQUFJLElBQUksY0FBYyxTQUFTLEdBQUc7QUFDaEMsUUFBSSxZQUFZLFNBQVM7QUFDekIsUUFBSSxhQUFhO0FBQUEsRUFDbkI7QUFDQSxRQUFNLE9BQXVCLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoRCxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsaUJBQWlCLFFBQWdCLE9BQThCO0FBQ25GLFFBQU0sWUFBWSxRQUFRLEVBQUUsZUFBZSxNQUFNLENBQUM7QUFDcEQ7QUFJQSxlQUFzQixnQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLFlBQVk7QUFDNUI7QUFFQSxlQUFzQixhQUFhLFFBQTJDO0FBQzVFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU0sS0FBSztBQUN4QjtBQUVBLGVBQXNCLGFBQWEsUUFBZ0IsS0FBK0I7QUFDaEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFFQSxlQUFzQixlQUFlLFFBQStCO0FBQ2xFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU07QUFDakIsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUlBLGVBQXNCLGNBQW1DO0FBQ3ZELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBRUEsZUFBc0IsZUFBZSxJQUFtQztBQUN0RSxRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLE1BQUksUUFBUSxFQUFFO0FBQ2QsTUFBSSxJQUFJLFNBQVMsa0JBQW1CLEtBQUksU0FBUztBQUNqRCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGdCQUErQjtBQUNuRCxRQUFNLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDN0I7QUFJQSxlQUFzQixvQkFBNkU7QUFDakcsU0FBTyxPQUFPLGdCQUFnQjtBQUNoQztBQUVBLGVBQXNCLGtCQUNwQixLQUNlO0FBQ2YsUUFBTSxPQUFPLGtCQUFrQixHQUFHO0FBQ3BDO0FBVU8sU0FBUyxjQUNkLE9BQ0EsVUFDQSxTQUNBLFFBQ0EsY0FBdUIsT0FDZjtBQUNSLFNBQU8sR0FBRyxLQUFLLElBQUksUUFBUSxJQUFJLE9BQU8sSUFBSSxNQUFNLElBQUksY0FBYyxNQUFNLEdBQUc7QUFDN0U7QUFHQSxlQUFzQixvQkFBb0IsVUFBbUM7QUFDM0UsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLFFBQU0sU0FBUyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksUUFBUSxFQUFFLFlBQVk7QUFDM0QsTUFBSSxTQUFTO0FBQ2IsYUFBVyxVQUFVLE9BQU8sS0FBSyxHQUFHLEdBQUc7QUFDckMsVUFBTSxRQUFRLElBQUksTUFBTTtBQUN4QixRQUFJLENBQUMsTUFBTztBQUNaLGVBQVcsT0FBTyxPQUFPLEtBQUssS0FBSyxHQUFHO0FBQ3BDLFlBQU0sSUFBSSxNQUFNLEdBQUc7QUFDbkIsVUFBSSxLQUFLLEVBQUUsS0FBSyxRQUFRO0FBQ3RCLGVBQU8sTUFBTSxHQUFHO0FBQ2hCLGtCQUFVO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sS0FBSyxLQUFLLEVBQUUsV0FBVyxFQUFHLFFBQU8sSUFBSSxNQUFNO0FBQUEsRUFDeEQ7QUFDQSxNQUFJLFNBQVMsRUFBRyxPQUFNLGtCQUFrQixHQUFHO0FBQzNDLFNBQU87QUFDVDtBQUlBLGVBQXNCLGtCQUFxRDtBQUN6RSxTQUFPLE9BQU8sY0FBYztBQUM5QjtBQUVBLGVBQXNCLG9CQUFxQztBQUN6RCxRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsTUFBSSxRQUFRO0FBQ1osYUFBVyxPQUFPLE9BQU8sT0FBTyxDQUFDLEVBQUcsVUFBUyxJQUFJO0FBQ2pELFNBQU87QUFDVDtBQUVBLGVBQXNCLGVBQWUsUUFBZ0IsU0FBZ0M7QUFDbkYsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLFFBQU0sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzFCLE1BQUksQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHO0FBQzFCLFFBQUksS0FBSyxPQUFPO0FBQ2hCLE1BQUUsTUFBTSxJQUFJO0FBQ1osVUFBTSxPQUFPLGdCQUFnQixDQUFDO0FBQUEsRUFDaEM7QUFDRjtBQUVBLGVBQXNCLGVBQWUsUUFBZ0IsU0FBZ0M7QUFDbkYsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLFFBQU0sTUFBTSxFQUFFLE1BQU07QUFDcEIsTUFBSSxDQUFDLElBQUs7QUFDVixRQUFNLFdBQVcsSUFBSSxPQUFPLENBQUMsT0FBTyxPQUFPLE9BQU87QUFDbEQsTUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLEVBQUUsTUFBTTtBQUFBLE1BQ3JDLEdBQUUsTUFBTSxJQUFJO0FBQ2pCLFFBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUNoQztBQUVBLGVBQXNCLG9CQUdaO0FBQ1IsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFFBQUksSUFBSSxTQUFTLEVBQUcsUUFBTyxFQUFFLFFBQVEsU0FBUyxJQUFJLENBQUMsRUFBRztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0IscUJBQXdEO0FBQzVFLFNBQU8sT0FBTyxpQkFBaUI7QUFDakM7QUFFQSxlQUFzQix1QkFBd0M7QUFDNUQsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixrQkFBa0IsWUFBMkIsU0FBZ0M7QUFDakcsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLFFBQU0sU0FBUyxjQUFjO0FBQzdCLFFBQU0sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzFCLE1BQUksQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHO0FBQzFCLFFBQUksS0FBSyxPQUFPO0FBQ2hCLE1BQUUsTUFBTSxJQUFJO0FBQ1osVUFBTSxPQUFPLG1CQUFtQixDQUFDO0FBQUEsRUFDbkM7QUFDRjtBQUVBLGVBQXNCLGtCQUFrQixTQUFnQztBQUN0RSxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxVQUFVO0FBQ2QsYUFBVyxVQUFVLE9BQU8sS0FBSyxDQUFDLEdBQUc7QUFDbkMsVUFBTSxNQUFNLEVBQUUsTUFBTTtBQUNwQixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sV0FBVyxJQUFJLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTztBQUNsRCxRQUFJLFNBQVMsV0FBVyxJQUFJLFFBQVE7QUFDbEMsZ0JBQVU7QUFDVixVQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNO0FBQUEsVUFDckMsR0FBRSxNQUFNLElBQUk7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFFBQVMsT0FBTSxPQUFPLG1CQUFtQixDQUFDO0FBQ2hEO0FBRUEsZUFBc0IsdUJBR1o7QUFDUixRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFHO0FBQUEsRUFDeEQ7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixZQUFZLFNBQW1DO0FBQ25FLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxhQUFXLFNBQVMsT0FBTyxPQUFPLEdBQUcsR0FBRztBQUN0QyxRQUFJLFNBQVMsV0FBVyxNQUFPLFFBQU87QUFBQSxFQUN4QztBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLG9CQUFpRDtBQUNyRSxTQUFPLE9BQU8sZ0JBQWdCO0FBQ2hDO0FBQ0EsZUFBc0Isa0JBQWtCLEdBQXNDO0FBQzVFLFFBQU0sT0FBTyxrQkFBa0IsQ0FBQztBQUNsQztBQUNBLGVBQXNCLHVCQUFvRDtBQUN4RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQXNDO0FBQy9FLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQUNBLGVBQXNCLHVCQUEwRDtBQUM5RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQTRDO0FBQ3JGLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQVlBLGVBQXNCLG9CQUFvQixVQU12QztBQUNELFFBQU0sWUFBWSxJQUFJLElBQUksQ0FBQyxHQUFHLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sYUFBYSxDQUFDLE1BQXVCLFVBQVUsSUFBSSxFQUFFLFlBQVksQ0FBQztBQUd4RSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksa0JBQWtCO0FBQ3RCLGFBQVcsS0FBSyxPQUFPLEtBQUssUUFBUSxHQUFHO0FBQ3JDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLFNBQVMsQ0FBQztBQUNqQix5QkFBbUI7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sWUFBWSxRQUFRO0FBR2pDLFFBQU0sVUFBVSxNQUFNLGNBQWM7QUFDcEMsTUFBSSxpQkFBaUI7QUFDckIsYUFBVyxLQUFLLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDcEMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sUUFBUSxDQUFDO0FBQ2hCLHdCQUFrQjtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxjQUFjLE9BQU87QUFHbEMsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLE1BQUksMEJBQTBCO0FBQzlCLGFBQVcsS0FBSyxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ2hDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLElBQUksQ0FBQztBQUNaLGlDQUEyQjtBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUNBLFFBQU0sa0JBQWtCLEdBQUc7QUFHM0IsUUFBTSxLQUFLLE1BQU0sZ0JBQWdCO0FBQ2pDLE1BQUksd0JBQXdCO0FBQzVCLGFBQVcsS0FBSyxPQUFPLEtBQUssRUFBRSxHQUFHO0FBQy9CLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLEdBQUcsQ0FBQztBQUNYLCtCQUF5QjtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxnQkFBZ0IsRUFBRTtBQUsvQixRQUFNLEtBQUssTUFBTSxtQkFBbUI7QUFDcEMsTUFBSSx1QkFBdUI7QUFDM0IsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLCtCQUF5QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDdEMsYUFBTyxHQUFHLENBQUM7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxtQkFBbUIsRUFBRTtBQUVsQyxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFJQSxlQUFzQixXQUEwQjtBQUM5QyxRQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU07QUFDcEM7OztBQ3RoQkEsSUFBSSxZQUE2QztBQUUxQyxTQUFTLGVBQWUsSUFBa0M7QUFDL0QsY0FBWTtBQUNkO0FBRUEsU0FBUyxTQUFpQjtBQUN4QixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ2hDO0FBRUEsZUFBZSxLQUFLLE9BQWlCLEtBQWEsU0FBaUQ7QUFDakcsUUFBTSxLQUFlLEVBQUUsSUFBSSxPQUFPLEdBQUcsT0FBTyxLQUFLLFNBQVMsT0FBTyxPQUFPLEVBQUU7QUFFMUUsUUFBTSxPQUFPLGlCQUFpQixNQUFNLFlBQVksQ0FBQyxJQUFJLEdBQUc7QUFDeEQsTUFBSSxVQUFVLFFBQVMsU0FBUSxNQUFNLE1BQU0sR0FBRyxPQUFPO0FBQUEsV0FDNUMsVUFBVSxPQUFRLFNBQVEsS0FBSyxNQUFNLEdBQUcsT0FBTztBQUFBLE1BQ25ELFNBQVEsSUFBSSxNQUFNLEdBQUcsT0FBTztBQUVqQyxNQUFJO0FBQ0YsVUFBTSxlQUFlLEVBQUU7QUFBQSxFQUN6QixTQUFTLEtBQUs7QUFDWixZQUFRLEtBQUssMkNBQTJDLEdBQUc7QUFBQSxFQUM3RDtBQUVBLE1BQUk7QUFDRixnQkFBWSxFQUFFO0FBQUEsRUFDaEIsUUFBUTtBQUFBLEVBRVI7QUFDRjtBQUVPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxLQUFLLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN0RixTQUFPLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDbEM7QUFDTyxTQUFTLE1BQU0sS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3ZGLFNBQU8sS0FBSyxTQUFTLEtBQUssT0FBTztBQUNuQztBQUVPLFNBQVMsY0FBYyxLQUF5RDtBQUNyRixNQUFJLGVBQWUsT0FBTztBQUN4QixXQUFPLEVBQUUsU0FBUyxJQUFJLFNBQVMsT0FBTyxJQUFJLFNBQVMsS0FBSztBQUFBLEVBQzFEO0FBQ0EsTUFBSTtBQUNGLFdBQU8sRUFBRSxTQUFTLE9BQU8sR0FBRyxHQUFHLE9BQU8sS0FBSztBQUFBLEVBQzdDLFFBQVE7QUFDTixXQUFPLEVBQUUsU0FBUyx1QkFBdUIsT0FBTyxLQUFLO0FBQUEsRUFDdkQ7QUFDRjtBQU9BLFNBQVMsT0FBTyxLQUF1RDtBQUNyRSxRQUFNLE1BQStCLENBQUM7QUFDdEMsYUFBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDeEMsUUFBSSxFQUFFLFlBQVksRUFBRSxTQUFTLE9BQU8sS0FBSyxFQUFFLFlBQVksTUFBTSxTQUFTLE1BQU0saUJBQWlCO0FBQzNGLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWCxXQUFXLE9BQU8sTUFBTSxZQUFZLCtCQUErQixLQUFLLENBQUMsR0FBRztBQUMxRSxVQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsNkJBQTZCLHVCQUF1QjtBQUFBLElBQ3pFLFdBQVcsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLE1BQU07QUFDbkQsVUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLE1BQU0sR0FBRyxJQUFJLENBQUM7QUFBQSxJQUM5QixPQUFPO0FBQ0wsVUFBSSxDQUFDLElBQUk7QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDs7O0FDdkVBLElBQU0sV0FBVztBQUNqQixJQUFNLFdBQVc7QUErQlYsSUFBTSxjQUFOLGNBQTBCLE1BQU07QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUE7QUFBQSxFQUVBLFlBQVksTUFPVDtBQUNELFVBQU0sS0FBSyxPQUFPO0FBQ2xCLFNBQUssT0FBTztBQUNaLFNBQUssU0FBUyxLQUFLO0FBQ25CLFNBQUssT0FBTyxLQUFLO0FBQ2pCLFNBQUssWUFBWSxLQUFLO0FBQ3RCLFNBQUssV0FBVyxLQUFLO0FBQ3JCLFNBQUssbUJBQW1CLEtBQUssb0JBQW9CO0FBQUEsRUFDbkQ7QUFDRjtBQUVPLElBQU0sZUFBTixNQUFtQjtBQUFBLEVBQ1A7QUFBQSxFQUVqQixZQUFZLFVBQW9CO0FBQzlCLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUE7QUFBQSxFQUdBLE1BQU0sU0FBMEI7QUFDOUIsVUFBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTztBQUMvQyxXQUFRLElBQTJCLFNBQVM7QUFBQSxFQUM5QztBQUFBO0FBQUEsRUFHQSxNQUFNLGFBQWEsUUFBa0M7QUFDbkQsUUFBSTtBQUNGLFlBQU0sS0FBSztBQUFBLFFBQ1Q7QUFBQSxRQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLG1CQUFtQixNQUFNLENBQUM7QUFBQSxNQUM1RjtBQUNBLGFBQU87QUFBQSxJQUNULFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLE1BQU0sbUJBQTBGO0FBQzlGLFVBQU0sS0FBSyxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDOUMsVUFBTSxPQUFPLE1BQU0sS0FBSyxVQUFVLE9BQU8sVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLEVBQUU7QUFDOUYsVUFBTSxJQUFJO0FBQ1YsV0FBTztBQUFBLE1BQ0wsT0FBUSxHQUF5QjtBQUFBLE1BQ2pDLFdBQVcsRUFBRTtBQUFBLE1BQ2IsZ0JBQWdCLEVBQUU7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxhQUFhLFlBQTRDO0FBQzdELFVBQU0sTUFBTSxHQUFHLFFBQVEsSUFBSSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLElBQUksS0FBSyxTQUFTLE1BQU0sSUFBSSxVQUFVO0FBQzFHLFVBQU0sTUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLE1BQzNCLFFBQVE7QUFBQSxNQUNSLFNBQVMsRUFBRSxlQUFlLFVBQVUsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUFBLElBQzFELENBQUM7QUFDRCxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxDQUFDLElBQUksR0FBSSxPQUFNLE1BQU0sS0FBSyxVQUFVLEtBQUssV0FBVyxVQUFVLEVBQUU7QUFDcEUsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLFdBQVcsTUFBc0M7QUFDckQsUUFBSTtBQUNGLFlBQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxRQUNyQjtBQUFBLFFBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUMsUUFBUSxtQkFBbUIsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLE1BQ2xJO0FBQ0EsWUFBTSxJQUFJO0FBQ1YsYUFBTyxFQUFFLE9BQU87QUFBQSxJQUNsQixTQUFTLEtBQUs7QUFDWixVQUFJLGVBQWUsZUFBZSxJQUFJLGFBQWEsWUFBYSxRQUFPO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE1BQU0sUUFBUSxNQUE4QztBQUMxRCxVQUFNLE9BQU8sS0FBSztBQUNsQixVQUFNLE1BQU0sVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUM7QUFDNUYsUUFBSSxNQUFxQixLQUFLLGVBQWU7QUFDN0MsVUFBTSxjQUFjO0FBRXBCLGFBQVMsVUFBVSxHQUFHLFdBQVcsYUFBYSxXQUFXO0FBQ3ZELFlBQU0sT0FBZ0M7QUFBQSxRQUNwQyxTQUFTLEtBQUs7QUFBQSxRQUNkLFNBQVMsS0FBSztBQUFBLFFBQ2QsUUFBUSxLQUFLLFNBQVM7QUFBQSxNQUN4QjtBQUNBLFVBQUksSUFBSyxNQUFLLE1BQU07QUFDcEIsVUFBSTtBQUNGLGNBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxPQUFPLEtBQUssSUFBSTtBQUNqRCxjQUFNLE1BQU07QUFDWixlQUFPLEVBQUUsTUFBTSxJQUFJLFFBQVEsTUFBTSxLQUFLLElBQUksUUFBUSxLQUFLLEtBQUssSUFBSSxRQUFRLFNBQVM7QUFBQSxNQUNuRixTQUFTLEtBQUs7QUFDWixZQUFJLEVBQUUsZUFBZSxhQUFjLE9BQU07QUFDekMsWUFBSSxJQUFJLFdBQVcsT0FBTyxDQUFDLEtBQUs7QUFFOUIsZ0JBQU0sTUFBTSxLQUFLLFdBQVcsSUFBSTtBQUNoQyxjQUFJLENBQUMsSUFBSyxPQUFNO0FBQ2hCO0FBQUEsUUFDRjtBQUNBLFlBQUksQ0FBQyxJQUFJLGFBQWEsWUFBWSxZQUFhLE9BQU07QUFDckQsY0FBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLElBQUksTUFBTSxtQ0FBbUMsSUFBSSxFQUFFO0FBQUEsRUFDM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU0EsTUFBTSxZQUFZLE1BQXNEO0FBQ3RFLFFBQUksS0FBSyxNQUFNLFdBQVcsRUFBRyxPQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFDOUUsVUFBTSxjQUFjO0FBQ3BCLFFBQUksVUFBbUI7QUFFdkIsYUFBUyxVQUFVLEdBQUcsV0FBVyxhQUFhLFdBQVc7QUFDdkQsVUFBSTtBQUNGLGNBQU0sUUFBUSxNQUFNLFFBQVE7QUFBQSxVQUMxQixLQUFLLE1BQU0sSUFBSSxPQUFPLFNBQVM7QUFDN0Isa0JBQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxjQUNyQjtBQUFBLGNBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsY0FDbkQ7QUFBQSxnQkFDRSxTQUFTLEtBQUs7QUFBQSxnQkFDZCxVQUFVO0FBQUEsY0FDWjtBQUFBLFlBQ0Y7QUFDQSxtQkFBTztBQUFBLGNBQ0wsTUFBTSxLQUFLO0FBQUEsY0FDWCxLQUFNLElBQXdCO0FBQUEsWUFDaEM7QUFBQSxVQUNGLENBQUM7QUFBQSxRQUNIO0FBRUEsY0FBTSxPQUFPLE1BQU0sS0FBSyxjQUFjO0FBQ3RDLGNBQU0sT0FBTyxNQUFNLEtBQUs7QUFBQSxVQUN0QjtBQUFBLFVBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsVUFDbkQ7QUFBQSxZQUNFLFdBQVcsS0FBSztBQUFBLFlBQ2hCLE1BQU0sTUFBTSxJQUFJLENBQUMsVUFBVTtBQUFBLGNBQ3pCLE1BQU0sS0FBSztBQUFBLGNBQ1gsTUFBTTtBQUFBLGNBQ04sTUFBTTtBQUFBLGNBQ04sS0FBSyxLQUFLO0FBQUEsWUFDWixFQUFFO0FBQUEsVUFDSjtBQUFBLFFBQ0Y7QUFDQSxjQUFNLFVBQVcsS0FBeUI7QUFDMUMsY0FBTSxTQUFTLE1BQU0sS0FBSztBQUFBLFVBQ3hCO0FBQUEsVUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxVQUNuRDtBQUFBLFlBQ0UsU0FBUyxLQUFLO0FBQUEsWUFDZCxNQUFNO0FBQUEsWUFDTixTQUFTLENBQUMsS0FBSyxHQUFHO0FBQUEsVUFDcEI7QUFBQSxRQUNGO0FBQ0EsY0FBTSxZQUFZO0FBQ2xCLFlBQUk7QUFDRixnQkFBTSxLQUFLO0FBQUEsWUFDVDtBQUFBLFlBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLG1CQUFtQixXQUFXLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxZQUN0RztBQUFBLGNBQ0UsS0FBSyxVQUFVO0FBQUEsY0FDZixPQUFPO0FBQUEsWUFDVDtBQUFBLFVBQ0Y7QUFBQSxRQUNGLFNBQVMsS0FBSztBQUNaLGNBQUksV0FBVyxHQUFHLEtBQUssVUFBVSxhQUFhO0FBQzVDLHNCQUFVO0FBQ1Ysa0JBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQ25DO0FBQUEsVUFDRjtBQUNBLGdCQUFNO0FBQUEsUUFDUjtBQUNBLGVBQU87QUFBQSxVQUNMLFdBQVcsVUFBVTtBQUFBLFVBQ3JCLEtBQUssVUFBVTtBQUFBLFVBQ2YsT0FBTyxLQUFLLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxJQUFJO0FBQUEsUUFDM0M7QUFBQSxNQUNGLFNBQVMsS0FBSztBQUNaLGtCQUFVO0FBQ1YsWUFBSSxFQUFFLGVBQWUsYUFBYyxPQUFNO0FBQ3pDLFlBQUssQ0FBQyxJQUFJLGFBQWEsQ0FBQyxXQUFXLEdBQUcsS0FBTSxZQUFZLFlBQWEsT0FBTTtBQUMzRSxjQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sbUJBQW1CLFFBQVEsVUFBVSxJQUFJLE1BQU0saUNBQWlDO0FBQUEsRUFDeEY7QUFBQSxFQUVBLE1BQWMsZ0JBQTJEO0FBQ3ZFLFVBQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxNQUNyQjtBQUFBLE1BQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGtCQUFrQixXQUFXLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxJQUN2RztBQUNBLFVBQU0sVUFBVyxJQUFvQyxPQUFPO0FBQzVELFVBQU0sU0FBUyxNQUFNLEtBQUs7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGdCQUFnQixPQUFPO0FBQUEsSUFDNUU7QUFDQSxXQUFPO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTCxTQUFVLE9BQXFDLEtBQUs7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQWMsVUFBVSxRQUFnQixNQUFjLE1BQWtDO0FBQ3RGLFVBQU0sTUFBTSxLQUFLLFdBQVcsTUFBTSxJQUFJLE9BQU8sR0FBRyxRQUFRLEdBQUcsSUFBSTtBQUMvRCxVQUFNLE9BQW9CO0FBQUEsTUFDeEI7QUFBQSxNQUNBLFNBQVM7QUFBQSxRQUNQLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRztBQUFBLFFBQzFDLFFBQVE7QUFBQSxRQUNSLHdCQUF3QjtBQUFBLFFBQ3hCLEdBQUksT0FBTyxFQUFFLGdCQUFnQixtQkFBbUIsSUFBSSxDQUFDO0FBQUEsTUFDdkQ7QUFBQSxNQUNBLEdBQUksT0FBTyxFQUFFLE1BQU0sS0FBSyxVQUFVLElBQUksRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMvQztBQUNBLFFBQUk7QUFDSixRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSyxJQUFJO0FBQUEsSUFDN0IsU0FBUyxRQUFRO0FBQ2YsWUFBTSxJQUFJLFlBQVk7QUFBQSxRQUNwQixRQUFRO0FBQUEsUUFDUixNQUFNO0FBQUEsUUFDTixTQUFTLFlBQVksY0FBYyxNQUFNLEVBQUUsT0FBTztBQUFBLFFBQ2xELFdBQVc7QUFBQSxRQUNYLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNIO0FBQ0EsUUFBSSxJQUFJLFdBQVcsSUFBSyxRQUFPO0FBQy9CLFFBQUksU0FBa0I7QUFDdEIsVUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0FBQzVCLFFBQUksTUFBTTtBQUNSLFVBQUk7QUFDRixpQkFBUyxLQUFLLE1BQU0sSUFBSTtBQUFBLE1BQzFCLFFBQVE7QUFDTixpQkFBUztBQUFBLE1BQ1g7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLElBQUksR0FBSSxPQUFNLE1BQU0sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEdBQUcsTUFBTSxJQUFJLElBQUksRUFBRTtBQUNsRixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUEsTUFBYyxVQUFVLEtBQWUsT0FBcUM7QUFDMUUsUUFBSSxTQUFrQjtBQUN0QixRQUFJO0FBQ0YsWUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO0FBQzVCLFVBQUksS0FBTSxVQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsSUFDcEMsUUFBUTtBQUFBLElBRVI7QUFDQSxXQUFPLEtBQUssb0JBQW9CLEtBQUssUUFBUSxLQUFLO0FBQUEsRUFDcEQ7QUFBQSxFQUVRLG9CQUFvQixLQUFlLE1BQWUsT0FBNEI7QUFDcEYsVUFBTSxNQUNKLE9BQU8sU0FBUyxZQUFZLFFBQVEsYUFBYSxPQUM3QyxPQUFRLEtBQThCLE9BQU8sSUFDN0MsSUFBSTtBQUNWLFFBQUksV0FBb0M7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7QUFFNUMsWUFBTSxPQUFPLElBQUksUUFBUSxJQUFJLHVCQUF1QjtBQUNwRCxVQUFJLFNBQVMsT0FBTyxjQUFjLEtBQUssR0FBRyxHQUFHO0FBQzNDLG1CQUFXO0FBQ1gsb0JBQVk7QUFBQSxNQUNkLE9BQU87QUFDTCxtQkFBVztBQUFBLE1BQ2I7QUFBQSxJQUNGLFdBQVcsSUFBSSxXQUFXLEtBQUs7QUFDN0IsaUJBQVc7QUFBQSxJQUNiLFdBQVcsSUFBSSxXQUFXLE9BQU8sSUFBSSxXQUFXLEtBQUs7QUFDbkQsaUJBQVc7QUFBQSxJQUNiLFdBQVcsSUFBSSxVQUFVLEtBQUs7QUFDNUIsaUJBQVc7QUFDWCxrQkFBWTtBQUFBLElBQ2QsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZDtBQUNBLFdBQU8sSUFBSSxZQUFZO0FBQUEsTUFDckIsUUFBUSxJQUFJO0FBQUEsTUFDWjtBQUFBLE1BQ0EsU0FBUyxHQUFHLEtBQUssV0FBTSxJQUFJLE1BQU0sS0FBSyxHQUFHO0FBQUEsTUFDekM7QUFBQSxNQUNBO0FBQUEsTUFDQSxrQkFBa0IsYUFBYSxlQUFlLG9CQUFvQixJQUFJLE9BQU8sSUFBSTtBQUFBLElBQ25GLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFRQSxTQUFTLG9CQUFvQixTQUFpQztBQUM1RCxRQUFNLFFBQVEsUUFBUSxJQUFJLG1CQUFtQjtBQUM3QyxNQUFJLE9BQU87QUFDVCxVQUFNLElBQUksT0FBTyxTQUFTLE9BQU8sRUFBRTtBQUNuQyxRQUFJLE9BQU8sU0FBUyxDQUFDLEtBQUssSUFBSSxFQUFHLFFBQU87QUFBQSxFQUMxQztBQUNBLFFBQU0sYUFBYSxRQUFRLElBQUksYUFBYTtBQUM1QyxNQUFJLFlBQVk7QUFDZCxVQUFNLFFBQVEsT0FBTyxTQUFTLFlBQVksRUFBRTtBQUM1QyxRQUFJLE9BQU8sU0FBUyxLQUFLLEtBQUssU0FBUyxHQUFHO0FBQ3hDLGFBQU8sS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUksSUFBSTtBQUFBLElBQ3pDO0FBQ0EsVUFBTSxTQUFTLEtBQUssTUFBTSxVQUFVO0FBQ3BDLFFBQUksT0FBTyxTQUFTLE1BQU0sRUFBRyxRQUFPLEtBQUssTUFBTSxTQUFTLEdBQUk7QUFBQSxFQUM5RDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxNQUFzQjtBQUV4QyxTQUFPLEtBQUssTUFBTSxHQUFHLEVBQUUsSUFBSSxrQkFBa0IsRUFBRSxLQUFLLEdBQUc7QUFDekQ7QUFFQSxTQUFTLFVBQVUsU0FBaUIsS0FBMEI7QUFFNUQsUUFBTSxPQUFPLElBQUksYUFBYSxlQUFlLE1BQU87QUFDcEQsUUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFHO0FBQzdDLFNBQU8sS0FBSyxJQUFJLEtBQVEsT0FBTyxNQUFNLFVBQVUsS0FBSyxNQUFNO0FBQzVEO0FBRUEsU0FBUyxXQUFXLEtBQWtDO0FBQ3BELFNBQU8sZUFBZSxlQUFlLElBQUksYUFBYTtBQUN4RDtBQUVBLFNBQVMsTUFBTSxJQUEyQjtBQUN4QyxTQUFPLElBQUksUUFBUSxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQztBQUM3QztBQUVPLFNBQVNBLFVBQVMsT0FBdUI7QUFFOUMsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFLE9BQU8sS0FBSztBQUMzQyxNQUFJLE1BQU07QUFDVixhQUFXLEtBQUssS0FBTSxRQUFPLE9BQU8sYUFBYSxDQUFDO0FBQ2xELFNBQU8sS0FBSyxHQUFHO0FBQ2pCOzs7QUMxV0EsSUFBTSxjQUFjO0FBU3BCLElBQU0sdUJBQTRDLG9CQUFJLElBQUksQ0FBQyxXQUFXLENBQUM7QUFFaEUsU0FBUyxVQUFVLFNBQWtCLEtBQXdDO0FBQ2xGLFFBQU0sWUFBWSxjQUFjLE9BQU87QUFDdkMsUUFBTSxTQUEyQixDQUFDO0FBQ2xDLFFBQU0sb0JBQXdDLENBQUM7QUFDL0MsUUFBTSxXQUFxQixDQUFDO0FBQzVCLFFBQU0sUUFBUSxvQkFBSSxJQUFZO0FBQzlCLFFBQU0sYUFBYSxvQkFBSSxJQUEyQjtBQUNsRCxRQUFNLGtCQUFrQixxQkFBcUIsSUFBSSxJQUFJLFFBQVE7QUFDN0QsYUFBVyxPQUFPLFdBQVc7QUFDM0IsUUFBSTtBQUNGLFlBQU0sY0FBYyxxQkFBcUIsS0FBSyxHQUFHO0FBQ2pELFVBQUksYUFBYTtBQUNmLDBCQUFrQixLQUFLLFdBQVc7QUFDbEMsaUJBQVMsS0FBSyxZQUFZLFFBQVE7QUFDbEMsY0FBTSxJQUFJLFlBQVksUUFBUTtBQUM5QjtBQUFBLE1BQ0Y7QUFDQSxZQUFNLElBQUksV0FBVyxLQUFLLEdBQUc7QUFDN0IsVUFBSSxDQUFDLEdBQUc7QUFDTixZQUFJLGlCQUFpQjtBQUluQixnQkFBTSxVQUFVLFlBQVksR0FBRztBQUMvQixjQUFJLFFBQVMsWUFBVyxJQUFJLFFBQVEsVUFBVSxRQUFRLFdBQVc7QUFBQSxRQUNuRTtBQUNBO0FBQUEsTUFDRjtBQUNBLGVBQVMsS0FBSyxFQUFFLFFBQVE7QUFDeEIsWUFBTSxJQUFJLEVBQUUsUUFBUTtBQUNwQixVQUFJLElBQUksZUFBZSxTQUFTLEtBQUssSUFBSSxlQUFlLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxHQUFHO0FBQzNGLGVBQU8sS0FBSyxDQUFDO0FBQUEsTUFDZjtBQUFBLElBQ0YsUUFBUTtBQUFBLElBRVI7QUFBQSxFQUNGO0FBR0EsUUFBTSxjQUF1RSxDQUFDO0FBQzlFLGFBQVcsQ0FBQyxJQUFJLElBQUksS0FBSyxZQUFZO0FBQ25DLFFBQUksTUFBTSxJQUFJLEVBQUUsRUFBRztBQUNuQixnQkFBWSxLQUFLLEVBQUUsVUFBVSxJQUFJLGFBQWEsS0FBSyxDQUFDO0FBQUEsRUFDdEQ7QUFDQSxTQUFPLEVBQUUsUUFBUSxjQUFjLFVBQVUsb0JBQW9CLG1CQUFtQixZQUFZO0FBQzlGO0FBRUEsU0FBUyxxQkFBcUIsTUFBZSxLQUFnRDtBQUMzRixNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLE1BQUksRUFBRSxlQUFlLGlCQUFrQixRQUFPO0FBRTlDLFFBQU0sVUFDSixVQUFVLEVBQUUsT0FBTyxLQUNuQixvQkFBb0IsSUFBSSxNQUN2QixJQUFJLFlBQVksb0JBQW9CLElBQUksU0FBUyxJQUFJO0FBQ3hELE1BQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxLQUFLLE9BQU8sRUFBRyxRQUFPO0FBRW5ELFFBQU0sa0JBQWtCLGtCQUFrQixJQUFJO0FBQzlDLFNBQU87QUFBQSxJQUNMLFVBQVU7QUFBQSxJQUNWLGdCQUNFLHdCQUF3QixNQUFNLE9BQU8sTUFDcEMsSUFBSSxZQUFZLG1CQUFtQixJQUFJLFdBQVcsT0FBTyxJQUFJO0FBQUEsSUFDaEUseUJBQXlCLElBQUk7QUFBQSxJQUM3QixvQkFBb0IsMEJBQTBCLGVBQWU7QUFBQSxJQUM3RCxrQkFBa0I7QUFBQSxJQUNsQix3QkFBd0IsSUFBSSxhQUFhO0FBQUEsRUFDM0M7QUFDRjtBQUVBLFNBQVMsb0JBQW9CLE1BQThCO0FBQ3pELFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sTUFBTSxNQUFNLElBQUk7QUFDdEIsUUFBSSxPQUFPLFFBQVEsVUFBVTtBQUMzQixZQUFNLEtBQUssb0JBQW9CLEdBQUc7QUFDbEMsVUFBSSxHQUFJLFFBQU87QUFDZjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVTtBQUM3QyxRQUFJLEtBQUssSUFBSSxHQUFhLEVBQUc7QUFDN0IsU0FBSyxJQUFJLEdBQWE7QUFDdEIsUUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQ3RCLGlCQUFXLEtBQUssSUFBSyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ25DLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxHQUE4QixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDN0U7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxvQkFBb0IsUUFBK0I7QUFDMUQsTUFBSTtBQUNGLFVBQU0sTUFBTSxJQUFJLElBQUksUUFBUSxnQkFBZ0I7QUFDNUMsUUFBSSxJQUFJLGFBQWEsV0FBVyxJQUFJLGFBQWEsY0FBZSxRQUFPO0FBQ3ZFLFVBQU0sUUFBUSxJQUFJLFNBQVMsTUFBTSxvREFBb0Q7QUFDckYsV0FBTyxRQUFRLENBQUMsS0FBSztBQUFBLEVBQ3ZCLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxrQkFBa0IsTUFBOEI7QUFDdkQsUUFBTSxVQUFvQixDQUFDO0FBQzNCLFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sTUFBTSxNQUFNLElBQUk7QUFDdEIsUUFBSSxPQUFPLFFBQVEsVUFBVTtBQUMzQixZQUFNLFVBQVUsSUFBSSxLQUFLO0FBQ3pCLFVBQ0UsUUFBUSxVQUFVLEtBQ2xCLENBQUMsUUFBUSxXQUFXLFNBQVMsS0FDN0IsQ0FBQyxRQUFRLFdBQVcsVUFBVSxHQUM5QjtBQUNBLGdCQUFRLEtBQUssT0FBTztBQUFBLE1BQ3RCO0FBQ0E7QUFBQSxJQUNGO0FBQ0EsUUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVU7QUFDN0MsUUFBSSxLQUFLLElBQUksR0FBYSxFQUFHO0FBQzdCLFNBQUssSUFBSSxHQUFhO0FBQ3RCLFFBQUksTUFBTSxRQUFRLEdBQUcsR0FBRztBQUN0QixpQkFBVyxLQUFLLElBQUssT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNuQyxPQUFPO0FBQ0wsaUJBQVcsS0FBSyxPQUFPLE9BQU8sR0FBOEIsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQzdFO0FBQUEsRUFDRjtBQUNBLFFBQU0sWUFBWSxRQUFRO0FBQUEsSUFBSyxDQUFDLE1BQzlCLDhFQUE4RSxLQUFLLENBQUM7QUFBQSxFQUN0RjtBQUNBLFNBQU8sYUFBYSxRQUFRLENBQUMsS0FBSztBQUNwQztBQUVBLFNBQVMsMEJBQTBCLE1BQW9DO0FBQ3JFLE1BQUksQ0FBQyxLQUFNLFFBQU87QUFDbEIsTUFBSSx3QkFBd0IsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUMvQyxNQUFJLGdCQUFnQixLQUFLLElBQUksRUFBRyxRQUFPO0FBQ3ZDLE1BQUksdUJBQXVCLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDOUMsTUFBSSxpQkFBaUIsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUN4QyxNQUFJLGlDQUFpQyxLQUFLLElBQUksRUFBRyxRQUFPO0FBQ3hELFNBQU87QUFDVDtBQUVBLFNBQVMsWUFBWSxNQUF3RTtBQUMzRixNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUdWLE1BQUksRUFBRSxlQUFlLGlCQUFrQixRQUFPO0FBRzlDLFFBQU0sS0FBSyxFQUFFO0FBQ2IsTUFBSSxPQUFPLFdBQVcsT0FBTyxnQ0FBZ0MsQ0FBQyxJQUFJLEVBQUUsTUFBTSxHQUFHO0FBQzNFLFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxTQUNILE9BQU8sRUFBRSxZQUFZLFlBQVksRUFBRSxXQUNuQyxPQUFPLElBQUksRUFBRSxZQUFZLEdBQUcsV0FBVyxZQUNyQyxJQUFJLElBQUksRUFBRSxZQUFZLEdBQUcsTUFBTSxHQUFHO0FBQ3ZDLE1BQUksT0FBTyxXQUFXLFlBQVksQ0FBQyxZQUFZLEtBQUssTUFBTSxFQUFHLFFBQU87QUFDcEUsUUFBTSxhQUFhLGVBQWUsTUFBTSxNQUFNO0FBQzlDLE1BQUksQ0FBQyxXQUFZLFFBQU87QUFDeEIsU0FBTyxFQUFFLFVBQVUsUUFBUSxhQUFhLFdBQVc7QUFDckQ7QUFFQSxTQUFTLGVBQWUsTUFBZSxTQUFnQztBQUNyRSxNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLFFBQU0sYUFBYSxJQUFJLElBQUksSUFBSSxFQUFFLElBQUksR0FBRyxZQUFZLEdBQUcsTUFBTTtBQUM3RCxTQUNFLFVBQVUsSUFBSSxZQUFZLElBQUksR0FBRyxXQUFXLEtBQzVDLFVBQVUsSUFBSSxZQUFZLE1BQU0sR0FBRyxXQUFXLEtBQzlDLFVBQVUsSUFBSSxFQUFFLE1BQU0sR0FBRyxXQUFXLEtBQ3BDLHdCQUF3QixNQUFNLE9BQU87QUFFekM7QUFFQSxTQUFTLHdCQUF3QixNQUFlLFNBQWdDO0FBQzlFLFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sTUFBTSxNQUFNLElBQUk7QUFDdEIsUUFBSSxPQUFPLFFBQVEsVUFBVTtBQUMzQixZQUFNLFNBQVMsbUJBQW1CLEtBQUssT0FBTztBQUM5QyxVQUFJLE9BQVEsUUFBTztBQUNuQjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVTtBQUM3QyxRQUFJLEtBQUssSUFBSSxHQUFhLEVBQUc7QUFDN0IsU0FBSyxJQUFJLEdBQWE7QUFDdEIsUUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQ3RCLGlCQUFXLEtBQUssSUFBSyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ25DLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxHQUE4QixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDN0U7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxtQkFBbUIsUUFBZ0IsU0FBZ0M7QUFDMUUsTUFBSTtBQUNGLFVBQU0sTUFBTSxJQUFJLElBQUksUUFBUSxnQkFBZ0I7QUFDNUMsUUFBSSxJQUFJLGFBQWEsV0FBVyxJQUFJLGFBQWEsY0FBZSxRQUFPO0FBQ3ZFLFVBQU0sUUFBUSxJQUFJLFNBQVMsTUFBTSxzREFBc0Q7QUFDdkYsUUFBSSxDQUFDLFNBQVMsTUFBTSxDQUFDLE1BQU0sUUFBUyxRQUFPO0FBQzNDLFdBQU8sTUFBTSxDQUFDLEtBQUs7QUFBQSxFQUNyQixRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsY0FBY0MsTUFBeUI7QUFLOUMsUUFBTSxNQUFpQixDQUFDO0FBQ3hCLFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUNBLElBQUc7QUFDN0IsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE9BQU8sTUFBTSxJQUFJO0FBQ3ZCLFFBQUksU0FBUyxRQUFRLFNBQVMsT0FBVztBQUN6QyxRQUFJLE9BQU8sU0FBUyxTQUFVO0FBQzlCLFFBQUksS0FBSyxJQUFJLElBQWMsRUFBRztBQUM5QixTQUFLLElBQUksSUFBYztBQUV2QixRQUFJLGVBQWUsSUFBSSxHQUFHO0FBQ3hCLFVBQUksS0FBSyxZQUFZLElBQUksQ0FBQztBQUFBLElBQzVCO0FBQ0EsUUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGlCQUFXLEtBQUssS0FBTSxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ3BDLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxJQUErQixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDOUU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxlQUFlLE1BQWdEO0FBQ3RFLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsUUFBTSxXQUFXLEVBQUU7QUFDbkIsTUFDRSxhQUFhLFdBQ2IsYUFBYSxnQ0FDYixhQUFhLGtCQUNiO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUFPLE9BQU8sRUFBRSxZQUFZLFlBQVksT0FBTyxFQUFFLFdBQVcsWUFBWSxFQUFFLFdBQVc7QUFDdkY7QUFFQSxTQUFTLFlBQVksTUFBd0Q7QUFDM0UsTUFBSSxLQUFLLGVBQWUsZ0NBQWdDLE9BQU8sS0FBSyxVQUFVLFVBQVU7QUFDdEYsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxLQUFjLEtBQThDO0FBQzlFLE1BQUksT0FBTyxRQUFRLFlBQVksUUFBUSxLQUFNLFFBQU87QUFDcEQsUUFBTSxJQUFJO0FBRVYsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFFOUMsUUFBTSxTQUFTLFVBQVUsRUFBRSxPQUFPO0FBS2xDLFFBQU0sU0FBUyxJQUFJLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDakMsTUFBSSxDQUFDLE9BQVEsUUFBTztBQUVwQixRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksSUFBSSxNQUFNLFlBQVksR0FBRyxNQUFNO0FBR3RELFFBQU0sY0FBYyxJQUFJLFlBQVksSUFBSTtBQUN4QyxRQUFNLGFBQWEsSUFBSSxZQUFZLE1BQU07QUFDekMsUUFBTSxnQkFBZ0IsSUFBSSxZQUFZLE1BQU07QUFDNUMsUUFBTSxTQUNKLFVBQVUsYUFBYSxXQUFXLEtBQ2xDLFVBQVUsWUFBWSxXQUFXLEtBQ2pDLFVBQVUsWUFBWSxXQUFXLEtBQ2pDLFVBQVUsT0FBTyxXQUFXO0FBQzlCLFFBQU0sWUFDSixVQUFVLFlBQVksT0FBTyxLQUM3QixVQUFVLFlBQVksTUFBTSxLQUM1QixVQUFVLE9BQU8sV0FBVztBQUM5QixNQUFJLENBQUMsVUFBVSxDQUFDLFVBQVcsUUFBTztBQU1sQyxRQUFNLFNBQVMsb0JBQW9CLFlBQVksYUFBYSxZQUFZLGFBQWE7QUFFckYsUUFBTSxZQUFZLElBQUksSUFBSSxJQUFJLEVBQUUsVUFBVSxHQUFHLGtCQUFrQixHQUFHLE1BQU07QUFDeEUsUUFBTSxlQUFlLFVBQVUsV0FBVyxJQUFJO0FBQzlDLFFBQU0saUJBQWlCLFVBQVUsT0FBTyxTQUFTLEtBQUs7QUFDdEQsUUFBTSxPQUFPLGdCQUFnQjtBQUM3QixRQUFNLGNBQWMsaUJBQWlCLFdBQVcsUUFBUSxjQUFjO0FBQ3RFLFFBQU0sZ0JBQWdCLHFCQUFxQixHQUFHLFFBQVEsSUFBSSxVQUFVO0FBRXBFLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUSxLQUFLLENBQUM7QUFDMUMsUUFBTSxtQkFBbUIsSUFBSSxXQUFXLFVBQVU7QUFDbEQsUUFBTSxXQUFXLGdCQUFnQixvQkFBb0IsUUFBUTtBQUM3RCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sT0FBTyxZQUFZLG9CQUFvQixRQUFRO0FBQ3JELFFBQU0sUUFBUSxhQUFhLE1BQU07QUFFakMsUUFBTSxZQUFZLGtCQUFrQixHQUFHLE1BQU07QUFJN0MsUUFBTSxXQUNKLGlCQUFpQixVQUFVLE9BQU8sVUFBVSxDQUFDLEtBQUssaUJBQWlCLFVBQVUsRUFBRSxVQUFVLENBQUM7QUFDNUYsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUV0QixRQUFNLFFBQVEsSUFBSSxFQUFFLEtBQUs7QUFDekIsUUFBTSxZQUFZLFVBQVUsT0FBTyxLQUFLLEtBQUssVUFBVSxVQUFVLE9BQU8sS0FBSyxDQUFDO0FBRTlFLFFBQU0sT0FBTyxZQUFZLENBQUM7QUFDMUIsUUFBTSxRQUFRLElBQUksT0FBTyxLQUFLO0FBRTlCLFFBQU0sUUFBd0I7QUFBQSxJQUM1QixVQUFVO0FBQUEsSUFDVixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixXQUFXO0FBQUEsSUFDWCxtQkFBbUIsSUFBSTtBQUFBLElBQ3ZCLGNBQWMsSUFBSTtBQUFBLElBQ2xCLHNCQUFzQjtBQUFBLElBQ3RCLHlCQUF5QjtBQUFBLElBQ3pCLG9CQUFvQjtBQUFBLElBQ3BCLGtCQUFrQjtBQUFBLElBQ2xCLHdCQUF3QjtBQUFBLElBQ3hCLFdBQVcsR0FBRyxnQkFBZ0IsSUFBSSxNQUFNLFdBQVcsTUFBTTtBQUFBLElBQ3pELFlBQVk7QUFBQSxJQUNaLGlCQUFpQixVQUFVLE9BQU8sbUJBQW1CO0FBQUEsSUFDckQsbUJBQW1CLFVBQVUsT0FBTyx5QkFBeUI7QUFBQSxJQUM3RCxrQkFBa0IsVUFBVSxPQUFPLHVCQUF1QjtBQUFBLElBQzFELHFCQUFxQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDN0QsaUJBQWlCLFVBQVUsT0FBTyxvQkFBb0I7QUFBQSxJQUN0RCxvQkFBb0I7QUFBQSxNQUNsQixJQUFJLElBQUksT0FBTyx1QkFBdUIsR0FBRyxNQUFNLEdBQUcsV0FDL0MsT0FBbUM7QUFBQSxJQUN4QztBQUFBLElBQ0E7QUFBQSxJQUNBLGVBQWUsaUJBQWlCLE1BQU0sSUFBSTtBQUFBLElBQzFDLE1BQU0sVUFBVSxPQUFPLElBQUk7QUFBQSxJQUMzQixvQkFBb0IsV0FBVyxPQUFPLGtCQUFrQjtBQUFBLElBQ3hELFFBQVEsVUFBVSxPQUFPLE1BQU0sS0FBSyxVQUFVLEVBQUUsTUFBTTtBQUFBLElBQ3RELGlCQUFpQixVQUFVLE9BQU8sU0FBUztBQUFBLElBQzNDO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWSxVQUFVLE9BQU8sY0FBYztBQUFBLElBQzNDLGVBQWUsVUFBVSxPQUFPLGFBQWE7QUFBQSxJQUM3QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsYUFBYSxVQUFVLE9BQU8sV0FBVztBQUFBLElBQ3pDLFlBQVk7QUFBQSxJQUNaLGdCQUFnQixVQUFVLE9BQU8sY0FBYztBQUFBLElBQy9DLG9CQUFvQjtBQUFBLE1BQ2xCO0FBQUEsUUFDRSxhQUFhLElBQUk7QUFBQSxRQUNqQixPQUFPLFVBQVUsT0FBTyxjQUFjO0FBQUEsUUFDdEMsVUFBVSxVQUFVLE9BQU8sYUFBYTtBQUFBLFFBQ3hDLFNBQVMsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNyQyxRQUFRLFVBQVUsT0FBTyxXQUFXO0FBQUEsUUFDcEMsT0FBTztBQUFBLFFBQ1AsV0FBVyxVQUFVLE9BQU8sY0FBYztBQUFBLE1BQzVDO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFBQSxJQUNBLGdCQUFnQjtBQUFBLElBQ2hCLGNBQWM7QUFBQSxJQUNkLGFBQWE7QUFBQSxJQUNiLHNCQUFzQjtBQUFBLElBQ3RCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsRUFDbEI7QUFFQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGtCQUFrQixHQUE0QixRQUE0QztBQUNqRyxNQUFJLE9BQU8sMkJBQTJCLE9BQU8sd0JBQXlCLFFBQU87QUFDN0UsTUFBSSxPQUFPLDBCQUEyQixRQUFPO0FBQzdDLE1BQUksT0FBTyxvQkFBb0IsUUFBUSxPQUFPLHFCQUFzQixRQUFPO0FBQzNFLE1BQUksRUFBRSxlQUFlLDhCQUE4QjtBQUFBLEVBRW5EO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxnQkFBZ0IsVUFBNkM7QUFDcEUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFNBQU8sSUFDSjtBQUFBLElBQUksQ0FBQyxNQUNKLE9BQU8sTUFBTSxZQUFZLEtBQUssVUFBVSxJQUFJLE9BQVEsRUFBd0IsSUFBSSxJQUFJO0FBQUEsRUFDdEYsRUFDQyxPQUFPLENBQUMsTUFBbUIsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLENBQUM7QUFDckU7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsSUFDM0MsT0FBUSxFQUErQixXQUFXLElBQ2xEO0FBQUEsRUFDTixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsWUFBWSxVQUFnRDtBQUNuRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsUUFBTSxNQUFtQixDQUFDO0FBQzFCLGFBQVcsS0FBSyxLQUFLO0FBQ25CLFFBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFVBQU0sSUFBSTtBQUNWLFVBQU0sUUFBUSxVQUFVLEVBQUUsR0FBRztBQUM3QixVQUFNLFdBQVcsVUFBVSxFQUFFLFlBQVk7QUFDekMsVUFBTSxVQUFVLFVBQVUsRUFBRSxXQUFXO0FBQ3ZDLFFBQUksQ0FBQyxTQUFTLENBQUMsU0FBVTtBQUN6QixRQUFJLEtBQUssRUFBRSxPQUFPLFVBQVUsU0FBUyxXQUFXLFNBQVMsQ0FBQztBQUFBLEVBQzVEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLFFBQThDO0FBQ2xFLFFBQU0sV0FBVyxJQUFJLE9BQU8saUJBQWlCO0FBQzdDLFFBQU0sVUFBVSxXQUFXLFFBQVEsU0FBUyxLQUFLLElBQUksQ0FBQztBQUN0RCxRQUFNLFVBQVUsUUFBUSxJQUFJLE9BQU8sUUFBUSxHQUFHLEtBQUs7QUFDbkQsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxTQUFTLENBQUMsR0FBRyxTQUFTLEdBQUcsT0FBTyxFQUFFLE9BQU8sQ0FBQyxNQUFNO0FBQ3BELFFBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNLFFBQU87QUFDaEQsVUFBTSxLQUNKLFVBQVcsRUFBOEIsU0FBUyxLQUNsRCxVQUFXLEVBQThCLE1BQU07QUFDakQsUUFBSSxDQUFDLEdBQUksUUFBTztBQUNoQixRQUFJLEtBQUssSUFBSSxFQUFFLEVBQUcsUUFBTztBQUN6QixTQUFLLElBQUksRUFBRTtBQUNYLFdBQU87QUFBQSxFQUNULENBQUM7QUFDRCxTQUFPLE9BQU8sSUFBSSxDQUFDLFFBQVEsV0FBVyxHQUE4QixDQUFDO0FBQ3ZFO0FBRUEsU0FBUyxXQUFXLEdBQXVDO0FBQ3pELFFBQU0sT0FBTyxVQUFVLEVBQUUsSUFBSTtBQUM3QixRQUFNLFdBQVcsZ0JBQWdCLEdBQUcsSUFBSTtBQUN4QyxRQUFNQyxRQUFPLElBQUksRUFBRSxhQUFhO0FBQ2hDLFFBQU0sWUFBWSxJQUFJLEVBQUUsVUFBVTtBQUNsQyxRQUFNLGFBQWEsVUFBVSxXQUFXLGVBQWU7QUFDdkQsUUFBTSxVQUFVLFVBQVUsRUFBRSxZQUFZO0FBQ3hDLFFBQU0sVUFDSixVQUFVLEVBQUUsU0FBUyxLQUNyQixVQUFVLEVBQUUsTUFBTSxLQUNsQixHQUFHLFFBQVEsT0FBTyxJQUFJLEtBQUssT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQzNELFNBQU87QUFBQSxJQUNMLFVBQVU7QUFBQSxJQUNWLFlBQWEsUUFBUTtBQUFBLElBQ3JCLGNBQWMsWUFBWTtBQUFBLElBQzFCLG1CQUFtQjtBQUFBLElBQ25CLFFBQVE7QUFBQSxJQUNSLE9BQU87QUFBQSxJQUNQLGNBQWMsZUFBZSxPQUFPLGFBQWEsTUFBTztBQUFBLElBQ3hELE9BQU8sVUFBVUEsT0FBTSxLQUFLO0FBQUEsSUFDNUIsUUFBUSxVQUFVQSxPQUFNLE1BQU07QUFBQSxJQUM5QixVQUFVO0FBQUEsSUFDVixnQkFBZ0I7QUFBQSxJQUNoQixrQkFBa0I7QUFBQSxJQUNsQixpQkFBaUI7QUFBQSxFQUNuQjtBQUNGO0FBRUEsU0FBUyxnQkFBZ0IsR0FBNEIsTUFBb0M7QUFDdkYsTUFBSSxTQUFTLFFBQVMsUUFBTyxVQUFVLEVBQUUsZUFBZSxLQUFLLFVBQVUsRUFBRSxTQUFTO0FBQ2xGLFFBQU0sV0FBVyxRQUFRLElBQUksRUFBRSxVQUFVLEdBQUcsUUFBUTtBQUNwRCxNQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sVUFBVSxFQUFFLGVBQWU7QUFFN0QsTUFBSSxPQUFnRDtBQUNwRCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLEtBQUssVUFBVSxFQUFFLFlBQVk7QUFDbkMsVUFBTSxNQUFNLFVBQVUsRUFBRSxHQUFHO0FBQzNCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsUUFBSSxPQUFPLGFBQWE7QUFDdEIsWUFBTSxLQUFLLFVBQVUsRUFBRSxPQUFPLEtBQUs7QUFDbkMsVUFBSSxDQUFDLFFBQVEsS0FBSyxLQUFLLFFBQVMsUUFBTyxFQUFFLEtBQUssU0FBUyxHQUFHO0FBQUEsSUFDNUQsV0FBVyxDQUFDLE1BQU07QUFFaEIsYUFBTyxFQUFFLEtBQUssU0FBUyxFQUFFO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0EsU0FBTyxNQUFNLE9BQU87QUFDdEI7QUFFQSxTQUFTLGlCQUFpQixNQUFjLE1BQTJCO0FBQ2pFLE1BQUksS0FBSyxXQUFXLEVBQUcsUUFBTztBQUM5QixNQUFJLE1BQU07QUFDVixhQUFXLEtBQUssS0FBTSxPQUFNLElBQUksTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUTtBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxNQUFJLENBQUMsRUFBRyxRQUFPO0FBRWYsUUFBTSxJQUFJLElBQUksS0FBSyxDQUFDO0FBQ3BCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTztBQUN0QyxTQUFPLEVBQUUsWUFBWTtBQUN2QjtBQUVBLFNBQVMsVUFBVSxHQUEyQjtBQUM1QyxTQUFPLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxJQUFJLElBQUk7QUFDckQ7QUFDQSxTQUFTLFdBQVcsR0FBNEI7QUFDOUMsU0FBTyxPQUFPLE1BQU0sWUFBWSxJQUFJO0FBQ3RDO0FBQ0EsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ3hELE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsVUFBTSxJQUFJLE9BQU8sQ0FBQztBQUNsQixRQUFJLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUFBLEVBQ2pDO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLEdBQW9CO0FBQ3JDLFNBQU8sVUFBVSxDQUFDLEtBQUs7QUFDekI7QUFDQSxTQUFTLElBQUksR0FBNEM7QUFDdkQsU0FBTyxPQUFPLE1BQU0sWUFBWSxNQUFNLFFBQVEsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUN6RCxJQUNEO0FBQ047QUFDQSxTQUFTLFFBQVEsR0FBdUI7QUFDdEMsU0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQztBQUNqQztBQXdCQSxTQUFTLGlCQUNQLFdBQ0EsUUFDQSxVQUNTO0FBQ1QsTUFBSSxVQUFXLFFBQU87QUFDdEIsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUN0QixRQUFNLFdBQVcsSUFBSSxPQUFPLFFBQVE7QUFDcEMsUUFBTSxPQUFPLFdBQVcsU0FBUyxPQUFPO0FBQ3hDLE1BQUksTUFBTSxRQUFRLElBQUksR0FBRztBQUN2QixlQUFXLEtBQUssTUFBTTtBQUNwQixVQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTTtBQUN6QyxZQUFNLE1BQU8sRUFBOEI7QUFJM0MsVUFBSSxPQUFPLFFBQVEsWUFBWSx3QkFBd0IsS0FBSyxHQUFHLEdBQUc7QUFDaEUsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQWtCTyxTQUFTLGNBQ2QsUUFDQSxVQUNrQjtBQUNsQixNQUFJLFNBQVMsU0FBUyxFQUFHLFFBQU87QUFLaEMsUUFBTSxnQkFBZ0Isb0JBQUksSUFBWTtBQUN0QyxRQUFNLG1CQUFtQixvQkFBSSxJQUFZO0FBQ3pDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxFQUFHO0FBQ25ELHFCQUFpQixJQUFJLEVBQUUsUUFBUTtBQUMvQixRQUFJLEVBQUUsZ0JBQWlCLGVBQWMsSUFBSSxFQUFFLGVBQWU7QUFDMUQsUUFBSSxFQUFFLG1CQUFvQixlQUFjLElBQUksRUFBRSxrQkFBa0I7QUFDaEUsUUFBSSxFQUFFLGtCQUFtQixlQUFjLElBQUksRUFBRSxpQkFBaUI7QUFBQSxFQUNoRTtBQUNBLFNBQU8sT0FBTyxPQUFPLENBQUMsTUFBTTtBQUMxQixVQUFNLElBQUksRUFBRSxlQUFlLFlBQVk7QUFDdkMsUUFBSSxTQUFTLElBQUksQ0FBQyxFQUFHLFFBQU87QUFFNUIsUUFBSSxjQUFjLElBQUksRUFBRSxRQUFRLEVBQUcsUUFBTztBQUUxQyxRQUFJLEVBQUUsbUJBQW1CLGlCQUFpQixJQUFJLEVBQUUsZUFBZSxFQUFHLFFBQU87QUFDekUsUUFBSSxFQUFFLHNCQUFzQixpQkFBaUIsSUFBSSxFQUFFLGtCQUFrQixFQUFHLFFBQU87QUFDL0UsUUFBSSxFQUFFLHFCQUFxQixpQkFBaUIsSUFBSSxFQUFFLGlCQUFpQixFQUFHLFFBQU87QUFFN0UsUUFBSSxFQUFFLG9CQUFvQixTQUFTLElBQUksRUFBRSxpQkFBaUIsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUNqRixlQUFXLEtBQUssRUFBRSxVQUFVO0FBQzFCLFVBQUksU0FBUyxJQUFJLEVBQUUsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUFBLElBQzVDO0FBQ0EsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNIO0FBU0EsU0FBUyxxQkFDUCxHQUNBLFFBQ0EsWUFDc0I7QUFDdEIsUUFBTSxRQUFRLElBQUksRUFBRSxlQUFlLEtBQUssSUFBSSxPQUFPLGVBQWU7QUFDbEUsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixRQUFNLFdBQVcsSUFBSSxNQUFNLFFBQVE7QUFDbkMsUUFBTSxPQUFPLElBQUksTUFBTSxJQUFJO0FBQzNCLFFBQU0sVUFBVSxVQUFVLFVBQVUsSUFBSTtBQUN4QyxRQUFNLFFBQVEsVUFBVSxNQUFNLEtBQUs7QUFDbkMsUUFBTSxhQUFhLFVBQVUsTUFBTSxVQUFVO0FBQzdDLFFBQU0saUJBQWlCLFVBQVUsTUFBTSxjQUFjO0FBQ3JELFFBQU0sU0FBUyxVQUFVLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPO0FBRWpFLE1BQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQVEsUUFBTztBQUMxQyxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVDtBQUFBLElBQ0EsYUFBYTtBQUFBLElBQ2I7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLElBQ2pCLGFBQWE7QUFBQSxFQUNmO0FBQ0Y7QUFPQSxTQUFTLG9CQUNQLFlBQ0EsYUFDQSxZQUNBLGVBQ2M7QUFDZCxRQUFNLGVBQWUsSUFBSSxZQUFZLFlBQVk7QUFDakQsU0FBTztBQUFBLElBQ0wsY0FDRSxVQUFVLGFBQWEsSUFBSSxLQUFLLFVBQVUsWUFBWSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUk7QUFBQSxJQUMzRixZQUNFLFVBQVUsZUFBZSxTQUFTLEtBQ2xDLFVBQVUsWUFBWSx1QkFBdUIsS0FDN0MsVUFBVSxZQUFZLHVCQUF1QjtBQUFBLElBQy9DLFVBQVUsV0FBVyxjQUFjLFFBQVEsS0FBSyxXQUFXLFlBQVksUUFBUTtBQUFBLElBQy9FLGtCQUFrQixXQUFXLFlBQVksZ0JBQWdCO0FBQUEsSUFDekQsZUFBZSxVQUFVLGNBQWMsYUFBYSxLQUFLLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDNUYsYUFBYSxVQUFVLFlBQVksV0FBVztBQUFBLElBQzlDLFVBQVUsVUFBVSxJQUFJLFlBQVksUUFBUSxHQUFHLFFBQVEsS0FBSyxVQUFVLFlBQVksUUFBUTtBQUFBLElBQzFGLEtBQUssVUFBVSxZQUFZLEdBQUc7QUFBQSxJQUM5QixpQkFBaUIsVUFBVSxZQUFZLGVBQWU7QUFBQSxJQUN0RCxlQUFlLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDbEQsZ0JBQWdCLFVBQVUsWUFBWSxjQUFjO0FBQUEsSUFDcEQsb0JBQ0UsaUJBQWlCLFVBQVUsYUFBYSxVQUFVLENBQUMsS0FDbkQsaUJBQWlCLFVBQVUsWUFBWSxVQUFVLENBQUM7QUFBQSxJQUNwRCxXQUFXLFdBQVcsWUFBWSxTQUFTO0FBQUEsRUFDN0M7QUFDRjtBQU9BLFNBQVMsWUFBWSxHQUE4QztBQUNqRSxRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksTUFBTSxNQUFNO0FBQ25DLE1BQUksQ0FBQyxXQUFZLFFBQU87QUFDeEIsUUFBTSxXQUFXLFdBQVc7QUFDNUIsUUFBTSxRQUFpQyxDQUFDO0FBQ3hDLE1BQUksTUFBTSxRQUFRLFFBQVEsR0FBRztBQUMzQixlQUFXLE1BQU0sVUFBVTtBQUN6QixVQUFJLE9BQU8sT0FBTyxZQUFZLE9BQU8sS0FBTTtBQUMzQyxZQUFNLElBQUk7QUFDVixZQUFNLElBQUksVUFBVSxFQUFFLEdBQUc7QUFDekIsWUFBTSxJQUFJLElBQUksRUFBRSxLQUFLO0FBQ3JCLFVBQUksQ0FBQyxLQUFLLENBQUMsRUFBRztBQUNkLFlBQU0sQ0FBQyxJQUNMLFVBQVUsRUFBRSxZQUFZLEtBQ3hCLFVBQVUsSUFBSSxFQUFFLFdBQVcsR0FBRyxHQUFHLEtBQ2pDLFVBQVUsSUFBSSxFQUFFLGlCQUFpQixHQUFHLE9BQU87QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sVUFBVSxXQUFXLElBQUk7QUFDdEMsUUFBTSxVQUFVLFVBQVUsV0FBVyxHQUFHO0FBQ3hDLFFBQU0sWUFDSixPQUFPLE1BQU0sWUFBWSxNQUFNLFdBQVksTUFBTSxZQUFZLElBQWU7QUFDOUUsUUFBTSxRQUFRLE9BQU8sTUFBTSxPQUFPLE1BQU0sV0FBWSxNQUFNLE9BQU8sSUFBZTtBQUNoRixRQUFNLGNBQ0osT0FBTyxNQUFNLGFBQWEsTUFBTSxXQUFZLE1BQU0sYUFBYSxJQUFlO0FBQ2hGLFFBQU0sWUFDSCxPQUFPLE1BQU0sZ0NBQWdDLE1BQU0sV0FDL0MsTUFBTSxnQ0FBZ0MsSUFDdkMsVUFDSCxPQUFPLE1BQU0sMEJBQTBCLE1BQU0sV0FDekMsTUFBTSwwQkFBMEIsSUFDakMsVUFDSCxPQUFPLE1BQU0sOEJBQThCLE1BQU0sV0FDN0MsTUFBTSw4QkFBOEIsSUFDckM7QUFDTixNQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsU0FBVSxRQUFPO0FBQ3pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiO0FBQ0Y7OztBQ3J6QkEsSUFBTSxXQUFXO0FBRVYsU0FBUyxXQUFtQjtBQUNqQyxRQUFNLEtBQUssS0FBSyxJQUFJO0FBQ3BCLE1BQUksU0FBUztBQUNiLE1BQUksSUFBSTtBQUNSLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLGNBQVUsU0FBUyxJQUFJLEVBQUUsS0FBSyxPQUFPO0FBQ3JDLFFBQUksS0FBSyxNQUFNLElBQUksRUFBRTtBQUFBLEVBQ3ZCO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLEtBQU0sYUFBWSxTQUFTLElBQUksRUFBRSxLQUFLO0FBQ3RELFNBQU8sU0FBUztBQUNsQjtBQUVPLFNBQVMsV0FBVyxJQUFvQjtBQUM3QyxTQUFPLEdBQUcsTUFBTSxFQUFFO0FBQ3BCOzs7QUNQQSxJQUFNLG1CQUFpRCxvQkFBSSxJQUFJO0FBQUEsRUFDN0Q7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVNLFNBQVMsa0JBQWtCLE1BQStCO0FBQy9ELFFBQU0sV0FBNEIsQ0FBQztBQUNuQyxNQUFJLFVBQWtDLENBQUM7QUFDdkMsTUFBSSxhQUFhO0FBQ2pCLFFBQU0sUUFBUSxNQUFNO0FBQ2xCLFFBQUksUUFBUSxVQUFVLFFBQVEsT0FBTztBQUNuQyxVQUFJLENBQUMsUUFBUSxTQUFVLFNBQVEsV0FBVztBQUMxQyxlQUFTLEtBQUssT0FBd0I7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFDQSxhQUFXLFdBQVcsS0FBSyxNQUFNLElBQUksR0FBRztBQUN0QyxVQUFNLE9BQU8sY0FBYyxPQUFPO0FBQ2xDLFFBQUksS0FBSyxLQUFLLE1BQU0sR0FBSTtBQUN4QixRQUFJLGdCQUFnQixLQUFLLElBQUksR0FBRztBQUM5QixtQkFBYTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxXQUFZO0FBRWpCLFVBQU0sWUFBWSxLQUFLLE1BQU0sNEJBQTRCO0FBQ3pELFFBQUksV0FBVztBQUNiLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxVQUFVLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDaEQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx3QkFBd0I7QUFDdEQsUUFBSSxjQUFjLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUNyQyxZQUFNO0FBQ04sZ0JBQVUsRUFBRSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2pEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sdUJBQXVCO0FBQ3JELFFBQUksY0FBYyxRQUFRLFFBQVE7QUFDaEMsY0FBUSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRTtBQUMzQztBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixLQUFLLE1BQU0sMEJBQTBCO0FBQzNELFFBQUksaUJBQWlCLFFBQVEsUUFBUTtBQUNuQyxZQUFNLE1BQU0sUUFBUSxjQUFjLENBQUMsS0FBSyxFQUFFO0FBQzFDLGNBQVEsV0FBVyxpQkFBaUIsSUFBSSxHQUFzQixJQUN6RCxNQUNEO0FBQ0o7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU07QUFDTixTQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUNuRDtBQUVBLFNBQVMsY0FBYyxNQUFzQjtBQUczQyxRQUFNLE1BQU0sS0FBSyxRQUFRLEdBQUc7QUFDNUIsU0FBTyxRQUFRLEtBQUssT0FBTyxLQUFLLE1BQU0sR0FBRyxHQUFHO0FBQzlDO0FBRUEsU0FBUyxRQUFRLEdBQW1CO0FBQ2xDLFFBQU0sVUFBVSxFQUFFLEtBQUs7QUFDdkIsTUFDRyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQy9DLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsR0FDaEQ7QUFDQSxXQUFPLFFBQVEsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUM1QjtBQUNBLFNBQU87QUFDVDs7O0FDTEEsSUFBTSxjQUFjLFFBQVEsUUFBUSxZQUFZLEVBQUU7QUFFbEQsZUFBZSxDQUFDLE9BQWlCO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxhQUFhLE9BQU8sR0FBRyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFLENBQUM7QUFJRCxRQUFRLFFBQVEsWUFBWSxZQUFZLFlBQVk7QUFDbEQsUUFBTSxLQUFLLHVCQUF1QixFQUFFLFNBQVMsWUFBWSxDQUFDO0FBQzFELFFBQU0sT0FBTyxTQUFTO0FBQ3hCLENBQUM7QUFFRCxRQUFRLFFBQVEsVUFBVSxZQUFZLE1BQU07QUFDMUMsT0FBSyxPQUFPLFNBQVM7QUFDdkIsQ0FBQztBQUdELEtBQUssT0FBTyxhQUFhO0FBRXpCLGVBQWUsT0FBTyxRQUErQjtBQUNuRCxNQUFJO0FBQ0YsVUFBTSxhQUFhO0FBQ25CLFVBQU0sc0JBQXNCO0FBQzVCLFVBQU0sNEJBQTRCO0FBQ2xDLFVBQU0scUJBQXFCO0FBRzNCLFVBQU0sU0FBUyxNQUFNLG9CQUFvQixLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUk7QUFDakUsUUFBSSxTQUFTLEVBQUcsT0FBTSxLQUFLLDBCQUEwQixFQUFFLE9BQU8sQ0FBQztBQUMvRCxVQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQUksU0FBUyxPQUFPLFNBQVMsU0FBUyxTQUFTLE1BQU07QUFDbkQsWUFBTSxpQkFBaUIsS0FBSztBQUM1QixZQUFNLG9CQUFvQixLQUFLO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU87QUFBQSxRQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlO0FBQUEsUUFDZix3QkFBd0I7QUFBQSxRQUN4QixrQkFBa0I7QUFBQSxNQUNwQixDQUFDO0FBQ0QsWUFBTSxLQUFLLHdDQUF3QyxFQUFFLE9BQU8sQ0FBQztBQUFBLElBQy9EO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixVQUFNLE1BQU8sZUFBZSxFQUFFLFFBQVEsR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDL0Q7QUFDRjtBQVlBLGVBQWUsdUJBQXNDO0FBQ25ELE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsRUFDdkYsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDZCQUE2QixjQUFjLEdBQUcsQ0FBQztBQUMxRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJO0FBQ0YsWUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJdEIsT0FBTztBQUFBLE1BQ1QsQ0FBQztBQUNELFlBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLE1BQ3RCLENBQUM7QUFDRCxZQUFNLEtBQUsscUNBQXFDO0FBQUEsUUFDOUMsT0FBTyxJQUFJO0FBQUEsUUFDWCxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUU7QUFBQSxNQUMvQixDQUFDO0FBQUEsSUFDSCxTQUFTLEtBQUs7QUFJWixZQUFNLEtBQUssd0NBQXdDO0FBQUEsUUFDakQsT0FBTyxJQUFJO0FBQUEsUUFDWCxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUU7QUFBQSxRQUM3QixHQUFHLGNBQWMsR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxRQUFNLFFBQVEsT0FBTyxNQUFNLGFBQWE7QUFDeEMsUUFBTSxRQUFRLE9BQU8sTUFBTSxtQkFBbUI7QUFDOUMsUUFBTSxRQUFRLE9BQU8sT0FBTyxlQUFlLEVBQUUsaUJBQWlCLG9CQUFvQixDQUFDO0FBQ25GLFFBQU0sUUFBUSxPQUFPLE9BQU8scUJBQXFCO0FBQUEsSUFDL0MsaUJBQWlCLGdDQUFnQztBQUFBLEVBQ25ELENBQUM7QUFDSDtBQU1BLElBQUksa0JBQXlEO0FBSzdELElBQU0saUJBQWlCO0FBRXZCLGVBQWUsd0JBQXVDO0FBRXBELFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLE1BQUksU0FBUyxRQUFRLEVBQUUsWUFBWSxPQUFPO0FBQ3hDLHVCQUFtQixFQUFFLHFCQUFxQjtBQUFBLEVBQzVDLE9BQU87QUFDTCx5QkFBcUI7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyx1QkFBNkI7QUFDcEMsTUFBSSxvQkFBb0IsTUFBTTtBQUM1QixrQkFBYyxlQUFlO0FBQzdCLHNCQUFrQjtBQUFBLEVBQ3BCO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixhQUEyQjtBQUNyRCx1QkFBcUI7QUFDckIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sV0FBVyxDQUFDO0FBQUEsRUFDdkQ7QUFDQSxvQkFBa0IsWUFBWSxNQUFNO0FBQ2xDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsYUFBYTtBQUFBLElBQ2IsZUFBZTtBQUFBLElBQ2YsZUFBZTtBQUFBLEVBQ2pCLENBQUM7QUFDRCxxQkFBbUIsRUFBRSxxQkFBcUI7QUFDMUMsUUFBTSxLQUFLLDRCQUE0QixFQUFFLGNBQWMsRUFBRSxzQkFBc0IsQ0FBQztBQUVoRixPQUFLLGVBQWU7QUFDcEIsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQsdUJBQXFCO0FBQ3JCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLE1BQU0sZUFBZTtBQUFBLElBQzlCLFVBQVUsTUFBTSxpQkFBaUI7QUFBQSxJQUNqQyxVQUFVLE1BQU0saUJBQWlCO0FBQUEsRUFDbkMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsaUJBQWdDO0FBQzdDLE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsRUFDdkYsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlDQUFpQyxjQUFjLEdBQUcsQ0FBQztBQUM5RDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLE1BQUksY0FBYztBQUNsQixNQUFJLGdCQUFnQjtBQUNwQixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVU7QUFDaEMsUUFBSSxJQUFJLFVBQVc7QUFDbkIsUUFBSTtBQUNGLFlBQU0sVUFBVyxNQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDckQsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSVAsTUFBTyxNQUFNO0FBS1gsZ0JBQU0sc0JBQXNCO0FBQUEsWUFDMUI7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFDQSxnQkFBTSxVQUFVLG9CQUFJLElBQWE7QUFDakMsY0FBSSxXQUFXO0FBQ2YscUJBQVcsT0FBTyxxQkFBcUI7QUFDckMsdUJBQVcsTUFBTSxNQUFNLEtBQUssU0FBUyxpQkFBaUIsR0FBRyxDQUFDLEdBQUc7QUFDM0Qsa0JBQUksUUFBUSxJQUFJLEVBQUUsRUFBRztBQUVyQixvQkFBTSxLQUFLLEdBQUcsZUFBZSxJQUFJLEtBQUssRUFBRSxZQUFZO0FBQ3BELGtCQUFJLE1BQU0sZUFBZSxNQUFNLG1CQUFvQjtBQUNuRCxvQkFBTSxPQUFPLEdBQUcsc0JBQXNCO0FBQ3RDLGtCQUFJLEtBQUssVUFBVSxLQUFLLEtBQUssV0FBVyxFQUFHO0FBQzNDLHNCQUFRLElBQUksRUFBRTtBQUNkLGtCQUFJO0FBQ0YsZ0JBQUMsR0FBbUIsTUFBTTtBQUMxQiw0QkFBWTtBQUFBLGNBQ2QsUUFBUTtBQUFBLGNBRVI7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUlBLGdCQUFNLE9BQTBCO0FBQUEsWUFDOUIsS0FBSztBQUFBLFlBQ0wsTUFBTTtBQUFBLFlBQ04sU0FBUztBQUFBLFlBQ1QsT0FBTztBQUFBLFlBQ1AsU0FBUztBQUFBLFlBQ1QsWUFBWTtBQUFBLFVBQ2Q7QUFDQSxnQkFBTSxRQUFTLFNBQVMsaUJBQXdDLFNBQVM7QUFDekUsZ0JBQU0sY0FBYyxJQUFJLGNBQWMsV0FBVyxJQUFJLENBQUM7QUFDdEQsZ0JBQU0sY0FBYyxJQUFJLGNBQWMsU0FBUyxJQUFJLENBQUM7QUFDcEQsaUJBQU8sU0FBUztBQUFBLFlBQ2QsS0FBSyxTQUFTLGdCQUFnQjtBQUFBLFlBQzlCLFVBQVU7QUFBQSxVQUNaLENBQUM7QUFDRCxpQkFBTyxFQUFFLFNBQVM7QUFBQSxRQUNwQjtBQUFBLE1BQ0YsQ0FBQztBQUNELHFCQUFlO0FBQ2YsWUFBTSxJQUFJLFFBQVEsQ0FBQyxHQUFHO0FBQ3RCLFVBQUksS0FBSyxPQUFPLEVBQUUsYUFBYSxTQUFVLGtCQUFpQixFQUFFO0FBQUEsSUFDOUQsUUFBUTtBQUFBLElBR1I7QUFBQSxFQUNGO0FBQ0EsTUFBSSxjQUFjLEdBQUc7QUFDbkIsVUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQUksU0FBUyxNQUFNO0FBQ2pCLFdBQUssZUFBZTtBQUNwQixXQUFLLGlCQUFpQjtBQUN0QixZQUFNLHFCQUFxQixJQUFJO0FBQUEsSUFFakM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxRQUFRLE9BQU8sUUFBUSxZQUFZLENBQUMsVUFBVTtBQUM1QyxNQUFJLE1BQU0sU0FBUyxlQUFlO0FBQ2hDLFNBQUssaUJBQWlCO0FBQUEsRUFDeEIsV0FBVyxNQUFNLFNBQVMscUJBQXFCO0FBQzdDLFNBQUssaUJBQWlCLEtBQUs7QUFBQSxFQUM3QjtBQUlGLENBQUM7QUFJRCxJQUFJLFFBQVEsUUFBUSxXQUFXO0FBQzdCLFVBQVEsT0FBTyxVQUFVLFlBQVksWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTSxRQUFRLGNBQWMsT0FBTztBQUFBLElBQ3JDLFNBQVMsS0FBSztBQUVaLFlBQU0sS0FBSywwQ0FBMEMsY0FBYyxHQUFHLENBQUM7QUFDdkUsWUFBTSxRQUFRLFFBQVEsZ0JBQWdCO0FBQUEsSUFDeEM7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUlBLFFBQVEsUUFBUSxVQUFVLFlBQVksQ0FBQyxLQUFjLFlBQVk7QUFDL0QsTUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUcsUUFBTztBQUNuQyxTQUFPLGNBQWMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ3ZDLFNBQUssTUFBTywwQkFBMEIsRUFBRSxNQUFNLElBQUksTUFBTSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDL0UsVUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNILENBQUM7QUFFRCxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxTQUFPLENBQUMsQ0FBQyxLQUFLLE9BQU8sTUFBTSxZQUFZLE9BQVEsRUFBeUIsU0FBUztBQUNuRjtBQUlBLElBQU0sNEJBQTRCLG9CQUFJLElBQTRCO0FBQUEsRUFDaEU7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFFRCxlQUFlLFlBQThCO0FBQzNDLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsU0FBTyxFQUFFLFlBQVk7QUFDdkI7QUFFQSxlQUFlLGNBQWMsS0FBdUM7QUFLbEUsTUFBSSxDQUFFLE1BQU0sVUFBVSxLQUFNLDBCQUEwQixJQUFJLElBQUksSUFBSSxHQUFHO0FBQ25FLFdBQU8sRUFBRSxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUEsRUFDbEM7QUFDQSxVQUFRLElBQUksTUFBTTtBQUFBLElBQ2hCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJLFVBQVUsSUFBSSxLQUFLLElBQUksV0FBVyxNQUFNLElBQUksUUFBUTtBQUMvRSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN2RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN0RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFVBQUksSUFBSSxVQUFVLFFBQVE7QUFDeEIsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQsV0FBVyxJQUFJLFVBQVUsU0FBUztBQUNoQyxjQUFNLE1BQU8sSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNwRCxPQUFPO0FBQ0wsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQ7QUFDQSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFdBQVcsSUFBSSxNQUFNO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFdBQVc7QUFDakIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZ0JBQWdCO0FBQ3RCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFNBQVMsTUFBTTtBQUNyQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxZQUFZLElBQUksUUFBUSxNQUFNO0FBQ3BDLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGVBQWUsRUFBRSxhQUFhLElBQUksR0FBRyxDQUFDO0FBQzVDLFlBQU0sS0FBSyx3QkFBd0IsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQ2pELGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssa0JBQWtCO0FBQ3JCLFlBQU0sSUFBSSxNQUFNLGVBQWUsRUFBRSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2xELFVBQUksQ0FBQyxJQUFJLElBQUk7QUFHWCw2QkFBcUI7QUFDckIsNEJBQW9CO0FBQ3BCLCtCQUF1QjtBQUN2QixjQUFNLFFBQVEsT0FBTyxNQUFNLGNBQWM7QUFDekMsY0FBTSxRQUFRLE9BQU8sTUFBTSxrQkFBa0I7QUFBQSxNQUMvQyxPQUFPO0FBRUwsY0FBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFlBQUksU0FBUyxLQUFNLG9CQUFtQixFQUFFLHFCQUFxQjtBQUFBLE1BQy9EO0FBQ0EsWUFBTSxLQUFLLG1DQUFtQyxFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDNUQsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQjtBQUMxQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxxQkFBcUI7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSyw0QkFBNEI7QUFDL0IsWUFBTSxVQUFVLEtBQUs7QUFBQSxRQUNuQjtBQUFBLFFBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sSUFBSSxPQUFPLENBQUM7QUFBQSxNQUN2RDtBQUNBLFlBQU0sZUFBZSxFQUFFLHVCQUF1QixRQUFRLENBQUM7QUFFdkQsWUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFVBQUksU0FBUyxLQUFNLG9CQUFtQixPQUFPO0FBQzdDLFVBQUksMEJBQTBCLEtBQU0sc0JBQXFCLE9BQU87QUFDaEUsVUFBSSw2QkFBNkIsS0FBTSx5QkFBd0IsT0FBTztBQUN0RSxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0saUJBQWlCO0FBQ3ZCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGtCQUFrQjtBQUN4QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssbUJBQW1CO0FBQ3RCLFlBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsWUFBTSxVQUFVLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUMvRCxZQUFNLFVBQVUsTUFBTSxvQkFBb0IsT0FBTztBQUNqRCxZQUFNLEtBQUssMEJBQTBCLE9BQU87QUFDNUMsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQixJQUFJO0FBQzlCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGNBQWM7QUFDcEIsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFDdEMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssZUFBZTtBQUNsQixZQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFlBQU0sTUFBTSxVQUFVLENBQUM7QUFDdkIsWUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLElBQUksQ0FBQztBQUNqQyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQ0UsYUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLHVCQUF1QjtBQUFBLEVBQ3REO0FBQ0Y7QUFJQSxlQUFlLGlCQUNiLFVBQ0EsS0FDQSxTQUNBLFVBQ2U7QUFDZixNQUFJLGtCQUFrQixJQUFJLFFBQVEsRUFBRztBQUNyQyxNQUFJLENBQUMsZ0JBQWdCLElBQUksUUFBUSxFQUFHO0FBRXBDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFnQm5DLFFBQU0sVUFBVSxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDbkUsUUFBTSxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBRTFDLE1BQUk7QUFDSixNQUFJO0FBQ0YsaUJBQWEsVUFBVSxVQUFVO0FBQUEsTUFDL0I7QUFBQSxNQUNBLE9BQU87QUFBQSxNQUNQO0FBQUEsTUFDQSxnQkFBZ0Isb0JBQUksSUFBWTtBQUFBLE1BQ2hDLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sV0FBVyxtQkFBbUIsVUFBVSxLQUFLLFVBQVUsR0FBRztBQUNoRTtBQUFBLEVBQ0Y7QUFRQSxRQUFNLGVBQWUsV0FBVyxPQUFPO0FBQ3ZDLGFBQVcsU0FBUyxjQUFjLFdBQVcsUUFBUSxPQUFPO0FBQzVELFFBQU0sbUJBQW1CLGVBQWUsV0FBVyxPQUFPO0FBQzFELE1BQUksbUJBQW1CLEdBQUc7QUFDeEIsVUFBTSxLQUFLLDRCQUE0QjtBQUFBLE1BQ3JDO0FBQUEsTUFDQSxTQUFTO0FBQUEsTUFDVCxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBT0EsTUFBSSxXQUFXLGFBQWEsV0FBVyxHQUFHO0FBQ3hDLFVBQU0sS0FBSyw0Q0FBdUM7QUFBQSxNQUNoRDtBQUFBLE1BQ0EsV0FBVyxlQUFlLFFBQVEsRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLE1BQy9DLFlBQVksb0JBQW9CLFVBQVUsT0FBTztBQUFBLE1BQ2pELGlCQUFpQixpQkFBaUIsVUFBVSxTQUFTLENBQUMsTUFBTSxDQUFDO0FBQUEsTUFDN0QsbUJBQW1CLGlCQUFpQixVQUFVLFNBQVMsQ0FBQyxRQUFRLENBQUM7QUFBQSxNQUNqRSwwQkFBMEIsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQzVEO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxNQUNELCtCQUErQixpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDakU7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxNQUNELGlDQUFpQyxpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDbkU7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNILE9BQU87QUFDTCxVQUFNLEtBQUssd0JBQXdCO0FBQUEsTUFDakM7QUFBQSxNQUNBLFVBQVUsV0FBVyxhQUFhO0FBQUEsTUFDbEMsTUFBTSxXQUFXLE9BQU87QUFBQSxJQUMxQixDQUFDO0FBQUEsRUFDSDtBQUVBLE1BQUksV0FBVyxtQkFBbUIsU0FBUyxHQUFHO0FBQzVDLFVBQU0sd0JBQXdCLFdBQVcsb0JBQW9CLFNBQVMsWUFBWSxLQUFLLFFBQVE7QUFBQSxFQUNqRztBQUVBLE1BQUksV0FBVyxPQUFPLFdBQVcsRUFBRztBQVdwQyxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsYUFBVyxLQUFLLFdBQVcsUUFBUTtBQUNqQyxRQUFJLEVBQUUsY0FBYztBQUNsQixZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRO0FBQUEsSUFDbkQsT0FBTztBQUNMLFlBQU0sZUFBZSxFQUFFLGdCQUFnQixFQUFFLFFBQVE7QUFBQSxJQUNuRDtBQUdBLFVBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxRQUFJLGFBQWEsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNqRCxrQkFBWSxXQUFXO0FBQ3ZCLGtCQUFZLGFBQWE7QUFDekIsWUFBTSxrQkFBa0IsV0FBVztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUtBLGFBQVcsV0FBVyxXQUFXLGFBQWE7QUFDNUMsUUFBSSxNQUFNLFlBQVksUUFBUSxRQUFRLEVBQUc7QUFDekMsVUFBTSxrQkFBa0IsUUFBUSxhQUFhLFFBQVEsUUFBUTtBQUFBLEVBQy9EO0FBQ0EsTUFBSSxXQUFXLFlBQVksU0FBUyxHQUFHO0FBQ3JDLFVBQU0sS0FBSywwQ0FBMEM7QUFBQSxNQUNuRDtBQUFBLE1BQ0EsU0FBUyxXQUFXLFlBQVk7QUFBQSxNQUNoQyxhQUFhLE1BQU0scUJBQXFCO0FBQUEsSUFDMUMsQ0FBQztBQUFBLEVBQ0g7QUFRQSxRQUFNLGVBQWUsTUFBTSxrQkFBa0I7QUFDN0MsTUFBSSxpQkFBaUI7QUFDckIsUUFBTSxhQUF1QyxDQUFDO0FBQzlDLGFBQVcsS0FBSyxXQUFXLFFBQVE7QUFDakMsVUFBTSxPQUFPLGFBQWEsRUFBRSxjQUFjLElBQUksRUFBRSxRQUFRO0FBQ3hELFVBQU0sTUFBTTtBQUFBLE1BQ1YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLE1BQ0YsRUFBRTtBQUFBLElBQ0o7QUFDQSxRQUFJLFFBQVEsS0FBSyxRQUFRLEtBQUs7QUFDNUIsd0JBQWtCO0FBQ2xCO0FBQUEsSUFDRjtBQUNBLGVBQVcsS0FBSyxDQUFDO0FBQUEsRUFDbkI7QUFDQSxNQUFJLGlCQUFpQixHQUFHO0FBQ3RCLFVBQU0sS0FBSyxtQ0FBbUM7QUFBQSxNQUM1QztBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsV0FBVyxXQUFXO0FBQUEsSUFDeEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxNQUFJLFdBQVcsV0FBVyxFQUFHO0FBRzdCLFFBQU0sV0FBVyxvQkFBSSxJQUE4QjtBQUNuRCxhQUFXLEtBQUssWUFBWTtBQUMxQixVQUFNLE1BQU0sU0FBUyxJQUFJLEVBQUUsY0FBYyxLQUFLLENBQUM7QUFDL0MsUUFBSSxLQUFLLENBQUM7QUFDVixhQUFTLElBQUksRUFBRSxnQkFBZ0IsR0FBRztBQUFBLEVBQ3BDO0FBRUEsYUFBVyxDQUFDLFFBQVEsTUFBTSxLQUFLLFVBQVU7QUFDdkMsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxLQUFLLFFBQVE7QUFDbkUsUUFBSSxRQUFRO0FBQ1osZUFBVyxLQUFLLFFBQVE7QUFDdEIsWUFBTSxXQUFXLElBQUksYUFBYSxFQUFFLFFBQVE7QUFDNUMsVUFBSSxVQUFVO0FBR1osaUJBQVMsZUFBZTtBQUN4QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsZ0JBQWdCLEVBQUU7QUFDM0IsaUJBQVMsY0FBYyxFQUFFO0FBQ3pCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsaUJBQWlCLEVBQUU7QUFDNUIsY0FBTSxPQUFPLFNBQVMsbUJBQW1CLFNBQVMsbUJBQW1CLFNBQVMsQ0FBQztBQUMvRSxjQUFNLE9BQU8sRUFBRSxtQkFBbUIsQ0FBQztBQUNuQyxZQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssZ0JBQWdCLEtBQUssY0FBYztBQUM1RCxtQkFBUyxtQkFBbUIsS0FBSyxJQUFJO0FBQUEsUUFDdkM7QUFBQSxNQUNGLE9BQU87QUFDTCxjQUFNLFVBQTBCLEVBQUUsR0FBRyxHQUFHLGdCQUFnQixJQUFJLE9BQU87QUFDbkUsWUFBSSxhQUFhLEVBQUUsUUFBUSxJQUFJO0FBQy9CLGlCQUFTO0FBQUEsTUFDWDtBQUNBLFVBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQ2hELFlBQUksbUJBQW1CLEtBQUssRUFBRSxRQUFRO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTTtBQUFBLE1BQ0o7QUFBQSxNQUNBLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRSxTQUFTLE9BQU8sS0FBSyxJQUFJLHFCQUFxQixDQUFDLENBQUMsRUFBRTtBQUFBLElBQ2xGO0FBQ0EsUUFBSSxRQUFRLEdBQUc7QUFDYixZQUFNLEtBQUssbUJBQW1CO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsT0FBTyxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUU7QUFBQSxNQUN2QyxDQUFDO0FBR0QsWUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8saUJBQWlCO0FBQ3hCLGNBQU0scUJBQXFCLE1BQU07QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRSxVQUFVLHVCQUF1QjtBQUNqRSxZQUFNLFlBQVksUUFBUSxXQUFXO0FBQUEsSUFDdkM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSx3QkFDYixtQkFDQSxTQUNBLFlBQ0EsV0FDQSxVQUNlO0FBQ2YsUUFBTSxlQUFlLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sY0FBYyxNQUFNLGtCQUFrQjtBQUM1QyxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxNQUFJLFdBQVc7QUFDZixNQUFJLFVBQVU7QUFDZCxNQUFJLGdCQUFnQjtBQUVwQixhQUFXLEtBQUssbUJBQW1CO0FBQ2pDLFVBQU0sU0FBUyxFQUFFO0FBQ2pCLFFBQUksQ0FBQyxRQUFRO0FBQ1gsdUJBQWlCO0FBQ2pCLFlBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQztBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsT0FBTyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sWUFBWSxDQUFDLEdBQUc7QUFDMUQsaUJBQVc7QUFDWDtBQUFBLElBQ0Y7QUFFQSxVQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsVUFBTSxlQUFlLFFBQVEsRUFBRSxRQUFRO0FBQ3ZDLFFBQUksYUFBYSxVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ2pELGtCQUFZLFdBQVc7QUFDdkIsa0JBQVksYUFBYTtBQUN6QixZQUFNLGtCQUFrQixXQUFXO0FBQUEsSUFDckM7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLHFCQUFxQixjQUFjO0FBQUEsSUFDM0M7QUFFQSxVQUFNLE1BQU0sZUFBZSxDQUFDO0FBQzVCLFVBQU0sT0FBTyxhQUFhLE1BQU0sSUFBSSxFQUFFLFFBQVE7QUFDOUMsUUFBSSxNQUFNLFFBQVEsS0FBSztBQUNyQixpQkFBVztBQUNYO0FBQUEsSUFDRjtBQUVBLFVBQU0sTUFBTSxNQUFNLGdCQUFnQixRQUFRLFlBQVksV0FBVyxRQUFRO0FBQ3pFLFVBQU0sa0JBQWtCLElBQUkscUJBQXFCLENBQUM7QUFDbEQsb0JBQWdCLEVBQUUsUUFBUSxJQUFJO0FBQzlCLFFBQUksb0JBQW9CO0FBQ3hCLFFBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxHQUFHO0FBQ2hELFVBQUksbUJBQW1CLEtBQUssRUFBRSxRQUFRO0FBQUEsSUFDeEM7QUFDQSxRQUFJLENBQUMsSUFBSSxlQUFlLFNBQVMsUUFBUSxFQUFHLEtBQUksZUFBZSxLQUFLLFFBQVE7QUFDNUUsUUFBSSxrQkFBa0I7QUFDdEIsVUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixVQUFNO0FBQUEsTUFDSjtBQUFBLE1BQ0EsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFNBQVMsT0FBTyxLQUFLLGVBQWUsRUFBRTtBQUFBLElBQ3RFO0FBQ0EsZ0JBQVk7QUFBQSxFQUNkO0FBRUEsTUFBSSxXQUFXLEtBQUssZ0JBQWdCLEtBQUssVUFBVSxHQUFHO0FBQ3BELFVBQU0sS0FBSywrQkFBK0IsRUFBRSxVQUFVLFVBQVUsU0FBUyxjQUFjLENBQUM7QUFBQSxFQUMxRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLFNBQVMsZUFBZSxHQUE2QjtBQUNuRCxTQUFPLGVBQWUsRUFBRSxzQkFBc0IsRUFBRSxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7QUFDOUU7QUFFQSxlQUFlLGdCQUNiLFFBQ0EsSUFDQSxXQUNBLFVBQ29CO0FBQ3BCLFFBQU0sTUFBTSxNQUFNLGFBQWEsTUFBTTtBQUNyQyxNQUFJLElBQUssUUFBTztBQUNoQixRQUFNLE1BQWlCO0FBQUEsSUFDckIsUUFBUSxTQUFTO0FBQUEsSUFDakIsZ0JBQWdCO0FBQUEsSUFDaEIsWUFBWTtBQUFBLElBQ1osaUJBQWlCO0FBQUEsSUFDakIsY0FBYyxDQUFDO0FBQUEsSUFDZixtQkFBbUIsQ0FBQztBQUFBLElBQ3BCLG9CQUFvQixDQUFDO0FBQUEsSUFDckIsZ0JBQWdCLENBQUMsUUFBUTtBQUFBLElBQ3pCLFlBQVk7QUFBQSxFQUNkO0FBQ0EsUUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixRQUFNLEtBQUssZUFBZSxFQUFFLFFBQVEsS0FBSyxXQUFXLElBQUksTUFBTSxFQUFFLENBQUM7QUFDakUsU0FBTztBQUNUO0FBSUEsSUFBSSxhQUE0QixRQUFRLFFBQVE7QUFlaEQsZUFBZSxtQkFBa0M7QUFDL0MsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLFFBQU0sVUFBb0IsQ0FBQztBQUMzQixhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUMvQyxVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksZUFBZTtBQUMzQyxRQUFJLE9BQU8sU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLGVBQWU7QUFDeEQsY0FBUSxLQUFLLE1BQU07QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsU0FBUyxNQUFNO0FBQ3BDO0FBRUEsZUFBZSw4QkFBNkM7QUFPMUQsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxLQUFNO0FBQ3hELFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxNQUFNLEtBQUssSUFBSTtBQUNyQixRQUFNLFVBQW9CLENBQUM7QUFDM0IsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELGNBQVEsS0FBSyxNQUFNO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxhQUFhLFNBQVMsTUFBTTtBQUNwQztBQUVBLGVBQWUsU0FBUyxRQUErQjtBQUNyRCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sYUFBYSxPQUFPLEtBQUssR0FBRyxHQUFHLE1BQU07QUFDN0M7QUFFQSxlQUFlLFlBQVksUUFBZ0IsUUFBK0I7QUFDeEUsUUFBTSxhQUFhLENBQUMsTUFBTSxHQUFHLE1BQU07QUFDckM7QUFFQSxlQUFlLGFBQWEsU0FBbUIsUUFBK0I7QUFDNUUsUUFBTSxTQUFTLENBQUMsR0FBRyxJQUFJLElBQUksT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7QUFDL0QsTUFBSSxPQUFPLFdBQVcsRUFBRztBQUN6QixRQUFNLE1BQU0sV0FBVyxLQUFLLE1BQU0sbUJBQW1CLFFBQVEsTUFBTSxDQUFDO0FBQ3BFLGVBQWEsSUFBSSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDL0IsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUIsU0FBbUIsUUFBK0I7QUFDbEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLFFBQXFCLENBQUM7QUFDNUIsYUFBVyxVQUFVLFNBQVM7QUFDNUIsVUFBTSxNQUFNLElBQUksTUFBTTtBQUN0QixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sU0FBUyxPQUFPLE9BQU8sSUFBSSxZQUFZO0FBQzdDLFVBQU0sb0JBQW9CLE9BQU8sT0FBTyxJQUFJLHFCQUFxQixDQUFDLENBQUM7QUFDbkUsUUFBSSxPQUFPLFdBQVcsS0FBSyxrQkFBa0IsV0FBVyxHQUFHO0FBQ3pELFlBQU0sZUFBZSxNQUFNO0FBQzNCLFlBQU0saUJBQWlCLFFBQVEsQ0FBQztBQUNoQztBQUFBLElBQ0Y7QUFDQSxVQUFNLEtBQUssZUFBZSxRQUFRLEtBQUssUUFBUSxpQkFBaUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsTUFBSSxNQUFNLFdBQVcsRUFBRztBQUV4QixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLE1BQU07QUFDdEQsVUFBTSxLQUFLLHVDQUF1QztBQUFBLE1BQ2hELE9BQU8sTUFBTTtBQUFBLE1BQ2IsU0FBUyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsSUFDdkQsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxRQUFNLFFBQVEsTUFBTSxRQUFRLENBQUMsU0FBUztBQUFBLElBQ3BDO0FBQUEsTUFDRSxNQUFNLEtBQUs7QUFBQSxNQUNYLGVBQWVDLFVBQVMsS0FBSyxVQUFVLEtBQUssU0FBUyxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsSUFDdEU7QUFBQSxJQUNBO0FBQUEsTUFDRSxNQUFNLEtBQUs7QUFBQSxNQUNYLGVBQWVBLFVBQVMsS0FBSyxVQUFVLEtBQUssTUFBTSxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsSUFDbkU7QUFBQSxFQUNGLENBQUM7QUFDRCxRQUFNLFlBQVksd0JBQXdCLEtBQUs7QUFFL0MsTUFBSTtBQUNGLFVBQU0sU0FBUyxNQUFNLE9BQU8sWUFBWTtBQUFBLE1BQ3RDO0FBQUEsTUFDQSxTQUFTO0FBQUEsSUFDWCxDQUFDO0FBQ0QsVUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLGVBQVcsUUFBUSxPQUFPO0FBQ3hCLFlBQU0saUJBQWlCLE1BQU0sK0JBQStCLElBQUk7QUFLaEUsWUFBTSxRQUFRLE1BQU0sWUFBWSxHQUFHLEtBQUssTUFBTTtBQUM5QyxZQUFNLFNBQVEsb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUNsRCxZQUFNLGVBQWUsUUFBUSxLQUFLLGNBQWMsUUFBUSxLQUFLLGFBQWE7QUFDMUUsWUFBTSxZQUFZLEtBQUssUUFBUTtBQUFBLFFBQzdCLFlBQVksZUFBZSxLQUFLLE9BQU8sU0FBUyxLQUFLLGtCQUFrQjtBQUFBLFFBQ3ZFLFdBQVc7QUFBQSxRQUNYLGVBQWUsS0FBSyxJQUFJO0FBQUEsUUFDeEIsaUJBQ0csTUFBTSxrQkFBa0IsS0FBSyxLQUFLLE9BQU8sU0FBUyxLQUFLLGtCQUFrQjtBQUFBLFFBQzVFLGVBQWU7QUFBQSxNQUNqQixDQUFDO0FBR0QsWUFBTSxRQUFRLElBQUksS0FBSyxNQUFNLEtBQUssQ0FBQztBQUNuQyxZQUFNLFVBQVMsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDdEMsaUJBQVcsS0FBSyxLQUFLLFFBQVE7QUFDM0IsY0FBTSxFQUFFLFFBQVEsSUFBSTtBQUFBLFVBQ2xCLElBQUk7QUFBQSxVQUNKLEtBQUs7QUFBQSxZQUNILEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxZQUNGLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxLQUFLLEtBQUssbUJBQW1CO0FBQ3RDLGNBQU0sRUFBRSxRQUFRLElBQUk7QUFBQSxVQUNsQixJQUFJO0FBQUEsVUFDSixLQUFLLGVBQWUsQ0FBQztBQUFBLFFBQ3ZCO0FBQUEsTUFDRjtBQUNBLFVBQUksS0FBSyxNQUFNLElBQUk7QUFDbkIsWUFBTSxLQUFLLG1CQUFtQjtBQUFBLFFBQzVCLFFBQVEsS0FBSztBQUFBLFFBQ2I7QUFBQSxRQUNBLFFBQVEsS0FBSyxPQUFPO0FBQUEsUUFDcEIsYUFBYSxLQUFLLGtCQUFrQjtBQUFBLFFBQ3BDLEtBQUssS0FBSztBQUFBLFFBQ1YsTUFBTSxLQUFLO0FBQUEsUUFDWCxjQUFjLE9BQU87QUFBQSxNQUN2QixDQUFDO0FBQUEsSUFDSDtBQUNBLFVBQU0sa0JBQWtCLEdBQUc7QUFDM0IsVUFBTSxLQUFLLHlCQUF5QjtBQUFBLE1BQ2xDO0FBQUEsTUFDQSxNQUFNLE1BQU07QUFBQSxNQUNaLE9BQU8sTUFBTTtBQUFBLE1BQ2IsUUFBUSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQUEsTUFDbkUsYUFBYSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLGtCQUFrQixRQUFRLENBQUM7QUFBQSxNQUNuRixRQUFRLE9BQU87QUFBQSxJQUNqQixDQUFDO0FBQ0Q7QUFDRSxZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU8sS0FBSztBQUFBLFFBQ1osWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWUsS0FBSztBQUFBLFFBQ3BCLHdCQUF3QixLQUFLO0FBQUEsUUFDN0Isa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFFBQUksZUFBZSxhQUFhO0FBQzlCLFlBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsWUFBTSxTQUNKLElBQUksYUFBYSxTQUNiLGVBQ0EsSUFBSSxhQUFhLGVBQ2YsaUJBQ0EsSUFBSSxhQUFhLFlBQ2Ysa0JBQ0EsS0FBSztBQUNmLFlBQU0sY0FBYztBQUFBLFFBQ2xCO0FBQUEsUUFDQSxPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPLElBQUk7QUFBQSxRQUNYLGVBQWUsS0FBSztBQUFBLFFBQ3BCLHdCQUF3QixLQUFLO0FBQUEsUUFDN0Isa0JBQ0UsSUFBSSxhQUFhLGVBQWUsSUFBSSxtQkFBbUIsS0FBSztBQUFBLE1BQ2hFLENBQUM7QUFDRCxZQUFNLE1BQU8sZ0JBQWdCO0FBQUEsUUFDM0I7QUFBQSxRQUNBLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3JELE1BQU0sTUFBTTtBQUFBLFFBQ1osT0FBTyxNQUFNO0FBQUEsUUFDYixVQUFVLElBQUk7QUFBQSxRQUNkLFFBQVEsSUFBSTtBQUFBLFFBQ1osU0FBUyxJQUFJO0FBQUEsUUFDYixrQkFBa0IsSUFBSTtBQUFBLE1BQ3hCLENBQUM7QUFBQSxJQUNILE9BQU87QUFDTCxZQUFNLE1BQU8sZ0JBQWdCO0FBQUEsUUFDM0I7QUFBQSxRQUNBLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3JELE1BQU0sTUFBTTtBQUFBLFFBQ1osT0FBTyxNQUFNO0FBQUEsUUFDYixHQUFHLGNBQWMsR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFFRixVQUFFO0FBQ0EsVUFBTSxlQUFlO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsZUFDUCxRQUNBLEtBQ0EsUUFDQSxtQkFDVztBQUNYLFFBQU0sS0FBSyxXQUFXLElBQUksVUFBVTtBQUNwQyxRQUFNLE1BQU0sSUFBSSxXQUFXLE1BQU0sR0FBRyxFQUFFO0FBQ3RDLFFBQU0sV0FBVyxXQUFXLElBQUksTUFBTTtBQUN0QyxRQUFNLFVBQVUsT0FBTyxNQUFNLElBQUksRUFBRSxJQUFJLFFBQVE7QUFDL0MsUUFBTSxXQUFXLFFBQVEsTUFBTSxJQUFJLEVBQUUsSUFBSSxRQUFRO0FBQ2pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsU0FBUztBQUFBLE1BQ1AsZ0JBQWdCO0FBQUEsTUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxNQUNwQixnQkFBZ0I7QUFBQSxNQUNoQixhQUFhLElBQUk7QUFBQSxNQUNqQixVQUFVLElBQUksZUFBZSxLQUFLLEdBQUc7QUFBQSxNQUNyQyxZQUFZLFVBQVU7QUFBQSxNQUN0QixZQUFZLElBQUk7QUFBQSxNQUNoQjtBQUFBLE1BQ0Esb0JBQW9CO0FBQUEsSUFDdEI7QUFBQSxJQUNBLE1BQU07QUFBQSxNQUNKLGdCQUFnQjtBQUFBLE1BQ2hCLGdCQUFnQixJQUFJO0FBQUEsTUFDcEIsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYSxJQUFJO0FBQUEsTUFDakIsb0JBQW9CLElBQUk7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsd0JBQXdCLE9BQTRCO0FBQzNELE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdEIsVUFBTSxPQUFPLE1BQU0sQ0FBQztBQUNwQixVQUFNQyxvQkFBbUIsS0FBSyxrQkFBa0I7QUFDaEQsVUFBTUMsVUFBU0Qsb0JBQW1CLElBQUksS0FBS0EsaUJBQWdCLGlCQUFpQjtBQUM1RSxXQUFPLFlBQVksS0FBSyxNQUFNLElBQUksS0FBSyxHQUFHLElBQUksS0FBSyxPQUFPLE1BQU0sU0FBUyxLQUFLLE9BQU8sV0FBVyxJQUFJLEtBQUssR0FBRyxHQUFHQyxPQUFNLFNBQVMsS0FBSyxRQUFRO0FBQUEsRUFDN0k7QUFDQSxRQUFNLE9BQU8sQ0FBQyxHQUFHLElBQUksSUFBSSxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLO0FBQzlELFFBQU0sV0FBVyxLQUFLLFdBQVcsSUFBSSxLQUFLLENBQUMsSUFBSyxHQUFHLEtBQUssQ0FBQyxDQUFDLEtBQUssS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDO0FBQ3BGLFFBQU0sYUFBYSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQzlFLFFBQU0sbUJBQW1CLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssa0JBQWtCLFFBQVEsQ0FBQztBQUMvRixRQUFNLFNBQVMsbUJBQW1CLElBQUksS0FBSyxnQkFBZ0IsaUJBQWlCO0FBQzVFLFNBQU8sa0JBQWtCLE1BQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxlQUFlLElBQUksS0FBSyxHQUFHLEdBQUcsTUFBTSxLQUFLLFFBQVE7QUFDckg7QUFFQSxlQUFlLCtCQUErQixNQUFrQztBQUM5RSxRQUFNLFVBQVUsTUFBTSxhQUFhLEtBQUssTUFBTTtBQUM5QyxNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLE1BQUksUUFBUSxXQUFXLEtBQUssSUFBSSxPQUFRLFFBQU8sT0FBTyxLQUFLLFFBQVEsWUFBWSxFQUFFO0FBRWpGLFFBQU0sWUFBWSxJQUFJO0FBQUEsSUFDcEIsS0FBSyxPQUFPLElBQUksQ0FBQyxNQUFNO0FBQUEsTUFDckIsRUFBRTtBQUFBLE1BQ0YsY0FBYyxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRSxZQUFZO0FBQUEsSUFDM0YsQ0FBQztBQUFBLEVBQ0g7QUFDQSxhQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdEMsY0FBVSxJQUFJLEVBQUUsVUFBVSxlQUFlLENBQUMsQ0FBQztBQUFBLEVBQzdDO0FBQ0EsUUFBTSxrQkFBa0QsQ0FBQztBQUN6RCxhQUFXLENBQUMsU0FBUyxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ25FLFVBQU0sZUFBZSxVQUFVLElBQUksT0FBTztBQUMxQyxVQUFNLGFBQWE7QUFBQSxNQUNqQixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsSUFDUjtBQUNBLFFBQUksQ0FBQyxnQkFBZ0IsaUJBQWlCLFlBQVk7QUFDaEQsc0JBQWdCLE9BQU8sSUFBSSxFQUFFLEdBQUcsTUFBTTtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sdUJBQXlELENBQUM7QUFDaEUsYUFBVyxDQUFDLFNBQVMsV0FBVyxLQUFLLE9BQU8sUUFBUSxRQUFRLHFCQUFxQixDQUFDLENBQUMsR0FBRztBQUNwRixVQUFNLGVBQWUsVUFBVSxJQUFJLE9BQU87QUFDMUMsVUFBTSxhQUFhLGVBQWUsV0FBVztBQUM3QyxRQUFJLENBQUMsZ0JBQWdCLGlCQUFpQixZQUFZO0FBQ2hELDJCQUFxQixPQUFPLElBQUksRUFBRSxHQUFHLFlBQVk7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNLGVBQWUsb0JBQUksSUFBSTtBQUFBLElBQzNCLEdBQUcsT0FBTyxLQUFLLGVBQWU7QUFBQSxJQUM5QixHQUFHLE9BQU8sS0FBSyxvQkFBb0I7QUFBQSxFQUNyQyxDQUFDO0FBQ0QsUUFBTSxpQkFBaUIsYUFBYTtBQUNwQyxNQUFJLG1CQUFtQixHQUFHO0FBQ3hCLFVBQU0sZUFBZSxLQUFLLE1BQU07QUFDaEMsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNLFlBQVksU0FBUztBQUMzQixhQUFXLFNBQVMsT0FBTyxPQUFPLGVBQWUsR0FBRztBQUNsRCxVQUFNLGlCQUFpQjtBQUFBLEVBQ3pCO0FBQ0EsUUFBTSxhQUFhLEtBQUssUUFBUTtBQUFBLElBQzlCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVksUUFBUTtBQUFBLElBQ3BCLGNBQWM7QUFBQSxJQUNkLG1CQUFtQjtBQUFBLElBQ25CLG9CQUFvQixRQUFRLG1CQUFtQixPQUFPLENBQUMsT0FBTyxhQUFhLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDcEYsQ0FBQztBQUNELFFBQU0sS0FBSyxvQ0FBb0M7QUFBQSxJQUM3QyxRQUFRLEtBQUs7QUFBQSxJQUNiLGVBQWUsS0FBSztBQUFBLElBQ3BCLFVBQVUsV0FBVyxTQUFTO0FBQUEsSUFDOUIsV0FBVztBQUFBLEVBQ2IsQ0FBQztBQUNELFNBQU87QUFDVDtBQUlBLGVBQWUsV0FBVyxRQUErQjtBQU12RCxRQUFNLFlBQVksaUJBQWlCLE1BQU07QUFDekMsUUFBTSxLQUFLLHlCQUF5QixFQUFFLFFBQVEsS0FBSyxlQUFlLENBQUM7QUFDbkUsTUFBSSxDQUFFLE1BQU0sYUFBYSxNQUFNLEdBQUk7QUFDakMsVUFBTSxPQUFNLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ25DLFVBQU0sYUFBYSxRQUFRO0FBQUEsTUFDekIsUUFBUSxTQUFTO0FBQUEsTUFDakIsZ0JBQWdCO0FBQUEsTUFDaEIsWUFBWTtBQUFBLE1BQ1osaUJBQWlCO0FBQUEsTUFDakIsY0FBYyxDQUFDO0FBQUEsTUFDZixtQkFBbUIsQ0FBQztBQUFBLE1BQ3BCLG9CQUFvQixDQUFDO0FBQUEsTUFDckIsZ0JBQWdCLENBQUM7QUFBQSxNQUNqQixZQUFZO0FBQUEsSUFDZCxDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFdBQVcsUUFBUSxLQUFLLENBQUM7QUFDNUQ7QUFFQSxlQUFlLGFBQTRCO0FBQ3pDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxLQUFLLHlCQUF5QixFQUFFLE9BQU8sU0FBUyxPQUFPLENBQUM7QUFDOUQsYUFBVyxLQUFLLFVBQVU7QUFDeEIsVUFBTSxXQUFXLEVBQUUsTUFBTTtBQUFBLEVBQzNCO0FBQ0Y7QUFXQSxlQUFlLGtCQUFpQztBQUM5QyxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUFBLEVBQ3ZFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFDOUU7QUFBQSxFQUNGO0FBQ0EsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixNQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxZQUFZLENBQUMsSUFBSSxLQUFLO0FBQ2xELFVBQU0sS0FBSyxrQ0FBa0M7QUFDN0M7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLGdDQUFnQyxLQUFLLElBQUksR0FBRyxHQUFHO0FBQ2xELFVBQU0sS0FBSywrREFBK0Q7QUFBQSxNQUN4RSxLQUFLLFdBQVcsSUFBSSxHQUFHO0FBQUEsSUFDekIsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUd0RSxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUEsTUFDdEIsT0FBTztBQUFBLElBQ1QsQ0FBQztBQUNELFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyx1Q0FBdUMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUN0RTtBQUdBLE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTztBQUFBLE1BQ1AsTUFBTSxNQUFNO0FBQ1YsY0FBTSxJQUFJLE9BQU87QUFDakIsZUFBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUM7QUFDcEQsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLEdBQUc7QUFDM0UsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFBQSxNQUM5RTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ3pFO0FBQ0Y7QUFhQSxJQUFNLGtCQUFrQjtBQUV4QixlQUFlLGtCQUEwQztBQUN2RCxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGVBQWU7QUFDOUQsUUFBTSxLQUFLLE9BQU8sZUFBZTtBQUNqQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLGdCQUFnQixJQUFrQztBQUMvRCxNQUFJLE9BQU8sTUFBTTtBQUNmLFVBQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxlQUFlO0FBQUEsRUFDcEQsT0FBTztBQUNMLFVBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZUFBZSxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQzNEO0FBQ0Y7QUFFQSxlQUFlLG1CQUFrQztBQUMvQyxRQUFNLFFBQVEsTUFBTSxrQkFBa0I7QUFDdEMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUsseUJBQXlCO0FBQ3BDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxrQkFBa0I7QUFBQSxJQUN0QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELHVCQUFxQixPQUFPO0FBQzVCLE9BQUssWUFBWTtBQUNqQixRQUFNLEtBQUssd0JBQXdCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQzNFLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksd0JBQStEO0FBRW5FLFNBQVMscUJBQXFCLFNBQXVCO0FBQ25ELE1BQUksMEJBQTBCLEtBQU0sZUFBYyxxQkFBcUI7QUFDdkUsMEJBQXdCLFlBQVksTUFBTTtBQUN4QyxTQUFLLFlBQVksRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNoQyxXQUFLLEtBQUssdUJBQXVCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDckQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHNCQUE0QjtBQUNuQyxNQUFJLDBCQUEwQixNQUFNO0FBQ2xDLGtCQUFjLHFCQUFxQjtBQUNuQyw0QkFBd0I7QUFBQSxFQUMxQjtBQUNGO0FBRUEsZUFBZSxvQkFBbUM7QUFDaEQsc0JBQW9CO0FBQ3BCLFFBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxRQUFNLFFBQVEsTUFBTSxnQkFBZ0I7QUFDcEMsUUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixRQUFNLE9BQU8sTUFBTSxrQkFBa0I7QUFDckMsUUFBTSxrQkFBa0IsSUFBSTtBQUM1QixRQUFNLEtBQUssMEJBQTBCO0FBQUEsSUFDbkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxjQUE2QjtBQUMxQyxNQUFJLE9BQU8sTUFBTSxrQkFBa0I7QUFDbkMsTUFBSSxTQUFTLE1BQU07QUFFakIsd0JBQW9CO0FBQ3BCO0FBQUEsRUFDRjtBQUlBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUVBLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFFRCxVQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsZUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsVUFBSSxJQUFJLFNBQVMsS0FBSyxTQUFTLE9BQU8sR0FBRztBQUN2QyxjQUFNLGVBQWUsUUFBUSxLQUFLLFNBQVMsT0FBTztBQUNsRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLGtCQUFrQixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNLFNBQVMsTUFBTSxrQkFBa0I7QUFDdkMsTUFBSSxDQUFDLFFBQVE7QUFDWCx3QkFBb0I7QUFDcEIsVUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyx5QkFBeUIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ2pFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLE1BQU0saUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUNuRSxNQUFJLFFBQVEsTUFBTSxnQkFBZ0I7QUFDbEMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLGdCQUFnQixJQUFJLEVBQUU7QUFBQSxJQUM5RCxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxXQUFRLE1BQU0sa0JBQWtCLEtBQU07QUFDdEMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyxnQkFBZ0I7QUFBQSxNQUN6QixRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLFdBQVcsTUFBTSxrQkFBa0I7QUFBQSxNQUNuQyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyw0Q0FBNEM7QUFBQSxNQUNyRCxRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sZUFBZSxPQUFPLFFBQVEsT0FBTyxPQUFPO0FBQ2xELFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBV0EsSUFBTSxzQkFBc0I7QUFFNUIsZUFBZSxxQkFBNkM7QUFDMUQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxtQkFBbUI7QUFDbEUsUUFBTSxLQUFLLE9BQU8sbUJBQW1CO0FBQ3JDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsbUJBQW1CLElBQWtDO0FBQ2xFLE1BQUksT0FBTyxLQUFNLE9BQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxtQkFBbUI7QUFBQSxNQUNsRSxPQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUNwRTtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELFFBQU0sUUFBUSxNQUFNLHFCQUFxQjtBQUN6QyxNQUFJLFVBQVUsR0FBRztBQUNmLFVBQU0sS0FBSyw2QkFBNkI7QUFDeEM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFVBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsSUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxFQUFFLHFCQUFxQixDQUFDO0FBQUEsRUFDbkU7QUFDQSxRQUFNLHFCQUFxQjtBQUFBLElBQ3pCLGNBQWM7QUFBQSxJQUNkLFdBQVc7QUFBQSxJQUNYLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsMEJBQXdCLE9BQU87QUFDL0IsT0FBSyxlQUFlO0FBQ3BCLFFBQU0sS0FBSyw0QkFBNEIsRUFBRSxRQUFRLE9BQU8sY0FBYyxRQUFRLENBQUM7QUFDL0UsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsSUFBSSwyQkFBa0U7QUFFdEUsU0FBUyx3QkFBd0IsU0FBdUI7QUFDdEQsTUFBSSw2QkFBNkIsS0FBTSxlQUFjLHdCQUF3QjtBQUM3RSw2QkFBMkIsWUFBWSxNQUFNO0FBQzNDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLFNBQVMseUJBQStCO0FBQ3RDLE1BQUksNkJBQTZCLE1BQU07QUFDckMsa0JBQWMsd0JBQXdCO0FBQ3RDLCtCQUEyQjtBQUFBLEVBQzdCO0FBQ0Y7QUFFQSxlQUFlLHVCQUFzQztBQUNuRCx5QkFBdUI7QUFDdkIsUUFBTSxRQUFRLE9BQU8sTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3ZDLFFBQU0sbUJBQW1CLElBQUk7QUFDN0IsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0scUJBQXFCLElBQUk7QUFDL0IsUUFBTSxLQUFLLDhCQUE4QjtBQUFBLElBQ3ZDLFNBQVMsVUFBVTtBQUFBLElBQ25CLFdBQVcsTUFBTSxhQUFhO0FBQUEsRUFDaEMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsaUJBQWdDO0FBQzdDLE1BQUksT0FBTyxNQUFNLHFCQUFxQjtBQUN0QyxNQUFJLFNBQVMsTUFBTTtBQUNqQiwyQkFBdUI7QUFDdkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLGFBQWEsTUFBTTtBQUMxQixVQUFNLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUyxXQUFXO0FBQ2pFLFFBQUksVUFBVSxnQkFBZ0I7QUFDNUI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxLQUFLLG9EQUFvRDtBQUFBLE1BQzdELFVBQVUsS0FBSyxTQUFTO0FBQUEsTUFDeEIsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUNELFVBQU0sa0JBQWtCLEtBQUssU0FBUyxPQUFPO0FBQzdDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBRUEsUUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsMkJBQXVCO0FBQ3ZCLFVBQU0sbUJBQW1CLElBQUk7QUFDN0IsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLEtBQUssNkJBQTZCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNyRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBR0EsTUFBSSxNQUFNLFlBQVksT0FBTyxPQUFPLEdBQUc7QUFDckMsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBTUEsTUFBSSxPQUFPLFdBQVcsWUFBWTtBQUNoQyxVQUFNLEtBQUssbUVBQW1FO0FBQUEsTUFDNUUsVUFBVSxPQUFPO0FBQUEsSUFDbkIsQ0FBQztBQUNELFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sTUFBTSxpQkFBaUIsT0FBTyxNQUFNLFdBQVcsT0FBTyxPQUFPO0FBQ25FLE1BQUksUUFBUSxNQUFNLG1CQUFtQjtBQUNyQyxNQUFJLFVBQVUsTUFBTTtBQUNsQixRQUFJO0FBQ0YsWUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDOUIsUUFBUTtBQUNOLGNBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixRQUFJLFVBQVUsTUFBTTtBQUNsQixZQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDNUQsVUFBSSxPQUFPLElBQUksT0FBTyxTQUFVLE9BQU0sbUJBQW1CLElBQUksRUFBRTtBQUFBLElBQ2pFLE9BQU87QUFDTCxZQUFNLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUNBLFdBQVEsTUFBTSxxQkFBcUIsS0FBTTtBQUN6QyxTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVMsT0FBTztBQUFBLE1BQ2hCLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUN0QztBQUNBLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLG9CQUFvQjtBQUFBLE1BQzdCLFVBQVUsT0FBTztBQUFBLE1BQ2pCLGFBQWEsT0FBTyxXQUFXLGFBQWEsT0FBTyxPQUFPO0FBQUEsTUFDMUQsV0FBVyxNQUFNLHFCQUFxQjtBQUFBLE1BQ3RDLFdBQVcsS0FBSztBQUFBLE1BQ2hCLGdCQUFnQixLQUFLO0FBQUEsSUFDdkIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGdEQUFnRDtBQUFBLE1BQ3pELFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUlBLGVBQWUsV0FDYixRQUNBLFVBQ0EsS0FDQSxLQUNBLEtBQ2U7QUFDZixRQUFNLE1BQU8sd0JBQXdCLEVBQUUsUUFBUSxVQUFVLEtBQUssR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQ3JGLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLFVBQTZCO0FBQUEsSUFDakMsZ0JBQWdCO0FBQUEsSUFDaEI7QUFBQSxJQUNBO0FBQUEsSUFDQSxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDcEMsWUFBWTtBQUFBLElBQ1osT0FBTyxjQUFjLEdBQUc7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssV0FBVyxRQUFRLFdBQVc7QUFDekMsUUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxDQUFDO0FBQy9DLFFBQU0sT0FBTyxtQkFBbUIsRUFBRSxJQUFJLElBQUk7QUFDMUMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ25CO0FBQUEsTUFDQSxlQUFlRixVQUFTLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUMvRCxTQUFTLGVBQWUsTUFBTSxJQUFJLFFBQVE7QUFBQSxJQUM1QyxDQUFDO0FBQUEsRUFDSCxTQUFTLE1BQU07QUFDYixVQUFNLE1BQU8sNEJBQTRCLEVBQUUsR0FBRyxjQUFjLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDckU7QUFDRjtBQUVBLGVBQWUsS0FBSyxHQUE0QjtBQUM5QyxRQUFNLE1BQU0sSUFBSSxZQUFZLEVBQUUsT0FBTyxDQUFDO0FBQ3RDLFFBQU0sU0FBUyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsR0FBRztBQUN4RCxRQUFNLE1BQU0sTUFBTSxLQUFLLElBQUksV0FBVyxNQUFNLENBQUMsRUFDMUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRTtBQUNWLFNBQU8sSUFBSSxNQUFNLEdBQUcsQ0FBQztBQUN2QjtBQUlBLGVBQWUsaUJBQWlCLE9BQStCO0FBQzdELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsTUFBTTtBQUN0RCxVQUFNLGNBQWM7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUixPQUFPO0FBQUEsTUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZTtBQUFBLE1BQ2Ysd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLE1BQUksQ0FBQyxPQUFPO0FBSVYsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBS0EsUUFBSSxLQUFLLFdBQVc7QUFDbEIsWUFBTSxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVM7QUFDbEQsVUFBSSxNQUFNLDhCQUErQjtBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxJQUFJLE1BQU0sT0FBTyxpQkFBaUI7QUFJeEMsUUFBSSxXQUFXO0FBQ2YsUUFBSSxTQUFTLFVBQVUsU0FBUyxXQUFXLEVBQUUsZ0JBQWdCO0FBQzNELGlCQUFXLE1BQU0sT0FBTyxhQUFhLFNBQVMsTUFBTTtBQUFBLElBQ3REO0FBQ0EsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTyxFQUFFO0FBQUEsTUFDVCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZSxFQUFFO0FBQUEsTUFDakIsd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sS0FBSyx1QkFBdUI7QUFBQSxNQUNoQyxPQUFPLEVBQUU7QUFBQSxNQUNULE1BQU0sRUFBRTtBQUFBLE1BQ1IsZ0JBQWdCLEVBQUU7QUFBQSxNQUNsQixtQkFBbUIsU0FBUztBQUFBLE1BQzVCLDBCQUEwQjtBQUFBLElBQzVCLENBQUM7QUFDRCxRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sS0FBSyw4Q0FBOEM7QUFBQSxRQUN2RCxZQUFZLFNBQVM7QUFBQSxRQUNyQixnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLEtBQUssd0NBQXdDLEVBQUU7QUFBQSxNQUNqRCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFNLGVBQWUsY0FBYyxJQUFJLFdBQVc7QUFDeEQsVUFBTSxTQUNKLFFBQVEsU0FDSixlQUNBLFFBQVEsZUFDTixpQkFDQSxRQUFRLFlBQ04sa0JBQ0E7QUFDVixVQUFNLFVBQ0osZUFBZSxlQUFlLFFBQVEsZUFBZSxJQUFJLG1CQUFtQjtBQUM5RSxVQUFNLGNBQWM7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU8sY0FBYyxHQUFHLEVBQUU7QUFBQSxNQUMxQixlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxLQUFLLDJCQUEyQjtBQUFBLE1BQ3BDLFVBQVU7QUFBQSxNQUNWLGtCQUFrQjtBQUFBLE1BQ2xCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLG9CQUFvQixPQUErQjtBQUNoRSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLEtBQUs7QUFDakIsVUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsT0FBTztBQUlWLFVBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBSUEsVUFBTSxnQkFBZ0IsTUFBTSx1QkFBdUI7QUFDbkQsUUFBSSxlQUFlO0FBQ2pCLFlBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sYUFBYTtBQUNqRCxVQUFJLE9BQU8sU0FBUyxHQUFHLEtBQUssTUFBTSw4QkFBK0I7QUFBQSxJQUNuRTtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxNQUFNLE9BQU8sYUFBYSxzQkFBc0I7QUFDN0QsUUFBSSxDQUFDLE1BQU07QUFDVCxVQUFJLE1BQU8sT0FBTSxLQUFLLGlEQUFpRDtBQUN2RSxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFTLGtCQUFrQixJQUFJO0FBQ3JDLFFBQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsWUFBTSxLQUFLLDhDQUE4QztBQUN6RCxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxZQUFZLE1BQU07QUFDeEIsVUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRCxRQUFJLE1BQU8sT0FBTSxLQUFLLDJCQUEyQixFQUFFLE9BQU8sT0FBTyxPQUFPLENBQUM7QUFBQSxFQUMzRSxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaURBQWlELGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDaEY7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFJQSxlQUFlLGlCQUFnQztBQUM3QyxRQUFNLFFBQVEsTUFBTSxXQUFXO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsTUFBTSxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFO0FBRUEsZUFBZSxhQUFzQztBQUNuRCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksV0FBVztBQUNmLE1BQUk7QUFDRixVQUFNLE9BQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUMzRixlQUFXLEtBQUs7QUFBQSxFQUNsQixRQUFRO0FBQUEsRUFHUjtBQUNBLFFBQU0sZ0JBQWdCLE1BQU0sa0JBQWtCO0FBQzlDLFFBQU0sbUJBQW1CLE1BQU0scUJBQXFCO0FBQ3BELFFBQU0sY0FBYyxNQUFNLGtCQUFrQjtBQUM1QyxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVCxVQUFVLGVBQWUsUUFBUTtBQUFBLElBQ2pDLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWTtBQUFBLE1BQ1YsUUFBUSxtQkFBbUIsUUFBUSxvQkFBb0I7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsYUFBYSxnQkFBZ0IsZUFBZTtBQUFBLE1BQzVDLGVBQWUsZ0JBQWdCLGlCQUFpQjtBQUFBLE1BQ2hELGVBQWUsZ0JBQWdCLGlCQUFpQjtBQUFBLElBQ2xEO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixPQUFPO0FBQUEsTUFDUCxTQUFTLDBCQUEwQjtBQUFBLE1BQ25DLFdBQVcsYUFBYSxhQUFhO0FBQUEsTUFDckMsZ0JBQWdCLGFBQWEsZ0JBQWdCO0FBQUEsSUFDL0M7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLE1BQ2YsT0FBTztBQUFBLE1BQ1AsU0FBUyw2QkFBNkI7QUFBQSxNQUN0QyxXQUFXLGdCQUFnQixhQUFhO0FBQUEsTUFDeEMsZ0JBQWdCLGdCQUFnQixnQkFBZ0I7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUF5QztBQUMvRCxTQUFPO0FBQUEsSUFDTCxPQUFPLEVBQUU7QUFBQSxJQUNULE1BQU0sRUFBRTtBQUFBLElBQ1IsUUFBUSxFQUFFO0FBQUEsSUFDVixTQUFTLEVBQUU7QUFBQSxJQUNYLGFBQWEsRUFBRTtBQUFBLElBQ2YsY0FBYyxFQUFFO0FBQUEsSUFDaEIsdUJBQXVCLEVBQUU7QUFBQSxJQUN6QixRQUFRLEVBQUUsSUFBSSxTQUFTO0FBQUEsSUFDdkIsV0FBVyxFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSTtBQUFBLEVBQ25EO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsS0FBcUI7QUFFdkMsUUFBTSxJQUFJLElBQUksS0FBSyxHQUFHO0FBQ3RCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTyxJQUFJLFFBQVEsU0FBUyxFQUFFO0FBQzdELFFBQU0sTUFBTSxDQUFDLEdBQVcsSUFBSSxNQUFNLE9BQU8sQ0FBQyxFQUFFLFNBQVMsR0FBRyxHQUFHO0FBQzNELFNBQ0UsR0FBRyxFQUFFLGVBQWUsQ0FBQyxJQUFJLElBQUksRUFBRSxZQUFZLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQ3BFLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQztBQUU5RTtBQUVBLFNBQVMsVUFBVSxHQUFxQjtBQUN0QyxTQUFPLFdBQVcsRUFBRSxLQUFLLGNBQWMsRUFBRSxJQUFJO0FBQy9DO0FBU0EsU0FBUyxlQUFlLE1BQXlCO0FBQy9DLFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUcsT0FBTTtBQUNaLFVBQUksT0FBT0EsS0FBSSxlQUFlLFNBQVUsTUFBSyxJQUFJQSxLQUFJLFVBQVU7QUFDL0QsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLFNBQU8sQ0FBQyxHQUFHLElBQUksRUFBRSxLQUFLO0FBQ3hCO0FBT0EsU0FBUyxvQkFBb0IsTUFBZSxVQUFtQztBQUM3RSxRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1BLE9BQU07QUFDWixVQUFJQSxLQUFJLGVBQWUsVUFBVTtBQUMvQixlQUFPLE9BQU8sS0FBS0EsSUFBRyxFQUFFLEtBQUs7QUFBQSxNQUMvQjtBQUNBLGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFRQSxTQUFTLGlCQUFpQixNQUFlLFVBQWtCLE1BQXlCO0FBQ2xGLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixNQUFJLFFBQXdDO0FBQzVDLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNQSxPQUFNO0FBQ1osVUFBSUEsS0FBSSxlQUFlLFVBQVU7QUFDL0IsZ0JBQVFBO0FBQ1I7QUFBQSxNQUNGO0FBQ0EsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxNQUFPLFFBQU87QUFDbkIsTUFBSSxNQUFlO0FBQ25CLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVLFFBQU8sSUFBSSxRQUFRLE9BQU8sU0FBUyxPQUFPLEdBQUc7QUFDMUYsVUFBTyxJQUFnQyxHQUFHO0FBQUEsRUFDNUM7QUFDQSxNQUFJLFFBQVEsT0FBVyxRQUFPO0FBQzlCLE1BQUksUUFBUSxLQUFNLFFBQU87QUFDekIsTUFBSSxPQUFPLFFBQVEsU0FBVSxRQUFPLElBQUksT0FBTyxHQUFHO0FBQ2xELE1BQUksTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLGNBQWMsSUFBSSxNQUFNO0FBQ3ZELFNBQU8sT0FBTyxLQUFLLEdBQThCLEVBQUUsS0FBSztBQUMxRDtBQUVBLFNBQVMsV0FBVyxHQUFtQjtBQUdyQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksSUFBSSxDQUFDO0FBQ3hCLFVBQU0sT0FBTyxPQUFPLFlBQVksT0FBTyxTQUFTLFlBQU87QUFDdkQsV0FBTyxPQUFPLFNBQVMsV0FBVyxPQUFPLFNBQVMsZ0JBQzlDLE9BQ0EsR0FBRyxPQUFPLElBQUksR0FBRyxJQUFJO0FBQUEsRUFDM0IsUUFBUTtBQUNOLFdBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUFBLEVBQ2hEO0FBQ0Y7QUFLQyxXQUF1QyxlQUFlO0FBQUEsRUFDckQ7QUFBQSxFQUNBLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFNBQVM7QUFBQSxFQUNULFVBQVUsTUFBTSxTQUFTLFVBQVU7QUFBQSxFQUNuQyxPQUFPO0FBQUEsRUFDUCxjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxlQUFlO0FBQUEsRUFDZixpQkFBaUI7QUFBQSxFQUNqQixpQkFBaUI7QUFBQSxFQUNqQixrQkFBa0I7QUFDcEI7IiwKICAibmFtZXMiOiBbInRvQmFzZTY0IiwgIm9iaiIsICJpbmZvIiwgInRvQmFzZTY0IiwgInVuYXZhaWxhYmxlQ291bnQiLCAic3VmZml4IiwgIm9iaiJdCn0K
