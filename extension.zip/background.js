// extension/src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// extension/src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// extension/src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  refetchSession: null,
  mediaCrawlSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// extension/src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// extension/src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// extension/src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, partial_ids };
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  return { tweet_id: restId, hint_handle: pickHintHandle(node) };
}
function pickHintHandle(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name);
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted) {
  if (targeted.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.retweeted_tweet_id && targetedTweetIds.has(t.retweeted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// extension/src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// extension/src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// extension/src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let expandedCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        // Cast: the @types/firefox-webext-browser type signature insists
        // `func` returns void, but the API actually surfaces the return
        // value via `result[0].result`. We use that for the expand count.
        func: () => {
          const SHOW_MORE_SELECTORS = [
            '[data-testid="tweet-text-show-more-link"]',
            'button[data-testid="tweet-text-show-more-link"]',
            'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
          ];
          const clicked = /* @__PURE__ */ new Set();
          let expanded = 0;
          for (const sel of SHOW_MORE_SELECTORS) {
            for (const el of Array.from(document.querySelectorAll(sel))) {
              if (clicked.has(el)) continue;
              const t = (el.textContent || "").trim().toLowerCase();
              if (t !== "show more" && t !== "show this thread") continue;
              const rect = el.getBoundingClientRect();
              if (rect.width === 0 || rect.height === 0) continue;
              clicked.add(el);
              try {
                el.click();
                expanded += 1;
              } catch {
              }
            }
          }
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { expanded };
        }
      });
      scrollCount += 1;
      const r = results[0]?.result;
      if (r && typeof r.expanded === "number") expandedCount += r.expanded;
    } catch {
    }
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      sess.expandedCount += expandedCount;
      await setAutoScrollSession(sess);
    }
  }
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async () => {
    try {
      await browser.sidebarAction.toggle();
    } catch (err) {
      await warn("sidebar toggle failed; opening options", describeError(err));
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, _sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(msg.endpoint, msg.url, msg.response);
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, response) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set()
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.tweets.length === 0) return;
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const committedIdx = await getCommittedIndex();
  let dedupedSkipped = 0;
  const liveTweets = [];
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      continue;
    }
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (liveTweets.length === 0) return;
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, Object.keys(buf.tweets_by_id).length);
    if (added > 0) {
      await info("captured tweets", {
        handle,
        endpoint,
        added,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    if (tweets.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("flush deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      idx[item.handle] = inner;
      await info("flush committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("flush batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("flush failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return Object.keys(current.tweets_by_id).length;
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingCount = Object.keys(remainingTweets).length;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => id in remainingTweets)
  });
  await info("flush kept newer buffered tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = target.bucket === "_unknown" ? `https://x.com/i/status/${target.tweetId}` : `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const autoScrollSess = await getAutoScrollSession();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    }
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHBhdDogJycsXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXG4gIHJlcG86ICd4JyxcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxuICBicmFuY2g6ICdtYXN0ZXInLFxuICBlbmFibGVkOiB0cnVlLFxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcbiAgY29uZmlndXJlZEF0OiBudWxsLFxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXG59O1xuXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xuXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cbiAqXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXG4gKiBHaXRIdWIgUEFUIGluIHBsYWludGV4dC4gQSBkZXRlcm1pbmVkIGF0dGFja2VyIHdpdGggdGhlIGV4dGVuc2lvbidzIHNvdXJjZVxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxuICogc3RyaW5nIHNpdHRpbmcgbmV4dCB0byBpdHMga2V5IG5hbWUgaW4gZXh0ZW5zaW9uIHN0b3JhZ2UuXG4gKlxuICogU2NoZW1lOlxuICogICAtIE9uIGZpcnN0IGVuY3J5cHRpb24gd2UgZ2VuZXJhdGUgYSAzMi1ieXRlIHNhbHQgYW5kIHBlcnNpc3QgaXQgaW5cbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cbiAqICAgICB8fCBcImltbS1hcmNoaXZlLXBhdC12MVwiYC4gVGhlIHNhbHQgYmVpbmcgcGVyLWluc3RhbGwgbWVhbnMgdHdvIGNvcGllc1xuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxuICogICAtIFBsYWludGV4dCBpcyBlbmNyeXB0ZWQgd2l0aCBhIGZyZXNoIDEyLWJ5dGUgSVYuIFRoZSBlbnZlbG9wZSBmb3JtYXQgaXNcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXG4gKlxuICogQmFja3dhcmRzIGNvbXBhdGliaWxpdHk6IGFuIHVucHJlZml4ZWQgdmFsdWUgaXMgdHJlYXRlZCBhcyBsZWdhY3lcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cbiAqL1xuXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xuXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcbiAgbGV0IHMgPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIGJ1ZikgcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShzKTtcbn1cblxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcbiAgY29uc3QgYmluID0gYXRvYihzKTtcbiAgY29uc3Qgb3V0ID0gbmV3IFVpbnQ4QXJyYXkoYmluLmxlbmd0aCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChTQUxUX1NUT1JBR0VfS0VZKTtcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4geyBzYWx0QjY0OiB2LCBzYWx0OiBmcm9tQmFzZTY0KHYpIH07XG4gIH1cbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcbiAgY29uc3Qgc2FsdEI2NCA9IHRvQmFzZTY0KHNhbHQpO1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICBjb25zdCB7IHNhbHRCNjQsIHNhbHQgfSA9IGF3YWl0IGxvYWRPckNyZWF0ZVNhbHQoKTtcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcbiAgfVxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXG4gICk7XG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcbiAgY29tYmluZWQuc2V0KHNhbHQsIHNlZWQubGVuZ3RoKTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcbiAgICAnZW5jcnlwdCcsXG4gICAgJ2RlY3J5cHQnLFxuICBdKTtcbiAgZGVyaXZlZEtleUNhY2hlID0ga2V5O1xuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcbiAgcmV0dXJuIGtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdi5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbmNyeXB0UGF0KHBsYWludGV4dDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gIGNvbnN0IGl2ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMikpO1xuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcbiAgICBrZXksXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcbiAgKTtcbiAgcmV0dXJuIGAke0VOVkVMT1BFX1BSRUZJWH0ke3RvQmFzZTY0KGl2KX06JHt0b0Jhc2U2NChuZXcgVWludDhBcnJheShjdCkpfWA7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWNyeXB0UGF0KGVudmVsb3BlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXG4gIC8vIHJlLWVuY3J5cHRzIGl0IHZpYSB0aGUgc3RvcmFnZSBsYXllci5cbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xuICBpZiAocGFydHMubGVuZ3RoICE9PSAyKSByZXR1cm4gJyc7XG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XG4gIHRyeSB7XG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcbiAgICBjb25zdCBjdCA9IGZyb21CYXNlNjQoY3RCNjQpO1xuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcbiAgICAgIGtleSxcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShwdCk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnJztcbiAgfVxufVxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB7IGRlY3J5cHRQYXQsIGVuY3J5cHRQYXQsIGlzRW5jcnlwdGVkUGF0IH0gZnJvbSAnLi9jcnlwdG8uanMnO1xuaW1wb3J0IHR5cGUge1xuICBBY2NvdW50Q29uZmlnLFxuICBBY2NvdW50Q291bnRlcixcbiAgQ2Fub25pY2FsVHdlZXQsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFNldHRpbmdzLFxufSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBCdWZmZXJlZCB0d2VldHMgZm9yIGEgZ2l2ZW4gYWNjb3VudCwgYXdhaXRpbmcgY29tbWl0LiBBIFwicnVuXCIgaXMgb25lIGVudHJ5XG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xuICBydW5faWQ6IHN0cmluZztcbiAgYWNjb3VudF9oYW5kbGU6IHN0cmluZztcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcbiAgdHdlZXRzX2J5X2lkOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD47XG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XG4gIGVuZHBvaW50c19zZWVuOiBzdHJpbmdbXTtcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcbn1cblxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxuICogVXNlZCB0byBza2lwIHJlLWNhcHR1cmluZyB0d2VldHMgd2UndmUgYWxyZWFkeSBwdXNoZWQgd2l0aCBpZGVudGljYWxcbiAqIGVuZ2FnZW1lbnQgY291bnRzIFx1MjAxNCBhdm9pZHMgZ2VuZXJhdGluZyBvbmUgbmV3IHJhdy8qIGZpbGUgZXZlcnkgYnJvd3NlLiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XG4gIHRzOiBzdHJpbmc7IC8vIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3QgY29tbWl0XG4gIHNpZzogc3RyaW5nOyAvLyBlbmdhZ2VtZW50IHNpZ25hdHVyZTogXCJsaWtlfHJ0fHJlcGx5fHF1b3RlXCJcbn1cblxuLyoqIFByb2dyZXNzICsgaW5mbGlnaHQgdHJhY2tpbmcgZm9yIGEgcXVldWUtZHJpdmVuIGxvb3AgKHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCkuXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcbiAqIFwiWCBvZiBZIHByb2Nlc3NlZFwiIFx1MjAxNCBhbmQgdGhlIHdhaXQtZm9yLWluZ2VzdCBndWFyZCBrbm93cyB3aGF0IHRvIGV4cGVjdC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XG4gIC8qKiBJbml0aWFsIHF1ZXVlIHNpemUgd2hlbiB0aGUgdXNlciBjbGlja2VkIFwiU3RhcnRcIi4gKi9cbiAgdG90YWxBdFN0YXJ0OiBudW1iZXI7XG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cbiAgcHJvY2Vzc2VkOiBudW1iZXI7XG4gIC8qKiBJU08gb2Ygd2hlbiB0aGlzIHNlc3Npb24gc3RhcnRlZC4gKi9cbiAgc3RhcnRlZEF0OiBzdHJpbmc7XG4gIC8qKiBUd2VldCBjdXJyZW50bHkgaW5mbGlnaHQgXHUyMDE0IHdlIG5hdmlnYXRlZCB0byBpdCBhbmQgYXJlIHdhaXRpbmcgZm9yIHRoZVxuICAgKiBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgcmVzcG9uc2UgYmVmb3JlIGFkdmFuY2luZy4gbnVsbCBiZXR3ZWVuIHRpY2tzXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xuICBpbmZsaWdodDogeyB0d2VldElkOiBzdHJpbmc7IG5hdmlnYXRlZEF0OiBzdHJpbmcgfSB8IG51bGw7XG59XG5cbi8qKiBBdXRvLXNjcm9sbCBzZXNzaW9uOiBjb3VudHMgb2YgdGlja3MgYW5kIHR3ZWV0cyBpbmdlc3RlZCBzaW5jZSB0aGUgdXNlclxuICogY2xpY2tlZCBTdGFydC4gUGVyc2lzdGVkIHNvIFNXIGV2aWN0aW9uIGR1cmluZyBhIHJ1biBrZWVwcyBwcm9ncmVzcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xuICBzdGFydGVkQXQ6IHN0cmluZztcbiAgc2Nyb2xsQ291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xuICBleHBhbmRlZENvdW50OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xuICBzZXR0aW5nczogU2V0dGluZ3M7XG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XG4gIC8qKiBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IHN1Y2Nlc3NmdWwgYWNjb3VudHMueWFtbCBmZXRjaCBmcm9tIHRoZSByZXBvLlxuICAgKiBVc2VkIGJ5IGByZWZyZXNoQWNjb3VudHNMaXN0YCB0byBza2lwIHJlLWZldGNoaW5nIG9uIGV2ZXJ5IFNXIHdha2UgXHUyMDE0IHRoZVxuICAgKiBmaWxlIGNoYW5nZXMgcmFyZWx5IGFuZCBhbiBhdXRoZW50aWNhdGVkIHJhdyBmZXRjaCBldmVyeSB3YWtlIGFkZHMgdXAuICovXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IHN0cmluZyB8IG51bGw7XG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcbiAgcnVuQnVmZmVyczogUmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPjtcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XG4gIGNvbW1pdHRlZEluZGV4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+O1xuICAvKiogVHdlZXRzIHRoZSBub3JtYWxpemVyIGZsYWdnZWQgYXMgdHJ1bmNhdGVkIGFuZCB0aGF0IHdlIGhhdmVuJ3Qgc2VlbiBhXG4gICAqIGZ1bGwtdGV4dCB2ZXJzaW9uIG9mIHlldC4gS2V5ZWQgYnkgaGFuZGxlIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuICovXG4gIHJlZmV0Y2hRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogVHdlZXQgSURzIHNlZW4gdmlhIE1lZGlhLXRhYiAvIHBhcnRpYWwgY2FwdHVyZXMgdGhhdCBjb3VsZG4ndCBiZVxuICAgKiBub3JtYWxpemVkIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gS2V5ZWQgYnkgaGludC1oYW5kbGUgKG9yXG4gICAqIFwiX3Vua25vd25cIikgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gVGhlIHVzZXIgY2FuIGRyaXZlIGEgY3Jhd2wgdGhhdFxuICAgKiBvcGVucyBlYWNoIGRldGFpbCBwYWdlIHRvIGNhcHR1cmUgdGhlIHJlYWwgdGhpbmcuICovXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBtZWRpYUNyYXdsU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBhdXRvU2Nyb2xsU2Vzc2lvbjogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsO1xufVxuXG5jb25zdCBERUZBVUxUX0NPTk5FQ1RJT046IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgc3RhdHVzOiAndW5rbm93bicsXG4gIGxvZ2luOiBudWxsLFxuICBjaGVja2VkQXQ6IG51bGwsXG4gIGVycm9yOiBudWxsLFxuICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxufTtcblxuY29uc3QgREVGQVVMVFM6IFN0b3JhZ2VTaGFwZSA9IHtcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9LFxuICBhY2NvdW50czogWy4uLkZBTExCQUNLX0FDQ09VTlRTXSxcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogbnVsbCxcbiAgY29ubmVjdGlvbjogeyAuLi5ERUZBVUxUX0NPTk5FQ1RJT04gfSxcbiAgY291bnRlcnM6IHt9LFxuICBydW5CdWZmZXJzOiB7fSxcbiAgYWN0aXZpdHk6IFtdLFxuICBjb21taXR0ZWRJbmRleDoge30sXG4gIHJlZmV0Y2hRdWV1ZToge30sXG4gIG1lZGlhQ3Jhd2xRdWV1ZToge30sXG4gIHJlZmV0Y2hTZXNzaW9uOiBudWxsLFxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcbiAgYXV0b1Njcm9sbFNlc3Npb246IG51bGwsXG59O1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChrZXkpO1xuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUoREVGQVVMVFNba2V5XSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW2tleV06IHZhbHVlIH0pO1xufVxuXG4vLyAtLS0gU2V0dGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICAvLyBCYWNrZmlsbCBhbnkga2V5cyB0aGUgdXNlcidzIHN0b3JlZCBzZXR0aW5ncyBwcmVkYXRlIFx1MjAxNCByZWFkZXJzIGNhbiByZWx5XG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XG4gIC8vIGV2ZXJ5IGNhbGxzaXRlLiBUaGUgUEFUIGlzIHN0b3JlZCBlbmNyeXB0ZWQtYXQtcmVzdCBhcyBvZiB2MC4yLjA7IHdlXG4gIC8vIGRlY3J5cHQgdHJhbnNwYXJlbnRseSBzbyBjYWxsZXJzIGNvbnRpbnVlIHRvIHNlZSBwbGFpbnRleHQuXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcbiAgY29uc3QgbWVyZ2VkID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi5zdG9yZWQgfTtcbiAgaWYgKG1lcmdlZC5wYXQgJiYgaXNFbmNyeXB0ZWRQYXQobWVyZ2VkLnBhdCkpIHtcbiAgICB0cnkge1xuICAgICAgbWVyZ2VkLnBhdCA9IGF3YWl0IGRlY3J5cHRQYXQobWVyZ2VkLnBhdCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBtZXJnZWQucGF0ID0gJyc7XG4gICAgfVxuICB9XG4gIHJldHVybiBtZXJnZWQ7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXG4gIC8vIG9uIHRoZSBuZXh0IHNhdmUuXG4gIGNvbnN0IHRvV3JpdGU6IFNldHRpbmdzID0geyAuLi5zIH07XG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XG4gICAgdG9Xcml0ZS5wYXQgPSBhd2FpdCBlbmNyeXB0UGF0KHRvV3JpdGUucGF0KTtcbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2V0dGluZ3MocGF0Y2g6IFBhcnRpYWw8U2V0dGluZ3M+KTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBuZXh0ID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGF3YWl0IHNldFNldHRpbmdzKG5leHQpO1xuICByZXR1cm4gbmV4dDtcbn1cblxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzKCk6IFByb21pc2U8QWNjb3VudENvbmZpZ1tdPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHMoYTogQWNjb3VudENvbmZpZ1tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50c1JlZnJlc2hlZEF0KCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHNSZWZyZXNoZWRBdChpc286IHN0cmluZyB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcbn1cblxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29ubmVjdGlvbigpOiBQcm9taXNlPENvbm5lY3Rpb25TdGF0ZT4ge1xuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XG4gIC8vIEJhY2tmaWxsIGZpZWxkcyBhZGRlZCBhZnRlciB0aGUgdXNlcidzIHN0b3JhZ2Ugd2FzIHdyaXR0ZW4uXG4gIGNvbnN0IG91dDogQ29ubmVjdGlvblN0YXRlID0ge1xuICAgIC4uLmMsXG4gICAgZGVmYXVsdEJyYW5jaDogYy5kZWZhdWx0QnJhbmNoID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5kZWZhdWx0QnJhbmNoLFxuICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6XG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgcmF0ZUxpbWl0UmVzZXRBdDogYy5yYXRlTGltaXRSZXNldEF0ID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5yYXRlTGltaXRSZXNldEF0LFxuICB9O1xuICByZXR1cm4gb3V0O1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xufVxuXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ2NvdW50ZXJzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xuICAgIHRvZGF5Q291bnQ6IDAsXG4gICAgdG9kYXlEYXRlOiB0b2RheUlTTygpLFxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXG4gICAgYnVmZmVyZWRDb3VudDogMCxcbiAgfTtcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcbiAgICBjdXIudG9kYXlEYXRlID0gdG9kYXlJU08oKTtcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XG4gIH1cbiAgY29uc3QgbmV4dDogQWNjb3VudENvdW50ZXIgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRCdWZmZXJlZENvdW50KGhhbmRsZTogc3RyaW5nLCBjb3VudDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcbn1cblxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj4+IHtcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgcmV0dXJuIGFsbFtoYW5kbGVdID8/IG51bGw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcsIGJ1ZjogUnVuQnVmZmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYWxsW2hhbmRsZV0gPSBidWY7XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcbn1cblxuLy8gLS0tIEFjdGl2aXR5IHRhaWwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY3Rpdml0eScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwZW5kQWN0aXZpdHkoZXY6IExvZ0V2ZW50KTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XG4gIGN1ci51bnNoaWZ0KGV2KTtcbiAgaWYgKGN1ci5sZW5ndGggPiBBQ1RJVklUWV9UQUlMX01BWCkgY3VyLmxlbmd0aCA9IEFDVElWSVRZX1RBSUxfTUFYO1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcbiAgcmV0dXJuIGN1cjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBbXSk7XG59XG5cbi8vIC0tLSBDb21taXR0ZWQtdHdlZXRzIGRlZHVwIGluZGV4IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb21taXR0ZWRJbmRleCcpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29tbWl0dGVkSW5kZXgoXG4gIGlkeDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PlxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29tbWl0dGVkSW5kZXgnLCBpZHgpO1xufVxuXG4vKiogQ29tcHV0ZSB0aGUgZW5nYWdlbWVudCBzaWduYXR1cmUgd2UgdXNlIHRvIGRlY2lkZSB3aGV0aGVyIGEgcmUtY2FwdHVyZWRcbiAqIHR3ZWV0IGlzIFwibWF0ZXJpYWxseSBkaWZmZXJlbnRcIiBmcm9tIHdoYXQgd2UgbGFzdCBjb21taXR0ZWQuIFdlIG9taXRcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXG4gKiBkZWZlYXQgdGhlIGRlZHVwLiBMaWtlcyAvIFJUcyAvIHJlcGxpZXMgLyBxdW90ZXMgY2hhbmdlIHJhcmVseSBlbm91Z2ggdGhhdFxuICogZWFjaCBjaGFuZ2UgaXMgd29ydGggYSByZS1jb21taXQgKGFuZCBhbiBlbmdhZ2VtZW50X2hpc3Rvcnkgc25hcHNob3QpLlxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxuICogdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkgYnlwYXNzZXMgdGhlIGRlZHVwIGV2ZW4gd2hlbiBlbmdhZ2VtZW50IGNvdW50c1xuICogaGF2ZW4ndCBtb3ZlZCBcdTIwMTQgb3RoZXJ3aXNlIHRoZSBuZXcgYm9keSB3b3VsZCBiZSBzaWxlbnRseSBkcm9wcGVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXG4gIGxpa2VzOiBudW1iZXIsXG4gIHJldHdlZXRzOiBudW1iZXIsXG4gIHJlcGxpZXM6IG51bWJlcixcbiAgcXVvdGVzOiBudW1iZXIsXG4gIGlzVHJ1bmNhdGVkOiBib29sZWFuID0gZmFsc2Vcbik6IHN0cmluZyB7XG4gIHJldHVybiBgJHtsaWtlc318JHtyZXR3ZWV0c318JHtyZXBsaWVzfXwke3F1b3Rlc318JHtpc1RydW5jYXRlZCA/ICd0JyA6ICdmJ31gO1xufVxuXG4vKiogRHJvcCBlbnRyaWVzIG9sZGVyIHRoYW4gYG1heEFnZU1zYC4gUmV0dXJucyB0aGUgbnVtYmVyIHBydW5lZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcnVuZUNvbW1pdHRlZEluZGV4KG1heEFnZU1zOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBjb25zdCBjdXRvZmYgPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gbWF4QWdlTXMpLnRvSVNPU3RyaW5nKCk7XG4gIGxldCBwcnVuZWQgPSAwO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgY29uc3QgaW5uZXIgPSBpZHhbaGFuZGxlXTtcbiAgICBpZiAoIWlubmVyKSBjb250aW51ZTtcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcbiAgICAgIGNvbnN0IGUgPSBpbm5lclt0aWRdO1xuICAgICAgaWYgKGUgJiYgZS50cyA8IGN1dG9mZikge1xuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcbiAgICAgICAgcHJ1bmVkICs9IDE7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhpbm5lcikubGVuZ3RoID09PSAwKSBkZWxldGUgaWR4W2hhbmRsZV07XG4gIH1cbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG4gIHJldHVybiBwcnVuZWQ7XG59XG5cbi8vIC0tLSBSZWZldGNoIHF1ZXVlICh0d2VldHMgbmVlZGluZyBmdWxsLXRleHQgcmVjYXB0dXJlKSAtLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hRdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbaGFuZGxlXSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdO1xuICBpZiAoIWlkcykgcmV0dXJuO1xuICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2hhbmRsZV07XG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0UmVmZXRjaFRhcmdldCgpOiBQcm9taXNlPHtcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIHR3ZWV0SWQ6IHN0cmluZztcbn0gfCBudWxsPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBoYW5kbGUsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVNZWRpYUNyYXdsKGhpbnRIYW5kbGU6IHN0cmluZyB8IG51bGwsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcbiAgY29uc3QgaWRzID0gcVtidWNrZXRdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbYnVja2V0XSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcbiAgICBpZiAoIWlkcykgY29udGludWU7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XG4gICAgfVxuICB9XG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTogUHJvbWlzZTx7XG4gIGJ1Y2tldDogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgYnVja2V0LCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXG4gKiBlbnF1ZXVlaW5nIG1lZGlhLWNyYXdsIHRhcmdldHMgd2UndmUgYWxyZWFkeSBhcmNoaXZlZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpc0NvbW1pdHRlZCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgZm9yIChjb25zdCBpbm5lciBvZiBPYmplY3QudmFsdWVzKGlkeCkpIHtcbiAgICBpZiAoaW5uZXIgJiYgdHdlZXRJZCBpbiBpbm5lcikgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyAtLS0gTG9vcCBzZXNzaW9uIHN0YXRlIChwcm9ncmVzcyArIGluZmxpZ2h0IGdhdGluZykgLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEF1dG9TY3JvbGxTZXNzaW9uKCk6IFByb21pc2U8QXV0b1Njcm9sbFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXV0b1Njcm9sbFNlc3Npb24oczogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nLCBzKTtcbn1cblxuLy8gLS0tIFB1cmdlOiB1bnJlbGF0ZWQgYnVmZmVycywgY291bnRlcnMsIHF1ZXVlIGVudHJpZXMgLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vKipcbiAqIERyb3AgZXZlcnkgcGVyLWhhbmRsZSBiaXQgb2Ygc3RhdGUgKGNvdW50ZXJzLCBydW4gYnVmZmVyLCBjb21taXR0ZWQtaW5kZXhcbiAqIGVudHJpZXMsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyaWVzKSB0aGF0IGRvZXNuJ3QgY29ycmVzcG9uZCB0byBhXG4gKiB0cmFja2VkIGFjY291bnQuIFJldHVybnMgYSBzdW1tYXJ5IGRlc2NyaWJpbmcgd2hhdCB3YXMgY2xlYXJlZCBzbyB0aGVcbiAqIGNhbGxlciBjYW4gbG9nIGl0LlxuICpcbiAqIFRyYWNrZWQgYWNjb3VudHMgYXJlIHBhc3NlZCBpbiAoY2FsbGVyIHJlc29sdmVzIGZyb20gdGhlIGxpdmUgY29uZmlnKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1cmdlVW5yZWxhdGVkU3RhdGUodGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4pOiBQcm9taXNlPHtcbiAgY291bnRlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGJ1ZmZlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XG4gIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xuICBtZWRpYUNyYXdsSWRzUmVtb3ZlZDogbnVtYmVyO1xufT4ge1xuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcbiAgY29uc3QgaXNUYXJnZXRlZCA9IChoOiBzdHJpbmcpOiBib29sZWFuID0+IHRhcmdMb3dlci5oYXMoaC50b0xvd2VyQ2FzZSgpKTtcblxuICAvLyBDb3VudGVyc1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCBjb3VudGVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgY291bnRlcnNbaF07XG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcblxuICAvLyBSdW4gYnVmZmVyc1xuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBsZXQgYnVmZmVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoYnVmZmVycykpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBidWZmZXJzW2hdO1xuICAgICAgYnVmZmVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYnVmZmVycyk7XG5cbiAgLy8gQ29tbWl0dGVkIGRlZHVwIGluZGV4XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgaWR4W2hdO1xuICAgICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcblxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXG4gIGNvbnN0IHJxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGxldCByZWZldGNoSGFuZGxlc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgcnFbaF07XG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XG5cbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IGJ1Y2tldHMgYXJlIGhpbnQtaGFuZGxlcyAob3IgXCJfdW5rbm93blwiKS4gRHJvcFxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCBcdTIwMTQgaW5jbHVkaW5nIFwiX3Vua25vd25cIiBzaW5jZSB3ZVxuICAvLyBjYW4ndCB2ZXJpZnkgcmVsYXRpb24uXG4gIGNvbnN0IG1xID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhtcSkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xuICAgICAgZGVsZXRlIG1xW2hdO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIG1xKTtcblxuICByZXR1cm4ge1xuICAgIGNvdW50ZXJzUmVtb3ZlZCxcbiAgICBidWZmZXJzUmVtb3ZlZCxcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcbiAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQsXG4gICAgbWVkaWFDcmF3bElkc1JlbW92ZWQsXG4gIH07XG59XG5cbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbn1cbiIsICJpbXBvcnQgeyBhcHBlbmRBY3Rpdml0eSB9IGZyb20gJy4vc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5sZXQgYnJvYWRjYXN0OiAoKGV2OiBMb2dFdmVudCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldEJyb2FkY2FzdGVyKGZuOiAoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKTogdm9pZCB7XG4gIGJyb2FkY2FzdCA9IGZuO1xufVxuXG5mdW5jdGlvbiBub3dJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBldjogTG9nRXZlbnQgPSB7IHRzOiBub3dJU08oKSwgbGV2ZWwsIG1zZywgY29udGV4dDogcmVkYWN0KGNvbnRleHQpIH07XG4gIC8vIENvbnNvbGUgZm9yIGRldnRvb2xzLlxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xuICBpZiAobGV2ZWwgPT09ICdlcnJvcicpIGNvbnNvbGUuZXJyb3IobGluZSwgZXYuY29udGV4dCk7XG4gIGVsc2UgaWYgKGxldmVsID09PSAnd2FybicpIGNvbnNvbGUud2FybihsaW5lLCBldi5jb250ZXh0KTtcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcbiAgLy8gUGVyc2lzdGVudCB0YWlsLlxuICB0cnkge1xuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGZhaWxlZCB0byBhcHBlbmQgYWN0aXZpdHknLCBlcnIpO1xuICB9XG4gIC8vIExpdmUgYnJvYWRjYXN0IChlLmcuIHRvIHNpZGViYXIpLlxuICB0cnkge1xuICAgIGJyb2FkY2FzdD8uKGV2KTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gU2lkZWJhciBtYXkgbm90IGJlIG9wZW47IHRoYXQncyBmaW5lLlxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCdpbmZvJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCd3YXJuJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gZW1pdCgnZXJyb3InLCBtc2csIGNvbnRleHQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmVFcnJvcihlcnI6IHVua25vd24pOiB7IG1lc3NhZ2U6IHN0cmluZzsgc3RhY2s6IHN0cmluZyB8IG51bGwgfSB7XG4gIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcbiAgfVxuICB0cnkge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4geyBtZXNzYWdlOiAnPHVucHJpbnRhYmxlIGVycm9yPicsIHN0YWNrOiBudWxsIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTdHJpcCBhbnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSBQQVQgb3Igb3RoZXIgbG9uZyBzZWNyZXQgZnJvbSBhIGNvbnRleHRcbiAqIG9iamVjdCBiZWZvcmUgcGVyc2lzdGluZyBpdC4gRGVmZW5zaXZlOiBjYWxsZXJzIHNob3VsZCBub3QgbG9nIHRva2VucywgYnV0XG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxuICovXG5mdW5jdGlvbiByZWRhY3QoY3R4OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhjdHgpKSB7XG4gICAgaWYgKGsudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygndG9rZW4nKSB8fCBrLnRvTG93ZXJDYXNlKCkgPT09ICdwYXQnIHx8IGsgPT09ICdhdXRob3JpemF0aW9uJykge1xuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIC9naXRodWJfcGF0X1tBLVphLXowLTlfXXszMCx9Ly50ZXN0KHYpKSB7XG4gICAgICBvdXRba10gPSB2LnJlcGxhY2UoL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dKy9nLCAnZ2l0aHViX3BhdF88cmVkYWN0ZWQ+Jyk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XG4gICAgICBvdXRba10gPSBgJHt2LnNsaWNlKDAsIDQwOTYpfVx1MjAyNjx0cnVuY2F0ZWQ+YDtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0W2tdID0gdjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cbiIsICJpbXBvcnQgeyBkZXNjcmliZUVycm9yIH0gZnJvbSAnLi9sb2dnZXIuanMnO1xuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5jb25zdCBBUElfQkFTRSA9ICdodHRwczovL2FwaS5naXRodWIuY29tJztcbmNvbnN0IFJBV19CQVNFID0gJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZU9wdGlvbnMge1xuICBwYXRoOiBzdHJpbmc7XG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBleHBlY3RlZFNoYT86IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZVJlc3VsdCB7XG4gIHBhdGg6IHN0cmluZztcbiAgc2hhOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVPcHRpb25zIHtcbiAgcGF0aDogc3RyaW5nO1xuICBjb250ZW50QmFzZTY0OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZXNPcHRpb25zIHtcbiAgZmlsZXM6IENvbW1pdEZpbGVPcHRpb25zW107XG4gIG1lc3NhZ2U6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlc1Jlc3VsdCB7XG4gIGNvbW1pdFNoYTogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbiAgZmlsZXM6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgY2xhc3MgR2l0SHViRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIHN0YXR1czogbnVtYmVyO1xuICBib2R5OiB1bmtub3duO1xuICByZXRyaWFibGU6IGJvb2xlYW47XG4gIGNhdGVnb3J5OiAnYXV0aCcgfCAncmF0ZS1saW1pdCcgfCAnY29uZmxpY3QnIHwgJ25vdC1mb3VuZCcgfCAnc2VydmVyJyB8ICduZXR3b3JrJyB8ICd1bmtub3duJztcbiAgLyoqIFdoZW4gdGhlIEdpdEh1YiByYXRlLWxpbWl0IHdpbmRvdyBmb3IgdGhpcyB0b2tlbiByZXNldHMsIGFzIGEgVW5peFxuICAgKiBlcG9jaCBpbiBzZWNvbmRzLiBQb3B1bGF0ZWQgZnJvbSBgWC1SYXRlTGltaXQtUmVzZXRgIG9uIDQwMy80MjksIG9yXG4gICAqIGRlcml2ZWQgZnJvbSBgUmV0cnktQWZ0ZXJgIGZvciBzZWNvbmRhcnkgbGltaXRzLiBudWxsIHdoZW4gdW5rbm93bi4gKi9cbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVtYmVyIHwgbnVsbDtcblxuICBjb25zdHJ1Y3RvcihvcHRzOiB7XG4gICAgc3RhdHVzOiBudW1iZXI7XG4gICAgYm9keTogdW5rbm93bjtcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgcmV0cmlhYmxlOiBib29sZWFuO1xuICAgIGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXTtcbiAgICByYXRlTGltaXRSZXNldEF0PzogbnVtYmVyIHwgbnVsbDtcbiAgfSkge1xuICAgIHN1cGVyKG9wdHMubWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0dpdEh1YkVycm9yJztcbiAgICB0aGlzLnN0YXR1cyA9IG9wdHMuc3RhdHVzO1xuICAgIHRoaXMuYm9keSA9IG9wdHMuYm9keTtcbiAgICB0aGlzLnJldHJpYWJsZSA9IG9wdHMucmV0cmlhYmxlO1xuICAgIHRoaXMuY2F0ZWdvcnkgPSBvcHRzLmNhdGVnb3J5O1xuICAgIHRoaXMucmF0ZUxpbWl0UmVzZXRBdCA9IG9wdHMucmF0ZUxpbWl0UmVzZXRBdCA/PyBudWxsO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBHaXRIdWJDbGllbnQge1xuICBwcml2YXRlIHJlYWRvbmx5IHNldHRpbmdzOiBTZXR0aW5ncztcblxuICBjb25zdHJ1Y3RvcihzZXR0aW5nczogU2V0dGluZ3MpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gIH1cblxuICAvKiogUmV0dXJucyB0aGUgYXV0aGVudGljYXRlZCB1c2VyJ3MgbG9naW4uIFRocm93cyBvbiBhdXRoIGZhaWx1cmUuICovXG4gIGFzeW5jIHdob2FtaSgpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICByZXR1cm4gKHJlcyBhcyB7IGxvZ2luPzogc3RyaW5nIH0pLmxvZ2luID8/ICc8dW5rbm93bj4nO1xuICB9XG5cbiAgLyoqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZ2l2ZW4gYnJhbmNoIGV4aXN0cyBvbiB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xuICBhc3luYyBicmFuY2hFeGlzdHMoYnJhbmNoOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICdHRVQnLFxuICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2JyYW5jaGVzLyR7ZW5jb2RlVVJJQ29tcG9uZW50KGJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBmYWxzZTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKiogVmVyaWZpZXMgdGhlIFBBVCBjYW4gc2VlIHRoZSBjb25maWd1cmVkIHJlcG8uICovXG4gIGFzeW5jIHZlcmlmeVJlcG9BY2Nlc3MoKTogUHJvbWlzZTx7IGxvZ2luOiBzdHJpbmc7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH0+IHtcbiAgICBjb25zdCBtZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICBjb25zdCByZXBvID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb31gKTtcbiAgICBjb25zdCByID0gcmVwbyBhcyB7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGxvZ2luOiAobWUgYXMgeyBsb2dpbjogc3RyaW5nIH0pLmxvZ2luLFxuICAgICAgZnVsbF9uYW1lOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRmV0Y2ggYSB0ZXh0IGZpbGUgZnJvbSByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tIGF1dGhlbnRpY2F0ZWQgd2l0aCB0aGVcbiAgICogUEFULiBSZXR1cm5zIG51bGwgaWYgdGhlIGZpbGUgZG9lc24ndCBleGlzdC4gVXNlZCBmb3IgY29uZmlnL2FjY291bnRzLnlhbWwuXG4gICAqL1xuICBhc3luYyBmZXRjaFJhd1RleHQocGF0aEluUmVwbzogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgdXJsID0gYCR7UkFXX0JBU0V9LyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99LyR7dGhpcy5zZXR0aW5ncy5icmFuY2h9LyR7cGF0aEluUmVwb31gO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAgfSxcbiAgICB9KTtcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSByZXR1cm4gbnVsbDtcbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3IocmVzLCBgR0VUIHJhdyAke3BhdGhJblJlcG99YCk7XG4gICAgcmV0dXJuIHJlcy50ZXh0KCk7XG4gIH1cblxuICAvKipcbiAgICogTG9vayB1cCBhbiBleGlzdGluZyBmaWxlJ3MgU0hBIHZpYSB0aGUgQ29udGVudHMgQVBJLCBvciBudWxsIGlmIG5vdCBmb3VuZC5cbiAgICogVXNlZCB3aGVuIHJldHJ5aW5nIGEgUFVUIGFmdGVyIGEgNDIyIHNoYSBtaXNtYXRjaC5cbiAgICovXG4gIGFzeW5jIGdldEZpbGVTaGEocGF0aDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9P3JlZj0ke2VuY29kZVVSSUNvbXBvbmVudCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHIgPSByZXMgYXMgeyBzaGE/OiBzdHJpbmcgfTtcbiAgICAgIHJldHVybiByLnNoYSA/PyBudWxsO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBudWxsO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBQVVQgYSBmaWxlIHRvIHRoZSByZXBvLiBIYW5kbGVzIDQyMiAoc2hhIHJlcXVpcmVkKSBieSByZS1mZXRjaGluZyB0aGVcbiAgICogZXhpc3Rpbmcgc2hhIGFuZCByZXRyeWluZyBvbmNlLiBSZXRyaWVzIG5ldHdvcmsgLyA1eHggLyByYXRlLWxpbWl0IGVycm9yc1xuICAgKiB3aXRoIGV4cG9uZW50aWFsIGJhY2tvZmYgdXAgdG8gbWF4QXR0ZW1wdHMuXG4gICAqL1xuICBhc3luYyBwdXRGaWxlKG9wdHM6IFB1dEZpbGVPcHRpb25zKTogUHJvbWlzZTxQdXRGaWxlUmVzdWx0PiB7XG4gICAgY29uc3QgcGF0aCA9IG9wdHMucGF0aDtcbiAgICBjb25zdCB1cmwgPSBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2NvbnRlbnRzLyR7ZW5jb2RlUGF0aChwYXRoKX1gO1xuICAgIGxldCBzaGE6IHN0cmluZyB8IG51bGwgPSBvcHRzLmV4cGVjdGVkU2hhID8/IG51bGw7XG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xuXG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDE7IGF0dGVtcHQgPD0gbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xuICAgICAgY29uc3QgYm9keTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICAgIG1lc3NhZ2U6IG9wdHMubWVzc2FnZSxcbiAgICAgICAgY29udGVudDogb3B0cy5jb250ZW50QmFzZTY0LFxuICAgICAgICBicmFuY2g6IHRoaXMuc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgfTtcbiAgICAgIGlmIChzaGEpIGJvZHkuc2hhID0gc2hhO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ1BVVCcsIHVybCwgYm9keSk7XG4gICAgICAgIGNvbnN0IG91dCA9IHJlcyBhcyB7IGNvbnRlbnQ6IHsgc2hhOiBzdHJpbmc7IGh0bWxfdXJsOiBzdHJpbmc7IHBhdGg6IHN0cmluZyB9IH07XG4gICAgICAgIHJldHVybiB7IHBhdGg6IG91dC5jb250ZW50LnBhdGgsIHNoYTogb3V0LmNvbnRlbnQuc2hhLCB1cmw6IG91dC5jb250ZW50Lmh0bWxfdXJsIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XG4gICAgICAgIGlmIChlcnIuc3RhdHVzID09PSA0MjIgJiYgIXNoYSkge1xuICAgICAgICAgIC8vIEZpbGUgYWxyZWFkeSBleGlzdHM7IGZldGNoIGl0cyBzaGEgYW5kIHJldHJ5IG9uY2UuXG4gICAgICAgICAgc2hhID0gYXdhaXQgdGhpcy5nZXRGaWxlU2hhKHBhdGgpO1xuICAgICAgICAgIGlmICghc2hhKSB0aHJvdyBlcnI7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFlcnIucmV0cmlhYmxlIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGBwdXRGaWxlOiBleGhhdXN0ZWQgYXR0ZW1wdHMgZm9yICR7cGF0aH1gKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb21taXQgc2V2ZXJhbCBmaWxlcyB3aXRoIG9uZSBicmFuY2ggdXBkYXRlLiBUaGUgQ29udGVudHMgQVBJIGNyZWF0ZXMgb25lXG4gICAqIGNvbW1pdCBwZXIgUFVULCBzbyByYXBpZCBmbHVzaGVzIHJhY2UgZWFjaCBvdGhlciBvbiB0aGUgYnJhbmNoIGhlYWQuIFRoaXNcbiAgICogdXNlcyB0aGUgbG93ZXItbGV2ZWwgR2l0IERhdGEgQVBJIGluc3RlYWQ6IHVwbG9hZCBibG9icywgYnVpbGQgYSB0cmVlLFxuICAgKiBjcmVhdGUgb25lIGNvbW1pdCwgdGhlbiBtb3ZlIHRoZSBicmFuY2ggcmVmIG9uY2UuIElmIGFub3RoZXIgd3JpdGVyIG1vdmVzXG4gICAqIHRoZSBicmFuY2ggZmlyc3QsIHJlYmFzZSB0aGlzIHRyZWUgcGF0Y2ggb250byB0aGUgbGF0ZXN0IGhlYWQgYW5kIHJldHJ5LlxuICAgKi9cbiAgYXN5bmMgY29tbWl0RmlsZXMob3B0czogQ29tbWl0RmlsZXNPcHRpb25zKTogUHJvbWlzZTxDb21taXRGaWxlc1Jlc3VsdD4ge1xuICAgIGlmIChvcHRzLmZpbGVzLmxlbmd0aCA9PT0gMCkgdGhyb3cgbmV3IEVycm9yKCdjb21taXRGaWxlczogbm8gZmlsZXMgdG8gY29tbWl0Jyk7XG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xuICAgIGxldCBsYXN0RXJyOiB1bmtub3duID0gbnVsbDtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGJsb2JzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgICAgb3B0cy5maWxlcy5tYXAoYXN5bmMgKGZpbGUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG91dCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L2Jsb2JzYCxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGZpbGUuY29udGVudEJhc2U2NCxcbiAgICAgICAgICAgICAgICBlbmNvZGluZzogJ2Jhc2U2NCcsXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBwYXRoOiBmaWxlLnBhdGgsXG4gICAgICAgICAgICAgIHNoYTogKG91dCBhcyB7IHNoYTogc3RyaW5nIH0pLnNoYSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSlcbiAgICAgICAgKTtcblxuICAgICAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XG4gICAgICAgIGNvbnN0IHRyZWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvdHJlZXNgLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGJhc2VfdHJlZTogaGVhZC50cmVlU2hhLFxuICAgICAgICAgICAgdHJlZTogYmxvYnMubWFwKChibG9iKSA9PiAoe1xuICAgICAgICAgICAgICBwYXRoOiBibG9iLnBhdGgsXG4gICAgICAgICAgICAgIG1vZGU6ICcxMDA2NDQnLFxuICAgICAgICAgICAgICB0eXBlOiAnYmxvYicsXG4gICAgICAgICAgICAgIHNoYTogYmxvYi5zaGEsXG4gICAgICAgICAgICB9KSksXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICBjb25zdCB0cmVlU2hhID0gKHRyZWUgYXMgeyBzaGE6IHN0cmluZyB9KS5zaGE7XG4gICAgICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICdQT1NUJyxcbiAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9jb21taXRzYCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXG4gICAgICAgICAgICB0cmVlOiB0cmVlU2hhLFxuICAgICAgICAgICAgcGFyZW50czogW2hlYWQuc2hhXSxcbiAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGNvbW1pdE91dCA9IGNvbW1pdCBhcyB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nIH07XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICAgICAnUEFUQ0gnLFxuICAgICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNoYTogY29tbWl0T3V0LnNoYSxcbiAgICAgICAgICAgICAgZm9yY2U6IGZhbHNlLFxuICAgICAgICAgICAgfVxuICAgICAgICAgICk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGlmIChpc0NvbmZsaWN0KGVycikgJiYgYXR0ZW1wdCA8IG1heEF0dGVtcHRzKSB7XG4gICAgICAgICAgICBsYXN0RXJyID0gZXJyO1xuICAgICAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGNvbW1pdFNoYTogY29tbWl0T3V0LnNoYSxcbiAgICAgICAgICB1cmw6IGNvbW1pdE91dC5odG1sX3VybCxcbiAgICAgICAgICBmaWxlczogb3B0cy5maWxlcy5tYXAoKGZpbGUpID0+IGZpbGUucGF0aCksXG4gICAgICAgIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgbGFzdEVyciA9IGVycjtcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XG4gICAgICAgIGlmICgoIWVyci5yZXRyaWFibGUgJiYgIWlzQ29uZmxpY3QoZXJyKSkgfHwgYXR0ZW1wdCA9PT0gbWF4QXR0ZW1wdHMpIHRocm93IGVycjtcbiAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aHJvdyBsYXN0RXJyIGluc3RhbmNlb2YgRXJyb3IgPyBsYXN0RXJyIDogbmV3IEVycm9yKCdjb21taXRGaWxlczogZXhoYXVzdGVkIGF0dGVtcHRzJyk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGdldEJyYW5jaEhlYWQoKTogUHJvbWlzZTx7IHNoYTogc3RyaW5nOyB0cmVlU2hhOiBzdHJpbmcgfT4ge1xuICAgIGNvbnN0IHJlZiA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgJ0dFVCcsXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9yZWYvaGVhZHMvJHtlbmNvZGVQYXRoKHRoaXMuc2V0dGluZ3MuYnJhbmNoKX1gXG4gICAgKTtcbiAgICBjb25zdCBoZWFkU2hhID0gKHJlZiBhcyB7IG9iamVjdDogeyBzaGE6IHN0cmluZyB9IH0pLm9iamVjdC5zaGE7XG4gICAgY29uc3QgY29tbWl0ID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAnR0VUJyxcbiAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L2NvbW1pdHMvJHtoZWFkU2hhfWBcbiAgICApO1xuICAgIHJldHVybiB7XG4gICAgICBzaGE6IGhlYWRTaGEsXG4gICAgICB0cmVlU2hhOiAoY29tbWl0IGFzIHsgdHJlZTogeyBzaGE6IHN0cmluZyB9IH0pLnRyZWUuc2hhLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZldGNoSnNvbihtZXRob2Q6IHN0cmluZywgcGF0aDogc3RyaW5nLCBib2R5PzogdW5rbm93bik6IFByb21pc2U8dW5rbm93bj4ge1xuICAgIGNvbnN0IHVybCA9IHBhdGguc3RhcnRzV2l0aCgnaHR0cCcpID8gcGF0aCA6IGAke0FQSV9CQVNFfSR7cGF0aH1gO1xuICAgIGNvbnN0IGluaXQ6IFJlcXVlc3RJbml0ID0ge1xuICAgICAgbWV0aG9kLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dGhpcy5zZXR0aW5ncy5wYXR9YCxcbiAgICAgICAgQWNjZXB0OiAnYXBwbGljYXRpb24vdm5kLmdpdGh1Yitqc29uJyxcbiAgICAgICAgJ1gtR2l0SHViLUFwaS1WZXJzaW9uJzogJzIwMjItMTEtMjgnLFxuICAgICAgICAuLi4oYm9keSA/IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IDoge30pLFxuICAgICAgfSxcbiAgICAgIC4uLihib2R5ID8geyBib2R5OiBKU09OLnN0cmluZ2lmeShib2R5KSB9IDoge30pLFxuICAgIH07XG4gICAgbGV0IHJlczogUmVzcG9uc2U7XG4gICAgdHJ5IHtcbiAgICAgIHJlcyA9IGF3YWl0IGZldGNoKHVybCwgaW5pdCk7XG4gICAgfSBjYXRjaCAobmV0RXJyKSB7XG4gICAgICB0aHJvdyBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgICBzdGF0dXM6IDAsXG4gICAgICAgIGJvZHk6IG51bGwsXG4gICAgICAgIG1lc3NhZ2U6IGBuZXR3b3JrOiAke2Rlc2NyaWJlRXJyb3IobmV0RXJyKS5tZXNzYWdlfWAsXG4gICAgICAgIHJldHJpYWJsZTogdHJ1ZSxcbiAgICAgICAgY2F0ZWdvcnk6ICduZXR3b3JrJyxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gMjA0KSByZXR1cm4gbnVsbDtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICBpZiAodGV4dCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBwYXJzZWQgPSB0ZXh0O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBgJHttZXRob2R9ICR7cGF0aH1gKTtcbiAgICByZXR1cm4gcGFyc2VkO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBtYWtlRXJyb3IocmVzOiBSZXNwb25zZSwgbGFiZWw6IHN0cmluZyk6IFByb21pc2U8R2l0SHViRXJyb3I+IHtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICBpZiAodGV4dCkgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBsYWJlbCk7XG4gIH1cblxuICBwcml2YXRlIG1ha2VFcnJvckZyb21QYXJzZWQocmVzOiBSZXNwb25zZSwgYm9keTogdW5rbm93biwgbGFiZWw6IHN0cmluZyk6IEdpdEh1YkVycm9yIHtcbiAgICBjb25zdCBtc2cgPVxuICAgICAgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmIGJvZHkgJiYgJ21lc3NhZ2UnIGluIGJvZHlcbiAgICAgICAgPyBTdHJpbmcoKGJvZHkgYXMgeyBtZXNzYWdlOiB1bmtub3duIH0pLm1lc3NhZ2UpXG4gICAgICAgIDogcmVzLnN0YXR1c1RleHQ7XG4gICAgbGV0IGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXSA9ICd1bmtub3duJztcbiAgICBsZXQgcmV0cmlhYmxlID0gZmFsc2U7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSB8fCByZXMuc3RhdHVzID09PSA0MDMpIHtcbiAgICAgIC8vIDQwMyBjYW4gYmUgZWl0aGVyIGF1dGggb3IgcmF0ZSBsaW1pdDsgY2hlY2sgaGVhZGVycy5cbiAgICAgIGNvbnN0IHJhdGUgPSByZXMuaGVhZGVycy5nZXQoJ3gtcmF0ZWxpbWl0LXJlbWFpbmluZycpO1xuICAgICAgaWYgKHJhdGUgPT09ICcwJyB8fCAvcmF0ZSBsaW1pdC9pLnRlc3QobXNnKSkge1xuICAgICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNhdGVnb3J5ID0gJ2F1dGgnO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSB7XG4gICAgICBjYXRlZ29yeSA9ICdub3QtZm91bmQnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA5IHx8IHJlcy5zdGF0dXMgPT09IDQyMikge1xuICAgICAgY2F0ZWdvcnkgPSAnY29uZmxpY3QnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA+PSA1MDApIHtcbiAgICAgIGNhdGVnb3J5ID0gJ3NlcnZlcic7XG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDI5KSB7XG4gICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgc3RhdHVzOiByZXMuc3RhdHVzLFxuICAgICAgYm9keSxcbiAgICAgIG1lc3NhZ2U6IGAke2xhYmVsfSBcdTIxOTIgJHtyZXMuc3RhdHVzfTogJHttc2d9YCxcbiAgICAgIHJldHJpYWJsZSxcbiAgICAgIGNhdGVnb3J5LFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IHBhcnNlUmF0ZUxpbWl0UmVzZXQocmVzLmhlYWRlcnMpIDogbnVsbCxcbiAgICB9KTtcbiAgfVxufVxuXG4vKipcbiAqIEJlc3QtZWZmb3J0IHBhcnNlIG9mIHdoZW4gdGhlIGN1cnJlbnQgcmF0ZS1saW1pdCB3aW5kb3cgZW5kcy4gR2l0SHViJ3NcbiAqIHByaW1hcnkgbGltaXQgcmVwb3J0cyBgWC1SYXRlTGltaXQtUmVzZXRgIGFzIGEgVW5peCBlcG9jaCBpbiBzZWNvbmRzLlxuICogU2Vjb25kYXJ5IC8gYWJ1c2UgbGltaXRzIHVzZSBgUmV0cnktQWZ0ZXJgLCB3aGljaCBpcyBlaXRoZXIgYW4gSFRUUC1kYXRlXG4gKiBvciBhIGRlbHRhIGluIHNlY29uZHMgXHUyMDE0IHdlIG5vcm1hbGl6ZSBib3RoIHRvIGVwb2NoIHNlY29uZHMuXG4gKi9cbmZ1bmN0aW9uIHBhcnNlUmF0ZUxpbWl0UmVzZXQoaGVhZGVyczogSGVhZGVycyk6IG51bWJlciB8IG51bGwge1xuICBjb25zdCByZXNldCA9IGhlYWRlcnMuZ2V0KCd4LXJhdGVsaW1pdC1yZXNldCcpO1xuICBpZiAocmVzZXQpIHtcbiAgICBjb25zdCBuID0gTnVtYmVyLnBhcnNlSW50KHJlc2V0LCAxMCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShuKSAmJiBuID4gMCkgcmV0dXJuIG47XG4gIH1cbiAgY29uc3QgcmV0cnlBZnRlciA9IGhlYWRlcnMuZ2V0KCdyZXRyeS1hZnRlcicpO1xuICBpZiAocmV0cnlBZnRlcikge1xuICAgIGNvbnN0IGRlbHRhID0gTnVtYmVyLnBhcnNlSW50KHJldHJ5QWZ0ZXIsIDEwKTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGRlbHRhKSAmJiBkZWx0YSA+PSAwKSB7XG4gICAgICByZXR1cm4gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCkgKyBkZWx0YTtcbiAgICB9XG4gICAgY29uc3QgYXNEYXRlID0gRGF0ZS5wYXJzZShyZXRyeUFmdGVyKTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGFzRGF0ZSkpIHJldHVybiBNYXRoLmZsb29yKGFzRGF0ZSAvIDEwMDApO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBlbmNvZGVQYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIEVuY29kZSBzZWdtZW50cyBpbmRpdmlkdWFsbHkgc28gc2xhc2hlcyByZW1haW4uXG4gIHJldHVybiBwYXRoLnNwbGl0KCcvJykubWFwKGVuY29kZVVSSUNvbXBvbmVudCkuam9pbignLycpO1xufVxuXG5mdW5jdGlvbiBiYWNrb2ZmTXMoYXR0ZW1wdDogbnVtYmVyLCBlcnI6IEdpdEh1YkVycm9yKTogbnVtYmVyIHtcbiAgLy8gRXhwb25lbnRpYWwgd2l0aCBqaXR0ZXI7IGJ1bXAgaGlnaGVyIGZvciByYXRlLWxpbWl0IHJlc3BvbnNlcy5cbiAgY29uc3QgYmFzZSA9IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnID8gNTAwMCA6IDUwMDtcbiAgY29uc3Qgaml0dGVyID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNDAwKTtcbiAgcmV0dXJuIE1hdGgubWluKDYwXzAwMCwgYmFzZSAqIDIgKiogKGF0dGVtcHQgLSAxKSArIGppdHRlcik7XG59XG5cbmZ1bmN0aW9uIGlzQ29uZmxpY3QoZXJyOiB1bmtub3duKTogZXJyIGlzIEdpdEh1YkVycm9yIHtcbiAgcmV0dXJuIGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ2NvbmZsaWN0Jztcbn1cblxuZnVuY3Rpb24gc2xlZXAobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBieXRlcyBpcyBhIFVURi04IHN0cmluZyBvZiBKU09OOyBlbmNvZGUgdG8gYmFzZTY0IHRoZSBzYWZlIHdheS5cbiAgY29uc3QgdXRmOCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShieXRlcyk7XG4gIGxldCBiaW4gPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIHV0ZjgpIGJpbiArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShiaW4pO1xufVxuIiwgImltcG9ydCB7IFRXRUVUX1VSTF9QUkVGSVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDb21tdW5pdHlOb3RlLFxuICBNZWRpYUl0ZW0sXG4gIFR3ZWV0Q2FyZCxcbiAgVHdlZXRUeXBlLFxuICBVcmxFbnRpdHksXG4gIFVzZXJTbmFwc2hvdCxcbn0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTm9ybWFsaXplIEdyYXBoUUwgcmVzcG9uc2UgcGF5bG9hZHMgZnJvbSBYJ3MgaW50ZXJuYWwgQVBJIGludG9cbiAqIGBDYW5vbmljYWxUd2VldGBzLiBNYW55IGVuZHBvaW50cyBzaGFyZSBhIHNpbWlsYXIgdHdlZXQgc2hhcGUgYnV0IHdyYXAgaXQgaW5cbiAqIGRpZmZlcmVudCBlbnZlbG9wZXM7IHRoaXMgbW9kdWxlIHdhbGtzIHRoZSBzdHJ1Y3R1cmUgZGVmZW5zaXZlbHkuXG4gKlxuICogVGhlIHBhcnNlciBpcyBpbnRlbnRpb25hbGx5IHBlcm1pc3NpdmU6IGl0IHdpbGwgc2lsZW50bHkgc2tpcCBlbnRyaWVzIGl0XG4gKiBjYW4ndCByZWNvZ25pemUgYXMgdHdlZXRzIChjdXJzb3JzLCBhZHMsIGdhcCBlbnRyaWVzLCBtb2R1bGVzIG9mIG90aGVyXG4gKiB0d2VldHMsIHRvbWJzdG9uZXMpLiBJdCB0aHJvd3MgKm9ubHkqIHdoZW4gZ2l2ZW4gYSBwYXlsb2FkIGl0IGRvZXNuJ3Qga25vd1xuICogaG93IHRvIHdhbGsgYXQgYWxsIFx1MjAxNCB0aG9zZSBjYXNlcyBhcmUgY2F1Z2h0IGFuZCBxdWFyYW50aW5lZCB1cHN0cmVhbS5cbiAqL1xuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZUNvbnRleHQge1xuICBjYXB0dXJlZEF0OiBzdHJpbmc7XG4gIHJ1bklkOiBzdHJpbmc7XG4gIGVuZHBvaW50OiBzdHJpbmc7XG4gIGFsbG93ZWRIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZVJlc3VsdCB7XG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcbiAgb2JzZXJ2ZWRfaWRzOiBzdHJpbmdbXTtcbiAgLyoqXG4gICAqIFR3ZWV0LXNoYXBlZCBub2RlcyB0aGUgd2Fsa2VyIHNhdyAoaGFkIGEgYHJlc3RfaWRgKSBidXQgY291bGRuJ3QgdHVyblxuICAgKiBpbnRvIGEgZnVsbCBgQ2Fub25pY2FsVHdlZXRgIFx1MjAxNCB0eXBpY2FsbHkgYmVjYXVzZSB0aGUgZW1iZWRkZWQgdXNlclxuICAgKiBpbmZvIHdhcyBtaXNzaW5nIG9yIHRoZSBlbnRyeSB3YXMgYSBtZWRpYS1vbmx5IHRodW1ibmFpbCBjYXJkIGZyb21cbiAgICogdGhlIFVzZXJNZWRpYSBlbmRwb2ludC4gVGhlIGJhY2tncm91bmQgcXVldWVzIHRoZXNlIGZvciBhbiBleHBsaWNpdFxuICAgKiBcImdvIGZldGNoIHRoZSBkZXRhaWwgcGFnZVwiIGNyYXdsIHNvIHdlIGRvbid0IGRyb3AgdGhlbSBvbiB0aGUgZmxvb3IuXG4gICAqL1xuICBwYXJ0aWFsX2lkczogQXJyYXk8eyB0d2VldF9pZDogc3RyaW5nOyBoaW50X2hhbmRsZTogc3RyaW5nIHwgbnVsbCB9Pjtcbn1cblxuLy8gWCB0d2VldCBJRHMgYXJlIDY0LWJpdCBwb3NpdGl2ZSBpbnRlZ2VycyBzZXJpYWxpemVkIGFzIGRlY2ltYWwgc3RyaW5ncy5cbi8vIFRoZXkndmUgZ3Jvd24gdG8gMTkgY2hhcnMgKH4xLjVlMTgpIGJ5IDIwMjYuIFJlamVjdCBhbnl0aGluZyB0aGF0IGRvZXNuJ3Rcbi8vIG1hdGNoIHRoaXMgc2hhcGUgXHUyMDE0IG90aGVyd2lzZSBzcHVyaW91cyBjYXJkIElEcywgY3Vyc29yIHN0cmluZ3MsIGFkIHNsb3Rcbi8vIElEcywgZXRjLiBlbmQgdXAgaW4gdGhlIHBhcnRpYWwtY2FwdHVyZSBxdWV1ZSBhbmQgdGhlIGNyYXdsIGxvb3Bcbi8vIG5hdmlnYXRlcyB0byBpbnZhbGlkIFVSTHMgdGhhdCBzaG93IFwidGhpcyBwYWdlIGRvZXNuJ3QgZXhpc3RcIi5cbmNvbnN0IFRXRUVUX0lEX1JFID0gL15cXGR7MTUsMjB9JC87XG5cbi8vIE9ubHkgb25lIGVuZHBvaW50IGFjdHVhbGx5IGV4cG9zZXMgdGhlIGZhaWx1cmUgbW9kZSB0aGUgcGFydGlhbC1jYXB0dXJlXG4vLyBxdWV1ZSBleGlzdHMgZm9yIFx1MjAxNCB0aGUgTWVkaWEgdGFiJ3MgYFVzZXJNZWRpYWAgcXVlcnkgcmV0dXJuaW5nXG4vLyB0aHVtYm5haWwtb25seSBlbnRyaWVzIHdpdGhvdXQgYSBwb3B1bGF0ZWQgYXV0aG9yIGJsb2NrLiBFdmVyeSBvdGhlclxuLy8gZW5kcG9pbnQgdGhhdCBoYW5kcyB1cyBhIGBUd2VldGAgc2hhcGUgZ2l2ZXMgdXMgdGhlIGZ1bGwgZW50cnk7IGlmXG4vLyBgYnVpbGRUd2VldGAgZmFpbHMgdGhlcmUgaXQncyBhIHJlYWwgZXJyb3IsIG5vdCBcImdvIHJlLWZldGNoIHRoaXNcIi5cbi8vIFJlc3RyaWN0aW5nIHBhcnRpYWwtaWQgZW1pc3Npb24gdG8gVXNlck1lZGlhIHN0b3BzIHRoZSBmbG9vZHMgb2Zcbi8vIGZhbHNlIHBvc2l0aXZlcyByZXBvcnRlZCBvbiBSZXBsaWVzIC8gVHdlZXREZXRhaWwgLyBTZWFyY2hUaW1lbGluZS5cbmNvbnN0IFBBUlRJQUxfT0tfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJNZWRpYSddKTtcblxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShwYXlsb2FkOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBOb3JtYWxpemVSZXN1bHQge1xuICBjb25zdCByYXdUd2VldHMgPSBjb2xsZWN0VHdlZXRzKHBheWxvYWQpO1xuICBjb25zdCB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10gPSBbXTtcbiAgY29uc3Qgb2JzZXJ2ZWQ6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IGJ1aWx0ID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHBhcnRpYWxNYXAgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nIHwgbnVsbD4oKTtcbiAgY29uc3QgY29sbGVjdFBhcnRpYWxzID0gUEFSVElBTF9PS19FTkRQT0lOVFMuaGFzKGN0eC5lbmRwb2ludCk7XG4gIGZvciAoY29uc3QgcmF3IG9mIHJhd1R3ZWV0cykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0ID0gYnVpbGRUd2VldChyYXcsIGN0eCk7XG4gICAgICBpZiAoIXQpIHtcbiAgICAgICAgaWYgKGNvbGxlY3RQYXJ0aWFscykge1xuICAgICAgICAgIC8vIE9ubHkgZW5xdWV1ZSByZWFsLXR3ZWV0IHNoZWxscyAobm90IHRvbWJzdG9uZXMsIG5vdCBzdHJpcHBlZFxuICAgICAgICAgIC8vIG5vZGVzIGxhY2tpbmcgYSBsZWdhY3kgYmxvY2ssIG5vdCBnYXJiYWdlIElEcykuXG4gICAgICAgICAgY29uc3QgcGFydGlhbCA9IHBpY2tQYXJ0aWFsKHJhdyk7XG4gICAgICAgICAgaWYgKHBhcnRpYWwpIHBhcnRpYWxNYXAuc2V0KHBhcnRpYWwudHdlZXRfaWQsIHBhcnRpYWwuaGludF9oYW5kbGUpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIGJ1aWx0LmFkZCh0LnR3ZWV0X2lkKTtcbiAgICAgIGlmIChjdHguYWxsb3dlZEhhbmRsZXMuc2l6ZSA9PT0gMCB8fCBjdHguYWxsb3dlZEhhbmRsZXMuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgdHdlZXRzLnB1c2godCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBPbmUgYmFkIGVudHJ5IHNob3VsZG4ndCB0YWtlIGRvd24gdGhlIHdob2xlIGJhdGNoLlxuICAgIH1cbiAgfVxuICAvLyBBbnl0aGluZyB0aGF0IGVuZGVkIHVwIGluIHBhcnRpYWxNYXAgYnV0IEFMU08gY2FtZSBiYWNrIGFzIGEgYnVpbHRcbiAgLy8gdHdlZXQgKGRpZmZlcmVudCB3YWxrZXIgcGFzcywgc2FtZSBpZCkgaXNuJ3QgYWN0dWFsbHkgcGFydGlhbC5cbiAgY29uc3QgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcbiAgZm9yIChjb25zdCBbaWQsIGhpbnRdIG9mIHBhcnRpYWxNYXApIHtcbiAgICBpZiAoYnVpbHQuaGFzKGlkKSkgY29udGludWU7XG4gICAgcGFydGlhbF9pZHMucHVzaCh7IHR3ZWV0X2lkOiBpZCwgaGludF9oYW5kbGU6IGhpbnQgfSk7XG4gIH1cbiAgcmV0dXJuIHsgdHdlZXRzLCBvYnNlcnZlZF9pZHM6IG9ic2VydmVkLCBwYXJ0aWFsX2lkcyB9O1xufVxuXG5mdW5jdGlvbiBwaWNrUGFydGlhbChub2RlOiB1bmtub3duKTogeyB0d2VldF9pZDogc3RyaW5nOyBoaW50X2hhbmRsZTogc3RyaW5nIHwgbnVsbCB9IHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAvLyBEZWxldGVkIHR3ZWV0cyBzdXJmYWNlIGFzIFR3ZWV0VG9tYnN0b25lIFx1MjAxNCB0aGVyZSdzIG5vdGhpbmcgdG8gcmVmZXRjaCxcbiAgLy8gc2tpcCB0aGVtIG9yIHRoZSBjcmF3bCBsb29wIHdpbGwgc3BpbiBvbiBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXG4gIGlmIChuLl9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xuICAvLyBSZXF1aXJlIGEgcmVjb2duaXplZCBUd2VldCB0eXBlbmFtZSBPUiBhIGxlZ2FjeSBibG9jay4gQ3Vyc29ycywgYWRzLFxuICAvLyBtb2R1bGUgaGVhZGVycywgYW5kIHRoZSBsaWtlIGdldCByZWplY3RlZCBoZXJlLlxuICBjb25zdCB0biA9IG4uX190eXBlbmFtZTtcbiAgaWYgKHRuICE9PSAnVHdlZXQnICYmIHRuICE9PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnICYmICFvYmoobi5sZWdhY3kpKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgcmVzdElkID1cbiAgICAodHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgbi5yZXN0X2lkKSB8fFxuICAgICh0eXBlb2Ygb2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0ID09PSAnb2JqZWN0JyAmJlxuICAgICAgKG9iaihvYmoobi50d2VldF9yZXN1bHQpPy5yZXN1bHQpPy5yZXN0X2lkIGFzIHN0cmluZykpO1xuICBpZiAodHlwZW9mIHJlc3RJZCAhPT0gJ3N0cmluZycgfHwgIVRXRUVUX0lEX1JFLnRlc3QocmVzdElkKSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiB7IHR3ZWV0X2lkOiByZXN0SWQsIGhpbnRfaGFuZGxlOiBwaWNrSGludEhhbmRsZShub2RlKSB9O1xufVxuXG5mdW5jdGlvbiBwaWNrSGludEhhbmRsZShub2RlOiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihvYmoobi5jb3JlKT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgcmV0dXJuIChcbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmNvcmUpPy5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbChvYmoobi5sZWdhY3kpPy5zY3JlZW5fbmFtZSlcbiAgKTtcbn1cblxuZnVuY3Rpb24gY29sbGVjdFR3ZWV0cyhvYmo6IHVua25vd24pOiB1bmtub3duW10ge1xuICAvLyBXYWxrIHRoZSByZXNwb25zZSB0cmVlIGdhdGhlcmluZyBldmVyeXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIHR3ZWV0XG4gIC8vIHJlc3VsdC4gV2UgbG9vayBmb3Igbm9kZXMgc2hhcGVkIGxpa2U6XG4gIC8vICAgeyBfX3R5cGVuYW1lPzogJ1R3ZWV0J3wnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnLCByZXN0X2lkLCBsZWdhY3kgfVxuICAvLyBhbmQgdW53cmFwIHZpc2liaWxpdHkgd3JhcHBlcnMuXG4gIGNvbnN0IG91dDogdW5rbm93bltdID0gW107XG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbb2JqXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBub2RlID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG5vZGUgPT09IG51bGwgfHwgbm9kZSA9PT0gdW5kZWZpbmVkKSBjb250aW51ZTtcbiAgICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAoc2Vlbi5oYXMobm9kZSBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChub2RlIGFzIG9iamVjdCk7XG5cbiAgICBpZiAobG9va3NMaWtlVHdlZXQobm9kZSkpIHtcbiAgICAgIG91dC5wdXNoKHVud3JhcFR3ZWV0KG5vZGUpKTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobm9kZSkpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBub2RlKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gbG9va3NMaWtlVHdlZXQobm9kZTogdW5rbm93bik6IG5vZGUgaXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIGNvbnN0IHR5cGVuYW1lID0gbi5fX3R5cGVuYW1lO1xuICBpZiAoXG4gICAgdHlwZW5hbWUgPT09ICdUd2VldCcgfHxcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyB8fFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnXG4gICkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIC8vIFNvbWUgZW50cmllcyBsYWNrIF9fdHlwZW5hbWUgYnV0IHN0aWxsIGNhcnJ5IGxlZ2FjeSArIHJlc3RfaWQgKyBjb3JlLlxuICByZXR1cm4gdHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgdHlwZW9mIG4ubGVnYWN5ID09PSAnb2JqZWN0JyAmJiBuLmxlZ2FjeSAhPT0gbnVsbDtcbn1cblxuZnVuY3Rpb24gdW53cmFwVHdlZXQobm9kZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XG4gIGlmIChub2RlLl9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgJiYgdHlwZW9mIG5vZGUudHdlZXQgPT09ICdvYmplY3QnKSB7XG4gICAgcmV0dXJuIG5vZGUudHdlZXQgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIH1cbiAgcmV0dXJuIG5vZGU7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkVHdlZXQocmF3OiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBDYW5vbmljYWxUd2VldCB8IG51bGwge1xuICBpZiAodHlwZW9mIHJhdyAhPT0gJ29iamVjdCcgfHwgcmF3ID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgdCA9IHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcblxuICBpZiAodC5fX3R5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCByZXN0SWQgPSBzdHJPck51bGwodC5yZXN0X2lkKTtcbiAgLy8gYGxlZ2FjeWAgaXMgc3RpbGwgd2hlcmUgbW9zdCBlbmdhZ2VtZW50IC8gZW50aXRpZXMgbGl2ZSBpbiAyMDI2LWVyYSBYXG4gIC8vIHBheWxvYWRzLCBidXQgYXMgb2YgcmVjZW50IHNjaGVtYSBtaWdyYXRpb25zIHNldmVyYWwgZmllbGRzIHByZXZpb3VzbHlcbiAgLy8gdGhlcmUgKG5vdGFibHkgdGhlIGF1dGhvciBoYW5kbGUpIGhhdmUgbW92ZWQgdG8gc2libGluZyBsb2NhdGlvbnMuIFdlXG4gIC8vIHRvbGVyYXRlIGEgbWlzc2luZyBsZWdhY3kgaGVyZSBhbmQgbG9vayB1cCBldmVyeXRoaW5nIHZpYSBmYWxsYmFja3MuXG4gIGNvbnN0IGxlZ2FjeSA9IG9iaih0LmxlZ2FjeSkgPz8ge307XG4gIGlmICghcmVzdElkKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBjb3JlID0gb2JqKHQuY29yZSk7XG4gIGNvbnN0IHVzZXJSZXN1bHQgPSBvYmoob2JqKGNvcmU/LnVzZXJfcmVzdWx0cyk/LnJlc3VsdCk7XG4gIC8vIEF1dGhvciBoYW5kbGU6IHRyeSB0aGUgbmV3IGBjb3JlYCBzdWJzdHJ1Y3R1cmUgZmlyc3QgKGN1cnJlbnQgWCBzaGFwZSksXG4gIC8vIHRoZW4gdGhlIGxlZ2FjeSBgbGVnYWN5LnNjcmVlbl9uYW1lYCwgdGhlbiBhIGNvdXBsZSBvZiBvbGRlciB2YXJpYW50cy5cbiAgY29uc3QgdXNlckNvcmVOZXcgPSBvYmoodXNlclJlc3VsdD8uY29yZSk7XG4gIGNvbnN0IHVzZXJMZWdhY3kgPSBvYmoodXNlclJlc3VsdD8ubGVnYWN5KTtcbiAgY29uc3QgdXNlckF2YXRhck9iaiA9IG9iaih1c2VyUmVzdWx0Py5hdmF0YXIpO1xuICBjb25zdCBoYW5kbGUgPVxuICAgIHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwobGVnYWN5LnNjcmVlbl9uYW1lKTtcbiAgY29uc3QgYWNjb3VudElkID1cbiAgICBzdHJPck51bGwodXNlclJlc3VsdD8ucmVzdF9pZCkgPz9cbiAgICBzdHJPck51bGwodXNlclJlc3VsdD8uaWRfc3RyKSA/P1xuICAgIHN0ck9yTnVsbChsZWdhY3kudXNlcl9pZF9zdHIpO1xuICBpZiAoIWhhbmRsZSB8fCAhYWNjb3VudElkKSByZXR1cm4gbnVsbDtcbiAgLy8gQXV0aG9yIHNuYXBzaG90LiBEaXNwbGF5IG5hbWUgKyBhdmF0YXIgbW92ZWQgYmV0d2VlbiBgbGVnYWN5YCBhbmQgdGhlXG4gIC8vIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIG92ZXIgdGltZTsgdGhlIHJlc3QgKHZlcmlmaWNhdGlvbiwgZm9sbG93ZXJcbiAgLy8gY291bnRzLCBhY2NvdW50X2NyZWF0ZWRfYXQpIGlzIHN0aWxsIGluIGBsZWdhY3lgLiBXZSBzbmFwc2hvdCB0aGVcbiAgLy8gd2hvbGUgVXNlclNuYXBzaG90IHBlciB0d2VldCBiZWNhdXNlIHRoZXNlIHZhbHVlcyBkcmlmdCBvdmVyIHRpbWVcbiAgLy8gYW5kIHRoZSBhdC1jYXB0dXJlIHN0YXRlIGlzIHRoZSBvbmx5IHJlbGlhYmxlIHJlY29yZC5cbiAgY29uc3QgYXV0aG9yID0gZXh0cmFjdFVzZXJTbmFwc2hvdCh1c2VyUmVzdWx0LCB1c2VyQ29yZU5ldywgdXNlckxlZ2FjeSwgdXNlckF2YXRhck9iaik7XG5cbiAgY29uc3Qgbm90ZVR3ZWV0ID0gb2JqKG9iaihvYmoodC5ub3RlX3R3ZWV0KT8ubm90ZV90d2VldF9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgY29uc3QgdGV4dEZyb21Ob3RlID0gc3RyT3JOdWxsKG5vdGVUd2VldD8udGV4dCk7XG4gIGNvbnN0IHRleHRGcm9tTGVnYWN5ID0gc3RyT3JOdWxsKGxlZ2FjeS5mdWxsX3RleHQpID8/ICcnO1xuICBjb25zdCB0ZXh0ID0gdGV4dEZyb21Ob3RlID8/IHRleHRGcm9tTGVnYWN5O1xuICBjb25zdCBpc1RydW5jYXRlZCA9IGRldGVjdFRydW5jYXRpb24obm90ZVR3ZWV0LCBsZWdhY3ksIHRleHRGcm9tTGVnYWN5KTtcbiAgY29uc3QgY29tbXVuaXR5Tm90ZSA9IGV4dHJhY3RDb21tdW5pdHlOb3RlKHQsIGxlZ2FjeSwgY3R4LmNhcHR1cmVkQXQpO1xuXG4gIGNvbnN0IGVudGl0aWVzID0gb2JqKGxlZ2FjeS5lbnRpdGllcykgPz8ge307XG4gIGNvbnN0IGVudGl0aWVzRnJvbU5vdGUgPSBvYmoobm90ZVR3ZWV0Py5lbnRpdHlfc2V0KTtcbiAgY29uc3QgaGFzaHRhZ3MgPSBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IG1lbnRpb25zID0gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xuICBjb25zdCB1cmxzID0gZXh0cmFjdFVybHMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IG1lZGlhID0gZXh0cmFjdE1lZGlhKGxlZ2FjeSk7XG5cbiAgY29uc3QgdHdlZXRUeXBlID0gY2xhc3NpZnlUd2VldFR5cGUodCwgbGVnYWN5KTtcblxuICAvLyBwb3N0ZWRfYXQ6IGxlZ2FjeS5jcmVhdGVkX2F0IHJlbWFpbnMgdGhlIGNhbm9uaWNhbCBsb2NhdGlvbjsgaWYgdGhhdCdzXG4gIC8vIG1pc3NpbmcgaW4gYSBmdXR1cmUgc2NoZW1hIHdlIGZhbGwgYmFjayB0byB0b3AtbGV2ZWwgY3JlYXRlZF9hdC5cbiAgY29uc3QgcG9zdGVkQXQgPVxuICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKGxlZ2FjeS5jcmVhdGVkX2F0KSkgPz8gcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodC5jcmVhdGVkX2F0KSk7XG4gIGlmICghcG9zdGVkQXQpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHZpZXdzID0gb2JqKHQudmlld3MpO1xuICBjb25zdCB2aWV3Q291bnQgPSBudW1Pck51bGwodmlld3M/LmNvdW50KSA/PyBudW1Pck51bGwoc3RyT3JOdWxsKHZpZXdzPy5jb3VudCkpO1xuXG4gIGNvbnN0IGNhcmQgPSBleHRyYWN0Q2FyZCh0KTtcbiAgY29uc3QgcGxhY2UgPSBvYmoobGVnYWN5LnBsYWNlKTtcblxuICBjb25zdCB0d2VldDogQ2Fub25pY2FsVHdlZXQgPSB7XG4gICAgdHdlZXRfaWQ6IHJlc3RJZCxcbiAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgIGFjY291bnRfaWQ6IGFjY291bnRJZCxcbiAgICBwb3N0ZWRfYXQ6IHBvc3RlZEF0LFxuICAgIGZpcnN0X2NhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICBsYXN0X3NlZW5fYXQ6IGN0eC5jYXB0dXJlZEF0LFxuICAgIGRlbGV0aW9uX2RldGVjdGVkX2F0OiBudWxsLFxuICAgIHR3ZWV0X3VybDogYCR7VFdFRVRfVVJMX1BSRUZJWH0vJHtoYW5kbGV9L3N0YXR1cy8ke3Jlc3RJZH1gLFxuICAgIHR3ZWV0X3R5cGU6IHR3ZWV0VHlwZSxcbiAgICBjb252ZXJzYXRpb25faWQ6IHN0ck9yTnVsbChsZWdhY3kuY29udmVyc2F0aW9uX2lkX3N0ciksXG4gICAgcmVwbHlfdG9fdHdlZXRfaWQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0ciksXG4gICAgcmVwbHlfdG9fYWNjb3VudDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zY3JlZW5fbmFtZSksXG4gICAgcmVwbHlfdG9fYWNjb3VudF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b191c2VyX2lkX3N0ciksXG4gICAgcXVvdGVkX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSxcbiAgICByZXR3ZWV0ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChcbiAgICAgIG9iaihvYmoobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCA/P1xuICAgICAgICAobGVnYWN5IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0clxuICAgICksXG4gICAgdGV4dCxcbiAgICB0ZXh0X3Jlc29sdmVkOiByZXNvbHZlU2hvcnRVcmxzKHRleHQsIHVybHMpLFxuICAgIGxhbmc6IHN0ck9yTnVsbChsZWdhY3kubGFuZyksXG4gICAgcG9zc2libHlfc2Vuc2l0aXZlOiBib29sT3JOdWxsKGxlZ2FjeS5wb3NzaWJseV9zZW5zaXRpdmUpLFxuICAgIHNvdXJjZTogc3RyT3JOdWxsKGxlZ2FjeS5zb3VyY2UpID8/IHN0ck9yTnVsbCh0LnNvdXJjZSksXG4gICAgcGxhY2VfZnVsbF9uYW1lOiBzdHJPck51bGwocGxhY2U/LmZ1bGxfbmFtZSksXG4gICAgaGFzaHRhZ3MsXG4gICAgbWVudGlvbnMsXG4gICAgdXJscyxcbiAgICBjYXJkLFxuICAgIG1lZGlhLFxuICAgIGxpa2VfY291bnQ6IG51bU9yWmVybyhsZWdhY3kuZmF2b3JpdGVfY291bnQpLFxuICAgIHJldHdlZXRfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXG4gICAgcmVwbHlfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucmVwbHlfY291bnQpLFxuICAgIHF1b3RlX2NvdW50OiBudW1Pclplcm8obGVnYWN5LnF1b3RlX2NvdW50KSxcbiAgICB2aWV3X2NvdW50OiB2aWV3Q291bnQsXG4gICAgYm9va21hcmtfY291bnQ6IG51bU9yTnVsbChsZWdhY3kuYm9va21hcmtfY291bnQpLFxuICAgIGVuZ2FnZW1lbnRfaGlzdG9yeTogW1xuICAgICAge1xuICAgICAgICBjYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgICAgIGxpa2VzOiBudW1Pclplcm8obGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcbiAgICAgICAgcmV0d2VldHM6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXG4gICAgICAgIHJlcGxpZXM6IG51bU9yWmVybyhsZWdhY3kucmVwbHlfY291bnQpLFxuICAgICAgICBxdW90ZXM6IG51bU9yWmVybyhsZWdhY3kucXVvdGVfY291bnQpLFxuICAgICAgICB2aWV3czogdmlld0NvdW50LFxuICAgICAgICBib29rbWFya3M6IG51bU9yTnVsbChsZWdhY3kuYm9va21hcmtfY291bnQpLFxuICAgICAgfSxcbiAgICBdLFxuICAgIGF1dGhvcixcbiAgICBjb21tdW5pdHlfbm90ZTogY29tbXVuaXR5Tm90ZSxcbiAgICBpc190cnVuY2F0ZWQ6IGlzVHJ1bmNhdGVkLFxuICAgIHdheWJhY2tfdXJsOiBudWxsLFxuICAgIHdheWJhY2tfc3VibWl0dGVkX2F0OiBudWxsLFxuICAgIGNhcHR1cmVfc291cmNlOiAnZXh0ZW5zaW9uJyxcbiAgICBjYXB0dXJlX3J1bl9pZDogY3R4LnJ1bklkLFxuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICB9O1xuXG4gIHJldHVybiB0d2VldDtcbn1cblxuZnVuY3Rpb24gY2xhc3NpZnlUd2VldFR5cGUodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldFR5cGUge1xuICBpZiAobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0IHx8IGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXR3ZWV0JztcbiAgaWYgKGxlZ2FjeS5pbl9yZXBseV90b19zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JlcGx5JztcbiAgaWYgKGxlZ2FjeS5pc19xdW90ZV9zdGF0dXMgPT09IHRydWUgfHwgbGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3F1b3RlJztcbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJykge1xuICAgIC8vIHBhc3MgdGhyb3VnaFxuICB9XG4gIHJldHVybiAnb3JpZ2luYWwnO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy5oYXNodGFncztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgcmV0dXJuIGFyclxuICAgIC5tYXAoKGgpID0+XG4gICAgICB0eXBlb2YgaCA9PT0gJ29iamVjdCcgJiYgaCAmJiAndGV4dCcgaW4gaCA/IFN0cmluZygoaCBhcyB7IHRleHQ6IHVua25vd24gfSkudGV4dCkgOiBudWxsXG4gICAgKVxuICAgIC5maWx0ZXIoKHMpOiBzIGlzIHN0cmluZyA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZ1tdIHtcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXNlcl9tZW50aW9ucztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgcmV0dXJuIGFyclxuICAgIC5tYXAoKHUpID0+XG4gICAgICB0eXBlb2YgdSA9PT0gJ29iamVjdCcgJiYgdSAmJiAnc2NyZWVuX25hbWUnIGluIHVcbiAgICAgICAgPyBTdHJpbmcoKHUgYXMgeyBzY3JlZW5fbmFtZTogdW5rbm93biB9KS5zY3JlZW5fbmFtZSlcbiAgICAgICAgOiBudWxsXG4gICAgKVxuICAgIC5maWx0ZXIoKHMpOiBzIGlzIHN0cmluZyA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdFVybHMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVXJsRW50aXR5W10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy51cmxzO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICBjb25zdCBvdXQ6IFVybEVudGl0eVtdID0gW107XG4gIGZvciAoY29uc3QgdSBvZiBhcnIpIHtcbiAgICBpZiAodHlwZW9mIHUgIT09ICdvYmplY3QnIHx8IHUgPT09IG51bGwpIGNvbnRpbnVlO1xuICAgIGNvbnN0IG8gPSB1IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIGNvbnN0IHNob3J0ID0gc3RyT3JOdWxsKG8udXJsKTtcbiAgICBjb25zdCBleHBhbmRlZCA9IHN0ck9yTnVsbChvLmV4cGFuZGVkX3VybCk7XG4gICAgY29uc3QgZGlzcGxheSA9IHN0ck9yTnVsbChvLmRpc3BsYXlfdXJsKTtcbiAgICBpZiAoIXNob3J0IHx8ICFleHBhbmRlZCkgY29udGludWU7XG4gICAgb3V0LnB1c2goeyBzaG9ydCwgZXhwYW5kZWQsIGRpc3BsYXk6IGRpc3BsYXkgPz8gZXhwYW5kZWQgfSk7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdE1lZGlhKGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW1bXSB7XG4gIGNvbnN0IGV4dGVuZGVkID0gb2JqKGxlZ2FjeS5leHRlbmRlZF9lbnRpdGllcyk7XG4gIGNvbnN0IGZyb21FeHQgPSBleHRlbmRlZCA/IHRvQXJyYXkoZXh0ZW5kZWQubWVkaWEpIDogW107XG4gIGNvbnN0IGZyb21FbnQgPSB0b0FycmF5KG9iaihsZWdhY3kuZW50aXRpZXMpPy5tZWRpYSk7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgbWVyZ2VkID0gWy4uLmZyb21FeHQsIC4uLmZyb21FbnRdLmZpbHRlcigobSkgPT4ge1xuICAgIGlmICh0eXBlb2YgbSAhPT0gJ29iamVjdCcgfHwgbSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGlkID1cbiAgICAgIHN0ck9yTnVsbCgobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikubWVkaWFfa2V5KSA/P1xuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5pZF9zdHIpO1xuICAgIGlmICghaWQpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoc2Vlbi5oYXMoaWQpKSByZXR1cm4gZmFsc2U7XG4gICAgc2Vlbi5hZGQoaWQpO1xuICAgIHJldHVybiB0cnVlO1xuICB9KTtcbiAgcmV0dXJuIG1lcmdlZC5tYXAoKHJhdykgPT4gYnVpbGRNZWRpYShyYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKTtcbn1cblxuZnVuY3Rpb24gYnVpbGRNZWRpYShtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbSB7XG4gIGNvbnN0IHR5cGUgPSBzdHJPck51bGwobS50eXBlKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXTtcbiAgY29uc3Qgb3JpZ2luYWwgPSBwaWNrT3JpZ2luYWxVcmwobSwgdHlwZSk7XG4gIGNvbnN0IGluZm8gPSBvYmoobS5vcmlnaW5hbF9pbmZvKTtcbiAgY29uc3QgdmlkZW9JbmZvID0gb2JqKG0udmlkZW9faW5mbyk7XG4gIGNvbnN0IGR1cmF0aW9uTXMgPSBudW1Pck51bGwodmlkZW9JbmZvPy5kdXJhdGlvbl9taWxsaXMpO1xuICBjb25zdCBhbHRUZXh0ID0gc3RyT3JOdWxsKG0uZXh0X2FsdF90ZXh0KTtcbiAgY29uc3QgbWVkaWFJZCA9XG4gICAgc3RyT3JOdWxsKG0ubWVkaWFfa2V5KSA/P1xuICAgIHN0ck9yTnVsbChtLmlkX3N0cikgPz9cbiAgICBgJHt0eXBlID8/ICdtZWRpYSd9LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMil9YDtcbiAgcmV0dXJuIHtcbiAgICBtZWRpYV9pZDogbWVkaWFJZCxcbiAgICBtZWRpYV90eXBlOiAodHlwZSA/PyAncGhvdG8nKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXSxcbiAgICBvcmlnaW5hbF91cmw6IG9yaWdpbmFsID8/ICcnLFxuICAgIHJlbGVhc2VfYXNzZXRfdXJsOiBudWxsLFxuICAgIHNoYTI1NjogbnVsbCxcbiAgICBieXRlczogbnVsbCxcbiAgICBkdXJhdGlvbl9zZWM6IGR1cmF0aW9uTXMgIT09IG51bGwgPyBkdXJhdGlvbk1zIC8gMTAwMCA6IG51bGwsXG4gICAgd2lkdGg6IG51bU9yTnVsbChpbmZvPy53aWR0aCksXG4gICAgaGVpZ2h0OiBudW1Pck51bGwoaW5mbz8uaGVpZ2h0KSxcbiAgICBhbHRfdGV4dDogYWx0VGV4dCxcbiAgICBhcmNoaXZlX3N0YXR1czogJ3BlbmRpbmcnLFxuICAgIGFyY2hpdmVfYXR0ZW1wdHM6IDAsXG4gICAgbGFzdF9hdHRlbXB0X2F0OiBudWxsLFxuICB9O1xufVxuXG5mdW5jdGlvbiBwaWNrT3JpZ2luYWxVcmwobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHR5cGU6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKHR5cGUgPT09ICdwaG90bycpIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpID8/IHN0ck9yTnVsbChtLm1lZGlhX3VybCk7XG4gIGNvbnN0IHZhcmlhbnRzID0gdG9BcnJheShvYmoobS52aWRlb19pbmZvKT8udmFyaWFudHMpIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+W107XG4gIGlmICh2YXJpYW50cy5sZW5ndGggPT09IDApIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpO1xuICAvLyBIaWdoZXN0LWJpdHJhdGUgbXA0LlxuICBsZXQgYmVzdDogeyB1cmw6IHN0cmluZzsgYml0cmF0ZTogbnVtYmVyIH0gfCBudWxsID0gbnVsbDtcbiAgZm9yIChjb25zdCB2IG9mIHZhcmlhbnRzKSB7XG4gICAgY29uc3QgY3QgPSBzdHJPck51bGwodi5jb250ZW50X3R5cGUpO1xuICAgIGNvbnN0IHVybCA9IHN0ck9yTnVsbCh2LnVybCk7XG4gICAgaWYgKCF1cmwpIGNvbnRpbnVlO1xuICAgIGlmIChjdCA9PT0gJ3ZpZGVvL21wNCcpIHtcbiAgICAgIGNvbnN0IGJyID0gbnVtT3JOdWxsKHYuYml0cmF0ZSkgPz8gMDtcbiAgICAgIGlmICghYmVzdCB8fCBiciA+IGJlc3QuYml0cmF0ZSkgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiBiciB9O1xuICAgIH0gZWxzZSBpZiAoIWJlc3QpIHtcbiAgICAgIC8vIEZhbGxiYWNrIHRvIGFueSB2YXJpYW50IGlmIG5vIG1wNCBmb3VuZC5cbiAgICAgIGJlc3QgPSB7IHVybCwgYml0cmF0ZTogMCB9O1xuICAgIH1cbiAgfVxuICByZXR1cm4gYmVzdD8udXJsID8/IG51bGw7XG59XG5cbmZ1bmN0aW9uIHJlc29sdmVTaG9ydFVybHModGV4dDogc3RyaW5nLCB1cmxzOiBVcmxFbnRpdHlbXSk6IHN0cmluZyB7XG4gIGlmICh1cmxzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHRleHQ7XG4gIGxldCBvdXQgPSB0ZXh0O1xuICBmb3IgKGNvbnN0IHUgb2YgdXJscykgb3V0ID0gb3V0LnNwbGl0KHUuc2hvcnQpLmpvaW4odS5leHBhbmRlZCk7XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIHBhcnNlVHdpdHRlckRhdGUoczogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAoIXMpIHJldHVybiBudWxsO1xuICAvLyBUd2l0dGVyIHNoaXBzIGRhdGVzIGxpa2UgXCJNb24gQXByIDEyIDE0OjIzOjAxICswMDAwIDIwMjVcIi5cbiAgY29uc3QgZCA9IG5ldyBEYXRlKHMpO1xuICBpZiAoTnVtYmVyLmlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiBkLnRvSVNPU3RyaW5nKCk7XG59XG5cbmZ1bmN0aW9uIHN0ck9yTnVsbCh2OiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwID8gdiA6IG51bGw7XG59XG5mdW5jdGlvbiBib29sT3JOdWxsKHY6IHVua25vd24pOiBib29sZWFuIHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nID8gdiA6IG51bGw7XG59XG5mdW5jdGlvbiBudW1Pck51bGwodjogdW5rbm93bik6IG51bWJlciB8IG51bGwge1xuICBpZiAodHlwZW9mIHYgPT09ICdudW1iZXInICYmIE51bWJlci5pc0Zpbml0ZSh2KSkgcmV0dXJuIHY7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IE51bWJlcih2KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKG4pKSByZXR1cm4gbjtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIG51bU9yWmVybyh2OiB1bmtub3duKTogbnVtYmVyIHtcbiAgcmV0dXJuIG51bU9yTnVsbCh2KSA/PyAwO1xufVxuZnVuY3Rpb24gb2JqKHY6IHVua25vd24pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwge1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdvYmplY3QnICYmIHYgIT09IG51bGwgJiYgIUFycmF5LmlzQXJyYXkodilcbiAgICA/ICh2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVxuICAgIDogbnVsbDtcbn1cbmZ1bmN0aW9uIHRvQXJyYXkodjogdW5rbm93bik6IHVua25vd25bXSB7XG4gIHJldHVybiBBcnJheS5pc0FycmF5KHYpID8gdiA6IFtdO1xufVxuXG4vKipcbiAqIERlY2lkZSB3aGV0aGVyIGEgdHdlZXQncyBhcmNoaXZlZCBgdGV4dGAgaXMgdGhlIHRydW5jYXRlZCBoZWFkIG9mIGEgbG9uZ2VyXG4gKiBib2R5LiBBIHRydW5jYXRlZCB0d2VldCBoYXMgWCdzIFwiU2hvdyBtb3JlXCIgdC5jbyBVUkwgYXBwZW5kZWQgXHUyMDE0IHRoYXQgVVJMXG4gKiBzcGVjaWZpY2FsbHkgZXhwYW5kcyB0byB0aGUgdHdlZXQncyBvd24gL2kvd2ViL3N0YXR1cy88aWQ+IHBlcm1hbGluaywgYW5kXG4gKiBpcyB0aGUgb25seSByZWxpYWJsZSBkaXN0aW5ndWlzaGluZyBmZWF0dXJlLiBQbGVudHkgb2Ygbm9ybWFsIHR3ZWV0cyBoYXZlXG4gKiB0cmFpbGluZyB0LmNvIFVSTHMgKG1lZGlhLCBxdW90ZXMsIHJlZ3VsYXIgbGlua3MpLCBhbmQgdGhlaXJcbiAqIGRpc3BsYXlfdGV4dF9yYW5nZSBhbHNvIHRyaW1zIHBhc3QgZnVsbF90ZXh0Lmxlbmd0aCwgc28gdGhlIG9sZFxuICogXCJkaXNwbGF5X3RleHRfcmFuZ2VbMV0gPCBmdWxsX3RleHQubGVuZ3RoXCIgaGV1cmlzdGljIHdhcyBvdmVyZmxhZ2dpbmdcbiAqIGVzc2VudGlhbGx5IGV2ZXJ5IHR3ZWV0IHdpdGggYSBsaW5rIGluIGl0LlxuICpcbiAqIFJ1bGVzOlxuICogICAtIG5vdGVfdHdlZXQgcHJlc2VudCAgXHUyMTkyIG5vdCB0cnVuY2F0ZWQgKHdlIGFscmVhZHkgaGF2ZSB0aGUgZnVsbCBib2R5KS5cbiAqICAgLSBPbmUgb2YgbGVnYWN5LmVudGl0aWVzLnVybHMgaGFzIGFuIGV4cGFuZGVkX3VybCBsaWtlXG4gKiAgICAgXCIuLi4vaS93ZWIvc3RhdHVzLzxpZD5cIiAgXHUyMTkyICB0cnVuY2F0ZWQuXG4gKiAgIC0gT3RoZXJ3aXNlIFx1MjE5MiBub3QgdHJ1bmNhdGVkLlxuICpcbiAqIFRoZSBwcmV2aW91cyBmYWxsYmFjayAoXCJ0cmFpbGluZyB0LmNvIFVSTCArIGxlbmd0aCBcdTIyNjUgMjcwXCIpIGZsYWdnZWQgZXZlcnlcbiAqIG1lZGlhIHR3ZWV0IGV4YWN0bHkgYXQgdGhlIDI4MC1jaGFyIGxpbWl0LiBXZSBkcm9wIGl0IGVudGlyZWx5OyB0aGUgb25seVxuICogY29zdCBpcyBtaXNzaW5nIGdlbnVpbmVseS10cnVuY2F0ZWQgdHdlZXRzIHdob3NlIHBheWxvYWQgd2FzIHNvIGRlZ3JhZGVkXG4gKiBpdCBsYWNrZWQgZW50aXRpZXMgXHUyMDE0IHdoaWNoIGlzIGFsc28gd2hlcmUgdGhlIHJlZmV0Y2ggbG9vcCB3b3VsZCBmYWlsXG4gKiBhbnl3YXksIHNvIG5vdGhpbmcgaXMgYWN0dWFsbHkgbG9zdC5cbiAqL1xuZnVuY3Rpb24gZGV0ZWN0VHJ1bmNhdGlvbihcbiAgbm90ZVR3ZWV0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gIGZ1bGxUZXh0OiBzdHJpbmdcbik6IGJvb2xlYW4ge1xuICBpZiAobm90ZVR3ZWV0KSByZXR1cm4gZmFsc2U7XG4gIGlmICghZnVsbFRleHQpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKTtcbiAgY29uc3QgdXJscyA9IGVudGl0aWVzID8gZW50aXRpZXMudXJscyA6IG51bGw7XG4gIGlmIChBcnJheS5pc0FycmF5KHVybHMpKSB7XG4gICAgZm9yIChjb25zdCB1IG9mIHVybHMpIHtcbiAgICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XG4gICAgICBjb25zdCBleHAgPSAodSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuZXhwYW5kZWRfdXJsO1xuICAgICAgLy8gVGhlIFwiU2hvdyBtb3JlXCIgbGluayBleHBhbmRzIHRvIGVpdGhlciBvZiB0aGVzZSBzZWxmLXBlcm1hbGlua1xuICAgICAgLy8gc2hhcGVzOiAgaHR0cHM6Ly94LmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxuICAgICAgLy8gICAgICAgICAgaHR0cHM6Ly90d2l0dGVyLmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxuICAgICAgaWYgKHR5cGVvZiBleHAgPT09ICdzdHJpbmcnICYmIC9cXC9pXFwvd2ViXFwvc3RhdHVzXFwvXFxkKy8udGVzdChleHApKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbi8qKlxuICogRmlsdGVyIGB0d2VldHNgIGRvd24gdG8gdGhvc2UgcmVsYXRlZCB0byBhIHRyYWNrZWQgYWNjb3VudC4gQSB0d2VldCBpc1xuICogXCJyZWxhdGVkXCIgaWYgYW55IG9mIHRoZSBmb2xsb3dpbmcgaG9sZDpcbiAqXG4gKiAgIC0gaXRzIGF1dGhvciBpcyB0cmFja2VkIChoYW5kbGUgaW4gYHRhcmdldGVkYCksXG4gKiAgIC0gaXQgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZSxcbiAqICAgLSBpdCByZXBsaWVzIHRvIGEgdHJhY2tlZCBhY2NvdW50LFxuICogICAtIGl0IHF1b3Rlcy9yZXR3ZWV0cy9yZXBsaWVzLXRvIGEgdHdlZXQgdGhhdCdzIGFsc28gcHJlc2VudCBpbiB0aGVcbiAqICAgICBiYXRjaCAqYW5kKiBhdXRob3JlZCBieSBhIHRyYWNrZWQgYWNjb3VudCAodHJhbnNpdGl2ZWx5IHJlbGF0ZWQgXHUyMDE0XG4gKiAgICAgY2FwdHVyZXMgdGhlIHF1b3RlZC9SVCdkIGNvbnRlbnQgdGhhdCBhcHBlYXJzIGFzIGEgc2libGluZyBub2RlIGluXG4gKiAgICAgdGhlIHNhbWUgR3JhcGhRTCByZXNwb25zZSkuXG4gKlxuICogQW55dGhpbmcgZWxzZSAocmFuZG9tIHJlcGxpZXMgdW5kZXIgYSB0cmFja2VkIGFjY291bnQncyB0d2VldCwgcmFuZG9tXG4gKiBhdXRob3JzIHRoYXQgaGFwcGVuIHRvIHN1cmZhY2UgaW4gYSB0cmFja2VkIGFjY291bnQncyB0aHJlYWQpIGlzIGRyb3BwZWQuXG4gKiBQYXNzIGFuIGVtcHR5IGB0YXJnZXRlZGAgc2V0IHRvIGRpc2FibGUgZmlsdGVyaW5nIGVudGlyZWx5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyUmVsYXRlZChcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdLFxuICB0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPlxuKTogQ2Fub25pY2FsVHdlZXRbXSB7XG4gIGlmICh0YXJnZXRlZC5zaXplID09PSAwKSByZXR1cm4gdHdlZXRzO1xuICAvLyBGaXJzdCBwYXNzOiB3aGljaCB0d2VldCBJRHMgZG8gdHJhY2tlZC1hdXRob3IgdHdlZXRzIHJlZmVyZW5jZSAodGhlXG4gIC8vIFwiZm9yd2FyZFwiIGRpcmVjdGlvbiBcdTIwMTQgdHJhY2tlZCBhY2NvdW50IHF1b3RlcyAvIFJUcyAvIHJlcGxpZXMgdG8gWCk/XG4gIC8vIEFuZCB3aGljaCB0d2VldCBJRHMgQVJFIHRyYWNrZWQtYXV0aG9yZWQgKHRoZSBcInJldmVyc2VcIiBkaXJlY3Rpb24gXHUyMDE0XG4gIC8vIFggcXVvdGVzIC8gUlRzIC8gcmVwbGllcyB0byBhIHRyYWNrZWQgdHdlZXQpP1xuICBjb25zdCByZWZlcmVuY2VkSWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHRhcmdldGVkVHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgIGlmICghdGFyZ2V0ZWQuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIGNvbnRpbnVlO1xuICAgIHRhcmdldGVkVHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xuICAgIGlmICh0LnF1b3RlZF90d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5xdW90ZWRfdHdlZXRfaWQpO1xuICAgIGlmICh0LnJldHdlZXRlZF90d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpO1xuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnJlcGx5X3RvX3R3ZWV0X2lkKTtcbiAgfVxuICByZXR1cm4gdHdlZXRzLmZpbHRlcigodCkgPT4ge1xuICAgIGNvbnN0IGggPSB0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKHRhcmdldGVkLmhhcyhoKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gRm9yd2FyZDogYSB0cmFja2VkLWF1dGhvciB0d2VldCBwb2ludGVkIGF0IHRoaXMgb25lLlxuICAgIGlmIChyZWZlcmVuY2VkSWRzLmhhcyh0LnR3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gUmV2ZXJzZTogdGhpcyB0d2VldCBwb2ludHMgYXQgYSB0cmFja2VkLWF1dGhvciB0d2VldCBpbiB0aGUgYmF0Y2guXG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucXVvdGVkX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKHQucmV0d2VldGVkX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucmV0d2VldGVkX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKHQucmVwbHlfdG9fdHdlZXRfaWQgJiYgdGFyZ2V0ZWRUd2VldElkcy5oYXModC5yZXBseV90b190d2VldF9pZCkpIHJldHVybiB0cnVlO1xuICAgIC8vIFJlcGx5LXRvLWFjY291bnQgb3IgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZS5cbiAgICBpZiAodC5yZXBseV90b19hY2NvdW50ICYmIHRhcmdldGVkLmhhcyh0LnJlcGx5X3RvX2FjY291bnQudG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xuICAgIGZvciAoY29uc3QgbSBvZiB0Lm1lbnRpb25zKSB7XG4gICAgICBpZiAodGFyZ2V0ZWQuaGFzKG0udG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH0pO1xufVxuXG4vKipcbiAqIFB1bGwgdGhlIENvbW11bml0eSBOb3RlIChmb3JtZXJseSBCaXJkd2F0Y2gpIGJsb2NrIGF0dGFjaGVkIHRvIGEgdHdlZXQsIGlmXG4gKiBhbnkuIFRoZSBwaXZvdCBjYW4gbGl2ZSBhdCBgdHdlZXQubGVnYWN5LmJpcmR3YXRjaF9waXZvdGAgKG9sZGVyIHNoYXBlKSBvclxuICogYHR3ZWV0LmJpcmR3YXRjaF9waXZvdGAgKGN1cnJlbnQgc2hhcGUpLiBUaGUgc3VtbWFyeSB0ZXh0IGlzIHdoYXQgcmVhZGVyc1xuICogYWN0dWFsbHkgc2VlOyB3ZSBrZWVwIHRoZSBzdXJyb3VuZGluZyBtZXRhZGF0YSBzbyBkb3duc3RyZWFtIHRvb2xpbmcgY2FuXG4gKiB0ZWxsIGRyYWZ0cyBhcGFydCBmcm9tIHJhdGVkLWhlbHBmdWwgbm90ZXMuXG4gKi9cbmZ1bmN0aW9uIGV4dHJhY3RDb21tdW5pdHlOb3RlKFxuICB0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAgb2JzZXJ2ZWRBdDogc3RyaW5nXG4pOiBDb21tdW5pdHlOb3RlIHwgbnVsbCB7XG4gIGNvbnN0IHBpdm90ID0gb2JqKHQuYmlyZHdhdGNoX3Bpdm90KSA/PyBvYmoobGVnYWN5LmJpcmR3YXRjaF9waXZvdCk7XG4gIGlmICghcGl2b3QpIHJldHVybiBudWxsO1xuICBjb25zdCBzdWJ0aXRsZSA9IG9iaihwaXZvdC5zdWJ0aXRsZSk7XG4gIGNvbnN0IG5vdGUgPSBvYmoocGl2b3Qubm90ZSk7XG4gIGNvbnN0IHN1bW1hcnkgPSBzdHJPck51bGwoc3VidGl0bGU/LnRleHQpO1xuICBjb25zdCB0aXRsZSA9IHN0ck9yTnVsbChwaXZvdC50aXRsZSk7XG4gIGNvbnN0IHNob3J0VGl0bGUgPSBzdHJPck51bGwocGl2b3Quc2hvcnRUaXRsZSk7XG4gIGNvbnN0IGRlc3RpbmF0aW9uVXJsID0gc3RyT3JOdWxsKHBpdm90LmRlc3RpbmF0aW9uVXJsKTtcbiAgY29uc3Qgbm90ZUlkID0gc3RyT3JOdWxsKHBpdm90Lm5vdGVJZCkgPz8gc3RyT3JOdWxsKG5vdGU/LnJlc3RfaWQpO1xuICAvLyBTa2lwIGVtcHR5IHNoZWxscyB0aGF0IGhhdmUgbm8gYWN0dWFsIGNvbnRlbnQuXG4gIGlmICghc3VtbWFyeSAmJiAhdGl0bGUgJiYgIW5vdGVJZCkgcmV0dXJuIG51bGw7XG4gIHJldHVybiB7XG4gICAgbm90ZV9pZDogbm90ZUlkLFxuICAgIHRpdGxlLFxuICAgIHNob3J0X3RpdGxlOiBzaG9ydFRpdGxlLFxuICAgIHN1bW1hcnksXG4gICAgZGVzdGluYXRpb25fdXJsOiBkZXN0aW5hdGlvblVybCxcbiAgICBvYnNlcnZlZF9hdDogb2JzZXJ2ZWRBdCxcbiAgfTtcbn1cblxuLyoqXG4gKiBQdWxsIGEgcGVyLWF1dGhvciBVc2VyU25hcHNob3QgZnJvbSB0aGUgdHdlZXQncyB1c2VyX3Jlc3VsdHMgbm9kZS4gRXZlcnlcbiAqIGZpZWxkIGRlZmF1bHRzIHRvIG51bGwgd2hlbiBtaXNzaW5nIHNvIHRoZSBzY2hlbWEgc3RheXMgc3RhYmxlIGFjcm9zc1xuICogdGhlIGxlZ2FjeSAvIGNvcmUgc2hhcGUgbWlncmF0aW9ucyBYIGhhcyBiZWVuIGRvaW5nLlxuICovXG5mdW5jdGlvbiBleHRyYWN0VXNlclNuYXBzaG90KFxuICB1c2VyUmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIHVzZXJDb3JlTmV3OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIHVzZXJMZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgdXNlckF2YXRhck9iajogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsXG4pOiBVc2VyU25hcHNob3Qge1xuICBjb25zdCB2ZXJpZmljYXRpb24gPSBvYmoodXNlclJlc3VsdD8udmVyaWZpY2F0aW9uKTtcbiAgcmV0dXJuIHtcbiAgICBkaXNwbGF5X25hbWU6XG4gICAgICBzdHJPck51bGwodXNlckNvcmVOZXc/Lm5hbWUpID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5uYW1lKSA/PyBzdHJPck51bGwodXNlclJlc3VsdD8ubmFtZSksXG4gICAgYXZhdGFyX3VybDpcbiAgICAgIHN0ck9yTnVsbCh1c2VyQXZhdGFyT2JqPy5pbWFnZV91cmwpID8/XG4gICAgICBzdHJPck51bGwodXNlckxlZ2FjeT8ucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMpID8/XG4gICAgICBzdHJPck51bGwodXNlclJlc3VsdD8ucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMpLFxuICAgIHZlcmlmaWVkOiBib29sT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWQpID8/IGJvb2xPck51bGwodXNlckxlZ2FjeT8udmVyaWZpZWQpLFxuICAgIGlzX2JsdWVfdmVyaWZpZWQ6IGJvb2xPck51bGwodXNlclJlc3VsdD8uaXNfYmx1ZV92ZXJpZmllZCksXG4gICAgdmVyaWZpZWRfdHlwZTogc3RyT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWRfdHlwZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnZlcmlmaWVkX3R5cGUpLFxuICAgIGRlc2NyaXB0aW9uOiBzdHJPck51bGwodXNlckxlZ2FjeT8uZGVzY3JpcHRpb24pLFxuICAgIGxvY2F0aW9uOiBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmxvY2F0aW9uKT8ubG9jYXRpb24pID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5sb2NhdGlvbiksXG4gICAgdXJsOiBzdHJPck51bGwodXNlckxlZ2FjeT8udXJsKSxcbiAgICBmb2xsb3dlcnNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5mb2xsb3dlcnNfY291bnQpLFxuICAgIGZyaWVuZHNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5mcmllbmRzX2NvdW50KSxcbiAgICBzdGF0dXNlc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LnN0YXR1c2VzX2NvdW50KSxcbiAgICBhY2NvdW50X2NyZWF0ZWRfYXQ6XG4gICAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8uY3JlYXRlZF9hdCkpID8/XG4gICAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5jcmVhdGVkX2F0KSksXG4gICAgcHJvdGVjdGVkOiBib29sT3JOdWxsKHVzZXJMZWdhY3k/LnByb3RlY3RlZCksXG4gIH07XG59XG5cbi8qKlxuICogV2FsayB0aGUgdHdlZXQncyBgY2FyZC5sZWdhY3kuYmluZGluZ192YWx1ZXNgIChrZXkvdmFsdWUgYXJyYXkpIGludG8gYVxuICogZmxhdCBUd2VldENhcmQgd2l0aCB0aXRsZSwgZGVzY3JpcHRpb24sIGFuZCBhIHJlcHJlc2VudGF0aXZlIGltYWdlIFVSTC5cbiAqIFJldHVybnMgbnVsbCB3aGVuIHRoZSB0d2VldCBoYXMgbm8gY2FyZC5cbiAqL1xuZnVuY3Rpb24gZXh0cmFjdENhcmQodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldENhcmQgfCBudWxsIHtcbiAgY29uc3QgY2FyZCA9IG9iaih0LmNhcmQpO1xuICBjb25zdCBjYXJkTGVnYWN5ID0gb2JqKGNhcmQ/LmxlZ2FjeSk7XG4gIGlmICghY2FyZExlZ2FjeSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGJpbmRpbmdzID0gY2FyZExlZ2FjeS5iaW5kaW5nX3ZhbHVlcztcbiAgY29uc3QgYnlLZXk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XG4gIGlmIChBcnJheS5pc0FycmF5KGJpbmRpbmdzKSkge1xuICAgIGZvciAoY29uc3QgYnYgb2YgYmluZGluZ3MpIHtcbiAgICAgIGlmICh0eXBlb2YgYnYgIT09ICdvYmplY3QnIHx8IGJ2ID09PSBudWxsKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IG8gPSBidiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGNvbnN0IGsgPSBzdHJPck51bGwoby5rZXkpO1xuICAgICAgY29uc3QgdiA9IG9iaihvLnZhbHVlKTtcbiAgICAgIGlmICghayB8fCAhdikgY29udGludWU7XG4gICAgICBieUtleVtrXSA9XG4gICAgICAgIHN0ck9yTnVsbCh2LnN0cmluZ192YWx1ZSkgPz9cbiAgICAgICAgc3RyT3JOdWxsKG9iaih2LmltYWdlX3ZhbHVlKT8udXJsKSA/P1xuICAgICAgICBzdHJPck51bGwob2JqKHYuaW1hZ2VfY29sb3JfdmFsdWUpPy5wYWxldHRlKTtcbiAgICB9XG4gIH1cbiAgY29uc3QgbmFtZSA9IHN0ck9yTnVsbChjYXJkTGVnYWN5Lm5hbWUpO1xuICBjb25zdCBjYXJkVXJsID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kudXJsKTtcbiAgY29uc3QgdmVuZG9yVXJsID1cbiAgICB0eXBlb2YgYnlLZXlbJ3Zhbml0eV91cmwnXSA9PT0gJ3N0cmluZycgPyAoYnlLZXlbJ3Zhbml0eV91cmwnXSBhcyBzdHJpbmcpIDogbnVsbDtcbiAgY29uc3QgdGl0bGUgPSB0eXBlb2YgYnlLZXlbJ3RpdGxlJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5Wyd0aXRsZSddIGFzIHN0cmluZykgOiBudWxsO1xuICBjb25zdCBkZXNjcmlwdGlvbiA9XG4gICAgdHlwZW9mIGJ5S2V5WydkZXNjcmlwdGlvbiddID09PSAnc3RyaW5nJyA/IChieUtleVsnZGVzY3JpcHRpb24nXSBhcyBzdHJpbmcpIDogbnVsbDtcbiAgY29uc3QgaW1hZ2VVcmwgPVxuICAgICh0eXBlb2YgYnlLZXlbJ3Bob3RvX2ltYWdlX2Z1bGxfc2l6ZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xuICAgICAgPyAoYnlLZXlbJ3Bob3RvX2ltYWdlX2Z1bGxfc2l6ZV9vcmlnaW5hbCddIGFzIHN0cmluZylcbiAgICAgIDogbnVsbCkgPz9cbiAgICAodHlwZW9mIGJ5S2V5Wyd0aHVtYm5haWxfaW1hZ2Vfb3JpZ2luYWwnXSA9PT0gJ3N0cmluZydcbiAgICAgID8gKGJ5S2V5Wyd0aHVtYm5haWxfaW1hZ2Vfb3JpZ2luYWwnXSBhcyBzdHJpbmcpXG4gICAgICA6IG51bGwpID8/XG4gICAgKHR5cGVvZiBieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xuICAgICAgPyAoYnlLZXlbJ3N1bW1hcnlfcGhvdG9faW1hZ2Vfb3JpZ2luYWwnXSBhcyBzdHJpbmcpXG4gICAgICA6IG51bGwpO1xuICBpZiAoIW5hbWUgJiYgIXRpdGxlICYmICFkZXNjcmlwdGlvbiAmJiAhaW1hZ2VVcmwpIHJldHVybiBudWxsO1xuICByZXR1cm4ge1xuICAgIG5hbWUsXG4gICAgY2FyZF91cmw6IGNhcmRVcmwsXG4gICAgdmVuZG9yX3VybDogdmVuZG9yVXJsLFxuICAgIHRpdGxlLFxuICAgIGRlc2NyaXB0aW9uLFxuICAgIGltYWdlX3VybDogaW1hZ2VVcmwsXG4gIH07XG59XG4iLCAiLyoqXG4gKiBMaWdodHdlaWdodCBVTElELWxpa2UgaWQgZ2VuZXJhdG9yOiAyNi1jaGFyYWN0ZXIgQ3JvY2tmb3JkIGJhc2UzMiBzdHJpbmdcbiAqIG9mICh0aW1lc3RhbXBfbXMgfHwgcmFuZG9tbmVzcykuIEdvb2QgZW5vdWdoIGZvciBydW4gaWRlbnRpZmllcnMgd2l0aG91dFxuICogcHVsbGluZyBpbiBhIHJlYWwgVUxJRCBkZXBlbmRlbmN5LlxuICovXG5cbmNvbnN0IEFMUEhBQkVUID0gJzAxMjM0NTY3ODlBQkNERUZHSEpLTU5QUVJTVFZXWFlaJzsgLy8gQ3JvY2tmb3JkXG5cbmV4cG9ydCBmdW5jdGlvbiBuZXdSdW5JZCgpOiBzdHJpbmcge1xuICBjb25zdCB0cyA9IERhdGUubm93KCk7XG4gIGxldCB0c1BhcnQgPSAnJztcbiAgbGV0IHQgPSB0cztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDsgaSsrKSB7XG4gICAgdHNQYXJ0ID0gKEFMUEhBQkVUW3QgJSAzMl0gPz8gJzAnKSArIHRzUGFydDtcbiAgICB0ID0gTWF0aC5mbG9vcih0IC8gMzIpO1xuICB9XG4gIGNvbnN0IHJhbmQgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEwKSk7XG4gIGxldCByYW5kUGFydCA9ICcnO1xuICBmb3IgKGNvbnN0IGIgb2YgcmFuZCkgcmFuZFBhcnQgKz0gQUxQSEFCRVRbYiAlIDMyXSA/PyAnMCc7XG4gIHJldHVybiB0c1BhcnQgKyByYW5kUGFydDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNob3J0UnVuSWQoaWQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBpZC5zbGljZSgtOCk7XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q2F0ZWdvcnksIEFjY291bnRDb25maWcgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBNaW5pbWFsIHBhcnNlciBmb3IgdGhlIHN0cmljdCBzaGFwZSB1c2VkIGJ5IGBjb25maWcvYWNjb3VudHMueWFtbGA6XG4gKlxuICogICBhY2NvdW50czpcbiAqICAgICAtIGhhbmRsZTogREhTZ292XG4gKiAgICAgICBsYWJlbDogRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eVxuICogICAgICAgY2F0ZWdvcnk6IGNvcmVcbiAqXG4gKiBXZSBkZWxpYmVyYXRlbHkgZG9uJ3QgcHVsbCBpbiBhIGZ1bGwgWUFNTCBsaWJyYXJ5IFx1MjAxNCB3ZSBjb250cm9sIGJvdGggZW5kcyBvZlxuICogdGhpcyBmaWxlLCBhbmQgYSBzbWFsbCBwYXJzZXIgaXMgZWFzaWVyIHRvIGF1ZGl0IHRoYW4gdGhlIGFsdGVybmF0aXZlcy5cbiAqIFVua25vd24ga2V5cyBhbmQgY29tbWVudHMgYXJlIHRvbGVyYXRlZDsgbWFsZm9ybWVkIGxpbmVzIGFyZSBza2lwcGVkLlxuICpcbiAqIEVudHJpZXMgbWlzc2luZyBhIGBjYXRlZ29yeWAgZGVmYXVsdCB0byBgY29yZWAgZm9yIGJhY2t3YXJkIGNvbXBhdGliaWxpdHlcbiAqIHdpdGggdGhlIHByZS1jYXRlZ29yaXphdGlvbiBmaWxlIHNoYXBlLlxuICovXG5jb25zdCBWQUxJRF9DQVRFR09SSUVTOiBSZWFkb25seVNldDxBY2NvdW50Q2F0ZWdvcnk+ID0gbmV3IFNldChbXG4gICdjb3JlJyxcbiAgJ2dvdmVybm1lbnQnLFxuICAnb2ZmaWNpYWxzJyxcbiAgJ3B1YmxpY19maWd1cmVzJyxcbiAgJ3B1YmxpYycsXG5dKTtcblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQWNjb3VudHNZYW1sKHRleHQ6IHN0cmluZyk6IEFjY291bnRDb25maWdbXSB7XG4gIGNvbnN0IGFjY291bnRzOiBBY2NvdW50Q29uZmlnW10gPSBbXTtcbiAgbGV0IGN1cnJlbnQ6IFBhcnRpYWw8QWNjb3VudENvbmZpZz4gPSB7fTtcbiAgbGV0IGluQWNjb3VudHMgPSBmYWxzZTtcbiAgY29uc3QgZmx1c2ggPSAoKSA9PiB7XG4gICAgaWYgKGN1cnJlbnQuaGFuZGxlICYmIGN1cnJlbnQubGFiZWwpIHtcbiAgICAgIGlmICghY3VycmVudC5jYXRlZ29yeSkgY3VycmVudC5jYXRlZ29yeSA9ICdjb3JlJztcbiAgICAgIGFjY291bnRzLnB1c2goY3VycmVudCBhcyBBY2NvdW50Q29uZmlnKTtcbiAgICB9XG4gIH07XG4gIGZvciAoY29uc3QgcmF3TGluZSBvZiB0ZXh0LnNwbGl0KCdcXG4nKSkge1xuICAgIGNvbnN0IGxpbmUgPSBzdHJpcENvbW1lbnRzKHJhd0xpbmUpO1xuICAgIGlmIChsaW5lLnRyaW0oKSA9PT0gJycpIGNvbnRpbnVlO1xuICAgIGlmICgvXmFjY291bnRzXFxzKjovLnRlc3QobGluZSkpIHtcbiAgICAgIGluQWNjb3VudHMgPSB0cnVlO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICghaW5BY2NvdW50cykgY29udGludWU7XG5cbiAgICBjb25zdCBpdGVtTWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKi1cXHMqaGFuZGxlXFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoaXRlbU1hdGNoKSB7XG4gICAgICBmbHVzaCgpO1xuICAgICAgY3VycmVudCA9IHsgaGFuZGxlOiB1bnF1b3RlKGl0ZW1NYXRjaFsxXSA/PyAnJykgfTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBoYW5kbGVPbmx5ID0gbGluZS5tYXRjaCgvXlxccypoYW5kbGVcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChoYW5kbGVPbmx5ICYmICFsaW5lLmluY2x1ZGVzKCctJykpIHtcbiAgICAgIGZsdXNoKCk7XG4gICAgICBjdXJyZW50ID0geyBoYW5kbGU6IHVucXVvdGUoaGFuZGxlT25seVsxXSA/PyAnJykgfTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBsYWJlbE1hdGNoID0gbGluZS5tYXRjaCgvXlxccypsYWJlbFxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGxhYmVsTWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcbiAgICAgIGN1cnJlbnQubGFiZWwgPSB1bnF1b3RlKGxhYmVsTWF0Y2hbMV0gPz8gJycpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGNvbnN0IGNhdGVnb3J5TWF0Y2ggPSBsaW5lLm1hdGNoKC9eXFxzKmNhdGVnb3J5XFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoY2F0ZWdvcnlNYXRjaCAmJiBjdXJyZW50LmhhbmRsZSkge1xuICAgICAgY29uc3QgcmF3ID0gdW5xdW90ZShjYXRlZ29yeU1hdGNoWzFdID8/ICcnKTtcbiAgICAgIGN1cnJlbnQuY2F0ZWdvcnkgPSBWQUxJRF9DQVRFR09SSUVTLmhhcyhyYXcgYXMgQWNjb3VudENhdGVnb3J5KVxuICAgICAgICA/IChyYXcgYXMgQWNjb3VudENhdGVnb3J5KVxuICAgICAgICA6ICdjb3JlJztcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgfVxuICBmbHVzaCgpO1xuICByZXR1cm4gYWNjb3VudHMuZmlsdGVyKChhKSA9PiBhLmhhbmRsZS5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gc3RyaXBDb21tZW50cyhsaW5lOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBOYWl2ZSBidXQgYWRlcXVhdGUgZm9yIG91ciBmb3JtYXQ6IHN0cmlwIGV2ZXJ5dGhpbmcgYWZ0ZXIgYSBgI2AgdGhhdCBpc24ndFxuICAvLyBpbnNpZGUgcXVvdGVzLiBPdXIgY29uZmlnIG5ldmVyIHVzZXMgaW5saW5lIHN0cmluZ3Mgd2l0aCBgI2AuXG4gIGNvbnN0IGlkeCA9IGxpbmUuaW5kZXhPZignIycpO1xuICByZXR1cm4gaWR4ID09PSAtMSA/IGxpbmUgOiBsaW5lLnNsaWNlKDAsIGlkeCk7XG59XG5cbmZ1bmN0aW9uIHVucXVvdGUoczogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgdHJpbW1lZCA9IHMudHJpbSgpO1xuICBpZiAoXG4gICAgKHRyaW1tZWQuc3RhcnRzV2l0aCgnXCInKSAmJiB0cmltbWVkLmVuZHNXaXRoKCdcIicpKSB8fFxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoXCInXCIpICYmIHRyaW1tZWQuZW5kc1dpdGgoXCInXCIpKVxuICApIHtcbiAgICByZXR1cm4gdHJpbW1lZC5zbGljZSgxLCAtMSk7XG4gIH1cbiAgcmV0dXJuIHRyaW1tZWQ7XG59XG4iLCAiLyoqXG4gKiBiYWNrZ3JvdW5kLnRzIFx1MjAxNCBleHRlbnNpb24gc2VydmljZSB3b3JrZXIuXG4gKlxuICogT3ducyB0aGUgY2FwdHVyZSBwaXBlbGluZTogcmVjZWl2ZXMgYGdyYXBocWwtY2FwdHVyZWAgbWVzc2FnZXMgZnJvbSB0aGVcbiAqIGNvbnRlbnQgc2NyaXB0LCBub3JtYWxpemVzIHRoZW0sIGFjY3VtdWxhdGVzIHBlci1oYW5kbGUgcnVuIGJ1ZmZlcnMgaW5cbiAqIGBicm93c2VyLnN0b3JhZ2UubG9jYWxgLCBhbmQgY29tbWl0cyB0aGVtIHRvIHRoZSBjb25maWd1cmVkIEdpdEh1YiByZXBvXG4gKiB2aWEgdGhlIENvbnRlbnRzIEFQSS5cbiAqXG4gKiBTZXJ2aWNlIHdvcmtlcnMgaW4gTVYzIG1heSBiZSBldmljdGVkIGF0IGFueSB0aW1lLCBzbyBhbGwgY3JpdGljYWwgc3RhdGVcbiAqIGxpdmVzIGluIHN0b3JhZ2UgKG5ldmVyIG1vZHVsZS1zY29wZSkuIE9uIGV2ZXJ5IHdha2Ugd2UgcmUtZGVyaXZlIHdoYXQgd2VcbiAqIG5lZWQ7IHBlbmRpbmcgZmx1c2hlcyBhcmUgZHJpdmVuIGJ5IGBicm93c2VyLmFsYXJtc2AgcmF0aGVyIHRoYW4gdGltZXJzLlxuICovXG5cbmltcG9ydCB7XG4gIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gIEFVVE9fU0NST0xMX01JTl9TRUMsXG4gIEZBTExCQUNLX0FDQ09VTlRTLFxuICBGTFVTSF9BTEFSTV9NSU5VVEVTLFxuICBGTFVTSF9JRExFX01TLFxuICBGTFVTSF9UV0VFVF9USFJFU0hPTEQsXG4gIFBST0ZJTEVfRU5EUE9JTlRTLFxuICBUV0VFVF9FTkRQT0lOVFMsXG4gIFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TLFxufSBmcm9tICcuL2xpYi9jb25maWcuanMnO1xuaW1wb3J0IHsgR2l0SHViQ2xpZW50LCBHaXRIdWJFcnJvciwgdG9CYXNlNjQgfSBmcm9tICcuL2xpYi9naXRodWIuanMnO1xuaW1wb3J0IHsgZGVzY3JpYmVFcnJvciwgZXJyb3IgYXMgbG9nRXJyLCBpbmZvLCBzZXRCcm9hZGNhc3Rlciwgd2FybiB9IGZyb20gJy4vbGliL2xvZ2dlci5qcyc7XG5pbXBvcnQgeyBmaWx0ZXJSZWxhdGVkLCBub3JtYWxpemUgfSBmcm9tICcuL2xpYi9ub3JtYWxpemUuanMnO1xuaW1wb3J0IHsgbmV3UnVuSWQsIHNob3J0UnVuSWQgfSBmcm9tICcuL2xpYi9ydW5pZHMuanMnO1xuaW1wb3J0IHtcbiAgYnVtcENvdW50ZXIsXG4gIGNsZWFyQWN0aXZpdHksXG4gIGNsZWFyQWxsLFxuICBjbGVhclJ1bkJ1ZmZlcixcbiAgZGVxdWV1ZU1lZGlhQ3Jhd2wsXG4gIGRlcXVldWVSZWZldGNoLFxuICBlbmdhZ2VtZW50U2lnLFxuICBlbnF1ZXVlTWVkaWFDcmF3bCxcbiAgZW5xdWV1ZVJlZmV0Y2gsXG4gIGdldEFjY291bnRzLFxuICBnZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxuICBnZXRBY3Rpdml0eSxcbiAgZ2V0QXV0b1Njcm9sbFNlc3Npb24sXG4gIGdldENvbW1pdHRlZEluZGV4LFxuICBnZXRDb25uZWN0aW9uLFxuICBnZXRDb3VudGVycyxcbiAgZ2V0TWVkaWFDcmF3bFF1ZXVlLFxuICBnZXRNZWRpYUNyYXdsU2Vzc2lvbixcbiAgZ2V0UmVmZXRjaFF1ZXVlLFxuICBnZXRSZWZldGNoU2Vzc2lvbixcbiAgZ2V0UnVuQnVmZmVyLFxuICBnZXRSdW5CdWZmZXJzLFxuICBnZXRTZXR0aW5ncyxcbiAgaXNDb21taXR0ZWQsXG4gIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsLFxuICBuZXh0TWVkaWFDcmF3bFRhcmdldCxcbiAgbmV4dFJlZmV0Y2hUYXJnZXQsXG4gIHBydW5lQ29tbWl0dGVkSW5kZXgsXG4gIHB1cmdlVW5yZWxhdGVkU3RhdGUsXG4gIHJlZmV0Y2hRdWV1ZVRvdGFsLFxuICBzZXRBY2NvdW50cyxcbiAgc2V0QWNjb3VudHNSZWZyZXNoZWRBdCxcbiAgc2V0QXV0b1Njcm9sbFNlc3Npb24sXG4gIHNldEJ1ZmZlcmVkQ291bnQsXG4gIHNldENvbW1pdHRlZEluZGV4LFxuICBzZXRDb25uZWN0aW9uLFxuICBzZXRNZWRpYUNyYXdsU2Vzc2lvbixcbiAgc2V0UmVmZXRjaFNlc3Npb24sXG4gIHNldFJ1bkJ1ZmZlcixcbiAgdHlwZSBSdW5CdWZmZXIsXG4gIHVwZGF0ZVNldHRpbmdzLFxufSBmcm9tICcuL2xpYi9zdG9yYWdlLmpzJztcbmltcG9ydCB0eXBlIHtcbiAgQ2Fub25pY2FsVHdlZXQsXG4gIENhcHR1cmVQYXlsb2FkLFxuICBDb25uZWN0aW9uU3RhdGUsXG4gIEV4dGVuc2lvblN0YXRlLFxuICBMb2dFdmVudCxcbiAgUXVhcmFudGluZVBheWxvYWQsXG4gIFJ1bnRpbWVNZXNzYWdlLFxuICBTZWVuUGF5bG9hZCxcbiAgU2V0dGluZ3MsXG59IGZyb20gJy4vbGliL3R5cGVzLmpzJztcbmltcG9ydCB7IHBhcnNlQWNjb3VudHNZYW1sIH0gZnJvbSAnLi9saWIveWFtbC5qcyc7XG5cbmNvbnN0IEVYVF9WRVJTSU9OID0gYnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbjtcblxuc2V0QnJvYWRjYXN0ZXIoKGV2OiBMb2dFdmVudCkgPT4ge1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnbG9nLWV2ZW50JywgZXZlbnQ6IGV2IH0pLmNhdGNoKCgpID0+IHt9KTtcbn0pO1xuXG4vLyAtLS0gV2FrZSBoYW5kbGVycyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5icm93c2VyLnJ1bnRpbWUub25JbnN0YWxsZWQuYWRkTGlzdGVuZXIoYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBpbmZvKCdleHRlbnNpb24gaW5zdGFsbGVkJywgeyB2ZXJzaW9uOiBFWFRfVkVSU0lPTiB9KTtcbiAgYXdhaXQgb25XYWtlKCdpbnN0YWxsJyk7XG59KTtcblxuYnJvd3Nlci5ydW50aW1lLm9uU3RhcnR1cC5hZGRMaXN0ZW5lcigoKSA9PiB7XG4gIHZvaWQgb25XYWtlKCdzdGFydHVwJyk7XG59KTtcblxuLy8gRm9yY2UgYXQgbGVhc3Qgb25lIHdha2UgdG8gcmVnaXN0ZXIgYWxhcm1zIC8gdmVyaWZ5IGNvbm5lY3Rpb24uXG52b2lkIG9uV2FrZSgnbW9kdWxlLWxvYWQnKTtcblxuYXN5bmMgZnVuY3Rpb24gb25XYWtlKHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgYXdhaXQgZW5zdXJlQWxhcm1zKCk7XG4gICAgYXdhaXQgZW5zdXJlQXV0b1Njcm9sbEFsYXJtKCk7XG4gICAgYXdhaXQgZmx1c2hPcnBoYW5lZEJ1ZmZlcnNJZlN0YWxlKCk7XG4gICAgYXdhaXQgcmVpbmplY3RJbnRvT3BlblRhYnMoKTtcbiAgICAvLyBEcm9wIGRlZHVwLWluZGV4IGVudHJpZXMgb2xkZXIgdGhhbiAzMCBkYXlzIHNvIHRoZSBzdG9yZSBkb2Vzbid0XG4gICAgLy8gZ3JvdyB1bmJvdW5kZWQgb3ZlciBtb250aHMgb2YgY2FwdHVyZSBzZXNzaW9ucy5cbiAgICBjb25zdCBwcnVuZWQgPSBhd2FpdCBwcnVuZUNvbW1pdHRlZEluZGV4KDMwICogMjQgKiA2MCAqIDYwICogMTAwMCk7XG4gICAgaWYgKHBydW5lZCA+IDApIGF3YWl0IGluZm8oJ3BydW5lZCBjb21taXR0ZWQgaW5kZXgnLCB7IHBydW5lZCB9KTtcbiAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgaWYgKHNldHRpbmdzLnBhdCAmJiBzZXR0aW5ncy5vd25lciAmJiBzZXR0aW5ncy5yZXBvKSB7XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgICAgIGF3YWl0IHJlZnJlc2hBY2NvdW50c0xpc3QoZmFsc2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgICBsb2dpbjogbnVsbCxcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBpbmZvKCdleHRlbnNpb24gYXdha2U7IHNldHRpbmdzIGluY29tcGxldGUnLCB7IHJlYXNvbiB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IGxvZ0Vycignd2FrZSBmYWlsZWQnLCB7IHJlYXNvbiwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICB9XG59XG5cbi8qKlxuICogUmUtaW5qZWN0IHRoZSBNQUlOLXdvcmxkIHBhZ2UtaG9vayArIGlzb2xhdGVkLXdvcmxkIGNvbnRlbnQgc2NyaXB0IGludG9cbiAqIGV2ZXJ5IGFscmVhZHktb3BlbiB4LmNvbSAvIHR3aXR0ZXIuY29tIHRhYi5cbiAqXG4gKiBNYW5pZmVzdCBjb250ZW50X3NjcmlwdHMgb25seSBpbmplY3Qgb24gZnJlc2ggbmF2aWdhdGlvbiAocnVuX2F0OlxuICogZG9jdW1lbnRfc3RhcnQpLiBXaGVuIHRoZSB1c2VyIHJlbG9hZHMgdGhlIGV4dGVuc2lvbiB3aGlsZSBYIHRhYnMgYXJlXG4gKiBvcGVuLCB0aG9zZSB0YWJzIGtlZXAgdGhlaXIgY29udGVudCBzY3JpcHRzIGJ1dCBuZXZlciBnZXQgYSBuZXcgcGFnZS1ob29rXG4gKiBcdTIwMTQgc28gZmV0Y2gvWEhSIHN0YXlzIHVucGF0Y2hlZCBhbmQgY2FwdHVyZXMgc2lsZW50bHkgZmFpbC4gRG9pbmcgdGhpcyBvblxuICogZXZlcnkgd2FrZSBpcyBpZGVtcG90ZW50IChwYWdlLWhvb2sgaGFzIGEgVEFHIGd1YXJkKSBhbmQgY2hlYXAuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIHJlaW5qZWN0SW50b09wZW5UYWJzKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjb3VsZCBub3QgcXVlcnkgb3BlbiB0YWJzJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHRhYnMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcbiAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIGNvbnRpbnVlO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgZmlsZXM6IFsncGFnZS1ob29rLmpzJ10sXG4gICAgICAgIC8vIEZpcmVmb3ggMTI4KyBzdXBwb3J0cyB0aGUgTUFJTiBleGVjdXRpb24gd29ybGQgdmlhIHRoaXMgQVBJLCBidXRcbiAgICAgICAgLy8gdGhlIEB0eXBlcy9maXJlZm94LXdlYmV4dC1icm93c2VyIHBhY2thZ2Ugd2UncmUgb24gc3RpbGwgb25seVxuICAgICAgICAvLyBkZWNsYXJlcyAnSVNPTEFURUQnLiBDYXN0IHRocm91Z2ggdGhlIGxpdGVyYWwgdW5pb24uXG4gICAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICAgIGZpbGVzOiBbJ2NvbnRlbnQuanMnXSxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgaW5mbygncmUtaW5qZWN0ZWQgc2NyaXB0cyBpbnRvIG9wZW4gdGFiJywge1xuICAgICAgICB0YWJJZDogdGFiLmlkLFxuICAgICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCA/PyAnJyksXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIC8vIFNvbWUgdGFicyAoYWJvdXQ6IHBhZ2VzLCBkaXNjYXJkZWQgdGFicywgbWlkLW5hdmlnYXRpb24pIHJlamVjdFxuICAgICAgLy8gZXhlY3V0ZVNjcmlwdC4gVGhhdCdzIGZpbmUgXHUyMDE0IHdlJ2xsIGNhdGNoIHRoZW0gb24gdGhlIG5leHQgd2FrZSBvclxuICAgICAgLy8gd2hlbiB0aGUgdXNlciBuYXZpZ2F0ZXMuXG4gICAgICBhd2FpdCB3YXJuKCdyZS1pbmplY3QgZmFpbGVkIGZvciB0YWI7IGNvbnRpbnVpbmcnLCB7XG4gICAgICAgIHRhYklkOiB0YWIuaWQsXG4gICAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsID8/ICcnKSxcbiAgICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUFsYXJtcygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ2ZsdXNoLXN3ZWVwJyk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd2ZXJpZnktY29ubmVjdGlvbicpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jcmVhdGUoJ2ZsdXNoLXN3ZWVwJywgeyBwZXJpb2RJbk1pbnV0ZXM6IEZMVVNIX0FMQVJNX01JTlVURVMgfSk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgndmVyaWZ5LWNvbm5lY3Rpb24nLCB7XG4gICAgcGVyaW9kSW5NaW51dGVzOiBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyAvIDYwXzAwMCxcbiAgfSk7XG59XG5cbi8vIEZpcmVmb3ggTVYzIGFsYXJtcyBoYXZlIGEgMzBzIG1pbmltdW0gcGVyaW9kLCBidXQgd2Ugd2FudCBzdWItbWludXRlXG4vLyBzY3JvbGxpbmcuIFRoZSBhdXRvLXNjcm9sbCBsb29wIHRoZXJlZm9yZSBydW5zIG9uIGFuIGluLVNXIGludGVydmFsLlxuLy8gYGF1dG9TY3JvbGxTZXNzaW9uYCBpbiBzdG9yYWdlIGlzIHRoZSBzb3VyY2Ugb2YgdHJ1dGggZm9yIHdoZXRoZXIgdGhlIGxvb3Bcbi8vIGlzIG1lYW50IHRvIGJlIHJ1bm5pbmcgXHUyMDE0IHRoZSB0aW1lciBpcyBqdXN0IHRoZSBsb2NhbCBleGVjdXRpb24gYXJtLlxubGV0IGF1dG9TY3JvbGxUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbi8vIFdhaXQtZm9yLWluZ2VzdCB0aW1lb3V0OiBpZiBhIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCB0YWIgbmF2aWdhdGlvbiBkb2Vzbid0XG4vLyBwcm9kdWNlIGFuIGluZ2VzdGVkIGNhcHR1cmUgd2l0aGluIHRoaXMgbWFueSBtcywgYWR2YW5jZSBhbnl3YXkgc28gd2Vcbi8vIGRvbid0IGRlYWRsb2NrIG9uIGRlbGV0ZWQgLyA0MDQgLyBwYXl3YWxsZWQgdHdlZXRzLlxuY29uc3QgSU5HRVNUX1dBSVRfTVMgPSAyNV8wMDA7XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUF1dG9TY3JvbGxBbGFybSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gV2FzIHRoZSBsb29wIHJ1bm5pbmcgYmVmb3JlIHRoZSBTVyBldmljdGlvbj8gUmUtYXJtIGlmIHNvLlxuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmIChzZXNzICE9PSBudWxsICYmIHMuZW5hYmxlZCAhPT0gZmFsc2UpIHtcbiAgICBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xuICB9IGVsc2Uge1xuICAgIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTogdm9pZCB7XG4gIGlmIChhdXRvU2Nyb2xsVGltZXIgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKGF1dG9TY3JvbGxUaW1lcik7XG4gICAgYXV0b1Njcm9sbFRpbWVyID0gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBhcm1BdXRvU2Nyb2xsVGltZXIoaW50ZXJ2YWxTZWM6IG51bWJlcik6IHZvaWQge1xuICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICBjb25zdCBjbGFtcGVkID0gTWF0aC5taW4oXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKGludGVydmFsU2VjKSlcbiAgKTtcbiAgYXV0b1Njcm9sbFRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgYXV0b1Njcm9sbFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ2F1dG8tc2Nyb2xsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICB9KTtcbiAgfSwgY2xhbXBlZCAqIDEwMDApO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydEF1dG9TY3JvbGxMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oe1xuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNjcm9sbENvdW50OiAwLFxuICAgIGluZ2VzdGVkQ291bnQ6IDAsXG4gICAgZXhwYW5kZWRDb3VudDogMCxcbiAgfSk7XG4gIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XG4gIGF3YWl0IGluZm8oJ2F1dG8tc2Nyb2xsIGxvb3Agc3RhcnRlZCcsIHsgaW50ZXJ2YWxfc2VjOiBzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyB9KTtcbiAgLy8gRmlyZSBvbmUgaW1tZWRpYXRlIHRpY2sgc28gdGhlIHVzZXIgc2VlcyBtb3Rpb24gcmlnaHQgYXdheS5cbiAgdm9pZCBhdXRvU2Nyb2xsVGljaygpO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdhdXRvLXNjcm9sbCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBzY3JvbGxzOiBzZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxuICAgIGluZ2VzdGVkOiBzZXNzPy5pbmdlc3RlZENvdW50ID8/IDAsXG4gICAgZXhwYW5kZWQ6IHNlc3M/LmV4cGFuZGVkQ291bnQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGF1dG9TY3JvbGxUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdhdXRvLXNjcm9sbDogdGFiIHF1ZXJ5IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBsZXQgc2Nyb2xsQ291bnQgPSAwO1xuICBsZXQgZXhwYW5kZWRDb3VudCA9IDA7XG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcbiAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIGNvbnRpbnVlO1xuICAgIGlmICh0YWIuZGlzY2FyZGVkKSBjb250aW51ZTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0cyA9IChhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgICAvLyBDYXN0OiB0aGUgQHR5cGVzL2ZpcmVmb3gtd2ViZXh0LWJyb3dzZXIgdHlwZSBzaWduYXR1cmUgaW5zaXN0c1xuICAgICAgICAvLyBgZnVuY2AgcmV0dXJucyB2b2lkLCBidXQgdGhlIEFQSSBhY3R1YWxseSBzdXJmYWNlcyB0aGUgcmV0dXJuXG4gICAgICAgIC8vIHZhbHVlIHZpYSBgcmVzdWx0WzBdLnJlc3VsdGAuIFdlIHVzZSB0aGF0IGZvciB0aGUgZXhwYW5kIGNvdW50LlxuICAgICAgICBmdW5jOiAoKCkgPT4ge1xuICAgICAgICAgIC8vIDEuIENsaWNrIGFueSB2aXNpYmxlIFwiU2hvdyBtb3JlXCIgbGlua3MgaW4gbG9uZy10d2VldCBib2RpZXMgc28gWFxuICAgICAgICAgIC8vICAgIGlubGluZXMgdGhlIG5vdGVfdHdlZXQgYm9keSBhbmQgb3VyIHBhZ2UtaG9vayBjYXB0dXJlcyB0aGVcbiAgICAgICAgICAvLyAgICBmdWxsIHRleHQgd2l0aG91dCB0aGUgcmVmZXRjaCBkZXRvdXIuIFRyeSBzZXZlcmFsIHNlbGVjdG9yc1xuICAgICAgICAgIC8vICAgIGJlY2F1c2UgWCByb3RhdGVzIHRoZSB0ZXN0aWQgbGFiZWwgc2VtaS1yZWd1bGFybHkuXG4gICAgICAgICAgY29uc3QgU0hPV19NT1JFX1NFTEVDVE9SUyA9IFtcbiAgICAgICAgICAgICdbZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcbiAgICAgICAgICAgICdidXR0b25bZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcbiAgICAgICAgICAgICdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0gW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcbiAgICAgICAgICBdO1xuICAgICAgICAgIGNvbnN0IGNsaWNrZWQgPSBuZXcgU2V0PEVsZW1lbnQ+KCk7XG4gICAgICAgICAgbGV0IGV4cGFuZGVkID0gMDtcbiAgICAgICAgICBmb3IgKGNvbnN0IHNlbCBvZiBTSE9XX01PUkVfU0VMRUNUT1JTKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGVsIG9mIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWwpKSkge1xuICAgICAgICAgICAgICBpZiAoY2xpY2tlZC5oYXMoZWwpKSBjb250aW51ZTtcbiAgICAgICAgICAgICAgLy8gQ29uZmlybSBpdCdzIGFjdHVhbGx5IHRoZSBzaG93LW1vcmUgYWZmb3JkYW5jZSBieSB0ZXh0LlxuICAgICAgICAgICAgICBjb25zdCB0ID0gKGVsLnRleHRDb250ZW50IHx8ICcnKS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgICAgaWYgKHQgIT09ICdzaG93IG1vcmUnICYmIHQgIT09ICdzaG93IHRoaXMgdGhyZWFkJykgY29udGludWU7XG4gICAgICAgICAgICAgIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICAgICAgaWYgKHJlY3Qud2lkdGggPT09IDAgfHwgcmVjdC5oZWlnaHQgPT09IDApIGNvbnRpbnVlO1xuICAgICAgICAgICAgICBjbGlja2VkLmFkZChlbCk7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgICAgICAgICAgICAgIGV4cGFuZGVkICs9IDE7XG4gICAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgIC8vIGlnbm9yZVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIDIuIFNjcm9sbCB0aGUgcGFnZS4gRGlzcGF0Y2ggRW5kIGtleSBmaXJzdCBzaW5jZSBtYW55IFggc3VyZmFjZXNcbiAgICAgICAgICAvLyAgICAobGlzdHMsIHNlYXJjaCwgcmVwbGllcykgYmluZCBwYWdpbmF0aW9uIHRyaWdnZXJzIHRvIGl0IHZpYVxuICAgICAgICAgIC8vICAgIFJlYWN0IGhhbmRsZXJzOyB0aGVuIGV4cGxpY2l0bHkgc2Nyb2xsIHRoZSBkb2N1bWVudC5cbiAgICAgICAgICBjb25zdCBvcHRzOiBLZXlib2FyZEV2ZW50SW5pdCA9IHtcbiAgICAgICAgICAgIGtleTogJ0VuZCcsXG4gICAgICAgICAgICBjb2RlOiAnRW5kJyxcbiAgICAgICAgICAgIGtleUNvZGU6IDM1LFxuICAgICAgICAgICAgd2hpY2g6IDM1LFxuICAgICAgICAgICAgYnViYmxlczogdHJ1ZSxcbiAgICAgICAgICAgIGNhbmNlbGFibGU6IHRydWUsXG4gICAgICAgICAgfTtcbiAgICAgICAgICBjb25zdCBmb2N1cyA9IChkb2N1bWVudC5hY3RpdmVFbGVtZW50IGFzIEhUTUxFbGVtZW50IHwgbnVsbCkgPz8gZG9jdW1lbnQuYm9keTtcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXlkb3duJywgb3B0cykpO1xuICAgICAgICAgIGZvY3VzLmRpc3BhdGNoRXZlbnQobmV3IEtleWJvYXJkRXZlbnQoJ2tleXVwJywgb3B0cykpO1xuICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbyh7XG4gICAgICAgICAgICB0b3A6IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxIZWlnaHQsXG4gICAgICAgICAgICBiZWhhdmlvcjogJ2F1dG8nLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiB7IGV4cGFuZGVkIH07XG4gICAgICAgIH0pIGFzICgpID0+IHZvaWQsXG4gICAgICB9KSkgYXMgQXJyYXk8eyByZXN1bHQ/OiB1bmtub3duIH0+O1xuICAgICAgc2Nyb2xsQ291bnQgKz0gMTtcbiAgICAgIGNvbnN0IHIgPSByZXN1bHRzWzBdPy5yZXN1bHQgYXMgeyBleHBhbmRlZD86IG51bWJlciB9IHwgdW5kZWZpbmVkO1xuICAgICAgaWYgKHIgJiYgdHlwZW9mIHIuZXhwYW5kZWQgPT09ICdudW1iZXInKSBleHBhbmRlZENvdW50ICs9IHIuZXhwYW5kZWQ7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBUYWJzIHRoYXQgZGlzYWxsb3cgc2NyaXB0aW5nIChhYm91dDosIGRpc2NhcmRlZCwgbWlkLW5hdmlnYXRpb24pXG4gICAgICAvLyBqdXN0IGdldCBza2lwcGVkIFx1MjAxNCB0aGV5J2xsIGJlIGVsaWdpYmxlIG9uIGEgbGF0ZXIgdGljay5cbiAgICB9XG4gIH1cbiAgaWYgKHNjcm9sbENvdW50ID4gMCkge1xuICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgIGlmIChzZXNzICE9PSBudWxsKSB7XG4gICAgICBzZXNzLnNjcm9sbENvdW50ICs9IHNjcm9sbENvdW50O1xuICAgICAgc2Vzcy5leHBhbmRlZENvdW50ICs9IGV4cGFuZGVkQ291bnQ7XG4gICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzZXNzKTtcbiAgICAgIC8vIE5vIGJyb2FkY2FzdCBvbiBldmVyeSB0aWNrIFx1MjAxNCB0aGUgMTVzIHNpZGViYXIgcmVmcmVzaCBwaWNrcyBpdCB1cC5cbiAgICB9XG4gIH1cbn1cblxuYnJvd3Nlci5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcigoYWxhcm0pID0+IHtcbiAgaWYgKGFsYXJtLm5hbWUgPT09ICdmbHVzaC1zd2VlcCcpIHtcbiAgICB2b2lkIGZsdXNoSWRsZUJ1ZmZlcnMoKTtcbiAgfSBlbHNlIGlmIChhbGFybS5uYW1lID09PSAndmVyaWZ5LWNvbm5lY3Rpb24nKSB7XG4gICAgdm9pZCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgfVxuICAvLyByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcHJldmlvdXNseSByYW4gdmlhIGFsYXJtczsgdGhleSBub3cgdXNlXG4gIC8vIHNldEludGVydmFsIHRvIGVzY2FwZSB0aGUgMzBzIGFsYXJtIGZsb29yLiBMZWF2ZSB0aGUgbmFtZXMgbGlzdGVkXG4gIC8vIG5vd2hlcmUgc28gYW55IG9ycGhhbmVkIGFsYXJtcyAoZnJvbSBvbGRlciBidWlsZHMpIGp1c3Qgbm8tb3AuXG59KTtcblxuLy8gLS0tIFRvb2xiYXIgYWN0aW9uOiB0b2dnbGUgdGhlIHNpZGViYXIgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuaWYgKGJyb3dzZXIuYWN0aW9uPy5vbkNsaWNrZWQpIHtcbiAgYnJvd3Nlci5hY3Rpb24ub25DbGlja2VkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci5zaWRlYmFyQWN0aW9uLnRvZ2dsZSgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgLy8gRmFsbGJhY2s6IG9wZW4gb3B0aW9ucyBpZiBzaWRlYmFyIGNhbid0IGJlIHRvZ2dsZWQuXG4gICAgICBhd2FpdCB3YXJuKCdzaWRlYmFyIHRvZ2dsZSBmYWlsZWQ7IG9wZW5pbmcgb3B0aW9ucycsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgfVxuICB9KTtcbn1cblxuLy8gLS0tIFJ1bnRpbWUgbWVzc2FnZSBkaXNwYXRjaCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24sIF9zZW5kZXIpID0+IHtcbiAgaWYgKCFpc1J1bnRpbWVNZXNzYWdlKG1zZykpIHJldHVybiB1bmRlZmluZWQ7XG4gIHJldHVybiBoYW5kbGVNZXNzYWdlKG1zZykuY2F0Y2goKGVycikgPT4ge1xuICAgIHZvaWQgbG9nRXJyKCdtZXNzYWdlIGhhbmRsZXIgZmFpbGVkJywgeyB0eXBlOiBtc2cudHlwZSwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICAgIHRocm93IGVycjtcbiAgfSk7XG59KTtcblxuZnVuY3Rpb24gaXNSdW50aW1lTWVzc2FnZShtOiB1bmtub3duKTogbSBpcyBSdW50aW1lTWVzc2FnZSB7XG4gIHJldHVybiAhIW0gJiYgdHlwZW9mIG0gPT09ICdvYmplY3QnICYmIHR5cGVvZiAobSBhcyB7IHR5cGU/OiB1bmtub3duIH0pLnR5cGUgPT09ICdzdHJpbmcnO1xufVxuXG4vKiogTWVzc2FnZXMgdGhhdCBkcml2ZSB0aGUgY2FwdHVyZSBwaXBlbGluZS4gV2hlbiB0aGUgbWFzdGVyIHN3aXRjaCBpcyBPRkZcbiAqIHdlIGlnbm9yZSB0aGVzZSBidXQgc3RpbGwgcmVzcG9uZCB0byBzdGF0dXMgLyBjb25maWd1cmF0aW9uIHF1ZXJpZXMuICovXG5jb25zdCBDQVBUVVJFX1BJUEVMSU5FX01FU1NBR0VTID0gbmV3IFNldDxSdW50aW1lTWVzc2FnZVsndHlwZSddPihbXG4gICdncmFwaHFsLWNhcHR1cmUnLFxuICAnY2FwdHVyZS1ub3cnLFxuICAnY2FwdHVyZS1hbGwnLFxuICAnY2FwdHVyZS10aGlzLXBhZ2UnLFxuICAnZmx1c2gtYWxsJyxcbiAgJ2ZsdXNoLWhhbmRsZScsXG4gICdzdGFydC1yZWZldGNoJyxcbiAgJ3N0YXJ0LW1lZGlhLWNyYXdsJyxcbiAgJ3N0YXJ0LWF1dG8tc2Nyb2xsJyxcbl0pO1xuXG5hc3luYyBmdW5jdGlvbiBpc0VuYWJsZWQoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICByZXR1cm4gcy5lbmFibGVkICE9PSBmYWxzZTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlTWVzc2FnZShtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTx1bmtub3duPiB7XG4gIC8vIE1hc3RlciBzd2l0Y2g6IHdoZW4gdGhlIHVzZXIgaGFzIHBhdXNlZCB0aGUgZXh0ZW5zaW9uIHdlIHN0aWxsIG5lZWRcbiAgLy8gdGhlIG1ldGEtY2hhbm5lbHMgKGdldC1zdGF0ZSwgdG9nZ2xlLWVuYWJsZWQsIG9wZW4tb3B0aW9ucywgXHUyMDI2KSBzbyB0aGVcbiAgLy8gc2lkZWJhciBzdGF5cyBmdW5jdGlvbmFsLCBidXQgYW55dGhpbmcgdGhhdCB3b3VsZCBhY3R1YWxseSBjYXB0dXJlLFxuICAvLyBjb21taXQsIG9yIGRyaXZlIGEgdGFiIGlzIGEgbm8tb3AuXG4gIGlmICghKGF3YWl0IGlzRW5hYmxlZCgpKSAmJiBDQVBUVVJFX1BJUEVMSU5FX01FU1NBR0VTLmhhcyhtc2cudHlwZSkpIHtcbiAgICByZXR1cm4geyBvazogdHJ1ZSwgcGF1c2VkOiB0cnVlIH07XG4gIH1cbiAgc3dpdGNoIChtc2cudHlwZSkge1xuICAgIGNhc2UgJ2dyYXBocWwtY2FwdHVyZSc6XG4gICAgICBhd2FpdCBvbkdyYXBocWxDYXB0dXJlKG1zZy5lbmRwb2ludCwgbXNnLnVybCwgbXNnLnJlc3BvbnNlKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnY29udGVudC1hbGl2ZSc6XG4gICAgICBhd2FpdCBpbmZvKCdjb250ZW50IHNjcmlwdCBhbGl2ZSBvbiBwYWdlJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ3BhZ2UtaG9vay1hY3RpdmUnOlxuICAgICAgYXdhaXQgaW5mbygncGFnZSBob29rIHBhdGNoZWQgZmV0Y2gvWEhSJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2xvZy1jb250ZW50LWV2ZW50JzpcbiAgICAgIGlmIChtc2cubGV2ZWwgPT09ICd3YXJuJykge1xuICAgICAgICBhd2FpdCB3YXJuKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfSBlbHNlIGlmIChtc2cubGV2ZWwgPT09ICdlcnJvcicpIHtcbiAgICAgICAgYXdhaXQgbG9nRXJyKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgaW5mbyhtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnZ2V0LXN0YXRlJzpcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS1ub3cnOlxuICAgICAgYXdhaXQgY2FwdHVyZU5vdyhtc2cuaGFuZGxlKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS1hbGwnOlxuICAgICAgYXdhaXQgY2FwdHVyZUFsbCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLXRoaXMtcGFnZSc6XG4gICAgICBhd2FpdCBjYXB0dXJlVGhpc1BhZ2UoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnZmx1c2gtYWxsJzpcbiAgICAgIGF3YWl0IGZsdXNoQWxsKCd1c2VyJyk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2ZsdXNoLWhhbmRsZSc6XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShtc2cuaGFuZGxlLCAndXNlcicpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtYXV0by1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b0NhcHR1cmU6IG1zZy5vbiB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2F1dG8tY2FwdHVyZSB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtZW5hYmxlZCc6IHtcbiAgICAgIGNvbnN0IHMgPSBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGVuYWJsZWQ6IG1zZy5vbiB9KTtcbiAgICAgIGlmICghbXNnLm9uKSB7XG4gICAgICAgIC8vIFBhdXNpbmcgc3RvcHMgYWxsIGluLWZsaWdodCBsb29wcyBzbyB0aGUgdXNlciBnZXRzIGltbWVkaWF0ZVxuICAgICAgICAvLyBxdWlldCwgbm90IGEgXCJvbmUgbW9yZSB0aWNrXCIgc3VycHJpc2UuXG4gICAgICAgIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gICAgICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICAgICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigncmVmZXRjaC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBSZXN1bWluZyByZS1hcm1zIGFueSBsb29wcyB3aG9zZSBzZXNzaW9uIGlzIHN0aWxsIHNldC5cbiAgICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICAgIGlmIChzZXNzICE9PSBudWxsKSBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xuICAgICAgfVxuICAgICAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIG1hc3RlciBzd2l0Y2ggdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgfVxuICAgIGNhc2UgJ3N0YXJ0LWF1dG8tc2Nyb2xsJzpcbiAgICAgIGF3YWl0IHN0YXJ0QXV0b1Njcm9sbExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLWF1dG8tc2Nyb2xsJzpcbiAgICAgIGF3YWl0IGNhbmNlbEF1dG9TY3JvbGxMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCc6IHtcbiAgICAgIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICAgICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICAgICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChtc2cuc2Vjb25kcykpXG4gICAgICApO1xuICAgICAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IHNlY29uZHMgfSk7XG4gICAgICAvLyBSZS1hcm0gYW55IGFjdGl2ZSBsb29wcyB3aXRoIHRoZSBuZXcgaW50ZXJ2YWwuXG4gICAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgIGlmIChzZXNzICE9PSBudWxsKSBhcm1BdXRvU2Nyb2xsVGltZXIoc2Vjb25kcyk7XG4gICAgICBpZiAocmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcbiAgICAgIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHMpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAnc3RhcnQtcmVmZXRjaCc6XG4gICAgICBhd2FpdCBzdGFydFJlZmV0Y2hMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1yZWZldGNoJzpcbiAgICAgIGF3YWl0IGNhbmNlbFJlZmV0Y2hMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3N0YXJ0LW1lZGlhLWNyYXdsJzpcbiAgICAgIGF3YWl0IHN0YXJ0TWVkaWFDcmF3bExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLW1lZGlhLWNyYXdsJzpcbiAgICAgIGF3YWl0IGNhbmNlbE1lZGlhQ3Jhd2xMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3B1cmdlLXVucmVsYXRlZCc6IHtcbiAgICAgIGNvbnN0IGFjY3MgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICAgICAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjcy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcbiAgICAgIGNvbnN0IHN1bW1hcnkgPSBhd2FpdCBwdXJnZVVucmVsYXRlZFN0YXRlKHRyYWNrZWQpO1xuICAgICAgYXdhaXQgaW5mbygncHVyZ2VkIHVucmVsYXRlZCBzdGF0ZScsIHN1bW1hcnkpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAncmVmcmVzaC1hY2NvdW50cyc6XG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd2ZXJpZnktY29ubmVjdGlvbic6XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjbGVhci1hY3Rpdml0eSc6XG4gICAgICBhd2FpdCBjbGVhckFjdGl2aXR5KCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tb3B0aW9ucyc6XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tdmlld2VyJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgICBjb25zdCB1cmwgPSB2aWV3ZXJVcmwocyk7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICd1bmtub3duIG1lc3NhZ2UgdHlwZScgfTtcbiAgfVxufVxuXG4vLyAtLS0gQ2FwdHVyZSBwaXBlbGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBvbkdyYXBocWxDYXB0dXJlKGVuZHBvaW50OiBzdHJpbmcsIHVybDogc3RyaW5nLCByZXNwb25zZTogdW5rbm93bik6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoUFJPRklMRV9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuOyAvLyBub3QgdHdlZXQtYmVhcmluZ1xuICBpZiAoIVRXRUVUX0VORFBPSU5UUy5oYXMoZW5kcG9pbnQpKSByZXR1cm47XG5cbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICAvLyBXZSBkZWxpYmVyYXRlbHkgZG8gTk9UIHNob3J0LWNpcmN1aXQgd2hlbiB0aGUgUEFUIGlzIG1pc3NpbmcuIFRoZVxuICAvLyBub3JtYWxpemUgc3RlcCBpcyBjaGVhcCwgdGhlIGJ1ZmZlciBzdXJ2aXZlcyBzZXJ2aWNlLXdvcmtlciBldmljdGlvbixcbiAgLy8gYW5kIG9uY2UgdGhlIFBBVCBpcyBzZXQgdGhlIG5leHQgYWxhcm0gb3IgdXNlci10cmlnZ2VyZWQgZmx1c2ggY29tbWl0c1xuICAvLyBldmVyeXRoaW5nIHdlJ3ZlIHNlZW4uIERyb3BwaW5nIGNhcHR1cmVzIGhlcmUgd2FzIGhpZGluZyB0aGUgdXNlcidzXG4gIC8vIGZpcnN0IGJyb3dzaW5nIHNlc3Npb24gZW50aXJlbHkuXG5cbiAgLy8gVHdvLXN0YWdlIGZpbHRlcjpcbiAgLy8gICAxLiBCdWlsZCBFVkVSWSBjYW5vbmljYWwgdHdlZXQgd2UgY2FuIGZpbmQgaW4gdGhlIHJlc3BvbnNlIChubyBoYW5kbGVcbiAgLy8gICAgICBmaWx0ZXIgYXQgdGhlIG5vcm1hbGl6ZXIgbGV2ZWwgXHUyMDE0IHdlIHN0aWxsIHdhbnQgcXVvdGVkL1JUJ2QgcGFyZW50c1xuICAvLyAgICAgIHRoYXQgYXBwZWFyIGFzIHNpYmxpbmcgbm9kZXMpLlxuICAvLyAgIDIuIEFwcGx5IGBmaWx0ZXJSZWxhdGVkYCBwb3N0LWhvYyB0byBkcm9wIGFueXRoaW5nIHRoYXQgaGFzIG5vXG4gIC8vICAgICAgcmVsYXRpb25zaGlwIHRvIGEgdHJhY2tlZCBhY2NvdW50LiBUaGUgb2xkIGJlaGF2aW91ciAoXCJlbXB0eVxuICAvLyAgICAgIGFsbG93ZWQtc2V0IG9uIHVzZXItcGFnZSBlbmRwb2ludHMsIGZ1bGwgZmlsdGVyIG9uIGhvbWUvc2VhcmNoXCIpXG4gIC8vICAgICAgd2FzIHdheSB0b28gcGVybWlzc2l2ZSBvbiB0aGUgUmVwbGllcyB0YWI6IGV2ZXJ5IHJhbmRvbSByZXBsaWVyJ3NcbiAgLy8gICAgICByZXBseSBsYW5kZWQgaW4gYSBwZXItaGFuZGxlIGJ1ZmZlciBrZXllZCBieSB0aGVpciBvd24gaGFuZGxlLlxuICBjb25zdCB0cmFja2VkID0gbmV3IFNldChhY2NvdW50cy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcbiAgY29uc3QgY2FwdHVyZWRBdCA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICBsZXQgbm9ybWFsaXplZDtcbiAgdHJ5IHtcbiAgICBub3JtYWxpemVkID0gbm9ybWFsaXplKHJlc3BvbnNlLCB7XG4gICAgICBjYXB0dXJlZEF0LFxuICAgICAgcnVuSWQ6ICdwZW5kaW5nJyxcbiAgICAgIGVuZHBvaW50LFxuICAgICAgYWxsb3dlZEhhbmRsZXM6IG5ldyBTZXQ8c3RyaW5nPigpLFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCBxdWFyYW50aW5lKCdub3JtYWxpemUtdGhyZXcnLCBlbmRwb2ludCwgdXJsLCByZXNwb25zZSwgZXJyKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gRHJvcCB1bnJlbGF0ZWQgdHdlZXRzLiBUaGUgZmlsdGVyIGlzIGVuZHBvaW50LWF3YXJlOlxuICAvLyAgIC0gT24gdGhlIGhvbWUgLyBzZWFyY2ggdGltZWxpbmVzIHdlJ2QgYWxyZWFkeSBiZWVuIGZpbHRlcmluZyB0b1xuICAvLyAgICAgdHJhY2tlZCBhdXRob3JzIG9ubHkgXHUyMDE0IGtlZXAgdGhhdCBiZWhhdmlvdXIgYnV0IGdvIHRocm91Z2ggdGhlIHNhbWVcbiAgLy8gICAgIGBmaWx0ZXJSZWxhdGVkYCBoZWxwZXIgc28gdGhlIHJ1bGVzIGFyZSB1bmlmb3JtLlxuICAvLyAgIC0gT24gdXNlci1wYWdlIGVuZHBvaW50cyB3ZSBub3cgYWxzbyBkcm9wIGFueXRoaW5nIHRoYXQgaXNuJ3QgZWl0aGVyXG4gIC8vICAgICBhdXRob3JlZC1ieSwgbWVudGlvbmluZywgcmVwbHlpbmctdG8sIG9yIHJlZmVyZW5jZWQtYnkgYSB0cmFja2VkXG4gIC8vICAgICBhY2NvdW50LlxuICBjb25zdCBiZWZvcmVGaWx0ZXIgPSBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGg7XG4gIG5vcm1hbGl6ZWQudHdlZXRzID0gZmlsdGVyUmVsYXRlZChub3JtYWxpemVkLnR3ZWV0cywgdHJhY2tlZCk7XG4gIGNvbnN0IGRyb3BwZWRVbnJlbGF0ZWQgPSBiZWZvcmVGaWx0ZXIgLSBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGg7XG4gIGlmIChkcm9wcGVkVW5yZWxhdGVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2Ryb3BwZWQgdW5yZWxhdGVkIHR3ZWV0cycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgZHJvcHBlZDogZHJvcHBlZFVucmVsYXRlZCxcbiAgICAgIGtlcHQ6IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIERpYWdub3N0aWM6IGV2ZXJ5IHR3ZWV0LWVuZHBvaW50IHBheWxvYWQgZ2V0cyBhIGxpbmUgaW4gdGhlIGFjdGl2aXR5XG4gIC8vIHRhaWwgd2l0aCB3aGF0IHdlIHNhdyB2cyBrZXB0LiBXaGVuIG9ic2VydmVkPTAgd2UgYWxzbyBlbWl0IGEgc2hhcGVcbiAgLy8gcHJvYmUgKGtleSBwYXRocyArIHR5cGVuYW1lcykgc28gd2UgY2FuIHRlbGwgd2hldGhlciBYIHJldHVybmVkIGFuXG4gIC8vIGVtcHR5IGVudmVsb3BlLCBhIGxvZ2luLXdhbGwgcmVzcG9uc2UsIG9yIGEgbmV3IHNoYXBlIHdlIGRvbid0IGtub3cgaG93XG4gIC8vIHRvIHdhbGsgeWV0LlxuICBpZiAobm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygnZ3JhcGhxbCBwYXlsb2FkIGVtcHR5IFx1MjAxNCBzaGFwZSBwcm9iZScsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgdHlwZW5hbWVzOiBwcm9iZVR5cGVuYW1lcyhyZXNwb25zZSkuc2xpY2UoMCwgMzApLFxuICAgICAgdHdlZXRfa2V5czogcHJvYmVGaXJzdFR5cGVTaGFwZShyZXNwb25zZSwgJ1R3ZWV0JyksXG4gICAgICB0d2VldF9jb3JlX2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFsnY29yZSddKSxcbiAgICAgIHR3ZWV0X2xlZ2FjeV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbJ2xlZ2FjeSddKSxcbiAgICAgIHVzZXJfcmVzdWx0c19yZXN1bHRfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xuICAgICAgICAnY29yZScsXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxuICAgICAgICAncmVzdWx0JyxcbiAgICAgIF0pLFxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9jb3JlX2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcbiAgICAgICAgJ3Jlc3VsdCcsXG4gICAgICAgICdjb3JlJyxcbiAgICAgIF0pLFxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9sZWdhY3lfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xuICAgICAgICAnY29yZScsXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxuICAgICAgICAncmVzdWx0JyxcbiAgICAgICAgJ2xlZ2FjeScsXG4gICAgICBdKSxcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBhd2FpdCBpbmZvKCdncmFwaHFsIHBheWxvYWQgc2VlbicsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgb2JzZXJ2ZWQ6IG5vcm1hbGl6ZWQub2JzZXJ2ZWRfaWRzLmxlbmd0aCxcbiAgICAgIGtlcHQ6IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuXG4gIGlmIChub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAvLyBSZWZldGNoIHF1ZXVlIGhvdXNla2VlcGluZyBcdTIwMTQgcnVucyBCRUZPUkUgdGhlIGRlZHVwIHNob3J0LWNpcmN1aXQuIEFcbiAgLy8gcmVmZXRjaCBjYXB0dXJlIGNvbWVzIGJhY2sgd2l0aCB0aGUgc2FtZSBlbmdhZ2VtZW50IGNvdW50cyAod2UncmVcbiAgLy8gb25seSBhZnRlciB0aGUgZnVsbCB0ZXh0KSwgc28gdGhlIGRlZHVwIGJlbG93IHdvdWxkIHNpbGVudGx5IGRyb3BcbiAgLy8gaXQgYW5kIHRoZSBxdWV1ZSB3b3VsZCBuZXZlciBkcmFpbi4gSG9pc3QgdGhlIGVucXVldWUvZGVxdWV1ZSBoZXJlXG4gIC8vIHNvIHRoZSBsb29wIHJlbGlhYmx5IGFkdmFuY2VzIGV2ZW4gd2hlbiBubyBjb21taXQgaGFwcGVucy5cbiAgLy9cbiAgLy8gQWxzbzogaWYgZWl0aGVyIGxvb3AncyBpbmZsaWdodCB0YXJnZXQgYXBwZWFycyBoZXJlLCBtYXJrIHRoZSBsb29wXG4gIC8vIGFzIFwiaW5nZXN0ZWRcIiBzbyB0aGUgbmV4dCB0aWNrIGNhbiBhZHZhbmNlLiBUaGUgd2FpdC1mb3ItaW5nZXN0XG4gIC8vIGd1YXJkIG90aGVyd2lzZSBibG9ja3MgdW50aWwgdGhlIG5hdmlnYXRpb24tdGltZW91dCBmaXJlcy5cbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGlmICh0LmlzX3RydW5jYXRlZCkge1xuICAgICAgYXdhaXQgZW5xdWV1ZVJlZmV0Y2godC5hY2NvdW50X2hhbmRsZSwgdC50d2VldF9pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xuICAgIH1cbiAgICAvLyBTdWNjZXNzZnVsbHkgYnVpbHQgdHdlZXRzIGFyZSBubyBsb25nZXIgXCJwYXJ0aWFsXCIgXHUyMDE0IGRyb3AgZnJvbSB0aGVcbiAgICAvLyBtZWRpYS1jcmF3bCBxdWV1ZSByZWdhcmRsZXNzIG9mIHdoaWNoIGhhbmRsZSB3ZSdkIGhpbnRlZCBlYXJsaWVyLlxuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHQudHdlZXRfaWQpO1xuICAgIGlmIChyZWZldGNoU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcbiAgICAgIHJlZmV0Y2hTZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIHJlZmV0Y2hTZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24ocmVmZXRjaFNlc3MpO1xuICAgIH1cbiAgICBpZiAobWVkaWFDcmF3bFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XG4gICAgICBtZWRpYUNyYXdsU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICBtZWRpYUNyYXdsU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG1lZGlhQ3Jhd2xTZXNzKTtcbiAgICB9XG4gIH1cblxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXQtc2hhcGVkIG5vZGVzIHRoZSB3YWxrZXIgc2F3IGJ1dCBjb3VsZG4ndCB0dXJuXG4gIC8vIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gRW5xdWV1ZSBvbmx5IElEcyB3ZSBoYXZlbid0IGFscmVhZHlcbiAgLy8gY29tbWl0dGVkICh1c2VyLXJlcXVlc3RlZCBkZWR1cCBhZ2FpbnN0IHRoZSBhcmNoaXZlKS5cbiAgZm9yIChjb25zdCBwYXJ0aWFsIG9mIG5vcm1hbGl6ZWQucGFydGlhbF9pZHMpIHtcbiAgICBpZiAoYXdhaXQgaXNDb21taXR0ZWQocGFydGlhbC50d2VldF9pZCkpIGNvbnRpbnVlO1xuICAgIGF3YWl0IGVucXVldWVNZWRpYUNyYXdsKHBhcnRpYWwuaGludF9oYW5kbGUsIHBhcnRpYWwudHdlZXRfaWQpO1xuICB9XG4gIGlmIChub3JtYWxpemVkLnBhcnRpYWxfaWRzLmxlbmd0aCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogZW5xdWV1ZWQgcGFydGlhbCBjYXB0dXJlcycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgcGFydGlhbDogbm9ybWFsaXplZC5wYXJ0aWFsX2lkcy5sZW5ndGgsXG4gICAgICBxdWV1ZV90b3RhbDogYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKSxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIENyb3NzLXNlc3Npb24gZGVkdXA6IGRyb3AgdHdlZXRzIHdlJ3ZlIGFscmVhZHkgY29tbWl0dGVkIHdpdGggaWRlbnRpY2FsXG4gIC8vIGVuZ2FnZW1lbnQgY291bnRzLiBMaWtlcy9SVHMvcmVwbGllcy9xdW90ZXMgc3RpbGwgdHJpZ2dlciBhIHJlY2FwdHVyZVxuICAvLyBzbyBlbmdhZ2VtZW50X2hpc3RvcnkgZ3Jvd3Mgb3ZlciB0aW1lLiB2aWV3X2NvdW50IGlzIGludGVudGlvbmFsbHlcbiAgLy8gZXhjbHVkZWQgXHUyMDE0IGl0IGNodXJucyB0b28gZmFzdCB0byBiZSB1c2VmdWwgYXMgYSBmcmVzaG5lc3Mgc2lnbmFsLlxuICAvLyBgaXNfdHJ1bmNhdGVkYCBpcyBwYXJ0IG9mIHRoZSBzaWduYXR1cmUgc28gYSByZWZldGNoIHRoYXQgZmxpcHNcbiAgLy8gdHJ1bmNhdGVkXHUyMTkyZnVsbCBpcyB0cmVhdGVkIGFzIGEgbWF0ZXJpYWwgY2hhbmdlIGFuZCBnZXRzIGNvbW1pdHRlZC5cbiAgY29uc3QgY29tbWl0dGVkSWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgbGV0IGRlZHVwZWRTa2lwcGVkID0gMDtcbiAgY29uc3QgbGl2ZVR3ZWV0czogdHlwZW9mIG5vcm1hbGl6ZWQudHdlZXRzID0gW107XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbdC5hY2NvdW50X2hhbmRsZV0/Llt0LnR3ZWV0X2lkXTtcbiAgICBjb25zdCBzaWcgPSBlbmdhZ2VtZW50U2lnKFxuICAgICAgdC5saWtlX2NvdW50LFxuICAgICAgdC5yZXR3ZWV0X2NvdW50LFxuICAgICAgdC5yZXBseV9jb3VudCxcbiAgICAgIHQucXVvdGVfY291bnQsXG4gICAgICB0LmlzX3RydW5jYXRlZFxuICAgICk7XG4gICAgaWYgKHByZXYgJiYgcHJldi5zaWcgPT09IHNpZykge1xuICAgICAgZGVkdXBlZFNraXBwZWQgKz0gMTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBsaXZlVHdlZXRzLnB1c2godCk7XG4gIH1cbiAgaWYgKGRlZHVwZWRTa2lwcGVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2RlZHVwOiBza2lwcGVkIHVuY2hhbmdlZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHNraXBwZWQ6IGRlZHVwZWRTa2lwcGVkLFxuICAgICAgcmVtYWluaW5nOiBsaXZlVHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuICBpZiAobGl2ZVR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAvLyBHcm91cCBzdXJ2aXZpbmcgdHdlZXRzIGJ5IGF1dGhvciBoYW5kbGUuXG4gIGNvbnN0IGJ5SGFuZGxlID0gbmV3IE1hcDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0W10+KCk7XG4gIGZvciAoY29uc3QgdCBvZiBsaXZlVHdlZXRzKSB7XG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUpID8/IFtdO1xuICAgIGFyci5wdXNoKHQpO1xuICAgIGJ5SGFuZGxlLnNldCh0LmFjY291bnRfaGFuZGxlLCBhcnIpO1xuICB9XG5cbiAgZm9yIChjb25zdCBbaGFuZGxlLCB0d2VldHNdIG9mIGJ5SGFuZGxlKSB7XG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgdXJsLCBlbmRwb2ludCk7XG4gICAgbGV0IGFkZGVkID0gMDtcbiAgICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgICBjb25zdCBleGlzdGluZyA9IGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF07XG4gICAgICBpZiAoZXhpc3RpbmcpIHtcbiAgICAgICAgLy8gUHJlc2VydmUgZmlyc3RfY2FwdHVyZWRfYXQsIGFwcGVuZCBlbmdhZ2VtZW50IHNuYXBzaG90LCByZWZyZXNoXG4gICAgICAgIC8vIGxhc3Rfc2Vlbl9hdCArIGNvdW50cyAodGhlIGxhdGVzdCBzY3JhcGUgd2lucyBmb3IgY291bnRzKS5cbiAgICAgICAgZXhpc3RpbmcubGFzdF9zZWVuX2F0ID0gY2FwdHVyZWRBdDtcbiAgICAgICAgZXhpc3RpbmcubGlrZV9jb3VudCA9IHQubGlrZV9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmV0d2VldF9jb3VudCA9IHQucmV0d2VldF9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmVwbHlfY291bnQgPSB0LnJlcGx5X2NvdW50O1xuICAgICAgICBleGlzdGluZy5xdW90ZV9jb3VudCA9IHQucXVvdGVfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnZpZXdfY291bnQgPSB0LnZpZXdfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLmJvb2ttYXJrX2NvdW50ID0gdC5ib29rbWFya19jb3VudDtcbiAgICAgICAgY29uc3QgbGFzdCA9IGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeVtleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnkubGVuZ3RoIC0gMV07XG4gICAgICAgIGNvbnN0IHNuYXAgPSB0LmVuZ2FnZW1lbnRfaGlzdG9yeVswXTtcbiAgICAgICAgaWYgKHNuYXAgJiYgKCFsYXN0IHx8IGxhc3QuY2FwdHVyZWRfYXQgIT09IHNuYXAuY2FwdHVyZWRfYXQpKSB7XG4gICAgICAgICAgZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5LnB1c2goc25hcCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHN0YW1wZWQ6IENhbm9uaWNhbFR3ZWV0ID0geyAuLi50LCBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCB9O1xuICAgICAgICBidWYudHdlZXRzX2J5X2lkW3QudHdlZXRfaWRdID0gc3RhbXBlZDtcbiAgICAgICAgYWRkZWQgKz0gMTtcbiAgICAgIH1cbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyh0LnR3ZWV0X2lkKSkge1xuICAgICAgICBidWYudHdlZXRfaWRzX29ic2VydmVkLnB1c2godC50d2VldF9pZCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xuICAgIGJ1Zi5sYXN0X2NhcHR1cmVfYXQgPSBjYXB0dXJlZEF0O1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCk7XG4gICAgaWYgKGFkZGVkID4gMCkge1xuICAgICAgYXdhaXQgaW5mbygnY2FwdHVyZWQgdHdlZXRzJywge1xuICAgICAgICBoYW5kbGUsXG4gICAgICAgIGVuZHBvaW50LFxuICAgICAgICBhZGRlZCxcbiAgICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCxcbiAgICAgIH0pO1xuICAgICAgLy8gQnVtcCB0aGUgYXV0by1zY3JvbGwgcHJvZ3Jlc3Mgc28gdGhlIHVzZXIgc2VlcyBcIlggaW5nZXN0ZWRcIiB0aWNrIHVwXG4gICAgICAvLyBpbiByZWFsIHRpbWUuIFdlIGNvdW50IGFjdHVhbGx5LW5ldyB0d2VldHMsIG5vdCBkdXBsaWNhdGVzLlxuICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgIGlmIChhc1Nlc3MgIT09IG51bGwpIHtcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkQ291bnQgKz0gYWRkZWQ7XG4gICAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKGFzU2Vzcyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggPj0gRkxVU0hfVFdFRVRfVEhSRVNIT0xEKSB7XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICd0aHJlc2hvbGQnKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlUnVuQnVmZmVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgdHM6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8UnVuQnVmZmVyPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpO1xuICBpZiAoY3VyKSByZXR1cm4gY3VyO1xuICBjb25zdCBidWY6IFJ1bkJ1ZmZlciA9IHtcbiAgICBydW5faWQ6IG5ld1J1bklkKCksXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBzdGFydGVkX2F0OiB0cyxcbiAgICBsYXN0X2NhcHR1cmVfYXQ6IHRzLFxuICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcbiAgICBlbmRwb2ludHNfc2VlbjogW2VuZHBvaW50XSxcbiAgICBzb3VyY2VfdXJsOiBzb3VyY2VVcmwsXG4gIH07XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gIGF3YWl0IGluZm8oJ3J1biBzdGFydGVkJywgeyBoYW5kbGUsIHJ1bjogc2hvcnRSdW5JZChidWYucnVuX2lkKSB9KTtcbiAgcmV0dXJuIGJ1Zjtcbn1cblxuLy8gLS0tIEZsdXNoIGxvZ2ljIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxubGV0IGZsdXNoQ2hhaW46IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKTtcblxuaW50ZXJmYWNlIEZsdXNoSXRlbSB7XG4gIGhhbmRsZTogc3RyaW5nO1xuICBidWY6IFJ1bkJ1ZmZlcjtcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdO1xuICByYXdQYXRoOiBzdHJpbmc7XG4gIHNlZW5QYXRoOiBzdHJpbmc7XG4gIGNhcHR1cmU6IENhcHR1cmVQYXlsb2FkO1xuICBzZWVuOiBTZWVuUGF5bG9hZDtcbiAgZGF5OiBzdHJpbmc7XG4gIHJ1blNob3J0OiBzdHJpbmc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSWRsZUJ1ZmZlcnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgY29uc3QgaGFuZGxlczogc3RyaW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xuICAgICAgaGFuZGxlcy5wdXNoKGhhbmRsZSk7XG4gICAgfVxuICB9XG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhoYW5kbGVzLCAnaWRsZScpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIE9uIHdvcmtlciB3YWtlLCBhbnkgYnVmZmVyIG9sZGVyIHRoYW4gdGhlIGlkbGUgdGhyZXNob2xkIGdldHMgYSBjaGFuY2UgdG9cbiAgLy8gY29tbWl0IGltbWVkaWF0ZWx5IFx1MjAxNCB1c2VmdWwgd2hlbiB0aGUgd29ya2VyIHdhcyBldmljdGVkIGJlZm9yZSBpZGxlLWZsdXNoLlxuICAvLyBJZiB0aGUgUEFUL293bmVyL3JlcG8gYXJlbid0IHNldCB3ZSdkIGp1c3QgZW1pdCBcImZsdXNoIGRlZmVycmVkXCIgZm9yIGV2ZXJ5XG4gIC8vIHNpbmdsZSBoYW5kbGUgaW4gc3RvcmFnZSAodGhlIGRpYWdub3N0aWMgc2hvd2VkIHRoaXMgZmlyaW5nIDMwMCsgdGltZXMgaW5cbiAgLy8gYSByb3cgd2hlbiB0aGUgZXh0ZW5zaW9uIHdva2UgYmVmb3JlIHNldHRpbmdzIGxvYWQpLCBzbyBzaG9ydC1jaXJjdWl0XG4gIC8vIGhlcmUgaW5zdGVhZC5cbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBjb25zdCBoYW5kbGVzOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XG4gICAgICBoYW5kbGVzLnB1c2goaGFuZGxlKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgZmx1c2hIYW5kbGVzKGhhbmRsZXMsICd3YWtlJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoQWxsKHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKE9iamVjdC5rZXlzKGFsbCksIHJlYXNvbik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlKGhhbmRsZTogc3RyaW5nLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBmbHVzaEhhbmRsZXMoW2hhbmRsZV0sIHJlYXNvbik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlcyhoYW5kbGVzOiBzdHJpbmdbXSwgcmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdW5pcXVlID0gWy4uLm5ldyBTZXQoaGFuZGxlcyldLmZpbHRlcigoaCkgPT4gaC5sZW5ndGggPiAwKTtcbiAgaWYgKHVuaXF1ZS5sZW5ndGggPT09IDApIHJldHVybjtcbiAgY29uc3QgcnVuID0gZmx1c2hDaGFpbi50aGVuKCgpID0+IGZsdXNoSGFuZGxlc0xvY2tlZCh1bmlxdWUsIHJlYXNvbikpO1xuICBmbHVzaENoYWluID0gcnVuLmNhdGNoKCgpID0+IHt9KTtcbiAgcmV0dXJuIHJ1bjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGVzTG9ja2VkKGhhbmRsZXM6IHN0cmluZ1tdLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGNvbnN0IGl0ZW1zOiBGbHVzaEl0ZW1bXSA9IFtdO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBoYW5kbGVzKSB7XG4gICAgY29uc3QgYnVmID0gYWxsW2hhbmRsZV07XG4gICAgaWYgKCFidWYpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHR3ZWV0cyA9IE9iamVjdC52YWx1ZXMoYnVmLnR3ZWV0c19ieV9pZCk7XG4gICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApIHtcbiAgICAgIGF3YWl0IGNsZWFyUnVuQnVmZmVyKGhhbmRsZSk7XG4gICAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgMCk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaXRlbXMucHVzaChidWlsZEZsdXNoSXRlbShoYW5kbGUsIGJ1ZiwgdHdlZXRzKSk7XG4gIH1cbiAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSB7XG4gICAgYXdhaXQgd2FybignZmx1c2ggZGVmZXJyZWQ6IHNldHRpbmdzIGluY29tcGxldGUnLCB7XG4gICAgICBjb3VudDogaXRlbXMubGVuZ3RoLFxuICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgY29uc3QgZmlsZXMgPSBpdGVtcy5mbGF0TWFwKChpdGVtKSA9PiBbXG4gICAge1xuICAgICAgcGF0aDogaXRlbS5yYXdQYXRoLFxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkoaXRlbS5jYXB0dXJlLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICB9LFxuICAgIHtcbiAgICAgIHBhdGg6IGl0ZW0uc2VlblBhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShpdGVtLnNlZW4sIG51bGwsIDIpICsgJ1xcbicpLFxuICAgIH0sXG4gIF0pO1xuICBjb25zdCBjb21taXRNc2cgPSBidWlsZEJhdGNoQ29tbWl0TWVzc2FnZShpdGVtcyk7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQuY29tbWl0RmlsZXMoe1xuICAgICAgZmlsZXMsXG4gICAgICBtZXNzYWdlOiBjb21taXRNc2csXG4gICAgfSk7XG4gICAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgaXRlbXMpIHtcbiAgICAgIGNvbnN0IHJlbWFpbmluZ0NvdW50ID0gYXdhaXQgY2xlYXJDb21taXR0ZWRUd2VldHNGcm9tQnVmZmVyKGl0ZW0pO1xuICAgICAgLy8gQ291bnRlciBidW1wOiBhY3R1YWxseSBJTkNSRU1FTlQgdG9kYXlDb3VudCBhbmQgdG90YWxDb21taXR0ZWQgYnlcbiAgICAgIC8vIHRoZSBudW1iZXIgb2YgdHdlZXRzIHdlIGp1c3QgcGVyc2lzdGVkICh0aGUgcHJldmlvdXMgY29kZSByZWFkIHRoZVxuICAgICAgLy8gZXhpc3RpbmcgdmFsdWVzIGFuZCB3cm90ZSB0aGVtIGJhY2ssIGxlYXZpbmcgdGhlIGNvdW50ZXIgcGVnZ2VkIGF0XG4gICAgICAvLyB6ZXJvKS5cbiAgICAgIGNvbnN0IHByZXYgPSAoYXdhaXQgZ2V0Q291bnRlcnMoKSlbaXRlbS5oYW5kbGVdO1xuICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuICAgICAgY29uc3QgY2FycmllZFRvZGF5ID0gcHJldiAmJiBwcmV2LnRvZGF5RGF0ZSA9PT0gdG9kYXkgPyBwcmV2LnRvZGF5Q291bnQgOiAwO1xuICAgICAgYXdhaXQgYnVtcENvdW50ZXIoaXRlbS5oYW5kbGUsIHtcbiAgICAgICAgdG9kYXlDb3VudDogY2FycmllZFRvZGF5ICsgaXRlbS50d2VldHMubGVuZ3RoLFxuICAgICAgICB0b2RheURhdGU6IHRvZGF5LFxuICAgICAgICBsYXN0Q2FwdHVyZUF0OiBpdGVtLmJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICAgIHRvdGFsQ29tbWl0dGVkOiAocHJldj8udG90YWxDb21taXR0ZWQgPz8gMCkgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIGJ1ZmZlcmVkQ291bnQ6IHJlbWFpbmluZ0NvdW50LFxuICAgICAgfSk7XG4gICAgICAvLyBSZWNvcmQgY29tbWl0cyBpbiB0aGUgZGVkdXAgaW5kZXggc28gd2UgZG9uJ3QgcmUtY29tbWl0IHRoZW0gbmV4dFxuICAgICAgLy8gYnJvd3NlIHdpdGggdW5jaGFuZ2VkIGVuZ2FnZW1lbnQuXG4gICAgICBjb25zdCBpbm5lciA9IGlkeFtpdGVtLmhhbmRsZV0gPz8ge307XG4gICAgICBjb25zdCBub3dJc28gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgICBmb3IgKGNvbnN0IHQgb2YgaXRlbS50d2VldHMpIHtcbiAgICAgICAgaW5uZXJbdC50d2VldF9pZF0gPSB7XG4gICAgICAgICAgdHM6IG5vd0lzbyxcbiAgICAgICAgICBzaWc6IGVuZ2FnZW1lbnRTaWcoXG4gICAgICAgICAgICB0Lmxpa2VfY291bnQsXG4gICAgICAgICAgICB0LnJldHdlZXRfY291bnQsXG4gICAgICAgICAgICB0LnJlcGx5X2NvdW50LFxuICAgICAgICAgICAgdC5xdW90ZV9jb3VudCxcbiAgICAgICAgICAgIHQuaXNfdHJ1bmNhdGVkXG4gICAgICAgICAgKSxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGlkeFtpdGVtLmhhbmRsZV0gPSBpbm5lcjtcbiAgICAgIGF3YWl0IGluZm8oJ2ZsdXNoIGNvbW1pdHRlZCcsIHtcbiAgICAgICAgaGFuZGxlOiBpdGVtLmhhbmRsZSxcbiAgICAgICAgcmVhc29uLFxuICAgICAgICB0d2VldHM6IGl0ZW0udHdlZXRzLmxlbmd0aCxcbiAgICAgICAgcnVuOiBpdGVtLnJ1blNob3J0LFxuICAgICAgICBwYXRoOiBpdGVtLnJhd1BhdGgsXG4gICAgICAgIGJhdGNoX2NvbW1pdDogcmVzdWx0LmNvbW1pdFNoYSxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xuICAgIGF3YWl0IGluZm8oJ2ZsdXNoIGJhdGNoIGNvbW1pdHRlZCcsIHtcbiAgICAgIHJlYXNvbixcbiAgICAgIHJ1bnM6IGl0ZW1zLmxlbmd0aCxcbiAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXG4gICAgICB0d2VldHM6IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS50d2VldHMubGVuZ3RoLCAwKSxcbiAgICAgIGNvbW1pdDogcmVzdWx0LmNvbW1pdFNoYSxcbiAgICB9KTtcbiAgICB7XG4gICAgICBjb25zdCBwcmV2ID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICAgIHN0YXR1czogJ29rJyxcbiAgICAgICAgbG9naW46IHByZXYubG9naW4sXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBlcnJvcjogbnVsbCxcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogcHJldi5kZWZhdWx0QnJhbmNoLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBwcmV2LmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgICB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvcikge1xuICAgICAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XG4gICAgICAgIGVyci5jYXRlZ29yeSA9PT0gJ2F1dGgnXG4gICAgICAgICAgPyAnYXV0aC1lcnJvcidcbiAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnXG4gICAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ25ldHdvcmsnXG4gICAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXG4gICAgICAgICAgICAgIDogY29ubi5zdGF0dXM7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzLFxuICAgICAgICBsb2dpbjogY29ubi5sb2dpbixcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBlcnIubWVzc2FnZSxcbiAgICAgICAgZGVmYXVsdEJyYW5jaDogY29ubi5kZWZhdWx0QnJhbmNoLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBjb25uLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6XG4gICAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyBlcnIucmF0ZUxpbWl0UmVzZXRBdCA6IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCxcbiAgICAgIH0pO1xuICAgICAgYXdhaXQgbG9nRXJyKCdmbHVzaCBmYWlsZWQnLCB7XG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxuICAgICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXG4gICAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXG4gICAgICAgIGNhdGVnb3J5OiBlcnIuY2F0ZWdvcnksXG4gICAgICAgIHN0YXR1czogZXJyLnN0YXR1cyxcbiAgICAgICAgbWVzc2FnZTogZXJyLm1lc3NhZ2UsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGVyci5yYXRlTGltaXRSZXNldEF0LFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGxvZ0VycignZmx1c2ggZmFpbGVkJywge1xuICAgICAgICByZWFzb24sXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcbiAgICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgICB9KTtcbiAgICB9XG4gICAgLy8gTGVhdmUgYnVmZmVyIGludGFjdCBmb3IgcmV0cnkuXG4gIH0gZmluYWxseSB7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBidWlsZEZsdXNoSXRlbShoYW5kbGU6IHN0cmluZywgYnVmOiBSdW5CdWZmZXIsIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSk6IEZsdXNoSXRlbSB7XG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChidWYuc3RhcnRlZF9hdCk7XG4gIGNvbnN0IGRheSA9IGJ1Zi5zdGFydGVkX2F0LnNsaWNlKDAsIDEwKTtcbiAgY29uc3QgcnVuU2hvcnQgPSBzaG9ydFJ1bklkKGJ1Zi5ydW5faWQpO1xuICBjb25zdCByYXdQYXRoID0gYHJhdy8ke2hhbmRsZX0vJHt0c30tJHtydW5TaG9ydH0uanNvbmA7XG4gIGNvbnN0IHNlZW5QYXRoID0gYHNlZW4vJHtoYW5kbGV9LyR7dHN9LSR7cnVuU2hvcnR9Lmpzb25gO1xuICByZXR1cm4ge1xuICAgIGhhbmRsZSxcbiAgICBidWYsXG4gICAgdHdlZXRzLFxuICAgIHJhd1BhdGgsXG4gICAgc2VlblBhdGgsXG4gICAgZGF5LFxuICAgIHJ1blNob3J0LFxuICAgIGNhcHR1cmU6IHtcbiAgICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICBlbmRwb2ludDogYnVmLmVuZHBvaW50c19zZWVuLmpvaW4oJywnKSxcbiAgICAgIHVzZXJfYWdlbnQ6IG5hdmlnYXRvci51c2VyQWdlbnQsXG4gICAgICBzb3VyY2VfdXJsOiBidWYuc291cmNlX3VybCxcbiAgICAgIHR3ZWV0cyxcbiAgICB9LFxuICAgIHNlZW46IHtcbiAgICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQsXG4gICAgfSxcbiAgfTtcbn1cblxuZnVuY3Rpb24gYnVpbGRCYXRjaENvbW1pdE1lc3NhZ2UoaXRlbXM6IEZsdXNoSXRlbVtdKTogc3RyaW5nIHtcbiAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMSkge1xuICAgIGNvbnN0IGl0ZW0gPSBpdGVtc1swXSE7XG4gICAgcmV0dXJuIGBjYXB0dXJlOiAke2l0ZW0uaGFuZGxlfSAke2l0ZW0uZGF5fSAke2l0ZW0udHdlZXRzLmxlbmd0aH0gdHdlZXQke2l0ZW0udHdlZXRzLmxlbmd0aCA9PT0gMSA/ICcnIDogJ3MnfSAocnVuICR7aXRlbS5ydW5TaG9ydH0pYDtcbiAgfVxuICBjb25zdCBkYXlzID0gWy4uLm5ldyBTZXQoaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmRheSkpXS5zb3J0KCk7XG4gIGNvbnN0IGRheUxhYmVsID0gZGF5cy5sZW5ndGggPT09IDEgPyBkYXlzWzBdISA6IGAke2RheXNbMF19Li4ke2RheXNbZGF5cy5sZW5ndGggLSAxXX1gO1xuICBjb25zdCB0d2VldENvdW50ID0gaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApO1xuICByZXR1cm4gYGNhcHR1cmUgYmF0Y2g6ICR7aXRlbXMubGVuZ3RofSBydW5zLCAke3R3ZWV0Q291bnR9IHR3ZWV0JHt0d2VldENvdW50ID09PSAxID8gJycgOiAncyd9ICgke2RheUxhYmVsfSlgO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjbGVhckNvbW1pdHRlZFR3ZWV0c0Zyb21CdWZmZXIoaXRlbTogRmx1c2hJdGVtKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgY3VycmVudCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSk7XG4gIGlmICghY3VycmVudCkgcmV0dXJuIDA7XG4gIGlmIChjdXJyZW50LnJ1bl9pZCAhPT0gaXRlbS5idWYucnVuX2lkKSByZXR1cm4gT2JqZWN0LmtleXMoY3VycmVudC50d2VldHNfYnlfaWQpLmxlbmd0aDtcblxuICBjb25zdCBjb21taXR0ZWQgPSBuZXcgTWFwKFxuICAgIGl0ZW0udHdlZXRzLm1hcCgodCkgPT4gW1xuICAgICAgdC50d2VldF9pZCxcbiAgICAgIGVuZ2FnZW1lbnRTaWcodC5saWtlX2NvdW50LCB0LnJldHdlZXRfY291bnQsIHQucmVwbHlfY291bnQsIHQucXVvdGVfY291bnQsIHQuaXNfdHJ1bmNhdGVkKSxcbiAgICBdKVxuICApO1xuICBjb25zdCByZW1haW5pbmdUd2VldHM6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PiA9IHt9O1xuICBmb3IgKGNvbnN0IFt0d2VldElkLCB0d2VldF0gb2YgT2JqZWN0LmVudHJpZXMoY3VycmVudC50d2VldHNfYnlfaWQpKSB7XG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcbiAgICBjb25zdCBjdXJyZW50U2lnID0gZW5nYWdlbWVudFNpZyhcbiAgICAgIHR3ZWV0Lmxpa2VfY291bnQsXG4gICAgICB0d2VldC5yZXR3ZWV0X2NvdW50LFxuICAgICAgdHdlZXQucmVwbHlfY291bnQsXG4gICAgICB0d2VldC5xdW90ZV9jb3VudCxcbiAgICAgIHR3ZWV0LmlzX3RydW5jYXRlZFxuICAgICk7XG4gICAgaWYgKCFjb21taXR0ZWRTaWcgfHwgY29tbWl0dGVkU2lnICE9PSBjdXJyZW50U2lnKSB7XG4gICAgICByZW1haW5pbmdUd2VldHNbdHdlZXRJZF0gPSB7IC4uLnR3ZWV0IH07XG4gICAgfVxuICB9XG5cbiAgY29uc3QgcmVtYWluaW5nQ291bnQgPSBPYmplY3Qua2V5cyhyZW1haW5pbmdUd2VldHMpLmxlbmd0aDtcbiAgaWYgKHJlbWFpbmluZ0NvdW50ID09PSAwKSB7XG4gICAgYXdhaXQgY2xlYXJSdW5CdWZmZXIoaXRlbS5oYW5kbGUpO1xuICAgIHJldHVybiAwO1xuICB9XG5cbiAgY29uc3QgbmV4dFJ1bklkID0gbmV3UnVuSWQoKTtcbiAgZm9yIChjb25zdCB0d2VldCBvZiBPYmplY3QudmFsdWVzKHJlbWFpbmluZ1R3ZWV0cykpIHtcbiAgICB0d2VldC5jYXB0dXJlX3J1bl9pZCA9IG5leHRSdW5JZDtcbiAgfVxuICBhd2FpdCBzZXRSdW5CdWZmZXIoaXRlbS5oYW5kbGUsIHtcbiAgICAuLi5jdXJyZW50LFxuICAgIHJ1bl9pZDogbmV4dFJ1bklkLFxuICAgIHN0YXJ0ZWRfYXQ6IGN1cnJlbnQubGFzdF9jYXB0dXJlX2F0LFxuICAgIHR3ZWV0c19ieV9pZDogcmVtYWluaW5nVHdlZXRzLFxuICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogY3VycmVudC50d2VldF9pZHNfb2JzZXJ2ZWQuZmlsdGVyKChpZCkgPT4gaWQgaW4gcmVtYWluaW5nVHdlZXRzKSxcbiAgfSk7XG4gIGF3YWl0IGluZm8oJ2ZsdXNoIGtlcHQgbmV3ZXIgYnVmZmVyZWQgdHdlZXRzJywge1xuICAgIGhhbmRsZTogaXRlbS5oYW5kbGUsXG4gICAgY29tbWl0dGVkX3J1bjogaXRlbS5ydW5TaG9ydCxcbiAgICBuZXh0X3J1bjogc2hvcnRSdW5JZChuZXh0UnVuSWQpLFxuICAgIHJlbWFpbmluZzogcmVtYWluaW5nQ291bnQsXG4gIH0pO1xuICByZXR1cm4gcmVtYWluaW5nQ291bnQ7XG59XG5cbi8vIC0tLSBDYXB0dXJlLW5vdyAvIGNhcHR1cmUtYWxsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gY2FwdHVyZU5vdyhoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBMYW5kIG9uIHRoZSBSZXBsaWVzIHRhYiBzbyBYIGZldGNoZXMgdmlhIFVzZXJUd2VldHNBbmRSZXBsaWVzIFx1MjAxNCB0aGF0XG4gIC8vIGVuZHBvaW50IHJldHVybnMgYm90aCB0b3AtbGV2ZWwgcG9zdHMgYW5kIHJlcGxpZXMsIHdoaWNoIGlzIHRoZSBzdXBlcnNldFxuICAvLyB3ZSB3YW50IGZvciB0aGUgYXJjaGl2ZS4gVGhlIHBsYWluIGAvPGhhbmRsZT5gIFVSTCBoaXRzIFVzZXJUd2VldHMsXG4gIC8vIHdoaWNoIG9taXRzIHJlcGxpZXMuIFRoZSBwYWdlLWhvb2sgaW50ZXJjZXB0cyBlaXRoZXIgZW5kcG9pbnQsIGJ1dFxuICAvLyBmb3JjaW5nIHRoZSBicm9hZGVyIHRhYiBvbiB1c2VyLWluaXRpYXRlZCBjYXB0dXJlcyBpcyB0aGUgcmlnaHQgZGVmYXVsdC5cbiAgY29uc3QgdGFyZ2V0VXJsID0gYGh0dHBzOi8veC5jb20vJHtoYW5kbGV9L3dpdGhfcmVwbGllc2A7XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtbm93IHJlcXVlc3RlZCcsIHsgaGFuZGxlLCB0YWI6ICd3aXRoX3JlcGxpZXMnIH0pO1xuICBpZiAoIShhd2FpdCBnZXRSdW5CdWZmZXIoaGFuZGxlKSkpIHtcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwge1xuICAgICAgcnVuX2lkOiBuZXdSdW5JZCgpLFxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICAgIHN0YXJ0ZWRfYXQ6IG5vdyxcbiAgICAgIGxhc3RfY2FwdHVyZV9hdDogbm93LFxuICAgICAgdHdlZXRzX2J5X2lkOiB7fSxcbiAgICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogW10sXG4gICAgICBlbmRwb2ludHNfc2VlbjogW10sXG4gICAgICBzb3VyY2VfdXJsOiB0YXJnZXRVcmwsXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogdGFyZ2V0VXJsLCBhY3RpdmU6IHRydWUgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVBbGwoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgYXdhaXQgaW5mbygnY2FwdHVyZS1hbGwgcmVxdWVzdGVkJywgeyBjb3VudDogYWNjb3VudHMubGVuZ3RoIH0pO1xuICBmb3IgKGNvbnN0IGEgb2YgYWNjb3VudHMpIHtcbiAgICBhd2FpdCBjYXB0dXJlTm93KGEuaGFuZGxlKTtcbiAgfVxufVxuXG4vKipcbiAqIENhcHR1cmUgd2hhdGV2ZXIgdGhlIHVzZXIgaXMgY3VycmVudGx5IGxvb2tpbmcgYXQ6IGVuc3VyZXMgcGFnZS1ob29rIGlzXG4gKiBwYXRjaGVkIGludG8gdGhlIGFjdGl2ZSB0YWIsIHRoZW4gbnVkZ2VzIHRoZSBwYWdlIHdpdGggYSBwcm9ncmFtbWF0aWNcbiAqIHNjcm9sbCBzbyBYIGZpcmVzIGFub3RoZXIgYmF0Y2ggb2YgR3JhcGhRTCByZXF1ZXN0cyB3ZSBjYW4gaW50ZXJjZXB0LlxuICpcbiAqIExlc3MgZGlzcnVwdGl2ZSB0aGFuIGBDYXB0dXJlIG5vd2AgKG5vIG5ldyB0YWIsIG5vIG5hdmlnYXRpb24pIGFuZCB3b3Jrc1xuICogZm9yIGFyYml0cmFyeSBYIFVSTHMgKHNwZWNpZmljIHR3ZWV0IHRocmVhZHMsIHNlYXJjaCByZXN1bHRzLCBsaXN0cylcbiAqIHRoYXQgZG9uJ3QgbWFwIGNsZWFubHkgdG8gb25lIG9mIHRoZSBjb25maWd1cmVkIGhhbmRsZXMuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVUaGlzUGFnZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcbiAgdHJ5IHtcbiAgICB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogY291bGQgbm90IHF1ZXJ5IGFjdGl2ZSB0YWInLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCB0YWIgPSB0YWJzWzBdO1xuICBpZiAoIXRhYiB8fCB0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJyB8fCAhdGFiLnVybCkge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBubyBhY3RpdmUgdGFiJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICghL15odHRwczpcXC9cXC8oeHx0d2l0dGVyKVxcLmNvbVxcLy8udGVzdCh0YWIudXJsKSkge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBhY3RpdmUgdGFiIGlzIG5vdCBvbiB4LmNvbSAvIHR3aXR0ZXIuY29tJywge1xuICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwpLFxuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuICBhd2FpdCBpbmZvKCdjYXB0dXJlLXRoaXMtcGFnZSByZXF1ZXN0ZWQnLCB7IHVybDogc2hvcnRlblVybCh0YWIudXJsKSB9KTtcbiAgLy8gKFJlLSlpbmplY3QgdGhlIHBhZ2UtaG9vayArIGlzb2xhdGVkIGNvbnRlbnQgc2NyaXB0IHNvIGZldGNoL1hIUiBhcmVcbiAgLy8gcGF0Y2hlZCBldmVuIG9uIHRhYnMgb3BlbmVkIGJlZm9yZSB0aGUgZXh0ZW5zaW9uIHJlbG9hZGVkLlxuICB0cnkge1xuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgIGZpbGVzOiBbJ3BhZ2UtaG9vay5qcyddLFxuICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgIH0pO1xuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgIGZpbGVzOiBbJ2NvbnRlbnQuanMnXSxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IHJlLWluamVjdCBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG4gIC8vIE51ZGdlIFggdG8gZmlyZSBtb3JlIEdyYXBoUUwgcmVxdWVzdHMgYnkgc2Nyb2xsaW5nLiBNb3N0IHRpbWVsaW5lIC9cbiAgLy8gY29udmVyc2F0aW9uIHZpZXdzIGZldGNoIG9uIGludGVyc2VjdGlvbi1vYnNlcnZlciB0cmlnZ2Vycy5cbiAgdHJ5IHtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXG4gICAgICBmdW5jOiAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGggPSB3aW5kb3cuaW5uZXJIZWlnaHQ7XG4gICAgICAgIHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuNSwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuNSwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pLCA2MDApO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuNSwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pLCAxMjAwKTtcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBzY3JvbGwtbnVkZ2UgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxufVxuXG4vLyAtLS0gUmVmZXRjaCBsb29wIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy9cbi8vIFggdHJ1bmNhdGVzIGxvbmcgdHdlZXRzIGluIHRpbWVsaW5lIHBheWxvYWRzIFx1MjAxNCBgbm90ZV90d2VldGAgaXMgb25seVxuLy8gaW5saW5lZCBmb3Igc29tZSBlbmRwb2ludHMuIFJlLW9wZW5pbmcgZWFjaCB0cnVuY2F0ZWQgdHdlZXQncyBkZXRhaWwgcGFnZVxuLy8gY2F1c2VzIHRoZSBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgZnVsbCBgbm90ZV90d2VldGAgYm9keS4gVGhlIGxvb3Bcbi8vIGRyaXZlcyB0aGF0IGJ5IG5hdmlnYXRpbmcgYSBzaW5nbGUgZGVkaWNhdGVkIHRhYiB0aHJvdWdoIHRoZSBxdWV1ZSwgb25lXG4vLyB0d2VldCBhdCBhIHRpbWUsIGdhdGVkIG9uIHRoZSBwYWdlLWhvb2sgYWN0dWFsbHkgaW5nZXN0aW5nIGEgcmVzcG9uc2UgZm9yXG4vLyB0aGUgdHdlZXQgd2UganVzdCBuYXZpZ2F0ZWQgdG8gKHNvIGRlbGV0ZWQgLyBwYXl3YWxsZWQgLyA0MDQnZCB0d2VldHNcbi8vIGRvbid0IG1ha2UgdXMgc3BpbiBhbmQgc28gd2UgZG9uJ3Qgc2xhbSBYIHdpdGggcmVmcmVzaGVzIGZhc3RlciB0aGFuIHRoZVxuLy8gdGFiIGNhbiBsb2FkKS5cblxuY29uc3QgUkVGRVRDSF9UQUJfS0VZID0gJ19faW1tX2FyY2hpdmVfcmVmZXRjaF90YWJfaWRfXyc7XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hUYWJJZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChSRUZFVENIX1RBQl9LRVkpO1xuICBjb25zdCBpZCA9IHN0b3JlZFtSRUZFVENIX1RBQl9LRVldO1xuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0UmVmZXRjaFRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChpZCA9PT0gbnVsbCkge1xuICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5yZW1vdmUoUkVGRVRDSF9UQUJfS0VZKTtcbiAgfSBlbHNlIHtcbiAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1JFRkVUQ0hfVEFCX0tFWV06IGlkIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0UmVmZXRjaExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHRvdGFsID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcbiAgaWYgKHRvdGFsID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygncmVmZXRjaDogbm90aGluZyBxdWV1ZWQnKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxuICApO1xuICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbih7XG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcbiAgICBwcm9jZXNzZWQ6IDAsXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgaW5mbGlnaHQ6IG51bGwsXG4gIH0pO1xuICBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcbiAgdm9pZCByZWZldGNoVGljaygpO1xuICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3Agc3RhcnRlZCcsIHsgcXVldWVkOiB0b3RhbCwgaW50ZXJ2YWxfc2VjOiBzZWNvbmRzIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5sZXQgcmVmZXRjaEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kczogbnVtYmVyKTogdm9pZCB7XG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcbiAgcmVmZXRjaEludGVydmFsSGFuZGxlID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgcmVmZXRjaFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ3JlZmV0Y2ggdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIH0pO1xuICB9LCBzZWNvbmRzICogMTAwMCk7XG59XG5cbmZ1bmN0aW9uIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTogdm9pZCB7XG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSk7XG4gICAgcmVmZXRjaEludGVydmFsSGFuZGxlID0gbnVsbDtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigncmVmZXRjaC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XG4gIGF3YWl0IHNldFJlZmV0Y2hUYWJJZChudWxsKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3AgY2FuY2VsbGVkJywge1xuICAgIGhhZF90YWI6IHRhYklkICE9PSBudWxsLFxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZldGNoVGljaygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBpZiAoc2VzcyA9PT0gbnVsbCkge1xuICAgIC8vIExvb3Agd2FzIGNhbmNlbGxlZCBvciBuZXZlciBzdGFydGVkOyBub3RoaW5nIHRvIGRvLlxuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gV2FpdC1mb3ItaW5nZXN0IGd1YXJkOiBpZiB3ZSdyZSBzdGlsbCBleHBlY3RpbmcgYSBjYXB0dXJlIGZvciB0aGVcbiAgLy8gcHJldmlvdXNseS1uYXZpZ2F0ZWQgdGFyZ2V0LCBvbmx5IGFkdmFuY2Ugb25jZSB3ZSd2ZSBlaXRoZXIgc2VlbiB0aGVcbiAgLy8gY2FwdHVyZSAob25HcmFwaHFsQ2FwdHVyZSBjbGVhcnMgYGluZmxpZ2h0YCkgb3IgaGl0IHRoZSB0aW1lb3V0LlxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShzZXNzLmluZmxpZ2h0Lm5hdmlnYXRlZEF0KTtcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgXHUyMDE0IHBhZ2UtaG9vayBtYXkgeWV0IGNhcHR1cmUgdGhlIHJlc3BvbnNlLlxuICAgIH1cbiAgICAvLyBUaW1lZCBvdXQuIFRyZWF0IGFzIFwidGhpcyB0YXJnZXQgd29uJ3QgaW5nZXN0XCIgYW5kIGRyb3AgaXQuXG4gICAgYXdhaXQgd2FybigncmVmZXRjaDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XG4gICAgICB0d2VldF9pZDogc2Vzcy5pbmZsaWdodC50d2VldElkLFxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxuICAgIH0pO1xuICAgIC8vIEZpbmQgd2hpY2ggaGFuZGxlIHRoaXMgaWQgaXMgcXVldWVkIHVuZGVyIHNvIHdlIGNhbiBkZXF1ZXVlIGl0LlxuICAgIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICAgIGlmIChpZHMuaW5jbHVkZXMoc2Vzcy5pbmZsaWdodC50d2VldElkKSkge1xuICAgICAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaChoYW5kbGUsIHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICB9XG5cbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dFJlZmV0Y2hUYXJnZXQoKTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBjb21wbGV0ZScsIHsgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCB9KTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHVybCA9IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmhhbmRsZX0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcbiAgbGV0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XG4gIGlmICh0YWJJZCAhPT0gbnVsbCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRhYklkID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBpZiAodGFiSWQgPT09IG51bGwpIHtcbiAgICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwsIGFjdGl2ZTogZmFsc2UgfSk7XG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicpIGF3YWl0IHNldFJlZmV0Y2hUYWJJZCh0YWIuaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcbiAgICB9XG4gICAgc2VzcyA9IChhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpKSA/PyBzZXNzO1xuICAgIHNlc3MuaW5mbGlnaHQgPSB7XG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIG5hdmlnYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoIHRpY2snLCB7XG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICByZW1haW5pbmc6IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCksXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIH0pO1xuICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHRhcmdldC5oYW5kbGUsIHRhcmdldC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbi8vIC0tLSBNZWRpYS1jcmF3bCBsb29wIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vL1xuLy8gTWlycm9ycyB0aGUgcmVmZXRjaCBsb29wIGJ1dCB0YXJnZXRzIHRoZSBtZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXRzIHRoYXRcbi8vIHRoZSBub3JtYWxpemVyIG9ic2VydmVkIHZpYSB0aGUgTWVkaWEgdGFiIC8gVXNlck1lZGlhIGVuZHBvaW50IHdpdGhcbi8vIGluc3VmZmljaWVudCBkYXRhIHRvIGJ1aWxkIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIFRoZSBjcmF3bCBsb29wIHdhbGtzXG4vLyBhIGRlZGljYXRlZCB0YWIgdGhyb3VnaCBlYWNoIHR3ZWV0J3MgZGV0YWlsIHBhZ2UgKGhhbmRsZS1sZXNzIFVSTCBmb3JtXG4vLyB3aGVuIHRoZSBoaW50LWhhbmRsZSBpcyBtaXNzaW5nKSwgYXQgdGhlIGF1dG8tc2Nyb2xsIGNhZGVuY2UsIHNvIHRoZVxuLy8gcGFnZS1ob29rIGNhbiBjYXB0dXJlIHRoZSByZWFsIHR3ZWV0IHNoYXBlLlxuXG5jb25zdCBNRURJQV9DUkFXTF9UQUJfS0VZID0gJ19faW1tX2FyY2hpdmVfbWVkaWFfY3Jhd2xfdGFiX2lkX18nO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoTUVESUFfQ1JBV0xfVEFCX0tFWSk7XG4gIGNvbnN0IGlkID0gc3RvcmVkW01FRElBX0NSQVdMX1RBQl9LRVldO1xuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChpZCA9PT0gbnVsbCkgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnJlbW92ZShNRURJQV9DUkFXTF9UQUJfS0VZKTtcbiAgZWxzZSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW01FRElBX0NSQVdMX1RBQl9LRVldOiBpZCB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRNZWRpYUNyYXdsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdG90YWwgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xuICBpZiAodG90YWwgPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogbm90aGluZyBxdWV1ZWQnKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxuICApO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbih7XG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcbiAgICBwcm9jZXNzZWQ6IDAsXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgaW5mbGlnaHQ6IG51bGwsXG4gIH0pO1xuICBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzKTtcbiAgdm9pZCBtZWRpYUNyYXdsVGljaygpO1xuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxubGV0IG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZTogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xuICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XG4gIG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIG1lZGlhQ3Jhd2xUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCdtZWRpYS1jcmF3bCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcbn1cblxuZnVuY3Rpb24gc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpOiB2b2lkIHtcbiAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwobWVkaWFDcmF3bEludGVydmFsSGFuZGxlKTtcbiAgICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbE1lZGlhQ3Jhd2xMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFRhYklkKCk7XG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZChudWxsKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcbiAgICBwcm9jZXNzZWQ6IHNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBzZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgaWYgKHNlc3MgPT09IG51bGwpIHtcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xuICAgIGlmIChlbGFwc2VkIDwgSU5HRVNUX1dBSVRfTVMpIHtcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBvbiB0aGUgcGFnZS1ob29rXG4gICAgfVxuICAgIGF3YWl0IHdhcm4oJ21lZGlhLWNyYXdsOiB0YXJnZXQgdGltZWQgb3V0IHdhaXRpbmcgZm9yIGluZ2VzdCcsIHtcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXG4gICAgICB3YWl0ZWRfbXM6IGVsYXBzZWQsXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2woc2Vzcy5pbmZsaWdodC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xuICB9XG5cbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKG51bGwpO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG51bGwpO1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gU2tpcCBpZiBhbHJlYWR5IGluIHRoZSBhcmNoaXZlIFx1MjAxNCBwYXJ0aWFsIGNhcHR1cmVzIGNhbiBvdXRsaXZlIGFcbiAgLy8gc2VwYXJhdGUgZnVsbCBjYXB0dXJlIHBhdGguXG4gIGlmIChhd2FpdCBpc0NvbW1pdHRlZCh0YXJnZXQudHdlZXRJZCkpIHtcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8vIEFsd2F5cyB1c2UgdGhlIGV4cGxpY2l0IGhhbmRsZSBVUkwgd2hlbiB3ZSBrbm93IG9uZS4gVGhlIGhhbmRsZS1sZXNzXG4gIC8vIGBpL3N0YXR1cy88aWQ+YCBmb3JtIGhhcyBzdXJmYWNlZCBhcyBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIgaW5cbiAgLy8gcHJhY3RpY2UgKFgncyByb3V0ZXIgZG9lc24ndCBhbHdheXMgcmVzb2x2ZSBpdCBmb3IgdHdlZXRzIHRoYXQgbmVlZCBhXG4gIC8vIGxvZ2luIHdhbGwgb3IgaGF2ZSBhdXRob3ItY29udGV4dCByZWRpcmVjdHMpLlxuICBjb25zdCB1cmwgPVxuICAgIHRhcmdldC5idWNrZXQgPT09ICdfdW5rbm93bidcbiAgICAgID8gYGh0dHBzOi8veC5jb20vaS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gXG4gICAgICA6IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmJ1Y2tldH0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcbiAgbGV0IHRhYklkID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFRhYklkKCk7XG4gIGlmICh0YWJJZCAhPT0gbnVsbCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRhYklkID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBpZiAodGFiSWQgPT09IG51bGwpIHtcbiAgICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwsIGFjdGl2ZTogZmFsc2UgfSk7XG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicpIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZCh0YWIuaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcbiAgICB9XG4gICAgc2VzcyA9IChhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpKSA/PyBzZXNzO1xuICAgIHNlc3MuaW5mbGlnaHQgPSB7XG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIG5hdmlnYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCB0aWNrJywge1xuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgaGludF9oYW5kbGU6IHRhcmdldC5idWNrZXQgPT09ICdfdW5rbm93bicgPyBudWxsIDogdGFyZ2V0LmJ1Y2tldCxcbiAgICAgIHJlbWFpbmluZzogYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKSxcbiAgICAgIHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQsXG4gICAgICB0b3RhbF9hdF9zdGFydDogc2Vzcy50b3RhbEF0U3RhcnQsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ21lZGlhLWNyYXdsIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIH0pO1xuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHRhcmdldC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbi8vIC0tLSBRdWFyYW50aW5lIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIHF1YXJhbnRpbmUoXG4gIHJlYXNvbjogc3RyaW5nLFxuICBlbmRwb2ludDogc3RyaW5nLFxuICB1cmw6IHN0cmluZyxcbiAgcmF3OiB1bmtub3duLFxuICBlcnI6IHVua25vd25cbik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBsb2dFcnIoJ3F1YXJhbnRpbmluZyBjYXB0dXJlJywgeyByZWFzb24sIGVuZHBvaW50LCB1cmwsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcbiAgY29uc3QgcGF5bG9hZDogUXVhcmFudGluZVBheWxvYWQgPSB7XG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gICAgcmVhc29uLFxuICAgIGVuZHBvaW50LFxuICAgIGNhcHR1cmVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgc291cmNlX3VybDogdXJsLFxuICAgIGVycm9yOiBkZXNjcmliZUVycm9yKGVyciksXG4gICAgcmF3LFxuICB9O1xuICBjb25zdCB0cyA9IGlzb0NvbXBhY3QocGF5bG9hZC5jYXB0dXJlZF9hdCk7XG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBzaGE4KEpTT04uc3RyaW5naWZ5KHBheWxvYWQpKTtcbiAgY29uc3QgcGF0aCA9IGByYXcvX3F1YXJhbnRpbmUvJHt0c30tJHtoYXNofS5qc29uYDtcbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgICBhd2FpdCBjbGllbnQucHV0RmlsZSh7XG4gICAgICBwYXRoLFxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkocGF5bG9hZCwgbnVsbCwgMikgKyAnXFxuJyksXG4gICAgICBtZXNzYWdlOiBgcXVhcmFudGluZTogJHtyZWFzb259ICR7ZW5kcG9pbnR9YCxcbiAgICB9KTtcbiAgfSBjYXRjaCAocWVycikge1xuICAgIGF3YWl0IGxvZ0VycigncXVhcmFudGluZSBjb21taXQgZmFpbGVkJywgeyAuLi5kZXNjcmliZUVycm9yKHFlcnIpIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNoYTgoczogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgYnVmID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHMpO1xuICBjb25zdCBkaWdlc3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGJ1Zik7XG4gIGNvbnN0IGhleCA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoZGlnZXN0KSlcbiAgICAubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuICAgIC5qb2luKCcnKTtcbiAgcmV0dXJuIGhleC5zbGljZSgwLCA4KTtcbn1cblxuLy8gLS0tIENvbm5lY3Rpb24gdmVyaWZpY2F0aW9uICYgYWNjb3VudHMgbGlzdCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiB2ZXJpZnlDb25uZWN0aW9uKGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSB7XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXM6ICdub3QtY29uZmlndXJlZCcsXG4gICAgICBsb2dpbjogbnVsbCxcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IG51bGwsXG4gICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgfSk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgaWYgKCFmb3JjZSkge1xuICAgIC8vIFNraXAgaWYgd2UncmUgaW5zaWRlIHRoZSByZXBvcnRlZCByYXRlLWxpbWl0IHdpbmRvdyBcdTIwMTQgcmUtY2hlY2tpbmdcbiAgICAvLyBiZWZvcmUgcmVzZXQganVzdCB3YXN0ZXMgbW9yZSBvZiB0aGUgc2FtZSBleGhhdXN0ZWQgcXVvdGEgYW5kIGtlZXBzXG4gICAgLy8gdGhlIDQwM3MgY29taW5nLlxuICAgIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcgJiYgY29ubi5yYXRlTGltaXRSZXNldEF0ICE9PSBudWxsKSB7XG4gICAgICBjb25zdCBub3dTZWMgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcbiAgICAgIGlmIChub3dTZWMgPCBjb25uLnJhdGVMaW1pdFJlc2V0QXQpIHJldHVybjtcbiAgICB9XG4gICAgLy8gQXBwbHkgdGhlIHBlcmlvZGljLWNoZWNrIGdhdGUgdG8gZXZlcnkgc3RhdHVzLCBub3QganVzdCAnb2snLiBUaGVcbiAgICAvLyBwcmV2aW91cyBiZWhhdmlvciByZS12ZXJpZmllZCBvbiBldmVyeSB3YWtlIHdoZW5ldmVyIHRoZSBjb25uZWN0aW9uXG4gICAgLy8gd2Fzbid0ICdvaycsIHdoaWNoIGR1cmluZyBhIHJhdGUtbGltaXQgd2luZG93IG1lYW50IDIgQVBJIGNhbGxzIHBlclxuICAgIC8vIFNXIHdha2UgKHZlcmlmeVJlcG9BY2Nlc3MgZG9lcyBHRVQgL3VzZXIgKyBHRVQgL3JlcG9zL3tvfS97cn0pLlxuICAgIGlmIChjb25uLmNoZWNrZWRBdCkge1xuICAgICAgY29uc3QgYWdlID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2UoY29ubi5jaGVja2VkQXQpO1xuICAgICAgaWYgKGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgY29uc3QgciA9IGF3YWl0IGNsaWVudC52ZXJpZnlSZXBvQWNjZXNzKCk7XG4gICAgLy8gUHJvYmUgdGhlIGNvbmZpZ3VyZWQgYnJhbmNoLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCBpcyBmaW5lIFx1MjAxNCBpdCdzXG4gICAgLy8gcm91dGluZSB0byBjYXB0dXJlIGludG8gYSB3b3JraW5nIGJyYW5jaCBcdTIwMTQgYnV0IGEgKm1pc3NpbmcqIGJyYW5jaFxuICAgIC8vIHdvdWxkIDQyMiBldmVyeSBjb21taXQuXG4gICAgbGV0IGJyYW5jaE9rID0gdHJ1ZTtcbiAgICBpZiAoc2V0dGluZ3MuYnJhbmNoICYmIHNldHRpbmdzLmJyYW5jaCAhPT0gci5kZWZhdWx0X2JyYW5jaCkge1xuICAgICAgYnJhbmNoT2sgPSBhd2FpdCBjbGllbnQuYnJhbmNoRXhpc3RzKHNldHRpbmdzLmJyYW5jaCk7XG4gICAgfVxuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnb2snLFxuICAgICAgbG9naW46IHIubG9naW4sXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgZGVmYXVsdEJyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGJyYW5jaE9rLFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbiAgICB9KTtcbiAgICBhd2FpdCBpbmZvKCdjb25uZWN0aW9uIHZlcmlmaWVkJywge1xuICAgICAgbG9naW46IHIubG9naW4sXG4gICAgICByZXBvOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgY29uZmlndXJlZF9icmFuY2g6IHNldHRpbmdzLmJyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRfYnJhbmNoX2V4aXN0czogYnJhbmNoT2ssXG4gICAgfSk7XG4gICAgaWYgKCFicmFuY2hPaykge1xuICAgICAgYXdhaXQgd2FybignY29uZmlndXJlZCBicmFuY2ggZG9lcyBub3QgZXhpc3Qgb24gcmVtb3RlJywge1xuICAgICAgICBjb25maWd1cmVkOiBzZXR0aW5ncy5icmFuY2gsXG4gICAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgICBmaXg6ICdvcGVuIFNldHRpbmdzIGFuZCBjaGFuZ2UgYnJhbmNoIHRvICcgKyByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgfSk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zdCBjYXQgPSBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciA/IGVyci5jYXRlZ29yeSA6ICd1bmtub3duJztcbiAgICBjb25zdCBzdGF0dXM6IENvbm5lY3Rpb25TdGF0ZVsnc3RhdHVzJ10gPVxuICAgICAgY2F0ID09PSAnYXV0aCdcbiAgICAgICAgPyAnYXV0aC1lcnJvcidcbiAgICAgICAgOiBjYXQgPT09ICdyYXRlLWxpbWl0J1xuICAgICAgICAgID8gJ3JhdGUtbGltaXRlZCdcbiAgICAgICAgICA6IGNhdCA9PT0gJ25ldHdvcmsnXG4gICAgICAgICAgICA/ICduZXR3b3JrLWVycm9yJ1xuICAgICAgICAgICAgOiAnYXV0aC1lcnJvcic7XG4gICAgY29uc3QgcmVzZXRBdCA9XG4gICAgICBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBjYXQgPT09ICdyYXRlLWxpbWl0JyA/IGVyci5yYXRlTGltaXRSZXNldEF0IDogbnVsbDtcbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1cyxcbiAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLm1lc3NhZ2UsXG4gICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXG4gICAgfSk7XG4gICAgYXdhaXQgd2FybignY29ubmVjdGlvbiBjaGVjayBmYWlsZWQnLCB7XG4gICAgICBjYXRlZ29yeTogY2F0LFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogcmVzZXRBdCxcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICB9KTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQWNjb3VudHNMaXN0KGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQpIHtcbiAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKCFmb3JjZSkge1xuICAgIC8vIFNraXAgd2hpbGUgaW5zaWRlIGEga25vd24gcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IGFjY291bnRzLnlhbWwgaXMgZmV0Y2hlZFxuICAgIC8vIHZpYSBhdXRoZW50aWNhdGVkIHJhdy5naXRodWJ1c2VyY29udGVudC5jb20sIHdoaWNoIGNvdW50cyBhZ2FpbnN0IHRoZVxuICAgIC8vIHNhbWUgcXVvdGEuXG4gICAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xuICAgICAgY29uc3Qgbm93U2VjID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gICAgICBpZiAobm93U2VjIDwgY29ubi5yYXRlTGltaXRSZXNldEF0KSByZXR1cm47XG4gICAgfVxuICAgIC8vIFNraXAgaWYgd2UgcmVmcmVzaGVkIHJlY2VudGx5LiBhY2NvdW50cy55YW1sIGNoYW5nZXMgcmFyZWx5IFx1MjAxNCB0aGUgb2xkXG4gICAgLy8gY29kZSByZS1mZXRjaGVkIGl0IG9uIGV2ZXJ5IFNXIHdha2UsIHdoaWNoIGR1cmluZyBoZWF2eSBicm93c2luZyBtZWFudFxuICAgIC8vIGEgR2l0SHViIGNhbGwgZXZlcnkgZmV3IHNlY29uZHMgZXZlbiB3aGVuIG5vdGhpbmcgd2FzIGJlaW5nIGNhcHR1cmVkLlxuICAgIGNvbnN0IGxhc3RSZWZyZXNoZWQgPSBhd2FpdCBnZXRBY2NvdW50c1JlZnJlc2hlZEF0KCk7XG4gICAgaWYgKGxhc3RSZWZyZXNoZWQpIHtcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGxhc3RSZWZyZXNoZWQpO1xuICAgICAgaWYgKE51bWJlci5pc0Zpbml0ZShhZ2UpICYmIGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IGNsaWVudC5mZXRjaFJhd1RleHQoJ2NvbmZpZy9hY2NvdW50cy55YW1sJyk7XG4gICAgaWYgKCF0ZXh0KSB7XG4gICAgICBpZiAoZm9yY2UpIGF3YWl0IHdhcm4oJ2FjY291bnRzLnlhbWwgbm90IGZvdW5kIGluIHJlcG87IHVzaW5nIGZhbGxiYWNrJyk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcGFyc2VkID0gcGFyc2VBY2NvdW50c1lhbWwodGV4dCk7XG4gICAgaWYgKHBhcnNlZC5sZW5ndGggPT09IDApIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2FjY291bnRzLnlhbWwgcGFyc2VkIGVtcHR5OyBrZWVwaW5nIGZhbGxiYWNrJyk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgYXdhaXQgc2V0QWNjb3VudHMocGFyc2VkKTtcbiAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgaWYgKGZvcmNlKSBhd2FpdCBpbmZvKCdhY2NvdW50cyBsaXN0IHJlZnJlc2hlZCcsIHsgY291bnQ6IHBhcnNlZC5sZW5ndGggfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ3JlZnJlc2ggYWNjb3VudHMgZmFpbGVkOyBrZWVwaW5nIGN1cnJlbnQgbGlzdCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuLy8gLS0tIFN0YXRlIGJyb2FkY2FzdCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBicm9hZGNhc3RTdGF0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc3RhdGUgPSBhd2FpdCBidWlsZFN0YXRlKCk7XG4gIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdzdGF0ZS1jaGFuZ2VkJywgc3RhdGUgfSkuY2F0Y2goKCkgPT4ge30pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBidWlsZFN0YXRlKCk6IFByb21pc2U8RXh0ZW5zaW9uU3RhdGU+IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgbGV0IHRhYkNvdW50ID0gMDtcbiAgdHJ5IHtcbiAgICBjb25zdCB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcbiAgICB0YWJDb3VudCA9IHRhYnMubGVuZ3RoO1xuICB9IGNhdGNoIHtcbiAgICAvLyB0YWJzLnF1ZXJ5IGlzIGFsbG93ZWQgYnkgdGhlIG1hbmlmZXN0IGJ1dCBjYW4gdHJhbnNpZW50bHkgZmFpbFxuICAgIC8vIGFyb3VuZCBleHRlbnNpb24gc3RhcnR1cDsgc3VyZmFjaW5nIDAgaXMgZmluZS5cbiAgfVxuICBjb25zdCByZWZldGNoUXVldWVkID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcbiAgY29uc3QgbWVkaWFDcmF3bFF1ZXVlZCA9IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCk7XG4gIGNvbnN0IHJlZmV0Y2hTZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBjb25zdCBhdXRvU2Nyb2xsU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gIHJldHVybiB7XG4gICAgdmVyc2lvbjogRVhUX1ZFUlNJT04sXG4gICAgc2V0dGluZ3M6IHJlZGFjdFNldHRpbmdzKHNldHRpbmdzKSxcbiAgICBjb25uZWN0aW9uOiBjb25uLFxuICAgIGFjY291bnRzLFxuICAgIGNvdW50ZXJzLFxuICAgIGF1dG9TY3JvbGw6IHtcbiAgICAgIGFjdGl2ZTogYXV0b1Njcm9sbFNlc3MgIT09IG51bGwgJiYgYXV0b1Njcm9sbFRpbWVyICE9PSBudWxsLFxuICAgICAgdGFiQ291bnQsXG4gICAgICBzY3JvbGxDb3VudDogYXV0b1Njcm9sbFNlc3M/LnNjcm9sbENvdW50ID8/IDAsXG4gICAgICBpbmdlc3RlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uaW5nZXN0ZWRDb3VudCA/PyAwLFxuICAgICAgZXhwYW5kZWRDb3VudDogYXV0b1Njcm9sbFNlc3M/LmV4cGFuZGVkQ291bnQgPz8gMCxcbiAgICB9LFxuICAgIHJlZmV0Y2hRdWV1ZToge1xuICAgICAgdG90YWw6IHJlZmV0Y2hRdWV1ZWQsXG4gICAgICBydW5uaW5nOiByZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwsXG4gICAgICBwcm9jZXNzZWQ6IHJlZmV0Y2hTZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiByZWZldGNoU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXG4gICAgfSxcbiAgICBtZWRpYUNyYXdsUXVldWU6IHtcbiAgICAgIHRvdGFsOiBtZWRpYUNyYXdsUXVldWVkLFxuICAgICAgcnVubmluZzogbWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsLFxuICAgICAgcHJvY2Vzc2VkOiBtZWRpYUNyYXdsU2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gICAgICB0b3RhbF9hdF9zdGFydDogbWVkaWFDcmF3bFNlc3M/LnRvdGFsQXRTdGFydCA/PyAwLFxuICAgIH0sXG4gIH07XG59XG5cbmZ1bmN0aW9uIHJlZGFjdFNldHRpbmdzKHM6IFNldHRpbmdzKTogRXh0ZW5zaW9uU3RhdGVbJ3NldHRpbmdzJ10ge1xuICByZXR1cm4ge1xuICAgIG93bmVyOiBzLm93bmVyLFxuICAgIHJlcG86IHMucmVwbyxcbiAgICBicmFuY2g6IHMuYnJhbmNoLFxuICAgIGVuYWJsZWQ6IHMuZW5hYmxlZCxcbiAgICBhdXRvQ2FwdHVyZTogcy5hdXRvQ2FwdHVyZSxcbiAgICBjb25maWd1cmVkQXQ6IHMuY29uZmlndXJlZEF0LFxuICAgIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogcy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMsXG4gICAgcGF0U2V0OiBzLnBhdC5sZW5ndGggPiAwLFxuICAgIHBhdFN1ZmZpeDogcy5wYXQubGVuZ3RoID49IDQgPyBzLnBhdC5zbGljZSgtNCkgOiAnJyxcbiAgfTtcbn1cblxuZnVuY3Rpb24gaXNvQ29tcGFjdChpc286IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIDIwMjUtMDQtMTJUMTQ6MjM6MDEuMDAwWiBcdTIxOTIgMjAyNS0wNC0xMlQxNDIzMDFaXG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShpc28pO1xuICBpZiAoTnVtYmVyLmlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIGlzby5yZXBsYWNlKC9bOi5dL2csICcnKTtcbiAgY29uc3QgcGFkID0gKG46IG51bWJlciwgdyA9IDIpID0+IFN0cmluZyhuKS5wYWRTdGFydCh3LCAnMCcpO1xuICByZXR1cm4gKFxuICAgIGAke2QuZ2V0VVRDRnVsbFllYXIoKX0tJHtwYWQoZC5nZXRVVENNb250aCgpICsgMSl9LSR7cGFkKGQuZ2V0VVRDRGF0ZSgpKX1gICtcbiAgICBgVCR7cGFkKGQuZ2V0VVRDSG91cnMoKSl9JHtwYWQoZC5nZXRVVENNaW51dGVzKCkpfSR7cGFkKGQuZ2V0VVRDU2Vjb25kcygpKX1aYFxuICApO1xufVxuXG5mdW5jdGlvbiB2aWV3ZXJVcmwoczogU2V0dGluZ3MpOiBzdHJpbmcge1xuICByZXR1cm4gYGh0dHBzOi8vJHtzLm93bmVyfS5naXRodWIuaW8vJHtzLnJlcG99L2A7XG59XG5cbi8qKlxuICogV2FsayBgbm9kZWAgY29sbGVjdGluZyBkb3R0ZWQga2V5IHBhdGhzIHVwIHRvIGBtYXhEZXB0aGAgZGVlcC4gQXJyYXlcbiAqIGluZGljZXMgY29sbGFwc2UgdG8gYFswXWAgKHdlIG9ubHkgZGVzY2VuZCBpbnRvIHRoZSBmaXJzdCBlbGVtZW50KS4gVXNlZFxuICogdG8gc3VyZmFjZSB0aGUgc3RydWN0dXJhbCBza2VsZXRvbiBvZiBhbiB1bmZhbWlsaWFyIEdyYXBoUUwgcmVzcG9uc2VcbiAqIHdpdGhvdXQgaW5jbHVkaW5nIGFueSBkYXRhIHZhbHVlcy5cbiAqL1xuLyoqIENvbGxlY3QgZXZlcnkgZGlzdGluY3QgYF9fdHlwZW5hbWVgIHZhbHVlIGZvdW5kIGFueXdoZXJlIGluIHRoZSB0cmVlLiAqL1xuZnVuY3Rpb24gcHJvYmVUeXBlbmFtZXMobm9kZTogdW5rbm93bik6IHN0cmluZ1tdIHtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobiA9PT0gbnVsbCB8fCB0eXBlb2YgbiAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShuKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG9iaiA9IG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBpZiAodHlwZW9mIG9iai5fX3R5cGVuYW1lID09PSAnc3RyaW5nJykgc2Vlbi5hZGQob2JqLl9fdHlwZW5hbWUpO1xuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIFsuLi5zZWVuXS5zb3J0KCk7XG59XG5cbi8qKlxuICogRmluZCB0aGUgZmlyc3Qgbm9kZSBhbnl3aGVyZSBpbiB0aGUgdHJlZSB3aG9zZSBgX190eXBlbmFtZWAgbWF0Y2hlcyBhbmRcbiAqIHJldHVybiBpdHMgdG9wLWxldmVsIGtleSBsaXN0IChzb3J0ZWQpLiBVc2VmdWwgZm9yIGRpc2NvdmVyaW5nIHdoYXQgZmllbGRzXG4gKiBYIGlzIGFjdHVhbGx5IHNoaXBwaW5nIGZvciBhIGdpdmVuIG5vZGUgdHlwZSBhZnRlciBhIHNjaGVtYSBjaGFuZ2UuXG4gKi9cbmZ1bmN0aW9uIHByb2JlRmlyc3RUeXBlU2hhcGUobm9kZTogdW5rbm93biwgdHlwZW5hbWU6IHN0cmluZyk6IHN0cmluZ1tdIHwgbnVsbCB7XG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGlmIChvYmouX190eXBlbmFtZSA9PT0gdHlwZW5hbWUpIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKG9iaikuc29ydCgpO1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKlxuICogRmluZCB0aGUgZmlyc3Qgbm9kZSB3aXRoIGBfX3R5cGVuYW1lID09PSB0eXBlbmFtZWAsIHRoZW4gZGVzY2VuZCB0aHJvdWdoXG4gKiB0aGUgZ2l2ZW4ga2V5IHBhdGgsIGFuZCByZXR1cm4gdGhlIHRvcC1sZXZlbCBrZXlzIG9mIHdoYXRldmVyIGlzIGF0IHRoZVxuICogZW5kLiBSZXR1cm5zIGEgbWFya2VyIHN0cmluZyB3aGVuIHRoZSBwYXRoIGxlYWRzIHNvbWV3aGVyZSBub24tb2JqZWN0IHNvXG4gKiB3ZSBjYW4gdGVsbCBhcGFydCBcImFic2VudFwiIGZyb20gXCJwcmVzZW50IGJ1dCBub3QgYW4gb2JqZWN0XCIuXG4gKi9cbmZ1bmN0aW9uIHByb2JlVHlwZWROZXN0ZWQobm9kZTogdW5rbm93biwgdHlwZW5hbWU6IHN0cmluZywgcGF0aDogc3RyaW5nW10pOiB1bmtub3duIHtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgbGV0IGZvdW5kOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwgPSBudWxsO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobiA9PT0gbnVsbCB8fCB0eXBlb2YgbiAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShuKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG9iaiA9IG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBpZiAob2JqLl9fdHlwZW5hbWUgPT09IHR5cGVuYW1lKSB7XG4gICAgICAgIGZvdW5kID0gb2JqO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIGlmICghZm91bmQpIHJldHVybiBudWxsO1xuICBsZXQgY3VyOiB1bmtub3duID0gZm91bmQ7XG4gIGZvciAoY29uc3Qgc2VnIG9mIHBhdGgpIHtcbiAgICBpZiAoY3VyID09PSBudWxsIHx8IHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSByZXR1cm4gYDwke2N1ciA9PT0gbnVsbCA/ICdudWxsJyA6IHR5cGVvZiBjdXJ9PmA7XG4gICAgY3VyID0gKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilbc2VnXTtcbiAgfVxuICBpZiAoY3VyID09PSB1bmRlZmluZWQpIHJldHVybiAnPG1pc3Npbmc+JztcbiAgaWYgKGN1ciA9PT0gbnVsbCkgcmV0dXJuICc8bnVsbD4nO1xuICBpZiAodHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIHJldHVybiBgPCR7dHlwZW9mIGN1cn0+YDtcbiAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkgcmV0dXJuIGA8YXJyYXkgbGVuPSR7Y3VyLmxlbmd0aH0+YDtcbiAgcmV0dXJuIE9iamVjdC5rZXlzKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuc29ydCgpO1xufVxuXG5mdW5jdGlvbiBzaG9ydGVuVXJsKHU6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIEFjdGl2aXR5LXRhaWwgY29udGV4dCBpcyBtb3JlIHVzZWZ1bCB3aXRoIGp1c3QgdGhlIHBhdGg7IGZ1bGwgVVJMcyBiZWNvbWVcbiAgLy8gaGFyZCB0byByZWFkIGF0IHRoZSBzaWRlYmFyJ3Mgd2lkdGguXG4gIHRyeSB7XG4gICAgY29uc3QgcGFyc2VkID0gbmV3IFVSTCh1KTtcbiAgICBjb25zdCBwYXRoID0gcGFyc2VkLnBhdGhuYW1lICsgKHBhcnNlZC5zZWFyY2ggPyAnP1x1MjAyNicgOiAnJyk7XG4gICAgcmV0dXJuIHBhcnNlZC5ob3N0ID09PSAneC5jb20nIHx8IHBhcnNlZC5ob3N0ID09PSAndHdpdHRlci5jb20nXG4gICAgICA/IHBhdGhcbiAgICAgIDogYCR7cGFyc2VkLmhvc3R9JHtwYXRofWA7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiB1Lmxlbmd0aCA+IDgwID8gYCR7dS5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHU7XG4gIH1cbn1cblxuLy8gLS0tIERldiBoZWxwZXJzIGV4cG9zZWQgb24gZ2xvYmFsVGhpcyBmb3IgdGhlIGRldnRvb2xzIGNvbnNvbGUgLS0tLS0tLS0tLVxuLy8gKGUuZy4gYF9faW1tQXJjaGl2ZS5jbGVhckFsbCgpYCBpbiB0aGUgYmFja2dyb3VuZCB3b3JrZXIncyBkZXZ0b29scykuXG5cbihnbG9iYWxUaGlzIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5fX2ltbUFyY2hpdmUgPSB7XG4gIGNsZWFyQWxsLFxuICBhY3Rpdml0eTogZ2V0QWN0aXZpdHksXG4gIGFjY291bnRzOiBnZXRBY2NvdW50cyxcbiAgYnVmZmVyczogZ2V0UnVuQnVmZmVycyxcbiAgZmx1c2hBbGw6ICgpID0+IGZsdXNoQWxsKCdkZXZ0b29scycpLFxuICBzdGF0ZTogYnVpbGRTdGF0ZSxcbiAgcmVmZXRjaFF1ZXVlOiBnZXRSZWZldGNoUXVldWUsXG4gIHN0YXJ0UmVmZXRjaDogc3RhcnRSZWZldGNoTG9vcCxcbiAgY2FuY2VsUmVmZXRjaDogY2FuY2VsUmVmZXRjaExvb3AsXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogZ2V0TWVkaWFDcmF3bFF1ZXVlLFxuICBzdGFydE1lZGlhQ3Jhd2w6IHN0YXJ0TWVkaWFDcmF3bExvb3AsXG4gIGNhbmNlbE1lZGlhQ3Jhd2w6IGNhbmNlbE1lZGlhQ3Jhd2xMb29wLFxufTtcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFBQSxFQUNQLE1BQU07QUFBQTtBQUFBO0FBQUEsRUFHTixRQUFRO0FBQUEsRUFDUixTQUFTO0FBQUEsRUFDVCxhQUFhO0FBQUEsRUFDYixjQUFjO0FBQUEsRUFDZCx1QkFBdUI7QUFDekI7QUFFTyxJQUFNLHNCQUFzQjtBQUM1QixJQUFNLHNCQUFzQjtBQUk1QixJQUFNLG9CQUFxQztBQUFBLEVBQ2hELEVBQUUsUUFBUSxVQUFVLE9BQU8sbUNBQW1DLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxVQUFVLE9BQU8sNENBQTRDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxPQUFPLE9BQU8sc0NBQXNDLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxTQUFTLE9BQU8sNkNBQTZDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxjQUFjLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUFBLEVBQ25FLEVBQUUsUUFBUSxZQUFZLE9BQU8sK0JBQStCLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sa0NBQWtDLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sNEJBQTRCLFVBQVUsT0FBTztBQUFBLEVBQ3ZFLEVBQUUsUUFBUSxtQkFBbUIsT0FBTyxxQkFBcUIsVUFBVSxPQUFPO0FBQzVFO0FBR08sSUFBTSxrQkFBdUMsb0JBQUksSUFBSTtBQUFBLEVBQzFEO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBV00sSUFBTSxvQkFBeUMsb0JBQUksSUFBSSxDQUFDLG9CQUFvQixjQUFjLENBQUM7QUF1QjNGLElBQU0sd0JBQXdCO0FBRzlCLElBQU0sZ0JBQWdCO0FBR3RCLElBQU0sc0JBQXNCO0FBRzVCLElBQU0sb0JBQW9CO0FBRzFCLElBQU0sZ0NBQWdDLEtBQUssS0FBSztBQUVoRCxJQUFNLG1CQUFtQjs7O0FDdEVoQyxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGtCQUFrQjtBQUV4QixJQUFJLGtCQUFvQztBQUN4QyxJQUFJLHNCQUFxQztBQUV6QyxTQUFTLFNBQVMsS0FBeUI7QUFDekMsTUFBSSxJQUFJO0FBQ1IsYUFBVyxLQUFLLElBQUssTUFBSyxPQUFPLGFBQWEsQ0FBQztBQUMvQyxTQUFPLEtBQUssQ0FBQztBQUNmO0FBRUEsU0FBUyxXQUFXLEdBQXVCO0FBQ3pDLFFBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsUUFBTSxNQUFNLElBQUksV0FBVyxJQUFJLE1BQU07QUFDckMsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsSUFBSyxLQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQztBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxlQUFlLG1CQUFtRTtBQUNoRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUMvRCxRQUFNLElBQUksT0FBTyxnQkFBZ0I7QUFDakMsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxXQUFPLEVBQUUsU0FBUyxHQUFHLE1BQU0sV0FBVyxDQUFDLEVBQUU7QUFBQSxFQUMzQztBQUNBLFFBQU0sT0FBTyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxTQUFTLElBQUk7QUFDN0IsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUM7QUFDL0QsU0FBTyxFQUFFLFNBQVMsS0FBSztBQUN6QjtBQUVBLGVBQWUsWUFBZ0M7QUFDN0MsUUFBTSxFQUFFLFNBQVMsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBQ2pELE1BQUksb0JBQW9CLFFBQVEsd0JBQXdCLFNBQVM7QUFDL0QsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUU7QUFBQSxJQUM3QixHQUFHLFFBQVEsUUFBUSxFQUFFLElBQUksUUFBUSxRQUFRLFlBQVksRUFBRSxPQUFPO0FBQUEsRUFDaEU7QUFDQSxRQUFNLFdBQVcsSUFBSSxXQUFXLEtBQUssU0FBUyxLQUFLLE1BQU07QUFDekQsV0FBUyxJQUFJLE1BQU0sQ0FBQztBQUNwQixXQUFTLElBQUksTUFBTSxLQUFLLE1BQU07QUFDOUIsUUFBTSxPQUFPLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxRQUFRO0FBQzNELFFBQU0sTUFBTSxNQUFNLE9BQU8sT0FBTyxVQUFVLE9BQU8sTUFBTSxFQUFFLE1BQU0sVUFBVSxHQUFHLE9BQU87QUFBQSxJQUNqRjtBQUFBLElBQ0E7QUFBQSxFQUNGLENBQUM7QUFDRCxvQkFBa0I7QUFDbEIsd0JBQXNCO0FBQ3RCLFNBQU87QUFDVDtBQUVPLFNBQVMsZUFBZSxHQUFvQjtBQUNqRCxTQUFPLEVBQUUsV0FBVyxlQUFlO0FBQ3JDO0FBRUEsZUFBc0IsV0FBVyxXQUFvQztBQUNuRSxNQUFJLENBQUMsVUFBVyxRQUFPO0FBQ3ZCLFFBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsUUFBTSxLQUFLLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDcEQsUUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsSUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBRztBQUFBLElBQ3RCO0FBQUEsSUFDQSxJQUFJLFlBQVksRUFBRSxPQUFPLFNBQVM7QUFBQSxFQUNwQztBQUNBLFNBQU8sR0FBRyxlQUFlLEdBQUcsU0FBUyxFQUFFLENBQUMsSUFBSSxTQUFTLElBQUksV0FBVyxFQUFFLENBQUMsQ0FBQztBQUMxRTtBQUVBLGVBQXNCLFdBQVcsVUFBbUM7QUFDbEUsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUd0QixNQUFJLENBQUMsU0FBUyxXQUFXLGVBQWUsRUFBRyxRQUFPO0FBQ2xELFFBQU0sUUFBUSxTQUFTLE1BQU0sZ0JBQWdCLE1BQU0sRUFBRSxNQUFNLEdBQUc7QUFDOUQsTUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBQy9CLFFBQU0sQ0FBQyxPQUFPLEtBQUssSUFBSTtBQUN2QixNQUFJLENBQUMsU0FBUyxDQUFDLE1BQU8sUUFBTztBQUM3QixNQUFJO0FBQ0YsVUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsTUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBdUI7QUFBQSxNQUMxQztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsV0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEVBQUU7QUFBQSxFQUNwQyxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjs7O0FDNUJBLElBQU0scUJBQXNDO0FBQUEsRUFDMUMsUUFBUTtBQUFBLEVBQ1IsT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUFBLEVBQ1AsZUFBZTtBQUFBLEVBQ2Ysd0JBQXdCO0FBQUEsRUFDeEIsa0JBQWtCO0FBQ3BCO0FBRUEsSUFBTSxXQUF5QjtBQUFBLEVBQzdCLFVBQVUsRUFBRSxHQUFHLGlCQUFpQjtBQUFBLEVBQ2hDLFVBQVUsQ0FBQyxHQUFHLGlCQUFpQjtBQUFBLEVBQy9CLHFCQUFxQjtBQUFBLEVBQ3JCLFlBQVksRUFBRSxHQUFHLG1CQUFtQjtBQUFBLEVBQ3BDLFVBQVUsQ0FBQztBQUFBLEVBQ1gsWUFBWSxDQUFDO0FBQUEsRUFDYixVQUFVLENBQUM7QUFBQSxFQUNYLGdCQUFnQixDQUFDO0FBQUEsRUFDakIsY0FBYyxDQUFDO0FBQUEsRUFDZixpQkFBaUIsQ0FBQztBQUFBLEVBQ2xCLGdCQUFnQjtBQUFBLEVBQ2hCLG1CQUFtQjtBQUFBLEVBQ25CLG1CQUFtQjtBQUNyQjtBQUVBLGVBQWUsT0FBcUMsS0FBa0M7QUFDcEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxHQUFHO0FBQ2xELFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsTUFBSSxVQUFVLFFBQVc7QUFDdkIsV0FBTyxnQkFBZ0IsU0FBUyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUNBLFNBQU87QUFDVDtBQUVBLGVBQWUsT0FBcUMsS0FBUSxPQUF1QztBQUNqRyxRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUM7QUFDbEQ7QUFJQSxlQUFzQixjQUFpQztBQUtyRCxRQUFNLFNBQVMsTUFBTSxPQUFPLFVBQVU7QUFDdEMsUUFBTSxTQUFTLEVBQUUsR0FBRyxrQkFBa0IsR0FBRyxPQUFPO0FBQ2hELE1BQUksT0FBTyxPQUFPLGVBQWUsT0FBTyxHQUFHLEdBQUc7QUFDNUMsUUFBSTtBQUNGLGFBQU8sTUFBTSxNQUFNLFdBQVcsT0FBTyxHQUFHO0FBQUEsSUFDMUMsUUFBUTtBQUNOLGFBQU8sTUFBTTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsWUFBWSxHQUE0QjtBQUc1RCxRQUFNLFVBQW9CLEVBQUUsR0FBRyxFQUFFO0FBQ2pDLE1BQUksUUFBUSxPQUFPLENBQUMsZUFBZSxRQUFRLEdBQUcsR0FBRztBQUMvQyxZQUFRLE1BQU0sTUFBTSxXQUFXLFFBQVEsR0FBRztBQUFBLEVBQzVDO0FBQ0EsUUFBTSxPQUFPLFlBQVksT0FBTztBQUNsQztBQUNBLGVBQXNCLGVBQWUsT0FBNkM7QUFDaEYsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE9BQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hDLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFNBQU87QUFDVDtBQUlBLGVBQXNCLGNBQXdDO0FBQzVELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFBWSxHQUFtQztBQUNuRSxRQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzVCO0FBQ0EsZUFBc0IseUJBQWlEO0FBQ3JFLFNBQU8sT0FBTyxxQkFBcUI7QUFDckM7QUFDQSxlQUFzQix1QkFBdUIsS0FBbUM7QUFDOUUsUUFBTSxPQUFPLHVCQUF1QixHQUFHO0FBQ3pDO0FBSUEsZUFBc0IsZ0JBQTBDO0FBQzlELFFBQU0sSUFBSSxNQUFNLE9BQU8sWUFBWTtBQUVuQyxRQUFNLE1BQXVCO0FBQUEsSUFDM0IsR0FBRztBQUFBLElBQ0gsZUFBZSxFQUFFLGtCQUFrQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3hELHdCQUNFLEVBQUUsMkJBQTJCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDcEQsa0JBQWtCLEVBQUUscUJBQXFCLFNBQVksT0FBTyxFQUFFO0FBQUEsRUFDaEU7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixjQUFjLEdBQW1DO0FBQ3JFLFFBQU0sT0FBTyxjQUFjLENBQUM7QUFDOUI7QUFJQSxTQUFTLFdBQW1CO0FBQzFCLFVBQU8sb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUM3QztBQUVBLGVBQXNCLGNBQXVEO0FBQzNFLFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFDcEIsUUFDQSxPQUN5QjtBQUN6QixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sTUFBTSxJQUFJLE1BQU0sS0FBSztBQUFBLElBQ3pCLFlBQVk7QUFBQSxJQUNaLFdBQVcsU0FBUztBQUFBLElBQ3BCLGVBQWU7QUFBQSxJQUNmLGdCQUFnQjtBQUFBLElBQ2hCLGVBQWU7QUFBQSxFQUNqQjtBQUNBLE1BQUksSUFBSSxjQUFjLFNBQVMsR0FBRztBQUNoQyxRQUFJLFlBQVksU0FBUztBQUN6QixRQUFJLGFBQWE7QUFBQSxFQUNuQjtBQUNBLFFBQU0sT0FBdUIsRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hELE1BQUksTUFBTSxJQUFJO0FBQ2QsUUFBTSxPQUFPLFlBQVksR0FBRztBQUM1QixTQUFPO0FBQ1Q7QUFFQSxlQUFzQixpQkFBaUIsUUFBZ0IsT0FBOEI7QUFDbkYsUUFBTSxZQUFZLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztBQUNwRDtBQUlBLGVBQXNCLGdCQUFvRDtBQUN4RSxTQUFPLE9BQU8sWUFBWTtBQUM1QjtBQUVBLGVBQXNCLGFBQWEsUUFBMkM7QUFDNUUsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxTQUFPLElBQUksTUFBTSxLQUFLO0FBQ3hCO0FBRUEsZUFBc0IsYUFBYSxRQUFnQixLQUErQjtBQUNoRixRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLE1BQUksTUFBTSxJQUFJO0FBQ2QsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUVBLGVBQXNCLGVBQWUsUUFBK0I7QUFDbEUsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxTQUFPLElBQUksTUFBTTtBQUNqQixRQUFNLE9BQU8sY0FBYyxHQUFHO0FBQ2hDO0FBSUEsZUFBc0IsY0FBbUM7QUFDdkQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFFQSxlQUFzQixlQUFlLElBQW1DO0FBQ3RFLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsTUFBSSxRQUFRLEVBQUU7QUFDZCxNQUFJLElBQUksU0FBUyxrQkFBbUIsS0FBSSxTQUFTO0FBQ2pELFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsZ0JBQStCO0FBQ25ELFFBQU0sT0FBTyxZQUFZLENBQUMsQ0FBQztBQUM3QjtBQUlBLGVBQXNCLG9CQUE2RTtBQUNqRyxTQUFPLE9BQU8sZ0JBQWdCO0FBQ2hDO0FBRUEsZUFBc0Isa0JBQ3BCLEtBQ2U7QUFDZixRQUFNLE9BQU8sa0JBQWtCLEdBQUc7QUFDcEM7QUFVTyxTQUFTLGNBQ2QsT0FDQSxVQUNBLFNBQ0EsUUFDQSxjQUF1QixPQUNmO0FBQ1IsU0FBTyxHQUFHLEtBQUssSUFBSSxRQUFRLElBQUksT0FBTyxJQUFJLE1BQU0sSUFBSSxjQUFjLE1BQU0sR0FBRztBQUM3RTtBQUdBLGVBQXNCLG9CQUFvQixVQUFtQztBQUMzRSxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsUUFBTSxTQUFTLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxRQUFRLEVBQUUsWUFBWTtBQUMzRCxNQUFJLFNBQVM7QUFDYixhQUFXLFVBQVUsT0FBTyxLQUFLLEdBQUcsR0FBRztBQUNyQyxVQUFNLFFBQVEsSUFBSSxNQUFNO0FBQ3hCLFFBQUksQ0FBQyxNQUFPO0FBQ1osZUFBVyxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDcEMsWUFBTSxJQUFJLE1BQU0sR0FBRztBQUNuQixVQUFJLEtBQUssRUFBRSxLQUFLLFFBQVE7QUFDdEIsZUFBTyxNQUFNLEdBQUc7QUFDaEIsa0JBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxLQUFLLEtBQUssRUFBRSxXQUFXLEVBQUcsUUFBTyxJQUFJLE1BQU07QUFBQSxFQUN4RDtBQUNBLE1BQUksU0FBUyxFQUFHLE9BQU0sa0JBQWtCLEdBQUc7QUFDM0MsU0FBTztBQUNUO0FBSUEsZUFBc0Isa0JBQXFEO0FBQ3pFLFNBQU8sT0FBTyxjQUFjO0FBQzlCO0FBRUEsZUFBc0Isb0JBQXFDO0FBQ3pELFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0IsZUFBZSxRQUFnQixTQUFnQztBQUNuRixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsUUFBTSxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDMUIsTUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUc7QUFDMUIsUUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBRSxNQUFNLElBQUk7QUFDWixVQUFNLE9BQU8sZ0JBQWdCLENBQUM7QUFBQSxFQUNoQztBQUNGO0FBRUEsZUFBc0IsZUFBZSxRQUFnQixTQUFnQztBQUNuRixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsUUFBTSxNQUFNLEVBQUUsTUFBTTtBQUNwQixNQUFJLENBQUMsSUFBSztBQUNWLFFBQU0sV0FBVyxJQUFJLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTztBQUNsRCxNQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNO0FBQUEsTUFDckMsR0FBRSxNQUFNLElBQUk7QUFDakIsUUFBTSxPQUFPLGdCQUFnQixDQUFDO0FBQ2hDO0FBRUEsZUFBc0Isb0JBR1o7QUFDUixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFHO0FBQUEsRUFDeEQ7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixxQkFBd0Q7QUFDNUUsU0FBTyxPQUFPLGlCQUFpQjtBQUNqQztBQUVBLGVBQXNCLHVCQUF3QztBQUM1RCxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxRQUFRO0FBQ1osYUFBVyxPQUFPLE9BQU8sT0FBTyxDQUFDLEVBQUcsVUFBUyxJQUFJO0FBQ2pELFNBQU87QUFDVDtBQUVBLGVBQXNCLGtCQUFrQixZQUEyQixTQUFnQztBQUNqRyxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsUUFBTSxTQUFTLGNBQWM7QUFDN0IsUUFBTSxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDMUIsTUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUc7QUFDMUIsUUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBRSxNQUFNLElBQUk7QUFDWixVQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFBQSxFQUNuQztBQUNGO0FBRUEsZUFBc0Isa0JBQWtCLFNBQWdDO0FBQ3RFLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFVBQVU7QUFDZCxhQUFXLFVBQVUsT0FBTyxLQUFLLENBQUMsR0FBRztBQUNuQyxVQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsVUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELFFBQUksU0FBUyxXQUFXLElBQUksUUFBUTtBQUNsQyxnQkFBVTtBQUNWLFVBQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxVQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLE1BQUksUUFBUyxPQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFDaEQ7QUFFQSxlQUFzQix1QkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLFlBQVksU0FBbUM7QUFDbkUsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLGFBQVcsU0FBUyxPQUFPLE9BQU8sR0FBRyxHQUFHO0FBQ3RDLFFBQUksU0FBUyxXQUFXLE1BQU8sUUFBTztBQUFBLEVBQ3hDO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0Isb0JBQWlEO0FBQ3JFLFNBQU8sT0FBTyxnQkFBZ0I7QUFDaEM7QUFDQSxlQUFzQixrQkFBa0IsR0FBc0M7QUFDNUUsUUFBTSxPQUFPLGtCQUFrQixDQUFDO0FBQ2xDO0FBQ0EsZUFBc0IsdUJBQW9EO0FBQ3hFLFNBQU8sT0FBTyxtQkFBbUI7QUFDbkM7QUFDQSxlQUFzQixxQkFBcUIsR0FBc0M7QUFDL0UsUUFBTSxPQUFPLHFCQUFxQixDQUFDO0FBQ3JDO0FBQ0EsZUFBc0IsdUJBQTBEO0FBQzlFLFNBQU8sT0FBTyxtQkFBbUI7QUFDbkM7QUFDQSxlQUFzQixxQkFBcUIsR0FBNEM7QUFDckYsUUFBTSxPQUFPLHFCQUFxQixDQUFDO0FBQ3JDO0FBWUEsZUFBc0Isb0JBQW9CLFVBTXZDO0FBQ0QsUUFBTSxZQUFZLElBQUksSUFBSSxDQUFDLEdBQUcsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDbkUsUUFBTSxhQUFhLENBQUMsTUFBdUIsVUFBVSxJQUFJLEVBQUUsWUFBWSxDQUFDO0FBR3hFLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxrQkFBa0I7QUFDdEIsYUFBVyxLQUFLLE9BQU8sS0FBSyxRQUFRLEdBQUc7QUFDckMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sU0FBUyxDQUFDO0FBQ2pCLHlCQUFtQjtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxZQUFZLFFBQVE7QUFHakMsUUFBTSxVQUFVLE1BQU0sY0FBYztBQUNwQyxNQUFJLGlCQUFpQjtBQUNyQixhQUFXLEtBQUssT0FBTyxLQUFLLE9BQU8sR0FBRztBQUNwQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxRQUFRLENBQUM7QUFDaEIsd0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLGNBQWMsT0FBTztBQUdsQyxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsTUFBSSwwQkFBMEI7QUFDOUIsYUFBVyxLQUFLLE9BQU8sS0FBSyxHQUFHLEdBQUc7QUFDaEMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sSUFBSSxDQUFDO0FBQ1osaUNBQTJCO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxrQkFBa0IsR0FBRztBQUczQixRQUFNLEtBQUssTUFBTSxnQkFBZ0I7QUFDakMsTUFBSSx3QkFBd0I7QUFDNUIsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sR0FBRyxDQUFDO0FBQ1gsK0JBQXlCO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLGdCQUFnQixFQUFFO0FBSy9CLFFBQU0sS0FBSyxNQUFNLG1CQUFtQjtBQUNwQyxNQUFJLHVCQUF1QjtBQUMzQixhQUFXLEtBQUssT0FBTyxLQUFLLEVBQUUsR0FBRztBQUMvQixRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsK0JBQXlCLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRztBQUN0QyxhQUFPLEdBQUcsQ0FBQztBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLG1CQUFtQixFQUFFO0FBRWxDLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUlBLGVBQXNCLFdBQTBCO0FBQzlDLFFBQU0sUUFBUSxRQUFRLE1BQU0sTUFBTTtBQUNwQzs7O0FDcGhCQSxJQUFJLFlBQTZDO0FBRTFDLFNBQVMsZUFBZSxJQUFrQztBQUMvRCxjQUFZO0FBQ2Q7QUFFQSxTQUFTLFNBQWlCO0FBQ3hCLFVBQU8sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDaEM7QUFFQSxlQUFlLEtBQUssT0FBaUIsS0FBYSxTQUFpRDtBQUNqRyxRQUFNLEtBQWUsRUFBRSxJQUFJLE9BQU8sR0FBRyxPQUFPLEtBQUssU0FBUyxPQUFPLE9BQU8sRUFBRTtBQUUxRSxRQUFNLE9BQU8saUJBQWlCLE1BQU0sWUFBWSxDQUFDLElBQUksR0FBRztBQUN4RCxNQUFJLFVBQVUsUUFBUyxTQUFRLE1BQU0sTUFBTSxHQUFHLE9BQU87QUFBQSxXQUM1QyxVQUFVLE9BQVEsU0FBUSxLQUFLLE1BQU0sR0FBRyxPQUFPO0FBQUEsTUFDbkQsU0FBUSxJQUFJLE1BQU0sR0FBRyxPQUFPO0FBRWpDLE1BQUk7QUFDRixVQUFNLGVBQWUsRUFBRTtBQUFBLEVBQ3pCLFNBQVMsS0FBSztBQUNaLFlBQVEsS0FBSywyQ0FBMkMsR0FBRztBQUFBLEVBQzdEO0FBRUEsTUFBSTtBQUNGLGdCQUFZLEVBQUU7QUFBQSxFQUNoQixRQUFRO0FBQUEsRUFFUjtBQUNGO0FBRU8sU0FBUyxLQUFLLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN0RixTQUFPLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDbEM7QUFDTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsTUFBTSxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdkYsU0FBTyxLQUFLLFNBQVMsS0FBSyxPQUFPO0FBQ25DO0FBRU8sU0FBUyxjQUFjLEtBQXlEO0FBQ3JGLE1BQUksZUFBZSxPQUFPO0FBQ3hCLFdBQU8sRUFBRSxTQUFTLElBQUksU0FBUyxPQUFPLElBQUksU0FBUyxLQUFLO0FBQUEsRUFDMUQ7QUFDQSxNQUFJO0FBQ0YsV0FBTyxFQUFFLFNBQVMsT0FBTyxHQUFHLEdBQUcsT0FBTyxLQUFLO0FBQUEsRUFDN0MsUUFBUTtBQUNOLFdBQU8sRUFBRSxTQUFTLHVCQUF1QixPQUFPLEtBQUs7QUFBQSxFQUN2RDtBQUNGO0FBT0EsU0FBUyxPQUFPLEtBQXVEO0FBQ3JFLFFBQU0sTUFBK0IsQ0FBQztBQUN0QyxhQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUN4QyxRQUFJLEVBQUUsWUFBWSxFQUFFLFNBQVMsT0FBTyxLQUFLLEVBQUUsWUFBWSxNQUFNLFNBQVMsTUFBTSxpQkFBaUI7QUFDM0YsVUFBSSxDQUFDLElBQUk7QUFBQSxJQUNYLFdBQVcsT0FBTyxNQUFNLFlBQVksK0JBQStCLEtBQUssQ0FBQyxHQUFHO0FBQzFFLFVBQUksQ0FBQyxJQUFJLEVBQUUsUUFBUSw2QkFBNkIsdUJBQXVCO0FBQUEsSUFDekUsV0FBVyxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsTUFBTTtBQUNuRCxVQUFJLENBQUMsSUFBSSxHQUFHLEVBQUUsTUFBTSxHQUFHLElBQUksQ0FBQztBQUFBLElBQzlCLE9BQU87QUFDTCxVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1g7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUOzs7QUN2RUEsSUFBTSxXQUFXO0FBQ2pCLElBQU0sV0FBVztBQStCVixJQUFNLGNBQU4sY0FBMEIsTUFBTTtBQUFBLEVBQ3JDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFJQTtBQUFBLEVBRUEsWUFBWSxNQU9UO0FBQ0QsVUFBTSxLQUFLLE9BQU87QUFDbEIsU0FBSyxPQUFPO0FBQ1osU0FBSyxTQUFTLEtBQUs7QUFDbkIsU0FBSyxPQUFPLEtBQUs7QUFDakIsU0FBSyxZQUFZLEtBQUs7QUFDdEIsU0FBSyxXQUFXLEtBQUs7QUFDckIsU0FBSyxtQkFBbUIsS0FBSyxvQkFBb0I7QUFBQSxFQUNuRDtBQUNGO0FBRU8sSUFBTSxlQUFOLE1BQW1CO0FBQUEsRUFDUDtBQUFBLEVBRWpCLFlBQVksVUFBb0I7QUFDOUIsU0FBSyxXQUFXO0FBQUEsRUFDbEI7QUFBQTtBQUFBLEVBR0EsTUFBTSxTQUEwQjtBQUM5QixVQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQy9DLFdBQVEsSUFBMkIsU0FBUztBQUFBLEVBQzlDO0FBQUE7QUFBQSxFQUdBLE1BQU0sYUFBYSxRQUFrQztBQUNuRCxRQUFJO0FBQ0YsWUFBTSxLQUFLO0FBQUEsUUFDVDtBQUFBLFFBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLGFBQWEsbUJBQW1CLE1BQU0sQ0FBQztBQUFBLE1BQzVGO0FBQ0EsYUFBTztBQUFBLElBQ1QsU0FBUyxLQUFLO0FBQ1osVUFBSSxlQUFlLGVBQWUsSUFBSSxhQUFhLFlBQWEsUUFBTztBQUN2RSxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQTtBQUFBLEVBR0EsTUFBTSxtQkFBMEY7QUFDOUYsVUFBTSxLQUFLLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTztBQUM5QyxVQUFNLE9BQU8sTUFBTSxLQUFLLFVBQVUsT0FBTyxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksRUFBRTtBQUM5RixVQUFNLElBQUk7QUFDVixXQUFPO0FBQUEsTUFDTCxPQUFRLEdBQXlCO0FBQUEsTUFDakMsV0FBVyxFQUFFO0FBQUEsTUFDYixnQkFBZ0IsRUFBRTtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLGFBQWEsWUFBNEM7QUFDN0QsVUFBTSxNQUFNLEdBQUcsUUFBUSxJQUFJLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFNBQVMsTUFBTSxJQUFJLFVBQVU7QUFDMUcsVUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDM0IsUUFBUTtBQUFBLE1BQ1IsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQUEsSUFDMUQsQ0FBQztBQUNELFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLFVBQVUsS0FBSyxXQUFXLFVBQVUsRUFBRTtBQUNwRSxXQUFPLElBQUksS0FBSztBQUFBLEVBQ2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sV0FBVyxNQUFzQztBQUNyRCxRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLFFBQ3JCO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQyxRQUFRLG1CQUFtQixLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDbEk7QUFDQSxZQUFNLElBQUk7QUFDVixhQUFPLEVBQUUsT0FBTztBQUFBLElBQ2xCLFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxRQUFRLE1BQThDO0FBQzFELFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sTUFBTSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQztBQUM1RixRQUFJLE1BQXFCLEtBQUssZUFBZTtBQUM3QyxVQUFNLGNBQWM7QUFFcEIsYUFBUyxVQUFVLEdBQUcsV0FBVyxhQUFhLFdBQVc7QUFDdkQsWUFBTSxPQUFnQztBQUFBLFFBQ3BDLFNBQVMsS0FBSztBQUFBLFFBQ2QsU0FBUyxLQUFLO0FBQUEsUUFDZCxRQUFRLEtBQUssU0FBUztBQUFBLE1BQ3hCO0FBQ0EsVUFBSSxJQUFLLE1BQUssTUFBTTtBQUNwQixVQUFJO0FBQ0YsY0FBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sS0FBSyxJQUFJO0FBQ2pELGNBQU0sTUFBTTtBQUNaLGVBQU8sRUFBRSxNQUFNLElBQUksUUFBUSxNQUFNLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLFFBQVEsU0FBUztBQUFBLE1BQ25GLFNBQVMsS0FBSztBQUNaLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFJLElBQUksV0FBVyxPQUFPLENBQUMsS0FBSztBQUU5QixnQkFBTSxNQUFNLEtBQUssV0FBVyxJQUFJO0FBQ2hDLGNBQUksQ0FBQyxJQUFLLE9BQU07QUFDaEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxDQUFDLElBQUksYUFBYSxZQUFZLFlBQWEsT0FBTTtBQUNyRCxjQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sSUFBSSxNQUFNLG1DQUFtQyxJQUFJLEVBQUU7QUFBQSxFQUMzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxNQUFNLFlBQVksTUFBc0Q7QUFDdEUsUUFBSSxLQUFLLE1BQU0sV0FBVyxFQUFHLE9BQU0sSUFBSSxNQUFNLGlDQUFpQztBQUM5RSxVQUFNLGNBQWM7QUFDcEIsUUFBSSxVQUFtQjtBQUV2QixhQUFTLFVBQVUsR0FBRyxXQUFXLGFBQWEsV0FBVztBQUN2RCxVQUFJO0FBQ0YsY0FBTSxRQUFRLE1BQU0sUUFBUTtBQUFBLFVBQzFCLEtBQUssTUFBTSxJQUFJLE9BQU8sU0FBUztBQUM3QixrQkFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLGNBQ3JCO0FBQUEsY0FDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxjQUNuRDtBQUFBLGdCQUNFLFNBQVMsS0FBSztBQUFBLGdCQUNkLFVBQVU7QUFBQSxjQUNaO0FBQUEsWUFDRjtBQUNBLG1CQUFPO0FBQUEsY0FDTCxNQUFNLEtBQUs7QUFBQSxjQUNYLEtBQU0sSUFBd0I7QUFBQSxZQUNoQztBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFFQSxjQUFNLE9BQU8sTUFBTSxLQUFLLGNBQWM7QUFDdEMsY0FBTSxPQUFPLE1BQU0sS0FBSztBQUFBLFVBQ3RCO0FBQUEsVUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxVQUNuRDtBQUFBLFlBQ0UsV0FBVyxLQUFLO0FBQUEsWUFDaEIsTUFBTSxNQUFNLElBQUksQ0FBQyxVQUFVO0FBQUEsY0FDekIsTUFBTSxLQUFLO0FBQUEsY0FDWCxNQUFNO0FBQUEsY0FDTixNQUFNO0FBQUEsY0FDTixLQUFLLEtBQUs7QUFBQSxZQUNaLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUNBLGNBQU0sVUFBVyxLQUF5QjtBQUMxQyxjQUFNLFNBQVMsTUFBTSxLQUFLO0FBQUEsVUFDeEI7QUFBQSxVQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLFVBQ25EO0FBQUEsWUFDRSxTQUFTLEtBQUs7QUFBQSxZQUNkLE1BQU07QUFBQSxZQUNOLFNBQVMsQ0FBQyxLQUFLLEdBQUc7QUFBQSxVQUNwQjtBQUFBLFFBQ0Y7QUFDQSxjQUFNLFlBQVk7QUFDbEIsWUFBSTtBQUNGLGdCQUFNLEtBQUs7QUFBQSxZQUNUO0FBQUEsWUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksbUJBQW1CLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLFlBQ3RHO0FBQUEsY0FDRSxLQUFLLFVBQVU7QUFBQSxjQUNmLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0YsU0FBUyxLQUFLO0FBQ1osY0FBSSxXQUFXLEdBQUcsS0FBSyxVQUFVLGFBQWE7QUFDNUMsc0JBQVU7QUFDVixrQkFBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFDbkM7QUFBQSxVQUNGO0FBQ0EsZ0JBQU07QUFBQSxRQUNSO0FBQ0EsZUFBTztBQUFBLFVBQ0wsV0FBVyxVQUFVO0FBQUEsVUFDckIsS0FBSyxVQUFVO0FBQUEsVUFDZixPQUFPLEtBQUssTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUk7QUFBQSxRQUMzQztBQUFBLE1BQ0YsU0FBUyxLQUFLO0FBQ1osa0JBQVU7QUFDVixZQUFJLEVBQUUsZUFBZSxhQUFjLE9BQU07QUFDekMsWUFBSyxDQUFDLElBQUksYUFBYSxDQUFDLFdBQVcsR0FBRyxLQUFNLFlBQVksWUFBYSxPQUFNO0FBQzNFLGNBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxtQkFBbUIsUUFBUSxVQUFVLElBQUksTUFBTSxpQ0FBaUM7QUFBQSxFQUN4RjtBQUFBLEVBRUEsTUFBYyxnQkFBMkQ7QUFDdkUsVUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLE1BQ3JCO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksa0JBQWtCLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLElBQ3ZHO0FBQ0EsVUFBTSxVQUFXLElBQW9DLE9BQU87QUFDNUQsVUFBTSxTQUFTLE1BQU0sS0FBSztBQUFBLE1BQ3hCO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksZ0JBQWdCLE9BQU87QUFBQSxJQUM1RTtBQUNBLFdBQU87QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLFNBQVUsT0FBcUMsS0FBSztBQUFBLElBQ3REO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBYyxVQUFVLFFBQWdCLE1BQWMsTUFBa0M7QUFDdEYsVUFBTSxNQUFNLEtBQUssV0FBVyxNQUFNLElBQUksT0FBTyxHQUFHLFFBQVEsR0FBRyxJQUFJO0FBQy9ELFVBQU0sT0FBb0I7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsU0FBUztBQUFBLFFBQ1AsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHO0FBQUEsUUFDMUMsUUFBUTtBQUFBLFFBQ1Isd0JBQXdCO0FBQUEsUUFDeEIsR0FBSSxPQUFPLEVBQUUsZ0JBQWdCLG1CQUFtQixJQUFJLENBQUM7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsR0FBSSxPQUFPLEVBQUUsTUFBTSxLQUFLLFVBQVUsSUFBSSxFQUFFLElBQUksQ0FBQztBQUFBLElBQy9DO0FBQ0EsUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLLElBQUk7QUFBQSxJQUM3QixTQUFTLFFBQVE7QUFDZixZQUFNLElBQUksWUFBWTtBQUFBLFFBQ3BCLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxRQUNOLFNBQVMsWUFBWSxjQUFjLE1BQU0sRUFBRSxPQUFPO0FBQUEsUUFDbEQsV0FBVztBQUFBLFFBQ1gsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFDQSxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxTQUFrQjtBQUN0QixVQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsUUFBSSxNQUFNO0FBQ1IsVUFBSTtBQUNGLGlCQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsTUFDMUIsUUFBUTtBQUNOLGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLG9CQUFvQixLQUFLLFFBQVEsR0FBRyxNQUFNLElBQUksSUFBSSxFQUFFO0FBQ2xGLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLFVBQVUsS0FBZSxPQUFxQztBQUMxRSxRQUFJLFNBQWtCO0FBQ3RCLFFBQUk7QUFDRixZQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsVUFBSSxLQUFNLFVBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxJQUNwQyxRQUFRO0FBQUEsSUFFUjtBQUNBLFdBQU8sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEtBQUs7QUFBQSxFQUNwRDtBQUFBLEVBRVEsb0JBQW9CLEtBQWUsTUFBZSxPQUE0QjtBQUNwRixVQUFNLE1BQ0osT0FBTyxTQUFTLFlBQVksUUFBUSxhQUFhLE9BQzdDLE9BQVEsS0FBOEIsT0FBTyxJQUM3QyxJQUFJO0FBQ1YsUUFBSSxXQUFvQztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUU1QyxZQUFNLE9BQU8sSUFBSSxRQUFRLElBQUksdUJBQXVCO0FBQ3BELFVBQUksU0FBUyxPQUFPLGNBQWMsS0FBSyxHQUFHLEdBQUc7QUFDM0MsbUJBQVc7QUFDWCxvQkFBWTtBQUFBLE1BQ2QsT0FBTztBQUNMLG1CQUFXO0FBQUEsTUFDYjtBQUFBLElBQ0YsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUNuRCxpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFVBQVUsS0FBSztBQUM1QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZCxXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkO0FBQ0EsV0FBTyxJQUFJLFlBQVk7QUFBQSxNQUNyQixRQUFRLElBQUk7QUFBQSxNQUNaO0FBQUEsTUFDQSxTQUFTLEdBQUcsS0FBSyxXQUFNLElBQUksTUFBTSxLQUFLLEdBQUc7QUFBQSxNQUN6QztBQUFBLE1BQ0E7QUFBQSxNQUNBLGtCQUFrQixhQUFhLGVBQWUsb0JBQW9CLElBQUksT0FBTyxJQUFJO0FBQUEsSUFDbkYsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQVFBLFNBQVMsb0JBQW9CLFNBQWlDO0FBQzVELFFBQU0sUUFBUSxRQUFRLElBQUksbUJBQW1CO0FBQzdDLE1BQUksT0FBTztBQUNULFVBQU0sSUFBSSxPQUFPLFNBQVMsT0FBTyxFQUFFO0FBQ25DLFFBQUksT0FBTyxTQUFTLENBQUMsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUFBLEVBQzFDO0FBQ0EsUUFBTSxhQUFhLFFBQVEsSUFBSSxhQUFhO0FBQzVDLE1BQUksWUFBWTtBQUNkLFVBQU0sUUFBUSxPQUFPLFNBQVMsWUFBWSxFQUFFO0FBQzVDLFFBQUksT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLEdBQUc7QUFDeEMsYUFBTyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSSxJQUFJO0FBQUEsSUFDekM7QUFDQSxVQUFNLFNBQVMsS0FBSyxNQUFNLFVBQVU7QUFDcEMsUUFBSSxPQUFPLFNBQVMsTUFBTSxFQUFHLFFBQU8sS0FBSyxNQUFNLFNBQVMsR0FBSTtBQUFBLEVBQzlEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLE1BQXNCO0FBRXhDLFNBQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJLGtCQUFrQixFQUFFLEtBQUssR0FBRztBQUN6RDtBQUVBLFNBQVMsVUFBVSxTQUFpQixLQUEwQjtBQUU1RCxRQUFNLE9BQU8sSUFBSSxhQUFhLGVBQWUsTUFBTztBQUNwRCxRQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQUc7QUFDN0MsU0FBTyxLQUFLLElBQUksS0FBUSxPQUFPLE1BQU0sVUFBVSxLQUFLLE1BQU07QUFDNUQ7QUFFQSxTQUFTLFdBQVcsS0FBa0M7QUFDcEQsU0FBTyxlQUFlLGVBQWUsSUFBSSxhQUFhO0FBQ3hEO0FBRUEsU0FBUyxNQUFNLElBQTJCO0FBQ3hDLFNBQU8sSUFBSSxRQUFRLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQzdDO0FBRU8sU0FBU0EsVUFBUyxPQUF1QjtBQUU5QyxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxLQUFLO0FBQzNDLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLFFBQU8sT0FBTyxhQUFhLENBQUM7QUFDbEQsU0FBTyxLQUFLLEdBQUc7QUFDakI7OztBQzlXQSxJQUFNLGNBQWM7QUFTcEIsSUFBTSx1QkFBNEMsb0JBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUVoRSxTQUFTLFVBQVUsU0FBa0IsS0FBd0M7QUFDbEYsUUFBTSxZQUFZLGNBQWMsT0FBTztBQUN2QyxRQUFNLFNBQTJCLENBQUM7QUFDbEMsUUFBTSxXQUFxQixDQUFDO0FBQzVCLFFBQU0sUUFBUSxvQkFBSSxJQUFZO0FBQzlCLFFBQU0sYUFBYSxvQkFBSSxJQUEyQjtBQUNsRCxRQUFNLGtCQUFrQixxQkFBcUIsSUFBSSxJQUFJLFFBQVE7QUFDN0QsYUFBVyxPQUFPLFdBQVc7QUFDM0IsUUFBSTtBQUNGLFlBQU0sSUFBSSxXQUFXLEtBQUssR0FBRztBQUM3QixVQUFJLENBQUMsR0FBRztBQUNOLFlBQUksaUJBQWlCO0FBR25CLGdCQUFNLFVBQVUsWUFBWSxHQUFHO0FBQy9CLGNBQUksUUFBUyxZQUFXLElBQUksUUFBUSxVQUFVLFFBQVEsV0FBVztBQUFBLFFBQ25FO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsZUFBUyxLQUFLLEVBQUUsUUFBUTtBQUN4QixZQUFNLElBQUksRUFBRSxRQUFRO0FBQ3BCLFVBQUksSUFBSSxlQUFlLFNBQVMsS0FBSyxJQUFJLGVBQWUsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEdBQUc7QUFDM0YsZUFBTyxLQUFLLENBQUM7QUFBQSxNQUNmO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFHQSxRQUFNLGNBQXVFLENBQUM7QUFDOUUsYUFBVyxDQUFDLElBQUksSUFBSSxLQUFLLFlBQVk7QUFDbkMsUUFBSSxNQUFNLElBQUksRUFBRSxFQUFHO0FBQ25CLGdCQUFZLEtBQUssRUFBRSxVQUFVLElBQUksYUFBYSxLQUFLLENBQUM7QUFBQSxFQUN0RDtBQUNBLFNBQU8sRUFBRSxRQUFRLGNBQWMsVUFBVSxZQUFZO0FBQ3ZEO0FBRUEsU0FBUyxZQUFZLE1BQXdFO0FBQzNGLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBR1YsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFHOUMsUUFBTSxLQUFLLEVBQUU7QUFDYixNQUFJLE9BQU8sV0FBVyxPQUFPLGdDQUFnQyxDQUFDLElBQUksRUFBRSxNQUFNLEdBQUc7QUFDM0UsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLFNBQ0gsT0FBTyxFQUFFLFlBQVksWUFBWSxFQUFFLFdBQ25DLE9BQU8sSUFBSSxFQUFFLFlBQVksR0FBRyxXQUFXLFlBQ3JDLElBQUksSUFBSSxFQUFFLFlBQVksR0FBRyxNQUFNLEdBQUc7QUFDdkMsTUFBSSxPQUFPLFdBQVcsWUFBWSxDQUFDLFlBQVksS0FBSyxNQUFNLEVBQUcsUUFBTztBQUNwRSxTQUFPLEVBQUUsVUFBVSxRQUFRLGFBQWEsZUFBZSxJQUFJLEVBQUU7QUFDL0Q7QUFFQSxTQUFTLGVBQWUsTUFBOEI7QUFDcEQsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLGFBQWEsSUFBSSxJQUFJLElBQUksRUFBRSxJQUFJLEdBQUcsWUFBWSxHQUFHLE1BQU07QUFDN0QsU0FDRSxVQUFVLElBQUksWUFBWSxJQUFJLEdBQUcsV0FBVyxLQUM1QyxVQUFVLElBQUksWUFBWSxNQUFNLEdBQUcsV0FBVyxLQUM5QyxVQUFVLElBQUksRUFBRSxNQUFNLEdBQUcsV0FBVztBQUV4QztBQUVBLFNBQVMsY0FBY0MsTUFBeUI7QUFLOUMsUUFBTSxNQUFpQixDQUFDO0FBQ3hCLFFBQU0sT0FBTyxvQkFBSSxRQUFnQjtBQUNqQyxRQUFNLFFBQW1CLENBQUNBLElBQUc7QUFDN0IsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE9BQU8sTUFBTSxJQUFJO0FBQ3ZCLFFBQUksU0FBUyxRQUFRLFNBQVMsT0FBVztBQUN6QyxRQUFJLE9BQU8sU0FBUyxTQUFVO0FBQzlCLFFBQUksS0FBSyxJQUFJLElBQWMsRUFBRztBQUM5QixTQUFLLElBQUksSUFBYztBQUV2QixRQUFJLGVBQWUsSUFBSSxHQUFHO0FBQ3hCLFVBQUksS0FBSyxZQUFZLElBQUksQ0FBQztBQUFBLElBQzVCO0FBQ0EsUUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGlCQUFXLEtBQUssS0FBTSxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ3BDLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxJQUErQixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDOUU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxlQUFlLE1BQWdEO0FBQ3RFLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsUUFBTSxXQUFXLEVBQUU7QUFDbkIsTUFDRSxhQUFhLFdBQ2IsYUFBYSxnQ0FDYixhQUFhLGtCQUNiO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxTQUFPLE9BQU8sRUFBRSxZQUFZLFlBQVksT0FBTyxFQUFFLFdBQVcsWUFBWSxFQUFFLFdBQVc7QUFDdkY7QUFFQSxTQUFTLFlBQVksTUFBd0Q7QUFDM0UsTUFBSSxLQUFLLGVBQWUsZ0NBQWdDLE9BQU8sS0FBSyxVQUFVLFVBQVU7QUFDdEYsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxLQUFjLEtBQThDO0FBQzlFLE1BQUksT0FBTyxRQUFRLFlBQVksUUFBUSxLQUFNLFFBQU87QUFDcEQsUUFBTSxJQUFJO0FBRVYsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFFOUMsUUFBTSxTQUFTLFVBQVUsRUFBRSxPQUFPO0FBS2xDLFFBQU0sU0FBUyxJQUFJLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDakMsTUFBSSxDQUFDLE9BQVEsUUFBTztBQUVwQixRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksSUFBSSxNQUFNLFlBQVksR0FBRyxNQUFNO0FBR3RELFFBQU0sY0FBYyxJQUFJLFlBQVksSUFBSTtBQUN4QyxRQUFNLGFBQWEsSUFBSSxZQUFZLE1BQU07QUFDekMsUUFBTSxnQkFBZ0IsSUFBSSxZQUFZLE1BQU07QUFDNUMsUUFBTSxTQUNKLFVBQVUsYUFBYSxXQUFXLEtBQ2xDLFVBQVUsWUFBWSxXQUFXLEtBQ2pDLFVBQVUsWUFBWSxXQUFXLEtBQ2pDLFVBQVUsT0FBTyxXQUFXO0FBQzlCLFFBQU0sWUFDSixVQUFVLFlBQVksT0FBTyxLQUM3QixVQUFVLFlBQVksTUFBTSxLQUM1QixVQUFVLE9BQU8sV0FBVztBQUM5QixNQUFJLENBQUMsVUFBVSxDQUFDLFVBQVcsUUFBTztBQU1sQyxRQUFNLFNBQVMsb0JBQW9CLFlBQVksYUFBYSxZQUFZLGFBQWE7QUFFckYsUUFBTSxZQUFZLElBQUksSUFBSSxJQUFJLEVBQUUsVUFBVSxHQUFHLGtCQUFrQixHQUFHLE1BQU07QUFDeEUsUUFBTSxlQUFlLFVBQVUsV0FBVyxJQUFJO0FBQzlDLFFBQU0saUJBQWlCLFVBQVUsT0FBTyxTQUFTLEtBQUs7QUFDdEQsUUFBTSxPQUFPLGdCQUFnQjtBQUM3QixRQUFNLGNBQWMsaUJBQWlCLFdBQVcsUUFBUSxjQUFjO0FBQ3RFLFFBQU0sZ0JBQWdCLHFCQUFxQixHQUFHLFFBQVEsSUFBSSxVQUFVO0FBRXBFLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUSxLQUFLLENBQUM7QUFDMUMsUUFBTSxtQkFBbUIsSUFBSSxXQUFXLFVBQVU7QUFDbEQsUUFBTSxXQUFXLGdCQUFnQixvQkFBb0IsUUFBUTtBQUM3RCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sT0FBTyxZQUFZLG9CQUFvQixRQUFRO0FBQ3JELFFBQU0sUUFBUSxhQUFhLE1BQU07QUFFakMsUUFBTSxZQUFZLGtCQUFrQixHQUFHLE1BQU07QUFJN0MsUUFBTSxXQUNKLGlCQUFpQixVQUFVLE9BQU8sVUFBVSxDQUFDLEtBQUssaUJBQWlCLFVBQVUsRUFBRSxVQUFVLENBQUM7QUFDNUYsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUV0QixRQUFNLFFBQVEsSUFBSSxFQUFFLEtBQUs7QUFDekIsUUFBTSxZQUFZLFVBQVUsT0FBTyxLQUFLLEtBQUssVUFBVSxVQUFVLE9BQU8sS0FBSyxDQUFDO0FBRTlFLFFBQU0sT0FBTyxZQUFZLENBQUM7QUFDMUIsUUFBTSxRQUFRLElBQUksT0FBTyxLQUFLO0FBRTlCLFFBQU0sUUFBd0I7QUFBQSxJQUM1QixVQUFVO0FBQUEsSUFDVixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixXQUFXO0FBQUEsSUFDWCxtQkFBbUIsSUFBSTtBQUFBLElBQ3ZCLGNBQWMsSUFBSTtBQUFBLElBQ2xCLHNCQUFzQjtBQUFBLElBQ3RCLFdBQVcsR0FBRyxnQkFBZ0IsSUFBSSxNQUFNLFdBQVcsTUFBTTtBQUFBLElBQ3pELFlBQVk7QUFBQSxJQUNaLGlCQUFpQixVQUFVLE9BQU8sbUJBQW1CO0FBQUEsSUFDckQsbUJBQW1CLFVBQVUsT0FBTyx5QkFBeUI7QUFBQSxJQUM3RCxrQkFBa0IsVUFBVSxPQUFPLHVCQUF1QjtBQUFBLElBQzFELHFCQUFxQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDN0QsaUJBQWlCLFVBQVUsT0FBTyxvQkFBb0I7QUFBQSxJQUN0RCxvQkFBb0I7QUFBQSxNQUNsQixJQUFJLElBQUksT0FBTyx1QkFBdUIsR0FBRyxNQUFNLEdBQUcsV0FDL0MsT0FBbUM7QUFBQSxJQUN4QztBQUFBLElBQ0E7QUFBQSxJQUNBLGVBQWUsaUJBQWlCLE1BQU0sSUFBSTtBQUFBLElBQzFDLE1BQU0sVUFBVSxPQUFPLElBQUk7QUFBQSxJQUMzQixvQkFBb0IsV0FBVyxPQUFPLGtCQUFrQjtBQUFBLElBQ3hELFFBQVEsVUFBVSxPQUFPLE1BQU0sS0FBSyxVQUFVLEVBQUUsTUFBTTtBQUFBLElBQ3RELGlCQUFpQixVQUFVLE9BQU8sU0FBUztBQUFBLElBQzNDO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWSxVQUFVLE9BQU8sY0FBYztBQUFBLElBQzNDLGVBQWUsVUFBVSxPQUFPLGFBQWE7QUFBQSxJQUM3QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsYUFBYSxVQUFVLE9BQU8sV0FBVztBQUFBLElBQ3pDLFlBQVk7QUFBQSxJQUNaLGdCQUFnQixVQUFVLE9BQU8sY0FBYztBQUFBLElBQy9DLG9CQUFvQjtBQUFBLE1BQ2xCO0FBQUEsUUFDRSxhQUFhLElBQUk7QUFBQSxRQUNqQixPQUFPLFVBQVUsT0FBTyxjQUFjO0FBQUEsUUFDdEMsVUFBVSxVQUFVLE9BQU8sYUFBYTtBQUFBLFFBQ3hDLFNBQVMsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNyQyxRQUFRLFVBQVUsT0FBTyxXQUFXO0FBQUEsUUFDcEMsT0FBTztBQUFBLFFBQ1AsV0FBVyxVQUFVLE9BQU8sY0FBYztBQUFBLE1BQzVDO0FBQUEsSUFDRjtBQUFBLElBQ0E7QUFBQSxJQUNBLGdCQUFnQjtBQUFBLElBQ2hCLGNBQWM7QUFBQSxJQUNkLGFBQWE7QUFBQSxJQUNiLHNCQUFzQjtBQUFBLElBQ3RCLGdCQUFnQjtBQUFBLElBQ2hCLGdCQUFnQixJQUFJO0FBQUEsSUFDcEIsZ0JBQWdCO0FBQUEsRUFDbEI7QUFFQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGtCQUFrQixHQUE0QixRQUE0QztBQUNqRyxNQUFJLE9BQU8sMkJBQTJCLE9BQU8sd0JBQXlCLFFBQU87QUFDN0UsTUFBSSxPQUFPLDBCQUEyQixRQUFPO0FBQzdDLE1BQUksT0FBTyxvQkFBb0IsUUFBUSxPQUFPLHFCQUFzQixRQUFPO0FBQzNFLE1BQUksRUFBRSxlQUFlLDhCQUE4QjtBQUFBLEVBRW5EO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxnQkFBZ0IsVUFBNkM7QUFDcEUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFNBQU8sSUFDSjtBQUFBLElBQUksQ0FBQyxNQUNKLE9BQU8sTUFBTSxZQUFZLEtBQUssVUFBVSxJQUFJLE9BQVEsRUFBd0IsSUFBSSxJQUFJO0FBQUEsRUFDdEYsRUFDQyxPQUFPLENBQUMsTUFBbUIsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLENBQUM7QUFDckU7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxpQkFBaUIsSUFDM0MsT0FBUSxFQUErQixXQUFXLElBQ2xEO0FBQUEsRUFDTixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsWUFBWSxVQUFnRDtBQUNuRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsUUFBTSxNQUFtQixDQUFDO0FBQzFCLGFBQVcsS0FBSyxLQUFLO0FBQ25CLFFBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFVBQU0sSUFBSTtBQUNWLFVBQU0sUUFBUSxVQUFVLEVBQUUsR0FBRztBQUM3QixVQUFNLFdBQVcsVUFBVSxFQUFFLFlBQVk7QUFDekMsVUFBTSxVQUFVLFVBQVUsRUFBRSxXQUFXO0FBQ3ZDLFFBQUksQ0FBQyxTQUFTLENBQUMsU0FBVTtBQUN6QixRQUFJLEtBQUssRUFBRSxPQUFPLFVBQVUsU0FBUyxXQUFXLFNBQVMsQ0FBQztBQUFBLEVBQzVEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLFFBQThDO0FBQ2xFLFFBQU0sV0FBVyxJQUFJLE9BQU8saUJBQWlCO0FBQzdDLFFBQU0sVUFBVSxXQUFXLFFBQVEsU0FBUyxLQUFLLElBQUksQ0FBQztBQUN0RCxRQUFNLFVBQVUsUUFBUSxJQUFJLE9BQU8sUUFBUSxHQUFHLEtBQUs7QUFDbkQsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxTQUFTLENBQUMsR0FBRyxTQUFTLEdBQUcsT0FBTyxFQUFFLE9BQU8sQ0FBQyxNQUFNO0FBQ3BELFFBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNLFFBQU87QUFDaEQsVUFBTSxLQUNKLFVBQVcsRUFBOEIsU0FBUyxLQUNsRCxVQUFXLEVBQThCLE1BQU07QUFDakQsUUFBSSxDQUFDLEdBQUksUUFBTztBQUNoQixRQUFJLEtBQUssSUFBSSxFQUFFLEVBQUcsUUFBTztBQUN6QixTQUFLLElBQUksRUFBRTtBQUNYLFdBQU87QUFBQSxFQUNULENBQUM7QUFDRCxTQUFPLE9BQU8sSUFBSSxDQUFDLFFBQVEsV0FBVyxHQUE4QixDQUFDO0FBQ3ZFO0FBRUEsU0FBUyxXQUFXLEdBQXVDO0FBQ3pELFFBQU0sT0FBTyxVQUFVLEVBQUUsSUFBSTtBQUM3QixRQUFNLFdBQVcsZ0JBQWdCLEdBQUcsSUFBSTtBQUN4QyxRQUFNQyxRQUFPLElBQUksRUFBRSxhQUFhO0FBQ2hDLFFBQU0sWUFBWSxJQUFJLEVBQUUsVUFBVTtBQUNsQyxRQUFNLGFBQWEsVUFBVSxXQUFXLGVBQWU7QUFDdkQsUUFBTSxVQUFVLFVBQVUsRUFBRSxZQUFZO0FBQ3hDLFFBQU0sVUFDSixVQUFVLEVBQUUsU0FBUyxLQUNyQixVQUFVLEVBQUUsTUFBTSxLQUNsQixHQUFHLFFBQVEsT0FBTyxJQUFJLEtBQUssT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQzNELFNBQU87QUFBQSxJQUNMLFVBQVU7QUFBQSxJQUNWLFlBQWEsUUFBUTtBQUFBLElBQ3JCLGNBQWMsWUFBWTtBQUFBLElBQzFCLG1CQUFtQjtBQUFBLElBQ25CLFFBQVE7QUFBQSxJQUNSLE9BQU87QUFBQSxJQUNQLGNBQWMsZUFBZSxPQUFPLGFBQWEsTUFBTztBQUFBLElBQ3hELE9BQU8sVUFBVUEsT0FBTSxLQUFLO0FBQUEsSUFDNUIsUUFBUSxVQUFVQSxPQUFNLE1BQU07QUFBQSxJQUM5QixVQUFVO0FBQUEsSUFDVixnQkFBZ0I7QUFBQSxJQUNoQixrQkFBa0I7QUFBQSxJQUNsQixpQkFBaUI7QUFBQSxFQUNuQjtBQUNGO0FBRUEsU0FBUyxnQkFBZ0IsR0FBNEIsTUFBb0M7QUFDdkYsTUFBSSxTQUFTLFFBQVMsUUFBTyxVQUFVLEVBQUUsZUFBZSxLQUFLLFVBQVUsRUFBRSxTQUFTO0FBQ2xGLFFBQU0sV0FBVyxRQUFRLElBQUksRUFBRSxVQUFVLEdBQUcsUUFBUTtBQUNwRCxNQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sVUFBVSxFQUFFLGVBQWU7QUFFN0QsTUFBSSxPQUFnRDtBQUNwRCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLEtBQUssVUFBVSxFQUFFLFlBQVk7QUFDbkMsVUFBTSxNQUFNLFVBQVUsRUFBRSxHQUFHO0FBQzNCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsUUFBSSxPQUFPLGFBQWE7QUFDdEIsWUFBTSxLQUFLLFVBQVUsRUFBRSxPQUFPLEtBQUs7QUFDbkMsVUFBSSxDQUFDLFFBQVEsS0FBSyxLQUFLLFFBQVMsUUFBTyxFQUFFLEtBQUssU0FBUyxHQUFHO0FBQUEsSUFDNUQsV0FBVyxDQUFDLE1BQU07QUFFaEIsYUFBTyxFQUFFLEtBQUssU0FBUyxFQUFFO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0EsU0FBTyxNQUFNLE9BQU87QUFDdEI7QUFFQSxTQUFTLGlCQUFpQixNQUFjLE1BQTJCO0FBQ2pFLE1BQUksS0FBSyxXQUFXLEVBQUcsUUFBTztBQUM5QixNQUFJLE1BQU07QUFDVixhQUFXLEtBQUssS0FBTSxPQUFNLElBQUksTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUTtBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxNQUFJLENBQUMsRUFBRyxRQUFPO0FBRWYsUUFBTSxJQUFJLElBQUksS0FBSyxDQUFDO0FBQ3BCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTztBQUN0QyxTQUFPLEVBQUUsWUFBWTtBQUN2QjtBQUVBLFNBQVMsVUFBVSxHQUEyQjtBQUM1QyxTQUFPLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxJQUFJLElBQUk7QUFDckQ7QUFDQSxTQUFTLFdBQVcsR0FBNEI7QUFDOUMsU0FBTyxPQUFPLE1BQU0sWUFBWSxJQUFJO0FBQ3RDO0FBQ0EsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ3hELE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsVUFBTSxJQUFJLE9BQU8sQ0FBQztBQUNsQixRQUFJLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUFBLEVBQ2pDO0FBQ0EsU0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLEdBQW9CO0FBQ3JDLFNBQU8sVUFBVSxDQUFDLEtBQUs7QUFDekI7QUFDQSxTQUFTLElBQUksR0FBNEM7QUFDdkQsU0FBTyxPQUFPLE1BQU0sWUFBWSxNQUFNLFFBQVEsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUN6RCxJQUNEO0FBQ047QUFDQSxTQUFTLFFBQVEsR0FBdUI7QUFDdEMsU0FBTyxNQUFNLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQztBQUNqQztBQXdCQSxTQUFTLGlCQUNQLFdBQ0EsUUFDQSxVQUNTO0FBQ1QsTUFBSSxVQUFXLFFBQU87QUFDdEIsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUN0QixRQUFNLFdBQVcsSUFBSSxPQUFPLFFBQVE7QUFDcEMsUUFBTSxPQUFPLFdBQVcsU0FBUyxPQUFPO0FBQ3hDLE1BQUksTUFBTSxRQUFRLElBQUksR0FBRztBQUN2QixlQUFXLEtBQUssTUFBTTtBQUNwQixVQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTTtBQUN6QyxZQUFNLE1BQU8sRUFBOEI7QUFJM0MsVUFBSSxPQUFPLFFBQVEsWUFBWSx3QkFBd0IsS0FBSyxHQUFHLEdBQUc7QUFDaEUsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQWtCTyxTQUFTLGNBQ2QsUUFDQSxVQUNrQjtBQUNsQixNQUFJLFNBQVMsU0FBUyxFQUFHLFFBQU87QUFLaEMsUUFBTSxnQkFBZ0Isb0JBQUksSUFBWTtBQUN0QyxRQUFNLG1CQUFtQixvQkFBSSxJQUFZO0FBQ3pDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxFQUFHO0FBQ25ELHFCQUFpQixJQUFJLEVBQUUsUUFBUTtBQUMvQixRQUFJLEVBQUUsZ0JBQWlCLGVBQWMsSUFBSSxFQUFFLGVBQWU7QUFDMUQsUUFBSSxFQUFFLG1CQUFvQixlQUFjLElBQUksRUFBRSxrQkFBa0I7QUFDaEUsUUFBSSxFQUFFLGtCQUFtQixlQUFjLElBQUksRUFBRSxpQkFBaUI7QUFBQSxFQUNoRTtBQUNBLFNBQU8sT0FBTyxPQUFPLENBQUMsTUFBTTtBQUMxQixVQUFNLElBQUksRUFBRSxlQUFlLFlBQVk7QUFDdkMsUUFBSSxTQUFTLElBQUksQ0FBQyxFQUFHLFFBQU87QUFFNUIsUUFBSSxjQUFjLElBQUksRUFBRSxRQUFRLEVBQUcsUUFBTztBQUUxQyxRQUFJLEVBQUUsbUJBQW1CLGlCQUFpQixJQUFJLEVBQUUsZUFBZSxFQUFHLFFBQU87QUFDekUsUUFBSSxFQUFFLHNCQUFzQixpQkFBaUIsSUFBSSxFQUFFLGtCQUFrQixFQUFHLFFBQU87QUFDL0UsUUFBSSxFQUFFLHFCQUFxQixpQkFBaUIsSUFBSSxFQUFFLGlCQUFpQixFQUFHLFFBQU87QUFFN0UsUUFBSSxFQUFFLG9CQUFvQixTQUFTLElBQUksRUFBRSxpQkFBaUIsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUNqRixlQUFXLEtBQUssRUFBRSxVQUFVO0FBQzFCLFVBQUksU0FBUyxJQUFJLEVBQUUsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUFBLElBQzVDO0FBQ0EsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNIO0FBU0EsU0FBUyxxQkFDUCxHQUNBLFFBQ0EsWUFDc0I7QUFDdEIsUUFBTSxRQUFRLElBQUksRUFBRSxlQUFlLEtBQUssSUFBSSxPQUFPLGVBQWU7QUFDbEUsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixRQUFNLFdBQVcsSUFBSSxNQUFNLFFBQVE7QUFDbkMsUUFBTSxPQUFPLElBQUksTUFBTSxJQUFJO0FBQzNCLFFBQU0sVUFBVSxVQUFVLFVBQVUsSUFBSTtBQUN4QyxRQUFNLFFBQVEsVUFBVSxNQUFNLEtBQUs7QUFDbkMsUUFBTSxhQUFhLFVBQVUsTUFBTSxVQUFVO0FBQzdDLFFBQU0saUJBQWlCLFVBQVUsTUFBTSxjQUFjO0FBQ3JELFFBQU0sU0FBUyxVQUFVLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPO0FBRWpFLE1BQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQVEsUUFBTztBQUMxQyxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVDtBQUFBLElBQ0EsYUFBYTtBQUFBLElBQ2I7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLElBQ2pCLGFBQWE7QUFBQSxFQUNmO0FBQ0Y7QUFPQSxTQUFTLG9CQUNQLFlBQ0EsYUFDQSxZQUNBLGVBQ2M7QUFDZCxRQUFNLGVBQWUsSUFBSSxZQUFZLFlBQVk7QUFDakQsU0FBTztBQUFBLElBQ0wsY0FDRSxVQUFVLGFBQWEsSUFBSSxLQUFLLFVBQVUsWUFBWSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUk7QUFBQSxJQUMzRixZQUNFLFVBQVUsZUFBZSxTQUFTLEtBQ2xDLFVBQVUsWUFBWSx1QkFBdUIsS0FDN0MsVUFBVSxZQUFZLHVCQUF1QjtBQUFBLElBQy9DLFVBQVUsV0FBVyxjQUFjLFFBQVEsS0FBSyxXQUFXLFlBQVksUUFBUTtBQUFBLElBQy9FLGtCQUFrQixXQUFXLFlBQVksZ0JBQWdCO0FBQUEsSUFDekQsZUFBZSxVQUFVLGNBQWMsYUFBYSxLQUFLLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDNUYsYUFBYSxVQUFVLFlBQVksV0FBVztBQUFBLElBQzlDLFVBQVUsVUFBVSxJQUFJLFlBQVksUUFBUSxHQUFHLFFBQVEsS0FBSyxVQUFVLFlBQVksUUFBUTtBQUFBLElBQzFGLEtBQUssVUFBVSxZQUFZLEdBQUc7QUFBQSxJQUM5QixpQkFBaUIsVUFBVSxZQUFZLGVBQWU7QUFBQSxJQUN0RCxlQUFlLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDbEQsZ0JBQWdCLFVBQVUsWUFBWSxjQUFjO0FBQUEsSUFDcEQsb0JBQ0UsaUJBQWlCLFVBQVUsYUFBYSxVQUFVLENBQUMsS0FDbkQsaUJBQWlCLFVBQVUsWUFBWSxVQUFVLENBQUM7QUFBQSxJQUNwRCxXQUFXLFdBQVcsWUFBWSxTQUFTO0FBQUEsRUFDN0M7QUFDRjtBQU9BLFNBQVMsWUFBWSxHQUE4QztBQUNqRSxRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksTUFBTSxNQUFNO0FBQ25DLE1BQUksQ0FBQyxXQUFZLFFBQU87QUFDeEIsUUFBTSxXQUFXLFdBQVc7QUFDNUIsUUFBTSxRQUFpQyxDQUFDO0FBQ3hDLE1BQUksTUFBTSxRQUFRLFFBQVEsR0FBRztBQUMzQixlQUFXLE1BQU0sVUFBVTtBQUN6QixVQUFJLE9BQU8sT0FBTyxZQUFZLE9BQU8sS0FBTTtBQUMzQyxZQUFNLElBQUk7QUFDVixZQUFNLElBQUksVUFBVSxFQUFFLEdBQUc7QUFDekIsWUFBTSxJQUFJLElBQUksRUFBRSxLQUFLO0FBQ3JCLFVBQUksQ0FBQyxLQUFLLENBQUMsRUFBRztBQUNkLFlBQU0sQ0FBQyxJQUNMLFVBQVUsRUFBRSxZQUFZLEtBQ3hCLFVBQVUsSUFBSSxFQUFFLFdBQVcsR0FBRyxHQUFHLEtBQ2pDLFVBQVUsSUFBSSxFQUFFLGlCQUFpQixHQUFHLE9BQU87QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sVUFBVSxXQUFXLElBQUk7QUFDdEMsUUFBTSxVQUFVLFVBQVUsV0FBVyxHQUFHO0FBQ3hDLFFBQU0sWUFDSixPQUFPLE1BQU0sWUFBWSxNQUFNLFdBQVksTUFBTSxZQUFZLElBQWU7QUFDOUUsUUFBTSxRQUFRLE9BQU8sTUFBTSxPQUFPLE1BQU0sV0FBWSxNQUFNLE9BQU8sSUFBZTtBQUNoRixRQUFNLGNBQ0osT0FBTyxNQUFNLGFBQWEsTUFBTSxXQUFZLE1BQU0sYUFBYSxJQUFlO0FBQ2hGLFFBQU0sWUFDSCxPQUFPLE1BQU0sZ0NBQWdDLE1BQU0sV0FDL0MsTUFBTSxnQ0FBZ0MsSUFDdkMsVUFDSCxPQUFPLE1BQU0sMEJBQTBCLE1BQU0sV0FDekMsTUFBTSwwQkFBMEIsSUFDakMsVUFDSCxPQUFPLE1BQU0sOEJBQThCLE1BQU0sV0FDN0MsTUFBTSw4QkFBOEIsSUFDckM7QUFDTixNQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsU0FBVSxRQUFPO0FBQ3pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiO0FBQ0Y7OztBQzVwQkEsSUFBTSxXQUFXO0FBRVYsU0FBUyxXQUFtQjtBQUNqQyxRQUFNLEtBQUssS0FBSyxJQUFJO0FBQ3BCLE1BQUksU0FBUztBQUNiLE1BQUksSUFBSTtBQUNSLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLGNBQVUsU0FBUyxJQUFJLEVBQUUsS0FBSyxPQUFPO0FBQ3JDLFFBQUksS0FBSyxNQUFNLElBQUksRUFBRTtBQUFBLEVBQ3ZCO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLEtBQU0sYUFBWSxTQUFTLElBQUksRUFBRSxLQUFLO0FBQ3RELFNBQU8sU0FBUztBQUNsQjtBQUVPLFNBQVMsV0FBVyxJQUFvQjtBQUM3QyxTQUFPLEdBQUcsTUFBTSxFQUFFO0FBQ3BCOzs7QUNQQSxJQUFNLG1CQUFpRCxvQkFBSSxJQUFJO0FBQUEsRUFDN0Q7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVNLFNBQVMsa0JBQWtCLE1BQStCO0FBQy9ELFFBQU0sV0FBNEIsQ0FBQztBQUNuQyxNQUFJLFVBQWtDLENBQUM7QUFDdkMsTUFBSSxhQUFhO0FBQ2pCLFFBQU0sUUFBUSxNQUFNO0FBQ2xCLFFBQUksUUFBUSxVQUFVLFFBQVEsT0FBTztBQUNuQyxVQUFJLENBQUMsUUFBUSxTQUFVLFNBQVEsV0FBVztBQUMxQyxlQUFTLEtBQUssT0FBd0I7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFDQSxhQUFXLFdBQVcsS0FBSyxNQUFNLElBQUksR0FBRztBQUN0QyxVQUFNLE9BQU8sY0FBYyxPQUFPO0FBQ2xDLFFBQUksS0FBSyxLQUFLLE1BQU0sR0FBSTtBQUN4QixRQUFJLGdCQUFnQixLQUFLLElBQUksR0FBRztBQUM5QixtQkFBYTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxXQUFZO0FBRWpCLFVBQU0sWUFBWSxLQUFLLE1BQU0sNEJBQTRCO0FBQ3pELFFBQUksV0FBVztBQUNiLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxVQUFVLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDaEQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx3QkFBd0I7QUFDdEQsUUFBSSxjQUFjLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUNyQyxZQUFNO0FBQ04sZ0JBQVUsRUFBRSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2pEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sdUJBQXVCO0FBQ3JELFFBQUksY0FBYyxRQUFRLFFBQVE7QUFDaEMsY0FBUSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRTtBQUMzQztBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixLQUFLLE1BQU0sMEJBQTBCO0FBQzNELFFBQUksaUJBQWlCLFFBQVEsUUFBUTtBQUNuQyxZQUFNLE1BQU0sUUFBUSxjQUFjLENBQUMsS0FBSyxFQUFFO0FBQzFDLGNBQVEsV0FBVyxpQkFBaUIsSUFBSSxHQUFzQixJQUN6RCxNQUNEO0FBQ0o7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU07QUFDTixTQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUNuRDtBQUVBLFNBQVMsY0FBYyxNQUFzQjtBQUczQyxRQUFNLE1BQU0sS0FBSyxRQUFRLEdBQUc7QUFDNUIsU0FBTyxRQUFRLEtBQUssT0FBTyxLQUFLLE1BQU0sR0FBRyxHQUFHO0FBQzlDO0FBRUEsU0FBUyxRQUFRLEdBQW1CO0FBQ2xDLFFBQU0sVUFBVSxFQUFFLEtBQUs7QUFDdkIsTUFDRyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQy9DLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsR0FDaEQ7QUFDQSxXQUFPLFFBQVEsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUM1QjtBQUNBLFNBQU87QUFDVDs7O0FDTkEsSUFBTSxjQUFjLFFBQVEsUUFBUSxZQUFZLEVBQUU7QUFFbEQsZUFBZSxDQUFDLE9BQWlCO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxhQUFhLE9BQU8sR0FBRyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFLENBQUM7QUFJRCxRQUFRLFFBQVEsWUFBWSxZQUFZLFlBQVk7QUFDbEQsUUFBTSxLQUFLLHVCQUF1QixFQUFFLFNBQVMsWUFBWSxDQUFDO0FBQzFELFFBQU0sT0FBTyxTQUFTO0FBQ3hCLENBQUM7QUFFRCxRQUFRLFFBQVEsVUFBVSxZQUFZLE1BQU07QUFDMUMsT0FBSyxPQUFPLFNBQVM7QUFDdkIsQ0FBQztBQUdELEtBQUssT0FBTyxhQUFhO0FBRXpCLGVBQWUsT0FBTyxRQUErQjtBQUNuRCxNQUFJO0FBQ0YsVUFBTSxhQUFhO0FBQ25CLFVBQU0sc0JBQXNCO0FBQzVCLFVBQU0sNEJBQTRCO0FBQ2xDLFVBQU0scUJBQXFCO0FBRzNCLFVBQU0sU0FBUyxNQUFNLG9CQUFvQixLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUk7QUFDakUsUUFBSSxTQUFTLEVBQUcsT0FBTSxLQUFLLDBCQUEwQixFQUFFLE9BQU8sQ0FBQztBQUMvRCxVQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQUksU0FBUyxPQUFPLFNBQVMsU0FBUyxTQUFTLE1BQU07QUFDbkQsWUFBTSxpQkFBaUIsS0FBSztBQUM1QixZQUFNLG9CQUFvQixLQUFLO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU87QUFBQSxRQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlO0FBQUEsUUFDZix3QkFBd0I7QUFBQSxRQUN4QixrQkFBa0I7QUFBQSxNQUNwQixDQUFDO0FBQ0QsWUFBTSxLQUFLLHdDQUF3QyxFQUFFLE9BQU8sQ0FBQztBQUFBLElBQy9EO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixVQUFNLE1BQU8sZUFBZSxFQUFFLFFBQVEsR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQUEsRUFDL0Q7QUFDRjtBQVlBLGVBQWUsdUJBQXNDO0FBQ25ELE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsRUFDdkYsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDZCQUE2QixjQUFjLEdBQUcsQ0FBQztBQUMxRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJO0FBQ0YsWUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJdEIsT0FBTztBQUFBLE1BQ1QsQ0FBQztBQUNELFlBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLE1BQ3RCLENBQUM7QUFDRCxZQUFNLEtBQUsscUNBQXFDO0FBQUEsUUFDOUMsT0FBTyxJQUFJO0FBQUEsUUFDWCxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUU7QUFBQSxNQUMvQixDQUFDO0FBQUEsSUFDSCxTQUFTLEtBQUs7QUFJWixZQUFNLEtBQUssd0NBQXdDO0FBQUEsUUFDakQsT0FBTyxJQUFJO0FBQUEsUUFDWCxLQUFLLFdBQVcsSUFBSSxPQUFPLEVBQUU7QUFBQSxRQUM3QixHQUFHLGNBQWMsR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxRQUFNLFFBQVEsT0FBTyxNQUFNLGFBQWE7QUFDeEMsUUFBTSxRQUFRLE9BQU8sTUFBTSxtQkFBbUI7QUFDOUMsUUFBTSxRQUFRLE9BQU8sT0FBTyxlQUFlLEVBQUUsaUJBQWlCLG9CQUFvQixDQUFDO0FBQ25GLFFBQU0sUUFBUSxPQUFPLE9BQU8scUJBQXFCO0FBQUEsSUFDL0MsaUJBQWlCLGdDQUFnQztBQUFBLEVBQ25ELENBQUM7QUFDSDtBQU1BLElBQUksa0JBQXlEO0FBSzdELElBQU0saUJBQWlCO0FBRXZCLGVBQWUsd0JBQXVDO0FBRXBELFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLE1BQUksU0FBUyxRQUFRLEVBQUUsWUFBWSxPQUFPO0FBQ3hDLHVCQUFtQixFQUFFLHFCQUFxQjtBQUFBLEVBQzVDLE9BQU87QUFDTCx5QkFBcUI7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyx1QkFBNkI7QUFDcEMsTUFBSSxvQkFBb0IsTUFBTTtBQUM1QixrQkFBYyxlQUFlO0FBQzdCLHNCQUFrQjtBQUFBLEVBQ3BCO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixhQUEyQjtBQUNyRCx1QkFBcUI7QUFDckIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sV0FBVyxDQUFDO0FBQUEsRUFDdkQ7QUFDQSxvQkFBa0IsWUFBWSxNQUFNO0FBQ2xDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsYUFBYTtBQUFBLElBQ2IsZUFBZTtBQUFBLElBQ2YsZUFBZTtBQUFBLEVBQ2pCLENBQUM7QUFDRCxxQkFBbUIsRUFBRSxxQkFBcUI7QUFDMUMsUUFBTSxLQUFLLDRCQUE0QixFQUFFLGNBQWMsRUFBRSxzQkFBc0IsQ0FBQztBQUVoRixPQUFLLGVBQWU7QUFDcEIsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQsdUJBQXFCO0FBQ3JCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLE1BQU0sZUFBZTtBQUFBLElBQzlCLFVBQVUsTUFBTSxpQkFBaUI7QUFBQSxJQUNqQyxVQUFVLE1BQU0saUJBQWlCO0FBQUEsRUFDbkMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsaUJBQWdDO0FBQzdDLE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsRUFDdkYsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlDQUFpQyxjQUFjLEdBQUcsQ0FBQztBQUM5RDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLE1BQUksY0FBYztBQUNsQixNQUFJLGdCQUFnQjtBQUNwQixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVU7QUFDaEMsUUFBSSxJQUFJLFVBQVc7QUFDbkIsUUFBSTtBQUNGLFlBQU0sVUFBVyxNQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDckQsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSVAsTUFBTyxNQUFNO0FBS1gsZ0JBQU0sc0JBQXNCO0FBQUEsWUFDMUI7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFDQSxnQkFBTSxVQUFVLG9CQUFJLElBQWE7QUFDakMsY0FBSSxXQUFXO0FBQ2YscUJBQVcsT0FBTyxxQkFBcUI7QUFDckMsdUJBQVcsTUFBTSxNQUFNLEtBQUssU0FBUyxpQkFBaUIsR0FBRyxDQUFDLEdBQUc7QUFDM0Qsa0JBQUksUUFBUSxJQUFJLEVBQUUsRUFBRztBQUVyQixvQkFBTSxLQUFLLEdBQUcsZUFBZSxJQUFJLEtBQUssRUFBRSxZQUFZO0FBQ3BELGtCQUFJLE1BQU0sZUFBZSxNQUFNLG1CQUFvQjtBQUNuRCxvQkFBTSxPQUFPLEdBQUcsc0JBQXNCO0FBQ3RDLGtCQUFJLEtBQUssVUFBVSxLQUFLLEtBQUssV0FBVyxFQUFHO0FBQzNDLHNCQUFRLElBQUksRUFBRTtBQUNkLGtCQUFJO0FBQ0YsZ0JBQUMsR0FBbUIsTUFBTTtBQUMxQiw0QkFBWTtBQUFBLGNBQ2QsUUFBUTtBQUFBLGNBRVI7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUlBLGdCQUFNLE9BQTBCO0FBQUEsWUFDOUIsS0FBSztBQUFBLFlBQ0wsTUFBTTtBQUFBLFlBQ04sU0FBUztBQUFBLFlBQ1QsT0FBTztBQUFBLFlBQ1AsU0FBUztBQUFBLFlBQ1QsWUFBWTtBQUFBLFVBQ2Q7QUFDQSxnQkFBTSxRQUFTLFNBQVMsaUJBQXdDLFNBQVM7QUFDekUsZ0JBQU0sY0FBYyxJQUFJLGNBQWMsV0FBVyxJQUFJLENBQUM7QUFDdEQsZ0JBQU0sY0FBYyxJQUFJLGNBQWMsU0FBUyxJQUFJLENBQUM7QUFDcEQsaUJBQU8sU0FBUztBQUFBLFlBQ2QsS0FBSyxTQUFTLGdCQUFnQjtBQUFBLFlBQzlCLFVBQVU7QUFBQSxVQUNaLENBQUM7QUFDRCxpQkFBTyxFQUFFLFNBQVM7QUFBQSxRQUNwQjtBQUFBLE1BQ0YsQ0FBQztBQUNELHFCQUFlO0FBQ2YsWUFBTSxJQUFJLFFBQVEsQ0FBQyxHQUFHO0FBQ3RCLFVBQUksS0FBSyxPQUFPLEVBQUUsYUFBYSxTQUFVLGtCQUFpQixFQUFFO0FBQUEsSUFDOUQsUUFBUTtBQUFBLElBR1I7QUFBQSxFQUNGO0FBQ0EsTUFBSSxjQUFjLEdBQUc7QUFDbkIsVUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQUksU0FBUyxNQUFNO0FBQ2pCLFdBQUssZUFBZTtBQUNwQixXQUFLLGlCQUFpQjtBQUN0QixZQUFNLHFCQUFxQixJQUFJO0FBQUEsSUFFakM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxRQUFRLE9BQU8sUUFBUSxZQUFZLENBQUMsVUFBVTtBQUM1QyxNQUFJLE1BQU0sU0FBUyxlQUFlO0FBQ2hDLFNBQUssaUJBQWlCO0FBQUEsRUFDeEIsV0FBVyxNQUFNLFNBQVMscUJBQXFCO0FBQzdDLFNBQUssaUJBQWlCLEtBQUs7QUFBQSxFQUM3QjtBQUlGLENBQUM7QUFJRCxJQUFJLFFBQVEsUUFBUSxXQUFXO0FBQzdCLFVBQVEsT0FBTyxVQUFVLFlBQVksWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTSxRQUFRLGNBQWMsT0FBTztBQUFBLElBQ3JDLFNBQVMsS0FBSztBQUVaLFlBQU0sS0FBSywwQ0FBMEMsY0FBYyxHQUFHLENBQUM7QUFDdkUsWUFBTSxRQUFRLFFBQVEsZ0JBQWdCO0FBQUEsSUFDeEM7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUlBLFFBQVEsUUFBUSxVQUFVLFlBQVksQ0FBQyxLQUFjLFlBQVk7QUFDL0QsTUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUcsUUFBTztBQUNuQyxTQUFPLGNBQWMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ3ZDLFNBQUssTUFBTywwQkFBMEIsRUFBRSxNQUFNLElBQUksTUFBTSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDL0UsVUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNILENBQUM7QUFFRCxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxTQUFPLENBQUMsQ0FBQyxLQUFLLE9BQU8sTUFBTSxZQUFZLE9BQVEsRUFBeUIsU0FBUztBQUNuRjtBQUlBLElBQU0sNEJBQTRCLG9CQUFJLElBQTRCO0FBQUEsRUFDaEU7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFFRCxlQUFlLFlBQThCO0FBQzNDLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsU0FBTyxFQUFFLFlBQVk7QUFDdkI7QUFFQSxlQUFlLGNBQWMsS0FBdUM7QUFLbEUsTUFBSSxDQUFFLE1BQU0sVUFBVSxLQUFNLDBCQUEwQixJQUFJLElBQUksSUFBSSxHQUFHO0FBQ25FLFdBQU8sRUFBRSxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUEsRUFDbEM7QUFDQSxVQUFRLElBQUksTUFBTTtBQUFBLElBQ2hCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJLFVBQVUsSUFBSSxLQUFLLElBQUksUUFBUTtBQUMxRCxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN2RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN0RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFVBQUksSUFBSSxVQUFVLFFBQVE7QUFDeEIsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQsV0FBVyxJQUFJLFVBQVUsU0FBUztBQUNoQyxjQUFNLE1BQU8sSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNwRCxPQUFPO0FBQ0wsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQ7QUFDQSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFdBQVcsSUFBSSxNQUFNO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFdBQVc7QUFDakIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZ0JBQWdCO0FBQ3RCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFNBQVMsTUFBTTtBQUNyQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxZQUFZLElBQUksUUFBUSxNQUFNO0FBQ3BDLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGVBQWUsRUFBRSxhQUFhLElBQUksR0FBRyxDQUFDO0FBQzVDLFlBQU0sS0FBSyx3QkFBd0IsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQ2pELGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssa0JBQWtCO0FBQ3JCLFlBQU0sSUFBSSxNQUFNLGVBQWUsRUFBRSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2xELFVBQUksQ0FBQyxJQUFJLElBQUk7QUFHWCw2QkFBcUI7QUFDckIsNEJBQW9CO0FBQ3BCLCtCQUF1QjtBQUN2QixjQUFNLFFBQVEsT0FBTyxNQUFNLGNBQWM7QUFDekMsY0FBTSxRQUFRLE9BQU8sTUFBTSxrQkFBa0I7QUFBQSxNQUMvQyxPQUFPO0FBRUwsY0FBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFlBQUksU0FBUyxLQUFNLG9CQUFtQixFQUFFLHFCQUFxQjtBQUFBLE1BQy9EO0FBQ0EsWUFBTSxLQUFLLG1DQUFtQyxFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDNUQsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQjtBQUMxQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxxQkFBcUI7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSyw0QkFBNEI7QUFDL0IsWUFBTSxVQUFVLEtBQUs7QUFBQSxRQUNuQjtBQUFBLFFBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sSUFBSSxPQUFPLENBQUM7QUFBQSxNQUN2RDtBQUNBLFlBQU0sZUFBZSxFQUFFLHVCQUF1QixRQUFRLENBQUM7QUFFdkQsWUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFVBQUksU0FBUyxLQUFNLG9CQUFtQixPQUFPO0FBQzdDLFVBQUksMEJBQTBCLEtBQU0sc0JBQXFCLE9BQU87QUFDaEUsVUFBSSw2QkFBNkIsS0FBTSx5QkFBd0IsT0FBTztBQUN0RSxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0saUJBQWlCO0FBQ3ZCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGtCQUFrQjtBQUN4QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssbUJBQW1CO0FBQ3RCLFlBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsWUFBTSxVQUFVLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUMvRCxZQUFNLFVBQVUsTUFBTSxvQkFBb0IsT0FBTztBQUNqRCxZQUFNLEtBQUssMEJBQTBCLE9BQU87QUFDNUMsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQixJQUFJO0FBQzlCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGNBQWM7QUFDcEIsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFDdEMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssZUFBZTtBQUNsQixZQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFlBQU0sTUFBTSxVQUFVLENBQUM7QUFDdkIsWUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLElBQUksQ0FBQztBQUNqQyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQ0UsYUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLHVCQUF1QjtBQUFBLEVBQ3REO0FBQ0Y7QUFJQSxlQUFlLGlCQUFpQixVQUFrQixLQUFhLFVBQWtDO0FBQy9GLE1BQUksa0JBQWtCLElBQUksUUFBUSxFQUFHO0FBQ3JDLE1BQUksQ0FBQyxnQkFBZ0IsSUFBSSxRQUFRLEVBQUc7QUFFcEMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQWdCbkMsUUFBTSxVQUFVLElBQUksSUFBSSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUNuRSxRQUFNLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFFMUMsTUFBSTtBQUNKLE1BQUk7QUFDRixpQkFBYSxVQUFVLFVBQVU7QUFBQSxNQUMvQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1A7QUFBQSxNQUNBLGdCQUFnQixvQkFBSSxJQUFZO0FBQUEsSUFDbEMsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxXQUFXLG1CQUFtQixVQUFVLEtBQUssVUFBVSxHQUFHO0FBQ2hFO0FBQUEsRUFDRjtBQVFBLFFBQU0sZUFBZSxXQUFXLE9BQU87QUFDdkMsYUFBVyxTQUFTLGNBQWMsV0FBVyxRQUFRLE9BQU87QUFDNUQsUUFBTSxtQkFBbUIsZUFBZSxXQUFXLE9BQU87QUFDMUQsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLEtBQUssNEJBQTRCO0FBQUEsTUFDckM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDMUIsQ0FBQztBQUFBLEVBQ0g7QUFPQSxNQUFJLFdBQVcsYUFBYSxXQUFXLEdBQUc7QUFDeEMsVUFBTSxLQUFLLDRDQUF1QztBQUFBLE1BQ2hEO0FBQUEsTUFDQSxXQUFXLGVBQWUsUUFBUSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsTUFDL0MsWUFBWSxvQkFBb0IsVUFBVSxPQUFPO0FBQUEsTUFDakQsaUJBQWlCLGlCQUFpQixVQUFVLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFBQSxNQUM3RCxtQkFBbUIsaUJBQWlCLFVBQVUsU0FBUyxDQUFDLFFBQVEsQ0FBQztBQUFBLE1BQ2pFLDBCQUEwQixpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDNUQ7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLE1BQ0QsK0JBQStCLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUNqRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLE1BQ0QsaUNBQWlDLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUNuRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0gsT0FBTztBQUNMLFVBQU0sS0FBSyx3QkFBd0I7QUFBQSxNQUNqQztBQUFBLE1BQ0EsVUFBVSxXQUFXLGFBQWE7QUFBQSxNQUNsQyxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBRUEsTUFBSSxXQUFXLE9BQU8sV0FBVyxFQUFHO0FBV3BDLFFBQU0sY0FBYyxNQUFNLGtCQUFrQjtBQUM1QyxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxhQUFXLEtBQUssV0FBVyxRQUFRO0FBQ2pDLFFBQUksRUFBRSxjQUFjO0FBQ2xCLFlBQU0sZUFBZSxFQUFFLGdCQUFnQixFQUFFLFFBQVE7QUFBQSxJQUNuRCxPQUFPO0FBQ0wsWUFBTSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUTtBQUFBLElBQ25EO0FBR0EsVUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFFBQUksYUFBYSxVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ2pELGtCQUFZLFdBQVc7QUFDdkIsa0JBQVksYUFBYTtBQUN6QixZQUFNLGtCQUFrQixXQUFXO0FBQUEsSUFDckM7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLHFCQUFxQixjQUFjO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBS0EsYUFBVyxXQUFXLFdBQVcsYUFBYTtBQUM1QyxRQUFJLE1BQU0sWUFBWSxRQUFRLFFBQVEsRUFBRztBQUN6QyxVQUFNLGtCQUFrQixRQUFRLGFBQWEsUUFBUSxRQUFRO0FBQUEsRUFDL0Q7QUFDQSxNQUFJLFdBQVcsWUFBWSxTQUFTLEdBQUc7QUFDckMsVUFBTSxLQUFLLDBDQUEwQztBQUFBLE1BQ25EO0FBQUEsTUFDQSxTQUFTLFdBQVcsWUFBWTtBQUFBLE1BQ2hDLGFBQWEsTUFBTSxxQkFBcUI7QUFBQSxJQUMxQyxDQUFDO0FBQUEsRUFDSDtBQVFBLFFBQU0sZUFBZSxNQUFNLGtCQUFrQjtBQUM3QyxNQUFJLGlCQUFpQjtBQUNyQixRQUFNLGFBQXVDLENBQUM7QUFDOUMsYUFBVyxLQUFLLFdBQVcsUUFBUTtBQUNqQyxVQUFNLE9BQU8sYUFBYSxFQUFFLGNBQWMsSUFBSSxFQUFFLFFBQVE7QUFDeEQsVUFBTSxNQUFNO0FBQUEsTUFDVixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsSUFDSjtBQUNBLFFBQUksUUFBUSxLQUFLLFFBQVEsS0FBSztBQUM1Qix3QkFBa0I7QUFDbEI7QUFBQSxJQUNGO0FBQ0EsZUFBVyxLQUFLLENBQUM7QUFBQSxFQUNuQjtBQUNBLE1BQUksaUJBQWlCLEdBQUc7QUFDdEIsVUFBTSxLQUFLLG1DQUFtQztBQUFBLE1BQzVDO0FBQUEsTUFDQSxTQUFTO0FBQUEsTUFDVCxXQUFXLFdBQVc7QUFBQSxJQUN4QixDQUFDO0FBQUEsRUFDSDtBQUNBLE1BQUksV0FBVyxXQUFXLEVBQUc7QUFHN0IsUUFBTSxXQUFXLG9CQUFJLElBQThCO0FBQ25ELGFBQVcsS0FBSyxZQUFZO0FBQzFCLFVBQU0sTUFBTSxTQUFTLElBQUksRUFBRSxjQUFjLEtBQUssQ0FBQztBQUMvQyxRQUFJLEtBQUssQ0FBQztBQUNWLGFBQVMsSUFBSSxFQUFFLGdCQUFnQixHQUFHO0FBQUEsRUFDcEM7QUFFQSxhQUFXLENBQUMsUUFBUSxNQUFNLEtBQUssVUFBVTtBQUN2QyxVQUFNLE1BQU0sTUFBTSxnQkFBZ0IsUUFBUSxZQUFZLEtBQUssUUFBUTtBQUNuRSxRQUFJLFFBQVE7QUFDWixlQUFXLEtBQUssUUFBUTtBQUN0QixZQUFNLFdBQVcsSUFBSSxhQUFhLEVBQUUsUUFBUTtBQUM1QyxVQUFJLFVBQVU7QUFHWixpQkFBUyxlQUFlO0FBQ3hCLGlCQUFTLGFBQWEsRUFBRTtBQUN4QixpQkFBUyxnQkFBZ0IsRUFBRTtBQUMzQixpQkFBUyxjQUFjLEVBQUU7QUFDekIsaUJBQVMsY0FBYyxFQUFFO0FBQ3pCLGlCQUFTLGFBQWEsRUFBRTtBQUN4QixpQkFBUyxpQkFBaUIsRUFBRTtBQUM1QixjQUFNLE9BQU8sU0FBUyxtQkFBbUIsU0FBUyxtQkFBbUIsU0FBUyxDQUFDO0FBQy9FLGNBQU0sT0FBTyxFQUFFLG1CQUFtQixDQUFDO0FBQ25DLFlBQUksU0FBUyxDQUFDLFFBQVEsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjO0FBQzVELG1CQUFTLG1CQUFtQixLQUFLLElBQUk7QUFBQSxRQUN2QztBQUFBLE1BQ0YsT0FBTztBQUNMLGNBQU0sVUFBMEIsRUFBRSxHQUFHLEdBQUcsZ0JBQWdCLElBQUksT0FBTztBQUNuRSxZQUFJLGFBQWEsRUFBRSxRQUFRLElBQUk7QUFDL0IsaUJBQVM7QUFBQSxNQUNYO0FBQ0EsVUFBSSxDQUFDLElBQUksbUJBQW1CLFNBQVMsRUFBRSxRQUFRLEdBQUc7QUFDaEQsWUFBSSxtQkFBbUIsS0FBSyxFQUFFLFFBQVE7QUFBQSxNQUN4QztBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxlQUFlLFNBQVMsUUFBUSxFQUFHLEtBQUksZUFBZSxLQUFLLFFBQVE7QUFDNUUsUUFBSSxrQkFBa0I7QUFDdEIsVUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixVQUFNLGlCQUFpQixRQUFRLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRSxNQUFNO0FBQ25FLFFBQUksUUFBUSxHQUFHO0FBQ2IsWUFBTSxLQUFLLG1CQUFtQjtBQUFBLFFBQzVCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLE9BQU8sT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFO0FBQUEsTUFDdkMsQ0FBQztBQUdELFlBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxVQUFJLFdBQVcsTUFBTTtBQUNuQixlQUFPLGlCQUFpQjtBQUN4QixjQUFNLHFCQUFxQixNQUFNO0FBQUEsTUFDbkM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsVUFBVSx1QkFBdUI7QUFDakUsWUFBTSxZQUFZLFFBQVEsV0FBVztBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsZ0JBQ2IsUUFDQSxJQUNBLFdBQ0EsVUFDb0I7QUFDcEIsUUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBQ3JDLE1BQUksSUFBSyxRQUFPO0FBQ2hCLFFBQU0sTUFBaUI7QUFBQSxJQUNyQixRQUFRLFNBQVM7QUFBQSxJQUNqQixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixpQkFBaUI7QUFBQSxJQUNqQixjQUFjLENBQUM7QUFBQSxJQUNmLG9CQUFvQixDQUFDO0FBQUEsSUFDckIsZ0JBQWdCLENBQUMsUUFBUTtBQUFBLElBQ3pCLFlBQVk7QUFBQSxFQUNkO0FBQ0EsUUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixRQUFNLEtBQUssZUFBZSxFQUFFLFFBQVEsS0FBSyxXQUFXLElBQUksTUFBTSxFQUFFLENBQUM7QUFDakUsU0FBTztBQUNUO0FBSUEsSUFBSSxhQUE0QixRQUFRLFFBQVE7QUFjaEQsZUFBZSxtQkFBa0M7QUFDL0MsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLFFBQU0sVUFBb0IsQ0FBQztBQUMzQixhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUMvQyxVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksZUFBZTtBQUMzQyxRQUFJLE9BQU8sU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLGVBQWU7QUFDeEQsY0FBUSxLQUFLLE1BQU07QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsU0FBUyxNQUFNO0FBQ3BDO0FBRUEsZUFBZSw4QkFBNkM7QUFPMUQsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxLQUFNO0FBQ3hELFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxNQUFNLEtBQUssSUFBSTtBQUNyQixRQUFNLFVBQW9CLENBQUM7QUFDM0IsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELGNBQVEsS0FBSyxNQUFNO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxhQUFhLFNBQVMsTUFBTTtBQUNwQztBQUVBLGVBQWUsU0FBUyxRQUErQjtBQUNyRCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sYUFBYSxPQUFPLEtBQUssR0FBRyxHQUFHLE1BQU07QUFDN0M7QUFFQSxlQUFlLFlBQVksUUFBZ0IsUUFBK0I7QUFDeEUsUUFBTSxhQUFhLENBQUMsTUFBTSxHQUFHLE1BQU07QUFDckM7QUFFQSxlQUFlLGFBQWEsU0FBbUIsUUFBK0I7QUFDNUUsUUFBTSxTQUFTLENBQUMsR0FBRyxJQUFJLElBQUksT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7QUFDL0QsTUFBSSxPQUFPLFdBQVcsRUFBRztBQUN6QixRQUFNLE1BQU0sV0FBVyxLQUFLLE1BQU0sbUJBQW1CLFFBQVEsTUFBTSxDQUFDO0FBQ3BFLGVBQWEsSUFBSSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDL0IsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUIsU0FBbUIsUUFBK0I7QUFDbEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLFFBQXFCLENBQUM7QUFDNUIsYUFBVyxVQUFVLFNBQVM7QUFDNUIsVUFBTSxNQUFNLElBQUksTUFBTTtBQUN0QixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sU0FBUyxPQUFPLE9BQU8sSUFBSSxZQUFZO0FBQzdDLFFBQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsWUFBTSxlQUFlLE1BQU07QUFDM0IsWUFBTSxpQkFBaUIsUUFBUSxDQUFDO0FBQ2hDO0FBQUEsSUFDRjtBQUNBLFVBQU0sS0FBSyxlQUFlLFFBQVEsS0FBSyxNQUFNLENBQUM7QUFBQSxFQUNoRDtBQUNBLE1BQUksTUFBTSxXQUFXLEVBQUc7QUFFeEIsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sS0FBSyx1Q0FBdUM7QUFBQSxNQUNoRCxPQUFPLE1BQU07QUFBQSxNQUNiLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLElBQ3ZELENBQUM7QUFDRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsUUFBTSxRQUFRLE1BQU0sUUFBUSxDQUFDLFNBQVM7QUFBQSxJQUNwQztBQUFBLE1BQ0UsTUFBTSxLQUFLO0FBQUEsTUFDWCxlQUFlQyxVQUFTLEtBQUssVUFBVSxLQUFLLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLElBQ3RFO0FBQUEsSUFDQTtBQUFBLE1BQ0UsTUFBTSxLQUFLO0FBQUEsTUFDWCxlQUFlQSxVQUFTLEtBQUssVUFBVSxLQUFLLE1BQU0sTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLElBQ25FO0FBQUEsRUFDRixDQUFDO0FBQ0QsUUFBTSxZQUFZLHdCQUF3QixLQUFLO0FBRS9DLE1BQUk7QUFDRixVQUFNLFNBQVMsTUFBTSxPQUFPLFlBQVk7QUFBQSxNQUN0QztBQUFBLE1BQ0EsU0FBUztBQUFBLElBQ1gsQ0FBQztBQUNELFVBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxlQUFXLFFBQVEsT0FBTztBQUN4QixZQUFNLGlCQUFpQixNQUFNLCtCQUErQixJQUFJO0FBS2hFLFlBQU0sUUFBUSxNQUFNLFlBQVksR0FBRyxLQUFLLE1BQU07QUFDOUMsWUFBTSxTQUFRLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDbEQsWUFBTSxlQUFlLFFBQVEsS0FBSyxjQUFjLFFBQVEsS0FBSyxhQUFhO0FBQzFFLFlBQU0sWUFBWSxLQUFLLFFBQVE7QUFBQSxRQUM3QixZQUFZLGVBQWUsS0FBSyxPQUFPO0FBQUEsUUFDdkMsV0FBVztBQUFBLFFBQ1gsZUFBZSxLQUFLLElBQUk7QUFBQSxRQUN4QixpQkFBaUIsTUFBTSxrQkFBa0IsS0FBSyxLQUFLLE9BQU87QUFBQSxRQUMxRCxlQUFlO0FBQUEsTUFDakIsQ0FBQztBQUdELFlBQU0sUUFBUSxJQUFJLEtBQUssTUFBTSxLQUFLLENBQUM7QUFDbkMsWUFBTSxVQUFTLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ3RDLGlCQUFXLEtBQUssS0FBSyxRQUFRO0FBQzNCLGNBQU0sRUFBRSxRQUFRLElBQUk7QUFBQSxVQUNsQixJQUFJO0FBQUEsVUFDSixLQUFLO0FBQUEsWUFDSCxFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsVUFDSjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsVUFBSSxLQUFLLE1BQU0sSUFBSTtBQUNuQixZQUFNLEtBQUssbUJBQW1CO0FBQUEsUUFDNUIsUUFBUSxLQUFLO0FBQUEsUUFDYjtBQUFBLFFBQ0EsUUFBUSxLQUFLLE9BQU87QUFBQSxRQUNwQixLQUFLLEtBQUs7QUFBQSxRQUNWLE1BQU0sS0FBSztBQUFBLFFBQ1gsY0FBYyxPQUFPO0FBQUEsTUFDdkIsQ0FBQztBQUFBLElBQ0g7QUFDQSxVQUFNLGtCQUFrQixHQUFHO0FBQzNCLFVBQU0sS0FBSyx5QkFBeUI7QUFBQSxNQUNsQztBQUFBLE1BQ0EsTUFBTSxNQUFNO0FBQUEsTUFDWixPQUFPLE1BQU07QUFBQSxNQUNiLFFBQVEsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxPQUFPLFFBQVEsQ0FBQztBQUFBLE1BQ25FLFFBQVEsT0FBTztBQUFBLElBQ2pCLENBQUM7QUFDRDtBQUNFLFlBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsWUFBTSxjQUFjO0FBQUEsUUFDbEIsUUFBUTtBQUFBLFFBQ1IsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTztBQUFBLFFBQ1AsZUFBZSxLQUFLO0FBQUEsUUFDcEIsd0JBQXdCLEtBQUs7QUFBQSxRQUM3QixrQkFBa0I7QUFBQSxNQUNwQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osUUFBSSxlQUFlLGFBQWE7QUFDOUIsWUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxZQUFNLFNBQ0osSUFBSSxhQUFhLFNBQ2IsZUFDQSxJQUFJLGFBQWEsZUFDZixpQkFDQSxJQUFJLGFBQWEsWUFDZixrQkFDQSxLQUFLO0FBQ2YsWUFBTSxjQUFjO0FBQUEsUUFDbEI7QUFBQSxRQUNBLE9BQU8sS0FBSztBQUFBLFFBQ1osWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU8sSUFBSTtBQUFBLFFBQ1gsZUFBZSxLQUFLO0FBQUEsUUFDcEIsd0JBQXdCLEtBQUs7QUFBQSxRQUM3QixrQkFDRSxJQUFJLGFBQWEsZUFBZSxJQUFJLG1CQUFtQixLQUFLO0FBQUEsTUFDaEUsQ0FBQztBQUNELFlBQU0sTUFBTyxnQkFBZ0I7QUFBQSxRQUMzQjtBQUFBLFFBQ0EsU0FBUyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsUUFDckQsTUFBTSxNQUFNO0FBQUEsUUFDWixPQUFPLE1BQU07QUFBQSxRQUNiLFVBQVUsSUFBSTtBQUFBLFFBQ2QsUUFBUSxJQUFJO0FBQUEsUUFDWixTQUFTLElBQUk7QUFBQSxRQUNiLGtCQUFrQixJQUFJO0FBQUEsTUFDeEIsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMLFlBQU0sTUFBTyxnQkFBZ0I7QUFBQSxRQUMzQjtBQUFBLFFBQ0EsU0FBUyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsUUFDckQsTUFBTSxNQUFNO0FBQUEsUUFDWixPQUFPLE1BQU07QUFBQSxRQUNiLEdBQUcsY0FBYyxHQUFHO0FBQUEsTUFDdEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUVGLFVBQUU7QUFDQSxVQUFNLGVBQWU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyxlQUFlLFFBQWdCLEtBQWdCLFFBQXFDO0FBQzNGLFFBQU0sS0FBSyxXQUFXLElBQUksVUFBVTtBQUNwQyxRQUFNLE1BQU0sSUFBSSxXQUFXLE1BQU0sR0FBRyxFQUFFO0FBQ3RDLFFBQU0sV0FBVyxXQUFXLElBQUksTUFBTTtBQUN0QyxRQUFNLFVBQVUsT0FBTyxNQUFNLElBQUksRUFBRSxJQUFJLFFBQVE7QUFDL0MsUUFBTSxXQUFXLFFBQVEsTUFBTSxJQUFJLEVBQUUsSUFBSSxRQUFRO0FBQ2pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxTQUFTO0FBQUEsTUFDUCxnQkFBZ0I7QUFBQSxNQUNoQixnQkFBZ0IsSUFBSTtBQUFBLE1BQ3BCLGdCQUFnQjtBQUFBLE1BQ2hCLGFBQWEsSUFBSTtBQUFBLE1BQ2pCLFVBQVUsSUFBSSxlQUFlLEtBQUssR0FBRztBQUFBLE1BQ3JDLFlBQVksVUFBVTtBQUFBLE1BQ3RCLFlBQVksSUFBSTtBQUFBLE1BQ2hCO0FBQUEsSUFDRjtBQUFBLElBQ0EsTUFBTTtBQUFBLE1BQ0osZ0JBQWdCO0FBQUEsTUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxNQUNwQixnQkFBZ0I7QUFBQSxNQUNoQixhQUFhLElBQUk7QUFBQSxNQUNqQixvQkFBb0IsSUFBSTtBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyx3QkFBd0IsT0FBNEI7QUFDM0QsTUFBSSxNQUFNLFdBQVcsR0FBRztBQUN0QixVQUFNLE9BQU8sTUFBTSxDQUFDO0FBQ3BCLFdBQU8sWUFBWSxLQUFLLE1BQU0sSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxXQUFXLElBQUksS0FBSyxHQUFHLFNBQVMsS0FBSyxRQUFRO0FBQUEsRUFDcEk7QUFDQSxRQUFNLE9BQU8sQ0FBQyxHQUFHLElBQUksSUFBSSxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLO0FBQzlELFFBQU0sV0FBVyxLQUFLLFdBQVcsSUFBSSxLQUFLLENBQUMsSUFBSyxHQUFHLEtBQUssQ0FBQyxDQUFDLEtBQUssS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDO0FBQ3BGLFFBQU0sYUFBYSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQzlFLFNBQU8sa0JBQWtCLE1BQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxlQUFlLElBQUksS0FBSyxHQUFHLEtBQUssUUFBUTtBQUM1RztBQUVBLGVBQWUsK0JBQStCLE1BQWtDO0FBQzlFLFFBQU0sVUFBVSxNQUFNLGFBQWEsS0FBSyxNQUFNO0FBQzlDLE1BQUksQ0FBQyxRQUFTLFFBQU87QUFDckIsTUFBSSxRQUFRLFdBQVcsS0FBSyxJQUFJLE9BQVEsUUFBTyxPQUFPLEtBQUssUUFBUSxZQUFZLEVBQUU7QUFFakYsUUFBTSxZQUFZLElBQUk7QUFBQSxJQUNwQixLQUFLLE9BQU8sSUFBSSxDQUFDLE1BQU07QUFBQSxNQUNyQixFQUFFO0FBQUEsTUFDRixjQUFjLEVBQUUsWUFBWSxFQUFFLGVBQWUsRUFBRSxhQUFhLEVBQUUsYUFBYSxFQUFFLFlBQVk7QUFBQSxJQUMzRixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sa0JBQWtELENBQUM7QUFDekQsYUFBVyxDQUFDLFNBQVMsS0FBSyxLQUFLLE9BQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUNuRSxVQUFNLGVBQWUsVUFBVSxJQUFJLE9BQU87QUFDMUMsVUFBTSxhQUFhO0FBQUEsTUFDakIsTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLE1BQ04sTUFBTTtBQUFBLElBQ1I7QUFDQSxRQUFJLENBQUMsZ0JBQWdCLGlCQUFpQixZQUFZO0FBQ2hELHNCQUFnQixPQUFPLElBQUksRUFBRSxHQUFHLE1BQU07QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFFQSxRQUFNLGlCQUFpQixPQUFPLEtBQUssZUFBZSxFQUFFO0FBQ3BELE1BQUksbUJBQW1CLEdBQUc7QUFDeEIsVUFBTSxlQUFlLEtBQUssTUFBTTtBQUNoQyxXQUFPO0FBQUEsRUFDVDtBQUVBLFFBQU0sWUFBWSxTQUFTO0FBQzNCLGFBQVcsU0FBUyxPQUFPLE9BQU8sZUFBZSxHQUFHO0FBQ2xELFVBQU0saUJBQWlCO0FBQUEsRUFDekI7QUFDQSxRQUFNLGFBQWEsS0FBSyxRQUFRO0FBQUEsSUFDOUIsR0FBRztBQUFBLElBQ0gsUUFBUTtBQUFBLElBQ1IsWUFBWSxRQUFRO0FBQUEsSUFDcEIsY0FBYztBQUFBLElBQ2Qsb0JBQW9CLFFBQVEsbUJBQW1CLE9BQU8sQ0FBQyxPQUFPLE1BQU0sZUFBZTtBQUFBLEVBQ3JGLENBQUM7QUFDRCxRQUFNLEtBQUssb0NBQW9DO0FBQUEsSUFDN0MsUUFBUSxLQUFLO0FBQUEsSUFDYixlQUFlLEtBQUs7QUFBQSxJQUNwQixVQUFVLFdBQVcsU0FBUztBQUFBLElBQzlCLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFDRCxTQUFPO0FBQ1Q7QUFJQSxlQUFlLFdBQVcsUUFBK0I7QUFNdkQsUUFBTSxZQUFZLGlCQUFpQixNQUFNO0FBQ3pDLFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxRQUFRLEtBQUssZUFBZSxDQUFDO0FBQ25FLE1BQUksQ0FBRSxNQUFNLGFBQWEsTUFBTSxHQUFJO0FBQ2pDLFVBQU0sT0FBTSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNuQyxVQUFNLGFBQWEsUUFBUTtBQUFBLE1BQ3pCLFFBQVEsU0FBUztBQUFBLE1BQ2pCLGdCQUFnQjtBQUFBLE1BQ2hCLFlBQVk7QUFBQSxNQUNaLGlCQUFpQjtBQUFBLE1BQ2pCLGNBQWMsQ0FBQztBQUFBLE1BQ2Ysb0JBQW9CLENBQUM7QUFBQSxNQUNyQixnQkFBZ0IsQ0FBQztBQUFBLE1BQ2pCLFlBQVk7QUFBQSxJQUNkLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssV0FBVyxRQUFRLEtBQUssQ0FBQztBQUM1RDtBQUVBLGVBQWUsYUFBNEI7QUFDekMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsT0FBTyxTQUFTLE9BQU8sQ0FBQztBQUM5RCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLFdBQVcsRUFBRSxNQUFNO0FBQUEsRUFDM0I7QUFDRjtBQVdBLGVBQWUsa0JBQWlDO0FBQzlDLE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsUUFBUSxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQUEsRUFDdkUsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlEQUFpRCxjQUFjLEdBQUcsQ0FBQztBQUM5RTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLE1BQUksQ0FBQyxPQUFPLE9BQU8sSUFBSSxPQUFPLFlBQVksQ0FBQyxJQUFJLEtBQUs7QUFDbEQsVUFBTSxLQUFLLGtDQUFrQztBQUM3QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsZ0NBQWdDLEtBQUssSUFBSSxHQUFHLEdBQUc7QUFDbEQsVUFBTSxLQUFLLCtEQUErRDtBQUFBLE1BQ3hFLEtBQUssV0FBVyxJQUFJLEdBQUc7QUFBQSxJQUN6QixDQUFDO0FBQ0Q7QUFBQSxFQUNGO0FBQ0EsUUFBTSxLQUFLLCtCQUErQixFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBR3RFLE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTyxDQUFDLGNBQWM7QUFBQSxNQUN0QixPQUFPO0FBQUEsSUFDVCxDQUFDO0FBQ0QsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU8sQ0FBQyxZQUFZO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLHVDQUF1QyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ3RFO0FBR0EsTUFBSTtBQUNGLFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPO0FBQUEsTUFDUCxNQUFNLE1BQU07QUFDVixjQUFNLElBQUksT0FBTztBQUNqQixlQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQztBQUNwRCxtQkFBVyxNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDLEdBQUcsR0FBRztBQUMzRSxtQkFBVyxNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDLEdBQUcsSUFBSTtBQUFBLE1BQzlFO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssMENBQTBDLGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDekU7QUFDRjtBQWFBLElBQU0sa0JBQWtCO0FBRXhCLGVBQWUsa0JBQTBDO0FBQ3ZELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksZUFBZTtBQUM5RCxRQUFNLEtBQUssT0FBTyxlQUFlO0FBQ2pDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsZ0JBQWdCLElBQWtDO0FBQy9ELE1BQUksT0FBTyxNQUFNO0FBQ2YsVUFBTSxRQUFRLFFBQVEsTUFBTSxPQUFPLGVBQWU7QUFBQSxFQUNwRCxPQUFPO0FBQ0wsVUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxlQUFlLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDM0Q7QUFDRjtBQUVBLGVBQWUsbUJBQWtDO0FBQy9DLFFBQU0sUUFBUSxNQUFNLGtCQUFrQjtBQUN0QyxNQUFJLFVBQVUsR0FBRztBQUNmLFVBQU0sS0FBSyx5QkFBeUI7QUFDcEM7QUFBQSxFQUNGO0FBQ0EsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixRQUFNLFVBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsSUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxFQUFFLHFCQUFxQixDQUFDO0FBQUEsRUFDbkU7QUFDQSxRQUFNLGtCQUFrQjtBQUFBLElBQ3RCLGNBQWM7QUFBQSxJQUNkLFdBQVc7QUFBQSxJQUNYLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNsQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsdUJBQXFCLE9BQU87QUFDNUIsT0FBSyxZQUFZO0FBQ2pCLFFBQU0sS0FBSyx3QkFBd0IsRUFBRSxRQUFRLE9BQU8sY0FBYyxRQUFRLENBQUM7QUFDM0UsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsSUFBSSx3QkFBK0Q7QUFFbkUsU0FBUyxxQkFBcUIsU0FBdUI7QUFDbkQsTUFBSSwwQkFBMEIsS0FBTSxlQUFjLHFCQUFxQjtBQUN2RSwwQkFBd0IsWUFBWSxNQUFNO0FBQ3hDLFNBQUssWUFBWSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ2hDLFdBQUssS0FBSyx1QkFBdUIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUNyRCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLFNBQVMsc0JBQTRCO0FBQ25DLE1BQUksMEJBQTBCLE1BQU07QUFDbEMsa0JBQWMscUJBQXFCO0FBQ25DLDRCQUF3QjtBQUFBLEVBQzFCO0FBQ0Y7QUFFQSxlQUFlLG9CQUFtQztBQUNoRCxzQkFBb0I7QUFDcEIsUUFBTSxRQUFRLE9BQU8sTUFBTSxjQUFjO0FBQ3pDLFFBQU0sUUFBUSxNQUFNLGdCQUFnQjtBQUNwQyxRQUFNLGdCQUFnQixJQUFJO0FBQzFCLFFBQU0sT0FBTyxNQUFNLGtCQUFrQjtBQUNyQyxRQUFNLGtCQUFrQixJQUFJO0FBQzVCLFFBQU0sS0FBSywwQkFBMEI7QUFBQSxJQUNuQyxTQUFTLFVBQVU7QUFBQSxJQUNuQixXQUFXLE1BQU0sYUFBYTtBQUFBLEVBQ2hDLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGNBQTZCO0FBQzFDLE1BQUksT0FBTyxNQUFNLGtCQUFrQjtBQUNuQyxNQUFJLFNBQVMsTUFBTTtBQUVqQix3QkFBb0I7QUFDcEI7QUFBQSxFQUNGO0FBSUEsTUFBSSxLQUFLLGFBQWEsTUFBTTtBQUMxQixVQUFNLFVBQVUsS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUyxXQUFXO0FBQ2pFLFFBQUksVUFBVSxnQkFBZ0I7QUFDNUI7QUFBQSxJQUNGO0FBRUEsVUFBTSxLQUFLLGdEQUFnRDtBQUFBLE1BQ3pELFVBQVUsS0FBSyxTQUFTO0FBQUEsTUFDeEIsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUVELFVBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxlQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxVQUFJLElBQUksU0FBUyxLQUFLLFNBQVMsT0FBTyxHQUFHO0FBQ3ZDLGNBQU0sZUFBZSxRQUFRLEtBQUssU0FBUyxPQUFPO0FBQ2xEO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0sa0JBQWtCLElBQUk7QUFBQSxFQUM5QjtBQUVBLFFBQU0sU0FBUyxNQUFNLGtCQUFrQjtBQUN2QyxNQUFJLENBQUMsUUFBUTtBQUNYLHdCQUFvQjtBQUNwQixVQUFNLGdCQUFnQixJQUFJO0FBQzFCLFVBQU0sa0JBQWtCLElBQUk7QUFDNUIsVUFBTSxLQUFLLHlCQUF5QixFQUFFLFdBQVcsS0FBSyxVQUFVLENBQUM7QUFDakUsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU0sTUFBTSxpQkFBaUIsT0FBTyxNQUFNLFdBQVcsT0FBTyxPQUFPO0FBQ25FLE1BQUksUUFBUSxNQUFNLGdCQUFnQjtBQUNsQyxNQUFJLFVBQVUsTUFBTTtBQUNsQixRQUFJO0FBQ0YsWUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDOUIsUUFBUTtBQUNOLGNBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixRQUFJLFVBQVUsTUFBTTtBQUNsQixZQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDNUQsVUFBSSxPQUFPLElBQUksT0FBTyxTQUFVLE9BQU0sZ0JBQWdCLElBQUksRUFBRTtBQUFBLElBQzlELE9BQU87QUFDTCxZQUFNLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUNBLFdBQVEsTUFBTSxrQkFBa0IsS0FBTTtBQUN0QyxTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVMsT0FBTztBQUFBLE1BQ2hCLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUN0QztBQUNBLFVBQU0sa0JBQWtCLElBQUk7QUFDNUIsVUFBTSxLQUFLLGdCQUFnQjtBQUFBLE1BQ3pCLFFBQVEsT0FBTztBQUFBLE1BQ2YsVUFBVSxPQUFPO0FBQUEsTUFDakIsV0FBVyxNQUFNLGtCQUFrQjtBQUFBLE1BQ25DLFdBQVcsS0FBSztBQUFBLE1BQ2hCLGdCQUFnQixLQUFLO0FBQUEsSUFDdkIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDRDQUE0QztBQUFBLE1BQ3JELFFBQVEsT0FBTztBQUFBLE1BQ2YsVUFBVSxPQUFPO0FBQUEsTUFDakIsR0FBRyxjQUFjLEdBQUc7QUFBQSxJQUN0QixDQUFDO0FBQ0QsVUFBTSxlQUFlLE9BQU8sUUFBUSxPQUFPLE9BQU87QUFDbEQsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLGtCQUFrQixJQUFJO0FBQUEsRUFDOUI7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFXQSxJQUFNLHNCQUFzQjtBQUU1QixlQUFlLHFCQUE2QztBQUMxRCxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLG1CQUFtQjtBQUNsRSxRQUFNLEtBQUssT0FBTyxtQkFBbUI7QUFDckMsU0FBTyxPQUFPLE9BQU8sV0FBVyxLQUFLO0FBQ3ZDO0FBRUEsZUFBZSxtQkFBbUIsSUFBa0M7QUFDbEUsTUFBSSxPQUFPLEtBQU0sT0FBTSxRQUFRLFFBQVEsTUFBTSxPQUFPLG1CQUFtQjtBQUFBLE1BQ2xFLE9BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsbUJBQW1CLEdBQUcsR0FBRyxDQUFDO0FBQ3BFO0FBRUEsZUFBZSxzQkFBcUM7QUFDbEQsUUFBTSxRQUFRLE1BQU0scUJBQXFCO0FBQ3pDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLDZCQUE2QjtBQUN4QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCwwQkFBd0IsT0FBTztBQUMvQixPQUFLLGVBQWU7QUFDcEIsUUFBTSxLQUFLLDRCQUE0QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMvRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLDJCQUFrRTtBQUV0RSxTQUFTLHdCQUF3QixTQUF1QjtBQUN0RCxNQUFJLDZCQUE2QixLQUFNLGVBQWMsd0JBQXdCO0FBQzdFLDZCQUEyQixZQUFZLE1BQU07QUFDM0MsU0FBSyxlQUFlLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDbkMsV0FBSyxLQUFLLDJCQUEyQixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3pELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyx5QkFBK0I7QUFDdEMsTUFBSSw2QkFBNkIsTUFBTTtBQUNyQyxrQkFBYyx3QkFBd0I7QUFDdEMsK0JBQTJCO0FBQUEsRUFDN0I7QUFDRjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHlCQUF1QjtBQUN2QixRQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLFFBQVEsTUFBTSxtQkFBbUI7QUFDdkMsUUFBTSxtQkFBbUIsSUFBSTtBQUM3QixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxpQkFBZ0M7QUFDN0MsTUFBSSxPQUFPLE1BQU0scUJBQXFCO0FBQ3RDLE1BQUksU0FBUyxNQUFNO0FBQ2pCLDJCQUF1QjtBQUN2QjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGdCQUFnQjtBQUM1QjtBQUFBLElBQ0Y7QUFDQSxVQUFNLEtBQUssb0RBQW9EO0FBQUEsTUFDN0QsVUFBVSxLQUFLLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsSUFDYixDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsS0FBSyxTQUFTLE9BQU87QUFDN0MsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQUEsRUFDakM7QUFFQSxRQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsTUFBSSxDQUFDLFFBQVE7QUFDWCwyQkFBdUI7QUFDdkIsVUFBTSxtQkFBbUIsSUFBSTtBQUM3QixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sS0FBSyw2QkFBNkIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ3JFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFHQSxNQUFJLE1BQU0sWUFBWSxPQUFPLE9BQU8sR0FBRztBQUNyQyxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFNQSxRQUFNLE1BQ0osT0FBTyxXQUFXLGFBQ2QsMEJBQTBCLE9BQU8sT0FBTyxLQUN4QyxpQkFBaUIsT0FBTyxNQUFNLFdBQVcsT0FBTyxPQUFPO0FBQzdELE1BQUksUUFBUSxNQUFNLG1CQUFtQjtBQUNyQyxNQUFJLFVBQVUsTUFBTTtBQUNsQixRQUFJO0FBQ0YsWUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDOUIsUUFBUTtBQUNOLGNBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixRQUFJLFVBQVUsTUFBTTtBQUNsQixZQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDNUQsVUFBSSxPQUFPLElBQUksT0FBTyxTQUFVLE9BQU0sbUJBQW1CLElBQUksRUFBRTtBQUFBLElBQ2pFLE9BQU87QUFDTCxZQUFNLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUNBLFdBQVEsTUFBTSxxQkFBcUIsS0FBTTtBQUN6QyxTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVMsT0FBTztBQUFBLE1BQ2hCLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUN0QztBQUNBLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLG9CQUFvQjtBQUFBLE1BQzdCLFVBQVUsT0FBTztBQUFBLE1BQ2pCLGFBQWEsT0FBTyxXQUFXLGFBQWEsT0FBTyxPQUFPO0FBQUEsTUFDMUQsV0FBVyxNQUFNLHFCQUFxQjtBQUFBLE1BQ3RDLFdBQVcsS0FBSztBQUFBLE1BQ2hCLGdCQUFnQixLQUFLO0FBQUEsSUFDdkIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGdEQUFnRDtBQUFBLE1BQ3pELFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUlBLGVBQWUsV0FDYixRQUNBLFVBQ0EsS0FDQSxLQUNBLEtBQ2U7QUFDZixRQUFNLE1BQU8sd0JBQXdCLEVBQUUsUUFBUSxVQUFVLEtBQUssR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQ3JGLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsS0FBTTtBQUN4RCxRQUFNLFVBQTZCO0FBQUEsSUFDakMsZ0JBQWdCO0FBQUEsSUFDaEI7QUFBQSxJQUNBO0FBQUEsSUFDQSxjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDcEMsWUFBWTtBQUFBLElBQ1osT0FBTyxjQUFjLEdBQUc7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLEtBQUssV0FBVyxRQUFRLFdBQVc7QUFDekMsUUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxDQUFDO0FBQy9DLFFBQU0sT0FBTyxtQkFBbUIsRUFBRSxJQUFJLElBQUk7QUFDMUMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ25CO0FBQUEsTUFDQSxlQUFlQSxVQUFTLEtBQUssVUFBVSxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUMvRCxTQUFTLGVBQWUsTUFBTSxJQUFJLFFBQVE7QUFBQSxJQUM1QyxDQUFDO0FBQUEsRUFDSCxTQUFTLE1BQU07QUFDYixVQUFNLE1BQU8sNEJBQTRCLEVBQUUsR0FBRyxjQUFjLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDckU7QUFDRjtBQUVBLGVBQWUsS0FBSyxHQUE0QjtBQUM5QyxRQUFNLE1BQU0sSUFBSSxZQUFZLEVBQUUsT0FBTyxDQUFDO0FBQ3RDLFFBQU0sU0FBUyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsR0FBRztBQUN4RCxRQUFNLE1BQU0sTUFBTSxLQUFLLElBQUksV0FBVyxNQUFNLENBQUMsRUFDMUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRyxDQUFDLEVBQzFDLEtBQUssRUFBRTtBQUNWLFNBQU8sSUFBSSxNQUFNLEdBQUcsQ0FBQztBQUN2QjtBQUlBLGVBQWUsaUJBQWlCLE9BQStCO0FBQzdELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsTUFBTTtBQUN0RCxVQUFNLGNBQWM7QUFBQSxNQUNsQixRQUFRO0FBQUEsTUFDUixPQUFPO0FBQUEsTUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZTtBQUFBLE1BQ2Ysd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLE1BQUksQ0FBQyxPQUFPO0FBSVYsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBS0EsUUFBSSxLQUFLLFdBQVc7QUFDbEIsWUFBTSxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVM7QUFDbEQsVUFBSSxNQUFNLDhCQUErQjtBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxJQUFJLE1BQU0sT0FBTyxpQkFBaUI7QUFJeEMsUUFBSSxXQUFXO0FBQ2YsUUFBSSxTQUFTLFVBQVUsU0FBUyxXQUFXLEVBQUUsZ0JBQWdCO0FBQzNELGlCQUFXLE1BQU0sT0FBTyxhQUFhLFNBQVMsTUFBTTtBQUFBLElBQ3REO0FBQ0EsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTyxFQUFFO0FBQUEsTUFDVCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZSxFQUFFO0FBQUEsTUFDakIsd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sS0FBSyx1QkFBdUI7QUFBQSxNQUNoQyxPQUFPLEVBQUU7QUFBQSxNQUNULE1BQU0sRUFBRTtBQUFBLE1BQ1IsZ0JBQWdCLEVBQUU7QUFBQSxNQUNsQixtQkFBbUIsU0FBUztBQUFBLE1BQzVCLDBCQUEwQjtBQUFBLElBQzVCLENBQUM7QUFDRCxRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sS0FBSyw4Q0FBOEM7QUFBQSxRQUN2RCxZQUFZLFNBQVM7QUFBQSxRQUNyQixnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLEtBQUssd0NBQXdDLEVBQUU7QUFBQSxNQUNqRCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFNLGVBQWUsY0FBYyxJQUFJLFdBQVc7QUFDeEQsVUFBTSxTQUNKLFFBQVEsU0FDSixlQUNBLFFBQVEsZUFDTixpQkFDQSxRQUFRLFlBQ04sa0JBQ0E7QUFDVixVQUFNLFVBQ0osZUFBZSxlQUFlLFFBQVEsZUFBZSxJQUFJLG1CQUFtQjtBQUM5RSxVQUFNLGNBQWM7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU8sY0FBYyxHQUFHLEVBQUU7QUFBQSxNQUMxQixlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxLQUFLLDJCQUEyQjtBQUFBLE1BQ3BDLFVBQVU7QUFBQSxNQUNWLGtCQUFrQjtBQUFBLE1BQ2xCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLG9CQUFvQixPQUErQjtBQUNoRSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLEtBQUs7QUFDakIsVUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsT0FBTztBQUlWLFVBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBSUEsVUFBTSxnQkFBZ0IsTUFBTSx1QkFBdUI7QUFDbkQsUUFBSSxlQUFlO0FBQ2pCLFlBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sYUFBYTtBQUNqRCxVQUFJLE9BQU8sU0FBUyxHQUFHLEtBQUssTUFBTSw4QkFBK0I7QUFBQSxJQUNuRTtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxNQUFNLE9BQU8sYUFBYSxzQkFBc0I7QUFDN0QsUUFBSSxDQUFDLE1BQU07QUFDVCxVQUFJLE1BQU8sT0FBTSxLQUFLLGlEQUFpRDtBQUN2RSxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFTLGtCQUFrQixJQUFJO0FBQ3JDLFFBQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsWUFBTSxLQUFLLDhDQUE4QztBQUN6RCxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxZQUFZLE1BQU07QUFDeEIsVUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRCxRQUFJLE1BQU8sT0FBTSxLQUFLLDJCQUEyQixFQUFFLE9BQU8sT0FBTyxPQUFPLENBQUM7QUFBQSxFQUMzRSxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaURBQWlELGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDaEY7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFJQSxlQUFlLGlCQUFnQztBQUM3QyxRQUFNLFFBQVEsTUFBTSxXQUFXO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsTUFBTSxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFO0FBRUEsZUFBZSxhQUFzQztBQUNuRCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksV0FBVztBQUNmLE1BQUk7QUFDRixVQUFNLE9BQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUMzRixlQUFXLEtBQUs7QUFBQSxFQUNsQixRQUFRO0FBQUEsRUFHUjtBQUNBLFFBQU0sZ0JBQWdCLE1BQU0sa0JBQWtCO0FBQzlDLFFBQU0sbUJBQW1CLE1BQU0scUJBQXFCO0FBQ3BELFFBQU0sY0FBYyxNQUFNLGtCQUFrQjtBQUM1QyxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVCxVQUFVLGVBQWUsUUFBUTtBQUFBLElBQ2pDLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsWUFBWTtBQUFBLE1BQ1YsUUFBUSxtQkFBbUIsUUFBUSxvQkFBb0I7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsYUFBYSxnQkFBZ0IsZUFBZTtBQUFBLE1BQzVDLGVBQWUsZ0JBQWdCLGlCQUFpQjtBQUFBLE1BQ2hELGVBQWUsZ0JBQWdCLGlCQUFpQjtBQUFBLElBQ2xEO0FBQUEsSUFDQSxjQUFjO0FBQUEsTUFDWixPQUFPO0FBQUEsTUFDUCxTQUFTLDBCQUEwQjtBQUFBLE1BQ25DLFdBQVcsYUFBYSxhQUFhO0FBQUEsTUFDckMsZ0JBQWdCLGFBQWEsZ0JBQWdCO0FBQUEsSUFDL0M7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLE1BQ2YsT0FBTztBQUFBLE1BQ1AsU0FBUyw2QkFBNkI7QUFBQSxNQUN0QyxXQUFXLGdCQUFnQixhQUFhO0FBQUEsTUFDeEMsZ0JBQWdCLGdCQUFnQixnQkFBZ0I7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUF5QztBQUMvRCxTQUFPO0FBQUEsSUFDTCxPQUFPLEVBQUU7QUFBQSxJQUNULE1BQU0sRUFBRTtBQUFBLElBQ1IsUUFBUSxFQUFFO0FBQUEsSUFDVixTQUFTLEVBQUU7QUFBQSxJQUNYLGFBQWEsRUFBRTtBQUFBLElBQ2YsY0FBYyxFQUFFO0FBQUEsSUFDaEIsdUJBQXVCLEVBQUU7QUFBQSxJQUN6QixRQUFRLEVBQUUsSUFBSSxTQUFTO0FBQUEsSUFDdkIsV0FBVyxFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSTtBQUFBLEVBQ25EO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsS0FBcUI7QUFFdkMsUUFBTSxJQUFJLElBQUksS0FBSyxHQUFHO0FBQ3RCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTyxJQUFJLFFBQVEsU0FBUyxFQUFFO0FBQzdELFFBQU0sTUFBTSxDQUFDLEdBQVcsSUFBSSxNQUFNLE9BQU8sQ0FBQyxFQUFFLFNBQVMsR0FBRyxHQUFHO0FBQzNELFNBQ0UsR0FBRyxFQUFFLGVBQWUsQ0FBQyxJQUFJLElBQUksRUFBRSxZQUFZLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQ3BFLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQztBQUU5RTtBQUVBLFNBQVMsVUFBVSxHQUFxQjtBQUN0QyxTQUFPLFdBQVcsRUFBRSxLQUFLLGNBQWMsRUFBRSxJQUFJO0FBQy9DO0FBU0EsU0FBUyxlQUFlLE1BQXlCO0FBQy9DLFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUMsT0FBTTtBQUNaLFVBQUksT0FBT0EsS0FBSSxlQUFlLFNBQVUsTUFBSyxJQUFJQSxLQUFJLFVBQVU7QUFDL0QsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLFNBQU8sQ0FBQyxHQUFHLElBQUksRUFBRSxLQUFLO0FBQ3hCO0FBT0EsU0FBUyxvQkFBb0IsTUFBZSxVQUFtQztBQUM3RSxRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1BLE9BQU07QUFDWixVQUFJQSxLQUFJLGVBQWUsVUFBVTtBQUMvQixlQUFPLE9BQU8sS0FBS0EsSUFBRyxFQUFFLEtBQUs7QUFBQSxNQUMvQjtBQUNBLGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFRQSxTQUFTLGlCQUFpQixNQUFlLFVBQWtCLE1BQXlCO0FBQ2xGLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixNQUFJLFFBQXdDO0FBQzVDLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNQSxPQUFNO0FBQ1osVUFBSUEsS0FBSSxlQUFlLFVBQVU7QUFDL0IsZ0JBQVFBO0FBQ1I7QUFBQSxNQUNGO0FBQ0EsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxNQUFPLFFBQU87QUFDbkIsTUFBSSxNQUFlO0FBQ25CLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVLFFBQU8sSUFBSSxRQUFRLE9BQU8sU0FBUyxPQUFPLEdBQUc7QUFDMUYsVUFBTyxJQUFnQyxHQUFHO0FBQUEsRUFDNUM7QUFDQSxNQUFJLFFBQVEsT0FBVyxRQUFPO0FBQzlCLE1BQUksUUFBUSxLQUFNLFFBQU87QUFDekIsTUFBSSxPQUFPLFFBQVEsU0FBVSxRQUFPLElBQUksT0FBTyxHQUFHO0FBQ2xELE1BQUksTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLGNBQWMsSUFBSSxNQUFNO0FBQ3ZELFNBQU8sT0FBTyxLQUFLLEdBQThCLEVBQUUsS0FBSztBQUMxRDtBQUVBLFNBQVMsV0FBVyxHQUFtQjtBQUdyQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksSUFBSSxDQUFDO0FBQ3hCLFVBQU0sT0FBTyxPQUFPLFlBQVksT0FBTyxTQUFTLFlBQU87QUFDdkQsV0FBTyxPQUFPLFNBQVMsV0FBVyxPQUFPLFNBQVMsZ0JBQzlDLE9BQ0EsR0FBRyxPQUFPLElBQUksR0FBRyxJQUFJO0FBQUEsRUFDM0IsUUFBUTtBQUNOLFdBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUFBLEVBQ2hEO0FBQ0Y7QUFLQyxXQUF1QyxlQUFlO0FBQUEsRUFDckQ7QUFBQSxFQUNBLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFNBQVM7QUFBQSxFQUNULFVBQVUsTUFBTSxTQUFTLFVBQVU7QUFBQSxFQUNuQyxPQUFPO0FBQUEsRUFDUCxjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxlQUFlO0FBQUEsRUFDZixpQkFBaUI7QUFBQSxFQUNqQixpQkFBaUI7QUFBQSxFQUNqQixrQkFBa0I7QUFDcEI7IiwKICAibmFtZXMiOiBbInRvQmFzZTY0IiwgIm9iaiIsICJpbmZvIiwgInRvQmFzZTY0IiwgIm9iaiJdCn0K
