"use strict";
(() => {
  // extension/src/content.ts
  var TARGET = "IMM_ARCHIVE_CAPTURE";
  var READY = "IMM_ARCHIVE_HOOK_READY";
  var UNFOLD_SYNC_MS = 2e3;
  var UNFOLD_SCAN_DEBOUNCE_MS = 250;
  var unfoldEnabled = false;
  var unfoldCoreHandles = /* @__PURE__ */ new Set();
  var unfoldRelevantTweetIds = /* @__PURE__ */ new Set();
  var unfoldScanTimer = null;
  var unfoldedControls = /* @__PURE__ */ new WeakSet();
  void browser.runtime.sendMessage({ type: "content-alive", url: location.href }).catch((err) => {
    console.warn("[imm-archive] content-alive ping failed", err);
  });
  function fallbackInject() {
    try {
      const src = browser.runtime.getURL("page-hook.js");
      const script = document.createElement("script");
      script.src = src;
      script.async = false;
      script.dataset.immArchive = "1";
      (document.head || document.documentElement).appendChild(script);
      script.onload = () => script.remove();
      script.onerror = () => {
        browser.runtime.sendMessage({
          type: "log-content-event",
          level: "warn",
          msg: "inline page-hook injection blocked (CSP); relying on MAIN-world content script",
          url: location.href
        }).catch(() => {
        });
      };
    } catch (err) {
      console.warn("[imm-archive] inline page-hook injection threw", err);
    }
  }
  fallbackInject();
  function normalizeHandle(raw) {
    if (!raw) return null;
    const cleaned = raw.trim().replace(/^@/, "").toLowerCase();
    return cleaned.length > 0 ? cleaned : null;
  }
  var STATUS_HOSTS = /* @__PURE__ */ new Set(["x.com", "twitter.com", "mobile.twitter.com"]);
  function parseTweetUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const parts = u.pathname.split("/").filter(Boolean);
      const statusIdx = parts.indexOf("status");
      if (statusIdx <= 0) return null;
      const handle = normalizeHandle(parts[statusIdx - 1] ?? null);
      const id = parts[statusIdx + 1] ?? null;
      if (!handle || !id || !/^\d+$/.test(id)) return null;
      return { handle, id };
    } catch {
      return null;
    }
  }
  function parseHandleUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const first = u.pathname.split("/").filter(Boolean)[0];
      if (!first || first === "i" || first === "intent" || first === "search") return null;
      return normalizeHandle(first);
    } catch {
      return null;
    }
  }
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none";
  }
  function nearestTweetContainer(el) {
    return el.closest("article") ?? el.closest('div[data-testid="cellInnerDiv"]');
  }
  function isReplyToCore(container) {
    const text = (container.textContent || "").toLowerCase();
    if (!text.includes("replying to")) return false;
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const handle = parseHandleUrl(link.getAttribute("href"));
      if (handle && unfoldCoreHandles.has(handle)) return true;
    }
    return false;
  }
  function isCoreRelevant(container) {
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const tweet = parseTweetUrl(link.getAttribute("href"));
      if (!tweet) continue;
      if (unfoldCoreHandles.has(tweet.handle)) return true;
      if (unfoldRelevantTweetIds.has(tweet.id)) return true;
    }
    return isReplyToCore(container);
  }
  function scanAndUnfoldShowMore() {
    unfoldScanTimer = null;
    if (!unfoldEnabled || unfoldCoreHandles.size === 0) return;
    const selectors = [
      '[data-testid="tweet-text-show-more-link"]',
      'button[data-testid="tweet-text-show-more-link"]',
      'article [role="button"][tabindex="0"]',
      'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
    ];
    const seen = /* @__PURE__ */ new Set();
    let clicked = 0;
    for (const sel of selectors) {
      for (const el of Array.from(document.querySelectorAll(sel))) {
        if (seen.has(el) || unfoldedControls.has(el)) continue;
        seen.add(el);
        if ((el.textContent || "").trim().toLowerCase() !== "show more") continue;
        if (!isVisible(el)) continue;
        const container = nearestTweetContainer(el);
        if (!container || !isCoreRelevant(container)) continue;
        unfoldedControls.add(el);
        try {
          el.click();
          clicked += 1;
        } catch {
        }
      }
    }
    if (clicked > 0) {
      browser.runtime.sendMessage({ type: "show-more-unfolded", count: clicked }).catch(() => {
      });
    }
  }
  function scheduleUnfoldScan(delay = UNFOLD_SCAN_DEBOUNCE_MS) {
    if (unfoldScanTimer !== null) return;
    unfoldScanTimer = setTimeout(scanAndUnfoldShowMore, delay);
  }
  async function refreshUnfoldTargets() {
    try {
      const response = await browser.runtime.sendMessage({
        type: "get-unfold-targets"
      });
      const raw = response && typeof response === "object" ? response : {};
      unfoldEnabled = raw.enabled !== false;
      unfoldCoreHandles = new Set(
        (raw.coreHandles ?? []).map((h) => h.toLowerCase().replace(/^@/, ""))
      );
      unfoldRelevantTweetIds = new Set(raw.relevantTweetIds ?? []);
      scheduleUnfoldScan(0);
    } catch {
      unfoldEnabled = false;
    }
  }
  function installUnfoldObserver() {
    const root = document.documentElement || document.body;
    if (!root) {
      setTimeout(installUnfoldObserver, 100);
      return;
    }
    const observer = new MutationObserver(() => scheduleUnfoldScan());
    observer.observe(root, { childList: true, subtree: true });
    window.addEventListener("scroll", () => scheduleUnfoldScan(), { passive: true });
    void refreshUnfoldTargets();
    setInterval(() => {
      void refreshUnfoldTargets();
    }, UNFOLD_SYNC_MS);
  }
  installUnfoldObserver();
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== "object") return;
    const d = data;
    if (d.source === READY) {
      browser.runtime.sendMessage({
        type: "page-hook-active",
        url: typeof d.url === "string" ? d.url : location.href
      }).catch(() => {
      });
      return;
    }
    if (d.source !== TARGET) return;
    const endpoint = typeof d.endpoint === "string" ? d.endpoint : null;
    const url = typeof d.url === "string" ? d.url : null;
    const pageUrl = typeof d.page_url === "string" ? d.page_url : location.href;
    const response = d.response;
    if (!endpoint || !url || response === void 0) return;
    browser.runtime.sendMessage({ type: "graphql-capture", endpoint, url, pageUrl, response }).catch((err) => {
      console.warn("[imm-archive] sendMessage failed", err);
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbnRlbnQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKlxyXG4gKiBjb250ZW50LnRzIFx1MjAxNCBjb250ZW50LXNjcmlwdCBjb250ZXh0IChpc29sYXRlZCB3b3JsZCkuXHJcbiAqXHJcbiAqIFRoZSBhY3R1YWwgcGFnZS1ob29rICh3aGljaCBwYXRjaGVzIGBmZXRjaGAgLyBgWEhSYCkgaXMgZGVjbGFyZWQgYXMgYVxyXG4gKiBzZXBhcmF0ZSBjb250ZW50IHNjcmlwdCB3aXRoIGB3b3JsZDogXCJNQUlOXCJgIGluIHRoZSBtYW5pZmVzdCwgc28gaXQgcnVuc1xyXG4gKiBpbiB0aGUgcGFnZSB3b3JsZCBkaXJlY3RseSB3aXRob3V0IHVzIGhhdmluZyB0byBpbmplY3QgYSA8c2NyaXB0PiB0YWcgXHUyMDE0XHJcbiAqIHdoaWNoIFgncyBub25jZS1iYXNlZCBDU1Agd291bGQgYmxvY2suXHJcbiAqXHJcbiAqIFRoaXMgZmlsZSBkb2VzIHRocmVlIHRoaW5nczpcclxuICpcclxuICogICAxLiBQaW5ncyB0aGUgYmFja2dyb3VuZCBvbiBsb2FkIHNvIHRoZSBhY3Rpdml0eSB0YWlsIGNvbmZpcm1zIHRoZVxyXG4gKiAgICAgIGNvbnRlbnQgc2NyaXB0IHJlYWNoZWQgdGhlIFggcGFnZSAodXNlZnVsIHdoZW4gZGlhZ25vc2luZyBhIHNpbGVudFxyXG4gKiAgICAgIFwiY2FwdHVyZS1ub3cgZG9lcyBub3RoaW5nXCIgZmFpbHVyZSkuXHJcbiAqICAgMi4gQXMgYSBkZWZlbnNpdmUgZmFsbGJhY2ssIGFsc28gdHJpZXMgdG8gaW5qZWN0IGBwYWdlLWhvb2suanNgIHZpYSBhXHJcbiAqICAgICAgc2NyaXB0IHRhZy4gSGFybWxlc3Mgb24gbW9kZXJuIEZpcmVmb3ggKHRoZSBwYWdlLWhvb2sncyBUQUcgZ3VhcmRcclxuICogICAgICBwcmV2ZW50cyBkb3VibGUtaW5pdCk7IGNvdmVycyB0aGUgcmFyZSBjYXNlIHdoZXJlIHRoZSBNQUlOLXdvcmxkXHJcbiAqICAgICAgY29udGVudCBzY3JpcHQgZW50cnkgaXNuJ3QgaG9ub3JlZC5cclxuICogICAzLiBCcmlkZ2VzIGB3aW5kb3cucG9zdE1lc3NhZ2VgIGZyb20gdGhlIHBhZ2UgaG9vayB0byB0aGUgYmFja2dyb3VuZDpcclxuICogICAgICBib3RoIHRoZSBgKl9SRUFEWWAgYm9vdCBwaW5nIGFuZCB0aGUgYElNTV9BUkNISVZFX0NBUFRVUkVgIHBheWxvYWRcclxuICogICAgICBldmVudHMuXHJcbiAqL1xyXG5cclxuY29uc3QgVEFSR0VUID0gJ0lNTV9BUkNISVZFX0NBUFRVUkUnO1xyXG5jb25zdCBSRUFEWSA9ICdJTU1fQVJDSElWRV9IT09LX1JFQURZJztcclxuY29uc3QgVU5GT0xEX1NZTkNfTVMgPSAyXzAwMDtcclxuY29uc3QgVU5GT0xEX1NDQU5fREVCT1VOQ0VfTVMgPSAyNTA7XHJcblxyXG5pbnRlcmZhY2UgVW5mb2xkVGFyZ2V0c1Jlc3BvbnNlIHtcclxuICBlbmFibGVkPzogYm9vbGVhbjtcclxuICBjb3JlSGFuZGxlcz86IHN0cmluZ1tdO1xyXG4gIHJlbGV2YW50VHdlZXRJZHM/OiBzdHJpbmdbXTtcclxufVxyXG5cclxubGV0IHVuZm9sZEVuYWJsZWQgPSBmYWxzZTtcclxubGV0IHVuZm9sZENvcmVIYW5kbGVzID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbmxldCB1bmZvbGRSZWxldmFudFR3ZWV0SWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbmxldCB1bmZvbGRTY2FuVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbCA9IG51bGw7XHJcbmNvbnN0IHVuZm9sZGVkQ29udHJvbHMgPSBuZXcgV2Vha1NldDxFbGVtZW50PigpO1xyXG5cclxudm9pZCBicm93c2VyLnJ1bnRpbWVcclxuICAuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnY29udGVudC1hbGl2ZScsIHVybDogbG9jYXRpb24uaHJlZiB9KVxyXG4gIC5jYXRjaCgoZXJyOiB1bmtub3duKSA9PiB7XHJcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gY29udGVudC1hbGl2ZSBwaW5nIGZhaWxlZCcsIGVycik7XHJcbiAgfSk7XHJcblxyXG5mdW5jdGlvbiBmYWxsYmFja0luamVjdCgpOiB2b2lkIHtcclxuICB0cnkge1xyXG4gICAgY29uc3Qgc3JjID0gYnJvd3Nlci5ydW50aW1lLmdldFVSTCgncGFnZS1ob29rLmpzJyk7XHJcbiAgICBjb25zdCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtcclxuICAgIHNjcmlwdC5zcmMgPSBzcmM7XHJcbiAgICBzY3JpcHQuYXN5bmMgPSBmYWxzZTtcclxuICAgIHNjcmlwdC5kYXRhc2V0LmltbUFyY2hpdmUgPSAnMSc7XHJcbiAgICAoZG9jdW1lbnQuaGVhZCB8fCBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpLmFwcGVuZENoaWxkKHNjcmlwdCk7XHJcbiAgICBzY3JpcHQub25sb2FkID0gKCkgPT4gc2NyaXB0LnJlbW92ZSgpO1xyXG4gICAgc2NyaXB0Lm9uZXJyb3IgPSAoKSA9PiB7XHJcbiAgICAgIC8vIENTUCBwcm9iYWJseSBibG9ja2VkIHRoaXMuIE5vdCBmYXRhbCBcdTIwMTQgdGhlIE1BSU4td29ybGQgY29udGVudCBzY3JpcHRcclxuICAgICAgLy8gZGVjbGFyZWQgaW4gbWFuaWZlc3QuanNvbiBpcyB0aGUgcHJpbWFyeSBwYXRoLiBTdXJmYWNlIGFzIGEgbG9nIHNvXHJcbiAgICAgIC8vIHdlIGtub3cgd2hhdCBoYXBwZW5lZCB3aXRob3V0IGx5aW5nIGFib3V0IHN1Y2Nlc3MuXHJcbiAgICAgIGJyb3dzZXIucnVudGltZVxyXG4gICAgICAgIC5zZW5kTWVzc2FnZSh7XHJcbiAgICAgICAgICB0eXBlOiAnbG9nLWNvbnRlbnQtZXZlbnQnLFxyXG4gICAgICAgICAgbGV2ZWw6ICd3YXJuJyxcclxuICAgICAgICAgIG1zZzogJ2lubGluZSBwYWdlLWhvb2sgaW5qZWN0aW9uIGJsb2NrZWQgKENTUCk7IHJlbHlpbmcgb24gTUFJTi13b3JsZCBjb250ZW50IHNjcmlwdCcsXHJcbiAgICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWYsXHJcbiAgICAgICAgfSlcclxuICAgICAgICAuY2F0Y2goKCkgPT4ge30pO1xyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBpbmxpbmUgcGFnZS1ob29rIGluamVjdGlvbiB0aHJldycsIGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mYWxsYmFja0luamVjdCgpO1xyXG5cclxuZnVuY3Rpb24gbm9ybWFsaXplSGFuZGxlKHJhdzogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xyXG4gIGlmICghcmF3KSByZXR1cm4gbnVsbDtcclxuICBjb25zdCBjbGVhbmVkID0gcmF3LnRyaW0oKS5yZXBsYWNlKC9eQC8sICcnKS50b0xvd2VyQ2FzZSgpO1xyXG4gIHJldHVybiBjbGVhbmVkLmxlbmd0aCA+IDAgPyBjbGVhbmVkIDogbnVsbDtcclxufVxyXG5cclxuY29uc3QgU1RBVFVTX0hPU1RTID0gbmV3IFNldChbJ3guY29tJywgJ3R3aXR0ZXIuY29tJywgJ21vYmlsZS50d2l0dGVyLmNvbSddKTtcclxuXHJcbmZ1bmN0aW9uIHBhcnNlVHdlZXRVcmwoaHJlZjogc3RyaW5nIHwgbnVsbCk6IHsgaGFuZGxlOiBzdHJpbmc7IGlkOiBzdHJpbmcgfSB8IG51bGwge1xyXG4gIGlmICghaHJlZikgcmV0dXJuIG51bGw7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHUgPSBuZXcgVVJMKGhyZWYsIGxvY2F0aW9uLmhyZWYpO1xyXG4gICAgaWYgKCFTVEFUVVNfSE9TVFMuaGFzKHUuaG9zdG5hbWUudG9Mb3dlckNhc2UoKSkpIHJldHVybiBudWxsO1xyXG4gICAgY29uc3QgcGFydHMgPSB1LnBhdGhuYW1lLnNwbGl0KCcvJykuZmlsdGVyKEJvb2xlYW4pO1xyXG4gICAgY29uc3Qgc3RhdHVzSWR4ID0gcGFydHMuaW5kZXhPZignc3RhdHVzJyk7XHJcbiAgICBpZiAoc3RhdHVzSWR4IDw9IDApIHJldHVybiBudWxsO1xyXG4gICAgY29uc3QgaGFuZGxlID0gbm9ybWFsaXplSGFuZGxlKHBhcnRzW3N0YXR1c0lkeCAtIDFdID8/IG51bGwpO1xyXG4gICAgY29uc3QgaWQgPSBwYXJ0c1tzdGF0dXNJZHggKyAxXSA/PyBudWxsO1xyXG4gICAgaWYgKCFoYW5kbGUgfHwgIWlkIHx8ICEvXlxcZCskLy50ZXN0KGlkKSkgcmV0dXJuIG51bGw7XHJcbiAgICByZXR1cm4geyBoYW5kbGUsIGlkIH07XHJcbiAgfSBjYXRjaCB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhcnNlSGFuZGxlVXJsKGhyZWY6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAoIWhyZWYpIHJldHVybiBudWxsO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB1ID0gbmV3IFVSTChocmVmLCBsb2NhdGlvbi5ocmVmKTtcclxuICAgIGlmICghU1RBVFVTX0hPU1RTLmhhcyh1Lmhvc3RuYW1lLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IGZpcnN0ID0gdS5wYXRobmFtZS5zcGxpdCgnLycpLmZpbHRlcihCb29sZWFuKVswXTtcclxuICAgIGlmICghZmlyc3QgfHwgZmlyc3QgPT09ICdpJyB8fCBmaXJzdCA9PT0gJ2ludGVudCcgfHwgZmlyc3QgPT09ICdzZWFyY2gnKSByZXR1cm4gbnVsbDtcclxuICAgIHJldHVybiBub3JtYWxpemVIYW5kbGUoZmlyc3QpO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBpc1Zpc2libGUoZWw6IEVsZW1lbnQpOiBib29sZWFuIHtcclxuICBjb25zdCByZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgaWYgKHJlY3Qud2lkdGggPT09IDAgfHwgcmVjdC5oZWlnaHQgPT09IDApIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBzdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsKTtcclxuICByZXR1cm4gc3R5bGUudmlzaWJpbGl0eSAhPT0gJ2hpZGRlbicgJiYgc3R5bGUuZGlzcGxheSAhPT0gJ25vbmUnO1xyXG59XHJcblxyXG5mdW5jdGlvbiBuZWFyZXN0VHdlZXRDb250YWluZXIoZWw6IEVsZW1lbnQpOiBFbGVtZW50IHwgbnVsbCB7XHJcbiAgcmV0dXJuIGVsLmNsb3Nlc3QoJ2FydGljbGUnKSA/PyBlbC5jbG9zZXN0KCdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0nKTtcclxufVxyXG5cclxuZnVuY3Rpb24gaXNSZXBseVRvQ29yZShjb250YWluZXI6IEVsZW1lbnQpOiBib29sZWFuIHtcclxuICBjb25zdCB0ZXh0ID0gKGNvbnRhaW5lci50ZXh0Q29udGVudCB8fCAnJykudG9Mb3dlckNhc2UoKTtcclxuICBpZiAoIXRleHQuaW5jbHVkZXMoJ3JlcGx5aW5nIHRvJykpIHJldHVybiBmYWxzZTtcclxuICBmb3IgKGNvbnN0IGxpbmsgb2YgQXJyYXkuZnJvbShjb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnYVtocmVmXScpKSkge1xyXG4gICAgY29uc3QgaGFuZGxlID0gcGFyc2VIYW5kbGVVcmwobGluay5nZXRBdHRyaWJ1dGUoJ2hyZWYnKSk7XHJcbiAgICBpZiAoaGFuZGxlICYmIHVuZm9sZENvcmVIYW5kbGVzLmhhcyhoYW5kbGUpKSByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbiAgcmV0dXJuIGZhbHNlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBpc0NvcmVSZWxldmFudChjb250YWluZXI6IEVsZW1lbnQpOiBib29sZWFuIHtcclxuICBmb3IgKGNvbnN0IGxpbmsgb2YgQXJyYXkuZnJvbShjb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnYVtocmVmXScpKSkge1xyXG4gICAgY29uc3QgdHdlZXQgPSBwYXJzZVR3ZWV0VXJsKGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJykpO1xyXG4gICAgaWYgKCF0d2VldCkgY29udGludWU7XHJcbiAgICBpZiAodW5mb2xkQ29yZUhhbmRsZXMuaGFzKHR3ZWV0LmhhbmRsZSkpIHJldHVybiB0cnVlO1xyXG4gICAgaWYgKHVuZm9sZFJlbGV2YW50VHdlZXRJZHMuaGFzKHR3ZWV0LmlkKSkgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG4gIHJldHVybiBpc1JlcGx5VG9Db3JlKGNvbnRhaW5lcik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNjYW5BbmRVbmZvbGRTaG93TW9yZSgpOiB2b2lkIHtcclxuICB1bmZvbGRTY2FuVGltZXIgPSBudWxsO1xyXG4gIGlmICghdW5mb2xkRW5hYmxlZCB8fCB1bmZvbGRDb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm47XHJcbiAgY29uc3Qgc2VsZWN0b3JzID0gW1xyXG4gICAgJ1tkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxyXG4gICAgJ2J1dHRvbltkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxyXG4gICAgJ2FydGljbGUgW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcclxuICAgICdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0gW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcclxuICBdO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PEVsZW1lbnQ+KCk7XHJcbiAgbGV0IGNsaWNrZWQgPSAwO1xyXG4gIGZvciAoY29uc3Qgc2VsIG9mIHNlbGVjdG9ycykge1xyXG4gICAgZm9yIChjb25zdCBlbCBvZiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsKSkpIHtcclxuICAgICAgaWYgKHNlZW4uaGFzKGVsKSB8fCB1bmZvbGRlZENvbnRyb2xzLmhhcyhlbCkpIGNvbnRpbnVlO1xyXG4gICAgICBzZWVuLmFkZChlbCk7XHJcbiAgICAgIGlmICgoZWwudGV4dENvbnRlbnQgfHwgJycpLnRyaW0oKS50b0xvd2VyQ2FzZSgpICE9PSAnc2hvdyBtb3JlJykgY29udGludWU7XHJcbiAgICAgIGlmICghaXNWaXNpYmxlKGVsKSkgY29udGludWU7XHJcbiAgICAgIGNvbnN0IGNvbnRhaW5lciA9IG5lYXJlc3RUd2VldENvbnRhaW5lcihlbCk7XHJcbiAgICAgIGlmICghY29udGFpbmVyIHx8ICFpc0NvcmVSZWxldmFudChjb250YWluZXIpKSBjb250aW51ZTtcclxuICAgICAgdW5mb2xkZWRDb250cm9scy5hZGQoZWwpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIChlbCBhcyBIVE1MRWxlbWVudCkuY2xpY2soKTtcclxuICAgICAgICBjbGlja2VkICs9IDE7XHJcbiAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgIC8vIElnbm9yZSBzdGFsZSBvciBzeW50aGV0aWMgY29udHJvbHMuXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgaWYgKGNsaWNrZWQgPiAwKSB7XHJcbiAgICBicm93c2VyLnJ1bnRpbWVcclxuICAgICAgLnNlbmRNZXNzYWdlKHsgdHlwZTogJ3Nob3ctbW9yZS11bmZvbGRlZCcsIGNvdW50OiBjbGlja2VkIH0pXHJcbiAgICAgIC5jYXRjaCgoKSA9PiB7fSk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBzY2hlZHVsZVVuZm9sZFNjYW4oZGVsYXkgPSBVTkZPTERfU0NBTl9ERUJPVU5DRV9NUyk6IHZvaWQge1xyXG4gIGlmICh1bmZvbGRTY2FuVGltZXIgIT09IG51bGwpIHJldHVybjtcclxuICB1bmZvbGRTY2FuVGltZXIgPSBzZXRUaW1lb3V0KHNjYW5BbmRVbmZvbGRTaG93TW9yZSwgZGVsYXkpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoVW5mb2xkVGFyZ2V0cygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xyXG4gICAgICB0eXBlOiAnZ2V0LXVuZm9sZC10YXJnZXRzJyxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgcmF3ID1cclxuICAgICAgcmVzcG9uc2UgJiYgdHlwZW9mIHJlc3BvbnNlID09PSAnb2JqZWN0JyA/IChyZXNwb25zZSBhcyBVbmZvbGRUYXJnZXRzUmVzcG9uc2UpIDoge307XHJcbiAgICB1bmZvbGRFbmFibGVkID0gcmF3LmVuYWJsZWQgIT09IGZhbHNlO1xyXG4gICAgdW5mb2xkQ29yZUhhbmRsZXMgPSBuZXcgU2V0KFxyXG4gICAgICAocmF3LmNvcmVIYW5kbGVzID8/IFtdKS5tYXAoKGgpID0+IGgudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9eQC8sICcnKSlcclxuICAgICk7XHJcbiAgICB1bmZvbGRSZWxldmFudFR3ZWV0SWRzID0gbmV3IFNldChyYXcucmVsZXZhbnRUd2VldElkcyA/PyBbXSk7XHJcbiAgICBzY2hlZHVsZVVuZm9sZFNjYW4oMCk7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICB1bmZvbGRFbmFibGVkID0gZmFsc2U7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBpbnN0YWxsVW5mb2xkT2JzZXJ2ZXIoKTogdm9pZCB7XHJcbiAgY29uc3Qgcm9vdCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCB8fCBkb2N1bWVudC5ib2R5O1xyXG4gIGlmICghcm9vdCkge1xyXG4gICAgc2V0VGltZW91dChpbnN0YWxsVW5mb2xkT2JzZXJ2ZXIsIDEwMCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4gc2NoZWR1bGVVbmZvbGRTY2FuKCkpO1xyXG4gIG9ic2VydmVyLm9ic2VydmUocm9vdCwgeyBjaGlsZExpc3Q6IHRydWUsIHN1YnRyZWU6IHRydWUgfSk7XHJcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsICgpID0+IHNjaGVkdWxlVW5mb2xkU2NhbigpLCB7IHBhc3NpdmU6IHRydWUgfSk7XHJcbiAgdm9pZCByZWZyZXNoVW5mb2xkVGFyZ2V0cygpO1xyXG4gIHNldEludGVydmFsKCgpID0+IHtcclxuICAgIHZvaWQgcmVmcmVzaFVuZm9sZFRhcmdldHMoKTtcclxuICB9LCBVTkZPTERfU1lOQ19NUyk7XHJcbn1cclxuXHJcbmluc3RhbGxVbmZvbGRPYnNlcnZlcigpO1xyXG5cclxud2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCAoZXZlbnQ6IE1lc3NhZ2VFdmVudCkgPT4ge1xyXG4gIGlmIChldmVudC5zb3VyY2UgIT09IHdpbmRvdykgcmV0dXJuO1xyXG4gIGNvbnN0IGRhdGEgPSBldmVudC5kYXRhIGFzIHVua25vd247XHJcbiAgaWYgKCFkYXRhIHx8IHR5cGVvZiBkYXRhICE9PSAnb2JqZWN0JykgcmV0dXJuO1xyXG4gIGNvbnN0IGQgPSBkYXRhIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG5cclxuICBpZiAoZC5zb3VyY2UgPT09IFJFQURZKSB7XHJcbiAgICBicm93c2VyLnJ1bnRpbWVcclxuICAgICAgLnNlbmRNZXNzYWdlKHtcclxuICAgICAgICB0eXBlOiAncGFnZS1ob29rLWFjdGl2ZScsXHJcbiAgICAgICAgdXJsOiB0eXBlb2YgZC51cmwgPT09ICdzdHJpbmcnID8gZC51cmwgOiBsb2NhdGlvbi5ocmVmLFxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKCkgPT4ge30pO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgaWYgKGQuc291cmNlICE9PSBUQVJHRVQpIHJldHVybjtcclxuICBjb25zdCBlbmRwb2ludCA9IHR5cGVvZiBkLmVuZHBvaW50ID09PSAnc3RyaW5nJyA/IGQuZW5kcG9pbnQgOiBudWxsO1xyXG4gIGNvbnN0IHVybCA9IHR5cGVvZiBkLnVybCA9PT0gJ3N0cmluZycgPyBkLnVybCA6IG51bGw7XHJcbiAgY29uc3QgcGFnZVVybCA9IHR5cGVvZiBkLnBhZ2VfdXJsID09PSAnc3RyaW5nJyA/IGQucGFnZV91cmwgOiBsb2NhdGlvbi5ocmVmO1xyXG4gIGNvbnN0IHJlc3BvbnNlID0gZC5yZXNwb25zZTtcclxuICBpZiAoIWVuZHBvaW50IHx8ICF1cmwgfHwgcmVzcG9uc2UgPT09IHVuZGVmaW5lZCkgcmV0dXJuO1xyXG4gIGJyb3dzZXIucnVudGltZVxyXG4gICAgLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2dyYXBocWwtY2FwdHVyZScsIGVuZHBvaW50LCB1cmwsIHBhZ2VVcmwsIHJlc3BvbnNlIH0pXHJcbiAgICAuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gc2VuZE1lc3NhZ2UgZmFpbGVkJywgZXJyKTtcclxuICAgIH0pO1xyXG59KTtcclxuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBc0JBLE1BQU0sU0FBUztBQUNmLE1BQU0sUUFBUTtBQUNkLE1BQU0saUJBQWlCO0FBQ3ZCLE1BQU0sMEJBQTBCO0FBUWhDLE1BQUksZ0JBQWdCO0FBQ3BCLE1BQUksb0JBQW9CLG9CQUFJLElBQVk7QUFDeEMsTUFBSSx5QkFBeUIsb0JBQUksSUFBWTtBQUM3QyxNQUFJLGtCQUF3RDtBQUM1RCxNQUFNLG1CQUFtQixvQkFBSSxRQUFpQjtBQUU5QyxPQUFLLFFBQVEsUUFDVixZQUFZLEVBQUUsTUFBTSxpQkFBaUIsS0FBSyxTQUFTLEtBQUssQ0FBQyxFQUN6RCxNQUFNLENBQUMsUUFBaUI7QUFDdkIsWUFBUSxLQUFLLDJDQUEyQyxHQUFHO0FBQUEsRUFDN0QsQ0FBQztBQUVILFdBQVMsaUJBQXVCO0FBQzlCLFFBQUk7QUFDRixZQUFNLE1BQU0sUUFBUSxRQUFRLE9BQU8sY0FBYztBQUNqRCxZQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7QUFDOUMsYUFBTyxNQUFNO0FBQ2IsYUFBTyxRQUFRO0FBQ2YsYUFBTyxRQUFRLGFBQWE7QUFDNUIsT0FBQyxTQUFTLFFBQVEsU0FBUyxpQkFBaUIsWUFBWSxNQUFNO0FBQzlELGFBQU8sU0FBUyxNQUFNLE9BQU8sT0FBTztBQUNwQyxhQUFPLFVBQVUsTUFBTTtBQUlyQixnQkFBUSxRQUNMLFlBQVk7QUFBQSxVQUNYLE1BQU07QUFBQSxVQUNOLE9BQU87QUFBQSxVQUNQLEtBQUs7QUFBQSxVQUNMLEtBQUssU0FBUztBQUFBLFFBQ2hCLENBQUMsRUFDQSxNQUFNLE1BQU07QUFBQSxRQUFDLENBQUM7QUFBQSxNQUNuQjtBQUFBLElBQ0YsU0FBUyxLQUFLO0FBQ1osY0FBUSxLQUFLLGtEQUFrRCxHQUFHO0FBQUEsSUFDcEU7QUFBQSxFQUNGO0FBRUEsaUJBQWU7QUFFZixXQUFTLGdCQUFnQixLQUFtQztBQUMxRCxRQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLFVBQU0sVUFBVSxJQUFJLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxFQUFFLFlBQVk7QUFDekQsV0FBTyxRQUFRLFNBQVMsSUFBSSxVQUFVO0FBQUEsRUFDeEM7QUFFQSxNQUFNLGVBQWUsb0JBQUksSUFBSSxDQUFDLFNBQVMsZUFBZSxvQkFBb0IsQ0FBQztBQUUzRSxXQUFTLGNBQWMsTUFBNEQ7QUFDakYsUUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixRQUFJO0FBQ0YsWUFBTSxJQUFJLElBQUksSUFBSSxNQUFNLFNBQVMsSUFBSTtBQUNyQyxVQUFJLENBQUMsYUFBYSxJQUFJLEVBQUUsU0FBUyxZQUFZLENBQUMsRUFBRyxRQUFPO0FBQ3hELFlBQU0sUUFBUSxFQUFFLFNBQVMsTUFBTSxHQUFHLEVBQUUsT0FBTyxPQUFPO0FBQ2xELFlBQU0sWUFBWSxNQUFNLFFBQVEsUUFBUTtBQUN4QyxVQUFJLGFBQWEsRUFBRyxRQUFPO0FBQzNCLFlBQU0sU0FBUyxnQkFBZ0IsTUFBTSxZQUFZLENBQUMsS0FBSyxJQUFJO0FBQzNELFlBQU0sS0FBSyxNQUFNLFlBQVksQ0FBQyxLQUFLO0FBQ25DLFVBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxFQUFFLEVBQUcsUUFBTztBQUNoRCxhQUFPLEVBQUUsUUFBUSxHQUFHO0FBQUEsSUFDdEIsUUFBUTtBQUNOLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFdBQVMsZUFBZSxNQUFvQztBQUMxRCxRQUFJLENBQUMsS0FBTSxRQUFPO0FBQ2xCLFFBQUk7QUFDRixZQUFNLElBQUksSUFBSSxJQUFJLE1BQU0sU0FBUyxJQUFJO0FBQ3JDLFVBQUksQ0FBQyxhQUFhLElBQUksRUFBRSxTQUFTLFlBQVksQ0FBQyxFQUFHLFFBQU87QUFDeEQsWUFBTSxRQUFRLEVBQUUsU0FBUyxNQUFNLEdBQUcsRUFBRSxPQUFPLE9BQU8sRUFBRSxDQUFDO0FBQ3JELFVBQUksQ0FBQyxTQUFTLFVBQVUsT0FBTyxVQUFVLFlBQVksVUFBVSxTQUFVLFFBQU87QUFDaEYsYUFBTyxnQkFBZ0IsS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLFVBQVUsSUFBc0I7QUFDdkMsVUFBTSxPQUFPLEdBQUcsc0JBQXNCO0FBQ3RDLFFBQUksS0FBSyxVQUFVLEtBQUssS0FBSyxXQUFXLEVBQUcsUUFBTztBQUNsRCxVQUFNLFFBQVEsT0FBTyxpQkFBaUIsRUFBRTtBQUN4QyxXQUFPLE1BQU0sZUFBZSxZQUFZLE1BQU0sWUFBWTtBQUFBLEVBQzVEO0FBRUEsV0FBUyxzQkFBc0IsSUFBNkI7QUFDMUQsV0FBTyxHQUFHLFFBQVEsU0FBUyxLQUFLLEdBQUcsUUFBUSxpQ0FBaUM7QUFBQSxFQUM5RTtBQUVBLFdBQVMsY0FBYyxXQUE2QjtBQUNsRCxVQUFNLFFBQVEsVUFBVSxlQUFlLElBQUksWUFBWTtBQUN2RCxRQUFJLENBQUMsS0FBSyxTQUFTLGFBQWEsRUFBRyxRQUFPO0FBQzFDLGVBQVcsUUFBUSxNQUFNLEtBQUssVUFBVSxpQkFBaUIsU0FBUyxDQUFDLEdBQUc7QUFDcEUsWUFBTSxTQUFTLGVBQWUsS0FBSyxhQUFhLE1BQU0sQ0FBQztBQUN2RCxVQUFJLFVBQVUsa0JBQWtCLElBQUksTUFBTSxFQUFHLFFBQU87QUFBQSxJQUN0RDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsV0FBUyxlQUFlLFdBQTZCO0FBQ25ELGVBQVcsUUFBUSxNQUFNLEtBQUssVUFBVSxpQkFBaUIsU0FBUyxDQUFDLEdBQUc7QUFDcEUsWUFBTSxRQUFRLGNBQWMsS0FBSyxhQUFhLE1BQU0sQ0FBQztBQUNyRCxVQUFJLENBQUMsTUFBTztBQUNaLFVBQUksa0JBQWtCLElBQUksTUFBTSxNQUFNLEVBQUcsUUFBTztBQUNoRCxVQUFJLHVCQUF1QixJQUFJLE1BQU0sRUFBRSxFQUFHLFFBQU87QUFBQSxJQUNuRDtBQUNBLFdBQU8sY0FBYyxTQUFTO0FBQUEsRUFDaEM7QUFFQSxXQUFTLHdCQUE4QjtBQUNyQyxzQkFBa0I7QUFDbEIsUUFBSSxDQUFDLGlCQUFpQixrQkFBa0IsU0FBUyxFQUFHO0FBQ3BELFVBQU0sWUFBWTtBQUFBLE1BQ2hCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sT0FBTyxvQkFBSSxJQUFhO0FBQzlCLFFBQUksVUFBVTtBQUNkLGVBQVcsT0FBTyxXQUFXO0FBQzNCLGlCQUFXLE1BQU0sTUFBTSxLQUFLLFNBQVMsaUJBQWlCLEdBQUcsQ0FBQyxHQUFHO0FBQzNELFlBQUksS0FBSyxJQUFJLEVBQUUsS0FBSyxpQkFBaUIsSUFBSSxFQUFFLEVBQUc7QUFDOUMsYUFBSyxJQUFJLEVBQUU7QUFDWCxhQUFLLEdBQUcsZUFBZSxJQUFJLEtBQUssRUFBRSxZQUFZLE1BQU0sWUFBYTtBQUNqRSxZQUFJLENBQUMsVUFBVSxFQUFFLEVBQUc7QUFDcEIsY0FBTSxZQUFZLHNCQUFzQixFQUFFO0FBQzFDLFlBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxTQUFTLEVBQUc7QUFDOUMseUJBQWlCLElBQUksRUFBRTtBQUN2QixZQUFJO0FBQ0YsVUFBQyxHQUFtQixNQUFNO0FBQzFCLHFCQUFXO0FBQUEsUUFDYixRQUFRO0FBQUEsUUFFUjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxVQUFVLEdBQUc7QUFDZixjQUFRLFFBQ0wsWUFBWSxFQUFFLE1BQU0sc0JBQXNCLE9BQU8sUUFBUSxDQUFDLEVBQzFELE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLFdBQVMsbUJBQW1CLFFBQVEseUJBQStCO0FBQ2pFLFFBQUksb0JBQW9CLEtBQU07QUFDOUIsc0JBQWtCLFdBQVcsdUJBQXVCLEtBQUs7QUFBQSxFQUMzRDtBQUVBLGlCQUFlLHVCQUFzQztBQUNuRCxRQUFJO0FBQ0YsWUFBTSxXQUFXLE1BQU0sUUFBUSxRQUFRLFlBQVk7QUFBQSxRQUNqRCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0QsWUFBTSxNQUNKLFlBQVksT0FBTyxhQUFhLFdBQVksV0FBcUMsQ0FBQztBQUNwRixzQkFBZ0IsSUFBSSxZQUFZO0FBQ2hDLDBCQUFvQixJQUFJO0FBQUEsU0FDckIsSUFBSSxlQUFlLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksRUFBRSxRQUFRLE1BQU0sRUFBRSxDQUFDO0FBQUEsTUFDdEU7QUFDQSwrQkFBeUIsSUFBSSxJQUFJLElBQUksb0JBQW9CLENBQUMsQ0FBQztBQUMzRCx5QkFBbUIsQ0FBQztBQUFBLElBQ3RCLFFBQVE7QUFDTixzQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLHdCQUE4QjtBQUNyQyxVQUFNLE9BQU8sU0FBUyxtQkFBbUIsU0FBUztBQUNsRCxRQUFJLENBQUMsTUFBTTtBQUNULGlCQUFXLHVCQUF1QixHQUFHO0FBQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sV0FBVyxJQUFJLGlCQUFpQixNQUFNLG1CQUFtQixDQUFDO0FBQ2hFLGFBQVMsUUFBUSxNQUFNLEVBQUUsV0FBVyxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBQ3pELFdBQU8saUJBQWlCLFVBQVUsTUFBTSxtQkFBbUIsR0FBRyxFQUFFLFNBQVMsS0FBSyxDQUFDO0FBQy9FLFNBQUsscUJBQXFCO0FBQzFCLGdCQUFZLE1BQU07QUFDaEIsV0FBSyxxQkFBcUI7QUFBQSxJQUM1QixHQUFHLGNBQWM7QUFBQSxFQUNuQjtBQUVBLHdCQUFzQjtBQUV0QixTQUFPLGlCQUFpQixXQUFXLENBQUMsVUFBd0I7QUFDMUQsUUFBSSxNQUFNLFdBQVcsT0FBUTtBQUM3QixVQUFNLE9BQU8sTUFBTTtBQUNuQixRQUFJLENBQUMsUUFBUSxPQUFPLFNBQVMsU0FBVTtBQUN2QyxVQUFNLElBQUk7QUFFVixRQUFJLEVBQUUsV0FBVyxPQUFPO0FBQ3RCLGNBQVEsUUFDTCxZQUFZO0FBQUEsUUFDWCxNQUFNO0FBQUEsUUFDTixLQUFLLE9BQU8sRUFBRSxRQUFRLFdBQVcsRUFBRSxNQUFNLFNBQVM7QUFBQSxNQUNwRCxDQUFDLEVBQ0EsTUFBTSxNQUFNO0FBQUEsTUFBQyxDQUFDO0FBQ2pCO0FBQUEsSUFDRjtBQUVBLFFBQUksRUFBRSxXQUFXLE9BQVE7QUFDekIsVUFBTSxXQUFXLE9BQU8sRUFBRSxhQUFhLFdBQVcsRUFBRSxXQUFXO0FBQy9ELFVBQU0sTUFBTSxPQUFPLEVBQUUsUUFBUSxXQUFXLEVBQUUsTUFBTTtBQUNoRCxVQUFNLFVBQVUsT0FBTyxFQUFFLGFBQWEsV0FBVyxFQUFFLFdBQVcsU0FBUztBQUN2RSxVQUFNLFdBQVcsRUFBRTtBQUNuQixRQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sYUFBYSxPQUFXO0FBQ2pELFlBQVEsUUFDTCxZQUFZLEVBQUUsTUFBTSxtQkFBbUIsVUFBVSxLQUFLLFNBQVMsU0FBUyxDQUFDLEVBQ3pFLE1BQU0sQ0FBQyxRQUFRO0FBQ2QsY0FBUSxLQUFLLG9DQUFvQyxHQUFHO0FBQUEsSUFDdEQsQ0FBQztBQUFBLEVBQ0wsQ0FBQzsiLAogICJuYW1lcyI6IFtdCn0K
