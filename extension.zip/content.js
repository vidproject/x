"use strict";
(() => {
  // extension/src/content.ts
  var TARGET = "IMM_ARCHIVE_CAPTURE";
  var READY = "IMM_ARCHIVE_HOOK_READY";
  var UNFOLD_SYNC_MS = 2e3;
  var UNFOLD_SCAN_DEBOUNCE_MS = 250;
  var unfoldEnabled = false;
  var unfoldCoreHandles = /* @__PURE__ */ new Set();
  var unfoldRelevantTweetIds = /* @__PURE__ */ new Set();
  var unfoldScanTimer = null;
  var unfoldedControls = /* @__PURE__ */ new WeakSet();
  void browser.runtime.sendMessage({ type: "content-alive", url: location.href }).catch((err) => {
    console.warn("[imm-archive] content-alive ping failed", err);
  });
  function fallbackInject() {
    try {
      const src = browser.runtime.getURL("page-hook.js");
      const script = document.createElement("script");
      script.src = src;
      script.async = false;
      script.dataset.immArchive = "1";
      (document.head || document.documentElement).appendChild(script);
      script.onload = () => script.remove();
      script.onerror = () => {
        browser.runtime.sendMessage({
          type: "log-content-event",
          level: "warn",
          msg: "inline page-hook injection blocked (CSP); relying on MAIN-world content script",
          url: location.href
        }).catch(() => {
        });
      };
    } catch (err) {
      console.warn("[imm-archive] inline page-hook injection threw", err);
    }
  }
  fallbackInject();
  function normalizeHandle(raw) {
    if (!raw) return null;
    const cleaned = raw.trim().replace(/^@/, "").toLowerCase();
    return cleaned.length > 0 ? cleaned : null;
  }
  var STATUS_HOSTS = /* @__PURE__ */ new Set(["x.com", "twitter.com", "mobile.twitter.com"]);
  function parseTweetUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const parts = u.pathname.split("/").filter(Boolean);
      const statusIdx = parts.indexOf("status");
      if (statusIdx <= 0) return null;
      const handle = normalizeHandle(parts[statusIdx - 1] ?? null);
      const id = parts[statusIdx + 1] ?? null;
      if (!handle || !id || !/^\d+$/.test(id)) return null;
      return { handle, id };
    } catch {
      return null;
    }
  }
  function parseHandleUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const first = u.pathname.split("/").filter(Boolean)[0];
      if (!first || first === "i" || first === "intent" || first === "search") return null;
      return normalizeHandle(first);
    } catch {
      return null;
    }
  }
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none";
  }
  function nearestTweetContainer(el) {
    return el.closest("article") ?? el.closest('div[data-testid="cellInnerDiv"]');
  }
  function isReplyToCore(container) {
    const text = (container.textContent || "").toLowerCase();
    if (!text.includes("replying to")) return false;
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const handle = parseHandleUrl(link.getAttribute("href"));
      if (handle && unfoldCoreHandles.has(handle)) return true;
    }
    return false;
  }
  function isCoreRelevant(container) {
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const tweet = parseTweetUrl(link.getAttribute("href"));
      if (!tweet) continue;
      if (unfoldCoreHandles.has(tweet.handle)) return true;
      if (unfoldRelevantTweetIds.has(tweet.id)) return true;
    }
    return isReplyToCore(container);
  }
  function scanAndUnfoldShowMore() {
    unfoldScanTimer = null;
    if (!unfoldEnabled || unfoldCoreHandles.size === 0) return;
    const selectors = [
      '[data-testid="tweet-text-show-more-link"]',
      'button[data-testid="tweet-text-show-more-link"]',
      'article [role="button"][tabindex="0"]',
      'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
    ];
    const seen = /* @__PURE__ */ new Set();
    let clicked = 0;
    for (const sel of selectors) {
      for (const el of Array.from(document.querySelectorAll(sel))) {
        if (seen.has(el) || unfoldedControls.has(el)) continue;
        seen.add(el);
        if ((el.textContent || "").trim().toLowerCase() !== "show more") continue;
        if (!isVisible(el)) continue;
        const container = nearestTweetContainer(el);
        if (!container || !isCoreRelevant(container)) continue;
        unfoldedControls.add(el);
        try {
          el.click();
          clicked += 1;
        } catch {
        }
      }
    }
    if (clicked > 0) {
      browser.runtime.sendMessage({ type: "show-more-unfolded", count: clicked }).catch(() => {
      });
    }
  }
  function scheduleUnfoldScan(delay = UNFOLD_SCAN_DEBOUNCE_MS) {
    if (unfoldScanTimer !== null) return;
    unfoldScanTimer = setTimeout(scanAndUnfoldShowMore, delay);
  }
  async function refreshUnfoldTargets() {
    try {
      const response = await browser.runtime.sendMessage({
        type: "get-unfold-targets"
      });
      const raw = response && typeof response === "object" ? response : {};
      unfoldEnabled = raw.enabled !== false;
      unfoldCoreHandles = new Set(
        (raw.coreHandles ?? []).map((h) => h.toLowerCase().replace(/^@/, ""))
      );
      unfoldRelevantTweetIds = new Set(raw.relevantTweetIds ?? []);
      scheduleUnfoldScan(0);
    } catch {
      unfoldEnabled = false;
    }
  }
  function installUnfoldObserver() {
    const root = document.documentElement || document.body;
    if (!root) {
      setTimeout(installUnfoldObserver, 100);
      return;
    }
    const observer = new MutationObserver(() => scheduleUnfoldScan());
    observer.observe(root, { childList: true, subtree: true });
    window.addEventListener("scroll", () => scheduleUnfoldScan(), { passive: true });
    void refreshUnfoldTargets();
    setInterval(() => {
      void refreshUnfoldTargets();
    }, UNFOLD_SYNC_MS);
  }
  installUnfoldObserver();
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== "object") return;
    const d = data;
    if (d.source === READY) {
      browser.runtime.sendMessage({
        type: "page-hook-active",
        url: typeof d.url === "string" ? d.url : location.href
      }).catch(() => {
      });
      return;
    }
    if (d.source !== TARGET) return;
    const endpoint = typeof d.endpoint === "string" ? d.endpoint : null;
    const url = typeof d.url === "string" ? d.url : null;
    const pageUrl = typeof d.page_url === "string" ? d.page_url : location.href;
    const response = d.response;
    if (!endpoint || !url || response === void 0) return;
    browser.runtime.sendMessage({ type: "graphql-capture", endpoint, url, pageUrl, response }).catch((err) => {
      console.warn("[imm-archive] sendMessage failed", err);
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbnRlbnQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKlxyXG4gKiBjb250ZW50LnRzIFx1MjAxNCBjb250ZW50LXNjcmlwdCBjb250ZXh0IChpc29sYXRlZCB3b3JsZCkuXHJcbiAqXHJcbiAqIFRoZSBhY3R1YWwgcGFnZS1ob29rICh3aGljaCBwYXRjaGVzIGBmZXRjaGAgLyBgWEhSYCkgaXMgZGVjbGFyZWQgYXMgYVxyXG4gKiBzZXBhcmF0ZSBjb250ZW50IHNjcmlwdCB3aXRoIGB3b3JsZDogXCJNQUlOXCJgIGluIHRoZSBtYW5pZmVzdCwgc28gaXQgcnVuc1xyXG4gKiBpbiB0aGUgcGFnZSB3b3JsZCBkaXJlY3RseSB3aXRob3V0IHVzIGhhdmluZyB0byBpbmplY3QgYSA8c2NyaXB0PiB0YWcgXHUyMDE0XHJcbiAqIHdoaWNoIFgncyBub25jZS1iYXNlZCBDU1Agd291bGQgYmxvY2suXHJcbiAqXHJcbiAqIFRoaXMgZmlsZSBkb2VzIHRocmVlIHRoaW5nczpcclxuICpcclxuICogICAxLiBQaW5ncyB0aGUgYmFja2dyb3VuZCBvbiBsb2FkIHNvIHRoZSBhY3Rpdml0eSB0YWlsIGNvbmZpcm1zIHRoZVxyXG4gKiAgICAgIGNvbnRlbnQgc2NyaXB0IHJlYWNoZWQgdGhlIFggcGFnZSAodXNlZnVsIHdoZW4gZGlhZ25vc2luZyBhIHNpbGVudFxyXG4gKiAgICAgIFwiY2FwdHVyZS1ub3cgZG9lcyBub3RoaW5nXCIgZmFpbHVyZSkuXHJcbiAqICAgMi4gQXMgYSBkZWZlbnNpdmUgZmFsbGJhY2ssIGFsc28gdHJpZXMgdG8gaW5qZWN0IGBwYWdlLWhvb2suanNgIHZpYSBhXHJcbiAqICAgICAgc2NyaXB0IHRhZy4gSGFybWxlc3Mgb24gbW9kZXJuIEZpcmVmb3ggKHRoZSBwYWdlLWhvb2sncyBUQUcgZ3VhcmRcclxuICogICAgICBwcmV2ZW50cyBkb3VibGUtaW5pdCk7IGNvdmVycyB0aGUgcmFyZSBjYXNlIHdoZXJlIHRoZSBNQUlOLXdvcmxkXHJcbiAqICAgICAgY29udGVudCBzY3JpcHQgZW50cnkgaXNuJ3QgaG9ub3JlZC5cclxuICogICAzLiBCcmlkZ2VzIGB3aW5kb3cucG9zdE1lc3NhZ2VgIGZyb20gdGhlIHBhZ2UgaG9vayB0byB0aGUgYmFja2dyb3VuZDpcclxuICogICAgICBib3RoIHRoZSBgKl9SRUFEWWAgYm9vdCBwaW5nIGFuZCB0aGUgYElNTV9BUkNISVZFX0NBUFRVUkVgIHBheWxvYWRcclxuICogICAgICBldmVudHMuXHJcbiAqL1xyXG5cclxuY29uc3QgVEFSR0VUID0gJ0lNTV9BUkNISVZFX0NBUFRVUkUnO1xyXG5jb25zdCBSRUFEWSA9ICdJTU1fQVJDSElWRV9IT09LX1JFQURZJztcclxuY29uc3QgVU5GT0xEX1NZTkNfTVMgPSAyXzAwMDtcclxuY29uc3QgVU5GT0xEX1NDQU5fREVCT1VOQ0VfTVMgPSAyNTA7XHJcblxyXG5pbnRlcmZhY2UgVW5mb2xkVGFyZ2V0c1Jlc3BvbnNlIHtcclxuICBlbmFibGVkPzogYm9vbGVhbjtcclxuICBjb3JlSGFuZGxlcz86IHN0cmluZ1tdO1xyXG4gIHJlbGV2YW50VHdlZXRJZHM/OiBzdHJpbmdbXTtcclxufVxyXG5cclxubGV0IHVuZm9sZEVuYWJsZWQgPSBmYWxzZTtcclxubGV0IHVuZm9sZENvcmVIYW5kbGVzID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbmxldCB1bmZvbGRSZWxldmFudFR3ZWV0SWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbmxldCB1bmZvbGRTY2FuVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbCA9IG51bGw7XHJcbmNvbnN0IHVuZm9sZGVkQ29udHJvbHMgPSBuZXcgV2Vha1NldDxFbGVtZW50PigpO1xyXG5cclxudm9pZCBicm93c2VyLnJ1bnRpbWVcclxuICAuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnY29udGVudC1hbGl2ZScsIHVybDogbG9jYXRpb24uaHJlZiB9KVxyXG4gIC5jYXRjaCgoZXJyOiB1bmtub3duKSA9PiB7XHJcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gY29udGVudC1hbGl2ZSBwaW5nIGZhaWxlZCcsIGVycik7XHJcbiAgfSk7XHJcblxyXG5mdW5jdGlvbiBmYWxsYmFja0luamVjdCgpOiB2b2lkIHtcclxuICB0cnkge1xyXG4gICAgY29uc3Qgc3JjID0gYnJvd3Nlci5ydW50aW1lLmdldFVSTCgncGFnZS1ob29rLmpzJyk7XHJcbiAgICBjb25zdCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtcclxuICAgIHNjcmlwdC5zcmMgPSBzcmM7XHJcbiAgICBzY3JpcHQuYXN5bmMgPSBmYWxzZTtcclxuICAgIHNjcmlwdC5kYXRhc2V0LmltbUFyY2hpdmUgPSAnMSc7XHJcbiAgICAoZG9jdW1lbnQuaGVhZCB8fCBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpLmFwcGVuZENoaWxkKHNjcmlwdCk7XHJcbiAgICBzY3JpcHQub25sb2FkID0gKCkgPT4gc2NyaXB0LnJlbW92ZSgpO1xyXG4gICAgc2NyaXB0Lm9uZXJyb3IgPSAoKSA9PiB7XHJcbiAgICAgIC8vIENTUCBwcm9iYWJseSBibG9ja2VkIHRoaXMuIE5vdCBmYXRhbCBcdTIwMTQgdGhlIE1BSU4td29ybGQgY29udGVudCBzY3JpcHRcclxuICAgICAgLy8gZGVjbGFyZWQgaW4gbWFuaWZlc3QuanNvbiBpcyB0aGUgcHJpbWFyeSBwYXRoLiBTdXJmYWNlIGFzIGEgbG9nIHNvXHJcbiAgICAgIC8vIHdlIGtub3cgd2hhdCBoYXBwZW5lZCB3aXRob3V0IGx5aW5nIGFib3V0IHN1Y2Nlc3MuXHJcbiAgICAgIGJyb3dzZXIucnVudGltZVxyXG4gICAgICAgIC5zZW5kTWVzc2FnZSh7XHJcbiAgICAgICAgICB0eXBlOiAnbG9nLWNvbnRlbnQtZXZlbnQnLFxyXG4gICAgICAgICAgbGV2ZWw6ICd3YXJuJyxcclxuICAgICAgICAgIG1zZzogJ2lubGluZSBwYWdlLWhvb2sgaW5qZWN0aW9uIGJsb2NrZWQgKENTUCk7IHJlbHlpbmcgb24gTUFJTi13b3JsZCBjb250ZW50IHNjcmlwdCcsXHJcbiAgICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWYsXHJcbiAgICAgICAgfSlcclxuICAgICAgICAuY2F0Y2goKCkgPT4ge30pO1xyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBpbmxpbmUgcGFnZS1ob29rIGluamVjdGlvbiB0aHJldycsIGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mYWxsYmFja0luamVjdCgpO1xyXG5cclxuZnVuY3Rpb24gbm9ybWFsaXplSGFuZGxlKHJhdzogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xyXG4gIGlmICghcmF3KSByZXR1cm4gbnVsbDtcclxuICBjb25zdCBjbGVhbmVkID0gcmF3LnRyaW0oKS5yZXBsYWNlKC9eQC8sICcnKS50b0xvd2VyQ2FzZSgpO1xyXG4gIHJldHVybiBjbGVhbmVkLmxlbmd0aCA+IDAgPyBjbGVhbmVkIDogbnVsbDtcclxufVxyXG5cclxuY29uc3QgU1RBVFVTX0hPU1RTID0gbmV3IFNldChbJ3guY29tJywgJ3R3aXR0ZXIuY29tJywgJ21vYmlsZS50d2l0dGVyLmNvbSddKTtcclxuXHJcbmZ1bmN0aW9uIHBhcnNlVHdlZXRVcmwoaHJlZjogc3RyaW5nIHwgbnVsbCk6IHsgaGFuZGxlOiBzdHJpbmc7IGlkOiBzdHJpbmcgfSB8IG51bGwge1xyXG4gIGlmICghaHJlZikgcmV0dXJuIG51bGw7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHUgPSBuZXcgVVJMKGhyZWYsIGxvY2F0aW9uLmhyZWYpO1xyXG4gICAgaWYgKCFTVEFUVVNfSE9TVFMuaGFzKHUuaG9zdG5hbWUudG9Mb3dlckNhc2UoKSkpIHJldHVybiBudWxsO1xyXG4gICAgY29uc3QgcGFydHMgPSB1LnBhdGhuYW1lLnNwbGl0KCcvJykuZmlsdGVyKEJvb2xlYW4pO1xyXG4gICAgY29uc3Qgc3RhdHVzSWR4ID0gcGFydHMuaW5kZXhPZignc3RhdHVzJyk7XHJcbiAgICBpZiAoc3RhdHVzSWR4IDw9IDApIHJldHVybiBudWxsO1xyXG4gICAgY29uc3QgaGFuZGxlID0gbm9ybWFsaXplSGFuZGxlKHBhcnRzW3N0YXR1c0lkeCAtIDFdID8/IG51bGwpO1xyXG4gICAgY29uc3QgaWQgPSBwYXJ0c1tzdGF0dXNJZHggKyAxXSA/PyBudWxsO1xyXG4gICAgaWYgKCFoYW5kbGUgfHwgIWlkIHx8ICEvXlxcZCskLy50ZXN0KGlkKSkgcmV0dXJuIG51bGw7XHJcbiAgICByZXR1cm4geyBoYW5kbGUsIGlkIH07XHJcbiAgfSBjYXRjaCB7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhcnNlSGFuZGxlVXJsKGhyZWY6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAoIWhyZWYpIHJldHVybiBudWxsO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB1ID0gbmV3IFVSTChocmVmLCBsb2NhdGlvbi5ocmVmKTtcclxuICAgIGlmICghU1RBVFVTX0hPU1RTLmhhcyh1Lmhvc3RuYW1lLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IGZpcnN0ID0gdS5wYXRobmFtZS5zcGxpdCgnLycpLmZpbHRlcihCb29sZWFuKVswXTtcclxuICAgIGlmICghZmlyc3QgfHwgZmlyc3QgPT09ICdpJyB8fCBmaXJzdCA9PT0gJ2ludGVudCcgfHwgZmlyc3QgPT09ICdzZWFyY2gnKSByZXR1cm4gbnVsbDtcclxuICAgIHJldHVybiBub3JtYWxpemVIYW5kbGUoZmlyc3QpO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBpc1Zpc2libGUoZWw6IEVsZW1lbnQpOiBib29sZWFuIHtcclxuICBjb25zdCByZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XHJcbiAgaWYgKHJlY3Qud2lkdGggPT09IDAgfHwgcmVjdC5oZWlnaHQgPT09IDApIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBzdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsKTtcclxuICByZXR1cm4gc3R5bGUudmlzaWJpbGl0eSAhPT0gJ2hpZGRlbicgJiYgc3R5bGUuZGlzcGxheSAhPT0gJ25vbmUnO1xyXG59XHJcblxyXG5mdW5jdGlvbiBuZWFyZXN0VHdlZXRDb250YWluZXIoZWw6IEVsZW1lbnQpOiBFbGVtZW50IHwgbnVsbCB7XHJcbiAgcmV0dXJuIGVsLmNsb3Nlc3QoJ2FydGljbGUnKSA/PyBlbC5jbG9zZXN0KCdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0nKTtcclxufVxyXG5cclxuZnVuY3Rpb24gaXNSZXBseVRvQ29yZShjb250YWluZXI6IEVsZW1lbnQpOiBib29sZWFuIHtcclxuICBjb25zdCB0ZXh0ID0gKGNvbnRhaW5lci50ZXh0Q29udGVudCB8fCAnJykudG9Mb3dlckNhc2UoKTtcclxuICBpZiAoIXRleHQuaW5jbHVkZXMoJ3JlcGx5aW5nIHRvJykpIHJldHVybiBmYWxzZTtcclxuICBmb3IgKGNvbnN0IGxpbmsgb2YgQXJyYXkuZnJvbShjb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnYVtocmVmXScpKSkge1xyXG4gICAgY29uc3QgaGFuZGxlID0gcGFyc2VIYW5kbGVVcmwobGluay5nZXRBdHRyaWJ1dGUoJ2hyZWYnKSk7XHJcbiAgICBpZiAoaGFuZGxlICYmIHVuZm9sZENvcmVIYW5kbGVzLmhhcyhoYW5kbGUpKSByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbiAgcmV0dXJuIGZhbHNlO1xyXG59XHJcblxyXG5mdW5jdGlvbiBpc0NvcmVSZWxldmFudChjb250YWluZXI6IEVsZW1lbnQpOiBib29sZWFuIHtcclxuICBmb3IgKGNvbnN0IGxpbmsgb2YgQXJyYXkuZnJvbShjb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnYVtocmVmXScpKSkge1xyXG4gICAgY29uc3QgdHdlZXQgPSBwYXJzZVR3ZWV0VXJsKGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJykpO1xyXG4gICAgaWYgKCF0d2VldCkgY29udGludWU7XHJcbiAgICBpZiAodW5mb2xkQ29yZUhhbmRsZXMuaGFzKHR3ZWV0LmhhbmRsZSkpIHJldHVybiB0cnVlO1xyXG4gICAgaWYgKHVuZm9sZFJlbGV2YW50VHdlZXRJZHMuaGFzKHR3ZWV0LmlkKSkgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG4gIHJldHVybiBpc1JlcGx5VG9Db3JlKGNvbnRhaW5lcik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNjYW5BbmRVbmZvbGRTaG93TW9yZSgpOiB2b2lkIHtcclxuICB1bmZvbGRTY2FuVGltZXIgPSBudWxsO1xyXG4gIGlmICghdW5mb2xkRW5hYmxlZCB8fCB1bmZvbGRDb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm47XHJcbiAgY29uc3Qgc2VsZWN0b3JzID0gW1xyXG4gICAgJ1tkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxyXG4gICAgJ2J1dHRvbltkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxyXG4gICAgJ2FydGljbGUgW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcclxuICAgICdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0gW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcclxuICBdO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PEVsZW1lbnQ+KCk7XHJcbiAgbGV0IGNsaWNrZWQgPSAwO1xyXG4gIGZvciAoY29uc3Qgc2VsIG9mIHNlbGVjdG9ycykge1xyXG4gICAgZm9yIChjb25zdCBlbCBvZiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsKSkpIHtcclxuICAgICAgaWYgKHNlZW4uaGFzKGVsKSB8fCB1bmZvbGRlZENvbnRyb2xzLmhhcyhlbCkpIGNvbnRpbnVlO1xyXG4gICAgICBzZWVuLmFkZChlbCk7XHJcbiAgICAgIGlmICgoZWwudGV4dENvbnRlbnQgfHwgJycpLnRyaW0oKS50b0xvd2VyQ2FzZSgpICE9PSAnc2hvdyBtb3JlJykgY29udGludWU7XHJcbiAgICAgIGlmICghaXNWaXNpYmxlKGVsKSkgY29udGludWU7XHJcbiAgICAgIGNvbnN0IGNvbnRhaW5lciA9IG5lYXJlc3RUd2VldENvbnRhaW5lcihlbCk7XHJcbiAgICAgIGlmICghY29udGFpbmVyIHx8ICFpc0NvcmVSZWxldmFudChjb250YWluZXIpKSBjb250aW51ZTtcclxuICAgICAgdW5mb2xkZWRDb250cm9scy5hZGQoZWwpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIChlbCBhcyBIVE1MRWxlbWVudCkuY2xpY2soKTtcclxuICAgICAgICBjbGlja2VkICs9IDE7XHJcbiAgICAgIH0gY2F0Y2gge1xyXG4gICAgICAgIC8vIElnbm9yZSBzdGFsZSBvciBzeW50aGV0aWMgY29udHJvbHMuXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgaWYgKGNsaWNrZWQgPiAwKSB7XHJcbiAgICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc2hvdy1tb3JlLXVuZm9sZGVkJywgY291bnQ6IGNsaWNrZWQgfSkuY2F0Y2goKCkgPT4ge30pO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gc2NoZWR1bGVVbmZvbGRTY2FuKGRlbGF5ID0gVU5GT0xEX1NDQU5fREVCT1VOQ0VfTVMpOiB2b2lkIHtcclxuICBpZiAodW5mb2xkU2NhblRpbWVyICE9PSBudWxsKSByZXR1cm47XHJcbiAgdW5mb2xkU2NhblRpbWVyID0gc2V0VGltZW91dChzY2FuQW5kVW5mb2xkU2hvd01vcmUsIGRlbGF5KTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaFVuZm9sZFRhcmdldHMoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHtcclxuICAgICAgdHlwZTogJ2dldC11bmZvbGQtdGFyZ2V0cycsXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IHJhdyA9IHJlc3BvbnNlICYmIHR5cGVvZiByZXNwb25zZSA9PT0gJ29iamVjdCcgPyAocmVzcG9uc2UgYXMgVW5mb2xkVGFyZ2V0c1Jlc3BvbnNlKSA6IHt9O1xyXG4gICAgdW5mb2xkRW5hYmxlZCA9IHJhdy5lbmFibGVkICE9PSBmYWxzZTtcclxuICAgIHVuZm9sZENvcmVIYW5kbGVzID0gbmV3IFNldChcclxuICAgICAgKHJhdy5jb3JlSGFuZGxlcyA/PyBbXSkubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXkAvLCAnJykpXHJcbiAgICApO1xyXG4gICAgdW5mb2xkUmVsZXZhbnRUd2VldElkcyA9IG5ldyBTZXQocmF3LnJlbGV2YW50VHdlZXRJZHMgPz8gW10pO1xyXG4gICAgc2NoZWR1bGVVbmZvbGRTY2FuKDApO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgdW5mb2xkRW5hYmxlZCA9IGZhbHNlO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gaW5zdGFsbFVuZm9sZE9ic2VydmVyKCk6IHZvaWQge1xyXG4gIGNvbnN0IHJvb3QgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQgfHwgZG9jdW1lbnQuYm9keTtcclxuICBpZiAoIXJvb3QpIHtcclxuICAgIHNldFRpbWVvdXQoaW5zdGFsbFVuZm9sZE9ic2VydmVyLCAxMDApO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKCgpID0+IHNjaGVkdWxlVW5mb2xkU2NhbigpKTtcclxuICBvYnNlcnZlci5vYnNlcnZlKHJvb3QsIHsgY2hpbGRMaXN0OiB0cnVlLCBzdWJ0cmVlOiB0cnVlIH0pO1xyXG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdzY3JvbGwnLCAoKSA9PiBzY2hlZHVsZVVuZm9sZFNjYW4oKSwgeyBwYXNzaXZlOiB0cnVlIH0pO1xyXG4gIHZvaWQgcmVmcmVzaFVuZm9sZFRhcmdldHMoKTtcclxuICBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIHJlZnJlc2hVbmZvbGRUYXJnZXRzKCk7XHJcbiAgfSwgVU5GT0xEX1NZTkNfTVMpO1xyXG59XHJcblxyXG5pbnN0YWxsVW5mb2xkT2JzZXJ2ZXIoKTtcclxuXHJcbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgKGV2ZW50OiBNZXNzYWdlRXZlbnQpID0+IHtcclxuICBpZiAoZXZlbnQuc291cmNlICE9PSB3aW5kb3cpIHJldHVybjtcclxuICBjb25zdCBkYXRhID0gZXZlbnQuZGF0YSBhcyB1bmtub3duO1xyXG4gIGlmICghZGF0YSB8fCB0eXBlb2YgZGF0YSAhPT0gJ29iamVjdCcpIHJldHVybjtcclxuICBjb25zdCBkID0gZGF0YSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuXHJcbiAgaWYgKGQuc291cmNlID09PSBSRUFEWSkge1xyXG4gICAgYnJvd3Nlci5ydW50aW1lXHJcbiAgICAgIC5zZW5kTWVzc2FnZSh7XHJcbiAgICAgICAgdHlwZTogJ3BhZ2UtaG9vay1hY3RpdmUnLFxyXG4gICAgICAgIHVybDogdHlwZW9mIGQudXJsID09PSAnc3RyaW5nJyA/IGQudXJsIDogbG9jYXRpb24uaHJlZixcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHt9KTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIGlmIChkLnNvdXJjZSAhPT0gVEFSR0VUKSByZXR1cm47XHJcbiAgY29uc3QgZW5kcG9pbnQgPSB0eXBlb2YgZC5lbmRwb2ludCA9PT0gJ3N0cmluZycgPyBkLmVuZHBvaW50IDogbnVsbDtcclxuICBjb25zdCB1cmwgPSB0eXBlb2YgZC51cmwgPT09ICdzdHJpbmcnID8gZC51cmwgOiBudWxsO1xyXG4gIGNvbnN0IHBhZ2VVcmwgPSB0eXBlb2YgZC5wYWdlX3VybCA9PT0gJ3N0cmluZycgPyBkLnBhZ2VfdXJsIDogbG9jYXRpb24uaHJlZjtcclxuICBjb25zdCByZXNwb25zZSA9IGQucmVzcG9uc2U7XHJcbiAgaWYgKCFlbmRwb2ludCB8fCAhdXJsIHx8IHJlc3BvbnNlID09PSB1bmRlZmluZWQpIHJldHVybjtcclxuICBicm93c2VyLnJ1bnRpbWVcclxuICAgIC5zZW5kTWVzc2FnZSh7IHR5cGU6ICdncmFwaHFsLWNhcHR1cmUnLCBlbmRwb2ludCwgdXJsLCBwYWdlVXJsLCByZXNwb25zZSB9KVxyXG4gICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNlbmRNZXNzYWdlIGZhaWxlZCcsIGVycik7XHJcbiAgICB9KTtcclxufSk7XHJcbiJdLAogICJtYXBwaW5ncyI6ICI7OztBQXNCQSxNQUFNLFNBQVM7QUFDZixNQUFNLFFBQVE7QUFDZCxNQUFNLGlCQUFpQjtBQUN2QixNQUFNLDBCQUEwQjtBQVFoQyxNQUFJLGdCQUFnQjtBQUNwQixNQUFJLG9CQUFvQixvQkFBSSxJQUFZO0FBQ3hDLE1BQUkseUJBQXlCLG9CQUFJLElBQVk7QUFDN0MsTUFBSSxrQkFBd0Q7QUFDNUQsTUFBTSxtQkFBbUIsb0JBQUksUUFBaUI7QUFFOUMsT0FBSyxRQUFRLFFBQ1YsWUFBWSxFQUFFLE1BQU0saUJBQWlCLEtBQUssU0FBUyxLQUFLLENBQUMsRUFDekQsTUFBTSxDQUFDLFFBQWlCO0FBQ3ZCLFlBQVEsS0FBSywyQ0FBMkMsR0FBRztBQUFBLEVBQzdELENBQUM7QUFFSCxXQUFTLGlCQUF1QjtBQUM5QixRQUFJO0FBQ0YsWUFBTSxNQUFNLFFBQVEsUUFBUSxPQUFPLGNBQWM7QUFDakQsWUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0FBQzlDLGFBQU8sTUFBTTtBQUNiLGFBQU8sUUFBUTtBQUNmLGFBQU8sUUFBUSxhQUFhO0FBQzVCLE9BQUMsU0FBUyxRQUFRLFNBQVMsaUJBQWlCLFlBQVksTUFBTTtBQUM5RCxhQUFPLFNBQVMsTUFBTSxPQUFPLE9BQU87QUFDcEMsYUFBTyxVQUFVLE1BQU07QUFJckIsZ0JBQVEsUUFDTCxZQUFZO0FBQUEsVUFDWCxNQUFNO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxLQUFLO0FBQUEsVUFDTCxLQUFLLFNBQVM7QUFBQSxRQUNoQixDQUFDLEVBQ0EsTUFBTSxNQUFNO0FBQUEsUUFBQyxDQUFDO0FBQUEsTUFDbkI7QUFBQSxJQUNGLFNBQVMsS0FBSztBQUNaLGNBQVEsS0FBSyxrREFBa0QsR0FBRztBQUFBLElBQ3BFO0FBQUEsRUFDRjtBQUVBLGlCQUFlO0FBRWYsV0FBUyxnQkFBZ0IsS0FBbUM7QUFDMUQsUUFBSSxDQUFDLElBQUssUUFBTztBQUNqQixVQUFNLFVBQVUsSUFBSSxLQUFLLEVBQUUsUUFBUSxNQUFNLEVBQUUsRUFBRSxZQUFZO0FBQ3pELFdBQU8sUUFBUSxTQUFTLElBQUksVUFBVTtBQUFBLEVBQ3hDO0FBRUEsTUFBTSxlQUFlLG9CQUFJLElBQUksQ0FBQyxTQUFTLGVBQWUsb0JBQW9CLENBQUM7QUFFM0UsV0FBUyxjQUFjLE1BQTREO0FBQ2pGLFFBQUksQ0FBQyxLQUFNLFFBQU87QUFDbEIsUUFBSTtBQUNGLFlBQU0sSUFBSSxJQUFJLElBQUksTUFBTSxTQUFTLElBQUk7QUFDckMsVUFBSSxDQUFDLGFBQWEsSUFBSSxFQUFFLFNBQVMsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUN4RCxZQUFNLFFBQVEsRUFBRSxTQUFTLE1BQU0sR0FBRyxFQUFFLE9BQU8sT0FBTztBQUNsRCxZQUFNLFlBQVksTUFBTSxRQUFRLFFBQVE7QUFDeEMsVUFBSSxhQUFhLEVBQUcsUUFBTztBQUMzQixZQUFNLFNBQVMsZ0JBQWdCLE1BQU0sWUFBWSxDQUFDLEtBQUssSUFBSTtBQUMzRCxZQUFNLEtBQUssTUFBTSxZQUFZLENBQUMsS0FBSztBQUNuQyxVQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssRUFBRSxFQUFHLFFBQU87QUFDaEQsYUFBTyxFQUFFLFFBQVEsR0FBRztBQUFBLElBQ3RCLFFBQVE7QUFDTixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGVBQWUsTUFBb0M7QUFDMUQsUUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixRQUFJO0FBQ0YsWUFBTSxJQUFJLElBQUksSUFBSSxNQUFNLFNBQVMsSUFBSTtBQUNyQyxVQUFJLENBQUMsYUFBYSxJQUFJLEVBQUUsU0FBUyxZQUFZLENBQUMsRUFBRyxRQUFPO0FBQ3hELFlBQU0sUUFBUSxFQUFFLFNBQVMsTUFBTSxHQUFHLEVBQUUsT0FBTyxPQUFPLEVBQUUsQ0FBQztBQUNyRCxVQUFJLENBQUMsU0FBUyxVQUFVLE9BQU8sVUFBVSxZQUFZLFVBQVUsU0FBVSxRQUFPO0FBQ2hGLGFBQU8sZ0JBQWdCLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsV0FBUyxVQUFVLElBQXNCO0FBQ3ZDLFVBQU0sT0FBTyxHQUFHLHNCQUFzQjtBQUN0QyxRQUFJLEtBQUssVUFBVSxLQUFLLEtBQUssV0FBVyxFQUFHLFFBQU87QUFDbEQsVUFBTSxRQUFRLE9BQU8saUJBQWlCLEVBQUU7QUFDeEMsV0FBTyxNQUFNLGVBQWUsWUFBWSxNQUFNLFlBQVk7QUFBQSxFQUM1RDtBQUVBLFdBQVMsc0JBQXNCLElBQTZCO0FBQzFELFdBQU8sR0FBRyxRQUFRLFNBQVMsS0FBSyxHQUFHLFFBQVEsaUNBQWlDO0FBQUEsRUFDOUU7QUFFQSxXQUFTLGNBQWMsV0FBNkI7QUFDbEQsVUFBTSxRQUFRLFVBQVUsZUFBZSxJQUFJLFlBQVk7QUFDdkQsUUFBSSxDQUFDLEtBQUssU0FBUyxhQUFhLEVBQUcsUUFBTztBQUMxQyxlQUFXLFFBQVEsTUFBTSxLQUFLLFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxHQUFHO0FBQ3BFLFlBQU0sU0FBUyxlQUFlLEtBQUssYUFBYSxNQUFNLENBQUM7QUFDdkQsVUFBSSxVQUFVLGtCQUFrQixJQUFJLE1BQU0sRUFBRyxRQUFPO0FBQUEsSUFDdEQ7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFdBQVMsZUFBZSxXQUE2QjtBQUNuRCxlQUFXLFFBQVEsTUFBTSxLQUFLLFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxHQUFHO0FBQ3BFLFlBQU0sUUFBUSxjQUFjLEtBQUssYUFBYSxNQUFNLENBQUM7QUFDckQsVUFBSSxDQUFDLE1BQU87QUFDWixVQUFJLGtCQUFrQixJQUFJLE1BQU0sTUFBTSxFQUFHLFFBQU87QUFDaEQsVUFBSSx1QkFBdUIsSUFBSSxNQUFNLEVBQUUsRUFBRyxRQUFPO0FBQUEsSUFDbkQ7QUFDQSxXQUFPLGNBQWMsU0FBUztBQUFBLEVBQ2hDO0FBRUEsV0FBUyx3QkFBOEI7QUFDckMsc0JBQWtCO0FBQ2xCLFFBQUksQ0FBQyxpQkFBaUIsa0JBQWtCLFNBQVMsRUFBRztBQUNwRCxVQUFNLFlBQVk7QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLE9BQU8sb0JBQUksSUFBYTtBQUM5QixRQUFJLFVBQVU7QUFDZCxlQUFXLE9BQU8sV0FBVztBQUMzQixpQkFBVyxNQUFNLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixHQUFHLENBQUMsR0FBRztBQUMzRCxZQUFJLEtBQUssSUFBSSxFQUFFLEtBQUssaUJBQWlCLElBQUksRUFBRSxFQUFHO0FBQzlDLGFBQUssSUFBSSxFQUFFO0FBQ1gsYUFBSyxHQUFHLGVBQWUsSUFBSSxLQUFLLEVBQUUsWUFBWSxNQUFNLFlBQWE7QUFDakUsWUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFHO0FBQ3BCLGNBQU0sWUFBWSxzQkFBc0IsRUFBRTtBQUMxQyxZQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsU0FBUyxFQUFHO0FBQzlDLHlCQUFpQixJQUFJLEVBQUU7QUFDdkIsWUFBSTtBQUNGLFVBQUMsR0FBbUIsTUFBTTtBQUMxQixxQkFBVztBQUFBLFFBQ2IsUUFBUTtBQUFBLFFBRVI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFFBQUksVUFBVSxHQUFHO0FBQ2YsY0FBUSxRQUFRLFlBQVksRUFBRSxNQUFNLHNCQUFzQixPQUFPLFFBQVEsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUFBLElBQzVGO0FBQUEsRUFDRjtBQUVBLFdBQVMsbUJBQW1CLFFBQVEseUJBQStCO0FBQ2pFLFFBQUksb0JBQW9CLEtBQU07QUFDOUIsc0JBQWtCLFdBQVcsdUJBQXVCLEtBQUs7QUFBQSxFQUMzRDtBQUVBLGlCQUFlLHVCQUFzQztBQUNuRCxRQUFJO0FBQ0YsWUFBTSxXQUFXLE1BQU0sUUFBUSxRQUFRLFlBQVk7QUFBQSxRQUNqRCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0QsWUFBTSxNQUFNLFlBQVksT0FBTyxhQUFhLFdBQVksV0FBcUMsQ0FBQztBQUM5RixzQkFBZ0IsSUFBSSxZQUFZO0FBQ2hDLDBCQUFvQixJQUFJO0FBQUEsU0FDckIsSUFBSSxlQUFlLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksRUFBRSxRQUFRLE1BQU0sRUFBRSxDQUFDO0FBQUEsTUFDdEU7QUFDQSwrQkFBeUIsSUFBSSxJQUFJLElBQUksb0JBQW9CLENBQUMsQ0FBQztBQUMzRCx5QkFBbUIsQ0FBQztBQUFBLElBQ3RCLFFBQVE7QUFDTixzQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLHdCQUE4QjtBQUNyQyxVQUFNLE9BQU8sU0FBUyxtQkFBbUIsU0FBUztBQUNsRCxRQUFJLENBQUMsTUFBTTtBQUNULGlCQUFXLHVCQUF1QixHQUFHO0FBQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sV0FBVyxJQUFJLGlCQUFpQixNQUFNLG1CQUFtQixDQUFDO0FBQ2hFLGFBQVMsUUFBUSxNQUFNLEVBQUUsV0FBVyxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBQ3pELFdBQU8saUJBQWlCLFVBQVUsTUFBTSxtQkFBbUIsR0FBRyxFQUFFLFNBQVMsS0FBSyxDQUFDO0FBQy9FLFNBQUsscUJBQXFCO0FBQzFCLGdCQUFZLE1BQU07QUFDaEIsV0FBSyxxQkFBcUI7QUFBQSxJQUM1QixHQUFHLGNBQWM7QUFBQSxFQUNuQjtBQUVBLHdCQUFzQjtBQUV0QixTQUFPLGlCQUFpQixXQUFXLENBQUMsVUFBd0I7QUFDMUQsUUFBSSxNQUFNLFdBQVcsT0FBUTtBQUM3QixVQUFNLE9BQU8sTUFBTTtBQUNuQixRQUFJLENBQUMsUUFBUSxPQUFPLFNBQVMsU0FBVTtBQUN2QyxVQUFNLElBQUk7QUFFVixRQUFJLEVBQUUsV0FBVyxPQUFPO0FBQ3RCLGNBQVEsUUFDTCxZQUFZO0FBQUEsUUFDWCxNQUFNO0FBQUEsUUFDTixLQUFLLE9BQU8sRUFBRSxRQUFRLFdBQVcsRUFBRSxNQUFNLFNBQVM7QUFBQSxNQUNwRCxDQUFDLEVBQ0EsTUFBTSxNQUFNO0FBQUEsTUFBQyxDQUFDO0FBQ2pCO0FBQUEsSUFDRjtBQUVBLFFBQUksRUFBRSxXQUFXLE9BQVE7QUFDekIsVUFBTSxXQUFXLE9BQU8sRUFBRSxhQUFhLFdBQVcsRUFBRSxXQUFXO0FBQy9ELFVBQU0sTUFBTSxPQUFPLEVBQUUsUUFBUSxXQUFXLEVBQUUsTUFBTTtBQUNoRCxVQUFNLFVBQVUsT0FBTyxFQUFFLGFBQWEsV0FBVyxFQUFFLFdBQVcsU0FBUztBQUN2RSxVQUFNLFdBQVcsRUFBRTtBQUNuQixRQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sYUFBYSxPQUFXO0FBQ2pELFlBQVEsUUFDTCxZQUFZLEVBQUUsTUFBTSxtQkFBbUIsVUFBVSxLQUFLLFNBQVMsU0FBUyxDQUFDLEVBQ3pFLE1BQU0sQ0FBQyxRQUFRO0FBQ2QsY0FBUSxLQUFLLG9DQUFvQyxHQUFHO0FBQUEsSUFDdEQsQ0FBQztBQUFBLEVBQ0wsQ0FBQzsiLAogICJuYW1lcyI6IFtdCn0K
