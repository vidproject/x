"use strict";
(() => {
  // extension/src/content.ts
  var TARGET = "IMM_ARCHIVE_CAPTURE";
  function inject() {
    try {
      const src = browser.runtime.getURL("page-hook.js");
      const script = document.createElement("script");
      script.src = src;
      script.async = false;
      script.dataset.immArchive = "1";
      (document.head || document.documentElement).appendChild(script);
      script.onload = () => script.remove();
    } catch (err) {
      console.warn("[imm-archive] failed to inject page hook", err);
    }
  }
  inject();
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== "object") return;
    const d = data;
    if (d.source !== TARGET) return;
    const endpoint = typeof d.endpoint === "string" ? d.endpoint : null;
    const url = typeof d.url === "string" ? d.url : null;
    const response = d.response;
    if (!endpoint || !url || response === void 0) return;
    browser.runtime.sendMessage({ type: "graphql-capture", endpoint, url, response }).catch((err) => {
      console.warn("[imm-archive] sendMessage failed", err);
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbnRlbnQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKlxuICogY29udGVudC50cyBcdTIwMTQgY29udGVudC1zY3JpcHQgY29udGV4dC5cbiAqXG4gKiAxLiBJbmplY3RzIGBwYWdlLWhvb2suanNgIGludG8gdGhlIHBhZ2Ugd29ybGQgc28gd2UgY2FuIG9ic2VydmUgR3JhcGhRTFxuICogICAgcmVzcG9uc2VzIChjb250ZW50IHNjcmlwdHMgcnVuIGluIGFuIGlzb2xhdGVkIHdvcmxkIGFuZCBjYW4ndCBzZWUgdGhlXG4gKiAgICBwYWdlJ3MgZmV0Y2gvWEhSIGJ5IGRlZmF1bHQpLlxuICogMi4gTGlzdGVucyBmb3IgYHdpbmRvdy5wb3N0TWVzc2FnZWAgZXZlbnRzIGZyb20gdGhlIHBhZ2UgaG9vayBhbmQgZm9yd2FyZHNcbiAqICAgIHRoZW0gdG8gdGhlIGJhY2tncm91bmQgc2VydmljZSB3b3JrZXIuXG4gKlxuICogVGhlIGhvb2sgcnVucyBhdCBkb2N1bWVudF9zdGFydCBzbyBpdCBwYXRjaGVzIGZldGNoL1hIUiBiZWZvcmUgWCdzIGFwcFxuICogY29kZSBzdGFydHMgdXNpbmcgdGhlbS5cbiAqL1xuXG5jb25zdCBUQVJHRVQgPSAnSU1NX0FSQ0hJVkVfQ0FQVFVSRSc7XG5cbmZ1bmN0aW9uIGluamVjdCgpOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBjb25zdCBzcmMgPSBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKCdwYWdlLWhvb2suanMnKTtcbiAgICBjb25zdCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtcbiAgICBzY3JpcHQuc3JjID0gc3JjO1xuICAgIHNjcmlwdC5hc3luYyA9IGZhbHNlO1xuICAgIHNjcmlwdC5kYXRhc2V0LmltbUFyY2hpdmUgPSAnMSc7XG4gICAgKGRvY3VtZW50LmhlYWQgfHwgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICAgIHNjcmlwdC5vbmxvYWQgPSAoKSA9PiBzY3JpcHQucmVtb3ZlKCk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBmYWlsZWQgdG8gaW5qZWN0IHBhZ2UgaG9vaycsIGVycik7XG4gIH1cbn1cblxuaW5qZWN0KCk7XG5cbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgKGV2ZW50OiBNZXNzYWdlRXZlbnQpID0+IHtcbiAgaWYgKGV2ZW50LnNvdXJjZSAhPT0gd2luZG93KSByZXR1cm47XG4gIGNvbnN0IGRhdGEgPSBldmVudC5kYXRhIGFzIHVua25vd247XG4gIGlmICghZGF0YSB8fCB0eXBlb2YgZGF0YSAhPT0gJ29iamVjdCcpIHJldHVybjtcbiAgY29uc3QgZCA9IGRhdGEgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIGlmIChkLnNvdXJjZSAhPT0gVEFSR0VUKSByZXR1cm47XG4gIGNvbnN0IGVuZHBvaW50ID0gdHlwZW9mIGQuZW5kcG9pbnQgPT09ICdzdHJpbmcnID8gZC5lbmRwb2ludCA6IG51bGw7XG4gIGNvbnN0IHVybCA9IHR5cGVvZiBkLnVybCA9PT0gJ3N0cmluZycgPyBkLnVybCA6IG51bGw7XG4gIGNvbnN0IHJlc3BvbnNlID0gZC5yZXNwb25zZTtcbiAgaWYgKCFlbmRwb2ludCB8fCAhdXJsIHx8IHJlc3BvbnNlID09PSB1bmRlZmluZWQpIHJldHVybjtcbiAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2dyYXBocWwtY2FwdHVyZScsIGVuZHBvaW50LCB1cmwsIHJlc3BvbnNlIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICAvLyBUaGUgYmFja2dyb3VuZCB3b3JrZXIgbWF5IGJlIGFzbGVlcDsgc2VuZE1lc3NhZ2Ugc2hvdWxkIHdha2UgaXQuXG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNlbmRNZXNzYWdlIGZhaWxlZCcsIGVycik7XG4gIH0pO1xufSk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFhQSxNQUFNLFNBQVM7QUFFZixXQUFTLFNBQWU7QUFDdEIsUUFBSTtBQUNGLFlBQU0sTUFBTSxRQUFRLFFBQVEsT0FBTyxjQUFjO0FBQ2pELFlBQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtBQUM5QyxhQUFPLE1BQU07QUFDYixhQUFPLFFBQVE7QUFDZixhQUFPLFFBQVEsYUFBYTtBQUM1QixPQUFDLFNBQVMsUUFBUSxTQUFTLGlCQUFpQixZQUFZLE1BQU07QUFDOUQsYUFBTyxTQUFTLE1BQU0sT0FBTyxPQUFPO0FBQUEsSUFDdEMsU0FBUyxLQUFLO0FBQ1osY0FBUSxLQUFLLDRDQUE0QyxHQUFHO0FBQUEsSUFDOUQ7QUFBQSxFQUNGO0FBRUEsU0FBTztBQUVQLFNBQU8saUJBQWlCLFdBQVcsQ0FBQyxVQUF3QjtBQUMxRCxRQUFJLE1BQU0sV0FBVyxPQUFRO0FBQzdCLFVBQU0sT0FBTyxNQUFNO0FBQ25CLFFBQUksQ0FBQyxRQUFRLE9BQU8sU0FBUyxTQUFVO0FBQ3ZDLFVBQU0sSUFBSTtBQUNWLFFBQUksRUFBRSxXQUFXLE9BQVE7QUFDekIsVUFBTSxXQUFXLE9BQU8sRUFBRSxhQUFhLFdBQVcsRUFBRSxXQUFXO0FBQy9ELFVBQU0sTUFBTSxPQUFPLEVBQUUsUUFBUSxXQUFXLEVBQUUsTUFBTTtBQUNoRCxVQUFNLFdBQVcsRUFBRTtBQUNuQixRQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sYUFBYSxPQUFXO0FBQ2pELFlBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxtQkFBbUIsVUFBVSxLQUFLLFNBQVMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBRS9GLGNBQVEsS0FBSyxvQ0FBb0MsR0FBRztBQUFBLElBQ3RELENBQUM7QUFBQSxFQUNILENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
