"use strict";
(() => {
  // extension/src/content.ts
  var TARGET = "IMM_ARCHIVE_CAPTURE";
  var READY = "IMM_ARCHIVE_HOOK_READY";
  var UNFOLD_SYNC_MS = 2e3;
  var UNFOLD_SCAN_DEBOUNCE_MS = 250;
  var unfoldEnabled = false;
  var unfoldCoreHandles = /* @__PURE__ */ new Set();
  var unfoldRelevantTweetIds = /* @__PURE__ */ new Set();
  var unfoldScanTimer = null;
  var unfoldedControls = /* @__PURE__ */ new WeakSet();
  void browser.runtime.sendMessage({ type: "content-alive", url: location.href }).catch((err) => {
    console.warn("[imm-archive] content-alive ping failed", err);
  });
  function fallbackInject() {
    try {
      const src = browser.runtime.getURL("page-hook.js");
      const script = document.createElement("script");
      script.src = src;
      script.async = false;
      script.dataset.immArchive = "1";
      (document.head || document.documentElement).appendChild(script);
      script.onload = () => script.remove();
      script.onerror = () => {
        browser.runtime.sendMessage({
          type: "log-content-event",
          level: "warn",
          msg: "inline page-hook injection blocked (CSP); relying on MAIN-world content script",
          url: location.href
        }).catch(() => {
        });
      };
    } catch (err) {
      console.warn("[imm-archive] inline page-hook injection threw", err);
    }
  }
  fallbackInject();
  function normalizeHandle(raw) {
    if (!raw) return null;
    const cleaned = raw.trim().replace(/^@/, "").toLowerCase();
    return cleaned.length > 0 ? cleaned : null;
  }
  var STATUS_HOSTS = /* @__PURE__ */ new Set(["x.com", "twitter.com", "mobile.twitter.com"]);
  function parseTweetUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const parts = u.pathname.split("/").filter(Boolean);
      const statusIdx = parts.indexOf("status");
      if (statusIdx <= 0) return null;
      const handle = normalizeHandle(parts[statusIdx - 1] ?? null);
      const id = parts[statusIdx + 1] ?? null;
      if (!handle || !id || !/^\d+$/.test(id)) return null;
      return { handle, id };
    } catch {
      return null;
    }
  }
  function parseHandleUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const first = u.pathname.split("/").filter(Boolean)[0];
      if (!first || first === "i" || first === "intent" || first === "search") return null;
      return normalizeHandle(first);
    } catch {
      return null;
    }
  }
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none";
  }
  function nearestTweetContainer(el) {
    return el.closest("article") ?? el.closest('div[data-testid="cellInnerDiv"]');
  }
  function isReplyToCore(container) {
    const text = (container.textContent || "").toLowerCase();
    if (!text.includes("replying to")) return false;
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const handle = parseHandleUrl(link.getAttribute("href"));
      if (handle && unfoldCoreHandles.has(handle)) return true;
    }
    return false;
  }
  function isCoreRelevant(container) {
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const tweet = parseTweetUrl(link.getAttribute("href"));
      if (!tweet) continue;
      if (unfoldCoreHandles.has(tweet.handle)) return true;
      if (unfoldRelevantTweetIds.has(tweet.id)) return true;
    }
    return isReplyToCore(container);
  }
  function scanAndUnfoldShowMore() {
    unfoldScanTimer = null;
    if (!unfoldEnabled || unfoldCoreHandles.size === 0) return;
    const selectors = [
      '[data-testid="tweet-text-show-more-link"]',
      'button[data-testid="tweet-text-show-more-link"]',
      'article [role="button"][tabindex="0"]',
      'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
    ];
    const seen = /* @__PURE__ */ new Set();
    let clicked = 0;
    for (const sel of selectors) {
      for (const el of Array.from(document.querySelectorAll(sel))) {
        if (seen.has(el) || unfoldedControls.has(el)) continue;
        seen.add(el);
        if ((el.textContent || "").trim().toLowerCase() !== "show more") continue;
        if (!isVisible(el)) continue;
        const container = nearestTweetContainer(el);
        if (!container || !isCoreRelevant(container)) continue;
        unfoldedControls.add(el);
        try {
          el.click();
          clicked += 1;
        } catch {
        }
      }
    }
    if (clicked > 0) {
      browser.runtime.sendMessage({ type: "show-more-unfolded", count: clicked }).catch(() => {
      });
    }
  }
  function scheduleUnfoldScan(delay = UNFOLD_SCAN_DEBOUNCE_MS) {
    if (unfoldScanTimer !== null) return;
    unfoldScanTimer = setTimeout(scanAndUnfoldShowMore, delay);
  }
  async function refreshUnfoldTargets() {
    try {
      const response = await browser.runtime.sendMessage({
        type: "get-unfold-targets"
      });
      const raw = response && typeof response === "object" ? response : {};
      unfoldEnabled = raw.enabled !== false;
      unfoldCoreHandles = new Set(
        (raw.coreHandles ?? []).map((h) => h.toLowerCase().replace(/^@/, ""))
      );
      unfoldRelevantTweetIds = new Set(raw.relevantTweetIds ?? []);
      scheduleUnfoldScan(0);
    } catch {
      unfoldEnabled = false;
    }
  }
  function installUnfoldObserver() {
    const root = document.documentElement || document.body;
    if (!root) {
      setTimeout(installUnfoldObserver, 100);
      return;
    }
    const observer = new MutationObserver(() => scheduleUnfoldScan());
    observer.observe(root, { childList: true, subtree: true });
    window.addEventListener("scroll", () => scheduleUnfoldScan(), { passive: true });
    void refreshUnfoldTargets();
    setInterval(() => {
      void refreshUnfoldTargets();
    }, UNFOLD_SYNC_MS);
  }
  installUnfoldObserver();
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== "object") return;
    const d = data;
    if (d.source === READY) {
      browser.runtime.sendMessage({
        type: "page-hook-active",
        url: typeof d.url === "string" ? d.url : location.href
      }).catch(() => {
      });
      return;
    }
    if (d.source !== TARGET) return;
    const endpoint = typeof d.endpoint === "string" ? d.endpoint : null;
    const url = typeof d.url === "string" ? d.url : null;
    const pageUrl = typeof d.page_url === "string" ? d.page_url : location.href;
    const response = d.response;
    if (!endpoint || !url || response === void 0) return;
    browser.runtime.sendMessage({ type: "graphql-capture", endpoint, url, pageUrl, response }).catch((err) => {
      console.warn("[imm-archive] sendMessage failed", err);
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbnRlbnQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKlxuICogY29udGVudC50cyBcdTIwMTQgY29udGVudC1zY3JpcHQgY29udGV4dCAoaXNvbGF0ZWQgd29ybGQpLlxuICpcbiAqIFRoZSBhY3R1YWwgcGFnZS1ob29rICh3aGljaCBwYXRjaGVzIGBmZXRjaGAgLyBgWEhSYCkgaXMgZGVjbGFyZWQgYXMgYVxuICogc2VwYXJhdGUgY29udGVudCBzY3JpcHQgd2l0aCBgd29ybGQ6IFwiTUFJTlwiYCBpbiB0aGUgbWFuaWZlc3QsIHNvIGl0IHJ1bnNcbiAqIGluIHRoZSBwYWdlIHdvcmxkIGRpcmVjdGx5IHdpdGhvdXQgdXMgaGF2aW5nIHRvIGluamVjdCBhIDxzY3JpcHQ+IHRhZyBcdTIwMTRcbiAqIHdoaWNoIFgncyBub25jZS1iYXNlZCBDU1Agd291bGQgYmxvY2suXG4gKlxuICogVGhpcyBmaWxlIGRvZXMgdGhyZWUgdGhpbmdzOlxuICpcbiAqICAgMS4gUGluZ3MgdGhlIGJhY2tncm91bmQgb24gbG9hZCBzbyB0aGUgYWN0aXZpdHkgdGFpbCBjb25maXJtcyB0aGVcbiAqICAgICAgY29udGVudCBzY3JpcHQgcmVhY2hlZCB0aGUgWCBwYWdlICh1c2VmdWwgd2hlbiBkaWFnbm9zaW5nIGEgc2lsZW50XG4gKiAgICAgIFwiY2FwdHVyZS1ub3cgZG9lcyBub3RoaW5nXCIgZmFpbHVyZSkuXG4gKiAgIDIuIEFzIGEgZGVmZW5zaXZlIGZhbGxiYWNrLCBhbHNvIHRyaWVzIHRvIGluamVjdCBgcGFnZS1ob29rLmpzYCB2aWEgYVxuICogICAgICBzY3JpcHQgdGFnLiBIYXJtbGVzcyBvbiBtb2Rlcm4gRmlyZWZveCAodGhlIHBhZ2UtaG9vaydzIFRBRyBndWFyZFxuICogICAgICBwcmV2ZW50cyBkb3VibGUtaW5pdCk7IGNvdmVycyB0aGUgcmFyZSBjYXNlIHdoZXJlIHRoZSBNQUlOLXdvcmxkXG4gKiAgICAgIGNvbnRlbnQgc2NyaXB0IGVudHJ5IGlzbid0IGhvbm9yZWQuXG4gKiAgIDMuIEJyaWRnZXMgYHdpbmRvdy5wb3N0TWVzc2FnZWAgZnJvbSB0aGUgcGFnZSBob29rIHRvIHRoZSBiYWNrZ3JvdW5kOlxuICogICAgICBib3RoIHRoZSBgKl9SRUFEWWAgYm9vdCBwaW5nIGFuZCB0aGUgYElNTV9BUkNISVZFX0NBUFRVUkVgIHBheWxvYWRcbiAqICAgICAgZXZlbnRzLlxuICovXG5cbmNvbnN0IFRBUkdFVCA9ICdJTU1fQVJDSElWRV9DQVBUVVJFJztcbmNvbnN0IFJFQURZID0gJ0lNTV9BUkNISVZFX0hPT0tfUkVBRFknO1xuY29uc3QgVU5GT0xEX1NZTkNfTVMgPSAyXzAwMDtcbmNvbnN0IFVORk9MRF9TQ0FOX0RFQk9VTkNFX01TID0gMjUwO1xuXG5pbnRlcmZhY2UgVW5mb2xkVGFyZ2V0c1Jlc3BvbnNlIHtcbiAgZW5hYmxlZD86IGJvb2xlYW47XG4gIGNvcmVIYW5kbGVzPzogc3RyaW5nW107XG4gIHJlbGV2YW50VHdlZXRJZHM/OiBzdHJpbmdbXTtcbn1cblxubGV0IHVuZm9sZEVuYWJsZWQgPSBmYWxzZTtcbmxldCB1bmZvbGRDb3JlSGFuZGxlcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xubGV0IHVuZm9sZFJlbGV2YW50VHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbmxldCB1bmZvbGRTY2FuVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbCA9IG51bGw7XG5jb25zdCB1bmZvbGRlZENvbnRyb2xzID0gbmV3IFdlYWtTZXQ8RWxlbWVudD4oKTtcblxudm9pZCBicm93c2VyLnJ1bnRpbWVcbiAgLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2NvbnRlbnQtYWxpdmUnLCB1cmw6IGxvY2F0aW9uLmhyZWYgfSlcbiAgLmNhdGNoKChlcnI6IHVua25vd24pID0+IHtcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gY29udGVudC1hbGl2ZSBwaW5nIGZhaWxlZCcsIGVycik7XG4gIH0pO1xuXG5mdW5jdGlvbiBmYWxsYmFja0luamVjdCgpOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBjb25zdCBzcmMgPSBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKCdwYWdlLWhvb2suanMnKTtcbiAgICBjb25zdCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtcbiAgICBzY3JpcHQuc3JjID0gc3JjO1xuICAgIHNjcmlwdC5hc3luYyA9IGZhbHNlO1xuICAgIHNjcmlwdC5kYXRhc2V0LmltbUFyY2hpdmUgPSAnMSc7XG4gICAgKGRvY3VtZW50LmhlYWQgfHwgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICAgIHNjcmlwdC5vbmxvYWQgPSAoKSA9PiBzY3JpcHQucmVtb3ZlKCk7XG4gICAgc2NyaXB0Lm9uZXJyb3IgPSAoKSA9PiB7XG4gICAgICAvLyBDU1AgcHJvYmFibHkgYmxvY2tlZCB0aGlzLiBOb3QgZmF0YWwgXHUyMDE0IHRoZSBNQUlOLXdvcmxkIGNvbnRlbnQgc2NyaXB0XG4gICAgICAvLyBkZWNsYXJlZCBpbiBtYW5pZmVzdC5qc29uIGlzIHRoZSBwcmltYXJ5IHBhdGguIFN1cmZhY2UgYXMgYSBsb2cgc29cbiAgICAgIC8vIHdlIGtub3cgd2hhdCBoYXBwZW5lZCB3aXRob3V0IGx5aW5nIGFib3V0IHN1Y2Nlc3MuXG4gICAgICBicm93c2VyLnJ1bnRpbWVcbiAgICAgICAgLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgICB0eXBlOiAnbG9nLWNvbnRlbnQtZXZlbnQnLFxuICAgICAgICAgIGxldmVsOiAnd2FybicsXG4gICAgICAgICAgbXNnOiAnaW5saW5lIHBhZ2UtaG9vayBpbmplY3Rpb24gYmxvY2tlZCAoQ1NQKTsgcmVseWluZyBvbiBNQUlOLXdvcmxkIGNvbnRlbnQgc2NyaXB0JyxcbiAgICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWYsXG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7fSk7XG4gICAgfTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGlubGluZSBwYWdlLWhvb2sgaW5qZWN0aW9uIHRocmV3JywgZXJyKTtcbiAgfVxufVxuXG5mYWxsYmFja0luamVjdCgpO1xuXG5mdW5jdGlvbiBub3JtYWxpemVIYW5kbGUocmF3OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICghcmF3KSByZXR1cm4gbnVsbDtcbiAgY29uc3QgY2xlYW5lZCA9IHJhdy50cmltKCkucmVwbGFjZSgvXkAvLCAnJykudG9Mb3dlckNhc2UoKTtcbiAgcmV0dXJuIGNsZWFuZWQubGVuZ3RoID4gMCA/IGNsZWFuZWQgOiBudWxsO1xufVxuXG5jb25zdCBTVEFUVVNfSE9TVFMgPSBuZXcgU2V0KFsneC5jb20nLCAndHdpdHRlci5jb20nLCAnbW9iaWxlLnR3aXR0ZXIuY29tJ10pO1xuXG5mdW5jdGlvbiBwYXJzZVR3ZWV0VXJsKGhyZWY6IHN0cmluZyB8IG51bGwpOiB7IGhhbmRsZTogc3RyaW5nOyBpZDogc3RyaW5nIH0gfCBudWxsIHtcbiAgaWYgKCFocmVmKSByZXR1cm4gbnVsbDtcbiAgdHJ5IHtcbiAgICBjb25zdCB1ID0gbmV3IFVSTChocmVmLCBsb2NhdGlvbi5ocmVmKTtcbiAgICBpZiAoIVNUQVRVU19IT1NUUy5oYXModS5ob3N0bmFtZS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgcGFydHMgPSB1LnBhdGhuYW1lLnNwbGl0KCcvJykuZmlsdGVyKEJvb2xlYW4pO1xuICAgIGNvbnN0IHN0YXR1c0lkeCA9IHBhcnRzLmluZGV4T2YoJ3N0YXR1cycpO1xuICAgIGlmIChzdGF0dXNJZHggPD0gMCkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgaGFuZGxlID0gbm9ybWFsaXplSGFuZGxlKHBhcnRzW3N0YXR1c0lkeCAtIDFdID8/IG51bGwpO1xuICAgIGNvbnN0IGlkID0gcGFydHNbc3RhdHVzSWR4ICsgMV0gPz8gbnVsbDtcbiAgICBpZiAoIWhhbmRsZSB8fCAhaWQgfHwgIS9eXFxkKyQvLnRlc3QoaWQpKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4geyBoYW5kbGUsIGlkIH07XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBhcnNlSGFuZGxlVXJsKGhyZWY6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKCFocmVmKSByZXR1cm4gbnVsbDtcbiAgdHJ5IHtcbiAgICBjb25zdCB1ID0gbmV3IFVSTChocmVmLCBsb2NhdGlvbi5ocmVmKTtcbiAgICBpZiAoIVNUQVRVU19IT1NUUy5oYXModS5ob3N0bmFtZS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgZmlyc3QgPSB1LnBhdGhuYW1lLnNwbGl0KCcvJykuZmlsdGVyKEJvb2xlYW4pWzBdO1xuICAgIGlmICghZmlyc3QgfHwgZmlyc3QgPT09ICdpJyB8fCBmaXJzdCA9PT0gJ2ludGVudCcgfHwgZmlyc3QgPT09ICdzZWFyY2gnKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gbm9ybWFsaXplSGFuZGxlKGZpcnN0KTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gaXNWaXNpYmxlKGVsOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgaWYgKHJlY3Qud2lkdGggPT09IDAgfHwgcmVjdC5oZWlnaHQgPT09IDApIHJldHVybiBmYWxzZTtcbiAgY29uc3Qgc3R5bGUgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbCk7XG4gIHJldHVybiBzdHlsZS52aXNpYmlsaXR5ICE9PSAnaGlkZGVuJyAmJiBzdHlsZS5kaXNwbGF5ICE9PSAnbm9uZSc7XG59XG5cbmZ1bmN0aW9uIG5lYXJlc3RUd2VldENvbnRhaW5lcihlbDogRWxlbWVudCk6IEVsZW1lbnQgfCBudWxsIHtcbiAgcmV0dXJuIGVsLmNsb3Nlc3QoJ2FydGljbGUnKSA/PyBlbC5jbG9zZXN0KCdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0nKTtcbn1cblxuZnVuY3Rpb24gaXNSZXBseVRvQ29yZShjb250YWluZXI6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgY29uc3QgdGV4dCA9IChjb250YWluZXIudGV4dENvbnRlbnQgfHwgJycpLnRvTG93ZXJDYXNlKCk7XG4gIGlmICghdGV4dC5pbmNsdWRlcygncmVwbHlpbmcgdG8nKSkgcmV0dXJuIGZhbHNlO1xuICBmb3IgKGNvbnN0IGxpbmsgb2YgQXJyYXkuZnJvbShjb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnYVtocmVmXScpKSkge1xuICAgIGNvbnN0IGhhbmRsZSA9IHBhcnNlSGFuZGxlVXJsKGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJykpO1xuICAgIGlmIChoYW5kbGUgJiYgdW5mb2xkQ29yZUhhbmRsZXMuaGFzKGhhbmRsZSkpIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuZnVuY3Rpb24gaXNDb3JlUmVsZXZhbnQoY29udGFpbmVyOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGZvciAoY29uc3QgbGluayBvZiBBcnJheS5mcm9tKGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCdhW2hyZWZdJykpKSB7XG4gICAgY29uc3QgdHdlZXQgPSBwYXJzZVR3ZWV0VXJsKGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJykpO1xuICAgIGlmICghdHdlZXQpIGNvbnRpbnVlO1xuICAgIGlmICh1bmZvbGRDb3JlSGFuZGxlcy5oYXModHdlZXQuaGFuZGxlKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKHVuZm9sZFJlbGV2YW50VHdlZXRJZHMuaGFzKHR3ZWV0LmlkKSkgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGlzUmVwbHlUb0NvcmUoY29udGFpbmVyKTtcbn1cblxuZnVuY3Rpb24gc2NhbkFuZFVuZm9sZFNob3dNb3JlKCk6IHZvaWQge1xuICB1bmZvbGRTY2FuVGltZXIgPSBudWxsO1xuICBpZiAoIXVuZm9sZEVuYWJsZWQgfHwgdW5mb2xkQ29yZUhhbmRsZXMuc2l6ZSA9PT0gMCkgcmV0dXJuO1xuICBjb25zdCBzZWxlY3RvcnMgPSBbXG4gICAgJ1tkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxuICAgICdidXR0b25bZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcbiAgICAnYXJ0aWNsZSBbcm9sZT1cImJ1dHRvblwiXVt0YWJpbmRleD1cIjBcIl0nLFxuICAgICdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0gW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcbiAgXTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8RWxlbWVudD4oKTtcbiAgbGV0IGNsaWNrZWQgPSAwO1xuICBmb3IgKGNvbnN0IHNlbCBvZiBzZWxlY3RvcnMpIHtcbiAgICBmb3IgKGNvbnN0IGVsIG9mIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWwpKSkge1xuICAgICAgaWYgKHNlZW4uaGFzKGVsKSB8fCB1bmZvbGRlZENvbnRyb2xzLmhhcyhlbCkpIGNvbnRpbnVlO1xuICAgICAgc2Vlbi5hZGQoZWwpO1xuICAgICAgaWYgKChlbC50ZXh0Q29udGVudCB8fCAnJykudHJpbSgpLnRvTG93ZXJDYXNlKCkgIT09ICdzaG93IG1vcmUnKSBjb250aW51ZTtcbiAgICAgIGlmICghaXNWaXNpYmxlKGVsKSkgY29udGludWU7XG4gICAgICBjb25zdCBjb250YWluZXIgPSBuZWFyZXN0VHdlZXRDb250YWluZXIoZWwpO1xuICAgICAgaWYgKCFjb250YWluZXIgfHwgIWlzQ29yZVJlbGV2YW50KGNvbnRhaW5lcikpIGNvbnRpbnVlO1xuICAgICAgdW5mb2xkZWRDb250cm9scy5hZGQoZWwpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgICAgICBjbGlja2VkICs9IDE7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gSWdub3JlIHN0YWxlIG9yIHN5bnRoZXRpYyBjb250cm9scy5cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGNsaWNrZWQgPiAwKSB7XG4gICAgYnJvd3Nlci5ydW50aW1lXG4gICAgICAuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc2hvdy1tb3JlLXVuZm9sZGVkJywgY291bnQ6IGNsaWNrZWQgfSlcbiAgICAgIC5jYXRjaCgoKSA9PiB7fSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc2NoZWR1bGVVbmZvbGRTY2FuKGRlbGF5ID0gVU5GT0xEX1NDQU5fREVCT1VOQ0VfTVMpOiB2b2lkIHtcbiAgaWYgKHVuZm9sZFNjYW5UaW1lciAhPT0gbnVsbCkgcmV0dXJuO1xuICB1bmZvbGRTY2FuVGltZXIgPSBzZXRUaW1lb3V0KHNjYW5BbmRVbmZvbGRTaG93TW9yZSwgZGVsYXkpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoVW5mb2xkVGFyZ2V0cygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7XG4gICAgICB0eXBlOiAnZ2V0LXVuZm9sZC10YXJnZXRzJyxcbiAgICB9KTtcbiAgICBjb25zdCByYXcgPVxuICAgICAgcmVzcG9uc2UgJiYgdHlwZW9mIHJlc3BvbnNlID09PSAnb2JqZWN0JyA/IChyZXNwb25zZSBhcyBVbmZvbGRUYXJnZXRzUmVzcG9uc2UpIDoge307XG4gICAgdW5mb2xkRW5hYmxlZCA9IHJhdy5lbmFibGVkICE9PSBmYWxzZTtcbiAgICB1bmZvbGRDb3JlSGFuZGxlcyA9IG5ldyBTZXQoXG4gICAgICAocmF3LmNvcmVIYW5kbGVzID8/IFtdKS5tYXAoKGgpID0+IGgudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9eQC8sICcnKSlcbiAgICApO1xuICAgIHVuZm9sZFJlbGV2YW50VHdlZXRJZHMgPSBuZXcgU2V0KHJhdy5yZWxldmFudFR3ZWV0SWRzID8/IFtdKTtcbiAgICBzY2hlZHVsZVVuZm9sZFNjYW4oMCk7XG4gIH0gY2F0Y2gge1xuICAgIHVuZm9sZEVuYWJsZWQgPSBmYWxzZTtcbiAgfVxufVxuXG5mdW5jdGlvbiBpbnN0YWxsVW5mb2xkT2JzZXJ2ZXIoKTogdm9pZCB7XG4gIGNvbnN0IHJvb3QgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQgfHwgZG9jdW1lbnQuYm9keTtcbiAgaWYgKCFyb290KSB7XG4gICAgc2V0VGltZW91dChpbnN0YWxsVW5mb2xkT2JzZXJ2ZXIsIDEwMCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4gc2NoZWR1bGVVbmZvbGRTY2FuKCkpO1xuICBvYnNlcnZlci5vYnNlcnZlKHJvb3QsIHsgY2hpbGRMaXN0OiB0cnVlLCBzdWJ0cmVlOiB0cnVlIH0pO1xuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgKCkgPT4gc2NoZWR1bGVVbmZvbGRTY2FuKCksIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgdm9pZCByZWZyZXNoVW5mb2xkVGFyZ2V0cygpO1xuICBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgdm9pZCByZWZyZXNoVW5mb2xkVGFyZ2V0cygpO1xuICB9LCBVTkZPTERfU1lOQ19NUyk7XG59XG5cbmluc3RhbGxVbmZvbGRPYnNlcnZlcigpO1xuXG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbWVzc2FnZScsIChldmVudDogTWVzc2FnZUV2ZW50KSA9PiB7XG4gIGlmIChldmVudC5zb3VyY2UgIT09IHdpbmRvdykgcmV0dXJuO1xuICBjb25zdCBkYXRhID0gZXZlbnQuZGF0YSBhcyB1bmtub3duO1xuICBpZiAoIWRhdGEgfHwgdHlwZW9mIGRhdGEgIT09ICdvYmplY3QnKSByZXR1cm47XG4gIGNvbnN0IGQgPSBkYXRhIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuXG4gIGlmIChkLnNvdXJjZSA9PT0gUkVBRFkpIHtcbiAgICBicm93c2VyLnJ1bnRpbWVcbiAgICAgIC5zZW5kTWVzc2FnZSh7XG4gICAgICAgIHR5cGU6ICdwYWdlLWhvb2stYWN0aXZlJyxcbiAgICAgICAgdXJsOiB0eXBlb2YgZC51cmwgPT09ICdzdHJpbmcnID8gZC51cmwgOiBsb2NhdGlvbi5ocmVmLFxuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoKSA9PiB7fSk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGQuc291cmNlICE9PSBUQVJHRVQpIHJldHVybjtcbiAgY29uc3QgZW5kcG9pbnQgPSB0eXBlb2YgZC5lbmRwb2ludCA9PT0gJ3N0cmluZycgPyBkLmVuZHBvaW50IDogbnVsbDtcbiAgY29uc3QgdXJsID0gdHlwZW9mIGQudXJsID09PSAnc3RyaW5nJyA/IGQudXJsIDogbnVsbDtcbiAgY29uc3QgcGFnZVVybCA9IHR5cGVvZiBkLnBhZ2VfdXJsID09PSAnc3RyaW5nJyA/IGQucGFnZV91cmwgOiBsb2NhdGlvbi5ocmVmO1xuICBjb25zdCByZXNwb25zZSA9IGQucmVzcG9uc2U7XG4gIGlmICghZW5kcG9pbnQgfHwgIXVybCB8fCByZXNwb25zZSA9PT0gdW5kZWZpbmVkKSByZXR1cm47XG4gIGJyb3dzZXIucnVudGltZVxuICAgIC5zZW5kTWVzc2FnZSh7IHR5cGU6ICdncmFwaHFsLWNhcHR1cmUnLCBlbmRwb2ludCwgdXJsLCBwYWdlVXJsLCByZXNwb25zZSB9KVxuICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gc2VuZE1lc3NhZ2UgZmFpbGVkJywgZXJyKTtcbiAgICB9KTtcbn0pO1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBc0JBLE1BQU0sU0FBUztBQUNmLE1BQU0sUUFBUTtBQUNkLE1BQU0saUJBQWlCO0FBQ3ZCLE1BQU0sMEJBQTBCO0FBUWhDLE1BQUksZ0JBQWdCO0FBQ3BCLE1BQUksb0JBQW9CLG9CQUFJLElBQVk7QUFDeEMsTUFBSSx5QkFBeUIsb0JBQUksSUFBWTtBQUM3QyxNQUFJLGtCQUF3RDtBQUM1RCxNQUFNLG1CQUFtQixvQkFBSSxRQUFpQjtBQUU5QyxPQUFLLFFBQVEsUUFDVixZQUFZLEVBQUUsTUFBTSxpQkFBaUIsS0FBSyxTQUFTLEtBQUssQ0FBQyxFQUN6RCxNQUFNLENBQUMsUUFBaUI7QUFDdkIsWUFBUSxLQUFLLDJDQUEyQyxHQUFHO0FBQUEsRUFDN0QsQ0FBQztBQUVILFdBQVMsaUJBQXVCO0FBQzlCLFFBQUk7QUFDRixZQUFNLE1BQU0sUUFBUSxRQUFRLE9BQU8sY0FBYztBQUNqRCxZQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7QUFDOUMsYUFBTyxNQUFNO0FBQ2IsYUFBTyxRQUFRO0FBQ2YsYUFBTyxRQUFRLGFBQWE7QUFDNUIsT0FBQyxTQUFTLFFBQVEsU0FBUyxpQkFBaUIsWUFBWSxNQUFNO0FBQzlELGFBQU8sU0FBUyxNQUFNLE9BQU8sT0FBTztBQUNwQyxhQUFPLFVBQVUsTUFBTTtBQUlyQixnQkFBUSxRQUNMLFlBQVk7QUFBQSxVQUNYLE1BQU07QUFBQSxVQUNOLE9BQU87QUFBQSxVQUNQLEtBQUs7QUFBQSxVQUNMLEtBQUssU0FBUztBQUFBLFFBQ2hCLENBQUMsRUFDQSxNQUFNLE1BQU07QUFBQSxRQUFDLENBQUM7QUFBQSxNQUNuQjtBQUFBLElBQ0YsU0FBUyxLQUFLO0FBQ1osY0FBUSxLQUFLLGtEQUFrRCxHQUFHO0FBQUEsSUFDcEU7QUFBQSxFQUNGO0FBRUEsaUJBQWU7QUFFZixXQUFTLGdCQUFnQixLQUFtQztBQUMxRCxRQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLFVBQU0sVUFBVSxJQUFJLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxFQUFFLFlBQVk7QUFDekQsV0FBTyxRQUFRLFNBQVMsSUFBSSxVQUFVO0FBQUEsRUFDeEM7QUFFQSxNQUFNLGVBQWUsb0JBQUksSUFBSSxDQUFDLFNBQVMsZUFBZSxvQkFBb0IsQ0FBQztBQUUzRSxXQUFTLGNBQWMsTUFBNEQ7QUFDakYsUUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixRQUFJO0FBQ0YsWUFBTSxJQUFJLElBQUksSUFBSSxNQUFNLFNBQVMsSUFBSTtBQUNyQyxVQUFJLENBQUMsYUFBYSxJQUFJLEVBQUUsU0FBUyxZQUFZLENBQUMsRUFBRyxRQUFPO0FBQ3hELFlBQU0sUUFBUSxFQUFFLFNBQVMsTUFBTSxHQUFHLEVBQUUsT0FBTyxPQUFPO0FBQ2xELFlBQU0sWUFBWSxNQUFNLFFBQVEsUUFBUTtBQUN4QyxVQUFJLGFBQWEsRUFBRyxRQUFPO0FBQzNCLFlBQU0sU0FBUyxnQkFBZ0IsTUFBTSxZQUFZLENBQUMsS0FBSyxJQUFJO0FBQzNELFlBQU0sS0FBSyxNQUFNLFlBQVksQ0FBQyxLQUFLO0FBQ25DLFVBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxFQUFFLEVBQUcsUUFBTztBQUNoRCxhQUFPLEVBQUUsUUFBUSxHQUFHO0FBQUEsSUFDdEIsUUFBUTtBQUNOLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFdBQVMsZUFBZSxNQUFvQztBQUMxRCxRQUFJLENBQUMsS0FBTSxRQUFPO0FBQ2xCLFFBQUk7QUFDRixZQUFNLElBQUksSUFBSSxJQUFJLE1BQU0sU0FBUyxJQUFJO0FBQ3JDLFVBQUksQ0FBQyxhQUFhLElBQUksRUFBRSxTQUFTLFlBQVksQ0FBQyxFQUFHLFFBQU87QUFDeEQsWUFBTSxRQUFRLEVBQUUsU0FBUyxNQUFNLEdBQUcsRUFBRSxPQUFPLE9BQU8sRUFBRSxDQUFDO0FBQ3JELFVBQUksQ0FBQyxTQUFTLFVBQVUsT0FBTyxVQUFVLFlBQVksVUFBVSxTQUFVLFFBQU87QUFDaEYsYUFBTyxnQkFBZ0IsS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLFVBQVUsSUFBc0I7QUFDdkMsVUFBTSxPQUFPLEdBQUcsc0JBQXNCO0FBQ3RDLFFBQUksS0FBSyxVQUFVLEtBQUssS0FBSyxXQUFXLEVBQUcsUUFBTztBQUNsRCxVQUFNLFFBQVEsT0FBTyxpQkFBaUIsRUFBRTtBQUN4QyxXQUFPLE1BQU0sZUFBZSxZQUFZLE1BQU0sWUFBWTtBQUFBLEVBQzVEO0FBRUEsV0FBUyxzQkFBc0IsSUFBNkI7QUFDMUQsV0FBTyxHQUFHLFFBQVEsU0FBUyxLQUFLLEdBQUcsUUFBUSxpQ0FBaUM7QUFBQSxFQUM5RTtBQUVBLFdBQVMsY0FBYyxXQUE2QjtBQUNsRCxVQUFNLFFBQVEsVUFBVSxlQUFlLElBQUksWUFBWTtBQUN2RCxRQUFJLENBQUMsS0FBSyxTQUFTLGFBQWEsRUFBRyxRQUFPO0FBQzFDLGVBQVcsUUFBUSxNQUFNLEtBQUssVUFBVSxpQkFBaUIsU0FBUyxDQUFDLEdBQUc7QUFDcEUsWUFBTSxTQUFTLGVBQWUsS0FBSyxhQUFhLE1BQU0sQ0FBQztBQUN2RCxVQUFJLFVBQVUsa0JBQWtCLElBQUksTUFBTSxFQUFHLFFBQU87QUFBQSxJQUN0RDtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsV0FBUyxlQUFlLFdBQTZCO0FBQ25ELGVBQVcsUUFBUSxNQUFNLEtBQUssVUFBVSxpQkFBaUIsU0FBUyxDQUFDLEdBQUc7QUFDcEUsWUFBTSxRQUFRLGNBQWMsS0FBSyxhQUFhLE1BQU0sQ0FBQztBQUNyRCxVQUFJLENBQUMsTUFBTztBQUNaLFVBQUksa0JBQWtCLElBQUksTUFBTSxNQUFNLEVBQUcsUUFBTztBQUNoRCxVQUFJLHVCQUF1QixJQUFJLE1BQU0sRUFBRSxFQUFHLFFBQU87QUFBQSxJQUNuRDtBQUNBLFdBQU8sY0FBYyxTQUFTO0FBQUEsRUFDaEM7QUFFQSxXQUFTLHdCQUE4QjtBQUNyQyxzQkFBa0I7QUFDbEIsUUFBSSxDQUFDLGlCQUFpQixrQkFBa0IsU0FBUyxFQUFHO0FBQ3BELFVBQU0sWUFBWTtBQUFBLE1BQ2hCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFVBQU0sT0FBTyxvQkFBSSxJQUFhO0FBQzlCLFFBQUksVUFBVTtBQUNkLGVBQVcsT0FBTyxXQUFXO0FBQzNCLGlCQUFXLE1BQU0sTUFBTSxLQUFLLFNBQVMsaUJBQWlCLEdBQUcsQ0FBQyxHQUFHO0FBQzNELFlBQUksS0FBSyxJQUFJLEVBQUUsS0FBSyxpQkFBaUIsSUFBSSxFQUFFLEVBQUc7QUFDOUMsYUFBSyxJQUFJLEVBQUU7QUFDWCxhQUFLLEdBQUcsZUFBZSxJQUFJLEtBQUssRUFBRSxZQUFZLE1BQU0sWUFBYTtBQUNqRSxZQUFJLENBQUMsVUFBVSxFQUFFLEVBQUc7QUFDcEIsY0FBTSxZQUFZLHNCQUFzQixFQUFFO0FBQzFDLFlBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxTQUFTLEVBQUc7QUFDOUMseUJBQWlCLElBQUksRUFBRTtBQUN2QixZQUFJO0FBQ0YsVUFBQyxHQUFtQixNQUFNO0FBQzFCLHFCQUFXO0FBQUEsUUFDYixRQUFRO0FBQUEsUUFFUjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxVQUFVLEdBQUc7QUFDZixjQUFRLFFBQ0wsWUFBWSxFQUFFLE1BQU0sc0JBQXNCLE9BQU8sUUFBUSxDQUFDLEVBQzFELE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUVBLFdBQVMsbUJBQW1CLFFBQVEseUJBQStCO0FBQ2pFLFFBQUksb0JBQW9CLEtBQU07QUFDOUIsc0JBQWtCLFdBQVcsdUJBQXVCLEtBQUs7QUFBQSxFQUMzRDtBQUVBLGlCQUFlLHVCQUFzQztBQUNuRCxRQUFJO0FBQ0YsWUFBTSxXQUFXLE1BQU0sUUFBUSxRQUFRLFlBQVk7QUFBQSxRQUNqRCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0QsWUFBTSxNQUNKLFlBQVksT0FBTyxhQUFhLFdBQVksV0FBcUMsQ0FBQztBQUNwRixzQkFBZ0IsSUFBSSxZQUFZO0FBQ2hDLDBCQUFvQixJQUFJO0FBQUEsU0FDckIsSUFBSSxlQUFlLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksRUFBRSxRQUFRLE1BQU0sRUFBRSxDQUFDO0FBQUEsTUFDdEU7QUFDQSwrQkFBeUIsSUFBSSxJQUFJLElBQUksb0JBQW9CLENBQUMsQ0FBQztBQUMzRCx5QkFBbUIsQ0FBQztBQUFBLElBQ3RCLFFBQVE7QUFDTixzQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLHdCQUE4QjtBQUNyQyxVQUFNLE9BQU8sU0FBUyxtQkFBbUIsU0FBUztBQUNsRCxRQUFJLENBQUMsTUFBTTtBQUNULGlCQUFXLHVCQUF1QixHQUFHO0FBQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sV0FBVyxJQUFJLGlCQUFpQixNQUFNLG1CQUFtQixDQUFDO0FBQ2hFLGFBQVMsUUFBUSxNQUFNLEVBQUUsV0FBVyxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBQ3pELFdBQU8saUJBQWlCLFVBQVUsTUFBTSxtQkFBbUIsR0FBRyxFQUFFLFNBQVMsS0FBSyxDQUFDO0FBQy9FLFNBQUsscUJBQXFCO0FBQzFCLGdCQUFZLE1BQU07QUFDaEIsV0FBSyxxQkFBcUI7QUFBQSxJQUM1QixHQUFHLGNBQWM7QUFBQSxFQUNuQjtBQUVBLHdCQUFzQjtBQUV0QixTQUFPLGlCQUFpQixXQUFXLENBQUMsVUFBd0I7QUFDMUQsUUFBSSxNQUFNLFdBQVcsT0FBUTtBQUM3QixVQUFNLE9BQU8sTUFBTTtBQUNuQixRQUFJLENBQUMsUUFBUSxPQUFPLFNBQVMsU0FBVTtBQUN2QyxVQUFNLElBQUk7QUFFVixRQUFJLEVBQUUsV0FBVyxPQUFPO0FBQ3RCLGNBQVEsUUFDTCxZQUFZO0FBQUEsUUFDWCxNQUFNO0FBQUEsUUFDTixLQUFLLE9BQU8sRUFBRSxRQUFRLFdBQVcsRUFBRSxNQUFNLFNBQVM7QUFBQSxNQUNwRCxDQUFDLEVBQ0EsTUFBTSxNQUFNO0FBQUEsTUFBQyxDQUFDO0FBQ2pCO0FBQUEsSUFDRjtBQUVBLFFBQUksRUFBRSxXQUFXLE9BQVE7QUFDekIsVUFBTSxXQUFXLE9BQU8sRUFBRSxhQUFhLFdBQVcsRUFBRSxXQUFXO0FBQy9ELFVBQU0sTUFBTSxPQUFPLEVBQUUsUUFBUSxXQUFXLEVBQUUsTUFBTTtBQUNoRCxVQUFNLFVBQVUsT0FBTyxFQUFFLGFBQWEsV0FBVyxFQUFFLFdBQVcsU0FBUztBQUN2RSxVQUFNLFdBQVcsRUFBRTtBQUNuQixRQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sYUFBYSxPQUFXO0FBQ2pELFlBQVEsUUFDTCxZQUFZLEVBQUUsTUFBTSxtQkFBbUIsVUFBVSxLQUFLLFNBQVMsU0FBUyxDQUFDLEVBQ3pFLE1BQU0sQ0FBQyxRQUFRO0FBQ2QsY0FBUSxLQUFLLG9DQUFvQyxHQUFHO0FBQUEsSUFDdEQsQ0FBQztBQUFBLEVBQ0wsQ0FBQzsiLAogICJuYW1lcyI6IFtdCn0K
