"use strict";
(() => {
  // extension/src/content.ts
  var TARGET = "IMM_ARCHIVE_CAPTURE";
  var READY = "IMM_ARCHIVE_HOOK_READY";
  var UNFOLD_SYNC_MS = 2e3;
  var UNFOLD_SCAN_DEBOUNCE_MS = 250;
  var unfoldEnabled = false;
  var unfoldCoreHandles = /* @__PURE__ */ new Set();
  var unfoldRelevantTweetIds = /* @__PURE__ */ new Set();
  var unfoldScanTimer = null;
  var unfoldedControls = /* @__PURE__ */ new WeakSet();
  void browser.runtime.sendMessage({ type: "content-alive", url: location.href }).catch((err) => {
    console.warn("[imm-archive] content-alive ping failed", err);
  });
  function fallbackInject() {
    try {
      const src = browser.runtime.getURL("page-hook.js");
      const script = document.createElement("script");
      script.src = src;
      script.async = false;
      script.dataset.immArchive = "1";
      (document.head || document.documentElement).appendChild(script);
      script.onload = () => script.remove();
      script.onerror = () => {
        browser.runtime.sendMessage({
          type: "log-content-event",
          level: "warn",
          msg: "inline page-hook injection blocked (CSP); relying on MAIN-world content script",
          url: location.href
        }).catch(() => {
        });
      };
    } catch (err) {
      console.warn("[imm-archive] inline page-hook injection threw", err);
    }
  }
  fallbackInject();
  function normalizeHandle(raw) {
    if (!raw) return null;
    const cleaned = raw.trim().replace(/^@/, "").toLowerCase();
    return cleaned.length > 0 ? cleaned : null;
  }
  var STATUS_HOSTS = /* @__PURE__ */ new Set(["x.com", "twitter.com", "mobile.twitter.com"]);
  function parseTweetUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const parts = u.pathname.split("/").filter(Boolean);
      const statusIdx = parts.indexOf("status");
      if (statusIdx <= 0) return null;
      const handle = normalizeHandle(parts[statusIdx - 1] ?? null);
      const id = parts[statusIdx + 1] ?? null;
      if (!handle || !id || !/^\d+$/.test(id)) return null;
      return { handle, id };
    } catch {
      return null;
    }
  }
  function parseHandleUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const first = u.pathname.split("/").filter(Boolean)[0];
      if (!first || first === "i" || first === "intent" || first === "search") return null;
      return normalizeHandle(first);
    } catch {
      return null;
    }
  }
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none";
  }
  function nearestTweetContainer(el) {
    return el.closest("article") ?? el.closest('div[data-testid="cellInnerDiv"]');
  }
  function isReplyToCore(container) {
    const text = (container.textContent || "").toLowerCase();
    if (!text.includes("replying to")) return false;
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const handle = parseHandleUrl(link.getAttribute("href"));
      if (handle && unfoldCoreHandles.has(handle)) return true;
    }
    return false;
  }
  function isCoreRelevant(container) {
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const tweet = parseTweetUrl(link.getAttribute("href"));
      if (!tweet) continue;
      if (unfoldCoreHandles.has(tweet.handle)) return true;
      if (unfoldRelevantTweetIds.has(tweet.id)) return true;
    }
    return isReplyToCore(container);
  }
  function scanAndUnfoldShowMore() {
    unfoldScanTimer = null;
    if (!unfoldEnabled || unfoldCoreHandles.size === 0) return;
    const selectors = [
      '[data-testid="tweet-text-show-more-link"]',
      'button[data-testid="tweet-text-show-more-link"]',
      'article [role="button"][tabindex="0"]',
      'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
    ];
    const seen = /* @__PURE__ */ new Set();
    let clicked = 0;
    for (const sel of selectors) {
      for (const el of Array.from(document.querySelectorAll(sel))) {
        if (seen.has(el) || unfoldedControls.has(el)) continue;
        seen.add(el);
        if ((el.textContent || "").trim().toLowerCase() !== "show more") continue;
        if (!isVisible(el)) continue;
        const container = nearestTweetContainer(el);
        if (!container || !isCoreRelevant(container)) continue;
        unfoldedControls.add(el);
        try {
          el.click();
          clicked += 1;
        } catch {
        }
      }
    }
    if (clicked > 0) {
      browser.runtime.sendMessage({ type: "show-more-unfolded", count: clicked }).catch(() => {
      });
    }
  }
  function scheduleUnfoldScan(delay = UNFOLD_SCAN_DEBOUNCE_MS) {
    if (unfoldScanTimer !== null) return;
    unfoldScanTimer = setTimeout(scanAndUnfoldShowMore, delay);
  }
  async function refreshUnfoldTargets() {
    try {
      const response = await browser.runtime.sendMessage({
        type: "get-unfold-targets"
      });
      const raw = response && typeof response === "object" ? response : {};
      unfoldEnabled = raw.enabled !== false;
      unfoldCoreHandles = new Set(
        (raw.coreHandles ?? []).map((h) => h.toLowerCase().replace(/^@/, ""))
      );
      unfoldRelevantTweetIds = new Set(raw.relevantTweetIds ?? []);
      scheduleUnfoldScan(0);
    } catch {
      unfoldEnabled = false;
    }
  }
  function installUnfoldObserver() {
    const root = document.documentElement || document.body;
    if (!root) {
      setTimeout(installUnfoldObserver, 100);
      return;
    }
    const observer = new MutationObserver(() => scheduleUnfoldScan());
    observer.observe(root, { childList: true, subtree: true });
    window.addEventListener("scroll", () => scheduleUnfoldScan(), { passive: true });
    void refreshUnfoldTargets();
    setInterval(() => {
      void refreshUnfoldTargets();
    }, UNFOLD_SYNC_MS);
  }
  installUnfoldObserver();
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== "object") return;
    const d = data;
    if (d.source === READY) {
      browser.runtime.sendMessage({
        type: "page-hook-active",
        url: typeof d.url === "string" ? d.url : location.href
      }).catch(() => {
      });
      return;
    }
    if (d.source !== TARGET) return;
    const endpoint = typeof d.endpoint === "string" ? d.endpoint : null;
    const url = typeof d.url === "string" ? d.url : null;
    const pageUrl = typeof d.page_url === "string" ? d.page_url : location.href;
    const response = d.response;
    if (!endpoint || !url || response === void 0) return;
    browser.runtime.sendMessage({ type: "graphql-capture", endpoint, url, pageUrl, response }).catch((err) => {
      console.warn("[imm-archive] sendMessage failed", err);
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbnRlbnQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKlxuICogY29udGVudC50cyBcdTIwMTQgY29udGVudC1zY3JpcHQgY29udGV4dCAoaXNvbGF0ZWQgd29ybGQpLlxuICpcbiAqIFRoZSBhY3R1YWwgcGFnZS1ob29rICh3aGljaCBwYXRjaGVzIGBmZXRjaGAgLyBgWEhSYCkgaXMgZGVjbGFyZWQgYXMgYVxuICogc2VwYXJhdGUgY29udGVudCBzY3JpcHQgd2l0aCBgd29ybGQ6IFwiTUFJTlwiYCBpbiB0aGUgbWFuaWZlc3QsIHNvIGl0IHJ1bnNcbiAqIGluIHRoZSBwYWdlIHdvcmxkIGRpcmVjdGx5IHdpdGhvdXQgdXMgaGF2aW5nIHRvIGluamVjdCBhIDxzY3JpcHQ+IHRhZyBcdTIwMTRcbiAqIHdoaWNoIFgncyBub25jZS1iYXNlZCBDU1Agd291bGQgYmxvY2suXG4gKlxuICogVGhpcyBmaWxlIGRvZXMgdGhyZWUgdGhpbmdzOlxuICpcbiAqICAgMS4gUGluZ3MgdGhlIGJhY2tncm91bmQgb24gbG9hZCBzbyB0aGUgYWN0aXZpdHkgdGFpbCBjb25maXJtcyB0aGVcbiAqICAgICAgY29udGVudCBzY3JpcHQgcmVhY2hlZCB0aGUgWCBwYWdlICh1c2VmdWwgd2hlbiBkaWFnbm9zaW5nIGEgc2lsZW50XG4gKiAgICAgIFwiY2FwdHVyZS1ub3cgZG9lcyBub3RoaW5nXCIgZmFpbHVyZSkuXG4gKiAgIDIuIEFzIGEgZGVmZW5zaXZlIGZhbGxiYWNrLCBhbHNvIHRyaWVzIHRvIGluamVjdCBgcGFnZS1ob29rLmpzYCB2aWEgYVxuICogICAgICBzY3JpcHQgdGFnLiBIYXJtbGVzcyBvbiBtb2Rlcm4gRmlyZWZveCAodGhlIHBhZ2UtaG9vaydzIFRBRyBndWFyZFxuICogICAgICBwcmV2ZW50cyBkb3VibGUtaW5pdCk7IGNvdmVycyB0aGUgcmFyZSBjYXNlIHdoZXJlIHRoZSBNQUlOLXdvcmxkXG4gKiAgICAgIGNvbnRlbnQgc2NyaXB0IGVudHJ5IGlzbid0IGhvbm9yZWQuXG4gKiAgIDMuIEJyaWRnZXMgYHdpbmRvdy5wb3N0TWVzc2FnZWAgZnJvbSB0aGUgcGFnZSBob29rIHRvIHRoZSBiYWNrZ3JvdW5kOlxuICogICAgICBib3RoIHRoZSBgKl9SRUFEWWAgYm9vdCBwaW5nIGFuZCB0aGUgYElNTV9BUkNISVZFX0NBUFRVUkVgIHBheWxvYWRcbiAqICAgICAgZXZlbnRzLlxuICovXG5cbmNvbnN0IFRBUkdFVCA9ICdJTU1fQVJDSElWRV9DQVBUVVJFJztcbmNvbnN0IFJFQURZID0gJ0lNTV9BUkNISVZFX0hPT0tfUkVBRFknO1xuY29uc3QgVU5GT0xEX1NZTkNfTVMgPSAyXzAwMDtcbmNvbnN0IFVORk9MRF9TQ0FOX0RFQk9VTkNFX01TID0gMjUwO1xuXG5pbnRlcmZhY2UgVW5mb2xkVGFyZ2V0c1Jlc3BvbnNlIHtcbiAgZW5hYmxlZD86IGJvb2xlYW47XG4gIGNvcmVIYW5kbGVzPzogc3RyaW5nW107XG4gIHJlbGV2YW50VHdlZXRJZHM/OiBzdHJpbmdbXTtcbn1cblxubGV0IHVuZm9sZEVuYWJsZWQgPSBmYWxzZTtcbmxldCB1bmZvbGRDb3JlSGFuZGxlcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xubGV0IHVuZm9sZFJlbGV2YW50VHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbmxldCB1bmZvbGRTY2FuVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbCA9IG51bGw7XG5jb25zdCB1bmZvbGRlZENvbnRyb2xzID0gbmV3IFdlYWtTZXQ8RWxlbWVudD4oKTtcblxudm9pZCBicm93c2VyLnJ1bnRpbWVcbiAgLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2NvbnRlbnQtYWxpdmUnLCB1cmw6IGxvY2F0aW9uLmhyZWYgfSlcbiAgLmNhdGNoKChlcnI6IHVua25vd24pID0+IHtcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gY29udGVudC1hbGl2ZSBwaW5nIGZhaWxlZCcsIGVycik7XG4gIH0pO1xuXG5mdW5jdGlvbiBmYWxsYmFja0luamVjdCgpOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBjb25zdCBzcmMgPSBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKCdwYWdlLWhvb2suanMnKTtcbiAgICBjb25zdCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtcbiAgICBzY3JpcHQuc3JjID0gc3JjO1xuICAgIHNjcmlwdC5hc3luYyA9IGZhbHNlO1xuICAgIHNjcmlwdC5kYXRhc2V0LmltbUFyY2hpdmUgPSAnMSc7XG4gICAgKGRvY3VtZW50LmhlYWQgfHwgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICAgIHNjcmlwdC5vbmxvYWQgPSAoKSA9PiBzY3JpcHQucmVtb3ZlKCk7XG4gICAgc2NyaXB0Lm9uZXJyb3IgPSAoKSA9PiB7XG4gICAgICAvLyBDU1AgcHJvYmFibHkgYmxvY2tlZCB0aGlzLiBOb3QgZmF0YWwgXHUyMDE0IHRoZSBNQUlOLXdvcmxkIGNvbnRlbnQgc2NyaXB0XG4gICAgICAvLyBkZWNsYXJlZCBpbiBtYW5pZmVzdC5qc29uIGlzIHRoZSBwcmltYXJ5IHBhdGguIFN1cmZhY2UgYXMgYSBsb2cgc29cbiAgICAgIC8vIHdlIGtub3cgd2hhdCBoYXBwZW5lZCB3aXRob3V0IGx5aW5nIGFib3V0IHN1Y2Nlc3MuXG4gICAgICBicm93c2VyLnJ1bnRpbWVcbiAgICAgICAgLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgICB0eXBlOiAnbG9nLWNvbnRlbnQtZXZlbnQnLFxuICAgICAgICAgIGxldmVsOiAnd2FybicsXG4gICAgICAgICAgbXNnOiAnaW5saW5lIHBhZ2UtaG9vayBpbmplY3Rpb24gYmxvY2tlZCAoQ1NQKTsgcmVseWluZyBvbiBNQUlOLXdvcmxkIGNvbnRlbnQgc2NyaXB0JyxcbiAgICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWYsXG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7fSk7XG4gICAgfTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGlubGluZSBwYWdlLWhvb2sgaW5qZWN0aW9uIHRocmV3JywgZXJyKTtcbiAgfVxufVxuXG5mYWxsYmFja0luamVjdCgpO1xuXG5mdW5jdGlvbiBub3JtYWxpemVIYW5kbGUocmF3OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICghcmF3KSByZXR1cm4gbnVsbDtcbiAgY29uc3QgY2xlYW5lZCA9IHJhdy50cmltKCkucmVwbGFjZSgvXkAvLCAnJykudG9Mb3dlckNhc2UoKTtcbiAgcmV0dXJuIGNsZWFuZWQubGVuZ3RoID4gMCA/IGNsZWFuZWQgOiBudWxsO1xufVxuXG5jb25zdCBTVEFUVVNfSE9TVFMgPSBuZXcgU2V0KFsneC5jb20nLCAndHdpdHRlci5jb20nLCAnbW9iaWxlLnR3aXR0ZXIuY29tJ10pO1xuXG5mdW5jdGlvbiBwYXJzZVR3ZWV0VXJsKGhyZWY6IHN0cmluZyB8IG51bGwpOiB7IGhhbmRsZTogc3RyaW5nOyBpZDogc3RyaW5nIH0gfCBudWxsIHtcbiAgaWYgKCFocmVmKSByZXR1cm4gbnVsbDtcbiAgdHJ5IHtcbiAgICBjb25zdCB1ID0gbmV3IFVSTChocmVmLCBsb2NhdGlvbi5ocmVmKTtcbiAgICBpZiAoIVNUQVRVU19IT1NUUy5oYXModS5ob3N0bmFtZS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgcGFydHMgPSB1LnBhdGhuYW1lLnNwbGl0KCcvJykuZmlsdGVyKEJvb2xlYW4pO1xuICAgIGNvbnN0IHN0YXR1c0lkeCA9IHBhcnRzLmluZGV4T2YoJ3N0YXR1cycpO1xuICAgIGlmIChzdGF0dXNJZHggPD0gMCkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgaGFuZGxlID0gbm9ybWFsaXplSGFuZGxlKHBhcnRzW3N0YXR1c0lkeCAtIDFdID8/IG51bGwpO1xuICAgIGNvbnN0IGlkID0gcGFydHNbc3RhdHVzSWR4ICsgMV0gPz8gbnVsbDtcbiAgICBpZiAoIWhhbmRsZSB8fCAhaWQgfHwgIS9eXFxkKyQvLnRlc3QoaWQpKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4geyBoYW5kbGUsIGlkIH07XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBhcnNlSGFuZGxlVXJsKGhyZWY6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKCFocmVmKSByZXR1cm4gbnVsbDtcbiAgdHJ5IHtcbiAgICBjb25zdCB1ID0gbmV3IFVSTChocmVmLCBsb2NhdGlvbi5ocmVmKTtcbiAgICBpZiAoIVNUQVRVU19IT1NUUy5oYXModS5ob3N0bmFtZS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgZmlyc3QgPSB1LnBhdGhuYW1lLnNwbGl0KCcvJykuZmlsdGVyKEJvb2xlYW4pWzBdO1xuICAgIGlmICghZmlyc3QgfHwgZmlyc3QgPT09ICdpJyB8fCBmaXJzdCA9PT0gJ2ludGVudCcgfHwgZmlyc3QgPT09ICdzZWFyY2gnKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gbm9ybWFsaXplSGFuZGxlKGZpcnN0KTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gaXNWaXNpYmxlKGVsOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgaWYgKHJlY3Qud2lkdGggPT09IDAgfHwgcmVjdC5oZWlnaHQgPT09IDApIHJldHVybiBmYWxzZTtcbiAgY29uc3Qgc3R5bGUgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbCk7XG4gIHJldHVybiBzdHlsZS52aXNpYmlsaXR5ICE9PSAnaGlkZGVuJyAmJiBzdHlsZS5kaXNwbGF5ICE9PSAnbm9uZSc7XG59XG5cbmZ1bmN0aW9uIG5lYXJlc3RUd2VldENvbnRhaW5lcihlbDogRWxlbWVudCk6IEVsZW1lbnQgfCBudWxsIHtcbiAgcmV0dXJuIGVsLmNsb3Nlc3QoJ2FydGljbGUnKSA/PyBlbC5jbG9zZXN0KCdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0nKTtcbn1cblxuZnVuY3Rpb24gaXNSZXBseVRvQ29yZShjb250YWluZXI6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgY29uc3QgdGV4dCA9IChjb250YWluZXIudGV4dENvbnRlbnQgfHwgJycpLnRvTG93ZXJDYXNlKCk7XG4gIGlmICghdGV4dC5pbmNsdWRlcygncmVwbHlpbmcgdG8nKSkgcmV0dXJuIGZhbHNlO1xuICBmb3IgKGNvbnN0IGxpbmsgb2YgQXJyYXkuZnJvbShjb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnYVtocmVmXScpKSkge1xuICAgIGNvbnN0IGhhbmRsZSA9IHBhcnNlSGFuZGxlVXJsKGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJykpO1xuICAgIGlmIChoYW5kbGUgJiYgdW5mb2xkQ29yZUhhbmRsZXMuaGFzKGhhbmRsZSkpIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuZnVuY3Rpb24gaXNDb3JlUmVsZXZhbnQoY29udGFpbmVyOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGZvciAoY29uc3QgbGluayBvZiBBcnJheS5mcm9tKGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCdhW2hyZWZdJykpKSB7XG4gICAgY29uc3QgdHdlZXQgPSBwYXJzZVR3ZWV0VXJsKGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJykpO1xuICAgIGlmICghdHdlZXQpIGNvbnRpbnVlO1xuICAgIGlmICh1bmZvbGRDb3JlSGFuZGxlcy5oYXModHdlZXQuaGFuZGxlKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKHVuZm9sZFJlbGV2YW50VHdlZXRJZHMuaGFzKHR3ZWV0LmlkKSkgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGlzUmVwbHlUb0NvcmUoY29udGFpbmVyKTtcbn1cblxuZnVuY3Rpb24gc2NhbkFuZFVuZm9sZFNob3dNb3JlKCk6IHZvaWQge1xuICB1bmZvbGRTY2FuVGltZXIgPSBudWxsO1xuICBpZiAoIXVuZm9sZEVuYWJsZWQgfHwgdW5mb2xkQ29yZUhhbmRsZXMuc2l6ZSA9PT0gMCkgcmV0dXJuO1xuICBjb25zdCBzZWxlY3RvcnMgPSBbXG4gICAgJ1tkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxuICAgICdidXR0b25bZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcbiAgICAnYXJ0aWNsZSBbcm9sZT1cImJ1dHRvblwiXVt0YWJpbmRleD1cIjBcIl0nLFxuICAgICdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0gW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcbiAgXTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8RWxlbWVudD4oKTtcbiAgbGV0IGNsaWNrZWQgPSAwO1xuICBmb3IgKGNvbnN0IHNlbCBvZiBzZWxlY3RvcnMpIHtcbiAgICBmb3IgKGNvbnN0IGVsIG9mIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWwpKSkge1xuICAgICAgaWYgKHNlZW4uaGFzKGVsKSB8fCB1bmZvbGRlZENvbnRyb2xzLmhhcyhlbCkpIGNvbnRpbnVlO1xuICAgICAgc2Vlbi5hZGQoZWwpO1xuICAgICAgaWYgKChlbC50ZXh0Q29udGVudCB8fCAnJykudHJpbSgpLnRvTG93ZXJDYXNlKCkgIT09ICdzaG93IG1vcmUnKSBjb250aW51ZTtcbiAgICAgIGlmICghaXNWaXNpYmxlKGVsKSkgY29udGludWU7XG4gICAgICBjb25zdCBjb250YWluZXIgPSBuZWFyZXN0VHdlZXRDb250YWluZXIoZWwpO1xuICAgICAgaWYgKCFjb250YWluZXIgfHwgIWlzQ29yZVJlbGV2YW50KGNvbnRhaW5lcikpIGNvbnRpbnVlO1xuICAgICAgdW5mb2xkZWRDb250cm9scy5hZGQoZWwpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgICAgICBjbGlja2VkICs9IDE7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gSWdub3JlIHN0YWxlIG9yIHN5bnRoZXRpYyBjb250cm9scy5cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGNsaWNrZWQgPiAwKSB7XG4gICAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ3Nob3ctbW9yZS11bmZvbGRlZCcsIGNvdW50OiBjbGlja2VkIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzY2hlZHVsZVVuZm9sZFNjYW4oZGVsYXkgPSBVTkZPTERfU0NBTl9ERUJPVU5DRV9NUyk6IHZvaWQge1xuICBpZiAodW5mb2xkU2NhblRpbWVyICE9PSBudWxsKSByZXR1cm47XG4gIHVuZm9sZFNjYW5UaW1lciA9IHNldFRpbWVvdXQoc2NhbkFuZFVuZm9sZFNob3dNb3JlLCBkZWxheSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hVbmZvbGRUYXJnZXRzKCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgIHR5cGU6ICdnZXQtdW5mb2xkLXRhcmdldHMnLFxuICAgIH0pO1xuICAgIGNvbnN0IHJhdyA9IHJlc3BvbnNlICYmIHR5cGVvZiByZXNwb25zZSA9PT0gJ29iamVjdCcgPyAocmVzcG9uc2UgYXMgVW5mb2xkVGFyZ2V0c1Jlc3BvbnNlKSA6IHt9O1xuICAgIHVuZm9sZEVuYWJsZWQgPSByYXcuZW5hYmxlZCAhPT0gZmFsc2U7XG4gICAgdW5mb2xkQ29yZUhhbmRsZXMgPSBuZXcgU2V0KFxuICAgICAgKHJhdy5jb3JlSGFuZGxlcyA/PyBbXSkubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXkAvLCAnJykpXG4gICAgKTtcbiAgICB1bmZvbGRSZWxldmFudFR3ZWV0SWRzID0gbmV3IFNldChyYXcucmVsZXZhbnRUd2VldElkcyA/PyBbXSk7XG4gICAgc2NoZWR1bGVVbmZvbGRTY2FuKDApO1xuICB9IGNhdGNoIHtcbiAgICB1bmZvbGRFbmFibGVkID0gZmFsc2U7XG4gIH1cbn1cblxuZnVuY3Rpb24gaW5zdGFsbFVuZm9sZE9ic2VydmVyKCk6IHZvaWQge1xuICBjb25zdCByb290ID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50IHx8IGRvY3VtZW50LmJvZHk7XG4gIGlmICghcm9vdCkge1xuICAgIHNldFRpbWVvdXQoaW5zdGFsbFVuZm9sZE9ic2VydmVyLCAxMDApO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKCgpID0+IHNjaGVkdWxlVW5mb2xkU2NhbigpKTtcbiAgb2JzZXJ2ZXIub2JzZXJ2ZShyb290LCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsICgpID0+IHNjaGVkdWxlVW5mb2xkU2NhbigpLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gIHZvaWQgcmVmcmVzaFVuZm9sZFRhcmdldHMoKTtcbiAgc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgcmVmcmVzaFVuZm9sZFRhcmdldHMoKTtcbiAgfSwgVU5GT0xEX1NZTkNfTVMpO1xufVxuXG5pbnN0YWxsVW5mb2xkT2JzZXJ2ZXIoKTtcblxud2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCAoZXZlbnQ6IE1lc3NhZ2VFdmVudCkgPT4ge1xuICBpZiAoZXZlbnQuc291cmNlICE9PSB3aW5kb3cpIHJldHVybjtcbiAgY29uc3QgZGF0YSA9IGV2ZW50LmRhdGEgYXMgdW5rbm93bjtcbiAgaWYgKCFkYXRhIHx8IHR5cGVvZiBkYXRhICE9PSAnb2JqZWN0JykgcmV0dXJuO1xuICBjb25zdCBkID0gZGF0YSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcblxuICBpZiAoZC5zb3VyY2UgPT09IFJFQURZKSB7XG4gICAgYnJvd3Nlci5ydW50aW1lXG4gICAgICAuc2VuZE1lc3NhZ2Uoe1xuICAgICAgICB0eXBlOiAncGFnZS1ob29rLWFjdGl2ZScsXG4gICAgICAgIHVybDogdHlwZW9mIGQudXJsID09PSAnc3RyaW5nJyA/IGQudXJsIDogbG9jYXRpb24uaHJlZixcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKCkgPT4ge30pO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChkLnNvdXJjZSAhPT0gVEFSR0VUKSByZXR1cm47XG4gIGNvbnN0IGVuZHBvaW50ID0gdHlwZW9mIGQuZW5kcG9pbnQgPT09ICdzdHJpbmcnID8gZC5lbmRwb2ludCA6IG51bGw7XG4gIGNvbnN0IHVybCA9IHR5cGVvZiBkLnVybCA9PT0gJ3N0cmluZycgPyBkLnVybCA6IG51bGw7XG4gIGNvbnN0IHBhZ2VVcmwgPSB0eXBlb2YgZC5wYWdlX3VybCA9PT0gJ3N0cmluZycgPyBkLnBhZ2VfdXJsIDogbG9jYXRpb24uaHJlZjtcbiAgY29uc3QgcmVzcG9uc2UgPSBkLnJlc3BvbnNlO1xuICBpZiAoIWVuZHBvaW50IHx8ICF1cmwgfHwgcmVzcG9uc2UgPT09IHVuZGVmaW5lZCkgcmV0dXJuO1xuICBicm93c2VyLnJ1bnRpbWVcbiAgICAuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnZ3JhcGhxbC1jYXB0dXJlJywgZW5kcG9pbnQsIHVybCwgcGFnZVVybCwgcmVzcG9uc2UgfSlcbiAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNlbmRNZXNzYWdlIGZhaWxlZCcsIGVycik7XG4gICAgfSk7XG59KTtcbiJdLAogICJtYXBwaW5ncyI6ICI7OztBQXNCQSxNQUFNLFNBQVM7QUFDZixNQUFNLFFBQVE7QUFDZCxNQUFNLGlCQUFpQjtBQUN2QixNQUFNLDBCQUEwQjtBQVFoQyxNQUFJLGdCQUFnQjtBQUNwQixNQUFJLG9CQUFvQixvQkFBSSxJQUFZO0FBQ3hDLE1BQUkseUJBQXlCLG9CQUFJLElBQVk7QUFDN0MsTUFBSSxrQkFBd0Q7QUFDNUQsTUFBTSxtQkFBbUIsb0JBQUksUUFBaUI7QUFFOUMsT0FBSyxRQUFRLFFBQ1YsWUFBWSxFQUFFLE1BQU0saUJBQWlCLEtBQUssU0FBUyxLQUFLLENBQUMsRUFDekQsTUFBTSxDQUFDLFFBQWlCO0FBQ3ZCLFlBQVEsS0FBSywyQ0FBMkMsR0FBRztBQUFBLEVBQzdELENBQUM7QUFFSCxXQUFTLGlCQUF1QjtBQUM5QixRQUFJO0FBQ0YsWUFBTSxNQUFNLFFBQVEsUUFBUSxPQUFPLGNBQWM7QUFDakQsWUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0FBQzlDLGFBQU8sTUFBTTtBQUNiLGFBQU8sUUFBUTtBQUNmLGFBQU8sUUFBUSxhQUFhO0FBQzVCLE9BQUMsU0FBUyxRQUFRLFNBQVMsaUJBQWlCLFlBQVksTUFBTTtBQUM5RCxhQUFPLFNBQVMsTUFBTSxPQUFPLE9BQU87QUFDcEMsYUFBTyxVQUFVLE1BQU07QUFJckIsZ0JBQVEsUUFDTCxZQUFZO0FBQUEsVUFDWCxNQUFNO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxLQUFLO0FBQUEsVUFDTCxLQUFLLFNBQVM7QUFBQSxRQUNoQixDQUFDLEVBQ0EsTUFBTSxNQUFNO0FBQUEsUUFBQyxDQUFDO0FBQUEsTUFDbkI7QUFBQSxJQUNGLFNBQVMsS0FBSztBQUNaLGNBQVEsS0FBSyxrREFBa0QsR0FBRztBQUFBLElBQ3BFO0FBQUEsRUFDRjtBQUVBLGlCQUFlO0FBRWYsV0FBUyxnQkFBZ0IsS0FBbUM7QUFDMUQsUUFBSSxDQUFDLElBQUssUUFBTztBQUNqQixVQUFNLFVBQVUsSUFBSSxLQUFLLEVBQUUsUUFBUSxNQUFNLEVBQUUsRUFBRSxZQUFZO0FBQ3pELFdBQU8sUUFBUSxTQUFTLElBQUksVUFBVTtBQUFBLEVBQ3hDO0FBRUEsTUFBTSxlQUFlLG9CQUFJLElBQUksQ0FBQyxTQUFTLGVBQWUsb0JBQW9CLENBQUM7QUFFM0UsV0FBUyxjQUFjLE1BQTREO0FBQ2pGLFFBQUksQ0FBQyxLQUFNLFFBQU87QUFDbEIsUUFBSTtBQUNGLFlBQU0sSUFBSSxJQUFJLElBQUksTUFBTSxTQUFTLElBQUk7QUFDckMsVUFBSSxDQUFDLGFBQWEsSUFBSSxFQUFFLFNBQVMsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUN4RCxZQUFNLFFBQVEsRUFBRSxTQUFTLE1BQU0sR0FBRyxFQUFFLE9BQU8sT0FBTztBQUNsRCxZQUFNLFlBQVksTUFBTSxRQUFRLFFBQVE7QUFDeEMsVUFBSSxhQUFhLEVBQUcsUUFBTztBQUMzQixZQUFNLFNBQVMsZ0JBQWdCLE1BQU0sWUFBWSxDQUFDLEtBQUssSUFBSTtBQUMzRCxZQUFNLEtBQUssTUFBTSxZQUFZLENBQUMsS0FBSztBQUNuQyxVQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssRUFBRSxFQUFHLFFBQU87QUFDaEQsYUFBTyxFQUFFLFFBQVEsR0FBRztBQUFBLElBQ3RCLFFBQVE7QUFDTixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGVBQWUsTUFBb0M7QUFDMUQsUUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixRQUFJO0FBQ0YsWUFBTSxJQUFJLElBQUksSUFBSSxNQUFNLFNBQVMsSUFBSTtBQUNyQyxVQUFJLENBQUMsYUFBYSxJQUFJLEVBQUUsU0FBUyxZQUFZLENBQUMsRUFBRyxRQUFPO0FBQ3hELFlBQU0sUUFBUSxFQUFFLFNBQVMsTUFBTSxHQUFHLEVBQUUsT0FBTyxPQUFPLEVBQUUsQ0FBQztBQUNyRCxVQUFJLENBQUMsU0FBUyxVQUFVLE9BQU8sVUFBVSxZQUFZLFVBQVUsU0FBVSxRQUFPO0FBQ2hGLGFBQU8sZ0JBQWdCLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsV0FBUyxVQUFVLElBQXNCO0FBQ3ZDLFVBQU0sT0FBTyxHQUFHLHNCQUFzQjtBQUN0QyxRQUFJLEtBQUssVUFBVSxLQUFLLEtBQUssV0FBVyxFQUFHLFFBQU87QUFDbEQsVUFBTSxRQUFRLE9BQU8saUJBQWlCLEVBQUU7QUFDeEMsV0FBTyxNQUFNLGVBQWUsWUFBWSxNQUFNLFlBQVk7QUFBQSxFQUM1RDtBQUVBLFdBQVMsc0JBQXNCLElBQTZCO0FBQzFELFdBQU8sR0FBRyxRQUFRLFNBQVMsS0FBSyxHQUFHLFFBQVEsaUNBQWlDO0FBQUEsRUFDOUU7QUFFQSxXQUFTLGNBQWMsV0FBNkI7QUFDbEQsVUFBTSxRQUFRLFVBQVUsZUFBZSxJQUFJLFlBQVk7QUFDdkQsUUFBSSxDQUFDLEtBQUssU0FBUyxhQUFhLEVBQUcsUUFBTztBQUMxQyxlQUFXLFFBQVEsTUFBTSxLQUFLLFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxHQUFHO0FBQ3BFLFlBQU0sU0FBUyxlQUFlLEtBQUssYUFBYSxNQUFNLENBQUM7QUFDdkQsVUFBSSxVQUFVLGtCQUFrQixJQUFJLE1BQU0sRUFBRyxRQUFPO0FBQUEsSUFDdEQ7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFdBQVMsZUFBZSxXQUE2QjtBQUNuRCxlQUFXLFFBQVEsTUFBTSxLQUFLLFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxHQUFHO0FBQ3BFLFlBQU0sUUFBUSxjQUFjLEtBQUssYUFBYSxNQUFNLENBQUM7QUFDckQsVUFBSSxDQUFDLE1BQU87QUFDWixVQUFJLGtCQUFrQixJQUFJLE1BQU0sTUFBTSxFQUFHLFFBQU87QUFDaEQsVUFBSSx1QkFBdUIsSUFBSSxNQUFNLEVBQUUsRUFBRyxRQUFPO0FBQUEsSUFDbkQ7QUFDQSxXQUFPLGNBQWMsU0FBUztBQUFBLEVBQ2hDO0FBRUEsV0FBUyx3QkFBOEI7QUFDckMsc0JBQWtCO0FBQ2xCLFFBQUksQ0FBQyxpQkFBaUIsa0JBQWtCLFNBQVMsRUFBRztBQUNwRCxVQUFNLFlBQVk7QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLE9BQU8sb0JBQUksSUFBYTtBQUM5QixRQUFJLFVBQVU7QUFDZCxlQUFXLE9BQU8sV0FBVztBQUMzQixpQkFBVyxNQUFNLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixHQUFHLENBQUMsR0FBRztBQUMzRCxZQUFJLEtBQUssSUFBSSxFQUFFLEtBQUssaUJBQWlCLElBQUksRUFBRSxFQUFHO0FBQzlDLGFBQUssSUFBSSxFQUFFO0FBQ1gsYUFBSyxHQUFHLGVBQWUsSUFBSSxLQUFLLEVBQUUsWUFBWSxNQUFNLFlBQWE7QUFDakUsWUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFHO0FBQ3BCLGNBQU0sWUFBWSxzQkFBc0IsRUFBRTtBQUMxQyxZQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsU0FBUyxFQUFHO0FBQzlDLHlCQUFpQixJQUFJLEVBQUU7QUFDdkIsWUFBSTtBQUNGLFVBQUMsR0FBbUIsTUFBTTtBQUMxQixxQkFBVztBQUFBLFFBQ2IsUUFBUTtBQUFBLFFBRVI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFFBQUksVUFBVSxHQUFHO0FBQ2YsY0FBUSxRQUFRLFlBQVksRUFBRSxNQUFNLHNCQUFzQixPQUFPLFFBQVEsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUFBLElBQzVGO0FBQUEsRUFDRjtBQUVBLFdBQVMsbUJBQW1CLFFBQVEseUJBQStCO0FBQ2pFLFFBQUksb0JBQW9CLEtBQU07QUFDOUIsc0JBQWtCLFdBQVcsdUJBQXVCLEtBQUs7QUFBQSxFQUMzRDtBQUVBLGlCQUFlLHVCQUFzQztBQUNuRCxRQUFJO0FBQ0YsWUFBTSxXQUFXLE1BQU0sUUFBUSxRQUFRLFlBQVk7QUFBQSxRQUNqRCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0QsWUFBTSxNQUFNLFlBQVksT0FBTyxhQUFhLFdBQVksV0FBcUMsQ0FBQztBQUM5RixzQkFBZ0IsSUFBSSxZQUFZO0FBQ2hDLDBCQUFvQixJQUFJO0FBQUEsU0FDckIsSUFBSSxlQUFlLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksRUFBRSxRQUFRLE1BQU0sRUFBRSxDQUFDO0FBQUEsTUFDdEU7QUFDQSwrQkFBeUIsSUFBSSxJQUFJLElBQUksb0JBQW9CLENBQUMsQ0FBQztBQUMzRCx5QkFBbUIsQ0FBQztBQUFBLElBQ3RCLFFBQVE7QUFDTixzQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLHdCQUE4QjtBQUNyQyxVQUFNLE9BQU8sU0FBUyxtQkFBbUIsU0FBUztBQUNsRCxRQUFJLENBQUMsTUFBTTtBQUNULGlCQUFXLHVCQUF1QixHQUFHO0FBQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sV0FBVyxJQUFJLGlCQUFpQixNQUFNLG1CQUFtQixDQUFDO0FBQ2hFLGFBQVMsUUFBUSxNQUFNLEVBQUUsV0FBVyxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBQ3pELFdBQU8saUJBQWlCLFVBQVUsTUFBTSxtQkFBbUIsR0FBRyxFQUFFLFNBQVMsS0FBSyxDQUFDO0FBQy9FLFNBQUsscUJBQXFCO0FBQzFCLGdCQUFZLE1BQU07QUFDaEIsV0FBSyxxQkFBcUI7QUFBQSxJQUM1QixHQUFHLGNBQWM7QUFBQSxFQUNuQjtBQUVBLHdCQUFzQjtBQUV0QixTQUFPLGlCQUFpQixXQUFXLENBQUMsVUFBd0I7QUFDMUQsUUFBSSxNQUFNLFdBQVcsT0FBUTtBQUM3QixVQUFNLE9BQU8sTUFBTTtBQUNuQixRQUFJLENBQUMsUUFBUSxPQUFPLFNBQVMsU0FBVTtBQUN2QyxVQUFNLElBQUk7QUFFVixRQUFJLEVBQUUsV0FBVyxPQUFPO0FBQ3RCLGNBQVEsUUFDTCxZQUFZO0FBQUEsUUFDWCxNQUFNO0FBQUEsUUFDTixLQUFLLE9BQU8sRUFBRSxRQUFRLFdBQVcsRUFBRSxNQUFNLFNBQVM7QUFBQSxNQUNwRCxDQUFDLEVBQ0EsTUFBTSxNQUFNO0FBQUEsTUFBQyxDQUFDO0FBQ2pCO0FBQUEsSUFDRjtBQUVBLFFBQUksRUFBRSxXQUFXLE9BQVE7QUFDekIsVUFBTSxXQUFXLE9BQU8sRUFBRSxhQUFhLFdBQVcsRUFBRSxXQUFXO0FBQy9ELFVBQU0sTUFBTSxPQUFPLEVBQUUsUUFBUSxXQUFXLEVBQUUsTUFBTTtBQUNoRCxVQUFNLFVBQVUsT0FBTyxFQUFFLGFBQWEsV0FBVyxFQUFFLFdBQVcsU0FBUztBQUN2RSxVQUFNLFdBQVcsRUFBRTtBQUNuQixRQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sYUFBYSxPQUFXO0FBQ2pELFlBQVEsUUFDTCxZQUFZLEVBQUUsTUFBTSxtQkFBbUIsVUFBVSxLQUFLLFNBQVMsU0FBUyxDQUFDLEVBQ3pFLE1BQU0sQ0FBQyxRQUFRO0FBQ2QsY0FBUSxLQUFLLG9DQUFvQyxHQUFHO0FBQUEsSUFDdEQsQ0FBQztBQUFBLEVBQ0wsQ0FBQzsiLAogICJuYW1lcyI6IFtdCn0K
