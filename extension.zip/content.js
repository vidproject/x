var browser=globalThis.browser??globalThis.chrome;
"use strict";
(() => {
  // src/content.ts
  var TARGET = "IMM_ARCHIVE_CAPTURE";
  var READY = "IMM_ARCHIVE_HOOK_READY";
  var UNFOLD_SYNC_MS = 2e3;
  var UNFOLD_SCAN_DEBOUNCE_MS = 250;
  var LOW_BANDWIDTH_SCAN_DEBOUNCE_MS = 100;
  var LOW_BANDWIDTH_RESCAN_MS = 1500;
  var LOW_BANDWIDTH_MEDIA_EVENTS = ["loadstart", "loadedmetadata", "play", "playing"];
  var unfoldEnabled = false;
  var unfoldCoreHandles = /* @__PURE__ */ new Set();
  var unfoldRelevantTweetIds = /* @__PURE__ */ new Set();
  var unfoldScanTimer = null;
  var unfoldedControls = /* @__PURE__ */ new WeakSet();
  var lowBandwidthScrubberEnabled = false;
  var lowBandwidthObserver = null;
  var lowBandwidthScanTimer = null;
  var lowBandwidthRescanTimer = null;
  void browser.runtime.sendMessage({ type: "content-alive", url: location.href }).catch((err) => {
    console.warn("[imm-archive] content-alive ping failed", err);
  });
  function fallbackInject() {
    try {
      const src = browser.runtime.getURL("page-hook.js");
      const script = document.createElement("script");
      script.src = src;
      script.async = false;
      script.dataset.immArchive = "1";
      (document.head || document.documentElement).appendChild(script);
      script.onload = () => script.remove();
      script.onerror = () => {
        browser.runtime.sendMessage({
          type: "log-content-event",
          level: "warn",
          msg: "inline page-hook injection blocked (CSP); relying on MAIN-world content script",
          url: location.href
        }).catch(() => {
        });
      };
    } catch (err) {
      console.warn("[imm-archive] inline page-hook injection threw", err);
    }
  }
  fallbackInject();
  function normalizeHandle(raw) {
    if (!raw) return null;
    const cleaned = raw.trim().replace(/^@/, "").toLowerCase();
    return cleaned.length > 0 ? cleaned : null;
  }
  var STATUS_HOSTS = /* @__PURE__ */ new Set(["x.com", "twitter.com", "mobile.twitter.com"]);
  function parseTweetUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const parts = u.pathname.split("/").filter(Boolean);
      const statusIdx = parts.indexOf("status");
      if (statusIdx <= 0) return null;
      const handle = normalizeHandle(parts[statusIdx - 1] ?? null);
      const id = parts[statusIdx + 1] ?? null;
      if (!handle || !id || !/^\d+$/.test(id)) return null;
      return { handle, id };
    } catch {
      return null;
    }
  }
  function parseHandleUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const first = u.pathname.split("/").filter(Boolean)[0];
      if (!first || first === "i" || first === "intent" || first === "search") return null;
      return normalizeHandle(first);
    } catch {
      return null;
    }
  }
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none";
  }
  function nearestTweetContainer(el) {
    return el.closest("article") ?? el.closest('div[data-testid="cellInnerDiv"]');
  }
  function isReplyToCore(container) {
    const text = (container.textContent || "").toLowerCase();
    if (!text.includes("replying to")) return false;
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const handle = parseHandleUrl(link.getAttribute("href"));
      if (handle && unfoldCoreHandles.has(handle)) return true;
    }
    return false;
  }
  function isCoreRelevant(container) {
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const tweet = parseTweetUrl(link.getAttribute("href"));
      if (!tweet) continue;
      if (unfoldCoreHandles.has(tweet.handle)) return true;
      if (unfoldRelevantTweetIds.has(tweet.id)) return true;
    }
    return isReplyToCore(container);
  }
  function scanAndUnfoldShowMore() {
    unfoldScanTimer = null;
    if (!unfoldEnabled || unfoldCoreHandles.size === 0) return;
    const selectors = [
      '[data-testid="tweet-text-show-more-link"]',
      'button[data-testid="tweet-text-show-more-link"]',
      'article [role="button"][tabindex="0"]',
      'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
    ];
    const seen = /* @__PURE__ */ new Set();
    let clicked = 0;
    for (const sel of selectors) {
      for (const el of Array.from(document.querySelectorAll(sel))) {
        if (seen.has(el) || unfoldedControls.has(el)) continue;
        seen.add(el);
        if ((el.textContent || "").trim().toLowerCase() !== "show more") continue;
        if (!isVisible(el)) continue;
        const container = nearestTweetContainer(el);
        if (!container || !isCoreRelevant(container)) continue;
        unfoldedControls.add(el);
        try {
          el.click();
          clicked += 1;
        } catch {
        }
      }
    }
    if (clicked > 0) {
      browser.runtime.sendMessage({ type: "show-more-unfolded", count: clicked }).catch(() => {
      });
    }
  }
  function scheduleUnfoldScan(delay = UNFOLD_SCAN_DEBOUNCE_MS) {
    if (unfoldScanTimer !== null) return;
    unfoldScanTimer = setTimeout(scanAndUnfoldShowMore, delay);
  }
  async function refreshUnfoldTargets() {
    try {
      const response = await browser.runtime.sendMessage({
        type: "get-unfold-targets"
      });
      const raw = response && typeof response === "object" ? response : {};
      unfoldEnabled = raw.enabled !== false;
      unfoldCoreHandles = new Set(
        (raw.coreHandles ?? []).map((h) => h.toLowerCase().replace(/^@/, ""))
      );
      unfoldRelevantTweetIds = new Set(raw.relevantTweetIds ?? []);
      scheduleUnfoldScan(0);
    } catch {
      unfoldEnabled = false;
    }
  }
  function installUnfoldObserver() {
    const root = document.documentElement || document.body;
    if (!root) {
      setTimeout(installUnfoldObserver, 100);
      return;
    }
    const observer = new MutationObserver(() => scheduleUnfoldScan());
    observer.observe(root, { childList: true, subtree: true });
    window.addEventListener("scroll", () => scheduleUnfoldScan(), { passive: true });
    void refreshUnfoldTargets();
    setInterval(() => {
      void refreshUnfoldTargets();
    }, UNFOLD_SYNC_MS);
  }
  installUnfoldObserver();
  function lowBandwidthSettingFrom(raw) {
    if (!raw || typeof raw !== "object") return false;
    return raw.lowBandwidthBrowsing === true;
  }
  function isScrubbableMedia(el) {
    return el instanceof HTMLVideoElement || el instanceof HTMLAudioElement;
  }
  function scrubMediaElement(el) {
    try {
      el.pause();
    } catch {
    }
    try {
      el.autoplay = false;
      el.preload = "none";
      el.removeAttribute("autoplay");
      el.removeAttribute("src");
      el.src = "";
      if ("srcObject" in el) el.srcObject = null;
      for (const source of Array.from(el.querySelectorAll("source[src]"))) {
        source.removeAttribute("src");
      }
      el.load();
    } catch {
    }
  }
  function scanLowBandwidthMedia() {
    lowBandwidthScanTimer = null;
    if (!lowBandwidthScrubberEnabled) return;
    for (const el of Array.from(document.querySelectorAll("video,audio"))) {
      if (isScrubbableMedia(el)) scrubMediaElement(el);
    }
  }
  function scheduleLowBandwidthScan(delay = LOW_BANDWIDTH_SCAN_DEBOUNCE_MS) {
    if (!lowBandwidthScrubberEnabled || lowBandwidthScanTimer !== null) return;
    lowBandwidthScanTimer = setTimeout(scanLowBandwidthMedia, delay);
  }
  function onLowBandwidthMediaEvent(event) {
    if (!lowBandwidthScrubberEnabled) return;
    if (isScrubbableMedia(event.target)) scrubMediaElement(event.target);
  }
  function setLowBandwidthScrubber(on) {
    if (lowBandwidthScrubberEnabled === on) return;
    lowBandwidthScrubberEnabled = on;
    if (on) {
      const root = document.documentElement || document.body;
      if (root) {
        lowBandwidthObserver = new MutationObserver(() => scheduleLowBandwidthScan());
        lowBandwidthObserver.observe(root, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["src"]
        });
      }
      for (const eventName of LOW_BANDWIDTH_MEDIA_EVENTS) {
        document.addEventListener(eventName, onLowBandwidthMediaEvent, true);
      }
      lowBandwidthRescanTimer = setInterval(scanLowBandwidthMedia, LOW_BANDWIDTH_RESCAN_MS);
      scheduleLowBandwidthScan(0);
      return;
    }
    if (lowBandwidthObserver) {
      lowBandwidthObserver.disconnect();
      lowBandwidthObserver = null;
    }
    if (lowBandwidthScanTimer !== null) {
      clearTimeout(lowBandwidthScanTimer);
      lowBandwidthScanTimer = null;
    }
    if (lowBandwidthRescanTimer !== null) {
      clearInterval(lowBandwidthRescanTimer);
      lowBandwidthRescanTimer = null;
    }
    for (const eventName of LOW_BANDWIDTH_MEDIA_EVENTS) {
      document.removeEventListener(eventName, onLowBandwidthMediaEvent, true);
    }
  }
  async function refreshLowBandwidthScrubber() {
    try {
      const result = await browser.storage.local.get("settings");
      setLowBandwidthScrubber(lowBandwidthSettingFrom(result.settings));
    } catch {
      setLowBandwidthScrubber(false);
    }
  }
  browser.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.settings) return;
    setLowBandwidthScrubber(lowBandwidthSettingFrom(changes.settings.newValue));
  });
  void refreshLowBandwidthScrubber();
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== "object") return;
    const d = data;
    if (d.source === READY) {
      browser.runtime.sendMessage({
        type: "page-hook-active",
        url: typeof d.url === "string" ? d.url : location.href
      }).catch(() => {
      });
      return;
    }
    if (d.source !== TARGET) return;
    const endpoint = typeof d.endpoint === "string" ? d.endpoint : null;
    const url = typeof d.url === "string" ? d.url : null;
    const pageUrl = typeof d.page_url === "string" ? d.page_url : location.href;
    const response = d.response;
    if (!endpoint || !url || response === void 0) return;
    browser.runtime.sendMessage({ type: "graphql-capture", endpoint, url, pageUrl, response }).catch((err) => {
      console.warn("[imm-archive] sendMessage failed", err);
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbnRlbnQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKlxuICogY29udGVudC50cyBcdTIwMTQgY29udGVudC1zY3JpcHQgY29udGV4dCAoaXNvbGF0ZWQgd29ybGQpLlxuICpcbiAqIFRoZSBhY3R1YWwgcGFnZS1ob29rICh3aGljaCBwYXRjaGVzIGBmZXRjaGAgLyBgWEhSYCkgaXMgZGVjbGFyZWQgYXMgYVxuICogc2VwYXJhdGUgY29udGVudCBzY3JpcHQgd2l0aCBgd29ybGQ6IFwiTUFJTlwiYCBpbiB0aGUgbWFuaWZlc3QsIHNvIGl0IHJ1bnNcbiAqIGluIHRoZSBwYWdlIHdvcmxkIGRpcmVjdGx5IHdpdGhvdXQgdXMgaGF2aW5nIHRvIGluamVjdCBhIDxzY3JpcHQ+IHRhZyBcdTIwMTRcbiAqIHdoaWNoIFgncyBub25jZS1iYXNlZCBDU1Agd291bGQgYmxvY2suXG4gKlxuICogVGhpcyBmaWxlIGRvZXMgdGhyZWUgdGhpbmdzOlxuICpcbiAqICAgMS4gUGluZ3MgdGhlIGJhY2tncm91bmQgb24gbG9hZCBzbyB0aGUgYWN0aXZpdHkgdGFpbCBjb25maXJtcyB0aGVcbiAqICAgICAgY29udGVudCBzY3JpcHQgcmVhY2hlZCB0aGUgWCBwYWdlICh1c2VmdWwgd2hlbiBkaWFnbm9zaW5nIGEgc2lsZW50XG4gKiAgICAgIFwiY2FwdHVyZS1ub3cgZG9lcyBub3RoaW5nXCIgZmFpbHVyZSkuXG4gKiAgIDIuIEFzIGEgZGVmZW5zaXZlIGZhbGxiYWNrLCBhbHNvIHRyaWVzIHRvIGluamVjdCBgcGFnZS1ob29rLmpzYCB2aWEgYVxuICogICAgICBzY3JpcHQgdGFnLiBIYXJtbGVzcyBvbiBtb2Rlcm4gRmlyZWZveCAodGhlIHBhZ2UtaG9vaydzIFRBRyBndWFyZFxuICogICAgICBwcmV2ZW50cyBkb3VibGUtaW5pdCk7IGNvdmVycyB0aGUgcmFyZSBjYXNlIHdoZXJlIHRoZSBNQUlOLXdvcmxkXG4gKiAgICAgIGNvbnRlbnQgc2NyaXB0IGVudHJ5IGlzbid0IGhvbm9yZWQuXG4gKiAgIDMuIEJyaWRnZXMgYHdpbmRvdy5wb3N0TWVzc2FnZWAgZnJvbSB0aGUgcGFnZSBob29rIHRvIHRoZSBiYWNrZ3JvdW5kOlxuICogICAgICBib3RoIHRoZSBgKl9SRUFEWWAgYm9vdCBwaW5nIGFuZCB0aGUgYElNTV9BUkNISVZFX0NBUFRVUkVgIHBheWxvYWRcbiAqICAgICAgZXZlbnRzLlxuICovXG5cbmNvbnN0IFRBUkdFVCA9ICdJTU1fQVJDSElWRV9DQVBUVVJFJztcbmNvbnN0IFJFQURZID0gJ0lNTV9BUkNISVZFX0hPT0tfUkVBRFknO1xuY29uc3QgVU5GT0xEX1NZTkNfTVMgPSAyXzAwMDtcbmNvbnN0IFVORk9MRF9TQ0FOX0RFQk9VTkNFX01TID0gMjUwO1xuY29uc3QgTE9XX0JBTkRXSURUSF9TQ0FOX0RFQk9VTkNFX01TID0gMTAwO1xuY29uc3QgTE9XX0JBTkRXSURUSF9SRVNDQU5fTVMgPSAxXzUwMDtcbmNvbnN0IExPV19CQU5EV0lEVEhfTUVESUFfRVZFTlRTID0gWydsb2Fkc3RhcnQnLCAnbG9hZGVkbWV0YWRhdGEnLCAncGxheScsICdwbGF5aW5nJ10gYXMgY29uc3Q7XG5cbmludGVyZmFjZSBVbmZvbGRUYXJnZXRzUmVzcG9uc2Uge1xuICBlbmFibGVkPzogYm9vbGVhbjtcbiAgY29yZUhhbmRsZXM/OiBzdHJpbmdbXTtcbiAgcmVsZXZhbnRUd2VldElkcz86IHN0cmluZ1tdO1xufVxuXG5sZXQgdW5mb2xkRW5hYmxlZCA9IGZhbHNlO1xubGV0IHVuZm9sZENvcmVIYW5kbGVzID0gbmV3IFNldDxzdHJpbmc+KCk7XG5sZXQgdW5mb2xkUmVsZXZhbnRUd2VldElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xubGV0IHVuZm9sZFNjYW5UaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCBudWxsID0gbnVsbDtcbmNvbnN0IHVuZm9sZGVkQ29udHJvbHMgPSBuZXcgV2Vha1NldDxFbGVtZW50PigpO1xubGV0IGxvd0JhbmR3aWR0aFNjcnViYmVyRW5hYmxlZCA9IGZhbHNlO1xubGV0IGxvd0JhbmR3aWR0aE9ic2VydmVyOiBNdXRhdGlvbk9ic2VydmVyIHwgbnVsbCA9IG51bGw7XG5sZXQgbG93QmFuZHdpZHRoU2NhblRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IG51bGwgPSBudWxsO1xubGV0IGxvd0JhbmR3aWR0aFJlc2NhblRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcblxudm9pZCBicm93c2VyLnJ1bnRpbWVcbiAgLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2NvbnRlbnQtYWxpdmUnLCB1cmw6IGxvY2F0aW9uLmhyZWYgfSlcbiAgLmNhdGNoKChlcnI6IHVua25vd24pID0+IHtcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gY29udGVudC1hbGl2ZSBwaW5nIGZhaWxlZCcsIGVycik7XG4gIH0pO1xuXG5mdW5jdGlvbiBmYWxsYmFja0luamVjdCgpOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBjb25zdCBzcmMgPSBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKCdwYWdlLWhvb2suanMnKTtcbiAgICBjb25zdCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtcbiAgICBzY3JpcHQuc3JjID0gc3JjO1xuICAgIHNjcmlwdC5hc3luYyA9IGZhbHNlO1xuICAgIHNjcmlwdC5kYXRhc2V0LmltbUFyY2hpdmUgPSAnMSc7XG4gICAgKGRvY3VtZW50LmhlYWQgfHwgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS5hcHBlbmRDaGlsZChzY3JpcHQpO1xuICAgIHNjcmlwdC5vbmxvYWQgPSAoKSA9PiBzY3JpcHQucmVtb3ZlKCk7XG4gICAgc2NyaXB0Lm9uZXJyb3IgPSAoKSA9PiB7XG4gICAgICAvLyBDU1AgcHJvYmFibHkgYmxvY2tlZCB0aGlzLiBOb3QgZmF0YWwgXHUyMDE0IHRoZSBNQUlOLXdvcmxkIGNvbnRlbnQgc2NyaXB0XG4gICAgICAvLyBkZWNsYXJlZCBpbiBtYW5pZmVzdC5qc29uIGlzIHRoZSBwcmltYXJ5IHBhdGguIFN1cmZhY2UgYXMgYSBsb2cgc29cbiAgICAgIC8vIHdlIGtub3cgd2hhdCBoYXBwZW5lZCB3aXRob3V0IGx5aW5nIGFib3V0IHN1Y2Nlc3MuXG4gICAgICBicm93c2VyLnJ1bnRpbWVcbiAgICAgICAgLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgICB0eXBlOiAnbG9nLWNvbnRlbnQtZXZlbnQnLFxuICAgICAgICAgIGxldmVsOiAnd2FybicsXG4gICAgICAgICAgbXNnOiAnaW5saW5lIHBhZ2UtaG9vayBpbmplY3Rpb24gYmxvY2tlZCAoQ1NQKTsgcmVseWluZyBvbiBNQUlOLXdvcmxkIGNvbnRlbnQgc2NyaXB0JyxcbiAgICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWYsXG4gICAgICAgIH0pXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7fSk7XG4gICAgfTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGlubGluZSBwYWdlLWhvb2sgaW5qZWN0aW9uIHRocmV3JywgZXJyKTtcbiAgfVxufVxuXG5mYWxsYmFja0luamVjdCgpO1xuXG5mdW5jdGlvbiBub3JtYWxpemVIYW5kbGUocmF3OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICghcmF3KSByZXR1cm4gbnVsbDtcbiAgY29uc3QgY2xlYW5lZCA9IHJhdy50cmltKCkucmVwbGFjZSgvXkAvLCAnJykudG9Mb3dlckNhc2UoKTtcbiAgcmV0dXJuIGNsZWFuZWQubGVuZ3RoID4gMCA/IGNsZWFuZWQgOiBudWxsO1xufVxuXG5jb25zdCBTVEFUVVNfSE9TVFMgPSBuZXcgU2V0KFsneC5jb20nLCAndHdpdHRlci5jb20nLCAnbW9iaWxlLnR3aXR0ZXIuY29tJ10pO1xuXG5mdW5jdGlvbiBwYXJzZVR3ZWV0VXJsKGhyZWY6IHN0cmluZyB8IG51bGwpOiB7IGhhbmRsZTogc3RyaW5nOyBpZDogc3RyaW5nIH0gfCBudWxsIHtcbiAgaWYgKCFocmVmKSByZXR1cm4gbnVsbDtcbiAgdHJ5IHtcbiAgICBjb25zdCB1ID0gbmV3IFVSTChocmVmLCBsb2NhdGlvbi5ocmVmKTtcbiAgICBpZiAoIVNUQVRVU19IT1NUUy5oYXModS5ob3N0bmFtZS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgcGFydHMgPSB1LnBhdGhuYW1lLnNwbGl0KCcvJykuZmlsdGVyKEJvb2xlYW4pO1xuICAgIGNvbnN0IHN0YXR1c0lkeCA9IHBhcnRzLmluZGV4T2YoJ3N0YXR1cycpO1xuICAgIGlmIChzdGF0dXNJZHggPD0gMCkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgaGFuZGxlID0gbm9ybWFsaXplSGFuZGxlKHBhcnRzW3N0YXR1c0lkeCAtIDFdID8/IG51bGwpO1xuICAgIGNvbnN0IGlkID0gcGFydHNbc3RhdHVzSWR4ICsgMV0gPz8gbnVsbDtcbiAgICBpZiAoIWhhbmRsZSB8fCAhaWQgfHwgIS9eXFxkKyQvLnRlc3QoaWQpKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4geyBoYW5kbGUsIGlkIH07XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBhcnNlSGFuZGxlVXJsKGhyZWY6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKCFocmVmKSByZXR1cm4gbnVsbDtcbiAgdHJ5IHtcbiAgICBjb25zdCB1ID0gbmV3IFVSTChocmVmLCBsb2NhdGlvbi5ocmVmKTtcbiAgICBpZiAoIVNUQVRVU19IT1NUUy5oYXModS5ob3N0bmFtZS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgZmlyc3QgPSB1LnBhdGhuYW1lLnNwbGl0KCcvJykuZmlsdGVyKEJvb2xlYW4pWzBdO1xuICAgIGlmICghZmlyc3QgfHwgZmlyc3QgPT09ICdpJyB8fCBmaXJzdCA9PT0gJ2ludGVudCcgfHwgZmlyc3QgPT09ICdzZWFyY2gnKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gbm9ybWFsaXplSGFuZGxlKGZpcnN0KTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gaXNWaXNpYmxlKGVsOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgaWYgKHJlY3Qud2lkdGggPT09IDAgfHwgcmVjdC5oZWlnaHQgPT09IDApIHJldHVybiBmYWxzZTtcbiAgY29uc3Qgc3R5bGUgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbCk7XG4gIHJldHVybiBzdHlsZS52aXNpYmlsaXR5ICE9PSAnaGlkZGVuJyAmJiBzdHlsZS5kaXNwbGF5ICE9PSAnbm9uZSc7XG59XG5cbmZ1bmN0aW9uIG5lYXJlc3RUd2VldENvbnRhaW5lcihlbDogRWxlbWVudCk6IEVsZW1lbnQgfCBudWxsIHtcbiAgcmV0dXJuIGVsLmNsb3Nlc3QoJ2FydGljbGUnKSA/PyBlbC5jbG9zZXN0KCdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0nKTtcbn1cblxuZnVuY3Rpb24gaXNSZXBseVRvQ29yZShjb250YWluZXI6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgY29uc3QgdGV4dCA9IChjb250YWluZXIudGV4dENvbnRlbnQgfHwgJycpLnRvTG93ZXJDYXNlKCk7XG4gIGlmICghdGV4dC5pbmNsdWRlcygncmVwbHlpbmcgdG8nKSkgcmV0dXJuIGZhbHNlO1xuICBmb3IgKGNvbnN0IGxpbmsgb2YgQXJyYXkuZnJvbShjb250YWluZXIucXVlcnlTZWxlY3RvckFsbCgnYVtocmVmXScpKSkge1xuICAgIGNvbnN0IGhhbmRsZSA9IHBhcnNlSGFuZGxlVXJsKGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJykpO1xuICAgIGlmIChoYW5kbGUgJiYgdW5mb2xkQ29yZUhhbmRsZXMuaGFzKGhhbmRsZSkpIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuZnVuY3Rpb24gaXNDb3JlUmVsZXZhbnQoY29udGFpbmVyOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGZvciAoY29uc3QgbGluayBvZiBBcnJheS5mcm9tKGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yQWxsKCdhW2hyZWZdJykpKSB7XG4gICAgY29uc3QgdHdlZXQgPSBwYXJzZVR3ZWV0VXJsKGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJykpO1xuICAgIGlmICghdHdlZXQpIGNvbnRpbnVlO1xuICAgIGlmICh1bmZvbGRDb3JlSGFuZGxlcy5oYXModHdlZXQuaGFuZGxlKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKHVuZm9sZFJlbGV2YW50VHdlZXRJZHMuaGFzKHR3ZWV0LmlkKSkgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGlzUmVwbHlUb0NvcmUoY29udGFpbmVyKTtcbn1cblxuZnVuY3Rpb24gc2NhbkFuZFVuZm9sZFNob3dNb3JlKCk6IHZvaWQge1xuICB1bmZvbGRTY2FuVGltZXIgPSBudWxsO1xuICBpZiAoIXVuZm9sZEVuYWJsZWQgfHwgdW5mb2xkQ29yZUhhbmRsZXMuc2l6ZSA9PT0gMCkgcmV0dXJuO1xuICBjb25zdCBzZWxlY3RvcnMgPSBbXG4gICAgJ1tkYXRhLXRlc3RpZD1cInR3ZWV0LXRleHQtc2hvdy1tb3JlLWxpbmtcIl0nLFxuICAgICdidXR0b25bZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcbiAgICAnYXJ0aWNsZSBbcm9sZT1cImJ1dHRvblwiXVt0YWJpbmRleD1cIjBcIl0nLFxuICAgICdkaXZbZGF0YS10ZXN0aWQ9XCJjZWxsSW5uZXJEaXZcIl0gW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcbiAgXTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8RWxlbWVudD4oKTtcbiAgbGV0IGNsaWNrZWQgPSAwO1xuICBmb3IgKGNvbnN0IHNlbCBvZiBzZWxlY3RvcnMpIHtcbiAgICBmb3IgKGNvbnN0IGVsIG9mIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWwpKSkge1xuICAgICAgaWYgKHNlZW4uaGFzKGVsKSB8fCB1bmZvbGRlZENvbnRyb2xzLmhhcyhlbCkpIGNvbnRpbnVlO1xuICAgICAgc2Vlbi5hZGQoZWwpO1xuICAgICAgaWYgKChlbC50ZXh0Q29udGVudCB8fCAnJykudHJpbSgpLnRvTG93ZXJDYXNlKCkgIT09ICdzaG93IG1vcmUnKSBjb250aW51ZTtcbiAgICAgIGlmICghaXNWaXNpYmxlKGVsKSkgY29udGludWU7XG4gICAgICBjb25zdCBjb250YWluZXIgPSBuZWFyZXN0VHdlZXRDb250YWluZXIoZWwpO1xuICAgICAgaWYgKCFjb250YWluZXIgfHwgIWlzQ29yZVJlbGV2YW50KGNvbnRhaW5lcikpIGNvbnRpbnVlO1xuICAgICAgdW5mb2xkZWRDb250cm9scy5hZGQoZWwpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgICAgICBjbGlja2VkICs9IDE7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gSWdub3JlIHN0YWxlIG9yIHN5bnRoZXRpYyBjb250cm9scy5cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGNsaWNrZWQgPiAwKSB7XG4gICAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ3Nob3ctbW9yZS11bmZvbGRlZCcsIGNvdW50OiBjbGlja2VkIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzY2hlZHVsZVVuZm9sZFNjYW4oZGVsYXkgPSBVTkZPTERfU0NBTl9ERUJPVU5DRV9NUyk6IHZvaWQge1xuICBpZiAodW5mb2xkU2NhblRpbWVyICE9PSBudWxsKSByZXR1cm47XG4gIHVuZm9sZFNjYW5UaW1lciA9IHNldFRpbWVvdXQoc2NhbkFuZFVuZm9sZFNob3dNb3JlLCBkZWxheSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hVbmZvbGRUYXJnZXRzKCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgIHR5cGU6ICdnZXQtdW5mb2xkLXRhcmdldHMnLFxuICAgIH0pO1xuICAgIGNvbnN0IHJhdyA9IHJlc3BvbnNlICYmIHR5cGVvZiByZXNwb25zZSA9PT0gJ29iamVjdCcgPyAocmVzcG9uc2UgYXMgVW5mb2xkVGFyZ2V0c1Jlc3BvbnNlKSA6IHt9O1xuICAgIHVuZm9sZEVuYWJsZWQgPSByYXcuZW5hYmxlZCAhPT0gZmFsc2U7XG4gICAgdW5mb2xkQ29yZUhhbmRsZXMgPSBuZXcgU2V0KFxuICAgICAgKHJhdy5jb3JlSGFuZGxlcyA/PyBbXSkubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXkAvLCAnJykpXG4gICAgKTtcbiAgICB1bmZvbGRSZWxldmFudFR3ZWV0SWRzID0gbmV3IFNldChyYXcucmVsZXZhbnRUd2VldElkcyA/PyBbXSk7XG4gICAgc2NoZWR1bGVVbmZvbGRTY2FuKDApO1xuICB9IGNhdGNoIHtcbiAgICB1bmZvbGRFbmFibGVkID0gZmFsc2U7XG4gIH1cbn1cblxuZnVuY3Rpb24gaW5zdGFsbFVuZm9sZE9ic2VydmVyKCk6IHZvaWQge1xuICBjb25zdCByb290ID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50IHx8IGRvY3VtZW50LmJvZHk7XG4gIGlmICghcm9vdCkge1xuICAgIHNldFRpbWVvdXQoaW5zdGFsbFVuZm9sZE9ic2VydmVyLCAxMDApO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKCgpID0+IHNjaGVkdWxlVW5mb2xkU2NhbigpKTtcbiAgb2JzZXJ2ZXIub2JzZXJ2ZShyb290LCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsICgpID0+IHNjaGVkdWxlVW5mb2xkU2NhbigpLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gIHZvaWQgcmVmcmVzaFVuZm9sZFRhcmdldHMoKTtcbiAgc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgcmVmcmVzaFVuZm9sZFRhcmdldHMoKTtcbiAgfSwgVU5GT0xEX1NZTkNfTVMpO1xufVxuXG5pbnN0YWxsVW5mb2xkT2JzZXJ2ZXIoKTtcblxuZnVuY3Rpb24gbG93QmFuZHdpZHRoU2V0dGluZ0Zyb20ocmF3OiB1bmtub3duKTogYm9vbGVhbiB7XG4gIGlmICghcmF3IHx8IHR5cGVvZiByYXcgIT09ICdvYmplY3QnKSByZXR1cm4gZmFsc2U7XG4gIHJldHVybiAocmF3IGFzIHsgbG93QmFuZHdpZHRoQnJvd3Npbmc/OiB1bmtub3duIH0pLmxvd0JhbmR3aWR0aEJyb3dzaW5nID09PSB0cnVlO1xufVxuXG5mdW5jdGlvbiBpc1NjcnViYmFibGVNZWRpYShlbDogRXZlbnRUYXJnZXQgfCBFbGVtZW50IHwgbnVsbCk6IGVsIGlzIEhUTUxNZWRpYUVsZW1lbnQge1xuICByZXR1cm4gZWwgaW5zdGFuY2VvZiBIVE1MVmlkZW9FbGVtZW50IHx8IGVsIGluc3RhbmNlb2YgSFRNTEF1ZGlvRWxlbWVudDtcbn1cblxuZnVuY3Rpb24gc2NydWJNZWRpYUVsZW1lbnQoZWw6IEhUTUxNZWRpYUVsZW1lbnQpOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBlbC5wYXVzZSgpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBJZ25vcmUgc3RhbGUgbWVkaWEgbm9kZXMuXG4gIH1cbiAgdHJ5IHtcbiAgICBlbC5hdXRvcGxheSA9IGZhbHNlO1xuICAgIGVsLnByZWxvYWQgPSAnbm9uZSc7XG4gICAgZWwucmVtb3ZlQXR0cmlidXRlKCdhdXRvcGxheScpO1xuICAgIGVsLnJlbW92ZUF0dHJpYnV0ZSgnc3JjJyk7XG4gICAgZWwuc3JjID0gJyc7XG4gICAgaWYgKCdzcmNPYmplY3QnIGluIGVsKSBlbC5zcmNPYmplY3QgPSBudWxsO1xuICAgIGZvciAoY29uc3Qgc291cmNlIG9mIEFycmF5LmZyb20oZWwucXVlcnlTZWxlY3RvckFsbCgnc291cmNlW3NyY10nKSkpIHtcbiAgICAgIHNvdXJjZS5yZW1vdmVBdHRyaWJ1dGUoJ3NyYycpO1xuICAgIH1cbiAgICBlbC5sb2FkKCk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIFggY2FuIHJlcGxhY2Ugbm9kZXMgZHVyaW5nIHNjcm9sbDsgYmVzdC1lZmZvcnQgc2NydWJiaW5nIGlzIGVub3VnaC5cbiAgfVxufVxuXG5mdW5jdGlvbiBzY2FuTG93QmFuZHdpZHRoTWVkaWEoKTogdm9pZCB7XG4gIGxvd0JhbmR3aWR0aFNjYW5UaW1lciA9IG51bGw7XG4gIGlmICghbG93QmFuZHdpZHRoU2NydWJiZXJFbmFibGVkKSByZXR1cm47XG4gIGZvciAoY29uc3QgZWwgb2YgQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCd2aWRlbyxhdWRpbycpKSkge1xuICAgIGlmIChpc1NjcnViYmFibGVNZWRpYShlbCkpIHNjcnViTWVkaWFFbGVtZW50KGVsKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzY2hlZHVsZUxvd0JhbmR3aWR0aFNjYW4oZGVsYXkgPSBMT1dfQkFORFdJRFRIX1NDQU5fREVCT1VOQ0VfTVMpOiB2b2lkIHtcbiAgaWYgKCFsb3dCYW5kd2lkdGhTY3J1YmJlckVuYWJsZWQgfHwgbG93QmFuZHdpZHRoU2NhblRpbWVyICE9PSBudWxsKSByZXR1cm47XG4gIGxvd0JhbmR3aWR0aFNjYW5UaW1lciA9IHNldFRpbWVvdXQoc2Nhbkxvd0JhbmR3aWR0aE1lZGlhLCBkZWxheSk7XG59XG5cbmZ1bmN0aW9uIG9uTG93QmFuZHdpZHRoTWVkaWFFdmVudChldmVudDogRXZlbnQpOiB2b2lkIHtcbiAgaWYgKCFsb3dCYW5kd2lkdGhTY3J1YmJlckVuYWJsZWQpIHJldHVybjtcbiAgaWYgKGlzU2NydWJiYWJsZU1lZGlhKGV2ZW50LnRhcmdldCkpIHNjcnViTWVkaWFFbGVtZW50KGV2ZW50LnRhcmdldCk7XG59XG5cbmZ1bmN0aW9uIHNldExvd0JhbmR3aWR0aFNjcnViYmVyKG9uOiBib29sZWFuKTogdm9pZCB7XG4gIGlmIChsb3dCYW5kd2lkdGhTY3J1YmJlckVuYWJsZWQgPT09IG9uKSByZXR1cm47XG4gIGxvd0JhbmR3aWR0aFNjcnViYmVyRW5hYmxlZCA9IG9uO1xuXG4gIGlmIChvbikge1xuICAgIGNvbnN0IHJvb3QgPSBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQgfHwgZG9jdW1lbnQuYm9keTtcbiAgICBpZiAocm9vdCkge1xuICAgICAgbG93QmFuZHdpZHRoT2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigoKSA9PiBzY2hlZHVsZUxvd0JhbmR3aWR0aFNjYW4oKSk7XG4gICAgICBsb3dCYW5kd2lkdGhPYnNlcnZlci5vYnNlcnZlKHJvb3QsIHtcbiAgICAgICAgY2hpbGRMaXN0OiB0cnVlLFxuICAgICAgICBzdWJ0cmVlOiB0cnVlLFxuICAgICAgICBhdHRyaWJ1dGVzOiB0cnVlLFxuICAgICAgICBhdHRyaWJ1dGVGaWx0ZXI6IFsnc3JjJ10sXG4gICAgICB9KTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBldmVudE5hbWUgb2YgTE9XX0JBTkRXSURUSF9NRURJQV9FVkVOVFMpIHtcbiAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoZXZlbnROYW1lLCBvbkxvd0JhbmR3aWR0aE1lZGlhRXZlbnQsIHRydWUpO1xuICAgIH1cbiAgICBsb3dCYW5kd2lkdGhSZXNjYW5UaW1lciA9IHNldEludGVydmFsKHNjYW5Mb3dCYW5kd2lkdGhNZWRpYSwgTE9XX0JBTkRXSURUSF9SRVNDQU5fTVMpO1xuICAgIHNjaGVkdWxlTG93QmFuZHdpZHRoU2NhbigwKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAobG93QmFuZHdpZHRoT2JzZXJ2ZXIpIHtcbiAgICBsb3dCYW5kd2lkdGhPYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgbG93QmFuZHdpZHRoT2JzZXJ2ZXIgPSBudWxsO1xuICB9XG4gIGlmIChsb3dCYW5kd2lkdGhTY2FuVGltZXIgIT09IG51bGwpIHtcbiAgICBjbGVhclRpbWVvdXQobG93QmFuZHdpZHRoU2NhblRpbWVyKTtcbiAgICBsb3dCYW5kd2lkdGhTY2FuVGltZXIgPSBudWxsO1xuICB9XG4gIGlmIChsb3dCYW5kd2lkdGhSZXNjYW5UaW1lciAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwobG93QmFuZHdpZHRoUmVzY2FuVGltZXIpO1xuICAgIGxvd0JhbmR3aWR0aFJlc2NhblRpbWVyID0gbnVsbDtcbiAgfVxuICBmb3IgKGNvbnN0IGV2ZW50TmFtZSBvZiBMT1dfQkFORFdJRFRIX01FRElBX0VWRU5UUykge1xuICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoZXZlbnROYW1lLCBvbkxvd0JhbmR3aWR0aE1lZGlhRXZlbnQsIHRydWUpO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hMb3dCYW5kd2lkdGhTY3J1YmJlcigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KCdzZXR0aW5ncycpO1xuICAgIHNldExvd0JhbmR3aWR0aFNjcnViYmVyKGxvd0JhbmR3aWR0aFNldHRpbmdGcm9tKHJlc3VsdC5zZXR0aW5ncykpO1xuICB9IGNhdGNoIHtcbiAgICBzZXRMb3dCYW5kd2lkdGhTY3J1YmJlcihmYWxzZSk7XG4gIH1cbn1cblxuYnJvd3Nlci5zdG9yYWdlLm9uQ2hhbmdlZC5hZGRMaXN0ZW5lcigoY2hhbmdlcywgYXJlYU5hbWUpID0+IHtcbiAgaWYgKGFyZWFOYW1lICE9PSAnbG9jYWwnIHx8ICFjaGFuZ2VzLnNldHRpbmdzKSByZXR1cm47XG4gIHNldExvd0JhbmR3aWR0aFNjcnViYmVyKGxvd0JhbmR3aWR0aFNldHRpbmdGcm9tKGNoYW5nZXMuc2V0dGluZ3MubmV3VmFsdWUpKTtcbn0pO1xuXG52b2lkIHJlZnJlc2hMb3dCYW5kd2lkdGhTY3J1YmJlcigpO1xuXG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbWVzc2FnZScsIChldmVudDogTWVzc2FnZUV2ZW50KSA9PiB7XG4gIGlmIChldmVudC5zb3VyY2UgIT09IHdpbmRvdykgcmV0dXJuO1xuICBjb25zdCBkYXRhID0gZXZlbnQuZGF0YSBhcyB1bmtub3duO1xuICBpZiAoIWRhdGEgfHwgdHlwZW9mIGRhdGEgIT09ICdvYmplY3QnKSByZXR1cm47XG4gIGNvbnN0IGQgPSBkYXRhIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuXG4gIGlmIChkLnNvdXJjZSA9PT0gUkVBRFkpIHtcbiAgICBicm93c2VyLnJ1bnRpbWVcbiAgICAgIC5zZW5kTWVzc2FnZSh7XG4gICAgICAgIHR5cGU6ICdwYWdlLWhvb2stYWN0aXZlJyxcbiAgICAgICAgdXJsOiB0eXBlb2YgZC51cmwgPT09ICdzdHJpbmcnID8gZC51cmwgOiBsb2NhdGlvbi5ocmVmLFxuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoKSA9PiB7fSk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGQuc291cmNlICE9PSBUQVJHRVQpIHJldHVybjtcbiAgY29uc3QgZW5kcG9pbnQgPSB0eXBlb2YgZC5lbmRwb2ludCA9PT0gJ3N0cmluZycgPyBkLmVuZHBvaW50IDogbnVsbDtcbiAgY29uc3QgdXJsID0gdHlwZW9mIGQudXJsID09PSAnc3RyaW5nJyA/IGQudXJsIDogbnVsbDtcbiAgY29uc3QgcGFnZVVybCA9IHR5cGVvZiBkLnBhZ2VfdXJsID09PSAnc3RyaW5nJyA/IGQucGFnZV91cmwgOiBsb2NhdGlvbi5ocmVmO1xuICBjb25zdCByZXNwb25zZSA9IGQucmVzcG9uc2U7XG4gIGlmICghZW5kcG9pbnQgfHwgIXVybCB8fCByZXNwb25zZSA9PT0gdW5kZWZpbmVkKSByZXR1cm47XG4gIGJyb3dzZXIucnVudGltZVxuICAgIC5zZW5kTWVzc2FnZSh7IHR5cGU6ICdncmFwaHFsLWNhcHR1cmUnLCBlbmRwb2ludCwgdXJsLCBwYWdlVXJsLCByZXNwb25zZSB9KVxuICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gc2VuZE1lc3NhZ2UgZmFpbGVkJywgZXJyKTtcbiAgICB9KTtcbn0pO1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7OztBQXNCQSxNQUFNLFNBQVM7QUFDZixNQUFNLFFBQVE7QUFDZCxNQUFNLGlCQUFpQjtBQUN2QixNQUFNLDBCQUEwQjtBQUNoQyxNQUFNLGlDQUFpQztBQUN2QyxNQUFNLDBCQUEwQjtBQUNoQyxNQUFNLDZCQUE2QixDQUFDLGFBQWEsa0JBQWtCLFFBQVEsU0FBUztBQVFwRixNQUFJLGdCQUFnQjtBQUNwQixNQUFJLG9CQUFvQixvQkFBSSxJQUFZO0FBQ3hDLE1BQUkseUJBQXlCLG9CQUFJLElBQVk7QUFDN0MsTUFBSSxrQkFBd0Q7QUFDNUQsTUFBTSxtQkFBbUIsb0JBQUksUUFBaUI7QUFDOUMsTUFBSSw4QkFBOEI7QUFDbEMsTUFBSSx1QkFBZ0Q7QUFDcEQsTUFBSSx3QkFBOEQ7QUFDbEUsTUFBSSwwQkFBaUU7QUFFckUsT0FBSyxRQUFRLFFBQ1YsWUFBWSxFQUFFLE1BQU0saUJBQWlCLEtBQUssU0FBUyxLQUFLLENBQUMsRUFDekQsTUFBTSxDQUFDLFFBQWlCO0FBQ3ZCLFlBQVEsS0FBSywyQ0FBMkMsR0FBRztBQUFBLEVBQzdELENBQUM7QUFFSCxXQUFTLGlCQUF1QjtBQUM5QixRQUFJO0FBQ0YsWUFBTSxNQUFNLFFBQVEsUUFBUSxPQUFPLGNBQWM7QUFDakQsWUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0FBQzlDLGFBQU8sTUFBTTtBQUNiLGFBQU8sUUFBUTtBQUNmLGFBQU8sUUFBUSxhQUFhO0FBQzVCLE9BQUMsU0FBUyxRQUFRLFNBQVMsaUJBQWlCLFlBQVksTUFBTTtBQUM5RCxhQUFPLFNBQVMsTUFBTSxPQUFPLE9BQU87QUFDcEMsYUFBTyxVQUFVLE1BQU07QUFJckIsZ0JBQVEsUUFDTCxZQUFZO0FBQUEsVUFDWCxNQUFNO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxLQUFLO0FBQUEsVUFDTCxLQUFLLFNBQVM7QUFBQSxRQUNoQixDQUFDLEVBQ0EsTUFBTSxNQUFNO0FBQUEsUUFBQyxDQUFDO0FBQUEsTUFDbkI7QUFBQSxJQUNGLFNBQVMsS0FBSztBQUNaLGNBQVEsS0FBSyxrREFBa0QsR0FBRztBQUFBLElBQ3BFO0FBQUEsRUFDRjtBQUVBLGlCQUFlO0FBRWYsV0FBUyxnQkFBZ0IsS0FBbUM7QUFDMUQsUUFBSSxDQUFDLElBQUssUUFBTztBQUNqQixVQUFNLFVBQVUsSUFBSSxLQUFLLEVBQUUsUUFBUSxNQUFNLEVBQUUsRUFBRSxZQUFZO0FBQ3pELFdBQU8sUUFBUSxTQUFTLElBQUksVUFBVTtBQUFBLEVBQ3hDO0FBRUEsTUFBTSxlQUFlLG9CQUFJLElBQUksQ0FBQyxTQUFTLGVBQWUsb0JBQW9CLENBQUM7QUFFM0UsV0FBUyxjQUFjLE1BQTREO0FBQ2pGLFFBQUksQ0FBQyxLQUFNLFFBQU87QUFDbEIsUUFBSTtBQUNGLFlBQU0sSUFBSSxJQUFJLElBQUksTUFBTSxTQUFTLElBQUk7QUFDckMsVUFBSSxDQUFDLGFBQWEsSUFBSSxFQUFFLFNBQVMsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUN4RCxZQUFNLFFBQVEsRUFBRSxTQUFTLE1BQU0sR0FBRyxFQUFFLE9BQU8sT0FBTztBQUNsRCxZQUFNLFlBQVksTUFBTSxRQUFRLFFBQVE7QUFDeEMsVUFBSSxhQUFhLEVBQUcsUUFBTztBQUMzQixZQUFNLFNBQVMsZ0JBQWdCLE1BQU0sWUFBWSxDQUFDLEtBQUssSUFBSTtBQUMzRCxZQUFNLEtBQUssTUFBTSxZQUFZLENBQUMsS0FBSztBQUNuQyxVQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssRUFBRSxFQUFHLFFBQU87QUFDaEQsYUFBTyxFQUFFLFFBQVEsR0FBRztBQUFBLElBQ3RCLFFBQVE7QUFDTixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGVBQWUsTUFBb0M7QUFDMUQsUUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixRQUFJO0FBQ0YsWUFBTSxJQUFJLElBQUksSUFBSSxNQUFNLFNBQVMsSUFBSTtBQUNyQyxVQUFJLENBQUMsYUFBYSxJQUFJLEVBQUUsU0FBUyxZQUFZLENBQUMsRUFBRyxRQUFPO0FBQ3hELFlBQU0sUUFBUSxFQUFFLFNBQVMsTUFBTSxHQUFHLEVBQUUsT0FBTyxPQUFPLEVBQUUsQ0FBQztBQUNyRCxVQUFJLENBQUMsU0FBUyxVQUFVLE9BQU8sVUFBVSxZQUFZLFVBQVUsU0FBVSxRQUFPO0FBQ2hGLGFBQU8sZ0JBQWdCLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsV0FBUyxVQUFVLElBQXNCO0FBQ3ZDLFVBQU0sT0FBTyxHQUFHLHNCQUFzQjtBQUN0QyxRQUFJLEtBQUssVUFBVSxLQUFLLEtBQUssV0FBVyxFQUFHLFFBQU87QUFDbEQsVUFBTSxRQUFRLE9BQU8saUJBQWlCLEVBQUU7QUFDeEMsV0FBTyxNQUFNLGVBQWUsWUFBWSxNQUFNLFlBQVk7QUFBQSxFQUM1RDtBQUVBLFdBQVMsc0JBQXNCLElBQTZCO0FBQzFELFdBQU8sR0FBRyxRQUFRLFNBQVMsS0FBSyxHQUFHLFFBQVEsaUNBQWlDO0FBQUEsRUFDOUU7QUFFQSxXQUFTLGNBQWMsV0FBNkI7QUFDbEQsVUFBTSxRQUFRLFVBQVUsZUFBZSxJQUFJLFlBQVk7QUFDdkQsUUFBSSxDQUFDLEtBQUssU0FBUyxhQUFhLEVBQUcsUUFBTztBQUMxQyxlQUFXLFFBQVEsTUFBTSxLQUFLLFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxHQUFHO0FBQ3BFLFlBQU0sU0FBUyxlQUFlLEtBQUssYUFBYSxNQUFNLENBQUM7QUFDdkQsVUFBSSxVQUFVLGtCQUFrQixJQUFJLE1BQU0sRUFBRyxRQUFPO0FBQUEsSUFDdEQ7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFdBQVMsZUFBZSxXQUE2QjtBQUNuRCxlQUFXLFFBQVEsTUFBTSxLQUFLLFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxHQUFHO0FBQ3BFLFlBQU0sUUFBUSxjQUFjLEtBQUssYUFBYSxNQUFNLENBQUM7QUFDckQsVUFBSSxDQUFDLE1BQU87QUFDWixVQUFJLGtCQUFrQixJQUFJLE1BQU0sTUFBTSxFQUFHLFFBQU87QUFDaEQsVUFBSSx1QkFBdUIsSUFBSSxNQUFNLEVBQUUsRUFBRyxRQUFPO0FBQUEsSUFDbkQ7QUFDQSxXQUFPLGNBQWMsU0FBUztBQUFBLEVBQ2hDO0FBRUEsV0FBUyx3QkFBOEI7QUFDckMsc0JBQWtCO0FBQ2xCLFFBQUksQ0FBQyxpQkFBaUIsa0JBQWtCLFNBQVMsRUFBRztBQUNwRCxVQUFNLFlBQVk7QUFBQSxNQUNoQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxVQUFNLE9BQU8sb0JBQUksSUFBYTtBQUM5QixRQUFJLFVBQVU7QUFDZCxlQUFXLE9BQU8sV0FBVztBQUMzQixpQkFBVyxNQUFNLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixHQUFHLENBQUMsR0FBRztBQUMzRCxZQUFJLEtBQUssSUFBSSxFQUFFLEtBQUssaUJBQWlCLElBQUksRUFBRSxFQUFHO0FBQzlDLGFBQUssSUFBSSxFQUFFO0FBQ1gsYUFBSyxHQUFHLGVBQWUsSUFBSSxLQUFLLEVBQUUsWUFBWSxNQUFNLFlBQWE7QUFDakUsWUFBSSxDQUFDLFVBQVUsRUFBRSxFQUFHO0FBQ3BCLGNBQU0sWUFBWSxzQkFBc0IsRUFBRTtBQUMxQyxZQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsU0FBUyxFQUFHO0FBQzlDLHlCQUFpQixJQUFJLEVBQUU7QUFDdkIsWUFBSTtBQUNGLFVBQUMsR0FBbUIsTUFBTTtBQUMxQixxQkFBVztBQUFBLFFBQ2IsUUFBUTtBQUFBLFFBRVI7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFFBQUksVUFBVSxHQUFHO0FBQ2YsY0FBUSxRQUFRLFlBQVksRUFBRSxNQUFNLHNCQUFzQixPQUFPLFFBQVEsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUFBLElBQzVGO0FBQUEsRUFDRjtBQUVBLFdBQVMsbUJBQW1CLFFBQVEseUJBQStCO0FBQ2pFLFFBQUksb0JBQW9CLEtBQU07QUFDOUIsc0JBQWtCLFdBQVcsdUJBQXVCLEtBQUs7QUFBQSxFQUMzRDtBQUVBLGlCQUFlLHVCQUFzQztBQUNuRCxRQUFJO0FBQ0YsWUFBTSxXQUFXLE1BQU0sUUFBUSxRQUFRLFlBQVk7QUFBQSxRQUNqRCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0QsWUFBTSxNQUFNLFlBQVksT0FBTyxhQUFhLFdBQVksV0FBcUMsQ0FBQztBQUM5RixzQkFBZ0IsSUFBSSxZQUFZO0FBQ2hDLDBCQUFvQixJQUFJO0FBQUEsU0FDckIsSUFBSSxlQUFlLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksRUFBRSxRQUFRLE1BQU0sRUFBRSxDQUFDO0FBQUEsTUFDdEU7QUFDQSwrQkFBeUIsSUFBSSxJQUFJLElBQUksb0JBQW9CLENBQUMsQ0FBQztBQUMzRCx5QkFBbUIsQ0FBQztBQUFBLElBQ3RCLFFBQVE7QUFDTixzQkFBZ0I7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLHdCQUE4QjtBQUNyQyxVQUFNLE9BQU8sU0FBUyxtQkFBbUIsU0FBUztBQUNsRCxRQUFJLENBQUMsTUFBTTtBQUNULGlCQUFXLHVCQUF1QixHQUFHO0FBQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sV0FBVyxJQUFJLGlCQUFpQixNQUFNLG1CQUFtQixDQUFDO0FBQ2hFLGFBQVMsUUFBUSxNQUFNLEVBQUUsV0FBVyxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBQ3pELFdBQU8saUJBQWlCLFVBQVUsTUFBTSxtQkFBbUIsR0FBRyxFQUFFLFNBQVMsS0FBSyxDQUFDO0FBQy9FLFNBQUsscUJBQXFCO0FBQzFCLGdCQUFZLE1BQU07QUFDaEIsV0FBSyxxQkFBcUI7QUFBQSxJQUM1QixHQUFHLGNBQWM7QUFBQSxFQUNuQjtBQUVBLHdCQUFzQjtBQUV0QixXQUFTLHdCQUF3QixLQUF1QjtBQUN0RCxRQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsU0FBVSxRQUFPO0FBQzVDLFdBQVEsSUFBMkMseUJBQXlCO0FBQUEsRUFDOUU7QUFFQSxXQUFTLGtCQUFrQixJQUEwRDtBQUNuRixXQUFPLGNBQWMsb0JBQW9CLGNBQWM7QUFBQSxFQUN6RDtBQUVBLFdBQVMsa0JBQWtCLElBQTRCO0FBQ3JELFFBQUk7QUFDRixTQUFHLE1BQU07QUFBQSxJQUNYLFFBQVE7QUFBQSxJQUVSO0FBQ0EsUUFBSTtBQUNGLFNBQUcsV0FBVztBQUNkLFNBQUcsVUFBVTtBQUNiLFNBQUcsZ0JBQWdCLFVBQVU7QUFDN0IsU0FBRyxnQkFBZ0IsS0FBSztBQUN4QixTQUFHLE1BQU07QUFDVCxVQUFJLGVBQWUsR0FBSSxJQUFHLFlBQVk7QUFDdEMsaUJBQVcsVUFBVSxNQUFNLEtBQUssR0FBRyxpQkFBaUIsYUFBYSxDQUFDLEdBQUc7QUFDbkUsZUFBTyxnQkFBZ0IsS0FBSztBQUFBLE1BQzlCO0FBQ0EsU0FBRyxLQUFLO0FBQUEsSUFDVixRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLHdCQUE4QjtBQUNyQyw0QkFBd0I7QUFDeEIsUUFBSSxDQUFDLDRCQUE2QjtBQUNsQyxlQUFXLE1BQU0sTUFBTSxLQUFLLFNBQVMsaUJBQWlCLGFBQWEsQ0FBQyxHQUFHO0FBQ3JFLFVBQUksa0JBQWtCLEVBQUUsRUFBRyxtQkFBa0IsRUFBRTtBQUFBLElBQ2pEO0FBQUEsRUFDRjtBQUVBLFdBQVMseUJBQXlCLFFBQVEsZ0NBQXNDO0FBQzlFLFFBQUksQ0FBQywrQkFBK0IsMEJBQTBCLEtBQU07QUFDcEUsNEJBQXdCLFdBQVcsdUJBQXVCLEtBQUs7QUFBQSxFQUNqRTtBQUVBLFdBQVMseUJBQXlCLE9BQW9CO0FBQ3BELFFBQUksQ0FBQyw0QkFBNkI7QUFDbEMsUUFBSSxrQkFBa0IsTUFBTSxNQUFNLEVBQUcsbUJBQWtCLE1BQU0sTUFBTTtBQUFBLEVBQ3JFO0FBRUEsV0FBUyx3QkFBd0IsSUFBbUI7QUFDbEQsUUFBSSxnQ0FBZ0MsR0FBSTtBQUN4QyxrQ0FBOEI7QUFFOUIsUUFBSSxJQUFJO0FBQ04sWUFBTSxPQUFPLFNBQVMsbUJBQW1CLFNBQVM7QUFDbEQsVUFBSSxNQUFNO0FBQ1IsK0JBQXVCLElBQUksaUJBQWlCLE1BQU0seUJBQXlCLENBQUM7QUFDNUUsNkJBQXFCLFFBQVEsTUFBTTtBQUFBLFVBQ2pDLFdBQVc7QUFBQSxVQUNYLFNBQVM7QUFBQSxVQUNULFlBQVk7QUFBQSxVQUNaLGlCQUFpQixDQUFDLEtBQUs7QUFBQSxRQUN6QixDQUFDO0FBQUEsTUFDSDtBQUNBLGlCQUFXLGFBQWEsNEJBQTRCO0FBQ2xELGlCQUFTLGlCQUFpQixXQUFXLDBCQUEwQixJQUFJO0FBQUEsTUFDckU7QUFDQSxnQ0FBMEIsWUFBWSx1QkFBdUIsdUJBQXVCO0FBQ3BGLCtCQUF5QixDQUFDO0FBQzFCO0FBQUEsSUFDRjtBQUVBLFFBQUksc0JBQXNCO0FBQ3hCLDJCQUFxQixXQUFXO0FBQ2hDLDZCQUF1QjtBQUFBLElBQ3pCO0FBQ0EsUUFBSSwwQkFBMEIsTUFBTTtBQUNsQyxtQkFBYSxxQkFBcUI7QUFDbEMsOEJBQXdCO0FBQUEsSUFDMUI7QUFDQSxRQUFJLDRCQUE0QixNQUFNO0FBQ3BDLG9CQUFjLHVCQUF1QjtBQUNyQyxnQ0FBMEI7QUFBQSxJQUM1QjtBQUNBLGVBQVcsYUFBYSw0QkFBNEI7QUFDbEQsZUFBUyxvQkFBb0IsV0FBVywwQkFBMEIsSUFBSTtBQUFBLElBQ3hFO0FBQUEsRUFDRjtBQUVBLGlCQUFlLDhCQUE2QztBQUMxRCxRQUFJO0FBQ0YsWUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxVQUFVO0FBQ3pELDhCQUF3Qix3QkFBd0IsT0FBTyxRQUFRLENBQUM7QUFBQSxJQUNsRSxRQUFRO0FBQ04sOEJBQXdCLEtBQUs7QUFBQSxJQUMvQjtBQUFBLEVBQ0Y7QUFFQSxVQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsU0FBUyxhQUFhO0FBQzNELFFBQUksYUFBYSxXQUFXLENBQUMsUUFBUSxTQUFVO0FBQy9DLDRCQUF3Qix3QkFBd0IsUUFBUSxTQUFTLFFBQVEsQ0FBQztBQUFBLEVBQzVFLENBQUM7QUFFRCxPQUFLLDRCQUE0QjtBQUVqQyxTQUFPLGlCQUFpQixXQUFXLENBQUMsVUFBd0I7QUFDMUQsUUFBSSxNQUFNLFdBQVcsT0FBUTtBQUM3QixVQUFNLE9BQU8sTUFBTTtBQUNuQixRQUFJLENBQUMsUUFBUSxPQUFPLFNBQVMsU0FBVTtBQUN2QyxVQUFNLElBQUk7QUFFVixRQUFJLEVBQUUsV0FBVyxPQUFPO0FBQ3RCLGNBQVEsUUFDTCxZQUFZO0FBQUEsUUFDWCxNQUFNO0FBQUEsUUFDTixLQUFLLE9BQU8sRUFBRSxRQUFRLFdBQVcsRUFBRSxNQUFNLFNBQVM7QUFBQSxNQUNwRCxDQUFDLEVBQ0EsTUFBTSxNQUFNO0FBQUEsTUFBQyxDQUFDO0FBQ2pCO0FBQUEsSUFDRjtBQUVBLFFBQUksRUFBRSxXQUFXLE9BQVE7QUFDekIsVUFBTSxXQUFXLE9BQU8sRUFBRSxhQUFhLFdBQVcsRUFBRSxXQUFXO0FBQy9ELFVBQU0sTUFBTSxPQUFPLEVBQUUsUUFBUSxXQUFXLEVBQUUsTUFBTTtBQUNoRCxVQUFNLFVBQVUsT0FBTyxFQUFFLGFBQWEsV0FBVyxFQUFFLFdBQVcsU0FBUztBQUN2RSxVQUFNLFdBQVcsRUFBRTtBQUNuQixRQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sYUFBYSxPQUFXO0FBQ2pELFlBQVEsUUFDTCxZQUFZLEVBQUUsTUFBTSxtQkFBbUIsVUFBVSxLQUFLLFNBQVMsU0FBUyxDQUFDLEVBQ3pFLE1BQU0sQ0FBQyxRQUFRO0FBQ2QsY0FBUSxLQUFLLG9DQUFvQyxHQUFHO0FBQUEsSUFDdEQsQ0FBQztBQUFBLEVBQ0wsQ0FBQzsiLAogICJuYW1lcyI6IFtdCn0K
