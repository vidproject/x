"use strict";
(() => {
  // extension/src/content.ts
  var TARGET = "IMM_ARCHIVE_CAPTURE";
  var READY = "IMM_ARCHIVE_HOOK_READY";
  void browser.runtime.sendMessage({ type: "content-alive", url: location.href }).catch((err) => {
    console.warn("[imm-archive] content-alive ping failed", err);
  });
  function fallbackInject() {
    try {
      const src = browser.runtime.getURL("page-hook.js");
      const script = document.createElement("script");
      script.src = src;
      script.async = false;
      script.dataset.immArchive = "1";
      (document.head || document.documentElement).appendChild(script);
      script.onload = () => script.remove();
      script.onerror = () => {
        browser.runtime.sendMessage({
          type: "log-content-event",
          level: "warn",
          msg: "inline page-hook injection blocked (CSP); relying on MAIN-world content script",
          url: location.href
        }).catch(() => {
        });
      };
    } catch (err) {
      console.warn("[imm-archive] inline page-hook injection threw", err);
    }
  }
  fallbackInject();
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== "object") return;
    const d = data;
    if (d.source === READY) {
      browser.runtime.sendMessage({
        type: "page-hook-active",
        url: typeof d.url === "string" ? d.url : location.href
      }).catch(() => {
      });
      return;
    }
    if (d.source !== TARGET) return;
    const endpoint = typeof d.endpoint === "string" ? d.endpoint : null;
    const url = typeof d.url === "string" ? d.url : null;
    const pageUrl = typeof d.page_url === "string" ? d.page_url : location.href;
    const response = d.response;
    if (!endpoint || !url || response === void 0) return;
    browser.runtime.sendMessage({ type: "graphql-capture", endpoint, url, pageUrl, response }).catch((err) => {
      console.warn("[imm-archive] sendMessage failed", err);
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbnRlbnQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKlxuICogY29udGVudC50cyBcdTIwMTQgY29udGVudC1zY3JpcHQgY29udGV4dCAoaXNvbGF0ZWQgd29ybGQpLlxuICpcbiAqIFRoZSBhY3R1YWwgcGFnZS1ob29rICh3aGljaCBwYXRjaGVzIGBmZXRjaGAgLyBgWEhSYCkgaXMgZGVjbGFyZWQgYXMgYVxuICogc2VwYXJhdGUgY29udGVudCBzY3JpcHQgd2l0aCBgd29ybGQ6IFwiTUFJTlwiYCBpbiB0aGUgbWFuaWZlc3QsIHNvIGl0IHJ1bnNcbiAqIGluIHRoZSBwYWdlIHdvcmxkIGRpcmVjdGx5IHdpdGhvdXQgdXMgaGF2aW5nIHRvIGluamVjdCBhIDxzY3JpcHQ+IHRhZyBcdTIwMTRcbiAqIHdoaWNoIFgncyBub25jZS1iYXNlZCBDU1Agd291bGQgYmxvY2suXG4gKlxuICogVGhpcyBmaWxlIGRvZXMgdGhyZWUgdGhpbmdzOlxuICpcbiAqICAgMS4gUGluZ3MgdGhlIGJhY2tncm91bmQgb24gbG9hZCBzbyB0aGUgYWN0aXZpdHkgdGFpbCBjb25maXJtcyB0aGVcbiAqICAgICAgY29udGVudCBzY3JpcHQgcmVhY2hlZCB0aGUgWCBwYWdlICh1c2VmdWwgd2hlbiBkaWFnbm9zaW5nIGEgc2lsZW50XG4gKiAgICAgIFwiY2FwdHVyZS1ub3cgZG9lcyBub3RoaW5nXCIgZmFpbHVyZSkuXG4gKiAgIDIuIEFzIGEgZGVmZW5zaXZlIGZhbGxiYWNrLCBhbHNvIHRyaWVzIHRvIGluamVjdCBgcGFnZS1ob29rLmpzYCB2aWEgYVxuICogICAgICBzY3JpcHQgdGFnLiBIYXJtbGVzcyBvbiBtb2Rlcm4gRmlyZWZveCAodGhlIHBhZ2UtaG9vaydzIFRBRyBndWFyZFxuICogICAgICBwcmV2ZW50cyBkb3VibGUtaW5pdCk7IGNvdmVycyB0aGUgcmFyZSBjYXNlIHdoZXJlIHRoZSBNQUlOLXdvcmxkXG4gKiAgICAgIGNvbnRlbnQgc2NyaXB0IGVudHJ5IGlzbid0IGhvbm9yZWQuXG4gKiAgIDMuIEJyaWRnZXMgYHdpbmRvdy5wb3N0TWVzc2FnZWAgZnJvbSB0aGUgcGFnZSBob29rIHRvIHRoZSBiYWNrZ3JvdW5kOlxuICogICAgICBib3RoIHRoZSBgKl9SRUFEWWAgYm9vdCBwaW5nIGFuZCB0aGUgYElNTV9BUkNISVZFX0NBUFRVUkVgIHBheWxvYWRcbiAqICAgICAgZXZlbnRzLlxuICovXG5cbmNvbnN0IFRBUkdFVCA9ICdJTU1fQVJDSElWRV9DQVBUVVJFJztcbmNvbnN0IFJFQURZID0gJ0lNTV9BUkNISVZFX0hPT0tfUkVBRFknO1xuXG52b2lkIGJyb3dzZXIucnVudGltZVxuICAuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnY29udGVudC1hbGl2ZScsIHVybDogbG9jYXRpb24uaHJlZiB9KVxuICAuY2F0Y2goKGVycjogdW5rbm93bikgPT4ge1xuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBjb250ZW50LWFsaXZlIHBpbmcgZmFpbGVkJywgZXJyKTtcbiAgfSk7XG5cbmZ1bmN0aW9uIGZhbGxiYWNrSW5qZWN0KCk6IHZvaWQge1xuICB0cnkge1xuICAgIGNvbnN0IHNyYyA9IGJyb3dzZXIucnVudGltZS5nZXRVUkwoJ3BhZ2UtaG9vay5qcycpO1xuICAgIGNvbnN0IHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICAgIHNjcmlwdC5zcmMgPSBzcmM7XG4gICAgc2NyaXB0LmFzeW5jID0gZmFsc2U7XG4gICAgc2NyaXB0LmRhdGFzZXQuaW1tQXJjaGl2ZSA9ICcxJztcbiAgICAoZG9jdW1lbnQuaGVhZCB8fCBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpLmFwcGVuZENoaWxkKHNjcmlwdCk7XG4gICAgc2NyaXB0Lm9ubG9hZCA9ICgpID0+IHNjcmlwdC5yZW1vdmUoKTtcbiAgICBzY3JpcHQub25lcnJvciA9ICgpID0+IHtcbiAgICAgIC8vIENTUCBwcm9iYWJseSBibG9ja2VkIHRoaXMuIE5vdCBmYXRhbCBcdTIwMTQgdGhlIE1BSU4td29ybGQgY29udGVudCBzY3JpcHRcbiAgICAgIC8vIGRlY2xhcmVkIGluIG1hbmlmZXN0Lmpzb24gaXMgdGhlIHByaW1hcnkgcGF0aC4gU3VyZmFjZSBhcyBhIGxvZyBzb1xuICAgICAgLy8gd2Uga25vdyB3aGF0IGhhcHBlbmVkIHdpdGhvdXQgbHlpbmcgYWJvdXQgc3VjY2Vzcy5cbiAgICAgIGJyb3dzZXIucnVudGltZVxuICAgICAgICAuc2VuZE1lc3NhZ2Uoe1xuICAgICAgICAgIHR5cGU6ICdsb2ctY29udGVudC1ldmVudCcsXG4gICAgICAgICAgbGV2ZWw6ICd3YXJuJyxcbiAgICAgICAgICBtc2c6ICdpbmxpbmUgcGFnZS1ob29rIGluamVjdGlvbiBibG9ja2VkIChDU1ApOyByZWx5aW5nIG9uIE1BSU4td29ybGQgY29udGVudCBzY3JpcHQnLFxuICAgICAgICAgIHVybDogbG9jYXRpb24uaHJlZixcbiAgICAgICAgfSlcbiAgICAgICAgLmNhdGNoKCgpID0+IHt9KTtcbiAgICB9O1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gaW5saW5lIHBhZ2UtaG9vayBpbmplY3Rpb24gdGhyZXcnLCBlcnIpO1xuICB9XG59XG5cbmZhbGxiYWNrSW5qZWN0KCk7XG5cbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgKGV2ZW50OiBNZXNzYWdlRXZlbnQpID0+IHtcbiAgaWYgKGV2ZW50LnNvdXJjZSAhPT0gd2luZG93KSByZXR1cm47XG4gIGNvbnN0IGRhdGEgPSBldmVudC5kYXRhIGFzIHVua25vd247XG4gIGlmICghZGF0YSB8fCB0eXBlb2YgZGF0YSAhPT0gJ29iamVjdCcpIHJldHVybjtcbiAgY29uc3QgZCA9IGRhdGEgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG5cbiAgaWYgKGQuc291cmNlID09PSBSRUFEWSkge1xuICAgIGJyb3dzZXIucnVudGltZVxuICAgICAgLnNlbmRNZXNzYWdlKHtcbiAgICAgICAgdHlwZTogJ3BhZ2UtaG9vay1hY3RpdmUnLFxuICAgICAgICB1cmw6IHR5cGVvZiBkLnVybCA9PT0gJ3N0cmluZycgPyBkLnVybCA6IGxvY2F0aW9uLmhyZWYsXG4gICAgICB9KVxuICAgICAgLmNhdGNoKCgpID0+IHt9KTtcbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoZC5zb3VyY2UgIT09IFRBUkdFVCkgcmV0dXJuO1xuICBjb25zdCBlbmRwb2ludCA9IHR5cGVvZiBkLmVuZHBvaW50ID09PSAnc3RyaW5nJyA/IGQuZW5kcG9pbnQgOiBudWxsO1xuICBjb25zdCB1cmwgPSB0eXBlb2YgZC51cmwgPT09ICdzdHJpbmcnID8gZC51cmwgOiBudWxsO1xuICBjb25zdCBwYWdlVXJsID0gdHlwZW9mIGQucGFnZV91cmwgPT09ICdzdHJpbmcnID8gZC5wYWdlX3VybCA6IGxvY2F0aW9uLmhyZWY7XG4gIGNvbnN0IHJlc3BvbnNlID0gZC5yZXNwb25zZTtcbiAgaWYgKCFlbmRwb2ludCB8fCAhdXJsIHx8IHJlc3BvbnNlID09PSB1bmRlZmluZWQpIHJldHVybjtcbiAgYnJvd3Nlci5ydW50aW1lXG4gICAgLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2dyYXBocWwtY2FwdHVyZScsIGVuZHBvaW50LCB1cmwsIHBhZ2VVcmwsIHJlc3BvbnNlIH0pXG4gICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBzZW5kTWVzc2FnZSBmYWlsZWQnLCBlcnIpO1xuICAgIH0pO1xufSk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFzQkEsTUFBTSxTQUFTO0FBQ2YsTUFBTSxRQUFRO0FBRWQsT0FBSyxRQUFRLFFBQ1YsWUFBWSxFQUFFLE1BQU0saUJBQWlCLEtBQUssU0FBUyxLQUFLLENBQUMsRUFDekQsTUFBTSxDQUFDLFFBQWlCO0FBQ3ZCLFlBQVEsS0FBSywyQ0FBMkMsR0FBRztBQUFBLEVBQzdELENBQUM7QUFFSCxXQUFTLGlCQUF1QjtBQUM5QixRQUFJO0FBQ0YsWUFBTSxNQUFNLFFBQVEsUUFBUSxPQUFPLGNBQWM7QUFDakQsWUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0FBQzlDLGFBQU8sTUFBTTtBQUNiLGFBQU8sUUFBUTtBQUNmLGFBQU8sUUFBUSxhQUFhO0FBQzVCLE9BQUMsU0FBUyxRQUFRLFNBQVMsaUJBQWlCLFlBQVksTUFBTTtBQUM5RCxhQUFPLFNBQVMsTUFBTSxPQUFPLE9BQU87QUFDcEMsYUFBTyxVQUFVLE1BQU07QUFJckIsZ0JBQVEsUUFDTCxZQUFZO0FBQUEsVUFDWCxNQUFNO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxLQUFLO0FBQUEsVUFDTCxLQUFLLFNBQVM7QUFBQSxRQUNoQixDQUFDLEVBQ0EsTUFBTSxNQUFNO0FBQUEsUUFBQyxDQUFDO0FBQUEsTUFDbkI7QUFBQSxJQUNGLFNBQVMsS0FBSztBQUNaLGNBQVEsS0FBSyxrREFBa0QsR0FBRztBQUFBLElBQ3BFO0FBQUEsRUFDRjtBQUVBLGlCQUFlO0FBRWYsU0FBTyxpQkFBaUIsV0FBVyxDQUFDLFVBQXdCO0FBQzFELFFBQUksTUFBTSxXQUFXLE9BQVE7QUFDN0IsVUFBTSxPQUFPLE1BQU07QUFDbkIsUUFBSSxDQUFDLFFBQVEsT0FBTyxTQUFTLFNBQVU7QUFDdkMsVUFBTSxJQUFJO0FBRVYsUUFBSSxFQUFFLFdBQVcsT0FBTztBQUN0QixjQUFRLFFBQ0wsWUFBWTtBQUFBLFFBQ1gsTUFBTTtBQUFBLFFBQ04sS0FBSyxPQUFPLEVBQUUsUUFBUSxXQUFXLEVBQUUsTUFBTSxTQUFTO0FBQUEsTUFDcEQsQ0FBQyxFQUNBLE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUNqQjtBQUFBLElBQ0Y7QUFFQSxRQUFJLEVBQUUsV0FBVyxPQUFRO0FBQ3pCLFVBQU0sV0FBVyxPQUFPLEVBQUUsYUFBYSxXQUFXLEVBQUUsV0FBVztBQUMvRCxVQUFNLE1BQU0sT0FBTyxFQUFFLFFBQVEsV0FBVyxFQUFFLE1BQU07QUFDaEQsVUFBTSxVQUFVLE9BQU8sRUFBRSxhQUFhLFdBQVcsRUFBRSxXQUFXLFNBQVM7QUFDdkUsVUFBTSxXQUFXLEVBQUU7QUFDbkIsUUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLGFBQWEsT0FBVztBQUNqRCxZQUFRLFFBQ0wsWUFBWSxFQUFFLE1BQU0sbUJBQW1CLFVBQVUsS0FBSyxTQUFTLFNBQVMsQ0FBQyxFQUN6RSxNQUFNLENBQUMsUUFBUTtBQUNkLGNBQVEsS0FBSyxvQ0FBb0MsR0FBRztBQUFBLElBQ3RELENBQUM7QUFBQSxFQUNMLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
