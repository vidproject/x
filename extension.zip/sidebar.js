// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var recentTweetList = $("recent-tweet-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var updateExistingToggle = $("update-existing");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = isWriteAuthError(connection.error) ? "PAT can read repo but cannot write - set Contents: Read & Write" : "Auth error - check your PAT";
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  updateExistingToggle.checked = state.settings.updateExisting !== false;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  renderRecentTweets(state.recentTweetSightings);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
}
function renderRecentTweets(rows) {
  recentTweetList.replaceChildren();
  if (rows.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No tweets seen yet.";
    recentTweetList.append(li);
    return;
  }
  for (const row of rows.slice(0, 40)) {
    const li = document.createElement("li");
    li.className = `recent-tweet ${row.archive_status}`;
    const top = document.createElement("div");
    top.className = "tweet-head";
    const link = document.createElement("a");
    link.className = "tweet-handle";
    link.href = row.tweet_url;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = `@${row.account_handle}`;
    const status = document.createElement("span");
    status.className = `tweet-pill ${row.archive_status}`;
    status.textContent = row.archive_status === "saved" ? "saved" : "new";
    top.append(link, status);
    const text = document.createElement("div");
    text.className = "tweet-text";
    text.textContent = truncateText(row.text, 140);
    const meta = document.createElement("div");
    meta.className = "tweet-meta";
    meta.textContent = `${formatTweetAction(row.action)} \xB7 ${row.tweet_type} \xB7 posted ${fmtRel(row.posted_at)}`;
    li.append(top, text, meta);
    recentTweetList.append(li);
  }
}
function formatTweetAction(action) {
  if (action === "buffered") return "buffered";
  if (action === "unchanged") return "unchanged";
  return "skipped";
}
function truncateText(text, max) {
  const compact = text.replace(/\s+/g, " ").trim();
  return compact.length <= max ? compact : `${compact.slice(0, max - 1)}\u2026`;
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    const parts = [
      `${fmtNum(as.scrollCount)} scrolls`,
      `${fmtNum(as.ingestedNewCount)} new buffered`,
      `${fmtNum(as.ingestedExistingCount)} old buffered`
    ];
    if (as.skippedOldCount > 0) parts.push(`${fmtNum(as.skippedOldCount)} old skipped`);
    parts.push(`${fmtNum(as.expandedCount)} expanded`);
    autoScrollProgress.textContent = parts.join(" \xB7 ");
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
updateExistingToggle.addEventListener("change", () => {
  void send({ type: "toggle-update-existing", on: updateExistingToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgZW5hYmxlZDogdHJ1ZSxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxuICB1cGRhdGVFeGlzdGluZzogdHJ1ZSxcbn07XG5cbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XG5cbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1JhcGlkUmVzcG9uc2U0NycsIGxhYmVsOiAnUmFwaWQgUmVzcG9uc2UgNDcnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG5dO1xuXG4vLyBHcmFwaFFMIGVuZHBvaW50IG5hbWVzIHdlIGNhcmUgYWJvdXQgKG1hdGNoZWQgYnkgc3Vic3RyaW5nIGFnYWluc3QgVVJMIHBhdGgpLlxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG4gICdMaWtlcycsXG4gICdCb29rbWFya3MnLFxuICAnSG9tZVRpbWVsaW5lJyxcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXG4gICdTZWFyY2hUaW1lbGluZScsXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxuXSk7XG5cbi8vIEVuZHBvaW50cyB0aGF0IGNhcnJ5IENvbW11bml0eSBOb3RlIGJvZGllcyBcdTIwMTQgY2FwdHVyZWQgZm9yIGNvbXBsZXRlbmVzcyBidXRcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXG5leHBvcnQgY29uc3QgQklSRFdBVENIX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnQmlyZHdhdGNoRmV0Y2hPbmVOb3RlJyxcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxuXSk7XG5cbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxuLy8gdG8gbGVhcm4gYWNjb3VudF9pZCA8LT4gaGFuZGxlIGJpbmRpbmdzKS5cbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcblxuLy8gRW5kcG9pbnRzIHdob3NlIHJlc3BvbnNlcyBhcmUgc2NvcGVkIHRvIGEgcGFydGljdWxhciBhY2NvdW50IG9yXG4vLyBjb252ZXJzYXRpb24gXHUyMDE0IGkuZS4gdmlzaXRpbmcgYC88aGFuZGxlPmAgLyBgLzxoYW5kbGU+L3dpdGhfcmVwbGllc2AsXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcbi8vIGVpdGhlciBhdXRob3JlZCBieSB0aGUgdHJhY2tlZCBhY2NvdW50IG9yIGRpcmVjdGx5IHJlZmVyZW5jZWQgYnkgdGhlbVxuLy8gKHJldHdlZXRlZCwgcXVvdGVkLCByZXBsaWVkIHRvKSwgc28gd2Uga2VlcCBldmVyeXRoaW5nIHdlIHNlZSByYXRoZXJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcbi8vIGFjY291bnQgc3RpbGwgZ2V0cyBpdHMgb3JpZ2luYWwtdHdlZXQgY29udGVudCBhcmNoaXZlZC5cbi8vXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcbi8vIHN0aWxsIGdldCBmaWx0ZXJlZCB0byB0cmFja2VkLWhhbmRsZSBhdXRob3JzIFx1MjAxNCBzZWUgdGhlIHNwZWMnc1xuLy8gXCJCcm93c2luZyBteSBob21lIHRpbWVsaW5lIGlzIGlnbm9yZWRcIiBydWxlLlxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuXSk7XG5cbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxuZXhwb3J0IGNvbnN0IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCA9IDIwMDtcblxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxuZXhwb3J0IGNvbnN0IEZMVVNIX0lETEVfTVMgPSA0NV8wMDA7XG5cbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxuZXhwb3J0IGNvbnN0IEZMVVNIX0FMQVJNX01JTlVURVMgPSAxO1xuXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXG5leHBvcnQgY29uc3QgQUNUSVZJVFlfVEFJTF9NQVggPSAyNTA7XG5cbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cbmV4cG9ydCBjb25zdCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyA9IDEwICogNjAgKiAxMDAwO1xuXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcbiIsICIvKipcbiAqIHNpZGViYXIudHMgXHUyMDE0IFVJIGZvciB0aGUgcGVyc2lzdGVudCBzaWRlYmFyLlxuICpcbiAqIFNpZGViYXJzIGluIEZpcmVmb3ggc3RheSBvcGVuIGFjcm9zcyB0YWIvd2luZG93IHN3aXRjaGVzLCB3aGljaCBpcyB0aGVcbiAqIGludGVuZGVkIHBlcnNpc3RlbmNlIG1vZGVsLiBUaGlzIG1vZHVsZSByZW5kZXJzIHN0YXRlIHB1c2hlZCBmcm9tIHRoZVxuICogYmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciBhbmQgZm9yd2FyZHMgdXNlciBjb21tYW5kcyBiYWNrLlxuICovXG5cbmltcG9ydCB7IEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcbmltcG9ydCB0eXBlIHsgRXh0ZW5zaW9uU3RhdGUsIExvZ0V2ZW50LCBSdW50aW1lTWVzc2FnZSwgVHdlZXRTaWdodGluZyB9IGZyb20gJy4vbGliL3R5cGVzLmpzJztcblxuY29uc3QgJCA9IDxUIGV4dGVuZHMgSFRNTEVsZW1lbnQgPSBIVE1MRWxlbWVudD4oaWQ6IHN0cmluZyk6IFQgPT4ge1xuICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcbiAgaWYgKCFlbCkgdGhyb3cgbmV3IEVycm9yKGBtaXNzaW5nIGVsZW1lbnQgIyR7aWR9YCk7XG4gIHJldHVybiBlbCBhcyBUO1xufTtcblxuY29uc3QgY29ubkRvdCA9ICQoJ2Nvbm4tZG90Jyk7XG5jb25zdCBjb25uVGV4dCA9ICQ8SFRNTFNwYW5FbGVtZW50PignY29ubi10ZXh0Jyk7XG5jb25zdCBhY2NvdW50TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjY291bnQtbGlzdCcpO1xuY29uc3QgcmVjZW50VHdlZXRMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PigncmVjZW50LXR3ZWV0LWxpc3QnKTtcbmNvbnN0IGFjdGl2aXR5TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjdGl2aXR5LWxpc3QnKTtcbmNvbnN0IGF1dG9Ub2dnbGUgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdhdXRvLWNhcHR1cmUnKTtcbmNvbnN0IHVwZGF0ZUV4aXN0aW5nVG9nZ2xlID0gJDxIVE1MSW5wdXRFbGVtZW50PigndXBkYXRlLWV4aXN0aW5nJyk7XG5jb25zdCBjYXB0dXJlQWxsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtYWxsJyk7XG5jb25zdCBjYXB0dXJlVGhpc0J0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjYXB0dXJlLXRoaXMnKTtcbmNvbnN0IGZsdXNoQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2ZsdXNoLWFsbCcpO1xuY29uc3Qgb3B0aW9uc0xpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi1vcHRpb25zJyk7XG5jb25zdCB2aWV3ZXJMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ29wZW4tdmlld2VyJyk7XG5jb25zdCBjbGVhckFjdEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjbGVhci1hY3Rpdml0eScpO1xuY29uc3QgZXh0VmVyc2lvbkVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdleHQtdmVyc2lvbicpO1xuY29uc3QgbWFzdGVyU3dpdGNoID0gJDxIVE1MSW5wdXRFbGVtZW50PignbWFzdGVyLXN3aXRjaCcpO1xuY29uc3QgbWFzdGVyTGFiZWwgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ21hc3Rlci1sYWJlbCcpO1xuY29uc3QgYXV0b1Njcm9sbEludGVydmFsID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1zY3JvbGwtaW50ZXJ2YWwnKTtcbmNvbnN0IGF1dG9TY3JvbGxTZWNzRWwgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXNlY3MnKTtcbmNvbnN0IGF1dG9TY3JvbGxTdGF0dXMgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXN0YXR1cycpO1xuY29uc3QgYXV0b1Njcm9sbFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXN0YXJ0Jyk7XG5jb25zdCBhdXRvU2Nyb2xsQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLWNhbmNlbCcpO1xuY29uc3QgYXV0b1Njcm9sbFByb2dyZXNzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1wcm9ncmVzcycpO1xuY29uc3QgcmVmZXRjaFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PigncmVmZXRjaC1zZWN0aW9uJyk7XG5jb25zdCByZWZldGNoQ291bnQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3JlZmV0Y2gtY291bnQnKTtcbmNvbnN0IHJlZmV0Y2hTdGFydEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZWZldGNoLXN0YXJ0Jyk7XG5jb25zdCByZWZldGNoQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZmV0Y2gtY2FuY2VsJyk7XG5jb25zdCByZWZldGNoUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3JlZmV0Y2gtcHJvZ3Jlc3MnKTtcbmNvbnN0IG1lZGlhQ3Jhd2xTZWN0aW9uID0gJDxIVE1MRWxlbWVudD4oJ21lZGlhLWNyYXdsLXNlY3Rpb24nKTtcbmNvbnN0IG1lZGlhQ3Jhd2xDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtY291bnQnKTtcbmNvbnN0IG1lZGlhQ3Jhd2xTdGFydEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1zdGFydCcpO1xuY29uc3QgbWVkaWFDcmF3bENhbmNlbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1jYW5jZWwnKTtcbmNvbnN0IG1lZGlhQ3Jhd2xQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtcHJvZ3Jlc3MnKTtcbmNvbnN0IHB1cmdlTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdwdXJnZS11bnJlbGF0ZWQnKTtcblxubGV0IGxhc3RTdGF0ZTogRXh0ZW5zaW9uU3RhdGUgfCBudWxsID0gbnVsbDtcblxuYXN5bmMgZnVuY3Rpb24gc2VuZDxUPihtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTxUPiB7XG4gIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKSBhcyBQcm9taXNlPFQ+O1xufVxuXG5mdW5jdGlvbiBzZXRDb25uU3RhdHVzKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCB7IGNvbm5lY3Rpb24sIHNldHRpbmdzIH0gPSBzdGF0ZTtcbiAgbGV0IGNscyA9ICcnO1xuICBsZXQgdGV4dCA9ICcnO1xuICAvLyBPbmx5IHdhcm4gd2hlbiB0aGUgY29uZmlndXJlZCBicmFuY2ggZ2VudWluZWx5IGRvZXNuJ3QgZXhpc3Qgb24gdGhlXG4gIC8vIHJlbW90ZS4gQSBub24tZGVmYXVsdCBicmFuY2ggdGhhdCBleGlzdHMgaXMgZmluZSBcdTIwMTQgY2FwdHVyaW5nIGludG8gYVxuICAvLyB3b3JraW5nIGJyYW5jaCBpcyByb3V0aW5lIFx1MjAxNCBzbyB0aGUgbWVyZSBgIT09YCB0byBkZWZhdWx0X2JyYW5jaCBpcyBub3RcbiAgLy8gYSBwcm9ibGVtIGFuZCBzaG91bGRuJ3Qgc2hvdXQgaW4gdGhlIGhlYWRlci5cbiAgY29uc3QgYnJhbmNoTWlzc2luZyA9XG4gICAgY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycgJiYgc2V0dGluZ3MuYnJhbmNoICYmIGNvbm5lY3Rpb24uY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gZmFsc2U7XG4gIGlmICghc2V0dGluZ3MucGF0U2V0KSB7XG4gICAgY2xzID0gJ3dhcm4nO1xuICAgIHRleHQgPSAnTm90IGNvbmZpZ3VyZWQgXHUyMDE0IG9wZW4gU2V0dGluZ3MnO1xuICB9IGVsc2UgaWYgKGJyYW5jaE1pc3NpbmcpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gYEJyYW5jaCBcIiR7c2V0dGluZ3MuYnJhbmNofVwiIGRvZXMgbm90IGV4aXN0IG9uICR7c2V0dGluZ3Mub3duZXJ9LyR7c2V0dGluZ3MucmVwb30gXHUyMDE0IGNvbW1pdHMgd2lsbCA0MjIuIFNldCBicmFuY2ggdG8gXCIke2Nvbm5lY3Rpb24uZGVmYXVsdEJyYW5jaCA/PyAnbWFzdGVyJ31cIiBpbiBTZXR0aW5ncy5gO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnb2snKSB7XG4gICAgY2xzID0gJ29rJztcbiAgICB0ZXh0ID0gYENvbm5lY3RlZCBhcyBAJHtjb25uZWN0aW9uLmxvZ2luID8/ICc/J30gdG8gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTAwQjcgXHUyMDI2JHtzZXR0aW5ncy5wYXRTdWZmaXh9YDtcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ2F1dGgtZXJyb3InKSB7XG4gICAgY2xzID0gJ2Vycic7XG4gICAgdGV4dCA9IGlzV3JpdGVBdXRoRXJyb3IoY29ubmVjdGlvbi5lcnJvcilcbiAgICAgID8gJ1BBVCBjYW4gcmVhZCByZXBvIGJ1dCBjYW5ub3Qgd3JpdGUgLSBzZXQgQ29udGVudHM6IFJlYWQgJiBXcml0ZSdcbiAgICAgIDogJ0F1dGggZXJyb3IgLSBjaGVjayB5b3VyIFBBVCc7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnKSB7XG4gICAgY2xzID0gJ3dhcm4nO1xuICAgIGNvbnN0IHJlc2V0cyA9IGZtdFJhdGVMaW1pdFJlc2V0KGNvbm5lY3Rpb24ucmF0ZUxpbWl0UmVzZXRBdCk7XG4gICAgdGV4dCA9IHJlc2V0c1xuICAgICAgPyBgR2l0SHViIHJhdGUtbGltaXRlZCBcdTIwMTQgcmVzZXRzICR7cmVzZXRzfWBcbiAgICAgIDogJ0dpdEh1YiByYXRlLWxpbWl0ZWQgXHUyMDE0IGNhcHR1cmVzIHdpbGwgcmV0cnknO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnbmV0d29yay1lcnJvcicpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gJ05ldHdvcmsgZXJyb3IgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpdml0eSc7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdub3QtY29uZmlndXJlZCcpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XG4gIH0gZWxzZSB7XG4gICAgY2xzID0gJyc7XG4gICAgdGV4dCA9ICdDaGVja2luZ1x1MjAyNic7XG4gIH1cbiAgY29ubkRvdC5jbGFzc05hbWUgPSBgZG90ICR7Y2xzfWA7XG4gIGNvbm5UZXh0LnRleHRDb250ZW50ID0gdGV4dDtcbiAgY29ublRleHQudGl0bGUgPSBjb25uZWN0aW9uLmVycm9yID8/ICcnO1xufVxuXG5mdW5jdGlvbiBmbXRSZWwoaXNvOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHtcbiAgaWYgKCFpc28pIHJldHVybiAnXHUyMDE0JztcbiAgY29uc3QgZCA9IERhdGUucGFyc2UoaXNvKTtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoZCkpIHJldHVybiAnXHUyMDE0JztcbiAgY29uc3Qgc2VjcyA9IE1hdGgubWF4KDAsIE1hdGgucm91bmQoKERhdGUubm93KCkgLSBkKSAvIDEwMDApKTtcbiAgaWYgKHNlY3MgPCA1KSByZXR1cm4gJ2p1c3Qgbm93JztcbiAgaWYgKHNlY3MgPCA2MCkgcmV0dXJuIGAke3NlY3N9cyBhZ29gO1xuICBjb25zdCBtaW5zID0gTWF0aC5yb3VuZChzZWNzIC8gNjApO1xuICBpZiAobWlucyA8IDYwKSByZXR1cm4gYCR7bWluc31tIGFnb2A7XG4gIGNvbnN0IGhvdXJzID0gTWF0aC5yb3VuZChtaW5zIC8gNjApO1xuICBpZiAoaG91cnMgPCAyNCkgcmV0dXJuIGAke2hvdXJzfWggYWdvYDtcbiAgY29uc3QgZGF5cyA9IE1hdGgucm91bmQoaG91cnMgLyAyNCk7XG4gIHJldHVybiBgJHtkYXlzfWQgYWdvYDtcbn1cblxuZnVuY3Rpb24gZm10UmF0ZUxpbWl0UmVzZXQoZXBvY2hTZWM6IG51bWJlciB8IG51bGwpOiBzdHJpbmcge1xuICBpZiAoZXBvY2hTZWMgPT09IG51bGwpIHJldHVybiAnJztcbiAgY29uc3QgZGVsdGFTZWMgPSBlcG9jaFNlYyAtIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICBpZiAoZGVsdGFTZWMgPD0gMCkgcmV0dXJuICdtb21lbnRhcmlseSc7XG4gIGNvbnN0IHdhbGxDbG9jayA9IG5ldyBEYXRlKGVwb2NoU2VjICogMTAwMCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7XG4gICAgaG91cjogJzItZGlnaXQnLFxuICAgIG1pbnV0ZTogJzItZGlnaXQnLFxuICB9KTtcbiAgaWYgKGRlbHRhU2VjIDwgNjApIHJldHVybiBgaW4gJHtkZWx0YVNlY31zICgke3dhbGxDbG9ja30pYDtcbiAgY29uc3QgbWlucyA9IE1hdGgucm91bmQoZGVsdGFTZWMgLyA2MCk7XG4gIGlmIChtaW5zIDwgNjApIHJldHVybiBgaW4gJHttaW5zfW0gKCR7d2FsbENsb2NrfSlgO1xuICBjb25zdCBob3VycyA9IE1hdGgucm91bmQobWlucyAvIDYwKTtcbiAgcmV0dXJuIGBpbiAke2hvdXJzfWggKCR7d2FsbENsb2NrfSlgO1xufVxuXG5mdW5jdGlvbiBmbXROdW0objogbnVtYmVyKTogc3RyaW5nIHtcbiAgcmV0dXJuIG4udG9Mb2NhbGVTdHJpbmcoJ2VuLVVTJyk7XG59XG5cbmZ1bmN0aW9uIGlzV3JpdGVBdXRoRXJyb3IobWVzc2FnZTogc3RyaW5nIHwgbnVsbCk6IGJvb2xlYW4ge1xuICByZXR1cm4gKFxuICAgIHR5cGVvZiBtZXNzYWdlID09PSAnc3RyaW5nJyAmJlxuICAgIC9SZXNvdXJjZSBub3QgYWNjZXNzaWJsZSBieSBwZXJzb25hbCBhY2Nlc3MgdG9rZW58XFwvZ2l0XFwvYmxvYnN8XFwvZ2l0XFwvcmVmcy9pLnRlc3QobWVzc2FnZSlcbiAgKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQWNjb3VudHMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGFjY291bnRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBpZiAoc3RhdGUuYWNjb3VudHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWNjb3VudHMgY29uZmlndXJlZC4nO1xuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3QgYSBvZiBzdGF0ZS5hY2NvdW50cykge1xuICAgIGNvbnN0IGMgPSBzdGF0ZS5jb3VudGVyc1thLmhhbmRsZV07XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9IGMgJiYgYy5idWZmZXJlZENvdW50ID4gMCA/ICdhY2MgcGVuZGluZycgOiAnYWNjJztcblxuICAgIGNvbnN0IGhlYWQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBoZWFkLmNsYXNzTmFtZSA9ICdhY2MtaGVhZCc7XG4gICAgY29uc3QgaGFuZGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGhhbmRsZS5jbGFzc05hbWUgPSAnYWNjLWhhbmRsZSc7XG4gICAgaGFuZGxlLmlubmVySFRNTCA9IGA8c3BhbiBjbGFzcz1cImF0XCI+QDwvc3Bhbj4ke2VzY2FwZUh0bWwoYS5oYW5kbGUpfWA7XG4gICAgY29uc3QgbWV0YSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBtZXRhLmNsYXNzTmFtZSA9ICdhY2MtbWV0YSc7XG4gICAgbWV0YS50ZXh0Q29udGVudCA9IGEubGFiZWw7XG4gICAgaGVhZC5hcHBlbmQoaGFuZGxlLCBtZXRhKTtcblxuICAgIGNvbnN0IHJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHJvdy5jbGFzc05hbWUgPSAnYWNjLXJvdyc7XG4gICAgY29uc3Qgc3RhdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgc3RhdHMuY2xhc3NOYW1lID0gJ2FjYy1zdGF0cyc7XG4gICAgY29uc3QgdG9kYXkgPSBjPy50b2RheUNvdW50ID8/IDA7XG4gICAgY29uc3QgYnVmZmVyZWQgPSBjPy5idWZmZXJlZENvdW50ID8/IDA7XG4gICAgY29uc3QgbGFzdCA9IGM/Lmxhc3RDYXB0dXJlQXQgPz8gbnVsbDtcbiAgICBzdGF0cy5pbm5lckhUTUwgPVxuICAgICAgYDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0odG9kYXkpfTwvc3Bhbj4gdG9kYXlgICtcbiAgICAgIChidWZmZXJlZCA+IDAgPyBgIFx1MDBCNyA8c3BhbiBjbGFzcz1cIm51bVwiPiR7Zm10TnVtKGJ1ZmZlcmVkKX08L3NwYW4+IGJ1ZmZlcmVkYCA6ICcnKSArXG4gICAgICBgIFx1MDBCNyBsYXN0ICR7ZXNjYXBlSHRtbChmbXRSZWwobGFzdCkpfWA7XG5cbiAgICBjb25zdCBhY3Rpb25zID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGFjdGlvbnMuY2xhc3NOYW1lID0gJ2FjYy1hY3Rpb24nO1xuICAgIGNvbnN0IGJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGJ0bi5jbGFzc05hbWUgPSAnYnRuJztcbiAgICBidG4udGV4dENvbnRlbnQgPSAnQ2FwdHVyZSBub3cnO1xuICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtbm93JywgaGFuZGxlOiBhLmhhbmRsZSB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGFjdGlvbnMuYXBwZW5kKGJ0bik7XG5cbiAgICByb3cuYXBwZW5kKHN0YXRzLCBhY3Rpb25zKTtcbiAgICBsaS5hcHBlbmQoaGVhZCwgcm93KTtcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFjdGl2aXR5KGV2ZW50czogTG9nRXZlbnRbXSk6IHZvaWQge1xuICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChldmVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWN0aXZpdHkgeWV0Lic7XG4gICAgYWN0aXZpdHlMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3QgZXYgb2YgZXZlbnRzLnNsaWNlKDAsIEFDVElWSVRZX1RBSUxfTUFYKSkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xuICAgIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XG4gICAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcbiAgICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xuICAgIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xuICAgIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xuICAgIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcbiAgICBib2R5LmFwcGVuZChtc2cpO1xuICAgIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcbiAgICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcbiAgICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgICBib2R5LmFwcGVuZChjdHgpO1xuICAgIH1cbiAgICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xuICAgIGFjdGl2aXR5TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHN0cmluZ2lmeVNob3J0KHY6IHVua25vd24pOiBzdHJpbmcge1xuICBpZiAodiA9PT0gbnVsbCkgcmV0dXJuICdudWxsJztcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJykgcmV0dXJuIHYubGVuZ3RoID4gODAgPyBgJHt2LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdjtcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gU3RyaW5nKHYpO1xuICB0cnkge1xuICAgIGNvbnN0IHMgPSBKU09OLnN0cmluZ2lmeSh2KTtcbiAgICByZXR1cm4gcy5sZW5ndGggPiA4MCA/IGAke3Muc2xpY2UoMCwgODApfVx1MjAyNmAgOiBzO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gJz8nO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoczogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHMucmVwbGFjZSgvWyY8PlwiJ10vZywgKGMpID0+XG4gICAgYyA9PT0gJyYnID8gJyZhbXA7JyA6IGMgPT09ICc8JyA/ICcmbHQ7JyA6IGMgPT09ICc+JyA/ICcmZ3Q7JyA6IGMgPT09ICdcIicgPyAnJnF1b3Q7JyA6ICcmIzM5OydcbiAgKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaFN0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGxhc3RTdGF0ZSA9IGF3YWl0IHNlbmQ8RXh0ZW5zaW9uU3RhdGU+KHsgdHlwZTogJ2dldC1zdGF0ZScgfSk7XG4gICAgcGFpbnQobGFzdFN0YXRlKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNpZGViYXIgcmVmcmVzaFN0YXRlIGZhaWxlZCcsIGVycik7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGFpbnQoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGV4dFZlcnNpb25FbC50ZXh0Q29udGVudCA9IHN0YXRlLnZlcnNpb247XG4gIHNldENvbm5TdGF0dXMoc3RhdGUpO1xuICBhdXRvVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvQ2FwdHVyZTtcbiAgdXBkYXRlRXhpc3RpbmdUb2dnbGUuY2hlY2tlZCA9IHN0YXRlLnNldHRpbmdzLnVwZGF0ZUV4aXN0aW5nICE9PSBmYWxzZTtcbiAgdmlld2VyTGluay5ocmVmID0gYGh0dHBzOi8vJHtzdGF0ZS5zZXR0aW5ncy5vd25lcn0uZ2l0aHViLmlvLyR7c3RhdGUuc2V0dGluZ3MucmVwb30vYDtcbiAgcGFpbnRNYXN0ZXJTd2l0Y2goc3RhdGUpO1xuICByZW5kZXJBY2NvdW50cyhzdGF0ZSk7XG4gIHJlbmRlclJlY2VudFR3ZWV0cyhzdGF0ZS5yZWNlbnRUd2VldFNpZ2h0aW5ncyk7XG4gIHBhaW50QXV0b1Njcm9sbChzdGF0ZSk7XG4gIHBhaW50TWVkaWFDcmF3bChzdGF0ZSk7XG4gIHBhaW50UmVmZXRjaChzdGF0ZSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclJlY2VudFR3ZWV0cyhyb3dzOiBUd2VldFNpZ2h0aW5nW10pOiB2b2lkIHtcbiAgcmVjZW50VHdlZXRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBpZiAocm93cy5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcbiAgICBsaS50ZXh0Q29udGVudCA9ICdObyB0d2VldHMgc2VlbiB5ZXQuJztcbiAgICByZWNlbnRUd2VldExpc3QuYXBwZW5kKGxpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yIChjb25zdCByb3cgb2Ygcm93cy5zbGljZSgwLCA0MCkpIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gYHJlY2VudC10d2VldCAke3Jvdy5hcmNoaXZlX3N0YXR1c31gO1xuXG4gICAgY29uc3QgdG9wID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgdG9wLmNsYXNzTmFtZSA9ICd0d2VldC1oZWFkJztcbiAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgIGxpbmsuY2xhc3NOYW1lID0gJ3R3ZWV0LWhhbmRsZSc7XG4gICAgbGluay5ocmVmID0gcm93LnR3ZWV0X3VybDtcbiAgICBsaW5rLnRhcmdldCA9ICdfYmxhbmsnO1xuICAgIGxpbmsucmVsID0gJ25vb3BlbmVyJztcbiAgICBsaW5rLnRleHRDb250ZW50ID0gYEAke3Jvdy5hY2NvdW50X2hhbmRsZX1gO1xuICAgIGNvbnN0IHN0YXR1cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBzdGF0dXMuY2xhc3NOYW1lID0gYHR3ZWV0LXBpbGwgJHtyb3cuYXJjaGl2ZV9zdGF0dXN9YDtcbiAgICBzdGF0dXMudGV4dENvbnRlbnQgPSByb3cuYXJjaGl2ZV9zdGF0dXMgPT09ICdzYXZlZCcgPyAnc2F2ZWQnIDogJ25ldyc7XG4gICAgdG9wLmFwcGVuZChsaW5rLCBzdGF0dXMpO1xuXG4gICAgY29uc3QgdGV4dCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHRleHQuY2xhc3NOYW1lID0gJ3R3ZWV0LXRleHQnO1xuICAgIHRleHQudGV4dENvbnRlbnQgPSB0cnVuY2F0ZVRleHQocm93LnRleHQsIDE0MCk7XG5cbiAgICBjb25zdCBtZXRhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgbWV0YS5jbGFzc05hbWUgPSAndHdlZXQtbWV0YSc7XG4gICAgbWV0YS50ZXh0Q29udGVudCA9XG4gICAgICBgJHtmb3JtYXRUd2VldEFjdGlvbihyb3cuYWN0aW9uKX0gXHUwMEI3ICR7cm93LnR3ZWV0X3R5cGV9IFx1MDBCNyBwb3N0ZWQgJHtmbXRSZWwocm93LnBvc3RlZF9hdCl9YDtcblxuICAgIGxpLmFwcGVuZCh0b3AsIHRleHQsIG1ldGEpO1xuICAgIHJlY2VudFR3ZWV0TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGZvcm1hdFR3ZWV0QWN0aW9uKGFjdGlvbjogVHdlZXRTaWdodGluZ1snYWN0aW9uJ10pOiBzdHJpbmcge1xuICBpZiAoYWN0aW9uID09PSAnYnVmZmVyZWQnKSByZXR1cm4gJ2J1ZmZlcmVkJztcbiAgaWYgKGFjdGlvbiA9PT0gJ3VuY2hhbmdlZCcpIHJldHVybiAndW5jaGFuZ2VkJztcbiAgcmV0dXJuICdza2lwcGVkJztcbn1cblxuZnVuY3Rpb24gdHJ1bmNhdGVUZXh0KHRleHQ6IHN0cmluZywgbWF4OiBudW1iZXIpOiBzdHJpbmcge1xuICBjb25zdCBjb21wYWN0ID0gdGV4dC5yZXBsYWNlKC9cXHMrL2csICcgJykudHJpbSgpO1xuICByZXR1cm4gY29tcGFjdC5sZW5ndGggPD0gbWF4ID8gY29tcGFjdCA6IGAke2NvbXBhY3Quc2xpY2UoMCwgbWF4IC0gMSl9XHUyMDI2YDtcbn1cblxuZnVuY3Rpb24gcGFpbnRNZWRpYUNyYXdsKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBxID0gc3RhdGUubWVkaWFDcmF3bFF1ZXVlO1xuICBjb25zdCB0b3RhbCA9IHEudG90YWw7XG4gIGNvbnN0IHJ1bm5pbmcgPSBxLnJ1bm5pbmc7XG4gIG1lZGlhQ3Jhd2xTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xuICBtZWRpYUNyYXdsQ291bnQudGV4dENvbnRlbnQgPVxuICAgIHRvdGFsID09PSAwXG4gICAgICA/IHJ1bm5pbmdcbiAgICAgICAgPyAnZmluaXNoaW5nXHUyMDI2J1xuICAgICAgICA6ICcwIHF1ZXVlZCdcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmRpc2FibGVkID0gdG90YWwgPT09IDA7XG4gIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XG4gIHBhaW50UXVldWVQcm9ncmVzcyhtZWRpYUNyYXdsUHJvZ3Jlc3MsIHEpO1xufVxuXG5mdW5jdGlvbiBwYWludFF1ZXVlUHJvZ3Jlc3MoXG4gIGVsOiBIVE1MU3BhbkVsZW1lbnQsXG4gIHE6IHsgcHJvY2Vzc2VkOiBudW1iZXI7IHRvdGFsX2F0X3N0YXJ0OiBudW1iZXI7IHJ1bm5pbmc6IGJvb2xlYW47IHRvdGFsOiBudW1iZXIgfVxuKTogdm9pZCB7XG4gIGlmICghcS5ydW5uaW5nICYmIHEucHJvY2Vzc2VkID09PSAwKSB7XG4gICAgZWwuaGlkZGVuID0gdHJ1ZTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gRGVub21pbmF0b3I6IG1heCBvZiBpbml0aWFsIHRvdGFsIGFuZCBjdXJyZW50IHByb2Nlc3NlZCtyZW1haW5pbmcgc28gdGhlXG4gIC8vIGJhciBzdGlsbCBtYWtlcyBzZW5zZSBpZiBuZXcgZW50cmllcyB3ZXJlIGVucXVldWVkIG1pZC1ydW4uXG4gIGNvbnN0IGRlbm9tID0gTWF0aC5tYXgocS50b3RhbF9hdF9zdGFydCwgcS5wcm9jZXNzZWQgKyBxLnRvdGFsKTtcbiAgZWwuaGlkZGVuID0gZmFsc2U7XG4gIGVsLnRleHRDb250ZW50ID0gYCR7Zm10TnVtKHEucHJvY2Vzc2VkKX0gLyAke2ZtdE51bShkZW5vbSl9IHByb2Nlc3NlZGA7XG4gIGVsLmNsYXNzTmFtZSA9IHEucnVubmluZyA/ICdwcm9ncmVzcyBvbicgOiAncHJvZ3Jlc3MnO1xufVxuXG5mdW5jdGlvbiBwYWludE1hc3RlclN3aXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3Qgb24gPSBzdGF0ZS5zZXR0aW5ncy5lbmFibGVkICE9PSBmYWxzZTtcbiAgbWFzdGVyU3dpdGNoLmNoZWNrZWQgPSBvbjtcbiAgbWFzdGVyTGFiZWwudGV4dENvbnRlbnQgPSBvbiA/ICdPTicgOiAnUEFVU0VEJztcbiAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKCdwYXVzZWQnLCAhb24pO1xufVxuXG5mdW5jdGlvbiBwYWludEF1dG9TY3JvbGwoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHNlY3MgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWM7XG4gIGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZSA9IFN0cmluZyhzZWNzKTtcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IFN0cmluZyhzZWNzKTtcbiAgY29uc3QgYXMgPSBzdGF0ZS5hdXRvU2Nyb2xsO1xuICBhdXRvU2Nyb2xsU3RhcnRCdG4uaGlkZGVuID0gYXMuYWN0aXZlO1xuICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmhpZGRlbiA9ICFhcy5hY3RpdmU7XG4gIGlmIChhcy5hY3RpdmUpIHtcbiAgICBjb25zdCBuID0gYXMudGFiQ291bnQ7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9XG4gICAgICBuID09PSAwID8gYHJ1bm5pbmcgXHUyMDE0IG5vIFggdGFicyBvcGVuYCA6IGBydW5uaW5nIFx1MjAxNCAke259ICR7biA9PT0gMSA/ICd0YWInIDogJ3RhYnMnfWA7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy5jbGFzc05hbWUgPSAnbXV0ZWQgb24nO1xuICB9IGVsc2Uge1xuICAgIGF1dG9TY3JvbGxTdGF0dXMudGV4dENvbnRlbnQgPSAnaWRsZSc7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy5jbGFzc05hbWUgPSAnbXV0ZWQnO1xuICB9XG4gIGlmIChhcy5hY3RpdmUgfHwgYXMuc2Nyb2xsQ291bnQgPiAwIHx8IGFzLmluZ2VzdGVkQ291bnQgPiAwKSB7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmhpZGRlbiA9IGZhbHNlO1xuICAgIGNvbnN0IHBhcnRzID0gW1xuICAgICAgYCR7Zm10TnVtKGFzLnNjcm9sbENvdW50KX0gc2Nyb2xsc2AsXG4gICAgICBgJHtmbXROdW0oYXMuaW5nZXN0ZWROZXdDb3VudCl9IG5ldyBidWZmZXJlZGAsXG4gICAgICBgJHtmbXROdW0oYXMuaW5nZXN0ZWRFeGlzdGluZ0NvdW50KX0gb2xkIGJ1ZmZlcmVkYCxcbiAgICBdO1xuICAgIGlmIChhcy5za2lwcGVkT2xkQ291bnQgPiAwKSBwYXJ0cy5wdXNoKGAke2ZtdE51bShhcy5za2lwcGVkT2xkQ291bnQpfSBvbGQgc2tpcHBlZGApO1xuICAgIHBhcnRzLnB1c2goYCR7Zm10TnVtKGFzLmV4cGFuZGVkQ291bnQpfSBleHBhbmRlZGApO1xuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy50ZXh0Q29udGVudCA9IHBhcnRzLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmNsYXNzTmFtZSA9IGFzLmFjdGl2ZSA/ICdwcm9ncmVzcyBvbicgOiAncHJvZ3Jlc3MnO1xuICB9IGVsc2Uge1xuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy5oaWRkZW4gPSB0cnVlO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBhaW50UmVmZXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3QgcSA9IHN0YXRlLnJlZmV0Y2hRdWV1ZTtcbiAgY29uc3QgdG90YWwgPSBxLnRvdGFsO1xuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xuICByZWZldGNoU2VjdGlvbi5oaWRkZW4gPSB0b3RhbCA9PT0gMCAmJiAhcnVubmluZztcbiAgcmVmZXRjaENvdW50LnRleHRDb250ZW50ID1cbiAgICB0b3RhbCA9PT0gMFxuICAgICAgPyBydW5uaW5nXG4gICAgICAgID8gJ2ZpbmlzaGluZ1x1MjAyNidcbiAgICAgICAgOiAnMCBxdWV1ZWQnXG4gICAgICA6IGAke2ZtdE51bSh0b3RhbCl9IHF1ZXVlZCR7cnVubmluZyA/ICcgXHUwMEI3IHJ1bm5pbmcnIDogJyd9YDtcbiAgcmVmZXRjaFN0YXJ0QnRuLmhpZGRlbiA9IHJ1bm5pbmc7XG4gIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xuICByZWZldGNoQ2FuY2VsQnRuLmhpZGRlbiA9ICFydW5uaW5nO1xuICBwYWludFF1ZXVlUHJvZ3Jlc3MocmVmZXRjaFByb2dyZXNzLCBxKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBQdWxsIHN0cmFpZ2h0IGZyb20gc3RvcmFnZSBvbiBmaXJzdCByZW5kZXI7IGxpdmUgdXBkYXRlcyBjb21lIHZpYVxuICAvLyBgbG9nLWV2ZW50YCBicm9hZGNhc3RzLlxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KCdhY3Rpdml0eScpO1xuICBjb25zdCBldmVudHMgPSAoc3RvcmVkLmFjdGl2aXR5IGFzIExvZ0V2ZW50W10gfCB1bmRlZmluZWQpID8/IFtdO1xuICByZW5kZXJBY3Rpdml0eShldmVudHMpO1xufVxuXG4vLyAtLS0gV2lyZSB1cCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5jYXB0dXJlQWxsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtYWxsJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5jYXB0dXJlVGhpc0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS10aGlzLXBhZ2UnIH0pO1xuICB9IGZpbmFsbHkge1xuICAgIGNhcHR1cmVUaGlzQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5mbHVzaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgZmx1c2hCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnZmx1c2gtYWxsJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBmbHVzaEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuYXV0b1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtYXV0by1jYXB0dXJlJywgb246IGF1dG9Ub2dnbGUuY2hlY2tlZCB9KTtcbn0pO1xuXG51cGRhdGVFeGlzdGluZ1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtdXBkYXRlLWV4aXN0aW5nJywgb246IHVwZGF0ZUV4aXN0aW5nVG9nZ2xlLmNoZWNrZWQgfSk7XG59KTtcblxubWFzdGVyU3dpdGNoLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1lbmFibGVkJywgb246IG1hc3RlclN3aXRjaC5jaGVja2VkIH0pO1xufSk7XG5cbmF1dG9TY3JvbGxTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgYXV0b1Njcm9sbFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LWF1dG8tc2Nyb2xsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcbmF1dG9TY3JvbGxDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGF1dG9TY3JvbGxDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLWF1dG8tc2Nyb2xsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbmF1dG9TY3JvbGxJbnRlcnZhbC5hZGRFdmVudExpc3RlbmVyKCdpbnB1dCcsICgpID0+IHtcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZTtcbn0pO1xuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgY29uc3Qgc2Vjb25kcyA9IE51bWJlcihhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWUpO1xuICBpZiAoTnVtYmVyLmlzRmluaXRlKHNlY29uZHMpKSB7XG4gICAgdm9pZCBzZW5kKHsgdHlwZTogJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCcsIHNlY29uZHMgfSk7XG4gIH1cbn0pO1xuXG5wdXJnZUxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICBjb25zdCBvayA9IHdpbmRvdy5jb25maXJtKFxuICAgICdEcm9wIGV2ZXJ5IGNvdW50ZXIsIHJ1biBidWZmZXIsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyeSBmb3IgYWNjb3VudHMgbm90IGluIHlvdXIgdHJhY2tlZCBsaXN0P1xcblxcbicgK1xuICAgICAgJ1RoaXMgb25seSB0b3VjaGVzIGxvY2FsIGV4dGVuc2lvbiBzdGF0ZS4gQWxyZWFkeS1jb21taXR0ZWQgZmlsZXMgaW4gdGhlIEdpdEh1YiByZXBvIGFyZSBub3QgYWZmZWN0ZWQgXHUyMDE0ICcgK1xuICAgICAgJ3J1biBzY3JpcHRzL3B1cmdlX3VucmVsYXRlZC5weSBzZXBhcmF0ZWx5IGlmIHlvdSBhbHNvIHdhbnQgdG8gc2NydWIgdGhlIHJlcG8uJ1xuICApO1xuICBpZiAoIW9rKSByZXR1cm47XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdwdXJnZS11bnJlbGF0ZWQnIH0pO1xufSk7XG5cbnJlZmV0Y2hTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5yZWZldGNoQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1yZWZldGNoJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbm1lZGlhQ3Jhd2xTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LW1lZGlhLWNyYXdsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxubWVkaWFDcmF3bENhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxub3B0aW9uc0xpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnb3Blbi1vcHRpb25zJyB9KTtcbn0pO1xuXG52aWV3ZXJMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ29wZW4tdmlld2VyJyB9KTtcbn0pO1xuXG5jbGVhckFjdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjbGVhci1hY3Rpdml0eScgfSk7XG4gIHJlbmRlckFjdGl2aXR5KFtdKTtcbn0pO1xuXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24pID0+IHtcbiAgaWYgKCFtc2cgfHwgdHlwZW9mIG1zZyAhPT0gJ29iamVjdCcpIHJldHVybjtcbiAgY29uc3QgbSA9IG1zZyBhcyB7IHR5cGU/OiBzdHJpbmc7IHN0YXRlPzogRXh0ZW5zaW9uU3RhdGU7IGV2ZW50PzogTG9nRXZlbnQgfTtcbiAgaWYgKG0udHlwZSA9PT0gJ3N0YXRlLWNoYW5nZWQnICYmIG0uc3RhdGUpIHtcbiAgICBsYXN0U3RhdGUgPSBtLnN0YXRlO1xuICAgIHBhaW50KG0uc3RhdGUpO1xuICB9IGVsc2UgaWYgKG0udHlwZSA9PT0gJ2xvZy1ldmVudCcgJiYgbS5ldmVudCkge1xuICAgIHByZXBlbmRFdmVudChtLmV2ZW50KTtcbiAgfVxufSk7XG5cbmZ1bmN0aW9uIHByZXBlbmRFdmVudChldjogTG9nRXZlbnQpOiB2b2lkIHtcbiAgLy8gSWYgdGhlIGxpc3QgaXMgc2hvd2luZyB0aGUgXCJlbXB0eVwiIHBsYWNlaG9sZGVyLCBjbGVhciBpdC5cbiAgaWYgKGFjdGl2aXR5TGlzdC5maXJzdEVsZW1lbnRDaGlsZD8uY2xhc3NMaXN0LmNvbnRhaW5zKCdlbXB0eScpKSB7XG4gICAgYWN0aXZpdHlMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICB9XG4gIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgbGkuY2xhc3NOYW1lID0gYGV2ICR7ZXYubGV2ZWx9YDtcbiAgY29uc3QgdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XG4gIHRzLnRleHRDb250ZW50ID0gbmV3IERhdGUoZXYudHMpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tVVMnLCB7IGhvdXIxMjogZmFsc2UgfSk7XG4gIGNvbnN0IGljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xuICBpY29uLnRleHRDb250ZW50ID0gZXYubGV2ZWwgPT09ICdlcnJvcicgPyAnXHUyNzE3JyA6IGV2LmxldmVsID09PSAnd2FybicgPyAnIScgOiAnXHUwMEI3JztcbiAgY29uc3QgYm9keSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIG1zZy5jbGFzc05hbWUgPSAnZXYtbXNnJztcbiAgbXNnLnRleHRDb250ZW50ID0gZXYubXNnO1xuICBib2R5LmFwcGVuZChtc2cpO1xuICBjb25zdCBjdHhLZXlzID0gT2JqZWN0LmtleXMoZXYuY29udGV4dCk7XG4gIGlmIChjdHhLZXlzLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBjdHguY2xhc3NOYW1lID0gJ2V2LWN0eCc7XG4gICAgY3R4LnRleHRDb250ZW50ID0gY3R4S2V5cy5tYXAoKGspID0+IGAke2t9PSR7c3RyaW5naWZ5U2hvcnQoZXYuY29udGV4dFtrXSl9YCkuam9pbignIFx1MDBCNyAnKTtcbiAgICBib2R5LmFwcGVuZChjdHgpO1xuICB9XG4gIGxpLmFwcGVuZCh0cywgaWNvbiwgYm9keSk7XG4gIGFjdGl2aXR5TGlzdC5wcmVwZW5kKGxpKTtcbiAgd2hpbGUgKGFjdGl2aXR5TGlzdC5jaGlsZEVsZW1lbnRDb3VudCA+IEFDVElWSVRZX1RBSUxfTUFYKSB7XG4gICAgYWN0aXZpdHlMaXN0Lmxhc3RFbGVtZW50Q2hpbGQ/LnJlbW92ZSgpO1xuICB9XG59XG5cbi8vIEluaXRpYWwgcGFpbnQuXG52b2lkIHJlZnJlc2hTdGF0ZSgpO1xudm9pZCByZWZyZXNoQWN0aXZpdHkoKTtcblxuLy8gUGVyaW9kaWNhbGx5IHJlLWZldGNoIHN0YXRlIHNvIFwibGFzdCBjYXB0dXJlXCIgdGltZXMgc3RheSBmcmVzaC5cbnNldEludGVydmFsKCgpID0+IHtcbiAgdm9pZCByZWZyZXNoU3RhdGUoKTtcbn0sIDE1XzAwMCk7XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBMEZPLElBQU0sb0JBQW9CO0FBRzFCLElBQU0sZ0NBQWdDLEtBQUssS0FBSzs7O0FDbEZ2RCxJQUFNLElBQUksQ0FBc0MsT0FBa0I7QUFDaEUsUUFBTSxLQUFLLFNBQVMsZUFBZSxFQUFFO0FBQ3JDLE1BQUksQ0FBQyxHQUFJLE9BQU0sSUFBSSxNQUFNLG9CQUFvQixFQUFFLEVBQUU7QUFDakQsU0FBTztBQUNUO0FBRUEsSUFBTSxVQUFVLEVBQUUsVUFBVTtBQUM1QixJQUFNLFdBQVcsRUFBbUIsV0FBVztBQUMvQyxJQUFNLGNBQWMsRUFBb0IsY0FBYztBQUN0RCxJQUFNLGtCQUFrQixFQUFvQixtQkFBbUI7QUFDL0QsSUFBTSxlQUFlLEVBQW9CLGVBQWU7QUFDeEQsSUFBTSxhQUFhLEVBQW9CLGNBQWM7QUFDckQsSUFBTSx1QkFBdUIsRUFBb0IsaUJBQWlCO0FBQ2xFLElBQU0sZ0JBQWdCLEVBQXFCLGFBQWE7QUFDeEQsSUFBTSxpQkFBaUIsRUFBcUIsY0FBYztBQUMxRCxJQUFNLFdBQVcsRUFBcUIsV0FBVztBQUNqRCxJQUFNLGNBQWMsRUFBcUIsY0FBYztBQUN2RCxJQUFNLGFBQWEsRUFBcUIsYUFBYTtBQUNyRCxJQUFNLGNBQWMsRUFBcUIsZ0JBQWdCO0FBQ3pELElBQU0sZUFBZSxFQUFtQixhQUFhO0FBQ3JELElBQU0sZUFBZSxFQUFvQixlQUFlO0FBQ3hELElBQU0sY0FBYyxFQUFtQixjQUFjO0FBQ3JELElBQU0scUJBQXFCLEVBQW9CLHNCQUFzQjtBQUNyRSxJQUFNLG1CQUFtQixFQUFtQixrQkFBa0I7QUFDOUQsSUFBTSxtQkFBbUIsRUFBbUIsb0JBQW9CO0FBQ2hFLElBQU0scUJBQXFCLEVBQXFCLG1CQUFtQjtBQUNuRSxJQUFNLHNCQUFzQixFQUFxQixvQkFBb0I7QUFDckUsSUFBTSxxQkFBcUIsRUFBbUIsc0JBQXNCO0FBQ3BFLElBQU0saUJBQWlCLEVBQWUsaUJBQWlCO0FBQ3ZELElBQU0sZUFBZSxFQUFtQixlQUFlO0FBQ3ZELElBQU0sa0JBQWtCLEVBQXFCLGVBQWU7QUFDNUQsSUFBTSxtQkFBbUIsRUFBcUIsZ0JBQWdCO0FBQzlELElBQU0sa0JBQWtCLEVBQW1CLGtCQUFrQjtBQUM3RCxJQUFNLG9CQUFvQixFQUFlLHFCQUFxQjtBQUM5RCxJQUFNLGtCQUFrQixFQUFtQixtQkFBbUI7QUFDOUQsSUFBTSxxQkFBcUIsRUFBcUIsbUJBQW1CO0FBQ25FLElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLHFCQUFxQixFQUFtQixzQkFBc0I7QUFDcEUsSUFBTSxZQUFZLEVBQXFCLGlCQUFpQjtBQUV4RCxJQUFJLFlBQW1DO0FBRXZDLGVBQWUsS0FBUSxLQUFpQztBQUN0RCxTQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDeEM7QUFFQSxTQUFTLGNBQWMsT0FBNkI7QUFDbEQsUUFBTSxFQUFFLFlBQVksU0FBUyxJQUFJO0FBQ2pDLE1BQUksTUFBTTtBQUNWLE1BQUksT0FBTztBQUtYLFFBQU0sZ0JBQ0osV0FBVyxXQUFXLFFBQVEsU0FBUyxVQUFVLFdBQVcsMkJBQTJCO0FBQ3pGLE1BQUksQ0FBQyxTQUFTLFFBQVE7QUFDcEIsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsZUFBZTtBQUN4QixVQUFNO0FBQ04sV0FBTyxXQUFXLFNBQVMsTUFBTSx1QkFBdUIsU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLDRDQUF1QyxXQUFXLGlCQUFpQixRQUFRO0FBQUEsRUFDcEssV0FBVyxXQUFXLFdBQVcsTUFBTTtBQUNyQyxVQUFNO0FBQ04sV0FBTyxpQkFBaUIsV0FBVyxTQUFTLEdBQUcsT0FBTyxTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksZUFBTyxTQUFTLFNBQVM7QUFBQSxFQUNoSCxXQUFXLFdBQVcsV0FBVyxjQUFjO0FBQzdDLFVBQU07QUFDTixXQUFPLGlCQUFpQixXQUFXLEtBQUssSUFDcEMsb0VBQ0E7QUFBQSxFQUNOLFdBQVcsV0FBVyxXQUFXLGdCQUFnQjtBQUMvQyxVQUFNO0FBQ04sVUFBTSxTQUFTLGtCQUFrQixXQUFXLGdCQUFnQjtBQUM1RCxXQUFPLFNBQ0gscUNBQWdDLE1BQU0sS0FDdEM7QUFBQSxFQUNOLFdBQVcsV0FBVyxXQUFXLGlCQUFpQjtBQUNoRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxXQUFXLFdBQVcsa0JBQWtCO0FBQ2pELFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxPQUFPO0FBQ0wsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0EsVUFBUSxZQUFZLE9BQU8sR0FBRztBQUM5QixXQUFTLGNBQWM7QUFDdkIsV0FBUyxRQUFRLFdBQVcsU0FBUztBQUN2QztBQUVBLFNBQVMsT0FBTyxLQUE0QjtBQUMxQyxNQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLFFBQU0sSUFBSSxLQUFLLE1BQU0sR0FBRztBQUN4QixNQUFJLENBQUMsT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ2hDLFFBQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxHQUFJLENBQUM7QUFDNUQsTUFBSSxPQUFPLEVBQUcsUUFBTztBQUNyQixNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNqQyxNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxNQUFJLFFBQVEsR0FBSSxRQUFPLEdBQUcsS0FBSztBQUMvQixRQUFNLE9BQU8sS0FBSyxNQUFNLFFBQVEsRUFBRTtBQUNsQyxTQUFPLEdBQUcsSUFBSTtBQUNoQjtBQUVBLFNBQVMsa0JBQWtCLFVBQWlDO0FBQzFELE1BQUksYUFBYSxLQUFNLFFBQU87QUFDOUIsUUFBTSxXQUFXLFdBQVcsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDeEQsTUFBSSxZQUFZLEVBQUcsUUFBTztBQUMxQixRQUFNLFlBQVksSUFBSSxLQUFLLFdBQVcsR0FBSSxFQUFFLG1CQUFtQixDQUFDLEdBQUc7QUFBQSxJQUNqRSxNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsRUFDVixDQUFDO0FBQ0QsTUFBSSxXQUFXLEdBQUksUUFBTyxNQUFNLFFBQVEsTUFBTSxTQUFTO0FBQ3ZELFFBQU0sT0FBTyxLQUFLLE1BQU0sV0FBVyxFQUFFO0FBQ3JDLE1BQUksT0FBTyxHQUFJLFFBQU8sTUFBTSxJQUFJLE1BQU0sU0FBUztBQUMvQyxRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxTQUFPLE1BQU0sS0FBSyxNQUFNLFNBQVM7QUFDbkM7QUFFQSxTQUFTLE9BQU8sR0FBbUI7QUFDakMsU0FBTyxFQUFFLGVBQWUsT0FBTztBQUNqQztBQUVBLFNBQVMsaUJBQWlCLFNBQWlDO0FBQ3pELFNBQ0UsT0FBTyxZQUFZLFlBQ25CLDZFQUE2RSxLQUFLLE9BQU87QUFFN0Y7QUFFQSxTQUFTLGVBQWUsT0FBNkI7QUFDbkQsY0FBWSxnQkFBZ0I7QUFDNUIsTUFBSSxNQUFNLFNBQVMsV0FBVyxHQUFHO0FBQy9CLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsZ0JBQVksT0FBTyxFQUFFO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLGFBQVcsS0FBSyxNQUFNLFVBQVU7QUFDOUIsVUFBTSxJQUFJLE1BQU0sU0FBUyxFQUFFLE1BQU07QUFDakMsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxLQUFLLEVBQUUsZ0JBQWdCLElBQUksZ0JBQWdCO0FBRTFELFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsVUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0FBQzVDLFdBQU8sWUFBWTtBQUNuQixXQUFPLFlBQVksNEJBQTRCLFdBQVcsRUFBRSxNQUFNLENBQUM7QUFDbkUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsRUFBRTtBQUNyQixTQUFLLE9BQU8sUUFBUSxJQUFJO0FBRXhCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsVUFBTSxRQUFRLFNBQVMsY0FBYyxNQUFNO0FBQzNDLFVBQU0sWUFBWTtBQUNsQixVQUFNLFFBQVEsR0FBRyxjQUFjO0FBQy9CLFVBQU0sV0FBVyxHQUFHLGlCQUFpQjtBQUNyQyxVQUFNLE9BQU8sR0FBRyxpQkFBaUI7QUFDakMsVUFBTSxZQUNKLHFCQUFxQixPQUFPLEtBQUssQ0FBQyxtQkFDakMsV0FBVyxJQUFJLDJCQUF3QixPQUFPLFFBQVEsQ0FBQyxxQkFBcUIsTUFDN0UsY0FBVyxXQUFXLE9BQU8sSUFBSSxDQUFDLENBQUM7QUFFckMsVUFBTSxVQUFVLFNBQVMsY0FBYyxNQUFNO0FBQzdDLFlBQVEsWUFBWTtBQUNwQixVQUFNLE1BQU0sU0FBUyxjQUFjLFFBQVE7QUFDM0MsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYztBQUNsQixRQUFJLGlCQUFpQixTQUFTLFlBQVk7QUFDeEMsVUFBSSxXQUFXO0FBQ2YsVUFBSTtBQUNGLGNBQU0sS0FBSyxFQUFFLE1BQU0sZUFBZSxRQUFRLEVBQUUsT0FBTyxDQUFDO0FBQUEsTUFDdEQsVUFBRTtBQUNBLFlBQUksV0FBVztBQUFBLE1BQ2pCO0FBQUEsSUFDRixDQUFDO0FBQ0QsWUFBUSxPQUFPLEdBQUc7QUFFbEIsUUFBSSxPQUFPLE9BQU8sT0FBTztBQUN6QixPQUFHLE9BQU8sTUFBTSxHQUFHO0FBQ25CLGdCQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsUUFBMEI7QUFDaEQsZUFBYSxnQkFBZ0I7QUFDN0IsTUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLGlCQUFhLE9BQU8sRUFBRTtBQUN0QjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLE1BQU0sT0FBTyxNQUFNLEdBQUcsaUJBQWlCLEdBQUc7QUFDbkQsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixVQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsR0FBRztBQUNyQixTQUFLLE9BQU8sR0FBRztBQUNmLFVBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLFFBQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsWUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFVBQUksWUFBWTtBQUNoQixVQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFdBQUssT0FBTyxHQUFHO0FBQUEsSUFDakI7QUFDQSxPQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsaUJBQWEsT0FBTyxFQUFFO0FBQUEsRUFDeEI7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUFvQjtBQUMxQyxNQUFJLE1BQU0sS0FBTSxRQUFPO0FBQ3ZCLE1BQUksT0FBTyxNQUFNLFNBQVUsUUFBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQ3pFLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFVBQVcsUUFBTyxPQUFPLENBQUM7QUFDcEUsTUFBSTtBQUNGLFVBQU0sSUFBSSxLQUFLLFVBQVUsQ0FBQztBQUMxQixXQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFBQSxFQUNoRCxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsV0FBVyxHQUFtQjtBQUNyQyxTQUFPLEVBQUU7QUFBQSxJQUFRO0FBQUEsSUFBWSxDQUFDLE1BQzVCLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxXQUFXO0FBQUEsRUFDekY7QUFDRjtBQUVBLGVBQWUsZUFBOEI7QUFDM0MsTUFBSTtBQUNGLGdCQUFZLE1BQU0sS0FBcUIsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUM1RCxVQUFNLFNBQVM7QUFBQSxFQUNqQixTQUFTLEtBQUs7QUFDWixZQUFRLEtBQUssNkNBQTZDLEdBQUc7QUFBQSxFQUMvRDtBQUNGO0FBRUEsU0FBUyxNQUFNLE9BQTZCO0FBQzFDLGVBQWEsY0FBYyxNQUFNO0FBQ2pDLGdCQUFjLEtBQUs7QUFDbkIsYUFBVyxVQUFVLE1BQU0sU0FBUztBQUNwQyx1QkFBcUIsVUFBVSxNQUFNLFNBQVMsbUJBQW1CO0FBQ2pFLGFBQVcsT0FBTyxXQUFXLE1BQU0sU0FBUyxLQUFLLGNBQWMsTUFBTSxTQUFTLElBQUk7QUFDbEYsb0JBQWtCLEtBQUs7QUFDdkIsaUJBQWUsS0FBSztBQUNwQixxQkFBbUIsTUFBTSxvQkFBb0I7QUFDN0Msa0JBQWdCLEtBQUs7QUFDckIsa0JBQWdCLEtBQUs7QUFDckIsZUFBYSxLQUFLO0FBQ3BCO0FBRUEsU0FBUyxtQkFBbUIsTUFBNkI7QUFDdkQsa0JBQWdCLGdCQUFnQjtBQUNoQyxNQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3JCLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsb0JBQWdCLE9BQU8sRUFBRTtBQUN6QjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLE9BQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxHQUFHO0FBQ25DLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksZ0JBQWdCLElBQUksY0FBYztBQUVqRCxVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFVBQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztBQUN2QyxTQUFLLFlBQVk7QUFDakIsU0FBSyxPQUFPLElBQUk7QUFDaEIsU0FBSyxTQUFTO0FBQ2QsU0FBSyxNQUFNO0FBQ1gsU0FBSyxjQUFjLElBQUksSUFBSSxjQUFjO0FBQ3pDLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVksY0FBYyxJQUFJLGNBQWM7QUFDbkQsV0FBTyxjQUFjLElBQUksbUJBQW1CLFVBQVUsVUFBVTtBQUNoRSxRQUFJLE9BQU8sTUFBTSxNQUFNO0FBRXZCLFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLGFBQWEsSUFBSSxNQUFNLEdBQUc7QUFFN0MsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQ0gsR0FBRyxrQkFBa0IsSUFBSSxNQUFNLENBQUMsU0FBTSxJQUFJLFVBQVUsZ0JBQWEsT0FBTyxJQUFJLFNBQVMsQ0FBQztBQUV4RixPQUFHLE9BQU8sS0FBSyxNQUFNLElBQUk7QUFDekIsb0JBQWdCLE9BQU8sRUFBRTtBQUFBLEVBQzNCO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixRQUF5QztBQUNsRSxNQUFJLFdBQVcsV0FBWSxRQUFPO0FBQ2xDLE1BQUksV0FBVyxZQUFhLFFBQU87QUFDbkMsU0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLE1BQWMsS0FBcUI7QUFDdkQsUUFBTSxVQUFVLEtBQUssUUFBUSxRQUFRLEdBQUcsRUFBRSxLQUFLO0FBQy9DLFNBQU8sUUFBUSxVQUFVLE1BQU0sVUFBVSxHQUFHLFFBQVEsTUFBTSxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQ3ZFO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsb0JBQWtCLFNBQVMsVUFBVSxLQUFLLENBQUM7QUFDM0Msa0JBQWdCLGNBQ2QsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELHFCQUFtQixTQUFTO0FBQzVCLHFCQUFtQixXQUFXLFVBQVU7QUFDeEMsc0JBQW9CLFNBQVMsQ0FBQztBQUM5QixxQkFBbUIsb0JBQW9CLENBQUM7QUFDMUM7QUFFQSxTQUFTLG1CQUNQLElBQ0EsR0FDTTtBQUNOLE1BQUksQ0FBQyxFQUFFLFdBQVcsRUFBRSxjQUFjLEdBQUc7QUFDbkMsT0FBRyxTQUFTO0FBQ1o7QUFBQSxFQUNGO0FBR0EsUUFBTSxRQUFRLEtBQUssSUFBSSxFQUFFLGdCQUFnQixFQUFFLFlBQVksRUFBRSxLQUFLO0FBQzlELEtBQUcsU0FBUztBQUNaLEtBQUcsY0FBYyxHQUFHLE9BQU8sRUFBRSxTQUFTLENBQUMsTUFBTSxPQUFPLEtBQUssQ0FBQztBQUMxRCxLQUFHLFlBQVksRUFBRSxVQUFVLGdCQUFnQjtBQUM3QztBQUVBLFNBQVMsa0JBQWtCLE9BQTZCO0FBQ3RELFFBQU0sS0FBSyxNQUFNLFNBQVMsWUFBWTtBQUN0QyxlQUFhLFVBQVU7QUFDdkIsY0FBWSxjQUFjLEtBQUssT0FBTztBQUN0QyxXQUFTLEtBQUssVUFBVSxPQUFPLFVBQVUsQ0FBQyxFQUFFO0FBQzlDO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxPQUFPLE1BQU0sU0FBUztBQUM1QixxQkFBbUIsUUFBUSxPQUFPLElBQUk7QUFDdEMsbUJBQWlCLGNBQWMsT0FBTyxJQUFJO0FBQzFDLFFBQU0sS0FBSyxNQUFNO0FBQ2pCLHFCQUFtQixTQUFTLEdBQUc7QUFDL0Isc0JBQW9CLFNBQVMsQ0FBQyxHQUFHO0FBQ2pDLE1BQUksR0FBRyxRQUFRO0FBQ2IsVUFBTSxJQUFJLEdBQUc7QUFDYixxQkFBaUIsY0FDZixNQUFNLElBQUksa0NBQTZCLGtCQUFhLENBQUMsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNO0FBQ25GLHFCQUFpQixZQUFZO0FBQUEsRUFDL0IsT0FBTztBQUNMLHFCQUFpQixjQUFjO0FBQy9CLHFCQUFpQixZQUFZO0FBQUEsRUFDL0I7QUFDQSxNQUFJLEdBQUcsVUFBVSxHQUFHLGNBQWMsS0FBSyxHQUFHLGdCQUFnQixHQUFHO0FBQzNELHVCQUFtQixTQUFTO0FBQzVCLFVBQU0sUUFBUTtBQUFBLE1BQ1osR0FBRyxPQUFPLEdBQUcsV0FBVyxDQUFDO0FBQUEsTUFDekIsR0FBRyxPQUFPLEdBQUcsZ0JBQWdCLENBQUM7QUFBQSxNQUM5QixHQUFHLE9BQU8sR0FBRyxxQkFBcUIsQ0FBQztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxHQUFHLGtCQUFrQixFQUFHLE9BQU0sS0FBSyxHQUFHLE9BQU8sR0FBRyxlQUFlLENBQUMsY0FBYztBQUNsRixVQUFNLEtBQUssR0FBRyxPQUFPLEdBQUcsYUFBYSxDQUFDLFdBQVc7QUFDakQsdUJBQW1CLGNBQWMsTUFBTSxLQUFLLFFBQUs7QUFDakQsdUJBQW1CLFlBQVksR0FBRyxTQUFTLGdCQUFnQjtBQUFBLEVBQzdELE9BQU87QUFDTCx1QkFBbUIsU0FBUztBQUFBLEVBQzlCO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsT0FBNkI7QUFDakQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsaUJBQWUsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUN4QyxlQUFhLGNBQ1gsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELGtCQUFnQixTQUFTO0FBQ3pCLGtCQUFnQixXQUFXLFVBQVU7QUFDckMsbUJBQWlCLFNBQVMsQ0FBQztBQUMzQixxQkFBbUIsaUJBQWlCLENBQUM7QUFDdkM7QUFFQSxlQUFlLGtCQUFpQztBQUc5QyxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLFVBQVU7QUFDekQsUUFBTSxTQUFVLE9BQU8sWUFBdUMsQ0FBQztBQUMvRCxpQkFBZSxNQUFNO0FBQ3ZCO0FBSUEsY0FBYyxpQkFBaUIsU0FBUyxZQUFZO0FBQ2xELGdCQUFjLFdBQVc7QUFDekIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQUEsRUFDcEMsVUFBRTtBQUNBLGtCQUFjLFdBQVc7QUFBQSxFQUMzQjtBQUNGLENBQUM7QUFFRCxlQUFlLGlCQUFpQixTQUFTLFlBQVk7QUFDbkQsaUJBQWUsV0FBVztBQUMxQixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUFBLEVBQzFDLFVBQUU7QUFDQSxtQkFBZSxXQUFXO0FBQUEsRUFDNUI7QUFDRixDQUFDO0FBRUQsU0FBUyxpQkFBaUIsU0FBUyxZQUFZO0FBQzdDLFdBQVMsV0FBVztBQUNwQixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFBQSxFQUNsQyxVQUFFO0FBQ0EsYUFBUyxXQUFXO0FBQUEsRUFDdEI7QUFDRixDQUFDO0FBRUQsV0FBVyxpQkFBaUIsVUFBVSxNQUFNO0FBQzFDLE9BQUssS0FBSyxFQUFFLE1BQU0sdUJBQXVCLElBQUksV0FBVyxRQUFRLENBQUM7QUFDbkUsQ0FBQztBQUVELHFCQUFxQixpQkFBaUIsVUFBVSxNQUFNO0FBQ3BELE9BQUssS0FBSyxFQUFFLE1BQU0sMEJBQTBCLElBQUkscUJBQXFCLFFBQVEsQ0FBQztBQUNoRixDQUFDO0FBRUQsYUFBYSxpQkFBaUIsVUFBVSxNQUFNO0FBQzVDLE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLElBQUksYUFBYSxRQUFRLENBQUM7QUFDaEUsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUNELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELG1CQUFpQixjQUFjLG1CQUFtQjtBQUNwRCxDQUFDO0FBQ0QsbUJBQW1CLGlCQUFpQixVQUFVLE1BQU07QUFDbEQsUUFBTSxVQUFVLE9BQU8sbUJBQW1CLEtBQUs7QUFDL0MsTUFBSSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzVCLFNBQUssS0FBSyxFQUFFLE1BQU0sNEJBQTRCLFFBQVEsQ0FBQztBQUFBLEVBQ3pEO0FBQ0YsQ0FBQztBQUVELFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2hELElBQUUsZUFBZTtBQUNqQixRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFHRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsT0FBSyxLQUFLLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUN2QyxDQUFDO0FBRUQsZ0JBQWdCLGlCQUFpQixTQUFTLE1BQU07QUFDOUMsa0JBQWdCLFdBQVc7QUFDM0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNqRCxvQkFBZ0IsV0FBVztBQUFBLEVBQzdCLENBQUM7QUFDSCxDQUFDO0FBRUQsaUJBQWlCLGlCQUFpQixTQUFTLE1BQU07QUFDL0MsbUJBQWlCLFdBQVc7QUFDNUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNsRCxxQkFBaUIsV0FBVztBQUFBLEVBQzlCLENBQUM7QUFDSCxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQscUJBQW1CLFdBQVc7QUFDOUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNyRCx1QkFBbUIsV0FBVztBQUFBLEVBQ2hDLENBQUM7QUFDSCxDQUFDO0FBRUQsb0JBQW9CLGlCQUFpQixTQUFTLE1BQU07QUFDbEQsc0JBQW9CLFdBQVc7QUFDL0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUN0RCx3QkFBb0IsV0FBVztBQUFBLEVBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRUQsWUFBWSxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3BDLENBQUM7QUFFRCxXQUFXLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNqRCxJQUFFLGVBQWU7QUFDakIsT0FBSyxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDbkMsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsWUFBWTtBQUNoRCxRQUFNLEtBQUssRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3JDLGlCQUFlLENBQUMsQ0FBQztBQUNuQixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLFFBQWlCO0FBQ3RELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVO0FBQ3JDLFFBQU0sSUFBSTtBQUNWLE1BQUksRUFBRSxTQUFTLG1CQUFtQixFQUFFLE9BQU87QUFDekMsZ0JBQVksRUFBRTtBQUNkLFVBQU0sRUFBRSxLQUFLO0FBQUEsRUFDZixXQUFXLEVBQUUsU0FBUyxlQUFlLEVBQUUsT0FBTztBQUM1QyxpQkFBYSxFQUFFLEtBQUs7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxTQUFTLGFBQWEsSUFBb0I7QUFFeEMsTUFBSSxhQUFhLG1CQUFtQixVQUFVLFNBQVMsT0FBTyxHQUFHO0FBQy9ELGlCQUFhLGdCQUFnQjtBQUFBLEVBQy9CO0FBQ0EsUUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLEtBQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixRQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsS0FBRyxZQUFZO0FBQ2YsS0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFFBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxPQUFLLFlBQVk7QUFDakIsT0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsUUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLE1BQUksWUFBWTtBQUNoQixNQUFJLGNBQWMsR0FBRztBQUNyQixPQUFLLE9BQU8sR0FBRztBQUNmLFFBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLE1BQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFNBQUssT0FBTyxHQUFHO0FBQUEsRUFDakI7QUFDQSxLQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsZUFBYSxRQUFRLEVBQUU7QUFDdkIsU0FBTyxhQUFhLG9CQUFvQixtQkFBbUI7QUFDekQsaUJBQWEsa0JBQWtCLE9BQU87QUFBQSxFQUN4QztBQUNGO0FBR0EsS0FBSyxhQUFhO0FBQ2xCLEtBQUssZ0JBQWdCO0FBR3JCLFlBQVksTUFBTTtBQUNoQixPQUFLLGFBQWE7QUFDcEIsR0FBRyxJQUFNOyIsCiAgIm5hbWVzIjogW10KfQo=
