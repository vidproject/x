// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = `Auth error \u2014 check your PAT`;
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    autoScrollProgress.textContent = `${fmtNum(as.scrollCount)} scrolls \xB7 ${fmtNum(as.ingestedCount)} tweets ingested \xB7 ${fmtNum(as.expandedCount)} expanded`;
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBTZXR0aW5ncyA9IHtcclxuICBwYXQ6ICcnLFxyXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXHJcbiAgcmVwbzogJ3gnLFxyXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcclxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxyXG4gIGJyYW5jaDogJ21hc3RlcicsXHJcbiAgZW5hYmxlZDogdHJ1ZSxcclxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcclxuICBjb25maWd1cmVkQXQ6IG51bGwsXHJcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01JTl9TRUMgPSAzO1xyXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xyXG5cclxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcclxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxyXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcclxuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1JhcGlkUmVzcG9uc2U0NycsIGxhYmVsOiAnUmFwaWQgUmVzcG9uc2UgNDcnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbl07XHJcblxyXG4vLyBHcmFwaFFMIGVuZHBvaW50IG5hbWVzIHdlIGNhcmUgYWJvdXQgKG1hdGNoZWQgYnkgc3Vic3RyaW5nIGFnYWluc3QgVVJMIHBhdGgpLlxyXG5leHBvcnQgY29uc3QgVFdFRVRfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ1VzZXJUd2VldHMnLFxyXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXHJcbiAgJ1VzZXJNZWRpYScsXHJcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcclxuICAnVHdlZXREZXRhaWwnLFxyXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcclxuICAnTGlrZXMnLFxyXG4gICdCb29rbWFya3MnLFxyXG4gICdIb21lVGltZWxpbmUnLFxyXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxyXG4gICdTZWFyY2hUaW1lbGluZScsXHJcbiAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXHJcbl0pO1xyXG5cclxuLy8gRW5kcG9pbnRzIHRoYXQgY2FycnkgQ29tbXVuaXR5IE5vdGUgYm9kaWVzIFx1MjAxNCBjYXB0dXJlZCBmb3IgY29tcGxldGVuZXNzIGJ1dFxyXG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxyXG5leHBvcnQgY29uc3QgQklSRFdBVENIX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdCaXJkd2F0Y2hGZXRjaE9uZU5vdGUnLFxyXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcclxuXSk7XHJcblxyXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcclxuLy8gdG8gbGVhcm4gYWNjb3VudF9pZCA8LT4gaGFuZGxlIGJpbmRpbmdzKS5cclxuZXhwb3J0IGNvbnN0IFBST0ZJTEVfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJCeVNjcmVlbk5hbWUnLCAnVXNlckJ5UmVzdElkJ10pO1xyXG5cclxuLy8gRW5kcG9pbnRzIHdob3NlIHJlc3BvbnNlcyBhcmUgc2NvcGVkIHRvIGEgcGFydGljdWxhciBhY2NvdW50IG9yXHJcbi8vIGNvbnZlcnNhdGlvbiBcdTIwMTQgaS5lLiB2aXNpdGluZyBgLzxoYW5kbGU+YCAvIGAvPGhhbmRsZT4vd2l0aF9yZXBsaWVzYCxcclxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXHJcbi8vIGVpdGhlciBhdXRob3JlZCBieSB0aGUgdHJhY2tlZCBhY2NvdW50IG9yIGRpcmVjdGx5IHJlZmVyZW5jZWQgYnkgdGhlbVxyXG4vLyAocmV0d2VldGVkLCBxdW90ZWQsIHJlcGxpZWQgdG8pLCBzbyB3ZSBrZWVwIGV2ZXJ5dGhpbmcgd2Ugc2VlIHJhdGhlclxyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXHJcbi8vIGFjY291bnQgc3RpbGwgZ2V0cyBpdHMgb3JpZ2luYWwtdHdlZXQgY29udGVudCBhcmNoaXZlZC5cclxuLy9cclxuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXHJcbi8vIHN0aWxsIGdldCBmaWx0ZXJlZCB0byB0cmFja2VkLWhhbmRsZSBhdXRob3JzIFx1MjAxNCBzZWUgdGhlIHNwZWMnc1xyXG4vLyBcIkJyb3dzaW5nIG15IGhvbWUgdGltZWxpbmUgaXMgaWdub3JlZFwiIHJ1bGUuXHJcbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ1VzZXJUd2VldHMnLFxyXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXHJcbiAgJ1VzZXJNZWRpYScsXHJcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcclxuICAnVHdlZXREZXRhaWwnLFxyXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcclxuXSk7XHJcblxyXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cclxuZXhwb3J0IGNvbnN0IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCA9IDIwMDtcclxuXHJcbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cclxuZXhwb3J0IGNvbnN0IEZMVVNIX0lETEVfTVMgPSA0NV8wMDA7XHJcblxyXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cclxuZXhwb3J0IGNvbnN0IEZMVVNIX0FMQVJNX01JTlVURVMgPSAxO1xyXG5cclxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxyXG5leHBvcnQgY29uc3QgQUNUSVZJVFlfVEFJTF9NQVggPSAyNTA7XHJcblxyXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXHJcbmV4cG9ydCBjb25zdCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyA9IDEwICogNjAgKiAxMDAwO1xyXG5cclxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XHJcbiIsICIvKipcclxuICogc2lkZWJhci50cyBcdTIwMTQgVUkgZm9yIHRoZSBwZXJzaXN0ZW50IHNpZGViYXIuXHJcbiAqXHJcbiAqIFNpZGViYXJzIGluIEZpcmVmb3ggc3RheSBvcGVuIGFjcm9zcyB0YWIvd2luZG93IHN3aXRjaGVzLCB3aGljaCBpcyB0aGVcclxuICogaW50ZW5kZWQgcGVyc2lzdGVuY2UgbW9kZWwuIFRoaXMgbW9kdWxlIHJlbmRlcnMgc3RhdGUgcHVzaGVkIGZyb20gdGhlXHJcbiAqIGJhY2tncm91bmQgc2VydmljZSB3b3JrZXIgYW5kIGZvcndhcmRzIHVzZXIgY29tbWFuZHMgYmFjay5cclxuICovXHJcblxyXG5pbXBvcnQgeyBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XHJcbmltcG9ydCB0eXBlIHsgRXh0ZW5zaW9uU3RhdGUsIExvZ0V2ZW50LCBSdW50aW1lTWVzc2FnZSB9IGZyb20gJy4vbGliL3R5cGVzLmpzJztcclxuXHJcbmNvbnN0ICQgPSA8VCBleHRlbmRzIEhUTUxFbGVtZW50ID0gSFRNTEVsZW1lbnQ+KGlkOiBzdHJpbmcpOiBUID0+IHtcclxuICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcclxuICBpZiAoIWVsKSB0aHJvdyBuZXcgRXJyb3IoYG1pc3NpbmcgZWxlbWVudCAjJHtpZH1gKTtcclxuICByZXR1cm4gZWwgYXMgVDtcclxufTtcclxuXHJcbmNvbnN0IGNvbm5Eb3QgPSAkKCdjb25uLWRvdCcpO1xyXG5jb25zdCBjb25uVGV4dCA9ICQ8SFRNTFNwYW5FbGVtZW50PignY29ubi10ZXh0Jyk7XHJcbmNvbnN0IGFjY291bnRMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWNjb3VudC1saXN0Jyk7XHJcbmNvbnN0IGFjdGl2aXR5TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjdGl2aXR5LWxpc3QnKTtcclxuY29uc3QgYXV0b1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tY2FwdHVyZScpO1xyXG5jb25zdCBjYXB0dXJlQWxsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtYWxsJyk7XHJcbmNvbnN0IGNhcHR1cmVUaGlzQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtdGhpcycpO1xyXG5jb25zdCBmbHVzaEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdmbHVzaC1hbGwnKTtcclxuY29uc3Qgb3B0aW9uc0xpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi1vcHRpb25zJyk7XHJcbmNvbnN0IHZpZXdlckxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi12aWV3ZXInKTtcclxuY29uc3QgY2xlYXJBY3RCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2xlYXItYWN0aXZpdHknKTtcclxuY29uc3QgZXh0VmVyc2lvbkVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdleHQtdmVyc2lvbicpO1xyXG5jb25zdCBtYXN0ZXJTd2l0Y2ggPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdtYXN0ZXItc3dpdGNoJyk7XHJcbmNvbnN0IG1hc3RlckxhYmVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtYXN0ZXItbGFiZWwnKTtcclxuY29uc3QgYXV0b1Njcm9sbEludGVydmFsID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1zY3JvbGwtaW50ZXJ2YWwnKTtcclxuY29uc3QgYXV0b1Njcm9sbFNlY3NFbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc2VjcycpO1xyXG5jb25zdCBhdXRvU2Nyb2xsU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zdGF0dXMnKTtcclxuY29uc3QgYXV0b1Njcm9sbFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXN0YXJ0Jyk7XHJcbmNvbnN0IGF1dG9TY3JvbGxDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtY2FuY2VsJyk7XHJcbmNvbnN0IGF1dG9TY3JvbGxQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtcHJvZ3Jlc3MnKTtcclxuY29uc3QgcmVmZXRjaFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PigncmVmZXRjaC1zZWN0aW9uJyk7XHJcbmNvbnN0IHJlZmV0Y2hDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1jb3VudCcpO1xyXG5jb25zdCByZWZldGNoU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1zdGFydCcpO1xyXG5jb25zdCByZWZldGNoQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZmV0Y2gtY2FuY2VsJyk7XHJcbmNvbnN0IHJlZmV0Y2hQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1wcm9ncmVzcycpO1xyXG5jb25zdCBtZWRpYUNyYXdsU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1zZWN0aW9uJyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtY291bnQnKTtcclxuY29uc3QgbWVkaWFDcmF3bFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLXN0YXJ0Jyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignbWVkaWEtY3Jhd2wtY2FuY2VsJyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtcHJvZ3Jlc3MnKTtcclxuY29uc3QgcHVyZ2VMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ3B1cmdlLXVucmVsYXRlZCcpO1xyXG5cclxubGV0IGxhc3RTdGF0ZTogRXh0ZW5zaW9uU3RhdGUgfCBudWxsID0gbnVsbDtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNlbmQ8VD4obXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8VD4ge1xyXG4gIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKSBhcyBQcm9taXNlPFQ+O1xyXG59XHJcblxyXG5mdW5jdGlvbiBzZXRDb25uU3RhdHVzKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xyXG4gIGNvbnN0IHsgY29ubmVjdGlvbiwgc2V0dGluZ3MgfSA9IHN0YXRlO1xyXG4gIGxldCBjbHMgPSAnJztcclxuICBsZXQgdGV4dCA9ICcnO1xyXG4gIC8vIE9ubHkgd2FybiB3aGVuIHRoZSBjb25maWd1cmVkIGJyYW5jaCBnZW51aW5lbHkgZG9lc24ndCBleGlzdCBvbiB0aGVcclxuICAvLyByZW1vdGUuIEEgbm9uLWRlZmF1bHQgYnJhbmNoIHRoYXQgZXhpc3RzIGlzIGZpbmUgXHUyMDE0IGNhcHR1cmluZyBpbnRvIGFcclxuICAvLyB3b3JraW5nIGJyYW5jaCBpcyByb3V0aW5lIFx1MjAxNCBzbyB0aGUgbWVyZSBgIT09YCB0byBkZWZhdWx0X2JyYW5jaCBpcyBub3RcclxuICAvLyBhIHByb2JsZW0gYW5kIHNob3VsZG4ndCBzaG91dCBpbiB0aGUgaGVhZGVyLlxyXG4gIGNvbnN0IGJyYW5jaE1pc3NpbmcgPVxyXG4gICAgY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycgJiYgc2V0dGluZ3MuYnJhbmNoICYmIGNvbm5lY3Rpb24uY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gZmFsc2U7XHJcbiAgaWYgKCFzZXR0aW5ncy5wYXRTZXQpIHtcclxuICAgIGNscyA9ICd3YXJuJztcclxuICAgIHRleHQgPSAnTm90IGNvbmZpZ3VyZWQgXHUyMDE0IG9wZW4gU2V0dGluZ3MnO1xyXG4gIH0gZWxzZSBpZiAoYnJhbmNoTWlzc2luZykge1xyXG4gICAgY2xzID0gJ2Vycic7XHJcbiAgICB0ZXh0ID0gYEJyYW5jaCBcIiR7c2V0dGluZ3MuYnJhbmNofVwiIGRvZXMgbm90IGV4aXN0IG9uICR7c2V0dGluZ3Mub3duZXJ9LyR7c2V0dGluZ3MucmVwb30gXHUyMDE0IGNvbW1pdHMgd2lsbCA0MjIuIFNldCBicmFuY2ggdG8gXCIke2Nvbm5lY3Rpb24uZGVmYXVsdEJyYW5jaCA/PyAnbWFzdGVyJ31cIiBpbiBTZXR0aW5ncy5gO1xyXG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycpIHtcclxuICAgIGNscyA9ICdvayc7XHJcbiAgICB0ZXh0ID0gYENvbm5lY3RlZCBhcyBAJHtjb25uZWN0aW9uLmxvZ2luID8/ICc/J30gdG8gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTAwQjcgXHUyMDI2JHtzZXR0aW5ncy5wYXRTdWZmaXh9YDtcclxuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcclxuICAgIGNscyA9ICdlcnInO1xyXG4gICAgdGV4dCA9IGBBdXRoIGVycm9yIFx1MjAxNCBjaGVjayB5b3VyIFBBVGA7XHJcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcclxuICAgIGNscyA9ICd3YXJuJztcclxuICAgIGNvbnN0IHJlc2V0cyA9IGZtdFJhdGVMaW1pdFJlc2V0KGNvbm5lY3Rpb24ucmF0ZUxpbWl0UmVzZXRBdCk7XHJcbiAgICB0ZXh0ID0gcmVzZXRzXHJcbiAgICAgID8gYEdpdEh1YiByYXRlLWxpbWl0ZWQgXHUyMDE0IHJlc2V0cyAke3Jlc2V0c31gXHJcbiAgICAgIDogJ0dpdEh1YiByYXRlLWxpbWl0ZWQgXHUyMDE0IGNhcHR1cmVzIHdpbGwgcmV0cnknO1xyXG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICduZXR3b3JrLWVycm9yJykge1xyXG4gICAgY2xzID0gJ2Vycic7XHJcbiAgICB0ZXh0ID0gJ05ldHdvcmsgZXJyb3IgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpdml0eSc7XHJcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ25vdC1jb25maWd1cmVkJykge1xyXG4gICAgY2xzID0gJ3dhcm4nO1xyXG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XHJcbiAgfSBlbHNlIHtcclxuICAgIGNscyA9ICcnO1xyXG4gICAgdGV4dCA9ICdDaGVja2luZ1x1MjAyNic7XHJcbiAgfVxyXG4gIGNvbm5Eb3QuY2xhc3NOYW1lID0gYGRvdCAke2Nsc31gO1xyXG4gIGNvbm5UZXh0LnRleHRDb250ZW50ID0gdGV4dDtcclxuICBjb25uVGV4dC50aXRsZSA9IGNvbm5lY3Rpb24uZXJyb3IgPz8gJyc7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZtdFJlbChpc286IHN0cmluZyB8IG51bGwpOiBzdHJpbmcge1xyXG4gIGlmICghaXNvKSByZXR1cm4gJ1x1MjAxNCc7XHJcbiAgY29uc3QgZCA9IERhdGUucGFyc2UoaXNvKTtcclxuICBpZiAoIU51bWJlci5pc0Zpbml0ZShkKSkgcmV0dXJuICdcdTIwMTQnO1xyXG4gIGNvbnN0IHNlY3MgPSBNYXRoLm1heCgwLCBNYXRoLnJvdW5kKChEYXRlLm5vdygpIC0gZCkgLyAxMDAwKSk7XHJcbiAgaWYgKHNlY3MgPCA1KSByZXR1cm4gJ2p1c3Qgbm93JztcclxuICBpZiAoc2VjcyA8IDYwKSByZXR1cm4gYCR7c2Vjc31zIGFnb2A7XHJcbiAgY29uc3QgbWlucyA9IE1hdGgucm91bmQoc2VjcyAvIDYwKTtcclxuICBpZiAobWlucyA8IDYwKSByZXR1cm4gYCR7bWluc31tIGFnb2A7XHJcbiAgY29uc3QgaG91cnMgPSBNYXRoLnJvdW5kKG1pbnMgLyA2MCk7XHJcbiAgaWYgKGhvdXJzIDwgMjQpIHJldHVybiBgJHtob3Vyc31oIGFnb2A7XHJcbiAgY29uc3QgZGF5cyA9IE1hdGgucm91bmQoaG91cnMgLyAyNCk7XHJcbiAgcmV0dXJuIGAke2RheXN9ZCBhZ29gO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmbXRSYXRlTGltaXRSZXNldChlcG9jaFNlYzogbnVtYmVyIHwgbnVsbCk6IHN0cmluZyB7XHJcbiAgaWYgKGVwb2NoU2VjID09PSBudWxsKSByZXR1cm4gJyc7XHJcbiAgY29uc3QgZGVsdGFTZWMgPSBlcG9jaFNlYyAtIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xyXG4gIGlmIChkZWx0YVNlYyA8PSAwKSByZXR1cm4gJ21vbWVudGFyaWx5JztcclxuICBjb25zdCB3YWxsQ2xvY2sgPSBuZXcgRGF0ZShlcG9jaFNlYyAqIDEwMDApLnRvTG9jYWxlVGltZVN0cmluZyhbXSwge1xyXG4gICAgaG91cjogJzItZGlnaXQnLFxyXG4gICAgbWludXRlOiAnMi1kaWdpdCcsXHJcbiAgfSk7XHJcbiAgaWYgKGRlbHRhU2VjIDwgNjApIHJldHVybiBgaW4gJHtkZWx0YVNlY31zICgke3dhbGxDbG9ja30pYDtcclxuICBjb25zdCBtaW5zID0gTWF0aC5yb3VuZChkZWx0YVNlYyAvIDYwKTtcclxuICBpZiAobWlucyA8IDYwKSByZXR1cm4gYGluICR7bWluc31tICgke3dhbGxDbG9ja30pYDtcclxuICBjb25zdCBob3VycyA9IE1hdGgucm91bmQobWlucyAvIDYwKTtcclxuICByZXR1cm4gYGluICR7aG91cnN9aCAoJHt3YWxsQ2xvY2t9KWA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZtdE51bShuOiBudW1iZXIpOiBzdHJpbmcge1xyXG4gIHJldHVybiBuLnRvTG9jYWxlU3RyaW5nKCdlbi1VUycpO1xyXG59XHJcblxyXG5mdW5jdGlvbiByZW5kZXJBY2NvdW50cyhzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBhY2NvdW50TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcclxuICBpZiAoc3RhdGUuYWNjb3VudHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xyXG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWNjb3VudHMgY29uZmlndXJlZC4nO1xyXG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgZm9yIChjb25zdCBhIG9mIHN0YXRlLmFjY291bnRzKSB7XHJcbiAgICBjb25zdCBjID0gc3RhdGUuY291bnRlcnNbYS5oYW5kbGVdO1xyXG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xyXG4gICAgbGkuY2xhc3NOYW1lID0gYyAmJiBjLmJ1ZmZlcmVkQ291bnQgPiAwID8gJ2FjYyBwZW5kaW5nJyA6ICdhY2MnO1xyXG5cclxuICAgIGNvbnN0IGhlYWQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIGhlYWQuY2xhc3NOYW1lID0gJ2FjYy1oZWFkJztcclxuICAgIGNvbnN0IGhhbmRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIGhhbmRsZS5jbGFzc05hbWUgPSAnYWNjLWhhbmRsZSc7XHJcbiAgICBoYW5kbGUuaW5uZXJIVE1MID0gYDxzcGFuIGNsYXNzPVwiYXRcIj5APC9zcGFuPiR7ZXNjYXBlSHRtbChhLmhhbmRsZSl9YDtcclxuICAgIGNvbnN0IG1ldGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBtZXRhLmNsYXNzTmFtZSA9ICdhY2MtbWV0YSc7XHJcbiAgICBtZXRhLnRleHRDb250ZW50ID0gYS5sYWJlbDtcclxuICAgIGhlYWQuYXBwZW5kKGhhbmRsZSwgbWV0YSk7XHJcblxyXG4gICAgY29uc3Qgcm93ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICByb3cuY2xhc3NOYW1lID0gJ2FjYy1yb3cnO1xyXG4gICAgY29uc3Qgc3RhdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBzdGF0cy5jbGFzc05hbWUgPSAnYWNjLXN0YXRzJztcclxuICAgIGNvbnN0IHRvZGF5ID0gYz8udG9kYXlDb3VudCA/PyAwO1xyXG4gICAgY29uc3QgYnVmZmVyZWQgPSBjPy5idWZmZXJlZENvdW50ID8/IDA7XHJcbiAgICBjb25zdCBsYXN0ID0gYz8ubGFzdENhcHR1cmVBdCA/PyBudWxsO1xyXG4gICAgc3RhdHMuaW5uZXJIVE1MID1cclxuICAgICAgYDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0odG9kYXkpfTwvc3Bhbj4gdG9kYXlgICtcclxuICAgICAgKGJ1ZmZlcmVkID4gMCA/IGAgXHUwMEI3IDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0oYnVmZmVyZWQpfTwvc3Bhbj4gYnVmZmVyZWRgIDogJycpICtcclxuICAgICAgYCBcdTAwQjcgbGFzdCAke2VzY2FwZUh0bWwoZm10UmVsKGxhc3QpKX1gO1xyXG5cclxuICAgIGNvbnN0IGFjdGlvbnMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBhY3Rpb25zLmNsYXNzTmFtZSA9ICdhY2MtYWN0aW9uJztcclxuICAgIGNvbnN0IGJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xyXG4gICAgYnRuLmNsYXNzTmFtZSA9ICdidG4nO1xyXG4gICAgYnRuLnRleHRDb250ZW50ID0gJ0NhcHR1cmUgbm93JztcclxuICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICAgICAgYnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtbm93JywgaGFuZGxlOiBhLmhhbmRsZSB9KTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBidG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICBhY3Rpb25zLmFwcGVuZChidG4pO1xyXG5cclxuICAgIHJvdy5hcHBlbmQoc3RhdHMsIGFjdGlvbnMpO1xyXG4gICAgbGkuYXBwZW5kKGhlYWQsIHJvdyk7XHJcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcmVuZGVyQWN0aXZpdHkoZXZlbnRzOiBMb2dFdmVudFtdKTogdm9pZCB7XHJcbiAgYWN0aXZpdHlMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xyXG4gIGlmIChldmVudHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xyXG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWN0aXZpdHkgeWV0Lic7XHJcbiAgICBhY3Rpdml0eUxpc3QuYXBwZW5kKGxpKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgZm9yIChjb25zdCBldiBvZiBldmVudHMuc2xpY2UoMCwgQUNUSVZJVFlfVEFJTF9NQVgpKSB7XHJcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xyXG4gICAgY29uc3QgdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICB0cy5jbGFzc05hbWUgPSAnZXYtdHMnO1xyXG4gICAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcclxuICAgIGNvbnN0IGljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBpY29uLmNsYXNzTmFtZSA9ICdldi1pY29uJztcclxuICAgIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xyXG4gICAgY29uc3QgYm9keSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIGNvbnN0IG1zZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xyXG4gICAgbXNnLnRleHRDb250ZW50ID0gZXYubXNnO1xyXG4gICAgYm9keS5hcHBlbmQobXNnKTtcclxuICAgIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcclxuICAgIGlmIChjdHhLZXlzLmxlbmd0aCA+IDApIHtcclxuICAgICAgY29uc3QgY3R4ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcclxuICAgICAgY3R4LnRleHRDb250ZW50ID0gY3R4S2V5cy5tYXAoKGspID0+IGAke2t9PSR7c3RyaW5naWZ5U2hvcnQoZXYuY29udGV4dFtrXSl9YCkuam9pbignIFx1MDBCNyAnKTtcclxuICAgICAgYm9keS5hcHBlbmQoY3R4KTtcclxuICAgIH1cclxuICAgIGxpLmFwcGVuZCh0cywgaWNvbiwgYm9keSk7XHJcbiAgICBhY3Rpdml0eUxpc3QuYXBwZW5kKGxpKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHN0cmluZ2lmeVNob3J0KHY6IHVua25vd24pOiBzdHJpbmcge1xyXG4gIGlmICh2ID09PSBudWxsKSByZXR1cm4gJ251bGwnO1xyXG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycpIHJldHVybiB2Lmxlbmd0aCA+IDgwID8gYCR7di5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHY7XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gU3RyaW5nKHYpO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzID0gSlNPTi5zdHJpbmdpZnkodik7XHJcbiAgICByZXR1cm4gcy5sZW5ndGggPiA4MCA/IGAke3Muc2xpY2UoMCwgODApfVx1MjAyNmAgOiBzO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuICc/JztcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGVzY2FwZUh0bWwoczogc3RyaW5nKTogc3RyaW5nIHtcclxuICByZXR1cm4gcy5yZXBsYWNlKC9bJjw+XCInXS9nLCAoYykgPT5cclxuICAgIGMgPT09ICcmJyA/ICcmYW1wOycgOiBjID09PSAnPCcgPyAnJmx0OycgOiBjID09PSAnPicgPyAnJmd0OycgOiBjID09PSAnXCInID8gJyZxdW90OycgOiAnJiMzOTsnXHJcbiAgKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaFN0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHRyeSB7XHJcbiAgICBsYXN0U3RhdGUgPSBhd2FpdCBzZW5kPEV4dGVuc2lvblN0YXRlPih7IHR5cGU6ICdnZXQtc3RhdGUnIH0pO1xyXG4gICAgcGFpbnQobGFzdFN0YXRlKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBzaWRlYmFyIHJlZnJlc2hTdGF0ZSBmYWlsZWQnLCBlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcGFpbnQoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgZXh0VmVyc2lvbkVsLnRleHRDb250ZW50ID0gc3RhdGUudmVyc2lvbjtcclxuICBzZXRDb25uU3RhdHVzKHN0YXRlKTtcclxuICBhdXRvVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvQ2FwdHVyZTtcclxuICB2aWV3ZXJMaW5rLmhyZWYgPSBgaHR0cHM6Ly8ke3N0YXRlLnNldHRpbmdzLm93bmVyfS5naXRodWIuaW8vJHtzdGF0ZS5zZXR0aW5ncy5yZXBvfS9gO1xyXG4gIHBhaW50TWFzdGVyU3dpdGNoKHN0YXRlKTtcclxuICByZW5kZXJBY2NvdW50cyhzdGF0ZSk7XHJcbiAgcGFpbnRBdXRvU2Nyb2xsKHN0YXRlKTtcclxuICBwYWludE1lZGlhQ3Jhd2woc3RhdGUpO1xyXG4gIHBhaW50UmVmZXRjaChzdGF0ZSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhaW50TWVkaWFDcmF3bChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBjb25zdCBxID0gc3RhdGUubWVkaWFDcmF3bFF1ZXVlO1xyXG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcclxuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xyXG4gIG1lZGlhQ3Jhd2xTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xyXG4gIG1lZGlhQ3Jhd2xDb3VudC50ZXh0Q29udGVudCA9XHJcbiAgICB0b3RhbCA9PT0gMFxyXG4gICAgICA/IHJ1bm5pbmdcclxuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXHJcbiAgICAgICAgOiAnMCBxdWV1ZWQnXHJcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xyXG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xyXG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xyXG4gIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XHJcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKG1lZGlhQ3Jhd2xQcm9ncmVzcywgcSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhaW50UXVldWVQcm9ncmVzcyhcclxuICBlbDogSFRNTFNwYW5FbGVtZW50LFxyXG4gIHE6IHsgcHJvY2Vzc2VkOiBudW1iZXI7IHRvdGFsX2F0X3N0YXJ0OiBudW1iZXI7IHJ1bm5pbmc6IGJvb2xlYW47IHRvdGFsOiBudW1iZXIgfVxyXG4pOiB2b2lkIHtcclxuICBpZiAoIXEucnVubmluZyAmJiBxLnByb2Nlc3NlZCA9PT0gMCkge1xyXG4gICAgZWwuaGlkZGVuID0gdHJ1ZTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgLy8gRGVub21pbmF0b3I6IG1heCBvZiBpbml0aWFsIHRvdGFsIGFuZCBjdXJyZW50IHByb2Nlc3NlZCtyZW1haW5pbmcgc28gdGhlXHJcbiAgLy8gYmFyIHN0aWxsIG1ha2VzIHNlbnNlIGlmIG5ldyBlbnRyaWVzIHdlcmUgZW5xdWV1ZWQgbWlkLXJ1bi5cclxuICBjb25zdCBkZW5vbSA9IE1hdGgubWF4KHEudG90YWxfYXRfc3RhcnQsIHEucHJvY2Vzc2VkICsgcS50b3RhbCk7XHJcbiAgZWwuaGlkZGVuID0gZmFsc2U7XHJcbiAgZWwudGV4dENvbnRlbnQgPSBgJHtmbXROdW0ocS5wcm9jZXNzZWQpfSAvICR7Zm10TnVtKGRlbm9tKX0gcHJvY2Vzc2VkYDtcclxuICBlbC5jbGFzc05hbWUgPSBxLnJ1bm5pbmcgPyAncHJvZ3Jlc3Mgb24nIDogJ3Byb2dyZXNzJztcclxufVxyXG5cclxuZnVuY3Rpb24gcGFpbnRNYXN0ZXJTd2l0Y2goc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgY29uc3Qgb24gPSBzdGF0ZS5zZXR0aW5ncy5lbmFibGVkICE9PSBmYWxzZTtcclxuICBtYXN0ZXJTd2l0Y2guY2hlY2tlZCA9IG9uO1xyXG4gIG1hc3RlckxhYmVsLnRleHRDb250ZW50ID0gb24gPyAnT04nIDogJ1BBVVNFRCc7XHJcbiAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKCdwYXVzZWQnLCAhb24pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYWludEF1dG9TY3JvbGwoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgY29uc3Qgc2VjcyA9IHN0YXRlLnNldHRpbmdzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYztcclxuICBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWUgPSBTdHJpbmcoc2Vjcyk7XHJcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IFN0cmluZyhzZWNzKTtcclxuICBjb25zdCBhcyA9IHN0YXRlLmF1dG9TY3JvbGw7XHJcbiAgYXV0b1Njcm9sbFN0YXJ0QnRuLmhpZGRlbiA9IGFzLmFjdGl2ZTtcclxuICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmhpZGRlbiA9ICFhcy5hY3RpdmU7XHJcbiAgaWYgKGFzLmFjdGl2ZSkge1xyXG4gICAgY29uc3QgbiA9IGFzLnRhYkNvdW50O1xyXG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9XHJcbiAgICAgIG4gPT09IDAgPyBgcnVubmluZyBcdTIwMTQgbm8gWCB0YWJzIG9wZW5gIDogYHJ1bm5pbmcgXHUyMDE0ICR7bn0gJHtuID09PSAxID8gJ3RhYicgOiAndGFicyd9YDtcclxuICAgIGF1dG9TY3JvbGxTdGF0dXMuY2xhc3NOYW1lID0gJ211dGVkIG9uJztcclxuICB9IGVsc2Uge1xyXG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9ICdpZGxlJztcclxuICAgIGF1dG9TY3JvbGxTdGF0dXMuY2xhc3NOYW1lID0gJ211dGVkJztcclxuICB9XHJcbiAgaWYgKGFzLmFjdGl2ZSB8fCBhcy5zY3JvbGxDb3VudCA+IDAgfHwgYXMuaW5nZXN0ZWRDb3VudCA+IDApIHtcclxuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy5oaWRkZW4gPSBmYWxzZTtcclxuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy50ZXh0Q29udGVudCA9XHJcbiAgICAgIGAke2ZtdE51bShhcy5zY3JvbGxDb3VudCl9IHNjcm9sbHMgXHUwMEI3IGAgK1xyXG4gICAgICBgJHtmbXROdW0oYXMuaW5nZXN0ZWRDb3VudCl9IHR3ZWV0cyBpbmdlc3RlZCBcdTAwQjcgYCArXHJcbiAgICAgIGAke2ZtdE51bShhcy5leHBhbmRlZENvdW50KX0gZXhwYW5kZWRgO1xyXG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmNsYXNzTmFtZSA9IGFzLmFjdGl2ZSA/ICdwcm9ncmVzcyBvbicgOiAncHJvZ3Jlc3MnO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuaGlkZGVuID0gdHJ1ZTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhaW50UmVmZXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBjb25zdCBxID0gc3RhdGUucmVmZXRjaFF1ZXVlO1xyXG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcclxuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xyXG4gIHJlZmV0Y2hTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xyXG4gIHJlZmV0Y2hDb3VudC50ZXh0Q29udGVudCA9XHJcbiAgICB0b3RhbCA9PT0gMFxyXG4gICAgICA/IHJ1bm5pbmdcclxuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXHJcbiAgICAgICAgOiAnMCBxdWV1ZWQnXHJcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xyXG4gIHJlZmV0Y2hTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xyXG4gIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xyXG4gIHJlZmV0Y2hDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XHJcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKHJlZmV0Y2hQcm9ncmVzcywgcSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hBY3Rpdml0eSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAvLyBQdWxsIHN0cmFpZ2h0IGZyb20gc3RvcmFnZSBvbiBmaXJzdCByZW5kZXI7IGxpdmUgdXBkYXRlcyBjb21lIHZpYVxyXG4gIC8vIGBsb2ctZXZlbnRgIGJyb2FkY2FzdHMuXHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldCgnYWN0aXZpdHknKTtcclxuICBjb25zdCBldmVudHMgPSAoc3RvcmVkLmFjdGl2aXR5IGFzIExvZ0V2ZW50W10gfCB1bmRlZmluZWQpID8/IFtdO1xyXG4gIHJlbmRlckFjdGl2aXR5KGV2ZW50cyk7XHJcbn1cclxuXHJcbi8vIC0tLSBXaXJlIHVwIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5jYXB0dXJlQWxsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xyXG4gIGNhcHR1cmVBbGxCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtYWxsJyB9KTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgY2FwdHVyZUFsbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH1cclxufSk7XHJcblxyXG5jYXB0dXJlVGhpc0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICBjYXB0dXJlVGhpc0J0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS10aGlzLXBhZ2UnIH0pO1xyXG4gIH0gZmluYWxseSB7XHJcbiAgICBjYXB0dXJlVGhpc0J0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH1cclxufSk7XHJcblxyXG5mbHVzaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICBmbHVzaEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnZmx1c2gtYWxsJyB9KTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgZmx1c2hCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9XHJcbn0pO1xyXG5cclxuYXV0b1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1hdXRvLWNhcHR1cmUnLCBvbjogYXV0b1RvZ2dsZS5jaGVja2VkIH0pO1xyXG59KTtcclxuXHJcbm1hc3RlclN3aXRjaC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1lbmFibGVkJywgb246IG1hc3RlclN3aXRjaC5jaGVja2VkIH0pO1xyXG59KTtcclxuXHJcbmF1dG9TY3JvbGxTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC1hdXRvLXNjcm9sbCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9KTtcclxufSk7XHJcbmF1dG9TY3JvbGxDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgYXV0b1Njcm9sbENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1hdXRvLXNjcm9sbCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JywgKCkgPT4ge1xyXG4gIGF1dG9TY3JvbGxTZWNzRWwudGV4dENvbnRlbnQgPSBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWU7XHJcbn0pO1xyXG5hdXRvU2Nyb2xsSW50ZXJ2YWwuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xyXG4gIGNvbnN0IHNlY29uZHMgPSBOdW1iZXIoYXV0b1Njcm9sbEludGVydmFsLnZhbHVlKTtcclxuICBpZiAoTnVtYmVyLmlzRmluaXRlKHNlY29uZHMpKSB7XHJcbiAgICB2b2lkIHNlbmQoeyB0eXBlOiAnc2V0LWF1dG8tc2Nyb2xsLWludGVydmFsJywgc2Vjb25kcyB9KTtcclxuICB9XHJcbn0pO1xyXG5cclxucHVyZ2VMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XHJcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIGNvbnN0IG9rID0gd2luZG93LmNvbmZpcm0oXHJcbiAgICAnRHJvcCBldmVyeSBjb3VudGVyLCBydW4gYnVmZmVyLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcXVldWUgZW50cnkgZm9yIGFjY291bnRzIG5vdCBpbiB5b3VyIHRyYWNrZWQgbGlzdD9cXG5cXG4nICtcclxuICAgICAgJ1RoaXMgb25seSB0b3VjaGVzIGxvY2FsIGV4dGVuc2lvbiBzdGF0ZS4gQWxyZWFkeS1jb21taXR0ZWQgZmlsZXMgaW4gdGhlIEdpdEh1YiByZXBvIGFyZSBub3QgYWZmZWN0ZWQgXHUyMDE0ICcgK1xyXG4gICAgICAncnVuIHNjcmlwdHMvcHVyZ2VfdW5yZWxhdGVkLnB5IHNlcGFyYXRlbHkgaWYgeW91IGFsc28gd2FudCB0byBzY3J1YiB0aGUgcmVwby4nXHJcbiAgKTtcclxuICBpZiAoIW9rKSByZXR1cm47XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3B1cmdlLXVucmVsYXRlZCcgfSk7XHJcbn0pO1xyXG5cclxucmVmZXRjaFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xyXG4gICAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxucmVmZXRjaENhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xyXG4gICAgcmVmZXRjaENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH0pO1xyXG59KTtcclxuXHJcbm1lZGlhQ3Jhd2xTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC1tZWRpYS1jcmF3bCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9KTtcclxufSk7XHJcblxyXG5tZWRpYUNyYXdsQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xyXG4gICAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH0pO1xyXG59KTtcclxuXHJcbm9wdGlvbnNMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XHJcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdvcGVuLW9wdGlvbnMnIH0pO1xyXG59KTtcclxuXHJcbnZpZXdlckxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcclxuICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ29wZW4tdmlld2VyJyB9KTtcclxufSk7XHJcblxyXG5jbGVhckFjdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NsZWFyLWFjdGl2aXR5JyB9KTtcclxuICByZW5kZXJBY3Rpdml0eShbXSk7XHJcbn0pO1xyXG5cclxuYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiB1bmtub3duKSA9PiB7XHJcbiAgaWYgKCFtc2cgfHwgdHlwZW9mIG1zZyAhPT0gJ29iamVjdCcpIHJldHVybjtcclxuICBjb25zdCBtID0gbXNnIGFzIHsgdHlwZT86IHN0cmluZzsgc3RhdGU/OiBFeHRlbnNpb25TdGF0ZTsgZXZlbnQ/OiBMb2dFdmVudCB9O1xyXG4gIGlmIChtLnR5cGUgPT09ICdzdGF0ZS1jaGFuZ2VkJyAmJiBtLnN0YXRlKSB7XHJcbiAgICBsYXN0U3RhdGUgPSBtLnN0YXRlO1xyXG4gICAgcGFpbnQobS5zdGF0ZSk7XHJcbiAgfSBlbHNlIGlmIChtLnR5cGUgPT09ICdsb2ctZXZlbnQnICYmIG0uZXZlbnQpIHtcclxuICAgIHByZXBlbmRFdmVudChtLmV2ZW50KTtcclxuICB9XHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gcHJlcGVuZEV2ZW50KGV2OiBMb2dFdmVudCk6IHZvaWQge1xyXG4gIC8vIElmIHRoZSBsaXN0IGlzIHNob3dpbmcgdGhlIFwiZW1wdHlcIiBwbGFjZWhvbGRlciwgY2xlYXIgaXQuXHJcbiAgaWYgKGFjdGl2aXR5TGlzdC5maXJzdEVsZW1lbnRDaGlsZD8uY2xhc3NMaXN0LmNvbnRhaW5zKCdlbXB0eScpKSB7XHJcbiAgICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XHJcbiAgfVxyXG4gIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcclxuICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xyXG4gIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XHJcbiAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcclxuICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xyXG4gIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xyXG4gIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xyXG4gIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcclxuICBib2R5LmFwcGVuZChtc2cpO1xyXG4gIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcclxuICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcclxuICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XHJcbiAgICBib2R5LmFwcGVuZChjdHgpO1xyXG4gIH1cclxuICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xyXG4gIGFjdGl2aXR5TGlzdC5wcmVwZW5kKGxpKTtcclxuICB3aGlsZSAoYWN0aXZpdHlMaXN0LmNoaWxkRWxlbWVudENvdW50ID4gQUNUSVZJVFlfVEFJTF9NQVgpIHtcclxuICAgIGFjdGl2aXR5TGlzdC5sYXN0RWxlbWVudENoaWxkPy5yZW1vdmUoKTtcclxuICB9XHJcbn1cclxuXHJcbi8vIEluaXRpYWwgcGFpbnQuXHJcbnZvaWQgcmVmcmVzaFN0YXRlKCk7XHJcbnZvaWQgcmVmcmVzaEFjdGl2aXR5KCk7XHJcblxyXG4vLyBQZXJpb2RpY2FsbHkgcmUtZmV0Y2ggc3RhdGUgc28gXCJsYXN0IGNhcHR1cmVcIiB0aW1lcyBzdGF5IGZyZXNoLlxyXG5zZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgdm9pZCByZWZyZXNoU3RhdGUoKTtcclxufSwgMTVfMDAwKTtcclxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQXlGTyxJQUFNLG9CQUFvQjtBQUcxQixJQUFNLGdDQUFnQyxLQUFLLEtBQUs7OztBQ2pGdkQsSUFBTSxJQUFJLENBQXNDLE9BQWtCO0FBQ2hFLFFBQU0sS0FBSyxTQUFTLGVBQWUsRUFBRTtBQUNyQyxNQUFJLENBQUMsR0FBSSxPQUFNLElBQUksTUFBTSxvQkFBb0IsRUFBRSxFQUFFO0FBQ2pELFNBQU87QUFDVDtBQUVBLElBQU0sVUFBVSxFQUFFLFVBQVU7QUFDNUIsSUFBTSxXQUFXLEVBQW1CLFdBQVc7QUFDL0MsSUFBTSxjQUFjLEVBQW9CLGNBQWM7QUFDdEQsSUFBTSxlQUFlLEVBQW9CLGVBQWU7QUFDeEQsSUFBTSxhQUFhLEVBQW9CLGNBQWM7QUFDckQsSUFBTSxnQkFBZ0IsRUFBcUIsYUFBYTtBQUN4RCxJQUFNLGlCQUFpQixFQUFxQixjQUFjO0FBQzFELElBQU0sV0FBVyxFQUFxQixXQUFXO0FBQ2pELElBQU0sY0FBYyxFQUFxQixjQUFjO0FBQ3ZELElBQU0sYUFBYSxFQUFxQixhQUFhO0FBQ3JELElBQU0sY0FBYyxFQUFxQixnQkFBZ0I7QUFDekQsSUFBTSxlQUFlLEVBQW1CLGFBQWE7QUFDckQsSUFBTSxlQUFlLEVBQW9CLGVBQWU7QUFDeEQsSUFBTSxjQUFjLEVBQW1CLGNBQWM7QUFDckQsSUFBTSxxQkFBcUIsRUFBb0Isc0JBQXNCO0FBQ3JFLElBQU0sbUJBQW1CLEVBQW1CLGtCQUFrQjtBQUM5RCxJQUFNLG1CQUFtQixFQUFtQixvQkFBb0I7QUFDaEUsSUFBTSxxQkFBcUIsRUFBcUIsbUJBQW1CO0FBQ25FLElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLHFCQUFxQixFQUFtQixzQkFBc0I7QUFDcEUsSUFBTSxpQkFBaUIsRUFBZSxpQkFBaUI7QUFDdkQsSUFBTSxlQUFlLEVBQW1CLGVBQWU7QUFDdkQsSUFBTSxrQkFBa0IsRUFBcUIsZUFBZTtBQUM1RCxJQUFNLG1CQUFtQixFQUFxQixnQkFBZ0I7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsa0JBQWtCO0FBQzdELElBQU0sb0JBQW9CLEVBQWUscUJBQXFCO0FBQzlELElBQU0sa0JBQWtCLEVBQW1CLG1CQUFtQjtBQUM5RCxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLFlBQVksRUFBcUIsaUJBQWlCO0FBRXhELElBQUksWUFBbUM7QUFFdkMsZUFBZSxLQUFRLEtBQWlDO0FBQ3RELFNBQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUN4QztBQUVBLFNBQVMsY0FBYyxPQUE2QjtBQUNsRCxRQUFNLEVBQUUsWUFBWSxTQUFTLElBQUk7QUFDakMsTUFBSSxNQUFNO0FBQ1YsTUFBSSxPQUFPO0FBS1gsUUFBTSxnQkFDSixXQUFXLFdBQVcsUUFBUSxTQUFTLFVBQVUsV0FBVywyQkFBMkI7QUFDekYsTUFBSSxDQUFDLFNBQVMsUUFBUTtBQUNwQixVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxlQUFlO0FBQ3hCLFVBQU07QUFDTixXQUFPLFdBQVcsU0FBUyxNQUFNLHVCQUF1QixTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksNENBQXVDLFdBQVcsaUJBQWlCLFFBQVE7QUFBQSxFQUNwSyxXQUFXLFdBQVcsV0FBVyxNQUFNO0FBQ3JDLFVBQU07QUFDTixXQUFPLGlCQUFpQixXQUFXLFNBQVMsR0FBRyxPQUFPLFNBQVMsS0FBSyxJQUFJLFNBQVMsSUFBSSxlQUFPLFNBQVMsU0FBUztBQUFBLEVBQ2hILFdBQVcsV0FBVyxXQUFXLGNBQWM7QUFDN0MsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsV0FBVyxXQUFXLGdCQUFnQjtBQUMvQyxVQUFNO0FBQ04sVUFBTSxTQUFTLGtCQUFrQixXQUFXLGdCQUFnQjtBQUM1RCxXQUFPLFNBQ0gscUNBQWdDLE1BQU0sS0FDdEM7QUFBQSxFQUNOLFdBQVcsV0FBVyxXQUFXLGlCQUFpQjtBQUNoRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxXQUFXLFdBQVcsa0JBQWtCO0FBQ2pELFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxPQUFPO0FBQ0wsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0EsVUFBUSxZQUFZLE9BQU8sR0FBRztBQUM5QixXQUFTLGNBQWM7QUFDdkIsV0FBUyxRQUFRLFdBQVcsU0FBUztBQUN2QztBQUVBLFNBQVMsT0FBTyxLQUE0QjtBQUMxQyxNQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLFFBQU0sSUFBSSxLQUFLLE1BQU0sR0FBRztBQUN4QixNQUFJLENBQUMsT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ2hDLFFBQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxHQUFJLENBQUM7QUFDNUQsTUFBSSxPQUFPLEVBQUcsUUFBTztBQUNyQixNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNqQyxNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxNQUFJLFFBQVEsR0FBSSxRQUFPLEdBQUcsS0FBSztBQUMvQixRQUFNLE9BQU8sS0FBSyxNQUFNLFFBQVEsRUFBRTtBQUNsQyxTQUFPLEdBQUcsSUFBSTtBQUNoQjtBQUVBLFNBQVMsa0JBQWtCLFVBQWlDO0FBQzFELE1BQUksYUFBYSxLQUFNLFFBQU87QUFDOUIsUUFBTSxXQUFXLFdBQVcsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDeEQsTUFBSSxZQUFZLEVBQUcsUUFBTztBQUMxQixRQUFNLFlBQVksSUFBSSxLQUFLLFdBQVcsR0FBSSxFQUFFLG1CQUFtQixDQUFDLEdBQUc7QUFBQSxJQUNqRSxNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsRUFDVixDQUFDO0FBQ0QsTUFBSSxXQUFXLEdBQUksUUFBTyxNQUFNLFFBQVEsTUFBTSxTQUFTO0FBQ3ZELFFBQU0sT0FBTyxLQUFLLE1BQU0sV0FBVyxFQUFFO0FBQ3JDLE1BQUksT0FBTyxHQUFJLFFBQU8sTUFBTSxJQUFJLE1BQU0sU0FBUztBQUMvQyxRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxTQUFPLE1BQU0sS0FBSyxNQUFNLFNBQVM7QUFDbkM7QUFFQSxTQUFTLE9BQU8sR0FBbUI7QUFDakMsU0FBTyxFQUFFLGVBQWUsT0FBTztBQUNqQztBQUVBLFNBQVMsZUFBZSxPQUE2QjtBQUNuRCxjQUFZLGdCQUFnQjtBQUM1QixNQUFJLE1BQU0sU0FBUyxXQUFXLEdBQUc7QUFDL0IsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixnQkFBWSxPQUFPLEVBQUU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsYUFBVyxLQUFLLE1BQU0sVUFBVTtBQUM5QixVQUFNLElBQUksTUFBTSxTQUFTLEVBQUUsTUFBTTtBQUNqQyxVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZLEtBQUssRUFBRSxnQkFBZ0IsSUFBSSxnQkFBZ0I7QUFFMUQsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixVQUFNLFNBQVMsU0FBUyxjQUFjLE1BQU07QUFDNUMsV0FBTyxZQUFZO0FBQ25CLFdBQU8sWUFBWSw0QkFBNEIsV0FBVyxFQUFFLE1BQU0sQ0FBQztBQUNuRSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxFQUFFO0FBQ3JCLFNBQUssT0FBTyxRQUFRLElBQUk7QUFFeEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixVQUFNLFFBQVEsU0FBUyxjQUFjLE1BQU07QUFDM0MsVUFBTSxZQUFZO0FBQ2xCLFVBQU0sUUFBUSxHQUFHLGNBQWM7QUFDL0IsVUFBTSxXQUFXLEdBQUcsaUJBQWlCO0FBQ3JDLFVBQU0sT0FBTyxHQUFHLGlCQUFpQjtBQUNqQyxVQUFNLFlBQ0oscUJBQXFCLE9BQU8sS0FBSyxDQUFDLG1CQUNqQyxXQUFXLElBQUksMkJBQXdCLE9BQU8sUUFBUSxDQUFDLHFCQUFxQixNQUM3RSxjQUFXLFdBQVcsT0FBTyxJQUFJLENBQUMsQ0FBQztBQUVyQyxVQUFNLFVBQVUsU0FBUyxjQUFjLE1BQU07QUFDN0MsWUFBUSxZQUFZO0FBQ3BCLFVBQU0sTUFBTSxTQUFTLGNBQWMsUUFBUTtBQUMzQyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjO0FBQ2xCLFFBQUksaUJBQWlCLFNBQVMsWUFBWTtBQUN4QyxVQUFJLFdBQVc7QUFDZixVQUFJO0FBQ0YsY0FBTSxLQUFLLEVBQUUsTUFBTSxlQUFlLFFBQVEsRUFBRSxPQUFPLENBQUM7QUFBQSxNQUN0RCxVQUFFO0FBQ0EsWUFBSSxXQUFXO0FBQUEsTUFDakI7QUFBQSxJQUNGLENBQUM7QUFDRCxZQUFRLE9BQU8sR0FBRztBQUVsQixRQUFJLE9BQU8sT0FBTyxPQUFPO0FBQ3pCLE9BQUcsT0FBTyxNQUFNLEdBQUc7QUFDbkIsZ0JBQVksT0FBTyxFQUFFO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsZUFBZSxRQUEwQjtBQUNoRCxlQUFhLGdCQUFnQjtBQUM3QixNQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsaUJBQWEsT0FBTyxFQUFFO0FBQ3RCO0FBQUEsRUFDRjtBQUNBLGFBQVcsTUFBTSxPQUFPLE1BQU0sR0FBRyxpQkFBaUIsR0FBRztBQUNuRCxVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZLE1BQU0sR0FBRyxLQUFLO0FBQzdCLFVBQU0sS0FBSyxTQUFTLGNBQWMsTUFBTTtBQUN4QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWMsSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxNQUFNLENBQUM7QUFDOUUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsR0FBRyxVQUFVLFVBQVUsV0FBTSxHQUFHLFVBQVUsU0FBUyxNQUFNO0FBQzVFLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYyxHQUFHO0FBQ3JCLFNBQUssT0FBTyxHQUFHO0FBQ2YsVUFBTSxVQUFVLE9BQU8sS0FBSyxHQUFHLE9BQU87QUFDdEMsUUFBSSxRQUFRLFNBQVMsR0FBRztBQUN0QixZQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsVUFBSSxZQUFZO0FBQ2hCLFVBQUksY0FBYyxRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLGVBQWUsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLFFBQUs7QUFDeEYsV0FBSyxPQUFPLEdBQUc7QUFBQSxJQUNqQjtBQUNBLE9BQUcsT0FBTyxJQUFJLE1BQU0sSUFBSTtBQUN4QixpQkFBYSxPQUFPLEVBQUU7QUFBQSxFQUN4QjtBQUNGO0FBRUEsU0FBUyxlQUFlLEdBQW9CO0FBQzFDLE1BQUksTUFBTSxLQUFNLFFBQU87QUFDdkIsTUFBSSxPQUFPLE1BQU0sU0FBVSxRQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFDekUsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLE1BQU0sVUFBVyxRQUFPLE9BQU8sQ0FBQztBQUNwRSxNQUFJO0FBQ0YsVUFBTSxJQUFJLEtBQUssVUFBVSxDQUFDO0FBQzFCLFdBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUFBLEVBQ2hELFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxXQUFXLEdBQW1CO0FBQ3JDLFNBQU8sRUFBRTtBQUFBLElBQVE7QUFBQSxJQUFZLENBQUMsTUFDNUIsTUFBTSxNQUFNLFVBQVUsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLFdBQVc7QUFBQSxFQUN6RjtBQUNGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxNQUFJO0FBQ0YsZ0JBQVksTUFBTSxLQUFxQixFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQzVELFVBQU0sU0FBUztBQUFBLEVBQ2pCLFNBQVMsS0FBSztBQUNaLFlBQVEsS0FBSyw2Q0FBNkMsR0FBRztBQUFBLEVBQy9EO0FBQ0Y7QUFFQSxTQUFTLE1BQU0sT0FBNkI7QUFDMUMsZUFBYSxjQUFjLE1BQU07QUFDakMsZ0JBQWMsS0FBSztBQUNuQixhQUFXLFVBQVUsTUFBTSxTQUFTO0FBQ3BDLGFBQVcsT0FBTyxXQUFXLE1BQU0sU0FBUyxLQUFLLGNBQWMsTUFBTSxTQUFTLElBQUk7QUFDbEYsb0JBQWtCLEtBQUs7QUFDdkIsaUJBQWUsS0FBSztBQUNwQixrQkFBZ0IsS0FBSztBQUNyQixrQkFBZ0IsS0FBSztBQUNyQixlQUFhLEtBQUs7QUFDcEI7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLElBQUksTUFBTTtBQUNoQixRQUFNLFFBQVEsRUFBRTtBQUNoQixRQUFNLFVBQVUsRUFBRTtBQUNsQixvQkFBa0IsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUMzQyxrQkFBZ0IsY0FDZCxVQUFVLElBQ04sVUFDRSxvQkFDQSxhQUNGLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxVQUFVLGtCQUFlLEVBQUU7QUFDM0QscUJBQW1CLFNBQVM7QUFDNUIscUJBQW1CLFdBQVcsVUFBVTtBQUN4QyxzQkFBb0IsU0FBUyxDQUFDO0FBQzlCLHFCQUFtQixvQkFBb0IsQ0FBQztBQUMxQztBQUVBLFNBQVMsbUJBQ1AsSUFDQSxHQUNNO0FBQ04sTUFBSSxDQUFDLEVBQUUsV0FBVyxFQUFFLGNBQWMsR0FBRztBQUNuQyxPQUFHLFNBQVM7QUFDWjtBQUFBLEVBQ0Y7QUFHQSxRQUFNLFFBQVEsS0FBSyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLEtBQUs7QUFDOUQsS0FBRyxTQUFTO0FBQ1osS0FBRyxjQUFjLEdBQUcsT0FBTyxFQUFFLFNBQVMsQ0FBQyxNQUFNLE9BQU8sS0FBSyxDQUFDO0FBQzFELEtBQUcsWUFBWSxFQUFFLFVBQVUsZ0JBQWdCO0FBQzdDO0FBRUEsU0FBUyxrQkFBa0IsT0FBNkI7QUFDdEQsUUFBTSxLQUFLLE1BQU0sU0FBUyxZQUFZO0FBQ3RDLGVBQWEsVUFBVTtBQUN2QixjQUFZLGNBQWMsS0FBSyxPQUFPO0FBQ3RDLFdBQVMsS0FBSyxVQUFVLE9BQU8sVUFBVSxDQUFDLEVBQUU7QUFDOUM7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLE9BQU8sTUFBTSxTQUFTO0FBQzVCLHFCQUFtQixRQUFRLE9BQU8sSUFBSTtBQUN0QyxtQkFBaUIsY0FBYyxPQUFPLElBQUk7QUFDMUMsUUFBTSxLQUFLLE1BQU07QUFDakIscUJBQW1CLFNBQVMsR0FBRztBQUMvQixzQkFBb0IsU0FBUyxDQUFDLEdBQUc7QUFDakMsTUFBSSxHQUFHLFFBQVE7QUFDYixVQUFNLElBQUksR0FBRztBQUNiLHFCQUFpQixjQUNmLE1BQU0sSUFBSSxrQ0FBNkIsa0JBQWEsQ0FBQyxJQUFJLE1BQU0sSUFBSSxRQUFRLE1BQU07QUFDbkYscUJBQWlCLFlBQVk7QUFBQSxFQUMvQixPQUFPO0FBQ0wscUJBQWlCLGNBQWM7QUFDL0IscUJBQWlCLFlBQVk7QUFBQSxFQUMvQjtBQUNBLE1BQUksR0FBRyxVQUFVLEdBQUcsY0FBYyxLQUFLLEdBQUcsZ0JBQWdCLEdBQUc7QUFDM0QsdUJBQW1CLFNBQVM7QUFDNUIsdUJBQW1CLGNBQ2pCLEdBQUcsT0FBTyxHQUFHLFdBQVcsQ0FBQyxpQkFDdEIsT0FBTyxHQUFHLGFBQWEsQ0FBQyx5QkFDeEIsT0FBTyxHQUFHLGFBQWEsQ0FBQztBQUM3Qix1QkFBbUIsWUFBWSxHQUFHLFNBQVMsZ0JBQWdCO0FBQUEsRUFDN0QsT0FBTztBQUNMLHVCQUFtQixTQUFTO0FBQUEsRUFDOUI7QUFDRjtBQUVBLFNBQVMsYUFBYSxPQUE2QjtBQUNqRCxRQUFNLElBQUksTUFBTTtBQUNoQixRQUFNLFFBQVEsRUFBRTtBQUNoQixRQUFNLFVBQVUsRUFBRTtBQUNsQixpQkFBZSxTQUFTLFVBQVUsS0FBSyxDQUFDO0FBQ3hDLGVBQWEsY0FDWCxVQUFVLElBQ04sVUFDRSxvQkFDQSxhQUNGLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxVQUFVLGtCQUFlLEVBQUU7QUFDM0Qsa0JBQWdCLFNBQVM7QUFDekIsa0JBQWdCLFdBQVcsVUFBVTtBQUNyQyxtQkFBaUIsU0FBUyxDQUFDO0FBQzNCLHFCQUFtQixpQkFBaUIsQ0FBQztBQUN2QztBQUVBLGVBQWUsa0JBQWlDO0FBRzlDLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVTtBQUN6RCxRQUFNLFNBQVUsT0FBTyxZQUF1QyxDQUFDO0FBQy9ELGlCQUFlLE1BQU07QUFDdkI7QUFJQSxjQUFjLGlCQUFpQixTQUFTLFlBQVk7QUFDbEQsZ0JBQWMsV0FBVztBQUN6QixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFBQSxFQUNwQyxVQUFFO0FBQ0Esa0JBQWMsV0FBVztBQUFBLEVBQzNCO0FBQ0YsQ0FBQztBQUVELGVBQWUsaUJBQWlCLFNBQVMsWUFBWTtBQUNuRCxpQkFBZSxXQUFXO0FBQzFCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQUEsRUFDMUMsVUFBRTtBQUNBLG1CQUFlLFdBQVc7QUFBQSxFQUM1QjtBQUNGLENBQUM7QUFFRCxTQUFTLGlCQUFpQixTQUFTLFlBQVk7QUFDN0MsV0FBUyxXQUFXO0FBQ3BCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLFlBQVksQ0FBQztBQUFBLEVBQ2xDLFVBQUU7QUFDQSxhQUFTLFdBQVc7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxXQUFXLGlCQUFpQixVQUFVLE1BQU07QUFDMUMsT0FBSyxLQUFLLEVBQUUsTUFBTSx1QkFBdUIsSUFBSSxXQUFXLFFBQVEsQ0FBQztBQUNuRSxDQUFDO0FBRUQsYUFBYSxpQkFBaUIsVUFBVSxNQUFNO0FBQzVDLE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLElBQUksYUFBYSxRQUFRLENBQUM7QUFDaEUsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUNELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELG1CQUFpQixjQUFjLG1CQUFtQjtBQUNwRCxDQUFDO0FBQ0QsbUJBQW1CLGlCQUFpQixVQUFVLE1BQU07QUFDbEQsUUFBTSxVQUFVLE9BQU8sbUJBQW1CLEtBQUs7QUFDL0MsTUFBSSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzVCLFNBQUssS0FBSyxFQUFFLE1BQU0sNEJBQTRCLFFBQVEsQ0FBQztBQUFBLEVBQ3pEO0FBQ0YsQ0FBQztBQUVELFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2hELElBQUUsZUFBZTtBQUNqQixRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFHRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsT0FBSyxLQUFLLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUN2QyxDQUFDO0FBRUQsZ0JBQWdCLGlCQUFpQixTQUFTLE1BQU07QUFDOUMsa0JBQWdCLFdBQVc7QUFDM0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNqRCxvQkFBZ0IsV0FBVztBQUFBLEVBQzdCLENBQUM7QUFDSCxDQUFDO0FBRUQsaUJBQWlCLGlCQUFpQixTQUFTLE1BQU07QUFDL0MsbUJBQWlCLFdBQVc7QUFDNUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNsRCxxQkFBaUIsV0FBVztBQUFBLEVBQzlCLENBQUM7QUFDSCxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQscUJBQW1CLFdBQVc7QUFDOUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNyRCx1QkFBbUIsV0FBVztBQUFBLEVBQ2hDLENBQUM7QUFDSCxDQUFDO0FBRUQsb0JBQW9CLGlCQUFpQixTQUFTLE1BQU07QUFDbEQsc0JBQW9CLFdBQVc7QUFDL0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUN0RCx3QkFBb0IsV0FBVztBQUFBLEVBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRUQsWUFBWSxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3BDLENBQUM7QUFFRCxXQUFXLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNqRCxJQUFFLGVBQWU7QUFDakIsT0FBSyxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDbkMsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsWUFBWTtBQUNoRCxRQUFNLEtBQUssRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3JDLGlCQUFlLENBQUMsQ0FBQztBQUNuQixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLFFBQWlCO0FBQ3RELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVO0FBQ3JDLFFBQU0sSUFBSTtBQUNWLE1BQUksRUFBRSxTQUFTLG1CQUFtQixFQUFFLE9BQU87QUFDekMsZ0JBQVksRUFBRTtBQUNkLFVBQU0sRUFBRSxLQUFLO0FBQUEsRUFDZixXQUFXLEVBQUUsU0FBUyxlQUFlLEVBQUUsT0FBTztBQUM1QyxpQkFBYSxFQUFFLEtBQUs7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxTQUFTLGFBQWEsSUFBb0I7QUFFeEMsTUFBSSxhQUFhLG1CQUFtQixVQUFVLFNBQVMsT0FBTyxHQUFHO0FBQy9ELGlCQUFhLGdCQUFnQjtBQUFBLEVBQy9CO0FBQ0EsUUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLEtBQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixRQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsS0FBRyxZQUFZO0FBQ2YsS0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFFBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxPQUFLLFlBQVk7QUFDakIsT0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsUUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLE1BQUksWUFBWTtBQUNoQixNQUFJLGNBQWMsR0FBRztBQUNyQixPQUFLLE9BQU8sR0FBRztBQUNmLFFBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLE1BQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFNBQUssT0FBTyxHQUFHO0FBQUEsRUFDakI7QUFDQSxLQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsZUFBYSxRQUFRLEVBQUU7QUFDdkIsU0FBTyxhQUFhLG9CQUFvQixtQkFBbUI7QUFDekQsaUJBQWEsa0JBQWtCLE9BQU87QUFBQSxFQUN4QztBQUNGO0FBR0EsS0FBSyxhQUFhO0FBQ2xCLEtBQUssZ0JBQWdCO0FBR3JCLFlBQVksTUFBTTtBQUNoQixPQUFLLGFBQWE7QUFDcEIsR0FBRyxJQUFNOyIsCiAgIm5hbWVzIjogW10KfQo=
