// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var recentTweetList = $("recent-tweet-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var updateExistingToggle = $("update-existing");
var lowBandwidthToggle = $("low-bandwidth");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var threadOpenSection = $("thread-open-section");
var threadOpenCount = $("thread-open-count");
var threadOpenStartBtn = $("thread-open-start");
var threadOpenCancelBtn = $("thread-open-cancel");
var threadOpenProgress = $("thread-open-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = isWriteAuthError(connection.error) ? "PAT can read repo but cannot write - set Contents: Read & Write" : "Auth error - check your PAT";
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  updateExistingToggle.checked = state.settings.updateExisting !== false;
  lowBandwidthToggle.checked = state.settings.lowBandwidthBrowsing === true;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  renderRecentTweets(state.recentTweetSightings);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
  paintThreadOpen(state);
}
function renderRecentTweets(rows) {
  recentTweetList.replaceChildren();
  if (rows.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No tweets seen yet.";
    recentTweetList.append(li);
    return;
  }
  for (const row of rows.slice(0, 40)) {
    const li = document.createElement("li");
    li.className = `recent-tweet ${row.archive_status}`;
    const top = document.createElement("div");
    top.className = "tweet-head";
    const link = document.createElement("a");
    link.className = "tweet-handle";
    link.href = row.tweet_url;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = `@${row.account_handle}`;
    const status = document.createElement("span");
    status.className = `tweet-pill ${row.archive_status}`;
    status.textContent = row.archive_status === "saved" ? "saved" : "new";
    top.append(link, status);
    const text = document.createElement("div");
    text.className = "tweet-text";
    text.textContent = truncateText(row.text, 140);
    const meta = document.createElement("div");
    meta.className = "tweet-meta";
    meta.textContent = `${formatTweetAction(row.action)} \xB7 ${row.tweet_type} \xB7 posted ${fmtRel(row.posted_at)}`;
    li.append(top, text, meta);
    recentTweetList.append(li);
  }
}
function formatTweetAction(action) {
  if (action === "buffered") return "buffered";
  if (action === "unchanged") return "unchanged";
  return "skipped";
}
function truncateText(text, max) {
  const compact = text.replace(/\s+/g, " ").trim();
  return compact.length <= max ? compact : `${compact.slice(0, max - 1)}\u2026`;
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    const parts = [
      `${fmtNum(as.scrollCount)} scrolls`,
      `${fmtNum(as.ingestedNewCount)} new buffered`,
      `${fmtNum(as.ingestedExistingCount)} old buffered`
    ];
    if (as.skippedOldCount > 0) parts.push(`${fmtNum(as.skippedOldCount)} old skipped`);
    parts.push(`${fmtNum(as.expandedCount)} expanded`);
    autoScrollProgress.textContent = parts.join(" \xB7 ");
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
function paintThreadOpen(state) {
  const q = state.threadOpenQueue;
  const total = q.total;
  const running = q.running;
  threadOpenSection.hidden = total === 0 && !running;
  threadOpenCount.textContent = total === 0 ? running ? "finishing..." : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  threadOpenStartBtn.hidden = running;
  threadOpenStartBtn.disabled = total === 0;
  threadOpenCancelBtn.hidden = !running;
  paintQueueProgress(threadOpenProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
updateExistingToggle.addEventListener("change", () => {
  void send({ type: "toggle-update-existing", on: updateExistingToggle.checked });
});
lowBandwidthToggle.addEventListener("change", () => {
  void send({ type: "toggle-low-bandwidth", on: lowBandwidthToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl / thread-opening queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
threadOpenStartBtn.addEventListener("click", () => {
  threadOpenStartBtn.disabled = true;
  void send({ type: "start-thread-open" }).finally(() => {
    threadOpenStartBtn.disabled = false;
  });
});
threadOpenCancelBtn.addEventListener("click", () => {
  threadOpenCancelBtn.disabled = true;
  void send({ type: "cancel-thread-open" }).finally(() => {
    threadOpenCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBTZXR0aW5ncyA9IHtcclxuICBwYXQ6ICcnLFxyXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXHJcbiAgcmVwbzogJ3gnLFxyXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcclxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxyXG4gIGJyYW5jaDogJ21hc3RlcicsXHJcbiAgZW5hYmxlZDogdHJ1ZSxcclxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcclxuICBjb25maWd1cmVkQXQ6IG51bGwsXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcbiAgdXBkYXRlRXhpc3Rpbmc6IHRydWUsXG4gIGxvd0JhbmR3aWR0aEJyb3dzaW5nOiBmYWxzZSxcbn07XG5cclxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01JTl9TRUMgPSAzO1xyXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xyXG5cclxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcclxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxyXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcclxuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1JhcGlkUmVzcG9uc2U0NycsIGxhYmVsOiAnUmFwaWQgUmVzcG9uc2UgNDcnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdTdGVwaGVuTScsIGxhYmVsOiAnU3RlcGhlbiBNaWxsZXInLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdHcmVnb3J5S0JvdmlubycsIGxhYmVsOiAnR3JlZ29yeSBCb3Zpbm8nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdSZWFsVG9tSG9tYW4nLCBsYWJlbDogJ1Rob21hcyBELiBIb21hbicsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuXTtcclxuXHJcbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXHJcbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG4gICdMaWtlcycsXHJcbiAgJ0Jvb2ttYXJrcycsXHJcbiAgJ0hvbWVUaW1lbGluZScsXHJcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXHJcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcclxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcclxuXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XHJcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXHJcbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXHJcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxyXG5dKTtcclxuXHJcbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxyXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxyXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XHJcblxyXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3JcclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxyXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcclxuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXHJcbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXHJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcclxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxyXG4vL1xyXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcclxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXHJcbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cclxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnVXNlclR3ZWV0cycsXHJcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcclxuICAnVXNlck1lZGlhJyxcclxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxyXG4gICdUd2VldERldGFpbCcsXHJcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxyXG5dKTtcclxuXHJcbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxyXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xyXG5cclxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcclxuXHJcbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxyXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XHJcblxyXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXHJcbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcclxuXHJcbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cclxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XHJcblxyXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcclxuIiwgIi8qKlxyXG4gKiBzaWRlYmFyLnRzIFx1MjAxNCBVSSBmb3IgdGhlIHBlcnNpc3RlbnQgc2lkZWJhci5cclxuICpcclxuICogU2lkZWJhcnMgaW4gRmlyZWZveCBzdGF5IG9wZW4gYWNyb3NzIHRhYi93aW5kb3cgc3dpdGNoZXMsIHdoaWNoIGlzIHRoZVxyXG4gKiBpbnRlbmRlZCBwZXJzaXN0ZW5jZSBtb2RlbC4gVGhpcyBtb2R1bGUgcmVuZGVycyBzdGF0ZSBwdXNoZWQgZnJvbSB0aGVcclxuICogYmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciBhbmQgZm9yd2FyZHMgdXNlciBjb21tYW5kcyBiYWNrLlxyXG4gKi9cclxuXHJcbmltcG9ydCB7IEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcclxuaW1wb3J0IHR5cGUgeyBFeHRlbnNpb25TdGF0ZSwgTG9nRXZlbnQsIFJ1bnRpbWVNZXNzYWdlLCBUd2VldFNpZ2h0aW5nIH0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xyXG5cclxuY29uc3QgJCA9IDxUIGV4dGVuZHMgSFRNTEVsZW1lbnQgPSBIVE1MRWxlbWVudD4oaWQ6IHN0cmluZyk6IFQgPT4ge1xyXG4gIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xyXG4gIGlmICghZWwpIHRocm93IG5ldyBFcnJvcihgbWlzc2luZyBlbGVtZW50ICMke2lkfWApO1xyXG4gIHJldHVybiBlbCBhcyBUO1xyXG59O1xyXG5cclxuY29uc3QgY29ubkRvdCA9ICQoJ2Nvbm4tZG90Jyk7XHJcbmNvbnN0IGNvbm5UZXh0ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdjb25uLXRleHQnKTtcclxuY29uc3QgYWNjb3VudExpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdhY2NvdW50LWxpc3QnKTtcclxuY29uc3QgcmVjZW50VHdlZXRMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PigncmVjZW50LXR3ZWV0LWxpc3QnKTtcclxuY29uc3QgYWN0aXZpdHlMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWN0aXZpdHktbGlzdCcpO1xuY29uc3QgYXV0b1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tY2FwdHVyZScpO1xuY29uc3QgdXBkYXRlRXhpc3RpbmdUb2dnbGUgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCd1cGRhdGUtZXhpc3RpbmcnKTtcbmNvbnN0IGxvd0JhbmR3aWR0aFRvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2xvdy1iYW5kd2lkdGgnKTtcbmNvbnN0IGNhcHR1cmVBbGxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2FwdHVyZS1hbGwnKTtcbmNvbnN0IGNhcHR1cmVUaGlzQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtdGhpcycpO1xyXG5jb25zdCBmbHVzaEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdmbHVzaC1hbGwnKTtcclxuY29uc3Qgb3B0aW9uc0xpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi1vcHRpb25zJyk7XHJcbmNvbnN0IHZpZXdlckxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi12aWV3ZXInKTtcclxuY29uc3QgY2xlYXJBY3RCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2xlYXItYWN0aXZpdHknKTtcclxuY29uc3QgZXh0VmVyc2lvbkVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdleHQtdmVyc2lvbicpO1xyXG5jb25zdCBtYXN0ZXJTd2l0Y2ggPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdtYXN0ZXItc3dpdGNoJyk7XHJcbmNvbnN0IG1hc3RlckxhYmVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtYXN0ZXItbGFiZWwnKTtcclxuY29uc3QgYXV0b1Njcm9sbEludGVydmFsID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1zY3JvbGwtaW50ZXJ2YWwnKTtcclxuY29uc3QgYXV0b1Njcm9sbFNlY3NFbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc2VjcycpO1xyXG5jb25zdCBhdXRvU2Nyb2xsU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zdGF0dXMnKTtcclxuY29uc3QgYXV0b1Njcm9sbFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXN0YXJ0Jyk7XHJcbmNvbnN0IGF1dG9TY3JvbGxDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtY2FuY2VsJyk7XHJcbmNvbnN0IGF1dG9TY3JvbGxQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtcHJvZ3Jlc3MnKTtcclxuY29uc3QgcmVmZXRjaFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PigncmVmZXRjaC1zZWN0aW9uJyk7XHJcbmNvbnN0IHJlZmV0Y2hDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1jb3VudCcpO1xyXG5jb25zdCByZWZldGNoU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1zdGFydCcpO1xyXG5jb25zdCByZWZldGNoQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZmV0Y2gtY2FuY2VsJyk7XHJcbmNvbnN0IHJlZmV0Y2hQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1wcm9ncmVzcycpO1xyXG5jb25zdCBtZWRpYUNyYXdsU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1zZWN0aW9uJyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtY291bnQnKTtcclxuY29uc3QgbWVkaWFDcmF3bFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLXN0YXJ0Jyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignbWVkaWEtY3Jhd2wtY2FuY2VsJyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtcHJvZ3Jlc3MnKTtcclxuY29uc3QgdGhyZWFkT3BlblNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PigndGhyZWFkLW9wZW4tc2VjdGlvbicpO1xyXG5jb25zdCB0aHJlYWRPcGVuQ291bnQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3RocmVhZC1vcGVuLWNvdW50Jyk7XHJcbmNvbnN0IHRocmVhZE9wZW5TdGFydEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCd0aHJlYWQtb3Blbi1zdGFydCcpO1xyXG5jb25zdCB0aHJlYWRPcGVuQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3RocmVhZC1vcGVuLWNhbmNlbCcpO1xyXG5jb25zdCB0aHJlYWRPcGVuUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3RocmVhZC1vcGVuLXByb2dyZXNzJyk7XHJcbmNvbnN0IHB1cmdlTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdwdXJnZS11bnJlbGF0ZWQnKTtcclxuXHJcbmxldCBsYXN0U3RhdGU6IEV4dGVuc2lvblN0YXRlIHwgbnVsbCA9IG51bGw7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzZW5kPFQ+KG1zZzogUnVudGltZU1lc3NhZ2UpOiBQcm9taXNlPFQ+IHtcclxuICByZXR1cm4gYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKG1zZykgYXMgUHJvbWlzZTxUPjtcclxufVxyXG5cclxuZnVuY3Rpb24gc2V0Q29ublN0YXR1cyhzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBjb25zdCB7IGNvbm5lY3Rpb24sIHNldHRpbmdzIH0gPSBzdGF0ZTtcclxuICBsZXQgY2xzID0gJyc7XHJcbiAgbGV0IHRleHQgPSAnJztcclxuICAvLyBPbmx5IHdhcm4gd2hlbiB0aGUgY29uZmlndXJlZCBicmFuY2ggZ2VudWluZWx5IGRvZXNuJ3QgZXhpc3Qgb24gdGhlXHJcbiAgLy8gcmVtb3RlLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCB0aGF0IGV4aXN0cyBpcyBmaW5lIFx1MjAxNCBjYXB0dXJpbmcgaW50byBhXHJcbiAgLy8gd29ya2luZyBicmFuY2ggaXMgcm91dGluZSBcdTIwMTQgc28gdGhlIG1lcmUgYCE9PWAgdG8gZGVmYXVsdF9icmFuY2ggaXMgbm90XHJcbiAgLy8gYSBwcm9ibGVtIGFuZCBzaG91bGRuJ3Qgc2hvdXQgaW4gdGhlIGhlYWRlci5cclxuICBjb25zdCBicmFuY2hNaXNzaW5nID1cclxuICAgIGNvbm5lY3Rpb24uc3RhdHVzID09PSAnb2snICYmIHNldHRpbmdzLmJyYW5jaCAmJiBjb25uZWN0aW9uLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IGZhbHNlO1xyXG4gIGlmICghc2V0dGluZ3MucGF0U2V0KSB7XHJcbiAgICBjbHMgPSAnd2Fybic7XHJcbiAgICB0ZXh0ID0gJ05vdCBjb25maWd1cmVkIFx1MjAxNCBvcGVuIFNldHRpbmdzJztcclxuICB9IGVsc2UgaWYgKGJyYW5jaE1pc3NpbmcpIHtcclxuICAgIGNscyA9ICdlcnInO1xyXG4gICAgdGV4dCA9IGBCcmFuY2ggXCIke3NldHRpbmdzLmJyYW5jaH1cIiBkb2VzIG5vdCBleGlzdCBvbiAke3NldHRpbmdzLm93bmVyfS8ke3NldHRpbmdzLnJlcG99IFx1MjAxNCBjb21taXRzIHdpbGwgNDIyLiBTZXQgYnJhbmNoIHRvIFwiJHtjb25uZWN0aW9uLmRlZmF1bHRCcmFuY2ggPz8gJ21hc3Rlcid9XCIgaW4gU2V0dGluZ3MuYDtcclxuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnb2snKSB7XHJcbiAgICBjbHMgPSAnb2snO1xyXG4gICAgdGV4dCA9IGBDb25uZWN0ZWQgYXMgQCR7Y29ubmVjdGlvbi5sb2dpbiA/PyAnPyd9IHRvICR7c2V0dGluZ3Mub3duZXJ9LyR7c2V0dGluZ3MucmVwb30gXHUwMEI3IFx1MjAyNiR7c2V0dGluZ3MucGF0U3VmZml4fWA7XHJcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ2F1dGgtZXJyb3InKSB7XHJcbiAgICBjbHMgPSAnZXJyJztcclxuICAgIHRleHQgPSBpc1dyaXRlQXV0aEVycm9yKGNvbm5lY3Rpb24uZXJyb3IpXHJcbiAgICAgID8gJ1BBVCBjYW4gcmVhZCByZXBvIGJ1dCBjYW5ub3Qgd3JpdGUgLSBzZXQgQ29udGVudHM6IFJlYWQgJiBXcml0ZSdcclxuICAgICAgOiAnQXV0aCBlcnJvciAtIGNoZWNrIHlvdXIgUEFUJztcclxuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJykge1xyXG4gICAgY2xzID0gJ3dhcm4nO1xyXG4gICAgY29uc3QgcmVzZXRzID0gZm10UmF0ZUxpbWl0UmVzZXQoY29ubmVjdGlvbi5yYXRlTGltaXRSZXNldEF0KTtcclxuICAgIHRleHQgPSByZXNldHNcclxuICAgICAgPyBgR2l0SHViIHJhdGUtbGltaXRlZCBcdTIwMTQgcmVzZXRzICR7cmVzZXRzfWBcclxuICAgICAgOiAnR2l0SHViIHJhdGUtbGltaXRlZCBcdTIwMTQgY2FwdHVyZXMgd2lsbCByZXRyeSc7XHJcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ25ldHdvcmstZXJyb3InKSB7XHJcbiAgICBjbHMgPSAnZXJyJztcclxuICAgIHRleHQgPSAnTmV0d29yayBlcnJvciBcdTIwMTQgY2hlY2sgY29ubmVjdGl2aXR5JztcclxuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnbm90LWNvbmZpZ3VyZWQnKSB7XHJcbiAgICBjbHMgPSAnd2Fybic7XHJcbiAgICB0ZXh0ID0gJ05vdCBjb25maWd1cmVkIFx1MjAxNCBvcGVuIFNldHRpbmdzJztcclxuICB9IGVsc2Uge1xyXG4gICAgY2xzID0gJyc7XHJcbiAgICB0ZXh0ID0gJ0NoZWNraW5nXHUyMDI2JztcclxuICB9XHJcbiAgY29ubkRvdC5jbGFzc05hbWUgPSBgZG90ICR7Y2xzfWA7XHJcbiAgY29ublRleHQudGV4dENvbnRlbnQgPSB0ZXh0O1xyXG4gIGNvbm5UZXh0LnRpdGxlID0gY29ubmVjdGlvbi5lcnJvciA/PyAnJztcclxufVxyXG5cclxuZnVuY3Rpb24gZm10UmVsKGlzbzogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB7XHJcbiAgaWYgKCFpc28pIHJldHVybiAnXHUyMDE0JztcclxuICBjb25zdCBkID0gRGF0ZS5wYXJzZShpc28pO1xyXG4gIGlmICghTnVtYmVyLmlzRmluaXRlKGQpKSByZXR1cm4gJ1x1MjAxNCc7XHJcbiAgY29uc3Qgc2VjcyA9IE1hdGgubWF4KDAsIE1hdGgucm91bmQoKERhdGUubm93KCkgLSBkKSAvIDEwMDApKTtcclxuICBpZiAoc2VjcyA8IDUpIHJldHVybiAnanVzdCBub3cnO1xyXG4gIGlmIChzZWNzIDwgNjApIHJldHVybiBgJHtzZWNzfXMgYWdvYDtcclxuICBjb25zdCBtaW5zID0gTWF0aC5yb3VuZChzZWNzIC8gNjApO1xyXG4gIGlmIChtaW5zIDwgNjApIHJldHVybiBgJHttaW5zfW0gYWdvYDtcclxuICBjb25zdCBob3VycyA9IE1hdGgucm91bmQobWlucyAvIDYwKTtcclxuICBpZiAoaG91cnMgPCAyNCkgcmV0dXJuIGAke2hvdXJzfWggYWdvYDtcclxuICBjb25zdCBkYXlzID0gTWF0aC5yb3VuZChob3VycyAvIDI0KTtcclxuICByZXR1cm4gYCR7ZGF5c31kIGFnb2A7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZtdFJhdGVMaW1pdFJlc2V0KGVwb2NoU2VjOiBudW1iZXIgfCBudWxsKTogc3RyaW5nIHtcclxuICBpZiAoZXBvY2hTZWMgPT09IG51bGwpIHJldHVybiAnJztcclxuICBjb25zdCBkZWx0YVNlYyA9IGVwb2NoU2VjIC0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XHJcbiAgaWYgKGRlbHRhU2VjIDw9IDApIHJldHVybiAnbW9tZW50YXJpbHknO1xyXG4gIGNvbnN0IHdhbGxDbG9jayA9IG5ldyBEYXRlKGVwb2NoU2VjICogMTAwMCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7XHJcbiAgICBob3VyOiAnMi1kaWdpdCcsXHJcbiAgICBtaW51dGU6ICcyLWRpZ2l0JyxcclxuICB9KTtcclxuICBpZiAoZGVsdGFTZWMgPCA2MCkgcmV0dXJuIGBpbiAke2RlbHRhU2VjfXMgKCR7d2FsbENsb2NrfSlgO1xyXG4gIGNvbnN0IG1pbnMgPSBNYXRoLnJvdW5kKGRlbHRhU2VjIC8gNjApO1xyXG4gIGlmIChtaW5zIDwgNjApIHJldHVybiBgaW4gJHttaW5zfW0gKCR7d2FsbENsb2NrfSlgO1xyXG4gIGNvbnN0IGhvdXJzID0gTWF0aC5yb3VuZChtaW5zIC8gNjApO1xyXG4gIHJldHVybiBgaW4gJHtob3Vyc31oICgke3dhbGxDbG9ja30pYDtcclxufVxyXG5cclxuZnVuY3Rpb24gZm10TnVtKG46IG51bWJlcik6IHN0cmluZyB7XHJcbiAgcmV0dXJuIG4udG9Mb2NhbGVTdHJpbmcoJ2VuLVVTJyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGlzV3JpdGVBdXRoRXJyb3IobWVzc2FnZTogc3RyaW5nIHwgbnVsbCk6IGJvb2xlYW4ge1xyXG4gIHJldHVybiAoXHJcbiAgICB0eXBlb2YgbWVzc2FnZSA9PT0gJ3N0cmluZycgJiZcclxuICAgIC9SZXNvdXJjZSBub3QgYWNjZXNzaWJsZSBieSBwZXJzb25hbCBhY2Nlc3MgdG9rZW58XFwvZ2l0XFwvYmxvYnN8XFwvZ2l0XFwvcmVmcy9pLnRlc3QobWVzc2FnZSlcclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiByZW5kZXJBY2NvdW50cyhzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBhY2NvdW50TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcclxuICBpZiAoc3RhdGUuYWNjb3VudHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xyXG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWNjb3VudHMgY29uZmlndXJlZC4nO1xyXG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgZm9yIChjb25zdCBhIG9mIHN0YXRlLmFjY291bnRzKSB7XHJcbiAgICBjb25zdCBjID0gc3RhdGUuY291bnRlcnNbYS5oYW5kbGVdO1xyXG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xyXG4gICAgbGkuY2xhc3NOYW1lID0gYyAmJiBjLmJ1ZmZlcmVkQ291bnQgPiAwID8gJ2FjYyBwZW5kaW5nJyA6ICdhY2MnO1xyXG5cclxuICAgIGNvbnN0IGhlYWQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIGhlYWQuY2xhc3NOYW1lID0gJ2FjYy1oZWFkJztcclxuICAgIGNvbnN0IGhhbmRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIGhhbmRsZS5jbGFzc05hbWUgPSAnYWNjLWhhbmRsZSc7XHJcbiAgICBoYW5kbGUuaW5uZXJIVE1MID0gYDxzcGFuIGNsYXNzPVwiYXRcIj5APC9zcGFuPiR7ZXNjYXBlSHRtbChhLmhhbmRsZSl9YDtcclxuICAgIGNvbnN0IG1ldGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBtZXRhLmNsYXNzTmFtZSA9ICdhY2MtbWV0YSc7XHJcbiAgICBtZXRhLnRleHRDb250ZW50ID0gYS5sYWJlbDtcclxuICAgIGhlYWQuYXBwZW5kKGhhbmRsZSwgbWV0YSk7XHJcblxyXG4gICAgY29uc3Qgcm93ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICByb3cuY2xhc3NOYW1lID0gJ2FjYy1yb3cnO1xyXG4gICAgY29uc3Qgc3RhdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBzdGF0cy5jbGFzc05hbWUgPSAnYWNjLXN0YXRzJztcclxuICAgIGNvbnN0IHRvZGF5ID0gYz8udG9kYXlDb3VudCA/PyAwO1xyXG4gICAgY29uc3QgYnVmZmVyZWQgPSBjPy5idWZmZXJlZENvdW50ID8/IDA7XHJcbiAgICBjb25zdCBsYXN0ID0gYz8ubGFzdENhcHR1cmVBdCA/PyBudWxsO1xyXG4gICAgc3RhdHMuaW5uZXJIVE1MID1cclxuICAgICAgYDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0odG9kYXkpfTwvc3Bhbj4gdG9kYXlgICtcclxuICAgICAgKGJ1ZmZlcmVkID4gMCA/IGAgXHUwMEI3IDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0oYnVmZmVyZWQpfTwvc3Bhbj4gYnVmZmVyZWRgIDogJycpICtcclxuICAgICAgYCBcdTAwQjcgbGFzdCAke2VzY2FwZUh0bWwoZm10UmVsKGxhc3QpKX1gO1xyXG5cclxuICAgIGNvbnN0IGFjdGlvbnMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBhY3Rpb25zLmNsYXNzTmFtZSA9ICdhY2MtYWN0aW9uJztcclxuICAgIGNvbnN0IGJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xyXG4gICAgYnRuLmNsYXNzTmFtZSA9ICdidG4nO1xyXG4gICAgYnRuLnRleHRDb250ZW50ID0gJ0NhcHR1cmUgbm93JztcclxuICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICAgICAgYnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtbm93JywgaGFuZGxlOiBhLmhhbmRsZSB9KTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBidG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICBhY3Rpb25zLmFwcGVuZChidG4pO1xyXG5cclxuICAgIHJvdy5hcHBlbmQoc3RhdHMsIGFjdGlvbnMpO1xyXG4gICAgbGkuYXBwZW5kKGhlYWQsIHJvdyk7XHJcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcmVuZGVyQWN0aXZpdHkoZXZlbnRzOiBMb2dFdmVudFtdKTogdm9pZCB7XHJcbiAgYWN0aXZpdHlMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xyXG4gIGlmIChldmVudHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xyXG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWN0aXZpdHkgeWV0Lic7XHJcbiAgICBhY3Rpdml0eUxpc3QuYXBwZW5kKGxpKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgZm9yIChjb25zdCBldiBvZiBldmVudHMuc2xpY2UoMCwgQUNUSVZJVFlfVEFJTF9NQVgpKSB7XHJcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xyXG4gICAgY29uc3QgdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICB0cy5jbGFzc05hbWUgPSAnZXYtdHMnO1xyXG4gICAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcclxuICAgIGNvbnN0IGljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBpY29uLmNsYXNzTmFtZSA9ICdldi1pY29uJztcclxuICAgIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xyXG4gICAgY29uc3QgYm9keSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIGNvbnN0IG1zZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xyXG4gICAgbXNnLnRleHRDb250ZW50ID0gZXYubXNnO1xyXG4gICAgYm9keS5hcHBlbmQobXNnKTtcclxuICAgIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcclxuICAgIGlmIChjdHhLZXlzLmxlbmd0aCA+IDApIHtcclxuICAgICAgY29uc3QgY3R4ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcclxuICAgICAgY3R4LnRleHRDb250ZW50ID0gY3R4S2V5cy5tYXAoKGspID0+IGAke2t9PSR7c3RyaW5naWZ5U2hvcnQoZXYuY29udGV4dFtrXSl9YCkuam9pbignIFx1MDBCNyAnKTtcclxuICAgICAgYm9keS5hcHBlbmQoY3R4KTtcclxuICAgIH1cclxuICAgIGxpLmFwcGVuZCh0cywgaWNvbiwgYm9keSk7XHJcbiAgICBhY3Rpdml0eUxpc3QuYXBwZW5kKGxpKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHN0cmluZ2lmeVNob3J0KHY6IHVua25vd24pOiBzdHJpbmcge1xyXG4gIGlmICh2ID09PSBudWxsKSByZXR1cm4gJ251bGwnO1xyXG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycpIHJldHVybiB2Lmxlbmd0aCA+IDgwID8gYCR7di5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHY7XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gU3RyaW5nKHYpO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzID0gSlNPTi5zdHJpbmdpZnkodik7XHJcbiAgICByZXR1cm4gcy5sZW5ndGggPiA4MCA/IGAke3Muc2xpY2UoMCwgODApfVx1MjAyNmAgOiBzO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuICc/JztcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGVzY2FwZUh0bWwoczogc3RyaW5nKTogc3RyaW5nIHtcclxuICByZXR1cm4gcy5yZXBsYWNlKC9bJjw+XCInXS9nLCAoYykgPT5cclxuICAgIGMgPT09ICcmJyA/ICcmYW1wOycgOiBjID09PSAnPCcgPyAnJmx0OycgOiBjID09PSAnPicgPyAnJmd0OycgOiBjID09PSAnXCInID8gJyZxdW90OycgOiAnJiMzOTsnXHJcbiAgKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaFN0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHRyeSB7XHJcbiAgICBsYXN0U3RhdGUgPSBhd2FpdCBzZW5kPEV4dGVuc2lvblN0YXRlPih7IHR5cGU6ICdnZXQtc3RhdGUnIH0pO1xyXG4gICAgcGFpbnQobGFzdFN0YXRlKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBzaWRlYmFyIHJlZnJlc2hTdGF0ZSBmYWlsZWQnLCBlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcGFpbnQoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgZXh0VmVyc2lvbkVsLnRleHRDb250ZW50ID0gc3RhdGUudmVyc2lvbjtcclxuICBzZXRDb25uU3RhdHVzKHN0YXRlKTtcbiAgYXV0b1RvZ2dsZS5jaGVja2VkID0gc3RhdGUuc2V0dGluZ3MuYXV0b0NhcHR1cmU7XG4gIHVwZGF0ZUV4aXN0aW5nVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy51cGRhdGVFeGlzdGluZyAhPT0gZmFsc2U7XG4gIGxvd0JhbmR3aWR0aFRvZ2dsZS5jaGVja2VkID0gc3RhdGUuc2V0dGluZ3MubG93QmFuZHdpZHRoQnJvd3NpbmcgPT09IHRydWU7XG4gIHZpZXdlckxpbmsuaHJlZiA9IGBodHRwczovLyR7c3RhdGUuc2V0dGluZ3Mub3duZXJ9LmdpdGh1Yi5pby8ke3N0YXRlLnNldHRpbmdzLnJlcG99L2A7XG4gIHBhaW50TWFzdGVyU3dpdGNoKHN0YXRlKTtcclxuICByZW5kZXJBY2NvdW50cyhzdGF0ZSk7XHJcbiAgcmVuZGVyUmVjZW50VHdlZXRzKHN0YXRlLnJlY2VudFR3ZWV0U2lnaHRpbmdzKTtcclxuICBwYWludEF1dG9TY3JvbGwoc3RhdGUpO1xyXG4gIHBhaW50TWVkaWFDcmF3bChzdGF0ZSk7XHJcbiAgcGFpbnRSZWZldGNoKHN0YXRlKTtcclxuICBwYWludFRocmVhZE9wZW4oc3RhdGUpO1xyXG59XHJcblxyXG5mdW5jdGlvbiByZW5kZXJSZWNlbnRUd2VldHMocm93czogVHdlZXRTaWdodGluZ1tdKTogdm9pZCB7XHJcbiAgcmVjZW50VHdlZXRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xyXG4gIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xyXG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcclxuICAgIGxpLnRleHRDb250ZW50ID0gJ05vIHR3ZWV0cyBzZWVuIHlldC4nO1xyXG4gICAgcmVjZW50VHdlZXRMaXN0LmFwcGVuZChsaSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGZvciAoY29uc3Qgcm93IG9mIHJvd3Muc2xpY2UoMCwgNDApKSB7XHJcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgICBsaS5jbGFzc05hbWUgPSBgcmVjZW50LXR3ZWV0ICR7cm93LmFyY2hpdmVfc3RhdHVzfWA7XHJcblxyXG4gICAgY29uc3QgdG9wID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICB0b3AuY2xhc3NOYW1lID0gJ3R3ZWV0LWhlYWQnO1xyXG4gICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcclxuICAgIGxpbmsuY2xhc3NOYW1lID0gJ3R3ZWV0LWhhbmRsZSc7XHJcbiAgICBsaW5rLmhyZWYgPSByb3cudHdlZXRfdXJsO1xyXG4gICAgbGluay50YXJnZXQgPSAnX2JsYW5rJztcclxuICAgIGxpbmsucmVsID0gJ25vb3BlbmVyJztcclxuICAgIGxpbmsudGV4dENvbnRlbnQgPSBgQCR7cm93LmFjY291bnRfaGFuZGxlfWA7XHJcbiAgICBjb25zdCBzdGF0dXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBzdGF0dXMuY2xhc3NOYW1lID0gYHR3ZWV0LXBpbGwgJHtyb3cuYXJjaGl2ZV9zdGF0dXN9YDtcclxuICAgIHN0YXR1cy50ZXh0Q29udGVudCA9IHJvdy5hcmNoaXZlX3N0YXR1cyA9PT0gJ3NhdmVkJyA/ICdzYXZlZCcgOiAnbmV3JztcclxuICAgIHRvcC5hcHBlbmQobGluaywgc3RhdHVzKTtcclxuXHJcbiAgICBjb25zdCB0ZXh0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICB0ZXh0LmNsYXNzTmFtZSA9ICd0d2VldC10ZXh0JztcclxuICAgIHRleHQudGV4dENvbnRlbnQgPSB0cnVuY2F0ZVRleHQocm93LnRleHQsIDE0MCk7XHJcblxyXG4gICAgY29uc3QgbWV0YSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgbWV0YS5jbGFzc05hbWUgPSAndHdlZXQtbWV0YSc7XHJcbiAgICBtZXRhLnRleHRDb250ZW50ID0gYCR7Zm9ybWF0VHdlZXRBY3Rpb24ocm93LmFjdGlvbil9IFx1MDBCNyAke3Jvdy50d2VldF90eXBlfSBcdTAwQjcgcG9zdGVkICR7Zm10UmVsKHJvdy5wb3N0ZWRfYXQpfWA7XHJcblxyXG4gICAgbGkuYXBwZW5kKHRvcCwgdGV4dCwgbWV0YSk7XHJcbiAgICByZWNlbnRUd2VldExpc3QuYXBwZW5kKGxpKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdFR3ZWV0QWN0aW9uKGFjdGlvbjogVHdlZXRTaWdodGluZ1snYWN0aW9uJ10pOiBzdHJpbmcge1xyXG4gIGlmIChhY3Rpb24gPT09ICdidWZmZXJlZCcpIHJldHVybiAnYnVmZmVyZWQnO1xyXG4gIGlmIChhY3Rpb24gPT09ICd1bmNoYW5nZWQnKSByZXR1cm4gJ3VuY2hhbmdlZCc7XHJcbiAgcmV0dXJuICdza2lwcGVkJztcclxufVxyXG5cclxuZnVuY3Rpb24gdHJ1bmNhdGVUZXh0KHRleHQ6IHN0cmluZywgbWF4OiBudW1iZXIpOiBzdHJpbmcge1xyXG4gIGNvbnN0IGNvbXBhY3QgPSB0ZXh0LnJlcGxhY2UoL1xccysvZywgJyAnKS50cmltKCk7XHJcbiAgcmV0dXJuIGNvbXBhY3QubGVuZ3RoIDw9IG1heCA/IGNvbXBhY3QgOiBgJHtjb21wYWN0LnNsaWNlKDAsIG1heCAtIDEpfVx1MjAyNmA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhaW50TWVkaWFDcmF3bChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBjb25zdCBxID0gc3RhdGUubWVkaWFDcmF3bFF1ZXVlO1xyXG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcclxuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xyXG4gIG1lZGlhQ3Jhd2xTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xyXG4gIG1lZGlhQ3Jhd2xDb3VudC50ZXh0Q29udGVudCA9XHJcbiAgICB0b3RhbCA9PT0gMFxyXG4gICAgICA/IHJ1bm5pbmdcclxuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXHJcbiAgICAgICAgOiAnMCBxdWV1ZWQnXHJcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xyXG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xyXG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xyXG4gIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XHJcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKG1lZGlhQ3Jhd2xQcm9ncmVzcywgcSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhaW50UXVldWVQcm9ncmVzcyhcclxuICBlbDogSFRNTFNwYW5FbGVtZW50LFxyXG4gIHE6IHsgcHJvY2Vzc2VkOiBudW1iZXI7IHRvdGFsX2F0X3N0YXJ0OiBudW1iZXI7IHJ1bm5pbmc6IGJvb2xlYW47IHRvdGFsOiBudW1iZXIgfVxyXG4pOiB2b2lkIHtcclxuICBpZiAoIXEucnVubmluZyAmJiBxLnByb2Nlc3NlZCA9PT0gMCkge1xyXG4gICAgZWwuaGlkZGVuID0gdHJ1ZTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgLy8gRGVub21pbmF0b3I6IG1heCBvZiBpbml0aWFsIHRvdGFsIGFuZCBjdXJyZW50IHByb2Nlc3NlZCtyZW1haW5pbmcgc28gdGhlXHJcbiAgLy8gYmFyIHN0aWxsIG1ha2VzIHNlbnNlIGlmIG5ldyBlbnRyaWVzIHdlcmUgZW5xdWV1ZWQgbWlkLXJ1bi5cclxuICBjb25zdCBkZW5vbSA9IE1hdGgubWF4KHEudG90YWxfYXRfc3RhcnQsIHEucHJvY2Vzc2VkICsgcS50b3RhbCk7XHJcbiAgZWwuaGlkZGVuID0gZmFsc2U7XHJcbiAgZWwudGV4dENvbnRlbnQgPSBgJHtmbXROdW0ocS5wcm9jZXNzZWQpfSAvICR7Zm10TnVtKGRlbm9tKX0gcHJvY2Vzc2VkYDtcclxuICBlbC5jbGFzc05hbWUgPSBxLnJ1bm5pbmcgPyAncHJvZ3Jlc3Mgb24nIDogJ3Byb2dyZXNzJztcclxufVxyXG5cclxuZnVuY3Rpb24gcGFpbnRNYXN0ZXJTd2l0Y2goc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgY29uc3Qgb24gPSBzdGF0ZS5zZXR0aW5ncy5lbmFibGVkICE9PSBmYWxzZTtcclxuICBtYXN0ZXJTd2l0Y2guY2hlY2tlZCA9IG9uO1xyXG4gIG1hc3RlckxhYmVsLnRleHRDb250ZW50ID0gb24gPyAnT04nIDogJ1BBVVNFRCc7XHJcbiAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKCdwYXVzZWQnLCAhb24pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYWludEF1dG9TY3JvbGwoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgY29uc3Qgc2VjcyA9IHN0YXRlLnNldHRpbmdzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYztcclxuICBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWUgPSBTdHJpbmcoc2Vjcyk7XHJcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IFN0cmluZyhzZWNzKTtcclxuICBjb25zdCBhcyA9IHN0YXRlLmF1dG9TY3JvbGw7XHJcbiAgYXV0b1Njcm9sbFN0YXJ0QnRuLmhpZGRlbiA9IGFzLmFjdGl2ZTtcclxuICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmhpZGRlbiA9ICFhcy5hY3RpdmU7XHJcbiAgaWYgKGFzLmFjdGl2ZSkge1xyXG4gICAgY29uc3QgbiA9IGFzLnRhYkNvdW50O1xyXG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9XHJcbiAgICAgIG4gPT09IDAgPyBgcnVubmluZyBcdTIwMTQgbm8gWCB0YWJzIG9wZW5gIDogYHJ1bm5pbmcgXHUyMDE0ICR7bn0gJHtuID09PSAxID8gJ3RhYicgOiAndGFicyd9YDtcclxuICAgIGF1dG9TY3JvbGxTdGF0dXMuY2xhc3NOYW1lID0gJ211dGVkIG9uJztcclxuICB9IGVsc2Uge1xyXG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9ICdpZGxlJztcclxuICAgIGF1dG9TY3JvbGxTdGF0dXMuY2xhc3NOYW1lID0gJ211dGVkJztcclxuICB9XHJcbiAgaWYgKGFzLmFjdGl2ZSB8fCBhcy5zY3JvbGxDb3VudCA+IDAgfHwgYXMuaW5nZXN0ZWRDb3VudCA+IDApIHtcclxuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy5oaWRkZW4gPSBmYWxzZTtcclxuICAgIGNvbnN0IHBhcnRzID0gW1xyXG4gICAgICBgJHtmbXROdW0oYXMuc2Nyb2xsQ291bnQpfSBzY3JvbGxzYCxcclxuICAgICAgYCR7Zm10TnVtKGFzLmluZ2VzdGVkTmV3Q291bnQpfSBuZXcgYnVmZmVyZWRgLFxyXG4gICAgICBgJHtmbXROdW0oYXMuaW5nZXN0ZWRFeGlzdGluZ0NvdW50KX0gb2xkIGJ1ZmZlcmVkYCxcclxuICAgIF07XHJcbiAgICBpZiAoYXMuc2tpcHBlZE9sZENvdW50ID4gMCkgcGFydHMucHVzaChgJHtmbXROdW0oYXMuc2tpcHBlZE9sZENvdW50KX0gb2xkIHNraXBwZWRgKTtcclxuICAgIHBhcnRzLnB1c2goYCR7Zm10TnVtKGFzLmV4cGFuZGVkQ291bnQpfSBleHBhbmRlZGApO1xyXG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLnRleHRDb250ZW50ID0gcGFydHMuam9pbignIFx1MDBCNyAnKTtcclxuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy5jbGFzc05hbWUgPSBhcy5hY3RpdmUgPyAncHJvZ3Jlc3Mgb24nIDogJ3Byb2dyZXNzJztcclxuICB9IGVsc2Uge1xyXG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmhpZGRlbiA9IHRydWU7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBwYWludFJlZmV0Y2goc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgY29uc3QgcSA9IHN0YXRlLnJlZmV0Y2hRdWV1ZTtcclxuICBjb25zdCB0b3RhbCA9IHEudG90YWw7XHJcbiAgY29uc3QgcnVubmluZyA9IHEucnVubmluZztcclxuICByZWZldGNoU2VjdGlvbi5oaWRkZW4gPSB0b3RhbCA9PT0gMCAmJiAhcnVubmluZztcclxuICByZWZldGNoQ291bnQudGV4dENvbnRlbnQgPVxyXG4gICAgdG90YWwgPT09IDBcclxuICAgICAgPyBydW5uaW5nXHJcbiAgICAgICAgPyAnZmluaXNoaW5nXHUyMDI2J1xyXG4gICAgICAgIDogJzAgcXVldWVkJ1xyXG4gICAgICA6IGAke2ZtdE51bSh0b3RhbCl9IHF1ZXVlZCR7cnVubmluZyA/ICcgXHUwMEI3IHJ1bm5pbmcnIDogJyd9YDtcclxuICByZWZldGNoU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcclxuICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcclxuICByZWZldGNoQ2FuY2VsQnRuLmhpZGRlbiA9ICFydW5uaW5nO1xyXG4gIHBhaW50UXVldWVQcm9ncmVzcyhyZWZldGNoUHJvZ3Jlc3MsIHEpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYWludFRocmVhZE9wZW4oc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgY29uc3QgcSA9IHN0YXRlLnRocmVhZE9wZW5RdWV1ZTtcclxuICBjb25zdCB0b3RhbCA9IHEudG90YWw7XHJcbiAgY29uc3QgcnVubmluZyA9IHEucnVubmluZztcclxuICB0aHJlYWRPcGVuU2VjdGlvbi5oaWRkZW4gPSB0b3RhbCA9PT0gMCAmJiAhcnVubmluZztcclxuICB0aHJlYWRPcGVuQ291bnQudGV4dENvbnRlbnQgPVxyXG4gICAgdG90YWwgPT09IDBcclxuICAgICAgPyBydW5uaW5nXHJcbiAgICAgICAgPyAnZmluaXNoaW5nLi4uJ1xyXG4gICAgICAgIDogJzAgcXVldWVkJ1xyXG4gICAgICA6IGAke2ZtdE51bSh0b3RhbCl9IHF1ZXVlZCR7cnVubmluZyA/ICcgXHUwMEI3IHJ1bm5pbmcnIDogJyd9YDtcclxuICB0aHJlYWRPcGVuU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcclxuICB0aHJlYWRPcGVuU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcclxuICB0aHJlYWRPcGVuQ2FuY2VsQnRuLmhpZGRlbiA9ICFydW5uaW5nO1xyXG4gIHBhaW50UXVldWVQcm9ncmVzcyh0aHJlYWRPcGVuUHJvZ3Jlc3MsIHEpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgLy8gUHVsbCBzdHJhaWdodCBmcm9tIHN0b3JhZ2Ugb24gZmlyc3QgcmVuZGVyOyBsaXZlIHVwZGF0ZXMgY29tZSB2aWFcclxuICAvLyBgbG9nLWV2ZW50YCBicm9hZGNhc3RzLlxyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoJ2FjdGl2aXR5Jyk7XHJcbiAgY29uc3QgZXZlbnRzID0gKHN0b3JlZC5hY3Rpdml0eSBhcyBMb2dFdmVudFtdIHwgdW5kZWZpbmVkKSA/PyBbXTtcclxuICByZW5kZXJBY3Rpdml0eShldmVudHMpO1xyXG59XHJcblxyXG4vLyAtLS0gV2lyZSB1cCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuY2FwdHVyZUFsbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICB0cnkge1xyXG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjYXB0dXJlLWFsbCcgfSk7XHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIGNhcHR1cmVBbGxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9XHJcbn0pO1xyXG5cclxuY2FwdHVyZVRoaXNCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtdGhpcy1wYWdlJyB9KTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9XHJcbn0pO1xyXG5cclxuZmx1c2hCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgZmx1c2hCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2ZsdXNoLWFsbCcgfSk7XHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIGZsdXNoQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfVxyXG59KTtcclxuXHJcbmF1dG9Ub2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtYXV0by1jYXB0dXJlJywgb246IGF1dG9Ub2dnbGUuY2hlY2tlZCB9KTtcclxufSk7XHJcblxyXG51cGRhdGVFeGlzdGluZ1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtdXBkYXRlLWV4aXN0aW5nJywgb246IHVwZGF0ZUV4aXN0aW5nVG9nZ2xlLmNoZWNrZWQgfSk7XG59KTtcblxubG93QmFuZHdpZHRoVG9nZ2xlLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1sb3ctYmFuZHdpZHRoJywgb246IGxvd0JhbmR3aWR0aFRvZ2dsZS5jaGVja2VkIH0pO1xufSk7XG5cbm1hc3RlclN3aXRjaC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtZW5hYmxlZCcsIG9uOiBtYXN0ZXJTd2l0Y2guY2hlY2tlZCB9KTtcbn0pO1xuXHJcbmF1dG9TY3JvbGxTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC1hdXRvLXNjcm9sbCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9KTtcclxufSk7XHJcbmF1dG9TY3JvbGxDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgYXV0b1Njcm9sbENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1hdXRvLXNjcm9sbCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JywgKCkgPT4ge1xyXG4gIGF1dG9TY3JvbGxTZWNzRWwudGV4dENvbnRlbnQgPSBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWU7XHJcbn0pO1xyXG5hdXRvU2Nyb2xsSW50ZXJ2YWwuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xyXG4gIGNvbnN0IHNlY29uZHMgPSBOdW1iZXIoYXV0b1Njcm9sbEludGVydmFsLnZhbHVlKTtcclxuICBpZiAoTnVtYmVyLmlzRmluaXRlKHNlY29uZHMpKSB7XHJcbiAgICB2b2lkIHNlbmQoeyB0eXBlOiAnc2V0LWF1dG8tc2Nyb2xsLWludGVydmFsJywgc2Vjb25kcyB9KTtcclxuICB9XHJcbn0pO1xyXG5cclxucHVyZ2VMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XHJcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIGNvbnN0IG9rID0gd2luZG93LmNvbmZpcm0oXHJcbiAgICAnRHJvcCBldmVyeSBjb3VudGVyLCBydW4gYnVmZmVyLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgLyB0aHJlYWQtb3BlbmluZyBxdWV1ZSBlbnRyeSBmb3IgYWNjb3VudHMgbm90IGluIHlvdXIgdHJhY2tlZCBsaXN0P1xcblxcbicgK1xyXG4gICAgICAnVGhpcyBvbmx5IHRvdWNoZXMgbG9jYWwgZXh0ZW5zaW9uIHN0YXRlLiBBbHJlYWR5LWNvbW1pdHRlZCBmaWxlcyBpbiB0aGUgR2l0SHViIHJlcG8gYXJlIG5vdCBhZmZlY3RlZCBcdTIwMTQgJyArXHJcbiAgICAgICdydW4gc2NyaXB0cy9wdXJnZV91bnJlbGF0ZWQucHkgc2VwYXJhdGVseSBpZiB5b3UgYWxzbyB3YW50IHRvIHNjcnViIHRoZSByZXBvLidcclxuICApO1xyXG4gIGlmICghb2spIHJldHVybjtcclxuICB2b2lkIHNlbmQoeyB0eXBlOiAncHVyZ2UtdW5yZWxhdGVkJyB9KTtcclxufSk7XHJcblxyXG5yZWZldGNoU3RhcnRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtcmVmZXRjaCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9KTtcclxufSk7XHJcblxyXG5yZWZldGNoQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtcmVmZXRjaCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxubWVkaWFDcmF3bFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LW1lZGlhLWNyYXdsJyB9KS5maW5hbGx5KCgpID0+IHtcclxuICAgIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH0pO1xyXG59KTtcclxuXHJcbm1lZGlhQ3Jhd2xDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1tZWRpYS1jcmF3bCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICBtZWRpYUNyYXdsQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxudGhyZWFkT3BlblN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gIHRocmVhZE9wZW5TdGFydEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LXRocmVhZC1vcGVuJyB9KS5maW5hbGx5KCgpID0+IHtcclxuICAgIHRocmVhZE9wZW5TdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH0pO1xyXG59KTtcclxuXHJcbnRocmVhZE9wZW5DYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgdGhyZWFkT3BlbkNhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC10aHJlYWQtb3BlbicgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICB0aHJlYWRPcGVuQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxub3B0aW9uc0xpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcclxuICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ29wZW4tb3B0aW9ucycgfSk7XHJcbn0pO1xyXG5cclxudmlld2VyTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xyXG4gIGUucHJldmVudERlZmF1bHQoKTtcclxuICB2b2lkIHNlbmQoeyB0eXBlOiAnb3Blbi12aWV3ZXInIH0pO1xyXG59KTtcclxuXHJcbmNsZWFyQWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xyXG4gIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2xlYXItYWN0aXZpdHknIH0pO1xyXG4gIHJlbmRlckFjdGl2aXR5KFtdKTtcclxufSk7XHJcblxyXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24pID0+IHtcclxuICBpZiAoIW1zZyB8fCB0eXBlb2YgbXNnICE9PSAnb2JqZWN0JykgcmV0dXJuO1xyXG4gIGNvbnN0IG0gPSBtc2cgYXMgeyB0eXBlPzogc3RyaW5nOyBzdGF0ZT86IEV4dGVuc2lvblN0YXRlOyBldmVudD86IExvZ0V2ZW50IH07XHJcbiAgaWYgKG0udHlwZSA9PT0gJ3N0YXRlLWNoYW5nZWQnICYmIG0uc3RhdGUpIHtcclxuICAgIGxhc3RTdGF0ZSA9IG0uc3RhdGU7XHJcbiAgICBwYWludChtLnN0YXRlKTtcclxuICB9IGVsc2UgaWYgKG0udHlwZSA9PT0gJ2xvZy1ldmVudCcgJiYgbS5ldmVudCkge1xyXG4gICAgcHJlcGVuZEV2ZW50KG0uZXZlbnQpO1xyXG4gIH1cclxufSk7XHJcblxyXG5mdW5jdGlvbiBwcmVwZW5kRXZlbnQoZXY6IExvZ0V2ZW50KTogdm9pZCB7XHJcbiAgLy8gSWYgdGhlIGxpc3QgaXMgc2hvd2luZyB0aGUgXCJlbXB0eVwiIHBsYWNlaG9sZGVyLCBjbGVhciBpdC5cclxuICBpZiAoYWN0aXZpdHlMaXN0LmZpcnN0RWxlbWVudENoaWxkPy5jbGFzc0xpc3QuY29udGFpbnMoJ2VtcHR5JykpIHtcclxuICAgIGFjdGl2aXR5TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcclxuICB9XHJcbiAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xyXG4gIGxpLmNsYXNzTmFtZSA9IGBldiAke2V2LmxldmVsfWA7XHJcbiAgY29uc3QgdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgdHMuY2xhc3NOYW1lID0gJ2V2LXRzJztcclxuICB0cy50ZXh0Q29udGVudCA9IG5ldyBEYXRlKGV2LnRzKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLVVTJywgeyBob3VyMTI6IGZhbHNlIH0pO1xyXG4gIGNvbnN0IGljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgaWNvbi5jbGFzc05hbWUgPSAnZXYtaWNvbic7XHJcbiAgaWNvbi50ZXh0Q29udGVudCA9IGV2LmxldmVsID09PSAnZXJyb3InID8gJ1x1MjcxNycgOiBldi5sZXZlbCA9PT0gJ3dhcm4nID8gJyEnIDogJ1x1MDBCNyc7XHJcbiAgY29uc3QgYm9keSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICBjb25zdCBtc2cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICBtc2cuY2xhc3NOYW1lID0gJ2V2LW1zZyc7XHJcbiAgbXNnLnRleHRDb250ZW50ID0gZXYubXNnO1xyXG4gIGJvZHkuYXBwZW5kKG1zZyk7XHJcbiAgY29uc3QgY3R4S2V5cyA9IE9iamVjdC5rZXlzKGV2LmNvbnRleHQpO1xyXG4gIGlmIChjdHhLZXlzLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IGN0eCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgY3R4LmNsYXNzTmFtZSA9ICdldi1jdHgnO1xyXG4gICAgY3R4LnRleHRDb250ZW50ID0gY3R4S2V5cy5tYXAoKGspID0+IGAke2t9PSR7c3RyaW5naWZ5U2hvcnQoZXYuY29udGV4dFtrXSl9YCkuam9pbignIFx1MDBCNyAnKTtcclxuICAgIGJvZHkuYXBwZW5kKGN0eCk7XHJcbiAgfVxyXG4gIGxpLmFwcGVuZCh0cywgaWNvbiwgYm9keSk7XHJcbiAgYWN0aXZpdHlMaXN0LnByZXBlbmQobGkpO1xyXG4gIHdoaWxlIChhY3Rpdml0eUxpc3QuY2hpbGRFbGVtZW50Q291bnQgPiBBQ1RJVklUWV9UQUlMX01BWCkge1xyXG4gICAgYWN0aXZpdHlMaXN0Lmxhc3RFbGVtZW50Q2hpbGQ/LnJlbW92ZSgpO1xyXG4gIH1cclxufVxyXG5cclxuLy8gSW5pdGlhbCBwYWludC5cclxudm9pZCByZWZyZXNoU3RhdGUoKTtcclxudm9pZCByZWZyZXNoQWN0aXZpdHkoKTtcclxuXHJcbi8vIFBlcmlvZGljYWxseSByZS1mZXRjaCBzdGF0ZSBzbyBcImxhc3QgY2FwdHVyZVwiIHRpbWVzIHN0YXkgZnJlc2guXHJcbnNldEludGVydmFsKCgpID0+IHtcclxuICB2b2lkIHJlZnJlc2hTdGF0ZSgpO1xyXG59LCAxNV8wMDApO1xyXG4iXSwKICAibWFwcGluZ3MiOiAiO0FBOEZPLElBQU0sb0JBQW9CO0FBRzFCLElBQU0sZ0NBQWdDLEtBQUssS0FBSzs7O0FDdEZ2RCxJQUFNLElBQUksQ0FBc0MsT0FBa0I7QUFDaEUsUUFBTSxLQUFLLFNBQVMsZUFBZSxFQUFFO0FBQ3JDLE1BQUksQ0FBQyxHQUFJLE9BQU0sSUFBSSxNQUFNLG9CQUFvQixFQUFFLEVBQUU7QUFDakQsU0FBTztBQUNUO0FBRUEsSUFBTSxVQUFVLEVBQUUsVUFBVTtBQUM1QixJQUFNLFdBQVcsRUFBbUIsV0FBVztBQUMvQyxJQUFNLGNBQWMsRUFBb0IsY0FBYztBQUN0RCxJQUFNLGtCQUFrQixFQUFvQixtQkFBbUI7QUFDL0QsSUFBTSxlQUFlLEVBQW9CLGVBQWU7QUFDeEQsSUFBTSxhQUFhLEVBQW9CLGNBQWM7QUFDckQsSUFBTSx1QkFBdUIsRUFBb0IsaUJBQWlCO0FBQ2xFLElBQU0scUJBQXFCLEVBQW9CLGVBQWU7QUFDOUQsSUFBTSxnQkFBZ0IsRUFBcUIsYUFBYTtBQUN4RCxJQUFNLGlCQUFpQixFQUFxQixjQUFjO0FBQzFELElBQU0sV0FBVyxFQUFxQixXQUFXO0FBQ2pELElBQU0sY0FBYyxFQUFxQixjQUFjO0FBQ3ZELElBQU0sYUFBYSxFQUFxQixhQUFhO0FBQ3JELElBQU0sY0FBYyxFQUFxQixnQkFBZ0I7QUFDekQsSUFBTSxlQUFlLEVBQW1CLGFBQWE7QUFDckQsSUFBTSxlQUFlLEVBQW9CLGVBQWU7QUFDeEQsSUFBTSxjQUFjLEVBQW1CLGNBQWM7QUFDckQsSUFBTSxxQkFBcUIsRUFBb0Isc0JBQXNCO0FBQ3JFLElBQU0sbUJBQW1CLEVBQW1CLGtCQUFrQjtBQUM5RCxJQUFNLG1CQUFtQixFQUFtQixvQkFBb0I7QUFDaEUsSUFBTSxxQkFBcUIsRUFBcUIsbUJBQW1CO0FBQ25FLElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLHFCQUFxQixFQUFtQixzQkFBc0I7QUFDcEUsSUFBTSxpQkFBaUIsRUFBZSxpQkFBaUI7QUFDdkQsSUFBTSxlQUFlLEVBQW1CLGVBQWU7QUFDdkQsSUFBTSxrQkFBa0IsRUFBcUIsZUFBZTtBQUM1RCxJQUFNLG1CQUFtQixFQUFxQixnQkFBZ0I7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsa0JBQWtCO0FBQzdELElBQU0sb0JBQW9CLEVBQWUscUJBQXFCO0FBQzlELElBQU0sa0JBQWtCLEVBQW1CLG1CQUFtQjtBQUM5RCxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLG9CQUFvQixFQUFlLHFCQUFxQjtBQUM5RCxJQUFNLGtCQUFrQixFQUFtQixtQkFBbUI7QUFDOUQsSUFBTSxxQkFBcUIsRUFBcUIsbUJBQW1CO0FBQ25FLElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLHFCQUFxQixFQUFtQixzQkFBc0I7QUFDcEUsSUFBTSxZQUFZLEVBQXFCLGlCQUFpQjtBQUV4RCxJQUFJLFlBQW1DO0FBRXZDLGVBQWUsS0FBUSxLQUFpQztBQUN0RCxTQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDeEM7QUFFQSxTQUFTLGNBQWMsT0FBNkI7QUFDbEQsUUFBTSxFQUFFLFlBQVksU0FBUyxJQUFJO0FBQ2pDLE1BQUksTUFBTTtBQUNWLE1BQUksT0FBTztBQUtYLFFBQU0sZ0JBQ0osV0FBVyxXQUFXLFFBQVEsU0FBUyxVQUFVLFdBQVcsMkJBQTJCO0FBQ3pGLE1BQUksQ0FBQyxTQUFTLFFBQVE7QUFDcEIsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsZUFBZTtBQUN4QixVQUFNO0FBQ04sV0FBTyxXQUFXLFNBQVMsTUFBTSx1QkFBdUIsU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLDRDQUF1QyxXQUFXLGlCQUFpQixRQUFRO0FBQUEsRUFDcEssV0FBVyxXQUFXLFdBQVcsTUFBTTtBQUNyQyxVQUFNO0FBQ04sV0FBTyxpQkFBaUIsV0FBVyxTQUFTLEdBQUcsT0FBTyxTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksZUFBTyxTQUFTLFNBQVM7QUFBQSxFQUNoSCxXQUFXLFdBQVcsV0FBVyxjQUFjO0FBQzdDLFVBQU07QUFDTixXQUFPLGlCQUFpQixXQUFXLEtBQUssSUFDcEMsb0VBQ0E7QUFBQSxFQUNOLFdBQVcsV0FBVyxXQUFXLGdCQUFnQjtBQUMvQyxVQUFNO0FBQ04sVUFBTSxTQUFTLGtCQUFrQixXQUFXLGdCQUFnQjtBQUM1RCxXQUFPLFNBQ0gscUNBQWdDLE1BQU0sS0FDdEM7QUFBQSxFQUNOLFdBQVcsV0FBVyxXQUFXLGlCQUFpQjtBQUNoRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxXQUFXLFdBQVcsa0JBQWtCO0FBQ2pELFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxPQUFPO0FBQ0wsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0EsVUFBUSxZQUFZLE9BQU8sR0FBRztBQUM5QixXQUFTLGNBQWM7QUFDdkIsV0FBUyxRQUFRLFdBQVcsU0FBUztBQUN2QztBQUVBLFNBQVMsT0FBTyxLQUE0QjtBQUMxQyxNQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLFFBQU0sSUFBSSxLQUFLLE1BQU0sR0FBRztBQUN4QixNQUFJLENBQUMsT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ2hDLFFBQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxHQUFJLENBQUM7QUFDNUQsTUFBSSxPQUFPLEVBQUcsUUFBTztBQUNyQixNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNqQyxNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxNQUFJLFFBQVEsR0FBSSxRQUFPLEdBQUcsS0FBSztBQUMvQixRQUFNLE9BQU8sS0FBSyxNQUFNLFFBQVEsRUFBRTtBQUNsQyxTQUFPLEdBQUcsSUFBSTtBQUNoQjtBQUVBLFNBQVMsa0JBQWtCLFVBQWlDO0FBQzFELE1BQUksYUFBYSxLQUFNLFFBQU87QUFDOUIsUUFBTSxXQUFXLFdBQVcsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDeEQsTUFBSSxZQUFZLEVBQUcsUUFBTztBQUMxQixRQUFNLFlBQVksSUFBSSxLQUFLLFdBQVcsR0FBSSxFQUFFLG1CQUFtQixDQUFDLEdBQUc7QUFBQSxJQUNqRSxNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsRUFDVixDQUFDO0FBQ0QsTUFBSSxXQUFXLEdBQUksUUFBTyxNQUFNLFFBQVEsTUFBTSxTQUFTO0FBQ3ZELFFBQU0sT0FBTyxLQUFLLE1BQU0sV0FBVyxFQUFFO0FBQ3JDLE1BQUksT0FBTyxHQUFJLFFBQU8sTUFBTSxJQUFJLE1BQU0sU0FBUztBQUMvQyxRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxTQUFPLE1BQU0sS0FBSyxNQUFNLFNBQVM7QUFDbkM7QUFFQSxTQUFTLE9BQU8sR0FBbUI7QUFDakMsU0FBTyxFQUFFLGVBQWUsT0FBTztBQUNqQztBQUVBLFNBQVMsaUJBQWlCLFNBQWlDO0FBQ3pELFNBQ0UsT0FBTyxZQUFZLFlBQ25CLDZFQUE2RSxLQUFLLE9BQU87QUFFN0Y7QUFFQSxTQUFTLGVBQWUsT0FBNkI7QUFDbkQsY0FBWSxnQkFBZ0I7QUFDNUIsTUFBSSxNQUFNLFNBQVMsV0FBVyxHQUFHO0FBQy9CLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsZ0JBQVksT0FBTyxFQUFFO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLGFBQVcsS0FBSyxNQUFNLFVBQVU7QUFDOUIsVUFBTSxJQUFJLE1BQU0sU0FBUyxFQUFFLE1BQU07QUFDakMsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxLQUFLLEVBQUUsZ0JBQWdCLElBQUksZ0JBQWdCO0FBRTFELFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsVUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0FBQzVDLFdBQU8sWUFBWTtBQUNuQixXQUFPLFlBQVksNEJBQTRCLFdBQVcsRUFBRSxNQUFNLENBQUM7QUFDbkUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsRUFBRTtBQUNyQixTQUFLLE9BQU8sUUFBUSxJQUFJO0FBRXhCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsVUFBTSxRQUFRLFNBQVMsY0FBYyxNQUFNO0FBQzNDLFVBQU0sWUFBWTtBQUNsQixVQUFNLFFBQVEsR0FBRyxjQUFjO0FBQy9CLFVBQU0sV0FBVyxHQUFHLGlCQUFpQjtBQUNyQyxVQUFNLE9BQU8sR0FBRyxpQkFBaUI7QUFDakMsVUFBTSxZQUNKLHFCQUFxQixPQUFPLEtBQUssQ0FBQyxtQkFDakMsV0FBVyxJQUFJLDJCQUF3QixPQUFPLFFBQVEsQ0FBQyxxQkFBcUIsTUFDN0UsY0FBVyxXQUFXLE9BQU8sSUFBSSxDQUFDLENBQUM7QUFFckMsVUFBTSxVQUFVLFNBQVMsY0FBYyxNQUFNO0FBQzdDLFlBQVEsWUFBWTtBQUNwQixVQUFNLE1BQU0sU0FBUyxjQUFjLFFBQVE7QUFDM0MsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYztBQUNsQixRQUFJLGlCQUFpQixTQUFTLFlBQVk7QUFDeEMsVUFBSSxXQUFXO0FBQ2YsVUFBSTtBQUNGLGNBQU0sS0FBSyxFQUFFLE1BQU0sZUFBZSxRQUFRLEVBQUUsT0FBTyxDQUFDO0FBQUEsTUFDdEQsVUFBRTtBQUNBLFlBQUksV0FBVztBQUFBLE1BQ2pCO0FBQUEsSUFDRixDQUFDO0FBQ0QsWUFBUSxPQUFPLEdBQUc7QUFFbEIsUUFBSSxPQUFPLE9BQU8sT0FBTztBQUN6QixPQUFHLE9BQU8sTUFBTSxHQUFHO0FBQ25CLGdCQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsUUFBMEI7QUFDaEQsZUFBYSxnQkFBZ0I7QUFDN0IsTUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLGlCQUFhLE9BQU8sRUFBRTtBQUN0QjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLE1BQU0sT0FBTyxNQUFNLEdBQUcsaUJBQWlCLEdBQUc7QUFDbkQsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixVQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsR0FBRztBQUNyQixTQUFLLE9BQU8sR0FBRztBQUNmLFVBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLFFBQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsWUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFVBQUksWUFBWTtBQUNoQixVQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFdBQUssT0FBTyxHQUFHO0FBQUEsSUFDakI7QUFDQSxPQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsaUJBQWEsT0FBTyxFQUFFO0FBQUEsRUFDeEI7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUFvQjtBQUMxQyxNQUFJLE1BQU0sS0FBTSxRQUFPO0FBQ3ZCLE1BQUksT0FBTyxNQUFNLFNBQVUsUUFBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQ3pFLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFVBQVcsUUFBTyxPQUFPLENBQUM7QUFDcEUsTUFBSTtBQUNGLFVBQU0sSUFBSSxLQUFLLFVBQVUsQ0FBQztBQUMxQixXQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFBQSxFQUNoRCxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsV0FBVyxHQUFtQjtBQUNyQyxTQUFPLEVBQUU7QUFBQSxJQUFRO0FBQUEsSUFBWSxDQUFDLE1BQzVCLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxXQUFXO0FBQUEsRUFDekY7QUFDRjtBQUVBLGVBQWUsZUFBOEI7QUFDM0MsTUFBSTtBQUNGLGdCQUFZLE1BQU0sS0FBcUIsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUM1RCxVQUFNLFNBQVM7QUFBQSxFQUNqQixTQUFTLEtBQUs7QUFDWixZQUFRLEtBQUssNkNBQTZDLEdBQUc7QUFBQSxFQUMvRDtBQUNGO0FBRUEsU0FBUyxNQUFNLE9BQTZCO0FBQzFDLGVBQWEsY0FBYyxNQUFNO0FBQ2pDLGdCQUFjLEtBQUs7QUFDbkIsYUFBVyxVQUFVLE1BQU0sU0FBUztBQUNwQyx1QkFBcUIsVUFBVSxNQUFNLFNBQVMsbUJBQW1CO0FBQ2pFLHFCQUFtQixVQUFVLE1BQU0sU0FBUyx5QkFBeUI7QUFDckUsYUFBVyxPQUFPLFdBQVcsTUFBTSxTQUFTLEtBQUssY0FBYyxNQUFNLFNBQVMsSUFBSTtBQUNsRixvQkFBa0IsS0FBSztBQUN2QixpQkFBZSxLQUFLO0FBQ3BCLHFCQUFtQixNQUFNLG9CQUFvQjtBQUM3QyxrQkFBZ0IsS0FBSztBQUNyQixrQkFBZ0IsS0FBSztBQUNyQixlQUFhLEtBQUs7QUFDbEIsa0JBQWdCLEtBQUs7QUFDdkI7QUFFQSxTQUFTLG1CQUFtQixNQUE2QjtBQUN2RCxrQkFBZ0IsZ0JBQWdCO0FBQ2hDLE1BQUksS0FBSyxXQUFXLEdBQUc7QUFDckIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixvQkFBZ0IsT0FBTyxFQUFFO0FBQ3pCO0FBQUEsRUFDRjtBQUNBLGFBQVcsT0FBTyxLQUFLLE1BQU0sR0FBRyxFQUFFLEdBQUc7QUFDbkMsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxnQkFBZ0IsSUFBSSxjQUFjO0FBRWpELFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsVUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0FBQ3ZDLFNBQUssWUFBWTtBQUNqQixTQUFLLE9BQU8sSUFBSTtBQUNoQixTQUFLLFNBQVM7QUFDZCxTQUFLLE1BQU07QUFDWCxTQUFLLGNBQWMsSUFBSSxJQUFJLGNBQWM7QUFDekMsVUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0FBQzVDLFdBQU8sWUFBWSxjQUFjLElBQUksY0FBYztBQUNuRCxXQUFPLGNBQWMsSUFBSSxtQkFBbUIsVUFBVSxVQUFVO0FBQ2hFLFFBQUksT0FBTyxNQUFNLE1BQU07QUFFdkIsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsYUFBYSxJQUFJLE1BQU0sR0FBRztBQUU3QyxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxHQUFHLGtCQUFrQixJQUFJLE1BQU0sQ0FBQyxTQUFNLElBQUksVUFBVSxnQkFBYSxPQUFPLElBQUksU0FBUyxDQUFDO0FBRXpHLE9BQUcsT0FBTyxLQUFLLE1BQU0sSUFBSTtBQUN6QixvQkFBZ0IsT0FBTyxFQUFFO0FBQUEsRUFDM0I7QUFDRjtBQUVBLFNBQVMsa0JBQWtCLFFBQXlDO0FBQ2xFLE1BQUksV0FBVyxXQUFZLFFBQU87QUFDbEMsTUFBSSxXQUFXLFlBQWEsUUFBTztBQUNuQyxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGFBQWEsTUFBYyxLQUFxQjtBQUN2RCxRQUFNLFVBQVUsS0FBSyxRQUFRLFFBQVEsR0FBRyxFQUFFLEtBQUs7QUFDL0MsU0FBTyxRQUFRLFVBQVUsTUFBTSxVQUFVLEdBQUcsUUFBUSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDdkU7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLElBQUksTUFBTTtBQUNoQixRQUFNLFFBQVEsRUFBRTtBQUNoQixRQUFNLFVBQVUsRUFBRTtBQUNsQixvQkFBa0IsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUMzQyxrQkFBZ0IsY0FDZCxVQUFVLElBQ04sVUFDRSxvQkFDQSxhQUNGLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxVQUFVLGtCQUFlLEVBQUU7QUFDM0QscUJBQW1CLFNBQVM7QUFDNUIscUJBQW1CLFdBQVcsVUFBVTtBQUN4QyxzQkFBb0IsU0FBUyxDQUFDO0FBQzlCLHFCQUFtQixvQkFBb0IsQ0FBQztBQUMxQztBQUVBLFNBQVMsbUJBQ1AsSUFDQSxHQUNNO0FBQ04sTUFBSSxDQUFDLEVBQUUsV0FBVyxFQUFFLGNBQWMsR0FBRztBQUNuQyxPQUFHLFNBQVM7QUFDWjtBQUFBLEVBQ0Y7QUFHQSxRQUFNLFFBQVEsS0FBSyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLEtBQUs7QUFDOUQsS0FBRyxTQUFTO0FBQ1osS0FBRyxjQUFjLEdBQUcsT0FBTyxFQUFFLFNBQVMsQ0FBQyxNQUFNLE9BQU8sS0FBSyxDQUFDO0FBQzFELEtBQUcsWUFBWSxFQUFFLFVBQVUsZ0JBQWdCO0FBQzdDO0FBRUEsU0FBUyxrQkFBa0IsT0FBNkI7QUFDdEQsUUFBTSxLQUFLLE1BQU0sU0FBUyxZQUFZO0FBQ3RDLGVBQWEsVUFBVTtBQUN2QixjQUFZLGNBQWMsS0FBSyxPQUFPO0FBQ3RDLFdBQVMsS0FBSyxVQUFVLE9BQU8sVUFBVSxDQUFDLEVBQUU7QUFDOUM7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLE9BQU8sTUFBTSxTQUFTO0FBQzVCLHFCQUFtQixRQUFRLE9BQU8sSUFBSTtBQUN0QyxtQkFBaUIsY0FBYyxPQUFPLElBQUk7QUFDMUMsUUFBTSxLQUFLLE1BQU07QUFDakIscUJBQW1CLFNBQVMsR0FBRztBQUMvQixzQkFBb0IsU0FBUyxDQUFDLEdBQUc7QUFDakMsTUFBSSxHQUFHLFFBQVE7QUFDYixVQUFNLElBQUksR0FBRztBQUNiLHFCQUFpQixjQUNmLE1BQU0sSUFBSSxrQ0FBNkIsa0JBQWEsQ0FBQyxJQUFJLE1BQU0sSUFBSSxRQUFRLE1BQU07QUFDbkYscUJBQWlCLFlBQVk7QUFBQSxFQUMvQixPQUFPO0FBQ0wscUJBQWlCLGNBQWM7QUFDL0IscUJBQWlCLFlBQVk7QUFBQSxFQUMvQjtBQUNBLE1BQUksR0FBRyxVQUFVLEdBQUcsY0FBYyxLQUFLLEdBQUcsZ0JBQWdCLEdBQUc7QUFDM0QsdUJBQW1CLFNBQVM7QUFDNUIsVUFBTSxRQUFRO0FBQUEsTUFDWixHQUFHLE9BQU8sR0FBRyxXQUFXLENBQUM7QUFBQSxNQUN6QixHQUFHLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQztBQUFBLE1BQzlCLEdBQUcsT0FBTyxHQUFHLHFCQUFxQixDQUFDO0FBQUEsSUFDckM7QUFDQSxRQUFJLEdBQUcsa0JBQWtCLEVBQUcsT0FBTSxLQUFLLEdBQUcsT0FBTyxHQUFHLGVBQWUsQ0FBQyxjQUFjO0FBQ2xGLFVBQU0sS0FBSyxHQUFHLE9BQU8sR0FBRyxhQUFhLENBQUMsV0FBVztBQUNqRCx1QkFBbUIsY0FBYyxNQUFNLEtBQUssUUFBSztBQUNqRCx1QkFBbUIsWUFBWSxHQUFHLFNBQVMsZ0JBQWdCO0FBQUEsRUFDN0QsT0FBTztBQUNMLHVCQUFtQixTQUFTO0FBQUEsRUFDOUI7QUFDRjtBQUVBLFNBQVMsYUFBYSxPQUE2QjtBQUNqRCxRQUFNLElBQUksTUFBTTtBQUNoQixRQUFNLFFBQVEsRUFBRTtBQUNoQixRQUFNLFVBQVUsRUFBRTtBQUNsQixpQkFBZSxTQUFTLFVBQVUsS0FBSyxDQUFDO0FBQ3hDLGVBQWEsY0FDWCxVQUFVLElBQ04sVUFDRSxvQkFDQSxhQUNGLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxVQUFVLGtCQUFlLEVBQUU7QUFDM0Qsa0JBQWdCLFNBQVM7QUFDekIsa0JBQWdCLFdBQVcsVUFBVTtBQUNyQyxtQkFBaUIsU0FBUyxDQUFDO0FBQzNCLHFCQUFtQixpQkFBaUIsQ0FBQztBQUN2QztBQUVBLFNBQVMsZ0JBQWdCLE9BQTZCO0FBQ3BELFFBQU0sSUFBSSxNQUFNO0FBQ2hCLFFBQU0sUUFBUSxFQUFFO0FBQ2hCLFFBQU0sVUFBVSxFQUFFO0FBQ2xCLG9CQUFrQixTQUFTLFVBQVUsS0FBSyxDQUFDO0FBQzNDLGtCQUFnQixjQUNkLFVBQVUsSUFDTixVQUNFLGlCQUNBLGFBQ0YsR0FBRyxPQUFPLEtBQUssQ0FBQyxVQUFVLFVBQVUsa0JBQWUsRUFBRTtBQUMzRCxxQkFBbUIsU0FBUztBQUM1QixxQkFBbUIsV0FBVyxVQUFVO0FBQ3hDLHNCQUFvQixTQUFTLENBQUM7QUFDOUIscUJBQW1CLG9CQUFvQixDQUFDO0FBQzFDO0FBRUEsZUFBZSxrQkFBaUM7QUFHOUMsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxVQUFVO0FBQ3pELFFBQU0sU0FBVSxPQUFPLFlBQXVDLENBQUM7QUFDL0QsaUJBQWUsTUFBTTtBQUN2QjtBQUlBLGNBQWMsaUJBQWlCLFNBQVMsWUFBWTtBQUNsRCxnQkFBYyxXQUFXO0FBQ3pCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUFBLEVBQ3BDLFVBQUU7QUFDQSxrQkFBYyxXQUFXO0FBQUEsRUFDM0I7QUFDRixDQUFDO0FBRUQsZUFBZSxpQkFBaUIsU0FBUyxZQUFZO0FBQ25ELGlCQUFlLFdBQVc7QUFDMUIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFBQSxFQUMxQyxVQUFFO0FBQ0EsbUJBQWUsV0FBVztBQUFBLEVBQzVCO0FBQ0YsQ0FBQztBQUVELFNBQVMsaUJBQWlCLFNBQVMsWUFBWTtBQUM3QyxXQUFTLFdBQVc7QUFDcEIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQUEsRUFDbEMsVUFBRTtBQUNBLGFBQVMsV0FBVztBQUFBLEVBQ3RCO0FBQ0YsQ0FBQztBQUVELFdBQVcsaUJBQWlCLFVBQVUsTUFBTTtBQUMxQyxPQUFLLEtBQUssRUFBRSxNQUFNLHVCQUF1QixJQUFJLFdBQVcsUUFBUSxDQUFDO0FBQ25FLENBQUM7QUFFRCxxQkFBcUIsaUJBQWlCLFVBQVUsTUFBTTtBQUNwRCxPQUFLLEtBQUssRUFBRSxNQUFNLDBCQUEwQixJQUFJLHFCQUFxQixRQUFRLENBQUM7QUFDaEYsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsVUFBVSxNQUFNO0FBQ2xELE9BQUssS0FBSyxFQUFFLE1BQU0sd0JBQXdCLElBQUksbUJBQW1CLFFBQVEsQ0FBQztBQUM1RSxDQUFDO0FBRUQsYUFBYSxpQkFBaUIsVUFBVSxNQUFNO0FBQzVDLE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLElBQUksYUFBYSxRQUFRLENBQUM7QUFDaEUsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUNELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELG1CQUFpQixjQUFjLG1CQUFtQjtBQUNwRCxDQUFDO0FBQ0QsbUJBQW1CLGlCQUFpQixVQUFVLE1BQU07QUFDbEQsUUFBTSxVQUFVLE9BQU8sbUJBQW1CLEtBQUs7QUFDL0MsTUFBSSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzVCLFNBQUssS0FBSyxFQUFFLE1BQU0sNEJBQTRCLFFBQVEsQ0FBQztBQUFBLEVBQ3pEO0FBQ0YsQ0FBQztBQUVELFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2hELElBQUUsZUFBZTtBQUNqQixRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFHRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsT0FBSyxLQUFLLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUN2QyxDQUFDO0FBRUQsZ0JBQWdCLGlCQUFpQixTQUFTLE1BQU07QUFDOUMsa0JBQWdCLFdBQVc7QUFDM0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNqRCxvQkFBZ0IsV0FBVztBQUFBLEVBQzdCLENBQUM7QUFDSCxDQUFDO0FBRUQsaUJBQWlCLGlCQUFpQixTQUFTLE1BQU07QUFDL0MsbUJBQWlCLFdBQVc7QUFDNUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNsRCxxQkFBaUIsV0FBVztBQUFBLEVBQzlCLENBQUM7QUFDSCxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQscUJBQW1CLFdBQVc7QUFDOUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNyRCx1QkFBbUIsV0FBVztBQUFBLEVBQ2hDLENBQUM7QUFDSCxDQUFDO0FBRUQsb0JBQW9CLGlCQUFpQixTQUFTLE1BQU07QUFDbEQsc0JBQW9CLFdBQVc7QUFDL0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUN0RCx3QkFBb0IsV0FBVztBQUFBLEVBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQscUJBQW1CLFdBQVc7QUFDOUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNyRCx1QkFBbUIsV0FBVztBQUFBLEVBQ2hDLENBQUM7QUFDSCxDQUFDO0FBRUQsb0JBQW9CLGlCQUFpQixTQUFTLE1BQU07QUFDbEQsc0JBQW9CLFdBQVc7QUFDL0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUN0RCx3QkFBb0IsV0FBVztBQUFBLEVBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRUQsWUFBWSxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3BDLENBQUM7QUFFRCxXQUFXLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNqRCxJQUFFLGVBQWU7QUFDakIsT0FBSyxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDbkMsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsWUFBWTtBQUNoRCxRQUFNLEtBQUssRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3JDLGlCQUFlLENBQUMsQ0FBQztBQUNuQixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLFFBQWlCO0FBQ3RELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVO0FBQ3JDLFFBQU0sSUFBSTtBQUNWLE1BQUksRUFBRSxTQUFTLG1CQUFtQixFQUFFLE9BQU87QUFDekMsZ0JBQVksRUFBRTtBQUNkLFVBQU0sRUFBRSxLQUFLO0FBQUEsRUFDZixXQUFXLEVBQUUsU0FBUyxlQUFlLEVBQUUsT0FBTztBQUM1QyxpQkFBYSxFQUFFLEtBQUs7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxTQUFTLGFBQWEsSUFBb0I7QUFFeEMsTUFBSSxhQUFhLG1CQUFtQixVQUFVLFNBQVMsT0FBTyxHQUFHO0FBQy9ELGlCQUFhLGdCQUFnQjtBQUFBLEVBQy9CO0FBQ0EsUUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLEtBQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixRQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsS0FBRyxZQUFZO0FBQ2YsS0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFFBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxPQUFLLFlBQVk7QUFDakIsT0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsUUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLE1BQUksWUFBWTtBQUNoQixNQUFJLGNBQWMsR0FBRztBQUNyQixPQUFLLE9BQU8sR0FBRztBQUNmLFFBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLE1BQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFNBQUssT0FBTyxHQUFHO0FBQUEsRUFDakI7QUFDQSxLQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsZUFBYSxRQUFRLEVBQUU7QUFDdkIsU0FBTyxhQUFhLG9CQUFvQixtQkFBbUI7QUFDekQsaUJBQWEsa0JBQWtCLE9BQU87QUFBQSxFQUN4QztBQUNGO0FBR0EsS0FBSyxhQUFhO0FBQ2xCLEtBQUssZ0JBQWdCO0FBR3JCLFlBQVksTUFBTTtBQUNoQixPQUFLLGFBQWE7QUFDcEIsR0FBRyxJQUFNOyIsCiAgIm5hbWVzIjogW10KfQo=
