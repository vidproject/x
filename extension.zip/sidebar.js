// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var recentTweetList = $("recent-tweet-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var updateExistingToggle = $("update-existing");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var threadOpenSection = $("thread-open-section");
var threadOpenCount = $("thread-open-count");
var threadOpenStartBtn = $("thread-open-start");
var threadOpenCancelBtn = $("thread-open-cancel");
var threadOpenProgress = $("thread-open-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = isWriteAuthError(connection.error) ? "PAT can read repo but cannot write - set Contents: Read & Write" : "Auth error - check your PAT";
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  updateExistingToggle.checked = state.settings.updateExisting !== false;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  renderRecentTweets(state.recentTweetSightings);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
  paintThreadOpen(state);
}
function renderRecentTweets(rows) {
  recentTweetList.replaceChildren();
  if (rows.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No tweets seen yet.";
    recentTweetList.append(li);
    return;
  }
  for (const row of rows.slice(0, 40)) {
    const li = document.createElement("li");
    li.className = `recent-tweet ${row.archive_status}`;
    const top = document.createElement("div");
    top.className = "tweet-head";
    const link = document.createElement("a");
    link.className = "tweet-handle";
    link.href = row.tweet_url;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = `@${row.account_handle}`;
    const status = document.createElement("span");
    status.className = `tweet-pill ${row.archive_status}`;
    status.textContent = row.archive_status === "saved" ? "saved" : "new";
    top.append(link, status);
    const text = document.createElement("div");
    text.className = "tweet-text";
    text.textContent = truncateText(row.text, 140);
    const meta = document.createElement("div");
    meta.className = "tweet-meta";
    meta.textContent = `${formatTweetAction(row.action)} \xB7 ${row.tweet_type} \xB7 posted ${fmtRel(row.posted_at)}`;
    li.append(top, text, meta);
    recentTweetList.append(li);
  }
}
function formatTweetAction(action) {
  if (action === "buffered") return "buffered";
  if (action === "unchanged") return "unchanged";
  return "skipped";
}
function truncateText(text, max) {
  const compact = text.replace(/\s+/g, " ").trim();
  return compact.length <= max ? compact : `${compact.slice(0, max - 1)}\u2026`;
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    const parts = [
      `${fmtNum(as.scrollCount)} scrolls`,
      `${fmtNum(as.ingestedNewCount)} new buffered`,
      `${fmtNum(as.ingestedExistingCount)} old buffered`
    ];
    if (as.skippedOldCount > 0) parts.push(`${fmtNum(as.skippedOldCount)} old skipped`);
    parts.push(`${fmtNum(as.expandedCount)} expanded`);
    autoScrollProgress.textContent = parts.join(" \xB7 ");
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
function paintThreadOpen(state) {
  const q = state.threadOpenQueue;
  const total = q.total;
  const running = q.running;
  threadOpenSection.hidden = total === 0 && !running;
  threadOpenCount.textContent = total === 0 ? running ? "finishing..." : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  threadOpenStartBtn.hidden = running;
  threadOpenStartBtn.disabled = total === 0;
  threadOpenCancelBtn.hidden = !running;
  paintQueueProgress(threadOpenProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
updateExistingToggle.addEventListener("change", () => {
  void send({ type: "toggle-update-existing", on: updateExistingToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl / thread-opening queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
threadOpenStartBtn.addEventListener("click", () => {
  threadOpenStartBtn.disabled = true;
  void send({ type: "start-thread-open" }).finally(() => {
    threadOpenStartBtn.disabled = false;
  });
});
threadOpenCancelBtn.addEventListener("click", () => {
  threadOpenCancelBtn.disabled = true;
  void send({ type: "cancel-thread-open" }).finally(() => {
    threadOpenCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgZW5hYmxlZDogdHJ1ZSxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxuICB1cGRhdGVFeGlzdGluZzogdHJ1ZSxcbn07XG5cbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XG5cbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1JhcGlkUmVzcG9uc2U0NycsIGxhYmVsOiAnUmFwaWQgUmVzcG9uc2UgNDcnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnU3RlcGhlbk0nLCBsYWJlbDogJ1N0ZXBoZW4gTWlsbGVyJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0dyZWdvcnlLQm92aW5vJywgbGFiZWw6ICdHcmVnb3J5IEJvdmlubycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSZWFsVG9tSG9tYW4nLCBsYWJlbDogJ1Rob21hcyBELiBIb21hbicsIGNhdGVnb3J5OiAnY29yZScgfSxcbl07XG5cbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXG5leHBvcnQgY29uc3QgVFdFRVRfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbiAgJ0xpa2VzJyxcbiAgJ0Jvb2ttYXJrcycsXG4gICdIb21lVGltZWxpbmUnLFxuICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcbiAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXG5dKTtcblxuLy8gRW5kcG9pbnRzIHRoYXQgY2FycnkgQ29tbXVuaXR5IE5vdGUgYm9kaWVzIFx1MjAxNCBjYXB0dXJlZCBmb3IgY29tcGxldGVuZXNzIGJ1dFxuLy8gdGhleSBkb24ndCBpbnRyb2R1Y2UgbmV3IHR3ZWV0cywgc28gdGhleSBkb24ndCBuZWVkIHRvIGJlIGluIFRXRUVUX0VORFBPSU5UUy5cbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdCaXJkd2F0Y2hGZXRjaE9uZU5vdGUnLFxuICAnQmlyZHdhdGNoRmV0Y2hOb3RlcycsXG5dKTtcblxuLy8gQXV4aWxpYXJ5IGVuZHBvaW50cyB3ZSBkb24ndCBleHRyYWN0IHR3ZWV0cyBmcm9tIGJ1dCB1c2UgZm9yIGNvbnRleHQgKGUuZy4sXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxuZXhwb3J0IGNvbnN0IFBST0ZJTEVfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJCeVNjcmVlbk5hbWUnLCAnVXNlckJ5UmVzdElkJ10pO1xuXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3Jcbi8vIGNvbnZlcnNhdGlvbiBcdTIwMTQgaS5lLiB2aXNpdGluZyBgLzxoYW5kbGU+YCAvIGAvPGhhbmRsZT4vd2l0aF9yZXBsaWVzYCxcbi8vIGxvb2tpbmcgYXQgb25lIHR3ZWV0LCBldGMuIEV2ZXJ5IHR3ZWV0IHJldHVybmVkIGJ5IHRoZXNlIGVuZHBvaW50cyBpc1xuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXG4vLyAocmV0d2VldGVkLCBxdW90ZWQsIHJlcGxpZWQgdG8pLCBzbyB3ZSBrZWVwIGV2ZXJ5dGhpbmcgd2Ugc2VlIHJhdGhlclxuLy8gdGhhbiBkcm9wcGluZyBub24tdHJhY2tlZCBhdXRob3JzLiBUaGF0IHdheSBhIHJldHdlZXQgb2YgYSBub24tdHJhY2tlZFxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxuLy9cbi8vIEVuZHBvaW50cyBOT1QgaW4gdGhpcyBzZXQgKEhvbWVUaW1lbGluZSwgU2VhcmNoVGltZWxpbmUsIExpa2VzLCBldGMuKVxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXG4vLyBcIkJyb3dzaW5nIG15IGhvbWUgdGltZWxpbmUgaXMgaWdub3JlZFwiIHJ1bGUuXG5leHBvcnQgY29uc3QgVVNFUl9QQUdFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG5dKTtcblxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xuXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcblxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XG5cbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcblxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XG5cbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xuIiwgIi8qKlxuICogc2lkZWJhci50cyBcdTIwMTQgVUkgZm9yIHRoZSBwZXJzaXN0ZW50IHNpZGViYXIuXG4gKlxuICogU2lkZWJhcnMgaW4gRmlyZWZveCBzdGF5IG9wZW4gYWNyb3NzIHRhYi93aW5kb3cgc3dpdGNoZXMsIHdoaWNoIGlzIHRoZVxuICogaW50ZW5kZWQgcGVyc2lzdGVuY2UgbW9kZWwuIFRoaXMgbW9kdWxlIHJlbmRlcnMgc3RhdGUgcHVzaGVkIGZyb20gdGhlXG4gKiBiYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyIGFuZCBmb3J3YXJkcyB1c2VyIGNvbW1hbmRzIGJhY2suXG4gKi9cblxuaW1wb3J0IHsgQUNUSVZJVFlfVEFJTF9NQVggfSBmcm9tICcuL2xpYi9jb25maWcuanMnO1xuaW1wb3J0IHR5cGUgeyBFeHRlbnNpb25TdGF0ZSwgTG9nRXZlbnQsIFJ1bnRpbWVNZXNzYWdlLCBUd2VldFNpZ2h0aW5nIH0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xuXG5jb25zdCAkID0gPFQgZXh0ZW5kcyBIVE1MRWxlbWVudCA9IEhUTUxFbGVtZW50PihpZDogc3RyaW5nKTogVCA9PiB7XG4gIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xuICBpZiAoIWVsKSB0aHJvdyBuZXcgRXJyb3IoYG1pc3NpbmcgZWxlbWVudCAjJHtpZH1gKTtcbiAgcmV0dXJuIGVsIGFzIFQ7XG59O1xuXG5jb25zdCBjb25uRG90ID0gJCgnY29ubi1kb3QnKTtcbmNvbnN0IGNvbm5UZXh0ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdjb25uLXRleHQnKTtcbmNvbnN0IGFjY291bnRMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWNjb3VudC1saXN0Jyk7XG5jb25zdCByZWNlbnRUd2VldExpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdyZWNlbnQtdHdlZXQtbGlzdCcpO1xuY29uc3QgYWN0aXZpdHlMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWN0aXZpdHktbGlzdCcpO1xuY29uc3QgYXV0b1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tY2FwdHVyZScpO1xuY29uc3QgdXBkYXRlRXhpc3RpbmdUb2dnbGUgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCd1cGRhdGUtZXhpc3RpbmcnKTtcbmNvbnN0IGNhcHR1cmVBbGxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2FwdHVyZS1hbGwnKTtcbmNvbnN0IGNhcHR1cmVUaGlzQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtdGhpcycpO1xuY29uc3QgZmx1c2hCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignZmx1c2gtYWxsJyk7XG5jb25zdCBvcHRpb25zTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdvcGVuLW9wdGlvbnMnKTtcbmNvbnN0IHZpZXdlckxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi12aWV3ZXInKTtcbmNvbnN0IGNsZWFyQWN0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NsZWFyLWFjdGl2aXR5Jyk7XG5jb25zdCBleHRWZXJzaW9uRWwgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2V4dC12ZXJzaW9uJyk7XG5jb25zdCBtYXN0ZXJTd2l0Y2ggPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdtYXN0ZXItc3dpdGNoJyk7XG5jb25zdCBtYXN0ZXJMYWJlbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWFzdGVyLWxhYmVsJyk7XG5jb25zdCBhdXRvU2Nyb2xsSW50ZXJ2YWwgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1pbnRlcnZhbCcpO1xuY29uc3QgYXV0b1Njcm9sbFNlY3NFbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc2VjcycpO1xuY29uc3QgYXV0b1Njcm9sbFN0YXR1cyA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc3RhdHVzJyk7XG5jb25zdCBhdXRvU2Nyb2xsU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtc3RhcnQnKTtcbmNvbnN0IGF1dG9TY3JvbGxDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtY2FuY2VsJyk7XG5jb25zdCBhdXRvU2Nyb2xsUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXByb2dyZXNzJyk7XG5jb25zdCByZWZldGNoU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCdyZWZldGNoLXNlY3Rpb24nKTtcbmNvbnN0IHJlZmV0Y2hDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1jb3VudCcpO1xuY29uc3QgcmVmZXRjaFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZmV0Y2gtc3RhcnQnKTtcbmNvbnN0IHJlZmV0Y2hDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1jYW5jZWwnKTtcbmNvbnN0IHJlZmV0Y2hQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1wcm9ncmVzcycpO1xuY29uc3QgbWVkaWFDcmF3bFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PignbWVkaWEtY3Jhd2wtc2VjdGlvbicpO1xuY29uc3QgbWVkaWFDcmF3bENvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1jb3VudCcpO1xuY29uc3QgbWVkaWFDcmF3bFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLXN0YXJ0Jyk7XG5jb25zdCBtZWRpYUNyYXdsQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLWNhbmNlbCcpO1xuY29uc3QgbWVkaWFDcmF3bFByb2dyZXNzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1wcm9ncmVzcycpO1xuY29uc3QgdGhyZWFkT3BlblNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PigndGhyZWFkLW9wZW4tc2VjdGlvbicpO1xuY29uc3QgdGhyZWFkT3BlbkNvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCd0aHJlYWQtb3Blbi1jb3VudCcpO1xuY29uc3QgdGhyZWFkT3BlblN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3RocmVhZC1vcGVuLXN0YXJ0Jyk7XG5jb25zdCB0aHJlYWRPcGVuQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3RocmVhZC1vcGVuLWNhbmNlbCcpO1xuY29uc3QgdGhyZWFkT3BlblByb2dyZXNzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCd0aHJlYWQtb3Blbi1wcm9ncmVzcycpO1xuY29uc3QgcHVyZ2VMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ3B1cmdlLXVucmVsYXRlZCcpO1xuXG5sZXQgbGFzdFN0YXRlOiBFeHRlbnNpb25TdGF0ZSB8IG51bGwgPSBudWxsO1xuXG5hc3luYyBmdW5jdGlvbiBzZW5kPFQ+KG1zZzogUnVudGltZU1lc3NhZ2UpOiBQcm9taXNlPFQ+IHtcbiAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZShtc2cpIGFzIFByb21pc2U8VD47XG59XG5cbmZ1bmN0aW9uIHNldENvbm5TdGF0dXMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHsgY29ubmVjdGlvbiwgc2V0dGluZ3MgfSA9IHN0YXRlO1xuICBsZXQgY2xzID0gJyc7XG4gIGxldCB0ZXh0ID0gJyc7XG4gIC8vIE9ubHkgd2FybiB3aGVuIHRoZSBjb25maWd1cmVkIGJyYW5jaCBnZW51aW5lbHkgZG9lc24ndCBleGlzdCBvbiB0aGVcbiAgLy8gcmVtb3RlLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCB0aGF0IGV4aXN0cyBpcyBmaW5lIFx1MjAxNCBjYXB0dXJpbmcgaW50byBhXG4gIC8vIHdvcmtpbmcgYnJhbmNoIGlzIHJvdXRpbmUgXHUyMDE0IHNvIHRoZSBtZXJlIGAhPT1gIHRvIGRlZmF1bHRfYnJhbmNoIGlzIG5vdFxuICAvLyBhIHByb2JsZW0gYW5kIHNob3VsZG4ndCBzaG91dCBpbiB0aGUgaGVhZGVyLlxuICBjb25zdCBicmFuY2hNaXNzaW5nID1cbiAgICBjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ29rJyAmJiBzZXR0aW5ncy5icmFuY2ggJiYgY29ubmVjdGlvbi5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSBmYWxzZTtcbiAgaWYgKCFzZXR0aW5ncy5wYXRTZXQpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XG4gIH0gZWxzZSBpZiAoYnJhbmNoTWlzc2luZykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSBgQnJhbmNoIFwiJHtzZXR0aW5ncy5icmFuY2h9XCIgZG9lcyBub3QgZXhpc3Qgb24gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTIwMTQgY29tbWl0cyB3aWxsIDQyMi4gU2V0IGJyYW5jaCB0byBcIiR7Y29ubmVjdGlvbi5kZWZhdWx0QnJhbmNoID8/ICdtYXN0ZXInfVwiIGluIFNldHRpbmdzLmA7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycpIHtcbiAgICBjbHMgPSAnb2snO1xuICAgIHRleHQgPSBgQ29ubmVjdGVkIGFzIEAke2Nvbm5lY3Rpb24ubG9naW4gPz8gJz8nfSB0byAke3NldHRpbmdzLm93bmVyfS8ke3NldHRpbmdzLnJlcG99IFx1MDBCNyBcdTIwMjYke3NldHRpbmdzLnBhdFN1ZmZpeH1gO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gaXNXcml0ZUF1dGhFcnJvcihjb25uZWN0aW9uLmVycm9yKVxuICAgICAgPyAnUEFUIGNhbiByZWFkIHJlcG8gYnV0IGNhbm5vdCB3cml0ZSAtIHNldCBDb250ZW50czogUmVhZCAmIFdyaXRlJ1xuICAgICAgOiAnQXV0aCBlcnJvciAtIGNoZWNrIHlvdXIgUEFUJztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgY29uc3QgcmVzZXRzID0gZm10UmF0ZUxpbWl0UmVzZXQoY29ubmVjdGlvbi5yYXRlTGltaXRSZXNldEF0KTtcbiAgICB0ZXh0ID0gcmVzZXRzXG4gICAgICA/IGBHaXRIdWIgcmF0ZS1saW1pdGVkIFx1MjAxNCByZXNldHMgJHtyZXNldHN9YFxuICAgICAgOiAnR2l0SHViIHJhdGUtbGltaXRlZCBcdTIwMTQgY2FwdHVyZXMgd2lsbCByZXRyeSc7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICduZXR3b3JrLWVycm9yJykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSAnTmV0d29yayBlcnJvciBcdTIwMTQgY2hlY2sgY29ubmVjdGl2aXR5JztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ25vdC1jb25maWd1cmVkJykge1xuICAgIGNscyA9ICd3YXJuJztcbiAgICB0ZXh0ID0gJ05vdCBjb25maWd1cmVkIFx1MjAxNCBvcGVuIFNldHRpbmdzJztcbiAgfSBlbHNlIHtcbiAgICBjbHMgPSAnJztcbiAgICB0ZXh0ID0gJ0NoZWNraW5nXHUyMDI2JztcbiAgfVxuICBjb25uRG90LmNsYXNzTmFtZSA9IGBkb3QgJHtjbHN9YDtcbiAgY29ublRleHQudGV4dENvbnRlbnQgPSB0ZXh0O1xuICBjb25uVGV4dC50aXRsZSA9IGNvbm5lY3Rpb24uZXJyb3IgPz8gJyc7XG59XG5cbmZ1bmN0aW9uIGZtdFJlbChpc286IHN0cmluZyB8IG51bGwpOiBzdHJpbmcge1xuICBpZiAoIWlzbykgcmV0dXJuICdcdTIwMTQnO1xuICBjb25zdCBkID0gRGF0ZS5wYXJzZShpc28pO1xuICBpZiAoIU51bWJlci5pc0Zpbml0ZShkKSkgcmV0dXJuICdcdTIwMTQnO1xuICBjb25zdCBzZWNzID0gTWF0aC5tYXgoMCwgTWF0aC5yb3VuZCgoRGF0ZS5ub3coKSAtIGQpIC8gMTAwMCkpO1xuICBpZiAoc2VjcyA8IDUpIHJldHVybiAnanVzdCBub3cnO1xuICBpZiAoc2VjcyA8IDYwKSByZXR1cm4gYCR7c2Vjc31zIGFnb2A7XG4gIGNvbnN0IG1pbnMgPSBNYXRoLnJvdW5kKHNlY3MgLyA2MCk7XG4gIGlmIChtaW5zIDwgNjApIHJldHVybiBgJHttaW5zfW0gYWdvYDtcbiAgY29uc3QgaG91cnMgPSBNYXRoLnJvdW5kKG1pbnMgLyA2MCk7XG4gIGlmIChob3VycyA8IDI0KSByZXR1cm4gYCR7aG91cnN9aCBhZ29gO1xuICBjb25zdCBkYXlzID0gTWF0aC5yb3VuZChob3VycyAvIDI0KTtcbiAgcmV0dXJuIGAke2RheXN9ZCBhZ29gO1xufVxuXG5mdW5jdGlvbiBmbXRSYXRlTGltaXRSZXNldChlcG9jaFNlYzogbnVtYmVyIHwgbnVsbCk6IHN0cmluZyB7XG4gIGlmIChlcG9jaFNlYyA9PT0gbnVsbCkgcmV0dXJuICcnO1xuICBjb25zdCBkZWx0YVNlYyA9IGVwb2NoU2VjIC0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gIGlmIChkZWx0YVNlYyA8PSAwKSByZXR1cm4gJ21vbWVudGFyaWx5JztcbiAgY29uc3Qgd2FsbENsb2NrID0gbmV3IERhdGUoZXBvY2hTZWMgKiAxMDAwKS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHtcbiAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgbWludXRlOiAnMi1kaWdpdCcsXG4gIH0pO1xuICBpZiAoZGVsdGFTZWMgPCA2MCkgcmV0dXJuIGBpbiAke2RlbHRhU2VjfXMgKCR7d2FsbENsb2NrfSlgO1xuICBjb25zdCBtaW5zID0gTWF0aC5yb3VuZChkZWx0YVNlYyAvIDYwKTtcbiAgaWYgKG1pbnMgPCA2MCkgcmV0dXJuIGBpbiAke21pbnN9bSAoJHt3YWxsQ2xvY2t9KWA7XG4gIGNvbnN0IGhvdXJzID0gTWF0aC5yb3VuZChtaW5zIC8gNjApO1xuICByZXR1cm4gYGluICR7aG91cnN9aCAoJHt3YWxsQ2xvY2t9KWA7XG59XG5cbmZ1bmN0aW9uIGZtdE51bShuOiBudW1iZXIpOiBzdHJpbmcge1xuICByZXR1cm4gbi50b0xvY2FsZVN0cmluZygnZW4tVVMnKTtcbn1cblxuZnVuY3Rpb24gaXNXcml0ZUF1dGhFcnJvcihtZXNzYWdlOiBzdHJpbmcgfCBudWxsKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnICYmXG4gICAgL1Jlc291cmNlIG5vdCBhY2Nlc3NpYmxlIGJ5IHBlcnNvbmFsIGFjY2VzcyB0b2tlbnxcXC9naXRcXC9ibG9ic3xcXC9naXRcXC9yZWZzL2kudGVzdChtZXNzYWdlKVxuICApO1xufVxuXG5mdW5jdGlvbiByZW5kZXJBY2NvdW50cyhzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgYWNjb3VudExpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChzdGF0ZS5hY2NvdW50cy5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcbiAgICBsaS50ZXh0Q29udGVudCA9ICdObyBhY2NvdW50cyBjb25maWd1cmVkLic7XG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yIChjb25zdCBhIG9mIHN0YXRlLmFjY291bnRzKSB7XG4gICAgY29uc3QgYyA9IHN0YXRlLmNvdW50ZXJzW2EuaGFuZGxlXTtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gYyAmJiBjLmJ1ZmZlcmVkQ291bnQgPiAwID8gJ2FjYyBwZW5kaW5nJyA6ICdhY2MnO1xuXG4gICAgY29uc3QgaGVhZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGhlYWQuY2xhc3NOYW1lID0gJ2FjYy1oZWFkJztcbiAgICBjb25zdCBoYW5kbGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgaGFuZGxlLmNsYXNzTmFtZSA9ICdhY2MtaGFuZGxlJztcbiAgICBoYW5kbGUuaW5uZXJIVE1MID0gYDxzcGFuIGNsYXNzPVwiYXRcIj5APC9zcGFuPiR7ZXNjYXBlSHRtbChhLmhhbmRsZSl9YDtcbiAgICBjb25zdCBtZXRhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIG1ldGEuY2xhc3NOYW1lID0gJ2FjYy1tZXRhJztcbiAgICBtZXRhLnRleHRDb250ZW50ID0gYS5sYWJlbDtcbiAgICBoZWFkLmFwcGVuZChoYW5kbGUsIG1ldGEpO1xuXG4gICAgY29uc3Qgcm93ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgcm93LmNsYXNzTmFtZSA9ICdhY2Mtcm93JztcbiAgICBjb25zdCBzdGF0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBzdGF0cy5jbGFzc05hbWUgPSAnYWNjLXN0YXRzJztcbiAgICBjb25zdCB0b2RheSA9IGM/LnRvZGF5Q291bnQgPz8gMDtcbiAgICBjb25zdCBidWZmZXJlZCA9IGM/LmJ1ZmZlcmVkQ291bnQgPz8gMDtcbiAgICBjb25zdCBsYXN0ID0gYz8ubGFzdENhcHR1cmVBdCA/PyBudWxsO1xuICAgIHN0YXRzLmlubmVySFRNTCA9XG4gICAgICBgPHNwYW4gY2xhc3M9XCJudW1cIj4ke2ZtdE51bSh0b2RheSl9PC9zcGFuPiB0b2RheWAgK1xuICAgICAgKGJ1ZmZlcmVkID4gMCA/IGAgXHUwMEI3IDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0oYnVmZmVyZWQpfTwvc3Bhbj4gYnVmZmVyZWRgIDogJycpICtcbiAgICAgIGAgXHUwMEI3IGxhc3QgJHtlc2NhcGVIdG1sKGZtdFJlbChsYXN0KSl9YDtcblxuICAgIGNvbnN0IGFjdGlvbnMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgYWN0aW9ucy5jbGFzc05hbWUgPSAnYWNjLWFjdGlvbic7XG4gICAgY29uc3QgYnRuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJyk7XG4gICAgYnRuLmNsYXNzTmFtZSA9ICdidG4nO1xuICAgIGJ0bi50ZXh0Q29udGVudCA9ICdDYXB0dXJlIG5vdyc7XG4gICAgYnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICAgICAgYnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS1ub3cnLCBoYW5kbGU6IGEuaGFuZGxlIH0pO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgYnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG4gICAgYWN0aW9ucy5hcHBlbmQoYnRuKTtcblxuICAgIHJvdy5hcHBlbmQoc3RhdHMsIGFjdGlvbnMpO1xuICAgIGxpLmFwcGVuZChoZWFkLCByb3cpO1xuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyQWN0aXZpdHkoZXZlbnRzOiBMb2dFdmVudFtdKTogdm9pZCB7XG4gIGFjdGl2aXR5TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgaWYgKGV2ZW50cy5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcbiAgICBsaS50ZXh0Q29udGVudCA9ICdObyBhY3Rpdml0eSB5ZXQuJztcbiAgICBhY3Rpdml0eUxpc3QuYXBwZW5kKGxpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yIChjb25zdCBldiBvZiBldmVudHMuc2xpY2UoMCwgQUNUSVZJVFlfVEFJTF9NQVgpKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9IGBldiAke2V2LmxldmVsfWA7XG4gICAgY29uc3QgdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgdHMuY2xhc3NOYW1lID0gJ2V2LXRzJztcbiAgICB0cy50ZXh0Q29udGVudCA9IG5ldyBEYXRlKGV2LnRzKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLVVTJywgeyBob3VyMTI6IGZhbHNlIH0pO1xuICAgIGNvbnN0IGljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgaWNvbi5jbGFzc05hbWUgPSAnZXYtaWNvbic7XG4gICAgaWNvbi50ZXh0Q29udGVudCA9IGV2LmxldmVsID09PSAnZXJyb3InID8gJ1x1MjcxNycgOiBldi5sZXZlbCA9PT0gJ3dhcm4nID8gJyEnIDogJ1x1MDBCNyc7XG4gICAgY29uc3QgYm9keSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBjb25zdCBtc2cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBtc2cuY2xhc3NOYW1lID0gJ2V2LW1zZyc7XG4gICAgbXNnLnRleHRDb250ZW50ID0gZXYubXNnO1xuICAgIGJvZHkuYXBwZW5kKG1zZyk7XG4gICAgY29uc3QgY3R4S2V5cyA9IE9iamVjdC5rZXlzKGV2LmNvbnRleHQpO1xuICAgIGlmIChjdHhLZXlzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IGN0eCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgY3R4LmNsYXNzTmFtZSA9ICdldi1jdHgnO1xuICAgICAgY3R4LnRleHRDb250ZW50ID0gY3R4S2V5cy5tYXAoKGspID0+IGAke2t9PSR7c3RyaW5naWZ5U2hvcnQoZXYuY29udGV4dFtrXSl9YCkuam9pbignIFx1MDBCNyAnKTtcbiAgICAgIGJvZHkuYXBwZW5kKGN0eCk7XG4gICAgfVxuICAgIGxpLmFwcGVuZCh0cywgaWNvbiwgYm9keSk7XG4gICAgYWN0aXZpdHlMaXN0LmFwcGVuZChsaSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc3RyaW5naWZ5U2hvcnQodjogdW5rbm93bik6IHN0cmluZyB7XG4gIGlmICh2ID09PSBudWxsKSByZXR1cm4gJ251bGwnO1xuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnKSByZXR1cm4gdi5sZW5ndGggPiA4MCA/IGAke3Yuc2xpY2UoMCwgODApfVx1MjAyNmAgOiB2O1xuICBpZiAodHlwZW9mIHYgPT09ICdudW1iZXInIHx8IHR5cGVvZiB2ID09PSAnYm9vbGVhbicpIHJldHVybiBTdHJpbmcodik7XG4gIHRyeSB7XG4gICAgY29uc3QgcyA9IEpTT04uc3RyaW5naWZ5KHYpO1xuICAgIHJldHVybiBzLmxlbmd0aCA+IDgwID8gYCR7cy5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHM7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnPyc7XG4gIH1cbn1cblxuZnVuY3Rpb24gZXNjYXBlSHRtbChzOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gcy5yZXBsYWNlKC9bJjw+XCInXS9nLCAoYykgPT5cbiAgICBjID09PSAnJicgPyAnJmFtcDsnIDogYyA9PT0gJzwnID8gJyZsdDsnIDogYyA9PT0gJz4nID8gJyZndDsnIDogYyA9PT0gJ1wiJyA/ICcmcXVvdDsnIDogJyYjMzk7J1xuICApO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoU3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgbGFzdFN0YXRlID0gYXdhaXQgc2VuZDxFeHRlbnNpb25TdGF0ZT4oeyB0eXBlOiAnZ2V0LXN0YXRlJyB9KTtcbiAgICBwYWludChsYXN0U3RhdGUpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gc2lkZWJhciByZWZyZXNoU3RhdGUgZmFpbGVkJywgZXJyKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBwYWludChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgZXh0VmVyc2lvbkVsLnRleHRDb250ZW50ID0gc3RhdGUudmVyc2lvbjtcbiAgc2V0Q29ublN0YXR1cyhzdGF0ZSk7XG4gIGF1dG9Ub2dnbGUuY2hlY2tlZCA9IHN0YXRlLnNldHRpbmdzLmF1dG9DYXB0dXJlO1xuICB1cGRhdGVFeGlzdGluZ1RvZ2dsZS5jaGVja2VkID0gc3RhdGUuc2V0dGluZ3MudXBkYXRlRXhpc3RpbmcgIT09IGZhbHNlO1xuICB2aWV3ZXJMaW5rLmhyZWYgPSBgaHR0cHM6Ly8ke3N0YXRlLnNldHRpbmdzLm93bmVyfS5naXRodWIuaW8vJHtzdGF0ZS5zZXR0aW5ncy5yZXBvfS9gO1xuICBwYWludE1hc3RlclN3aXRjaChzdGF0ZSk7XG4gIHJlbmRlckFjY291bnRzKHN0YXRlKTtcbiAgcmVuZGVyUmVjZW50VHdlZXRzKHN0YXRlLnJlY2VudFR3ZWV0U2lnaHRpbmdzKTtcbiAgcGFpbnRBdXRvU2Nyb2xsKHN0YXRlKTtcbiAgcGFpbnRNZWRpYUNyYXdsKHN0YXRlKTtcbiAgcGFpbnRSZWZldGNoKHN0YXRlKTtcbiAgcGFpbnRUaHJlYWRPcGVuKHN0YXRlKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyUmVjZW50VHdlZXRzKHJvd3M6IFR3ZWV0U2lnaHRpbmdbXSk6IHZvaWQge1xuICByZWNlbnRUd2VldExpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xuICAgIGxpLnRleHRDb250ZW50ID0gJ05vIHR3ZWV0cyBzZWVuIHlldC4nO1xuICAgIHJlY2VudFR3ZWV0TGlzdC5hcHBlbmQobGkpO1xuICAgIHJldHVybjtcbiAgfVxuICBmb3IgKGNvbnN0IHJvdyBvZiByb3dzLnNsaWNlKDAsIDQwKSkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSBgcmVjZW50LXR3ZWV0ICR7cm93LmFyY2hpdmVfc3RhdHVzfWA7XG5cbiAgICBjb25zdCB0b3AgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICB0b3AuY2xhc3NOYW1lID0gJ3R3ZWV0LWhlYWQnO1xuICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgbGluay5jbGFzc05hbWUgPSAndHdlZXQtaGFuZGxlJztcbiAgICBsaW5rLmhyZWYgPSByb3cudHdlZXRfdXJsO1xuICAgIGxpbmsudGFyZ2V0ID0gJ19ibGFuayc7XG4gICAgbGluay5yZWwgPSAnbm9vcGVuZXInO1xuICAgIGxpbmsudGV4dENvbnRlbnQgPSBgQCR7cm93LmFjY291bnRfaGFuZGxlfWA7XG4gICAgY29uc3Qgc3RhdHVzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHN0YXR1cy5jbGFzc05hbWUgPSBgdHdlZXQtcGlsbCAke3Jvdy5hcmNoaXZlX3N0YXR1c31gO1xuICAgIHN0YXR1cy50ZXh0Q29udGVudCA9IHJvdy5hcmNoaXZlX3N0YXR1cyA9PT0gJ3NhdmVkJyA/ICdzYXZlZCcgOiAnbmV3JztcbiAgICB0b3AuYXBwZW5kKGxpbmssIHN0YXR1cyk7XG5cbiAgICBjb25zdCB0ZXh0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgdGV4dC5jbGFzc05hbWUgPSAndHdlZXQtdGV4dCc7XG4gICAgdGV4dC50ZXh0Q29udGVudCA9IHRydW5jYXRlVGV4dChyb3cudGV4dCwgMTQwKTtcblxuICAgIGNvbnN0IG1ldGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBtZXRhLmNsYXNzTmFtZSA9ICd0d2VldC1tZXRhJztcbiAgICBtZXRhLnRleHRDb250ZW50ID1cbiAgICAgIGAke2Zvcm1hdFR3ZWV0QWN0aW9uKHJvdy5hY3Rpb24pfSBcdTAwQjcgJHtyb3cudHdlZXRfdHlwZX0gXHUwMEI3IHBvc3RlZCAke2ZtdFJlbChyb3cucG9zdGVkX2F0KX1gO1xuXG4gICAgbGkuYXBwZW5kKHRvcCwgdGV4dCwgbWV0YSk7XG4gICAgcmVjZW50VHdlZXRMaXN0LmFwcGVuZChsaSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZm9ybWF0VHdlZXRBY3Rpb24oYWN0aW9uOiBUd2VldFNpZ2h0aW5nWydhY3Rpb24nXSk6IHN0cmluZyB7XG4gIGlmIChhY3Rpb24gPT09ICdidWZmZXJlZCcpIHJldHVybiAnYnVmZmVyZWQnO1xuICBpZiAoYWN0aW9uID09PSAndW5jaGFuZ2VkJykgcmV0dXJuICd1bmNoYW5nZWQnO1xuICByZXR1cm4gJ3NraXBwZWQnO1xufVxuXG5mdW5jdGlvbiB0cnVuY2F0ZVRleHQodGV4dDogc3RyaW5nLCBtYXg6IG51bWJlcik6IHN0cmluZyB7XG4gIGNvbnN0IGNvbXBhY3QgPSB0ZXh0LnJlcGxhY2UoL1xccysvZywgJyAnKS50cmltKCk7XG4gIHJldHVybiBjb21wYWN0Lmxlbmd0aCA8PSBtYXggPyBjb21wYWN0IDogYCR7Y29tcGFjdC5zbGljZSgwLCBtYXggLSAxKX1cdTIwMjZgO1xufVxuXG5mdW5jdGlvbiBwYWludE1lZGlhQ3Jhd2woc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHEgPSBzdGF0ZS5tZWRpYUNyYXdsUXVldWU7XG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcbiAgY29uc3QgcnVubmluZyA9IHEucnVubmluZztcbiAgbWVkaWFDcmF3bFNlY3Rpb24uaGlkZGVuID0gdG90YWwgPT09IDAgJiYgIXJ1bm5pbmc7XG4gIG1lZGlhQ3Jhd2xDb3VudC50ZXh0Q29udGVudCA9XG4gICAgdG90YWwgPT09IDBcbiAgICAgID8gcnVubmluZ1xuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXG4gICAgICAgIDogJzAgcXVldWVkJ1xuICAgICAgOiBgJHtmbXROdW0odG90YWwpfSBxdWV1ZWQke3J1bm5pbmcgPyAnIFx1MDBCNyBydW5uaW5nJyA6ICcnfWA7XG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcbiAgbWVkaWFDcmF3bENhbmNlbEJ0bi5oaWRkZW4gPSAhcnVubmluZztcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKG1lZGlhQ3Jhd2xQcm9ncmVzcywgcSk7XG59XG5cbmZ1bmN0aW9uIHBhaW50UXVldWVQcm9ncmVzcyhcbiAgZWw6IEhUTUxTcGFuRWxlbWVudCxcbiAgcTogeyBwcm9jZXNzZWQ6IG51bWJlcjsgdG90YWxfYXRfc3RhcnQ6IG51bWJlcjsgcnVubmluZzogYm9vbGVhbjsgdG90YWw6IG51bWJlciB9XG4pOiB2b2lkIHtcbiAgaWYgKCFxLnJ1bm5pbmcgJiYgcS5wcm9jZXNzZWQgPT09IDApIHtcbiAgICBlbC5oaWRkZW4gPSB0cnVlO1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBEZW5vbWluYXRvcjogbWF4IG9mIGluaXRpYWwgdG90YWwgYW5kIGN1cnJlbnQgcHJvY2Vzc2VkK3JlbWFpbmluZyBzbyB0aGVcbiAgLy8gYmFyIHN0aWxsIG1ha2VzIHNlbnNlIGlmIG5ldyBlbnRyaWVzIHdlcmUgZW5xdWV1ZWQgbWlkLXJ1bi5cbiAgY29uc3QgZGVub20gPSBNYXRoLm1heChxLnRvdGFsX2F0X3N0YXJ0LCBxLnByb2Nlc3NlZCArIHEudG90YWwpO1xuICBlbC5oaWRkZW4gPSBmYWxzZTtcbiAgZWwudGV4dENvbnRlbnQgPSBgJHtmbXROdW0ocS5wcm9jZXNzZWQpfSAvICR7Zm10TnVtKGRlbm9tKX0gcHJvY2Vzc2VkYDtcbiAgZWwuY2xhc3NOYW1lID0gcS5ydW5uaW5nID8gJ3Byb2dyZXNzIG9uJyA6ICdwcm9ncmVzcyc7XG59XG5cbmZ1bmN0aW9uIHBhaW50TWFzdGVyU3dpdGNoKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBvbiA9IHN0YXRlLnNldHRpbmdzLmVuYWJsZWQgIT09IGZhbHNlO1xuICBtYXN0ZXJTd2l0Y2guY2hlY2tlZCA9IG9uO1xuICBtYXN0ZXJMYWJlbC50ZXh0Q29udGVudCA9IG9uID8gJ09OJyA6ICdQQVVTRUQnO1xuICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC50b2dnbGUoJ3BhdXNlZCcsICFvbik7XG59XG5cbmZ1bmN0aW9uIHBhaW50QXV0b1Njcm9sbChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3Qgc2VjcyA9IHN0YXRlLnNldHRpbmdzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYztcbiAgYXV0b1Njcm9sbEludGVydmFsLnZhbHVlID0gU3RyaW5nKHNlY3MpO1xuICBhdXRvU2Nyb2xsU2Vjc0VsLnRleHRDb250ZW50ID0gU3RyaW5nKHNlY3MpO1xuICBjb25zdCBhcyA9IHN0YXRlLmF1dG9TY3JvbGw7XG4gIGF1dG9TY3JvbGxTdGFydEJ0bi5oaWRkZW4gPSBhcy5hY3RpdmU7XG4gIGF1dG9TY3JvbGxDYW5jZWxCdG4uaGlkZGVuID0gIWFzLmFjdGl2ZTtcbiAgaWYgKGFzLmFjdGl2ZSkge1xuICAgIGNvbnN0IG4gPSBhcy50YWJDb3VudDtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLnRleHRDb250ZW50ID1cbiAgICAgIG4gPT09IDAgPyBgcnVubmluZyBcdTIwMTQgbm8gWCB0YWJzIG9wZW5gIDogYHJ1bm5pbmcgXHUyMDE0ICR7bn0gJHtuID09PSAxID8gJ3RhYicgOiAndGFicyd9YDtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLmNsYXNzTmFtZSA9ICdtdXRlZCBvbic7XG4gIH0gZWxzZSB7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9ICdpZGxlJztcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLmNsYXNzTmFtZSA9ICdtdXRlZCc7XG4gIH1cbiAgaWYgKGFzLmFjdGl2ZSB8fCBhcy5zY3JvbGxDb3VudCA+IDAgfHwgYXMuaW5nZXN0ZWRDb3VudCA+IDApIHtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuaGlkZGVuID0gZmFsc2U7XG4gICAgY29uc3QgcGFydHMgPSBbXG4gICAgICBgJHtmbXROdW0oYXMuc2Nyb2xsQ291bnQpfSBzY3JvbGxzYCxcbiAgICAgIGAke2ZtdE51bShhcy5pbmdlc3RlZE5ld0NvdW50KX0gbmV3IGJ1ZmZlcmVkYCxcbiAgICAgIGAke2ZtdE51bShhcy5pbmdlc3RlZEV4aXN0aW5nQ291bnQpfSBvbGQgYnVmZmVyZWRgLFxuICAgIF07XG4gICAgaWYgKGFzLnNraXBwZWRPbGRDb3VudCA+IDApIHBhcnRzLnB1c2goYCR7Zm10TnVtKGFzLnNraXBwZWRPbGRDb3VudCl9IG9sZCBza2lwcGVkYCk7XG4gICAgcGFydHMucHVzaChgJHtmbXROdW0oYXMuZXhwYW5kZWRDb3VudCl9IGV4cGFuZGVkYCk7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLnRleHRDb250ZW50ID0gcGFydHMuam9pbignIFx1MDBCNyAnKTtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuY2xhc3NOYW1lID0gYXMuYWN0aXZlID8gJ3Byb2dyZXNzIG9uJyA6ICdwcm9ncmVzcyc7XG4gIH0gZWxzZSB7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmhpZGRlbiA9IHRydWU7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGFpbnRSZWZldGNoKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBxID0gc3RhdGUucmVmZXRjaFF1ZXVlO1xuICBjb25zdCB0b3RhbCA9IHEudG90YWw7XG4gIGNvbnN0IHJ1bm5pbmcgPSBxLnJ1bm5pbmc7XG4gIHJlZmV0Y2hTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xuICByZWZldGNoQ291bnQudGV4dENvbnRlbnQgPVxuICAgIHRvdGFsID09PSAwXG4gICAgICA/IHJ1bm5pbmdcbiAgICAgICAgPyAnZmluaXNoaW5nXHUyMDI2J1xuICAgICAgICA6ICcwIHF1ZXVlZCdcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xuICByZWZldGNoU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcbiAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gdG90YWwgPT09IDA7XG4gIHJlZmV0Y2hDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XG4gIHBhaW50UXVldWVQcm9ncmVzcyhyZWZldGNoUHJvZ3Jlc3MsIHEpO1xufVxuXG5mdW5jdGlvbiBwYWludFRocmVhZE9wZW4oc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHEgPSBzdGF0ZS50aHJlYWRPcGVuUXVldWU7XG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcbiAgY29uc3QgcnVubmluZyA9IHEucnVubmluZztcbiAgdGhyZWFkT3BlblNlY3Rpb24uaGlkZGVuID0gdG90YWwgPT09IDAgJiYgIXJ1bm5pbmc7XG4gIHRocmVhZE9wZW5Db3VudC50ZXh0Q29udGVudCA9XG4gICAgdG90YWwgPT09IDBcbiAgICAgID8gcnVubmluZ1xuICAgICAgICA/ICdmaW5pc2hpbmcuLi4nXG4gICAgICAgIDogJzAgcXVldWVkJ1xuICAgICAgOiBgJHtmbXROdW0odG90YWwpfSBxdWV1ZWQke3J1bm5pbmcgPyAnIFx1MDBCNyBydW5uaW5nJyA6ICcnfWA7XG4gIHRocmVhZE9wZW5TdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xuICB0aHJlYWRPcGVuU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcbiAgdGhyZWFkT3BlbkNhbmNlbEJ0bi5oaWRkZW4gPSAhcnVubmluZztcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKHRocmVhZE9wZW5Qcm9ncmVzcywgcSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hBY3Rpdml0eSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gUHVsbCBzdHJhaWdodCBmcm9tIHN0b3JhZ2Ugb24gZmlyc3QgcmVuZGVyOyBsaXZlIHVwZGF0ZXMgY29tZSB2aWFcbiAgLy8gYGxvZy1ldmVudGAgYnJvYWRjYXN0cy5cbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldCgnYWN0aXZpdHknKTtcbiAgY29uc3QgZXZlbnRzID0gKHN0b3JlZC5hY3Rpdml0eSBhcyBMb2dFdmVudFtdIHwgdW5kZWZpbmVkKSA/PyBbXTtcbiAgcmVuZGVyQWN0aXZpdHkoZXZlbnRzKTtcbn1cblxuLy8gLS0tIFdpcmUgdXAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuY2FwdHVyZUFsbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgY2FwdHVyZUFsbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjYXB0dXJlLWFsbCcgfSk7XG4gIH0gZmluYWxseSB7XG4gICAgY2FwdHVyZUFsbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuY2FwdHVyZVRoaXNCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGNhcHR1cmVUaGlzQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtdGhpcy1wYWdlJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjYXB0dXJlVGhpc0J0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuZmx1c2hCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGZsdXNoQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2ZsdXNoLWFsbCcgfSk7XG4gIH0gZmluYWxseSB7XG4gICAgZmx1c2hCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfVxufSk7XG5cbmF1dG9Ub2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLWF1dG8tY2FwdHVyZScsIG9uOiBhdXRvVG9nZ2xlLmNoZWNrZWQgfSk7XG59KTtcblxudXBkYXRlRXhpc3RpbmdUb2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLXVwZGF0ZS1leGlzdGluZycsIG9uOiB1cGRhdGVFeGlzdGluZ1RvZ2dsZS5jaGVja2VkIH0pO1xufSk7XG5cbm1hc3RlclN3aXRjaC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtZW5hYmxlZCcsIG9uOiBtYXN0ZXJTd2l0Y2guY2hlY2tlZCB9KTtcbn0pO1xuXG5hdXRvU2Nyb2xsU3RhcnRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGF1dG9TY3JvbGxTdGFydEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC1hdXRvLXNjcm9sbCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgYXV0b1Njcm9sbFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5hdXRvU2Nyb2xsQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1hdXRvLXNjcm9sbCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgYXV0b1Njcm9sbENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5hdXRvU2Nyb2xsSW50ZXJ2YWwuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLCAoKSA9PiB7XG4gIGF1dG9TY3JvbGxTZWNzRWwudGV4dENvbnRlbnQgPSBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWU7XG59KTtcbmF1dG9TY3JvbGxJbnRlcnZhbC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIGNvbnN0IHNlY29uZHMgPSBOdW1iZXIoYXV0b1Njcm9sbEludGVydmFsLnZhbHVlKTtcbiAgaWYgKE51bWJlci5pc0Zpbml0ZShzZWNvbmRzKSkge1xuICAgIHZvaWQgc2VuZCh7IHR5cGU6ICdzZXQtYXV0by1zY3JvbGwtaW50ZXJ2YWwnLCBzZWNvbmRzIH0pO1xuICB9XG59KTtcblxucHVyZ2VMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKTtcbiAgY29uc3Qgb2sgPSB3aW5kb3cuY29uZmlybShcbiAgICAnRHJvcCBldmVyeSBjb3VudGVyLCBydW4gYnVmZmVyLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgLyB0aHJlYWQtb3BlbmluZyBxdWV1ZSBlbnRyeSBmb3IgYWNjb3VudHMgbm90IGluIHlvdXIgdHJhY2tlZCBsaXN0P1xcblxcbicgK1xuICAgICAgJ1RoaXMgb25seSB0b3VjaGVzIGxvY2FsIGV4dGVuc2lvbiBzdGF0ZS4gQWxyZWFkeS1jb21taXR0ZWQgZmlsZXMgaW4gdGhlIEdpdEh1YiByZXBvIGFyZSBub3QgYWZmZWN0ZWQgXHUyMDE0ICcgK1xuICAgICAgJ3J1biBzY3JpcHRzL3B1cmdlX3VucmVsYXRlZC5weSBzZXBhcmF0ZWx5IGlmIHlvdSBhbHNvIHdhbnQgdG8gc2NydWIgdGhlIHJlcG8uJ1xuICApO1xuICBpZiAoIW9rKSByZXR1cm47XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdwdXJnZS11bnJlbGF0ZWQnIH0pO1xufSk7XG5cbnJlZmV0Y2hTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5yZWZldGNoQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1yZWZldGNoJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbm1lZGlhQ3Jhd2xTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LW1lZGlhLWNyYXdsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxubWVkaWFDcmF3bENhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxudGhyZWFkT3BlblN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICB0aHJlYWRPcGVuU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtdGhyZWFkLW9wZW4nIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHRocmVhZE9wZW5TdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG50aHJlYWRPcGVuQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICB0aHJlYWRPcGVuQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC10aHJlYWQtb3BlbicgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgdGhyZWFkT3BlbkNhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5vcHRpb25zTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdvcGVuLW9wdGlvbnMnIH0pO1xufSk7XG5cbnZpZXdlckxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnb3Blbi12aWV3ZXInIH0pO1xufSk7XG5cbmNsZWFyQWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NsZWFyLWFjdGl2aXR5JyB9KTtcbiAgcmVuZGVyQWN0aXZpdHkoW10pO1xufSk7XG5cbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93bikgPT4ge1xuICBpZiAoIW1zZyB8fCB0eXBlb2YgbXNnICE9PSAnb2JqZWN0JykgcmV0dXJuO1xuICBjb25zdCBtID0gbXNnIGFzIHsgdHlwZT86IHN0cmluZzsgc3RhdGU/OiBFeHRlbnNpb25TdGF0ZTsgZXZlbnQ/OiBMb2dFdmVudCB9O1xuICBpZiAobS50eXBlID09PSAnc3RhdGUtY2hhbmdlZCcgJiYgbS5zdGF0ZSkge1xuICAgIGxhc3RTdGF0ZSA9IG0uc3RhdGU7XG4gICAgcGFpbnQobS5zdGF0ZSk7XG4gIH0gZWxzZSBpZiAobS50eXBlID09PSAnbG9nLWV2ZW50JyAmJiBtLmV2ZW50KSB7XG4gICAgcHJlcGVuZEV2ZW50KG0uZXZlbnQpO1xuICB9XG59KTtcblxuZnVuY3Rpb24gcHJlcGVuZEV2ZW50KGV2OiBMb2dFdmVudCk6IHZvaWQge1xuICAvLyBJZiB0aGUgbGlzdCBpcyBzaG93aW5nIHRoZSBcImVtcHR5XCIgcGxhY2Vob2xkZXIsIGNsZWFyIGl0LlxuICBpZiAoYWN0aXZpdHlMaXN0LmZpcnN0RWxlbWVudENoaWxkPy5jbGFzc0xpc3QuY29udGFpbnMoJ2VtcHR5JykpIHtcbiAgICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIH1cbiAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xuICBjb25zdCB0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgdHMuY2xhc3NOYW1lID0gJ2V2LXRzJztcbiAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcbiAgY29uc3QgaWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgaWNvbi5jbGFzc05hbWUgPSAnZXYtaWNvbic7XG4gIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xuICBjb25zdCBib2R5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBjb25zdCBtc2cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xuICBtc2cudGV4dENvbnRlbnQgPSBldi5tc2c7XG4gIGJvZHkuYXBwZW5kKG1zZyk7XG4gIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcbiAgaWYgKGN0eEtleXMubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGN0eCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcbiAgICBjdHgudGV4dENvbnRlbnQgPSBjdHhLZXlzLm1hcCgoaykgPT4gYCR7a309JHtzdHJpbmdpZnlTaG9ydChldi5jb250ZXh0W2tdKX1gKS5qb2luKCcgXHUwMEI3ICcpO1xuICAgIGJvZHkuYXBwZW5kKGN0eCk7XG4gIH1cbiAgbGkuYXBwZW5kKHRzLCBpY29uLCBib2R5KTtcbiAgYWN0aXZpdHlMaXN0LnByZXBlbmQobGkpO1xuICB3aGlsZSAoYWN0aXZpdHlMaXN0LmNoaWxkRWxlbWVudENvdW50ID4gQUNUSVZJVFlfVEFJTF9NQVgpIHtcbiAgICBhY3Rpdml0eUxpc3QubGFzdEVsZW1lbnRDaGlsZD8ucmVtb3ZlKCk7XG4gIH1cbn1cblxuLy8gSW5pdGlhbCBwYWludC5cbnZvaWQgcmVmcmVzaFN0YXRlKCk7XG52b2lkIHJlZnJlc2hBY3Rpdml0eSgpO1xuXG4vLyBQZXJpb2RpY2FsbHkgcmUtZmV0Y2ggc3RhdGUgc28gXCJsYXN0IGNhcHR1cmVcIiB0aW1lcyBzdGF5IGZyZXNoLlxuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICB2b2lkIHJlZnJlc2hTdGF0ZSgpO1xufSwgMTVfMDAwKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7QUE2Rk8sSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLOzs7QUNyRnZELElBQU0sSUFBSSxDQUFzQyxPQUFrQjtBQUNoRSxRQUFNLEtBQUssU0FBUyxlQUFlLEVBQUU7QUFDckMsTUFBSSxDQUFDLEdBQUksT0FBTSxJQUFJLE1BQU0sb0JBQW9CLEVBQUUsRUFBRTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxJQUFNLFVBQVUsRUFBRSxVQUFVO0FBQzVCLElBQU0sV0FBVyxFQUFtQixXQUFXO0FBQy9DLElBQU0sY0FBYyxFQUFvQixjQUFjO0FBQ3RELElBQU0sa0JBQWtCLEVBQW9CLG1CQUFtQjtBQUMvRCxJQUFNLGVBQWUsRUFBb0IsZUFBZTtBQUN4RCxJQUFNLGFBQWEsRUFBb0IsY0FBYztBQUNyRCxJQUFNLHVCQUF1QixFQUFvQixpQkFBaUI7QUFDbEUsSUFBTSxnQkFBZ0IsRUFBcUIsYUFBYTtBQUN4RCxJQUFNLGlCQUFpQixFQUFxQixjQUFjO0FBQzFELElBQU0sV0FBVyxFQUFxQixXQUFXO0FBQ2pELElBQU0sY0FBYyxFQUFxQixjQUFjO0FBQ3ZELElBQU0sYUFBYSxFQUFxQixhQUFhO0FBQ3JELElBQU0sY0FBYyxFQUFxQixnQkFBZ0I7QUFDekQsSUFBTSxlQUFlLEVBQW1CLGFBQWE7QUFDckQsSUFBTSxlQUFlLEVBQW9CLGVBQWU7QUFDeEQsSUFBTSxjQUFjLEVBQW1CLGNBQWM7QUFDckQsSUFBTSxxQkFBcUIsRUFBb0Isc0JBQXNCO0FBQ3JFLElBQU0sbUJBQW1CLEVBQW1CLGtCQUFrQjtBQUM5RCxJQUFNLG1CQUFtQixFQUFtQixvQkFBb0I7QUFDaEUsSUFBTSxxQkFBcUIsRUFBcUIsbUJBQW1CO0FBQ25FLElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLHFCQUFxQixFQUFtQixzQkFBc0I7QUFDcEUsSUFBTSxpQkFBaUIsRUFBZSxpQkFBaUI7QUFDdkQsSUFBTSxlQUFlLEVBQW1CLGVBQWU7QUFDdkQsSUFBTSxrQkFBa0IsRUFBcUIsZUFBZTtBQUM1RCxJQUFNLG1CQUFtQixFQUFxQixnQkFBZ0I7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsa0JBQWtCO0FBQzdELElBQU0sb0JBQW9CLEVBQWUscUJBQXFCO0FBQzlELElBQU0sa0JBQWtCLEVBQW1CLG1CQUFtQjtBQUM5RCxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLG9CQUFvQixFQUFlLHFCQUFxQjtBQUM5RCxJQUFNLGtCQUFrQixFQUFtQixtQkFBbUI7QUFDOUQsSUFBTSxxQkFBcUIsRUFBcUIsbUJBQW1CO0FBQ25FLElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLHFCQUFxQixFQUFtQixzQkFBc0I7QUFDcEUsSUFBTSxZQUFZLEVBQXFCLGlCQUFpQjtBQUV4RCxJQUFJLFlBQW1DO0FBRXZDLGVBQWUsS0FBUSxLQUFpQztBQUN0RCxTQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDeEM7QUFFQSxTQUFTLGNBQWMsT0FBNkI7QUFDbEQsUUFBTSxFQUFFLFlBQVksU0FBUyxJQUFJO0FBQ2pDLE1BQUksTUFBTTtBQUNWLE1BQUksT0FBTztBQUtYLFFBQU0sZ0JBQ0osV0FBVyxXQUFXLFFBQVEsU0FBUyxVQUFVLFdBQVcsMkJBQTJCO0FBQ3pGLE1BQUksQ0FBQyxTQUFTLFFBQVE7QUFDcEIsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsZUFBZTtBQUN4QixVQUFNO0FBQ04sV0FBTyxXQUFXLFNBQVMsTUFBTSx1QkFBdUIsU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLDRDQUF1QyxXQUFXLGlCQUFpQixRQUFRO0FBQUEsRUFDcEssV0FBVyxXQUFXLFdBQVcsTUFBTTtBQUNyQyxVQUFNO0FBQ04sV0FBTyxpQkFBaUIsV0FBVyxTQUFTLEdBQUcsT0FBTyxTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksZUFBTyxTQUFTLFNBQVM7QUFBQSxFQUNoSCxXQUFXLFdBQVcsV0FBVyxjQUFjO0FBQzdDLFVBQU07QUFDTixXQUFPLGlCQUFpQixXQUFXLEtBQUssSUFDcEMsb0VBQ0E7QUFBQSxFQUNOLFdBQVcsV0FBVyxXQUFXLGdCQUFnQjtBQUMvQyxVQUFNO0FBQ04sVUFBTSxTQUFTLGtCQUFrQixXQUFXLGdCQUFnQjtBQUM1RCxXQUFPLFNBQ0gscUNBQWdDLE1BQU0sS0FDdEM7QUFBQSxFQUNOLFdBQVcsV0FBVyxXQUFXLGlCQUFpQjtBQUNoRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxXQUFXLFdBQVcsa0JBQWtCO0FBQ2pELFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxPQUFPO0FBQ0wsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0EsVUFBUSxZQUFZLE9BQU8sR0FBRztBQUM5QixXQUFTLGNBQWM7QUFDdkIsV0FBUyxRQUFRLFdBQVcsU0FBUztBQUN2QztBQUVBLFNBQVMsT0FBTyxLQUE0QjtBQUMxQyxNQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLFFBQU0sSUFBSSxLQUFLLE1BQU0sR0FBRztBQUN4QixNQUFJLENBQUMsT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ2hDLFFBQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxHQUFJLENBQUM7QUFDNUQsTUFBSSxPQUFPLEVBQUcsUUFBTztBQUNyQixNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNqQyxNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxNQUFJLFFBQVEsR0FBSSxRQUFPLEdBQUcsS0FBSztBQUMvQixRQUFNLE9BQU8sS0FBSyxNQUFNLFFBQVEsRUFBRTtBQUNsQyxTQUFPLEdBQUcsSUFBSTtBQUNoQjtBQUVBLFNBQVMsa0JBQWtCLFVBQWlDO0FBQzFELE1BQUksYUFBYSxLQUFNLFFBQU87QUFDOUIsUUFBTSxXQUFXLFdBQVcsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDeEQsTUFBSSxZQUFZLEVBQUcsUUFBTztBQUMxQixRQUFNLFlBQVksSUFBSSxLQUFLLFdBQVcsR0FBSSxFQUFFLG1CQUFtQixDQUFDLEdBQUc7QUFBQSxJQUNqRSxNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsRUFDVixDQUFDO0FBQ0QsTUFBSSxXQUFXLEdBQUksUUFBTyxNQUFNLFFBQVEsTUFBTSxTQUFTO0FBQ3ZELFFBQU0sT0FBTyxLQUFLLE1BQU0sV0FBVyxFQUFFO0FBQ3JDLE1BQUksT0FBTyxHQUFJLFFBQU8sTUFBTSxJQUFJLE1BQU0sU0FBUztBQUMvQyxRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxTQUFPLE1BQU0sS0FBSyxNQUFNLFNBQVM7QUFDbkM7QUFFQSxTQUFTLE9BQU8sR0FBbUI7QUFDakMsU0FBTyxFQUFFLGVBQWUsT0FBTztBQUNqQztBQUVBLFNBQVMsaUJBQWlCLFNBQWlDO0FBQ3pELFNBQ0UsT0FBTyxZQUFZLFlBQ25CLDZFQUE2RSxLQUFLLE9BQU87QUFFN0Y7QUFFQSxTQUFTLGVBQWUsT0FBNkI7QUFDbkQsY0FBWSxnQkFBZ0I7QUFDNUIsTUFBSSxNQUFNLFNBQVMsV0FBVyxHQUFHO0FBQy9CLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsZ0JBQVksT0FBTyxFQUFFO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLGFBQVcsS0FBSyxNQUFNLFVBQVU7QUFDOUIsVUFBTSxJQUFJLE1BQU0sU0FBUyxFQUFFLE1BQU07QUFDakMsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxLQUFLLEVBQUUsZ0JBQWdCLElBQUksZ0JBQWdCO0FBRTFELFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsVUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0FBQzVDLFdBQU8sWUFBWTtBQUNuQixXQUFPLFlBQVksNEJBQTRCLFdBQVcsRUFBRSxNQUFNLENBQUM7QUFDbkUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsRUFBRTtBQUNyQixTQUFLLE9BQU8sUUFBUSxJQUFJO0FBRXhCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsVUFBTSxRQUFRLFNBQVMsY0FBYyxNQUFNO0FBQzNDLFVBQU0sWUFBWTtBQUNsQixVQUFNLFFBQVEsR0FBRyxjQUFjO0FBQy9CLFVBQU0sV0FBVyxHQUFHLGlCQUFpQjtBQUNyQyxVQUFNLE9BQU8sR0FBRyxpQkFBaUI7QUFDakMsVUFBTSxZQUNKLHFCQUFxQixPQUFPLEtBQUssQ0FBQyxtQkFDakMsV0FBVyxJQUFJLDJCQUF3QixPQUFPLFFBQVEsQ0FBQyxxQkFBcUIsTUFDN0UsY0FBVyxXQUFXLE9BQU8sSUFBSSxDQUFDLENBQUM7QUFFckMsVUFBTSxVQUFVLFNBQVMsY0FBYyxNQUFNO0FBQzdDLFlBQVEsWUFBWTtBQUNwQixVQUFNLE1BQU0sU0FBUyxjQUFjLFFBQVE7QUFDM0MsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYztBQUNsQixRQUFJLGlCQUFpQixTQUFTLFlBQVk7QUFDeEMsVUFBSSxXQUFXO0FBQ2YsVUFBSTtBQUNGLGNBQU0sS0FBSyxFQUFFLE1BQU0sZUFBZSxRQUFRLEVBQUUsT0FBTyxDQUFDO0FBQUEsTUFDdEQsVUFBRTtBQUNBLFlBQUksV0FBVztBQUFBLE1BQ2pCO0FBQUEsSUFDRixDQUFDO0FBQ0QsWUFBUSxPQUFPLEdBQUc7QUFFbEIsUUFBSSxPQUFPLE9BQU8sT0FBTztBQUN6QixPQUFHLE9BQU8sTUFBTSxHQUFHO0FBQ25CLGdCQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsUUFBMEI7QUFDaEQsZUFBYSxnQkFBZ0I7QUFDN0IsTUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLGlCQUFhLE9BQU8sRUFBRTtBQUN0QjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLE1BQU0sT0FBTyxNQUFNLEdBQUcsaUJBQWlCLEdBQUc7QUFDbkQsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixVQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsR0FBRztBQUNyQixTQUFLLE9BQU8sR0FBRztBQUNmLFVBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLFFBQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsWUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFVBQUksWUFBWTtBQUNoQixVQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFdBQUssT0FBTyxHQUFHO0FBQUEsSUFDakI7QUFDQSxPQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsaUJBQWEsT0FBTyxFQUFFO0FBQUEsRUFDeEI7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUFvQjtBQUMxQyxNQUFJLE1BQU0sS0FBTSxRQUFPO0FBQ3ZCLE1BQUksT0FBTyxNQUFNLFNBQVUsUUFBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQ3pFLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFVBQVcsUUFBTyxPQUFPLENBQUM7QUFDcEUsTUFBSTtBQUNGLFVBQU0sSUFBSSxLQUFLLFVBQVUsQ0FBQztBQUMxQixXQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFBQSxFQUNoRCxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsV0FBVyxHQUFtQjtBQUNyQyxTQUFPLEVBQUU7QUFBQSxJQUFRO0FBQUEsSUFBWSxDQUFDLE1BQzVCLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxXQUFXO0FBQUEsRUFDekY7QUFDRjtBQUVBLGVBQWUsZUFBOEI7QUFDM0MsTUFBSTtBQUNGLGdCQUFZLE1BQU0sS0FBcUIsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUM1RCxVQUFNLFNBQVM7QUFBQSxFQUNqQixTQUFTLEtBQUs7QUFDWixZQUFRLEtBQUssNkNBQTZDLEdBQUc7QUFBQSxFQUMvRDtBQUNGO0FBRUEsU0FBUyxNQUFNLE9BQTZCO0FBQzFDLGVBQWEsY0FBYyxNQUFNO0FBQ2pDLGdCQUFjLEtBQUs7QUFDbkIsYUFBVyxVQUFVLE1BQU0sU0FBUztBQUNwQyx1QkFBcUIsVUFBVSxNQUFNLFNBQVMsbUJBQW1CO0FBQ2pFLGFBQVcsT0FBTyxXQUFXLE1BQU0sU0FBUyxLQUFLLGNBQWMsTUFBTSxTQUFTLElBQUk7QUFDbEYsb0JBQWtCLEtBQUs7QUFDdkIsaUJBQWUsS0FBSztBQUNwQixxQkFBbUIsTUFBTSxvQkFBb0I7QUFDN0Msa0JBQWdCLEtBQUs7QUFDckIsa0JBQWdCLEtBQUs7QUFDckIsZUFBYSxLQUFLO0FBQ2xCLGtCQUFnQixLQUFLO0FBQ3ZCO0FBRUEsU0FBUyxtQkFBbUIsTUFBNkI7QUFDdkQsa0JBQWdCLGdCQUFnQjtBQUNoQyxNQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3JCLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsb0JBQWdCLE9BQU8sRUFBRTtBQUN6QjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLE9BQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxHQUFHO0FBQ25DLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksZ0JBQWdCLElBQUksY0FBYztBQUVqRCxVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFVBQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztBQUN2QyxTQUFLLFlBQVk7QUFDakIsU0FBSyxPQUFPLElBQUk7QUFDaEIsU0FBSyxTQUFTO0FBQ2QsU0FBSyxNQUFNO0FBQ1gsU0FBSyxjQUFjLElBQUksSUFBSSxjQUFjO0FBQ3pDLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVksY0FBYyxJQUFJLGNBQWM7QUFDbkQsV0FBTyxjQUFjLElBQUksbUJBQW1CLFVBQVUsVUFBVTtBQUNoRSxRQUFJLE9BQU8sTUFBTSxNQUFNO0FBRXZCLFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLGFBQWEsSUFBSSxNQUFNLEdBQUc7QUFFN0MsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQ0gsR0FBRyxrQkFBa0IsSUFBSSxNQUFNLENBQUMsU0FBTSxJQUFJLFVBQVUsZ0JBQWEsT0FBTyxJQUFJLFNBQVMsQ0FBQztBQUV4RixPQUFHLE9BQU8sS0FBSyxNQUFNLElBQUk7QUFDekIsb0JBQWdCLE9BQU8sRUFBRTtBQUFBLEVBQzNCO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixRQUF5QztBQUNsRSxNQUFJLFdBQVcsV0FBWSxRQUFPO0FBQ2xDLE1BQUksV0FBVyxZQUFhLFFBQU87QUFDbkMsU0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLE1BQWMsS0FBcUI7QUFDdkQsUUFBTSxVQUFVLEtBQUssUUFBUSxRQUFRLEdBQUcsRUFBRSxLQUFLO0FBQy9DLFNBQU8sUUFBUSxVQUFVLE1BQU0sVUFBVSxHQUFHLFFBQVEsTUFBTSxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQ3ZFO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsb0JBQWtCLFNBQVMsVUFBVSxLQUFLLENBQUM7QUFDM0Msa0JBQWdCLGNBQ2QsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELHFCQUFtQixTQUFTO0FBQzVCLHFCQUFtQixXQUFXLFVBQVU7QUFDeEMsc0JBQW9CLFNBQVMsQ0FBQztBQUM5QixxQkFBbUIsb0JBQW9CLENBQUM7QUFDMUM7QUFFQSxTQUFTLG1CQUNQLElBQ0EsR0FDTTtBQUNOLE1BQUksQ0FBQyxFQUFFLFdBQVcsRUFBRSxjQUFjLEdBQUc7QUFDbkMsT0FBRyxTQUFTO0FBQ1o7QUFBQSxFQUNGO0FBR0EsUUFBTSxRQUFRLEtBQUssSUFBSSxFQUFFLGdCQUFnQixFQUFFLFlBQVksRUFBRSxLQUFLO0FBQzlELEtBQUcsU0FBUztBQUNaLEtBQUcsY0FBYyxHQUFHLE9BQU8sRUFBRSxTQUFTLENBQUMsTUFBTSxPQUFPLEtBQUssQ0FBQztBQUMxRCxLQUFHLFlBQVksRUFBRSxVQUFVLGdCQUFnQjtBQUM3QztBQUVBLFNBQVMsa0JBQWtCLE9BQTZCO0FBQ3RELFFBQU0sS0FBSyxNQUFNLFNBQVMsWUFBWTtBQUN0QyxlQUFhLFVBQVU7QUFDdkIsY0FBWSxjQUFjLEtBQUssT0FBTztBQUN0QyxXQUFTLEtBQUssVUFBVSxPQUFPLFVBQVUsQ0FBQyxFQUFFO0FBQzlDO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxPQUFPLE1BQU0sU0FBUztBQUM1QixxQkFBbUIsUUFBUSxPQUFPLElBQUk7QUFDdEMsbUJBQWlCLGNBQWMsT0FBTyxJQUFJO0FBQzFDLFFBQU0sS0FBSyxNQUFNO0FBQ2pCLHFCQUFtQixTQUFTLEdBQUc7QUFDL0Isc0JBQW9CLFNBQVMsQ0FBQyxHQUFHO0FBQ2pDLE1BQUksR0FBRyxRQUFRO0FBQ2IsVUFBTSxJQUFJLEdBQUc7QUFDYixxQkFBaUIsY0FDZixNQUFNLElBQUksa0NBQTZCLGtCQUFhLENBQUMsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNO0FBQ25GLHFCQUFpQixZQUFZO0FBQUEsRUFDL0IsT0FBTztBQUNMLHFCQUFpQixjQUFjO0FBQy9CLHFCQUFpQixZQUFZO0FBQUEsRUFDL0I7QUFDQSxNQUFJLEdBQUcsVUFBVSxHQUFHLGNBQWMsS0FBSyxHQUFHLGdCQUFnQixHQUFHO0FBQzNELHVCQUFtQixTQUFTO0FBQzVCLFVBQU0sUUFBUTtBQUFBLE1BQ1osR0FBRyxPQUFPLEdBQUcsV0FBVyxDQUFDO0FBQUEsTUFDekIsR0FBRyxPQUFPLEdBQUcsZ0JBQWdCLENBQUM7QUFBQSxNQUM5QixHQUFHLE9BQU8sR0FBRyxxQkFBcUIsQ0FBQztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxHQUFHLGtCQUFrQixFQUFHLE9BQU0sS0FBSyxHQUFHLE9BQU8sR0FBRyxlQUFlLENBQUMsY0FBYztBQUNsRixVQUFNLEtBQUssR0FBRyxPQUFPLEdBQUcsYUFBYSxDQUFDLFdBQVc7QUFDakQsdUJBQW1CLGNBQWMsTUFBTSxLQUFLLFFBQUs7QUFDakQsdUJBQW1CLFlBQVksR0FBRyxTQUFTLGdCQUFnQjtBQUFBLEVBQzdELE9BQU87QUFDTCx1QkFBbUIsU0FBUztBQUFBLEVBQzlCO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsT0FBNkI7QUFDakQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsaUJBQWUsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUN4QyxlQUFhLGNBQ1gsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELGtCQUFnQixTQUFTO0FBQ3pCLGtCQUFnQixXQUFXLFVBQVU7QUFDckMsbUJBQWlCLFNBQVMsQ0FBQztBQUMzQixxQkFBbUIsaUJBQWlCLENBQUM7QUFDdkM7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLElBQUksTUFBTTtBQUNoQixRQUFNLFFBQVEsRUFBRTtBQUNoQixRQUFNLFVBQVUsRUFBRTtBQUNsQixvQkFBa0IsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUMzQyxrQkFBZ0IsY0FDZCxVQUFVLElBQ04sVUFDRSxpQkFDQSxhQUNGLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxVQUFVLGtCQUFlLEVBQUU7QUFDM0QscUJBQW1CLFNBQVM7QUFDNUIscUJBQW1CLFdBQVcsVUFBVTtBQUN4QyxzQkFBb0IsU0FBUyxDQUFDO0FBQzlCLHFCQUFtQixvQkFBb0IsQ0FBQztBQUMxQztBQUVBLGVBQWUsa0JBQWlDO0FBRzlDLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVTtBQUN6RCxRQUFNLFNBQVUsT0FBTyxZQUF1QyxDQUFDO0FBQy9ELGlCQUFlLE1BQU07QUFDdkI7QUFJQSxjQUFjLGlCQUFpQixTQUFTLFlBQVk7QUFDbEQsZ0JBQWMsV0FBVztBQUN6QixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFBQSxFQUNwQyxVQUFFO0FBQ0Esa0JBQWMsV0FBVztBQUFBLEVBQzNCO0FBQ0YsQ0FBQztBQUVELGVBQWUsaUJBQWlCLFNBQVMsWUFBWTtBQUNuRCxpQkFBZSxXQUFXO0FBQzFCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQUEsRUFDMUMsVUFBRTtBQUNBLG1CQUFlLFdBQVc7QUFBQSxFQUM1QjtBQUNGLENBQUM7QUFFRCxTQUFTLGlCQUFpQixTQUFTLFlBQVk7QUFDN0MsV0FBUyxXQUFXO0FBQ3BCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLFlBQVksQ0FBQztBQUFBLEVBQ2xDLFVBQUU7QUFDQSxhQUFTLFdBQVc7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxXQUFXLGlCQUFpQixVQUFVLE1BQU07QUFDMUMsT0FBSyxLQUFLLEVBQUUsTUFBTSx1QkFBdUIsSUFBSSxXQUFXLFFBQVEsQ0FBQztBQUNuRSxDQUFDO0FBRUQscUJBQXFCLGlCQUFpQixVQUFVLE1BQU07QUFDcEQsT0FBSyxLQUFLLEVBQUUsTUFBTSwwQkFBMEIsSUFBSSxxQkFBcUIsUUFBUSxDQUFDO0FBQ2hGLENBQUM7QUFFRCxhQUFhLGlCQUFpQixVQUFVLE1BQU07QUFDNUMsT0FBSyxLQUFLLEVBQUUsTUFBTSxrQkFBa0IsSUFBSSxhQUFhLFFBQVEsQ0FBQztBQUNoRSxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQscUJBQW1CLFdBQVc7QUFDOUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNyRCx1QkFBbUIsV0FBVztBQUFBLEVBQ2hDLENBQUM7QUFDSCxDQUFDO0FBQ0Qsb0JBQW9CLGlCQUFpQixTQUFTLE1BQU07QUFDbEQsc0JBQW9CLFdBQVc7QUFDL0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUN0RCx3QkFBb0IsV0FBVztBQUFBLEVBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQsbUJBQWlCLGNBQWMsbUJBQW1CO0FBQ3BELENBQUM7QUFDRCxtQkFBbUIsaUJBQWlCLFVBQVUsTUFBTTtBQUNsRCxRQUFNLFVBQVUsT0FBTyxtQkFBbUIsS0FBSztBQUMvQyxNQUFJLE9BQU8sU0FBUyxPQUFPLEdBQUc7QUFDNUIsU0FBSyxLQUFLLEVBQUUsTUFBTSw0QkFBNEIsUUFBUSxDQUFDO0FBQUEsRUFDekQ7QUFDRixDQUFDO0FBRUQsVUFBVSxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDaEQsSUFBRSxlQUFlO0FBQ2pCLFFBQU0sS0FBSyxPQUFPO0FBQUEsSUFDaEI7QUFBQSxFQUdGO0FBQ0EsTUFBSSxDQUFDLEdBQUk7QUFDVCxPQUFLLEtBQUssRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBQ3ZDLENBQUM7QUFFRCxnQkFBZ0IsaUJBQWlCLFNBQVMsTUFBTTtBQUM5QyxrQkFBZ0IsV0FBVztBQUMzQixPQUFLLEtBQUssRUFBRSxNQUFNLGdCQUFnQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ2pELG9CQUFnQixXQUFXO0FBQUEsRUFDN0IsQ0FBQztBQUNILENBQUM7QUFFRCxpQkFBaUIsaUJBQWlCLFNBQVMsTUFBTTtBQUMvQyxtQkFBaUIsV0FBVztBQUM1QixPQUFLLEtBQUssRUFBRSxNQUFNLGlCQUFpQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ2xELHFCQUFpQixXQUFXO0FBQUEsRUFDOUIsQ0FBQztBQUNILENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxxQkFBbUIsV0FBVztBQUM5QixPQUFLLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3JELHVCQUFtQixXQUFXO0FBQUEsRUFDaEMsQ0FBQztBQUNILENBQUM7QUFFRCxvQkFBb0IsaUJBQWlCLFNBQVMsTUFBTTtBQUNsRCxzQkFBb0IsV0FBVztBQUMvQixPQUFLLEtBQUssRUFBRSxNQUFNLHFCQUFxQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3RELHdCQUFvQixXQUFXO0FBQUEsRUFDakMsQ0FBQztBQUNILENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxxQkFBbUIsV0FBVztBQUM5QixPQUFLLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3JELHVCQUFtQixXQUFXO0FBQUEsRUFDaEMsQ0FBQztBQUNILENBQUM7QUFFRCxvQkFBb0IsaUJBQWlCLFNBQVMsTUFBTTtBQUNsRCxzQkFBb0IsV0FBVztBQUMvQixPQUFLLEtBQUssRUFBRSxNQUFNLHFCQUFxQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3RELHdCQUFvQixXQUFXO0FBQUEsRUFDakMsQ0FBQztBQUNILENBQUM7QUFFRCxZQUFZLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNsRCxJQUFFLGVBQWU7QUFDakIsT0FBSyxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDcEMsQ0FBQztBQUVELFdBQVcsaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2pELElBQUUsZUFBZTtBQUNqQixPQUFLLEtBQUssRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUNuQyxDQUFDO0FBRUQsWUFBWSxpQkFBaUIsU0FBUyxZQUFZO0FBQ2hELFFBQU0sS0FBSyxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDckMsaUJBQWUsQ0FBQyxDQUFDO0FBQ25CLENBQUM7QUFFRCxRQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsUUFBaUI7QUFDdEQsTUFBSSxDQUFDLE9BQU8sT0FBTyxRQUFRLFNBQVU7QUFDckMsUUFBTSxJQUFJO0FBQ1YsTUFBSSxFQUFFLFNBQVMsbUJBQW1CLEVBQUUsT0FBTztBQUN6QyxnQkFBWSxFQUFFO0FBQ2QsVUFBTSxFQUFFLEtBQUs7QUFBQSxFQUNmLFdBQVcsRUFBRSxTQUFTLGVBQWUsRUFBRSxPQUFPO0FBQzVDLGlCQUFhLEVBQUUsS0FBSztBQUFBLEVBQ3RCO0FBQ0YsQ0FBQztBQUVELFNBQVMsYUFBYSxJQUFvQjtBQUV4QyxNQUFJLGFBQWEsbUJBQW1CLFVBQVUsU0FBUyxPQUFPLEdBQUc7QUFDL0QsaUJBQWEsZ0JBQWdCO0FBQUEsRUFDL0I7QUFDQSxRQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsS0FBRyxZQUFZLE1BQU0sR0FBRyxLQUFLO0FBQzdCLFFBQU0sS0FBSyxTQUFTLGNBQWMsTUFBTTtBQUN4QyxLQUFHLFlBQVk7QUFDZixLQUFHLGNBQWMsSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxNQUFNLENBQUM7QUFDOUUsUUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLE9BQUssWUFBWTtBQUNqQixPQUFLLGNBQWMsR0FBRyxVQUFVLFVBQVUsV0FBTSxHQUFHLFVBQVUsU0FBUyxNQUFNO0FBQzVFLFFBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxRQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsTUFBSSxZQUFZO0FBQ2hCLE1BQUksY0FBYyxHQUFHO0FBQ3JCLE9BQUssT0FBTyxHQUFHO0FBQ2YsUUFBTSxVQUFVLE9BQU8sS0FBSyxHQUFHLE9BQU87QUFDdEMsTUFBSSxRQUFRLFNBQVMsR0FBRztBQUN0QixVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYyxRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLGVBQWUsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLFFBQUs7QUFDeEYsU0FBSyxPQUFPLEdBQUc7QUFBQSxFQUNqQjtBQUNBLEtBQUcsT0FBTyxJQUFJLE1BQU0sSUFBSTtBQUN4QixlQUFhLFFBQVEsRUFBRTtBQUN2QixTQUFPLGFBQWEsb0JBQW9CLG1CQUFtQjtBQUN6RCxpQkFBYSxrQkFBa0IsT0FBTztBQUFBLEVBQ3hDO0FBQ0Y7QUFHQSxLQUFLLGFBQWE7QUFDbEIsS0FBSyxnQkFBZ0I7QUFHckIsWUFBWSxNQUFNO0FBQ2hCLE9BQUssYUFBYTtBQUNwQixHQUFHLElBQU07IiwKICAibmFtZXMiOiBbXQp9Cg==
