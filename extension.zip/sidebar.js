// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollToggle = $("auto-scroll");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = `Auth error \u2014 check your PAT`;
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    text = "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
}
function paintMediaCrawl(state) {
  const total = state.mediaCrawlQueue.total;
  const running = state.mediaCrawlQueue.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  autoScrollToggle.checked = state.settings.autoScroll;
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  if (state.settings.autoScroll) {
    const n = state.autoScroll.tabCount;
    autoScrollStatus.textContent = n === 0 ? "on \u2014 no X tabs open" : `on \u2014 scrolling ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "rate-info on";
  } else {
    autoScrollStatus.textContent = "off";
    autoScrollStatus.className = "rate-info";
  }
}
function paintRefetch(state) {
  const total = state.refetchQueue.total;
  const running = state.refetchQueue.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-scroll", on: autoScrollToggle.checked });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgZW5hYmxlZDogdHJ1ZSxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbDogZmFsc2UsXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcbn07XG5cbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XG5cbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknIH0sXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JyB9LFxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicgfSxcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnIH0sXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJyB9LFxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknIH0sXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycgfSxcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBzaWRlYmFyLnRzIFx1MjAxNCBVSSBmb3IgdGhlIHBlcnNpc3RlbnQgc2lkZWJhci5cbiAqXG4gKiBTaWRlYmFycyBpbiBGaXJlZm94IHN0YXkgb3BlbiBhY3Jvc3MgdGFiL3dpbmRvdyBzd2l0Y2hlcywgd2hpY2ggaXMgdGhlXG4gKiBpbnRlbmRlZCBwZXJzaXN0ZW5jZSBtb2RlbC4gVGhpcyBtb2R1bGUgcmVuZGVycyBzdGF0ZSBwdXNoZWQgZnJvbSB0aGVcbiAqIGJhY2tncm91bmQgc2VydmljZSB3b3JrZXIgYW5kIGZvcndhcmRzIHVzZXIgY29tbWFuZHMgYmFjay5cbiAqL1xuXG5pbXBvcnQgeyBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7IEV4dGVuc2lvblN0YXRlLCBMb2dFdmVudCwgUnVudGltZU1lc3NhZ2UgfSBmcm9tICcuL2xpYi90eXBlcy5qcyc7XG5cbmNvbnN0ICQgPSA8VCBleHRlbmRzIEhUTUxFbGVtZW50ID0gSFRNTEVsZW1lbnQ+KGlkOiBzdHJpbmcpOiBUID0+IHtcbiAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCk7XG4gIGlmICghZWwpIHRocm93IG5ldyBFcnJvcihgbWlzc2luZyBlbGVtZW50ICMke2lkfWApO1xuICByZXR1cm4gZWwgYXMgVDtcbn07XG5cbmNvbnN0IGNvbm5Eb3QgPSAkKCdjb25uLWRvdCcpO1xuY29uc3QgY29ublRleHQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2Nvbm4tdGV4dCcpO1xuY29uc3QgYWNjb3VudExpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdhY2NvdW50LWxpc3QnKTtcbmNvbnN0IGFjdGl2aXR5TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjdGl2aXR5LWxpc3QnKTtcbmNvbnN0IGF1dG9Ub2dnbGUgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdhdXRvLWNhcHR1cmUnKTtcbmNvbnN0IGNhcHR1cmVBbGxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2FwdHVyZS1hbGwnKTtcbmNvbnN0IGNhcHR1cmVUaGlzQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtdGhpcycpO1xuY29uc3QgZmx1c2hCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignZmx1c2gtYWxsJyk7XG5jb25zdCBvcHRpb25zTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdvcGVuLW9wdGlvbnMnKTtcbmNvbnN0IHZpZXdlckxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi12aWV3ZXInKTtcbmNvbnN0IGNsZWFyQWN0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NsZWFyLWFjdGl2aXR5Jyk7XG5jb25zdCBleHRWZXJzaW9uRWwgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2V4dC12ZXJzaW9uJyk7XG5jb25zdCBtYXN0ZXJTd2l0Y2ggPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdtYXN0ZXItc3dpdGNoJyk7XG5jb25zdCBtYXN0ZXJMYWJlbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWFzdGVyLWxhYmVsJyk7XG5jb25zdCBhdXRvU2Nyb2xsVG9nZ2xlID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1zY3JvbGwnKTtcbmNvbnN0IGF1dG9TY3JvbGxJbnRlcnZhbCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tc2Nyb2xsLWludGVydmFsJyk7XG5jb25zdCBhdXRvU2Nyb2xsU2Vjc0VsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zZWNzJyk7XG5jb25zdCBhdXRvU2Nyb2xsU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zdGF0dXMnKTtcbmNvbnN0IHJlZmV0Y2hTZWN0aW9uID0gJDxIVE1MRWxlbWVudD4oJ3JlZmV0Y2gtc2VjdGlvbicpO1xuY29uc3QgcmVmZXRjaENvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdyZWZldGNoLWNvdW50Jyk7XG5jb25zdCByZWZldGNoU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1zdGFydCcpO1xuY29uc3QgcmVmZXRjaENhbmNlbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZWZldGNoLWNhbmNlbCcpO1xuY29uc3QgbWVkaWFDcmF3bFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PignbWVkaWEtY3Jhd2wtc2VjdGlvbicpO1xuY29uc3QgbWVkaWFDcmF3bENvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1jb3VudCcpO1xuY29uc3QgbWVkaWFDcmF3bFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLXN0YXJ0Jyk7XG5jb25zdCBtZWRpYUNyYXdsQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLWNhbmNlbCcpO1xuXG5sZXQgbGFzdFN0YXRlOiBFeHRlbnNpb25TdGF0ZSB8IG51bGwgPSBudWxsO1xuXG5hc3luYyBmdW5jdGlvbiBzZW5kPFQ+KG1zZzogUnVudGltZU1lc3NhZ2UpOiBQcm9taXNlPFQ+IHtcbiAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZShtc2cpIGFzIFByb21pc2U8VD47XG59XG5cbmZ1bmN0aW9uIHNldENvbm5TdGF0dXMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHsgY29ubmVjdGlvbiwgc2V0dGluZ3MgfSA9IHN0YXRlO1xuICBsZXQgY2xzID0gJyc7XG4gIGxldCB0ZXh0ID0gJyc7XG4gIC8vIE9ubHkgd2FybiB3aGVuIHRoZSBjb25maWd1cmVkIGJyYW5jaCBnZW51aW5lbHkgZG9lc24ndCBleGlzdCBvbiB0aGVcbiAgLy8gcmVtb3RlLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCB0aGF0IGV4aXN0cyBpcyBmaW5lIFx1MjAxNCBjYXB0dXJpbmcgaW50byBhXG4gIC8vIHdvcmtpbmcgYnJhbmNoIGlzIHJvdXRpbmUgXHUyMDE0IHNvIHRoZSBtZXJlIGAhPT1gIHRvIGRlZmF1bHRfYnJhbmNoIGlzIG5vdFxuICAvLyBhIHByb2JsZW0gYW5kIHNob3VsZG4ndCBzaG91dCBpbiB0aGUgaGVhZGVyLlxuICBjb25zdCBicmFuY2hNaXNzaW5nID1cbiAgICBjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ29rJyAmJiBzZXR0aW5ncy5icmFuY2ggJiYgY29ubmVjdGlvbi5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSBmYWxzZTtcbiAgaWYgKCFzZXR0aW5ncy5wYXRTZXQpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XG4gIH0gZWxzZSBpZiAoYnJhbmNoTWlzc2luZykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSBgQnJhbmNoIFwiJHtzZXR0aW5ncy5icmFuY2h9XCIgZG9lcyBub3QgZXhpc3Qgb24gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTIwMTQgY29tbWl0cyB3aWxsIDQyMi4gU2V0IGJyYW5jaCB0byBcIiR7Y29ubmVjdGlvbi5kZWZhdWx0QnJhbmNoID8/ICdtYXN0ZXInfVwiIGluIFNldHRpbmdzLmA7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycpIHtcbiAgICBjbHMgPSAnb2snO1xuICAgIHRleHQgPSBgQ29ubmVjdGVkIGFzIEAke2Nvbm5lY3Rpb24ubG9naW4gPz8gJz8nfSB0byAke3NldHRpbmdzLm93bmVyfS8ke3NldHRpbmdzLnJlcG99IFx1MDBCNyBcdTIwMjYke3NldHRpbmdzLnBhdFN1ZmZpeH1gO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gYEF1dGggZXJyb3IgXHUyMDE0IGNoZWNrIHlvdXIgUEFUYDtcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdHaXRIdWIgcmF0ZS1saW1pdGVkIFx1MjAxNCBjYXB0dXJlcyB3aWxsIHJldHJ5JztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ25ldHdvcmstZXJyb3InKSB7XG4gICAgY2xzID0gJ2Vycic7XG4gICAgdGV4dCA9ICdOZXR3b3JrIGVycm9yIFx1MjAxNCBjaGVjayBjb25uZWN0aXZpdHknO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnbm90LWNvbmZpZ3VyZWQnKSB7XG4gICAgY2xzID0gJ3dhcm4nO1xuICAgIHRleHQgPSAnTm90IGNvbmZpZ3VyZWQgXHUyMDE0IG9wZW4gU2V0dGluZ3MnO1xuICB9IGVsc2Uge1xuICAgIGNscyA9ICcnO1xuICAgIHRleHQgPSAnQ2hlY2tpbmdcdTIwMjYnO1xuICB9XG4gIGNvbm5Eb3QuY2xhc3NOYW1lID0gYGRvdCAke2Nsc31gO1xuICBjb25uVGV4dC50ZXh0Q29udGVudCA9IHRleHQ7XG4gIGNvbm5UZXh0LnRpdGxlID0gY29ubmVjdGlvbi5lcnJvciA/PyAnJztcbn1cblxuZnVuY3Rpb24gZm10UmVsKGlzbzogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB7XG4gIGlmICghaXNvKSByZXR1cm4gJ1x1MjAxNCc7XG4gIGNvbnN0IGQgPSBEYXRlLnBhcnNlKGlzbyk7XG4gIGlmICghTnVtYmVyLmlzRmluaXRlKGQpKSByZXR1cm4gJ1x1MjAxNCc7XG4gIGNvbnN0IHNlY3MgPSBNYXRoLm1heCgwLCBNYXRoLnJvdW5kKChEYXRlLm5vdygpIC0gZCkgLyAxMDAwKSk7XG4gIGlmIChzZWNzIDwgNSkgcmV0dXJuICdqdXN0IG5vdyc7XG4gIGlmIChzZWNzIDwgNjApIHJldHVybiBgJHtzZWNzfXMgYWdvYDtcbiAgY29uc3QgbWlucyA9IE1hdGgucm91bmQoc2VjcyAvIDYwKTtcbiAgaWYgKG1pbnMgPCA2MCkgcmV0dXJuIGAke21pbnN9bSBhZ29gO1xuICBjb25zdCBob3VycyA9IE1hdGgucm91bmQobWlucyAvIDYwKTtcbiAgaWYgKGhvdXJzIDwgMjQpIHJldHVybiBgJHtob3Vyc31oIGFnb2A7XG4gIGNvbnN0IGRheXMgPSBNYXRoLnJvdW5kKGhvdXJzIC8gMjQpO1xuICByZXR1cm4gYCR7ZGF5c31kIGFnb2A7XG59XG5cbmZ1bmN0aW9uIGZtdE51bShuOiBudW1iZXIpOiBzdHJpbmcge1xuICByZXR1cm4gbi50b0xvY2FsZVN0cmluZygnZW4tVVMnKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQWNjb3VudHMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGFjY291bnRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBpZiAoc3RhdGUuYWNjb3VudHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWNjb3VudHMgY29uZmlndXJlZC4nO1xuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3QgYSBvZiBzdGF0ZS5hY2NvdW50cykge1xuICAgIGNvbnN0IGMgPSBzdGF0ZS5jb3VudGVyc1thLmhhbmRsZV07XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9IGMgJiYgYy5idWZmZXJlZENvdW50ID4gMCA/ICdhY2MgcGVuZGluZycgOiAnYWNjJztcblxuICAgIGNvbnN0IGhlYWQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBoZWFkLmNsYXNzTmFtZSA9ICdhY2MtaGVhZCc7XG4gICAgY29uc3QgaGFuZGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGhhbmRsZS5jbGFzc05hbWUgPSAnYWNjLWhhbmRsZSc7XG4gICAgaGFuZGxlLmlubmVySFRNTCA9IGA8c3BhbiBjbGFzcz1cImF0XCI+QDwvc3Bhbj4ke2VzY2FwZUh0bWwoYS5oYW5kbGUpfWA7XG4gICAgY29uc3QgbWV0YSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBtZXRhLmNsYXNzTmFtZSA9ICdhY2MtbWV0YSc7XG4gICAgbWV0YS50ZXh0Q29udGVudCA9IGEubGFiZWw7XG4gICAgaGVhZC5hcHBlbmQoaGFuZGxlLCBtZXRhKTtcblxuICAgIGNvbnN0IHJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHJvdy5jbGFzc05hbWUgPSAnYWNjLXJvdyc7XG4gICAgY29uc3Qgc3RhdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgc3RhdHMuY2xhc3NOYW1lID0gJ2FjYy1zdGF0cyc7XG4gICAgY29uc3QgdG9kYXkgPSBjPy50b2RheUNvdW50ID8/IDA7XG4gICAgY29uc3QgYnVmZmVyZWQgPSBjPy5idWZmZXJlZENvdW50ID8/IDA7XG4gICAgY29uc3QgbGFzdCA9IGM/Lmxhc3RDYXB0dXJlQXQgPz8gbnVsbDtcbiAgICBzdGF0cy5pbm5lckhUTUwgPVxuICAgICAgYDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0odG9kYXkpfTwvc3Bhbj4gdG9kYXlgICtcbiAgICAgIChidWZmZXJlZCA+IDAgPyBgIFx1MDBCNyA8c3BhbiBjbGFzcz1cIm51bVwiPiR7Zm10TnVtKGJ1ZmZlcmVkKX08L3NwYW4+IGJ1ZmZlcmVkYCA6ICcnKSArXG4gICAgICBgIFx1MDBCNyBsYXN0ICR7ZXNjYXBlSHRtbChmbXRSZWwobGFzdCkpfWA7XG5cbiAgICBjb25zdCBhY3Rpb25zID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGFjdGlvbnMuY2xhc3NOYW1lID0gJ2FjYy1hY3Rpb24nO1xuICAgIGNvbnN0IGJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGJ0bi5jbGFzc05hbWUgPSAnYnRuJztcbiAgICBidG4udGV4dENvbnRlbnQgPSAnQ2FwdHVyZSBub3cnO1xuICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtbm93JywgaGFuZGxlOiBhLmhhbmRsZSB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGFjdGlvbnMuYXBwZW5kKGJ0bik7XG5cbiAgICByb3cuYXBwZW5kKHN0YXRzLCBhY3Rpb25zKTtcbiAgICBsaS5hcHBlbmQoaGVhZCwgcm93KTtcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFjdGl2aXR5KGV2ZW50czogTG9nRXZlbnRbXSk6IHZvaWQge1xuICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChldmVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWN0aXZpdHkgeWV0Lic7XG4gICAgYWN0aXZpdHlMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3QgZXYgb2YgZXZlbnRzLnNsaWNlKDAsIEFDVElWSVRZX1RBSUxfTUFYKSkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xuICAgIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XG4gICAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcbiAgICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xuICAgIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xuICAgIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xuICAgIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcbiAgICBib2R5LmFwcGVuZChtc2cpO1xuICAgIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcbiAgICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcbiAgICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgICBib2R5LmFwcGVuZChjdHgpO1xuICAgIH1cbiAgICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xuICAgIGFjdGl2aXR5TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHN0cmluZ2lmeVNob3J0KHY6IHVua25vd24pOiBzdHJpbmcge1xuICBpZiAodiA9PT0gbnVsbCkgcmV0dXJuICdudWxsJztcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJykgcmV0dXJuIHYubGVuZ3RoID4gODAgPyBgJHt2LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdjtcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gU3RyaW5nKHYpO1xuICB0cnkge1xuICAgIGNvbnN0IHMgPSBKU09OLnN0cmluZ2lmeSh2KTtcbiAgICByZXR1cm4gcy5sZW5ndGggPiA4MCA/IGAke3Muc2xpY2UoMCwgODApfVx1MjAyNmAgOiBzO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gJz8nO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoczogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHMucmVwbGFjZSgvWyY8PlwiJ10vZywgKGMpID0+XG4gICAgYyA9PT0gJyYnID8gJyZhbXA7JyA6IGMgPT09ICc8JyA/ICcmbHQ7JyA6IGMgPT09ICc+JyA/ICcmZ3Q7JyA6IGMgPT09ICdcIicgPyAnJnF1b3Q7JyA6ICcmIzM5OydcbiAgKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaFN0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGxhc3RTdGF0ZSA9IGF3YWl0IHNlbmQ8RXh0ZW5zaW9uU3RhdGU+KHsgdHlwZTogJ2dldC1zdGF0ZScgfSk7XG4gICAgcGFpbnQobGFzdFN0YXRlKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNpZGViYXIgcmVmcmVzaFN0YXRlIGZhaWxlZCcsIGVycik7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGFpbnQoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGV4dFZlcnNpb25FbC50ZXh0Q29udGVudCA9IHN0YXRlLnZlcnNpb247XG4gIHNldENvbm5TdGF0dXMoc3RhdGUpO1xuICBhdXRvVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvQ2FwdHVyZTtcbiAgdmlld2VyTGluay5ocmVmID0gYGh0dHBzOi8vJHtzdGF0ZS5zZXR0aW5ncy5vd25lcn0uZ2l0aHViLmlvLyR7c3RhdGUuc2V0dGluZ3MucmVwb30vYDtcbiAgcGFpbnRNYXN0ZXJTd2l0Y2goc3RhdGUpO1xuICByZW5kZXJBY2NvdW50cyhzdGF0ZSk7XG4gIHBhaW50QXV0b1Njcm9sbChzdGF0ZSk7XG4gIHBhaW50TWVkaWFDcmF3bChzdGF0ZSk7XG4gIHBhaW50UmVmZXRjaChzdGF0ZSk7XG59XG5cbmZ1bmN0aW9uIHBhaW50TWVkaWFDcmF3bChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3QgdG90YWwgPSBzdGF0ZS5tZWRpYUNyYXdsUXVldWUudG90YWw7XG4gIGNvbnN0IHJ1bm5pbmcgPSBzdGF0ZS5tZWRpYUNyYXdsUXVldWUucnVubmluZztcbiAgbWVkaWFDcmF3bFNlY3Rpb24uaGlkZGVuID0gdG90YWwgPT09IDAgJiYgIXJ1bm5pbmc7XG4gIG1lZGlhQ3Jhd2xDb3VudC50ZXh0Q29udGVudCA9XG4gICAgdG90YWwgPT09IDBcbiAgICAgID8gcnVubmluZ1xuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXG4gICAgICAgIDogJzAgcXVldWVkJ1xuICAgICAgOiBgJHtmbXROdW0odG90YWwpfSBxdWV1ZWQke3J1bm5pbmcgPyAnIFx1MDBCNyBydW5uaW5nJyA6ICcnfWA7XG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcbiAgbWVkaWFDcmF3bENhbmNlbEJ0bi5oaWRkZW4gPSAhcnVubmluZztcbn1cblxuZnVuY3Rpb24gcGFpbnRNYXN0ZXJTd2l0Y2goc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IG9uID0gc3RhdGUuc2V0dGluZ3MuZW5hYmxlZCAhPT0gZmFsc2U7XG4gIG1hc3RlclN3aXRjaC5jaGVja2VkID0gb247XG4gIG1hc3RlckxhYmVsLnRleHRDb250ZW50ID0gb24gPyAnT04nIDogJ1BBVVNFRCc7XG4gIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnRvZ2dsZSgncGF1c2VkJywgIW9uKTtcbn1cblxuZnVuY3Rpb24gcGFpbnRBdXRvU2Nyb2xsKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBhdXRvU2Nyb2xsVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvU2Nyb2xsO1xuICBjb25zdCBzZWNzID0gc3RhdGUuc2V0dGluZ3MuYXV0b1Njcm9sbEludGVydmFsU2VjO1xuICBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWUgPSBTdHJpbmcoc2Vjcyk7XG4gIGF1dG9TY3JvbGxTZWNzRWwudGV4dENvbnRlbnQgPSBTdHJpbmcoc2Vjcyk7XG4gIGlmIChzdGF0ZS5zZXR0aW5ncy5hdXRvU2Nyb2xsKSB7XG4gICAgY29uc3QgbiA9IHN0YXRlLmF1dG9TY3JvbGwudGFiQ291bnQ7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9XG4gICAgICBuID09PSAwID8gJ29uIFx1MjAxNCBubyBYIHRhYnMgb3BlbicgOiBgb24gXHUyMDE0IHNjcm9sbGluZyAke259ICR7biA9PT0gMSA/ICd0YWInIDogJ3RhYnMnfWA7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy5jbGFzc05hbWUgPSAncmF0ZS1pbmZvIG9uJztcbiAgfSBlbHNlIHtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLnRleHRDb250ZW50ID0gJ29mZic7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy5jbGFzc05hbWUgPSAncmF0ZS1pbmZvJztcbiAgfVxufVxuXG5mdW5jdGlvbiBwYWludFJlZmV0Y2goc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHRvdGFsID0gc3RhdGUucmVmZXRjaFF1ZXVlLnRvdGFsO1xuICBjb25zdCBydW5uaW5nID0gc3RhdGUucmVmZXRjaFF1ZXVlLnJ1bm5pbmc7XG4gIHJlZmV0Y2hTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xuICByZWZldGNoQ291bnQudGV4dENvbnRlbnQgPVxuICAgIHRvdGFsID09PSAwXG4gICAgICA/IHJ1bm5pbmdcbiAgICAgICAgPyAnZmluaXNoaW5nXHUyMDI2J1xuICAgICAgICA6ICcwIHF1ZXVlZCdcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xuICByZWZldGNoU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcbiAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gdG90YWwgPT09IDA7XG4gIHJlZmV0Y2hDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hBY3Rpdml0eSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gUHVsbCBzdHJhaWdodCBmcm9tIHN0b3JhZ2Ugb24gZmlyc3QgcmVuZGVyOyBsaXZlIHVwZGF0ZXMgY29tZSB2aWFcbiAgLy8gYGxvZy1ldmVudGAgYnJvYWRjYXN0cy5cbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldCgnYWN0aXZpdHknKTtcbiAgY29uc3QgZXZlbnRzID0gKHN0b3JlZC5hY3Rpdml0eSBhcyBMb2dFdmVudFtdIHwgdW5kZWZpbmVkKSA/PyBbXTtcbiAgcmVuZGVyQWN0aXZpdHkoZXZlbnRzKTtcbn1cblxuLy8gLS0tIFdpcmUgdXAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuY2FwdHVyZUFsbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgY2FwdHVyZUFsbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjYXB0dXJlLWFsbCcgfSk7XG4gIH0gZmluYWxseSB7XG4gICAgY2FwdHVyZUFsbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuY2FwdHVyZVRoaXNCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGNhcHR1cmVUaGlzQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtdGhpcy1wYWdlJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjYXB0dXJlVGhpc0J0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuZmx1c2hCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGZsdXNoQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2ZsdXNoLWFsbCcgfSk7XG4gIH0gZmluYWxseSB7XG4gICAgZmx1c2hCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfVxufSk7XG5cbmF1dG9Ub2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLWF1dG8tY2FwdHVyZScsIG9uOiBhdXRvVG9nZ2xlLmNoZWNrZWQgfSk7XG59KTtcblxubWFzdGVyU3dpdGNoLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1lbmFibGVkJywgb246IG1hc3RlclN3aXRjaC5jaGVja2VkIH0pO1xufSk7XG5cbmF1dG9TY3JvbGxUb2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLWF1dG8tc2Nyb2xsJywgb246IGF1dG9TY3JvbGxUb2dnbGUuY2hlY2tlZCB9KTtcbn0pO1xuXG5hdXRvU2Nyb2xsSW50ZXJ2YWwuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLCAoKSA9PiB7XG4gIGF1dG9TY3JvbGxTZWNzRWwudGV4dENvbnRlbnQgPSBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWU7XG59KTtcbmF1dG9TY3JvbGxJbnRlcnZhbC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIGNvbnN0IHNlY29uZHMgPSBOdW1iZXIoYXV0b1Njcm9sbEludGVydmFsLnZhbHVlKTtcbiAgaWYgKE51bWJlci5pc0Zpbml0ZShzZWNvbmRzKSkge1xuICAgIHZvaWQgc2VuZCh7IHR5cGU6ICdzZXQtYXV0by1zY3JvbGwtaW50ZXJ2YWwnLCBzZWNvbmRzIH0pO1xuICB9XG59KTtcblxucmVmZXRjaFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtcmVmZXRjaCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbnJlZmV0Y2hDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxubWVkaWFDcmF3bFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5tZWRpYUNyYXdsQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBtZWRpYUNyYXdsQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1tZWRpYS1jcmF3bCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5vcHRpb25zTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdvcGVuLW9wdGlvbnMnIH0pO1xufSk7XG5cbnZpZXdlckxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnb3Blbi12aWV3ZXInIH0pO1xufSk7XG5cbmNsZWFyQWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NsZWFyLWFjdGl2aXR5JyB9KTtcbiAgcmVuZGVyQWN0aXZpdHkoW10pO1xufSk7XG5cbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93bikgPT4ge1xuICBpZiAoIW1zZyB8fCB0eXBlb2YgbXNnICE9PSAnb2JqZWN0JykgcmV0dXJuO1xuICBjb25zdCBtID0gbXNnIGFzIHsgdHlwZT86IHN0cmluZzsgc3RhdGU/OiBFeHRlbnNpb25TdGF0ZTsgZXZlbnQ/OiBMb2dFdmVudCB9O1xuICBpZiAobS50eXBlID09PSAnc3RhdGUtY2hhbmdlZCcgJiYgbS5zdGF0ZSkge1xuICAgIGxhc3RTdGF0ZSA9IG0uc3RhdGU7XG4gICAgcGFpbnQobS5zdGF0ZSk7XG4gIH0gZWxzZSBpZiAobS50eXBlID09PSAnbG9nLWV2ZW50JyAmJiBtLmV2ZW50KSB7XG4gICAgcHJlcGVuZEV2ZW50KG0uZXZlbnQpO1xuICB9XG59KTtcblxuZnVuY3Rpb24gcHJlcGVuZEV2ZW50KGV2OiBMb2dFdmVudCk6IHZvaWQge1xuICAvLyBJZiB0aGUgbGlzdCBpcyBzaG93aW5nIHRoZSBcImVtcHR5XCIgcGxhY2Vob2xkZXIsIGNsZWFyIGl0LlxuICBpZiAoYWN0aXZpdHlMaXN0LmZpcnN0RWxlbWVudENoaWxkPy5jbGFzc0xpc3QuY29udGFpbnMoJ2VtcHR5JykpIHtcbiAgICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIH1cbiAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xuICBjb25zdCB0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgdHMuY2xhc3NOYW1lID0gJ2V2LXRzJztcbiAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcbiAgY29uc3QgaWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgaWNvbi5jbGFzc05hbWUgPSAnZXYtaWNvbic7XG4gIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xuICBjb25zdCBib2R5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBjb25zdCBtc2cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xuICBtc2cudGV4dENvbnRlbnQgPSBldi5tc2c7XG4gIGJvZHkuYXBwZW5kKG1zZyk7XG4gIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcbiAgaWYgKGN0eEtleXMubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGN0eCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcbiAgICBjdHgudGV4dENvbnRlbnQgPSBjdHhLZXlzLm1hcCgoaykgPT4gYCR7a309JHtzdHJpbmdpZnlTaG9ydChldi5jb250ZXh0W2tdKX1gKS5qb2luKCcgXHUwMEI3ICcpO1xuICAgIGJvZHkuYXBwZW5kKGN0eCk7XG4gIH1cbiAgbGkuYXBwZW5kKHRzLCBpY29uLCBib2R5KTtcbiAgYWN0aXZpdHlMaXN0LnByZXBlbmQobGkpO1xuICB3aGlsZSAoYWN0aXZpdHlMaXN0LmNoaWxkRWxlbWVudENvdW50ID4gQUNUSVZJVFlfVEFJTF9NQVgpIHtcbiAgICBhY3Rpdml0eUxpc3QubGFzdEVsZW1lbnRDaGlsZD8ucmVtb3ZlKCk7XG4gIH1cbn1cblxuLy8gSW5pdGlhbCBwYWludC5cbnZvaWQgcmVmcmVzaFN0YXRlKCk7XG52b2lkIHJlZnJlc2hBY3Rpdml0eSgpO1xuXG4vLyBQZXJpb2RpY2FsbHkgcmUtZmV0Y2ggc3RhdGUgc28gXCJsYXN0IGNhcHR1cmVcIiB0aW1lcyBzdGF5IGZyZXNoLlxuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICB2b2lkIHJlZnJlc2hTdGF0ZSgpO1xufSwgMTVfMDAwKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7QUF5Rk8sSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLOzs7QUNqRnZELElBQU0sSUFBSSxDQUFzQyxPQUFrQjtBQUNoRSxRQUFNLEtBQUssU0FBUyxlQUFlLEVBQUU7QUFDckMsTUFBSSxDQUFDLEdBQUksT0FBTSxJQUFJLE1BQU0sb0JBQW9CLEVBQUUsRUFBRTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxJQUFNLFVBQVUsRUFBRSxVQUFVO0FBQzVCLElBQU0sV0FBVyxFQUFtQixXQUFXO0FBQy9DLElBQU0sY0FBYyxFQUFvQixjQUFjO0FBQ3RELElBQU0sZUFBZSxFQUFvQixlQUFlO0FBQ3hELElBQU0sYUFBYSxFQUFvQixjQUFjO0FBQ3JELElBQU0sZ0JBQWdCLEVBQXFCLGFBQWE7QUFDeEQsSUFBTSxpQkFBaUIsRUFBcUIsY0FBYztBQUMxRCxJQUFNLFdBQVcsRUFBcUIsV0FBVztBQUNqRCxJQUFNLGNBQWMsRUFBcUIsY0FBYztBQUN2RCxJQUFNLGFBQWEsRUFBcUIsYUFBYTtBQUNyRCxJQUFNLGNBQWMsRUFBcUIsZ0JBQWdCO0FBQ3pELElBQU0sZUFBZSxFQUFtQixhQUFhO0FBQ3JELElBQU0sZUFBZSxFQUFvQixlQUFlO0FBQ3hELElBQU0sY0FBYyxFQUFtQixjQUFjO0FBQ3JELElBQU0sbUJBQW1CLEVBQW9CLGFBQWE7QUFDMUQsSUFBTSxxQkFBcUIsRUFBb0Isc0JBQXNCO0FBQ3JFLElBQU0sbUJBQW1CLEVBQW1CLGtCQUFrQjtBQUM5RCxJQUFNLG1CQUFtQixFQUFtQixvQkFBb0I7QUFDaEUsSUFBTSxpQkFBaUIsRUFBZSxpQkFBaUI7QUFDdkQsSUFBTSxlQUFlLEVBQW1CLGVBQWU7QUFDdkQsSUFBTSxrQkFBa0IsRUFBcUIsZUFBZTtBQUM1RCxJQUFNLG1CQUFtQixFQUFxQixnQkFBZ0I7QUFDOUQsSUFBTSxvQkFBb0IsRUFBZSxxQkFBcUI7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsbUJBQW1CO0FBQzlELElBQU0scUJBQXFCLEVBQXFCLG1CQUFtQjtBQUNuRSxJQUFNLHNCQUFzQixFQUFxQixvQkFBb0I7QUFFckUsSUFBSSxZQUFtQztBQUV2QyxlQUFlLEtBQVEsS0FBaUM7QUFDdEQsU0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ3hDO0FBRUEsU0FBUyxjQUFjLE9BQTZCO0FBQ2xELFFBQU0sRUFBRSxZQUFZLFNBQVMsSUFBSTtBQUNqQyxNQUFJLE1BQU07QUFDVixNQUFJLE9BQU87QUFLWCxRQUFNLGdCQUNKLFdBQVcsV0FBVyxRQUFRLFNBQVMsVUFBVSxXQUFXLDJCQUEyQjtBQUN6RixNQUFJLENBQUMsU0FBUyxRQUFRO0FBQ3BCLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLGVBQWU7QUFDeEIsVUFBTTtBQUNOLFdBQU8sV0FBVyxTQUFTLE1BQU0sdUJBQXVCLFNBQVMsS0FBSyxJQUFJLFNBQVMsSUFBSSw0Q0FBdUMsV0FBVyxpQkFBaUIsUUFBUTtBQUFBLEVBQ3BLLFdBQVcsV0FBVyxXQUFXLE1BQU07QUFDckMsVUFBTTtBQUNOLFdBQU8saUJBQWlCLFdBQVcsU0FBUyxHQUFHLE9BQU8sU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLGVBQU8sU0FBUyxTQUFTO0FBQUEsRUFDaEgsV0FBVyxXQUFXLFdBQVcsY0FBYztBQUM3QyxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxXQUFXLFdBQVcsZ0JBQWdCO0FBQy9DLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLFdBQVcsV0FBVyxpQkFBaUI7QUFDaEQsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsV0FBVyxXQUFXLGtCQUFrQjtBQUNqRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsT0FBTztBQUNMLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNBLFVBQVEsWUFBWSxPQUFPLEdBQUc7QUFDOUIsV0FBUyxjQUFjO0FBQ3ZCLFdBQVMsUUFBUSxXQUFXLFNBQVM7QUFDdkM7QUFFQSxTQUFTLE9BQU8sS0FBNEI7QUFDMUMsTUFBSSxDQUFDLElBQUssUUFBTztBQUNqQixRQUFNLElBQUksS0FBSyxNQUFNLEdBQUc7QUFDeEIsTUFBSSxDQUFDLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUNoQyxRQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSSxDQUFDO0FBQzVELE1BQUksT0FBTyxFQUFHLFFBQU87QUFDckIsTUFBSSxPQUFPLEdBQUksUUFBTyxHQUFHLElBQUk7QUFDN0IsUUFBTSxPQUFPLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDakMsTUFBSSxPQUFPLEdBQUksUUFBTyxHQUFHLElBQUk7QUFDN0IsUUFBTSxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDbEMsTUFBSSxRQUFRLEdBQUksUUFBTyxHQUFHLEtBQUs7QUFDL0IsUUFBTSxPQUFPLEtBQUssTUFBTSxRQUFRLEVBQUU7QUFDbEMsU0FBTyxHQUFHLElBQUk7QUFDaEI7QUFFQSxTQUFTLE9BQU8sR0FBbUI7QUFDakMsU0FBTyxFQUFFLGVBQWUsT0FBTztBQUNqQztBQUVBLFNBQVMsZUFBZSxPQUE2QjtBQUNuRCxjQUFZLGdCQUFnQjtBQUM1QixNQUFJLE1BQU0sU0FBUyxXQUFXLEdBQUc7QUFDL0IsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixnQkFBWSxPQUFPLEVBQUU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsYUFBVyxLQUFLLE1BQU0sVUFBVTtBQUM5QixVQUFNLElBQUksTUFBTSxTQUFTLEVBQUUsTUFBTTtBQUNqQyxVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZLEtBQUssRUFBRSxnQkFBZ0IsSUFBSSxnQkFBZ0I7QUFFMUQsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixVQUFNLFNBQVMsU0FBUyxjQUFjLE1BQU07QUFDNUMsV0FBTyxZQUFZO0FBQ25CLFdBQU8sWUFBWSw0QkFBNEIsV0FBVyxFQUFFLE1BQU0sQ0FBQztBQUNuRSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxFQUFFO0FBQ3JCLFNBQUssT0FBTyxRQUFRLElBQUk7QUFFeEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixVQUFNLFFBQVEsU0FBUyxjQUFjLE1BQU07QUFDM0MsVUFBTSxZQUFZO0FBQ2xCLFVBQU0sUUFBUSxHQUFHLGNBQWM7QUFDL0IsVUFBTSxXQUFXLEdBQUcsaUJBQWlCO0FBQ3JDLFVBQU0sT0FBTyxHQUFHLGlCQUFpQjtBQUNqQyxVQUFNLFlBQ0oscUJBQXFCLE9BQU8sS0FBSyxDQUFDLG1CQUNqQyxXQUFXLElBQUksMkJBQXdCLE9BQU8sUUFBUSxDQUFDLHFCQUFxQixNQUM3RSxjQUFXLFdBQVcsT0FBTyxJQUFJLENBQUMsQ0FBQztBQUVyQyxVQUFNLFVBQVUsU0FBUyxjQUFjLE1BQU07QUFDN0MsWUFBUSxZQUFZO0FBQ3BCLFVBQU0sTUFBTSxTQUFTLGNBQWMsUUFBUTtBQUMzQyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjO0FBQ2xCLFFBQUksaUJBQWlCLFNBQVMsWUFBWTtBQUN4QyxVQUFJLFdBQVc7QUFDZixVQUFJO0FBQ0YsY0FBTSxLQUFLLEVBQUUsTUFBTSxlQUFlLFFBQVEsRUFBRSxPQUFPLENBQUM7QUFBQSxNQUN0RCxVQUFFO0FBQ0EsWUFBSSxXQUFXO0FBQUEsTUFDakI7QUFBQSxJQUNGLENBQUM7QUFDRCxZQUFRLE9BQU8sR0FBRztBQUVsQixRQUFJLE9BQU8sT0FBTyxPQUFPO0FBQ3pCLE9BQUcsT0FBTyxNQUFNLEdBQUc7QUFDbkIsZ0JBQVksT0FBTyxFQUFFO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsZUFBZSxRQUEwQjtBQUNoRCxlQUFhLGdCQUFnQjtBQUM3QixNQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsaUJBQWEsT0FBTyxFQUFFO0FBQ3RCO0FBQUEsRUFDRjtBQUNBLGFBQVcsTUFBTSxPQUFPLE1BQU0sR0FBRyxpQkFBaUIsR0FBRztBQUNuRCxVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZLE1BQU0sR0FBRyxLQUFLO0FBQzdCLFVBQU0sS0FBSyxTQUFTLGNBQWMsTUFBTTtBQUN4QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWMsSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxNQUFNLENBQUM7QUFDOUUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsR0FBRyxVQUFVLFVBQVUsV0FBTSxHQUFHLFVBQVUsU0FBUyxNQUFNO0FBQzVFLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYyxHQUFHO0FBQ3JCLFNBQUssT0FBTyxHQUFHO0FBQ2YsVUFBTSxVQUFVLE9BQU8sS0FBSyxHQUFHLE9BQU87QUFDdEMsUUFBSSxRQUFRLFNBQVMsR0FBRztBQUN0QixZQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsVUFBSSxZQUFZO0FBQ2hCLFVBQUksY0FBYyxRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLGVBQWUsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLFFBQUs7QUFDeEYsV0FBSyxPQUFPLEdBQUc7QUFBQSxJQUNqQjtBQUNBLE9BQUcsT0FBTyxJQUFJLE1BQU0sSUFBSTtBQUN4QixpQkFBYSxPQUFPLEVBQUU7QUFBQSxFQUN4QjtBQUNGO0FBRUEsU0FBUyxlQUFlLEdBQW9CO0FBQzFDLE1BQUksTUFBTSxLQUFNLFFBQU87QUFDdkIsTUFBSSxPQUFPLE1BQU0sU0FBVSxRQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFDekUsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLE1BQU0sVUFBVyxRQUFPLE9BQU8sQ0FBQztBQUNwRSxNQUFJO0FBQ0YsVUFBTSxJQUFJLEtBQUssVUFBVSxDQUFDO0FBQzFCLFdBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUFBLEVBQ2hELFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxXQUFXLEdBQW1CO0FBQ3JDLFNBQU8sRUFBRTtBQUFBLElBQVE7QUFBQSxJQUFZLENBQUMsTUFDNUIsTUFBTSxNQUFNLFVBQVUsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLFdBQVc7QUFBQSxFQUN6RjtBQUNGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxNQUFJO0FBQ0YsZ0JBQVksTUFBTSxLQUFxQixFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQzVELFVBQU0sU0FBUztBQUFBLEVBQ2pCLFNBQVMsS0FBSztBQUNaLFlBQVEsS0FBSyw2Q0FBNkMsR0FBRztBQUFBLEVBQy9EO0FBQ0Y7QUFFQSxTQUFTLE1BQU0sT0FBNkI7QUFDMUMsZUFBYSxjQUFjLE1BQU07QUFDakMsZ0JBQWMsS0FBSztBQUNuQixhQUFXLFVBQVUsTUFBTSxTQUFTO0FBQ3BDLGFBQVcsT0FBTyxXQUFXLE1BQU0sU0FBUyxLQUFLLGNBQWMsTUFBTSxTQUFTLElBQUk7QUFDbEYsb0JBQWtCLEtBQUs7QUFDdkIsaUJBQWUsS0FBSztBQUNwQixrQkFBZ0IsS0FBSztBQUNyQixrQkFBZ0IsS0FBSztBQUNyQixlQUFhLEtBQUs7QUFDcEI7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLFFBQVEsTUFBTSxnQkFBZ0I7QUFDcEMsUUFBTSxVQUFVLE1BQU0sZ0JBQWdCO0FBQ3RDLG9CQUFrQixTQUFTLFVBQVUsS0FBSyxDQUFDO0FBQzNDLGtCQUFnQixjQUNkLFVBQVUsSUFDTixVQUNFLG9CQUNBLGFBQ0YsR0FBRyxPQUFPLEtBQUssQ0FBQyxVQUFVLFVBQVUsa0JBQWUsRUFBRTtBQUMzRCxxQkFBbUIsU0FBUztBQUM1QixxQkFBbUIsV0FBVyxVQUFVO0FBQ3hDLHNCQUFvQixTQUFTLENBQUM7QUFDaEM7QUFFQSxTQUFTLGtCQUFrQixPQUE2QjtBQUN0RCxRQUFNLEtBQUssTUFBTSxTQUFTLFlBQVk7QUFDdEMsZUFBYSxVQUFVO0FBQ3ZCLGNBQVksY0FBYyxLQUFLLE9BQU87QUFDdEMsV0FBUyxLQUFLLFVBQVUsT0FBTyxVQUFVLENBQUMsRUFBRTtBQUM5QztBQUVBLFNBQVMsZ0JBQWdCLE9BQTZCO0FBQ3BELG1CQUFpQixVQUFVLE1BQU0sU0FBUztBQUMxQyxRQUFNLE9BQU8sTUFBTSxTQUFTO0FBQzVCLHFCQUFtQixRQUFRLE9BQU8sSUFBSTtBQUN0QyxtQkFBaUIsY0FBYyxPQUFPLElBQUk7QUFDMUMsTUFBSSxNQUFNLFNBQVMsWUFBWTtBQUM3QixVQUFNLElBQUksTUFBTSxXQUFXO0FBQzNCLHFCQUFpQixjQUNmLE1BQU0sSUFBSSw2QkFBd0IsdUJBQWtCLENBQUMsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNO0FBQ25GLHFCQUFpQixZQUFZO0FBQUEsRUFDL0IsT0FBTztBQUNMLHFCQUFpQixjQUFjO0FBQy9CLHFCQUFpQixZQUFZO0FBQUEsRUFDL0I7QUFDRjtBQUVBLFNBQVMsYUFBYSxPQUE2QjtBQUNqRCxRQUFNLFFBQVEsTUFBTSxhQUFhO0FBQ2pDLFFBQU0sVUFBVSxNQUFNLGFBQWE7QUFDbkMsaUJBQWUsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUN4QyxlQUFhLGNBQ1gsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELGtCQUFnQixTQUFTO0FBQ3pCLGtCQUFnQixXQUFXLFVBQVU7QUFDckMsbUJBQWlCLFNBQVMsQ0FBQztBQUM3QjtBQUVBLGVBQWUsa0JBQWlDO0FBRzlDLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVTtBQUN6RCxRQUFNLFNBQVUsT0FBTyxZQUF1QyxDQUFDO0FBQy9ELGlCQUFlLE1BQU07QUFDdkI7QUFJQSxjQUFjLGlCQUFpQixTQUFTLFlBQVk7QUFDbEQsZ0JBQWMsV0FBVztBQUN6QixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFBQSxFQUNwQyxVQUFFO0FBQ0Esa0JBQWMsV0FBVztBQUFBLEVBQzNCO0FBQ0YsQ0FBQztBQUVELGVBQWUsaUJBQWlCLFNBQVMsWUFBWTtBQUNuRCxpQkFBZSxXQUFXO0FBQzFCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQUEsRUFDMUMsVUFBRTtBQUNBLG1CQUFlLFdBQVc7QUFBQSxFQUM1QjtBQUNGLENBQUM7QUFFRCxTQUFTLGlCQUFpQixTQUFTLFlBQVk7QUFDN0MsV0FBUyxXQUFXO0FBQ3BCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLFlBQVksQ0FBQztBQUFBLEVBQ2xDLFVBQUU7QUFDQSxhQUFTLFdBQVc7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxXQUFXLGlCQUFpQixVQUFVLE1BQU07QUFDMUMsT0FBSyxLQUFLLEVBQUUsTUFBTSx1QkFBdUIsSUFBSSxXQUFXLFFBQVEsQ0FBQztBQUNuRSxDQUFDO0FBRUQsYUFBYSxpQkFBaUIsVUFBVSxNQUFNO0FBQzVDLE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLElBQUksYUFBYSxRQUFRLENBQUM7QUFDaEUsQ0FBQztBQUVELGlCQUFpQixpQkFBaUIsVUFBVSxNQUFNO0FBQ2hELE9BQUssS0FBSyxFQUFFLE1BQU0sc0JBQXNCLElBQUksaUJBQWlCLFFBQVEsQ0FBQztBQUN4RSxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQsbUJBQWlCLGNBQWMsbUJBQW1CO0FBQ3BELENBQUM7QUFDRCxtQkFBbUIsaUJBQWlCLFVBQVUsTUFBTTtBQUNsRCxRQUFNLFVBQVUsT0FBTyxtQkFBbUIsS0FBSztBQUMvQyxNQUFJLE9BQU8sU0FBUyxPQUFPLEdBQUc7QUFDNUIsU0FBSyxLQUFLLEVBQUUsTUFBTSw0QkFBNEIsUUFBUSxDQUFDO0FBQUEsRUFDekQ7QUFDRixDQUFDO0FBRUQsZ0JBQWdCLGlCQUFpQixTQUFTLE1BQU07QUFDOUMsa0JBQWdCLFdBQVc7QUFDM0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNqRCxvQkFBZ0IsV0FBVztBQUFBLEVBQzdCLENBQUM7QUFDSCxDQUFDO0FBRUQsaUJBQWlCLGlCQUFpQixTQUFTLE1BQU07QUFDL0MsbUJBQWlCLFdBQVc7QUFDNUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNsRCxxQkFBaUIsV0FBVztBQUFBLEVBQzlCLENBQUM7QUFDSCxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQscUJBQW1CLFdBQVc7QUFDOUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNyRCx1QkFBbUIsV0FBVztBQUFBLEVBQ2hDLENBQUM7QUFDSCxDQUFDO0FBRUQsb0JBQW9CLGlCQUFpQixTQUFTLE1BQU07QUFDbEQsc0JBQW9CLFdBQVc7QUFDL0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUN0RCx3QkFBb0IsV0FBVztBQUFBLEVBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRUQsWUFBWSxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3BDLENBQUM7QUFFRCxXQUFXLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNqRCxJQUFFLGVBQWU7QUFDakIsT0FBSyxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDbkMsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsWUFBWTtBQUNoRCxRQUFNLEtBQUssRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3JDLGlCQUFlLENBQUMsQ0FBQztBQUNuQixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLFFBQWlCO0FBQ3RELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVO0FBQ3JDLFFBQU0sSUFBSTtBQUNWLE1BQUksRUFBRSxTQUFTLG1CQUFtQixFQUFFLE9BQU87QUFDekMsZ0JBQVksRUFBRTtBQUNkLFVBQU0sRUFBRSxLQUFLO0FBQUEsRUFDZixXQUFXLEVBQUUsU0FBUyxlQUFlLEVBQUUsT0FBTztBQUM1QyxpQkFBYSxFQUFFLEtBQUs7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxTQUFTLGFBQWEsSUFBb0I7QUFFeEMsTUFBSSxhQUFhLG1CQUFtQixVQUFVLFNBQVMsT0FBTyxHQUFHO0FBQy9ELGlCQUFhLGdCQUFnQjtBQUFBLEVBQy9CO0FBQ0EsUUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLEtBQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixRQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsS0FBRyxZQUFZO0FBQ2YsS0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFFBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxPQUFLLFlBQVk7QUFDakIsT0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsUUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLE1BQUksWUFBWTtBQUNoQixNQUFJLGNBQWMsR0FBRztBQUNyQixPQUFLLE9BQU8sR0FBRztBQUNmLFFBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLE1BQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFNBQUssT0FBTyxHQUFHO0FBQUEsRUFDakI7QUFDQSxLQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsZUFBYSxRQUFRLEVBQUU7QUFDdkIsU0FBTyxhQUFhLG9CQUFvQixtQkFBbUI7QUFDekQsaUJBQWEsa0JBQWtCLE9BQU87QUFBQSxFQUN4QztBQUNGO0FBR0EsS0FBSyxhQUFhO0FBQ2xCLEtBQUssZ0JBQWdCO0FBR3JCLFlBQVksTUFBTTtBQUNoQixPQUFLLGFBQWE7QUFDcEIsR0FBRyxJQUFNOyIsCiAgIm5hbWVzIjogW10KfQo=
