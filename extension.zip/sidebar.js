// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var recentTweetList = $("recent-tweet-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var updateExistingToggle = $("update-existing");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = isWriteAuthError(connection.error) ? "PAT can read repo but cannot write - set Contents: Read & Write" : "Auth error - check your PAT";
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  updateExistingToggle.checked = state.settings.updateExisting !== false;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  renderRecentTweets(state.recentTweetSightings);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
}
function renderRecentTweets(rows) {
  recentTweetList.replaceChildren();
  if (rows.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No tweets seen yet.";
    recentTweetList.append(li);
    return;
  }
  for (const row of rows.slice(0, 40)) {
    const li = document.createElement("li");
    li.className = `recent-tweet ${row.archive_status}`;
    const top = document.createElement("div");
    top.className = "tweet-head";
    const link = document.createElement("a");
    link.className = "tweet-handle";
    link.href = row.tweet_url;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = `@${row.account_handle}`;
    const status = document.createElement("span");
    status.className = `tweet-pill ${row.archive_status}`;
    status.textContent = row.archive_status === "saved" ? "saved" : "new";
    top.append(link, status);
    const text = document.createElement("div");
    text.className = "tweet-text";
    text.textContent = truncateText(row.text, 140);
    const meta = document.createElement("div");
    meta.className = "tweet-meta";
    meta.textContent = `${formatTweetAction(row.action)} \xB7 ${row.tweet_type} \xB7 posted ${fmtRel(row.posted_at)}`;
    li.append(top, text, meta);
    recentTweetList.append(li);
  }
}
function formatTweetAction(action) {
  if (action === "buffered") return "buffered";
  if (action === "unchanged") return "unchanged";
  return "skipped";
}
function truncateText(text, max) {
  const compact = text.replace(/\s+/g, " ").trim();
  return compact.length <= max ? compact : `${compact.slice(0, max - 1)}\u2026`;
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    const parts = [
      `${fmtNum(as.scrollCount)} scrolls`,
      `${fmtNum(as.ingestedNewCount)} new buffered`,
      `${fmtNum(as.ingestedExistingCount)} old buffered`
    ];
    if (as.skippedOldCount > 0) parts.push(`${fmtNum(as.skippedOldCount)} old skipped`);
    parts.push(`${fmtNum(as.expandedCount)} expanded`);
    autoScrollProgress.textContent = parts.join(" \xB7 ");
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
updateExistingToggle.addEventListener("change", () => {
  void send({ type: "toggle-update-existing", on: updateExistingToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBTZXR0aW5ncyA9IHtcclxuICBwYXQ6ICcnLFxyXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXHJcbiAgcmVwbzogJ3gnLFxyXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcclxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxyXG4gIGJyYW5jaDogJ21hc3RlcicsXHJcbiAgZW5hYmxlZDogdHJ1ZSxcclxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcclxuICBjb25maWd1cmVkQXQ6IG51bGwsXHJcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxyXG4gIHVwZGF0ZUV4aXN0aW5nOiB0cnVlLFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01JTl9TRUMgPSAzO1xyXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xyXG5cclxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcclxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxyXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcclxuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1JhcGlkUmVzcG9uc2U0NycsIGxhYmVsOiAnUmFwaWQgUmVzcG9uc2UgNDcnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbl07XHJcblxyXG4vLyBHcmFwaFFMIGVuZHBvaW50IG5hbWVzIHdlIGNhcmUgYWJvdXQgKG1hdGNoZWQgYnkgc3Vic3RyaW5nIGFnYWluc3QgVVJMIHBhdGgpLlxyXG5leHBvcnQgY29uc3QgVFdFRVRfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ1VzZXJUd2VldHMnLFxyXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXHJcbiAgJ1VzZXJNZWRpYScsXHJcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcclxuICAnVHdlZXREZXRhaWwnLFxyXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcclxuICAnTGlrZXMnLFxyXG4gICdCb29rbWFya3MnLFxyXG4gICdIb21lVGltZWxpbmUnLFxyXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxyXG4gICdTZWFyY2hUaW1lbGluZScsXHJcbiAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXHJcbl0pO1xyXG5cclxuLy8gRW5kcG9pbnRzIHRoYXQgY2FycnkgQ29tbXVuaXR5IE5vdGUgYm9kaWVzIFx1MjAxNCBjYXB0dXJlZCBmb3IgY29tcGxldGVuZXNzIGJ1dFxyXG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxyXG5leHBvcnQgY29uc3QgQklSRFdBVENIX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdCaXJkd2F0Y2hGZXRjaE9uZU5vdGUnLFxyXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcclxuXSk7XHJcblxyXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcclxuLy8gdG8gbGVhcm4gYWNjb3VudF9pZCA8LT4gaGFuZGxlIGJpbmRpbmdzKS5cclxuZXhwb3J0IGNvbnN0IFBST0ZJTEVfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJCeVNjcmVlbk5hbWUnLCAnVXNlckJ5UmVzdElkJ10pO1xyXG5cclxuLy8gRW5kcG9pbnRzIHdob3NlIHJlc3BvbnNlcyBhcmUgc2NvcGVkIHRvIGEgcGFydGljdWxhciBhY2NvdW50IG9yXHJcbi8vIGNvbnZlcnNhdGlvbiBcdTIwMTQgaS5lLiB2aXNpdGluZyBgLzxoYW5kbGU+YCAvIGAvPGhhbmRsZT4vd2l0aF9yZXBsaWVzYCxcclxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXHJcbi8vIGVpdGhlciBhdXRob3JlZCBieSB0aGUgdHJhY2tlZCBhY2NvdW50IG9yIGRpcmVjdGx5IHJlZmVyZW5jZWQgYnkgdGhlbVxyXG4vLyAocmV0d2VldGVkLCBxdW90ZWQsIHJlcGxpZWQgdG8pLCBzbyB3ZSBrZWVwIGV2ZXJ5dGhpbmcgd2Ugc2VlIHJhdGhlclxyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXHJcbi8vIGFjY291bnQgc3RpbGwgZ2V0cyBpdHMgb3JpZ2luYWwtdHdlZXQgY29udGVudCBhcmNoaXZlZC5cclxuLy9cclxuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXHJcbi8vIHN0aWxsIGdldCBmaWx0ZXJlZCB0byB0cmFja2VkLWhhbmRsZSBhdXRob3JzIFx1MjAxNCBzZWUgdGhlIHNwZWMnc1xyXG4vLyBcIkJyb3dzaW5nIG15IGhvbWUgdGltZWxpbmUgaXMgaWdub3JlZFwiIHJ1bGUuXHJcbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ1VzZXJUd2VldHMnLFxyXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXHJcbiAgJ1VzZXJNZWRpYScsXHJcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcclxuICAnVHdlZXREZXRhaWwnLFxyXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcclxuXSk7XHJcblxyXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cclxuZXhwb3J0IGNvbnN0IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCA9IDIwMDtcclxuXHJcbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cclxuZXhwb3J0IGNvbnN0IEZMVVNIX0lETEVfTVMgPSA0NV8wMDA7XHJcblxyXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cclxuZXhwb3J0IGNvbnN0IEZMVVNIX0FMQVJNX01JTlVURVMgPSAxO1xyXG5cclxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxyXG5leHBvcnQgY29uc3QgQUNUSVZJVFlfVEFJTF9NQVggPSAyNTA7XHJcblxyXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXHJcbmV4cG9ydCBjb25zdCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyA9IDEwICogNjAgKiAxMDAwO1xyXG5cclxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XHJcbiIsICIvKipcclxuICogc2lkZWJhci50cyBcdTIwMTQgVUkgZm9yIHRoZSBwZXJzaXN0ZW50IHNpZGViYXIuXHJcbiAqXHJcbiAqIFNpZGViYXJzIGluIEZpcmVmb3ggc3RheSBvcGVuIGFjcm9zcyB0YWIvd2luZG93IHN3aXRjaGVzLCB3aGljaCBpcyB0aGVcclxuICogaW50ZW5kZWQgcGVyc2lzdGVuY2UgbW9kZWwuIFRoaXMgbW9kdWxlIHJlbmRlcnMgc3RhdGUgcHVzaGVkIGZyb20gdGhlXHJcbiAqIGJhY2tncm91bmQgc2VydmljZSB3b3JrZXIgYW5kIGZvcndhcmRzIHVzZXIgY29tbWFuZHMgYmFjay5cclxuICovXHJcblxyXG5pbXBvcnQgeyBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XHJcbmltcG9ydCB0eXBlIHsgRXh0ZW5zaW9uU3RhdGUsIExvZ0V2ZW50LCBSdW50aW1lTWVzc2FnZSwgVHdlZXRTaWdodGluZyB9IGZyb20gJy4vbGliL3R5cGVzLmpzJztcclxuXHJcbmNvbnN0ICQgPSA8VCBleHRlbmRzIEhUTUxFbGVtZW50ID0gSFRNTEVsZW1lbnQ+KGlkOiBzdHJpbmcpOiBUID0+IHtcclxuICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcclxuICBpZiAoIWVsKSB0aHJvdyBuZXcgRXJyb3IoYG1pc3NpbmcgZWxlbWVudCAjJHtpZH1gKTtcclxuICByZXR1cm4gZWwgYXMgVDtcclxufTtcclxuXHJcbmNvbnN0IGNvbm5Eb3QgPSAkKCdjb25uLWRvdCcpO1xyXG5jb25zdCBjb25uVGV4dCA9ICQ8SFRNTFNwYW5FbGVtZW50PignY29ubi10ZXh0Jyk7XHJcbmNvbnN0IGFjY291bnRMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWNjb3VudC1saXN0Jyk7XHJcbmNvbnN0IHJlY2VudFR3ZWV0TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ3JlY2VudC10d2VldC1saXN0Jyk7XHJcbmNvbnN0IGFjdGl2aXR5TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjdGl2aXR5LWxpc3QnKTtcclxuY29uc3QgYXV0b1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tY2FwdHVyZScpO1xyXG5jb25zdCB1cGRhdGVFeGlzdGluZ1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ3VwZGF0ZS1leGlzdGluZycpO1xyXG5jb25zdCBjYXB0dXJlQWxsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtYWxsJyk7XHJcbmNvbnN0IGNhcHR1cmVUaGlzQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtdGhpcycpO1xyXG5jb25zdCBmbHVzaEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdmbHVzaC1hbGwnKTtcclxuY29uc3Qgb3B0aW9uc0xpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi1vcHRpb25zJyk7XHJcbmNvbnN0IHZpZXdlckxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi12aWV3ZXInKTtcclxuY29uc3QgY2xlYXJBY3RCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2xlYXItYWN0aXZpdHknKTtcclxuY29uc3QgZXh0VmVyc2lvbkVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdleHQtdmVyc2lvbicpO1xyXG5jb25zdCBtYXN0ZXJTd2l0Y2ggPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdtYXN0ZXItc3dpdGNoJyk7XHJcbmNvbnN0IG1hc3RlckxhYmVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtYXN0ZXItbGFiZWwnKTtcclxuY29uc3QgYXV0b1Njcm9sbEludGVydmFsID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1zY3JvbGwtaW50ZXJ2YWwnKTtcclxuY29uc3QgYXV0b1Njcm9sbFNlY3NFbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc2VjcycpO1xyXG5jb25zdCBhdXRvU2Nyb2xsU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zdGF0dXMnKTtcclxuY29uc3QgYXV0b1Njcm9sbFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXN0YXJ0Jyk7XHJcbmNvbnN0IGF1dG9TY3JvbGxDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtY2FuY2VsJyk7XHJcbmNvbnN0IGF1dG9TY3JvbGxQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtcHJvZ3Jlc3MnKTtcclxuY29uc3QgcmVmZXRjaFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PigncmVmZXRjaC1zZWN0aW9uJyk7XHJcbmNvbnN0IHJlZmV0Y2hDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1jb3VudCcpO1xyXG5jb25zdCByZWZldGNoU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1zdGFydCcpO1xyXG5jb25zdCByZWZldGNoQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZmV0Y2gtY2FuY2VsJyk7XHJcbmNvbnN0IHJlZmV0Y2hQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1wcm9ncmVzcycpO1xyXG5jb25zdCBtZWRpYUNyYXdsU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1zZWN0aW9uJyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtY291bnQnKTtcclxuY29uc3QgbWVkaWFDcmF3bFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLXN0YXJ0Jyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignbWVkaWEtY3Jhd2wtY2FuY2VsJyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtcHJvZ3Jlc3MnKTtcclxuY29uc3QgcHVyZ2VMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ3B1cmdlLXVucmVsYXRlZCcpO1xyXG5cclxubGV0IGxhc3RTdGF0ZTogRXh0ZW5zaW9uU3RhdGUgfCBudWxsID0gbnVsbDtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNlbmQ8VD4obXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8VD4ge1xyXG4gIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKSBhcyBQcm9taXNlPFQ+O1xyXG59XHJcblxyXG5mdW5jdGlvbiBzZXRDb25uU3RhdHVzKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xyXG4gIGNvbnN0IHsgY29ubmVjdGlvbiwgc2V0dGluZ3MgfSA9IHN0YXRlO1xyXG4gIGxldCBjbHMgPSAnJztcclxuICBsZXQgdGV4dCA9ICcnO1xyXG4gIC8vIE9ubHkgd2FybiB3aGVuIHRoZSBjb25maWd1cmVkIGJyYW5jaCBnZW51aW5lbHkgZG9lc24ndCBleGlzdCBvbiB0aGVcclxuICAvLyByZW1vdGUuIEEgbm9uLWRlZmF1bHQgYnJhbmNoIHRoYXQgZXhpc3RzIGlzIGZpbmUgXHUyMDE0IGNhcHR1cmluZyBpbnRvIGFcclxuICAvLyB3b3JraW5nIGJyYW5jaCBpcyByb3V0aW5lIFx1MjAxNCBzbyB0aGUgbWVyZSBgIT09YCB0byBkZWZhdWx0X2JyYW5jaCBpcyBub3RcclxuICAvLyBhIHByb2JsZW0gYW5kIHNob3VsZG4ndCBzaG91dCBpbiB0aGUgaGVhZGVyLlxyXG4gIGNvbnN0IGJyYW5jaE1pc3NpbmcgPVxyXG4gICAgY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycgJiYgc2V0dGluZ3MuYnJhbmNoICYmIGNvbm5lY3Rpb24uY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gZmFsc2U7XHJcbiAgaWYgKCFzZXR0aW5ncy5wYXRTZXQpIHtcclxuICAgIGNscyA9ICd3YXJuJztcclxuICAgIHRleHQgPSAnTm90IGNvbmZpZ3VyZWQgXHUyMDE0IG9wZW4gU2V0dGluZ3MnO1xyXG4gIH0gZWxzZSBpZiAoYnJhbmNoTWlzc2luZykge1xyXG4gICAgY2xzID0gJ2Vycic7XHJcbiAgICB0ZXh0ID0gYEJyYW5jaCBcIiR7c2V0dGluZ3MuYnJhbmNofVwiIGRvZXMgbm90IGV4aXN0IG9uICR7c2V0dGluZ3Mub3duZXJ9LyR7c2V0dGluZ3MucmVwb30gXHUyMDE0IGNvbW1pdHMgd2lsbCA0MjIuIFNldCBicmFuY2ggdG8gXCIke2Nvbm5lY3Rpb24uZGVmYXVsdEJyYW5jaCA/PyAnbWFzdGVyJ31cIiBpbiBTZXR0aW5ncy5gO1xyXG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycpIHtcclxuICAgIGNscyA9ICdvayc7XHJcbiAgICB0ZXh0ID0gYENvbm5lY3RlZCBhcyBAJHtjb25uZWN0aW9uLmxvZ2luID8/ICc/J30gdG8gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTAwQjcgXHUyMDI2JHtzZXR0aW5ncy5wYXRTdWZmaXh9YDtcclxuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcclxuICAgIGNscyA9ICdlcnInO1xyXG4gICAgdGV4dCA9IGlzV3JpdGVBdXRoRXJyb3IoY29ubmVjdGlvbi5lcnJvcilcclxuICAgICAgPyAnUEFUIGNhbiByZWFkIHJlcG8gYnV0IGNhbm5vdCB3cml0ZSAtIHNldCBDb250ZW50czogUmVhZCAmIFdyaXRlJ1xyXG4gICAgICA6ICdBdXRoIGVycm9yIC0gY2hlY2sgeW91ciBQQVQnO1xyXG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnKSB7XHJcbiAgICBjbHMgPSAnd2Fybic7XHJcbiAgICBjb25zdCByZXNldHMgPSBmbXRSYXRlTGltaXRSZXNldChjb25uZWN0aW9uLnJhdGVMaW1pdFJlc2V0QXQpO1xyXG4gICAgdGV4dCA9IHJlc2V0c1xyXG4gICAgICA/IGBHaXRIdWIgcmF0ZS1saW1pdGVkIFx1MjAxNCByZXNldHMgJHtyZXNldHN9YFxyXG4gICAgICA6ICdHaXRIdWIgcmF0ZS1saW1pdGVkIFx1MjAxNCBjYXB0dXJlcyB3aWxsIHJldHJ5JztcclxuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnbmV0d29yay1lcnJvcicpIHtcclxuICAgIGNscyA9ICdlcnInO1xyXG4gICAgdGV4dCA9ICdOZXR3b3JrIGVycm9yIFx1MjAxNCBjaGVjayBjb25uZWN0aXZpdHknO1xyXG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdub3QtY29uZmlndXJlZCcpIHtcclxuICAgIGNscyA9ICd3YXJuJztcclxuICAgIHRleHQgPSAnTm90IGNvbmZpZ3VyZWQgXHUyMDE0IG9wZW4gU2V0dGluZ3MnO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBjbHMgPSAnJztcclxuICAgIHRleHQgPSAnQ2hlY2tpbmdcdTIwMjYnO1xyXG4gIH1cclxuICBjb25uRG90LmNsYXNzTmFtZSA9IGBkb3QgJHtjbHN9YDtcclxuICBjb25uVGV4dC50ZXh0Q29udGVudCA9IHRleHQ7XHJcbiAgY29ublRleHQudGl0bGUgPSBjb25uZWN0aW9uLmVycm9yID8/ICcnO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmbXRSZWwoaXNvOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHtcclxuICBpZiAoIWlzbykgcmV0dXJuICdcdTIwMTQnO1xyXG4gIGNvbnN0IGQgPSBEYXRlLnBhcnNlKGlzbyk7XHJcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoZCkpIHJldHVybiAnXHUyMDE0JztcclxuICBjb25zdCBzZWNzID0gTWF0aC5tYXgoMCwgTWF0aC5yb3VuZCgoRGF0ZS5ub3coKSAtIGQpIC8gMTAwMCkpO1xyXG4gIGlmIChzZWNzIDwgNSkgcmV0dXJuICdqdXN0IG5vdyc7XHJcbiAgaWYgKHNlY3MgPCA2MCkgcmV0dXJuIGAke3NlY3N9cyBhZ29gO1xyXG4gIGNvbnN0IG1pbnMgPSBNYXRoLnJvdW5kKHNlY3MgLyA2MCk7XHJcbiAgaWYgKG1pbnMgPCA2MCkgcmV0dXJuIGAke21pbnN9bSBhZ29gO1xyXG4gIGNvbnN0IGhvdXJzID0gTWF0aC5yb3VuZChtaW5zIC8gNjApO1xyXG4gIGlmIChob3VycyA8IDI0KSByZXR1cm4gYCR7aG91cnN9aCBhZ29gO1xyXG4gIGNvbnN0IGRheXMgPSBNYXRoLnJvdW5kKGhvdXJzIC8gMjQpO1xyXG4gIHJldHVybiBgJHtkYXlzfWQgYWdvYDtcclxufVxyXG5cclxuZnVuY3Rpb24gZm10UmF0ZUxpbWl0UmVzZXQoZXBvY2hTZWM6IG51bWJlciB8IG51bGwpOiBzdHJpbmcge1xyXG4gIGlmIChlcG9jaFNlYyA9PT0gbnVsbCkgcmV0dXJuICcnO1xyXG4gIGNvbnN0IGRlbHRhU2VjID0gZXBvY2hTZWMgLSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcclxuICBpZiAoZGVsdGFTZWMgPD0gMCkgcmV0dXJuICdtb21lbnRhcmlseSc7XHJcbiAgY29uc3Qgd2FsbENsb2NrID0gbmV3IERhdGUoZXBvY2hTZWMgKiAxMDAwKS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHtcclxuICAgIGhvdXI6ICcyLWRpZ2l0JyxcclxuICAgIG1pbnV0ZTogJzItZGlnaXQnLFxyXG4gIH0pO1xyXG4gIGlmIChkZWx0YVNlYyA8IDYwKSByZXR1cm4gYGluICR7ZGVsdGFTZWN9cyAoJHt3YWxsQ2xvY2t9KWA7XHJcbiAgY29uc3QgbWlucyA9IE1hdGgucm91bmQoZGVsdGFTZWMgLyA2MCk7XHJcbiAgaWYgKG1pbnMgPCA2MCkgcmV0dXJuIGBpbiAke21pbnN9bSAoJHt3YWxsQ2xvY2t9KWA7XHJcbiAgY29uc3QgaG91cnMgPSBNYXRoLnJvdW5kKG1pbnMgLyA2MCk7XHJcbiAgcmV0dXJuIGBpbiAke2hvdXJzfWggKCR7d2FsbENsb2NrfSlgO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmbXROdW0objogbnVtYmVyKTogc3RyaW5nIHtcclxuICByZXR1cm4gbi50b0xvY2FsZVN0cmluZygnZW4tVVMnKTtcclxufVxyXG5cclxuZnVuY3Rpb24gaXNXcml0ZUF1dGhFcnJvcihtZXNzYWdlOiBzdHJpbmcgfCBudWxsKTogYm9vbGVhbiB7XHJcbiAgcmV0dXJuIChcclxuICAgIHR5cGVvZiBtZXNzYWdlID09PSAnc3RyaW5nJyAmJlxyXG4gICAgL1Jlc291cmNlIG5vdCBhY2Nlc3NpYmxlIGJ5IHBlcnNvbmFsIGFjY2VzcyB0b2tlbnxcXC9naXRcXC9ibG9ic3xcXC9naXRcXC9yZWZzL2kudGVzdChtZXNzYWdlKVxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlbmRlckFjY291bnRzKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xyXG4gIGFjY291bnRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xyXG4gIGlmIChzdGF0ZS5hY2NvdW50cy5sZW5ndGggPT09IDApIHtcclxuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcclxuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XHJcbiAgICBsaS50ZXh0Q29udGVudCA9ICdObyBhY2NvdW50cyBjb25maWd1cmVkLic7XHJcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBmb3IgKGNvbnN0IGEgb2Ygc3RhdGUuYWNjb3VudHMpIHtcclxuICAgIGNvbnN0IGMgPSBzdGF0ZS5jb3VudGVyc1thLmhhbmRsZV07XHJcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgICBsaS5jbGFzc05hbWUgPSBjICYmIGMuYnVmZmVyZWRDb3VudCA+IDAgPyAnYWNjIHBlbmRpbmcnIDogJ2FjYyc7XHJcblxyXG4gICAgY29uc3QgaGVhZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgaGVhZC5jbGFzc05hbWUgPSAnYWNjLWhlYWQnO1xyXG4gICAgY29uc3QgaGFuZGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgaGFuZGxlLmNsYXNzTmFtZSA9ICdhY2MtaGFuZGxlJztcclxuICAgIGhhbmRsZS5pbm5lckhUTUwgPSBgPHNwYW4gY2xhc3M9XCJhdFwiPkA8L3NwYW4+JHtlc2NhcGVIdG1sKGEuaGFuZGxlKX1gO1xyXG4gICAgY29uc3QgbWV0YSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIG1ldGEuY2xhc3NOYW1lID0gJ2FjYy1tZXRhJztcclxuICAgIG1ldGEudGV4dENvbnRlbnQgPSBhLmxhYmVsO1xyXG4gICAgaGVhZC5hcHBlbmQoaGFuZGxlLCBtZXRhKTtcclxuXHJcbiAgICBjb25zdCByb3cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIHJvdy5jbGFzc05hbWUgPSAnYWNjLXJvdyc7XHJcbiAgICBjb25zdCBzdGF0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIHN0YXRzLmNsYXNzTmFtZSA9ICdhY2Mtc3RhdHMnO1xyXG4gICAgY29uc3QgdG9kYXkgPSBjPy50b2RheUNvdW50ID8/IDA7XHJcbiAgICBjb25zdCBidWZmZXJlZCA9IGM/LmJ1ZmZlcmVkQ291bnQgPz8gMDtcclxuICAgIGNvbnN0IGxhc3QgPSBjPy5sYXN0Q2FwdHVyZUF0ID8/IG51bGw7XHJcbiAgICBzdGF0cy5pbm5lckhUTUwgPVxyXG4gICAgICBgPHNwYW4gY2xhc3M9XCJudW1cIj4ke2ZtdE51bSh0b2RheSl9PC9zcGFuPiB0b2RheWAgK1xyXG4gICAgICAoYnVmZmVyZWQgPiAwID8gYCBcdTAwQjcgPHNwYW4gY2xhc3M9XCJudW1cIj4ke2ZtdE51bShidWZmZXJlZCl9PC9zcGFuPiBidWZmZXJlZGAgOiAnJykgK1xyXG4gICAgICBgIFx1MDBCNyBsYXN0ICR7ZXNjYXBlSHRtbChmbXRSZWwobGFzdCkpfWA7XHJcblxyXG4gICAgY29uc3QgYWN0aW9ucyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIGFjdGlvbnMuY2xhc3NOYW1lID0gJ2FjYy1hY3Rpb24nO1xyXG4gICAgY29uc3QgYnRuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJyk7XHJcbiAgICBidG4uY2xhc3NOYW1lID0gJ2J0bic7XHJcbiAgICBidG4udGV4dENvbnRlbnQgPSAnQ2FwdHVyZSBub3cnO1xyXG4gICAgYnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICBidG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS1ub3cnLCBoYW5kbGU6IGEuaGFuZGxlIH0pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICAgIGFjdGlvbnMuYXBwZW5kKGJ0bik7XHJcblxyXG4gICAgcm93LmFwcGVuZChzdGF0cywgYWN0aW9ucyk7XHJcbiAgICBsaS5hcHBlbmQoaGVhZCwgcm93KTtcclxuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiByZW5kZXJBY3Rpdml0eShldmVudHM6IExvZ0V2ZW50W10pOiB2b2lkIHtcclxuICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XHJcbiAgaWYgKGV2ZW50cy5sZW5ndGggPT09IDApIHtcclxuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcclxuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XHJcbiAgICBsaS50ZXh0Q29udGVudCA9ICdObyBhY3Rpdml0eSB5ZXQuJztcclxuICAgIGFjdGl2aXR5TGlzdC5hcHBlbmQobGkpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBmb3IgKGNvbnN0IGV2IG9mIGV2ZW50cy5zbGljZSgwLCBBQ1RJVklUWV9UQUlMX01BWCkpIHtcclxuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcclxuICAgIGxpLmNsYXNzTmFtZSA9IGBldiAke2V2LmxldmVsfWA7XHJcbiAgICBjb25zdCB0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XHJcbiAgICB0cy50ZXh0Q29udGVudCA9IG5ldyBEYXRlKGV2LnRzKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLVVTJywgeyBob3VyMTI6IGZhbHNlIH0pO1xyXG4gICAgY29uc3QgaWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xyXG4gICAgaWNvbi50ZXh0Q29udGVudCA9IGV2LmxldmVsID09PSAnZXJyb3InID8gJ1x1MjcxNycgOiBldi5sZXZlbCA9PT0gJ3dhcm4nID8gJyEnIDogJ1x1MDBCNyc7XHJcbiAgICBjb25zdCBib2R5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICBtc2cuY2xhc3NOYW1lID0gJ2V2LW1zZyc7XHJcbiAgICBtc2cudGV4dENvbnRlbnQgPSBldi5tc2c7XHJcbiAgICBib2R5LmFwcGVuZChtc2cpO1xyXG4gICAgY29uc3QgY3R4S2V5cyA9IE9iamVjdC5rZXlzKGV2LmNvbnRleHQpO1xyXG4gICAgaWYgKGN0eEtleXMubGVuZ3RoID4gMCkge1xyXG4gICAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgICAgY3R4LmNsYXNzTmFtZSA9ICdldi1jdHgnO1xyXG4gICAgICBjdHgudGV4dENvbnRlbnQgPSBjdHhLZXlzLm1hcCgoaykgPT4gYCR7a309JHtzdHJpbmdpZnlTaG9ydChldi5jb250ZXh0W2tdKX1gKS5qb2luKCcgXHUwMEI3ICcpO1xyXG4gICAgICBib2R5LmFwcGVuZChjdHgpO1xyXG4gICAgfVxyXG4gICAgbGkuYXBwZW5kKHRzLCBpY29uLCBib2R5KTtcclxuICAgIGFjdGl2aXR5TGlzdC5hcHBlbmQobGkpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gc3RyaW5naWZ5U2hvcnQodjogdW5rbm93bik6IHN0cmluZyB7XHJcbiAgaWYgKHYgPT09IG51bGwpIHJldHVybiAnbnVsbCc7XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJykgcmV0dXJuIHYubGVuZ3RoID4gODAgPyBgJHt2LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdjtcclxuICBpZiAodHlwZW9mIHYgPT09ICdudW1iZXInIHx8IHR5cGVvZiB2ID09PSAnYm9vbGVhbicpIHJldHVybiBTdHJpbmcodik7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHMgPSBKU09OLnN0cmluZ2lmeSh2KTtcclxuICAgIHJldHVybiBzLmxlbmd0aCA+IDgwID8gYCR7cy5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHM7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICByZXR1cm4gJz8nO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZXNjYXBlSHRtbChzOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIHJldHVybiBzLnJlcGxhY2UoL1smPD5cIiddL2csIChjKSA9PlxyXG4gICAgYyA9PT0gJyYnID8gJyZhbXA7JyA6IGMgPT09ICc8JyA/ICcmbHQ7JyA6IGMgPT09ICc+JyA/ICcmZ3Q7JyA6IGMgPT09ICdcIicgPyAnJnF1b3Q7JyA6ICcmIzM5OydcclxuICApO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoU3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgdHJ5IHtcclxuICAgIGxhc3RTdGF0ZSA9IGF3YWl0IHNlbmQ8RXh0ZW5zaW9uU3RhdGU+KHsgdHlwZTogJ2dldC1zdGF0ZScgfSk7XHJcbiAgICBwYWludChsYXN0U3RhdGUpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNpZGViYXIgcmVmcmVzaFN0YXRlIGZhaWxlZCcsIGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBwYWludChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBleHRWZXJzaW9uRWwudGV4dENvbnRlbnQgPSBzdGF0ZS52ZXJzaW9uO1xyXG4gIHNldENvbm5TdGF0dXMoc3RhdGUpO1xyXG4gIGF1dG9Ub2dnbGUuY2hlY2tlZCA9IHN0YXRlLnNldHRpbmdzLmF1dG9DYXB0dXJlO1xyXG4gIHVwZGF0ZUV4aXN0aW5nVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy51cGRhdGVFeGlzdGluZyAhPT0gZmFsc2U7XHJcbiAgdmlld2VyTGluay5ocmVmID0gYGh0dHBzOi8vJHtzdGF0ZS5zZXR0aW5ncy5vd25lcn0uZ2l0aHViLmlvLyR7c3RhdGUuc2V0dGluZ3MucmVwb30vYDtcclxuICBwYWludE1hc3RlclN3aXRjaChzdGF0ZSk7XHJcbiAgcmVuZGVyQWNjb3VudHMoc3RhdGUpO1xyXG4gIHJlbmRlclJlY2VudFR3ZWV0cyhzdGF0ZS5yZWNlbnRUd2VldFNpZ2h0aW5ncyk7XHJcbiAgcGFpbnRBdXRvU2Nyb2xsKHN0YXRlKTtcclxuICBwYWludE1lZGlhQ3Jhd2woc3RhdGUpO1xyXG4gIHBhaW50UmVmZXRjaChzdGF0ZSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlbmRlclJlY2VudFR3ZWV0cyhyb3dzOiBUd2VldFNpZ2h0aW5nW10pOiB2b2lkIHtcclxuICByZWNlbnRUd2VldExpc3QucmVwbGFjZUNoaWxkcmVuKCk7XHJcbiAgaWYgKHJvd3MubGVuZ3RoID09PSAwKSB7XHJcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xyXG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gdHdlZXRzIHNlZW4geWV0Lic7XHJcbiAgICByZWNlbnRUd2VldExpc3QuYXBwZW5kKGxpKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgZm9yIChjb25zdCByb3cgb2Ygcm93cy5zbGljZSgwLCA0MCkpIHtcclxuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcclxuICAgIGxpLmNsYXNzTmFtZSA9IGByZWNlbnQtdHdlZXQgJHtyb3cuYXJjaGl2ZV9zdGF0dXN9YDtcclxuXHJcbiAgICBjb25zdCB0b3AgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIHRvcC5jbGFzc05hbWUgPSAndHdlZXQtaGVhZCc7XHJcbiAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xyXG4gICAgbGluay5jbGFzc05hbWUgPSAndHdlZXQtaGFuZGxlJztcclxuICAgIGxpbmsuaHJlZiA9IHJvdy50d2VldF91cmw7XHJcbiAgICBsaW5rLnRhcmdldCA9ICdfYmxhbmsnO1xyXG4gICAgbGluay5yZWwgPSAnbm9vcGVuZXInO1xyXG4gICAgbGluay50ZXh0Q29udGVudCA9IGBAJHtyb3cuYWNjb3VudF9oYW5kbGV9YDtcclxuICAgIGNvbnN0IHN0YXR1cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICAgIHN0YXR1cy5jbGFzc05hbWUgPSBgdHdlZXQtcGlsbCAke3Jvdy5hcmNoaXZlX3N0YXR1c31gO1xyXG4gICAgc3RhdHVzLnRleHRDb250ZW50ID0gcm93LmFyY2hpdmVfc3RhdHVzID09PSAnc2F2ZWQnID8gJ3NhdmVkJyA6ICduZXcnO1xyXG4gICAgdG9wLmFwcGVuZChsaW5rLCBzdGF0dXMpO1xyXG5cclxuICAgIGNvbnN0IHRleHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIHRleHQuY2xhc3NOYW1lID0gJ3R3ZWV0LXRleHQnO1xyXG4gICAgdGV4dC50ZXh0Q29udGVudCA9IHRydW5jYXRlVGV4dChyb3cudGV4dCwgMTQwKTtcclxuXHJcbiAgICBjb25zdCBtZXRhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICBtZXRhLmNsYXNzTmFtZSA9ICd0d2VldC1tZXRhJztcclxuICAgIG1ldGEudGV4dENvbnRlbnQgPVxyXG4gICAgICBgJHtmb3JtYXRUd2VldEFjdGlvbihyb3cuYWN0aW9uKX0gXHUwMEI3ICR7cm93LnR3ZWV0X3R5cGV9IFx1MDBCNyBwb3N0ZWQgJHtmbXRSZWwocm93LnBvc3RlZF9hdCl9YDtcclxuXHJcbiAgICBsaS5hcHBlbmQodG9wLCB0ZXh0LCBtZXRhKTtcclxuICAgIHJlY2VudFR3ZWV0TGlzdC5hcHBlbmQobGkpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gZm9ybWF0VHdlZXRBY3Rpb24oYWN0aW9uOiBUd2VldFNpZ2h0aW5nWydhY3Rpb24nXSk6IHN0cmluZyB7XHJcbiAgaWYgKGFjdGlvbiA9PT0gJ2J1ZmZlcmVkJykgcmV0dXJuICdidWZmZXJlZCc7XHJcbiAgaWYgKGFjdGlvbiA9PT0gJ3VuY2hhbmdlZCcpIHJldHVybiAndW5jaGFuZ2VkJztcclxuICByZXR1cm4gJ3NraXBwZWQnO1xyXG59XHJcblxyXG5mdW5jdGlvbiB0cnVuY2F0ZVRleHQodGV4dDogc3RyaW5nLCBtYXg6IG51bWJlcik6IHN0cmluZyB7XHJcbiAgY29uc3QgY29tcGFjdCA9IHRleHQucmVwbGFjZSgvXFxzKy9nLCAnICcpLnRyaW0oKTtcclxuICByZXR1cm4gY29tcGFjdC5sZW5ndGggPD0gbWF4ID8gY29tcGFjdCA6IGAke2NvbXBhY3Quc2xpY2UoMCwgbWF4IC0gMSl9XHUyMDI2YDtcclxufVxyXG5cclxuZnVuY3Rpb24gcGFpbnRNZWRpYUNyYXdsKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xyXG4gIGNvbnN0IHEgPSBzdGF0ZS5tZWRpYUNyYXdsUXVldWU7XHJcbiAgY29uc3QgdG90YWwgPSBxLnRvdGFsO1xyXG4gIGNvbnN0IHJ1bm5pbmcgPSBxLnJ1bm5pbmc7XHJcbiAgbWVkaWFDcmF3bFNlY3Rpb24uaGlkZGVuID0gdG90YWwgPT09IDAgJiYgIXJ1bm5pbmc7XHJcbiAgbWVkaWFDcmF3bENvdW50LnRleHRDb250ZW50ID1cclxuICAgIHRvdGFsID09PSAwXHJcbiAgICAgID8gcnVubmluZ1xyXG4gICAgICAgID8gJ2ZpbmlzaGluZ1x1MjAyNidcclxuICAgICAgICA6ICcwIHF1ZXVlZCdcclxuICAgICAgOiBgJHtmbXROdW0odG90YWwpfSBxdWV1ZWQke3J1bm5pbmcgPyAnIFx1MDBCNyBydW5uaW5nJyA6ICcnfWA7XHJcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmhpZGRlbiA9IHJ1bm5pbmc7XHJcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmRpc2FibGVkID0gdG90YWwgPT09IDA7XHJcbiAgbWVkaWFDcmF3bENhbmNlbEJ0bi5oaWRkZW4gPSAhcnVubmluZztcclxuICBwYWludFF1ZXVlUHJvZ3Jlc3MobWVkaWFDcmF3bFByb2dyZXNzLCBxKTtcclxufVxyXG5cclxuZnVuY3Rpb24gcGFpbnRRdWV1ZVByb2dyZXNzKFxyXG4gIGVsOiBIVE1MU3BhbkVsZW1lbnQsXHJcbiAgcTogeyBwcm9jZXNzZWQ6IG51bWJlcjsgdG90YWxfYXRfc3RhcnQ6IG51bWJlcjsgcnVubmluZzogYm9vbGVhbjsgdG90YWw6IG51bWJlciB9XHJcbik6IHZvaWQge1xyXG4gIGlmICghcS5ydW5uaW5nICYmIHEucHJvY2Vzc2VkID09PSAwKSB7XHJcbiAgICBlbC5oaWRkZW4gPSB0cnVlO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICAvLyBEZW5vbWluYXRvcjogbWF4IG9mIGluaXRpYWwgdG90YWwgYW5kIGN1cnJlbnQgcHJvY2Vzc2VkK3JlbWFpbmluZyBzbyB0aGVcclxuICAvLyBiYXIgc3RpbGwgbWFrZXMgc2Vuc2UgaWYgbmV3IGVudHJpZXMgd2VyZSBlbnF1ZXVlZCBtaWQtcnVuLlxyXG4gIGNvbnN0IGRlbm9tID0gTWF0aC5tYXgocS50b3RhbF9hdF9zdGFydCwgcS5wcm9jZXNzZWQgKyBxLnRvdGFsKTtcclxuICBlbC5oaWRkZW4gPSBmYWxzZTtcclxuICBlbC50ZXh0Q29udGVudCA9IGAke2ZtdE51bShxLnByb2Nlc3NlZCl9IC8gJHtmbXROdW0oZGVub20pfSBwcm9jZXNzZWRgO1xyXG4gIGVsLmNsYXNzTmFtZSA9IHEucnVubmluZyA/ICdwcm9ncmVzcyBvbicgOiAncHJvZ3Jlc3MnO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYWludE1hc3RlclN3aXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBjb25zdCBvbiA9IHN0YXRlLnNldHRpbmdzLmVuYWJsZWQgIT09IGZhbHNlO1xyXG4gIG1hc3RlclN3aXRjaC5jaGVja2VkID0gb247XHJcbiAgbWFzdGVyTGFiZWwudGV4dENvbnRlbnQgPSBvbiA/ICdPTicgOiAnUEFVU0VEJztcclxuICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC50b2dnbGUoJ3BhdXNlZCcsICFvbik7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhaW50QXV0b1Njcm9sbChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBjb25zdCBzZWNzID0gc3RhdGUuc2V0dGluZ3MuYXV0b1Njcm9sbEludGVydmFsU2VjO1xyXG4gIGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZSA9IFN0cmluZyhzZWNzKTtcclxuICBhdXRvU2Nyb2xsU2Vjc0VsLnRleHRDb250ZW50ID0gU3RyaW5nKHNlY3MpO1xyXG4gIGNvbnN0IGFzID0gc3RhdGUuYXV0b1Njcm9sbDtcclxuICBhdXRvU2Nyb2xsU3RhcnRCdG4uaGlkZGVuID0gYXMuYWN0aXZlO1xyXG4gIGF1dG9TY3JvbGxDYW5jZWxCdG4uaGlkZGVuID0gIWFzLmFjdGl2ZTtcclxuICBpZiAoYXMuYWN0aXZlKSB7XHJcbiAgICBjb25zdCBuID0gYXMudGFiQ291bnQ7XHJcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLnRleHRDb250ZW50ID1cclxuICAgICAgbiA9PT0gMCA/IGBydW5uaW5nIFx1MjAxNCBubyBYIHRhYnMgb3BlbmAgOiBgcnVubmluZyBcdTIwMTQgJHtufSAke24gPT09IDEgPyAndGFiJyA6ICd0YWJzJ31gO1xyXG4gICAgYXV0b1Njcm9sbFN0YXR1cy5jbGFzc05hbWUgPSAnbXV0ZWQgb24nO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLnRleHRDb250ZW50ID0gJ2lkbGUnO1xyXG4gICAgYXV0b1Njcm9sbFN0YXR1cy5jbGFzc05hbWUgPSAnbXV0ZWQnO1xyXG4gIH1cclxuICBpZiAoYXMuYWN0aXZlIHx8IGFzLnNjcm9sbENvdW50ID4gMCB8fCBhcy5pbmdlc3RlZENvdW50ID4gMCkge1xyXG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmhpZGRlbiA9IGZhbHNlO1xyXG4gICAgY29uc3QgcGFydHMgPSBbXHJcbiAgICAgIGAke2ZtdE51bShhcy5zY3JvbGxDb3VudCl9IHNjcm9sbHNgLFxyXG4gICAgICBgJHtmbXROdW0oYXMuaW5nZXN0ZWROZXdDb3VudCl9IG5ldyBidWZmZXJlZGAsXHJcbiAgICAgIGAke2ZtdE51bShhcy5pbmdlc3RlZEV4aXN0aW5nQ291bnQpfSBvbGQgYnVmZmVyZWRgLFxyXG4gICAgXTtcclxuICAgIGlmIChhcy5za2lwcGVkT2xkQ291bnQgPiAwKSBwYXJ0cy5wdXNoKGAke2ZtdE51bShhcy5za2lwcGVkT2xkQ291bnQpfSBvbGQgc2tpcHBlZGApO1xyXG4gICAgcGFydHMucHVzaChgJHtmbXROdW0oYXMuZXhwYW5kZWRDb3VudCl9IGV4cGFuZGVkYCk7XHJcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MudGV4dENvbnRlbnQgPSBwYXJ0cy5qb2luKCcgXHUwMEI3ICcpO1xyXG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmNsYXNzTmFtZSA9IGFzLmFjdGl2ZSA/ICdwcm9ncmVzcyBvbicgOiAncHJvZ3Jlc3MnO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuaGlkZGVuID0gdHJ1ZTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhaW50UmVmZXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBjb25zdCBxID0gc3RhdGUucmVmZXRjaFF1ZXVlO1xyXG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcclxuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xyXG4gIHJlZmV0Y2hTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xyXG4gIHJlZmV0Y2hDb3VudC50ZXh0Q29udGVudCA9XHJcbiAgICB0b3RhbCA9PT0gMFxyXG4gICAgICA/IHJ1bm5pbmdcclxuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXHJcbiAgICAgICAgOiAnMCBxdWV1ZWQnXHJcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xyXG4gIHJlZmV0Y2hTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xyXG4gIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xyXG4gIHJlZmV0Y2hDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XHJcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKHJlZmV0Y2hQcm9ncmVzcywgcSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hBY3Rpdml0eSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICAvLyBQdWxsIHN0cmFpZ2h0IGZyb20gc3RvcmFnZSBvbiBmaXJzdCByZW5kZXI7IGxpdmUgdXBkYXRlcyBjb21lIHZpYVxyXG4gIC8vIGBsb2ctZXZlbnRgIGJyb2FkY2FzdHMuXHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldCgnYWN0aXZpdHknKTtcclxuICBjb25zdCBldmVudHMgPSAoc3RvcmVkLmFjdGl2aXR5IGFzIExvZ0V2ZW50W10gfCB1bmRlZmluZWQpID8/IFtdO1xyXG4gIHJlbmRlckFjdGl2aXR5KGV2ZW50cyk7XHJcbn1cclxuXHJcbi8vIC0tLSBXaXJlIHVwIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5jYXB0dXJlQWxsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xyXG4gIGNhcHR1cmVBbGxCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtYWxsJyB9KTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgY2FwdHVyZUFsbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH1cclxufSk7XHJcblxyXG5jYXB0dXJlVGhpc0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICBjYXB0dXJlVGhpc0J0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS10aGlzLXBhZ2UnIH0pO1xyXG4gIH0gZmluYWxseSB7XHJcbiAgICBjYXB0dXJlVGhpc0J0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH1cclxufSk7XHJcblxyXG5mbHVzaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICBmbHVzaEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnZmx1c2gtYWxsJyB9KTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgZmx1c2hCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9XHJcbn0pO1xyXG5cclxuYXV0b1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1hdXRvLWNhcHR1cmUnLCBvbjogYXV0b1RvZ2dsZS5jaGVja2VkIH0pO1xyXG59KTtcclxuXHJcbnVwZGF0ZUV4aXN0aW5nVG9nZ2xlLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcclxuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLXVwZGF0ZS1leGlzdGluZycsIG9uOiB1cGRhdGVFeGlzdGluZ1RvZ2dsZS5jaGVja2VkIH0pO1xyXG59KTtcclxuXHJcbm1hc3RlclN3aXRjaC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1lbmFibGVkJywgb246IG1hc3RlclN3aXRjaC5jaGVja2VkIH0pO1xyXG59KTtcclxuXHJcbmF1dG9TY3JvbGxTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC1hdXRvLXNjcm9sbCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9KTtcclxufSk7XHJcbmF1dG9TY3JvbGxDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgYXV0b1Njcm9sbENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1hdXRvLXNjcm9sbCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JywgKCkgPT4ge1xyXG4gIGF1dG9TY3JvbGxTZWNzRWwudGV4dENvbnRlbnQgPSBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWU7XHJcbn0pO1xyXG5hdXRvU2Nyb2xsSW50ZXJ2YWwuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xyXG4gIGNvbnN0IHNlY29uZHMgPSBOdW1iZXIoYXV0b1Njcm9sbEludGVydmFsLnZhbHVlKTtcclxuICBpZiAoTnVtYmVyLmlzRmluaXRlKHNlY29uZHMpKSB7XHJcbiAgICB2b2lkIHNlbmQoeyB0eXBlOiAnc2V0LWF1dG8tc2Nyb2xsLWludGVydmFsJywgc2Vjb25kcyB9KTtcclxuICB9XHJcbn0pO1xyXG5cclxucHVyZ2VMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XHJcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIGNvbnN0IG9rID0gd2luZG93LmNvbmZpcm0oXHJcbiAgICAnRHJvcCBldmVyeSBjb3VudGVyLCBydW4gYnVmZmVyLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcXVldWUgZW50cnkgZm9yIGFjY291bnRzIG5vdCBpbiB5b3VyIHRyYWNrZWQgbGlzdD9cXG5cXG4nICtcclxuICAgICAgJ1RoaXMgb25seSB0b3VjaGVzIGxvY2FsIGV4dGVuc2lvbiBzdGF0ZS4gQWxyZWFkeS1jb21taXR0ZWQgZmlsZXMgaW4gdGhlIEdpdEh1YiByZXBvIGFyZSBub3QgYWZmZWN0ZWQgXHUyMDE0ICcgK1xyXG4gICAgICAncnVuIHNjcmlwdHMvcHVyZ2VfdW5yZWxhdGVkLnB5IHNlcGFyYXRlbHkgaWYgeW91IGFsc28gd2FudCB0byBzY3J1YiB0aGUgcmVwby4nXHJcbiAgKTtcclxuICBpZiAoIW9rKSByZXR1cm47XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3B1cmdlLXVucmVsYXRlZCcgfSk7XHJcbn0pO1xyXG5cclxucmVmZXRjaFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xyXG4gICAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxucmVmZXRjaENhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xyXG4gICAgcmVmZXRjaENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH0pO1xyXG59KTtcclxuXHJcbm1lZGlhQ3Jhd2xTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC1tZWRpYS1jcmF3bCcgfSkuZmluYWxseSgoKSA9PiB7XHJcbiAgICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9KTtcclxufSk7XHJcblxyXG5tZWRpYUNyYXdsQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xyXG4gICAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH0pO1xyXG59KTtcclxuXHJcbm9wdGlvbnNMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XHJcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdvcGVuLW9wdGlvbnMnIH0pO1xyXG59KTtcclxuXHJcbnZpZXdlckxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcclxuICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ29wZW4tdmlld2VyJyB9KTtcclxufSk7XHJcblxyXG5jbGVhckFjdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NsZWFyLWFjdGl2aXR5JyB9KTtcclxuICByZW5kZXJBY3Rpdml0eShbXSk7XHJcbn0pO1xyXG5cclxuYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiB1bmtub3duKSA9PiB7XHJcbiAgaWYgKCFtc2cgfHwgdHlwZW9mIG1zZyAhPT0gJ29iamVjdCcpIHJldHVybjtcclxuICBjb25zdCBtID0gbXNnIGFzIHsgdHlwZT86IHN0cmluZzsgc3RhdGU/OiBFeHRlbnNpb25TdGF0ZTsgZXZlbnQ/OiBMb2dFdmVudCB9O1xyXG4gIGlmIChtLnR5cGUgPT09ICdzdGF0ZS1jaGFuZ2VkJyAmJiBtLnN0YXRlKSB7XHJcbiAgICBsYXN0U3RhdGUgPSBtLnN0YXRlO1xyXG4gICAgcGFpbnQobS5zdGF0ZSk7XHJcbiAgfSBlbHNlIGlmIChtLnR5cGUgPT09ICdsb2ctZXZlbnQnICYmIG0uZXZlbnQpIHtcclxuICAgIHByZXBlbmRFdmVudChtLmV2ZW50KTtcclxuICB9XHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gcHJlcGVuZEV2ZW50KGV2OiBMb2dFdmVudCk6IHZvaWQge1xyXG4gIC8vIElmIHRoZSBsaXN0IGlzIHNob3dpbmcgdGhlIFwiZW1wdHlcIiBwbGFjZWhvbGRlciwgY2xlYXIgaXQuXHJcbiAgaWYgKGFjdGl2aXR5TGlzdC5maXJzdEVsZW1lbnRDaGlsZD8uY2xhc3NMaXN0LmNvbnRhaW5zKCdlbXB0eScpKSB7XHJcbiAgICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XHJcbiAgfVxyXG4gIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcclxuICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xyXG4gIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XHJcbiAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcclxuICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xyXG4gIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xyXG4gIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xyXG4gIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcclxuICBib2R5LmFwcGVuZChtc2cpO1xyXG4gIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcclxuICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcclxuICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XHJcbiAgICBib2R5LmFwcGVuZChjdHgpO1xyXG4gIH1cclxuICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xyXG4gIGFjdGl2aXR5TGlzdC5wcmVwZW5kKGxpKTtcclxuICB3aGlsZSAoYWN0aXZpdHlMaXN0LmNoaWxkRWxlbWVudENvdW50ID4gQUNUSVZJVFlfVEFJTF9NQVgpIHtcclxuICAgIGFjdGl2aXR5TGlzdC5sYXN0RWxlbWVudENoaWxkPy5yZW1vdmUoKTtcclxuICB9XHJcbn1cclxuXHJcbi8vIEluaXRpYWwgcGFpbnQuXHJcbnZvaWQgcmVmcmVzaFN0YXRlKCk7XHJcbnZvaWQgcmVmcmVzaEFjdGl2aXR5KCk7XHJcblxyXG4vLyBQZXJpb2RpY2FsbHkgcmUtZmV0Y2ggc3RhdGUgc28gXCJsYXN0IGNhcHR1cmVcIiB0aW1lcyBzdGF5IGZyZXNoLlxyXG5zZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgdm9pZCByZWZyZXNoU3RhdGUoKTtcclxufSwgMTVfMDAwKTtcclxuIl0sCiAgIm1hcHBpbmdzIjogIjtBQTBGTyxJQUFNLG9CQUFvQjtBQUcxQixJQUFNLGdDQUFnQyxLQUFLLEtBQUs7OztBQ2xGdkQsSUFBTSxJQUFJLENBQXNDLE9BQWtCO0FBQ2hFLFFBQU0sS0FBSyxTQUFTLGVBQWUsRUFBRTtBQUNyQyxNQUFJLENBQUMsR0FBSSxPQUFNLElBQUksTUFBTSxvQkFBb0IsRUFBRSxFQUFFO0FBQ2pELFNBQU87QUFDVDtBQUVBLElBQU0sVUFBVSxFQUFFLFVBQVU7QUFDNUIsSUFBTSxXQUFXLEVBQW1CLFdBQVc7QUFDL0MsSUFBTSxjQUFjLEVBQW9CLGNBQWM7QUFDdEQsSUFBTSxrQkFBa0IsRUFBb0IsbUJBQW1CO0FBQy9ELElBQU0sZUFBZSxFQUFvQixlQUFlO0FBQ3hELElBQU0sYUFBYSxFQUFvQixjQUFjO0FBQ3JELElBQU0sdUJBQXVCLEVBQW9CLGlCQUFpQjtBQUNsRSxJQUFNLGdCQUFnQixFQUFxQixhQUFhO0FBQ3hELElBQU0saUJBQWlCLEVBQXFCLGNBQWM7QUFDMUQsSUFBTSxXQUFXLEVBQXFCLFdBQVc7QUFDakQsSUFBTSxjQUFjLEVBQXFCLGNBQWM7QUFDdkQsSUFBTSxhQUFhLEVBQXFCLGFBQWE7QUFDckQsSUFBTSxjQUFjLEVBQXFCLGdCQUFnQjtBQUN6RCxJQUFNLGVBQWUsRUFBbUIsYUFBYTtBQUNyRCxJQUFNLGVBQWUsRUFBb0IsZUFBZTtBQUN4RCxJQUFNLGNBQWMsRUFBbUIsY0FBYztBQUNyRCxJQUFNLHFCQUFxQixFQUFvQixzQkFBc0I7QUFDckUsSUFBTSxtQkFBbUIsRUFBbUIsa0JBQWtCO0FBQzlELElBQU0sbUJBQW1CLEVBQW1CLG9CQUFvQjtBQUNoRSxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLGlCQUFpQixFQUFlLGlCQUFpQjtBQUN2RCxJQUFNLGVBQWUsRUFBbUIsZUFBZTtBQUN2RCxJQUFNLGtCQUFrQixFQUFxQixlQUFlO0FBQzVELElBQU0sbUJBQW1CLEVBQXFCLGdCQUFnQjtBQUM5RCxJQUFNLGtCQUFrQixFQUFtQixrQkFBa0I7QUFDN0QsSUFBTSxvQkFBb0IsRUFBZSxxQkFBcUI7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsbUJBQW1CO0FBQzlELElBQU0scUJBQXFCLEVBQXFCLG1CQUFtQjtBQUNuRSxJQUFNLHNCQUFzQixFQUFxQixvQkFBb0I7QUFDckUsSUFBTSxxQkFBcUIsRUFBbUIsc0JBQXNCO0FBQ3BFLElBQU0sWUFBWSxFQUFxQixpQkFBaUI7QUFFeEQsSUFBSSxZQUFtQztBQUV2QyxlQUFlLEtBQVEsS0FBaUM7QUFDdEQsU0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ3hDO0FBRUEsU0FBUyxjQUFjLE9BQTZCO0FBQ2xELFFBQU0sRUFBRSxZQUFZLFNBQVMsSUFBSTtBQUNqQyxNQUFJLE1BQU07QUFDVixNQUFJLE9BQU87QUFLWCxRQUFNLGdCQUNKLFdBQVcsV0FBVyxRQUFRLFNBQVMsVUFBVSxXQUFXLDJCQUEyQjtBQUN6RixNQUFJLENBQUMsU0FBUyxRQUFRO0FBQ3BCLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLGVBQWU7QUFDeEIsVUFBTTtBQUNOLFdBQU8sV0FBVyxTQUFTLE1BQU0sdUJBQXVCLFNBQVMsS0FBSyxJQUFJLFNBQVMsSUFBSSw0Q0FBdUMsV0FBVyxpQkFBaUIsUUFBUTtBQUFBLEVBQ3BLLFdBQVcsV0FBVyxXQUFXLE1BQU07QUFDckMsVUFBTTtBQUNOLFdBQU8saUJBQWlCLFdBQVcsU0FBUyxHQUFHLE9BQU8sU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLGVBQU8sU0FBUyxTQUFTO0FBQUEsRUFDaEgsV0FBVyxXQUFXLFdBQVcsY0FBYztBQUM3QyxVQUFNO0FBQ04sV0FBTyxpQkFBaUIsV0FBVyxLQUFLLElBQ3BDLG9FQUNBO0FBQUEsRUFDTixXQUFXLFdBQVcsV0FBVyxnQkFBZ0I7QUFDL0MsVUFBTTtBQUNOLFVBQU0sU0FBUyxrQkFBa0IsV0FBVyxnQkFBZ0I7QUFDNUQsV0FBTyxTQUNILHFDQUFnQyxNQUFNLEtBQ3RDO0FBQUEsRUFDTixXQUFXLFdBQVcsV0FBVyxpQkFBaUI7QUFDaEQsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsV0FBVyxXQUFXLGtCQUFrQjtBQUNqRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsT0FBTztBQUNMLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNBLFVBQVEsWUFBWSxPQUFPLEdBQUc7QUFDOUIsV0FBUyxjQUFjO0FBQ3ZCLFdBQVMsUUFBUSxXQUFXLFNBQVM7QUFDdkM7QUFFQSxTQUFTLE9BQU8sS0FBNEI7QUFDMUMsTUFBSSxDQUFDLElBQUssUUFBTztBQUNqQixRQUFNLElBQUksS0FBSyxNQUFNLEdBQUc7QUFDeEIsTUFBSSxDQUFDLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUNoQyxRQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSSxDQUFDO0FBQzVELE1BQUksT0FBTyxFQUFHLFFBQU87QUFDckIsTUFBSSxPQUFPLEdBQUksUUFBTyxHQUFHLElBQUk7QUFDN0IsUUFBTSxPQUFPLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDakMsTUFBSSxPQUFPLEdBQUksUUFBTyxHQUFHLElBQUk7QUFDN0IsUUFBTSxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDbEMsTUFBSSxRQUFRLEdBQUksUUFBTyxHQUFHLEtBQUs7QUFDL0IsUUFBTSxPQUFPLEtBQUssTUFBTSxRQUFRLEVBQUU7QUFDbEMsU0FBTyxHQUFHLElBQUk7QUFDaEI7QUFFQSxTQUFTLGtCQUFrQixVQUFpQztBQUMxRCxNQUFJLGFBQWEsS0FBTSxRQUFPO0FBQzlCLFFBQU0sV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQ3hELE1BQUksWUFBWSxFQUFHLFFBQU87QUFDMUIsUUFBTSxZQUFZLElBQUksS0FBSyxXQUFXLEdBQUksRUFBRSxtQkFBbUIsQ0FBQyxHQUFHO0FBQUEsSUFDakUsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNELE1BQUksV0FBVyxHQUFJLFFBQU8sTUFBTSxRQUFRLE1BQU0sU0FBUztBQUN2RCxRQUFNLE9BQU8sS0FBSyxNQUFNLFdBQVcsRUFBRTtBQUNyQyxNQUFJLE9BQU8sR0FBSSxRQUFPLE1BQU0sSUFBSSxNQUFNLFNBQVM7QUFDL0MsUUFBTSxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDbEMsU0FBTyxNQUFNLEtBQUssTUFBTSxTQUFTO0FBQ25DO0FBRUEsU0FBUyxPQUFPLEdBQW1CO0FBQ2pDLFNBQU8sRUFBRSxlQUFlLE9BQU87QUFDakM7QUFFQSxTQUFTLGlCQUFpQixTQUFpQztBQUN6RCxTQUNFLE9BQU8sWUFBWSxZQUNuQiw2RUFBNkUsS0FBSyxPQUFPO0FBRTdGO0FBRUEsU0FBUyxlQUFlLE9BQTZCO0FBQ25ELGNBQVksZ0JBQWdCO0FBQzVCLE1BQUksTUFBTSxTQUFTLFdBQVcsR0FBRztBQUMvQixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLGdCQUFZLE9BQU8sRUFBRTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLEtBQUssTUFBTSxVQUFVO0FBQzlCLFVBQU0sSUFBSSxNQUFNLFNBQVMsRUFBRSxNQUFNO0FBQ2pDLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksS0FBSyxFQUFFLGdCQUFnQixJQUFJLGdCQUFnQjtBQUUxRCxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBQ2pCLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVk7QUFDbkIsV0FBTyxZQUFZLDRCQUE0QixXQUFXLEVBQUUsTUFBTSxDQUFDO0FBQ25FLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLEVBQUU7QUFDckIsU0FBSyxPQUFPLFFBQVEsSUFBSTtBQUV4QixVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFVBQU0sUUFBUSxTQUFTLGNBQWMsTUFBTTtBQUMzQyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxRQUFRLEdBQUcsY0FBYztBQUMvQixVQUFNLFdBQVcsR0FBRyxpQkFBaUI7QUFDckMsVUFBTSxPQUFPLEdBQUcsaUJBQWlCO0FBQ2pDLFVBQU0sWUFDSixxQkFBcUIsT0FBTyxLQUFLLENBQUMsbUJBQ2pDLFdBQVcsSUFBSSwyQkFBd0IsT0FBTyxRQUFRLENBQUMscUJBQXFCLE1BQzdFLGNBQVcsV0FBVyxPQUFPLElBQUksQ0FBQyxDQUFDO0FBRXJDLFVBQU0sVUFBVSxTQUFTLGNBQWMsTUFBTTtBQUM3QyxZQUFRLFlBQVk7QUFDcEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxRQUFRO0FBQzNDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWM7QUFDbEIsUUFBSSxpQkFBaUIsU0FBUyxZQUFZO0FBQ3hDLFVBQUksV0FBVztBQUNmLFVBQUk7QUFDRixjQUFNLEtBQUssRUFBRSxNQUFNLGVBQWUsUUFBUSxFQUFFLE9BQU8sQ0FBQztBQUFBLE1BQ3RELFVBQUU7QUFDQSxZQUFJLFdBQVc7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUNELFlBQVEsT0FBTyxHQUFHO0FBRWxCLFFBQUksT0FBTyxPQUFPLE9BQU87QUFDekIsT0FBRyxPQUFPLE1BQU0sR0FBRztBQUNuQixnQkFBWSxPQUFPLEVBQUU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyxlQUFlLFFBQTBCO0FBQ2hELGVBQWEsZ0JBQWdCO0FBQzdCLE1BQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixpQkFBYSxPQUFPLEVBQUU7QUFDdEI7QUFBQSxFQUNGO0FBQ0EsYUFBVyxNQUFNLE9BQU8sTUFBTSxHQUFHLGlCQUFpQixHQUFHO0FBQ25ELFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDN0IsVUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQ3hDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUM5RSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxHQUFHLFVBQVUsVUFBVSxXQUFNLEdBQUcsVUFBVSxTQUFTLE1BQU07QUFDNUUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLEdBQUc7QUFDckIsU0FBSyxPQUFPLEdBQUc7QUFDZixVQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTztBQUN0QyxRQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLFlBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxVQUFJLFlBQVk7QUFDaEIsVUFBSSxjQUFjLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssUUFBSztBQUN4RixXQUFLLE9BQU8sR0FBRztBQUFBLElBQ2pCO0FBQ0EsT0FBRyxPQUFPLElBQUksTUFBTSxJQUFJO0FBQ3hCLGlCQUFhLE9BQU8sRUFBRTtBQUFBLEVBQ3hCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBb0I7QUFDMUMsTUFBSSxNQUFNLEtBQU0sUUFBTztBQUN2QixNQUFJLE9BQU8sTUFBTSxTQUFVLFFBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUN6RSxNQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxVQUFXLFFBQU8sT0FBTyxDQUFDO0FBQ3BFLE1BQUk7QUFDRixVQUFNLElBQUksS0FBSyxVQUFVLENBQUM7QUFDMUIsV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsR0FBbUI7QUFDckMsU0FBTyxFQUFFO0FBQUEsSUFBUTtBQUFBLElBQVksQ0FBQyxNQUM1QixNQUFNLE1BQU0sVUFBVSxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sV0FBVztBQUFBLEVBQ3pGO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLE1BQUk7QUFDRixnQkFBWSxNQUFNLEtBQXFCLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFDNUQsVUFBTSxTQUFTO0FBQUEsRUFDakIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDZDQUE2QyxHQUFHO0FBQUEsRUFDL0Q7QUFDRjtBQUVBLFNBQVMsTUFBTSxPQUE2QjtBQUMxQyxlQUFhLGNBQWMsTUFBTTtBQUNqQyxnQkFBYyxLQUFLO0FBQ25CLGFBQVcsVUFBVSxNQUFNLFNBQVM7QUFDcEMsdUJBQXFCLFVBQVUsTUFBTSxTQUFTLG1CQUFtQjtBQUNqRSxhQUFXLE9BQU8sV0FBVyxNQUFNLFNBQVMsS0FBSyxjQUFjLE1BQU0sU0FBUyxJQUFJO0FBQ2xGLG9CQUFrQixLQUFLO0FBQ3ZCLGlCQUFlLEtBQUs7QUFDcEIscUJBQW1CLE1BQU0sb0JBQW9CO0FBQzdDLGtCQUFnQixLQUFLO0FBQ3JCLGtCQUFnQixLQUFLO0FBQ3JCLGVBQWEsS0FBSztBQUNwQjtBQUVBLFNBQVMsbUJBQW1CLE1BQTZCO0FBQ3ZELGtCQUFnQixnQkFBZ0I7QUFDaEMsTUFBSSxLQUFLLFdBQVcsR0FBRztBQUNyQixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLG9CQUFnQixPQUFPLEVBQUU7QUFDekI7QUFBQSxFQUNGO0FBQ0EsYUFBVyxPQUFPLEtBQUssTUFBTSxHQUFHLEVBQUUsR0FBRztBQUNuQyxVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZLGdCQUFnQixJQUFJLGNBQWM7QUFFakQsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixVQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7QUFDdkMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssT0FBTyxJQUFJO0FBQ2hCLFNBQUssU0FBUztBQUNkLFNBQUssTUFBTTtBQUNYLFNBQUssY0FBYyxJQUFJLElBQUksY0FBYztBQUN6QyxVQUFNLFNBQVMsU0FBUyxjQUFjLE1BQU07QUFDNUMsV0FBTyxZQUFZLGNBQWMsSUFBSSxjQUFjO0FBQ25ELFdBQU8sY0FBYyxJQUFJLG1CQUFtQixVQUFVLFVBQVU7QUFDaEUsUUFBSSxPQUFPLE1BQU0sTUFBTTtBQUV2QixVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxhQUFhLElBQUksTUFBTSxHQUFHO0FBRTdDLFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUNILEdBQUcsa0JBQWtCLElBQUksTUFBTSxDQUFDLFNBQU0sSUFBSSxVQUFVLGdCQUFhLE9BQU8sSUFBSSxTQUFTLENBQUM7QUFFeEYsT0FBRyxPQUFPLEtBQUssTUFBTSxJQUFJO0FBQ3pCLG9CQUFnQixPQUFPLEVBQUU7QUFBQSxFQUMzQjtBQUNGO0FBRUEsU0FBUyxrQkFBa0IsUUFBeUM7QUFDbEUsTUFBSSxXQUFXLFdBQVksUUFBTztBQUNsQyxNQUFJLFdBQVcsWUFBYSxRQUFPO0FBQ25DLFNBQU87QUFDVDtBQUVBLFNBQVMsYUFBYSxNQUFjLEtBQXFCO0FBQ3ZELFFBQU0sVUFBVSxLQUFLLFFBQVEsUUFBUSxHQUFHLEVBQUUsS0FBSztBQUMvQyxTQUFPLFFBQVEsVUFBVSxNQUFNLFVBQVUsR0FBRyxRQUFRLE1BQU0sR0FBRyxNQUFNLENBQUMsQ0FBQztBQUN2RTtBQUVBLFNBQVMsZ0JBQWdCLE9BQTZCO0FBQ3BELFFBQU0sSUFBSSxNQUFNO0FBQ2hCLFFBQU0sUUFBUSxFQUFFO0FBQ2hCLFFBQU0sVUFBVSxFQUFFO0FBQ2xCLG9CQUFrQixTQUFTLFVBQVUsS0FBSyxDQUFDO0FBQzNDLGtCQUFnQixjQUNkLFVBQVUsSUFDTixVQUNFLG9CQUNBLGFBQ0YsR0FBRyxPQUFPLEtBQUssQ0FBQyxVQUFVLFVBQVUsa0JBQWUsRUFBRTtBQUMzRCxxQkFBbUIsU0FBUztBQUM1QixxQkFBbUIsV0FBVyxVQUFVO0FBQ3hDLHNCQUFvQixTQUFTLENBQUM7QUFDOUIscUJBQW1CLG9CQUFvQixDQUFDO0FBQzFDO0FBRUEsU0FBUyxtQkFDUCxJQUNBLEdBQ007QUFDTixNQUFJLENBQUMsRUFBRSxXQUFXLEVBQUUsY0FBYyxHQUFHO0FBQ25DLE9BQUcsU0FBUztBQUNaO0FBQUEsRUFDRjtBQUdBLFFBQU0sUUFBUSxLQUFLLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxZQUFZLEVBQUUsS0FBSztBQUM5RCxLQUFHLFNBQVM7QUFDWixLQUFHLGNBQWMsR0FBRyxPQUFPLEVBQUUsU0FBUyxDQUFDLE1BQU0sT0FBTyxLQUFLLENBQUM7QUFDMUQsS0FBRyxZQUFZLEVBQUUsVUFBVSxnQkFBZ0I7QUFDN0M7QUFFQSxTQUFTLGtCQUFrQixPQUE2QjtBQUN0RCxRQUFNLEtBQUssTUFBTSxTQUFTLFlBQVk7QUFDdEMsZUFBYSxVQUFVO0FBQ3ZCLGNBQVksY0FBYyxLQUFLLE9BQU87QUFDdEMsV0FBUyxLQUFLLFVBQVUsT0FBTyxVQUFVLENBQUMsRUFBRTtBQUM5QztBQUVBLFNBQVMsZ0JBQWdCLE9BQTZCO0FBQ3BELFFBQU0sT0FBTyxNQUFNLFNBQVM7QUFDNUIscUJBQW1CLFFBQVEsT0FBTyxJQUFJO0FBQ3RDLG1CQUFpQixjQUFjLE9BQU8sSUFBSTtBQUMxQyxRQUFNLEtBQUssTUFBTTtBQUNqQixxQkFBbUIsU0FBUyxHQUFHO0FBQy9CLHNCQUFvQixTQUFTLENBQUMsR0FBRztBQUNqQyxNQUFJLEdBQUcsUUFBUTtBQUNiLFVBQU0sSUFBSSxHQUFHO0FBQ2IscUJBQWlCLGNBQ2YsTUFBTSxJQUFJLGtDQUE2QixrQkFBYSxDQUFDLElBQUksTUFBTSxJQUFJLFFBQVEsTUFBTTtBQUNuRixxQkFBaUIsWUFBWTtBQUFBLEVBQy9CLE9BQU87QUFDTCxxQkFBaUIsY0FBYztBQUMvQixxQkFBaUIsWUFBWTtBQUFBLEVBQy9CO0FBQ0EsTUFBSSxHQUFHLFVBQVUsR0FBRyxjQUFjLEtBQUssR0FBRyxnQkFBZ0IsR0FBRztBQUMzRCx1QkFBbUIsU0FBUztBQUM1QixVQUFNLFFBQVE7QUFBQSxNQUNaLEdBQUcsT0FBTyxHQUFHLFdBQVcsQ0FBQztBQUFBLE1BQ3pCLEdBQUcsT0FBTyxHQUFHLGdCQUFnQixDQUFDO0FBQUEsTUFDOUIsR0FBRyxPQUFPLEdBQUcscUJBQXFCLENBQUM7QUFBQSxJQUNyQztBQUNBLFFBQUksR0FBRyxrQkFBa0IsRUFBRyxPQUFNLEtBQUssR0FBRyxPQUFPLEdBQUcsZUFBZSxDQUFDLGNBQWM7QUFDbEYsVUFBTSxLQUFLLEdBQUcsT0FBTyxHQUFHLGFBQWEsQ0FBQyxXQUFXO0FBQ2pELHVCQUFtQixjQUFjLE1BQU0sS0FBSyxRQUFLO0FBQ2pELHVCQUFtQixZQUFZLEdBQUcsU0FBUyxnQkFBZ0I7QUFBQSxFQUM3RCxPQUFPO0FBQ0wsdUJBQW1CLFNBQVM7QUFBQSxFQUM5QjtBQUNGO0FBRUEsU0FBUyxhQUFhLE9BQTZCO0FBQ2pELFFBQU0sSUFBSSxNQUFNO0FBQ2hCLFFBQU0sUUFBUSxFQUFFO0FBQ2hCLFFBQU0sVUFBVSxFQUFFO0FBQ2xCLGlCQUFlLFNBQVMsVUFBVSxLQUFLLENBQUM7QUFDeEMsZUFBYSxjQUNYLFVBQVUsSUFDTixVQUNFLG9CQUNBLGFBQ0YsR0FBRyxPQUFPLEtBQUssQ0FBQyxVQUFVLFVBQVUsa0JBQWUsRUFBRTtBQUMzRCxrQkFBZ0IsU0FBUztBQUN6QixrQkFBZ0IsV0FBVyxVQUFVO0FBQ3JDLG1CQUFpQixTQUFTLENBQUM7QUFDM0IscUJBQW1CLGlCQUFpQixDQUFDO0FBQ3ZDO0FBRUEsZUFBZSxrQkFBaUM7QUFHOUMsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxVQUFVO0FBQ3pELFFBQU0sU0FBVSxPQUFPLFlBQXVDLENBQUM7QUFDL0QsaUJBQWUsTUFBTTtBQUN2QjtBQUlBLGNBQWMsaUJBQWlCLFNBQVMsWUFBWTtBQUNsRCxnQkFBYyxXQUFXO0FBQ3pCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUFBLEVBQ3BDLFVBQUU7QUFDQSxrQkFBYyxXQUFXO0FBQUEsRUFDM0I7QUFDRixDQUFDO0FBRUQsZUFBZSxpQkFBaUIsU0FBUyxZQUFZO0FBQ25ELGlCQUFlLFdBQVc7QUFDMUIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFBQSxFQUMxQyxVQUFFO0FBQ0EsbUJBQWUsV0FBVztBQUFBLEVBQzVCO0FBQ0YsQ0FBQztBQUVELFNBQVMsaUJBQWlCLFNBQVMsWUFBWTtBQUM3QyxXQUFTLFdBQVc7QUFDcEIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQUEsRUFDbEMsVUFBRTtBQUNBLGFBQVMsV0FBVztBQUFBLEVBQ3RCO0FBQ0YsQ0FBQztBQUVELFdBQVcsaUJBQWlCLFVBQVUsTUFBTTtBQUMxQyxPQUFLLEtBQUssRUFBRSxNQUFNLHVCQUF1QixJQUFJLFdBQVcsUUFBUSxDQUFDO0FBQ25FLENBQUM7QUFFRCxxQkFBcUIsaUJBQWlCLFVBQVUsTUFBTTtBQUNwRCxPQUFLLEtBQUssRUFBRSxNQUFNLDBCQUEwQixJQUFJLHFCQUFxQixRQUFRLENBQUM7QUFDaEYsQ0FBQztBQUVELGFBQWEsaUJBQWlCLFVBQVUsTUFBTTtBQUM1QyxPQUFLLEtBQUssRUFBRSxNQUFNLGtCQUFrQixJQUFJLGFBQWEsUUFBUSxDQUFDO0FBQ2hFLENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxxQkFBbUIsV0FBVztBQUM5QixPQUFLLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3JELHVCQUFtQixXQUFXO0FBQUEsRUFDaEMsQ0FBQztBQUNILENBQUM7QUFDRCxvQkFBb0IsaUJBQWlCLFNBQVMsTUFBTTtBQUNsRCxzQkFBb0IsV0FBVztBQUMvQixPQUFLLEtBQUssRUFBRSxNQUFNLHFCQUFxQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3RELHdCQUFvQixXQUFXO0FBQUEsRUFDakMsQ0FBQztBQUNILENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxtQkFBaUIsY0FBYyxtQkFBbUI7QUFDcEQsQ0FBQztBQUNELG1CQUFtQixpQkFBaUIsVUFBVSxNQUFNO0FBQ2xELFFBQU0sVUFBVSxPQUFPLG1CQUFtQixLQUFLO0FBQy9DLE1BQUksT0FBTyxTQUFTLE9BQU8sR0FBRztBQUM1QixTQUFLLEtBQUssRUFBRSxNQUFNLDRCQUE0QixRQUFRLENBQUM7QUFBQSxFQUN6RDtBQUNGLENBQUM7QUFFRCxVQUFVLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNoRCxJQUFFLGVBQWU7QUFDakIsUUFBTSxLQUFLLE9BQU87QUFBQSxJQUNoQjtBQUFBLEVBR0Y7QUFDQSxNQUFJLENBQUMsR0FBSTtBQUNULE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFDdkMsQ0FBQztBQUVELGdCQUFnQixpQkFBaUIsU0FBUyxNQUFNO0FBQzlDLGtCQUFnQixXQUFXO0FBQzNCLE9BQUssS0FBSyxFQUFFLE1BQU0sZ0JBQWdCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDakQsb0JBQWdCLFdBQVc7QUFBQSxFQUM3QixDQUFDO0FBQ0gsQ0FBQztBQUVELGlCQUFpQixpQkFBaUIsU0FBUyxNQUFNO0FBQy9DLG1CQUFpQixXQUFXO0FBQzVCLE9BQUssS0FBSyxFQUFFLE1BQU0saUJBQWlCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDbEQscUJBQWlCLFdBQVc7QUFBQSxFQUM5QixDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2xELElBQUUsZUFBZTtBQUNqQixPQUFLLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNwQyxDQUFDO0FBRUQsV0FBVyxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDakQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQ25DLENBQUM7QUFFRCxZQUFZLGlCQUFpQixTQUFTLFlBQVk7QUFDaEQsUUFBTSxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNyQyxpQkFBZSxDQUFDLENBQUM7QUFDbkIsQ0FBQztBQUVELFFBQVEsUUFBUSxVQUFVLFlBQVksQ0FBQyxRQUFpQjtBQUN0RCxNQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsU0FBVTtBQUNyQyxRQUFNLElBQUk7QUFDVixNQUFJLEVBQUUsU0FBUyxtQkFBbUIsRUFBRSxPQUFPO0FBQ3pDLGdCQUFZLEVBQUU7QUFDZCxVQUFNLEVBQUUsS0FBSztBQUFBLEVBQ2YsV0FBVyxFQUFFLFNBQVMsZUFBZSxFQUFFLE9BQU87QUFDNUMsaUJBQWEsRUFBRSxLQUFLO0FBQUEsRUFDdEI7QUFDRixDQUFDO0FBRUQsU0FBUyxhQUFhLElBQW9CO0FBRXhDLE1BQUksYUFBYSxtQkFBbUIsVUFBVSxTQUFTLE9BQU8sR0FBRztBQUMvRCxpQkFBYSxnQkFBZ0I7QUFBQSxFQUMvQjtBQUNBLFFBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxLQUFHLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDN0IsUUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQ3hDLEtBQUcsWUFBWTtBQUNmLEtBQUcsY0FBYyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUM5RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsT0FBSyxZQUFZO0FBQ2pCLE9BQUssY0FBYyxHQUFHLFVBQVUsVUFBVSxXQUFNLEdBQUcsVUFBVSxTQUFTLE1BQU07QUFDNUUsUUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFFBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxNQUFJLFlBQVk7QUFDaEIsTUFBSSxjQUFjLEdBQUc7QUFDckIsT0FBSyxPQUFPLEdBQUc7QUFDZixRQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTztBQUN0QyxNQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssUUFBSztBQUN4RixTQUFLLE9BQU8sR0FBRztBQUFBLEVBQ2pCO0FBQ0EsS0FBRyxPQUFPLElBQUksTUFBTSxJQUFJO0FBQ3hCLGVBQWEsUUFBUSxFQUFFO0FBQ3ZCLFNBQU8sYUFBYSxvQkFBb0IsbUJBQW1CO0FBQ3pELGlCQUFhLGtCQUFrQixPQUFPO0FBQUEsRUFDeEM7QUFDRjtBQUdBLEtBQUssYUFBYTtBQUNsQixLQUFLLGdCQUFnQjtBQUdyQixZQUFZLE1BQU07QUFDaEIsT0FBSyxhQUFhO0FBQ3BCLEdBQUcsSUFBTTsiLAogICJuYW1lcyI6IFtdCn0K
