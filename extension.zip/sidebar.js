// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var recentTweetList = $("recent-tweet-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var updateExistingToggle = $("update-existing");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var threadOpenSection = $("thread-open-section");
var threadOpenCount = $("thread-open-count");
var threadOpenStartBtn = $("thread-open-start");
var threadOpenCancelBtn = $("thread-open-cancel");
var threadOpenProgress = $("thread-open-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = isWriteAuthError(connection.error) ? "PAT can read repo but cannot write - set Contents: Read & Write" : "Auth error - check your PAT";
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  updateExistingToggle.checked = state.settings.updateExisting !== false;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  renderRecentTweets(state.recentTweetSightings);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
  paintThreadOpen(state);
}
function renderRecentTweets(rows) {
  recentTweetList.replaceChildren();
  if (rows.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No tweets seen yet.";
    recentTweetList.append(li);
    return;
  }
  for (const row of rows.slice(0, 40)) {
    const li = document.createElement("li");
    li.className = `recent-tweet ${row.archive_status}`;
    const top = document.createElement("div");
    top.className = "tweet-head";
    const link = document.createElement("a");
    link.className = "tweet-handle";
    link.href = row.tweet_url;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = `@${row.account_handle}`;
    const status = document.createElement("span");
    status.className = `tweet-pill ${row.archive_status}`;
    status.textContent = row.archive_status === "saved" ? "saved" : "new";
    top.append(link, status);
    const text = document.createElement("div");
    text.className = "tweet-text";
    text.textContent = truncateText(row.text, 140);
    const meta = document.createElement("div");
    meta.className = "tweet-meta";
    meta.textContent = `${formatTweetAction(row.action)} \xB7 ${row.tweet_type} \xB7 posted ${fmtRel(row.posted_at)}`;
    li.append(top, text, meta);
    recentTweetList.append(li);
  }
}
function formatTweetAction(action) {
  if (action === "buffered") return "buffered";
  if (action === "unchanged") return "unchanged";
  return "skipped";
}
function truncateText(text, max) {
  const compact = text.replace(/\s+/g, " ").trim();
  return compact.length <= max ? compact : `${compact.slice(0, max - 1)}\u2026`;
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    const parts = [
      `${fmtNum(as.scrollCount)} scrolls`,
      `${fmtNum(as.ingestedNewCount)} new buffered`,
      `${fmtNum(as.ingestedExistingCount)} old buffered`
    ];
    if (as.skippedOldCount > 0) parts.push(`${fmtNum(as.skippedOldCount)} old skipped`);
    parts.push(`${fmtNum(as.expandedCount)} expanded`);
    autoScrollProgress.textContent = parts.join(" \xB7 ");
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
function paintThreadOpen(state) {
  const q = state.threadOpenQueue;
  const total = q.total;
  const running = q.running;
  threadOpenSection.hidden = total === 0 && !running;
  threadOpenCount.textContent = total === 0 ? running ? "finishing..." : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  threadOpenStartBtn.hidden = running;
  threadOpenStartBtn.disabled = total === 0;
  threadOpenCancelBtn.hidden = !running;
  paintQueueProgress(threadOpenProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
updateExistingToggle.addEventListener("change", () => {
  void send({ type: "toggle-update-existing", on: updateExistingToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl / thread-opening queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
threadOpenStartBtn.addEventListener("click", () => {
  threadOpenStartBtn.disabled = true;
  void send({ type: "start-thread-open" }).finally(() => {
    threadOpenStartBtn.disabled = false;
  });
});
threadOpenCancelBtn.addEventListener("click", () => {
  threadOpenCancelBtn.disabled = true;
  void send({ type: "cancel-thread-open" }).finally(() => {
    threadOpenCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgZW5hYmxlZDogdHJ1ZSxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxuICB1cGRhdGVFeGlzdGluZzogdHJ1ZSxcbn07XG5cbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XG5cbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1JhcGlkUmVzcG9uc2U0NycsIGxhYmVsOiAnUmFwaWQgUmVzcG9uc2UgNDcnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnU3RlcGhlbk0nLCBsYWJlbDogJ1N0ZXBoZW4gTWlsbGVyJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0dyZWdvcnlLQm92aW5vJywgbGFiZWw6ICdHcmVnb3J5IEJvdmlubycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSZWFsVG9tSG9tYW4nLCBsYWJlbDogJ1Rob21hcyBELiBIb21hbicsIGNhdGVnb3J5OiAnY29yZScgfSxcbl07XG5cbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXG5leHBvcnQgY29uc3QgVFdFRVRfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbiAgJ0xpa2VzJyxcbiAgJ0Jvb2ttYXJrcycsXG4gICdIb21lVGltZWxpbmUnLFxuICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcbiAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXG5dKTtcblxuLy8gRW5kcG9pbnRzIHRoYXQgY2FycnkgQ29tbXVuaXR5IE5vdGUgYm9kaWVzIFx1MjAxNCBjYXB0dXJlZCBmb3IgY29tcGxldGVuZXNzIGJ1dFxuLy8gdGhleSBkb24ndCBpbnRyb2R1Y2UgbmV3IHR3ZWV0cywgc28gdGhleSBkb24ndCBuZWVkIHRvIGJlIGluIFRXRUVUX0VORFBPSU5UUy5cbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdCaXJkd2F0Y2hGZXRjaE9uZU5vdGUnLFxuICAnQmlyZHdhdGNoRmV0Y2hOb3RlcycsXG5dKTtcblxuLy8gQXV4aWxpYXJ5IGVuZHBvaW50cyB3ZSBkb24ndCBleHRyYWN0IHR3ZWV0cyBmcm9tIGJ1dCB1c2UgZm9yIGNvbnRleHQgKGUuZy4sXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxuZXhwb3J0IGNvbnN0IFBST0ZJTEVfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJCeVNjcmVlbk5hbWUnLCAnVXNlckJ5UmVzdElkJ10pO1xuXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3Jcbi8vIGNvbnZlcnNhdGlvbiBcdTIwMTQgaS5lLiB2aXNpdGluZyBgLzxoYW5kbGU+YCAvIGAvPGhhbmRsZT4vd2l0aF9yZXBsaWVzYCxcbi8vIGxvb2tpbmcgYXQgb25lIHR3ZWV0LCBldGMuIEV2ZXJ5IHR3ZWV0IHJldHVybmVkIGJ5IHRoZXNlIGVuZHBvaW50cyBpc1xuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXG4vLyAocmV0d2VldGVkLCBxdW90ZWQsIHJlcGxpZWQgdG8pLCBzbyB3ZSBrZWVwIGV2ZXJ5dGhpbmcgd2Ugc2VlIHJhdGhlclxuLy8gdGhhbiBkcm9wcGluZyBub24tdHJhY2tlZCBhdXRob3JzLiBUaGF0IHdheSBhIHJldHdlZXQgb2YgYSBub24tdHJhY2tlZFxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxuLy9cbi8vIEVuZHBvaW50cyBOT1QgaW4gdGhpcyBzZXQgKEhvbWVUaW1lbGluZSwgU2VhcmNoVGltZWxpbmUsIExpa2VzLCBldGMuKVxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXG4vLyBcIkJyb3dzaW5nIG15IGhvbWUgdGltZWxpbmUgaXMgaWdub3JlZFwiIHJ1bGUuXG5leHBvcnQgY29uc3QgVVNFUl9QQUdFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG5dKTtcblxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xuXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcblxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XG5cbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcblxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XG5cbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xuIiwgIi8qKlxuICogc2lkZWJhci50cyBcdTIwMTQgVUkgZm9yIHRoZSBwZXJzaXN0ZW50IHNpZGViYXIuXG4gKlxuICogU2lkZWJhcnMgaW4gRmlyZWZveCBzdGF5IG9wZW4gYWNyb3NzIHRhYi93aW5kb3cgc3dpdGNoZXMsIHdoaWNoIGlzIHRoZVxuICogaW50ZW5kZWQgcGVyc2lzdGVuY2UgbW9kZWwuIFRoaXMgbW9kdWxlIHJlbmRlcnMgc3RhdGUgcHVzaGVkIGZyb20gdGhlXG4gKiBiYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyIGFuZCBmb3J3YXJkcyB1c2VyIGNvbW1hbmRzIGJhY2suXG4gKi9cblxuaW1wb3J0IHsgQUNUSVZJVFlfVEFJTF9NQVggfSBmcm9tICcuL2xpYi9jb25maWcuanMnO1xuaW1wb3J0IHR5cGUgeyBFeHRlbnNpb25TdGF0ZSwgTG9nRXZlbnQsIFJ1bnRpbWVNZXNzYWdlLCBUd2VldFNpZ2h0aW5nIH0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xuXG5jb25zdCAkID0gPFQgZXh0ZW5kcyBIVE1MRWxlbWVudCA9IEhUTUxFbGVtZW50PihpZDogc3RyaW5nKTogVCA9PiB7XG4gIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xuICBpZiAoIWVsKSB0aHJvdyBuZXcgRXJyb3IoYG1pc3NpbmcgZWxlbWVudCAjJHtpZH1gKTtcbiAgcmV0dXJuIGVsIGFzIFQ7XG59O1xuXG5jb25zdCBjb25uRG90ID0gJCgnY29ubi1kb3QnKTtcbmNvbnN0IGNvbm5UZXh0ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdjb25uLXRleHQnKTtcbmNvbnN0IGFjY291bnRMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWNjb3VudC1saXN0Jyk7XG5jb25zdCByZWNlbnRUd2VldExpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdyZWNlbnQtdHdlZXQtbGlzdCcpO1xuY29uc3QgYWN0aXZpdHlMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWN0aXZpdHktbGlzdCcpO1xuY29uc3QgYXV0b1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tY2FwdHVyZScpO1xuY29uc3QgdXBkYXRlRXhpc3RpbmdUb2dnbGUgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCd1cGRhdGUtZXhpc3RpbmcnKTtcbmNvbnN0IGNhcHR1cmVBbGxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2FwdHVyZS1hbGwnKTtcbmNvbnN0IGNhcHR1cmVUaGlzQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtdGhpcycpO1xuY29uc3QgZmx1c2hCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignZmx1c2gtYWxsJyk7XG5jb25zdCBvcHRpb25zTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdvcGVuLW9wdGlvbnMnKTtcbmNvbnN0IHZpZXdlckxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi12aWV3ZXInKTtcbmNvbnN0IGNsZWFyQWN0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NsZWFyLWFjdGl2aXR5Jyk7XG5jb25zdCBleHRWZXJzaW9uRWwgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2V4dC12ZXJzaW9uJyk7XG5jb25zdCBtYXN0ZXJTd2l0Y2ggPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdtYXN0ZXItc3dpdGNoJyk7XG5jb25zdCBtYXN0ZXJMYWJlbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWFzdGVyLWxhYmVsJyk7XG5jb25zdCBhdXRvU2Nyb2xsSW50ZXJ2YWwgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1pbnRlcnZhbCcpO1xuY29uc3QgYXV0b1Njcm9sbFNlY3NFbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc2VjcycpO1xuY29uc3QgYXV0b1Njcm9sbFN0YXR1cyA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc3RhdHVzJyk7XG5jb25zdCBhdXRvU2Nyb2xsU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtc3RhcnQnKTtcbmNvbnN0IGF1dG9TY3JvbGxDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtY2FuY2VsJyk7XG5jb25zdCBhdXRvU2Nyb2xsUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXByb2dyZXNzJyk7XG5jb25zdCByZWZldGNoU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCdyZWZldGNoLXNlY3Rpb24nKTtcbmNvbnN0IHJlZmV0Y2hDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1jb3VudCcpO1xuY29uc3QgcmVmZXRjaFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZmV0Y2gtc3RhcnQnKTtcbmNvbnN0IHJlZmV0Y2hDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1jYW5jZWwnKTtcbmNvbnN0IHJlZmV0Y2hQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1wcm9ncmVzcycpO1xuY29uc3QgbWVkaWFDcmF3bFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PignbWVkaWEtY3Jhd2wtc2VjdGlvbicpO1xuY29uc3QgbWVkaWFDcmF3bENvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1jb3VudCcpO1xuY29uc3QgbWVkaWFDcmF3bFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLXN0YXJ0Jyk7XG5jb25zdCBtZWRpYUNyYXdsQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLWNhbmNlbCcpO1xuY29uc3QgbWVkaWFDcmF3bFByb2dyZXNzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1wcm9ncmVzcycpO1xuY29uc3QgdGhyZWFkT3BlblNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PigndGhyZWFkLW9wZW4tc2VjdGlvbicpO1xuY29uc3QgdGhyZWFkT3BlbkNvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCd0aHJlYWQtb3Blbi1jb3VudCcpO1xuY29uc3QgdGhyZWFkT3BlblN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3RocmVhZC1vcGVuLXN0YXJ0Jyk7XG5jb25zdCB0aHJlYWRPcGVuQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3RocmVhZC1vcGVuLWNhbmNlbCcpO1xuY29uc3QgdGhyZWFkT3BlblByb2dyZXNzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCd0aHJlYWQtb3Blbi1wcm9ncmVzcycpO1xuY29uc3QgcHVyZ2VMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ3B1cmdlLXVucmVsYXRlZCcpO1xuXG5sZXQgbGFzdFN0YXRlOiBFeHRlbnNpb25TdGF0ZSB8IG51bGwgPSBudWxsO1xuXG5hc3luYyBmdW5jdGlvbiBzZW5kPFQ+KG1zZzogUnVudGltZU1lc3NhZ2UpOiBQcm9taXNlPFQ+IHtcbiAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZShtc2cpIGFzIFByb21pc2U8VD47XG59XG5cbmZ1bmN0aW9uIHNldENvbm5TdGF0dXMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHsgY29ubmVjdGlvbiwgc2V0dGluZ3MgfSA9IHN0YXRlO1xuICBsZXQgY2xzID0gJyc7XG4gIGxldCB0ZXh0ID0gJyc7XG4gIC8vIE9ubHkgd2FybiB3aGVuIHRoZSBjb25maWd1cmVkIGJyYW5jaCBnZW51aW5lbHkgZG9lc24ndCBleGlzdCBvbiB0aGVcbiAgLy8gcmVtb3RlLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCB0aGF0IGV4aXN0cyBpcyBmaW5lIFx1MjAxNCBjYXB0dXJpbmcgaW50byBhXG4gIC8vIHdvcmtpbmcgYnJhbmNoIGlzIHJvdXRpbmUgXHUyMDE0IHNvIHRoZSBtZXJlIGAhPT1gIHRvIGRlZmF1bHRfYnJhbmNoIGlzIG5vdFxuICAvLyBhIHByb2JsZW0gYW5kIHNob3VsZG4ndCBzaG91dCBpbiB0aGUgaGVhZGVyLlxuICBjb25zdCBicmFuY2hNaXNzaW5nID1cbiAgICBjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ29rJyAmJiBzZXR0aW5ncy5icmFuY2ggJiYgY29ubmVjdGlvbi5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSBmYWxzZTtcbiAgaWYgKCFzZXR0aW5ncy5wYXRTZXQpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XG4gIH0gZWxzZSBpZiAoYnJhbmNoTWlzc2luZykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSBgQnJhbmNoIFwiJHtzZXR0aW5ncy5icmFuY2h9XCIgZG9lcyBub3QgZXhpc3Qgb24gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTIwMTQgY29tbWl0cyB3aWxsIDQyMi4gU2V0IGJyYW5jaCB0byBcIiR7Y29ubmVjdGlvbi5kZWZhdWx0QnJhbmNoID8/ICdtYXN0ZXInfVwiIGluIFNldHRpbmdzLmA7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycpIHtcbiAgICBjbHMgPSAnb2snO1xuICAgIHRleHQgPSBgQ29ubmVjdGVkIGFzIEAke2Nvbm5lY3Rpb24ubG9naW4gPz8gJz8nfSB0byAke3NldHRpbmdzLm93bmVyfS8ke3NldHRpbmdzLnJlcG99IFx1MDBCNyBcdTIwMjYke3NldHRpbmdzLnBhdFN1ZmZpeH1gO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gaXNXcml0ZUF1dGhFcnJvcihjb25uZWN0aW9uLmVycm9yKVxuICAgICAgPyAnUEFUIGNhbiByZWFkIHJlcG8gYnV0IGNhbm5vdCB3cml0ZSAtIHNldCBDb250ZW50czogUmVhZCAmIFdyaXRlJ1xuICAgICAgOiAnQXV0aCBlcnJvciAtIGNoZWNrIHlvdXIgUEFUJztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgY29uc3QgcmVzZXRzID0gZm10UmF0ZUxpbWl0UmVzZXQoY29ubmVjdGlvbi5yYXRlTGltaXRSZXNldEF0KTtcbiAgICB0ZXh0ID0gcmVzZXRzXG4gICAgICA/IGBHaXRIdWIgcmF0ZS1saW1pdGVkIFx1MjAxNCByZXNldHMgJHtyZXNldHN9YFxuICAgICAgOiAnR2l0SHViIHJhdGUtbGltaXRlZCBcdTIwMTQgY2FwdHVyZXMgd2lsbCByZXRyeSc7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICduZXR3b3JrLWVycm9yJykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSAnTmV0d29yayBlcnJvciBcdTIwMTQgY2hlY2sgY29ubmVjdGl2aXR5JztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ25vdC1jb25maWd1cmVkJykge1xuICAgIGNscyA9ICd3YXJuJztcbiAgICB0ZXh0ID0gJ05vdCBjb25maWd1cmVkIFx1MjAxNCBvcGVuIFNldHRpbmdzJztcbiAgfSBlbHNlIHtcbiAgICBjbHMgPSAnJztcbiAgICB0ZXh0ID0gJ0NoZWNraW5nXHUyMDI2JztcbiAgfVxuICBjb25uRG90LmNsYXNzTmFtZSA9IGBkb3QgJHtjbHN9YDtcbiAgY29ublRleHQudGV4dENvbnRlbnQgPSB0ZXh0O1xuICBjb25uVGV4dC50aXRsZSA9IGNvbm5lY3Rpb24uZXJyb3IgPz8gJyc7XG59XG5cbmZ1bmN0aW9uIGZtdFJlbChpc286IHN0cmluZyB8IG51bGwpOiBzdHJpbmcge1xuICBpZiAoIWlzbykgcmV0dXJuICdcdTIwMTQnO1xuICBjb25zdCBkID0gRGF0ZS5wYXJzZShpc28pO1xuICBpZiAoIU51bWJlci5pc0Zpbml0ZShkKSkgcmV0dXJuICdcdTIwMTQnO1xuICBjb25zdCBzZWNzID0gTWF0aC5tYXgoMCwgTWF0aC5yb3VuZCgoRGF0ZS5ub3coKSAtIGQpIC8gMTAwMCkpO1xuICBpZiAoc2VjcyA8IDUpIHJldHVybiAnanVzdCBub3cnO1xuICBpZiAoc2VjcyA8IDYwKSByZXR1cm4gYCR7c2Vjc31zIGFnb2A7XG4gIGNvbnN0IG1pbnMgPSBNYXRoLnJvdW5kKHNlY3MgLyA2MCk7XG4gIGlmIChtaW5zIDwgNjApIHJldHVybiBgJHttaW5zfW0gYWdvYDtcbiAgY29uc3QgaG91cnMgPSBNYXRoLnJvdW5kKG1pbnMgLyA2MCk7XG4gIGlmIChob3VycyA8IDI0KSByZXR1cm4gYCR7aG91cnN9aCBhZ29gO1xuICBjb25zdCBkYXlzID0gTWF0aC5yb3VuZChob3VycyAvIDI0KTtcbiAgcmV0dXJuIGAke2RheXN9ZCBhZ29gO1xufVxuXG5mdW5jdGlvbiBmbXRSYXRlTGltaXRSZXNldChlcG9jaFNlYzogbnVtYmVyIHwgbnVsbCk6IHN0cmluZyB7XG4gIGlmIChlcG9jaFNlYyA9PT0gbnVsbCkgcmV0dXJuICcnO1xuICBjb25zdCBkZWx0YVNlYyA9IGVwb2NoU2VjIC0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gIGlmIChkZWx0YVNlYyA8PSAwKSByZXR1cm4gJ21vbWVudGFyaWx5JztcbiAgY29uc3Qgd2FsbENsb2NrID0gbmV3IERhdGUoZXBvY2hTZWMgKiAxMDAwKS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHtcbiAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgbWludXRlOiAnMi1kaWdpdCcsXG4gIH0pO1xuICBpZiAoZGVsdGFTZWMgPCA2MCkgcmV0dXJuIGBpbiAke2RlbHRhU2VjfXMgKCR7d2FsbENsb2NrfSlgO1xuICBjb25zdCBtaW5zID0gTWF0aC5yb3VuZChkZWx0YVNlYyAvIDYwKTtcbiAgaWYgKG1pbnMgPCA2MCkgcmV0dXJuIGBpbiAke21pbnN9bSAoJHt3YWxsQ2xvY2t9KWA7XG4gIGNvbnN0IGhvdXJzID0gTWF0aC5yb3VuZChtaW5zIC8gNjApO1xuICByZXR1cm4gYGluICR7aG91cnN9aCAoJHt3YWxsQ2xvY2t9KWA7XG59XG5cbmZ1bmN0aW9uIGZtdE51bShuOiBudW1iZXIpOiBzdHJpbmcge1xuICByZXR1cm4gbi50b0xvY2FsZVN0cmluZygnZW4tVVMnKTtcbn1cblxuZnVuY3Rpb24gaXNXcml0ZUF1dGhFcnJvcihtZXNzYWdlOiBzdHJpbmcgfCBudWxsKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnICYmXG4gICAgL1Jlc291cmNlIG5vdCBhY2Nlc3NpYmxlIGJ5IHBlcnNvbmFsIGFjY2VzcyB0b2tlbnxcXC9naXRcXC9ibG9ic3xcXC9naXRcXC9yZWZzL2kudGVzdChtZXNzYWdlKVxuICApO1xufVxuXG5mdW5jdGlvbiByZW5kZXJBY2NvdW50cyhzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgYWNjb3VudExpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChzdGF0ZS5hY2NvdW50cy5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcbiAgICBsaS50ZXh0Q29udGVudCA9ICdObyBhY2NvdW50cyBjb25maWd1cmVkLic7XG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yIChjb25zdCBhIG9mIHN0YXRlLmFjY291bnRzKSB7XG4gICAgY29uc3QgYyA9IHN0YXRlLmNvdW50ZXJzW2EuaGFuZGxlXTtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gYyAmJiBjLmJ1ZmZlcmVkQ291bnQgPiAwID8gJ2FjYyBwZW5kaW5nJyA6ICdhY2MnO1xuXG4gICAgY29uc3QgaGVhZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGhlYWQuY2xhc3NOYW1lID0gJ2FjYy1oZWFkJztcbiAgICBjb25zdCBoYW5kbGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgaGFuZGxlLmNsYXNzTmFtZSA9ICdhY2MtaGFuZGxlJztcbiAgICBoYW5kbGUuaW5uZXJIVE1MID0gYDxzcGFuIGNsYXNzPVwiYXRcIj5APC9zcGFuPiR7ZXNjYXBlSHRtbChhLmhhbmRsZSl9YDtcbiAgICBjb25zdCBtZXRhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIG1ldGEuY2xhc3NOYW1lID0gJ2FjYy1tZXRhJztcbiAgICBtZXRhLnRleHRDb250ZW50ID0gYS5sYWJlbDtcbiAgICBoZWFkLmFwcGVuZChoYW5kbGUsIG1ldGEpO1xuXG4gICAgY29uc3Qgcm93ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgcm93LmNsYXNzTmFtZSA9ICdhY2Mtcm93JztcbiAgICBjb25zdCBzdGF0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBzdGF0cy5jbGFzc05hbWUgPSAnYWNjLXN0YXRzJztcbiAgICBjb25zdCB0b2RheSA9IGM/LnRvZGF5Q291bnQgPz8gMDtcbiAgICBjb25zdCBidWZmZXJlZCA9IGM/LmJ1ZmZlcmVkQ291bnQgPz8gMDtcbiAgICBjb25zdCBsYXN0ID0gYz8ubGFzdENhcHR1cmVBdCA/PyBudWxsO1xuICAgIHN0YXRzLmlubmVySFRNTCA9XG4gICAgICBgPHNwYW4gY2xhc3M9XCJudW1cIj4ke2ZtdE51bSh0b2RheSl9PC9zcGFuPiB0b2RheWAgK1xuICAgICAgKGJ1ZmZlcmVkID4gMCA/IGAgXHUwMEI3IDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0oYnVmZmVyZWQpfTwvc3Bhbj4gYnVmZmVyZWRgIDogJycpICtcbiAgICAgIGAgXHUwMEI3IGxhc3QgJHtlc2NhcGVIdG1sKGZtdFJlbChsYXN0KSl9YDtcblxuICAgIGNvbnN0IGFjdGlvbnMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgYWN0aW9ucy5jbGFzc05hbWUgPSAnYWNjLWFjdGlvbic7XG4gICAgY29uc3QgYnRuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJyk7XG4gICAgYnRuLmNsYXNzTmFtZSA9ICdidG4nO1xuICAgIGJ0bi50ZXh0Q29udGVudCA9ICdDYXB0dXJlIG5vdyc7XG4gICAgYnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICAgICAgYnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS1ub3cnLCBoYW5kbGU6IGEuaGFuZGxlIH0pO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgYnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG4gICAgYWN0aW9ucy5hcHBlbmQoYnRuKTtcblxuICAgIHJvdy5hcHBlbmQoc3RhdHMsIGFjdGlvbnMpO1xuICAgIGxpLmFwcGVuZChoZWFkLCByb3cpO1xuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyQWN0aXZpdHkoZXZlbnRzOiBMb2dFdmVudFtdKTogdm9pZCB7XG4gIGFjdGl2aXR5TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgaWYgKGV2ZW50cy5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcbiAgICBsaS50ZXh0Q29udGVudCA9ICdObyBhY3Rpdml0eSB5ZXQuJztcbiAgICBhY3Rpdml0eUxpc3QuYXBwZW5kKGxpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yIChjb25zdCBldiBvZiBldmVudHMuc2xpY2UoMCwgQUNUSVZJVFlfVEFJTF9NQVgpKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9IGBldiAke2V2LmxldmVsfWA7XG4gICAgY29uc3QgdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgdHMuY2xhc3NOYW1lID0gJ2V2LXRzJztcbiAgICB0cy50ZXh0Q29udGVudCA9IG5ldyBEYXRlKGV2LnRzKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLVVTJywgeyBob3VyMTI6IGZhbHNlIH0pO1xuICAgIGNvbnN0IGljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgaWNvbi5jbGFzc05hbWUgPSAnZXYtaWNvbic7XG4gICAgaWNvbi50ZXh0Q29udGVudCA9IGV2LmxldmVsID09PSAnZXJyb3InID8gJ1x1MjcxNycgOiBldi5sZXZlbCA9PT0gJ3dhcm4nID8gJyEnIDogJ1x1MDBCNyc7XG4gICAgY29uc3QgYm9keSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBjb25zdCBtc2cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBtc2cuY2xhc3NOYW1lID0gJ2V2LW1zZyc7XG4gICAgbXNnLnRleHRDb250ZW50ID0gZXYubXNnO1xuICAgIGJvZHkuYXBwZW5kKG1zZyk7XG4gICAgY29uc3QgY3R4S2V5cyA9IE9iamVjdC5rZXlzKGV2LmNvbnRleHQpO1xuICAgIGlmIChjdHhLZXlzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IGN0eCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgY3R4LmNsYXNzTmFtZSA9ICdldi1jdHgnO1xuICAgICAgY3R4LnRleHRDb250ZW50ID0gY3R4S2V5cy5tYXAoKGspID0+IGAke2t9PSR7c3RyaW5naWZ5U2hvcnQoZXYuY29udGV4dFtrXSl9YCkuam9pbignIFx1MDBCNyAnKTtcbiAgICAgIGJvZHkuYXBwZW5kKGN0eCk7XG4gICAgfVxuICAgIGxpLmFwcGVuZCh0cywgaWNvbiwgYm9keSk7XG4gICAgYWN0aXZpdHlMaXN0LmFwcGVuZChsaSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc3RyaW5naWZ5U2hvcnQodjogdW5rbm93bik6IHN0cmluZyB7XG4gIGlmICh2ID09PSBudWxsKSByZXR1cm4gJ251bGwnO1xuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnKSByZXR1cm4gdi5sZW5ndGggPiA4MCA/IGAke3Yuc2xpY2UoMCwgODApfVx1MjAyNmAgOiB2O1xuICBpZiAodHlwZW9mIHYgPT09ICdudW1iZXInIHx8IHR5cGVvZiB2ID09PSAnYm9vbGVhbicpIHJldHVybiBTdHJpbmcodik7XG4gIHRyeSB7XG4gICAgY29uc3QgcyA9IEpTT04uc3RyaW5naWZ5KHYpO1xuICAgIHJldHVybiBzLmxlbmd0aCA+IDgwID8gYCR7cy5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHM7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnPyc7XG4gIH1cbn1cblxuZnVuY3Rpb24gZXNjYXBlSHRtbChzOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gcy5yZXBsYWNlKC9bJjw+XCInXS9nLCAoYykgPT5cbiAgICBjID09PSAnJicgPyAnJmFtcDsnIDogYyA9PT0gJzwnID8gJyZsdDsnIDogYyA9PT0gJz4nID8gJyZndDsnIDogYyA9PT0gJ1wiJyA/ICcmcXVvdDsnIDogJyYjMzk7J1xuICApO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoU3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgbGFzdFN0YXRlID0gYXdhaXQgc2VuZDxFeHRlbnNpb25TdGF0ZT4oeyB0eXBlOiAnZ2V0LXN0YXRlJyB9KTtcbiAgICBwYWludChsYXN0U3RhdGUpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gc2lkZWJhciByZWZyZXNoU3RhdGUgZmFpbGVkJywgZXJyKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBwYWludChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgZXh0VmVyc2lvbkVsLnRleHRDb250ZW50ID0gc3RhdGUudmVyc2lvbjtcbiAgc2V0Q29ublN0YXR1cyhzdGF0ZSk7XG4gIGF1dG9Ub2dnbGUuY2hlY2tlZCA9IHN0YXRlLnNldHRpbmdzLmF1dG9DYXB0dXJlO1xuICB1cGRhdGVFeGlzdGluZ1RvZ2dsZS5jaGVja2VkID0gc3RhdGUuc2V0dGluZ3MudXBkYXRlRXhpc3RpbmcgIT09IGZhbHNlO1xuICB2aWV3ZXJMaW5rLmhyZWYgPSBgaHR0cHM6Ly8ke3N0YXRlLnNldHRpbmdzLm93bmVyfS5naXRodWIuaW8vJHtzdGF0ZS5zZXR0aW5ncy5yZXBvfS9gO1xuICBwYWludE1hc3RlclN3aXRjaChzdGF0ZSk7XG4gIHJlbmRlckFjY291bnRzKHN0YXRlKTtcbiAgcmVuZGVyUmVjZW50VHdlZXRzKHN0YXRlLnJlY2VudFR3ZWV0U2lnaHRpbmdzKTtcbiAgcGFpbnRBdXRvU2Nyb2xsKHN0YXRlKTtcbiAgcGFpbnRNZWRpYUNyYXdsKHN0YXRlKTtcbiAgcGFpbnRSZWZldGNoKHN0YXRlKTtcbiAgcGFpbnRUaHJlYWRPcGVuKHN0YXRlKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyUmVjZW50VHdlZXRzKHJvd3M6IFR3ZWV0U2lnaHRpbmdbXSk6IHZvaWQge1xuICByZWNlbnRUd2VldExpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xuICAgIGxpLnRleHRDb250ZW50ID0gJ05vIHR3ZWV0cyBzZWVuIHlldC4nO1xuICAgIHJlY2VudFR3ZWV0TGlzdC5hcHBlbmQobGkpO1xuICAgIHJldHVybjtcbiAgfVxuICBmb3IgKGNvbnN0IHJvdyBvZiByb3dzLnNsaWNlKDAsIDQwKSkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSBgcmVjZW50LXR3ZWV0ICR7cm93LmFyY2hpdmVfc3RhdHVzfWA7XG5cbiAgICBjb25zdCB0b3AgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICB0b3AuY2xhc3NOYW1lID0gJ3R3ZWV0LWhlYWQnO1xuICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgbGluay5jbGFzc05hbWUgPSAndHdlZXQtaGFuZGxlJztcbiAgICBsaW5rLmhyZWYgPSByb3cudHdlZXRfdXJsO1xuICAgIGxpbmsudGFyZ2V0ID0gJ19ibGFuayc7XG4gICAgbGluay5yZWwgPSAnbm9vcGVuZXInO1xuICAgIGxpbmsudGV4dENvbnRlbnQgPSBgQCR7cm93LmFjY291bnRfaGFuZGxlfWA7XG4gICAgY29uc3Qgc3RhdHVzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHN0YXR1cy5jbGFzc05hbWUgPSBgdHdlZXQtcGlsbCAke3Jvdy5hcmNoaXZlX3N0YXR1c31gO1xuICAgIHN0YXR1cy50ZXh0Q29udGVudCA9IHJvdy5hcmNoaXZlX3N0YXR1cyA9PT0gJ3NhdmVkJyA/ICdzYXZlZCcgOiAnbmV3JztcbiAgICB0b3AuYXBwZW5kKGxpbmssIHN0YXR1cyk7XG5cbiAgICBjb25zdCB0ZXh0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgdGV4dC5jbGFzc05hbWUgPSAndHdlZXQtdGV4dCc7XG4gICAgdGV4dC50ZXh0Q29udGVudCA9IHRydW5jYXRlVGV4dChyb3cudGV4dCwgMTQwKTtcblxuICAgIGNvbnN0IG1ldGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBtZXRhLmNsYXNzTmFtZSA9ICd0d2VldC1tZXRhJztcbiAgICBtZXRhLnRleHRDb250ZW50ID0gYCR7Zm9ybWF0VHdlZXRBY3Rpb24ocm93LmFjdGlvbil9IFx1MDBCNyAke3Jvdy50d2VldF90eXBlfSBcdTAwQjcgcG9zdGVkICR7Zm10UmVsKHJvdy5wb3N0ZWRfYXQpfWA7XG5cbiAgICBsaS5hcHBlbmQodG9wLCB0ZXh0LCBtZXRhKTtcbiAgICByZWNlbnRUd2VldExpc3QuYXBwZW5kKGxpKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBmb3JtYXRUd2VldEFjdGlvbihhY3Rpb246IFR3ZWV0U2lnaHRpbmdbJ2FjdGlvbiddKTogc3RyaW5nIHtcbiAgaWYgKGFjdGlvbiA9PT0gJ2J1ZmZlcmVkJykgcmV0dXJuICdidWZmZXJlZCc7XG4gIGlmIChhY3Rpb24gPT09ICd1bmNoYW5nZWQnKSByZXR1cm4gJ3VuY2hhbmdlZCc7XG4gIHJldHVybiAnc2tpcHBlZCc7XG59XG5cbmZ1bmN0aW9uIHRydW5jYXRlVGV4dCh0ZXh0OiBzdHJpbmcsIG1heDogbnVtYmVyKTogc3RyaW5nIHtcbiAgY29uc3QgY29tcGFjdCA9IHRleHQucmVwbGFjZSgvXFxzKy9nLCAnICcpLnRyaW0oKTtcbiAgcmV0dXJuIGNvbXBhY3QubGVuZ3RoIDw9IG1heCA/IGNvbXBhY3QgOiBgJHtjb21wYWN0LnNsaWNlKDAsIG1heCAtIDEpfVx1MjAyNmA7XG59XG5cbmZ1bmN0aW9uIHBhaW50TWVkaWFDcmF3bChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3QgcSA9IHN0YXRlLm1lZGlhQ3Jhd2xRdWV1ZTtcbiAgY29uc3QgdG90YWwgPSBxLnRvdGFsO1xuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xuICBtZWRpYUNyYXdsU2VjdGlvbi5oaWRkZW4gPSB0b3RhbCA9PT0gMCAmJiAhcnVubmluZztcbiAgbWVkaWFDcmF3bENvdW50LnRleHRDb250ZW50ID1cbiAgICB0b3RhbCA9PT0gMFxuICAgICAgPyBydW5uaW5nXG4gICAgICAgID8gJ2ZpbmlzaGluZ1x1MjAyNidcbiAgICAgICAgOiAnMCBxdWV1ZWQnXG4gICAgICA6IGAke2ZtdE51bSh0b3RhbCl9IHF1ZXVlZCR7cnVubmluZyA/ICcgXHUwMEI3IHJ1bm5pbmcnIDogJyd9YDtcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmhpZGRlbiA9IHJ1bm5pbmc7XG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xuICBtZWRpYUNyYXdsQ2FuY2VsQnRuLmhpZGRlbiA9ICFydW5uaW5nO1xuICBwYWludFF1ZXVlUHJvZ3Jlc3MobWVkaWFDcmF3bFByb2dyZXNzLCBxKTtcbn1cblxuZnVuY3Rpb24gcGFpbnRRdWV1ZVByb2dyZXNzKFxuICBlbDogSFRNTFNwYW5FbGVtZW50LFxuICBxOiB7IHByb2Nlc3NlZDogbnVtYmVyOyB0b3RhbF9hdF9zdGFydDogbnVtYmVyOyBydW5uaW5nOiBib29sZWFuOyB0b3RhbDogbnVtYmVyIH1cbik6IHZvaWQge1xuICBpZiAoIXEucnVubmluZyAmJiBxLnByb2Nlc3NlZCA9PT0gMCkge1xuICAgIGVsLmhpZGRlbiA9IHRydWU7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIERlbm9taW5hdG9yOiBtYXggb2YgaW5pdGlhbCB0b3RhbCBhbmQgY3VycmVudCBwcm9jZXNzZWQrcmVtYWluaW5nIHNvIHRoZVxuICAvLyBiYXIgc3RpbGwgbWFrZXMgc2Vuc2UgaWYgbmV3IGVudHJpZXMgd2VyZSBlbnF1ZXVlZCBtaWQtcnVuLlxuICBjb25zdCBkZW5vbSA9IE1hdGgubWF4KHEudG90YWxfYXRfc3RhcnQsIHEucHJvY2Vzc2VkICsgcS50b3RhbCk7XG4gIGVsLmhpZGRlbiA9IGZhbHNlO1xuICBlbC50ZXh0Q29udGVudCA9IGAke2ZtdE51bShxLnByb2Nlc3NlZCl9IC8gJHtmbXROdW0oZGVub20pfSBwcm9jZXNzZWRgO1xuICBlbC5jbGFzc05hbWUgPSBxLnJ1bm5pbmcgPyAncHJvZ3Jlc3Mgb24nIDogJ3Byb2dyZXNzJztcbn1cblxuZnVuY3Rpb24gcGFpbnRNYXN0ZXJTd2l0Y2goc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IG9uID0gc3RhdGUuc2V0dGluZ3MuZW5hYmxlZCAhPT0gZmFsc2U7XG4gIG1hc3RlclN3aXRjaC5jaGVja2VkID0gb247XG4gIG1hc3RlckxhYmVsLnRleHRDb250ZW50ID0gb24gPyAnT04nIDogJ1BBVVNFRCc7XG4gIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnRvZ2dsZSgncGF1c2VkJywgIW9uKTtcbn1cblxuZnVuY3Rpb24gcGFpbnRBdXRvU2Nyb2xsKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBzZWNzID0gc3RhdGUuc2V0dGluZ3MuYXV0b1Njcm9sbEludGVydmFsU2VjO1xuICBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWUgPSBTdHJpbmcoc2Vjcyk7XG4gIGF1dG9TY3JvbGxTZWNzRWwudGV4dENvbnRlbnQgPSBTdHJpbmcoc2Vjcyk7XG4gIGNvbnN0IGFzID0gc3RhdGUuYXV0b1Njcm9sbDtcbiAgYXV0b1Njcm9sbFN0YXJ0QnRuLmhpZGRlbiA9IGFzLmFjdGl2ZTtcbiAgYXV0b1Njcm9sbENhbmNlbEJ0bi5oaWRkZW4gPSAhYXMuYWN0aXZlO1xuICBpZiAoYXMuYWN0aXZlKSB7XG4gICAgY29uc3QgbiA9IGFzLnRhYkNvdW50O1xuICAgIGF1dG9TY3JvbGxTdGF0dXMudGV4dENvbnRlbnQgPVxuICAgICAgbiA9PT0gMCA/IGBydW5uaW5nIFx1MjAxNCBubyBYIHRhYnMgb3BlbmAgOiBgcnVubmluZyBcdTIwMTQgJHtufSAke24gPT09IDEgPyAndGFiJyA6ICd0YWJzJ31gO1xuICAgIGF1dG9TY3JvbGxTdGF0dXMuY2xhc3NOYW1lID0gJ211dGVkIG9uJztcbiAgfSBlbHNlIHtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLnRleHRDb250ZW50ID0gJ2lkbGUnO1xuICAgIGF1dG9TY3JvbGxTdGF0dXMuY2xhc3NOYW1lID0gJ211dGVkJztcbiAgfVxuICBpZiAoYXMuYWN0aXZlIHx8IGFzLnNjcm9sbENvdW50ID4gMCB8fCBhcy5pbmdlc3RlZENvdW50ID4gMCkge1xuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy5oaWRkZW4gPSBmYWxzZTtcbiAgICBjb25zdCBwYXJ0cyA9IFtcbiAgICAgIGAke2ZtdE51bShhcy5zY3JvbGxDb3VudCl9IHNjcm9sbHNgLFxuICAgICAgYCR7Zm10TnVtKGFzLmluZ2VzdGVkTmV3Q291bnQpfSBuZXcgYnVmZmVyZWRgLFxuICAgICAgYCR7Zm10TnVtKGFzLmluZ2VzdGVkRXhpc3RpbmdDb3VudCl9IG9sZCBidWZmZXJlZGAsXG4gICAgXTtcbiAgICBpZiAoYXMuc2tpcHBlZE9sZENvdW50ID4gMCkgcGFydHMucHVzaChgJHtmbXROdW0oYXMuc2tpcHBlZE9sZENvdW50KX0gb2xkIHNraXBwZWRgKTtcbiAgICBwYXJ0cy5wdXNoKGAke2ZtdE51bShhcy5leHBhbmRlZENvdW50KX0gZXhwYW5kZWRgKTtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MudGV4dENvbnRlbnQgPSBwYXJ0cy5qb2luKCcgXHUwMEI3ICcpO1xuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy5jbGFzc05hbWUgPSBhcy5hY3RpdmUgPyAncHJvZ3Jlc3Mgb24nIDogJ3Byb2dyZXNzJztcbiAgfSBlbHNlIHtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuaGlkZGVuID0gdHJ1ZTtcbiAgfVxufVxuXG5mdW5jdGlvbiBwYWludFJlZmV0Y2goc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHEgPSBzdGF0ZS5yZWZldGNoUXVldWU7XG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcbiAgY29uc3QgcnVubmluZyA9IHEucnVubmluZztcbiAgcmVmZXRjaFNlY3Rpb24uaGlkZGVuID0gdG90YWwgPT09IDAgJiYgIXJ1bm5pbmc7XG4gIHJlZmV0Y2hDb3VudC50ZXh0Q29udGVudCA9XG4gICAgdG90YWwgPT09IDBcbiAgICAgID8gcnVubmluZ1xuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXG4gICAgICAgIDogJzAgcXVldWVkJ1xuICAgICAgOiBgJHtmbXROdW0odG90YWwpfSBxdWV1ZWQke3J1bm5pbmcgPyAnIFx1MDBCNyBydW5uaW5nJyA6ICcnfWA7XG4gIHJlZmV0Y2hTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xuICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcbiAgcmVmZXRjaENhbmNlbEJ0bi5oaWRkZW4gPSAhcnVubmluZztcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKHJlZmV0Y2hQcm9ncmVzcywgcSk7XG59XG5cbmZ1bmN0aW9uIHBhaW50VGhyZWFkT3BlbihzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3QgcSA9IHN0YXRlLnRocmVhZE9wZW5RdWV1ZTtcbiAgY29uc3QgdG90YWwgPSBxLnRvdGFsO1xuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xuICB0aHJlYWRPcGVuU2VjdGlvbi5oaWRkZW4gPSB0b3RhbCA9PT0gMCAmJiAhcnVubmluZztcbiAgdGhyZWFkT3BlbkNvdW50LnRleHRDb250ZW50ID1cbiAgICB0b3RhbCA9PT0gMFxuICAgICAgPyBydW5uaW5nXG4gICAgICAgID8gJ2ZpbmlzaGluZy4uLidcbiAgICAgICAgOiAnMCBxdWV1ZWQnXG4gICAgICA6IGAke2ZtdE51bSh0b3RhbCl9IHF1ZXVlZCR7cnVubmluZyA/ICcgXHUwMEI3IHJ1bm5pbmcnIDogJyd9YDtcbiAgdGhyZWFkT3BlblN0YXJ0QnRuLmhpZGRlbiA9IHJ1bm5pbmc7XG4gIHRocmVhZE9wZW5TdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xuICB0aHJlYWRPcGVuQ2FuY2VsQnRuLmhpZGRlbiA9ICFydW5uaW5nO1xuICBwYWludFF1ZXVlUHJvZ3Jlc3ModGhyZWFkT3BlblByb2dyZXNzLCBxKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBQdWxsIHN0cmFpZ2h0IGZyb20gc3RvcmFnZSBvbiBmaXJzdCByZW5kZXI7IGxpdmUgdXBkYXRlcyBjb21lIHZpYVxuICAvLyBgbG9nLWV2ZW50YCBicm9hZGNhc3RzLlxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KCdhY3Rpdml0eScpO1xuICBjb25zdCBldmVudHMgPSAoc3RvcmVkLmFjdGl2aXR5IGFzIExvZ0V2ZW50W10gfCB1bmRlZmluZWQpID8/IFtdO1xuICByZW5kZXJBY3Rpdml0eShldmVudHMpO1xufVxuXG4vLyAtLS0gV2lyZSB1cCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5jYXB0dXJlQWxsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtYWxsJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5jYXB0dXJlVGhpc0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS10aGlzLXBhZ2UnIH0pO1xuICB9IGZpbmFsbHkge1xuICAgIGNhcHR1cmVUaGlzQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5mbHVzaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgZmx1c2hCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnZmx1c2gtYWxsJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBmbHVzaEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuYXV0b1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtYXV0by1jYXB0dXJlJywgb246IGF1dG9Ub2dnbGUuY2hlY2tlZCB9KTtcbn0pO1xuXG51cGRhdGVFeGlzdGluZ1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtdXBkYXRlLWV4aXN0aW5nJywgb246IHVwZGF0ZUV4aXN0aW5nVG9nZ2xlLmNoZWNrZWQgfSk7XG59KTtcblxubWFzdGVyU3dpdGNoLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1lbmFibGVkJywgb246IG1hc3RlclN3aXRjaC5jaGVja2VkIH0pO1xufSk7XG5cbmF1dG9TY3JvbGxTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgYXV0b1Njcm9sbFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LWF1dG8tc2Nyb2xsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcbmF1dG9TY3JvbGxDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGF1dG9TY3JvbGxDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLWF1dG8tc2Nyb2xsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbmF1dG9TY3JvbGxJbnRlcnZhbC5hZGRFdmVudExpc3RlbmVyKCdpbnB1dCcsICgpID0+IHtcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZTtcbn0pO1xuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgY29uc3Qgc2Vjb25kcyA9IE51bWJlcihhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWUpO1xuICBpZiAoTnVtYmVyLmlzRmluaXRlKHNlY29uZHMpKSB7XG4gICAgdm9pZCBzZW5kKHsgdHlwZTogJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCcsIHNlY29uZHMgfSk7XG4gIH1cbn0pO1xuXG5wdXJnZUxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICBjb25zdCBvayA9IHdpbmRvdy5jb25maXJtKFxuICAgICdEcm9wIGV2ZXJ5IGNvdW50ZXIsIHJ1biBidWZmZXIsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCAvIHRocmVhZC1vcGVuaW5nIHF1ZXVlIGVudHJ5IGZvciBhY2NvdW50cyBub3QgaW4geW91ciB0cmFja2VkIGxpc3Q/XFxuXFxuJyArXG4gICAgICAnVGhpcyBvbmx5IHRvdWNoZXMgbG9jYWwgZXh0ZW5zaW9uIHN0YXRlLiBBbHJlYWR5LWNvbW1pdHRlZCBmaWxlcyBpbiB0aGUgR2l0SHViIHJlcG8gYXJlIG5vdCBhZmZlY3RlZCBcdTIwMTQgJyArXG4gICAgICAncnVuIHNjcmlwdHMvcHVyZ2VfdW5yZWxhdGVkLnB5IHNlcGFyYXRlbHkgaWYgeW91IGFsc28gd2FudCB0byBzY3J1YiB0aGUgcmVwby4nXG4gICk7XG4gIGlmICghb2spIHJldHVybjtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3B1cmdlLXVucmVsYXRlZCcgfSk7XG59KTtcblxucmVmZXRjaFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtcmVmZXRjaCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbnJlZmV0Y2hDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxubWVkaWFDcmF3bFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5tZWRpYUNyYXdsQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBtZWRpYUNyYXdsQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1tZWRpYS1jcmF3bCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG50aHJlYWRPcGVuU3RhcnRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIHRocmVhZE9wZW5TdGFydEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC10aHJlYWQtb3BlbicgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgdGhyZWFkT3BlblN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbnRocmVhZE9wZW5DYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIHRocmVhZE9wZW5DYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLXRocmVhZC1vcGVuJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICB0aHJlYWRPcGVuQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbm9wdGlvbnNMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ29wZW4tb3B0aW9ucycgfSk7XG59KTtcblxudmlld2VyTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdvcGVuLXZpZXdlcicgfSk7XG59KTtcblxuY2xlYXJBY3RCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2xlYXItYWN0aXZpdHknIH0pO1xuICByZW5kZXJBY3Rpdml0eShbXSk7XG59KTtcblxuYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiB1bmtub3duKSA9PiB7XG4gIGlmICghbXNnIHx8IHR5cGVvZiBtc2cgIT09ICdvYmplY3QnKSByZXR1cm47XG4gIGNvbnN0IG0gPSBtc2cgYXMgeyB0eXBlPzogc3RyaW5nOyBzdGF0ZT86IEV4dGVuc2lvblN0YXRlOyBldmVudD86IExvZ0V2ZW50IH07XG4gIGlmIChtLnR5cGUgPT09ICdzdGF0ZS1jaGFuZ2VkJyAmJiBtLnN0YXRlKSB7XG4gICAgbGFzdFN0YXRlID0gbS5zdGF0ZTtcbiAgICBwYWludChtLnN0YXRlKTtcbiAgfSBlbHNlIGlmIChtLnR5cGUgPT09ICdsb2ctZXZlbnQnICYmIG0uZXZlbnQpIHtcbiAgICBwcmVwZW5kRXZlbnQobS5ldmVudCk7XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBwcmVwZW5kRXZlbnQoZXY6IExvZ0V2ZW50KTogdm9pZCB7XG4gIC8vIElmIHRoZSBsaXN0IGlzIHNob3dpbmcgdGhlIFwiZW1wdHlcIiBwbGFjZWhvbGRlciwgY2xlYXIgaXQuXG4gIGlmIChhY3Rpdml0eUxpc3QuZmlyc3RFbGVtZW50Q2hpbGQ/LmNsYXNzTGlzdC5jb250YWlucygnZW1wdHknKSkge1xuICAgIGFjdGl2aXR5TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgfVxuICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gIGxpLmNsYXNzTmFtZSA9IGBldiAke2V2LmxldmVsfWA7XG4gIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICB0cy5jbGFzc05hbWUgPSAnZXYtdHMnO1xuICB0cy50ZXh0Q29udGVudCA9IG5ldyBEYXRlKGV2LnRzKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLVVTJywgeyBob3VyMTI6IGZhbHNlIH0pO1xuICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBpY29uLmNsYXNzTmFtZSA9ICdldi1pY29uJztcbiAgaWNvbi50ZXh0Q29udGVudCA9IGV2LmxldmVsID09PSAnZXJyb3InID8gJ1x1MjcxNycgOiBldi5sZXZlbCA9PT0gJ3dhcm4nID8gJyEnIDogJ1x1MDBCNyc7XG4gIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIGNvbnN0IG1zZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBtc2cuY2xhc3NOYW1lID0gJ2V2LW1zZyc7XG4gIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcbiAgYm9keS5hcHBlbmQobXNnKTtcbiAgY29uc3QgY3R4S2V5cyA9IE9iamVjdC5rZXlzKGV2LmNvbnRleHQpO1xuICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgY3R4ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgY3R4LmNsYXNzTmFtZSA9ICdldi1jdHgnO1xuICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgYm9keS5hcHBlbmQoY3R4KTtcbiAgfVxuICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xuICBhY3Rpdml0eUxpc3QucHJlcGVuZChsaSk7XG4gIHdoaWxlIChhY3Rpdml0eUxpc3QuY2hpbGRFbGVtZW50Q291bnQgPiBBQ1RJVklUWV9UQUlMX01BWCkge1xuICAgIGFjdGl2aXR5TGlzdC5sYXN0RWxlbWVudENoaWxkPy5yZW1vdmUoKTtcbiAgfVxufVxuXG4vLyBJbml0aWFsIHBhaW50Llxudm9pZCByZWZyZXNoU3RhdGUoKTtcbnZvaWQgcmVmcmVzaEFjdGl2aXR5KCk7XG5cbi8vIFBlcmlvZGljYWxseSByZS1mZXRjaCBzdGF0ZSBzbyBcImxhc3QgY2FwdHVyZVwiIHRpbWVzIHN0YXkgZnJlc2guXG5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gIHZvaWQgcmVmcmVzaFN0YXRlKCk7XG59LCAxNV8wMDApO1xuIl0sCiAgIm1hcHBpbmdzIjogIjtBQTZGTyxJQUFNLG9CQUFvQjtBQUcxQixJQUFNLGdDQUFnQyxLQUFLLEtBQUs7OztBQ3JGdkQsSUFBTSxJQUFJLENBQXNDLE9BQWtCO0FBQ2hFLFFBQU0sS0FBSyxTQUFTLGVBQWUsRUFBRTtBQUNyQyxNQUFJLENBQUMsR0FBSSxPQUFNLElBQUksTUFBTSxvQkFBb0IsRUFBRSxFQUFFO0FBQ2pELFNBQU87QUFDVDtBQUVBLElBQU0sVUFBVSxFQUFFLFVBQVU7QUFDNUIsSUFBTSxXQUFXLEVBQW1CLFdBQVc7QUFDL0MsSUFBTSxjQUFjLEVBQW9CLGNBQWM7QUFDdEQsSUFBTSxrQkFBa0IsRUFBb0IsbUJBQW1CO0FBQy9ELElBQU0sZUFBZSxFQUFvQixlQUFlO0FBQ3hELElBQU0sYUFBYSxFQUFvQixjQUFjO0FBQ3JELElBQU0sdUJBQXVCLEVBQW9CLGlCQUFpQjtBQUNsRSxJQUFNLGdCQUFnQixFQUFxQixhQUFhO0FBQ3hELElBQU0saUJBQWlCLEVBQXFCLGNBQWM7QUFDMUQsSUFBTSxXQUFXLEVBQXFCLFdBQVc7QUFDakQsSUFBTSxjQUFjLEVBQXFCLGNBQWM7QUFDdkQsSUFBTSxhQUFhLEVBQXFCLGFBQWE7QUFDckQsSUFBTSxjQUFjLEVBQXFCLGdCQUFnQjtBQUN6RCxJQUFNLGVBQWUsRUFBbUIsYUFBYTtBQUNyRCxJQUFNLGVBQWUsRUFBb0IsZUFBZTtBQUN4RCxJQUFNLGNBQWMsRUFBbUIsY0FBYztBQUNyRCxJQUFNLHFCQUFxQixFQUFvQixzQkFBc0I7QUFDckUsSUFBTSxtQkFBbUIsRUFBbUIsa0JBQWtCO0FBQzlELElBQU0sbUJBQW1CLEVBQW1CLG9CQUFvQjtBQUNoRSxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLGlCQUFpQixFQUFlLGlCQUFpQjtBQUN2RCxJQUFNLGVBQWUsRUFBbUIsZUFBZTtBQUN2RCxJQUFNLGtCQUFrQixFQUFxQixlQUFlO0FBQzVELElBQU0sbUJBQW1CLEVBQXFCLGdCQUFnQjtBQUM5RCxJQUFNLGtCQUFrQixFQUFtQixrQkFBa0I7QUFDN0QsSUFBTSxvQkFBb0IsRUFBZSxxQkFBcUI7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsbUJBQW1CO0FBQzlELElBQU0scUJBQXFCLEVBQXFCLG1CQUFtQjtBQUNuRSxJQUFNLHNCQUFzQixFQUFxQixvQkFBb0I7QUFDckUsSUFBTSxxQkFBcUIsRUFBbUIsc0JBQXNCO0FBQ3BFLElBQU0sb0JBQW9CLEVBQWUscUJBQXFCO0FBQzlELElBQU0sa0JBQWtCLEVBQW1CLG1CQUFtQjtBQUM5RCxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLFlBQVksRUFBcUIsaUJBQWlCO0FBRXhELElBQUksWUFBbUM7QUFFdkMsZUFBZSxLQUFRLEtBQWlDO0FBQ3RELFNBQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUN4QztBQUVBLFNBQVMsY0FBYyxPQUE2QjtBQUNsRCxRQUFNLEVBQUUsWUFBWSxTQUFTLElBQUk7QUFDakMsTUFBSSxNQUFNO0FBQ1YsTUFBSSxPQUFPO0FBS1gsUUFBTSxnQkFDSixXQUFXLFdBQVcsUUFBUSxTQUFTLFVBQVUsV0FBVywyQkFBMkI7QUFDekYsTUFBSSxDQUFDLFNBQVMsUUFBUTtBQUNwQixVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxlQUFlO0FBQ3hCLFVBQU07QUFDTixXQUFPLFdBQVcsU0FBUyxNQUFNLHVCQUF1QixTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksNENBQXVDLFdBQVcsaUJBQWlCLFFBQVE7QUFBQSxFQUNwSyxXQUFXLFdBQVcsV0FBVyxNQUFNO0FBQ3JDLFVBQU07QUFDTixXQUFPLGlCQUFpQixXQUFXLFNBQVMsR0FBRyxPQUFPLFNBQVMsS0FBSyxJQUFJLFNBQVMsSUFBSSxlQUFPLFNBQVMsU0FBUztBQUFBLEVBQ2hILFdBQVcsV0FBVyxXQUFXLGNBQWM7QUFDN0MsVUFBTTtBQUNOLFdBQU8saUJBQWlCLFdBQVcsS0FBSyxJQUNwQyxvRUFDQTtBQUFBLEVBQ04sV0FBVyxXQUFXLFdBQVcsZ0JBQWdCO0FBQy9DLFVBQU07QUFDTixVQUFNLFNBQVMsa0JBQWtCLFdBQVcsZ0JBQWdCO0FBQzVELFdBQU8sU0FDSCxxQ0FBZ0MsTUFBTSxLQUN0QztBQUFBLEVBQ04sV0FBVyxXQUFXLFdBQVcsaUJBQWlCO0FBQ2hELFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLFdBQVcsV0FBVyxrQkFBa0I7QUFDakQsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULE9BQU87QUFDTCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDQSxVQUFRLFlBQVksT0FBTyxHQUFHO0FBQzlCLFdBQVMsY0FBYztBQUN2QixXQUFTLFFBQVEsV0FBVyxTQUFTO0FBQ3ZDO0FBRUEsU0FBUyxPQUFPLEtBQTRCO0FBQzFDLE1BQUksQ0FBQyxJQUFLLFFBQU87QUFDakIsUUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHO0FBQ3hCLE1BQUksQ0FBQyxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFDaEMsUUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssT0FBTyxLQUFLLElBQUksSUFBSSxLQUFLLEdBQUksQ0FBQztBQUM1RCxNQUFJLE9BQU8sRUFBRyxRQUFPO0FBQ3JCLE1BQUksT0FBTyxHQUFJLFFBQU8sR0FBRyxJQUFJO0FBQzdCLFFBQU0sT0FBTyxLQUFLLE1BQU0sT0FBTyxFQUFFO0FBQ2pDLE1BQUksT0FBTyxHQUFJLFFBQU8sR0FBRyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxLQUFLLE1BQU0sT0FBTyxFQUFFO0FBQ2xDLE1BQUksUUFBUSxHQUFJLFFBQU8sR0FBRyxLQUFLO0FBQy9CLFFBQU0sT0FBTyxLQUFLLE1BQU0sUUFBUSxFQUFFO0FBQ2xDLFNBQU8sR0FBRyxJQUFJO0FBQ2hCO0FBRUEsU0FBUyxrQkFBa0IsVUFBaUM7QUFDMUQsTUFBSSxhQUFhLEtBQU0sUUFBTztBQUM5QixRQUFNLFdBQVcsV0FBVyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUN4RCxNQUFJLFlBQVksRUFBRyxRQUFPO0FBQzFCLFFBQU0sWUFBWSxJQUFJLEtBQUssV0FBVyxHQUFJLEVBQUUsbUJBQW1CLENBQUMsR0FBRztBQUFBLElBQ2pFLE1BQU07QUFBQSxJQUNOLFFBQVE7QUFBQSxFQUNWLENBQUM7QUFDRCxNQUFJLFdBQVcsR0FBSSxRQUFPLE1BQU0sUUFBUSxNQUFNLFNBQVM7QUFDdkQsUUFBTSxPQUFPLEtBQUssTUFBTSxXQUFXLEVBQUU7QUFDckMsTUFBSSxPQUFPLEdBQUksUUFBTyxNQUFNLElBQUksTUFBTSxTQUFTO0FBQy9DLFFBQU0sUUFBUSxLQUFLLE1BQU0sT0FBTyxFQUFFO0FBQ2xDLFNBQU8sTUFBTSxLQUFLLE1BQU0sU0FBUztBQUNuQztBQUVBLFNBQVMsT0FBTyxHQUFtQjtBQUNqQyxTQUFPLEVBQUUsZUFBZSxPQUFPO0FBQ2pDO0FBRUEsU0FBUyxpQkFBaUIsU0FBaUM7QUFDekQsU0FDRSxPQUFPLFlBQVksWUFDbkIsNkVBQTZFLEtBQUssT0FBTztBQUU3RjtBQUVBLFNBQVMsZUFBZSxPQUE2QjtBQUNuRCxjQUFZLGdCQUFnQjtBQUM1QixNQUFJLE1BQU0sU0FBUyxXQUFXLEdBQUc7QUFDL0IsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixnQkFBWSxPQUFPLEVBQUU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsYUFBVyxLQUFLLE1BQU0sVUFBVTtBQUM5QixVQUFNLElBQUksTUFBTSxTQUFTLEVBQUUsTUFBTTtBQUNqQyxVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZLEtBQUssRUFBRSxnQkFBZ0IsSUFBSSxnQkFBZ0I7QUFFMUQsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixVQUFNLFNBQVMsU0FBUyxjQUFjLE1BQU07QUFDNUMsV0FBTyxZQUFZO0FBQ25CLFdBQU8sWUFBWSw0QkFBNEIsV0FBVyxFQUFFLE1BQU0sQ0FBQztBQUNuRSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxFQUFFO0FBQ3JCLFNBQUssT0FBTyxRQUFRLElBQUk7QUFFeEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixVQUFNLFFBQVEsU0FBUyxjQUFjLE1BQU07QUFDM0MsVUFBTSxZQUFZO0FBQ2xCLFVBQU0sUUFBUSxHQUFHLGNBQWM7QUFDL0IsVUFBTSxXQUFXLEdBQUcsaUJBQWlCO0FBQ3JDLFVBQU0sT0FBTyxHQUFHLGlCQUFpQjtBQUNqQyxVQUFNLFlBQ0oscUJBQXFCLE9BQU8sS0FBSyxDQUFDLG1CQUNqQyxXQUFXLElBQUksMkJBQXdCLE9BQU8sUUFBUSxDQUFDLHFCQUFxQixNQUM3RSxjQUFXLFdBQVcsT0FBTyxJQUFJLENBQUMsQ0FBQztBQUVyQyxVQUFNLFVBQVUsU0FBUyxjQUFjLE1BQU07QUFDN0MsWUFBUSxZQUFZO0FBQ3BCLFVBQU0sTUFBTSxTQUFTLGNBQWMsUUFBUTtBQUMzQyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjO0FBQ2xCLFFBQUksaUJBQWlCLFNBQVMsWUFBWTtBQUN4QyxVQUFJLFdBQVc7QUFDZixVQUFJO0FBQ0YsY0FBTSxLQUFLLEVBQUUsTUFBTSxlQUFlLFFBQVEsRUFBRSxPQUFPLENBQUM7QUFBQSxNQUN0RCxVQUFFO0FBQ0EsWUFBSSxXQUFXO0FBQUEsTUFDakI7QUFBQSxJQUNGLENBQUM7QUFDRCxZQUFRLE9BQU8sR0FBRztBQUVsQixRQUFJLE9BQU8sT0FBTyxPQUFPO0FBQ3pCLE9BQUcsT0FBTyxNQUFNLEdBQUc7QUFDbkIsZ0JBQVksT0FBTyxFQUFFO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsZUFBZSxRQUEwQjtBQUNoRCxlQUFhLGdCQUFnQjtBQUM3QixNQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsaUJBQWEsT0FBTyxFQUFFO0FBQ3RCO0FBQUEsRUFDRjtBQUNBLGFBQVcsTUFBTSxPQUFPLE1BQU0sR0FBRyxpQkFBaUIsR0FBRztBQUNuRCxVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZLE1BQU0sR0FBRyxLQUFLO0FBQzdCLFVBQU0sS0FBSyxTQUFTLGNBQWMsTUFBTTtBQUN4QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWMsSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxNQUFNLENBQUM7QUFDOUUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsR0FBRyxVQUFVLFVBQVUsV0FBTSxHQUFHLFVBQVUsU0FBUyxNQUFNO0FBQzVFLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYyxHQUFHO0FBQ3JCLFNBQUssT0FBTyxHQUFHO0FBQ2YsVUFBTSxVQUFVLE9BQU8sS0FBSyxHQUFHLE9BQU87QUFDdEMsUUFBSSxRQUFRLFNBQVMsR0FBRztBQUN0QixZQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsVUFBSSxZQUFZO0FBQ2hCLFVBQUksY0FBYyxRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLGVBQWUsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLFFBQUs7QUFDeEYsV0FBSyxPQUFPLEdBQUc7QUFBQSxJQUNqQjtBQUNBLE9BQUcsT0FBTyxJQUFJLE1BQU0sSUFBSTtBQUN4QixpQkFBYSxPQUFPLEVBQUU7QUFBQSxFQUN4QjtBQUNGO0FBRUEsU0FBUyxlQUFlLEdBQW9CO0FBQzFDLE1BQUksTUFBTSxLQUFNLFFBQU87QUFDdkIsTUFBSSxPQUFPLE1BQU0sU0FBVSxRQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFDekUsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLE1BQU0sVUFBVyxRQUFPLE9BQU8sQ0FBQztBQUNwRSxNQUFJO0FBQ0YsVUFBTSxJQUFJLEtBQUssVUFBVSxDQUFDO0FBQzFCLFdBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUFBLEVBQ2hELFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxXQUFXLEdBQW1CO0FBQ3JDLFNBQU8sRUFBRTtBQUFBLElBQVE7QUFBQSxJQUFZLENBQUMsTUFDNUIsTUFBTSxNQUFNLFVBQVUsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLFdBQVc7QUFBQSxFQUN6RjtBQUNGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxNQUFJO0FBQ0YsZ0JBQVksTUFBTSxLQUFxQixFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQzVELFVBQU0sU0FBUztBQUFBLEVBQ2pCLFNBQVMsS0FBSztBQUNaLFlBQVEsS0FBSyw2Q0FBNkMsR0FBRztBQUFBLEVBQy9EO0FBQ0Y7QUFFQSxTQUFTLE1BQU0sT0FBNkI7QUFDMUMsZUFBYSxjQUFjLE1BQU07QUFDakMsZ0JBQWMsS0FBSztBQUNuQixhQUFXLFVBQVUsTUFBTSxTQUFTO0FBQ3BDLHVCQUFxQixVQUFVLE1BQU0sU0FBUyxtQkFBbUI7QUFDakUsYUFBVyxPQUFPLFdBQVcsTUFBTSxTQUFTLEtBQUssY0FBYyxNQUFNLFNBQVMsSUFBSTtBQUNsRixvQkFBa0IsS0FBSztBQUN2QixpQkFBZSxLQUFLO0FBQ3BCLHFCQUFtQixNQUFNLG9CQUFvQjtBQUM3QyxrQkFBZ0IsS0FBSztBQUNyQixrQkFBZ0IsS0FBSztBQUNyQixlQUFhLEtBQUs7QUFDbEIsa0JBQWdCLEtBQUs7QUFDdkI7QUFFQSxTQUFTLG1CQUFtQixNQUE2QjtBQUN2RCxrQkFBZ0IsZ0JBQWdCO0FBQ2hDLE1BQUksS0FBSyxXQUFXLEdBQUc7QUFDckIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixvQkFBZ0IsT0FBTyxFQUFFO0FBQ3pCO0FBQUEsRUFDRjtBQUNBLGFBQVcsT0FBTyxLQUFLLE1BQU0sR0FBRyxFQUFFLEdBQUc7QUFDbkMsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxnQkFBZ0IsSUFBSSxjQUFjO0FBRWpELFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsVUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0FBQ3ZDLFNBQUssWUFBWTtBQUNqQixTQUFLLE9BQU8sSUFBSTtBQUNoQixTQUFLLFNBQVM7QUFDZCxTQUFLLE1BQU07QUFDWCxTQUFLLGNBQWMsSUFBSSxJQUFJLGNBQWM7QUFDekMsVUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0FBQzVDLFdBQU8sWUFBWSxjQUFjLElBQUksY0FBYztBQUNuRCxXQUFPLGNBQWMsSUFBSSxtQkFBbUIsVUFBVSxVQUFVO0FBQ2hFLFFBQUksT0FBTyxNQUFNLE1BQU07QUFFdkIsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsYUFBYSxJQUFJLE1BQU0sR0FBRztBQUU3QyxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxHQUFHLGtCQUFrQixJQUFJLE1BQU0sQ0FBQyxTQUFNLElBQUksVUFBVSxnQkFBYSxPQUFPLElBQUksU0FBUyxDQUFDO0FBRXpHLE9BQUcsT0FBTyxLQUFLLE1BQU0sSUFBSTtBQUN6QixvQkFBZ0IsT0FBTyxFQUFFO0FBQUEsRUFDM0I7QUFDRjtBQUVBLFNBQVMsa0JBQWtCLFFBQXlDO0FBQ2xFLE1BQUksV0FBVyxXQUFZLFFBQU87QUFDbEMsTUFBSSxXQUFXLFlBQWEsUUFBTztBQUNuQyxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGFBQWEsTUFBYyxLQUFxQjtBQUN2RCxRQUFNLFVBQVUsS0FBSyxRQUFRLFFBQVEsR0FBRyxFQUFFLEtBQUs7QUFDL0MsU0FBTyxRQUFRLFVBQVUsTUFBTSxVQUFVLEdBQUcsUUFBUSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDdkU7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLElBQUksTUFBTTtBQUNoQixRQUFNLFFBQVEsRUFBRTtBQUNoQixRQUFNLFVBQVUsRUFBRTtBQUNsQixvQkFBa0IsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUMzQyxrQkFBZ0IsY0FDZCxVQUFVLElBQ04sVUFDRSxvQkFDQSxhQUNGLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxVQUFVLGtCQUFlLEVBQUU7QUFDM0QscUJBQW1CLFNBQVM7QUFDNUIscUJBQW1CLFdBQVcsVUFBVTtBQUN4QyxzQkFBb0IsU0FBUyxDQUFDO0FBQzlCLHFCQUFtQixvQkFBb0IsQ0FBQztBQUMxQztBQUVBLFNBQVMsbUJBQ1AsSUFDQSxHQUNNO0FBQ04sTUFBSSxDQUFDLEVBQUUsV0FBVyxFQUFFLGNBQWMsR0FBRztBQUNuQyxPQUFHLFNBQVM7QUFDWjtBQUFBLEVBQ0Y7QUFHQSxRQUFNLFFBQVEsS0FBSyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLEtBQUs7QUFDOUQsS0FBRyxTQUFTO0FBQ1osS0FBRyxjQUFjLEdBQUcsT0FBTyxFQUFFLFNBQVMsQ0FBQyxNQUFNLE9BQU8sS0FBSyxDQUFDO0FBQzFELEtBQUcsWUFBWSxFQUFFLFVBQVUsZ0JBQWdCO0FBQzdDO0FBRUEsU0FBUyxrQkFBa0IsT0FBNkI7QUFDdEQsUUFBTSxLQUFLLE1BQU0sU0FBUyxZQUFZO0FBQ3RDLGVBQWEsVUFBVTtBQUN2QixjQUFZLGNBQWMsS0FBSyxPQUFPO0FBQ3RDLFdBQVMsS0FBSyxVQUFVLE9BQU8sVUFBVSxDQUFDLEVBQUU7QUFDOUM7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLE9BQU8sTUFBTSxTQUFTO0FBQzVCLHFCQUFtQixRQUFRLE9BQU8sSUFBSTtBQUN0QyxtQkFBaUIsY0FBYyxPQUFPLElBQUk7QUFDMUMsUUFBTSxLQUFLLE1BQU07QUFDakIscUJBQW1CLFNBQVMsR0FBRztBQUMvQixzQkFBb0IsU0FBUyxDQUFDLEdBQUc7QUFDakMsTUFBSSxHQUFHLFFBQVE7QUFDYixVQUFNLElBQUksR0FBRztBQUNiLHFCQUFpQixjQUNmLE1BQU0sSUFBSSxrQ0FBNkIsa0JBQWEsQ0FBQyxJQUFJLE1BQU0sSUFBSSxRQUFRLE1BQU07QUFDbkYscUJBQWlCLFlBQVk7QUFBQSxFQUMvQixPQUFPO0FBQ0wscUJBQWlCLGNBQWM7QUFDL0IscUJBQWlCLFlBQVk7QUFBQSxFQUMvQjtBQUNBLE1BQUksR0FBRyxVQUFVLEdBQUcsY0FBYyxLQUFLLEdBQUcsZ0JBQWdCLEdBQUc7QUFDM0QsdUJBQW1CLFNBQVM7QUFDNUIsVUFBTSxRQUFRO0FBQUEsTUFDWixHQUFHLE9BQU8sR0FBRyxXQUFXLENBQUM7QUFBQSxNQUN6QixHQUFHLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQztBQUFBLE1BQzlCLEdBQUcsT0FBTyxHQUFHLHFCQUFxQixDQUFDO0FBQUEsSUFDckM7QUFDQSxRQUFJLEdBQUcsa0JBQWtCLEVBQUcsT0FBTSxLQUFLLEdBQUcsT0FBTyxHQUFHLGVBQWUsQ0FBQyxjQUFjO0FBQ2xGLFVBQU0sS0FBSyxHQUFHLE9BQU8sR0FBRyxhQUFhLENBQUMsV0FBVztBQUNqRCx1QkFBbUIsY0FBYyxNQUFNLEtBQUssUUFBSztBQUNqRCx1QkFBbUIsWUFBWSxHQUFHLFNBQVMsZ0JBQWdCO0FBQUEsRUFDN0QsT0FBTztBQUNMLHVCQUFtQixTQUFTO0FBQUEsRUFDOUI7QUFDRjtBQUVBLFNBQVMsYUFBYSxPQUE2QjtBQUNqRCxRQUFNLElBQUksTUFBTTtBQUNoQixRQUFNLFFBQVEsRUFBRTtBQUNoQixRQUFNLFVBQVUsRUFBRTtBQUNsQixpQkFBZSxTQUFTLFVBQVUsS0FBSyxDQUFDO0FBQ3hDLGVBQWEsY0FDWCxVQUFVLElBQ04sVUFDRSxvQkFDQSxhQUNGLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxVQUFVLGtCQUFlLEVBQUU7QUFDM0Qsa0JBQWdCLFNBQVM7QUFDekIsa0JBQWdCLFdBQVcsVUFBVTtBQUNyQyxtQkFBaUIsU0FBUyxDQUFDO0FBQzNCLHFCQUFtQixpQkFBaUIsQ0FBQztBQUN2QztBQUVBLFNBQVMsZ0JBQWdCLE9BQTZCO0FBQ3BELFFBQU0sSUFBSSxNQUFNO0FBQ2hCLFFBQU0sUUFBUSxFQUFFO0FBQ2hCLFFBQU0sVUFBVSxFQUFFO0FBQ2xCLG9CQUFrQixTQUFTLFVBQVUsS0FBSyxDQUFDO0FBQzNDLGtCQUFnQixjQUNkLFVBQVUsSUFDTixVQUNFLGlCQUNBLGFBQ0YsR0FBRyxPQUFPLEtBQUssQ0FBQyxVQUFVLFVBQVUsa0JBQWUsRUFBRTtBQUMzRCxxQkFBbUIsU0FBUztBQUM1QixxQkFBbUIsV0FBVyxVQUFVO0FBQ3hDLHNCQUFvQixTQUFTLENBQUM7QUFDOUIscUJBQW1CLG9CQUFvQixDQUFDO0FBQzFDO0FBRUEsZUFBZSxrQkFBaUM7QUFHOUMsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxVQUFVO0FBQ3pELFFBQU0sU0FBVSxPQUFPLFlBQXVDLENBQUM7QUFDL0QsaUJBQWUsTUFBTTtBQUN2QjtBQUlBLGNBQWMsaUJBQWlCLFNBQVMsWUFBWTtBQUNsRCxnQkFBYyxXQUFXO0FBQ3pCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUFBLEVBQ3BDLFVBQUU7QUFDQSxrQkFBYyxXQUFXO0FBQUEsRUFDM0I7QUFDRixDQUFDO0FBRUQsZUFBZSxpQkFBaUIsU0FBUyxZQUFZO0FBQ25ELGlCQUFlLFdBQVc7QUFDMUIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFBQSxFQUMxQyxVQUFFO0FBQ0EsbUJBQWUsV0FBVztBQUFBLEVBQzVCO0FBQ0YsQ0FBQztBQUVELFNBQVMsaUJBQWlCLFNBQVMsWUFBWTtBQUM3QyxXQUFTLFdBQVc7QUFDcEIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQUEsRUFDbEMsVUFBRTtBQUNBLGFBQVMsV0FBVztBQUFBLEVBQ3RCO0FBQ0YsQ0FBQztBQUVELFdBQVcsaUJBQWlCLFVBQVUsTUFBTTtBQUMxQyxPQUFLLEtBQUssRUFBRSxNQUFNLHVCQUF1QixJQUFJLFdBQVcsUUFBUSxDQUFDO0FBQ25FLENBQUM7QUFFRCxxQkFBcUIsaUJBQWlCLFVBQVUsTUFBTTtBQUNwRCxPQUFLLEtBQUssRUFBRSxNQUFNLDBCQUEwQixJQUFJLHFCQUFxQixRQUFRLENBQUM7QUFDaEYsQ0FBQztBQUVELGFBQWEsaUJBQWlCLFVBQVUsTUFBTTtBQUM1QyxPQUFLLEtBQUssRUFBRSxNQUFNLGtCQUFrQixJQUFJLGFBQWEsUUFBUSxDQUFDO0FBQ2hFLENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxxQkFBbUIsV0FBVztBQUM5QixPQUFLLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3JELHVCQUFtQixXQUFXO0FBQUEsRUFDaEMsQ0FBQztBQUNILENBQUM7QUFDRCxvQkFBb0IsaUJBQWlCLFNBQVMsTUFBTTtBQUNsRCxzQkFBb0IsV0FBVztBQUMvQixPQUFLLEtBQUssRUFBRSxNQUFNLHFCQUFxQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3RELHdCQUFvQixXQUFXO0FBQUEsRUFDakMsQ0FBQztBQUNILENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxtQkFBaUIsY0FBYyxtQkFBbUI7QUFDcEQsQ0FBQztBQUNELG1CQUFtQixpQkFBaUIsVUFBVSxNQUFNO0FBQ2xELFFBQU0sVUFBVSxPQUFPLG1CQUFtQixLQUFLO0FBQy9DLE1BQUksT0FBTyxTQUFTLE9BQU8sR0FBRztBQUM1QixTQUFLLEtBQUssRUFBRSxNQUFNLDRCQUE0QixRQUFRLENBQUM7QUFBQSxFQUN6RDtBQUNGLENBQUM7QUFFRCxVQUFVLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNoRCxJQUFFLGVBQWU7QUFDakIsUUFBTSxLQUFLLE9BQU87QUFBQSxJQUNoQjtBQUFBLEVBR0Y7QUFDQSxNQUFJLENBQUMsR0FBSTtBQUNULE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFDdkMsQ0FBQztBQUVELGdCQUFnQixpQkFBaUIsU0FBUyxNQUFNO0FBQzlDLGtCQUFnQixXQUFXO0FBQzNCLE9BQUssS0FBSyxFQUFFLE1BQU0sZ0JBQWdCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDakQsb0JBQWdCLFdBQVc7QUFBQSxFQUM3QixDQUFDO0FBQ0gsQ0FBQztBQUVELGlCQUFpQixpQkFBaUIsU0FBUyxNQUFNO0FBQy9DLG1CQUFpQixXQUFXO0FBQzVCLE9BQUssS0FBSyxFQUFFLE1BQU0saUJBQWlCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDbEQscUJBQWlCLFdBQVc7QUFBQSxFQUM5QixDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2xELElBQUUsZUFBZTtBQUNqQixPQUFLLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNwQyxDQUFDO0FBRUQsV0FBVyxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDakQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQ25DLENBQUM7QUFFRCxZQUFZLGlCQUFpQixTQUFTLFlBQVk7QUFDaEQsUUFBTSxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNyQyxpQkFBZSxDQUFDLENBQUM7QUFDbkIsQ0FBQztBQUVELFFBQVEsUUFBUSxVQUFVLFlBQVksQ0FBQyxRQUFpQjtBQUN0RCxNQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsU0FBVTtBQUNyQyxRQUFNLElBQUk7QUFDVixNQUFJLEVBQUUsU0FBUyxtQkFBbUIsRUFBRSxPQUFPO0FBQ3pDLGdCQUFZLEVBQUU7QUFDZCxVQUFNLEVBQUUsS0FBSztBQUFBLEVBQ2YsV0FBVyxFQUFFLFNBQVMsZUFBZSxFQUFFLE9BQU87QUFDNUMsaUJBQWEsRUFBRSxLQUFLO0FBQUEsRUFDdEI7QUFDRixDQUFDO0FBRUQsU0FBUyxhQUFhLElBQW9CO0FBRXhDLE1BQUksYUFBYSxtQkFBbUIsVUFBVSxTQUFTLE9BQU8sR0FBRztBQUMvRCxpQkFBYSxnQkFBZ0I7QUFBQSxFQUMvQjtBQUNBLFFBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxLQUFHLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDN0IsUUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQ3hDLEtBQUcsWUFBWTtBQUNmLEtBQUcsY0FBYyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUM5RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsT0FBSyxZQUFZO0FBQ2pCLE9BQUssY0FBYyxHQUFHLFVBQVUsVUFBVSxXQUFNLEdBQUcsVUFBVSxTQUFTLE1BQU07QUFDNUUsUUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFFBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxNQUFJLFlBQVk7QUFDaEIsTUFBSSxjQUFjLEdBQUc7QUFDckIsT0FBSyxPQUFPLEdBQUc7QUFDZixRQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTztBQUN0QyxNQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssUUFBSztBQUN4RixTQUFLLE9BQU8sR0FBRztBQUFBLEVBQ2pCO0FBQ0EsS0FBRyxPQUFPLElBQUksTUFBTSxJQUFJO0FBQ3hCLGVBQWEsUUFBUSxFQUFFO0FBQ3ZCLFNBQU8sYUFBYSxvQkFBb0IsbUJBQW1CO0FBQ3pELGlCQUFhLGtCQUFrQixPQUFPO0FBQUEsRUFDeEM7QUFDRjtBQUdBLEtBQUssYUFBYTtBQUNsQixLQUFLLGdCQUFnQjtBQUdyQixZQUFZLE1BQU07QUFDaEIsT0FBSyxhQUFhO0FBQ3BCLEdBQUcsSUFBTTsiLAogICJuYW1lcyI6IFtdCn0K
