// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var updateExistingToggle = $("update-existing");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = isWriteAuthError(connection.error) ? "PAT can read repo but cannot write - set Contents: Read & Write" : "Auth error - check your PAT";
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  updateExistingToggle.checked = state.settings.updateExisting !== false;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    const parts = [
      `${fmtNum(as.scrollCount)} scrolls`,
      `${fmtNum(as.ingestedNewCount)} new buffered`,
      `${fmtNum(as.ingestedExistingCount)} old buffered`
    ];
    if (as.skippedOldCount > 0) parts.push(`${fmtNum(as.skippedOldCount)} old skipped`);
    parts.push(`${fmtNum(as.expandedCount)} expanded`);
    autoScrollProgress.textContent = parts.join(" \xB7 ");
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
updateExistingToggle.addEventListener("change", () => {
  void send({ type: "toggle-update-existing", on: updateExistingToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBTZXR0aW5ncyA9IHtcclxuICBwYXQ6ICcnLFxyXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXHJcbiAgcmVwbzogJ3gnLFxyXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcclxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxyXG4gIGJyYW5jaDogJ21hc3RlcicsXHJcbiAgZW5hYmxlZDogdHJ1ZSxcclxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcclxuICBjb25maWd1cmVkQXQ6IG51bGwsXHJcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxyXG4gIHVwZGF0ZUV4aXN0aW5nOiB0cnVlLFxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01JTl9TRUMgPSAzO1xyXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xyXG5cclxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcclxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxyXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcclxuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1JhcGlkUmVzcG9uc2U0NycsIGxhYmVsOiAnUmFwaWQgUmVzcG9uc2UgNDcnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbl07XHJcblxyXG4vLyBHcmFwaFFMIGVuZHBvaW50IG5hbWVzIHdlIGNhcmUgYWJvdXQgKG1hdGNoZWQgYnkgc3Vic3RyaW5nIGFnYWluc3QgVVJMIHBhdGgpLlxyXG5leHBvcnQgY29uc3QgVFdFRVRfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ1VzZXJUd2VldHMnLFxyXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXHJcbiAgJ1VzZXJNZWRpYScsXHJcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcclxuICAnVHdlZXREZXRhaWwnLFxyXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcclxuICAnTGlrZXMnLFxyXG4gICdCb29rbWFya3MnLFxyXG4gICdIb21lVGltZWxpbmUnLFxyXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxyXG4gICdTZWFyY2hUaW1lbGluZScsXHJcbiAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXHJcbl0pO1xyXG5cclxuLy8gRW5kcG9pbnRzIHRoYXQgY2FycnkgQ29tbXVuaXR5IE5vdGUgYm9kaWVzIFx1MjAxNCBjYXB0dXJlZCBmb3IgY29tcGxldGVuZXNzIGJ1dFxyXG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxyXG5leHBvcnQgY29uc3QgQklSRFdBVENIX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdCaXJkd2F0Y2hGZXRjaE9uZU5vdGUnLFxyXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcclxuXSk7XHJcblxyXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcclxuLy8gdG8gbGVhcm4gYWNjb3VudF9pZCA8LT4gaGFuZGxlIGJpbmRpbmdzKS5cclxuZXhwb3J0IGNvbnN0IFBST0ZJTEVfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJCeVNjcmVlbk5hbWUnLCAnVXNlckJ5UmVzdElkJ10pO1xyXG5cclxuLy8gRW5kcG9pbnRzIHdob3NlIHJlc3BvbnNlcyBhcmUgc2NvcGVkIHRvIGEgcGFydGljdWxhciBhY2NvdW50IG9yXHJcbi8vIGNvbnZlcnNhdGlvbiBcdTIwMTQgaS5lLiB2aXNpdGluZyBgLzxoYW5kbGU+YCAvIGAvPGhhbmRsZT4vd2l0aF9yZXBsaWVzYCxcclxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXHJcbi8vIGVpdGhlciBhdXRob3JlZCBieSB0aGUgdHJhY2tlZCBhY2NvdW50IG9yIGRpcmVjdGx5IHJlZmVyZW5jZWQgYnkgdGhlbVxyXG4vLyAocmV0d2VldGVkLCBxdW90ZWQsIHJlcGxpZWQgdG8pLCBzbyB3ZSBrZWVwIGV2ZXJ5dGhpbmcgd2Ugc2VlIHJhdGhlclxyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXHJcbi8vIGFjY291bnQgc3RpbGwgZ2V0cyBpdHMgb3JpZ2luYWwtdHdlZXQgY29udGVudCBhcmNoaXZlZC5cclxuLy9cclxuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXHJcbi8vIHN0aWxsIGdldCBmaWx0ZXJlZCB0byB0cmFja2VkLWhhbmRsZSBhdXRob3JzIFx1MjAxNCBzZWUgdGhlIHNwZWMnc1xyXG4vLyBcIkJyb3dzaW5nIG15IGhvbWUgdGltZWxpbmUgaXMgaWdub3JlZFwiIHJ1bGUuXHJcbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXHJcbiAgJ1VzZXJUd2VldHMnLFxyXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXHJcbiAgJ1VzZXJNZWRpYScsXHJcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcclxuICAnVHdlZXREZXRhaWwnLFxyXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcclxuXSk7XHJcblxyXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cclxuZXhwb3J0IGNvbnN0IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCA9IDIwMDtcclxuXHJcbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cclxuZXhwb3J0IGNvbnN0IEZMVVNIX0lETEVfTVMgPSA0NV8wMDA7XHJcblxyXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cclxuZXhwb3J0IGNvbnN0IEZMVVNIX0FMQVJNX01JTlVURVMgPSAxO1xyXG5cclxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxyXG5leHBvcnQgY29uc3QgQUNUSVZJVFlfVEFJTF9NQVggPSAyNTA7XHJcblxyXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXHJcbmV4cG9ydCBjb25zdCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyA9IDEwICogNjAgKiAxMDAwO1xyXG5cclxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XHJcbiIsICIvKipcclxuICogc2lkZWJhci50cyBcdTIwMTQgVUkgZm9yIHRoZSBwZXJzaXN0ZW50IHNpZGViYXIuXHJcbiAqXHJcbiAqIFNpZGViYXJzIGluIEZpcmVmb3ggc3RheSBvcGVuIGFjcm9zcyB0YWIvd2luZG93IHN3aXRjaGVzLCB3aGljaCBpcyB0aGVcclxuICogaW50ZW5kZWQgcGVyc2lzdGVuY2UgbW9kZWwuIFRoaXMgbW9kdWxlIHJlbmRlcnMgc3RhdGUgcHVzaGVkIGZyb20gdGhlXHJcbiAqIGJhY2tncm91bmQgc2VydmljZSB3b3JrZXIgYW5kIGZvcndhcmRzIHVzZXIgY29tbWFuZHMgYmFjay5cclxuICovXHJcblxyXG5pbXBvcnQgeyBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XHJcbmltcG9ydCB0eXBlIHsgRXh0ZW5zaW9uU3RhdGUsIExvZ0V2ZW50LCBSdW50aW1lTWVzc2FnZSB9IGZyb20gJy4vbGliL3R5cGVzLmpzJztcclxuXHJcbmNvbnN0ICQgPSA8VCBleHRlbmRzIEhUTUxFbGVtZW50ID0gSFRNTEVsZW1lbnQ+KGlkOiBzdHJpbmcpOiBUID0+IHtcclxuICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcclxuICBpZiAoIWVsKSB0aHJvdyBuZXcgRXJyb3IoYG1pc3NpbmcgZWxlbWVudCAjJHtpZH1gKTtcclxuICByZXR1cm4gZWwgYXMgVDtcclxufTtcclxuXHJcbmNvbnN0IGNvbm5Eb3QgPSAkKCdjb25uLWRvdCcpO1xyXG5jb25zdCBjb25uVGV4dCA9ICQ8SFRNTFNwYW5FbGVtZW50PignY29ubi10ZXh0Jyk7XHJcbmNvbnN0IGFjY291bnRMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWNjb3VudC1saXN0Jyk7XHJcbmNvbnN0IGFjdGl2aXR5TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjdGl2aXR5LWxpc3QnKTtcclxuY29uc3QgYXV0b1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tY2FwdHVyZScpO1xyXG5jb25zdCB1cGRhdGVFeGlzdGluZ1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ3VwZGF0ZS1leGlzdGluZycpO1xyXG5jb25zdCBjYXB0dXJlQWxsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtYWxsJyk7XHJcbmNvbnN0IGNhcHR1cmVUaGlzQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtdGhpcycpO1xyXG5jb25zdCBmbHVzaEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdmbHVzaC1hbGwnKTtcclxuY29uc3Qgb3B0aW9uc0xpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi1vcHRpb25zJyk7XHJcbmNvbnN0IHZpZXdlckxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi12aWV3ZXInKTtcclxuY29uc3QgY2xlYXJBY3RCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2xlYXItYWN0aXZpdHknKTtcclxuY29uc3QgZXh0VmVyc2lvbkVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdleHQtdmVyc2lvbicpO1xyXG5jb25zdCBtYXN0ZXJTd2l0Y2ggPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdtYXN0ZXItc3dpdGNoJyk7XHJcbmNvbnN0IG1hc3RlckxhYmVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtYXN0ZXItbGFiZWwnKTtcclxuY29uc3QgYXV0b1Njcm9sbEludGVydmFsID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1zY3JvbGwtaW50ZXJ2YWwnKTtcclxuY29uc3QgYXV0b1Njcm9sbFNlY3NFbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc2VjcycpO1xyXG5jb25zdCBhdXRvU2Nyb2xsU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zdGF0dXMnKTtcclxuY29uc3QgYXV0b1Njcm9sbFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXN0YXJ0Jyk7XHJcbmNvbnN0IGF1dG9TY3JvbGxDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtY2FuY2VsJyk7XHJcbmNvbnN0IGF1dG9TY3JvbGxQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtcHJvZ3Jlc3MnKTtcclxuY29uc3QgcmVmZXRjaFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PigncmVmZXRjaC1zZWN0aW9uJyk7XHJcbmNvbnN0IHJlZmV0Y2hDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1jb3VudCcpO1xyXG5jb25zdCByZWZldGNoU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1zdGFydCcpO1xyXG5jb25zdCByZWZldGNoQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZmV0Y2gtY2FuY2VsJyk7XHJcbmNvbnN0IHJlZmV0Y2hQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1wcm9ncmVzcycpO1xyXG5jb25zdCBtZWRpYUNyYXdsU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1zZWN0aW9uJyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtY291bnQnKTtcclxuY29uc3QgbWVkaWFDcmF3bFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLXN0YXJ0Jyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignbWVkaWEtY3Jhd2wtY2FuY2VsJyk7XHJcbmNvbnN0IG1lZGlhQ3Jhd2xQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtcHJvZ3Jlc3MnKTtcclxuY29uc3QgcHVyZ2VMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ3B1cmdlLXVucmVsYXRlZCcpO1xyXG5cclxubGV0IGxhc3RTdGF0ZTogRXh0ZW5zaW9uU3RhdGUgfCBudWxsID0gbnVsbDtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNlbmQ8VD4obXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8VD4ge1xyXG4gIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKSBhcyBQcm9taXNlPFQ+O1xyXG59XHJcblxyXG5mdW5jdGlvbiBzZXRDb25uU3RhdHVzKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xyXG4gIGNvbnN0IHsgY29ubmVjdGlvbiwgc2V0dGluZ3MgfSA9IHN0YXRlO1xyXG4gIGxldCBjbHMgPSAnJztcclxuICBsZXQgdGV4dCA9ICcnO1xyXG4gIC8vIE9ubHkgd2FybiB3aGVuIHRoZSBjb25maWd1cmVkIGJyYW5jaCBnZW51aW5lbHkgZG9lc24ndCBleGlzdCBvbiB0aGVcclxuICAvLyByZW1vdGUuIEEgbm9uLWRlZmF1bHQgYnJhbmNoIHRoYXQgZXhpc3RzIGlzIGZpbmUgXHUyMDE0IGNhcHR1cmluZyBpbnRvIGFcclxuICAvLyB3b3JraW5nIGJyYW5jaCBpcyByb3V0aW5lIFx1MjAxNCBzbyB0aGUgbWVyZSBgIT09YCB0byBkZWZhdWx0X2JyYW5jaCBpcyBub3RcclxuICAvLyBhIHByb2JsZW0gYW5kIHNob3VsZG4ndCBzaG91dCBpbiB0aGUgaGVhZGVyLlxyXG4gIGNvbnN0IGJyYW5jaE1pc3NpbmcgPVxyXG4gICAgY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycgJiYgc2V0dGluZ3MuYnJhbmNoICYmIGNvbm5lY3Rpb24uY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gZmFsc2U7XHJcbiAgaWYgKCFzZXR0aW5ncy5wYXRTZXQpIHtcclxuICAgIGNscyA9ICd3YXJuJztcclxuICAgIHRleHQgPSAnTm90IGNvbmZpZ3VyZWQgXHUyMDE0IG9wZW4gU2V0dGluZ3MnO1xyXG4gIH0gZWxzZSBpZiAoYnJhbmNoTWlzc2luZykge1xyXG4gICAgY2xzID0gJ2Vycic7XHJcbiAgICB0ZXh0ID0gYEJyYW5jaCBcIiR7c2V0dGluZ3MuYnJhbmNofVwiIGRvZXMgbm90IGV4aXN0IG9uICR7c2V0dGluZ3Mub3duZXJ9LyR7c2V0dGluZ3MucmVwb30gXHUyMDE0IGNvbW1pdHMgd2lsbCA0MjIuIFNldCBicmFuY2ggdG8gXCIke2Nvbm5lY3Rpb24uZGVmYXVsdEJyYW5jaCA/PyAnbWFzdGVyJ31cIiBpbiBTZXR0aW5ncy5gO1xyXG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycpIHtcclxuICAgIGNscyA9ICdvayc7XHJcbiAgICB0ZXh0ID0gYENvbm5lY3RlZCBhcyBAJHtjb25uZWN0aW9uLmxvZ2luID8/ICc/J30gdG8gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTAwQjcgXHUyMDI2JHtzZXR0aW5ncy5wYXRTdWZmaXh9YDtcclxuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gaXNXcml0ZUF1dGhFcnJvcihjb25uZWN0aW9uLmVycm9yKVxuICAgICAgPyAnUEFUIGNhbiByZWFkIHJlcG8gYnV0IGNhbm5vdCB3cml0ZSAtIHNldCBDb250ZW50czogUmVhZCAmIFdyaXRlJ1xuICAgICAgOiAnQXV0aCBlcnJvciAtIGNoZWNrIHlvdXIgUEFUJztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcclxuICAgIGNscyA9ICd3YXJuJztcclxuICAgIGNvbnN0IHJlc2V0cyA9IGZtdFJhdGVMaW1pdFJlc2V0KGNvbm5lY3Rpb24ucmF0ZUxpbWl0UmVzZXRBdCk7XHJcbiAgICB0ZXh0ID0gcmVzZXRzXHJcbiAgICAgID8gYEdpdEh1YiByYXRlLWxpbWl0ZWQgXHUyMDE0IHJlc2V0cyAke3Jlc2V0c31gXHJcbiAgICAgIDogJ0dpdEh1YiByYXRlLWxpbWl0ZWQgXHUyMDE0IGNhcHR1cmVzIHdpbGwgcmV0cnknO1xyXG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICduZXR3b3JrLWVycm9yJykge1xyXG4gICAgY2xzID0gJ2Vycic7XHJcbiAgICB0ZXh0ID0gJ05ldHdvcmsgZXJyb3IgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpdml0eSc7XHJcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ25vdC1jb25maWd1cmVkJykge1xyXG4gICAgY2xzID0gJ3dhcm4nO1xyXG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XHJcbiAgfSBlbHNlIHtcclxuICAgIGNscyA9ICcnO1xyXG4gICAgdGV4dCA9ICdDaGVja2luZ1x1MjAyNic7XHJcbiAgfVxyXG4gIGNvbm5Eb3QuY2xhc3NOYW1lID0gYGRvdCAke2Nsc31gO1xyXG4gIGNvbm5UZXh0LnRleHRDb250ZW50ID0gdGV4dDtcclxuICBjb25uVGV4dC50aXRsZSA9IGNvbm5lY3Rpb24uZXJyb3IgPz8gJyc7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZtdFJlbChpc286IHN0cmluZyB8IG51bGwpOiBzdHJpbmcge1xyXG4gIGlmICghaXNvKSByZXR1cm4gJ1x1MjAxNCc7XHJcbiAgY29uc3QgZCA9IERhdGUucGFyc2UoaXNvKTtcclxuICBpZiAoIU51bWJlci5pc0Zpbml0ZShkKSkgcmV0dXJuICdcdTIwMTQnO1xyXG4gIGNvbnN0IHNlY3MgPSBNYXRoLm1heCgwLCBNYXRoLnJvdW5kKChEYXRlLm5vdygpIC0gZCkgLyAxMDAwKSk7XHJcbiAgaWYgKHNlY3MgPCA1KSByZXR1cm4gJ2p1c3Qgbm93JztcclxuICBpZiAoc2VjcyA8IDYwKSByZXR1cm4gYCR7c2Vjc31zIGFnb2A7XHJcbiAgY29uc3QgbWlucyA9IE1hdGgucm91bmQoc2VjcyAvIDYwKTtcclxuICBpZiAobWlucyA8IDYwKSByZXR1cm4gYCR7bWluc31tIGFnb2A7XHJcbiAgY29uc3QgaG91cnMgPSBNYXRoLnJvdW5kKG1pbnMgLyA2MCk7XHJcbiAgaWYgKGhvdXJzIDwgMjQpIHJldHVybiBgJHtob3Vyc31oIGFnb2A7XHJcbiAgY29uc3QgZGF5cyA9IE1hdGgucm91bmQoaG91cnMgLyAyNCk7XHJcbiAgcmV0dXJuIGAke2RheXN9ZCBhZ29gO1xyXG59XHJcblxyXG5mdW5jdGlvbiBmbXRSYXRlTGltaXRSZXNldChlcG9jaFNlYzogbnVtYmVyIHwgbnVsbCk6IHN0cmluZyB7XHJcbiAgaWYgKGVwb2NoU2VjID09PSBudWxsKSByZXR1cm4gJyc7XHJcbiAgY29uc3QgZGVsdGFTZWMgPSBlcG9jaFNlYyAtIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xyXG4gIGlmIChkZWx0YVNlYyA8PSAwKSByZXR1cm4gJ21vbWVudGFyaWx5JztcclxuICBjb25zdCB3YWxsQ2xvY2sgPSBuZXcgRGF0ZShlcG9jaFNlYyAqIDEwMDApLnRvTG9jYWxlVGltZVN0cmluZyhbXSwge1xyXG4gICAgaG91cjogJzItZGlnaXQnLFxyXG4gICAgbWludXRlOiAnMi1kaWdpdCcsXHJcbiAgfSk7XHJcbiAgaWYgKGRlbHRhU2VjIDwgNjApIHJldHVybiBgaW4gJHtkZWx0YVNlY31zICgke3dhbGxDbG9ja30pYDtcclxuICBjb25zdCBtaW5zID0gTWF0aC5yb3VuZChkZWx0YVNlYyAvIDYwKTtcclxuICBpZiAobWlucyA8IDYwKSByZXR1cm4gYGluICR7bWluc31tICgke3dhbGxDbG9ja30pYDtcclxuICBjb25zdCBob3VycyA9IE1hdGgucm91bmQobWlucyAvIDYwKTtcclxuICByZXR1cm4gYGluICR7aG91cnN9aCAoJHt3YWxsQ2xvY2t9KWA7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZtdE51bShuOiBudW1iZXIpOiBzdHJpbmcge1xuICByZXR1cm4gbi50b0xvY2FsZVN0cmluZygnZW4tVVMnKTtcbn1cblxuZnVuY3Rpb24gaXNXcml0ZUF1dGhFcnJvcihtZXNzYWdlOiBzdHJpbmcgfCBudWxsKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnICYmXG4gICAgL1Jlc291cmNlIG5vdCBhY2Nlc3NpYmxlIGJ5IHBlcnNvbmFsIGFjY2VzcyB0b2tlbnxcXC9naXRcXC9ibG9ic3xcXC9naXRcXC9yZWZzL2kudGVzdChtZXNzYWdlKVxuICApO1xufVxuXG5mdW5jdGlvbiByZW5kZXJBY2NvdW50cyhzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgYWNjb3VudExpc3QucmVwbGFjZUNoaWxkcmVuKCk7XHJcbiAgaWYgKHN0YXRlLmFjY291bnRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xyXG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcclxuICAgIGxpLnRleHRDb250ZW50ID0gJ05vIGFjY291bnRzIGNvbmZpZ3VyZWQuJztcclxuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGZvciAoY29uc3QgYSBvZiBzdGF0ZS5hY2NvdW50cykge1xyXG4gICAgY29uc3QgYyA9IHN0YXRlLmNvdW50ZXJzW2EuaGFuZGxlXTtcclxuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcclxuICAgIGxpLmNsYXNzTmFtZSA9IGMgJiYgYy5idWZmZXJlZENvdW50ID4gMCA/ICdhY2MgcGVuZGluZycgOiAnYWNjJztcclxuXHJcbiAgICBjb25zdCBoZWFkID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICBoZWFkLmNsYXNzTmFtZSA9ICdhY2MtaGVhZCc7XHJcbiAgICBjb25zdCBoYW5kbGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBoYW5kbGUuY2xhc3NOYW1lID0gJ2FjYy1oYW5kbGUnO1xyXG4gICAgaGFuZGxlLmlubmVySFRNTCA9IGA8c3BhbiBjbGFzcz1cImF0XCI+QDwvc3Bhbj4ke2VzY2FwZUh0bWwoYS5oYW5kbGUpfWA7XHJcbiAgICBjb25zdCBtZXRhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgbWV0YS5jbGFzc05hbWUgPSAnYWNjLW1ldGEnO1xyXG4gICAgbWV0YS50ZXh0Q29udGVudCA9IGEubGFiZWw7XHJcbiAgICBoZWFkLmFwcGVuZChoYW5kbGUsIG1ldGEpO1xyXG5cclxuICAgIGNvbnN0IHJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgcm93LmNsYXNzTmFtZSA9ICdhY2Mtcm93JztcclxuICAgIGNvbnN0IHN0YXRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgc3RhdHMuY2xhc3NOYW1lID0gJ2FjYy1zdGF0cyc7XHJcbiAgICBjb25zdCB0b2RheSA9IGM/LnRvZGF5Q291bnQgPz8gMDtcclxuICAgIGNvbnN0IGJ1ZmZlcmVkID0gYz8uYnVmZmVyZWRDb3VudCA/PyAwO1xyXG4gICAgY29uc3QgbGFzdCA9IGM/Lmxhc3RDYXB0dXJlQXQgPz8gbnVsbDtcclxuICAgIHN0YXRzLmlubmVySFRNTCA9XHJcbiAgICAgIGA8c3BhbiBjbGFzcz1cIm51bVwiPiR7Zm10TnVtKHRvZGF5KX08L3NwYW4+IHRvZGF5YCArXHJcbiAgICAgIChidWZmZXJlZCA+IDAgPyBgIFx1MDBCNyA8c3BhbiBjbGFzcz1cIm51bVwiPiR7Zm10TnVtKGJ1ZmZlcmVkKX08L3NwYW4+IGJ1ZmZlcmVkYCA6ICcnKSArXHJcbiAgICAgIGAgXHUwMEI3IGxhc3QgJHtlc2NhcGVIdG1sKGZtdFJlbChsYXN0KSl9YDtcclxuXHJcbiAgICBjb25zdCBhY3Rpb25zID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgYWN0aW9ucy5jbGFzc05hbWUgPSAnYWNjLWFjdGlvbic7XHJcbiAgICBjb25zdCBidG4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdidXR0b24nKTtcclxuICAgIGJ0bi5jbGFzc05hbWUgPSAnYnRuJztcclxuICAgIGJ0bi50ZXh0Q29udGVudCA9ICdDYXB0dXJlIG5vdyc7XHJcbiAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjYXB0dXJlLW5vdycsIGhhbmRsZTogYS5oYW5kbGUgfSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgYnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gICAgYWN0aW9ucy5hcHBlbmQoYnRuKTtcclxuXHJcbiAgICByb3cuYXBwZW5kKHN0YXRzLCBhY3Rpb25zKTtcclxuICAgIGxpLmFwcGVuZChoZWFkLCByb3cpO1xyXG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlbmRlckFjdGl2aXR5KGV2ZW50czogTG9nRXZlbnRbXSk6IHZvaWQge1xyXG4gIGFjdGl2aXR5TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcclxuICBpZiAoZXZlbnRzLmxlbmd0aCA9PT0gMCkge1xyXG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xyXG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcclxuICAgIGxpLnRleHRDb250ZW50ID0gJ05vIGFjdGl2aXR5IHlldC4nO1xyXG4gICAgYWN0aXZpdHlMaXN0LmFwcGVuZChsaSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGZvciAoY29uc3QgZXYgb2YgZXZlbnRzLnNsaWNlKDAsIEFDVElWSVRZX1RBSUxfTUFYKSkge1xyXG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xyXG4gICAgbGkuY2xhc3NOYW1lID0gYGV2ICR7ZXYubGV2ZWx9YDtcclxuICAgIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgdHMuY2xhc3NOYW1lID0gJ2V2LXRzJztcclxuICAgIHRzLnRleHRDb250ZW50ID0gbmV3IERhdGUoZXYudHMpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tVVMnLCB7IGhvdXIxMjogZmFsc2UgfSk7XHJcbiAgICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gICAgaWNvbi5jbGFzc05hbWUgPSAnZXYtaWNvbic7XHJcbiAgICBpY29uLnRleHRDb250ZW50ID0gZXYubGV2ZWwgPT09ICdlcnJvcicgPyAnXHUyNzE3JyA6IGV2LmxldmVsID09PSAnd2FybicgPyAnIScgOiAnXHUwMEI3JztcclxuICAgIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XHJcbiAgICBjb25zdCBtc2cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcclxuICAgIG1zZy5jbGFzc05hbWUgPSAnZXYtbXNnJztcclxuICAgIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcclxuICAgIGJvZHkuYXBwZW5kKG1zZyk7XHJcbiAgICBjb25zdCBjdHhLZXlzID0gT2JqZWN0LmtleXMoZXYuY29udGV4dCk7XHJcbiAgICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XHJcbiAgICAgIGNvbnN0IGN0eCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gICAgICBjdHguY2xhc3NOYW1lID0gJ2V2LWN0eCc7XHJcbiAgICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XHJcbiAgICAgIGJvZHkuYXBwZW5kKGN0eCk7XHJcbiAgICB9XHJcbiAgICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xyXG4gICAgYWN0aXZpdHlMaXN0LmFwcGVuZChsaSk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBzdHJpbmdpZnlTaG9ydCh2OiB1bmtub3duKTogc3RyaW5nIHtcclxuICBpZiAodiA9PT0gbnVsbCkgcmV0dXJuICdudWxsJztcclxuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnKSByZXR1cm4gdi5sZW5ndGggPiA4MCA/IGAke3Yuc2xpY2UoMCwgODApfVx1MjAyNmAgOiB2O1xyXG4gIGlmICh0eXBlb2YgdiA9PT0gJ251bWJlcicgfHwgdHlwZW9mIHYgPT09ICdib29sZWFuJykgcmV0dXJuIFN0cmluZyh2KTtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcyA9IEpTT04uc3RyaW5naWZ5KHYpO1xyXG4gICAgcmV0dXJuIHMubGVuZ3RoID4gODAgPyBgJHtzLnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogcztcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiAnPyc7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBlc2NhcGVIdG1sKHM6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIHMucmVwbGFjZSgvWyY8PlwiJ10vZywgKGMpID0+XHJcbiAgICBjID09PSAnJicgPyAnJmFtcDsnIDogYyA9PT0gJzwnID8gJyZsdDsnIDogYyA9PT0gJz4nID8gJyZndDsnIDogYyA9PT0gJ1wiJyA/ICcmcXVvdDsnIDogJyYjMzk7J1xyXG4gICk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hTdGF0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICB0cnkge1xyXG4gICAgbGFzdFN0YXRlID0gYXdhaXQgc2VuZDxFeHRlbnNpb25TdGF0ZT4oeyB0eXBlOiAnZ2V0LXN0YXRlJyB9KTtcclxuICAgIHBhaW50KGxhc3RTdGF0ZSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gc2lkZWJhciByZWZyZXNoU3RhdGUgZmFpbGVkJywgZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhaW50KHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xyXG4gIGV4dFZlcnNpb25FbC50ZXh0Q29udGVudCA9IHN0YXRlLnZlcnNpb247XHJcbiAgc2V0Q29ublN0YXR1cyhzdGF0ZSk7XHJcbiAgYXV0b1RvZ2dsZS5jaGVja2VkID0gc3RhdGUuc2V0dGluZ3MuYXV0b0NhcHR1cmU7XHJcbiAgdXBkYXRlRXhpc3RpbmdUb2dnbGUuY2hlY2tlZCA9IHN0YXRlLnNldHRpbmdzLnVwZGF0ZUV4aXN0aW5nICE9PSBmYWxzZTtcclxuICB2aWV3ZXJMaW5rLmhyZWYgPSBgaHR0cHM6Ly8ke3N0YXRlLnNldHRpbmdzLm93bmVyfS5naXRodWIuaW8vJHtzdGF0ZS5zZXR0aW5ncy5yZXBvfS9gO1xyXG4gIHBhaW50TWFzdGVyU3dpdGNoKHN0YXRlKTtcclxuICByZW5kZXJBY2NvdW50cyhzdGF0ZSk7XHJcbiAgcGFpbnRBdXRvU2Nyb2xsKHN0YXRlKTtcclxuICBwYWludE1lZGlhQ3Jhd2woc3RhdGUpO1xyXG4gIHBhaW50UmVmZXRjaChzdGF0ZSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhaW50TWVkaWFDcmF3bChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcclxuICBjb25zdCBxID0gc3RhdGUubWVkaWFDcmF3bFF1ZXVlO1xyXG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcclxuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xyXG4gIG1lZGlhQ3Jhd2xTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xyXG4gIG1lZGlhQ3Jhd2xDb3VudC50ZXh0Q29udGVudCA9XHJcbiAgICB0b3RhbCA9PT0gMFxyXG4gICAgICA/IHJ1bm5pbmdcclxuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXHJcbiAgICAgICAgOiAnMCBxdWV1ZWQnXHJcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xyXG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xyXG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xyXG4gIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XHJcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKG1lZGlhQ3Jhd2xQcm9ncmVzcywgcSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBhaW50UXVldWVQcm9ncmVzcyhcclxuICBlbDogSFRNTFNwYW5FbGVtZW50LFxyXG4gIHE6IHsgcHJvY2Vzc2VkOiBudW1iZXI7IHRvdGFsX2F0X3N0YXJ0OiBudW1iZXI7IHJ1bm5pbmc6IGJvb2xlYW47IHRvdGFsOiBudW1iZXIgfVxyXG4pOiB2b2lkIHtcclxuICBpZiAoIXEucnVubmluZyAmJiBxLnByb2Nlc3NlZCA9PT0gMCkge1xyXG4gICAgZWwuaGlkZGVuID0gdHJ1ZTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgLy8gRGVub21pbmF0b3I6IG1heCBvZiBpbml0aWFsIHRvdGFsIGFuZCBjdXJyZW50IHByb2Nlc3NlZCtyZW1haW5pbmcgc28gdGhlXHJcbiAgLy8gYmFyIHN0aWxsIG1ha2VzIHNlbnNlIGlmIG5ldyBlbnRyaWVzIHdlcmUgZW5xdWV1ZWQgbWlkLXJ1bi5cclxuICBjb25zdCBkZW5vbSA9IE1hdGgubWF4KHEudG90YWxfYXRfc3RhcnQsIHEucHJvY2Vzc2VkICsgcS50b3RhbCk7XHJcbiAgZWwuaGlkZGVuID0gZmFsc2U7XHJcbiAgZWwudGV4dENvbnRlbnQgPSBgJHtmbXROdW0ocS5wcm9jZXNzZWQpfSAvICR7Zm10TnVtKGRlbm9tKX0gcHJvY2Vzc2VkYDtcclxuICBlbC5jbGFzc05hbWUgPSBxLnJ1bm5pbmcgPyAncHJvZ3Jlc3Mgb24nIDogJ3Byb2dyZXNzJztcclxufVxyXG5cclxuZnVuY3Rpb24gcGFpbnRNYXN0ZXJTd2l0Y2goc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgY29uc3Qgb24gPSBzdGF0ZS5zZXR0aW5ncy5lbmFibGVkICE9PSBmYWxzZTtcclxuICBtYXN0ZXJTd2l0Y2guY2hlY2tlZCA9IG9uO1xyXG4gIG1hc3RlckxhYmVsLnRleHRDb250ZW50ID0gb24gPyAnT04nIDogJ1BBVVNFRCc7XHJcbiAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKCdwYXVzZWQnLCAhb24pO1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYWludEF1dG9TY3JvbGwoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgY29uc3Qgc2VjcyA9IHN0YXRlLnNldHRpbmdzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYztcclxuICBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWUgPSBTdHJpbmcoc2Vjcyk7XHJcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IFN0cmluZyhzZWNzKTtcclxuICBjb25zdCBhcyA9IHN0YXRlLmF1dG9TY3JvbGw7XHJcbiAgYXV0b1Njcm9sbFN0YXJ0QnRuLmhpZGRlbiA9IGFzLmFjdGl2ZTtcclxuICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmhpZGRlbiA9ICFhcy5hY3RpdmU7XHJcbiAgaWYgKGFzLmFjdGl2ZSkge1xyXG4gICAgY29uc3QgbiA9IGFzLnRhYkNvdW50O1xyXG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9XHJcbiAgICAgIG4gPT09IDAgPyBgcnVubmluZyBcdTIwMTQgbm8gWCB0YWJzIG9wZW5gIDogYHJ1bm5pbmcgXHUyMDE0ICR7bn0gJHtuID09PSAxID8gJ3RhYicgOiAndGFicyd9YDtcclxuICAgIGF1dG9TY3JvbGxTdGF0dXMuY2xhc3NOYW1lID0gJ211dGVkIG9uJztcclxuICB9IGVsc2Uge1xyXG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9ICdpZGxlJztcclxuICAgIGF1dG9TY3JvbGxTdGF0dXMuY2xhc3NOYW1lID0gJ211dGVkJztcclxuICB9XHJcbiAgaWYgKGFzLmFjdGl2ZSB8fCBhcy5zY3JvbGxDb3VudCA+IDAgfHwgYXMuaW5nZXN0ZWRDb3VudCA+IDApIHtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuaGlkZGVuID0gZmFsc2U7XG4gICAgY29uc3QgcGFydHMgPSBbXG4gICAgICBgJHtmbXROdW0oYXMuc2Nyb2xsQ291bnQpfSBzY3JvbGxzYCxcbiAgICAgIGAke2ZtdE51bShhcy5pbmdlc3RlZE5ld0NvdW50KX0gbmV3IGJ1ZmZlcmVkYCxcbiAgICAgIGAke2ZtdE51bShhcy5pbmdlc3RlZEV4aXN0aW5nQ291bnQpfSBvbGQgYnVmZmVyZWRgLFxuICAgIF07XG4gICAgaWYgKGFzLnNraXBwZWRPbGRDb3VudCA+IDApIHBhcnRzLnB1c2goYCR7Zm10TnVtKGFzLnNraXBwZWRPbGRDb3VudCl9IG9sZCBza2lwcGVkYCk7XG4gICAgcGFydHMucHVzaChgJHtmbXROdW0oYXMuZXhwYW5kZWRDb3VudCl9IGV4cGFuZGVkYCk7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLnRleHRDb250ZW50ID0gcGFydHMuam9pbignIFx1MDBCNyAnKTtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuY2xhc3NOYW1lID0gYXMuYWN0aXZlID8gJ3Byb2dyZXNzIG9uJyA6ICdwcm9ncmVzcyc7XG4gIH0gZWxzZSB7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmhpZGRlbiA9IHRydWU7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBwYWludFJlZmV0Y2goc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XHJcbiAgY29uc3QgcSA9IHN0YXRlLnJlZmV0Y2hRdWV1ZTtcclxuICBjb25zdCB0b3RhbCA9IHEudG90YWw7XHJcbiAgY29uc3QgcnVubmluZyA9IHEucnVubmluZztcclxuICByZWZldGNoU2VjdGlvbi5oaWRkZW4gPSB0b3RhbCA9PT0gMCAmJiAhcnVubmluZztcclxuICByZWZldGNoQ291bnQudGV4dENvbnRlbnQgPVxyXG4gICAgdG90YWwgPT09IDBcclxuICAgICAgPyBydW5uaW5nXHJcbiAgICAgICAgPyAnZmluaXNoaW5nXHUyMDI2J1xyXG4gICAgICAgIDogJzAgcXVldWVkJ1xyXG4gICAgICA6IGAke2ZtdE51bSh0b3RhbCl9IHF1ZXVlZCR7cnVubmluZyA/ICcgXHUwMEI3IHJ1bm5pbmcnIDogJyd9YDtcclxuICByZWZldGNoU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcclxuICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcclxuICByZWZldGNoQ2FuY2VsQnRuLmhpZGRlbiA9ICFydW5uaW5nO1xyXG4gIHBhaW50UXVldWVQcm9ncmVzcyhyZWZldGNoUHJvZ3Jlc3MsIHEpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgLy8gUHVsbCBzdHJhaWdodCBmcm9tIHN0b3JhZ2Ugb24gZmlyc3QgcmVuZGVyOyBsaXZlIHVwZGF0ZXMgY29tZSB2aWFcclxuICAvLyBgbG9nLWV2ZW50YCBicm9hZGNhc3RzLlxyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoJ2FjdGl2aXR5Jyk7XHJcbiAgY29uc3QgZXZlbnRzID0gKHN0b3JlZC5hY3Rpdml0eSBhcyBMb2dFdmVudFtdIHwgdW5kZWZpbmVkKSA/PyBbXTtcclxuICByZW5kZXJBY3Rpdml0eShldmVudHMpO1xyXG59XHJcblxyXG4vLyAtLS0gV2lyZSB1cCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuY2FwdHVyZUFsbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICB0cnkge1xyXG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjYXB0dXJlLWFsbCcgfSk7XHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIGNhcHR1cmVBbGxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9XHJcbn0pO1xyXG5cclxuY2FwdHVyZVRoaXNCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtdGhpcy1wYWdlJyB9KTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9XHJcbn0pO1xyXG5cclxuZmx1c2hCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgZmx1c2hCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2ZsdXNoLWFsbCcgfSk7XHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIGZsdXNoQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfVxyXG59KTtcclxuXHJcbmF1dG9Ub2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtYXV0by1jYXB0dXJlJywgb246IGF1dG9Ub2dnbGUuY2hlY2tlZCB9KTtcclxufSk7XHJcblxyXG51cGRhdGVFeGlzdGluZ1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS11cGRhdGUtZXhpc3RpbmcnLCBvbjogdXBkYXRlRXhpc3RpbmdUb2dnbGUuY2hlY2tlZCB9KTtcclxufSk7XHJcblxyXG5tYXN0ZXJTd2l0Y2guYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtZW5hYmxlZCcsIG9uOiBtYXN0ZXJTd2l0Y2guY2hlY2tlZCB9KTtcclxufSk7XHJcblxyXG5hdXRvU2Nyb2xsU3RhcnRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgYXV0b1Njcm9sbFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtYXV0by1zY3JvbGwnIH0pLmZpbmFsbHkoKCkgPT4ge1xyXG4gICAgYXV0b1Njcm9sbFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfSk7XHJcbn0pO1xyXG5hdXRvU2Nyb2xsQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gIGF1dG9TY3JvbGxDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtYXV0by1zY3JvbGwnIH0pLmZpbmFsbHkoKCkgPT4ge1xyXG4gICAgYXV0b1Njcm9sbENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH0pO1xyXG59KTtcclxuXHJcbmF1dG9TY3JvbGxJbnRlcnZhbC5hZGRFdmVudExpc3RlbmVyKCdpbnB1dCcsICgpID0+IHtcclxuICBhdXRvU2Nyb2xsU2Vjc0VsLnRleHRDb250ZW50ID0gYXV0b1Njcm9sbEludGVydmFsLnZhbHVlO1xyXG59KTtcclxuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcclxuICBjb25zdCBzZWNvbmRzID0gTnVtYmVyKGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZSk7XHJcbiAgaWYgKE51bWJlci5pc0Zpbml0ZShzZWNvbmRzKSkge1xyXG4gICAgdm9pZCBzZW5kKHsgdHlwZTogJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCcsIHNlY29uZHMgfSk7XHJcbiAgfVxyXG59KTtcclxuXHJcbnB1cmdlTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xyXG4gIGUucHJldmVudERlZmF1bHQoKTtcclxuICBjb25zdCBvayA9IHdpbmRvdy5jb25maXJtKFxyXG4gICAgJ0Ryb3AgZXZlcnkgY291bnRlciwgcnVuIGJ1ZmZlciwgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHF1ZXVlIGVudHJ5IGZvciBhY2NvdW50cyBub3QgaW4geW91ciB0cmFja2VkIGxpc3Q/XFxuXFxuJyArXHJcbiAgICAgICdUaGlzIG9ubHkgdG91Y2hlcyBsb2NhbCBleHRlbnNpb24gc3RhdGUuIEFscmVhZHktY29tbWl0dGVkIGZpbGVzIGluIHRoZSBHaXRIdWIgcmVwbyBhcmUgbm90IGFmZmVjdGVkIFx1MjAxNCAnICtcclxuICAgICAgJ3J1biBzY3JpcHRzL3B1cmdlX3VucmVsYXRlZC5weSBzZXBhcmF0ZWx5IGlmIHlvdSBhbHNvIHdhbnQgdG8gc2NydWIgdGhlIHJlcG8uJ1xyXG4gICk7XHJcbiAgaWYgKCFvaykgcmV0dXJuO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdwdXJnZS11bnJlbGF0ZWQnIH0pO1xyXG59KTtcclxuXHJcbnJlZmV0Y2hTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC1yZWZldGNoJyB9KS5maW5hbGx5KCgpID0+IHtcclxuICAgIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xyXG4gIH0pO1xyXG59KTtcclxuXHJcbnJlZmV0Y2hDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgcmVmZXRjaENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XHJcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1yZWZldGNoJyB9KS5maW5hbGx5KCgpID0+IHtcclxuICAgIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9KTtcclxufSk7XHJcblxyXG5tZWRpYUNyYXdsU3RhcnRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xyXG4gICAgbWVkaWFDcmF3bFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfSk7XHJcbn0pO1xyXG5cclxubWVkaWFDcmF3bENhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICBtZWRpYUNyYXdsQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLW1lZGlhLWNyYXdsJyB9KS5maW5hbGx5KCgpID0+IHtcclxuICAgIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICB9KTtcclxufSk7XHJcblxyXG5vcHRpb25zTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xyXG4gIGUucHJldmVudERlZmF1bHQoKTtcclxuICB2b2lkIHNlbmQoeyB0eXBlOiAnb3Blbi1vcHRpb25zJyB9KTtcclxufSk7XHJcblxyXG52aWV3ZXJMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XHJcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdvcGVuLXZpZXdlcicgfSk7XHJcbn0pO1xyXG5cclxuY2xlYXJBY3RCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjbGVhci1hY3Rpdml0eScgfSk7XHJcbiAgcmVuZGVyQWN0aXZpdHkoW10pO1xyXG59KTtcclxuXHJcbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93bikgPT4ge1xyXG4gIGlmICghbXNnIHx8IHR5cGVvZiBtc2cgIT09ICdvYmplY3QnKSByZXR1cm47XHJcbiAgY29uc3QgbSA9IG1zZyBhcyB7IHR5cGU/OiBzdHJpbmc7IHN0YXRlPzogRXh0ZW5zaW9uU3RhdGU7IGV2ZW50PzogTG9nRXZlbnQgfTtcclxuICBpZiAobS50eXBlID09PSAnc3RhdGUtY2hhbmdlZCcgJiYgbS5zdGF0ZSkge1xyXG4gICAgbGFzdFN0YXRlID0gbS5zdGF0ZTtcclxuICAgIHBhaW50KG0uc3RhdGUpO1xyXG4gIH0gZWxzZSBpZiAobS50eXBlID09PSAnbG9nLWV2ZW50JyAmJiBtLmV2ZW50KSB7XHJcbiAgICBwcmVwZW5kRXZlbnQobS5ldmVudCk7XHJcbiAgfVxyXG59KTtcclxuXHJcbmZ1bmN0aW9uIHByZXBlbmRFdmVudChldjogTG9nRXZlbnQpOiB2b2lkIHtcclxuICAvLyBJZiB0aGUgbGlzdCBpcyBzaG93aW5nIHRoZSBcImVtcHR5XCIgcGxhY2Vob2xkZXIsIGNsZWFyIGl0LlxyXG4gIGlmIChhY3Rpdml0eUxpc3QuZmlyc3RFbGVtZW50Q2hpbGQ/LmNsYXNzTGlzdC5jb250YWlucygnZW1wdHknKSkge1xyXG4gICAgYWN0aXZpdHlMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xyXG4gIH1cclxuICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XHJcbiAgbGkuY2xhc3NOYW1lID0gYGV2ICR7ZXYubGV2ZWx9YDtcclxuICBjb25zdCB0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICB0cy5jbGFzc05hbWUgPSAnZXYtdHMnO1xyXG4gIHRzLnRleHRDb250ZW50ID0gbmV3IERhdGUoZXYudHMpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tVVMnLCB7IGhvdXIxMjogZmFsc2UgfSk7XHJcbiAgY29uc3QgaWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcclxuICBpY29uLmNsYXNzTmFtZSA9ICdldi1pY29uJztcclxuICBpY29uLnRleHRDb250ZW50ID0gZXYubGV2ZWwgPT09ICdlcnJvcicgPyAnXHUyNzE3JyA6IGV2LmxldmVsID09PSAnd2FybicgPyAnIScgOiAnXHUwMEI3JztcclxuICBjb25zdCBib2R5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xyXG4gIGNvbnN0IG1zZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xyXG4gIG1zZy5jbGFzc05hbWUgPSAnZXYtbXNnJztcclxuICBtc2cudGV4dENvbnRlbnQgPSBldi5tc2c7XHJcbiAgYm9keS5hcHBlbmQobXNnKTtcclxuICBjb25zdCBjdHhLZXlzID0gT2JqZWN0LmtleXMoZXYuY29udGV4dCk7XHJcbiAgaWYgKGN0eEtleXMubGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgY3R4ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICBjdHguY2xhc3NOYW1lID0gJ2V2LWN0eCc7XHJcbiAgICBjdHgudGV4dENvbnRlbnQgPSBjdHhLZXlzLm1hcCgoaykgPT4gYCR7a309JHtzdHJpbmdpZnlTaG9ydChldi5jb250ZXh0W2tdKX1gKS5qb2luKCcgXHUwMEI3ICcpO1xyXG4gICAgYm9keS5hcHBlbmQoY3R4KTtcclxuICB9XHJcbiAgbGkuYXBwZW5kKHRzLCBpY29uLCBib2R5KTtcclxuICBhY3Rpdml0eUxpc3QucHJlcGVuZChsaSk7XHJcbiAgd2hpbGUgKGFjdGl2aXR5TGlzdC5jaGlsZEVsZW1lbnRDb3VudCA+IEFDVElWSVRZX1RBSUxfTUFYKSB7XHJcbiAgICBhY3Rpdml0eUxpc3QubGFzdEVsZW1lbnRDaGlsZD8ucmVtb3ZlKCk7XHJcbiAgfVxyXG59XHJcblxyXG4vLyBJbml0aWFsIHBhaW50LlxyXG52b2lkIHJlZnJlc2hTdGF0ZSgpO1xyXG52b2lkIHJlZnJlc2hBY3Rpdml0eSgpO1xyXG5cclxuLy8gUGVyaW9kaWNhbGx5IHJlLWZldGNoIHN0YXRlIHNvIFwibGFzdCBjYXB0dXJlXCIgdGltZXMgc3RheSBmcmVzaC5cclxuc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gIHZvaWQgcmVmcmVzaFN0YXRlKCk7XHJcbn0sIDE1XzAwMCk7XHJcbiJdLAogICJtYXBwaW5ncyI6ICI7QUEwRk8sSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLOzs7QUNsRnZELElBQU0sSUFBSSxDQUFzQyxPQUFrQjtBQUNoRSxRQUFNLEtBQUssU0FBUyxlQUFlLEVBQUU7QUFDckMsTUFBSSxDQUFDLEdBQUksT0FBTSxJQUFJLE1BQU0sb0JBQW9CLEVBQUUsRUFBRTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxJQUFNLFVBQVUsRUFBRSxVQUFVO0FBQzVCLElBQU0sV0FBVyxFQUFtQixXQUFXO0FBQy9DLElBQU0sY0FBYyxFQUFvQixjQUFjO0FBQ3RELElBQU0sZUFBZSxFQUFvQixlQUFlO0FBQ3hELElBQU0sYUFBYSxFQUFvQixjQUFjO0FBQ3JELElBQU0sdUJBQXVCLEVBQW9CLGlCQUFpQjtBQUNsRSxJQUFNLGdCQUFnQixFQUFxQixhQUFhO0FBQ3hELElBQU0saUJBQWlCLEVBQXFCLGNBQWM7QUFDMUQsSUFBTSxXQUFXLEVBQXFCLFdBQVc7QUFDakQsSUFBTSxjQUFjLEVBQXFCLGNBQWM7QUFDdkQsSUFBTSxhQUFhLEVBQXFCLGFBQWE7QUFDckQsSUFBTSxjQUFjLEVBQXFCLGdCQUFnQjtBQUN6RCxJQUFNLGVBQWUsRUFBbUIsYUFBYTtBQUNyRCxJQUFNLGVBQWUsRUFBb0IsZUFBZTtBQUN4RCxJQUFNLGNBQWMsRUFBbUIsY0FBYztBQUNyRCxJQUFNLHFCQUFxQixFQUFvQixzQkFBc0I7QUFDckUsSUFBTSxtQkFBbUIsRUFBbUIsa0JBQWtCO0FBQzlELElBQU0sbUJBQW1CLEVBQW1CLG9CQUFvQjtBQUNoRSxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLGlCQUFpQixFQUFlLGlCQUFpQjtBQUN2RCxJQUFNLGVBQWUsRUFBbUIsZUFBZTtBQUN2RCxJQUFNLGtCQUFrQixFQUFxQixlQUFlO0FBQzVELElBQU0sbUJBQW1CLEVBQXFCLGdCQUFnQjtBQUM5RCxJQUFNLGtCQUFrQixFQUFtQixrQkFBa0I7QUFDN0QsSUFBTSxvQkFBb0IsRUFBZSxxQkFBcUI7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsbUJBQW1CO0FBQzlELElBQU0scUJBQXFCLEVBQXFCLG1CQUFtQjtBQUNuRSxJQUFNLHNCQUFzQixFQUFxQixvQkFBb0I7QUFDckUsSUFBTSxxQkFBcUIsRUFBbUIsc0JBQXNCO0FBQ3BFLElBQU0sWUFBWSxFQUFxQixpQkFBaUI7QUFFeEQsSUFBSSxZQUFtQztBQUV2QyxlQUFlLEtBQVEsS0FBaUM7QUFDdEQsU0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ3hDO0FBRUEsU0FBUyxjQUFjLE9BQTZCO0FBQ2xELFFBQU0sRUFBRSxZQUFZLFNBQVMsSUFBSTtBQUNqQyxNQUFJLE1BQU07QUFDVixNQUFJLE9BQU87QUFLWCxRQUFNLGdCQUNKLFdBQVcsV0FBVyxRQUFRLFNBQVMsVUFBVSxXQUFXLDJCQUEyQjtBQUN6RixNQUFJLENBQUMsU0FBUyxRQUFRO0FBQ3BCLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLGVBQWU7QUFDeEIsVUFBTTtBQUNOLFdBQU8sV0FBVyxTQUFTLE1BQU0sdUJBQXVCLFNBQVMsS0FBSyxJQUFJLFNBQVMsSUFBSSw0Q0FBdUMsV0FBVyxpQkFBaUIsUUFBUTtBQUFBLEVBQ3BLLFdBQVcsV0FBVyxXQUFXLE1BQU07QUFDckMsVUFBTTtBQUNOLFdBQU8saUJBQWlCLFdBQVcsU0FBUyxHQUFHLE9BQU8sU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLGVBQU8sU0FBUyxTQUFTO0FBQUEsRUFDaEgsV0FBVyxXQUFXLFdBQVcsY0FBYztBQUM3QyxVQUFNO0FBQ04sV0FBTyxpQkFBaUIsV0FBVyxLQUFLLElBQ3BDLG9FQUNBO0FBQUEsRUFDTixXQUFXLFdBQVcsV0FBVyxnQkFBZ0I7QUFDL0MsVUFBTTtBQUNOLFVBQU0sU0FBUyxrQkFBa0IsV0FBVyxnQkFBZ0I7QUFDNUQsV0FBTyxTQUNILHFDQUFnQyxNQUFNLEtBQ3RDO0FBQUEsRUFDTixXQUFXLFdBQVcsV0FBVyxpQkFBaUI7QUFDaEQsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsV0FBVyxXQUFXLGtCQUFrQjtBQUNqRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsT0FBTztBQUNMLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNBLFVBQVEsWUFBWSxPQUFPLEdBQUc7QUFDOUIsV0FBUyxjQUFjO0FBQ3ZCLFdBQVMsUUFBUSxXQUFXLFNBQVM7QUFDdkM7QUFFQSxTQUFTLE9BQU8sS0FBNEI7QUFDMUMsTUFBSSxDQUFDLElBQUssUUFBTztBQUNqQixRQUFNLElBQUksS0FBSyxNQUFNLEdBQUc7QUFDeEIsTUFBSSxDQUFDLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUNoQyxRQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSSxDQUFDO0FBQzVELE1BQUksT0FBTyxFQUFHLFFBQU87QUFDckIsTUFBSSxPQUFPLEdBQUksUUFBTyxHQUFHLElBQUk7QUFDN0IsUUFBTSxPQUFPLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDakMsTUFBSSxPQUFPLEdBQUksUUFBTyxHQUFHLElBQUk7QUFDN0IsUUFBTSxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDbEMsTUFBSSxRQUFRLEdBQUksUUFBTyxHQUFHLEtBQUs7QUFDL0IsUUFBTSxPQUFPLEtBQUssTUFBTSxRQUFRLEVBQUU7QUFDbEMsU0FBTyxHQUFHLElBQUk7QUFDaEI7QUFFQSxTQUFTLGtCQUFrQixVQUFpQztBQUMxRCxNQUFJLGFBQWEsS0FBTSxRQUFPO0FBQzlCLFFBQU0sV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQ3hELE1BQUksWUFBWSxFQUFHLFFBQU87QUFDMUIsUUFBTSxZQUFZLElBQUksS0FBSyxXQUFXLEdBQUksRUFBRSxtQkFBbUIsQ0FBQyxHQUFHO0FBQUEsSUFDakUsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNELE1BQUksV0FBVyxHQUFJLFFBQU8sTUFBTSxRQUFRLE1BQU0sU0FBUztBQUN2RCxRQUFNLE9BQU8sS0FBSyxNQUFNLFdBQVcsRUFBRTtBQUNyQyxNQUFJLE9BQU8sR0FBSSxRQUFPLE1BQU0sSUFBSSxNQUFNLFNBQVM7QUFDL0MsUUFBTSxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDbEMsU0FBTyxNQUFNLEtBQUssTUFBTSxTQUFTO0FBQ25DO0FBRUEsU0FBUyxPQUFPLEdBQW1CO0FBQ2pDLFNBQU8sRUFBRSxlQUFlLE9BQU87QUFDakM7QUFFQSxTQUFTLGlCQUFpQixTQUFpQztBQUN6RCxTQUNFLE9BQU8sWUFBWSxZQUNuQiw2RUFBNkUsS0FBSyxPQUFPO0FBRTdGO0FBRUEsU0FBUyxlQUFlLE9BQTZCO0FBQ25ELGNBQVksZ0JBQWdCO0FBQzVCLE1BQUksTUFBTSxTQUFTLFdBQVcsR0FBRztBQUMvQixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLGdCQUFZLE9BQU8sRUFBRTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLEtBQUssTUFBTSxVQUFVO0FBQzlCLFVBQU0sSUFBSSxNQUFNLFNBQVMsRUFBRSxNQUFNO0FBQ2pDLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksS0FBSyxFQUFFLGdCQUFnQixJQUFJLGdCQUFnQjtBQUUxRCxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBQ2pCLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVk7QUFDbkIsV0FBTyxZQUFZLDRCQUE0QixXQUFXLEVBQUUsTUFBTSxDQUFDO0FBQ25FLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLEVBQUU7QUFDckIsU0FBSyxPQUFPLFFBQVEsSUFBSTtBQUV4QixVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFVBQU0sUUFBUSxTQUFTLGNBQWMsTUFBTTtBQUMzQyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxRQUFRLEdBQUcsY0FBYztBQUMvQixVQUFNLFdBQVcsR0FBRyxpQkFBaUI7QUFDckMsVUFBTSxPQUFPLEdBQUcsaUJBQWlCO0FBQ2pDLFVBQU0sWUFDSixxQkFBcUIsT0FBTyxLQUFLLENBQUMsbUJBQ2pDLFdBQVcsSUFBSSwyQkFBd0IsT0FBTyxRQUFRLENBQUMscUJBQXFCLE1BQzdFLGNBQVcsV0FBVyxPQUFPLElBQUksQ0FBQyxDQUFDO0FBRXJDLFVBQU0sVUFBVSxTQUFTLGNBQWMsTUFBTTtBQUM3QyxZQUFRLFlBQVk7QUFDcEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxRQUFRO0FBQzNDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWM7QUFDbEIsUUFBSSxpQkFBaUIsU0FBUyxZQUFZO0FBQ3hDLFVBQUksV0FBVztBQUNmLFVBQUk7QUFDRixjQUFNLEtBQUssRUFBRSxNQUFNLGVBQWUsUUFBUSxFQUFFLE9BQU8sQ0FBQztBQUFBLE1BQ3RELFVBQUU7QUFDQSxZQUFJLFdBQVc7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUNELFlBQVEsT0FBTyxHQUFHO0FBRWxCLFFBQUksT0FBTyxPQUFPLE9BQU87QUFDekIsT0FBRyxPQUFPLE1BQU0sR0FBRztBQUNuQixnQkFBWSxPQUFPLEVBQUU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyxlQUFlLFFBQTBCO0FBQ2hELGVBQWEsZ0JBQWdCO0FBQzdCLE1BQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixpQkFBYSxPQUFPLEVBQUU7QUFDdEI7QUFBQSxFQUNGO0FBQ0EsYUFBVyxNQUFNLE9BQU8sTUFBTSxHQUFHLGlCQUFpQixHQUFHO0FBQ25ELFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDN0IsVUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQ3hDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUM5RSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxHQUFHLFVBQVUsVUFBVSxXQUFNLEdBQUcsVUFBVSxTQUFTLE1BQU07QUFDNUUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLEdBQUc7QUFDckIsU0FBSyxPQUFPLEdBQUc7QUFDZixVQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTztBQUN0QyxRQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLFlBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxVQUFJLFlBQVk7QUFDaEIsVUFBSSxjQUFjLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssUUFBSztBQUN4RixXQUFLLE9BQU8sR0FBRztBQUFBLElBQ2pCO0FBQ0EsT0FBRyxPQUFPLElBQUksTUFBTSxJQUFJO0FBQ3hCLGlCQUFhLE9BQU8sRUFBRTtBQUFBLEVBQ3hCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBb0I7QUFDMUMsTUFBSSxNQUFNLEtBQU0sUUFBTztBQUN2QixNQUFJLE9BQU8sTUFBTSxTQUFVLFFBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUN6RSxNQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxVQUFXLFFBQU8sT0FBTyxDQUFDO0FBQ3BFLE1BQUk7QUFDRixVQUFNLElBQUksS0FBSyxVQUFVLENBQUM7QUFDMUIsV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsR0FBbUI7QUFDckMsU0FBTyxFQUFFO0FBQUEsSUFBUTtBQUFBLElBQVksQ0FBQyxNQUM1QixNQUFNLE1BQU0sVUFBVSxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sV0FBVztBQUFBLEVBQ3pGO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLE1BQUk7QUFDRixnQkFBWSxNQUFNLEtBQXFCLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFDNUQsVUFBTSxTQUFTO0FBQUEsRUFDakIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDZDQUE2QyxHQUFHO0FBQUEsRUFDL0Q7QUFDRjtBQUVBLFNBQVMsTUFBTSxPQUE2QjtBQUMxQyxlQUFhLGNBQWMsTUFBTTtBQUNqQyxnQkFBYyxLQUFLO0FBQ25CLGFBQVcsVUFBVSxNQUFNLFNBQVM7QUFDcEMsdUJBQXFCLFVBQVUsTUFBTSxTQUFTLG1CQUFtQjtBQUNqRSxhQUFXLE9BQU8sV0FBVyxNQUFNLFNBQVMsS0FBSyxjQUFjLE1BQU0sU0FBUyxJQUFJO0FBQ2xGLG9CQUFrQixLQUFLO0FBQ3ZCLGlCQUFlLEtBQUs7QUFDcEIsa0JBQWdCLEtBQUs7QUFDckIsa0JBQWdCLEtBQUs7QUFDckIsZUFBYSxLQUFLO0FBQ3BCO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsb0JBQWtCLFNBQVMsVUFBVSxLQUFLLENBQUM7QUFDM0Msa0JBQWdCLGNBQ2QsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELHFCQUFtQixTQUFTO0FBQzVCLHFCQUFtQixXQUFXLFVBQVU7QUFDeEMsc0JBQW9CLFNBQVMsQ0FBQztBQUM5QixxQkFBbUIsb0JBQW9CLENBQUM7QUFDMUM7QUFFQSxTQUFTLG1CQUNQLElBQ0EsR0FDTTtBQUNOLE1BQUksQ0FBQyxFQUFFLFdBQVcsRUFBRSxjQUFjLEdBQUc7QUFDbkMsT0FBRyxTQUFTO0FBQ1o7QUFBQSxFQUNGO0FBR0EsUUFBTSxRQUFRLEtBQUssSUFBSSxFQUFFLGdCQUFnQixFQUFFLFlBQVksRUFBRSxLQUFLO0FBQzlELEtBQUcsU0FBUztBQUNaLEtBQUcsY0FBYyxHQUFHLE9BQU8sRUFBRSxTQUFTLENBQUMsTUFBTSxPQUFPLEtBQUssQ0FBQztBQUMxRCxLQUFHLFlBQVksRUFBRSxVQUFVLGdCQUFnQjtBQUM3QztBQUVBLFNBQVMsa0JBQWtCLE9BQTZCO0FBQ3RELFFBQU0sS0FBSyxNQUFNLFNBQVMsWUFBWTtBQUN0QyxlQUFhLFVBQVU7QUFDdkIsY0FBWSxjQUFjLEtBQUssT0FBTztBQUN0QyxXQUFTLEtBQUssVUFBVSxPQUFPLFVBQVUsQ0FBQyxFQUFFO0FBQzlDO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxPQUFPLE1BQU0sU0FBUztBQUM1QixxQkFBbUIsUUFBUSxPQUFPLElBQUk7QUFDdEMsbUJBQWlCLGNBQWMsT0FBTyxJQUFJO0FBQzFDLFFBQU0sS0FBSyxNQUFNO0FBQ2pCLHFCQUFtQixTQUFTLEdBQUc7QUFDL0Isc0JBQW9CLFNBQVMsQ0FBQyxHQUFHO0FBQ2pDLE1BQUksR0FBRyxRQUFRO0FBQ2IsVUFBTSxJQUFJLEdBQUc7QUFDYixxQkFBaUIsY0FDZixNQUFNLElBQUksa0NBQTZCLGtCQUFhLENBQUMsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNO0FBQ25GLHFCQUFpQixZQUFZO0FBQUEsRUFDL0IsT0FBTztBQUNMLHFCQUFpQixjQUFjO0FBQy9CLHFCQUFpQixZQUFZO0FBQUEsRUFDL0I7QUFDQSxNQUFJLEdBQUcsVUFBVSxHQUFHLGNBQWMsS0FBSyxHQUFHLGdCQUFnQixHQUFHO0FBQzNELHVCQUFtQixTQUFTO0FBQzVCLFVBQU0sUUFBUTtBQUFBLE1BQ1osR0FBRyxPQUFPLEdBQUcsV0FBVyxDQUFDO0FBQUEsTUFDekIsR0FBRyxPQUFPLEdBQUcsZ0JBQWdCLENBQUM7QUFBQSxNQUM5QixHQUFHLE9BQU8sR0FBRyxxQkFBcUIsQ0FBQztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxHQUFHLGtCQUFrQixFQUFHLE9BQU0sS0FBSyxHQUFHLE9BQU8sR0FBRyxlQUFlLENBQUMsY0FBYztBQUNsRixVQUFNLEtBQUssR0FBRyxPQUFPLEdBQUcsYUFBYSxDQUFDLFdBQVc7QUFDakQsdUJBQW1CLGNBQWMsTUFBTSxLQUFLLFFBQUs7QUFDakQsdUJBQW1CLFlBQVksR0FBRyxTQUFTLGdCQUFnQjtBQUFBLEVBQzdELE9BQU87QUFDTCx1QkFBbUIsU0FBUztBQUFBLEVBQzlCO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsT0FBNkI7QUFDakQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsaUJBQWUsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUN4QyxlQUFhLGNBQ1gsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELGtCQUFnQixTQUFTO0FBQ3pCLGtCQUFnQixXQUFXLFVBQVU7QUFDckMsbUJBQWlCLFNBQVMsQ0FBQztBQUMzQixxQkFBbUIsaUJBQWlCLENBQUM7QUFDdkM7QUFFQSxlQUFlLGtCQUFpQztBQUc5QyxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLFVBQVU7QUFDekQsUUFBTSxTQUFVLE9BQU8sWUFBdUMsQ0FBQztBQUMvRCxpQkFBZSxNQUFNO0FBQ3ZCO0FBSUEsY0FBYyxpQkFBaUIsU0FBUyxZQUFZO0FBQ2xELGdCQUFjLFdBQVc7QUFDekIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQUEsRUFDcEMsVUFBRTtBQUNBLGtCQUFjLFdBQVc7QUFBQSxFQUMzQjtBQUNGLENBQUM7QUFFRCxlQUFlLGlCQUFpQixTQUFTLFlBQVk7QUFDbkQsaUJBQWUsV0FBVztBQUMxQixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUFBLEVBQzFDLFVBQUU7QUFDQSxtQkFBZSxXQUFXO0FBQUEsRUFDNUI7QUFDRixDQUFDO0FBRUQsU0FBUyxpQkFBaUIsU0FBUyxZQUFZO0FBQzdDLFdBQVMsV0FBVztBQUNwQixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFBQSxFQUNsQyxVQUFFO0FBQ0EsYUFBUyxXQUFXO0FBQUEsRUFDdEI7QUFDRixDQUFDO0FBRUQsV0FBVyxpQkFBaUIsVUFBVSxNQUFNO0FBQzFDLE9BQUssS0FBSyxFQUFFLE1BQU0sdUJBQXVCLElBQUksV0FBVyxRQUFRLENBQUM7QUFDbkUsQ0FBQztBQUVELHFCQUFxQixpQkFBaUIsVUFBVSxNQUFNO0FBQ3BELE9BQUssS0FBSyxFQUFFLE1BQU0sMEJBQTBCLElBQUkscUJBQXFCLFFBQVEsQ0FBQztBQUNoRixDQUFDO0FBRUQsYUFBYSxpQkFBaUIsVUFBVSxNQUFNO0FBQzVDLE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLElBQUksYUFBYSxRQUFRLENBQUM7QUFDaEUsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUNELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELG1CQUFpQixjQUFjLG1CQUFtQjtBQUNwRCxDQUFDO0FBQ0QsbUJBQW1CLGlCQUFpQixVQUFVLE1BQU07QUFDbEQsUUFBTSxVQUFVLE9BQU8sbUJBQW1CLEtBQUs7QUFDL0MsTUFBSSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzVCLFNBQUssS0FBSyxFQUFFLE1BQU0sNEJBQTRCLFFBQVEsQ0FBQztBQUFBLEVBQ3pEO0FBQ0YsQ0FBQztBQUVELFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2hELElBQUUsZUFBZTtBQUNqQixRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFHRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsT0FBSyxLQUFLLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUN2QyxDQUFDO0FBRUQsZ0JBQWdCLGlCQUFpQixTQUFTLE1BQU07QUFDOUMsa0JBQWdCLFdBQVc7QUFDM0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNqRCxvQkFBZ0IsV0FBVztBQUFBLEVBQzdCLENBQUM7QUFDSCxDQUFDO0FBRUQsaUJBQWlCLGlCQUFpQixTQUFTLE1BQU07QUFDL0MsbUJBQWlCLFdBQVc7QUFDNUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNsRCxxQkFBaUIsV0FBVztBQUFBLEVBQzlCLENBQUM7QUFDSCxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQscUJBQW1CLFdBQVc7QUFDOUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNyRCx1QkFBbUIsV0FBVztBQUFBLEVBQ2hDLENBQUM7QUFDSCxDQUFDO0FBRUQsb0JBQW9CLGlCQUFpQixTQUFTLE1BQU07QUFDbEQsc0JBQW9CLFdBQVc7QUFDL0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUN0RCx3QkFBb0IsV0FBVztBQUFBLEVBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRUQsWUFBWSxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3BDLENBQUM7QUFFRCxXQUFXLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNqRCxJQUFFLGVBQWU7QUFDakIsT0FBSyxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDbkMsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsWUFBWTtBQUNoRCxRQUFNLEtBQUssRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3JDLGlCQUFlLENBQUMsQ0FBQztBQUNuQixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLFFBQWlCO0FBQ3RELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVO0FBQ3JDLFFBQU0sSUFBSTtBQUNWLE1BQUksRUFBRSxTQUFTLG1CQUFtQixFQUFFLE9BQU87QUFDekMsZ0JBQVksRUFBRTtBQUNkLFVBQU0sRUFBRSxLQUFLO0FBQUEsRUFDZixXQUFXLEVBQUUsU0FBUyxlQUFlLEVBQUUsT0FBTztBQUM1QyxpQkFBYSxFQUFFLEtBQUs7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxTQUFTLGFBQWEsSUFBb0I7QUFFeEMsTUFBSSxhQUFhLG1CQUFtQixVQUFVLFNBQVMsT0FBTyxHQUFHO0FBQy9ELGlCQUFhLGdCQUFnQjtBQUFBLEVBQy9CO0FBQ0EsUUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLEtBQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixRQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsS0FBRyxZQUFZO0FBQ2YsS0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFFBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxPQUFLLFlBQVk7QUFDakIsT0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsUUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLE1BQUksWUFBWTtBQUNoQixNQUFJLGNBQWMsR0FBRztBQUNyQixPQUFLLE9BQU8sR0FBRztBQUNmLFFBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLE1BQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFNBQUssT0FBTyxHQUFHO0FBQUEsRUFDakI7QUFDQSxLQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsZUFBYSxRQUFRLEVBQUU7QUFDdkIsU0FBTyxhQUFhLG9CQUFvQixtQkFBbUI7QUFDekQsaUJBQWEsa0JBQWtCLE9BQU87QUFBQSxFQUN4QztBQUNGO0FBR0EsS0FBSyxhQUFhO0FBQ2xCLEtBQUssZ0JBQWdCO0FBR3JCLFlBQVksTUFBTTtBQUNoQixPQUFLLGFBQWE7QUFDcEIsR0FBRyxJQUFNOyIsCiAgIm5hbWVzIjogW10KfQo=
