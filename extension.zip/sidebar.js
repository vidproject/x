// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var autoScrollToggle = $("auto-scroll");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = `Auth error \u2014 check your PAT`;
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    text = "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  renderAccounts(state);
  paintAutoScroll(state);
  paintRefetch(state);
}
function paintAutoScroll(state) {
  autoScrollToggle.checked = state.settings.autoScroll;
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  if (state.settings.autoScroll) {
    const n = state.autoScroll.tabCount;
    autoScrollStatus.textContent = n === 0 ? "on \u2014 no X tabs open" : `on \u2014 scrolling ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "rate-info on";
  } else {
    autoScrollStatus.textContent = "off";
    autoScrollStatus.className = "rate-info";
  }
}
function paintRefetch(state) {
  const total = state.refetchQueue.total;
  const running = state.refetchQueue.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
autoScrollToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-scroll", on: autoScrollToggle.checked });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbDogZmFsc2UsXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcbn07XG5cbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XG5cbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknIH0sXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JyB9LFxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicgfSxcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnIH0sXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJyB9LFxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknIH0sXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycgfSxcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBzaWRlYmFyLnRzIFx1MjAxNCBVSSBmb3IgdGhlIHBlcnNpc3RlbnQgc2lkZWJhci5cbiAqXG4gKiBTaWRlYmFycyBpbiBGaXJlZm94IHN0YXkgb3BlbiBhY3Jvc3MgdGFiL3dpbmRvdyBzd2l0Y2hlcywgd2hpY2ggaXMgdGhlXG4gKiBpbnRlbmRlZCBwZXJzaXN0ZW5jZSBtb2RlbC4gVGhpcyBtb2R1bGUgcmVuZGVycyBzdGF0ZSBwdXNoZWQgZnJvbSB0aGVcbiAqIGJhY2tncm91bmQgc2VydmljZSB3b3JrZXIgYW5kIGZvcndhcmRzIHVzZXIgY29tbWFuZHMgYmFjay5cbiAqL1xuXG5pbXBvcnQgeyBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7IEV4dGVuc2lvblN0YXRlLCBMb2dFdmVudCwgUnVudGltZU1lc3NhZ2UgfSBmcm9tICcuL2xpYi90eXBlcy5qcyc7XG5cbmNvbnN0ICQgPSA8VCBleHRlbmRzIEhUTUxFbGVtZW50ID0gSFRNTEVsZW1lbnQ+KGlkOiBzdHJpbmcpOiBUID0+IHtcbiAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCk7XG4gIGlmICghZWwpIHRocm93IG5ldyBFcnJvcihgbWlzc2luZyBlbGVtZW50ICMke2lkfWApO1xuICByZXR1cm4gZWwgYXMgVDtcbn07XG5cbmNvbnN0IGNvbm5Eb3QgPSAkKCdjb25uLWRvdCcpO1xuY29uc3QgY29ublRleHQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2Nvbm4tdGV4dCcpO1xuY29uc3QgYWNjb3VudExpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdhY2NvdW50LWxpc3QnKTtcbmNvbnN0IGFjdGl2aXR5TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjdGl2aXR5LWxpc3QnKTtcbmNvbnN0IGF1dG9Ub2dnbGUgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdhdXRvLWNhcHR1cmUnKTtcbmNvbnN0IGNhcHR1cmVBbGxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2FwdHVyZS1hbGwnKTtcbmNvbnN0IGNhcHR1cmVUaGlzQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtdGhpcycpO1xuY29uc3QgZmx1c2hCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignZmx1c2gtYWxsJyk7XG5jb25zdCBvcHRpb25zTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdvcGVuLW9wdGlvbnMnKTtcbmNvbnN0IHZpZXdlckxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi12aWV3ZXInKTtcbmNvbnN0IGNsZWFyQWN0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NsZWFyLWFjdGl2aXR5Jyk7XG5jb25zdCBleHRWZXJzaW9uRWwgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2V4dC12ZXJzaW9uJyk7XG5jb25zdCBhdXRvU2Nyb2xsVG9nZ2xlID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1zY3JvbGwnKTtcbmNvbnN0IGF1dG9TY3JvbGxJbnRlcnZhbCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tc2Nyb2xsLWludGVydmFsJyk7XG5jb25zdCBhdXRvU2Nyb2xsU2Vjc0VsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zZWNzJyk7XG5jb25zdCBhdXRvU2Nyb2xsU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zdGF0dXMnKTtcbmNvbnN0IHJlZmV0Y2hTZWN0aW9uID0gJDxIVE1MRWxlbWVudD4oJ3JlZmV0Y2gtc2VjdGlvbicpO1xuY29uc3QgcmVmZXRjaENvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdyZWZldGNoLWNvdW50Jyk7XG5jb25zdCByZWZldGNoU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1zdGFydCcpO1xuY29uc3QgcmVmZXRjaENhbmNlbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZWZldGNoLWNhbmNlbCcpO1xuXG5sZXQgbGFzdFN0YXRlOiBFeHRlbnNpb25TdGF0ZSB8IG51bGwgPSBudWxsO1xuXG5hc3luYyBmdW5jdGlvbiBzZW5kPFQ+KG1zZzogUnVudGltZU1lc3NhZ2UpOiBQcm9taXNlPFQ+IHtcbiAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZShtc2cpIGFzIFByb21pc2U8VD47XG59XG5cbmZ1bmN0aW9uIHNldENvbm5TdGF0dXMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHsgY29ubmVjdGlvbiwgc2V0dGluZ3MgfSA9IHN0YXRlO1xuICBsZXQgY2xzID0gJyc7XG4gIGxldCB0ZXh0ID0gJyc7XG4gIC8vIE9ubHkgd2FybiB3aGVuIHRoZSBjb25maWd1cmVkIGJyYW5jaCBnZW51aW5lbHkgZG9lc24ndCBleGlzdCBvbiB0aGVcbiAgLy8gcmVtb3RlLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCB0aGF0IGV4aXN0cyBpcyBmaW5lIFx1MjAxNCBjYXB0dXJpbmcgaW50byBhXG4gIC8vIHdvcmtpbmcgYnJhbmNoIGlzIHJvdXRpbmUgXHUyMDE0IHNvIHRoZSBtZXJlIGAhPT1gIHRvIGRlZmF1bHRfYnJhbmNoIGlzIG5vdFxuICAvLyBhIHByb2JsZW0gYW5kIHNob3VsZG4ndCBzaG91dCBpbiB0aGUgaGVhZGVyLlxuICBjb25zdCBicmFuY2hNaXNzaW5nID1cbiAgICBjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ29rJyAmJiBzZXR0aW5ncy5icmFuY2ggJiYgY29ubmVjdGlvbi5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSBmYWxzZTtcbiAgaWYgKCFzZXR0aW5ncy5wYXRTZXQpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XG4gIH0gZWxzZSBpZiAoYnJhbmNoTWlzc2luZykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSBgQnJhbmNoIFwiJHtzZXR0aW5ncy5icmFuY2h9XCIgZG9lcyBub3QgZXhpc3Qgb24gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTIwMTQgY29tbWl0cyB3aWxsIDQyMi4gU2V0IGJyYW5jaCB0byBcIiR7Y29ubmVjdGlvbi5kZWZhdWx0QnJhbmNoID8/ICdtYXN0ZXInfVwiIGluIFNldHRpbmdzLmA7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycpIHtcbiAgICBjbHMgPSAnb2snO1xuICAgIHRleHQgPSBgQ29ubmVjdGVkIGFzIEAke2Nvbm5lY3Rpb24ubG9naW4gPz8gJz8nfSB0byAke3NldHRpbmdzLm93bmVyfS8ke3NldHRpbmdzLnJlcG99IFx1MDBCNyBcdTIwMjYke3NldHRpbmdzLnBhdFN1ZmZpeH1gO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gYEF1dGggZXJyb3IgXHUyMDE0IGNoZWNrIHlvdXIgUEFUYDtcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdHaXRIdWIgcmF0ZS1saW1pdGVkIFx1MjAxNCBjYXB0dXJlcyB3aWxsIHJldHJ5JztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ25ldHdvcmstZXJyb3InKSB7XG4gICAgY2xzID0gJ2Vycic7XG4gICAgdGV4dCA9ICdOZXR3b3JrIGVycm9yIFx1MjAxNCBjaGVjayBjb25uZWN0aXZpdHknO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnbm90LWNvbmZpZ3VyZWQnKSB7XG4gICAgY2xzID0gJ3dhcm4nO1xuICAgIHRleHQgPSAnTm90IGNvbmZpZ3VyZWQgXHUyMDE0IG9wZW4gU2V0dGluZ3MnO1xuICB9IGVsc2Uge1xuICAgIGNscyA9ICcnO1xuICAgIHRleHQgPSAnQ2hlY2tpbmdcdTIwMjYnO1xuICB9XG4gIGNvbm5Eb3QuY2xhc3NOYW1lID0gYGRvdCAke2Nsc31gO1xuICBjb25uVGV4dC50ZXh0Q29udGVudCA9IHRleHQ7XG4gIGNvbm5UZXh0LnRpdGxlID0gY29ubmVjdGlvbi5lcnJvciA/PyAnJztcbn1cblxuZnVuY3Rpb24gZm10UmVsKGlzbzogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB7XG4gIGlmICghaXNvKSByZXR1cm4gJ1x1MjAxNCc7XG4gIGNvbnN0IGQgPSBEYXRlLnBhcnNlKGlzbyk7XG4gIGlmICghTnVtYmVyLmlzRmluaXRlKGQpKSByZXR1cm4gJ1x1MjAxNCc7XG4gIGNvbnN0IHNlY3MgPSBNYXRoLm1heCgwLCBNYXRoLnJvdW5kKChEYXRlLm5vdygpIC0gZCkgLyAxMDAwKSk7XG4gIGlmIChzZWNzIDwgNSkgcmV0dXJuICdqdXN0IG5vdyc7XG4gIGlmIChzZWNzIDwgNjApIHJldHVybiBgJHtzZWNzfXMgYWdvYDtcbiAgY29uc3QgbWlucyA9IE1hdGgucm91bmQoc2VjcyAvIDYwKTtcbiAgaWYgKG1pbnMgPCA2MCkgcmV0dXJuIGAke21pbnN9bSBhZ29gO1xuICBjb25zdCBob3VycyA9IE1hdGgucm91bmQobWlucyAvIDYwKTtcbiAgaWYgKGhvdXJzIDwgMjQpIHJldHVybiBgJHtob3Vyc31oIGFnb2A7XG4gIGNvbnN0IGRheXMgPSBNYXRoLnJvdW5kKGhvdXJzIC8gMjQpO1xuICByZXR1cm4gYCR7ZGF5c31kIGFnb2A7XG59XG5cbmZ1bmN0aW9uIGZtdE51bShuOiBudW1iZXIpOiBzdHJpbmcge1xuICByZXR1cm4gbi50b0xvY2FsZVN0cmluZygnZW4tVVMnKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQWNjb3VudHMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGFjY291bnRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBpZiAoc3RhdGUuYWNjb3VudHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWNjb3VudHMgY29uZmlndXJlZC4nO1xuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3QgYSBvZiBzdGF0ZS5hY2NvdW50cykge1xuICAgIGNvbnN0IGMgPSBzdGF0ZS5jb3VudGVyc1thLmhhbmRsZV07XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9IGMgJiYgYy5idWZmZXJlZENvdW50ID4gMCA/ICdhY2MgcGVuZGluZycgOiAnYWNjJztcblxuICAgIGNvbnN0IGhlYWQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBoZWFkLmNsYXNzTmFtZSA9ICdhY2MtaGVhZCc7XG4gICAgY29uc3QgaGFuZGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGhhbmRsZS5jbGFzc05hbWUgPSAnYWNjLWhhbmRsZSc7XG4gICAgaGFuZGxlLmlubmVySFRNTCA9IGA8c3BhbiBjbGFzcz1cImF0XCI+QDwvc3Bhbj4ke2VzY2FwZUh0bWwoYS5oYW5kbGUpfWA7XG4gICAgY29uc3QgbWV0YSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBtZXRhLmNsYXNzTmFtZSA9ICdhY2MtbWV0YSc7XG4gICAgbWV0YS50ZXh0Q29udGVudCA9IGEubGFiZWw7XG4gICAgaGVhZC5hcHBlbmQoaGFuZGxlLCBtZXRhKTtcblxuICAgIGNvbnN0IHJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHJvdy5jbGFzc05hbWUgPSAnYWNjLXJvdyc7XG4gICAgY29uc3Qgc3RhdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgc3RhdHMuY2xhc3NOYW1lID0gJ2FjYy1zdGF0cyc7XG4gICAgY29uc3QgdG9kYXkgPSBjPy50b2RheUNvdW50ID8/IDA7XG4gICAgY29uc3QgYnVmZmVyZWQgPSBjPy5idWZmZXJlZENvdW50ID8/IDA7XG4gICAgY29uc3QgbGFzdCA9IGM/Lmxhc3RDYXB0dXJlQXQgPz8gbnVsbDtcbiAgICBzdGF0cy5pbm5lckhUTUwgPVxuICAgICAgYDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0odG9kYXkpfTwvc3Bhbj4gdG9kYXlgICtcbiAgICAgIChidWZmZXJlZCA+IDAgPyBgIFx1MDBCNyA8c3BhbiBjbGFzcz1cIm51bVwiPiR7Zm10TnVtKGJ1ZmZlcmVkKX08L3NwYW4+IGJ1ZmZlcmVkYCA6ICcnKSArXG4gICAgICBgIFx1MDBCNyBsYXN0ICR7ZXNjYXBlSHRtbChmbXRSZWwobGFzdCkpfWA7XG5cbiAgICBjb25zdCBhY3Rpb25zID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGFjdGlvbnMuY2xhc3NOYW1lID0gJ2FjYy1hY3Rpb24nO1xuICAgIGNvbnN0IGJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGJ0bi5jbGFzc05hbWUgPSAnYnRuJztcbiAgICBidG4udGV4dENvbnRlbnQgPSAnQ2FwdHVyZSBub3cnO1xuICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtbm93JywgaGFuZGxlOiBhLmhhbmRsZSB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGFjdGlvbnMuYXBwZW5kKGJ0bik7XG5cbiAgICByb3cuYXBwZW5kKHN0YXRzLCBhY3Rpb25zKTtcbiAgICBsaS5hcHBlbmQoaGVhZCwgcm93KTtcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFjdGl2aXR5KGV2ZW50czogTG9nRXZlbnRbXSk6IHZvaWQge1xuICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChldmVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWN0aXZpdHkgeWV0Lic7XG4gICAgYWN0aXZpdHlMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3QgZXYgb2YgZXZlbnRzLnNsaWNlKDAsIEFDVElWSVRZX1RBSUxfTUFYKSkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xuICAgIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XG4gICAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcbiAgICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xuICAgIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xuICAgIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xuICAgIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcbiAgICBib2R5LmFwcGVuZChtc2cpO1xuICAgIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcbiAgICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcbiAgICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgICBib2R5LmFwcGVuZChjdHgpO1xuICAgIH1cbiAgICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xuICAgIGFjdGl2aXR5TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHN0cmluZ2lmeVNob3J0KHY6IHVua25vd24pOiBzdHJpbmcge1xuICBpZiAodiA9PT0gbnVsbCkgcmV0dXJuICdudWxsJztcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJykgcmV0dXJuIHYubGVuZ3RoID4gODAgPyBgJHt2LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdjtcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gU3RyaW5nKHYpO1xuICB0cnkge1xuICAgIGNvbnN0IHMgPSBKU09OLnN0cmluZ2lmeSh2KTtcbiAgICByZXR1cm4gcy5sZW5ndGggPiA4MCA/IGAke3Muc2xpY2UoMCwgODApfVx1MjAyNmAgOiBzO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gJz8nO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoczogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHMucmVwbGFjZSgvWyY8PlwiJ10vZywgKGMpID0+XG4gICAgYyA9PT0gJyYnID8gJyZhbXA7JyA6IGMgPT09ICc8JyA/ICcmbHQ7JyA6IGMgPT09ICc+JyA/ICcmZ3Q7JyA6IGMgPT09ICdcIicgPyAnJnF1b3Q7JyA6ICcmIzM5OydcbiAgKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaFN0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGxhc3RTdGF0ZSA9IGF3YWl0IHNlbmQ8RXh0ZW5zaW9uU3RhdGU+KHsgdHlwZTogJ2dldC1zdGF0ZScgfSk7XG4gICAgcGFpbnQobGFzdFN0YXRlKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNpZGViYXIgcmVmcmVzaFN0YXRlIGZhaWxlZCcsIGVycik7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGFpbnQoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGV4dFZlcnNpb25FbC50ZXh0Q29udGVudCA9IHN0YXRlLnZlcnNpb247XG4gIHNldENvbm5TdGF0dXMoc3RhdGUpO1xuICBhdXRvVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvQ2FwdHVyZTtcbiAgdmlld2VyTGluay5ocmVmID0gYGh0dHBzOi8vJHtzdGF0ZS5zZXR0aW5ncy5vd25lcn0uZ2l0aHViLmlvLyR7c3RhdGUuc2V0dGluZ3MucmVwb30vYDtcbiAgcmVuZGVyQWNjb3VudHMoc3RhdGUpO1xuICBwYWludEF1dG9TY3JvbGwoc3RhdGUpO1xuICBwYWludFJlZmV0Y2goc3RhdGUpO1xufVxuXG5mdW5jdGlvbiBwYWludEF1dG9TY3JvbGwoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGF1dG9TY3JvbGxUb2dnbGUuY2hlY2tlZCA9IHN0YXRlLnNldHRpbmdzLmF1dG9TY3JvbGw7XG4gIGNvbnN0IHNlY3MgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWM7XG4gIGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZSA9IFN0cmluZyhzZWNzKTtcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IFN0cmluZyhzZWNzKTtcbiAgaWYgKHN0YXRlLnNldHRpbmdzLmF1dG9TY3JvbGwpIHtcbiAgICBjb25zdCBuID0gc3RhdGUuYXV0b1Njcm9sbC50YWJDb3VudDtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLnRleHRDb250ZW50ID1cbiAgICAgIG4gPT09IDAgPyAnb24gXHUyMDE0IG5vIFggdGFicyBvcGVuJyA6IGBvbiBcdTIwMTQgc2Nyb2xsaW5nICR7bn0gJHtuID09PSAxID8gJ3RhYicgOiAndGFicyd9YDtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLmNsYXNzTmFtZSA9ICdyYXRlLWluZm8gb24nO1xuICB9IGVsc2Uge1xuICAgIGF1dG9TY3JvbGxTdGF0dXMudGV4dENvbnRlbnQgPSAnb2ZmJztcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLmNsYXNzTmFtZSA9ICdyYXRlLWluZm8nO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBhaW50UmVmZXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3QgdG90YWwgPSBzdGF0ZS5yZWZldGNoUXVldWUudG90YWw7XG4gIGNvbnN0IHJ1bm5pbmcgPSBzdGF0ZS5yZWZldGNoUXVldWUucnVubmluZztcbiAgcmVmZXRjaFNlY3Rpb24uaGlkZGVuID0gdG90YWwgPT09IDAgJiYgIXJ1bm5pbmc7XG4gIHJlZmV0Y2hDb3VudC50ZXh0Q29udGVudCA9XG4gICAgdG90YWwgPT09IDBcbiAgICAgID8gcnVubmluZ1xuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXG4gICAgICAgIDogJzAgcXVldWVkJ1xuICAgICAgOiBgJHtmbXROdW0odG90YWwpfSBxdWV1ZWQke3J1bm5pbmcgPyAnIFx1MDBCNyBydW5uaW5nJyA6ICcnfWA7XG4gIHJlZmV0Y2hTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xuICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcbiAgcmVmZXRjaENhbmNlbEJ0bi5oaWRkZW4gPSAhcnVubmluZztcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBQdWxsIHN0cmFpZ2h0IGZyb20gc3RvcmFnZSBvbiBmaXJzdCByZW5kZXI7IGxpdmUgdXBkYXRlcyBjb21lIHZpYVxuICAvLyBgbG9nLWV2ZW50YCBicm9hZGNhc3RzLlxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KCdhY3Rpdml0eScpO1xuICBjb25zdCBldmVudHMgPSAoc3RvcmVkLmFjdGl2aXR5IGFzIExvZ0V2ZW50W10gfCB1bmRlZmluZWQpID8/IFtdO1xuICByZW5kZXJBY3Rpdml0eShldmVudHMpO1xufVxuXG4vLyAtLS0gV2lyZSB1cCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5jYXB0dXJlQWxsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtYWxsJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5jYXB0dXJlVGhpc0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS10aGlzLXBhZ2UnIH0pO1xuICB9IGZpbmFsbHkge1xuICAgIGNhcHR1cmVUaGlzQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5mbHVzaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgZmx1c2hCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnZmx1c2gtYWxsJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBmbHVzaEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuYXV0b1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtYXV0by1jYXB0dXJlJywgb246IGF1dG9Ub2dnbGUuY2hlY2tlZCB9KTtcbn0pO1xuXG5hdXRvU2Nyb2xsVG9nZ2xlLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1hdXRvLXNjcm9sbCcsIG9uOiBhdXRvU2Nyb2xsVG9nZ2xlLmNoZWNrZWQgfSk7XG59KTtcblxuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JywgKCkgPT4ge1xuICBhdXRvU2Nyb2xsU2Vjc0VsLnRleHRDb250ZW50ID0gYXV0b1Njcm9sbEludGVydmFsLnZhbHVlO1xufSk7XG5hdXRvU2Nyb2xsSW50ZXJ2YWwuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICBjb25zdCBzZWNvbmRzID0gTnVtYmVyKGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZSk7XG4gIGlmIChOdW1iZXIuaXNGaW5pdGUoc2Vjb25kcykpIHtcbiAgICB2b2lkIHNlbmQoeyB0eXBlOiAnc2V0LWF1dG8tc2Nyb2xsLWludGVydmFsJywgc2Vjb25kcyB9KTtcbiAgfVxufSk7XG5cbnJlZmV0Y2hTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5yZWZldGNoQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1yZWZldGNoJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbm9wdGlvbnNMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ29wZW4tb3B0aW9ucycgfSk7XG59KTtcblxudmlld2VyTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdvcGVuLXZpZXdlcicgfSk7XG59KTtcblxuY2xlYXJBY3RCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2xlYXItYWN0aXZpdHknIH0pO1xuICByZW5kZXJBY3Rpdml0eShbXSk7XG59KTtcblxuYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiB1bmtub3duKSA9PiB7XG4gIGlmICghbXNnIHx8IHR5cGVvZiBtc2cgIT09ICdvYmplY3QnKSByZXR1cm47XG4gIGNvbnN0IG0gPSBtc2cgYXMgeyB0eXBlPzogc3RyaW5nOyBzdGF0ZT86IEV4dGVuc2lvblN0YXRlOyBldmVudD86IExvZ0V2ZW50IH07XG4gIGlmIChtLnR5cGUgPT09ICdzdGF0ZS1jaGFuZ2VkJyAmJiBtLnN0YXRlKSB7XG4gICAgbGFzdFN0YXRlID0gbS5zdGF0ZTtcbiAgICBwYWludChtLnN0YXRlKTtcbiAgfSBlbHNlIGlmIChtLnR5cGUgPT09ICdsb2ctZXZlbnQnICYmIG0uZXZlbnQpIHtcbiAgICBwcmVwZW5kRXZlbnQobS5ldmVudCk7XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBwcmVwZW5kRXZlbnQoZXY6IExvZ0V2ZW50KTogdm9pZCB7XG4gIC8vIElmIHRoZSBsaXN0IGlzIHNob3dpbmcgdGhlIFwiZW1wdHlcIiBwbGFjZWhvbGRlciwgY2xlYXIgaXQuXG4gIGlmIChhY3Rpdml0eUxpc3QuZmlyc3RFbGVtZW50Q2hpbGQ/LmNsYXNzTGlzdC5jb250YWlucygnZW1wdHknKSkge1xuICAgIGFjdGl2aXR5TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgfVxuICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gIGxpLmNsYXNzTmFtZSA9IGBldiAke2V2LmxldmVsfWA7XG4gIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICB0cy5jbGFzc05hbWUgPSAnZXYtdHMnO1xuICB0cy50ZXh0Q29udGVudCA9IG5ldyBEYXRlKGV2LnRzKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLVVTJywgeyBob3VyMTI6IGZhbHNlIH0pO1xuICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBpY29uLmNsYXNzTmFtZSA9ICdldi1pY29uJztcbiAgaWNvbi50ZXh0Q29udGVudCA9IGV2LmxldmVsID09PSAnZXJyb3InID8gJ1x1MjcxNycgOiBldi5sZXZlbCA9PT0gJ3dhcm4nID8gJyEnIDogJ1x1MDBCNyc7XG4gIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIGNvbnN0IG1zZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBtc2cuY2xhc3NOYW1lID0gJ2V2LW1zZyc7XG4gIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcbiAgYm9keS5hcHBlbmQobXNnKTtcbiAgY29uc3QgY3R4S2V5cyA9IE9iamVjdC5rZXlzKGV2LmNvbnRleHQpO1xuICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgY3R4ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgY3R4LmNsYXNzTmFtZSA9ICdldi1jdHgnO1xuICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgYm9keS5hcHBlbmQoY3R4KTtcbiAgfVxuICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xuICBhY3Rpdml0eUxpc3QucHJlcGVuZChsaSk7XG4gIHdoaWxlIChhY3Rpdml0eUxpc3QuY2hpbGRFbGVtZW50Q291bnQgPiBBQ1RJVklUWV9UQUlMX01BWCkge1xuICAgIGFjdGl2aXR5TGlzdC5sYXN0RWxlbWVudENoaWxkPy5yZW1vdmUoKTtcbiAgfVxufVxuXG4vLyBJbml0aWFsIHBhaW50Llxudm9pZCByZWZyZXNoU3RhdGUoKTtcbnZvaWQgcmVmcmVzaEFjdGl2aXR5KCk7XG5cbi8vIFBlcmlvZGljYWxseSByZS1mZXRjaCBzdGF0ZSBzbyBcImxhc3QgY2FwdHVyZVwiIHRpbWVzIHN0YXkgZnJlc2guXG5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gIHZvaWQgcmVmcmVzaFN0YXRlKCk7XG59LCAxNV8wMDApO1xuIl0sCiAgIm1hcHBpbmdzIjogIjtBQXdGTyxJQUFNLG9CQUFvQjtBQUcxQixJQUFNLGdDQUFnQyxLQUFLLEtBQUs7OztBQ2hGdkQsSUFBTSxJQUFJLENBQXNDLE9BQWtCO0FBQ2hFLFFBQU0sS0FBSyxTQUFTLGVBQWUsRUFBRTtBQUNyQyxNQUFJLENBQUMsR0FBSSxPQUFNLElBQUksTUFBTSxvQkFBb0IsRUFBRSxFQUFFO0FBQ2pELFNBQU87QUFDVDtBQUVBLElBQU0sVUFBVSxFQUFFLFVBQVU7QUFDNUIsSUFBTSxXQUFXLEVBQW1CLFdBQVc7QUFDL0MsSUFBTSxjQUFjLEVBQW9CLGNBQWM7QUFDdEQsSUFBTSxlQUFlLEVBQW9CLGVBQWU7QUFDeEQsSUFBTSxhQUFhLEVBQW9CLGNBQWM7QUFDckQsSUFBTSxnQkFBZ0IsRUFBcUIsYUFBYTtBQUN4RCxJQUFNLGlCQUFpQixFQUFxQixjQUFjO0FBQzFELElBQU0sV0FBVyxFQUFxQixXQUFXO0FBQ2pELElBQU0sY0FBYyxFQUFxQixjQUFjO0FBQ3ZELElBQU0sYUFBYSxFQUFxQixhQUFhO0FBQ3JELElBQU0sY0FBYyxFQUFxQixnQkFBZ0I7QUFDekQsSUFBTSxlQUFlLEVBQW1CLGFBQWE7QUFDckQsSUFBTSxtQkFBbUIsRUFBb0IsYUFBYTtBQUMxRCxJQUFNLHFCQUFxQixFQUFvQixzQkFBc0I7QUFDckUsSUFBTSxtQkFBbUIsRUFBbUIsa0JBQWtCO0FBQzlELElBQU0sbUJBQW1CLEVBQW1CLG9CQUFvQjtBQUNoRSxJQUFNLGlCQUFpQixFQUFlLGlCQUFpQjtBQUN2RCxJQUFNLGVBQWUsRUFBbUIsZUFBZTtBQUN2RCxJQUFNLGtCQUFrQixFQUFxQixlQUFlO0FBQzVELElBQU0sbUJBQW1CLEVBQXFCLGdCQUFnQjtBQUU5RCxJQUFJLFlBQW1DO0FBRXZDLGVBQWUsS0FBUSxLQUFpQztBQUN0RCxTQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDeEM7QUFFQSxTQUFTLGNBQWMsT0FBNkI7QUFDbEQsUUFBTSxFQUFFLFlBQVksU0FBUyxJQUFJO0FBQ2pDLE1BQUksTUFBTTtBQUNWLE1BQUksT0FBTztBQUtYLFFBQU0sZ0JBQ0osV0FBVyxXQUFXLFFBQVEsU0FBUyxVQUFVLFdBQVcsMkJBQTJCO0FBQ3pGLE1BQUksQ0FBQyxTQUFTLFFBQVE7QUFDcEIsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsZUFBZTtBQUN4QixVQUFNO0FBQ04sV0FBTyxXQUFXLFNBQVMsTUFBTSx1QkFBdUIsU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLDRDQUF1QyxXQUFXLGlCQUFpQixRQUFRO0FBQUEsRUFDcEssV0FBVyxXQUFXLFdBQVcsTUFBTTtBQUNyQyxVQUFNO0FBQ04sV0FBTyxpQkFBaUIsV0FBVyxTQUFTLEdBQUcsT0FBTyxTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksZUFBTyxTQUFTLFNBQVM7QUFBQSxFQUNoSCxXQUFXLFdBQVcsV0FBVyxjQUFjO0FBQzdDLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLFdBQVcsV0FBVyxnQkFBZ0I7QUFDL0MsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsV0FBVyxXQUFXLGlCQUFpQjtBQUNoRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxXQUFXLFdBQVcsa0JBQWtCO0FBQ2pELFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxPQUFPO0FBQ0wsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0EsVUFBUSxZQUFZLE9BQU8sR0FBRztBQUM5QixXQUFTLGNBQWM7QUFDdkIsV0FBUyxRQUFRLFdBQVcsU0FBUztBQUN2QztBQUVBLFNBQVMsT0FBTyxLQUE0QjtBQUMxQyxNQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLFFBQU0sSUFBSSxLQUFLLE1BQU0sR0FBRztBQUN4QixNQUFJLENBQUMsT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ2hDLFFBQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxHQUFJLENBQUM7QUFDNUQsTUFBSSxPQUFPLEVBQUcsUUFBTztBQUNyQixNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNqQyxNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxNQUFJLFFBQVEsR0FBSSxRQUFPLEdBQUcsS0FBSztBQUMvQixRQUFNLE9BQU8sS0FBSyxNQUFNLFFBQVEsRUFBRTtBQUNsQyxTQUFPLEdBQUcsSUFBSTtBQUNoQjtBQUVBLFNBQVMsT0FBTyxHQUFtQjtBQUNqQyxTQUFPLEVBQUUsZUFBZSxPQUFPO0FBQ2pDO0FBRUEsU0FBUyxlQUFlLE9BQTZCO0FBQ25ELGNBQVksZ0JBQWdCO0FBQzVCLE1BQUksTUFBTSxTQUFTLFdBQVcsR0FBRztBQUMvQixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLGdCQUFZLE9BQU8sRUFBRTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLEtBQUssTUFBTSxVQUFVO0FBQzlCLFVBQU0sSUFBSSxNQUFNLFNBQVMsRUFBRSxNQUFNO0FBQ2pDLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksS0FBSyxFQUFFLGdCQUFnQixJQUFJLGdCQUFnQjtBQUUxRCxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBQ2pCLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVk7QUFDbkIsV0FBTyxZQUFZLDRCQUE0QixXQUFXLEVBQUUsTUFBTSxDQUFDO0FBQ25FLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLEVBQUU7QUFDckIsU0FBSyxPQUFPLFFBQVEsSUFBSTtBQUV4QixVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFVBQU0sUUFBUSxTQUFTLGNBQWMsTUFBTTtBQUMzQyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxRQUFRLEdBQUcsY0FBYztBQUMvQixVQUFNLFdBQVcsR0FBRyxpQkFBaUI7QUFDckMsVUFBTSxPQUFPLEdBQUcsaUJBQWlCO0FBQ2pDLFVBQU0sWUFDSixxQkFBcUIsT0FBTyxLQUFLLENBQUMsbUJBQ2pDLFdBQVcsSUFBSSwyQkFBd0IsT0FBTyxRQUFRLENBQUMscUJBQXFCLE1BQzdFLGNBQVcsV0FBVyxPQUFPLElBQUksQ0FBQyxDQUFDO0FBRXJDLFVBQU0sVUFBVSxTQUFTLGNBQWMsTUFBTTtBQUM3QyxZQUFRLFlBQVk7QUFDcEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxRQUFRO0FBQzNDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWM7QUFDbEIsUUFBSSxpQkFBaUIsU0FBUyxZQUFZO0FBQ3hDLFVBQUksV0FBVztBQUNmLFVBQUk7QUFDRixjQUFNLEtBQUssRUFBRSxNQUFNLGVBQWUsUUFBUSxFQUFFLE9BQU8sQ0FBQztBQUFBLE1BQ3RELFVBQUU7QUFDQSxZQUFJLFdBQVc7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUNELFlBQVEsT0FBTyxHQUFHO0FBRWxCLFFBQUksT0FBTyxPQUFPLE9BQU87QUFDekIsT0FBRyxPQUFPLE1BQU0sR0FBRztBQUNuQixnQkFBWSxPQUFPLEVBQUU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyxlQUFlLFFBQTBCO0FBQ2hELGVBQWEsZ0JBQWdCO0FBQzdCLE1BQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixpQkFBYSxPQUFPLEVBQUU7QUFDdEI7QUFBQSxFQUNGO0FBQ0EsYUFBVyxNQUFNLE9BQU8sTUFBTSxHQUFHLGlCQUFpQixHQUFHO0FBQ25ELFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDN0IsVUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQ3hDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUM5RSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxHQUFHLFVBQVUsVUFBVSxXQUFNLEdBQUcsVUFBVSxTQUFTLE1BQU07QUFDNUUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLEdBQUc7QUFDckIsU0FBSyxPQUFPLEdBQUc7QUFDZixVQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTztBQUN0QyxRQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLFlBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxVQUFJLFlBQVk7QUFDaEIsVUFBSSxjQUFjLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssUUFBSztBQUN4RixXQUFLLE9BQU8sR0FBRztBQUFBLElBQ2pCO0FBQ0EsT0FBRyxPQUFPLElBQUksTUFBTSxJQUFJO0FBQ3hCLGlCQUFhLE9BQU8sRUFBRTtBQUFBLEVBQ3hCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBb0I7QUFDMUMsTUFBSSxNQUFNLEtBQU0sUUFBTztBQUN2QixNQUFJLE9BQU8sTUFBTSxTQUFVLFFBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUN6RSxNQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxVQUFXLFFBQU8sT0FBTyxDQUFDO0FBQ3BFLE1BQUk7QUFDRixVQUFNLElBQUksS0FBSyxVQUFVLENBQUM7QUFDMUIsV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsR0FBbUI7QUFDckMsU0FBTyxFQUFFO0FBQUEsSUFBUTtBQUFBLElBQVksQ0FBQyxNQUM1QixNQUFNLE1BQU0sVUFBVSxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sV0FBVztBQUFBLEVBQ3pGO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLE1BQUk7QUFDRixnQkFBWSxNQUFNLEtBQXFCLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFDNUQsVUFBTSxTQUFTO0FBQUEsRUFDakIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDZDQUE2QyxHQUFHO0FBQUEsRUFDL0Q7QUFDRjtBQUVBLFNBQVMsTUFBTSxPQUE2QjtBQUMxQyxlQUFhLGNBQWMsTUFBTTtBQUNqQyxnQkFBYyxLQUFLO0FBQ25CLGFBQVcsVUFBVSxNQUFNLFNBQVM7QUFDcEMsYUFBVyxPQUFPLFdBQVcsTUFBTSxTQUFTLEtBQUssY0FBYyxNQUFNLFNBQVMsSUFBSTtBQUNsRixpQkFBZSxLQUFLO0FBQ3BCLGtCQUFnQixLQUFLO0FBQ3JCLGVBQWEsS0FBSztBQUNwQjtBQUVBLFNBQVMsZ0JBQWdCLE9BQTZCO0FBQ3BELG1CQUFpQixVQUFVLE1BQU0sU0FBUztBQUMxQyxRQUFNLE9BQU8sTUFBTSxTQUFTO0FBQzVCLHFCQUFtQixRQUFRLE9BQU8sSUFBSTtBQUN0QyxtQkFBaUIsY0FBYyxPQUFPLElBQUk7QUFDMUMsTUFBSSxNQUFNLFNBQVMsWUFBWTtBQUM3QixVQUFNLElBQUksTUFBTSxXQUFXO0FBQzNCLHFCQUFpQixjQUNmLE1BQU0sSUFBSSw2QkFBd0IsdUJBQWtCLENBQUMsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNO0FBQ25GLHFCQUFpQixZQUFZO0FBQUEsRUFDL0IsT0FBTztBQUNMLHFCQUFpQixjQUFjO0FBQy9CLHFCQUFpQixZQUFZO0FBQUEsRUFDL0I7QUFDRjtBQUVBLFNBQVMsYUFBYSxPQUE2QjtBQUNqRCxRQUFNLFFBQVEsTUFBTSxhQUFhO0FBQ2pDLFFBQU0sVUFBVSxNQUFNLGFBQWE7QUFDbkMsaUJBQWUsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUN4QyxlQUFhLGNBQ1gsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELGtCQUFnQixTQUFTO0FBQ3pCLGtCQUFnQixXQUFXLFVBQVU7QUFDckMsbUJBQWlCLFNBQVMsQ0FBQztBQUM3QjtBQUVBLGVBQWUsa0JBQWlDO0FBRzlDLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVTtBQUN6RCxRQUFNLFNBQVUsT0FBTyxZQUF1QyxDQUFDO0FBQy9ELGlCQUFlLE1BQU07QUFDdkI7QUFJQSxjQUFjLGlCQUFpQixTQUFTLFlBQVk7QUFDbEQsZ0JBQWMsV0FBVztBQUN6QixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFBQSxFQUNwQyxVQUFFO0FBQ0Esa0JBQWMsV0FBVztBQUFBLEVBQzNCO0FBQ0YsQ0FBQztBQUVELGVBQWUsaUJBQWlCLFNBQVMsWUFBWTtBQUNuRCxpQkFBZSxXQUFXO0FBQzFCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQUEsRUFDMUMsVUFBRTtBQUNBLG1CQUFlLFdBQVc7QUFBQSxFQUM1QjtBQUNGLENBQUM7QUFFRCxTQUFTLGlCQUFpQixTQUFTLFlBQVk7QUFDN0MsV0FBUyxXQUFXO0FBQ3BCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLFlBQVksQ0FBQztBQUFBLEVBQ2xDLFVBQUU7QUFDQSxhQUFTLFdBQVc7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxXQUFXLGlCQUFpQixVQUFVLE1BQU07QUFDMUMsT0FBSyxLQUFLLEVBQUUsTUFBTSx1QkFBdUIsSUFBSSxXQUFXLFFBQVEsQ0FBQztBQUNuRSxDQUFDO0FBRUQsaUJBQWlCLGlCQUFpQixVQUFVLE1BQU07QUFDaEQsT0FBSyxLQUFLLEVBQUUsTUFBTSxzQkFBc0IsSUFBSSxpQkFBaUIsUUFBUSxDQUFDO0FBQ3hFLENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxtQkFBaUIsY0FBYyxtQkFBbUI7QUFDcEQsQ0FBQztBQUNELG1CQUFtQixpQkFBaUIsVUFBVSxNQUFNO0FBQ2xELFFBQU0sVUFBVSxPQUFPLG1CQUFtQixLQUFLO0FBQy9DLE1BQUksT0FBTyxTQUFTLE9BQU8sR0FBRztBQUM1QixTQUFLLEtBQUssRUFBRSxNQUFNLDRCQUE0QixRQUFRLENBQUM7QUFBQSxFQUN6RDtBQUNGLENBQUM7QUFFRCxnQkFBZ0IsaUJBQWlCLFNBQVMsTUFBTTtBQUM5QyxrQkFBZ0IsV0FBVztBQUMzQixPQUFLLEtBQUssRUFBRSxNQUFNLGdCQUFnQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ2pELG9CQUFnQixXQUFXO0FBQUEsRUFDN0IsQ0FBQztBQUNILENBQUM7QUFFRCxpQkFBaUIsaUJBQWlCLFNBQVMsTUFBTTtBQUMvQyxtQkFBaUIsV0FBVztBQUM1QixPQUFLLEtBQUssRUFBRSxNQUFNLGlCQUFpQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ2xELHFCQUFpQixXQUFXO0FBQUEsRUFDOUIsQ0FBQztBQUNILENBQUM7QUFFRCxZQUFZLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNsRCxJQUFFLGVBQWU7QUFDakIsT0FBSyxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDcEMsQ0FBQztBQUVELFdBQVcsaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2pELElBQUUsZUFBZTtBQUNqQixPQUFLLEtBQUssRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUNuQyxDQUFDO0FBRUQsWUFBWSxpQkFBaUIsU0FBUyxZQUFZO0FBQ2hELFFBQU0sS0FBSyxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDckMsaUJBQWUsQ0FBQyxDQUFDO0FBQ25CLENBQUM7QUFFRCxRQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsUUFBaUI7QUFDdEQsTUFBSSxDQUFDLE9BQU8sT0FBTyxRQUFRLFNBQVU7QUFDckMsUUFBTSxJQUFJO0FBQ1YsTUFBSSxFQUFFLFNBQVMsbUJBQW1CLEVBQUUsT0FBTztBQUN6QyxnQkFBWSxFQUFFO0FBQ2QsVUFBTSxFQUFFLEtBQUs7QUFBQSxFQUNmLFdBQVcsRUFBRSxTQUFTLGVBQWUsRUFBRSxPQUFPO0FBQzVDLGlCQUFhLEVBQUUsS0FBSztBQUFBLEVBQ3RCO0FBQ0YsQ0FBQztBQUVELFNBQVMsYUFBYSxJQUFvQjtBQUV4QyxNQUFJLGFBQWEsbUJBQW1CLFVBQVUsU0FBUyxPQUFPLEdBQUc7QUFDL0QsaUJBQWEsZ0JBQWdCO0FBQUEsRUFDL0I7QUFDQSxRQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsS0FBRyxZQUFZLE1BQU0sR0FBRyxLQUFLO0FBQzdCLFFBQU0sS0FBSyxTQUFTLGNBQWMsTUFBTTtBQUN4QyxLQUFHLFlBQVk7QUFDZixLQUFHLGNBQWMsSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxNQUFNLENBQUM7QUFDOUUsUUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLE9BQUssWUFBWTtBQUNqQixPQUFLLGNBQWMsR0FBRyxVQUFVLFVBQVUsV0FBTSxHQUFHLFVBQVUsU0FBUyxNQUFNO0FBQzVFLFFBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxRQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsTUFBSSxZQUFZO0FBQ2hCLE1BQUksY0FBYyxHQUFHO0FBQ3JCLE9BQUssT0FBTyxHQUFHO0FBQ2YsUUFBTSxVQUFVLE9BQU8sS0FBSyxHQUFHLE9BQU87QUFDdEMsTUFBSSxRQUFRLFNBQVMsR0FBRztBQUN0QixVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYyxRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLGVBQWUsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLFFBQUs7QUFDeEYsU0FBSyxPQUFPLEdBQUc7QUFBQSxFQUNqQjtBQUNBLEtBQUcsT0FBTyxJQUFJLE1BQU0sSUFBSTtBQUN4QixlQUFhLFFBQVEsRUFBRTtBQUN2QixTQUFPLGFBQWEsb0JBQW9CLG1CQUFtQjtBQUN6RCxpQkFBYSxrQkFBa0IsT0FBTztBQUFBLEVBQ3hDO0FBQ0Y7QUFHQSxLQUFLLGFBQWE7QUFDbEIsS0FBSyxnQkFBZ0I7QUFHckIsWUFBWSxNQUFNO0FBQ2hCLE9BQUssYUFBYTtBQUNwQixHQUFHLElBQU07IiwKICAibmFtZXMiOiBbXQp9Cg==
