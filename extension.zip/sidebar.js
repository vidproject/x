// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var updateExistingToggle = $("update-existing");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = isWriteAuthError(connection.error) ? "PAT can read repo but cannot write - set Contents: Read & Write" : "Auth error - check your PAT";
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  updateExistingToggle.checked = state.settings.updateExisting !== false;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    const parts = [
      `${fmtNum(as.scrollCount)} scrolls`,
      `${fmtNum(as.ingestedNewCount)} new buffered`,
      `${fmtNum(as.ingestedExistingCount)} old buffered`
    ];
    if (as.skippedOldCount > 0) parts.push(`${fmtNum(as.skippedOldCount)} old skipped`);
    parts.push(`${fmtNum(as.expandedCount)} expanded`);
    autoScrollProgress.textContent = parts.join(" \xB7 ");
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
updateExistingToggle.addEventListener("change", () => {
  void send({ type: "toggle-update-existing", on: updateExistingToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgZW5hYmxlZDogdHJ1ZSxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxuICB1cGRhdGVFeGlzdGluZzogdHJ1ZSxcbn07XG5cbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XG5cbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1JhcGlkUmVzcG9uc2U0NycsIGxhYmVsOiAnUmFwaWQgUmVzcG9uc2UgNDcnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG5dO1xuXG4vLyBHcmFwaFFMIGVuZHBvaW50IG5hbWVzIHdlIGNhcmUgYWJvdXQgKG1hdGNoZWQgYnkgc3Vic3RyaW5nIGFnYWluc3QgVVJMIHBhdGgpLlxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG4gICdMaWtlcycsXG4gICdCb29rbWFya3MnLFxuICAnSG9tZVRpbWVsaW5lJyxcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXG4gICdTZWFyY2hUaW1lbGluZScsXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxuXSk7XG5cbi8vIEVuZHBvaW50cyB0aGF0IGNhcnJ5IENvbW11bml0eSBOb3RlIGJvZGllcyBcdTIwMTQgY2FwdHVyZWQgZm9yIGNvbXBsZXRlbmVzcyBidXRcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXG5leHBvcnQgY29uc3QgQklSRFdBVENIX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnQmlyZHdhdGNoRmV0Y2hPbmVOb3RlJyxcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxuXSk7XG5cbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxuLy8gdG8gbGVhcm4gYWNjb3VudF9pZCA8LT4gaGFuZGxlIGJpbmRpbmdzKS5cbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcblxuLy8gRW5kcG9pbnRzIHdob3NlIHJlc3BvbnNlcyBhcmUgc2NvcGVkIHRvIGEgcGFydGljdWxhciBhY2NvdW50IG9yXG4vLyBjb252ZXJzYXRpb24gXHUyMDE0IGkuZS4gdmlzaXRpbmcgYC88aGFuZGxlPmAgLyBgLzxoYW5kbGU+L3dpdGhfcmVwbGllc2AsXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcbi8vIGVpdGhlciBhdXRob3JlZCBieSB0aGUgdHJhY2tlZCBhY2NvdW50IG9yIGRpcmVjdGx5IHJlZmVyZW5jZWQgYnkgdGhlbVxuLy8gKHJldHdlZXRlZCwgcXVvdGVkLCByZXBsaWVkIHRvKSwgc28gd2Uga2VlcCBldmVyeXRoaW5nIHdlIHNlZSByYXRoZXJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcbi8vIGFjY291bnQgc3RpbGwgZ2V0cyBpdHMgb3JpZ2luYWwtdHdlZXQgY29udGVudCBhcmNoaXZlZC5cbi8vXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcbi8vIHN0aWxsIGdldCBmaWx0ZXJlZCB0byB0cmFja2VkLWhhbmRsZSBhdXRob3JzIFx1MjAxNCBzZWUgdGhlIHNwZWMnc1xuLy8gXCJCcm93c2luZyBteSBob21lIHRpbWVsaW5lIGlzIGlnbm9yZWRcIiBydWxlLlxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuXSk7XG5cbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxuZXhwb3J0IGNvbnN0IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCA9IDIwMDtcblxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxuZXhwb3J0IGNvbnN0IEZMVVNIX0lETEVfTVMgPSA0NV8wMDA7XG5cbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxuZXhwb3J0IGNvbnN0IEZMVVNIX0FMQVJNX01JTlVURVMgPSAxO1xuXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXG5leHBvcnQgY29uc3QgQUNUSVZJVFlfVEFJTF9NQVggPSAyNTA7XG5cbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cbmV4cG9ydCBjb25zdCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyA9IDEwICogNjAgKiAxMDAwO1xuXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcbiIsICIvKipcbiAqIHNpZGViYXIudHMgXHUyMDE0IFVJIGZvciB0aGUgcGVyc2lzdGVudCBzaWRlYmFyLlxuICpcbiAqIFNpZGViYXJzIGluIEZpcmVmb3ggc3RheSBvcGVuIGFjcm9zcyB0YWIvd2luZG93IHN3aXRjaGVzLCB3aGljaCBpcyB0aGVcbiAqIGludGVuZGVkIHBlcnNpc3RlbmNlIG1vZGVsLiBUaGlzIG1vZHVsZSByZW5kZXJzIHN0YXRlIHB1c2hlZCBmcm9tIHRoZVxuICogYmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciBhbmQgZm9yd2FyZHMgdXNlciBjb21tYW5kcyBiYWNrLlxuICovXG5cbmltcG9ydCB7IEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcbmltcG9ydCB0eXBlIHsgRXh0ZW5zaW9uU3RhdGUsIExvZ0V2ZW50LCBSdW50aW1lTWVzc2FnZSB9IGZyb20gJy4vbGliL3R5cGVzLmpzJztcblxuY29uc3QgJCA9IDxUIGV4dGVuZHMgSFRNTEVsZW1lbnQgPSBIVE1MRWxlbWVudD4oaWQ6IHN0cmluZyk6IFQgPT4ge1xuICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcbiAgaWYgKCFlbCkgdGhyb3cgbmV3IEVycm9yKGBtaXNzaW5nIGVsZW1lbnQgIyR7aWR9YCk7XG4gIHJldHVybiBlbCBhcyBUO1xufTtcblxuY29uc3QgY29ubkRvdCA9ICQoJ2Nvbm4tZG90Jyk7XG5jb25zdCBjb25uVGV4dCA9ICQ8SFRNTFNwYW5FbGVtZW50PignY29ubi10ZXh0Jyk7XG5jb25zdCBhY2NvdW50TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjY291bnQtbGlzdCcpO1xuY29uc3QgYWN0aXZpdHlMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWN0aXZpdHktbGlzdCcpO1xuY29uc3QgYXV0b1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tY2FwdHVyZScpO1xuY29uc3QgdXBkYXRlRXhpc3RpbmdUb2dnbGUgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCd1cGRhdGUtZXhpc3RpbmcnKTtcbmNvbnN0IGNhcHR1cmVBbGxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2FwdHVyZS1hbGwnKTtcbmNvbnN0IGNhcHR1cmVUaGlzQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtdGhpcycpO1xuY29uc3QgZmx1c2hCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignZmx1c2gtYWxsJyk7XG5jb25zdCBvcHRpb25zTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdvcGVuLW9wdGlvbnMnKTtcbmNvbnN0IHZpZXdlckxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi12aWV3ZXInKTtcbmNvbnN0IGNsZWFyQWN0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NsZWFyLWFjdGl2aXR5Jyk7XG5jb25zdCBleHRWZXJzaW9uRWwgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2V4dC12ZXJzaW9uJyk7XG5jb25zdCBtYXN0ZXJTd2l0Y2ggPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdtYXN0ZXItc3dpdGNoJyk7XG5jb25zdCBtYXN0ZXJMYWJlbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWFzdGVyLWxhYmVsJyk7XG5jb25zdCBhdXRvU2Nyb2xsSW50ZXJ2YWwgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1pbnRlcnZhbCcpO1xuY29uc3QgYXV0b1Njcm9sbFNlY3NFbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc2VjcycpO1xuY29uc3QgYXV0b1Njcm9sbFN0YXR1cyA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc3RhdHVzJyk7XG5jb25zdCBhdXRvU2Nyb2xsU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtc3RhcnQnKTtcbmNvbnN0IGF1dG9TY3JvbGxDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtY2FuY2VsJyk7XG5jb25zdCBhdXRvU2Nyb2xsUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXByb2dyZXNzJyk7XG5jb25zdCByZWZldGNoU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCdyZWZldGNoLXNlY3Rpb24nKTtcbmNvbnN0IHJlZmV0Y2hDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1jb3VudCcpO1xuY29uc3QgcmVmZXRjaFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZmV0Y2gtc3RhcnQnKTtcbmNvbnN0IHJlZmV0Y2hDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1jYW5jZWwnKTtcbmNvbnN0IHJlZmV0Y2hQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1wcm9ncmVzcycpO1xuY29uc3QgbWVkaWFDcmF3bFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PignbWVkaWEtY3Jhd2wtc2VjdGlvbicpO1xuY29uc3QgbWVkaWFDcmF3bENvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1jb3VudCcpO1xuY29uc3QgbWVkaWFDcmF3bFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLXN0YXJ0Jyk7XG5jb25zdCBtZWRpYUNyYXdsQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLWNhbmNlbCcpO1xuY29uc3QgbWVkaWFDcmF3bFByb2dyZXNzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1wcm9ncmVzcycpO1xuY29uc3QgcHVyZ2VMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ3B1cmdlLXVucmVsYXRlZCcpO1xuXG5sZXQgbGFzdFN0YXRlOiBFeHRlbnNpb25TdGF0ZSB8IG51bGwgPSBudWxsO1xuXG5hc3luYyBmdW5jdGlvbiBzZW5kPFQ+KG1zZzogUnVudGltZU1lc3NhZ2UpOiBQcm9taXNlPFQ+IHtcbiAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZShtc2cpIGFzIFByb21pc2U8VD47XG59XG5cbmZ1bmN0aW9uIHNldENvbm5TdGF0dXMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHsgY29ubmVjdGlvbiwgc2V0dGluZ3MgfSA9IHN0YXRlO1xuICBsZXQgY2xzID0gJyc7XG4gIGxldCB0ZXh0ID0gJyc7XG4gIC8vIE9ubHkgd2FybiB3aGVuIHRoZSBjb25maWd1cmVkIGJyYW5jaCBnZW51aW5lbHkgZG9lc24ndCBleGlzdCBvbiB0aGVcbiAgLy8gcmVtb3RlLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCB0aGF0IGV4aXN0cyBpcyBmaW5lIFx1MjAxNCBjYXB0dXJpbmcgaW50byBhXG4gIC8vIHdvcmtpbmcgYnJhbmNoIGlzIHJvdXRpbmUgXHUyMDE0IHNvIHRoZSBtZXJlIGAhPT1gIHRvIGRlZmF1bHRfYnJhbmNoIGlzIG5vdFxuICAvLyBhIHByb2JsZW0gYW5kIHNob3VsZG4ndCBzaG91dCBpbiB0aGUgaGVhZGVyLlxuICBjb25zdCBicmFuY2hNaXNzaW5nID1cbiAgICBjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ29rJyAmJiBzZXR0aW5ncy5icmFuY2ggJiYgY29ubmVjdGlvbi5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSBmYWxzZTtcbiAgaWYgKCFzZXR0aW5ncy5wYXRTZXQpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XG4gIH0gZWxzZSBpZiAoYnJhbmNoTWlzc2luZykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSBgQnJhbmNoIFwiJHtzZXR0aW5ncy5icmFuY2h9XCIgZG9lcyBub3QgZXhpc3Qgb24gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTIwMTQgY29tbWl0cyB3aWxsIDQyMi4gU2V0IGJyYW5jaCB0byBcIiR7Y29ubmVjdGlvbi5kZWZhdWx0QnJhbmNoID8/ICdtYXN0ZXInfVwiIGluIFNldHRpbmdzLmA7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycpIHtcbiAgICBjbHMgPSAnb2snO1xuICAgIHRleHQgPSBgQ29ubmVjdGVkIGFzIEAke2Nvbm5lY3Rpb24ubG9naW4gPz8gJz8nfSB0byAke3NldHRpbmdzLm93bmVyfS8ke3NldHRpbmdzLnJlcG99IFx1MDBCNyBcdTIwMjYke3NldHRpbmdzLnBhdFN1ZmZpeH1gO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gaXNXcml0ZUF1dGhFcnJvcihjb25uZWN0aW9uLmVycm9yKVxuICAgICAgPyAnUEFUIGNhbiByZWFkIHJlcG8gYnV0IGNhbm5vdCB3cml0ZSAtIHNldCBDb250ZW50czogUmVhZCAmIFdyaXRlJ1xuICAgICAgOiAnQXV0aCBlcnJvciAtIGNoZWNrIHlvdXIgUEFUJztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgY29uc3QgcmVzZXRzID0gZm10UmF0ZUxpbWl0UmVzZXQoY29ubmVjdGlvbi5yYXRlTGltaXRSZXNldEF0KTtcbiAgICB0ZXh0ID0gcmVzZXRzXG4gICAgICA/IGBHaXRIdWIgcmF0ZS1saW1pdGVkIFx1MjAxNCByZXNldHMgJHtyZXNldHN9YFxuICAgICAgOiAnR2l0SHViIHJhdGUtbGltaXRlZCBcdTIwMTQgY2FwdHVyZXMgd2lsbCByZXRyeSc7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICduZXR3b3JrLWVycm9yJykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSAnTmV0d29yayBlcnJvciBcdTIwMTQgY2hlY2sgY29ubmVjdGl2aXR5JztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ25vdC1jb25maWd1cmVkJykge1xuICAgIGNscyA9ICd3YXJuJztcbiAgICB0ZXh0ID0gJ05vdCBjb25maWd1cmVkIFx1MjAxNCBvcGVuIFNldHRpbmdzJztcbiAgfSBlbHNlIHtcbiAgICBjbHMgPSAnJztcbiAgICB0ZXh0ID0gJ0NoZWNraW5nXHUyMDI2JztcbiAgfVxuICBjb25uRG90LmNsYXNzTmFtZSA9IGBkb3QgJHtjbHN9YDtcbiAgY29ublRleHQudGV4dENvbnRlbnQgPSB0ZXh0O1xuICBjb25uVGV4dC50aXRsZSA9IGNvbm5lY3Rpb24uZXJyb3IgPz8gJyc7XG59XG5cbmZ1bmN0aW9uIGZtdFJlbChpc286IHN0cmluZyB8IG51bGwpOiBzdHJpbmcge1xuICBpZiAoIWlzbykgcmV0dXJuICdcdTIwMTQnO1xuICBjb25zdCBkID0gRGF0ZS5wYXJzZShpc28pO1xuICBpZiAoIU51bWJlci5pc0Zpbml0ZShkKSkgcmV0dXJuICdcdTIwMTQnO1xuICBjb25zdCBzZWNzID0gTWF0aC5tYXgoMCwgTWF0aC5yb3VuZCgoRGF0ZS5ub3coKSAtIGQpIC8gMTAwMCkpO1xuICBpZiAoc2VjcyA8IDUpIHJldHVybiAnanVzdCBub3cnO1xuICBpZiAoc2VjcyA8IDYwKSByZXR1cm4gYCR7c2Vjc31zIGFnb2A7XG4gIGNvbnN0IG1pbnMgPSBNYXRoLnJvdW5kKHNlY3MgLyA2MCk7XG4gIGlmIChtaW5zIDwgNjApIHJldHVybiBgJHttaW5zfW0gYWdvYDtcbiAgY29uc3QgaG91cnMgPSBNYXRoLnJvdW5kKG1pbnMgLyA2MCk7XG4gIGlmIChob3VycyA8IDI0KSByZXR1cm4gYCR7aG91cnN9aCBhZ29gO1xuICBjb25zdCBkYXlzID0gTWF0aC5yb3VuZChob3VycyAvIDI0KTtcbiAgcmV0dXJuIGAke2RheXN9ZCBhZ29gO1xufVxuXG5mdW5jdGlvbiBmbXRSYXRlTGltaXRSZXNldChlcG9jaFNlYzogbnVtYmVyIHwgbnVsbCk6IHN0cmluZyB7XG4gIGlmIChlcG9jaFNlYyA9PT0gbnVsbCkgcmV0dXJuICcnO1xuICBjb25zdCBkZWx0YVNlYyA9IGVwb2NoU2VjIC0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gIGlmIChkZWx0YVNlYyA8PSAwKSByZXR1cm4gJ21vbWVudGFyaWx5JztcbiAgY29uc3Qgd2FsbENsb2NrID0gbmV3IERhdGUoZXBvY2hTZWMgKiAxMDAwKS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHtcbiAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgbWludXRlOiAnMi1kaWdpdCcsXG4gIH0pO1xuICBpZiAoZGVsdGFTZWMgPCA2MCkgcmV0dXJuIGBpbiAke2RlbHRhU2VjfXMgKCR7d2FsbENsb2NrfSlgO1xuICBjb25zdCBtaW5zID0gTWF0aC5yb3VuZChkZWx0YVNlYyAvIDYwKTtcbiAgaWYgKG1pbnMgPCA2MCkgcmV0dXJuIGBpbiAke21pbnN9bSAoJHt3YWxsQ2xvY2t9KWA7XG4gIGNvbnN0IGhvdXJzID0gTWF0aC5yb3VuZChtaW5zIC8gNjApO1xuICByZXR1cm4gYGluICR7aG91cnN9aCAoJHt3YWxsQ2xvY2t9KWA7XG59XG5cbmZ1bmN0aW9uIGZtdE51bShuOiBudW1iZXIpOiBzdHJpbmcge1xuICByZXR1cm4gbi50b0xvY2FsZVN0cmluZygnZW4tVVMnKTtcbn1cblxuZnVuY3Rpb24gaXNXcml0ZUF1dGhFcnJvcihtZXNzYWdlOiBzdHJpbmcgfCBudWxsKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnICYmXG4gICAgL1Jlc291cmNlIG5vdCBhY2Nlc3NpYmxlIGJ5IHBlcnNvbmFsIGFjY2VzcyB0b2tlbnxcXC9naXRcXC9ibG9ic3xcXC9naXRcXC9yZWZzL2kudGVzdChtZXNzYWdlKVxuICApO1xufVxuXG5mdW5jdGlvbiByZW5kZXJBY2NvdW50cyhzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgYWNjb3VudExpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChzdGF0ZS5hY2NvdW50cy5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcbiAgICBsaS50ZXh0Q29udGVudCA9ICdObyBhY2NvdW50cyBjb25maWd1cmVkLic7XG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yIChjb25zdCBhIG9mIHN0YXRlLmFjY291bnRzKSB7XG4gICAgY29uc3QgYyA9IHN0YXRlLmNvdW50ZXJzW2EuaGFuZGxlXTtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gYyAmJiBjLmJ1ZmZlcmVkQ291bnQgPiAwID8gJ2FjYyBwZW5kaW5nJyA6ICdhY2MnO1xuXG4gICAgY29uc3QgaGVhZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGhlYWQuY2xhc3NOYW1lID0gJ2FjYy1oZWFkJztcbiAgICBjb25zdCBoYW5kbGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgaGFuZGxlLmNsYXNzTmFtZSA9ICdhY2MtaGFuZGxlJztcbiAgICBoYW5kbGUuaW5uZXJIVE1MID0gYDxzcGFuIGNsYXNzPVwiYXRcIj5APC9zcGFuPiR7ZXNjYXBlSHRtbChhLmhhbmRsZSl9YDtcbiAgICBjb25zdCBtZXRhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIG1ldGEuY2xhc3NOYW1lID0gJ2FjYy1tZXRhJztcbiAgICBtZXRhLnRleHRDb250ZW50ID0gYS5sYWJlbDtcbiAgICBoZWFkLmFwcGVuZChoYW5kbGUsIG1ldGEpO1xuXG4gICAgY29uc3Qgcm93ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgcm93LmNsYXNzTmFtZSA9ICdhY2Mtcm93JztcbiAgICBjb25zdCBzdGF0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBzdGF0cy5jbGFzc05hbWUgPSAnYWNjLXN0YXRzJztcbiAgICBjb25zdCB0b2RheSA9IGM/LnRvZGF5Q291bnQgPz8gMDtcbiAgICBjb25zdCBidWZmZXJlZCA9IGM/LmJ1ZmZlcmVkQ291bnQgPz8gMDtcbiAgICBjb25zdCBsYXN0ID0gYz8ubGFzdENhcHR1cmVBdCA/PyBudWxsO1xuICAgIHN0YXRzLmlubmVySFRNTCA9XG4gICAgICBgPHNwYW4gY2xhc3M9XCJudW1cIj4ke2ZtdE51bSh0b2RheSl9PC9zcGFuPiB0b2RheWAgK1xuICAgICAgKGJ1ZmZlcmVkID4gMCA/IGAgXHUwMEI3IDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0oYnVmZmVyZWQpfTwvc3Bhbj4gYnVmZmVyZWRgIDogJycpICtcbiAgICAgIGAgXHUwMEI3IGxhc3QgJHtlc2NhcGVIdG1sKGZtdFJlbChsYXN0KSl9YDtcblxuICAgIGNvbnN0IGFjdGlvbnMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgYWN0aW9ucy5jbGFzc05hbWUgPSAnYWNjLWFjdGlvbic7XG4gICAgY29uc3QgYnRuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJyk7XG4gICAgYnRuLmNsYXNzTmFtZSA9ICdidG4nO1xuICAgIGJ0bi50ZXh0Q29udGVudCA9ICdDYXB0dXJlIG5vdyc7XG4gICAgYnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICAgICAgYnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS1ub3cnLCBoYW5kbGU6IGEuaGFuZGxlIH0pO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgYnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG4gICAgYWN0aW9ucy5hcHBlbmQoYnRuKTtcblxuICAgIHJvdy5hcHBlbmQoc3RhdHMsIGFjdGlvbnMpO1xuICAgIGxpLmFwcGVuZChoZWFkLCByb3cpO1xuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyQWN0aXZpdHkoZXZlbnRzOiBMb2dFdmVudFtdKTogdm9pZCB7XG4gIGFjdGl2aXR5TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgaWYgKGV2ZW50cy5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcbiAgICBsaS50ZXh0Q29udGVudCA9ICdObyBhY3Rpdml0eSB5ZXQuJztcbiAgICBhY3Rpdml0eUxpc3QuYXBwZW5kKGxpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yIChjb25zdCBldiBvZiBldmVudHMuc2xpY2UoMCwgQUNUSVZJVFlfVEFJTF9NQVgpKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9IGBldiAke2V2LmxldmVsfWA7XG4gICAgY29uc3QgdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgdHMuY2xhc3NOYW1lID0gJ2V2LXRzJztcbiAgICB0cy50ZXh0Q29udGVudCA9IG5ldyBEYXRlKGV2LnRzKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLVVTJywgeyBob3VyMTI6IGZhbHNlIH0pO1xuICAgIGNvbnN0IGljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgaWNvbi5jbGFzc05hbWUgPSAnZXYtaWNvbic7XG4gICAgaWNvbi50ZXh0Q29udGVudCA9IGV2LmxldmVsID09PSAnZXJyb3InID8gJ1x1MjcxNycgOiBldi5sZXZlbCA9PT0gJ3dhcm4nID8gJyEnIDogJ1x1MDBCNyc7XG4gICAgY29uc3QgYm9keSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBjb25zdCBtc2cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBtc2cuY2xhc3NOYW1lID0gJ2V2LW1zZyc7XG4gICAgbXNnLnRleHRDb250ZW50ID0gZXYubXNnO1xuICAgIGJvZHkuYXBwZW5kKG1zZyk7XG4gICAgY29uc3QgY3R4S2V5cyA9IE9iamVjdC5rZXlzKGV2LmNvbnRleHQpO1xuICAgIGlmIChjdHhLZXlzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IGN0eCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgY3R4LmNsYXNzTmFtZSA9ICdldi1jdHgnO1xuICAgICAgY3R4LnRleHRDb250ZW50ID0gY3R4S2V5cy5tYXAoKGspID0+IGAke2t9PSR7c3RyaW5naWZ5U2hvcnQoZXYuY29udGV4dFtrXSl9YCkuam9pbignIFx1MDBCNyAnKTtcbiAgICAgIGJvZHkuYXBwZW5kKGN0eCk7XG4gICAgfVxuICAgIGxpLmFwcGVuZCh0cywgaWNvbiwgYm9keSk7XG4gICAgYWN0aXZpdHlMaXN0LmFwcGVuZChsaSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc3RyaW5naWZ5U2hvcnQodjogdW5rbm93bik6IHN0cmluZyB7XG4gIGlmICh2ID09PSBudWxsKSByZXR1cm4gJ251bGwnO1xuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnKSByZXR1cm4gdi5sZW5ndGggPiA4MCA/IGAke3Yuc2xpY2UoMCwgODApfVx1MjAyNmAgOiB2O1xuICBpZiAodHlwZW9mIHYgPT09ICdudW1iZXInIHx8IHR5cGVvZiB2ID09PSAnYm9vbGVhbicpIHJldHVybiBTdHJpbmcodik7XG4gIHRyeSB7XG4gICAgY29uc3QgcyA9IEpTT04uc3RyaW5naWZ5KHYpO1xuICAgIHJldHVybiBzLmxlbmd0aCA+IDgwID8gYCR7cy5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHM7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnPyc7XG4gIH1cbn1cblxuZnVuY3Rpb24gZXNjYXBlSHRtbChzOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gcy5yZXBsYWNlKC9bJjw+XCInXS9nLCAoYykgPT5cbiAgICBjID09PSAnJicgPyAnJmFtcDsnIDogYyA9PT0gJzwnID8gJyZsdDsnIDogYyA9PT0gJz4nID8gJyZndDsnIDogYyA9PT0gJ1wiJyA/ICcmcXVvdDsnIDogJyYjMzk7J1xuICApO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoU3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgbGFzdFN0YXRlID0gYXdhaXQgc2VuZDxFeHRlbnNpb25TdGF0ZT4oeyB0eXBlOiAnZ2V0LXN0YXRlJyB9KTtcbiAgICBwYWludChsYXN0U3RhdGUpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gc2lkZWJhciByZWZyZXNoU3RhdGUgZmFpbGVkJywgZXJyKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBwYWludChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgZXh0VmVyc2lvbkVsLnRleHRDb250ZW50ID0gc3RhdGUudmVyc2lvbjtcbiAgc2V0Q29ublN0YXR1cyhzdGF0ZSk7XG4gIGF1dG9Ub2dnbGUuY2hlY2tlZCA9IHN0YXRlLnNldHRpbmdzLmF1dG9DYXB0dXJlO1xuICB1cGRhdGVFeGlzdGluZ1RvZ2dsZS5jaGVja2VkID0gc3RhdGUuc2V0dGluZ3MudXBkYXRlRXhpc3RpbmcgIT09IGZhbHNlO1xuICB2aWV3ZXJMaW5rLmhyZWYgPSBgaHR0cHM6Ly8ke3N0YXRlLnNldHRpbmdzLm93bmVyfS5naXRodWIuaW8vJHtzdGF0ZS5zZXR0aW5ncy5yZXBvfS9gO1xuICBwYWludE1hc3RlclN3aXRjaChzdGF0ZSk7XG4gIHJlbmRlckFjY291bnRzKHN0YXRlKTtcbiAgcGFpbnRBdXRvU2Nyb2xsKHN0YXRlKTtcbiAgcGFpbnRNZWRpYUNyYXdsKHN0YXRlKTtcbiAgcGFpbnRSZWZldGNoKHN0YXRlKTtcbn1cblxuZnVuY3Rpb24gcGFpbnRNZWRpYUNyYXdsKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBxID0gc3RhdGUubWVkaWFDcmF3bFF1ZXVlO1xuICBjb25zdCB0b3RhbCA9IHEudG90YWw7XG4gIGNvbnN0IHJ1bm5pbmcgPSBxLnJ1bm5pbmc7XG4gIG1lZGlhQ3Jhd2xTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xuICBtZWRpYUNyYXdsQ291bnQudGV4dENvbnRlbnQgPVxuICAgIHRvdGFsID09PSAwXG4gICAgICA/IHJ1bm5pbmdcbiAgICAgICAgPyAnZmluaXNoaW5nXHUyMDI2J1xuICAgICAgICA6ICcwIHF1ZXVlZCdcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmRpc2FibGVkID0gdG90YWwgPT09IDA7XG4gIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XG4gIHBhaW50UXVldWVQcm9ncmVzcyhtZWRpYUNyYXdsUHJvZ3Jlc3MsIHEpO1xufVxuXG5mdW5jdGlvbiBwYWludFF1ZXVlUHJvZ3Jlc3MoXG4gIGVsOiBIVE1MU3BhbkVsZW1lbnQsXG4gIHE6IHsgcHJvY2Vzc2VkOiBudW1iZXI7IHRvdGFsX2F0X3N0YXJ0OiBudW1iZXI7IHJ1bm5pbmc6IGJvb2xlYW47IHRvdGFsOiBudW1iZXIgfVxuKTogdm9pZCB7XG4gIGlmICghcS5ydW5uaW5nICYmIHEucHJvY2Vzc2VkID09PSAwKSB7XG4gICAgZWwuaGlkZGVuID0gdHJ1ZTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gRGVub21pbmF0b3I6IG1heCBvZiBpbml0aWFsIHRvdGFsIGFuZCBjdXJyZW50IHByb2Nlc3NlZCtyZW1haW5pbmcgc28gdGhlXG4gIC8vIGJhciBzdGlsbCBtYWtlcyBzZW5zZSBpZiBuZXcgZW50cmllcyB3ZXJlIGVucXVldWVkIG1pZC1ydW4uXG4gIGNvbnN0IGRlbm9tID0gTWF0aC5tYXgocS50b3RhbF9hdF9zdGFydCwgcS5wcm9jZXNzZWQgKyBxLnRvdGFsKTtcbiAgZWwuaGlkZGVuID0gZmFsc2U7XG4gIGVsLnRleHRDb250ZW50ID0gYCR7Zm10TnVtKHEucHJvY2Vzc2VkKX0gLyAke2ZtdE51bShkZW5vbSl9IHByb2Nlc3NlZGA7XG4gIGVsLmNsYXNzTmFtZSA9IHEucnVubmluZyA/ICdwcm9ncmVzcyBvbicgOiAncHJvZ3Jlc3MnO1xufVxuXG5mdW5jdGlvbiBwYWludE1hc3RlclN3aXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3Qgb24gPSBzdGF0ZS5zZXR0aW5ncy5lbmFibGVkICE9PSBmYWxzZTtcbiAgbWFzdGVyU3dpdGNoLmNoZWNrZWQgPSBvbjtcbiAgbWFzdGVyTGFiZWwudGV4dENvbnRlbnQgPSBvbiA/ICdPTicgOiAnUEFVU0VEJztcbiAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKCdwYXVzZWQnLCAhb24pO1xufVxuXG5mdW5jdGlvbiBwYWludEF1dG9TY3JvbGwoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHNlY3MgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWM7XG4gIGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZSA9IFN0cmluZyhzZWNzKTtcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IFN0cmluZyhzZWNzKTtcbiAgY29uc3QgYXMgPSBzdGF0ZS5hdXRvU2Nyb2xsO1xuICBhdXRvU2Nyb2xsU3RhcnRCdG4uaGlkZGVuID0gYXMuYWN0aXZlO1xuICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmhpZGRlbiA9ICFhcy5hY3RpdmU7XG4gIGlmIChhcy5hY3RpdmUpIHtcbiAgICBjb25zdCBuID0gYXMudGFiQ291bnQ7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9XG4gICAgICBuID09PSAwID8gYHJ1bm5pbmcgXHUyMDE0IG5vIFggdGFicyBvcGVuYCA6IGBydW5uaW5nIFx1MjAxNCAke259ICR7biA9PT0gMSA/ICd0YWInIDogJ3RhYnMnfWA7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy5jbGFzc05hbWUgPSAnbXV0ZWQgb24nO1xuICB9IGVsc2Uge1xuICAgIGF1dG9TY3JvbGxTdGF0dXMudGV4dENvbnRlbnQgPSAnaWRsZSc7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy5jbGFzc05hbWUgPSAnbXV0ZWQnO1xuICB9XG4gIGlmIChhcy5hY3RpdmUgfHwgYXMuc2Nyb2xsQ291bnQgPiAwIHx8IGFzLmluZ2VzdGVkQ291bnQgPiAwKSB7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmhpZGRlbiA9IGZhbHNlO1xuICAgIGNvbnN0IHBhcnRzID0gW1xuICAgICAgYCR7Zm10TnVtKGFzLnNjcm9sbENvdW50KX0gc2Nyb2xsc2AsXG4gICAgICBgJHtmbXROdW0oYXMuaW5nZXN0ZWROZXdDb3VudCl9IG5ldyBidWZmZXJlZGAsXG4gICAgICBgJHtmbXROdW0oYXMuaW5nZXN0ZWRFeGlzdGluZ0NvdW50KX0gb2xkIGJ1ZmZlcmVkYCxcbiAgICBdO1xuICAgIGlmIChhcy5za2lwcGVkT2xkQ291bnQgPiAwKSBwYXJ0cy5wdXNoKGAke2ZtdE51bShhcy5za2lwcGVkT2xkQ291bnQpfSBvbGQgc2tpcHBlZGApO1xuICAgIHBhcnRzLnB1c2goYCR7Zm10TnVtKGFzLmV4cGFuZGVkQ291bnQpfSBleHBhbmRlZGApO1xuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy50ZXh0Q29udGVudCA9IHBhcnRzLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmNsYXNzTmFtZSA9IGFzLmFjdGl2ZSA/ICdwcm9ncmVzcyBvbicgOiAncHJvZ3Jlc3MnO1xuICB9IGVsc2Uge1xuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy5oaWRkZW4gPSB0cnVlO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBhaW50UmVmZXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3QgcSA9IHN0YXRlLnJlZmV0Y2hRdWV1ZTtcbiAgY29uc3QgdG90YWwgPSBxLnRvdGFsO1xuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xuICByZWZldGNoU2VjdGlvbi5oaWRkZW4gPSB0b3RhbCA9PT0gMCAmJiAhcnVubmluZztcbiAgcmVmZXRjaENvdW50LnRleHRDb250ZW50ID1cbiAgICB0b3RhbCA9PT0gMFxuICAgICAgPyBydW5uaW5nXG4gICAgICAgID8gJ2ZpbmlzaGluZ1x1MjAyNidcbiAgICAgICAgOiAnMCBxdWV1ZWQnXG4gICAgICA6IGAke2ZtdE51bSh0b3RhbCl9IHF1ZXVlZCR7cnVubmluZyA/ICcgXHUwMEI3IHJ1bm5pbmcnIDogJyd9YDtcbiAgcmVmZXRjaFN0YXJ0QnRuLmhpZGRlbiA9IHJ1bm5pbmc7XG4gIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xuICByZWZldGNoQ2FuY2VsQnRuLmhpZGRlbiA9ICFydW5uaW5nO1xuICBwYWludFF1ZXVlUHJvZ3Jlc3MocmVmZXRjaFByb2dyZXNzLCBxKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBQdWxsIHN0cmFpZ2h0IGZyb20gc3RvcmFnZSBvbiBmaXJzdCByZW5kZXI7IGxpdmUgdXBkYXRlcyBjb21lIHZpYVxuICAvLyBgbG9nLWV2ZW50YCBicm9hZGNhc3RzLlxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KCdhY3Rpdml0eScpO1xuICBjb25zdCBldmVudHMgPSAoc3RvcmVkLmFjdGl2aXR5IGFzIExvZ0V2ZW50W10gfCB1bmRlZmluZWQpID8/IFtdO1xuICByZW5kZXJBY3Rpdml0eShldmVudHMpO1xufVxuXG4vLyAtLS0gV2lyZSB1cCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5jYXB0dXJlQWxsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtYWxsJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5jYXB0dXJlVGhpc0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS10aGlzLXBhZ2UnIH0pO1xuICB9IGZpbmFsbHkge1xuICAgIGNhcHR1cmVUaGlzQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5mbHVzaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgZmx1c2hCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnZmx1c2gtYWxsJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBmbHVzaEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuYXV0b1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtYXV0by1jYXB0dXJlJywgb246IGF1dG9Ub2dnbGUuY2hlY2tlZCB9KTtcbn0pO1xuXG51cGRhdGVFeGlzdGluZ1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtdXBkYXRlLWV4aXN0aW5nJywgb246IHVwZGF0ZUV4aXN0aW5nVG9nZ2xlLmNoZWNrZWQgfSk7XG59KTtcblxubWFzdGVyU3dpdGNoLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1lbmFibGVkJywgb246IG1hc3RlclN3aXRjaC5jaGVja2VkIH0pO1xufSk7XG5cbmF1dG9TY3JvbGxTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgYXV0b1Njcm9sbFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LWF1dG8tc2Nyb2xsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcbmF1dG9TY3JvbGxDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGF1dG9TY3JvbGxDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLWF1dG8tc2Nyb2xsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbmF1dG9TY3JvbGxJbnRlcnZhbC5hZGRFdmVudExpc3RlbmVyKCdpbnB1dCcsICgpID0+IHtcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZTtcbn0pO1xuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgY29uc3Qgc2Vjb25kcyA9IE51bWJlcihhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWUpO1xuICBpZiAoTnVtYmVyLmlzRmluaXRlKHNlY29uZHMpKSB7XG4gICAgdm9pZCBzZW5kKHsgdHlwZTogJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCcsIHNlY29uZHMgfSk7XG4gIH1cbn0pO1xuXG5wdXJnZUxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICBjb25zdCBvayA9IHdpbmRvdy5jb25maXJtKFxuICAgICdEcm9wIGV2ZXJ5IGNvdW50ZXIsIHJ1biBidWZmZXIsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyeSBmb3IgYWNjb3VudHMgbm90IGluIHlvdXIgdHJhY2tlZCBsaXN0P1xcblxcbicgK1xuICAgICAgJ1RoaXMgb25seSB0b3VjaGVzIGxvY2FsIGV4dGVuc2lvbiBzdGF0ZS4gQWxyZWFkeS1jb21taXR0ZWQgZmlsZXMgaW4gdGhlIEdpdEh1YiByZXBvIGFyZSBub3QgYWZmZWN0ZWQgXHUyMDE0ICcgK1xuICAgICAgJ3J1biBzY3JpcHRzL3B1cmdlX3VucmVsYXRlZC5weSBzZXBhcmF0ZWx5IGlmIHlvdSBhbHNvIHdhbnQgdG8gc2NydWIgdGhlIHJlcG8uJ1xuICApO1xuICBpZiAoIW9rKSByZXR1cm47XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdwdXJnZS11bnJlbGF0ZWQnIH0pO1xufSk7XG5cbnJlZmV0Y2hTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5yZWZldGNoQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1yZWZldGNoJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICByZWZldGNoQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbm1lZGlhQ3Jhd2xTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LW1lZGlhLWNyYXdsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxubWVkaWFDcmF3bENhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxub3B0aW9uc0xpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnb3Blbi1vcHRpb25zJyB9KTtcbn0pO1xuXG52aWV3ZXJMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ29wZW4tdmlld2VyJyB9KTtcbn0pO1xuXG5jbGVhckFjdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjbGVhci1hY3Rpdml0eScgfSk7XG4gIHJlbmRlckFjdGl2aXR5KFtdKTtcbn0pO1xuXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24pID0+IHtcbiAgaWYgKCFtc2cgfHwgdHlwZW9mIG1zZyAhPT0gJ29iamVjdCcpIHJldHVybjtcbiAgY29uc3QgbSA9IG1zZyBhcyB7IHR5cGU/OiBzdHJpbmc7IHN0YXRlPzogRXh0ZW5zaW9uU3RhdGU7IGV2ZW50PzogTG9nRXZlbnQgfTtcbiAgaWYgKG0udHlwZSA9PT0gJ3N0YXRlLWNoYW5nZWQnICYmIG0uc3RhdGUpIHtcbiAgICBsYXN0U3RhdGUgPSBtLnN0YXRlO1xuICAgIHBhaW50KG0uc3RhdGUpO1xuICB9IGVsc2UgaWYgKG0udHlwZSA9PT0gJ2xvZy1ldmVudCcgJiYgbS5ldmVudCkge1xuICAgIHByZXBlbmRFdmVudChtLmV2ZW50KTtcbiAgfVxufSk7XG5cbmZ1bmN0aW9uIHByZXBlbmRFdmVudChldjogTG9nRXZlbnQpOiB2b2lkIHtcbiAgLy8gSWYgdGhlIGxpc3QgaXMgc2hvd2luZyB0aGUgXCJlbXB0eVwiIHBsYWNlaG9sZGVyLCBjbGVhciBpdC5cbiAgaWYgKGFjdGl2aXR5TGlzdC5maXJzdEVsZW1lbnRDaGlsZD8uY2xhc3NMaXN0LmNvbnRhaW5zKCdlbXB0eScpKSB7XG4gICAgYWN0aXZpdHlMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICB9XG4gIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgbGkuY2xhc3NOYW1lID0gYGV2ICR7ZXYubGV2ZWx9YDtcbiAgY29uc3QgdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XG4gIHRzLnRleHRDb250ZW50ID0gbmV3IERhdGUoZXYudHMpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tVVMnLCB7IGhvdXIxMjogZmFsc2UgfSk7XG4gIGNvbnN0IGljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xuICBpY29uLnRleHRDb250ZW50ID0gZXYubGV2ZWwgPT09ICdlcnJvcicgPyAnXHUyNzE3JyA6IGV2LmxldmVsID09PSAnd2FybicgPyAnIScgOiAnXHUwMEI3JztcbiAgY29uc3QgYm9keSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIG1zZy5jbGFzc05hbWUgPSAnZXYtbXNnJztcbiAgbXNnLnRleHRDb250ZW50ID0gZXYubXNnO1xuICBib2R5LmFwcGVuZChtc2cpO1xuICBjb25zdCBjdHhLZXlzID0gT2JqZWN0LmtleXMoZXYuY29udGV4dCk7XG4gIGlmIChjdHhLZXlzLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBjdHguY2xhc3NOYW1lID0gJ2V2LWN0eCc7XG4gICAgY3R4LnRleHRDb250ZW50ID0gY3R4S2V5cy5tYXAoKGspID0+IGAke2t9PSR7c3RyaW5naWZ5U2hvcnQoZXYuY29udGV4dFtrXSl9YCkuam9pbignIFx1MDBCNyAnKTtcbiAgICBib2R5LmFwcGVuZChjdHgpO1xuICB9XG4gIGxpLmFwcGVuZCh0cywgaWNvbiwgYm9keSk7XG4gIGFjdGl2aXR5TGlzdC5wcmVwZW5kKGxpKTtcbiAgd2hpbGUgKGFjdGl2aXR5TGlzdC5jaGlsZEVsZW1lbnRDb3VudCA+IEFDVElWSVRZX1RBSUxfTUFYKSB7XG4gICAgYWN0aXZpdHlMaXN0Lmxhc3RFbGVtZW50Q2hpbGQ/LnJlbW92ZSgpO1xuICB9XG59XG5cbi8vIEluaXRpYWwgcGFpbnQuXG52b2lkIHJlZnJlc2hTdGF0ZSgpO1xudm9pZCByZWZyZXNoQWN0aXZpdHkoKTtcblxuLy8gUGVyaW9kaWNhbGx5IHJlLWZldGNoIHN0YXRlIHNvIFwibGFzdCBjYXB0dXJlXCIgdGltZXMgc3RheSBmcmVzaC5cbnNldEludGVydmFsKCgpID0+IHtcbiAgdm9pZCByZWZyZXNoU3RhdGUoKTtcbn0sIDE1XzAwMCk7XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBMEZPLElBQU0sb0JBQW9CO0FBRzFCLElBQU0sZ0NBQWdDLEtBQUssS0FBSzs7O0FDbEZ2RCxJQUFNLElBQUksQ0FBc0MsT0FBa0I7QUFDaEUsUUFBTSxLQUFLLFNBQVMsZUFBZSxFQUFFO0FBQ3JDLE1BQUksQ0FBQyxHQUFJLE9BQU0sSUFBSSxNQUFNLG9CQUFvQixFQUFFLEVBQUU7QUFDakQsU0FBTztBQUNUO0FBRUEsSUFBTSxVQUFVLEVBQUUsVUFBVTtBQUM1QixJQUFNLFdBQVcsRUFBbUIsV0FBVztBQUMvQyxJQUFNLGNBQWMsRUFBb0IsY0FBYztBQUN0RCxJQUFNLGVBQWUsRUFBb0IsZUFBZTtBQUN4RCxJQUFNLGFBQWEsRUFBb0IsY0FBYztBQUNyRCxJQUFNLHVCQUF1QixFQUFvQixpQkFBaUI7QUFDbEUsSUFBTSxnQkFBZ0IsRUFBcUIsYUFBYTtBQUN4RCxJQUFNLGlCQUFpQixFQUFxQixjQUFjO0FBQzFELElBQU0sV0FBVyxFQUFxQixXQUFXO0FBQ2pELElBQU0sY0FBYyxFQUFxQixjQUFjO0FBQ3ZELElBQU0sYUFBYSxFQUFxQixhQUFhO0FBQ3JELElBQU0sY0FBYyxFQUFxQixnQkFBZ0I7QUFDekQsSUFBTSxlQUFlLEVBQW1CLGFBQWE7QUFDckQsSUFBTSxlQUFlLEVBQW9CLGVBQWU7QUFDeEQsSUFBTSxjQUFjLEVBQW1CLGNBQWM7QUFDckQsSUFBTSxxQkFBcUIsRUFBb0Isc0JBQXNCO0FBQ3JFLElBQU0sbUJBQW1CLEVBQW1CLGtCQUFrQjtBQUM5RCxJQUFNLG1CQUFtQixFQUFtQixvQkFBb0I7QUFDaEUsSUFBTSxxQkFBcUIsRUFBcUIsbUJBQW1CO0FBQ25FLElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLHFCQUFxQixFQUFtQixzQkFBc0I7QUFDcEUsSUFBTSxpQkFBaUIsRUFBZSxpQkFBaUI7QUFDdkQsSUFBTSxlQUFlLEVBQW1CLGVBQWU7QUFDdkQsSUFBTSxrQkFBa0IsRUFBcUIsZUFBZTtBQUM1RCxJQUFNLG1CQUFtQixFQUFxQixnQkFBZ0I7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsa0JBQWtCO0FBQzdELElBQU0sb0JBQW9CLEVBQWUscUJBQXFCO0FBQzlELElBQU0sa0JBQWtCLEVBQW1CLG1CQUFtQjtBQUM5RCxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLFlBQVksRUFBcUIsaUJBQWlCO0FBRXhELElBQUksWUFBbUM7QUFFdkMsZUFBZSxLQUFRLEtBQWlDO0FBQ3RELFNBQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUN4QztBQUVBLFNBQVMsY0FBYyxPQUE2QjtBQUNsRCxRQUFNLEVBQUUsWUFBWSxTQUFTLElBQUk7QUFDakMsTUFBSSxNQUFNO0FBQ1YsTUFBSSxPQUFPO0FBS1gsUUFBTSxnQkFDSixXQUFXLFdBQVcsUUFBUSxTQUFTLFVBQVUsV0FBVywyQkFBMkI7QUFDekYsTUFBSSxDQUFDLFNBQVMsUUFBUTtBQUNwQixVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxlQUFlO0FBQ3hCLFVBQU07QUFDTixXQUFPLFdBQVcsU0FBUyxNQUFNLHVCQUF1QixTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksNENBQXVDLFdBQVcsaUJBQWlCLFFBQVE7QUFBQSxFQUNwSyxXQUFXLFdBQVcsV0FBVyxNQUFNO0FBQ3JDLFVBQU07QUFDTixXQUFPLGlCQUFpQixXQUFXLFNBQVMsR0FBRyxPQUFPLFNBQVMsS0FBSyxJQUFJLFNBQVMsSUFBSSxlQUFPLFNBQVMsU0FBUztBQUFBLEVBQ2hILFdBQVcsV0FBVyxXQUFXLGNBQWM7QUFDN0MsVUFBTTtBQUNOLFdBQU8saUJBQWlCLFdBQVcsS0FBSyxJQUNwQyxvRUFDQTtBQUFBLEVBQ04sV0FBVyxXQUFXLFdBQVcsZ0JBQWdCO0FBQy9DLFVBQU07QUFDTixVQUFNLFNBQVMsa0JBQWtCLFdBQVcsZ0JBQWdCO0FBQzVELFdBQU8sU0FDSCxxQ0FBZ0MsTUFBTSxLQUN0QztBQUFBLEVBQ04sV0FBVyxXQUFXLFdBQVcsaUJBQWlCO0FBQ2hELFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLFdBQVcsV0FBVyxrQkFBa0I7QUFDakQsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULE9BQU87QUFDTCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDQSxVQUFRLFlBQVksT0FBTyxHQUFHO0FBQzlCLFdBQVMsY0FBYztBQUN2QixXQUFTLFFBQVEsV0FBVyxTQUFTO0FBQ3ZDO0FBRUEsU0FBUyxPQUFPLEtBQTRCO0FBQzFDLE1BQUksQ0FBQyxJQUFLLFFBQU87QUFDakIsUUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHO0FBQ3hCLE1BQUksQ0FBQyxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFDaEMsUUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssT0FBTyxLQUFLLElBQUksSUFBSSxLQUFLLEdBQUksQ0FBQztBQUM1RCxNQUFJLE9BQU8sRUFBRyxRQUFPO0FBQ3JCLE1BQUksT0FBTyxHQUFJLFFBQU8sR0FBRyxJQUFJO0FBQzdCLFFBQU0sT0FBTyxLQUFLLE1BQU0sT0FBTyxFQUFFO0FBQ2pDLE1BQUksT0FBTyxHQUFJLFFBQU8sR0FBRyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxLQUFLLE1BQU0sT0FBTyxFQUFFO0FBQ2xDLE1BQUksUUFBUSxHQUFJLFFBQU8sR0FBRyxLQUFLO0FBQy9CLFFBQU0sT0FBTyxLQUFLLE1BQU0sUUFBUSxFQUFFO0FBQ2xDLFNBQU8sR0FBRyxJQUFJO0FBQ2hCO0FBRUEsU0FBUyxrQkFBa0IsVUFBaUM7QUFDMUQsTUFBSSxhQUFhLEtBQU0sUUFBTztBQUM5QixRQUFNLFdBQVcsV0FBVyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUN4RCxNQUFJLFlBQVksRUFBRyxRQUFPO0FBQzFCLFFBQU0sWUFBWSxJQUFJLEtBQUssV0FBVyxHQUFJLEVBQUUsbUJBQW1CLENBQUMsR0FBRztBQUFBLElBQ2pFLE1BQU07QUFBQSxJQUNOLFFBQVE7QUFBQSxFQUNWLENBQUM7QUFDRCxNQUFJLFdBQVcsR0FBSSxRQUFPLE1BQU0sUUFBUSxNQUFNLFNBQVM7QUFDdkQsUUFBTSxPQUFPLEtBQUssTUFBTSxXQUFXLEVBQUU7QUFDckMsTUFBSSxPQUFPLEdBQUksUUFBTyxNQUFNLElBQUksTUFBTSxTQUFTO0FBQy9DLFFBQU0sUUFBUSxLQUFLLE1BQU0sT0FBTyxFQUFFO0FBQ2xDLFNBQU8sTUFBTSxLQUFLLE1BQU0sU0FBUztBQUNuQztBQUVBLFNBQVMsT0FBTyxHQUFtQjtBQUNqQyxTQUFPLEVBQUUsZUFBZSxPQUFPO0FBQ2pDO0FBRUEsU0FBUyxpQkFBaUIsU0FBaUM7QUFDekQsU0FDRSxPQUFPLFlBQVksWUFDbkIsNkVBQTZFLEtBQUssT0FBTztBQUU3RjtBQUVBLFNBQVMsZUFBZSxPQUE2QjtBQUNuRCxjQUFZLGdCQUFnQjtBQUM1QixNQUFJLE1BQU0sU0FBUyxXQUFXLEdBQUc7QUFDL0IsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixnQkFBWSxPQUFPLEVBQUU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsYUFBVyxLQUFLLE1BQU0sVUFBVTtBQUM5QixVQUFNLElBQUksTUFBTSxTQUFTLEVBQUUsTUFBTTtBQUNqQyxVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZLEtBQUssRUFBRSxnQkFBZ0IsSUFBSSxnQkFBZ0I7QUFFMUQsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixVQUFNLFNBQVMsU0FBUyxjQUFjLE1BQU07QUFDNUMsV0FBTyxZQUFZO0FBQ25CLFdBQU8sWUFBWSw0QkFBNEIsV0FBVyxFQUFFLE1BQU0sQ0FBQztBQUNuRSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxFQUFFO0FBQ3JCLFNBQUssT0FBTyxRQUFRLElBQUk7QUFFeEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixVQUFNLFFBQVEsU0FBUyxjQUFjLE1BQU07QUFDM0MsVUFBTSxZQUFZO0FBQ2xCLFVBQU0sUUFBUSxHQUFHLGNBQWM7QUFDL0IsVUFBTSxXQUFXLEdBQUcsaUJBQWlCO0FBQ3JDLFVBQU0sT0FBTyxHQUFHLGlCQUFpQjtBQUNqQyxVQUFNLFlBQ0oscUJBQXFCLE9BQU8sS0FBSyxDQUFDLG1CQUNqQyxXQUFXLElBQUksMkJBQXdCLE9BQU8sUUFBUSxDQUFDLHFCQUFxQixNQUM3RSxjQUFXLFdBQVcsT0FBTyxJQUFJLENBQUMsQ0FBQztBQUVyQyxVQUFNLFVBQVUsU0FBUyxjQUFjLE1BQU07QUFDN0MsWUFBUSxZQUFZO0FBQ3BCLFVBQU0sTUFBTSxTQUFTLGNBQWMsUUFBUTtBQUMzQyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjO0FBQ2xCLFFBQUksaUJBQWlCLFNBQVMsWUFBWTtBQUN4QyxVQUFJLFdBQVc7QUFDZixVQUFJO0FBQ0YsY0FBTSxLQUFLLEVBQUUsTUFBTSxlQUFlLFFBQVEsRUFBRSxPQUFPLENBQUM7QUFBQSxNQUN0RCxVQUFFO0FBQ0EsWUFBSSxXQUFXO0FBQUEsTUFDakI7QUFBQSxJQUNGLENBQUM7QUFDRCxZQUFRLE9BQU8sR0FBRztBQUVsQixRQUFJLE9BQU8sT0FBTyxPQUFPO0FBQ3pCLE9BQUcsT0FBTyxNQUFNLEdBQUc7QUFDbkIsZ0JBQVksT0FBTyxFQUFFO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsZUFBZSxRQUEwQjtBQUNoRCxlQUFhLGdCQUFnQjtBQUM3QixNQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsaUJBQWEsT0FBTyxFQUFFO0FBQ3RCO0FBQUEsRUFDRjtBQUNBLGFBQVcsTUFBTSxPQUFPLE1BQU0sR0FBRyxpQkFBaUIsR0FBRztBQUNuRCxVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZLE1BQU0sR0FBRyxLQUFLO0FBQzdCLFVBQU0sS0FBSyxTQUFTLGNBQWMsTUFBTTtBQUN4QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWMsSUFBSSxLQUFLLEdBQUcsRUFBRSxFQUFFLG1CQUFtQixTQUFTLEVBQUUsUUFBUSxNQUFNLENBQUM7QUFDOUUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsR0FBRyxVQUFVLFVBQVUsV0FBTSxHQUFHLFVBQVUsU0FBUyxNQUFNO0FBQzVFLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYyxHQUFHO0FBQ3JCLFNBQUssT0FBTyxHQUFHO0FBQ2YsVUFBTSxVQUFVLE9BQU8sS0FBSyxHQUFHLE9BQU87QUFDdEMsUUFBSSxRQUFRLFNBQVMsR0FBRztBQUN0QixZQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsVUFBSSxZQUFZO0FBQ2hCLFVBQUksY0FBYyxRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLGVBQWUsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxLQUFLLFFBQUs7QUFDeEYsV0FBSyxPQUFPLEdBQUc7QUFBQSxJQUNqQjtBQUNBLE9BQUcsT0FBTyxJQUFJLE1BQU0sSUFBSTtBQUN4QixpQkFBYSxPQUFPLEVBQUU7QUFBQSxFQUN4QjtBQUNGO0FBRUEsU0FBUyxlQUFlLEdBQW9CO0FBQzFDLE1BQUksTUFBTSxLQUFNLFFBQU87QUFDdkIsTUFBSSxPQUFPLE1BQU0sU0FBVSxRQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFDekUsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLE1BQU0sVUFBVyxRQUFPLE9BQU8sQ0FBQztBQUNwRSxNQUFJO0FBQ0YsVUFBTSxJQUFJLEtBQUssVUFBVSxDQUFDO0FBQzFCLFdBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUFBLEVBQ2hELFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxXQUFXLEdBQW1CO0FBQ3JDLFNBQU8sRUFBRTtBQUFBLElBQVE7QUFBQSxJQUFZLENBQUMsTUFDNUIsTUFBTSxNQUFNLFVBQVUsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLFdBQVc7QUFBQSxFQUN6RjtBQUNGO0FBRUEsZUFBZSxlQUE4QjtBQUMzQyxNQUFJO0FBQ0YsZ0JBQVksTUFBTSxLQUFxQixFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQzVELFVBQU0sU0FBUztBQUFBLEVBQ2pCLFNBQVMsS0FBSztBQUNaLFlBQVEsS0FBSyw2Q0FBNkMsR0FBRztBQUFBLEVBQy9EO0FBQ0Y7QUFFQSxTQUFTLE1BQU0sT0FBNkI7QUFDMUMsZUFBYSxjQUFjLE1BQU07QUFDakMsZ0JBQWMsS0FBSztBQUNuQixhQUFXLFVBQVUsTUFBTSxTQUFTO0FBQ3BDLHVCQUFxQixVQUFVLE1BQU0sU0FBUyxtQkFBbUI7QUFDakUsYUFBVyxPQUFPLFdBQVcsTUFBTSxTQUFTLEtBQUssY0FBYyxNQUFNLFNBQVMsSUFBSTtBQUNsRixvQkFBa0IsS0FBSztBQUN2QixpQkFBZSxLQUFLO0FBQ3BCLGtCQUFnQixLQUFLO0FBQ3JCLGtCQUFnQixLQUFLO0FBQ3JCLGVBQWEsS0FBSztBQUNwQjtBQUVBLFNBQVMsZ0JBQWdCLE9BQTZCO0FBQ3BELFFBQU0sSUFBSSxNQUFNO0FBQ2hCLFFBQU0sUUFBUSxFQUFFO0FBQ2hCLFFBQU0sVUFBVSxFQUFFO0FBQ2xCLG9CQUFrQixTQUFTLFVBQVUsS0FBSyxDQUFDO0FBQzNDLGtCQUFnQixjQUNkLFVBQVUsSUFDTixVQUNFLG9CQUNBLGFBQ0YsR0FBRyxPQUFPLEtBQUssQ0FBQyxVQUFVLFVBQVUsa0JBQWUsRUFBRTtBQUMzRCxxQkFBbUIsU0FBUztBQUM1QixxQkFBbUIsV0FBVyxVQUFVO0FBQ3hDLHNCQUFvQixTQUFTLENBQUM7QUFDOUIscUJBQW1CLG9CQUFvQixDQUFDO0FBQzFDO0FBRUEsU0FBUyxtQkFDUCxJQUNBLEdBQ007QUFDTixNQUFJLENBQUMsRUFBRSxXQUFXLEVBQUUsY0FBYyxHQUFHO0FBQ25DLE9BQUcsU0FBUztBQUNaO0FBQUEsRUFDRjtBQUdBLFFBQU0sUUFBUSxLQUFLLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxZQUFZLEVBQUUsS0FBSztBQUM5RCxLQUFHLFNBQVM7QUFDWixLQUFHLGNBQWMsR0FBRyxPQUFPLEVBQUUsU0FBUyxDQUFDLE1BQU0sT0FBTyxLQUFLLENBQUM7QUFDMUQsS0FBRyxZQUFZLEVBQUUsVUFBVSxnQkFBZ0I7QUFDN0M7QUFFQSxTQUFTLGtCQUFrQixPQUE2QjtBQUN0RCxRQUFNLEtBQUssTUFBTSxTQUFTLFlBQVk7QUFDdEMsZUFBYSxVQUFVO0FBQ3ZCLGNBQVksY0FBYyxLQUFLLE9BQU87QUFDdEMsV0FBUyxLQUFLLFVBQVUsT0FBTyxVQUFVLENBQUMsRUFBRTtBQUM5QztBQUVBLFNBQVMsZ0JBQWdCLE9BQTZCO0FBQ3BELFFBQU0sT0FBTyxNQUFNLFNBQVM7QUFDNUIscUJBQW1CLFFBQVEsT0FBTyxJQUFJO0FBQ3RDLG1CQUFpQixjQUFjLE9BQU8sSUFBSTtBQUMxQyxRQUFNLEtBQUssTUFBTTtBQUNqQixxQkFBbUIsU0FBUyxHQUFHO0FBQy9CLHNCQUFvQixTQUFTLENBQUMsR0FBRztBQUNqQyxNQUFJLEdBQUcsUUFBUTtBQUNiLFVBQU0sSUFBSSxHQUFHO0FBQ2IscUJBQWlCLGNBQ2YsTUFBTSxJQUFJLGtDQUE2QixrQkFBYSxDQUFDLElBQUksTUFBTSxJQUFJLFFBQVEsTUFBTTtBQUNuRixxQkFBaUIsWUFBWTtBQUFBLEVBQy9CLE9BQU87QUFDTCxxQkFBaUIsY0FBYztBQUMvQixxQkFBaUIsWUFBWTtBQUFBLEVBQy9CO0FBQ0EsTUFBSSxHQUFHLFVBQVUsR0FBRyxjQUFjLEtBQUssR0FBRyxnQkFBZ0IsR0FBRztBQUMzRCx1QkFBbUIsU0FBUztBQUM1QixVQUFNLFFBQVE7QUFBQSxNQUNaLEdBQUcsT0FBTyxHQUFHLFdBQVcsQ0FBQztBQUFBLE1BQ3pCLEdBQUcsT0FBTyxHQUFHLGdCQUFnQixDQUFDO0FBQUEsTUFDOUIsR0FBRyxPQUFPLEdBQUcscUJBQXFCLENBQUM7QUFBQSxJQUNyQztBQUNBLFFBQUksR0FBRyxrQkFBa0IsRUFBRyxPQUFNLEtBQUssR0FBRyxPQUFPLEdBQUcsZUFBZSxDQUFDLGNBQWM7QUFDbEYsVUFBTSxLQUFLLEdBQUcsT0FBTyxHQUFHLGFBQWEsQ0FBQyxXQUFXO0FBQ2pELHVCQUFtQixjQUFjLE1BQU0sS0FBSyxRQUFLO0FBQ2pELHVCQUFtQixZQUFZLEdBQUcsU0FBUyxnQkFBZ0I7QUFBQSxFQUM3RCxPQUFPO0FBQ0wsdUJBQW1CLFNBQVM7QUFBQSxFQUM5QjtBQUNGO0FBRUEsU0FBUyxhQUFhLE9BQTZCO0FBQ2pELFFBQU0sSUFBSSxNQUFNO0FBQ2hCLFFBQU0sUUFBUSxFQUFFO0FBQ2hCLFFBQU0sVUFBVSxFQUFFO0FBQ2xCLGlCQUFlLFNBQVMsVUFBVSxLQUFLLENBQUM7QUFDeEMsZUFBYSxjQUNYLFVBQVUsSUFDTixVQUNFLG9CQUNBLGFBQ0YsR0FBRyxPQUFPLEtBQUssQ0FBQyxVQUFVLFVBQVUsa0JBQWUsRUFBRTtBQUMzRCxrQkFBZ0IsU0FBUztBQUN6QixrQkFBZ0IsV0FBVyxVQUFVO0FBQ3JDLG1CQUFpQixTQUFTLENBQUM7QUFDM0IscUJBQW1CLGlCQUFpQixDQUFDO0FBQ3ZDO0FBRUEsZUFBZSxrQkFBaUM7QUFHOUMsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxVQUFVO0FBQ3pELFFBQU0sU0FBVSxPQUFPLFlBQXVDLENBQUM7QUFDL0QsaUJBQWUsTUFBTTtBQUN2QjtBQUlBLGNBQWMsaUJBQWlCLFNBQVMsWUFBWTtBQUNsRCxnQkFBYyxXQUFXO0FBQ3pCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUFBLEVBQ3BDLFVBQUU7QUFDQSxrQkFBYyxXQUFXO0FBQUEsRUFDM0I7QUFDRixDQUFDO0FBRUQsZUFBZSxpQkFBaUIsU0FBUyxZQUFZO0FBQ25ELGlCQUFlLFdBQVc7QUFDMUIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFBQSxFQUMxQyxVQUFFO0FBQ0EsbUJBQWUsV0FBVztBQUFBLEVBQzVCO0FBQ0YsQ0FBQztBQUVELFNBQVMsaUJBQWlCLFNBQVMsWUFBWTtBQUM3QyxXQUFTLFdBQVc7QUFDcEIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQUEsRUFDbEMsVUFBRTtBQUNBLGFBQVMsV0FBVztBQUFBLEVBQ3RCO0FBQ0YsQ0FBQztBQUVELFdBQVcsaUJBQWlCLFVBQVUsTUFBTTtBQUMxQyxPQUFLLEtBQUssRUFBRSxNQUFNLHVCQUF1QixJQUFJLFdBQVcsUUFBUSxDQUFDO0FBQ25FLENBQUM7QUFFRCxxQkFBcUIsaUJBQWlCLFVBQVUsTUFBTTtBQUNwRCxPQUFLLEtBQUssRUFBRSxNQUFNLDBCQUEwQixJQUFJLHFCQUFxQixRQUFRLENBQUM7QUFDaEYsQ0FBQztBQUVELGFBQWEsaUJBQWlCLFVBQVUsTUFBTTtBQUM1QyxPQUFLLEtBQUssRUFBRSxNQUFNLGtCQUFrQixJQUFJLGFBQWEsUUFBUSxDQUFDO0FBQ2hFLENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxxQkFBbUIsV0FBVztBQUM5QixPQUFLLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3JELHVCQUFtQixXQUFXO0FBQUEsRUFDaEMsQ0FBQztBQUNILENBQUM7QUFDRCxvQkFBb0IsaUJBQWlCLFNBQVMsTUFBTTtBQUNsRCxzQkFBb0IsV0FBVztBQUMvQixPQUFLLEtBQUssRUFBRSxNQUFNLHFCQUFxQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3RELHdCQUFvQixXQUFXO0FBQUEsRUFDakMsQ0FBQztBQUNILENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxtQkFBaUIsY0FBYyxtQkFBbUI7QUFDcEQsQ0FBQztBQUNELG1CQUFtQixpQkFBaUIsVUFBVSxNQUFNO0FBQ2xELFFBQU0sVUFBVSxPQUFPLG1CQUFtQixLQUFLO0FBQy9DLE1BQUksT0FBTyxTQUFTLE9BQU8sR0FBRztBQUM1QixTQUFLLEtBQUssRUFBRSxNQUFNLDRCQUE0QixRQUFRLENBQUM7QUFBQSxFQUN6RDtBQUNGLENBQUM7QUFFRCxVQUFVLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNoRCxJQUFFLGVBQWU7QUFDakIsUUFBTSxLQUFLLE9BQU87QUFBQSxJQUNoQjtBQUFBLEVBR0Y7QUFDQSxNQUFJLENBQUMsR0FBSTtBQUNULE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFDdkMsQ0FBQztBQUVELGdCQUFnQixpQkFBaUIsU0FBUyxNQUFNO0FBQzlDLGtCQUFnQixXQUFXO0FBQzNCLE9BQUssS0FBSyxFQUFFLE1BQU0sZ0JBQWdCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDakQsb0JBQWdCLFdBQVc7QUFBQSxFQUM3QixDQUFDO0FBQ0gsQ0FBQztBQUVELGlCQUFpQixpQkFBaUIsU0FBUyxNQUFNO0FBQy9DLG1CQUFpQixXQUFXO0FBQzVCLE9BQUssS0FBSyxFQUFFLE1BQU0saUJBQWlCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDbEQscUJBQWlCLFdBQVc7QUFBQSxFQUM5QixDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2xELElBQUUsZUFBZTtBQUNqQixPQUFLLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNwQyxDQUFDO0FBRUQsV0FBVyxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDakQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQ25DLENBQUM7QUFFRCxZQUFZLGlCQUFpQixTQUFTLFlBQVk7QUFDaEQsUUFBTSxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNyQyxpQkFBZSxDQUFDLENBQUM7QUFDbkIsQ0FBQztBQUVELFFBQVEsUUFBUSxVQUFVLFlBQVksQ0FBQyxRQUFpQjtBQUN0RCxNQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsU0FBVTtBQUNyQyxRQUFNLElBQUk7QUFDVixNQUFJLEVBQUUsU0FBUyxtQkFBbUIsRUFBRSxPQUFPO0FBQ3pDLGdCQUFZLEVBQUU7QUFDZCxVQUFNLEVBQUUsS0FBSztBQUFBLEVBQ2YsV0FBVyxFQUFFLFNBQVMsZUFBZSxFQUFFLE9BQU87QUFDNUMsaUJBQWEsRUFBRSxLQUFLO0FBQUEsRUFDdEI7QUFDRixDQUFDO0FBRUQsU0FBUyxhQUFhLElBQW9CO0FBRXhDLE1BQUksYUFBYSxtQkFBbUIsVUFBVSxTQUFTLE9BQU8sR0FBRztBQUMvRCxpQkFBYSxnQkFBZ0I7QUFBQSxFQUMvQjtBQUNBLFFBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxLQUFHLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDN0IsUUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQ3hDLEtBQUcsWUFBWTtBQUNmLEtBQUcsY0FBYyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUM5RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsT0FBSyxZQUFZO0FBQ2pCLE9BQUssY0FBYyxHQUFHLFVBQVUsVUFBVSxXQUFNLEdBQUcsVUFBVSxTQUFTLE1BQU07QUFDNUUsUUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFFBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxNQUFJLFlBQVk7QUFDaEIsTUFBSSxjQUFjLEdBQUc7QUFDckIsT0FBSyxPQUFPLEdBQUc7QUFDZixRQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTztBQUN0QyxNQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssUUFBSztBQUN4RixTQUFLLE9BQU8sR0FBRztBQUFBLEVBQ2pCO0FBQ0EsS0FBRyxPQUFPLElBQUksTUFBTSxJQUFJO0FBQ3hCLGVBQWEsUUFBUSxFQUFFO0FBQ3ZCLFNBQU8sYUFBYSxvQkFBb0IsbUJBQW1CO0FBQ3pELGlCQUFhLGtCQUFrQixPQUFPO0FBQUEsRUFDeEM7QUFDRjtBQUdBLEtBQUssYUFBYTtBQUNsQixLQUFLLGdCQUFnQjtBQUdyQixZQUFZLE1BQU07QUFDaEIsT0FBSyxhQUFhO0FBQ3BCLEdBQUcsSUFBTTsiLAogICJuYW1lcyI6IFtdCn0K
