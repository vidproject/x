// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = `Auth error \u2014 check your PAT`;
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    autoScrollProgress.textContent = `${fmtNum(as.scrollCount)} scrolls \xB7 ${fmtNum(as.ingestedCount)} tweets ingested \xB7 ${fmtNum(as.expandedCount)} expanded`;
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgZW5hYmxlZDogdHJ1ZSxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxufTtcblxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01JTl9TRUMgPSAzO1xuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01BWF9TRUMgPSA2MDtcblxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcbi8vIHJlcG8gaGFzIGJlZW4gaW5pdGlhbGl6ZWQgb3IgUEFUIG1pc2NvbmZpZ3VyZWQpLiBLZXB0IGluIHN5bmMgd2l0aCB0aGUgZmlsZS5cbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScgfSxcbiAgeyBoYW5kbGU6ICdJQ0Vnb3YnLCBsYWJlbDogJ1UuUy4gSW1taWdyYXRpb24gYW5kIEN1c3RvbXMgRW5mb3JjZW1lbnQnIH0sXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJyB9LFxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycgfSxcbiAgeyBoYW5kbGU6ICdXaGl0ZUhvdXNlJywgbGFiZWw6ICdUaGUgV2hpdGUgSG91c2UnIH0sXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScgfSxcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJyB9LFxuICB7IGhhbmRsZTogJ1VTRE9MJywgbGFiZWw6ICdVLlMuIERlcGFydG1lbnQgb2YgTGFib3InIH0sXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycgfSxcbl07XG5cbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXG5leHBvcnQgY29uc3QgVFdFRVRfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbiAgJ0xpa2VzJyxcbiAgJ0Jvb2ttYXJrcycsXG4gICdIb21lVGltZWxpbmUnLFxuICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcbiAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXG5dKTtcblxuLy8gRW5kcG9pbnRzIHRoYXQgY2FycnkgQ29tbXVuaXR5IE5vdGUgYm9kaWVzIFx1MjAxNCBjYXB0dXJlZCBmb3IgY29tcGxldGVuZXNzIGJ1dFxuLy8gdGhleSBkb24ndCBpbnRyb2R1Y2UgbmV3IHR3ZWV0cywgc28gdGhleSBkb24ndCBuZWVkIHRvIGJlIGluIFRXRUVUX0VORFBPSU5UUy5cbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdCaXJkd2F0Y2hGZXRjaE9uZU5vdGUnLFxuICAnQmlyZHdhdGNoRmV0Y2hOb3RlcycsXG5dKTtcblxuLy8gQXV4aWxpYXJ5IGVuZHBvaW50cyB3ZSBkb24ndCBleHRyYWN0IHR3ZWV0cyBmcm9tIGJ1dCB1c2UgZm9yIGNvbnRleHQgKGUuZy4sXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxuZXhwb3J0IGNvbnN0IFBST0ZJTEVfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJCeVNjcmVlbk5hbWUnLCAnVXNlckJ5UmVzdElkJ10pO1xuXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3Jcbi8vIGNvbnZlcnNhdGlvbiBcdTIwMTQgaS5lLiB2aXNpdGluZyBgLzxoYW5kbGU+YCAvIGAvPGhhbmRsZT4vd2l0aF9yZXBsaWVzYCxcbi8vIGxvb2tpbmcgYXQgb25lIHR3ZWV0LCBldGMuIEV2ZXJ5IHR3ZWV0IHJldHVybmVkIGJ5IHRoZXNlIGVuZHBvaW50cyBpc1xuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXG4vLyAocmV0d2VldGVkLCBxdW90ZWQsIHJlcGxpZWQgdG8pLCBzbyB3ZSBrZWVwIGV2ZXJ5dGhpbmcgd2Ugc2VlIHJhdGhlclxuLy8gdGhhbiBkcm9wcGluZyBub24tdHJhY2tlZCBhdXRob3JzLiBUaGF0IHdheSBhIHJldHdlZXQgb2YgYSBub24tdHJhY2tlZFxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxuLy9cbi8vIEVuZHBvaW50cyBOT1QgaW4gdGhpcyBzZXQgKEhvbWVUaW1lbGluZSwgU2VhcmNoVGltZWxpbmUsIExpa2VzLCBldGMuKVxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXG4vLyBcIkJyb3dzaW5nIG15IGhvbWUgdGltZWxpbmUgaXMgaWdub3JlZFwiIHJ1bGUuXG5leHBvcnQgY29uc3QgVVNFUl9QQUdFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG5dKTtcblxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xuXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcblxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XG5cbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcblxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XG5cbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xuIiwgIi8qKlxuICogc2lkZWJhci50cyBcdTIwMTQgVUkgZm9yIHRoZSBwZXJzaXN0ZW50IHNpZGViYXIuXG4gKlxuICogU2lkZWJhcnMgaW4gRmlyZWZveCBzdGF5IG9wZW4gYWNyb3NzIHRhYi93aW5kb3cgc3dpdGNoZXMsIHdoaWNoIGlzIHRoZVxuICogaW50ZW5kZWQgcGVyc2lzdGVuY2UgbW9kZWwuIFRoaXMgbW9kdWxlIHJlbmRlcnMgc3RhdGUgcHVzaGVkIGZyb20gdGhlXG4gKiBiYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyIGFuZCBmb3J3YXJkcyB1c2VyIGNvbW1hbmRzIGJhY2suXG4gKi9cblxuaW1wb3J0IHsgQUNUSVZJVFlfVEFJTF9NQVggfSBmcm9tICcuL2xpYi9jb25maWcuanMnO1xuaW1wb3J0IHR5cGUgeyBFeHRlbnNpb25TdGF0ZSwgTG9nRXZlbnQsIFJ1bnRpbWVNZXNzYWdlIH0gZnJvbSAnLi9saWIvdHlwZXMuanMnO1xuXG5jb25zdCAkID0gPFQgZXh0ZW5kcyBIVE1MRWxlbWVudCA9IEhUTUxFbGVtZW50PihpZDogc3RyaW5nKTogVCA9PiB7XG4gIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpO1xuICBpZiAoIWVsKSB0aHJvdyBuZXcgRXJyb3IoYG1pc3NpbmcgZWxlbWVudCAjJHtpZH1gKTtcbiAgcmV0dXJuIGVsIGFzIFQ7XG59O1xuXG5jb25zdCBjb25uRG90ID0gJCgnY29ubi1kb3QnKTtcbmNvbnN0IGNvbm5UZXh0ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdjb25uLXRleHQnKTtcbmNvbnN0IGFjY291bnRMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWNjb3VudC1saXN0Jyk7XG5jb25zdCBhY3Rpdml0eUxpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdhY3Rpdml0eS1saXN0Jyk7XG5jb25zdCBhdXRvVG9nZ2xlID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1jYXB0dXJlJyk7XG5jb25zdCBjYXB0dXJlQWxsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtYWxsJyk7XG5jb25zdCBjYXB0dXJlVGhpc0J0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjYXB0dXJlLXRoaXMnKTtcbmNvbnN0IGZsdXNoQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2ZsdXNoLWFsbCcpO1xuY29uc3Qgb3B0aW9uc0xpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi1vcHRpb25zJyk7XG5jb25zdCB2aWV3ZXJMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ29wZW4tdmlld2VyJyk7XG5jb25zdCBjbGVhckFjdEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjbGVhci1hY3Rpdml0eScpO1xuY29uc3QgZXh0VmVyc2lvbkVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdleHQtdmVyc2lvbicpO1xuY29uc3QgbWFzdGVyU3dpdGNoID0gJDxIVE1MSW5wdXRFbGVtZW50PignbWFzdGVyLXN3aXRjaCcpO1xuY29uc3QgbWFzdGVyTGFiZWwgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ21hc3Rlci1sYWJlbCcpO1xuY29uc3QgYXV0b1Njcm9sbEludGVydmFsID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1zY3JvbGwtaW50ZXJ2YWwnKTtcbmNvbnN0IGF1dG9TY3JvbGxTZWNzRWwgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXNlY3MnKTtcbmNvbnN0IGF1dG9TY3JvbGxTdGF0dXMgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXN0YXR1cycpO1xuY29uc3QgYXV0b1Njcm9sbFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXN0YXJ0Jyk7XG5jb25zdCBhdXRvU2Nyb2xsQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLWNhbmNlbCcpO1xuY29uc3QgYXV0b1Njcm9sbFByb2dyZXNzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1wcm9ncmVzcycpO1xuY29uc3QgcmVmZXRjaFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PigncmVmZXRjaC1zZWN0aW9uJyk7XG5jb25zdCByZWZldGNoQ291bnQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3JlZmV0Y2gtY291bnQnKTtcbmNvbnN0IHJlZmV0Y2hTdGFydEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZWZldGNoLXN0YXJ0Jyk7XG5jb25zdCByZWZldGNoQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZmV0Y2gtY2FuY2VsJyk7XG5jb25zdCByZWZldGNoUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3JlZmV0Y2gtcHJvZ3Jlc3MnKTtcbmNvbnN0IG1lZGlhQ3Jhd2xTZWN0aW9uID0gJDxIVE1MRWxlbWVudD4oJ21lZGlhLWNyYXdsLXNlY3Rpb24nKTtcbmNvbnN0IG1lZGlhQ3Jhd2xDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtY291bnQnKTtcbmNvbnN0IG1lZGlhQ3Jhd2xTdGFydEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1zdGFydCcpO1xuY29uc3QgbWVkaWFDcmF3bENhbmNlbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1jYW5jZWwnKTtcbmNvbnN0IG1lZGlhQ3Jhd2xQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWVkaWEtY3Jhd2wtcHJvZ3Jlc3MnKTtcbmNvbnN0IHB1cmdlTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdwdXJnZS11bnJlbGF0ZWQnKTtcblxubGV0IGxhc3RTdGF0ZTogRXh0ZW5zaW9uU3RhdGUgfCBudWxsID0gbnVsbDtcblxuYXN5bmMgZnVuY3Rpb24gc2VuZDxUPihtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTxUPiB7XG4gIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKSBhcyBQcm9taXNlPFQ+O1xufVxuXG5mdW5jdGlvbiBzZXRDb25uU3RhdHVzKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCB7IGNvbm5lY3Rpb24sIHNldHRpbmdzIH0gPSBzdGF0ZTtcbiAgbGV0IGNscyA9ICcnO1xuICBsZXQgdGV4dCA9ICcnO1xuICAvLyBPbmx5IHdhcm4gd2hlbiB0aGUgY29uZmlndXJlZCBicmFuY2ggZ2VudWluZWx5IGRvZXNuJ3QgZXhpc3Qgb24gdGhlXG4gIC8vIHJlbW90ZS4gQSBub24tZGVmYXVsdCBicmFuY2ggdGhhdCBleGlzdHMgaXMgZmluZSBcdTIwMTQgY2FwdHVyaW5nIGludG8gYVxuICAvLyB3b3JraW5nIGJyYW5jaCBpcyByb3V0aW5lIFx1MjAxNCBzbyB0aGUgbWVyZSBgIT09YCB0byBkZWZhdWx0X2JyYW5jaCBpcyBub3RcbiAgLy8gYSBwcm9ibGVtIGFuZCBzaG91bGRuJ3Qgc2hvdXQgaW4gdGhlIGhlYWRlci5cbiAgY29uc3QgYnJhbmNoTWlzc2luZyA9XG4gICAgY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycgJiYgc2V0dGluZ3MuYnJhbmNoICYmIGNvbm5lY3Rpb24uY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gZmFsc2U7XG4gIGlmICghc2V0dGluZ3MucGF0U2V0KSB7XG4gICAgY2xzID0gJ3dhcm4nO1xuICAgIHRleHQgPSAnTm90IGNvbmZpZ3VyZWQgXHUyMDE0IG9wZW4gU2V0dGluZ3MnO1xuICB9IGVsc2UgaWYgKGJyYW5jaE1pc3NpbmcpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gYEJyYW5jaCBcIiR7c2V0dGluZ3MuYnJhbmNofVwiIGRvZXMgbm90IGV4aXN0IG9uICR7c2V0dGluZ3Mub3duZXJ9LyR7c2V0dGluZ3MucmVwb30gXHUyMDE0IGNvbW1pdHMgd2lsbCA0MjIuIFNldCBicmFuY2ggdG8gXCIke2Nvbm5lY3Rpb24uZGVmYXVsdEJyYW5jaCA/PyAnbWFzdGVyJ31cIiBpbiBTZXR0aW5ncy5gO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnb2snKSB7XG4gICAgY2xzID0gJ29rJztcbiAgICB0ZXh0ID0gYENvbm5lY3RlZCBhcyBAJHtjb25uZWN0aW9uLmxvZ2luID8/ICc/J30gdG8gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTAwQjcgXHUyMDI2JHtzZXR0aW5ncy5wYXRTdWZmaXh9YDtcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ2F1dGgtZXJyb3InKSB7XG4gICAgY2xzID0gJ2Vycic7XG4gICAgdGV4dCA9IGBBdXRoIGVycm9yIFx1MjAxNCBjaGVjayB5b3VyIFBBVGA7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnKSB7XG4gICAgY2xzID0gJ3dhcm4nO1xuICAgIGNvbnN0IHJlc2V0cyA9IGZtdFJhdGVMaW1pdFJlc2V0KGNvbm5lY3Rpb24ucmF0ZUxpbWl0UmVzZXRBdCk7XG4gICAgdGV4dCA9IHJlc2V0c1xuICAgICAgPyBgR2l0SHViIHJhdGUtbGltaXRlZCBcdTIwMTQgcmVzZXRzICR7cmVzZXRzfWBcbiAgICAgIDogJ0dpdEh1YiByYXRlLWxpbWl0ZWQgXHUyMDE0IGNhcHR1cmVzIHdpbGwgcmV0cnknO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnbmV0d29yay1lcnJvcicpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gJ05ldHdvcmsgZXJyb3IgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpdml0eSc7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdub3QtY29uZmlndXJlZCcpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XG4gIH0gZWxzZSB7XG4gICAgY2xzID0gJyc7XG4gICAgdGV4dCA9ICdDaGVja2luZ1x1MjAyNic7XG4gIH1cbiAgY29ubkRvdC5jbGFzc05hbWUgPSBgZG90ICR7Y2xzfWA7XG4gIGNvbm5UZXh0LnRleHRDb250ZW50ID0gdGV4dDtcbiAgY29ublRleHQudGl0bGUgPSBjb25uZWN0aW9uLmVycm9yID8/ICcnO1xufVxuXG5mdW5jdGlvbiBmbXRSZWwoaXNvOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHtcbiAgaWYgKCFpc28pIHJldHVybiAnXHUyMDE0JztcbiAgY29uc3QgZCA9IERhdGUucGFyc2UoaXNvKTtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoZCkpIHJldHVybiAnXHUyMDE0JztcbiAgY29uc3Qgc2VjcyA9IE1hdGgubWF4KDAsIE1hdGgucm91bmQoKERhdGUubm93KCkgLSBkKSAvIDEwMDApKTtcbiAgaWYgKHNlY3MgPCA1KSByZXR1cm4gJ2p1c3Qgbm93JztcbiAgaWYgKHNlY3MgPCA2MCkgcmV0dXJuIGAke3NlY3N9cyBhZ29gO1xuICBjb25zdCBtaW5zID0gTWF0aC5yb3VuZChzZWNzIC8gNjApO1xuICBpZiAobWlucyA8IDYwKSByZXR1cm4gYCR7bWluc31tIGFnb2A7XG4gIGNvbnN0IGhvdXJzID0gTWF0aC5yb3VuZChtaW5zIC8gNjApO1xuICBpZiAoaG91cnMgPCAyNCkgcmV0dXJuIGAke2hvdXJzfWggYWdvYDtcbiAgY29uc3QgZGF5cyA9IE1hdGgucm91bmQoaG91cnMgLyAyNCk7XG4gIHJldHVybiBgJHtkYXlzfWQgYWdvYDtcbn1cblxuZnVuY3Rpb24gZm10UmF0ZUxpbWl0UmVzZXQoZXBvY2hTZWM6IG51bWJlciB8IG51bGwpOiBzdHJpbmcge1xuICBpZiAoZXBvY2hTZWMgPT09IG51bGwpIHJldHVybiAnJztcbiAgY29uc3QgZGVsdGFTZWMgPSBlcG9jaFNlYyAtIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICBpZiAoZGVsdGFTZWMgPD0gMCkgcmV0dXJuICdtb21lbnRhcmlseSc7XG4gIGNvbnN0IHdhbGxDbG9jayA9IG5ldyBEYXRlKGVwb2NoU2VjICogMTAwMCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7XG4gICAgaG91cjogJzItZGlnaXQnLFxuICAgIG1pbnV0ZTogJzItZGlnaXQnLFxuICB9KTtcbiAgaWYgKGRlbHRhU2VjIDwgNjApIHJldHVybiBgaW4gJHtkZWx0YVNlY31zICgke3dhbGxDbG9ja30pYDtcbiAgY29uc3QgbWlucyA9IE1hdGgucm91bmQoZGVsdGFTZWMgLyA2MCk7XG4gIGlmIChtaW5zIDwgNjApIHJldHVybiBgaW4gJHttaW5zfW0gKCR7d2FsbENsb2NrfSlgO1xuICBjb25zdCBob3VycyA9IE1hdGgucm91bmQobWlucyAvIDYwKTtcbiAgcmV0dXJuIGBpbiAke2hvdXJzfWggKCR7d2FsbENsb2NrfSlgO1xufVxuXG5mdW5jdGlvbiBmbXROdW0objogbnVtYmVyKTogc3RyaW5nIHtcbiAgcmV0dXJuIG4udG9Mb2NhbGVTdHJpbmcoJ2VuLVVTJyk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFjY291bnRzKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBhY2NvdW50TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgaWYgKHN0YXRlLmFjY291bnRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xuICAgIGxpLnRleHRDb250ZW50ID0gJ05vIGFjY291bnRzIGNvbmZpZ3VyZWQuJztcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xuICAgIHJldHVybjtcbiAgfVxuICBmb3IgKGNvbnN0IGEgb2Ygc3RhdGUuYWNjb3VudHMpIHtcbiAgICBjb25zdCBjID0gc3RhdGUuY291bnRlcnNbYS5oYW5kbGVdO1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSBjICYmIGMuYnVmZmVyZWRDb3VudCA+IDAgPyAnYWNjIHBlbmRpbmcnIDogJ2FjYyc7XG5cbiAgICBjb25zdCBoZWFkID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgaGVhZC5jbGFzc05hbWUgPSAnYWNjLWhlYWQnO1xuICAgIGNvbnN0IGhhbmRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBoYW5kbGUuY2xhc3NOYW1lID0gJ2FjYy1oYW5kbGUnO1xuICAgIGhhbmRsZS5pbm5lckhUTUwgPSBgPHNwYW4gY2xhc3M9XCJhdFwiPkA8L3NwYW4+JHtlc2NhcGVIdG1sKGEuaGFuZGxlKX1gO1xuICAgIGNvbnN0IG1ldGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgbWV0YS5jbGFzc05hbWUgPSAnYWNjLW1ldGEnO1xuICAgIG1ldGEudGV4dENvbnRlbnQgPSBhLmxhYmVsO1xuICAgIGhlYWQuYXBwZW5kKGhhbmRsZSwgbWV0YSk7XG5cbiAgICBjb25zdCByb3cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICByb3cuY2xhc3NOYW1lID0gJ2FjYy1yb3cnO1xuICAgIGNvbnN0IHN0YXRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHN0YXRzLmNsYXNzTmFtZSA9ICdhY2Mtc3RhdHMnO1xuICAgIGNvbnN0IHRvZGF5ID0gYz8udG9kYXlDb3VudCA/PyAwO1xuICAgIGNvbnN0IGJ1ZmZlcmVkID0gYz8uYnVmZmVyZWRDb3VudCA/PyAwO1xuICAgIGNvbnN0IGxhc3QgPSBjPy5sYXN0Q2FwdHVyZUF0ID8/IG51bGw7XG4gICAgc3RhdHMuaW5uZXJIVE1MID1cbiAgICAgIGA8c3BhbiBjbGFzcz1cIm51bVwiPiR7Zm10TnVtKHRvZGF5KX08L3NwYW4+IHRvZGF5YCArXG4gICAgICAoYnVmZmVyZWQgPiAwID8gYCBcdTAwQjcgPHNwYW4gY2xhc3M9XCJudW1cIj4ke2ZtdE51bShidWZmZXJlZCl9PC9zcGFuPiBidWZmZXJlZGAgOiAnJykgK1xuICAgICAgYCBcdTAwQjcgbGFzdCAke2VzY2FwZUh0bWwoZm10UmVsKGxhc3QpKX1gO1xuXG4gICAgY29uc3QgYWN0aW9ucyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBhY3Rpb25zLmNsYXNzTmFtZSA9ICdhY2MtYWN0aW9uJztcbiAgICBjb25zdCBidG4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdidXR0b24nKTtcbiAgICBidG4uY2xhc3NOYW1lID0gJ2J0bic7XG4gICAgYnRuLnRleHRDb250ZW50ID0gJ0NhcHR1cmUgbm93JztcbiAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gICAgICBidG4uZGlzYWJsZWQgPSB0cnVlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjYXB0dXJlLW5vdycsIGhhbmRsZTogYS5oYW5kbGUgfSk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBidG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBhY3Rpb25zLmFwcGVuZChidG4pO1xuXG4gICAgcm93LmFwcGVuZChzdGF0cywgYWN0aW9ucyk7XG4gICAgbGkuYXBwZW5kKGhlYWQsIHJvdyk7XG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJBY3Rpdml0eShldmVudHM6IExvZ0V2ZW50W10pOiB2b2lkIHtcbiAgYWN0aXZpdHlMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBpZiAoZXZlbnRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xuICAgIGxpLnRleHRDb250ZW50ID0gJ05vIGFjdGl2aXR5IHlldC4nO1xuICAgIGFjdGl2aXR5TGlzdC5hcHBlbmQobGkpO1xuICAgIHJldHVybjtcbiAgfVxuICBmb3IgKGNvbnN0IGV2IG9mIGV2ZW50cy5zbGljZSgwLCBBQ1RJVklUWV9UQUlMX01BWCkpIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gYGV2ICR7ZXYubGV2ZWx9YDtcbiAgICBjb25zdCB0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICB0cy5jbGFzc05hbWUgPSAnZXYtdHMnO1xuICAgIHRzLnRleHRDb250ZW50ID0gbmV3IERhdGUoZXYudHMpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tVVMnLCB7IGhvdXIxMjogZmFsc2UgfSk7XG4gICAgY29uc3QgaWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBpY29uLmNsYXNzTmFtZSA9ICdldi1pY29uJztcbiAgICBpY29uLnRleHRDb250ZW50ID0gZXYubGV2ZWwgPT09ICdlcnJvcicgPyAnXHUyNzE3JyA6IGV2LmxldmVsID09PSAnd2FybicgPyAnIScgOiAnXHUwMEI3JztcbiAgICBjb25zdCBib2R5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGNvbnN0IG1zZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIG1zZy5jbGFzc05hbWUgPSAnZXYtbXNnJztcbiAgICBtc2cudGV4dENvbnRlbnQgPSBldi5tc2c7XG4gICAgYm9keS5hcHBlbmQobXNnKTtcbiAgICBjb25zdCBjdHhLZXlzID0gT2JqZWN0LmtleXMoZXYuY29udGV4dCk7XG4gICAgaWYgKGN0eEtleXMubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgY3R4ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICBjdHguY2xhc3NOYW1lID0gJ2V2LWN0eCc7XG4gICAgICBjdHgudGV4dENvbnRlbnQgPSBjdHhLZXlzLm1hcCgoaykgPT4gYCR7a309JHtzdHJpbmdpZnlTaG9ydChldi5jb250ZXh0W2tdKX1gKS5qb2luKCcgXHUwMEI3ICcpO1xuICAgICAgYm9keS5hcHBlbmQoY3R4KTtcbiAgICB9XG4gICAgbGkuYXBwZW5kKHRzLCBpY29uLCBib2R5KTtcbiAgICBhY3Rpdml0eUxpc3QuYXBwZW5kKGxpKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzdHJpbmdpZnlTaG9ydCh2OiB1bmtub3duKTogc3RyaW5nIHtcbiAgaWYgKHYgPT09IG51bGwpIHJldHVybiAnbnVsbCc7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycpIHJldHVybiB2Lmxlbmd0aCA+IDgwID8gYCR7di5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHY7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ251bWJlcicgfHwgdHlwZW9mIHYgPT09ICdib29sZWFuJykgcmV0dXJuIFN0cmluZyh2KTtcbiAgdHJ5IHtcbiAgICBjb25zdCBzID0gSlNPTi5zdHJpbmdpZnkodik7XG4gICAgcmV0dXJuIHMubGVuZ3RoID4gODAgPyBgJHtzLnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogcztcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuICc/JztcbiAgfVxufVxuXG5mdW5jdGlvbiBlc2NhcGVIdG1sKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBzLnJlcGxhY2UoL1smPD5cIiddL2csIChjKSA9PlxuICAgIGMgPT09ICcmJyA/ICcmYW1wOycgOiBjID09PSAnPCcgPyAnJmx0OycgOiBjID09PSAnPicgPyAnJmd0OycgOiBjID09PSAnXCInID8gJyZxdW90OycgOiAnJiMzOTsnXG4gICk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hTdGF0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBsYXN0U3RhdGUgPSBhd2FpdCBzZW5kPEV4dGVuc2lvblN0YXRlPih7IHR5cGU6ICdnZXQtc3RhdGUnIH0pO1xuICAgIHBhaW50KGxhc3RTdGF0ZSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBzaWRlYmFyIHJlZnJlc2hTdGF0ZSBmYWlsZWQnLCBlcnIpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBhaW50KHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBleHRWZXJzaW9uRWwudGV4dENvbnRlbnQgPSBzdGF0ZS52ZXJzaW9uO1xuICBzZXRDb25uU3RhdHVzKHN0YXRlKTtcbiAgYXV0b1RvZ2dsZS5jaGVja2VkID0gc3RhdGUuc2V0dGluZ3MuYXV0b0NhcHR1cmU7XG4gIHZpZXdlckxpbmsuaHJlZiA9IGBodHRwczovLyR7c3RhdGUuc2V0dGluZ3Mub3duZXJ9LmdpdGh1Yi5pby8ke3N0YXRlLnNldHRpbmdzLnJlcG99L2A7XG4gIHBhaW50TWFzdGVyU3dpdGNoKHN0YXRlKTtcbiAgcmVuZGVyQWNjb3VudHMoc3RhdGUpO1xuICBwYWludEF1dG9TY3JvbGwoc3RhdGUpO1xuICBwYWludE1lZGlhQ3Jhd2woc3RhdGUpO1xuICBwYWludFJlZmV0Y2goc3RhdGUpO1xufVxuXG5mdW5jdGlvbiBwYWludE1lZGlhQ3Jhd2woc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHEgPSBzdGF0ZS5tZWRpYUNyYXdsUXVldWU7XG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcbiAgY29uc3QgcnVubmluZyA9IHEucnVubmluZztcbiAgbWVkaWFDcmF3bFNlY3Rpb24uaGlkZGVuID0gdG90YWwgPT09IDAgJiYgIXJ1bm5pbmc7XG4gIG1lZGlhQ3Jhd2xDb3VudC50ZXh0Q29udGVudCA9XG4gICAgdG90YWwgPT09IDBcbiAgICAgID8gcnVubmluZ1xuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXG4gICAgICAgIDogJzAgcXVldWVkJ1xuICAgICAgOiBgJHtmbXROdW0odG90YWwpfSBxdWV1ZWQke3J1bm5pbmcgPyAnIFx1MDBCNyBydW5uaW5nJyA6ICcnfWA7XG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcbiAgbWVkaWFDcmF3bENhbmNlbEJ0bi5oaWRkZW4gPSAhcnVubmluZztcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKG1lZGlhQ3Jhd2xQcm9ncmVzcywgcSk7XG59XG5cbmZ1bmN0aW9uIHBhaW50UXVldWVQcm9ncmVzcyhcbiAgZWw6IEhUTUxTcGFuRWxlbWVudCxcbiAgcTogeyBwcm9jZXNzZWQ6IG51bWJlcjsgdG90YWxfYXRfc3RhcnQ6IG51bWJlcjsgcnVubmluZzogYm9vbGVhbjsgdG90YWw6IG51bWJlciB9XG4pOiB2b2lkIHtcbiAgaWYgKCFxLnJ1bm5pbmcgJiYgcS5wcm9jZXNzZWQgPT09IDApIHtcbiAgICBlbC5oaWRkZW4gPSB0cnVlO1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBEZW5vbWluYXRvcjogbWF4IG9mIGluaXRpYWwgdG90YWwgYW5kIGN1cnJlbnQgcHJvY2Vzc2VkK3JlbWFpbmluZyBzbyB0aGVcbiAgLy8gYmFyIHN0aWxsIG1ha2VzIHNlbnNlIGlmIG5ldyBlbnRyaWVzIHdlcmUgZW5xdWV1ZWQgbWlkLXJ1bi5cbiAgY29uc3QgZGVub20gPSBNYXRoLm1heChxLnRvdGFsX2F0X3N0YXJ0LCBxLnByb2Nlc3NlZCArIHEudG90YWwpO1xuICBlbC5oaWRkZW4gPSBmYWxzZTtcbiAgZWwudGV4dENvbnRlbnQgPSBgJHtmbXROdW0ocS5wcm9jZXNzZWQpfSAvICR7Zm10TnVtKGRlbm9tKX0gcHJvY2Vzc2VkYDtcbiAgZWwuY2xhc3NOYW1lID0gcS5ydW5uaW5nID8gJ3Byb2dyZXNzIG9uJyA6ICdwcm9ncmVzcyc7XG59XG5cbmZ1bmN0aW9uIHBhaW50TWFzdGVyU3dpdGNoKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBvbiA9IHN0YXRlLnNldHRpbmdzLmVuYWJsZWQgIT09IGZhbHNlO1xuICBtYXN0ZXJTd2l0Y2guY2hlY2tlZCA9IG9uO1xuICBtYXN0ZXJMYWJlbC50ZXh0Q29udGVudCA9IG9uID8gJ09OJyA6ICdQQVVTRUQnO1xuICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC50b2dnbGUoJ3BhdXNlZCcsICFvbik7XG59XG5cbmZ1bmN0aW9uIHBhaW50QXV0b1Njcm9sbChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3Qgc2VjcyA9IHN0YXRlLnNldHRpbmdzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYztcbiAgYXV0b1Njcm9sbEludGVydmFsLnZhbHVlID0gU3RyaW5nKHNlY3MpO1xuICBhdXRvU2Nyb2xsU2Vjc0VsLnRleHRDb250ZW50ID0gU3RyaW5nKHNlY3MpO1xuICBjb25zdCBhcyA9IHN0YXRlLmF1dG9TY3JvbGw7XG4gIGF1dG9TY3JvbGxTdGFydEJ0bi5oaWRkZW4gPSBhcy5hY3RpdmU7XG4gIGF1dG9TY3JvbGxDYW5jZWxCdG4uaGlkZGVuID0gIWFzLmFjdGl2ZTtcbiAgaWYgKGFzLmFjdGl2ZSkge1xuICAgIGNvbnN0IG4gPSBhcy50YWJDb3VudDtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLnRleHRDb250ZW50ID1cbiAgICAgIG4gPT09IDAgPyBgcnVubmluZyBcdTIwMTQgbm8gWCB0YWJzIG9wZW5gIDogYHJ1bm5pbmcgXHUyMDE0ICR7bn0gJHtuID09PSAxID8gJ3RhYicgOiAndGFicyd9YDtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLmNsYXNzTmFtZSA9ICdtdXRlZCBvbic7XG4gIH0gZWxzZSB7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9ICdpZGxlJztcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLmNsYXNzTmFtZSA9ICdtdXRlZCc7XG4gIH1cbiAgaWYgKGFzLmFjdGl2ZSB8fCBhcy5zY3JvbGxDb3VudCA+IDAgfHwgYXMuaW5nZXN0ZWRDb3VudCA+IDApIHtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuaGlkZGVuID0gZmFsc2U7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLnRleHRDb250ZW50ID1cbiAgICAgIGAke2ZtdE51bShhcy5zY3JvbGxDb3VudCl9IHNjcm9sbHMgXHUwMEI3IGAgK1xuICAgICAgYCR7Zm10TnVtKGFzLmluZ2VzdGVkQ291bnQpfSB0d2VldHMgaW5nZXN0ZWQgXHUwMEI3IGAgK1xuICAgICAgYCR7Zm10TnVtKGFzLmV4cGFuZGVkQ291bnQpfSBleHBhbmRlZGA7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmNsYXNzTmFtZSA9IGFzLmFjdGl2ZSA/ICdwcm9ncmVzcyBvbicgOiAncHJvZ3Jlc3MnO1xuICB9IGVsc2Uge1xuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy5oaWRkZW4gPSB0cnVlO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBhaW50UmVmZXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3QgcSA9IHN0YXRlLnJlZmV0Y2hRdWV1ZTtcbiAgY29uc3QgdG90YWwgPSBxLnRvdGFsO1xuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xuICByZWZldGNoU2VjdGlvbi5oaWRkZW4gPSB0b3RhbCA9PT0gMCAmJiAhcnVubmluZztcbiAgcmVmZXRjaENvdW50LnRleHRDb250ZW50ID1cbiAgICB0b3RhbCA9PT0gMFxuICAgICAgPyBydW5uaW5nXG4gICAgICAgID8gJ2ZpbmlzaGluZ1x1MjAyNidcbiAgICAgICAgOiAnMCBxdWV1ZWQnXG4gICAgICA6IGAke2ZtdE51bSh0b3RhbCl9IHF1ZXVlZCR7cnVubmluZyA/ICcgXHUwMEI3IHJ1bm5pbmcnIDogJyd9YDtcbiAgcmVmZXRjaFN0YXJ0QnRuLmhpZGRlbiA9IHJ1bm5pbmc7XG4gIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xuICByZWZldGNoQ2FuY2VsQnRuLmhpZGRlbiA9ICFydW5uaW5nO1xuICBwYWludFF1ZXVlUHJvZ3Jlc3MocmVmZXRjaFByb2dyZXNzLCBxKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBQdWxsIHN0cmFpZ2h0IGZyb20gc3RvcmFnZSBvbiBmaXJzdCByZW5kZXI7IGxpdmUgdXBkYXRlcyBjb21lIHZpYVxuICAvLyBgbG9nLWV2ZW50YCBicm9hZGNhc3RzLlxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KCdhY3Rpdml0eScpO1xuICBjb25zdCBldmVudHMgPSAoc3RvcmVkLmFjdGl2aXR5IGFzIExvZ0V2ZW50W10gfCB1bmRlZmluZWQpID8/IFtdO1xuICByZW5kZXJBY3Rpdml0eShldmVudHMpO1xufVxuXG4vLyAtLS0gV2lyZSB1cCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5jYXB0dXJlQWxsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtYWxsJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjYXB0dXJlQWxsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5jYXB0dXJlVGhpc0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS10aGlzLXBhZ2UnIH0pO1xuICB9IGZpbmFsbHkge1xuICAgIGNhcHR1cmVUaGlzQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5mbHVzaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgZmx1c2hCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnZmx1c2gtYWxsJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBmbHVzaEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuYXV0b1RvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtYXV0by1jYXB0dXJlJywgb246IGF1dG9Ub2dnbGUuY2hlY2tlZCB9KTtcbn0pO1xuXG5tYXN0ZXJTd2l0Y2guYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLWVuYWJsZWQnLCBvbjogbWFzdGVyU3dpdGNoLmNoZWNrZWQgfSk7XG59KTtcblxuYXV0b1Njcm9sbFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtYXV0by1zY3JvbGwnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIGF1dG9TY3JvbGxTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuYXV0b1Njcm9sbENhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgYXV0b1Njcm9sbENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtYXV0by1zY3JvbGwnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIGF1dG9TY3JvbGxDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JywgKCkgPT4ge1xuICBhdXRvU2Nyb2xsU2Vjc0VsLnRleHRDb250ZW50ID0gYXV0b1Njcm9sbEludGVydmFsLnZhbHVlO1xufSk7XG5hdXRvU2Nyb2xsSW50ZXJ2YWwuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICBjb25zdCBzZWNvbmRzID0gTnVtYmVyKGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZSk7XG4gIGlmIChOdW1iZXIuaXNGaW5pdGUoc2Vjb25kcykpIHtcbiAgICB2b2lkIHNlbmQoeyB0eXBlOiAnc2V0LWF1dG8tc2Nyb2xsLWludGVydmFsJywgc2Vjb25kcyB9KTtcbiAgfVxufSk7XG5cbnB1cmdlTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIGNvbnN0IG9rID0gd2luZG93LmNvbmZpcm0oXG4gICAgJ0Ryb3AgZXZlcnkgY291bnRlciwgcnVuIGJ1ZmZlciwgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHF1ZXVlIGVudHJ5IGZvciBhY2NvdW50cyBub3QgaW4geW91ciB0cmFja2VkIGxpc3Q/XFxuXFxuJyArXG4gICAgICAnVGhpcyBvbmx5IHRvdWNoZXMgbG9jYWwgZXh0ZW5zaW9uIHN0YXRlLiBBbHJlYWR5LWNvbW1pdHRlZCBmaWxlcyBpbiB0aGUgR2l0SHViIHJlcG8gYXJlIG5vdCBhZmZlY3RlZCBcdTIwMTQgJyArXG4gICAgICAncnVuIHNjcmlwdHMvcHVyZ2VfdW5yZWxhdGVkLnB5IHNlcGFyYXRlbHkgaWYgeW91IGFsc28gd2FudCB0byBzY3J1YiB0aGUgcmVwby4nXG4gICk7XG4gIGlmICghb2spIHJldHVybjtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3B1cmdlLXVucmVsYXRlZCcgfSk7XG59KTtcblxucmVmZXRjaFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtcmVmZXRjaCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbnJlZmV0Y2hDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxubWVkaWFDcmF3bFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5tZWRpYUNyYXdsQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBtZWRpYUNyYXdsQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1tZWRpYS1jcmF3bCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5vcHRpb25zTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdvcGVuLW9wdGlvbnMnIH0pO1xufSk7XG5cbnZpZXdlckxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnb3Blbi12aWV3ZXInIH0pO1xufSk7XG5cbmNsZWFyQWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NsZWFyLWFjdGl2aXR5JyB9KTtcbiAgcmVuZGVyQWN0aXZpdHkoW10pO1xufSk7XG5cbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93bikgPT4ge1xuICBpZiAoIW1zZyB8fCB0eXBlb2YgbXNnICE9PSAnb2JqZWN0JykgcmV0dXJuO1xuICBjb25zdCBtID0gbXNnIGFzIHsgdHlwZT86IHN0cmluZzsgc3RhdGU/OiBFeHRlbnNpb25TdGF0ZTsgZXZlbnQ/OiBMb2dFdmVudCB9O1xuICBpZiAobS50eXBlID09PSAnc3RhdGUtY2hhbmdlZCcgJiYgbS5zdGF0ZSkge1xuICAgIGxhc3RTdGF0ZSA9IG0uc3RhdGU7XG4gICAgcGFpbnQobS5zdGF0ZSk7XG4gIH0gZWxzZSBpZiAobS50eXBlID09PSAnbG9nLWV2ZW50JyAmJiBtLmV2ZW50KSB7XG4gICAgcHJlcGVuZEV2ZW50KG0uZXZlbnQpO1xuICB9XG59KTtcblxuZnVuY3Rpb24gcHJlcGVuZEV2ZW50KGV2OiBMb2dFdmVudCk6IHZvaWQge1xuICAvLyBJZiB0aGUgbGlzdCBpcyBzaG93aW5nIHRoZSBcImVtcHR5XCIgcGxhY2Vob2xkZXIsIGNsZWFyIGl0LlxuICBpZiAoYWN0aXZpdHlMaXN0LmZpcnN0RWxlbWVudENoaWxkPy5jbGFzc0xpc3QuY29udGFpbnMoJ2VtcHR5JykpIHtcbiAgICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIH1cbiAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xuICBjb25zdCB0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgdHMuY2xhc3NOYW1lID0gJ2V2LXRzJztcbiAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcbiAgY29uc3QgaWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgaWNvbi5jbGFzc05hbWUgPSAnZXYtaWNvbic7XG4gIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xuICBjb25zdCBib2R5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBjb25zdCBtc2cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xuICBtc2cudGV4dENvbnRlbnQgPSBldi5tc2c7XG4gIGJvZHkuYXBwZW5kKG1zZyk7XG4gIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcbiAgaWYgKGN0eEtleXMubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGN0eCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcbiAgICBjdHgudGV4dENvbnRlbnQgPSBjdHhLZXlzLm1hcCgoaykgPT4gYCR7a309JHtzdHJpbmdpZnlTaG9ydChldi5jb250ZXh0W2tdKX1gKS5qb2luKCcgXHUwMEI3ICcpO1xuICAgIGJvZHkuYXBwZW5kKGN0eCk7XG4gIH1cbiAgbGkuYXBwZW5kKHRzLCBpY29uLCBib2R5KTtcbiAgYWN0aXZpdHlMaXN0LnByZXBlbmQobGkpO1xuICB3aGlsZSAoYWN0aXZpdHlMaXN0LmNoaWxkRWxlbWVudENvdW50ID4gQUNUSVZJVFlfVEFJTF9NQVgpIHtcbiAgICBhY3Rpdml0eUxpc3QubGFzdEVsZW1lbnRDaGlsZD8ucmVtb3ZlKCk7XG4gIH1cbn1cblxuLy8gSW5pdGlhbCBwYWludC5cbnZvaWQgcmVmcmVzaFN0YXRlKCk7XG52b2lkIHJlZnJlc2hBY3Rpdml0eSgpO1xuXG4vLyBQZXJpb2RpY2FsbHkgcmUtZmV0Y2ggc3RhdGUgc28gXCJsYXN0IGNhcHR1cmVcIiB0aW1lcyBzdGF5IGZyZXNoLlxuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICB2b2lkIHJlZnJlc2hTdGF0ZSgpO1xufSwgMTVfMDAwKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7QUF5Rk8sSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLOzs7QUNqRnZELElBQU0sSUFBSSxDQUFzQyxPQUFrQjtBQUNoRSxRQUFNLEtBQUssU0FBUyxlQUFlLEVBQUU7QUFDckMsTUFBSSxDQUFDLEdBQUksT0FBTSxJQUFJLE1BQU0sb0JBQW9CLEVBQUUsRUFBRTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxJQUFNLFVBQVUsRUFBRSxVQUFVO0FBQzVCLElBQU0sV0FBVyxFQUFtQixXQUFXO0FBQy9DLElBQU0sY0FBYyxFQUFvQixjQUFjO0FBQ3RELElBQU0sZUFBZSxFQUFvQixlQUFlO0FBQ3hELElBQU0sYUFBYSxFQUFvQixjQUFjO0FBQ3JELElBQU0sZ0JBQWdCLEVBQXFCLGFBQWE7QUFDeEQsSUFBTSxpQkFBaUIsRUFBcUIsY0FBYztBQUMxRCxJQUFNLFdBQVcsRUFBcUIsV0FBVztBQUNqRCxJQUFNLGNBQWMsRUFBcUIsY0FBYztBQUN2RCxJQUFNLGFBQWEsRUFBcUIsYUFBYTtBQUNyRCxJQUFNLGNBQWMsRUFBcUIsZ0JBQWdCO0FBQ3pELElBQU0sZUFBZSxFQUFtQixhQUFhO0FBQ3JELElBQU0sZUFBZSxFQUFvQixlQUFlO0FBQ3hELElBQU0sY0FBYyxFQUFtQixjQUFjO0FBQ3JELElBQU0scUJBQXFCLEVBQW9CLHNCQUFzQjtBQUNyRSxJQUFNLG1CQUFtQixFQUFtQixrQkFBa0I7QUFDOUQsSUFBTSxtQkFBbUIsRUFBbUIsb0JBQW9CO0FBQ2hFLElBQU0scUJBQXFCLEVBQXFCLG1CQUFtQjtBQUNuRSxJQUFNLHNCQUFzQixFQUFxQixvQkFBb0I7QUFDckUsSUFBTSxxQkFBcUIsRUFBbUIsc0JBQXNCO0FBQ3BFLElBQU0saUJBQWlCLEVBQWUsaUJBQWlCO0FBQ3ZELElBQU0sZUFBZSxFQUFtQixlQUFlO0FBQ3ZELElBQU0sa0JBQWtCLEVBQXFCLGVBQWU7QUFDNUQsSUFBTSxtQkFBbUIsRUFBcUIsZ0JBQWdCO0FBQzlELElBQU0sa0JBQWtCLEVBQW1CLGtCQUFrQjtBQUM3RCxJQUFNLG9CQUFvQixFQUFlLHFCQUFxQjtBQUM5RCxJQUFNLGtCQUFrQixFQUFtQixtQkFBbUI7QUFDOUQsSUFBTSxxQkFBcUIsRUFBcUIsbUJBQW1CO0FBQ25FLElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLHFCQUFxQixFQUFtQixzQkFBc0I7QUFDcEUsSUFBTSxZQUFZLEVBQXFCLGlCQUFpQjtBQUV4RCxJQUFJLFlBQW1DO0FBRXZDLGVBQWUsS0FBUSxLQUFpQztBQUN0RCxTQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDeEM7QUFFQSxTQUFTLGNBQWMsT0FBNkI7QUFDbEQsUUFBTSxFQUFFLFlBQVksU0FBUyxJQUFJO0FBQ2pDLE1BQUksTUFBTTtBQUNWLE1BQUksT0FBTztBQUtYLFFBQU0sZ0JBQ0osV0FBVyxXQUFXLFFBQVEsU0FBUyxVQUFVLFdBQVcsMkJBQTJCO0FBQ3pGLE1BQUksQ0FBQyxTQUFTLFFBQVE7QUFDcEIsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsZUFBZTtBQUN4QixVQUFNO0FBQ04sV0FBTyxXQUFXLFNBQVMsTUFBTSx1QkFBdUIsU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLDRDQUF1QyxXQUFXLGlCQUFpQixRQUFRO0FBQUEsRUFDcEssV0FBVyxXQUFXLFdBQVcsTUFBTTtBQUNyQyxVQUFNO0FBQ04sV0FBTyxpQkFBaUIsV0FBVyxTQUFTLEdBQUcsT0FBTyxTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksZUFBTyxTQUFTLFNBQVM7QUFBQSxFQUNoSCxXQUFXLFdBQVcsV0FBVyxjQUFjO0FBQzdDLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLFdBQVcsV0FBVyxnQkFBZ0I7QUFDL0MsVUFBTTtBQUNOLFVBQU0sU0FBUyxrQkFBa0IsV0FBVyxnQkFBZ0I7QUFDNUQsV0FBTyxTQUNILHFDQUFnQyxNQUFNLEtBQ3RDO0FBQUEsRUFDTixXQUFXLFdBQVcsV0FBVyxpQkFBaUI7QUFDaEQsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsV0FBVyxXQUFXLGtCQUFrQjtBQUNqRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsT0FBTztBQUNMLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNBLFVBQVEsWUFBWSxPQUFPLEdBQUc7QUFDOUIsV0FBUyxjQUFjO0FBQ3ZCLFdBQVMsUUFBUSxXQUFXLFNBQVM7QUFDdkM7QUFFQSxTQUFTLE9BQU8sS0FBNEI7QUFDMUMsTUFBSSxDQUFDLElBQUssUUFBTztBQUNqQixRQUFNLElBQUksS0FBSyxNQUFNLEdBQUc7QUFDeEIsTUFBSSxDQUFDLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUNoQyxRQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSSxDQUFDO0FBQzVELE1BQUksT0FBTyxFQUFHLFFBQU87QUFDckIsTUFBSSxPQUFPLEdBQUksUUFBTyxHQUFHLElBQUk7QUFDN0IsUUFBTSxPQUFPLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDakMsTUFBSSxPQUFPLEdBQUksUUFBTyxHQUFHLElBQUk7QUFDN0IsUUFBTSxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDbEMsTUFBSSxRQUFRLEdBQUksUUFBTyxHQUFHLEtBQUs7QUFDL0IsUUFBTSxPQUFPLEtBQUssTUFBTSxRQUFRLEVBQUU7QUFDbEMsU0FBTyxHQUFHLElBQUk7QUFDaEI7QUFFQSxTQUFTLGtCQUFrQixVQUFpQztBQUMxRCxNQUFJLGFBQWEsS0FBTSxRQUFPO0FBQzlCLFFBQU0sV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQ3hELE1BQUksWUFBWSxFQUFHLFFBQU87QUFDMUIsUUFBTSxZQUFZLElBQUksS0FBSyxXQUFXLEdBQUksRUFBRSxtQkFBbUIsQ0FBQyxHQUFHO0FBQUEsSUFDakUsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNELE1BQUksV0FBVyxHQUFJLFFBQU8sTUFBTSxRQUFRLE1BQU0sU0FBUztBQUN2RCxRQUFNLE9BQU8sS0FBSyxNQUFNLFdBQVcsRUFBRTtBQUNyQyxNQUFJLE9BQU8sR0FBSSxRQUFPLE1BQU0sSUFBSSxNQUFNLFNBQVM7QUFDL0MsUUFBTSxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDbEMsU0FBTyxNQUFNLEtBQUssTUFBTSxTQUFTO0FBQ25DO0FBRUEsU0FBUyxPQUFPLEdBQW1CO0FBQ2pDLFNBQU8sRUFBRSxlQUFlLE9BQU87QUFDakM7QUFFQSxTQUFTLGVBQWUsT0FBNkI7QUFDbkQsY0FBWSxnQkFBZ0I7QUFDNUIsTUFBSSxNQUFNLFNBQVMsV0FBVyxHQUFHO0FBQy9CLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsZ0JBQVksT0FBTyxFQUFFO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLGFBQVcsS0FBSyxNQUFNLFVBQVU7QUFDOUIsVUFBTSxJQUFJLE1BQU0sU0FBUyxFQUFFLE1BQU07QUFDakMsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxLQUFLLEVBQUUsZ0JBQWdCLElBQUksZ0JBQWdCO0FBRTFELFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsVUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0FBQzVDLFdBQU8sWUFBWTtBQUNuQixXQUFPLFlBQVksNEJBQTRCLFdBQVcsRUFBRSxNQUFNLENBQUM7QUFDbkUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsRUFBRTtBQUNyQixTQUFLLE9BQU8sUUFBUSxJQUFJO0FBRXhCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsVUFBTSxRQUFRLFNBQVMsY0FBYyxNQUFNO0FBQzNDLFVBQU0sWUFBWTtBQUNsQixVQUFNLFFBQVEsR0FBRyxjQUFjO0FBQy9CLFVBQU0sV0FBVyxHQUFHLGlCQUFpQjtBQUNyQyxVQUFNLE9BQU8sR0FBRyxpQkFBaUI7QUFDakMsVUFBTSxZQUNKLHFCQUFxQixPQUFPLEtBQUssQ0FBQyxtQkFDakMsV0FBVyxJQUFJLDJCQUF3QixPQUFPLFFBQVEsQ0FBQyxxQkFBcUIsTUFDN0UsY0FBVyxXQUFXLE9BQU8sSUFBSSxDQUFDLENBQUM7QUFFckMsVUFBTSxVQUFVLFNBQVMsY0FBYyxNQUFNO0FBQzdDLFlBQVEsWUFBWTtBQUNwQixVQUFNLE1BQU0sU0FBUyxjQUFjLFFBQVE7QUFDM0MsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYztBQUNsQixRQUFJLGlCQUFpQixTQUFTLFlBQVk7QUFDeEMsVUFBSSxXQUFXO0FBQ2YsVUFBSTtBQUNGLGNBQU0sS0FBSyxFQUFFLE1BQU0sZUFBZSxRQUFRLEVBQUUsT0FBTyxDQUFDO0FBQUEsTUFDdEQsVUFBRTtBQUNBLFlBQUksV0FBVztBQUFBLE1BQ2pCO0FBQUEsSUFDRixDQUFDO0FBQ0QsWUFBUSxPQUFPLEdBQUc7QUFFbEIsUUFBSSxPQUFPLE9BQU8sT0FBTztBQUN6QixPQUFHLE9BQU8sTUFBTSxHQUFHO0FBQ25CLGdCQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsUUFBMEI7QUFDaEQsZUFBYSxnQkFBZ0I7QUFDN0IsTUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLGlCQUFhLE9BQU8sRUFBRTtBQUN0QjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLE1BQU0sT0FBTyxNQUFNLEdBQUcsaUJBQWlCLEdBQUc7QUFDbkQsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixVQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsR0FBRztBQUNyQixTQUFLLE9BQU8sR0FBRztBQUNmLFVBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLFFBQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsWUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFVBQUksWUFBWTtBQUNoQixVQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFdBQUssT0FBTyxHQUFHO0FBQUEsSUFDakI7QUFDQSxPQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsaUJBQWEsT0FBTyxFQUFFO0FBQUEsRUFDeEI7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUFvQjtBQUMxQyxNQUFJLE1BQU0sS0FBTSxRQUFPO0FBQ3ZCLE1BQUksT0FBTyxNQUFNLFNBQVUsUUFBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQ3pFLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFVBQVcsUUFBTyxPQUFPLENBQUM7QUFDcEUsTUFBSTtBQUNGLFVBQU0sSUFBSSxLQUFLLFVBQVUsQ0FBQztBQUMxQixXQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFBQSxFQUNoRCxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsV0FBVyxHQUFtQjtBQUNyQyxTQUFPLEVBQUU7QUFBQSxJQUFRO0FBQUEsSUFBWSxDQUFDLE1BQzVCLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxXQUFXO0FBQUEsRUFDekY7QUFDRjtBQUVBLGVBQWUsZUFBOEI7QUFDM0MsTUFBSTtBQUNGLGdCQUFZLE1BQU0sS0FBcUIsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUM1RCxVQUFNLFNBQVM7QUFBQSxFQUNqQixTQUFTLEtBQUs7QUFDWixZQUFRLEtBQUssNkNBQTZDLEdBQUc7QUFBQSxFQUMvRDtBQUNGO0FBRUEsU0FBUyxNQUFNLE9BQTZCO0FBQzFDLGVBQWEsY0FBYyxNQUFNO0FBQ2pDLGdCQUFjLEtBQUs7QUFDbkIsYUFBVyxVQUFVLE1BQU0sU0FBUztBQUNwQyxhQUFXLE9BQU8sV0FBVyxNQUFNLFNBQVMsS0FBSyxjQUFjLE1BQU0sU0FBUyxJQUFJO0FBQ2xGLG9CQUFrQixLQUFLO0FBQ3ZCLGlCQUFlLEtBQUs7QUFDcEIsa0JBQWdCLEtBQUs7QUFDckIsa0JBQWdCLEtBQUs7QUFDckIsZUFBYSxLQUFLO0FBQ3BCO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsb0JBQWtCLFNBQVMsVUFBVSxLQUFLLENBQUM7QUFDM0Msa0JBQWdCLGNBQ2QsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELHFCQUFtQixTQUFTO0FBQzVCLHFCQUFtQixXQUFXLFVBQVU7QUFDeEMsc0JBQW9CLFNBQVMsQ0FBQztBQUM5QixxQkFBbUIsb0JBQW9CLENBQUM7QUFDMUM7QUFFQSxTQUFTLG1CQUNQLElBQ0EsR0FDTTtBQUNOLE1BQUksQ0FBQyxFQUFFLFdBQVcsRUFBRSxjQUFjLEdBQUc7QUFDbkMsT0FBRyxTQUFTO0FBQ1o7QUFBQSxFQUNGO0FBR0EsUUFBTSxRQUFRLEtBQUssSUFBSSxFQUFFLGdCQUFnQixFQUFFLFlBQVksRUFBRSxLQUFLO0FBQzlELEtBQUcsU0FBUztBQUNaLEtBQUcsY0FBYyxHQUFHLE9BQU8sRUFBRSxTQUFTLENBQUMsTUFBTSxPQUFPLEtBQUssQ0FBQztBQUMxRCxLQUFHLFlBQVksRUFBRSxVQUFVLGdCQUFnQjtBQUM3QztBQUVBLFNBQVMsa0JBQWtCLE9BQTZCO0FBQ3RELFFBQU0sS0FBSyxNQUFNLFNBQVMsWUFBWTtBQUN0QyxlQUFhLFVBQVU7QUFDdkIsY0FBWSxjQUFjLEtBQUssT0FBTztBQUN0QyxXQUFTLEtBQUssVUFBVSxPQUFPLFVBQVUsQ0FBQyxFQUFFO0FBQzlDO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxPQUFPLE1BQU0sU0FBUztBQUM1QixxQkFBbUIsUUFBUSxPQUFPLElBQUk7QUFDdEMsbUJBQWlCLGNBQWMsT0FBTyxJQUFJO0FBQzFDLFFBQU0sS0FBSyxNQUFNO0FBQ2pCLHFCQUFtQixTQUFTLEdBQUc7QUFDL0Isc0JBQW9CLFNBQVMsQ0FBQyxHQUFHO0FBQ2pDLE1BQUksR0FBRyxRQUFRO0FBQ2IsVUFBTSxJQUFJLEdBQUc7QUFDYixxQkFBaUIsY0FDZixNQUFNLElBQUksa0NBQTZCLGtCQUFhLENBQUMsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNO0FBQ25GLHFCQUFpQixZQUFZO0FBQUEsRUFDL0IsT0FBTztBQUNMLHFCQUFpQixjQUFjO0FBQy9CLHFCQUFpQixZQUFZO0FBQUEsRUFDL0I7QUFDQSxNQUFJLEdBQUcsVUFBVSxHQUFHLGNBQWMsS0FBSyxHQUFHLGdCQUFnQixHQUFHO0FBQzNELHVCQUFtQixTQUFTO0FBQzVCLHVCQUFtQixjQUNqQixHQUFHLE9BQU8sR0FBRyxXQUFXLENBQUMsaUJBQ3RCLE9BQU8sR0FBRyxhQUFhLENBQUMseUJBQ3hCLE9BQU8sR0FBRyxhQUFhLENBQUM7QUFDN0IsdUJBQW1CLFlBQVksR0FBRyxTQUFTLGdCQUFnQjtBQUFBLEVBQzdELE9BQU87QUFDTCx1QkFBbUIsU0FBUztBQUFBLEVBQzlCO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsT0FBNkI7QUFDakQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsaUJBQWUsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUN4QyxlQUFhLGNBQ1gsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELGtCQUFnQixTQUFTO0FBQ3pCLGtCQUFnQixXQUFXLFVBQVU7QUFDckMsbUJBQWlCLFNBQVMsQ0FBQztBQUMzQixxQkFBbUIsaUJBQWlCLENBQUM7QUFDdkM7QUFFQSxlQUFlLGtCQUFpQztBQUc5QyxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLFVBQVU7QUFDekQsUUFBTSxTQUFVLE9BQU8sWUFBdUMsQ0FBQztBQUMvRCxpQkFBZSxNQUFNO0FBQ3ZCO0FBSUEsY0FBYyxpQkFBaUIsU0FBUyxZQUFZO0FBQ2xELGdCQUFjLFdBQVc7QUFDekIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQUEsRUFDcEMsVUFBRTtBQUNBLGtCQUFjLFdBQVc7QUFBQSxFQUMzQjtBQUNGLENBQUM7QUFFRCxlQUFlLGlCQUFpQixTQUFTLFlBQVk7QUFDbkQsaUJBQWUsV0FBVztBQUMxQixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUFBLEVBQzFDLFVBQUU7QUFDQSxtQkFBZSxXQUFXO0FBQUEsRUFDNUI7QUFDRixDQUFDO0FBRUQsU0FBUyxpQkFBaUIsU0FBUyxZQUFZO0FBQzdDLFdBQVMsV0FBVztBQUNwQixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFBQSxFQUNsQyxVQUFFO0FBQ0EsYUFBUyxXQUFXO0FBQUEsRUFDdEI7QUFDRixDQUFDO0FBRUQsV0FBVyxpQkFBaUIsVUFBVSxNQUFNO0FBQzFDLE9BQUssS0FBSyxFQUFFLE1BQU0sdUJBQXVCLElBQUksV0FBVyxRQUFRLENBQUM7QUFDbkUsQ0FBQztBQUVELGFBQWEsaUJBQWlCLFVBQVUsTUFBTTtBQUM1QyxPQUFLLEtBQUssRUFBRSxNQUFNLGtCQUFrQixJQUFJLGFBQWEsUUFBUSxDQUFDO0FBQ2hFLENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxxQkFBbUIsV0FBVztBQUM5QixPQUFLLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3JELHVCQUFtQixXQUFXO0FBQUEsRUFDaEMsQ0FBQztBQUNILENBQUM7QUFDRCxvQkFBb0IsaUJBQWlCLFNBQVMsTUFBTTtBQUNsRCxzQkFBb0IsV0FBVztBQUMvQixPQUFLLEtBQUssRUFBRSxNQUFNLHFCQUFxQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3RELHdCQUFvQixXQUFXO0FBQUEsRUFDakMsQ0FBQztBQUNILENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxtQkFBaUIsY0FBYyxtQkFBbUI7QUFDcEQsQ0FBQztBQUNELG1CQUFtQixpQkFBaUIsVUFBVSxNQUFNO0FBQ2xELFFBQU0sVUFBVSxPQUFPLG1CQUFtQixLQUFLO0FBQy9DLE1BQUksT0FBTyxTQUFTLE9BQU8sR0FBRztBQUM1QixTQUFLLEtBQUssRUFBRSxNQUFNLDRCQUE0QixRQUFRLENBQUM7QUFBQSxFQUN6RDtBQUNGLENBQUM7QUFFRCxVQUFVLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNoRCxJQUFFLGVBQWU7QUFDakIsUUFBTSxLQUFLLE9BQU87QUFBQSxJQUNoQjtBQUFBLEVBR0Y7QUFDQSxNQUFJLENBQUMsR0FBSTtBQUNULE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFDdkMsQ0FBQztBQUVELGdCQUFnQixpQkFBaUIsU0FBUyxNQUFNO0FBQzlDLGtCQUFnQixXQUFXO0FBQzNCLE9BQUssS0FBSyxFQUFFLE1BQU0sZ0JBQWdCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDakQsb0JBQWdCLFdBQVc7QUFBQSxFQUM3QixDQUFDO0FBQ0gsQ0FBQztBQUVELGlCQUFpQixpQkFBaUIsU0FBUyxNQUFNO0FBQy9DLG1CQUFpQixXQUFXO0FBQzVCLE9BQUssS0FBSyxFQUFFLE1BQU0saUJBQWlCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDbEQscUJBQWlCLFdBQVc7QUFBQSxFQUM5QixDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2xELElBQUUsZUFBZTtBQUNqQixPQUFLLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNwQyxDQUFDO0FBRUQsV0FBVyxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDakQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQ25DLENBQUM7QUFFRCxZQUFZLGlCQUFpQixTQUFTLFlBQVk7QUFDaEQsUUFBTSxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNyQyxpQkFBZSxDQUFDLENBQUM7QUFDbkIsQ0FBQztBQUVELFFBQVEsUUFBUSxVQUFVLFlBQVksQ0FBQyxRQUFpQjtBQUN0RCxNQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsU0FBVTtBQUNyQyxRQUFNLElBQUk7QUFDVixNQUFJLEVBQUUsU0FBUyxtQkFBbUIsRUFBRSxPQUFPO0FBQ3pDLGdCQUFZLEVBQUU7QUFDZCxVQUFNLEVBQUUsS0FBSztBQUFBLEVBQ2YsV0FBVyxFQUFFLFNBQVMsZUFBZSxFQUFFLE9BQU87QUFDNUMsaUJBQWEsRUFBRSxLQUFLO0FBQUEsRUFDdEI7QUFDRixDQUFDO0FBRUQsU0FBUyxhQUFhLElBQW9CO0FBRXhDLE1BQUksYUFBYSxtQkFBbUIsVUFBVSxTQUFTLE9BQU8sR0FBRztBQUMvRCxpQkFBYSxnQkFBZ0I7QUFBQSxFQUMvQjtBQUNBLFFBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxLQUFHLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDN0IsUUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQ3hDLEtBQUcsWUFBWTtBQUNmLEtBQUcsY0FBYyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUM5RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsT0FBSyxZQUFZO0FBQ2pCLE9BQUssY0FBYyxHQUFHLFVBQVUsVUFBVSxXQUFNLEdBQUcsVUFBVSxTQUFTLE1BQU07QUFDNUUsUUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFFBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxNQUFJLFlBQVk7QUFDaEIsTUFBSSxjQUFjLEdBQUc7QUFDckIsT0FBSyxPQUFPLEdBQUc7QUFDZixRQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTztBQUN0QyxNQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssUUFBSztBQUN4RixTQUFLLE9BQU8sR0FBRztBQUFBLEVBQ2pCO0FBQ0EsS0FBRyxPQUFPLElBQUksTUFBTSxJQUFJO0FBQ3hCLGVBQWEsUUFBUSxFQUFFO0FBQ3ZCLFNBQU8sYUFBYSxvQkFBb0IsbUJBQW1CO0FBQ3pELGlCQUFhLGtCQUFrQixPQUFPO0FBQUEsRUFDeEM7QUFDRjtBQUdBLEtBQUssYUFBYTtBQUNsQixLQUFLLGdCQUFnQjtBQUdyQixZQUFZLE1BQU07QUFDaEIsT0FBSyxhQUFhO0FBQ3BCLEdBQUcsSUFBTTsiLAogICJuYW1lcyI6IFtdCn0K
