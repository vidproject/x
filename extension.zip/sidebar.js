// extension/src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// extension/src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var updateExistingToggle = $("update-existing");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = `Auth error \u2014 check your PAT`;
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  updateExistingToggle.checked = state.settings.updateExisting !== false;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    autoScrollProgress.textContent = `${fmtNum(as.scrollCount)} scrolls \xB7 ${fmtNum(as.ingestedCount)} tweets ingested \xB7 ${fmtNum(as.expandedCount)} expanded`;
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
updateExistingToggle.addEventListener("change", () => {
  void send({ type: "toggle-update-existing", on: updateExistingToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgZW5hYmxlZDogdHJ1ZSxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxuICB1cGRhdGVFeGlzdGluZzogdHJ1ZSxcbn07XG5cbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XG5cbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1JhcGlkUmVzcG9uc2U0NycsIGxhYmVsOiAnUmFwaWQgUmVzcG9uc2UgNDcnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG5dO1xuXG4vLyBHcmFwaFFMIGVuZHBvaW50IG5hbWVzIHdlIGNhcmUgYWJvdXQgKG1hdGNoZWQgYnkgc3Vic3RyaW5nIGFnYWluc3QgVVJMIHBhdGgpLlxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG4gICdMaWtlcycsXG4gICdCb29rbWFya3MnLFxuICAnSG9tZVRpbWVsaW5lJyxcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXG4gICdTZWFyY2hUaW1lbGluZScsXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxuXSk7XG5cbi8vIEVuZHBvaW50cyB0aGF0IGNhcnJ5IENvbW11bml0eSBOb3RlIGJvZGllcyBcdTIwMTQgY2FwdHVyZWQgZm9yIGNvbXBsZXRlbmVzcyBidXRcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXG5leHBvcnQgY29uc3QgQklSRFdBVENIX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnQmlyZHdhdGNoRmV0Y2hPbmVOb3RlJyxcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxuXSk7XG5cbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxuLy8gdG8gbGVhcm4gYWNjb3VudF9pZCA8LT4gaGFuZGxlIGJpbmRpbmdzKS5cbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcblxuLy8gRW5kcG9pbnRzIHdob3NlIHJlc3BvbnNlcyBhcmUgc2NvcGVkIHRvIGEgcGFydGljdWxhciBhY2NvdW50IG9yXG4vLyBjb252ZXJzYXRpb24gXHUyMDE0IGkuZS4gdmlzaXRpbmcgYC88aGFuZGxlPmAgLyBgLzxoYW5kbGU+L3dpdGhfcmVwbGllc2AsXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcbi8vIGVpdGhlciBhdXRob3JlZCBieSB0aGUgdHJhY2tlZCBhY2NvdW50IG9yIGRpcmVjdGx5IHJlZmVyZW5jZWQgYnkgdGhlbVxuLy8gKHJldHdlZXRlZCwgcXVvdGVkLCByZXBsaWVkIHRvKSwgc28gd2Uga2VlcCBldmVyeXRoaW5nIHdlIHNlZSByYXRoZXJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcbi8vIGFjY291bnQgc3RpbGwgZ2V0cyBpdHMgb3JpZ2luYWwtdHdlZXQgY29udGVudCBhcmNoaXZlZC5cbi8vXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcbi8vIHN0aWxsIGdldCBmaWx0ZXJlZCB0byB0cmFja2VkLWhhbmRsZSBhdXRob3JzIFx1MjAxNCBzZWUgdGhlIHNwZWMnc1xuLy8gXCJCcm93c2luZyBteSBob21lIHRpbWVsaW5lIGlzIGlnbm9yZWRcIiBydWxlLlxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuXSk7XG5cbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxuZXhwb3J0IGNvbnN0IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCA9IDIwMDtcblxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxuZXhwb3J0IGNvbnN0IEZMVVNIX0lETEVfTVMgPSA0NV8wMDA7XG5cbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxuZXhwb3J0IGNvbnN0IEZMVVNIX0FMQVJNX01JTlVURVMgPSAxO1xuXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXG5leHBvcnQgY29uc3QgQUNUSVZJVFlfVEFJTF9NQVggPSAyNTA7XG5cbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cbmV4cG9ydCBjb25zdCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyA9IDEwICogNjAgKiAxMDAwO1xuXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcbiIsICIvKipcbiAqIHNpZGViYXIudHMgXHUyMDE0IFVJIGZvciB0aGUgcGVyc2lzdGVudCBzaWRlYmFyLlxuICpcbiAqIFNpZGViYXJzIGluIEZpcmVmb3ggc3RheSBvcGVuIGFjcm9zcyB0YWIvd2luZG93IHN3aXRjaGVzLCB3aGljaCBpcyB0aGVcbiAqIGludGVuZGVkIHBlcnNpc3RlbmNlIG1vZGVsLiBUaGlzIG1vZHVsZSByZW5kZXJzIHN0YXRlIHB1c2hlZCBmcm9tIHRoZVxuICogYmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciBhbmQgZm9yd2FyZHMgdXNlciBjb21tYW5kcyBiYWNrLlxuICovXG5cbmltcG9ydCB7IEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcbmltcG9ydCB0eXBlIHsgRXh0ZW5zaW9uU3RhdGUsIExvZ0V2ZW50LCBSdW50aW1lTWVzc2FnZSB9IGZyb20gJy4vbGliL3R5cGVzLmpzJztcblxuY29uc3QgJCA9IDxUIGV4dGVuZHMgSFRNTEVsZW1lbnQgPSBIVE1MRWxlbWVudD4oaWQ6IHN0cmluZyk6IFQgPT4ge1xuICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcbiAgaWYgKCFlbCkgdGhyb3cgbmV3IEVycm9yKGBtaXNzaW5nIGVsZW1lbnQgIyR7aWR9YCk7XG4gIHJldHVybiBlbCBhcyBUO1xufTtcblxuY29uc3QgY29ubkRvdCA9ICQoJ2Nvbm4tZG90Jyk7XG5jb25zdCBjb25uVGV4dCA9ICQ8SFRNTFNwYW5FbGVtZW50PignY29ubi10ZXh0Jyk7XG5jb25zdCBhY2NvdW50TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjY291bnQtbGlzdCcpO1xuY29uc3QgYWN0aXZpdHlMaXN0ID0gJDxIVE1MVUxpc3RFbGVtZW50PignYWN0aXZpdHktbGlzdCcpO1xuY29uc3QgYXV0b1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tY2FwdHVyZScpO1xuY29uc3QgdXBkYXRlRXhpc3RpbmdUb2dnbGUgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCd1cGRhdGUtZXhpc3RpbmcnKTtcbmNvbnN0IGNhcHR1cmVBbGxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2FwdHVyZS1hbGwnKTtcbmNvbnN0IGNhcHR1cmVUaGlzQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NhcHR1cmUtdGhpcycpO1xuY29uc3QgZmx1c2hCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignZmx1c2gtYWxsJyk7XG5jb25zdCBvcHRpb25zTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdvcGVuLW9wdGlvbnMnKTtcbmNvbnN0IHZpZXdlckxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50Pignb3Blbi12aWV3ZXInKTtcbmNvbnN0IGNsZWFyQWN0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NsZWFyLWFjdGl2aXR5Jyk7XG5jb25zdCBleHRWZXJzaW9uRWwgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2V4dC12ZXJzaW9uJyk7XG5jb25zdCBtYXN0ZXJTd2l0Y2ggPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdtYXN0ZXItc3dpdGNoJyk7XG5jb25zdCBtYXN0ZXJMYWJlbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignbWFzdGVyLWxhYmVsJyk7XG5jb25zdCBhdXRvU2Nyb2xsSW50ZXJ2YWwgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1pbnRlcnZhbCcpO1xuY29uc3QgYXV0b1Njcm9sbFNlY3NFbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc2VjcycpO1xuY29uc3QgYXV0b1Njcm9sbFN0YXR1cyA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtc3RhdHVzJyk7XG5jb25zdCBhdXRvU2Nyb2xsU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtc3RhcnQnKTtcbmNvbnN0IGF1dG9TY3JvbGxDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignYXV0by1zY3JvbGwtY2FuY2VsJyk7XG5jb25zdCBhdXRvU2Nyb2xsUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2F1dG8tc2Nyb2xsLXByb2dyZXNzJyk7XG5jb25zdCByZWZldGNoU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCdyZWZldGNoLXNlY3Rpb24nKTtcbmNvbnN0IHJlZmV0Y2hDb3VudCA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1jb3VudCcpO1xuY29uc3QgcmVmZXRjaFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ3JlZmV0Y2gtc3RhcnQnKTtcbmNvbnN0IHJlZmV0Y2hDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1jYW5jZWwnKTtcbmNvbnN0IHJlZmV0Y2hQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PigncmVmZXRjaC1wcm9ncmVzcycpO1xuY29uc3QgbWVkaWFDcmF3bFNlY3Rpb24gPSAkPEhUTUxFbGVtZW50PignbWVkaWEtY3Jhd2wtc2VjdGlvbicpO1xuY29uc3QgbWVkaWFDcmF3bENvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1jb3VudCcpO1xuY29uc3QgbWVkaWFDcmF3bFN0YXJ0QnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLXN0YXJ0Jyk7XG5jb25zdCBtZWRpYUNyYXdsQ2FuY2VsQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ21lZGlhLWNyYXdsLWNhbmNlbCcpO1xuY29uc3QgbWVkaWFDcmF3bFByb2dyZXNzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1wcm9ncmVzcycpO1xuY29uc3QgcHVyZ2VMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ3B1cmdlLXVucmVsYXRlZCcpO1xuXG5sZXQgbGFzdFN0YXRlOiBFeHRlbnNpb25TdGF0ZSB8IG51bGwgPSBudWxsO1xuXG5hc3luYyBmdW5jdGlvbiBzZW5kPFQ+KG1zZzogUnVudGltZU1lc3NhZ2UpOiBQcm9taXNlPFQ+IHtcbiAgcmV0dXJuIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZShtc2cpIGFzIFByb21pc2U8VD47XG59XG5cbmZ1bmN0aW9uIHNldENvbm5TdGF0dXMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHsgY29ubmVjdGlvbiwgc2V0dGluZ3MgfSA9IHN0YXRlO1xuICBsZXQgY2xzID0gJyc7XG4gIGxldCB0ZXh0ID0gJyc7XG4gIC8vIE9ubHkgd2FybiB3aGVuIHRoZSBjb25maWd1cmVkIGJyYW5jaCBnZW51aW5lbHkgZG9lc24ndCBleGlzdCBvbiB0aGVcbiAgLy8gcmVtb3RlLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCB0aGF0IGV4aXN0cyBpcyBmaW5lIFx1MjAxNCBjYXB0dXJpbmcgaW50byBhXG4gIC8vIHdvcmtpbmcgYnJhbmNoIGlzIHJvdXRpbmUgXHUyMDE0IHNvIHRoZSBtZXJlIGAhPT1gIHRvIGRlZmF1bHRfYnJhbmNoIGlzIG5vdFxuICAvLyBhIHByb2JsZW0gYW5kIHNob3VsZG4ndCBzaG91dCBpbiB0aGUgaGVhZGVyLlxuICBjb25zdCBicmFuY2hNaXNzaW5nID1cbiAgICBjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ29rJyAmJiBzZXR0aW5ncy5icmFuY2ggJiYgY29ubmVjdGlvbi5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSBmYWxzZTtcbiAgaWYgKCFzZXR0aW5ncy5wYXRTZXQpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XG4gIH0gZWxzZSBpZiAoYnJhbmNoTWlzc2luZykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSBgQnJhbmNoIFwiJHtzZXR0aW5ncy5icmFuY2h9XCIgZG9lcyBub3QgZXhpc3Qgb24gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTIwMTQgY29tbWl0cyB3aWxsIDQyMi4gU2V0IGJyYW5jaCB0byBcIiR7Y29ubmVjdGlvbi5kZWZhdWx0QnJhbmNoID8/ICdtYXN0ZXInfVwiIGluIFNldHRpbmdzLmA7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycpIHtcbiAgICBjbHMgPSAnb2snO1xuICAgIHRleHQgPSBgQ29ubmVjdGVkIGFzIEAke2Nvbm5lY3Rpb24ubG9naW4gPz8gJz8nfSB0byAke3NldHRpbmdzLm93bmVyfS8ke3NldHRpbmdzLnJlcG99IFx1MDBCNyBcdTIwMjYke3NldHRpbmdzLnBhdFN1ZmZpeH1gO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnYXV0aC1lcnJvcicpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gYEF1dGggZXJyb3IgXHUyMDE0IGNoZWNrIHlvdXIgUEFUYDtcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgY29uc3QgcmVzZXRzID0gZm10UmF0ZUxpbWl0UmVzZXQoY29ubmVjdGlvbi5yYXRlTGltaXRSZXNldEF0KTtcbiAgICB0ZXh0ID0gcmVzZXRzXG4gICAgICA/IGBHaXRIdWIgcmF0ZS1saW1pdGVkIFx1MjAxNCByZXNldHMgJHtyZXNldHN9YFxuICAgICAgOiAnR2l0SHViIHJhdGUtbGltaXRlZCBcdTIwMTQgY2FwdHVyZXMgd2lsbCByZXRyeSc7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICduZXR3b3JrLWVycm9yJykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSAnTmV0d29yayBlcnJvciBcdTIwMTQgY2hlY2sgY29ubmVjdGl2aXR5JztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ25vdC1jb25maWd1cmVkJykge1xuICAgIGNscyA9ICd3YXJuJztcbiAgICB0ZXh0ID0gJ05vdCBjb25maWd1cmVkIFx1MjAxNCBvcGVuIFNldHRpbmdzJztcbiAgfSBlbHNlIHtcbiAgICBjbHMgPSAnJztcbiAgICB0ZXh0ID0gJ0NoZWNraW5nXHUyMDI2JztcbiAgfVxuICBjb25uRG90LmNsYXNzTmFtZSA9IGBkb3QgJHtjbHN9YDtcbiAgY29ublRleHQudGV4dENvbnRlbnQgPSB0ZXh0O1xuICBjb25uVGV4dC50aXRsZSA9IGNvbm5lY3Rpb24uZXJyb3IgPz8gJyc7XG59XG5cbmZ1bmN0aW9uIGZtdFJlbChpc286IHN0cmluZyB8IG51bGwpOiBzdHJpbmcge1xuICBpZiAoIWlzbykgcmV0dXJuICdcdTIwMTQnO1xuICBjb25zdCBkID0gRGF0ZS5wYXJzZShpc28pO1xuICBpZiAoIU51bWJlci5pc0Zpbml0ZShkKSkgcmV0dXJuICdcdTIwMTQnO1xuICBjb25zdCBzZWNzID0gTWF0aC5tYXgoMCwgTWF0aC5yb3VuZCgoRGF0ZS5ub3coKSAtIGQpIC8gMTAwMCkpO1xuICBpZiAoc2VjcyA8IDUpIHJldHVybiAnanVzdCBub3cnO1xuICBpZiAoc2VjcyA8IDYwKSByZXR1cm4gYCR7c2Vjc31zIGFnb2A7XG4gIGNvbnN0IG1pbnMgPSBNYXRoLnJvdW5kKHNlY3MgLyA2MCk7XG4gIGlmIChtaW5zIDwgNjApIHJldHVybiBgJHttaW5zfW0gYWdvYDtcbiAgY29uc3QgaG91cnMgPSBNYXRoLnJvdW5kKG1pbnMgLyA2MCk7XG4gIGlmIChob3VycyA8IDI0KSByZXR1cm4gYCR7aG91cnN9aCBhZ29gO1xuICBjb25zdCBkYXlzID0gTWF0aC5yb3VuZChob3VycyAvIDI0KTtcbiAgcmV0dXJuIGAke2RheXN9ZCBhZ29gO1xufVxuXG5mdW5jdGlvbiBmbXRSYXRlTGltaXRSZXNldChlcG9jaFNlYzogbnVtYmVyIHwgbnVsbCk6IHN0cmluZyB7XG4gIGlmIChlcG9jaFNlYyA9PT0gbnVsbCkgcmV0dXJuICcnO1xuICBjb25zdCBkZWx0YVNlYyA9IGVwb2NoU2VjIC0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gIGlmIChkZWx0YVNlYyA8PSAwKSByZXR1cm4gJ21vbWVudGFyaWx5JztcbiAgY29uc3Qgd2FsbENsb2NrID0gbmV3IERhdGUoZXBvY2hTZWMgKiAxMDAwKS50b0xvY2FsZVRpbWVTdHJpbmcoW10sIHtcbiAgICBob3VyOiAnMi1kaWdpdCcsXG4gICAgbWludXRlOiAnMi1kaWdpdCcsXG4gIH0pO1xuICBpZiAoZGVsdGFTZWMgPCA2MCkgcmV0dXJuIGBpbiAke2RlbHRhU2VjfXMgKCR7d2FsbENsb2NrfSlgO1xuICBjb25zdCBtaW5zID0gTWF0aC5yb3VuZChkZWx0YVNlYyAvIDYwKTtcbiAgaWYgKG1pbnMgPCA2MCkgcmV0dXJuIGBpbiAke21pbnN9bSAoJHt3YWxsQ2xvY2t9KWA7XG4gIGNvbnN0IGhvdXJzID0gTWF0aC5yb3VuZChtaW5zIC8gNjApO1xuICByZXR1cm4gYGluICR7aG91cnN9aCAoJHt3YWxsQ2xvY2t9KWA7XG59XG5cbmZ1bmN0aW9uIGZtdE51bShuOiBudW1iZXIpOiBzdHJpbmcge1xuICByZXR1cm4gbi50b0xvY2FsZVN0cmluZygnZW4tVVMnKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQWNjb3VudHMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGFjY291bnRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBpZiAoc3RhdGUuYWNjb3VudHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWNjb3VudHMgY29uZmlndXJlZC4nO1xuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3QgYSBvZiBzdGF0ZS5hY2NvdW50cykge1xuICAgIGNvbnN0IGMgPSBzdGF0ZS5jb3VudGVyc1thLmhhbmRsZV07XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9IGMgJiYgYy5idWZmZXJlZENvdW50ID4gMCA/ICdhY2MgcGVuZGluZycgOiAnYWNjJztcblxuICAgIGNvbnN0IGhlYWQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBoZWFkLmNsYXNzTmFtZSA9ICdhY2MtaGVhZCc7XG4gICAgY29uc3QgaGFuZGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGhhbmRsZS5jbGFzc05hbWUgPSAnYWNjLWhhbmRsZSc7XG4gICAgaGFuZGxlLmlubmVySFRNTCA9IGA8c3BhbiBjbGFzcz1cImF0XCI+QDwvc3Bhbj4ke2VzY2FwZUh0bWwoYS5oYW5kbGUpfWA7XG4gICAgY29uc3QgbWV0YSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBtZXRhLmNsYXNzTmFtZSA9ICdhY2MtbWV0YSc7XG4gICAgbWV0YS50ZXh0Q29udGVudCA9IGEubGFiZWw7XG4gICAgaGVhZC5hcHBlbmQoaGFuZGxlLCBtZXRhKTtcblxuICAgIGNvbnN0IHJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHJvdy5jbGFzc05hbWUgPSAnYWNjLXJvdyc7XG4gICAgY29uc3Qgc3RhdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgc3RhdHMuY2xhc3NOYW1lID0gJ2FjYy1zdGF0cyc7XG4gICAgY29uc3QgdG9kYXkgPSBjPy50b2RheUNvdW50ID8/IDA7XG4gICAgY29uc3QgYnVmZmVyZWQgPSBjPy5idWZmZXJlZENvdW50ID8/IDA7XG4gICAgY29uc3QgbGFzdCA9IGM/Lmxhc3RDYXB0dXJlQXQgPz8gbnVsbDtcbiAgICBzdGF0cy5pbm5lckhUTUwgPVxuICAgICAgYDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0odG9kYXkpfTwvc3Bhbj4gdG9kYXlgICtcbiAgICAgIChidWZmZXJlZCA+IDAgPyBgIFx1MDBCNyA8c3BhbiBjbGFzcz1cIm51bVwiPiR7Zm10TnVtKGJ1ZmZlcmVkKX08L3NwYW4+IGJ1ZmZlcmVkYCA6ICcnKSArXG4gICAgICBgIFx1MDBCNyBsYXN0ICR7ZXNjYXBlSHRtbChmbXRSZWwobGFzdCkpfWA7XG5cbiAgICBjb25zdCBhY3Rpb25zID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGFjdGlvbnMuY2xhc3NOYW1lID0gJ2FjYy1hY3Rpb24nO1xuICAgIGNvbnN0IGJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGJ0bi5jbGFzc05hbWUgPSAnYnRuJztcbiAgICBidG4udGV4dENvbnRlbnQgPSAnQ2FwdHVyZSBub3cnO1xuICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtbm93JywgaGFuZGxlOiBhLmhhbmRsZSB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGFjdGlvbnMuYXBwZW5kKGJ0bik7XG5cbiAgICByb3cuYXBwZW5kKHN0YXRzLCBhY3Rpb25zKTtcbiAgICBsaS5hcHBlbmQoaGVhZCwgcm93KTtcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFjdGl2aXR5KGV2ZW50czogTG9nRXZlbnRbXSk6IHZvaWQge1xuICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChldmVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWN0aXZpdHkgeWV0Lic7XG4gICAgYWN0aXZpdHlMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3QgZXYgb2YgZXZlbnRzLnNsaWNlKDAsIEFDVElWSVRZX1RBSUxfTUFYKSkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xuICAgIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XG4gICAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcbiAgICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xuICAgIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xuICAgIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xuICAgIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcbiAgICBib2R5LmFwcGVuZChtc2cpO1xuICAgIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcbiAgICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcbiAgICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgICBib2R5LmFwcGVuZChjdHgpO1xuICAgIH1cbiAgICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xuICAgIGFjdGl2aXR5TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHN0cmluZ2lmeVNob3J0KHY6IHVua25vd24pOiBzdHJpbmcge1xuICBpZiAodiA9PT0gbnVsbCkgcmV0dXJuICdudWxsJztcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJykgcmV0dXJuIHYubGVuZ3RoID4gODAgPyBgJHt2LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdjtcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gU3RyaW5nKHYpO1xuICB0cnkge1xuICAgIGNvbnN0IHMgPSBKU09OLnN0cmluZ2lmeSh2KTtcbiAgICByZXR1cm4gcy5sZW5ndGggPiA4MCA/IGAke3Muc2xpY2UoMCwgODApfVx1MjAyNmAgOiBzO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gJz8nO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoczogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHMucmVwbGFjZSgvWyY8PlwiJ10vZywgKGMpID0+XG4gICAgYyA9PT0gJyYnID8gJyZhbXA7JyA6IGMgPT09ICc8JyA/ICcmbHQ7JyA6IGMgPT09ICc+JyA/ICcmZ3Q7JyA6IGMgPT09ICdcIicgPyAnJnF1b3Q7JyA6ICcmIzM5OydcbiAgKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaFN0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGxhc3RTdGF0ZSA9IGF3YWl0IHNlbmQ8RXh0ZW5zaW9uU3RhdGU+KHsgdHlwZTogJ2dldC1zdGF0ZScgfSk7XG4gICAgcGFpbnQobGFzdFN0YXRlKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNpZGViYXIgcmVmcmVzaFN0YXRlIGZhaWxlZCcsIGVycik7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGFpbnQoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGV4dFZlcnNpb25FbC50ZXh0Q29udGVudCA9IHN0YXRlLnZlcnNpb247XG4gIHNldENvbm5TdGF0dXMoc3RhdGUpO1xuICBhdXRvVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvQ2FwdHVyZTtcbiAgdXBkYXRlRXhpc3RpbmdUb2dnbGUuY2hlY2tlZCA9IHN0YXRlLnNldHRpbmdzLnVwZGF0ZUV4aXN0aW5nICE9PSBmYWxzZTtcbiAgdmlld2VyTGluay5ocmVmID0gYGh0dHBzOi8vJHtzdGF0ZS5zZXR0aW5ncy5vd25lcn0uZ2l0aHViLmlvLyR7c3RhdGUuc2V0dGluZ3MucmVwb30vYDtcbiAgcGFpbnRNYXN0ZXJTd2l0Y2goc3RhdGUpO1xuICByZW5kZXJBY2NvdW50cyhzdGF0ZSk7XG4gIHBhaW50QXV0b1Njcm9sbChzdGF0ZSk7XG4gIHBhaW50TWVkaWFDcmF3bChzdGF0ZSk7XG4gIHBhaW50UmVmZXRjaChzdGF0ZSk7XG59XG5cbmZ1bmN0aW9uIHBhaW50TWVkaWFDcmF3bChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3QgcSA9IHN0YXRlLm1lZGlhQ3Jhd2xRdWV1ZTtcbiAgY29uc3QgdG90YWwgPSBxLnRvdGFsO1xuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xuICBtZWRpYUNyYXdsU2VjdGlvbi5oaWRkZW4gPSB0b3RhbCA9PT0gMCAmJiAhcnVubmluZztcbiAgbWVkaWFDcmF3bENvdW50LnRleHRDb250ZW50ID1cbiAgICB0b3RhbCA9PT0gMFxuICAgICAgPyBydW5uaW5nXG4gICAgICAgID8gJ2ZpbmlzaGluZ1x1MjAyNidcbiAgICAgICAgOiAnMCBxdWV1ZWQnXG4gICAgICA6IGAke2ZtdE51bSh0b3RhbCl9IHF1ZXVlZCR7cnVubmluZyA/ICcgXHUwMEI3IHJ1bm5pbmcnIDogJyd9YDtcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmhpZGRlbiA9IHJ1bm5pbmc7XG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xuICBtZWRpYUNyYXdsQ2FuY2VsQnRuLmhpZGRlbiA9ICFydW5uaW5nO1xuICBwYWludFF1ZXVlUHJvZ3Jlc3MobWVkaWFDcmF3bFByb2dyZXNzLCBxKTtcbn1cblxuZnVuY3Rpb24gcGFpbnRRdWV1ZVByb2dyZXNzKFxuICBlbDogSFRNTFNwYW5FbGVtZW50LFxuICBxOiB7IHByb2Nlc3NlZDogbnVtYmVyOyB0b3RhbF9hdF9zdGFydDogbnVtYmVyOyBydW5uaW5nOiBib29sZWFuOyB0b3RhbDogbnVtYmVyIH1cbik6IHZvaWQge1xuICBpZiAoIXEucnVubmluZyAmJiBxLnByb2Nlc3NlZCA9PT0gMCkge1xuICAgIGVsLmhpZGRlbiA9IHRydWU7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIERlbm9taW5hdG9yOiBtYXggb2YgaW5pdGlhbCB0b3RhbCBhbmQgY3VycmVudCBwcm9jZXNzZWQrcmVtYWluaW5nIHNvIHRoZVxuICAvLyBiYXIgc3RpbGwgbWFrZXMgc2Vuc2UgaWYgbmV3IGVudHJpZXMgd2VyZSBlbnF1ZXVlZCBtaWQtcnVuLlxuICBjb25zdCBkZW5vbSA9IE1hdGgubWF4KHEudG90YWxfYXRfc3RhcnQsIHEucHJvY2Vzc2VkICsgcS50b3RhbCk7XG4gIGVsLmhpZGRlbiA9IGZhbHNlO1xuICBlbC50ZXh0Q29udGVudCA9IGAke2ZtdE51bShxLnByb2Nlc3NlZCl9IC8gJHtmbXROdW0oZGVub20pfSBwcm9jZXNzZWRgO1xuICBlbC5jbGFzc05hbWUgPSBxLnJ1bm5pbmcgPyAncHJvZ3Jlc3Mgb24nIDogJ3Byb2dyZXNzJztcbn1cblxuZnVuY3Rpb24gcGFpbnRNYXN0ZXJTd2l0Y2goc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IG9uID0gc3RhdGUuc2V0dGluZ3MuZW5hYmxlZCAhPT0gZmFsc2U7XG4gIG1hc3RlclN3aXRjaC5jaGVja2VkID0gb247XG4gIG1hc3RlckxhYmVsLnRleHRDb250ZW50ID0gb24gPyAnT04nIDogJ1BBVVNFRCc7XG4gIGRvY3VtZW50LmJvZHkuY2xhc3NMaXN0LnRvZ2dsZSgncGF1c2VkJywgIW9uKTtcbn1cblxuZnVuY3Rpb24gcGFpbnRBdXRvU2Nyb2xsKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBzZWNzID0gc3RhdGUuc2V0dGluZ3MuYXV0b1Njcm9sbEludGVydmFsU2VjO1xuICBhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWUgPSBTdHJpbmcoc2Vjcyk7XG4gIGF1dG9TY3JvbGxTZWNzRWwudGV4dENvbnRlbnQgPSBTdHJpbmcoc2Vjcyk7XG4gIGNvbnN0IGFzID0gc3RhdGUuYXV0b1Njcm9sbDtcbiAgYXV0b1Njcm9sbFN0YXJ0QnRuLmhpZGRlbiA9IGFzLmFjdGl2ZTtcbiAgYXV0b1Njcm9sbENhbmNlbEJ0bi5oaWRkZW4gPSAhYXMuYWN0aXZlO1xuICBpZiAoYXMuYWN0aXZlKSB7XG4gICAgY29uc3QgbiA9IGFzLnRhYkNvdW50O1xuICAgIGF1dG9TY3JvbGxTdGF0dXMudGV4dENvbnRlbnQgPVxuICAgICAgbiA9PT0gMCA/IGBydW5uaW5nIFx1MjAxNCBubyBYIHRhYnMgb3BlbmAgOiBgcnVubmluZyBcdTIwMTQgJHtufSAke24gPT09IDEgPyAndGFiJyA6ICd0YWJzJ31gO1xuICAgIGF1dG9TY3JvbGxTdGF0dXMuY2xhc3NOYW1lID0gJ211dGVkIG9uJztcbiAgfSBlbHNlIHtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLnRleHRDb250ZW50ID0gJ2lkbGUnO1xuICAgIGF1dG9TY3JvbGxTdGF0dXMuY2xhc3NOYW1lID0gJ211dGVkJztcbiAgfVxuICBpZiAoYXMuYWN0aXZlIHx8IGFzLnNjcm9sbENvdW50ID4gMCB8fCBhcy5pbmdlc3RlZENvdW50ID4gMCkge1xuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy5oaWRkZW4gPSBmYWxzZTtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MudGV4dENvbnRlbnQgPVxuICAgICAgYCR7Zm10TnVtKGFzLnNjcm9sbENvdW50KX0gc2Nyb2xscyBcdTAwQjcgYCArXG4gICAgICBgJHtmbXROdW0oYXMuaW5nZXN0ZWRDb3VudCl9IHR3ZWV0cyBpbmdlc3RlZCBcdTAwQjcgYCArXG4gICAgICBgJHtmbXROdW0oYXMuZXhwYW5kZWRDb3VudCl9IGV4cGFuZGVkYDtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuY2xhc3NOYW1lID0gYXMuYWN0aXZlID8gJ3Byb2dyZXNzIG9uJyA6ICdwcm9ncmVzcyc7XG4gIH0gZWxzZSB7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmhpZGRlbiA9IHRydWU7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGFpbnRSZWZldGNoKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBxID0gc3RhdGUucmVmZXRjaFF1ZXVlO1xuICBjb25zdCB0b3RhbCA9IHEudG90YWw7XG4gIGNvbnN0IHJ1bm5pbmcgPSBxLnJ1bm5pbmc7XG4gIHJlZmV0Y2hTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xuICByZWZldGNoQ291bnQudGV4dENvbnRlbnQgPVxuICAgIHRvdGFsID09PSAwXG4gICAgICA/IHJ1bm5pbmdcbiAgICAgICAgPyAnZmluaXNoaW5nXHUyMDI2J1xuICAgICAgICA6ICcwIHF1ZXVlZCdcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xuICByZWZldGNoU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcbiAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gdG90YWwgPT09IDA7XG4gIHJlZmV0Y2hDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XG4gIHBhaW50UXVldWVQcm9ncmVzcyhyZWZldGNoUHJvZ3Jlc3MsIHEpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIFB1bGwgc3RyYWlnaHQgZnJvbSBzdG9yYWdlIG9uIGZpcnN0IHJlbmRlcjsgbGl2ZSB1cGRhdGVzIGNvbWUgdmlhXG4gIC8vIGBsb2ctZXZlbnRgIGJyb2FkY2FzdHMuXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoJ2FjdGl2aXR5Jyk7XG4gIGNvbnN0IGV2ZW50cyA9IChzdG9yZWQuYWN0aXZpdHkgYXMgTG9nRXZlbnRbXSB8IHVuZGVmaW5lZCkgPz8gW107XG4gIHJlbmRlckFjdGl2aXR5KGV2ZW50cyk7XG59XG5cbi8vIC0tLSBXaXJlIHVwIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmNhcHR1cmVBbGxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGNhcHR1cmVBbGxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS1hbGwnIH0pO1xuICB9IGZpbmFsbHkge1xuICAgIGNhcHR1cmVBbGxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfVxufSk7XG5cbmNhcHR1cmVUaGlzQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBjYXB0dXJlVGhpc0J0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjYXB0dXJlLXRoaXMtcGFnZScgfSk7XG4gIH0gZmluYWxseSB7XG4gICAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfVxufSk7XG5cbmZsdXNoQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBmbHVzaEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdmbHVzaC1hbGwnIH0pO1xuICB9IGZpbmFsbHkge1xuICAgIGZsdXNoQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5hdXRvVG9nZ2xlLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1hdXRvLWNhcHR1cmUnLCBvbjogYXV0b1RvZ2dsZS5jaGVja2VkIH0pO1xufSk7XG5cbnVwZGF0ZUV4aXN0aW5nVG9nZ2xlLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS11cGRhdGUtZXhpc3RpbmcnLCBvbjogdXBkYXRlRXhpc3RpbmdUb2dnbGUuY2hlY2tlZCB9KTtcbn0pO1xuXG5tYXN0ZXJTd2l0Y2guYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLWVuYWJsZWQnLCBvbjogbWFzdGVyU3dpdGNoLmNoZWNrZWQgfSk7XG59KTtcblxuYXV0b1Njcm9sbFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtYXV0by1zY3JvbGwnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIGF1dG9TY3JvbGxTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuYXV0b1Njcm9sbENhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgYXV0b1Njcm9sbENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtYXV0by1zY3JvbGwnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIGF1dG9TY3JvbGxDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JywgKCkgPT4ge1xuICBhdXRvU2Nyb2xsU2Vjc0VsLnRleHRDb250ZW50ID0gYXV0b1Njcm9sbEludGVydmFsLnZhbHVlO1xufSk7XG5hdXRvU2Nyb2xsSW50ZXJ2YWwuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICBjb25zdCBzZWNvbmRzID0gTnVtYmVyKGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZSk7XG4gIGlmIChOdW1iZXIuaXNGaW5pdGUoc2Vjb25kcykpIHtcbiAgICB2b2lkIHNlbmQoeyB0eXBlOiAnc2V0LWF1dG8tc2Nyb2xsLWludGVydmFsJywgc2Vjb25kcyB9KTtcbiAgfVxufSk7XG5cbnB1cmdlTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIGNvbnN0IG9rID0gd2luZG93LmNvbmZpcm0oXG4gICAgJ0Ryb3AgZXZlcnkgY291bnRlciwgcnVuIGJ1ZmZlciwgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHF1ZXVlIGVudHJ5IGZvciBhY2NvdW50cyBub3QgaW4geW91ciB0cmFja2VkIGxpc3Q/XFxuXFxuJyArXG4gICAgICAnVGhpcyBvbmx5IHRvdWNoZXMgbG9jYWwgZXh0ZW5zaW9uIHN0YXRlLiBBbHJlYWR5LWNvbW1pdHRlZCBmaWxlcyBpbiB0aGUgR2l0SHViIHJlcG8gYXJlIG5vdCBhZmZlY3RlZCBcdTIwMTQgJyArXG4gICAgICAncnVuIHNjcmlwdHMvcHVyZ2VfdW5yZWxhdGVkLnB5IHNlcGFyYXRlbHkgaWYgeW91IGFsc28gd2FudCB0byBzY3J1YiB0aGUgcmVwby4nXG4gICk7XG4gIGlmICghb2spIHJldHVybjtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3B1cmdlLXVucmVsYXRlZCcgfSk7XG59KTtcblxucmVmZXRjaFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtcmVmZXRjaCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbnJlZmV0Y2hDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxubWVkaWFDcmF3bFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5tZWRpYUNyYXdsQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBtZWRpYUNyYXdsQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1tZWRpYS1jcmF3bCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5vcHRpb25zTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdvcGVuLW9wdGlvbnMnIH0pO1xufSk7XG5cbnZpZXdlckxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnb3Blbi12aWV3ZXInIH0pO1xufSk7XG5cbmNsZWFyQWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NsZWFyLWFjdGl2aXR5JyB9KTtcbiAgcmVuZGVyQWN0aXZpdHkoW10pO1xufSk7XG5cbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93bikgPT4ge1xuICBpZiAoIW1zZyB8fCB0eXBlb2YgbXNnICE9PSAnb2JqZWN0JykgcmV0dXJuO1xuICBjb25zdCBtID0gbXNnIGFzIHsgdHlwZT86IHN0cmluZzsgc3RhdGU/OiBFeHRlbnNpb25TdGF0ZTsgZXZlbnQ/OiBMb2dFdmVudCB9O1xuICBpZiAobS50eXBlID09PSAnc3RhdGUtY2hhbmdlZCcgJiYgbS5zdGF0ZSkge1xuICAgIGxhc3RTdGF0ZSA9IG0uc3RhdGU7XG4gICAgcGFpbnQobS5zdGF0ZSk7XG4gIH0gZWxzZSBpZiAobS50eXBlID09PSAnbG9nLWV2ZW50JyAmJiBtLmV2ZW50KSB7XG4gICAgcHJlcGVuZEV2ZW50KG0uZXZlbnQpO1xuICB9XG59KTtcblxuZnVuY3Rpb24gcHJlcGVuZEV2ZW50KGV2OiBMb2dFdmVudCk6IHZvaWQge1xuICAvLyBJZiB0aGUgbGlzdCBpcyBzaG93aW5nIHRoZSBcImVtcHR5XCIgcGxhY2Vob2xkZXIsIGNsZWFyIGl0LlxuICBpZiAoYWN0aXZpdHlMaXN0LmZpcnN0RWxlbWVudENoaWxkPy5jbGFzc0xpc3QuY29udGFpbnMoJ2VtcHR5JykpIHtcbiAgICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIH1cbiAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xuICBjb25zdCB0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgdHMuY2xhc3NOYW1lID0gJ2V2LXRzJztcbiAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcbiAgY29uc3QgaWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgaWNvbi5jbGFzc05hbWUgPSAnZXYtaWNvbic7XG4gIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xuICBjb25zdCBib2R5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBjb25zdCBtc2cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xuICBtc2cudGV4dENvbnRlbnQgPSBldi5tc2c7XG4gIGJvZHkuYXBwZW5kKG1zZyk7XG4gIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcbiAgaWYgKGN0eEtleXMubGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGN0eCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcbiAgICBjdHgudGV4dENvbnRlbnQgPSBjdHhLZXlzLm1hcCgoaykgPT4gYCR7a309JHtzdHJpbmdpZnlTaG9ydChldi5jb250ZXh0W2tdKX1gKS5qb2luKCcgXHUwMEI3ICcpO1xuICAgIGJvZHkuYXBwZW5kKGN0eCk7XG4gIH1cbiAgbGkuYXBwZW5kKHRzLCBpY29uLCBib2R5KTtcbiAgYWN0aXZpdHlMaXN0LnByZXBlbmQobGkpO1xuICB3aGlsZSAoYWN0aXZpdHlMaXN0LmNoaWxkRWxlbWVudENvdW50ID4gQUNUSVZJVFlfVEFJTF9NQVgpIHtcbiAgICBhY3Rpdml0eUxpc3QubGFzdEVsZW1lbnRDaGlsZD8ucmVtb3ZlKCk7XG4gIH1cbn1cblxuLy8gSW5pdGlhbCBwYWludC5cbnZvaWQgcmVmcmVzaFN0YXRlKCk7XG52b2lkIHJlZnJlc2hBY3Rpdml0eSgpO1xuXG4vLyBQZXJpb2RpY2FsbHkgcmUtZmV0Y2ggc3RhdGUgc28gXCJsYXN0IGNhcHR1cmVcIiB0aW1lcyBzdGF5IGZyZXNoLlxuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICB2b2lkIHJlZnJlc2hTdGF0ZSgpO1xufSwgMTVfMDAwKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7QUEwRk8sSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLOzs7QUNsRnZELElBQU0sSUFBSSxDQUFzQyxPQUFrQjtBQUNoRSxRQUFNLEtBQUssU0FBUyxlQUFlLEVBQUU7QUFDckMsTUFBSSxDQUFDLEdBQUksT0FBTSxJQUFJLE1BQU0sb0JBQW9CLEVBQUUsRUFBRTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxJQUFNLFVBQVUsRUFBRSxVQUFVO0FBQzVCLElBQU0sV0FBVyxFQUFtQixXQUFXO0FBQy9DLElBQU0sY0FBYyxFQUFvQixjQUFjO0FBQ3RELElBQU0sZUFBZSxFQUFvQixlQUFlO0FBQ3hELElBQU0sYUFBYSxFQUFvQixjQUFjO0FBQ3JELElBQU0sdUJBQXVCLEVBQW9CLGlCQUFpQjtBQUNsRSxJQUFNLGdCQUFnQixFQUFxQixhQUFhO0FBQ3hELElBQU0saUJBQWlCLEVBQXFCLGNBQWM7QUFDMUQsSUFBTSxXQUFXLEVBQXFCLFdBQVc7QUFDakQsSUFBTSxjQUFjLEVBQXFCLGNBQWM7QUFDdkQsSUFBTSxhQUFhLEVBQXFCLGFBQWE7QUFDckQsSUFBTSxjQUFjLEVBQXFCLGdCQUFnQjtBQUN6RCxJQUFNLGVBQWUsRUFBbUIsYUFBYTtBQUNyRCxJQUFNLGVBQWUsRUFBb0IsZUFBZTtBQUN4RCxJQUFNLGNBQWMsRUFBbUIsY0FBYztBQUNyRCxJQUFNLHFCQUFxQixFQUFvQixzQkFBc0I7QUFDckUsSUFBTSxtQkFBbUIsRUFBbUIsa0JBQWtCO0FBQzlELElBQU0sbUJBQW1CLEVBQW1CLG9CQUFvQjtBQUNoRSxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLGlCQUFpQixFQUFlLGlCQUFpQjtBQUN2RCxJQUFNLGVBQWUsRUFBbUIsZUFBZTtBQUN2RCxJQUFNLGtCQUFrQixFQUFxQixlQUFlO0FBQzVELElBQU0sbUJBQW1CLEVBQXFCLGdCQUFnQjtBQUM5RCxJQUFNLGtCQUFrQixFQUFtQixrQkFBa0I7QUFDN0QsSUFBTSxvQkFBb0IsRUFBZSxxQkFBcUI7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsbUJBQW1CO0FBQzlELElBQU0scUJBQXFCLEVBQXFCLG1CQUFtQjtBQUNuRSxJQUFNLHNCQUFzQixFQUFxQixvQkFBb0I7QUFDckUsSUFBTSxxQkFBcUIsRUFBbUIsc0JBQXNCO0FBQ3BFLElBQU0sWUFBWSxFQUFxQixpQkFBaUI7QUFFeEQsSUFBSSxZQUFtQztBQUV2QyxlQUFlLEtBQVEsS0FBaUM7QUFDdEQsU0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ3hDO0FBRUEsU0FBUyxjQUFjLE9BQTZCO0FBQ2xELFFBQU0sRUFBRSxZQUFZLFNBQVMsSUFBSTtBQUNqQyxNQUFJLE1BQU07QUFDVixNQUFJLE9BQU87QUFLWCxRQUFNLGdCQUNKLFdBQVcsV0FBVyxRQUFRLFNBQVMsVUFBVSxXQUFXLDJCQUEyQjtBQUN6RixNQUFJLENBQUMsU0FBUyxRQUFRO0FBQ3BCLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLGVBQWU7QUFDeEIsVUFBTTtBQUNOLFdBQU8sV0FBVyxTQUFTLE1BQU0sdUJBQXVCLFNBQVMsS0FBSyxJQUFJLFNBQVMsSUFBSSw0Q0FBdUMsV0FBVyxpQkFBaUIsUUFBUTtBQUFBLEVBQ3BLLFdBQVcsV0FBVyxXQUFXLE1BQU07QUFDckMsVUFBTTtBQUNOLFdBQU8saUJBQWlCLFdBQVcsU0FBUyxHQUFHLE9BQU8sU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLGVBQU8sU0FBUyxTQUFTO0FBQUEsRUFDaEgsV0FBVyxXQUFXLFdBQVcsY0FBYztBQUM3QyxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxXQUFXLFdBQVcsZ0JBQWdCO0FBQy9DLFVBQU07QUFDTixVQUFNLFNBQVMsa0JBQWtCLFdBQVcsZ0JBQWdCO0FBQzVELFdBQU8sU0FDSCxxQ0FBZ0MsTUFBTSxLQUN0QztBQUFBLEVBQ04sV0FBVyxXQUFXLFdBQVcsaUJBQWlCO0FBQ2hELFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLFdBQVcsV0FBVyxrQkFBa0I7QUFDakQsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULE9BQU87QUFDTCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDQSxVQUFRLFlBQVksT0FBTyxHQUFHO0FBQzlCLFdBQVMsY0FBYztBQUN2QixXQUFTLFFBQVEsV0FBVyxTQUFTO0FBQ3ZDO0FBRUEsU0FBUyxPQUFPLEtBQTRCO0FBQzFDLE1BQUksQ0FBQyxJQUFLLFFBQU87QUFDakIsUUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHO0FBQ3hCLE1BQUksQ0FBQyxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFDaEMsUUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssT0FBTyxLQUFLLElBQUksSUFBSSxLQUFLLEdBQUksQ0FBQztBQUM1RCxNQUFJLE9BQU8sRUFBRyxRQUFPO0FBQ3JCLE1BQUksT0FBTyxHQUFJLFFBQU8sR0FBRyxJQUFJO0FBQzdCLFFBQU0sT0FBTyxLQUFLLE1BQU0sT0FBTyxFQUFFO0FBQ2pDLE1BQUksT0FBTyxHQUFJLFFBQU8sR0FBRyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxLQUFLLE1BQU0sT0FBTyxFQUFFO0FBQ2xDLE1BQUksUUFBUSxHQUFJLFFBQU8sR0FBRyxLQUFLO0FBQy9CLFFBQU0sT0FBTyxLQUFLLE1BQU0sUUFBUSxFQUFFO0FBQ2xDLFNBQU8sR0FBRyxJQUFJO0FBQ2hCO0FBRUEsU0FBUyxrQkFBa0IsVUFBaUM7QUFDMUQsTUFBSSxhQUFhLEtBQU0sUUFBTztBQUM5QixRQUFNLFdBQVcsV0FBVyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUN4RCxNQUFJLFlBQVksRUFBRyxRQUFPO0FBQzFCLFFBQU0sWUFBWSxJQUFJLEtBQUssV0FBVyxHQUFJLEVBQUUsbUJBQW1CLENBQUMsR0FBRztBQUFBLElBQ2pFLE1BQU07QUFBQSxJQUNOLFFBQVE7QUFBQSxFQUNWLENBQUM7QUFDRCxNQUFJLFdBQVcsR0FBSSxRQUFPLE1BQU0sUUFBUSxNQUFNLFNBQVM7QUFDdkQsUUFBTSxPQUFPLEtBQUssTUFBTSxXQUFXLEVBQUU7QUFDckMsTUFBSSxPQUFPLEdBQUksUUFBTyxNQUFNLElBQUksTUFBTSxTQUFTO0FBQy9DLFFBQU0sUUFBUSxLQUFLLE1BQU0sT0FBTyxFQUFFO0FBQ2xDLFNBQU8sTUFBTSxLQUFLLE1BQU0sU0FBUztBQUNuQztBQUVBLFNBQVMsT0FBTyxHQUFtQjtBQUNqQyxTQUFPLEVBQUUsZUFBZSxPQUFPO0FBQ2pDO0FBRUEsU0FBUyxlQUFlLE9BQTZCO0FBQ25ELGNBQVksZ0JBQWdCO0FBQzVCLE1BQUksTUFBTSxTQUFTLFdBQVcsR0FBRztBQUMvQixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLGdCQUFZLE9BQU8sRUFBRTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLEtBQUssTUFBTSxVQUFVO0FBQzlCLFVBQU0sSUFBSSxNQUFNLFNBQVMsRUFBRSxNQUFNO0FBQ2pDLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksS0FBSyxFQUFFLGdCQUFnQixJQUFJLGdCQUFnQjtBQUUxRCxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBQ2pCLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVk7QUFDbkIsV0FBTyxZQUFZLDRCQUE0QixXQUFXLEVBQUUsTUFBTSxDQUFDO0FBQ25FLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLEVBQUU7QUFDckIsU0FBSyxPQUFPLFFBQVEsSUFBSTtBQUV4QixVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFVBQU0sUUFBUSxTQUFTLGNBQWMsTUFBTTtBQUMzQyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxRQUFRLEdBQUcsY0FBYztBQUMvQixVQUFNLFdBQVcsR0FBRyxpQkFBaUI7QUFDckMsVUFBTSxPQUFPLEdBQUcsaUJBQWlCO0FBQ2pDLFVBQU0sWUFDSixxQkFBcUIsT0FBTyxLQUFLLENBQUMsbUJBQ2pDLFdBQVcsSUFBSSwyQkFBd0IsT0FBTyxRQUFRLENBQUMscUJBQXFCLE1BQzdFLGNBQVcsV0FBVyxPQUFPLElBQUksQ0FBQyxDQUFDO0FBRXJDLFVBQU0sVUFBVSxTQUFTLGNBQWMsTUFBTTtBQUM3QyxZQUFRLFlBQVk7QUFDcEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxRQUFRO0FBQzNDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWM7QUFDbEIsUUFBSSxpQkFBaUIsU0FBUyxZQUFZO0FBQ3hDLFVBQUksV0FBVztBQUNmLFVBQUk7QUFDRixjQUFNLEtBQUssRUFBRSxNQUFNLGVBQWUsUUFBUSxFQUFFLE9BQU8sQ0FBQztBQUFBLE1BQ3RELFVBQUU7QUFDQSxZQUFJLFdBQVc7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUNELFlBQVEsT0FBTyxHQUFHO0FBRWxCLFFBQUksT0FBTyxPQUFPLE9BQU87QUFDekIsT0FBRyxPQUFPLE1BQU0sR0FBRztBQUNuQixnQkFBWSxPQUFPLEVBQUU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyxlQUFlLFFBQTBCO0FBQ2hELGVBQWEsZ0JBQWdCO0FBQzdCLE1BQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixpQkFBYSxPQUFPLEVBQUU7QUFDdEI7QUFBQSxFQUNGO0FBQ0EsYUFBVyxNQUFNLE9BQU8sTUFBTSxHQUFHLGlCQUFpQixHQUFHO0FBQ25ELFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDN0IsVUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQ3hDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUM5RSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxHQUFHLFVBQVUsVUFBVSxXQUFNLEdBQUcsVUFBVSxTQUFTLE1BQU07QUFDNUUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLEdBQUc7QUFDckIsU0FBSyxPQUFPLEdBQUc7QUFDZixVQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTztBQUN0QyxRQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLFlBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxVQUFJLFlBQVk7QUFDaEIsVUFBSSxjQUFjLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssUUFBSztBQUN4RixXQUFLLE9BQU8sR0FBRztBQUFBLElBQ2pCO0FBQ0EsT0FBRyxPQUFPLElBQUksTUFBTSxJQUFJO0FBQ3hCLGlCQUFhLE9BQU8sRUFBRTtBQUFBLEVBQ3hCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBb0I7QUFDMUMsTUFBSSxNQUFNLEtBQU0sUUFBTztBQUN2QixNQUFJLE9BQU8sTUFBTSxTQUFVLFFBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUN6RSxNQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxVQUFXLFFBQU8sT0FBTyxDQUFDO0FBQ3BFLE1BQUk7QUFDRixVQUFNLElBQUksS0FBSyxVQUFVLENBQUM7QUFDMUIsV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsR0FBbUI7QUFDckMsU0FBTyxFQUFFO0FBQUEsSUFBUTtBQUFBLElBQVksQ0FBQyxNQUM1QixNQUFNLE1BQU0sVUFBVSxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sV0FBVztBQUFBLEVBQ3pGO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLE1BQUk7QUFDRixnQkFBWSxNQUFNLEtBQXFCLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFDNUQsVUFBTSxTQUFTO0FBQUEsRUFDakIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDZDQUE2QyxHQUFHO0FBQUEsRUFDL0Q7QUFDRjtBQUVBLFNBQVMsTUFBTSxPQUE2QjtBQUMxQyxlQUFhLGNBQWMsTUFBTTtBQUNqQyxnQkFBYyxLQUFLO0FBQ25CLGFBQVcsVUFBVSxNQUFNLFNBQVM7QUFDcEMsdUJBQXFCLFVBQVUsTUFBTSxTQUFTLG1CQUFtQjtBQUNqRSxhQUFXLE9BQU8sV0FBVyxNQUFNLFNBQVMsS0FBSyxjQUFjLE1BQU0sU0FBUyxJQUFJO0FBQ2xGLG9CQUFrQixLQUFLO0FBQ3ZCLGlCQUFlLEtBQUs7QUFDcEIsa0JBQWdCLEtBQUs7QUFDckIsa0JBQWdCLEtBQUs7QUFDckIsZUFBYSxLQUFLO0FBQ3BCO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsb0JBQWtCLFNBQVMsVUFBVSxLQUFLLENBQUM7QUFDM0Msa0JBQWdCLGNBQ2QsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELHFCQUFtQixTQUFTO0FBQzVCLHFCQUFtQixXQUFXLFVBQVU7QUFDeEMsc0JBQW9CLFNBQVMsQ0FBQztBQUM5QixxQkFBbUIsb0JBQW9CLENBQUM7QUFDMUM7QUFFQSxTQUFTLG1CQUNQLElBQ0EsR0FDTTtBQUNOLE1BQUksQ0FBQyxFQUFFLFdBQVcsRUFBRSxjQUFjLEdBQUc7QUFDbkMsT0FBRyxTQUFTO0FBQ1o7QUFBQSxFQUNGO0FBR0EsUUFBTSxRQUFRLEtBQUssSUFBSSxFQUFFLGdCQUFnQixFQUFFLFlBQVksRUFBRSxLQUFLO0FBQzlELEtBQUcsU0FBUztBQUNaLEtBQUcsY0FBYyxHQUFHLE9BQU8sRUFBRSxTQUFTLENBQUMsTUFBTSxPQUFPLEtBQUssQ0FBQztBQUMxRCxLQUFHLFlBQVksRUFBRSxVQUFVLGdCQUFnQjtBQUM3QztBQUVBLFNBQVMsa0JBQWtCLE9BQTZCO0FBQ3RELFFBQU0sS0FBSyxNQUFNLFNBQVMsWUFBWTtBQUN0QyxlQUFhLFVBQVU7QUFDdkIsY0FBWSxjQUFjLEtBQUssT0FBTztBQUN0QyxXQUFTLEtBQUssVUFBVSxPQUFPLFVBQVUsQ0FBQyxFQUFFO0FBQzlDO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxPQUFPLE1BQU0sU0FBUztBQUM1QixxQkFBbUIsUUFBUSxPQUFPLElBQUk7QUFDdEMsbUJBQWlCLGNBQWMsT0FBTyxJQUFJO0FBQzFDLFFBQU0sS0FBSyxNQUFNO0FBQ2pCLHFCQUFtQixTQUFTLEdBQUc7QUFDL0Isc0JBQW9CLFNBQVMsQ0FBQyxHQUFHO0FBQ2pDLE1BQUksR0FBRyxRQUFRO0FBQ2IsVUFBTSxJQUFJLEdBQUc7QUFDYixxQkFBaUIsY0FDZixNQUFNLElBQUksa0NBQTZCLGtCQUFhLENBQUMsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNO0FBQ25GLHFCQUFpQixZQUFZO0FBQUEsRUFDL0IsT0FBTztBQUNMLHFCQUFpQixjQUFjO0FBQy9CLHFCQUFpQixZQUFZO0FBQUEsRUFDL0I7QUFDQSxNQUFJLEdBQUcsVUFBVSxHQUFHLGNBQWMsS0FBSyxHQUFHLGdCQUFnQixHQUFHO0FBQzNELHVCQUFtQixTQUFTO0FBQzVCLHVCQUFtQixjQUNqQixHQUFHLE9BQU8sR0FBRyxXQUFXLENBQUMsaUJBQ3RCLE9BQU8sR0FBRyxhQUFhLENBQUMseUJBQ3hCLE9BQU8sR0FBRyxhQUFhLENBQUM7QUFDN0IsdUJBQW1CLFlBQVksR0FBRyxTQUFTLGdCQUFnQjtBQUFBLEVBQzdELE9BQU87QUFDTCx1QkFBbUIsU0FBUztBQUFBLEVBQzlCO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsT0FBNkI7QUFDakQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsaUJBQWUsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUN4QyxlQUFhLGNBQ1gsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELGtCQUFnQixTQUFTO0FBQ3pCLGtCQUFnQixXQUFXLFVBQVU7QUFDckMsbUJBQWlCLFNBQVMsQ0FBQztBQUMzQixxQkFBbUIsaUJBQWlCLENBQUM7QUFDdkM7QUFFQSxlQUFlLGtCQUFpQztBQUc5QyxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLFVBQVU7QUFDekQsUUFBTSxTQUFVLE9BQU8sWUFBdUMsQ0FBQztBQUMvRCxpQkFBZSxNQUFNO0FBQ3ZCO0FBSUEsY0FBYyxpQkFBaUIsU0FBUyxZQUFZO0FBQ2xELGdCQUFjLFdBQVc7QUFDekIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQUEsRUFDcEMsVUFBRTtBQUNBLGtCQUFjLFdBQVc7QUFBQSxFQUMzQjtBQUNGLENBQUM7QUFFRCxlQUFlLGlCQUFpQixTQUFTLFlBQVk7QUFDbkQsaUJBQWUsV0FBVztBQUMxQixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUFBLEVBQzFDLFVBQUU7QUFDQSxtQkFBZSxXQUFXO0FBQUEsRUFDNUI7QUFDRixDQUFDO0FBRUQsU0FBUyxpQkFBaUIsU0FBUyxZQUFZO0FBQzdDLFdBQVMsV0FBVztBQUNwQixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFBQSxFQUNsQyxVQUFFO0FBQ0EsYUFBUyxXQUFXO0FBQUEsRUFDdEI7QUFDRixDQUFDO0FBRUQsV0FBVyxpQkFBaUIsVUFBVSxNQUFNO0FBQzFDLE9BQUssS0FBSyxFQUFFLE1BQU0sdUJBQXVCLElBQUksV0FBVyxRQUFRLENBQUM7QUFDbkUsQ0FBQztBQUVELHFCQUFxQixpQkFBaUIsVUFBVSxNQUFNO0FBQ3BELE9BQUssS0FBSyxFQUFFLE1BQU0sMEJBQTBCLElBQUkscUJBQXFCLFFBQVEsQ0FBQztBQUNoRixDQUFDO0FBRUQsYUFBYSxpQkFBaUIsVUFBVSxNQUFNO0FBQzVDLE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLElBQUksYUFBYSxRQUFRLENBQUM7QUFDaEUsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUNELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELG1CQUFpQixjQUFjLG1CQUFtQjtBQUNwRCxDQUFDO0FBQ0QsbUJBQW1CLGlCQUFpQixVQUFVLE1BQU07QUFDbEQsUUFBTSxVQUFVLE9BQU8sbUJBQW1CLEtBQUs7QUFDL0MsTUFBSSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzVCLFNBQUssS0FBSyxFQUFFLE1BQU0sNEJBQTRCLFFBQVEsQ0FBQztBQUFBLEVBQ3pEO0FBQ0YsQ0FBQztBQUVELFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2hELElBQUUsZUFBZTtBQUNqQixRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFHRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsT0FBSyxLQUFLLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUN2QyxDQUFDO0FBRUQsZ0JBQWdCLGlCQUFpQixTQUFTLE1BQU07QUFDOUMsa0JBQWdCLFdBQVc7QUFDM0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNqRCxvQkFBZ0IsV0FBVztBQUFBLEVBQzdCLENBQUM7QUFDSCxDQUFDO0FBRUQsaUJBQWlCLGlCQUFpQixTQUFTLE1BQU07QUFDL0MsbUJBQWlCLFdBQVc7QUFDNUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNsRCxxQkFBaUIsV0FBVztBQUFBLEVBQzlCLENBQUM7QUFDSCxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQscUJBQW1CLFdBQVc7QUFDOUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNyRCx1QkFBbUIsV0FBVztBQUFBLEVBQ2hDLENBQUM7QUFDSCxDQUFDO0FBRUQsb0JBQW9CLGlCQUFpQixTQUFTLE1BQU07QUFDbEQsc0JBQW9CLFdBQVc7QUFDL0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUN0RCx3QkFBb0IsV0FBVztBQUFBLEVBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRUQsWUFBWSxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3BDLENBQUM7QUFFRCxXQUFXLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNqRCxJQUFFLGVBQWU7QUFDakIsT0FBSyxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDbkMsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsWUFBWTtBQUNoRCxRQUFNLEtBQUssRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3JDLGlCQUFlLENBQUMsQ0FBQztBQUNuQixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLFFBQWlCO0FBQ3RELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVO0FBQ3JDLFFBQU0sSUFBSTtBQUNWLE1BQUksRUFBRSxTQUFTLG1CQUFtQixFQUFFLE9BQU87QUFDekMsZ0JBQVksRUFBRTtBQUNkLFVBQU0sRUFBRSxLQUFLO0FBQUEsRUFDZixXQUFXLEVBQUUsU0FBUyxlQUFlLEVBQUUsT0FBTztBQUM1QyxpQkFBYSxFQUFFLEtBQUs7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxTQUFTLGFBQWEsSUFBb0I7QUFFeEMsTUFBSSxhQUFhLG1CQUFtQixVQUFVLFNBQVMsT0FBTyxHQUFHO0FBQy9ELGlCQUFhLGdCQUFnQjtBQUFBLEVBQy9CO0FBQ0EsUUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLEtBQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixRQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsS0FBRyxZQUFZO0FBQ2YsS0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFFBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxPQUFLLFlBQVk7QUFDakIsT0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsUUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLE1BQUksWUFBWTtBQUNoQixNQUFJLGNBQWMsR0FBRztBQUNyQixPQUFLLE9BQU8sR0FBRztBQUNmLFFBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLE1BQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFNBQUssT0FBTyxHQUFHO0FBQUEsRUFDakI7QUFDQSxLQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsZUFBYSxRQUFRLEVBQUU7QUFDdkIsU0FBTyxhQUFhLG9CQUFvQixtQkFBbUI7QUFDekQsaUJBQWEsa0JBQWtCLE9BQU87QUFBQSxFQUN4QztBQUNGO0FBR0EsS0FBSyxhQUFhO0FBQ2xCLEtBQUssZ0JBQWdCO0FBR3JCLFlBQVksTUFBTTtBQUNoQixPQUFLLGFBQWE7QUFDcEIsR0FBRyxJQUFNOyIsCiAgIm5hbWVzIjogW10KfQo=
