var browser=globalThis.browser??globalThis.chrome;

// src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true,
  lowBandwidthBrowsing: false
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" },
  { handle: "StephenM", label: "Stephen Miller", category: "core" },
  { handle: "GregoryKBovino", label: "Gregory Bovino", category: "core" },
  { handle: "RealTomHoman", label: "Thomas D. Homan", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  threadOpenQueue: {},
  threadOpenSeen: {},
  refetchSession: null,
  mediaCrawlSession: null,
  threadOpenSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function setArchiveSnapshot(snapshot) {
  await setRaw("archiveSnapshot", snapshot);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
var RECENT_TWEET_SIGHTINGS_MAX = 80;
async function getRecentTweetSightings() {
  return getRaw("recentTweetSightings");
}
async function prependRecentTweetSightings(rows) {
  if (rows.length === 0) return;
  const cur = await getRecentTweetSightings();
  const seen = /* @__PURE__ */ new Set();
  const next = [];
  for (const row of rows) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  for (const row of cur) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  next.length = Math.min(next.length, RECENT_TWEET_SIGHTINGS_MAX);
  await setRaw("recentTweetSightings", next);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function getThreadOpenQueue() {
  return getRaw("threadOpenQueue");
}
async function threadOpenQueueTotal() {
  const q = await getThreadOpenQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function hasThreadOpenSeen(tweetId) {
  const seen = await getRaw("threadOpenSeen");
  return tweetId in seen;
}
async function markThreadOpenSeen(tweetId) {
  const seen = await getRaw("threadOpenSeen");
  seen[tweetId] = (/* @__PURE__ */ new Date()).toISOString();
  await setRaw("threadOpenSeen", seen);
}
async function enqueueThreadOpen(handle, tweetId) {
  if (await hasThreadOpenSeen(tweetId)) return;
  const q = await getThreadOpenQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("threadOpenQueue", q);
  }
}
async function dequeueThreadOpen(tweetId) {
  const q = await getThreadOpenQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("threadOpenQueue", q);
}
async function nextThreadOpenTarget() {
  const q = await getThreadOpenQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getThreadOpenSession() {
  return getRaw("threadOpenSession");
}
async function setThreadOpenSession(s) {
  await setRaw("threadOpenSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (h !== "_unknown" && !isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  const tq = await getThreadOpenQueue();
  let threadOpenIdsRemoved = 0;
  for (const h of Object.keys(tq)) {
    if (!isTargeted(h)) {
      threadOpenIdsRemoved += (tq[h] ?? []).length;
      delete tq[h];
    }
  }
  await setRaw("threadOpenQueue", tq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved,
    threadOpenIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Verify the PAT can write to the configured branch without creating a
   * commit. Moving a ref to its current SHA is a no-op, but GitHub still
   * enforces the Contents: Write permission required by commitFiles().
   */
  async verifyWriteAccess() {
    const head = await this.getBranchHead();
    await this.fetchJson(
      "PATCH",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
      {
        sha: head.sha,
        force: false
      }
    );
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const unavailableTweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const unavailable = pickUnavailableTweet(raw, ctx);
      if (unavailable) {
        unavailableTweets.push(unavailable);
        observed.push(unavailable.tweet_id);
        built.add(unavailable.tweet_id);
        continue;
      }
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, unavailable_tweets: unavailableTweets, partial_ids };
}
function pickUnavailableTweet(node, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename !== "TweetTombstone") return null;
  const tweetId = strOrNull(n.rest_id) ?? pickTweetIdFromUrls(node) ?? (ctx.sourceUrl ? tweetIdFromTweetUrl(ctx.sourceUrl) : null);
  if (!tweetId || !TWEET_ID_RE.test(tweetId)) return null;
  const unavailableText = pickTombstoneText(node);
  return {
    tweet_id: tweetId,
    account_handle: pickHandleFromTweetUrls(node, tweetId) ?? (ctx.sourceUrl ? handleFromTweetUrl(ctx.sourceUrl, tweetId) : null),
    unavailable_detected_at: ctx.capturedAt,
    unavailable_reason: classifyUnavailableReason(unavailableText),
    unavailable_text: unavailableText,
    unavailable_source_url: ctx.sourceUrl ?? null
  };
}
function pickTweetIdFromUrls(node) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const id = tweetIdFromTweetUrl(cur);
      if (id) return id;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function tweetIdFromTweetUrl(rawUrl) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/[A-Za-z0-9_]{1,15}\/status\/(\d{15,20})(?:\/|$)/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
function pickTombstoneText(node) {
  const strings = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const trimmed = cur.trim();
      if (trimmed.length >= 4 && !trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
        strings.push(trimmed);
      }
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  const preferred = strings.find(
    (s) => /\b(copyright|dmca|unavailable|withheld|removed|deleted|violat|suspended)\b/i.test(s)
  );
  return preferred ?? strings[0] ?? null;
}
function classifyUnavailableReason(text) {
  if (!text) return null;
  if (/\b(copyright|dmca)\b/i.test(text)) return "copyright";
  if (/\bwithheld\b/i.test(text)) return "withheld";
  if (/\bdeleted|removed\b/i.test(text)) return "removed";
  if (/\bsuspended\b/i.test(text)) return "suspended";
  if (/\bunavailable|not available\b/i.test(text)) return "unavailable";
  return null;
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  const hintHandle = pickHintHandle(node, restId);
  if (!hintHandle) return null;
  return { tweet_id: restId, hint_handle: hintHandle };
}
function pickHintHandle(node, tweetId) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name) ?? pickHandleFromTweetUrls(node, tweetId);
}
function pickHandleFromTweetUrls(node, tweetId) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const handle = handleFromTweetUrl(cur, tweetId);
      if (handle) return handle;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function handleFromTweetUrl(rawUrl, tweetId) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d{15,20})(?:\/|$)/);
    if (!match || match[2] !== tweetId) return null;
    return match[1] ?? null;
  } catch {
    return null;
  }
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const retweetedLegacy = obj(obj(obj(legacy.retweeted_status_result)?.result)?.legacy);
  const engLegacy = tweetType === "retweet" && retweetedLegacy ? retweetedLegacy : legacy;
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    unavailable_detected_at: null,
    unavailable_reason: null,
    unavailable_text: null,
    unavailable_source_url: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(engLegacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(engLegacy.reply_count),
    quote_count: numOrZero(engLegacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(engLegacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(engLegacy.reply_count),
        quotes: numOrZero(engLegacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted, coreHandles = /* @__PURE__ */ new Set()) {
  if (targeted.size === 0 && coreHandles.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (coreHandles.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
var MANUAL_CAPTURE_WINDOW_MS = 9e4;
var LOW_BANDWIDTH_BASE_RULE_ID = 760001;
var LOW_BANDWIDTH_MEDIA_RULE_ID_BASE = 760010;
var LOW_BANDWIDTH_RESOURCE_TYPES = ["image", "media", "font"];
var LOW_BANDWIDTH_MEDIA_CHUNK_RESOURCE_TYPES = ["media", "xmlhttprequest", "other"];
var LOW_BANDWIDTH_MEDIA_URL_FILTERS = [
  "||video.twimg.com^",
  "||ton.twimg.com^",
  "||amp.twimg.com^",
  "||video.pscp.tv^",
  "||prod-fastly-us-west-1.video.pscp.tv^",
  "|https://x.com/i/videos/",
  "|https://twitter.com/i/videos/"
];
var manualCaptureUntilMs = 0;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
function allowManualCaptureWindow() {
  manualCaptureUntilMs = Date.now() + MANUAL_CAPTURE_WINDOW_MS;
}
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await syncLowBandwidthRules({ reason: `wake:${reason}`, log: false });
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
function dnrApi() {
  const maybeBrowser = browser;
  return maybeBrowser.declarativeNetRequest ?? null;
}
async function currentXTabIds() {
  const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  return tabs.flatMap((tab) => typeof tab.id === "number" ? [tab.id] : []);
}
async function syncLowBandwidthRules({
  reason,
  log
}) {
  const settings = await getSettings();
  const dnr = dnrApi();
  if (!dnr) {
    if (settings.lowBandwidthBrowsing && log) {
      await warn("low-bandwidth browsing unavailable; declarativeNetRequest API missing", {
        reason
      });
    }
    return;
  }
  const tabIds = settings.lowBandwidthBrowsing ? await currentXTabIds() : [];
  const removeRuleIds = [
    LOW_BANDWIDTH_BASE_RULE_ID,
    ...LOW_BANDWIDTH_MEDIA_URL_FILTERS.map((_, idx) => LOW_BANDWIDTH_MEDIA_RULE_ID_BASE + idx)
  ];
  const addRules = tabIds.length > 0 ? [
    {
      id: LOW_BANDWIDTH_BASE_RULE_ID,
      priority: 1,
      action: { type: "block" },
      condition: {
        tabIds,
        resourceTypes: [...LOW_BANDWIDTH_RESOURCE_TYPES]
      }
    },
    ...LOW_BANDWIDTH_MEDIA_URL_FILTERS.map((urlFilter, idx) => ({
      id: LOW_BANDWIDTH_MEDIA_RULE_ID_BASE + idx,
      priority: 2,
      action: { type: "block" },
      condition: {
        tabIds,
        urlFilter,
        resourceTypes: [...LOW_BANDWIDTH_MEDIA_CHUNK_RESOURCE_TYPES]
      }
    }))
  ] : [];
  await dnr.updateSessionRules({
    removeRuleIds,
    addRules
  });
  if (log) {
    await info("low-bandwidth browsing rules updated", {
      enabled: settings.lowBandwidthBrowsing,
      tab_count: tabIds.length,
      blocked_resource_types: LOW_BANDWIDTH_RESOURCE_TYPES.join(","),
      blocked_media_filters: LOW_BANDWIDTH_MEDIA_URL_FILTERS.join(","),
      reason
    });
  }
}
browser.tabs.onUpdated.addListener((_tabId, changeInfo) => {
  if (changeInfo.url || changeInfo.status === "complete") {
    void syncLowBandwidthRules({ reason: "tab-updated", log: false }).catch((err) => {
      void warn("low-bandwidth rule refresh failed", describeError(err));
    });
  }
});
browser.tabs.onRemoved.addListener(() => {
  void syncLowBandwidthRules({ reason: "tab-removed", log: false }).catch((err) => {
    void warn("low-bandwidth rule refresh failed", describeError(err));
  });
});
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var SHOW_MORE_RELEVANCE_TTL_MS = 10 * 60 * 1e3;
var showMoreRelevantTweetsByTab = /* @__PURE__ */ new Map();
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  allowManualCaptureWindow();
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    ingestedNewCount: 0,
    ingestedExistingCount: 0,
    skippedOldCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let retryCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: () => {
          const normalizedText = (el) => `${el.textContent ?? ""} ${el.getAttribute("aria-label") ?? ""}`.replace(/\s+/g, " ").trim().toLowerCase();
          const clickRetryIfReloadError = () => {
            const bodyText = (document.body?.innerText ?? "").toLowerCase();
            if (!bodyText.includes("something went wrong") && !bodyText.includes("try reloading")) {
              return false;
            }
            const controls = Array.from(
              document.querySelectorAll('button,[role="button"],a[href]')
            );
            const retry = controls.find((el) => {
              const text = normalizedText(el);
              return text === "retry" || text.includes("retry") || text.includes("try again");
            });
            if (!retry) return false;
            retry.click();
            return true;
          };
          if (clickRetryIfReloadError()) return { retried: true, scrolled: false };
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { retried: false, scrolled: true };
        }
      });
      const pageResults = results.map((r) => r.result).filter(
        (result) => typeof result === "object" && result !== null
      );
      if (pageResults.some((result) => result.retried === true)) {
        retryCount += 1;
      }
      if (pageResults.some((result) => result.scrolled === true)) {
        scrollCount += 1;
      }
    } catch {
    }
  }
  if (retryCount > 0) {
    await info("auto-scroll clicked X retry control", { tab_count: retryCount });
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      await setAutoScrollSession(sess);
    }
  }
}
function pruneShowMoreRelevance() {
  const cutoff = Date.now() - SHOW_MORE_RELEVANCE_TTL_MS;
  for (const [tabId, entry] of showMoreRelevantTweetsByTab) {
    if (entry.updatedAt < cutoff) showMoreRelevantTweetsByTab.delete(tabId);
  }
}
function rememberShowMoreRelevantTweets(tabId, pageUrl, tweets, coreHandles) {
  if (tabId === null || tweets.length === 0 || coreHandles.size === 0) return;
  const coreTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (coreHandles.has(t.account_handle.toLowerCase())) coreTweetIds.add(t.tweet_id);
  }
  const existing = showMoreRelevantTweetsByTab.get(tabId);
  const tweetIds = existing?.tweetIds ?? /* @__PURE__ */ new Set();
  for (const t of tweets) {
    const handle = t.account_handle.toLowerCase();
    const replyHandle = t.reply_to_account?.toLowerCase() ?? null;
    if (coreHandles.has(handle) || replyHandle !== null && coreHandles.has(replyHandle) || t.reply_to_tweet_id !== null && coreTweetIds.has(t.reply_to_tweet_id) || t.quoted_tweet_id !== null && coreTweetIds.has(t.quoted_tweet_id) || t.retweeted_tweet_id !== null && coreTweetIds.has(t.retweeted_tweet_id)) {
      tweetIds.add(t.tweet_id);
    }
  }
  showMoreRelevantTweetsByTab.set(tabId, {
    updatedAt: Date.now(),
    pageUrl,
    tweetIds
  });
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async (tab) => {
    try {
      const sidebarAction = browser.sidebarAction;
      if (sidebarAction?.toggle) {
        await sidebarAction.toggle();
        return;
      }
      const sidePanel = browser.sidePanel;
      if (sidePanel?.open) {
        const options = {};
        if (typeof tab.windowId === "number") options.windowId = tab.windowId;
        await sidePanel.open(options);
        return;
      }
      await browser.tabs.create({ url: browser.runtime.getURL("sidebar.html") });
    } catch (err) {
      await warn("sidebar open failed; opening sidebar tab", describeError(err));
      try {
        await browser.tabs.create({ url: browser.runtime.getURL("sidebar.html") });
        return;
      } catch (tabErr) {
        await warn("sidebar tab failed; opening options", describeError(tabErr));
      }
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg, sender).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-thread-open",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg, sender) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(
        msg.endpoint,
        msg.url,
        msg.pageUrl ?? null,
        msg.response,
        sender?.tab?.id ?? null
      );
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-unfold-targets": {
      const settings = await getSettings();
      if (settings.enabled === false) {
        return { enabled: false, coreHandles: [], relevantTweetIds: [] };
      }
      pruneShowMoreRelevance();
      const accounts = await getAccounts();
      const coreHandles = accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase());
      const tabId = sender?.tab?.id ?? null;
      return {
        enabled: true,
        coreHandles,
        relevantTweetIds: tabId === null ? [] : Array.from(showMoreRelevantTweetsByTab.get(tabId)?.tweetIds ?? [])
      };
    }
    case "show-more-unfolded": {
      if (msg.count > 0) {
        const asSess = await getAutoScrollSession();
        if (asSess !== null) {
          asSess.expandedCount += msg.count;
          await setAutoScrollSession(asSess);
        }
      }
      return { ok: true };
    }
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-update-existing":
      await updateSettings({ updateExisting: msg.on });
      await info("update-existing toggled", { on: msg.on });
      return buildState();
    case "toggle-low-bandwidth":
      await updateSettings({ lowBandwidthBrowsing: msg.on });
      await syncLowBandwidthRules({ reason: "toggle", log: true });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        stopThreadOpenInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
        await browser.alarms.clear("thread-open-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      if (threadOpenIntervalHandle !== null) startThreadOpenInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "start-thread-open":
      await startThreadOpenLoop();
      return buildState();
    case "cancel-thread-open":
      await cancelThreadOpenLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, pageUrl, response, senderTabId) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const settings = await getSettings();
  if (settings.enabled === false) return;
  if (settings.autoCapture === false) {
    const explicitCaptureActive = Date.now() < manualCaptureUntilMs || await getAutoScrollSession() !== null || await getRefetchSession() !== null || await getMediaCrawlSession() !== null;
    if (!explicitCaptureActive) return;
  }
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const core = new Set(
    accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase())
  );
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set(),
      sourceUrl: pageUrl
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const retweetEdges = buildRetweetEdges(
    normalized.tweets,
    accounts,
    capturedAt,
    endpoint,
    pageUrl ?? url
  );
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked, core);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  rememberShowMoreRelevantTweets(senderTabId, pageUrl, normalized.tweets, core);
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.unavailable_tweets.length > 0) {
    await recordUnavailableTweets(
      normalized.unavailable_tweets,
      tracked,
      capturedAt,
      url,
      endpoint
    );
  }
  if (normalized.tweets.length === 0) {
    const bufferedEdges = await bufferRetweetEdges(
      retweetEdges,
      capturedAt,
      pageUrl ?? url,
      endpoint
    );
    if (bufferedEdges > 0) await broadcastState();
    return;
  }
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    if (threadOpenSess?.inflight?.tweetId === t.tweet_id) {
      threadOpenSess.inflight = null;
      threadOpenSess.processed += 1;
      await markThreadOpenSeen(t.tweet_id);
      await dequeueThreadOpen(t.tweet_id);
      await setThreadOpenSession(threadOpenSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const updateExisting = settings.updateExisting !== false;
  const committedIdx = await getCommittedIndex();
  const archiveSnapshot = await getArchiveSnapshot();
  let dedupedSkipped = 0;
  let skippedNoUpdateLocal = 0;
  let skippedNoUpdateSnapshot = 0;
  let oldFromSnapshot = 0;
  let fullTextUpgrades = 0;
  const liveTweets = [];
  const freshnessById = /* @__PURE__ */ new Map();
  const actionById = /* @__PURE__ */ new Map();
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const oldBySnapshot = !prev && archiveSnapshotHasTweet(t, archiveSnapshot);
    const previouslyArchived = Boolean(prev) || oldBySnapshot;
    freshnessById.set(t.tweet_id, previouslyArchived ? "existing" : "new");
    if (oldBySnapshot) oldFromSnapshot += 1;
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    const fullTextUpgrade = prev !== void 0 && sigMarksTruncated(prev.sig) && !t.is_truncated;
    if (previouslyArchived && !updateExisting && !fullTextUpgrade) {
      if (prev) skippedNoUpdateLocal += 1;
      else skippedNoUpdateSnapshot += 1;
      actionById.set(t.tweet_id, "skipped");
      continue;
    }
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      actionById.set(t.tweet_id, "unchanged");
      continue;
    }
    if (fullTextUpgrade) fullTextUpgrades += 1;
    actionById.set(t.tweet_id, "buffered");
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (skippedNoUpdateLocal + skippedNoUpdateSnapshot > 0) {
    const skippedOld = skippedNoUpdateLocal + skippedNoUpdateSnapshot;
    await info("dedup: skipped previously archived tweets (updateExisting=false)", {
      endpoint,
      skipped: skippedOld,
      local_index: skippedNoUpdateLocal,
      archive_snapshot: skippedNoUpdateSnapshot,
      remaining: liveTweets.length
    });
    const asSess = await getAutoScrollSession();
    if (asSess !== null) {
      asSess.skippedOldCount = (asSess.skippedOldCount ?? 0) + skippedOld;
      await setAutoScrollSession(asSess);
    }
  }
  if (oldFromSnapshot > 0 && updateExisting) {
    await info("archive snapshot recognized old tweets", {
      endpoint,
      old: oldFromSnapshot,
      action: "buffering because updateExisting=true",
      snapshot_generated_at: archiveSnapshot?.generated_at ?? null
    });
  }
  if (fullTextUpgrades > 0) {
    await info("dedup: buffering full-text upgrades", {
      endpoint,
      upgrades: fullTextUpgrades,
      updateExisting,
      remaining: liveTweets.length
    });
  }
  await prependRecentTweetSightings(
    normalized.tweets.map(
      (t) => buildTweetSighting(
        t,
        endpoint,
        capturedAt,
        freshnessById.get(t.tweet_id),
        actionById.get(t.tweet_id)
      )
    )
  );
  await enqueueMissingParents(normalized.tweets, endpoint);
  await enqueueThreadOpenCandidates(normalized.tweets, core, endpoint);
  const bufferedRetweetEdges = await bufferRetweetEdges(
    retweetEdges,
    capturedAt,
    pageUrl ?? url,
    endpoint
  );
  if (liveTweets.length === 0) {
    if (bufferedRetweetEdges > 0) await broadcastState();
    return;
  }
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    let addedNew = 0;
    let addedExisting = 0;
    let updatedBuffered = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
        updatedBuffered += 1;
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
        if (freshnessById.get(t.tweet_id) === "existing") addedExisting += 1;
        else addedNew += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    if (added > 0 || updatedBuffered > 0) {
      await info("buffered tweets", {
        handle,
        endpoint,
        added,
        new: addedNew,
        existing: addedExisting,
        updated_buffered: updatedBuffered,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        asSess.ingestedNewCount = (asSess.ingestedNewCount ?? 0) + addedNew;
        asSess.ingestedExistingCount = (asSess.ingestedExistingCount ?? 0) + addedExisting;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function recordUnavailableTweets(unavailableTweets, tracked, capturedAt, sourceUrl, endpoint) {
  const committedIdx = await getCommittedIndex();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  let recorded = 0;
  let skipped = 0;
  let missingHandle = 0;
  for (const u of unavailableTweets) {
    const handle = u.account_handle;
    if (!handle) {
      missingHandle += 1;
      await dequeueMediaCrawl(u.tweet_id);
      await dequeueThreadOpen(u.tweet_id);
      continue;
    }
    if (tracked.size > 0 && !tracked.has(handle.toLowerCase())) {
      skipped += 1;
      continue;
    }
    await dequeueMediaCrawl(u.tweet_id);
    await dequeueRefetch(handle, u.tweet_id);
    await dequeueThreadOpen(u.tweet_id);
    if (refetchSess?.inflight?.tweetId === u.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === u.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    if (threadOpenSess?.inflight?.tweetId === u.tweet_id) {
      threadOpenSess.inflight = null;
      threadOpenSess.processed += 1;
      await markThreadOpenSeen(u.tweet_id);
      await setThreadOpenSession(threadOpenSess);
    }
    const sig = unavailableSig(u);
    const prev = committedIdx[handle]?.[u.tweet_id];
    if (prev?.sig === sig) {
      skipped += 1;
      continue;
    }
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const unavailableById = buf.unavailable_by_id ?? {};
    unavailableById[u.tweet_id] = u;
    buf.unavailable_by_id = unavailableById;
    if (!buf.tweet_ids_observed.includes(u.tweet_id)) {
      buf.tweet_ids_observed.push(u.tweet_id);
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    recorded += 1;
  }
  if (recorded > 0 || missingHandle > 0 || skipped > 0) {
    await info("unavailable tweets observed", { endpoint, recorded, skipped, missingHandle });
  }
  await broadcastState();
}
function unavailableSig(u) {
  return `unavailable|${u.unavailable_reason ?? ""}|${u.unavailable_text ?? ""}`;
}
function sigMarksTruncated(sig) {
  const parts = sig.split("|");
  return parts[parts.length - 1] === "t";
}
function runBufferItemCount(buf) {
  return Object.keys(buf.tweets_by_id).length + Object.keys(buf.unavailable_by_id ?? {}).length + Object.keys(buf.retweet_edges_by_key ?? {}).length;
}
function retweetEdgeKey(edge) {
  return [edge.retweeter_handle.toLowerCase(), edge.retweet_tweet_id, edge.original_tweet_id].join(
    "|"
  );
}
function inferRetweetedHandle(text) {
  const match = text.match(/^RT\s+@([A-Za-z0-9_]{1,15})\b/i);
  return match?.[1] ?? null;
}
function buildRetweetEdges(tweets, accounts, capturedAt, endpoint, sourceUrl) {
  const categoryByHandle = new Map(accounts.map((a) => [a.handle.toLowerCase(), a.category]));
  const byId = new Map(tweets.map((t) => [t.tweet_id, t]));
  const out = /* @__PURE__ */ new Map();
  for (const t of tweets) {
    if (t.tweet_type !== "retweet" || !t.retweeted_tweet_id) continue;
    const retweeterCategory = categoryByHandle.get(t.account_handle.toLowerCase());
    if (!retweeterCategory) continue;
    const original = byId.get(t.retweeted_tweet_id);
    const originalHandle = original?.account_handle ?? inferRetweetedHandle(t.text_resolved || t.text);
    const originalCategory = originalHandle ? categoryByHandle.get(originalHandle.toLowerCase()) ?? "public" : null;
    const edge = {
      retweeter_handle: t.account_handle,
      retweeter_account_id: t.account_id ?? null,
      retweeter_category: retweeterCategory,
      retweet_tweet_id: t.tweet_id,
      retweet_url: t.tweet_url,
      original_tweet_id: t.retweeted_tweet_id,
      original_author_handle: originalHandle,
      original_author_account_id: original?.account_id ?? null,
      original_author_category: originalCategory,
      captured_at: capturedAt,
      capture_run_id: "pending",
      endpoint,
      source_url: sourceUrl
    };
    out.set(retweetEdgeKey(edge), edge);
  }
  return [...out.values()];
}
async function bufferRetweetEdges(edges, capturedAt, sourceUrl, endpoint) {
  if (edges.length === 0) return 0;
  const byHandle = /* @__PURE__ */ new Map();
  for (const edge of edges) {
    const arr = byHandle.get(edge.retweeter_handle) ?? [];
    arr.push(edge);
    byHandle.set(edge.retweeter_handle, arr);
  }
  let added = 0;
  for (const [handle, handleEdges] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const edgeMap = buf.retweet_edges_by_key ?? {};
    let addedForHandle = 0;
    for (const edge of handleEdges) {
      const stamped = { ...edge, capture_run_id: buf.run_id };
      const key = retweetEdgeKey(stamped);
      if (!edgeMap[key]) addedForHandle += 1;
      edgeMap[key] = stamped;
      if (!buf.tweet_ids_observed.includes(stamped.retweet_tweet_id)) {
        buf.tweet_ids_observed.push(stamped.retweet_tweet_id);
      }
      if (!buf.tweet_ids_observed.includes(stamped.original_tweet_id)) {
        buf.tweet_ids_observed.push(stamped.original_tweet_id);
      }
    }
    if (addedForHandle === 0) continue;
    buf.retweet_edges_by_key = edgeMap;
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    added += addedForHandle;
    await info("buffered retweet edges", {
      handle,
      endpoint,
      added: addedForHandle,
      total: Object.keys(edgeMap).length
    });
  }
  return added;
}
async function enqueueMissingParents(tweets, endpoint) {
  if (tweets.length === 0) return;
  const sameBatchIds = /* @__PURE__ */ new Set();
  for (const t of tweets) sameBatchIds.add(t.tweet_id);
  let enqueued = 0;
  for (const t of tweets) {
    const parents = [];
    if (t.reply_to_tweet_id) {
      parents.push({ id: t.reply_to_tweet_id, hint: t.reply_to_account });
    }
    if (t.quoted_tweet_id) parents.push({ id: t.quoted_tweet_id, hint: null });
    if (t.retweeted_tweet_id) parents.push({ id: t.retweeted_tweet_id, hint: null });
    for (const p of parents) {
      if (sameBatchIds.has(p.id)) continue;
      if (await isCommitted(p.id)) continue;
      await enqueueMediaCrawl(p.hint, p.id);
      enqueued += 1;
    }
  }
  if (enqueued > 0) {
    await info("queued missing parent tweets for detail-page crawl", {
      endpoint,
      enqueued,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
}
async function enqueueThreadOpenCandidates(tweets, coreHandles, endpoint) {
  if (tweets.length === 0 || coreHandles.size === 0) return;
  if (endpoint.includes("TweetDetail") || endpoint.includes("TweetResultByRestId")) return;
  const candidates = /* @__PURE__ */ new Map();
  for (const t of tweets) {
    const handle = t.account_handle.toLowerCase();
    if (!coreHandles.has(handle)) continue;
    const rootId = t.conversation_id ?? t.tweet_id;
    const isRoot = rootId === t.tweet_id || t.reply_to_tweet_id === null;
    const isCoreReply = t.reply_to_tweet_id !== null;
    if (isRoot && t.reply_count > 0) {
      candidates.set(rootId, t.account_handle);
    } else if (isCoreReply && rootId) {
      candidates.set(rootId, t.account_handle);
    }
  }
  let enqueued = 0;
  for (const [tweetId, handle] of candidates) {
    const before = await threadOpenQueueTotal();
    await enqueueThreadOpen(handle, tweetId);
    const after = await threadOpenQueueTotal();
    if (after > before) enqueued += 1;
  }
  if (enqueued > 0) {
    await info("queued core thread roots for opening", {
      endpoint,
      enqueued,
      queue_total: await threadOpenQueueTotal()
    });
  }
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    unavailable_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    const unavailableTweets = Object.values(buf.unavailable_by_id ?? {});
    const retweetEdges = Object.values(buf.retweet_edges_by_key ?? {});
    if (tweets.length === 0 && unavailableTweets.length === 0 && retweetEdges.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets, unavailableTweets, retweetEdges));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("upload buffer deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length + item.unavailableTweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length + item.unavailableTweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      for (const u of item.unavailableTweets) {
        inner[u.tweet_id] = {
          ts: nowIso,
          sig: unavailableSig(u)
        };
      }
      idx[item.handle] = inner;
      await info("upload buffer committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        unavailable: item.unavailableTweets.length,
        retweet_edges: item.retweetEdges.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("upload buffer batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      unavailable: items.reduce((total, item) => total + item.unavailableTweets.length, 0),
      retweet_edges: items.reduce((total, item) => total + item.retweetEdges.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("upload buffer failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("upload buffer failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets, unavailableTweets, retweetEdges) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    unavailableTweets,
    retweetEdges,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets,
      unavailable_tweets: unavailableTweets,
      retweet_edges: retweetEdges
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    const unavailableCount2 = item.unavailableTweets.length;
    const edgeCount2 = item.retweetEdges.length;
    const suffix2 = (unavailableCount2 > 0 ? `, ${unavailableCount2} unavailable` : "") + (edgeCount2 > 0 ? `, ${edgeCount2} retweet edge${edgeCount2 === 1 ? "" : "s"}` : "");
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"}${suffix2} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  const unavailableCount = items.reduce((total, item) => total + item.unavailableTweets.length, 0);
  const edgeCount = items.reduce((total, item) => total + item.retweetEdges.length, 0);
  const suffix = (unavailableCount > 0 ? `, ${unavailableCount} unavailable` : "") + (edgeCount > 0 ? `, ${edgeCount} retweet edge${edgeCount === 1 ? "" : "s"}` : "");
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"}${suffix} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return runBufferItemCount(current);
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  for (const u of item.unavailableTweets) {
    committed.set(u.tweet_id, unavailableSig(u));
  }
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingUnavailable = {};
  for (const [tweetId, unavailable] of Object.entries(current.unavailable_by_id ?? {})) {
    const committedSig = committed.get(tweetId);
    const currentSig = unavailableSig(unavailable);
    if (!committedSig || committedSig !== currentSig) {
      remainingUnavailable[tweetId] = { ...unavailable };
    }
  }
  const remainingRetweetEdges = {};
  for (const [key, edge] of Object.entries(current.retweet_edges_by_key ?? {})) {
    if (!item.retweetEdges.some((committedEdge) => retweetEdgeKey(committedEdge) === key)) {
      remainingRetweetEdges[key] = { ...edge };
    }
  }
  const remainingIds = /* @__PURE__ */ new Set([
    ...Object.keys(remainingTweets),
    ...Object.keys(remainingUnavailable),
    ...Object.values(remainingRetweetEdges).flatMap((edge) => [
      edge.retweet_tweet_id,
      edge.original_tweet_id
    ])
  ]);
  const remainingCount = Object.keys(remainingTweets).length + Object.keys(remainingUnavailable).length + Object.keys(remainingRetweetEdges).length;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  for (const edge of Object.values(remainingRetweetEdges)) {
    edge.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    unavailable_by_id: remainingUnavailable,
    retweet_edges_by_key: remainingRetweetEdges,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => remainingIds.has(id))
  });
  await info("upload buffer kept newer tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  allowManualCaptureWindow();
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      unavailable_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  allowManualCaptureWindow();
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  allowManualCaptureWindow();
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  allowManualCaptureWindow();
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = target.bucket === "_unknown" ? `https://x.com/i/web/status/${target.tweetId}` : `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
var THREAD_OPEN_TAB_KEY = "__imm_archive_thread_open_tab_id__";
async function getThreadOpenTabId() {
  const stored = await browser.storage.local.get(THREAD_OPEN_TAB_KEY);
  const id = stored[THREAD_OPEN_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setThreadOpenTabId(id) {
  if (id === null) await browser.storage.local.remove(THREAD_OPEN_TAB_KEY);
  else await browser.storage.local.set({ [THREAD_OPEN_TAB_KEY]: id });
}
async function startThreadOpenLoop() {
  allowManualCaptureWindow();
  const total = await threadOpenQueueTotal();
  if (total === 0) {
    await info("thread-open: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setThreadOpenSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startThreadOpenInterval(seconds);
  void threadOpenTick();
  await info("thread-open loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var threadOpenIntervalHandle = null;
function startThreadOpenInterval(seconds) {
  if (threadOpenIntervalHandle !== null) clearInterval(threadOpenIntervalHandle);
  threadOpenIntervalHandle = setInterval(() => {
    void threadOpenTick().catch((err) => {
      void warn("thread-open tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopThreadOpenInterval() {
  if (threadOpenIntervalHandle !== null) {
    clearInterval(threadOpenIntervalHandle);
    threadOpenIntervalHandle = null;
  }
}
async function cancelThreadOpenLoop() {
  stopThreadOpenInterval();
  await browser.alarms.clear("thread-open-tick");
  const tabId = await getThreadOpenTabId();
  await setThreadOpenTabId(null);
  const sess = await getThreadOpenSession();
  await setThreadOpenSession(null);
  await info("thread-open loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function threadOpenTick() {
  let sess = await getThreadOpenSession();
  if (sess === null) {
    stopThreadOpenInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) return;
    await warn("thread-open: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await markThreadOpenSeen(sess.inflight.tweetId);
    await dequeueThreadOpen(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
  }
  const target = await nextThreadOpenTarget();
  if (!target) {
    stopThreadOpenInterval();
    await setThreadOpenTabId(null);
    await setThreadOpenSession(null);
    await info("thread-open loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await hasThreadOpenSeen(target.tweetId)) {
    await dequeueThreadOpen(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getThreadOpenTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id !== "number") throw new Error("created tab without id");
      tabId = tab.id;
      await setThreadOpenTabId(tabId);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    await markThreadOpenSeen(target.tweetId);
    sess = await getThreadOpenSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setThreadOpenSession(sess);
    if (tabId !== null) {
      void nudgeThreadOpenTab(tabId);
    }
    await info("thread-open tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await threadOpenQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("thread-open navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await markThreadOpenSeen(target.tweetId);
    await dequeueThreadOpen(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
  }
  await broadcastState();
}
async function nudgeThreadOpenTab(tabId) {
  await new Promise((resolve) => setTimeout(resolve, 1500));
  try {
    await browser.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        const step = () => window.scrollBy({ top: h * 1.3, behavior: "smooth" });
        step();
        setTimeout(step, 1400);
        setTimeout(step, 2800);
      }
    });
  } catch (err) {
    await warn("thread-open scroll-nudge failed", describeError(err));
  }
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    const checkWrite = force || isWriteAuthError(conn.error);
    if (branchOk && checkWrite) {
      await client.verifyWriteAccess();
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk,
      write_access: checkWrite ? "checked" : "not_checked"
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await refreshArchiveSnapshot(client, force);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function refreshArchiveSnapshot(client, force) {
  const text = await client.fetchRawText("data/manifest.json");
  if (!text) {
    await setArchiveSnapshot(null);
    if (force) await warn("archive manifest not found; old-tweet detection disabled");
    return;
  }
  try {
    const snapshot = parseArchiveSnapshot(JSON.parse(text));
    await setArchiveSnapshot(snapshot);
    if (force) {
      await info("archive snapshot refreshed", {
        accounts: Object.keys(snapshot.accounts).length,
        generated_at: snapshot.generated_at
      });
    }
  } catch (err) {
    await warn("archive snapshot parse failed; old-tweet detection disabled", describeError(err));
  }
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const threadOpenQueued = await threadOpenQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  const autoScrollSess = await getAutoScrollSession();
  const recentTweetSightings = await getRecentTweetSightings();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      ingestedNewCount: autoScrollSess?.ingestedNewCount ?? 0,
      ingestedExistingCount: autoScrollSess?.ingestedExistingCount ?? 0,
      skippedOldCount: autoScrollSess?.skippedOldCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    },
    threadOpenQueue: {
      total: threadOpenQueued,
      running: threadOpenIntervalHandle !== null,
      processed: threadOpenSess?.processed ?? 0,
      total_at_start: threadOpenSess?.totalAtStart ?? 0
    },
    recentTweetSightings
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    updateExisting: s.updateExisting,
    lowBandwidthBrowsing: s.lowBandwidthBrowsing,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function parseArchiveSnapshot(raw) {
  if (!raw || typeof raw !== "object") throw new Error("manifest is not an object");
  const manifest = raw;
  if (!Array.isArray(manifest.accounts)) throw new Error("manifest.accounts is not an array");
  const accounts = {};
  for (const entry of manifest.accounts) {
    if (!entry || typeof entry !== "object") continue;
    const row = entry;
    const handle = typeof row.handle === "string" ? row.handle : "";
    if (!handle || handle === "_misc") continue;
    accounts[handle.toLowerCase()] = {
      handle,
      latest_post_at: typeof row.latest_post_at === "string" ? row.latest_post_at : null,
      latest_capture_at: typeof row.latest_capture_at === "string" ? row.latest_capture_at : null,
      row_count: typeof row.row_count === "number" ? row.row_count : null
    };
  }
  return {
    generated_at: typeof manifest.generated_at === "string" ? manifest.generated_at : null,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    accounts
  };
}
function archiveSnapshotHasTweet(t, snapshot) {
  if (!snapshot) return false;
  const entry = snapshot.accounts[t.account_handle.toLowerCase()];
  if (!entry?.latest_post_at) return false;
  const posted = Date.parse(t.posted_at);
  const latest = Date.parse(entry.latest_post_at);
  return Number.isFinite(posted) && Number.isFinite(latest) && posted <= latest;
}
function buildTweetSighting(t, endpoint, seenAt, freshness = "new", action = "buffered") {
  return {
    tweet_id: t.tweet_id,
    account_handle: t.account_handle,
    posted_at: t.posted_at,
    text: t.text_resolved || t.text,
    tweet_type: t.tweet_type,
    tweet_url: t.tweet_url,
    seen_at: seenAt,
    endpoint,
    archive_status: freshness === "existing" ? "saved" : "new",
    action
  };
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop,
  threadOpenQueue: getThreadOpenQueue,
  startThreadOpen: startThreadOpenLoop,
  cancelThreadOpen: cancelThreadOpenLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHBhdDogJycsXG4gIG93bmVyOiAndmlkcHJvamVjdCcsXG4gIHJlcG86ICd4JyxcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxuICAvLyBpdCBsYXRlciwgdXBkYXRlIFNldHRpbmdzIGJlZm9yZSB0aGUgbmV4dCBjYXB0dXJlLlxuICBicmFuY2g6ICdtYXN0ZXInLFxuICBlbmFibGVkOiB0cnVlLFxuICBhdXRvQ2FwdHVyZTogdHJ1ZSxcbiAgY29uZmlndXJlZEF0OiBudWxsLFxuICBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IDYsXG4gIHVwZGF0ZUV4aXN0aW5nOiB0cnVlLFxuICBsb3dCYW5kd2lkdGhCcm93c2luZzogZmFsc2UsXG59O1xuXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUFYX1NFQyA9IDYwO1xuXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxuLy8gcmVwbyBoYXMgYmVlbiBpbml0aWFsaXplZCBvciBQQVQgbWlzY29uZmlndXJlZCkuIEtlcHQgaW4gc3luYyB3aXRoIHRoZSBmaWxlLlxuZXhwb3J0IGNvbnN0IEZBTExCQUNLX0FDQ09VTlRTOiBBY2NvdW50Q29uZmlnW10gPSBbXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0lDRWdvdicsIGxhYmVsOiAnVS5TLiBJbW1pZ3JhdGlvbiBhbmQgQ3VzdG9tcyBFbmZvcmNlbWVudCcsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdDQlAnLCBsYWJlbDogJ1UuUy4gQ3VzdG9tcyBhbmQgQm9yZGVyIFByb3RlY3Rpb24nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1doaXRlSG91c2UnLCBsYWJlbDogJ1RoZSBXaGl0ZSBIb3VzZScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQcmVzc1NlYycsIGxhYmVsOiAnV2hpdGUgSG91c2UgUHJlc3MgU2VjcmV0YXJ5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnVVNET0wnLCBsYWJlbDogJ1UuUy4gRGVwYXJ0bWVudCBvZiBMYWJvcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSYXBpZFJlc3BvbnNlNDcnLCBsYWJlbDogJ1JhcGlkIFJlc3BvbnNlIDQ3JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1N0ZXBoZW5NJywgbGFiZWw6ICdTdGVwaGVuIE1pbGxlcicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdHcmVnb3J5S0JvdmlubycsIGxhYmVsOiAnR3JlZ29yeSBCb3Zpbm8nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUmVhbFRvbUhvbWFuJywgbGFiZWw6ICdUaG9tYXMgRC4gSG9tYW4nLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG5dO1xuXG4vLyBHcmFwaFFMIGVuZHBvaW50IG5hbWVzIHdlIGNhcmUgYWJvdXQgKG1hdGNoZWQgYnkgc3Vic3RyaW5nIGFnYWluc3QgVVJMIHBhdGgpLlxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG4gICdMaWtlcycsXG4gICdCb29rbWFya3MnLFxuICAnSG9tZVRpbWVsaW5lJyxcbiAgJ0hvbWVMYXRlc3RUaW1lbGluZScsXG4gICdTZWFyY2hUaW1lbGluZScsXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxuXSk7XG5cbi8vIEVuZHBvaW50cyB0aGF0IGNhcnJ5IENvbW11bml0eSBOb3RlIGJvZGllcyBcdTIwMTQgY2FwdHVyZWQgZm9yIGNvbXBsZXRlbmVzcyBidXRcbi8vIHRoZXkgZG9uJ3QgaW50cm9kdWNlIG5ldyB0d2VldHMsIHNvIHRoZXkgZG9uJ3QgbmVlZCB0byBiZSBpbiBUV0VFVF9FTkRQT0lOVFMuXG5leHBvcnQgY29uc3QgQklSRFdBVENIX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnQmlyZHdhdGNoRmV0Y2hPbmVOb3RlJyxcbiAgJ0JpcmR3YXRjaEZldGNoTm90ZXMnLFxuXSk7XG5cbi8vIEF1eGlsaWFyeSBlbmRwb2ludHMgd2UgZG9uJ3QgZXh0cmFjdCB0d2VldHMgZnJvbSBidXQgdXNlIGZvciBjb250ZXh0IChlLmcuLFxuLy8gdG8gbGVhcm4gYWNjb3VudF9pZCA8LT4gaGFuZGxlIGJpbmRpbmdzKS5cbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcblxuLy8gRW5kcG9pbnRzIHdob3NlIHJlc3BvbnNlcyBhcmUgc2NvcGVkIHRvIGEgcGFydGljdWxhciBhY2NvdW50IG9yXG4vLyBjb252ZXJzYXRpb24gXHUyMDE0IGkuZS4gdmlzaXRpbmcgYC88aGFuZGxlPmAgLyBgLzxoYW5kbGU+L3dpdGhfcmVwbGllc2AsXG4vLyBsb29raW5nIGF0IG9uZSB0d2VldCwgZXRjLiBFdmVyeSB0d2VldCByZXR1cm5lZCBieSB0aGVzZSBlbmRwb2ludHMgaXNcbi8vIGVpdGhlciBhdXRob3JlZCBieSB0aGUgdHJhY2tlZCBhY2NvdW50IG9yIGRpcmVjdGx5IHJlZmVyZW5jZWQgYnkgdGhlbVxuLy8gKHJldHdlZXRlZCwgcXVvdGVkLCByZXBsaWVkIHRvKSwgc28gd2Uga2VlcCBldmVyeXRoaW5nIHdlIHNlZSByYXRoZXJcbi8vIHRoYW4gZHJvcHBpbmcgbm9uLXRyYWNrZWQgYXV0aG9ycy4gVGhhdCB3YXkgYSByZXR3ZWV0IG9mIGEgbm9uLXRyYWNrZWRcbi8vIGFjY291bnQgc3RpbGwgZ2V0cyBpdHMgb3JpZ2luYWwtdHdlZXQgY29udGVudCBhcmNoaXZlZC5cbi8vXG4vLyBFbmRwb2ludHMgTk9UIGluIHRoaXMgc2V0IChIb21lVGltZWxpbmUsIFNlYXJjaFRpbWVsaW5lLCBMaWtlcywgZXRjLilcbi8vIHN0aWxsIGdldCBmaWx0ZXJlZCB0byB0cmFja2VkLWhhbmRsZSBhdXRob3JzIFx1MjAxNCBzZWUgdGhlIHNwZWMnc1xuLy8gXCJCcm93c2luZyBteSBob21lIHRpbWVsaW5lIGlzIGlnbm9yZWRcIiBydWxlLlxuZXhwb3J0IGNvbnN0IFVTRVJfUEFHRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuXSk7XG5cbi8vIE1heGltdW0gdHdlZXRzIHRvIGJ1ZmZlciBwZXIgaGFuZGxlIGJlZm9yZSBmb3JjaW5nIGEgY29tbWl0LlxuZXhwb3J0IGNvbnN0IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCA9IDIwMDtcblxuLy8gSWRsZSBkZWxheSBhZnRlciB0aGUgbGFzdCBjYXB0dXJlIGJlZm9yZSBhdXRvLWZsdXNoaW5nIGEgaGFuZGxlJ3MgYnVmZmVyLlxuZXhwb3J0IGNvbnN0IEZMVVNIX0lETEVfTVMgPSA0NV8wMDA7XG5cbi8vIEhvdyBsb25nIGFuIGFsYXJtLWJhc2VkIGZsdXNoIHN3ZWVwIHdhaXRzIGJldHdlZW4gY2hlY2tzLlxuZXhwb3J0IGNvbnN0IEZMVVNIX0FMQVJNX01JTlVURVMgPSAxO1xuXG4vLyBBY3Rpdml0eSB0YWlsIHNpemUuXG5leHBvcnQgY29uc3QgQUNUSVZJVFlfVEFJTF9NQVggPSAyNTA7XG5cbi8vIFBlcmlvZGljIHJlLXZlcmlmaWNhdGlvbiBvZiB0aGUgR2l0SHViIGNvbm5lY3Rpb24gKG1zKS5cbmV4cG9ydCBjb25zdCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyA9IDEwICogNjAgKiAxMDAwO1xuXG5leHBvcnQgY29uc3QgVFdFRVRfVVJMX1BSRUZJWCA9ICdodHRwczovL3guY29tJztcbiIsICIvKipcbiAqIGNyeXB0by50cyBcdTIwMTQgYXQtcmVzdCBlbmNyeXB0aW9uIGZvciBzZW5zaXRpdmUgc2V0dGluZ3MgKHRoZSBQQVQpLlxuICpcbiAqIFRocmVhdCBtb2RlbDogYW4gYXR0YWNrZXIgd2hvIHJlYWRzIGBicm93c2VyLnN0b3JhZ2UubG9jYWxgIChkZXZ0b29scywgYVxuICogZm9yZ290dGVuIGJhY2t1cCwgYSBtaXNjb25maWd1cmVkIHByb2ZpbGUgc3luYykgc2hvdWxkIG5vdCBzZWUgYSB1c2FibGVcbiAqIEdpdEh1YiBQQVQgaW4gcGxhaW50ZXh0LiBBIGRldGVybWluZWQgYXR0YWNrZXIgd2l0aCB0aGUgZXh0ZW5zaW9uJ3Mgc291cmNlXG4gKiBjYW4gc3RpbGwgZGVyaXZlIHRoZSBrZXkgXHUyMDE0IHdlIG1ha2Ugbm8gY2xhaW0gb2YgXCJyZWFsXCIgY3J5cHRvZ3JhcGhpY1xuICogY29uZmlkZW50aWFsaXR5LiBUaGUgYWltIGlzIHRvIHJhaXNlIHRoZSBiYXIgc28gdGhlIFBBVCBpc24ndCBhIGNvcHlhYmxlXG4gKiBzdHJpbmcgc2l0dGluZyBuZXh0IHRvIGl0cyBrZXkgbmFtZSBpbiBleHRlbnNpb24gc3RvcmFnZS5cbiAqXG4gKiBTY2hlbWU6XG4gKiAgIC0gT24gZmlyc3QgZW5jcnlwdGlvbiB3ZSBnZW5lcmF0ZSBhIDMyLWJ5dGUgc2FsdCBhbmQgcGVyc2lzdCBpdCBpblxuICogICAgIGBicm93c2VyLnN0b3JhZ2UubG9jYWxgIHVuZGVyIGBfX2ltbV9hcmNoaXZlX3NhbHRfX2AuXG4gKiAgIC0gV2UgZGVyaXZlIGFuIEFFUy1HQ00ga2V5IGJ5IFNIQS0yNTYnaW5nIGBzYWx0IHx8IHJ1bnRpbWUuaWQgfHwgdmVyc2lvblxuICogICAgIHx8IFwiaW1tLWFyY2hpdmUtcGF0LXYxXCJgLiBUaGUgc2FsdCBiZWluZyBwZXItaW5zdGFsbCBtZWFucyB0d28gY29waWVzXG4gKiAgICAgb2YgdGhlIGV4dGVuc2lvbiBkb24ndCBzaGFyZSBhIGtleS4gVGhlIHJ1bnRpbWUuaWQgaXMgdGhlIGV4dGVuc2lvbidzXG4gKiAgICAgVVVJRCBcdTIwMTQgc3RhYmxlIGZvciBhIGdpdmVuIGluc3RhbGwgYnV0IHVua25vd24gdG8gYSByZW1vdGUgYXR0YWNrZXIuXG4gKiAgIC0gUGxhaW50ZXh0IGlzIGVuY3J5cHRlZCB3aXRoIGEgZnJlc2ggMTItYnl0ZSBJVi4gVGhlIGVudmVsb3BlIGZvcm1hdCBpc1xuICogICAgIGB2MTo8aXYtYjY0Pjo8Y2lwaGVydGV4dC1iNjQ+YCBhbmQgaXMgd2hhdCBnZXRzIHN0b3JlZC5cbiAqXG4gKiBCYWNrd2FyZHMgY29tcGF0aWJpbGl0eTogYW4gdW5wcmVmaXhlZCB2YWx1ZSBpcyB0cmVhdGVkIGFzIGxlZ2FjeVxuICogcGxhaW50ZXh0LCBkZWNyeXB0ZWQgdG8gaXRzZWxmLCBhbmQgcmUtZW5jcnlwdGVkIG9uIHRoZSBuZXh0IHdyaXRlLlxuICovXG5cbmNvbnN0IFNBTFRfU1RPUkFHRV9LRVkgPSAnX19pbW1fYXJjaGl2ZV9zYWx0X18nO1xuY29uc3QgRU5WRUxPUEVfUFJFRklYID0gJ3YxOic7XG5cbmxldCBkZXJpdmVkS2V5Q2FjaGU6IENyeXB0b0tleSB8IG51bGwgPSBudWxsO1xubGV0IGRlcml2ZWRLZXlDYWNoZVNhbHQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiB0b0Jhc2U2NChidWY6IFVpbnQ4QXJyYXkpOiBzdHJpbmcge1xuICBsZXQgcyA9ICcnO1xuICBmb3IgKGNvbnN0IGIgb2YgYnVmKSBzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYik7XG4gIHJldHVybiBidG9hKHMpO1xufVxuXG5mdW5jdGlvbiBmcm9tQmFzZTY0KHM6IHN0cmluZyk6IFVpbnQ4QXJyYXkge1xuICBjb25zdCBiaW4gPSBhdG9iKHMpO1xuICBjb25zdCBvdXQgPSBuZXcgVWludDhBcnJheShiaW4ubGVuZ3RoKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBiaW4ubGVuZ3RoOyBpKyspIG91dFtpXSA9IGJpbi5jaGFyQ29kZUF0KGkpO1xuICByZXR1cm4gb3V0O1xufVxuXG5hc3luYyBmdW5jdGlvbiBsb2FkT3JDcmVhdGVTYWx0KCk6IFByb21pc2U8eyBzYWx0QjY0OiBzdHJpbmc7IHNhbHQ6IFVpbnQ4QXJyYXkgfT4ge1xuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFNBTFRfU1RPUkFHRV9LRVkpO1xuICBjb25zdCB2ID0gc3RvcmVkW1NBTFRfU1RPUkFHRV9LRVldO1xuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xuICAgIHJldHVybiB7IHNhbHRCNjQ6IHYsIHNhbHQ6IGZyb21CYXNlNjQodikgfTtcbiAgfVxuICBjb25zdCBzYWx0ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgzMikpO1xuICBjb25zdCBzYWx0QjY0ID0gdG9CYXNlNjQoc2FsdCk7XG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbU0FMVF9TVE9SQUdFX0tFWV06IHNhbHRCNjQgfSk7XG4gIHJldHVybiB7IHNhbHRCNjQsIHNhbHQgfTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZGVyaXZlS2V5KCk6IFByb21pc2U8Q3J5cHRvS2V5PiB7XG4gIGNvbnN0IHsgc2FsdEI2NCwgc2FsdCB9ID0gYXdhaXQgbG9hZE9yQ3JlYXRlU2FsdCgpO1xuICBpZiAoZGVyaXZlZEtleUNhY2hlICE9PSBudWxsICYmIGRlcml2ZWRLZXlDYWNoZVNhbHQgPT09IHNhbHRCNjQpIHtcbiAgICByZXR1cm4gZGVyaXZlZEtleUNhY2hlO1xuICB9XG4gIGNvbnN0IHNlZWQgPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoXG4gICAgYCR7YnJvd3Nlci5ydW50aW1lLmlkfXwke2Jyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb259fGltbS1hcmNoaXZlLXBhdC12MWBcbiAgKTtcbiAgY29uc3QgY29tYmluZWQgPSBuZXcgVWludDhBcnJheShzZWVkLmxlbmd0aCArIHNhbHQubGVuZ3RoKTtcbiAgY29tYmluZWQuc2V0KHNlZWQsIDApO1xuICBjb21iaW5lZC5zZXQoc2FsdCwgc2VlZC5sZW5ndGgpO1xuICBjb25zdCBoYXNoID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBjb21iaW5lZCk7XG4gIGNvbnN0IGtleSA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuaW1wb3J0S2V5KCdyYXcnLCBoYXNoLCB7IG5hbWU6ICdBRVMtR0NNJyB9LCBmYWxzZSwgW1xuICAgICdlbmNyeXB0JyxcbiAgICAnZGVjcnlwdCcsXG4gIF0pO1xuICBkZXJpdmVkS2V5Q2FjaGUgPSBrZXk7XG4gIGRlcml2ZWRLZXlDYWNoZVNhbHQgPSBzYWx0QjY0O1xuICByZXR1cm4ga2V5O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNFbmNyeXB0ZWRQYXQodjogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiB2LnN0YXJ0c1dpdGgoRU5WRUxPUEVfUFJFRklYKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVuY3J5cHRQYXQocGxhaW50ZXh0OiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBpZiAoIXBsYWludGV4dCkgcmV0dXJuICcnO1xuICBjb25zdCBrZXkgPSBhd2FpdCBkZXJpdmVLZXkoKTtcbiAgY29uc3QgaXYgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEyKSk7XG4gIGNvbnN0IGN0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5lbmNyeXB0KFxuICAgIHsgbmFtZTogJ0FFUy1HQ00nLCBpdiB9LFxuICAgIGtleSxcbiAgICBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUocGxhaW50ZXh0KVxuICApO1xuICByZXR1cm4gYCR7RU5WRUxPUEVfUFJFRklYfSR7dG9CYXNlNjQoaXYpfToke3RvQmFzZTY0KG5ldyBVaW50OEFycmF5KGN0KSl9YDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlY3J5cHRQYXQoZW52ZWxvcGU6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGlmICghZW52ZWxvcGUpIHJldHVybiAnJztcbiAgLy8gTGVnYWN5IHBsYWludGV4dCAocHJlLWVuY3J5cHRpb24gaW5zdGFsbHMpOiBwYXNzIHRocm91Z2guIFRoZSBuZXh0IHNhdmVcbiAgLy8gcmUtZW5jcnlwdHMgaXQgdmlhIHRoZSBzdG9yYWdlIGxheWVyLlxuICBpZiAoIWVudmVsb3BlLnN0YXJ0c1dpdGgoRU5WRUxPUEVfUFJFRklYKSkgcmV0dXJuIGVudmVsb3BlO1xuICBjb25zdCBwYXJ0cyA9IGVudmVsb3BlLnNsaWNlKEVOVkVMT1BFX1BSRUZJWC5sZW5ndGgpLnNwbGl0KCc6Jyk7XG4gIGlmIChwYXJ0cy5sZW5ndGggIT09IDIpIHJldHVybiAnJztcbiAgY29uc3QgW2l2QjY0LCBjdEI2NF0gPSBwYXJ0cztcbiAgaWYgKCFpdkI2NCB8fCAhY3RCNjQpIHJldHVybiAnJztcbiAgdHJ5IHtcbiAgICBjb25zdCBrZXkgPSBhd2FpdCBkZXJpdmVLZXkoKTtcbiAgICBjb25zdCBpdiA9IGZyb21CYXNlNjQoaXZCNjQpO1xuICAgIGNvbnN0IGN0ID0gZnJvbUJhc2U2NChjdEI2NCk7XG4gICAgY29uc3QgcHQgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRlY3J5cHQoXG4gICAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXY6IGl2IGFzIEJ1ZmZlclNvdXJjZSB9LFxuICAgICAga2V5LFxuICAgICAgY3QgYXMgQnVmZmVyU291cmNlXG4gICAgKTtcbiAgICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKHB0KTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuICcnO1xuICB9XG59XG4iLCAiaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUywgRkFMTEJBQ0tfQUNDT1VOVFMsIEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9jb25maWcuanMnO1xuaW1wb3J0IHsgZGVjcnlwdFBhdCwgZW5jcnlwdFBhdCwgaXNFbmNyeXB0ZWRQYXQgfSBmcm9tICcuL2NyeXB0by5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIEFjY291bnRDb25maWcsXG4gIEFjY291bnRDb3VudGVyLFxuICBBcmNoaXZlU25hcHNob3QsXG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDb25uZWN0aW9uU3RhdGUsXG4gIExvZ0V2ZW50LFxuICBSZXR3ZWV0RWRnZSxcbiAgU2V0dGluZ3MsXG4gIFR3ZWV0U2lnaHRpbmcsXG4gIFVuYXZhaWxhYmxlVHdlZXQsXG59IGZyb20gJy4vdHlwZXMuanMnO1xuXG4vKipcbiAqIEJ1ZmZlcmVkIHR3ZWV0cyBmb3IgYSBnaXZlbiBhY2NvdW50LCBhd2FpdGluZyBjb21taXQuIEEgXCJydW5cIiBpcyBvbmUgZW50cnlcbiAqIGluIHRoaXMgbWFwOyBmbHVzaGluZyBjbGVhcnMgdGhlIGVudHJ5LiBXZSBzdG9yZSBhcyBSZWNvcmQgc28gdGhlIHN0cnVjdHVyZVxuICogc3Vydml2ZXMgSlNPTiBzZXJpYWxpemF0aW9uIHRocm91Z2ggYnJvd3Nlci5zdG9yYWdlLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFJ1bkJ1ZmZlciB7XG4gIHJ1bl9pZDogc3RyaW5nO1xuICBhY2NvdW50X2hhbmRsZTogc3RyaW5nO1xuICBzdGFydGVkX2F0OiBzdHJpbmc7XG4gIGxhc3RfY2FwdHVyZV9hdDogc3RyaW5nO1xuICB0d2VldHNfYnlfaWQ6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PjtcbiAgdW5hdmFpbGFibGVfYnlfaWQ/OiBSZWNvcmQ8c3RyaW5nLCBVbmF2YWlsYWJsZVR3ZWV0PjtcbiAgcmV0d2VldF9lZGdlc19ieV9rZXk/OiBSZWNvcmQ8c3RyaW5nLCBSZXR3ZWV0RWRnZT47XG4gIHR3ZWV0X2lkc19vYnNlcnZlZDogc3RyaW5nW107XG4gIGVuZHBvaW50c19zZWVuOiBzdHJpbmdbXTtcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcbn1cblxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxuICogVXNlZCB0byBza2lwIHJlLWNhcHR1cmluZyB0d2VldHMgd2UndmUgYWxyZWFkeSBwdXNoZWQgd2l0aCBpZGVudGljYWxcbiAqIGVuZ2FnZW1lbnQgY291bnRzIFx1MjAxNCBhdm9pZHMgZ2VuZXJhdGluZyBvbmUgbmV3IHJhdy8qIGZpbGUgZXZlcnkgYnJvd3NlLiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XG4gIHRzOiBzdHJpbmc7IC8vIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3QgY29tbWl0XG4gIHNpZzogc3RyaW5nOyAvLyBlbmdhZ2VtZW50IHNpZ25hdHVyZTogXCJsaWtlfHJ0fHJlcGx5fHF1b3RlXCJcbn1cblxuLyoqIFByb2dyZXNzICsgaW5mbGlnaHQgdHJhY2tpbmcgZm9yIGEgcXVldWUtZHJpdmVuIGxvb3AgKHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCkuXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcbiAqIFwiWCBvZiBZIHByb2Nlc3NlZFwiIFx1MjAxNCBhbmQgdGhlIHdhaXQtZm9yLWluZ2VzdCBndWFyZCBrbm93cyB3aGF0IHRvIGV4cGVjdC5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XG4gIC8qKiBJbml0aWFsIHF1ZXVlIHNpemUgd2hlbiB0aGUgdXNlciBjbGlja2VkIFwiU3RhcnRcIi4gKi9cbiAgdG90YWxBdFN0YXJ0OiBudW1iZXI7XG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cbiAgcHJvY2Vzc2VkOiBudW1iZXI7XG4gIC8qKiBJU08gb2Ygd2hlbiB0aGlzIHNlc3Npb24gc3RhcnRlZC4gKi9cbiAgc3RhcnRlZEF0OiBzdHJpbmc7XG4gIC8qKiBUd2VldCBjdXJyZW50bHkgaW5mbGlnaHQgXHUyMDE0IHdlIG5hdmlnYXRlZCB0byBpdCBhbmQgYXJlIHdhaXRpbmcgZm9yIHRoZVxuICAgKiBwYWdlLWhvb2sgdG8gY2FwdHVyZSB0aGUgcmVzcG9uc2UgYmVmb3JlIGFkdmFuY2luZy4gbnVsbCBiZXR3ZWVuIHRpY2tzXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xuICBpbmZsaWdodDogeyB0d2VldElkOiBzdHJpbmc7IG5hdmlnYXRlZEF0OiBzdHJpbmcgfSB8IG51bGw7XG59XG5cbi8qKiBBdXRvLXNjcm9sbCBzZXNzaW9uOiBjb3VudHMgb2YgdGlja3MgYW5kIHR3ZWV0cyBpbmdlc3RlZCBzaW5jZSB0aGUgdXNlclxuICogY2xpY2tlZCBTdGFydC4gUGVyc2lzdGVkIHNvIFNXIGV2aWN0aW9uIGR1cmluZyBhIHJ1biBrZWVwcyBwcm9ncmVzcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xuICBzdGFydGVkQXQ6IHN0cmluZztcbiAgc2Nyb2xsQ291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xuICBpbmdlc3RlZE5ld0NvdW50OiBudW1iZXI7XG4gIGluZ2VzdGVkRXhpc3RpbmdDb3VudDogbnVtYmVyO1xuICBza2lwcGVkT2xkQ291bnQ6IG51bWJlcjtcbiAgZXhwYW5kZWRDb3VudDogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgU3RvcmFnZVNoYXBlIHtcbiAgc2V0dGluZ3M6IFNldHRpbmdzO1xuICBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdO1xuICAvKiogSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBzdWNjZXNzZnVsIGFjY291bnRzLnlhbWwgZmV0Y2ggZnJvbSB0aGUgcmVwby5cbiAgICogVXNlZCBieSBgcmVmcmVzaEFjY291bnRzTGlzdGAgdG8gc2tpcCByZS1mZXRjaGluZyBvbiBldmVyeSBTVyB3YWtlIFx1MjAxNCB0aGVcbiAgICogZmlsZSBjaGFuZ2VzIHJhcmVseSBhbmQgYW4gYXV0aGVudGljYXRlZCByYXcgZmV0Y2ggZXZlcnkgd2FrZSBhZGRzIHVwLiAqL1xuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBzdHJpbmcgfCBudWxsO1xuICBhcmNoaXZlU25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGw7XG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcbiAgY291bnRlcnM6IFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPjtcbiAgcnVuQnVmZmVyczogUmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPjtcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XG4gIHJlY2VudFR3ZWV0U2lnaHRpbmdzOiBUd2VldFNpZ2h0aW5nW107XG4gIGNvbW1pdHRlZEluZGV4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+O1xuICAvKiogVHdlZXRzIHRoZSBub3JtYWxpemVyIGZsYWdnZWQgYXMgdHJ1bmNhdGVkIGFuZCB0aGF0IHdlIGhhdmVuJ3Qgc2VlbiBhXG4gICAqIGZ1bGwtdGV4dCB2ZXJzaW9uIG9mIHlldC4gS2V5ZWQgYnkgaGFuZGxlIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuICovXG4gIHJlZmV0Y2hRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogVHdlZXQgSURzIHNlZW4gdmlhIE1lZGlhLXRhYiAvIHBhcnRpYWwgY2FwdHVyZXMgdGhhdCBjb3VsZG4ndCBiZVxuICAgKiBub3JtYWxpemVkIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gS2V5ZWQgYnkgaGludC1oYW5kbGUgKG9yXG4gICAqIFwiX3Vua25vd25cIikgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gVGhlIHVzZXIgY2FuIGRyaXZlIGEgY3Jhd2wgdGhhdFxuICAgKiBvcGVucyBlYWNoIGRldGFpbCBwYWdlIHRvIGNhcHR1cmUgdGhlIHJlYWwgdGhpbmcuICovXG4gIG1lZGlhQ3Jhd2xRdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogQ29yZS1hY2NvdW50IHRocmVhZCByb290cyB3b3J0aCBvcGVuaW5nIGJlY2F1c2UgdGltZWxpbmUvc2VhcmNoIHZpZXdzIG1heVxuICAgKiBvbWl0IGxhdGVyIHNlbGYtcmVwbGllcy4gS2V5ZWQgYnkgaGludC1oYW5kbGUgLT4gcm9vdCB0d2VldCBpZHMuICovXG4gIHRocmVhZE9wZW5RdWV1ZTogUmVjb3JkPHN0cmluZywgc3RyaW5nW10+O1xuICAvKiogUm9vdCB0d2VldCBpZHMgYWxyZWFkeSBhdHRlbXB0ZWQgYnkgdGhlIHRocmVhZC1vcGVuaW5nIHV0aWxpdHkuICovXG4gIHRocmVhZE9wZW5TZWVuOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuICByZWZldGNoU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBtZWRpYUNyYXdsU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICB0aHJlYWRPcGVuU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xuICBhdXRvU2Nyb2xsU2Vzc2lvbjogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsO1xufVxuXG5jb25zdCBERUZBVUxUX0NPTk5FQ1RJT046IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgc3RhdHVzOiAndW5rbm93bicsXG4gIGxvZ2luOiBudWxsLFxuICBjaGVja2VkQXQ6IG51bGwsXG4gIGVycm9yOiBudWxsLFxuICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxufTtcblxuY29uc3QgREVGQVVMVFM6IFN0b3JhZ2VTaGFwZSA9IHtcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9LFxuICBhY2NvdW50czogWy4uLkZBTExCQUNLX0FDQ09VTlRTXSxcbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogbnVsbCxcbiAgYXJjaGl2ZVNuYXBzaG90OiBudWxsLFxuICBjb25uZWN0aW9uOiB7IC4uLkRFRkFVTFRfQ09OTkVDVElPTiB9LFxuICBjb3VudGVyczoge30sXG4gIHJ1bkJ1ZmZlcnM6IHt9LFxuICBhY3Rpdml0eTogW10sXG4gIHJlY2VudFR3ZWV0U2lnaHRpbmdzOiBbXSxcbiAgY29tbWl0dGVkSW5kZXg6IHt9LFxuICByZWZldGNoUXVldWU6IHt9LFxuICBtZWRpYUNyYXdsUXVldWU6IHt9LFxuICB0aHJlYWRPcGVuUXVldWU6IHt9LFxuICB0aHJlYWRPcGVuU2Vlbjoge30sXG4gIHJlZmV0Y2hTZXNzaW9uOiBudWxsLFxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcbiAgdGhyZWFkT3BlblNlc3Npb246IG51bGwsXG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBudWxsLFxufTtcblxuYXN5bmMgZnVuY3Rpb24gZ2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSyk6IFByb21pc2U8U3RvcmFnZVNoYXBlW0tdPiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoa2V5KTtcbiAgY29uc3QgdmFsdWUgPSByZXN1bHRba2V5XTtcbiAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gc3RydWN0dXJlZENsb25lKERFRkFVTFRTW2tleV0pO1xuICB9XG4gIHJldHVybiB2YWx1ZSBhcyBTdG9yYWdlU2hhcGVbS107XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEssIHZhbHVlOiBTdG9yYWdlU2hhcGVbS10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtrZXldOiB2YWx1ZSB9KTtcbn1cblxuLy8gLS0tIFNldHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNldHRpbmdzKCk6IFByb21pc2U8U2V0dGluZ3M+IHtcbiAgLy8gQmFja2ZpbGwgYW55IGtleXMgdGhlIHVzZXIncyBzdG9yZWQgc2V0dGluZ3MgcHJlZGF0ZSBcdTIwMTQgcmVhZGVycyBjYW4gcmVseVxuICAvLyBvbiBldmVyeSBTZXR0aW5ncyBmaWVsZCBiZWluZyBwcmVzZW50IHJhdGhlciB0aGFuIGA/PyBkZWZhdWx0aW5nYCBhdFxuICAvLyBldmVyeSBjYWxsc2l0ZS4gVGhlIFBBVCBpcyBzdG9yZWQgZW5jcnlwdGVkLWF0LXJlc3QgYXMgb2YgdjAuMi4wOyB3ZVxuICAvLyBkZWNyeXB0IHRyYW5zcGFyZW50bHkgc28gY2FsbGVycyBjb250aW51ZSB0byBzZWUgcGxhaW50ZXh0LlxuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBnZXRSYXcoJ3NldHRpbmdzJyk7XG4gIGNvbnN0IG1lcmdlZCA9IHsgLi4uREVGQVVMVF9TRVRUSU5HUywgLi4uc3RvcmVkIH07XG4gIGlmIChtZXJnZWQucGF0ICYmIGlzRW5jcnlwdGVkUGF0KG1lcmdlZC5wYXQpKSB7XG4gICAgdHJ5IHtcbiAgICAgIG1lcmdlZC5wYXQgPSBhd2FpdCBkZWNyeXB0UGF0KG1lcmdlZC5wYXQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgbWVyZ2VkLnBhdCA9ICcnO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbWVyZ2VkO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIEVuY3J5cHQgdGhlIFBBVCBiZWZvcmUgcGVyc2lzdGluZzsgbGVnYWN5IHBsYWludGV4dCBQQVRzIGdldCB1cGdyYWRlZFxuICAvLyBvbiB0aGUgbmV4dCBzYXZlLlxuICBjb25zdCB0b1dyaXRlOiBTZXR0aW5ncyA9IHsgLi4ucyB9O1xuICBpZiAodG9Xcml0ZS5wYXQgJiYgIWlzRW5jcnlwdGVkUGF0KHRvV3JpdGUucGF0KSkge1xuICAgIHRvV3JpdGUucGF0ID0gYXdhaXQgZW5jcnlwdFBhdCh0b1dyaXRlLnBhdCk7XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdzZXR0aW5ncycsIHRvV3JpdGUpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHBhdGNoOiBQYXJ0aWFsPFNldHRpbmdzPik6IFByb21pc2U8U2V0dGluZ3M+IHtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgbmV4dCA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xuICBhd2FpdCBzZXRTZXR0aW5ncyhuZXh0KTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbi8vIC0tLSBBY2NvdW50cyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50cygpOiBQcm9taXNlPEFjY291bnRDb25maWdbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50cycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzKGE6IEFjY291bnRDb25maWdbXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzJywgYSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzUmVmcmVzaGVkQXQoaXNvOiBzdHJpbmcgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHNSZWZyZXNoZWRBdCcsIGlzbyk7XG59XG5cbi8vIC0tLSBBcmNoaXZlIHNuYXBzaG90IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFyY2hpdmVTbmFwc2hvdCgpOiBQcm9taXNlPEFyY2hpdmVTbmFwc2hvdCB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYXJjaGl2ZVNuYXBzaG90Jyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBcmNoaXZlU25hcHNob3Qoc25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhcmNoaXZlU25hcHNob3QnLCBzbmFwc2hvdCk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHN0YXRlIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbm5lY3Rpb24oKTogUHJvbWlzZTxDb25uZWN0aW9uU3RhdGU+IHtcbiAgY29uc3QgYyA9IGF3YWl0IGdldFJhdygnY29ubmVjdGlvbicpO1xuICAvLyBCYWNrZmlsbCBmaWVsZHMgYWRkZWQgYWZ0ZXIgdGhlIHVzZXIncyBzdG9yYWdlIHdhcyB3cml0dGVuLlxuICBjb25zdCBvdXQ6IENvbm5lY3Rpb25TdGF0ZSA9IHtcbiAgICAuLi5jLFxuICAgIGRlZmF1bHRCcmFuY2g6IGMuZGVmYXVsdEJyYW5jaCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuZGVmYXVsdEJyYW5jaCxcbiAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOlxuICAgICAgYy5jb25maWd1cmVkQnJhbmNoRXhpc3RzID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxuICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGMucmF0ZUxpbWl0UmVzZXRBdCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMucmF0ZUxpbWl0UmVzZXRBdCxcbiAgfTtcbiAgcmV0dXJuIG91dDtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb25uZWN0aW9uKGM6IENvbm5lY3Rpb25TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2Nvbm5lY3Rpb24nLCBjKTtcbn1cblxuLy8gLS0tIENvdW50ZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZnVuY3Rpb24gdG9kYXlJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb3VudGVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIEFjY291bnRDb3VudGVyPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb3VudGVycycpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGJ1bXBDb3VudGVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgcGF0Y2g6IFBhcnRpYWw8QWNjb3VudENvdW50ZXI+XG4pOiBQcm9taXNlPEFjY291bnRDb3VudGVyPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGNvbnN0IGN1ciA9IGFsbFtoYW5kbGVdID8/IHtcbiAgICB0b2RheUNvdW50OiAwLFxuICAgIHRvZGF5RGF0ZTogdG9kYXlJU08oKSxcbiAgICBsYXN0Q2FwdHVyZUF0OiBudWxsLFxuICAgIHRvdGFsQ29tbWl0dGVkOiAwLFxuICAgIGJ1ZmZlcmVkQ291bnQ6IDAsXG4gIH07XG4gIGlmIChjdXIudG9kYXlEYXRlICE9PSB0b2RheUlTTygpKSB7XG4gICAgY3VyLnRvZGF5RGF0ZSA9IHRvZGF5SVNPKCk7XG4gICAgY3VyLnRvZGF5Q291bnQgPSAwO1xuICB9XG4gIGNvbnN0IG5leHQ6IEFjY291bnRDb3VudGVyID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGFsbFtoYW5kbGVdID0gbmV4dDtcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGFsbCk7XG4gIHJldHVybiBuZXh0O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QnVmZmVyZWRDb3VudChoYW5kbGU6IHN0cmluZywgY291bnQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBidW1wQ291bnRlcihoYW5kbGUsIHsgYnVmZmVyZWRDb3VudDogY291bnQgfSk7XG59XG5cbi8vIC0tLSBSdW4gYnVmZmVycyAodGhlIHBlbmRpbmcgY2FwdHVyZXMgYXdhaXRpbmcgY29tbWl0KSAtLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3J1bkJ1ZmZlcnMnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8UnVuQnVmZmVyIHwgbnVsbD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIHJldHVybiBhbGxbaGFuZGxlXSA/PyBudWxsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nLCBidWY6IFJ1bkJ1ZmZlcik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGFsbFtoYW5kbGVdID0gYnVmO1xuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBkZWxldGUgYWxsW2hhbmRsZV07XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbi8vIC0tLSBBY3Rpdml0eSB0YWlsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY3Rpdml0eSgpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcbiAgcmV0dXJuIGdldFJhdygnYWN0aXZpdHknKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGVuZEFjdGl2aXR5KGV2OiBMb2dFdmVudCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRBY3Rpdml0eSgpO1xuICBjdXIudW5zaGlmdChldik7XG4gIGlmIChjdXIubGVuZ3RoID4gQUNUSVZJVFlfVEFJTF9NQVgpIGN1ci5sZW5ndGggPSBBQ1RJVklUWV9UQUlMX01BWDtcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIGN1cik7XG4gIHJldHVybiBjdXI7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFjdGl2aXR5KCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgW10pO1xufVxuXG4vLyAtLS0gUmVjZW50IHR3ZWV0IHNpZ2h0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuY29uc3QgUkVDRU5UX1RXRUVUX1NJR0hUSU5HU19NQVggPSA4MDtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk6IFByb21pc2U8VHdlZXRTaWdodGluZ1tdPiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlY2VudFR3ZWV0U2lnaHRpbmdzJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVwZW5kUmVjZW50VHdlZXRTaWdodGluZ3Mocm93czogVHdlZXRTaWdodGluZ1tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncygpO1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IG5leHQ6IFR3ZWV0U2lnaHRpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHJvdyBvZiByb3dzKSB7XG4gICAgY29uc3Qga2V5ID0gYCR7cm93LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCl9OiR7cm93LnR3ZWV0X2lkfWA7XG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGtleSk7XG4gICAgbmV4dC5wdXNoKHJvdyk7XG4gIH1cbiAgZm9yIChjb25zdCByb3cgb2YgY3VyKSB7XG4gICAgY29uc3Qga2V5ID0gYCR7cm93LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCl9OiR7cm93LnR3ZWV0X2lkfWA7XG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGtleSk7XG4gICAgbmV4dC5wdXNoKHJvdyk7XG4gIH1cbiAgbmV4dC5sZW5ndGggPSBNYXRoLm1pbihuZXh0Lmxlbmd0aCwgUkVDRU5UX1RXRUVUX1NJR0hUSU5HU19NQVgpO1xuICBhd2FpdCBzZXRSYXcoJ3JlY2VudFR3ZWV0U2lnaHRpbmdzJywgbmV4dCk7XG59XG5cbi8vIC0tLSBDb21taXR0ZWQtdHdlZXRzIGRlZHVwIGluZGV4IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvbW1pdHRlZEluZGV4KCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+Pj4ge1xuICByZXR1cm4gZ2V0UmF3KCdjb21taXR0ZWRJbmRleCcpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29tbWl0dGVkSW5kZXgoXG4gIGlkeDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PlxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29tbWl0dGVkSW5kZXgnLCBpZHgpO1xufVxuXG4vKiogQ29tcHV0ZSB0aGUgZW5nYWdlbWVudCBzaWduYXR1cmUgd2UgdXNlIHRvIGRlY2lkZSB3aGV0aGVyIGEgcmUtY2FwdHVyZWRcbiAqIHR3ZWV0IGlzIFwibWF0ZXJpYWxseSBkaWZmZXJlbnRcIiBmcm9tIHdoYXQgd2UgbGFzdCBjb21taXR0ZWQuIFdlIG9taXRcbiAqIHZpZXdfY291bnQgYmVjYXVzZSBpdCB0aWNrcyB1cCBmcmVxdWVudGx5IG9uIGFjdGl2ZSB0d2VldHMgYW5kIHdvdWxkXG4gKiBkZWZlYXQgdGhlIGRlZHVwLiBMaWtlcyAvIFJUcyAvIHJlcGxpZXMgLyBxdW90ZXMgY2hhbmdlIHJhcmVseSBlbm91Z2ggdGhhdFxuICogZWFjaCBjaGFuZ2UgaXMgd29ydGggYSByZS1jb21taXQgKGFuZCBhbiBlbmdhZ2VtZW50X2hpc3Rvcnkgc25hcHNob3QpLlxuICogYGlzX3RydW5jYXRlZGAgaXMgZm9sZGVkIGluIHNvIGEgcmVmZXRjaCB0aGF0IHN3YXBzIHRoZSAyODAtY2hhciBoZWFkIGZvclxuICogdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkgYnlwYXNzZXMgdGhlIGRlZHVwIGV2ZW4gd2hlbiBlbmdhZ2VtZW50IGNvdW50c1xuICogaGF2ZW4ndCBtb3ZlZCBcdTIwMTQgb3RoZXJ3aXNlIHRoZSBuZXcgYm9keSB3b3VsZCBiZSBzaWxlbnRseSBkcm9wcGVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuZ2FnZW1lbnRTaWcoXG4gIGxpa2VzOiBudW1iZXIsXG4gIHJldHdlZXRzOiBudW1iZXIsXG4gIHJlcGxpZXM6IG51bWJlcixcbiAgcXVvdGVzOiBudW1iZXIsXG4gIGlzVHJ1bmNhdGVkOiBib29sZWFuID0gZmFsc2Vcbik6IHN0cmluZyB7XG4gIHJldHVybiBgJHtsaWtlc318JHtyZXR3ZWV0c318JHtyZXBsaWVzfXwke3F1b3Rlc318JHtpc1RydW5jYXRlZCA/ICd0JyA6ICdmJ31gO1xufVxuXG4vKiogRHJvcCBlbnRyaWVzIG9sZGVyIHRoYW4gYG1heEFnZU1zYC4gUmV0dXJucyB0aGUgbnVtYmVyIHBydW5lZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcnVuZUNvbW1pdHRlZEluZGV4KG1heEFnZU1zOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBjb25zdCBjdXRvZmYgPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gbWF4QWdlTXMpLnRvSVNPU3RyaW5nKCk7XG4gIGxldCBwcnVuZWQgPSAwO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgY29uc3QgaW5uZXIgPSBpZHhbaGFuZGxlXTtcbiAgICBpZiAoIWlubmVyKSBjb250aW51ZTtcbiAgICBmb3IgKGNvbnN0IHRpZCBvZiBPYmplY3Qua2V5cyhpbm5lcikpIHtcbiAgICAgIGNvbnN0IGUgPSBpbm5lclt0aWRdO1xuICAgICAgaWYgKGUgJiYgZS50cyA8IGN1dG9mZikge1xuICAgICAgICBkZWxldGUgaW5uZXJbdGlkXTtcbiAgICAgICAgcHJ1bmVkICs9IDE7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhpbm5lcikubGVuZ3RoID09PSAwKSBkZWxldGUgaWR4W2hhbmRsZV07XG4gIH1cbiAgaWYgKHBydW5lZCA+IDApIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG4gIHJldHVybiBwcnVuZWQ7XG59XG5cbi8vIC0tLSBSZWZldGNoIHF1ZXVlICh0d2VldHMgbmVlZGluZyBmdWxsLXRleHQgcmVjYXB0dXJlKSAtLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hRdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbaGFuZGxlXSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdO1xuICBpZiAoIWlkcykgcmV0dXJuO1xuICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2hhbmRsZV07XG4gIGVsc2UgcVtoYW5kbGVdID0gZmlsdGVyZWQ7XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0UmVmZXRjaFRhcmdldCgpOiBQcm9taXNlPHtcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIHR3ZWV0SWQ6IHN0cmluZztcbn0gfCBudWxsPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBoYW5kbGUsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLy8gLS0tIE1lZGlhLWNyYXdsIHF1ZXVlIChwYXJ0aWFsIGNhcHR1cmVzIGF3YWl0aW5nIGRldGFpbC1wYWdlIGZldGNoKSAtLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtZWRpYUNyYXdsUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVNZWRpYUNyYXdsKGhpbnRIYW5kbGU6IHN0cmluZyB8IG51bGwsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGNvbnN0IGJ1Y2tldCA9IGhpbnRIYW5kbGUgPz8gJ191bmtub3duJztcbiAgY29uc3QgaWRzID0gcVtidWNrZXRdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbYnVja2V0XSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlTWVkaWFDcmF3bCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcbiAgICBpZiAoIWlkcykgY29udGludWU7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XG4gICAgfVxuICB9XG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTogUHJvbWlzZTx7XG4gIGJ1Y2tldDogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2J1Y2tldCwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgYnVja2V0LCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8vIC0tLSBUaHJlYWQtb3BlbmluZyBxdWV1ZSAoY29yZSBjb252ZXJzYXRpb24gcm9vdHMgdG8gdmlzaXQpIC0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRocmVhZE9wZW5RdWV1ZSgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICByZXR1cm4gZ2V0UmF3KCd0aHJlYWRPcGVuUXVldWUnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRocmVhZE9wZW5RdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcbiAgbGV0IHRvdGFsID0gMDtcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcbiAgcmV0dXJuIHRvdGFsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFzVGhyZWFkT3BlblNlZW4odHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHNlZW4gPSBhd2FpdCBnZXRSYXcoJ3RocmVhZE9wZW5TZWVuJyk7XG4gIHJldHVybiB0d2VldElkIGluIHNlZW47XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtYXJrVGhyZWFkT3BlblNlZW4odHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHNlZW4gPSBhd2FpdCBnZXRSYXcoJ3RocmVhZE9wZW5TZWVuJyk7XG4gIHNlZW5bdHdlZXRJZF0gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblNlZW4nLCBzZWVuKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVUaHJlYWRPcGVuKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGF3YWl0IGhhc1RocmVhZE9wZW5TZWVuKHR3ZWV0SWQpKSByZXR1cm47XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdID8/IFtdO1xuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xuICAgIHFbaGFuZGxlXSA9IGlkcztcbiAgICBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5RdWV1ZScsIHEpO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlVGhyZWFkT3Blbih0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xuICAgIGNvbnN0IGlkcyA9IHFbYnVja2V0XTtcbiAgICBpZiAoIWlkcykgY29udGludWU7XG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggIT09IGlkcy5sZW5ndGgpIHtcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcbiAgICAgIGVsc2UgcVtidWNrZXRdID0gZmlsdGVyZWQ7XG4gICAgfVxuICB9XG4gIGlmIChjaGFuZ2VkKSBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5RdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dFRocmVhZE9wZW5UYXJnZXQoKTogUHJvbWlzZTx7XG4gIGhhbmRsZTogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgaGFuZGxlLCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXG4gKiBlbnF1ZXVlaW5nIG1lZGlhLWNyYXdsIHRhcmdldHMgd2UndmUgYWxyZWFkeSBhcmNoaXZlZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpc0NvbW1pdHRlZCh0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgZm9yIChjb25zdCBpbm5lciBvZiBPYmplY3QudmFsdWVzKGlkeCkpIHtcbiAgICBpZiAoaW5uZXIgJiYgdHdlZXRJZCBpbiBpbm5lcikgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG4vLyAtLS0gTG9vcCBzZXNzaW9uIHN0YXRlIChwcm9ncmVzcyArIGluZmxpZ2h0IGdhdGluZykgLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRocmVhZE9wZW5TZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ3RocmVhZE9wZW5TZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0VGhyZWFkT3BlblNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblNlc3Npb24nLCBzKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpOiBQcm9taXNlPEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEF1dG9TY3JvbGxTZXNzaW9uKHM6IEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJywgcyk7XG59XG5cbi8vIC0tLSBQdXJnZTogdW5yZWxhdGVkIGJ1ZmZlcnMsIGNvdW50ZXJzLCBxdWV1ZSBlbnRyaWVzIC0tLS0tLS0tLS0tLS0tLS0tLS1cblxuLyoqXG4gKiBEcm9wIGV2ZXJ5IHBlci1oYW5kbGUgYml0IG9mIHN0YXRlIChjb3VudGVycywgcnVuIGJ1ZmZlciwgY29tbWl0dGVkLWluZGV4XG4gKiBlbnRyaWVzLCByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcXVldWUgZW50cmllcykgdGhhdCBkb2Vzbid0IGNvcnJlc3BvbmQgdG8gYVxuICogdHJhY2tlZCBhY2NvdW50LiBSZXR1cm5zIGEgc3VtbWFyeSBkZXNjcmliaW5nIHdoYXQgd2FzIGNsZWFyZWQgc28gdGhlXG4gKiBjYWxsZXIgY2FuIGxvZyBpdC5cbiAqXG4gKiBUcmFja2VkIGFjY291bnRzIGFyZSBwYXNzZWQgaW4gKGNhbGxlciByZXNvbHZlcyBmcm9tIHRoZSBsaXZlIGNvbmZpZykuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwdXJnZVVucmVsYXRlZFN0YXRlKHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+KTogUHJvbWlzZTx7XG4gIGNvdW50ZXJzUmVtb3ZlZDogbnVtYmVyO1xuICBidWZmZXJzUmVtb3ZlZDogbnVtYmVyO1xuICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xuICByZWZldGNoSGFuZGxlc1JlbW92ZWQ6IG51bWJlcjtcbiAgbWVkaWFDcmF3bElkc1JlbW92ZWQ6IG51bWJlcjtcbiAgdGhyZWFkT3Blbklkc1JlbW92ZWQ6IG51bWJlcjtcbn0+IHtcbiAgY29uc3QgdGFyZ0xvd2VyID0gbmV3IFNldChbLi4udGFyZ2V0ZWRdLm1hcCgoaCkgPT4gaC50b0xvd2VyQ2FzZSgpKSk7XG4gIGNvbnN0IGlzVGFyZ2V0ZWQgPSAoaDogc3RyaW5nKTogYm9vbGVhbiA9PiB0YXJnTG93ZXIuaGFzKGgudG9Mb3dlckNhc2UoKSk7XG5cbiAgLy8gQ291bnRlcnNcbiAgY29uc3QgY291bnRlcnMgPSBhd2FpdCBnZXRDb3VudGVycygpO1xuICBsZXQgY291bnRlcnNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGNvdW50ZXJzKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIGNvdW50ZXJzW2hdO1xuICAgICAgY291bnRlcnNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygnY291bnRlcnMnLCBjb3VudGVycyk7XG5cbiAgLy8gUnVuIGJ1ZmZlcnNcbiAgY29uc3QgYnVmZmVycyA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgbGV0IGJ1ZmZlcnNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGJ1ZmZlcnMpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgYnVmZmVyc1toXTtcbiAgICAgIGJ1ZmZlcnNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGJ1ZmZlcnMpO1xuXG4gIC8vIENvbW1pdHRlZCBkZWR1cCBpbmRleFxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBsZXQgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoaWR4KSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIGlkeFtoXTtcbiAgICAgIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG5cbiAgLy8gUmVmZXRjaCBxdWV1ZTogYnVja2V0cyBhcmUga2V5ZWQgYnkgaGFuZGxlLlxuICBjb25zdCBycSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBsZXQgcmVmZXRjaEhhbmRsZXNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKHJxKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIHJxW2hdO1xuICAgICAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkICs9IDE7XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcnEpO1xuXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiBidWNrZXRzIGFyZSBoaW50LWhhbmRsZXMgKG9yIFwiX3Vua25vd25cIikuIERyb3BcbiAgLy8gZW50cmllcyB3aG9zZSBidWNrZXQgaXNuJ3QgdGFyZ2V0ZWQsIGJ1dCBLRUVQIFwiX3Vua25vd25cIjogdGhvc2UgYXJlXG4gIC8vIGNhcHR1cmVzIGF3YWl0aW5nIGhhbmRsZSByZXNvbHV0aW9uIGZvciBsYXRlciBmdWxsLWRldGFpbCByZWNhcHR1cmUsIHNvXG4gIC8vIHB1cmdpbmcgdGhlbSB3b3VsZCBzaWxlbnRseSBkaXNjYXJkIHBlbmRpbmcgd29yay5cbiAgY29uc3QgbXEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgbGV0IG1lZGlhQ3Jhd2xJZHNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKG1xKSkge1xuICAgIGlmIChoICE9PSAnX3Vua25vd24nICYmICFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBtZWRpYUNyYXdsSWRzUmVtb3ZlZCArPSAobXFbaF0gPz8gW10pLmxlbmd0aDtcbiAgICAgIGRlbGV0ZSBtcVtoXTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBtcSk7XG5cbiAgY29uc3QgdHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcbiAgbGV0IHRocmVhZE9wZW5JZHNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKHRxKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgdGhyZWFkT3Blbklkc1JlbW92ZWQgKz0gKHRxW2hdID8/IFtdKS5sZW5ndGg7XG4gICAgICBkZWxldGUgdHFbaF07XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblF1ZXVlJywgdHEpO1xuXG4gIHJldHVybiB7XG4gICAgY291bnRlcnNSZW1vdmVkLFxuICAgIGJ1ZmZlcnNSZW1vdmVkLFxuICAgIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkLFxuICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCxcbiAgICBtZWRpYUNyYXdsSWRzUmVtb3ZlZCxcbiAgICB0aHJlYWRPcGVuSWRzUmVtb3ZlZCxcbiAgfTtcbn1cblxuLy8gLS0tIEZ1bGwgcmVzZXQgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJBbGwoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5jbGVhcigpO1xufVxuIiwgImltcG9ydCB7IGFwcGVuZEFjdGl2aXR5IH0gZnJvbSAnLi9zdG9yYWdlLmpzJztcbmltcG9ydCB0eXBlIHsgTG9nRXZlbnQsIExvZ0xldmVsIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmxldCBicm9hZGNhc3Q6ICgoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKSB8IG51bGwgPSBudWxsO1xuXG5leHBvcnQgZnVuY3Rpb24gc2V0QnJvYWRjYXN0ZXIoZm46IChldjogTG9nRXZlbnQpID0+IHZvaWQpOiB2b2lkIHtcbiAgYnJvYWRjYXN0ID0gZm47XG59XG5cbmZ1bmN0aW9uIG5vd0lTTygpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBlbWl0KGxldmVsOiBMb2dMZXZlbCwgbXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGV2OiBMb2dFdmVudCA9IHsgdHM6IG5vd0lTTygpLCBsZXZlbCwgbXNnLCBjb250ZXh0OiByZWRhY3QoY29udGV4dCkgfTtcbiAgLy8gQ29uc29sZSBmb3IgZGV2dG9vbHMuXG4gIGNvbnN0IGxpbmUgPSBgW2ltbS1hcmNoaXZlXSAke2xldmVsLnRvVXBwZXJDYXNlKCl9ICR7bXNnfWA7XG4gIGlmIChsZXZlbCA9PT0gJ2Vycm9yJykgY29uc29sZS5lcnJvcihsaW5lLCBldi5jb250ZXh0KTtcbiAgZWxzZSBpZiAobGV2ZWwgPT09ICd3YXJuJykgY29uc29sZS53YXJuKGxpbmUsIGV2LmNvbnRleHQpO1xuICBlbHNlIGNvbnNvbGUubG9nKGxpbmUsIGV2LmNvbnRleHQpO1xuICAvLyBQZXJzaXN0ZW50IHRhaWwuXG4gIHRyeSB7XG4gICAgYXdhaXQgYXBwZW5kQWN0aXZpdHkoZXYpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gZmFpbGVkIHRvIGFwcGVuZCBhY3Rpdml0eScsIGVycik7XG4gIH1cbiAgLy8gTGl2ZSBicm9hZGNhc3QgKGUuZy4gdG8gc2lkZWJhcikuXG4gIHRyeSB7XG4gICAgYnJvYWRjYXN0Py4oZXYpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBTaWRlYmFyIG1heSBub3QgYmUgb3BlbjsgdGhhdCdzIGZpbmUuXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGluZm8obXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge30pOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIGVtaXQoJ2luZm8nLCBtc2csIGNvbnRleHQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHdhcm4obXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge30pOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIGVtaXQoJ3dhcm4nLCBtc2csIGNvbnRleHQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGVycm9yKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCdlcnJvcicsIG1zZywgY29udGV4dCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZUVycm9yKGVycjogdW5rbm93bik6IHsgbWVzc2FnZTogc3RyaW5nOyBzdGFjazogc3RyaW5nIHwgbnVsbCB9IHtcbiAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgcmV0dXJuIHsgbWVzc2FnZTogZXJyLm1lc3NhZ2UsIHN0YWNrOiBlcnIuc3RhY2sgPz8gbnVsbCB9O1xuICB9XG4gIHRyeSB7XG4gICAgcmV0dXJuIHsgbWVzc2FnZTogU3RyaW5nKGVyciksIHN0YWNrOiBudWxsIH07XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6ICc8dW5wcmludGFibGUgZXJyb3I+Jywgc3RhY2s6IG51bGwgfTtcbiAgfVxufVxuXG4vKipcbiAqIFN0cmlwIGFueXRoaW5nIHRoYXQgbG9va3MgbGlrZSBhIFBBVCBvciBvdGhlciBsb25nIHNlY3JldCBmcm9tIGEgY29udGV4dFxuICogb2JqZWN0IGJlZm9yZSBwZXJzaXN0aW5nIGl0LiBEZWZlbnNpdmU6IGNhbGxlcnMgc2hvdWxkIG5vdCBsb2cgdG9rZW5zLCBidXRcbiAqIGlmIHRoZXkgc2xpcCB0aHJvdWdoIHdlIHdhbnQgdG8gcmVkYWN0IHRoZW0uXG4gKi9cbmZ1bmN0aW9uIHJlZGFjdChjdHg6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xuICBjb25zdCBvdXQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XG4gIGZvciAoY29uc3QgW2ssIHZdIG9mIE9iamVjdC5lbnRyaWVzKGN0eCkpIHtcbiAgICBpZiAoay50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCd0b2tlbicpIHx8IGsudG9Mb3dlckNhc2UoKSA9PT0gJ3BhdCcgfHwgayA9PT0gJ2F1dGhvcml6YXRpb24nKSB7XG4gICAgICBvdXRba10gPSAnPHJlZGFjdGVkPic7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dezMwLH0vLnRlc3QodikpIHtcbiAgICAgIG91dFtrXSA9IHYucmVwbGFjZSgvZ2l0aHViX3BhdF9bQS1aYS16MC05X10rL2csICdnaXRodWJfcGF0XzxyZWRhY3RlZD4nKTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDQwOTYpIHtcbiAgICAgIG91dFtrXSA9IGAke3Yuc2xpY2UoMCwgNDA5Nil9XHUyMDI2PHRydW5jYXRlZD5gO1xuICAgIH0gZWxzZSB7XG4gICAgICBvdXRba10gPSB2O1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufVxuIiwgImltcG9ydCB7IGRlc2NyaWJlRXJyb3IgfSBmcm9tICcuL2xvZ2dlci5qcyc7XG5pbXBvcnQgdHlwZSB7IFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmNvbnN0IEFQSV9CQVNFID0gJ2h0dHBzOi8vYXBpLmdpdGh1Yi5jb20nO1xuY29uc3QgUkFXX0JBU0UgPSAnaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tJztcblxuZXhwb3J0IGludGVyZmFjZSBQdXRGaWxlT3B0aW9ucyB7XG4gIHBhdGg6IHN0cmluZztcbiAgY29udGVudEJhc2U2NDogc3RyaW5nO1xuICBtZXNzYWdlOiBzdHJpbmc7XG4gIGV4cGVjdGVkU2hhPzogc3RyaW5nIHwgbnVsbDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQdXRGaWxlUmVzdWx0IHtcbiAgcGF0aDogc3RyaW5nO1xuICBzaGE6IHN0cmluZztcbiAgdXJsOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZU9wdGlvbnMge1xuICBwYXRoOiBzdHJpbmc7XG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlc09wdGlvbnMge1xuICBmaWxlczogQ29tbWl0RmlsZU9wdGlvbnNbXTtcbiAgbWVzc2FnZTogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVzUmVzdWx0IHtcbiAgY29tbWl0U2hhOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xuICBmaWxlczogc3RyaW5nW107XG59XG5cbmV4cG9ydCBjbGFzcyBHaXRIdWJFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgc3RhdHVzOiBudW1iZXI7XG4gIGJvZHk6IHVua25vd247XG4gIHJldHJpYWJsZTogYm9vbGVhbjtcbiAgY2F0ZWdvcnk6ICdhdXRoJyB8ICdyYXRlLWxpbWl0JyB8ICdjb25mbGljdCcgfCAnbm90LWZvdW5kJyB8ICdzZXJ2ZXInIHwgJ25ldHdvcmsnIHwgJ3Vua25vd24nO1xuICAvKiogV2hlbiB0aGUgR2l0SHViIHJhdGUtbGltaXQgd2luZG93IGZvciB0aGlzIHRva2VuIHJlc2V0cywgYXMgYSBVbml4XG4gICAqIGVwb2NoIGluIHNlY29uZHMuIFBvcHVsYXRlZCBmcm9tIGBYLVJhdGVMaW1pdC1SZXNldGAgb24gNDAzLzQyOSwgb3JcbiAgICogZGVyaXZlZCBmcm9tIGBSZXRyeS1BZnRlcmAgZm9yIHNlY29uZGFyeSBsaW1pdHMuIG51bGwgd2hlbiB1bmtub3duLiAqL1xuICByYXRlTGltaXRSZXNldEF0OiBudW1iZXIgfCBudWxsO1xuXG4gIGNvbnN0cnVjdG9yKG9wdHM6IHtcbiAgICBzdGF0dXM6IG51bWJlcjtcbiAgICBib2R5OiB1bmtub3duO1xuICAgIG1lc3NhZ2U6IHN0cmluZztcbiAgICByZXRyaWFibGU6IGJvb2xlYW47XG4gICAgY2F0ZWdvcnk6IEdpdEh1YkVycm9yWydjYXRlZ29yeSddO1xuICAgIHJhdGVMaW1pdFJlc2V0QXQ/OiBudW1iZXIgfCBudWxsO1xuICB9KSB7XG4gICAgc3VwZXIob3B0cy5tZXNzYWdlKTtcbiAgICB0aGlzLm5hbWUgPSAnR2l0SHViRXJyb3InO1xuICAgIHRoaXMuc3RhdHVzID0gb3B0cy5zdGF0dXM7XG4gICAgdGhpcy5ib2R5ID0gb3B0cy5ib2R5O1xuICAgIHRoaXMucmV0cmlhYmxlID0gb3B0cy5yZXRyaWFibGU7XG4gICAgdGhpcy5jYXRlZ29yeSA9IG9wdHMuY2F0ZWdvcnk7XG4gICAgdGhpcy5yYXRlTGltaXRSZXNldEF0ID0gb3B0cy5yYXRlTGltaXRSZXNldEF0ID8/IG51bGw7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIEdpdEh1YkNsaWVudCB7XG4gIHByaXZhdGUgcmVhZG9ubHkgc2V0dGluZ3M6IFNldHRpbmdzO1xuXG4gIGNvbnN0cnVjdG9yKHNldHRpbmdzOiBTZXR0aW5ncykge1xuICAgIHRoaXMuc2V0dGluZ3MgPSBzZXR0aW5ncztcbiAgfVxuXG4gIC8qKiBSZXR1cm5zIHRoZSBhdXRoZW50aWNhdGVkIHVzZXIncyBsb2dpbi4gVGhyb3dzIG9uIGF1dGggZmFpbHVyZS4gKi9cbiAgYXN5bmMgd2hvYW1pKCk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsICcvdXNlcicpO1xuICAgIHJldHVybiAocmVzIGFzIHsgbG9naW4/OiBzdHJpbmcgfSkubG9naW4gPz8gJzx1bmtub3duPic7XG4gIH1cblxuICAvKiogUmV0dXJucyB0cnVlIGlmIHRoZSBnaXZlbiBicmFuY2ggZXhpc3RzIG9uIHRoZSBjb25maWd1cmVkIHJlcG8uICovXG4gIGFzeW5jIGJyYW5jaEV4aXN0cyhicmFuY2g6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vYnJhbmNoZXMvJHtlbmNvZGVVUklDb21wb25lbnQoYnJhbmNoKX1gXG4gICAgICApO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBpZiAoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgZXJyLmNhdGVnb3J5ID09PSAnbm90LWZvdW5kJykgcmV0dXJuIGZhbHNlO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKiBWZXJpZmllcyB0aGUgUEFUIGNhbiBzZWUgdGhlIGNvbmZpZ3VyZWQgcmVwby4gKi9cbiAgYXN5bmMgdmVyaWZ5UmVwb0FjY2VzcygpOiBQcm9taXNlPHsgbG9naW46IHN0cmluZzsgZnVsbF9uYW1lOiBzdHJpbmc7IGRlZmF1bHRfYnJhbmNoOiBzdHJpbmcgfT4ge1xuICAgIGNvbnN0IG1lID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsICcvdXNlcicpO1xuICAgIGNvbnN0IHJlcG8gPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfWApO1xuICAgIGNvbnN0IHIgPSByZXBvIGFzIHsgZnVsbF9uYW1lOiBzdHJpbmc7IGRlZmF1bHRfYnJhbmNoOiBzdHJpbmcgfTtcbiAgICByZXR1cm4ge1xuICAgICAgbG9naW46IChtZSBhcyB7IGxvZ2luOiBzdHJpbmcgfSkubG9naW4sXG4gICAgICBmdWxsX25hbWU6IHIuZnVsbF9uYW1lLFxuICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBWZXJpZnkgdGhlIFBBVCBjYW4gd3JpdGUgdG8gdGhlIGNvbmZpZ3VyZWQgYnJhbmNoIHdpdGhvdXQgY3JlYXRpbmcgYVxuICAgKiBjb21taXQuIE1vdmluZyBhIHJlZiB0byBpdHMgY3VycmVudCBTSEEgaXMgYSBuby1vcCwgYnV0IEdpdEh1YiBzdGlsbFxuICAgKiBlbmZvcmNlcyB0aGUgQ29udGVudHM6IFdyaXRlIHBlcm1pc3Npb24gcmVxdWlyZWQgYnkgY29tbWl0RmlsZXMoKS5cbiAgICovXG4gIGFzeW5jIHZlcmlmeVdyaXRlQWNjZXNzKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGhlYWQgPSBhd2FpdCB0aGlzLmdldEJyYW5jaEhlYWQoKTtcbiAgICBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICdQQVRDSCcsXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9yZWZzL2hlYWRzLyR7ZW5jb2RlUGF0aCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YCxcbiAgICAgIHtcbiAgICAgICAgc2hhOiBoZWFkLnNoYSxcbiAgICAgICAgZm9yY2U6IGZhbHNlLFxuICAgICAgfVxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogRmV0Y2ggYSB0ZXh0IGZpbGUgZnJvbSByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tIGF1dGhlbnRpY2F0ZWQgd2l0aCB0aGVcbiAgICogUEFULiBSZXR1cm5zIG51bGwgaWYgdGhlIGZpbGUgZG9lc24ndCBleGlzdC4gVXNlZCBmb3IgY29uZmlnL2FjY291bnRzLnlhbWwuXG4gICAqL1xuICBhc3luYyBmZXRjaFJhd1RleHQocGF0aEluUmVwbzogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgY29uc3QgdXJsID0gYCR7UkFXX0JBU0V9LyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99LyR7dGhpcy5zZXR0aW5ncy5icmFuY2h9LyR7cGF0aEluUmVwb31gO1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAgfSxcbiAgICB9KTtcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSByZXR1cm4gbnVsbDtcbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3IocmVzLCBgR0VUIHJhdyAke3BhdGhJblJlcG99YCk7XG4gICAgcmV0dXJuIHJlcy50ZXh0KCk7XG4gIH1cblxuICAvKipcbiAgICogTG9vayB1cCBhbiBleGlzdGluZyBmaWxlJ3MgU0hBIHZpYSB0aGUgQ29udGVudHMgQVBJLCBvciBudWxsIGlmIG5vdCBmb3VuZC5cbiAgICogVXNlZCB3aGVuIHJldHJ5aW5nIGEgUFVUIGFmdGVyIGEgNDIyIHNoYSBtaXNtYXRjaC5cbiAgICovXG4gIGFzeW5jIGdldEZpbGVTaGEocGF0aDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9P3JlZj0ke2VuY29kZVVSSUNvbXBvbmVudCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHIgPSByZXMgYXMgeyBzaGE/OiBzdHJpbmcgfTtcbiAgICAgIHJldHVybiByLnNoYSA/PyBudWxsO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBudWxsO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBQVVQgYSBmaWxlIHRvIHRoZSByZXBvLiBIYW5kbGVzIDQyMiAoc2hhIHJlcXVpcmVkKSBieSByZS1mZXRjaGluZyB0aGVcbiAgICogZXhpc3Rpbmcgc2hhIGFuZCByZXRyeWluZyBvbmNlLiBSZXRyaWVzIG5ldHdvcmsgLyA1eHggLyByYXRlLWxpbWl0IGVycm9yc1xuICAgKiB3aXRoIGV4cG9uZW50aWFsIGJhY2tvZmYgdXAgdG8gbWF4QXR0ZW1wdHMuXG4gICAqL1xuICBhc3luYyBwdXRGaWxlKG9wdHM6IFB1dEZpbGVPcHRpb25zKTogUHJvbWlzZTxQdXRGaWxlUmVzdWx0PiB7XG4gICAgY29uc3QgcGF0aCA9IG9wdHMucGF0aDtcbiAgICBjb25zdCB1cmwgPSBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2NvbnRlbnRzLyR7ZW5jb2RlUGF0aChwYXRoKX1gO1xuICAgIGxldCBzaGE6IHN0cmluZyB8IG51bGwgPSBvcHRzLmV4cGVjdGVkU2hhID8/IG51bGw7XG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xuXG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDE7IGF0dGVtcHQgPD0gbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xuICAgICAgY29uc3QgYm9keTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7XG4gICAgICAgIG1lc3NhZ2U6IG9wdHMubWVzc2FnZSxcbiAgICAgICAgY29udGVudDogb3B0cy5jb250ZW50QmFzZTY0LFxuICAgICAgICBicmFuY2g6IHRoaXMuc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgfTtcbiAgICAgIGlmIChzaGEpIGJvZHkuc2hhID0gc2hhO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ1BVVCcsIHVybCwgYm9keSk7XG4gICAgICAgIGNvbnN0IG91dCA9IHJlcyBhcyB7IGNvbnRlbnQ6IHsgc2hhOiBzdHJpbmc7IGh0bWxfdXJsOiBzdHJpbmc7IHBhdGg6IHN0cmluZyB9IH07XG4gICAgICAgIHJldHVybiB7IHBhdGg6IG91dC5jb250ZW50LnBhdGgsIHNoYTogb3V0LmNvbnRlbnQuc2hhLCB1cmw6IG91dC5jb250ZW50Lmh0bWxfdXJsIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XG4gICAgICAgIGlmIChlcnIuc3RhdHVzID09PSA0MjIgJiYgIXNoYSkge1xuICAgICAgICAgIC8vIEZpbGUgYWxyZWFkeSBleGlzdHM7IGZldGNoIGl0cyBzaGEgYW5kIHJldHJ5IG9uY2UuXG4gICAgICAgICAgc2hhID0gYXdhaXQgdGhpcy5nZXRGaWxlU2hhKHBhdGgpO1xuICAgICAgICAgIGlmICghc2hhKSB0aHJvdyBlcnI7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFlcnIucmV0cmlhYmxlIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKGBwdXRGaWxlOiBleGhhdXN0ZWQgYXR0ZW1wdHMgZm9yICR7cGF0aH1gKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb21taXQgc2V2ZXJhbCBmaWxlcyB3aXRoIG9uZSBicmFuY2ggdXBkYXRlLiBUaGUgQ29udGVudHMgQVBJIGNyZWF0ZXMgb25lXG4gICAqIGNvbW1pdCBwZXIgUFVULCBzbyByYXBpZCBmbHVzaGVzIHJhY2UgZWFjaCBvdGhlciBvbiB0aGUgYnJhbmNoIGhlYWQuIFRoaXNcbiAgICogdXNlcyB0aGUgbG93ZXItbGV2ZWwgR2l0IERhdGEgQVBJIGluc3RlYWQ6IHVwbG9hZCBibG9icywgYnVpbGQgYSB0cmVlLFxuICAgKiBjcmVhdGUgb25lIGNvbW1pdCwgdGhlbiBtb3ZlIHRoZSBicmFuY2ggcmVmIG9uY2UuIElmIGFub3RoZXIgd3JpdGVyIG1vdmVzXG4gICAqIHRoZSBicmFuY2ggZmlyc3QsIHJlYmFzZSB0aGlzIHRyZWUgcGF0Y2ggb250byB0aGUgbGF0ZXN0IGhlYWQgYW5kIHJldHJ5LlxuICAgKi9cbiAgYXN5bmMgY29tbWl0RmlsZXMob3B0czogQ29tbWl0RmlsZXNPcHRpb25zKTogUHJvbWlzZTxDb21taXRGaWxlc1Jlc3VsdD4ge1xuICAgIGlmIChvcHRzLmZpbGVzLmxlbmd0aCA9PT0gMCkgdGhyb3cgbmV3IEVycm9yKCdjb21taXRGaWxlczogbm8gZmlsZXMgdG8gY29tbWl0Jyk7XG4gICAgY29uc3QgbWF4QXR0ZW1wdHMgPSA1O1xuICAgIGxldCBsYXN0RXJyOiB1bmtub3duID0gbnVsbDtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGJsb2JzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgICAgb3B0cy5maWxlcy5tYXAoYXN5bmMgKGZpbGUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG91dCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L2Jsb2JzYCxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGNvbnRlbnQ6IGZpbGUuY29udGVudEJhc2U2NCxcbiAgICAgICAgICAgICAgICBlbmNvZGluZzogJ2Jhc2U2NCcsXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBwYXRoOiBmaWxlLnBhdGgsXG4gICAgICAgICAgICAgIHNoYTogKG91dCBhcyB7IHNoYTogc3RyaW5nIH0pLnNoYSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSlcbiAgICAgICAgKTtcblxuICAgICAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XG4gICAgICAgIGNvbnN0IHRyZWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvdHJlZXNgLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGJhc2VfdHJlZTogaGVhZC50cmVlU2hhLFxuICAgICAgICAgICAgdHJlZTogYmxvYnMubWFwKChibG9iKSA9PiAoe1xuICAgICAgICAgICAgICBwYXRoOiBibG9iLnBhdGgsXG4gICAgICAgICAgICAgIG1vZGU6ICcxMDA2NDQnLFxuICAgICAgICAgICAgICB0eXBlOiAnYmxvYicsXG4gICAgICAgICAgICAgIHNoYTogYmxvYi5zaGEsXG4gICAgICAgICAgICB9KSksXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICBjb25zdCB0cmVlU2hhID0gKHRyZWUgYXMgeyBzaGE6IHN0cmluZyB9KS5zaGE7XG4gICAgICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICdQT1NUJyxcbiAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9jb21taXRzYCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXG4gICAgICAgICAgICB0cmVlOiB0cmVlU2hhLFxuICAgICAgICAgICAgcGFyZW50czogW2hlYWQuc2hhXSxcbiAgICAgICAgICB9XG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGNvbW1pdE91dCA9IGNvbW1pdCBhcyB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nIH07XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICAgICAnUEFUQ0gnLFxuICAgICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNoYTogY29tbWl0T3V0LnNoYSxcbiAgICAgICAgICAgICAgZm9yY2U6IGZhbHNlLFxuICAgICAgICAgICAgfVxuICAgICAgICAgICk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGlmIChpc0NvbmZsaWN0KGVycikgJiYgYXR0ZW1wdCA8IG1heEF0dGVtcHRzKSB7XG4gICAgICAgICAgICBsYXN0RXJyID0gZXJyO1xuICAgICAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRocm93IGVycjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGNvbW1pdFNoYTogY29tbWl0T3V0LnNoYSxcbiAgICAgICAgICB1cmw6IGNvbW1pdE91dC5odG1sX3VybCxcbiAgICAgICAgICBmaWxlczogb3B0cy5maWxlcy5tYXAoKGZpbGUpID0+IGZpbGUucGF0aCksXG4gICAgICAgIH07XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgbGFzdEVyciA9IGVycjtcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XG4gICAgICAgIGlmICgoIWVyci5yZXRyaWFibGUgJiYgIWlzQ29uZmxpY3QoZXJyKSkgfHwgYXR0ZW1wdCA9PT0gbWF4QXR0ZW1wdHMpIHRocm93IGVycjtcbiAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aHJvdyBsYXN0RXJyIGluc3RhbmNlb2YgRXJyb3IgPyBsYXN0RXJyIDogbmV3IEVycm9yKCdjb21taXRGaWxlczogZXhoYXVzdGVkIGF0dGVtcHRzJyk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGdldEJyYW5jaEhlYWQoKTogUHJvbWlzZTx7IHNoYTogc3RyaW5nOyB0cmVlU2hhOiBzdHJpbmcgfT4ge1xuICAgIGNvbnN0IHJlZiA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgJ0dFVCcsXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9yZWYvaGVhZHMvJHtlbmNvZGVQYXRoKHRoaXMuc2V0dGluZ3MuYnJhbmNoKX1gXG4gICAgKTtcbiAgICBjb25zdCBoZWFkU2hhID0gKHJlZiBhcyB7IG9iamVjdDogeyBzaGE6IHN0cmluZyB9IH0pLm9iamVjdC5zaGE7XG4gICAgY29uc3QgY29tbWl0ID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAnR0VUJyxcbiAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L2NvbW1pdHMvJHtoZWFkU2hhfWBcbiAgICApO1xuICAgIHJldHVybiB7XG4gICAgICBzaGE6IGhlYWRTaGEsXG4gICAgICB0cmVlU2hhOiAoY29tbWl0IGFzIHsgdHJlZTogeyBzaGE6IHN0cmluZyB9IH0pLnRyZWUuc2hhLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGZldGNoSnNvbihtZXRob2Q6IHN0cmluZywgcGF0aDogc3RyaW5nLCBib2R5PzogdW5rbm93bik6IFByb21pc2U8dW5rbm93bj4ge1xuICAgIGNvbnN0IHVybCA9IHBhdGguc3RhcnRzV2l0aCgnaHR0cCcpID8gcGF0aCA6IGAke0FQSV9CQVNFfSR7cGF0aH1gO1xuICAgIGNvbnN0IGluaXQ6IFJlcXVlc3RJbml0ID0ge1xuICAgICAgbWV0aG9kLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dGhpcy5zZXR0aW5ncy5wYXR9YCxcbiAgICAgICAgQWNjZXB0OiAnYXBwbGljYXRpb24vdm5kLmdpdGh1Yitqc29uJyxcbiAgICAgICAgJ1gtR2l0SHViLUFwaS1WZXJzaW9uJzogJzIwMjItMTEtMjgnLFxuICAgICAgICAuLi4oYm9keSA/IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IDoge30pLFxuICAgICAgfSxcbiAgICAgIC4uLihib2R5ID8geyBib2R5OiBKU09OLnN0cmluZ2lmeShib2R5KSB9IDoge30pLFxuICAgIH07XG4gICAgbGV0IHJlczogUmVzcG9uc2U7XG4gICAgdHJ5IHtcbiAgICAgIHJlcyA9IGF3YWl0IGZldGNoKHVybCwgaW5pdCk7XG4gICAgfSBjYXRjaCAobmV0RXJyKSB7XG4gICAgICB0aHJvdyBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgICBzdGF0dXM6IDAsXG4gICAgICAgIGJvZHk6IG51bGwsXG4gICAgICAgIG1lc3NhZ2U6IGBuZXR3b3JrOiAke2Rlc2NyaWJlRXJyb3IobmV0RXJyKS5tZXNzYWdlfWAsXG4gICAgICAgIHJldHJpYWJsZTogdHJ1ZSxcbiAgICAgICAgY2F0ZWdvcnk6ICduZXR3b3JrJyxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gMjA0KSByZXR1cm4gbnVsbDtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcbiAgICBpZiAodGV4dCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICBwYXJzZWQgPSB0ZXh0O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBgJHttZXRob2R9ICR7cGF0aH1gKTtcbiAgICByZXR1cm4gcGFyc2VkO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBtYWtlRXJyb3IocmVzOiBSZXNwb25zZSwgbGFiZWw6IHN0cmluZyk6IFByb21pc2U8R2l0SHViRXJyb3I+IHtcbiAgICBsZXQgcGFyc2VkOiB1bmtub3duID0gbnVsbDtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICBpZiAodGV4dCkgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgICByZXR1cm4gdGhpcy5tYWtlRXJyb3JGcm9tUGFyc2VkKHJlcywgcGFyc2VkLCBsYWJlbCk7XG4gIH1cblxuICBwcml2YXRlIG1ha2VFcnJvckZyb21QYXJzZWQocmVzOiBSZXNwb25zZSwgYm9keTogdW5rbm93biwgbGFiZWw6IHN0cmluZyk6IEdpdEh1YkVycm9yIHtcbiAgICBjb25zdCBtc2cgPVxuICAgICAgdHlwZW9mIGJvZHkgPT09ICdvYmplY3QnICYmIGJvZHkgJiYgJ21lc3NhZ2UnIGluIGJvZHlcbiAgICAgICAgPyBTdHJpbmcoKGJvZHkgYXMgeyBtZXNzYWdlOiB1bmtub3duIH0pLm1lc3NhZ2UpXG4gICAgICAgIDogcmVzLnN0YXR1c1RleHQ7XG4gICAgbGV0IGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXSA9ICd1bmtub3duJztcbiAgICBsZXQgcmV0cmlhYmxlID0gZmFsc2U7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSB8fCByZXMuc3RhdHVzID09PSA0MDMpIHtcbiAgICAgIC8vIDQwMyBjYW4gYmUgZWl0aGVyIGF1dGggb3IgcmF0ZSBsaW1pdDsgY2hlY2sgaGVhZGVycy5cbiAgICAgIGNvbnN0IHJhdGUgPSByZXMuaGVhZGVycy5nZXQoJ3gtcmF0ZWxpbWl0LXJlbWFpbmluZycpO1xuICAgICAgaWYgKHJhdGUgPT09ICcwJyB8fCAvcmF0ZSBsaW1pdC9pLnRlc3QobXNnKSkge1xuICAgICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNhdGVnb3J5ID0gJ2F1dGgnO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSB7XG4gICAgICBjYXRlZ29yeSA9ICdub3QtZm91bmQnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA5IHx8IHJlcy5zdGF0dXMgPT09IDQyMikge1xuICAgICAgY2F0ZWdvcnkgPSAnY29uZmxpY3QnO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA+PSA1MDApIHtcbiAgICAgIGNhdGVnb3J5ID0gJ3NlcnZlcic7XG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDI5KSB7XG4gICAgICBjYXRlZ29yeSA9ICdyYXRlLWxpbWl0JztcbiAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBuZXcgR2l0SHViRXJyb3Ioe1xuICAgICAgc3RhdHVzOiByZXMuc3RhdHVzLFxuICAgICAgYm9keSxcbiAgICAgIG1lc3NhZ2U6IGAke2xhYmVsfSBcdTIxOTIgJHtyZXMuc3RhdHVzfTogJHttc2d9YCxcbiAgICAgIHJldHJpYWJsZSxcbiAgICAgIGNhdGVnb3J5LFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IHBhcnNlUmF0ZUxpbWl0UmVzZXQocmVzLmhlYWRlcnMpIDogbnVsbCxcbiAgICB9KTtcbiAgfVxufVxuXG4vKipcbiAqIEJlc3QtZWZmb3J0IHBhcnNlIG9mIHdoZW4gdGhlIGN1cnJlbnQgcmF0ZS1saW1pdCB3aW5kb3cgZW5kcy4gR2l0SHViJ3NcbiAqIHByaW1hcnkgbGltaXQgcmVwb3J0cyBgWC1SYXRlTGltaXQtUmVzZXRgIGFzIGEgVW5peCBlcG9jaCBpbiBzZWNvbmRzLlxuICogU2Vjb25kYXJ5IC8gYWJ1c2UgbGltaXRzIHVzZSBgUmV0cnktQWZ0ZXJgLCB3aGljaCBpcyBlaXRoZXIgYW4gSFRUUC1kYXRlXG4gKiBvciBhIGRlbHRhIGluIHNlY29uZHMgXHUyMDE0IHdlIG5vcm1hbGl6ZSBib3RoIHRvIGVwb2NoIHNlY29uZHMuXG4gKi9cbmZ1bmN0aW9uIHBhcnNlUmF0ZUxpbWl0UmVzZXQoaGVhZGVyczogSGVhZGVycyk6IG51bWJlciB8IG51bGwge1xuICBjb25zdCByZXNldCA9IGhlYWRlcnMuZ2V0KCd4LXJhdGVsaW1pdC1yZXNldCcpO1xuICBpZiAocmVzZXQpIHtcbiAgICBjb25zdCBuID0gTnVtYmVyLnBhcnNlSW50KHJlc2V0LCAxMCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShuKSAmJiBuID4gMCkgcmV0dXJuIG47XG4gIH1cbiAgY29uc3QgcmV0cnlBZnRlciA9IGhlYWRlcnMuZ2V0KCdyZXRyeS1hZnRlcicpO1xuICBpZiAocmV0cnlBZnRlcikge1xuICAgIGNvbnN0IGRlbHRhID0gTnVtYmVyLnBhcnNlSW50KHJldHJ5QWZ0ZXIsIDEwKTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGRlbHRhKSAmJiBkZWx0YSA+PSAwKSB7XG4gICAgICByZXR1cm4gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCkgKyBkZWx0YTtcbiAgICB9XG4gICAgY29uc3QgYXNEYXRlID0gRGF0ZS5wYXJzZShyZXRyeUFmdGVyKTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGFzRGF0ZSkpIHJldHVybiBNYXRoLmZsb29yKGFzRGF0ZSAvIDEwMDApO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBlbmNvZGVQYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gIC8vIEVuY29kZSBzZWdtZW50cyBpbmRpdmlkdWFsbHkgc28gc2xhc2hlcyByZW1haW4uXG4gIHJldHVybiBwYXRoLnNwbGl0KCcvJykubWFwKGVuY29kZVVSSUNvbXBvbmVudCkuam9pbignLycpO1xufVxuXG5mdW5jdGlvbiBiYWNrb2ZmTXMoYXR0ZW1wdDogbnVtYmVyLCBlcnI6IEdpdEh1YkVycm9yKTogbnVtYmVyIHtcbiAgLy8gRXhwb25lbnRpYWwgd2l0aCBqaXR0ZXI7IGJ1bXAgaGlnaGVyIGZvciByYXRlLWxpbWl0IHJlc3BvbnNlcy5cbiAgY29uc3QgYmFzZSA9IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnID8gNTAwMCA6IDUwMDtcbiAgY29uc3Qgaml0dGVyID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNDAwKTtcbiAgcmV0dXJuIE1hdGgubWluKDYwXzAwMCwgYmFzZSAqIDIgKiogKGF0dGVtcHQgLSAxKSArIGppdHRlcik7XG59XG5cbmZ1bmN0aW9uIGlzQ29uZmxpY3QoZXJyOiB1bmtub3duKTogZXJyIGlzIEdpdEh1YkVycm9yIHtcbiAgcmV0dXJuIGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ2NvbmZsaWN0Jztcbn1cblxuZnVuY3Rpb24gc2xlZXAobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBieXRlcyBpcyBhIFVURi04IHN0cmluZyBvZiBKU09OOyBlbmNvZGUgdG8gYmFzZTY0IHRoZSBzYWZlIHdheS5cbiAgY29uc3QgdXRmOCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShieXRlcyk7XG4gIGxldCBiaW4gPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIHV0ZjgpIGJpbiArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShiaW4pO1xufVxuIiwgImltcG9ydCB7IFRXRUVUX1VSTF9QUkVGSVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDb21tdW5pdHlOb3RlLFxuICBNZWRpYUl0ZW0sXG4gIFR3ZWV0Q2FyZCxcbiAgVHdlZXRUeXBlLFxuICBVbmF2YWlsYWJsZVR3ZWV0LFxuICBVcmxFbnRpdHksXG4gIFVzZXJTbmFwc2hvdCxcbn0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTm9ybWFsaXplIEdyYXBoUUwgcmVzcG9uc2UgcGF5bG9hZHMgZnJvbSBYJ3MgaW50ZXJuYWwgQVBJIGludG9cbiAqIGBDYW5vbmljYWxUd2VldGBzLiBNYW55IGVuZHBvaW50cyBzaGFyZSBhIHNpbWlsYXIgdHdlZXQgc2hhcGUgYnV0IHdyYXAgaXQgaW5cbiAqIGRpZmZlcmVudCBlbnZlbG9wZXM7IHRoaXMgbW9kdWxlIHdhbGtzIHRoZSBzdHJ1Y3R1cmUgZGVmZW5zaXZlbHkuXG4gKlxuICogVGhlIHBhcnNlciBpcyBpbnRlbnRpb25hbGx5IHBlcm1pc3NpdmU6IGl0IHdpbGwgc2lsZW50bHkgc2tpcCBlbnRyaWVzIGl0XG4gKiBjYW4ndCByZWNvZ25pemUgYXMgdHdlZXRzIChjdXJzb3JzLCBhZHMsIGdhcCBlbnRyaWVzLCBtb2R1bGVzIG9mIG90aGVyXG4gKiB0d2VldHMsIHRvbWJzdG9uZXMpLiBJdCB0aHJvd3MgKm9ubHkqIHdoZW4gZ2l2ZW4gYSBwYXlsb2FkIGl0IGRvZXNuJ3Qga25vd1xuICogaG93IHRvIHdhbGsgYXQgYWxsIFx1MjAxNCB0aG9zZSBjYXNlcyBhcmUgY2F1Z2h0IGFuZCBxdWFyYW50aW5lZCB1cHN0cmVhbS5cbiAqL1xuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZUNvbnRleHQge1xuICBjYXB0dXJlZEF0OiBzdHJpbmc7XG4gIHJ1bklkOiBzdHJpbmc7XG4gIGVuZHBvaW50OiBzdHJpbmc7XG4gIGFsbG93ZWRIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+O1xuICBzb3VyY2VVcmw/OiBzdHJpbmcgfCBudWxsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZVJlc3VsdCB7XG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcbiAgb2JzZXJ2ZWRfaWRzOiBzdHJpbmdbXTtcbiAgdW5hdmFpbGFibGVfdHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W107XG4gIC8qKlxuICAgKiBUd2VldC1zaGFwZWQgbm9kZXMgdGhlIHdhbGtlciBzYXcgKGhhZCBhIGByZXN0X2lkYCkgYnV0IGNvdWxkbid0IHR1cm5cbiAgICogaW50byBhIGZ1bGwgYENhbm9uaWNhbFR3ZWV0YCBcdTIwMTQgdHlwaWNhbGx5IGJlY2F1c2UgdGhlIGVtYmVkZGVkIHVzZXJcbiAgICogaW5mbyB3YXMgbWlzc2luZyBvciB0aGUgZW50cnkgd2FzIGEgbWVkaWEtb25seSB0aHVtYm5haWwgY2FyZCBmcm9tXG4gICAqIHRoZSBVc2VyTWVkaWEgZW5kcG9pbnQuIE9ubHkgSURzIHdpdGggYSB0cnVzdHdvcnRoeSBoYW5kbGUgZnJvbSB0aGVcbiAgICogdHdlZXQgbm9kZSBpdHNlbGYgYXJlIHJldHVybmVkOyBvdGhlcndpc2UgdGhlIGJhY2tncm91bmQgY2Fubm90IGJ1aWxkXG4gICAqIGEgcmVsaWFibGUgLzxoYW5kbGU+L3N0YXR1cy88aWQ+IGRldGFpbCBVUkwuXG4gICAqL1xuICBwYXJ0aWFsX2lkczogQXJyYXk8eyB0d2VldF9pZDogc3RyaW5nOyBoaW50X2hhbmRsZTogc3RyaW5nIHwgbnVsbCB9Pjtcbn1cblxuLy8gWCB0d2VldCBJRHMgYXJlIDY0LWJpdCBwb3NpdGl2ZSBpbnRlZ2VycyBzZXJpYWxpemVkIGFzIGRlY2ltYWwgc3RyaW5ncy5cbi8vIFRoZXkndmUgZ3Jvd24gdG8gMTkgY2hhcnMgKH4xLjVlMTgpIGJ5IDIwMjYuIFJlamVjdCBhbnl0aGluZyB0aGF0IGRvZXNuJ3Rcbi8vIG1hdGNoIHRoaXMgc2hhcGUgXHUyMDE0IG90aGVyd2lzZSBzcHVyaW91cyBjYXJkIElEcywgY3Vyc29yIHN0cmluZ3MsIGFkIHNsb3Rcbi8vIElEcywgZXRjLiBlbmQgdXAgaW4gdGhlIHBhcnRpYWwtY2FwdHVyZSBxdWV1ZSBhbmQgdGhlIGNyYXdsIGxvb3Bcbi8vIG5hdmlnYXRlcyB0byBpbnZhbGlkIFVSTHMgdGhhdCBzaG93IFwidGhpcyBwYWdlIGRvZXNuJ3QgZXhpc3RcIi5cbmNvbnN0IFRXRUVUX0lEX1JFID0gL15cXGR7MTUsMjB9JC87XG5cbi8vIE9ubHkgb25lIGVuZHBvaW50IGFjdHVhbGx5IGV4cG9zZXMgdGhlIGZhaWx1cmUgbW9kZSB0aGUgcGFydGlhbC1jYXB0dXJlXG4vLyBxdWV1ZSBleGlzdHMgZm9yIFx1MjAxNCB0aGUgTWVkaWEgdGFiJ3MgYFVzZXJNZWRpYWAgcXVlcnkgcmV0dXJuaW5nXG4vLyB0aHVtYm5haWwtb25seSBlbnRyaWVzIHdpdGhvdXQgYSBwb3B1bGF0ZWQgYXV0aG9yIGJsb2NrLiBFdmVyeSBvdGhlclxuLy8gZW5kcG9pbnQgdGhhdCBoYW5kcyB1cyBhIGBUd2VldGAgc2hhcGUgZ2l2ZXMgdXMgdGhlIGZ1bGwgZW50cnk7IGlmXG4vLyBgYnVpbGRUd2VldGAgZmFpbHMgdGhlcmUgaXQncyBhIHJlYWwgZXJyb3IsIG5vdCBcImdvIHJlLWZldGNoIHRoaXNcIi5cbi8vIFJlc3RyaWN0aW5nIHBhcnRpYWwtaWQgZW1pc3Npb24gdG8gVXNlck1lZGlhIHN0b3BzIHRoZSBmbG9vZHMgb2Zcbi8vIGZhbHNlIHBvc2l0aXZlcyByZXBvcnRlZCBvbiBSZXBsaWVzIC8gVHdlZXREZXRhaWwgLyBTZWFyY2hUaW1lbGluZS5cbmNvbnN0IFBBUlRJQUxfT0tfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJNZWRpYSddKTtcblxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShwYXlsb2FkOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBOb3JtYWxpemVSZXN1bHQge1xuICBjb25zdCByYXdUd2VldHMgPSBjb2xsZWN0VHdlZXRzKHBheWxvYWQpO1xuICBjb25zdCB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10gPSBbXTtcbiAgY29uc3QgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXSA9IFtdO1xuICBjb25zdCBvYnNlcnZlZDogc3RyaW5nW10gPSBbXTtcbiAgY29uc3QgYnVpbHQgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgcGFydGlhbE1hcCA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmcgfCBudWxsPigpO1xuICBjb25zdCBjb2xsZWN0UGFydGlhbHMgPSBQQVJUSUFMX09LX0VORFBPSU5UUy5oYXMoY3R4LmVuZHBvaW50KTtcbiAgZm9yIChjb25zdCByYXcgb2YgcmF3VHdlZXRzKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVuYXZhaWxhYmxlID0gcGlja1VuYXZhaWxhYmxlVHdlZXQocmF3LCBjdHgpO1xuICAgICAgaWYgKHVuYXZhaWxhYmxlKSB7XG4gICAgICAgIHVuYXZhaWxhYmxlVHdlZXRzLnB1c2godW5hdmFpbGFibGUpO1xuICAgICAgICBvYnNlcnZlZC5wdXNoKHVuYXZhaWxhYmxlLnR3ZWV0X2lkKTtcbiAgICAgICAgYnVpbHQuYWRkKHVuYXZhaWxhYmxlLnR3ZWV0X2lkKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBjb25zdCB0ID0gYnVpbGRUd2VldChyYXcsIGN0eCk7XG4gICAgICBpZiAoIXQpIHtcbiAgICAgICAgaWYgKGNvbGxlY3RQYXJ0aWFscykge1xuICAgICAgICAgIC8vIE9ubHkgZW5xdWV1ZSByZWFsLXR3ZWV0IHNoZWxscyB3aXRoIGEgdHJ1c3R3b3J0aHkgaGFuZGxlIChub3RcbiAgICAgICAgICAvLyB0b21ic3RvbmVzLCBzdHJpcHBlZCBub2RlcyBsYWNraW5nIGEgbGVnYWN5IGJsb2NrLCBnYXJiYWdlIElEcyxcbiAgICAgICAgICAvLyBvciBJRHMgdGhhdCB3b3VsZCByZXF1aXJlIGd1ZXNzaW5nIHRoZSBhdXRob3IgZnJvbSB0aGUgcGFnZSkuXG4gICAgICAgICAgY29uc3QgcGFydGlhbCA9IHBpY2tQYXJ0aWFsKHJhdyk7XG4gICAgICAgICAgaWYgKHBhcnRpYWwpIHBhcnRpYWxNYXAuc2V0KHBhcnRpYWwudHdlZXRfaWQsIHBhcnRpYWwuaGludF9oYW5kbGUpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIGJ1aWx0LmFkZCh0LnR3ZWV0X2lkKTtcbiAgICAgIGlmIChjdHguYWxsb3dlZEhhbmRsZXMuc2l6ZSA9PT0gMCB8fCBjdHguYWxsb3dlZEhhbmRsZXMuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgdHdlZXRzLnB1c2godCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBPbmUgYmFkIGVudHJ5IHNob3VsZG4ndCB0YWtlIGRvd24gdGhlIHdob2xlIGJhdGNoLlxuICAgIH1cbiAgfVxuICAvLyBBbnl0aGluZyB0aGF0IGVuZGVkIHVwIGluIHBhcnRpYWxNYXAgYnV0IEFMU08gY2FtZSBiYWNrIGFzIGEgYnVpbHRcbiAgLy8gdHdlZXQgKGRpZmZlcmVudCB3YWxrZXIgcGFzcywgc2FtZSBpZCkgaXNuJ3QgYWN0dWFsbHkgcGFydGlhbC5cbiAgY29uc3QgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcbiAgZm9yIChjb25zdCBbaWQsIGhpbnRdIG9mIHBhcnRpYWxNYXApIHtcbiAgICBpZiAoYnVpbHQuaGFzKGlkKSkgY29udGludWU7XG4gICAgcGFydGlhbF9pZHMucHVzaCh7IHR3ZWV0X2lkOiBpZCwgaGludF9oYW5kbGU6IGhpbnQgfSk7XG4gIH1cbiAgcmV0dXJuIHsgdHdlZXRzLCBvYnNlcnZlZF9pZHM6IG9ic2VydmVkLCB1bmF2YWlsYWJsZV90d2VldHM6IHVuYXZhaWxhYmxlVHdlZXRzLCBwYXJ0aWFsX2lkcyB9O1xufVxuXG5mdW5jdGlvbiBwaWNrVW5hdmFpbGFibGVUd2VldChub2RlOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBVbmF2YWlsYWJsZVR3ZWV0IHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBpZiAobi5fX3R5cGVuYW1lICE9PSAnVHdlZXRUb21ic3RvbmUnKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCB0d2VldElkID1cbiAgICBzdHJPck51bGwobi5yZXN0X2lkKSA/P1xuICAgIHBpY2tUd2VldElkRnJvbVVybHMobm9kZSkgPz9cbiAgICAoY3R4LnNvdXJjZVVybCA/IHR3ZWV0SWRGcm9tVHdlZXRVcmwoY3R4LnNvdXJjZVVybCkgOiBudWxsKTtcbiAgaWYgKCF0d2VldElkIHx8ICFUV0VFVF9JRF9SRS50ZXN0KHR3ZWV0SWQpKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCB1bmF2YWlsYWJsZVRleHQgPSBwaWNrVG9tYnN0b25lVGV4dChub2RlKTtcbiAgcmV0dXJuIHtcbiAgICB0d2VldF9pZDogdHdlZXRJZCxcbiAgICBhY2NvdW50X2hhbmRsZTpcbiAgICAgIHBpY2tIYW5kbGVGcm9tVHdlZXRVcmxzKG5vZGUsIHR3ZWV0SWQpID8/XG4gICAgICAoY3R4LnNvdXJjZVVybCA/IGhhbmRsZUZyb21Ud2VldFVybChjdHguc291cmNlVXJsLCB0d2VldElkKSA6IG51bGwpLFxuICAgIHVuYXZhaWxhYmxlX2RldGVjdGVkX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICB1bmF2YWlsYWJsZV9yZWFzb246IGNsYXNzaWZ5VW5hdmFpbGFibGVSZWFzb24odW5hdmFpbGFibGVUZXh0KSxcbiAgICB1bmF2YWlsYWJsZV90ZXh0OiB1bmF2YWlsYWJsZVRleHQsXG4gICAgdW5hdmFpbGFibGVfc291cmNlX3VybDogY3R4LnNvdXJjZVVybCA/PyBudWxsLFxuICB9O1xufVxuXG5mdW5jdGlvbiBwaWNrVHdlZXRJZEZyb21VcmxzKG5vZGU6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBjdXIgPSBzdGFjay5wb3AoKTtcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGNvbnN0IGlkID0gdHdlZXRJZEZyb21Ud2VldFVybChjdXIpO1xuICAgICAgaWYgKGlkKSByZXR1cm4gaWQ7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHNlZW4uaGFzKGN1ciBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChjdXIgYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgY3VyKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gdHdlZXRJZEZyb21Ud2VldFVybChyYXdVcmw6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICB0cnkge1xuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmF3VXJsLCBUV0VFVF9VUkxfUFJFRklYKTtcbiAgICBpZiAodXJsLmhvc3RuYW1lICE9PSAneC5jb20nICYmIHVybC5ob3N0bmFtZSAhPT0gJ3R3aXR0ZXIuY29tJykgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC9bQS1aYS16MC05X117MSwxNX1cXC9zdGF0dXNcXC8oXFxkezE1LDIwfSkoPzpcXC98JCkvKTtcbiAgICByZXR1cm4gbWF0Y2g/LlsxXSA/PyBudWxsO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBwaWNrVG9tYnN0b25lVGV4dChub2RlOiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gIGNvbnN0IHN0cmluZ3M6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgY3VyID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKHR5cGVvZiBjdXIgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25zdCB0cmltbWVkID0gY3VyLnRyaW0oKTtcbiAgICAgIGlmIChcbiAgICAgICAgdHJpbW1lZC5sZW5ndGggPj0gNCAmJlxuICAgICAgICAhdHJpbW1lZC5zdGFydHNXaXRoKCdodHRwOi8vJykgJiZcbiAgICAgICAgIXRyaW1tZWQuc3RhcnRzV2l0aCgnaHR0cHM6Ly8nKVxuICAgICAgKSB7XG4gICAgICAgIHN0cmluZ3MucHVzaCh0cmltbWVkKTtcbiAgICAgIH1cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY3VyID09PSBudWxsIHx8IHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAoc2Vlbi5oYXMoY3VyIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBjdXIpIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIGNvbnN0IHByZWZlcnJlZCA9IHN0cmluZ3MuZmluZCgocykgPT5cbiAgICAvXFxiKGNvcHlyaWdodHxkbWNhfHVuYXZhaWxhYmxlfHdpdGhoZWxkfHJlbW92ZWR8ZGVsZXRlZHx2aW9sYXR8c3VzcGVuZGVkKVxcYi9pLnRlc3QocylcbiAgKTtcbiAgcmV0dXJuIHByZWZlcnJlZCA/PyBzdHJpbmdzWzBdID8/IG51bGw7XG59XG5cbmZ1bmN0aW9uIGNsYXNzaWZ5VW5hdmFpbGFibGVSZWFzb24odGV4dDogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAoIXRleHQpIHJldHVybiBudWxsO1xuICBpZiAoL1xcYihjb3B5cmlnaHR8ZG1jYSlcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ2NvcHlyaWdodCc7XG4gIGlmICgvXFxid2l0aGhlbGRcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3dpdGhoZWxkJztcbiAgaWYgKC9cXGJkZWxldGVkfHJlbW92ZWRcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3JlbW92ZWQnO1xuICBpZiAoL1xcYnN1c3BlbmRlZFxcYi9pLnRlc3QodGV4dCkpIHJldHVybiAnc3VzcGVuZGVkJztcbiAgaWYgKC9cXGJ1bmF2YWlsYWJsZXxub3QgYXZhaWxhYmxlXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICd1bmF2YWlsYWJsZSc7XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBwaWNrUGFydGlhbChub2RlOiB1bmtub3duKTogeyB0d2VldF9pZDogc3RyaW5nOyBoaW50X2hhbmRsZTogc3RyaW5nIHwgbnVsbCB9IHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAvLyBEZWxldGVkIHR3ZWV0cyBzdXJmYWNlIGFzIFR3ZWV0VG9tYnN0b25lIFx1MjAxNCB0aGVyZSdzIG5vdGhpbmcgdG8gcmVmZXRjaCxcbiAgLy8gc2tpcCB0aGVtIG9yIHRoZSBjcmF3bCBsb29wIHdpbGwgc3BpbiBvbiBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXG4gIGlmIChuLl9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xuICAvLyBSZXF1aXJlIGEgcmVjb2duaXplZCBUd2VldCB0eXBlbmFtZSBPUiBhIGxlZ2FjeSBibG9jay4gQ3Vyc29ycywgYWRzLFxuICAvLyBtb2R1bGUgaGVhZGVycywgYW5kIHRoZSBsaWtlIGdldCByZWplY3RlZCBoZXJlLlxuICBjb25zdCB0biA9IG4uX190eXBlbmFtZTtcbiAgaWYgKHRuICE9PSAnVHdlZXQnICYmIHRuICE9PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnICYmICFvYmoobi5sZWdhY3kpKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgcmVzdElkID1cbiAgICAodHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgbi5yZXN0X2lkKSB8fFxuICAgICh0eXBlb2Ygb2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0ID09PSAnb2JqZWN0JyAmJlxuICAgICAgKG9iaihvYmoobi50d2VldF9yZXN1bHQpPy5yZXN1bHQpPy5yZXN0X2lkIGFzIHN0cmluZykpO1xuICBpZiAodHlwZW9mIHJlc3RJZCAhPT0gJ3N0cmluZycgfHwgIVRXRUVUX0lEX1JFLnRlc3QocmVzdElkKSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGhpbnRIYW5kbGUgPSBwaWNrSGludEhhbmRsZShub2RlLCByZXN0SWQpO1xuICBpZiAoIWhpbnRIYW5kbGUpIHJldHVybiBudWxsO1xuICByZXR1cm4geyB0d2VldF9pZDogcmVzdElkLCBoaW50X2hhbmRsZTogaGludEhhbmRsZSB9O1xufVxuXG5mdW5jdGlvbiBwaWNrSGludEhhbmRsZShub2RlOiB1bmtub3duLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JyB8fCBub2RlID09PSBudWxsKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gIGNvbnN0IHVzZXJSZXN1bHQgPSBvYmoob2JqKG9iaihuLmNvcmUpPy51c2VyX3Jlc3VsdHMpPy5yZXN1bHQpO1xuICByZXR1cm4gKFxuICAgIHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8uY29yZSk/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubGVnYWN5KT8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKG9iaihuLmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHBpY2tIYW5kbGVGcm9tVHdlZXRVcmxzKG5vZGUsIHR3ZWV0SWQpXG4gICk7XG59XG5cbmZ1bmN0aW9uIHBpY2tIYW5kbGVGcm9tVHdlZXRVcmxzKG5vZGU6IHVua25vd24sIHR3ZWV0SWQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGN1ciA9IHN0YWNrLnBvcCgpO1xuICAgIGlmICh0eXBlb2YgY3VyID09PSAnc3RyaW5nJykge1xuICAgICAgY29uc3QgaGFuZGxlID0gaGFuZGxlRnJvbVR3ZWV0VXJsKGN1ciwgdHdlZXRJZCk7XG4gICAgICBpZiAoaGFuZGxlKSByZXR1cm4gaGFuZGxlO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmIChzZWVuLmhhcyhjdXIgYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQoY3VyIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIGN1cikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmZ1bmN0aW9uIGhhbmRsZUZyb21Ud2VldFVybChyYXdVcmw6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIHRyeSB7XG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChyYXdVcmwsIFRXRUVUX1VSTF9QUkVGSVgpO1xuICAgIGlmICh1cmwuaG9zdG5hbWUgIT09ICd4LmNvbScgJiYgdXJsLmhvc3RuYW1lICE9PSAndHdpdHRlci5jb20nKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBtYXRjaCA9IHVybC5wYXRobmFtZS5tYXRjaCgvXlxcLyhbQS1aYS16MC05X117MSwxNX0pXFwvc3RhdHVzXFwvKFxcZHsxNSwyMH0pKD86XFwvfCQpLyk7XG4gICAgaWYgKCFtYXRjaCB8fCBtYXRjaFsyXSAhPT0gdHdlZXRJZCkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIG1hdGNoWzFdID8/IG51bGw7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNvbGxlY3RUd2VldHMob2JqOiB1bmtub3duKTogdW5rbm93bltdIHtcbiAgLy8gV2FsayB0aGUgcmVzcG9uc2UgdHJlZSBnYXRoZXJpbmcgZXZlcnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSB0d2VldFxuICAvLyByZXN1bHQuIFdlIGxvb2sgZm9yIG5vZGVzIHNoYXBlZCBsaWtlOlxuICAvLyAgIHsgX190eXBlbmFtZT86ICdUd2VldCd8J1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJywgcmVzdF9pZCwgbGVnYWN5IH1cbiAgLy8gYW5kIHVud3JhcCB2aXNpYmlsaXR5IHdyYXBwZXJzLlxuICBjb25zdCBvdXQ6IHVua25vd25bXSA9IFtdO1xuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW29ial07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3Qgbm9kZSA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChub2RlID09PSBudWxsIHx8IG5vZGUgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHNlZW4uaGFzKG5vZGUgYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQobm9kZSBhcyBvYmplY3QpO1xuXG4gICAgaWYgKGxvb2tzTGlrZVR3ZWV0KG5vZGUpKSB7XG4gICAgICBvdXQucHVzaCh1bndyYXBUd2VldChub2RlKSk7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KG5vZGUpKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbm9kZSkgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMobm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIGxvb2tzTGlrZVR3ZWV0KG5vZGU6IHVua25vd24pOiBub2RlIGlzIFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JyB8fCBub2RlID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBjb25zdCB0eXBlbmFtZSA9IG4uX190eXBlbmFtZTtcbiAgaWYgKFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXQnIHx8XG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgfHxcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJ1xuICApIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICAvLyBTb21lIGVudHJpZXMgbGFjayBfX3R5cGVuYW1lIGJ1dCBzdGlsbCBjYXJyeSBsZWdhY3kgKyByZXN0X2lkICsgY29yZS5cbiAgcmV0dXJuIHR5cGVvZiBuLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIHR5cGVvZiBuLmxlZ2FjeSA9PT0gJ29iamVjdCcgJiYgbi5sZWdhY3kgIT09IG51bGw7XG59XG5cbmZ1bmN0aW9uIHVud3JhcFR3ZWV0KG5vZGU6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xuICBpZiAobm9kZS5fX3R5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnICYmIHR5cGVvZiBub2RlLnR3ZWV0ID09PSAnb2JqZWN0Jykge1xuICAgIHJldHVybiBub2RlLnR3ZWV0IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICB9XG4gIHJldHVybiBub2RlO1xufVxuXG5mdW5jdGlvbiBidWlsZFR3ZWV0KHJhdzogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogQ2Fub25pY2FsVHdlZXQgfCBudWxsIHtcbiAgaWYgKHR5cGVvZiByYXcgIT09ICdvYmplY3QnIHx8IHJhdyA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHQgPSByYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG5cbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgcmVzdElkID0gc3RyT3JOdWxsKHQucmVzdF9pZCk7XG4gIC8vIGBsZWdhY3lgIGlzIHN0aWxsIHdoZXJlIG1vc3QgZW5nYWdlbWVudCAvIGVudGl0aWVzIGxpdmUgaW4gMjAyNi1lcmEgWFxuICAvLyBwYXlsb2FkcywgYnV0IGFzIG9mIHJlY2VudCBzY2hlbWEgbWlncmF0aW9ucyBzZXZlcmFsIGZpZWxkcyBwcmV2aW91c2x5XG4gIC8vIHRoZXJlIChub3RhYmx5IHRoZSBhdXRob3IgaGFuZGxlKSBoYXZlIG1vdmVkIHRvIHNpYmxpbmcgbG9jYXRpb25zLiBXZVxuICAvLyB0b2xlcmF0ZSBhIG1pc3NpbmcgbGVnYWN5IGhlcmUgYW5kIGxvb2sgdXAgZXZlcnl0aGluZyB2aWEgZmFsbGJhY2tzLlxuICBjb25zdCBsZWdhY3kgPSBvYmoodC5sZWdhY3kpID8/IHt9O1xuICBpZiAoIXJlc3RJZCkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgY29yZSA9IG9iaih0LmNvcmUpO1xuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihjb3JlPy51c2VyX3Jlc3VsdHMpPy5yZXN1bHQpO1xuICAvLyBBdXRob3IgaGFuZGxlOiB0cnkgdGhlIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIGZpcnN0IChjdXJyZW50IFggc2hhcGUpLFxuICAvLyB0aGVuIHRoZSBsZWdhY3kgYGxlZ2FjeS5zY3JlZW5fbmFtZWAsIHRoZW4gYSBjb3VwbGUgb2Ygb2xkZXIgdmFyaWFudHMuXG4gIGNvbnN0IHVzZXJDb3JlTmV3ID0gb2JqKHVzZXJSZXN1bHQ/LmNvcmUpO1xuICBjb25zdCB1c2VyTGVnYWN5ID0gb2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk7XG4gIGNvbnN0IHVzZXJBdmF0YXJPYmogPSBvYmoodXNlclJlc3VsdD8uYXZhdGFyKTtcbiAgY29uc3QgaGFuZGxlID1cbiAgICBzdHJPck51bGwodXNlckNvcmVOZXc/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwodXNlclJlc3VsdD8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKGxlZ2FjeS5zY3JlZW5fbmFtZSk7XG4gIGNvbnN0IGFjY291bnRJZCA9XG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnJlc3RfaWQpID8/XG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LmlkX3N0cikgPz9cbiAgICBzdHJPck51bGwobGVnYWN5LnVzZXJfaWRfc3RyKTtcbiAgaWYgKCFoYW5kbGUgfHwgIWFjY291bnRJZCkgcmV0dXJuIG51bGw7XG4gIC8vIEF1dGhvciBzbmFwc2hvdC4gRGlzcGxheSBuYW1lICsgYXZhdGFyIG1vdmVkIGJldHdlZW4gYGxlZ2FjeWAgYW5kIHRoZVxuICAvLyBuZXcgYGNvcmVgIHN1YnN0cnVjdHVyZSBvdmVyIHRpbWU7IHRoZSByZXN0ICh2ZXJpZmljYXRpb24sIGZvbGxvd2VyXG4gIC8vIGNvdW50cywgYWNjb3VudF9jcmVhdGVkX2F0KSBpcyBzdGlsbCBpbiBgbGVnYWN5YC4gV2Ugc25hcHNob3QgdGhlXG4gIC8vIHdob2xlIFVzZXJTbmFwc2hvdCBwZXIgdHdlZXQgYmVjYXVzZSB0aGVzZSB2YWx1ZXMgZHJpZnQgb3ZlciB0aW1lXG4gIC8vIGFuZCB0aGUgYXQtY2FwdHVyZSBzdGF0ZSBpcyB0aGUgb25seSByZWxpYWJsZSByZWNvcmQuXG4gIGNvbnN0IGF1dGhvciA9IGV4dHJhY3RVc2VyU25hcHNob3QodXNlclJlc3VsdCwgdXNlckNvcmVOZXcsIHVzZXJMZWdhY3ksIHVzZXJBdmF0YXJPYmopO1xuXG4gIGNvbnN0IG5vdGVUd2VldCA9IG9iaihvYmoob2JqKHQubm90ZV90d2VldCk/Lm5vdGVfdHdlZXRfcmVzdWx0cyk/LnJlc3VsdCk7XG4gIGNvbnN0IHRleHRGcm9tTm90ZSA9IHN0ck9yTnVsbChub3RlVHdlZXQ/LnRleHQpO1xuICBjb25zdCB0ZXh0RnJvbUxlZ2FjeSA9IHN0ck9yTnVsbChsZWdhY3kuZnVsbF90ZXh0KSA/PyAnJztcbiAgY29uc3QgdGV4dCA9IHRleHRGcm9tTm90ZSA/PyB0ZXh0RnJvbUxlZ2FjeTtcbiAgY29uc3QgaXNUcnVuY2F0ZWQgPSBkZXRlY3RUcnVuY2F0aW9uKG5vdGVUd2VldCwgbGVnYWN5LCB0ZXh0RnJvbUxlZ2FjeSk7XG4gIGNvbnN0IGNvbW11bml0eU5vdGUgPSBleHRyYWN0Q29tbXVuaXR5Tm90ZSh0LCBsZWdhY3ksIGN0eC5jYXB0dXJlZEF0KTtcblxuICBjb25zdCBlbnRpdGllcyA9IG9iaihsZWdhY3kuZW50aXRpZXMpID8/IHt9O1xuICBjb25zdCBlbnRpdGllc0Zyb21Ob3RlID0gb2JqKG5vdGVUd2VldD8uZW50aXR5X3NldCk7XG4gIGNvbnN0IGhhc2h0YWdzID0gZXh0cmFjdEhhc2h0YWdzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xuICBjb25zdCBtZW50aW9ucyA9IGV4dHJhY3RNZW50aW9ucyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgdXJscyA9IGV4dHJhY3RVcmxzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xuICBjb25zdCBtZWRpYSA9IGV4dHJhY3RNZWRpYShsZWdhY3kpO1xuXG4gIGNvbnN0IHR3ZWV0VHlwZSA9IGNsYXNzaWZ5VHdlZXRUeXBlKHQsIGxlZ2FjeSk7XG5cbiAgLy8gWCBvbWl0cyBmYXZvcml0ZV9jb3VudCAvIHJlcGx5X2NvdW50IC8gcXVvdGVfY291bnQgZnJvbSBhIHJldHdlZXRcbiAgLy8gd3JhcHBlcidzIGxlZ2FjeSBibG9jayAob25seSByZXR3ZWV0X2NvdW50IGlzIHByb3BhZ2F0ZWQpIFx1MjAxNCB0aGUgcmVhbFxuICAvLyBjb3VudHMgbGl2ZSBvbiB0aGUgcmV0d2VldGVkIHN0YXR1cy4gUmVhZCBlbmdhZ2VtZW50IGZyb20gdGhlcmUgZm9yXG4gIC8vIHJldHdlZXRzIHNvIHdlIGRvbid0IHJlY29yZCAwIGxpa2VzL3JlcGxpZXMvcXVvdGVzIG9uIGV2ZXJ5IHJldHdlZXQuXG4gIGNvbnN0IHJldHdlZXRlZExlZ2FjeSA9IG9iaihvYmoob2JqKGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX3Jlc3VsdCk/LnJlc3VsdCk/LmxlZ2FjeSk7XG4gIGNvbnN0IGVuZ0xlZ2FjeSA9IHR3ZWV0VHlwZSA9PT0gJ3JldHdlZXQnICYmIHJldHdlZXRlZExlZ2FjeSA/IHJldHdlZXRlZExlZ2FjeSA6IGxlZ2FjeTtcblxuICAvLyBwb3N0ZWRfYXQ6IGxlZ2FjeS5jcmVhdGVkX2F0IHJlbWFpbnMgdGhlIGNhbm9uaWNhbCBsb2NhdGlvbjsgaWYgdGhhdCdzXG4gIC8vIG1pc3NpbmcgaW4gYSBmdXR1cmUgc2NoZW1hIHdlIGZhbGwgYmFjayB0byB0b3AtbGV2ZWwgY3JlYXRlZF9hdC5cbiAgY29uc3QgcG9zdGVkQXQgPVxuICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKGxlZ2FjeS5jcmVhdGVkX2F0KSkgPz8gcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodC5jcmVhdGVkX2F0KSk7XG4gIGlmICghcG9zdGVkQXQpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHZpZXdzID0gb2JqKHQudmlld3MpO1xuICBjb25zdCB2aWV3Q291bnQgPSBudW1Pck51bGwodmlld3M/LmNvdW50KSA/PyBudW1Pck51bGwoc3RyT3JOdWxsKHZpZXdzPy5jb3VudCkpO1xuXG4gIGNvbnN0IGNhcmQgPSBleHRyYWN0Q2FyZCh0KTtcbiAgY29uc3QgcGxhY2UgPSBvYmoobGVnYWN5LnBsYWNlKTtcblxuICBjb25zdCB0d2VldDogQ2Fub25pY2FsVHdlZXQgPSB7XG4gICAgdHdlZXRfaWQ6IHJlc3RJZCxcbiAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgIGFjY291bnRfaWQ6IGFjY291bnRJZCxcbiAgICBwb3N0ZWRfYXQ6IHBvc3RlZEF0LFxuICAgIGZpcnN0X2NhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICBsYXN0X3NlZW5fYXQ6IGN0eC5jYXB0dXJlZEF0LFxuICAgIGRlbGV0aW9uX2RldGVjdGVkX2F0OiBudWxsLFxuICAgIHVuYXZhaWxhYmxlX2RldGVjdGVkX2F0OiBudWxsLFxuICAgIHVuYXZhaWxhYmxlX3JlYXNvbjogbnVsbCxcbiAgICB1bmF2YWlsYWJsZV90ZXh0OiBudWxsLFxuICAgIHVuYXZhaWxhYmxlX3NvdXJjZV91cmw6IG51bGwsXG4gICAgdHdlZXRfdXJsOiBgJHtUV0VFVF9VUkxfUFJFRklYfS8ke2hhbmRsZX0vc3RhdHVzLyR7cmVzdElkfWAsXG4gICAgdHdlZXRfdHlwZTogdHdlZXRUeXBlLFxuICAgIGNvbnZlcnNhdGlvbl9pZDogc3RyT3JOdWxsKGxlZ2FjeS5jb252ZXJzYXRpb25faWRfc3RyKSxcbiAgICByZXBseV90b190d2VldF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zdGF0dXNfaWRfc3RyKSxcbiAgICByZXBseV90b19hY2NvdW50OiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3NjcmVlbl9uYW1lKSxcbiAgICByZXBseV90b19hY2NvdW50X2lkOiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3VzZXJfaWRfc3RyKSxcbiAgICBxdW90ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChsZWdhY3kucXVvdGVkX3N0YXR1c19pZF9zdHIpLFxuICAgIHJldHdlZXRlZF90d2VldF9pZDogc3RyT3JOdWxsKFxuICAgICAgb2JqKG9iaihsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQpPy5yZXN1bHQpPy5yZXN0X2lkID8/XG4gICAgICAgIChsZWdhY3kgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLnJldHdlZXRlZF9zdGF0dXNfaWRfc3RyXG4gICAgKSxcbiAgICB0ZXh0LFxuICAgIHRleHRfcmVzb2x2ZWQ6IHJlc29sdmVTaG9ydFVybHModGV4dCwgdXJscyksXG4gICAgbGFuZzogc3RyT3JOdWxsKGxlZ2FjeS5sYW5nKSxcbiAgICBwb3NzaWJseV9zZW5zaXRpdmU6IGJvb2xPck51bGwobGVnYWN5LnBvc3NpYmx5X3NlbnNpdGl2ZSksXG4gICAgc291cmNlOiBzdHJPck51bGwobGVnYWN5LnNvdXJjZSkgPz8gc3RyT3JOdWxsKHQuc291cmNlKSxcbiAgICBwbGFjZV9mdWxsX25hbWU6IHN0ck9yTnVsbChwbGFjZT8uZnVsbF9uYW1lKSxcbiAgICBoYXNodGFncyxcbiAgICBtZW50aW9ucyxcbiAgICB1cmxzLFxuICAgIGNhcmQsXG4gICAgbWVkaWEsXG4gICAgbGlrZV9jb3VudDogbnVtT3JaZXJvKGVuZ0xlZ2FjeS5mYXZvcml0ZV9jb3VudCksXG4gICAgcmV0d2VldF9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcbiAgICByZXBseV9jb3VudDogbnVtT3JaZXJvKGVuZ0xlZ2FjeS5yZXBseV9jb3VudCksXG4gICAgcXVvdGVfY291bnQ6IG51bU9yWmVybyhlbmdMZWdhY3kucXVvdGVfY291bnQpLFxuICAgIHZpZXdfY291bnQ6IHZpZXdDb3VudCxcbiAgICBib29rbWFya19jb3VudDogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXG4gICAgZW5nYWdlbWVudF9oaXN0b3J5OiBbXG4gICAgICB7XG4gICAgICAgIGNhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICAgICAgbGlrZXM6IG51bU9yWmVybyhlbmdMZWdhY3kuZmF2b3JpdGVfY291bnQpLFxuICAgICAgICByZXR3ZWV0czogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcbiAgICAgICAgcmVwbGllczogbnVtT3JaZXJvKGVuZ0xlZ2FjeS5yZXBseV9jb3VudCksXG4gICAgICAgIHF1b3RlczogbnVtT3JaZXJvKGVuZ0xlZ2FjeS5xdW90ZV9jb3VudCksXG4gICAgICAgIHZpZXdzOiB2aWV3Q291bnQsXG4gICAgICAgIGJvb2ttYXJrczogbnVtT3JOdWxsKGxlZ2FjeS5ib29rbWFya19jb3VudCksXG4gICAgICB9LFxuICAgIF0sXG4gICAgYXV0aG9yLFxuICAgIGNvbW11bml0eV9ub3RlOiBjb21tdW5pdHlOb3RlLFxuICAgIGlzX3RydW5jYXRlZDogaXNUcnVuY2F0ZWQsXG4gICAgd2F5YmFja191cmw6IG51bGwsXG4gICAgd2F5YmFja19zdWJtaXR0ZWRfYXQ6IG51bGwsXG4gICAgY2FwdHVyZV9zb3VyY2U6ICdleHRlbnNpb24nLFxuICAgIGNhcHR1cmVfcnVuX2lkOiBjdHgucnVuSWQsXG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gIH07XG5cbiAgcmV0dXJuIHR3ZWV0O1xufVxuXG5mdW5jdGlvbiBjbGFzc2lmeVR3ZWV0VHlwZSh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFR3ZWV0VHlwZSB7XG4gIGlmIChsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQgfHwgbGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JldHdlZXQnO1xuICBpZiAobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpIHJldHVybiAncmVwbHknO1xuICBpZiAobGVnYWN5LmlzX3F1b3RlX3N0YXR1cyA9PT0gdHJ1ZSB8fCBsZWdhY3kucXVvdGVkX3N0YXR1c19pZF9zdHIpIHJldHVybiAncXVvdGUnO1xuICBpZiAodC5fX3R5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnKSB7XG4gICAgLy8gcGFzcyB0aHJvdWdoXG4gIH1cbiAgcmV0dXJuICdvcmlnaW5hbCc7XG59XG5cbmZ1bmN0aW9uIGV4dHJhY3RIYXNodGFncyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLmhhc2h0YWdzO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICByZXR1cm4gYXJyXG4gICAgLm1hcCgoaCkgPT5cbiAgICAgIHR5cGVvZiBoID09PSAnb2JqZWN0JyAmJiBoICYmICd0ZXh0JyBpbiBoID8gU3RyaW5nKChoIGFzIHsgdGV4dDogdW5rbm93biB9KS50ZXh0KSA6IG51bGxcbiAgICApXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0TWVudGlvbnMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy51c2VyX21lbnRpb25zO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICByZXR1cm4gYXJyXG4gICAgLm1hcCgodSkgPT5cbiAgICAgIHR5cGVvZiB1ID09PSAnb2JqZWN0JyAmJiB1ICYmICdzY3JlZW5fbmFtZScgaW4gdVxuICAgICAgICA/IFN0cmluZygodSBhcyB7IHNjcmVlbl9uYW1lOiB1bmtub3duIH0pLnNjcmVlbl9uYW1lKVxuICAgICAgICA6IG51bGxcbiAgICApXG4gICAgLmZpbHRlcigocyk6IHMgaXMgc3RyaW5nID0+IHR5cGVvZiBzID09PSAnc3RyaW5nJyAmJiBzLmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0VXJscyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBVcmxFbnRpdHlbXSB7XG4gIGNvbnN0IGFyciA9IGVudGl0aWVzLnVybHM7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XG4gIGNvbnN0IG91dDogVXJsRW50aXR5W10gPSBbXTtcbiAgZm9yIChjb25zdCB1IG9mIGFycikge1xuICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XG4gICAgY29uc3QgbyA9IHUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgY29uc3Qgc2hvcnQgPSBzdHJPck51bGwoby51cmwpO1xuICAgIGNvbnN0IGV4cGFuZGVkID0gc3RyT3JOdWxsKG8uZXhwYW5kZWRfdXJsKTtcbiAgICBjb25zdCBkaXNwbGF5ID0gc3RyT3JOdWxsKG8uZGlzcGxheV91cmwpO1xuICAgIGlmICghc2hvcnQgfHwgIWV4cGFuZGVkKSBjb250aW51ZTtcbiAgICBvdXQucHVzaCh7IHNob3J0LCBleHBhbmRlZCwgZGlzcGxheTogZGlzcGxheSA/PyBleHBhbmRlZCB9KTtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBleHRyYWN0TWVkaWEobGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbVtdIHtcbiAgY29uc3QgZXh0ZW5kZWQgPSBvYmoobGVnYWN5LmV4dGVuZGVkX2VudGl0aWVzKTtcbiAgY29uc3QgZnJvbUV4dCA9IGV4dGVuZGVkID8gdG9BcnJheShleHRlbmRlZC5tZWRpYSkgOiBbXTtcbiAgY29uc3QgZnJvbUVudCA9IHRvQXJyYXkob2JqKGxlZ2FjeS5lbnRpdGllcyk/Lm1lZGlhKTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCBtZXJnZWQgPSBbLi4uZnJvbUV4dCwgLi4uZnJvbUVudF0uZmlsdGVyKChtKSA9PiB7XG4gICAgaWYgKHR5cGVvZiBtICE9PSAnb2JqZWN0JyB8fCBtID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgaWQgPVxuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5tZWRpYV9rZXkpID8/XG4gICAgICBzdHJPck51bGwoKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLmlkX3N0cik7XG4gICAgaWYgKCFpZCkgcmV0dXJuIGZhbHNlO1xuICAgIGlmIChzZWVuLmhhcyhpZCkpIHJldHVybiBmYWxzZTtcbiAgICBzZWVuLmFkZChpZCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuICByZXR1cm4gbWVyZ2VkLm1hcCgocmF3KSA9PiBidWlsZE1lZGlhKHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpO1xufVxuXG5mdW5jdGlvbiBidWlsZE1lZGlhKG06IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogTWVkaWFJdGVtIHtcbiAgY29uc3QgdHlwZSA9IHN0ck9yTnVsbChtLnR5cGUpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddO1xuICBjb25zdCBvcmlnaW5hbCA9IHBpY2tPcmlnaW5hbFVybChtLCB0eXBlKTtcbiAgY29uc3QgaW5mbyA9IG9iaihtLm9yaWdpbmFsX2luZm8pO1xuICBjb25zdCB2aWRlb0luZm8gPSBvYmoobS52aWRlb19pbmZvKTtcbiAgY29uc3QgZHVyYXRpb25NcyA9IG51bU9yTnVsbCh2aWRlb0luZm8/LmR1cmF0aW9uX21pbGxpcyk7XG4gIGNvbnN0IGFsdFRleHQgPSBzdHJPck51bGwobS5leHRfYWx0X3RleHQpO1xuICBjb25zdCBtZWRpYUlkID1cbiAgICBzdHJPck51bGwobS5tZWRpYV9rZXkpID8/XG4gICAgc3RyT3JOdWxsKG0uaWRfc3RyKSA/P1xuICAgIGAke3R5cGUgPz8gJ21lZGlhJ30tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKX1gO1xuICByZXR1cm4ge1xuICAgIG1lZGlhX2lkOiBtZWRpYUlkLFxuICAgIG1lZGlhX3R5cGU6ICh0eXBlID8/ICdwaG90bycpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddLFxuICAgIG9yaWdpbmFsX3VybDogb3JpZ2luYWwgPz8gJycsXG4gICAgcmVsZWFzZV9hc3NldF91cmw6IG51bGwsXG4gICAgc2hhMjU2OiBudWxsLFxuICAgIGJ5dGVzOiBudWxsLFxuICAgIGR1cmF0aW9uX3NlYzogZHVyYXRpb25NcyAhPT0gbnVsbCA/IGR1cmF0aW9uTXMgLyAxMDAwIDogbnVsbCxcbiAgICB3aWR0aDogbnVtT3JOdWxsKGluZm8/LndpZHRoKSxcbiAgICBoZWlnaHQ6IG51bU9yTnVsbChpbmZvPy5oZWlnaHQpLFxuICAgIGFsdF90ZXh0OiBhbHRUZXh0LFxuICAgIGFyY2hpdmVfc3RhdHVzOiAncGVuZGluZycsXG4gICAgYXJjaGl2ZV9hdHRlbXB0czogMCxcbiAgICBsYXN0X2F0dGVtcHRfYXQ6IG51bGwsXG4gIH07XG59XG5cbmZ1bmN0aW9uIHBpY2tPcmlnaW5hbFVybChtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdHlwZTogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAodHlwZSA9PT0gJ3Bob3RvJykgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcykgPz8gc3RyT3JOdWxsKG0ubWVkaWFfdXJsKTtcbiAgY29uc3QgdmFyaWFudHMgPSB0b0FycmF5KG9iaihtLnZpZGVvX2luZm8pPy52YXJpYW50cykgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj5bXTtcbiAgaWYgKHZhcmlhbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcyk7XG4gIC8vIEhpZ2hlc3QtYml0cmF0ZSBtcDQuXG4gIGxldCBiZXN0OiB7IHVybDogc3RyaW5nOyBiaXRyYXRlOiBudW1iZXIgfSB8IG51bGwgPSBudWxsO1xuICBmb3IgKGNvbnN0IHYgb2YgdmFyaWFudHMpIHtcbiAgICBjb25zdCBjdCA9IHN0ck9yTnVsbCh2LmNvbnRlbnRfdHlwZSk7XG4gICAgY29uc3QgdXJsID0gc3RyT3JOdWxsKHYudXJsKTtcbiAgICBpZiAoIXVybCkgY29udGludWU7XG4gICAgaWYgKGN0ID09PSAndmlkZW8vbXA0Jykge1xuICAgICAgY29uc3QgYnIgPSBudW1Pck51bGwodi5iaXRyYXRlKSA/PyAwO1xuICAgICAgaWYgKCFiZXN0IHx8IGJyID4gYmVzdC5iaXRyYXRlKSBiZXN0ID0geyB1cmwsIGJpdHJhdGU6IGJyIH07XG4gICAgfSBlbHNlIGlmICghYmVzdCkge1xuICAgICAgLy8gRmFsbGJhY2sgdG8gYW55IHZhcmlhbnQgaWYgbm8gbXA0IGZvdW5kLlxuICAgICAgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiAwIH07XG4gICAgfVxuICB9XG4gIHJldHVybiBiZXN0Py51cmwgPz8gbnVsbDtcbn1cblxuZnVuY3Rpb24gcmVzb2x2ZVNob3J0VXJscyh0ZXh0OiBzdHJpbmcsIHVybHM6IFVybEVudGl0eVtdKTogc3RyaW5nIHtcbiAgaWYgKHVybHMubGVuZ3RoID09PSAwKSByZXR1cm4gdGV4dDtcbiAgbGV0IG91dCA9IHRleHQ7XG4gIGZvciAoY29uc3QgdSBvZiB1cmxzKSBvdXQgPSBvdXQuc3BsaXQodS5zaG9ydCkuam9pbih1LmV4cGFuZGVkKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gcGFyc2VUd2l0dGVyRGF0ZShzOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICghcykgcmV0dXJuIG51bGw7XG4gIC8vIFR3aXR0ZXIgc2hpcHMgZGF0ZXMgbGlrZSBcIk1vbiBBcHIgMTIgMTQ6MjM6MDEgKzAwMDAgMjAyNVwiLlxuICBjb25zdCBkID0gbmV3IERhdGUocyk7XG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIGQudG9JU09TdHJpbmcoKTtcbn1cblxuZnVuY3Rpb24gc3RyT3JOdWxsKHY6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDAgPyB2IDogbnVsbDtcbn1cbmZ1bmN0aW9uIGJvb2xPck51bGwodjogdW5rbm93bik6IGJvb2xlYW4gfCBudWxsIHtcbiAgcmV0dXJuIHR5cGVvZiB2ID09PSAnYm9vbGVhbicgPyB2IDogbnVsbDtcbn1cbmZ1bmN0aW9uIG51bU9yTnVsbCh2OiB1bmtub3duKTogbnVtYmVyIHwgbnVsbCB7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ251bWJlcicgJiYgTnVtYmVyLmlzRmluaXRlKHYpKSByZXR1cm4gdjtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gTnVtYmVyKHYpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikpIHJldHVybiBuO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gbnVtT3JaZXJvKHY6IHVua25vd24pOiBudW1iZXIge1xuICByZXR1cm4gbnVtT3JOdWxsKHYpID8/IDA7XG59XG5mdW5jdGlvbiBvYmoodjogdW5rbm93bik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ29iamVjdCcgJiYgdiAhPT0gbnVsbCAmJiAhQXJyYXkuaXNBcnJheSh2KVxuICAgID8gKHYgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pXG4gICAgOiBudWxsO1xufVxuZnVuY3Rpb24gdG9BcnJheSh2OiB1bmtub3duKTogdW5rbm93bltdIHtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkodikgPyB2IDogW107XG59XG5cbi8qKlxuICogRGVjaWRlIHdoZXRoZXIgYSB0d2VldCdzIGFyY2hpdmVkIGB0ZXh0YCBpcyB0aGUgdHJ1bmNhdGVkIGhlYWQgb2YgYSBsb25nZXJcbiAqIGJvZHkuIEEgdHJ1bmNhdGVkIHR3ZWV0IGhhcyBYJ3MgXCJTaG93IG1vcmVcIiB0LmNvIFVSTCBhcHBlbmRlZCBcdTIwMTQgdGhhdCBVUkxcbiAqIHNwZWNpZmljYWxseSBleHBhbmRzIHRvIHRoZSB0d2VldCdzIG93biAvaS93ZWIvc3RhdHVzLzxpZD4gcGVybWFsaW5rLCBhbmRcbiAqIGlzIHRoZSBvbmx5IHJlbGlhYmxlIGRpc3Rpbmd1aXNoaW5nIGZlYXR1cmUuIFBsZW50eSBvZiBub3JtYWwgdHdlZXRzIGhhdmVcbiAqIHRyYWlsaW5nIHQuY28gVVJMcyAobWVkaWEsIHF1b3RlcywgcmVndWxhciBsaW5rcyksIGFuZCB0aGVpclxuICogZGlzcGxheV90ZXh0X3JhbmdlIGFsc28gdHJpbXMgcGFzdCBmdWxsX3RleHQubGVuZ3RoLCBzbyB0aGUgb2xkXG4gKiBcImRpc3BsYXlfdGV4dF9yYW5nZVsxXSA8IGZ1bGxfdGV4dC5sZW5ndGhcIiBoZXVyaXN0aWMgd2FzIG92ZXJmbGFnZ2luZ1xuICogZXNzZW50aWFsbHkgZXZlcnkgdHdlZXQgd2l0aCBhIGxpbmsgaW4gaXQuXG4gKlxuICogUnVsZXM6XG4gKiAgIC0gbm90ZV90d2VldCBwcmVzZW50ICBcdTIxOTIgbm90IHRydW5jYXRlZCAod2UgYWxyZWFkeSBoYXZlIHRoZSBmdWxsIGJvZHkpLlxuICogICAtIE9uZSBvZiBsZWdhY3kuZW50aXRpZXMudXJscyBoYXMgYW4gZXhwYW5kZWRfdXJsIGxpa2VcbiAqICAgICBcIi4uLi9pL3dlYi9zdGF0dXMvPGlkPlwiICBcdTIxOTIgIHRydW5jYXRlZC5cbiAqICAgLSBPdGhlcndpc2UgXHUyMTkyIG5vdCB0cnVuY2F0ZWQuXG4gKlxuICogVGhlIHByZXZpb3VzIGZhbGxiYWNrIChcInRyYWlsaW5nIHQuY28gVVJMICsgbGVuZ3RoIFx1MjI2NSAyNzBcIikgZmxhZ2dlZCBldmVyeVxuICogbWVkaWEgdHdlZXQgZXhhY3RseSBhdCB0aGUgMjgwLWNoYXIgbGltaXQuIFdlIGRyb3AgaXQgZW50aXJlbHk7IHRoZSBvbmx5XG4gKiBjb3N0IGlzIG1pc3NpbmcgZ2VudWluZWx5LXRydW5jYXRlZCB0d2VldHMgd2hvc2UgcGF5bG9hZCB3YXMgc28gZGVncmFkZWRcbiAqIGl0IGxhY2tlZCBlbnRpdGllcyBcdTIwMTQgd2hpY2ggaXMgYWxzbyB3aGVyZSB0aGUgcmVmZXRjaCBsb29wIHdvdWxkIGZhaWxcbiAqIGFueXdheSwgc28gbm90aGluZyBpcyBhY3R1YWxseSBsb3N0LlxuICovXG5mdW5jdGlvbiBkZXRlY3RUcnVuY2F0aW9uKFxuICBub3RlVHdlZXQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAgZnVsbFRleHQ6IHN0cmluZ1xuKTogYm9vbGVhbiB7XG4gIGlmIChub3RlVHdlZXQpIHJldHVybiBmYWxzZTtcbiAgaWYgKCFmdWxsVGV4dCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBlbnRpdGllcyA9IG9iaihsZWdhY3kuZW50aXRpZXMpO1xuICBjb25zdCB1cmxzID0gZW50aXRpZXMgPyBlbnRpdGllcy51cmxzIDogbnVsbDtcbiAgaWYgKEFycmF5LmlzQXJyYXkodXJscykpIHtcbiAgICBmb3IgKGNvbnN0IHUgb2YgdXJscykge1xuICAgICAgaWYgKHR5cGVvZiB1ICE9PSAnb2JqZWN0JyB8fCB1ID09PSBudWxsKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IGV4cCA9ICh1IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5leHBhbmRlZF91cmw7XG4gICAgICAvLyBUaGUgXCJTaG93IG1vcmVcIiBsaW5rIGV4cGFuZHMgdG8gZWl0aGVyIG9mIHRoZXNlIHNlbGYtcGVybWFsaW5rXG4gICAgICAvLyBzaGFwZXM6ICBodHRwczovL3guY29tL2kvd2ViL3N0YXR1cy88aWQ+XG4gICAgICAvLyAgICAgICAgICBodHRwczovL3R3aXR0ZXIuY29tL2kvd2ViL3N0YXR1cy88aWQ+XG4gICAgICBpZiAodHlwZW9mIGV4cCA9PT0gJ3N0cmluZycgJiYgL1xcL2lcXC93ZWJcXC9zdGF0dXNcXC9cXGQrLy50ZXN0KGV4cCkpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuLyoqXG4gKiBGaWx0ZXIgYHR3ZWV0c2AgZG93biB0byB0aG9zZSByZWxhdGVkIHRvIGEgdHJhY2tlZCBhY2NvdW50LiBBIHR3ZWV0IGlzXG4gKiBcInJlbGF0ZWRcIiBpZiBhbnkgb2YgdGhlIGZvbGxvd2luZyBob2xkOlxuICpcbiAqICAgLSBpdHMgYXV0aG9yIGlzIHRyYWNrZWQgKGhhbmRsZSBpbiBgdGFyZ2V0ZWRgKSxcbiAqICAgLSBpdHMgYXV0aG9yIGlzIGNvcmUgKGhhbmRsZSBpbiBgY29yZUhhbmRsZXNgKSwgcmVnYXJkbGVzcyBvZiB3aGVyZSBYXG4gKiAgICAgc3VyZmFjZWQgaXQsXG4gKiAgIC0gaXQgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZSxcbiAqICAgLSBpdCByZXBsaWVzIHRvIGEgdHJhY2tlZCBhY2NvdW50LFxuICogICAtIGl0IHF1b3Rlcy9yZXBsaWVzLXRvIGEgdHdlZXQgdGhhdCdzIGFsc28gcHJlc2VudCBpbiB0aGVcbiAqICAgICBiYXRjaCAqYW5kKiBhdXRob3JlZCBieSBhIHRyYWNrZWQgYWNjb3VudCAodHJhbnNpdGl2ZWx5IHJlbGF0ZWQgXHUyMDE0XG4gKiAgICAgY2FwdHVyZXMgcXVvdGVkL3JlcGx5IGNvbnRleHQgdGhhdCBhcHBlYXJzIGFzIGEgc2libGluZyBub2RlIGluIHRoZVxuICogICAgIHNhbWUgR3JhcGhRTCByZXNwb25zZSkuXG4gKlxuICogTm9uLWNvcmUgcmV0d2VldCB3cmFwcGVycyBhcmUgbm90IGtlcHQgbWVyZWx5IGJlY2F1c2UgdGhleSByZXR3ZWV0ZWQgYVxuICogdHJhY2tlZC9jb3JlIHR3ZWV0LiBUaGUgdW5kZXJseWluZyBjb3JlIHR3ZWV0IGlzIGtlcHQgYXMgaXRzIG93biByb3cgd2hlblxuICogcHJlc2VudCBpbiB0aGUgcGF5bG9hZC5cbiAqXG4gKiBBbnl0aGluZyBlbHNlIChyYW5kb20gcmVwbGllcyB1bmRlciBhIHRyYWNrZWQgYWNjb3VudCdzIHR3ZWV0LCByYW5kb21cbiAqIGF1dGhvcnMgdGhhdCBoYXBwZW4gdG8gc3VyZmFjZSBpbiBhIHRyYWNrZWQgYWNjb3VudCdzIHRocmVhZCkgaXMgZHJvcHBlZC5cbiAqIFBhc3MgYW4gZW1wdHkgYHRhcmdldGVkYCBzZXQgdG8gZGlzYWJsZSBmaWx0ZXJpbmcgZW50aXJlbHkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmaWx0ZXJSZWxhdGVkKFxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10sXG4gIHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+LFxuICBjb3JlSGFuZGxlczogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoKVxuKTogQ2Fub25pY2FsVHdlZXRbXSB7XG4gIGlmICh0YXJnZXRlZC5zaXplID09PSAwICYmIGNvcmVIYW5kbGVzLnNpemUgPT09IDApIHJldHVybiB0d2VldHM7XG4gIC8vIEZpcnN0IHBhc3M6IHdoaWNoIHR3ZWV0IElEcyBkbyB0cmFja2VkLWF1dGhvciB0d2VldHMgcmVmZXJlbmNlICh0aGVcbiAgLy8gXCJmb3J3YXJkXCIgZGlyZWN0aW9uIFx1MjAxNCB0cmFja2VkIGFjY291bnQgcXVvdGVzIC8gUlRzIC8gcmVwbGllcyB0byBYKT9cbiAgLy8gQW5kIHdoaWNoIHR3ZWV0IElEcyBBUkUgdHJhY2tlZC1hdXRob3JlZCAodGhlIFwicmV2ZXJzZVwiIGRpcmVjdGlvbiBcdTIwMTRcbiAgLy8gWCBxdW90ZXMgLyBSVHMgLyByZXBsaWVzIHRvIGEgdHJhY2tlZCB0d2VldCk/XG4gIGNvbnN0IHJlZmVyZW5jZWRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgdGFyZ2V0ZWRUd2VldElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgaWYgKCF0YXJnZXRlZC5oYXModC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpKSkgY29udGludWU7XG4gICAgdGFyZ2V0ZWRUd2VldElkcy5hZGQodC50d2VldF9pZCk7XG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnF1b3RlZF90d2VldF9pZCk7XG4gICAgaWYgKHQucmV0d2VldGVkX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnJldHdlZXRlZF90d2VldF9pZCk7XG4gICAgaWYgKHQucmVwbHlfdG9fdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucmVwbHlfdG9fdHdlZXRfaWQpO1xuICB9XG4gIHJldHVybiB0d2VldHMuZmlsdGVyKCh0KSA9PiB7XG4gICAgY29uc3QgaCA9IHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAodGFyZ2V0ZWQuaGFzKGgpKSByZXR1cm4gdHJ1ZTtcbiAgICBpZiAoY29yZUhhbmRsZXMuaGFzKGgpKSByZXR1cm4gdHJ1ZTtcbiAgICAvLyBGb3J3YXJkOiBhIHRyYWNrZWQtYXV0aG9yIHR3ZWV0IHBvaW50ZWQgYXQgdGhpcyBvbmUuXG4gICAgaWYgKHJlZmVyZW5jZWRJZHMuaGFzKHQudHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcbiAgICAvLyBSZXZlcnNlOiB0aGlzIHR3ZWV0IHF1b3Rlcy9yZXBsaWVzIHRvIGEgdHJhY2tlZC1hdXRob3IgdHdlZXQgaW4gdGhlXG4gICAgLy8gYmF0Y2guIFJldmVyc2UgcmV0d2VldHMgYXJlIGp1c3QgXCJub24tY29yZSBhY2NvdW50IHJldHdlZXRlZCBjb3JlXG4gICAgLy8gdHdlZXRcIiB3cmFwcGVycywgYW5kIGRvIG5vdCBhZGQgY29yZSBhcmNoaXZlIHZhbHVlLlxuICAgIGlmICh0LnF1b3RlZF90d2VldF9pZCAmJiB0YXJnZXRlZFR3ZWV0SWRzLmhhcyh0LnF1b3RlZF90d2VldF9pZCkpIHJldHVybiB0cnVlO1xuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucmVwbHlfdG9fdHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcbiAgICAvLyBSZXBseS10by1hY2NvdW50IG9yIG1lbnRpb25zIGEgdHJhY2tlZCBoYW5kbGUuXG4gICAgaWYgKHQucmVwbHlfdG9fYWNjb3VudCAmJiB0YXJnZXRlZC5oYXModC5yZXBseV90b19hY2NvdW50LnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gdHJ1ZTtcbiAgICBmb3IgKGNvbnN0IG0gb2YgdC5tZW50aW9ucykge1xuICAgICAgaWYgKHRhcmdldGVkLmhhcyhtLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9KTtcbn1cblxuLyoqXG4gKiBQdWxsIHRoZSBDb21tdW5pdHkgTm90ZSAoZm9ybWVybHkgQmlyZHdhdGNoKSBibG9jayBhdHRhY2hlZCB0byBhIHR3ZWV0LCBpZlxuICogYW55LiBUaGUgcGl2b3QgY2FuIGxpdmUgYXQgYHR3ZWV0LmxlZ2FjeS5iaXJkd2F0Y2hfcGl2b3RgIChvbGRlciBzaGFwZSkgb3JcbiAqIGB0d2VldC5iaXJkd2F0Y2hfcGl2b3RgIChjdXJyZW50IHNoYXBlKS4gVGhlIHN1bW1hcnkgdGV4dCBpcyB3aGF0IHJlYWRlcnNcbiAqIGFjdHVhbGx5IHNlZTsgd2Uga2VlcCB0aGUgc3Vycm91bmRpbmcgbWV0YWRhdGEgc28gZG93bnN0cmVhbSB0b29saW5nIGNhblxuICogdGVsbCBkcmFmdHMgYXBhcnQgZnJvbSByYXRlZC1oZWxwZnVsIG5vdGVzLlxuICovXG5mdW5jdGlvbiBleHRyYWN0Q29tbXVuaXR5Tm90ZShcbiAgdDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gIG9ic2VydmVkQXQ6IHN0cmluZ1xuKTogQ29tbXVuaXR5Tm90ZSB8IG51bGwge1xuICBjb25zdCBwaXZvdCA9IG9iaih0LmJpcmR3YXRjaF9waXZvdCkgPz8gb2JqKGxlZ2FjeS5iaXJkd2F0Y2hfcGl2b3QpO1xuICBpZiAoIXBpdm90KSByZXR1cm4gbnVsbDtcbiAgY29uc3Qgc3VidGl0bGUgPSBvYmoocGl2b3Quc3VidGl0bGUpO1xuICBjb25zdCBub3RlID0gb2JqKHBpdm90Lm5vdGUpO1xuICBjb25zdCBzdW1tYXJ5ID0gc3RyT3JOdWxsKHN1YnRpdGxlPy50ZXh0KTtcbiAgY29uc3QgdGl0bGUgPSBzdHJPck51bGwocGl2b3QudGl0bGUpO1xuICBjb25zdCBzaG9ydFRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnNob3J0VGl0bGUpO1xuICBjb25zdCBkZXN0aW5hdGlvblVybCA9IHN0ck9yTnVsbChwaXZvdC5kZXN0aW5hdGlvblVybCk7XG4gIGNvbnN0IG5vdGVJZCA9IHN0ck9yTnVsbChwaXZvdC5ub3RlSWQpID8/IHN0ck9yTnVsbChub3RlPy5yZXN0X2lkKTtcbiAgLy8gU2tpcCBlbXB0eSBzaGVsbHMgdGhhdCBoYXZlIG5vIGFjdHVhbCBjb250ZW50LlxuICBpZiAoIXN1bW1hcnkgJiYgIXRpdGxlICYmICFub3RlSWQpIHJldHVybiBudWxsO1xuICByZXR1cm4ge1xuICAgIG5vdGVfaWQ6IG5vdGVJZCxcbiAgICB0aXRsZSxcbiAgICBzaG9ydF90aXRsZTogc2hvcnRUaXRsZSxcbiAgICBzdW1tYXJ5LFxuICAgIGRlc3RpbmF0aW9uX3VybDogZGVzdGluYXRpb25VcmwsXG4gICAgb2JzZXJ2ZWRfYXQ6IG9ic2VydmVkQXQsXG4gIH07XG59XG5cbi8qKlxuICogUHVsbCBhIHBlci1hdXRob3IgVXNlclNuYXBzaG90IGZyb20gdGhlIHR3ZWV0J3MgdXNlcl9yZXN1bHRzIG5vZGUuIEV2ZXJ5XG4gKiBmaWVsZCBkZWZhdWx0cyB0byBudWxsIHdoZW4gbWlzc2luZyBzbyB0aGUgc2NoZW1hIHN0YXlzIHN0YWJsZSBhY3Jvc3NcbiAqIHRoZSBsZWdhY3kgLyBjb3JlIHNoYXBlIG1pZ3JhdGlvbnMgWCBoYXMgYmVlbiBkb2luZy5cbiAqL1xuZnVuY3Rpb24gZXh0cmFjdFVzZXJTbmFwc2hvdChcbiAgdXNlclJlc3VsdDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxuICB1c2VyQ29yZU5ldzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxuICB1c2VyTGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIHVzZXJBdmF0YXJPYmo6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbFxuKTogVXNlclNuYXBzaG90IHtcbiAgY29uc3QgdmVyaWZpY2F0aW9uID0gb2JqKHVzZXJSZXN1bHQ/LnZlcmlmaWNhdGlvbik7XG4gIHJldHVybiB7XG4gICAgZGlzcGxheV9uYW1lOlxuICAgICAgc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5uYW1lKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8ubmFtZSkgPz8gc3RyT3JOdWxsKHVzZXJSZXN1bHQ/Lm5hbWUpLFxuICAgIGF2YXRhcl91cmw6XG4gICAgICBzdHJPck51bGwodXNlckF2YXRhck9iaj8uaW1hZ2VfdXJsKSA/P1xuICAgICAgc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzKSA/P1xuICAgICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzKSxcbiAgICB2ZXJpZmllZDogYm9vbE9yTnVsbCh2ZXJpZmljYXRpb24/LnZlcmlmaWVkKSA/PyBib29sT3JOdWxsKHVzZXJMZWdhY3k/LnZlcmlmaWVkKSxcbiAgICBpc19ibHVlX3ZlcmlmaWVkOiBib29sT3JOdWxsKHVzZXJSZXN1bHQ/LmlzX2JsdWVfdmVyaWZpZWQpLFxuICAgIHZlcmlmaWVkX3R5cGU6IHN0ck9yTnVsbCh2ZXJpZmljYXRpb24/LnZlcmlmaWVkX3R5cGUpID8/IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py52ZXJpZmllZF90eXBlKSxcbiAgICBkZXNjcmlwdGlvbjogc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmRlc2NyaXB0aW9uKSxcbiAgICBsb2NhdGlvbjogc3RyT3JOdWxsKG9iaih1c2VyUmVzdWx0Py5sb2NhdGlvbik/LmxvY2F0aW9uKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8ubG9jYXRpb24pLFxuICAgIHVybDogc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnVybCksXG4gICAgZm9sbG93ZXJzX2NvdW50OiBudW1Pck51bGwodXNlckxlZ2FjeT8uZm9sbG93ZXJzX2NvdW50KSxcbiAgICBmcmllbmRzX2NvdW50OiBudW1Pck51bGwodXNlckxlZ2FjeT8uZnJpZW5kc19jb3VudCksXG4gICAgc3RhdHVzZXNfY291bnQ6IG51bU9yTnVsbCh1c2VyTGVnYWN5Py5zdGF0dXNlc19jb3VudCksXG4gICAgYWNjb3VudF9jcmVhdGVkX2F0OlxuICAgICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodXNlckNvcmVOZXc/LmNyZWF0ZWRfYXQpKSA/P1xuICAgICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodXNlckxlZ2FjeT8uY3JlYXRlZF9hdCkpLFxuICAgIHByb3RlY3RlZDogYm9vbE9yTnVsbCh1c2VyTGVnYWN5Py5wcm90ZWN0ZWQpLFxuICB9O1xufVxuXG4vKipcbiAqIFdhbGsgdGhlIHR3ZWV0J3MgYGNhcmQubGVnYWN5LmJpbmRpbmdfdmFsdWVzYCAoa2V5L3ZhbHVlIGFycmF5KSBpbnRvIGFcbiAqIGZsYXQgVHdlZXRDYXJkIHdpdGggdGl0bGUsIGRlc2NyaXB0aW9uLCBhbmQgYSByZXByZXNlbnRhdGl2ZSBpbWFnZSBVUkwuXG4gKiBSZXR1cm5zIG51bGwgd2hlbiB0aGUgdHdlZXQgaGFzIG5vIGNhcmQuXG4gKi9cbmZ1bmN0aW9uIGV4dHJhY3RDYXJkKHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVHdlZXRDYXJkIHwgbnVsbCB7XG4gIGNvbnN0IGNhcmQgPSBvYmoodC5jYXJkKTtcbiAgY29uc3QgY2FyZExlZ2FjeSA9IG9iaihjYXJkPy5sZWdhY3kpO1xuICBpZiAoIWNhcmRMZWdhY3kpIHJldHVybiBudWxsO1xuICBjb25zdCBiaW5kaW5ncyA9IGNhcmRMZWdhY3kuYmluZGluZ192YWx1ZXM7XG4gIGNvbnN0IGJ5S2V5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBpZiAoQXJyYXkuaXNBcnJheShiaW5kaW5ncykpIHtcbiAgICBmb3IgKGNvbnN0IGJ2IG9mIGJpbmRpbmdzKSB7XG4gICAgICBpZiAodHlwZW9mIGJ2ICE9PSAnb2JqZWN0JyB8fCBidiA9PT0gbnVsbCkgY29udGludWU7XG4gICAgICBjb25zdCBvID0gYnYgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBjb25zdCBrID0gc3RyT3JOdWxsKG8ua2V5KTtcbiAgICAgIGNvbnN0IHYgPSBvYmooby52YWx1ZSk7XG4gICAgICBpZiAoIWsgfHwgIXYpIGNvbnRpbnVlO1xuICAgICAgYnlLZXlba10gPVxuICAgICAgICBzdHJPck51bGwodi5zdHJpbmdfdmFsdWUpID8/XG4gICAgICAgIHN0ck9yTnVsbChvYmoodi5pbWFnZV92YWx1ZSk/LnVybCkgPz9cbiAgICAgICAgc3RyT3JOdWxsKG9iaih2LmltYWdlX2NvbG9yX3ZhbHVlKT8ucGFsZXR0ZSk7XG4gICAgfVxuICB9XG4gIGNvbnN0IG5hbWUgPSBzdHJPck51bGwoY2FyZExlZ2FjeS5uYW1lKTtcbiAgY29uc3QgY2FyZFVybCA9IHN0ck9yTnVsbChjYXJkTGVnYWN5LnVybCk7XG4gIGNvbnN0IHZlbmRvclVybCA9XG4gICAgdHlwZW9mIGJ5S2V5Wyd2YW5pdHlfdXJsJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5Wyd2YW5pdHlfdXJsJ10gYXMgc3RyaW5nKSA6IG51bGw7XG4gIGNvbnN0IHRpdGxlID0gdHlwZW9mIGJ5S2V5Wyd0aXRsZSddID09PSAnc3RyaW5nJyA/IChieUtleVsndGl0bGUnXSBhcyBzdHJpbmcpIDogbnVsbDtcbiAgY29uc3QgZGVzY3JpcHRpb24gPVxuICAgIHR5cGVvZiBieUtleVsnZGVzY3JpcHRpb24nXSA9PT0gJ3N0cmluZycgPyAoYnlLZXlbJ2Rlc2NyaXB0aW9uJ10gYXMgc3RyaW5nKSA6IG51bGw7XG4gIGNvbnN0IGltYWdlVXJsID1cbiAgICAodHlwZW9mIGJ5S2V5WydwaG90b19pbWFnZV9mdWxsX3NpemVfb3JpZ2luYWwnXSA9PT0gJ3N0cmluZydcbiAgICAgID8gKGJ5S2V5WydwaG90b19pbWFnZV9mdWxsX3NpemVfb3JpZ2luYWwnXSBhcyBzdHJpbmcpXG4gICAgICA6IG51bGwpID8/XG4gICAgKHR5cGVvZiBieUtleVsndGh1bWJuYWlsX2ltYWdlX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXG4gICAgICA/IChieUtleVsndGh1bWJuYWlsX2ltYWdlX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxuICAgICAgOiBudWxsKSA/P1xuICAgICh0eXBlb2YgYnlLZXlbJ3N1bW1hcnlfcGhvdG9faW1hZ2Vfb3JpZ2luYWwnXSA9PT0gJ3N0cmluZydcbiAgICAgID8gKGJ5S2V5WydzdW1tYXJ5X3Bob3RvX2ltYWdlX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxuICAgICAgOiBudWxsKTtcbiAgaWYgKCFuYW1lICYmICF0aXRsZSAmJiAhZGVzY3JpcHRpb24gJiYgIWltYWdlVXJsKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHtcbiAgICBuYW1lLFxuICAgIGNhcmRfdXJsOiBjYXJkVXJsLFxuICAgIHZlbmRvcl91cmw6IHZlbmRvclVybCxcbiAgICB0aXRsZSxcbiAgICBkZXNjcmlwdGlvbixcbiAgICBpbWFnZV91cmw6IGltYWdlVXJsLFxuICB9O1xufVxuIiwgIi8qKlxuICogTGlnaHR3ZWlnaHQgVUxJRC1saWtlIGlkIGdlbmVyYXRvcjogMjYtY2hhcmFjdGVyIENyb2NrZm9yZCBiYXNlMzIgc3RyaW5nXG4gKiBvZiAodGltZXN0YW1wX21zIHx8IHJhbmRvbW5lc3MpLiBHb29kIGVub3VnaCBmb3IgcnVuIGlkZW50aWZpZXJzIHdpdGhvdXRcbiAqIHB1bGxpbmcgaW4gYSByZWFsIFVMSUQgZGVwZW5kZW5jeS5cbiAqL1xuXG5jb25zdCBBTFBIQUJFVCA9ICcwMTIzNDU2Nzg5QUJDREVGR0hKS01OUFFSU1RWV1hZWic7IC8vIENyb2NrZm9yZFxuXG5leHBvcnQgZnVuY3Rpb24gbmV3UnVuSWQoKTogc3RyaW5nIHtcbiAgY29uc3QgdHMgPSBEYXRlLm5vdygpO1xuICBsZXQgdHNQYXJ0ID0gJyc7XG4gIGxldCB0ID0gdHM7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMTA7IGkrKykge1xuICAgIHRzUGFydCA9IChBTFBIQUJFVFt0ICUgMzJdID8/ICcwJykgKyB0c1BhcnQ7XG4gICAgdCA9IE1hdGguZmxvb3IodCAvIDMyKTtcbiAgfVxuICBjb25zdCByYW5kID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMCkpO1xuICBsZXQgcmFuZFBhcnQgPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIHJhbmQpIHJhbmRQYXJ0ICs9IEFMUEhBQkVUW2IgJSAzMl0gPz8gJzAnO1xuICByZXR1cm4gdHNQYXJ0ICsgcmFuZFBhcnQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzaG9ydFJ1bklkKGlkOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gaWQuc2xpY2UoLTgpO1xufVxuIiwgImltcG9ydCB0eXBlIHsgQWNjb3VudENhdGVnb3J5LCBBY2NvdW50Q29uZmlnIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTWluaW1hbCBwYXJzZXIgZm9yIHRoZSBzdHJpY3Qgc2hhcGUgdXNlZCBieSBgY29uZmlnL2FjY291bnRzLnlhbWxgOlxuICpcbiAqICAgYWNjb3VudHM6XG4gKiAgICAgLSBoYW5kbGU6IERIU2dvdlxuICogICAgICAgbGFiZWw6IERlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHlcbiAqICAgICAgIGNhdGVnb3J5OiBjb3JlXG4gKlxuICogV2UgZGVsaWJlcmF0ZWx5IGRvbid0IHB1bGwgaW4gYSBmdWxsIFlBTUwgbGlicmFyeSBcdTIwMTQgd2UgY29udHJvbCBib3RoIGVuZHMgb2ZcbiAqIHRoaXMgZmlsZSwgYW5kIGEgc21hbGwgcGFyc2VyIGlzIGVhc2llciB0byBhdWRpdCB0aGFuIHRoZSBhbHRlcm5hdGl2ZXMuXG4gKiBVbmtub3duIGtleXMgYW5kIGNvbW1lbnRzIGFyZSB0b2xlcmF0ZWQ7IG1hbGZvcm1lZCBsaW5lcyBhcmUgc2tpcHBlZC5cbiAqXG4gKiBFbnRyaWVzIG1pc3NpbmcgYSBgY2F0ZWdvcnlgIGRlZmF1bHQgdG8gYGNvcmVgIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XG4gKiB3aXRoIHRoZSBwcmUtY2F0ZWdvcml6YXRpb24gZmlsZSBzaGFwZS5cbiAqL1xuY29uc3QgVkFMSURfQ0FURUdPUklFUzogUmVhZG9ubHlTZXQ8QWNjb3VudENhdGVnb3J5PiA9IG5ldyBTZXQoW1xuICAnY29yZScsXG4gICdnb3Zlcm5tZW50JyxcbiAgJ29mZmljaWFscycsXG4gICdwdWJsaWNfZmlndXJlcycsXG4gICdwdWJsaWMnLFxuXSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUFjY291bnRzWWFtbCh0ZXh0OiBzdHJpbmcpOiBBY2NvdW50Q29uZmlnW10ge1xuICBjb25zdCBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdID0gW107XG4gIGxldCBjdXJyZW50OiBQYXJ0aWFsPEFjY291bnRDb25maWc+ID0ge307XG4gIGxldCBpbkFjY291bnRzID0gZmFsc2U7XG4gIGNvbnN0IGZsdXNoID0gKCkgPT4ge1xuICAgIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSB7XG4gICAgICBpZiAoIWN1cnJlbnQuY2F0ZWdvcnkpIGN1cnJlbnQuY2F0ZWdvcnkgPSAnY29yZSc7XG4gICAgICBhY2NvdW50cy5wdXNoKGN1cnJlbnQgYXMgQWNjb3VudENvbmZpZyk7XG4gICAgfVxuICB9O1xuICBmb3IgKGNvbnN0IHJhd0xpbmUgb2YgdGV4dC5zcGxpdCgnXFxuJykpIHtcbiAgICBjb25zdCBsaW5lID0gc3RyaXBDb21tZW50cyhyYXdMaW5lKTtcbiAgICBpZiAobGluZS50cmltKCkgPT09ICcnKSBjb250aW51ZTtcbiAgICBpZiAoL15hY2NvdW50c1xccyo6Ly50ZXN0KGxpbmUpKSB7XG4gICAgICBpbkFjY291bnRzID0gdHJ1ZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoIWluQWNjb3VudHMpIGNvbnRpbnVlO1xuXG4gICAgY29uc3QgaXRlbU1hdGNoID0gbGluZS5tYXRjaCgvXlxccyotXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGl0ZW1NYXRjaCkge1xuICAgICAgZmx1c2goKTtcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShpdGVtTWF0Y2hbMV0gPz8gJycpIH07XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgaGFuZGxlT25seSA9IGxpbmUubWF0Y2goL15cXHMqaGFuZGxlXFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoaGFuZGxlT25seSAmJiAhbGluZS5pbmNsdWRlcygnLScpKSB7XG4gICAgICBmbHVzaCgpO1xuICAgICAgY3VycmVudCA9IHsgaGFuZGxlOiB1bnF1b3RlKGhhbmRsZU9ubHlbMV0gPz8gJycpIH07XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgbGFiZWxNYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqbGFiZWxcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChsYWJlbE1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XG4gICAgICBjdXJyZW50LmxhYmVsID0gdW5xdW90ZShsYWJlbE1hdGNoWzFdID8/ICcnKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBjYXRlZ29yeU1hdGNoID0gbGluZS5tYXRjaCgvXlxccypjYXRlZ29yeVxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGNhdGVnb3J5TWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcbiAgICAgIGNvbnN0IHJhdyA9IHVucXVvdGUoY2F0ZWdvcnlNYXRjaFsxXSA/PyAnJyk7XG4gICAgICBjdXJyZW50LmNhdGVnb3J5ID0gVkFMSURfQ0FURUdPUklFUy5oYXMocmF3IGFzIEFjY291bnRDYXRlZ29yeSlcbiAgICAgICAgPyAocmF3IGFzIEFjY291bnRDYXRlZ29yeSlcbiAgICAgICAgOiAnY29yZSc7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gIH1cbiAgZmx1c2goKTtcbiAgcmV0dXJuIGFjY291bnRzLmZpbHRlcigoYSkgPT4gYS5oYW5kbGUubGVuZ3RoID4gMCk7XG59XG5cbmZ1bmN0aW9uIHN0cmlwQ29tbWVudHMobGluZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gTmFpdmUgYnV0IGFkZXF1YXRlIGZvciBvdXIgZm9ybWF0OiBzdHJpcCBldmVyeXRoaW5nIGFmdGVyIGEgYCNgIHRoYXQgaXNuJ3RcbiAgLy8gaW5zaWRlIHF1b3Rlcy4gT3VyIGNvbmZpZyBuZXZlciB1c2VzIGlubGluZSBzdHJpbmdzIHdpdGggYCNgLlxuICBjb25zdCBpZHggPSBsaW5lLmluZGV4T2YoJyMnKTtcbiAgcmV0dXJuIGlkeCA9PT0gLTEgPyBsaW5lIDogbGluZS5zbGljZSgwLCBpZHgpO1xufVxuXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IHRyaW1tZWQgPSBzLnRyaW0oKTtcbiAgaWYgKFxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoJ1wiJykgJiYgdHJpbW1lZC5lbmRzV2l0aCgnXCInKSkgfHxcbiAgICAodHJpbW1lZC5zdGFydHNXaXRoKFwiJ1wiKSAmJiB0cmltbWVkLmVuZHNXaXRoKFwiJ1wiKSlcbiAgKSB7XG4gICAgcmV0dXJuIHRyaW1tZWQuc2xpY2UoMSwgLTEpO1xuICB9XG4gIHJldHVybiB0cmltbWVkO1xufVxuIiwgIi8qKlxuICogYmFja2dyb3VuZC50cyBcdTIwMTQgZXh0ZW5zaW9uIHNlcnZpY2Ugd29ya2VyLlxuICpcbiAqIE93bnMgdGhlIGNhcHR1cmUgcGlwZWxpbmU6IHJlY2VpdmVzIGBncmFwaHFsLWNhcHR1cmVgIG1lc3NhZ2VzIGZyb20gdGhlXG4gKiBjb250ZW50IHNjcmlwdCwgbm9ybWFsaXplcyB0aGVtLCBhY2N1bXVsYXRlcyBwZXItaGFuZGxlIHJ1biBidWZmZXJzIGluXG4gKiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgYW5kIGNvbW1pdHMgdGhlbSB0byB0aGUgY29uZmlndXJlZCBHaXRIdWIgcmVwb1xuICogdmlhIHRoZSBHaXQgRGF0YSBBUEkuXG4gKlxuICogU2VydmljZSB3b3JrZXJzIGluIE1WMyBtYXkgYmUgZXZpY3RlZCBhdCBhbnkgdGltZSwgc28gYWxsIGNyaXRpY2FsIHN0YXRlXG4gKiBsaXZlcyBpbiBzdG9yYWdlIChuZXZlciBtb2R1bGUtc2NvcGUpLiBPbiBldmVyeSB3YWtlIHdlIHJlLWRlcml2ZSB3aGF0IHdlXG4gKiBuZWVkOyBwZW5kaW5nIGZsdXNoZXMgYXJlIGRyaXZlbiBieSBgYnJvd3Nlci5hbGFybXNgIHJhdGhlciB0aGFuIHRpbWVycy5cbiAqL1xuXG5pbXBvcnQge1xuICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICBBVVRPX1NDUk9MTF9NSU5fU0VDLFxuICBGQUxMQkFDS19BQ0NPVU5UUyxcbiAgRkxVU0hfQUxBUk1fTUlOVVRFUyxcbiAgRkxVU0hfSURMRV9NUyxcbiAgRkxVU0hfVFdFRVRfVEhSRVNIT0xELFxuICBQUk9GSUxFX0VORFBPSU5UUyxcbiAgVFdFRVRfRU5EUE9JTlRTLFxuICBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyxcbn0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcbmltcG9ydCB7IEdpdEh1YkNsaWVudCwgR2l0SHViRXJyb3IsIHRvQmFzZTY0IH0gZnJvbSAnLi9saWIvZ2l0aHViLmpzJztcbmltcG9ydCB7IGRlc2NyaWJlRXJyb3IsIGVycm9yIGFzIGxvZ0VyciwgaW5mbywgc2V0QnJvYWRjYXN0ZXIsIHdhcm4gfSBmcm9tICcuL2xpYi9sb2dnZXIuanMnO1xuaW1wb3J0IHsgZmlsdGVyUmVsYXRlZCwgbm9ybWFsaXplIH0gZnJvbSAnLi9saWIvbm9ybWFsaXplLmpzJztcbmltcG9ydCB7IG5ld1J1bklkLCBzaG9ydFJ1bklkIH0gZnJvbSAnLi9saWIvcnVuaWRzLmpzJztcbmltcG9ydCB7XG4gIGJ1bXBDb3VudGVyLFxuICBjbGVhckFjdGl2aXR5LFxuICBjbGVhckFsbCxcbiAgY2xlYXJSdW5CdWZmZXIsXG4gIGRlcXVldWVNZWRpYUNyYXdsLFxuICBkZXF1ZXVlUmVmZXRjaCxcbiAgZGVxdWV1ZVRocmVhZE9wZW4sXG4gIGVuZ2FnZW1lbnRTaWcsXG4gIGVucXVldWVNZWRpYUNyYXdsLFxuICBlbnF1ZXVlUmVmZXRjaCxcbiAgZW5xdWV1ZVRocmVhZE9wZW4sXG4gIGdldEFjY291bnRzLFxuICBnZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxuICBnZXRBY3Rpdml0eSxcbiAgZ2V0QXJjaGl2ZVNuYXBzaG90LFxuICBnZXRBdXRvU2Nyb2xsU2Vzc2lvbixcbiAgZ2V0Q29tbWl0dGVkSW5kZXgsXG4gIGdldENvbm5lY3Rpb24sXG4gIGdldENvdW50ZXJzLFxuICBnZXRNZWRpYUNyYXdsUXVldWUsXG4gIGdldE1lZGlhQ3Jhd2xTZXNzaW9uLFxuICBnZXRSZWZldGNoUXVldWUsXG4gIGdldFJlZmV0Y2hTZXNzaW9uLFxuICBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncyxcbiAgZ2V0UnVuQnVmZmVyLFxuICBnZXRSdW5CdWZmZXJzLFxuICBnZXRTZXR0aW5ncyxcbiAgZ2V0VGhyZWFkT3BlblF1ZXVlLFxuICBnZXRUaHJlYWRPcGVuU2Vzc2lvbixcbiAgaGFzVGhyZWFkT3BlblNlZW4sXG4gIGlzQ29tbWl0dGVkLFxuICBtYXJrVGhyZWFkT3BlblNlZW4sXG4gIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsLFxuICBuZXh0TWVkaWFDcmF3bFRhcmdldCxcbiAgbmV4dFJlZmV0Y2hUYXJnZXQsXG4gIG5leHRUaHJlYWRPcGVuVGFyZ2V0LFxuICBwcnVuZUNvbW1pdHRlZEluZGV4LFxuICBwdXJnZVVucmVsYXRlZFN0YXRlLFxuICByZWZldGNoUXVldWVUb3RhbCxcbiAgcHJlcGVuZFJlY2VudFR3ZWV0U2lnaHRpbmdzLFxuICBzZXRBY2NvdW50cyxcbiAgc2V0QWNjb3VudHNSZWZyZXNoZWRBdCxcbiAgc2V0QXJjaGl2ZVNuYXBzaG90LFxuICBzZXRBdXRvU2Nyb2xsU2Vzc2lvbixcbiAgc2V0QnVmZmVyZWRDb3VudCxcbiAgc2V0Q29tbWl0dGVkSW5kZXgsXG4gIHNldENvbm5lY3Rpb24sXG4gIHNldE1lZGlhQ3Jhd2xTZXNzaW9uLFxuICBzZXRSZWZldGNoU2Vzc2lvbixcbiAgc2V0UnVuQnVmZmVyLFxuICBzZXRUaHJlYWRPcGVuU2Vzc2lvbixcbiAgdGhyZWFkT3BlblF1ZXVlVG90YWwsXG4gIHR5cGUgUnVuQnVmZmVyLFxuICB1cGRhdGVTZXR0aW5ncyxcbn0gZnJvbSAnLi9saWIvc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIENhbm9uaWNhbFR3ZWV0LFxuICBDYXB0dXJlUGF5bG9hZCxcbiAgQXJjaGl2ZVNuYXBzaG90LFxuICBDb25uZWN0aW9uU3RhdGUsXG4gIEV4dGVuc2lvblN0YXRlLFxuICBMb2dFdmVudCxcbiAgUXVhcmFudGluZVBheWxvYWQsXG4gIFJldHdlZXRFZGdlLFxuICBSdW50aW1lTWVzc2FnZSxcbiAgU2VlblBheWxvYWQsXG4gIFNldHRpbmdzLFxuICBUd2VldFNpZ2h0aW5nLFxuICBVbmF2YWlsYWJsZVR3ZWV0LFxufSBmcm9tICcuL2xpYi90eXBlcy5qcyc7XG5pbXBvcnQgeyBwYXJzZUFjY291bnRzWWFtbCB9IGZyb20gJy4vbGliL3lhbWwuanMnO1xuXG5jb25zdCBFWFRfVkVSU0lPTiA9IGJyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb247XG5jb25zdCBNQU5VQUxfQ0FQVFVSRV9XSU5ET1dfTVMgPSA5MF8wMDA7XG5jb25zdCBMT1dfQkFORFdJRFRIX0JBU0VfUlVMRV9JRCA9IDc2MF8wMDE7XG5jb25zdCBMT1dfQkFORFdJRFRIX01FRElBX1JVTEVfSURfQkFTRSA9IDc2MF8wMTA7XG5jb25zdCBMT1dfQkFORFdJRFRIX1JFU09VUkNFX1RZUEVTID0gWydpbWFnZScsICdtZWRpYScsICdmb250J10gYXMgY29uc3Q7XG5jb25zdCBMT1dfQkFORFdJRFRIX01FRElBX0NIVU5LX1JFU09VUkNFX1RZUEVTID0gWydtZWRpYScsICd4bWxodHRwcmVxdWVzdCcsICdvdGhlciddIGFzIGNvbnN0O1xuY29uc3QgTE9XX0JBTkRXSURUSF9NRURJQV9VUkxfRklMVEVSUyA9IFtcbiAgJ3x8dmlkZW8udHdpbWcuY29tXicsXG4gICd8fHRvbi50d2ltZy5jb21eJyxcbiAgJ3x8YW1wLnR3aW1nLmNvbV4nLFxuICAnfHx2aWRlby5wc2NwLnR2XicsXG4gICd8fHByb2QtZmFzdGx5LXVzLXdlc3QtMS52aWRlby5wc2NwLnR2XicsXG4gICd8aHR0cHM6Ly94LmNvbS9pL3ZpZGVvcy8nLFxuICAnfGh0dHBzOi8vdHdpdHRlci5jb20vaS92aWRlb3MvJyxcbl0gYXMgY29uc3Q7XG5sZXQgbWFudWFsQ2FwdHVyZVVudGlsTXMgPSAwO1xuXG50eXBlIExvd0JhbmR3aWR0aFJlc291cmNlVHlwZSA9XG4gIHwgKHR5cGVvZiBMT1dfQkFORFdJRFRIX1JFU09VUkNFX1RZUEVTKVtudW1iZXJdXG4gIHwgKHR5cGVvZiBMT1dfQkFORFdJRFRIX01FRElBX0NIVU5LX1JFU09VUkNFX1RZUEVTKVtudW1iZXJdO1xuXG5pbnRlcmZhY2UgTG93QmFuZHdpZHRoUnVsZSB7XG4gIGlkOiBudW1iZXI7XG4gIHByaW9yaXR5OiBudW1iZXI7XG4gIGFjdGlvbjogeyB0eXBlOiAnYmxvY2snIH07XG4gIGNvbmRpdGlvbjoge1xuICAgIHRhYklkczogbnVtYmVyW107XG4gICAgcmVzb3VyY2VUeXBlczogTG93QmFuZHdpZHRoUmVzb3VyY2VUeXBlW107XG4gICAgdXJsRmlsdGVyPzogc3RyaW5nO1xuICB9O1xufVxuXG5pbnRlcmZhY2UgRGVjbGFyYXRpdmVOZXRSZXF1ZXN0QXBpIHtcbiAgdXBkYXRlU2Vzc2lvblJ1bGVzKHVwZGF0ZToge1xuICAgIGFkZFJ1bGVzPzogTG93QmFuZHdpZHRoUnVsZVtdO1xuICAgIHJlbW92ZVJ1bGVJZHM/OiBudW1iZXJbXTtcbiAgfSk6IFByb21pc2U8dm9pZD47XG59XG5cbnNldEJyb2FkY2FzdGVyKChldjogTG9nRXZlbnQpID0+IHtcbiAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2xvZy1ldmVudCcsIGV2ZW50OiBldiB9KS5jYXRjaCgoKSA9PiB7fSk7XG59KTtcblxuZnVuY3Rpb24gYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk6IHZvaWQge1xuICBtYW51YWxDYXB0dXJlVW50aWxNcyA9IERhdGUubm93KCkgKyBNQU5VQUxfQ0FQVFVSRV9XSU5ET1dfTVM7XG59XG5cbi8vIC0tLSBXYWtlIGhhbmRsZXJzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmJyb3dzZXIucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XG4gIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBpbnN0YWxsZWQnLCB7IHZlcnNpb246IEVYVF9WRVJTSU9OIH0pO1xuICBhd2FpdCBvbldha2UoJ2luc3RhbGwnKTtcbn0pO1xuXG5icm93c2VyLnJ1bnRpbWUub25TdGFydHVwLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgdm9pZCBvbldha2UoJ3N0YXJ0dXAnKTtcbn0pO1xuXG4vLyBGb3JjZSBhdCBsZWFzdCBvbmUgd2FrZSB0byByZWdpc3RlciBhbGFybXMgLyB2ZXJpZnkgY29ubmVjdGlvbi5cbnZvaWQgb25XYWtlKCdtb2R1bGUtbG9hZCcpO1xuXG5hc3luYyBmdW5jdGlvbiBvbldha2UocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBlbnN1cmVBbGFybXMoKTtcbiAgICBhd2FpdCBlbnN1cmVBdXRvU2Nyb2xsQWxhcm0oKTtcbiAgICBhd2FpdCBzeW5jTG93QmFuZHdpZHRoUnVsZXMoeyByZWFzb246IGB3YWtlOiR7cmVhc29ufWAsIGxvZzogZmFsc2UgfSk7XG4gICAgYXdhaXQgZmx1c2hPcnBoYW5lZEJ1ZmZlcnNJZlN0YWxlKCk7XG4gICAgYXdhaXQgcmVpbmplY3RJbnRvT3BlblRhYnMoKTtcbiAgICAvLyBEcm9wIGRlZHVwLWluZGV4IGVudHJpZXMgb2xkZXIgdGhhbiAzMCBkYXlzIHNvIHRoZSBzdG9yZSBkb2Vzbid0XG4gICAgLy8gZ3JvdyB1bmJvdW5kZWQgb3ZlciBtb250aHMgb2YgY2FwdHVyZSBzZXNzaW9ucy5cbiAgICBjb25zdCBwcnVuZWQgPSBhd2FpdCBwcnVuZUNvbW1pdHRlZEluZGV4KDMwICogMjQgKiA2MCAqIDYwICogMTAwMCk7XG4gICAgaWYgKHBydW5lZCA+IDApIGF3YWl0IGluZm8oJ3BydW5lZCBjb21taXR0ZWQgaW5kZXgnLCB7IHBydW5lZCB9KTtcbiAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgaWYgKHNldHRpbmdzLnBhdCAmJiBzZXR0aW5ncy5vd25lciAmJiBzZXR0aW5ncy5yZXBvKSB7XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgICAgIGF3YWl0IHJlZnJlc2hBY2NvdW50c0xpc3QoZmFsc2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgICBsb2dpbjogbnVsbCxcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICAgICAgICBjb25maWd1cmVkQnJhbmNoRXhpc3RzOiBudWxsLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBpbmZvKCdleHRlbnNpb24gYXdha2U7IHNldHRpbmdzIGluY29tcGxldGUnLCB7IHJlYXNvbiB9KTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IGxvZ0Vycignd2FrZSBmYWlsZWQnLCB7IHJlYXNvbiwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIGRuckFwaSgpOiBEZWNsYXJhdGl2ZU5ldFJlcXVlc3RBcGkgfCBudWxsIHtcbiAgY29uc3QgbWF5YmVCcm93c2VyID0gYnJvd3NlciBhcyB1bmtub3duIGFzIHtcbiAgICBkZWNsYXJhdGl2ZU5ldFJlcXVlc3Q/OiBEZWNsYXJhdGl2ZU5ldFJlcXVlc3RBcGk7XG4gIH07XG4gIHJldHVybiBtYXliZUJyb3dzZXIuZGVjbGFyYXRpdmVOZXRSZXF1ZXN0ID8/IG51bGw7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGN1cnJlbnRYVGFiSWRzKCk6IFByb21pc2U8bnVtYmVyW10+IHtcbiAgY29uc3QgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gIHJldHVybiB0YWJzLmZsYXRNYXAoKHRhYikgPT4gKHR5cGVvZiB0YWIuaWQgPT09ICdudW1iZXInID8gW3RhYi5pZF0gOiBbXSkpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzeW5jTG93QmFuZHdpZHRoUnVsZXMoe1xuICByZWFzb24sXG4gIGxvZyxcbn06IHtcbiAgcmVhc29uOiBzdHJpbmc7XG4gIGxvZzogYm9vbGVhbjtcbn0pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBkbnIgPSBkbnJBcGkoKTtcbiAgaWYgKCFkbnIpIHtcbiAgICBpZiAoc2V0dGluZ3MubG93QmFuZHdpZHRoQnJvd3NpbmcgJiYgbG9nKSB7XG4gICAgICBhd2FpdCB3YXJuKCdsb3ctYmFuZHdpZHRoIGJyb3dzaW5nIHVuYXZhaWxhYmxlOyBkZWNsYXJhdGl2ZU5ldFJlcXVlc3QgQVBJIG1pc3NpbmcnLCB7XG4gICAgICAgIHJlYXNvbixcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zdCB0YWJJZHMgPSBzZXR0aW5ncy5sb3dCYW5kd2lkdGhCcm93c2luZyA/IGF3YWl0IGN1cnJlbnRYVGFiSWRzKCkgOiBbXTtcbiAgY29uc3QgcmVtb3ZlUnVsZUlkcyA9IFtcbiAgICBMT1dfQkFORFdJRFRIX0JBU0VfUlVMRV9JRCxcbiAgICAuLi5MT1dfQkFORFdJRFRIX01FRElBX1VSTF9GSUxURVJTLm1hcCgoXywgaWR4KSA9PiBMT1dfQkFORFdJRFRIX01FRElBX1JVTEVfSURfQkFTRSArIGlkeCksXG4gIF07XG4gIGNvbnN0IGFkZFJ1bGVzOiBMb3dCYW5kd2lkdGhSdWxlW10gPVxuICAgIHRhYklkcy5sZW5ndGggPiAwXG4gICAgICA/IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogTE9XX0JBTkRXSURUSF9CQVNFX1JVTEVfSUQsXG4gICAgICAgICAgICBwcmlvcml0eTogMSxcbiAgICAgICAgICAgIGFjdGlvbjogeyB0eXBlOiAnYmxvY2snIH0sXG4gICAgICAgICAgICBjb25kaXRpb246IHtcbiAgICAgICAgICAgICAgdGFiSWRzLFxuICAgICAgICAgICAgICByZXNvdXJjZVR5cGVzOiBbLi4uTE9XX0JBTkRXSURUSF9SRVNPVVJDRV9UWVBFU10sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgLi4uTE9XX0JBTkRXSURUSF9NRURJQV9VUkxfRklMVEVSUy5tYXAoKHVybEZpbHRlciwgaWR4KSA9PiAoe1xuICAgICAgICAgICAgaWQ6IExPV19CQU5EV0lEVEhfTUVESUFfUlVMRV9JRF9CQVNFICsgaWR4LFxuICAgICAgICAgICAgcHJpb3JpdHk6IDIsXG4gICAgICAgICAgICBhY3Rpb246IHsgdHlwZTogJ2Jsb2NrJyBhcyBjb25zdCB9LFxuICAgICAgICAgICAgY29uZGl0aW9uOiB7XG4gICAgICAgICAgICAgIHRhYklkcyxcbiAgICAgICAgICAgICAgdXJsRmlsdGVyLFxuICAgICAgICAgICAgICByZXNvdXJjZVR5cGVzOiBbLi4uTE9XX0JBTkRXSURUSF9NRURJQV9DSFVOS19SRVNPVVJDRV9UWVBFU10sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pKSxcbiAgICAgICAgXVxuICAgICAgOiBbXTtcbiAgYXdhaXQgZG5yLnVwZGF0ZVNlc3Npb25SdWxlcyh7XG4gICAgcmVtb3ZlUnVsZUlkcyxcbiAgICBhZGRSdWxlcyxcbiAgfSk7XG5cbiAgaWYgKGxvZykge1xuICAgIGF3YWl0IGluZm8oJ2xvdy1iYW5kd2lkdGggYnJvd3NpbmcgcnVsZXMgdXBkYXRlZCcsIHtcbiAgICAgIGVuYWJsZWQ6IHNldHRpbmdzLmxvd0JhbmR3aWR0aEJyb3dzaW5nLFxuICAgICAgdGFiX2NvdW50OiB0YWJJZHMubGVuZ3RoLFxuICAgICAgYmxvY2tlZF9yZXNvdXJjZV90eXBlczogTE9XX0JBTkRXSURUSF9SRVNPVVJDRV9UWVBFUy5qb2luKCcsJyksXG4gICAgICBibG9ja2VkX21lZGlhX2ZpbHRlcnM6IExPV19CQU5EV0lEVEhfTUVESUFfVVJMX0ZJTFRFUlMuam9pbignLCcpLFxuICAgICAgcmVhc29uLFxuICAgIH0pO1xuICB9XG59XG5cbmJyb3dzZXIudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoKF90YWJJZCwgY2hhbmdlSW5mbykgPT4ge1xuICBpZiAoY2hhbmdlSW5mby51cmwgfHwgY2hhbmdlSW5mby5zdGF0dXMgPT09ICdjb21wbGV0ZScpIHtcbiAgICB2b2lkIHN5bmNMb3dCYW5kd2lkdGhSdWxlcyh7IHJlYXNvbjogJ3RhYi11cGRhdGVkJywgbG9nOiBmYWxzZSB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ2xvdy1iYW5kd2lkdGggcnVsZSByZWZyZXNoIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH1cbn0pO1xuXG5icm93c2VyLnRhYnMub25SZW1vdmVkLmFkZExpc3RlbmVyKCgpID0+IHtcbiAgdm9pZCBzeW5jTG93QmFuZHdpZHRoUnVsZXMoeyByZWFzb246ICd0YWItcmVtb3ZlZCcsIGxvZzogZmFsc2UgfSkuY2F0Y2goKGVycikgPT4ge1xuICAgIHZvaWQgd2FybignbG93LWJhbmR3aWR0aCBydWxlIHJlZnJlc2ggZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfSk7XG59KTtcblxuLyoqXG4gKiBSZS1pbmplY3QgdGhlIE1BSU4td29ybGQgcGFnZS1ob29rICsgaXNvbGF0ZWQtd29ybGQgY29udGVudCBzY3JpcHQgaW50b1xuICogZXZlcnkgYWxyZWFkeS1vcGVuIHguY29tIC8gdHdpdHRlci5jb20gdGFiLlxuICpcbiAqIE1hbmlmZXN0IGNvbnRlbnRfc2NyaXB0cyBvbmx5IGluamVjdCBvbiBmcmVzaCBuYXZpZ2F0aW9uIChydW5fYXQ6XG4gKiBkb2N1bWVudF9zdGFydCkuIFdoZW4gdGhlIHVzZXIgcmVsb2FkcyB0aGUgZXh0ZW5zaW9uIHdoaWxlIFggdGFicyBhcmVcbiAqIG9wZW4sIHRob3NlIHRhYnMga2VlcCB0aGVpciBjb250ZW50IHNjcmlwdHMgYnV0IG5ldmVyIGdldCBhIG5ldyBwYWdlLWhvb2tcbiAqIFx1MjAxNCBzbyBmZXRjaC9YSFIgc3RheXMgdW5wYXRjaGVkIGFuZCBjYXB0dXJlcyBzaWxlbnRseSBmYWlsLiBEb2luZyB0aGlzIG9uXG4gKiBldmVyeSB3YWtlIGlzIGlkZW1wb3RlbnQgKHBhZ2UtaG9vayBoYXMgYSBUQUcgZ3VhcmQpIGFuZCBjaGVhcC5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gcmVpbmplY3RJbnRvT3BlblRhYnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XG4gIHRyeSB7XG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NvdWxkIG5vdCBxdWVyeSBvcGVuIHRhYnMnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodGFicy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgZm9yIChjb25zdCB0YWIgb2YgdGFicykge1xuICAgIGlmICh0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJykgY29udGludWU7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICBmaWxlczogWydwYWdlLWhvb2suanMnXSxcbiAgICAgICAgLy8gRmlyZWZveCAxMjgrIHN1cHBvcnRzIHRoZSBNQUlOIGV4ZWN1dGlvbiB3b3JsZCB2aWEgdGhpcyBBUEksIGJ1dFxuICAgICAgICAvLyB0aGUgQHR5cGVzL2ZpcmVmb3gtd2ViZXh0LWJyb3dzZXIgcGFja2FnZSB3ZSdyZSBvbiBzdGlsbCBvbmx5XG4gICAgICAgIC8vIGRlY2xhcmVzICdJU09MQVRFRCcuIENhc3QgdGhyb3VnaCB0aGUgbGl0ZXJhbCB1bmlvbi5cbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgZmlsZXM6IFsnY29udGVudC5qcyddLFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBpbmZvKCdyZS1pbmplY3RlZCBzY3JpcHRzIGludG8gb3BlbiB0YWInLCB7XG4gICAgICAgIHRhYklkOiB0YWIuaWQsXG4gICAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsID8/ICcnKSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgLy8gU29tZSB0YWJzIChhYm91dDogcGFnZXMsIGRpc2NhcmRlZCB0YWJzLCBtaWQtbmF2aWdhdGlvbikgcmVqZWN0XG4gICAgICAvLyBleGVjdXRlU2NyaXB0LiBUaGF0J3MgZmluZSBcdTIwMTQgd2UnbGwgY2F0Y2ggdGhlbSBvbiB0aGUgbmV4dCB3YWtlIG9yXG4gICAgICAvLyB3aGVuIHRoZSB1c2VyIG5hdmlnYXRlcy5cbiAgICAgIGF3YWl0IHdhcm4oJ3JlLWluamVjdCBmYWlsZWQgZm9yIHRhYjsgY29udGludWluZycsIHtcbiAgICAgICAgdGFiSWQ6IHRhYi5pZCxcbiAgICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwgPz8gJycpLFxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQWxhcm1zKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignZmx1c2gtc3dlZXAnKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3ZlcmlmeS1jb25uZWN0aW9uJyk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNyZWF0ZSgnZmx1c2gtc3dlZXAnLCB7IHBlcmlvZEluTWludXRlczogRkxVU0hfQUxBUk1fTUlOVVRFUyB9KTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY3JlYXRlKCd2ZXJpZnktY29ubmVjdGlvbicsIHtcbiAgICBwZXJpb2RJbk1pbnV0ZXM6IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TIC8gNjBfMDAwLFxuICB9KTtcbn1cblxuLy8gRmlyZWZveCBNVjMgYWxhcm1zIGhhdmUgYSAzMHMgbWluaW11bSBwZXJpb2QsIGJ1dCB3ZSB3YW50IHN1Yi1taW51dGVcbi8vIHNjcm9sbGluZy4gVGhlIGF1dG8tc2Nyb2xsIGxvb3AgdGhlcmVmb3JlIHJ1bnMgb24gYW4gaW4tU1cgaW50ZXJ2YWwuXG4vLyBgYXV0b1Njcm9sbFNlc3Npb25gIGluIHN0b3JhZ2UgaXMgdGhlIHNvdXJjZSBvZiB0cnV0aCBmb3Igd2hldGhlciB0aGUgbG9vcFxuLy8gaXMgbWVhbnQgdG8gYmUgcnVubmluZyBcdTIwMTQgdGhlIHRpbWVyIGlzIGp1c3QgdGhlIGxvY2FsIGV4ZWN1dGlvbiBhcm0uXG5sZXQgYXV0b1Njcm9sbFRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcbmNvbnN0IFNIT1dfTU9SRV9SRUxFVkFOQ0VfVFRMX01TID0gMTAgKiA2MCAqIDEwMDA7XG5pbnRlcmZhY2UgVGFiUmVsZXZhbnRUd2VldHMge1xuICB1cGRhdGVkQXQ6IG51bWJlcjtcbiAgcGFnZVVybDogc3RyaW5nIHwgbnVsbDtcbiAgdHdlZXRJZHM6IFNldDxzdHJpbmc+O1xufVxuY29uc3Qgc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiID0gbmV3IE1hcDxudW1iZXIsIFRhYlJlbGV2YW50VHdlZXRzPigpO1xuXG4vLyBXYWl0LWZvci1pbmdlc3QgdGltZW91dDogaWYgYSByZWZldGNoIC8gbWVkaWEtY3Jhd2wgdGFiIG5hdmlnYXRpb24gZG9lc24ndFxuLy8gcHJvZHVjZSBhbiBpbmdlc3RlZCBjYXB0dXJlIHdpdGhpbiB0aGlzIG1hbnkgbXMsIGFkdmFuY2UgYW55d2F5IHNvIHdlXG4vLyBkb24ndCBkZWFkbG9jayBvbiBkZWxldGVkIC8gNDA0IC8gcGF5d2FsbGVkIHR3ZWV0cy5cbmNvbnN0IElOR0VTVF9XQUlUX01TID0gMjVfMDAwO1xuXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVBdXRvU2Nyb2xsQWxhcm0oKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIFdhcyB0aGUgbG9vcCBydW5uaW5nIGJlZm9yZSB0aGUgU1cgZXZpY3Rpb24/IFJlLWFybSBpZiBzby5cbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoc2VzcyAhPT0gbnVsbCAmJiBzLmVuYWJsZWQgIT09IGZhbHNlKSB7XG4gICAgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcbiAgfSBlbHNlIHtcbiAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk6IHZvaWQge1xuICBpZiAoYXV0b1Njcm9sbFRpbWVyICE9PSBudWxsKSB7XG4gICAgY2xlYXJJbnRlcnZhbChhdXRvU2Nyb2xsVGltZXIpO1xuICAgIGF1dG9TY3JvbGxUaW1lciA9IG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gYXJtQXV0b1Njcm9sbFRpbWVyKGludGVydmFsU2VjOiBudW1iZXIpOiB2b2lkIHtcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgY29uc3QgY2xhbXBlZCA9IE1hdGgubWluKFxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChpbnRlcnZhbFNlYykpXG4gICk7XG4gIGF1dG9TY3JvbGxUaW1lciA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIGF1dG9TY3JvbGxUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCdhdXRvLXNjcm9sbCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIGNsYW1wZWQgKiAxMDAwKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbih7XG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgc2Nyb2xsQ291bnQ6IDAsXG4gICAgaW5nZXN0ZWRDb3VudDogMCxcbiAgICBpbmdlc3RlZE5ld0NvdW50OiAwLFxuICAgIGluZ2VzdGVkRXhpc3RpbmdDb3VudDogMCxcbiAgICBza2lwcGVkT2xkQ291bnQ6IDAsXG4gICAgZXhwYW5kZWRDb3VudDogMCxcbiAgfSk7XG4gIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XG4gIGF3YWl0IGluZm8oJ2F1dG8tc2Nyb2xsIGxvb3Agc3RhcnRlZCcsIHsgaW50ZXJ2YWxfc2VjOiBzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyB9KTtcbiAgLy8gRmlyZSBvbmUgaW1tZWRpYXRlIHRpY2sgc28gdGhlIHVzZXIgc2VlcyBtb3Rpb24gcmlnaHQgYXdheS5cbiAgdm9pZCBhdXRvU2Nyb2xsVGljaygpO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdhdXRvLXNjcm9sbCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBzY3JvbGxzOiBzZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxuICAgIGluZ2VzdGVkOiBzZXNzPy5pbmdlc3RlZENvdW50ID8/IDAsXG4gICAgZXhwYW5kZWQ6IHNlc3M/LmV4cGFuZGVkQ291bnQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGF1dG9TY3JvbGxUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyB1cmw6IFsnaHR0cHM6Ly94LmNvbS8qJywgJ2h0dHBzOi8vdHdpdHRlci5jb20vKiddIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdhdXRvLXNjcm9sbDogdGFiIHF1ZXJ5IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBsZXQgc2Nyb2xsQ291bnQgPSAwO1xuICBsZXQgcmV0cnlDb3VudCA9IDA7XG4gIGZvciAoY29uc3QgdGFiIG9mIHRhYnMpIHtcbiAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIGNvbnRpbnVlO1xuICAgIGlmICh0YWIuZGlzY2FyZGVkKSBjb250aW51ZTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzdWx0cyA9IChhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgICBmdW5jOiAoKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRUZXh0ID0gKGVsOiBFbGVtZW50KTogc3RyaW5nID0+XG4gICAgICAgICAgICBgJHtlbC50ZXh0Q29udGVudCA/PyAnJ30gJHtlbC5nZXRBdHRyaWJ1dGUoJ2FyaWEtbGFiZWwnKSA/PyAnJ31gXG4gICAgICAgICAgICAgIC5yZXBsYWNlKC9cXHMrL2csICcgJylcbiAgICAgICAgICAgICAgLnRyaW0oKVxuICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICBjb25zdCBjbGlja1JldHJ5SWZSZWxvYWRFcnJvciA9ICgpOiBib29sZWFuID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGJvZHlUZXh0ID0gKGRvY3VtZW50LmJvZHk/LmlubmVyVGV4dCA/PyAnJykudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgIWJvZHlUZXh0LmluY2x1ZGVzKCdzb21ldGhpbmcgd2VudCB3cm9uZycpICYmXG4gICAgICAgICAgICAgICFib2R5VGV4dC5pbmNsdWRlcygndHJ5IHJlbG9hZGluZycpXG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgY29udHJvbHMgPSBBcnJheS5mcm9tKFxuICAgICAgICAgICAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdidXR0b24sW3JvbGU9XCJidXR0b25cIl0sYVtocmVmXScpXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY29uc3QgcmV0cnkgPSBjb250cm9scy5maW5kKChlbCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCB0ZXh0ID0gbm9ybWFsaXplZFRleHQoZWwpO1xuICAgICAgICAgICAgICByZXR1cm4gdGV4dCA9PT0gJ3JldHJ5JyB8fCB0ZXh0LmluY2x1ZGVzKCdyZXRyeScpIHx8IHRleHQuaW5jbHVkZXMoJ3RyeSBhZ2FpbicpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoIXJldHJ5KSByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAocmV0cnkgYXMgSFRNTEVsZW1lbnQpLmNsaWNrKCk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICB9O1xuICAgICAgICAgIGlmIChjbGlja1JldHJ5SWZSZWxvYWRFcnJvcigpKSByZXR1cm4geyByZXRyaWVkOiB0cnVlLCBzY3JvbGxlZDogZmFsc2UgfTtcbiAgICAgICAgICAvLyBTY3JvbGwgdGhlIHBhZ2UuIERpc3BhdGNoIEVuZCBrZXkgZmlyc3Qgc2luY2UgbWFueSBYIHN1cmZhY2VzXG4gICAgICAgICAgLy8gICAgKGxpc3RzLCBzZWFyY2gsIHJlcGxpZXMpIGJpbmQgcGFnaW5hdGlvbiB0cmlnZ2VycyB0byBpdCB2aWFcbiAgICAgICAgICAvLyAgICBSZWFjdCBoYW5kbGVyczsgdGhlbiBleHBsaWNpdGx5IHNjcm9sbCB0aGUgZG9jdW1lbnQuXG4gICAgICAgICAgY29uc3Qgb3B0czogS2V5Ym9hcmRFdmVudEluaXQgPSB7XG4gICAgICAgICAgICBrZXk6ICdFbmQnLFxuICAgICAgICAgICAgY29kZTogJ0VuZCcsXG4gICAgICAgICAgICBrZXlDb2RlOiAzNSxcbiAgICAgICAgICAgIHdoaWNoOiAzNSxcbiAgICAgICAgICAgIGJ1YmJsZXM6IHRydWUsXG4gICAgICAgICAgICBjYW5jZWxhYmxlOiB0cnVlLFxuICAgICAgICAgIH07XG4gICAgICAgICAgY29uc3QgZm9jdXMgPSAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCBhcyBIVE1MRWxlbWVudCB8IG51bGwpID8/IGRvY3VtZW50LmJvZHk7XG4gICAgICAgICAgZm9jdXMuZGlzcGF0Y2hFdmVudChuZXcgS2V5Ym9hcmRFdmVudCgna2V5ZG93bicsIG9wdHMpKTtcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXl1cCcsIG9wdHMpKTtcbiAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oe1xuICAgICAgICAgICAgdG9wOiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuc2Nyb2xsSGVpZ2h0LFxuICAgICAgICAgICAgYmVoYXZpb3I6ICdhdXRvJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICByZXR1cm4geyByZXRyaWVkOiBmYWxzZSwgc2Nyb2xsZWQ6IHRydWUgfTtcbiAgICAgICAgfSkgYXMgdW5rbm93biBhcyAoKSA9PiB2b2lkLFxuICAgICAgfSkpIGFzIEFycmF5PHsgcmVzdWx0PzogdW5rbm93biB9PjtcbiAgICAgIGNvbnN0IHBhZ2VSZXN1bHRzID0gcmVzdWx0c1xuICAgICAgICAubWFwKChyKSA9PiByLnJlc3VsdClcbiAgICAgICAgLmZpbHRlcihcbiAgICAgICAgICAocmVzdWx0KTogcmVzdWx0IGlzIHsgcmV0cmllZD86IHVua25vd247IHNjcm9sbGVkPzogdW5rbm93biB9ID0+XG4gICAgICAgICAgICB0eXBlb2YgcmVzdWx0ID09PSAnb2JqZWN0JyAmJiByZXN1bHQgIT09IG51bGxcbiAgICAgICAgKTtcbiAgICAgIGlmIChwYWdlUmVzdWx0cy5zb21lKChyZXN1bHQpID0+IHJlc3VsdC5yZXRyaWVkID09PSB0cnVlKSkge1xuICAgICAgICByZXRyeUNvdW50ICs9IDE7XG4gICAgICB9XG4gICAgICBpZiAocGFnZVJlc3VsdHMuc29tZSgocmVzdWx0KSA9PiByZXN1bHQuc2Nyb2xsZWQgPT09IHRydWUpKSB7XG4gICAgICAgIHNjcm9sbENvdW50ICs9IDE7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBUYWJzIHRoYXQgZGlzYWxsb3cgc2NyaXB0aW5nIChhYm91dDosIGRpc2NhcmRlZCwgbWlkLW5hdmlnYXRpb24pXG4gICAgICAvLyBqdXN0IGdldCBza2lwcGVkIFx1MjAxNCB0aGV5J2xsIGJlIGVsaWdpYmxlIG9uIGEgbGF0ZXIgdGljay5cbiAgICB9XG4gIH1cbiAgaWYgKHJldHJ5Q291bnQgPiAwKSB7XG4gICAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgY2xpY2tlZCBYIHJldHJ5IGNvbnRyb2wnLCB7IHRhYl9jb3VudDogcmV0cnlDb3VudCB9KTtcbiAgfVxuICBpZiAoc2Nyb2xsQ291bnQgPiAwKSB7XG4gICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgaWYgKHNlc3MgIT09IG51bGwpIHtcbiAgICAgIHNlc3Muc2Nyb2xsQ291bnQgKz0gc2Nyb2xsQ291bnQ7XG4gICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzZXNzKTtcbiAgICAgIC8vIE5vIGJyb2FkY2FzdCBvbiBldmVyeSB0aWNrIFx1MjAxNCB0aGUgMTVzIHNpZGViYXIgcmVmcmVzaCBwaWNrcyBpdCB1cC5cbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gcHJ1bmVTaG93TW9yZVJlbGV2YW5jZSgpOiB2b2lkIHtcbiAgY29uc3QgY3V0b2ZmID0gRGF0ZS5ub3coKSAtIFNIT1dfTU9SRV9SRUxFVkFOQ0VfVFRMX01TO1xuICBmb3IgKGNvbnN0IFt0YWJJZCwgZW50cnldIG9mIHNob3dNb3JlUmVsZXZhbnRUd2VldHNCeVRhYikge1xuICAgIGlmIChlbnRyeS51cGRhdGVkQXQgPCBjdXRvZmYpIHNob3dNb3JlUmVsZXZhbnRUd2VldHNCeVRhYi5kZWxldGUodGFiSWQpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbWVtYmVyU2hvd01vcmVSZWxldmFudFR3ZWV0cyhcbiAgdGFiSWQ6IG51bWJlciB8IG51bGwsXG4gIHBhZ2VVcmw6IHN0cmluZyB8IG51bGwsXG4gIHR3ZWV0czogUmVhZG9ubHlBcnJheTxDYW5vbmljYWxUd2VldD4sXG4gIGNvcmVIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+XG4pOiB2b2lkIHtcbiAgaWYgKHRhYklkID09PSBudWxsIHx8IHR3ZWV0cy5sZW5ndGggPT09IDAgfHwgY29yZUhhbmRsZXMuc2l6ZSA9PT0gMCkgcmV0dXJuO1xuICBjb25zdCBjb3JlVHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgIGlmIChjb3JlSGFuZGxlcy5oYXModC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpKSkgY29yZVR3ZWV0SWRzLmFkZCh0LnR3ZWV0X2lkKTtcbiAgfVxuICBjb25zdCBleGlzdGluZyA9IHNob3dNb3JlUmVsZXZhbnRUd2VldHNCeVRhYi5nZXQodGFiSWQpO1xuICBjb25zdCB0d2VldElkcyA9IGV4aXN0aW5nPy50d2VldElkcyA/PyBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgIGNvbnN0IGhhbmRsZSA9IHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKTtcbiAgICBjb25zdCByZXBseUhhbmRsZSA9IHQucmVwbHlfdG9fYWNjb3VudD8udG9Mb3dlckNhc2UoKSA/PyBudWxsO1xuICAgIGlmIChcbiAgICAgIGNvcmVIYW5kbGVzLmhhcyhoYW5kbGUpIHx8XG4gICAgICAocmVwbHlIYW5kbGUgIT09IG51bGwgJiYgY29yZUhhbmRsZXMuaGFzKHJlcGx5SGFuZGxlKSkgfHxcbiAgICAgICh0LnJlcGx5X3RvX3R3ZWV0X2lkICE9PSBudWxsICYmIGNvcmVUd2VldElkcy5oYXModC5yZXBseV90b190d2VldF9pZCkpIHx8XG4gICAgICAodC5xdW90ZWRfdHdlZXRfaWQgIT09IG51bGwgJiYgY29yZVR3ZWV0SWRzLmhhcyh0LnF1b3RlZF90d2VldF9pZCkpIHx8XG4gICAgICAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQgIT09IG51bGwgJiYgY29yZVR3ZWV0SWRzLmhhcyh0LnJldHdlZXRlZF90d2VldF9pZCkpXG4gICAgKSB7XG4gICAgICB0d2VldElkcy5hZGQodC50d2VldF9pZCk7XG4gICAgfVxuICB9XG4gIHNob3dNb3JlUmVsZXZhbnRUd2VldHNCeVRhYi5zZXQodGFiSWQsIHtcbiAgICB1cGRhdGVkQXQ6IERhdGUubm93KCksXG4gICAgcGFnZVVybCxcbiAgICB0d2VldElkcyxcbiAgfSk7XG59XG5cbmJyb3dzZXIuYWxhcm1zLm9uQWxhcm0uYWRkTGlzdGVuZXIoKGFsYXJtKSA9PiB7XG4gIGlmIChhbGFybS5uYW1lID09PSAnZmx1c2gtc3dlZXAnKSB7XG4gICAgdm9pZCBmbHVzaElkbGVCdWZmZXJzKCk7XG4gIH0gZWxzZSBpZiAoYWxhcm0ubmFtZSA9PT0gJ3ZlcmlmeS1jb25uZWN0aW9uJykge1xuICAgIHZvaWQgdmVyaWZ5Q29ubmVjdGlvbihmYWxzZSk7XG4gIH1cbiAgLy8gcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHByZXZpb3VzbHkgcmFuIHZpYSBhbGFybXM7IHRoZXkgbm93IHVzZVxuICAvLyBzZXRJbnRlcnZhbCB0byBlc2NhcGUgdGhlIDMwcyBhbGFybSBmbG9vci4gTGVhdmUgdGhlIG5hbWVzIGxpc3RlZFxuICAvLyBub3doZXJlIHNvIGFueSBvcnBoYW5lZCBhbGFybXMgKGZyb20gb2xkZXIgYnVpbGRzKSBqdXN0IG5vLW9wLlxufSk7XG5cbi8vIC0tLSBUb29sYmFyIGFjdGlvbjogdG9nZ2xlIHRoZSBzaWRlYmFyIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmlmIChicm93c2VyLmFjdGlvbj8ub25DbGlja2VkKSB7XG4gIGJyb3dzZXIuYWN0aW9uLm9uQ2xpY2tlZC5hZGRMaXN0ZW5lcihhc3luYyAodGFiKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNpZGViYXJBY3Rpb24gPSAoYnJvd3NlciBhcyB1bmtub3duIGFzIHtcbiAgICAgICAgc2lkZWJhckFjdGlvbj86IHsgdG9nZ2xlPzogKCkgPT4gUHJvbWlzZTx2b2lkPiB9O1xuICAgICAgfSkuc2lkZWJhckFjdGlvbjtcbiAgICAgIGlmIChzaWRlYmFyQWN0aW9uPy50b2dnbGUpIHtcbiAgICAgICAgYXdhaXQgc2lkZWJhckFjdGlvbi50b2dnbGUoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBzaWRlUGFuZWwgPSAoYnJvd3NlciBhcyB1bmtub3duIGFzIHtcbiAgICAgICAgc2lkZVBhbmVsPzogeyBvcGVuPzogKG9wdGlvbnM6IHsgd2luZG93SWQ/OiBudW1iZXIgfSkgPT4gUHJvbWlzZTx2b2lkPiB9O1xuICAgICAgfSkuc2lkZVBhbmVsO1xuICAgICAgaWYgKHNpZGVQYW5lbD8ub3Blbikge1xuICAgICAgICBjb25zdCBvcHRpb25zOiB7IHdpbmRvd0lkPzogbnVtYmVyIH0gPSB7fTtcbiAgICAgICAgaWYgKHR5cGVvZiB0YWIud2luZG93SWQgPT09ICdudW1iZXInKSBvcHRpb25zLndpbmRvd0lkID0gdGFiLndpbmRvd0lkO1xuICAgICAgICBhd2FpdCBzaWRlUGFuZWwub3BlbihvcHRpb25zKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsOiBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKCdzaWRlYmFyLmh0bWwnKSB9KTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIC8vIEZhbGxiYWNrOiBvcGVuIHRoZSBleHRlbnNpb24gVUkgaW4gYSB0YWIgaWYgdGhlIGJyb3dzZXItc3BlY2lmaWNcbiAgICAgIC8vIHNpZGViYXIgQVBJIGlzIHVuYXZhaWxhYmxlIG9yIHJlamVjdHMgdGhlIGFjdGlvbi1jbGljayByZXF1ZXN0LlxuICAgICAgYXdhaXQgd2Fybignc2lkZWJhciBvcGVuIGZhaWxlZDsgb3BlbmluZyBzaWRlYmFyIHRhYicsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsOiBicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKCdzaWRlYmFyLmh0bWwnKSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBjYXRjaCAodGFiRXJyKSB7XG4gICAgICAgIGF3YWl0IHdhcm4oJ3NpZGViYXIgdGFiIGZhaWxlZDsgb3BlbmluZyBvcHRpb25zJywgZGVzY3JpYmVFcnJvcih0YWJFcnIpKTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IGJyb3dzZXIucnVudGltZS5vcGVuT3B0aW9uc1BhZ2UoKTtcbiAgICB9XG4gIH0pO1xufVxuXG4vLyAtLS0gUnVudGltZSBtZXNzYWdlIGRpc3BhdGNoIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogdW5rbm93biwgc2VuZGVyKSA9PiB7XG4gIGlmICghaXNSdW50aW1lTWVzc2FnZShtc2cpKSByZXR1cm4gdW5kZWZpbmVkO1xuICByZXR1cm4gaGFuZGxlTWVzc2FnZShtc2csIHNlbmRlcikuY2F0Y2goKGVycikgPT4ge1xuICAgIHZvaWQgbG9nRXJyKCdtZXNzYWdlIGhhbmRsZXIgZmFpbGVkJywgeyB0eXBlOiBtc2cudHlwZSwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xuICAgIHRocm93IGVycjtcbiAgfSk7XG59KTtcblxuZnVuY3Rpb24gaXNSdW50aW1lTWVzc2FnZShtOiB1bmtub3duKTogbSBpcyBSdW50aW1lTWVzc2FnZSB7XG4gIHJldHVybiAhIW0gJiYgdHlwZW9mIG0gPT09ICdvYmplY3QnICYmIHR5cGVvZiAobSBhcyB7IHR5cGU/OiB1bmtub3duIH0pLnR5cGUgPT09ICdzdHJpbmcnO1xufVxuXG4vKiogTWVzc2FnZXMgdGhhdCBkcml2ZSB0aGUgY2FwdHVyZSBwaXBlbGluZS4gV2hlbiB0aGUgbWFzdGVyIHN3aXRjaCBpcyBPRkZcbiAqIHdlIGlnbm9yZSB0aGVzZSBidXQgc3RpbGwgcmVzcG9uZCB0byBzdGF0dXMgLyBjb25maWd1cmF0aW9uIHF1ZXJpZXMuICovXG5jb25zdCBDQVBUVVJFX1BJUEVMSU5FX01FU1NBR0VTID0gbmV3IFNldDxSdW50aW1lTWVzc2FnZVsndHlwZSddPihbXG4gICdncmFwaHFsLWNhcHR1cmUnLFxuICAnY2FwdHVyZS1ub3cnLFxuICAnY2FwdHVyZS1hbGwnLFxuICAnY2FwdHVyZS10aGlzLXBhZ2UnLFxuICAnZmx1c2gtYWxsJyxcbiAgJ2ZsdXNoLWhhbmRsZScsXG4gICdzdGFydC1yZWZldGNoJyxcbiAgJ3N0YXJ0LW1lZGlhLWNyYXdsJyxcbiAgJ3N0YXJ0LXRocmVhZC1vcGVuJyxcbiAgJ3N0YXJ0LWF1dG8tc2Nyb2xsJyxcbl0pO1xuXG5hc3luYyBmdW5jdGlvbiBpc0VuYWJsZWQoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICByZXR1cm4gcy5lbmFibGVkICE9PSBmYWxzZTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlTWVzc2FnZShcbiAgbXNnOiBSdW50aW1lTWVzc2FnZSxcbiAgc2VuZGVyPzogYnJvd3Nlci5ydW50aW1lLk1lc3NhZ2VTZW5kZXJcbik6IFByb21pc2U8dW5rbm93bj4ge1xuICAvLyBNYXN0ZXIgc3dpdGNoOiB3aGVuIHRoZSB1c2VyIGhhcyBwYXVzZWQgdGhlIGV4dGVuc2lvbiB3ZSBzdGlsbCBuZWVkXG4gIC8vIHRoZSBtZXRhLWNoYW5uZWxzIChnZXQtc3RhdGUsIHRvZ2dsZS1lbmFibGVkLCBvcGVuLW9wdGlvbnMsIFx1MjAyNikgc28gdGhlXG4gIC8vIHNpZGViYXIgc3RheXMgZnVuY3Rpb25hbCwgYnV0IGFueXRoaW5nIHRoYXQgd291bGQgYWN0dWFsbHkgY2FwdHVyZSxcbiAgLy8gY29tbWl0LCBvciBkcml2ZSBhIHRhYiBpcyBhIG5vLW9wLlxuICBpZiAoIShhd2FpdCBpc0VuYWJsZWQoKSkgJiYgQ0FQVFVSRV9QSVBFTElORV9NRVNTQUdFUy5oYXMobXNnLnR5cGUpKSB7XG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHBhdXNlZDogdHJ1ZSB9O1xuICB9XG4gIHN3aXRjaCAobXNnLnR5cGUpIHtcbiAgICBjYXNlICdncmFwaHFsLWNhcHR1cmUnOlxuICAgICAgYXdhaXQgb25HcmFwaHFsQ2FwdHVyZShcbiAgICAgICAgbXNnLmVuZHBvaW50LFxuICAgICAgICBtc2cudXJsLFxuICAgICAgICBtc2cucGFnZVVybCA/PyBudWxsLFxuICAgICAgICBtc2cucmVzcG9uc2UsXG4gICAgICAgIHNlbmRlcj8udGFiPy5pZCA/PyBudWxsXG4gICAgICApO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdjb250ZW50LWFsaXZlJzpcbiAgICAgIGF3YWl0IGluZm8oJ2NvbnRlbnQgc2NyaXB0IGFsaXZlIG9uIHBhZ2UnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAncGFnZS1ob29rLWFjdGl2ZSc6XG4gICAgICBhd2FpdCBpbmZvKCdwYWdlIGhvb2sgcGF0Y2hlZCBmZXRjaC9YSFInLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnbG9nLWNvbnRlbnQtZXZlbnQnOlxuICAgICAgaWYgKG1zZy5sZXZlbCA9PT0gJ3dhcm4nKSB7XG4gICAgICAgIGF3YWl0IHdhcm4obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9IGVsc2UgaWYgKG1zZy5sZXZlbCA9PT0gJ2Vycm9yJykge1xuICAgICAgICBhd2FpdCBsb2dFcnIobXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhd2FpdCBpbmZvKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICBjYXNlICdnZXQtdW5mb2xkLXRhcmdldHMnOiB7XG4gICAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgICBpZiAoc2V0dGluZ3MuZW5hYmxlZCA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuIHsgZW5hYmxlZDogZmFsc2UsIGNvcmVIYW5kbGVzOiBbXSwgcmVsZXZhbnRUd2VldElkczogW10gfTtcbiAgICAgIH1cbiAgICAgIHBydW5lU2hvd01vcmVSZWxldmFuY2UoKTtcbiAgICAgIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgICAgIGNvbnN0IGNvcmVIYW5kbGVzID0gYWNjb3VudHNcbiAgICAgICAgLmZpbHRlcigoYSkgPT4gYS5jYXRlZ29yeSA9PT0gJ2NvcmUnKVxuICAgICAgICAubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKTtcbiAgICAgIGNvbnN0IHRhYklkID0gc2VuZGVyPy50YWI/LmlkID8/IG51bGw7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICBjb3JlSGFuZGxlcyxcbiAgICAgICAgcmVsZXZhbnRUd2VldElkczpcbiAgICAgICAgICB0YWJJZCA9PT0gbnVsbCA/IFtdIDogQXJyYXkuZnJvbShzaG93TW9yZVJlbGV2YW50VHdlZXRzQnlUYWIuZ2V0KHRhYklkKT8udHdlZXRJZHMgPz8gW10pLFxuICAgICAgfTtcbiAgICB9XG4gICAgY2FzZSAnc2hvdy1tb3JlLXVuZm9sZGVkJzoge1xuICAgICAgaWYgKG1zZy5jb3VudCA+IDApIHtcbiAgICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xuICAgICAgICAgIGFzU2Vzcy5leHBhbmRlZENvdW50ICs9IG1zZy5jb3VudDtcbiAgICAgICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihhc1Nlc3MpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIH1cbiAgICBjYXNlICdnZXQtc3RhdGUnOlxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLW5vdyc6XG4gICAgICBhd2FpdCBjYXB0dXJlTm93KG1zZy5oYW5kbGUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLWFsbCc6XG4gICAgICBhd2FpdCBjYXB0dXJlQWxsKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhcHR1cmUtdGhpcy1wYWdlJzpcbiAgICAgIGF3YWl0IGNhcHR1cmVUaGlzUGFnZSgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdmbHVzaC1hbGwnOlxuICAgICAgYXdhaXQgZmx1c2hBbGwoJ3VzZXInKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnZmx1c2gtaGFuZGxlJzpcbiAgICAgIGF3YWl0IGZsdXNoSGFuZGxlKG1zZy5oYW5kbGUsICd1c2VyJyk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3RvZ2dsZS1hdXRvLWNhcHR1cmUnOlxuICAgICAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBhdXRvQ2FwdHVyZTogbXNnLm9uIH0pO1xuICAgICAgYXdhaXQgaW5mbygnYXV0by1jYXB0dXJlIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3RvZ2dsZS11cGRhdGUtZXhpc3RpbmcnOlxuICAgICAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyB1cGRhdGVFeGlzdGluZzogbXNnLm9uIH0pO1xuICAgICAgYXdhaXQgaW5mbygndXBkYXRlLWV4aXN0aW5nIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3RvZ2dsZS1sb3ctYmFuZHdpZHRoJzpcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgbG93QmFuZHdpZHRoQnJvd3Npbmc6IG1zZy5vbiB9KTtcbiAgICAgIGF3YWl0IHN5bmNMb3dCYW5kd2lkdGhSdWxlcyh7IHJlYXNvbjogJ3RvZ2dsZScsIGxvZzogdHJ1ZSB9KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAndG9nZ2xlLWVuYWJsZWQnOiB7XG4gICAgICBjb25zdCBzID0gYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBlbmFibGVkOiBtc2cub24gfSk7XG4gICAgICBpZiAoIW1zZy5vbikge1xuICAgICAgICAvLyBQYXVzaW5nIHN0b3BzIGFsbCBpbi1mbGlnaHQgbG9vcHMgc28gdGhlIHVzZXIgZ2V0cyBpbW1lZGlhdGVcbiAgICAgICAgLy8gcXVpZXQsIG5vdCBhIFwib25lIG1vcmUgdGlja1wiIHN1cnByaXNlLlxuICAgICAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICAgICAgICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gICAgICAgIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTtcbiAgICAgICAgc3RvcFRocmVhZE9wZW5JbnRlcnZhbCgpO1xuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigncmVmZXRjaC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7XG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd0aHJlYWQtb3Blbi10aWNrJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBSZXN1bWluZyByZS1hcm1zIGFueSBsb29wcyB3aG9zZSBzZXNzaW9uIGlzIHN0aWxsIHNldC5cbiAgICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICAgIGlmIChzZXNzICE9PSBudWxsKSBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xuICAgICAgfVxuICAgICAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIG1hc3RlciBzd2l0Y2ggdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgfVxuICAgIGNhc2UgJ3N0YXJ0LWF1dG8tc2Nyb2xsJzpcbiAgICAgIGF3YWl0IHN0YXJ0QXV0b1Njcm9sbExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLWF1dG8tc2Nyb2xsJzpcbiAgICAgIGF3YWl0IGNhbmNlbEF1dG9TY3JvbGxMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCc6IHtcbiAgICAgIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICAgICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICAgICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChtc2cuc2Vjb25kcykpXG4gICAgICApO1xuICAgICAgYXdhaXQgdXBkYXRlU2V0dGluZ3MoeyBhdXRvU2Nyb2xsSW50ZXJ2YWxTZWM6IHNlY29uZHMgfSk7XG4gICAgICAvLyBSZS1hcm0gYW55IGFjdGl2ZSBsb29wcyB3aXRoIHRoZSBuZXcgaW50ZXJ2YWwuXG4gICAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgIGlmIChzZXNzICE9PSBudWxsKSBhcm1BdXRvU2Nyb2xsVGltZXIoc2Vjb25kcyk7XG4gICAgICBpZiAocmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcbiAgICAgIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHMpO1xuICAgICAgaWYgKHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgc3RhcnRUaHJlYWRPcGVuSW50ZXJ2YWwoc2Vjb25kcyk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIH1cbiAgICBjYXNlICdzdGFydC1yZWZldGNoJzpcbiAgICAgIGF3YWl0IHN0YXJ0UmVmZXRjaExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLXJlZmV0Y2gnOlxuICAgICAgYXdhaXQgY2FuY2VsUmVmZXRjaExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnc3RhcnQtbWVkaWEtY3Jhd2wnOlxuICAgICAgYXdhaXQgc3RhcnRNZWRpYUNyYXdsTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYW5jZWwtbWVkaWEtY3Jhd2wnOlxuICAgICAgYXdhaXQgY2FuY2VsTWVkaWFDcmF3bExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnc3RhcnQtdGhyZWFkLW9wZW4nOlxuICAgICAgYXdhaXQgc3RhcnRUaHJlYWRPcGVuTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYW5jZWwtdGhyZWFkLW9wZW4nOlxuICAgICAgYXdhaXQgY2FuY2VsVGhyZWFkT3Blbkxvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAncHVyZ2UtdW5yZWxhdGVkJzoge1xuICAgICAgY29uc3QgYWNjcyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gICAgICBjb25zdCB0cmFja2VkID0gbmV3IFNldChhY2NzLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSkpO1xuICAgICAgY29uc3Qgc3VtbWFyeSA9IGF3YWl0IHB1cmdlVW5yZWxhdGVkU3RhdGUodHJhY2tlZCk7XG4gICAgICBhd2FpdCBpbmZvKCdwdXJnZWQgdW5yZWxhdGVkIHN0YXRlJywgc3VtbWFyeSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIH1cbiAgICBjYXNlICdyZWZyZXNoLWFjY291bnRzJzpcbiAgICAgIGF3YWl0IHJlZnJlc2hBY2NvdW50c0xpc3QodHJ1ZSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3ZlcmlmeS1jb25uZWN0aW9uJzpcbiAgICAgIGF3YWl0IHZlcmlmeUNvbm5lY3Rpb24odHJ1ZSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NsZWFyLWFjdGl2aXR5JzpcbiAgICAgIGF3YWl0IGNsZWFyQWN0aXZpdHkoKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnb3Blbi1vcHRpb25zJzpcbiAgICAgIGF3YWl0IGJyb3dzZXIucnVudGltZS5vcGVuT3B0aW9uc1BhZ2UoKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnb3Blbi12aWV3ZXInOiB7XG4gICAgICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgICAgIGNvbnN0IHVybCA9IHZpZXdlclVybChzKTtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ3Vua25vd24gbWVzc2FnZSB0eXBlJyB9O1xuICB9XG59XG5cbi8vIC0tLSBDYXB0dXJlIHBpcGVsaW5lIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIG9uR3JhcGhxbENhcHR1cmUoXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHVybDogc3RyaW5nLFxuICBwYWdlVXJsOiBzdHJpbmcgfCBudWxsLFxuICByZXNwb25zZTogdW5rbm93bixcbiAgc2VuZGVyVGFiSWQ6IG51bWJlciB8IG51bGxcbik6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoUFJPRklMRV9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuOyAvLyBub3QgdHdlZXQtYmVhcmluZ1xuICBpZiAoIVRXRUVUX0VORFBPSU5UUy5oYXMoZW5kcG9pbnQpKSByZXR1cm47XG5cbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoc2V0dGluZ3MuZW5hYmxlZCA9PT0gZmFsc2UpIHJldHVybjtcbiAgaWYgKHNldHRpbmdzLmF1dG9DYXB0dXJlID09PSBmYWxzZSkge1xuICAgIGNvbnN0IGV4cGxpY2l0Q2FwdHVyZUFjdGl2ZSA9XG4gICAgICBEYXRlLm5vdygpIDwgbWFudWFsQ2FwdHVyZVVudGlsTXMgfHxcbiAgICAgIChhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpKSAhPT0gbnVsbCB8fFxuICAgICAgKGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCkpICE9PSBudWxsIHx8XG4gICAgICAoYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKSkgIT09IG51bGw7XG4gICAgaWYgKCFleHBsaWNpdENhcHR1cmVBY3RpdmUpIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgLy8gV2UgZGVsaWJlcmF0ZWx5IGRvIE5PVCBzaG9ydC1jaXJjdWl0IHdoZW4gdGhlIFBBVCBpcyBtaXNzaW5nLiBUaGVcbiAgLy8gbm9ybWFsaXplIHN0ZXAgaXMgY2hlYXAsIHRoZSBidWZmZXIgc3Vydml2ZXMgc2VydmljZS13b3JrZXIgZXZpY3Rpb24sXG4gIC8vIGFuZCBvbmNlIHRoZSBQQVQgaXMgc2V0IHRoZSBuZXh0IGFsYXJtIG9yIHVzZXItdHJpZ2dlcmVkIGZsdXNoIGNvbW1pdHNcbiAgLy8gZXZlcnl0aGluZyB3ZSd2ZSBzZWVuLiBEcm9wcGluZyBjYXB0dXJlcyBoZXJlIHdhcyBoaWRpbmcgdGhlIHVzZXInc1xuICAvLyBmaXJzdCBicm93c2luZyBzZXNzaW9uIGVudGlyZWx5LlxuXG4gIC8vIFR3by1zdGFnZSBmaWx0ZXI6XG4gIC8vICAgMS4gQnVpbGQgRVZFUlkgY2Fub25pY2FsIHR3ZWV0IHdlIGNhbiBmaW5kIGluIHRoZSByZXNwb25zZSAobm8gaGFuZGxlXG4gIC8vICAgICAgZmlsdGVyIGF0IHRoZSBub3JtYWxpemVyIGxldmVsIFx1MjAxNCB3ZSBzdGlsbCB3YW50IHF1b3RlZC9SVCdkIHBhcmVudHNcbiAgLy8gICAgICB0aGF0IGFwcGVhciBhcyBzaWJsaW5nIG5vZGVzKS5cbiAgLy8gICAyLiBBcHBseSBgZmlsdGVyUmVsYXRlZGAgcG9zdC1ob2MgdG8gZHJvcCBhbnl0aGluZyB0aGF0IGhhcyBub1xuICAvLyAgICAgIHJlbGF0aW9uc2hpcCB0byBhIHRyYWNrZWQgYWNjb3VudC4gVGhlIG9sZCBiZWhhdmlvdXIgKFwiZW1wdHlcbiAgLy8gICAgICBhbGxvd2VkLXNldCBvbiB1c2VyLXBhZ2UgZW5kcG9pbnRzLCBmdWxsIGZpbHRlciBvbiBob21lL3NlYXJjaFwiKVxuICAvLyAgICAgIHdhcyB3YXkgdG9vIHBlcm1pc3NpdmUgb24gdGhlIFJlcGxpZXMgdGFiOiBldmVyeSByYW5kb20gcmVwbGllcidzXG4gIC8vICAgICAgcmVwbHkgbGFuZGVkIGluIGEgcGVyLWhhbmRsZSBidWZmZXIga2V5ZWQgYnkgdGhlaXIgb3duIGhhbmRsZS5cbiAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjb3VudHMubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKSk7XG4gIGNvbnN0IGNvcmUgPSBuZXcgU2V0KFxuICAgIGFjY291bnRzLmZpbHRlcigoYSkgPT4gYS5jYXRlZ29yeSA9PT0gJ2NvcmUnKS5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpXG4gICk7XG4gIGNvbnN0IGNhcHR1cmVkQXQgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG5cbiAgbGV0IG5vcm1hbGl6ZWQ7XG4gIHRyeSB7XG4gICAgbm9ybWFsaXplZCA9IG5vcm1hbGl6ZShyZXNwb25zZSwge1xuICAgICAgY2FwdHVyZWRBdCxcbiAgICAgIHJ1bklkOiAncGVuZGluZycsXG4gICAgICBlbmRwb2ludCxcbiAgICAgIGFsbG93ZWRIYW5kbGVzOiBuZXcgU2V0PHN0cmluZz4oKSxcbiAgICAgIHNvdXJjZVVybDogcGFnZVVybCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgcXVhcmFudGluZSgnbm9ybWFsaXplLXRocmV3JywgZW5kcG9pbnQsIHVybCwgcmVzcG9uc2UsIGVycik7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHJldHdlZXRFZGdlcyA9IGJ1aWxkUmV0d2VldEVkZ2VzKFxuICAgIG5vcm1hbGl6ZWQudHdlZXRzLFxuICAgIGFjY291bnRzLFxuICAgIGNhcHR1cmVkQXQsXG4gICAgZW5kcG9pbnQsXG4gICAgcGFnZVVybCA/PyB1cmxcbiAgKTtcbiAgLy8gRHJvcCB1bnJlbGF0ZWQgdHdlZXRzLiBUaGUgZmlsdGVyIGlzIGVuZHBvaW50LWF3YXJlOlxuICAvLyAgIC0gT24gdGhlIGhvbWUgLyBzZWFyY2ggdGltZWxpbmVzIHdlJ2QgYWxyZWFkeSBiZWVuIGZpbHRlcmluZyB0b1xuICAvLyAgICAgdHJhY2tlZCBhdXRob3JzIG9ubHkgXHUyMDE0IGtlZXAgdGhhdCBiZWhhdmlvdXIgYnV0IGdvIHRocm91Z2ggdGhlIHNhbWVcbiAgLy8gICAgIGBmaWx0ZXJSZWxhdGVkYCBoZWxwZXIgc28gdGhlIHJ1bGVzIGFyZSB1bmlmb3JtLlxuICAvLyAgIC0gT24gdXNlci1wYWdlIGVuZHBvaW50cyB3ZSBub3cgYWxzbyBkcm9wIGFueXRoaW5nIHRoYXQgaXNuJ3QgZWl0aGVyXG4gIC8vICAgICBhdXRob3JlZC1ieSwgbWVudGlvbmluZywgcmVwbHlpbmctdG8sIG9yIHJlZmVyZW5jZWQtYnkgYSB0cmFja2VkXG4gIC8vICAgICBhY2NvdW50LlxuICBjb25zdCBiZWZvcmVGaWx0ZXIgPSBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGg7XG4gIG5vcm1hbGl6ZWQudHdlZXRzID0gZmlsdGVyUmVsYXRlZChub3JtYWxpemVkLnR3ZWV0cywgdHJhY2tlZCwgY29yZSk7XG4gIGNvbnN0IGRyb3BwZWRVbnJlbGF0ZWQgPSBiZWZvcmVGaWx0ZXIgLSBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGg7XG4gIGlmIChkcm9wcGVkVW5yZWxhdGVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2Ryb3BwZWQgdW5yZWxhdGVkIHR3ZWV0cycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgZHJvcHBlZDogZHJvcHBlZFVucmVsYXRlZCxcbiAgICAgIGtlcHQ6IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuICByZW1lbWJlclNob3dNb3JlUmVsZXZhbnRUd2VldHMoc2VuZGVyVGFiSWQsIHBhZ2VVcmwsIG5vcm1hbGl6ZWQudHdlZXRzLCBjb3JlKTtcblxuICAvLyBEaWFnbm9zdGljOiBldmVyeSB0d2VldC1lbmRwb2ludCBwYXlsb2FkIGdldHMgYSBsaW5lIGluIHRoZSBhY3Rpdml0eVxuICAvLyB0YWlsIHdpdGggd2hhdCB3ZSBzYXcgdnMga2VwdC4gV2hlbiBvYnNlcnZlZD0wIHdlIGFsc28gZW1pdCBhIHNoYXBlXG4gIC8vIHByb2JlIChrZXkgcGF0aHMgKyB0eXBlbmFtZXMpIHNvIHdlIGNhbiB0ZWxsIHdoZXRoZXIgWCByZXR1cm5lZCBhblxuICAvLyBlbXB0eSBlbnZlbG9wZSwgYSBsb2dpbi13YWxsIHJlc3BvbnNlLCBvciBhIG5ldyBzaGFwZSB3ZSBkb24ndCBrbm93IGhvd1xuICAvLyB0byB3YWxrIHlldC5cbiAgaWYgKG5vcm1hbGl6ZWQub2JzZXJ2ZWRfaWRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGF3YWl0IGluZm8oJ2dyYXBocWwgcGF5bG9hZCBlbXB0eSBcdTIwMTQgc2hhcGUgcHJvYmUnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHR5cGVuYW1lczogcHJvYmVUeXBlbmFtZXMocmVzcG9uc2UpLnNsaWNlKDAsIDMwKSxcbiAgICAgIHR3ZWV0X2tleXM6IHByb2JlRmlyc3RUeXBlU2hhcGUocmVzcG9uc2UsICdUd2VldCcpLFxuICAgICAgdHdlZXRfY29yZV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbJ2NvcmUnXSksXG4gICAgICB0d2VldF9sZWdhY3lfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgWydsZWdhY3knXSksXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcbiAgICAgICAgJ3Jlc3VsdCcsXG4gICAgICBdKSxcbiAgICAgIHVzZXJfcmVzdWx0c19yZXN1bHRfY29yZV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXG4gICAgICAgICdjb3JlJyxcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXG4gICAgICAgICdyZXN1bHQnLFxuICAgICAgICAnY29yZScsXG4gICAgICBdKSxcbiAgICAgIHVzZXJfcmVzdWx0c19yZXN1bHRfbGVnYWN5X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcbiAgICAgICAgJ3Jlc3VsdCcsXG4gICAgICAgICdsZWdhY3knLFxuICAgICAgXSksXG4gICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgYXdhaXQgaW5mbygnZ3JhcGhxbCBwYXlsb2FkIHNlZW4nLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIG9ic2VydmVkOiBub3JtYWxpemVkLm9ic2VydmVkX2lkcy5sZW5ndGgsXG4gICAgICBrZXB0OiBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGgsXG4gICAgfSk7XG4gIH1cblxuICBpZiAobm9ybWFsaXplZC51bmF2YWlsYWJsZV90d2VldHMubGVuZ3RoID4gMCkge1xuICAgIGF3YWl0IHJlY29yZFVuYXZhaWxhYmxlVHdlZXRzKFxuICAgICAgbm9ybWFsaXplZC51bmF2YWlsYWJsZV90d2VldHMsXG4gICAgICB0cmFja2VkLFxuICAgICAgY2FwdHVyZWRBdCxcbiAgICAgIHVybCxcbiAgICAgIGVuZHBvaW50XG4gICAgKTtcbiAgfVxuXG4gIGlmIChub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBidWZmZXJlZEVkZ2VzID0gYXdhaXQgYnVmZmVyUmV0d2VldEVkZ2VzKFxuICAgICAgcmV0d2VldEVkZ2VzLFxuICAgICAgY2FwdHVyZWRBdCxcbiAgICAgIHBhZ2VVcmwgPz8gdXJsLFxuICAgICAgZW5kcG9pbnRcbiAgICApO1xuICAgIGlmIChidWZmZXJlZEVkZ2VzID4gMCkgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBSZWZldGNoIHF1ZXVlIGhvdXNla2VlcGluZyBcdTIwMTQgcnVucyBCRUZPUkUgdGhlIGRlZHVwIHNob3J0LWNpcmN1aXQuIEFcbiAgLy8gcmVmZXRjaCBjYXB0dXJlIGNvbWVzIGJhY2sgd2l0aCB0aGUgc2FtZSBlbmdhZ2VtZW50IGNvdW50cyAod2UncmVcbiAgLy8gb25seSBhZnRlciB0aGUgZnVsbCB0ZXh0KSwgc28gdGhlIGRlZHVwIGJlbG93IHdvdWxkIHNpbGVudGx5IGRyb3BcbiAgLy8gaXQgYW5kIHRoZSBxdWV1ZSB3b3VsZCBuZXZlciBkcmFpbi4gSG9pc3QgdGhlIGVucXVldWUvZGVxdWV1ZSBoZXJlXG4gIC8vIHNvIHRoZSBsb29wIHJlbGlhYmx5IGFkdmFuY2VzIGV2ZW4gd2hlbiBubyBjb21taXQgaGFwcGVucy5cbiAgLy9cbiAgLy8gQWxzbzogaWYgZWl0aGVyIGxvb3AncyBpbmZsaWdodCB0YXJnZXQgYXBwZWFycyBoZXJlLCBtYXJrIHRoZSBsb29wXG4gIC8vIGFzIFwiaW5nZXN0ZWRcIiBzbyB0aGUgbmV4dCB0aWNrIGNhbiBhZHZhbmNlLiBUaGUgd2FpdC1mb3ItaW5nZXN0XG4gIC8vIGd1YXJkIG90aGVyd2lzZSBibG9ja3MgdW50aWwgdGhlIG5hdmlnYXRpb24tdGltZW91dCBmaXJlcy5cbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGNvbnN0IHRocmVhZE9wZW5TZXNzID0gYXdhaXQgZ2V0VGhyZWFkT3BlblNlc3Npb24oKTtcbiAgZm9yIChjb25zdCB0IG9mIG5vcm1hbGl6ZWQudHdlZXRzKSB7XG4gICAgaWYgKHQuaXNfdHJ1bmNhdGVkKSB7XG4gICAgICBhd2FpdCBlbnF1ZXVlUmVmZXRjaCh0LmFjY291bnRfaGFuZGxlLCB0LnR3ZWV0X2lkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2godC5hY2NvdW50X2hhbmRsZSwgdC50d2VldF9pZCk7XG4gICAgfVxuICAgIC8vIFN1Y2Nlc3NmdWxseSBidWlsdCB0d2VldHMgYXJlIG5vIGxvbmdlciBcInBhcnRpYWxcIiBcdTIwMTQgZHJvcCBmcm9tIHRoZVxuICAgIC8vIG1lZGlhLWNyYXdsIHF1ZXVlIHJlZ2FyZGxlc3Mgb2Ygd2hpY2ggaGFuZGxlIHdlJ2QgaGludGVkIGVhcmxpZXIuXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodC50d2VldF9pZCk7XG4gICAgaWYgKHJlZmV0Y2hTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdC50d2VldF9pZCkge1xuICAgICAgcmVmZXRjaFNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgICAgcmVmZXRjaFNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihyZWZldGNoU2Vzcyk7XG4gICAgfVxuICAgIGlmIChtZWRpYUNyYXdsU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obWVkaWFDcmF3bFNlc3MpO1xuICAgIH1cbiAgICBpZiAodGhyZWFkT3BlblNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XG4gICAgICB0aHJlYWRPcGVuU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICB0aHJlYWRPcGVuU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IG1hcmtUaHJlYWRPcGVuU2Vlbih0LnR3ZWV0X2lkKTtcbiAgICAgIGF3YWl0IGRlcXVldWVUaHJlYWRPcGVuKHQudHdlZXRfaWQpO1xuICAgICAgYXdhaXQgc2V0VGhyZWFkT3BlblNlc3Npb24odGhyZWFkT3BlblNlc3MpO1xuICAgIH1cbiAgfVxuXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiB0d2VldC1zaGFwZWQgbm9kZXMgdGhlIHdhbGtlciBzYXcgYnV0IGNvdWxkbid0IHR1cm5cbiAgLy8gaW50byBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBFbnF1ZXVlIG9ubHkgSURzIHdlIGhhdmVuJ3QgYWxyZWFkeVxuICAvLyBjb21taXR0ZWQgKHVzZXItcmVxdWVzdGVkIGRlZHVwIGFnYWluc3QgdGhlIGFyY2hpdmUpLlxuICBmb3IgKGNvbnN0IHBhcnRpYWwgb2Ygbm9ybWFsaXplZC5wYXJ0aWFsX2lkcykge1xuICAgIGlmIChhd2FpdCBpc0NvbW1pdHRlZChwYXJ0aWFsLnR3ZWV0X2lkKSkgY29udGludWU7XG4gICAgYXdhaXQgZW5xdWV1ZU1lZGlhQ3Jhd2wocGFydGlhbC5oaW50X2hhbmRsZSwgcGFydGlhbC50d2VldF9pZCk7XG4gIH1cbiAgaWYgKG5vcm1hbGl6ZWQucGFydGlhbF9pZHMubGVuZ3RoID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsOiBlbnF1ZXVlZCBwYXJ0aWFsIGNhcHR1cmVzJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBwYXJ0aWFsOiBub3JtYWxpemVkLnBhcnRpYWxfaWRzLmxlbmd0aCxcbiAgICAgIHF1ZXVlX3RvdGFsOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxuICAgIH0pO1xuICB9XG5cbiAgLy8gQ3Jvc3Mtc2Vzc2lvbiBkZWR1cDogZHJvcCB0d2VldHMgd2UndmUgYWxyZWFkeSBjb21taXR0ZWQgd2l0aCBpZGVudGljYWxcbiAgLy8gZW5nYWdlbWVudCBjb3VudHMuIExpa2VzL1JUcy9yZXBsaWVzL3F1b3RlcyBzdGlsbCB0cmlnZ2VyIGEgcmVjYXB0dXJlXG4gIC8vIHNvIGVuZ2FnZW1lbnRfaGlzdG9yeSBncm93cyBvdmVyIHRpbWUuIHZpZXdfY291bnQgaXMgaW50ZW50aW9uYWxseVxuICAvLyBleGNsdWRlZCBcdTIwMTQgaXQgY2h1cm5zIHRvbyBmYXN0IHRvIGJlIHVzZWZ1bCBhcyBhIGZyZXNobmVzcyBzaWduYWwuXG4gIC8vIGBpc190cnVuY2F0ZWRgIGlzIHBhcnQgb2YgdGhlIHNpZ25hdHVyZSBzbyBhIHJlZmV0Y2ggdGhhdCBmbGlwc1xuICAvLyB0cnVuY2F0ZWRcdTIxOTJmdWxsIGlzIHRyZWF0ZWQgYXMgYSBtYXRlcmlhbCBjaGFuZ2UgYW5kIGdldHMgY29tbWl0dGVkLlxuICAvL1xuICAvLyBXaGVuIHRoZSB1c2VyIGhhcyB0dXJuZWQgb2ZmIFwidXBkYXRlIGV4aXN0aW5nXCIsIHdlIHNraXAgdGhlIGVuZ2FnZW1lbnRcbiAgLy8gY29tcGFyaXNvbiBlbnRpcmVseTogYW55IHR3ZWV0IHRoYXQncyBhbHJlYWR5IGNvbW1pdHRlZCB1bmRlciBhbnlcbiAgLy8gaGFuZGxlIGdldHMgZHJvcHBlZCBoZXJlLCBzbyB3ZSBkb24ndCBwYXkgR2l0SHViLUFQSSBvdmVyaGVhZCBqdXN0IHRvXG4gIC8vIHJlZnJlc2ggbGlrZSAvIFJUIGNvdW50cy4gTmV3IHR3ZWV0cyBhbmQgdHJ1bmNhdGVkXHUyMTkyZnVsbCByZWZldGNoZXNcbiAgLy8gc3RpbGwgZmxvdyB0aHJvdWdoIG5vcm1hbGx5IGJlY2F1c2UgdGhleSBhcmVuJ3QgaW4gdGhlIGluZGV4IHlldFxuICAvLyAob3IgY2FycnkgYW4gaXNfdHJ1bmNhdGVkIHRyYW5zaXRpb24gdGhhdCBmYWlscyB0aGUgc2lnIGNoZWNrKS5cbiAgLy8gRnVsbC10ZXh0IHVwZ3JhZGVzIGJ5cGFzcyB0aGlzIHNraXAgZXZlbiB3aXRoIHVwZGF0ZUV4aXN0aW5nPWZhbHNlLlxuICBjb25zdCB1cGRhdGVFeGlzdGluZyA9IHNldHRpbmdzLnVwZGF0ZUV4aXN0aW5nICE9PSBmYWxzZTtcbiAgY29uc3QgY29tbWl0dGVkSWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgY29uc3QgYXJjaGl2ZVNuYXBzaG90ID0gYXdhaXQgZ2V0QXJjaGl2ZVNuYXBzaG90KCk7XG4gIGxldCBkZWR1cGVkU2tpcHBlZCA9IDA7XG4gIGxldCBza2lwcGVkTm9VcGRhdGVMb2NhbCA9IDA7XG4gIGxldCBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCA9IDA7XG4gIGxldCBvbGRGcm9tU25hcHNob3QgPSAwO1xuICBsZXQgZnVsbFRleHRVcGdyYWRlcyA9IDA7XG4gIGNvbnN0IGxpdmVUd2VldHM6IHR5cGVvZiBub3JtYWxpemVkLnR3ZWV0cyA9IFtdO1xuICBjb25zdCBmcmVzaG5lc3NCeUlkID0gbmV3IE1hcDxzdHJpbmcsICduZXcnIHwgJ2V4aXN0aW5nJz4oKTtcbiAgY29uc3QgYWN0aW9uQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCBUd2VldFNpZ2h0aW5nWydhY3Rpb24nXT4oKTtcbiAgZm9yIChjb25zdCB0IG9mIG5vcm1hbGl6ZWQudHdlZXRzKSB7XG4gICAgY29uc3QgcHJldiA9IGNvbW1pdHRlZElkeFt0LmFjY291bnRfaGFuZGxlXT8uW3QudHdlZXRfaWRdO1xuICAgIGNvbnN0IG9sZEJ5U25hcHNob3QgPSAhcHJldiAmJiBhcmNoaXZlU25hcHNob3RIYXNUd2VldCh0LCBhcmNoaXZlU25hcHNob3QpO1xuICAgIGNvbnN0IHByZXZpb3VzbHlBcmNoaXZlZCA9IEJvb2xlYW4ocHJldikgfHwgb2xkQnlTbmFwc2hvdDtcbiAgICBmcmVzaG5lc3NCeUlkLnNldCh0LnR3ZWV0X2lkLCBwcmV2aW91c2x5QXJjaGl2ZWQgPyAnZXhpc3RpbmcnIDogJ25ldycpO1xuICAgIGlmIChvbGRCeVNuYXBzaG90KSBvbGRGcm9tU25hcHNob3QgKz0gMTtcbiAgICBjb25zdCBzaWcgPSBlbmdhZ2VtZW50U2lnKFxuICAgICAgdC5saWtlX2NvdW50LFxuICAgICAgdC5yZXR3ZWV0X2NvdW50LFxuICAgICAgdC5yZXBseV9jb3VudCxcbiAgICAgIHQucXVvdGVfY291bnQsXG4gICAgICB0LmlzX3RydW5jYXRlZFxuICAgICk7XG4gICAgY29uc3QgZnVsbFRleHRVcGdyYWRlID0gcHJldiAhPT0gdW5kZWZpbmVkICYmIHNpZ01hcmtzVHJ1bmNhdGVkKHByZXYuc2lnKSAmJiAhdC5pc190cnVuY2F0ZWQ7XG4gICAgaWYgKHByZXZpb3VzbHlBcmNoaXZlZCAmJiAhdXBkYXRlRXhpc3RpbmcgJiYgIWZ1bGxUZXh0VXBncmFkZSkge1xuICAgICAgaWYgKHByZXYpIHNraXBwZWROb1VwZGF0ZUxvY2FsICs9IDE7XG4gICAgICBlbHNlIHNraXBwZWROb1VwZGF0ZVNuYXBzaG90ICs9IDE7XG4gICAgICBhY3Rpb25CeUlkLnNldCh0LnR3ZWV0X2lkLCAnc2tpcHBlZCcpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChwcmV2ICYmIHByZXYuc2lnID09PSBzaWcpIHtcbiAgICAgIGRlZHVwZWRTa2lwcGVkICs9IDE7XG4gICAgICBhY3Rpb25CeUlkLnNldCh0LnR3ZWV0X2lkLCAndW5jaGFuZ2VkJyk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGZ1bGxUZXh0VXBncmFkZSkgZnVsbFRleHRVcGdyYWRlcyArPSAxO1xuICAgIGFjdGlvbkJ5SWQuc2V0KHQudHdlZXRfaWQsICdidWZmZXJlZCcpO1xuICAgIGxpdmVUd2VldHMucHVzaCh0KTtcbiAgfVxuICBpZiAoZGVkdXBlZFNraXBwZWQgPiAwKSB7XG4gICAgYXdhaXQgaW5mbygnZGVkdXA6IHNraXBwZWQgdW5jaGFuZ2VkIHR3ZWV0cycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgc2tpcHBlZDogZGVkdXBlZFNraXBwZWQsXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG4gIGlmIChza2lwcGVkTm9VcGRhdGVMb2NhbCArIHNraXBwZWROb1VwZGF0ZVNuYXBzaG90ID4gMCkge1xuICAgIGNvbnN0IHNraXBwZWRPbGQgPSBza2lwcGVkTm9VcGRhdGVMb2NhbCArIHNraXBwZWROb1VwZGF0ZVNuYXBzaG90O1xuICAgIGF3YWl0IGluZm8oJ2RlZHVwOiBza2lwcGVkIHByZXZpb3VzbHkgYXJjaGl2ZWQgdHdlZXRzICh1cGRhdGVFeGlzdGluZz1mYWxzZSknLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHNraXBwZWQ6IHNraXBwZWRPbGQsXG4gICAgICBsb2NhbF9pbmRleDogc2tpcHBlZE5vVXBkYXRlTG9jYWwsXG4gICAgICBhcmNoaXZlX3NuYXBzaG90OiBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCxcbiAgICAgIHJlbWFpbmluZzogbGl2ZVR3ZWV0cy5sZW5ndGgsXG4gICAgfSk7XG4gICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICBpZiAoYXNTZXNzICE9PSBudWxsKSB7XG4gICAgICBhc1Nlc3Muc2tpcHBlZE9sZENvdW50ID0gKGFzU2Vzcy5za2lwcGVkT2xkQ291bnQgPz8gMCkgKyBza2lwcGVkT2xkO1xuICAgICAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oYXNTZXNzKTtcbiAgICB9XG4gIH1cbiAgaWYgKG9sZEZyb21TbmFwc2hvdCA+IDAgJiYgdXBkYXRlRXhpc3RpbmcpIHtcbiAgICBhd2FpdCBpbmZvKCdhcmNoaXZlIHNuYXBzaG90IHJlY29nbml6ZWQgb2xkIHR3ZWV0cycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgb2xkOiBvbGRGcm9tU25hcHNob3QsXG4gICAgICBhY3Rpb246ICdidWZmZXJpbmcgYmVjYXVzZSB1cGRhdGVFeGlzdGluZz10cnVlJyxcbiAgICAgIHNuYXBzaG90X2dlbmVyYXRlZF9hdDogYXJjaGl2ZVNuYXBzaG90Py5nZW5lcmF0ZWRfYXQgPz8gbnVsbCxcbiAgICB9KTtcbiAgfVxuICBpZiAoZnVsbFRleHRVcGdyYWRlcyA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdkZWR1cDogYnVmZmVyaW5nIGZ1bGwtdGV4dCB1cGdyYWRlcycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgdXBncmFkZXM6IGZ1bGxUZXh0VXBncmFkZXMsXG4gICAgICB1cGRhdGVFeGlzdGluZyxcbiAgICAgIHJlbWFpbmluZzogbGl2ZVR3ZWV0cy5sZW5ndGgsXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgcHJlcGVuZFJlY2VudFR3ZWV0U2lnaHRpbmdzKFxuICAgIG5vcm1hbGl6ZWQudHdlZXRzLm1hcCgodCkgPT5cbiAgICAgIGJ1aWxkVHdlZXRTaWdodGluZyhcbiAgICAgICAgdCxcbiAgICAgICAgZW5kcG9pbnQsXG4gICAgICAgIGNhcHR1cmVkQXQsXG4gICAgICAgIGZyZXNobmVzc0J5SWQuZ2V0KHQudHdlZXRfaWQpLFxuICAgICAgICBhY3Rpb25CeUlkLmdldCh0LnR3ZWV0X2lkKVxuICAgICAgKVxuICAgIClcbiAgKTtcbiAgLy8gLS0tIE1pc3NpbmctcGFyZW50IHJlY292ZXJ5IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gWCdzIFVzZXJUd2VldHNBbmRSZXBsaWVzIGVuZHBvaW50IHNvbWV0aW1lcyBzZXJ2ZXMgYSByZXBseSB3aXRob3V0IHRoZVxuICAvLyBwYXJlbnQgdHdlZXQgaXQgcG9pbnRzIGF0IFx1MjAxNCBvbmx5IGFuIGluX3JlcGx5X3RvX3NjcmVlbl9uYW1lIGFuY2hvci4gV2VcbiAgLy8gbmV2ZXIgc2VlIHRoYXQgcGFyZW50LCBzbyBpdCBuZXZlciBsYW5kcyBpbiB0aGUgYXJjaGl2ZS4gU2FtZSBmb3JcbiAgLy8gcXVvdGVkX3R3ZWV0X2lkIC8gcmV0d2VldGVkX3R3ZWV0X2lkIHdoZW4gWCBzdHJpcHMgdGhlIHJlZmVyZW5jZWRcbiAgLy8gbm9kZS4gV2FsayB0aGUgdHdlZXRzIHdlIGp1c3Qgc2F3LCBmaW5kIGFueSBwYXJlbnQgSUQgd2UgZG9uJ3QgaGF2ZSxcbiAgLy8gYW5kIGVucXVldWUgaXQgb24gdGhlIG1lZGlhLWNyYXdsIGxvb3Agc28gaXRzIGRldGFpbCBwYWdlIGdldHNcbiAgLy8gdmlzaXRlZCBhbmQgaW5nZXN0ZWQgbmV4dCB0aW1lIHRoZSB1c2VyIHN0YXJ0cyB0aGUgY3Jhd2wuXG4gIGF3YWl0IGVucXVldWVNaXNzaW5nUGFyZW50cyhub3JtYWxpemVkLnR3ZWV0cywgZW5kcG9pbnQpO1xuICBhd2FpdCBlbnF1ZXVlVGhyZWFkT3BlbkNhbmRpZGF0ZXMobm9ybWFsaXplZC50d2VldHMsIGNvcmUsIGVuZHBvaW50KTtcbiAgY29uc3QgYnVmZmVyZWRSZXR3ZWV0RWRnZXMgPSBhd2FpdCBidWZmZXJSZXR3ZWV0RWRnZXMoXG4gICAgcmV0d2VldEVkZ2VzLFxuICAgIGNhcHR1cmVkQXQsXG4gICAgcGFnZVVybCA/PyB1cmwsXG4gICAgZW5kcG9pbnRcbiAgKTtcbiAgaWYgKGxpdmVUd2VldHMubGVuZ3RoID09PSAwKSB7XG4gICAgaWYgKGJ1ZmZlcmVkUmV0d2VldEVkZ2VzID4gMCkgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBHcm91cCBzdXJ2aXZpbmcgdHdlZXRzIGJ5IGF1dGhvciBoYW5kbGUuXG4gIGNvbnN0IGJ5SGFuZGxlID0gbmV3IE1hcDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0W10+KCk7XG4gIGZvciAoY29uc3QgdCBvZiBsaXZlVHdlZXRzKSB7XG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUpID8/IFtdO1xuICAgIGFyci5wdXNoKHQpO1xuICAgIGJ5SGFuZGxlLnNldCh0LmFjY291bnRfaGFuZGxlLCBhcnIpO1xuICB9XG5cbiAgZm9yIChjb25zdCBbaGFuZGxlLCB0d2VldHNdIG9mIGJ5SGFuZGxlKSB7XG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgdXJsLCBlbmRwb2ludCk7XG4gICAgbGV0IGFkZGVkID0gMDtcbiAgICBsZXQgYWRkZWROZXcgPSAwO1xuICAgIGxldCBhZGRlZEV4aXN0aW5nID0gMDtcbiAgICBsZXQgdXBkYXRlZEJ1ZmZlcmVkID0gMDtcbiAgICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgICBjb25zdCBleGlzdGluZyA9IGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF07XG4gICAgICBpZiAoZXhpc3RpbmcpIHtcbiAgICAgICAgLy8gUHJlc2VydmUgZmlyc3RfY2FwdHVyZWRfYXQsIGFwcGVuZCBlbmdhZ2VtZW50IHNuYXBzaG90LCByZWZyZXNoXG4gICAgICAgIC8vIGxhc3Rfc2Vlbl9hdCArIGNvdW50cyAodGhlIGxhdGVzdCBzY3JhcGUgd2lucyBmb3IgY291bnRzKS5cbiAgICAgICAgZXhpc3RpbmcubGFzdF9zZWVuX2F0ID0gY2FwdHVyZWRBdDtcbiAgICAgICAgZXhpc3RpbmcubGlrZV9jb3VudCA9IHQubGlrZV9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmV0d2VldF9jb3VudCA9IHQucmV0d2VldF9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucmVwbHlfY291bnQgPSB0LnJlcGx5X2NvdW50O1xuICAgICAgICBleGlzdGluZy5xdW90ZV9jb3VudCA9IHQucXVvdGVfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnZpZXdfY291bnQgPSB0LnZpZXdfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLmJvb2ttYXJrX2NvdW50ID0gdC5ib29rbWFya19jb3VudDtcbiAgICAgICAgY29uc3QgbGFzdCA9IGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeVtleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnkubGVuZ3RoIC0gMV07XG4gICAgICAgIGNvbnN0IHNuYXAgPSB0LmVuZ2FnZW1lbnRfaGlzdG9yeVswXTtcbiAgICAgICAgaWYgKHNuYXAgJiYgKCFsYXN0IHx8IGxhc3QuY2FwdHVyZWRfYXQgIT09IHNuYXAuY2FwdHVyZWRfYXQpKSB7XG4gICAgICAgICAgZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5LnB1c2goc25hcCk7XG4gICAgICAgIH1cbiAgICAgICAgdXBkYXRlZEJ1ZmZlcmVkICs9IDE7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBzdGFtcGVkOiBDYW5vbmljYWxUd2VldCA9IHsgLi4udCwgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQgfTtcbiAgICAgICAgYnVmLnR3ZWV0c19ieV9pZFt0LnR3ZWV0X2lkXSA9IHN0YW1wZWQ7XG4gICAgICAgIGFkZGVkICs9IDE7XG4gICAgICAgIGlmIChmcmVzaG5lc3NCeUlkLmdldCh0LnR3ZWV0X2lkKSA9PT0gJ2V4aXN0aW5nJykgYWRkZWRFeGlzdGluZyArPSAxO1xuICAgICAgICBlbHNlIGFkZGVkTmV3ICs9IDE7XG4gICAgICB9XG4gICAgICBpZiAoIWJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQuaW5jbHVkZXModC50d2VldF9pZCkpIHtcbiAgICAgICAgYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5wdXNoKHQudHdlZXRfaWQpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIWJ1Zi5lbmRwb2ludHNfc2Vlbi5pbmNsdWRlcyhlbmRwb2ludCkpIGJ1Zi5lbmRwb2ludHNfc2Vlbi5wdXNoKGVuZHBvaW50KTtcbiAgICBidWYubGFzdF9jYXB0dXJlX2F0ID0gY2FwdHVyZWRBdDtcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICAgIGF3YWl0IHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlLCBydW5CdWZmZXJJdGVtQ291bnQoYnVmKSk7XG4gICAgaWYgKGFkZGVkID4gMCB8fCB1cGRhdGVkQnVmZmVyZWQgPiAwKSB7XG4gICAgICBhd2FpdCBpbmZvKCdidWZmZXJlZCB0d2VldHMnLCB7XG4gICAgICAgIGhhbmRsZSxcbiAgICAgICAgZW5kcG9pbnQsXG4gICAgICAgIGFkZGVkLFxuICAgICAgICBuZXc6IGFkZGVkTmV3LFxuICAgICAgICBleGlzdGluZzogYWRkZWRFeGlzdGluZyxcbiAgICAgICAgdXBkYXRlZF9idWZmZXJlZDogdXBkYXRlZEJ1ZmZlcmVkLFxuICAgICAgICB0b3RhbDogT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoLFxuICAgICAgfSk7XG4gICAgICAvLyBCdW1wIHRoZSBhdXRvLXNjcm9sbCBwcm9ncmVzcyBzbyB0aGUgdXNlciBzZWVzIFwiWCBpbmdlc3RlZFwiIHRpY2sgdXBcbiAgICAgIC8vIGluIHJlYWwgdGltZS4gV2UgY291bnQgYWN0dWFsbHktbmV3IHR3ZWV0cywgbm90IGR1cGxpY2F0ZXMuXG4gICAgICBjb25zdCBhc1Nlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xuICAgICAgICBhc1Nlc3MuaW5nZXN0ZWRDb3VudCArPSBhZGRlZDtcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkTmV3Q291bnQgPSAoYXNTZXNzLmluZ2VzdGVkTmV3Q291bnQgPz8gMCkgKyBhZGRlZE5ldztcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkRXhpc3RpbmdDb3VudCA9IChhc1Nlc3MuaW5nZXN0ZWRFeGlzdGluZ0NvdW50ID8/IDApICsgYWRkZWRFeGlzdGluZztcbiAgICAgICAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oYXNTZXNzKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCA+PSBGTFVTSF9UV0VFVF9USFJFU0hPTEQpIHtcbiAgICAgIGF3YWl0IGZsdXNoSGFuZGxlKGhhbmRsZSwgJ3RocmVzaG9sZCcpO1xuICAgIH1cbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWNvcmRVbmF2YWlsYWJsZVR3ZWV0cyhcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXSxcbiAgdHJhY2tlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPixcbiAgY2FwdHVyZWRBdDogc3RyaW5nLFxuICBzb3VyY2VVcmw6IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZ1xuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGNvbW1pdHRlZElkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGNvbnN0IHJlZmV0Y2hTZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBjb25zdCB0aHJlYWRPcGVuU2VzcyA9IGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCk7XG4gIGxldCByZWNvcmRlZCA9IDA7XG4gIGxldCBza2lwcGVkID0gMDtcbiAgbGV0IG1pc3NpbmdIYW5kbGUgPSAwO1xuXG4gIGZvciAoY29uc3QgdSBvZiB1bmF2YWlsYWJsZVR3ZWV0cykge1xuICAgIGNvbnN0IGhhbmRsZSA9IHUuYWNjb3VudF9oYW5kbGU7XG4gICAgaWYgKCFoYW5kbGUpIHtcbiAgICAgIG1pc3NpbmdIYW5kbGUgKz0gMTtcbiAgICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHUudHdlZXRfaWQpO1xuICAgICAgYXdhaXQgZGVxdWV1ZVRocmVhZE9wZW4odS50d2VldF9pZCk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKHRyYWNrZWQuc2l6ZSA+IDAgJiYgIXRyYWNrZWQuaGFzKGhhbmRsZS50b0xvd2VyQ2FzZSgpKSkge1xuICAgICAgc2tpcHBlZCArPSAxO1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodS50d2VldF9pZCk7XG4gICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2goaGFuZGxlLCB1LnR3ZWV0X2lkKTtcbiAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih1LnR3ZWV0X2lkKTtcbiAgICBpZiAocmVmZXRjaFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB1LnR3ZWV0X2lkKSB7XG4gICAgICByZWZldGNoU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICByZWZldGNoU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHJlZmV0Y2hTZXNzKTtcbiAgICB9XG4gICAgaWYgKG1lZGlhQ3Jhd2xTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdS50d2VldF9pZCkge1xuICAgICAgbWVkaWFDcmF3bFNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgICAgbWVkaWFDcmF3bFNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihtZWRpYUNyYXdsU2Vzcyk7XG4gICAgfVxuICAgIGlmICh0aHJlYWRPcGVuU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHUudHdlZXRfaWQpIHtcbiAgICAgIHRocmVhZE9wZW5TZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIHRocmVhZE9wZW5TZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgbWFya1RocmVhZE9wZW5TZWVuKHUudHdlZXRfaWQpO1xuICAgICAgYXdhaXQgc2V0VGhyZWFkT3BlblNlc3Npb24odGhyZWFkT3BlblNlc3MpO1xuICAgIH1cblxuICAgIGNvbnN0IHNpZyA9IHVuYXZhaWxhYmxlU2lnKHUpO1xuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbaGFuZGxlXT8uW3UudHdlZXRfaWRdO1xuICAgIGlmIChwcmV2Py5zaWcgPT09IHNpZykge1xuICAgICAgc2tpcHBlZCArPSAxO1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgc291cmNlVXJsLCBlbmRwb2ludCk7XG4gICAgY29uc3QgdW5hdmFpbGFibGVCeUlkID0gYnVmLnVuYXZhaWxhYmxlX2J5X2lkID8/IHt9O1xuICAgIHVuYXZhaWxhYmxlQnlJZFt1LnR3ZWV0X2lkXSA9IHU7XG4gICAgYnVmLnVuYXZhaWxhYmxlX2J5X2lkID0gdW5hdmFpbGFibGVCeUlkO1xuICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyh1LnR3ZWV0X2lkKSkge1xuICAgICAgYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5wdXNoKHUudHdlZXRfaWQpO1xuICAgIH1cbiAgICBpZiAoIWJ1Zi5lbmRwb2ludHNfc2Vlbi5pbmNsdWRlcyhlbmRwb2ludCkpIGJ1Zi5lbmRwb2ludHNfc2Vlbi5wdXNoKGVuZHBvaW50KTtcbiAgICBidWYubGFzdF9jYXB0dXJlX2F0ID0gY2FwdHVyZWRBdDtcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICAgIGF3YWl0IHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlLCBydW5CdWZmZXJJdGVtQ291bnQoYnVmKSk7XG4gICAgcmVjb3JkZWQgKz0gMTtcbiAgfVxuXG4gIGlmIChyZWNvcmRlZCA+IDAgfHwgbWlzc2luZ0hhbmRsZSA+IDAgfHwgc2tpcHBlZCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCd1bmF2YWlsYWJsZSB0d2VldHMgb2JzZXJ2ZWQnLCB7IGVuZHBvaW50LCByZWNvcmRlZCwgc2tpcHBlZCwgbWlzc2luZ0hhbmRsZSB9KTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5mdW5jdGlvbiB1bmF2YWlsYWJsZVNpZyh1OiBVbmF2YWlsYWJsZVR3ZWV0KTogc3RyaW5nIHtcbiAgcmV0dXJuIGB1bmF2YWlsYWJsZXwke3UudW5hdmFpbGFibGVfcmVhc29uID8/ICcnfXwke3UudW5hdmFpbGFibGVfdGV4dCA/PyAnJ31gO1xufVxuXG5mdW5jdGlvbiBzaWdNYXJrc1RydW5jYXRlZChzaWc6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCBwYXJ0cyA9IHNpZy5zcGxpdCgnfCcpO1xuICByZXR1cm4gcGFydHNbcGFydHMubGVuZ3RoIC0gMV0gPT09ICd0Jztcbn1cblxuZnVuY3Rpb24gcnVuQnVmZmVySXRlbUNvdW50KGJ1ZjogUnVuQnVmZmVyKTogbnVtYmVyIHtcbiAgcmV0dXJuIChcbiAgICBPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggK1xuICAgIE9iamVjdC5rZXlzKGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fSkubGVuZ3RoICtcbiAgICBPYmplY3Qua2V5cyhidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge30pLmxlbmd0aFxuICApO1xufVxuXG5mdW5jdGlvbiByZXR3ZWV0RWRnZUtleShlZGdlOiBSZXR3ZWV0RWRnZSk6IHN0cmluZyB7XG4gIHJldHVybiBbZWRnZS5yZXR3ZWV0ZXJfaGFuZGxlLnRvTG93ZXJDYXNlKCksIGVkZ2UucmV0d2VldF90d2VldF9pZCwgZWRnZS5vcmlnaW5hbF90d2VldF9pZF0uam9pbihcbiAgICAnfCdcbiAgKTtcbn1cblxuZnVuY3Rpb24gaW5mZXJSZXR3ZWV0ZWRIYW5kbGUodGV4dDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIGNvbnN0IG1hdGNoID0gdGV4dC5tYXRjaCgvXlJUXFxzK0AoW0EtWmEtejAtOV9dezEsMTV9KVxcYi9pKTtcbiAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gbnVsbDtcbn1cblxuZnVuY3Rpb24gYnVpbGRSZXR3ZWV0RWRnZXMoXG4gIHR3ZWV0czogUmVhZG9ubHlBcnJheTxDYW5vbmljYWxUd2VldD4sXG4gIGFjY291bnRzOiBSZWFkb25seUFycmF5PHsgaGFuZGxlOiBzdHJpbmc7IGNhdGVnb3J5OiBzdHJpbmcgfT4sXG4gIGNhcHR1cmVkQXQ6IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcgfCBudWxsXG4pOiBSZXR3ZWV0RWRnZVtdIHtcbiAgY29uc3QgY2F0ZWdvcnlCeUhhbmRsZSA9IG5ldyBNYXAoYWNjb3VudHMubWFwKChhKSA9PiBbYS5oYW5kbGUudG9Mb3dlckNhc2UoKSwgYS5jYXRlZ29yeV0pKTtcbiAgY29uc3QgYnlJZCA9IG5ldyBNYXAodHdlZXRzLm1hcCgodCkgPT4gW3QudHdlZXRfaWQsIHRdKSk7XG4gIGNvbnN0IG91dCA9IG5ldyBNYXA8c3RyaW5nLCBSZXR3ZWV0RWRnZT4oKTtcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgIGlmICh0LnR3ZWV0X3R5cGUgIT09ICdyZXR3ZWV0JyB8fCAhdC5yZXR3ZWV0ZWRfdHdlZXRfaWQpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHJldHdlZXRlckNhdGVnb3J5ID0gY2F0ZWdvcnlCeUhhbmRsZS5nZXQodC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpKTtcbiAgICBpZiAoIXJldHdlZXRlckNhdGVnb3J5KSBjb250aW51ZTtcbiAgICBjb25zdCBvcmlnaW5hbCA9IGJ5SWQuZ2V0KHQucmV0d2VldGVkX3R3ZWV0X2lkKTtcbiAgICBjb25zdCBvcmlnaW5hbEhhbmRsZSA9XG4gICAgICBvcmlnaW5hbD8uYWNjb3VudF9oYW5kbGUgPz8gaW5mZXJSZXR3ZWV0ZWRIYW5kbGUodC50ZXh0X3Jlc29sdmVkIHx8IHQudGV4dCk7XG4gICAgY29uc3Qgb3JpZ2luYWxDYXRlZ29yeSA9IG9yaWdpbmFsSGFuZGxlXG4gICAgICA/IChjYXRlZ29yeUJ5SGFuZGxlLmdldChvcmlnaW5hbEhhbmRsZS50b0xvd2VyQ2FzZSgpKSA/PyAncHVibGljJylcbiAgICAgIDogbnVsbDtcbiAgICBjb25zdCBlZGdlOiBSZXR3ZWV0RWRnZSA9IHtcbiAgICAgIHJldHdlZXRlcl9oYW5kbGU6IHQuYWNjb3VudF9oYW5kbGUsXG4gICAgICByZXR3ZWV0ZXJfYWNjb3VudF9pZDogdC5hY2NvdW50X2lkID8/IG51bGwsXG4gICAgICByZXR3ZWV0ZXJfY2F0ZWdvcnk6IHJldHdlZXRlckNhdGVnb3J5LFxuICAgICAgcmV0d2VldF90d2VldF9pZDogdC50d2VldF9pZCxcbiAgICAgIHJldHdlZXRfdXJsOiB0LnR3ZWV0X3VybCxcbiAgICAgIG9yaWdpbmFsX3R3ZWV0X2lkOiB0LnJldHdlZXRlZF90d2VldF9pZCxcbiAgICAgIG9yaWdpbmFsX2F1dGhvcl9oYW5kbGU6IG9yaWdpbmFsSGFuZGxlLFxuICAgICAgb3JpZ2luYWxfYXV0aG9yX2FjY291bnRfaWQ6IG9yaWdpbmFsPy5hY2NvdW50X2lkID8/IG51bGwsXG4gICAgICBvcmlnaW5hbF9hdXRob3JfY2F0ZWdvcnk6IG9yaWdpbmFsQ2F0ZWdvcnksXG4gICAgICBjYXB0dXJlZF9hdDogY2FwdHVyZWRBdCxcbiAgICAgIGNhcHR1cmVfcnVuX2lkOiAncGVuZGluZycsXG4gICAgICBlbmRwb2ludCxcbiAgICAgIHNvdXJjZV91cmw6IHNvdXJjZVVybCxcbiAgICB9O1xuICAgIG91dC5zZXQocmV0d2VldEVkZ2VLZXkoZWRnZSksIGVkZ2UpO1xuICB9XG4gIHJldHVybiBbLi4ub3V0LnZhbHVlcygpXTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYnVmZmVyUmV0d2VldEVkZ2VzKFxuICBlZGdlczogUmVhZG9ubHlBcnJheTxSZXR3ZWV0RWRnZT4sXG4gIGNhcHR1cmVkQXQ6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8bnVtYmVyPiB7XG4gIGlmIChlZGdlcy5sZW5ndGggPT09IDApIHJldHVybiAwO1xuICBjb25zdCBieUhhbmRsZSA9IG5ldyBNYXA8c3RyaW5nLCBSZXR3ZWV0RWRnZVtdPigpO1xuICBmb3IgKGNvbnN0IGVkZ2Ugb2YgZWRnZXMpIHtcbiAgICBjb25zdCBhcnIgPSBieUhhbmRsZS5nZXQoZWRnZS5yZXR3ZWV0ZXJfaGFuZGxlKSA/PyBbXTtcbiAgICBhcnIucHVzaChlZGdlKTtcbiAgICBieUhhbmRsZS5zZXQoZWRnZS5yZXR3ZWV0ZXJfaGFuZGxlLCBhcnIpO1xuICB9XG4gIGxldCBhZGRlZCA9IDA7XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgaGFuZGxlRWRnZXNdIG9mIGJ5SGFuZGxlKSB7XG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgc291cmNlVXJsLCBlbmRwb2ludCk7XG4gICAgY29uc3QgZWRnZU1hcCA9IGJ1Zi5yZXR3ZWV0X2VkZ2VzX2J5X2tleSA/PyB7fTtcbiAgICBsZXQgYWRkZWRGb3JIYW5kbGUgPSAwO1xuICAgIGZvciAoY29uc3QgZWRnZSBvZiBoYW5kbGVFZGdlcykge1xuICAgICAgY29uc3Qgc3RhbXBlZDogUmV0d2VldEVkZ2UgPSB7IC4uLmVkZ2UsIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkIH07XG4gICAgICBjb25zdCBrZXkgPSByZXR3ZWV0RWRnZUtleShzdGFtcGVkKTtcbiAgICAgIGlmICghZWRnZU1hcFtrZXldKSBhZGRlZEZvckhhbmRsZSArPSAxO1xuICAgICAgZWRnZU1hcFtrZXldID0gc3RhbXBlZDtcbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyhzdGFtcGVkLnJldHdlZXRfdHdlZXRfaWQpKSB7XG4gICAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaChzdGFtcGVkLnJldHdlZXRfdHdlZXRfaWQpO1xuICAgICAgfVxuICAgICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHN0YW1wZWQub3JpZ2luYWxfdHdlZXRfaWQpKSB7XG4gICAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaChzdGFtcGVkLm9yaWdpbmFsX3R3ZWV0X2lkKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGFkZGVkRm9ySGFuZGxlID09PSAwKSBjb250aW51ZTtcbiAgICBidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPSBlZGdlTWFwO1xuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xuICAgIGJ1Zi5sYXN0X2NhcHR1cmVfYXQgPSBjYXB0dXJlZEF0O1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIHJ1bkJ1ZmZlckl0ZW1Db3VudChidWYpKTtcbiAgICBhZGRlZCArPSBhZGRlZEZvckhhbmRsZTtcbiAgICBhd2FpdCBpbmZvKCdidWZmZXJlZCByZXR3ZWV0IGVkZ2VzJywge1xuICAgICAgaGFuZGxlLFxuICAgICAgZW5kcG9pbnQsXG4gICAgICBhZGRlZDogYWRkZWRGb3JIYW5kbGUsXG4gICAgICB0b3RhbDogT2JqZWN0LmtleXMoZWRnZU1hcCkubGVuZ3RoLFxuICAgIH0pO1xuICB9XG4gIHJldHVybiBhZGRlZDtcbn1cblxuLyoqXG4gKiBGaW5kIGV2ZXJ5IHBhcmVudCB0d2VldCByZWZlcmVuY2VkIGJ5IHRoZSBjYXB0dXJlcyB3ZSBqdXN0IGluZ2VzdGVkXG4gKiAoYHJlcGx5X3RvX3R3ZWV0X2lkYCwgYHF1b3RlZF90d2VldF9pZGAsIGByZXR3ZWV0ZWRfdHdlZXRfaWRgKSB0aGF0IHdlXG4gKiBkb24ndCB5ZXQgaGF2ZSBpbiB0aGUgYXJjaGl2ZSwgYW5kIGVucXVldWUgaXQgb24gdGhlIG1lZGlhLWNyYXdsIGxvb3AuXG4gKlxuICogV2h5OiBYJ3MgVXNlclR3ZWV0c0FuZFJlcGxpZXMgZW5kcG9pbnQgc29tZXRpbWVzIHJldHVybnMgYSB0cmFja2VkXG4gKiBhY2NvdW50J3MgcmVwbHkgKndpdGhvdXQqIHRoZSBwYXJlbnQgaXQgcG9pbnRzIGF0LiBUaGUgYHJlcGx5X3RvXypgXG4gKiBmaWVsZHMgb24gdGhlIHJlcGx5IHN0aWxsIGdldCBzZXQgZnJvbSBgaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0cmAsIGJ1dFxuICogYGZpbHRlclJlbGF0ZWRgIGhhcyBub3RoaW5nIHRvIGtlZXAgXHUyMDE0IHRoZXJlIGlzIG5vIHBhcmVudCBub2RlIGluIHRoZVxuICogYmF0Y2ggdG8ga2VlcC4gUmVzdWx0OiB0aGUgYXJjaGl2ZSBzaG93cyBESFNnb3YncyByZXBseSBidXQgbm90IHRoZVxuICogb3JpZ2luYWwgaXQncyByZXBseWluZyB0by4gU3ltbWV0cmljIHByb2JsZW0gZm9yIG9ycGhhbmVkIHF1b3RlIC8gUlRcbiAqIHBvaW50ZXJzLlxuICpcbiAqIFJldXNpbmcgdGhlIG1lZGlhLWNyYXdsIHF1ZXVlICsgbG9vcCBtZWFucyBubyBuZXcgVUk7IHRoZSB1c2VyIGFscmVhZHlcbiAqIHN0YXJ0cyBpdCBtYW51YWxseSB3aGVuIHRoZXkgd2FudCB0byBmZXRjaCBwYXJ0aWFsLWNhcHR1cmVkIHR3ZWV0cy5cbiAqIFNhbWUgZGVkdXAgcnVsZXMgYXBwbHkgKGNvbW1pdHRlZCBcdTIxOTIgc2tpcDsgYWxyZWFkeSBxdWV1ZWQgXHUyMTkyIG5vLW9wKS5cbiAqXG4gKiBXZSBvbmx5IHdhbGsgdGhlIHR3ZWV0cyB0aGF0IHN1cnZpdmVkIGBmaWx0ZXJSZWxhdGVkYCBzbyB3ZSBkb24ndCBjcmF3bFxuICogcGFyZW50cyBvZiByYW5kb20gcmVwbGllcyB0aGF0IHdvdWxkbid0IGhhdmUgYmVlbiBrZXB0IGFueXdheS5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZU1pc3NpbmdQYXJlbnRzKFxuICB0d2VldHM6IFJlYWRvbmx5QXJyYXk8Q2Fub25pY2FsVHdlZXQ+LFxuICBlbmRwb2ludDogc3RyaW5nXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgLy8gQnVpbGQgYSBzYW1lLWJhdGNoIElEIHNldCBzbyB3ZSBkb24ndCBlbnF1ZXVlIGEgcGFyZW50IHRoYXQgYWxyZWFkeVxuICAvLyBhcnJpdmVkIGluIHRoaXMgdmVyeSByZXNwb25zZS5cbiAgY29uc3Qgc2FtZUJhdGNoSWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHNhbWVCYXRjaElkcy5hZGQodC50d2VldF9pZCk7XG5cbiAgbGV0IGVucXVldWVkID0gMDtcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgIGNvbnN0IHBhcmVudHM6IEFycmF5PHsgaWQ6IHN0cmluZzsgaGludDogc3RyaW5nIHwgbnVsbCB9PiA9IFtdO1xuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkKSB7XG4gICAgICBwYXJlbnRzLnB1c2goeyBpZDogdC5yZXBseV90b190d2VldF9pZCwgaGludDogdC5yZXBseV90b19hY2NvdW50IH0pO1xuICAgIH1cbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQpIHBhcmVudHMucHVzaCh7IGlkOiB0LnF1b3RlZF90d2VldF9pZCwgaGludDogbnVsbCB9KTtcbiAgICBpZiAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpIHBhcmVudHMucHVzaCh7IGlkOiB0LnJldHdlZXRlZF90d2VldF9pZCwgaGludDogbnVsbCB9KTtcbiAgICBmb3IgKGNvbnN0IHAgb2YgcGFyZW50cykge1xuICAgICAgaWYgKHNhbWVCYXRjaElkcy5oYXMocC5pZCkpIGNvbnRpbnVlO1xuICAgICAgaWYgKGF3YWl0IGlzQ29tbWl0dGVkKHAuaWQpKSBjb250aW51ZTtcbiAgICAgIGF3YWl0IGVucXVldWVNZWRpYUNyYXdsKHAuaGludCwgcC5pZCk7XG4gICAgICBlbnF1ZXVlZCArPSAxO1xuICAgIH1cbiAgfVxuICBpZiAoZW5xdWV1ZWQgPiAwKSB7XG4gICAgYXdhaXQgaW5mbygncXVldWVkIG1pc3NpbmcgcGFyZW50IHR3ZWV0cyBmb3IgZGV0YWlsLXBhZ2UgY3Jhd2wnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIGVucXVldWVkLFxuICAgICAgcXVldWVfdG90YWw6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXG4gICAgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVRocmVhZE9wZW5DYW5kaWRhdGVzKFxuICB0d2VldHM6IFJlYWRvbmx5QXJyYXk8Q2Fub25pY2FsVHdlZXQ+LFxuICBjb3JlSGFuZGxlczogUmVhZG9ubHlTZXQ8c3RyaW5nPixcbiAgZW5kcG9pbnQ6IHN0cmluZ1xuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmICh0d2VldHMubGVuZ3RoID09PSAwIHx8IGNvcmVIYW5kbGVzLnNpemUgPT09IDApIHJldHVybjtcbiAgaWYgKGVuZHBvaW50LmluY2x1ZGVzKCdUd2VldERldGFpbCcpIHx8IGVuZHBvaW50LmluY2x1ZGVzKCdUd2VldFJlc3VsdEJ5UmVzdElkJykpIHJldHVybjtcblxuICBjb25zdCBjYW5kaWRhdGVzID0gbmV3IE1hcDxzdHJpbmcsIHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgIGNvbnN0IGhhbmRsZSA9IHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoIWNvcmVIYW5kbGVzLmhhcyhoYW5kbGUpKSBjb250aW51ZTtcblxuICAgIGNvbnN0IHJvb3RJZCA9IHQuY29udmVyc2F0aW9uX2lkID8/IHQudHdlZXRfaWQ7XG4gICAgY29uc3QgaXNSb290ID0gcm9vdElkID09PSB0LnR3ZWV0X2lkIHx8IHQucmVwbHlfdG9fdHdlZXRfaWQgPT09IG51bGw7XG4gICAgY29uc3QgaXNDb3JlUmVwbHkgPSB0LnJlcGx5X3RvX3R3ZWV0X2lkICE9PSBudWxsO1xuICAgIGlmIChpc1Jvb3QgJiYgdC5yZXBseV9jb3VudCA+IDApIHtcbiAgICAgIGNhbmRpZGF0ZXMuc2V0KHJvb3RJZCwgdC5hY2NvdW50X2hhbmRsZSk7XG4gICAgfSBlbHNlIGlmIChpc0NvcmVSZXBseSAmJiByb290SWQpIHtcbiAgICAgIGNhbmRpZGF0ZXMuc2V0KHJvb3RJZCwgdC5hY2NvdW50X2hhbmRsZSk7XG4gICAgfVxuICB9XG5cbiAgbGV0IGVucXVldWVkID0gMDtcbiAgZm9yIChjb25zdCBbdHdlZXRJZCwgaGFuZGxlXSBvZiBjYW5kaWRhdGVzKSB7XG4gICAgY29uc3QgYmVmb3JlID0gYXdhaXQgdGhyZWFkT3BlblF1ZXVlVG90YWwoKTtcbiAgICBhd2FpdCBlbnF1ZXVlVGhyZWFkT3BlbihoYW5kbGUsIHR3ZWV0SWQpO1xuICAgIGNvbnN0IGFmdGVyID0gYXdhaXQgdGhyZWFkT3BlblF1ZXVlVG90YWwoKTtcbiAgICBpZiAoYWZ0ZXIgPiBiZWZvcmUpIGVucXVldWVkICs9IDE7XG4gIH1cbiAgaWYgKGVucXVldWVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ3F1ZXVlZCBjb3JlIHRocmVhZCByb290cyBmb3Igb3BlbmluZycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgZW5xdWV1ZWQsXG4gICAgICBxdWV1ZV90b3RhbDogYXdhaXQgdGhyZWFkT3BlblF1ZXVlVG90YWwoKSxcbiAgICB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVSdW5CdWZmZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICB0czogc3RyaW5nLFxuICBzb3VyY2VVcmw6IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZ1xuKTogUHJvbWlzZTxSdW5CdWZmZXI+IHtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSk7XG4gIGlmIChjdXIpIHJldHVybiBjdXI7XG4gIGNvbnN0IGJ1ZjogUnVuQnVmZmVyID0ge1xuICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcbiAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgIHN0YXJ0ZWRfYXQ6IHRzLFxuICAgIGxhc3RfY2FwdHVyZV9hdDogdHMsXG4gICAgdHdlZXRzX2J5X2lkOiB7fSxcbiAgICB1bmF2YWlsYWJsZV9ieV9pZDoge30sXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcbiAgICBlbmRwb2ludHNfc2VlbjogW2VuZHBvaW50XSxcbiAgICBzb3VyY2VfdXJsOiBzb3VyY2VVcmwsXG4gIH07XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIGJ1Zik7XG4gIGF3YWl0IGluZm8oJ3J1biBzdGFydGVkJywgeyBoYW5kbGUsIHJ1bjogc2hvcnRSdW5JZChidWYucnVuX2lkKSB9KTtcbiAgcmV0dXJuIGJ1Zjtcbn1cblxuLy8gLS0tIEZsdXNoIGxvZ2ljIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxubGV0IGZsdXNoQ2hhaW46IFByb21pc2U8dm9pZD4gPSBQcm9taXNlLnJlc29sdmUoKTtcblxuaW50ZXJmYWNlIEZsdXNoSXRlbSB7XG4gIGhhbmRsZTogc3RyaW5nO1xuICBidWY6IFJ1bkJ1ZmZlcjtcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdO1xuICB1bmF2YWlsYWJsZVR3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdO1xuICByZXR3ZWV0RWRnZXM6IFJldHdlZXRFZGdlW107XG4gIHJhd1BhdGg6IHN0cmluZztcbiAgc2VlblBhdGg6IHN0cmluZztcbiAgY2FwdHVyZTogQ2FwdHVyZVBheWxvYWQ7XG4gIHNlZW46IFNlZW5QYXlsb2FkO1xuICBkYXk6IHN0cmluZztcbiAgcnVuU2hvcnQ6IHN0cmluZztcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hJZGxlQnVmZmVycygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBjb25zdCBoYW5kbGVzOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XG4gICAgICBoYW5kbGVzLnB1c2goaGFuZGxlKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgZmx1c2hIYW5kbGVzKGhhbmRsZXMsICdpZGxlJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoT3JwaGFuZWRCdWZmZXJzSWZTdGFsZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gT24gd29ya2VyIHdha2UsIGFueSBidWZmZXIgb2xkZXIgdGhhbiB0aGUgaWRsZSB0aHJlc2hvbGQgZ2V0cyBhIGNoYW5jZSB0b1xuICAvLyBjb21taXQgaW1tZWRpYXRlbHkgXHUyMDE0IHVzZWZ1bCB3aGVuIHRoZSB3b3JrZXIgd2FzIGV2aWN0ZWQgYmVmb3JlIGlkbGUtZmx1c2guXG4gIC8vIElmIHRoZSBQQVQvb3duZXIvcmVwbyBhcmVuJ3Qgc2V0IHdlJ2QganVzdCBlbWl0IFwiZmx1c2ggZGVmZXJyZWRcIiBmb3IgZXZlcnlcbiAgLy8gc2luZ2xlIGhhbmRsZSBpbiBzdG9yYWdlICh0aGUgZGlhZ25vc3RpYyBzaG93ZWQgdGhpcyBmaXJpbmcgMzAwKyB0aW1lcyBpblxuICAvLyBhIHJvdyB3aGVuIHRoZSBleHRlbnNpb24gd29rZSBiZWZvcmUgc2V0dGluZ3MgbG9hZCksIHNvIHNob3J0LWNpcmN1aXRcbiAgLy8gaGVyZSBpbnN0ZWFkLlxuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykgcmV0dXJuO1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gIGNvbnN0IGhhbmRsZXM6IHN0cmluZ1tdID0gW107XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgYnVmXSBvZiBPYmplY3QuZW50cmllcyhhbGwpKSB7XG4gICAgY29uc3QgbGFzdCA9IERhdGUucGFyc2UoYnVmLmxhc3RfY2FwdHVyZV9hdCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShsYXN0KSAmJiBub3cgLSBsYXN0ID49IEZMVVNIX0lETEVfTVMpIHtcbiAgICAgIGhhbmRsZXMucHVzaChoYW5kbGUpO1xuICAgIH1cbiAgfVxuICBhd2FpdCBmbHVzaEhhbmRsZXMoaGFuZGxlcywgJ3dha2UnKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hBbGwocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBhd2FpdCBmbHVzaEhhbmRsZXMoT2JqZWN0LmtleXMoYWxsKSwgcmVhc29uKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGUoaGFuZGxlOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhbaGFuZGxlXSwgcmVhc29uKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGVzKGhhbmRsZXM6IHN0cmluZ1tdLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCB1bmlxdWUgPSBbLi4ubmV3IFNldChoYW5kbGVzKV0uZmlsdGVyKChoKSA9PiBoLmxlbmd0aCA+IDApO1xuICBpZiAodW5pcXVlLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBjb25zdCBydW4gPSBmbHVzaENoYWluLnRoZW4oKCkgPT4gZmx1c2hIYW5kbGVzTG9ja2VkKHVuaXF1ZSwgcmVhc29uKSk7XG4gIGZsdXNoQ2hhaW4gPSBydW4uY2F0Y2goKCkgPT4ge30pO1xuICByZXR1cm4gcnVuO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaEhhbmRsZXNMb2NrZWQoaGFuZGxlczogc3RyaW5nW10sIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3QgaXRlbXM6IEZsdXNoSXRlbVtdID0gW107XG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIGhhbmRsZXMpIHtcbiAgICBjb25zdCBidWYgPSBhbGxbaGFuZGxlXTtcbiAgICBpZiAoIWJ1ZikgY29udGludWU7XG4gICAgY29uc3QgdHdlZXRzID0gT2JqZWN0LnZhbHVlcyhidWYudHdlZXRzX2J5X2lkKTtcbiAgICBjb25zdCB1bmF2YWlsYWJsZVR3ZWV0cyA9IE9iamVjdC52YWx1ZXMoYnVmLnVuYXZhaWxhYmxlX2J5X2lkID8/IHt9KTtcbiAgICBjb25zdCByZXR3ZWV0RWRnZXMgPSBPYmplY3QudmFsdWVzKGJ1Zi5yZXR3ZWV0X2VkZ2VzX2J5X2tleSA/PyB7fSk7XG4gICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDAgJiYgdW5hdmFpbGFibGVUd2VldHMubGVuZ3RoID09PSAwICYmIHJldHdlZXRFZGdlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIGF3YWl0IGNsZWFyUnVuQnVmZmVyKGhhbmRsZSk7XG4gICAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgMCk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaXRlbXMucHVzaChidWlsZEZsdXNoSXRlbShoYW5kbGUsIGJ1ZiwgdHdlZXRzLCB1bmF2YWlsYWJsZVR3ZWV0cywgcmV0d2VldEVkZ2VzKSk7XG4gIH1cbiAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSB7XG4gICAgYXdhaXQgd2FybigndXBsb2FkIGJ1ZmZlciBkZWZlcnJlZDogc2V0dGluZ3MgaW5jb21wbGV0ZScsIHtcbiAgICAgIGNvdW50OiBpdGVtcy5sZW5ndGgsXG4gICAgICBoYW5kbGVzOiBpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uaGFuZGxlKS5zbGljZSgwLCAyMCksXG4gICAgfSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICBjb25zdCBmaWxlcyA9IGl0ZW1zLmZsYXRNYXAoKGl0ZW0pID0+IFtcbiAgICB7XG4gICAgICBwYXRoOiBpdGVtLnJhd1BhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShpdGVtLmNhcHR1cmUsIG51bGwsIDIpICsgJ1xcbicpLFxuICAgIH0sXG4gICAge1xuICAgICAgcGF0aDogaXRlbS5zZWVuUGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KGl0ZW0uc2VlbiwgbnVsbCwgMikgKyAnXFxuJyksXG4gICAgfSxcbiAgXSk7XG4gIGNvbnN0IGNvbW1pdE1zZyA9IGJ1aWxkQmF0Y2hDb21taXRNZXNzYWdlKGl0ZW1zKTtcblxuICB0cnkge1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNsaWVudC5jb21taXRGaWxlcyh7XG4gICAgICBmaWxlcyxcbiAgICAgIG1lc3NhZ2U6IGNvbW1pdE1zZyxcbiAgICB9KTtcbiAgICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xuICAgICAgY29uc3QgcmVtYWluaW5nQ291bnQgPSBhd2FpdCBjbGVhckNvbW1pdHRlZFR3ZWV0c0Zyb21CdWZmZXIoaXRlbSk7XG4gICAgICAvLyBDb3VudGVyIGJ1bXA6IGFjdHVhbGx5IElOQ1JFTUVOVCB0b2RheUNvdW50IGFuZCB0b3RhbENvbW1pdHRlZCBieVxuICAgICAgLy8gdGhlIG51bWJlciBvZiB0d2VldHMgd2UganVzdCBwZXJzaXN0ZWQgKHRoZSBwcmV2aW91cyBjb2RlIHJlYWQgdGhlXG4gICAgICAvLyBleGlzdGluZyB2YWx1ZXMgYW5kIHdyb3RlIHRoZW0gYmFjaywgbGVhdmluZyB0aGUgY291bnRlciBwZWdnZWQgYXRcbiAgICAgIC8vIHplcm8pLlxuICAgICAgY29uc3QgcHJldiA9IChhd2FpdCBnZXRDb3VudGVycygpKVtpdGVtLmhhbmRsZV07XG4gICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG4gICAgICBjb25zdCBjYXJyaWVkVG9kYXkgPSBwcmV2ICYmIHByZXYudG9kYXlEYXRlID09PSB0b2RheSA/IHByZXYudG9kYXlDb3VudCA6IDA7XG4gICAgICBhd2FpdCBidW1wQ291bnRlcihpdGVtLmhhbmRsZSwge1xuICAgICAgICB0b2RheUNvdW50OiBjYXJyaWVkVG9kYXkgKyBpdGVtLnR3ZWV0cy5sZW5ndGggKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCxcbiAgICAgICAgdG9kYXlEYXRlOiB0b2RheSxcbiAgICAgICAgbGFzdENhcHR1cmVBdDogaXRlbS5idWYubGFzdF9jYXB0dXJlX2F0LFxuICAgICAgICB0b3RhbENvbW1pdHRlZDpcbiAgICAgICAgICAocHJldj8udG90YWxDb21taXR0ZWQgPz8gMCkgKyBpdGVtLnR3ZWV0cy5sZW5ndGggKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCxcbiAgICAgICAgYnVmZmVyZWRDb3VudDogcmVtYWluaW5nQ291bnQsXG4gICAgICB9KTtcbiAgICAgIC8vIFJlY29yZCBjb21taXRzIGluIHRoZSBkZWR1cCBpbmRleCBzbyB3ZSBkb24ndCByZS1jb21taXQgdGhlbSBuZXh0XG4gICAgICAvLyBicm93c2Ugd2l0aCB1bmNoYW5nZWQgZW5nYWdlbWVudC5cbiAgICAgIGNvbnN0IGlubmVyID0gaWR4W2l0ZW0uaGFuZGxlXSA/PyB7fTtcbiAgICAgIGNvbnN0IG5vd0lzbyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICAgIGZvciAoY29uc3QgdCBvZiBpdGVtLnR3ZWV0cykge1xuICAgICAgICBpbm5lclt0LnR3ZWV0X2lkXSA9IHtcbiAgICAgICAgICB0czogbm93SXNvLFxuICAgICAgICAgIHNpZzogZW5nYWdlbWVudFNpZyhcbiAgICAgICAgICAgIHQubGlrZV9jb3VudCxcbiAgICAgICAgICAgIHQucmV0d2VldF9jb3VudCxcbiAgICAgICAgICAgIHQucmVwbHlfY291bnQsXG4gICAgICAgICAgICB0LnF1b3RlX2NvdW50LFxuICAgICAgICAgICAgdC5pc190cnVuY2F0ZWRcbiAgICAgICAgICApLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCB1IG9mIGl0ZW0udW5hdmFpbGFibGVUd2VldHMpIHtcbiAgICAgICAgaW5uZXJbdS50d2VldF9pZF0gPSB7XG4gICAgICAgICAgdHM6IG5vd0lzbyxcbiAgICAgICAgICBzaWc6IHVuYXZhaWxhYmxlU2lnKHUpLFxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWR4W2l0ZW0uaGFuZGxlXSA9IGlubmVyO1xuICAgICAgYXdhaXQgaW5mbygndXBsb2FkIGJ1ZmZlciBjb21taXR0ZWQnLCB7XG4gICAgICAgIGhhbmRsZTogaXRlbS5oYW5kbGUsXG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgdHdlZXRzOiBpdGVtLnR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIHVuYXZhaWxhYmxlOiBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCxcbiAgICAgICAgcmV0d2VldF9lZGdlczogaXRlbS5yZXR3ZWV0RWRnZXMubGVuZ3RoLFxuICAgICAgICBydW46IGl0ZW0ucnVuU2hvcnQsXG4gICAgICAgIHBhdGg6IGl0ZW0ucmF3UGF0aCxcbiAgICAgICAgYmF0Y2hfY29tbWl0OiByZXN1bHQuY29tbWl0U2hhLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XG4gICAgYXdhaXQgaW5mbygndXBsb2FkIGJ1ZmZlciBiYXRjaCBjb21taXR0ZWQnLCB7XG4gICAgICByZWFzb24sXG4gICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXG4gICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgdHdlZXRzOiBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udHdlZXRzLmxlbmd0aCwgMCksXG4gICAgICB1bmF2YWlsYWJsZTogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCwgMCksXG4gICAgICByZXR3ZWV0X2VkZ2VzOiBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0ucmV0d2VldEVkZ2VzLmxlbmd0aCwgMCksXG4gICAgICBjb21taXQ6IHJlc3VsdC5jb21taXRTaGEsXG4gICAgfSk7XG4gICAge1xuICAgICAgY29uc3QgcHJldiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXM6ICdvaycsXG4gICAgICAgIGxvZ2luOiBwcmV2LmxvZ2luLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IHByZXYuZGVmYXVsdEJyYW5jaCxcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogcHJldi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgICAgfSk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBpZiAoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpIHtcbiAgICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgICBjb25zdCBzdGF0dXM6IENvbm5lY3Rpb25TdGF0ZVsnc3RhdHVzJ10gPVxuICAgICAgICBlcnIuY2F0ZWdvcnkgPT09ICdhdXRoJ1xuICAgICAgICAgID8gJ2F1dGgtZXJyb3InXG4gICAgICAgICAgOiBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0J1xuICAgICAgICAgICAgPyAncmF0ZS1saW1pdGVkJ1xuICAgICAgICAgICAgOiBlcnIuY2F0ZWdvcnkgPT09ICduZXR3b3JrJ1xuICAgICAgICAgICAgICA/ICduZXR3b3JrLWVycm9yJ1xuICAgICAgICAgICAgICA6IGNvbm4uc3RhdHVzO1xuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICAgIHN0YXR1cyxcbiAgICAgICAgbG9naW46IGNvbm4ubG9naW4sXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBlcnJvcjogZXJyLm1lc3NhZ2UsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IGNvbm4uZGVmYXVsdEJyYW5jaCxcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogY29ubi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OlxuICAgICAgICAgIGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnID8gZXJyLnJhdGVMaW1pdFJlc2V0QXQgOiBjb25uLnJhdGVMaW1pdFJlc2V0QXQsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGxvZ0VycigndXBsb2FkIGJ1ZmZlciBmYWlsZWQnLCB7XG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxuICAgICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXG4gICAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXG4gICAgICAgIGNhdGVnb3J5OiBlcnIuY2F0ZWdvcnksXG4gICAgICAgIHN0YXR1czogZXJyLnN0YXR1cyxcbiAgICAgICAgbWVzc2FnZTogZXJyLm1lc3NhZ2UsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGVyci5yYXRlTGltaXRSZXNldEF0LFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGxvZ0VycigndXBsb2FkIGJ1ZmZlciBmYWlsZWQnLCB7XG4gICAgICAgIHJlYXNvbixcbiAgICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxuICAgICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXG4gICAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXG4gICAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICAgIH0pO1xuICAgIH1cbiAgICAvLyBMZWF2ZSBidWZmZXIgaW50YWN0IGZvciByZXRyeS5cbiAgfSBmaW5hbGx5IHtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGJ1aWxkRmx1c2hJdGVtKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgYnVmOiBSdW5CdWZmZXIsXG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXSxcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXSxcbiAgcmV0d2VldEVkZ2VzOiBSZXR3ZWV0RWRnZVtdXG4pOiBGbHVzaEl0ZW0ge1xuICBjb25zdCB0cyA9IGlzb0NvbXBhY3QoYnVmLnN0YXJ0ZWRfYXQpO1xuICBjb25zdCBkYXkgPSBidWYuc3RhcnRlZF9hdC5zbGljZSgwLCAxMCk7XG4gIGNvbnN0IHJ1blNob3J0ID0gc2hvcnRSdW5JZChidWYucnVuX2lkKTtcbiAgY29uc3QgcmF3UGF0aCA9IGByYXcvJHtoYW5kbGV9LyR7dHN9LSR7cnVuU2hvcnR9Lmpzb25gO1xuICBjb25zdCBzZWVuUGF0aCA9IGBzZWVuLyR7aGFuZGxlfS8ke3RzfS0ke3J1blNob3J0fS5qc29uYDtcbiAgcmV0dXJuIHtcbiAgICBoYW5kbGUsXG4gICAgYnVmLFxuICAgIHR3ZWV0cyxcbiAgICB1bmF2YWlsYWJsZVR3ZWV0cyxcbiAgICByZXR3ZWV0RWRnZXMsXG4gICAgcmF3UGF0aCxcbiAgICBzZWVuUGF0aCxcbiAgICBkYXksXG4gICAgcnVuU2hvcnQsXG4gICAgY2FwdHVyZToge1xuICAgICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gICAgICBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgIGVuZHBvaW50OiBidWYuZW5kcG9pbnRzX3NlZW4uam9pbignLCcpLFxuICAgICAgdXNlcl9hZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcbiAgICAgIHNvdXJjZV91cmw6IGJ1Zi5zb3VyY2VfdXJsLFxuICAgICAgdHdlZXRzLFxuICAgICAgdW5hdmFpbGFibGVfdHdlZXRzOiB1bmF2YWlsYWJsZVR3ZWV0cyxcbiAgICAgIHJldHdlZXRfZWRnZXM6IHJldHdlZXRFZGdlcyxcbiAgICB9LFxuICAgIHNlZW46IHtcbiAgICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQsXG4gICAgfSxcbiAgfTtcbn1cblxuZnVuY3Rpb24gYnVpbGRCYXRjaENvbW1pdE1lc3NhZ2UoaXRlbXM6IEZsdXNoSXRlbVtdKTogc3RyaW5nIHtcbiAgaWYgKGl0ZW1zLmxlbmd0aCA9PT0gMSkge1xuICAgIGNvbnN0IGl0ZW0gPSBpdGVtc1swXSE7XG4gICAgY29uc3QgdW5hdmFpbGFibGVDb3VudCA9IGl0ZW0udW5hdmFpbGFibGVUd2VldHMubGVuZ3RoO1xuICAgIGNvbnN0IGVkZ2VDb3VudCA9IGl0ZW0ucmV0d2VldEVkZ2VzLmxlbmd0aDtcbiAgICBjb25zdCBzdWZmaXggPVxuICAgICAgKHVuYXZhaWxhYmxlQ291bnQgPiAwID8gYCwgJHt1bmF2YWlsYWJsZUNvdW50fSB1bmF2YWlsYWJsZWAgOiAnJykgK1xuICAgICAgKGVkZ2VDb3VudCA+IDAgPyBgLCAke2VkZ2VDb3VudH0gcmV0d2VldCBlZGdlJHtlZGdlQ291bnQgPT09IDEgPyAnJyA6ICdzJ31gIDogJycpO1xuICAgIHJldHVybiBgY2FwdHVyZTogJHtpdGVtLmhhbmRsZX0gJHtpdGVtLmRheX0gJHtpdGVtLnR3ZWV0cy5sZW5ndGh9IHR3ZWV0JHtpdGVtLnR3ZWV0cy5sZW5ndGggPT09IDEgPyAnJyA6ICdzJ30ke3N1ZmZpeH0gKHJ1biAke2l0ZW0ucnVuU2hvcnR9KWA7XG4gIH1cbiAgY29uc3QgZGF5cyA9IFsuLi5uZXcgU2V0KGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5kYXkpKV0uc29ydCgpO1xuICBjb25zdCBkYXlMYWJlbCA9IGRheXMubGVuZ3RoID09PSAxID8gZGF5c1swXSEgOiBgJHtkYXlzWzBdfS4uJHtkYXlzW2RheXMubGVuZ3RoIC0gMV19YDtcbiAgY29uc3QgdHdlZXRDb3VudCA9IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS50d2VldHMubGVuZ3RoLCAwKTtcbiAgY29uc3QgdW5hdmFpbGFibGVDb3VudCA9IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsIDApO1xuICBjb25zdCBlZGdlQ291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0ucmV0d2VldEVkZ2VzLmxlbmd0aCwgMCk7XG4gIGNvbnN0IHN1ZmZpeCA9XG4gICAgKHVuYXZhaWxhYmxlQ291bnQgPiAwID8gYCwgJHt1bmF2YWlsYWJsZUNvdW50fSB1bmF2YWlsYWJsZWAgOiAnJykgK1xuICAgIChlZGdlQ291bnQgPiAwID8gYCwgJHtlZGdlQ291bnR9IHJldHdlZXQgZWRnZSR7ZWRnZUNvdW50ID09PSAxID8gJycgOiAncyd9YCA6ICcnKTtcbiAgcmV0dXJuIGBjYXB0dXJlIGJhdGNoOiAke2l0ZW1zLmxlbmd0aH0gcnVucywgJHt0d2VldENvdW50fSB0d2VldCR7dHdlZXRDb3VudCA9PT0gMSA/ICcnIDogJ3MnfSR7c3VmZml4fSAoJHtkYXlMYWJlbH0pYDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2xlYXJDb21taXR0ZWRUd2VldHNGcm9tQnVmZmVyKGl0ZW06IEZsdXNoSXRlbSk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IGN1cnJlbnQgPSBhd2FpdCBnZXRSdW5CdWZmZXIoaXRlbS5oYW5kbGUpO1xuICBpZiAoIWN1cnJlbnQpIHJldHVybiAwO1xuICBpZiAoY3VycmVudC5ydW5faWQgIT09IGl0ZW0uYnVmLnJ1bl9pZCkgcmV0dXJuIHJ1bkJ1ZmZlckl0ZW1Db3VudChjdXJyZW50KTtcblxuICBjb25zdCBjb21taXR0ZWQgPSBuZXcgTWFwKFxuICAgIGl0ZW0udHdlZXRzLm1hcCgodCkgPT4gW1xuICAgICAgdC50d2VldF9pZCxcbiAgICAgIGVuZ2FnZW1lbnRTaWcodC5saWtlX2NvdW50LCB0LnJldHdlZXRfY291bnQsIHQucmVwbHlfY291bnQsIHQucXVvdGVfY291bnQsIHQuaXNfdHJ1bmNhdGVkKSxcbiAgICBdKVxuICApO1xuICBmb3IgKGNvbnN0IHUgb2YgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cykge1xuICAgIGNvbW1pdHRlZC5zZXQodS50d2VldF9pZCwgdW5hdmFpbGFibGVTaWcodSkpO1xuICB9XG4gIGNvbnN0IHJlbWFpbmluZ1R3ZWV0czogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+ID0ge307XG4gIGZvciAoY29uc3QgW3R3ZWV0SWQsIHR3ZWV0XSBvZiBPYmplY3QuZW50cmllcyhjdXJyZW50LnR3ZWV0c19ieV9pZCkpIHtcbiAgICBjb25zdCBjb21taXR0ZWRTaWcgPSBjb21taXR0ZWQuZ2V0KHR3ZWV0SWQpO1xuICAgIGNvbnN0IGN1cnJlbnRTaWcgPSBlbmdhZ2VtZW50U2lnKFxuICAgICAgdHdlZXQubGlrZV9jb3VudCxcbiAgICAgIHR3ZWV0LnJldHdlZXRfY291bnQsXG4gICAgICB0d2VldC5yZXBseV9jb3VudCxcbiAgICAgIHR3ZWV0LnF1b3RlX2NvdW50LFxuICAgICAgdHdlZXQuaXNfdHJ1bmNhdGVkXG4gICAgKTtcbiAgICBpZiAoIWNvbW1pdHRlZFNpZyB8fCBjb21taXR0ZWRTaWcgIT09IGN1cnJlbnRTaWcpIHtcbiAgICAgIHJlbWFpbmluZ1R3ZWV0c1t0d2VldElkXSA9IHsgLi4udHdlZXQgfTtcbiAgICB9XG4gIH1cbiAgY29uc3QgcmVtYWluaW5nVW5hdmFpbGFibGU6IFJlY29yZDxzdHJpbmcsIFVuYXZhaWxhYmxlVHdlZXQ+ID0ge307XG4gIGZvciAoY29uc3QgW3R3ZWV0SWQsIHVuYXZhaWxhYmxlXSBvZiBPYmplY3QuZW50cmllcyhjdXJyZW50LnVuYXZhaWxhYmxlX2J5X2lkID8/IHt9KSkge1xuICAgIGNvbnN0IGNvbW1pdHRlZFNpZyA9IGNvbW1pdHRlZC5nZXQodHdlZXRJZCk7XG4gICAgY29uc3QgY3VycmVudFNpZyA9IHVuYXZhaWxhYmxlU2lnKHVuYXZhaWxhYmxlKTtcbiAgICBpZiAoIWNvbW1pdHRlZFNpZyB8fCBjb21taXR0ZWRTaWcgIT09IGN1cnJlbnRTaWcpIHtcbiAgICAgIHJlbWFpbmluZ1VuYXZhaWxhYmxlW3R3ZWV0SWRdID0geyAuLi51bmF2YWlsYWJsZSB9O1xuICAgIH1cbiAgfVxuICBjb25zdCByZW1haW5pbmdSZXR3ZWV0RWRnZXM6IFJlY29yZDxzdHJpbmcsIFJldHdlZXRFZGdlPiA9IHt9O1xuICBmb3IgKGNvbnN0IFtrZXksIGVkZ2VdIG9mIE9iamVjdC5lbnRyaWVzKGN1cnJlbnQucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge30pKSB7XG4gICAgaWYgKCFpdGVtLnJldHdlZXRFZGdlcy5zb21lKChjb21taXR0ZWRFZGdlKSA9PiByZXR3ZWV0RWRnZUtleShjb21taXR0ZWRFZGdlKSA9PT0ga2V5KSkge1xuICAgICAgcmVtYWluaW5nUmV0d2VldEVkZ2VzW2tleV0gPSB7IC4uLmVkZ2UgfTtcbiAgICB9XG4gIH1cblxuICBjb25zdCByZW1haW5pbmdJZHMgPSBuZXcgU2V0KFtcbiAgICAuLi5PYmplY3Qua2V5cyhyZW1haW5pbmdUd2VldHMpLFxuICAgIC4uLk9iamVjdC5rZXlzKHJlbWFpbmluZ1VuYXZhaWxhYmxlKSxcbiAgICAuLi5PYmplY3QudmFsdWVzKHJlbWFpbmluZ1JldHdlZXRFZGdlcykuZmxhdE1hcCgoZWRnZSkgPT4gW1xuICAgICAgZWRnZS5yZXR3ZWV0X3R3ZWV0X2lkLFxuICAgICAgZWRnZS5vcmlnaW5hbF90d2VldF9pZCxcbiAgICBdKSxcbiAgXSk7XG4gIGNvbnN0IHJlbWFpbmluZ0NvdW50ID1cbiAgICBPYmplY3Qua2V5cyhyZW1haW5pbmdUd2VldHMpLmxlbmd0aCArXG4gICAgT2JqZWN0LmtleXMocmVtYWluaW5nVW5hdmFpbGFibGUpLmxlbmd0aCArXG4gICAgT2JqZWN0LmtleXMocmVtYWluaW5nUmV0d2VldEVkZ2VzKS5sZW5ndGg7XG4gIGlmIChyZW1haW5pbmdDb3VudCA9PT0gMCkge1xuICAgIGF3YWl0IGNsZWFyUnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcbiAgICByZXR1cm4gMDtcbiAgfVxuXG4gIGNvbnN0IG5leHRSdW5JZCA9IG5ld1J1bklkKCk7XG4gIGZvciAoY29uc3QgdHdlZXQgb2YgT2JqZWN0LnZhbHVlcyhyZW1haW5pbmdUd2VldHMpKSB7XG4gICAgdHdlZXQuY2FwdHVyZV9ydW5faWQgPSBuZXh0UnVuSWQ7XG4gIH1cbiAgZm9yIChjb25zdCBlZGdlIG9mIE9iamVjdC52YWx1ZXMocmVtYWluaW5nUmV0d2VldEVkZ2VzKSkge1xuICAgIGVkZ2UuY2FwdHVyZV9ydW5faWQgPSBuZXh0UnVuSWQ7XG4gIH1cbiAgYXdhaXQgc2V0UnVuQnVmZmVyKGl0ZW0uaGFuZGxlLCB7XG4gICAgLi4uY3VycmVudCxcbiAgICBydW5faWQ6IG5leHRSdW5JZCxcbiAgICBzdGFydGVkX2F0OiBjdXJyZW50Lmxhc3RfY2FwdHVyZV9hdCxcbiAgICB0d2VldHNfYnlfaWQ6IHJlbWFpbmluZ1R3ZWV0cyxcbiAgICB1bmF2YWlsYWJsZV9ieV9pZDogcmVtYWluaW5nVW5hdmFpbGFibGUsXG4gICAgcmV0d2VldF9lZGdlc19ieV9rZXk6IHJlbWFpbmluZ1JldHdlZXRFZGdlcyxcbiAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IGN1cnJlbnQudHdlZXRfaWRzX29ic2VydmVkLmZpbHRlcigoaWQpID0+IHJlbWFpbmluZ0lkcy5oYXMoaWQpKSxcbiAgfSk7XG4gIGF3YWl0IGluZm8oJ3VwbG9hZCBidWZmZXIga2VwdCBuZXdlciB0d2VldHMnLCB7XG4gICAgaGFuZGxlOiBpdGVtLmhhbmRsZSxcbiAgICBjb21taXR0ZWRfcnVuOiBpdGVtLnJ1blNob3J0LFxuICAgIG5leHRfcnVuOiBzaG9ydFJ1bklkKG5leHRSdW5JZCksXG4gICAgcmVtYWluaW5nOiByZW1haW5pbmdDb3VudCxcbiAgfSk7XG4gIHJldHVybiByZW1haW5pbmdDb3VudDtcbn1cblxuLy8gLS0tIENhcHR1cmUtbm93IC8gY2FwdHVyZS1hbGwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlTm93KGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGFsbG93TWFudWFsQ2FwdHVyZVdpbmRvdygpO1xuICAvLyBMYW5kIG9uIHRoZSBSZXBsaWVzIHRhYiBzbyBYIGZldGNoZXMgdmlhIFVzZXJUd2VldHNBbmRSZXBsaWVzIFx1MjAxNCB0aGF0XG4gIC8vIGVuZHBvaW50IHJldHVybnMgYm90aCB0b3AtbGV2ZWwgcG9zdHMgYW5kIHJlcGxpZXMsIHdoaWNoIGlzIHRoZSBzdXBlcnNldFxuICAvLyB3ZSB3YW50IGZvciB0aGUgYXJjaGl2ZS4gVGhlIHBsYWluIGAvPGhhbmRsZT5gIFVSTCBoaXRzIFVzZXJUd2VldHMsXG4gIC8vIHdoaWNoIG9taXRzIHJlcGxpZXMuIFRoZSBwYWdlLWhvb2sgaW50ZXJjZXB0cyBlaXRoZXIgZW5kcG9pbnQsIGJ1dFxuICAvLyBmb3JjaW5nIHRoZSBicm9hZGVyIHRhYiBvbiB1c2VyLWluaXRpYXRlZCBjYXB0dXJlcyBpcyB0aGUgcmlnaHQgZGVmYXVsdC5cbiAgY29uc3QgdGFyZ2V0VXJsID0gYGh0dHBzOi8veC5jb20vJHtoYW5kbGV9L3dpdGhfcmVwbGllc2A7XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtbm93IHJlcXVlc3RlZCcsIHsgaGFuZGxlLCB0YWI6ICd3aXRoX3JlcGxpZXMnIH0pO1xuICBpZiAoIShhd2FpdCBnZXRSdW5CdWZmZXIoaGFuZGxlKSkpIHtcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwge1xuICAgICAgcnVuX2lkOiBuZXdSdW5JZCgpLFxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICAgIHN0YXJ0ZWRfYXQ6IG5vdyxcbiAgICAgIGxhc3RfY2FwdHVyZV9hdDogbm93LFxuICAgICAgdHdlZXRzX2J5X2lkOiB7fSxcbiAgICAgIHVuYXZhaWxhYmxlX2J5X2lkOiB7fSxcbiAgICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogW10sXG4gICAgICBlbmRwb2ludHNfc2VlbjogW10sXG4gICAgICBzb3VyY2VfdXJsOiB0YXJnZXRVcmwsXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogdGFyZ2V0VXJsLCBhY3RpdmU6IHRydWUgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVBbGwoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFjY291bnRzID0gYXdhaXQgZ2V0QWNjb3VudHMoKTtcbiAgYXdhaXQgaW5mbygnY2FwdHVyZS1hbGwgcmVxdWVzdGVkJywgeyBjb3VudDogYWNjb3VudHMubGVuZ3RoIH0pO1xuICBmb3IgKGNvbnN0IGEgb2YgYWNjb3VudHMpIHtcbiAgICBhd2FpdCBjYXB0dXJlTm93KGEuaGFuZGxlKTtcbiAgfVxufVxuXG4vKipcbiAqIENhcHR1cmUgd2hhdGV2ZXIgdGhlIHVzZXIgaXMgY3VycmVudGx5IGxvb2tpbmcgYXQ6IGVuc3VyZXMgcGFnZS1ob29rIGlzXG4gKiBwYXRjaGVkIGludG8gdGhlIGFjdGl2ZSB0YWIsIHRoZW4gbnVkZ2VzIHRoZSBwYWdlIHdpdGggYSBwcm9ncmFtbWF0aWNcbiAqIHNjcm9sbCBzbyBYIGZpcmVzIGFub3RoZXIgYmF0Y2ggb2YgR3JhcGhRTCByZXF1ZXN0cyB3ZSBjYW4gaW50ZXJjZXB0LlxuICpcbiAqIExlc3MgZGlzcnVwdGl2ZSB0aGFuIGBDYXB0dXJlIG5vd2AgKG5vIG5ldyB0YWIsIG5vIG5hdmlnYXRpb24pIGFuZCB3b3Jrc1xuICogZm9yIGFyYml0cmFyeSBYIFVSTHMgKHNwZWNpZmljIHR3ZWV0IHRocmVhZHMsIHNlYXJjaCByZXN1bHRzLCBsaXN0cylcbiAqIHRoYXQgZG9uJ3QgbWFwIGNsZWFubHkgdG8gb25lIG9mIHRoZSBjb25maWd1cmVkIGhhbmRsZXMuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVUaGlzUGFnZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XG4gIHRyeSB7XG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGNvdWxkIG5vdCBxdWVyeSBhY3RpdmUgdGFiJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgdGFiID0gdGFic1swXTtcbiAgaWYgKCF0YWIgfHwgdHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicgfHwgIXRhYi51cmwpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogbm8gYWN0aXZlIHRhYicpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIS9eaHR0cHM6XFwvXFwvKHh8dHdpdHRlcilcXC5jb21cXC8vLnRlc3QodGFiLnVybCkpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogYWN0aXZlIHRhYiBpcyBub3Qgb24geC5jb20gLyB0d2l0dGVyLmNvbScsIHtcbiAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsKSxcbiAgICB9KTtcbiAgICByZXR1cm47XG4gIH1cbiAgYXdhaXQgaW5mbygnY2FwdHVyZS10aGlzLXBhZ2UgcmVxdWVzdGVkJywgeyB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCkgfSk7XG4gIC8vIChSZS0paW5qZWN0IHRoZSBwYWdlLWhvb2sgKyBpc29sYXRlZCBjb250ZW50IHNjcmlwdCBzbyBmZXRjaC9YSFIgYXJlXG4gIC8vIHBhdGNoZWQgZXZlbiBvbiB0YWJzIG9wZW5lZCBiZWZvcmUgdGhlIGV4dGVuc2lvbiByZWxvYWRlZC5cbiAgdHJ5IHtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICBmaWxlczogWydwYWdlLWhvb2suanMnXSxcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICB9KTtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiByZS1pbmplY3QgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxuICAvLyBOdWRnZSBYIHRvIGZpcmUgbW9yZSBHcmFwaFFMIHJlcXVlc3RzIGJ5IHNjcm9sbGluZy4gTW9zdCB0aW1lbGluZSAvXG4gIC8vIGNvbnZlcnNhdGlvbiB2aWV3cyBmZXRjaCBvbiBpbnRlcnNlY3Rpb24tb2JzZXJ2ZXIgdHJpZ2dlcnMuXG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgZnVuYzogKCkgPT4ge1xuICAgICAgICBjb25zdCBoID0gd2luZG93LmlubmVySGVpZ2h0O1xuICAgICAgICB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgNjAwKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgMTIwMCk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogc2Nyb2xsLW51ZGdlIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbn1cblxuLy8gLS0tIFJlZmV0Y2ggbG9vcCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vXG4vLyBYIHRydW5jYXRlcyBsb25nIHR3ZWV0cyBpbiB0aW1lbGluZSBwYXlsb2FkcyBcdTIwMTQgYG5vdGVfdHdlZXRgIGlzIG9ubHlcbi8vIGlubGluZWQgZm9yIHNvbWUgZW5kcG9pbnRzLiBSZS1vcGVuaW5nIGVhY2ggdHJ1bmNhdGVkIHR3ZWV0J3MgZGV0YWlsIHBhZ2Vcbi8vIGNhdXNlcyB0aGUgcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkuIFRoZSBsb29wXG4vLyBkcml2ZXMgdGhhdCBieSBuYXZpZ2F0aW5nIGEgc2luZ2xlIGRlZGljYXRlZCB0YWIgdGhyb3VnaCB0aGUgcXVldWUsIG9uZVxuLy8gdHdlZXQgYXQgYSB0aW1lLCBnYXRlZCBvbiB0aGUgcGFnZS1ob29rIGFjdHVhbGx5IGluZ2VzdGluZyBhIHJlc3BvbnNlIGZvclxuLy8gdGhlIHR3ZWV0IHdlIGp1c3QgbmF2aWdhdGVkIHRvIChzbyBkZWxldGVkIC8gcGF5d2FsbGVkIC8gNDA0J2QgdHdlZXRzXG4vLyBkb24ndCBtYWtlIHVzIHNwaW4gYW5kIHNvIHdlIGRvbid0IHNsYW0gWCB3aXRoIHJlZnJlc2hlcyBmYXN0ZXIgdGhhbiB0aGVcbi8vIHRhYiBjYW4gbG9hZCkuXG5cbmNvbnN0IFJFRkVUQ0hfVEFCX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3JlZmV0Y2hfdGFiX2lkX18nO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoUkVGRVRDSF9UQUJfS0VZKTtcbiAgY29uc3QgaWQgPSBzdG9yZWRbUkVGRVRDSF9UQUJfS0VZXTtcbiAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ251bWJlcicgPyBpZCA6IG51bGw7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hUYWJJZChpZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoaWQgPT09IG51bGwpIHtcbiAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFJFRkVUQ0hfVEFCX0tFWSk7XG4gIH0gZWxzZSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtSRUZFVENIX1RBQl9LRVldOiBpZCB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydFJlZmV0Y2hMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcbiAgY29uc3QgdG90YWwgPSBhd2FpdCByZWZldGNoUXVldWVUb3RhbCgpO1xuICBpZiAodG90YWwgPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoOiBub3RoaW5nIHF1ZXVlZCcpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3Qgc2Vjb25kcyA9IE1hdGgubWluKFxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYykpXG4gICk7XG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHtcbiAgICB0b3RhbEF0U3RhcnQ6IHRvdGFsLFxuICAgIHByb2Nlc3NlZDogMCxcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBpbmZsaWdodDogbnVsbCxcbiAgfSk7XG4gIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHMpO1xuICB2b2lkIHJlZmV0Y2hUaWNrKCk7XG4gIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBzdGFydGVkJywgeyBxdWV1ZWQ6IHRvdGFsLCBpbnRlcnZhbF9zZWM6IHNlY29uZHMgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmxldCByZWZldGNoSW50ZXJ2YWxIYW5kbGU6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzOiBudW1iZXIpOiB2b2lkIHtcbiAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgY2xlYXJJbnRlcnZhbChyZWZldGNoSW50ZXJ2YWxIYW5kbGUpO1xuICByZWZldGNoSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgdm9pZCByZWZldGNoVGljaygpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybigncmVmZXRjaCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcbn1cblxuZnVuY3Rpb24gc3RvcFJlZmV0Y2hJbnRlcnZhbCgpOiB2b2lkIHtcbiAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcbiAgICByZWZldGNoSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbFJlZmV0Y2hMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdyZWZldGNoLXRpY2snKTsgLy8gbGVnYWN5IGNsZWFudXBcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRSZWZldGNoVGFiSWQoKTtcbiAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24obnVsbCk7XG4gIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBjYW5jZWxsZWQnLCB7XG4gICAgaGFkX3RhYjogdGFiSWQgIT09IG51bGwsXG4gICAgcHJvY2Vzc2VkOiBzZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZmV0Y2hUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgc2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGlmIChzZXNzID09PSBudWxsKSB7XG4gICAgLy8gTG9vcCB3YXMgY2FuY2VsbGVkIG9yIG5ldmVyIHN0YXJ0ZWQ7IG5vdGhpbmcgdG8gZG8uXG4gICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBXYWl0LWZvci1pbmdlc3QgZ3VhcmQ6IGlmIHdlJ3JlIHN0aWxsIGV4cGVjdGluZyBhIGNhcHR1cmUgZm9yIHRoZVxuICAvLyBwcmV2aW91c2x5LW5hdmlnYXRlZCB0YXJnZXQsIG9ubHkgYWR2YW5jZSBvbmNlIHdlJ3ZlIGVpdGhlciBzZWVuIHRoZVxuICAvLyBjYXB0dXJlIChvbkdyYXBocWxDYXB0dXJlIGNsZWFycyBgaW5mbGlnaHRgKSBvciBoaXQgdGhlIHRpbWVvdXQuXG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xuICAgIGlmIChlbGFwc2VkIDwgSU5HRVNUX1dBSVRfTVMpIHtcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBcdTIwMTQgcGFnZS1ob29rIG1heSB5ZXQgY2FwdHVyZSB0aGUgcmVzcG9uc2UuXG4gICAgfVxuICAgIC8vIFRpbWVkIG91dC4gVHJlYXQgYXMgXCJ0aGlzIHRhcmdldCB3b24ndCBpbmdlc3RcIiBhbmQgZHJvcCBpdC5cbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoOiB0YXJnZXQgdGltZWQgb3V0IHdhaXRpbmcgZm9yIGluZ2VzdCcsIHtcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXG4gICAgICB3YWl0ZWRfbXM6IGVsYXBzZWQsXG4gICAgfSk7XG4gICAgLy8gRmluZCB3aGljaCBoYW5kbGUgdGhpcyBpZCBpcyBxdWV1ZWQgdW5kZXIgc28gd2UgY2FuIGRlcXVldWUgaXQuXG4gICAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICAgIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgICAgaWYgKGlkcy5pbmNsdWRlcyhzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpKSB7XG4gICAgICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKGhhbmRsZSwgc2Vzcy5pbmZsaWdodC50d2VldElkKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24oc2Vzcyk7XG4gIH1cblxuICBjb25zdCB0YXJnZXQgPSBhd2FpdCBuZXh0UmVmZXRjaFRhcmdldCgpO1xuICBpZiAoIXRhcmdldCkge1xuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICBhd2FpdCBzZXRSZWZldGNoVGFiSWQobnVsbCk7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24obnVsbCk7XG4gICAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuaGFuZGxlfS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRSZWZldGNoVGFiSWQoKTtcbiAgaWYgKHRhYklkICE9PSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdGFiSWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiBmYWxzZSB9KTtcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkID09PSAnbnVtYmVyJykgYXdhaXQgc2V0UmVmZXRjaFRhYklkKHRhYi5pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy51cGRhdGUodGFiSWQsIHsgdXJsIH0pO1xuICAgIH1cbiAgICBzZXNzID0gKGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCkpID8/IHNlc3M7XG4gICAgc2Vzcy5pbmZsaWdodCA9IHtcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2ggdGljaycsIHtcbiAgICAgIGhhbmRsZTogdGFyZ2V0LmhhbmRsZSxcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIHJlbWFpbmluZzogYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKSxcbiAgICAgIHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQsXG4gICAgICB0b3RhbF9hdF9zdGFydDogc2Vzcy50b3RhbEF0U3RhcnQsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ3JlZmV0Y2ggbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2godGFyZ2V0LmhhbmRsZSwgdGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24oc2Vzcyk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuLy8gLS0tIE1lZGlhLWNyYXdsIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vXG4vLyBNaXJyb3JzIHRoZSByZWZldGNoIGxvb3AgYnV0IHRhcmdldHMgdGhlIG1lZGlhLWNyYXdsIHF1ZXVlOiB0d2VldHMgdGhhdFxuLy8gdGhlIG5vcm1hbGl6ZXIgb2JzZXJ2ZWQgdmlhIHRoZSBNZWRpYSB0YWIgLyBVc2VyTWVkaWEgZW5kcG9pbnQgd2l0aFxuLy8gaW5zdWZmaWNpZW50IGRhdGEgdG8gYnVpbGQgYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gVGhlIGNyYXdsIGxvb3Agd2Fsa3Ncbi8vIGEgZGVkaWNhdGVkIHRhYiB0aHJvdWdoIGVhY2ggdHdlZXQncyBkZXRhaWwgcGFnZSAoaGFuZGxlLWxlc3MgVVJMIGZvcm1cbi8vIHdoZW4gdGhlIGhpbnQtaGFuZGxlIGlzIG1pc3NpbmcpLCBhdCB0aGUgYXV0by1zY3JvbGwgY2FkZW5jZSwgc28gdGhlXG4vLyBwYWdlLWhvb2sgY2FuIGNhcHR1cmUgdGhlIHJlYWwgdHdlZXQgc2hhcGUuXG5cbmNvbnN0IE1FRElBX0NSQVdMX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV9tZWRpYV9jcmF3bF90YWJfaWRfXyc7XG5cbmFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xUYWJJZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChNRURJQV9DUkFXTF9UQUJfS0VZKTtcbiAgY29uc3QgaWQgPSBzdG9yZWRbTUVESUFfQ1JBV0xfVEFCX0tFWV07XG4gIHJldHVybiB0eXBlb2YgaWQgPT09ICdudW1iZXInID8gaWQgOiBudWxsO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsVGFiSWQoaWQ6IG51bWJlciB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGlkID09PSBudWxsKSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKE1FRElBX0NSQVdMX1RBQl9LRVkpO1xuICBlbHNlIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbTUVESUFfQ1JBV0xfVEFCX0tFWV06IGlkIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydE1lZGlhQ3Jhd2xMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcbiAgY29uc3QgdG90YWwgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xuICBpZiAodG90YWwgPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogbm90aGluZyBxdWV1ZWQnKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxuICApO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbih7XG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcbiAgICBwcm9jZXNzZWQ6IDAsXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgaW5mbGlnaHQ6IG51bGwsXG4gIH0pO1xuICBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzKTtcbiAgdm9pZCBtZWRpYUNyYXdsVGljaygpO1xuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxubGV0IG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZTogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xuICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XG4gIG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIG1lZGlhQ3Jhd2xUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCdtZWRpYS1jcmF3bCB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcbn1cblxuZnVuY3Rpb24gc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpOiB2b2lkIHtcbiAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwobWVkaWFDcmF3bEludGVydmFsSGFuZGxlKTtcbiAgICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbE1lZGlhQ3Jhd2xMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFRhYklkKCk7XG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZChudWxsKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcbiAgICBwcm9jZXNzZWQ6IHNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBzZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgaWYgKHNlc3MgPT09IG51bGwpIHtcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xuICAgIGlmIChlbGFwc2VkIDwgSU5HRVNUX1dBSVRfTVMpIHtcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBvbiB0aGUgcGFnZS1ob29rXG4gICAgfVxuICAgIGF3YWl0IHdhcm4oJ21lZGlhLWNyYXdsOiB0YXJnZXQgdGltZWQgb3V0IHdhaXRpbmcgZm9yIGluZ2VzdCcsIHtcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXG4gICAgICB3YWl0ZWRfbXM6IGVsYXBzZWQsXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2woc2Vzcy5pbmZsaWdodC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xuICB9XG5cbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKG51bGwpO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG51bGwpO1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gU2tpcCBpZiBhbHJlYWR5IGluIHRoZSBhcmNoaXZlIFx1MjAxNCBwYXJ0aWFsIGNhcHR1cmVzIGNhbiBvdXRsaXZlIGFcbiAgLy8gc2VwYXJhdGUgZnVsbCBjYXB0dXJlIHBhdGguXG4gIGlmIChhd2FpdCBpc0NvbW1pdHRlZCh0YXJnZXQudHdlZXRJZCkpIHtcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8vIFdoZW4gd2UgZG9uJ3Qga25vdyB0aGUgcGFyZW50J3MgYXV0aG9yIGhhbmRsZSAocXVvdGUvUlQgb2YgYSB0d2VldFxuICAvLyBYIHN0cmlwcGVkLCBvciBhIFVzZXJNZWRpYSB0aHVtYm5haWwgdGhhdCBsYWNrZWQgdGhlIGF1dGhvciBibG9jayksXG4gIC8vIGZhbGwgYmFjayB0byBgL2kvd2ViL3N0YXR1cy88aWQ+YC4gWCByZXNvbHZlcyBpdCB0byB0aGUgY29ycmVjdFxuICAvLyBkZXRhaWwgcGFnZSwgd2hpY2ggaXMgZW5vdWdoIGZvciB0aGUgcGFnZS1ob29rIHRvIGluZ2VzdCBhXG4gIC8vIFR3ZWV0RGV0YWlsIHJlc3BvbnNlLlxuICBjb25zdCB1cmwgPVxuICAgIHRhcmdldC5idWNrZXQgPT09ICdfdW5rbm93bidcbiAgICAgID8gYGh0dHBzOi8veC5jb20vaS93ZWIvc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YFxuICAgICAgOiBgaHR0cHM6Ly94LmNvbS8ke3RhcmdldC5idWNrZXR9L3N0YXR1cy8ke3RhcmdldC50d2VldElkfWA7XG4gIGxldCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xuICBpZiAodGFiSWQgIT09IG51bGwpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmdldCh0YWJJZCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICB0YWJJZCA9IG51bGw7XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgaWYgKHRhYklkID09PSBudWxsKSB7XG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xuICAgICAgaWYgKHR5cGVvZiB0YWIuaWQgPT09ICdudW1iZXInKSBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQodGFiLmlkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XG4gICAgfVxuICAgIHNlc3MgPSAoYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKSkgPz8gc2VzcztcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xuICAgICAgdHdlZXRJZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBuYXZpZ2F0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgdGljaycsIHtcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIGhpbnRfaGFuZGxlOiB0YXJnZXQuYnVja2V0ID09PSAnX3Vua25vd24nID8gbnVsbCA6IHRhcmdldC5idWNrZXQsXG4gICAgICByZW1haW5pbmc6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bCBuYXZpZ2F0ZSBmYWlsZWQ7IGRyb3BwaW5nIHRhcmdldCcsIHtcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICB9KTtcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG4vLyAtLS0gVGhyZWFkLW9wZW5pbmcgbG9vcCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vL1xuLy8gVGltZWxpbmVzIG9mdGVuIHNob3cgYSBjb3JlIGFjY291bnQncyByb290IHR3ZWV0IHdpdGhvdXQgZXZlcnkgbGF0ZXJcbi8vIHNlbGYtcmVwbHkgaW4gdGhlIGNvbnZlcnNhdGlvbi4gVGhpcyB1dGlsaXR5IHdhbGtzIGEgZGVkaWNhdGVkIHRhYiB0aHJvdWdoXG4vLyBxdWV1ZWQgY29yZSB0aHJlYWQgcm9vdHMgYW5kIG51ZGdlcyB0aGUgZGV0YWlsIHBhZ2Ugc28gVHdlZXREZXRhaWwgcGF5bG9hZHNcbi8vIGxvYWQgdGhlIHJlc3Qgb2YgdGhlIGNvbnZlcnNhdGlvbi5cblxuY29uc3QgVEhSRUFEX09QRU5fVEFCX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3RocmVhZF9vcGVuX3RhYl9pZF9fJztcblxuYXN5bmMgZnVuY3Rpb24gZ2V0VGhyZWFkT3BlblRhYklkKCk6IFByb21pc2U8bnVtYmVyIHwgbnVsbD4ge1xuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFRIUkVBRF9PUEVOX1RBQl9LRVkpO1xuICBjb25zdCBpZCA9IHN0b3JlZFtUSFJFQURfT1BFTl9UQUJfS0VZXTtcbiAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ251bWJlcicgPyBpZCA6IG51bGw7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldFRocmVhZE9wZW5UYWJJZChpZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoaWQgPT09IG51bGwpIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5yZW1vdmUoVEhSRUFEX09QRU5fVEFCX0tFWSk7XG4gIGVsc2UgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtUSFJFQURfT1BFTl9UQUJfS0VZXTogaWQgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0VGhyZWFkT3Blbkxvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGFsbG93TWFudWFsQ2FwdHVyZVdpbmRvdygpO1xuICBjb25zdCB0b3RhbCA9IGF3YWl0IHRocmVhZE9wZW5RdWV1ZVRvdGFsKCk7XG4gIGlmICh0b3RhbCA9PT0gMCkge1xuICAgIGF3YWl0IGluZm8oJ3RocmVhZC1vcGVuOiBub3RoaW5nIHF1ZXVlZCcpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3Qgc2Vjb25kcyA9IE1hdGgubWluKFxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYykpXG4gICk7XG4gIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHtcbiAgICB0b3RhbEF0U3RhcnQ6IHRvdGFsLFxuICAgIHByb2Nlc3NlZDogMCxcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBpbmZsaWdodDogbnVsbCxcbiAgfSk7XG4gIHN0YXJ0VGhyZWFkT3BlbkludGVydmFsKHNlY29uZHMpO1xuICB2b2lkIHRocmVhZE9wZW5UaWNrKCk7XG4gIGF3YWl0IGluZm8oJ3RocmVhZC1vcGVuIGxvb3Agc3RhcnRlZCcsIHsgcXVldWVkOiB0b3RhbCwgaW50ZXJ2YWxfc2VjOiBzZWNvbmRzIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5sZXQgdGhyZWFkT3BlbkludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gc3RhcnRUaHJlYWRPcGVuSW50ZXJ2YWwoc2Vjb25kczogbnVtYmVyKTogdm9pZCB7XG4gIGlmICh0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwodGhyZWFkT3BlbkludGVydmFsSGFuZGxlKTtcbiAgdGhyZWFkT3BlbkludGVydmFsSGFuZGxlID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgdGhyZWFkT3BlblRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ3RocmVhZC1vcGVuIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICB9KTtcbiAgfSwgc2Vjb25kcyAqIDEwMDApO1xufVxuXG5mdW5jdGlvbiBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk6IHZvaWQge1xuICBpZiAodGhyZWFkT3BlbkludGVydmFsSGFuZGxlICE9PSBudWxsKSB7XG4gICAgY2xlYXJJbnRlcnZhbCh0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUpO1xuICAgIHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSA9IG51bGw7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsVGhyZWFkT3Blbkxvb3AoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHN0b3BUaHJlYWRPcGVuSW50ZXJ2YWwoKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3RocmVhZC1vcGVuLXRpY2snKTsgLy8gbGVnYWN5IGNsZWFudXBcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRUaHJlYWRPcGVuVGFiSWQoKTtcbiAgYXdhaXQgc2V0VGhyZWFkT3BlblRhYklkKG51bGwpO1xuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0VGhyZWFkT3BlblNlc3Npb24oKTtcbiAgYXdhaXQgc2V0VGhyZWFkT3BlblNlc3Npb24obnVsbCk7XG4gIGF3YWl0IGluZm8oJ3RocmVhZC1vcGVuIGxvb3AgY2FuY2VsbGVkJywge1xuICAgIGhhZF90YWI6IHRhYklkICE9PSBudWxsLFxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiB0aHJlYWRPcGVuVGljaygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRUaHJlYWRPcGVuU2Vzc2lvbigpO1xuICBpZiAoc2VzcyA9PT0gbnVsbCkge1xuICAgIHN0b3BUaHJlYWRPcGVuSW50ZXJ2YWwoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHNlc3MuaW5mbGlnaHQgIT09IG51bGwpIHtcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2Uoc2Vzcy5pbmZsaWdodC5uYXZpZ2F0ZWRBdCk7XG4gICAgaWYgKGVsYXBzZWQgPCBJTkdFU1RfV0FJVF9NUykgcmV0dXJuO1xuICAgIGF3YWl0IHdhcm4oJ3RocmVhZC1vcGVuOiB0YXJnZXQgdGltZWQgb3V0IHdhaXRpbmcgZm9yIGluZ2VzdCcsIHtcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXG4gICAgICB3YWl0ZWRfbXM6IGVsYXBzZWQsXG4gICAgfSk7XG4gICAgYXdhaXQgbWFya1RocmVhZE9wZW5TZWVuKHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgYXdhaXQgZGVxdWV1ZVRocmVhZE9wZW4oc2Vzcy5pbmZsaWdodC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHNlc3MpO1xuICB9XG5cbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dFRocmVhZE9wZW5UYXJnZXQoKTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk7XG4gICAgYXdhaXQgc2V0VGhyZWFkT3BlblRhYklkKG51bGwpO1xuICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKG51bGwpO1xuICAgIGF3YWl0IGluZm8oJ3RocmVhZC1vcGVuIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGF3YWl0IGhhc1RocmVhZE9wZW5TZWVuKHRhcmdldC50d2VldElkKSkge1xuICAgIGF3YWl0IGRlcXVldWVUaHJlYWRPcGVuKHRhcmdldC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHNlc3MpO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc3QgdXJsID0gYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuaGFuZGxlfS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRUaHJlYWRPcGVuVGFiSWQoKTtcbiAgaWYgKHRhYklkICE9PSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdGFiSWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiBmYWxzZSB9KTtcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJykgdGhyb3cgbmV3IEVycm9yKCdjcmVhdGVkIHRhYiB3aXRob3V0IGlkJyk7XG4gICAgICB0YWJJZCA9IHRhYi5pZDtcbiAgICAgIGF3YWl0IHNldFRocmVhZE9wZW5UYWJJZCh0YWJJZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy51cGRhdGUodGFiSWQsIHsgdXJsIH0pO1xuICAgIH1cbiAgICBhd2FpdCBtYXJrVGhyZWFkT3BlblNlZW4odGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MgPSAoYXdhaXQgZ2V0VGhyZWFkT3BlblNlc3Npb24oKSkgPz8gc2VzcztcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xuICAgICAgdHdlZXRJZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBuYXZpZ2F0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG4gICAgYXdhaXQgc2V0VGhyZWFkT3BlblNlc3Npb24oc2Vzcyk7XG4gICAgaWYgKHRhYklkICE9PSBudWxsKSB7XG4gICAgICB2b2lkIG51ZGdlVGhyZWFkT3BlblRhYih0YWJJZCk7XG4gICAgfVxuICAgIGF3YWl0IGluZm8oJ3RocmVhZC1vcGVuIHRpY2snLCB7XG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICByZW1haW5pbmc6IGF3YWl0IHRocmVhZE9wZW5RdWV1ZVRvdGFsKCksXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCd0aHJlYWQtb3BlbiBuYXZpZ2F0ZSBmYWlsZWQ7IGRyb3BwaW5nIHRhcmdldCcsIHtcbiAgICAgIGhhbmRsZTogdGFyZ2V0LmhhbmRsZSxcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICB9KTtcbiAgICBhd2FpdCBtYXJrVGhyZWFkT3BlblNlZW4odGFyZ2V0LnR3ZWV0SWQpO1xuICAgIGF3YWl0IGRlcXVldWVUaHJlYWRPcGVuKHRhcmdldC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHNlc3MpO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG51ZGdlVGhyZWFkT3BlblRhYih0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIDE1MDApKTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDogeyB0YWJJZCB9LFxuICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxuICAgICAgZnVuYzogKCkgPT4ge1xuICAgICAgICBjb25zdCBoID0gd2luZG93LmlubmVySGVpZ2h0O1xuICAgICAgICBjb25zdCBzdGVwID0gKCkgPT4gd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS4zLCBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XG4gICAgICAgIHN0ZXAoKTtcbiAgICAgICAgc2V0VGltZW91dChzdGVwLCAxNDAwKTtcbiAgICAgICAgc2V0VGltZW91dChzdGVwLCAyODAwKTtcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ3RocmVhZC1vcGVuIHNjcm9sbC1udWRnZSBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG59XG5cbi8vIC0tLSBRdWFyYW50aW5lIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmFzeW5jIGZ1bmN0aW9uIHF1YXJhbnRpbmUoXG4gIHJlYXNvbjogc3RyaW5nLFxuICBlbmRwb2ludDogc3RyaW5nLFxuICB1cmw6IHN0cmluZyxcbiAgcmF3OiB1bmtub3duLFxuICBlcnI6IHVua25vd25cbik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBsb2dFcnIoJ3F1YXJhbnRpbmluZyBjYXB0dXJlJywgeyByZWFzb24sIGVuZHBvaW50LCB1cmwsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcbiAgY29uc3QgcGF5bG9hZDogUXVhcmFudGluZVBheWxvYWQgPSB7XG4gICAgc2NoZW1hX3ZlcnNpb246IDEsXG4gICAgcmVhc29uLFxuICAgIGVuZHBvaW50LFxuICAgIGNhcHR1cmVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgc291cmNlX3VybDogdXJsLFxuICAgIGVycm9yOiBkZXNjcmliZUVycm9yKGVyciksXG4gICAgcmF3LFxuICB9O1xuICBjb25zdCB0cyA9IGlzb0NvbXBhY3QocGF5bG9hZC5jYXB0dXJlZF9hdCk7XG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBzaGE4KEpTT04uc3RyaW5naWZ5KHBheWxvYWQpKTtcbiAgY29uc3QgcGF0aCA9IGByYXcvX3F1YXJhbnRpbmUvJHt0c30tJHtoYXNofS5qc29uYDtcbiAgdHJ5IHtcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgICBhd2FpdCBjbGllbnQucHV0RmlsZSh7XG4gICAgICBwYXRoLFxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkocGF5bG9hZCwgbnVsbCwgMikgKyAnXFxuJyksXG4gICAgICBtZXNzYWdlOiBgcXVhcmFudGluZTogJHtyZWFzb259ICR7ZW5kcG9pbnR9YCxcbiAgICB9KTtcbiAgfSBjYXRjaCAocWVycikge1xuICAgIGF3YWl0IGxvZ0VycigncXVhcmFudGluZSBjb21taXQgZmFpbGVkJywgeyAuLi5kZXNjcmliZUVycm9yKHFlcnIpIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNoYTgoczogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgYnVmID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHMpO1xuICBjb25zdCBkaWdlc3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGJ1Zik7XG4gIGNvbnN0IGhleCA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoZGlnZXN0KSlcbiAgICAubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKVxuICAgIC5qb2luKCcnKTtcbiAgcmV0dXJuIGhleC5zbGljZSgwLCA4KTtcbn1cblxuLy8gLS0tIENvbm5lY3Rpb24gdmVyaWZpY2F0aW9uICYgYWNjb3VudHMgbGlzdCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiB2ZXJpZnlDb25uZWN0aW9uKGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSB7XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXM6ICdub3QtY29uZmlndXJlZCcsXG4gICAgICBsb2dpbjogbnVsbCxcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IG51bGwsXG4gICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgfSk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgaWYgKCFmb3JjZSkge1xuICAgIC8vIFNraXAgaWYgd2UncmUgaW5zaWRlIHRoZSByZXBvcnRlZCByYXRlLWxpbWl0IHdpbmRvdyBcdTIwMTQgcmUtY2hlY2tpbmdcbiAgICAvLyBiZWZvcmUgcmVzZXQganVzdCB3YXN0ZXMgbW9yZSBvZiB0aGUgc2FtZSBleGhhdXN0ZWQgcXVvdGEgYW5kIGtlZXBzXG4gICAgLy8gdGhlIDQwM3MgY29taW5nLlxuICAgIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcgJiYgY29ubi5yYXRlTGltaXRSZXNldEF0ICE9PSBudWxsKSB7XG4gICAgICBjb25zdCBub3dTZWMgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcbiAgICAgIGlmIChub3dTZWMgPCBjb25uLnJhdGVMaW1pdFJlc2V0QXQpIHJldHVybjtcbiAgICB9XG4gICAgLy8gQXBwbHkgdGhlIHBlcmlvZGljLWNoZWNrIGdhdGUgdG8gZXZlcnkgc3RhdHVzLCBub3QganVzdCAnb2snLiBUaGVcbiAgICAvLyBwcmV2aW91cyBiZWhhdmlvciByZS12ZXJpZmllZCBvbiBldmVyeSB3YWtlIHdoZW5ldmVyIHRoZSBjb25uZWN0aW9uXG4gICAgLy8gd2Fzbid0ICdvaycsIHdoaWNoIGR1cmluZyBhIHJhdGUtbGltaXQgd2luZG93IG1lYW50IDIgQVBJIGNhbGxzIHBlclxuICAgIC8vIFNXIHdha2UgKHZlcmlmeVJlcG9BY2Nlc3MgZG9lcyBHRVQgL3VzZXIgKyBHRVQgL3JlcG9zL3tvfS97cn0pLlxuICAgIGlmIChjb25uLmNoZWNrZWRBdCkge1xuICAgICAgY29uc3QgYWdlID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2UoY29ubi5jaGVja2VkQXQpO1xuICAgICAgaWYgKGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgY29uc3QgciA9IGF3YWl0IGNsaWVudC52ZXJpZnlSZXBvQWNjZXNzKCk7XG4gICAgLy8gUHJvYmUgdGhlIGNvbmZpZ3VyZWQgYnJhbmNoLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCBpcyBmaW5lIFx1MjAxNCBpdCdzXG4gICAgLy8gcm91dGluZSB0byBjYXB0dXJlIGludG8gYSB3b3JraW5nIGJyYW5jaCBcdTIwMTQgYnV0IGEgKm1pc3NpbmcqIGJyYW5jaFxuICAgIC8vIHdvdWxkIDQyMiBldmVyeSBjb21taXQuXG4gICAgbGV0IGJyYW5jaE9rID0gdHJ1ZTtcbiAgICBpZiAoc2V0dGluZ3MuYnJhbmNoICYmIHNldHRpbmdzLmJyYW5jaCAhPT0gci5kZWZhdWx0X2JyYW5jaCkge1xuICAgICAgYnJhbmNoT2sgPSBhd2FpdCBjbGllbnQuYnJhbmNoRXhpc3RzKHNldHRpbmdzLmJyYW5jaCk7XG4gICAgfVxuICAgIGNvbnN0IGNoZWNrV3JpdGUgPSBmb3JjZSB8fCBpc1dyaXRlQXV0aEVycm9yKGNvbm4uZXJyb3IpO1xuICAgIGlmIChicmFuY2hPayAmJiBjaGVja1dyaXRlKSB7XG4gICAgICBhd2FpdCBjbGllbnQudmVyaWZ5V3JpdGVBY2Nlc3MoKTtcbiAgICB9XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXM6ICdvaycsXG4gICAgICBsb2dpbjogci5sb2dpbixcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IG51bGwsXG4gICAgICBkZWZhdWx0QnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogYnJhbmNoT2ssXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IGluZm8oJ2Nvbm5lY3Rpb24gdmVyaWZpZWQnLCB7XG4gICAgICBsb2dpbjogci5sb2dpbixcbiAgICAgIHJlcG86IHIuZnVsbF9uYW1lLFxuICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXG4gICAgICBjb25maWd1cmVkX2JyYW5jaDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgY29uZmlndXJlZF9icmFuY2hfZXhpc3RzOiBicmFuY2hPayxcbiAgICAgIHdyaXRlX2FjY2VzczogY2hlY2tXcml0ZSA/ICdjaGVja2VkJyA6ICdub3RfY2hlY2tlZCcsXG4gICAgfSk7XG4gICAgaWYgKCFicmFuY2hPaykge1xuICAgICAgYXdhaXQgd2FybignY29uZmlndXJlZCBicmFuY2ggZG9lcyBub3QgZXhpc3Qgb24gcmVtb3RlJywge1xuICAgICAgICBjb25maWd1cmVkOiBzZXR0aW5ncy5icmFuY2gsXG4gICAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgICBmaXg6ICdvcGVuIFNldHRpbmdzIGFuZCBjaGFuZ2UgYnJhbmNoIHRvICcgKyByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgfSk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zdCBjYXQgPSBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciA/IGVyci5jYXRlZ29yeSA6ICd1bmtub3duJztcbiAgICBjb25zdCBzdGF0dXM6IENvbm5lY3Rpb25TdGF0ZVsnc3RhdHVzJ10gPVxuICAgICAgY2F0ID09PSAnYXV0aCdcbiAgICAgICAgPyAnYXV0aC1lcnJvcidcbiAgICAgICAgOiBjYXQgPT09ICdyYXRlLWxpbWl0J1xuICAgICAgICAgID8gJ3JhdGUtbGltaXRlZCdcbiAgICAgICAgICA6IGNhdCA9PT0gJ25ldHdvcmsnXG4gICAgICAgICAgICA/ICduZXR3b3JrLWVycm9yJ1xuICAgICAgICAgICAgOiAnYXV0aC1lcnJvcic7XG4gICAgY29uc3QgcmVzZXRBdCA9XG4gICAgICBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBjYXQgPT09ICdyYXRlLWxpbWl0JyA/IGVyci5yYXRlTGltaXRSZXNldEF0IDogbnVsbDtcbiAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgIHN0YXR1cyxcbiAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLm1lc3NhZ2UsXG4gICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXG4gICAgfSk7XG4gICAgYXdhaXQgd2FybignY29ubmVjdGlvbiBjaGVjayBmYWlsZWQnLCB7XG4gICAgICBjYXRlZ29yeTogY2F0LFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogcmVzZXRBdCxcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICB9KTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQWNjb3VudHNMaXN0KGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQpIHtcbiAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKCFmb3JjZSkge1xuICAgIC8vIFNraXAgd2hpbGUgaW5zaWRlIGEga25vd24gcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IGFjY291bnRzLnlhbWwgaXMgZmV0Y2hlZFxuICAgIC8vIHZpYSBhdXRoZW50aWNhdGVkIHJhdy5naXRodWJ1c2VyY29udGVudC5jb20sIHdoaWNoIGNvdW50cyBhZ2FpbnN0IHRoZVxuICAgIC8vIHNhbWUgcXVvdGEuXG4gICAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xuICAgICAgY29uc3Qgbm93U2VjID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gICAgICBpZiAobm93U2VjIDwgY29ubi5yYXRlTGltaXRSZXNldEF0KSByZXR1cm47XG4gICAgfVxuICAgIC8vIFNraXAgaWYgd2UgcmVmcmVzaGVkIHJlY2VudGx5LiBhY2NvdW50cy55YW1sIGNoYW5nZXMgcmFyZWx5IFx1MjAxNCB0aGUgb2xkXG4gICAgLy8gY29kZSByZS1mZXRjaGVkIGl0IG9uIGV2ZXJ5IFNXIHdha2UsIHdoaWNoIGR1cmluZyBoZWF2eSBicm93c2luZyBtZWFudFxuICAgIC8vIGEgR2l0SHViIGNhbGwgZXZlcnkgZmV3IHNlY29uZHMgZXZlbiB3aGVuIG5vdGhpbmcgd2FzIGJlaW5nIGNhcHR1cmVkLlxuICAgIGNvbnN0IGxhc3RSZWZyZXNoZWQgPSBhd2FpdCBnZXRBY2NvdW50c1JlZnJlc2hlZEF0KCk7XG4gICAgaWYgKGxhc3RSZWZyZXNoZWQpIHtcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGxhc3RSZWZyZXNoZWQpO1xuICAgICAgaWYgKE51bWJlci5pc0Zpbml0ZShhZ2UpICYmIGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IGNsaWVudC5mZXRjaFJhd1RleHQoJ2NvbmZpZy9hY2NvdW50cy55YW1sJyk7XG4gICAgaWYgKCF0ZXh0KSB7XG4gICAgICBpZiAoZm9yY2UpIGF3YWl0IHdhcm4oJ2FjY291bnRzLnlhbWwgbm90IGZvdW5kIGluIHJlcG87IHVzaW5nIGZhbGxiYWNrJyk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcGFyc2VkID0gcGFyc2VBY2NvdW50c1lhbWwodGV4dCk7XG4gICAgaWYgKHBhcnNlZC5sZW5ndGggPT09IDApIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2FjY291bnRzLnlhbWwgcGFyc2VkIGVtcHR5OyBrZWVwaW5nIGZhbGxiYWNrJyk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50cyhbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdKTtcbiAgICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgYXdhaXQgc2V0QWNjb3VudHMocGFyc2VkKTtcbiAgICBhd2FpdCByZWZyZXNoQXJjaGl2ZVNuYXBzaG90KGNsaWVudCwgZm9yY2UpO1xuICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcbiAgICBpZiAoZm9yY2UpIGF3YWl0IGluZm8oJ2FjY291bnRzIGxpc3QgcmVmcmVzaGVkJywgeyBjb3VudDogcGFyc2VkLmxlbmd0aCB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybigncmVmcmVzaCBhY2NvdW50cyBmYWlsZWQ7IGtlZXBpbmcgY3VycmVudCBsaXN0JywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQXJjaGl2ZVNuYXBzaG90KGNsaWVudDogR2l0SHViQ2xpZW50LCBmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCB0ZXh0ID0gYXdhaXQgY2xpZW50LmZldGNoUmF3VGV4dCgnZGF0YS9tYW5pZmVzdC5qc29uJyk7XG4gIGlmICghdGV4dCkge1xuICAgIGF3YWl0IHNldEFyY2hpdmVTbmFwc2hvdChudWxsKTtcbiAgICBpZiAoZm9yY2UpIGF3YWl0IHdhcm4oJ2FyY2hpdmUgbWFuaWZlc3Qgbm90IGZvdW5kOyBvbGQtdHdlZXQgZGV0ZWN0aW9uIGRpc2FibGVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIHRyeSB7XG4gICAgY29uc3Qgc25hcHNob3QgPSBwYXJzZUFyY2hpdmVTbmFwc2hvdChKU09OLnBhcnNlKHRleHQpIGFzIHVua25vd24pO1xuICAgIGF3YWl0IHNldEFyY2hpdmVTbmFwc2hvdChzbmFwc2hvdCk7XG4gICAgaWYgKGZvcmNlKSB7XG4gICAgICBhd2FpdCBpbmZvKCdhcmNoaXZlIHNuYXBzaG90IHJlZnJlc2hlZCcsIHtcbiAgICAgICAgYWNjb3VudHM6IE9iamVjdC5rZXlzKHNuYXBzaG90LmFjY291bnRzKS5sZW5ndGgsXG4gICAgICAgIGdlbmVyYXRlZF9hdDogc25hcHNob3QuZ2VuZXJhdGVkX2F0LFxuICAgICAgfSk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdhcmNoaXZlIHNuYXBzaG90IHBhcnNlIGZhaWxlZDsgb2xkLXR3ZWV0IGRldGVjdGlvbiBkaXNhYmxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbn1cblxuLy8gLS0tIFN0YXRlIGJyb2FkY2FzdCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBicm9hZGNhc3RTdGF0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc3RhdGUgPSBhd2FpdCBidWlsZFN0YXRlKCk7XG4gIGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdzdGF0ZS1jaGFuZ2VkJywgc3RhdGUgfSkuY2F0Y2goKCkgPT4ge30pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBidWlsZFN0YXRlKCk6IFByb21pc2U8RXh0ZW5zaW9uU3RhdGU+IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgbGV0IHRhYkNvdW50ID0gMDtcbiAgdHJ5IHtcbiAgICBjb25zdCB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcbiAgICB0YWJDb3VudCA9IHRhYnMubGVuZ3RoO1xuICB9IGNhdGNoIHtcbiAgICAvLyB0YWJzLnF1ZXJ5IGlzIGFsbG93ZWQgYnkgdGhlIG1hbmlmZXN0IGJ1dCBjYW4gdHJhbnNpZW50bHkgZmFpbFxuICAgIC8vIGFyb3VuZCBleHRlbnNpb24gc3RhcnR1cDsgc3VyZmFjaW5nIDAgaXMgZmluZS5cbiAgfVxuICBjb25zdCByZWZldGNoUXVldWVkID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcbiAgY29uc3QgbWVkaWFDcmF3bFF1ZXVlZCA9IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCk7XG4gIGNvbnN0IHRocmVhZE9wZW5RdWV1ZWQgPSBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpO1xuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xTZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgY29uc3QgdGhyZWFkT3BlblNlc3MgPSBhd2FpdCBnZXRUaHJlYWRPcGVuU2Vzc2lvbigpO1xuICBjb25zdCBhdXRvU2Nyb2xsU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gIGNvbnN0IHJlY2VudFR3ZWV0U2lnaHRpbmdzID0gYXdhaXQgZ2V0UmVjZW50VHdlZXRTaWdodGluZ3MoKTtcbiAgcmV0dXJuIHtcbiAgICB2ZXJzaW9uOiBFWFRfVkVSU0lPTixcbiAgICBzZXR0aW5nczogcmVkYWN0U2V0dGluZ3Moc2V0dGluZ3MpLFxuICAgIGNvbm5lY3Rpb246IGNvbm4sXG4gICAgYWNjb3VudHMsXG4gICAgY291bnRlcnMsXG4gICAgYXV0b1Njcm9sbDoge1xuICAgICAgYWN0aXZlOiBhdXRvU2Nyb2xsU2VzcyAhPT0gbnVsbCAmJiBhdXRvU2Nyb2xsVGltZXIgIT09IG51bGwsXG4gICAgICB0YWJDb3VudCxcbiAgICAgIHNjcm9sbENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uc2Nyb2xsQ291bnQgPz8gMCxcbiAgICAgIGluZ2VzdGVkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5pbmdlc3RlZENvdW50ID8/IDAsXG4gICAgICBpbmdlc3RlZE5ld0NvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uaW5nZXN0ZWROZXdDb3VudCA/PyAwLFxuICAgICAgaW5nZXN0ZWRFeGlzdGluZ0NvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uaW5nZXN0ZWRFeGlzdGluZ0NvdW50ID8/IDAsXG4gICAgICBza2lwcGVkT2xkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5za2lwcGVkT2xkQ291bnQgPz8gMCxcbiAgICAgIGV4cGFuZGVkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5leHBhbmRlZENvdW50ID8/IDAsXG4gICAgfSxcbiAgICByZWZldGNoUXVldWU6IHtcbiAgICAgIHRvdGFsOiByZWZldGNoUXVldWVkLFxuICAgICAgcnVubmluZzogcmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsLFxuICAgICAgcHJvY2Vzc2VkOiByZWZldGNoU2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gICAgICB0b3RhbF9hdF9zdGFydDogcmVmZXRjaFNlc3M/LnRvdGFsQXRTdGFydCA/PyAwLFxuICAgIH0sXG4gICAgbWVkaWFDcmF3bFF1ZXVlOiB7XG4gICAgICB0b3RhbDogbWVkaWFDcmF3bFF1ZXVlZCxcbiAgICAgIHJ1bm5pbmc6IG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcbiAgICAgIHByb2Nlc3NlZDogbWVkaWFDcmF3bFNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IG1lZGlhQ3Jhd2xTZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcbiAgICB9LFxuICAgIHRocmVhZE9wZW5RdWV1ZToge1xuICAgICAgdG90YWw6IHRocmVhZE9wZW5RdWV1ZWQsXG4gICAgICBydW5uaW5nOiB0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwsXG4gICAgICBwcm9jZXNzZWQ6IHRocmVhZE9wZW5TZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiB0aHJlYWRPcGVuU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXG4gICAgfSxcbiAgICByZWNlbnRUd2VldFNpZ2h0aW5ncyxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcmVkYWN0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBFeHRlbnNpb25TdGF0ZVsnc2V0dGluZ3MnXSB7XG4gIHJldHVybiB7XG4gICAgb3duZXI6IHMub3duZXIsXG4gICAgcmVwbzogcy5yZXBvLFxuICAgIGJyYW5jaDogcy5icmFuY2gsXG4gICAgZW5hYmxlZDogcy5lbmFibGVkLFxuICAgIGF1dG9DYXB0dXJlOiBzLmF1dG9DYXB0dXJlLFxuICAgIGNvbmZpZ3VyZWRBdDogcy5jb25maWd1cmVkQXQsXG4gICAgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyxcbiAgICB1cGRhdGVFeGlzdGluZzogcy51cGRhdGVFeGlzdGluZyxcbiAgICBsb3dCYW5kd2lkdGhCcm93c2luZzogcy5sb3dCYW5kd2lkdGhCcm93c2luZyxcbiAgICBwYXRTZXQ6IHMucGF0Lmxlbmd0aCA+IDAsXG4gICAgcGF0U3VmZml4OiBzLnBhdC5sZW5ndGggPj0gNCA/IHMucGF0LnNsaWNlKC00KSA6ICcnLFxuICB9O1xufVxuXG5mdW5jdGlvbiBwYXJzZUFyY2hpdmVTbmFwc2hvdChyYXc6IHVua25vd24pOiBBcmNoaXZlU25hcHNob3Qge1xuICBpZiAoIXJhdyB8fCB0eXBlb2YgcmF3ICE9PSAnb2JqZWN0JykgdGhyb3cgbmV3IEVycm9yKCdtYW5pZmVzdCBpcyBub3QgYW4gb2JqZWN0Jyk7XG4gIGNvbnN0IG1hbmlmZXN0ID0gcmF3IGFzIHsgZ2VuZXJhdGVkX2F0PzogdW5rbm93bjsgYWNjb3VudHM/OiB1bmtub3duIH07XG4gIGlmICghQXJyYXkuaXNBcnJheShtYW5pZmVzdC5hY2NvdW50cykpIHRocm93IG5ldyBFcnJvcignbWFuaWZlc3QuYWNjb3VudHMgaXMgbm90IGFuIGFycmF5Jyk7XG4gIGNvbnN0IGFjY291bnRzOiBBcmNoaXZlU25hcHNob3RbJ2FjY291bnRzJ10gPSB7fTtcbiAgZm9yIChjb25zdCBlbnRyeSBvZiBtYW5pZmVzdC5hY2NvdW50cykge1xuICAgIGlmICghZW50cnkgfHwgdHlwZW9mIGVudHJ5ICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgY29uc3Qgcm93ID0gZW50cnkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgY29uc3QgaGFuZGxlID0gdHlwZW9mIHJvdy5oYW5kbGUgPT09ICdzdHJpbmcnID8gcm93LmhhbmRsZSA6ICcnO1xuICAgIGlmICghaGFuZGxlIHx8IGhhbmRsZSA9PT0gJ19taXNjJykgY29udGludWU7XG4gICAgYWNjb3VudHNbaGFuZGxlLnRvTG93ZXJDYXNlKCldID0ge1xuICAgICAgaGFuZGxlLFxuICAgICAgbGF0ZXN0X3Bvc3RfYXQ6IHR5cGVvZiByb3cubGF0ZXN0X3Bvc3RfYXQgPT09ICdzdHJpbmcnID8gcm93LmxhdGVzdF9wb3N0X2F0IDogbnVsbCxcbiAgICAgIGxhdGVzdF9jYXB0dXJlX2F0OiB0eXBlb2Ygcm93LmxhdGVzdF9jYXB0dXJlX2F0ID09PSAnc3RyaW5nJyA/IHJvdy5sYXRlc3RfY2FwdHVyZV9hdCA6IG51bGwsXG4gICAgICByb3dfY291bnQ6IHR5cGVvZiByb3cucm93X2NvdW50ID09PSAnbnVtYmVyJyA/IHJvdy5yb3dfY291bnQgOiBudWxsLFxuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBnZW5lcmF0ZWRfYXQ6IHR5cGVvZiBtYW5pZmVzdC5nZW5lcmF0ZWRfYXQgPT09ICdzdHJpbmcnID8gbWFuaWZlc3QuZ2VuZXJhdGVkX2F0IDogbnVsbCxcbiAgICBmZXRjaGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgYWNjb3VudHMsXG4gIH07XG59XG5cbmZ1bmN0aW9uIGFyY2hpdmVTbmFwc2hvdEhhc1R3ZWV0KHQ6IENhbm9uaWNhbFR3ZWV0LCBzbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbCk6IGJvb2xlYW4ge1xuICBpZiAoIXNuYXBzaG90KSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGVudHJ5ID0gc25hcHNob3QuYWNjb3VudHNbdC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpXTtcbiAgaWYgKCFlbnRyeT8ubGF0ZXN0X3Bvc3RfYXQpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgcG9zdGVkID0gRGF0ZS5wYXJzZSh0LnBvc3RlZF9hdCk7XG4gIGNvbnN0IGxhdGVzdCA9IERhdGUucGFyc2UoZW50cnkubGF0ZXN0X3Bvc3RfYXQpO1xuICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHBvc3RlZCkgJiYgTnVtYmVyLmlzRmluaXRlKGxhdGVzdCkgJiYgcG9zdGVkIDw9IGxhdGVzdDtcbn1cblxuZnVuY3Rpb24gYnVpbGRUd2VldFNpZ2h0aW5nKFxuICB0OiBDYW5vbmljYWxUd2VldCxcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgc2VlbkF0OiBzdHJpbmcsXG4gIGZyZXNobmVzczogJ25ldycgfCAnZXhpc3RpbmcnID0gJ25ldycsXG4gIGFjdGlvbjogVHdlZXRTaWdodGluZ1snYWN0aW9uJ10gPSAnYnVmZmVyZWQnXG4pOiBUd2VldFNpZ2h0aW5nIHtcbiAgcmV0dXJuIHtcbiAgICB0d2VldF9pZDogdC50d2VldF9pZCxcbiAgICBhY2NvdW50X2hhbmRsZTogdC5hY2NvdW50X2hhbmRsZSxcbiAgICBwb3N0ZWRfYXQ6IHQucG9zdGVkX2F0LFxuICAgIHRleHQ6IHQudGV4dF9yZXNvbHZlZCB8fCB0LnRleHQsXG4gICAgdHdlZXRfdHlwZTogdC50d2VldF90eXBlLFxuICAgIHR3ZWV0X3VybDogdC50d2VldF91cmwsXG4gICAgc2Vlbl9hdDogc2VlbkF0LFxuICAgIGVuZHBvaW50LFxuICAgIGFyY2hpdmVfc3RhdHVzOiBmcmVzaG5lc3MgPT09ICdleGlzdGluZycgPyAnc2F2ZWQnIDogJ25ldycsXG4gICAgYWN0aW9uLFxuICB9O1xufVxuXG5mdW5jdGlvbiBpc1dyaXRlQXV0aEVycm9yKG1lc3NhZ2U6IHN0cmluZyB8IG51bGwpOiBib29sZWFuIHtcbiAgcmV0dXJuIChcbiAgICB0eXBlb2YgbWVzc2FnZSA9PT0gJ3N0cmluZycgJiZcbiAgICAvUmVzb3VyY2Ugbm90IGFjY2Vzc2libGUgYnkgcGVyc29uYWwgYWNjZXNzIHRva2VufFxcL2dpdFxcL2Jsb2JzfFxcL2dpdFxcL3JlZnMvaS50ZXN0KG1lc3NhZ2UpXG4gICk7XG59XG5cbmZ1bmN0aW9uIGlzb0NvbXBhY3QoaXNvOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyAyMDI1LTA0LTEyVDE0OjIzOjAxLjAwMFogXHUyMTkyIDIwMjUtMDQtMTJUMTQyMzAxWlxuICBjb25zdCBkID0gbmV3IERhdGUoaXNvKTtcbiAgaWYgKE51bWJlci5pc05hTihkLmdldFRpbWUoKSkpIHJldHVybiBpc28ucmVwbGFjZSgvWzouXS9nLCAnJyk7XG4gIGNvbnN0IHBhZCA9IChuOiBudW1iZXIsIHcgPSAyKSA9PiBTdHJpbmcobikucGFkU3RhcnQodywgJzAnKTtcbiAgcmV0dXJuIChcbiAgICBgJHtkLmdldFVUQ0Z1bGxZZWFyKCl9LSR7cGFkKGQuZ2V0VVRDTW9udGgoKSArIDEpfS0ke3BhZChkLmdldFVUQ0RhdGUoKSl9YCArXG4gICAgYFQke3BhZChkLmdldFVUQ0hvdXJzKCkpfSR7cGFkKGQuZ2V0VVRDTWludXRlcygpKX0ke3BhZChkLmdldFVUQ1NlY29uZHMoKSl9WmBcbiAgKTtcbn1cblxuZnVuY3Rpb24gdmlld2VyVXJsKHM6IFNldHRpbmdzKTogc3RyaW5nIHtcbiAgcmV0dXJuIGBodHRwczovLyR7cy5vd25lcn0uZ2l0aHViLmlvLyR7cy5yZXBvfS9gO1xufVxuXG4vKipcbiAqIFdhbGsgYG5vZGVgIGNvbGxlY3RpbmcgZG90dGVkIGtleSBwYXRocyB1cCB0byBgbWF4RGVwdGhgIGRlZXAuIEFycmF5XG4gKiBpbmRpY2VzIGNvbGxhcHNlIHRvIGBbMF1gICh3ZSBvbmx5IGRlc2NlbmQgaW50byB0aGUgZmlyc3QgZWxlbWVudCkuIFVzZWRcbiAqIHRvIHN1cmZhY2UgdGhlIHN0cnVjdHVyYWwgc2tlbGV0b24gb2YgYW4gdW5mYW1pbGlhciBHcmFwaFFMIHJlc3BvbnNlXG4gKiB3aXRob3V0IGluY2x1ZGluZyBhbnkgZGF0YSB2YWx1ZXMuXG4gKi9cbi8qKiBDb2xsZWN0IGV2ZXJ5IGRpc3RpbmN0IGBfX3R5cGVuYW1lYCB2YWx1ZSBmb3VuZCBhbnl3aGVyZSBpbiB0aGUgdHJlZS4gKi9cbmZ1bmN0aW9uIHByb2JlVHlwZW5hbWVzKG5vZGU6IHVua25vd24pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKHR5cGVvZiBvYmouX190eXBlbmFtZSA9PT0gJ3N0cmluZycpIHNlZW4uYWRkKG9iai5fX3R5cGVuYW1lKTtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBbLi4uc2Vlbl0uc29ydCgpO1xufVxuXG4vKipcbiAqIEZpbmQgdGhlIGZpcnN0IG5vZGUgYW55d2hlcmUgaW4gdGhlIHRyZWUgd2hvc2UgYF9fdHlwZW5hbWVgIG1hdGNoZXMgYW5kXG4gKiByZXR1cm4gaXRzIHRvcC1sZXZlbCBrZXkgbGlzdCAoc29ydGVkKS4gVXNlZnVsIGZvciBkaXNjb3ZlcmluZyB3aGF0IGZpZWxkc1xuICogWCBpcyBhY3R1YWxseSBzaGlwcGluZyBmb3IgYSBnaXZlbiBub2RlIHR5cGUgYWZ0ZXIgYSBzY2hlbWEgY2hhbmdlLlxuICovXG5mdW5jdGlvbiBwcm9iZUZpcnN0VHlwZVNoYXBlKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcpOiBzdHJpbmdbXSB8IG51bGwge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobiA9PT0gbnVsbCB8fCB0eXBlb2YgbiAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShuKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG9iaiA9IG4gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICBpZiAob2JqLl9fdHlwZW5hbWUgPT09IHR5cGVuYW1lKSB7XG4gICAgICAgIHJldHVybiBPYmplY3Qua2V5cyhvYmopLnNvcnQoKTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vKipcbiAqIEZpbmQgdGhlIGZpcnN0IG5vZGUgd2l0aCBgX190eXBlbmFtZSA9PT0gdHlwZW5hbWVgLCB0aGVuIGRlc2NlbmQgdGhyb3VnaFxuICogdGhlIGdpdmVuIGtleSBwYXRoLCBhbmQgcmV0dXJuIHRoZSB0b3AtbGV2ZWwga2V5cyBvZiB3aGF0ZXZlciBpcyBhdCB0aGVcbiAqIGVuZC4gUmV0dXJucyBhIG1hcmtlciBzdHJpbmcgd2hlbiB0aGUgcGF0aCBsZWFkcyBzb21ld2hlcmUgbm9uLW9iamVjdCBzb1xuICogd2UgY2FuIHRlbGwgYXBhcnQgXCJhYnNlbnRcIiBmcm9tIFwicHJlc2VudCBidXQgbm90IGFuIG9iamVjdFwiLlxuICovXG5mdW5jdGlvbiBwcm9iZVR5cGVkTmVzdGVkKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcsIHBhdGg6IHN0cmluZ1tdKTogdW5rbm93biB7XG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIGxldCBmb3VuZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsID0gbnVsbDtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSB0eXBlbmFtZSkge1xuICAgICAgICBmb3VuZCA9IG9iajtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICBpZiAoIWZvdW5kKSByZXR1cm4gbnVsbDtcbiAgbGV0IGN1cjogdW5rbm93biA9IGZvdW5kO1xuICBmb3IgKGNvbnN0IHNlZyBvZiBwYXRoKSB7XG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgcmV0dXJuIGA8JHtjdXIgPT09IG51bGwgPyAnbnVsbCcgOiB0eXBlb2YgY3VyfT5gO1xuICAgIGN1ciA9IChjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW3NlZ107XG4gIH1cbiAgaWYgKGN1ciA9PT0gdW5kZWZpbmVkKSByZXR1cm4gJzxtaXNzaW5nPic7XG4gIGlmIChjdXIgPT09IG51bGwpIHJldHVybiAnPG51bGw+JztcbiAgaWYgKHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSByZXR1cm4gYDwke3R5cGVvZiBjdXJ9PmA7XG4gIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHJldHVybiBgPGFycmF5IGxlbj0ke2N1ci5sZW5ndGh9PmA7XG4gIHJldHVybiBPYmplY3Qua2V5cyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLnNvcnQoKTtcbn1cblxuZnVuY3Rpb24gc2hvcnRlblVybCh1OiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBBY3Rpdml0eS10YWlsIGNvbnRleHQgaXMgbW9yZSB1c2VmdWwgd2l0aCBqdXN0IHRoZSBwYXRoOyBmdWxsIFVSTHMgYmVjb21lXG4gIC8vIGhhcmQgdG8gcmVhZCBhdCB0aGUgc2lkZWJhcidzIHdpZHRoLlxuICB0cnkge1xuICAgIGNvbnN0IHBhcnNlZCA9IG5ldyBVUkwodSk7XG4gICAgY29uc3QgcGF0aCA9IHBhcnNlZC5wYXRobmFtZSArIChwYXJzZWQuc2VhcmNoID8gJz9cdTIwMjYnIDogJycpO1xuICAgIHJldHVybiBwYXJzZWQuaG9zdCA9PT0gJ3guY29tJyB8fCBwYXJzZWQuaG9zdCA9PT0gJ3R3aXR0ZXIuY29tJ1xuICAgICAgPyBwYXRoXG4gICAgICA6IGAke3BhcnNlZC5ob3N0fSR7cGF0aH1gO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gdS5sZW5ndGggPiA4MCA/IGAke3Uuc2xpY2UoMCwgODApfVx1MjAyNmAgOiB1O1xuICB9XG59XG5cbi8vIC0tLSBEZXYgaGVscGVycyBleHBvc2VkIG9uIGdsb2JhbFRoaXMgZm9yIHRoZSBkZXZ0b29scyBjb25zb2xlIC0tLS0tLS0tLS1cbi8vIChlLmcuIGBfX2ltbUFyY2hpdmUuY2xlYXJBbGwoKWAgaW4gdGhlIGJhY2tncm91bmQgd29ya2VyJ3MgZGV2dG9vbHMpLlxuXG4oZ2xvYmFsVGhpcyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuX19pbW1BcmNoaXZlID0ge1xuICBjbGVhckFsbCxcbiAgYWN0aXZpdHk6IGdldEFjdGl2aXR5LFxuICBhY2NvdW50czogZ2V0QWNjb3VudHMsXG4gIGJ1ZmZlcnM6IGdldFJ1bkJ1ZmZlcnMsXG4gIGZsdXNoQWxsOiAoKSA9PiBmbHVzaEFsbCgnZGV2dG9vbHMnKSxcbiAgc3RhdGU6IGJ1aWxkU3RhdGUsXG4gIHJlZmV0Y2hRdWV1ZTogZ2V0UmVmZXRjaFF1ZXVlLFxuICBzdGFydFJlZmV0Y2g6IHN0YXJ0UmVmZXRjaExvb3AsXG4gIGNhbmNlbFJlZmV0Y2g6IGNhbmNlbFJlZmV0Y2hMb29wLFxuICBtZWRpYUNyYXdsUXVldWU6IGdldE1lZGlhQ3Jhd2xRdWV1ZSxcbiAgc3RhcnRNZWRpYUNyYXdsOiBzdGFydE1lZGlhQ3Jhd2xMb29wLFxuICBjYW5jZWxNZWRpYUNyYXdsOiBjYW5jZWxNZWRpYUNyYXdsTG9vcCxcbiAgdGhyZWFkT3BlblF1ZXVlOiBnZXRUaHJlYWRPcGVuUXVldWUsXG4gIHN0YXJ0VGhyZWFkT3Blbjogc3RhcnRUaHJlYWRPcGVuTG9vcCxcbiAgY2FuY2VsVGhyZWFkT3BlbjogY2FuY2VsVGhyZWFkT3Blbkxvb3AsXG59O1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBRU8sSUFBTSxtQkFBNkI7QUFBQSxFQUN4QyxLQUFLO0FBQUEsRUFDTCxPQUFPO0FBQUEsRUFDUCxNQUFNO0FBQUE7QUFBQTtBQUFBLEVBR04sUUFBUTtBQUFBLEVBQ1IsU0FBUztBQUFBLEVBQ1QsYUFBYTtBQUFBLEVBQ2IsY0FBYztBQUFBLEVBQ2QsdUJBQXVCO0FBQUEsRUFDdkIsZ0JBQWdCO0FBQUEsRUFDaEIsc0JBQXNCO0FBQ3hCO0FBRU8sSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxzQkFBc0I7QUFJNUIsSUFBTSxvQkFBcUM7QUFBQSxFQUNoRCxFQUFFLFFBQVEsVUFBVSxPQUFPLG1DQUFtQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsVUFBVSxPQUFPLDRDQUE0QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsT0FBTyxPQUFPLHNDQUFzQyxVQUFVLE9BQU87QUFBQSxFQUMvRSxFQUFFLFFBQVEsU0FBUyxPQUFPLDZDQUE2QyxVQUFVLE9BQU87QUFBQSxFQUN4RixFQUFFLFFBQVEsY0FBYyxPQUFPLG1CQUFtQixVQUFVLE9BQU87QUFBQSxFQUNuRSxFQUFFLFFBQVEsWUFBWSxPQUFPLCtCQUErQixVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLGtDQUFrQyxVQUFVLE9BQU87QUFBQSxFQUM3RSxFQUFFLFFBQVEsU0FBUyxPQUFPLDRCQUE0QixVQUFVLE9BQU87QUFBQSxFQUN2RSxFQUFFLFFBQVEsbUJBQW1CLE9BQU8scUJBQXFCLFVBQVUsT0FBTztBQUFBLEVBQzFFLEVBQUUsUUFBUSxZQUFZLE9BQU8sa0JBQWtCLFVBQVUsT0FBTztBQUFBLEVBQ2hFLEVBQUUsUUFBUSxrQkFBa0IsT0FBTyxrQkFBa0IsVUFBVSxPQUFPO0FBQUEsRUFDdEUsRUFBRSxRQUFRLGdCQUFnQixPQUFPLG1CQUFtQixVQUFVLE9BQU87QUFDdkU7QUFHTyxJQUFNLGtCQUF1QyxvQkFBSSxJQUFJO0FBQUEsRUFDMUQ7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGLENBQUM7QUFXTSxJQUFNLG9CQUF5QyxvQkFBSSxJQUFJLENBQUMsb0JBQW9CLGNBQWMsQ0FBQztBQXVCM0YsSUFBTSx3QkFBd0I7QUFHOUIsSUFBTSxnQkFBZ0I7QUFHdEIsSUFBTSxzQkFBc0I7QUFHNUIsSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLO0FBRWhELElBQU0sbUJBQW1COzs7QUMzRWhDLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sa0JBQWtCO0FBRXhCLElBQUksa0JBQW9DO0FBQ3hDLElBQUksc0JBQXFDO0FBRXpDLFNBQVMsU0FBUyxLQUF5QjtBQUN6QyxNQUFJLElBQUk7QUFDUixhQUFXLEtBQUssSUFBSyxNQUFLLE9BQU8sYUFBYSxDQUFDO0FBQy9DLFNBQU8sS0FBSyxDQUFDO0FBQ2Y7QUFFQSxTQUFTLFdBQVcsR0FBdUI7QUFDekMsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixRQUFNLE1BQU0sSUFBSSxXQUFXLElBQUksTUFBTTtBQUNyQyxXQUFTLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxJQUFLLEtBQUksQ0FBQyxJQUFJLElBQUksV0FBVyxDQUFDO0FBQzlELFNBQU87QUFDVDtBQUVBLGVBQWUsbUJBQW1FO0FBQ2hGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksZ0JBQWdCO0FBQy9ELFFBQU0sSUFBSSxPQUFPLGdCQUFnQjtBQUNqQyxNQUFJLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxHQUFHO0FBQ3pDLFdBQU8sRUFBRSxTQUFTLEdBQUcsTUFBTSxXQUFXLENBQUMsRUFBRTtBQUFBLEVBQzNDO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsUUFBTSxVQUFVLFNBQVMsSUFBSTtBQUM3QixRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGdCQUFnQixHQUFHLFFBQVEsQ0FBQztBQUMvRCxTQUFPLEVBQUUsU0FBUyxLQUFLO0FBQ3pCO0FBRUEsZUFBZSxZQUFnQztBQUM3QyxRQUFNLEVBQUUsU0FBUyxLQUFLLElBQUksTUFBTSxpQkFBaUI7QUFDakQsTUFBSSxvQkFBb0IsUUFBUSx3QkFBd0IsU0FBUztBQUMvRCxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRTtBQUFBLElBQzdCLEdBQUcsUUFBUSxRQUFRLEVBQUUsSUFBSSxRQUFRLFFBQVEsWUFBWSxFQUFFLE9BQU87QUFBQSxFQUNoRTtBQUNBLFFBQU0sV0FBVyxJQUFJLFdBQVcsS0FBSyxTQUFTLEtBQUssTUFBTTtBQUN6RCxXQUFTLElBQUksTUFBTSxDQUFDO0FBQ3BCLFdBQVMsSUFBSSxNQUFNLEtBQUssTUFBTTtBQUM5QixRQUFNLE9BQU8sTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLFFBQVE7QUFDM0QsUUFBTSxNQUFNLE1BQU0sT0FBTyxPQUFPLFVBQVUsT0FBTyxNQUFNLEVBQUUsTUFBTSxVQUFVLEdBQUcsT0FBTztBQUFBLElBQ2pGO0FBQUEsSUFDQTtBQUFBLEVBQ0YsQ0FBQztBQUNELG9CQUFrQjtBQUNsQix3QkFBc0I7QUFDdEIsU0FBTztBQUNUO0FBRU8sU0FBUyxlQUFlLEdBQW9CO0FBQ2pELFNBQU8sRUFBRSxXQUFXLGVBQWU7QUFDckM7QUFFQSxlQUFzQixXQUFXLFdBQW9DO0FBQ25FLE1BQUksQ0FBQyxVQUFXLFFBQU87QUFDdkIsUUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixRQUFNLEtBQUssT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUNwRCxRQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxJQUM3QixFQUFFLE1BQU0sV0FBVyxHQUFHO0FBQUEsSUFDdEI7QUFBQSxJQUNBLElBQUksWUFBWSxFQUFFLE9BQU8sU0FBUztBQUFBLEVBQ3BDO0FBQ0EsU0FBTyxHQUFHLGVBQWUsR0FBRyxTQUFTLEVBQUUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxXQUFXLEVBQUUsQ0FBQyxDQUFDO0FBQzFFO0FBRUEsZUFBc0IsV0FBVyxVQUFtQztBQUNsRSxNQUFJLENBQUMsU0FBVSxRQUFPO0FBR3RCLE1BQUksQ0FBQyxTQUFTLFdBQVcsZUFBZSxFQUFHLFFBQU87QUFDbEQsUUFBTSxRQUFRLFNBQVMsTUFBTSxnQkFBZ0IsTUFBTSxFQUFFLE1BQU0sR0FBRztBQUM5RCxNQUFJLE1BQU0sV0FBVyxFQUFHLFFBQU87QUFDL0IsUUFBTSxDQUFDLE9BQU8sS0FBSyxJQUFJO0FBQ3ZCLE1BQUksQ0FBQyxTQUFTLENBQUMsTUFBTyxRQUFPO0FBQzdCLE1BQUk7QUFDRixVQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssTUFBTSxPQUFPLE9BQU87QUFBQSxNQUM3QixFQUFFLE1BQU0sV0FBVyxHQUF1QjtBQUFBLE1BQzFDO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFDQSxXQUFPLElBQUksWUFBWSxFQUFFLE9BQU8sRUFBRTtBQUFBLEVBQ3BDLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGOzs7QUNYQSxJQUFNLHFCQUFzQztBQUFBLEVBQzFDLFFBQVE7QUFBQSxFQUNSLE9BQU87QUFBQSxFQUNQLFdBQVc7QUFBQSxFQUNYLE9BQU87QUFBQSxFQUNQLGVBQWU7QUFBQSxFQUNmLHdCQUF3QjtBQUFBLEVBQ3hCLGtCQUFrQjtBQUNwQjtBQUVBLElBQU0sV0FBeUI7QUFBQSxFQUM3QixVQUFVLEVBQUUsR0FBRyxpQkFBaUI7QUFBQSxFQUNoQyxVQUFVLENBQUMsR0FBRyxpQkFBaUI7QUFBQSxFQUMvQixxQkFBcUI7QUFBQSxFQUNyQixpQkFBaUI7QUFBQSxFQUNqQixZQUFZLEVBQUUsR0FBRyxtQkFBbUI7QUFBQSxFQUNwQyxVQUFVLENBQUM7QUFBQSxFQUNYLFlBQVksQ0FBQztBQUFBLEVBQ2IsVUFBVSxDQUFDO0FBQUEsRUFDWCxzQkFBc0IsQ0FBQztBQUFBLEVBQ3ZCLGdCQUFnQixDQUFDO0FBQUEsRUFDakIsY0FBYyxDQUFDO0FBQUEsRUFDZixpQkFBaUIsQ0FBQztBQUFBLEVBQ2xCLGlCQUFpQixDQUFDO0FBQUEsRUFDbEIsZ0JBQWdCLENBQUM7QUFBQSxFQUNqQixnQkFBZ0I7QUFBQSxFQUNoQixtQkFBbUI7QUFBQSxFQUNuQixtQkFBbUI7QUFBQSxFQUNuQixtQkFBbUI7QUFDckI7QUFFQSxlQUFlLE9BQXFDLEtBQWtDO0FBQ3BGLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksR0FBRztBQUNsRCxRQUFNLFFBQVEsT0FBTyxHQUFHO0FBQ3hCLE1BQUksVUFBVSxRQUFXO0FBQ3ZCLFdBQU8sZ0JBQWdCLFNBQVMsR0FBRyxDQUFDO0FBQUEsRUFDdEM7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxlQUFlLE9BQXFDLEtBQVEsT0FBdUM7QUFDakcsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUcsTUFBTSxDQUFDO0FBQ2xEO0FBSUEsZUFBc0IsY0FBaUM7QUFLckQsUUFBTSxTQUFTLE1BQU0sT0FBTyxVQUFVO0FBQ3RDLFFBQU0sU0FBUyxFQUFFLEdBQUcsa0JBQWtCLEdBQUcsT0FBTztBQUNoRCxNQUFJLE9BQU8sT0FBTyxlQUFlLE9BQU8sR0FBRyxHQUFHO0FBQzVDLFFBQUk7QUFDRixhQUFPLE1BQU0sTUFBTSxXQUFXLE9BQU8sR0FBRztBQUFBLElBQzFDLFFBQVE7QUFDTixhQUFPLE1BQU07QUFBQSxJQUNmO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLFlBQVksR0FBNEI7QUFHNUQsUUFBTSxVQUFvQixFQUFFLEdBQUcsRUFBRTtBQUNqQyxNQUFJLFFBQVEsT0FBTyxDQUFDLGVBQWUsUUFBUSxHQUFHLEdBQUc7QUFDL0MsWUFBUSxNQUFNLE1BQU0sV0FBVyxRQUFRLEdBQUc7QUFBQSxFQUM1QztBQUNBLFFBQU0sT0FBTyxZQUFZLE9BQU87QUFDbEM7QUFDQSxlQUFzQixlQUFlLE9BQTZDO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxPQUFPLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoQyxRQUFNLFlBQVksSUFBSTtBQUN0QixTQUFPO0FBQ1Q7QUFJQSxlQUFzQixjQUF3QztBQUM1RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQVksR0FBbUM7QUFDbkUsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUM1QjtBQUNBLGVBQXNCLHlCQUFpRDtBQUNyRSxTQUFPLE9BQU8scUJBQXFCO0FBQ3JDO0FBQ0EsZUFBc0IsdUJBQXVCLEtBQW1DO0FBQzlFLFFBQU0sT0FBTyx1QkFBdUIsR0FBRztBQUN6QztBQUlBLGVBQXNCLHFCQUFzRDtBQUMxRSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBRUEsZUFBc0IsbUJBQW1CLFVBQWlEO0FBQ3hGLFFBQU0sT0FBTyxtQkFBbUIsUUFBUTtBQUMxQztBQUlBLGVBQXNCLGdCQUEwQztBQUM5RCxRQUFNLElBQUksTUFBTSxPQUFPLFlBQVk7QUFFbkMsUUFBTSxNQUF1QjtBQUFBLElBQzNCLEdBQUc7QUFBQSxJQUNILGVBQWUsRUFBRSxrQkFBa0IsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUN4RCx3QkFDRSxFQUFFLDJCQUEyQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3BELGtCQUFrQixFQUFFLHFCQUFxQixTQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ2hFO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsY0FBYyxHQUFtQztBQUNyRSxRQUFNLE9BQU8sY0FBYyxDQUFDO0FBQzlCO0FBSUEsU0FBUyxXQUFtQjtBQUMxQixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDN0M7QUFFQSxlQUFzQixjQUF1RDtBQUMzRSxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUNBLGVBQXNCLFlBQ3BCLFFBQ0EsT0FDeUI7QUFDekIsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUs7QUFBQSxJQUN6QixZQUFZO0FBQUEsSUFDWixXQUFXLFNBQVM7QUFBQSxJQUNwQixlQUFlO0FBQUEsSUFDZixnQkFBZ0I7QUFBQSxJQUNoQixlQUFlO0FBQUEsRUFDakI7QUFDQSxNQUFJLElBQUksY0FBYyxTQUFTLEdBQUc7QUFDaEMsUUFBSSxZQUFZLFNBQVM7QUFDekIsUUFBSSxhQUFhO0FBQUEsRUFDbkI7QUFDQSxRQUFNLE9BQXVCLEVBQUUsR0FBRyxLQUFLLEdBQUcsTUFBTTtBQUNoRCxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsaUJBQWlCLFFBQWdCLE9BQThCO0FBQ25GLFFBQU0sWUFBWSxRQUFRLEVBQUUsZUFBZSxNQUFNLENBQUM7QUFDcEQ7QUFJQSxlQUFzQixnQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLFlBQVk7QUFDNUI7QUFFQSxlQUFzQixhQUFhLFFBQTJDO0FBQzVFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU0sS0FBSztBQUN4QjtBQUVBLGVBQXNCLGFBQWEsUUFBZ0IsS0FBK0I7QUFDaEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxNQUFJLE1BQU0sSUFBSTtBQUNkLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFFQSxlQUFzQixlQUFlLFFBQStCO0FBQ2xFLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsU0FBTyxJQUFJLE1BQU07QUFDakIsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUlBLGVBQXNCLGNBQW1DO0FBQ3ZELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBRUEsZUFBc0IsZUFBZSxJQUFtQztBQUN0RSxRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLE1BQUksUUFBUSxFQUFFO0FBQ2QsTUFBSSxJQUFJLFNBQVMsa0JBQW1CLEtBQUksU0FBUztBQUNqRCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGdCQUErQjtBQUNuRCxRQUFNLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDN0I7QUFJQSxJQUFNLDZCQUE2QjtBQUVuQyxlQUFzQiwwQkFBb0Q7QUFDeEUsU0FBTyxPQUFPLHNCQUFzQjtBQUN0QztBQUVBLGVBQXNCLDRCQUE0QixNQUFzQztBQUN0RixNQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLFFBQU0sTUFBTSxNQUFNLHdCQUF3QjtBQUMxQyxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLE9BQXdCLENBQUM7QUFDL0IsYUFBVyxPQUFPLE1BQU07QUFDdEIsVUFBTSxNQUFNLEdBQUcsSUFBSSxlQUFlLFlBQVksQ0FBQyxJQUFJLElBQUksUUFBUTtBQUMvRCxRQUFJLEtBQUssSUFBSSxHQUFHLEVBQUc7QUFDbkIsU0FBSyxJQUFJLEdBQUc7QUFDWixTQUFLLEtBQUssR0FBRztBQUFBLEVBQ2Y7QUFDQSxhQUFXLE9BQU8sS0FBSztBQUNyQixVQUFNLE1BQU0sR0FBRyxJQUFJLGVBQWUsWUFBWSxDQUFDLElBQUksSUFBSSxRQUFRO0FBQy9ELFFBQUksS0FBSyxJQUFJLEdBQUcsRUFBRztBQUNuQixTQUFLLElBQUksR0FBRztBQUNaLFNBQUssS0FBSyxHQUFHO0FBQUEsRUFDZjtBQUNBLE9BQUssU0FBUyxLQUFLLElBQUksS0FBSyxRQUFRLDBCQUEwQjtBQUM5RCxRQUFNLE9BQU8sd0JBQXdCLElBQUk7QUFDM0M7QUFJQSxlQUFzQixvQkFBNkU7QUFDakcsU0FBTyxPQUFPLGdCQUFnQjtBQUNoQztBQUVBLGVBQXNCLGtCQUNwQixLQUNlO0FBQ2YsUUFBTSxPQUFPLGtCQUFrQixHQUFHO0FBQ3BDO0FBVU8sU0FBUyxjQUNkLE9BQ0EsVUFDQSxTQUNBLFFBQ0EsY0FBdUIsT0FDZjtBQUNSLFNBQU8sR0FBRyxLQUFLLElBQUksUUFBUSxJQUFJLE9BQU8sSUFBSSxNQUFNLElBQUksY0FBYyxNQUFNLEdBQUc7QUFDN0U7QUFHQSxlQUFzQixvQkFBb0IsVUFBbUM7QUFDM0UsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLFFBQU0sU0FBUyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksUUFBUSxFQUFFLFlBQVk7QUFDM0QsTUFBSSxTQUFTO0FBQ2IsYUFBVyxVQUFVLE9BQU8sS0FBSyxHQUFHLEdBQUc7QUFDckMsVUFBTSxRQUFRLElBQUksTUFBTTtBQUN4QixRQUFJLENBQUMsTUFBTztBQUNaLGVBQVcsT0FBTyxPQUFPLEtBQUssS0FBSyxHQUFHO0FBQ3BDLFlBQU0sSUFBSSxNQUFNLEdBQUc7QUFDbkIsVUFBSSxLQUFLLEVBQUUsS0FBSyxRQUFRO0FBQ3RCLGVBQU8sTUFBTSxHQUFHO0FBQ2hCLGtCQUFVO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFDQSxRQUFJLE9BQU8sS0FBSyxLQUFLLEVBQUUsV0FBVyxFQUFHLFFBQU8sSUFBSSxNQUFNO0FBQUEsRUFDeEQ7QUFDQSxNQUFJLFNBQVMsRUFBRyxPQUFNLGtCQUFrQixHQUFHO0FBQzNDLFNBQU87QUFDVDtBQUlBLGVBQXNCLGtCQUFxRDtBQUN6RSxTQUFPLE9BQU8sY0FBYztBQUM5QjtBQUVBLGVBQXNCLG9CQUFxQztBQUN6RCxRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsTUFBSSxRQUFRO0FBQ1osYUFBVyxPQUFPLE9BQU8sT0FBTyxDQUFDLEVBQUcsVUFBUyxJQUFJO0FBQ2pELFNBQU87QUFDVDtBQUVBLGVBQXNCLGVBQWUsUUFBZ0IsU0FBZ0M7QUFDbkYsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLFFBQU0sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzFCLE1BQUksQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHO0FBQzFCLFFBQUksS0FBSyxPQUFPO0FBQ2hCLE1BQUUsTUFBTSxJQUFJO0FBQ1osVUFBTSxPQUFPLGdCQUFnQixDQUFDO0FBQUEsRUFDaEM7QUFDRjtBQUVBLGVBQXNCLGVBQWUsUUFBZ0IsU0FBZ0M7QUFDbkYsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLFFBQU0sTUFBTSxFQUFFLE1BQU07QUFDcEIsTUFBSSxDQUFDLElBQUs7QUFDVixRQUFNLFdBQVcsSUFBSSxPQUFPLENBQUMsT0FBTyxPQUFPLE9BQU87QUFDbEQsTUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLEVBQUUsTUFBTTtBQUFBLE1BQ3JDLEdBQUUsTUFBTSxJQUFJO0FBQ2pCLFFBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUNoQztBQUVBLGVBQXNCLG9CQUdaO0FBQ1IsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFFBQUksSUFBSSxTQUFTLEVBQUcsUUFBTyxFQUFFLFFBQVEsU0FBUyxJQUFJLENBQUMsRUFBRztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0IscUJBQXdEO0FBQzVFLFNBQU8sT0FBTyxpQkFBaUI7QUFDakM7QUFFQSxlQUFzQix1QkFBd0M7QUFDNUQsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixrQkFBa0IsWUFBMkIsU0FBZ0M7QUFDakcsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLFFBQU0sU0FBUyxjQUFjO0FBQzdCLFFBQU0sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzFCLE1BQUksQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHO0FBQzFCLFFBQUksS0FBSyxPQUFPO0FBQ2hCLE1BQUUsTUFBTSxJQUFJO0FBQ1osVUFBTSxPQUFPLG1CQUFtQixDQUFDO0FBQUEsRUFDbkM7QUFDRjtBQUVBLGVBQXNCLGtCQUFrQixTQUFnQztBQUN0RSxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxVQUFVO0FBQ2QsYUFBVyxVQUFVLE9BQU8sS0FBSyxDQUFDLEdBQUc7QUFDbkMsVUFBTSxNQUFNLEVBQUUsTUFBTTtBQUNwQixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sV0FBVyxJQUFJLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTztBQUNsRCxRQUFJLFNBQVMsV0FBVyxJQUFJLFFBQVE7QUFDbEMsZ0JBQVU7QUFDVixVQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNO0FBQUEsVUFDckMsR0FBRSxNQUFNLElBQUk7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFFBQVMsT0FBTSxPQUFPLG1CQUFtQixDQUFDO0FBQ2hEO0FBRUEsZUFBc0IsdUJBR1o7QUFDUixRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFHO0FBQUEsRUFDeEQ7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixxQkFBd0Q7QUFDNUUsU0FBTyxPQUFPLGlCQUFpQjtBQUNqQztBQUVBLGVBQXNCLHVCQUF3QztBQUM1RCxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxRQUFRO0FBQ1osYUFBVyxPQUFPLE9BQU8sT0FBTyxDQUFDLEVBQUcsVUFBUyxJQUFJO0FBQ2pELFNBQU87QUFDVDtBQUVBLGVBQXNCLGtCQUFrQixTQUFtQztBQUN6RSxRQUFNLE9BQU8sTUFBTSxPQUFPLGdCQUFnQjtBQUMxQyxTQUFPLFdBQVc7QUFDcEI7QUFFQSxlQUFzQixtQkFBbUIsU0FBZ0M7QUFDdkUsUUFBTSxPQUFPLE1BQU0sT0FBTyxnQkFBZ0I7QUFDMUMsT0FBSyxPQUFPLEtBQUksb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDdkMsUUFBTSxPQUFPLGtCQUFrQixJQUFJO0FBQ3JDO0FBRUEsZUFBc0Isa0JBQWtCLFFBQWdCLFNBQWdDO0FBQ3RGLE1BQUksTUFBTSxrQkFBa0IsT0FBTyxFQUFHO0FBQ3RDLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUFBLEVBQ25DO0FBQ0Y7QUFFQSxlQUFzQixrQkFBa0IsU0FBZ0M7QUFDdEUsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksVUFBVTtBQUNkLGFBQVcsVUFBVSxPQUFPLEtBQUssQ0FBQyxHQUFHO0FBQ25DLFVBQU0sTUFBTSxFQUFFLE1BQU07QUFDcEIsUUFBSSxDQUFDLElBQUs7QUFDVixVQUFNLFdBQVcsSUFBSSxPQUFPLENBQUMsT0FBTyxPQUFPLE9BQU87QUFDbEQsUUFBSSxTQUFTLFdBQVcsSUFBSSxRQUFRO0FBQ2xDLGdCQUFVO0FBQ1YsVUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLEVBQUUsTUFBTTtBQUFBLFVBQ3JDLEdBQUUsTUFBTSxJQUFJO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxRQUFTLE9BQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUNoRDtBQUVBLGVBQXNCLHVCQUdaO0FBQ1IsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFFBQUksSUFBSSxTQUFTLEVBQUcsUUFBTyxFQUFFLFFBQVEsU0FBUyxJQUFJLENBQUMsRUFBRztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0IsWUFBWSxTQUFtQztBQUNuRSxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsYUFBVyxTQUFTLE9BQU8sT0FBTyxHQUFHLEdBQUc7QUFDdEMsUUFBSSxTQUFTLFdBQVcsTUFBTyxRQUFPO0FBQUEsRUFDeEM7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixvQkFBaUQ7QUFDckUsU0FBTyxPQUFPLGdCQUFnQjtBQUNoQztBQUNBLGVBQXNCLGtCQUFrQixHQUFzQztBQUM1RSxRQUFNLE9BQU8sa0JBQWtCLENBQUM7QUFDbEM7QUFDQSxlQUFzQix1QkFBb0Q7QUFDeEUsU0FBTyxPQUFPLG1CQUFtQjtBQUNuQztBQUNBLGVBQXNCLHFCQUFxQixHQUFzQztBQUMvRSxRQUFNLE9BQU8scUJBQXFCLENBQUM7QUFDckM7QUFDQSxlQUFzQix1QkFBb0Q7QUFDeEUsU0FBTyxPQUFPLG1CQUFtQjtBQUNuQztBQUNBLGVBQXNCLHFCQUFxQixHQUFzQztBQUMvRSxRQUFNLE9BQU8scUJBQXFCLENBQUM7QUFDckM7QUFDQSxlQUFzQix1QkFBMEQ7QUFDOUUsU0FBTyxPQUFPLG1CQUFtQjtBQUNuQztBQUNBLGVBQXNCLHFCQUFxQixHQUE0QztBQUNyRixRQUFNLE9BQU8scUJBQXFCLENBQUM7QUFDckM7QUFZQSxlQUFzQixvQkFBb0IsVUFPdkM7QUFDRCxRQUFNLFlBQVksSUFBSSxJQUFJLENBQUMsR0FBRyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsQ0FBQztBQUNuRSxRQUFNLGFBQWEsQ0FBQyxNQUF1QixVQUFVLElBQUksRUFBRSxZQUFZLENBQUM7QUFHeEUsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLGtCQUFrQjtBQUN0QixhQUFXLEtBQUssT0FBTyxLQUFLLFFBQVEsR0FBRztBQUNyQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxTQUFTLENBQUM7QUFDakIseUJBQW1CO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLFlBQVksUUFBUTtBQUdqQyxRQUFNLFVBQVUsTUFBTSxjQUFjO0FBQ3BDLE1BQUksaUJBQWlCO0FBQ3JCLGFBQVcsS0FBSyxPQUFPLEtBQUssT0FBTyxHQUFHO0FBQ3BDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLFFBQVEsQ0FBQztBQUNoQix3QkFBa0I7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sY0FBYyxPQUFPO0FBR2xDLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxNQUFJLDBCQUEwQjtBQUM5QixhQUFXLEtBQUssT0FBTyxLQUFLLEdBQUcsR0FBRztBQUNoQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxJQUFJLENBQUM7QUFDWixpQ0FBMkI7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGtCQUFrQixHQUFHO0FBRzNCLFFBQU0sS0FBSyxNQUFNLGdCQUFnQjtBQUNqQyxNQUFJLHdCQUF3QjtBQUM1QixhQUFXLEtBQUssT0FBTyxLQUFLLEVBQUUsR0FBRztBQUMvQixRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxHQUFHLENBQUM7QUFDWCwrQkFBeUI7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sZ0JBQWdCLEVBQUU7QUFNL0IsUUFBTSxLQUFLLE1BQU0sbUJBQW1CO0FBQ3BDLE1BQUksdUJBQXVCO0FBQzNCLGFBQVcsS0FBSyxPQUFPLEtBQUssRUFBRSxHQUFHO0FBQy9CLFFBQUksTUFBTSxjQUFjLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDdEMsK0JBQXlCLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRztBQUN0QyxhQUFPLEdBQUcsQ0FBQztBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLG1CQUFtQixFQUFFO0FBRWxDLFFBQU0sS0FBSyxNQUFNLG1CQUFtQjtBQUNwQyxNQUFJLHVCQUF1QjtBQUMzQixhQUFXLEtBQUssT0FBTyxLQUFLLEVBQUUsR0FBRztBQUMvQixRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsK0JBQXlCLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRztBQUN0QyxhQUFPLEdBQUcsQ0FBQztBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLG1CQUFtQixFQUFFO0FBRWxDLFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFJQSxlQUFzQixXQUEwQjtBQUM5QyxRQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU07QUFDcEM7OztBQ2xxQkEsSUFBSSxZQUE2QztBQUUxQyxTQUFTLGVBQWUsSUFBa0M7QUFDL0QsY0FBWTtBQUNkO0FBRUEsU0FBUyxTQUFpQjtBQUN4QixVQUFPLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ2hDO0FBRUEsZUFBZSxLQUFLLE9BQWlCLEtBQWEsU0FBaUQ7QUFDakcsUUFBTSxLQUFlLEVBQUUsSUFBSSxPQUFPLEdBQUcsT0FBTyxLQUFLLFNBQVMsT0FBTyxPQUFPLEVBQUU7QUFFMUUsUUFBTSxPQUFPLGlCQUFpQixNQUFNLFlBQVksQ0FBQyxJQUFJLEdBQUc7QUFDeEQsTUFBSSxVQUFVLFFBQVMsU0FBUSxNQUFNLE1BQU0sR0FBRyxPQUFPO0FBQUEsV0FDNUMsVUFBVSxPQUFRLFNBQVEsS0FBSyxNQUFNLEdBQUcsT0FBTztBQUFBLE1BQ25ELFNBQVEsSUFBSSxNQUFNLEdBQUcsT0FBTztBQUVqQyxNQUFJO0FBQ0YsVUFBTSxlQUFlLEVBQUU7QUFBQSxFQUN6QixTQUFTLEtBQUs7QUFDWixZQUFRLEtBQUssMkNBQTJDLEdBQUc7QUFBQSxFQUM3RDtBQUVBLE1BQUk7QUFDRixnQkFBWSxFQUFFO0FBQUEsRUFDaEIsUUFBUTtBQUFBLEVBRVI7QUFDRjtBQUVPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxLQUFLLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN0RixTQUFPLEtBQUssUUFBUSxLQUFLLE9BQU87QUFDbEM7QUFDTyxTQUFTLE1BQU0sS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3ZGLFNBQU8sS0FBSyxTQUFTLEtBQUssT0FBTztBQUNuQztBQUVPLFNBQVMsY0FBYyxLQUF5RDtBQUNyRixNQUFJLGVBQWUsT0FBTztBQUN4QixXQUFPLEVBQUUsU0FBUyxJQUFJLFNBQVMsT0FBTyxJQUFJLFNBQVMsS0FBSztBQUFBLEVBQzFEO0FBQ0EsTUFBSTtBQUNGLFdBQU8sRUFBRSxTQUFTLE9BQU8sR0FBRyxHQUFHLE9BQU8sS0FBSztBQUFBLEVBQzdDLFFBQVE7QUFDTixXQUFPLEVBQUUsU0FBUyx1QkFBdUIsT0FBTyxLQUFLO0FBQUEsRUFDdkQ7QUFDRjtBQU9BLFNBQVMsT0FBTyxLQUF1RDtBQUNyRSxRQUFNLE1BQStCLENBQUM7QUFDdEMsYUFBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDeEMsUUFBSSxFQUFFLFlBQVksRUFBRSxTQUFTLE9BQU8sS0FBSyxFQUFFLFlBQVksTUFBTSxTQUFTLE1BQU0saUJBQWlCO0FBQzNGLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWCxXQUFXLE9BQU8sTUFBTSxZQUFZLCtCQUErQixLQUFLLENBQUMsR0FBRztBQUMxRSxVQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsNkJBQTZCLHVCQUF1QjtBQUFBLElBQ3pFLFdBQVcsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLE1BQU07QUFDbkQsVUFBSSxDQUFDLElBQUksR0FBRyxFQUFFLE1BQU0sR0FBRyxJQUFJLENBQUM7QUFBQSxJQUM5QixPQUFPO0FBQ0wsVUFBSSxDQUFDLElBQUk7QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDs7O0FDdkVBLElBQU0sV0FBVztBQUNqQixJQUFNLFdBQVc7QUErQlYsSUFBTSxjQUFOLGNBQTBCLE1BQU07QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBSUE7QUFBQSxFQUVBLFlBQVksTUFPVDtBQUNELFVBQU0sS0FBSyxPQUFPO0FBQ2xCLFNBQUssT0FBTztBQUNaLFNBQUssU0FBUyxLQUFLO0FBQ25CLFNBQUssT0FBTyxLQUFLO0FBQ2pCLFNBQUssWUFBWSxLQUFLO0FBQ3RCLFNBQUssV0FBVyxLQUFLO0FBQ3JCLFNBQUssbUJBQW1CLEtBQUssb0JBQW9CO0FBQUEsRUFDbkQ7QUFDRjtBQUVPLElBQU0sZUFBTixNQUFtQjtBQUFBLEVBQ1A7QUFBQSxFQUVqQixZQUFZLFVBQW9CO0FBQzlCLFNBQUssV0FBVztBQUFBLEVBQ2xCO0FBQUE7QUFBQSxFQUdBLE1BQU0sU0FBMEI7QUFDOUIsVUFBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTztBQUMvQyxXQUFRLElBQTJCLFNBQVM7QUFBQSxFQUM5QztBQUFBO0FBQUEsRUFHQSxNQUFNLGFBQWEsUUFBa0M7QUFDbkQsUUFBSTtBQUNGLFlBQU0sS0FBSztBQUFBLFFBQ1Q7QUFBQSxRQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLG1CQUFtQixNQUFNLENBQUM7QUFBQSxNQUM1RjtBQUNBLGFBQU87QUFBQSxJQUNULFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLE1BQU0sbUJBQTBGO0FBQzlGLFVBQU0sS0FBSyxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDOUMsVUFBTSxPQUFPLE1BQU0sS0FBSyxVQUFVLE9BQU8sVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLEVBQUU7QUFDOUYsVUFBTSxJQUFJO0FBQ1YsV0FBTztBQUFBLE1BQ0wsT0FBUSxHQUF5QjtBQUFBLE1BQ2pDLFdBQVcsRUFBRTtBQUFBLE1BQ2IsZ0JBQWdCLEVBQUU7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxNQUFNLG9CQUFtQztBQUN2QyxVQUFNLE9BQU8sTUFBTSxLQUFLLGNBQWM7QUFDdEMsVUFBTSxLQUFLO0FBQUEsTUFDVDtBQUFBLE1BQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJLG1CQUFtQixXQUFXLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxNQUN0RztBQUFBLFFBQ0UsS0FBSyxLQUFLO0FBQUEsUUFDVixPQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sYUFBYSxZQUE0QztBQUM3RCxVQUFNLE1BQU0sR0FBRyxRQUFRLElBQUksS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssU0FBUyxNQUFNLElBQUksVUFBVTtBQUMxRyxVQUFNLE1BQU0sTUFBTSxNQUFNLEtBQUs7QUFBQSxNQUMzQixRQUFRO0FBQUEsTUFDUixTQUFTLEVBQUUsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHLEdBQUc7QUFBQSxJQUMxRCxDQUFDO0FBQ0QsUUFBSSxJQUFJLFdBQVcsSUFBSyxRQUFPO0FBQy9CLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxNQUFNLEtBQUssVUFBVSxLQUFLLFdBQVcsVUFBVSxFQUFFO0FBQ3BFLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxXQUFXLE1BQXNDO0FBQ3JELFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsUUFDckI7QUFBQSxRQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDLFFBQVEsbUJBQW1CLEtBQUssU0FBUyxNQUFNLENBQUM7QUFBQSxNQUNsSTtBQUNBLFlBQU0sSUFBSTtBQUNWLGFBQU8sRUFBRSxPQUFPO0FBQUEsSUFDbEIsU0FBUyxLQUFLO0FBQ1osVUFBSSxlQUFlLGVBQWUsSUFBSSxhQUFhLFlBQWEsUUFBTztBQUN2RSxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFPQSxNQUFNLFFBQVEsTUFBOEM7QUFDMUQsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxNQUFNLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxhQUFhLFdBQVcsSUFBSSxDQUFDO0FBQzVGLFFBQUksTUFBcUIsS0FBSyxlQUFlO0FBQzdDLFVBQU0sY0FBYztBQUVwQixhQUFTLFVBQVUsR0FBRyxXQUFXLGFBQWEsV0FBVztBQUN2RCxZQUFNLE9BQWdDO0FBQUEsUUFDcEMsU0FBUyxLQUFLO0FBQUEsUUFDZCxTQUFTLEtBQUs7QUFBQSxRQUNkLFFBQVEsS0FBSyxTQUFTO0FBQUEsTUFDeEI7QUFDQSxVQUFJLElBQUssTUFBSyxNQUFNO0FBQ3BCLFVBQUk7QUFDRixjQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxLQUFLLElBQUk7QUFDakQsY0FBTSxNQUFNO0FBQ1osZUFBTyxFQUFFLE1BQU0sSUFBSSxRQUFRLE1BQU0sS0FBSyxJQUFJLFFBQVEsS0FBSyxLQUFLLElBQUksUUFBUSxTQUFTO0FBQUEsTUFDbkYsU0FBUyxLQUFLO0FBQ1osWUFBSSxFQUFFLGVBQWUsYUFBYyxPQUFNO0FBQ3pDLFlBQUksSUFBSSxXQUFXLE9BQU8sQ0FBQyxLQUFLO0FBRTlCLGdCQUFNLE1BQU0sS0FBSyxXQUFXLElBQUk7QUFDaEMsY0FBSSxDQUFDLElBQUssT0FBTTtBQUNoQjtBQUFBLFFBQ0Y7QUFDQSxZQUFJLENBQUMsSUFBSSxhQUFhLFlBQVksWUFBYSxPQUFNO0FBQ3JELGNBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxJQUFJLE1BQU0sbUNBQW1DLElBQUksRUFBRTtBQUFBLEVBQzNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBLE1BQU0sWUFBWSxNQUFzRDtBQUN0RSxRQUFJLEtBQUssTUFBTSxXQUFXLEVBQUcsT0FBTSxJQUFJLE1BQU0saUNBQWlDO0FBQzlFLFVBQU0sY0FBYztBQUNwQixRQUFJLFVBQW1CO0FBRXZCLGFBQVMsVUFBVSxHQUFHLFdBQVcsYUFBYSxXQUFXO0FBQ3ZELFVBQUk7QUFDRixjQUFNLFFBQVEsTUFBTSxRQUFRO0FBQUEsVUFDMUIsS0FBSyxNQUFNLElBQUksT0FBTyxTQUFTO0FBQzdCLGtCQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsY0FDckI7QUFBQSxjQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLGNBQ25EO0FBQUEsZ0JBQ0UsU0FBUyxLQUFLO0FBQUEsZ0JBQ2QsVUFBVTtBQUFBLGNBQ1o7QUFBQSxZQUNGO0FBQ0EsbUJBQU87QUFBQSxjQUNMLE1BQU0sS0FBSztBQUFBLGNBQ1gsS0FBTSxJQUF3QjtBQUFBLFlBQ2hDO0FBQUEsVUFDRixDQUFDO0FBQUEsUUFDSDtBQUVBLGNBQU0sT0FBTyxNQUFNLEtBQUssY0FBYztBQUN0QyxjQUFNLE9BQU8sTUFBTSxLQUFLO0FBQUEsVUFDdEI7QUFBQSxVQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLFVBQ25EO0FBQUEsWUFDRSxXQUFXLEtBQUs7QUFBQSxZQUNoQixNQUFNLE1BQU0sSUFBSSxDQUFDLFVBQVU7QUFBQSxjQUN6QixNQUFNLEtBQUs7QUFBQSxjQUNYLE1BQU07QUFBQSxjQUNOLE1BQU07QUFBQSxjQUNOLEtBQUssS0FBSztBQUFBLFlBQ1osRUFBRTtBQUFBLFVBQ0o7QUFBQSxRQUNGO0FBQ0EsY0FBTSxVQUFXLEtBQXlCO0FBQzFDLGNBQU0sU0FBUyxNQUFNLEtBQUs7QUFBQSxVQUN4QjtBQUFBLFVBQ0EsVUFBVSxLQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsVUFDbkQ7QUFBQSxZQUNFLFNBQVMsS0FBSztBQUFBLFlBQ2QsTUFBTTtBQUFBLFlBQ04sU0FBUyxDQUFDLEtBQUssR0FBRztBQUFBLFVBQ3BCO0FBQUEsUUFDRjtBQUNBLGNBQU0sWUFBWTtBQUNsQixZQUFJO0FBQ0YsZ0JBQU0sS0FBSztBQUFBLFlBQ1Q7QUFBQSxZQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxtQkFBbUIsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsWUFDdEc7QUFBQSxjQUNFLEtBQUssVUFBVTtBQUFBLGNBQ2YsT0FBTztBQUFBLFlBQ1Q7QUFBQSxVQUNGO0FBQUEsUUFDRixTQUFTLEtBQUs7QUFDWixjQUFJLFdBQVcsR0FBRyxLQUFLLFVBQVUsYUFBYTtBQUM1QyxzQkFBVTtBQUNWLGtCQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUNuQztBQUFBLFVBQ0Y7QUFDQSxnQkFBTTtBQUFBLFFBQ1I7QUFDQSxlQUFPO0FBQUEsVUFDTCxXQUFXLFVBQVU7QUFBQSxVQUNyQixLQUFLLFVBQVU7QUFBQSxVQUNmLE9BQU8sS0FBSyxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssSUFBSTtBQUFBLFFBQzNDO0FBQUEsTUFDRixTQUFTLEtBQUs7QUFDWixrQkFBVTtBQUNWLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFLLENBQUMsSUFBSSxhQUFhLENBQUMsV0FBVyxHQUFHLEtBQU0sWUFBWSxZQUFhLE9BQU07QUFDM0UsY0FBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLG1CQUFtQixRQUFRLFVBQVUsSUFBSSxNQUFNLGlDQUFpQztBQUFBLEVBQ3hGO0FBQUEsRUFFQSxNQUFjLGdCQUEyRDtBQUN2RSxVQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDckI7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxrQkFBa0IsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsSUFDdkc7QUFDQSxVQUFNLFVBQVcsSUFBb0MsT0FBTztBQUM1RCxVQUFNLFNBQVMsTUFBTSxLQUFLO0FBQUEsTUFDeEI7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxnQkFBZ0IsT0FBTztBQUFBLElBQzVFO0FBQ0EsV0FBTztBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0wsU0FBVSxPQUFxQyxLQUFLO0FBQUEsSUFDdEQ7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFjLFVBQVUsUUFBZ0IsTUFBYyxNQUFrQztBQUN0RixVQUFNLE1BQU0sS0FBSyxXQUFXLE1BQU0sSUFBSSxPQUFPLEdBQUcsUUFBUSxHQUFHLElBQUk7QUFDL0QsVUFBTSxPQUFvQjtBQUFBLE1BQ3hCO0FBQUEsTUFDQSxTQUFTO0FBQUEsUUFDUCxlQUFlLFVBQVUsS0FBSyxTQUFTLEdBQUc7QUFBQSxRQUMxQyxRQUFRO0FBQUEsUUFDUix3QkFBd0I7QUFBQSxRQUN4QixHQUFJLE9BQU8sRUFBRSxnQkFBZ0IsbUJBQW1CLElBQUksQ0FBQztBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxHQUFJLE9BQU8sRUFBRSxNQUFNLEtBQUssVUFBVSxJQUFJLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDL0M7QUFDQSxRQUFJO0FBQ0osUUFBSTtBQUNGLFlBQU0sTUFBTSxNQUFNLEtBQUssSUFBSTtBQUFBLElBQzdCLFNBQVMsUUFBUTtBQUNmLFlBQU0sSUFBSSxZQUFZO0FBQUEsUUFDcEIsUUFBUTtBQUFBLFFBQ1IsTUFBTTtBQUFBLFFBQ04sU0FBUyxZQUFZLGNBQWMsTUFBTSxFQUFFLE9BQU87QUFBQSxRQUNsRCxXQUFXO0FBQUEsUUFDWCxVQUFVO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLFNBQWtCO0FBQ3RCLFVBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixRQUFJLE1BQU07QUFDUixVQUFJO0FBQ0YsaUJBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxNQUMxQixRQUFRO0FBQ04saUJBQVM7QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxNQUFNLEtBQUssb0JBQW9CLEtBQUssUUFBUSxHQUFHLE1BQU0sSUFBSSxJQUFJLEVBQUU7QUFDbEYsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE1BQWMsVUFBVSxLQUFlLE9BQXFDO0FBQzFFLFFBQUksU0FBa0I7QUFDdEIsUUFBSTtBQUNGLFlBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixVQUFJLEtBQU0sVUFBUyxLQUFLLE1BQU0sSUFBSTtBQUFBLElBQ3BDLFFBQVE7QUFBQSxJQUVSO0FBQ0EsV0FBTyxLQUFLLG9CQUFvQixLQUFLLFFBQVEsS0FBSztBQUFBLEVBQ3BEO0FBQUEsRUFFUSxvQkFBb0IsS0FBZSxNQUFlLE9BQTRCO0FBQ3BGLFVBQU0sTUFDSixPQUFPLFNBQVMsWUFBWSxRQUFRLGFBQWEsT0FDN0MsT0FBUSxLQUE4QixPQUFPLElBQzdDLElBQUk7QUFDVixRQUFJLFdBQW9DO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0FBRTVDLFlBQU0sT0FBTyxJQUFJLFFBQVEsSUFBSSx1QkFBdUI7QUFDcEQsVUFBSSxTQUFTLE9BQU8sY0FBYyxLQUFLLEdBQUcsR0FBRztBQUMzQyxtQkFBVztBQUNYLG9CQUFZO0FBQUEsTUFDZCxPQUFPO0FBQ0wsbUJBQVc7QUFBQSxNQUNiO0FBQUEsSUFDRixXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQUEsSUFDYixXQUFXLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxLQUFLO0FBQ25ELGlCQUFXO0FBQUEsSUFDYixXQUFXLElBQUksVUFBVSxLQUFLO0FBQzVCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkLFdBQVcsSUFBSSxXQUFXLEtBQUs7QUFDN0IsaUJBQVc7QUFDWCxrQkFBWTtBQUFBLElBQ2Q7QUFDQSxXQUFPLElBQUksWUFBWTtBQUFBLE1BQ3JCLFFBQVEsSUFBSTtBQUFBLE1BQ1o7QUFBQSxNQUNBLFNBQVMsR0FBRyxLQUFLLFdBQU0sSUFBSSxNQUFNLEtBQUssR0FBRztBQUFBLE1BQ3pDO0FBQUEsTUFDQTtBQUFBLE1BQ0Esa0JBQWtCLGFBQWEsZUFBZSxvQkFBb0IsSUFBSSxPQUFPLElBQUk7QUFBQSxJQUNuRixDQUFDO0FBQUEsRUFDSDtBQUNGO0FBUUEsU0FBUyxvQkFBb0IsU0FBaUM7QUFDNUQsUUFBTSxRQUFRLFFBQVEsSUFBSSxtQkFBbUI7QUFDN0MsTUFBSSxPQUFPO0FBQ1QsVUFBTSxJQUFJLE9BQU8sU0FBUyxPQUFPLEVBQUU7QUFDbkMsUUFBSSxPQUFPLFNBQVMsQ0FBQyxLQUFLLElBQUksRUFBRyxRQUFPO0FBQUEsRUFDMUM7QUFDQSxRQUFNLGFBQWEsUUFBUSxJQUFJLGFBQWE7QUFDNUMsTUFBSSxZQUFZO0FBQ2QsVUFBTSxRQUFRLE9BQU8sU0FBUyxZQUFZLEVBQUU7QUFDNUMsUUFBSSxPQUFPLFNBQVMsS0FBSyxLQUFLLFNBQVMsR0FBRztBQUN4QyxhQUFPLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJLElBQUk7QUFBQSxJQUN6QztBQUNBLFVBQU0sU0FBUyxLQUFLLE1BQU0sVUFBVTtBQUNwQyxRQUFJLE9BQU8sU0FBUyxNQUFNLEVBQUcsUUFBTyxLQUFLLE1BQU0sU0FBUyxHQUFJO0FBQUEsRUFDOUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFdBQVcsTUFBc0I7QUFFeEMsU0FBTyxLQUFLLE1BQU0sR0FBRyxFQUFFLElBQUksa0JBQWtCLEVBQUUsS0FBSyxHQUFHO0FBQ3pEO0FBRUEsU0FBUyxVQUFVLFNBQWlCLEtBQTBCO0FBRTVELFFBQU0sT0FBTyxJQUFJLGFBQWEsZUFBZSxNQUFPO0FBQ3BELFFBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksR0FBRztBQUM3QyxTQUFPLEtBQUssSUFBSSxLQUFRLE9BQU8sTUFBTSxVQUFVLEtBQUssTUFBTTtBQUM1RDtBQUVBLFNBQVMsV0FBVyxLQUFrQztBQUNwRCxTQUFPLGVBQWUsZUFBZSxJQUFJLGFBQWE7QUFDeEQ7QUFFQSxTQUFTLE1BQU0sSUFBMkI7QUFDeEMsU0FBTyxJQUFJLFFBQVEsQ0FBQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUM7QUFDN0M7QUFFTyxTQUFTQSxVQUFTLE9BQXVCO0FBRTlDLFFBQU0sT0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEtBQUs7QUFDM0MsTUFBSSxNQUFNO0FBQ1YsYUFBVyxLQUFLLEtBQU0sUUFBTyxPQUFPLGFBQWEsQ0FBQztBQUNsRCxTQUFPLEtBQUssR0FBRztBQUNqQjs7O0FDM1hBLElBQU0sY0FBYztBQVNwQixJQUFNLHVCQUE0QyxvQkFBSSxJQUFJLENBQUMsV0FBVyxDQUFDO0FBRWhFLFNBQVMsVUFBVSxTQUFrQixLQUF3QztBQUNsRixRQUFNLFlBQVksY0FBYyxPQUFPO0FBQ3ZDLFFBQU0sU0FBMkIsQ0FBQztBQUNsQyxRQUFNLG9CQUF3QyxDQUFDO0FBQy9DLFFBQU0sV0FBcUIsQ0FBQztBQUM1QixRQUFNLFFBQVEsb0JBQUksSUFBWTtBQUM5QixRQUFNLGFBQWEsb0JBQUksSUFBMkI7QUFDbEQsUUFBTSxrQkFBa0IscUJBQXFCLElBQUksSUFBSSxRQUFRO0FBQzdELGFBQVcsT0FBTyxXQUFXO0FBQzNCLFFBQUk7QUFDRixZQUFNLGNBQWMscUJBQXFCLEtBQUssR0FBRztBQUNqRCxVQUFJLGFBQWE7QUFDZiwwQkFBa0IsS0FBSyxXQUFXO0FBQ2xDLGlCQUFTLEtBQUssWUFBWSxRQUFRO0FBQ2xDLGNBQU0sSUFBSSxZQUFZLFFBQVE7QUFDOUI7QUFBQSxNQUNGO0FBQ0EsWUFBTSxJQUFJLFdBQVcsS0FBSyxHQUFHO0FBQzdCLFVBQUksQ0FBQyxHQUFHO0FBQ04sWUFBSSxpQkFBaUI7QUFJbkIsZ0JBQU0sVUFBVSxZQUFZLEdBQUc7QUFDL0IsY0FBSSxRQUFTLFlBQVcsSUFBSSxRQUFRLFVBQVUsUUFBUSxXQUFXO0FBQUEsUUFDbkU7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxlQUFTLEtBQUssRUFBRSxRQUFRO0FBQ3hCLFlBQU0sSUFBSSxFQUFFLFFBQVE7QUFDcEIsVUFBSSxJQUFJLGVBQWUsU0FBUyxLQUFLLElBQUksZUFBZSxJQUFJLEVBQUUsZUFBZSxZQUFZLENBQUMsR0FBRztBQUMzRixlQUFPLEtBQUssQ0FBQztBQUFBLE1BQ2Y7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUVSO0FBQUEsRUFDRjtBQUdBLFFBQU0sY0FBdUUsQ0FBQztBQUM5RSxhQUFXLENBQUMsSUFBSSxJQUFJLEtBQUssWUFBWTtBQUNuQyxRQUFJLE1BQU0sSUFBSSxFQUFFLEVBQUc7QUFDbkIsZ0JBQVksS0FBSyxFQUFFLFVBQVUsSUFBSSxhQUFhLEtBQUssQ0FBQztBQUFBLEVBQ3REO0FBQ0EsU0FBTyxFQUFFLFFBQVEsY0FBYyxVQUFVLG9CQUFvQixtQkFBbUIsWUFBWTtBQUM5RjtBQUVBLFNBQVMscUJBQXFCLE1BQWUsS0FBZ0Q7QUFDM0YsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUU5QyxRQUFNLFVBQ0osVUFBVSxFQUFFLE9BQU8sS0FDbkIsb0JBQW9CLElBQUksTUFDdkIsSUFBSSxZQUFZLG9CQUFvQixJQUFJLFNBQVMsSUFBSTtBQUN4RCxNQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksS0FBSyxPQUFPLEVBQUcsUUFBTztBQUVuRCxRQUFNLGtCQUFrQixrQkFBa0IsSUFBSTtBQUM5QyxTQUFPO0FBQUEsSUFDTCxVQUFVO0FBQUEsSUFDVixnQkFDRSx3QkFBd0IsTUFBTSxPQUFPLE1BQ3BDLElBQUksWUFBWSxtQkFBbUIsSUFBSSxXQUFXLE9BQU8sSUFBSTtBQUFBLElBQ2hFLHlCQUF5QixJQUFJO0FBQUEsSUFDN0Isb0JBQW9CLDBCQUEwQixlQUFlO0FBQUEsSUFDN0Qsa0JBQWtCO0FBQUEsSUFDbEIsd0JBQXdCLElBQUksYUFBYTtBQUFBLEVBQzNDO0FBQ0Y7QUFFQSxTQUFTLG9CQUFvQixNQUE4QjtBQUN6RCxRQUFNLE9BQU8sb0JBQUksUUFBZ0I7QUFDakMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE1BQU0sTUFBTSxJQUFJO0FBQ3RCLFFBQUksT0FBTyxRQUFRLFVBQVU7QUFDM0IsWUFBTSxLQUFLLG9CQUFvQixHQUFHO0FBQ2xDLFVBQUksR0FBSSxRQUFPO0FBQ2Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVU7QUFDN0MsUUFBSSxLQUFLLElBQUksR0FBYSxFQUFHO0FBQzdCLFNBQUssSUFBSSxHQUFhO0FBQ3RCLFFBQUksTUFBTSxRQUFRLEdBQUcsR0FBRztBQUN0QixpQkFBVyxLQUFLLElBQUssT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNuQyxPQUFPO0FBQ0wsaUJBQVcsS0FBSyxPQUFPLE9BQU8sR0FBOEIsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQzdFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsb0JBQW9CLFFBQStCO0FBQzFELE1BQUk7QUFDRixVQUFNLE1BQU0sSUFBSSxJQUFJLFFBQVEsZ0JBQWdCO0FBQzVDLFFBQUksSUFBSSxhQUFhLFdBQVcsSUFBSSxhQUFhLGNBQWUsUUFBTztBQUN2RSxVQUFNLFFBQVEsSUFBSSxTQUFTLE1BQU0sb0RBQW9EO0FBQ3JGLFdBQU8sUUFBUSxDQUFDLEtBQUs7QUFBQSxFQUN2QixRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsa0JBQWtCLE1BQThCO0FBQ3ZELFFBQU0sVUFBb0IsQ0FBQztBQUMzQixRQUFNLE9BQU8sb0JBQUksUUFBZ0I7QUFDakMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE1BQU0sTUFBTSxJQUFJO0FBQ3RCLFFBQUksT0FBTyxRQUFRLFVBQVU7QUFDM0IsWUFBTSxVQUFVLElBQUksS0FBSztBQUN6QixVQUNFLFFBQVEsVUFBVSxLQUNsQixDQUFDLFFBQVEsV0FBVyxTQUFTLEtBQzdCLENBQUMsUUFBUSxXQUFXLFVBQVUsR0FDOUI7QUFDQSxnQkFBUSxLQUFLLE9BQU87QUFBQSxNQUN0QjtBQUNBO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFlBQVksUUFBUTtBQUFBLElBQUssQ0FBQyxNQUM5Qiw4RUFBOEUsS0FBSyxDQUFDO0FBQUEsRUFDdEY7QUFDQSxTQUFPLGFBQWEsUUFBUSxDQUFDLEtBQUs7QUFDcEM7QUFFQSxTQUFTLDBCQUEwQixNQUFvQztBQUNyRSxNQUFJLENBQUMsS0FBTSxRQUFPO0FBQ2xCLE1BQUksd0JBQXdCLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDL0MsTUFBSSxnQkFBZ0IsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUN2QyxNQUFJLHVCQUF1QixLQUFLLElBQUksRUFBRyxRQUFPO0FBQzlDLE1BQUksaUJBQWlCLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDeEMsTUFBSSxpQ0FBaUMsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUN4RCxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFlBQVksTUFBd0U7QUFDM0YsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFHVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUc5QyxRQUFNLEtBQUssRUFBRTtBQUNiLE1BQUksT0FBTyxXQUFXLE9BQU8sZ0NBQWdDLENBQUMsSUFBSSxFQUFFLE1BQU0sR0FBRztBQUMzRSxXQUFPO0FBQUEsRUFDVDtBQUNBLFFBQU0sU0FDSCxPQUFPLEVBQUUsWUFBWSxZQUFZLEVBQUUsV0FDbkMsT0FBTyxJQUFJLEVBQUUsWUFBWSxHQUFHLFdBQVcsWUFDckMsSUFBSSxJQUFJLEVBQUUsWUFBWSxHQUFHLE1BQU0sR0FBRztBQUN2QyxNQUFJLE9BQU8sV0FBVyxZQUFZLENBQUMsWUFBWSxLQUFLLE1BQU0sRUFBRyxRQUFPO0FBQ3BFLFFBQU0sYUFBYSxlQUFlLE1BQU0sTUFBTTtBQUM5QyxNQUFJLENBQUMsV0FBWSxRQUFPO0FBQ3hCLFNBQU8sRUFBRSxVQUFVLFFBQVEsYUFBYSxXQUFXO0FBQ3JEO0FBRUEsU0FBUyxlQUFlLE1BQWUsU0FBZ0M7QUFDckUsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLGFBQWEsSUFBSSxJQUFJLElBQUksRUFBRSxJQUFJLEdBQUcsWUFBWSxHQUFHLE1BQU07QUFDN0QsU0FDRSxVQUFVLElBQUksWUFBWSxJQUFJLEdBQUcsV0FBVyxLQUM1QyxVQUFVLElBQUksWUFBWSxNQUFNLEdBQUcsV0FBVyxLQUM5QyxVQUFVLElBQUksRUFBRSxNQUFNLEdBQUcsV0FBVyxLQUNwQyx3QkFBd0IsTUFBTSxPQUFPO0FBRXpDO0FBRUEsU0FBUyx3QkFBd0IsTUFBZSxTQUFnQztBQUM5RSxRQUFNLE9BQU8sb0JBQUksUUFBZ0I7QUFDakMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLE1BQU0sTUFBTSxJQUFJO0FBQ3RCLFFBQUksT0FBTyxRQUFRLFVBQVU7QUFDM0IsWUFBTSxTQUFTLG1CQUFtQixLQUFLLE9BQU87QUFDOUMsVUFBSSxPQUFRLFFBQU87QUFDbkI7QUFBQSxJQUNGO0FBQ0EsUUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVU7QUFDN0MsUUFBSSxLQUFLLElBQUksR0FBYSxFQUFHO0FBQzdCLFNBQUssSUFBSSxHQUFhO0FBQ3RCLFFBQUksTUFBTSxRQUFRLEdBQUcsR0FBRztBQUN0QixpQkFBVyxLQUFLLElBQUssT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNuQyxPQUFPO0FBQ0wsaUJBQVcsS0FBSyxPQUFPLE9BQU8sR0FBOEIsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQzdFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsbUJBQW1CLFFBQWdCLFNBQWdDO0FBQzFFLE1BQUk7QUFDRixVQUFNLE1BQU0sSUFBSSxJQUFJLFFBQVEsZ0JBQWdCO0FBQzVDLFFBQUksSUFBSSxhQUFhLFdBQVcsSUFBSSxhQUFhLGNBQWUsUUFBTztBQUN2RSxVQUFNLFFBQVEsSUFBSSxTQUFTLE1BQU0sc0RBQXNEO0FBQ3ZGLFFBQUksQ0FBQyxTQUFTLE1BQU0sQ0FBQyxNQUFNLFFBQVMsUUFBTztBQUMzQyxXQUFPLE1BQU0sQ0FBQyxLQUFLO0FBQUEsRUFDckIsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLGNBQWNDLE1BQXlCO0FBSzlDLFFBQU0sTUFBaUIsQ0FBQztBQUN4QixRQUFNLE9BQU8sb0JBQUksUUFBZ0I7QUFDakMsUUFBTSxRQUFtQixDQUFDQSxJQUFHO0FBQzdCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxPQUFPLE1BQU0sSUFBSTtBQUN2QixRQUFJLFNBQVMsUUFBUSxTQUFTLE9BQVc7QUFDekMsUUFBSSxPQUFPLFNBQVMsU0FBVTtBQUM5QixRQUFJLEtBQUssSUFBSSxJQUFjLEVBQUc7QUFDOUIsU0FBSyxJQUFJLElBQWM7QUFFdkIsUUFBSSxlQUFlLElBQUksR0FBRztBQUN4QixVQUFJLEtBQUssWUFBWSxJQUFJLENBQUM7QUFBQSxJQUM1QjtBQUNBLFFBQUksTUFBTSxRQUFRLElBQUksR0FBRztBQUN2QixpQkFBVyxLQUFLLEtBQU0sT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNwQyxPQUFPO0FBQ0wsaUJBQVcsS0FBSyxPQUFPLE9BQU8sSUFBK0IsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQzlFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsZUFBZSxNQUFnRDtBQUN0RSxNQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsS0FBTSxRQUFPO0FBQ3RELFFBQU0sSUFBSTtBQUNWLFFBQU0sV0FBVyxFQUFFO0FBQ25CLE1BQ0UsYUFBYSxXQUNiLGFBQWEsZ0NBQ2IsYUFBYSxrQkFDYjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsU0FBTyxPQUFPLEVBQUUsWUFBWSxZQUFZLE9BQU8sRUFBRSxXQUFXLFlBQVksRUFBRSxXQUFXO0FBQ3ZGO0FBRUEsU0FBUyxZQUFZLE1BQXdEO0FBQzNFLE1BQUksS0FBSyxlQUFlLGdDQUFnQyxPQUFPLEtBQUssVUFBVSxVQUFVO0FBQ3RGLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLFdBQVcsS0FBYyxLQUE4QztBQUM5RSxNQUFJLE9BQU8sUUFBUSxZQUFZLFFBQVEsS0FBTSxRQUFPO0FBQ3BELFFBQU0sSUFBSTtBQUVWLE1BQUksRUFBRSxlQUFlLGlCQUFrQixRQUFPO0FBRTlDLFFBQU0sU0FBUyxVQUFVLEVBQUUsT0FBTztBQUtsQyxRQUFNLFNBQVMsSUFBSSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQ2pDLE1BQUksQ0FBQyxPQUFRLFFBQU87QUFFcEIsUUFBTSxPQUFPLElBQUksRUFBRSxJQUFJO0FBQ3ZCLFFBQU0sYUFBYSxJQUFJLElBQUksTUFBTSxZQUFZLEdBQUcsTUFBTTtBQUd0RCxRQUFNLGNBQWMsSUFBSSxZQUFZLElBQUk7QUFDeEMsUUFBTSxhQUFhLElBQUksWUFBWSxNQUFNO0FBQ3pDLFFBQU0sZ0JBQWdCLElBQUksWUFBWSxNQUFNO0FBQzVDLFFBQU0sU0FDSixVQUFVLGFBQWEsV0FBVyxLQUNsQyxVQUFVLFlBQVksV0FBVyxLQUNqQyxVQUFVLFlBQVksV0FBVyxLQUNqQyxVQUFVLE9BQU8sV0FBVztBQUM5QixRQUFNLFlBQ0osVUFBVSxZQUFZLE9BQU8sS0FDN0IsVUFBVSxZQUFZLE1BQU0sS0FDNUIsVUFBVSxPQUFPLFdBQVc7QUFDOUIsTUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFXLFFBQU87QUFNbEMsUUFBTSxTQUFTLG9CQUFvQixZQUFZLGFBQWEsWUFBWSxhQUFhO0FBRXJGLFFBQU0sWUFBWSxJQUFJLElBQUksSUFBSSxFQUFFLFVBQVUsR0FBRyxrQkFBa0IsR0FBRyxNQUFNO0FBQ3hFLFFBQU0sZUFBZSxVQUFVLFdBQVcsSUFBSTtBQUM5QyxRQUFNLGlCQUFpQixVQUFVLE9BQU8sU0FBUyxLQUFLO0FBQ3RELFFBQU0sT0FBTyxnQkFBZ0I7QUFDN0IsUUFBTSxjQUFjLGlCQUFpQixXQUFXLFFBQVEsY0FBYztBQUN0RSxRQUFNLGdCQUFnQixxQkFBcUIsR0FBRyxRQUFRLElBQUksVUFBVTtBQUVwRSxRQUFNLFdBQVcsSUFBSSxPQUFPLFFBQVEsS0FBSyxDQUFDO0FBQzFDLFFBQU0sbUJBQW1CLElBQUksV0FBVyxVQUFVO0FBQ2xELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxXQUFXLGdCQUFnQixvQkFBb0IsUUFBUTtBQUM3RCxRQUFNLE9BQU8sWUFBWSxvQkFBb0IsUUFBUTtBQUNyRCxRQUFNLFFBQVEsYUFBYSxNQUFNO0FBRWpDLFFBQU0sWUFBWSxrQkFBa0IsR0FBRyxNQUFNO0FBTTdDLFFBQU0sa0JBQWtCLElBQUksSUFBSSxJQUFJLE9BQU8sdUJBQXVCLEdBQUcsTUFBTSxHQUFHLE1BQU07QUFDcEYsUUFBTSxZQUFZLGNBQWMsYUFBYSxrQkFBa0Isa0JBQWtCO0FBSWpGLFFBQU0sV0FDSixpQkFBaUIsVUFBVSxPQUFPLFVBQVUsQ0FBQyxLQUFLLGlCQUFpQixVQUFVLEVBQUUsVUFBVSxDQUFDO0FBQzVGLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFFdEIsUUFBTSxRQUFRLElBQUksRUFBRSxLQUFLO0FBQ3pCLFFBQU0sWUFBWSxVQUFVLE9BQU8sS0FBSyxLQUFLLFVBQVUsVUFBVSxPQUFPLEtBQUssQ0FBQztBQUU5RSxRQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzFCLFFBQU0sUUFBUSxJQUFJLE9BQU8sS0FBSztBQUU5QixRQUFNLFFBQXdCO0FBQUEsSUFDNUIsVUFBVTtBQUFBLElBQ1YsZ0JBQWdCO0FBQUEsSUFDaEIsWUFBWTtBQUFBLElBQ1osV0FBVztBQUFBLElBQ1gsbUJBQW1CLElBQUk7QUFBQSxJQUN2QixjQUFjLElBQUk7QUFBQSxJQUNsQixzQkFBc0I7QUFBQSxJQUN0Qix5QkFBeUI7QUFBQSxJQUN6QixvQkFBb0I7QUFBQSxJQUNwQixrQkFBa0I7QUFBQSxJQUNsQix3QkFBd0I7QUFBQSxJQUN4QixXQUFXLEdBQUcsZ0JBQWdCLElBQUksTUFBTSxXQUFXLE1BQU07QUFBQSxJQUN6RCxZQUFZO0FBQUEsSUFDWixpQkFBaUIsVUFBVSxPQUFPLG1CQUFtQjtBQUFBLElBQ3JELG1CQUFtQixVQUFVLE9BQU8seUJBQXlCO0FBQUEsSUFDN0Qsa0JBQWtCLFVBQVUsT0FBTyx1QkFBdUI7QUFBQSxJQUMxRCxxQkFBcUIsVUFBVSxPQUFPLHVCQUF1QjtBQUFBLElBQzdELGlCQUFpQixVQUFVLE9BQU8sb0JBQW9CO0FBQUEsSUFDdEQsb0JBQW9CO0FBQUEsTUFDbEIsSUFBSSxJQUFJLE9BQU8sdUJBQXVCLEdBQUcsTUFBTSxHQUFHLFdBQy9DLE9BQW1DO0FBQUEsSUFDeEM7QUFBQSxJQUNBO0FBQUEsSUFDQSxlQUFlLGlCQUFpQixNQUFNLElBQUk7QUFBQSxJQUMxQyxNQUFNLFVBQVUsT0FBTyxJQUFJO0FBQUEsSUFDM0Isb0JBQW9CLFdBQVcsT0FBTyxrQkFBa0I7QUFBQSxJQUN4RCxRQUFRLFVBQVUsT0FBTyxNQUFNLEtBQUssVUFBVSxFQUFFLE1BQU07QUFBQSxJQUN0RCxpQkFBaUIsVUFBVSxPQUFPLFNBQVM7QUFBQSxJQUMzQztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVksVUFBVSxVQUFVLGNBQWM7QUFBQSxJQUM5QyxlQUFlLFVBQVUsT0FBTyxhQUFhO0FBQUEsSUFDN0MsYUFBYSxVQUFVLFVBQVUsV0FBVztBQUFBLElBQzVDLGFBQWEsVUFBVSxVQUFVLFdBQVc7QUFBQSxJQUM1QyxZQUFZO0FBQUEsSUFDWixnQkFBZ0IsVUFBVSxPQUFPLGNBQWM7QUFBQSxJQUMvQyxvQkFBb0I7QUFBQSxNQUNsQjtBQUFBLFFBQ0UsYUFBYSxJQUFJO0FBQUEsUUFDakIsT0FBTyxVQUFVLFVBQVUsY0FBYztBQUFBLFFBQ3pDLFVBQVUsVUFBVSxPQUFPLGFBQWE7QUFBQSxRQUN4QyxTQUFTLFVBQVUsVUFBVSxXQUFXO0FBQUEsUUFDeEMsUUFBUSxVQUFVLFVBQVUsV0FBVztBQUFBLFFBQ3ZDLE9BQU87QUFBQSxRQUNQLFdBQVcsVUFBVSxPQUFPLGNBQWM7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFBQSxJQUNBO0FBQUEsSUFDQSxnQkFBZ0I7QUFBQSxJQUNoQixjQUFjO0FBQUEsSUFDZCxhQUFhO0FBQUEsSUFDYixzQkFBc0I7QUFBQSxJQUN0QixnQkFBZ0I7QUFBQSxJQUNoQixnQkFBZ0IsSUFBSTtBQUFBLElBQ3BCLGdCQUFnQjtBQUFBLEVBQ2xCO0FBRUEsU0FBTztBQUNUO0FBRUEsU0FBUyxrQkFBa0IsR0FBNEIsUUFBNEM7QUFDakcsTUFBSSxPQUFPLDJCQUEyQixPQUFPLHdCQUF5QixRQUFPO0FBQzdFLE1BQUksT0FBTywwQkFBMkIsUUFBTztBQUM3QyxNQUFJLE9BQU8sb0JBQW9CLFFBQVEsT0FBTyxxQkFBc0IsUUFBTztBQUMzRSxNQUFJLEVBQUUsZUFBZSw4QkFBOEI7QUFBQSxFQUVuRDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLFVBQVUsSUFBSSxPQUFRLEVBQXdCLElBQUksSUFBSTtBQUFBLEVBQ3RGLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxnQkFBZ0IsVUFBNkM7QUFDcEUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFNBQU8sSUFDSjtBQUFBLElBQUksQ0FBQyxNQUNKLE9BQU8sTUFBTSxZQUFZLEtBQUssaUJBQWlCLElBQzNDLE9BQVEsRUFBK0IsV0FBVyxJQUNsRDtBQUFBLEVBQ04sRUFDQyxPQUFPLENBQUMsTUFBbUIsT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLENBQUM7QUFDckU7QUFFQSxTQUFTLFlBQVksVUFBZ0Q7QUFDbkUsUUFBTSxNQUFNLFNBQVM7QUFDckIsTUFBSSxDQUFDLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxDQUFDO0FBQ2pDLFFBQU0sTUFBbUIsQ0FBQztBQUMxQixhQUFXLEtBQUssS0FBSztBQUNuQixRQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTTtBQUN6QyxVQUFNLElBQUk7QUFDVixVQUFNLFFBQVEsVUFBVSxFQUFFLEdBQUc7QUFDN0IsVUFBTSxXQUFXLFVBQVUsRUFBRSxZQUFZO0FBQ3pDLFVBQU0sVUFBVSxVQUFVLEVBQUUsV0FBVztBQUN2QyxRQUFJLENBQUMsU0FBUyxDQUFDLFNBQVU7QUFDekIsUUFBSSxLQUFLLEVBQUUsT0FBTyxVQUFVLFNBQVMsV0FBVyxTQUFTLENBQUM7QUFBQSxFQUM1RDtBQUNBLFNBQU87QUFDVDtBQUVBLFNBQVMsYUFBYSxRQUE4QztBQUNsRSxRQUFNLFdBQVcsSUFBSSxPQUFPLGlCQUFpQjtBQUM3QyxRQUFNLFVBQVUsV0FBVyxRQUFRLFNBQVMsS0FBSyxJQUFJLENBQUM7QUFDdEQsUUFBTSxVQUFVLFFBQVEsSUFBSSxPQUFPLFFBQVEsR0FBRyxLQUFLO0FBQ25ELFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sU0FBUyxDQUFDLEdBQUcsU0FBUyxHQUFHLE9BQU8sRUFBRSxPQUFPLENBQUMsTUFBTTtBQUNwRCxRQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTSxRQUFPO0FBQ2hELFVBQU0sS0FDSixVQUFXLEVBQThCLFNBQVMsS0FDbEQsVUFBVyxFQUE4QixNQUFNO0FBQ2pELFFBQUksQ0FBQyxHQUFJLFFBQU87QUFDaEIsUUFBSSxLQUFLLElBQUksRUFBRSxFQUFHLFFBQU87QUFDekIsU0FBSyxJQUFJLEVBQUU7QUFDWCxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0QsU0FBTyxPQUFPLElBQUksQ0FBQyxRQUFRLFdBQVcsR0FBOEIsQ0FBQztBQUN2RTtBQUVBLFNBQVMsV0FBVyxHQUF1QztBQUN6RCxRQUFNLE9BQU8sVUFBVSxFQUFFLElBQUk7QUFDN0IsUUFBTSxXQUFXLGdCQUFnQixHQUFHLElBQUk7QUFDeEMsUUFBTUMsUUFBTyxJQUFJLEVBQUUsYUFBYTtBQUNoQyxRQUFNLFlBQVksSUFBSSxFQUFFLFVBQVU7QUFDbEMsUUFBTSxhQUFhLFVBQVUsV0FBVyxlQUFlO0FBQ3ZELFFBQU0sVUFBVSxVQUFVLEVBQUUsWUFBWTtBQUN4QyxRQUFNLFVBQ0osVUFBVSxFQUFFLFNBQVMsS0FDckIsVUFBVSxFQUFFLE1BQU0sS0FDbEIsR0FBRyxRQUFRLE9BQU8sSUFBSSxLQUFLLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztBQUMzRCxTQUFPO0FBQUEsSUFDTCxVQUFVO0FBQUEsSUFDVixZQUFhLFFBQVE7QUFBQSxJQUNyQixjQUFjLFlBQVk7QUFBQSxJQUMxQixtQkFBbUI7QUFBQSxJQUNuQixRQUFRO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxjQUFjLGVBQWUsT0FBTyxhQUFhLE1BQU87QUFBQSxJQUN4RCxPQUFPLFVBQVVBLE9BQU0sS0FBSztBQUFBLElBQzVCLFFBQVEsVUFBVUEsT0FBTSxNQUFNO0FBQUEsSUFDOUIsVUFBVTtBQUFBLElBQ1YsZ0JBQWdCO0FBQUEsSUFDaEIsa0JBQWtCO0FBQUEsSUFDbEIsaUJBQWlCO0FBQUEsRUFDbkI7QUFDRjtBQUVBLFNBQVMsZ0JBQWdCLEdBQTRCLE1BQW9DO0FBQ3ZGLE1BQUksU0FBUyxRQUFTLFFBQU8sVUFBVSxFQUFFLGVBQWUsS0FBSyxVQUFVLEVBQUUsU0FBUztBQUNsRixRQUFNLFdBQVcsUUFBUSxJQUFJLEVBQUUsVUFBVSxHQUFHLFFBQVE7QUFDcEQsTUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLFVBQVUsRUFBRSxlQUFlO0FBRTdELE1BQUksT0FBZ0Q7QUFDcEQsYUFBVyxLQUFLLFVBQVU7QUFDeEIsVUFBTSxLQUFLLFVBQVUsRUFBRSxZQUFZO0FBQ25DLFVBQU0sTUFBTSxVQUFVLEVBQUUsR0FBRztBQUMzQixRQUFJLENBQUMsSUFBSztBQUNWLFFBQUksT0FBTyxhQUFhO0FBQ3RCLFlBQU0sS0FBSyxVQUFVLEVBQUUsT0FBTyxLQUFLO0FBQ25DLFVBQUksQ0FBQyxRQUFRLEtBQUssS0FBSyxRQUFTLFFBQU8sRUFBRSxLQUFLLFNBQVMsR0FBRztBQUFBLElBQzVELFdBQVcsQ0FBQyxNQUFNO0FBRWhCLGFBQU8sRUFBRSxLQUFLLFNBQVMsRUFBRTtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNBLFNBQU8sTUFBTSxPQUFPO0FBQ3RCO0FBRUEsU0FBUyxpQkFBaUIsTUFBYyxNQUEyQjtBQUNqRSxNQUFJLEtBQUssV0FBVyxFQUFHLFFBQU87QUFDOUIsTUFBSSxNQUFNO0FBQ1YsYUFBVyxLQUFLLEtBQU0sT0FBTSxJQUFJLE1BQU0sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVE7QUFDOUQsU0FBTztBQUNUO0FBRUEsU0FBUyxpQkFBaUIsR0FBaUM7QUFDekQsTUFBSSxDQUFDLEVBQUcsUUFBTztBQUVmLFFBQU0sSUFBSSxJQUFJLEtBQUssQ0FBQztBQUNwQixNQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU87QUFDdEMsU0FBTyxFQUFFLFlBQVk7QUFDdkI7QUFFQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsU0FBTyxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsSUFBSSxJQUFJO0FBQ3JEO0FBQ0EsU0FBUyxXQUFXLEdBQTRCO0FBQzlDLFNBQU8sT0FBTyxNQUFNLFlBQVksSUFBSTtBQUN0QztBQUNBLFNBQVMsVUFBVSxHQUEyQjtBQUM1QyxNQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUN4RCxNQUFJLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxHQUFHO0FBQ3pDLFVBQU0sSUFBSSxPQUFPLENBQUM7QUFDbEIsUUFBSSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFBQSxFQUNqQztBQUNBLFNBQU87QUFDVDtBQUNBLFNBQVMsVUFBVSxHQUFvQjtBQUNyQyxTQUFPLFVBQVUsQ0FBQyxLQUFLO0FBQ3pCO0FBQ0EsU0FBUyxJQUFJLEdBQTRDO0FBQ3ZELFNBQU8sT0FBTyxNQUFNLFlBQVksTUFBTSxRQUFRLENBQUMsTUFBTSxRQUFRLENBQUMsSUFDekQsSUFDRDtBQUNOO0FBQ0EsU0FBUyxRQUFRLEdBQXVCO0FBQ3RDLFNBQU8sTUFBTSxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUM7QUFDakM7QUF3QkEsU0FBUyxpQkFDUCxXQUNBLFFBQ0EsVUFDUztBQUNULE1BQUksVUFBVyxRQUFPO0FBQ3RCLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFDdEIsUUFBTSxXQUFXLElBQUksT0FBTyxRQUFRO0FBQ3BDLFFBQU0sT0FBTyxXQUFXLFNBQVMsT0FBTztBQUN4QyxNQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDdkIsZUFBVyxLQUFLLE1BQU07QUFDcEIsVUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU07QUFDekMsWUFBTSxNQUFPLEVBQThCO0FBSTNDLFVBQUksT0FBTyxRQUFRLFlBQVksd0JBQXdCLEtBQUssR0FBRyxHQUFHO0FBQ2hFLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUF3Qk8sU0FBUyxjQUNkLFFBQ0EsVUFDQSxjQUFtQyxvQkFBSSxJQUFJLEdBQ3pCO0FBQ2xCLE1BQUksU0FBUyxTQUFTLEtBQUssWUFBWSxTQUFTLEVBQUcsUUFBTztBQUsxRCxRQUFNLGdCQUFnQixvQkFBSSxJQUFZO0FBQ3RDLFFBQU0sbUJBQW1CLG9CQUFJLElBQVk7QUFDekMsYUFBVyxLQUFLLFFBQVE7QUFDdEIsUUFBSSxDQUFDLFNBQVMsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEVBQUc7QUFDbkQscUJBQWlCLElBQUksRUFBRSxRQUFRO0FBQy9CLFFBQUksRUFBRSxnQkFBaUIsZUFBYyxJQUFJLEVBQUUsZUFBZTtBQUMxRCxRQUFJLEVBQUUsbUJBQW9CLGVBQWMsSUFBSSxFQUFFLGtCQUFrQjtBQUNoRSxRQUFJLEVBQUUsa0JBQW1CLGVBQWMsSUFBSSxFQUFFLGlCQUFpQjtBQUFBLEVBQ2hFO0FBQ0EsU0FBTyxPQUFPLE9BQU8sQ0FBQyxNQUFNO0FBQzFCLFVBQU0sSUFBSSxFQUFFLGVBQWUsWUFBWTtBQUN2QyxRQUFJLFNBQVMsSUFBSSxDQUFDLEVBQUcsUUFBTztBQUM1QixRQUFJLFlBQVksSUFBSSxDQUFDLEVBQUcsUUFBTztBQUUvQixRQUFJLGNBQWMsSUFBSSxFQUFFLFFBQVEsRUFBRyxRQUFPO0FBSTFDLFFBQUksRUFBRSxtQkFBbUIsaUJBQWlCLElBQUksRUFBRSxlQUFlLEVBQUcsUUFBTztBQUN6RSxRQUFJLEVBQUUscUJBQXFCLGlCQUFpQixJQUFJLEVBQUUsaUJBQWlCLEVBQUcsUUFBTztBQUU3RSxRQUFJLEVBQUUsb0JBQW9CLFNBQVMsSUFBSSxFQUFFLGlCQUFpQixZQUFZLENBQUMsRUFBRyxRQUFPO0FBQ2pGLGVBQVcsS0FBSyxFQUFFLFVBQVU7QUFDMUIsVUFBSSxTQUFTLElBQUksRUFBRSxZQUFZLENBQUMsRUFBRyxRQUFPO0FBQUEsSUFDNUM7QUFDQSxXQUFPO0FBQUEsRUFDVCxDQUFDO0FBQ0g7QUFTQSxTQUFTLHFCQUNQLEdBQ0EsUUFDQSxZQUNzQjtBQUN0QixRQUFNLFFBQVEsSUFBSSxFQUFFLGVBQWUsS0FBSyxJQUFJLE9BQU8sZUFBZTtBQUNsRSxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLFFBQU0sV0FBVyxJQUFJLE1BQU0sUUFBUTtBQUNuQyxRQUFNLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDM0IsUUFBTSxVQUFVLFVBQVUsVUFBVSxJQUFJO0FBQ3hDLFFBQU0sUUFBUSxVQUFVLE1BQU0sS0FBSztBQUNuQyxRQUFNLGFBQWEsVUFBVSxNQUFNLFVBQVU7QUFDN0MsUUFBTSxpQkFBaUIsVUFBVSxNQUFNLGNBQWM7QUFDckQsUUFBTSxTQUFTLFVBQVUsTUFBTSxNQUFNLEtBQUssVUFBVSxNQUFNLE9BQU87QUFFakUsTUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsT0FBUSxRQUFPO0FBQzFDLFNBQU87QUFBQSxJQUNMLFNBQVM7QUFBQSxJQUNUO0FBQUEsSUFDQSxhQUFhO0FBQUEsSUFDYjtBQUFBLElBQ0EsaUJBQWlCO0FBQUEsSUFDakIsYUFBYTtBQUFBLEVBQ2Y7QUFDRjtBQU9BLFNBQVMsb0JBQ1AsWUFDQSxhQUNBLFlBQ0EsZUFDYztBQUNkLFFBQU0sZUFBZSxJQUFJLFlBQVksWUFBWTtBQUNqRCxTQUFPO0FBQUEsSUFDTCxjQUNFLFVBQVUsYUFBYSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUksS0FBSyxVQUFVLFlBQVksSUFBSTtBQUFBLElBQzNGLFlBQ0UsVUFBVSxlQUFlLFNBQVMsS0FDbEMsVUFBVSxZQUFZLHVCQUF1QixLQUM3QyxVQUFVLFlBQVksdUJBQXVCO0FBQUEsSUFDL0MsVUFBVSxXQUFXLGNBQWMsUUFBUSxLQUFLLFdBQVcsWUFBWSxRQUFRO0FBQUEsSUFDL0Usa0JBQWtCLFdBQVcsWUFBWSxnQkFBZ0I7QUFBQSxJQUN6RCxlQUFlLFVBQVUsY0FBYyxhQUFhLEtBQUssVUFBVSxZQUFZLGFBQWE7QUFBQSxJQUM1RixhQUFhLFVBQVUsWUFBWSxXQUFXO0FBQUEsSUFDOUMsVUFBVSxVQUFVLElBQUksWUFBWSxRQUFRLEdBQUcsUUFBUSxLQUFLLFVBQVUsWUFBWSxRQUFRO0FBQUEsSUFDMUYsS0FBSyxVQUFVLFlBQVksR0FBRztBQUFBLElBQzlCLGlCQUFpQixVQUFVLFlBQVksZUFBZTtBQUFBLElBQ3RELGVBQWUsVUFBVSxZQUFZLGFBQWE7QUFBQSxJQUNsRCxnQkFBZ0IsVUFBVSxZQUFZLGNBQWM7QUFBQSxJQUNwRCxvQkFDRSxpQkFBaUIsVUFBVSxhQUFhLFVBQVUsQ0FBQyxLQUNuRCxpQkFBaUIsVUFBVSxZQUFZLFVBQVUsQ0FBQztBQUFBLElBQ3BELFdBQVcsV0FBVyxZQUFZLFNBQVM7QUFBQSxFQUM3QztBQUNGO0FBT0EsU0FBUyxZQUFZLEdBQThDO0FBQ2pFLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxNQUFNLE1BQU07QUFDbkMsTUFBSSxDQUFDLFdBQVksUUFBTztBQUN4QixRQUFNLFdBQVcsV0FBVztBQUM1QixRQUFNLFFBQWlDLENBQUM7QUFDeEMsTUFBSSxNQUFNLFFBQVEsUUFBUSxHQUFHO0FBQzNCLGVBQVcsTUFBTSxVQUFVO0FBQ3pCLFVBQUksT0FBTyxPQUFPLFlBQVksT0FBTyxLQUFNO0FBQzNDLFlBQU0sSUFBSTtBQUNWLFlBQU0sSUFBSSxVQUFVLEVBQUUsR0FBRztBQUN6QixZQUFNLElBQUksSUFBSSxFQUFFLEtBQUs7QUFDckIsVUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFHO0FBQ2QsWUFBTSxDQUFDLElBQ0wsVUFBVSxFQUFFLFlBQVksS0FDeEIsVUFBVSxJQUFJLEVBQUUsV0FBVyxHQUFHLEdBQUcsS0FDakMsVUFBVSxJQUFJLEVBQUUsaUJBQWlCLEdBQUcsT0FBTztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxVQUFVLFdBQVcsSUFBSTtBQUN0QyxRQUFNLFVBQVUsVUFBVSxXQUFXLEdBQUc7QUFDeEMsUUFBTSxZQUNKLE9BQU8sTUFBTSxZQUFZLE1BQU0sV0FBWSxNQUFNLFlBQVksSUFBZTtBQUM5RSxRQUFNLFFBQVEsT0FBTyxNQUFNLE9BQU8sTUFBTSxXQUFZLE1BQU0sT0FBTyxJQUFlO0FBQ2hGLFFBQU0sY0FDSixPQUFPLE1BQU0sYUFBYSxNQUFNLFdBQVksTUFBTSxhQUFhLElBQWU7QUFDaEYsUUFBTSxZQUNILE9BQU8sTUFBTSxnQ0FBZ0MsTUFBTSxXQUMvQyxNQUFNLGdDQUFnQyxJQUN2QyxVQUNILE9BQU8sTUFBTSwwQkFBMEIsTUFBTSxXQUN6QyxNQUFNLDBCQUEwQixJQUNqQyxVQUNILE9BQU8sTUFBTSw4QkFBOEIsTUFBTSxXQUM3QyxNQUFNLDhCQUE4QixJQUNyQztBQUNOLE1BQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxTQUFVLFFBQU87QUFDekQsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBLFVBQVU7QUFBQSxJQUNWLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsV0FBVztBQUFBLEVBQ2I7QUFDRjs7O0FDcjBCQSxJQUFNLFdBQVc7QUFFVixTQUFTLFdBQW1CO0FBQ2pDLFFBQU0sS0FBSyxLQUFLLElBQUk7QUFDcEIsTUFBSSxTQUFTO0FBQ2IsTUFBSSxJQUFJO0FBQ1IsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7QUFDM0IsY0FBVSxTQUFTLElBQUksRUFBRSxLQUFLLE9BQU87QUFDckMsUUFBSSxLQUFLLE1BQU0sSUFBSSxFQUFFO0FBQUEsRUFDdkI7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxNQUFJLFdBQVc7QUFDZixhQUFXLEtBQUssS0FBTSxhQUFZLFNBQVMsSUFBSSxFQUFFLEtBQUs7QUFDdEQsU0FBTyxTQUFTO0FBQ2xCO0FBRU8sU0FBUyxXQUFXLElBQW9CO0FBQzdDLFNBQU8sR0FBRyxNQUFNLEVBQUU7QUFDcEI7OztBQ1BBLElBQU0sbUJBQWlELG9CQUFJLElBQUk7QUFBQSxFQUM3RDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBRU0sU0FBUyxrQkFBa0IsTUFBK0I7QUFDL0QsUUFBTSxXQUE0QixDQUFDO0FBQ25DLE1BQUksVUFBa0MsQ0FBQztBQUN2QyxNQUFJLGFBQWE7QUFDakIsUUFBTSxRQUFRLE1BQU07QUFDbEIsUUFBSSxRQUFRLFVBQVUsUUFBUSxPQUFPO0FBQ25DLFVBQUksQ0FBQyxRQUFRLFNBQVUsU0FBUSxXQUFXO0FBQzFDLGVBQVMsS0FBSyxPQUF3QjtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNBLGFBQVcsV0FBVyxLQUFLLE1BQU0sSUFBSSxHQUFHO0FBQ3RDLFVBQU0sT0FBTyxjQUFjLE9BQU87QUFDbEMsUUFBSSxLQUFLLEtBQUssTUFBTSxHQUFJO0FBQ3hCLFFBQUksZ0JBQWdCLEtBQUssSUFBSSxHQUFHO0FBQzlCLG1CQUFhO0FBQ2I7QUFBQSxJQUNGO0FBQ0EsUUFBSSxDQUFDLFdBQVk7QUFFakIsVUFBTSxZQUFZLEtBQUssTUFBTSw0QkFBNEI7QUFDekQsUUFBSSxXQUFXO0FBQ2IsWUFBTTtBQUNOLGdCQUFVLEVBQUUsUUFBUSxRQUFRLFVBQVUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtBQUNoRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLGFBQWEsS0FBSyxNQUFNLHdCQUF3QjtBQUN0RCxRQUFJLGNBQWMsQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQ3JDLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxXQUFXLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDakQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx1QkFBdUI7QUFDckQsUUFBSSxjQUFjLFFBQVEsUUFBUTtBQUNoQyxjQUFRLFFBQVEsUUFBUSxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQzNDO0FBQUEsSUFDRjtBQUNBLFVBQU0sZ0JBQWdCLEtBQUssTUFBTSwwQkFBMEI7QUFDM0QsUUFBSSxpQkFBaUIsUUFBUSxRQUFRO0FBQ25DLFlBQU0sTUFBTSxRQUFRLGNBQWMsQ0FBQyxLQUFLLEVBQUU7QUFDMUMsY0FBUSxXQUFXLGlCQUFpQixJQUFJLEdBQXNCLElBQ3pELE1BQ0Q7QUFDSjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTTtBQUNOLFNBQU8sU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sU0FBUyxDQUFDO0FBQ25EO0FBRUEsU0FBUyxjQUFjLE1BQXNCO0FBRzNDLFFBQU0sTUFBTSxLQUFLLFFBQVEsR0FBRztBQUM1QixTQUFPLFFBQVEsS0FBSyxPQUFPLEtBQUssTUFBTSxHQUFHLEdBQUc7QUFDOUM7QUFFQSxTQUFTLFFBQVEsR0FBbUI7QUFDbEMsUUFBTSxVQUFVLEVBQUUsS0FBSztBQUN2QixNQUNHLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsS0FDL0MsUUFBUSxXQUFXLEdBQUcsS0FBSyxRQUFRLFNBQVMsR0FBRyxHQUNoRDtBQUNBLFdBQU8sUUFBUSxNQUFNLEdBQUcsRUFBRTtBQUFBLEVBQzVCO0FBQ0EsU0FBTztBQUNUOzs7QUNXQSxJQUFNLGNBQWMsUUFBUSxRQUFRLFlBQVksRUFBRTtBQUNsRCxJQUFNLDJCQUEyQjtBQUNqQyxJQUFNLDZCQUE2QjtBQUNuQyxJQUFNLG1DQUFtQztBQUN6QyxJQUFNLCtCQUErQixDQUFDLFNBQVMsU0FBUyxNQUFNO0FBQzlELElBQU0sMkNBQTJDLENBQUMsU0FBUyxrQkFBa0IsT0FBTztBQUNwRixJQUFNLGtDQUFrQztBQUFBLEVBQ3RDO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0Y7QUFDQSxJQUFJLHVCQUF1QjtBQXdCM0IsZUFBZSxDQUFDLE9BQWlCO0FBQy9CLFVBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxhQUFhLE9BQU8sR0FBRyxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQzlFLENBQUM7QUFFRCxTQUFTLDJCQUFpQztBQUN4Qyx5QkFBdUIsS0FBSyxJQUFJLElBQUk7QUFDdEM7QUFJQSxRQUFRLFFBQVEsWUFBWSxZQUFZLFlBQVk7QUFDbEQsUUFBTSxLQUFLLHVCQUF1QixFQUFFLFNBQVMsWUFBWSxDQUFDO0FBQzFELFFBQU0sT0FBTyxTQUFTO0FBQ3hCLENBQUM7QUFFRCxRQUFRLFFBQVEsVUFBVSxZQUFZLE1BQU07QUFDMUMsT0FBSyxPQUFPLFNBQVM7QUFDdkIsQ0FBQztBQUdELEtBQUssT0FBTyxhQUFhO0FBRXpCLGVBQWUsT0FBTyxRQUErQjtBQUNuRCxNQUFJO0FBQ0YsVUFBTSxhQUFhO0FBQ25CLFVBQU0sc0JBQXNCO0FBQzVCLFVBQU0sc0JBQXNCLEVBQUUsUUFBUSxRQUFRLE1BQU0sSUFBSSxLQUFLLE1BQU0sQ0FBQztBQUNwRSxVQUFNLDRCQUE0QjtBQUNsQyxVQUFNLHFCQUFxQjtBQUczQixVQUFNLFNBQVMsTUFBTSxvQkFBb0IsS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFJO0FBQ2pFLFFBQUksU0FBUyxFQUFHLE9BQU0sS0FBSywwQkFBMEIsRUFBRSxPQUFPLENBQUM7QUFDL0QsVUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFJLFNBQVMsT0FBTyxTQUFTLFNBQVMsU0FBUyxNQUFNO0FBQ25ELFlBQU0saUJBQWlCLEtBQUs7QUFDNUIsWUFBTSxvQkFBb0IsS0FBSztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTztBQUFBLFFBQ1AsZUFBZTtBQUFBLFFBQ2Ysd0JBQXdCO0FBQUEsUUFDeEIsa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUNELFlBQU0sS0FBSyx3Q0FBd0MsRUFBRSxPQUFPLENBQUM7QUFBQSxJQUMvRDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFPLGVBQWUsRUFBRSxRQUFRLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUFBLEVBQy9EO0FBQ0Y7QUFFQSxTQUFTLFNBQTBDO0FBQ2pELFFBQU0sZUFBZTtBQUdyQixTQUFPLGFBQWEseUJBQXlCO0FBQy9DO0FBRUEsZUFBZSxpQkFBb0M7QUFDakQsUUFBTSxPQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFDM0YsU0FBTyxLQUFLLFFBQVEsQ0FBQyxRQUFTLE9BQU8sSUFBSSxPQUFPLFdBQVcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUU7QUFDM0U7QUFFQSxlQUFlLHNCQUFzQjtBQUFBLEVBQ25DO0FBQUEsRUFDQTtBQUNGLEdBR2tCO0FBQ2hCLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxNQUFNLE9BQU87QUFDbkIsTUFBSSxDQUFDLEtBQUs7QUFDUixRQUFJLFNBQVMsd0JBQXdCLEtBQUs7QUFDeEMsWUFBTSxLQUFLLHlFQUF5RTtBQUFBLFFBQ2xGO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSDtBQUNBO0FBQUEsRUFDRjtBQUVBLFFBQU0sU0FBUyxTQUFTLHVCQUF1QixNQUFNLGVBQWUsSUFBSSxDQUFDO0FBQ3pFLFFBQU0sZ0JBQWdCO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEdBQUcsZ0NBQWdDLElBQUksQ0FBQyxHQUFHLFFBQVEsbUNBQW1DLEdBQUc7QUFBQSxFQUMzRjtBQUNBLFFBQU0sV0FDSixPQUFPLFNBQVMsSUFDWjtBQUFBLElBQ0U7QUFBQSxNQUNFLElBQUk7QUFBQSxNQUNKLFVBQVU7QUFBQSxNQUNWLFFBQVEsRUFBRSxNQUFNLFFBQVE7QUFBQSxNQUN4QixXQUFXO0FBQUEsUUFDVDtBQUFBLFFBQ0EsZUFBZSxDQUFDLEdBQUcsNEJBQTRCO0FBQUEsTUFDakQ7QUFBQSxJQUNGO0FBQUEsSUFDQSxHQUFHLGdDQUFnQyxJQUFJLENBQUMsV0FBVyxTQUFTO0FBQUEsTUFDMUQsSUFBSSxtQ0FBbUM7QUFBQSxNQUN2QyxVQUFVO0FBQUEsTUFDVixRQUFRLEVBQUUsTUFBTSxRQUFpQjtBQUFBLE1BQ2pDLFdBQVc7QUFBQSxRQUNUO0FBQUEsUUFDQTtBQUFBLFFBQ0EsZUFBZSxDQUFDLEdBQUcsd0NBQXdDO0FBQUEsTUFDN0Q7QUFBQSxJQUNGLEVBQUU7QUFBQSxFQUNKLElBQ0EsQ0FBQztBQUNQLFFBQU0sSUFBSSxtQkFBbUI7QUFBQSxJQUMzQjtBQUFBLElBQ0E7QUFBQSxFQUNGLENBQUM7QUFFRCxNQUFJLEtBQUs7QUFDUCxVQUFNLEtBQUssd0NBQXdDO0FBQUEsTUFDakQsU0FBUyxTQUFTO0FBQUEsTUFDbEIsV0FBVyxPQUFPO0FBQUEsTUFDbEIsd0JBQXdCLDZCQUE2QixLQUFLLEdBQUc7QUFBQSxNQUM3RCx1QkFBdUIsZ0NBQWdDLEtBQUssR0FBRztBQUFBLE1BQy9EO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNGO0FBRUEsUUFBUSxLQUFLLFVBQVUsWUFBWSxDQUFDLFFBQVEsZUFBZTtBQUN6RCxNQUFJLFdBQVcsT0FBTyxXQUFXLFdBQVcsWUFBWTtBQUN0RCxTQUFLLHNCQUFzQixFQUFFLFFBQVEsZUFBZSxLQUFLLE1BQU0sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQy9FLFdBQUssS0FBSyxxQ0FBcUMsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUNuRSxDQUFDO0FBQUEsRUFDSDtBQUNGLENBQUM7QUFFRCxRQUFRLEtBQUssVUFBVSxZQUFZLE1BQU07QUFDdkMsT0FBSyxzQkFBc0IsRUFBRSxRQUFRLGVBQWUsS0FBSyxNQUFNLENBQUMsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUMvRSxTQUFLLEtBQUsscUNBQXFDLGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDbkUsQ0FBQztBQUNILENBQUM7QUFZRCxlQUFlLHVCQUFzQztBQUNuRCxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUFBLEVBQ3ZGLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyw2QkFBNkIsY0FBYyxHQUFHLENBQUM7QUFDMUQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVU7QUFDaEMsUUFBSTtBQUNGLFlBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPLENBQUMsY0FBYztBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXRCLE9BQU87QUFBQSxNQUNULENBQUM7QUFDRCxZQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTyxDQUFDLFlBQVk7QUFBQSxNQUN0QixDQUFDO0FBQ0QsWUFBTSxLQUFLLHFDQUFxQztBQUFBLFFBQzlDLE9BQU8sSUFBSTtBQUFBLFFBQ1gsS0FBSyxXQUFXLElBQUksT0FBTyxFQUFFO0FBQUEsTUFDL0IsQ0FBQztBQUFBLElBQ0gsU0FBUyxLQUFLO0FBSVosWUFBTSxLQUFLLHdDQUF3QztBQUFBLFFBQ2pELE9BQU8sSUFBSTtBQUFBLFFBQ1gsS0FBSyxXQUFXLElBQUksT0FBTyxFQUFFO0FBQUEsUUFDN0IsR0FBRyxjQUFjLEdBQUc7QUFBQSxNQUN0QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQWUsZUFBOEI7QUFDM0MsUUFBTSxRQUFRLE9BQU8sTUFBTSxhQUFhO0FBQ3hDLFFBQU0sUUFBUSxPQUFPLE1BQU0sbUJBQW1CO0FBQzlDLFFBQU0sUUFBUSxPQUFPLE9BQU8sZUFBZSxFQUFFLGlCQUFpQixvQkFBb0IsQ0FBQztBQUNuRixRQUFNLFFBQVEsT0FBTyxPQUFPLHFCQUFxQjtBQUFBLElBQy9DLGlCQUFpQixnQ0FBZ0M7QUFBQSxFQUNuRCxDQUFDO0FBQ0g7QUFNQSxJQUFJLGtCQUF5RDtBQUM3RCxJQUFNLDZCQUE2QixLQUFLLEtBQUs7QUFNN0MsSUFBTSw4QkFBOEIsb0JBQUksSUFBK0I7QUFLdkUsSUFBTSxpQkFBaUI7QUFFdkIsZUFBZSx3QkFBdUM7QUFFcEQsUUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsTUFBSSxTQUFTLFFBQVEsRUFBRSxZQUFZLE9BQU87QUFDeEMsdUJBQW1CLEVBQUUscUJBQXFCO0FBQUEsRUFDNUMsT0FBTztBQUNMLHlCQUFxQjtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLHVCQUE2QjtBQUNwQyxNQUFJLG9CQUFvQixNQUFNO0FBQzVCLGtCQUFjLGVBQWU7QUFDN0Isc0JBQWtCO0FBQUEsRUFDcEI7QUFDRjtBQUVBLFNBQVMsbUJBQW1CLGFBQTJCO0FBQ3JELHVCQUFxQjtBQUNyQixRQUFNLFVBQVUsS0FBSztBQUFBLElBQ25CO0FBQUEsSUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxXQUFXLENBQUM7QUFBQSxFQUN2RDtBQUNBLG9CQUFrQixZQUFZLE1BQU07QUFDbEMsU0FBSyxlQUFlLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDbkMsV0FBSyxLQUFLLDJCQUEyQixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3pELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsZUFBZSxzQkFBcUM7QUFDbEQsMkJBQXlCO0FBQ3pCLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsYUFBYTtBQUFBLElBQ2IsZUFBZTtBQUFBLElBQ2Ysa0JBQWtCO0FBQUEsSUFDbEIsdUJBQXVCO0FBQUEsSUFDdkIsaUJBQWlCO0FBQUEsSUFDakIsZUFBZTtBQUFBLEVBQ2pCLENBQUM7QUFDRCxxQkFBbUIsRUFBRSxxQkFBcUI7QUFDMUMsUUFBTSxLQUFLLDRCQUE0QixFQUFFLGNBQWMsRUFBRSxzQkFBc0IsQ0FBQztBQUVoRixPQUFLLGVBQWU7QUFDcEIsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQsdUJBQXFCO0FBQ3JCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLE1BQU0sZUFBZTtBQUFBLElBQzlCLFVBQVUsTUFBTSxpQkFBaUI7QUFBQSxJQUNqQyxVQUFVLE1BQU0saUJBQWlCO0FBQUEsRUFDbkMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsaUJBQWdDO0FBQzdDLE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQUEsRUFDdkYsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlDQUFpQyxjQUFjLEdBQUcsQ0FBQztBQUM5RDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssV0FBVyxFQUFHO0FBQ3ZCLE1BQUksY0FBYztBQUNsQixNQUFJLGFBQWE7QUFDakIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxPQUFPLElBQUksT0FBTyxTQUFVO0FBQ2hDLFFBQUksSUFBSSxVQUFXO0FBQ25CLFFBQUk7QUFDRixZQUFNLFVBQVcsTUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3JELFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU87QUFBQSxRQUNQLE1BQU8sTUFBTTtBQUNYLGdCQUFNLGlCQUFpQixDQUFDLE9BQ3RCLEdBQUcsR0FBRyxlQUFlLEVBQUUsSUFBSSxHQUFHLGFBQWEsWUFBWSxLQUFLLEVBQUUsR0FDM0QsUUFBUSxRQUFRLEdBQUcsRUFDbkIsS0FBSyxFQUNMLFlBQVk7QUFDakIsZ0JBQU0sMEJBQTBCLE1BQWU7QUFDN0Msa0JBQU0sWUFBWSxTQUFTLE1BQU0sYUFBYSxJQUFJLFlBQVk7QUFDOUQsZ0JBQ0UsQ0FBQyxTQUFTLFNBQVMsc0JBQXNCLEtBQ3pDLENBQUMsU0FBUyxTQUFTLGVBQWUsR0FDbEM7QUFDQSxxQkFBTztBQUFBLFlBQ1Q7QUFDQSxrQkFBTSxXQUFXLE1BQU07QUFBQSxjQUNyQixTQUFTLGlCQUFpQixnQ0FBZ0M7QUFBQSxZQUM1RDtBQUNBLGtCQUFNLFFBQVEsU0FBUyxLQUFLLENBQUMsT0FBTztBQUNsQyxvQkFBTSxPQUFPLGVBQWUsRUFBRTtBQUM5QixxQkFBTyxTQUFTLFdBQVcsS0FBSyxTQUFTLE9BQU8sS0FBSyxLQUFLLFNBQVMsV0FBVztBQUFBLFlBQ2hGLENBQUM7QUFDRCxnQkFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixZQUFDLE1BQXNCLE1BQU07QUFDN0IsbUJBQU87QUFBQSxVQUNUO0FBQ0EsY0FBSSx3QkFBd0IsRUFBRyxRQUFPLEVBQUUsU0FBUyxNQUFNLFVBQVUsTUFBTTtBQUl2RSxnQkFBTSxPQUEwQjtBQUFBLFlBQzlCLEtBQUs7QUFBQSxZQUNMLE1BQU07QUFBQSxZQUNOLFNBQVM7QUFBQSxZQUNULE9BQU87QUFBQSxZQUNQLFNBQVM7QUFBQSxZQUNULFlBQVk7QUFBQSxVQUNkO0FBQ0EsZ0JBQU0sUUFBUyxTQUFTLGlCQUF3QyxTQUFTO0FBQ3pFLGdCQUFNLGNBQWMsSUFBSSxjQUFjLFdBQVcsSUFBSSxDQUFDO0FBQ3RELGdCQUFNLGNBQWMsSUFBSSxjQUFjLFNBQVMsSUFBSSxDQUFDO0FBQ3BELGlCQUFPLFNBQVM7QUFBQSxZQUNkLEtBQUssU0FBUyxnQkFBZ0I7QUFBQSxZQUM5QixVQUFVO0FBQUEsVUFDWixDQUFDO0FBQ0QsaUJBQU8sRUFBRSxTQUFTLE9BQU8sVUFBVSxLQUFLO0FBQUEsUUFDMUM7QUFBQSxNQUNGLENBQUM7QUFDRCxZQUFNLGNBQWMsUUFDakIsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQ25CO0FBQUEsUUFDQyxDQUFDLFdBQ0MsT0FBTyxXQUFXLFlBQVksV0FBVztBQUFBLE1BQzdDO0FBQ0YsVUFBSSxZQUFZLEtBQUssQ0FBQyxXQUFXLE9BQU8sWUFBWSxJQUFJLEdBQUc7QUFDekQsc0JBQWM7QUFBQSxNQUNoQjtBQUNBLFVBQUksWUFBWSxLQUFLLENBQUMsV0FBVyxPQUFPLGFBQWEsSUFBSSxHQUFHO0FBQzFELHVCQUFlO0FBQUEsTUFDakI7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUdSO0FBQUEsRUFDRjtBQUNBLE1BQUksYUFBYSxHQUFHO0FBQ2xCLFVBQU0sS0FBSyx1Q0FBdUMsRUFBRSxXQUFXLFdBQVcsQ0FBQztBQUFBLEVBQzdFO0FBQ0EsTUFBSSxjQUFjLEdBQUc7QUFDbkIsVUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQUksU0FBUyxNQUFNO0FBQ2pCLFdBQUssZUFBZTtBQUNwQixZQUFNLHFCQUFxQixJQUFJO0FBQUEsSUFFakM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHlCQUErQjtBQUN0QyxRQUFNLFNBQVMsS0FBSyxJQUFJLElBQUk7QUFDNUIsYUFBVyxDQUFDLE9BQU8sS0FBSyxLQUFLLDZCQUE2QjtBQUN4RCxRQUFJLE1BQU0sWUFBWSxPQUFRLDZCQUE0QixPQUFPLEtBQUs7QUFBQSxFQUN4RTtBQUNGO0FBRUEsU0FBUywrQkFDUCxPQUNBLFNBQ0EsUUFDQSxhQUNNO0FBQ04sTUFBSSxVQUFVLFFBQVEsT0FBTyxXQUFXLEtBQUssWUFBWSxTQUFTLEVBQUc7QUFDckUsUUFBTSxlQUFlLG9CQUFJLElBQVk7QUFDckMsYUFBVyxLQUFLLFFBQVE7QUFDdEIsUUFBSSxZQUFZLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxFQUFHLGNBQWEsSUFBSSxFQUFFLFFBQVE7QUFBQSxFQUNsRjtBQUNBLFFBQU0sV0FBVyw0QkFBNEIsSUFBSSxLQUFLO0FBQ3RELFFBQU0sV0FBVyxVQUFVLFlBQVksb0JBQUksSUFBWTtBQUN2RCxhQUFXLEtBQUssUUFBUTtBQUN0QixVQUFNLFNBQVMsRUFBRSxlQUFlLFlBQVk7QUFDNUMsVUFBTSxjQUFjLEVBQUUsa0JBQWtCLFlBQVksS0FBSztBQUN6RCxRQUNFLFlBQVksSUFBSSxNQUFNLEtBQ3JCLGdCQUFnQixRQUFRLFlBQVksSUFBSSxXQUFXLEtBQ25ELEVBQUUsc0JBQXNCLFFBQVEsYUFBYSxJQUFJLEVBQUUsaUJBQWlCLEtBQ3BFLEVBQUUsb0JBQW9CLFFBQVEsYUFBYSxJQUFJLEVBQUUsZUFBZSxLQUNoRSxFQUFFLHVCQUF1QixRQUFRLGFBQWEsSUFBSSxFQUFFLGtCQUFrQixHQUN2RTtBQUNBLGVBQVMsSUFBSSxFQUFFLFFBQVE7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFDQSw4QkFBNEIsSUFBSSxPQUFPO0FBQUEsSUFDckMsV0FBVyxLQUFLLElBQUk7QUFBQSxJQUNwQjtBQUFBLElBQ0E7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUVBLFFBQVEsT0FBTyxRQUFRLFlBQVksQ0FBQyxVQUFVO0FBQzVDLE1BQUksTUFBTSxTQUFTLGVBQWU7QUFDaEMsU0FBSyxpQkFBaUI7QUFBQSxFQUN4QixXQUFXLE1BQU0sU0FBUyxxQkFBcUI7QUFDN0MsU0FBSyxpQkFBaUIsS0FBSztBQUFBLEVBQzdCO0FBSUYsQ0FBQztBQUlELElBQUksUUFBUSxRQUFRLFdBQVc7QUFDN0IsVUFBUSxPQUFPLFVBQVUsWUFBWSxPQUFPLFFBQVE7QUFDbEQsUUFBSTtBQUNGLFlBQU0sZ0JBQWlCLFFBRXBCO0FBQ0gsVUFBSSxlQUFlLFFBQVE7QUFDekIsY0FBTSxjQUFjLE9BQU87QUFDM0I7QUFBQSxNQUNGO0FBRUEsWUFBTSxZQUFhLFFBRWhCO0FBQ0gsVUFBSSxXQUFXLE1BQU07QUFDbkIsY0FBTSxVQUFpQyxDQUFDO0FBQ3hDLFlBQUksT0FBTyxJQUFJLGFBQWEsU0FBVSxTQUFRLFdBQVcsSUFBSTtBQUM3RCxjQUFNLFVBQVUsS0FBSyxPQUFPO0FBQzVCO0FBQUEsTUFDRjtBQUVBLFlBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsUUFBUSxPQUFPLGNBQWMsRUFBRSxDQUFDO0FBQUEsSUFDM0UsU0FBUyxLQUFLO0FBR1osWUFBTSxLQUFLLDRDQUE0QyxjQUFjLEdBQUcsQ0FBQztBQUN6RSxVQUFJO0FBQ0YsY0FBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxRQUFRLE9BQU8sY0FBYyxFQUFFLENBQUM7QUFDekU7QUFBQSxNQUNGLFNBQVMsUUFBUTtBQUNmLGNBQU0sS0FBSyx1Q0FBdUMsY0FBYyxNQUFNLENBQUM7QUFBQSxNQUN6RTtBQUNBLFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUFBLElBQ3hDO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFJQSxRQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsS0FBYyxXQUFXO0FBQzlELE1BQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFHLFFBQU87QUFDbkMsU0FBTyxjQUFjLEtBQUssTUFBTSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQy9DLFNBQUssTUFBTywwQkFBMEIsRUFBRSxNQUFNLElBQUksTUFBTSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDL0UsVUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNILENBQUM7QUFFRCxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxTQUFPLENBQUMsQ0FBQyxLQUFLLE9BQU8sTUFBTSxZQUFZLE9BQVEsRUFBeUIsU0FBUztBQUNuRjtBQUlBLElBQU0sNEJBQTRCLG9CQUFJLElBQTRCO0FBQUEsRUFDaEU7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBRUQsZUFBZSxZQUE4QjtBQUMzQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsZUFBZSxjQUNiLEtBQ0EsUUFDa0I7QUFLbEIsTUFBSSxDQUFFLE1BQU0sVUFBVSxLQUFNLDBCQUEwQixJQUFJLElBQUksSUFBSSxHQUFHO0FBQ25FLFdBQU8sRUFBRSxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUEsRUFDbEM7QUFDQSxVQUFRLElBQUksTUFBTTtBQUFBLElBQ2hCLEtBQUs7QUFDSCxZQUFNO0FBQUEsUUFDSixJQUFJO0FBQUEsUUFDSixJQUFJO0FBQUEsUUFDSixJQUFJLFdBQVc7QUFBQSxRQUNmLElBQUk7QUFBQSxRQUNKLFFBQVEsS0FBSyxNQUFNO0FBQUEsTUFDckI7QUFDQSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN2RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN0RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFVBQUksSUFBSSxVQUFVLFFBQVE7QUFDeEIsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQsV0FBVyxJQUFJLFVBQVUsU0FBUztBQUNoQyxjQUFNLE1BQU8sSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNwRCxPQUFPO0FBQ0wsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQ7QUFDQSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSyxzQkFBc0I7QUFDekIsWUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxVQUFJLFNBQVMsWUFBWSxPQUFPO0FBQzlCLGVBQU8sRUFBRSxTQUFTLE9BQU8sYUFBYSxDQUFDLEdBQUcsa0JBQWtCLENBQUMsRUFBRTtBQUFBLE1BQ2pFO0FBQ0EsNkJBQXVCO0FBQ3ZCLFlBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsWUFBTSxjQUFjLFNBQ2pCLE9BQU8sQ0FBQyxNQUFNLEVBQUUsYUFBYSxNQUFNLEVBQ25DLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUM7QUFDcEMsWUFBTSxRQUFRLFFBQVEsS0FBSyxNQUFNO0FBQ2pDLGFBQU87QUFBQSxRQUNMLFNBQVM7QUFBQSxRQUNUO0FBQUEsUUFDQSxrQkFDRSxVQUFVLE9BQU8sQ0FBQyxJQUFJLE1BQU0sS0FBSyw0QkFBNEIsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLENBQUM7QUFBQSxNQUMzRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLEtBQUssc0JBQXNCO0FBQ3pCLFVBQUksSUFBSSxRQUFRLEdBQUc7QUFDakIsY0FBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFlBQUksV0FBVyxNQUFNO0FBQ25CLGlCQUFPLGlCQUFpQixJQUFJO0FBQzVCLGdCQUFNLHFCQUFxQixNQUFNO0FBQUEsUUFDbkM7QUFBQSxNQUNGO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVyxJQUFJLE1BQU07QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVztBQUNqQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxnQkFBZ0I7QUFDdEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sU0FBUyxNQUFNO0FBQ3JCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFlBQVksSUFBSSxRQUFRLE1BQU07QUFDcEMsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLGFBQWEsSUFBSSxHQUFHLENBQUM7QUFDNUMsWUFBTSxLQUFLLHdCQUF3QixFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDakQsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLGdCQUFnQixJQUFJLEdBQUcsQ0FBQztBQUMvQyxZQUFNLEtBQUssMkJBQTJCLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUNwRCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxlQUFlLEVBQUUsc0JBQXNCLElBQUksR0FBRyxDQUFDO0FBQ3JELFlBQU0sc0JBQXNCLEVBQUUsUUFBUSxVQUFVLEtBQUssS0FBSyxDQUFDO0FBQzNELGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssa0JBQWtCO0FBQ3JCLFlBQU0sSUFBSSxNQUFNLGVBQWUsRUFBRSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2xELFVBQUksQ0FBQyxJQUFJLElBQUk7QUFHWCw2QkFBcUI7QUFDckIsNEJBQW9CO0FBQ3BCLCtCQUF1QjtBQUN2QiwrQkFBdUI7QUFDdkIsY0FBTSxRQUFRLE9BQU8sTUFBTSxjQUFjO0FBQ3pDLGNBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQzdDLGNBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQUEsTUFDL0MsT0FBTztBQUVMLGNBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxZQUFJLFNBQVMsS0FBTSxvQkFBbUIsRUFBRSxxQkFBcUI7QUFBQSxNQUMvRDtBQUNBLFlBQU0sS0FBSyxtQ0FBbUMsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQzVELGFBQU8sV0FBVztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssNEJBQTRCO0FBQy9CLFlBQU0sVUFBVSxLQUFLO0FBQUEsUUFDbkI7QUFBQSxRQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLElBQUksT0FBTyxDQUFDO0FBQUEsTUFDdkQ7QUFDQSxZQUFNLGVBQWUsRUFBRSx1QkFBdUIsUUFBUSxDQUFDO0FBRXZELFlBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxVQUFJLFNBQVMsS0FBTSxvQkFBbUIsT0FBTztBQUM3QyxVQUFJLDBCQUEwQixLQUFNLHNCQUFxQixPQUFPO0FBQ2hFLFVBQUksNkJBQTZCLEtBQU0seUJBQXdCLE9BQU87QUFDdEUsVUFBSSw2QkFBNkIsS0FBTSx5QkFBd0IsT0FBTztBQUN0RSxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0saUJBQWlCO0FBQ3ZCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGtCQUFrQjtBQUN4QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLG9CQUFvQjtBQUMxQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxxQkFBcUI7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSyxtQkFBbUI7QUFDdEIsWUFBTSxPQUFPLE1BQU0sWUFBWTtBQUMvQixZQUFNLFVBQVUsSUFBSSxJQUFJLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQy9ELFlBQU0sVUFBVSxNQUFNLG9CQUFvQixPQUFPO0FBQ2pELFlBQU0sS0FBSywwQkFBMEIsT0FBTztBQUM1QyxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0sb0JBQW9CLElBQUk7QUFDOUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0saUJBQWlCLElBQUk7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sY0FBYztBQUNwQixhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUN0QyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSyxlQUFlO0FBQ2xCLFlBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsWUFBTSxNQUFNLFVBQVUsQ0FBQztBQUN2QixZQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQ2pDLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQjtBQUFBLElBQ0E7QUFDRSxhQUFPLEVBQUUsSUFBSSxPQUFPLE9BQU8sdUJBQXVCO0FBQUEsRUFDdEQ7QUFDRjtBQUlBLGVBQWUsaUJBQ2IsVUFDQSxLQUNBLFNBQ0EsVUFDQSxhQUNlO0FBQ2YsTUFBSSxrQkFBa0IsSUFBSSxRQUFRLEVBQUc7QUFDckMsTUFBSSxDQUFDLGdCQUFnQixJQUFJLFFBQVEsRUFBRztBQUVwQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksU0FBUyxZQUFZLE1BQU87QUFDaEMsTUFBSSxTQUFTLGdCQUFnQixPQUFPO0FBQ2xDLFVBQU0sd0JBQ0osS0FBSyxJQUFJLElBQUksd0JBQ1osTUFBTSxxQkFBcUIsTUFBTyxRQUNsQyxNQUFNLGtCQUFrQixNQUFPLFFBQy9CLE1BQU0scUJBQXFCLE1BQU87QUFDckMsUUFBSSxDQUFDLHNCQUF1QjtBQUFBLEVBQzlCO0FBRUEsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQWdCbkMsUUFBTSxVQUFVLElBQUksSUFBSSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUNuRSxRQUFNLE9BQU8sSUFBSTtBQUFBLElBQ2YsU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLGFBQWEsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUM7QUFBQSxFQUNqRjtBQUNBLFFBQU0sY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUUxQyxNQUFJO0FBQ0osTUFBSTtBQUNGLGlCQUFhLFVBQVUsVUFBVTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsZ0JBQWdCLG9CQUFJLElBQVk7QUFBQSxNQUNoQyxXQUFXO0FBQUEsSUFDYixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLFdBQVcsbUJBQW1CLFVBQVUsS0FBSyxVQUFVLEdBQUc7QUFDaEU7QUFBQSxFQUNGO0FBQ0EsUUFBTSxlQUFlO0FBQUEsSUFDbkIsV0FBVztBQUFBLElBQ1g7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsV0FBVztBQUFBLEVBQ2I7QUFRQSxRQUFNLGVBQWUsV0FBVyxPQUFPO0FBQ3ZDLGFBQVcsU0FBUyxjQUFjLFdBQVcsUUFBUSxTQUFTLElBQUk7QUFDbEUsUUFBTSxtQkFBbUIsZUFBZSxXQUFXLE9BQU87QUFDMUQsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLEtBQUssNEJBQTRCO0FBQUEsTUFDckM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDMUIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxpQ0FBK0IsYUFBYSxTQUFTLFdBQVcsUUFBUSxJQUFJO0FBTzVFLE1BQUksV0FBVyxhQUFhLFdBQVcsR0FBRztBQUN4QyxVQUFNLEtBQUssNENBQXVDO0FBQUEsTUFDaEQ7QUFBQSxNQUNBLFdBQVcsZUFBZSxRQUFRLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxNQUMvQyxZQUFZLG9CQUFvQixVQUFVLE9BQU87QUFBQSxNQUNqRCxpQkFBaUIsaUJBQWlCLFVBQVUsU0FBUyxDQUFDLE1BQU0sQ0FBQztBQUFBLE1BQzdELG1CQUFtQixpQkFBaUIsVUFBVSxTQUFTLENBQUMsUUFBUSxDQUFDO0FBQUEsTUFDakUsMEJBQTBCLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUM1RDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsTUFDRCwrQkFBK0IsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQ2pFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsTUFDRCxpQ0FBaUMsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQ25FO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSCxPQUFPO0FBQ0wsVUFBTSxLQUFLLHdCQUF3QjtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxVQUFVLFdBQVcsYUFBYTtBQUFBLE1BQ2xDLE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDMUIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxNQUFJLFdBQVcsbUJBQW1CLFNBQVMsR0FBRztBQUM1QyxVQUFNO0FBQUEsTUFDSixXQUFXO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsTUFBSSxXQUFXLE9BQU8sV0FBVyxHQUFHO0FBQ2xDLFVBQU0sZ0JBQWdCLE1BQU07QUFBQSxNQUMxQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFdBQVc7QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUNBLFFBQUksZ0JBQWdCLEVBQUcsT0FBTSxlQUFlO0FBQzVDO0FBQUEsRUFDRjtBQVdBLFFBQU0sY0FBYyxNQUFNLGtCQUFrQjtBQUM1QyxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxhQUFXLEtBQUssV0FBVyxRQUFRO0FBQ2pDLFFBQUksRUFBRSxjQUFjO0FBQ2xCLFlBQU0sZUFBZSxFQUFFLGdCQUFnQixFQUFFLFFBQVE7QUFBQSxJQUNuRCxPQUFPO0FBQ0wsWUFBTSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUTtBQUFBLElBQ25EO0FBR0EsVUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFFBQUksYUFBYSxVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ2pELGtCQUFZLFdBQVc7QUFDdkIsa0JBQVksYUFBYTtBQUN6QixZQUFNLGtCQUFrQixXQUFXO0FBQUEsSUFDckM7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLHFCQUFxQixjQUFjO0FBQUEsSUFDM0M7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLG1CQUFtQixFQUFFLFFBQVE7QUFDbkMsWUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFlBQU0scUJBQXFCLGNBQWM7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFLQSxhQUFXLFdBQVcsV0FBVyxhQUFhO0FBQzVDLFFBQUksTUFBTSxZQUFZLFFBQVEsUUFBUSxFQUFHO0FBQ3pDLFVBQU0sa0JBQWtCLFFBQVEsYUFBYSxRQUFRLFFBQVE7QUFBQSxFQUMvRDtBQUNBLE1BQUksV0FBVyxZQUFZLFNBQVMsR0FBRztBQUNyQyxVQUFNLEtBQUssMENBQTBDO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLFNBQVMsV0FBVyxZQUFZO0FBQUEsTUFDaEMsYUFBYSxNQUFNLHFCQUFxQjtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNIO0FBZ0JBLFFBQU0saUJBQWlCLFNBQVMsbUJBQW1CO0FBQ25ELFFBQU0sZUFBZSxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLGtCQUFrQixNQUFNLG1CQUFtQjtBQUNqRCxNQUFJLGlCQUFpQjtBQUNyQixNQUFJLHVCQUF1QjtBQUMzQixNQUFJLDBCQUEwQjtBQUM5QixNQUFJLGtCQUFrQjtBQUN0QixNQUFJLG1CQUFtQjtBQUN2QixRQUFNLGFBQXVDLENBQUM7QUFDOUMsUUFBTSxnQkFBZ0Isb0JBQUksSUFBZ0M7QUFDMUQsUUFBTSxhQUFhLG9CQUFJLElBQXFDO0FBQzVELGFBQVcsS0FBSyxXQUFXLFFBQVE7QUFDakMsVUFBTSxPQUFPLGFBQWEsRUFBRSxjQUFjLElBQUksRUFBRSxRQUFRO0FBQ3hELFVBQU0sZ0JBQWdCLENBQUMsUUFBUSx3QkFBd0IsR0FBRyxlQUFlO0FBQ3pFLFVBQU0scUJBQXFCLFFBQVEsSUFBSSxLQUFLO0FBQzVDLGtCQUFjLElBQUksRUFBRSxVQUFVLHFCQUFxQixhQUFhLEtBQUs7QUFDckUsUUFBSSxjQUFlLG9CQUFtQjtBQUN0QyxVQUFNLE1BQU07QUFBQSxNQUNWLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxJQUNKO0FBQ0EsVUFBTSxrQkFBa0IsU0FBUyxVQUFhLGtCQUFrQixLQUFLLEdBQUcsS0FBSyxDQUFDLEVBQUU7QUFDaEYsUUFBSSxzQkFBc0IsQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUI7QUFDN0QsVUFBSSxLQUFNLHlCQUF3QjtBQUFBLFVBQzdCLDRCQUEyQjtBQUNoQyxpQkFBVyxJQUFJLEVBQUUsVUFBVSxTQUFTO0FBQ3BDO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxLQUFLLFFBQVEsS0FBSztBQUM1Qix3QkFBa0I7QUFDbEIsaUJBQVcsSUFBSSxFQUFFLFVBQVUsV0FBVztBQUN0QztBQUFBLElBQ0Y7QUFDQSxRQUFJLGdCQUFpQixxQkFBb0I7QUFDekMsZUFBVyxJQUFJLEVBQUUsVUFBVSxVQUFVO0FBQ3JDLGVBQVcsS0FBSyxDQUFDO0FBQUEsRUFDbkI7QUFDQSxNQUFJLGlCQUFpQixHQUFHO0FBQ3RCLFVBQU0sS0FBSyxtQ0FBbUM7QUFBQSxNQUM1QztBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsV0FBVyxXQUFXO0FBQUEsSUFDeEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxNQUFJLHVCQUF1QiwwQkFBMEIsR0FBRztBQUN0RCxVQUFNLGFBQWEsdUJBQXVCO0FBQzFDLFVBQU0sS0FBSyxvRUFBb0U7QUFBQSxNQUM3RTtBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsYUFBYTtBQUFBLE1BQ2Isa0JBQWtCO0FBQUEsTUFDbEIsV0FBVyxXQUFXO0FBQUEsSUFDeEIsQ0FBQztBQUNELFVBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxRQUFJLFdBQVcsTUFBTTtBQUNuQixhQUFPLG1CQUFtQixPQUFPLG1CQUFtQixLQUFLO0FBQ3pELFlBQU0scUJBQXFCLE1BQU07QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFDQSxNQUFJLGtCQUFrQixLQUFLLGdCQUFnQjtBQUN6QyxVQUFNLEtBQUssMENBQTBDO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLEtBQUs7QUFBQSxNQUNMLFFBQVE7QUFBQSxNQUNSLHVCQUF1QixpQkFBaUIsZ0JBQWdCO0FBQUEsSUFDMUQsQ0FBQztBQUFBLEVBQ0g7QUFDQSxNQUFJLG1CQUFtQixHQUFHO0FBQ3hCLFVBQU0sS0FBSyx1Q0FBdUM7QUFBQSxNQUNoRDtBQUFBLE1BQ0EsVUFBVTtBQUFBLE1BQ1Y7QUFBQSxNQUNBLFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTTtBQUFBLElBQ0osV0FBVyxPQUFPO0FBQUEsTUFBSSxDQUFDLE1BQ3JCO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxjQUFjLElBQUksRUFBRSxRQUFRO0FBQUEsUUFDNUIsV0FBVyxJQUFJLEVBQUUsUUFBUTtBQUFBLE1BQzNCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFTQSxRQUFNLHNCQUFzQixXQUFXLFFBQVEsUUFBUTtBQUN2RCxRQUFNLDRCQUE0QixXQUFXLFFBQVEsTUFBTSxRQUFRO0FBQ25FLFFBQU0sdUJBQXVCLE1BQU07QUFBQSxJQUNqQztBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUNBLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDM0IsUUFBSSx1QkFBdUIsRUFBRyxPQUFNLGVBQWU7QUFDbkQ7QUFBQSxFQUNGO0FBR0EsUUFBTSxXQUFXLG9CQUFJLElBQThCO0FBQ25ELGFBQVcsS0FBSyxZQUFZO0FBQzFCLFVBQU0sTUFBTSxTQUFTLElBQUksRUFBRSxjQUFjLEtBQUssQ0FBQztBQUMvQyxRQUFJLEtBQUssQ0FBQztBQUNWLGFBQVMsSUFBSSxFQUFFLGdCQUFnQixHQUFHO0FBQUEsRUFDcEM7QUFFQSxhQUFXLENBQUMsUUFBUSxNQUFNLEtBQUssVUFBVTtBQUN2QyxVQUFNLE1BQU0sTUFBTSxnQkFBZ0IsUUFBUSxZQUFZLEtBQUssUUFBUTtBQUNuRSxRQUFJLFFBQVE7QUFDWixRQUFJLFdBQVc7QUFDZixRQUFJLGdCQUFnQjtBQUNwQixRQUFJLGtCQUFrQjtBQUN0QixlQUFXLEtBQUssUUFBUTtBQUN0QixZQUFNLFdBQVcsSUFBSSxhQUFhLEVBQUUsUUFBUTtBQUM1QyxVQUFJLFVBQVU7QUFHWixpQkFBUyxlQUFlO0FBQ3hCLGlCQUFTLGFBQWEsRUFBRTtBQUN4QixpQkFBUyxnQkFBZ0IsRUFBRTtBQUMzQixpQkFBUyxjQUFjLEVBQUU7QUFDekIsaUJBQVMsY0FBYyxFQUFFO0FBQ3pCLGlCQUFTLGFBQWEsRUFBRTtBQUN4QixpQkFBUyxpQkFBaUIsRUFBRTtBQUM1QixjQUFNLE9BQU8sU0FBUyxtQkFBbUIsU0FBUyxtQkFBbUIsU0FBUyxDQUFDO0FBQy9FLGNBQU0sT0FBTyxFQUFFLG1CQUFtQixDQUFDO0FBQ25DLFlBQUksU0FBUyxDQUFDLFFBQVEsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjO0FBQzVELG1CQUFTLG1CQUFtQixLQUFLLElBQUk7QUFBQSxRQUN2QztBQUNBLDJCQUFtQjtBQUFBLE1BQ3JCLE9BQU87QUFDTCxjQUFNLFVBQTBCLEVBQUUsR0FBRyxHQUFHLGdCQUFnQixJQUFJLE9BQU87QUFDbkUsWUFBSSxhQUFhLEVBQUUsUUFBUSxJQUFJO0FBQy9CLGlCQUFTO0FBQ1QsWUFBSSxjQUFjLElBQUksRUFBRSxRQUFRLE1BQU0sV0FBWSxrQkFBaUI7QUFBQSxZQUM5RCxhQUFZO0FBQUEsTUFDbkI7QUFDQSxVQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsR0FBRztBQUNoRCxZQUFJLG1CQUFtQixLQUFLLEVBQUUsUUFBUTtBQUFBLE1BQ3hDO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsbUJBQW1CLEdBQUcsQ0FBQztBQUN0RCxRQUFJLFFBQVEsS0FBSyxrQkFBa0IsR0FBRztBQUNwQyxZQUFNLEtBQUssbUJBQW1CO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0wsVUFBVTtBQUFBLFFBQ1Ysa0JBQWtCO0FBQUEsUUFDbEIsT0FBTyxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUU7QUFBQSxNQUN2QyxDQUFDO0FBR0QsWUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8saUJBQWlCO0FBQ3hCLGVBQU8sb0JBQW9CLE9BQU8sb0JBQW9CLEtBQUs7QUFDM0QsZUFBTyx5QkFBeUIsT0FBTyx5QkFBeUIsS0FBSztBQUNyRSxjQUFNLHFCQUFxQixNQUFNO0FBQUEsTUFDbkM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsVUFBVSx1QkFBdUI7QUFDakUsWUFBTSxZQUFZLFFBQVEsV0FBVztBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsd0JBQ2IsbUJBQ0EsU0FDQSxZQUNBLFdBQ0EsVUFDZTtBQUNmLFFBQU0sZUFBZSxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsTUFBSSxXQUFXO0FBQ2YsTUFBSSxVQUFVO0FBQ2QsTUFBSSxnQkFBZ0I7QUFFcEIsYUFBVyxLQUFLLG1CQUFtQjtBQUNqQyxVQUFNLFNBQVMsRUFBRTtBQUNqQixRQUFJLENBQUMsUUFBUTtBQUNYLHVCQUFpQjtBQUNqQixZQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsWUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxPQUFPLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxZQUFZLENBQUMsR0FBRztBQUMxRCxpQkFBVztBQUNYO0FBQUEsSUFDRjtBQUVBLFVBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxVQUFNLGVBQWUsUUFBUSxFQUFFLFFBQVE7QUFDdkMsVUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFFBQUksYUFBYSxVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ2pELGtCQUFZLFdBQVc7QUFDdkIsa0JBQVksYUFBYTtBQUN6QixZQUFNLGtCQUFrQixXQUFXO0FBQUEsSUFDckM7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLHFCQUFxQixjQUFjO0FBQUEsSUFDM0M7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLG1CQUFtQixFQUFFLFFBQVE7QUFDbkMsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBRUEsVUFBTSxNQUFNLGVBQWUsQ0FBQztBQUM1QixVQUFNLE9BQU8sYUFBYSxNQUFNLElBQUksRUFBRSxRQUFRO0FBQzlDLFFBQUksTUFBTSxRQUFRLEtBQUs7QUFDckIsaUJBQVc7QUFDWDtBQUFBLElBQ0Y7QUFFQSxVQUFNLE1BQU0sTUFBTSxnQkFBZ0IsUUFBUSxZQUFZLFdBQVcsUUFBUTtBQUN6RSxVQUFNLGtCQUFrQixJQUFJLHFCQUFxQixDQUFDO0FBQ2xELG9CQUFnQixFQUFFLFFBQVEsSUFBSTtBQUM5QixRQUFJLG9CQUFvQjtBQUN4QixRQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsR0FBRztBQUNoRCxVQUFJLG1CQUFtQixLQUFLLEVBQUUsUUFBUTtBQUFBLElBQ3hDO0FBQ0EsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTSxpQkFBaUIsUUFBUSxtQkFBbUIsR0FBRyxDQUFDO0FBQ3RELGdCQUFZO0FBQUEsRUFDZDtBQUVBLE1BQUksV0FBVyxLQUFLLGdCQUFnQixLQUFLLFVBQVUsR0FBRztBQUNwRCxVQUFNLEtBQUssK0JBQStCLEVBQUUsVUFBVSxVQUFVLFNBQVMsY0FBYyxDQUFDO0FBQUEsRUFDMUY7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxTQUFTLGVBQWUsR0FBNkI7QUFDbkQsU0FBTyxlQUFlLEVBQUUsc0JBQXNCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO0FBQzlFO0FBRUEsU0FBUyxrQkFBa0IsS0FBc0I7QUFDL0MsUUFBTSxRQUFRLElBQUksTUFBTSxHQUFHO0FBQzNCLFNBQU8sTUFBTSxNQUFNLFNBQVMsQ0FBQyxNQUFNO0FBQ3JDO0FBRUEsU0FBUyxtQkFBbUIsS0FBd0I7QUFDbEQsU0FDRSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsU0FDOUIsT0FBTyxLQUFLLElBQUkscUJBQXFCLENBQUMsQ0FBQyxFQUFFLFNBQ3pDLE9BQU8sS0FBSyxJQUFJLHdCQUF3QixDQUFDLENBQUMsRUFBRTtBQUVoRDtBQUVBLFNBQVMsZUFBZSxNQUEyQjtBQUNqRCxTQUFPLENBQUMsS0FBSyxpQkFBaUIsWUFBWSxHQUFHLEtBQUssa0JBQWtCLEtBQUssaUJBQWlCLEVBQUU7QUFBQSxJQUMxRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMscUJBQXFCLE1BQTZCO0FBQ3pELFFBQU0sUUFBUSxLQUFLLE1BQU0sZ0NBQWdDO0FBQ3pELFNBQU8sUUFBUSxDQUFDLEtBQUs7QUFDdkI7QUFFQSxTQUFTLGtCQUNQLFFBQ0EsVUFDQSxZQUNBLFVBQ0EsV0FDZTtBQUNmLFFBQU0sbUJBQW1CLElBQUksSUFBSSxTQUFTLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLFlBQVksR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQzFGLFFBQU0sT0FBTyxJQUFJLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUN2RCxRQUFNLE1BQU0sb0JBQUksSUFBeUI7QUFDekMsYUFBVyxLQUFLLFFBQVE7QUFDdEIsUUFBSSxFQUFFLGVBQWUsYUFBYSxDQUFDLEVBQUUsbUJBQW9CO0FBQ3pELFVBQU0sb0JBQW9CLGlCQUFpQixJQUFJLEVBQUUsZUFBZSxZQUFZLENBQUM7QUFDN0UsUUFBSSxDQUFDLGtCQUFtQjtBQUN4QixVQUFNLFdBQVcsS0FBSyxJQUFJLEVBQUUsa0JBQWtCO0FBQzlDLFVBQU0saUJBQ0osVUFBVSxrQkFBa0IscUJBQXFCLEVBQUUsaUJBQWlCLEVBQUUsSUFBSTtBQUM1RSxVQUFNLG1CQUFtQixpQkFDcEIsaUJBQWlCLElBQUksZUFBZSxZQUFZLENBQUMsS0FBSyxXQUN2RDtBQUNKLFVBQU0sT0FBb0I7QUFBQSxNQUN4QixrQkFBa0IsRUFBRTtBQUFBLE1BQ3BCLHNCQUFzQixFQUFFLGNBQWM7QUFBQSxNQUN0QyxvQkFBb0I7QUFBQSxNQUNwQixrQkFBa0IsRUFBRTtBQUFBLE1BQ3BCLGFBQWEsRUFBRTtBQUFBLE1BQ2YsbUJBQW1CLEVBQUU7QUFBQSxNQUNyQix3QkFBd0I7QUFBQSxNQUN4Qiw0QkFBNEIsVUFBVSxjQUFjO0FBQUEsTUFDcEQsMEJBQTBCO0FBQUEsTUFDMUIsYUFBYTtBQUFBLE1BQ2IsZ0JBQWdCO0FBQUEsTUFDaEI7QUFBQSxNQUNBLFlBQVk7QUFBQSxJQUNkO0FBQ0EsUUFBSSxJQUFJLGVBQWUsSUFBSSxHQUFHLElBQUk7QUFBQSxFQUNwQztBQUNBLFNBQU8sQ0FBQyxHQUFHLElBQUksT0FBTyxDQUFDO0FBQ3pCO0FBRUEsZUFBZSxtQkFDYixPQUNBLFlBQ0EsV0FDQSxVQUNpQjtBQUNqQixNQUFJLE1BQU0sV0FBVyxFQUFHLFFBQU87QUFDL0IsUUFBTSxXQUFXLG9CQUFJLElBQTJCO0FBQ2hELGFBQVcsUUFBUSxPQUFPO0FBQ3hCLFVBQU0sTUFBTSxTQUFTLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxDQUFDO0FBQ3BELFFBQUksS0FBSyxJQUFJO0FBQ2IsYUFBUyxJQUFJLEtBQUssa0JBQWtCLEdBQUc7QUFBQSxFQUN6QztBQUNBLE1BQUksUUFBUTtBQUNaLGFBQVcsQ0FBQyxRQUFRLFdBQVcsS0FBSyxVQUFVO0FBQzVDLFVBQU0sTUFBTSxNQUFNLGdCQUFnQixRQUFRLFlBQVksV0FBVyxRQUFRO0FBQ3pFLFVBQU0sVUFBVSxJQUFJLHdCQUF3QixDQUFDO0FBQzdDLFFBQUksaUJBQWlCO0FBQ3JCLGVBQVcsUUFBUSxhQUFhO0FBQzlCLFlBQU0sVUFBdUIsRUFBRSxHQUFHLE1BQU0sZ0JBQWdCLElBQUksT0FBTztBQUNuRSxZQUFNLE1BQU0sZUFBZSxPQUFPO0FBQ2xDLFVBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRyxtQkFBa0I7QUFDckMsY0FBUSxHQUFHLElBQUk7QUFDZixVQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxRQUFRLGdCQUFnQixHQUFHO0FBQzlELFlBQUksbUJBQW1CLEtBQUssUUFBUSxnQkFBZ0I7QUFBQSxNQUN0RDtBQUNBLFVBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLFFBQVEsaUJBQWlCLEdBQUc7QUFDL0QsWUFBSSxtQkFBbUIsS0FBSyxRQUFRLGlCQUFpQjtBQUFBLE1BQ3ZEO0FBQUEsSUFDRjtBQUNBLFFBQUksbUJBQW1CLEVBQUc7QUFDMUIsUUFBSSx1QkFBdUI7QUFDM0IsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTSxpQkFBaUIsUUFBUSxtQkFBbUIsR0FBRyxDQUFDO0FBQ3RELGFBQVM7QUFDVCxVQUFNLEtBQUssMEJBQTBCO0FBQUEsTUFDbkM7QUFBQSxNQUNBO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUCxPQUFPLE9BQU8sS0FBSyxPQUFPLEVBQUU7QUFBQSxJQUM5QixDQUFDO0FBQUEsRUFDSDtBQUNBLFNBQU87QUFDVDtBQXNCQSxlQUFlLHNCQUNiLFFBQ0EsVUFDZTtBQUNmLE1BQUksT0FBTyxXQUFXLEVBQUc7QUFHekIsUUFBTSxlQUFlLG9CQUFJLElBQVk7QUFDckMsYUFBVyxLQUFLLE9BQVEsY0FBYSxJQUFJLEVBQUUsUUFBUTtBQUVuRCxNQUFJLFdBQVc7QUFDZixhQUFXLEtBQUssUUFBUTtBQUN0QixVQUFNLFVBQXNELENBQUM7QUFDN0QsUUFBSSxFQUFFLG1CQUFtQjtBQUN2QixjQUFRLEtBQUssRUFBRSxJQUFJLEVBQUUsbUJBQW1CLE1BQU0sRUFBRSxpQkFBaUIsQ0FBQztBQUFBLElBQ3BFO0FBQ0EsUUFBSSxFQUFFLGdCQUFpQixTQUFRLEtBQUssRUFBRSxJQUFJLEVBQUUsaUJBQWlCLE1BQU0sS0FBSyxDQUFDO0FBQ3pFLFFBQUksRUFBRSxtQkFBb0IsU0FBUSxLQUFLLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixNQUFNLEtBQUssQ0FBQztBQUMvRSxlQUFXLEtBQUssU0FBUztBQUN2QixVQUFJLGFBQWEsSUFBSSxFQUFFLEVBQUUsRUFBRztBQUM1QixVQUFJLE1BQU0sWUFBWSxFQUFFLEVBQUUsRUFBRztBQUM3QixZQUFNLGtCQUFrQixFQUFFLE1BQU0sRUFBRSxFQUFFO0FBQ3BDLGtCQUFZO0FBQUEsSUFDZDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFdBQVcsR0FBRztBQUNoQixVQUFNLEtBQUssc0RBQXNEO0FBQUEsTUFDL0Q7QUFBQSxNQUNBO0FBQUEsTUFDQSxhQUFhLE1BQU0scUJBQXFCO0FBQUEsSUFDMUMsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQUVBLGVBQWUsNEJBQ2IsUUFDQSxhQUNBLFVBQ2U7QUFDZixNQUFJLE9BQU8sV0FBVyxLQUFLLFlBQVksU0FBUyxFQUFHO0FBQ25ELE1BQUksU0FBUyxTQUFTLGFBQWEsS0FBSyxTQUFTLFNBQVMscUJBQXFCLEVBQUc7QUFFbEYsUUFBTSxhQUFhLG9CQUFJLElBQW9CO0FBQzNDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFVBQU0sU0FBUyxFQUFFLGVBQWUsWUFBWTtBQUM1QyxRQUFJLENBQUMsWUFBWSxJQUFJLE1BQU0sRUFBRztBQUU5QixVQUFNLFNBQVMsRUFBRSxtQkFBbUIsRUFBRTtBQUN0QyxVQUFNLFNBQVMsV0FBVyxFQUFFLFlBQVksRUFBRSxzQkFBc0I7QUFDaEUsVUFBTSxjQUFjLEVBQUUsc0JBQXNCO0FBQzVDLFFBQUksVUFBVSxFQUFFLGNBQWMsR0FBRztBQUMvQixpQkFBVyxJQUFJLFFBQVEsRUFBRSxjQUFjO0FBQUEsSUFDekMsV0FBVyxlQUFlLFFBQVE7QUFDaEMsaUJBQVcsSUFBSSxRQUFRLEVBQUUsY0FBYztBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUVBLE1BQUksV0FBVztBQUNmLGFBQVcsQ0FBQyxTQUFTLE1BQU0sS0FBSyxZQUFZO0FBQzFDLFVBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxVQUFNLGtCQUFrQixRQUFRLE9BQU87QUFDdkMsVUFBTSxRQUFRLE1BQU0scUJBQXFCO0FBQ3pDLFFBQUksUUFBUSxPQUFRLGFBQVk7QUFBQSxFQUNsQztBQUNBLE1BQUksV0FBVyxHQUFHO0FBQ2hCLFVBQU0sS0FBSyx3Q0FBd0M7QUFBQSxNQUNqRDtBQUFBLE1BQ0E7QUFBQSxNQUNBLGFBQWEsTUFBTSxxQkFBcUI7QUFBQSxJQUMxQyxDQUFDO0FBQUEsRUFDSDtBQUNGO0FBRUEsZUFBZSxnQkFDYixRQUNBLElBQ0EsV0FDQSxVQUNvQjtBQUNwQixRQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFDckMsTUFBSSxJQUFLLFFBQU87QUFDaEIsUUFBTSxNQUFpQjtBQUFBLElBQ3JCLFFBQVEsU0FBUztBQUFBLElBQ2pCLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLGlCQUFpQjtBQUFBLElBQ2pCLGNBQWMsQ0FBQztBQUFBLElBQ2YsbUJBQW1CLENBQUM7QUFBQSxJQUNwQixvQkFBb0IsQ0FBQztBQUFBLElBQ3JCLGdCQUFnQixDQUFDLFFBQVE7QUFBQSxJQUN6QixZQUFZO0FBQUEsRUFDZDtBQUNBLFFBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsUUFBTSxLQUFLLGVBQWUsRUFBRSxRQUFRLEtBQUssV0FBVyxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQ2pFLFNBQU87QUFDVDtBQUlBLElBQUksYUFBNEIsUUFBUSxRQUFRO0FBZ0JoRCxlQUFlLG1CQUFrQztBQUMvQyxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsUUFBTSxVQUFvQixDQUFDO0FBQzNCLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFVBQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxlQUFlO0FBQzNDLFFBQUksT0FBTyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsZUFBZTtBQUN4RCxjQUFRLEtBQUssTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sYUFBYSxTQUFTLE1BQU07QUFDcEM7QUFFQSxlQUFlLDhCQUE2QztBQU8xRCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLEtBQU07QUFDeEQsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLFFBQU0sVUFBb0IsQ0FBQztBQUMzQixhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUMvQyxVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksZUFBZTtBQUMzQyxRQUFJLE9BQU8sU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLGVBQWU7QUFDeEQsY0FBUSxLQUFLLE1BQU07QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsU0FBUyxNQUFNO0FBQ3BDO0FBRUEsZUFBZSxTQUFTLFFBQStCO0FBQ3JELFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxhQUFhLE9BQU8sS0FBSyxHQUFHLEdBQUcsTUFBTTtBQUM3QztBQUVBLGVBQWUsWUFBWSxRQUFnQixRQUErQjtBQUN4RSxRQUFNLGFBQWEsQ0FBQyxNQUFNLEdBQUcsTUFBTTtBQUNyQztBQUVBLGVBQWUsYUFBYSxTQUFtQixRQUErQjtBQUM1RSxRQUFNLFNBQVMsQ0FBQyxHQUFHLElBQUksSUFBSSxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQztBQUMvRCxNQUFJLE9BQU8sV0FBVyxFQUFHO0FBQ3pCLFFBQU0sTUFBTSxXQUFXLEtBQUssTUFBTSxtQkFBbUIsUUFBUSxNQUFNLENBQUM7QUFDcEUsZUFBYSxJQUFJLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUMvQixTQUFPO0FBQ1Q7QUFFQSxlQUFlLG1CQUFtQixTQUFtQixRQUErQjtBQUNsRixRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sUUFBcUIsQ0FBQztBQUM1QixhQUFXLFVBQVUsU0FBUztBQUM1QixVQUFNLE1BQU0sSUFBSSxNQUFNO0FBQ3RCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsVUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJLFlBQVk7QUFDN0MsVUFBTSxvQkFBb0IsT0FBTyxPQUFPLElBQUkscUJBQXFCLENBQUMsQ0FBQztBQUNuRSxVQUFNLGVBQWUsT0FBTyxPQUFPLElBQUksd0JBQXdCLENBQUMsQ0FBQztBQUNqRSxRQUFJLE9BQU8sV0FBVyxLQUFLLGtCQUFrQixXQUFXLEtBQUssYUFBYSxXQUFXLEdBQUc7QUFDdEYsWUFBTSxlQUFlLE1BQU07QUFDM0IsWUFBTSxpQkFBaUIsUUFBUSxDQUFDO0FBQ2hDO0FBQUEsSUFDRjtBQUNBLFVBQU0sS0FBSyxlQUFlLFFBQVEsS0FBSyxRQUFRLG1CQUFtQixZQUFZLENBQUM7QUFBQSxFQUNqRjtBQUNBLE1BQUksTUFBTSxXQUFXLEVBQUc7QUFFeEIsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sS0FBSywrQ0FBK0M7QUFBQSxNQUN4RCxPQUFPLE1BQU07QUFBQSxNQUNiLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLElBQ3ZELENBQUM7QUFDRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsUUFBTSxRQUFRLE1BQU0sUUFBUSxDQUFDLFNBQVM7QUFBQSxJQUNwQztBQUFBLE1BQ0UsTUFBTSxLQUFLO0FBQUEsTUFDWCxlQUFlQyxVQUFTLEtBQUssVUFBVSxLQUFLLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLElBQ3RFO0FBQUEsSUFDQTtBQUFBLE1BQ0UsTUFBTSxLQUFLO0FBQUEsTUFDWCxlQUFlQSxVQUFTLEtBQUssVUFBVSxLQUFLLE1BQU0sTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLElBQ25FO0FBQUEsRUFDRixDQUFDO0FBQ0QsUUFBTSxZQUFZLHdCQUF3QixLQUFLO0FBRS9DLE1BQUk7QUFDRixVQUFNLFNBQVMsTUFBTSxPQUFPLFlBQVk7QUFBQSxNQUN0QztBQUFBLE1BQ0EsU0FBUztBQUFBLElBQ1gsQ0FBQztBQUNELFVBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxlQUFXLFFBQVEsT0FBTztBQUN4QixZQUFNLGlCQUFpQixNQUFNLCtCQUErQixJQUFJO0FBS2hFLFlBQU0sUUFBUSxNQUFNLFlBQVksR0FBRyxLQUFLLE1BQU07QUFDOUMsWUFBTSxTQUFRLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDbEQsWUFBTSxlQUFlLFFBQVEsS0FBSyxjQUFjLFFBQVEsS0FBSyxhQUFhO0FBQzFFLFlBQU0sWUFBWSxLQUFLLFFBQVE7QUFBQSxRQUM3QixZQUFZLGVBQWUsS0FBSyxPQUFPLFNBQVMsS0FBSyxrQkFBa0I7QUFBQSxRQUN2RSxXQUFXO0FBQUEsUUFDWCxlQUFlLEtBQUssSUFBSTtBQUFBLFFBQ3hCLGlCQUNHLE1BQU0sa0JBQWtCLEtBQUssS0FBSyxPQUFPLFNBQVMsS0FBSyxrQkFBa0I7QUFBQSxRQUM1RSxlQUFlO0FBQUEsTUFDakIsQ0FBQztBQUdELFlBQU0sUUFBUSxJQUFJLEtBQUssTUFBTSxLQUFLLENBQUM7QUFDbkMsWUFBTSxVQUFTLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ3RDLGlCQUFXLEtBQUssS0FBSyxRQUFRO0FBQzNCLGNBQU0sRUFBRSxRQUFRLElBQUk7QUFBQSxVQUNsQixJQUFJO0FBQUEsVUFDSixLQUFLO0FBQUEsWUFDSCxFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsVUFDSjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsaUJBQVcsS0FBSyxLQUFLLG1CQUFtQjtBQUN0QyxjQUFNLEVBQUUsUUFBUSxJQUFJO0FBQUEsVUFDbEIsSUFBSTtBQUFBLFVBQ0osS0FBSyxlQUFlLENBQUM7QUFBQSxRQUN2QjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLEtBQUssTUFBTSxJQUFJO0FBQ25CLFlBQU0sS0FBSywyQkFBMkI7QUFBQSxRQUNwQyxRQUFRLEtBQUs7QUFBQSxRQUNiO0FBQUEsUUFDQSxRQUFRLEtBQUssT0FBTztBQUFBLFFBQ3BCLGFBQWEsS0FBSyxrQkFBa0I7QUFBQSxRQUNwQyxlQUFlLEtBQUssYUFBYTtBQUFBLFFBQ2pDLEtBQUssS0FBSztBQUFBLFFBQ1YsTUFBTSxLQUFLO0FBQUEsUUFDWCxjQUFjLE9BQU87QUFBQSxNQUN2QixDQUFDO0FBQUEsSUFDSDtBQUNBLFVBQU0sa0JBQWtCLEdBQUc7QUFDM0IsVUFBTSxLQUFLLGlDQUFpQztBQUFBLE1BQzFDO0FBQUEsTUFDQSxNQUFNLE1BQU07QUFBQSxNQUNaLE9BQU8sTUFBTTtBQUFBLE1BQ2IsUUFBUSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQUEsTUFDbkUsYUFBYSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLGtCQUFrQixRQUFRLENBQUM7QUFBQSxNQUNuRixlQUFlLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssYUFBYSxRQUFRLENBQUM7QUFBQSxNQUNoRixRQUFRLE9BQU87QUFBQSxJQUNqQixDQUFDO0FBQ0Q7QUFDRSxZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU8sS0FBSztBQUFBLFFBQ1osWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWUsS0FBSztBQUFBLFFBQ3BCLHdCQUF3QixLQUFLO0FBQUEsUUFDN0Isa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFFBQUksZUFBZSxhQUFhO0FBQzlCLFlBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsWUFBTSxTQUNKLElBQUksYUFBYSxTQUNiLGVBQ0EsSUFBSSxhQUFhLGVBQ2YsaUJBQ0EsSUFBSSxhQUFhLFlBQ2Ysa0JBQ0EsS0FBSztBQUNmLFlBQU0sY0FBYztBQUFBLFFBQ2xCO0FBQUEsUUFDQSxPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPLElBQUk7QUFBQSxRQUNYLGVBQWUsS0FBSztBQUFBLFFBQ3BCLHdCQUF3QixLQUFLO0FBQUEsUUFDN0Isa0JBQ0UsSUFBSSxhQUFhLGVBQWUsSUFBSSxtQkFBbUIsS0FBSztBQUFBLE1BQ2hFLENBQUM7QUFDRCxZQUFNLE1BQU8sd0JBQXdCO0FBQUEsUUFDbkM7QUFBQSxRQUNBLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3JELE1BQU0sTUFBTTtBQUFBLFFBQ1osT0FBTyxNQUFNO0FBQUEsUUFDYixVQUFVLElBQUk7QUFBQSxRQUNkLFFBQVEsSUFBSTtBQUFBLFFBQ1osU0FBUyxJQUFJO0FBQUEsUUFDYixrQkFBa0IsSUFBSTtBQUFBLE1BQ3hCLENBQUM7QUFBQSxJQUNILE9BQU87QUFDTCxZQUFNLE1BQU8sd0JBQXdCO0FBQUEsUUFDbkM7QUFBQSxRQUNBLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3JELE1BQU0sTUFBTTtBQUFBLFFBQ1osT0FBTyxNQUFNO0FBQUEsUUFDYixHQUFHLGNBQWMsR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFFRixVQUFFO0FBQ0EsVUFBTSxlQUFlO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsZUFDUCxRQUNBLEtBQ0EsUUFDQSxtQkFDQSxjQUNXO0FBQ1gsUUFBTSxLQUFLLFdBQVcsSUFBSSxVQUFVO0FBQ3BDLFFBQU0sTUFBTSxJQUFJLFdBQVcsTUFBTSxHQUFHLEVBQUU7QUFDdEMsUUFBTSxXQUFXLFdBQVcsSUFBSSxNQUFNO0FBQ3RDLFFBQU0sVUFBVSxPQUFPLE1BQU0sSUFBSSxFQUFFLElBQUksUUFBUTtBQUMvQyxRQUFNLFdBQVcsUUFBUSxNQUFNLElBQUksRUFBRSxJQUFJLFFBQVE7QUFDakQsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsU0FBUztBQUFBLE1BQ1AsZ0JBQWdCO0FBQUEsTUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxNQUNwQixnQkFBZ0I7QUFBQSxNQUNoQixhQUFhLElBQUk7QUFBQSxNQUNqQixVQUFVLElBQUksZUFBZSxLQUFLLEdBQUc7QUFBQSxNQUNyQyxZQUFZLFVBQVU7QUFBQSxNQUN0QixZQUFZLElBQUk7QUFBQSxNQUNoQjtBQUFBLE1BQ0Esb0JBQW9CO0FBQUEsTUFDcEIsZUFBZTtBQUFBLElBQ2pCO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixnQkFBZ0I7QUFBQSxNQUNoQixnQkFBZ0IsSUFBSTtBQUFBLE1BQ3BCLGdCQUFnQjtBQUFBLE1BQ2hCLGFBQWEsSUFBSTtBQUFBLE1BQ2pCLG9CQUFvQixJQUFJO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHdCQUF3QixPQUE0QjtBQUMzRCxNQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLFVBQU0sT0FBTyxNQUFNLENBQUM7QUFDcEIsVUFBTUMsb0JBQW1CLEtBQUssa0JBQWtCO0FBQ2hELFVBQU1DLGFBQVksS0FBSyxhQUFhO0FBQ3BDLFVBQU1DLFdBQ0hGLG9CQUFtQixJQUFJLEtBQUtBLGlCQUFnQixpQkFBaUIsT0FDN0RDLGFBQVksSUFBSSxLQUFLQSxVQUFTLGdCQUFnQkEsZUFBYyxJQUFJLEtBQUssR0FBRyxLQUFLO0FBQ2hGLFdBQU8sWUFBWSxLQUFLLE1BQU0sSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxXQUFXLElBQUksS0FBSyxHQUFHLEdBQUdDLE9BQU0sU0FBUyxLQUFLLFFBQVE7QUFBQSxFQUM3STtBQUNBLFFBQU0sT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFLEtBQUs7QUFDOUQsUUFBTSxXQUFXLEtBQUssV0FBVyxJQUFJLEtBQUssQ0FBQyxJQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsS0FBSyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUM7QUFDcEYsUUFBTSxhQUFhLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssT0FBTyxRQUFRLENBQUM7QUFDOUUsUUFBTSxtQkFBbUIsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxrQkFBa0IsUUFBUSxDQUFDO0FBQy9GLFFBQU0sWUFBWSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLGFBQWEsUUFBUSxDQUFDO0FBQ25GLFFBQU0sVUFDSCxtQkFBbUIsSUFBSSxLQUFLLGdCQUFnQixpQkFBaUIsT0FDN0QsWUFBWSxJQUFJLEtBQUssU0FBUyxnQkFBZ0IsY0FBYyxJQUFJLEtBQUssR0FBRyxLQUFLO0FBQ2hGLFNBQU8sa0JBQWtCLE1BQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxlQUFlLElBQUksS0FBSyxHQUFHLEdBQUcsTUFBTSxLQUFLLFFBQVE7QUFDckg7QUFFQSxlQUFlLCtCQUErQixNQUFrQztBQUM5RSxRQUFNLFVBQVUsTUFBTSxhQUFhLEtBQUssTUFBTTtBQUM5QyxNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLE1BQUksUUFBUSxXQUFXLEtBQUssSUFBSSxPQUFRLFFBQU8sbUJBQW1CLE9BQU87QUFFekUsUUFBTSxZQUFZLElBQUk7QUFBQSxJQUNwQixLQUFLLE9BQU8sSUFBSSxDQUFDLE1BQU07QUFBQSxNQUNyQixFQUFFO0FBQUEsTUFDRixjQUFjLEVBQUUsWUFBWSxFQUFFLGVBQWUsRUFBRSxhQUFhLEVBQUUsYUFBYSxFQUFFLFlBQVk7QUFBQSxJQUMzRixDQUFDO0FBQUEsRUFDSDtBQUNBLGFBQVcsS0FBSyxLQUFLLG1CQUFtQjtBQUN0QyxjQUFVLElBQUksRUFBRSxVQUFVLGVBQWUsQ0FBQyxDQUFDO0FBQUEsRUFDN0M7QUFDQSxRQUFNLGtCQUFrRCxDQUFDO0FBQ3pELGFBQVcsQ0FBQyxTQUFTLEtBQUssS0FBSyxPQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDbkUsVUFBTSxlQUFlLFVBQVUsSUFBSSxPQUFPO0FBQzFDLFVBQU0sYUFBYTtBQUFBLE1BQ2pCLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxJQUNSO0FBQ0EsUUFBSSxDQUFDLGdCQUFnQixpQkFBaUIsWUFBWTtBQUNoRCxzQkFBZ0IsT0FBTyxJQUFJLEVBQUUsR0FBRyxNQUFNO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBQ0EsUUFBTSx1QkFBeUQsQ0FBQztBQUNoRSxhQUFXLENBQUMsU0FBUyxXQUFXLEtBQUssT0FBTyxRQUFRLFFBQVEscUJBQXFCLENBQUMsQ0FBQyxHQUFHO0FBQ3BGLFVBQU0sZUFBZSxVQUFVLElBQUksT0FBTztBQUMxQyxVQUFNLGFBQWEsZUFBZSxXQUFXO0FBQzdDLFFBQUksQ0FBQyxnQkFBZ0IsaUJBQWlCLFlBQVk7QUFDaEQsMkJBQXFCLE9BQU8sSUFBSSxFQUFFLEdBQUcsWUFBWTtBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUNBLFFBQU0sd0JBQXFELENBQUM7QUFDNUQsYUFBVyxDQUFDLEtBQUssSUFBSSxLQUFLLE9BQU8sUUFBUSxRQUFRLHdCQUF3QixDQUFDLENBQUMsR0FBRztBQUM1RSxRQUFJLENBQUMsS0FBSyxhQUFhLEtBQUssQ0FBQyxrQkFBa0IsZUFBZSxhQUFhLE1BQU0sR0FBRyxHQUFHO0FBQ3JGLDRCQUFzQixHQUFHLElBQUksRUFBRSxHQUFHLEtBQUs7QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxRQUFNLGVBQWUsb0JBQUksSUFBSTtBQUFBLElBQzNCLEdBQUcsT0FBTyxLQUFLLGVBQWU7QUFBQSxJQUM5QixHQUFHLE9BQU8sS0FBSyxvQkFBb0I7QUFBQSxJQUNuQyxHQUFHLE9BQU8sT0FBTyxxQkFBcUIsRUFBRSxRQUFRLENBQUMsU0FBUztBQUFBLE1BQ3hELEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxJQUNQLENBQUM7QUFBQSxFQUNILENBQUM7QUFDRCxRQUFNLGlCQUNKLE9BQU8sS0FBSyxlQUFlLEVBQUUsU0FDN0IsT0FBTyxLQUFLLG9CQUFvQixFQUFFLFNBQ2xDLE9BQU8sS0FBSyxxQkFBcUIsRUFBRTtBQUNyQyxNQUFJLG1CQUFtQixHQUFHO0FBQ3hCLFVBQU0sZUFBZSxLQUFLLE1BQU07QUFDaEMsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNLFlBQVksU0FBUztBQUMzQixhQUFXLFNBQVMsT0FBTyxPQUFPLGVBQWUsR0FBRztBQUNsRCxVQUFNLGlCQUFpQjtBQUFBLEVBQ3pCO0FBQ0EsYUFBVyxRQUFRLE9BQU8sT0FBTyxxQkFBcUIsR0FBRztBQUN2RCxTQUFLLGlCQUFpQjtBQUFBLEVBQ3hCO0FBQ0EsUUFBTSxhQUFhLEtBQUssUUFBUTtBQUFBLElBQzlCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVksUUFBUTtBQUFBLElBQ3BCLGNBQWM7QUFBQSxJQUNkLG1CQUFtQjtBQUFBLElBQ25CLHNCQUFzQjtBQUFBLElBQ3RCLG9CQUFvQixRQUFRLG1CQUFtQixPQUFPLENBQUMsT0FBTyxhQUFhLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDcEYsQ0FBQztBQUNELFFBQU0sS0FBSyxtQ0FBbUM7QUFBQSxJQUM1QyxRQUFRLEtBQUs7QUFBQSxJQUNiLGVBQWUsS0FBSztBQUFBLElBQ3BCLFVBQVUsV0FBVyxTQUFTO0FBQUEsSUFDOUIsV0FBVztBQUFBLEVBQ2IsQ0FBQztBQUNELFNBQU87QUFDVDtBQUlBLGVBQWUsV0FBVyxRQUErQjtBQUN2RCwyQkFBeUI7QUFNekIsUUFBTSxZQUFZLGlCQUFpQixNQUFNO0FBQ3pDLFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxRQUFRLEtBQUssZUFBZSxDQUFDO0FBQ25FLE1BQUksQ0FBRSxNQUFNLGFBQWEsTUFBTSxHQUFJO0FBQ2pDLFVBQU0sT0FBTSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNuQyxVQUFNLGFBQWEsUUFBUTtBQUFBLE1BQ3pCLFFBQVEsU0FBUztBQUFBLE1BQ2pCLGdCQUFnQjtBQUFBLE1BQ2hCLFlBQVk7QUFBQSxNQUNaLGlCQUFpQjtBQUFBLE1BQ2pCLGNBQWMsQ0FBQztBQUFBLE1BQ2YsbUJBQW1CLENBQUM7QUFBQSxNQUNwQixvQkFBb0IsQ0FBQztBQUFBLE1BQ3JCLGdCQUFnQixDQUFDO0FBQUEsTUFDakIsWUFBWTtBQUFBLElBQ2QsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxXQUFXLFFBQVEsS0FBSyxDQUFDO0FBQzVEO0FBRUEsZUFBZSxhQUE0QjtBQUN6QyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxPQUFPLFNBQVMsT0FBTyxDQUFDO0FBQzlELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sV0FBVyxFQUFFLE1BQU07QUFBQSxFQUMzQjtBQUNGO0FBV0EsZUFBZSxrQkFBaUM7QUFDOUMsMkJBQXlCO0FBQ3pCLE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsUUFBUSxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQUEsRUFDdkUsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlEQUFpRCxjQUFjLEdBQUcsQ0FBQztBQUM5RTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLE1BQUksQ0FBQyxPQUFPLE9BQU8sSUFBSSxPQUFPLFlBQVksQ0FBQyxJQUFJLEtBQUs7QUFDbEQsVUFBTSxLQUFLLGtDQUFrQztBQUM3QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsZ0NBQWdDLEtBQUssSUFBSSxHQUFHLEdBQUc7QUFDbEQsVUFBTSxLQUFLLCtEQUErRDtBQUFBLE1BQ3hFLEtBQUssV0FBVyxJQUFJLEdBQUc7QUFBQSxJQUN6QixDQUFDO0FBQ0Q7QUFBQSxFQUNGO0FBQ0EsUUFBTSxLQUFLLCtCQUErQixFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBR3RFLE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTyxDQUFDLGNBQWM7QUFBQSxNQUN0QixPQUFPO0FBQUEsSUFDVCxDQUFDO0FBQ0QsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU8sQ0FBQyxZQUFZO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLHVDQUF1QyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ3RFO0FBR0EsTUFBSTtBQUNGLFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPO0FBQUEsTUFDUCxNQUFNLE1BQU07QUFDVixjQUFNLElBQUksT0FBTztBQUNqQixlQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQztBQUNwRCxtQkFBVyxNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDLEdBQUcsR0FBRztBQUMzRSxtQkFBVyxNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDLEdBQUcsSUFBSTtBQUFBLE1BQzlFO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssMENBQTBDLGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDekU7QUFDRjtBQWFBLElBQU0sa0JBQWtCO0FBRXhCLGVBQWUsa0JBQTBDO0FBQ3ZELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksZUFBZTtBQUM5RCxRQUFNLEtBQUssT0FBTyxlQUFlO0FBQ2pDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsZ0JBQWdCLElBQWtDO0FBQy9ELE1BQUksT0FBTyxNQUFNO0FBQ2YsVUFBTSxRQUFRLFFBQVEsTUFBTSxPQUFPLGVBQWU7QUFBQSxFQUNwRCxPQUFPO0FBQ0wsVUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxlQUFlLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDM0Q7QUFDRjtBQUVBLGVBQWUsbUJBQWtDO0FBQy9DLDJCQUF5QjtBQUN6QixRQUFNLFFBQVEsTUFBTSxrQkFBa0I7QUFDdEMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUsseUJBQXlCO0FBQ3BDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxrQkFBa0I7QUFBQSxJQUN0QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELHVCQUFxQixPQUFPO0FBQzVCLE9BQUssWUFBWTtBQUNqQixRQUFNLEtBQUssd0JBQXdCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQzNFLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksd0JBQStEO0FBRW5FLFNBQVMscUJBQXFCLFNBQXVCO0FBQ25ELE1BQUksMEJBQTBCLEtBQU0sZUFBYyxxQkFBcUI7QUFDdkUsMEJBQXdCLFlBQVksTUFBTTtBQUN4QyxTQUFLLFlBQVksRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNoQyxXQUFLLEtBQUssdUJBQXVCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDckQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHNCQUE0QjtBQUNuQyxNQUFJLDBCQUEwQixNQUFNO0FBQ2xDLGtCQUFjLHFCQUFxQjtBQUNuQyw0QkFBd0I7QUFBQSxFQUMxQjtBQUNGO0FBRUEsZUFBZSxvQkFBbUM7QUFDaEQsc0JBQW9CO0FBQ3BCLFFBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxRQUFNLFFBQVEsTUFBTSxnQkFBZ0I7QUFDcEMsUUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixRQUFNLE9BQU8sTUFBTSxrQkFBa0I7QUFDckMsUUFBTSxrQkFBa0IsSUFBSTtBQUM1QixRQUFNLEtBQUssMEJBQTBCO0FBQUEsSUFDbkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxjQUE2QjtBQUMxQyxNQUFJLE9BQU8sTUFBTSxrQkFBa0I7QUFDbkMsTUFBSSxTQUFTLE1BQU07QUFFakIsd0JBQW9CO0FBQ3BCO0FBQUEsRUFDRjtBQUlBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUVBLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFFRCxVQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsZUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsVUFBSSxJQUFJLFNBQVMsS0FBSyxTQUFTLE9BQU8sR0FBRztBQUN2QyxjQUFNLGVBQWUsUUFBUSxLQUFLLFNBQVMsT0FBTztBQUNsRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLGtCQUFrQixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNLFNBQVMsTUFBTSxrQkFBa0I7QUFDdkMsTUFBSSxDQUFDLFFBQVE7QUFDWCx3QkFBb0I7QUFDcEIsVUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyx5QkFBeUIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ2pFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLE1BQU0saUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUNuRSxNQUFJLFFBQVEsTUFBTSxnQkFBZ0I7QUFDbEMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLGdCQUFnQixJQUFJLEVBQUU7QUFBQSxJQUM5RCxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxXQUFRLE1BQU0sa0JBQWtCLEtBQU07QUFDdEMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyxnQkFBZ0I7QUFBQSxNQUN6QixRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLFdBQVcsTUFBTSxrQkFBa0I7QUFBQSxNQUNuQyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyw0Q0FBNEM7QUFBQSxNQUNyRCxRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sZUFBZSxPQUFPLFFBQVEsT0FBTyxPQUFPO0FBQ2xELFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBV0EsSUFBTSxzQkFBc0I7QUFFNUIsZUFBZSxxQkFBNkM7QUFDMUQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxtQkFBbUI7QUFDbEUsUUFBTSxLQUFLLE9BQU8sbUJBQW1CO0FBQ3JDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsbUJBQW1CLElBQWtDO0FBQ2xFLE1BQUksT0FBTyxLQUFNLE9BQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxtQkFBbUI7QUFBQSxNQUNsRSxPQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUNwRTtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELDJCQUF5QjtBQUN6QixRQUFNLFFBQVEsTUFBTSxxQkFBcUI7QUFDekMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUssNkJBQTZCO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELDBCQUF3QixPQUFPO0FBQy9CLE9BQUssZUFBZTtBQUNwQixRQUFNLEtBQUssNEJBQTRCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQy9FLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksMkJBQWtFO0FBRXRFLFNBQVMsd0JBQXdCLFNBQXVCO0FBQ3RELE1BQUksNkJBQTZCLEtBQU0sZUFBYyx3QkFBd0I7QUFDN0UsNkJBQTJCLFlBQVksTUFBTTtBQUMzQyxTQUFLLGVBQWUsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNuQyxXQUFLLEtBQUssMkJBQTJCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDekQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHlCQUErQjtBQUN0QyxNQUFJLDZCQUE2QixNQUFNO0FBQ3JDLGtCQUFjLHdCQUF3QjtBQUN0QywrQkFBMkI7QUFBQSxFQUM3QjtBQUNGO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQseUJBQXVCO0FBQ3ZCLFFBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sUUFBUSxNQUFNLG1CQUFtQjtBQUN2QyxRQUFNLG1CQUFtQixJQUFJO0FBQzdCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLFVBQVU7QUFBQSxJQUNuQixXQUFXLE1BQU0sYUFBYTtBQUFBLEVBQ2hDLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJLE9BQU8sTUFBTSxxQkFBcUI7QUFDdEMsTUFBSSxTQUFTLE1BQU07QUFDakIsMkJBQXVCO0FBQ3ZCO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUNBLFVBQU0sS0FBSyxvREFBb0Q7QUFBQSxNQUM3RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFDRCxVQUFNLGtCQUFrQixLQUFLLFNBQVMsT0FBTztBQUM3QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUVBLFFBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxNQUFJLENBQUMsUUFBUTtBQUNYLDJCQUF1QjtBQUN2QixVQUFNLG1CQUFtQixJQUFJO0FBQzdCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLDZCQUE2QixFQUFFLFdBQVcsS0FBSyxVQUFVLENBQUM7QUFDckUsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUdBLE1BQUksTUFBTSxZQUFZLE9BQU8sT0FBTyxHQUFHO0FBQ3JDLFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQU9BLFFBQU0sTUFDSixPQUFPLFdBQVcsYUFDZCw4QkFBOEIsT0FBTyxPQUFPLEtBQzVDLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDN0QsTUFBSSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3JDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxtQkFBbUIsSUFBSSxFQUFFO0FBQUEsSUFDakUsT0FBTztBQUNMLFlBQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQztBQUFBLElBQzFDO0FBQ0EsV0FBUSxNQUFNLHFCQUFxQixLQUFNO0FBQ3pDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLEtBQUssb0JBQW9CO0FBQUEsTUFDN0IsVUFBVSxPQUFPO0FBQUEsTUFDakIsYUFBYSxPQUFPLFdBQVcsYUFBYSxPQUFPLE9BQU87QUFBQSxNQUMxRCxXQUFXLE1BQU0scUJBQXFCO0FBQUEsTUFDdEMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsVUFBVSxPQUFPO0FBQUEsTUFDakIsR0FBRyxjQUFjLEdBQUc7QUFBQSxJQUN0QixDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBU0EsSUFBTSxzQkFBc0I7QUFFNUIsZUFBZSxxQkFBNkM7QUFDMUQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxtQkFBbUI7QUFDbEUsUUFBTSxLQUFLLE9BQU8sbUJBQW1CO0FBQ3JDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsbUJBQW1CLElBQWtDO0FBQ2xFLE1BQUksT0FBTyxLQUFNLE9BQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxtQkFBbUI7QUFBQSxNQUNsRSxPQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUNwRTtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELDJCQUF5QjtBQUN6QixRQUFNLFFBQVEsTUFBTSxxQkFBcUI7QUFDekMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUssNkJBQTZCO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELDBCQUF3QixPQUFPO0FBQy9CLE9BQUssZUFBZTtBQUNwQixRQUFNLEtBQUssNEJBQTRCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQy9FLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksMkJBQWtFO0FBRXRFLFNBQVMsd0JBQXdCLFNBQXVCO0FBQ3RELE1BQUksNkJBQTZCLEtBQU0sZUFBYyx3QkFBd0I7QUFDN0UsNkJBQTJCLFlBQVksTUFBTTtBQUMzQyxTQUFLLGVBQWUsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNuQyxXQUFLLEtBQUssMkJBQTJCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDekQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHlCQUErQjtBQUN0QyxNQUFJLDZCQUE2QixNQUFNO0FBQ3JDLGtCQUFjLHdCQUF3QjtBQUN0QywrQkFBMkI7QUFBQSxFQUM3QjtBQUNGO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQseUJBQXVCO0FBQ3ZCLFFBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sUUFBUSxNQUFNLG1CQUFtQjtBQUN2QyxRQUFNLG1CQUFtQixJQUFJO0FBQzdCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLFVBQVU7QUFBQSxJQUNuQixXQUFXLE1BQU0sYUFBYTtBQUFBLEVBQ2hDLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJLE9BQU8sTUFBTSxxQkFBcUI7QUFDdEMsTUFBSSxTQUFTLE1BQU07QUFDakIsMkJBQXVCO0FBQ3ZCO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZUFBZ0I7QUFDOUIsVUFBTSxLQUFLLG9EQUFvRDtBQUFBLE1BQzdELFVBQVUsS0FBSyxTQUFTO0FBQUEsTUFDeEIsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUNELFVBQU0sbUJBQW1CLEtBQUssU0FBUyxPQUFPO0FBQzlDLFVBQU0sa0JBQWtCLEtBQUssU0FBUyxPQUFPO0FBQzdDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBRUEsUUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsMkJBQXVCO0FBQ3ZCLFVBQU0sbUJBQW1CLElBQUk7QUFDN0IsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLEtBQUssNkJBQTZCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNyRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxNQUFNLGtCQUFrQixPQUFPLE9BQU8sR0FBRztBQUMzQyxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLE1BQU0saUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUNuRSxNQUFJLFFBQVEsTUFBTSxtQkFBbUI7QUFDckMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLElBQUksTUFBTSx3QkFBd0I7QUFDeEUsY0FBUSxJQUFJO0FBQ1osWUFBTSxtQkFBbUIsS0FBSztBQUFBLElBQ2hDLE9BQU87QUFDTCxZQUFNLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUNBLFVBQU0sbUJBQW1CLE9BQU8sT0FBTztBQUN2QyxXQUFRLE1BQU0scUJBQXFCLEtBQU07QUFDekMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFdBQUssbUJBQW1CLEtBQUs7QUFBQSxJQUMvQjtBQUNBLFVBQU0sS0FBSyxvQkFBb0I7QUFBQSxNQUM3QixRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLFdBQVcsTUFBTSxxQkFBcUI7QUFBQSxNQUN0QyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sbUJBQW1CLE9BQU8sT0FBTztBQUN2QyxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQUEsRUFDakM7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLG1CQUFtQixPQUE4QjtBQUM5RCxRQUFNLElBQUksUUFBUSxDQUFDLFlBQVksV0FBVyxTQUFTLElBQUksQ0FBQztBQUN4RCxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxNQUFNO0FBQUEsTUFDaEIsT0FBTztBQUFBLE1BQ1AsTUFBTSxNQUFNO0FBQ1YsY0FBTSxJQUFJLE9BQU87QUFDakIsY0FBTSxPQUFPLE1BQU0sT0FBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUM7QUFDdkUsYUFBSztBQUNMLG1CQUFXLE1BQU0sSUFBSTtBQUNyQixtQkFBVyxNQUFNLElBQUk7QUFBQSxNQUN2QjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLG1DQUFtQyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ2xFO0FBQ0Y7QUFJQSxlQUFlLFdBQ2IsUUFDQSxVQUNBLEtBQ0EsS0FDQSxLQUNlO0FBQ2YsUUFBTSxNQUFPLHdCQUF3QixFQUFFLFFBQVEsVUFBVSxLQUFLLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUNyRixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLEtBQU07QUFDeEQsUUFBTSxVQUE2QjtBQUFBLElBQ2pDLGdCQUFnQjtBQUFBLElBQ2hCO0FBQUEsSUFDQTtBQUFBLElBQ0EsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3BDLFlBQVk7QUFBQSxJQUNaLE9BQU8sY0FBYyxHQUFHO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxLQUFLLFdBQVcsUUFBUSxXQUFXO0FBQ3pDLFFBQU0sT0FBTyxNQUFNLEtBQUssS0FBSyxVQUFVLE9BQU8sQ0FBQztBQUMvQyxRQUFNLE9BQU8sbUJBQW1CLEVBQUUsSUFBSSxJQUFJO0FBQzFDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxPQUFPLFFBQVE7QUFBQSxNQUNuQjtBQUFBLE1BQ0EsZUFBZUgsVUFBUyxLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsTUFDL0QsU0FBUyxlQUFlLE1BQU0sSUFBSSxRQUFRO0FBQUEsSUFDNUMsQ0FBQztBQUFBLEVBQ0gsU0FBUyxNQUFNO0FBQ2IsVUFBTSxNQUFPLDRCQUE0QixFQUFFLEdBQUcsY0FBYyxJQUFJLEVBQUUsQ0FBQztBQUFBLEVBQ3JFO0FBQ0Y7QUFFQSxlQUFlLEtBQUssR0FBNEI7QUFDOUMsUUFBTSxNQUFNLElBQUksWUFBWSxFQUFFLE9BQU8sQ0FBQztBQUN0QyxRQUFNLFNBQVMsTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLEdBQUc7QUFDeEQsUUFBTSxNQUFNLE1BQU0sS0FBSyxJQUFJLFdBQVcsTUFBTSxDQUFDLEVBQzFDLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUU7QUFDVixTQUFPLElBQUksTUFBTSxHQUFHLENBQUM7QUFDdkI7QUFJQSxlQUFlLGlCQUFpQixPQUErQjtBQUM3RCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLE1BQU07QUFDdEQsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU87QUFBQSxNQUNQLGVBQWU7QUFBQSxNQUNmLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxNQUFJLENBQUMsT0FBTztBQUlWLFFBQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFlBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUMzQyxVQUFJLFNBQVMsS0FBSyxpQkFBa0I7QUFBQSxJQUN0QztBQUtBLFFBQUksS0FBSyxXQUFXO0FBQ2xCLFlBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTO0FBQ2xELFVBQUksTUFBTSw4QkFBK0I7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sSUFBSSxNQUFNLE9BQU8saUJBQWlCO0FBSXhDLFFBQUksV0FBVztBQUNmLFFBQUksU0FBUyxVQUFVLFNBQVMsV0FBVyxFQUFFLGdCQUFnQjtBQUMzRCxpQkFBVyxNQUFNLE9BQU8sYUFBYSxTQUFTLE1BQU07QUFBQSxJQUN0RDtBQUNBLFVBQU0sYUFBYSxTQUFTLGlCQUFpQixLQUFLLEtBQUs7QUFDdkQsUUFBSSxZQUFZLFlBQVk7QUFDMUIsWUFBTSxPQUFPLGtCQUFrQjtBQUFBLElBQ2pDO0FBQ0EsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTyxFQUFFO0FBQUEsTUFDVCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZSxFQUFFO0FBQUEsTUFDakIsd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sS0FBSyx1QkFBdUI7QUFBQSxNQUNoQyxPQUFPLEVBQUU7QUFBQSxNQUNULE1BQU0sRUFBRTtBQUFBLE1BQ1IsZ0JBQWdCLEVBQUU7QUFBQSxNQUNsQixtQkFBbUIsU0FBUztBQUFBLE1BQzVCLDBCQUEwQjtBQUFBLE1BQzFCLGNBQWMsYUFBYSxZQUFZO0FBQUEsSUFDekMsQ0FBQztBQUNELFFBQUksQ0FBQyxVQUFVO0FBQ2IsWUFBTSxLQUFLLDhDQUE4QztBQUFBLFFBQ3ZELFlBQVksU0FBUztBQUFBLFFBQ3JCLGdCQUFnQixFQUFFO0FBQUEsUUFDbEIsS0FBSyx3Q0FBd0MsRUFBRTtBQUFBLE1BQ2pELENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixVQUFNLE1BQU0sZUFBZSxjQUFjLElBQUksV0FBVztBQUN4RCxVQUFNLFNBQ0osUUFBUSxTQUNKLGVBQ0EsUUFBUSxlQUNOLGlCQUNBLFFBQVEsWUFDTixrQkFDQTtBQUNWLFVBQU0sVUFDSixlQUFlLGVBQWUsUUFBUSxlQUFlLElBQUksbUJBQW1CO0FBQzlFLFVBQU0sY0FBYztBQUFBLE1BQ2xCO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTyxjQUFjLEdBQUcsRUFBRTtBQUFBLE1BQzFCLGVBQWU7QUFBQSxNQUNmLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLEtBQUssMkJBQTJCO0FBQUEsTUFDcEMsVUFBVTtBQUFBLE1BQ1Ysa0JBQWtCO0FBQUEsTUFDbEIsR0FBRyxjQUFjLEdBQUc7QUFBQSxJQUN0QixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsb0JBQW9CLE9BQStCO0FBQ2hFLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsS0FBSztBQUNqQixVQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxPQUFPO0FBSVYsVUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFJLEtBQUssV0FBVyxrQkFBa0IsS0FBSyxxQkFBcUIsTUFBTTtBQUNwRSxZQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDM0MsVUFBSSxTQUFTLEtBQUssaUJBQWtCO0FBQUEsSUFDdEM7QUFJQSxVQUFNLGdCQUFnQixNQUFNLHVCQUF1QjtBQUNuRCxRQUFJLGVBQWU7QUFDakIsWUFBTSxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxhQUFhO0FBQ2pELFVBQUksT0FBTyxTQUFTLEdBQUcsS0FBSyxNQUFNLDhCQUErQjtBQUFBLElBQ25FO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxPQUFPLE1BQU0sT0FBTyxhQUFhLHNCQUFzQjtBQUM3RCxRQUFJLENBQUMsTUFBTTtBQUNULFVBQUksTUFBTyxPQUFNLEtBQUssaURBQWlEO0FBQ3ZFLFlBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEMsWUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLFNBQVMsa0JBQWtCLElBQUk7QUFDckMsUUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QixZQUFNLEtBQUssOENBQThDO0FBQ3pELFlBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEMsWUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLFlBQVksTUFBTTtBQUN4QixVQUFNLHVCQUF1QixRQUFRLEtBQUs7QUFDMUMsVUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRCxRQUFJLE1BQU8sT0FBTSxLQUFLLDJCQUEyQixFQUFFLE9BQU8sT0FBTyxPQUFPLENBQUM7QUFBQSxFQUMzRSxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaURBQWlELGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDaEY7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLHVCQUF1QixRQUFzQixPQUErQjtBQUN6RixRQUFNLE9BQU8sTUFBTSxPQUFPLGFBQWEsb0JBQW9CO0FBQzNELE1BQUksQ0FBQyxNQUFNO0FBQ1QsVUFBTSxtQkFBbUIsSUFBSTtBQUM3QixRQUFJLE1BQU8sT0FBTSxLQUFLLDBEQUEwRDtBQUNoRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxXQUFXLHFCQUFxQixLQUFLLE1BQU0sSUFBSSxDQUFZO0FBQ2pFLFVBQU0sbUJBQW1CLFFBQVE7QUFDakMsUUFBSSxPQUFPO0FBQ1QsWUFBTSxLQUFLLDhCQUE4QjtBQUFBLFFBQ3ZDLFVBQVUsT0FBTyxLQUFLLFNBQVMsUUFBUSxFQUFFO0FBQUEsUUFDekMsY0FBYyxTQUFTO0FBQUEsTUFDekIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSywrREFBK0QsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUM5RjtBQUNGO0FBSUEsZUFBZSxpQkFBZ0M7QUFDN0MsUUFBTSxRQUFRLE1BQU0sV0FBVztBQUMvQixVQUFRLFFBQVEsWUFBWSxFQUFFLE1BQU0saUJBQWlCLE1BQU0sQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUM5RTtBQUVBLGVBQWUsYUFBc0M7QUFDbkQsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLFdBQVc7QUFDZixNQUFJO0FBQ0YsVUFBTSxPQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFDM0YsZUFBVyxLQUFLO0FBQUEsRUFDbEIsUUFBUTtBQUFBLEVBR1I7QUFDQSxRQUFNLGdCQUFnQixNQUFNLGtCQUFrQjtBQUM5QyxRQUFNLG1CQUFtQixNQUFNLHFCQUFxQjtBQUNwRCxRQUFNLG1CQUFtQixNQUFNLHFCQUFxQjtBQUNwRCxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSx1QkFBdUIsTUFBTSx3QkFBd0I7QUFDM0QsU0FBTztBQUFBLElBQ0wsU0FBUztBQUFBLElBQ1QsVUFBVSxlQUFlLFFBQVE7QUFBQSxJQUNqQyxZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVk7QUFBQSxNQUNWLFFBQVEsbUJBQW1CLFFBQVEsb0JBQW9CO0FBQUEsTUFDdkQ7QUFBQSxNQUNBLGFBQWEsZ0JBQWdCLGVBQWU7QUFBQSxNQUM1QyxlQUFlLGdCQUFnQixpQkFBaUI7QUFBQSxNQUNoRCxrQkFBa0IsZ0JBQWdCLG9CQUFvQjtBQUFBLE1BQ3RELHVCQUF1QixnQkFBZ0IseUJBQXlCO0FBQUEsTUFDaEUsaUJBQWlCLGdCQUFnQixtQkFBbUI7QUFBQSxNQUNwRCxlQUFlLGdCQUFnQixpQkFBaUI7QUFBQSxJQUNsRDtBQUFBLElBQ0EsY0FBYztBQUFBLE1BQ1osT0FBTztBQUFBLE1BQ1AsU0FBUywwQkFBMEI7QUFBQSxNQUNuQyxXQUFXLGFBQWEsYUFBYTtBQUFBLE1BQ3JDLGdCQUFnQixhQUFhLGdCQUFnQjtBQUFBLElBQy9DO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxNQUNmLE9BQU87QUFBQSxNQUNQLFNBQVMsNkJBQTZCO0FBQUEsTUFDdEMsV0FBVyxnQkFBZ0IsYUFBYTtBQUFBLE1BQ3hDLGdCQUFnQixnQkFBZ0IsZ0JBQWdCO0FBQUEsSUFDbEQ7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLE1BQ2YsT0FBTztBQUFBLE1BQ1AsU0FBUyw2QkFBNkI7QUFBQSxNQUN0QyxXQUFXLGdCQUFnQixhQUFhO0FBQUEsTUFDeEMsZ0JBQWdCLGdCQUFnQixnQkFBZ0I7QUFBQSxJQUNsRDtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBeUM7QUFDL0QsU0FBTztBQUFBLElBQ0wsT0FBTyxFQUFFO0FBQUEsSUFDVCxNQUFNLEVBQUU7QUFBQSxJQUNSLFFBQVEsRUFBRTtBQUFBLElBQ1YsU0FBUyxFQUFFO0FBQUEsSUFDWCxhQUFhLEVBQUU7QUFBQSxJQUNmLGNBQWMsRUFBRTtBQUFBLElBQ2hCLHVCQUF1QixFQUFFO0FBQUEsSUFDekIsZ0JBQWdCLEVBQUU7QUFBQSxJQUNsQixzQkFBc0IsRUFBRTtBQUFBLElBQ3hCLFFBQVEsRUFBRSxJQUFJLFNBQVM7QUFBQSxJQUN2QixXQUFXLEVBQUUsSUFBSSxVQUFVLElBQUksRUFBRSxJQUFJLE1BQU0sRUFBRSxJQUFJO0FBQUEsRUFDbkQ7QUFDRjtBQUVBLFNBQVMscUJBQXFCLEtBQStCO0FBQzNELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVLE9BQU0sSUFBSSxNQUFNLDJCQUEyQjtBQUNoRixRQUFNLFdBQVc7QUFDakIsTUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTLFFBQVEsRUFBRyxPQUFNLElBQUksTUFBTSxtQ0FBbUM7QUFDMUYsUUFBTSxXQUF3QyxDQUFDO0FBQy9DLGFBQVcsU0FBUyxTQUFTLFVBQVU7QUFDckMsUUFBSSxDQUFDLFNBQVMsT0FBTyxVQUFVLFNBQVU7QUFDekMsVUFBTSxNQUFNO0FBQ1osVUFBTSxTQUFTLE9BQU8sSUFBSSxXQUFXLFdBQVcsSUFBSSxTQUFTO0FBQzdELFFBQUksQ0FBQyxVQUFVLFdBQVcsUUFBUztBQUNuQyxhQUFTLE9BQU8sWUFBWSxDQUFDLElBQUk7QUFBQSxNQUMvQjtBQUFBLE1BQ0EsZ0JBQWdCLE9BQU8sSUFBSSxtQkFBbUIsV0FBVyxJQUFJLGlCQUFpQjtBQUFBLE1BQzlFLG1CQUFtQixPQUFPLElBQUksc0JBQXNCLFdBQVcsSUFBSSxvQkFBb0I7QUFBQSxNQUN2RixXQUFXLE9BQU8sSUFBSSxjQUFjLFdBQVcsSUFBSSxZQUFZO0FBQUEsSUFDakU7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUFBLElBQ0wsY0FBYyxPQUFPLFNBQVMsaUJBQWlCLFdBQVcsU0FBUyxlQUFlO0FBQUEsSUFDbEYsYUFBWSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ25DO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyx3QkFBd0IsR0FBbUIsVUFBMkM7QUFDN0YsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUN0QixRQUFNLFFBQVEsU0FBUyxTQUFTLEVBQUUsZUFBZSxZQUFZLENBQUM7QUFDOUQsTUFBSSxDQUFDLE9BQU8sZUFBZ0IsUUFBTztBQUNuQyxRQUFNLFNBQVMsS0FBSyxNQUFNLEVBQUUsU0FBUztBQUNyQyxRQUFNLFNBQVMsS0FBSyxNQUFNLE1BQU0sY0FBYztBQUM5QyxTQUFPLE9BQU8sU0FBUyxNQUFNLEtBQUssT0FBTyxTQUFTLE1BQU0sS0FBSyxVQUFVO0FBQ3pFO0FBRUEsU0FBUyxtQkFDUCxHQUNBLFVBQ0EsUUFDQSxZQUFnQyxPQUNoQyxTQUFrQyxZQUNuQjtBQUNmLFNBQU87QUFBQSxJQUNMLFVBQVUsRUFBRTtBQUFBLElBQ1osZ0JBQWdCLEVBQUU7QUFBQSxJQUNsQixXQUFXLEVBQUU7QUFBQSxJQUNiLE1BQU0sRUFBRSxpQkFBaUIsRUFBRTtBQUFBLElBQzNCLFlBQVksRUFBRTtBQUFBLElBQ2QsV0FBVyxFQUFFO0FBQUEsSUFDYixTQUFTO0FBQUEsSUFDVDtBQUFBLElBQ0EsZ0JBQWdCLGNBQWMsYUFBYSxVQUFVO0FBQUEsSUFDckQ7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGlCQUFpQixTQUFpQztBQUN6RCxTQUNFLE9BQU8sWUFBWSxZQUNuQiw2RUFBNkUsS0FBSyxPQUFPO0FBRTdGO0FBRUEsU0FBUyxXQUFXLEtBQXFCO0FBRXZDLFFBQU0sSUFBSSxJQUFJLEtBQUssR0FBRztBQUN0QixNQUFJLE9BQU8sTUFBTSxFQUFFLFFBQVEsQ0FBQyxFQUFHLFFBQU8sSUFBSSxRQUFRLFNBQVMsRUFBRTtBQUM3RCxRQUFNLE1BQU0sQ0FBQyxHQUFXLElBQUksTUFBTSxPQUFPLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUMzRCxTQUNFLEdBQUcsRUFBRSxlQUFlLENBQUMsSUFBSSxJQUFJLEVBQUUsWUFBWSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUNwRSxJQUFJLEVBQUUsWUFBWSxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUMsR0FBRyxJQUFJLEVBQUUsY0FBYyxDQUFDLENBQUM7QUFFOUU7QUFFQSxTQUFTLFVBQVUsR0FBcUI7QUFDdEMsU0FBTyxXQUFXLEVBQUUsS0FBSyxjQUFjLEVBQUUsSUFBSTtBQUMvQztBQVNBLFNBQVMsZUFBZSxNQUF5QjtBQUMvQyxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1JLE9BQU07QUFDWixVQUFJLE9BQU9BLEtBQUksZUFBZSxTQUFVLE1BQUssSUFBSUEsS0FBSSxVQUFVO0FBQy9ELGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsS0FBSztBQUN4QjtBQU9BLFNBQVMsb0JBQW9CLE1BQWUsVUFBbUM7QUFDN0UsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNQSxPQUFNO0FBQ1osVUFBSUEsS0FBSSxlQUFlLFVBQVU7QUFDL0IsZUFBTyxPQUFPLEtBQUtBLElBQUcsRUFBRSxLQUFLO0FBQUEsTUFDL0I7QUFDQSxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBUUEsU0FBUyxpQkFBaUIsTUFBZSxVQUFrQixNQUF5QjtBQUNsRixRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsTUFBSSxRQUF3QztBQUM1QyxTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUEsT0FBTTtBQUNaLFVBQUlBLEtBQUksZUFBZSxVQUFVO0FBQy9CLGdCQUFRQTtBQUNSO0FBQUEsTUFDRjtBQUNBLGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLE1BQUksTUFBZTtBQUNuQixhQUFXLE9BQU8sTUFBTTtBQUN0QixRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVSxRQUFPLElBQUksUUFBUSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzFGLFVBQU8sSUFBZ0MsR0FBRztBQUFBLEVBQzVDO0FBQ0EsTUFBSSxRQUFRLE9BQVcsUUFBTztBQUM5QixNQUFJLFFBQVEsS0FBTSxRQUFPO0FBQ3pCLE1BQUksT0FBTyxRQUFRLFNBQVUsUUFBTyxJQUFJLE9BQU8sR0FBRztBQUNsRCxNQUFJLE1BQU0sUUFBUSxHQUFHLEVBQUcsUUFBTyxjQUFjLElBQUksTUFBTTtBQUN2RCxTQUFPLE9BQU8sS0FBSyxHQUE4QixFQUFFLEtBQUs7QUFDMUQ7QUFFQSxTQUFTLFdBQVcsR0FBbUI7QUFHckMsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLElBQUksQ0FBQztBQUN4QixVQUFNLE9BQU8sT0FBTyxZQUFZLE9BQU8sU0FBUyxZQUFPO0FBQ3ZELFdBQU8sT0FBTyxTQUFTLFdBQVcsT0FBTyxTQUFTLGdCQUM5QyxPQUNBLEdBQUcsT0FBTyxJQUFJLEdBQUcsSUFBSTtBQUFBLEVBQzNCLFFBQVE7QUFDTixXQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFBQSxFQUNoRDtBQUNGO0FBS0MsV0FBdUMsZUFBZTtBQUFBLEVBQ3JEO0FBQUEsRUFDQSxVQUFVO0FBQUEsRUFDVixVQUFVO0FBQUEsRUFDVixTQUFTO0FBQUEsRUFDVCxVQUFVLE1BQU0sU0FBUyxVQUFVO0FBQUEsRUFDbkMsT0FBTztBQUFBLEVBQ1AsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsZUFBZTtBQUFBLEVBQ2YsaUJBQWlCO0FBQUEsRUFDakIsaUJBQWlCO0FBQUEsRUFDakIsa0JBQWtCO0FBQUEsRUFDbEIsaUJBQWlCO0FBQUEsRUFDakIsaUJBQWlCO0FBQUEsRUFDakIsa0JBQWtCO0FBQ3BCOyIsCiAgIm5hbWVzIjogWyJ0b0Jhc2U2NCIsICJvYmoiLCAiaW5mbyIsICJ0b0Jhc2U2NCIsICJ1bmF2YWlsYWJsZUNvdW50IiwgImVkZ2VDb3VudCIsICJzdWZmaXgiLCAib2JqIl0KfQo=
