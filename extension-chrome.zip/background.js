var browser=globalThis.browser??globalThis.chrome;

// src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true,
  lowBandwidthBrowsing: false
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" },
  { handle: "StephenM", label: "Stephen Miller", category: "core" },
  { handle: "GregoryKBovino", label: "Gregory Bovino", category: "core" },
  { handle: "RealTomHoman", label: "Thomas D. Homan", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  threadOpenQueue: {},
  threadOpenSeen: {},
  refetchSession: null,
  mediaCrawlSession: null,
  threadOpenSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function setArchiveSnapshot(snapshot) {
  await setRaw("archiveSnapshot", snapshot);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
var RECENT_TWEET_SIGHTINGS_MAX = 80;
async function getRecentTweetSightings() {
  return getRaw("recentTweetSightings");
}
async function prependRecentTweetSightings(rows) {
  if (rows.length === 0) return;
  const cur = await getRecentTweetSightings();
  const seen = /* @__PURE__ */ new Set();
  const next = [];
  for (const row of rows) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  for (const row of cur) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  next.length = Math.min(next.length, RECENT_TWEET_SIGHTINGS_MAX);
  await setRaw("recentTweetSightings", next);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function getThreadOpenQueue() {
  return getRaw("threadOpenQueue");
}
async function threadOpenQueueTotal() {
  const q = await getThreadOpenQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function hasThreadOpenSeen(tweetId) {
  const seen = await getRaw("threadOpenSeen");
  return tweetId in seen;
}
async function markThreadOpenSeen(tweetId) {
  const seen = await getRaw("threadOpenSeen");
  seen[tweetId] = (/* @__PURE__ */ new Date()).toISOString();
  await setRaw("threadOpenSeen", seen);
}
async function enqueueThreadOpen(handle, tweetId) {
  if (await hasThreadOpenSeen(tweetId)) return;
  const q = await getThreadOpenQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("threadOpenQueue", q);
  }
}
async function dequeueThreadOpen(tweetId) {
  const q = await getThreadOpenQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("threadOpenQueue", q);
}
async function nextThreadOpenTarget() {
  const q = await getThreadOpenQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getThreadOpenSession() {
  return getRaw("threadOpenSession");
}
async function setThreadOpenSession(s) {
  await setRaw("threadOpenSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (h !== "_unknown" && !isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  const tq = await getThreadOpenQueue();
  let threadOpenIdsRemoved = 0;
  for (const h of Object.keys(tq)) {
    if (!isTargeted(h)) {
      threadOpenIdsRemoved += (tq[h] ?? []).length;
      delete tq[h];
    }
  }
  await setRaw("threadOpenQueue", tq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved,
    threadOpenIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Verify the PAT can write to the configured branch without creating a
   * commit. Moving a ref to its current SHA is a no-op, but GitHub still
   * enforces the Contents: Write permission required by commitFiles().
   */
  async verifyWriteAccess() {
    const head = await this.getBranchHead();
    await this.fetchJson(
      "PATCH",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
      {
        sha: head.sha,
        force: false
      }
    );
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const unavailableTweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const unavailable = pickUnavailableTweet(raw, ctx);
      if (unavailable) {
        unavailableTweets.push(unavailable);
        observed.push(unavailable.tweet_id);
        built.add(unavailable.tweet_id);
        continue;
      }
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, unavailable_tweets: unavailableTweets, partial_ids };
}
function pickUnavailableTweet(node, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename !== "TweetTombstone") return null;
  const tweetId = strOrNull(n.rest_id) ?? pickTweetIdFromUrls(node) ?? (ctx.sourceUrl ? tweetIdFromTweetUrl(ctx.sourceUrl) : null);
  if (!tweetId || !TWEET_ID_RE.test(tweetId)) return null;
  const unavailableText = pickTombstoneText(node);
  return {
    tweet_id: tweetId,
    account_handle: pickHandleFromTweetUrls(node, tweetId) ?? (ctx.sourceUrl ? handleFromTweetUrl(ctx.sourceUrl, tweetId) : null),
    unavailable_detected_at: ctx.capturedAt,
    unavailable_reason: classifyUnavailableReason(unavailableText),
    unavailable_text: unavailableText,
    unavailable_source_url: ctx.sourceUrl ?? null
  };
}
function pickTweetIdFromUrls(node) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const id = tweetIdFromTweetUrl(cur);
      if (id) return id;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function tweetIdFromTweetUrl(rawUrl) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/[A-Za-z0-9_]{1,15}\/status\/(\d{15,20})(?:\/|$)/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
function pickTombstoneText(node) {
  const strings = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const trimmed = cur.trim();
      if (trimmed.length >= 4 && !trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
        strings.push(trimmed);
      }
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  const preferred = strings.find(
    (s) => /\b(copyright|dmca|unavailable|withheld|removed|deleted|violat|suspended)\b/i.test(s)
  );
  return preferred ?? strings[0] ?? null;
}
function classifyUnavailableReason(text) {
  if (!text) return null;
  if (/\b(copyright|dmca)\b/i.test(text)) return "copyright";
  if (/\bwithheld\b/i.test(text)) return "withheld";
  if (/\bdeleted|removed\b/i.test(text)) return "removed";
  if (/\bsuspended\b/i.test(text)) return "suspended";
  if (/\bunavailable|not available\b/i.test(text)) return "unavailable";
  return null;
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  const hintHandle = pickHintHandle(node, restId);
  if (!hintHandle) return null;
  return { tweet_id: restId, hint_handle: hintHandle };
}
function pickHintHandle(node, tweetId) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name) ?? pickHandleFromTweetUrls(node, tweetId);
}
function pickHandleFromTweetUrls(node, tweetId) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const handle = handleFromTweetUrl(cur, tweetId);
      if (handle) return handle;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function handleFromTweetUrl(rawUrl, tweetId) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d{15,20})(?:\/|$)/);
    if (!match || match[2] !== tweetId) return null;
    return match[1] ?? null;
  } catch {
    return null;
  }
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const retweetedLegacy = obj(obj(obj(legacy.retweeted_status_result)?.result)?.legacy);
  const engLegacy = tweetType === "retweet" && retweetedLegacy ? retweetedLegacy : legacy;
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    unavailable_detected_at: null,
    unavailable_reason: null,
    unavailable_text: null,
    unavailable_source_url: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(engLegacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(engLegacy.reply_count),
    quote_count: numOrZero(engLegacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(engLegacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(engLegacy.reply_count),
        quotes: numOrZero(engLegacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted, coreHandles = /* @__PURE__ */ new Set()) {
  if (targeted.size === 0 && coreHandles.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (coreHandles.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// src/lib/gaps.ts
var X_SEARCH_BASE = "https://x.com/search";
function monthKey(d) {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
}
function parseMonth(ym) {
  const parts = ym.split("-");
  const y = Number(parts[0]);
  const m = Number(parts[1] ?? "1");
  return new Date(Date.UTC(y, m - 1, 1));
}
function addMonths(d, n) {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + n, 1));
}
function addDays(d, n) {
  return new Date(d.getTime() + n * 864e5);
}
function isoDate(d) {
  return d.toISOString().slice(0, 10);
}
function median(nums) {
  if (nums.length === 0) return 0;
  const s = [...nums].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  if (s.length % 2) return s[mid] ?? 0;
  return ((s[mid - 1] ?? 0) + (s[mid] ?? 0)) / 2;
}
function gapSearchUrl(handle, fromDate, toDate) {
  const q = `from:${handle} since:${fromDate} until:${toDate}`;
  return `${X_SEARCH_BASE}?q=${encodeURIComponent(q)}&f=live`;
}
function findCoverageGaps(account, options = {}) {
  const now = options.now ?? /* @__PURE__ */ new Date();
  const sparseRatio = options.sparseRatio ?? 0.25;
  const sparseFloor = options.sparseFloor ?? 3;
  const minMedianForSparse = options.minMedianForSparse ?? 8;
  const recentFrontierMinAgeDays = options.recentFrontierMinAgeDays ?? 2;
  const months = account.months ?? {};
  if (!account.first_post_at) return [];
  const startMonth = parseMonth(account.first_post_at.slice(0, 7));
  const endMonth = parseMonth(monthKey(now));
  const seq = [];
  for (let d = startMonth; d <= endMonth; d = addMonths(d, 1)) {
    const ym = monthKey(d);
    seq.push({ ym, count: months[ym] ?? 0 });
  }
  if (seq.length === 0) return [];
  const activeCounts = seq.filter((s) => s.count > 0).map((s) => s.count);
  const med = median(activeCounts);
  const sparseThreshold = med >= minMedianForSparse ? Math.max(sparseFloor, Math.round(sparseRatio * med)) : 0;
  const latestPostMonth = account.latest_post_at ? account.latest_post_at.slice(0, 7) : null;
  const isHole = (s) => s.count === 0 || sparseThreshold > 0 && s.count < sparseThreshold;
  const gaps = [];
  let run = [];
  const flush = () => {
    const first = run[0];
    const last = run[run.length - 1];
    if (!first || !last) return;
    const fromMonth = first.ym;
    const toMonth = last.ym;
    const fromDate = `${fromMonth}-01`;
    const toDate = isoDate(addMonths(parseMonth(toMonth), 1));
    const captured = run.reduce((acc, s) => acc + s.count, 0);
    const allEmpty = run.every((s) => s.count === 0);
    const isRecent = latestPostMonth !== null && fromMonth > latestPostMonth;
    const kind = isRecent ? "recent" : allEmpty ? "empty" : "sparse";
    gaps.push({
      handle: account.handle,
      fromMonth,
      toMonth,
      fromDate,
      toDate,
      monthCount: run.length,
      capturedInRange: captured,
      kind,
      searchUrl: gapSearchUrl(account.handle, fromDate, toDate)
    });
    run = [];
  };
  for (const s of seq) {
    if (isHole(s)) run.push(s);
    else flush();
  }
  flush();
  if (account.latest_post_at) {
    const last = new Date(account.latest_post_at);
    const ageDays = (now.getTime() - last.getTime()) / 864e5;
    if (ageDays >= recentFrontierMinAgeDays && monthKey(last) === monthKey(now)) {
      const fromDate = isoDate(last);
      const toDate = isoDate(addDays(now, 1));
      gaps.push({
        handle: account.handle,
        fromMonth: monthKey(now),
        toMonth: monthKey(now),
        fromDate,
        toDate,
        monthCount: 0,
        capturedInRange: months[monthKey(now)] ?? 0,
        kind: "recent",
        searchUrl: gapSearchUrl(account.handle, fromDate, toDate)
      });
    }
  }
  return gaps;
}
function rankGaps(gaps) {
  const weight = { recent: 0, empty: 1, sparse: 2 };
  return [...gaps].sort((a, b) => weight[a.kind] - weight[b.kind] || b.monthCount - a.monthCount);
}

// src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
var MANUAL_CAPTURE_WINDOW_MS = 9e4;
var LOW_BANDWIDTH_BASE_RULE_ID = 760001;
var LOW_BANDWIDTH_MEDIA_RULE_ID_BASE = 760010;
var LOW_BANDWIDTH_RESOURCE_TYPES = ["image", "media", "font"];
var LOW_BANDWIDTH_MEDIA_CHUNK_RESOURCE_TYPES = ["media", "xmlhttprequest", "other"];
var LOW_BANDWIDTH_MEDIA_URL_FILTERS = [
  "||video.twimg.com^",
  "||ton.twimg.com^",
  "||amp.twimg.com^",
  "||video.pscp.tv^",
  "||prod-fastly-us-west-1.video.pscp.tv^",
  "|https://x.com/i/videos/",
  "|https://twitter.com/i/videos/"
];
var manualCaptureUntilMs = 0;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
function allowManualCaptureWindow() {
  manualCaptureUntilMs = Date.now() + MANUAL_CAPTURE_WINDOW_MS;
}
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await syncLowBandwidthRules({ reason: `wake:${reason}`, log: false });
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
function dnrApi() {
  const maybeBrowser = browser;
  return maybeBrowser.declarativeNetRequest ?? null;
}
async function currentXTabIds() {
  const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  return tabs.flatMap((tab) => typeof tab.id === "number" ? [tab.id] : []);
}
async function syncLowBandwidthRules({
  reason,
  log
}) {
  const settings = await getSettings();
  const dnr = dnrApi();
  if (!dnr) {
    if (settings.lowBandwidthBrowsing && log) {
      await warn("low-bandwidth browsing unavailable; declarativeNetRequest API missing", {
        reason
      });
    }
    return;
  }
  const tabIds = settings.lowBandwidthBrowsing ? await currentXTabIds() : [];
  const removeRuleIds = [
    LOW_BANDWIDTH_BASE_RULE_ID,
    ...LOW_BANDWIDTH_MEDIA_URL_FILTERS.map((_, idx) => LOW_BANDWIDTH_MEDIA_RULE_ID_BASE + idx)
  ];
  const addRules = tabIds.length > 0 ? [
    {
      id: LOW_BANDWIDTH_BASE_RULE_ID,
      priority: 1,
      action: { type: "block" },
      condition: {
        tabIds,
        resourceTypes: [...LOW_BANDWIDTH_RESOURCE_TYPES]
      }
    },
    ...LOW_BANDWIDTH_MEDIA_URL_FILTERS.map((urlFilter, idx) => ({
      id: LOW_BANDWIDTH_MEDIA_RULE_ID_BASE + idx,
      priority: 2,
      action: { type: "block" },
      condition: {
        tabIds,
        urlFilter,
        resourceTypes: [...LOW_BANDWIDTH_MEDIA_CHUNK_RESOURCE_TYPES]
      }
    }))
  ] : [];
  await dnr.updateSessionRules({
    removeRuleIds,
    addRules
  });
  if (log) {
    await info("low-bandwidth browsing rules updated", {
      enabled: settings.lowBandwidthBrowsing,
      tab_count: tabIds.length,
      blocked_resource_types: LOW_BANDWIDTH_RESOURCE_TYPES.join(","),
      blocked_media_filters: LOW_BANDWIDTH_MEDIA_URL_FILTERS.join(","),
      reason
    });
  }
}
browser.tabs.onUpdated.addListener((_tabId, changeInfo) => {
  if (changeInfo.url || changeInfo.status === "complete") {
    void syncLowBandwidthRules({ reason: "tab-updated", log: false }).catch((err) => {
      void warn("low-bandwidth rule refresh failed", describeError(err));
    });
  }
});
browser.tabs.onRemoved.addListener(() => {
  void syncLowBandwidthRules({ reason: "tab-removed", log: false }).catch((err) => {
    void warn("low-bandwidth rule refresh failed", describeError(err));
  });
});
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var SHOW_MORE_RELEVANCE_TTL_MS = 10 * 60 * 1e3;
var showMoreRelevantTweetsByTab = /* @__PURE__ */ new Map();
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  allowManualCaptureWindow();
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    ingestedNewCount: 0,
    ingestedExistingCount: 0,
    skippedOldCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let retryCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: () => {
          const normalizedText = (el) => `${el.textContent ?? ""} ${el.getAttribute("aria-label") ?? ""}`.replace(/\s+/g, " ").trim().toLowerCase();
          const clickRetryIfReloadError = () => {
            const bodyText = (document.body?.innerText ?? "").toLowerCase();
            if (!bodyText.includes("something went wrong") && !bodyText.includes("try reloading")) {
              return false;
            }
            const controls = Array.from(
              document.querySelectorAll('button,[role="button"],a[href]')
            );
            const retry = controls.find((el) => {
              const text = normalizedText(el);
              return text === "retry" || text.includes("retry") || text.includes("try again");
            });
            if (!retry) return false;
            retry.click();
            return true;
          };
          if (clickRetryIfReloadError()) return { retried: true, scrolled: false };
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { retried: false, scrolled: true };
        }
      });
      const pageResults = results.map((r) => r.result).filter(
        (result) => typeof result === "object" && result !== null
      );
      if (pageResults.some((result) => result.retried === true)) {
        retryCount += 1;
      }
      if (pageResults.some((result) => result.scrolled === true)) {
        scrollCount += 1;
      }
    } catch {
    }
  }
  if (retryCount > 0) {
    await info("auto-scroll clicked X retry control", { tab_count: retryCount });
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      await setAutoScrollSession(sess);
    }
  }
}
function pruneShowMoreRelevance() {
  const cutoff = Date.now() - SHOW_MORE_RELEVANCE_TTL_MS;
  for (const [tabId, entry] of showMoreRelevantTweetsByTab) {
    if (entry.updatedAt < cutoff) showMoreRelevantTweetsByTab.delete(tabId);
  }
}
function rememberShowMoreRelevantTweets(tabId, pageUrl, tweets, coreHandles) {
  if (tabId === null || tweets.length === 0 || coreHandles.size === 0) return;
  const coreTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (coreHandles.has(t.account_handle.toLowerCase())) coreTweetIds.add(t.tweet_id);
  }
  const existing = showMoreRelevantTweetsByTab.get(tabId);
  const tweetIds = existing?.tweetIds ?? /* @__PURE__ */ new Set();
  for (const t of tweets) {
    const handle = t.account_handle.toLowerCase();
    const replyHandle = t.reply_to_account?.toLowerCase() ?? null;
    if (coreHandles.has(handle) || replyHandle !== null && coreHandles.has(replyHandle) || t.reply_to_tweet_id !== null && coreTweetIds.has(t.reply_to_tweet_id) || t.quoted_tweet_id !== null && coreTweetIds.has(t.quoted_tweet_id) || t.retweeted_tweet_id !== null && coreTweetIds.has(t.retweeted_tweet_id)) {
      tweetIds.add(t.tweet_id);
    }
  }
  showMoreRelevantTweetsByTab.set(tabId, {
    updatedAt: Date.now(),
    pageUrl,
    tweetIds
  });
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async (tab) => {
    try {
      const sidebarAction = browser.sidebarAction;
      if (sidebarAction?.toggle) {
        await sidebarAction.toggle();
        return;
      }
      const sidePanel = browser.sidePanel;
      if (sidePanel?.open) {
        const options = {};
        if (typeof tab.windowId === "number") options.windowId = tab.windowId;
        await sidePanel.open(options);
        return;
      }
      await browser.tabs.create({ url: browser.runtime.getURL("sidebar.html") });
    } catch (err) {
      await warn("sidebar open failed; opening sidebar tab", describeError(err));
      try {
        await browser.tabs.create({ url: browser.runtime.getURL("sidebar.html") });
        return;
      } catch (tabErr) {
        await warn("sidebar tab failed; opening options", describeError(tabErr));
      }
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg, sender).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-thread-open",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg, sender) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(
        msg.endpoint,
        msg.url,
        msg.pageUrl ?? null,
        msg.response,
        sender?.tab?.id ?? null
      );
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-unfold-targets": {
      const settings = await getSettings();
      if (settings.enabled === false) {
        return { enabled: false, coreHandles: [], relevantTweetIds: [] };
      }
      pruneShowMoreRelevance();
      const accounts = await getAccounts();
      const coreHandles = accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase());
      const tabId = sender?.tab?.id ?? null;
      return {
        enabled: true,
        coreHandles,
        relevantTweetIds: tabId === null ? [] : Array.from(showMoreRelevantTweetsByTab.get(tabId)?.tweetIds ?? [])
      };
    }
    case "show-more-unfolded": {
      if (msg.count > 0) {
        const asSess = await getAutoScrollSession();
        if (asSess !== null) {
          asSess.expandedCount += msg.count;
          await setAutoScrollSession(asSess);
        }
      }
      return { ok: true };
    }
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-update-existing":
      await updateSettings({ updateExisting: msg.on });
      await info("update-existing toggled", { on: msg.on });
      return buildState();
    case "toggle-low-bandwidth":
      await updateSettings({ lowBandwidthBrowsing: msg.on });
      await syncLowBandwidthRules({ reason: "toggle", log: true });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        stopThreadOpenInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
        await browser.alarms.clear("thread-open-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      if (threadOpenIntervalHandle !== null) startThreadOpenInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "start-thread-open":
      await startThreadOpenLoop();
      return buildState();
    case "cancel-thread-open":
      await cancelThreadOpenLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    case "get-coverage-gaps": {
      const snapshot = await getArchiveSnapshot();
      if (!snapshot) {
        return { ok: false, error: "no archive snapshot yet \u2014 check connection in Settings" };
      }
      const all = [];
      for (const account of Object.values(snapshot.accounts)) {
        all.push(...findCoverageGaps(account));
      }
      return { ok: true, gaps: rankGaps(all), generatedAt: snapshot.generated_at };
    }
    case "open-url": {
      const url = msg.url;
      if (typeof url !== "string" || !/^https:\/\/(x\.com|twitter\.com)\//.test(url)) {
        return { ok: false, error: "refusing to open a non-X url" };
      }
      await browser.tabs.create({ url, active: true });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, pageUrl, response, senderTabId) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const settings = await getSettings();
  if (settings.enabled === false) return;
  if (settings.autoCapture === false) {
    const explicitCaptureActive = Date.now() < manualCaptureUntilMs || await getAutoScrollSession() !== null || await getRefetchSession() !== null || await getMediaCrawlSession() !== null;
    if (!explicitCaptureActive) return;
  }
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const core = new Set(
    accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase())
  );
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set(),
      sourceUrl: pageUrl
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const retweetEdges = buildRetweetEdges(
    normalized.tweets,
    accounts,
    capturedAt,
    endpoint,
    pageUrl ?? url
  );
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked, core);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  rememberShowMoreRelevantTweets(senderTabId, pageUrl, normalized.tweets, core);
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.unavailable_tweets.length > 0) {
    await recordUnavailableTweets(
      normalized.unavailable_tweets,
      tracked,
      capturedAt,
      url,
      endpoint
    );
  }
  if (normalized.tweets.length === 0) {
    const bufferedEdges = await bufferRetweetEdges(
      retweetEdges,
      capturedAt,
      pageUrl ?? url,
      endpoint
    );
    if (bufferedEdges > 0) await broadcastState();
    return;
  }
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    if (threadOpenSess?.inflight?.tweetId === t.tweet_id) {
      threadOpenSess.inflight = null;
      threadOpenSess.processed += 1;
      await markThreadOpenSeen(t.tweet_id);
      await dequeueThreadOpen(t.tweet_id);
      await setThreadOpenSession(threadOpenSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const updateExisting = settings.updateExisting !== false;
  const committedIdx = await getCommittedIndex();
  const archiveSnapshot = await getArchiveSnapshot();
  let dedupedSkipped = 0;
  let skippedNoUpdateLocal = 0;
  let skippedNoUpdateSnapshot = 0;
  let oldFromSnapshot = 0;
  let fullTextUpgrades = 0;
  const liveTweets = [];
  const freshnessById = /* @__PURE__ */ new Map();
  const actionById = /* @__PURE__ */ new Map();
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const oldBySnapshot = !prev && archiveSnapshotHasTweet(t, archiveSnapshot);
    const previouslyArchived = Boolean(prev) || oldBySnapshot;
    freshnessById.set(t.tweet_id, previouslyArchived ? "existing" : "new");
    if (oldBySnapshot) oldFromSnapshot += 1;
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    const fullTextUpgrade = prev !== void 0 && sigMarksTruncated(prev.sig) && !t.is_truncated;
    if (previouslyArchived && !updateExisting && !fullTextUpgrade) {
      if (prev) skippedNoUpdateLocal += 1;
      else skippedNoUpdateSnapshot += 1;
      actionById.set(t.tweet_id, "skipped");
      continue;
    }
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      actionById.set(t.tweet_id, "unchanged");
      continue;
    }
    if (fullTextUpgrade) fullTextUpgrades += 1;
    actionById.set(t.tweet_id, "buffered");
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (skippedNoUpdateLocal + skippedNoUpdateSnapshot > 0) {
    const skippedOld = skippedNoUpdateLocal + skippedNoUpdateSnapshot;
    await info("dedup: skipped previously archived tweets (updateExisting=false)", {
      endpoint,
      skipped: skippedOld,
      local_index: skippedNoUpdateLocal,
      archive_snapshot: skippedNoUpdateSnapshot,
      remaining: liveTweets.length
    });
    const asSess = await getAutoScrollSession();
    if (asSess !== null) {
      asSess.skippedOldCount = (asSess.skippedOldCount ?? 0) + skippedOld;
      await setAutoScrollSession(asSess);
    }
  }
  if (oldFromSnapshot > 0 && updateExisting) {
    await info("archive snapshot recognized old tweets", {
      endpoint,
      old: oldFromSnapshot,
      action: "buffering because updateExisting=true",
      snapshot_generated_at: archiveSnapshot?.generated_at ?? null
    });
  }
  if (fullTextUpgrades > 0) {
    await info("dedup: buffering full-text upgrades", {
      endpoint,
      upgrades: fullTextUpgrades,
      updateExisting,
      remaining: liveTweets.length
    });
  }
  await prependRecentTweetSightings(
    normalized.tweets.map(
      (t) => buildTweetSighting(
        t,
        endpoint,
        capturedAt,
        freshnessById.get(t.tweet_id),
        actionById.get(t.tweet_id)
      )
    )
  );
  await enqueueMissingParents(normalized.tweets, endpoint);
  await enqueueThreadOpenCandidates(normalized.tweets, core, endpoint);
  const bufferedRetweetEdges = await bufferRetweetEdges(
    retweetEdges,
    capturedAt,
    pageUrl ?? url,
    endpoint
  );
  if (liveTweets.length === 0) {
    if (bufferedRetweetEdges > 0) await broadcastState();
    return;
  }
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    let addedNew = 0;
    let addedExisting = 0;
    let updatedBuffered = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
        updatedBuffered += 1;
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
        if (freshnessById.get(t.tweet_id) === "existing") addedExisting += 1;
        else addedNew += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    if (added > 0 || updatedBuffered > 0) {
      await info("buffered tweets", {
        handle,
        endpoint,
        added,
        new: addedNew,
        existing: addedExisting,
        updated_buffered: updatedBuffered,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        asSess.ingestedNewCount = (asSess.ingestedNewCount ?? 0) + addedNew;
        asSess.ingestedExistingCount = (asSess.ingestedExistingCount ?? 0) + addedExisting;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function recordUnavailableTweets(unavailableTweets, tracked, capturedAt, sourceUrl, endpoint) {
  const committedIdx = await getCommittedIndex();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  let recorded = 0;
  let skipped = 0;
  let missingHandle = 0;
  for (const u of unavailableTweets) {
    const handle = u.account_handle;
    if (!handle) {
      missingHandle += 1;
      await dequeueMediaCrawl(u.tweet_id);
      await dequeueThreadOpen(u.tweet_id);
      continue;
    }
    if (tracked.size > 0 && !tracked.has(handle.toLowerCase())) {
      skipped += 1;
      continue;
    }
    await dequeueMediaCrawl(u.tweet_id);
    await dequeueRefetch(handle, u.tweet_id);
    await dequeueThreadOpen(u.tweet_id);
    if (refetchSess?.inflight?.tweetId === u.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === u.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    if (threadOpenSess?.inflight?.tweetId === u.tweet_id) {
      threadOpenSess.inflight = null;
      threadOpenSess.processed += 1;
      await markThreadOpenSeen(u.tweet_id);
      await setThreadOpenSession(threadOpenSess);
    }
    const sig = unavailableSig(u);
    const prev = committedIdx[handle]?.[u.tweet_id];
    if (prev?.sig === sig) {
      skipped += 1;
      continue;
    }
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const unavailableById = buf.unavailable_by_id ?? {};
    unavailableById[u.tweet_id] = u;
    buf.unavailable_by_id = unavailableById;
    if (!buf.tweet_ids_observed.includes(u.tweet_id)) {
      buf.tweet_ids_observed.push(u.tweet_id);
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    recorded += 1;
  }
  if (recorded > 0 || missingHandle > 0 || skipped > 0) {
    await info("unavailable tweets observed", { endpoint, recorded, skipped, missingHandle });
  }
  await broadcastState();
}
function unavailableSig(u) {
  return `unavailable|${u.unavailable_reason ?? ""}|${u.unavailable_text ?? ""}`;
}
function sigMarksTruncated(sig) {
  const parts = sig.split("|");
  return parts[parts.length - 1] === "t";
}
function runBufferItemCount(buf) {
  return Object.keys(buf.tweets_by_id).length + Object.keys(buf.unavailable_by_id ?? {}).length + Object.keys(buf.retweet_edges_by_key ?? {}).length;
}
function retweetEdgeKey(edge) {
  return [edge.retweeter_handle.toLowerCase(), edge.retweet_tweet_id, edge.original_tweet_id].join(
    "|"
  );
}
function inferRetweetedHandle(text) {
  const match = text.match(/^RT\s+@([A-Za-z0-9_]{1,15})\b/i);
  return match?.[1] ?? null;
}
function buildRetweetEdges(tweets, accounts, capturedAt, endpoint, sourceUrl) {
  const categoryByHandle = new Map(accounts.map((a) => [a.handle.toLowerCase(), a.category]));
  const byId = new Map(tweets.map((t) => [t.tweet_id, t]));
  const out = /* @__PURE__ */ new Map();
  for (const t of tweets) {
    if (t.tweet_type !== "retweet" || !t.retweeted_tweet_id) continue;
    const retweeterCategory = categoryByHandle.get(t.account_handle.toLowerCase());
    if (!retweeterCategory) continue;
    const original = byId.get(t.retweeted_tweet_id);
    const originalHandle = original?.account_handle ?? inferRetweetedHandle(t.text_resolved || t.text);
    const originalCategory = originalHandle ? categoryByHandle.get(originalHandle.toLowerCase()) ?? "public" : null;
    const edge = {
      retweeter_handle: t.account_handle,
      retweeter_account_id: t.account_id ?? null,
      retweeter_category: retweeterCategory,
      retweet_tweet_id: t.tweet_id,
      retweet_url: t.tweet_url,
      original_tweet_id: t.retweeted_tweet_id,
      original_author_handle: originalHandle,
      original_author_account_id: original?.account_id ?? null,
      original_author_category: originalCategory,
      captured_at: capturedAt,
      capture_run_id: "pending",
      endpoint,
      source_url: sourceUrl
    };
    out.set(retweetEdgeKey(edge), edge);
  }
  return [...out.values()];
}
async function bufferRetweetEdges(edges, capturedAt, sourceUrl, endpoint) {
  if (edges.length === 0) return 0;
  const byHandle = /* @__PURE__ */ new Map();
  for (const edge of edges) {
    const arr = byHandle.get(edge.retweeter_handle) ?? [];
    arr.push(edge);
    byHandle.set(edge.retweeter_handle, arr);
  }
  let added = 0;
  for (const [handle, handleEdges] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const edgeMap = buf.retweet_edges_by_key ?? {};
    let addedForHandle = 0;
    for (const edge of handleEdges) {
      const stamped = { ...edge, capture_run_id: buf.run_id };
      const key = retweetEdgeKey(stamped);
      if (!edgeMap[key]) addedForHandle += 1;
      edgeMap[key] = stamped;
      if (!buf.tweet_ids_observed.includes(stamped.retweet_tweet_id)) {
        buf.tweet_ids_observed.push(stamped.retweet_tweet_id);
      }
      if (!buf.tweet_ids_observed.includes(stamped.original_tweet_id)) {
        buf.tweet_ids_observed.push(stamped.original_tweet_id);
      }
    }
    if (addedForHandle === 0) continue;
    buf.retweet_edges_by_key = edgeMap;
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    added += addedForHandle;
    await info("buffered retweet edges", {
      handle,
      endpoint,
      added: addedForHandle,
      total: Object.keys(edgeMap).length
    });
  }
  return added;
}
async function enqueueMissingParents(tweets, endpoint) {
  if (tweets.length === 0) return;
  const sameBatchIds = /* @__PURE__ */ new Set();
  for (const t of tweets) sameBatchIds.add(t.tweet_id);
  let enqueued = 0;
  for (const t of tweets) {
    const parents = [];
    if (t.reply_to_tweet_id) {
      parents.push({ id: t.reply_to_tweet_id, hint: t.reply_to_account });
    }
    if (t.quoted_tweet_id) parents.push({ id: t.quoted_tweet_id, hint: null });
    if (t.retweeted_tweet_id) parents.push({ id: t.retweeted_tweet_id, hint: null });
    for (const p of parents) {
      if (sameBatchIds.has(p.id)) continue;
      if (await isCommitted(p.id)) continue;
      await enqueueMediaCrawl(p.hint, p.id);
      enqueued += 1;
    }
  }
  if (enqueued > 0) {
    await info("queued missing parent tweets for detail-page crawl", {
      endpoint,
      enqueued,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
}
async function enqueueThreadOpenCandidates(tweets, coreHandles, endpoint) {
  if (tweets.length === 0 || coreHandles.size === 0) return;
  if (endpoint.includes("TweetDetail") || endpoint.includes("TweetResultByRestId")) return;
  const candidates = /* @__PURE__ */ new Map();
  for (const t of tweets) {
    const handle = t.account_handle.toLowerCase();
    if (!coreHandles.has(handle)) continue;
    const rootId = t.conversation_id ?? t.tweet_id;
    const isRoot = rootId === t.tweet_id || t.reply_to_tweet_id === null;
    const isCoreReply = t.reply_to_tweet_id !== null;
    if (isRoot && t.reply_count > 0) {
      candidates.set(rootId, t.account_handle);
    } else if (isCoreReply && rootId) {
      candidates.set(rootId, t.account_handle);
    }
  }
  let enqueued = 0;
  for (const [tweetId, handle] of candidates) {
    const before = await threadOpenQueueTotal();
    await enqueueThreadOpen(handle, tweetId);
    const after = await threadOpenQueueTotal();
    if (after > before) enqueued += 1;
  }
  if (enqueued > 0) {
    await info("queued core thread roots for opening", {
      endpoint,
      enqueued,
      queue_total: await threadOpenQueueTotal()
    });
  }
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    unavailable_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    const unavailableTweets = Object.values(buf.unavailable_by_id ?? {});
    const retweetEdges = Object.values(buf.retweet_edges_by_key ?? {});
    if (tweets.length === 0 && unavailableTweets.length === 0 && retweetEdges.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets, unavailableTweets, retweetEdges));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("upload buffer deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length + item.unavailableTweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length + item.unavailableTweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      for (const u of item.unavailableTweets) {
        inner[u.tweet_id] = {
          ts: nowIso,
          sig: unavailableSig(u)
        };
      }
      idx[item.handle] = inner;
      await info("upload buffer committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        unavailable: item.unavailableTweets.length,
        retweet_edges: item.retweetEdges.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("upload buffer batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      unavailable: items.reduce((total, item) => total + item.unavailableTweets.length, 0),
      retweet_edges: items.reduce((total, item) => total + item.retweetEdges.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("upload buffer failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("upload buffer failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets, unavailableTweets, retweetEdges) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    unavailableTweets,
    retweetEdges,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets,
      unavailable_tweets: unavailableTweets,
      retweet_edges: retweetEdges
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    const unavailableCount2 = item.unavailableTweets.length;
    const edgeCount2 = item.retweetEdges.length;
    const suffix2 = (unavailableCount2 > 0 ? `, ${unavailableCount2} unavailable` : "") + (edgeCount2 > 0 ? `, ${edgeCount2} retweet edge${edgeCount2 === 1 ? "" : "s"}` : "");
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"}${suffix2} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  const unavailableCount = items.reduce((total, item) => total + item.unavailableTweets.length, 0);
  const edgeCount = items.reduce((total, item) => total + item.retweetEdges.length, 0);
  const suffix = (unavailableCount > 0 ? `, ${unavailableCount} unavailable` : "") + (edgeCount > 0 ? `, ${edgeCount} retweet edge${edgeCount === 1 ? "" : "s"}` : "");
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"}${suffix} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return runBufferItemCount(current);
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  for (const u of item.unavailableTweets) {
    committed.set(u.tweet_id, unavailableSig(u));
  }
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingUnavailable = {};
  for (const [tweetId, unavailable] of Object.entries(current.unavailable_by_id ?? {})) {
    const committedSig = committed.get(tweetId);
    const currentSig = unavailableSig(unavailable);
    if (!committedSig || committedSig !== currentSig) {
      remainingUnavailable[tweetId] = { ...unavailable };
    }
  }
  const remainingRetweetEdges = {};
  for (const [key, edge] of Object.entries(current.retweet_edges_by_key ?? {})) {
    if (!item.retweetEdges.some((committedEdge) => retweetEdgeKey(committedEdge) === key)) {
      remainingRetweetEdges[key] = { ...edge };
    }
  }
  const remainingIds = /* @__PURE__ */ new Set([
    ...Object.keys(remainingTweets),
    ...Object.keys(remainingUnavailable),
    ...Object.values(remainingRetweetEdges).flatMap((edge) => [
      edge.retweet_tweet_id,
      edge.original_tweet_id
    ])
  ]);
  const remainingCount = Object.keys(remainingTweets).length + Object.keys(remainingUnavailable).length + Object.keys(remainingRetweetEdges).length;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  for (const edge of Object.values(remainingRetweetEdges)) {
    edge.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    unavailable_by_id: remainingUnavailable,
    retweet_edges_by_key: remainingRetweetEdges,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => remainingIds.has(id))
  });
  await info("upload buffer kept newer tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  allowManualCaptureWindow();
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      unavailable_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  allowManualCaptureWindow();
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  allowManualCaptureWindow();
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  allowManualCaptureWindow();
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = target.bucket === "_unknown" ? `https://x.com/i/web/status/${target.tweetId}` : `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
var THREAD_OPEN_TAB_KEY = "__imm_archive_thread_open_tab_id__";
async function getThreadOpenTabId() {
  const stored = await browser.storage.local.get(THREAD_OPEN_TAB_KEY);
  const id = stored[THREAD_OPEN_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setThreadOpenTabId(id) {
  if (id === null) await browser.storage.local.remove(THREAD_OPEN_TAB_KEY);
  else await browser.storage.local.set({ [THREAD_OPEN_TAB_KEY]: id });
}
async function startThreadOpenLoop() {
  allowManualCaptureWindow();
  const total = await threadOpenQueueTotal();
  if (total === 0) {
    await info("thread-open: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setThreadOpenSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startThreadOpenInterval(seconds);
  void threadOpenTick();
  await info("thread-open loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var threadOpenIntervalHandle = null;
function startThreadOpenInterval(seconds) {
  if (threadOpenIntervalHandle !== null) clearInterval(threadOpenIntervalHandle);
  threadOpenIntervalHandle = setInterval(() => {
    void threadOpenTick().catch((err) => {
      void warn("thread-open tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopThreadOpenInterval() {
  if (threadOpenIntervalHandle !== null) {
    clearInterval(threadOpenIntervalHandle);
    threadOpenIntervalHandle = null;
  }
}
async function cancelThreadOpenLoop() {
  stopThreadOpenInterval();
  await browser.alarms.clear("thread-open-tick");
  const tabId = await getThreadOpenTabId();
  await setThreadOpenTabId(null);
  const sess = await getThreadOpenSession();
  await setThreadOpenSession(null);
  await info("thread-open loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function threadOpenTick() {
  let sess = await getThreadOpenSession();
  if (sess === null) {
    stopThreadOpenInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) return;
    await warn("thread-open: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await markThreadOpenSeen(sess.inflight.tweetId);
    await dequeueThreadOpen(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
  }
  const target = await nextThreadOpenTarget();
  if (!target) {
    stopThreadOpenInterval();
    await setThreadOpenTabId(null);
    await setThreadOpenSession(null);
    await info("thread-open loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await hasThreadOpenSeen(target.tweetId)) {
    await dequeueThreadOpen(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getThreadOpenTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id !== "number") throw new Error("created tab without id");
      tabId = tab.id;
      await setThreadOpenTabId(tabId);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    await markThreadOpenSeen(target.tweetId);
    sess = await getThreadOpenSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setThreadOpenSession(sess);
    if (tabId !== null) {
      void nudgeThreadOpenTab(tabId);
    }
    await info("thread-open tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await threadOpenQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("thread-open navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await markThreadOpenSeen(target.tweetId);
    await dequeueThreadOpen(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
  }
  await broadcastState();
}
async function nudgeThreadOpenTab(tabId) {
  await new Promise((resolve) => setTimeout(resolve, 1500));
  try {
    await browser.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        const step = () => window.scrollBy({ top: h * 1.3, behavior: "smooth" });
        step();
        setTimeout(step, 1400);
        setTimeout(step, 2800);
      }
    });
  } catch (err) {
    await warn("thread-open scroll-nudge failed", describeError(err));
  }
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    const checkWrite = force || isWriteAuthError(conn.error);
    if (branchOk && checkWrite) {
      await client.verifyWriteAccess();
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk,
      write_access: checkWrite ? "checked" : "not_checked"
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await refreshArchiveSnapshot(client, force);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function refreshArchiveSnapshot(client, force) {
  const text = await client.fetchRawText("data/manifest.json");
  if (!text) {
    await setArchiveSnapshot(null);
    if (force) await warn("archive manifest not found; old-tweet detection disabled");
    return;
  }
  try {
    const snapshot = parseArchiveSnapshot(JSON.parse(text));
    await setArchiveSnapshot(snapshot);
    if (force) {
      await info("archive snapshot refreshed", {
        accounts: Object.keys(snapshot.accounts).length,
        generated_at: snapshot.generated_at
      });
    }
  } catch (err) {
    await warn("archive snapshot parse failed; old-tweet detection disabled", describeError(err));
  }
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const threadOpenQueued = await threadOpenQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  const autoScrollSess = await getAutoScrollSession();
  const recentTweetSightings = await getRecentTweetSightings();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      ingestedNewCount: autoScrollSess?.ingestedNewCount ?? 0,
      ingestedExistingCount: autoScrollSess?.ingestedExistingCount ?? 0,
      skippedOldCount: autoScrollSess?.skippedOldCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    },
    threadOpenQueue: {
      total: threadOpenQueued,
      running: threadOpenIntervalHandle !== null,
      processed: threadOpenSess?.processed ?? 0,
      total_at_start: threadOpenSess?.totalAtStart ?? 0
    },
    recentTweetSightings
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    updateExisting: s.updateExisting,
    lowBandwidthBrowsing: s.lowBandwidthBrowsing,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function parseArchiveSnapshot(raw) {
  if (!raw || typeof raw !== "object") throw new Error("manifest is not an object");
  const manifest = raw;
  if (!Array.isArray(manifest.accounts)) throw new Error("manifest.accounts is not an array");
  const accounts = {};
  for (const entry of manifest.accounts) {
    if (!entry || typeof entry !== "object") continue;
    const row = entry;
    const handle = typeof row.handle === "string" ? row.handle : "";
    if (!handle || handle === "_misc") continue;
    const months = {};
    if (row.months && typeof row.months === "object") {
      for (const [k, v] of Object.entries(row.months)) {
        if (typeof v === "number") months[k] = v;
      }
    }
    accounts[handle.toLowerCase()] = {
      handle,
      first_post_at: typeof row.first_post_at === "string" ? row.first_post_at : null,
      latest_post_at: typeof row.latest_post_at === "string" ? row.latest_post_at : null,
      latest_capture_at: typeof row.latest_capture_at === "string" ? row.latest_capture_at : null,
      row_count: typeof row.row_count === "number" ? row.row_count : null,
      months
    };
  }
  return {
    generated_at: typeof manifest.generated_at === "string" ? manifest.generated_at : null,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    accounts
  };
}
function archiveSnapshotHasTweet(t, snapshot) {
  if (!snapshot) return false;
  const entry = snapshot.accounts[t.account_handle.toLowerCase()];
  if (!entry?.latest_post_at) return false;
  const posted = Date.parse(t.posted_at);
  const latest = Date.parse(entry.latest_post_at);
  return Number.isFinite(posted) && Number.isFinite(latest) && posted <= latest;
}
function buildTweetSighting(t, endpoint, seenAt, freshness = "new", action = "buffered") {
  return {
    tweet_id: t.tweet_id,
    account_handle: t.account_handle,
    posted_at: t.posted_at,
    text: t.text_resolved || t.text,
    tweet_type: t.tweet_type,
    tweet_url: t.tweet_url,
    seen_at: seenAt,
    endpoint,
    archive_status: freshness === "existing" ? "saved" : "new",
    action
  };
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop,
  threadOpenQueue: getThreadOpenQueue,
  startThreadOpen: startThreadOpenLoop,
  cancelThreadOpen: cancelThreadOpenLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIvZ2Fwcy50cyIsICIuLi9zcmMvbGliL3lhbWwudHMiLCAiLi4vc3JjL2JhY2tncm91bmQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgZW5hYmxlZDogdHJ1ZSxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxuICB1cGRhdGVFeGlzdGluZzogdHJ1ZSxcbiAgbG93QmFuZHdpZHRoQnJvd3Npbmc6IGZhbHNlLFxufTtcblxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01JTl9TRUMgPSAzO1xuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01BWF9TRUMgPSA2MDtcblxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcbi8vIHJlcG8gaGFzIGJlZW4gaW5pdGlhbGl6ZWQgb3IgUEFUIG1pc2NvbmZpZ3VyZWQpLiBLZXB0IGluIHN5bmMgd2l0aCB0aGUgZmlsZS5cbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdJQ0Vnb3YnLCBsYWJlbDogJ1UuUy4gSW1taWdyYXRpb24gYW5kIEN1c3RvbXMgRW5mb3JjZW1lbnQnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdXaGl0ZUhvdXNlJywgbGFiZWw6ICdUaGUgV2hpdGUgSG91c2UnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1VTRE9MJywgbGFiZWw6ICdVLlMuIERlcGFydG1lbnQgb2YgTGFib3InLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdTdGVwaGVuTScsIGxhYmVsOiAnU3RlcGhlbiBNaWxsZXInLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnR3JlZ29yeUtCb3Zpbm8nLCBsYWJlbDogJ0dyZWdvcnkgQm92aW5vJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1JlYWxUb21Ib21hbicsIGxhYmVsOiAnVGhvbWFzIEQuIEhvbWFuJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBjcnlwdG8udHMgXHUyMDE0IGF0LXJlc3QgZW5jcnlwdGlvbiBmb3Igc2Vuc2l0aXZlIHNldHRpbmdzICh0aGUgUEFUKS5cbiAqXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcbiAqIGZvcmdvdHRlbiBiYWNrdXAsIGEgbWlzY29uZmlndXJlZCBwcm9maWxlIHN5bmMpIHNob3VsZCBub3Qgc2VlIGEgdXNhYmxlXG4gKiBHaXRIdWIgUEFUIGluIHBsYWludGV4dC4gQSBkZXRlcm1pbmVkIGF0dGFja2VyIHdpdGggdGhlIGV4dGVuc2lvbidzIHNvdXJjZVxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcbiAqIGNvbmZpZGVudGlhbGl0eS4gVGhlIGFpbSBpcyB0byByYWlzZSB0aGUgYmFyIHNvIHRoZSBQQVQgaXNuJ3QgYSBjb3B5YWJsZVxuICogc3RyaW5nIHNpdHRpbmcgbmV4dCB0byBpdHMga2V5IG5hbWUgaW4gZXh0ZW5zaW9uIHN0b3JhZ2UuXG4gKlxuICogU2NoZW1lOlxuICogICAtIE9uIGZpcnN0IGVuY3J5cHRpb24gd2UgZ2VuZXJhdGUgYSAzMi1ieXRlIHNhbHQgYW5kIHBlcnNpc3QgaXQgaW5cbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxuICogICAtIFdlIGRlcml2ZSBhbiBBRVMtR0NNIGtleSBieSBTSEEtMjU2J2luZyBgc2FsdCB8fCBydW50aW1lLmlkIHx8IHZlcnNpb25cbiAqICAgICB8fCBcImltbS1hcmNoaXZlLXBhdC12MVwiYC4gVGhlIHNhbHQgYmVpbmcgcGVyLWluc3RhbGwgbWVhbnMgdHdvIGNvcGllc1xuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xuICogICAgIFVVSUQgXHUyMDE0IHN0YWJsZSBmb3IgYSBnaXZlbiBpbnN0YWxsIGJ1dCB1bmtub3duIHRvIGEgcmVtb3RlIGF0dGFja2VyLlxuICogICAtIFBsYWludGV4dCBpcyBlbmNyeXB0ZWQgd2l0aCBhIGZyZXNoIDEyLWJ5dGUgSVYuIFRoZSBlbnZlbG9wZSBmb3JtYXQgaXNcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXG4gKlxuICogQmFja3dhcmRzIGNvbXBhdGliaWxpdHk6IGFuIHVucHJlZml4ZWQgdmFsdWUgaXMgdHJlYXRlZCBhcyBsZWdhY3lcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cbiAqL1xuXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcbmNvbnN0IEVOVkVMT1BFX1BSRUZJWCA9ICd2MTonO1xuXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcbmxldCBkZXJpdmVkS2V5Q2FjaGVTYWx0OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcbiAgbGV0IHMgPSAnJztcbiAgZm9yIChjb25zdCBiIG9mIGJ1ZikgcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpO1xuICByZXR1cm4gYnRvYShzKTtcbn1cblxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcbiAgY29uc3QgYmluID0gYXRvYihzKTtcbiAgY29uc3Qgb3V0ID0gbmV3IFVpbnQ4QXJyYXkoYmluLmxlbmd0aCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcbiAgcmV0dXJuIG91dDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZE9yQ3JlYXRlU2FsdCgpOiBQcm9taXNlPHsgc2FsdEI2NDogc3RyaW5nOyBzYWx0OiBVaW50OEFycmF5IH0+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChTQUxUX1NUT1JBR0VfS0VZKTtcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4geyBzYWx0QjY0OiB2LCBzYWx0OiBmcm9tQmFzZTY0KHYpIH07XG4gIH1cbiAgY29uc3Qgc2FsdCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMzIpKTtcbiAgY29uc3Qgc2FsdEI2NCA9IHRvQmFzZTY0KHNhbHQpO1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xuICByZXR1cm4geyBzYWx0QjY0LCBzYWx0IH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGRlcml2ZUtleSgpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICBjb25zdCB7IHNhbHRCNjQsIHNhbHQgfSA9IGF3YWl0IGxvYWRPckNyZWF0ZVNhbHQoKTtcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XG4gICAgcmV0dXJuIGRlcml2ZWRLZXlDYWNoZTtcbiAgfVxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxuICAgIGAke2Jyb3dzZXIucnVudGltZS5pZH18JHticm93c2VyLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKS52ZXJzaW9ufXxpbW0tYXJjaGl2ZS1wYXQtdjFgXG4gICk7XG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XG4gIGNvbWJpbmVkLnNldChzZWVkLCAwKTtcbiAgY29tYmluZWQuc2V0KHNhbHQsIHNlZWQubGVuZ3RoKTtcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xuICBjb25zdCBrZXkgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgncmF3JywgaGFzaCwgeyBuYW1lOiAnQUVTLUdDTScgfSwgZmFsc2UsIFtcbiAgICAnZW5jcnlwdCcsXG4gICAgJ2RlY3J5cHQnLFxuICBdKTtcbiAgZGVyaXZlZEtleUNhY2hlID0ga2V5O1xuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcbiAgcmV0dXJuIGtleTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRW5jcnlwdGVkUGF0KHY6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gdi5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbmNyeXB0UGF0KHBsYWludGV4dDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcbiAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gIGNvbnN0IGl2ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxMikpO1xuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcbiAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXYgfSxcbiAgICBrZXksXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcbiAgKTtcbiAgcmV0dXJuIGAke0VOVkVMT1BFX1BSRUZJWH0ke3RvQmFzZTY0KGl2KX06JHt0b0Jhc2U2NChuZXcgVWludDhBcnJheShjdCkpfWA7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWNyeXB0UGF0KGVudmVsb3BlOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XG4gIC8vIExlZ2FjeSBwbGFpbnRleHQgKHByZS1lbmNyeXB0aW9uIGluc3RhbGxzKTogcGFzcyB0aHJvdWdoLiBUaGUgbmV4dCBzYXZlXG4gIC8vIHJlLWVuY3J5cHRzIGl0IHZpYSB0aGUgc3RvcmFnZSBsYXllci5cbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcbiAgY29uc3QgcGFydHMgPSBlbnZlbG9wZS5zbGljZShFTlZFTE9QRV9QUkVGSVgubGVuZ3RoKS5zcGxpdCgnOicpO1xuICBpZiAocGFydHMubGVuZ3RoICE9PSAyKSByZXR1cm4gJyc7XG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XG4gIGlmICghaXZCNjQgfHwgIWN0QjY0KSByZXR1cm4gJyc7XG4gIHRyeSB7XG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XG4gICAgY29uc3QgaXYgPSBmcm9tQmFzZTY0KGl2QjY0KTtcbiAgICBjb25zdCBjdCA9IGZyb21CYXNlNjQoY3RCNjQpO1xuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxuICAgICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2OiBpdiBhcyBCdWZmZXJTb3VyY2UgfSxcbiAgICAgIGtleSxcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxuICAgICk7XG4gICAgcmV0dXJuIG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShwdCk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiAnJztcbiAgfVxufVxuIiwgImltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIEZBTExCQUNLX0FDQ09VTlRTLCBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vY29uZmlnLmpzJztcbmltcG9ydCB7IGRlY3J5cHRQYXQsIGVuY3J5cHRQYXQsIGlzRW5jcnlwdGVkUGF0IH0gZnJvbSAnLi9jcnlwdG8uanMnO1xuaW1wb3J0IHR5cGUge1xuICBBY2NvdW50Q29uZmlnLFxuICBBY2NvdW50Q291bnRlcixcbiAgQXJjaGl2ZVNuYXBzaG90LFxuICBDYW5vbmljYWxUd2VldCxcbiAgQ29ubmVjdGlvblN0YXRlLFxuICBMb2dFdmVudCxcbiAgUmV0d2VldEVkZ2UsXG4gIFNldHRpbmdzLFxuICBUd2VldFNpZ2h0aW5nLFxuICBVbmF2YWlsYWJsZVR3ZWV0LFxufSBmcm9tICcuL3R5cGVzLmpzJztcblxuLyoqXG4gKiBCdWZmZXJlZCB0d2VldHMgZm9yIGEgZ2l2ZW4gYWNjb3VudCwgYXdhaXRpbmcgY29tbWl0LiBBIFwicnVuXCIgaXMgb25lIGVudHJ5XG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcbiAqIHN1cnZpdmVzIEpTT04gc2VyaWFsaXphdGlvbiB0aHJvdWdoIGJyb3dzZXIuc3RvcmFnZS5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xuICBydW5faWQ6IHN0cmluZztcbiAgYWNjb3VudF9oYW5kbGU6IHN0cmluZztcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xuICBsYXN0X2NhcHR1cmVfYXQ6IHN0cmluZztcbiAgdHdlZXRzX2J5X2lkOiBSZWNvcmQ8c3RyaW5nLCBDYW5vbmljYWxUd2VldD47XG4gIHVuYXZhaWxhYmxlX2J5X2lkPzogUmVjb3JkPHN0cmluZywgVW5hdmFpbGFibGVUd2VldD47XG4gIHJldHdlZXRfZWRnZXNfYnlfa2V5PzogUmVjb3JkPHN0cmluZywgUmV0d2VldEVkZ2U+O1xuICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IHN0cmluZ1tdO1xuICBlbmRwb2ludHNfc2Vlbjogc3RyaW5nW107XG4gIHNvdXJjZV91cmw6IHN0cmluZyB8IG51bGw7XG59XG5cbi8qKiBQZXItdHdlZXQgY29tbWl0dGVkLXN0YXRlIGluZGV4LCBrZXllZCBieSBoYW5kbGUgdGhlbiB0d2VldF9pZC5cbiAqIFVzZWQgdG8gc2tpcCByZS1jYXB0dXJpbmcgdHdlZXRzIHdlJ3ZlIGFscmVhZHkgcHVzaGVkIHdpdGggaWRlbnRpY2FsXG4gKiBlbmdhZ2VtZW50IGNvdW50cyBcdTIwMTQgYXZvaWRzIGdlbmVyYXRpbmcgb25lIG5ldyByYXcvKiBmaWxlIGV2ZXJ5IGJyb3dzZS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0dGVkRW50cnkge1xuICB0czogc3RyaW5nOyAvLyBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IGNvbW1pdFxuICBzaWc6IHN0cmluZzsgLy8gZW5nYWdlbWVudCBzaWduYXR1cmU6IFwibGlrZXxydHxyZXBseXxxdW90ZVwiXG59XG5cbi8qKiBQcm9ncmVzcyArIGluZmxpZ2h0IHRyYWNraW5nIGZvciBhIHF1ZXVlLWRyaXZlbiBsb29wIChyZWZldGNoIC8gbWVkaWEtY3Jhd2wpLlxuICogVGhlIGxvb3AgcGVyc2lzdHMgdGhpcyBzbyBhIFNXIGV2aWN0aW9uIGluIHRoZSBtaWRkbGUgb2YgYSBydW4gcHJlc2VydmVzXG4gKiBcIlggb2YgWSBwcm9jZXNzZWRcIiBcdTIwMTQgYW5kIHRoZSB3YWl0LWZvci1pbmdlc3QgZ3VhcmQga25vd3Mgd2hhdCB0byBleHBlY3QuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTG9vcFNlc3Npb24ge1xuICAvKiogSW5pdGlhbCBxdWV1ZSBzaXplIHdoZW4gdGhlIHVzZXIgY2xpY2tlZCBcIlN0YXJ0XCIuICovXG4gIHRvdGFsQXRTdGFydDogbnVtYmVyO1xuICAvKiogVHdlZXRzIHByb2Nlc3NlZCAoaW5nZXN0ZWQgT1IgZHJvcHBlZCBhZnRlciByZXRyaWVzKSBzbyBmYXIuICovXG4gIHByb2Nlc3NlZDogbnVtYmVyO1xuICAvKiogSVNPIG9mIHdoZW4gdGhpcyBzZXNzaW9uIHN0YXJ0ZWQuICovXG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xuICAvKiogVHdlZXQgY3VycmVudGx5IGluZmxpZ2h0IFx1MjAxNCB3ZSBuYXZpZ2F0ZWQgdG8gaXQgYW5kIGFyZSB3YWl0aW5nIGZvciB0aGVcbiAgICogcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIHJlc3BvbnNlIGJlZm9yZSBhZHZhbmNpbmcuIG51bGwgYmV0d2VlbiB0aWNrc1xuICAgKiAoYW5kIG9uY2UgYW4gaW5nZXN0IGhhcyBiZWVuIG9ic2VydmVkKS4gKi9cbiAgaW5mbGlnaHQ6IHsgdHdlZXRJZDogc3RyaW5nOyBuYXZpZ2F0ZWRBdDogc3RyaW5nIH0gfCBudWxsO1xufVxuXG4vKiogQXV0by1zY3JvbGwgc2Vzc2lvbjogY291bnRzIG9mIHRpY2tzIGFuZCB0d2VldHMgaW5nZXN0ZWQgc2luY2UgdGhlIHVzZXJcbiAqIGNsaWNrZWQgU3RhcnQuIFBlcnNpc3RlZCBzbyBTVyBldmljdGlvbiBkdXJpbmcgYSBydW4ga2VlcHMgcHJvZ3Jlc3MuICovXG5leHBvcnQgaW50ZXJmYWNlIEF1dG9TY3JvbGxTZXNzaW9uIHtcbiAgc3RhcnRlZEF0OiBzdHJpbmc7XG4gIHNjcm9sbENvdW50OiBudW1iZXI7XG4gIGluZ2VzdGVkQ291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWROZXdDb3VudDogbnVtYmVyO1xuICBpbmdlc3RlZEV4aXN0aW5nQ291bnQ6IG51bWJlcjtcbiAgc2tpcHBlZE9sZENvdW50OiBudW1iZXI7XG4gIGV4cGFuZGVkQ291bnQ6IG51bWJlcjtcbn1cblxuaW50ZXJmYWNlIFN0b3JhZ2VTaGFwZSB7XG4gIHNldHRpbmdzOiBTZXR0aW5ncztcbiAgYWNjb3VudHM6IEFjY291bnRDb25maWdbXTtcbiAgLyoqIElTTyB0aW1lc3RhbXAgb2YgdGhlIGxhc3Qgc3VjY2Vzc2Z1bCBhY2NvdW50cy55YW1sIGZldGNoIGZyb20gdGhlIHJlcG8uXG4gICAqIFVzZWQgYnkgYHJlZnJlc2hBY2NvdW50c0xpc3RgIHRvIHNraXAgcmUtZmV0Y2hpbmcgb24gZXZlcnkgU1cgd2FrZSBcdTIwMTQgdGhlXG4gICAqIGZpbGUgY2hhbmdlcyByYXJlbHkgYW5kIGFuIGF1dGhlbnRpY2F0ZWQgcmF3IGZldGNoIGV2ZXJ5IHdha2UgYWRkcyB1cC4gKi9cbiAgYWNjb3VudHNSZWZyZXNoZWRBdDogc3RyaW5nIHwgbnVsbDtcbiAgYXJjaGl2ZVNuYXBzaG90OiBBcmNoaXZlU25hcHNob3QgfCBudWxsO1xuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uU3RhdGU7XG4gIGNvdW50ZXJzOiBSZWNvcmQ8c3RyaW5nLCBBY2NvdW50Q291bnRlcj47XG4gIHJ1bkJ1ZmZlcnM6IFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj47XG4gIGFjdGl2aXR5OiBMb2dFdmVudFtdO1xuICByZWNlbnRUd2VldFNpZ2h0aW5nczogVHdlZXRTaWdodGluZ1tdO1xuICBjb21taXR0ZWRJbmRleDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PjtcbiAgLyoqIFR3ZWV0cyB0aGUgbm9ybWFsaXplciBmbGFnZ2VkIGFzIHRydW5jYXRlZCBhbmQgdGhhdCB3ZSBoYXZlbid0IHNlZW4gYVxuICAgKiBmdWxsLXRleHQgdmVyc2lvbiBvZiB5ZXQuIEtleWVkIGJ5IGhhbmRsZSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiAqL1xuICByZWZldGNoUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcbiAgLyoqIFR3ZWV0IElEcyBzZWVuIHZpYSBNZWRpYS10YWIgLyBwYXJ0aWFsIGNhcHR1cmVzIHRoYXQgY291bGRuJ3QgYmVcbiAgICogbm9ybWFsaXplZCBpbnRvIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIEtleWVkIGJ5IGhpbnQtaGFuZGxlIChvclxuICAgKiBcIl91bmtub3duXCIpIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuIFRoZSB1c2VyIGNhbiBkcml2ZSBhIGNyYXdsIHRoYXRcbiAgICogb3BlbnMgZWFjaCBkZXRhaWwgcGFnZSB0byBjYXB0dXJlIHRoZSByZWFsIHRoaW5nLiAqL1xuICBtZWRpYUNyYXdsUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcbiAgLyoqIENvcmUtYWNjb3VudCB0aHJlYWQgcm9vdHMgd29ydGggb3BlbmluZyBiZWNhdXNlIHRpbWVsaW5lL3NlYXJjaCB2aWV3cyBtYXlcbiAgICogb21pdCBsYXRlciBzZWxmLXJlcGxpZXMuIEtleWVkIGJ5IGhpbnQtaGFuZGxlIC0+IHJvb3QgdHdlZXQgaWRzLiAqL1xuICB0aHJlYWRPcGVuUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcbiAgLyoqIFJvb3QgdHdlZXQgaWRzIGFscmVhZHkgYXR0ZW1wdGVkIGJ5IHRoZSB0aHJlYWQtb3BlbmluZyB1dGlsaXR5LiAqL1xuICB0aHJlYWRPcGVuU2VlbjogUmVjb3JkPHN0cmluZywgc3RyaW5nPjtcbiAgcmVmZXRjaFNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcbiAgbWVkaWFDcmF3bFNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcbiAgdGhyZWFkT3BlblNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcbiAgYXV0b1Njcm9sbFNlc3Npb246IEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbDtcbn1cblxuY29uc3QgREVGQVVMVF9DT05ORUNUSU9OOiBDb25uZWN0aW9uU3RhdGUgPSB7XG4gIHN0YXR1czogJ3Vua25vd24nLFxuICBsb2dpbjogbnVsbCxcbiAgY2hlY2tlZEF0OiBudWxsLFxuICBlcnJvcjogbnVsbCxcbiAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbn07XG5cbmNvbnN0IERFRkFVTFRTOiBTdG9yYWdlU2hhcGUgPSB7XG4gIHNldHRpbmdzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MgfSxcbiAgYWNjb3VudHM6IFsuLi5GQUxMQkFDS19BQ0NPVU5UU10sXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IG51bGwsXG4gIGFyY2hpdmVTbmFwc2hvdDogbnVsbCxcbiAgY29ubmVjdGlvbjogeyAuLi5ERUZBVUxUX0NPTk5FQ1RJT04gfSxcbiAgY291bnRlcnM6IHt9LFxuICBydW5CdWZmZXJzOiB7fSxcbiAgYWN0aXZpdHk6IFtdLFxuICByZWNlbnRUd2VldFNpZ2h0aW5nczogW10sXG4gIGNvbW1pdHRlZEluZGV4OiB7fSxcbiAgcmVmZXRjaFF1ZXVlOiB7fSxcbiAgbWVkaWFDcmF3bFF1ZXVlOiB7fSxcbiAgdGhyZWFkT3BlblF1ZXVlOiB7fSxcbiAgdGhyZWFkT3BlblNlZW46IHt9LFxuICByZWZldGNoU2Vzc2lvbjogbnVsbCxcbiAgbWVkaWFDcmF3bFNlc3Npb246IG51bGwsXG4gIHRocmVhZE9wZW5TZXNzaW9uOiBudWxsLFxuICBhdXRvU2Nyb2xsU2Vzc2lvbjogbnVsbCxcbn07XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEspOiBQcm9taXNlPFN0b3JhZ2VTaGFwZVtLXT4ge1xuICBjb25zdCByZXN1bHQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KGtleSk7XG4gIGNvbnN0IHZhbHVlID0gcmVzdWx0W2tleV07XG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIHN0cnVjdHVyZWRDbG9uZShERUZBVUxUU1trZXldKTtcbiAgfVxuICByZXR1cm4gdmFsdWUgYXMgU3RvcmFnZVNoYXBlW0tdO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLLCB2YWx1ZTogU3RvcmFnZVNoYXBlW0tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBba2V5XTogdmFsdWUgfSk7XG59XG5cbi8vIC0tLSBTZXR0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gIC8vIEJhY2tmaWxsIGFueSBrZXlzIHRoZSB1c2VyJ3Mgc3RvcmVkIHNldHRpbmdzIHByZWRhdGUgXHUyMDE0IHJlYWRlcnMgY2FuIHJlbHlcbiAgLy8gb24gZXZlcnkgU2V0dGluZ3MgZmllbGQgYmVpbmcgcHJlc2VudCByYXRoZXIgdGhhbiBgPz8gZGVmYXVsdGluZ2AgYXRcbiAgLy8gZXZlcnkgY2FsbHNpdGUuIFRoZSBQQVQgaXMgc3RvcmVkIGVuY3J5cHRlZC1hdC1yZXN0IGFzIG9mIHYwLjIuMDsgd2VcbiAgLy8gZGVjcnlwdCB0cmFuc3BhcmVudGx5IHNvIGNhbGxlcnMgY29udGludWUgdG8gc2VlIHBsYWludGV4dC5cbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgZ2V0UmF3KCdzZXR0aW5ncycpO1xuICBjb25zdCBtZXJnZWQgPSB7IC4uLkRFRkFVTFRfU0VUVElOR1MsIC4uLnN0b3JlZCB9O1xuICBpZiAobWVyZ2VkLnBhdCAmJiBpc0VuY3J5cHRlZFBhdChtZXJnZWQucGF0KSkge1xuICAgIHRyeSB7XG4gICAgICBtZXJnZWQucGF0ID0gYXdhaXQgZGVjcnlwdFBhdChtZXJnZWQucGF0KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIG1lcmdlZC5wYXQgPSAnJztcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG1lcmdlZDtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBFbmNyeXB0IHRoZSBQQVQgYmVmb3JlIHBlcnNpc3Rpbmc7IGxlZ2FjeSBwbGFpbnRleHQgUEFUcyBnZXQgdXBncmFkZWRcbiAgLy8gb24gdGhlIG5leHQgc2F2ZS5cbiAgY29uc3QgdG9Xcml0ZTogU2V0dGluZ3MgPSB7IC4uLnMgfTtcbiAgaWYgKHRvV3JpdGUucGF0ICYmICFpc0VuY3J5cHRlZFBhdCh0b1dyaXRlLnBhdCkpIHtcbiAgICB0b1dyaXRlLnBhdCA9IGF3YWl0IGVuY3J5cHRQYXQodG9Xcml0ZS5wYXQpO1xuICB9XG4gIGF3YWl0IHNldFJhdygnc2V0dGluZ3MnLCB0b1dyaXRlKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVTZXR0aW5ncyhwYXRjaDogUGFydGlhbDxTZXR0aW5ncz4pOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IG5leHQgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYXdhaXQgc2V0U2V0dGluZ3MobmV4dCk7XG4gIHJldHVybiBuZXh0O1xufVxuXG4vLyAtLS0gQWNjb3VudHMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHMoKTogUHJvbWlzZTxBY2NvdW50Q29uZmlnW10+IHtcbiAgcmV0dXJuIGdldFJhdygnYWNjb3VudHMnKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50cyhhOiBBY2NvdW50Q29uZmlnW10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50cycsIGEpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzUmVmcmVzaGVkQXQoKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzUmVmcmVzaGVkQXQnKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KGlzbzogc3RyaW5nIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FjY291bnRzUmVmcmVzaGVkQXQnLCBpc28pO1xufVxuXG4vLyAtLS0gQXJjaGl2ZSBzbmFwc2hvdCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBcmNoaXZlU25hcHNob3QoKTogUHJvbWlzZTxBcmNoaXZlU25hcHNob3QgfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FyY2hpdmVTbmFwc2hvdCcpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXJjaGl2ZVNuYXBzaG90KHNuYXBzaG90OiBBcmNoaXZlU25hcHNob3QgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYXJjaGl2ZVNuYXBzaG90Jywgc25hcHNob3QpO1xufVxuXG4vLyAtLS0gQ29ubmVjdGlvbiBzdGF0ZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb25uZWN0aW9uKCk6IFByb21pc2U8Q29ubmVjdGlvblN0YXRlPiB7XG4gIGNvbnN0IGMgPSBhd2FpdCBnZXRSYXcoJ2Nvbm5lY3Rpb24nKTtcbiAgLy8gQmFja2ZpbGwgZmllbGRzIGFkZGVkIGFmdGVyIHRoZSB1c2VyJ3Mgc3RvcmFnZSB3YXMgd3JpdHRlbi5cbiAgY29uc3Qgb3V0OiBDb25uZWN0aW9uU3RhdGUgPSB7XG4gICAgLi4uYyxcbiAgICBkZWZhdWx0QnJhbmNoOiBjLmRlZmF1bHRCcmFuY2ggPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmRlZmF1bHRCcmFuY2gsXG4gICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czpcbiAgICAgIGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcbiAgICByYXRlTGltaXRSZXNldEF0OiBjLnJhdGVMaW1pdFJlc2V0QXQgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLnJhdGVMaW1pdFJlc2V0QXQsXG4gIH07XG4gIHJldHVybiBvdXQ7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0Q29ubmVjdGlvbihjOiBDb25uZWN0aW9uU3RhdGUpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdjb25uZWN0aW9uJywgYyk7XG59XG5cbi8vIC0tLSBDb3VudGVycyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmZ1bmN0aW9uIHRvZGF5SVNPKCk6IHN0cmluZyB7XG4gIHJldHVybiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q291bnRlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBBY2NvdW50Q291bnRlcj4+IHtcbiAgcmV0dXJuIGdldFJhdygnY291bnRlcnMnKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBidW1wQ291bnRlcihcbiAgaGFuZGxlOiBzdHJpbmcsXG4gIHBhdGNoOiBQYXJ0aWFsPEFjY291bnRDb3VudGVyPlxuKTogUHJvbWlzZTxBY2NvdW50Q291bnRlcj4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRDb3VudGVycygpO1xuICBjb25zdCBjdXIgPSBhbGxbaGFuZGxlXSA/PyB7XG4gICAgdG9kYXlDb3VudDogMCxcbiAgICB0b2RheURhdGU6IHRvZGF5SVNPKCksXG4gICAgbGFzdENhcHR1cmVBdDogbnVsbCxcbiAgICB0b3RhbENvbW1pdHRlZDogMCxcbiAgICBidWZmZXJlZENvdW50OiAwLFxuICB9O1xuICBpZiAoY3VyLnRvZGF5RGF0ZSAhPT0gdG9kYXlJU08oKSkge1xuICAgIGN1ci50b2RheURhdGUgPSB0b2RheUlTTygpO1xuICAgIGN1ci50b2RheUNvdW50ID0gMDtcbiAgfVxuICBjb25zdCBuZXh0OiBBY2NvdW50Q291bnRlciA9IHsgLi4uY3VyLCAuLi5wYXRjaCB9O1xuICBhbGxbaGFuZGxlXSA9IG5leHQ7XG4gIGF3YWl0IHNldFJhdygnY291bnRlcnMnLCBhbGwpO1xuICByZXR1cm4gbmV4dDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlOiBzdHJpbmcsIGNvdW50OiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnVtcENvdW50ZXIoaGFuZGxlLCB7IGJ1ZmZlcmVkQ291bnQ6IGNvdW50IH0pO1xufVxuXG4vLyAtLS0gUnVuIGJ1ZmZlcnMgKHRoZSBwZW5kaW5nIGNhcHR1cmVzIGF3YWl0aW5nIGNvbW1pdCkgLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5CdWZmZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgUnVuQnVmZmVyPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdydW5CdWZmZXJzJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPFJ1bkJ1ZmZlciB8IG51bGw+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICByZXR1cm4gYWxsW2hhbmRsZV0gPz8gbnVsbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZywgYnVmOiBSdW5CdWZmZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBhbGxbaGFuZGxlXSA9IGJ1ZjtcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyUnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgZGVsZXRlIGFsbFtoYW5kbGVdO1xuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xufVxuXG4vLyAtLS0gQWN0aXZpdHkgdGFpbCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWN0aXZpdHkoKTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FjdGl2aXR5Jyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcHBlbmRBY3Rpdml0eShldjogTG9nRXZlbnQpOiBQcm9taXNlPExvZ0V2ZW50W10+IHtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0QWN0aXZpdHkoKTtcbiAgY3VyLnVuc2hpZnQoZXYpO1xuICBpZiAoY3VyLmxlbmd0aCA+IEFDVElWSVRZX1RBSUxfTUFYKSBjdXIubGVuZ3RoID0gQUNUSVZJVFlfVEFJTF9NQVg7XG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBjdXIpO1xuICByZXR1cm4gY3VyO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJBY3Rpdml0eSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY3Rpdml0eScsIFtdKTtcbn1cblxuLy8gLS0tIFJlY2VudCB0d2VldCBzaWdodGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmNvbnN0IFJFQ0VOVF9UV0VFVF9TSUdIVElOR1NfTUFYID0gODA7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncygpOiBQcm9taXNlPFR3ZWV0U2lnaHRpbmdbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWNlbnRUd2VldFNpZ2h0aW5ncycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJlcGVuZFJlY2VudFR3ZWV0U2lnaHRpbmdzKHJvd3M6IFR3ZWV0U2lnaHRpbmdbXSk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAocm93cy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0UmVjZW50VHdlZXRTaWdodGluZ3MoKTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb25zdCBuZXh0OiBUd2VldFNpZ2h0aW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCByb3cgb2Ygcm93cykge1xuICAgIGNvbnN0IGtleSA9IGAke3Jvdy5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpfToke3Jvdy50d2VldF9pZH1gO1xuICAgIGlmIChzZWVuLmhhcyhrZXkpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChrZXkpO1xuICAgIG5leHQucHVzaChyb3cpO1xuICB9XG4gIGZvciAoY29uc3Qgcm93IG9mIGN1cikge1xuICAgIGNvbnN0IGtleSA9IGAke3Jvdy5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpfToke3Jvdy50d2VldF9pZH1gO1xuICAgIGlmIChzZWVuLmhhcyhrZXkpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChrZXkpO1xuICAgIG5leHQucHVzaChyb3cpO1xuICB9XG4gIG5leHQubGVuZ3RoID0gTWF0aC5taW4obmV4dC5sZW5ndGgsIFJFQ0VOVF9UV0VFVF9TSUdIVElOR1NfTUFYKTtcbiAgYXdhaXQgc2V0UmF3KCdyZWNlbnRUd2VldFNpZ2h0aW5ncycsIG5leHQpO1xufVxuXG4vLyAtLS0gQ29tbWl0dGVkLXR3ZWV0cyBkZWR1cCBpbmRleCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDb21taXR0ZWRJbmRleCgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj4+IHtcbiAgcmV0dXJuIGdldFJhdygnY29tbWl0dGVkSW5kZXgnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbW1pdHRlZEluZGV4KFxuICBpZHg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj5cbik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2NvbW1pdHRlZEluZGV4JywgaWR4KTtcbn1cblxuLyoqIENvbXB1dGUgdGhlIGVuZ2FnZW1lbnQgc2lnbmF0dXJlIHdlIHVzZSB0byBkZWNpZGUgd2hldGhlciBhIHJlLWNhcHR1cmVkXG4gKiB0d2VldCBpcyBcIm1hdGVyaWFsbHkgZGlmZmVyZW50XCIgZnJvbSB3aGF0IHdlIGxhc3QgY29tbWl0dGVkLiBXZSBvbWl0XG4gKiB2aWV3X2NvdW50IGJlY2F1c2UgaXQgdGlja3MgdXAgZnJlcXVlbnRseSBvbiBhY3RpdmUgdHdlZXRzIGFuZCB3b3VsZFxuICogZGVmZWF0IHRoZSBkZWR1cC4gTGlrZXMgLyBSVHMgLyByZXBsaWVzIC8gcXVvdGVzIGNoYW5nZSByYXJlbHkgZW5vdWdoIHRoYXRcbiAqIGVhY2ggY2hhbmdlIGlzIHdvcnRoIGEgcmUtY29tbWl0IChhbmQgYW4gZW5nYWdlbWVudF9oaXN0b3J5IHNuYXBzaG90KS5cbiAqIGBpc190cnVuY2F0ZWRgIGlzIGZvbGRlZCBpbiBzbyBhIHJlZmV0Y2ggdGhhdCBzd2FwcyB0aGUgMjgwLWNoYXIgaGVhZCBmb3JcbiAqIHRoZSBmdWxsIGBub3RlX3R3ZWV0YCBib2R5IGJ5cGFzc2VzIHRoZSBkZWR1cCBldmVuIHdoZW4gZW5nYWdlbWVudCBjb3VudHNcbiAqIGhhdmVuJ3QgbW92ZWQgXHUyMDE0IG90aGVyd2lzZSB0aGUgbmV3IGJvZHkgd291bGQgYmUgc2lsZW50bHkgZHJvcHBlZC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBlbmdhZ2VtZW50U2lnKFxuICBsaWtlczogbnVtYmVyLFxuICByZXR3ZWV0czogbnVtYmVyLFxuICByZXBsaWVzOiBudW1iZXIsXG4gIHF1b3RlczogbnVtYmVyLFxuICBpc1RydW5jYXRlZDogYm9vbGVhbiA9IGZhbHNlXG4pOiBzdHJpbmcge1xuICByZXR1cm4gYCR7bGlrZXN9fCR7cmV0d2VldHN9fCR7cmVwbGllc318JHtxdW90ZXN9fCR7aXNUcnVuY2F0ZWQgPyAndCcgOiAnZid9YDtcbn1cblxuLyoqIERyb3AgZW50cmllcyBvbGRlciB0aGFuIGBtYXhBZ2VNc2AuIFJldHVybnMgdGhlIG51bWJlciBwcnVuZWQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJ1bmVDb21taXR0ZWRJbmRleChtYXhBZ2VNczogbnVtYmVyKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgY29uc3QgY3V0b2ZmID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIG1heEFnZU1zKS50b0lTT1N0cmluZygpO1xuICBsZXQgcHJ1bmVkID0gMDtcbiAgZm9yIChjb25zdCBoYW5kbGUgb2YgT2JqZWN0LmtleXMoaWR4KSkge1xuICAgIGNvbnN0IGlubmVyID0gaWR4W2hhbmRsZV07XG4gICAgaWYgKCFpbm5lcikgY29udGludWU7XG4gICAgZm9yIChjb25zdCB0aWQgb2YgT2JqZWN0LmtleXMoaW5uZXIpKSB7XG4gICAgICBjb25zdCBlID0gaW5uZXJbdGlkXTtcbiAgICAgIGlmIChlICYmIGUudHMgPCBjdXRvZmYpIHtcbiAgICAgICAgZGVsZXRlIGlubmVyW3RpZF07XG4gICAgICAgIHBydW5lZCArPSAxO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoT2JqZWN0LmtleXMoaW5uZXIpLmxlbmd0aCA9PT0gMCkgZGVsZXRlIGlkeFtoYW5kbGVdO1xuICB9XG4gIGlmIChwcnVuZWQgPiAwKSBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xuICByZXR1cm4gcHJ1bmVkO1xufVxuXG4vLyAtLS0gUmVmZXRjaCBxdWV1ZSAodHdlZXRzIG5lZWRpbmcgZnVsbC10ZXh0IHJlY2FwdHVyZSkgLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hRdWV1ZSgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoUXVldWUnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlZmV0Y2hRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgbGV0IHRvdGFsID0gMDtcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcbiAgcmV0dXJuIHRvdGFsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXSA/PyBbXTtcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcbiAgICBpZHMucHVzaCh0d2VldElkKTtcbiAgICBxW2hhbmRsZV0gPSBpZHM7XG4gICAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZVJlZmV0Y2goaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXTtcbiAgaWYgKCFpZHMpIHJldHVybjtcbiAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xuICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtoYW5kbGVdO1xuICBlbHNlIHFbaGFuZGxlXSA9IGZpbHRlcmVkO1xuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dFJlZmV0Y2hUYXJnZXQoKTogUHJvbWlzZTx7XG4gIGhhbmRsZTogc3RyaW5nO1xuICB0d2VldElkOiBzdHJpbmc7XG59IHwgbnVsbD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgaGFuZGxlLCB0d2VldElkOiBpZHNbMF0hIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8vIC0tLSBNZWRpYS1jcmF3bCBxdWV1ZSAocGFydGlhbCBjYXB0dXJlcyBhd2FpdGluZyBkZXRhaWwtcGFnZSBmZXRjaCkgLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlTWVkaWFDcmF3bChoaW50SGFuZGxlOiBzdHJpbmcgfCBudWxsLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBjb25zdCBidWNrZXQgPSBoaW50SGFuZGxlID8/ICdfdW5rbm93bic7XG4gIGNvbnN0IGlkcyA9IHFbYnVja2V0XSA/PyBbXTtcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcbiAgICBpZHMucHVzaCh0d2VldElkKTtcbiAgICBxW2J1Y2tldF0gPSBpZHM7XG4gICAgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZU1lZGlhQ3Jhd2wodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgZm9yIChjb25zdCBidWNrZXQgb2YgT2JqZWN0LmtleXMocSkpIHtcbiAgICBjb25zdCBpZHMgPSBxW2J1Y2tldF07XG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcbiAgICBpZiAoZmlsdGVyZWQubGVuZ3RoICE9PSBpZHMubGVuZ3RoKSB7XG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2J1Y2tldF07XG4gICAgICBlbHNlIHFbYnVja2V0XSA9IGZpbHRlcmVkO1xuICAgIH1cbiAgfVxuICBpZiAoY2hhbmdlZCkgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRNZWRpYUNyYXdsVGFyZ2V0KCk6IFByb21pc2U8e1xuICBidWNrZXQ6IHN0cmluZztcbiAgdHdlZXRJZDogc3RyaW5nO1xufSB8IG51bGw+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBmb3IgKGNvbnN0IFtidWNrZXQsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGJ1Y2tldCwgdHdlZXRJZDogaWRzWzBdISB9O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vLyAtLS0gVGhyZWFkLW9wZW5pbmcgcXVldWUgKGNvcmUgY29udmVyc2F0aW9uIHJvb3RzIHRvIHZpc2l0KSAtLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUaHJlYWRPcGVuUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygndGhyZWFkT3BlblF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB0aHJlYWRPcGVuUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhc1RocmVhZE9wZW5TZWVuKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCBzZWVuID0gYXdhaXQgZ2V0UmF3KCd0aHJlYWRPcGVuU2VlbicpO1xuICByZXR1cm4gdHdlZXRJZCBpbiBzZWVuO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWFya1RocmVhZE9wZW5TZWVuKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZWVuID0gYXdhaXQgZ2V0UmF3KCd0aHJlYWRPcGVuU2VlbicpO1xuICBzZWVuW3R3ZWV0SWRdID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5TZWVuJywgc2Vlbik7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlVGhyZWFkT3BlbihoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChhd2FpdCBoYXNUaHJlYWRPcGVuU2Vlbih0d2VldElkKSkgcmV0dXJuO1xuICBjb25zdCBxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXSA/PyBbXTtcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcbiAgICBpZHMucHVzaCh0d2VldElkKTtcbiAgICBxW2hhbmRsZV0gPSBpZHM7XG4gICAgYXdhaXQgc2V0UmF3KCd0aHJlYWRPcGVuUXVldWUnLCBxKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVxdWV1ZVRocmVhZE9wZW4odHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgZm9yIChjb25zdCBidWNrZXQgb2YgT2JqZWN0LmtleXMocSkpIHtcbiAgICBjb25zdCBpZHMgPSBxW2J1Y2tldF07XG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcbiAgICBpZiAoZmlsdGVyZWQubGVuZ3RoICE9PSBpZHMubGVuZ3RoKSB7XG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcbiAgICAgIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2J1Y2tldF07XG4gICAgICBlbHNlIHFbYnVja2V0XSA9IGZpbHRlcmVkO1xuICAgIH1cbiAgfVxuICBpZiAoY2hhbmdlZCkgYXdhaXQgc2V0UmF3KCd0aHJlYWRPcGVuUXVldWUnLCBxKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRUaHJlYWRPcGVuVGFyZ2V0KCk6IFByb21pc2U8e1xuICBoYW5kbGU6IHN0cmluZztcbiAgdHdlZXRJZDogc3RyaW5nO1xufSB8IG51bGw+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGhhbmRsZSwgdHdlZXRJZDogaWRzWzBdISB9O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vKiogSGFzIHRoaXMgdHdlZXQgaWQgYWxyZWFkeSBiZWVuIGNvbW1pdHRlZCAoYW55IGhhbmRsZSk/IFVzZWQgdG8gc2tpcFxuICogZW5xdWV1ZWluZyBtZWRpYS1jcmF3bCB0YXJnZXRzIHdlJ3ZlIGFscmVhZHkgYXJjaGl2ZWQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNDb21taXR0ZWQodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGZvciAoY29uc3QgaW5uZXIgb2YgT2JqZWN0LnZhbHVlcyhpZHgpKSB7XG4gICAgaWYgKGlubmVyICYmIHR3ZWV0SWQgaW4gaW5uZXIpIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cblxuLy8gLS0tIExvb3Agc2Vzc2lvbiBzdGF0ZSAocHJvZ3Jlc3MgKyBpbmZsaWdodCBnYXRpbmcpIC0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSZWZldGNoU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFNlc3Npb24nLCBzKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUaHJlYWRPcGVuU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCd0aHJlYWRPcGVuU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFRocmVhZE9wZW5TZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5TZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTogUHJvbWlzZTxBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihzOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhdXRvU2Nyb2xsU2Vzc2lvbicsIHMpO1xufVxuXG4vLyAtLS0gUHVyZ2U6IHVucmVsYXRlZCBidWZmZXJzLCBjb3VudGVycywgcXVldWUgZW50cmllcyAtLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi8qKlxuICogRHJvcCBldmVyeSBwZXItaGFuZGxlIGJpdCBvZiBzdGF0ZSAoY291bnRlcnMsIHJ1biBidWZmZXIsIGNvbW1pdHRlZC1pbmRleFxuICogZW50cmllcywgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHF1ZXVlIGVudHJpZXMpIHRoYXQgZG9lc24ndCBjb3JyZXNwb25kIHRvIGFcbiAqIHRyYWNrZWQgYWNjb3VudC4gUmV0dXJucyBhIHN1bW1hcnkgZGVzY3JpYmluZyB3aGF0IHdhcyBjbGVhcmVkIHNvIHRoZVxuICogY2FsbGVyIGNhbiBsb2cgaXQuXG4gKlxuICogVHJhY2tlZCBhY2NvdW50cyBhcmUgcGFzc2VkIGluIChjYWxsZXIgcmVzb2x2ZXMgZnJvbSB0aGUgbGl2ZSBjb25maWcpLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHVyZ2VVbnJlbGF0ZWRTdGF0ZSh0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPik6IFByb21pc2U8e1xuICBjb3VudGVyc1JlbW92ZWQ6IG51bWJlcjtcbiAgYnVmZmVyc1JlbW92ZWQ6IG51bWJlcjtcbiAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQ6IG51bWJlcjtcbiAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XG4gIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkOiBudW1iZXI7XG4gIHRocmVhZE9wZW5JZHNSZW1vdmVkOiBudW1iZXI7XG59PiB7XG4gIGNvbnN0IHRhcmdMb3dlciA9IG5ldyBTZXQoWy4uLnRhcmdldGVkXS5tYXAoKGgpID0+IGgudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBpc1RhcmdldGVkID0gKGg6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGFyZ0xvd2VyLmhhcyhoLnRvTG93ZXJDYXNlKCkpO1xuXG4gIC8vIENvdW50ZXJzXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgbGV0IGNvdW50ZXJzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhjb3VudGVycykpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBjb3VudGVyc1toXTtcbiAgICAgIGNvdW50ZXJzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgY291bnRlcnMpO1xuXG4gIC8vIFJ1biBidWZmZXJzXG4gIGNvbnN0IGJ1ZmZlcnMgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGxldCBidWZmZXJzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhidWZmZXJzKSkge1xuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xuICAgICAgZGVsZXRlIGJ1ZmZlcnNbaF07XG4gICAgICBidWZmZXJzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBidWZmZXJzKTtcblxuICAvLyBDb21taXR0ZWQgZGVkdXAgaW5kZXhcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgbGV0IGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkID0gMDtcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBpZHhbaF07XG4gICAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xuXG4gIC8vIFJlZmV0Y2ggcXVldWU6IGJ1Y2tldHMgYXJlIGtleWVkIGJ5IGhhbmRsZS5cbiAgY29uc3QgcnEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgbGV0IHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhycSkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBycVtoXTtcbiAgICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCArPSAxO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHJxKTtcblxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogYnVja2V0cyBhcmUgaGludC1oYW5kbGVzIChvciBcIl91bmtub3duXCIpLiBEcm9wXG4gIC8vIGVudHJpZXMgd2hvc2UgYnVja2V0IGlzbid0IHRhcmdldGVkLCBidXQgS0VFUCBcIl91bmtub3duXCI6IHRob3NlIGFyZVxuICAvLyBjYXB0dXJlcyBhd2FpdGluZyBoYW5kbGUgcmVzb2x1dGlvbiBmb3IgbGF0ZXIgZnVsbC1kZXRhaWwgcmVjYXB0dXJlLCBzb1xuICAvLyBwdXJnaW5nIHRoZW0gd291bGQgc2lsZW50bHkgZGlzY2FyZCBwZW5kaW5nIHdvcmsuXG4gIGNvbnN0IG1xID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhtcSkpIHtcbiAgICBpZiAoaCAhPT0gJ191bmtub3duJyAmJiAhaXNUYXJnZXRlZChoKSkge1xuICAgICAgbWVkaWFDcmF3bElkc1JlbW92ZWQgKz0gKG1xW2hdID8/IFtdKS5sZW5ndGg7XG4gICAgICBkZWxldGUgbXFbaF07XG4gICAgfVxuICB9XG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgbXEpO1xuXG4gIGNvbnN0IHRxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XG4gIGxldCB0aHJlYWRPcGVuSWRzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyh0cSkpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIHRocmVhZE9wZW5JZHNSZW1vdmVkICs9ICh0cVtoXSA/PyBbXSkubGVuZ3RoO1xuICAgICAgZGVsZXRlIHRxW2hdO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3RocmVhZE9wZW5RdWV1ZScsIHRxKTtcblxuICByZXR1cm4ge1xuICAgIGNvdW50ZXJzUmVtb3ZlZCxcbiAgICBidWZmZXJzUmVtb3ZlZCxcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcbiAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQsXG4gICAgbWVkaWFDcmF3bElkc1JlbW92ZWQsXG4gICAgdGhyZWFkT3Blbklkc1JlbW92ZWQsXG4gIH07XG59XG5cbi8vIC0tLSBGdWxsIHJlc2V0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuY2xlYXIoKTtcbn1cbiIsICJpbXBvcnQgeyBhcHBlbmRBY3Rpdml0eSB9IGZyb20gJy4vc3RvcmFnZS5qcyc7XG5pbXBvcnQgdHlwZSB7IExvZ0V2ZW50LCBMb2dMZXZlbCB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5sZXQgYnJvYWRjYXN0OiAoKGV2OiBMb2dFdmVudCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldEJyb2FkY2FzdGVyKGZuOiAoZXY6IExvZ0V2ZW50KSA9PiB2b2lkKTogdm9pZCB7XG4gIGJyb2FkY2FzdCA9IGZuO1xufVxuXG5mdW5jdGlvbiBub3dJU08oKTogc3RyaW5nIHtcbiAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW1pdChsZXZlbDogTG9nTGV2ZWwsIG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBldjogTG9nRXZlbnQgPSB7IHRzOiBub3dJU08oKSwgbGV2ZWwsIG1zZywgY29udGV4dDogcmVkYWN0KGNvbnRleHQpIH07XG4gIC8vIENvbnNvbGUgZm9yIGRldnRvb2xzLlxuICBjb25zdCBsaW5lID0gYFtpbW0tYXJjaGl2ZV0gJHtsZXZlbC50b1VwcGVyQ2FzZSgpfSAke21zZ31gO1xuICBpZiAobGV2ZWwgPT09ICdlcnJvcicpIGNvbnNvbGUuZXJyb3IobGluZSwgZXYuY29udGV4dCk7XG4gIGVsc2UgaWYgKGxldmVsID09PSAnd2FybicpIGNvbnNvbGUud2FybihsaW5lLCBldi5jb250ZXh0KTtcbiAgZWxzZSBjb25zb2xlLmxvZyhsaW5lLCBldi5jb250ZXh0KTtcbiAgLy8gUGVyc2lzdGVudCB0YWlsLlxuICB0cnkge1xuICAgIGF3YWl0IGFwcGVuZEFjdGl2aXR5KGV2KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGZhaWxlZCB0byBhcHBlbmQgYWN0aXZpdHknLCBlcnIpO1xuICB9XG4gIC8vIExpdmUgYnJvYWRjYXN0IChlLmcuIHRvIHNpZGViYXIpLlxuICB0cnkge1xuICAgIGJyb2FkY2FzdD8uKGV2KTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gU2lkZWJhciBtYXkgbm90IGJlIG9wZW47IHRoYXQncyBmaW5lLlxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbmZvKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCdpbmZvJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB3YXJuKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiBlbWl0KCd3YXJuJywgbXNnLCBjb250ZXh0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlcnJvcihtc2c6IHN0cmluZywgY29udGV4dDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fSk6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gZW1pdCgnZXJyb3InLCBtc2csIGNvbnRleHQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmVFcnJvcihlcnI6IHVua25vd24pOiB7IG1lc3NhZ2U6IHN0cmluZzsgc3RhY2s6IHN0cmluZyB8IG51bGwgfSB7XG4gIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IGVyci5tZXNzYWdlLCBzdGFjazogZXJyLnN0YWNrID8/IG51bGwgfTtcbiAgfVxuICB0cnkge1xuICAgIHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyhlcnIpLCBzdGFjazogbnVsbCB9O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4geyBtZXNzYWdlOiAnPHVucHJpbnRhYmxlIGVycm9yPicsIHN0YWNrOiBudWxsIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTdHJpcCBhbnl0aGluZyB0aGF0IGxvb2tzIGxpa2UgYSBQQVQgb3Igb3RoZXIgbG9uZyBzZWNyZXQgZnJvbSBhIGNvbnRleHRcbiAqIG9iamVjdCBiZWZvcmUgcGVyc2lzdGluZyBpdC4gRGVmZW5zaXZlOiBjYWxsZXJzIHNob3VsZCBub3QgbG9nIHRva2VucywgYnV0XG4gKiBpZiB0aGV5IHNsaXAgdGhyb3VnaCB3ZSB3YW50IHRvIHJlZGFjdCB0aGVtLlxuICovXG5mdW5jdGlvbiByZWRhY3QoY3R4OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgY29uc3Qgb3V0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhjdHgpKSB7XG4gICAgaWYgKGsudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygndG9rZW4nKSB8fCBrLnRvTG93ZXJDYXNlKCkgPT09ICdwYXQnIHx8IGsgPT09ICdhdXRob3JpemF0aW9uJykge1xuICAgICAgb3V0W2tdID0gJzxyZWRhY3RlZD4nO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIC9naXRodWJfcGF0X1tBLVphLXowLTlfXXszMCx9Ly50ZXN0KHYpKSB7XG4gICAgICBvdXRba10gPSB2LnJlcGxhY2UoL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dKy9nLCAnZ2l0aHViX3BhdF88cmVkYWN0ZWQ+Jyk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiA0MDk2KSB7XG4gICAgICBvdXRba10gPSBgJHt2LnNsaWNlKDAsIDQwOTYpfVx1MjAyNjx0cnVuY2F0ZWQ+YDtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0W2tdID0gdjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cbiIsICJpbXBvcnQgeyBkZXNjcmliZUVycm9yIH0gZnJvbSAnLi9sb2dnZXIuanMnO1xuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xuXG5jb25zdCBBUElfQkFTRSA9ICdodHRwczovL2FwaS5naXRodWIuY29tJztcbmNvbnN0IFJBV19CQVNFID0gJ2h0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZU9wdGlvbnMge1xuICBwYXRoOiBzdHJpbmc7XG4gIGNvbnRlbnRCYXNlNjQ6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBleHBlY3RlZFNoYT86IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZVJlc3VsdCB7XG4gIHBhdGg6IHN0cmluZztcbiAgc2hhOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdEZpbGVPcHRpb25zIHtcbiAgcGF0aDogc3RyaW5nO1xuICBjb250ZW50QmFzZTY0OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZXNPcHRpb25zIHtcbiAgZmlsZXM6IENvbW1pdEZpbGVPcHRpb25zW107XG4gIG1lc3NhZ2U6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb21taXRGaWxlc1Jlc3VsdCB7XG4gIGNvbW1pdFNoYTogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbiAgZmlsZXM6IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgY2xhc3MgR2l0SHViRXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIHN0YXR1czogbnVtYmVyO1xuICBib2R5OiB1bmtub3duO1xuICByZXRyaWFibGU6IGJvb2xlYW47XG4gIGNhdGVnb3J5OiAnYXV0aCcgfCAncmF0ZS1saW1pdCcgfCAnY29uZmxpY3QnIHwgJ25vdC1mb3VuZCcgfCAnc2VydmVyJyB8ICduZXR3b3JrJyB8ICd1bmtub3duJztcbiAgLyoqIFdoZW4gdGhlIEdpdEh1YiByYXRlLWxpbWl0IHdpbmRvdyBmb3IgdGhpcyB0b2tlbiByZXNldHMsIGFzIGEgVW5peFxuICAgKiBlcG9jaCBpbiBzZWNvbmRzLiBQb3B1bGF0ZWQgZnJvbSBgWC1SYXRlTGltaXQtUmVzZXRgIG9uIDQwMy80MjksIG9yXG4gICAqIGRlcml2ZWQgZnJvbSBgUmV0cnktQWZ0ZXJgIGZvciBzZWNvbmRhcnkgbGltaXRzLiBudWxsIHdoZW4gdW5rbm93bi4gKi9cbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVtYmVyIHwgbnVsbDtcblxuICBjb25zdHJ1Y3RvcihvcHRzOiB7XG4gICAgc3RhdHVzOiBudW1iZXI7XG4gICAgYm9keTogdW5rbm93bjtcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgcmV0cmlhYmxlOiBib29sZWFuO1xuICAgIGNhdGVnb3J5OiBHaXRIdWJFcnJvclsnY2F0ZWdvcnknXTtcbiAgICByYXRlTGltaXRSZXNldEF0PzogbnVtYmVyIHwgbnVsbDtcbiAgfSkge1xuICAgIHN1cGVyKG9wdHMubWVzc2FnZSk7XG4gICAgdGhpcy5uYW1lID0gJ0dpdEh1YkVycm9yJztcbiAgICB0aGlzLnN0YXR1cyA9IG9wdHMuc3RhdHVzO1xuICAgIHRoaXMuYm9keSA9IG9wdHMuYm9keTtcbiAgICB0aGlzLnJldHJpYWJsZSA9IG9wdHMucmV0cmlhYmxlO1xuICAgIHRoaXMuY2F0ZWdvcnkgPSBvcHRzLmNhdGVnb3J5O1xuICAgIHRoaXMucmF0ZUxpbWl0UmVzZXRBdCA9IG9wdHMucmF0ZUxpbWl0UmVzZXRBdCA/PyBudWxsO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBHaXRIdWJDbGllbnQge1xuICBwcml2YXRlIHJlYWRvbmx5IHNldHRpbmdzOiBTZXR0aW5ncztcblxuICBjb25zdHJ1Y3RvcihzZXR0aW5nczogU2V0dGluZ3MpIHtcbiAgICB0aGlzLnNldHRpbmdzID0gc2V0dGluZ3M7XG4gIH1cblxuICAvKiogUmV0dXJucyB0aGUgYXV0aGVudGljYXRlZCB1c2VyJ3MgbG9naW4uIFRocm93cyBvbiBhdXRoIGZhaWx1cmUuICovXG4gIGFzeW5jIHdob2FtaSgpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICByZXR1cm4gKHJlcyBhcyB7IGxvZ2luPzogc3RyaW5nIH0pLmxvZ2luID8/ICc8dW5rbm93bj4nO1xuICB9XG5cbiAgLyoqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZ2l2ZW4gYnJhbmNoIGV4aXN0cyBvbiB0aGUgY29uZmlndXJlZCByZXBvLiAqL1xuICBhc3luYyBicmFuY2hFeGlzdHMoYnJhbmNoOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICdHRVQnLFxuICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2JyYW5jaGVzLyR7ZW5jb2RlVVJJQ29tcG9uZW50KGJyYW5jaCl9YFxuICAgICAgKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGVyci5jYXRlZ29yeSA9PT0gJ25vdC1mb3VuZCcpIHJldHVybiBmYWxzZTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKiogVmVyaWZpZXMgdGhlIFBBVCBjYW4gc2VlIHRoZSBjb25maWd1cmVkIHJlcG8uICovXG4gIGFzeW5jIHZlcmlmeVJlcG9BY2Nlc3MoKTogUHJvbWlzZTx7IGxvZ2luOiBzdHJpbmc7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH0+IHtcbiAgICBjb25zdCBtZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcbiAgICBjb25zdCByZXBvID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb31gKTtcbiAgICBjb25zdCByID0gcmVwbyBhcyB7IGZ1bGxfbmFtZTogc3RyaW5nOyBkZWZhdWx0X2JyYW5jaDogc3RyaW5nIH07XG4gICAgcmV0dXJuIHtcbiAgICAgIGxvZ2luOiAobWUgYXMgeyBsb2dpbjogc3RyaW5nIH0pLmxvZ2luLFxuICAgICAgZnVsbF9uYW1lOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogVmVyaWZ5IHRoZSBQQVQgY2FuIHdyaXRlIHRvIHRoZSBjb25maWd1cmVkIGJyYW5jaCB3aXRob3V0IGNyZWF0aW5nIGFcbiAgICogY29tbWl0LiBNb3ZpbmcgYSByZWYgdG8gaXRzIGN1cnJlbnQgU0hBIGlzIGEgbm8tb3AsIGJ1dCBHaXRIdWIgc3RpbGxcbiAgICogZW5mb3JjZXMgdGhlIENvbnRlbnRzOiBXcml0ZSBwZXJtaXNzaW9uIHJlcXVpcmVkIGJ5IGNvbW1pdEZpbGVzKCkuXG4gICAqL1xuICBhc3luYyB2ZXJpZnlXcml0ZUFjY2VzcygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XG4gICAgYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAnUEFUQ0gnLFxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXG4gICAgICB7XG4gICAgICAgIHNoYTogaGVhZC5zaGEsXG4gICAgICAgIGZvcmNlOiBmYWxzZSxcbiAgICAgIH1cbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIEZldGNoIGEgdGV4dCBmaWxlIGZyb20gcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSBhdXRoZW50aWNhdGVkIHdpdGggdGhlXG4gICAqIFBBVC4gUmV0dXJucyBudWxsIGlmIHRoZSBmaWxlIGRvZXNuJ3QgZXhpc3QuIFVzZWQgZm9yIGNvbmZpZy9hY2NvdW50cy55YW1sLlxuICAgKi9cbiAgYXN5bmMgZmV0Y2hSYXdUZXh0KHBhdGhJblJlcG86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IHVybCA9IGAke1JBV19CQVNFfS8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS8ke3RoaXMuc2V0dGluZ3MuYnJhbmNofS8ke3BhdGhJblJlcG99YDtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgIG1ldGhvZDogJ0dFVCcsXG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLnNldHRpbmdzLnBhdH1gIH0sXG4gICAgfSk7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkgcmV0dXJuIG51bGw7XG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yKHJlcywgYEdFVCByYXcgJHtwYXRoSW5SZXBvfWApO1xuICAgIHJldHVybiByZXMudGV4dCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIExvb2sgdXAgYW4gZXhpc3RpbmcgZmlsZSdzIFNIQSB2aWEgdGhlIENvbnRlbnRzIEFQSSwgb3IgbnVsbCBpZiBub3QgZm91bmQuXG4gICAqIFVzZWQgd2hlbiByZXRyeWluZyBhIFBVVCBhZnRlciBhIDQyMiBzaGEgbWlzbWF0Y2guXG4gICAqL1xuICBhc3luYyBnZXRGaWxlU2hhKHBhdGg6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vY29udGVudHMvJHtlbmNvZGVQYXRoKHBhdGgpfT9yZWY9JHtlbmNvZGVVUklDb21wb25lbnQodGhpcy5zZXR0aW5ncy5icmFuY2gpfWBcbiAgICAgICk7XG4gICAgICBjb25zdCByID0gcmVzIGFzIHsgc2hhPzogc3RyaW5nIH07XG4gICAgICByZXR1cm4gci5zaGEgPz8gbnVsbDtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gbnVsbDtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUFVUIGEgZmlsZSB0byB0aGUgcmVwby4gSGFuZGxlcyA0MjIgKHNoYSByZXF1aXJlZCkgYnkgcmUtZmV0Y2hpbmcgdGhlXG4gICAqIGV4aXN0aW5nIHNoYSBhbmQgcmV0cnlpbmcgb25jZS4gUmV0cmllcyBuZXR3b3JrIC8gNXh4IC8gcmF0ZS1saW1pdCBlcnJvcnNcbiAgICogd2l0aCBleHBvbmVudGlhbCBiYWNrb2ZmIHVwIHRvIG1heEF0dGVtcHRzLlxuICAgKi9cbiAgYXN5bmMgcHV0RmlsZShvcHRzOiBQdXRGaWxlT3B0aW9ucyk6IFByb21pc2U8UHV0RmlsZVJlc3VsdD4ge1xuICAgIGNvbnN0IHBhdGggPSBvcHRzLnBhdGg7XG4gICAgY29uc3QgdXJsID0gYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9YDtcbiAgICBsZXQgc2hhOiBzdHJpbmcgfCBudWxsID0gb3B0cy5leHBlY3RlZFNoYSA/PyBudWxsO1xuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAxOyBhdHRlbXB0IDw9IG1heEF0dGVtcHRzOyBhdHRlbXB0KyspIHtcbiAgICAgIGNvbnN0IGJvZHk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge1xuICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXG4gICAgICAgIGNvbnRlbnQ6IG9wdHMuY29udGVudEJhc2U2NCxcbiAgICAgICAgYnJhbmNoOiB0aGlzLnNldHRpbmdzLmJyYW5jaCxcbiAgICAgIH07XG4gICAgICBpZiAoc2hhKSBib2R5LnNoYSA9IHNoYTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdQVVQnLCB1cmwsIGJvZHkpO1xuICAgICAgICBjb25zdCBvdXQgPSByZXMgYXMgeyBjb250ZW50OiB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nOyBwYXRoOiBzdHJpbmcgfSB9O1xuICAgICAgICByZXR1cm4geyBwYXRoOiBvdXQuY29udGVudC5wYXRoLCBzaGE6IG91dC5jb250ZW50LnNoYSwgdXJsOiBvdXQuY29udGVudC5odG1sX3VybCB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xuICAgICAgICBpZiAoZXJyLnN0YXR1cyA9PT0gNDIyICYmICFzaGEpIHtcbiAgICAgICAgICAvLyBGaWxlIGFscmVhZHkgZXhpc3RzOyBmZXRjaCBpdHMgc2hhIGFuZCByZXRyeSBvbmNlLlxuICAgICAgICAgIHNoYSA9IGF3YWl0IHRoaXMuZ2V0RmlsZVNoYShwYXRoKTtcbiAgICAgICAgICBpZiAoIXNoYSkgdGhyb3cgZXJyO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICghZXJyLnJldHJpYWJsZSB8fCBhdHRlbXB0ID09PSBtYXhBdHRlbXB0cykgdGhyb3cgZXJyO1xuICAgICAgICBhd2FpdCBzbGVlcChiYWNrb2ZmTXMoYXR0ZW1wdCwgZXJyKSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihgcHV0RmlsZTogZXhoYXVzdGVkIGF0dGVtcHRzIGZvciAke3BhdGh9YCk7XG4gIH1cblxuICAvKipcbiAgICogQ29tbWl0IHNldmVyYWwgZmlsZXMgd2l0aCBvbmUgYnJhbmNoIHVwZGF0ZS4gVGhlIENvbnRlbnRzIEFQSSBjcmVhdGVzIG9uZVxuICAgKiBjb21taXQgcGVyIFBVVCwgc28gcmFwaWQgZmx1c2hlcyByYWNlIGVhY2ggb3RoZXIgb24gdGhlIGJyYW5jaCBoZWFkLiBUaGlzXG4gICAqIHVzZXMgdGhlIGxvd2VyLWxldmVsIEdpdCBEYXRhIEFQSSBpbnN0ZWFkOiB1cGxvYWQgYmxvYnMsIGJ1aWxkIGEgdHJlZSxcbiAgICogY3JlYXRlIG9uZSBjb21taXQsIHRoZW4gbW92ZSB0aGUgYnJhbmNoIHJlZiBvbmNlLiBJZiBhbm90aGVyIHdyaXRlciBtb3Zlc1xuICAgKiB0aGUgYnJhbmNoIGZpcnN0LCByZWJhc2UgdGhpcyB0cmVlIHBhdGNoIG9udG8gdGhlIGxhdGVzdCBoZWFkIGFuZCByZXRyeS5cbiAgICovXG4gIGFzeW5jIGNvbW1pdEZpbGVzKG9wdHM6IENvbW1pdEZpbGVzT3B0aW9ucyk6IFByb21pc2U8Q29tbWl0RmlsZXNSZXN1bHQ+IHtcbiAgICBpZiAob3B0cy5maWxlcy5sZW5ndGggPT09IDApIHRocm93IG5ldyBFcnJvcignY29tbWl0RmlsZXM6IG5vIGZpbGVzIHRvIGNvbW1pdCcpO1xuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcbiAgICBsZXQgbGFzdEVycjogdW5rbm93biA9IG51bGw7XG5cbiAgICBmb3IgKGxldCBhdHRlbXB0ID0gMTsgYXR0ZW1wdCA8PSBtYXhBdHRlbXB0czsgYXR0ZW1wdCsrKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBibG9icyA9IGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgICAgIG9wdHMuZmlsZXMubWFwKGFzeW5jIChmaWxlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBvdXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9ibG9ic2AsXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBjb250ZW50OiBmaWxlLmNvbnRlbnRCYXNlNjQsXG4gICAgICAgICAgICAgICAgZW5jb2Rpbmc6ICdiYXNlNjQnLFxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgcGF0aDogZmlsZS5wYXRoLFxuICAgICAgICAgICAgICBzaGE6IChvdXQgYXMgeyBzaGE6IHN0cmluZyB9KS5zaGEsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH0pXG4gICAgICAgICk7XG5cbiAgICAgICAgY29uc3QgaGVhZCA9IGF3YWl0IHRoaXMuZ2V0QnJhbmNoSGVhZCgpO1xuICAgICAgICBjb25zdCB0cmVlID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXG4gICAgICAgICAgJ1BPU1QnLFxuICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L3RyZWVzYCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBiYXNlX3RyZWU6IGhlYWQudHJlZVNoYSxcbiAgICAgICAgICAgIHRyZWU6IGJsb2JzLm1hcCgoYmxvYikgPT4gKHtcbiAgICAgICAgICAgICAgcGF0aDogYmxvYi5wYXRoLFxuICAgICAgICAgICAgICBtb2RlOiAnMTAwNjQ0JyxcbiAgICAgICAgICAgICAgdHlwZTogJ2Jsb2InLFxuICAgICAgICAgICAgICBzaGE6IGJsb2Iuc2hhLFxuICAgICAgICAgICAgfSkpLFxuICAgICAgICAgIH1cbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgdHJlZVNoYSA9ICh0cmVlIGFzIHsgc2hhOiBzdHJpbmcgfSkuc2hhO1xuICAgICAgICBjb25zdCBjb21taXQgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICAgICAnUE9TVCcsXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvY29tbWl0c2AsXG4gICAgICAgICAge1xuICAgICAgICAgICAgbWVzc2FnZTogb3B0cy5tZXNzYWdlLFxuICAgICAgICAgICAgdHJlZTogdHJlZVNoYSxcbiAgICAgICAgICAgIHBhcmVudHM6IFtoZWFkLnNoYV0sXG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICBjb25zdCBjb21taXRPdXQgPSBjb21taXQgYXMgeyBzaGE6IHN0cmluZzsgaHRtbF91cmw6IHN0cmluZyB9O1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgICAgICAgJ1BBVENIJyxcbiAgICAgICAgICAgIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb30vZ2l0L3JlZnMvaGVhZHMvJHtlbmNvZGVQYXRoKHRoaXMuc2V0dGluZ3MuYnJhbmNoKX1gLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaGE6IGNvbW1pdE91dC5zaGEsXG4gICAgICAgICAgICAgIGZvcmNlOiBmYWxzZSxcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBpZiAoaXNDb25mbGljdChlcnIpICYmIGF0dGVtcHQgPCBtYXhBdHRlbXB0cykge1xuICAgICAgICAgICAgbGFzdEVyciA9IGVycjtcbiAgICAgICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBjb21taXRTaGE6IGNvbW1pdE91dC5zaGEsXG4gICAgICAgICAgdXJsOiBjb21taXRPdXQuaHRtbF91cmwsXG4gICAgICAgICAgZmlsZXM6IG9wdHMuZmlsZXMubWFwKChmaWxlKSA9PiBmaWxlLnBhdGgpLFxuICAgICAgICB9O1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGxhc3RFcnIgPSBlcnI7XG4gICAgICAgIGlmICghKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSkgdGhyb3cgZXJyO1xuICAgICAgICBpZiAoKCFlcnIucmV0cmlhYmxlICYmICFpc0NvbmZsaWN0KGVycikpIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XG4gICAgICAgIGF3YWl0IHNsZWVwKGJhY2tvZmZNcyhhdHRlbXB0LCBlcnIpKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhyb3cgbGFzdEVyciBpbnN0YW5jZW9mIEVycm9yID8gbGFzdEVyciA6IG5ldyBFcnJvcignY29tbWl0RmlsZXM6IGV4aGF1c3RlZCBhdHRlbXB0cycpO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBnZXRCcmFuY2hIZWFkKCk6IFByb21pc2U8eyBzaGE6IHN0cmluZzsgdHJlZVNoYTogc3RyaW5nIH0+IHtcbiAgICBjb25zdCByZWYgPSBhd2FpdCB0aGlzLmZldGNoSnNvbihcbiAgICAgICdHRVQnLFxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmL2hlYWRzLyR7ZW5jb2RlUGF0aCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxuICAgICk7XG4gICAgY29uc3QgaGVhZFNoYSA9IChyZWYgYXMgeyBvYmplY3Q6IHsgc2hhOiBzdHJpbmcgfSB9KS5vYmplY3Quc2hhO1xuICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxuICAgICAgJ0dFVCcsXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9jb21taXRzLyR7aGVhZFNoYX1gXG4gICAgKTtcbiAgICByZXR1cm4ge1xuICAgICAgc2hhOiBoZWFkU2hhLFxuICAgICAgdHJlZVNoYTogKGNvbW1pdCBhcyB7IHRyZWU6IHsgc2hhOiBzdHJpbmcgfSB9KS50cmVlLnNoYSxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBmZXRjaEpzb24obWV0aG9kOiBzdHJpbmcsIHBhdGg6IHN0cmluZywgYm9keT86IHVua25vd24pOiBQcm9taXNlPHVua25vd24+IHtcbiAgICBjb25zdCB1cmwgPSBwYXRoLnN0YXJ0c1dpdGgoJ2h0dHAnKSA/IHBhdGggOiBgJHtBUElfQkFTRX0ke3BhdGh9YDtcbiAgICBjb25zdCBpbml0OiBSZXF1ZXN0SW5pdCA9IHtcbiAgICAgIG1ldGhvZCxcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAsXG4gICAgICAgIEFjY2VwdDogJ2FwcGxpY2F0aW9uL3ZuZC5naXRodWIranNvbicsXG4gICAgICAgICdYLUdpdEh1Yi1BcGktVmVyc2lvbic6ICcyMDIyLTExLTI4JyxcbiAgICAgICAgLi4uKGJvZHkgPyB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSA6IHt9KSxcbiAgICAgIH0sXG4gICAgICAuLi4oYm9keSA/IHsgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSkgfSA6IHt9KSxcbiAgICB9O1xuICAgIGxldCByZXM6IFJlc3BvbnNlO1xuICAgIHRyeSB7XG4gICAgICByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIGluaXQpO1xuICAgIH0gY2F0Y2ggKG5ldEVycikge1xuICAgICAgdGhyb3cgbmV3IEdpdEh1YkVycm9yKHtcbiAgICAgICAgc3RhdHVzOiAwLFxuICAgICAgICBib2R5OiBudWxsLFxuICAgICAgICBtZXNzYWdlOiBgbmV0d29yazogJHtkZXNjcmliZUVycm9yKG5ldEVycikubWVzc2FnZX1gLFxuICAgICAgICByZXRyaWFibGU6IHRydWUsXG4gICAgICAgIGNhdGVnb3J5OiAnbmV0d29yaycsXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDIwNCkgcmV0dXJuIG51bGw7XG4gICAgbGV0IHBhcnNlZDogdW5rbm93biA9IG51bGw7XG4gICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgaWYgKHRleHQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgcGFyc2VkID0gdGV4dDtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgYCR7bWV0aG9kfSAke3BhdGh9YCk7XG4gICAgcmV0dXJuIHBhcnNlZDtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbWFrZUVycm9yKHJlczogUmVzcG9uc2UsIGxhYmVsOiBzdHJpbmcpOiBQcm9taXNlPEdpdEh1YkVycm9yPiB7XG4gICAgbGV0IHBhcnNlZDogdW5rbm93biA9IG51bGw7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXMudGV4dCgpO1xuICAgICAgaWYgKHRleHQpIHBhcnNlZCA9IEpTT04ucGFyc2UodGV4dCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBpZ25vcmVcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgbGFiZWwpO1xuICB9XG5cbiAgcHJpdmF0ZSBtYWtlRXJyb3JGcm9tUGFyc2VkKHJlczogUmVzcG9uc2UsIGJvZHk6IHVua25vd24sIGxhYmVsOiBzdHJpbmcpOiBHaXRIdWJFcnJvciB7XG4gICAgY29uc3QgbXNnID1cbiAgICAgIHR5cGVvZiBib2R5ID09PSAnb2JqZWN0JyAmJiBib2R5ICYmICdtZXNzYWdlJyBpbiBib2R5XG4gICAgICAgID8gU3RyaW5nKChib2R5IGFzIHsgbWVzc2FnZTogdW5rbm93biB9KS5tZXNzYWdlKVxuICAgICAgICA6IHJlcy5zdGF0dXNUZXh0O1xuICAgIGxldCBjYXRlZ29yeTogR2l0SHViRXJyb3JbJ2NhdGVnb3J5J10gPSAndW5rbm93bic7XG4gICAgbGV0IHJldHJpYWJsZSA9IGZhbHNlO1xuICAgIGlmIChyZXMuc3RhdHVzID09PSA0MDEgfHwgcmVzLnN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICAvLyA0MDMgY2FuIGJlIGVpdGhlciBhdXRoIG9yIHJhdGUgbGltaXQ7IGNoZWNrIGhlYWRlcnMuXG4gICAgICBjb25zdCByYXRlID0gcmVzLmhlYWRlcnMuZ2V0KCd4LXJhdGVsaW1pdC1yZW1haW5pbmcnKTtcbiAgICAgIGlmIChyYXRlID09PSAnMCcgfHwgL3JhdGUgbGltaXQvaS50ZXN0KG1zZykpIHtcbiAgICAgICAgY2F0ZWdvcnkgPSAncmF0ZS1saW1pdCc7XG4gICAgICAgIHJldHJpYWJsZSA9IHRydWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjYXRlZ29yeSA9ICdhdXRoJztcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkge1xuICAgICAgY2F0ZWdvcnkgPSAnbm90LWZvdW5kJztcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwOSB8fCByZXMuc3RhdHVzID09PSA0MjIpIHtcbiAgICAgIGNhdGVnb3J5ID0gJ2NvbmZsaWN0JztcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPj0gNTAwKSB7XG4gICAgICBjYXRlZ29yeSA9ICdzZXJ2ZXInO1xuICAgICAgcmV0cmlhYmxlID0gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQyOSkge1xuICAgICAgY2F0ZWdvcnkgPSAncmF0ZS1saW1pdCc7XG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IEdpdEh1YkVycm9yKHtcbiAgICAgIHN0YXR1czogcmVzLnN0YXR1cyxcbiAgICAgIGJvZHksXG4gICAgICBtZXNzYWdlOiBgJHtsYWJlbH0gXHUyMTkyICR7cmVzLnN0YXR1c306ICR7bXNnfWAsXG4gICAgICByZXRyaWFibGUsXG4gICAgICBjYXRlZ29yeSxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyBwYXJzZVJhdGVMaW1pdFJlc2V0KHJlcy5oZWFkZXJzKSA6IG51bGwsXG4gICAgfSk7XG4gIH1cbn1cblxuLyoqXG4gKiBCZXN0LWVmZm9ydCBwYXJzZSBvZiB3aGVuIHRoZSBjdXJyZW50IHJhdGUtbGltaXQgd2luZG93IGVuZHMuIEdpdEh1YidzXG4gKiBwcmltYXJ5IGxpbWl0IHJlcG9ydHMgYFgtUmF0ZUxpbWl0LVJlc2V0YCBhcyBhIFVuaXggZXBvY2ggaW4gc2Vjb25kcy5cbiAqIFNlY29uZGFyeSAvIGFidXNlIGxpbWl0cyB1c2UgYFJldHJ5LUFmdGVyYCwgd2hpY2ggaXMgZWl0aGVyIGFuIEhUVFAtZGF0ZVxuICogb3IgYSBkZWx0YSBpbiBzZWNvbmRzIFx1MjAxNCB3ZSBub3JtYWxpemUgYm90aCB0byBlcG9jaCBzZWNvbmRzLlxuICovXG5mdW5jdGlvbiBwYXJzZVJhdGVMaW1pdFJlc2V0KGhlYWRlcnM6IEhlYWRlcnMpOiBudW1iZXIgfCBudWxsIHtcbiAgY29uc3QgcmVzZXQgPSBoZWFkZXJzLmdldCgneC1yYXRlbGltaXQtcmVzZXQnKTtcbiAgaWYgKHJlc2V0KSB7XG4gICAgY29uc3QgbiA9IE51bWJlci5wYXJzZUludChyZXNldCwgMTApO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikgJiYgbiA+IDApIHJldHVybiBuO1xuICB9XG4gIGNvbnN0IHJldHJ5QWZ0ZXIgPSBoZWFkZXJzLmdldCgncmV0cnktYWZ0ZXInKTtcbiAgaWYgKHJldHJ5QWZ0ZXIpIHtcbiAgICBjb25zdCBkZWx0YSA9IE51bWJlci5wYXJzZUludChyZXRyeUFmdGVyLCAxMCk7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShkZWx0YSkgJiYgZGVsdGEgPj0gMCkge1xuICAgICAgcmV0dXJuIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApICsgZGVsdGE7XG4gICAgfVxuICAgIGNvbnN0IGFzRGF0ZSA9IERhdGUucGFyc2UocmV0cnlBZnRlcik7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShhc0RhdGUpKSByZXR1cm4gTWF0aC5mbG9vcihhc0RhdGUgLyAxMDAwKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gZW5jb2RlUGF0aChwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyBFbmNvZGUgc2VnbWVudHMgaW5kaXZpZHVhbGx5IHNvIHNsYXNoZXMgcmVtYWluLlxuICByZXR1cm4gcGF0aC5zcGxpdCgnLycpLm1hcChlbmNvZGVVUklDb21wb25lbnQpLmpvaW4oJy8nKTtcbn1cblxuZnVuY3Rpb24gYmFja29mZk1zKGF0dGVtcHQ6IG51bWJlciwgZXJyOiBHaXRIdWJFcnJvcik6IG51bWJlciB7XG4gIC8vIEV4cG9uZW50aWFsIHdpdGggaml0dGVyOyBidW1wIGhpZ2hlciBmb3IgcmF0ZS1saW1pdCByZXNwb25zZXMuXG4gIGNvbnN0IGJhc2UgPSBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IDUwMDAgOiA1MDA7XG4gIGNvbnN0IGppdHRlciA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDQwMCk7XG4gIHJldHVybiBNYXRoLm1pbig2MF8wMDAsIGJhc2UgKiAyICoqIChhdHRlbXB0IC0gMSkgKyBqaXR0ZXIpO1xufVxuXG5mdW5jdGlvbiBpc0NvbmZsaWN0KGVycjogdW5rbm93bik6IGVyciBpcyBHaXRIdWJFcnJvciB7XG4gIHJldHVybiBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdjb25mbGljdCc7XG59XG5cbmZ1bmN0aW9uIHNsZWVwKG1zOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0b0Jhc2U2NChieXRlczogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gYnl0ZXMgaXMgYSBVVEYtOCBzdHJpbmcgb2YgSlNPTjsgZW5jb2RlIHRvIGJhc2U2NCB0aGUgc2FmZSB3YXkuXG4gIGNvbnN0IHV0ZjggPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoYnl0ZXMpO1xuICBsZXQgYmluID0gJyc7XG4gIGZvciAoY29uc3QgYiBvZiB1dGY4KSBiaW4gKz0gU3RyaW5nLmZyb21DaGFyQ29kZShiKTtcbiAgcmV0dXJuIGJ0b2EoYmluKTtcbn1cbiIsICJpbXBvcnQgeyBUV0VFVF9VUkxfUFJFRklYIH0gZnJvbSAnLi9jb25maWcuanMnO1xuaW1wb3J0IHR5cGUge1xuICBDYW5vbmljYWxUd2VldCxcbiAgQ29tbXVuaXR5Tm90ZSxcbiAgTWVkaWFJdGVtLFxuICBUd2VldENhcmQsXG4gIFR3ZWV0VHlwZSxcbiAgVW5hdmFpbGFibGVUd2VldCxcbiAgVXJsRW50aXR5LFxuICBVc2VyU25hcHNob3QsXG59IGZyb20gJy4vdHlwZXMuanMnO1xuXG4vKipcbiAqIE5vcm1hbGl6ZSBHcmFwaFFMIHJlc3BvbnNlIHBheWxvYWRzIGZyb20gWCdzIGludGVybmFsIEFQSSBpbnRvXG4gKiBgQ2Fub25pY2FsVHdlZXRgcy4gTWFueSBlbmRwb2ludHMgc2hhcmUgYSBzaW1pbGFyIHR3ZWV0IHNoYXBlIGJ1dCB3cmFwIGl0IGluXG4gKiBkaWZmZXJlbnQgZW52ZWxvcGVzOyB0aGlzIG1vZHVsZSB3YWxrcyB0aGUgc3RydWN0dXJlIGRlZmVuc2l2ZWx5LlxuICpcbiAqIFRoZSBwYXJzZXIgaXMgaW50ZW50aW9uYWxseSBwZXJtaXNzaXZlOiBpdCB3aWxsIHNpbGVudGx5IHNraXAgZW50cmllcyBpdFxuICogY2FuJ3QgcmVjb2duaXplIGFzIHR3ZWV0cyAoY3Vyc29ycywgYWRzLCBnYXAgZW50cmllcywgbW9kdWxlcyBvZiBvdGhlclxuICogdHdlZXRzLCB0b21ic3RvbmVzKS4gSXQgdGhyb3dzICpvbmx5KiB3aGVuIGdpdmVuIGEgcGF5bG9hZCBpdCBkb2Vzbid0IGtub3dcbiAqIGhvdyB0byB3YWxrIGF0IGFsbCBcdTIwMTQgdGhvc2UgY2FzZXMgYXJlIGNhdWdodCBhbmQgcXVhcmFudGluZWQgdXBzdHJlYW0uXG4gKi9cblxuZXhwb3J0IGludGVyZmFjZSBOb3JtYWxpemVDb250ZXh0IHtcbiAgY2FwdHVyZWRBdDogc3RyaW5nO1xuICBydW5JZDogc3RyaW5nO1xuICBlbmRwb2ludDogc3RyaW5nO1xuICBhbGxvd2VkSGFuZGxlczogUmVhZG9ubHlTZXQ8c3RyaW5nPjtcbiAgc291cmNlVXJsPzogc3RyaW5nIHwgbnVsbDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBOb3JtYWxpemVSZXN1bHQge1xuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W107XG4gIG9ic2VydmVkX2lkczogc3RyaW5nW107XG4gIHVuYXZhaWxhYmxlX3R3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdO1xuICAvKipcbiAgICogVHdlZXQtc2hhcGVkIG5vZGVzIHRoZSB3YWxrZXIgc2F3IChoYWQgYSBgcmVzdF9pZGApIGJ1dCBjb3VsZG4ndCB0dXJuXG4gICAqIGludG8gYSBmdWxsIGBDYW5vbmljYWxUd2VldGAgXHUyMDE0IHR5cGljYWxseSBiZWNhdXNlIHRoZSBlbWJlZGRlZCB1c2VyXG4gICAqIGluZm8gd2FzIG1pc3Npbmcgb3IgdGhlIGVudHJ5IHdhcyBhIG1lZGlhLW9ubHkgdGh1bWJuYWlsIGNhcmQgZnJvbVxuICAgKiB0aGUgVXNlck1lZGlhIGVuZHBvaW50LiBPbmx5IElEcyB3aXRoIGEgdHJ1c3R3b3J0aHkgaGFuZGxlIGZyb20gdGhlXG4gICAqIHR3ZWV0IG5vZGUgaXRzZWxmIGFyZSByZXR1cm5lZDsgb3RoZXJ3aXNlIHRoZSBiYWNrZ3JvdW5kIGNhbm5vdCBidWlsZFxuICAgKiBhIHJlbGlhYmxlIC88aGFuZGxlPi9zdGF0dXMvPGlkPiBkZXRhaWwgVVJMLlxuICAgKi9cbiAgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT47XG59XG5cbi8vIFggdHdlZXQgSURzIGFyZSA2NC1iaXQgcG9zaXRpdmUgaW50ZWdlcnMgc2VyaWFsaXplZCBhcyBkZWNpbWFsIHN0cmluZ3MuXG4vLyBUaGV5J3ZlIGdyb3duIHRvIDE5IGNoYXJzICh+MS41ZTE4KSBieSAyMDI2LiBSZWplY3QgYW55dGhpbmcgdGhhdCBkb2Vzbid0XG4vLyBtYXRjaCB0aGlzIHNoYXBlIFx1MjAxNCBvdGhlcndpc2Ugc3B1cmlvdXMgY2FyZCBJRHMsIGN1cnNvciBzdHJpbmdzLCBhZCBzbG90XG4vLyBJRHMsIGV0Yy4gZW5kIHVwIGluIHRoZSBwYXJ0aWFsLWNhcHR1cmUgcXVldWUgYW5kIHRoZSBjcmF3bCBsb29wXG4vLyBuYXZpZ2F0ZXMgdG8gaW52YWxpZCBVUkxzIHRoYXQgc2hvdyBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXG5jb25zdCBUV0VFVF9JRF9SRSA9IC9eXFxkezE1LDIwfSQvO1xuXG4vLyBPbmx5IG9uZSBlbmRwb2ludCBhY3R1YWxseSBleHBvc2VzIHRoZSBmYWlsdXJlIG1vZGUgdGhlIHBhcnRpYWwtY2FwdHVyZVxuLy8gcXVldWUgZXhpc3RzIGZvciBcdTIwMTQgdGhlIE1lZGlhIHRhYidzIGBVc2VyTWVkaWFgIHF1ZXJ5IHJldHVybmluZ1xuLy8gdGh1bWJuYWlsLW9ubHkgZW50cmllcyB3aXRob3V0IGEgcG9wdWxhdGVkIGF1dGhvciBibG9jay4gRXZlcnkgb3RoZXJcbi8vIGVuZHBvaW50IHRoYXQgaGFuZHMgdXMgYSBgVHdlZXRgIHNoYXBlIGdpdmVzIHVzIHRoZSBmdWxsIGVudHJ5OyBpZlxuLy8gYGJ1aWxkVHdlZXRgIGZhaWxzIHRoZXJlIGl0J3MgYSByZWFsIGVycm9yLCBub3QgXCJnbyByZS1mZXRjaCB0aGlzXCIuXG4vLyBSZXN0cmljdGluZyBwYXJ0aWFsLWlkIGVtaXNzaW9uIHRvIFVzZXJNZWRpYSBzdG9wcyB0aGUgZmxvb2RzIG9mXG4vLyBmYWxzZSBwb3NpdGl2ZXMgcmVwb3J0ZWQgb24gUmVwbGllcyAvIFR3ZWV0RGV0YWlsIC8gU2VhcmNoVGltZWxpbmUuXG5jb25zdCBQQVJUSUFMX09LX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyTWVkaWEnXSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemUocGF5bG9hZDogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogTm9ybWFsaXplUmVzdWx0IHtcbiAgY29uc3QgcmF3VHdlZXRzID0gY29sbGVjdFR3ZWV0cyhwYXlsb2FkKTtcbiAgY29uc3QgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdID0gW107XG4gIGNvbnN0IHVuYXZhaWxhYmxlVHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W10gPSBbXTtcbiAgY29uc3Qgb2JzZXJ2ZWQ6IHN0cmluZ1tdID0gW107XG4gIGNvbnN0IGJ1aWx0ID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHBhcnRpYWxNYXAgPSBuZXcgTWFwPHN0cmluZywgc3RyaW5nIHwgbnVsbD4oKTtcbiAgY29uc3QgY29sbGVjdFBhcnRpYWxzID0gUEFSVElBTF9PS19FTkRQT0lOVFMuaGFzKGN0eC5lbmRwb2ludCk7XG4gIGZvciAoY29uc3QgcmF3IG9mIHJhd1R3ZWV0cykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB1bmF2YWlsYWJsZSA9IHBpY2tVbmF2YWlsYWJsZVR3ZWV0KHJhdywgY3R4KTtcbiAgICAgIGlmICh1bmF2YWlsYWJsZSkge1xuICAgICAgICB1bmF2YWlsYWJsZVR3ZWV0cy5wdXNoKHVuYXZhaWxhYmxlKTtcbiAgICAgICAgb2JzZXJ2ZWQucHVzaCh1bmF2YWlsYWJsZS50d2VldF9pZCk7XG4gICAgICAgIGJ1aWx0LmFkZCh1bmF2YWlsYWJsZS50d2VldF9pZCk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgY29uc3QgdCA9IGJ1aWxkVHdlZXQocmF3LCBjdHgpO1xuICAgICAgaWYgKCF0KSB7XG4gICAgICAgIGlmIChjb2xsZWN0UGFydGlhbHMpIHtcbiAgICAgICAgICAvLyBPbmx5IGVucXVldWUgcmVhbC10d2VldCBzaGVsbHMgd2l0aCBhIHRydXN0d29ydGh5IGhhbmRsZSAobm90XG4gICAgICAgICAgLy8gdG9tYnN0b25lcywgc3RyaXBwZWQgbm9kZXMgbGFja2luZyBhIGxlZ2FjeSBibG9jaywgZ2FyYmFnZSBJRHMsXG4gICAgICAgICAgLy8gb3IgSURzIHRoYXQgd291bGQgcmVxdWlyZSBndWVzc2luZyB0aGUgYXV0aG9yIGZyb20gdGhlIHBhZ2UpLlxuICAgICAgICAgIGNvbnN0IHBhcnRpYWwgPSBwaWNrUGFydGlhbChyYXcpO1xuICAgICAgICAgIGlmIChwYXJ0aWFsKSBwYXJ0aWFsTWFwLnNldChwYXJ0aWFsLnR3ZWV0X2lkLCBwYXJ0aWFsLmhpbnRfaGFuZGxlKTtcbiAgICAgICAgfVxuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIG9ic2VydmVkLnB1c2godC50d2VldF9pZCk7XG4gICAgICBidWlsdC5hZGQodC50d2VldF9pZCk7XG4gICAgICBpZiAoY3R4LmFsbG93ZWRIYW5kbGVzLnNpemUgPT09IDAgfHwgY3R4LmFsbG93ZWRIYW5kbGVzLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSB7XG4gICAgICAgIHR3ZWV0cy5wdXNoKHQpO1xuICAgICAgfVxuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gT25lIGJhZCBlbnRyeSBzaG91bGRuJ3QgdGFrZSBkb3duIHRoZSB3aG9sZSBiYXRjaC5cbiAgICB9XG4gIH1cbiAgLy8gQW55dGhpbmcgdGhhdCBlbmRlZCB1cCBpbiBwYXJ0aWFsTWFwIGJ1dCBBTFNPIGNhbWUgYmFjayBhcyBhIGJ1aWx0XG4gIC8vIHR3ZWV0IChkaWZmZXJlbnQgd2Fsa2VyIHBhc3MsIHNhbWUgaWQpIGlzbid0IGFjdHVhbGx5IHBhcnRpYWwuXG4gIGNvbnN0IHBhcnRpYWxfaWRzOiBBcnJheTx7IHR3ZWV0X2lkOiBzdHJpbmc7IGhpbnRfaGFuZGxlOiBzdHJpbmcgfCBudWxsIH0+ID0gW107XG4gIGZvciAoY29uc3QgW2lkLCBoaW50XSBvZiBwYXJ0aWFsTWFwKSB7XG4gICAgaWYgKGJ1aWx0LmhhcyhpZCkpIGNvbnRpbnVlO1xuICAgIHBhcnRpYWxfaWRzLnB1c2goeyB0d2VldF9pZDogaWQsIGhpbnRfaGFuZGxlOiBoaW50IH0pO1xuICB9XG4gIHJldHVybiB7IHR3ZWV0cywgb2JzZXJ2ZWRfaWRzOiBvYnNlcnZlZCwgdW5hdmFpbGFibGVfdHdlZXRzOiB1bmF2YWlsYWJsZVR3ZWV0cywgcGFydGlhbF9pZHMgfTtcbn1cblxuZnVuY3Rpb24gcGlja1VuYXZhaWxhYmxlVHdlZXQobm9kZTogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogVW5hdmFpbGFibGVUd2VldCB8IG51bGwge1xuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgaWYgKG4uX190eXBlbmFtZSAhPT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgdHdlZXRJZCA9XG4gICAgc3RyT3JOdWxsKG4ucmVzdF9pZCkgPz9cbiAgICBwaWNrVHdlZXRJZEZyb21VcmxzKG5vZGUpID8/XG4gICAgKGN0eC5zb3VyY2VVcmwgPyB0d2VldElkRnJvbVR3ZWV0VXJsKGN0eC5zb3VyY2VVcmwpIDogbnVsbCk7XG4gIGlmICghdHdlZXRJZCB8fCAhVFdFRVRfSURfUkUudGVzdCh0d2VldElkKSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgdW5hdmFpbGFibGVUZXh0ID0gcGlja1RvbWJzdG9uZVRleHQobm9kZSk7XG4gIHJldHVybiB7XG4gICAgdHdlZXRfaWQ6IHR3ZWV0SWQsXG4gICAgYWNjb3VudF9oYW5kbGU6XG4gICAgICBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlLCB0d2VldElkKSA/P1xuICAgICAgKGN0eC5zb3VyY2VVcmwgPyBoYW5kbGVGcm9tVHdlZXRVcmwoY3R4LnNvdXJjZVVybCwgdHdlZXRJZCkgOiBudWxsKSxcbiAgICB1bmF2YWlsYWJsZV9kZXRlY3RlZF9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgdW5hdmFpbGFibGVfcmVhc29uOiBjbGFzc2lmeVVuYXZhaWxhYmxlUmVhc29uKHVuYXZhaWxhYmxlVGV4dCksXG4gICAgdW5hdmFpbGFibGVfdGV4dDogdW5hdmFpbGFibGVUZXh0LFxuICAgIHVuYXZhaWxhYmxlX3NvdXJjZV91cmw6IGN0eC5zb3VyY2VVcmwgPz8gbnVsbCxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcGlja1R3ZWV0SWRGcm9tVXJscyhub2RlOiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgY3VyID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKHR5cGVvZiBjdXIgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25zdCBpZCA9IHR3ZWV0SWRGcm9tVHdlZXRVcmwoY3VyKTtcbiAgICAgIGlmIChpZCkgcmV0dXJuIGlkO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmIChzZWVuLmhhcyhjdXIgYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQoY3VyIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIGN1cikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmZ1bmN0aW9uIHR3ZWV0SWRGcm9tVHdlZXRVcmwocmF3VXJsOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHJhd1VybCwgVFdFRVRfVVJMX1BSRUZJWCk7XG4gICAgaWYgKHVybC5ob3N0bmFtZSAhPT0gJ3guY29tJyAmJiB1cmwuaG9zdG5hbWUgIT09ICd0d2l0dGVyLmNvbScpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IG1hdGNoID0gdXJsLnBhdGhuYW1lLm1hdGNoKC9eXFwvW0EtWmEtejAtOV9dezEsMTV9XFwvc3RhdHVzXFwvKFxcZHsxNSwyMH0pKD86XFwvfCQpLyk7XG4gICAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gbnVsbDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGlja1RvbWJzdG9uZVRleHQobm9kZTogdW5rbm93bik6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBzdHJpbmdzOiBzdHJpbmdbXSA9IFtdO1xuICBjb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IGN1ciA9IHN0YWNrLnBvcCgpO1xuICAgIGlmICh0eXBlb2YgY3VyID09PSAnc3RyaW5nJykge1xuICAgICAgY29uc3QgdHJpbW1lZCA9IGN1ci50cmltKCk7XG4gICAgICBpZiAoXG4gICAgICAgIHRyaW1tZWQubGVuZ3RoID49IDQgJiZcbiAgICAgICAgIXRyaW1tZWQuc3RhcnRzV2l0aCgnaHR0cDovLycpICYmXG4gICAgICAgICF0cmltbWVkLnN0YXJ0c1dpdGgoJ2h0dHBzOi8vJylcbiAgICAgICkge1xuICAgICAgICBzdHJpbmdzLnB1c2godHJpbW1lZCk7XG4gICAgICB9XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHNlZW4uaGFzKGN1ciBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICBzZWVuLmFkZChjdXIgYXMgb2JqZWN0KTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgY3VyKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICBjb25zdCBwcmVmZXJyZWQgPSBzdHJpbmdzLmZpbmQoKHMpID0+XG4gICAgL1xcYihjb3B5cmlnaHR8ZG1jYXx1bmF2YWlsYWJsZXx3aXRoaGVsZHxyZW1vdmVkfGRlbGV0ZWR8dmlvbGF0fHN1c3BlbmRlZClcXGIvaS50ZXN0KHMpXG4gICk7XG4gIHJldHVybiBwcmVmZXJyZWQgPz8gc3RyaW5nc1swXSA/PyBudWxsO1xufVxuXG5mdW5jdGlvbiBjbGFzc2lmeVVuYXZhaWxhYmxlUmVhc29uKHRleHQ6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKCF0ZXh0KSByZXR1cm4gbnVsbDtcbiAgaWYgKC9cXGIoY29weXJpZ2h0fGRtY2EpXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICdjb3B5cmlnaHQnO1xuICBpZiAoL1xcYndpdGhoZWxkXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICd3aXRoaGVsZCc7XG4gIGlmICgvXFxiZGVsZXRlZHxyZW1vdmVkXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICdyZW1vdmVkJztcbiAgaWYgKC9cXGJzdXNwZW5kZWRcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3N1c3BlbmRlZCc7XG4gIGlmICgvXFxidW5hdmFpbGFibGV8bm90IGF2YWlsYWJsZVxcYi9pLnRlc3QodGV4dCkpIHJldHVybiAndW5hdmFpbGFibGUnO1xuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gcGlja1BhcnRpYWwobm9kZTogdW5rbm93bik6IHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfSB8IG51bGwge1xuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgLy8gRGVsZXRlZCB0d2VldHMgc3VyZmFjZSBhcyBUd2VldFRvbWJzdG9uZSBcdTIwMTQgdGhlcmUncyBub3RoaW5nIHRvIHJlZmV0Y2gsXG4gIC8vIHNraXAgdGhlbSBvciB0aGUgY3Jhd2wgbG9vcCB3aWxsIHNwaW4gb24gXCJ0aGlzIHBhZ2UgZG9lc24ndCBleGlzdFwiLlxuICBpZiAobi5fX3R5cGVuYW1lID09PSAnVHdlZXRUb21ic3RvbmUnKSByZXR1cm4gbnVsbDtcbiAgLy8gUmVxdWlyZSBhIHJlY29nbml6ZWQgVHdlZXQgdHlwZW5hbWUgT1IgYSBsZWdhY3kgYmxvY2suIEN1cnNvcnMsIGFkcyxcbiAgLy8gbW9kdWxlIGhlYWRlcnMsIGFuZCB0aGUgbGlrZSBnZXQgcmVqZWN0ZWQgaGVyZS5cbiAgY29uc3QgdG4gPSBuLl9fdHlwZW5hbWU7XG4gIGlmICh0biAhPT0gJ1R3ZWV0JyAmJiB0biAhPT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiAhb2JqKG4ubGVnYWN5KSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IHJlc3RJZCA9XG4gICAgKHR5cGVvZiBuLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIG4ucmVzdF9pZCkgfHxcbiAgICAodHlwZW9mIG9iaihuLnR3ZWV0X3Jlc3VsdCk/LnJlc3VsdCA9PT0gJ29iamVjdCcgJiZcbiAgICAgIChvYmoob2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCBhcyBzdHJpbmcpKTtcbiAgaWYgKHR5cGVvZiByZXN0SWQgIT09ICdzdHJpbmcnIHx8ICFUV0VFVF9JRF9SRS50ZXN0KHJlc3RJZCkpIHJldHVybiBudWxsO1xuICBjb25zdCBoaW50SGFuZGxlID0gcGlja0hpbnRIYW5kbGUobm9kZSwgcmVzdElkKTtcbiAgaWYgKCFoaW50SGFuZGxlKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHsgdHdlZXRfaWQ6IHJlc3RJZCwgaGludF9oYW5kbGU6IGhpbnRIYW5kbGUgfTtcbn1cblxuZnVuY3Rpb24gcGlja0hpbnRIYW5kbGUobm9kZTogdW5rbm93biwgdHdlZXRJZDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICBjb25zdCB1c2VyUmVzdWx0ID0gb2JqKG9iaihvYmoobi5jb3JlKT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgcmV0dXJuIChcbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmNvcmUpPy5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbChvYmoobi5sZWdhY3kpPy5zY3JlZW5fbmFtZSkgPz9cbiAgICBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlLCB0d2VldElkKVxuICApO1xufVxuXG5mdW5jdGlvbiBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlOiB1bmtub3duLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBjdXIgPSBzdGFjay5wb3AoKTtcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGNvbnN0IGhhbmRsZSA9IGhhbmRsZUZyb21Ud2VldFVybChjdXIsIHR3ZWV0SWQpO1xuICAgICAgaWYgKGhhbmRsZSkgcmV0dXJuIGhhbmRsZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoY3VyID09PSBudWxsIHx8IHR5cGVvZiBjdXIgIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAoc2Vlbi5oYXMoY3VyIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGN1cikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBjdXIpIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKGN1ciBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHN0YWNrLnB1c2godik7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBoYW5kbGVGcm9tVHdlZXRVcmwocmF3VXJsOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICB0cnkge1xuICAgIGNvbnN0IHVybCA9IG5ldyBVUkwocmF3VXJsLCBUV0VFVF9VUkxfUFJFRklYKTtcbiAgICBpZiAodXJsLmhvc3RuYW1lICE9PSAneC5jb20nICYmIHVybC5ob3N0bmFtZSAhPT0gJ3R3aXR0ZXIuY29tJykgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC8oW0EtWmEtejAtOV9dezEsMTV9KVxcL3N0YXR1c1xcLyhcXGR7MTUsMjB9KSg/OlxcL3wkKS8pO1xuICAgIGlmICghbWF0Y2ggfHwgbWF0Y2hbMl0gIT09IHR3ZWV0SWQpIHJldHVybiBudWxsO1xuICAgIHJldHVybiBtYXRjaFsxXSA/PyBudWxsO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBjb2xsZWN0VHdlZXRzKG9iajogdW5rbm93bik6IHVua25vd25bXSB7XG4gIC8vIFdhbGsgdGhlIHJlc3BvbnNlIHRyZWUgZ2F0aGVyaW5nIGV2ZXJ5dGhpbmcgdGhhdCBsb29rcyBsaWtlIGEgdHdlZXRcbiAgLy8gcmVzdWx0LiBXZSBsb29rIGZvciBub2RlcyBzaGFwZWQgbGlrZTpcbiAgLy8gICB7IF9fdHlwZW5hbWU/OiAnVHdlZXQnfCdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycsIHJlc3RfaWQsIGxlZ2FjeSB9XG4gIC8vIGFuZCB1bndyYXAgdmlzaWJpbGl0eSB3cmFwcGVycy5cbiAgY29uc3Qgb3V0OiB1bmtub3duW10gPSBbXTtcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtvYmpdO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xuICAgIGNvbnN0IG5vZGUgPSBzdGFjay5wb3AoKTtcbiAgICBpZiAobm9kZSA9PT0gbnVsbCB8fCBub2RlID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xuICAgIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGlmIChzZWVuLmhhcyhub2RlIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKG5vZGUgYXMgb2JqZWN0KTtcblxuICAgIGlmIChsb29rc0xpa2VUd2VldChub2RlKSkge1xuICAgICAgb3V0LnB1c2godW53cmFwVHdlZXQobm9kZSkpO1xuICAgIH1cbiAgICBpZiAoQXJyYXkuaXNBcnJheShub2RlKSkge1xuICAgICAgZm9yIChjb25zdCB2IG9mIG5vZGUpIHN0YWNrLnB1c2godik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG5mdW5jdGlvbiBsb29rc0xpa2VUd2VldChub2RlOiB1bmtub3duKTogbm9kZSBpcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBuID0gbm9kZSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgY29uc3QgdHlwZW5hbWUgPSBuLl9fdHlwZW5hbWU7XG4gIGlmIChcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0JyB8fFxuICAgIHR5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnIHx8XG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZSdcbiAgKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgLy8gU29tZSBlbnRyaWVzIGxhY2sgX190eXBlbmFtZSBidXQgc3RpbGwgY2FycnkgbGVnYWN5ICsgcmVzdF9pZCArIGNvcmUuXG4gIHJldHVybiB0eXBlb2Ygbi5yZXN0X2lkID09PSAnc3RyaW5nJyAmJiB0eXBlb2Ygbi5sZWdhY3kgPT09ICdvYmplY3QnICYmIG4ubGVnYWN5ICE9PSBudWxsO1xufVxuXG5mdW5jdGlvbiB1bndyYXBUd2VldChub2RlOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgaWYgKG5vZGUuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiB0eXBlb2Ygbm9kZS50d2VldCA9PT0gJ29iamVjdCcpIHtcbiAgICByZXR1cm4gbm9kZS50d2VldCBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgfVxuICByZXR1cm4gbm9kZTtcbn1cblxuZnVuY3Rpb24gYnVpbGRUd2VldChyYXc6IHVua25vd24sIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IENhbm9uaWNhbFR3ZWV0IHwgbnVsbCB7XG4gIGlmICh0eXBlb2YgcmF3ICE9PSAnb2JqZWN0JyB8fCByYXcgPT09IG51bGwpIHJldHVybiBudWxsO1xuICBjb25zdCB0ID0gcmF3IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuXG4gIGlmICh0Ll9fdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZScpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHJlc3RJZCA9IHN0ck9yTnVsbCh0LnJlc3RfaWQpO1xuICAvLyBgbGVnYWN5YCBpcyBzdGlsbCB3aGVyZSBtb3N0IGVuZ2FnZW1lbnQgLyBlbnRpdGllcyBsaXZlIGluIDIwMjYtZXJhIFhcbiAgLy8gcGF5bG9hZHMsIGJ1dCBhcyBvZiByZWNlbnQgc2NoZW1hIG1pZ3JhdGlvbnMgc2V2ZXJhbCBmaWVsZHMgcHJldmlvdXNseVxuICAvLyB0aGVyZSAobm90YWJseSB0aGUgYXV0aG9yIGhhbmRsZSkgaGF2ZSBtb3ZlZCB0byBzaWJsaW5nIGxvY2F0aW9ucy4gV2VcbiAgLy8gdG9sZXJhdGUgYSBtaXNzaW5nIGxlZ2FjeSBoZXJlIGFuZCBsb29rIHVwIGV2ZXJ5dGhpbmcgdmlhIGZhbGxiYWNrcy5cbiAgY29uc3QgbGVnYWN5ID0gb2JqKHQubGVnYWN5KSA/PyB7fTtcbiAgaWYgKCFyZXN0SWQpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGNvcmUgPSBvYmoodC5jb3JlKTtcbiAgY29uc3QgdXNlclJlc3VsdCA9IG9iaihvYmooY29yZT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcbiAgLy8gQXV0aG9yIGhhbmRsZTogdHJ5IHRoZSBuZXcgYGNvcmVgIHN1YnN0cnVjdHVyZSBmaXJzdCAoY3VycmVudCBYIHNoYXBlKSxcbiAgLy8gdGhlbiB0aGUgbGVnYWN5IGBsZWdhY3kuc2NyZWVuX25hbWVgLCB0aGVuIGEgY291cGxlIG9mIG9sZGVyIHZhcmlhbnRzLlxuICBjb25zdCB1c2VyQ29yZU5ldyA9IG9iaih1c2VyUmVzdWx0Py5jb3JlKTtcbiAgY29uc3QgdXNlckxlZ2FjeSA9IG9iaih1c2VyUmVzdWx0Py5sZWdhY3kpO1xuICBjb25zdCB1c2VyQXZhdGFyT2JqID0gb2JqKHVzZXJSZXN1bHQ/LmF2YXRhcik7XG4gIGNvbnN0IGhhbmRsZSA9XG4gICAgc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5zY3JlZW5fbmFtZSkgPz9cbiAgICBzdHJPck51bGwodXNlckxlZ2FjeT8uc2NyZWVuX25hbWUpID8/XG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnNjcmVlbl9uYW1lKSA/P1xuICAgIHN0ck9yTnVsbChsZWdhY3kuc2NyZWVuX25hbWUpO1xuICBjb25zdCBhY2NvdW50SWQgPVxuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5yZXN0X2lkKSA/P1xuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5pZF9zdHIpID8/XG4gICAgc3RyT3JOdWxsKGxlZ2FjeS51c2VyX2lkX3N0cik7XG4gIGlmICghaGFuZGxlIHx8ICFhY2NvdW50SWQpIHJldHVybiBudWxsO1xuICAvLyBBdXRob3Igc25hcHNob3QuIERpc3BsYXkgbmFtZSArIGF2YXRhciBtb3ZlZCBiZXR3ZWVuIGBsZWdhY3lgIGFuZCB0aGVcbiAgLy8gbmV3IGBjb3JlYCBzdWJzdHJ1Y3R1cmUgb3ZlciB0aW1lOyB0aGUgcmVzdCAodmVyaWZpY2F0aW9uLCBmb2xsb3dlclxuICAvLyBjb3VudHMsIGFjY291bnRfY3JlYXRlZF9hdCkgaXMgc3RpbGwgaW4gYGxlZ2FjeWAuIFdlIHNuYXBzaG90IHRoZVxuICAvLyB3aG9sZSBVc2VyU25hcHNob3QgcGVyIHR3ZWV0IGJlY2F1c2UgdGhlc2UgdmFsdWVzIGRyaWZ0IG92ZXIgdGltZVxuICAvLyBhbmQgdGhlIGF0LWNhcHR1cmUgc3RhdGUgaXMgdGhlIG9ubHkgcmVsaWFibGUgcmVjb3JkLlxuICBjb25zdCBhdXRob3IgPSBleHRyYWN0VXNlclNuYXBzaG90KHVzZXJSZXN1bHQsIHVzZXJDb3JlTmV3LCB1c2VyTGVnYWN5LCB1c2VyQXZhdGFyT2JqKTtcblxuICBjb25zdCBub3RlVHdlZXQgPSBvYmoob2JqKG9iaih0Lm5vdGVfdHdlZXQpPy5ub3RlX3R3ZWV0X3Jlc3VsdHMpPy5yZXN1bHQpO1xuICBjb25zdCB0ZXh0RnJvbU5vdGUgPSBzdHJPck51bGwobm90ZVR3ZWV0Py50ZXh0KTtcbiAgY29uc3QgdGV4dEZyb21MZWdhY3kgPSBzdHJPck51bGwobGVnYWN5LmZ1bGxfdGV4dCkgPz8gJyc7XG4gIGNvbnN0IHRleHQgPSB0ZXh0RnJvbU5vdGUgPz8gdGV4dEZyb21MZWdhY3k7XG4gIGNvbnN0IGlzVHJ1bmNhdGVkID0gZGV0ZWN0VHJ1bmNhdGlvbihub3RlVHdlZXQsIGxlZ2FjeSwgdGV4dEZyb21MZWdhY3kpO1xuICBjb25zdCBjb21tdW5pdHlOb3RlID0gZXh0cmFjdENvbW11bml0eU5vdGUodCwgbGVnYWN5LCBjdHguY2FwdHVyZWRBdCk7XG5cbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKSA/PyB7fTtcbiAgY29uc3QgZW50aXRpZXNGcm9tTm90ZSA9IG9iaihub3RlVHdlZXQ/LmVudGl0eV9zZXQpO1xuICBjb25zdCBoYXNodGFncyA9IGV4dHJhY3RIYXNodGFncyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgbWVudGlvbnMgPSBleHRyYWN0TWVudGlvbnMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XG4gIGNvbnN0IHVybHMgPSBleHRyYWN0VXJscyhlbnRpdGllc0Zyb21Ob3RlID8/IGVudGl0aWVzKTtcbiAgY29uc3QgbWVkaWEgPSBleHRyYWN0TWVkaWEobGVnYWN5KTtcblxuICBjb25zdCB0d2VldFR5cGUgPSBjbGFzc2lmeVR3ZWV0VHlwZSh0LCBsZWdhY3kpO1xuXG4gIC8vIFggb21pdHMgZmF2b3JpdGVfY291bnQgLyByZXBseV9jb3VudCAvIHF1b3RlX2NvdW50IGZyb20gYSByZXR3ZWV0XG4gIC8vIHdyYXBwZXIncyBsZWdhY3kgYmxvY2sgKG9ubHkgcmV0d2VldF9jb3VudCBpcyBwcm9wYWdhdGVkKSBcdTIwMTQgdGhlIHJlYWxcbiAgLy8gY291bnRzIGxpdmUgb24gdGhlIHJldHdlZXRlZCBzdGF0dXMuIFJlYWQgZW5nYWdlbWVudCBmcm9tIHRoZXJlIGZvclxuICAvLyByZXR3ZWV0cyBzbyB3ZSBkb24ndCByZWNvcmQgMCBsaWtlcy9yZXBsaWVzL3F1b3RlcyBvbiBldmVyeSByZXR3ZWV0LlxuICBjb25zdCByZXR3ZWV0ZWRMZWdhY3kgPSBvYmoob2JqKG9iaihsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQpPy5yZXN1bHQpPy5sZWdhY3kpO1xuICBjb25zdCBlbmdMZWdhY3kgPSB0d2VldFR5cGUgPT09ICdyZXR3ZWV0JyAmJiByZXR3ZWV0ZWRMZWdhY3kgPyByZXR3ZWV0ZWRMZWdhY3kgOiBsZWdhY3k7XG5cbiAgLy8gcG9zdGVkX2F0OiBsZWdhY3kuY3JlYXRlZF9hdCByZW1haW5zIHRoZSBjYW5vbmljYWwgbG9jYXRpb247IGlmIHRoYXQnc1xuICAvLyBtaXNzaW5nIGluIGEgZnV0dXJlIHNjaGVtYSB3ZSBmYWxsIGJhY2sgdG8gdG9wLWxldmVsIGNyZWF0ZWRfYXQuXG4gIGNvbnN0IHBvc3RlZEF0ID1cbiAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbChsZWdhY3kuY3JlYXRlZF9hdCkpID8/IHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHQuY3JlYXRlZF9hdCkpO1xuICBpZiAoIXBvc3RlZEF0KSByZXR1cm4gbnVsbDtcblxuICBjb25zdCB2aWV3cyA9IG9iaih0LnZpZXdzKTtcbiAgY29uc3Qgdmlld0NvdW50ID0gbnVtT3JOdWxsKHZpZXdzPy5jb3VudCkgPz8gbnVtT3JOdWxsKHN0ck9yTnVsbCh2aWV3cz8uY291bnQpKTtcblxuICBjb25zdCBjYXJkID0gZXh0cmFjdENhcmQodCk7XG4gIGNvbnN0IHBsYWNlID0gb2JqKGxlZ2FjeS5wbGFjZSk7XG5cbiAgY29uc3QgdHdlZXQ6IENhbm9uaWNhbFR3ZWV0ID0ge1xuICAgIHR3ZWV0X2lkOiByZXN0SWQsXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBhY2NvdW50X2lkOiBhY2NvdW50SWQsXG4gICAgcG9zdGVkX2F0OiBwb3N0ZWRBdCxcbiAgICBmaXJzdF9jYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgbGFzdF9zZWVuX2F0OiBjdHguY2FwdHVyZWRBdCxcbiAgICBkZWxldGlvbl9kZXRlY3RlZF9hdDogbnVsbCxcbiAgICB1bmF2YWlsYWJsZV9kZXRlY3RlZF9hdDogbnVsbCxcbiAgICB1bmF2YWlsYWJsZV9yZWFzb246IG51bGwsXG4gICAgdW5hdmFpbGFibGVfdGV4dDogbnVsbCxcbiAgICB1bmF2YWlsYWJsZV9zb3VyY2VfdXJsOiBudWxsLFxuICAgIHR3ZWV0X3VybDogYCR7VFdFRVRfVVJMX1BSRUZJWH0vJHtoYW5kbGV9L3N0YXR1cy8ke3Jlc3RJZH1gLFxuICAgIHR3ZWV0X3R5cGU6IHR3ZWV0VHlwZSxcbiAgICBjb252ZXJzYXRpb25faWQ6IHN0ck9yTnVsbChsZWdhY3kuY29udmVyc2F0aW9uX2lkX3N0ciksXG4gICAgcmVwbHlfdG9fdHdlZXRfaWQ6IHN0ck9yTnVsbChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0ciksXG4gICAgcmVwbHlfdG9fYWNjb3VudDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zY3JlZW5fbmFtZSksXG4gICAgcmVwbHlfdG9fYWNjb3VudF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b191c2VyX2lkX3N0ciksXG4gICAgcXVvdGVkX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSxcbiAgICByZXR3ZWV0ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChcbiAgICAgIG9iaihvYmoobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCA/P1xuICAgICAgICAobGVnYWN5IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0clxuICAgICksXG4gICAgdGV4dCxcbiAgICB0ZXh0X3Jlc29sdmVkOiByZXNvbHZlU2hvcnRVcmxzKHRleHQsIHVybHMpLFxuICAgIGxhbmc6IHN0ck9yTnVsbChsZWdhY3kubGFuZyksXG4gICAgcG9zc2libHlfc2Vuc2l0aXZlOiBib29sT3JOdWxsKGxlZ2FjeS5wb3NzaWJseV9zZW5zaXRpdmUpLFxuICAgIHNvdXJjZTogc3RyT3JOdWxsKGxlZ2FjeS5zb3VyY2UpID8/IHN0ck9yTnVsbCh0LnNvdXJjZSksXG4gICAgcGxhY2VfZnVsbF9uYW1lOiBzdHJPck51bGwocGxhY2U/LmZ1bGxfbmFtZSksXG4gICAgaGFzaHRhZ3MsXG4gICAgbWVudGlvbnMsXG4gICAgdXJscyxcbiAgICBjYXJkLFxuICAgIG1lZGlhLFxuICAgIGxpa2VfY291bnQ6IG51bU9yWmVybyhlbmdMZWdhY3kuZmF2b3JpdGVfY291bnQpLFxuICAgIHJldHdlZXRfY291bnQ6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXG4gICAgcmVwbHlfY291bnQ6IG51bU9yWmVybyhlbmdMZWdhY3kucmVwbHlfY291bnQpLFxuICAgIHF1b3RlX2NvdW50OiBudW1Pclplcm8oZW5nTGVnYWN5LnF1b3RlX2NvdW50KSxcbiAgICB2aWV3X2NvdW50OiB2aWV3Q291bnQsXG4gICAgYm9va21hcmtfY291bnQ6IG51bU9yTnVsbChsZWdhY3kuYm9va21hcmtfY291bnQpLFxuICAgIGVuZ2FnZW1lbnRfaGlzdG9yeTogW1xuICAgICAge1xuICAgICAgICBjYXB0dXJlZF9hdDogY3R4LmNhcHR1cmVkQXQsXG4gICAgICAgIGxpa2VzOiBudW1Pclplcm8oZW5nTGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcbiAgICAgICAgcmV0d2VldHM6IG51bU9yWmVybyhsZWdhY3kucmV0d2VldF9jb3VudCksXG4gICAgICAgIHJlcGxpZXM6IG51bU9yWmVybyhlbmdMZWdhY3kucmVwbHlfY291bnQpLFxuICAgICAgICBxdW90ZXM6IG51bU9yWmVybyhlbmdMZWdhY3kucXVvdGVfY291bnQpLFxuICAgICAgICB2aWV3czogdmlld0NvdW50LFxuICAgICAgICBib29rbWFya3M6IG51bU9yTnVsbChsZWdhY3kuYm9va21hcmtfY291bnQpLFxuICAgICAgfSxcbiAgICBdLFxuICAgIGF1dGhvcixcbiAgICBjb21tdW5pdHlfbm90ZTogY29tbXVuaXR5Tm90ZSxcbiAgICBpc190cnVuY2F0ZWQ6IGlzVHJ1bmNhdGVkLFxuICAgIHdheWJhY2tfdXJsOiBudWxsLFxuICAgIHdheWJhY2tfc3VibWl0dGVkX2F0OiBudWxsLFxuICAgIGNhcHR1cmVfc291cmNlOiAnZXh0ZW5zaW9uJyxcbiAgICBjYXB0dXJlX3J1bl9pZDogY3R4LnJ1bklkLFxuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICB9O1xuXG4gIHJldHVybiB0d2VldDtcbn1cblxuZnVuY3Rpb24gY2xhc3NpZnlUd2VldFR5cGUodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldFR5cGUge1xuICBpZiAobGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfcmVzdWx0IHx8IGxlZ2FjeS5yZXR3ZWV0ZWRfc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXR3ZWV0JztcbiAgaWYgKGxlZ2FjeS5pbl9yZXBseV90b19zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JlcGx5JztcbiAgaWYgKGxlZ2FjeS5pc19xdW90ZV9zdGF0dXMgPT09IHRydWUgfHwgbGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3F1b3RlJztcbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJykge1xuICAgIC8vIHBhc3MgdGhyb3VnaFxuICB9XG4gIHJldHVybiAnb3JpZ2luYWwnO1xufVxuXG5mdW5jdGlvbiBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nW10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy5oYXNodGFncztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgcmV0dXJuIGFyclxuICAgIC5tYXAoKGgpID0+XG4gICAgICB0eXBlb2YgaCA9PT0gJ29iamVjdCcgJiYgaCAmJiAndGV4dCcgaW4gaCA/IFN0cmluZygoaCBhcyB7IHRleHQ6IHVua25vd24gfSkudGV4dCkgOiBudWxsXG4gICAgKVxuICAgIC5maWx0ZXIoKHMpOiBzIGlzIHN0cmluZyA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdE1lbnRpb25zKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZ1tdIHtcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXNlcl9tZW50aW9ucztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcbiAgcmV0dXJuIGFyclxuICAgIC5tYXAoKHUpID0+XG4gICAgICB0eXBlb2YgdSA9PT0gJ29iamVjdCcgJiYgdSAmJiAnc2NyZWVuX25hbWUnIGluIHVcbiAgICAgICAgPyBTdHJpbmcoKHUgYXMgeyBzY3JlZW5fbmFtZTogdW5rbm93biB9KS5zY3JlZW5fbmFtZSlcbiAgICAgICAgOiBudWxsXG4gICAgKVxuICAgIC5maWx0ZXIoKHMpOiBzIGlzIHN0cmluZyA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZycgJiYgcy5sZW5ndGggPiAwKTtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdFVybHMoZW50aXRpZXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogVXJsRW50aXR5W10ge1xuICBjb25zdCBhcnIgPSBlbnRpdGllcy51cmxzO1xuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xuICBjb25zdCBvdXQ6IFVybEVudGl0eVtdID0gW107XG4gIGZvciAoY29uc3QgdSBvZiBhcnIpIHtcbiAgICBpZiAodHlwZW9mIHUgIT09ICdvYmplY3QnIHx8IHUgPT09IG51bGwpIGNvbnRpbnVlO1xuICAgIGNvbnN0IG8gPSB1IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIGNvbnN0IHNob3J0ID0gc3RyT3JOdWxsKG8udXJsKTtcbiAgICBjb25zdCBleHBhbmRlZCA9IHN0ck9yTnVsbChvLmV4cGFuZGVkX3VybCk7XG4gICAgY29uc3QgZGlzcGxheSA9IHN0ck9yTnVsbChvLmRpc3BsYXlfdXJsKTtcbiAgICBpZiAoIXNob3J0IHx8ICFleHBhbmRlZCkgY29udGludWU7XG4gICAgb3V0LnB1c2goeyBzaG9ydCwgZXhwYW5kZWQsIGRpc3BsYXk6IGRpc3BsYXkgPz8gZXhwYW5kZWQgfSk7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdE1lZGlhKGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW1bXSB7XG4gIGNvbnN0IGV4dGVuZGVkID0gb2JqKGxlZ2FjeS5leHRlbmRlZF9lbnRpdGllcyk7XG4gIGNvbnN0IGZyb21FeHQgPSBleHRlbmRlZCA/IHRvQXJyYXkoZXh0ZW5kZWQubWVkaWEpIDogW107XG4gIGNvbnN0IGZyb21FbnQgPSB0b0FycmF5KG9iaihsZWdhY3kuZW50aXRpZXMpPy5tZWRpYSk7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgbWVyZ2VkID0gWy4uLmZyb21FeHQsIC4uLmZyb21FbnRdLmZpbHRlcigobSkgPT4ge1xuICAgIGlmICh0eXBlb2YgbSAhPT0gJ29iamVjdCcgfHwgbSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IGlkID1cbiAgICAgIHN0ck9yTnVsbCgobSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikubWVkaWFfa2V5KSA/P1xuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5pZF9zdHIpO1xuICAgIGlmICghaWQpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoc2Vlbi5oYXMoaWQpKSByZXR1cm4gZmFsc2U7XG4gICAgc2Vlbi5hZGQoaWQpO1xuICAgIHJldHVybiB0cnVlO1xuICB9KTtcbiAgcmV0dXJuIG1lcmdlZC5tYXAoKHJhdykgPT4gYnVpbGRNZWRpYShyYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKTtcbn1cblxuZnVuY3Rpb24gYnVpbGRNZWRpYShtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbSB7XG4gIGNvbnN0IHR5cGUgPSBzdHJPck51bGwobS50eXBlKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXTtcbiAgY29uc3Qgb3JpZ2luYWwgPSBwaWNrT3JpZ2luYWxVcmwobSwgdHlwZSk7XG4gIGNvbnN0IGluZm8gPSBvYmoobS5vcmlnaW5hbF9pbmZvKTtcbiAgY29uc3QgdmlkZW9JbmZvID0gb2JqKG0udmlkZW9faW5mbyk7XG4gIGNvbnN0IGR1cmF0aW9uTXMgPSBudW1Pck51bGwodmlkZW9JbmZvPy5kdXJhdGlvbl9taWxsaXMpO1xuICBjb25zdCBhbHRUZXh0ID0gc3RyT3JOdWxsKG0uZXh0X2FsdF90ZXh0KTtcbiAgY29uc3QgbWVkaWFJZCA9XG4gICAgc3RyT3JOdWxsKG0ubWVkaWFfa2V5KSA/P1xuICAgIHN0ck9yTnVsbChtLmlkX3N0cikgPz9cbiAgICBgJHt0eXBlID8/ICdtZWRpYSd9LSR7TWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMil9YDtcbiAgcmV0dXJuIHtcbiAgICBtZWRpYV9pZDogbWVkaWFJZCxcbiAgICBtZWRpYV90eXBlOiAodHlwZSA/PyAncGhvdG8nKSBhcyBNZWRpYUl0ZW1bJ21lZGlhX3R5cGUnXSxcbiAgICBvcmlnaW5hbF91cmw6IG9yaWdpbmFsID8/ICcnLFxuICAgIHJlbGVhc2VfYXNzZXRfdXJsOiBudWxsLFxuICAgIHNoYTI1NjogbnVsbCxcbiAgICBieXRlczogbnVsbCxcbiAgICBkdXJhdGlvbl9zZWM6IGR1cmF0aW9uTXMgIT09IG51bGwgPyBkdXJhdGlvbk1zIC8gMTAwMCA6IG51bGwsXG4gICAgd2lkdGg6IG51bU9yTnVsbChpbmZvPy53aWR0aCksXG4gICAgaGVpZ2h0OiBudW1Pck51bGwoaW5mbz8uaGVpZ2h0KSxcbiAgICBhbHRfdGV4dDogYWx0VGV4dCxcbiAgICBhcmNoaXZlX3N0YXR1czogJ3BlbmRpbmcnLFxuICAgIGFyY2hpdmVfYXR0ZW1wdHM6IDAsXG4gICAgbGFzdF9hdHRlbXB0X2F0OiBudWxsLFxuICB9O1xufVxuXG5mdW5jdGlvbiBwaWNrT3JpZ2luYWxVcmwobTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIHR5cGU6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcbiAgaWYgKHR5cGUgPT09ICdwaG90bycpIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpID8/IHN0ck9yTnVsbChtLm1lZGlhX3VybCk7XG4gIGNvbnN0IHZhcmlhbnRzID0gdG9BcnJheShvYmoobS52aWRlb19pbmZvKT8udmFyaWFudHMpIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+W107XG4gIGlmICh2YXJpYW50cy5sZW5ndGggPT09IDApIHJldHVybiBzdHJPck51bGwobS5tZWRpYV91cmxfaHR0cHMpO1xuICAvLyBIaWdoZXN0LWJpdHJhdGUgbXA0LlxuICBsZXQgYmVzdDogeyB1cmw6IHN0cmluZzsgYml0cmF0ZTogbnVtYmVyIH0gfCBudWxsID0gbnVsbDtcbiAgZm9yIChjb25zdCB2IG9mIHZhcmlhbnRzKSB7XG4gICAgY29uc3QgY3QgPSBzdHJPck51bGwodi5jb250ZW50X3R5cGUpO1xuICAgIGNvbnN0IHVybCA9IHN0ck9yTnVsbCh2LnVybCk7XG4gICAgaWYgKCF1cmwpIGNvbnRpbnVlO1xuICAgIGlmIChjdCA9PT0gJ3ZpZGVvL21wNCcpIHtcbiAgICAgIGNvbnN0IGJyID0gbnVtT3JOdWxsKHYuYml0cmF0ZSkgPz8gMDtcbiAgICAgIGlmICghYmVzdCB8fCBiciA+IGJlc3QuYml0cmF0ZSkgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiBiciB9O1xuICAgIH0gZWxzZSBpZiAoIWJlc3QpIHtcbiAgICAgIC8vIEZhbGxiYWNrIHRvIGFueSB2YXJpYW50IGlmIG5vIG1wNCBmb3VuZC5cbiAgICAgIGJlc3QgPSB7IHVybCwgYml0cmF0ZTogMCB9O1xuICAgIH1cbiAgfVxuICByZXR1cm4gYmVzdD8udXJsID8/IG51bGw7XG59XG5cbmZ1bmN0aW9uIHJlc29sdmVTaG9ydFVybHModGV4dDogc3RyaW5nLCB1cmxzOiBVcmxFbnRpdHlbXSk6IHN0cmluZyB7XG4gIGlmICh1cmxzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHRleHQ7XG4gIGxldCBvdXQgPSB0ZXh0O1xuICBmb3IgKGNvbnN0IHUgb2YgdXJscykgb3V0ID0gb3V0LnNwbGl0KHUuc2hvcnQpLmpvaW4odS5leHBhbmRlZCk7XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIHBhcnNlVHdpdHRlckRhdGUoczogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAoIXMpIHJldHVybiBudWxsO1xuICAvLyBUd2l0dGVyIHNoaXBzIGRhdGVzIGxpa2UgXCJNb24gQXByIDEyIDE0OjIzOjAxICswMDAwIDIwMjVcIi5cbiAgY29uc3QgZCA9IG5ldyBEYXRlKHMpO1xuICBpZiAoTnVtYmVyLmlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiBkLnRvSVNPU3RyaW5nKCk7XG59XG5cbmZ1bmN0aW9uIHN0ck9yTnVsbCh2OiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwID8gdiA6IG51bGw7XG59XG5mdW5jdGlvbiBib29sT3JOdWxsKHY6IHVua25vd24pOiBib29sZWFuIHwgbnVsbCB7XG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nID8gdiA6IG51bGw7XG59XG5mdW5jdGlvbiBudW1Pck51bGwodjogdW5rbm93bik6IG51bWJlciB8IG51bGwge1xuICBpZiAodHlwZW9mIHYgPT09ICdudW1iZXInICYmIE51bWJlci5pc0Zpbml0ZSh2KSkgcmV0dXJuIHY7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IE51bWJlcih2KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKG4pKSByZXR1cm4gbjtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIG51bU9yWmVybyh2OiB1bmtub3duKTogbnVtYmVyIHtcbiAgcmV0dXJuIG51bU9yTnVsbCh2KSA/PyAwO1xufVxuZnVuY3Rpb24gb2JqKHY6IHVua25vd24pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwge1xuICByZXR1cm4gdHlwZW9mIHYgPT09ICdvYmplY3QnICYmIHYgIT09IG51bGwgJiYgIUFycmF5LmlzQXJyYXkodilcbiAgICA/ICh2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVxuICAgIDogbnVsbDtcbn1cbmZ1bmN0aW9uIHRvQXJyYXkodjogdW5rbm93bik6IHVua25vd25bXSB7XG4gIHJldHVybiBBcnJheS5pc0FycmF5KHYpID8gdiA6IFtdO1xufVxuXG4vKipcbiAqIERlY2lkZSB3aGV0aGVyIGEgdHdlZXQncyBhcmNoaXZlZCBgdGV4dGAgaXMgdGhlIHRydW5jYXRlZCBoZWFkIG9mIGEgbG9uZ2VyXG4gKiBib2R5LiBBIHRydW5jYXRlZCB0d2VldCBoYXMgWCdzIFwiU2hvdyBtb3JlXCIgdC5jbyBVUkwgYXBwZW5kZWQgXHUyMDE0IHRoYXQgVVJMXG4gKiBzcGVjaWZpY2FsbHkgZXhwYW5kcyB0byB0aGUgdHdlZXQncyBvd24gL2kvd2ViL3N0YXR1cy88aWQ+IHBlcm1hbGluaywgYW5kXG4gKiBpcyB0aGUgb25seSByZWxpYWJsZSBkaXN0aW5ndWlzaGluZyBmZWF0dXJlLiBQbGVudHkgb2Ygbm9ybWFsIHR3ZWV0cyBoYXZlXG4gKiB0cmFpbGluZyB0LmNvIFVSTHMgKG1lZGlhLCBxdW90ZXMsIHJlZ3VsYXIgbGlua3MpLCBhbmQgdGhlaXJcbiAqIGRpc3BsYXlfdGV4dF9yYW5nZSBhbHNvIHRyaW1zIHBhc3QgZnVsbF90ZXh0Lmxlbmd0aCwgc28gdGhlIG9sZFxuICogXCJkaXNwbGF5X3RleHRfcmFuZ2VbMV0gPCBmdWxsX3RleHQubGVuZ3RoXCIgaGV1cmlzdGljIHdhcyBvdmVyZmxhZ2dpbmdcbiAqIGVzc2VudGlhbGx5IGV2ZXJ5IHR3ZWV0IHdpdGggYSBsaW5rIGluIGl0LlxuICpcbiAqIFJ1bGVzOlxuICogICAtIG5vdGVfdHdlZXQgcHJlc2VudCAgXHUyMTkyIG5vdCB0cnVuY2F0ZWQgKHdlIGFscmVhZHkgaGF2ZSB0aGUgZnVsbCBib2R5KS5cbiAqICAgLSBPbmUgb2YgbGVnYWN5LmVudGl0aWVzLnVybHMgaGFzIGFuIGV4cGFuZGVkX3VybCBsaWtlXG4gKiAgICAgXCIuLi4vaS93ZWIvc3RhdHVzLzxpZD5cIiAgXHUyMTkyICB0cnVuY2F0ZWQuXG4gKiAgIC0gT3RoZXJ3aXNlIFx1MjE5MiBub3QgdHJ1bmNhdGVkLlxuICpcbiAqIFRoZSBwcmV2aW91cyBmYWxsYmFjayAoXCJ0cmFpbGluZyB0LmNvIFVSTCArIGxlbmd0aCBcdTIyNjUgMjcwXCIpIGZsYWdnZWQgZXZlcnlcbiAqIG1lZGlhIHR3ZWV0IGV4YWN0bHkgYXQgdGhlIDI4MC1jaGFyIGxpbWl0LiBXZSBkcm9wIGl0IGVudGlyZWx5OyB0aGUgb25seVxuICogY29zdCBpcyBtaXNzaW5nIGdlbnVpbmVseS10cnVuY2F0ZWQgdHdlZXRzIHdob3NlIHBheWxvYWQgd2FzIHNvIGRlZ3JhZGVkXG4gKiBpdCBsYWNrZWQgZW50aXRpZXMgXHUyMDE0IHdoaWNoIGlzIGFsc28gd2hlcmUgdGhlIHJlZmV0Y2ggbG9vcCB3b3VsZCBmYWlsXG4gKiBhbnl3YXksIHNvIG5vdGhpbmcgaXMgYWN0dWFsbHkgbG9zdC5cbiAqL1xuZnVuY3Rpb24gZGV0ZWN0VHJ1bmNhdGlvbihcbiAgbm90ZVR3ZWV0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gIGZ1bGxUZXh0OiBzdHJpbmdcbik6IGJvb2xlYW4ge1xuICBpZiAobm90ZVR3ZWV0KSByZXR1cm4gZmFsc2U7XG4gIGlmICghZnVsbFRleHQpIHJldHVybiBmYWxzZTtcbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKTtcbiAgY29uc3QgdXJscyA9IGVudGl0aWVzID8gZW50aXRpZXMudXJscyA6IG51bGw7XG4gIGlmIChBcnJheS5pc0FycmF5KHVybHMpKSB7XG4gICAgZm9yIChjb25zdCB1IG9mIHVybHMpIHtcbiAgICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XG4gICAgICBjb25zdCBleHAgPSAodSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikuZXhwYW5kZWRfdXJsO1xuICAgICAgLy8gVGhlIFwiU2hvdyBtb3JlXCIgbGluayBleHBhbmRzIHRvIGVpdGhlciBvZiB0aGVzZSBzZWxmLXBlcm1hbGlua1xuICAgICAgLy8gc2hhcGVzOiAgaHR0cHM6Ly94LmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxuICAgICAgLy8gICAgICAgICAgaHR0cHM6Ly90d2l0dGVyLmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxuICAgICAgaWYgKHR5cGVvZiBleHAgPT09ICdzdHJpbmcnICYmIC9cXC9pXFwvd2ViXFwvc3RhdHVzXFwvXFxkKy8udGVzdChleHApKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbi8qKlxuICogRmlsdGVyIGB0d2VldHNgIGRvd24gdG8gdGhvc2UgcmVsYXRlZCB0byBhIHRyYWNrZWQgYWNjb3VudC4gQSB0d2VldCBpc1xuICogXCJyZWxhdGVkXCIgaWYgYW55IG9mIHRoZSBmb2xsb3dpbmcgaG9sZDpcbiAqXG4gKiAgIC0gaXRzIGF1dGhvciBpcyB0cmFja2VkIChoYW5kbGUgaW4gYHRhcmdldGVkYCksXG4gKiAgIC0gaXRzIGF1dGhvciBpcyBjb3JlIChoYW5kbGUgaW4gYGNvcmVIYW5kbGVzYCksIHJlZ2FyZGxlc3Mgb2Ygd2hlcmUgWFxuICogICAgIHN1cmZhY2VkIGl0LFxuICogICAtIGl0IG1lbnRpb25zIGEgdHJhY2tlZCBoYW5kbGUsXG4gKiAgIC0gaXQgcmVwbGllcyB0byBhIHRyYWNrZWQgYWNjb3VudCxcbiAqICAgLSBpdCBxdW90ZXMvcmVwbGllcy10byBhIHR3ZWV0IHRoYXQncyBhbHNvIHByZXNlbnQgaW4gdGhlXG4gKiAgICAgYmF0Y2ggKmFuZCogYXV0aG9yZWQgYnkgYSB0cmFja2VkIGFjY291bnQgKHRyYW5zaXRpdmVseSByZWxhdGVkIFx1MjAxNFxuICogICAgIGNhcHR1cmVzIHF1b3RlZC9yZXBseSBjb250ZXh0IHRoYXQgYXBwZWFycyBhcyBhIHNpYmxpbmcgbm9kZSBpbiB0aGVcbiAqICAgICBzYW1lIEdyYXBoUUwgcmVzcG9uc2UpLlxuICpcbiAqIE5vbi1jb3JlIHJldHdlZXQgd3JhcHBlcnMgYXJlIG5vdCBrZXB0IG1lcmVseSBiZWNhdXNlIHRoZXkgcmV0d2VldGVkIGFcbiAqIHRyYWNrZWQvY29yZSB0d2VldC4gVGhlIHVuZGVybHlpbmcgY29yZSB0d2VldCBpcyBrZXB0IGFzIGl0cyBvd24gcm93IHdoZW5cbiAqIHByZXNlbnQgaW4gdGhlIHBheWxvYWQuXG4gKlxuICogQW55dGhpbmcgZWxzZSAocmFuZG9tIHJlcGxpZXMgdW5kZXIgYSB0cmFja2VkIGFjY291bnQncyB0d2VldCwgcmFuZG9tXG4gKiBhdXRob3JzIHRoYXQgaGFwcGVuIHRvIHN1cmZhY2UgaW4gYSB0cmFja2VkIGFjY291bnQncyB0aHJlYWQpIGlzIGRyb3BwZWQuXG4gKiBQYXNzIGFuIGVtcHR5IGB0YXJnZXRlZGAgc2V0IHRvIGRpc2FibGUgZmlsdGVyaW5nIGVudGlyZWx5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyUmVsYXRlZChcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdLFxuICB0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPixcbiAgY29yZUhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KClcbik6IENhbm9uaWNhbFR3ZWV0W10ge1xuICBpZiAodGFyZ2V0ZWQuc2l6ZSA9PT0gMCAmJiBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm4gdHdlZXRzO1xuICAvLyBGaXJzdCBwYXNzOiB3aGljaCB0d2VldCBJRHMgZG8gdHJhY2tlZC1hdXRob3IgdHdlZXRzIHJlZmVyZW5jZSAodGhlXG4gIC8vIFwiZm9yd2FyZFwiIGRpcmVjdGlvbiBcdTIwMTQgdHJhY2tlZCBhY2NvdW50IHF1b3RlcyAvIFJUcyAvIHJlcGxpZXMgdG8gWCk/XG4gIC8vIEFuZCB3aGljaCB0d2VldCBJRHMgQVJFIHRyYWNrZWQtYXV0aG9yZWQgKHRoZSBcInJldmVyc2VcIiBkaXJlY3Rpb24gXHUyMDE0XG4gIC8vIFggcXVvdGVzIC8gUlRzIC8gcmVwbGllcyB0byBhIHRyYWNrZWQgdHdlZXQpP1xuICBjb25zdCByZWZlcmVuY2VkSWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHRhcmdldGVkVHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgIGlmICghdGFyZ2V0ZWQuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIGNvbnRpbnVlO1xuICAgIHRhcmdldGVkVHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xuICAgIGlmICh0LnF1b3RlZF90d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5xdW90ZWRfdHdlZXRfaWQpO1xuICAgIGlmICh0LnJldHdlZXRlZF90d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpO1xuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkKSByZWZlcmVuY2VkSWRzLmFkZCh0LnJlcGx5X3RvX3R3ZWV0X2lkKTtcbiAgfVxuICByZXR1cm4gdHdlZXRzLmZpbHRlcigodCkgPT4ge1xuICAgIGNvbnN0IGggPSB0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKHRhcmdldGVkLmhhcyhoKSkgcmV0dXJuIHRydWU7XG4gICAgaWYgKGNvcmVIYW5kbGVzLmhhcyhoKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gRm9yd2FyZDogYSB0cmFja2VkLWF1dGhvciB0d2VldCBwb2ludGVkIGF0IHRoaXMgb25lLlxuICAgIGlmIChyZWZlcmVuY2VkSWRzLmhhcyh0LnR3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gUmV2ZXJzZTogdGhpcyB0d2VldCBxdW90ZXMvcmVwbGllcyB0byBhIHRyYWNrZWQtYXV0aG9yIHR3ZWV0IGluIHRoZVxuICAgIC8vIGJhdGNoLiBSZXZlcnNlIHJldHdlZXRzIGFyZSBqdXN0IFwibm9uLWNvcmUgYWNjb3VudCByZXR3ZWV0ZWQgY29yZVxuICAgIC8vIHR3ZWV0XCIgd3JhcHBlcnMsIGFuZCBkbyBub3QgYWRkIGNvcmUgYXJjaGl2ZSB2YWx1ZS5cbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQgJiYgdGFyZ2V0ZWRUd2VldElkcy5oYXModC5xdW90ZWRfdHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCAmJiB0YXJnZXRlZFR3ZWV0SWRzLmhhcyh0LnJlcGx5X3RvX3R3ZWV0X2lkKSkgcmV0dXJuIHRydWU7XG4gICAgLy8gUmVwbHktdG8tYWNjb3VudCBvciBtZW50aW9ucyBhIHRyYWNrZWQgaGFuZGxlLlxuICAgIGlmICh0LnJlcGx5X3RvX2FjY291bnQgJiYgdGFyZ2V0ZWQuaGFzKHQucmVwbHlfdG9fYWNjb3VudC50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIHRydWU7XG4gICAgZm9yIChjb25zdCBtIG9mIHQubWVudGlvbnMpIHtcbiAgICAgIGlmICh0YXJnZXRlZC5oYXMobS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfSk7XG59XG5cbi8qKlxuICogUHVsbCB0aGUgQ29tbXVuaXR5IE5vdGUgKGZvcm1lcmx5IEJpcmR3YXRjaCkgYmxvY2sgYXR0YWNoZWQgdG8gYSB0d2VldCwgaWZcbiAqIGFueS4gVGhlIHBpdm90IGNhbiBsaXZlIGF0IGB0d2VldC5sZWdhY3kuYmlyZHdhdGNoX3Bpdm90YCAob2xkZXIgc2hhcGUpIG9yXG4gKiBgdHdlZXQuYmlyZHdhdGNoX3Bpdm90YCAoY3VycmVudCBzaGFwZSkuIFRoZSBzdW1tYXJ5IHRleHQgaXMgd2hhdCByZWFkZXJzXG4gKiBhY3R1YWxseSBzZWU7IHdlIGtlZXAgdGhlIHN1cnJvdW5kaW5nIG1ldGFkYXRhIHNvIGRvd25zdHJlYW0gdG9vbGluZyBjYW5cbiAqIHRlbGwgZHJhZnRzIGFwYXJ0IGZyb20gcmF0ZWQtaGVscGZ1bCBub3Rlcy5cbiAqL1xuZnVuY3Rpb24gZXh0cmFjdENvbW11bml0eU5vdGUoXG4gIHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICBsZWdhY3k6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuICBvYnNlcnZlZEF0OiBzdHJpbmdcbik6IENvbW11bml0eU5vdGUgfCBudWxsIHtcbiAgY29uc3QgcGl2b3QgPSBvYmoodC5iaXJkd2F0Y2hfcGl2b3QpID8/IG9iaihsZWdhY3kuYmlyZHdhdGNoX3Bpdm90KTtcbiAgaWYgKCFwaXZvdCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHN1YnRpdGxlID0gb2JqKHBpdm90LnN1YnRpdGxlKTtcbiAgY29uc3Qgbm90ZSA9IG9iaihwaXZvdC5ub3RlKTtcbiAgY29uc3Qgc3VtbWFyeSA9IHN0ck9yTnVsbChzdWJ0aXRsZT8udGV4dCk7XG4gIGNvbnN0IHRpdGxlID0gc3RyT3JOdWxsKHBpdm90LnRpdGxlKTtcbiAgY29uc3Qgc2hvcnRUaXRsZSA9IHN0ck9yTnVsbChwaXZvdC5zaG9ydFRpdGxlKTtcbiAgY29uc3QgZGVzdGluYXRpb25VcmwgPSBzdHJPck51bGwocGl2b3QuZGVzdGluYXRpb25VcmwpO1xuICBjb25zdCBub3RlSWQgPSBzdHJPck51bGwocGl2b3Qubm90ZUlkKSA/PyBzdHJPck51bGwobm90ZT8ucmVzdF9pZCk7XG4gIC8vIFNraXAgZW1wdHkgc2hlbGxzIHRoYXQgaGF2ZSBubyBhY3R1YWwgY29udGVudC5cbiAgaWYgKCFzdW1tYXJ5ICYmICF0aXRsZSAmJiAhbm90ZUlkKSByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHtcbiAgICBub3RlX2lkOiBub3RlSWQsXG4gICAgdGl0bGUsXG4gICAgc2hvcnRfdGl0bGU6IHNob3J0VGl0bGUsXG4gICAgc3VtbWFyeSxcbiAgICBkZXN0aW5hdGlvbl91cmw6IGRlc3RpbmF0aW9uVXJsLFxuICAgIG9ic2VydmVkX2F0OiBvYnNlcnZlZEF0LFxuICB9O1xufVxuXG4vKipcbiAqIFB1bGwgYSBwZXItYXV0aG9yIFVzZXJTbmFwc2hvdCBmcm9tIHRoZSB0d2VldCdzIHVzZXJfcmVzdWx0cyBub2RlLiBFdmVyeVxuICogZmllbGQgZGVmYXVsdHMgdG8gbnVsbCB3aGVuIG1pc3Npbmcgc28gdGhlIHNjaGVtYSBzdGF5cyBzdGFibGUgYWNyb3NzXG4gKiB0aGUgbGVnYWN5IC8gY29yZSBzaGFwZSBtaWdyYXRpb25zIFggaGFzIGJlZW4gZG9pbmcuXG4gKi9cbmZ1bmN0aW9uIGV4dHJhY3RVc2VyU25hcHNob3QoXG4gIHVzZXJSZXN1bHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgdXNlckNvcmVOZXc6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcbiAgdXNlckxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxuICB1c2VyQXZhdGFyT2JqOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGxcbik6IFVzZXJTbmFwc2hvdCB7XG4gIGNvbnN0IHZlcmlmaWNhdGlvbiA9IG9iaih1c2VyUmVzdWx0Py52ZXJpZmljYXRpb24pO1xuICByZXR1cm4ge1xuICAgIGRpc3BsYXlfbmFtZTpcbiAgICAgIHN0ck9yTnVsbCh1c2VyQ29yZU5ldz8ubmFtZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/Lm5hbWUpID8/IHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5uYW1lKSxcbiAgICBhdmF0YXJfdXJsOlxuICAgICAgc3RyT3JOdWxsKHVzZXJBdmF0YXJPYmo/LmltYWdlX3VybCkgPz9cbiAgICAgIHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5wcm9maWxlX2ltYWdlX3VybF9odHRwcykgPz9cbiAgICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5wcm9maWxlX2ltYWdlX3VybF9odHRwcyksXG4gICAgdmVyaWZpZWQ6IGJvb2xPck51bGwodmVyaWZpY2F0aW9uPy52ZXJpZmllZCkgPz8gYm9vbE9yTnVsbCh1c2VyTGVnYWN5Py52ZXJpZmllZCksXG4gICAgaXNfYmx1ZV92ZXJpZmllZDogYm9vbE9yTnVsbCh1c2VyUmVzdWx0Py5pc19ibHVlX3ZlcmlmaWVkKSxcbiAgICB2ZXJpZmllZF90eXBlOiBzdHJPck51bGwodmVyaWZpY2F0aW9uPy52ZXJpZmllZF90eXBlKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8udmVyaWZpZWRfdHlwZSksXG4gICAgZGVzY3JpcHRpb246IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5kZXNjcmlwdGlvbiksXG4gICAgbG9jYXRpb246IHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubG9jYXRpb24pPy5sb2NhdGlvbikgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmxvY2F0aW9uKSxcbiAgICB1cmw6IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py51cmwpLFxuICAgIGZvbGxvd2Vyc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZvbGxvd2Vyc19jb3VudCksXG4gICAgZnJpZW5kc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZyaWVuZHNfY291bnQpLFxuICAgIHN0YXR1c2VzX2NvdW50OiBudW1Pck51bGwodXNlckxlZ2FjeT8uc3RhdHVzZXNfY291bnQpLFxuICAgIGFjY291bnRfY3JlYXRlZF9hdDpcbiAgICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5jcmVhdGVkX2F0KSkgPz9cbiAgICAgIHBhcnNlVHdpdHRlckRhdGUoc3RyT3JOdWxsKHVzZXJMZWdhY3k/LmNyZWF0ZWRfYXQpKSxcbiAgICBwcm90ZWN0ZWQ6IGJvb2xPck51bGwodXNlckxlZ2FjeT8ucHJvdGVjdGVkKSxcbiAgfTtcbn1cblxuLyoqXG4gKiBXYWxrIHRoZSB0d2VldCdzIGBjYXJkLmxlZ2FjeS5iaW5kaW5nX3ZhbHVlc2AgKGtleS92YWx1ZSBhcnJheSkgaW50byBhXG4gKiBmbGF0IFR3ZWV0Q2FyZCB3aXRoIHRpdGxlLCBkZXNjcmlwdGlvbiwgYW5kIGEgcmVwcmVzZW50YXRpdmUgaW1hZ2UgVVJMLlxuICogUmV0dXJucyBudWxsIHdoZW4gdGhlIHR3ZWV0IGhhcyBubyBjYXJkLlxuICovXG5mdW5jdGlvbiBleHRyYWN0Q2FyZCh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFR3ZWV0Q2FyZCB8IG51bGwge1xuICBjb25zdCBjYXJkID0gb2JqKHQuY2FyZCk7XG4gIGNvbnN0IGNhcmRMZWdhY3kgPSBvYmooY2FyZD8ubGVnYWN5KTtcbiAgaWYgKCFjYXJkTGVnYWN5KSByZXR1cm4gbnVsbDtcbiAgY29uc3QgYmluZGluZ3MgPSBjYXJkTGVnYWN5LmJpbmRpbmdfdmFsdWVzO1xuICBjb25zdCBieUtleTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gPSB7fTtcbiAgaWYgKEFycmF5LmlzQXJyYXkoYmluZGluZ3MpKSB7XG4gICAgZm9yIChjb25zdCBidiBvZiBiaW5kaW5ncykge1xuICAgICAgaWYgKHR5cGVvZiBidiAhPT0gJ29iamVjdCcgfHwgYnYgPT09IG51bGwpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgbyA9IGJ2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgY29uc3QgayA9IHN0ck9yTnVsbChvLmtleSk7XG4gICAgICBjb25zdCB2ID0gb2JqKG8udmFsdWUpO1xuICAgICAgaWYgKCFrIHx8ICF2KSBjb250aW51ZTtcbiAgICAgIGJ5S2V5W2tdID1cbiAgICAgICAgc3RyT3JOdWxsKHYuc3RyaW5nX3ZhbHVlKSA/P1xuICAgICAgICBzdHJPck51bGwob2JqKHYuaW1hZ2VfdmFsdWUpPy51cmwpID8/XG4gICAgICAgIHN0ck9yTnVsbChvYmoodi5pbWFnZV9jb2xvcl92YWx1ZSk/LnBhbGV0dGUpO1xuICAgIH1cbiAgfVxuICBjb25zdCBuYW1lID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kubmFtZSk7XG4gIGNvbnN0IGNhcmRVcmwgPSBzdHJPck51bGwoY2FyZExlZ2FjeS51cmwpO1xuICBjb25zdCB2ZW5kb3JVcmwgPVxuICAgIHR5cGVvZiBieUtleVsndmFuaXR5X3VybCddID09PSAnc3RyaW5nJyA/IChieUtleVsndmFuaXR5X3VybCddIGFzIHN0cmluZykgOiBudWxsO1xuICBjb25zdCB0aXRsZSA9IHR5cGVvZiBieUtleVsndGl0bGUnXSA9PT0gJ3N0cmluZycgPyAoYnlLZXlbJ3RpdGxlJ10gYXMgc3RyaW5nKSA6IG51bGw7XG4gIGNvbnN0IGRlc2NyaXB0aW9uID1cbiAgICB0eXBlb2YgYnlLZXlbJ2Rlc2NyaXB0aW9uJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5WydkZXNjcmlwdGlvbiddIGFzIHN0cmluZykgOiBudWxsO1xuICBjb25zdCBpbWFnZVVybCA9XG4gICAgKHR5cGVvZiBieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXG4gICAgICA/IChieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxuICAgICAgOiBudWxsKSA/P1xuICAgICh0eXBlb2YgYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xuICAgICAgPyAoYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcbiAgICAgIDogbnVsbCkgPz9cbiAgICAodHlwZW9mIGJ5S2V5WydzdW1tYXJ5X3Bob3RvX2ltYWdlX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXG4gICAgICA/IChieUtleVsnc3VtbWFyeV9waG90b19pbWFnZV9vcmlnaW5hbCddIGFzIHN0cmluZylcbiAgICAgIDogbnVsbCk7XG4gIGlmICghbmFtZSAmJiAhdGl0bGUgJiYgIWRlc2NyaXB0aW9uICYmICFpbWFnZVVybCkgcmV0dXJuIG51bGw7XG4gIHJldHVybiB7XG4gICAgbmFtZSxcbiAgICBjYXJkX3VybDogY2FyZFVybCxcbiAgICB2ZW5kb3JfdXJsOiB2ZW5kb3JVcmwsXG4gICAgdGl0bGUsXG4gICAgZGVzY3JpcHRpb24sXG4gICAgaW1hZ2VfdXJsOiBpbWFnZVVybCxcbiAgfTtcbn1cbiIsICIvKipcbiAqIExpZ2h0d2VpZ2h0IFVMSUQtbGlrZSBpZCBnZW5lcmF0b3I6IDI2LWNoYXJhY3RlciBDcm9ja2ZvcmQgYmFzZTMyIHN0cmluZ1xuICogb2YgKHRpbWVzdGFtcF9tcyB8fCByYW5kb21uZXNzKS4gR29vZCBlbm91Z2ggZm9yIHJ1biBpZGVudGlmaWVycyB3aXRob3V0XG4gKiBwdWxsaW5nIGluIGEgcmVhbCBVTElEIGRlcGVuZGVuY3kuXG4gKi9cblxuY29uc3QgQUxQSEFCRVQgPSAnMDEyMzQ1Njc4OUFCQ0RFRkdISktNTlBRUlNUVldYWVonOyAvLyBDcm9ja2ZvcmRcblxuZXhwb3J0IGZ1bmN0aW9uIG5ld1J1bklkKCk6IHN0cmluZyB7XG4gIGNvbnN0IHRzID0gRGF0ZS5ub3coKTtcbiAgbGV0IHRzUGFydCA9ICcnO1xuICBsZXQgdCA9IHRzO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDEwOyBpKyspIHtcbiAgICB0c1BhcnQgPSAoQUxQSEFCRVRbdCAlIDMyXSA/PyAnMCcpICsgdHNQYXJ0O1xuICAgIHQgPSBNYXRoLmZsb29yKHQgLyAzMik7XG4gIH1cbiAgY29uc3QgcmFuZCA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTApKTtcbiAgbGV0IHJhbmRQYXJ0ID0gJyc7XG4gIGZvciAoY29uc3QgYiBvZiByYW5kKSByYW5kUGFydCArPSBBTFBIQUJFVFtiICUgMzJdID8/ICcwJztcbiAgcmV0dXJuIHRzUGFydCArIHJhbmRQYXJ0O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gc2hvcnRSdW5JZChpZDogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIGlkLnNsaWNlKC04KTtcbn1cbiIsICIvLyBDb3ZlcmFnZS1nYXAgZGV0ZWN0aW9uOiB0dXJuIGFuIGFjY291bnQncyBwZXItbW9udGggcG9zdCBjb3VudHMgKGZyb20gdGhlXG4vLyBhcmNoaXZlIG1hbmlmZXN0KSBpbnRvIGRhdGUgcmFuZ2VzIHRoYXQgYXJlIGVtcHR5IG9yIHVudXN1YWxseSBzcGFyc2UgXHUyMDE0IHRoZVxuLy8gaG9sZXMgYSByZXNlYXJjaGVyIHdvdWxkIHdhbnQgdG8gcGF0Y2ggXHUyMDE0IHBsdXMgdGhlIHJlY2VudCBmcm9udGllciBvZiB0d2VldHNcbi8vIHBvc3RlZCBzaW5jZSB0aGUgbGFzdCBjYXB0dXJlLiBFYWNoIGdhcCBjYXJyaWVzIGEgcmVhZHktdG8tb3BlbiBYIHNlYXJjaFxuLy8gKGBmcm9tOjxoYW5kbGU+IHNpbmNlOjxkPiB1bnRpbDo8ZD5gKSBzbyB0aGUgc2lkZWJhciBjYW4gZHJpdmUgYSB0YXJnZXRlZCxcbi8vIGRhdGUtYm91bmRlZCByZS1zY2FuIGluc3RlYWQgb2YgcmUtd2Fsa2luZyB0aGUgd2hvbGUgdGltZWxpbmUuXG5cbmltcG9ydCB0eXBlIHsgQXJjaGl2ZVNuYXBzaG90QWNjb3VudCwgQ292ZXJhZ2VHYXAgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuY29uc3QgWF9TRUFSQ0hfQkFTRSA9ICdodHRwczovL3guY29tL3NlYXJjaCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgR2FwT3B0aW9ucyB7XG4gIG5vdz86IERhdGU7XG4gIC8qKiBBIG1vbnRoIGJlbG93IGBzcGFyc2VSYXRpbyAqIG1lZGlhbihhY3RpdmUgbW9udGhzKWAgY291bnRzIGFzIHNwYXJzZS4gKi9cbiAgc3BhcnNlUmF0aW8/OiBudW1iZXI7XG4gIC8qKiBOZXZlciBmbGFnIGEgbW9udGggc3BhcnNlIGlmIGl0IGhhcyBhdCBsZWFzdCB0aGlzIG1hbnkgcG9zdHMuICovXG4gIHNwYXJzZUZsb29yPzogbnVtYmVyO1xuICAvKiogT25seSBmbGFnIHNwYXJzZSBtb250aHMgb25jZSB0eXBpY2FsIG1vbnRobHkgdm9sdW1lIGlzIHRoaXMgaGlnaDsgYmVsb3dcbiAgICogaXQsIGFuIGFjY291bnQgaXMgdG9vIGxvdy12b2x1bWUgdG8gY2FsbCBhbnkgbW9udGggXCJzcGFyc2VcIiB3aXRoIG1lYW5pbmcuICovXG4gIG1pbk1lZGlhbkZvclNwYXJzZT86IG51bWJlcjtcbiAgLyoqIFNraXAgdGhlIGludHJhLW1vbnRoIHJlY2VudCBmcm9udGllciBpZiB0aGUgbGFzdCBwb3N0IGlzIG5ld2VyIHRoYW4gdGhpcy4gKi9cbiAgcmVjZW50RnJvbnRpZXJNaW5BZ2VEYXlzPzogbnVtYmVyO1xufVxuXG5mdW5jdGlvbiBtb250aEtleShkOiBEYXRlKTogc3RyaW5nIHtcbiAgcmV0dXJuIGAke2QuZ2V0VVRDRnVsbFllYXIoKX0tJHtTdHJpbmcoZC5nZXRVVENNb250aCgpICsgMSkucGFkU3RhcnQoMiwgJzAnKX1gO1xufVxuXG5mdW5jdGlvbiBwYXJzZU1vbnRoKHltOiBzdHJpbmcpOiBEYXRlIHtcbiAgY29uc3QgcGFydHMgPSB5bS5zcGxpdCgnLScpO1xuICBjb25zdCB5ID0gTnVtYmVyKHBhcnRzWzBdKTtcbiAgY29uc3QgbSA9IE51bWJlcihwYXJ0c1sxXSA/PyAnMScpO1xuICByZXR1cm4gbmV3IERhdGUoRGF0ZS5VVEMoeSwgbSAtIDEsIDEpKTtcbn1cblxuZnVuY3Rpb24gYWRkTW9udGhzKGQ6IERhdGUsIG46IG51bWJlcik6IERhdGUge1xuICByZXR1cm4gbmV3IERhdGUoRGF0ZS5VVEMoZC5nZXRVVENGdWxsWWVhcigpLCBkLmdldFVUQ01vbnRoKCkgKyBuLCAxKSk7XG59XG5cbmZ1bmN0aW9uIGFkZERheXMoZDogRGF0ZSwgbjogbnVtYmVyKTogRGF0ZSB7XG4gIHJldHVybiBuZXcgRGF0ZShkLmdldFRpbWUoKSArIG4gKiA4Nl80MDBfMDAwKTtcbn1cblxuZnVuY3Rpb24gaXNvRGF0ZShkOiBEYXRlKTogc3RyaW5nIHtcbiAgcmV0dXJuIGQudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG59XG5cbmZ1bmN0aW9uIG1lZGlhbihudW1zOiBudW1iZXJbXSk6IG51bWJlciB7XG4gIGlmIChudW1zLmxlbmd0aCA9PT0gMCkgcmV0dXJuIDA7XG4gIGNvbnN0IHMgPSBbLi4ubnVtc10uc29ydCgoYSwgYikgPT4gYSAtIGIpO1xuICBjb25zdCBtaWQgPSBNYXRoLmZsb29yKHMubGVuZ3RoIC8gMik7XG4gIGlmIChzLmxlbmd0aCAlIDIpIHJldHVybiBzW21pZF0gPz8gMDtcbiAgcmV0dXJuICgoc1ttaWQgLSAxXSA/PyAwKSArIChzW21pZF0gPz8gMCkpIC8gMjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdhcFNlYXJjaFVybChoYW5kbGU6IHN0cmluZywgZnJvbURhdGU6IHN0cmluZywgdG9EYXRlOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCBxID0gYGZyb206JHtoYW5kbGV9IHNpbmNlOiR7ZnJvbURhdGV9IHVudGlsOiR7dG9EYXRlfWA7XG4gIHJldHVybiBgJHtYX1NFQVJDSF9CQVNFfT9xPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHEpfSZmPWxpdmVgO1xufVxuXG4vKiogRmluZCBlbXB0eS9zcGFyc2UgbW9udGggcmFuZ2VzIChwbHVzIHRoZSByZWNlbnQgZnJvbnRpZXIpIGZvciBvbmUgYWNjb3VudC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmaW5kQ292ZXJhZ2VHYXBzKFxuICBhY2NvdW50OiBBcmNoaXZlU25hcHNob3RBY2NvdW50LFxuICBvcHRpb25zOiBHYXBPcHRpb25zID0ge31cbik6IENvdmVyYWdlR2FwW10ge1xuICBjb25zdCBub3cgPSBvcHRpb25zLm5vdyA/PyBuZXcgRGF0ZSgpO1xuICBjb25zdCBzcGFyc2VSYXRpbyA9IG9wdGlvbnMuc3BhcnNlUmF0aW8gPz8gMC4yNTtcbiAgY29uc3Qgc3BhcnNlRmxvb3IgPSBvcHRpb25zLnNwYXJzZUZsb29yID8/IDM7XG4gIGNvbnN0IG1pbk1lZGlhbkZvclNwYXJzZSA9IG9wdGlvbnMubWluTWVkaWFuRm9yU3BhcnNlID8/IDg7XG4gIGNvbnN0IHJlY2VudEZyb250aWVyTWluQWdlRGF5cyA9IG9wdGlvbnMucmVjZW50RnJvbnRpZXJNaW5BZ2VEYXlzID8/IDI7XG5cbiAgY29uc3QgbW9udGhzID0gYWNjb3VudC5tb250aHMgPz8ge307XG4gIGlmICghYWNjb3VudC5maXJzdF9wb3N0X2F0KSByZXR1cm4gW107XG4gIGNvbnN0IHN0YXJ0TW9udGggPSBwYXJzZU1vbnRoKGFjY291bnQuZmlyc3RfcG9zdF9hdC5zbGljZSgwLCA3KSk7XG4gIGNvbnN0IGVuZE1vbnRoID0gcGFyc2VNb250aChtb250aEtleShub3cpKTtcblxuICBjb25zdCBzZXE6IHsgeW06IHN0cmluZzsgY291bnQ6IG51bWJlciB9W10gPSBbXTtcbiAgZm9yIChsZXQgZCA9IHN0YXJ0TW9udGg7IGQgPD0gZW5kTW9udGg7IGQgPSBhZGRNb250aHMoZCwgMSkpIHtcbiAgICBjb25zdCB5bSA9IG1vbnRoS2V5KGQpO1xuICAgIHNlcS5wdXNoKHsgeW0sIGNvdW50OiBtb250aHNbeW1dID8/IDAgfSk7XG4gIH1cbiAgaWYgKHNlcS5sZW5ndGggPT09IDApIHJldHVybiBbXTtcblxuICBjb25zdCBhY3RpdmVDb3VudHMgPSBzZXEuZmlsdGVyKChzKSA9PiBzLmNvdW50ID4gMCkubWFwKChzKSA9PiBzLmNvdW50KTtcbiAgY29uc3QgbWVkID0gbWVkaWFuKGFjdGl2ZUNvdW50cyk7XG4gIGNvbnN0IHNwYXJzZVRocmVzaG9sZCA9XG4gICAgbWVkID49IG1pbk1lZGlhbkZvclNwYXJzZSA/IE1hdGgubWF4KHNwYXJzZUZsb29yLCBNYXRoLnJvdW5kKHNwYXJzZVJhdGlvICogbWVkKSkgOiAwO1xuXG4gIGNvbnN0IGxhdGVzdFBvc3RNb250aCA9IGFjY291bnQubGF0ZXN0X3Bvc3RfYXQgPyBhY2NvdW50LmxhdGVzdF9wb3N0X2F0LnNsaWNlKDAsIDcpIDogbnVsbDtcbiAgY29uc3QgaXNIb2xlID0gKHM6IHsgeW06IHN0cmluZzsgY291bnQ6IG51bWJlciB9KTogYm9vbGVhbiA9PlxuICAgIHMuY291bnQgPT09IDAgfHwgKHNwYXJzZVRocmVzaG9sZCA+IDAgJiYgcy5jb3VudCA8IHNwYXJzZVRocmVzaG9sZCk7XG5cbiAgY29uc3QgZ2FwczogQ292ZXJhZ2VHYXBbXSA9IFtdO1xuICBsZXQgcnVuOiB7IHltOiBzdHJpbmc7IGNvdW50OiBudW1iZXIgfVtdID0gW107XG4gIGNvbnN0IGZsdXNoID0gKCk6IHZvaWQgPT4ge1xuICAgIGNvbnN0IGZpcnN0ID0gcnVuWzBdO1xuICAgIGNvbnN0IGxhc3QgPSBydW5bcnVuLmxlbmd0aCAtIDFdO1xuICAgIGlmICghZmlyc3QgfHwgIWxhc3QpIHJldHVybjtcbiAgICBjb25zdCBmcm9tTW9udGggPSBmaXJzdC55bTtcbiAgICBjb25zdCB0b01vbnRoID0gbGFzdC55bTtcbiAgICBjb25zdCBmcm9tRGF0ZSA9IGAke2Zyb21Nb250aH0tMDFgO1xuICAgIGNvbnN0IHRvRGF0ZSA9IGlzb0RhdGUoYWRkTW9udGhzKHBhcnNlTW9udGgodG9Nb250aCksIDEpKTsgLy8gZXhjbHVzaXZlXG4gICAgY29uc3QgY2FwdHVyZWQgPSBydW4ucmVkdWNlKChhY2MsIHMpID0+IGFjYyArIHMuY291bnQsIDApO1xuICAgIGNvbnN0IGFsbEVtcHR5ID0gcnVuLmV2ZXJ5KChzKSA9PiBzLmNvdW50ID09PSAwKTtcbiAgICBjb25zdCBpc1JlY2VudCA9IGxhdGVzdFBvc3RNb250aCAhPT0gbnVsbCAmJiBmcm9tTW9udGggPiBsYXRlc3RQb3N0TW9udGg7XG4gICAgY29uc3Qga2luZDogQ292ZXJhZ2VHYXBbJ2tpbmQnXSA9IGlzUmVjZW50ID8gJ3JlY2VudCcgOiBhbGxFbXB0eSA/ICdlbXB0eScgOiAnc3BhcnNlJztcbiAgICBnYXBzLnB1c2goe1xuICAgICAgaGFuZGxlOiBhY2NvdW50LmhhbmRsZSxcbiAgICAgIGZyb21Nb250aCxcbiAgICAgIHRvTW9udGgsXG4gICAgICBmcm9tRGF0ZSxcbiAgICAgIHRvRGF0ZSxcbiAgICAgIG1vbnRoQ291bnQ6IHJ1bi5sZW5ndGgsXG4gICAgICBjYXB0dXJlZEluUmFuZ2U6IGNhcHR1cmVkLFxuICAgICAga2luZCxcbiAgICAgIHNlYXJjaFVybDogZ2FwU2VhcmNoVXJsKGFjY291bnQuaGFuZGxlLCBmcm9tRGF0ZSwgdG9EYXRlKSxcbiAgICB9KTtcbiAgICBydW4gPSBbXTtcbiAgfTtcbiAgZm9yIChjb25zdCBzIG9mIHNlcSkge1xuICAgIGlmIChpc0hvbGUocykpIHJ1bi5wdXNoKHMpO1xuICAgIGVsc2UgZmx1c2goKTtcbiAgfVxuICBmbHVzaCgpO1xuXG4gIC8vIEludHJhLW1vbnRoIHJlY2VudCBmcm9udGllcjogaWYgdGhlIGxhc3QgcG9zdCBzaXRzIGluc2lkZSB0aGUgY3VycmVudCBtb250aFxuICAvLyAoc28gdGhlIHRyYWlsaW5nLWVtcHR5LW1vbnRoIGxvZ2ljIHByb2R1Y2VkIG5vdGhpbmcgZm9yIGl0KSBidXQgaXMgYSBjb3VwbGVcbiAgLy8gZGF5cyBzdGFsZSwgb2ZmZXIgYSBzZWFyY2ggZnJvbSB0aGUgbGFzdCBwb3N0IHRocm91Z2ggdG9kYXkgdG8gcHVsbCBhbnl0aGluZ1xuICAvLyBwb3N0ZWQgc2luY2UgdGhlIGxhc3Qgc2Nhbi5cbiAgaWYgKGFjY291bnQubGF0ZXN0X3Bvc3RfYXQpIHtcbiAgICBjb25zdCBsYXN0ID0gbmV3IERhdGUoYWNjb3VudC5sYXRlc3RfcG9zdF9hdCk7XG4gICAgY29uc3QgYWdlRGF5cyA9IChub3cuZ2V0VGltZSgpIC0gbGFzdC5nZXRUaW1lKCkpIC8gODZfNDAwXzAwMDtcbiAgICBpZiAoYWdlRGF5cyA+PSByZWNlbnRGcm9udGllck1pbkFnZURheXMgJiYgbW9udGhLZXkobGFzdCkgPT09IG1vbnRoS2V5KG5vdykpIHtcbiAgICAgIGNvbnN0IGZyb21EYXRlID0gaXNvRGF0ZShsYXN0KTtcbiAgICAgIGNvbnN0IHRvRGF0ZSA9IGlzb0RhdGUoYWRkRGF5cyhub3csIDEpKTtcbiAgICAgIGdhcHMucHVzaCh7XG4gICAgICAgIGhhbmRsZTogYWNjb3VudC5oYW5kbGUsXG4gICAgICAgIGZyb21Nb250aDogbW9udGhLZXkobm93KSxcbiAgICAgICAgdG9Nb250aDogbW9udGhLZXkobm93KSxcbiAgICAgICAgZnJvbURhdGUsXG4gICAgICAgIHRvRGF0ZSxcbiAgICAgICAgbW9udGhDb3VudDogMCxcbiAgICAgICAgY2FwdHVyZWRJblJhbmdlOiBtb250aHNbbW9udGhLZXkobm93KV0gPz8gMCxcbiAgICAgICAga2luZDogJ3JlY2VudCcsXG4gICAgICAgIHNlYXJjaFVybDogZ2FwU2VhcmNoVXJsKGFjY291bnQuaGFuZGxlLCBmcm9tRGF0ZSwgdG9EYXRlKSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBnYXBzO1xufVxuXG4vKiogUmFuayBnYXBzIHdvcnN0LWZpcnN0IGFjcm9zcyBhY2NvdW50czogcmVjZW50ICsgZW1wdHkgYmVmb3JlIHNwYXJzZSwgdGhlbiBieSBzcGFuLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJhbmtHYXBzKGdhcHM6IENvdmVyYWdlR2FwW10pOiBDb3ZlcmFnZUdhcFtdIHtcbiAgY29uc3Qgd2VpZ2h0OiBSZWNvcmQ8Q292ZXJhZ2VHYXBbJ2tpbmQnXSwgbnVtYmVyPiA9IHsgcmVjZW50OiAwLCBlbXB0eTogMSwgc3BhcnNlOiAyIH07XG4gIHJldHVybiBbLi4uZ2Fwc10uc29ydCgoYSwgYikgPT4gd2VpZ2h0W2Eua2luZF0gLSB3ZWlnaHRbYi5raW5kXSB8fCBiLm1vbnRoQ291bnQgLSBhLm1vbnRoQ291bnQpO1xufVxuIiwgImltcG9ydCB0eXBlIHsgQWNjb3VudENhdGVnb3J5LCBBY2NvdW50Q29uZmlnIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogTWluaW1hbCBwYXJzZXIgZm9yIHRoZSBzdHJpY3Qgc2hhcGUgdXNlZCBieSBgY29uZmlnL2FjY291bnRzLnlhbWxgOlxuICpcbiAqICAgYWNjb3VudHM6XG4gKiAgICAgLSBoYW5kbGU6IERIU2dvdlxuICogICAgICAgbGFiZWw6IERlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHlcbiAqICAgICAgIGNhdGVnb3J5OiBjb3JlXG4gKlxuICogV2UgZGVsaWJlcmF0ZWx5IGRvbid0IHB1bGwgaW4gYSBmdWxsIFlBTUwgbGlicmFyeSBcdTIwMTQgd2UgY29udHJvbCBib3RoIGVuZHMgb2ZcbiAqIHRoaXMgZmlsZSwgYW5kIGEgc21hbGwgcGFyc2VyIGlzIGVhc2llciB0byBhdWRpdCB0aGFuIHRoZSBhbHRlcm5hdGl2ZXMuXG4gKiBVbmtub3duIGtleXMgYW5kIGNvbW1lbnRzIGFyZSB0b2xlcmF0ZWQ7IG1hbGZvcm1lZCBsaW5lcyBhcmUgc2tpcHBlZC5cbiAqXG4gKiBFbnRyaWVzIG1pc3NpbmcgYSBgY2F0ZWdvcnlgIGRlZmF1bHQgdG8gYGNvcmVgIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XG4gKiB3aXRoIHRoZSBwcmUtY2F0ZWdvcml6YXRpb24gZmlsZSBzaGFwZS5cbiAqL1xuY29uc3QgVkFMSURfQ0FURUdPUklFUzogUmVhZG9ubHlTZXQ8QWNjb3VudENhdGVnb3J5PiA9IG5ldyBTZXQoW1xuICAnY29yZScsXG4gICdnb3Zlcm5tZW50JyxcbiAgJ29mZmljaWFscycsXG4gICdwdWJsaWNfZmlndXJlcycsXG4gICdwdWJsaWMnLFxuXSk7XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUFjY291bnRzWWFtbCh0ZXh0OiBzdHJpbmcpOiBBY2NvdW50Q29uZmlnW10ge1xuICBjb25zdCBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdID0gW107XG4gIGxldCBjdXJyZW50OiBQYXJ0aWFsPEFjY291bnRDb25maWc+ID0ge307XG4gIGxldCBpbkFjY291bnRzID0gZmFsc2U7XG4gIGNvbnN0IGZsdXNoID0gKCkgPT4ge1xuICAgIGlmIChjdXJyZW50LmhhbmRsZSAmJiBjdXJyZW50LmxhYmVsKSB7XG4gICAgICBpZiAoIWN1cnJlbnQuY2F0ZWdvcnkpIGN1cnJlbnQuY2F0ZWdvcnkgPSAnY29yZSc7XG4gICAgICBhY2NvdW50cy5wdXNoKGN1cnJlbnQgYXMgQWNjb3VudENvbmZpZyk7XG4gICAgfVxuICB9O1xuICBmb3IgKGNvbnN0IHJhd0xpbmUgb2YgdGV4dC5zcGxpdCgnXFxuJykpIHtcbiAgICBjb25zdCBsaW5lID0gc3RyaXBDb21tZW50cyhyYXdMaW5lKTtcbiAgICBpZiAobGluZS50cmltKCkgPT09ICcnKSBjb250aW51ZTtcbiAgICBpZiAoL15hY2NvdW50c1xccyo6Ly50ZXN0KGxpbmUpKSB7XG4gICAgICBpbkFjY291bnRzID0gdHJ1ZTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoIWluQWNjb3VudHMpIGNvbnRpbnVlO1xuXG4gICAgY29uc3QgaXRlbU1hdGNoID0gbGluZS5tYXRjaCgvXlxccyotXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGl0ZW1NYXRjaCkge1xuICAgICAgZmx1c2goKTtcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShpdGVtTWF0Y2hbMV0gPz8gJycpIH07XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgaGFuZGxlT25seSA9IGxpbmUubWF0Y2goL15cXHMqaGFuZGxlXFxzKjpcXHMqKC4rKSQvKTtcbiAgICBpZiAoaGFuZGxlT25seSAmJiAhbGluZS5pbmNsdWRlcygnLScpKSB7XG4gICAgICBmbHVzaCgpO1xuICAgICAgY3VycmVudCA9IHsgaGFuZGxlOiB1bnF1b3RlKGhhbmRsZU9ubHlbMV0gPz8gJycpIH07XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgbGFiZWxNYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqbGFiZWxcXHMqOlxccyooLispJC8pO1xuICAgIGlmIChsYWJlbE1hdGNoICYmIGN1cnJlbnQuaGFuZGxlKSB7XG4gICAgICBjdXJyZW50LmxhYmVsID0gdW5xdW90ZShsYWJlbE1hdGNoWzFdID8/ICcnKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBjYXRlZ29yeU1hdGNoID0gbGluZS5tYXRjaCgvXlxccypjYXRlZ29yeVxccyo6XFxzKiguKykkLyk7XG4gICAgaWYgKGNhdGVnb3J5TWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcbiAgICAgIGNvbnN0IHJhdyA9IHVucXVvdGUoY2F0ZWdvcnlNYXRjaFsxXSA/PyAnJyk7XG4gICAgICBjdXJyZW50LmNhdGVnb3J5ID0gVkFMSURfQ0FURUdPUklFUy5oYXMocmF3IGFzIEFjY291bnRDYXRlZ29yeSlcbiAgICAgICAgPyAocmF3IGFzIEFjY291bnRDYXRlZ29yeSlcbiAgICAgICAgOiAnY29yZSc7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gIH1cbiAgZmx1c2goKTtcbiAgcmV0dXJuIGFjY291bnRzLmZpbHRlcigoYSkgPT4gYS5oYW5kbGUubGVuZ3RoID4gMCk7XG59XG5cbmZ1bmN0aW9uIHN0cmlwQ29tbWVudHMobGluZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gTmFpdmUgYnV0IGFkZXF1YXRlIGZvciBvdXIgZm9ybWF0OiBzdHJpcCBldmVyeXRoaW5nIGFmdGVyIGEgYCNgIHRoYXQgaXNuJ3RcbiAgLy8gaW5zaWRlIHF1b3Rlcy4gT3VyIGNvbmZpZyBuZXZlciB1c2VzIGlubGluZSBzdHJpbmdzIHdpdGggYCNgLlxuICBjb25zdCBpZHggPSBsaW5lLmluZGV4T2YoJyMnKTtcbiAgcmV0dXJuIGlkeCA9PT0gLTEgPyBsaW5lIDogbGluZS5zbGljZSgwLCBpZHgpO1xufVxuXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IHRyaW1tZWQgPSBzLnRyaW0oKTtcbiAgaWYgKFxuICAgICh0cmltbWVkLnN0YXJ0c1dpdGgoJ1wiJykgJiYgdHJpbW1lZC5lbmRzV2l0aCgnXCInKSkgfHxcbiAgICAodHJpbW1lZC5zdGFydHNXaXRoKFwiJ1wiKSAmJiB0cmltbWVkLmVuZHNXaXRoKFwiJ1wiKSlcbiAgKSB7XG4gICAgcmV0dXJuIHRyaW1tZWQuc2xpY2UoMSwgLTEpO1xuICB9XG4gIHJldHVybiB0cmltbWVkO1xufVxuIiwgIi8qKlxuICogYmFja2dyb3VuZC50cyBcdTIwMTQgZXh0ZW5zaW9uIHNlcnZpY2Ugd29ya2VyLlxuICpcbiAqIE93bnMgdGhlIGNhcHR1cmUgcGlwZWxpbmU6IHJlY2VpdmVzIGBncmFwaHFsLWNhcHR1cmVgIG1lc3NhZ2VzIGZyb20gdGhlXG4gKiBjb250ZW50IHNjcmlwdCwgbm9ybWFsaXplcyB0aGVtLCBhY2N1bXVsYXRlcyBwZXItaGFuZGxlIHJ1biBidWZmZXJzIGluXG4gKiBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCwgYW5kIGNvbW1pdHMgdGhlbSB0byB0aGUgY29uZmlndXJlZCBHaXRIdWIgcmVwb1xuICogdmlhIHRoZSBHaXQgRGF0YSBBUEkuXG4gKlxuICogU2VydmljZSB3b3JrZXJzIGluIE1WMyBtYXkgYmUgZXZpY3RlZCBhdCBhbnkgdGltZSwgc28gYWxsIGNyaXRpY2FsIHN0YXRlXG4gKiBsaXZlcyBpbiBzdG9yYWdlIChuZXZlciBtb2R1bGUtc2NvcGUpLiBPbiBldmVyeSB3YWtlIHdlIHJlLWRlcml2ZSB3aGF0IHdlXG4gKiBuZWVkOyBwZW5kaW5nIGZsdXNoZXMgYXJlIGRyaXZlbiBieSBgYnJvd3Nlci5hbGFybXNgIHJhdGhlciB0aGFuIHRpbWVycy5cbiAqL1xuXG5pbXBvcnQge1xuICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICBBVVRPX1NDUk9MTF9NSU5fU0VDLFxuICBGQUxMQkFDS19BQ0NPVU5UUyxcbiAgRkxVU0hfQUxBUk1fTUlOVVRFUyxcbiAgRkxVU0hfSURMRV9NUyxcbiAgRkxVU0hfVFdFRVRfVEhSRVNIT0xELFxuICBQUk9GSUxFX0VORFBPSU5UUyxcbiAgVFdFRVRfRU5EUE9JTlRTLFxuICBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyxcbn0gZnJvbSAnLi9saWIvY29uZmlnLmpzJztcbmltcG9ydCB7IEdpdEh1YkNsaWVudCwgR2l0SHViRXJyb3IsIHRvQmFzZTY0IH0gZnJvbSAnLi9saWIvZ2l0aHViLmpzJztcbmltcG9ydCB7IGRlc2NyaWJlRXJyb3IsIGVycm9yIGFzIGxvZ0VyciwgaW5mbywgc2V0QnJvYWRjYXN0ZXIsIHdhcm4gfSBmcm9tICcuL2xpYi9sb2dnZXIuanMnO1xuaW1wb3J0IHsgZmlsdGVyUmVsYXRlZCwgbm9ybWFsaXplIH0gZnJvbSAnLi9saWIvbm9ybWFsaXplLmpzJztcbmltcG9ydCB7IG5ld1J1bklkLCBzaG9ydFJ1bklkIH0gZnJvbSAnLi9saWIvcnVuaWRzLmpzJztcbmltcG9ydCB7XG4gIGJ1bXBDb3VudGVyLFxuICBjbGVhckFjdGl2aXR5LFxuICBjbGVhckFsbCxcbiAgY2xlYXJSdW5CdWZmZXIsXG4gIGRlcXVldWVNZWRpYUNyYXdsLFxuICBkZXF1ZXVlUmVmZXRjaCxcbiAgZGVxdWV1ZVRocmVhZE9wZW4sXG4gIGVuZ2FnZW1lbnRTaWcsXG4gIGVucXVldWVNZWRpYUNyYXdsLFxuICBlbnF1ZXVlUmVmZXRjaCxcbiAgZW5xdWV1ZVRocmVhZE9wZW4sXG4gIGdldEFjY291bnRzLFxuICBnZXRBY2NvdW50c1JlZnJlc2hlZEF0LFxuICBnZXRBY3Rpdml0eSxcbiAgZ2V0QXJjaGl2ZVNuYXBzaG90LFxuICBnZXRBdXRvU2Nyb2xsU2Vzc2lvbixcbiAgZ2V0Q29tbWl0dGVkSW5kZXgsXG4gIGdldENvbm5lY3Rpb24sXG4gIGdldENvdW50ZXJzLFxuICBnZXRNZWRpYUNyYXdsUXVldWUsXG4gIGdldE1lZGlhQ3Jhd2xTZXNzaW9uLFxuICBnZXRSZWZldGNoUXVldWUsXG4gIGdldFJlZmV0Y2hTZXNzaW9uLFxuICBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncyxcbiAgZ2V0UnVuQnVmZmVyLFxuICBnZXRSdW5CdWZmZXJzLFxuICBnZXRTZXR0aW5ncyxcbiAgZ2V0VGhyZWFkT3BlblF1ZXVlLFxuICBnZXRUaHJlYWRPcGVuU2Vzc2lvbixcbiAgaGFzVGhyZWFkT3BlblNlZW4sXG4gIGlzQ29tbWl0dGVkLFxuICBtYXJrVGhyZWFkT3BlblNlZW4sXG4gIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsLFxuICBuZXh0TWVkaWFDcmF3bFRhcmdldCxcbiAgbmV4dFJlZmV0Y2hUYXJnZXQsXG4gIG5leHRUaHJlYWRPcGVuVGFyZ2V0LFxuICBwcnVuZUNvbW1pdHRlZEluZGV4LFxuICBwdXJnZVVucmVsYXRlZFN0YXRlLFxuICByZWZldGNoUXVldWVUb3RhbCxcbiAgcHJlcGVuZFJlY2VudFR3ZWV0U2lnaHRpbmdzLFxuICBzZXRBY2NvdW50cyxcbiAgc2V0QWNjb3VudHNSZWZyZXNoZWRBdCxcbiAgc2V0QXJjaGl2ZVNuYXBzaG90LFxuICBzZXRBdXRvU2Nyb2xsU2Vzc2lvbixcbiAgc2V0QnVmZmVyZWRDb3VudCxcbiAgc2V0Q29tbWl0dGVkSW5kZXgsXG4gIHNldENvbm5lY3Rpb24sXG4gIHNldE1lZGlhQ3Jhd2xTZXNzaW9uLFxuICBzZXRSZWZldGNoU2Vzc2lvbixcbiAgc2V0UnVuQnVmZmVyLFxuICBzZXRUaHJlYWRPcGVuU2Vzc2lvbixcbiAgdGhyZWFkT3BlblF1ZXVlVG90YWwsXG4gIHR5cGUgUnVuQnVmZmVyLFxuICB1cGRhdGVTZXR0aW5ncyxcbn0gZnJvbSAnLi9saWIvc3RvcmFnZS5qcyc7XG5pbXBvcnQgeyBmaW5kQ292ZXJhZ2VHYXBzLCByYW5rR2FwcyB9IGZyb20gJy4vbGliL2dhcHMuanMnO1xuaW1wb3J0IHR5cGUge1xuICBDYW5vbmljYWxUd2VldCxcbiAgQ2FwdHVyZVBheWxvYWQsXG4gIEFyY2hpdmVTbmFwc2hvdCxcbiAgQ292ZXJhZ2VHYXAsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgRXh0ZW5zaW9uU3RhdGUsXG4gIExvZ0V2ZW50LFxuICBRdWFyYW50aW5lUGF5bG9hZCxcbiAgUmV0d2VldEVkZ2UsXG4gIFJ1bnRpbWVNZXNzYWdlLFxuICBTZWVuUGF5bG9hZCxcbiAgU2V0dGluZ3MsXG4gIFR3ZWV0U2lnaHRpbmcsXG4gIFVuYXZhaWxhYmxlVHdlZXQsXG59IGZyb20gJy4vbGliL3R5cGVzLmpzJztcbmltcG9ydCB7IHBhcnNlQWNjb3VudHNZYW1sIH0gZnJvbSAnLi9saWIveWFtbC5qcyc7XG5cbmNvbnN0IEVYVF9WRVJTSU9OID0gYnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbjtcbmNvbnN0IE1BTlVBTF9DQVBUVVJFX1dJTkRPV19NUyA9IDkwXzAwMDtcbmNvbnN0IExPV19CQU5EV0lEVEhfQkFTRV9SVUxFX0lEID0gNzYwXzAwMTtcbmNvbnN0IExPV19CQU5EV0lEVEhfTUVESUFfUlVMRV9JRF9CQVNFID0gNzYwXzAxMDtcbmNvbnN0IExPV19CQU5EV0lEVEhfUkVTT1VSQ0VfVFlQRVMgPSBbJ2ltYWdlJywgJ21lZGlhJywgJ2ZvbnQnXSBhcyBjb25zdDtcbmNvbnN0IExPV19CQU5EV0lEVEhfTUVESUFfQ0hVTktfUkVTT1VSQ0VfVFlQRVMgPSBbJ21lZGlhJywgJ3htbGh0dHByZXF1ZXN0JywgJ290aGVyJ10gYXMgY29uc3Q7XG5jb25zdCBMT1dfQkFORFdJRFRIX01FRElBX1VSTF9GSUxURVJTID0gW1xuICAnfHx2aWRlby50d2ltZy5jb21eJyxcbiAgJ3x8dG9uLnR3aW1nLmNvbV4nLFxuICAnfHxhbXAudHdpbWcuY29tXicsXG4gICd8fHZpZGVvLnBzY3AudHZeJyxcbiAgJ3x8cHJvZC1mYXN0bHktdXMtd2VzdC0xLnZpZGVvLnBzY3AudHZeJyxcbiAgJ3xodHRwczovL3guY29tL2kvdmlkZW9zLycsXG4gICd8aHR0cHM6Ly90d2l0dGVyLmNvbS9pL3ZpZGVvcy8nLFxuXSBhcyBjb25zdDtcbmxldCBtYW51YWxDYXB0dXJlVW50aWxNcyA9IDA7XG5cbnR5cGUgTG93QmFuZHdpZHRoUmVzb3VyY2VUeXBlID1cbiAgfCAodHlwZW9mIExPV19CQU5EV0lEVEhfUkVTT1VSQ0VfVFlQRVMpW251bWJlcl1cbiAgfCAodHlwZW9mIExPV19CQU5EV0lEVEhfTUVESUFfQ0hVTktfUkVTT1VSQ0VfVFlQRVMpW251bWJlcl07XG5cbmludGVyZmFjZSBMb3dCYW5kd2lkdGhSdWxlIHtcbiAgaWQ6IG51bWJlcjtcbiAgcHJpb3JpdHk6IG51bWJlcjtcbiAgYWN0aW9uOiB7IHR5cGU6ICdibG9jaycgfTtcbiAgY29uZGl0aW9uOiB7XG4gICAgdGFiSWRzOiBudW1iZXJbXTtcbiAgICByZXNvdXJjZVR5cGVzOiBMb3dCYW5kd2lkdGhSZXNvdXJjZVR5cGVbXTtcbiAgICB1cmxGaWx0ZXI/OiBzdHJpbmc7XG4gIH07XG59XG5cbmludGVyZmFjZSBEZWNsYXJhdGl2ZU5ldFJlcXVlc3RBcGkge1xuICB1cGRhdGVTZXNzaW9uUnVsZXModXBkYXRlOiB7XG4gICAgYWRkUnVsZXM/OiBMb3dCYW5kd2lkdGhSdWxlW107XG4gICAgcmVtb3ZlUnVsZUlkcz86IG51bWJlcltdO1xuICB9KTogUHJvbWlzZTx2b2lkPjtcbn1cblxuc2V0QnJvYWRjYXN0ZXIoKGV2OiBMb2dFdmVudCkgPT4ge1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnbG9nLWV2ZW50JywgZXZlbnQ6IGV2IH0pLmNhdGNoKCgpID0+IHt9KTtcbn0pO1xuXG5mdW5jdGlvbiBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTogdm9pZCB7XG4gIG1hbnVhbENhcHR1cmVVbnRpbE1zID0gRGF0ZS5ub3coKSArIE1BTlVBTF9DQVBUVVJFX1dJTkRPV19NUztcbn1cblxuLy8gLS0tIFdha2UgaGFuZGxlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYnJvd3Nlci5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIGluc3RhbGxlZCcsIHsgdmVyc2lvbjogRVhUX1ZFUlNJT04gfSk7XG4gIGF3YWl0IG9uV2FrZSgnaW5zdGFsbCcpO1xufSk7XG5cbmJyb3dzZXIucnVudGltZS5vblN0YXJ0dXAuYWRkTGlzdGVuZXIoKCkgPT4ge1xuICB2b2lkIG9uV2FrZSgnc3RhcnR1cCcpO1xufSk7XG5cbi8vIEZvcmNlIGF0IGxlYXN0IG9uZSB3YWtlIHRvIHJlZ2lzdGVyIGFsYXJtcyAvIHZlcmlmeSBjb25uZWN0aW9uLlxudm9pZCBvbldha2UoJ21vZHVsZS1sb2FkJyk7XG5cbmFzeW5jIGZ1bmN0aW9uIG9uV2FrZShyZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGF3YWl0IGVuc3VyZUFsYXJtcygpO1xuICAgIGF3YWl0IGVuc3VyZUF1dG9TY3JvbGxBbGFybSgpO1xuICAgIGF3YWl0IHN5bmNMb3dCYW5kd2lkdGhSdWxlcyh7IHJlYXNvbjogYHdha2U6JHtyZWFzb259YCwgbG9nOiBmYWxzZSB9KTtcbiAgICBhd2FpdCBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTtcbiAgICBhd2FpdCByZWluamVjdEludG9PcGVuVGFicygpO1xuICAgIC8vIERyb3AgZGVkdXAtaW5kZXggZW50cmllcyBvbGRlciB0aGFuIDMwIGRheXMgc28gdGhlIHN0b3JlIGRvZXNuJ3RcbiAgICAvLyBncm93IHVuYm91bmRlZCBvdmVyIG1vbnRocyBvZiBjYXB0dXJlIHNlc3Npb25zLlxuICAgIGNvbnN0IHBydW5lZCA9IGF3YWl0IHBydW5lQ29tbWl0dGVkSW5kZXgoMzAgKiAyNCAqIDYwICogNjAgKiAxMDAwKTtcbiAgICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgaW5mbygncHJ1bmVkIGNvbW1pdHRlZCBpbmRleCcsIHsgcHJ1bmVkIH0pO1xuICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgICBpZiAoc2V0dGluZ3MucGF0ICYmIHNldHRpbmdzLm93bmVyICYmIHNldHRpbmdzLnJlcG8pIHtcbiAgICAgIGF3YWl0IHZlcmlmeUNvbm5lY3Rpb24oZmFsc2UpO1xuICAgICAgYXdhaXQgcmVmcmVzaEFjY291bnRzTGlzdChmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXM6ICdub3QtY29uZmlndXJlZCcsXG4gICAgICAgIGxvZ2luOiBudWxsLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IG51bGwsXG4gICAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBhd2FrZTsgc2V0dGluZ3MgaW5jb21wbGV0ZScsIHsgcmVhc29uIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgbG9nRXJyKCd3YWtlIGZhaWxlZCcsIHsgcmVhc29uLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZG5yQXBpKCk6IERlY2xhcmF0aXZlTmV0UmVxdWVzdEFwaSB8IG51bGwge1xuICBjb25zdCBtYXliZUJyb3dzZXIgPSBicm93c2VyIGFzIHVua25vd24gYXMge1xuICAgIGRlY2xhcmF0aXZlTmV0UmVxdWVzdD86IERlY2xhcmF0aXZlTmV0UmVxdWVzdEFwaTtcbiAgfTtcbiAgcmV0dXJuIG1heWJlQnJvd3Nlci5kZWNsYXJhdGl2ZU5ldFJlcXVlc3QgPz8gbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY3VycmVudFhUYWJJZHMoKTogUHJvbWlzZTxudW1iZXJbXT4ge1xuICBjb25zdCB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcbiAgcmV0dXJuIHRhYnMuZmxhdE1hcCgodGFiKSA9PiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicgPyBbdGFiLmlkXSA6IFtdKSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN5bmNMb3dCYW5kd2lkdGhSdWxlcyh7XG4gIHJlYXNvbixcbiAgbG9nLFxufToge1xuICByZWFzb246IHN0cmluZztcbiAgbG9nOiBib29sZWFuO1xufSk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IGRuciA9IGRuckFwaSgpO1xuICBpZiAoIWRucikge1xuICAgIGlmIChzZXR0aW5ncy5sb3dCYW5kd2lkdGhCcm93c2luZyAmJiBsb2cpIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2xvdy1iYW5kd2lkdGggYnJvd3NpbmcgdW5hdmFpbGFibGU7IGRlY2xhcmF0aXZlTmV0UmVxdWVzdCBBUEkgbWlzc2luZycsIHtcbiAgICAgICAgcmVhc29uLFxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHRhYklkcyA9IHNldHRpbmdzLmxvd0JhbmR3aWR0aEJyb3dzaW5nID8gYXdhaXQgY3VycmVudFhUYWJJZHMoKSA6IFtdO1xuICBjb25zdCByZW1vdmVSdWxlSWRzID0gW1xuICAgIExPV19CQU5EV0lEVEhfQkFTRV9SVUxFX0lELFxuICAgIC4uLkxPV19CQU5EV0lEVEhfTUVESUFfVVJMX0ZJTFRFUlMubWFwKChfLCBpZHgpID0+IExPV19CQU5EV0lEVEhfTUVESUFfUlVMRV9JRF9CQVNFICsgaWR4KSxcbiAgXTtcbiAgY29uc3QgYWRkUnVsZXM6IExvd0JhbmR3aWR0aFJ1bGVbXSA9XG4gICAgdGFiSWRzLmxlbmd0aCA+IDBcbiAgICAgID8gW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiBMT1dfQkFORFdJRFRIX0JBU0VfUlVMRV9JRCxcbiAgICAgICAgICAgIHByaW9yaXR5OiAxLFxuICAgICAgICAgICAgYWN0aW9uOiB7IHR5cGU6ICdibG9jaycgfSxcbiAgICAgICAgICAgIGNvbmRpdGlvbjoge1xuICAgICAgICAgICAgICB0YWJJZHMsXG4gICAgICAgICAgICAgIHJlc291cmNlVHlwZXM6IFsuLi5MT1dfQkFORFdJRFRIX1JFU09VUkNFX1RZUEVTXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICAuLi5MT1dfQkFORFdJRFRIX01FRElBX1VSTF9GSUxURVJTLm1hcCgodXJsRmlsdGVyLCBpZHgpID0+ICh7XG4gICAgICAgICAgICBpZDogTE9XX0JBTkRXSURUSF9NRURJQV9SVUxFX0lEX0JBU0UgKyBpZHgsXG4gICAgICAgICAgICBwcmlvcml0eTogMixcbiAgICAgICAgICAgIGFjdGlvbjogeyB0eXBlOiAnYmxvY2snIGFzIGNvbnN0IH0sXG4gICAgICAgICAgICBjb25kaXRpb246IHtcbiAgICAgICAgICAgICAgdGFiSWRzLFxuICAgICAgICAgICAgICB1cmxGaWx0ZXIsXG4gICAgICAgICAgICAgIHJlc291cmNlVHlwZXM6IFsuLi5MT1dfQkFORFdJRFRIX01FRElBX0NIVU5LX1JFU09VUkNFX1RZUEVTXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSkpLFxuICAgICAgICBdXG4gICAgICA6IFtdO1xuICBhd2FpdCBkbnIudXBkYXRlU2Vzc2lvblJ1bGVzKHtcbiAgICByZW1vdmVSdWxlSWRzLFxuICAgIGFkZFJ1bGVzLFxuICB9KTtcblxuICBpZiAobG9nKSB7XG4gICAgYXdhaXQgaW5mbygnbG93LWJhbmR3aWR0aCBicm93c2luZyBydWxlcyB1cGRhdGVkJywge1xuICAgICAgZW5hYmxlZDogc2V0dGluZ3MubG93QmFuZHdpZHRoQnJvd3NpbmcsXG4gICAgICB0YWJfY291bnQ6IHRhYklkcy5sZW5ndGgsXG4gICAgICBibG9ja2VkX3Jlc291cmNlX3R5cGVzOiBMT1dfQkFORFdJRFRIX1JFU09VUkNFX1RZUEVTLmpvaW4oJywnKSxcbiAgICAgIGJsb2NrZWRfbWVkaWFfZmlsdGVyczogTE9XX0JBTkRXSURUSF9NRURJQV9VUkxfRklMVEVSUy5qb2luKCcsJyksXG4gICAgICByZWFzb24sXG4gICAgfSk7XG4gIH1cbn1cblxuYnJvd3Nlci50YWJzLm9uVXBkYXRlZC5hZGRMaXN0ZW5lcigoX3RhYklkLCBjaGFuZ2VJbmZvKSA9PiB7XG4gIGlmIChjaGFuZ2VJbmZvLnVybCB8fCBjaGFuZ2VJbmZvLnN0YXR1cyA9PT0gJ2NvbXBsZXRlJykge1xuICAgIHZvaWQgc3luY0xvd0JhbmR3aWR0aFJ1bGVzKHsgcmVhc29uOiAndGFiLXVwZGF0ZWQnLCBsb2c6IGZhbHNlIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybignbG93LWJhbmR3aWR0aCBydWxlIHJlZnJlc2ggZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICB9KTtcbiAgfVxufSk7XG5cbmJyb3dzZXIudGFicy5vblJlbW92ZWQuYWRkTGlzdGVuZXIoKCkgPT4ge1xuICB2b2lkIHN5bmNMb3dCYW5kd2lkdGhSdWxlcyh7IHJlYXNvbjogJ3RhYi1yZW1vdmVkJywgbG9nOiBmYWxzZSB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgdm9pZCB3YXJuKCdsb3ctYmFuZHdpZHRoIHJ1bGUgcmVmcmVzaCBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9KTtcbn0pO1xuXG4vKipcbiAqIFJlLWluamVjdCB0aGUgTUFJTi13b3JsZCBwYWdlLWhvb2sgKyBpc29sYXRlZC13b3JsZCBjb250ZW50IHNjcmlwdCBpbnRvXG4gKiBldmVyeSBhbHJlYWR5LW9wZW4geC5jb20gLyB0d2l0dGVyLmNvbSB0YWIuXG4gKlxuICogTWFuaWZlc3QgY29udGVudF9zY3JpcHRzIG9ubHkgaW5qZWN0IG9uIGZyZXNoIG5hdmlnYXRpb24gKHJ1bl9hdDpcbiAqIGRvY3VtZW50X3N0YXJ0KS4gV2hlbiB0aGUgdXNlciByZWxvYWRzIHRoZSBleHRlbnNpb24gd2hpbGUgWCB0YWJzIGFyZVxuICogb3BlbiwgdGhvc2UgdGFicyBrZWVwIHRoZWlyIGNvbnRlbnQgc2NyaXB0cyBidXQgbmV2ZXIgZ2V0IGEgbmV3IHBhZ2UtaG9va1xuICogXHUyMDE0IHNvIGZldGNoL1hIUiBzdGF5cyB1bnBhdGNoZWQgYW5kIGNhcHR1cmVzIHNpbGVudGx5IGZhaWwuIERvaW5nIHRoaXMgb25cbiAqIGV2ZXJ5IHdha2UgaXMgaWRlbXBvdGVudCAocGFnZS1ob29rIGhhcyBhIFRBRyBndWFyZCkgYW5kIGNoZWFwLlxuICovXG5hc3luYyBmdW5jdGlvbiByZWluamVjdEludG9PcGVuVGFicygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcbiAgdHJ5IHtcbiAgICB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY291bGQgbm90IHF1ZXJ5IG9wZW4gdGFicycsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh0YWJzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XG4gICAgaWYgKHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInKSBjb250aW51ZTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXG4gICAgICAgIGZpbGVzOiBbJ3BhZ2UtaG9vay5qcyddLFxuICAgICAgICAvLyBGaXJlZm94IDEyOCsgc3VwcG9ydHMgdGhlIE1BSU4gZXhlY3V0aW9uIHdvcmxkIHZpYSB0aGlzIEFQSSwgYnV0XG4gICAgICAgIC8vIHRoZSBAdHlwZXMvZmlyZWZveC13ZWJleHQtYnJvd3NlciBwYWNrYWdlIHdlJ3JlIG9uIHN0aWxsIG9ubHlcbiAgICAgICAgLy8gZGVjbGFyZXMgJ0lTT0xBVEVEJy4gQ2FzdCB0aHJvdWdoIHRoZSBsaXRlcmFsIHVuaW9uLlxuICAgICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXG4gICAgICB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ3JlLWluamVjdGVkIHNjcmlwdHMgaW50byBvcGVuIHRhYicsIHtcbiAgICAgICAgdGFiSWQ6IHRhYi5pZCxcbiAgICAgICAgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwgPz8gJycpLFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAvLyBTb21lIHRhYnMgKGFib3V0OiBwYWdlcywgZGlzY2FyZGVkIHRhYnMsIG1pZC1uYXZpZ2F0aW9uKSByZWplY3RcbiAgICAgIC8vIGV4ZWN1dGVTY3JpcHQuIFRoYXQncyBmaW5lIFx1MjAxNCB3ZSdsbCBjYXRjaCB0aGVtIG9uIHRoZSBuZXh0IHdha2Ugb3JcbiAgICAgIC8vIHdoZW4gdGhlIHVzZXIgbmF2aWdhdGVzLlxuICAgICAgYXdhaXQgd2FybigncmUtaW5qZWN0IGZhaWxlZCBmb3IgdGFiOyBjb250aW51aW5nJywge1xuICAgICAgICB0YWJJZDogdGFiLmlkLFxuICAgICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCA/PyAnJyksXG4gICAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVBbGFybXMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdmbHVzaC1zd2VlcCcpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigndmVyaWZ5LWNvbm5lY3Rpb24nKTtcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY3JlYXRlKCdmbHVzaC1zd2VlcCcsIHsgcGVyaW9kSW5NaW51dGVzOiBGTFVTSF9BTEFSTV9NSU5VVEVTIH0pO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jcmVhdGUoJ3ZlcmlmeS1jb25uZWN0aW9uJywge1xuICAgIHBlcmlvZEluTWludXRlczogVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgLyA2MF8wMDAsXG4gIH0pO1xufVxuXG4vLyBGaXJlZm94IE1WMyBhbGFybXMgaGF2ZSBhIDMwcyBtaW5pbXVtIHBlcmlvZCwgYnV0IHdlIHdhbnQgc3ViLW1pbnV0ZVxuLy8gc2Nyb2xsaW5nLiBUaGUgYXV0by1zY3JvbGwgbG9vcCB0aGVyZWZvcmUgcnVucyBvbiBhbiBpbi1TVyBpbnRlcnZhbC5cbi8vIGBhdXRvU2Nyb2xsU2Vzc2lvbmAgaW4gc3RvcmFnZSBpcyB0aGUgc291cmNlIG9mIHRydXRoIGZvciB3aGV0aGVyIHRoZSBsb29wXG4vLyBpcyBtZWFudCB0byBiZSBydW5uaW5nIFx1MjAxNCB0aGUgdGltZXIgaXMganVzdCB0aGUgbG9jYWwgZXhlY3V0aW9uIGFybS5cbmxldCBhdXRvU2Nyb2xsVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuY29uc3QgU0hPV19NT1JFX1JFTEVWQU5DRV9UVExfTVMgPSAxMCAqIDYwICogMTAwMDtcbmludGVyZmFjZSBUYWJSZWxldmFudFR3ZWV0cyB7XG4gIHVwZGF0ZWRBdDogbnVtYmVyO1xuICBwYWdlVXJsOiBzdHJpbmcgfCBudWxsO1xuICB0d2VldElkczogU2V0PHN0cmluZz47XG59XG5jb25zdCBzaG93TW9yZVJlbGV2YW50VHdlZXRzQnlUYWIgPSBuZXcgTWFwPG51bWJlciwgVGFiUmVsZXZhbnRUd2VldHM+KCk7XG5cbi8vIFdhaXQtZm9yLWluZ2VzdCB0aW1lb3V0OiBpZiBhIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCB0YWIgbmF2aWdhdGlvbiBkb2Vzbid0XG4vLyBwcm9kdWNlIGFuIGluZ2VzdGVkIGNhcHR1cmUgd2l0aGluIHRoaXMgbWFueSBtcywgYWR2YW5jZSBhbnl3YXkgc28gd2Vcbi8vIGRvbid0IGRlYWRsb2NrIG9uIGRlbGV0ZWQgLyA0MDQgLyBwYXl3YWxsZWQgdHdlZXRzLlxuY29uc3QgSU5HRVNUX1dBSVRfTVMgPSAyNV8wMDA7XG5cbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUF1dG9TY3JvbGxBbGFybSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gV2FzIHRoZSBsb29wIHJ1bm5pbmcgYmVmb3JlIHRoZSBTVyBldmljdGlvbj8gUmUtYXJtIGlmIHNvLlxuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmIChzZXNzICE9PSBudWxsICYmIHMuZW5hYmxlZCAhPT0gZmFsc2UpIHtcbiAgICBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xuICB9IGVsc2Uge1xuICAgIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTogdm9pZCB7XG4gIGlmIChhdXRvU2Nyb2xsVGltZXIgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKGF1dG9TY3JvbGxUaW1lcik7XG4gICAgYXV0b1Njcm9sbFRpbWVyID0gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBhcm1BdXRvU2Nyb2xsVGltZXIoaW50ZXJ2YWxTZWM6IG51bWJlcik6IHZvaWQge1xuICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICBjb25zdCBjbGFtcGVkID0gTWF0aC5taW4oXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKGludGVydmFsU2VjKSlcbiAgKTtcbiAgYXV0b1Njcm9sbFRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgYXV0b1Njcm9sbFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ2F1dG8tc2Nyb2xsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICB9KTtcbiAgfSwgY2xhbXBlZCAqIDEwMDApO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydEF1dG9TY3JvbGxMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKHtcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICBzY3JvbGxDb3VudDogMCxcbiAgICBpbmdlc3RlZENvdW50OiAwLFxuICAgIGluZ2VzdGVkTmV3Q291bnQ6IDAsXG4gICAgaW5nZXN0ZWRFeGlzdGluZ0NvdW50OiAwLFxuICAgIHNraXBwZWRPbGRDb3VudDogMCxcbiAgICBleHBhbmRlZENvdW50OiAwLFxuICB9KTtcbiAgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBzdGFydGVkJywgeyBpbnRlcnZhbF9zZWM6IHMuYXV0b1Njcm9sbEludGVydmFsU2VjIH0pO1xuICAvLyBGaXJlIG9uZSBpbW1lZGlhdGUgdGljayBzbyB0aGUgdXNlciBzZWVzIG1vdGlvbiByaWdodCBhd2F5LlxuICB2b2lkIGF1dG9TY3JvbGxUaWNrKCk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbEF1dG9TY3JvbGxMb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24obnVsbCk7XG4gIGF3YWl0IGluZm8oJ2F1dG8tc2Nyb2xsIGxvb3AgY2FuY2VsbGVkJywge1xuICAgIHNjcm9sbHM6IHNlc3M/LnNjcm9sbENvdW50ID8/IDAsXG4gICAgaW5nZXN0ZWQ6IHNlc3M/LmluZ2VzdGVkQ291bnQgPz8gMCxcbiAgICBleHBhbmRlZDogc2Vzcz8uZXhwYW5kZWRDb3VudCA/PyAwLFxuICB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYXV0b1Njcm9sbFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCB0YWJzOiBicm93c2VyLnRhYnMuVGFiW107XG4gIHRyeSB7XG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2F1dG8tc2Nyb2xsOiB0YWIgcXVlcnkgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHRhYnMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGxldCBzY3JvbGxDb3VudCA9IDA7XG4gIGxldCByZXRyeUNvdW50ID0gMDtcbiAgZm9yIChjb25zdCB0YWIgb2YgdGFicykge1xuICAgIGlmICh0eXBlb2YgdGFiLmlkICE9PSAnbnVtYmVyJykgY29udGludWU7XG4gICAgaWYgKHRhYi5kaXNjYXJkZWQpIGNvbnRpbnVlO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHRzID0gKGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXG4gICAgICAgIGZ1bmM6ICgoKSA9PiB7XG4gICAgICAgICAgY29uc3Qgbm9ybWFsaXplZFRleHQgPSAoZWw6IEVsZW1lbnQpOiBzdHJpbmcgPT5cbiAgICAgICAgICAgIGAke2VsLnRleHRDb250ZW50ID8/ICcnfSAke2VsLmdldEF0dHJpYnV0ZSgnYXJpYS1sYWJlbCcpID8/ICcnfWBcbiAgICAgICAgICAgICAgLnJlcGxhY2UoL1xccysvZywgJyAnKVxuICAgICAgICAgICAgICAudHJpbSgpXG4gICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgIGNvbnN0IGNsaWNrUmV0cnlJZlJlbG9hZEVycm9yID0gKCk6IGJvb2xlYW4gPT4ge1xuICAgICAgICAgICAgY29uc3QgYm9keVRleHQgPSAoZG9jdW1lbnQuYm9keT8uaW5uZXJUZXh0ID8/ICcnKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgaWYgKCFib2R5VGV4dC5pbmNsdWRlcygnc29tZXRoaW5nIHdlbnQgd3JvbmcnKSAmJiAhYm9keVRleHQuaW5jbHVkZXMoJ3RyeSByZWxvYWRpbmcnKSkge1xuICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBjb250cm9scyA9IEFycmF5LmZyb20oXG4gICAgICAgICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2J1dHRvbixbcm9sZT1cImJ1dHRvblwiXSxhW2hyZWZdJylcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBjb25zdCByZXRyeSA9IGNvbnRyb2xzLmZpbmQoKGVsKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHRleHQgPSBub3JtYWxpemVkVGV4dChlbCk7XG4gICAgICAgICAgICAgIHJldHVybiB0ZXh0ID09PSAncmV0cnknIHx8IHRleHQuaW5jbHVkZXMoJ3JldHJ5JykgfHwgdGV4dC5pbmNsdWRlcygndHJ5IGFnYWluJyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICghcmV0cnkpIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIChyZXRyeSBhcyBIVE1MRWxlbWVudCkuY2xpY2soKTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH07XG4gICAgICAgICAgaWYgKGNsaWNrUmV0cnlJZlJlbG9hZEVycm9yKCkpIHJldHVybiB7IHJldHJpZWQ6IHRydWUsIHNjcm9sbGVkOiBmYWxzZSB9O1xuICAgICAgICAgIC8vIFNjcm9sbCB0aGUgcGFnZS4gRGlzcGF0Y2ggRW5kIGtleSBmaXJzdCBzaW5jZSBtYW55IFggc3VyZmFjZXNcbiAgICAgICAgICAvLyAgICAobGlzdHMsIHNlYXJjaCwgcmVwbGllcykgYmluZCBwYWdpbmF0aW9uIHRyaWdnZXJzIHRvIGl0IHZpYVxuICAgICAgICAgIC8vICAgIFJlYWN0IGhhbmRsZXJzOyB0aGVuIGV4cGxpY2l0bHkgc2Nyb2xsIHRoZSBkb2N1bWVudC5cbiAgICAgICAgICBjb25zdCBvcHRzOiBLZXlib2FyZEV2ZW50SW5pdCA9IHtcbiAgICAgICAgICAgIGtleTogJ0VuZCcsXG4gICAgICAgICAgICBjb2RlOiAnRW5kJyxcbiAgICAgICAgICAgIGtleUNvZGU6IDM1LFxuICAgICAgICAgICAgd2hpY2g6IDM1LFxuICAgICAgICAgICAgYnViYmxlczogdHJ1ZSxcbiAgICAgICAgICAgIGNhbmNlbGFibGU6IHRydWUsXG4gICAgICAgICAgfTtcbiAgICAgICAgICBjb25zdCBmb2N1cyA9IChkb2N1bWVudC5hY3RpdmVFbGVtZW50IGFzIEhUTUxFbGVtZW50IHwgbnVsbCkgPz8gZG9jdW1lbnQuYm9keTtcbiAgICAgICAgICBmb2N1cy5kaXNwYXRjaEV2ZW50KG5ldyBLZXlib2FyZEV2ZW50KCdrZXlkb3duJywgb3B0cykpO1xuICAgICAgICAgIGZvY3VzLmRpc3BhdGNoRXZlbnQobmV3IEtleWJvYXJkRXZlbnQoJ2tleXVwJywgb3B0cykpO1xuICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbyh7XG4gICAgICAgICAgICB0b3A6IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxIZWlnaHQsXG4gICAgICAgICAgICBiZWhhdmlvcjogJ2F1dG8nLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHJldHVybiB7IHJldHJpZWQ6IGZhbHNlLCBzY3JvbGxlZDogdHJ1ZSB9O1xuICAgICAgICB9KSBhcyB1bmtub3duIGFzICgpID0+IHZvaWQsXG4gICAgICB9KSkgYXMgQXJyYXk8eyByZXN1bHQ/OiB1bmtub3duIH0+O1xuICAgICAgY29uc3QgcGFnZVJlc3VsdHMgPSByZXN1bHRzXG4gICAgICAgIC5tYXAoKHIpID0+IHIucmVzdWx0KVxuICAgICAgICAuZmlsdGVyKFxuICAgICAgICAgIChyZXN1bHQpOiByZXN1bHQgaXMgeyByZXRyaWVkPzogdW5rbm93bjsgc2Nyb2xsZWQ/OiB1bmtub3duIH0gPT5cbiAgICAgICAgICAgIHR5cGVvZiByZXN1bHQgPT09ICdvYmplY3QnICYmIHJlc3VsdCAhPT0gbnVsbFxuICAgICAgICApO1xuICAgICAgaWYgKHBhZ2VSZXN1bHRzLnNvbWUoKHJlc3VsdCkgPT4gcmVzdWx0LnJldHJpZWQgPT09IHRydWUpKSB7XG4gICAgICAgIHJldHJ5Q291bnQgKz0gMTtcbiAgICAgIH1cbiAgICAgIGlmIChwYWdlUmVzdWx0cy5zb21lKChyZXN1bHQpID0+IHJlc3VsdC5zY3JvbGxlZCA9PT0gdHJ1ZSkpIHtcbiAgICAgICAgc2Nyb2xsQ291bnQgKz0gMTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIFRhYnMgdGhhdCBkaXNhbGxvdyBzY3JpcHRpbmcgKGFib3V0OiwgZGlzY2FyZGVkLCBtaWQtbmF2aWdhdGlvbilcbiAgICAgIC8vIGp1c3QgZ2V0IHNraXBwZWQgXHUyMDE0IHRoZXknbGwgYmUgZWxpZ2libGUgb24gYSBsYXRlciB0aWNrLlxuICAgIH1cbiAgfVxuICBpZiAocmV0cnlDb3VudCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdhdXRvLXNjcm9sbCBjbGlja2VkIFggcmV0cnkgY29udHJvbCcsIHsgdGFiX2NvdW50OiByZXRyeUNvdW50IH0pO1xuICB9XG4gIGlmIChzY3JvbGxDb3VudCA+IDApIHtcbiAgICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICBpZiAoc2VzcyAhPT0gbnVsbCkge1xuICAgICAgc2Vzcy5zY3JvbGxDb3VudCArPSBzY3JvbGxDb3VudDtcbiAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKHNlc3MpO1xuICAgICAgLy8gTm8gYnJvYWRjYXN0IG9uIGV2ZXJ5IHRpY2sgXHUyMDE0IHRoZSAxNXMgc2lkZWJhciByZWZyZXNoIHBpY2tzIGl0IHVwLlxuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBwcnVuZVNob3dNb3JlUmVsZXZhbmNlKCk6IHZvaWQge1xuICBjb25zdCBjdXRvZmYgPSBEYXRlLm5vdygpIC0gU0hPV19NT1JFX1JFTEVWQU5DRV9UVExfTVM7XG4gIGZvciAoY29uc3QgW3RhYklkLCBlbnRyeV0gb2Ygc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiKSB7XG4gICAgaWYgKGVudHJ5LnVwZGF0ZWRBdCA8IGN1dG9mZikgc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiLmRlbGV0ZSh0YWJJZCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVtZW1iZXJTaG93TW9yZVJlbGV2YW50VHdlZXRzKFxuICB0YWJJZDogbnVtYmVyIHwgbnVsbCxcbiAgcGFnZVVybDogc3RyaW5nIHwgbnVsbCxcbiAgdHdlZXRzOiBSZWFkb25seUFycmF5PENhbm9uaWNhbFR3ZWV0PixcbiAgY29yZUhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz5cbik6IHZvaWQge1xuICBpZiAodGFiSWQgPT09IG51bGwgfHwgdHdlZXRzLmxlbmd0aCA9PT0gMCB8fCBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm47XG4gIGNvbnN0IGNvcmVUd2VldElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgaWYgKGNvcmVIYW5kbGVzLmhhcyh0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSBjb3JlVHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xuICB9XG4gIGNvbnN0IGV4aXN0aW5nID0gc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiLmdldCh0YWJJZCk7XG4gIGNvbnN0IHR3ZWV0SWRzID0gZXhpc3Rpbmc/LnR3ZWV0SWRzID8/IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XG4gICAgY29uc3QgaGFuZGxlID0gdC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IHJlcGx5SGFuZGxlID0gdC5yZXBseV90b19hY2NvdW50Py50b0xvd2VyQ2FzZSgpID8/IG51bGw7XG4gICAgaWYgKFxuICAgICAgY29yZUhhbmRsZXMuaGFzKGhhbmRsZSkgfHxcbiAgICAgIChyZXBseUhhbmRsZSAhPT0gbnVsbCAmJiBjb3JlSGFuZGxlcy5oYXMocmVwbHlIYW5kbGUpKSB8fFxuICAgICAgKHQucmVwbHlfdG9fdHdlZXRfaWQgIT09IG51bGwgJiYgY29yZVR3ZWV0SWRzLmhhcyh0LnJlcGx5X3RvX3R3ZWV0X2lkKSkgfHxcbiAgICAgICh0LnF1b3RlZF90d2VldF9pZCAhPT0gbnVsbCAmJiBjb3JlVHdlZXRJZHMuaGFzKHQucXVvdGVkX3R3ZWV0X2lkKSkgfHxcbiAgICAgICh0LnJldHdlZXRlZF90d2VldF9pZCAhPT0gbnVsbCAmJiBjb3JlVHdlZXRJZHMuaGFzKHQucmV0d2VldGVkX3R3ZWV0X2lkKSlcbiAgICApIHtcbiAgICAgIHR3ZWV0SWRzLmFkZCh0LnR3ZWV0X2lkKTtcbiAgICB9XG4gIH1cbiAgc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiLnNldCh0YWJJZCwge1xuICAgIHVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcbiAgICBwYWdlVXJsLFxuICAgIHR3ZWV0SWRzLFxuICB9KTtcbn1cblxuYnJvd3Nlci5hbGFybXMub25BbGFybS5hZGRMaXN0ZW5lcigoYWxhcm0pID0+IHtcbiAgaWYgKGFsYXJtLm5hbWUgPT09ICdmbHVzaC1zd2VlcCcpIHtcbiAgICB2b2lkIGZsdXNoSWRsZUJ1ZmZlcnMoKTtcbiAgfSBlbHNlIGlmIChhbGFybS5uYW1lID09PSAndmVyaWZ5LWNvbm5lY3Rpb24nKSB7XG4gICAgdm9pZCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcbiAgfVxuICAvLyByZWZldGNoIC8gbWVkaWEtY3Jhd2wgcHJldmlvdXNseSByYW4gdmlhIGFsYXJtczsgdGhleSBub3cgdXNlXG4gIC8vIHNldEludGVydmFsIHRvIGVzY2FwZSB0aGUgMzBzIGFsYXJtIGZsb29yLiBMZWF2ZSB0aGUgbmFtZXMgbGlzdGVkXG4gIC8vIG5vd2hlcmUgc28gYW55IG9ycGhhbmVkIGFsYXJtcyAoZnJvbSBvbGRlciBidWlsZHMpIGp1c3Qgbm8tb3AuXG59KTtcblxuLy8gLS0tIFRvb2xiYXIgYWN0aW9uOiB0b2dnbGUgdGhlIHNpZGViYXIgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuaWYgKGJyb3dzZXIuYWN0aW9uPy5vbkNsaWNrZWQpIHtcbiAgYnJvd3Nlci5hY3Rpb24ub25DbGlja2VkLmFkZExpc3RlbmVyKGFzeW5jICh0YWIpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc2lkZWJhckFjdGlvbiA9IChcbiAgICAgICAgYnJvd3NlciBhcyB1bmtub3duIGFzIHtcbiAgICAgICAgICBzaWRlYmFyQWN0aW9uPzogeyB0b2dnbGU/OiAoKSA9PiBQcm9taXNlPHZvaWQ+IH07XG4gICAgICAgIH1cbiAgICAgICkuc2lkZWJhckFjdGlvbjtcbiAgICAgIGlmIChzaWRlYmFyQWN0aW9uPy50b2dnbGUpIHtcbiAgICAgICAgYXdhaXQgc2lkZWJhckFjdGlvbi50b2dnbGUoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBzaWRlUGFuZWwgPSAoXG4gICAgICAgIGJyb3dzZXIgYXMgdW5rbm93biBhcyB7XG4gICAgICAgICAgc2lkZVBhbmVsPzogeyBvcGVuPzogKG9wdGlvbnM6IHsgd2luZG93SWQ/OiBudW1iZXIgfSkgPT4gUHJvbWlzZTx2b2lkPiB9O1xuICAgICAgICB9XG4gICAgICApLnNpZGVQYW5lbDtcbiAgICAgIGlmIChzaWRlUGFuZWw/Lm9wZW4pIHtcbiAgICAgICAgY29uc3Qgb3B0aW9uczogeyB3aW5kb3dJZD86IG51bWJlciB9ID0ge307XG4gICAgICAgIGlmICh0eXBlb2YgdGFiLndpbmRvd0lkID09PSAnbnVtYmVyJykgb3B0aW9ucy53aW5kb3dJZCA9IHRhYi53aW5kb3dJZDtcbiAgICAgICAgYXdhaXQgc2lkZVBhbmVsLm9wZW4ob3B0aW9ucyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogYnJvd3Nlci5ydW50aW1lLmdldFVSTCgnc2lkZWJhci5odG1sJykgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAvLyBGYWxsYmFjazogb3BlbiB0aGUgZXh0ZW5zaW9uIFVJIGluIGEgdGFiIGlmIHRoZSBicm93c2VyLXNwZWNpZmljXG4gICAgICAvLyBzaWRlYmFyIEFQSSBpcyB1bmF2YWlsYWJsZSBvciByZWplY3RzIHRoZSBhY3Rpb24tY2xpY2sgcmVxdWVzdC5cbiAgICAgIGF3YWl0IHdhcm4oJ3NpZGViYXIgb3BlbiBmYWlsZWQ7IG9wZW5pbmcgc2lkZWJhciB0YWInLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogYnJvd3Nlci5ydW50aW1lLmdldFVSTCgnc2lkZWJhci5odG1sJykgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH0gY2F0Y2ggKHRhYkVycikge1xuICAgICAgICBhd2FpdCB3YXJuKCdzaWRlYmFyIHRhYiBmYWlsZWQ7IG9wZW5pbmcgb3B0aW9ucycsIGRlc2NyaWJlRXJyb3IodGFiRXJyKSk7XG4gICAgICB9XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgfVxuICB9KTtcbn1cblxuLy8gLS0tIFJ1bnRpbWUgbWVzc2FnZSBkaXNwYXRjaCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24sIHNlbmRlcikgPT4ge1xuICBpZiAoIWlzUnVudGltZU1lc3NhZ2UobXNnKSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgcmV0dXJuIGhhbmRsZU1lc3NhZ2UobXNnLCBzZW5kZXIpLmNhdGNoKChlcnIpID0+IHtcbiAgICB2b2lkIGxvZ0VycignbWVzc2FnZSBoYW5kbGVyIGZhaWxlZCcsIHsgdHlwZTogbXNnLnR5cGUsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcbiAgICB0aHJvdyBlcnI7XG4gIH0pO1xufSk7XG5cbmZ1bmN0aW9uIGlzUnVudGltZU1lc3NhZ2UobTogdW5rbm93bik6IG0gaXMgUnVudGltZU1lc3NhZ2Uge1xuICByZXR1cm4gISFtICYmIHR5cGVvZiBtID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgKG0gYXMgeyB0eXBlPzogdW5rbm93biB9KS50eXBlID09PSAnc3RyaW5nJztcbn1cblxuLyoqIE1lc3NhZ2VzIHRoYXQgZHJpdmUgdGhlIGNhcHR1cmUgcGlwZWxpbmUuIFdoZW4gdGhlIG1hc3RlciBzd2l0Y2ggaXMgT0ZGXG4gKiB3ZSBpZ25vcmUgdGhlc2UgYnV0IHN0aWxsIHJlc3BvbmQgdG8gc3RhdHVzIC8gY29uZmlndXJhdGlvbiBxdWVyaWVzLiAqL1xuY29uc3QgQ0FQVFVSRV9QSVBFTElORV9NRVNTQUdFUyA9IG5ldyBTZXQ8UnVudGltZU1lc3NhZ2VbJ3R5cGUnXT4oW1xuICAnZ3JhcGhxbC1jYXB0dXJlJyxcbiAgJ2NhcHR1cmUtbm93JyxcbiAgJ2NhcHR1cmUtYWxsJyxcbiAgJ2NhcHR1cmUtdGhpcy1wYWdlJyxcbiAgJ2ZsdXNoLWFsbCcsXG4gICdmbHVzaC1oYW5kbGUnLFxuICAnc3RhcnQtcmVmZXRjaCcsXG4gICdzdGFydC1tZWRpYS1jcmF3bCcsXG4gICdzdGFydC10aHJlYWQtb3BlbicsXG4gICdzdGFydC1hdXRvLXNjcm9sbCcsXG5dKTtcblxuYXN5bmMgZnVuY3Rpb24gaXNFbmFibGVkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgcmV0dXJuIHMuZW5hYmxlZCAhPT0gZmFsc2U7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UoXG4gIG1zZzogUnVudGltZU1lc3NhZ2UsXG4gIHNlbmRlcj86IGJyb3dzZXIucnVudGltZS5NZXNzYWdlU2VuZGVyXG4pOiBQcm9taXNlPHVua25vd24+IHtcbiAgLy8gTWFzdGVyIHN3aXRjaDogd2hlbiB0aGUgdXNlciBoYXMgcGF1c2VkIHRoZSBleHRlbnNpb24gd2Ugc3RpbGwgbmVlZFxuICAvLyB0aGUgbWV0YS1jaGFubmVscyAoZ2V0LXN0YXRlLCB0b2dnbGUtZW5hYmxlZCwgb3Blbi1vcHRpb25zLCBcdTIwMjYpIHNvIHRoZVxuICAvLyBzaWRlYmFyIHN0YXlzIGZ1bmN0aW9uYWwsIGJ1dCBhbnl0aGluZyB0aGF0IHdvdWxkIGFjdHVhbGx5IGNhcHR1cmUsXG4gIC8vIGNvbW1pdCwgb3IgZHJpdmUgYSB0YWIgaXMgYSBuby1vcC5cbiAgaWYgKCEoYXdhaXQgaXNFbmFibGVkKCkpICYmIENBUFRVUkVfUElQRUxJTkVfTUVTU0FHRVMuaGFzKG1zZy50eXBlKSkge1xuICAgIHJldHVybiB7IG9rOiB0cnVlLCBwYXVzZWQ6IHRydWUgfTtcbiAgfVxuICBzd2l0Y2ggKG1zZy50eXBlKSB7XG4gICAgY2FzZSAnZ3JhcGhxbC1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IG9uR3JhcGhxbENhcHR1cmUoXG4gICAgICAgIG1zZy5lbmRwb2ludCxcbiAgICAgICAgbXNnLnVybCxcbiAgICAgICAgbXNnLnBhZ2VVcmwgPz8gbnVsbCxcbiAgICAgICAgbXNnLnJlc3BvbnNlLFxuICAgICAgICBzZW5kZXI/LnRhYj8uaWQgPz8gbnVsbFxuICAgICAgKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnY29udGVudC1hbGl2ZSc6XG4gICAgICBhd2FpdCBpbmZvKCdjb250ZW50IHNjcmlwdCBhbGl2ZSBvbiBwYWdlJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ3BhZ2UtaG9vay1hY3RpdmUnOlxuICAgICAgYXdhaXQgaW5mbygncGFnZSBob29rIHBhdGNoZWQgZmV0Y2gvWEhSJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ2xvZy1jb250ZW50LWV2ZW50JzpcbiAgICAgIGlmIChtc2cubGV2ZWwgPT09ICd3YXJuJykge1xuICAgICAgICBhd2FpdCB3YXJuKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfSBlbHNlIGlmIChtc2cubGV2ZWwgPT09ICdlcnJvcicpIHtcbiAgICAgICAgYXdhaXQgbG9nRXJyKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXdhaXQgaW5mbyhtc2cubXNnLCB7IHVybDogc2hvcnRlblVybChtc2cudXJsKSB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XG4gICAgY2FzZSAnZ2V0LXVuZm9sZC10YXJnZXRzJzoge1xuICAgICAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICAgICAgaWYgKHNldHRpbmdzLmVuYWJsZWQgPT09IGZhbHNlKSB7XG4gICAgICAgIHJldHVybiB7IGVuYWJsZWQ6IGZhbHNlLCBjb3JlSGFuZGxlczogW10sIHJlbGV2YW50VHdlZXRJZHM6IFtdIH07XG4gICAgICB9XG4gICAgICBwcnVuZVNob3dNb3JlUmVsZXZhbmNlKCk7XG4gICAgICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gICAgICBjb25zdCBjb3JlSGFuZGxlcyA9IGFjY291bnRzXG4gICAgICAgIC5maWx0ZXIoKGEpID0+IGEuY2F0ZWdvcnkgPT09ICdjb3JlJylcbiAgICAgICAgLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSk7XG4gICAgICBjb25zdCB0YWJJZCA9IHNlbmRlcj8udGFiPy5pZCA/PyBudWxsO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgY29yZUhhbmRsZXMsXG4gICAgICAgIHJlbGV2YW50VHdlZXRJZHM6XG4gICAgICAgICAgdGFiSWQgPT09IG51bGwgPyBbXSA6IEFycmF5LmZyb20oc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiLmdldCh0YWJJZCk/LnR3ZWV0SWRzID8/IFtdKSxcbiAgICAgIH07XG4gICAgfVxuICAgIGNhc2UgJ3Nob3ctbW9yZS11bmZvbGRlZCc6IHtcbiAgICAgIGlmIChtc2cuY291bnQgPiAwKSB7XG4gICAgICAgIGNvbnN0IGFzU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICAgIGlmIChhc1Nlc3MgIT09IG51bGwpIHtcbiAgICAgICAgICBhc1Nlc3MuZXhwYW5kZWRDb3VudCArPSBtc2cuY291bnQ7XG4gICAgICAgICAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oYXNTZXNzKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gICAgY2FzZSAnZ2V0LXN0YXRlJzpcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS1ub3cnOlxuICAgICAgYXdhaXQgY2FwdHVyZU5vdyhtc2cuaGFuZGxlKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FwdHVyZS1hbGwnOlxuICAgICAgYXdhaXQgY2FwdHVyZUFsbCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjYXB0dXJlLXRoaXMtcGFnZSc6XG4gICAgICBhd2FpdCBjYXB0dXJlVGhpc1BhZ2UoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnZmx1c2gtYWxsJzpcbiAgICAgIGF3YWl0IGZsdXNoQWxsKCd1c2VyJyk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2ZsdXNoLWhhbmRsZSc6XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShtc2cuaGFuZGxlLCAndXNlcicpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtYXV0by1jYXB0dXJlJzpcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b0NhcHR1cmU6IG1zZy5vbiB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ2F1dG8tY2FwdHVyZSB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtdXBkYXRlLWV4aXN0aW5nJzpcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgdXBkYXRlRXhpc3Rpbmc6IG1zZy5vbiB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ3VwZGF0ZS1leGlzdGluZyB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtbG93LWJhbmR3aWR0aCc6XG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGxvd0JhbmR3aWR0aEJyb3dzaW5nOiBtc2cub24gfSk7XG4gICAgICBhd2FpdCBzeW5jTG93QmFuZHdpZHRoUnVsZXMoeyByZWFzb246ICd0b2dnbGUnLCBsb2c6IHRydWUgfSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3RvZ2dsZS1lbmFibGVkJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgZW5hYmxlZDogbXNnLm9uIH0pO1xuICAgICAgaWYgKCFtc2cub24pIHtcbiAgICAgICAgLy8gUGF1c2luZyBzdG9wcyBhbGwgaW4tZmxpZ2h0IGxvb3BzIHNvIHRoZSB1c2VyIGdldHMgaW1tZWRpYXRlXG4gICAgICAgIC8vIHF1aWV0LCBub3QgYSBcIm9uZSBtb3JlIHRpY2tcIiBzdXJwcmlzZS5cbiAgICAgICAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcbiAgICAgICAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICAgICAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XG4gICAgICAgIHN0b3BUaHJlYWRPcGVuSW50ZXJ2YWwoKTtcbiAgICAgICAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignbWVkaWEtY3Jhd2wtdGljaycpO1xuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigndGhyZWFkLW9wZW4tdGljaycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gUmVzdW1pbmcgcmUtYXJtcyBhbnkgbG9vcHMgd2hvc2Ugc2Vzc2lvbiBpcyBzdGlsbCBzZXQuXG4gICAgICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICAgICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBtYXN0ZXIgc3dpdGNoIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIH1cbiAgICBjYXNlICdzdGFydC1hdXRvLXNjcm9sbCc6XG4gICAgICBhd2FpdCBzdGFydEF1dG9TY3JvbGxMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1hdXRvLXNjcm9sbCc6XG4gICAgICBhd2FpdCBjYW5jZWxBdXRvU2Nyb2xsTG9vcCgpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdzZXQtYXV0by1zY3JvbGwtaW50ZXJ2YWwnOiB7XG4gICAgICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXG4gICAgICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXG4gICAgICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQobXNnLnNlY29uZHMpKVxuICAgICAgKTtcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzZWNvbmRzIH0pO1xuICAgICAgLy8gUmUtYXJtIGFueSBhY3RpdmUgbG9vcHMgd2l0aCB0aGUgbmV3IGludGVydmFsLlxuICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHNlY29uZHMpO1xuICAgICAgaWYgKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kcyk7XG4gICAgICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzKTtcbiAgICAgIGlmICh0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHN0YXJ0VGhyZWFkT3BlbkludGVydmFsKHNlY29uZHMpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAnc3RhcnQtcmVmZXRjaCc6XG4gICAgICBhd2FpdCBzdGFydFJlZmV0Y2hMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ2NhbmNlbC1yZWZldGNoJzpcbiAgICAgIGF3YWl0IGNhbmNlbFJlZmV0Y2hMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3N0YXJ0LW1lZGlhLWNyYXdsJzpcbiAgICAgIGF3YWl0IHN0YXJ0TWVkaWFDcmF3bExvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLW1lZGlhLWNyYXdsJzpcbiAgICAgIGF3YWl0IGNhbmNlbE1lZGlhQ3Jhd2xMb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3N0YXJ0LXRocmVhZC1vcGVuJzpcbiAgICAgIGF3YWl0IHN0YXJ0VGhyZWFkT3Blbkxvb3AoKTtcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XG4gICAgY2FzZSAnY2FuY2VsLXRocmVhZC1vcGVuJzpcbiAgICAgIGF3YWl0IGNhbmNlbFRocmVhZE9wZW5Mb29wKCk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3B1cmdlLXVucmVsYXRlZCc6IHtcbiAgICAgIGNvbnN0IGFjY3MgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICAgICAgY29uc3QgdHJhY2tlZCA9IG5ldyBTZXQoYWNjcy5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpKTtcbiAgICAgIGNvbnN0IHN1bW1hcnkgPSBhd2FpdCBwdXJnZVVucmVsYXRlZFN0YXRlKHRyYWNrZWQpO1xuICAgICAgYXdhaXQgaW5mbygncHVyZ2VkIHVucmVsYXRlZCBzdGF0ZScsIHN1bW1hcnkpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICB9XG4gICAgY2FzZSAncmVmcmVzaC1hY2NvdW50cyc6XG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd2ZXJpZnktY29ubmVjdGlvbic6XG4gICAgICBhd2FpdCB2ZXJpZnlDb25uZWN0aW9uKHRydWUpO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICdjbGVhci1hY3Rpdml0eSc6XG4gICAgICBhd2FpdCBjbGVhckFjdGl2aXR5KCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tb3B0aW9ucyc6XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgIGNhc2UgJ29wZW4tdmlld2VyJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gICAgICBjb25zdCB1cmwgPSB2aWV3ZXJVcmwocyk7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gICAgY2FzZSAnZ2V0LWNvdmVyYWdlLWdhcHMnOiB7XG4gICAgICBjb25zdCBzbmFwc2hvdCA9IGF3YWl0IGdldEFyY2hpdmVTbmFwc2hvdCgpO1xuICAgICAgaWYgKCFzbmFwc2hvdCkge1xuICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAnbm8gYXJjaGl2ZSBzbmFwc2hvdCB5ZXQgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpb24gaW4gU2V0dGluZ3MnIH07XG4gICAgICB9XG4gICAgICBjb25zdCBhbGw6IENvdmVyYWdlR2FwW10gPSBbXTtcbiAgICAgIGZvciAoY29uc3QgYWNjb3VudCBvZiBPYmplY3QudmFsdWVzKHNuYXBzaG90LmFjY291bnRzKSkge1xuICAgICAgICBhbGwucHVzaCguLi5maW5kQ292ZXJhZ2VHYXBzKGFjY291bnQpKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG9rOiB0cnVlLCBnYXBzOiByYW5rR2FwcyhhbGwpLCBnZW5lcmF0ZWRBdDogc25hcHNob3QuZ2VuZXJhdGVkX2F0IH07XG4gICAgfVxuICAgIGNhc2UgJ29wZW4tdXJsJzoge1xuICAgICAgY29uc3QgdXJsID0gbXNnLnVybDtcbiAgICAgIGlmICh0eXBlb2YgdXJsICE9PSAnc3RyaW5nJyB8fCAhL15odHRwczpcXC9cXC8oeFxcLmNvbXx0d2l0dGVyXFwuY29tKVxcLy8udGVzdCh1cmwpKSB7XG4gICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICdyZWZ1c2luZyB0byBvcGVuIGEgbm9uLVggdXJsJyB9O1xuICAgICAgfVxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiB0cnVlIH0pO1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICd1bmtub3duIG1lc3NhZ2UgdHlwZScgfTtcbiAgfVxufVxuXG4vLyAtLS0gQ2FwdHVyZSBwaXBlbGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBvbkdyYXBocWxDYXB0dXJlKFxuICBlbmRwb2ludDogc3RyaW5nLFxuICB1cmw6IHN0cmluZyxcbiAgcGFnZVVybDogc3RyaW5nIHwgbnVsbCxcbiAgcmVzcG9uc2U6IHVua25vd24sXG4gIHNlbmRlclRhYklkOiBudW1iZXIgfCBudWxsXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKFBST0ZJTEVfRU5EUE9JTlRTLmhhcyhlbmRwb2ludCkpIHJldHVybjsgLy8gbm90IHR3ZWV0LWJlYXJpbmdcbiAgaWYgKCFUV0VFVF9FTkRQT0lOVFMuaGFzKGVuZHBvaW50KSkgcmV0dXJuO1xuXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKHNldHRpbmdzLmVuYWJsZWQgPT09IGZhbHNlKSByZXR1cm47XG4gIGlmIChzZXR0aW5ncy5hdXRvQ2FwdHVyZSA9PT0gZmFsc2UpIHtcbiAgICBjb25zdCBleHBsaWNpdENhcHR1cmVBY3RpdmUgPVxuICAgICAgRGF0ZS5ub3coKSA8IG1hbnVhbENhcHR1cmVVbnRpbE1zIHx8XG4gICAgICAoYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKSkgIT09IG51bGwgfHxcbiAgICAgIChhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpKSAhPT0gbnVsbCB8fFxuICAgICAgKGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCkpICE9PSBudWxsO1xuICAgIGlmICghZXhwbGljaXRDYXB0dXJlQWN0aXZlKSByZXR1cm47XG4gIH1cblxuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIC8vIFdlIGRlbGliZXJhdGVseSBkbyBOT1Qgc2hvcnQtY2lyY3VpdCB3aGVuIHRoZSBQQVQgaXMgbWlzc2luZy4gVGhlXG4gIC8vIG5vcm1hbGl6ZSBzdGVwIGlzIGNoZWFwLCB0aGUgYnVmZmVyIHN1cnZpdmVzIHNlcnZpY2Utd29ya2VyIGV2aWN0aW9uLFxuICAvLyBhbmQgb25jZSB0aGUgUEFUIGlzIHNldCB0aGUgbmV4dCBhbGFybSBvciB1c2VyLXRyaWdnZXJlZCBmbHVzaCBjb21taXRzXG4gIC8vIGV2ZXJ5dGhpbmcgd2UndmUgc2Vlbi4gRHJvcHBpbmcgY2FwdHVyZXMgaGVyZSB3YXMgaGlkaW5nIHRoZSB1c2VyJ3NcbiAgLy8gZmlyc3QgYnJvd3Npbmcgc2Vzc2lvbiBlbnRpcmVseS5cblxuICAvLyBUd28tc3RhZ2UgZmlsdGVyOlxuICAvLyAgIDEuIEJ1aWxkIEVWRVJZIGNhbm9uaWNhbCB0d2VldCB3ZSBjYW4gZmluZCBpbiB0aGUgcmVzcG9uc2UgKG5vIGhhbmRsZVxuICAvLyAgICAgIGZpbHRlciBhdCB0aGUgbm9ybWFsaXplciBsZXZlbCBcdTIwMTQgd2Ugc3RpbGwgd2FudCBxdW90ZWQvUlQnZCBwYXJlbnRzXG4gIC8vICAgICAgdGhhdCBhcHBlYXIgYXMgc2libGluZyBub2RlcykuXG4gIC8vICAgMi4gQXBwbHkgYGZpbHRlclJlbGF0ZWRgIHBvc3QtaG9jIHRvIGRyb3AgYW55dGhpbmcgdGhhdCBoYXMgbm9cbiAgLy8gICAgICByZWxhdGlvbnNoaXAgdG8gYSB0cmFja2VkIGFjY291bnQuIFRoZSBvbGQgYmVoYXZpb3VyIChcImVtcHR5XG4gIC8vICAgICAgYWxsb3dlZC1zZXQgb24gdXNlci1wYWdlIGVuZHBvaW50cywgZnVsbCBmaWx0ZXIgb24gaG9tZS9zZWFyY2hcIilcbiAgLy8gICAgICB3YXMgd2F5IHRvbyBwZXJtaXNzaXZlIG9uIHRoZSBSZXBsaWVzIHRhYjogZXZlcnkgcmFuZG9tIHJlcGxpZXInc1xuICAvLyAgICAgIHJlcGx5IGxhbmRlZCBpbiBhIHBlci1oYW5kbGUgYnVmZmVyIGtleWVkIGJ5IHRoZWlyIG93biBoYW5kbGUuXG4gIGNvbnN0IHRyYWNrZWQgPSBuZXcgU2V0KGFjY291bnRzLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSkpO1xuICBjb25zdCBjb3JlID0gbmV3IFNldChcbiAgICBhY2NvdW50cy5maWx0ZXIoKGEpID0+IGEuY2F0ZWdvcnkgPT09ICdjb3JlJykubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKVxuICApO1xuICBjb25zdCBjYXB0dXJlZEF0ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuXG4gIGxldCBub3JtYWxpemVkO1xuICB0cnkge1xuICAgIG5vcm1hbGl6ZWQgPSBub3JtYWxpemUocmVzcG9uc2UsIHtcbiAgICAgIGNhcHR1cmVkQXQsXG4gICAgICBydW5JZDogJ3BlbmRpbmcnLFxuICAgICAgZW5kcG9pbnQsXG4gICAgICBhbGxvd2VkSGFuZGxlczogbmV3IFNldDxzdHJpbmc+KCksXG4gICAgICBzb3VyY2VVcmw6IHBhZ2VVcmwsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHF1YXJhbnRpbmUoJ25vcm1hbGl6ZS10aHJldycsIGVuZHBvaW50LCB1cmwsIHJlc3BvbnNlLCBlcnIpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCByZXR3ZWV0RWRnZXMgPSBidWlsZFJldHdlZXRFZGdlcyhcbiAgICBub3JtYWxpemVkLnR3ZWV0cyxcbiAgICBhY2NvdW50cyxcbiAgICBjYXB0dXJlZEF0LFxuICAgIGVuZHBvaW50LFxuICAgIHBhZ2VVcmwgPz8gdXJsXG4gICk7XG4gIC8vIERyb3AgdW5yZWxhdGVkIHR3ZWV0cy4gVGhlIGZpbHRlciBpcyBlbmRwb2ludC1hd2FyZTpcbiAgLy8gICAtIE9uIHRoZSBob21lIC8gc2VhcmNoIHRpbWVsaW5lcyB3ZSdkIGFscmVhZHkgYmVlbiBmaWx0ZXJpbmcgdG9cbiAgLy8gICAgIHRyYWNrZWQgYXV0aG9ycyBvbmx5IFx1MjAxNCBrZWVwIHRoYXQgYmVoYXZpb3VyIGJ1dCBnbyB0aHJvdWdoIHRoZSBzYW1lXG4gIC8vICAgICBgZmlsdGVyUmVsYXRlZGAgaGVscGVyIHNvIHRoZSBydWxlcyBhcmUgdW5pZm9ybS5cbiAgLy8gICAtIE9uIHVzZXItcGFnZSBlbmRwb2ludHMgd2Ugbm93IGFsc28gZHJvcCBhbnl0aGluZyB0aGF0IGlzbid0IGVpdGhlclxuICAvLyAgICAgYXV0aG9yZWQtYnksIG1lbnRpb25pbmcsIHJlcGx5aW5nLXRvLCBvciByZWZlcmVuY2VkLWJ5IGEgdHJhY2tlZFxuICAvLyAgICAgYWNjb3VudC5cbiAgY29uc3QgYmVmb3JlRmlsdGVyID0gbm9ybWFsaXplZC50d2VldHMubGVuZ3RoO1xuICBub3JtYWxpemVkLnR3ZWV0cyA9IGZpbHRlclJlbGF0ZWQobm9ybWFsaXplZC50d2VldHMsIHRyYWNrZWQsIGNvcmUpO1xuICBjb25zdCBkcm9wcGVkVW5yZWxhdGVkID0gYmVmb3JlRmlsdGVyIC0gbm9ybWFsaXplZC50d2VldHMubGVuZ3RoO1xuICBpZiAoZHJvcHBlZFVucmVsYXRlZCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdkcm9wcGVkIHVucmVsYXRlZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIGRyb3BwZWQ6IGRyb3BwZWRVbnJlbGF0ZWQsXG4gICAgICBrZXB0OiBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGgsXG4gICAgfSk7XG4gIH1cbiAgcmVtZW1iZXJTaG93TW9yZVJlbGV2YW50VHdlZXRzKHNlbmRlclRhYklkLCBwYWdlVXJsLCBub3JtYWxpemVkLnR3ZWV0cywgY29yZSk7XG5cbiAgLy8gRGlhZ25vc3RpYzogZXZlcnkgdHdlZXQtZW5kcG9pbnQgcGF5bG9hZCBnZXRzIGEgbGluZSBpbiB0aGUgYWN0aXZpdHlcbiAgLy8gdGFpbCB3aXRoIHdoYXQgd2Ugc2F3IHZzIGtlcHQuIFdoZW4gb2JzZXJ2ZWQ9MCB3ZSBhbHNvIGVtaXQgYSBzaGFwZVxuICAvLyBwcm9iZSAoa2V5IHBhdGhzICsgdHlwZW5hbWVzKSBzbyB3ZSBjYW4gdGVsbCB3aGV0aGVyIFggcmV0dXJuZWQgYW5cbiAgLy8gZW1wdHkgZW52ZWxvcGUsIGEgbG9naW4td2FsbCByZXNwb25zZSwgb3IgYSBuZXcgc2hhcGUgd2UgZG9uJ3Qga25vdyBob3dcbiAgLy8gdG8gd2FsayB5ZXQuXG4gIGlmIChub3JtYWxpemVkLm9ic2VydmVkX2lkcy5sZW5ndGggPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCdncmFwaHFsIHBheWxvYWQgZW1wdHkgXHUyMDE0IHNoYXBlIHByb2JlJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICB0eXBlbmFtZXM6IHByb2JlVHlwZW5hbWVzKHJlc3BvbnNlKS5zbGljZSgwLCAzMCksXG4gICAgICB0d2VldF9rZXlzOiBwcm9iZUZpcnN0VHlwZVNoYXBlKHJlc3BvbnNlLCAnVHdlZXQnKSxcbiAgICAgIHR3ZWV0X2NvcmVfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgWydjb3JlJ10pLFxuICAgICAgdHdlZXRfbGVnYWN5X2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFsnbGVnYWN5J10pLFxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXG4gICAgICAgICdjb3JlJyxcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXG4gICAgICAgICdyZXN1bHQnLFxuICAgICAgXSksXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2NvcmVfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xuICAgICAgICAnY29yZScsXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxuICAgICAgICAncmVzdWx0JyxcbiAgICAgICAgJ2NvcmUnLFxuICAgICAgXSksXG4gICAgICB1c2VyX3Jlc3VsdHNfcmVzdWx0X2xlZ2FjeV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXG4gICAgICAgICdjb3JlJyxcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXG4gICAgICAgICdyZXN1bHQnLFxuICAgICAgICAnbGVnYWN5JyxcbiAgICAgIF0pLFxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGF3YWl0IGluZm8oJ2dyYXBocWwgcGF5bG9hZCBzZWVuJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBvYnNlcnZlZDogbm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoLFxuICAgICAga2VwdDogbm9ybWFsaXplZC50d2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG5cbiAgaWYgKG5vcm1hbGl6ZWQudW5hdmFpbGFibGVfdHdlZXRzLmxlbmd0aCA+IDApIHtcbiAgICBhd2FpdCByZWNvcmRVbmF2YWlsYWJsZVR3ZWV0cyhcbiAgICAgIG5vcm1hbGl6ZWQudW5hdmFpbGFibGVfdHdlZXRzLFxuICAgICAgdHJhY2tlZCxcbiAgICAgIGNhcHR1cmVkQXQsXG4gICAgICB1cmwsXG4gICAgICBlbmRwb2ludFxuICAgICk7XG4gIH1cblxuICBpZiAobm9ybWFsaXplZC50d2VldHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgYnVmZmVyZWRFZGdlcyA9IGF3YWl0IGJ1ZmZlclJldHdlZXRFZGdlcyhcbiAgICAgIHJldHdlZXRFZGdlcyxcbiAgICAgIGNhcHR1cmVkQXQsXG4gICAgICBwYWdlVXJsID8/IHVybCxcbiAgICAgIGVuZHBvaW50XG4gICAgKTtcbiAgICBpZiAoYnVmZmVyZWRFZGdlcyA+IDApIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gUmVmZXRjaCBxdWV1ZSBob3VzZWtlZXBpbmcgXHUyMDE0IHJ1bnMgQkVGT1JFIHRoZSBkZWR1cCBzaG9ydC1jaXJjdWl0LiBBXG4gIC8vIHJlZmV0Y2ggY2FwdHVyZSBjb21lcyBiYWNrIHdpdGggdGhlIHNhbWUgZW5nYWdlbWVudCBjb3VudHMgKHdlJ3JlXG4gIC8vIG9ubHkgYWZ0ZXIgdGhlIGZ1bGwgdGV4dCksIHNvIHRoZSBkZWR1cCBiZWxvdyB3b3VsZCBzaWxlbnRseSBkcm9wXG4gIC8vIGl0IGFuZCB0aGUgcXVldWUgd291bGQgbmV2ZXIgZHJhaW4uIEhvaXN0IHRoZSBlbnF1ZXVlL2RlcXVldWUgaGVyZVxuICAvLyBzbyB0aGUgbG9vcCByZWxpYWJseSBhZHZhbmNlcyBldmVuIHdoZW4gbm8gY29tbWl0IGhhcHBlbnMuXG4gIC8vXG4gIC8vIEFsc286IGlmIGVpdGhlciBsb29wJ3MgaW5mbGlnaHQgdGFyZ2V0IGFwcGVhcnMgaGVyZSwgbWFyayB0aGUgbG9vcFxuICAvLyBhcyBcImluZ2VzdGVkXCIgc28gdGhlIG5leHQgdGljayBjYW4gYWR2YW5jZS4gVGhlIHdhaXQtZm9yLWluZ2VzdFxuICAvLyBndWFyZCBvdGhlcndpc2UgYmxvY2tzIHVudGlsIHRoZSBuYXZpZ2F0aW9uLXRpbWVvdXQgZmlyZXMuXG4gIGNvbnN0IHJlZmV0Y2hTZXNzID0gYXdhaXQgZ2V0UmVmZXRjaFNlc3Npb24oKTtcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBjb25zdCB0aHJlYWRPcGVuU2VzcyA9IGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCk7XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGlmICh0LmlzX3RydW5jYXRlZCkge1xuICAgICAgYXdhaXQgZW5xdWV1ZVJlZmV0Y2godC5hY2NvdW50X2hhbmRsZSwgdC50d2VldF9pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xuICAgIH1cbiAgICAvLyBTdWNjZXNzZnVsbHkgYnVpbHQgdHdlZXRzIGFyZSBubyBsb25nZXIgXCJwYXJ0aWFsXCIgXHUyMDE0IGRyb3AgZnJvbSB0aGVcbiAgICAvLyBtZWRpYS1jcmF3bCBxdWV1ZSByZWdhcmRsZXNzIG9mIHdoaWNoIGhhbmRsZSB3ZSdkIGhpbnRlZCBlYXJsaWVyLlxuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHQudHdlZXRfaWQpO1xuICAgIGlmIChyZWZldGNoU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcbiAgICAgIHJlZmV0Y2hTZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIHJlZmV0Y2hTZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgc2V0UmVmZXRjaFNlc3Npb24ocmVmZXRjaFNlc3MpO1xuICAgIH1cbiAgICBpZiAobWVkaWFDcmF3bFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XG4gICAgICBtZWRpYUNyYXdsU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICBtZWRpYUNyYXdsU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKG1lZGlhQ3Jhd2xTZXNzKTtcbiAgICB9XG4gICAgaWYgKHRocmVhZE9wZW5TZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdC50d2VldF9pZCkge1xuICAgICAgdGhyZWFkT3BlblNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgICAgdGhyZWFkT3BlblNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgICBhd2FpdCBtYXJrVGhyZWFkT3BlblNlZW4odC50d2VldF9pZCk7XG4gICAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih0LnR3ZWV0X2lkKTtcbiAgICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHRocmVhZE9wZW5TZXNzKTtcbiAgICB9XG4gIH1cblxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXQtc2hhcGVkIG5vZGVzIHRoZSB3YWxrZXIgc2F3IGJ1dCBjb3VsZG4ndCB0dXJuXG4gIC8vIGludG8gYSBmdWxsIGNhbm9uaWNhbCB0d2VldC4gRW5xdWV1ZSBvbmx5IElEcyB3ZSBoYXZlbid0IGFscmVhZHlcbiAgLy8gY29tbWl0dGVkICh1c2VyLXJlcXVlc3RlZCBkZWR1cCBhZ2FpbnN0IHRoZSBhcmNoaXZlKS5cbiAgZm9yIChjb25zdCBwYXJ0aWFsIG9mIG5vcm1hbGl6ZWQucGFydGlhbF9pZHMpIHtcbiAgICBpZiAoYXdhaXQgaXNDb21taXR0ZWQocGFydGlhbC50d2VldF9pZCkpIGNvbnRpbnVlO1xuICAgIGF3YWl0IGVucXVldWVNZWRpYUNyYXdsKHBhcnRpYWwuaGludF9oYW5kbGUsIHBhcnRpYWwudHdlZXRfaWQpO1xuICB9XG4gIGlmIChub3JtYWxpemVkLnBhcnRpYWxfaWRzLmxlbmd0aCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bDogZW5xdWV1ZWQgcGFydGlhbCBjYXB0dXJlcycsIHtcbiAgICAgIGVuZHBvaW50LFxuICAgICAgcGFydGlhbDogbm9ybWFsaXplZC5wYXJ0aWFsX2lkcy5sZW5ndGgsXG4gICAgICBxdWV1ZV90b3RhbDogYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKSxcbiAgICB9KTtcbiAgfVxuXG4gIC8vIENyb3NzLXNlc3Npb24gZGVkdXA6IGRyb3AgdHdlZXRzIHdlJ3ZlIGFscmVhZHkgY29tbWl0dGVkIHdpdGggaWRlbnRpY2FsXG4gIC8vIGVuZ2FnZW1lbnQgY291bnRzLiBMaWtlcy9SVHMvcmVwbGllcy9xdW90ZXMgc3RpbGwgdHJpZ2dlciBhIHJlY2FwdHVyZVxuICAvLyBzbyBlbmdhZ2VtZW50X2hpc3RvcnkgZ3Jvd3Mgb3ZlciB0aW1lLiB2aWV3X2NvdW50IGlzIGludGVudGlvbmFsbHlcbiAgLy8gZXhjbHVkZWQgXHUyMDE0IGl0IGNodXJucyB0b28gZmFzdCB0byBiZSB1c2VmdWwgYXMgYSBmcmVzaG5lc3Mgc2lnbmFsLlxuICAvLyBgaXNfdHJ1bmNhdGVkYCBpcyBwYXJ0IG9mIHRoZSBzaWduYXR1cmUgc28gYSByZWZldGNoIHRoYXQgZmxpcHNcbiAgLy8gdHJ1bmNhdGVkXHUyMTkyZnVsbCBpcyB0cmVhdGVkIGFzIGEgbWF0ZXJpYWwgY2hhbmdlIGFuZCBnZXRzIGNvbW1pdHRlZC5cbiAgLy9cbiAgLy8gV2hlbiB0aGUgdXNlciBoYXMgdHVybmVkIG9mZiBcInVwZGF0ZSBleGlzdGluZ1wiLCB3ZSBza2lwIHRoZSBlbmdhZ2VtZW50XG4gIC8vIGNvbXBhcmlzb24gZW50aXJlbHk6IGFueSB0d2VldCB0aGF0J3MgYWxyZWFkeSBjb21taXR0ZWQgdW5kZXIgYW55XG4gIC8vIGhhbmRsZSBnZXRzIGRyb3BwZWQgaGVyZSwgc28gd2UgZG9uJ3QgcGF5IEdpdEh1Yi1BUEkgb3ZlcmhlYWQganVzdCB0b1xuICAvLyByZWZyZXNoIGxpa2UgLyBSVCBjb3VudHMuIE5ldyB0d2VldHMgYW5kIHRydW5jYXRlZFx1MjE5MmZ1bGwgcmVmZXRjaGVzXG4gIC8vIHN0aWxsIGZsb3cgdGhyb3VnaCBub3JtYWxseSBiZWNhdXNlIHRoZXkgYXJlbid0IGluIHRoZSBpbmRleCB5ZXRcbiAgLy8gKG9yIGNhcnJ5IGFuIGlzX3RydW5jYXRlZCB0cmFuc2l0aW9uIHRoYXQgZmFpbHMgdGhlIHNpZyBjaGVjaykuXG4gIC8vIEZ1bGwtdGV4dCB1cGdyYWRlcyBieXBhc3MgdGhpcyBza2lwIGV2ZW4gd2l0aCB1cGRhdGVFeGlzdGluZz1mYWxzZS5cbiAgY29uc3QgdXBkYXRlRXhpc3RpbmcgPSBzZXR0aW5ncy51cGRhdGVFeGlzdGluZyAhPT0gZmFsc2U7XG4gIGNvbnN0IGNvbW1pdHRlZElkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGNvbnN0IGFyY2hpdmVTbmFwc2hvdCA9IGF3YWl0IGdldEFyY2hpdmVTbmFwc2hvdCgpO1xuICBsZXQgZGVkdXBlZFNraXBwZWQgPSAwO1xuICBsZXQgc2tpcHBlZE5vVXBkYXRlTG9jYWwgPSAwO1xuICBsZXQgc2tpcHBlZE5vVXBkYXRlU25hcHNob3QgPSAwO1xuICBsZXQgb2xkRnJvbVNuYXBzaG90ID0gMDtcbiAgbGV0IGZ1bGxUZXh0VXBncmFkZXMgPSAwO1xuICBjb25zdCBsaXZlVHdlZXRzOiB0eXBlb2Ygbm9ybWFsaXplZC50d2VldHMgPSBbXTtcbiAgY29uc3QgZnJlc2huZXNzQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCAnbmV3JyB8ICdleGlzdGluZyc+KCk7XG4gIGNvbnN0IGFjdGlvbkJ5SWQgPSBuZXcgTWFwPHN0cmluZywgVHdlZXRTaWdodGluZ1snYWN0aW9uJ10+KCk7XG4gIGZvciAoY29uc3QgdCBvZiBub3JtYWxpemVkLnR3ZWV0cykge1xuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbdC5hY2NvdW50X2hhbmRsZV0/Llt0LnR3ZWV0X2lkXTtcbiAgICBjb25zdCBvbGRCeVNuYXBzaG90ID0gIXByZXYgJiYgYXJjaGl2ZVNuYXBzaG90SGFzVHdlZXQodCwgYXJjaGl2ZVNuYXBzaG90KTtcbiAgICBjb25zdCBwcmV2aW91c2x5QXJjaGl2ZWQgPSBCb29sZWFuKHByZXYpIHx8IG9sZEJ5U25hcHNob3Q7XG4gICAgZnJlc2huZXNzQnlJZC5zZXQodC50d2VldF9pZCwgcHJldmlvdXNseUFyY2hpdmVkID8gJ2V4aXN0aW5nJyA6ICduZXcnKTtcbiAgICBpZiAob2xkQnlTbmFwc2hvdCkgb2xkRnJvbVNuYXBzaG90ICs9IDE7XG4gICAgY29uc3Qgc2lnID0gZW5nYWdlbWVudFNpZyhcbiAgICAgIHQubGlrZV9jb3VudCxcbiAgICAgIHQucmV0d2VldF9jb3VudCxcbiAgICAgIHQucmVwbHlfY291bnQsXG4gICAgICB0LnF1b3RlX2NvdW50LFxuICAgICAgdC5pc190cnVuY2F0ZWRcbiAgICApO1xuICAgIGNvbnN0IGZ1bGxUZXh0VXBncmFkZSA9IHByZXYgIT09IHVuZGVmaW5lZCAmJiBzaWdNYXJrc1RydW5jYXRlZChwcmV2LnNpZykgJiYgIXQuaXNfdHJ1bmNhdGVkO1xuICAgIGlmIChwcmV2aW91c2x5QXJjaGl2ZWQgJiYgIXVwZGF0ZUV4aXN0aW5nICYmICFmdWxsVGV4dFVwZ3JhZGUpIHtcbiAgICAgIGlmIChwcmV2KSBza2lwcGVkTm9VcGRhdGVMb2NhbCArPSAxO1xuICAgICAgZWxzZSBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCArPSAxO1xuICAgICAgYWN0aW9uQnlJZC5zZXQodC50d2VldF9pZCwgJ3NraXBwZWQnKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAocHJldiAmJiBwcmV2LnNpZyA9PT0gc2lnKSB7XG4gICAgICBkZWR1cGVkU2tpcHBlZCArPSAxO1xuICAgICAgYWN0aW9uQnlJZC5zZXQodC50d2VldF9pZCwgJ3VuY2hhbmdlZCcpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChmdWxsVGV4dFVwZ3JhZGUpIGZ1bGxUZXh0VXBncmFkZXMgKz0gMTtcbiAgICBhY3Rpb25CeUlkLnNldCh0LnR3ZWV0X2lkLCAnYnVmZmVyZWQnKTtcbiAgICBsaXZlVHdlZXRzLnB1c2godCk7XG4gIH1cbiAgaWYgKGRlZHVwZWRTa2lwcGVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2RlZHVwOiBza2lwcGVkIHVuY2hhbmdlZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHNraXBwZWQ6IGRlZHVwZWRTa2lwcGVkLFxuICAgICAgcmVtYWluaW5nOiBsaXZlVHdlZXRzLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuICBpZiAoc2tpcHBlZE5vVXBkYXRlTG9jYWwgKyBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCA+IDApIHtcbiAgICBjb25zdCBza2lwcGVkT2xkID0gc2tpcHBlZE5vVXBkYXRlTG9jYWwgKyBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdDtcbiAgICBhd2FpdCBpbmZvKCdkZWR1cDogc2tpcHBlZCBwcmV2aW91c2x5IGFyY2hpdmVkIHR3ZWV0cyAodXBkYXRlRXhpc3Rpbmc9ZmFsc2UpJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBza2lwcGVkOiBza2lwcGVkT2xkLFxuICAgICAgbG9jYWxfaW5kZXg6IHNraXBwZWROb1VwZGF0ZUxvY2FsLFxuICAgICAgYXJjaGl2ZV9zbmFwc2hvdDogc2tpcHBlZE5vVXBkYXRlU25hcHNob3QsXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICAgIGNvbnN0IGFzU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XG4gICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xuICAgICAgYXNTZXNzLnNraXBwZWRPbGRDb3VudCA9IChhc1Nlc3Muc2tpcHBlZE9sZENvdW50ID8/IDApICsgc2tpcHBlZE9sZDtcbiAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKGFzU2Vzcyk7XG4gICAgfVxuICB9XG4gIGlmIChvbGRGcm9tU25hcHNob3QgPiAwICYmIHVwZGF0ZUV4aXN0aW5nKSB7XG4gICAgYXdhaXQgaW5mbygnYXJjaGl2ZSBzbmFwc2hvdCByZWNvZ25pemVkIG9sZCB0d2VldHMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIG9sZDogb2xkRnJvbVNuYXBzaG90LFxuICAgICAgYWN0aW9uOiAnYnVmZmVyaW5nIGJlY2F1c2UgdXBkYXRlRXhpc3Rpbmc9dHJ1ZScsXG4gICAgICBzbmFwc2hvdF9nZW5lcmF0ZWRfYXQ6IGFyY2hpdmVTbmFwc2hvdD8uZ2VuZXJhdGVkX2F0ID8/IG51bGwsXG4gICAgfSk7XG4gIH1cbiAgaWYgKGZ1bGxUZXh0VXBncmFkZXMgPiAwKSB7XG4gICAgYXdhaXQgaW5mbygnZGVkdXA6IGJ1ZmZlcmluZyBmdWxsLXRleHQgdXBncmFkZXMnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIHVwZ3JhZGVzOiBmdWxsVGV4dFVwZ3JhZGVzLFxuICAgICAgdXBkYXRlRXhpc3RpbmcsXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxuICAgIH0pO1xuICB9XG4gIGF3YWl0IHByZXBlbmRSZWNlbnRUd2VldFNpZ2h0aW5ncyhcbiAgICBub3JtYWxpemVkLnR3ZWV0cy5tYXAoKHQpID0+XG4gICAgICBidWlsZFR3ZWV0U2lnaHRpbmcoXG4gICAgICAgIHQsXG4gICAgICAgIGVuZHBvaW50LFxuICAgICAgICBjYXB0dXJlZEF0LFxuICAgICAgICBmcmVzaG5lc3NCeUlkLmdldCh0LnR3ZWV0X2lkKSxcbiAgICAgICAgYWN0aW9uQnlJZC5nZXQodC50d2VldF9pZClcbiAgICAgIClcbiAgICApXG4gICk7XG4gIC8vIC0tLSBNaXNzaW5nLXBhcmVudCByZWNvdmVyeSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFgncyBVc2VyVHdlZXRzQW5kUmVwbGllcyBlbmRwb2ludCBzb21ldGltZXMgc2VydmVzIGEgcmVwbHkgd2l0aG91dCB0aGVcbiAgLy8gcGFyZW50IHR3ZWV0IGl0IHBvaW50cyBhdCBcdTIwMTQgb25seSBhbiBpbl9yZXBseV90b19zY3JlZW5fbmFtZSBhbmNob3IuIFdlXG4gIC8vIG5ldmVyIHNlZSB0aGF0IHBhcmVudCwgc28gaXQgbmV2ZXIgbGFuZHMgaW4gdGhlIGFyY2hpdmUuIFNhbWUgZm9yXG4gIC8vIHF1b3RlZF90d2VldF9pZCAvIHJldHdlZXRlZF90d2VldF9pZCB3aGVuIFggc3RyaXBzIHRoZSByZWZlcmVuY2VkXG4gIC8vIG5vZGUuIFdhbGsgdGhlIHR3ZWV0cyB3ZSBqdXN0IHNhdywgZmluZCBhbnkgcGFyZW50IElEIHdlIGRvbid0IGhhdmUsXG4gIC8vIGFuZCBlbnF1ZXVlIGl0IG9uIHRoZSBtZWRpYS1jcmF3bCBsb29wIHNvIGl0cyBkZXRhaWwgcGFnZSBnZXRzXG4gIC8vIHZpc2l0ZWQgYW5kIGluZ2VzdGVkIG5leHQgdGltZSB0aGUgdXNlciBzdGFydHMgdGhlIGNyYXdsLlxuICBhd2FpdCBlbnF1ZXVlTWlzc2luZ1BhcmVudHMobm9ybWFsaXplZC50d2VldHMsIGVuZHBvaW50KTtcbiAgYXdhaXQgZW5xdWV1ZVRocmVhZE9wZW5DYW5kaWRhdGVzKG5vcm1hbGl6ZWQudHdlZXRzLCBjb3JlLCBlbmRwb2ludCk7XG4gIGNvbnN0IGJ1ZmZlcmVkUmV0d2VldEVkZ2VzID0gYXdhaXQgYnVmZmVyUmV0d2VldEVkZ2VzKFxuICAgIHJldHdlZXRFZGdlcyxcbiAgICBjYXB0dXJlZEF0LFxuICAgIHBhZ2VVcmwgPz8gdXJsLFxuICAgIGVuZHBvaW50XG4gICk7XG4gIGlmIChsaXZlVHdlZXRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGlmIChidWZmZXJlZFJldHdlZXRFZGdlcyA+IDApIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gR3JvdXAgc3Vydml2aW5nIHR3ZWV0cyBieSBhdXRob3IgaGFuZGxlLlxuICBjb25zdCBieUhhbmRsZSA9IG5ldyBNYXA8c3RyaW5nLCBDYW5vbmljYWxUd2VldFtdPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgbGl2ZVR3ZWV0cykge1xuICAgIGNvbnN0IGFyciA9IGJ5SGFuZGxlLmdldCh0LmFjY291bnRfaGFuZGxlKSA/PyBbXTtcbiAgICBhcnIucHVzaCh0KTtcbiAgICBieUhhbmRsZS5zZXQodC5hY2NvdW50X2hhbmRsZSwgYXJyKTtcbiAgfVxuXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgdHdlZXRzXSBvZiBieUhhbmRsZSkge1xuICAgIGNvbnN0IGJ1ZiA9IGF3YWl0IGVuc3VyZVJ1bkJ1ZmZlcihoYW5kbGUsIGNhcHR1cmVkQXQsIHVybCwgZW5kcG9pbnQpO1xuICAgIGxldCBhZGRlZCA9IDA7XG4gICAgbGV0IGFkZGVkTmV3ID0gMDtcbiAgICBsZXQgYWRkZWRFeGlzdGluZyA9IDA7XG4gICAgbGV0IHVwZGF0ZWRCdWZmZXJlZCA9IDA7XG4gICAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xuICAgICAgY29uc3QgZXhpc3RpbmcgPSBidWYudHdlZXRzX2J5X2lkW3QudHdlZXRfaWRdO1xuICAgICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICAgIC8vIFByZXNlcnZlIGZpcnN0X2NhcHR1cmVkX2F0LCBhcHBlbmQgZW5nYWdlbWVudCBzbmFwc2hvdCwgcmVmcmVzaFxuICAgICAgICAvLyBsYXN0X3NlZW5fYXQgKyBjb3VudHMgKHRoZSBsYXRlc3Qgc2NyYXBlIHdpbnMgZm9yIGNvdW50cykuXG4gICAgICAgIGV4aXN0aW5nLmxhc3Rfc2Vlbl9hdCA9IGNhcHR1cmVkQXQ7XG4gICAgICAgIGV4aXN0aW5nLmxpa2VfY291bnQgPSB0Lmxpa2VfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnJldHdlZXRfY291bnQgPSB0LnJldHdlZXRfY291bnQ7XG4gICAgICAgIGV4aXN0aW5nLnJlcGx5X2NvdW50ID0gdC5yZXBseV9jb3VudDtcbiAgICAgICAgZXhpc3RpbmcucXVvdGVfY291bnQgPSB0LnF1b3RlX2NvdW50O1xuICAgICAgICBleGlzdGluZy52aWV3X2NvdW50ID0gdC52aWV3X2NvdW50O1xuICAgICAgICBleGlzdGluZy5ib29rbWFya19jb3VudCA9IHQuYm9va21hcmtfY291bnQ7XG4gICAgICAgIGNvbnN0IGxhc3QgPSBleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnlbZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5Lmxlbmd0aCAtIDFdO1xuICAgICAgICBjb25zdCBzbmFwID0gdC5lbmdhZ2VtZW50X2hpc3RvcnlbMF07XG4gICAgICAgIGlmIChzbmFwICYmICghbGFzdCB8fCBsYXN0LmNhcHR1cmVkX2F0ICE9PSBzbmFwLmNhcHR1cmVkX2F0KSkge1xuICAgICAgICAgIGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeS5wdXNoKHNuYXApO1xuICAgICAgICB9XG4gICAgICAgIHVwZGF0ZWRCdWZmZXJlZCArPSAxO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3Qgc3RhbXBlZDogQ2Fub25pY2FsVHdlZXQgPSB7IC4uLnQsIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkIH07XG4gICAgICAgIGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF0gPSBzdGFtcGVkO1xuICAgICAgICBhZGRlZCArPSAxO1xuICAgICAgICBpZiAoZnJlc2huZXNzQnlJZC5nZXQodC50d2VldF9pZCkgPT09ICdleGlzdGluZycpIGFkZGVkRXhpc3RpbmcgKz0gMTtcbiAgICAgICAgZWxzZSBhZGRlZE5ldyArPSAxO1xuICAgICAgfVxuICAgICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHQudHdlZXRfaWQpKSB7XG4gICAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh0LnR3ZWV0X2lkKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFidWYuZW5kcG9pbnRzX3NlZW4uaW5jbHVkZXMoZW5kcG9pbnQpKSBidWYuZW5kcG9pbnRzX3NlZW4ucHVzaChlbmRwb2ludCk7XG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcbiAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgcnVuQnVmZmVySXRlbUNvdW50KGJ1ZikpO1xuICAgIGlmIChhZGRlZCA+IDAgfHwgdXBkYXRlZEJ1ZmZlcmVkID4gMCkge1xuICAgICAgYXdhaXQgaW5mbygnYnVmZmVyZWQgdHdlZXRzJywge1xuICAgICAgICBoYW5kbGUsXG4gICAgICAgIGVuZHBvaW50LFxuICAgICAgICBhZGRlZCxcbiAgICAgICAgbmV3OiBhZGRlZE5ldyxcbiAgICAgICAgZXhpc3Rpbmc6IGFkZGVkRXhpc3RpbmcsXG4gICAgICAgIHVwZGF0ZWRfYnVmZmVyZWQ6IHVwZGF0ZWRCdWZmZXJlZCxcbiAgICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCxcbiAgICAgIH0pO1xuICAgICAgLy8gQnVtcCB0aGUgYXV0by1zY3JvbGwgcHJvZ3Jlc3Mgc28gdGhlIHVzZXIgc2VlcyBcIlggaW5nZXN0ZWRcIiB0aWNrIHVwXG4gICAgICAvLyBpbiByZWFsIHRpbWUuIFdlIGNvdW50IGFjdHVhbGx5LW5ldyB0d2VldHMsIG5vdCBkdXBsaWNhdGVzLlxuICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcbiAgICAgIGlmIChhc1Nlc3MgIT09IG51bGwpIHtcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkQ291bnQgKz0gYWRkZWQ7XG4gICAgICAgIGFzU2Vzcy5pbmdlc3RlZE5ld0NvdW50ID0gKGFzU2Vzcy5pbmdlc3RlZE5ld0NvdW50ID8/IDApICsgYWRkZWROZXc7XG4gICAgICAgIGFzU2Vzcy5pbmdlc3RlZEV4aXN0aW5nQ291bnQgPSAoYXNTZXNzLmluZ2VzdGVkRXhpc3RpbmdDb3VudCA/PyAwKSArIGFkZGVkRXhpc3Rpbmc7XG4gICAgICAgIGF3YWl0IHNldEF1dG9TY3JvbGxTZXNzaW9uKGFzU2Vzcyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGggPj0gRkxVU0hfVFdFRVRfVEhSRVNIT0xEKSB7XG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICd0aHJlc2hvbGQnKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVjb3JkVW5hdmFpbGFibGVUd2VldHMoXG4gIHVuYXZhaWxhYmxlVHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W10sXG4gIHRyYWNrZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4sXG4gIGNhcHR1cmVkQXQ6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBjb21taXR0ZWRJZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xTZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcbiAgY29uc3QgdGhyZWFkT3BlblNlc3MgPSBhd2FpdCBnZXRUaHJlYWRPcGVuU2Vzc2lvbigpO1xuICBsZXQgcmVjb3JkZWQgPSAwO1xuICBsZXQgc2tpcHBlZCA9IDA7XG4gIGxldCBtaXNzaW5nSGFuZGxlID0gMDtcblxuICBmb3IgKGNvbnN0IHUgb2YgdW5hdmFpbGFibGVUd2VldHMpIHtcbiAgICBjb25zdCBoYW5kbGUgPSB1LmFjY291bnRfaGFuZGxlO1xuICAgIGlmICghaGFuZGxlKSB7XG4gICAgICBtaXNzaW5nSGFuZGxlICs9IDE7XG4gICAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh1LnR3ZWV0X2lkKTtcbiAgICAgIGF3YWl0IGRlcXVldWVUaHJlYWRPcGVuKHUudHdlZXRfaWQpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICh0cmFja2VkLnNpemUgPiAwICYmICF0cmFja2VkLmhhcyhoYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgIHNraXBwZWQgKz0gMTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHUudHdlZXRfaWQpO1xuICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKGhhbmRsZSwgdS50d2VldF9pZCk7XG4gICAgYXdhaXQgZGVxdWV1ZVRocmVhZE9wZW4odS50d2VldF9pZCk7XG4gICAgaWYgKHJlZmV0Y2hTZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdS50d2VldF9pZCkge1xuICAgICAgcmVmZXRjaFNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgICAgcmVmZXRjaFNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihyZWZldGNoU2Vzcyk7XG4gICAgfVxuICAgIGlmIChtZWRpYUNyYXdsU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHUudHdlZXRfaWQpIHtcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICAgIG1lZGlhQ3Jhd2xTZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obWVkaWFDcmF3bFNlc3MpO1xuICAgIH1cbiAgICBpZiAodGhyZWFkT3BlblNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB1LnR3ZWV0X2lkKSB7XG4gICAgICB0aHJlYWRPcGVuU2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgICB0aHJlYWRPcGVuU2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICAgIGF3YWl0IG1hcmtUaHJlYWRPcGVuU2Vlbih1LnR3ZWV0X2lkKTtcbiAgICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHRocmVhZE9wZW5TZXNzKTtcbiAgICB9XG5cbiAgICBjb25zdCBzaWcgPSB1bmF2YWlsYWJsZVNpZyh1KTtcbiAgICBjb25zdCBwcmV2ID0gY29tbWl0dGVkSWR4W2hhbmRsZV0/Llt1LnR3ZWV0X2lkXTtcbiAgICBpZiAocHJldj8uc2lnID09PSBzaWcpIHtcbiAgICAgIHNraXBwZWQgKz0gMTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGNvbnN0IGJ1ZiA9IGF3YWl0IGVuc3VyZVJ1bkJ1ZmZlcihoYW5kbGUsIGNhcHR1cmVkQXQsIHNvdXJjZVVybCwgZW5kcG9pbnQpO1xuICAgIGNvbnN0IHVuYXZhaWxhYmxlQnlJZCA9IGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fTtcbiAgICB1bmF2YWlsYWJsZUJ5SWRbdS50d2VldF9pZF0gPSB1O1xuICAgIGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA9IHVuYXZhaWxhYmxlQnlJZDtcbiAgICBpZiAoIWJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQuaW5jbHVkZXModS50d2VldF9pZCkpIHtcbiAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh1LnR3ZWV0X2lkKTtcbiAgICB9XG4gICAgaWYgKCFidWYuZW5kcG9pbnRzX3NlZW4uaW5jbHVkZXMoZW5kcG9pbnQpKSBidWYuZW5kcG9pbnRzX3NlZW4ucHVzaChlbmRwb2ludCk7XG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcbiAgICBhd2FpdCBzZXRCdWZmZXJlZENvdW50KGhhbmRsZSwgcnVuQnVmZmVySXRlbUNvdW50KGJ1ZikpO1xuICAgIHJlY29yZGVkICs9IDE7XG4gIH1cblxuICBpZiAocmVjb3JkZWQgPiAwIHx8IG1pc3NpbmdIYW5kbGUgPiAwIHx8IHNraXBwZWQgPiAwKSB7XG4gICAgYXdhaXQgaW5mbygndW5hdmFpbGFibGUgdHdlZXRzIG9ic2VydmVkJywgeyBlbmRwb2ludCwgcmVjb3JkZWQsIHNraXBwZWQsIG1pc3NpbmdIYW5kbGUgfSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuZnVuY3Rpb24gdW5hdmFpbGFibGVTaWcodTogVW5hdmFpbGFibGVUd2VldCk6IHN0cmluZyB7XG4gIHJldHVybiBgdW5hdmFpbGFibGV8JHt1LnVuYXZhaWxhYmxlX3JlYXNvbiA/PyAnJ318JHt1LnVuYXZhaWxhYmxlX3RleHQgPz8gJyd9YDtcbn1cblxuZnVuY3Rpb24gc2lnTWFya3NUcnVuY2F0ZWQoc2lnOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3QgcGFydHMgPSBzaWcuc3BsaXQoJ3wnKTtcbiAgcmV0dXJuIHBhcnRzW3BhcnRzLmxlbmd0aCAtIDFdID09PSAndCc7XG59XG5cbmZ1bmN0aW9uIHJ1bkJ1ZmZlckl0ZW1Db3VudChidWY6IFJ1bkJ1ZmZlcik6IG51bWJlciB7XG4gIHJldHVybiAoXG4gICAgT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoICtcbiAgICBPYmplY3Qua2V5cyhidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge30pLmxlbmd0aCArXG4gICAgT2JqZWN0LmtleXMoYnVmLnJldHdlZXRfZWRnZXNfYnlfa2V5ID8/IHt9KS5sZW5ndGhcbiAgKTtcbn1cblxuZnVuY3Rpb24gcmV0d2VldEVkZ2VLZXkoZWRnZTogUmV0d2VldEVkZ2UpOiBzdHJpbmcge1xuICByZXR1cm4gW2VkZ2UucmV0d2VldGVyX2hhbmRsZS50b0xvd2VyQ2FzZSgpLCBlZGdlLnJldHdlZXRfdHdlZXRfaWQsIGVkZ2Uub3JpZ2luYWxfdHdlZXRfaWRdLmpvaW4oXG4gICAgJ3wnXG4gICk7XG59XG5cbmZ1bmN0aW9uIGluZmVyUmV0d2VldGVkSGFuZGxlKHRleHQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBtYXRjaCA9IHRleHQubWF0Y2goL15SVFxccytAKFtBLVphLXowLTlfXXsxLDE1fSlcXGIvaSk7XG4gIHJldHVybiBtYXRjaD8uWzFdID8/IG51bGw7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkUmV0d2VldEVkZ2VzKFxuICB0d2VldHM6IFJlYWRvbmx5QXJyYXk8Q2Fub25pY2FsVHdlZXQ+LFxuICBhY2NvdW50czogUmVhZG9ubHlBcnJheTx7IGhhbmRsZTogc3RyaW5nOyBjYXRlZ29yeTogc3RyaW5nIH0+LFxuICBjYXB0dXJlZEF0OiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHNvdXJjZVVybDogc3RyaW5nIHwgbnVsbFxuKTogUmV0d2VldEVkZ2VbXSB7XG4gIGNvbnN0IGNhdGVnb3J5QnlIYW5kbGUgPSBuZXcgTWFwKGFjY291bnRzLm1hcCgoYSkgPT4gW2EuaGFuZGxlLnRvTG93ZXJDYXNlKCksIGEuY2F0ZWdvcnldKSk7XG4gIGNvbnN0IGJ5SWQgPSBuZXcgTWFwKHR3ZWV0cy5tYXAoKHQpID0+IFt0LnR3ZWV0X2lkLCB0XSkpO1xuICBjb25zdCBvdXQgPSBuZXcgTWFwPHN0cmluZywgUmV0d2VldEVkZ2U+KCk7XG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICBpZiAodC50d2VldF90eXBlICE9PSAncmV0d2VldCcgfHwgIXQucmV0d2VldGVkX3R3ZWV0X2lkKSBjb250aW51ZTtcbiAgICBjb25zdCByZXR3ZWV0ZXJDYXRlZ29yeSA9IGNhdGVnb3J5QnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSk7XG4gICAgaWYgKCFyZXR3ZWV0ZXJDYXRlZ29yeSkgY29udGludWU7XG4gICAgY29uc3Qgb3JpZ2luYWwgPSBieUlkLmdldCh0LnJldHdlZXRlZF90d2VldF9pZCk7XG4gICAgY29uc3Qgb3JpZ2luYWxIYW5kbGUgPVxuICAgICAgb3JpZ2luYWw/LmFjY291bnRfaGFuZGxlID8/IGluZmVyUmV0d2VldGVkSGFuZGxlKHQudGV4dF9yZXNvbHZlZCB8fCB0LnRleHQpO1xuICAgIGNvbnN0IG9yaWdpbmFsQ2F0ZWdvcnkgPSBvcmlnaW5hbEhhbmRsZVxuICAgICAgPyAoY2F0ZWdvcnlCeUhhbmRsZS5nZXQob3JpZ2luYWxIYW5kbGUudG9Mb3dlckNhc2UoKSkgPz8gJ3B1YmxpYycpXG4gICAgICA6IG51bGw7XG4gICAgY29uc3QgZWRnZTogUmV0d2VldEVkZ2UgPSB7XG4gICAgICByZXR3ZWV0ZXJfaGFuZGxlOiB0LmFjY291bnRfaGFuZGxlLFxuICAgICAgcmV0d2VldGVyX2FjY291bnRfaWQ6IHQuYWNjb3VudF9pZCA/PyBudWxsLFxuICAgICAgcmV0d2VldGVyX2NhdGVnb3J5OiByZXR3ZWV0ZXJDYXRlZ29yeSxcbiAgICAgIHJldHdlZXRfdHdlZXRfaWQ6IHQudHdlZXRfaWQsXG4gICAgICByZXR3ZWV0X3VybDogdC50d2VldF91cmwsXG4gICAgICBvcmlnaW5hbF90d2VldF9pZDogdC5yZXR3ZWV0ZWRfdHdlZXRfaWQsXG4gICAgICBvcmlnaW5hbF9hdXRob3JfaGFuZGxlOiBvcmlnaW5hbEhhbmRsZSxcbiAgICAgIG9yaWdpbmFsX2F1dGhvcl9hY2NvdW50X2lkOiBvcmlnaW5hbD8uYWNjb3VudF9pZCA/PyBudWxsLFxuICAgICAgb3JpZ2luYWxfYXV0aG9yX2NhdGVnb3J5OiBvcmlnaW5hbENhdGVnb3J5LFxuICAgICAgY2FwdHVyZWRfYXQ6IGNhcHR1cmVkQXQsXG4gICAgICBjYXB0dXJlX3J1bl9pZDogJ3BlbmRpbmcnLFxuICAgICAgZW5kcG9pbnQsXG4gICAgICBzb3VyY2VfdXJsOiBzb3VyY2VVcmwsXG4gICAgfTtcbiAgICBvdXQuc2V0KHJldHdlZXRFZGdlS2V5KGVkZ2UpLCBlZGdlKTtcbiAgfVxuICByZXR1cm4gWy4uLm91dC52YWx1ZXMoKV07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGJ1ZmZlclJldHdlZXRFZGdlcyhcbiAgZWRnZXM6IFJlYWRvbmx5QXJyYXk8UmV0d2VldEVkZ2U+LFxuICBjYXB0dXJlZEF0OiBzdHJpbmcsXG4gIHNvdXJjZVVybDogc3RyaW5nLFxuICBlbmRwb2ludDogc3RyaW5nXG4pOiBQcm9taXNlPG51bWJlcj4ge1xuICBpZiAoZWRnZXMubGVuZ3RoID09PSAwKSByZXR1cm4gMDtcbiAgY29uc3QgYnlIYW5kbGUgPSBuZXcgTWFwPHN0cmluZywgUmV0d2VldEVkZ2VbXT4oKTtcbiAgZm9yIChjb25zdCBlZGdlIG9mIGVkZ2VzKSB7XG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KGVkZ2UucmV0d2VldGVyX2hhbmRsZSkgPz8gW107XG4gICAgYXJyLnB1c2goZWRnZSk7XG4gICAgYnlIYW5kbGUuc2V0KGVkZ2UucmV0d2VldGVyX2hhbmRsZSwgYXJyKTtcbiAgfVxuICBsZXQgYWRkZWQgPSAwO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGhhbmRsZUVkZ2VzXSBvZiBieUhhbmRsZSkge1xuICAgIGNvbnN0IGJ1ZiA9IGF3YWl0IGVuc3VyZVJ1bkJ1ZmZlcihoYW5kbGUsIGNhcHR1cmVkQXQsIHNvdXJjZVVybCwgZW5kcG9pbnQpO1xuICAgIGNvbnN0IGVkZ2VNYXAgPSBidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge307XG4gICAgbGV0IGFkZGVkRm9ySGFuZGxlID0gMDtcbiAgICBmb3IgKGNvbnN0IGVkZ2Ugb2YgaGFuZGxlRWRnZXMpIHtcbiAgICAgIGNvbnN0IHN0YW1wZWQ6IFJldHdlZXRFZGdlID0geyAuLi5lZGdlLCBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCB9O1xuICAgICAgY29uc3Qga2V5ID0gcmV0d2VldEVkZ2VLZXkoc3RhbXBlZCk7XG4gICAgICBpZiAoIWVkZ2VNYXBba2V5XSkgYWRkZWRGb3JIYW5kbGUgKz0gMTtcbiAgICAgIGVkZ2VNYXBba2V5XSA9IHN0YW1wZWQ7XG4gICAgICBpZiAoIWJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQuaW5jbHVkZXMoc3RhbXBlZC5yZXR3ZWV0X3R3ZWV0X2lkKSkge1xuICAgICAgICBidWYudHdlZXRfaWRzX29ic2VydmVkLnB1c2goc3RhbXBlZC5yZXR3ZWV0X3R3ZWV0X2lkKTtcbiAgICAgIH1cbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyhzdGFtcGVkLm9yaWdpbmFsX3R3ZWV0X2lkKSkge1xuICAgICAgICBidWYudHdlZXRfaWRzX29ic2VydmVkLnB1c2goc3RhbXBlZC5vcmlnaW5hbF90d2VldF9pZCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChhZGRlZEZvckhhbmRsZSA9PT0gMCkgY29udGludWU7XG4gICAgYnVmLnJldHdlZXRfZWRnZXNfYnlfa2V5ID0gZWRnZU1hcDtcbiAgICBpZiAoIWJ1Zi5lbmRwb2ludHNfc2Vlbi5pbmNsdWRlcyhlbmRwb2ludCkpIGJ1Zi5lbmRwb2ludHNfc2Vlbi5wdXNoKGVuZHBvaW50KTtcbiAgICBidWYubGFzdF9jYXB0dXJlX2F0ID0gY2FwdHVyZWRBdDtcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICAgIGF3YWl0IHNldEJ1ZmZlcmVkQ291bnQoaGFuZGxlLCBydW5CdWZmZXJJdGVtQ291bnQoYnVmKSk7XG4gICAgYWRkZWQgKz0gYWRkZWRGb3JIYW5kbGU7XG4gICAgYXdhaXQgaW5mbygnYnVmZmVyZWQgcmV0d2VldCBlZGdlcycsIHtcbiAgICAgIGhhbmRsZSxcbiAgICAgIGVuZHBvaW50LFxuICAgICAgYWRkZWQ6IGFkZGVkRm9ySGFuZGxlLFxuICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGVkZ2VNYXApLmxlbmd0aCxcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gYWRkZWQ7XG59XG5cbi8qKlxuICogRmluZCBldmVyeSBwYXJlbnQgdHdlZXQgcmVmZXJlbmNlZCBieSB0aGUgY2FwdHVyZXMgd2UganVzdCBpbmdlc3RlZFxuICogKGByZXBseV90b190d2VldF9pZGAsIGBxdW90ZWRfdHdlZXRfaWRgLCBgcmV0d2VldGVkX3R3ZWV0X2lkYCkgdGhhdCB3ZVxuICogZG9uJ3QgeWV0IGhhdmUgaW4gdGhlIGFyY2hpdmUsIGFuZCBlbnF1ZXVlIGl0IG9uIHRoZSBtZWRpYS1jcmF3bCBsb29wLlxuICpcbiAqIFdoeTogWCdzIFVzZXJUd2VldHNBbmRSZXBsaWVzIGVuZHBvaW50IHNvbWV0aW1lcyByZXR1cm5zIGEgdHJhY2tlZFxuICogYWNjb3VudCdzIHJlcGx5ICp3aXRob3V0KiB0aGUgcGFyZW50IGl0IHBvaW50cyBhdC4gVGhlIGByZXBseV90b18qYFxuICogZmllbGRzIG9uIHRoZSByZXBseSBzdGlsbCBnZXQgc2V0IGZyb20gYGluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHJgLCBidXRcbiAqIGBmaWx0ZXJSZWxhdGVkYCBoYXMgbm90aGluZyB0byBrZWVwIFx1MjAxNCB0aGVyZSBpcyBubyBwYXJlbnQgbm9kZSBpbiB0aGVcbiAqIGJhdGNoIHRvIGtlZXAuIFJlc3VsdDogdGhlIGFyY2hpdmUgc2hvd3MgREhTZ292J3MgcmVwbHkgYnV0IG5vdCB0aGVcbiAqIG9yaWdpbmFsIGl0J3MgcmVwbHlpbmcgdG8uIFN5bW1ldHJpYyBwcm9ibGVtIGZvciBvcnBoYW5lZCBxdW90ZSAvIFJUXG4gKiBwb2ludGVycy5cbiAqXG4gKiBSZXVzaW5nIHRoZSBtZWRpYS1jcmF3bCBxdWV1ZSArIGxvb3AgbWVhbnMgbm8gbmV3IFVJOyB0aGUgdXNlciBhbHJlYWR5XG4gKiBzdGFydHMgaXQgbWFudWFsbHkgd2hlbiB0aGV5IHdhbnQgdG8gZmV0Y2ggcGFydGlhbC1jYXB0dXJlZCB0d2VldHMuXG4gKiBTYW1lIGRlZHVwIHJ1bGVzIGFwcGx5IChjb21taXR0ZWQgXHUyMTkyIHNraXA7IGFscmVhZHkgcXVldWVkIFx1MjE5MiBuby1vcCkuXG4gKlxuICogV2Ugb25seSB3YWxrIHRoZSB0d2VldHMgdGhhdCBzdXJ2aXZlZCBgZmlsdGVyUmVsYXRlZGAgc28gd2UgZG9uJ3QgY3Jhd2xcbiAqIHBhcmVudHMgb2YgcmFuZG9tIHJlcGxpZXMgdGhhdCB3b3VsZG4ndCBoYXZlIGJlZW4ga2VwdCBhbnl3YXkuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGVucXVldWVNaXNzaW5nUGFyZW50cyhcbiAgdHdlZXRzOiBSZWFkb25seUFycmF5PENhbm9uaWNhbFR3ZWV0PixcbiAgZW5kcG9pbnQ6IHN0cmluZ1xuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmICh0d2VldHMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIC8vIEJ1aWxkIGEgc2FtZS1iYXRjaCBJRCBzZXQgc28gd2UgZG9uJ3QgZW5xdWV1ZSBhIHBhcmVudCB0aGF0IGFscmVhZHlcbiAgLy8gYXJyaXZlZCBpbiB0aGlzIHZlcnkgcmVzcG9uc2UuXG4gIGNvbnN0IHNhbWVCYXRjaElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSBzYW1lQmF0Y2hJZHMuYWRkKHQudHdlZXRfaWQpO1xuXG4gIGxldCBlbnF1ZXVlZCA9IDA7XG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICBjb25zdCBwYXJlbnRzOiBBcnJheTx7IGlkOiBzdHJpbmc7IGhpbnQ6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcbiAgICBpZiAodC5yZXBseV90b190d2VldF9pZCkge1xuICAgICAgcGFyZW50cy5wdXNoKHsgaWQ6IHQucmVwbHlfdG9fdHdlZXRfaWQsIGhpbnQ6IHQucmVwbHlfdG9fYWNjb3VudCB9KTtcbiAgICB9XG4gICAgaWYgKHQucXVvdGVkX3R3ZWV0X2lkKSBwYXJlbnRzLnB1c2goeyBpZDogdC5xdW90ZWRfdHdlZXRfaWQsIGhpbnQ6IG51bGwgfSk7XG4gICAgaWYgKHQucmV0d2VldGVkX3R3ZWV0X2lkKSBwYXJlbnRzLnB1c2goeyBpZDogdC5yZXR3ZWV0ZWRfdHdlZXRfaWQsIGhpbnQ6IG51bGwgfSk7XG4gICAgZm9yIChjb25zdCBwIG9mIHBhcmVudHMpIHtcbiAgICAgIGlmIChzYW1lQmF0Y2hJZHMuaGFzKHAuaWQpKSBjb250aW51ZTtcbiAgICAgIGlmIChhd2FpdCBpc0NvbW1pdHRlZChwLmlkKSkgY29udGludWU7XG4gICAgICBhd2FpdCBlbnF1ZXVlTWVkaWFDcmF3bChwLmhpbnQsIHAuaWQpO1xuICAgICAgZW5xdWV1ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgaWYgKGVucXVldWVkID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ3F1ZXVlZCBtaXNzaW5nIHBhcmVudCB0d2VldHMgZm9yIGRldGFpbC1wYWdlIGNyYXdsJywge1xuICAgICAgZW5kcG9pbnQsXG4gICAgICBlbnF1ZXVlZCxcbiAgICAgIHF1ZXVlX3RvdGFsOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxuICAgIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGVucXVldWVUaHJlYWRPcGVuQ2FuZGlkYXRlcyhcbiAgdHdlZXRzOiBSZWFkb25seUFycmF5PENhbm9uaWNhbFR3ZWV0PixcbiAgY29yZUhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz4sXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8dm9pZD4ge1xuICBpZiAodHdlZXRzLmxlbmd0aCA9PT0gMCB8fCBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm47XG4gIGlmIChlbmRwb2ludC5pbmNsdWRlcygnVHdlZXREZXRhaWwnKSB8fCBlbmRwb2ludC5pbmNsdWRlcygnVHdlZXRSZXN1bHRCeVJlc3RJZCcpKSByZXR1cm47XG5cbiAgY29uc3QgY2FuZGlkYXRlcyA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcbiAgICBjb25zdCBoYW5kbGUgPSB0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKCFjb3JlSGFuZGxlcy5oYXMoaGFuZGxlKSkgY29udGludWU7XG5cbiAgICBjb25zdCByb290SWQgPSB0LmNvbnZlcnNhdGlvbl9pZCA/PyB0LnR3ZWV0X2lkO1xuICAgIGNvbnN0IGlzUm9vdCA9IHJvb3RJZCA9PT0gdC50d2VldF9pZCB8fCB0LnJlcGx5X3RvX3R3ZWV0X2lkID09PSBudWxsO1xuICAgIGNvbnN0IGlzQ29yZVJlcGx5ID0gdC5yZXBseV90b190d2VldF9pZCAhPT0gbnVsbDtcbiAgICBpZiAoaXNSb290ICYmIHQucmVwbHlfY291bnQgPiAwKSB7XG4gICAgICBjYW5kaWRhdGVzLnNldChyb290SWQsIHQuYWNjb3VudF9oYW5kbGUpO1xuICAgIH0gZWxzZSBpZiAoaXNDb3JlUmVwbHkgJiYgcm9vdElkKSB7XG4gICAgICBjYW5kaWRhdGVzLnNldChyb290SWQsIHQuYWNjb3VudF9oYW5kbGUpO1xuICAgIH1cbiAgfVxuXG4gIGxldCBlbnF1ZXVlZCA9IDA7XG4gIGZvciAoY29uc3QgW3R3ZWV0SWQsIGhhbmRsZV0gb2YgY2FuZGlkYXRlcykge1xuICAgIGNvbnN0IGJlZm9yZSA9IGF3YWl0IHRocmVhZE9wZW5RdWV1ZVRvdGFsKCk7XG4gICAgYXdhaXQgZW5xdWV1ZVRocmVhZE9wZW4oaGFuZGxlLCB0d2VldElkKTtcbiAgICBjb25zdCBhZnRlciA9IGF3YWl0IHRocmVhZE9wZW5RdWV1ZVRvdGFsKCk7XG4gICAgaWYgKGFmdGVyID4gYmVmb3JlKSBlbnF1ZXVlZCArPSAxO1xuICB9XG4gIGlmIChlbnF1ZXVlZCA+IDApIHtcbiAgICBhd2FpdCBpbmZvKCdxdWV1ZWQgY29yZSB0aHJlYWQgcm9vdHMgZm9yIG9wZW5pbmcnLCB7XG4gICAgICBlbmRwb2ludCxcbiAgICAgIGVucXVldWVkLFxuICAgICAgcXVldWVfdG90YWw6IGF3YWl0IHRocmVhZE9wZW5RdWV1ZVRvdGFsKCksXG4gICAgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlUnVuQnVmZmVyKFxuICBoYW5kbGU6IHN0cmluZyxcbiAgdHM6IHN0cmluZyxcbiAgc291cmNlVXJsOiBzdHJpbmcsXG4gIGVuZHBvaW50OiBzdHJpbmdcbik6IFByb21pc2U8UnVuQnVmZmVyPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpO1xuICBpZiAoY3VyKSByZXR1cm4gY3VyO1xuICBjb25zdCBidWY6IFJ1bkJ1ZmZlciA9IHtcbiAgICBydW5faWQ6IG5ld1J1bklkKCksXG4gICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICBzdGFydGVkX2F0OiB0cyxcbiAgICBsYXN0X2NhcHR1cmVfYXQ6IHRzLFxuICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgdW5hdmFpbGFibGVfYnlfaWQ6IHt9LFxuICAgIHR3ZWV0X2lkc19vYnNlcnZlZDogW10sXG4gICAgZW5kcG9pbnRzX3NlZW46IFtlbmRwb2ludF0sXG4gICAgc291cmNlX3VybDogc291cmNlVXJsLFxuICB9O1xuICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xuICBhd2FpdCBpbmZvKCdydW4gc3RhcnRlZCcsIHsgaGFuZGxlLCBydW46IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCkgfSk7XG4gIHJldHVybiBidWY7XG59XG5cbi8vIC0tLSBGbHVzaCBsb2dpYyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmxldCBmbHVzaENoYWluOiBQcm9taXNlPHZvaWQ+ID0gUHJvbWlzZS5yZXNvbHZlKCk7XG5cbmludGVyZmFjZSBGbHVzaEl0ZW0ge1xuICBoYW5kbGU6IHN0cmluZztcbiAgYnVmOiBSdW5CdWZmZXI7XG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXTtcbiAgcmV0d2VldEVkZ2VzOiBSZXR3ZWV0RWRnZVtdO1xuICByYXdQYXRoOiBzdHJpbmc7XG4gIHNlZW5QYXRoOiBzdHJpbmc7XG4gIGNhcHR1cmU6IENhcHR1cmVQYXlsb2FkO1xuICBzZWVuOiBTZWVuUGF5bG9hZDtcbiAgZGF5OiBzdHJpbmc7XG4gIHJ1blNob3J0OiBzdHJpbmc7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSWRsZUJ1ZmZlcnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgY29uc3QgaGFuZGxlczogc3RyaW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKGxhc3QpICYmIG5vdyAtIGxhc3QgPj0gRkxVU0hfSURMRV9NUykge1xuICAgICAgaGFuZGxlcy5wdXNoKGhhbmRsZSk7XG4gICAgfVxuICB9XG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhoYW5kbGVzLCAnaWRsZScpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBmbHVzaE9ycGhhbmVkQnVmZmVyc0lmU3RhbGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIE9uIHdvcmtlciB3YWtlLCBhbnkgYnVmZmVyIG9sZGVyIHRoYW4gdGhlIGlkbGUgdGhyZXNob2xkIGdldHMgYSBjaGFuY2UgdG9cbiAgLy8gY29tbWl0IGltbWVkaWF0ZWx5IFx1MjAxNCB1c2VmdWwgd2hlbiB0aGUgd29ya2VyIHdhcyBldmljdGVkIGJlZm9yZSBpZGxlLWZsdXNoLlxuICAvLyBJZiB0aGUgUEFUL293bmVyL3JlcG8gYXJlbid0IHNldCB3ZSdkIGp1c3QgZW1pdCBcImZsdXNoIGRlZmVycmVkXCIgZm9yIGV2ZXJ5XG4gIC8vIHNpbmdsZSBoYW5kbGUgaW4gc3RvcmFnZSAodGhlIGRpYWdub3N0aWMgc2hvd2VkIHRoaXMgZmlyaW5nIDMwMCsgdGltZXMgaW5cbiAgLy8gYSByb3cgd2hlbiB0aGUgZXh0ZW5zaW9uIHdva2UgYmVmb3JlIHNldHRpbmdzIGxvYWQpLCBzbyBzaG9ydC1jaXJjdWl0XG4gIC8vIGhlcmUgaW5zdGVhZC5cbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBjb25zdCBoYW5kbGVzOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGJ1Zl0gb2YgT2JqZWN0LmVudHJpZXMoYWxsKSkge1xuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XG4gICAgICBoYW5kbGVzLnB1c2goaGFuZGxlKTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgZmx1c2hIYW5kbGVzKGhhbmRsZXMsICd3YWtlJyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoQWxsKHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKE9iamVjdC5rZXlzKGFsbCksIHJlYXNvbik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlKGhhbmRsZTogc3RyaW5nLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBmbHVzaEhhbmRsZXMoW2hhbmRsZV0sIHJlYXNvbik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZsdXNoSGFuZGxlcyhoYW5kbGVzOiBzdHJpbmdbXSwgcmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdW5pcXVlID0gWy4uLm5ldyBTZXQoaGFuZGxlcyldLmZpbHRlcigoaCkgPT4gaC5sZW5ndGggPiAwKTtcbiAgaWYgKHVuaXF1ZS5sZW5ndGggPT09IDApIHJldHVybjtcbiAgY29uc3QgcnVuID0gZmx1c2hDaGFpbi50aGVuKCgpID0+IGZsdXNoSGFuZGxlc0xvY2tlZCh1bmlxdWUsIHJlYXNvbikpO1xuICBmbHVzaENoYWluID0gcnVuLmNhdGNoKCgpID0+IHt9KTtcbiAgcmV0dXJuIHJ1bjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGVzTG9ja2VkKGhhbmRsZXM6IHN0cmluZ1tdLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGNvbnN0IGl0ZW1zOiBGbHVzaEl0ZW1bXSA9IFtdO1xuICBmb3IgKGNvbnN0IGhhbmRsZSBvZiBoYW5kbGVzKSB7XG4gICAgY29uc3QgYnVmID0gYWxsW2hhbmRsZV07XG4gICAgaWYgKCFidWYpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHR3ZWV0cyA9IE9iamVjdC52YWx1ZXMoYnVmLnR3ZWV0c19ieV9pZCk7XG4gICAgY29uc3QgdW5hdmFpbGFibGVUd2VldHMgPSBPYmplY3QudmFsdWVzKGJ1Zi51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fSk7XG4gICAgY29uc3QgcmV0d2VldEVkZ2VzID0gT2JqZWN0LnZhbHVlcyhidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge30pO1xuICAgIGlmICh0d2VldHMubGVuZ3RoID09PSAwICYmIHVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCA9PT0gMCAmJiByZXR3ZWV0RWRnZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihoYW5kbGUpO1xuICAgICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIDApO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGl0ZW1zLnB1c2goYnVpbGRGbHVzaEl0ZW0oaGFuZGxlLCBidWYsIHR3ZWV0cywgdW5hdmFpbGFibGVUd2VldHMsIHJldHdlZXRFZGdlcykpO1xuICB9XG4gIGlmIChpdGVtcy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHdhcm4oJ3VwbG9hZCBidWZmZXIgZGVmZXJyZWQ6IHNldHRpbmdzIGluY29tcGxldGUnLCB7XG4gICAgICBjb3VudDogaXRlbXMubGVuZ3RoLFxuICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxuICAgIH0pO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcbiAgY29uc3QgZmlsZXMgPSBpdGVtcy5mbGF0TWFwKChpdGVtKSA9PiBbXG4gICAge1xuICAgICAgcGF0aDogaXRlbS5yYXdQYXRoLFxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkoaXRlbS5jYXB0dXJlLCBudWxsLCAyKSArICdcXG4nKSxcbiAgICB9LFxuICAgIHtcbiAgICAgIHBhdGg6IGl0ZW0uc2VlblBhdGgsXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShpdGVtLnNlZW4sIG51bGwsIDIpICsgJ1xcbicpLFxuICAgIH0sXG4gIF0pO1xuICBjb25zdCBjb21taXRNc2cgPSBidWlsZEJhdGNoQ29tbWl0TWVzc2FnZShpdGVtcyk7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQuY29tbWl0RmlsZXMoe1xuICAgICAgZmlsZXMsXG4gICAgICBtZXNzYWdlOiBjb21taXRNc2csXG4gICAgfSk7XG4gICAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcbiAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgaXRlbXMpIHtcbiAgICAgIGNvbnN0IHJlbWFpbmluZ0NvdW50ID0gYXdhaXQgY2xlYXJDb21taXR0ZWRUd2VldHNGcm9tQnVmZmVyKGl0ZW0pO1xuICAgICAgLy8gQ291bnRlciBidW1wOiBhY3R1YWxseSBJTkNSRU1FTlQgdG9kYXlDb3VudCBhbmQgdG90YWxDb21taXR0ZWQgYnlcbiAgICAgIC8vIHRoZSBudW1iZXIgb2YgdHdlZXRzIHdlIGp1c3QgcGVyc2lzdGVkICh0aGUgcHJldmlvdXMgY29kZSByZWFkIHRoZVxuICAgICAgLy8gZXhpc3RpbmcgdmFsdWVzIGFuZCB3cm90ZSB0aGVtIGJhY2ssIGxlYXZpbmcgdGhlIGNvdW50ZXIgcGVnZ2VkIGF0XG4gICAgICAvLyB6ZXJvKS5cbiAgICAgIGNvbnN0IHByZXYgPSAoYXdhaXQgZ2V0Q291bnRlcnMoKSlbaXRlbS5oYW5kbGVdO1xuICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuICAgICAgY29uc3QgY2FycmllZFRvZGF5ID0gcHJldiAmJiBwcmV2LnRvZGF5RGF0ZSA9PT0gdG9kYXkgPyBwcmV2LnRvZGF5Q291bnQgOiAwO1xuICAgICAgYXdhaXQgYnVtcENvdW50ZXIoaXRlbS5oYW5kbGUsIHtcbiAgICAgICAgdG9kYXlDb3VudDogY2FycmllZFRvZGF5ICsgaXRlbS50d2VldHMubGVuZ3RoICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIHRvZGF5RGF0ZTogdG9kYXksXG4gICAgICAgIGxhc3RDYXB0dXJlQXQ6IGl0ZW0uYnVmLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgICAgdG90YWxDb21taXR0ZWQ6XG4gICAgICAgICAgKHByZXY/LnRvdGFsQ29tbWl0dGVkID8/IDApICsgaXRlbS50d2VldHMubGVuZ3RoICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIGJ1ZmZlcmVkQ291bnQ6IHJlbWFpbmluZ0NvdW50LFxuICAgICAgfSk7XG4gICAgICAvLyBSZWNvcmQgY29tbWl0cyBpbiB0aGUgZGVkdXAgaW5kZXggc28gd2UgZG9uJ3QgcmUtY29tbWl0IHRoZW0gbmV4dFxuICAgICAgLy8gYnJvd3NlIHdpdGggdW5jaGFuZ2VkIGVuZ2FnZW1lbnQuXG4gICAgICBjb25zdCBpbm5lciA9IGlkeFtpdGVtLmhhbmRsZV0gPz8ge307XG4gICAgICBjb25zdCBub3dJc28gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgICBmb3IgKGNvbnN0IHQgb2YgaXRlbS50d2VldHMpIHtcbiAgICAgICAgaW5uZXJbdC50d2VldF9pZF0gPSB7XG4gICAgICAgICAgdHM6IG5vd0lzbyxcbiAgICAgICAgICBzaWc6IGVuZ2FnZW1lbnRTaWcoXG4gICAgICAgICAgICB0Lmxpa2VfY291bnQsXG4gICAgICAgICAgICB0LnJldHdlZXRfY291bnQsXG4gICAgICAgICAgICB0LnJlcGx5X2NvdW50LFxuICAgICAgICAgICAgdC5xdW90ZV9jb3VudCxcbiAgICAgICAgICAgIHQuaXNfdHJ1bmNhdGVkXG4gICAgICAgICAgKSxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3QgdSBvZiBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzKSB7XG4gICAgICAgIGlubmVyW3UudHdlZXRfaWRdID0ge1xuICAgICAgICAgIHRzOiBub3dJc28sXG4gICAgICAgICAgc2lnOiB1bmF2YWlsYWJsZVNpZyh1KSxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGlkeFtpdGVtLmhhbmRsZV0gPSBpbm5lcjtcbiAgICAgIGF3YWl0IGluZm8oJ3VwbG9hZCBidWZmZXIgY29tbWl0dGVkJywge1xuICAgICAgICBoYW5kbGU6IGl0ZW0uaGFuZGxlLFxuICAgICAgICByZWFzb24sXG4gICAgICAgIHR3ZWV0czogaXRlbS50d2VldHMubGVuZ3RoLFxuICAgICAgICB1bmF2YWlsYWJsZTogaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXG4gICAgICAgIHJldHdlZXRfZWRnZXM6IGl0ZW0ucmV0d2VldEVkZ2VzLmxlbmd0aCxcbiAgICAgICAgcnVuOiBpdGVtLnJ1blNob3J0LFxuICAgICAgICBwYXRoOiBpdGVtLnJhd1BhdGgsXG4gICAgICAgIGJhdGNoX2NvbW1pdDogcmVzdWx0LmNvbW1pdFNoYSxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xuICAgIGF3YWl0IGluZm8oJ3VwbG9hZCBidWZmZXIgYmF0Y2ggY29tbWl0dGVkJywge1xuICAgICAgcmVhc29uLFxuICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcbiAgICAgIHR3ZWV0czogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApLFxuICAgICAgdW5hdmFpbGFibGU6IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsIDApLFxuICAgICAgcmV0d2VldF9lZGdlczogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnJldHdlZXRFZGdlcy5sZW5ndGgsIDApLFxuICAgICAgY29tbWl0OiByZXN1bHQuY29tbWl0U2hhLFxuICAgIH0pO1xuICAgIHtcbiAgICAgIGNvbnN0IHByZXYgPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgICBhd2FpdCBzZXRDb25uZWN0aW9uKHtcbiAgICAgICAgc3RhdHVzOiAnb2snLFxuICAgICAgICBsb2dpbjogcHJldi5sb2dpbixcbiAgICAgICAgY2hlY2tlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGVycm9yOiBudWxsLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBwcmV2LmRlZmF1bHRCcmFuY2gsXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IHByZXYuY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSB7XG4gICAgICBjb25zdCBjb25uID0gYXdhaXQgZ2V0Q29ubmVjdGlvbigpO1xuICAgICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAnYXV0aCdcbiAgICAgICAgICA/ICdhdXRoLWVycm9yJ1xuICAgICAgICAgIDogZXJyLmNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICAgID8gJ3JhdGUtbGltaXRlZCdcbiAgICAgICAgICAgIDogZXJyLmNhdGVnb3J5ID09PSAnbmV0d29yaydcbiAgICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgICAgOiBjb25uLnN0YXR1cztcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgICBzdGF0dXMsXG4gICAgICAgIGxvZ2luOiBjb25uLmxvZ2luLFxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgZXJyb3I6IGVyci5tZXNzYWdlLFxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBjb25uLmRlZmF1bHRCcmFuY2gsXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGNvbm4uY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDpcbiAgICAgICAgICBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IGVyci5yYXRlTGltaXRSZXNldEF0IDogY29ubi5yYXRlTGltaXRSZXNldEF0LFxuICAgICAgfSk7XG4gICAgICBhd2FpdCBsb2dFcnIoJ3VwbG9hZCBidWZmZXIgZmFpbGVkJywge1xuICAgICAgICByZWFzb24sXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcbiAgICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgICBjYXRlZ29yeTogZXJyLmNhdGVnb3J5LFxuICAgICAgICBzdGF0dXM6IGVyci5zdGF0dXMsXG4gICAgICAgIG1lc3NhZ2U6IGVyci5tZXNzYWdlLFxuICAgICAgICByYXRlTGltaXRSZXNldEF0OiBlcnIucmF0ZUxpbWl0UmVzZXRBdCxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBsb2dFcnIoJ3VwbG9hZCBidWZmZXIgZmFpbGVkJywge1xuICAgICAgICByZWFzb24sXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcbiAgICAgICAgcnVuczogaXRlbXMubGVuZ3RoLFxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgICB9KTtcbiAgICB9XG4gICAgLy8gTGVhdmUgYnVmZmVyIGludGFjdCBmb3IgcmV0cnkuXG4gIH0gZmluYWxseSB7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBidWlsZEZsdXNoSXRlbShcbiAgaGFuZGxlOiBzdHJpbmcsXG4gIGJ1ZjogUnVuQnVmZmVyLFxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10sXG4gIHVuYXZhaWxhYmxlVHdlZXRzOiBVbmF2YWlsYWJsZVR3ZWV0W10sXG4gIHJldHdlZXRFZGdlczogUmV0d2VldEVkZ2VbXVxuKTogRmx1c2hJdGVtIHtcbiAgY29uc3QgdHMgPSBpc29Db21wYWN0KGJ1Zi5zdGFydGVkX2F0KTtcbiAgY29uc3QgZGF5ID0gYnVmLnN0YXJ0ZWRfYXQuc2xpY2UoMCwgMTApO1xuICBjb25zdCBydW5TaG9ydCA9IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCk7XG4gIGNvbnN0IHJhd1BhdGggPSBgcmF3LyR7aGFuZGxlfS8ke3RzfS0ke3J1blNob3J0fS5qc29uYDtcbiAgY29uc3Qgc2VlblBhdGggPSBgc2Vlbi8ke2hhbmRsZX0vJHt0c30tJHtydW5TaG9ydH0uanNvbmA7XG4gIHJldHVybiB7XG4gICAgaGFuZGxlLFxuICAgIGJ1ZixcbiAgICB0d2VldHMsXG4gICAgdW5hdmFpbGFibGVUd2VldHMsXG4gICAgcmV0d2VldEVkZ2VzLFxuICAgIHJhd1BhdGgsXG4gICAgc2VlblBhdGgsXG4gICAgZGF5LFxuICAgIHJ1blNob3J0LFxuICAgIGNhcHR1cmU6IHtcbiAgICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxuICAgICAgY2FwdHVyZWRfYXQ6IGJ1Zi5sYXN0X2NhcHR1cmVfYXQsXG4gICAgICBlbmRwb2ludDogYnVmLmVuZHBvaW50c19zZWVuLmpvaW4oJywnKSxcbiAgICAgIHVzZXJfYWdlbnQ6IG5hdmlnYXRvci51c2VyQWdlbnQsXG4gICAgICBzb3VyY2VfdXJsOiBidWYuc291cmNlX3VybCxcbiAgICAgIHR3ZWV0cyxcbiAgICAgIHVuYXZhaWxhYmxlX3R3ZWV0czogdW5hdmFpbGFibGVUd2VldHMsXG4gICAgICByZXR3ZWV0X2VkZ2VzOiByZXR3ZWV0RWRnZXMsXG4gICAgfSxcbiAgICBzZWVuOiB7XG4gICAgICBzY2hlbWFfdmVyc2lvbjogMSxcbiAgICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxuICAgICAgYWNjb3VudF9oYW5kbGU6IGhhbmRsZSxcbiAgICAgIGNhcHR1cmVkX2F0OiBidWYubGFzdF9jYXB0dXJlX2F0LFxuICAgICAgdHdlZXRfaWRzX29ic2VydmVkOiBidWYudHdlZXRfaWRzX29ic2VydmVkLFxuICAgIH0sXG4gIH07XG59XG5cbmZ1bmN0aW9uIGJ1aWxkQmF0Y2hDb21taXRNZXNzYWdlKGl0ZW1zOiBGbHVzaEl0ZW1bXSk6IHN0cmluZyB7XG4gIGlmIChpdGVtcy5sZW5ndGggPT09IDEpIHtcbiAgICBjb25zdCBpdGVtID0gaXRlbXNbMF0hO1xuICAgIGNvbnN0IHVuYXZhaWxhYmxlQ291bnQgPSBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aDtcbiAgICBjb25zdCBlZGdlQ291bnQgPSBpdGVtLnJldHdlZXRFZGdlcy5sZW5ndGg7XG4gICAgY29uc3Qgc3VmZml4ID1cbiAgICAgICh1bmF2YWlsYWJsZUNvdW50ID4gMCA/IGAsICR7dW5hdmFpbGFibGVDb3VudH0gdW5hdmFpbGFibGVgIDogJycpICtcbiAgICAgIChlZGdlQ291bnQgPiAwID8gYCwgJHtlZGdlQ291bnR9IHJldHdlZXQgZWRnZSR7ZWRnZUNvdW50ID09PSAxID8gJycgOiAncyd9YCA6ICcnKTtcbiAgICByZXR1cm4gYGNhcHR1cmU6ICR7aXRlbS5oYW5kbGV9ICR7aXRlbS5kYXl9ICR7aXRlbS50d2VldHMubGVuZ3RofSB0d2VldCR7aXRlbS50d2VldHMubGVuZ3RoID09PSAxID8gJycgOiAncyd9JHtzdWZmaXh9IChydW4gJHtpdGVtLnJ1blNob3J0fSlgO1xuICB9XG4gIGNvbnN0IGRheXMgPSBbLi4ubmV3IFNldChpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uZGF5KSldLnNvcnQoKTtcbiAgY29uc3QgZGF5TGFiZWwgPSBkYXlzLmxlbmd0aCA9PT0gMSA/IGRheXNbMF0hIDogYCR7ZGF5c1swXX0uLiR7ZGF5c1tkYXlzLmxlbmd0aCAtIDFdfWA7XG4gIGNvbnN0IHR3ZWV0Q291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udHdlZXRzLmxlbmd0aCwgMCk7XG4gIGNvbnN0IHVuYXZhaWxhYmxlQ291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udW5hdmFpbGFibGVUd2VldHMubGVuZ3RoLCAwKTtcbiAgY29uc3QgZWRnZUNvdW50ID0gaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnJldHdlZXRFZGdlcy5sZW5ndGgsIDApO1xuICBjb25zdCBzdWZmaXggPVxuICAgICh1bmF2YWlsYWJsZUNvdW50ID4gMCA/IGAsICR7dW5hdmFpbGFibGVDb3VudH0gdW5hdmFpbGFibGVgIDogJycpICtcbiAgICAoZWRnZUNvdW50ID4gMCA/IGAsICR7ZWRnZUNvdW50fSByZXR3ZWV0IGVkZ2Uke2VkZ2VDb3VudCA9PT0gMSA/ICcnIDogJ3MnfWAgOiAnJyk7XG4gIHJldHVybiBgY2FwdHVyZSBiYXRjaDogJHtpdGVtcy5sZW5ndGh9IHJ1bnMsICR7dHdlZXRDb3VudH0gdHdlZXQke3R3ZWV0Q291bnQgPT09IDEgPyAnJyA6ICdzJ30ke3N1ZmZpeH0gKCR7ZGF5TGFiZWx9KWA7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNsZWFyQ29tbWl0dGVkVHdlZXRzRnJvbUJ1ZmZlcihpdGVtOiBGbHVzaEl0ZW0pOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBjdXJyZW50ID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcbiAgaWYgKCFjdXJyZW50KSByZXR1cm4gMDtcbiAgaWYgKGN1cnJlbnQucnVuX2lkICE9PSBpdGVtLmJ1Zi5ydW5faWQpIHJldHVybiBydW5CdWZmZXJJdGVtQ291bnQoY3VycmVudCk7XG5cbiAgY29uc3QgY29tbWl0dGVkID0gbmV3IE1hcChcbiAgICBpdGVtLnR3ZWV0cy5tYXAoKHQpID0+IFtcbiAgICAgIHQudHdlZXRfaWQsXG4gICAgICBlbmdhZ2VtZW50U2lnKHQubGlrZV9jb3VudCwgdC5yZXR3ZWV0X2NvdW50LCB0LnJlcGx5X2NvdW50LCB0LnF1b3RlX2NvdW50LCB0LmlzX3RydW5jYXRlZCksXG4gICAgXSlcbiAgKTtcbiAgZm9yIChjb25zdCB1IG9mIGl0ZW0udW5hdmFpbGFibGVUd2VldHMpIHtcbiAgICBjb21taXR0ZWQuc2V0KHUudHdlZXRfaWQsIHVuYXZhaWxhYmxlU2lnKHUpKTtcbiAgfVxuICBjb25zdCByZW1haW5pbmdUd2VldHM6IFJlY29yZDxzdHJpbmcsIENhbm9uaWNhbFR3ZWV0PiA9IHt9O1xuICBmb3IgKGNvbnN0IFt0d2VldElkLCB0d2VldF0gb2YgT2JqZWN0LmVudHJpZXMoY3VycmVudC50d2VldHNfYnlfaWQpKSB7XG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcbiAgICBjb25zdCBjdXJyZW50U2lnID0gZW5nYWdlbWVudFNpZyhcbiAgICAgIHR3ZWV0Lmxpa2VfY291bnQsXG4gICAgICB0d2VldC5yZXR3ZWV0X2NvdW50LFxuICAgICAgdHdlZXQucmVwbHlfY291bnQsXG4gICAgICB0d2VldC5xdW90ZV9jb3VudCxcbiAgICAgIHR3ZWV0LmlzX3RydW5jYXRlZFxuICAgICk7XG4gICAgaWYgKCFjb21taXR0ZWRTaWcgfHwgY29tbWl0dGVkU2lnICE9PSBjdXJyZW50U2lnKSB7XG4gICAgICByZW1haW5pbmdUd2VldHNbdHdlZXRJZF0gPSB7IC4uLnR3ZWV0IH07XG4gICAgfVxuICB9XG4gIGNvbnN0IHJlbWFpbmluZ1VuYXZhaWxhYmxlOiBSZWNvcmQ8c3RyaW5nLCBVbmF2YWlsYWJsZVR3ZWV0PiA9IHt9O1xuICBmb3IgKGNvbnN0IFt0d2VldElkLCB1bmF2YWlsYWJsZV0gb2YgT2JqZWN0LmVudHJpZXMoY3VycmVudC51bmF2YWlsYWJsZV9ieV9pZCA/PyB7fSkpIHtcbiAgICBjb25zdCBjb21taXR0ZWRTaWcgPSBjb21taXR0ZWQuZ2V0KHR3ZWV0SWQpO1xuICAgIGNvbnN0IGN1cnJlbnRTaWcgPSB1bmF2YWlsYWJsZVNpZyh1bmF2YWlsYWJsZSk7XG4gICAgaWYgKCFjb21taXR0ZWRTaWcgfHwgY29tbWl0dGVkU2lnICE9PSBjdXJyZW50U2lnKSB7XG4gICAgICByZW1haW5pbmdVbmF2YWlsYWJsZVt0d2VldElkXSA9IHsgLi4udW5hdmFpbGFibGUgfTtcbiAgICB9XG4gIH1cbiAgY29uc3QgcmVtYWluaW5nUmV0d2VldEVkZ2VzOiBSZWNvcmQ8c3RyaW5nLCBSZXR3ZWV0RWRnZT4gPSB7fTtcbiAgZm9yIChjb25zdCBba2V5LCBlZGdlXSBvZiBPYmplY3QuZW50cmllcyhjdXJyZW50LnJldHdlZXRfZWRnZXNfYnlfa2V5ID8/IHt9KSkge1xuICAgIGlmICghaXRlbS5yZXR3ZWV0RWRnZXMuc29tZSgoY29tbWl0dGVkRWRnZSkgPT4gcmV0d2VldEVkZ2VLZXkoY29tbWl0dGVkRWRnZSkgPT09IGtleSkpIHtcbiAgICAgIHJlbWFpbmluZ1JldHdlZXRFZGdlc1trZXldID0geyAuLi5lZGdlIH07XG4gICAgfVxuICB9XG5cbiAgY29uc3QgcmVtYWluaW5nSWRzID0gbmV3IFNldChbXG4gICAgLi4uT2JqZWN0LmtleXMocmVtYWluaW5nVHdlZXRzKSxcbiAgICAuLi5PYmplY3Qua2V5cyhyZW1haW5pbmdVbmF2YWlsYWJsZSksXG4gICAgLi4uT2JqZWN0LnZhbHVlcyhyZW1haW5pbmdSZXR3ZWV0RWRnZXMpLmZsYXRNYXAoKGVkZ2UpID0+IFtcbiAgICAgIGVkZ2UucmV0d2VldF90d2VldF9pZCxcbiAgICAgIGVkZ2Uub3JpZ2luYWxfdHdlZXRfaWQsXG4gICAgXSksXG4gIF0pO1xuICBjb25zdCByZW1haW5pbmdDb3VudCA9XG4gICAgT2JqZWN0LmtleXMocmVtYWluaW5nVHdlZXRzKS5sZW5ndGggK1xuICAgIE9iamVjdC5rZXlzKHJlbWFpbmluZ1VuYXZhaWxhYmxlKS5sZW5ndGggK1xuICAgIE9iamVjdC5rZXlzKHJlbWFpbmluZ1JldHdlZXRFZGdlcykubGVuZ3RoO1xuICBpZiAocmVtYWluaW5nQ291bnQgPT09IDApIHtcbiAgICBhd2FpdCBjbGVhclJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSk7XG4gICAgcmV0dXJuIDA7XG4gIH1cblxuICBjb25zdCBuZXh0UnVuSWQgPSBuZXdSdW5JZCgpO1xuICBmb3IgKGNvbnN0IHR3ZWV0IG9mIE9iamVjdC52YWx1ZXMocmVtYWluaW5nVHdlZXRzKSkge1xuICAgIHR3ZWV0LmNhcHR1cmVfcnVuX2lkID0gbmV4dFJ1bklkO1xuICB9XG4gIGZvciAoY29uc3QgZWRnZSBvZiBPYmplY3QudmFsdWVzKHJlbWFpbmluZ1JldHdlZXRFZGdlcykpIHtcbiAgICBlZGdlLmNhcHR1cmVfcnVuX2lkID0gbmV4dFJ1bklkO1xuICB9XG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSwge1xuICAgIC4uLmN1cnJlbnQsXG4gICAgcnVuX2lkOiBuZXh0UnVuSWQsXG4gICAgc3RhcnRlZF9hdDogY3VycmVudC5sYXN0X2NhcHR1cmVfYXQsXG4gICAgdHdlZXRzX2J5X2lkOiByZW1haW5pbmdUd2VldHMsXG4gICAgdW5hdmFpbGFibGVfYnlfaWQ6IHJlbWFpbmluZ1VuYXZhaWxhYmxlLFxuICAgIHJldHdlZXRfZWRnZXNfYnlfa2V5OiByZW1haW5pbmdSZXR3ZWV0RWRnZXMsXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBjdXJyZW50LnR3ZWV0X2lkc19vYnNlcnZlZC5maWx0ZXIoKGlkKSA9PiByZW1haW5pbmdJZHMuaGFzKGlkKSksXG4gIH0pO1xuICBhd2FpdCBpbmZvKCd1cGxvYWQgYnVmZmVyIGtlcHQgbmV3ZXIgdHdlZXRzJywge1xuICAgIGhhbmRsZTogaXRlbS5oYW5kbGUsXG4gICAgY29tbWl0dGVkX3J1bjogaXRlbS5ydW5TaG9ydCxcbiAgICBuZXh0X3J1bjogc2hvcnRSdW5JZChuZXh0UnVuSWQpLFxuICAgIHJlbWFpbmluZzogcmVtYWluaW5nQ291bnQsXG4gIH0pO1xuICByZXR1cm4gcmVtYWluaW5nQ291bnQ7XG59XG5cbi8vIC0tLSBDYXB0dXJlLW5vdyAvIGNhcHR1cmUtYWxsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gY2FwdHVyZU5vdyhoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcbiAgLy8gTGFuZCBvbiB0aGUgUmVwbGllcyB0YWIgc28gWCBmZXRjaGVzIHZpYSBVc2VyVHdlZXRzQW5kUmVwbGllcyBcdTIwMTQgdGhhdFxuICAvLyBlbmRwb2ludCByZXR1cm5zIGJvdGggdG9wLWxldmVsIHBvc3RzIGFuZCByZXBsaWVzLCB3aGljaCBpcyB0aGUgc3VwZXJzZXRcbiAgLy8gd2Ugd2FudCBmb3IgdGhlIGFyY2hpdmUuIFRoZSBwbGFpbiBgLzxoYW5kbGU+YCBVUkwgaGl0cyBVc2VyVHdlZXRzLFxuICAvLyB3aGljaCBvbWl0cyByZXBsaWVzLiBUaGUgcGFnZS1ob29rIGludGVyY2VwdHMgZWl0aGVyIGVuZHBvaW50LCBidXRcbiAgLy8gZm9yY2luZyB0aGUgYnJvYWRlciB0YWIgb24gdXNlci1pbml0aWF0ZWQgY2FwdHVyZXMgaXMgdGhlIHJpZ2h0IGRlZmF1bHQuXG4gIGNvbnN0IHRhcmdldFVybCA9IGBodHRwczovL3guY29tLyR7aGFuZGxlfS93aXRoX3JlcGxpZXNgO1xuICBhd2FpdCBpbmZvKCdjYXB0dXJlLW5vdyByZXF1ZXN0ZWQnLCB7IGhhbmRsZSwgdGFiOiAnd2l0aF9yZXBsaWVzJyB9KTtcbiAgaWYgKCEoYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSkpKSB7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGF3YWl0IHNldFJ1bkJ1ZmZlcihoYW5kbGUsIHtcbiAgICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXG4gICAgICBzdGFydGVkX2F0OiBub3csXG4gICAgICBsYXN0X2NhcHR1cmVfYXQ6IG5vdyxcbiAgICAgIHR3ZWV0c19ieV9pZDoge30sXG4gICAgICB1bmF2YWlsYWJsZV9ieV9pZDoge30sXG4gICAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IFtdLFxuICAgICAgZW5kcG9pbnRzX3NlZW46IFtdLFxuICAgICAgc291cmNlX3VybDogdGFyZ2V0VXJsLFxuICAgIH0pO1xuICB9XG4gIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmw6IHRhcmdldFVybCwgYWN0aXZlOiB0cnVlIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhY2NvdW50cyA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtYWxsIHJlcXVlc3RlZCcsIHsgY291bnQ6IGFjY291bnRzLmxlbmd0aCB9KTtcbiAgZm9yIChjb25zdCBhIG9mIGFjY291bnRzKSB7XG4gICAgYXdhaXQgY2FwdHVyZU5vdyhhLmhhbmRsZSk7XG4gIH1cbn1cblxuLyoqXG4gKiBDYXB0dXJlIHdoYXRldmVyIHRoZSB1c2VyIGlzIGN1cnJlbnRseSBsb29raW5nIGF0OiBlbnN1cmVzIHBhZ2UtaG9vayBpc1xuICogcGF0Y2hlZCBpbnRvIHRoZSBhY3RpdmUgdGFiLCB0aGVuIG51ZGdlcyB0aGUgcGFnZSB3aXRoIGEgcHJvZ3JhbW1hdGljXG4gKiBzY3JvbGwgc28gWCBmaXJlcyBhbm90aGVyIGJhdGNoIG9mIEdyYXBoUUwgcmVxdWVzdHMgd2UgY2FuIGludGVyY2VwdC5cbiAqXG4gKiBMZXNzIGRpc3J1cHRpdmUgdGhhbiBgQ2FwdHVyZSBub3dgIChubyBuZXcgdGFiLCBubyBuYXZpZ2F0aW9uKSBhbmQgd29ya3NcbiAqIGZvciBhcmJpdHJhcnkgWCBVUkxzIChzcGVjaWZpYyB0d2VldCB0aHJlYWRzLCBzZWFyY2ggcmVzdWx0cywgbGlzdHMpXG4gKiB0aGF0IGRvbid0IG1hcCBjbGVhbmx5IHRvIG9uZSBvZiB0aGUgY29uZmlndXJlZCBoYW5kbGVzLlxuICovXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlVGhpc1BhZ2UoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGFsbG93TWFudWFsQ2FwdHVyZVdpbmRvdygpO1xuICBsZXQgdGFiczogYnJvd3Nlci50YWJzLlRhYltdO1xuICB0cnkge1xuICAgIHRhYnMgPSBhd2FpdCBicm93c2VyLnRhYnMucXVlcnkoeyBhY3RpdmU6IHRydWUsIGN1cnJlbnRXaW5kb3c6IHRydWUgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBjb3VsZCBub3QgcXVlcnkgYWN0aXZlIHRhYicsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHRhYiA9IHRhYnNbMF07XG4gIGlmICghdGFiIHx8IHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInIHx8ICF0YWIudXJsKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IG5vIGFjdGl2ZSB0YWInKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKCEvXmh0dHBzOlxcL1xcLyh4fHR3aXR0ZXIpXFwuY29tXFwvLy50ZXN0KHRhYi51cmwpKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGFjdGl2ZSB0YWIgaXMgbm90IG9uIHguY29tIC8gdHdpdHRlci5jb20nLCB7XG4gICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCksXG4gICAgfSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtdGhpcy1wYWdlIHJlcXVlc3RlZCcsIHsgdXJsOiBzaG9ydGVuVXJsKHRhYi51cmwpIH0pO1xuICAvLyAoUmUtKWluamVjdCB0aGUgcGFnZS1ob29rICsgaXNvbGF0ZWQgY29udGVudCBzY3JpcHQgc28gZmV0Y2gvWEhSIGFyZVxuICAvLyBwYXRjaGVkIGV2ZW4gb24gdGFicyBvcGVuZWQgYmVmb3JlIHRoZSBleHRlbnNpb24gcmVsb2FkZWQuXG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgZmlsZXM6IFsncGFnZS1ob29rLmpzJ10sXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXG4gICAgfSk7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgZmlsZXM6IFsnY29udGVudC5qcyddLFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdjYXB0dXJlLXRoaXMtcGFnZTogcmUtaW5qZWN0IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbiAgLy8gTnVkZ2UgWCB0byBmaXJlIG1vcmUgR3JhcGhRTCByZXF1ZXN0cyBieSBzY3JvbGxpbmcuIE1vc3QgdGltZWxpbmUgL1xuICAvLyBjb252ZXJzYXRpb24gdmlld3MgZmV0Y2ggb24gaW50ZXJzZWN0aW9uLW9ic2VydmVyIHRyaWdnZXJzLlxuICB0cnkge1xuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgIGZ1bmM6ICgpID0+IHtcbiAgICAgICAgY29uc3QgaCA9IHdpbmRvdy5pbm5lckhlaWdodDtcbiAgICAgICAgd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSksIDYwMCk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSksIDEyMDApO1xuICAgICAgfSxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IHNjcm9sbC1udWRnZSBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG59XG5cbi8vIC0tLSBSZWZldGNoIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vL1xuLy8gWCB0cnVuY2F0ZXMgbG9uZyB0d2VldHMgaW4gdGltZWxpbmUgcGF5bG9hZHMgXHUyMDE0IGBub3RlX3R3ZWV0YCBpcyBvbmx5XG4vLyBpbmxpbmVkIGZvciBzb21lIGVuZHBvaW50cy4gUmUtb3BlbmluZyBlYWNoIHRydW5jYXRlZCB0d2VldCdzIGRldGFpbCBwYWdlXG4vLyBjYXVzZXMgdGhlIHBhZ2UtaG9vayB0byBjYXB0dXJlIHRoZSBmdWxsIGBub3RlX3R3ZWV0YCBib2R5LiBUaGUgbG9vcFxuLy8gZHJpdmVzIHRoYXQgYnkgbmF2aWdhdGluZyBhIHNpbmdsZSBkZWRpY2F0ZWQgdGFiIHRocm91Z2ggdGhlIHF1ZXVlLCBvbmVcbi8vIHR3ZWV0IGF0IGEgdGltZSwgZ2F0ZWQgb24gdGhlIHBhZ2UtaG9vayBhY3R1YWxseSBpbmdlc3RpbmcgYSByZXNwb25zZSBmb3Jcbi8vIHRoZSB0d2VldCB3ZSBqdXN0IG5hdmlnYXRlZCB0byAoc28gZGVsZXRlZCAvIHBheXdhbGxlZCAvIDQwNCdkIHR3ZWV0c1xuLy8gZG9uJ3QgbWFrZSB1cyBzcGluIGFuZCBzbyB3ZSBkb24ndCBzbGFtIFggd2l0aCByZWZyZXNoZXMgZmFzdGVyIHRoYW4gdGhlXG4vLyB0YWIgY2FuIGxvYWQpLlxuXG5jb25zdCBSRUZFVENIX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV9yZWZldGNoX3RhYl9pZF9fJztcblxuYXN5bmMgZnVuY3Rpb24gZ2V0UmVmZXRjaFRhYklkKCk6IFByb21pc2U8bnVtYmVyIHwgbnVsbD4ge1xuICBjb25zdCBzdG9yZWQgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFJFRkVUQ0hfVEFCX0tFWSk7XG4gIGNvbnN0IGlkID0gc3RvcmVkW1JFRkVUQ0hfVEFCX0tFWV07XG4gIHJldHVybiB0eXBlb2YgaWQgPT09ICdudW1iZXInID8gaWQgOiBudWxsO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRSZWZldGNoVGFiSWQoaWQ6IG51bWJlciB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGlkID09PSBudWxsKSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnJlbW92ZShSRUZFVENIX1RBQl9LRVkpO1xuICB9IGVsc2Uge1xuICAgIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbUkVGRVRDSF9UQUJfS0VZXTogaWQgfSk7XG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XG4gIGNvbnN0IHRvdGFsID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcbiAgaWYgKHRvdGFsID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygncmVmZXRjaDogbm90aGluZyBxdWV1ZWQnKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxuICApO1xuICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbih7XG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcbiAgICBwcm9jZXNzZWQ6IDAsXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgaW5mbGlnaHQ6IG51bGwsXG4gIH0pO1xuICBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcbiAgdm9pZCByZWZldGNoVGljaygpO1xuICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3Agc3RhcnRlZCcsIHsgcXVldWVkOiB0b3RhbCwgaW50ZXJ2YWxfc2VjOiBzZWNvbmRzIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5sZXQgcmVmZXRjaEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gc3RhcnRSZWZldGNoSW50ZXJ2YWwoc2Vjb25kczogbnVtYmVyKTogdm9pZCB7XG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcbiAgcmVmZXRjaEludGVydmFsSGFuZGxlID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgIHZvaWQgcmVmZXRjaFRpY2soKS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICB2b2lkIHdhcm4oJ3JlZmV0Y2ggdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIH0pO1xuICB9LCBzZWNvbmRzICogMTAwMCk7XG59XG5cbmZ1bmN0aW9uIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTogdm9pZCB7XG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSk7XG4gICAgcmVmZXRjaEludGVydmFsSGFuZGxlID0gbnVsbDtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgc3RvcFJlZmV0Y2hJbnRlcnZhbCgpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigncmVmZXRjaC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XG4gIGF3YWl0IHNldFJlZmV0Y2hUYWJJZChudWxsKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCdyZWZldGNoIGxvb3AgY2FuY2VsbGVkJywge1xuICAgIGhhZF90YWI6IHRhYklkICE9PSBudWxsLFxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gIH0pO1xuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZldGNoVGljaygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBpZiAoc2VzcyA9PT0gbnVsbCkge1xuICAgIC8vIExvb3Agd2FzIGNhbmNlbGxlZCBvciBuZXZlciBzdGFydGVkOyBub3RoaW5nIHRvIGRvLlxuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gV2FpdC1mb3ItaW5nZXN0IGd1YXJkOiBpZiB3ZSdyZSBzdGlsbCBleHBlY3RpbmcgYSBjYXB0dXJlIGZvciB0aGVcbiAgLy8gcHJldmlvdXNseS1uYXZpZ2F0ZWQgdGFyZ2V0LCBvbmx5IGFkdmFuY2Ugb25jZSB3ZSd2ZSBlaXRoZXIgc2VlbiB0aGVcbiAgLy8gY2FwdHVyZSAob25HcmFwaHFsQ2FwdHVyZSBjbGVhcnMgYGluZmxpZ2h0YCkgb3IgaGl0IHRoZSB0aW1lb3V0LlxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShzZXNzLmluZmxpZ2h0Lm5hdmlnYXRlZEF0KTtcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgXHUyMDE0IHBhZ2UtaG9vayBtYXkgeWV0IGNhcHR1cmUgdGhlIHJlc3BvbnNlLlxuICAgIH1cbiAgICAvLyBUaW1lZCBvdXQuIFRyZWF0IGFzIFwidGhpcyB0YXJnZXQgd29uJ3QgaW5nZXN0XCIgYW5kIGRyb3AgaXQuXG4gICAgYXdhaXQgd2FybigncmVmZXRjaDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XG4gICAgICB0d2VldF9pZDogc2Vzcy5pbmZsaWdodC50d2VldElkLFxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxuICAgIH0pO1xuICAgIC8vIEZpbmQgd2hpY2ggaGFuZGxlIHRoaXMgaWQgaXMgcXVldWVkIHVuZGVyIHNvIHdlIGNhbiBkZXF1ZXVlIGl0LlxuICAgIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcbiAgICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICAgIGlmIChpZHMuaW5jbHVkZXMoc2Vzcy5pbmZsaWdodC50d2VldElkKSkge1xuICAgICAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaChoYW5kbGUsIHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICB9XG5cbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dFJlZmV0Y2hUYXJnZXQoKTtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICBzdG9wUmVmZXRjaEludGVydmFsKCk7XG4gICAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBjb21wbGV0ZScsIHsgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCB9KTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHVybCA9IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmhhbmRsZX0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcbiAgbGV0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XG4gIGlmICh0YWJJZCAhPT0gbnVsbCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRhYklkID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBpZiAodGFiSWQgPT09IG51bGwpIHtcbiAgICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwsIGFjdGl2ZTogZmFsc2UgfSk7XG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicpIGF3YWl0IHNldFJlZmV0Y2hUYWJJZCh0YWIuaWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcbiAgICB9XG4gICAgc2VzcyA9IChhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpKSA/PyBzZXNzO1xuICAgIHNlc3MuaW5mbGlnaHQgPSB7XG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcbiAgICAgIG5hdmlnYXRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoIHRpY2snLCB7XG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICByZW1haW5pbmc6IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCksXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIH0pO1xuICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHRhcmdldC5oYW5kbGUsIHRhcmdldC50d2VldElkKTtcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHNlc3MpO1xuICB9XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbi8vIC0tLSBNZWRpYS1jcmF3bCBsb29wIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vL1xuLy8gTWlycm9ycyB0aGUgcmVmZXRjaCBsb29wIGJ1dCB0YXJnZXRzIHRoZSBtZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXRzIHRoYXRcbi8vIHRoZSBub3JtYWxpemVyIG9ic2VydmVkIHZpYSB0aGUgTWVkaWEgdGFiIC8gVXNlck1lZGlhIGVuZHBvaW50IHdpdGhcbi8vIGluc3VmZmljaWVudCBkYXRhIHRvIGJ1aWxkIGEgZnVsbCBjYW5vbmljYWwgdHdlZXQuIFRoZSBjcmF3bCBsb29wIHdhbGtzXG4vLyBhIGRlZGljYXRlZCB0YWIgdGhyb3VnaCBlYWNoIHR3ZWV0J3MgZGV0YWlsIHBhZ2UgKGhhbmRsZS1sZXNzIFVSTCBmb3JtXG4vLyB3aGVuIHRoZSBoaW50LWhhbmRsZSBpcyBtaXNzaW5nKSwgYXQgdGhlIGF1dG8tc2Nyb2xsIGNhZGVuY2UsIHNvIHRoZVxuLy8gcGFnZS1ob29rIGNhbiBjYXB0dXJlIHRoZSByZWFsIHR3ZWV0IHNoYXBlLlxuXG5jb25zdCBNRURJQV9DUkFXTF9UQUJfS0VZID0gJ19faW1tX2FyY2hpdmVfbWVkaWFfY3Jhd2xfdGFiX2lkX18nO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoTUVESUFfQ1JBV0xfVEFCX0tFWSk7XG4gIGNvbnN0IGlkID0gc3RvcmVkW01FRElBX0NSQVdMX1RBQl9LRVldO1xuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChpZCA9PT0gbnVsbCkgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnJlbW92ZShNRURJQV9DUkFXTF9UQUJfS0VZKTtcbiAgZWxzZSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW01FRElBX0NSQVdMX1RBQl9LRVldOiBpZCB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRNZWRpYUNyYXdsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XG4gIGNvbnN0IHRvdGFsID0gYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTtcbiAgaWYgKHRvdGFsID09PSAwKSB7XG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IG5vdGhpbmcgcXVldWVkJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXG4gICAgQVVUT19TQ1JPTExfTUFYX1NFQyxcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcbiAgKTtcbiAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oe1xuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXG4gICAgcHJvY2Vzc2VkOiAwLFxuICAgIHN0YXJ0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIGluZmxpZ2h0OiBudWxsLFxuICB9KTtcbiAgc3RhcnRNZWRpYUNyYXdsSW50ZXJ2YWwoc2Vjb25kcyk7XG4gIHZvaWQgbWVkaWFDcmF3bFRpY2soKTtcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBzdGFydGVkJywgeyBxdWV1ZWQ6IHRvdGFsLCBpbnRlcnZhbF9zZWM6IHNlY29uZHMgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmxldCBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGU6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiBzdGFydE1lZGlhQ3Jhd2xJbnRlcnZhbChzZWNvbmRzOiBudW1iZXIpOiB2b2lkIHtcbiAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgY2xlYXJJbnRlcnZhbChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUpO1xuICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgdm9pZCBtZWRpYUNyYXdsVGljaygpLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybignbWVkaWEtY3Jhd2wgdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgIH0pO1xuICB9LCBzZWNvbmRzICogMTAwMCk7XG59XG5cbmZ1bmN0aW9uIHN0b3BNZWRpYUNyYXdsSW50ZXJ2YWwoKTogdm9pZCB7XG4gIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XG4gICAgbWVkaWFDcmF3bEludGVydmFsSGFuZGxlID0gbnVsbDtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxNZWRpYUNyYXdsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignbWVkaWEtY3Jhd2wtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxuICBjb25zdCB0YWJJZCA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xUYWJJZCgpO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQobnVsbCk7XG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xuICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihudWxsKTtcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBjYW5jZWxsZWQnLCB7XG4gICAgaGFkX3RhYjogdGFiSWQgIT09IG51bGwsXG4gICAgcHJvY2Vzc2VkOiBzZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgfSk7XG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG1lZGlhQ3Jhd2xUaWNrKCk6IFByb21pc2U8dm9pZD4ge1xuICBsZXQgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGlmIChzZXNzID09PSBudWxsKSB7XG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xuICAgIGNvbnN0IGVsYXBzZWQgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShzZXNzLmluZmxpZ2h0Lm5hdmlnYXRlZEF0KTtcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgb24gdGhlIHBhZ2UtaG9va1xuICAgIH1cbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XG4gICAgICB0d2VldF9pZDogc2Vzcy5pbmZsaWdodC50d2VldElkLFxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxuICAgIH0pO1xuICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcbiAgfVxuXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRNZWRpYUNyYXdsVGFyZ2V0KCk7XG4gIGlmICghdGFyZ2V0KSB7XG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZChudWxsKTtcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihudWxsKTtcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIC8vIFNraXAgaWYgYWxyZWFkeSBpbiB0aGUgYXJjaGl2ZSBcdTIwMTQgcGFydGlhbCBjYXB0dXJlcyBjYW4gb3V0bGl2ZSBhXG4gIC8vIHNlcGFyYXRlIGZ1bGwgY2FwdHVyZSBwYXRoLlxuICBpZiAoYXdhaXQgaXNDb21taXR0ZWQodGFyZ2V0LnR3ZWV0SWQpKSB7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBXaGVuIHdlIGRvbid0IGtub3cgdGhlIHBhcmVudCdzIGF1dGhvciBoYW5kbGUgKHF1b3RlL1JUIG9mIGEgdHdlZXRcbiAgLy8gWCBzdHJpcHBlZCwgb3IgYSBVc2VyTWVkaWEgdGh1bWJuYWlsIHRoYXQgbGFja2VkIHRoZSBhdXRob3IgYmxvY2spLFxuICAvLyBmYWxsIGJhY2sgdG8gYC9pL3dlYi9zdGF0dXMvPGlkPmAuIFggcmVzb2x2ZXMgaXQgdG8gdGhlIGNvcnJlY3RcbiAgLy8gZGV0YWlsIHBhZ2UsIHdoaWNoIGlzIGVub3VnaCBmb3IgdGhlIHBhZ2UtaG9vayB0byBpbmdlc3QgYVxuICAvLyBUd2VldERldGFpbCByZXNwb25zZS5cbiAgY29uc3QgdXJsID1cbiAgICB0YXJnZXQuYnVja2V0ID09PSAnX3Vua25vd24nXG4gICAgICA/IGBodHRwczovL3guY29tL2kvd2ViL3N0YXR1cy8ke3RhcmdldC50d2VldElkfWBcbiAgICAgIDogYGh0dHBzOi8veC5jb20vJHt0YXJnZXQuYnVja2V0fS9zdGF0dXMvJHt0YXJnZXQudHdlZXRJZH1gO1xuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRNZWRpYUNyYXdsVGFiSWQoKTtcbiAgaWYgKHRhYklkICE9PSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdGFiSWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiBmYWxzZSB9KTtcbiAgICAgIGlmICh0eXBlb2YgdGFiLmlkID09PSAnbnVtYmVyJykgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKHRhYi5pZCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy51cGRhdGUodGFiSWQsIHsgdXJsIH0pO1xuICAgIH1cbiAgICBzZXNzID0gKGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCkpID8/IHNlc3M7XG4gICAgc2Vzcy5pbmZsaWdodCA9IHtcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIHRpY2snLCB7XG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICBoaW50X2hhbmRsZTogdGFyZ2V0LmJ1Y2tldCA9PT0gJ191bmtub3duJyA/IG51bGwgOiB0YXJnZXQuYnVja2V0LFxuICAgICAgcmVtYWluaW5nOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBzZXNzLnRvdGFsQXRTdGFydCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignbWVkaWEtY3Jhd2wgbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuLy8gLS0tIFRocmVhZC1vcGVuaW5nIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy9cbi8vIFRpbWVsaW5lcyBvZnRlbiBzaG93IGEgY29yZSBhY2NvdW50J3Mgcm9vdCB0d2VldCB3aXRob3V0IGV2ZXJ5IGxhdGVyXG4vLyBzZWxmLXJlcGx5IGluIHRoZSBjb252ZXJzYXRpb24uIFRoaXMgdXRpbGl0eSB3YWxrcyBhIGRlZGljYXRlZCB0YWIgdGhyb3VnaFxuLy8gcXVldWVkIGNvcmUgdGhyZWFkIHJvb3RzIGFuZCBudWRnZXMgdGhlIGRldGFpbCBwYWdlIHNvIFR3ZWV0RGV0YWlsIHBheWxvYWRzXG4vLyBsb2FkIHRoZSByZXN0IG9mIHRoZSBjb252ZXJzYXRpb24uXG5cbmNvbnN0IFRIUkVBRF9PUEVOX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV90aHJlYWRfb3Blbl90YWJfaWRfXyc7XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFRocmVhZE9wZW5UYWJJZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChUSFJFQURfT1BFTl9UQUJfS0VZKTtcbiAgY29uc3QgaWQgPSBzdG9yZWRbVEhSRUFEX09QRU5fVEFCX0tFWV07XG4gIHJldHVybiB0eXBlb2YgaWQgPT09ICdudW1iZXInID8gaWQgOiBudWxsO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRUaHJlYWRPcGVuVGFiSWQoaWQ6IG51bWJlciB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGlkID09PSBudWxsKSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFRIUkVBRF9PUEVOX1RBQl9LRVkpO1xuICBlbHNlIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoeyBbVEhSRUFEX09QRU5fVEFCX0tFWV06IGlkIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydFRocmVhZE9wZW5Mb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcbiAgY29uc3QgdG90YWwgPSBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpO1xuICBpZiAodG90YWwgPT09IDApIHtcbiAgICBhd2FpdCBpbmZvKCd0aHJlYWQtb3Blbjogbm90aGluZyBxdWV1ZWQnKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgcyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxuICAgIE1hdGgubWF4KEFVVE9fU0NST0xMX01JTl9TRUMsIE1hdGgucm91bmQocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpKVxuICApO1xuICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbih7XG4gICAgdG90YWxBdFN0YXJ0OiB0b3RhbCxcbiAgICBwcm9jZXNzZWQ6IDAsXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgaW5mbGlnaHQ6IG51bGwsXG4gIH0pO1xuICBzdGFydFRocmVhZE9wZW5JbnRlcnZhbChzZWNvbmRzKTtcbiAgdm9pZCB0aHJlYWRPcGVuVGljaygpO1xuICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxubGV0IHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZTogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIHN0YXJ0VGhyZWFkT3BlbkludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xuICBpZiAodGhyZWFkT3BlbkludGVydmFsSGFuZGxlICE9PSBudWxsKSBjbGVhckludGVydmFsKHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSk7XG4gIHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIHRocmVhZE9wZW5UaWNrKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgdm9pZCB3YXJuKCd0aHJlYWQtb3BlbiB0aWNrIGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gICAgfSk7XG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcbn1cblxuZnVuY3Rpb24gc3RvcFRocmVhZE9wZW5JbnRlcnZhbCgpOiB2b2lkIHtcbiAgaWYgKHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkge1xuICAgIGNsZWFySW50ZXJ2YWwodGhyZWFkT3BlbkludGVydmFsSGFuZGxlKTtcbiAgICB0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbFRocmVhZE9wZW5Mb29wKCk6IFByb21pc2U8dm9pZD4ge1xuICBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk7XG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd0aHJlYWQtb3Blbi10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0VGhyZWFkT3BlblRhYklkKCk7XG4gIGF3YWl0IHNldFRocmVhZE9wZW5UYWJJZChudWxsKTtcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCk7XG4gIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKG51bGwpO1xuICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiBsb29wIGNhbmNlbGxlZCcsIHtcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcbiAgICBwcm9jZXNzZWQ6IHNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICB9KTtcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gdGhyZWFkT3BlblRpY2soKTogUHJvbWlzZTx2b2lkPiB7XG4gIGxldCBzZXNzID0gYXdhaXQgZ2V0VGhyZWFkT3BlblNlc3Npb24oKTtcbiAgaWYgKHNlc3MgPT09IG51bGwpIHtcbiAgICBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xuICAgIGlmIChlbGFwc2VkIDwgSU5HRVNUX1dBSVRfTVMpIHJldHVybjtcbiAgICBhd2FpdCB3YXJuKCd0aHJlYWQtb3BlbjogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XG4gICAgICB0d2VldF9pZDogc2Vzcy5pbmZsaWdodC50d2VldElkLFxuICAgICAgd2FpdGVkX21zOiBlbGFwc2VkLFxuICAgIH0pO1xuICAgIGF3YWl0IG1hcmtUaHJlYWRPcGVuU2VlbihzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xuICAgIGF3YWl0IGRlcXVldWVUaHJlYWRPcGVuKHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzZXNzKTtcbiAgfVxuXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRUaHJlYWRPcGVuVGFyZ2V0KCk7XG4gIGlmICghdGFyZ2V0KSB7XG4gICAgc3RvcFRocmVhZE9wZW5JbnRlcnZhbCgpO1xuICAgIGF3YWl0IHNldFRocmVhZE9wZW5UYWJJZChudWxsKTtcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihudWxsKTtcbiAgICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChhd2FpdCBoYXNUaHJlYWRPcGVuU2Vlbih0YXJnZXQudHdlZXRJZCkpIHtcbiAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzZXNzKTtcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHVybCA9IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmhhbmRsZX0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcbiAgbGV0IHRhYklkID0gYXdhaXQgZ2V0VGhyZWFkT3BlblRhYklkKCk7XG4gIGlmICh0YWJJZCAhPT0gbnVsbCkge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHRhYklkID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgdHJ5IHtcbiAgICBpZiAodGFiSWQgPT09IG51bGwpIHtcbiAgICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwsIGFjdGl2ZTogZmFsc2UgfSk7XG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIHRocm93IG5ldyBFcnJvcignY3JlYXRlZCB0YWIgd2l0aG91dCBpZCcpO1xuICAgICAgdGFiSWQgPSB0YWIuaWQ7XG4gICAgICBhd2FpdCBzZXRUaHJlYWRPcGVuVGFiSWQodGFiSWQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcbiAgICB9XG4gICAgYXdhaXQgbWFya1RocmVhZE9wZW5TZWVuKHRhcmdldC50d2VldElkKTtcbiAgICBzZXNzID0gKGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCkpID8/IHNlc3M7XG4gICAgc2Vzcy5pbmZsaWdodCA9IHtcbiAgICAgIHR3ZWV0SWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHNlc3MpO1xuICAgIGlmICh0YWJJZCAhPT0gbnVsbCkge1xuICAgICAgdm9pZCBudWRnZVRocmVhZE9wZW5UYWIodGFiSWQpO1xuICAgIH1cbiAgICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiB0aWNrJywge1xuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxuICAgICAgdHdlZXRfaWQ6IHRhcmdldC50d2VldElkLFxuICAgICAgcmVtYWluaW5nOiBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpLFxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBzZXNzLnRvdGFsQXRTdGFydCxcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybigndGhyZWFkLW9wZW4gbmF2aWdhdGUgZmFpbGVkOyBkcm9wcGluZyB0YXJnZXQnLCB7XG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gICAgYXdhaXQgbWFya1RocmVhZE9wZW5TZWVuKHRhcmdldC50d2VldElkKTtcbiAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih0YXJnZXQudHdlZXRJZCk7XG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzZXNzKTtcbiAgfVxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBudWRnZVRocmVhZE9wZW5UYWIodGFiSWQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCAxNTAwKSk7XG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHsgdGFiSWQgfSxcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcbiAgICAgIGZ1bmM6ICgpID0+IHtcbiAgICAgICAgY29uc3QgaCA9IHdpbmRvdy5pbm5lckhlaWdodDtcbiAgICAgICAgY29uc3Qgc3RlcCA9ICgpID0+IHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuMywgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xuICAgICAgICBzdGVwKCk7XG4gICAgICAgIHNldFRpbWVvdXQoc3RlcCwgMTQwMCk7XG4gICAgICAgIHNldFRpbWVvdXQoc3RlcCwgMjgwMCk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBhd2FpdCB3YXJuKCd0aHJlYWQtb3BlbiBzY3JvbGwtbnVkZ2UgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgfVxufVxuXG4vLyAtLS0gUXVhcmFudGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5hc3luYyBmdW5jdGlvbiBxdWFyYW50aW5lKFxuICByZWFzb246IHN0cmluZyxcbiAgZW5kcG9pbnQ6IHN0cmluZyxcbiAgdXJsOiBzdHJpbmcsXG4gIHJhdzogdW5rbm93bixcbiAgZXJyOiB1bmtub3duXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgbG9nRXJyKCdxdWFyYW50aW5pbmcgY2FwdHVyZScsIHsgcmVhc29uLCBlbmRwb2ludCwgdXJsLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgaWYgKCFzZXR0aW5ncy5wYXQgfHwgIXNldHRpbmdzLm93bmVyIHx8ICFzZXR0aW5ncy5yZXBvKSByZXR1cm47XG4gIGNvbnN0IHBheWxvYWQ6IFF1YXJhbnRpbmVQYXlsb2FkID0ge1xuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxuICAgIHJlYXNvbixcbiAgICBlbmRwb2ludCxcbiAgICBjYXB0dXJlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHNvdXJjZV91cmw6IHVybCxcbiAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLFxuICAgIHJhdyxcbiAgfTtcbiAgY29uc3QgdHMgPSBpc29Db21wYWN0KHBheWxvYWQuY2FwdHVyZWRfYXQpO1xuICBjb25zdCBoYXNoID0gYXdhaXQgc2hhOChKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XG4gIGNvbnN0IHBhdGggPSBgcmF3L19xdWFyYW50aW5lLyR7dHN9LSR7aGFzaH0uanNvbmA7XG4gIHRyeSB7XG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XG4gICAgYXdhaXQgY2xpZW50LnB1dEZpbGUoe1xuICAgICAgcGF0aCxcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHBheWxvYWQsIG51bGwsIDIpICsgJ1xcbicpLFxuICAgICAgbWVzc2FnZTogYHF1YXJhbnRpbmU6ICR7cmVhc29ufSAke2VuZHBvaW50fWAsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKHFlcnIpIHtcbiAgICBhd2FpdCBsb2dFcnIoJ3F1YXJhbnRpbmUgY29tbWl0IGZhaWxlZCcsIHsgLi4uZGVzY3JpYmVFcnJvcihxZXJyKSB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzaGE4KHM6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGJ1ZiA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcbiAgY29uc3QgZGlnZXN0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kaWdlc3QoJ1NIQS0yNTYnLCBidWYpO1xuICBjb25zdCBoZXggPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGRpZ2VzdCkpXG4gICAgLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcbiAgICAuam9pbignJyk7XG4gIHJldHVybiBoZXguc2xpY2UoMCwgOCk7XG59XG5cbi8vIC0tLSBDb25uZWN0aW9uIHZlcmlmaWNhdGlvbiAmIGFjY291bnRzIGxpc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gdmVyaWZ5Q29ubmVjdGlvbihmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnbm90LWNvbmZpZ3VyZWQnLFxuICAgICAgbG9naW46IG51bGwsXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxuICAgIH0pO1xuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGlmICghZm9yY2UpIHtcbiAgICAvLyBTa2lwIGlmIHdlJ3JlIGluc2lkZSB0aGUgcmVwb3J0ZWQgcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IHJlLWNoZWNraW5nXG4gICAgLy8gYmVmb3JlIHJlc2V0IGp1c3Qgd2FzdGVzIG1vcmUgb2YgdGhlIHNhbWUgZXhoYXVzdGVkIHF1b3RhIGFuZCBrZWVwc1xuICAgIC8vIHRoZSA0MDNzIGNvbWluZy5cbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xuICAgICAgY29uc3Qgbm93U2VjID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCk7XG4gICAgICBpZiAobm93U2VjIDwgY29ubi5yYXRlTGltaXRSZXNldEF0KSByZXR1cm47XG4gICAgfVxuICAgIC8vIEFwcGx5IHRoZSBwZXJpb2RpYy1jaGVjayBnYXRlIHRvIGV2ZXJ5IHN0YXR1cywgbm90IGp1c3QgJ29rJy4gVGhlXG4gICAgLy8gcHJldmlvdXMgYmVoYXZpb3IgcmUtdmVyaWZpZWQgb24gZXZlcnkgd2FrZSB3aGVuZXZlciB0aGUgY29ubmVjdGlvblxuICAgIC8vIHdhc24ndCAnb2snLCB3aGljaCBkdXJpbmcgYSByYXRlLWxpbWl0IHdpbmRvdyBtZWFudCAyIEFQSSBjYWxscyBwZXJcbiAgICAvLyBTVyB3YWtlICh2ZXJpZnlSZXBvQWNjZXNzIGRvZXMgR0VUIC91c2VyICsgR0VUIC9yZXBvcy97b30ve3J9KS5cbiAgICBpZiAoY29ubi5jaGVja2VkQXQpIHtcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGNvbm4uY2hlY2tlZEF0KTtcbiAgICAgIGlmIChhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHIgPSBhd2FpdCBjbGllbnQudmVyaWZ5UmVwb0FjY2VzcygpO1xuICAgIC8vIFByb2JlIHRoZSBjb25maWd1cmVkIGJyYW5jaC4gQSBub24tZGVmYXVsdCBicmFuY2ggaXMgZmluZSBcdTIwMTQgaXQnc1xuICAgIC8vIHJvdXRpbmUgdG8gY2FwdHVyZSBpbnRvIGEgd29ya2luZyBicmFuY2ggXHUyMDE0IGJ1dCBhICptaXNzaW5nKiBicmFuY2hcbiAgICAvLyB3b3VsZCA0MjIgZXZlcnkgY29tbWl0LlxuICAgIGxldCBicmFuY2hPayA9IHRydWU7XG4gICAgaWYgKHNldHRpbmdzLmJyYW5jaCAmJiBzZXR0aW5ncy5icmFuY2ggIT09IHIuZGVmYXVsdF9icmFuY2gpIHtcbiAgICAgIGJyYW5jaE9rID0gYXdhaXQgY2xpZW50LmJyYW5jaEV4aXN0cyhzZXR0aW5ncy5icmFuY2gpO1xuICAgIH1cbiAgICBjb25zdCBjaGVja1dyaXRlID0gZm9yY2UgfHwgaXNXcml0ZUF1dGhFcnJvcihjb25uLmVycm9yKTtcbiAgICBpZiAoYnJhbmNoT2sgJiYgY2hlY2tXcml0ZSkge1xuICAgICAgYXdhaXQgY2xpZW50LnZlcmlmeVdyaXRlQWNjZXNzKCk7XG4gICAgfVxuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xuICAgICAgc3RhdHVzOiAnb2snLFxuICAgICAgbG9naW46IHIubG9naW4sXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGVycm9yOiBudWxsLFxuICAgICAgZGVmYXVsdEJyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGJyYW5jaE9rLFxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcbiAgICB9KTtcbiAgICBhd2FpdCBpbmZvKCdjb25uZWN0aW9uIHZlcmlmaWVkJywge1xuICAgICAgbG9naW46IHIubG9naW4sXG4gICAgICByZXBvOiByLmZ1bGxfbmFtZSxcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxuICAgICAgY29uZmlndXJlZF9icmFuY2g6IHNldHRpbmdzLmJyYW5jaCxcbiAgICAgIGNvbmZpZ3VyZWRfYnJhbmNoX2V4aXN0czogYnJhbmNoT2ssXG4gICAgICB3cml0ZV9hY2Nlc3M6IGNoZWNrV3JpdGUgPyAnY2hlY2tlZCcgOiAnbm90X2NoZWNrZWQnLFxuICAgIH0pO1xuICAgIGlmICghYnJhbmNoT2spIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2NvbmZpZ3VyZWQgYnJhbmNoIGRvZXMgbm90IGV4aXN0IG9uIHJlbW90ZScsIHtcbiAgICAgICAgY29uZmlndXJlZDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgICAgZml4OiAnb3BlbiBTZXR0aW5ncyBhbmQgY2hhbmdlIGJyYW5jaCB0byAnICsgci5kZWZhdWx0X2JyYW5jaCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc3QgY2F0ID0gZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgPyBlcnIuY2F0ZWdvcnkgOiAndW5rbm93bic7XG4gICAgY29uc3Qgc3RhdHVzOiBDb25uZWN0aW9uU3RhdGVbJ3N0YXR1cyddID1cbiAgICAgIGNhdCA9PT0gJ2F1dGgnXG4gICAgICAgID8gJ2F1dGgtZXJyb3InXG4gICAgICAgIDogY2F0ID09PSAncmF0ZS1saW1pdCdcbiAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXG4gICAgICAgICAgOiBjYXQgPT09ICduZXR3b3JrJ1xuICAgICAgICAgICAgPyAnbmV0d29yay1lcnJvcidcbiAgICAgICAgICAgIDogJ2F1dGgtZXJyb3InO1xuICAgIGNvbnN0IHJlc2V0QXQgPVxuICAgICAgZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgY2F0ID09PSAncmF0ZS1saW1pdCcgPyBlcnIucmF0ZUxpbWl0UmVzZXRBdCA6IG51bGw7XG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XG4gICAgICBzdGF0dXMsXG4gICAgICBsb2dpbjogbnVsbCxcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKS5tZXNzYWdlLFxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gICAgICByYXRlTGltaXRSZXNldEF0OiByZXNldEF0LFxuICAgIH0pO1xuICAgIGF3YWl0IHdhcm4oJ2Nvbm5lY3Rpb24gY2hlY2sgZmFpbGVkJywge1xuICAgICAgY2F0ZWdvcnk6IGNhdCxcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXG4gICAgfSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjY291bnRzTGlzdChmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGlmICghc2V0dGluZ3MucGF0KSB7XG4gICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICghZm9yY2UpIHtcbiAgICAvLyBTa2lwIHdoaWxlIGluc2lkZSBhIGtub3duIHJhdGUtbGltaXQgd2luZG93IFx1MjAxNCBhY2NvdW50cy55YW1sIGlzIGZldGNoZWRcbiAgICAvLyB2aWEgYXV0aGVudGljYXRlZCByYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLCB3aGljaCBjb3VudHMgYWdhaW5zdCB0aGVcbiAgICAvLyBzYW1lIHF1b3RhLlxuICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gICAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcbiAgICAgIGNvbnN0IG5vd1NlYyA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBTa2lwIGlmIHdlIHJlZnJlc2hlZCByZWNlbnRseS4gYWNjb3VudHMueWFtbCBjaGFuZ2VzIHJhcmVseSBcdTIwMTQgdGhlIG9sZFxuICAgIC8vIGNvZGUgcmUtZmV0Y2hlZCBpdCBvbiBldmVyeSBTVyB3YWtlLCB3aGljaCBkdXJpbmcgaGVhdnkgYnJvd3NpbmcgbWVhbnRcbiAgICAvLyBhIEdpdEh1YiBjYWxsIGV2ZXJ5IGZldyBzZWNvbmRzIGV2ZW4gd2hlbiBub3RoaW5nIHdhcyBiZWluZyBjYXB0dXJlZC5cbiAgICBjb25zdCBsYXN0UmVmcmVzaGVkID0gYXdhaXQgZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpO1xuICAgIGlmIChsYXN0UmVmcmVzaGVkKSB7XG4gICAgICBjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gRGF0ZS5wYXJzZShsYXN0UmVmcmVzaGVkKTtcbiAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYWdlKSAmJiBhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xuICAgIH1cbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IGNsaWVudCA9IG5ldyBHaXRIdWJDbGllbnQoc2V0dGluZ3MpO1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCBjbGllbnQuZmV0Y2hSYXdUZXh0KCdjb25maWcvYWNjb3VudHMueWFtbCcpO1xuICAgIGlmICghdGV4dCkge1xuICAgICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIG5vdCBmb3VuZCBpbiByZXBvOyB1c2luZyBmYWxsYmFjaycpO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlQWNjb3VudHNZYW1sKHRleHQpO1xuICAgIGlmIChwYXJzZWQubGVuZ3RoID09PSAwKSB7XG4gICAgICBhd2FpdCB3YXJuKCdhY2NvdW50cy55YW1sIHBhcnNlZCBlbXB0eTsga2VlcGluZyBmYWxsYmFjaycpO1xuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGF3YWl0IHNldEFjY291bnRzKHBhcnNlZCk7XG4gICAgYXdhaXQgcmVmcmVzaEFyY2hpdmVTbmFwc2hvdChjbGllbnQsIGZvcmNlKTtcbiAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XG4gICAgaWYgKGZvcmNlKSBhd2FpdCBpbmZvKCdhY2NvdW50cyBsaXN0IHJlZnJlc2hlZCcsIHsgY291bnQ6IHBhcnNlZC5sZW5ndGggfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IHdhcm4oJ3JlZnJlc2ggYWNjb3VudHMgZmFpbGVkOyBrZWVwaW5nIGN1cnJlbnQgbGlzdCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XG4gIH1cbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFyY2hpdmVTbmFwc2hvdChjbGllbnQ6IEdpdEh1YkNsaWVudCwgZm9yY2U6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdGV4dCA9IGF3YWl0IGNsaWVudC5mZXRjaFJhd1RleHQoJ2RhdGEvbWFuaWZlc3QuanNvbicpO1xuICBpZiAoIXRleHQpIHtcbiAgICBhd2FpdCBzZXRBcmNoaXZlU25hcHNob3QobnVsbCk7XG4gICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhcmNoaXZlIG1hbmlmZXN0IG5vdCBmb3VuZDsgb2xkLXR3ZWV0IGRldGVjdGlvbiBkaXNhYmxlZCcpO1xuICAgIHJldHVybjtcbiAgfVxuICB0cnkge1xuICAgIGNvbnN0IHNuYXBzaG90ID0gcGFyc2VBcmNoaXZlU25hcHNob3QoSlNPTi5wYXJzZSh0ZXh0KSBhcyB1bmtub3duKTtcbiAgICBhd2FpdCBzZXRBcmNoaXZlU25hcHNob3Qoc25hcHNob3QpO1xuICAgIGlmIChmb3JjZSkge1xuICAgICAgYXdhaXQgaW5mbygnYXJjaGl2ZSBzbmFwc2hvdCByZWZyZXNoZWQnLCB7XG4gICAgICAgIGFjY291bnRzOiBPYmplY3Qua2V5cyhzbmFwc2hvdC5hY2NvdW50cykubGVuZ3RoLFxuICAgICAgICBnZW5lcmF0ZWRfYXQ6IHNuYXBzaG90LmdlbmVyYXRlZF9hdCxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgYXdhaXQgd2FybignYXJjaGl2ZSBzbmFwc2hvdCBwYXJzZSBmYWlsZWQ7IG9sZC10d2VldCBkZXRlY3Rpb24gZGlzYWJsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9XG59XG5cbi8vIC0tLSBTdGF0ZSBicm9hZGNhc3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuYXN5bmMgZnVuY3Rpb24gYnJvYWRjYXN0U3RhdGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHN0YXRlID0gYXdhaXQgYnVpbGRTdGF0ZSgpO1xuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCB0YWJDb3VudCA9IDA7XG4gIHRyeSB7XG4gICAgY29uc3QgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XG4gICAgdGFiQ291bnQgPSB0YWJzLmxlbmd0aDtcbiAgfSBjYXRjaCB7XG4gICAgLy8gdGFicy5xdWVyeSBpcyBhbGxvd2VkIGJ5IHRoZSBtYW5pZmVzdCBidXQgY2FuIHRyYW5zaWVudGx5IGZhaWxcbiAgICAvLyBhcm91bmQgZXh0ZW5zaW9uIHN0YXJ0dXA7IHN1cmZhY2luZyAwIGlzIGZpbmUuXG4gIH1cbiAgY29uc3QgcmVmZXRjaFF1ZXVlZCA9IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCk7XG4gIGNvbnN0IG1lZGlhQ3Jhd2xRdWV1ZWQgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xuICBjb25zdCB0aHJlYWRPcGVuUXVldWVkID0gYXdhaXQgdGhyZWFkT3BlblF1ZXVlVG90YWwoKTtcbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xuICBjb25zdCBtZWRpYUNyYXdsU2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XG4gIGNvbnN0IHRocmVhZE9wZW5TZXNzID0gYXdhaXQgZ2V0VGhyZWFkT3BlblNlc3Npb24oKTtcbiAgY29uc3QgYXV0b1Njcm9sbFNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xuICBjb25zdCByZWNlbnRUd2VldFNpZ2h0aW5ncyA9IGF3YWl0IGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk7XG4gIHJldHVybiB7XG4gICAgdmVyc2lvbjogRVhUX1ZFUlNJT04sXG4gICAgc2V0dGluZ3M6IHJlZGFjdFNldHRpbmdzKHNldHRpbmdzKSxcbiAgICBjb25uZWN0aW9uOiBjb25uLFxuICAgIGFjY291bnRzLFxuICAgIGNvdW50ZXJzLFxuICAgIGF1dG9TY3JvbGw6IHtcbiAgICAgIGFjdGl2ZTogYXV0b1Njcm9sbFNlc3MgIT09IG51bGwgJiYgYXV0b1Njcm9sbFRpbWVyICE9PSBudWxsLFxuICAgICAgdGFiQ291bnQsXG4gICAgICBzY3JvbGxDb3VudDogYXV0b1Njcm9sbFNlc3M/LnNjcm9sbENvdW50ID8/IDAsXG4gICAgICBpbmdlc3RlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uaW5nZXN0ZWRDb3VudCA/PyAwLFxuICAgICAgaW5nZXN0ZWROZXdDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkTmV3Q291bnQgPz8gMCxcbiAgICAgIGluZ2VzdGVkRXhpc3RpbmdDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkRXhpc3RpbmdDb3VudCA/PyAwLFxuICAgICAgc2tpcHBlZE9sZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uc2tpcHBlZE9sZENvdW50ID8/IDAsXG4gICAgICBleHBhbmRlZENvdW50OiBhdXRvU2Nyb2xsU2Vzcz8uZXhwYW5kZWRDb3VudCA/PyAwLFxuICAgIH0sXG4gICAgcmVmZXRjaFF1ZXVlOiB7XG4gICAgICB0b3RhbDogcmVmZXRjaFF1ZXVlZCxcbiAgICAgIHJ1bm5pbmc6IHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcbiAgICAgIHByb2Nlc3NlZDogcmVmZXRjaFNlc3M/LnByb2Nlc3NlZCA/PyAwLFxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHJlZmV0Y2hTZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcbiAgICB9LFxuICAgIG1lZGlhQ3Jhd2xRdWV1ZToge1xuICAgICAgdG90YWw6IG1lZGlhQ3Jhd2xRdWV1ZWQsXG4gICAgICBydW5uaW5nOiBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwsXG4gICAgICBwcm9jZXNzZWQ6IG1lZGlhQ3Jhd2xTZXNzPy5wcm9jZXNzZWQgPz8gMCxcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiBtZWRpYUNyYXdsU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXG4gICAgfSxcbiAgICB0aHJlYWRPcGVuUXVldWU6IHtcbiAgICAgIHRvdGFsOiB0aHJlYWRPcGVuUXVldWVkLFxuICAgICAgcnVubmluZzogdGhyZWFkT3BlbkludGVydmFsSGFuZGxlICE9PSBudWxsLFxuICAgICAgcHJvY2Vzc2VkOiB0aHJlYWRPcGVuU2Vzcz8ucHJvY2Vzc2VkID8/IDAsXG4gICAgICB0b3RhbF9hdF9zdGFydDogdGhyZWFkT3BlblNlc3M/LnRvdGFsQXRTdGFydCA/PyAwLFxuICAgIH0sXG4gICAgcmVjZW50VHdlZXRTaWdodGluZ3MsXG4gIH07XG59XG5cbmZ1bmN0aW9uIHJlZGFjdFNldHRpbmdzKHM6IFNldHRpbmdzKTogRXh0ZW5zaW9uU3RhdGVbJ3NldHRpbmdzJ10ge1xuICByZXR1cm4ge1xuICAgIG93bmVyOiBzLm93bmVyLFxuICAgIHJlcG86IHMucmVwbyxcbiAgICBicmFuY2g6IHMuYnJhbmNoLFxuICAgIGVuYWJsZWQ6IHMuZW5hYmxlZCxcbiAgICBhdXRvQ2FwdHVyZTogcy5hdXRvQ2FwdHVyZSxcbiAgICBjb25maWd1cmVkQXQ6IHMuY29uZmlndXJlZEF0LFxuICAgIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogcy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMsXG4gICAgdXBkYXRlRXhpc3Rpbmc6IHMudXBkYXRlRXhpc3RpbmcsXG4gICAgbG93QmFuZHdpZHRoQnJvd3Npbmc6IHMubG93QmFuZHdpZHRoQnJvd3NpbmcsXG4gICAgcGF0U2V0OiBzLnBhdC5sZW5ndGggPiAwLFxuICAgIHBhdFN1ZmZpeDogcy5wYXQubGVuZ3RoID49IDQgPyBzLnBhdC5zbGljZSgtNCkgOiAnJyxcbiAgfTtcbn1cblxuZnVuY3Rpb24gcGFyc2VBcmNoaXZlU25hcHNob3QocmF3OiB1bmtub3duKTogQXJjaGl2ZVNuYXBzaG90IHtcbiAgaWYgKCFyYXcgfHwgdHlwZW9mIHJhdyAhPT0gJ29iamVjdCcpIHRocm93IG5ldyBFcnJvcignbWFuaWZlc3QgaXMgbm90IGFuIG9iamVjdCcpO1xuICBjb25zdCBtYW5pZmVzdCA9IHJhdyBhcyB7IGdlbmVyYXRlZF9hdD86IHVua25vd247IGFjY291bnRzPzogdW5rbm93biB9O1xuICBpZiAoIUFycmF5LmlzQXJyYXkobWFuaWZlc3QuYWNjb3VudHMpKSB0aHJvdyBuZXcgRXJyb3IoJ21hbmlmZXN0LmFjY291bnRzIGlzIG5vdCBhbiBhcnJheScpO1xuICBjb25zdCBhY2NvdW50czogQXJjaGl2ZVNuYXBzaG90WydhY2NvdW50cyddID0ge307XG4gIGZvciAoY29uc3QgZW50cnkgb2YgbWFuaWZlc3QuYWNjb3VudHMpIHtcbiAgICBpZiAoIWVudHJ5IHx8IHR5cGVvZiBlbnRyeSAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHJvdyA9IGVudHJ5IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIGNvbnN0IGhhbmRsZSA9IHR5cGVvZiByb3cuaGFuZGxlID09PSAnc3RyaW5nJyA/IHJvdy5oYW5kbGUgOiAnJztcbiAgICBpZiAoIWhhbmRsZSB8fCBoYW5kbGUgPT09ICdfbWlzYycpIGNvbnRpbnVlO1xuICAgIGNvbnN0IG1vbnRoczogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgIGlmIChyb3cubW9udGhzICYmIHR5cGVvZiByb3cubW9udGhzID09PSAnb2JqZWN0Jykge1xuICAgICAgZm9yIChjb25zdCBbaywgdl0gb2YgT2JqZWN0LmVudHJpZXMocm93Lm1vbnRocyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikpIHtcbiAgICAgICAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJykgbW9udGhzW2tdID0gdjtcbiAgICAgIH1cbiAgICB9XG4gICAgYWNjb3VudHNbaGFuZGxlLnRvTG93ZXJDYXNlKCldID0ge1xuICAgICAgaGFuZGxlLFxuICAgICAgZmlyc3RfcG9zdF9hdDogdHlwZW9mIHJvdy5maXJzdF9wb3N0X2F0ID09PSAnc3RyaW5nJyA/IHJvdy5maXJzdF9wb3N0X2F0IDogbnVsbCxcbiAgICAgIGxhdGVzdF9wb3N0X2F0OiB0eXBlb2Ygcm93LmxhdGVzdF9wb3N0X2F0ID09PSAnc3RyaW5nJyA/IHJvdy5sYXRlc3RfcG9zdF9hdCA6IG51bGwsXG4gICAgICBsYXRlc3RfY2FwdHVyZV9hdDogdHlwZW9mIHJvdy5sYXRlc3RfY2FwdHVyZV9hdCA9PT0gJ3N0cmluZycgPyByb3cubGF0ZXN0X2NhcHR1cmVfYXQgOiBudWxsLFxuICAgICAgcm93X2NvdW50OiB0eXBlb2Ygcm93LnJvd19jb3VudCA9PT0gJ251bWJlcicgPyByb3cucm93X2NvdW50IDogbnVsbCxcbiAgICAgIG1vbnRocyxcbiAgICB9O1xuICB9XG4gIHJldHVybiB7XG4gICAgZ2VuZXJhdGVkX2F0OiB0eXBlb2YgbWFuaWZlc3QuZ2VuZXJhdGVkX2F0ID09PSAnc3RyaW5nJyA/IG1hbmlmZXN0LmdlbmVyYXRlZF9hdCA6IG51bGwsXG4gICAgZmV0Y2hlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIGFjY291bnRzLFxuICB9O1xufVxuXG5mdW5jdGlvbiBhcmNoaXZlU25hcHNob3RIYXNUd2VldCh0OiBDYW5vbmljYWxUd2VldCwgc25hcHNob3Q6IEFyY2hpdmVTbmFwc2hvdCB8IG51bGwpOiBib29sZWFuIHtcbiAgaWYgKCFzbmFwc2hvdCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBlbnRyeSA9IHNuYXBzaG90LmFjY291bnRzW3QuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKV07XG4gIGlmICghZW50cnk/LmxhdGVzdF9wb3N0X2F0KSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHBvc3RlZCA9IERhdGUucGFyc2UodC5wb3N0ZWRfYXQpO1xuICBjb25zdCBsYXRlc3QgPSBEYXRlLnBhcnNlKGVudHJ5LmxhdGVzdF9wb3N0X2F0KTtcbiAgcmV0dXJuIE51bWJlci5pc0Zpbml0ZShwb3N0ZWQpICYmIE51bWJlci5pc0Zpbml0ZShsYXRlc3QpICYmIHBvc3RlZCA8PSBsYXRlc3Q7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkVHdlZXRTaWdodGluZyhcbiAgdDogQ2Fub25pY2FsVHdlZXQsXG4gIGVuZHBvaW50OiBzdHJpbmcsXG4gIHNlZW5BdDogc3RyaW5nLFxuICBmcmVzaG5lc3M6ICduZXcnIHwgJ2V4aXN0aW5nJyA9ICduZXcnLFxuICBhY3Rpb246IFR3ZWV0U2lnaHRpbmdbJ2FjdGlvbiddID0gJ2J1ZmZlcmVkJ1xuKTogVHdlZXRTaWdodGluZyB7XG4gIHJldHVybiB7XG4gICAgdHdlZXRfaWQ6IHQudHdlZXRfaWQsXG4gICAgYWNjb3VudF9oYW5kbGU6IHQuYWNjb3VudF9oYW5kbGUsXG4gICAgcG9zdGVkX2F0OiB0LnBvc3RlZF9hdCxcbiAgICB0ZXh0OiB0LnRleHRfcmVzb2x2ZWQgfHwgdC50ZXh0LFxuICAgIHR3ZWV0X3R5cGU6IHQudHdlZXRfdHlwZSxcbiAgICB0d2VldF91cmw6IHQudHdlZXRfdXJsLFxuICAgIHNlZW5fYXQ6IHNlZW5BdCxcbiAgICBlbmRwb2ludCxcbiAgICBhcmNoaXZlX3N0YXR1czogZnJlc2huZXNzID09PSAnZXhpc3RpbmcnID8gJ3NhdmVkJyA6ICduZXcnLFxuICAgIGFjdGlvbixcbiAgfTtcbn1cblxuZnVuY3Rpb24gaXNXcml0ZUF1dGhFcnJvcihtZXNzYWdlOiBzdHJpbmcgfCBudWxsKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnICYmXG4gICAgL1Jlc291cmNlIG5vdCBhY2Nlc3NpYmxlIGJ5IHBlcnNvbmFsIGFjY2VzcyB0b2tlbnxcXC9naXRcXC9ibG9ic3xcXC9naXRcXC9yZWZzL2kudGVzdChtZXNzYWdlKVxuICApO1xufVxuXG5mdW5jdGlvbiBpc29Db21wYWN0KGlzbzogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gMjAyNS0wNC0xMlQxNDoyMzowMS4wMDBaIFx1MjE5MiAyMDI1LTA0LTEyVDE0MjMwMVpcbiAgY29uc3QgZCA9IG5ldyBEYXRlKGlzbyk7XG4gIGlmIChOdW1iZXIuaXNOYU4oZC5nZXRUaW1lKCkpKSByZXR1cm4gaXNvLnJlcGxhY2UoL1s6Ll0vZywgJycpO1xuICBjb25zdCBwYWQgPSAobjogbnVtYmVyLCB3ID0gMikgPT4gU3RyaW5nKG4pLnBhZFN0YXJ0KHcsICcwJyk7XG4gIHJldHVybiAoXG4gICAgYCR7ZC5nZXRVVENGdWxsWWVhcigpfS0ke3BhZChkLmdldFVUQ01vbnRoKCkgKyAxKX0tJHtwYWQoZC5nZXRVVENEYXRlKCkpfWAgK1xuICAgIGBUJHtwYWQoZC5nZXRVVENIb3VycygpKX0ke3BhZChkLmdldFVUQ01pbnV0ZXMoKSl9JHtwYWQoZC5nZXRVVENTZWNvbmRzKCkpfVpgXG4gICk7XG59XG5cbmZ1bmN0aW9uIHZpZXdlclVybChzOiBTZXR0aW5ncyk6IHN0cmluZyB7XG4gIHJldHVybiBgaHR0cHM6Ly8ke3Mub3duZXJ9LmdpdGh1Yi5pby8ke3MucmVwb30vYDtcbn1cblxuLyoqXG4gKiBXYWxrIGBub2RlYCBjb2xsZWN0aW5nIGRvdHRlZCBrZXkgcGF0aHMgdXAgdG8gYG1heERlcHRoYCBkZWVwLiBBcnJheVxuICogaW5kaWNlcyBjb2xsYXBzZSB0byBgWzBdYCAod2Ugb25seSBkZXNjZW5kIGludG8gdGhlIGZpcnN0IGVsZW1lbnQpLiBVc2VkXG4gKiB0byBzdXJmYWNlIHRoZSBzdHJ1Y3R1cmFsIHNrZWxldG9uIG9mIGFuIHVuZmFtaWxpYXIgR3JhcGhRTCByZXNwb25zZVxuICogd2l0aG91dCBpbmNsdWRpbmcgYW55IGRhdGEgdmFsdWVzLlxuICovXG4vKiogQ29sbGVjdCBldmVyeSBkaXN0aW5jdCBgX190eXBlbmFtZWAgdmFsdWUgZm91bmQgYW55d2hlcmUgaW4gdGhlIHRyZWUuICovXG5mdW5jdGlvbiBwcm9iZVR5cGVuYW1lcyhub2RlOiB1bmtub3duKTogc3RyaW5nW10ge1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGlmICh0eXBlb2Ygb2JqLl9fdHlwZW5hbWUgPT09ICdzdHJpbmcnKSBzZWVuLmFkZChvYmouX190eXBlbmFtZSk7XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gWy4uLnNlZW5dLnNvcnQoKTtcbn1cblxuLyoqXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIGFueXdoZXJlIGluIHRoZSB0cmVlIHdob3NlIGBfX3R5cGVuYW1lYCBtYXRjaGVzIGFuZFxuICogcmV0dXJuIGl0cyB0b3AtbGV2ZWwga2V5IGxpc3QgKHNvcnRlZCkuIFVzZWZ1bCBmb3IgZGlzY292ZXJpbmcgd2hhdCBmaWVsZHNcbiAqIFggaXMgYWN0dWFsbHkgc2hpcHBpbmcgZm9yIGEgZ2l2ZW4gbm9kZSB0eXBlIGFmdGVyIGEgc2NoZW1hIGNoYW5nZS5cbiAqL1xuZnVuY3Rpb24gcHJvYmVGaXJzdFR5cGVTaGFwZShub2RlOiB1bmtub3duLCB0eXBlbmFtZTogc3RyaW5nKTogc3RyaW5nW10gfCBudWxsIHtcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcbiAgICB2aXNpdGVkLmFkZChuIGFzIG9iamVjdCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgICAgaWYgKG9iai5fX3R5cGVuYW1lID09PSB0eXBlbmFtZSkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMob2JqKS5zb3J0KCk7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhvYmopKSBzdGFjay5wdXNoKHYpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLyoqXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIHdpdGggYF9fdHlwZW5hbWUgPT09IHR5cGVuYW1lYCwgdGhlbiBkZXNjZW5kIHRocm91Z2hcbiAqIHRoZSBnaXZlbiBrZXkgcGF0aCwgYW5kIHJldHVybiB0aGUgdG9wLWxldmVsIGtleXMgb2Ygd2hhdGV2ZXIgaXMgYXQgdGhlXG4gKiBlbmQuIFJldHVybnMgYSBtYXJrZXIgc3RyaW5nIHdoZW4gdGhlIHBhdGggbGVhZHMgc29tZXdoZXJlIG5vbi1vYmplY3Qgc29cbiAqIHdlIGNhbiB0ZWxsIGFwYXJ0IFwiYWJzZW50XCIgZnJvbSBcInByZXNlbnQgYnV0IG5vdCBhbiBvYmplY3RcIi5cbiAqL1xuZnVuY3Rpb24gcHJvYmVUeXBlZE5lc3RlZChub2RlOiB1bmtub3duLCB0eXBlbmFtZTogc3RyaW5nLCBwYXRoOiBzdHJpbmdbXSk6IHVua25vd24ge1xuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xuICBsZXQgZm91bmQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCA9IG51bGw7XG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XG4gICAgaWYgKHZpc2l0ZWQuaGFzKG4gYXMgb2JqZWN0KSkgY29udGludWU7XG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XG4gICAgICBmb3IgKGNvbnN0IHYgb2Ygbikgc3RhY2sucHVzaCh2KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIGlmIChvYmouX190eXBlbmFtZSA9PT0gdHlwZW5hbWUpIHtcbiAgICAgICAgZm91bmQgPSBvYmo7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcbiAgICB9XG4gIH1cbiAgaWYgKCFmb3VuZCkgcmV0dXJuIG51bGw7XG4gIGxldCBjdXI6IHVua25vd24gPSBmb3VuZDtcbiAgZm9yIChjb25zdCBzZWcgb2YgcGF0aCkge1xuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIHJldHVybiBgPCR7Y3VyID09PSBudWxsID8gJ251bGwnIDogdHlwZW9mIGN1cn0+YDtcbiAgICBjdXIgPSAoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KVtzZWddO1xuICB9XG4gIGlmIChjdXIgPT09IHVuZGVmaW5lZCkgcmV0dXJuICc8bWlzc2luZz4nO1xuICBpZiAoY3VyID09PSBudWxsKSByZXR1cm4gJzxudWxsPic7XG4gIGlmICh0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgcmV0dXJuIGA8JHt0eXBlb2YgY3VyfT5gO1xuICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSByZXR1cm4gYDxhcnJheSBsZW49JHtjdXIubGVuZ3RofT5gO1xuICByZXR1cm4gT2JqZWN0LmtleXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5zb3J0KCk7XG59XG5cbmZ1bmN0aW9uIHNob3J0ZW5VcmwodTogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gQWN0aXZpdHktdGFpbCBjb250ZXh0IGlzIG1vcmUgdXNlZnVsIHdpdGgganVzdCB0aGUgcGF0aDsgZnVsbCBVUkxzIGJlY29tZVxuICAvLyBoYXJkIHRvIHJlYWQgYXQgdGhlIHNpZGViYXIncyB3aWR0aC5cbiAgdHJ5IHtcbiAgICBjb25zdCBwYXJzZWQgPSBuZXcgVVJMKHUpO1xuICAgIGNvbnN0IHBhdGggPSBwYXJzZWQucGF0aG5hbWUgKyAocGFyc2VkLnNlYXJjaCA/ICc/XHUyMDI2JyA6ICcnKTtcbiAgICByZXR1cm4gcGFyc2VkLmhvc3QgPT09ICd4LmNvbScgfHwgcGFyc2VkLmhvc3QgPT09ICd0d2l0dGVyLmNvbSdcbiAgICAgID8gcGF0aFxuICAgICAgOiBgJHtwYXJzZWQuaG9zdH0ke3BhdGh9YDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHUubGVuZ3RoID4gODAgPyBgJHt1LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdTtcbiAgfVxufVxuXG4vLyAtLS0gRGV2IGhlbHBlcnMgZXhwb3NlZCBvbiBnbG9iYWxUaGlzIGZvciB0aGUgZGV2dG9vbHMgY29uc29sZSAtLS0tLS0tLS0tXG4vLyAoZS5nLiBgX19pbW1BcmNoaXZlLmNsZWFyQWxsKClgIGluIHRoZSBiYWNrZ3JvdW5kIHdvcmtlcidzIGRldnRvb2xzKS5cblxuKGdsb2JhbFRoaXMgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLl9faW1tQXJjaGl2ZSA9IHtcbiAgY2xlYXJBbGwsXG4gIGFjdGl2aXR5OiBnZXRBY3Rpdml0eSxcbiAgYWNjb3VudHM6IGdldEFjY291bnRzLFxuICBidWZmZXJzOiBnZXRSdW5CdWZmZXJzLFxuICBmbHVzaEFsbDogKCkgPT4gZmx1c2hBbGwoJ2RldnRvb2xzJyksXG4gIHN0YXRlOiBidWlsZFN0YXRlLFxuICByZWZldGNoUXVldWU6IGdldFJlZmV0Y2hRdWV1ZSxcbiAgc3RhcnRSZWZldGNoOiBzdGFydFJlZmV0Y2hMb29wLFxuICBjYW5jZWxSZWZldGNoOiBjYW5jZWxSZWZldGNoTG9vcCxcbiAgbWVkaWFDcmF3bFF1ZXVlOiBnZXRNZWRpYUNyYXdsUXVldWUsXG4gIHN0YXJ0TWVkaWFDcmF3bDogc3RhcnRNZWRpYUNyYXdsTG9vcCxcbiAgY2FuY2VsTWVkaWFDcmF3bDogY2FuY2VsTWVkaWFDcmF3bExvb3AsXG4gIHRocmVhZE9wZW5RdWV1ZTogZ2V0VGhyZWFkT3BlblF1ZXVlLFxuICBzdGFydFRocmVhZE9wZW46IHN0YXJ0VGhyZWFkT3Blbkxvb3AsXG4gIGNhbmNlbFRocmVhZE9wZW46IGNhbmNlbFRocmVhZE9wZW5Mb29wLFxufTtcbiJdLAogICJtYXBwaW5ncyI6ICI7OztBQUVPLElBQU0sbUJBQTZCO0FBQUEsRUFDeEMsS0FBSztBQUFBLEVBQ0wsT0FBTztBQUFBLEVBQ1AsTUFBTTtBQUFBO0FBQUE7QUFBQSxFQUdOLFFBQVE7QUFBQSxFQUNSLFNBQVM7QUFBQSxFQUNULGFBQWE7QUFBQSxFQUNiLGNBQWM7QUFBQSxFQUNkLHVCQUF1QjtBQUFBLEVBQ3ZCLGdCQUFnQjtBQUFBLEVBQ2hCLHNCQUFzQjtBQUN4QjtBQUVPLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sc0JBQXNCO0FBSTVCLElBQU0sb0JBQXFDO0FBQUEsRUFDaEQsRUFBRSxRQUFRLFVBQVUsT0FBTyxtQ0FBbUMsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFVBQVUsT0FBTyw0Q0FBNEMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLE9BQU8sT0FBTyxzQ0FBc0MsVUFBVSxPQUFPO0FBQUEsRUFDL0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw2Q0FBNkMsVUFBVSxPQUFPO0FBQUEsRUFDeEYsRUFBRSxRQUFRLGNBQWMsT0FBTyxtQkFBbUIsVUFBVSxPQUFPO0FBQUEsRUFDbkUsRUFBRSxRQUFRLFlBQVksT0FBTywrQkFBK0IsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyxrQ0FBa0MsVUFBVSxPQUFPO0FBQUEsRUFDN0UsRUFBRSxRQUFRLFNBQVMsT0FBTyw0QkFBNEIsVUFBVSxPQUFPO0FBQUEsRUFDdkUsRUFBRSxRQUFRLG1CQUFtQixPQUFPLHFCQUFxQixVQUFVLE9BQU87QUFBQSxFQUMxRSxFQUFFLFFBQVEsWUFBWSxPQUFPLGtCQUFrQixVQUFVLE9BQU87QUFBQSxFQUNoRSxFQUFFLFFBQVEsa0JBQWtCLE9BQU8sa0JBQWtCLFVBQVUsT0FBTztBQUFBLEVBQ3RFLEVBQUUsUUFBUSxnQkFBZ0IsT0FBTyxtQkFBbUIsVUFBVSxPQUFPO0FBQ3ZFO0FBR08sSUFBTSxrQkFBdUMsb0JBQUksSUFBSTtBQUFBLEVBQzFEO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBV00sSUFBTSxvQkFBeUMsb0JBQUksSUFBSSxDQUFDLG9CQUFvQixjQUFjLENBQUM7QUF1QjNGLElBQU0sd0JBQXdCO0FBRzlCLElBQU0sZ0JBQWdCO0FBR3RCLElBQU0sc0JBQXNCO0FBRzVCLElBQU0sb0JBQW9CO0FBRzFCLElBQU0sZ0NBQWdDLEtBQUssS0FBSztBQUVoRCxJQUFNLG1CQUFtQjs7O0FDM0VoQyxJQUFNLG1CQUFtQjtBQUN6QixJQUFNLGtCQUFrQjtBQUV4QixJQUFJLGtCQUFvQztBQUN4QyxJQUFJLHNCQUFxQztBQUV6QyxTQUFTLFNBQVMsS0FBeUI7QUFDekMsTUFBSSxJQUFJO0FBQ1IsYUFBVyxLQUFLLElBQUssTUFBSyxPQUFPLGFBQWEsQ0FBQztBQUMvQyxTQUFPLEtBQUssQ0FBQztBQUNmO0FBRUEsU0FBUyxXQUFXLEdBQXVCO0FBQ3pDLFFBQU0sTUFBTSxLQUFLLENBQUM7QUFDbEIsUUFBTSxNQUFNLElBQUksV0FBVyxJQUFJLE1BQU07QUFDckMsV0FBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsSUFBSyxLQUFJLENBQUMsSUFBSSxJQUFJLFdBQVcsQ0FBQztBQUM5RCxTQUFPO0FBQ1Q7QUFFQSxlQUFlLG1CQUFtRTtBQUNoRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUMvRCxRQUFNLElBQUksT0FBTyxnQkFBZ0I7QUFDakMsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxXQUFPLEVBQUUsU0FBUyxHQUFHLE1BQU0sV0FBVyxDQUFDLEVBQUU7QUFBQSxFQUMzQztBQUNBLFFBQU0sT0FBTyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxTQUFTLElBQUk7QUFDN0IsUUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUM7QUFDL0QsU0FBTyxFQUFFLFNBQVMsS0FBSztBQUN6QjtBQUVBLGVBQWUsWUFBZ0M7QUFDN0MsUUFBTSxFQUFFLFNBQVMsS0FBSyxJQUFJLE1BQU0saUJBQWlCO0FBQ2pELE1BQUksb0JBQW9CLFFBQVEsd0JBQXdCLFNBQVM7QUFDL0QsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUU7QUFBQSxJQUM3QixHQUFHLFFBQVEsUUFBUSxFQUFFLElBQUksUUFBUSxRQUFRLFlBQVksRUFBRSxPQUFPO0FBQUEsRUFDaEU7QUFDQSxRQUFNLFdBQVcsSUFBSSxXQUFXLEtBQUssU0FBUyxLQUFLLE1BQU07QUFDekQsV0FBUyxJQUFJLE1BQU0sQ0FBQztBQUNwQixXQUFTLElBQUksTUFBTSxLQUFLLE1BQU07QUFDOUIsUUFBTSxPQUFPLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxRQUFRO0FBQzNELFFBQU0sTUFBTSxNQUFNLE9BQU8sT0FBTyxVQUFVLE9BQU8sTUFBTSxFQUFFLE1BQU0sVUFBVSxHQUFHLE9BQU87QUFBQSxJQUNqRjtBQUFBLElBQ0E7QUFBQSxFQUNGLENBQUM7QUFDRCxvQkFBa0I7QUFDbEIsd0JBQXNCO0FBQ3RCLFNBQU87QUFDVDtBQUVPLFNBQVMsZUFBZSxHQUFvQjtBQUNqRCxTQUFPLEVBQUUsV0FBVyxlQUFlO0FBQ3JDO0FBRUEsZUFBc0IsV0FBVyxXQUFvQztBQUNuRSxNQUFJLENBQUMsVUFBVyxRQUFPO0FBQ3ZCLFFBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsUUFBTSxLQUFLLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDcEQsUUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsSUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBRztBQUFBLElBQ3RCO0FBQUEsSUFDQSxJQUFJLFlBQVksRUFBRSxPQUFPLFNBQVM7QUFBQSxFQUNwQztBQUNBLFNBQU8sR0FBRyxlQUFlLEdBQUcsU0FBUyxFQUFFLENBQUMsSUFBSSxTQUFTLElBQUksV0FBVyxFQUFFLENBQUMsQ0FBQztBQUMxRTtBQUVBLGVBQXNCLFdBQVcsVUFBbUM7QUFDbEUsTUFBSSxDQUFDLFNBQVUsUUFBTztBQUd0QixNQUFJLENBQUMsU0FBUyxXQUFXLGVBQWUsRUFBRyxRQUFPO0FBQ2xELFFBQU0sUUFBUSxTQUFTLE1BQU0sZ0JBQWdCLE1BQU0sRUFBRSxNQUFNLEdBQUc7QUFDOUQsTUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBQy9CLFFBQU0sQ0FBQyxPQUFPLEtBQUssSUFBSTtBQUN2QixNQUFJLENBQUMsU0FBUyxDQUFDLE1BQU8sUUFBTztBQUM3QixNQUFJO0FBQ0YsVUFBTSxNQUFNLE1BQU0sVUFBVTtBQUM1QixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxXQUFXLEtBQUs7QUFDM0IsVUFBTSxLQUFLLE1BQU0sT0FBTyxPQUFPO0FBQUEsTUFDN0IsRUFBRSxNQUFNLFdBQVcsR0FBdUI7QUFBQSxNQUMxQztBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsV0FBTyxJQUFJLFlBQVksRUFBRSxPQUFPLEVBQUU7QUFBQSxFQUNwQyxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjs7O0FDWEEsSUFBTSxxQkFBc0M7QUFBQSxFQUMxQyxRQUFRO0FBQUEsRUFDUixPQUFPO0FBQUEsRUFDUCxXQUFXO0FBQUEsRUFDWCxPQUFPO0FBQUEsRUFDUCxlQUFlO0FBQUEsRUFDZix3QkFBd0I7QUFBQSxFQUN4QixrQkFBa0I7QUFDcEI7QUFFQSxJQUFNLFdBQXlCO0FBQUEsRUFDN0IsVUFBVSxFQUFFLEdBQUcsaUJBQWlCO0FBQUEsRUFDaEMsVUFBVSxDQUFDLEdBQUcsaUJBQWlCO0FBQUEsRUFDL0IscUJBQXFCO0FBQUEsRUFDckIsaUJBQWlCO0FBQUEsRUFDakIsWUFBWSxFQUFFLEdBQUcsbUJBQW1CO0FBQUEsRUFDcEMsVUFBVSxDQUFDO0FBQUEsRUFDWCxZQUFZLENBQUM7QUFBQSxFQUNiLFVBQVUsQ0FBQztBQUFBLEVBQ1gsc0JBQXNCLENBQUM7QUFBQSxFQUN2QixnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGNBQWMsQ0FBQztBQUFBLEVBQ2YsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixpQkFBaUIsQ0FBQztBQUFBLEVBQ2xCLGdCQUFnQixDQUFDO0FBQUEsRUFDakIsZ0JBQWdCO0FBQUEsRUFDaEIsbUJBQW1CO0FBQUEsRUFDbkIsbUJBQW1CO0FBQUEsRUFDbkIsbUJBQW1CO0FBQ3JCO0FBRUEsZUFBZSxPQUFxQyxLQUFrQztBQUNwRixRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEdBQUc7QUFDbEQsUUFBTSxRQUFRLE9BQU8sR0FBRztBQUN4QixNQUFJLFVBQVUsUUFBVztBQUN2QixXQUFPLGdCQUFnQixTQUFTLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBQ0EsU0FBTztBQUNUO0FBRUEsZUFBZSxPQUFxQyxLQUFRLE9BQXVDO0FBQ2pHLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsR0FBRyxHQUFHLE1BQU0sQ0FBQztBQUNsRDtBQUlBLGVBQXNCLGNBQWlDO0FBS3JELFFBQU0sU0FBUyxNQUFNLE9BQU8sVUFBVTtBQUN0QyxRQUFNLFNBQVMsRUFBRSxHQUFHLGtCQUFrQixHQUFHLE9BQU87QUFDaEQsTUFBSSxPQUFPLE9BQU8sZUFBZSxPQUFPLEdBQUcsR0FBRztBQUM1QyxRQUFJO0FBQ0YsYUFBTyxNQUFNLE1BQU0sV0FBVyxPQUFPLEdBQUc7QUFBQSxJQUMxQyxRQUFRO0FBQ04sYUFBTyxNQUFNO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixZQUFZLEdBQTRCO0FBRzVELFFBQU0sVUFBb0IsRUFBRSxHQUFHLEVBQUU7QUFDakMsTUFBSSxRQUFRLE9BQU8sQ0FBQyxlQUFlLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFlBQVEsTUFBTSxNQUFNLFdBQVcsUUFBUSxHQUFHO0FBQUEsRUFDNUM7QUFDQSxRQUFNLE9BQU8sWUFBWSxPQUFPO0FBQ2xDO0FBQ0EsZUFBc0IsZUFBZSxPQUE2QztBQUNoRixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sT0FBTyxFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEMsUUFBTSxZQUFZLElBQUk7QUFDdEIsU0FBTztBQUNUO0FBSUEsZUFBc0IsY0FBd0M7QUFDNUQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUFZLEdBQW1DO0FBQ25FLFFBQU0sT0FBTyxZQUFZLENBQUM7QUFDNUI7QUFDQSxlQUFzQix5QkFBaUQ7QUFDckUsU0FBTyxPQUFPLHFCQUFxQjtBQUNyQztBQUNBLGVBQXNCLHVCQUF1QixLQUFtQztBQUM5RSxRQUFNLE9BQU8sdUJBQXVCLEdBQUc7QUFDekM7QUFJQSxlQUFzQixxQkFBc0Q7QUFDMUUsU0FBTyxPQUFPLGlCQUFpQjtBQUNqQztBQUVBLGVBQXNCLG1CQUFtQixVQUFpRDtBQUN4RixRQUFNLE9BQU8sbUJBQW1CLFFBQVE7QUFDMUM7QUFJQSxlQUFzQixnQkFBMEM7QUFDOUQsUUFBTSxJQUFJLE1BQU0sT0FBTyxZQUFZO0FBRW5DLFFBQU0sTUFBdUI7QUFBQSxJQUMzQixHQUFHO0FBQUEsSUFDSCxlQUFlLEVBQUUsa0JBQWtCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDeEQsd0JBQ0UsRUFBRSwyQkFBMkIsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUNwRCxrQkFBa0IsRUFBRSxxQkFBcUIsU0FBWSxPQUFPLEVBQUU7QUFBQSxFQUNoRTtBQUNBLFNBQU87QUFDVDtBQUNBLGVBQXNCLGNBQWMsR0FBbUM7QUFDckUsUUFBTSxPQUFPLGNBQWMsQ0FBQztBQUM5QjtBQUlBLFNBQVMsV0FBbUI7QUFDMUIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQzdDO0FBRUEsZUFBc0IsY0FBdUQ7QUFDM0UsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFDQSxlQUFzQixZQUNwQixRQUNBLE9BQ3lCO0FBQ3pCLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsUUFBTSxNQUFNLElBQUksTUFBTSxLQUFLO0FBQUEsSUFDekIsWUFBWTtBQUFBLElBQ1osV0FBVyxTQUFTO0FBQUEsSUFDcEIsZUFBZTtBQUFBLElBQ2YsZ0JBQWdCO0FBQUEsSUFDaEIsZUFBZTtBQUFBLEVBQ2pCO0FBQ0EsTUFBSSxJQUFJLGNBQWMsU0FBUyxHQUFHO0FBQ2hDLFFBQUksWUFBWSxTQUFTO0FBQ3pCLFFBQUksYUFBYTtBQUFBLEVBQ25CO0FBQ0EsUUFBTSxPQUF1QixFQUFFLEdBQUcsS0FBSyxHQUFHLE1BQU07QUFDaEQsTUFBSSxNQUFNLElBQUk7QUFDZCxRQUFNLE9BQU8sWUFBWSxHQUFHO0FBQzVCLFNBQU87QUFDVDtBQUVBLGVBQXNCLGlCQUFpQixRQUFnQixPQUE4QjtBQUNuRixRQUFNLFlBQVksUUFBUSxFQUFFLGVBQWUsTUFBTSxDQUFDO0FBQ3BEO0FBSUEsZUFBc0IsZ0JBQW9EO0FBQ3hFLFNBQU8sT0FBTyxZQUFZO0FBQzVCO0FBRUEsZUFBc0IsYUFBYSxRQUEyQztBQUM1RSxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFNBQU8sSUFBSSxNQUFNLEtBQUs7QUFDeEI7QUFFQSxlQUFzQixhQUFhLFFBQWdCLEtBQStCO0FBQ2hGLFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsTUFBSSxNQUFNLElBQUk7QUFDZCxRQUFNLE9BQU8sY0FBYyxHQUFHO0FBQ2hDO0FBRUEsZUFBc0IsZUFBZSxRQUErQjtBQUNsRSxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFNBQU8sSUFBSSxNQUFNO0FBQ2pCLFFBQU0sT0FBTyxjQUFjLEdBQUc7QUFDaEM7QUFJQSxlQUFzQixjQUFtQztBQUN2RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQUVBLGVBQXNCLGVBQWUsSUFBbUM7QUFDdEUsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixNQUFJLFFBQVEsRUFBRTtBQUNkLE1BQUksSUFBSSxTQUFTLGtCQUFtQixLQUFJLFNBQVM7QUFDakQsUUFBTSxPQUFPLFlBQVksR0FBRztBQUM1QixTQUFPO0FBQ1Q7QUFFQSxlQUFzQixnQkFBK0I7QUFDbkQsUUFBTSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQzdCO0FBSUEsSUFBTSw2QkFBNkI7QUFFbkMsZUFBc0IsMEJBQW9EO0FBQ3hFLFNBQU8sT0FBTyxzQkFBc0I7QUFDdEM7QUFFQSxlQUFzQiw0QkFBNEIsTUFBc0M7QUFDdEYsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixRQUFNLE1BQU0sTUFBTSx3QkFBd0I7QUFDMUMsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxPQUF3QixDQUFDO0FBQy9CLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFVBQU0sTUFBTSxHQUFHLElBQUksZUFBZSxZQUFZLENBQUMsSUFBSSxJQUFJLFFBQVE7QUFDL0QsUUFBSSxLQUFLLElBQUksR0FBRyxFQUFHO0FBQ25CLFNBQUssSUFBSSxHQUFHO0FBQ1osU0FBSyxLQUFLLEdBQUc7QUFBQSxFQUNmO0FBQ0EsYUFBVyxPQUFPLEtBQUs7QUFDckIsVUFBTSxNQUFNLEdBQUcsSUFBSSxlQUFlLFlBQVksQ0FBQyxJQUFJLElBQUksUUFBUTtBQUMvRCxRQUFJLEtBQUssSUFBSSxHQUFHLEVBQUc7QUFDbkIsU0FBSyxJQUFJLEdBQUc7QUFDWixTQUFLLEtBQUssR0FBRztBQUFBLEVBQ2Y7QUFDQSxPQUFLLFNBQVMsS0FBSyxJQUFJLEtBQUssUUFBUSwwQkFBMEI7QUFDOUQsUUFBTSxPQUFPLHdCQUF3QixJQUFJO0FBQzNDO0FBSUEsZUFBc0Isb0JBQTZFO0FBQ2pHLFNBQU8sT0FBTyxnQkFBZ0I7QUFDaEM7QUFFQSxlQUFzQixrQkFDcEIsS0FDZTtBQUNmLFFBQU0sT0FBTyxrQkFBa0IsR0FBRztBQUNwQztBQVVPLFNBQVMsY0FDZCxPQUNBLFVBQ0EsU0FDQSxRQUNBLGNBQXVCLE9BQ2Y7QUFDUixTQUFPLEdBQUcsS0FBSyxJQUFJLFFBQVEsSUFBSSxPQUFPLElBQUksTUFBTSxJQUFJLGNBQWMsTUFBTSxHQUFHO0FBQzdFO0FBR0EsZUFBc0Isb0JBQW9CLFVBQW1DO0FBQzNFLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxRQUFNLFNBQVMsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUFJLFFBQVEsRUFBRSxZQUFZO0FBQzNELE1BQUksU0FBUztBQUNiLGFBQVcsVUFBVSxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ3JDLFVBQU0sUUFBUSxJQUFJLE1BQU07QUFDeEIsUUFBSSxDQUFDLE1BQU87QUFDWixlQUFXLE9BQU8sT0FBTyxLQUFLLEtBQUssR0FBRztBQUNwQyxZQUFNLElBQUksTUFBTSxHQUFHO0FBQ25CLFVBQUksS0FBSyxFQUFFLEtBQUssUUFBUTtBQUN0QixlQUFPLE1BQU0sR0FBRztBQUNoQixrQkFBVTtBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLEtBQUssS0FBSyxFQUFFLFdBQVcsRUFBRyxRQUFPLElBQUksTUFBTTtBQUFBLEVBQ3hEO0FBQ0EsTUFBSSxTQUFTLEVBQUcsT0FBTSxrQkFBa0IsR0FBRztBQUMzQyxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixrQkFBcUQ7QUFDekUsU0FBTyxPQUFPLGNBQWM7QUFDOUI7QUFFQSxlQUFzQixvQkFBcUM7QUFDekQsUUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixlQUFlLFFBQWdCLFNBQWdDO0FBQ25GLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxnQkFBZ0IsQ0FBQztBQUFBLEVBQ2hDO0FBQ0Y7QUFFQSxlQUFzQixlQUFlLFFBQWdCLFNBQWdDO0FBQ25GLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxRQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLE1BQUksQ0FBQyxJQUFLO0FBQ1YsUUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxNQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUNqQixRQUFNLE9BQU8sZ0JBQWdCLENBQUM7QUFDaEM7QUFFQSxlQUFzQixvQkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLHFCQUF3RDtBQUM1RSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBRUEsZUFBc0IsdUJBQXdDO0FBQzVELFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0Isa0JBQWtCLFlBQTJCLFNBQWdDO0FBQ2pHLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxRQUFNLFNBQVMsY0FBYztBQUM3QixRQUFNLE1BQU0sRUFBRSxNQUFNLEtBQUssQ0FBQztBQUMxQixNQUFJLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRztBQUMxQixRQUFJLEtBQUssT0FBTztBQUNoQixNQUFFLE1BQU0sSUFBSTtBQUNaLFVBQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUFBLEVBQ25DO0FBQ0Y7QUFFQSxlQUFzQixrQkFBa0IsU0FBZ0M7QUFDdEUsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksVUFBVTtBQUNkLGFBQVcsVUFBVSxPQUFPLEtBQUssQ0FBQyxHQUFHO0FBQ25DLFVBQU0sTUFBTSxFQUFFLE1BQU07QUFDcEIsUUFBSSxDQUFDLElBQUs7QUFDVixVQUFNLFdBQVcsSUFBSSxPQUFPLENBQUMsT0FBTyxPQUFPLE9BQU87QUFDbEQsUUFBSSxTQUFTLFdBQVcsSUFBSSxRQUFRO0FBQ2xDLGdCQUFVO0FBQ1YsVUFBSSxTQUFTLFdBQVcsRUFBRyxRQUFPLEVBQUUsTUFBTTtBQUFBLFVBQ3JDLEdBQUUsTUFBTSxJQUFJO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxRQUFTLE9BQU0sT0FBTyxtQkFBbUIsQ0FBQztBQUNoRDtBQUVBLGVBQXNCLHVCQUdaO0FBQ1IsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFFBQUksSUFBSSxTQUFTLEVBQUcsUUFBTyxFQUFFLFFBQVEsU0FBUyxJQUFJLENBQUMsRUFBRztBQUFBLEVBQ3hEO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0IscUJBQXdEO0FBQzVFLFNBQU8sT0FBTyxpQkFBaUI7QUFDakM7QUFFQSxlQUFzQix1QkFBd0M7QUFDNUQsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLE1BQUksUUFBUTtBQUNaLGFBQVcsT0FBTyxPQUFPLE9BQU8sQ0FBQyxFQUFHLFVBQVMsSUFBSTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxlQUFzQixrQkFBa0IsU0FBbUM7QUFDekUsUUFBTSxPQUFPLE1BQU0sT0FBTyxnQkFBZ0I7QUFDMUMsU0FBTyxXQUFXO0FBQ3BCO0FBRUEsZUFBc0IsbUJBQW1CLFNBQWdDO0FBQ3ZFLFFBQU0sT0FBTyxNQUFNLE9BQU8sZ0JBQWdCO0FBQzFDLE9BQUssT0FBTyxLQUFJLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ3ZDLFFBQU0sT0FBTyxrQkFBa0IsSUFBSTtBQUNyQztBQUVBLGVBQXNCLGtCQUFrQixRQUFnQixTQUFnQztBQUN0RixNQUFJLE1BQU0sa0JBQWtCLE9BQU8sRUFBRztBQUN0QyxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsUUFBTSxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDMUIsTUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUc7QUFDMUIsUUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBRSxNQUFNLElBQUk7QUFDWixVQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFBQSxFQUNuQztBQUNGO0FBRUEsZUFBc0Isa0JBQWtCLFNBQWdDO0FBQ3RFLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFVBQVU7QUFDZCxhQUFXLFVBQVUsT0FBTyxLQUFLLENBQUMsR0FBRztBQUNuQyxVQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsVUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELFFBQUksU0FBUyxXQUFXLElBQUksUUFBUTtBQUNsQyxnQkFBVTtBQUNWLFVBQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxVQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLE1BQUksUUFBUyxPQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFDaEQ7QUFFQSxlQUFzQix1QkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLFlBQVksU0FBbUM7QUFDbkUsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLGFBQVcsU0FBUyxPQUFPLE9BQU8sR0FBRyxHQUFHO0FBQ3RDLFFBQUksU0FBUyxXQUFXLE1BQU8sUUFBTztBQUFBLEVBQ3hDO0FBQ0EsU0FBTztBQUNUO0FBSUEsZUFBc0Isb0JBQWlEO0FBQ3JFLFNBQU8sT0FBTyxnQkFBZ0I7QUFDaEM7QUFDQSxlQUFzQixrQkFBa0IsR0FBc0M7QUFDNUUsUUFBTSxPQUFPLGtCQUFrQixDQUFDO0FBQ2xDO0FBQ0EsZUFBc0IsdUJBQW9EO0FBQ3hFLFNBQU8sT0FBTyxtQkFBbUI7QUFDbkM7QUFDQSxlQUFzQixxQkFBcUIsR0FBc0M7QUFDL0UsUUFBTSxPQUFPLHFCQUFxQixDQUFDO0FBQ3JDO0FBQ0EsZUFBc0IsdUJBQW9EO0FBQ3hFLFNBQU8sT0FBTyxtQkFBbUI7QUFDbkM7QUFDQSxlQUFzQixxQkFBcUIsR0FBc0M7QUFDL0UsUUFBTSxPQUFPLHFCQUFxQixDQUFDO0FBQ3JDO0FBQ0EsZUFBc0IsdUJBQTBEO0FBQzlFLFNBQU8sT0FBTyxtQkFBbUI7QUFDbkM7QUFDQSxlQUFzQixxQkFBcUIsR0FBNEM7QUFDckYsUUFBTSxPQUFPLHFCQUFxQixDQUFDO0FBQ3JDO0FBWUEsZUFBc0Isb0JBQW9CLFVBT3ZDO0FBQ0QsUUFBTSxZQUFZLElBQUksSUFBSSxDQUFDLEdBQUcsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDbkUsUUFBTSxhQUFhLENBQUMsTUFBdUIsVUFBVSxJQUFJLEVBQUUsWUFBWSxDQUFDO0FBR3hFLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxrQkFBa0I7QUFDdEIsYUFBVyxLQUFLLE9BQU8sS0FBSyxRQUFRLEdBQUc7QUFDckMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sU0FBUyxDQUFDO0FBQ2pCLHlCQUFtQjtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxZQUFZLFFBQVE7QUFHakMsUUFBTSxVQUFVLE1BQU0sY0FBYztBQUNwQyxNQUFJLGlCQUFpQjtBQUNyQixhQUFXLEtBQUssT0FBTyxLQUFLLE9BQU8sR0FBRztBQUNwQyxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUc7QUFDbEIsYUFBTyxRQUFRLENBQUM7QUFDaEIsd0JBQWtCO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLGNBQWMsT0FBTztBQUdsQyxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsTUFBSSwwQkFBMEI7QUFDOUIsYUFBVyxLQUFLLE9BQU8sS0FBSyxHQUFHLEdBQUc7QUFDaEMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sSUFBSSxDQUFDO0FBQ1osaUNBQTJCO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxrQkFBa0IsR0FBRztBQUczQixRQUFNLEtBQUssTUFBTSxnQkFBZ0I7QUFDakMsTUFBSSx3QkFBd0I7QUFDNUIsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sR0FBRyxDQUFDO0FBQ1gsK0JBQXlCO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLGdCQUFnQixFQUFFO0FBTS9CLFFBQU0sS0FBSyxNQUFNLG1CQUFtQjtBQUNwQyxNQUFJLHVCQUF1QjtBQUMzQixhQUFXLEtBQUssT0FBTyxLQUFLLEVBQUUsR0FBRztBQUMvQixRQUFJLE1BQU0sY0FBYyxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ3RDLCtCQUF5QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDdEMsYUFBTyxHQUFHLENBQUM7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxtQkFBbUIsRUFBRTtBQUVsQyxRQUFNLEtBQUssTUFBTSxtQkFBbUI7QUFDcEMsTUFBSSx1QkFBdUI7QUFDM0IsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLCtCQUF5QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDdEMsYUFBTyxHQUFHLENBQUM7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxtQkFBbUIsRUFBRTtBQUVsQyxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBSUEsZUFBc0IsV0FBMEI7QUFDOUMsUUFBTSxRQUFRLFFBQVEsTUFBTSxNQUFNO0FBQ3BDOzs7QUNscUJBLElBQUksWUFBNkM7QUFFMUMsU0FBUyxlQUFlLElBQWtDO0FBQy9ELGNBQVk7QUFDZDtBQUVBLFNBQVMsU0FBaUI7QUFDeEIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNoQztBQUVBLGVBQWUsS0FBSyxPQUFpQixLQUFhLFNBQWlEO0FBQ2pHLFFBQU0sS0FBZSxFQUFFLElBQUksT0FBTyxHQUFHLE9BQU8sS0FBSyxTQUFTLE9BQU8sT0FBTyxFQUFFO0FBRTFFLFFBQU0sT0FBTyxpQkFBaUIsTUFBTSxZQUFZLENBQUMsSUFBSSxHQUFHO0FBQ3hELE1BQUksVUFBVSxRQUFTLFNBQVEsTUFBTSxNQUFNLEdBQUcsT0FBTztBQUFBLFdBQzVDLFVBQVUsT0FBUSxTQUFRLEtBQUssTUFBTSxHQUFHLE9BQU87QUFBQSxNQUNuRCxTQUFRLElBQUksTUFBTSxHQUFHLE9BQU87QUFFakMsTUFBSTtBQUNGLFVBQU0sZUFBZSxFQUFFO0FBQUEsRUFDekIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDJDQUEyQyxHQUFHO0FBQUEsRUFDN0Q7QUFFQSxNQUFJO0FBQ0YsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCLFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUFFTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxNQUFNLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN2RixTQUFPLEtBQUssU0FBUyxLQUFLLE9BQU87QUFDbkM7QUFFTyxTQUFTLGNBQWMsS0FBeUQ7QUFDckYsTUFBSSxlQUFlLE9BQU87QUFDeEIsV0FBTyxFQUFFLFNBQVMsSUFBSSxTQUFTLE9BQU8sSUFBSSxTQUFTLEtBQUs7QUFBQSxFQUMxRDtBQUNBLE1BQUk7QUFDRixXQUFPLEVBQUUsU0FBUyxPQUFPLEdBQUcsR0FBRyxPQUFPLEtBQUs7QUFBQSxFQUM3QyxRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsdUJBQXVCLE9BQU8sS0FBSztBQUFBLEVBQ3ZEO0FBQ0Y7QUFPQSxTQUFTLE9BQU8sS0FBdUQ7QUFDckUsUUFBTSxNQUErQixDQUFDO0FBQ3RDLGFBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQ3hDLFFBQUksRUFBRSxZQUFZLEVBQUUsU0FBUyxPQUFPLEtBQUssRUFBRSxZQUFZLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtBQUMzRixVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1gsV0FBVyxPQUFPLE1BQU0sWUFBWSwrQkFBK0IsS0FBSyxDQUFDLEdBQUc7QUFDMUUsVUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLDZCQUE2Qix1QkFBdUI7QUFBQSxJQUN6RSxXQUFXLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxNQUFNO0FBQ25ELFVBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsSUFDOUIsT0FBTztBQUNMLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7OztBQ3ZFQSxJQUFNLFdBQVc7QUFDakIsSUFBTSxXQUFXO0FBK0JWLElBQU0sY0FBTixjQUEwQixNQUFNO0FBQUEsRUFDckM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBO0FBQUEsRUFFQSxZQUFZLE1BT1Q7QUFDRCxVQUFNLEtBQUssT0FBTztBQUNsQixTQUFLLE9BQU87QUFDWixTQUFLLFNBQVMsS0FBSztBQUNuQixTQUFLLE9BQU8sS0FBSztBQUNqQixTQUFLLFlBQVksS0FBSztBQUN0QixTQUFLLFdBQVcsS0FBSztBQUNyQixTQUFLLG1CQUFtQixLQUFLLG9CQUFvQjtBQUFBLEVBQ25EO0FBQ0Y7QUFFTyxJQUFNLGVBQU4sTUFBbUI7QUFBQSxFQUNQO0FBQUEsRUFFakIsWUFBWSxVQUFvQjtBQUM5QixTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBO0FBQUEsRUFHQSxNQUFNLFNBQTBCO0FBQzlCLFVBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDL0MsV0FBUSxJQUEyQixTQUFTO0FBQUEsRUFDOUM7QUFBQTtBQUFBLEVBR0EsTUFBTSxhQUFhLFFBQWtDO0FBQ25ELFFBQUk7QUFDRixZQUFNLEtBQUs7QUFBQSxRQUNUO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxtQkFBbUIsTUFBTSxDQUFDO0FBQUEsTUFDNUY7QUFDQSxhQUFPO0FBQUEsSUFDVCxTQUFTLEtBQUs7QUFDWixVQUFJLGVBQWUsZUFBZSxJQUFJLGFBQWEsWUFBYSxRQUFPO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFHQSxNQUFNLG1CQUEwRjtBQUM5RixVQUFNLEtBQUssTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQzlDLFVBQU0sT0FBTyxNQUFNLEtBQUssVUFBVSxPQUFPLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxFQUFFO0FBQzlGLFVBQU0sSUFBSTtBQUNWLFdBQU87QUFBQSxNQUNMLE9BQVEsR0FBeUI7QUFBQSxNQUNqQyxXQUFXLEVBQUU7QUFBQSxNQUNiLGdCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxvQkFBbUM7QUFDdkMsVUFBTSxPQUFPLE1BQU0sS0FBSyxjQUFjO0FBQ3RDLFVBQU0sS0FBSztBQUFBLE1BQ1Q7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxtQkFBbUIsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDdEc7QUFBQSxRQUNFLEtBQUssS0FBSztBQUFBLFFBQ1YsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLGFBQWEsWUFBNEM7QUFDN0QsVUFBTSxNQUFNLEdBQUcsUUFBUSxJQUFJLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFNBQVMsTUFBTSxJQUFJLFVBQVU7QUFDMUcsVUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDM0IsUUFBUTtBQUFBLE1BQ1IsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQUEsSUFDMUQsQ0FBQztBQUNELFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLFVBQVUsS0FBSyxXQUFXLFVBQVUsRUFBRTtBQUNwRSxXQUFPLElBQUksS0FBSztBQUFBLEVBQ2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sV0FBVyxNQUFzQztBQUNyRCxRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLFFBQ3JCO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQyxRQUFRLG1CQUFtQixLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDbEk7QUFDQSxZQUFNLElBQUk7QUFDVixhQUFPLEVBQUUsT0FBTztBQUFBLElBQ2xCLFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxRQUFRLE1BQThDO0FBQzFELFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sTUFBTSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQztBQUM1RixRQUFJLE1BQXFCLEtBQUssZUFBZTtBQUM3QyxVQUFNLGNBQWM7QUFFcEIsYUFBUyxVQUFVLEdBQUcsV0FBVyxhQUFhLFdBQVc7QUFDdkQsWUFBTSxPQUFnQztBQUFBLFFBQ3BDLFNBQVMsS0FBSztBQUFBLFFBQ2QsU0FBUyxLQUFLO0FBQUEsUUFDZCxRQUFRLEtBQUssU0FBUztBQUFBLE1BQ3hCO0FBQ0EsVUFBSSxJQUFLLE1BQUssTUFBTTtBQUNwQixVQUFJO0FBQ0YsY0FBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sS0FBSyxJQUFJO0FBQ2pELGNBQU0sTUFBTTtBQUNaLGVBQU8sRUFBRSxNQUFNLElBQUksUUFBUSxNQUFNLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLFFBQVEsU0FBUztBQUFBLE1BQ25GLFNBQVMsS0FBSztBQUNaLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFJLElBQUksV0FBVyxPQUFPLENBQUMsS0FBSztBQUU5QixnQkFBTSxNQUFNLEtBQUssV0FBVyxJQUFJO0FBQ2hDLGNBQUksQ0FBQyxJQUFLLE9BQU07QUFDaEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxDQUFDLElBQUksYUFBYSxZQUFZLFlBQWEsT0FBTTtBQUNyRCxjQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sSUFBSSxNQUFNLG1DQUFtQyxJQUFJLEVBQUU7QUFBQSxFQUMzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxNQUFNLFlBQVksTUFBc0Q7QUFDdEUsUUFBSSxLQUFLLE1BQU0sV0FBVyxFQUFHLE9BQU0sSUFBSSxNQUFNLGlDQUFpQztBQUM5RSxVQUFNLGNBQWM7QUFDcEIsUUFBSSxVQUFtQjtBQUV2QixhQUFTLFVBQVUsR0FBRyxXQUFXLGFBQWEsV0FBVztBQUN2RCxVQUFJO0FBQ0YsY0FBTSxRQUFRLE1BQU0sUUFBUTtBQUFBLFVBQzFCLEtBQUssTUFBTSxJQUFJLE9BQU8sU0FBUztBQUM3QixrQkFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLGNBQ3JCO0FBQUEsY0FDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxjQUNuRDtBQUFBLGdCQUNFLFNBQVMsS0FBSztBQUFBLGdCQUNkLFVBQVU7QUFBQSxjQUNaO0FBQUEsWUFDRjtBQUNBLG1CQUFPO0FBQUEsY0FDTCxNQUFNLEtBQUs7QUFBQSxjQUNYLEtBQU0sSUFBd0I7QUFBQSxZQUNoQztBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFFQSxjQUFNLE9BQU8sTUFBTSxLQUFLLGNBQWM7QUFDdEMsY0FBTSxPQUFPLE1BQU0sS0FBSztBQUFBLFVBQ3RCO0FBQUEsVUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxVQUNuRDtBQUFBLFlBQ0UsV0FBVyxLQUFLO0FBQUEsWUFDaEIsTUFBTSxNQUFNLElBQUksQ0FBQyxVQUFVO0FBQUEsY0FDekIsTUFBTSxLQUFLO0FBQUEsY0FDWCxNQUFNO0FBQUEsY0FDTixNQUFNO0FBQUEsY0FDTixLQUFLLEtBQUs7QUFBQSxZQUNaLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUNBLGNBQU0sVUFBVyxLQUF5QjtBQUMxQyxjQUFNLFNBQVMsTUFBTSxLQUFLO0FBQUEsVUFDeEI7QUFBQSxVQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLFVBQ25EO0FBQUEsWUFDRSxTQUFTLEtBQUs7QUFBQSxZQUNkLE1BQU07QUFBQSxZQUNOLFNBQVMsQ0FBQyxLQUFLLEdBQUc7QUFBQSxVQUNwQjtBQUFBLFFBQ0Y7QUFDQSxjQUFNLFlBQVk7QUFDbEIsWUFBSTtBQUNGLGdCQUFNLEtBQUs7QUFBQSxZQUNUO0FBQUEsWUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksbUJBQW1CLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLFlBQ3RHO0FBQUEsY0FDRSxLQUFLLFVBQVU7QUFBQSxjQUNmLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0YsU0FBUyxLQUFLO0FBQ1osY0FBSSxXQUFXLEdBQUcsS0FBSyxVQUFVLGFBQWE7QUFDNUMsc0JBQVU7QUFDVixrQkFBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFDbkM7QUFBQSxVQUNGO0FBQ0EsZ0JBQU07QUFBQSxRQUNSO0FBQ0EsZUFBTztBQUFBLFVBQ0wsV0FBVyxVQUFVO0FBQUEsVUFDckIsS0FBSyxVQUFVO0FBQUEsVUFDZixPQUFPLEtBQUssTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUk7QUFBQSxRQUMzQztBQUFBLE1BQ0YsU0FBUyxLQUFLO0FBQ1osa0JBQVU7QUFDVixZQUFJLEVBQUUsZUFBZSxhQUFjLE9BQU07QUFDekMsWUFBSyxDQUFDLElBQUksYUFBYSxDQUFDLFdBQVcsR0FBRyxLQUFNLFlBQVksWUFBYSxPQUFNO0FBQzNFLGNBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxtQkFBbUIsUUFBUSxVQUFVLElBQUksTUFBTSxpQ0FBaUM7QUFBQSxFQUN4RjtBQUFBLEVBRUEsTUFBYyxnQkFBMkQ7QUFDdkUsVUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLE1BQ3JCO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksa0JBQWtCLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLElBQ3ZHO0FBQ0EsVUFBTSxVQUFXLElBQW9DLE9BQU87QUFDNUQsVUFBTSxTQUFTLE1BQU0sS0FBSztBQUFBLE1BQ3hCO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksZ0JBQWdCLE9BQU87QUFBQSxJQUM1RTtBQUNBLFdBQU87QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLFNBQVUsT0FBcUMsS0FBSztBQUFBLElBQ3REO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBYyxVQUFVLFFBQWdCLE1BQWMsTUFBa0M7QUFDdEYsVUFBTSxNQUFNLEtBQUssV0FBVyxNQUFNLElBQUksT0FBTyxHQUFHLFFBQVEsR0FBRyxJQUFJO0FBQy9ELFVBQU0sT0FBb0I7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsU0FBUztBQUFBLFFBQ1AsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHO0FBQUEsUUFDMUMsUUFBUTtBQUFBLFFBQ1Isd0JBQXdCO0FBQUEsUUFDeEIsR0FBSSxPQUFPLEVBQUUsZ0JBQWdCLG1CQUFtQixJQUFJLENBQUM7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsR0FBSSxPQUFPLEVBQUUsTUFBTSxLQUFLLFVBQVUsSUFBSSxFQUFFLElBQUksQ0FBQztBQUFBLElBQy9DO0FBQ0EsUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLLElBQUk7QUFBQSxJQUM3QixTQUFTLFFBQVE7QUFDZixZQUFNLElBQUksWUFBWTtBQUFBLFFBQ3BCLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxRQUNOLFNBQVMsWUFBWSxjQUFjLE1BQU0sRUFBRSxPQUFPO0FBQUEsUUFDbEQsV0FBVztBQUFBLFFBQ1gsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFDQSxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxTQUFrQjtBQUN0QixVQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsUUFBSSxNQUFNO0FBQ1IsVUFBSTtBQUNGLGlCQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsTUFDMUIsUUFBUTtBQUNOLGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLG9CQUFvQixLQUFLLFFBQVEsR0FBRyxNQUFNLElBQUksSUFBSSxFQUFFO0FBQ2xGLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLFVBQVUsS0FBZSxPQUFxQztBQUMxRSxRQUFJLFNBQWtCO0FBQ3RCLFFBQUk7QUFDRixZQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsVUFBSSxLQUFNLFVBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxJQUNwQyxRQUFRO0FBQUEsSUFFUjtBQUNBLFdBQU8sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEtBQUs7QUFBQSxFQUNwRDtBQUFBLEVBRVEsb0JBQW9CLEtBQWUsTUFBZSxPQUE0QjtBQUNwRixVQUFNLE1BQ0osT0FBTyxTQUFTLFlBQVksUUFBUSxhQUFhLE9BQzdDLE9BQVEsS0FBOEIsT0FBTyxJQUM3QyxJQUFJO0FBQ1YsUUFBSSxXQUFvQztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUU1QyxZQUFNLE9BQU8sSUFBSSxRQUFRLElBQUksdUJBQXVCO0FBQ3BELFVBQUksU0FBUyxPQUFPLGNBQWMsS0FBSyxHQUFHLEdBQUc7QUFDM0MsbUJBQVc7QUFDWCxvQkFBWTtBQUFBLE1BQ2QsT0FBTztBQUNMLG1CQUFXO0FBQUEsTUFDYjtBQUFBLElBQ0YsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUNuRCxpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFVBQVUsS0FBSztBQUM1QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZCxXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkO0FBQ0EsV0FBTyxJQUFJLFlBQVk7QUFBQSxNQUNyQixRQUFRLElBQUk7QUFBQSxNQUNaO0FBQUEsTUFDQSxTQUFTLEdBQUcsS0FBSyxXQUFNLElBQUksTUFBTSxLQUFLLEdBQUc7QUFBQSxNQUN6QztBQUFBLE1BQ0E7QUFBQSxNQUNBLGtCQUFrQixhQUFhLGVBQWUsb0JBQW9CLElBQUksT0FBTyxJQUFJO0FBQUEsSUFDbkYsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQVFBLFNBQVMsb0JBQW9CLFNBQWlDO0FBQzVELFFBQU0sUUFBUSxRQUFRLElBQUksbUJBQW1CO0FBQzdDLE1BQUksT0FBTztBQUNULFVBQU0sSUFBSSxPQUFPLFNBQVMsT0FBTyxFQUFFO0FBQ25DLFFBQUksT0FBTyxTQUFTLENBQUMsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUFBLEVBQzFDO0FBQ0EsUUFBTSxhQUFhLFFBQVEsSUFBSSxhQUFhO0FBQzVDLE1BQUksWUFBWTtBQUNkLFVBQU0sUUFBUSxPQUFPLFNBQVMsWUFBWSxFQUFFO0FBQzVDLFFBQUksT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLEdBQUc7QUFDeEMsYUFBTyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSSxJQUFJO0FBQUEsSUFDekM7QUFDQSxVQUFNLFNBQVMsS0FBSyxNQUFNLFVBQVU7QUFDcEMsUUFBSSxPQUFPLFNBQVMsTUFBTSxFQUFHLFFBQU8sS0FBSyxNQUFNLFNBQVMsR0FBSTtBQUFBLEVBQzlEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLE1BQXNCO0FBRXhDLFNBQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJLGtCQUFrQixFQUFFLEtBQUssR0FBRztBQUN6RDtBQUVBLFNBQVMsVUFBVSxTQUFpQixLQUEwQjtBQUU1RCxRQUFNLE9BQU8sSUFBSSxhQUFhLGVBQWUsTUFBTztBQUNwRCxRQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQUc7QUFDN0MsU0FBTyxLQUFLLElBQUksS0FBUSxPQUFPLE1BQU0sVUFBVSxLQUFLLE1BQU07QUFDNUQ7QUFFQSxTQUFTLFdBQVcsS0FBa0M7QUFDcEQsU0FBTyxlQUFlLGVBQWUsSUFBSSxhQUFhO0FBQ3hEO0FBRUEsU0FBUyxNQUFNLElBQTJCO0FBQ3hDLFNBQU8sSUFBSSxRQUFRLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQzdDO0FBRU8sU0FBU0EsVUFBUyxPQUF1QjtBQUU5QyxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxLQUFLO0FBQzNDLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLFFBQU8sT0FBTyxhQUFhLENBQUM7QUFDbEQsU0FBTyxLQUFLLEdBQUc7QUFDakI7OztBQzNYQSxJQUFNLGNBQWM7QUFTcEIsSUFBTSx1QkFBNEMsb0JBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUVoRSxTQUFTLFVBQVUsU0FBa0IsS0FBd0M7QUFDbEYsUUFBTSxZQUFZLGNBQWMsT0FBTztBQUN2QyxRQUFNLFNBQTJCLENBQUM7QUFDbEMsUUFBTSxvQkFBd0MsQ0FBQztBQUMvQyxRQUFNLFdBQXFCLENBQUM7QUFDNUIsUUFBTSxRQUFRLG9CQUFJLElBQVk7QUFDOUIsUUFBTSxhQUFhLG9CQUFJLElBQTJCO0FBQ2xELFFBQU0sa0JBQWtCLHFCQUFxQixJQUFJLElBQUksUUFBUTtBQUM3RCxhQUFXLE9BQU8sV0FBVztBQUMzQixRQUFJO0FBQ0YsWUFBTSxjQUFjLHFCQUFxQixLQUFLLEdBQUc7QUFDakQsVUFBSSxhQUFhO0FBQ2YsMEJBQWtCLEtBQUssV0FBVztBQUNsQyxpQkFBUyxLQUFLLFlBQVksUUFBUTtBQUNsQyxjQUFNLElBQUksWUFBWSxRQUFRO0FBQzlCO0FBQUEsTUFDRjtBQUNBLFlBQU0sSUFBSSxXQUFXLEtBQUssR0FBRztBQUM3QixVQUFJLENBQUMsR0FBRztBQUNOLFlBQUksaUJBQWlCO0FBSW5CLGdCQUFNLFVBQVUsWUFBWSxHQUFHO0FBQy9CLGNBQUksUUFBUyxZQUFXLElBQUksUUFBUSxVQUFVLFFBQVEsV0FBVztBQUFBLFFBQ25FO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsZUFBUyxLQUFLLEVBQUUsUUFBUTtBQUN4QixZQUFNLElBQUksRUFBRSxRQUFRO0FBQ3BCLFVBQUksSUFBSSxlQUFlLFNBQVMsS0FBSyxJQUFJLGVBQWUsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEdBQUc7QUFDM0YsZUFBTyxLQUFLLENBQUM7QUFBQSxNQUNmO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFHQSxRQUFNLGNBQXVFLENBQUM7QUFDOUUsYUFBVyxDQUFDLElBQUksSUFBSSxLQUFLLFlBQVk7QUFDbkMsUUFBSSxNQUFNLElBQUksRUFBRSxFQUFHO0FBQ25CLGdCQUFZLEtBQUssRUFBRSxVQUFVLElBQUksYUFBYSxLQUFLLENBQUM7QUFBQSxFQUN0RDtBQUNBLFNBQU8sRUFBRSxRQUFRLGNBQWMsVUFBVSxvQkFBb0IsbUJBQW1CLFlBQVk7QUFDOUY7QUFFQSxTQUFTLHFCQUFxQixNQUFlLEtBQWdEO0FBQzNGLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFFOUMsUUFBTSxVQUNKLFVBQVUsRUFBRSxPQUFPLEtBQ25CLG9CQUFvQixJQUFJLE1BQ3ZCLElBQUksWUFBWSxvQkFBb0IsSUFBSSxTQUFTLElBQUk7QUFDeEQsTUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEtBQUssT0FBTyxFQUFHLFFBQU87QUFFbkQsUUFBTSxrQkFBa0Isa0JBQWtCLElBQUk7QUFDOUMsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsZ0JBQ0Usd0JBQXdCLE1BQU0sT0FBTyxNQUNwQyxJQUFJLFlBQVksbUJBQW1CLElBQUksV0FBVyxPQUFPLElBQUk7QUFBQSxJQUNoRSx5QkFBeUIsSUFBSTtBQUFBLElBQzdCLG9CQUFvQiwwQkFBMEIsZUFBZTtBQUFBLElBQzdELGtCQUFrQjtBQUFBLElBQ2xCLHdCQUF3QixJQUFJLGFBQWE7QUFBQSxFQUMzQztBQUNGO0FBRUEsU0FBUyxvQkFBb0IsTUFBOEI7QUFDekQsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sS0FBSyxvQkFBb0IsR0FBRztBQUNsQyxVQUFJLEdBQUksUUFBTztBQUNmO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLG9CQUFvQixRQUErQjtBQUMxRCxNQUFJO0FBQ0YsVUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLGdCQUFnQjtBQUM1QyxRQUFJLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxjQUFlLFFBQU87QUFDdkUsVUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLG9EQUFvRDtBQUNyRixXQUFPLFFBQVEsQ0FBQyxLQUFLO0FBQUEsRUFDdkIsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixNQUE4QjtBQUN2RCxRQUFNLFVBQW9CLENBQUM7QUFDM0IsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sVUFBVSxJQUFJLEtBQUs7QUFDekIsVUFDRSxRQUFRLFVBQVUsS0FDbEIsQ0FBQyxRQUFRLFdBQVcsU0FBUyxLQUM3QixDQUFDLFFBQVEsV0FBVyxVQUFVLEdBQzlCO0FBQ0EsZ0JBQVEsS0FBSyxPQUFPO0FBQUEsTUFDdEI7QUFDQTtBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVTtBQUM3QyxRQUFJLEtBQUssSUFBSSxHQUFhLEVBQUc7QUFDN0IsU0FBSyxJQUFJLEdBQWE7QUFDdEIsUUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQ3RCLGlCQUFXLEtBQUssSUFBSyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ25DLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxHQUE4QixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDN0U7QUFBQSxFQUNGO0FBQ0EsUUFBTSxZQUFZLFFBQVE7QUFBQSxJQUFLLENBQUMsTUFDOUIsOEVBQThFLEtBQUssQ0FBQztBQUFBLEVBQ3RGO0FBQ0EsU0FBTyxhQUFhLFFBQVEsQ0FBQyxLQUFLO0FBQ3BDO0FBRUEsU0FBUywwQkFBMEIsTUFBb0M7QUFDckUsTUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixNQUFJLHdCQUF3QixLQUFLLElBQUksRUFBRyxRQUFPO0FBQy9DLE1BQUksZ0JBQWdCLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDdkMsTUFBSSx1QkFBdUIsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUM5QyxNQUFJLGlCQUFpQixLQUFLLElBQUksRUFBRyxRQUFPO0FBQ3hDLE1BQUksaUNBQWlDLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDeEQsU0FBTztBQUNUO0FBRUEsU0FBUyxZQUFZLE1BQXdFO0FBQzNGLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBR1YsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFHOUMsUUFBTSxLQUFLLEVBQUU7QUFDYixNQUFJLE9BQU8sV0FBVyxPQUFPLGdDQUFnQyxDQUFDLElBQUksRUFBRSxNQUFNLEdBQUc7QUFDM0UsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLFNBQ0gsT0FBTyxFQUFFLFlBQVksWUFBWSxFQUFFLFdBQ25DLE9BQU8sSUFBSSxFQUFFLFlBQVksR0FBRyxXQUFXLFlBQ3JDLElBQUksSUFBSSxFQUFFLFlBQVksR0FBRyxNQUFNLEdBQUc7QUFDdkMsTUFBSSxPQUFPLFdBQVcsWUFBWSxDQUFDLFlBQVksS0FBSyxNQUFNLEVBQUcsUUFBTztBQUNwRSxRQUFNLGFBQWEsZUFBZSxNQUFNLE1BQU07QUFDOUMsTUFBSSxDQUFDLFdBQVksUUFBTztBQUN4QixTQUFPLEVBQUUsVUFBVSxRQUFRLGFBQWEsV0FBVztBQUNyRDtBQUVBLFNBQVMsZUFBZSxNQUFlLFNBQWdDO0FBQ3JFLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsUUFBTSxhQUFhLElBQUksSUFBSSxJQUFJLEVBQUUsSUFBSSxHQUFHLFlBQVksR0FBRyxNQUFNO0FBQzdELFNBQ0UsVUFBVSxJQUFJLFlBQVksSUFBSSxHQUFHLFdBQVcsS0FDNUMsVUFBVSxJQUFJLFlBQVksTUFBTSxHQUFHLFdBQVcsS0FDOUMsVUFBVSxJQUFJLEVBQUUsTUFBTSxHQUFHLFdBQVcsS0FDcEMsd0JBQXdCLE1BQU0sT0FBTztBQUV6QztBQUVBLFNBQVMsd0JBQXdCLE1BQWUsU0FBZ0M7QUFDOUUsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sU0FBUyxtQkFBbUIsS0FBSyxPQUFPO0FBQzlDLFVBQUksT0FBUSxRQUFPO0FBQ25CO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLG1CQUFtQixRQUFnQixTQUFnQztBQUMxRSxNQUFJO0FBQ0YsVUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLGdCQUFnQjtBQUM1QyxRQUFJLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxjQUFlLFFBQU87QUFDdkUsVUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLHNEQUFzRDtBQUN2RixRQUFJLENBQUMsU0FBUyxNQUFNLENBQUMsTUFBTSxRQUFTLFFBQU87QUFDM0MsV0FBTyxNQUFNLENBQUMsS0FBSztBQUFBLEVBQ3JCLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxjQUFjQyxNQUF5QjtBQUs5QyxRQUFNLE1BQWlCLENBQUM7QUFDeEIsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQ0EsSUFBRztBQUM3QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sT0FBTyxNQUFNLElBQUk7QUFDdkIsUUFBSSxTQUFTLFFBQVEsU0FBUyxPQUFXO0FBQ3pDLFFBQUksT0FBTyxTQUFTLFNBQVU7QUFDOUIsUUFBSSxLQUFLLElBQUksSUFBYyxFQUFHO0FBQzlCLFNBQUssSUFBSSxJQUFjO0FBRXZCLFFBQUksZUFBZSxJQUFJLEdBQUc7QUFDeEIsVUFBSSxLQUFLLFlBQVksSUFBSSxDQUFDO0FBQUEsSUFDNUI7QUFDQSxRQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDdkIsaUJBQVcsS0FBSyxLQUFNLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDcEMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLElBQStCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM5RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGVBQWUsTUFBZ0Q7QUFDdEUsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLFdBQVcsRUFBRTtBQUNuQixNQUNFLGFBQWEsV0FDYixhQUFhLGdDQUNiLGFBQWEsa0JBQ2I7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQU8sT0FBTyxFQUFFLFlBQVksWUFBWSxPQUFPLEVBQUUsV0FBVyxZQUFZLEVBQUUsV0FBVztBQUN2RjtBQUVBLFNBQVMsWUFBWSxNQUF3RDtBQUMzRSxNQUFJLEtBQUssZUFBZSxnQ0FBZ0MsT0FBTyxLQUFLLFVBQVUsVUFBVTtBQUN0RixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLEtBQWMsS0FBOEM7QUFDOUUsTUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLEtBQU0sUUFBTztBQUNwRCxRQUFNLElBQUk7QUFFVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUU5QyxRQUFNLFNBQVMsVUFBVSxFQUFFLE9BQU87QUFLbEMsUUFBTSxTQUFTLElBQUksRUFBRSxNQUFNLEtBQUssQ0FBQztBQUNqQyxNQUFJLENBQUMsT0FBUSxRQUFPO0FBRXBCLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxJQUFJLE1BQU0sWUFBWSxHQUFHLE1BQU07QUFHdEQsUUFBTSxjQUFjLElBQUksWUFBWSxJQUFJO0FBQ3hDLFFBQU0sYUFBYSxJQUFJLFlBQVksTUFBTTtBQUN6QyxRQUFNLGdCQUFnQixJQUFJLFlBQVksTUFBTTtBQUM1QyxRQUFNLFNBQ0osVUFBVSxhQUFhLFdBQVcsS0FDbEMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxPQUFPLFdBQVc7QUFDOUIsUUFBTSxZQUNKLFVBQVUsWUFBWSxPQUFPLEtBQzdCLFVBQVUsWUFBWSxNQUFNLEtBQzVCLFVBQVUsT0FBTyxXQUFXO0FBQzlCLE1BQUksQ0FBQyxVQUFVLENBQUMsVUFBVyxRQUFPO0FBTWxDLFFBQU0sU0FBUyxvQkFBb0IsWUFBWSxhQUFhLFlBQVksYUFBYTtBQUVyRixRQUFNLFlBQVksSUFBSSxJQUFJLElBQUksRUFBRSxVQUFVLEdBQUcsa0JBQWtCLEdBQUcsTUFBTTtBQUN4RSxRQUFNLGVBQWUsVUFBVSxXQUFXLElBQUk7QUFDOUMsUUFBTSxpQkFBaUIsVUFBVSxPQUFPLFNBQVMsS0FBSztBQUN0RCxRQUFNLE9BQU8sZ0JBQWdCO0FBQzdCLFFBQU0sY0FBYyxpQkFBaUIsV0FBVyxRQUFRLGNBQWM7QUFDdEUsUUFBTSxnQkFBZ0IscUJBQXFCLEdBQUcsUUFBUSxJQUFJLFVBQVU7QUFFcEUsUUFBTSxXQUFXLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQztBQUMxQyxRQUFNLG1CQUFtQixJQUFJLFdBQVcsVUFBVTtBQUNsRCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxPQUFPLFlBQVksb0JBQW9CLFFBQVE7QUFDckQsUUFBTSxRQUFRLGFBQWEsTUFBTTtBQUVqQyxRQUFNLFlBQVksa0JBQWtCLEdBQUcsTUFBTTtBQU03QyxRQUFNLGtCQUFrQixJQUFJLElBQUksSUFBSSxPQUFPLHVCQUF1QixHQUFHLE1BQU0sR0FBRyxNQUFNO0FBQ3BGLFFBQU0sWUFBWSxjQUFjLGFBQWEsa0JBQWtCLGtCQUFrQjtBQUlqRixRQUFNLFdBQ0osaUJBQWlCLFVBQVUsT0FBTyxVQUFVLENBQUMsS0FBSyxpQkFBaUIsVUFBVSxFQUFFLFVBQVUsQ0FBQztBQUM1RixNQUFJLENBQUMsU0FBVSxRQUFPO0FBRXRCLFFBQU0sUUFBUSxJQUFJLEVBQUUsS0FBSztBQUN6QixRQUFNLFlBQVksVUFBVSxPQUFPLEtBQUssS0FBSyxVQUFVLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFFOUUsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUMxQixRQUFNLFFBQVEsSUFBSSxPQUFPLEtBQUs7QUFFOUIsUUFBTSxRQUF3QjtBQUFBLElBQzVCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLFdBQVc7QUFBQSxJQUNYLG1CQUFtQixJQUFJO0FBQUEsSUFDdkIsY0FBYyxJQUFJO0FBQUEsSUFDbEIsc0JBQXNCO0FBQUEsSUFDdEIseUJBQXlCO0FBQUEsSUFDekIsb0JBQW9CO0FBQUEsSUFDcEIsa0JBQWtCO0FBQUEsSUFDbEIsd0JBQXdCO0FBQUEsSUFDeEIsV0FBVyxHQUFHLGdCQUFnQixJQUFJLE1BQU0sV0FBVyxNQUFNO0FBQUEsSUFDekQsWUFBWTtBQUFBLElBQ1osaUJBQWlCLFVBQVUsT0FBTyxtQkFBbUI7QUFBQSxJQUNyRCxtQkFBbUIsVUFBVSxPQUFPLHlCQUF5QjtBQUFBLElBQzdELGtCQUFrQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDMUQscUJBQXFCLFVBQVUsT0FBTyx1QkFBdUI7QUFBQSxJQUM3RCxpQkFBaUIsVUFBVSxPQUFPLG9CQUFvQjtBQUFBLElBQ3RELG9CQUFvQjtBQUFBLE1BQ2xCLElBQUksSUFBSSxPQUFPLHVCQUF1QixHQUFHLE1BQU0sR0FBRyxXQUMvQyxPQUFtQztBQUFBLElBQ3hDO0FBQUEsSUFDQTtBQUFBLElBQ0EsZUFBZSxpQkFBaUIsTUFBTSxJQUFJO0FBQUEsSUFDMUMsTUFBTSxVQUFVLE9BQU8sSUFBSTtBQUFBLElBQzNCLG9CQUFvQixXQUFXLE9BQU8sa0JBQWtCO0FBQUEsSUFDeEQsUUFBUSxVQUFVLE9BQU8sTUFBTSxLQUFLLFVBQVUsRUFBRSxNQUFNO0FBQUEsSUFDdEQsaUJBQWlCLFVBQVUsT0FBTyxTQUFTO0FBQUEsSUFDM0M7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZLFVBQVUsVUFBVSxjQUFjO0FBQUEsSUFDOUMsZUFBZSxVQUFVLE9BQU8sYUFBYTtBQUFBLElBQzdDLGFBQWEsVUFBVSxVQUFVLFdBQVc7QUFBQSxJQUM1QyxhQUFhLFVBQVUsVUFBVSxXQUFXO0FBQUEsSUFDNUMsWUFBWTtBQUFBLElBQ1osZ0JBQWdCLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDL0Msb0JBQW9CO0FBQUEsTUFDbEI7QUFBQSxRQUNFLGFBQWEsSUFBSTtBQUFBLFFBQ2pCLE9BQU8sVUFBVSxVQUFVLGNBQWM7QUFBQSxRQUN6QyxVQUFVLFVBQVUsT0FBTyxhQUFhO0FBQUEsUUFDeEMsU0FBUyxVQUFVLFVBQVUsV0FBVztBQUFBLFFBQ3hDLFFBQVEsVUFBVSxVQUFVLFdBQVc7QUFBQSxRQUN2QyxPQUFPO0FBQUEsUUFDUCxXQUFXLFVBQVUsT0FBTyxjQUFjO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLElBQ0EsZ0JBQWdCO0FBQUEsSUFDaEIsY0FBYztBQUFBLElBQ2QsYUFBYTtBQUFBLElBQ2Isc0JBQXNCO0FBQUEsSUFDdEIsZ0JBQWdCO0FBQUEsSUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxJQUNwQixnQkFBZ0I7QUFBQSxFQUNsQjtBQUVBLFNBQU87QUFDVDtBQUVBLFNBQVMsa0JBQWtCLEdBQTRCLFFBQTRDO0FBQ2pHLE1BQUksT0FBTywyQkFBMkIsT0FBTyx3QkFBeUIsUUFBTztBQUM3RSxNQUFJLE9BQU8sMEJBQTJCLFFBQU87QUFDN0MsTUFBSSxPQUFPLG9CQUFvQixRQUFRLE9BQU8scUJBQXNCLFFBQU87QUFDM0UsTUFBSSxFQUFFLGVBQWUsOEJBQThCO0FBQUEsRUFFbkQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxVQUFVLElBQUksT0FBUSxFQUF3QixJQUFJLElBQUk7QUFBQSxFQUN0RixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixJQUMzQyxPQUFRLEVBQStCLFdBQVcsSUFDbEQ7QUFBQSxFQUNOLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxZQUFZLFVBQWdEO0FBQ25FLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxRQUFNLE1BQW1CLENBQUM7QUFDMUIsYUFBVyxLQUFLLEtBQUs7QUFDbkIsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU07QUFDekMsVUFBTSxJQUFJO0FBQ1YsVUFBTSxRQUFRLFVBQVUsRUFBRSxHQUFHO0FBQzdCLFVBQU0sV0FBVyxVQUFVLEVBQUUsWUFBWTtBQUN6QyxVQUFNLFVBQVUsVUFBVSxFQUFFLFdBQVc7QUFDdkMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFVO0FBQ3pCLFFBQUksS0FBSyxFQUFFLE9BQU8sVUFBVSxTQUFTLFdBQVcsU0FBUyxDQUFDO0FBQUEsRUFDNUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGFBQWEsUUFBOEM7QUFDbEUsUUFBTSxXQUFXLElBQUksT0FBTyxpQkFBaUI7QUFDN0MsUUFBTSxVQUFVLFdBQVcsUUFBUSxTQUFTLEtBQUssSUFBSSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxRQUFRLElBQUksT0FBTyxRQUFRLEdBQUcsS0FBSztBQUNuRCxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFNBQVMsQ0FBQyxHQUFHLFNBQVMsR0FBRyxPQUFPLEVBQUUsT0FBTyxDQUFDLE1BQU07QUFDcEQsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU0sUUFBTztBQUNoRCxVQUFNLEtBQ0osVUFBVyxFQUE4QixTQUFTLEtBQ2xELFVBQVcsRUFBOEIsTUFBTTtBQUNqRCxRQUFJLENBQUMsR0FBSSxRQUFPO0FBQ2hCLFFBQUksS0FBSyxJQUFJLEVBQUUsRUFBRyxRQUFPO0FBQ3pCLFNBQUssSUFBSSxFQUFFO0FBQ1gsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNELFNBQU8sT0FBTyxJQUFJLENBQUMsUUFBUSxXQUFXLEdBQThCLENBQUM7QUFDdkU7QUFFQSxTQUFTLFdBQVcsR0FBdUM7QUFDekQsUUFBTSxPQUFPLFVBQVUsRUFBRSxJQUFJO0FBQzdCLFFBQU0sV0FBVyxnQkFBZ0IsR0FBRyxJQUFJO0FBQ3hDLFFBQU1DLFFBQU8sSUFBSSxFQUFFLGFBQWE7QUFDaEMsUUFBTSxZQUFZLElBQUksRUFBRSxVQUFVO0FBQ2xDLFFBQU0sYUFBYSxVQUFVLFdBQVcsZUFBZTtBQUN2RCxRQUFNLFVBQVUsVUFBVSxFQUFFLFlBQVk7QUFDeEMsUUFBTSxVQUNKLFVBQVUsRUFBRSxTQUFTLEtBQ3JCLFVBQVUsRUFBRSxNQUFNLEtBQ2xCLEdBQUcsUUFBUSxPQUFPLElBQUksS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDM0QsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsWUFBYSxRQUFRO0FBQUEsSUFDckIsY0FBYyxZQUFZO0FBQUEsSUFDMUIsbUJBQW1CO0FBQUEsSUFDbkIsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsY0FBYyxlQUFlLE9BQU8sYUFBYSxNQUFPO0FBQUEsSUFDeEQsT0FBTyxVQUFVQSxPQUFNLEtBQUs7QUFBQSxJQUM1QixRQUFRLFVBQVVBLE9BQU0sTUFBTTtBQUFBLElBQzlCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLGtCQUFrQjtBQUFBLElBQ2xCLGlCQUFpQjtBQUFBLEVBQ25CO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixHQUE0QixNQUFvQztBQUN2RixNQUFJLFNBQVMsUUFBUyxRQUFPLFVBQVUsRUFBRSxlQUFlLEtBQUssVUFBVSxFQUFFLFNBQVM7QUFDbEYsUUFBTSxXQUFXLFFBQVEsSUFBSSxFQUFFLFVBQVUsR0FBRyxRQUFRO0FBQ3BELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxVQUFVLEVBQUUsZUFBZTtBQUU3RCxNQUFJLE9BQWdEO0FBQ3BELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sS0FBSyxVQUFVLEVBQUUsWUFBWTtBQUNuQyxVQUFNLE1BQU0sVUFBVSxFQUFFLEdBQUc7QUFDM0IsUUFBSSxDQUFDLElBQUs7QUFDVixRQUFJLE9BQU8sYUFBYTtBQUN0QixZQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sS0FBSztBQUNuQyxVQUFJLENBQUMsUUFBUSxLQUFLLEtBQUssUUFBUyxRQUFPLEVBQUUsS0FBSyxTQUFTLEdBQUc7QUFBQSxJQUM1RCxXQUFXLENBQUMsTUFBTTtBQUVoQixhQUFPLEVBQUUsS0FBSyxTQUFTLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLE1BQU0sT0FBTztBQUN0QjtBQUVBLFNBQVMsaUJBQWlCLE1BQWMsTUFBMkI7QUFDakUsTUFBSSxLQUFLLFdBQVcsRUFBRyxRQUFPO0FBQzlCLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLE9BQU0sSUFBSSxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRO0FBQzlELFNBQU87QUFDVDtBQUVBLFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELE1BQUksQ0FBQyxFQUFHLFFBQU87QUFFZixRQUFNLElBQUksSUFBSSxLQUFLLENBQUM7QUFDcEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPO0FBQ3RDLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLFNBQU8sT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLElBQUksSUFBSTtBQUNyRDtBQUNBLFNBQVMsV0FBVyxHQUE0QjtBQUM5QyxTQUFPLE9BQU8sTUFBTSxZQUFZLElBQUk7QUFDdEM7QUFDQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFDeEQsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxVQUFNLElBQUksT0FBTyxDQUFDO0FBQ2xCLFFBQUksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQUEsRUFDakM7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFVBQVUsR0FBb0I7QUFDckMsU0FBTyxVQUFVLENBQUMsS0FBSztBQUN6QjtBQUNBLFNBQVMsSUFBSSxHQUE0QztBQUN2RCxTQUFPLE9BQU8sTUFBTSxZQUFZLE1BQU0sUUFBUSxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQ3pELElBQ0Q7QUFDTjtBQUNBLFNBQVMsUUFBUSxHQUF1QjtBQUN0QyxTQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDO0FBQ2pDO0FBd0JBLFNBQVMsaUJBQ1AsV0FDQSxRQUNBLFVBQ1M7QUFDVCxNQUFJLFVBQVcsUUFBTztBQUN0QixNQUFJLENBQUMsU0FBVSxRQUFPO0FBQ3RCLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUTtBQUNwQyxRQUFNLE9BQU8sV0FBVyxTQUFTLE9BQU87QUFDeEMsTUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGVBQVcsS0FBSyxNQUFNO0FBQ3BCLFVBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFlBQU0sTUFBTyxFQUE4QjtBQUkzQyxVQUFJLE9BQU8sUUFBUSxZQUFZLHdCQUF3QixLQUFLLEdBQUcsR0FBRztBQUNoRSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBd0JPLFNBQVMsY0FDZCxRQUNBLFVBQ0EsY0FBbUMsb0JBQUksSUFBSSxHQUN6QjtBQUNsQixNQUFJLFNBQVMsU0FBUyxLQUFLLFlBQVksU0FBUyxFQUFHLFFBQU87QUFLMUQsUUFBTSxnQkFBZ0Isb0JBQUksSUFBWTtBQUN0QyxRQUFNLG1CQUFtQixvQkFBSSxJQUFZO0FBQ3pDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxFQUFHO0FBQ25ELHFCQUFpQixJQUFJLEVBQUUsUUFBUTtBQUMvQixRQUFJLEVBQUUsZ0JBQWlCLGVBQWMsSUFBSSxFQUFFLGVBQWU7QUFDMUQsUUFBSSxFQUFFLG1CQUFvQixlQUFjLElBQUksRUFBRSxrQkFBa0I7QUFDaEUsUUFBSSxFQUFFLGtCQUFtQixlQUFjLElBQUksRUFBRSxpQkFBaUI7QUFBQSxFQUNoRTtBQUNBLFNBQU8sT0FBTyxPQUFPLENBQUMsTUFBTTtBQUMxQixVQUFNLElBQUksRUFBRSxlQUFlLFlBQVk7QUFDdkMsUUFBSSxTQUFTLElBQUksQ0FBQyxFQUFHLFFBQU87QUFDNUIsUUFBSSxZQUFZLElBQUksQ0FBQyxFQUFHLFFBQU87QUFFL0IsUUFBSSxjQUFjLElBQUksRUFBRSxRQUFRLEVBQUcsUUFBTztBQUkxQyxRQUFJLEVBQUUsbUJBQW1CLGlCQUFpQixJQUFJLEVBQUUsZUFBZSxFQUFHLFFBQU87QUFDekUsUUFBSSxFQUFFLHFCQUFxQixpQkFBaUIsSUFBSSxFQUFFLGlCQUFpQixFQUFHLFFBQU87QUFFN0UsUUFBSSxFQUFFLG9CQUFvQixTQUFTLElBQUksRUFBRSxpQkFBaUIsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUNqRixlQUFXLEtBQUssRUFBRSxVQUFVO0FBQzFCLFVBQUksU0FBUyxJQUFJLEVBQUUsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUFBLElBQzVDO0FBQ0EsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNIO0FBU0EsU0FBUyxxQkFDUCxHQUNBLFFBQ0EsWUFDc0I7QUFDdEIsUUFBTSxRQUFRLElBQUksRUFBRSxlQUFlLEtBQUssSUFBSSxPQUFPLGVBQWU7QUFDbEUsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixRQUFNLFdBQVcsSUFBSSxNQUFNLFFBQVE7QUFDbkMsUUFBTSxPQUFPLElBQUksTUFBTSxJQUFJO0FBQzNCLFFBQU0sVUFBVSxVQUFVLFVBQVUsSUFBSTtBQUN4QyxRQUFNLFFBQVEsVUFBVSxNQUFNLEtBQUs7QUFDbkMsUUFBTSxhQUFhLFVBQVUsTUFBTSxVQUFVO0FBQzdDLFFBQU0saUJBQWlCLFVBQVUsTUFBTSxjQUFjO0FBQ3JELFFBQU0sU0FBUyxVQUFVLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPO0FBRWpFLE1BQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQVEsUUFBTztBQUMxQyxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVDtBQUFBLElBQ0EsYUFBYTtBQUFBLElBQ2I7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLElBQ2pCLGFBQWE7QUFBQSxFQUNmO0FBQ0Y7QUFPQSxTQUFTLG9CQUNQLFlBQ0EsYUFDQSxZQUNBLGVBQ2M7QUFDZCxRQUFNLGVBQWUsSUFBSSxZQUFZLFlBQVk7QUFDakQsU0FBTztBQUFBLElBQ0wsY0FDRSxVQUFVLGFBQWEsSUFBSSxLQUFLLFVBQVUsWUFBWSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUk7QUFBQSxJQUMzRixZQUNFLFVBQVUsZUFBZSxTQUFTLEtBQ2xDLFVBQVUsWUFBWSx1QkFBdUIsS0FDN0MsVUFBVSxZQUFZLHVCQUF1QjtBQUFBLElBQy9DLFVBQVUsV0FBVyxjQUFjLFFBQVEsS0FBSyxXQUFXLFlBQVksUUFBUTtBQUFBLElBQy9FLGtCQUFrQixXQUFXLFlBQVksZ0JBQWdCO0FBQUEsSUFDekQsZUFBZSxVQUFVLGNBQWMsYUFBYSxLQUFLLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDNUYsYUFBYSxVQUFVLFlBQVksV0FBVztBQUFBLElBQzlDLFVBQVUsVUFBVSxJQUFJLFlBQVksUUFBUSxHQUFHLFFBQVEsS0FBSyxVQUFVLFlBQVksUUFBUTtBQUFBLElBQzFGLEtBQUssVUFBVSxZQUFZLEdBQUc7QUFBQSxJQUM5QixpQkFBaUIsVUFBVSxZQUFZLGVBQWU7QUFBQSxJQUN0RCxlQUFlLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDbEQsZ0JBQWdCLFVBQVUsWUFBWSxjQUFjO0FBQUEsSUFDcEQsb0JBQ0UsaUJBQWlCLFVBQVUsYUFBYSxVQUFVLENBQUMsS0FDbkQsaUJBQWlCLFVBQVUsWUFBWSxVQUFVLENBQUM7QUFBQSxJQUNwRCxXQUFXLFdBQVcsWUFBWSxTQUFTO0FBQUEsRUFDN0M7QUFDRjtBQU9BLFNBQVMsWUFBWSxHQUE4QztBQUNqRSxRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksTUFBTSxNQUFNO0FBQ25DLE1BQUksQ0FBQyxXQUFZLFFBQU87QUFDeEIsUUFBTSxXQUFXLFdBQVc7QUFDNUIsUUFBTSxRQUFpQyxDQUFDO0FBQ3hDLE1BQUksTUFBTSxRQUFRLFFBQVEsR0FBRztBQUMzQixlQUFXLE1BQU0sVUFBVTtBQUN6QixVQUFJLE9BQU8sT0FBTyxZQUFZLE9BQU8sS0FBTTtBQUMzQyxZQUFNLElBQUk7QUFDVixZQUFNLElBQUksVUFBVSxFQUFFLEdBQUc7QUFDekIsWUFBTSxJQUFJLElBQUksRUFBRSxLQUFLO0FBQ3JCLFVBQUksQ0FBQyxLQUFLLENBQUMsRUFBRztBQUNkLFlBQU0sQ0FBQyxJQUNMLFVBQVUsRUFBRSxZQUFZLEtBQ3hCLFVBQVUsSUFBSSxFQUFFLFdBQVcsR0FBRyxHQUFHLEtBQ2pDLFVBQVUsSUFBSSxFQUFFLGlCQUFpQixHQUFHLE9BQU87QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sVUFBVSxXQUFXLElBQUk7QUFDdEMsUUFBTSxVQUFVLFVBQVUsV0FBVyxHQUFHO0FBQ3hDLFFBQU0sWUFDSixPQUFPLE1BQU0sWUFBWSxNQUFNLFdBQVksTUFBTSxZQUFZLElBQWU7QUFDOUUsUUFBTSxRQUFRLE9BQU8sTUFBTSxPQUFPLE1BQU0sV0FBWSxNQUFNLE9BQU8sSUFBZTtBQUNoRixRQUFNLGNBQ0osT0FBTyxNQUFNLGFBQWEsTUFBTSxXQUFZLE1BQU0sYUFBYSxJQUFlO0FBQ2hGLFFBQU0sWUFDSCxPQUFPLE1BQU0sZ0NBQWdDLE1BQU0sV0FDL0MsTUFBTSxnQ0FBZ0MsSUFDdkMsVUFDSCxPQUFPLE1BQU0sMEJBQTBCLE1BQU0sV0FDekMsTUFBTSwwQkFBMEIsSUFDakMsVUFDSCxPQUFPLE1BQU0sOEJBQThCLE1BQU0sV0FDN0MsTUFBTSw4QkFBOEIsSUFDckM7QUFDTixNQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsU0FBVSxRQUFPO0FBQ3pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiO0FBQ0Y7OztBQ3IwQkEsSUFBTSxXQUFXO0FBRVYsU0FBUyxXQUFtQjtBQUNqQyxRQUFNLEtBQUssS0FBSyxJQUFJO0FBQ3BCLE1BQUksU0FBUztBQUNiLE1BQUksSUFBSTtBQUNSLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLGNBQVUsU0FBUyxJQUFJLEVBQUUsS0FBSyxPQUFPO0FBQ3JDLFFBQUksS0FBSyxNQUFNLElBQUksRUFBRTtBQUFBLEVBQ3ZCO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLEtBQU0sYUFBWSxTQUFTLElBQUksRUFBRSxLQUFLO0FBQ3RELFNBQU8sU0FBUztBQUNsQjtBQUVPLFNBQVMsV0FBVyxJQUFvQjtBQUM3QyxTQUFPLEdBQUcsTUFBTSxFQUFFO0FBQ3BCOzs7QUNmQSxJQUFNLGdCQUFnQjtBQWV0QixTQUFTLFNBQVMsR0FBaUI7QUFDakMsU0FBTyxHQUFHLEVBQUUsZUFBZSxDQUFDLElBQUksT0FBTyxFQUFFLFlBQVksSUFBSSxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUM5RTtBQUVBLFNBQVMsV0FBVyxJQUFrQjtBQUNwQyxRQUFNLFFBQVEsR0FBRyxNQUFNLEdBQUc7QUFDMUIsUUFBTSxJQUFJLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFDekIsUUFBTSxJQUFJLE9BQU8sTUFBTSxDQUFDLEtBQUssR0FBRztBQUNoQyxTQUFPLElBQUksS0FBSyxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZDO0FBRUEsU0FBUyxVQUFVLEdBQVMsR0FBaUI7QUFDM0MsU0FBTyxJQUFJLEtBQUssS0FBSyxJQUFJLEVBQUUsZUFBZSxHQUFHLEVBQUUsWUFBWSxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBQ3RFO0FBRUEsU0FBUyxRQUFRLEdBQVMsR0FBaUI7QUFDekMsU0FBTyxJQUFJLEtBQUssRUFBRSxRQUFRLElBQUksSUFBSSxLQUFVO0FBQzlDO0FBRUEsU0FBUyxRQUFRLEdBQWlCO0FBQ2hDLFNBQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDcEM7QUFFQSxTQUFTLE9BQU8sTUFBd0I7QUFDdEMsTUFBSSxLQUFLLFdBQVcsRUFBRyxRQUFPO0FBQzlCLFFBQU0sSUFBSSxDQUFDLEdBQUcsSUFBSSxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0FBQ3hDLFFBQU0sTUFBTSxLQUFLLE1BQU0sRUFBRSxTQUFTLENBQUM7QUFDbkMsTUFBSSxFQUFFLFNBQVMsRUFBRyxRQUFPLEVBQUUsR0FBRyxLQUFLO0FBQ25DLFdBQVMsRUFBRSxNQUFNLENBQUMsS0FBSyxNQUFNLEVBQUUsR0FBRyxLQUFLLE1BQU07QUFDL0M7QUFFTyxTQUFTLGFBQWEsUUFBZ0IsVUFBa0IsUUFBd0I7QUFDckYsUUFBTSxJQUFJLFFBQVEsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0FBQzFELFNBQU8sR0FBRyxhQUFhLE1BQU0sbUJBQW1CLENBQUMsQ0FBQztBQUNwRDtBQUdPLFNBQVMsaUJBQ2QsU0FDQSxVQUFzQixDQUFDLEdBQ1I7QUFDZixRQUFNLE1BQU0sUUFBUSxPQUFPLG9CQUFJLEtBQUs7QUFDcEMsUUFBTSxjQUFjLFFBQVEsZUFBZTtBQUMzQyxRQUFNLGNBQWMsUUFBUSxlQUFlO0FBQzNDLFFBQU0scUJBQXFCLFFBQVEsc0JBQXNCO0FBQ3pELFFBQU0sMkJBQTJCLFFBQVEsNEJBQTRCO0FBRXJFLFFBQU0sU0FBUyxRQUFRLFVBQVUsQ0FBQztBQUNsQyxNQUFJLENBQUMsUUFBUSxjQUFlLFFBQU8sQ0FBQztBQUNwQyxRQUFNLGFBQWEsV0FBVyxRQUFRLGNBQWMsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUMvRCxRQUFNLFdBQVcsV0FBVyxTQUFTLEdBQUcsQ0FBQztBQUV6QyxRQUFNLE1BQXVDLENBQUM7QUFDOUMsV0FBUyxJQUFJLFlBQVksS0FBSyxVQUFVLElBQUksVUFBVSxHQUFHLENBQUMsR0FBRztBQUMzRCxVQUFNLEtBQUssU0FBUyxDQUFDO0FBQ3JCLFFBQUksS0FBSyxFQUFFLElBQUksT0FBTyxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFBQSxFQUN6QztBQUNBLE1BQUksSUFBSSxXQUFXLEVBQUcsUUFBTyxDQUFDO0FBRTlCLFFBQU0sZUFBZSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLO0FBQ3RFLFFBQU0sTUFBTSxPQUFPLFlBQVk7QUFDL0IsUUFBTSxrQkFDSixPQUFPLHFCQUFxQixLQUFLLElBQUksYUFBYSxLQUFLLE1BQU0sY0FBYyxHQUFHLENBQUMsSUFBSTtBQUVyRixRQUFNLGtCQUFrQixRQUFRLGlCQUFpQixRQUFRLGVBQWUsTUFBTSxHQUFHLENBQUMsSUFBSTtBQUN0RixRQUFNLFNBQVMsQ0FBQyxNQUNkLEVBQUUsVUFBVSxLQUFNLGtCQUFrQixLQUFLLEVBQUUsUUFBUTtBQUVyRCxRQUFNLE9BQXNCLENBQUM7QUFDN0IsTUFBSSxNQUF1QyxDQUFDO0FBQzVDLFFBQU0sUUFBUSxNQUFZO0FBQ3hCLFVBQU0sUUFBUSxJQUFJLENBQUM7QUFDbkIsVUFBTSxPQUFPLElBQUksSUFBSSxTQUFTLENBQUM7QUFDL0IsUUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFNO0FBQ3JCLFVBQU0sWUFBWSxNQUFNO0FBQ3hCLFVBQU0sVUFBVSxLQUFLO0FBQ3JCLFVBQU0sV0FBVyxHQUFHLFNBQVM7QUFDN0IsVUFBTSxTQUFTLFFBQVEsVUFBVSxXQUFXLE9BQU8sR0FBRyxDQUFDLENBQUM7QUFDeEQsVUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLEtBQUssTUFBTSxNQUFNLEVBQUUsT0FBTyxDQUFDO0FBQ3hELFVBQU0sV0FBVyxJQUFJLE1BQU0sQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDO0FBQy9DLFVBQU0sV0FBVyxvQkFBb0IsUUFBUSxZQUFZO0FBQ3pELFVBQU0sT0FBNEIsV0FBVyxXQUFXLFdBQVcsVUFBVTtBQUM3RSxTQUFLLEtBQUs7QUFBQSxNQUNSLFFBQVEsUUFBUTtBQUFBLE1BQ2hCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxZQUFZLElBQUk7QUFBQSxNQUNoQixpQkFBaUI7QUFBQSxNQUNqQjtBQUFBLE1BQ0EsV0FBVyxhQUFhLFFBQVEsUUFBUSxVQUFVLE1BQU07QUFBQSxJQUMxRCxDQUFDO0FBQ0QsVUFBTSxDQUFDO0FBQUEsRUFDVDtBQUNBLGFBQVcsS0FBSyxLQUFLO0FBQ25CLFFBQUksT0FBTyxDQUFDLEVBQUcsS0FBSSxLQUFLLENBQUM7QUFBQSxRQUNwQixPQUFNO0FBQUEsRUFDYjtBQUNBLFFBQU07QUFNTixNQUFJLFFBQVEsZ0JBQWdCO0FBQzFCLFVBQU0sT0FBTyxJQUFJLEtBQUssUUFBUSxjQUFjO0FBQzVDLFVBQU0sV0FBVyxJQUFJLFFBQVEsSUFBSSxLQUFLLFFBQVEsS0FBSztBQUNuRCxRQUFJLFdBQVcsNEJBQTRCLFNBQVMsSUFBSSxNQUFNLFNBQVMsR0FBRyxHQUFHO0FBQzNFLFlBQU0sV0FBVyxRQUFRLElBQUk7QUFDN0IsWUFBTSxTQUFTLFFBQVEsUUFBUSxLQUFLLENBQUMsQ0FBQztBQUN0QyxXQUFLLEtBQUs7QUFBQSxRQUNSLFFBQVEsUUFBUTtBQUFBLFFBQ2hCLFdBQVcsU0FBUyxHQUFHO0FBQUEsUUFDdkIsU0FBUyxTQUFTLEdBQUc7QUFBQSxRQUNyQjtBQUFBLFFBQ0E7QUFBQSxRQUNBLFlBQVk7QUFBQSxRQUNaLGlCQUFpQixPQUFPLFNBQVMsR0FBRyxDQUFDLEtBQUs7QUFBQSxRQUMxQyxNQUFNO0FBQUEsUUFDTixXQUFXLGFBQWEsUUFBUSxRQUFRLFVBQVUsTUFBTTtBQUFBLE1BQzFELENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFNBQU87QUFDVDtBQUdPLFNBQVMsU0FBUyxNQUFvQztBQUMzRCxRQUFNLFNBQThDLEVBQUUsUUFBUSxHQUFHLE9BQU8sR0FBRyxRQUFRLEVBQUU7QUFDckYsU0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sT0FBTyxFQUFFLElBQUksSUFBSSxPQUFPLEVBQUUsSUFBSSxLQUFLLEVBQUUsYUFBYSxFQUFFLFVBQVU7QUFDaEc7OztBQzNJQSxJQUFNLG1CQUFpRCxvQkFBSSxJQUFJO0FBQUEsRUFDN0Q7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVNLFNBQVMsa0JBQWtCLE1BQStCO0FBQy9ELFFBQU0sV0FBNEIsQ0FBQztBQUNuQyxNQUFJLFVBQWtDLENBQUM7QUFDdkMsTUFBSSxhQUFhO0FBQ2pCLFFBQU0sUUFBUSxNQUFNO0FBQ2xCLFFBQUksUUFBUSxVQUFVLFFBQVEsT0FBTztBQUNuQyxVQUFJLENBQUMsUUFBUSxTQUFVLFNBQVEsV0FBVztBQUMxQyxlQUFTLEtBQUssT0FBd0I7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFDQSxhQUFXLFdBQVcsS0FBSyxNQUFNLElBQUksR0FBRztBQUN0QyxVQUFNLE9BQU8sY0FBYyxPQUFPO0FBQ2xDLFFBQUksS0FBSyxLQUFLLE1BQU0sR0FBSTtBQUN4QixRQUFJLGdCQUFnQixLQUFLLElBQUksR0FBRztBQUM5QixtQkFBYTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxXQUFZO0FBRWpCLFVBQU0sWUFBWSxLQUFLLE1BQU0sNEJBQTRCO0FBQ3pELFFBQUksV0FBVztBQUNiLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxVQUFVLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDaEQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx3QkFBd0I7QUFDdEQsUUFBSSxjQUFjLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUNyQyxZQUFNO0FBQ04sZ0JBQVUsRUFBRSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2pEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sdUJBQXVCO0FBQ3JELFFBQUksY0FBYyxRQUFRLFFBQVE7QUFDaEMsY0FBUSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRTtBQUMzQztBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixLQUFLLE1BQU0sMEJBQTBCO0FBQzNELFFBQUksaUJBQWlCLFFBQVEsUUFBUTtBQUNuQyxZQUFNLE1BQU0sUUFBUSxjQUFjLENBQUMsS0FBSyxFQUFFO0FBQzFDLGNBQVEsV0FBVyxpQkFBaUIsSUFBSSxHQUFzQixJQUN6RCxNQUNEO0FBQ0o7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU07QUFDTixTQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUNuRDtBQUVBLFNBQVMsY0FBYyxNQUFzQjtBQUczQyxRQUFNLE1BQU0sS0FBSyxRQUFRLEdBQUc7QUFDNUIsU0FBTyxRQUFRLEtBQUssT0FBTyxLQUFLLE1BQU0sR0FBRyxHQUFHO0FBQzlDO0FBRUEsU0FBUyxRQUFRLEdBQW1CO0FBQ2xDLFFBQU0sVUFBVSxFQUFFLEtBQUs7QUFDdkIsTUFDRyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQy9DLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsR0FDaEQ7QUFDQSxXQUFPLFFBQVEsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUM1QjtBQUNBLFNBQU87QUFDVDs7O0FDYUEsSUFBTSxjQUFjLFFBQVEsUUFBUSxZQUFZLEVBQUU7QUFDbEQsSUFBTSwyQkFBMkI7QUFDakMsSUFBTSw2QkFBNkI7QUFDbkMsSUFBTSxtQ0FBbUM7QUFDekMsSUFBTSwrQkFBK0IsQ0FBQyxTQUFTLFNBQVMsTUFBTTtBQUM5RCxJQUFNLDJDQUEyQyxDQUFDLFNBQVMsa0JBQWtCLE9BQU87QUFDcEYsSUFBTSxrQ0FBa0M7QUFBQSxFQUN0QztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGO0FBQ0EsSUFBSSx1QkFBdUI7QUF3QjNCLGVBQWUsQ0FBQyxPQUFpQjtBQUMvQixVQUFRLFFBQVEsWUFBWSxFQUFFLE1BQU0sYUFBYSxPQUFPLEdBQUcsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUM5RSxDQUFDO0FBRUQsU0FBUywyQkFBaUM7QUFDeEMseUJBQXVCLEtBQUssSUFBSSxJQUFJO0FBQ3RDO0FBSUEsUUFBUSxRQUFRLFlBQVksWUFBWSxZQUFZO0FBQ2xELFFBQU0sS0FBSyx1QkFBdUIsRUFBRSxTQUFTLFlBQVksQ0FBQztBQUMxRCxRQUFNLE9BQU8sU0FBUztBQUN4QixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxNQUFNO0FBQzFDLE9BQUssT0FBTyxTQUFTO0FBQ3ZCLENBQUM7QUFHRCxLQUFLLE9BQU8sYUFBYTtBQUV6QixlQUFlLE9BQU8sUUFBK0I7QUFDbkQsTUFBSTtBQUNGLFVBQU0sYUFBYTtBQUNuQixVQUFNLHNCQUFzQjtBQUM1QixVQUFNLHNCQUFzQixFQUFFLFFBQVEsUUFBUSxNQUFNLElBQUksS0FBSyxNQUFNLENBQUM7QUFDcEUsVUFBTSw0QkFBNEI7QUFDbEMsVUFBTSxxQkFBcUI7QUFHM0IsVUFBTSxTQUFTLE1BQU0sb0JBQW9CLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBSTtBQUNqRSxRQUFJLFNBQVMsRUFBRyxPQUFNLEtBQUssMEJBQTBCLEVBQUUsT0FBTyxDQUFDO0FBQy9ELFVBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBSSxTQUFTLE9BQU8sU0FBUyxTQUFTLFNBQVMsTUFBTTtBQUNuRCxZQUFNLGlCQUFpQixLQUFLO0FBQzVCLFlBQU0sb0JBQW9CLEtBQUs7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTSxjQUFjO0FBQUEsUUFDbEIsUUFBUTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWU7QUFBQSxRQUNmLHdCQUF3QjtBQUFBLFFBQ3hCLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFDRCxZQUFNLEtBQUssd0NBQXdDLEVBQUUsT0FBTyxDQUFDO0FBQUEsSUFDL0Q7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sTUFBTyxlQUFlLEVBQUUsUUFBUSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFBQSxFQUMvRDtBQUNGO0FBRUEsU0FBUyxTQUEwQztBQUNqRCxRQUFNLGVBQWU7QUFHckIsU0FBTyxhQUFhLHlCQUF5QjtBQUMvQztBQUVBLGVBQWUsaUJBQW9DO0FBQ2pELFFBQU0sT0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQzNGLFNBQU8sS0FBSyxRQUFRLENBQUMsUUFBUyxPQUFPLElBQUksT0FBTyxXQUFXLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFFO0FBQzNFO0FBRUEsZUFBZSxzQkFBc0I7QUFBQSxFQUNuQztBQUFBLEVBQ0E7QUFDRixHQUdrQjtBQUNoQixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sTUFBTSxPQUFPO0FBQ25CLE1BQUksQ0FBQyxLQUFLO0FBQ1IsUUFBSSxTQUFTLHdCQUF3QixLQUFLO0FBQ3hDLFlBQU0sS0FBSyx5RUFBeUU7QUFBQSxRQUNsRjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFDQTtBQUFBLEVBQ0Y7QUFFQSxRQUFNLFNBQVMsU0FBUyx1QkFBdUIsTUFBTSxlQUFlLElBQUksQ0FBQztBQUN6RSxRQUFNLGdCQUFnQjtBQUFBLElBQ3BCO0FBQUEsSUFDQSxHQUFHLGdDQUFnQyxJQUFJLENBQUMsR0FBRyxRQUFRLG1DQUFtQyxHQUFHO0FBQUEsRUFDM0Y7QUFDQSxRQUFNLFdBQ0osT0FBTyxTQUFTLElBQ1o7QUFBQSxJQUNFO0FBQUEsTUFDRSxJQUFJO0FBQUEsTUFDSixVQUFVO0FBQUEsTUFDVixRQUFRLEVBQUUsTUFBTSxRQUFRO0FBQUEsTUFDeEIsV0FBVztBQUFBLFFBQ1Q7QUFBQSxRQUNBLGVBQWUsQ0FBQyxHQUFHLDRCQUE0QjtBQUFBLE1BQ2pEO0FBQUEsSUFDRjtBQUFBLElBQ0EsR0FBRyxnQ0FBZ0MsSUFBSSxDQUFDLFdBQVcsU0FBUztBQUFBLE1BQzFELElBQUksbUNBQW1DO0FBQUEsTUFDdkMsVUFBVTtBQUFBLE1BQ1YsUUFBUSxFQUFFLE1BQU0sUUFBaUI7QUFBQSxNQUNqQyxXQUFXO0FBQUEsUUFDVDtBQUFBLFFBQ0E7QUFBQSxRQUNBLGVBQWUsQ0FBQyxHQUFHLHdDQUF3QztBQUFBLE1BQzdEO0FBQUEsSUFDRixFQUFFO0FBQUEsRUFDSixJQUNBLENBQUM7QUFDUCxRQUFNLElBQUksbUJBQW1CO0FBQUEsSUFDM0I7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBRUQsTUFBSSxLQUFLO0FBQ1AsVUFBTSxLQUFLLHdDQUF3QztBQUFBLE1BQ2pELFNBQVMsU0FBUztBQUFBLE1BQ2xCLFdBQVcsT0FBTztBQUFBLE1BQ2xCLHdCQUF3Qiw2QkFBNkIsS0FBSyxHQUFHO0FBQUEsTUFDN0QsdUJBQXVCLGdDQUFnQyxLQUFLLEdBQUc7QUFBQSxNQUMvRDtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQUVBLFFBQVEsS0FBSyxVQUFVLFlBQVksQ0FBQyxRQUFRLGVBQWU7QUFDekQsTUFBSSxXQUFXLE9BQU8sV0FBVyxXQUFXLFlBQVk7QUFDdEQsU0FBSyxzQkFBc0IsRUFBRSxRQUFRLGVBQWUsS0FBSyxNQUFNLENBQUMsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUMvRSxXQUFLLEtBQUsscUNBQXFDLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDbkUsQ0FBQztBQUFBLEVBQ0g7QUFDRixDQUFDO0FBRUQsUUFBUSxLQUFLLFVBQVUsWUFBWSxNQUFNO0FBQ3ZDLE9BQUssc0JBQXNCLEVBQUUsUUFBUSxlQUFlLEtBQUssTUFBTSxDQUFDLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDL0UsU0FBSyxLQUFLLHFDQUFxQyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ25FLENBQUM7QUFDSCxDQUFDO0FBWUQsZUFBZSx1QkFBc0M7QUFDbkQsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFBQSxFQUN2RixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssNkJBQTZCLGNBQWMsR0FBRyxDQUFDO0FBQzFEO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxPQUFPLElBQUksT0FBTyxTQUFVO0FBQ2hDLFFBQUk7QUFDRixZQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTyxDQUFDLGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl0QixPQUFPO0FBQUEsTUFDVCxDQUFDO0FBQ0QsWUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU8sQ0FBQyxZQUFZO0FBQUEsTUFDdEIsQ0FBQztBQUNELFlBQU0sS0FBSyxxQ0FBcUM7QUFBQSxRQUM5QyxPQUFPLElBQUk7QUFBQSxRQUNYLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRTtBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNILFNBQVMsS0FBSztBQUlaLFlBQU0sS0FBSyx3Q0FBd0M7QUFBQSxRQUNqRCxPQUFPLElBQUk7QUFBQSxRQUNYLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRTtBQUFBLFFBQzdCLEdBQUcsY0FBYyxHQUFHO0FBQUEsTUFDdEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLFFBQU0sUUFBUSxPQUFPLE1BQU0sYUFBYTtBQUN4QyxRQUFNLFFBQVEsT0FBTyxNQUFNLG1CQUFtQjtBQUM5QyxRQUFNLFFBQVEsT0FBTyxPQUFPLGVBQWUsRUFBRSxpQkFBaUIsb0JBQW9CLENBQUM7QUFDbkYsUUFBTSxRQUFRLE9BQU8sT0FBTyxxQkFBcUI7QUFBQSxJQUMvQyxpQkFBaUIsZ0NBQWdDO0FBQUEsRUFDbkQsQ0FBQztBQUNIO0FBTUEsSUFBSSxrQkFBeUQ7QUFDN0QsSUFBTSw2QkFBNkIsS0FBSyxLQUFLO0FBTTdDLElBQU0sOEJBQThCLG9CQUFJLElBQStCO0FBS3ZFLElBQU0saUJBQWlCO0FBRXZCLGVBQWUsd0JBQXVDO0FBRXBELFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLE1BQUksU0FBUyxRQUFRLEVBQUUsWUFBWSxPQUFPO0FBQ3hDLHVCQUFtQixFQUFFLHFCQUFxQjtBQUFBLEVBQzVDLE9BQU87QUFDTCx5QkFBcUI7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyx1QkFBNkI7QUFDcEMsTUFBSSxvQkFBb0IsTUFBTTtBQUM1QixrQkFBYyxlQUFlO0FBQzdCLHNCQUFrQjtBQUFBLEVBQ3BCO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixhQUEyQjtBQUNyRCx1QkFBcUI7QUFDckIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sV0FBVyxDQUFDO0FBQUEsRUFDdkQ7QUFDQSxvQkFBa0IsWUFBWSxNQUFNO0FBQ2xDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELDJCQUF5QjtBQUN6QixRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLGFBQWE7QUFBQSxJQUNiLGVBQWU7QUFBQSxJQUNmLGtCQUFrQjtBQUFBLElBQ2xCLHVCQUF1QjtBQUFBLElBQ3ZCLGlCQUFpQjtBQUFBLElBQ2pCLGVBQWU7QUFBQSxFQUNqQixDQUFDO0FBQ0QscUJBQW1CLEVBQUUscUJBQXFCO0FBQzFDLFFBQU0sS0FBSyw0QkFBNEIsRUFBRSxjQUFjLEVBQUUsc0JBQXNCLENBQUM7QUFFaEYsT0FBSyxlQUFlO0FBQ3BCLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHVCQUFxQjtBQUNyQixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxNQUFNLGVBQWU7QUFBQSxJQUM5QixVQUFVLE1BQU0saUJBQWlCO0FBQUEsSUFDakMsVUFBVSxNQUFNLGlCQUFpQjtBQUFBLEVBQ25DLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUFBLEVBQ3ZGLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpQ0FBaUMsY0FBYyxHQUFHLENBQUM7QUFDOUQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixNQUFJLGNBQWM7QUFDbEIsTUFBSSxhQUFhO0FBQ2pCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJLElBQUksVUFBVztBQUNuQixRQUFJO0FBQ0YsWUFBTSxVQUFXLE1BQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNyRCxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPO0FBQUEsUUFDUCxNQUFPLE1BQU07QUFDWCxnQkFBTSxpQkFBaUIsQ0FBQyxPQUN0QixHQUFHLEdBQUcsZUFBZSxFQUFFLElBQUksR0FBRyxhQUFhLFlBQVksS0FBSyxFQUFFLEdBQzNELFFBQVEsUUFBUSxHQUFHLEVBQ25CLEtBQUssRUFDTCxZQUFZO0FBQ2pCLGdCQUFNLDBCQUEwQixNQUFlO0FBQzdDLGtCQUFNLFlBQVksU0FBUyxNQUFNLGFBQWEsSUFBSSxZQUFZO0FBQzlELGdCQUFJLENBQUMsU0FBUyxTQUFTLHNCQUFzQixLQUFLLENBQUMsU0FBUyxTQUFTLGVBQWUsR0FBRztBQUNyRixxQkFBTztBQUFBLFlBQ1Q7QUFDQSxrQkFBTSxXQUFXLE1BQU07QUFBQSxjQUNyQixTQUFTLGlCQUFpQixnQ0FBZ0M7QUFBQSxZQUM1RDtBQUNBLGtCQUFNLFFBQVEsU0FBUyxLQUFLLENBQUMsT0FBTztBQUNsQyxvQkFBTSxPQUFPLGVBQWUsRUFBRTtBQUM5QixxQkFBTyxTQUFTLFdBQVcsS0FBSyxTQUFTLE9BQU8sS0FBSyxLQUFLLFNBQVMsV0FBVztBQUFBLFlBQ2hGLENBQUM7QUFDRCxnQkFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixZQUFDLE1BQXNCLE1BQU07QUFDN0IsbUJBQU87QUFBQSxVQUNUO0FBQ0EsY0FBSSx3QkFBd0IsRUFBRyxRQUFPLEVBQUUsU0FBUyxNQUFNLFVBQVUsTUFBTTtBQUl2RSxnQkFBTSxPQUEwQjtBQUFBLFlBQzlCLEtBQUs7QUFBQSxZQUNMLE1BQU07QUFBQSxZQUNOLFNBQVM7QUFBQSxZQUNULE9BQU87QUFBQSxZQUNQLFNBQVM7QUFBQSxZQUNULFlBQVk7QUFBQSxVQUNkO0FBQ0EsZ0JBQU0sUUFBUyxTQUFTLGlCQUF3QyxTQUFTO0FBQ3pFLGdCQUFNLGNBQWMsSUFBSSxjQUFjLFdBQVcsSUFBSSxDQUFDO0FBQ3RELGdCQUFNLGNBQWMsSUFBSSxjQUFjLFNBQVMsSUFBSSxDQUFDO0FBQ3BELGlCQUFPLFNBQVM7QUFBQSxZQUNkLEtBQUssU0FBUyxnQkFBZ0I7QUFBQSxZQUM5QixVQUFVO0FBQUEsVUFDWixDQUFDO0FBQ0QsaUJBQU8sRUFBRSxTQUFTLE9BQU8sVUFBVSxLQUFLO0FBQUEsUUFDMUM7QUFBQSxNQUNGLENBQUM7QUFDRCxZQUFNLGNBQWMsUUFDakIsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQ25CO0FBQUEsUUFDQyxDQUFDLFdBQ0MsT0FBTyxXQUFXLFlBQVksV0FBVztBQUFBLE1BQzdDO0FBQ0YsVUFBSSxZQUFZLEtBQUssQ0FBQyxXQUFXLE9BQU8sWUFBWSxJQUFJLEdBQUc7QUFDekQsc0JBQWM7QUFBQSxNQUNoQjtBQUNBLFVBQUksWUFBWSxLQUFLLENBQUMsV0FBVyxPQUFPLGFBQWEsSUFBSSxHQUFHO0FBQzFELHVCQUFlO0FBQUEsTUFDakI7QUFBQSxJQUNGLFFBQVE7QUFBQSxJQUdSO0FBQUEsRUFDRjtBQUNBLE1BQUksYUFBYSxHQUFHO0FBQ2xCLFVBQU0sS0FBSyx1Q0FBdUMsRUFBRSxXQUFXLFdBQVcsQ0FBQztBQUFBLEVBQzdFO0FBQ0EsTUFBSSxjQUFjLEdBQUc7QUFDbkIsVUFBTSxPQUFPLE1BQU0scUJBQXFCO0FBQ3hDLFFBQUksU0FBUyxNQUFNO0FBQ2pCLFdBQUssZUFBZTtBQUNwQixZQUFNLHFCQUFxQixJQUFJO0FBQUEsSUFFakM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHlCQUErQjtBQUN0QyxRQUFNLFNBQVMsS0FBSyxJQUFJLElBQUk7QUFDNUIsYUFBVyxDQUFDLE9BQU8sS0FBSyxLQUFLLDZCQUE2QjtBQUN4RCxRQUFJLE1BQU0sWUFBWSxPQUFRLDZCQUE0QixPQUFPLEtBQUs7QUFBQSxFQUN4RTtBQUNGO0FBRUEsU0FBUywrQkFDUCxPQUNBLFNBQ0EsUUFDQSxhQUNNO0FBQ04sTUFBSSxVQUFVLFFBQVEsT0FBTyxXQUFXLEtBQUssWUFBWSxTQUFTLEVBQUc7QUFDckUsUUFBTSxlQUFlLG9CQUFJLElBQVk7QUFDckMsYUFBVyxLQUFLLFFBQVE7QUFDdEIsUUFBSSxZQUFZLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxFQUFHLGNBQWEsSUFBSSxFQUFFLFFBQVE7QUFBQSxFQUNsRjtBQUNBLFFBQU0sV0FBVyw0QkFBNEIsSUFBSSxLQUFLO0FBQ3RELFFBQU0sV0FBVyxVQUFVLFlBQVksb0JBQUksSUFBWTtBQUN2RCxhQUFXLEtBQUssUUFBUTtBQUN0QixVQUFNLFNBQVMsRUFBRSxlQUFlLFlBQVk7QUFDNUMsVUFBTSxjQUFjLEVBQUUsa0JBQWtCLFlBQVksS0FBSztBQUN6RCxRQUNFLFlBQVksSUFBSSxNQUFNLEtBQ3JCLGdCQUFnQixRQUFRLFlBQVksSUFBSSxXQUFXLEtBQ25ELEVBQUUsc0JBQXNCLFFBQVEsYUFBYSxJQUFJLEVBQUUsaUJBQWlCLEtBQ3BFLEVBQUUsb0JBQW9CLFFBQVEsYUFBYSxJQUFJLEVBQUUsZUFBZSxLQUNoRSxFQUFFLHVCQUF1QixRQUFRLGFBQWEsSUFBSSxFQUFFLGtCQUFrQixHQUN2RTtBQUNBLGVBQVMsSUFBSSxFQUFFLFFBQVE7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFDQSw4QkFBNEIsSUFBSSxPQUFPO0FBQUEsSUFDckMsV0FBVyxLQUFLLElBQUk7QUFBQSxJQUNwQjtBQUFBLElBQ0E7QUFBQSxFQUNGLENBQUM7QUFDSDtBQUVBLFFBQVEsT0FBTyxRQUFRLFlBQVksQ0FBQyxVQUFVO0FBQzVDLE1BQUksTUFBTSxTQUFTLGVBQWU7QUFDaEMsU0FBSyxpQkFBaUI7QUFBQSxFQUN4QixXQUFXLE1BQU0sU0FBUyxxQkFBcUI7QUFDN0MsU0FBSyxpQkFBaUIsS0FBSztBQUFBLEVBQzdCO0FBSUYsQ0FBQztBQUlELElBQUksUUFBUSxRQUFRLFdBQVc7QUFDN0IsVUFBUSxPQUFPLFVBQVUsWUFBWSxPQUFPLFFBQVE7QUFDbEQsUUFBSTtBQUNGLFlBQU0sZ0JBQ0osUUFHQTtBQUNGLFVBQUksZUFBZSxRQUFRO0FBQ3pCLGNBQU0sY0FBYyxPQUFPO0FBQzNCO0FBQUEsTUFDRjtBQUVBLFlBQU0sWUFDSixRQUdBO0FBQ0YsVUFBSSxXQUFXLE1BQU07QUFDbkIsY0FBTSxVQUFpQyxDQUFDO0FBQ3hDLFlBQUksT0FBTyxJQUFJLGFBQWEsU0FBVSxTQUFRLFdBQVcsSUFBSTtBQUM3RCxjQUFNLFVBQVUsS0FBSyxPQUFPO0FBQzVCO0FBQUEsTUFDRjtBQUVBLFlBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsUUFBUSxPQUFPLGNBQWMsRUFBRSxDQUFDO0FBQUEsSUFDM0UsU0FBUyxLQUFLO0FBR1osWUFBTSxLQUFLLDRDQUE0QyxjQUFjLEdBQUcsQ0FBQztBQUN6RSxVQUFJO0FBQ0YsY0FBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxRQUFRLE9BQU8sY0FBYyxFQUFFLENBQUM7QUFDekU7QUFBQSxNQUNGLFNBQVMsUUFBUTtBQUNmLGNBQU0sS0FBSyx1Q0FBdUMsY0FBYyxNQUFNLENBQUM7QUFBQSxNQUN6RTtBQUNBLFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUFBLElBQ3hDO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFJQSxRQUFRLFFBQVEsVUFBVSxZQUFZLENBQUMsS0FBYyxXQUFXO0FBQzlELE1BQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFHLFFBQU87QUFDbkMsU0FBTyxjQUFjLEtBQUssTUFBTSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQy9DLFNBQUssTUFBTywwQkFBMEIsRUFBRSxNQUFNLElBQUksTUFBTSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDL0UsVUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNILENBQUM7QUFFRCxTQUFTLGlCQUFpQixHQUFpQztBQUN6RCxTQUFPLENBQUMsQ0FBQyxLQUFLLE9BQU8sTUFBTSxZQUFZLE9BQVEsRUFBeUIsU0FBUztBQUNuRjtBQUlBLElBQU0sNEJBQTRCLG9CQUFJLElBQTRCO0FBQUEsRUFDaEU7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFDRixDQUFDO0FBRUQsZUFBZSxZQUE4QjtBQUMzQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsZUFBZSxjQUNiLEtBQ0EsUUFDa0I7QUFLbEIsTUFBSSxDQUFFLE1BQU0sVUFBVSxLQUFNLDBCQUEwQixJQUFJLElBQUksSUFBSSxHQUFHO0FBQ25FLFdBQU8sRUFBRSxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUEsRUFDbEM7QUFDQSxVQUFRLElBQUksTUFBTTtBQUFBLElBQ2hCLEtBQUs7QUFDSCxZQUFNO0FBQUEsUUFDSixJQUFJO0FBQUEsUUFDSixJQUFJO0FBQUEsUUFDSixJQUFJLFdBQVc7QUFBQSxRQUNmLElBQUk7QUFBQSxRQUNKLFFBQVEsS0FBSyxNQUFNO0FBQUEsTUFDckI7QUFDQSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSyxnQ0FBZ0MsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN2RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUN0RSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFVBQUksSUFBSSxVQUFVLFFBQVE7QUFDeEIsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQsV0FBVyxJQUFJLFVBQVUsU0FBUztBQUNoQyxjQUFNLE1BQU8sSUFBSSxLQUFLLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFBQSxNQUNwRCxPQUFPO0FBQ0wsY0FBTSxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDbEQ7QUFDQSxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSyxzQkFBc0I7QUFDekIsWUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxVQUFJLFNBQVMsWUFBWSxPQUFPO0FBQzlCLGVBQU8sRUFBRSxTQUFTLE9BQU8sYUFBYSxDQUFDLEdBQUcsa0JBQWtCLENBQUMsRUFBRTtBQUFBLE1BQ2pFO0FBQ0EsNkJBQXVCO0FBQ3ZCLFlBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsWUFBTSxjQUFjLFNBQ2pCLE9BQU8sQ0FBQyxNQUFNLEVBQUUsYUFBYSxNQUFNLEVBQ25DLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUM7QUFDcEMsWUFBTSxRQUFRLFFBQVEsS0FBSyxNQUFNO0FBQ2pDLGFBQU87QUFBQSxRQUNMLFNBQVM7QUFBQSxRQUNUO0FBQUEsUUFDQSxrQkFDRSxVQUFVLE9BQU8sQ0FBQyxJQUFJLE1BQU0sS0FBSyw0QkFBNEIsSUFBSSxLQUFLLEdBQUcsWUFBWSxDQUFDLENBQUM7QUFBQSxNQUMzRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLEtBQUssc0JBQXNCO0FBQ3pCLFVBQUksSUFBSSxRQUFRLEdBQUc7QUFDakIsY0FBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFlBQUksV0FBVyxNQUFNO0FBQ25CLGlCQUFPLGlCQUFpQixJQUFJO0FBQzVCLGdCQUFNLHFCQUFxQixNQUFNO0FBQUEsUUFDbkM7QUFBQSxNQUNGO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVyxJQUFJLE1BQU07QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sV0FBVztBQUNqQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxnQkFBZ0I7QUFDdEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sU0FBUyxNQUFNO0FBQ3JCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFlBQVksSUFBSSxRQUFRLE1BQU07QUFDcEMsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLGFBQWEsSUFBSSxHQUFHLENBQUM7QUFDNUMsWUFBTSxLQUFLLHdCQUF3QixFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDakQsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLGdCQUFnQixJQUFJLEdBQUcsQ0FBQztBQUMvQyxZQUFNLEtBQUssMkJBQTJCLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUNwRCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxlQUFlLEVBQUUsc0JBQXNCLElBQUksR0FBRyxDQUFDO0FBQ3JELFlBQU0sc0JBQXNCLEVBQUUsUUFBUSxVQUFVLEtBQUssS0FBSyxDQUFDO0FBQzNELGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssa0JBQWtCO0FBQ3JCLFlBQU0sSUFBSSxNQUFNLGVBQWUsRUFBRSxTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2xELFVBQUksQ0FBQyxJQUFJLElBQUk7QUFHWCw2QkFBcUI7QUFDckIsNEJBQW9CO0FBQ3BCLCtCQUF1QjtBQUN2QiwrQkFBdUI7QUFDdkIsY0FBTSxRQUFRLE9BQU8sTUFBTSxjQUFjO0FBQ3pDLGNBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQzdDLGNBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQUEsTUFDL0MsT0FBTztBQUVMLGNBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxZQUFJLFNBQVMsS0FBTSxvQkFBbUIsRUFBRSxxQkFBcUI7QUFBQSxNQUMvRDtBQUNBLFlBQU0sS0FBSyxtQ0FBbUMsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQzVELGFBQU8sV0FBVztBQUFBLElBQ3BCO0FBQUEsSUFDQSxLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssNEJBQTRCO0FBQy9CLFlBQU0sVUFBVSxLQUFLO0FBQUEsUUFDbkI7QUFBQSxRQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLElBQUksT0FBTyxDQUFDO0FBQUEsTUFDdkQ7QUFDQSxZQUFNLGVBQWUsRUFBRSx1QkFBdUIsUUFBUSxDQUFDO0FBRXZELFlBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxVQUFJLFNBQVMsS0FBTSxvQkFBbUIsT0FBTztBQUM3QyxVQUFJLDBCQUEwQixLQUFNLHNCQUFxQixPQUFPO0FBQ2hFLFVBQUksNkJBQTZCLEtBQU0seUJBQXdCLE9BQU87QUFDdEUsVUFBSSw2QkFBNkIsS0FBTSx5QkFBd0IsT0FBTztBQUN0RSxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0saUJBQWlCO0FBQ3ZCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGtCQUFrQjtBQUN4QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLG9CQUFvQjtBQUMxQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxxQkFBcUI7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSyxtQkFBbUI7QUFDdEIsWUFBTSxPQUFPLE1BQU0sWUFBWTtBQUMvQixZQUFNLFVBQVUsSUFBSSxJQUFJLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLFlBQVksQ0FBQyxDQUFDO0FBQy9ELFlBQU0sVUFBVSxNQUFNLG9CQUFvQixPQUFPO0FBQ2pELFlBQU0sS0FBSywwQkFBMEIsT0FBTztBQUM1QyxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0sb0JBQW9CLElBQUk7QUFDOUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0saUJBQWlCLElBQUk7QUFDM0IsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sY0FBYztBQUNwQixhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sUUFBUSxRQUFRLGdCQUFnQjtBQUN0QyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEIsS0FBSyxlQUFlO0FBQ2xCLFlBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsWUFBTSxNQUFNLFVBQVUsQ0FBQztBQUN2QixZQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQ2pDLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSyxxQkFBcUI7QUFDeEIsWUFBTSxXQUFXLE1BQU0sbUJBQW1CO0FBQzFDLFVBQUksQ0FBQyxVQUFVO0FBQ2IsZUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLDhEQUF5RDtBQUFBLE1BQ3RGO0FBQ0EsWUFBTSxNQUFxQixDQUFDO0FBQzVCLGlCQUFXLFdBQVcsT0FBTyxPQUFPLFNBQVMsUUFBUSxHQUFHO0FBQ3RELFlBQUksS0FBSyxHQUFHLGlCQUFpQixPQUFPLENBQUM7QUFBQSxNQUN2QztBQUNBLGFBQU8sRUFBRSxJQUFJLE1BQU0sTUFBTSxTQUFTLEdBQUcsR0FBRyxhQUFhLFNBQVMsYUFBYTtBQUFBLElBQzdFO0FBQUEsSUFDQSxLQUFLLFlBQVk7QUFDZixZQUFNLE1BQU0sSUFBSTtBQUNoQixVQUFJLE9BQU8sUUFBUSxZQUFZLENBQUMscUNBQXFDLEtBQUssR0FBRyxHQUFHO0FBQzlFLGVBQU8sRUFBRSxJQUFJLE9BQU8sT0FBTywrQkFBK0I7QUFBQSxNQUM1RDtBQUNBLFlBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsS0FBSyxDQUFDO0FBQy9DLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQjtBQUFBLElBQ0E7QUFDRSxhQUFPLEVBQUUsSUFBSSxPQUFPLE9BQU8sdUJBQXVCO0FBQUEsRUFDdEQ7QUFDRjtBQUlBLGVBQWUsaUJBQ2IsVUFDQSxLQUNBLFNBQ0EsVUFDQSxhQUNlO0FBQ2YsTUFBSSxrQkFBa0IsSUFBSSxRQUFRLEVBQUc7QUFDckMsTUFBSSxDQUFDLGdCQUFnQixJQUFJLFFBQVEsRUFBRztBQUVwQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksU0FBUyxZQUFZLE1BQU87QUFDaEMsTUFBSSxTQUFTLGdCQUFnQixPQUFPO0FBQ2xDLFVBQU0sd0JBQ0osS0FBSyxJQUFJLElBQUksd0JBQ1osTUFBTSxxQkFBcUIsTUFBTyxRQUNsQyxNQUFNLGtCQUFrQixNQUFPLFFBQy9CLE1BQU0scUJBQXFCLE1BQU87QUFDckMsUUFBSSxDQUFDLHNCQUF1QjtBQUFBLEVBQzlCO0FBRUEsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQWdCbkMsUUFBTSxVQUFVLElBQUksSUFBSSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUNuRSxRQUFNLE9BQU8sSUFBSTtBQUFBLElBQ2YsU0FBUyxPQUFPLENBQUMsTUFBTSxFQUFFLGFBQWEsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUM7QUFBQSxFQUNqRjtBQUNBLFFBQU0sY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUUxQyxNQUFJO0FBQ0osTUFBSTtBQUNGLGlCQUFhLFVBQVUsVUFBVTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsZ0JBQWdCLG9CQUFJLElBQVk7QUFBQSxNQUNoQyxXQUFXO0FBQUEsSUFDYixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLFdBQVcsbUJBQW1CLFVBQVUsS0FBSyxVQUFVLEdBQUc7QUFDaEU7QUFBQSxFQUNGO0FBQ0EsUUFBTSxlQUFlO0FBQUEsSUFDbkIsV0FBVztBQUFBLElBQ1g7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsV0FBVztBQUFBLEVBQ2I7QUFRQSxRQUFNLGVBQWUsV0FBVyxPQUFPO0FBQ3ZDLGFBQVcsU0FBUyxjQUFjLFdBQVcsUUFBUSxTQUFTLElBQUk7QUFDbEUsUUFBTSxtQkFBbUIsZUFBZSxXQUFXLE9BQU87QUFDMUQsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLEtBQUssNEJBQTRCO0FBQUEsTUFDckM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDMUIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxpQ0FBK0IsYUFBYSxTQUFTLFdBQVcsUUFBUSxJQUFJO0FBTzVFLE1BQUksV0FBVyxhQUFhLFdBQVcsR0FBRztBQUN4QyxVQUFNLEtBQUssNENBQXVDO0FBQUEsTUFDaEQ7QUFBQSxNQUNBLFdBQVcsZUFBZSxRQUFRLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxNQUMvQyxZQUFZLG9CQUFvQixVQUFVLE9BQU87QUFBQSxNQUNqRCxpQkFBaUIsaUJBQWlCLFVBQVUsU0FBUyxDQUFDLE1BQU0sQ0FBQztBQUFBLE1BQzdELG1CQUFtQixpQkFBaUIsVUFBVSxTQUFTLENBQUMsUUFBUSxDQUFDO0FBQUEsTUFDakUsMEJBQTBCLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUM1RDtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsTUFDRCwrQkFBK0IsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQ2pFO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsTUFDRCxpQ0FBaUMsaUJBQWlCLFVBQVUsU0FBUztBQUFBLFFBQ25FO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSCxPQUFPO0FBQ0wsVUFBTSxLQUFLLHdCQUF3QjtBQUFBLE1BQ2pDO0FBQUEsTUFDQSxVQUFVLFdBQVcsYUFBYTtBQUFBLE1BQ2xDLE1BQU0sV0FBVyxPQUFPO0FBQUEsSUFDMUIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxNQUFJLFdBQVcsbUJBQW1CLFNBQVMsR0FBRztBQUM1QyxVQUFNO0FBQUEsTUFDSixXQUFXO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsTUFBSSxXQUFXLE9BQU8sV0FBVyxHQUFHO0FBQ2xDLFVBQU0sZ0JBQWdCLE1BQU07QUFBQSxNQUMxQjtBQUFBLE1BQ0E7QUFBQSxNQUNBLFdBQVc7QUFBQSxNQUNYO0FBQUEsSUFDRjtBQUNBLFFBQUksZ0JBQWdCLEVBQUcsT0FBTSxlQUFlO0FBQzVDO0FBQUEsRUFDRjtBQVdBLFFBQU0sY0FBYyxNQUFNLGtCQUFrQjtBQUM1QyxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxRQUFNLGlCQUFpQixNQUFNLHFCQUFxQjtBQUNsRCxhQUFXLEtBQUssV0FBVyxRQUFRO0FBQ2pDLFFBQUksRUFBRSxjQUFjO0FBQ2xCLFlBQU0sZUFBZSxFQUFFLGdCQUFnQixFQUFFLFFBQVE7QUFBQSxJQUNuRCxPQUFPO0FBQ0wsWUFBTSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUTtBQUFBLElBQ25EO0FBR0EsVUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFFBQUksYUFBYSxVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ2pELGtCQUFZLFdBQVc7QUFDdkIsa0JBQVksYUFBYTtBQUN6QixZQUFNLGtCQUFrQixXQUFXO0FBQUEsSUFDckM7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLHFCQUFxQixjQUFjO0FBQUEsSUFDM0M7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLG1CQUFtQixFQUFFLFFBQVE7QUFDbkMsWUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFlBQU0scUJBQXFCLGNBQWM7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFLQSxhQUFXLFdBQVcsV0FBVyxhQUFhO0FBQzVDLFFBQUksTUFBTSxZQUFZLFFBQVEsUUFBUSxFQUFHO0FBQ3pDLFVBQU0sa0JBQWtCLFFBQVEsYUFBYSxRQUFRLFFBQVE7QUFBQSxFQUMvRDtBQUNBLE1BQUksV0FBVyxZQUFZLFNBQVMsR0FBRztBQUNyQyxVQUFNLEtBQUssMENBQTBDO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLFNBQVMsV0FBVyxZQUFZO0FBQUEsTUFDaEMsYUFBYSxNQUFNLHFCQUFxQjtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNIO0FBZ0JBLFFBQU0saUJBQWlCLFNBQVMsbUJBQW1CO0FBQ25ELFFBQU0sZUFBZSxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLGtCQUFrQixNQUFNLG1CQUFtQjtBQUNqRCxNQUFJLGlCQUFpQjtBQUNyQixNQUFJLHVCQUF1QjtBQUMzQixNQUFJLDBCQUEwQjtBQUM5QixNQUFJLGtCQUFrQjtBQUN0QixNQUFJLG1CQUFtQjtBQUN2QixRQUFNLGFBQXVDLENBQUM7QUFDOUMsUUFBTSxnQkFBZ0Isb0JBQUksSUFBZ0M7QUFDMUQsUUFBTSxhQUFhLG9CQUFJLElBQXFDO0FBQzVELGFBQVcsS0FBSyxXQUFXLFFBQVE7QUFDakMsVUFBTSxPQUFPLGFBQWEsRUFBRSxjQUFjLElBQUksRUFBRSxRQUFRO0FBQ3hELFVBQU0sZ0JBQWdCLENBQUMsUUFBUSx3QkFBd0IsR0FBRyxlQUFlO0FBQ3pFLFVBQU0scUJBQXFCLFFBQVEsSUFBSSxLQUFLO0FBQzVDLGtCQUFjLElBQUksRUFBRSxVQUFVLHFCQUFxQixhQUFhLEtBQUs7QUFDckUsUUFBSSxjQUFlLG9CQUFtQjtBQUN0QyxVQUFNLE1BQU07QUFBQSxNQUNWLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxNQUNGLEVBQUU7QUFBQSxJQUNKO0FBQ0EsVUFBTSxrQkFBa0IsU0FBUyxVQUFhLGtCQUFrQixLQUFLLEdBQUcsS0FBSyxDQUFDLEVBQUU7QUFDaEYsUUFBSSxzQkFBc0IsQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUI7QUFDN0QsVUFBSSxLQUFNLHlCQUF3QjtBQUFBLFVBQzdCLDRCQUEyQjtBQUNoQyxpQkFBVyxJQUFJLEVBQUUsVUFBVSxTQUFTO0FBQ3BDO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxLQUFLLFFBQVEsS0FBSztBQUM1Qix3QkFBa0I7QUFDbEIsaUJBQVcsSUFBSSxFQUFFLFVBQVUsV0FBVztBQUN0QztBQUFBLElBQ0Y7QUFDQSxRQUFJLGdCQUFpQixxQkFBb0I7QUFDekMsZUFBVyxJQUFJLEVBQUUsVUFBVSxVQUFVO0FBQ3JDLGVBQVcsS0FBSyxDQUFDO0FBQUEsRUFDbkI7QUFDQSxNQUFJLGlCQUFpQixHQUFHO0FBQ3RCLFVBQU0sS0FBSyxtQ0FBbUM7QUFBQSxNQUM1QztBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsV0FBVyxXQUFXO0FBQUEsSUFDeEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxNQUFJLHVCQUF1QiwwQkFBMEIsR0FBRztBQUN0RCxVQUFNLGFBQWEsdUJBQXVCO0FBQzFDLFVBQU0sS0FBSyxvRUFBb0U7QUFBQSxNQUM3RTtBQUFBLE1BQ0EsU0FBUztBQUFBLE1BQ1QsYUFBYTtBQUFBLE1BQ2Isa0JBQWtCO0FBQUEsTUFDbEIsV0FBVyxXQUFXO0FBQUEsSUFDeEIsQ0FBQztBQUNELFVBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxRQUFJLFdBQVcsTUFBTTtBQUNuQixhQUFPLG1CQUFtQixPQUFPLG1CQUFtQixLQUFLO0FBQ3pELFlBQU0scUJBQXFCLE1BQU07QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFDQSxNQUFJLGtCQUFrQixLQUFLLGdCQUFnQjtBQUN6QyxVQUFNLEtBQUssMENBQTBDO0FBQUEsTUFDbkQ7QUFBQSxNQUNBLEtBQUs7QUFBQSxNQUNMLFFBQVE7QUFBQSxNQUNSLHVCQUF1QixpQkFBaUIsZ0JBQWdCO0FBQUEsSUFDMUQsQ0FBQztBQUFBLEVBQ0g7QUFDQSxNQUFJLG1CQUFtQixHQUFHO0FBQ3hCLFVBQU0sS0FBSyx1Q0FBdUM7QUFBQSxNQUNoRDtBQUFBLE1BQ0EsVUFBVTtBQUFBLE1BQ1Y7QUFBQSxNQUNBLFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTTtBQUFBLElBQ0osV0FBVyxPQUFPO0FBQUEsTUFBSSxDQUFDLE1BQ3JCO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxjQUFjLElBQUksRUFBRSxRQUFRO0FBQUEsUUFDNUIsV0FBVyxJQUFJLEVBQUUsUUFBUTtBQUFBLE1BQzNCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFTQSxRQUFNLHNCQUFzQixXQUFXLFFBQVEsUUFBUTtBQUN2RCxRQUFNLDRCQUE0QixXQUFXLFFBQVEsTUFBTSxRQUFRO0FBQ25FLFFBQU0sdUJBQXVCLE1BQU07QUFBQSxJQUNqQztBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUNBLE1BQUksV0FBVyxXQUFXLEdBQUc7QUFDM0IsUUFBSSx1QkFBdUIsRUFBRyxPQUFNLGVBQWU7QUFDbkQ7QUFBQSxFQUNGO0FBR0EsUUFBTSxXQUFXLG9CQUFJLElBQThCO0FBQ25ELGFBQVcsS0FBSyxZQUFZO0FBQzFCLFVBQU0sTUFBTSxTQUFTLElBQUksRUFBRSxjQUFjLEtBQUssQ0FBQztBQUMvQyxRQUFJLEtBQUssQ0FBQztBQUNWLGFBQVMsSUFBSSxFQUFFLGdCQUFnQixHQUFHO0FBQUEsRUFDcEM7QUFFQSxhQUFXLENBQUMsUUFBUSxNQUFNLEtBQUssVUFBVTtBQUN2QyxVQUFNLE1BQU0sTUFBTSxnQkFBZ0IsUUFBUSxZQUFZLEtBQUssUUFBUTtBQUNuRSxRQUFJLFFBQVE7QUFDWixRQUFJLFdBQVc7QUFDZixRQUFJLGdCQUFnQjtBQUNwQixRQUFJLGtCQUFrQjtBQUN0QixlQUFXLEtBQUssUUFBUTtBQUN0QixZQUFNLFdBQVcsSUFBSSxhQUFhLEVBQUUsUUFBUTtBQUM1QyxVQUFJLFVBQVU7QUFHWixpQkFBUyxlQUFlO0FBQ3hCLGlCQUFTLGFBQWEsRUFBRTtBQUN4QixpQkFBUyxnQkFBZ0IsRUFBRTtBQUMzQixpQkFBUyxjQUFjLEVBQUU7QUFDekIsaUJBQVMsY0FBYyxFQUFFO0FBQ3pCLGlCQUFTLGFBQWEsRUFBRTtBQUN4QixpQkFBUyxpQkFBaUIsRUFBRTtBQUM1QixjQUFNLE9BQU8sU0FBUyxtQkFBbUIsU0FBUyxtQkFBbUIsU0FBUyxDQUFDO0FBQy9FLGNBQU0sT0FBTyxFQUFFLG1CQUFtQixDQUFDO0FBQ25DLFlBQUksU0FBUyxDQUFDLFFBQVEsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjO0FBQzVELG1CQUFTLG1CQUFtQixLQUFLLElBQUk7QUFBQSxRQUN2QztBQUNBLDJCQUFtQjtBQUFBLE1BQ3JCLE9BQU87QUFDTCxjQUFNLFVBQTBCLEVBQUUsR0FBRyxHQUFHLGdCQUFnQixJQUFJLE9BQU87QUFDbkUsWUFBSSxhQUFhLEVBQUUsUUFBUSxJQUFJO0FBQy9CLGlCQUFTO0FBQ1QsWUFBSSxjQUFjLElBQUksRUFBRSxRQUFRLE1BQU0sV0FBWSxrQkFBaUI7QUFBQSxZQUM5RCxhQUFZO0FBQUEsTUFDbkI7QUFDQSxVQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsR0FBRztBQUNoRCxZQUFJLG1CQUFtQixLQUFLLEVBQUUsUUFBUTtBQUFBLE1BQ3hDO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsbUJBQW1CLEdBQUcsQ0FBQztBQUN0RCxRQUFJLFFBQVEsS0FBSyxrQkFBa0IsR0FBRztBQUNwQyxZQUFNLEtBQUssbUJBQW1CO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSztBQUFBLFFBQ0wsVUFBVTtBQUFBLFFBQ1Ysa0JBQWtCO0FBQUEsUUFDbEIsT0FBTyxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUU7QUFBQSxNQUN2QyxDQUFDO0FBR0QsWUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLFVBQUksV0FBVyxNQUFNO0FBQ25CLGVBQU8saUJBQWlCO0FBQ3hCLGVBQU8sb0JBQW9CLE9BQU8sb0JBQW9CLEtBQUs7QUFDM0QsZUFBTyx5QkFBeUIsT0FBTyx5QkFBeUIsS0FBSztBQUNyRSxjQUFNLHFCQUFxQixNQUFNO0FBQUEsTUFDbkM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsVUFBVSx1QkFBdUI7QUFDakUsWUFBTSxZQUFZLFFBQVEsV0FBVztBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsd0JBQ2IsbUJBQ0EsU0FDQSxZQUNBLFdBQ0EsVUFDZTtBQUNmLFFBQU0sZUFBZSxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsTUFBSSxXQUFXO0FBQ2YsTUFBSSxVQUFVO0FBQ2QsTUFBSSxnQkFBZ0I7QUFFcEIsYUFBVyxLQUFLLG1CQUFtQjtBQUNqQyxVQUFNLFNBQVMsRUFBRTtBQUNqQixRQUFJLENBQUMsUUFBUTtBQUNYLHVCQUFpQjtBQUNqQixZQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsWUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxPQUFPLEtBQUssQ0FBQyxRQUFRLElBQUksT0FBTyxZQUFZLENBQUMsR0FBRztBQUMxRCxpQkFBVztBQUNYO0FBQUEsSUFDRjtBQUVBLFVBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxVQUFNLGVBQWUsUUFBUSxFQUFFLFFBQVE7QUFDdkMsVUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFFBQUksYUFBYSxVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ2pELGtCQUFZLFdBQVc7QUFDdkIsa0JBQVksYUFBYTtBQUN6QixZQUFNLGtCQUFrQixXQUFXO0FBQUEsSUFDckM7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLHFCQUFxQixjQUFjO0FBQUEsSUFDM0M7QUFDQSxRQUFJLGdCQUFnQixVQUFVLFlBQVksRUFBRSxVQUFVO0FBQ3BELHFCQUFlLFdBQVc7QUFDMUIscUJBQWUsYUFBYTtBQUM1QixZQUFNLG1CQUFtQixFQUFFLFFBQVE7QUFDbkMsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBRUEsVUFBTSxNQUFNLGVBQWUsQ0FBQztBQUM1QixVQUFNLE9BQU8sYUFBYSxNQUFNLElBQUksRUFBRSxRQUFRO0FBQzlDLFFBQUksTUFBTSxRQUFRLEtBQUs7QUFDckIsaUJBQVc7QUFDWDtBQUFBLElBQ0Y7QUFFQSxVQUFNLE1BQU0sTUFBTSxnQkFBZ0IsUUFBUSxZQUFZLFdBQVcsUUFBUTtBQUN6RSxVQUFNLGtCQUFrQixJQUFJLHFCQUFxQixDQUFDO0FBQ2xELG9CQUFnQixFQUFFLFFBQVEsSUFBSTtBQUM5QixRQUFJLG9CQUFvQjtBQUN4QixRQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsR0FBRztBQUNoRCxVQUFJLG1CQUFtQixLQUFLLEVBQUUsUUFBUTtBQUFBLElBQ3hDO0FBQ0EsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTSxpQkFBaUIsUUFBUSxtQkFBbUIsR0FBRyxDQUFDO0FBQ3RELGdCQUFZO0FBQUEsRUFDZDtBQUVBLE1BQUksV0FBVyxLQUFLLGdCQUFnQixLQUFLLFVBQVUsR0FBRztBQUNwRCxVQUFNLEtBQUssK0JBQStCLEVBQUUsVUFBVSxVQUFVLFNBQVMsY0FBYyxDQUFDO0FBQUEsRUFDMUY7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxTQUFTLGVBQWUsR0FBNkI7QUFDbkQsU0FBTyxlQUFlLEVBQUUsc0JBQXNCLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFO0FBQzlFO0FBRUEsU0FBUyxrQkFBa0IsS0FBc0I7QUFDL0MsUUFBTSxRQUFRLElBQUksTUFBTSxHQUFHO0FBQzNCLFNBQU8sTUFBTSxNQUFNLFNBQVMsQ0FBQyxNQUFNO0FBQ3JDO0FBRUEsU0FBUyxtQkFBbUIsS0FBd0I7QUFDbEQsU0FDRSxPQUFPLEtBQUssSUFBSSxZQUFZLEVBQUUsU0FDOUIsT0FBTyxLQUFLLElBQUkscUJBQXFCLENBQUMsQ0FBQyxFQUFFLFNBQ3pDLE9BQU8sS0FBSyxJQUFJLHdCQUF3QixDQUFDLENBQUMsRUFBRTtBQUVoRDtBQUVBLFNBQVMsZUFBZSxNQUEyQjtBQUNqRCxTQUFPLENBQUMsS0FBSyxpQkFBaUIsWUFBWSxHQUFHLEtBQUssa0JBQWtCLEtBQUssaUJBQWlCLEVBQUU7QUFBQSxJQUMxRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMscUJBQXFCLE1BQTZCO0FBQ3pELFFBQU0sUUFBUSxLQUFLLE1BQU0sZ0NBQWdDO0FBQ3pELFNBQU8sUUFBUSxDQUFDLEtBQUs7QUFDdkI7QUFFQSxTQUFTLGtCQUNQLFFBQ0EsVUFDQSxZQUNBLFVBQ0EsV0FDZTtBQUNmLFFBQU0sbUJBQW1CLElBQUksSUFBSSxTQUFTLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLFlBQVksR0FBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQzFGLFFBQU0sT0FBTyxJQUFJLElBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUN2RCxRQUFNLE1BQU0sb0JBQUksSUFBeUI7QUFDekMsYUFBVyxLQUFLLFFBQVE7QUFDdEIsUUFBSSxFQUFFLGVBQWUsYUFBYSxDQUFDLEVBQUUsbUJBQW9CO0FBQ3pELFVBQU0sb0JBQW9CLGlCQUFpQixJQUFJLEVBQUUsZUFBZSxZQUFZLENBQUM7QUFDN0UsUUFBSSxDQUFDLGtCQUFtQjtBQUN4QixVQUFNLFdBQVcsS0FBSyxJQUFJLEVBQUUsa0JBQWtCO0FBQzlDLFVBQU0saUJBQ0osVUFBVSxrQkFBa0IscUJBQXFCLEVBQUUsaUJBQWlCLEVBQUUsSUFBSTtBQUM1RSxVQUFNLG1CQUFtQixpQkFDcEIsaUJBQWlCLElBQUksZUFBZSxZQUFZLENBQUMsS0FBSyxXQUN2RDtBQUNKLFVBQU0sT0FBb0I7QUFBQSxNQUN4QixrQkFBa0IsRUFBRTtBQUFBLE1BQ3BCLHNCQUFzQixFQUFFLGNBQWM7QUFBQSxNQUN0QyxvQkFBb0I7QUFBQSxNQUNwQixrQkFBa0IsRUFBRTtBQUFBLE1BQ3BCLGFBQWEsRUFBRTtBQUFBLE1BQ2YsbUJBQW1CLEVBQUU7QUFBQSxNQUNyQix3QkFBd0I7QUFBQSxNQUN4Qiw0QkFBNEIsVUFBVSxjQUFjO0FBQUEsTUFDcEQsMEJBQTBCO0FBQUEsTUFDMUIsYUFBYTtBQUFBLE1BQ2IsZ0JBQWdCO0FBQUEsTUFDaEI7QUFBQSxNQUNBLFlBQVk7QUFBQSxJQUNkO0FBQ0EsUUFBSSxJQUFJLGVBQWUsSUFBSSxHQUFHLElBQUk7QUFBQSxFQUNwQztBQUNBLFNBQU8sQ0FBQyxHQUFHLElBQUksT0FBTyxDQUFDO0FBQ3pCO0FBRUEsZUFBZSxtQkFDYixPQUNBLFlBQ0EsV0FDQSxVQUNpQjtBQUNqQixNQUFJLE1BQU0sV0FBVyxFQUFHLFFBQU87QUFDL0IsUUFBTSxXQUFXLG9CQUFJLElBQTJCO0FBQ2hELGFBQVcsUUFBUSxPQUFPO0FBQ3hCLFVBQU0sTUFBTSxTQUFTLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxDQUFDO0FBQ3BELFFBQUksS0FBSyxJQUFJO0FBQ2IsYUFBUyxJQUFJLEtBQUssa0JBQWtCLEdBQUc7QUFBQSxFQUN6QztBQUNBLE1BQUksUUFBUTtBQUNaLGFBQVcsQ0FBQyxRQUFRLFdBQVcsS0FBSyxVQUFVO0FBQzVDLFVBQU0sTUFBTSxNQUFNLGdCQUFnQixRQUFRLFlBQVksV0FBVyxRQUFRO0FBQ3pFLFVBQU0sVUFBVSxJQUFJLHdCQUF3QixDQUFDO0FBQzdDLFFBQUksaUJBQWlCO0FBQ3JCLGVBQVcsUUFBUSxhQUFhO0FBQzlCLFlBQU0sVUFBdUIsRUFBRSxHQUFHLE1BQU0sZ0JBQWdCLElBQUksT0FBTztBQUNuRSxZQUFNLE1BQU0sZUFBZSxPQUFPO0FBQ2xDLFVBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRyxtQkFBa0I7QUFDckMsY0FBUSxHQUFHLElBQUk7QUFDZixVQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxRQUFRLGdCQUFnQixHQUFHO0FBQzlELFlBQUksbUJBQW1CLEtBQUssUUFBUSxnQkFBZ0I7QUFBQSxNQUN0RDtBQUNBLFVBQUksQ0FBQyxJQUFJLG1CQUFtQixTQUFTLFFBQVEsaUJBQWlCLEdBQUc7QUFDL0QsWUFBSSxtQkFBbUIsS0FBSyxRQUFRLGlCQUFpQjtBQUFBLE1BQ3ZEO0FBQUEsSUFDRjtBQUNBLFFBQUksbUJBQW1CLEVBQUc7QUFDMUIsUUFBSSx1QkFBdUI7QUFDM0IsUUFBSSxDQUFDLElBQUksZUFBZSxTQUFTLFFBQVEsRUFBRyxLQUFJLGVBQWUsS0FBSyxRQUFRO0FBQzVFLFFBQUksa0JBQWtCO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsVUFBTSxpQkFBaUIsUUFBUSxtQkFBbUIsR0FBRyxDQUFDO0FBQ3RELGFBQVM7QUFDVCxVQUFNLEtBQUssMEJBQTBCO0FBQUEsTUFDbkM7QUFBQSxNQUNBO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUCxPQUFPLE9BQU8sS0FBSyxPQUFPLEVBQUU7QUFBQSxJQUM5QixDQUFDO0FBQUEsRUFDSDtBQUNBLFNBQU87QUFDVDtBQXNCQSxlQUFlLHNCQUNiLFFBQ0EsVUFDZTtBQUNmLE1BQUksT0FBTyxXQUFXLEVBQUc7QUFHekIsUUFBTSxlQUFlLG9CQUFJLElBQVk7QUFDckMsYUFBVyxLQUFLLE9BQVEsY0FBYSxJQUFJLEVBQUUsUUFBUTtBQUVuRCxNQUFJLFdBQVc7QUFDZixhQUFXLEtBQUssUUFBUTtBQUN0QixVQUFNLFVBQXNELENBQUM7QUFDN0QsUUFBSSxFQUFFLG1CQUFtQjtBQUN2QixjQUFRLEtBQUssRUFBRSxJQUFJLEVBQUUsbUJBQW1CLE1BQU0sRUFBRSxpQkFBaUIsQ0FBQztBQUFBLElBQ3BFO0FBQ0EsUUFBSSxFQUFFLGdCQUFpQixTQUFRLEtBQUssRUFBRSxJQUFJLEVBQUUsaUJBQWlCLE1BQU0sS0FBSyxDQUFDO0FBQ3pFLFFBQUksRUFBRSxtQkFBb0IsU0FBUSxLQUFLLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixNQUFNLEtBQUssQ0FBQztBQUMvRSxlQUFXLEtBQUssU0FBUztBQUN2QixVQUFJLGFBQWEsSUFBSSxFQUFFLEVBQUUsRUFBRztBQUM1QixVQUFJLE1BQU0sWUFBWSxFQUFFLEVBQUUsRUFBRztBQUM3QixZQUFNLGtCQUFrQixFQUFFLE1BQU0sRUFBRSxFQUFFO0FBQ3BDLGtCQUFZO0FBQUEsSUFDZDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFdBQVcsR0FBRztBQUNoQixVQUFNLEtBQUssc0RBQXNEO0FBQUEsTUFDL0Q7QUFBQSxNQUNBO0FBQUEsTUFDQSxhQUFhLE1BQU0scUJBQXFCO0FBQUEsSUFDMUMsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQUVBLGVBQWUsNEJBQ2IsUUFDQSxhQUNBLFVBQ2U7QUFDZixNQUFJLE9BQU8sV0FBVyxLQUFLLFlBQVksU0FBUyxFQUFHO0FBQ25ELE1BQUksU0FBUyxTQUFTLGFBQWEsS0FBSyxTQUFTLFNBQVMscUJBQXFCLEVBQUc7QUFFbEYsUUFBTSxhQUFhLG9CQUFJLElBQW9CO0FBQzNDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFVBQU0sU0FBUyxFQUFFLGVBQWUsWUFBWTtBQUM1QyxRQUFJLENBQUMsWUFBWSxJQUFJLE1BQU0sRUFBRztBQUU5QixVQUFNLFNBQVMsRUFBRSxtQkFBbUIsRUFBRTtBQUN0QyxVQUFNLFNBQVMsV0FBVyxFQUFFLFlBQVksRUFBRSxzQkFBc0I7QUFDaEUsVUFBTSxjQUFjLEVBQUUsc0JBQXNCO0FBQzVDLFFBQUksVUFBVSxFQUFFLGNBQWMsR0FBRztBQUMvQixpQkFBVyxJQUFJLFFBQVEsRUFBRSxjQUFjO0FBQUEsSUFDekMsV0FBVyxlQUFlLFFBQVE7QUFDaEMsaUJBQVcsSUFBSSxRQUFRLEVBQUUsY0FBYztBQUFBLElBQ3pDO0FBQUEsRUFDRjtBQUVBLE1BQUksV0FBVztBQUNmLGFBQVcsQ0FBQyxTQUFTLE1BQU0sS0FBSyxZQUFZO0FBQzFDLFVBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxVQUFNLGtCQUFrQixRQUFRLE9BQU87QUFDdkMsVUFBTSxRQUFRLE1BQU0scUJBQXFCO0FBQ3pDLFFBQUksUUFBUSxPQUFRLGFBQVk7QUFBQSxFQUNsQztBQUNBLE1BQUksV0FBVyxHQUFHO0FBQ2hCLFVBQU0sS0FBSyx3Q0FBd0M7QUFBQSxNQUNqRDtBQUFBLE1BQ0E7QUFBQSxNQUNBLGFBQWEsTUFBTSxxQkFBcUI7QUFBQSxJQUMxQyxDQUFDO0FBQUEsRUFDSDtBQUNGO0FBRUEsZUFBZSxnQkFDYixRQUNBLElBQ0EsV0FDQSxVQUNvQjtBQUNwQixRQUFNLE1BQU0sTUFBTSxhQUFhLE1BQU07QUFDckMsTUFBSSxJQUFLLFFBQU87QUFDaEIsUUFBTSxNQUFpQjtBQUFBLElBQ3JCLFFBQVEsU0FBUztBQUFBLElBQ2pCLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLGlCQUFpQjtBQUFBLElBQ2pCLGNBQWMsQ0FBQztBQUFBLElBQ2YsbUJBQW1CLENBQUM7QUFBQSxJQUNwQixvQkFBb0IsQ0FBQztBQUFBLElBQ3JCLGdCQUFnQixDQUFDLFFBQVE7QUFBQSxJQUN6QixZQUFZO0FBQUEsRUFDZDtBQUNBLFFBQU0sYUFBYSxRQUFRLEdBQUc7QUFDOUIsUUFBTSxLQUFLLGVBQWUsRUFBRSxRQUFRLEtBQUssV0FBVyxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQ2pFLFNBQU87QUFDVDtBQUlBLElBQUksYUFBNEIsUUFBUSxRQUFRO0FBZ0JoRCxlQUFlLG1CQUFrQztBQUMvQyxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sTUFBTSxLQUFLLElBQUk7QUFDckIsUUFBTSxVQUFvQixDQUFDO0FBQzNCLGFBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQy9DLFVBQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxlQUFlO0FBQzNDLFFBQUksT0FBTyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsZUFBZTtBQUN4RCxjQUFRLEtBQUssTUFBTTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sYUFBYSxTQUFTLE1BQU07QUFDcEM7QUFFQSxlQUFlLDhCQUE2QztBQU8xRCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLEtBQU07QUFDeEQsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLFFBQU0sVUFBb0IsQ0FBQztBQUMzQixhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUMvQyxVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksZUFBZTtBQUMzQyxRQUFJLE9BQU8sU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLGVBQWU7QUFDeEQsY0FBUSxLQUFLLE1BQU07QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsU0FBUyxNQUFNO0FBQ3BDO0FBRUEsZUFBZSxTQUFTLFFBQStCO0FBQ3JELFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxhQUFhLE9BQU8sS0FBSyxHQUFHLEdBQUcsTUFBTTtBQUM3QztBQUVBLGVBQWUsWUFBWSxRQUFnQixRQUErQjtBQUN4RSxRQUFNLGFBQWEsQ0FBQyxNQUFNLEdBQUcsTUFBTTtBQUNyQztBQUVBLGVBQWUsYUFBYSxTQUFtQixRQUErQjtBQUM1RSxRQUFNLFNBQVMsQ0FBQyxHQUFHLElBQUksSUFBSSxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQztBQUMvRCxNQUFJLE9BQU8sV0FBVyxFQUFHO0FBQ3pCLFFBQU0sTUFBTSxXQUFXLEtBQUssTUFBTSxtQkFBbUIsUUFBUSxNQUFNLENBQUM7QUFDcEUsZUFBYSxJQUFJLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUMvQixTQUFPO0FBQ1Q7QUFFQSxlQUFlLG1CQUFtQixTQUFtQixRQUErQjtBQUNsRixRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sUUFBcUIsQ0FBQztBQUM1QixhQUFXLFVBQVUsU0FBUztBQUM1QixVQUFNLE1BQU0sSUFBSSxNQUFNO0FBQ3RCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsVUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJLFlBQVk7QUFDN0MsVUFBTSxvQkFBb0IsT0FBTyxPQUFPLElBQUkscUJBQXFCLENBQUMsQ0FBQztBQUNuRSxVQUFNLGVBQWUsT0FBTyxPQUFPLElBQUksd0JBQXdCLENBQUMsQ0FBQztBQUNqRSxRQUFJLE9BQU8sV0FBVyxLQUFLLGtCQUFrQixXQUFXLEtBQUssYUFBYSxXQUFXLEdBQUc7QUFDdEYsWUFBTSxlQUFlLE1BQU07QUFDM0IsWUFBTSxpQkFBaUIsUUFBUSxDQUFDO0FBQ2hDO0FBQUEsSUFDRjtBQUNBLFVBQU0sS0FBSyxlQUFlLFFBQVEsS0FBSyxRQUFRLG1CQUFtQixZQUFZLENBQUM7QUFBQSxFQUNqRjtBQUNBLE1BQUksTUFBTSxXQUFXLEVBQUc7QUFFeEIsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sS0FBSywrQ0FBK0M7QUFBQSxNQUN4RCxPQUFPLE1BQU07QUFBQSxNQUNiLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLElBQ3ZELENBQUM7QUFDRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsUUFBTSxRQUFRLE1BQU0sUUFBUSxDQUFDLFNBQVM7QUFBQSxJQUNwQztBQUFBLE1BQ0UsTUFBTSxLQUFLO0FBQUEsTUFDWCxlQUFlQyxVQUFTLEtBQUssVUFBVSxLQUFLLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLElBQ3RFO0FBQUEsSUFDQTtBQUFBLE1BQ0UsTUFBTSxLQUFLO0FBQUEsTUFDWCxlQUFlQSxVQUFTLEtBQUssVUFBVSxLQUFLLE1BQU0sTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLElBQ25FO0FBQUEsRUFDRixDQUFDO0FBQ0QsUUFBTSxZQUFZLHdCQUF3QixLQUFLO0FBRS9DLE1BQUk7QUFDRixVQUFNLFNBQVMsTUFBTSxPQUFPLFlBQVk7QUFBQSxNQUN0QztBQUFBLE1BQ0EsU0FBUztBQUFBLElBQ1gsQ0FBQztBQUNELFVBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxlQUFXLFFBQVEsT0FBTztBQUN4QixZQUFNLGlCQUFpQixNQUFNLCtCQUErQixJQUFJO0FBS2hFLFlBQU0sUUFBUSxNQUFNLFlBQVksR0FBRyxLQUFLLE1BQU07QUFDOUMsWUFBTSxTQUFRLG9CQUFJLEtBQUssR0FBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDbEQsWUFBTSxlQUFlLFFBQVEsS0FBSyxjQUFjLFFBQVEsS0FBSyxhQUFhO0FBQzFFLFlBQU0sWUFBWSxLQUFLLFFBQVE7QUFBQSxRQUM3QixZQUFZLGVBQWUsS0FBSyxPQUFPLFNBQVMsS0FBSyxrQkFBa0I7QUFBQSxRQUN2RSxXQUFXO0FBQUEsUUFDWCxlQUFlLEtBQUssSUFBSTtBQUFBLFFBQ3hCLGlCQUNHLE1BQU0sa0JBQWtCLEtBQUssS0FBSyxPQUFPLFNBQVMsS0FBSyxrQkFBa0I7QUFBQSxRQUM1RSxlQUFlO0FBQUEsTUFDakIsQ0FBQztBQUdELFlBQU0sUUFBUSxJQUFJLEtBQUssTUFBTSxLQUFLLENBQUM7QUFDbkMsWUFBTSxVQUFTLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ3RDLGlCQUFXLEtBQUssS0FBSyxRQUFRO0FBQzNCLGNBQU0sRUFBRSxRQUFRLElBQUk7QUFBQSxVQUNsQixJQUFJO0FBQUEsVUFDSixLQUFLO0FBQUEsWUFDSCxFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsWUFDRixFQUFFO0FBQUEsVUFDSjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsaUJBQVcsS0FBSyxLQUFLLG1CQUFtQjtBQUN0QyxjQUFNLEVBQUUsUUFBUSxJQUFJO0FBQUEsVUFDbEIsSUFBSTtBQUFBLFVBQ0osS0FBSyxlQUFlLENBQUM7QUFBQSxRQUN2QjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLEtBQUssTUFBTSxJQUFJO0FBQ25CLFlBQU0sS0FBSywyQkFBMkI7QUFBQSxRQUNwQyxRQUFRLEtBQUs7QUFBQSxRQUNiO0FBQUEsUUFDQSxRQUFRLEtBQUssT0FBTztBQUFBLFFBQ3BCLGFBQWEsS0FBSyxrQkFBa0I7QUFBQSxRQUNwQyxlQUFlLEtBQUssYUFBYTtBQUFBLFFBQ2pDLEtBQUssS0FBSztBQUFBLFFBQ1YsTUFBTSxLQUFLO0FBQUEsUUFDWCxjQUFjLE9BQU87QUFBQSxNQUN2QixDQUFDO0FBQUEsSUFDSDtBQUNBLFVBQU0sa0JBQWtCLEdBQUc7QUFDM0IsVUFBTSxLQUFLLGlDQUFpQztBQUFBLE1BQzFDO0FBQUEsTUFDQSxNQUFNLE1BQU07QUFBQSxNQUNaLE9BQU8sTUFBTTtBQUFBLE1BQ2IsUUFBUSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQUEsTUFDbkUsYUFBYSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLGtCQUFrQixRQUFRLENBQUM7QUFBQSxNQUNuRixlQUFlLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssYUFBYSxRQUFRLENBQUM7QUFBQSxNQUNoRixRQUFRLE9BQU87QUFBQSxJQUNqQixDQUFDO0FBQ0Q7QUFDRSxZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sY0FBYztBQUFBLFFBQ2xCLFFBQVE7QUFBQSxRQUNSLE9BQU8sS0FBSztBQUFBLFFBQ1osWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWUsS0FBSztBQUFBLFFBQ3BCLHdCQUF3QixLQUFLO0FBQUEsUUFDN0Isa0JBQWtCO0FBQUEsTUFDcEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFFBQUksZUFBZSxhQUFhO0FBQzlCLFlBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsWUFBTSxTQUNKLElBQUksYUFBYSxTQUNiLGVBQ0EsSUFBSSxhQUFhLGVBQ2YsaUJBQ0EsSUFBSSxhQUFhLFlBQ2Ysa0JBQ0EsS0FBSztBQUNmLFlBQU0sY0FBYztBQUFBLFFBQ2xCO0FBQUEsUUFDQSxPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPLElBQUk7QUFBQSxRQUNYLGVBQWUsS0FBSztBQUFBLFFBQ3BCLHdCQUF3QixLQUFLO0FBQUEsUUFDN0Isa0JBQ0UsSUFBSSxhQUFhLGVBQWUsSUFBSSxtQkFBbUIsS0FBSztBQUFBLE1BQ2hFLENBQUM7QUFDRCxZQUFNLE1BQU8sd0JBQXdCO0FBQUEsUUFDbkM7QUFBQSxRQUNBLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3JELE1BQU0sTUFBTTtBQUFBLFFBQ1osT0FBTyxNQUFNO0FBQUEsUUFDYixVQUFVLElBQUk7QUFBQSxRQUNkLFFBQVEsSUFBSTtBQUFBLFFBQ1osU0FBUyxJQUFJO0FBQUEsUUFDYixrQkFBa0IsSUFBSTtBQUFBLE1BQ3hCLENBQUM7QUFBQSxJQUNILE9BQU87QUFDTCxZQUFNLE1BQU8sd0JBQXdCO0FBQUEsUUFDbkM7QUFBQSxRQUNBLFNBQVMsTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3JELE1BQU0sTUFBTTtBQUFBLFFBQ1osT0FBTyxNQUFNO0FBQUEsUUFDYixHQUFHLGNBQWMsR0FBRztBQUFBLE1BQ3RCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFFRixVQUFFO0FBQ0EsVUFBTSxlQUFlO0FBQUEsRUFDdkI7QUFDRjtBQUVBLFNBQVMsZUFDUCxRQUNBLEtBQ0EsUUFDQSxtQkFDQSxjQUNXO0FBQ1gsUUFBTSxLQUFLLFdBQVcsSUFBSSxVQUFVO0FBQ3BDLFFBQU0sTUFBTSxJQUFJLFdBQVcsTUFBTSxHQUFHLEVBQUU7QUFDdEMsUUFBTSxXQUFXLFdBQVcsSUFBSSxNQUFNO0FBQ3RDLFFBQU0sVUFBVSxPQUFPLE1BQU0sSUFBSSxFQUFFLElBQUksUUFBUTtBQUMvQyxRQUFNLFdBQVcsUUFBUSxNQUFNLElBQUksRUFBRSxJQUFJLFFBQVE7QUFDakQsU0FBTztBQUFBLElBQ0w7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsU0FBUztBQUFBLE1BQ1AsZ0JBQWdCO0FBQUEsTUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxNQUNwQixnQkFBZ0I7QUFBQSxNQUNoQixhQUFhLElBQUk7QUFBQSxNQUNqQixVQUFVLElBQUksZUFBZSxLQUFLLEdBQUc7QUFBQSxNQUNyQyxZQUFZLFVBQVU7QUFBQSxNQUN0QixZQUFZLElBQUk7QUFBQSxNQUNoQjtBQUFBLE1BQ0Esb0JBQW9CO0FBQUEsTUFDcEIsZUFBZTtBQUFBLElBQ2pCO0FBQUEsSUFDQSxNQUFNO0FBQUEsTUFDSixnQkFBZ0I7QUFBQSxNQUNoQixnQkFBZ0IsSUFBSTtBQUFBLE1BQ3BCLGdCQUFnQjtBQUFBLE1BQ2hCLGFBQWEsSUFBSTtBQUFBLE1BQ2pCLG9CQUFvQixJQUFJO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHdCQUF3QixPQUE0QjtBQUMzRCxNQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLFVBQU0sT0FBTyxNQUFNLENBQUM7QUFDcEIsVUFBTUMsb0JBQW1CLEtBQUssa0JBQWtCO0FBQ2hELFVBQU1DLGFBQVksS0FBSyxhQUFhO0FBQ3BDLFVBQU1DLFdBQ0hGLG9CQUFtQixJQUFJLEtBQUtBLGlCQUFnQixpQkFBaUIsT0FDN0RDLGFBQVksSUFBSSxLQUFLQSxVQUFTLGdCQUFnQkEsZUFBYyxJQUFJLEtBQUssR0FBRyxLQUFLO0FBQ2hGLFdBQU8sWUFBWSxLQUFLLE1BQU0sSUFBSSxLQUFLLEdBQUcsSUFBSSxLQUFLLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxXQUFXLElBQUksS0FBSyxHQUFHLEdBQUdDLE9BQU0sU0FBUyxLQUFLLFFBQVE7QUFBQSxFQUM3STtBQUNBLFFBQU0sT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFLEtBQUs7QUFDOUQsUUFBTSxXQUFXLEtBQUssV0FBVyxJQUFJLEtBQUssQ0FBQyxJQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsS0FBSyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUM7QUFDcEYsUUFBTSxhQUFhLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssT0FBTyxRQUFRLENBQUM7QUFDOUUsUUFBTSxtQkFBbUIsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxrQkFBa0IsUUFBUSxDQUFDO0FBQy9GLFFBQU0sWUFBWSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLGFBQWEsUUFBUSxDQUFDO0FBQ25GLFFBQU0sVUFDSCxtQkFBbUIsSUFBSSxLQUFLLGdCQUFnQixpQkFBaUIsT0FDN0QsWUFBWSxJQUFJLEtBQUssU0FBUyxnQkFBZ0IsY0FBYyxJQUFJLEtBQUssR0FBRyxLQUFLO0FBQ2hGLFNBQU8sa0JBQWtCLE1BQU0sTUFBTSxVQUFVLFVBQVUsU0FBUyxlQUFlLElBQUksS0FBSyxHQUFHLEdBQUcsTUFBTSxLQUFLLFFBQVE7QUFDckg7QUFFQSxlQUFlLCtCQUErQixNQUFrQztBQUM5RSxRQUFNLFVBQVUsTUFBTSxhQUFhLEtBQUssTUFBTTtBQUM5QyxNQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLE1BQUksUUFBUSxXQUFXLEtBQUssSUFBSSxPQUFRLFFBQU8sbUJBQW1CLE9BQU87QUFFekUsUUFBTSxZQUFZLElBQUk7QUFBQSxJQUNwQixLQUFLLE9BQU8sSUFBSSxDQUFDLE1BQU07QUFBQSxNQUNyQixFQUFFO0FBQUEsTUFDRixjQUFjLEVBQUUsWUFBWSxFQUFFLGVBQWUsRUFBRSxhQUFhLEVBQUUsYUFBYSxFQUFFLFlBQVk7QUFBQSxJQUMzRixDQUFDO0FBQUEsRUFDSDtBQUNBLGFBQVcsS0FBSyxLQUFLLG1CQUFtQjtBQUN0QyxjQUFVLElBQUksRUFBRSxVQUFVLGVBQWUsQ0FBQyxDQUFDO0FBQUEsRUFDN0M7QUFDQSxRQUFNLGtCQUFrRCxDQUFDO0FBQ3pELGFBQVcsQ0FBQyxTQUFTLEtBQUssS0FBSyxPQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDbkUsVUFBTSxlQUFlLFVBQVUsSUFBSSxPQUFPO0FBQzFDLFVBQU0sYUFBYTtBQUFBLE1BQ2pCLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxJQUNSO0FBQ0EsUUFBSSxDQUFDLGdCQUFnQixpQkFBaUIsWUFBWTtBQUNoRCxzQkFBZ0IsT0FBTyxJQUFJLEVBQUUsR0FBRyxNQUFNO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBQ0EsUUFBTSx1QkFBeUQsQ0FBQztBQUNoRSxhQUFXLENBQUMsU0FBUyxXQUFXLEtBQUssT0FBTyxRQUFRLFFBQVEscUJBQXFCLENBQUMsQ0FBQyxHQUFHO0FBQ3BGLFVBQU0sZUFBZSxVQUFVLElBQUksT0FBTztBQUMxQyxVQUFNLGFBQWEsZUFBZSxXQUFXO0FBQzdDLFFBQUksQ0FBQyxnQkFBZ0IsaUJBQWlCLFlBQVk7QUFDaEQsMkJBQXFCLE9BQU8sSUFBSSxFQUFFLEdBQUcsWUFBWTtBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUNBLFFBQU0sd0JBQXFELENBQUM7QUFDNUQsYUFBVyxDQUFDLEtBQUssSUFBSSxLQUFLLE9BQU8sUUFBUSxRQUFRLHdCQUF3QixDQUFDLENBQUMsR0FBRztBQUM1RSxRQUFJLENBQUMsS0FBSyxhQUFhLEtBQUssQ0FBQyxrQkFBa0IsZUFBZSxhQUFhLE1BQU0sR0FBRyxHQUFHO0FBQ3JGLDRCQUFzQixHQUFHLElBQUksRUFBRSxHQUFHLEtBQUs7QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxRQUFNLGVBQWUsb0JBQUksSUFBSTtBQUFBLElBQzNCLEdBQUcsT0FBTyxLQUFLLGVBQWU7QUFBQSxJQUM5QixHQUFHLE9BQU8sS0FBSyxvQkFBb0I7QUFBQSxJQUNuQyxHQUFHLE9BQU8sT0FBTyxxQkFBcUIsRUFBRSxRQUFRLENBQUMsU0FBUztBQUFBLE1BQ3hELEtBQUs7QUFBQSxNQUNMLEtBQUs7QUFBQSxJQUNQLENBQUM7QUFBQSxFQUNILENBQUM7QUFDRCxRQUFNLGlCQUNKLE9BQU8sS0FBSyxlQUFlLEVBQUUsU0FDN0IsT0FBTyxLQUFLLG9CQUFvQixFQUFFLFNBQ2xDLE9BQU8sS0FBSyxxQkFBcUIsRUFBRTtBQUNyQyxNQUFJLG1CQUFtQixHQUFHO0FBQ3hCLFVBQU0sZUFBZSxLQUFLLE1BQU07QUFDaEMsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNLFlBQVksU0FBUztBQUMzQixhQUFXLFNBQVMsT0FBTyxPQUFPLGVBQWUsR0FBRztBQUNsRCxVQUFNLGlCQUFpQjtBQUFBLEVBQ3pCO0FBQ0EsYUFBVyxRQUFRLE9BQU8sT0FBTyxxQkFBcUIsR0FBRztBQUN2RCxTQUFLLGlCQUFpQjtBQUFBLEVBQ3hCO0FBQ0EsUUFBTSxhQUFhLEtBQUssUUFBUTtBQUFBLElBQzlCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVksUUFBUTtBQUFBLElBQ3BCLGNBQWM7QUFBQSxJQUNkLG1CQUFtQjtBQUFBLElBQ25CLHNCQUFzQjtBQUFBLElBQ3RCLG9CQUFvQixRQUFRLG1CQUFtQixPQUFPLENBQUMsT0FBTyxhQUFhLElBQUksRUFBRSxDQUFDO0FBQUEsRUFDcEYsQ0FBQztBQUNELFFBQU0sS0FBSyxtQ0FBbUM7QUFBQSxJQUM1QyxRQUFRLEtBQUs7QUFBQSxJQUNiLGVBQWUsS0FBSztBQUFBLElBQ3BCLFVBQVUsV0FBVyxTQUFTO0FBQUEsSUFDOUIsV0FBVztBQUFBLEVBQ2IsQ0FBQztBQUNELFNBQU87QUFDVDtBQUlBLGVBQWUsV0FBVyxRQUErQjtBQUN2RCwyQkFBeUI7QUFNekIsUUFBTSxZQUFZLGlCQUFpQixNQUFNO0FBQ3pDLFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxRQUFRLEtBQUssZUFBZSxDQUFDO0FBQ25FLE1BQUksQ0FBRSxNQUFNLGFBQWEsTUFBTSxHQUFJO0FBQ2pDLFVBQU0sT0FBTSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNuQyxVQUFNLGFBQWEsUUFBUTtBQUFBLE1BQ3pCLFFBQVEsU0FBUztBQUFBLE1BQ2pCLGdCQUFnQjtBQUFBLE1BQ2hCLFlBQVk7QUFBQSxNQUNaLGlCQUFpQjtBQUFBLE1BQ2pCLGNBQWMsQ0FBQztBQUFBLE1BQ2YsbUJBQW1CLENBQUM7QUFBQSxNQUNwQixvQkFBb0IsQ0FBQztBQUFBLE1BQ3JCLGdCQUFnQixDQUFDO0FBQUEsTUFDakIsWUFBWTtBQUFBLElBQ2QsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxXQUFXLFFBQVEsS0FBSyxDQUFDO0FBQzVEO0FBRUEsZUFBZSxhQUE0QjtBQUN6QyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sS0FBSyx5QkFBeUIsRUFBRSxPQUFPLFNBQVMsT0FBTyxDQUFDO0FBQzlELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sV0FBVyxFQUFFLE1BQU07QUFBQSxFQUMzQjtBQUNGO0FBV0EsZUFBZSxrQkFBaUM7QUFDOUMsMkJBQXlCO0FBQ3pCLE1BQUk7QUFDSixNQUFJO0FBQ0YsV0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsUUFBUSxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQUEsRUFDdkUsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlEQUFpRCxjQUFjLEdBQUcsQ0FBQztBQUM5RTtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLE1BQUksQ0FBQyxPQUFPLE9BQU8sSUFBSSxPQUFPLFlBQVksQ0FBQyxJQUFJLEtBQUs7QUFDbEQsVUFBTSxLQUFLLGtDQUFrQztBQUM3QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsZ0NBQWdDLEtBQUssSUFBSSxHQUFHLEdBQUc7QUFDbEQsVUFBTSxLQUFLLCtEQUErRDtBQUFBLE1BQ3hFLEtBQUssV0FBVyxJQUFJLEdBQUc7QUFBQSxJQUN6QixDQUFDO0FBQ0Q7QUFBQSxFQUNGO0FBQ0EsUUFBTSxLQUFLLCtCQUErQixFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBR3RFLE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTyxDQUFDLGNBQWM7QUFBQSxNQUN0QixPQUFPO0FBQUEsSUFDVCxDQUFDO0FBQ0QsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU8sQ0FBQyxZQUFZO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLHVDQUF1QyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ3RFO0FBR0EsTUFBSTtBQUNGLFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPO0FBQUEsTUFDUCxNQUFNLE1BQU07QUFDVixjQUFNLElBQUksT0FBTztBQUNqQixlQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQztBQUNwRCxtQkFBVyxNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDLEdBQUcsR0FBRztBQUMzRSxtQkFBVyxNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDLEdBQUcsSUFBSTtBQUFBLE1BQzlFO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssMENBQTBDLGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDekU7QUFDRjtBQWFBLElBQU0sa0JBQWtCO0FBRXhCLGVBQWUsa0JBQTBDO0FBQ3ZELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksZUFBZTtBQUM5RCxRQUFNLEtBQUssT0FBTyxlQUFlO0FBQ2pDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsZ0JBQWdCLElBQWtDO0FBQy9ELE1BQUksT0FBTyxNQUFNO0FBQ2YsVUFBTSxRQUFRLFFBQVEsTUFBTSxPQUFPLGVBQWU7QUFBQSxFQUNwRCxPQUFPO0FBQ0wsVUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxlQUFlLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDM0Q7QUFDRjtBQUVBLGVBQWUsbUJBQWtDO0FBQy9DLDJCQUF5QjtBQUN6QixRQUFNLFFBQVEsTUFBTSxrQkFBa0I7QUFDdEMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUsseUJBQXlCO0FBQ3BDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxrQkFBa0I7QUFBQSxJQUN0QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELHVCQUFxQixPQUFPO0FBQzVCLE9BQUssWUFBWTtBQUNqQixRQUFNLEtBQUssd0JBQXdCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQzNFLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksd0JBQStEO0FBRW5FLFNBQVMscUJBQXFCLFNBQXVCO0FBQ25ELE1BQUksMEJBQTBCLEtBQU0sZUFBYyxxQkFBcUI7QUFDdkUsMEJBQXdCLFlBQVksTUFBTTtBQUN4QyxTQUFLLFlBQVksRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNoQyxXQUFLLEtBQUssdUJBQXVCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDckQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHNCQUE0QjtBQUNuQyxNQUFJLDBCQUEwQixNQUFNO0FBQ2xDLGtCQUFjLHFCQUFxQjtBQUNuQyw0QkFBd0I7QUFBQSxFQUMxQjtBQUNGO0FBRUEsZUFBZSxvQkFBbUM7QUFDaEQsc0JBQW9CO0FBQ3BCLFFBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxRQUFNLFFBQVEsTUFBTSxnQkFBZ0I7QUFDcEMsUUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixRQUFNLE9BQU8sTUFBTSxrQkFBa0I7QUFDckMsUUFBTSxrQkFBa0IsSUFBSTtBQUM1QixRQUFNLEtBQUssMEJBQTBCO0FBQUEsSUFDbkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxjQUE2QjtBQUMxQyxNQUFJLE9BQU8sTUFBTSxrQkFBa0I7QUFDbkMsTUFBSSxTQUFTLE1BQU07QUFFakIsd0JBQW9CO0FBQ3BCO0FBQUEsRUFDRjtBQUlBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUVBLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFFRCxVQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsZUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsVUFBSSxJQUFJLFNBQVMsS0FBSyxTQUFTLE9BQU8sR0FBRztBQUN2QyxjQUFNLGVBQWUsUUFBUSxLQUFLLFNBQVMsT0FBTztBQUNsRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLGtCQUFrQixJQUFJO0FBQUEsRUFDOUI7QUFFQSxRQUFNLFNBQVMsTUFBTSxrQkFBa0I7QUFDdkMsTUFBSSxDQUFDLFFBQVE7QUFDWCx3QkFBb0I7QUFDcEIsVUFBTSxnQkFBZ0IsSUFBSTtBQUMxQixVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyx5QkFBeUIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ2pFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLE1BQU0saUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUNuRSxNQUFJLFFBQVEsTUFBTSxnQkFBZ0I7QUFDbEMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLGdCQUFnQixJQUFJLEVBQUU7QUFBQSxJQUM5RCxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxXQUFRLE1BQU0sa0JBQWtCLEtBQU07QUFDdEMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLGtCQUFrQixJQUFJO0FBQzVCLFVBQU0sS0FBSyxnQkFBZ0I7QUFBQSxNQUN6QixRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLFdBQVcsTUFBTSxrQkFBa0I7QUFBQSxNQUNuQyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyw0Q0FBNEM7QUFBQSxNQUNyRCxRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sZUFBZSxPQUFPLFFBQVEsT0FBTyxPQUFPO0FBQ2xELFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBV0EsSUFBTSxzQkFBc0I7QUFFNUIsZUFBZSxxQkFBNkM7QUFDMUQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxtQkFBbUI7QUFDbEUsUUFBTSxLQUFLLE9BQU8sbUJBQW1CO0FBQ3JDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsbUJBQW1CLElBQWtDO0FBQ2xFLE1BQUksT0FBTyxLQUFNLE9BQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxtQkFBbUI7QUFBQSxNQUNsRSxPQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUNwRTtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELDJCQUF5QjtBQUN6QixRQUFNLFFBQVEsTUFBTSxxQkFBcUI7QUFDekMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUssNkJBQTZCO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELDBCQUF3QixPQUFPO0FBQy9CLE9BQUssZUFBZTtBQUNwQixRQUFNLEtBQUssNEJBQTRCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQy9FLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksMkJBQWtFO0FBRXRFLFNBQVMsd0JBQXdCLFNBQXVCO0FBQ3RELE1BQUksNkJBQTZCLEtBQU0sZUFBYyx3QkFBd0I7QUFDN0UsNkJBQTJCLFlBQVksTUFBTTtBQUMzQyxTQUFLLGVBQWUsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNuQyxXQUFLLEtBQUssMkJBQTJCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDekQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHlCQUErQjtBQUN0QyxNQUFJLDZCQUE2QixNQUFNO0FBQ3JDLGtCQUFjLHdCQUF3QjtBQUN0QywrQkFBMkI7QUFBQSxFQUM3QjtBQUNGO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQseUJBQXVCO0FBQ3ZCLFFBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sUUFBUSxNQUFNLG1CQUFtQjtBQUN2QyxRQUFNLG1CQUFtQixJQUFJO0FBQzdCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLFVBQVU7QUFBQSxJQUNuQixXQUFXLE1BQU0sYUFBYTtBQUFBLEVBQ2hDLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJLE9BQU8sTUFBTSxxQkFBcUI7QUFDdEMsTUFBSSxTQUFTLE1BQU07QUFDakIsMkJBQXVCO0FBQ3ZCO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZ0JBQWdCO0FBQzVCO0FBQUEsSUFDRjtBQUNBLFVBQU0sS0FBSyxvREFBb0Q7QUFBQSxNQUM3RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFDRCxVQUFNLGtCQUFrQixLQUFLLFNBQVMsT0FBTztBQUM3QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUVBLFFBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxNQUFJLENBQUMsUUFBUTtBQUNYLDJCQUF1QjtBQUN2QixVQUFNLG1CQUFtQixJQUFJO0FBQzdCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLDZCQUE2QixFQUFFLFdBQVcsS0FBSyxVQUFVLENBQUM7QUFDckUsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUdBLE1BQUksTUFBTSxZQUFZLE9BQU8sT0FBTyxHQUFHO0FBQ3JDLFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQU9BLFFBQU0sTUFDSixPQUFPLFdBQVcsYUFDZCw4QkFBOEIsT0FBTyxPQUFPLEtBQzVDLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDN0QsTUFBSSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3JDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxtQkFBbUIsSUFBSSxFQUFFO0FBQUEsSUFDakUsT0FBTztBQUNMLFlBQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQztBQUFBLElBQzFDO0FBQ0EsV0FBUSxNQUFNLHFCQUFxQixLQUFNO0FBQ3pDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLEtBQUssb0JBQW9CO0FBQUEsTUFDN0IsVUFBVSxPQUFPO0FBQUEsTUFDakIsYUFBYSxPQUFPLFdBQVcsYUFBYSxPQUFPLE9BQU87QUFBQSxNQUMxRCxXQUFXLE1BQU0scUJBQXFCO0FBQUEsTUFDdEMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsVUFBVSxPQUFPO0FBQUEsTUFDakIsR0FBRyxjQUFjLEdBQUc7QUFBQSxJQUN0QixDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBU0EsSUFBTSxzQkFBc0I7QUFFNUIsZUFBZSxxQkFBNkM7QUFDMUQsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxtQkFBbUI7QUFDbEUsUUFBTSxLQUFLLE9BQU8sbUJBQW1CO0FBQ3JDLFNBQU8sT0FBTyxPQUFPLFdBQVcsS0FBSztBQUN2QztBQUVBLGVBQWUsbUJBQW1CLElBQWtDO0FBQ2xFLE1BQUksT0FBTyxLQUFNLE9BQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxtQkFBbUI7QUFBQSxNQUNsRSxPQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztBQUNwRTtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELDJCQUF5QjtBQUN6QixRQUFNLFFBQVEsTUFBTSxxQkFBcUI7QUFDekMsTUFBSSxVQUFVLEdBQUc7QUFDZixVQUFNLEtBQUssNkJBQTZCO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sRUFBRSxxQkFBcUIsQ0FBQztBQUFBLEVBQ25FO0FBQ0EsUUFBTSxxQkFBcUI7QUFBQSxJQUN6QixjQUFjO0FBQUEsSUFDZCxXQUFXO0FBQUEsSUFDWCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbEMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNELDBCQUF3QixPQUFPO0FBQy9CLE9BQUssZUFBZTtBQUNwQixRQUFNLEtBQUssNEJBQTRCLEVBQUUsUUFBUSxPQUFPLGNBQWMsUUFBUSxDQUFDO0FBQy9FLFFBQU0sZUFBZTtBQUN2QjtBQUVBLElBQUksMkJBQWtFO0FBRXRFLFNBQVMsd0JBQXdCLFNBQXVCO0FBQ3RELE1BQUksNkJBQTZCLEtBQU0sZUFBYyx3QkFBd0I7QUFDN0UsNkJBQTJCLFlBQVksTUFBTTtBQUMzQyxTQUFLLGVBQWUsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUNuQyxXQUFLLEtBQUssMkJBQTJCLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDekQsQ0FBQztBQUFBLEVBQ0gsR0FBRyxVQUFVLEdBQUk7QUFDbkI7QUFFQSxTQUFTLHlCQUErQjtBQUN0QyxNQUFJLDZCQUE2QixNQUFNO0FBQ3JDLGtCQUFjLHdCQUF3QjtBQUN0QywrQkFBMkI7QUFBQSxFQUM3QjtBQUNGO0FBRUEsZUFBZSx1QkFBc0M7QUFDbkQseUJBQXVCO0FBQ3ZCLFFBQU0sUUFBUSxPQUFPLE1BQU0sa0JBQWtCO0FBQzdDLFFBQU0sUUFBUSxNQUFNLG1CQUFtQjtBQUN2QyxRQUFNLG1CQUFtQixJQUFJO0FBQzdCLFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQU0sS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxTQUFTLFVBQVU7QUFBQSxJQUNuQixXQUFXLE1BQU0sYUFBYTtBQUFBLEVBQ2hDLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJLE9BQU8sTUFBTSxxQkFBcUI7QUFDdEMsTUFBSSxTQUFTLE1BQU07QUFDakIsMkJBQXVCO0FBQ3ZCO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxhQUFhLE1BQU07QUFDMUIsVUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxLQUFLLFNBQVMsV0FBVztBQUNqRSxRQUFJLFVBQVUsZUFBZ0I7QUFDOUIsVUFBTSxLQUFLLG9EQUFvRDtBQUFBLE1BQzdELFVBQVUsS0FBSyxTQUFTO0FBQUEsTUFDeEIsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUNELFVBQU0sbUJBQW1CLEtBQUssU0FBUyxPQUFPO0FBQzlDLFVBQU0sa0JBQWtCLEtBQUssU0FBUyxPQUFPO0FBQzdDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBRUEsUUFBTSxTQUFTLE1BQU0scUJBQXFCO0FBQzFDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsMkJBQXVCO0FBQ3ZCLFVBQU0sbUJBQW1CLElBQUk7QUFDN0IsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLEtBQUssNkJBQTZCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNyRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsTUFBSSxNQUFNLGtCQUFrQixPQUFPLE9BQU8sR0FBRztBQUMzQyxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNLE1BQU0saUJBQWlCLE9BQU8sTUFBTSxXQUFXLE9BQU8sT0FBTztBQUNuRSxNQUFJLFFBQVEsTUFBTSxtQkFBbUI7QUFDckMsTUFBSSxVQUFVLE1BQU07QUFDbEIsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLElBQUksS0FBSztBQUFBLElBQzlCLFFBQVE7QUFDTixjQUFRO0FBQUEsSUFDVjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsUUFBSSxVQUFVLE1BQU07QUFDbEIsWUFBTSxNQUFNLE1BQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsTUFBTSxDQUFDO0FBQzVELFVBQUksT0FBTyxJQUFJLE9BQU8sU0FBVSxPQUFNLElBQUksTUFBTSx3QkFBd0I7QUFDeEUsY0FBUSxJQUFJO0FBQ1osWUFBTSxtQkFBbUIsS0FBSztBQUFBLElBQ2hDLE9BQU87QUFDTCxZQUFNLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUNBLFVBQU0sbUJBQW1CLE9BQU8sT0FBTztBQUN2QyxXQUFRLE1BQU0scUJBQXFCLEtBQU07QUFDekMsU0FBSyxXQUFXO0FBQUEsTUFDZCxTQUFTLE9BQU87QUFBQSxNQUNoQixjQUFhLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDdEM7QUFDQSxVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFdBQUssbUJBQW1CLEtBQUs7QUFBQSxJQUMvQjtBQUNBLFVBQU0sS0FBSyxvQkFBb0I7QUFBQSxNQUM3QixRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLFdBQVcsTUFBTSxxQkFBcUI7QUFBQSxNQUN0QyxXQUFXLEtBQUs7QUFBQSxNQUNoQixnQkFBZ0IsS0FBSztBQUFBLElBQ3ZCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxnREFBZ0Q7QUFBQSxNQUN6RCxRQUFRLE9BQU87QUFBQSxNQUNmLFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sbUJBQW1CLE9BQU8sT0FBTztBQUN2QyxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQUEsRUFDakM7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLG1CQUFtQixPQUE4QjtBQUM5RCxRQUFNLElBQUksUUFBUSxDQUFDLFlBQVksV0FBVyxTQUFTLElBQUksQ0FBQztBQUN4RCxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxNQUFNO0FBQUEsTUFDaEIsT0FBTztBQUFBLE1BQ1AsTUFBTSxNQUFNO0FBQ1YsY0FBTSxJQUFJLE9BQU87QUFDakIsY0FBTSxPQUFPLE1BQU0sT0FBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUM7QUFDdkUsYUFBSztBQUNMLG1CQUFXLE1BQU0sSUFBSTtBQUNyQixtQkFBVyxNQUFNLElBQUk7QUFBQSxNQUN2QjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLG1DQUFtQyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ2xFO0FBQ0Y7QUFJQSxlQUFlLFdBQ2IsUUFDQSxVQUNBLEtBQ0EsS0FDQSxLQUNlO0FBQ2YsUUFBTSxNQUFPLHdCQUF3QixFQUFFLFFBQVEsVUFBVSxLQUFLLEdBQUcsY0FBYyxHQUFHLEVBQUUsQ0FBQztBQUNyRixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLEtBQU07QUFDeEQsUUFBTSxVQUE2QjtBQUFBLElBQ2pDLGdCQUFnQjtBQUFBLElBQ2hCO0FBQUEsSUFDQTtBQUFBLElBQ0EsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3BDLFlBQVk7QUFBQSxJQUNaLE9BQU8sY0FBYyxHQUFHO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxLQUFLLFdBQVcsUUFBUSxXQUFXO0FBQ3pDLFFBQU0sT0FBTyxNQUFNLEtBQUssS0FBSyxVQUFVLE9BQU8sQ0FBQztBQUMvQyxRQUFNLE9BQU8sbUJBQW1CLEVBQUUsSUFBSSxJQUFJO0FBQzFDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxPQUFPLFFBQVE7QUFBQSxNQUNuQjtBQUFBLE1BQ0EsZUFBZUgsVUFBUyxLQUFLLFVBQVUsU0FBUyxNQUFNLENBQUMsSUFBSSxJQUFJO0FBQUEsTUFDL0QsU0FBUyxlQUFlLE1BQU0sSUFBSSxRQUFRO0FBQUEsSUFDNUMsQ0FBQztBQUFBLEVBQ0gsU0FBUyxNQUFNO0FBQ2IsVUFBTSxNQUFPLDRCQUE0QixFQUFFLEdBQUcsY0FBYyxJQUFJLEVBQUUsQ0FBQztBQUFBLEVBQ3JFO0FBQ0Y7QUFFQSxlQUFlLEtBQUssR0FBNEI7QUFDOUMsUUFBTSxNQUFNLElBQUksWUFBWSxFQUFFLE9BQU8sQ0FBQztBQUN0QyxRQUFNLFNBQVMsTUFBTSxPQUFPLE9BQU8sT0FBTyxXQUFXLEdBQUc7QUFDeEQsUUFBTSxNQUFNLE1BQU0sS0FBSyxJQUFJLFdBQVcsTUFBTSxDQUFDLEVBQzFDLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEVBQUUsU0FBUyxHQUFHLEdBQUcsQ0FBQyxFQUMxQyxLQUFLLEVBQUU7QUFDVixTQUFPLElBQUksTUFBTSxHQUFHLENBQUM7QUFDdkI7QUFJQSxlQUFlLGlCQUFpQixPQUErQjtBQUM3RCxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxTQUFTLFNBQVMsQ0FBQyxTQUFTLE1BQU07QUFDdEQsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU87QUFBQSxNQUNQLGVBQWU7QUFBQSxNQUNmLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxNQUFJLENBQUMsT0FBTztBQUlWLFFBQUksS0FBSyxXQUFXLGtCQUFrQixLQUFLLHFCQUFxQixNQUFNO0FBQ3BFLFlBQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSTtBQUMzQyxVQUFJLFNBQVMsS0FBSyxpQkFBa0I7QUFBQSxJQUN0QztBQUtBLFFBQUksS0FBSyxXQUFXO0FBQ2xCLFlBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTO0FBQ2xELFVBQUksTUFBTSw4QkFBK0I7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sSUFBSSxNQUFNLE9BQU8saUJBQWlCO0FBSXhDLFFBQUksV0FBVztBQUNmLFFBQUksU0FBUyxVQUFVLFNBQVMsV0FBVyxFQUFFLGdCQUFnQjtBQUMzRCxpQkFBVyxNQUFNLE9BQU8sYUFBYSxTQUFTLE1BQU07QUFBQSxJQUN0RDtBQUNBLFVBQU0sYUFBYSxTQUFTLGlCQUFpQixLQUFLLEtBQUs7QUFDdkQsUUFBSSxZQUFZLFlBQVk7QUFDMUIsWUFBTSxPQUFPLGtCQUFrQjtBQUFBLElBQ2pDO0FBQ0EsVUFBTSxjQUFjO0FBQUEsTUFDbEIsUUFBUTtBQUFBLE1BQ1IsT0FBTyxFQUFFO0FBQUEsTUFDVCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTztBQUFBLE1BQ1AsZUFBZSxFQUFFO0FBQUEsTUFDakIsd0JBQXdCO0FBQUEsTUFDeEIsa0JBQWtCO0FBQUEsSUFDcEIsQ0FBQztBQUNELFVBQU0sS0FBSyx1QkFBdUI7QUFBQSxNQUNoQyxPQUFPLEVBQUU7QUFBQSxNQUNULE1BQU0sRUFBRTtBQUFBLE1BQ1IsZ0JBQWdCLEVBQUU7QUFBQSxNQUNsQixtQkFBbUIsU0FBUztBQUFBLE1BQzVCLDBCQUEwQjtBQUFBLE1BQzFCLGNBQWMsYUFBYSxZQUFZO0FBQUEsSUFDekMsQ0FBQztBQUNELFFBQUksQ0FBQyxVQUFVO0FBQ2IsWUFBTSxLQUFLLDhDQUE4QztBQUFBLFFBQ3ZELFlBQVksU0FBUztBQUFBLFFBQ3JCLGdCQUFnQixFQUFFO0FBQUEsUUFDbEIsS0FBSyx3Q0FBd0MsRUFBRTtBQUFBLE1BQ2pELENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixVQUFNLE1BQU0sZUFBZSxjQUFjLElBQUksV0FBVztBQUN4RCxVQUFNLFNBQ0osUUFBUSxTQUNKLGVBQ0EsUUFBUSxlQUNOLGlCQUNBLFFBQVEsWUFDTixrQkFDQTtBQUNWLFVBQU0sVUFDSixlQUFlLGVBQWUsUUFBUSxlQUFlLElBQUksbUJBQW1CO0FBQzlFLFVBQU0sY0FBYztBQUFBLE1BQ2xCO0FBQUEsTUFDQSxPQUFPO0FBQUEsTUFDUCxZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDbEMsT0FBTyxjQUFjLEdBQUcsRUFBRTtBQUFBLE1BQzFCLGVBQWU7QUFBQSxNQUNmLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLEtBQUssMkJBQTJCO0FBQUEsTUFDcEMsVUFBVTtBQUFBLE1BQ1Ysa0JBQWtCO0FBQUEsTUFDbEIsR0FBRyxjQUFjLEdBQUc7QUFBQSxJQUN0QixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsb0JBQW9CLE9BQStCO0FBQ2hFLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsS0FBSztBQUNqQixVQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxPQUFPO0FBSVYsVUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFJLEtBQUssV0FBVyxrQkFBa0IsS0FBSyxxQkFBcUIsTUFBTTtBQUNwRSxZQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDM0MsVUFBSSxTQUFTLEtBQUssaUJBQWtCO0FBQUEsSUFDdEM7QUFJQSxVQUFNLGdCQUFnQixNQUFNLHVCQUF1QjtBQUNuRCxRQUFJLGVBQWU7QUFDakIsWUFBTSxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUssTUFBTSxhQUFhO0FBQ2pELFVBQUksT0FBTyxTQUFTLEdBQUcsS0FBSyxNQUFNLDhCQUErQjtBQUFBLElBQ25FO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxhQUFhLFFBQVE7QUFDeEMsVUFBTSxPQUFPLE1BQU0sT0FBTyxhQUFhLHNCQUFzQjtBQUM3RCxRQUFJLENBQUMsTUFBTTtBQUNULFVBQUksTUFBTyxPQUFNLEtBQUssaURBQWlEO0FBQ3ZFLFlBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEMsWUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLFNBQVMsa0JBQWtCLElBQUk7QUFDckMsUUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QixZQUFNLEtBQUssOENBQThDO0FBQ3pELFlBQU0sWUFBWSxDQUFDLEdBQUcsaUJBQWlCLENBQUM7QUFDeEMsWUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRDtBQUFBLElBQ0Y7QUFDQSxVQUFNLFlBQVksTUFBTTtBQUN4QixVQUFNLHVCQUF1QixRQUFRLEtBQUs7QUFDMUMsVUFBTSx3QkFBdUIsb0JBQUksS0FBSyxHQUFFLFlBQVksQ0FBQztBQUNyRCxRQUFJLE1BQU8sT0FBTSxLQUFLLDJCQUEyQixFQUFFLE9BQU8sT0FBTyxPQUFPLENBQUM7QUFBQSxFQUMzRSxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssaURBQWlELGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDaEY7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLHVCQUF1QixRQUFzQixPQUErQjtBQUN6RixRQUFNLE9BQU8sTUFBTSxPQUFPLGFBQWEsb0JBQW9CO0FBQzNELE1BQUksQ0FBQyxNQUFNO0FBQ1QsVUFBTSxtQkFBbUIsSUFBSTtBQUM3QixRQUFJLE1BQU8sT0FBTSxLQUFLLDBEQUEwRDtBQUNoRjtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxXQUFXLHFCQUFxQixLQUFLLE1BQU0sSUFBSSxDQUFZO0FBQ2pFLFVBQU0sbUJBQW1CLFFBQVE7QUFDakMsUUFBSSxPQUFPO0FBQ1QsWUFBTSxLQUFLLDhCQUE4QjtBQUFBLFFBQ3ZDLFVBQVUsT0FBTyxLQUFLLFNBQVMsUUFBUSxFQUFFO0FBQUEsUUFDekMsY0FBYyxTQUFTO0FBQUEsTUFDekIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSywrREFBK0QsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUM5RjtBQUNGO0FBSUEsZUFBZSxpQkFBZ0M7QUFDN0MsUUFBTSxRQUFRLE1BQU0sV0FBVztBQUMvQixVQUFRLFFBQVEsWUFBWSxFQUFFLE1BQU0saUJBQWlCLE1BQU0sQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUM5RTtBQUVBLGVBQWUsYUFBc0M7QUFDbkQsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLFdBQVc7QUFDZixNQUFJO0FBQ0YsVUFBTSxPQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFDM0YsZUFBVyxLQUFLO0FBQUEsRUFDbEIsUUFBUTtBQUFBLEVBR1I7QUFDQSxRQUFNLGdCQUFnQixNQUFNLGtCQUFrQjtBQUM5QyxRQUFNLG1CQUFtQixNQUFNLHFCQUFxQjtBQUNwRCxRQUFNLG1CQUFtQixNQUFNLHFCQUFxQjtBQUNwRCxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSx1QkFBdUIsTUFBTSx3QkFBd0I7QUFDM0QsU0FBTztBQUFBLElBQ0wsU0FBUztBQUFBLElBQ1QsVUFBVSxlQUFlLFFBQVE7QUFBQSxJQUNqQyxZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFlBQVk7QUFBQSxNQUNWLFFBQVEsbUJBQW1CLFFBQVEsb0JBQW9CO0FBQUEsTUFDdkQ7QUFBQSxNQUNBLGFBQWEsZ0JBQWdCLGVBQWU7QUFBQSxNQUM1QyxlQUFlLGdCQUFnQixpQkFBaUI7QUFBQSxNQUNoRCxrQkFBa0IsZ0JBQWdCLG9CQUFvQjtBQUFBLE1BQ3RELHVCQUF1QixnQkFBZ0IseUJBQXlCO0FBQUEsTUFDaEUsaUJBQWlCLGdCQUFnQixtQkFBbUI7QUFBQSxNQUNwRCxlQUFlLGdCQUFnQixpQkFBaUI7QUFBQSxJQUNsRDtBQUFBLElBQ0EsY0FBYztBQUFBLE1BQ1osT0FBTztBQUFBLE1BQ1AsU0FBUywwQkFBMEI7QUFBQSxNQUNuQyxXQUFXLGFBQWEsYUFBYTtBQUFBLE1BQ3JDLGdCQUFnQixhQUFhLGdCQUFnQjtBQUFBLElBQy9DO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxNQUNmLE9BQU87QUFBQSxNQUNQLFNBQVMsNkJBQTZCO0FBQUEsTUFDdEMsV0FBVyxnQkFBZ0IsYUFBYTtBQUFBLE1BQ3hDLGdCQUFnQixnQkFBZ0IsZ0JBQWdCO0FBQUEsSUFDbEQ7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLE1BQ2YsT0FBTztBQUFBLE1BQ1AsU0FBUyw2QkFBNkI7QUFBQSxNQUN0QyxXQUFXLGdCQUFnQixhQUFhO0FBQUEsTUFDeEMsZ0JBQWdCLGdCQUFnQixnQkFBZ0I7QUFBQSxJQUNsRDtBQUFBLElBQ0E7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBeUM7QUFDL0QsU0FBTztBQUFBLElBQ0wsT0FBTyxFQUFFO0FBQUEsSUFDVCxNQUFNLEVBQUU7QUFBQSxJQUNSLFFBQVEsRUFBRTtBQUFBLElBQ1YsU0FBUyxFQUFFO0FBQUEsSUFDWCxhQUFhLEVBQUU7QUFBQSxJQUNmLGNBQWMsRUFBRTtBQUFBLElBQ2hCLHVCQUF1QixFQUFFO0FBQUEsSUFDekIsZ0JBQWdCLEVBQUU7QUFBQSxJQUNsQixzQkFBc0IsRUFBRTtBQUFBLElBQ3hCLFFBQVEsRUFBRSxJQUFJLFNBQVM7QUFBQSxJQUN2QixXQUFXLEVBQUUsSUFBSSxVQUFVLElBQUksRUFBRSxJQUFJLE1BQU0sRUFBRSxJQUFJO0FBQUEsRUFDbkQ7QUFDRjtBQUVBLFNBQVMscUJBQXFCLEtBQStCO0FBQzNELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVLE9BQU0sSUFBSSxNQUFNLDJCQUEyQjtBQUNoRixRQUFNLFdBQVc7QUFDakIsTUFBSSxDQUFDLE1BQU0sUUFBUSxTQUFTLFFBQVEsRUFBRyxPQUFNLElBQUksTUFBTSxtQ0FBbUM7QUFDMUYsUUFBTSxXQUF3QyxDQUFDO0FBQy9DLGFBQVcsU0FBUyxTQUFTLFVBQVU7QUFDckMsUUFBSSxDQUFDLFNBQVMsT0FBTyxVQUFVLFNBQVU7QUFDekMsVUFBTSxNQUFNO0FBQ1osVUFBTSxTQUFTLE9BQU8sSUFBSSxXQUFXLFdBQVcsSUFBSSxTQUFTO0FBQzdELFFBQUksQ0FBQyxVQUFVLFdBQVcsUUFBUztBQUNuQyxVQUFNLFNBQWlDLENBQUM7QUFDeEMsUUFBSSxJQUFJLFVBQVUsT0FBTyxJQUFJLFdBQVcsVUFBVTtBQUNoRCxpQkFBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sUUFBUSxJQUFJLE1BQWlDLEdBQUc7QUFDMUUsWUFBSSxPQUFPLE1BQU0sU0FBVSxRQUFPLENBQUMsSUFBSTtBQUFBLE1BQ3pDO0FBQUEsSUFDRjtBQUNBLGFBQVMsT0FBTyxZQUFZLENBQUMsSUFBSTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxlQUFlLE9BQU8sSUFBSSxrQkFBa0IsV0FBVyxJQUFJLGdCQUFnQjtBQUFBLE1BQzNFLGdCQUFnQixPQUFPLElBQUksbUJBQW1CLFdBQVcsSUFBSSxpQkFBaUI7QUFBQSxNQUM5RSxtQkFBbUIsT0FBTyxJQUFJLHNCQUFzQixXQUFXLElBQUksb0JBQW9CO0FBQUEsTUFDdkYsV0FBVyxPQUFPLElBQUksY0FBYyxXQUFXLElBQUksWUFBWTtBQUFBLE1BQy9EO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQUEsSUFDTCxjQUFjLE9BQU8sU0FBUyxpQkFBaUIsV0FBVyxTQUFTLGVBQWU7QUFBQSxJQUNsRixhQUFZLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHdCQUF3QixHQUFtQixVQUEyQztBQUM3RixNQUFJLENBQUMsU0FBVSxRQUFPO0FBQ3RCLFFBQU0sUUFBUSxTQUFTLFNBQVMsRUFBRSxlQUFlLFlBQVksQ0FBQztBQUM5RCxNQUFJLENBQUMsT0FBTyxlQUFnQixRQUFPO0FBQ25DLFFBQU0sU0FBUyxLQUFLLE1BQU0sRUFBRSxTQUFTO0FBQ3JDLFFBQU0sU0FBUyxLQUFLLE1BQU0sTUFBTSxjQUFjO0FBQzlDLFNBQU8sT0FBTyxTQUFTLE1BQU0sS0FBSyxPQUFPLFNBQVMsTUFBTSxLQUFLLFVBQVU7QUFDekU7QUFFQSxTQUFTLG1CQUNQLEdBQ0EsVUFDQSxRQUNBLFlBQWdDLE9BQ2hDLFNBQWtDLFlBQ25CO0FBQ2YsU0FBTztBQUFBLElBQ0wsVUFBVSxFQUFFO0FBQUEsSUFDWixnQkFBZ0IsRUFBRTtBQUFBLElBQ2xCLFdBQVcsRUFBRTtBQUFBLElBQ2IsTUFBTSxFQUFFLGlCQUFpQixFQUFFO0FBQUEsSUFDM0IsWUFBWSxFQUFFO0FBQUEsSUFDZCxXQUFXLEVBQUU7QUFBQSxJQUNiLFNBQVM7QUFBQSxJQUNUO0FBQUEsSUFDQSxnQkFBZ0IsY0FBYyxhQUFhLFVBQVU7QUFBQSxJQUNyRDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsaUJBQWlCLFNBQWlDO0FBQ3pELFNBQ0UsT0FBTyxZQUFZLFlBQ25CLDZFQUE2RSxLQUFLLE9BQU87QUFFN0Y7QUFFQSxTQUFTLFdBQVcsS0FBcUI7QUFFdkMsUUFBTSxJQUFJLElBQUksS0FBSyxHQUFHO0FBQ3RCLE1BQUksT0FBTyxNQUFNLEVBQUUsUUFBUSxDQUFDLEVBQUcsUUFBTyxJQUFJLFFBQVEsU0FBUyxFQUFFO0FBQzdELFFBQU0sTUFBTSxDQUFDLEdBQVcsSUFBSSxNQUFNLE9BQU8sQ0FBQyxFQUFFLFNBQVMsR0FBRyxHQUFHO0FBQzNELFNBQ0UsR0FBRyxFQUFFLGVBQWUsQ0FBQyxJQUFJLElBQUksRUFBRSxZQUFZLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQ3BFLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQztBQUU5RTtBQUVBLFNBQVMsVUFBVSxHQUFxQjtBQUN0QyxTQUFPLFdBQVcsRUFBRSxLQUFLLGNBQWMsRUFBRSxJQUFJO0FBQy9DO0FBU0EsU0FBUyxlQUFlLE1BQXlCO0FBQy9DLFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUksT0FBTTtBQUNaLFVBQUksT0FBT0EsS0FBSSxlQUFlLFNBQVUsTUFBSyxJQUFJQSxLQUFJLFVBQVU7QUFDL0QsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLFNBQU8sQ0FBQyxHQUFHLElBQUksRUFBRSxLQUFLO0FBQ3hCO0FBT0EsU0FBUyxvQkFBb0IsTUFBZSxVQUFtQztBQUM3RSxRQUFNLFVBQVUsb0JBQUksUUFBZ0I7QUFDcEMsUUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1BLE9BQU07QUFDWixVQUFJQSxLQUFJLGVBQWUsVUFBVTtBQUMvQixlQUFPLE9BQU8sS0FBS0EsSUFBRyxFQUFFLEtBQUs7QUFBQSxNQUMvQjtBQUNBLGlCQUFXLEtBQUssT0FBTyxPQUFPQSxJQUFHLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNsRDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFRQSxTQUFTLGlCQUFpQixNQUFlLFVBQWtCLE1BQXlCO0FBQ2xGLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixNQUFJLFFBQXdDO0FBQzVDLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNQSxPQUFNO0FBQ1osVUFBSUEsS0FBSSxlQUFlLFVBQVU7QUFDL0IsZ0JBQVFBO0FBQ1I7QUFBQSxNQUNGO0FBQ0EsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxNQUFPLFFBQU87QUFDbkIsTUFBSSxNQUFlO0FBQ25CLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVLFFBQU8sSUFBSSxRQUFRLE9BQU8sU0FBUyxPQUFPLEdBQUc7QUFDMUYsVUFBTyxJQUFnQyxHQUFHO0FBQUEsRUFDNUM7QUFDQSxNQUFJLFFBQVEsT0FBVyxRQUFPO0FBQzlCLE1BQUksUUFBUSxLQUFNLFFBQU87QUFDekIsTUFBSSxPQUFPLFFBQVEsU0FBVSxRQUFPLElBQUksT0FBTyxHQUFHO0FBQ2xELE1BQUksTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLGNBQWMsSUFBSSxNQUFNO0FBQ3ZELFNBQU8sT0FBTyxLQUFLLEdBQThCLEVBQUUsS0FBSztBQUMxRDtBQUVBLFNBQVMsV0FBVyxHQUFtQjtBQUdyQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksSUFBSSxDQUFDO0FBQ3hCLFVBQU0sT0FBTyxPQUFPLFlBQVksT0FBTyxTQUFTLFlBQU87QUFDdkQsV0FBTyxPQUFPLFNBQVMsV0FBVyxPQUFPLFNBQVMsZ0JBQzlDLE9BQ0EsR0FBRyxPQUFPLElBQUksR0FBRyxJQUFJO0FBQUEsRUFDM0IsUUFBUTtBQUNOLFdBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUFBLEVBQ2hEO0FBQ0Y7QUFLQyxXQUF1QyxlQUFlO0FBQUEsRUFDckQ7QUFBQSxFQUNBLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFNBQVM7QUFBQSxFQUNULFVBQVUsTUFBTSxTQUFTLFVBQVU7QUFBQSxFQUNuQyxPQUFPO0FBQUEsRUFDUCxjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxlQUFlO0FBQUEsRUFDZixpQkFBaUI7QUFBQSxFQUNqQixpQkFBaUI7QUFBQSxFQUNqQixrQkFBa0I7QUFBQSxFQUNsQixpQkFBaUI7QUFBQSxFQUNqQixpQkFBaUI7QUFBQSxFQUNqQixrQkFBa0I7QUFDcEI7IiwKICAibmFtZXMiOiBbInRvQmFzZTY0IiwgIm9iaiIsICJpbmZvIiwgInRvQmFzZTY0IiwgInVuYXZhaWxhYmxlQ291bnQiLCAiZWRnZUNvdW50IiwgInN1ZmZpeCIsICJvYmoiXQp9Cg==
