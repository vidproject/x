var browser=globalThis.browser??globalThis.chrome;

// src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true,
  lowBandwidthBrowsing: false
};
var AUTO_SCROLL_MIN_SEC = 3;
var AUTO_SCROLL_MAX_SEC = 60;
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" },
  { handle: "StephenM", label: "Stephen Miller", category: "core" },
  { handle: "GregoryKBovino", label: "Gregory Bovino", category: "core" },
  { handle: "RealTomHoman", label: "Thomas D. Homan", category: "core" }
];
var TWEET_ENDPOINTS = /* @__PURE__ */ new Set([
  "UserTweets",
  "UserTweetsAndReplies",
  "UserMedia",
  "UserHighlightsTweets",
  "TweetDetail",
  "TweetResultByRestId",
  "Likes",
  "Bookmarks",
  "HomeTimeline",
  "HomeLatestTimeline",
  "SearchTimeline",
  "ListLatestTweetsTimeline"
]);
var PROFILE_ENDPOINTS = /* @__PURE__ */ new Set(["UserByScreenName", "UserByRestId"]);
var FLUSH_TWEET_THRESHOLD = 200;
var FLUSH_IDLE_MS = 45e3;
var FLUSH_ALARM_MINUTES = 1;
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;
var TWEET_URL_PREFIX = "https://x.com";

// src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  threadOpenQueue: {},
  threadOpenSeen: {},
  refetchSession: null,
  mediaCrawlSession: null,
  threadOpenSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function setAccounts(a) {
  await setRaw("accounts", a);
}
async function getAccountsRefreshedAt() {
  return getRaw("accountsRefreshedAt");
}
async function setAccountsRefreshedAt(iso) {
  await setRaw("accountsRefreshedAt", iso);
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function setArchiveSnapshot(snapshot) {
  await setRaw("archiveSnapshot", snapshot);
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function setConnection(c) {
  await setRaw("connection", c);
}
function todayISO() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function getCounters() {
  return getRaw("counters");
}
async function bumpCounter(handle, patch) {
  const all = await getCounters();
  const cur = all[handle] ?? {
    todayCount: 0,
    todayDate: todayISO(),
    lastCaptureAt: null,
    totalCommitted: 0,
    bufferedCount: 0
  };
  if (cur.todayDate !== todayISO()) {
    cur.todayDate = todayISO();
    cur.todayCount = 0;
  }
  const next = { ...cur, ...patch };
  all[handle] = next;
  await setRaw("counters", all);
  return next;
}
async function setBufferedCount(handle, count) {
  await bumpCounter(handle, { bufferedCount: count });
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getRunBuffer(handle) {
  const all = await getRunBuffers();
  return all[handle] ?? null;
}
async function setRunBuffer(handle, buf) {
  const all = await getRunBuffers();
  all[handle] = buf;
  await setRaw("runBuffers", all);
}
async function clearRunBuffer(handle) {
  const all = await getRunBuffers();
  delete all[handle];
  await setRaw("runBuffers", all);
}
async function getActivity() {
  return getRaw("activity");
}
async function appendActivity(ev) {
  const cur = await getActivity();
  cur.unshift(ev);
  if (cur.length > ACTIVITY_TAIL_MAX) cur.length = ACTIVITY_TAIL_MAX;
  await setRaw("activity", cur);
  return cur;
}
async function clearActivity() {
  await setRaw("activity", []);
}
var RECENT_TWEET_SIGHTINGS_MAX = 80;
async function getRecentTweetSightings() {
  return getRaw("recentTweetSightings");
}
async function prependRecentTweetSightings(rows) {
  if (rows.length === 0) return;
  const cur = await getRecentTweetSightings();
  const seen = /* @__PURE__ */ new Set();
  const next = [];
  for (const row of rows) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  for (const row of cur) {
    const key = `${row.account_handle.toLowerCase()}:${row.tweet_id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    next.push(row);
  }
  next.length = Math.min(next.length, RECENT_TWEET_SIGHTINGS_MAX);
  await setRaw("recentTweetSightings", next);
}
async function getCommittedIndex() {
  return getRaw("committedIndex");
}
async function setCommittedIndex(idx) {
  await setRaw("committedIndex", idx);
}
function engagementSig(likes, retweets, replies, quotes, isTruncated = false) {
  return `${likes}|${retweets}|${replies}|${quotes}|${isTruncated ? "t" : "f"}`;
}
async function pruneCommittedIndex(maxAgeMs) {
  const idx = await getCommittedIndex();
  const cutoff = new Date(Date.now() - maxAgeMs).toISOString();
  let pruned = 0;
  for (const handle of Object.keys(idx)) {
    const inner = idx[handle];
    if (!inner) continue;
    for (const tid of Object.keys(inner)) {
      const e = inner[tid];
      if (e && e.ts < cutoff) {
        delete inner[tid];
        pruned += 1;
      }
    }
    if (Object.keys(inner).length === 0) delete idx[handle];
  }
  if (pruned > 0) await setCommittedIndex(idx);
  return pruned;
}
async function getRefetchQueue() {
  return getRaw("refetchQueue");
}
async function refetchQueueTotal() {
  const q = await getRefetchQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("refetchQueue", q);
  }
}
async function dequeueRefetch(handle, tweetId) {
  const q = await getRefetchQueue();
  const ids = q[handle];
  if (!ids) return;
  const filtered = ids.filter((id) => id !== tweetId);
  if (filtered.length === 0) delete q[handle];
  else q[handle] = filtered;
  await setRaw("refetchQueue", q);
}
async function nextRefetchTarget() {
  const q = await getRefetchQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function getMediaCrawlQueue() {
  return getRaw("mediaCrawlQueue");
}
async function mediaCrawlQueueTotal() {
  const q = await getMediaCrawlQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function enqueueMediaCrawl(hintHandle, tweetId) {
  const q = await getMediaCrawlQueue();
  const bucket = hintHandle ?? "_unknown";
  const ids = q[bucket] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[bucket] = ids;
    await setRaw("mediaCrawlQueue", q);
  }
}
async function dequeueMediaCrawl(tweetId) {
  const q = await getMediaCrawlQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("mediaCrawlQueue", q);
}
async function nextMediaCrawlTarget() {
  const q = await getMediaCrawlQueue();
  for (const [bucket, ids] of Object.entries(q)) {
    if (ids.length > 0) return { bucket, tweetId: ids[0] };
  }
  return null;
}
async function getThreadOpenQueue() {
  return getRaw("threadOpenQueue");
}
async function threadOpenQueueTotal() {
  const q = await getThreadOpenQueue();
  let total = 0;
  for (const ids of Object.values(q)) total += ids.length;
  return total;
}
async function hasThreadOpenSeen(tweetId) {
  const seen = await getRaw("threadOpenSeen");
  return tweetId in seen;
}
async function markThreadOpenSeen(tweetId) {
  const seen = await getRaw("threadOpenSeen");
  seen[tweetId] = (/* @__PURE__ */ new Date()).toISOString();
  await setRaw("threadOpenSeen", seen);
}
async function enqueueThreadOpen(handle, tweetId) {
  if (await hasThreadOpenSeen(tweetId)) return;
  const q = await getThreadOpenQueue();
  const ids = q[handle] ?? [];
  if (!ids.includes(tweetId)) {
    ids.push(tweetId);
    q[handle] = ids;
    await setRaw("threadOpenQueue", q);
  }
}
async function dequeueThreadOpen(tweetId) {
  const q = await getThreadOpenQueue();
  let changed = false;
  for (const bucket of Object.keys(q)) {
    const ids = q[bucket];
    if (!ids) continue;
    const filtered = ids.filter((id) => id !== tweetId);
    if (filtered.length !== ids.length) {
      changed = true;
      if (filtered.length === 0) delete q[bucket];
      else q[bucket] = filtered;
    }
  }
  if (changed) await setRaw("threadOpenQueue", q);
}
async function nextThreadOpenTarget() {
  const q = await getThreadOpenQueue();
  for (const [handle, ids] of Object.entries(q)) {
    if (ids.length > 0) return { handle, tweetId: ids[0] };
  }
  return null;
}
async function isCommitted(tweetId) {
  const idx = await getCommittedIndex();
  for (const inner of Object.values(idx)) {
    if (inner && tweetId in inner) return true;
  }
  return false;
}
async function getRefetchSession() {
  return getRaw("refetchSession");
}
async function setRefetchSession(s) {
  await setRaw("refetchSession", s);
}
async function getMediaCrawlSession() {
  return getRaw("mediaCrawlSession");
}
async function setMediaCrawlSession(s) {
  await setRaw("mediaCrawlSession", s);
}
async function getThreadOpenSession() {
  return getRaw("threadOpenSession");
}
async function setThreadOpenSession(s) {
  await setRaw("threadOpenSession", s);
}
async function getAutoScrollSession() {
  return getRaw("autoScrollSession");
}
async function setAutoScrollSession(s) {
  await setRaw("autoScrollSession", s);
}
async function purgeUnrelatedState(targeted) {
  const targLower = new Set([...targeted].map((h) => h.toLowerCase()));
  const isTargeted = (h) => targLower.has(h.toLowerCase());
  const counters = await getCounters();
  let countersRemoved = 0;
  for (const h of Object.keys(counters)) {
    if (!isTargeted(h)) {
      delete counters[h];
      countersRemoved += 1;
    }
  }
  await setRaw("counters", counters);
  const buffers = await getRunBuffers();
  let buffersRemoved = 0;
  for (const h of Object.keys(buffers)) {
    if (!isTargeted(h)) {
      delete buffers[h];
      buffersRemoved += 1;
    }
  }
  await setRaw("runBuffers", buffers);
  const idx = await getCommittedIndex();
  let committedHandlesRemoved = 0;
  for (const h of Object.keys(idx)) {
    if (!isTargeted(h)) {
      delete idx[h];
      committedHandlesRemoved += 1;
    }
  }
  await setCommittedIndex(idx);
  const rq = await getRefetchQueue();
  let refetchHandlesRemoved = 0;
  for (const h of Object.keys(rq)) {
    if (!isTargeted(h)) {
      delete rq[h];
      refetchHandlesRemoved += 1;
    }
  }
  await setRaw("refetchQueue", rq);
  const mq = await getMediaCrawlQueue();
  let mediaCrawlIdsRemoved = 0;
  for (const h of Object.keys(mq)) {
    if (!isTargeted(h)) {
      mediaCrawlIdsRemoved += (mq[h] ?? []).length;
      delete mq[h];
    }
  }
  await setRaw("mediaCrawlQueue", mq);
  const tq = await getThreadOpenQueue();
  let threadOpenIdsRemoved = 0;
  for (const h of Object.keys(tq)) {
    if (!isTargeted(h)) {
      threadOpenIdsRemoved += (tq[h] ?? []).length;
      delete tq[h];
    }
  }
  await setRaw("threadOpenQueue", tq);
  return {
    countersRemoved,
    buffersRemoved,
    committedHandlesRemoved,
    refetchHandlesRemoved,
    mediaCrawlIdsRemoved,
    threadOpenIdsRemoved
  };
}
async function clearAll() {
  await browser.storage.local.clear();
}

// src/lib/logger.ts
var broadcast = null;
function setBroadcaster(fn) {
  broadcast = fn;
}
function nowISO() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
async function emit(level, msg, context) {
  const ev = { ts: nowISO(), level, msg, context: redact(context) };
  const line = `[imm-archive] ${level.toUpperCase()} ${msg}`;
  if (level === "error") console.error(line, ev.context);
  else if (level === "warn") console.warn(line, ev.context);
  else console.log(line, ev.context);
  try {
    await appendActivity(ev);
  } catch (err) {
    console.warn("[imm-archive] failed to append activity", err);
  }
  try {
    broadcast?.(ev);
  } catch {
  }
}
function info(msg, context = {}) {
  return emit("info", msg, context);
}
function warn(msg, context = {}) {
  return emit("warn", msg, context);
}
function error(msg, context = {}) {
  return emit("error", msg, context);
}
function describeError(err) {
  if (err instanceof Error) {
    return { message: err.message, stack: err.stack ?? null };
  }
  try {
    return { message: String(err), stack: null };
  } catch {
    return { message: "<unprintable error>", stack: null };
  }
}
function redact(ctx) {
  const out = {};
  for (const [k, v] of Object.entries(ctx)) {
    if (k.toLowerCase().includes("token") || k.toLowerCase() === "pat" || k === "authorization") {
      out[k] = "<redacted>";
    } else if (typeof v === "string" && /github_pat_[A-Za-z0-9_]{30,}/.test(v)) {
      out[k] = v.replace(/github_pat_[A-Za-z0-9_]+/g, "github_pat_<redacted>");
    } else if (typeof v === "string" && v.length > 4096) {
      out[k] = `${v.slice(0, 4096)}\u2026<truncated>`;
    } else {
      out[k] = v;
    }
  }
  return out;
}

// src/lib/github.ts
var API_BASE = "https://api.github.com";
var RAW_BASE = "https://raw.githubusercontent.com";
var GitHubError = class extends Error {
  status;
  body;
  retriable;
  category;
  /** When the GitHub rate-limit window for this token resets, as a Unix
   * epoch in seconds. Populated from `X-RateLimit-Reset` on 403/429, or
   * derived from `Retry-After` for secondary limits. null when unknown. */
  rateLimitResetAt;
  constructor(opts) {
    super(opts.message);
    this.name = "GitHubError";
    this.status = opts.status;
    this.body = opts.body;
    this.retriable = opts.retriable;
    this.category = opts.category;
    this.rateLimitResetAt = opts.rateLimitResetAt ?? null;
  }
};
var GitHubClient = class {
  settings;
  constructor(settings) {
    this.settings = settings;
  }
  /** Returns the authenticated user's login. Throws on auth failure. */
  async whoami() {
    const res = await this.fetchJson("GET", "/user");
    return res.login ?? "<unknown>";
  }
  /** Returns true if the given branch exists on the configured repo. */
  async branchExists(branch) {
    try {
      await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/branches/${encodeURIComponent(branch)}`
      );
      return true;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return false;
      throw err;
    }
  }
  /** Verifies the PAT can see the configured repo. */
  async verifyRepoAccess() {
    const me = await this.fetchJson("GET", "/user");
    const repo = await this.fetchJson("GET", `/repos/${this.settings.owner}/${this.settings.repo}`);
    const r = repo;
    return {
      login: me.login,
      full_name: r.full_name,
      default_branch: r.default_branch
    };
  }
  /**
   * Verify the PAT can write to the configured branch without creating a
   * commit. Moving a ref to its current SHA is a no-op, but GitHub still
   * enforces the Contents: Write permission required by commitFiles().
   */
  async verifyWriteAccess() {
    const head = await this.getBranchHead();
    await this.fetchJson(
      "PATCH",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
      {
        sha: head.sha,
        force: false
      }
    );
  }
  /**
   * Fetch a text file from raw.githubusercontent.com authenticated with the
   * PAT. Returns null if the file doesn't exist. Used for config/accounts.yaml.
   */
  async fetchRawText(pathInRepo) {
    const url = `${RAW_BASE}/${this.settings.owner}/${this.settings.repo}/${this.settings.branch}/${pathInRepo}`;
    const res = await fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${this.settings.pat}` }
    });
    if (res.status === 404) return null;
    if (!res.ok) throw await this.makeError(res, `GET raw ${pathInRepo}`);
    return res.text();
  }
  /**
   * Look up an existing file's SHA via the Contents API, or null if not found.
   * Used when retrying a PUT after a 422 sha mismatch.
   */
  async getFileSha(path) {
    try {
      const res = await this.fetchJson(
        "GET",
        `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(this.settings.branch)}`
      );
      const r = res;
      return r.sha ?? null;
    } catch (err) {
      if (err instanceof GitHubError && err.category === "not-found") return null;
      throw err;
    }
  }
  /**
   * PUT a file to the repo. Handles 422 (sha required) by re-fetching the
   * existing sha and retrying once. Retries network / 5xx / rate-limit errors
   * with exponential backoff up to maxAttempts.
   */
  async putFile(opts) {
    const path = opts.path;
    const url = `/repos/${this.settings.owner}/${this.settings.repo}/contents/${encodePath(path)}`;
    let sha = opts.expectedSha ?? null;
    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const body = {
        message: opts.message,
        content: opts.contentBase64,
        branch: this.settings.branch
      };
      if (sha) body.sha = sha;
      try {
        const res = await this.fetchJson("PUT", url, body);
        const out = res;
        return { path: out.content.path, sha: out.content.sha, url: out.content.html_url };
      } catch (err) {
        if (!(err instanceof GitHubError)) throw err;
        if (err.status === 422 && !sha) {
          sha = await this.getFileSha(path);
          if (!sha) throw err;
          continue;
        }
        if (!err.retriable || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw new Error(`putFile: exhausted attempts for ${path}`);
  }
  /**
   * Commit several files with one branch update. The Contents API creates one
   * commit per PUT, so rapid flushes race each other on the branch head. This
   * uses the lower-level Git Data API instead: upload blobs, build a tree,
   * create one commit, then move the branch ref once. If another writer moves
   * the branch first, rebase this tree patch onto the latest head and retry.
   */
  async commitFiles(opts) {
    if (opts.files.length === 0) throw new Error("commitFiles: no files to commit");
    const maxAttempts = 5;
    let lastErr = null;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const blobs = await Promise.all(
          opts.files.map(async (file) => {
            const out = await this.fetchJson(
              "POST",
              `/repos/${this.settings.owner}/${this.settings.repo}/git/blobs`,
              {
                content: file.contentBase64,
                encoding: "base64"
              }
            );
            return {
              path: file.path,
              sha: out.sha
            };
          })
        );
        const head = await this.getBranchHead();
        const tree = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/trees`,
          {
            base_tree: head.treeSha,
            tree: blobs.map((blob) => ({
              path: blob.path,
              mode: "100644",
              type: "blob",
              sha: blob.sha
            }))
          }
        );
        const treeSha = tree.sha;
        const commit = await this.fetchJson(
          "POST",
          `/repos/${this.settings.owner}/${this.settings.repo}/git/commits`,
          {
            message: opts.message,
            tree: treeSha,
            parents: [head.sha]
          }
        );
        const commitOut = commit;
        try {
          await this.fetchJson(
            "PATCH",
            `/repos/${this.settings.owner}/${this.settings.repo}/git/refs/heads/${encodePath(this.settings.branch)}`,
            {
              sha: commitOut.sha,
              force: false
            }
          );
        } catch (err) {
          if (isConflict(err) && attempt < maxAttempts) {
            lastErr = err;
            await sleep(backoffMs(attempt, err));
            continue;
          }
          throw err;
        }
        return {
          commitSha: commitOut.sha,
          url: commitOut.html_url,
          files: opts.files.map((file) => file.path)
        };
      } catch (err) {
        lastErr = err;
        if (!(err instanceof GitHubError)) throw err;
        if (!err.retriable && !isConflict(err) || attempt === maxAttempts) throw err;
        await sleep(backoffMs(attempt, err));
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("commitFiles: exhausted attempts");
  }
  async getBranchHead() {
    const ref = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/ref/heads/${encodePath(this.settings.branch)}`
    );
    const headSha = ref.object.sha;
    const commit = await this.fetchJson(
      "GET",
      `/repos/${this.settings.owner}/${this.settings.repo}/git/commits/${headSha}`
    );
    return {
      sha: headSha,
      treeSha: commit.tree.sha
    };
  }
  async fetchJson(method, path, body) {
    const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
    const init = {
      method,
      headers: {
        Authorization: `Bearer ${this.settings.pat}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        ...body ? { "Content-Type": "application/json" } : {}
      },
      ...body ? { body: JSON.stringify(body) } : {}
    };
    let res;
    try {
      res = await fetch(url, init);
    } catch (netErr) {
      throw new GitHubError({
        status: 0,
        body: null,
        message: `network: ${describeError(netErr).message}`,
        retriable: true,
        category: "network"
      });
    }
    if (res.status === 204) return null;
    let parsed = null;
    const text = await res.text();
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }
    if (!res.ok) throw await this.makeErrorFromParsed(res, parsed, `${method} ${path}`);
    return parsed;
  }
  async makeError(res, label) {
    let parsed = null;
    try {
      const text = await res.text();
      if (text) parsed = JSON.parse(text);
    } catch {
    }
    return this.makeErrorFromParsed(res, parsed, label);
  }
  makeErrorFromParsed(res, body, label) {
    const msg = typeof body === "object" && body && "message" in body ? String(body.message) : res.statusText;
    let category = "unknown";
    let retriable = false;
    if (res.status === 401 || res.status === 403) {
      const rate = res.headers.get("x-ratelimit-remaining");
      if (rate === "0" || /rate limit/i.test(msg)) {
        category = "rate-limit";
        retriable = true;
      } else {
        category = "auth";
      }
    } else if (res.status === 404) {
      category = "not-found";
    } else if (res.status === 409 || res.status === 422) {
      category = "conflict";
    } else if (res.status >= 500) {
      category = "server";
      retriable = true;
    } else if (res.status === 429) {
      category = "rate-limit";
      retriable = true;
    }
    return new GitHubError({
      status: res.status,
      body,
      message: `${label} \u2192 ${res.status}: ${msg}`,
      retriable,
      category,
      rateLimitResetAt: category === "rate-limit" ? parseRateLimitReset(res.headers) : null
    });
  }
};
function parseRateLimitReset(headers) {
  const reset = headers.get("x-ratelimit-reset");
  if (reset) {
    const n = Number.parseInt(reset, 10);
    if (Number.isFinite(n) && n > 0) return n;
  }
  const retryAfter = headers.get("retry-after");
  if (retryAfter) {
    const delta = Number.parseInt(retryAfter, 10);
    if (Number.isFinite(delta) && delta >= 0) {
      return Math.floor(Date.now() / 1e3) + delta;
    }
    const asDate = Date.parse(retryAfter);
    if (Number.isFinite(asDate)) return Math.floor(asDate / 1e3);
  }
  return null;
}
function encodePath(path) {
  return path.split("/").map(encodeURIComponent).join("/");
}
function backoffMs(attempt, err) {
  const base = err.category === "rate-limit" ? 5e3 : 500;
  const jitter = Math.floor(Math.random() * 400);
  return Math.min(6e4, base * 2 ** (attempt - 1) + jitter);
}
function isConflict(err) {
  return err instanceof GitHubError && err.category === "conflict";
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function toBase642(bytes) {
  const utf8 = new TextEncoder().encode(bytes);
  let bin = "";
  for (const b of utf8) bin += String.fromCharCode(b);
  return btoa(bin);
}

// src/lib/normalize.ts
var TWEET_ID_RE = /^\d{15,20}$/;
var PARTIAL_OK_ENDPOINTS = /* @__PURE__ */ new Set(["UserMedia"]);
function normalize(payload, ctx) {
  const rawTweets = collectTweets(payload);
  const tweets = [];
  const unavailableTweets = [];
  const observed = [];
  const built = /* @__PURE__ */ new Set();
  const partialMap = /* @__PURE__ */ new Map();
  const collectPartials = PARTIAL_OK_ENDPOINTS.has(ctx.endpoint);
  for (const raw of rawTweets) {
    try {
      const unavailable = pickUnavailableTweet(raw, ctx);
      if (unavailable) {
        unavailableTweets.push(unavailable);
        observed.push(unavailable.tweet_id);
        built.add(unavailable.tweet_id);
        continue;
      }
      const t = buildTweet(raw, ctx);
      if (!t) {
        if (collectPartials) {
          const partial = pickPartial(raw);
          if (partial) partialMap.set(partial.tweet_id, partial.hint_handle);
        }
        continue;
      }
      observed.push(t.tweet_id);
      built.add(t.tweet_id);
      if (ctx.allowedHandles.size === 0 || ctx.allowedHandles.has(t.account_handle.toLowerCase())) {
        tweets.push(t);
      }
    } catch {
    }
  }
  const partial_ids = [];
  for (const [id, hint] of partialMap) {
    if (built.has(id)) continue;
    partial_ids.push({ tweet_id: id, hint_handle: hint });
  }
  return { tweets, observed_ids: observed, unavailable_tweets: unavailableTweets, partial_ids };
}
function pickUnavailableTweet(node, ctx) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename !== "TweetTombstone") return null;
  const tweetId = strOrNull(n.rest_id) ?? pickTweetIdFromUrls(node) ?? (ctx.sourceUrl ? tweetIdFromTweetUrl(ctx.sourceUrl) : null);
  if (!tweetId || !TWEET_ID_RE.test(tweetId)) return null;
  const unavailableText = pickTombstoneText(node);
  return {
    tweet_id: tweetId,
    account_handle: pickHandleFromTweetUrls(node, tweetId) ?? (ctx.sourceUrl ? handleFromTweetUrl(ctx.sourceUrl, tweetId) : null),
    unavailable_detected_at: ctx.capturedAt,
    unavailable_reason: classifyUnavailableReason(unavailableText),
    unavailable_text: unavailableText,
    unavailable_source_url: ctx.sourceUrl ?? null
  };
}
function pickTweetIdFromUrls(node) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const id = tweetIdFromTweetUrl(cur);
      if (id) return id;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function tweetIdFromTweetUrl(rawUrl) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/[A-Za-z0-9_]{1,15}\/status\/(\d{15,20})(?:\/|$)/);
    return match?.[1] ?? null;
  } catch {
    return null;
  }
}
function pickTombstoneText(node) {
  const strings = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const trimmed = cur.trim();
      if (trimmed.length >= 4 && !trimmed.startsWith("http://") && !trimmed.startsWith("https://")) {
        strings.push(trimmed);
      }
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  const preferred = strings.find(
    (s) => /\b(copyright|dmca|unavailable|withheld|removed|deleted|violat|suspended)\b/i.test(s)
  );
  return preferred ?? strings[0] ?? null;
}
function classifyUnavailableReason(text) {
  if (!text) return null;
  if (/\b(copyright|dmca)\b/i.test(text)) return "copyright";
  if (/\bwithheld\b/i.test(text)) return "withheld";
  if (/\bdeleted|removed\b/i.test(text)) return "removed";
  if (/\bsuspended\b/i.test(text)) return "suspended";
  if (/\bunavailable|not available\b/i.test(text)) return "unavailable";
  return null;
}
function pickPartial(node) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  if (n.__typename === "TweetTombstone") return null;
  const tn = n.__typename;
  if (tn !== "Tweet" && tn !== "TweetWithVisibilityResults" && !obj(n.legacy)) {
    return null;
  }
  const restId = typeof n.rest_id === "string" && n.rest_id || typeof obj(n.tweet_result)?.result === "object" && obj(obj(n.tweet_result)?.result)?.rest_id;
  if (typeof restId !== "string" || !TWEET_ID_RE.test(restId)) return null;
  const hintHandle = pickHintHandle(node, restId);
  if (!hintHandle) return null;
  return { tweet_id: restId, hint_handle: hintHandle };
}
function pickHintHandle(node, tweetId) {
  if (typeof node !== "object" || node === null) return null;
  const n = node;
  const userResult = obj(obj(obj(n.core)?.user_results)?.result);
  return strOrNull(obj(userResult?.core)?.screen_name) ?? strOrNull(obj(userResult?.legacy)?.screen_name) ?? strOrNull(obj(n.legacy)?.screen_name) ?? pickHandleFromTweetUrls(node, tweetId);
}
function pickHandleFromTweetUrls(node, tweetId) {
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const cur = stack.pop();
    if (typeof cur === "string") {
      const handle = handleFromTweetUrl(cur, tweetId);
      if (handle) return handle;
      continue;
    }
    if (cur === null || typeof cur !== "object") continue;
    if (seen.has(cur)) continue;
    seen.add(cur);
    if (Array.isArray(cur)) {
      for (const v of cur) stack.push(v);
    } else {
      for (const v of Object.values(cur)) stack.push(v);
    }
  }
  return null;
}
function handleFromTweetUrl(rawUrl, tweetId) {
  try {
    const url = new URL(rawUrl, TWEET_URL_PREFIX);
    if (url.hostname !== "x.com" && url.hostname !== "twitter.com") return null;
    const match = url.pathname.match(/^\/([A-Za-z0-9_]{1,15})\/status\/(\d{15,20})(?:\/|$)/);
    if (!match || match[2] !== tweetId) return null;
    return match[1] ?? null;
  } catch {
    return null;
  }
}
function collectTweets(obj2) {
  const out = [];
  const seen = /* @__PURE__ */ new WeakSet();
  const stack = [obj2];
  while (stack.length > 0) {
    const node = stack.pop();
    if (node === null || node === void 0) continue;
    if (typeof node !== "object") continue;
    if (seen.has(node)) continue;
    seen.add(node);
    if (looksLikeTweet(node)) {
      out.push(unwrapTweet(node));
    }
    if (Array.isArray(node)) {
      for (const v of node) stack.push(v);
    } else {
      for (const v of Object.values(node)) stack.push(v);
    }
  }
  return out;
}
function looksLikeTweet(node) {
  if (typeof node !== "object" || node === null) return false;
  const n = node;
  const typename = n.__typename;
  if (typename === "Tweet" || typename === "TweetWithVisibilityResults" || typename === "TweetTombstone") {
    return true;
  }
  return typeof n.rest_id === "string" && typeof n.legacy === "object" && n.legacy !== null;
}
function unwrapTweet(node) {
  if (node.__typename === "TweetWithVisibilityResults" && typeof node.tweet === "object") {
    return node.tweet;
  }
  return node;
}
function buildTweet(raw, ctx) {
  if (typeof raw !== "object" || raw === null) return null;
  const t = raw;
  if (t.__typename === "TweetTombstone") return null;
  const restId = strOrNull(t.rest_id);
  const legacy = obj(t.legacy) ?? {};
  if (!restId) return null;
  const core = obj(t.core);
  const userResult = obj(obj(core?.user_results)?.result);
  const userCoreNew = obj(userResult?.core);
  const userLegacy = obj(userResult?.legacy);
  const userAvatarObj = obj(userResult?.avatar);
  const handle = strOrNull(userCoreNew?.screen_name) ?? strOrNull(userLegacy?.screen_name) ?? strOrNull(userResult?.screen_name) ?? strOrNull(legacy.screen_name);
  const accountId = strOrNull(userResult?.rest_id) ?? strOrNull(userResult?.id_str) ?? strOrNull(legacy.user_id_str);
  if (!handle || !accountId) return null;
  const author = extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj);
  const noteTweet = obj(obj(obj(t.note_tweet)?.note_tweet_results)?.result);
  const textFromNote = strOrNull(noteTweet?.text);
  const textFromLegacy = strOrNull(legacy.full_text) ?? "";
  const text = textFromNote ?? textFromLegacy;
  const isTruncated = detectTruncation(noteTweet, legacy, textFromLegacy);
  const communityNote = extractCommunityNote(t, legacy, ctx.capturedAt);
  const entities = obj(legacy.entities) ?? {};
  const entitiesFromNote = obj(noteTweet?.entity_set);
  const hashtags = extractHashtags(entitiesFromNote ?? entities);
  const mentions = extractMentions(entitiesFromNote ?? entities);
  const urls = extractUrls(entitiesFromNote ?? entities);
  const media = extractMedia(legacy);
  const tweetType = classifyTweetType(t, legacy);
  const postedAt = parseTwitterDate(strOrNull(legacy.created_at)) ?? parseTwitterDate(strOrNull(t.created_at));
  if (!postedAt) return null;
  const views = obj(t.views);
  const viewCount = numOrNull(views?.count) ?? numOrNull(strOrNull(views?.count));
  const card = extractCard(t);
  const place = obj(legacy.place);
  const tweet = {
    tweet_id: restId,
    account_handle: handle,
    account_id: accountId,
    posted_at: postedAt,
    first_captured_at: ctx.capturedAt,
    last_seen_at: ctx.capturedAt,
    deletion_detected_at: null,
    unavailable_detected_at: null,
    unavailable_reason: null,
    unavailable_text: null,
    unavailable_source_url: null,
    tweet_url: `${TWEET_URL_PREFIX}/${handle}/status/${restId}`,
    tweet_type: tweetType,
    conversation_id: strOrNull(legacy.conversation_id_str),
    reply_to_tweet_id: strOrNull(legacy.in_reply_to_status_id_str),
    reply_to_account: strOrNull(legacy.in_reply_to_screen_name),
    reply_to_account_id: strOrNull(legacy.in_reply_to_user_id_str),
    quoted_tweet_id: strOrNull(legacy.quoted_status_id_str),
    retweeted_tweet_id: strOrNull(
      obj(obj(legacy.retweeted_status_result)?.result)?.rest_id ?? legacy.retweeted_status_id_str
    ),
    text,
    text_resolved: resolveShortUrls(text, urls),
    lang: strOrNull(legacy.lang),
    possibly_sensitive: boolOrNull(legacy.possibly_sensitive),
    source: strOrNull(legacy.source) ?? strOrNull(t.source),
    place_full_name: strOrNull(place?.full_name),
    hashtags,
    mentions,
    urls,
    card,
    media,
    like_count: numOrZero(legacy.favorite_count),
    retweet_count: numOrZero(legacy.retweet_count),
    reply_count: numOrZero(legacy.reply_count),
    quote_count: numOrZero(legacy.quote_count),
    view_count: viewCount,
    bookmark_count: numOrNull(legacy.bookmark_count),
    engagement_history: [
      {
        captured_at: ctx.capturedAt,
        likes: numOrZero(legacy.favorite_count),
        retweets: numOrZero(legacy.retweet_count),
        replies: numOrZero(legacy.reply_count),
        quotes: numOrZero(legacy.quote_count),
        views: viewCount,
        bookmarks: numOrNull(legacy.bookmark_count)
      }
    ],
    author,
    community_note: communityNote,
    is_truncated: isTruncated,
    wayback_url: null,
    wayback_submitted_at: null,
    capture_source: "extension",
    capture_run_id: ctx.runId,
    schema_version: 1
  };
  return tweet;
}
function classifyTweetType(t, legacy) {
  if (legacy.retweeted_status_result || legacy.retweeted_status_id_str) return "retweet";
  if (legacy.in_reply_to_status_id_str) return "reply";
  if (legacy.is_quote_status === true || legacy.quoted_status_id_str) return "quote";
  if (t.__typename === "TweetWithVisibilityResults") {
  }
  return "original";
}
function extractHashtags(entities) {
  const arr = entities.hashtags;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (h) => typeof h === "object" && h && "text" in h ? String(h.text) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractMentions(entities) {
  const arr = entities.user_mentions;
  if (!Array.isArray(arr)) return [];
  return arr.map(
    (u) => typeof u === "object" && u && "screen_name" in u ? String(u.screen_name) : null
  ).filter((s) => typeof s === "string" && s.length > 0);
}
function extractUrls(entities) {
  const arr = entities.urls;
  if (!Array.isArray(arr)) return [];
  const out = [];
  for (const u of arr) {
    if (typeof u !== "object" || u === null) continue;
    const o = u;
    const short = strOrNull(o.url);
    const expanded = strOrNull(o.expanded_url);
    const display = strOrNull(o.display_url);
    if (!short || !expanded) continue;
    out.push({ short, expanded, display: display ?? expanded });
  }
  return out;
}
function extractMedia(legacy) {
  const extended = obj(legacy.extended_entities);
  const fromExt = extended ? toArray(extended.media) : [];
  const fromEnt = toArray(obj(legacy.entities)?.media);
  const seen = /* @__PURE__ */ new Set();
  const merged = [...fromExt, ...fromEnt].filter((m) => {
    if (typeof m !== "object" || m === null) return false;
    const id = strOrNull(m.media_key) ?? strOrNull(m.id_str);
    if (!id) return false;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
  return merged.map((raw) => buildMedia(raw));
}
function buildMedia(m) {
  const type = strOrNull(m.type);
  const original = pickOriginalUrl(m, type);
  const info2 = obj(m.original_info);
  const videoInfo = obj(m.video_info);
  const durationMs = numOrNull(videoInfo?.duration_millis);
  const altText = strOrNull(m.ext_alt_text);
  const mediaId = strOrNull(m.media_key) ?? strOrNull(m.id_str) ?? `${type ?? "media"}-${Math.random().toString(36).slice(2)}`;
  return {
    media_id: mediaId,
    media_type: type ?? "photo",
    original_url: original ?? "",
    release_asset_url: null,
    sha256: null,
    bytes: null,
    duration_sec: durationMs !== null ? durationMs / 1e3 : null,
    width: numOrNull(info2?.width),
    height: numOrNull(info2?.height),
    alt_text: altText,
    archive_status: "pending",
    archive_attempts: 0,
    last_attempt_at: null
  };
}
function pickOriginalUrl(m, type) {
  if (type === "photo") return strOrNull(m.media_url_https) ?? strOrNull(m.media_url);
  const variants = toArray(obj(m.video_info)?.variants);
  if (variants.length === 0) return strOrNull(m.media_url_https);
  let best = null;
  for (const v of variants) {
    const ct = strOrNull(v.content_type);
    const url = strOrNull(v.url);
    if (!url) continue;
    if (ct === "video/mp4") {
      const br = numOrNull(v.bitrate) ?? 0;
      if (!best || br > best.bitrate) best = { url, bitrate: br };
    } else if (!best) {
      best = { url, bitrate: 0 };
    }
  }
  return best?.url ?? null;
}
function resolveShortUrls(text, urls) {
  if (urls.length === 0) return text;
  let out = text;
  for (const u of urls) out = out.split(u.short).join(u.expanded);
  return out;
}
function parseTwitterDate(s) {
  if (!s) return null;
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}
function strOrNull(v) {
  return typeof v === "string" && v.length > 0 ? v : null;
}
function boolOrNull(v) {
  return typeof v === "boolean" ? v : null;
}
function numOrNull(v) {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string" && v.length > 0) {
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}
function numOrZero(v) {
  return numOrNull(v) ?? 0;
}
function obj(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function toArray(v) {
  return Array.isArray(v) ? v : [];
}
function detectTruncation(noteTweet, legacy, fullText) {
  if (noteTweet) return false;
  if (!fullText) return false;
  const entities = obj(legacy.entities);
  const urls = entities ? entities.urls : null;
  if (Array.isArray(urls)) {
    for (const u of urls) {
      if (typeof u !== "object" || u === null) continue;
      const exp = u.expanded_url;
      if (typeof exp === "string" && /\/i\/web\/status\/\d+/.test(exp)) {
        return true;
      }
    }
  }
  return false;
}
function filterRelated(tweets, targeted, coreHandles = /* @__PURE__ */ new Set()) {
  if (targeted.size === 0 && coreHandles.size === 0) return tweets;
  const referencedIds = /* @__PURE__ */ new Set();
  const targetedTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (!targeted.has(t.account_handle.toLowerCase())) continue;
    targetedTweetIds.add(t.tweet_id);
    if (t.quoted_tweet_id) referencedIds.add(t.quoted_tweet_id);
    if (t.retweeted_tweet_id) referencedIds.add(t.retweeted_tweet_id);
    if (t.reply_to_tweet_id) referencedIds.add(t.reply_to_tweet_id);
  }
  return tweets.filter((t) => {
    const h = t.account_handle.toLowerCase();
    if (targeted.has(h)) return true;
    if (coreHandles.has(h)) return true;
    if (referencedIds.has(t.tweet_id)) return true;
    if (t.quoted_tweet_id && targetedTweetIds.has(t.quoted_tweet_id)) return true;
    if (t.reply_to_tweet_id && targetedTweetIds.has(t.reply_to_tweet_id)) return true;
    if (t.reply_to_account && targeted.has(t.reply_to_account.toLowerCase())) return true;
    for (const m of t.mentions) {
      if (targeted.has(m.toLowerCase())) return true;
    }
    return false;
  });
}
function extractCommunityNote(t, legacy, observedAt) {
  const pivot = obj(t.birdwatch_pivot) ?? obj(legacy.birdwatch_pivot);
  if (!pivot) return null;
  const subtitle = obj(pivot.subtitle);
  const note = obj(pivot.note);
  const summary = strOrNull(subtitle?.text);
  const title = strOrNull(pivot.title);
  const shortTitle = strOrNull(pivot.shortTitle);
  const destinationUrl = strOrNull(pivot.destinationUrl);
  const noteId = strOrNull(pivot.noteId) ?? strOrNull(note?.rest_id);
  if (!summary && !title && !noteId) return null;
  return {
    note_id: noteId,
    title,
    short_title: shortTitle,
    summary,
    destination_url: destinationUrl,
    observed_at: observedAt
  };
}
function extractUserSnapshot(userResult, userCoreNew, userLegacy, userAvatarObj) {
  const verification = obj(userResult?.verification);
  return {
    display_name: strOrNull(userCoreNew?.name) ?? strOrNull(userLegacy?.name) ?? strOrNull(userResult?.name),
    avatar_url: strOrNull(userAvatarObj?.image_url) ?? strOrNull(userLegacy?.profile_image_url_https) ?? strOrNull(userResult?.profile_image_url_https),
    verified: boolOrNull(verification?.verified) ?? boolOrNull(userLegacy?.verified),
    is_blue_verified: boolOrNull(userResult?.is_blue_verified),
    verified_type: strOrNull(verification?.verified_type) ?? strOrNull(userLegacy?.verified_type),
    description: strOrNull(userLegacy?.description),
    location: strOrNull(obj(userResult?.location)?.location) ?? strOrNull(userLegacy?.location),
    url: strOrNull(userLegacy?.url),
    followers_count: numOrNull(userLegacy?.followers_count),
    friends_count: numOrNull(userLegacy?.friends_count),
    statuses_count: numOrNull(userLegacy?.statuses_count),
    account_created_at: parseTwitterDate(strOrNull(userCoreNew?.created_at)) ?? parseTwitterDate(strOrNull(userLegacy?.created_at)),
    protected: boolOrNull(userLegacy?.protected)
  };
}
function extractCard(t) {
  const card = obj(t.card);
  const cardLegacy = obj(card?.legacy);
  if (!cardLegacy) return null;
  const bindings = cardLegacy.binding_values;
  const byKey = {};
  if (Array.isArray(bindings)) {
    for (const bv of bindings) {
      if (typeof bv !== "object" || bv === null) continue;
      const o = bv;
      const k = strOrNull(o.key);
      const v = obj(o.value);
      if (!k || !v) continue;
      byKey[k] = strOrNull(v.string_value) ?? strOrNull(obj(v.image_value)?.url) ?? strOrNull(obj(v.image_color_value)?.palette);
    }
  }
  const name = strOrNull(cardLegacy.name);
  const cardUrl = strOrNull(cardLegacy.url);
  const vendorUrl = typeof byKey["vanity_url"] === "string" ? byKey["vanity_url"] : null;
  const title = typeof byKey["title"] === "string" ? byKey["title"] : null;
  const description = typeof byKey["description"] === "string" ? byKey["description"] : null;
  const imageUrl = (typeof byKey["photo_image_full_size_original"] === "string" ? byKey["photo_image_full_size_original"] : null) ?? (typeof byKey["thumbnail_image_original"] === "string" ? byKey["thumbnail_image_original"] : null) ?? (typeof byKey["summary_photo_image_original"] === "string" ? byKey["summary_photo_image_original"] : null);
  if (!name && !title && !description && !imageUrl) return null;
  return {
    name,
    card_url: cardUrl,
    vendor_url: vendorUrl,
    title,
    description,
    image_url: imageUrl
  };
}

// src/lib/runids.ts
var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
function newRunId() {
  const ts = Date.now();
  let tsPart = "";
  let t = ts;
  for (let i = 0; i < 10; i++) {
    tsPart = (ALPHABET[t % 32] ?? "0") + tsPart;
    t = Math.floor(t / 32);
  }
  const rand = crypto.getRandomValues(new Uint8Array(10));
  let randPart = "";
  for (const b of rand) randPart += ALPHABET[b % 32] ?? "0";
  return tsPart + randPart;
}
function shortRunId(id) {
  return id.slice(-8);
}

// src/lib/yaml.ts
var VALID_CATEGORIES = /* @__PURE__ */ new Set([
  "core",
  "government",
  "officials",
  "public_figures",
  "public"
]);
function parseAccountsYaml(text) {
  const accounts = [];
  let current = {};
  let inAccounts = false;
  const flush = () => {
    if (current.handle && current.label) {
      if (!current.category) current.category = "core";
      accounts.push(current);
    }
  };
  for (const rawLine of text.split("\n")) {
    const line = stripComments(rawLine);
    if (line.trim() === "") continue;
    if (/^accounts\s*:/.test(line)) {
      inAccounts = true;
      continue;
    }
    if (!inAccounts) continue;
    const itemMatch = line.match(/^\s*-\s*handle\s*:\s*(.+)$/);
    if (itemMatch) {
      flush();
      current = { handle: unquote(itemMatch[1] ?? "") };
      continue;
    }
    const handleOnly = line.match(/^\s*handle\s*:\s*(.+)$/);
    if (handleOnly && !line.includes("-")) {
      flush();
      current = { handle: unquote(handleOnly[1] ?? "") };
      continue;
    }
    const labelMatch = line.match(/^\s*label\s*:\s*(.+)$/);
    if (labelMatch && current.handle) {
      current.label = unquote(labelMatch[1] ?? "");
      continue;
    }
    const categoryMatch = line.match(/^\s*category\s*:\s*(.+)$/);
    if (categoryMatch && current.handle) {
      const raw = unquote(categoryMatch[1] ?? "");
      current.category = VALID_CATEGORIES.has(raw) ? raw : "core";
      continue;
    }
  }
  flush();
  return accounts.filter((a) => a.handle.length > 0);
}
function stripComments(line) {
  const idx = line.indexOf("#");
  return idx === -1 ? line : line.slice(0, idx);
}
function unquote(s) {
  const trimmed = s.trim();
  if (trimmed.startsWith('"') && trimmed.endsWith('"') || trimmed.startsWith("'") && trimmed.endsWith("'")) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

// src/background.ts
var EXT_VERSION = browser.runtime.getManifest().version;
var MANUAL_CAPTURE_WINDOW_MS = 9e4;
var LOW_BANDWIDTH_BASE_RULE_ID = 760001;
var LOW_BANDWIDTH_MEDIA_RULE_ID_BASE = 760010;
var LOW_BANDWIDTH_RESOURCE_TYPES = ["image", "media", "font"];
var LOW_BANDWIDTH_MEDIA_CHUNK_RESOURCE_TYPES = ["media", "xmlhttprequest", "other"];
var LOW_BANDWIDTH_MEDIA_URL_FILTERS = [
  "||video.twimg.com^",
  "||ton.twimg.com^",
  "||amp.twimg.com^",
  "||video.pscp.tv^",
  "||prod-fastly-us-west-1.video.pscp.tv^",
  "|https://x.com/i/videos/",
  "|https://twitter.com/i/videos/"
];
var manualCaptureUntilMs = 0;
setBroadcaster((ev) => {
  browser.runtime.sendMessage({ type: "log-event", event: ev }).catch(() => {
  });
});
function allowManualCaptureWindow() {
  manualCaptureUntilMs = Date.now() + MANUAL_CAPTURE_WINDOW_MS;
}
browser.runtime.onInstalled.addListener(async () => {
  await info("extension installed", { version: EXT_VERSION });
  await onWake("install");
});
browser.runtime.onStartup.addListener(() => {
  void onWake("startup");
});
void onWake("module-load");
async function onWake(reason) {
  try {
    await ensureAlarms();
    await ensureAutoScrollAlarm();
    await syncLowBandwidthRules({ reason: `wake:${reason}`, log: false });
    await flushOrphanedBuffersIfStale();
    await reinjectIntoOpenTabs();
    const pruned = await pruneCommittedIndex(30 * 24 * 60 * 60 * 1e3);
    if (pruned > 0) await info("pruned committed index", { pruned });
    const settings = await getSettings();
    if (settings.pat && settings.owner && settings.repo) {
      await verifyConnection(false);
      await refreshAccountsList(false);
    } else {
      await setConnection({
        status: "not-configured",
        login: null,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: null,
        configuredBranchExists: null,
        rateLimitResetAt: null
      });
      await info("extension awake; settings incomplete", { reason });
    }
  } catch (err) {
    await error("wake failed", { reason, ...describeError(err) });
  }
}
function dnrApi() {
  const maybeBrowser = browser;
  return maybeBrowser.declarativeNetRequest ?? null;
}
async function currentXTabIds() {
  const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  return tabs.flatMap((tab) => typeof tab.id === "number" ? [tab.id] : []);
}
async function syncLowBandwidthRules({
  reason,
  log
}) {
  const settings = await getSettings();
  const dnr = dnrApi();
  if (!dnr) {
    if (settings.lowBandwidthBrowsing && log) {
      await warn("low-bandwidth browsing unavailable; declarativeNetRequest API missing", {
        reason
      });
    }
    return;
  }
  const tabIds = settings.lowBandwidthBrowsing ? await currentXTabIds() : [];
  const removeRuleIds = [
    LOW_BANDWIDTH_BASE_RULE_ID,
    ...LOW_BANDWIDTH_MEDIA_URL_FILTERS.map((_, idx) => LOW_BANDWIDTH_MEDIA_RULE_ID_BASE + idx)
  ];
  const addRules = tabIds.length > 0 ? [
    {
      id: LOW_BANDWIDTH_BASE_RULE_ID,
      priority: 1,
      action: { type: "block" },
      condition: {
        tabIds,
        resourceTypes: [...LOW_BANDWIDTH_RESOURCE_TYPES]
      }
    },
    ...LOW_BANDWIDTH_MEDIA_URL_FILTERS.map((urlFilter, idx) => ({
      id: LOW_BANDWIDTH_MEDIA_RULE_ID_BASE + idx,
      priority: 2,
      action: { type: "block" },
      condition: {
        tabIds,
        urlFilter,
        resourceTypes: [...LOW_BANDWIDTH_MEDIA_CHUNK_RESOURCE_TYPES]
      }
    }))
  ] : [];
  await dnr.updateSessionRules({
    removeRuleIds,
    addRules
  });
  if (log) {
    await info("low-bandwidth browsing rules updated", {
      enabled: settings.lowBandwidthBrowsing,
      tab_count: tabIds.length,
      blocked_resource_types: LOW_BANDWIDTH_RESOURCE_TYPES.join(","),
      blocked_media_filters: LOW_BANDWIDTH_MEDIA_URL_FILTERS.join(","),
      reason
    });
  }
}
browser.tabs.onUpdated.addListener((_tabId, changeInfo) => {
  if (changeInfo.url || changeInfo.status === "complete") {
    void syncLowBandwidthRules({ reason: "tab-updated", log: false }).catch((err) => {
      void warn("low-bandwidth rule refresh failed", describeError(err));
    });
  }
});
browser.tabs.onRemoved.addListener(() => {
  void syncLowBandwidthRules({ reason: "tab-removed", log: false }).catch((err) => {
    void warn("low-bandwidth rule refresh failed", describeError(err));
  });
});
async function reinjectIntoOpenTabs() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("could not query open tabs", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    try {
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["page-hook.js"],
        // Firefox 128+ supports the MAIN execution world via this API, but
        // the @types/firefox-webext-browser package we're on still only
        // declares 'ISOLATED'. Cast through the literal union.
        world: "MAIN"
      });
      await browser.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"]
      });
      await info("re-injected scripts into open tab", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? "")
      });
    } catch (err) {
      await warn("re-inject failed for tab; continuing", {
        tabId: tab.id,
        url: shortenUrl(tab.url ?? ""),
        ...describeError(err)
      });
    }
  }
}
async function ensureAlarms() {
  await browser.alarms.clear("flush-sweep");
  await browser.alarms.clear("verify-connection");
  await browser.alarms.create("flush-sweep", { periodInMinutes: FLUSH_ALARM_MINUTES });
  await browser.alarms.create("verify-connection", {
    periodInMinutes: VERIFY_CONNECTION_INTERVAL_MS / 6e4
  });
}
var autoScrollTimer = null;
var SHOW_MORE_RELEVANCE_TTL_MS = 10 * 60 * 1e3;
var showMoreRelevantTweetsByTab = /* @__PURE__ */ new Map();
var INGEST_WAIT_MS = 25e3;
async function ensureAutoScrollAlarm() {
  const sess = await getAutoScrollSession();
  const s = await getSettings();
  if (sess !== null && s.enabled !== false) {
    armAutoScrollTimer(s.autoScrollIntervalSec);
  } else {
    clearAutoScrollTimer();
  }
}
function clearAutoScrollTimer() {
  if (autoScrollTimer !== null) {
    clearInterval(autoScrollTimer);
    autoScrollTimer = null;
  }
}
function armAutoScrollTimer(intervalSec) {
  clearAutoScrollTimer();
  const clamped = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(intervalSec))
  );
  autoScrollTimer = setInterval(() => {
    void autoScrollTick().catch((err) => {
      void warn("auto-scroll tick failed", describeError(err));
    });
  }, clamped * 1e3);
}
async function startAutoScrollLoop() {
  allowManualCaptureWindow();
  const s = await getSettings();
  await setAutoScrollSession({
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    scrollCount: 0,
    ingestedCount: 0,
    ingestedNewCount: 0,
    ingestedExistingCount: 0,
    skippedOldCount: 0,
    expandedCount: 0
  });
  armAutoScrollTimer(s.autoScrollIntervalSec);
  await info("auto-scroll loop started", { interval_sec: s.autoScrollIntervalSec });
  void autoScrollTick();
  await broadcastState();
}
async function cancelAutoScrollLoop() {
  clearAutoScrollTimer();
  const sess = await getAutoScrollSession();
  await setAutoScrollSession(null);
  await info("auto-scroll loop cancelled", {
    scrolls: sess?.scrollCount ?? 0,
    ingested: sess?.ingestedCount ?? 0,
    expanded: sess?.expandedCount ?? 0
  });
  await broadcastState();
}
async function autoScrollTick() {
  let tabs;
  try {
    tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
  } catch (err) {
    await warn("auto-scroll: tab query failed", describeError(err));
    return;
  }
  if (tabs.length === 0) return;
  let scrollCount = 0;
  let retryCount = 0;
  for (const tab of tabs) {
    if (typeof tab.id !== "number") continue;
    if (tab.discarded) continue;
    try {
      const results = await browser.scripting.executeScript({
        target: { tabId: tab.id },
        world: "MAIN",
        func: () => {
          const normalizedText = (el) => `${el.textContent ?? ""} ${el.getAttribute("aria-label") ?? ""}`.replace(/\s+/g, " ").trim().toLowerCase();
          const clickRetryIfReloadError = () => {
            const bodyText = (document.body?.innerText ?? "").toLowerCase();
            if (!bodyText.includes("something went wrong") && !bodyText.includes("try reloading")) {
              return false;
            }
            const controls = Array.from(
              document.querySelectorAll('button,[role="button"],a[href]')
            );
            const retry = controls.find((el) => {
              const text = normalizedText(el);
              return text === "retry" || text.includes("retry") || text.includes("try again");
            });
            if (!retry) return false;
            retry.click();
            return true;
          };
          if (clickRetryIfReloadError()) return { retried: true, scrolled: false };
          const opts = {
            key: "End",
            code: "End",
            keyCode: 35,
            which: 35,
            bubbles: true,
            cancelable: true
          };
          const focus = document.activeElement ?? document.body;
          focus.dispatchEvent(new KeyboardEvent("keydown", opts));
          focus.dispatchEvent(new KeyboardEvent("keyup", opts));
          window.scrollTo({
            top: document.documentElement.scrollHeight,
            behavior: "auto"
          });
          return { retried: false, scrolled: true };
        }
      });
      const pageResults = results.map((r) => r.result).filter(
        (result) => typeof result === "object" && result !== null
      );
      if (pageResults.some((result) => result.retried === true)) {
        retryCount += 1;
      }
      if (pageResults.some((result) => result.scrolled === true)) {
        scrollCount += 1;
      }
    } catch {
    }
  }
  if (retryCount > 0) {
    await info("auto-scroll clicked X retry control", { tab_count: retryCount });
  }
  if (scrollCount > 0) {
    const sess = await getAutoScrollSession();
    if (sess !== null) {
      sess.scrollCount += scrollCount;
      await setAutoScrollSession(sess);
    }
  }
}
function pruneShowMoreRelevance() {
  const cutoff = Date.now() - SHOW_MORE_RELEVANCE_TTL_MS;
  for (const [tabId, entry] of showMoreRelevantTweetsByTab) {
    if (entry.updatedAt < cutoff) showMoreRelevantTweetsByTab.delete(tabId);
  }
}
function rememberShowMoreRelevantTweets(tabId, pageUrl, tweets, coreHandles) {
  if (tabId === null || tweets.length === 0 || coreHandles.size === 0) return;
  const coreTweetIds = /* @__PURE__ */ new Set();
  for (const t of tweets) {
    if (coreHandles.has(t.account_handle.toLowerCase())) coreTweetIds.add(t.tweet_id);
  }
  const existing = showMoreRelevantTweetsByTab.get(tabId);
  const tweetIds = existing?.tweetIds ?? /* @__PURE__ */ new Set();
  for (const t of tweets) {
    const handle = t.account_handle.toLowerCase();
    const replyHandle = t.reply_to_account?.toLowerCase() ?? null;
    if (coreHandles.has(handle) || replyHandle !== null && coreHandles.has(replyHandle) || t.reply_to_tweet_id !== null && coreTweetIds.has(t.reply_to_tweet_id) || t.quoted_tweet_id !== null && coreTweetIds.has(t.quoted_tweet_id) || t.retweeted_tweet_id !== null && coreTweetIds.has(t.retweeted_tweet_id)) {
      tweetIds.add(t.tweet_id);
    }
  }
  showMoreRelevantTweetsByTab.set(tabId, {
    updatedAt: Date.now(),
    pageUrl,
    tweetIds
  });
}
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "flush-sweep") {
    void flushIdleBuffers();
  } else if (alarm.name === "verify-connection") {
    void verifyConnection(false);
  }
});
if (browser.action?.onClicked) {
  browser.action.onClicked.addListener(async (tab) => {
    try {
      const sidebarAction = browser.sidebarAction;
      if (sidebarAction?.toggle) {
        await sidebarAction.toggle();
        return;
      }
      const sidePanel = browser.sidePanel;
      if (sidePanel?.open) {
        const options = {};
        if (typeof tab.windowId === "number") options.windowId = tab.windowId;
        await sidePanel.open(options);
        return;
      }
      await browser.tabs.create({ url: browser.runtime.getURL("sidebar.html") });
    } catch (err) {
      await warn("sidebar open failed; opening sidebar tab", describeError(err));
      try {
        await browser.tabs.create({ url: browser.runtime.getURL("sidebar.html") });
        return;
      } catch (tabErr) {
        await warn("sidebar tab failed; opening options", describeError(tabErr));
      }
      await browser.runtime.openOptionsPage();
    }
  });
}
browser.runtime.onMessage.addListener((msg, sender) => {
  if (!isRuntimeMessage(msg)) return void 0;
  return handleMessage(msg, sender).catch((err) => {
    void error("message handler failed", { type: msg.type, ...describeError(err) });
    throw err;
  });
});
function isRuntimeMessage(m) {
  return !!m && typeof m === "object" && typeof m.type === "string";
}
var CAPTURE_PIPELINE_MESSAGES = /* @__PURE__ */ new Set([
  "graphql-capture",
  "capture-now",
  "capture-all",
  "capture-this-page",
  "flush-all",
  "flush-handle",
  "start-refetch",
  "start-media-crawl",
  "start-thread-open",
  "start-auto-scroll"
]);
async function isEnabled() {
  const s = await getSettings();
  return s.enabled !== false;
}
async function handleMessage(msg, sender) {
  if (!await isEnabled() && CAPTURE_PIPELINE_MESSAGES.has(msg.type)) {
    return { ok: true, paused: true };
  }
  switch (msg.type) {
    case "graphql-capture":
      await onGraphqlCapture(
        msg.endpoint,
        msg.url,
        msg.pageUrl ?? null,
        msg.response,
        sender?.tab?.id ?? null
      );
      return { ok: true };
    case "content-alive":
      await info("content script alive on page", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "page-hook-active":
      await info("page hook patched fetch/XHR", { url: shortenUrl(msg.url) });
      return { ok: true };
    case "log-content-event":
      if (msg.level === "warn") {
        await warn(msg.msg, { url: shortenUrl(msg.url) });
      } else if (msg.level === "error") {
        await error(msg.msg, { url: shortenUrl(msg.url) });
      } else {
        await info(msg.msg, { url: shortenUrl(msg.url) });
      }
      return { ok: true };
    case "get-unfold-targets": {
      const settings = await getSettings();
      if (settings.enabled === false) {
        return { enabled: false, coreHandles: [], relevantTweetIds: [] };
      }
      pruneShowMoreRelevance();
      const accounts = await getAccounts();
      const coreHandles = accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase());
      const tabId = sender?.tab?.id ?? null;
      return {
        enabled: true,
        coreHandles,
        relevantTweetIds: tabId === null ? [] : Array.from(showMoreRelevantTweetsByTab.get(tabId)?.tweetIds ?? [])
      };
    }
    case "show-more-unfolded": {
      if (msg.count > 0) {
        const asSess = await getAutoScrollSession();
        if (asSess !== null) {
          asSess.expandedCount += msg.count;
          await setAutoScrollSession(asSess);
        }
      }
      return { ok: true };
    }
    case "get-state":
      return buildState();
    case "capture-now":
      await captureNow(msg.handle);
      return buildState();
    case "capture-all":
      await captureAll();
      return buildState();
    case "capture-this-page":
      await captureThisPage();
      return buildState();
    case "flush-all":
      await flushAll("user");
      return buildState();
    case "flush-handle":
      await flushHandle(msg.handle, "user");
      return buildState();
    case "toggle-auto-capture":
      await updateSettings({ autoCapture: msg.on });
      await info("auto-capture toggled", { on: msg.on });
      return buildState();
    case "toggle-update-existing":
      await updateSettings({ updateExisting: msg.on });
      await info("update-existing toggled", { on: msg.on });
      return buildState();
    case "toggle-low-bandwidth":
      await updateSettings({ lowBandwidthBrowsing: msg.on });
      await syncLowBandwidthRules({ reason: "toggle", log: true });
      return buildState();
    case "toggle-enabled": {
      const s = await updateSettings({ enabled: msg.on });
      if (!msg.on) {
        clearAutoScrollTimer();
        stopRefetchInterval();
        stopMediaCrawlInterval();
        stopThreadOpenInterval();
        await browser.alarms.clear("refetch-tick");
        await browser.alarms.clear("media-crawl-tick");
        await browser.alarms.clear("thread-open-tick");
      } else {
        const sess = await getAutoScrollSession();
        if (sess !== null) armAutoScrollTimer(s.autoScrollIntervalSec);
      }
      await info("extension master switch toggled", { on: msg.on });
      return buildState();
    }
    case "start-auto-scroll":
      await startAutoScrollLoop();
      return buildState();
    case "cancel-auto-scroll":
      await cancelAutoScrollLoop();
      return buildState();
    case "set-auto-scroll-interval": {
      const seconds = Math.min(
        AUTO_SCROLL_MAX_SEC,
        Math.max(AUTO_SCROLL_MIN_SEC, Math.round(msg.seconds))
      );
      await updateSettings({ autoScrollIntervalSec: seconds });
      const sess = await getAutoScrollSession();
      if (sess !== null) armAutoScrollTimer(seconds);
      if (refetchIntervalHandle !== null) startRefetchInterval(seconds);
      if (mediaCrawlIntervalHandle !== null) startMediaCrawlInterval(seconds);
      if (threadOpenIntervalHandle !== null) startThreadOpenInterval(seconds);
      return buildState();
    }
    case "start-refetch":
      await startRefetchLoop();
      return buildState();
    case "cancel-refetch":
      await cancelRefetchLoop();
      return buildState();
    case "start-media-crawl":
      await startMediaCrawlLoop();
      return buildState();
    case "cancel-media-crawl":
      await cancelMediaCrawlLoop();
      return buildState();
    case "start-thread-open":
      await startThreadOpenLoop();
      return buildState();
    case "cancel-thread-open":
      await cancelThreadOpenLoop();
      return buildState();
    case "purge-unrelated": {
      const accs = await getAccounts();
      const tracked = new Set(accs.map((a) => a.handle.toLowerCase()));
      const summary = await purgeUnrelatedState(tracked);
      await info("purged unrelated state", summary);
      return buildState();
    }
    case "refresh-accounts":
      await refreshAccountsList(true);
      return buildState();
    case "verify-connection":
      await verifyConnection(true);
      return buildState();
    case "clear-activity":
      await clearActivity();
      return { ok: true };
    case "open-options":
      await browser.runtime.openOptionsPage();
      return { ok: true };
    case "open-viewer": {
      const s = await getSettings();
      const url = viewerUrl(s);
      await browser.tabs.create({ url });
      return { ok: true };
    }
    default:
      return { ok: false, error: "unknown message type" };
  }
}
async function onGraphqlCapture(endpoint, url, pageUrl, response, senderTabId) {
  if (PROFILE_ENDPOINTS.has(endpoint)) return;
  if (!TWEET_ENDPOINTS.has(endpoint)) return;
  const settings = await getSettings();
  if (settings.enabled === false) return;
  if (settings.autoCapture === false) {
    const explicitCaptureActive = Date.now() < manualCaptureUntilMs || await getAutoScrollSession() !== null || await getRefetchSession() !== null || await getMediaCrawlSession() !== null;
    if (!explicitCaptureActive) return;
  }
  const accounts = await getAccounts();
  const tracked = new Set(accounts.map((a) => a.handle.toLowerCase()));
  const core = new Set(
    accounts.filter((a) => a.category === "core").map((a) => a.handle.toLowerCase())
  );
  const capturedAt = (/* @__PURE__ */ new Date()).toISOString();
  let normalized;
  try {
    normalized = normalize(response, {
      capturedAt,
      runId: "pending",
      endpoint,
      allowedHandles: /* @__PURE__ */ new Set(),
      sourceUrl: pageUrl
    });
  } catch (err) {
    await quarantine("normalize-threw", endpoint, url, response, err);
    return;
  }
  const retweetEdges = buildRetweetEdges(
    normalized.tweets,
    accounts,
    capturedAt,
    endpoint,
    pageUrl ?? url
  );
  const beforeFilter = normalized.tweets.length;
  normalized.tweets = filterRelated(normalized.tweets, tracked, core);
  const droppedUnrelated = beforeFilter - normalized.tweets.length;
  if (droppedUnrelated > 0) {
    await info("dropped unrelated tweets", {
      endpoint,
      dropped: droppedUnrelated,
      kept: normalized.tweets.length
    });
  }
  rememberShowMoreRelevantTweets(senderTabId, pageUrl, normalized.tweets, core);
  if (normalized.observed_ids.length === 0) {
    await info("graphql payload empty \u2014 shape probe", {
      endpoint,
      typenames: probeTypenames(response).slice(0, 30),
      tweet_keys: probeFirstTypeShape(response, "Tweet"),
      tweet_core_keys: probeTypedNested(response, "Tweet", ["core"]),
      tweet_legacy_keys: probeTypedNested(response, "Tweet", ["legacy"]),
      user_results_result_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result"
      ]),
      user_results_result_core_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "core"
      ]),
      user_results_result_legacy_keys: probeTypedNested(response, "Tweet", [
        "core",
        "user_results",
        "result",
        "legacy"
      ])
    });
  } else {
    await info("graphql payload seen", {
      endpoint,
      observed: normalized.observed_ids.length,
      kept: normalized.tweets.length
    });
  }
  if (normalized.unavailable_tweets.length > 0) {
    await recordUnavailableTweets(
      normalized.unavailable_tweets,
      tracked,
      capturedAt,
      url,
      endpoint
    );
  }
  if (normalized.tweets.length === 0) {
    const bufferedEdges = await bufferRetweetEdges(
      retweetEdges,
      capturedAt,
      pageUrl ?? url,
      endpoint
    );
    if (bufferedEdges > 0) await broadcastState();
    return;
  }
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  for (const t of normalized.tweets) {
    if (t.is_truncated) {
      await enqueueRefetch(t.account_handle, t.tweet_id);
    } else {
      await dequeueRefetch(t.account_handle, t.tweet_id);
    }
    await dequeueMediaCrawl(t.tweet_id);
    if (refetchSess?.inflight?.tweetId === t.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === t.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    if (threadOpenSess?.inflight?.tweetId === t.tweet_id) {
      threadOpenSess.inflight = null;
      threadOpenSess.processed += 1;
      await markThreadOpenSeen(t.tweet_id);
      await dequeueThreadOpen(t.tweet_id);
      await setThreadOpenSession(threadOpenSess);
    }
  }
  for (const partial of normalized.partial_ids) {
    if (await isCommitted(partial.tweet_id)) continue;
    await enqueueMediaCrawl(partial.hint_handle, partial.tweet_id);
  }
  if (normalized.partial_ids.length > 0) {
    await info("media-crawl: enqueued partial captures", {
      endpoint,
      partial: normalized.partial_ids.length,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
  const updateExisting = settings.updateExisting !== false;
  const committedIdx = await getCommittedIndex();
  const archiveSnapshot = await getArchiveSnapshot();
  let dedupedSkipped = 0;
  let skippedNoUpdateLocal = 0;
  let skippedNoUpdateSnapshot = 0;
  let oldFromSnapshot = 0;
  let fullTextUpgrades = 0;
  const liveTweets = [];
  const freshnessById = /* @__PURE__ */ new Map();
  const actionById = /* @__PURE__ */ new Map();
  for (const t of normalized.tweets) {
    const prev = committedIdx[t.account_handle]?.[t.tweet_id];
    const oldBySnapshot = !prev && archiveSnapshotHasTweet(t, archiveSnapshot);
    const previouslyArchived = Boolean(prev) || oldBySnapshot;
    freshnessById.set(t.tweet_id, previouslyArchived ? "existing" : "new");
    if (oldBySnapshot) oldFromSnapshot += 1;
    const sig = engagementSig(
      t.like_count,
      t.retweet_count,
      t.reply_count,
      t.quote_count,
      t.is_truncated
    );
    const fullTextUpgrade = prev !== void 0 && sigMarksTruncated(prev.sig) && !t.is_truncated;
    if (previouslyArchived && !updateExisting && !fullTextUpgrade) {
      if (prev) skippedNoUpdateLocal += 1;
      else skippedNoUpdateSnapshot += 1;
      actionById.set(t.tweet_id, "skipped");
      continue;
    }
    if (prev && prev.sig === sig) {
      dedupedSkipped += 1;
      actionById.set(t.tweet_id, "unchanged");
      continue;
    }
    if (fullTextUpgrade) fullTextUpgrades += 1;
    actionById.set(t.tweet_id, "buffered");
    liveTweets.push(t);
  }
  if (dedupedSkipped > 0) {
    await info("dedup: skipped unchanged tweets", {
      endpoint,
      skipped: dedupedSkipped,
      remaining: liveTweets.length
    });
  }
  if (skippedNoUpdateLocal + skippedNoUpdateSnapshot > 0) {
    const skippedOld = skippedNoUpdateLocal + skippedNoUpdateSnapshot;
    await info("dedup: skipped previously archived tweets (updateExisting=false)", {
      endpoint,
      skipped: skippedOld,
      local_index: skippedNoUpdateLocal,
      archive_snapshot: skippedNoUpdateSnapshot,
      remaining: liveTweets.length
    });
    const asSess = await getAutoScrollSession();
    if (asSess !== null) {
      asSess.skippedOldCount = (asSess.skippedOldCount ?? 0) + skippedOld;
      await setAutoScrollSession(asSess);
    }
  }
  if (oldFromSnapshot > 0 && updateExisting) {
    await info("archive snapshot recognized old tweets", {
      endpoint,
      old: oldFromSnapshot,
      action: "buffering because updateExisting=true",
      snapshot_generated_at: archiveSnapshot?.generated_at ?? null
    });
  }
  if (fullTextUpgrades > 0) {
    await info("dedup: buffering full-text upgrades", {
      endpoint,
      upgrades: fullTextUpgrades,
      updateExisting,
      remaining: liveTweets.length
    });
  }
  await prependRecentTweetSightings(
    normalized.tweets.map(
      (t) => buildTweetSighting(
        t,
        endpoint,
        capturedAt,
        freshnessById.get(t.tweet_id),
        actionById.get(t.tweet_id)
      )
    )
  );
  await enqueueMissingParents(normalized.tweets, endpoint);
  await enqueueThreadOpenCandidates(normalized.tweets, core, endpoint);
  const bufferedRetweetEdges = await bufferRetweetEdges(
    retweetEdges,
    capturedAt,
    pageUrl ?? url,
    endpoint
  );
  if (liveTweets.length === 0) {
    if (bufferedRetweetEdges > 0) await broadcastState();
    return;
  }
  const byHandle = /* @__PURE__ */ new Map();
  for (const t of liveTweets) {
    const arr = byHandle.get(t.account_handle) ?? [];
    arr.push(t);
    byHandle.set(t.account_handle, arr);
  }
  for (const [handle, tweets] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, url, endpoint);
    let added = 0;
    let addedNew = 0;
    let addedExisting = 0;
    let updatedBuffered = 0;
    for (const t of tweets) {
      const existing = buf.tweets_by_id[t.tweet_id];
      if (existing) {
        existing.last_seen_at = capturedAt;
        existing.like_count = t.like_count;
        existing.retweet_count = t.retweet_count;
        existing.reply_count = t.reply_count;
        existing.quote_count = t.quote_count;
        existing.view_count = t.view_count;
        existing.bookmark_count = t.bookmark_count;
        const last = existing.engagement_history[existing.engagement_history.length - 1];
        const snap = t.engagement_history[0];
        if (snap && (!last || last.captured_at !== snap.captured_at)) {
          existing.engagement_history.push(snap);
        }
        updatedBuffered += 1;
      } else {
        const stamped = { ...t, capture_run_id: buf.run_id };
        buf.tweets_by_id[t.tweet_id] = stamped;
        added += 1;
        if (freshnessById.get(t.tweet_id) === "existing") addedExisting += 1;
        else addedNew += 1;
      }
      if (!buf.tweet_ids_observed.includes(t.tweet_id)) {
        buf.tweet_ids_observed.push(t.tweet_id);
      }
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    if (added > 0 || updatedBuffered > 0) {
      await info("buffered tweets", {
        handle,
        endpoint,
        added,
        new: addedNew,
        existing: addedExisting,
        updated_buffered: updatedBuffered,
        total: Object.keys(buf.tweets_by_id).length
      });
      const asSess = await getAutoScrollSession();
      if (asSess !== null) {
        asSess.ingestedCount += added;
        asSess.ingestedNewCount = (asSess.ingestedNewCount ?? 0) + addedNew;
        asSess.ingestedExistingCount = (asSess.ingestedExistingCount ?? 0) + addedExisting;
        await setAutoScrollSession(asSess);
      }
    }
    if (Object.keys(buf.tweets_by_id).length >= FLUSH_TWEET_THRESHOLD) {
      await flushHandle(handle, "threshold");
    }
  }
  await broadcastState();
}
async function recordUnavailableTweets(unavailableTweets, tracked, capturedAt, sourceUrl, endpoint) {
  const committedIdx = await getCommittedIndex();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  let recorded = 0;
  let skipped = 0;
  let missingHandle = 0;
  for (const u of unavailableTweets) {
    const handle = u.account_handle;
    if (!handle) {
      missingHandle += 1;
      await dequeueMediaCrawl(u.tweet_id);
      await dequeueThreadOpen(u.tweet_id);
      continue;
    }
    if (tracked.size > 0 && !tracked.has(handle.toLowerCase())) {
      skipped += 1;
      continue;
    }
    await dequeueMediaCrawl(u.tweet_id);
    await dequeueRefetch(handle, u.tweet_id);
    await dequeueThreadOpen(u.tweet_id);
    if (refetchSess?.inflight?.tweetId === u.tweet_id) {
      refetchSess.inflight = null;
      refetchSess.processed += 1;
      await setRefetchSession(refetchSess);
    }
    if (mediaCrawlSess?.inflight?.tweetId === u.tweet_id) {
      mediaCrawlSess.inflight = null;
      mediaCrawlSess.processed += 1;
      await setMediaCrawlSession(mediaCrawlSess);
    }
    if (threadOpenSess?.inflight?.tweetId === u.tweet_id) {
      threadOpenSess.inflight = null;
      threadOpenSess.processed += 1;
      await markThreadOpenSeen(u.tweet_id);
      await setThreadOpenSession(threadOpenSess);
    }
    const sig = unavailableSig(u);
    const prev = committedIdx[handle]?.[u.tweet_id];
    if (prev?.sig === sig) {
      skipped += 1;
      continue;
    }
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const unavailableById = buf.unavailable_by_id ?? {};
    unavailableById[u.tweet_id] = u;
    buf.unavailable_by_id = unavailableById;
    if (!buf.tweet_ids_observed.includes(u.tweet_id)) {
      buf.tweet_ids_observed.push(u.tweet_id);
    }
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    recorded += 1;
  }
  if (recorded > 0 || missingHandle > 0 || skipped > 0) {
    await info("unavailable tweets observed", { endpoint, recorded, skipped, missingHandle });
  }
  await broadcastState();
}
function unavailableSig(u) {
  return `unavailable|${u.unavailable_reason ?? ""}|${u.unavailable_text ?? ""}`;
}
function sigMarksTruncated(sig) {
  const parts = sig.split("|");
  return parts[parts.length - 1] === "t";
}
function runBufferItemCount(buf) {
  return Object.keys(buf.tweets_by_id).length + Object.keys(buf.unavailable_by_id ?? {}).length + Object.keys(buf.retweet_edges_by_key ?? {}).length;
}
function retweetEdgeKey(edge) {
  return [edge.retweeter_handle.toLowerCase(), edge.retweet_tweet_id, edge.original_tweet_id].join(
    "|"
  );
}
function inferRetweetedHandle(text) {
  const match = text.match(/^RT\s+@([A-Za-z0-9_]{1,15})\b/i);
  return match?.[1] ?? null;
}
function buildRetweetEdges(tweets, accounts, capturedAt, endpoint, sourceUrl) {
  const categoryByHandle = new Map(accounts.map((a) => [a.handle.toLowerCase(), a.category]));
  const byId = new Map(tweets.map((t) => [t.tweet_id, t]));
  const out = /* @__PURE__ */ new Map();
  for (const t of tweets) {
    if (t.tweet_type !== "retweet" || !t.retweeted_tweet_id) continue;
    const retweeterCategory = categoryByHandle.get(t.account_handle.toLowerCase());
    if (!retweeterCategory) continue;
    const original = byId.get(t.retweeted_tweet_id);
    const originalHandle = original?.account_handle ?? inferRetweetedHandle(t.text_resolved || t.text);
    const originalCategory = originalHandle ? categoryByHandle.get(originalHandle.toLowerCase()) ?? "public" : null;
    const edge = {
      retweeter_handle: t.account_handle,
      retweeter_account_id: t.account_id ?? null,
      retweeter_category: retweeterCategory,
      retweet_tweet_id: t.tweet_id,
      retweet_url: t.tweet_url,
      original_tweet_id: t.retweeted_tweet_id,
      original_author_handle: originalHandle,
      original_author_account_id: original?.account_id ?? null,
      original_author_category: originalCategory,
      captured_at: capturedAt,
      capture_run_id: "pending",
      endpoint,
      source_url: sourceUrl
    };
    out.set(retweetEdgeKey(edge), edge);
  }
  return [...out.values()];
}
async function bufferRetweetEdges(edges, capturedAt, sourceUrl, endpoint) {
  if (edges.length === 0) return 0;
  const byHandle = /* @__PURE__ */ new Map();
  for (const edge of edges) {
    const arr = byHandle.get(edge.retweeter_handle) ?? [];
    arr.push(edge);
    byHandle.set(edge.retweeter_handle, arr);
  }
  let added = 0;
  for (const [handle, handleEdges] of byHandle) {
    const buf = await ensureRunBuffer(handle, capturedAt, sourceUrl, endpoint);
    const edgeMap = buf.retweet_edges_by_key ?? {};
    let addedForHandle = 0;
    for (const edge of handleEdges) {
      const stamped = { ...edge, capture_run_id: buf.run_id };
      const key = retweetEdgeKey(stamped);
      if (!edgeMap[key]) addedForHandle += 1;
      edgeMap[key] = stamped;
      if (!buf.tweet_ids_observed.includes(stamped.retweet_tweet_id)) {
        buf.tweet_ids_observed.push(stamped.retweet_tweet_id);
      }
      if (!buf.tweet_ids_observed.includes(stamped.original_tweet_id)) {
        buf.tweet_ids_observed.push(stamped.original_tweet_id);
      }
    }
    if (addedForHandle === 0) continue;
    buf.retweet_edges_by_key = edgeMap;
    if (!buf.endpoints_seen.includes(endpoint)) buf.endpoints_seen.push(endpoint);
    buf.last_capture_at = capturedAt;
    await setRunBuffer(handle, buf);
    await setBufferedCount(handle, runBufferItemCount(buf));
    added += addedForHandle;
    await info("buffered retweet edges", {
      handle,
      endpoint,
      added: addedForHandle,
      total: Object.keys(edgeMap).length
    });
  }
  return added;
}
async function enqueueMissingParents(tweets, endpoint) {
  if (tweets.length === 0) return;
  const sameBatchIds = /* @__PURE__ */ new Set();
  for (const t of tweets) sameBatchIds.add(t.tweet_id);
  let enqueued = 0;
  for (const t of tweets) {
    const parents = [];
    if (t.reply_to_tweet_id) {
      parents.push({ id: t.reply_to_tweet_id, hint: t.reply_to_account });
    }
    if (t.quoted_tweet_id) parents.push({ id: t.quoted_tweet_id, hint: null });
    if (t.retweeted_tweet_id) parents.push({ id: t.retweeted_tweet_id, hint: null });
    for (const p of parents) {
      if (sameBatchIds.has(p.id)) continue;
      if (await isCommitted(p.id)) continue;
      await enqueueMediaCrawl(p.hint, p.id);
      enqueued += 1;
    }
  }
  if (enqueued > 0) {
    await info("queued missing parent tweets for detail-page crawl", {
      endpoint,
      enqueued,
      queue_total: await mediaCrawlQueueTotal()
    });
  }
}
async function enqueueThreadOpenCandidates(tweets, coreHandles, endpoint) {
  if (tweets.length === 0 || coreHandles.size === 0) return;
  if (endpoint.includes("TweetDetail") || endpoint.includes("TweetResultByRestId")) return;
  const candidates = /* @__PURE__ */ new Map();
  for (const t of tweets) {
    const handle = t.account_handle.toLowerCase();
    if (!coreHandles.has(handle)) continue;
    const rootId = t.conversation_id ?? t.tweet_id;
    const isRoot = rootId === t.tweet_id || t.reply_to_tweet_id === null;
    const isCoreReply = t.reply_to_tweet_id !== null;
    if (isRoot && t.reply_count > 0) {
      candidates.set(rootId, t.account_handle);
    } else if (isCoreReply && rootId) {
      candidates.set(rootId, t.account_handle);
    }
  }
  let enqueued = 0;
  for (const [tweetId, handle] of candidates) {
    const before = await threadOpenQueueTotal();
    await enqueueThreadOpen(handle, tweetId);
    const after = await threadOpenQueueTotal();
    if (after > before) enqueued += 1;
  }
  if (enqueued > 0) {
    await info("queued core thread roots for opening", {
      endpoint,
      enqueued,
      queue_total: await threadOpenQueueTotal()
    });
  }
}
async function ensureRunBuffer(handle, ts, sourceUrl, endpoint) {
  const cur = await getRunBuffer(handle);
  if (cur) return cur;
  const buf = {
    run_id: newRunId(),
    account_handle: handle,
    started_at: ts,
    last_capture_at: ts,
    tweets_by_id: {},
    unavailable_by_id: {},
    tweet_ids_observed: [],
    endpoints_seen: [endpoint],
    source_url: sourceUrl
  };
  await setRunBuffer(handle, buf);
  await info("run started", { handle, run: shortRunId(buf.run_id) });
  return buf;
}
var flushChain = Promise.resolve();
async function flushIdleBuffers() {
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "idle");
}
async function flushOrphanedBuffersIfStale() {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const all = await getRunBuffers();
  const now = Date.now();
  const handles = [];
  for (const [handle, buf] of Object.entries(all)) {
    const last = Date.parse(buf.last_capture_at);
    if (Number.isFinite(last) && now - last >= FLUSH_IDLE_MS) {
      handles.push(handle);
    }
  }
  await flushHandles(handles, "wake");
}
async function flushAll(reason) {
  const all = await getRunBuffers();
  await flushHandles(Object.keys(all), reason);
}
async function flushHandle(handle, reason) {
  await flushHandles([handle], reason);
}
async function flushHandles(handles, reason) {
  const unique = [...new Set(handles)].filter((h) => h.length > 0);
  if (unique.length === 0) return;
  const run = flushChain.then(() => flushHandlesLocked(unique, reason));
  flushChain = run.catch(() => {
  });
  return run;
}
async function flushHandlesLocked(handles, reason) {
  const all = await getRunBuffers();
  const items = [];
  for (const handle of handles) {
    const buf = all[handle];
    if (!buf) continue;
    const tweets = Object.values(buf.tweets_by_id);
    const unavailableTweets = Object.values(buf.unavailable_by_id ?? {});
    const retweetEdges = Object.values(buf.retweet_edges_by_key ?? {});
    if (tweets.length === 0 && unavailableTweets.length === 0 && retweetEdges.length === 0) {
      await clearRunBuffer(handle);
      await setBufferedCount(handle, 0);
      continue;
    }
    items.push(buildFlushItem(handle, buf, tweets, unavailableTweets, retweetEdges));
  }
  if (items.length === 0) return;
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await warn("upload buffer deferred: settings incomplete", {
      count: items.length,
      handles: items.map((item) => item.handle).slice(0, 20)
    });
    return;
  }
  const client = new GitHubClient(settings);
  const files = items.flatMap((item) => [
    {
      path: item.rawPath,
      contentBase64: toBase642(JSON.stringify(item.capture, null, 2) + "\n")
    },
    {
      path: item.seenPath,
      contentBase64: toBase642(JSON.stringify(item.seen, null, 2) + "\n")
    }
  ]);
  const commitMsg = buildBatchCommitMessage(items);
  try {
    const result = await client.commitFiles({
      files,
      message: commitMsg
    });
    const idx = await getCommittedIndex();
    for (const item of items) {
      const remainingCount = await clearCommittedTweetsFromBuffer(item);
      const prev = (await getCounters())[item.handle];
      const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
      const carriedToday = prev && prev.todayDate === today ? prev.todayCount : 0;
      await bumpCounter(item.handle, {
        todayCount: carriedToday + item.tweets.length + item.unavailableTweets.length,
        todayDate: today,
        lastCaptureAt: item.buf.last_capture_at,
        totalCommitted: (prev?.totalCommitted ?? 0) + item.tweets.length + item.unavailableTweets.length,
        bufferedCount: remainingCount
      });
      const inner = idx[item.handle] ?? {};
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const t of item.tweets) {
        inner[t.tweet_id] = {
          ts: nowIso,
          sig: engagementSig(
            t.like_count,
            t.retweet_count,
            t.reply_count,
            t.quote_count,
            t.is_truncated
          )
        };
      }
      for (const u of item.unavailableTweets) {
        inner[u.tweet_id] = {
          ts: nowIso,
          sig: unavailableSig(u)
        };
      }
      idx[item.handle] = inner;
      await info("upload buffer committed", {
        handle: item.handle,
        reason,
        tweets: item.tweets.length,
        unavailable: item.unavailableTweets.length,
        retweet_edges: item.retweetEdges.length,
        run: item.runShort,
        path: item.rawPath,
        batch_commit: result.commitSha
      });
    }
    await setCommittedIndex(idx);
    await info("upload buffer batch committed", {
      reason,
      runs: items.length,
      files: files.length,
      tweets: items.reduce((total, item) => total + item.tweets.length, 0),
      unavailable: items.reduce((total, item) => total + item.unavailableTweets.length, 0),
      retweet_edges: items.reduce((total, item) => total + item.retweetEdges.length, 0),
      commit: result.commitSha
    });
    {
      const prev = await getConnection();
      await setConnection({
        status: "ok",
        login: prev.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: null,
        defaultBranch: prev.defaultBranch,
        configuredBranchExists: prev.configuredBranchExists,
        rateLimitResetAt: null
      });
    }
  } catch (err) {
    if (err instanceof GitHubError) {
      const conn = await getConnection();
      const status = err.category === "auth" ? "auth-error" : err.category === "rate-limit" ? "rate-limited" : err.category === "network" ? "network-error" : conn.status;
      await setConnection({
        status,
        login: conn.login,
        checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
        error: err.message,
        defaultBranch: conn.defaultBranch,
        configuredBranchExists: conn.configuredBranchExists,
        rateLimitResetAt: err.category === "rate-limit" ? err.rateLimitResetAt : conn.rateLimitResetAt
      });
      await error("upload buffer failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        category: err.category,
        status: err.status,
        message: err.message,
        rateLimitResetAt: err.rateLimitResetAt
      });
    } else {
      await error("upload buffer failed", {
        reason,
        handles: items.map((item) => item.handle).slice(0, 20),
        runs: items.length,
        files: files.length,
        ...describeError(err)
      });
    }
  } finally {
    await broadcastState();
  }
}
function buildFlushItem(handle, buf, tweets, unavailableTweets, retweetEdges) {
  const ts = isoCompact(buf.started_at);
  const day = buf.started_at.slice(0, 10);
  const runShort = shortRunId(buf.run_id);
  const rawPath = `raw/${handle}/${ts}-${runShort}.json`;
  const seenPath = `seen/${handle}/${ts}-${runShort}.json`;
  return {
    handle,
    buf,
    tweets,
    unavailableTweets,
    retweetEdges,
    rawPath,
    seenPath,
    day,
    runShort,
    capture: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      endpoint: buf.endpoints_seen.join(","),
      user_agent: navigator.userAgent,
      source_url: buf.source_url,
      tweets,
      unavailable_tweets: unavailableTweets,
      retweet_edges: retweetEdges
    },
    seen: {
      schema_version: 1,
      capture_run_id: buf.run_id,
      account_handle: handle,
      captured_at: buf.last_capture_at,
      tweet_ids_observed: buf.tweet_ids_observed
    }
  };
}
function buildBatchCommitMessage(items) {
  if (items.length === 1) {
    const item = items[0];
    const unavailableCount2 = item.unavailableTweets.length;
    const edgeCount2 = item.retweetEdges.length;
    const suffix2 = (unavailableCount2 > 0 ? `, ${unavailableCount2} unavailable` : "") + (edgeCount2 > 0 ? `, ${edgeCount2} retweet edge${edgeCount2 === 1 ? "" : "s"}` : "");
    return `capture: ${item.handle} ${item.day} ${item.tweets.length} tweet${item.tweets.length === 1 ? "" : "s"}${suffix2} (run ${item.runShort})`;
  }
  const days = [...new Set(items.map((item) => item.day))].sort();
  const dayLabel = days.length === 1 ? days[0] : `${days[0]}..${days[days.length - 1]}`;
  const tweetCount = items.reduce((total, item) => total + item.tweets.length, 0);
  const unavailableCount = items.reduce((total, item) => total + item.unavailableTweets.length, 0);
  const edgeCount = items.reduce((total, item) => total + item.retweetEdges.length, 0);
  const suffix = (unavailableCount > 0 ? `, ${unavailableCount} unavailable` : "") + (edgeCount > 0 ? `, ${edgeCount} retweet edge${edgeCount === 1 ? "" : "s"}` : "");
  return `capture batch: ${items.length} runs, ${tweetCount} tweet${tweetCount === 1 ? "" : "s"}${suffix} (${dayLabel})`;
}
async function clearCommittedTweetsFromBuffer(item) {
  const current = await getRunBuffer(item.handle);
  if (!current) return 0;
  if (current.run_id !== item.buf.run_id) return runBufferItemCount(current);
  const committed = new Map(
    item.tweets.map((t) => [
      t.tweet_id,
      engagementSig(t.like_count, t.retweet_count, t.reply_count, t.quote_count, t.is_truncated)
    ])
  );
  for (const u of item.unavailableTweets) {
    committed.set(u.tweet_id, unavailableSig(u));
  }
  const remainingTweets = {};
  for (const [tweetId, tweet] of Object.entries(current.tweets_by_id)) {
    const committedSig = committed.get(tweetId);
    const currentSig = engagementSig(
      tweet.like_count,
      tweet.retweet_count,
      tweet.reply_count,
      tweet.quote_count,
      tweet.is_truncated
    );
    if (!committedSig || committedSig !== currentSig) {
      remainingTweets[tweetId] = { ...tweet };
    }
  }
  const remainingUnavailable = {};
  for (const [tweetId, unavailable] of Object.entries(current.unavailable_by_id ?? {})) {
    const committedSig = committed.get(tweetId);
    const currentSig = unavailableSig(unavailable);
    if (!committedSig || committedSig !== currentSig) {
      remainingUnavailable[tweetId] = { ...unavailable };
    }
  }
  const remainingRetweetEdges = {};
  for (const [key, edge] of Object.entries(current.retweet_edges_by_key ?? {})) {
    if (!item.retweetEdges.some((committedEdge) => retweetEdgeKey(committedEdge) === key)) {
      remainingRetweetEdges[key] = { ...edge };
    }
  }
  const remainingIds = /* @__PURE__ */ new Set([
    ...Object.keys(remainingTweets),
    ...Object.keys(remainingUnavailable),
    ...Object.values(remainingRetweetEdges).flatMap((edge) => [
      edge.retweet_tweet_id,
      edge.original_tweet_id
    ])
  ]);
  const remainingCount = Object.keys(remainingTweets).length + Object.keys(remainingUnavailable).length + Object.keys(remainingRetweetEdges).length;
  if (remainingCount === 0) {
    await clearRunBuffer(item.handle);
    return 0;
  }
  const nextRunId = newRunId();
  for (const tweet of Object.values(remainingTweets)) {
    tweet.capture_run_id = nextRunId;
  }
  for (const edge of Object.values(remainingRetweetEdges)) {
    edge.capture_run_id = nextRunId;
  }
  await setRunBuffer(item.handle, {
    ...current,
    run_id: nextRunId,
    started_at: current.last_capture_at,
    tweets_by_id: remainingTweets,
    unavailable_by_id: remainingUnavailable,
    retweet_edges_by_key: remainingRetweetEdges,
    tweet_ids_observed: current.tweet_ids_observed.filter((id) => remainingIds.has(id))
  });
  await info("upload buffer kept newer tweets", {
    handle: item.handle,
    committed_run: item.runShort,
    next_run: shortRunId(nextRunId),
    remaining: remainingCount
  });
  return remainingCount;
}
async function captureNow(handle) {
  allowManualCaptureWindow();
  const targetUrl = `https://x.com/${handle}/with_replies`;
  await info("capture-now requested", { handle, tab: "with_replies" });
  if (!await getRunBuffer(handle)) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    await setRunBuffer(handle, {
      run_id: newRunId(),
      account_handle: handle,
      started_at: now,
      last_capture_at: now,
      tweets_by_id: {},
      unavailable_by_id: {},
      tweet_ids_observed: [],
      endpoints_seen: [],
      source_url: targetUrl
    });
  }
  await browser.tabs.create({ url: targetUrl, active: true });
}
async function captureAll() {
  const accounts = await getAccounts();
  await info("capture-all requested", { count: accounts.length });
  for (const a of accounts) {
    await captureNow(a.handle);
  }
}
async function captureThisPage() {
  allowManualCaptureWindow();
  let tabs;
  try {
    tabs = await browser.tabs.query({ active: true, currentWindow: true });
  } catch (err) {
    await warn("capture-this-page: could not query active tab", describeError(err));
    return;
  }
  const tab = tabs[0];
  if (!tab || typeof tab.id !== "number" || !tab.url) {
    await warn("capture-this-page: no active tab");
    return;
  }
  if (!/^https:\/\/(x|twitter)\.com\//.test(tab.url)) {
    await warn("capture-this-page: active tab is not on x.com / twitter.com", {
      url: shortenUrl(tab.url)
    });
    return;
  }
  await info("capture-this-page requested", { url: shortenUrl(tab.url) });
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["page-hook.js"],
      world: "MAIN"
    });
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });
  } catch (err) {
    await warn("capture-this-page: re-inject failed", describeError(err));
  }
  try {
    await browser.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        window.scrollBy({ top: h * 1.5, behavior: "smooth" });
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 600);
        setTimeout(() => window.scrollBy({ top: h * 1.5, behavior: "smooth" }), 1200);
      }
    });
  } catch (err) {
    await warn("capture-this-page: scroll-nudge failed", describeError(err));
  }
}
var REFETCH_TAB_KEY = "__imm_archive_refetch_tab_id__";
async function getRefetchTabId() {
  const stored = await browser.storage.local.get(REFETCH_TAB_KEY);
  const id = stored[REFETCH_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setRefetchTabId(id) {
  if (id === null) {
    await browser.storage.local.remove(REFETCH_TAB_KEY);
  } else {
    await browser.storage.local.set({ [REFETCH_TAB_KEY]: id });
  }
}
async function startRefetchLoop() {
  allowManualCaptureWindow();
  const total = await refetchQueueTotal();
  if (total === 0) {
    await info("refetch: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setRefetchSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startRefetchInterval(seconds);
  void refetchTick();
  await info("refetch loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var refetchIntervalHandle = null;
function startRefetchInterval(seconds) {
  if (refetchIntervalHandle !== null) clearInterval(refetchIntervalHandle);
  refetchIntervalHandle = setInterval(() => {
    void refetchTick().catch((err) => {
      void warn("refetch tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopRefetchInterval() {
  if (refetchIntervalHandle !== null) {
    clearInterval(refetchIntervalHandle);
    refetchIntervalHandle = null;
  }
}
async function cancelRefetchLoop() {
  stopRefetchInterval();
  await browser.alarms.clear("refetch-tick");
  const tabId = await getRefetchTabId();
  await setRefetchTabId(null);
  const sess = await getRefetchSession();
  await setRefetchSession(null);
  await info("refetch loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function refetchTick() {
  let sess = await getRefetchSession();
  if (sess === null) {
    stopRefetchInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("refetch: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    const q = await getRefetchQueue();
    for (const [handle, ids] of Object.entries(q)) {
      if (ids.includes(sess.inflight.tweetId)) {
        await dequeueRefetch(handle, sess.inflight.tweetId);
        break;
      }
    }
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  const target = await nextRefetchTarget();
  if (!target) {
    stopRefetchInterval();
    await setRefetchTabId(null);
    await setRefetchSession(null);
    await info("refetch loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getRefetchTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setRefetchTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getRefetchSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setRefetchSession(sess);
    await info("refetch tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await refetchQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("refetch navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueRefetch(target.handle, target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setRefetchSession(sess);
  }
  await broadcastState();
}
var MEDIA_CRAWL_TAB_KEY = "__imm_archive_media_crawl_tab_id__";
async function getMediaCrawlTabId() {
  const stored = await browser.storage.local.get(MEDIA_CRAWL_TAB_KEY);
  const id = stored[MEDIA_CRAWL_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setMediaCrawlTabId(id) {
  if (id === null) await browser.storage.local.remove(MEDIA_CRAWL_TAB_KEY);
  else await browser.storage.local.set({ [MEDIA_CRAWL_TAB_KEY]: id });
}
async function startMediaCrawlLoop() {
  allowManualCaptureWindow();
  const total = await mediaCrawlQueueTotal();
  if (total === 0) {
    await info("media-crawl: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setMediaCrawlSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startMediaCrawlInterval(seconds);
  void mediaCrawlTick();
  await info("media-crawl loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var mediaCrawlIntervalHandle = null;
function startMediaCrawlInterval(seconds) {
  if (mediaCrawlIntervalHandle !== null) clearInterval(mediaCrawlIntervalHandle);
  mediaCrawlIntervalHandle = setInterval(() => {
    void mediaCrawlTick().catch((err) => {
      void warn("media-crawl tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopMediaCrawlInterval() {
  if (mediaCrawlIntervalHandle !== null) {
    clearInterval(mediaCrawlIntervalHandle);
    mediaCrawlIntervalHandle = null;
  }
}
async function cancelMediaCrawlLoop() {
  stopMediaCrawlInterval();
  await browser.alarms.clear("media-crawl-tick");
  const tabId = await getMediaCrawlTabId();
  await setMediaCrawlTabId(null);
  const sess = await getMediaCrawlSession();
  await setMediaCrawlSession(null);
  await info("media-crawl loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function mediaCrawlTick() {
  let sess = await getMediaCrawlSession();
  if (sess === null) {
    stopMediaCrawlInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) {
      return;
    }
    await warn("media-crawl: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await dequeueMediaCrawl(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  const target = await nextMediaCrawlTarget();
  if (!target) {
    stopMediaCrawlInterval();
    await setMediaCrawlTabId(null);
    await setMediaCrawlSession(null);
    await info("media-crawl loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await isCommitted(target.tweetId)) {
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
    await broadcastState();
    return;
  }
  const url = target.bucket === "_unknown" ? `https://x.com/i/web/status/${target.tweetId}` : `https://x.com/${target.bucket}/status/${target.tweetId}`;
  let tabId = await getMediaCrawlTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id === "number") await setMediaCrawlTabId(tab.id);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    sess = await getMediaCrawlSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setMediaCrawlSession(sess);
    await info("media-crawl tick", {
      tweet_id: target.tweetId,
      hint_handle: target.bucket === "_unknown" ? null : target.bucket,
      remaining: await mediaCrawlQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("media-crawl navigate failed; dropping target", {
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await dequeueMediaCrawl(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setMediaCrawlSession(sess);
  }
  await broadcastState();
}
var THREAD_OPEN_TAB_KEY = "__imm_archive_thread_open_tab_id__";
async function getThreadOpenTabId() {
  const stored = await browser.storage.local.get(THREAD_OPEN_TAB_KEY);
  const id = stored[THREAD_OPEN_TAB_KEY];
  return typeof id === "number" ? id : null;
}
async function setThreadOpenTabId(id) {
  if (id === null) await browser.storage.local.remove(THREAD_OPEN_TAB_KEY);
  else await browser.storage.local.set({ [THREAD_OPEN_TAB_KEY]: id });
}
async function startThreadOpenLoop() {
  allowManualCaptureWindow();
  const total = await threadOpenQueueTotal();
  if (total === 0) {
    await info("thread-open: nothing queued");
    return;
  }
  const s = await getSettings();
  const seconds = Math.min(
    AUTO_SCROLL_MAX_SEC,
    Math.max(AUTO_SCROLL_MIN_SEC, Math.round(s.autoScrollIntervalSec))
  );
  await setThreadOpenSession({
    totalAtStart: total,
    processed: 0,
    startedAt: (/* @__PURE__ */ new Date()).toISOString(),
    inflight: null
  });
  startThreadOpenInterval(seconds);
  void threadOpenTick();
  await info("thread-open loop started", { queued: total, interval_sec: seconds });
  await broadcastState();
}
var threadOpenIntervalHandle = null;
function startThreadOpenInterval(seconds) {
  if (threadOpenIntervalHandle !== null) clearInterval(threadOpenIntervalHandle);
  threadOpenIntervalHandle = setInterval(() => {
    void threadOpenTick().catch((err) => {
      void warn("thread-open tick failed", describeError(err));
    });
  }, seconds * 1e3);
}
function stopThreadOpenInterval() {
  if (threadOpenIntervalHandle !== null) {
    clearInterval(threadOpenIntervalHandle);
    threadOpenIntervalHandle = null;
  }
}
async function cancelThreadOpenLoop() {
  stopThreadOpenInterval();
  await browser.alarms.clear("thread-open-tick");
  const tabId = await getThreadOpenTabId();
  await setThreadOpenTabId(null);
  const sess = await getThreadOpenSession();
  await setThreadOpenSession(null);
  await info("thread-open loop cancelled", {
    had_tab: tabId !== null,
    processed: sess?.processed ?? 0
  });
  await broadcastState();
}
async function threadOpenTick() {
  let sess = await getThreadOpenSession();
  if (sess === null) {
    stopThreadOpenInterval();
    return;
  }
  if (sess.inflight !== null) {
    const elapsed = Date.now() - Date.parse(sess.inflight.navigatedAt);
    if (elapsed < INGEST_WAIT_MS) return;
    await warn("thread-open: target timed out waiting for ingest", {
      tweet_id: sess.inflight.tweetId,
      waited_ms: elapsed
    });
    await markThreadOpenSeen(sess.inflight.tweetId);
    await dequeueThreadOpen(sess.inflight.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
  }
  const target = await nextThreadOpenTarget();
  if (!target) {
    stopThreadOpenInterval();
    await setThreadOpenTabId(null);
    await setThreadOpenSession(null);
    await info("thread-open loop complete", { processed: sess.processed });
    await broadcastState();
    return;
  }
  if (await hasThreadOpenSeen(target.tweetId)) {
    await dequeueThreadOpen(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
    await broadcastState();
    return;
  }
  const url = `https://x.com/${target.handle}/status/${target.tweetId}`;
  let tabId = await getThreadOpenTabId();
  if (tabId !== null) {
    try {
      await browser.tabs.get(tabId);
    } catch {
      tabId = null;
    }
  }
  try {
    if (tabId === null) {
      const tab = await browser.tabs.create({ url, active: false });
      if (typeof tab.id !== "number") throw new Error("created tab without id");
      tabId = tab.id;
      await setThreadOpenTabId(tabId);
    } else {
      await browser.tabs.update(tabId, { url });
    }
    await markThreadOpenSeen(target.tweetId);
    sess = await getThreadOpenSession() ?? sess;
    sess.inflight = {
      tweetId: target.tweetId,
      navigatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await setThreadOpenSession(sess);
    if (tabId !== null) {
      void nudgeThreadOpenTab(tabId);
    }
    await info("thread-open tick", {
      handle: target.handle,
      tweet_id: target.tweetId,
      remaining: await threadOpenQueueTotal(),
      processed: sess.processed,
      total_at_start: sess.totalAtStart
    });
  } catch (err) {
    await warn("thread-open navigate failed; dropping target", {
      handle: target.handle,
      tweet_id: target.tweetId,
      ...describeError(err)
    });
    await markThreadOpenSeen(target.tweetId);
    await dequeueThreadOpen(target.tweetId);
    sess.processed += 1;
    sess.inflight = null;
    await setThreadOpenSession(sess);
  }
  await broadcastState();
}
async function nudgeThreadOpenTab(tabId) {
  await new Promise((resolve) => setTimeout(resolve, 1500));
  try {
    await browser.scripting.executeScript({
      target: { tabId },
      world: "MAIN",
      func: () => {
        const h = window.innerHeight;
        const step = () => window.scrollBy({ top: h * 1.3, behavior: "smooth" });
        step();
        setTimeout(step, 1400);
        setTimeout(step, 2800);
      }
    });
  } catch (err) {
    await warn("thread-open scroll-nudge failed", describeError(err));
  }
}
async function quarantine(reason, endpoint, url, raw, err) {
  await error("quarantining capture", { reason, endpoint, url, ...describeError(err) });
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) return;
  const payload = {
    schema_version: 1,
    reason,
    endpoint,
    captured_at: (/* @__PURE__ */ new Date()).toISOString(),
    source_url: url,
    error: describeError(err),
    raw
  };
  const ts = isoCompact(payload.captured_at);
  const hash = await sha8(JSON.stringify(payload));
  const path = `raw/_quarantine/${ts}-${hash}.json`;
  try {
    const client = new GitHubClient(settings);
    await client.putFile({
      path,
      contentBase64: toBase642(JSON.stringify(payload, null, 2) + "\n"),
      message: `quarantine: ${reason} ${endpoint}`
    });
  } catch (qerr) {
    await error("quarantine commit failed", { ...describeError(qerr) });
  }
}
async function sha8(s) {
  const buf = new TextEncoder().encode(s);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const hex = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, "0")).join("");
  return hex.slice(0, 8);
}
async function verifyConnection(force) {
  const settings = await getSettings();
  if (!settings.pat || !settings.owner || !settings.repo) {
    await setConnection({
      status: "not-configured",
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: null
    });
    await broadcastState();
    return;
  }
  const conn = await getConnection();
  if (!force) {
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    if (conn.checkedAt) {
      const age = Date.now() - Date.parse(conn.checkedAt);
      if (age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const r = await client.verifyRepoAccess();
    let branchOk = true;
    if (settings.branch && settings.branch !== r.default_branch) {
      branchOk = await client.branchExists(settings.branch);
    }
    const checkWrite = force || isWriteAuthError(conn.error);
    if (branchOk && checkWrite) {
      await client.verifyWriteAccess();
    }
    await setConnection({
      status: "ok",
      login: r.login,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: null,
      defaultBranch: r.default_branch,
      configuredBranchExists: branchOk,
      rateLimitResetAt: null
    });
    await info("connection verified", {
      login: r.login,
      repo: r.full_name,
      default_branch: r.default_branch,
      configured_branch: settings.branch,
      configured_branch_exists: branchOk,
      write_access: checkWrite ? "checked" : "not_checked"
    });
    if (!branchOk) {
      await warn("configured branch does not exist on remote", {
        configured: settings.branch,
        default_branch: r.default_branch,
        fix: "open Settings and change branch to " + r.default_branch
      });
    }
  } catch (err) {
    const cat = err instanceof GitHubError ? err.category : "unknown";
    const status = cat === "auth" ? "auth-error" : cat === "rate-limit" ? "rate-limited" : cat === "network" ? "network-error" : "auth-error";
    const resetAt = err instanceof GitHubError && cat === "rate-limit" ? err.rateLimitResetAt : null;
    await setConnection({
      status,
      login: null,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
      error: describeError(err).message,
      defaultBranch: null,
      configuredBranchExists: null,
      rateLimitResetAt: resetAt
    });
    await warn("connection check failed", {
      category: cat,
      rateLimitResetAt: resetAt,
      ...describeError(err)
    });
  }
  await broadcastState();
}
async function refreshAccountsList(force) {
  const settings = await getSettings();
  if (!settings.pat) {
    await setAccounts([...FALLBACK_ACCOUNTS]);
    return;
  }
  if (!force) {
    const conn = await getConnection();
    if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
      const nowSec = Math.floor(Date.now() / 1e3);
      if (nowSec < conn.rateLimitResetAt) return;
    }
    const lastRefreshed = await getAccountsRefreshedAt();
    if (lastRefreshed) {
      const age = Date.now() - Date.parse(lastRefreshed);
      if (Number.isFinite(age) && age < VERIFY_CONNECTION_INTERVAL_MS) return;
    }
  }
  try {
    const client = new GitHubClient(settings);
    const text = await client.fetchRawText("config/accounts.yaml");
    if (!text) {
      if (force) await warn("accounts.yaml not found in repo; using fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    const parsed = parseAccountsYaml(text);
    if (parsed.length === 0) {
      await warn("accounts.yaml parsed empty; keeping fallback");
      await setAccounts([...FALLBACK_ACCOUNTS]);
      await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
      return;
    }
    await setAccounts(parsed);
    await refreshArchiveSnapshot(client, force);
    await setAccountsRefreshedAt((/* @__PURE__ */ new Date()).toISOString());
    if (force) await info("accounts list refreshed", { count: parsed.length });
  } catch (err) {
    await warn("refresh accounts failed; keeping current list", describeError(err));
  }
  await broadcastState();
}
async function refreshArchiveSnapshot(client, force) {
  const text = await client.fetchRawText("data/manifest.json");
  if (!text) {
    await setArchiveSnapshot(null);
    if (force) await warn("archive manifest not found; old-tweet detection disabled");
    return;
  }
  try {
    const snapshot = parseArchiveSnapshot(JSON.parse(text));
    await setArchiveSnapshot(snapshot);
    if (force) {
      await info("archive snapshot refreshed", {
        accounts: Object.keys(snapshot.accounts).length,
        generated_at: snapshot.generated_at
      });
    }
  } catch (err) {
    await warn("archive snapshot parse failed; old-tweet detection disabled", describeError(err));
  }
}
async function broadcastState() {
  const state = await buildState();
  browser.runtime.sendMessage({ type: "state-changed", state }).catch(() => {
  });
}
async function buildState() {
  const settings = await getSettings();
  const conn = await getConnection();
  const accounts = await getAccounts();
  const counters = await getCounters();
  let tabCount = 0;
  try {
    const tabs = await browser.tabs.query({ url: ["https://x.com/*", "https://twitter.com/*"] });
    tabCount = tabs.length;
  } catch {
  }
  const refetchQueued = await refetchQueueTotal();
  const mediaCrawlQueued = await mediaCrawlQueueTotal();
  const threadOpenQueued = await threadOpenQueueTotal();
  const refetchSess = await getRefetchSession();
  const mediaCrawlSess = await getMediaCrawlSession();
  const threadOpenSess = await getThreadOpenSession();
  const autoScrollSess = await getAutoScrollSession();
  const recentTweetSightings = await getRecentTweetSightings();
  return {
    version: EXT_VERSION,
    settings: redactSettings(settings),
    connection: conn,
    accounts,
    counters,
    autoScroll: {
      active: autoScrollSess !== null && autoScrollTimer !== null,
      tabCount,
      scrollCount: autoScrollSess?.scrollCount ?? 0,
      ingestedCount: autoScrollSess?.ingestedCount ?? 0,
      ingestedNewCount: autoScrollSess?.ingestedNewCount ?? 0,
      ingestedExistingCount: autoScrollSess?.ingestedExistingCount ?? 0,
      skippedOldCount: autoScrollSess?.skippedOldCount ?? 0,
      expandedCount: autoScrollSess?.expandedCount ?? 0
    },
    refetchQueue: {
      total: refetchQueued,
      running: refetchIntervalHandle !== null,
      processed: refetchSess?.processed ?? 0,
      total_at_start: refetchSess?.totalAtStart ?? 0
    },
    mediaCrawlQueue: {
      total: mediaCrawlQueued,
      running: mediaCrawlIntervalHandle !== null,
      processed: mediaCrawlSess?.processed ?? 0,
      total_at_start: mediaCrawlSess?.totalAtStart ?? 0
    },
    threadOpenQueue: {
      total: threadOpenQueued,
      running: threadOpenIntervalHandle !== null,
      processed: threadOpenSess?.processed ?? 0,
      total_at_start: threadOpenSess?.totalAtStart ?? 0
    },
    recentTweetSightings
  };
}
function redactSettings(s) {
  return {
    owner: s.owner,
    repo: s.repo,
    branch: s.branch,
    enabled: s.enabled,
    autoCapture: s.autoCapture,
    configuredAt: s.configuredAt,
    autoScrollIntervalSec: s.autoScrollIntervalSec,
    updateExisting: s.updateExisting,
    lowBandwidthBrowsing: s.lowBandwidthBrowsing,
    patSet: s.pat.length > 0,
    patSuffix: s.pat.length >= 4 ? s.pat.slice(-4) : ""
  };
}
function parseArchiveSnapshot(raw) {
  if (!raw || typeof raw !== "object") throw new Error("manifest is not an object");
  const manifest = raw;
  if (!Array.isArray(manifest.accounts)) throw new Error("manifest.accounts is not an array");
  const accounts = {};
  for (const entry of manifest.accounts) {
    if (!entry || typeof entry !== "object") continue;
    const row = entry;
    const handle = typeof row.handle === "string" ? row.handle : "";
    if (!handle || handle === "_misc") continue;
    accounts[handle.toLowerCase()] = {
      handle,
      latest_post_at: typeof row.latest_post_at === "string" ? row.latest_post_at : null,
      latest_capture_at: typeof row.latest_capture_at === "string" ? row.latest_capture_at : null,
      row_count: typeof row.row_count === "number" ? row.row_count : null
    };
  }
  return {
    generated_at: typeof manifest.generated_at === "string" ? manifest.generated_at : null,
    fetched_at: (/* @__PURE__ */ new Date()).toISOString(),
    accounts
  };
}
function archiveSnapshotHasTweet(t, snapshot) {
  if (!snapshot) return false;
  const entry = snapshot.accounts[t.account_handle.toLowerCase()];
  if (!entry?.latest_post_at) return false;
  const posted = Date.parse(t.posted_at);
  const latest = Date.parse(entry.latest_post_at);
  return Number.isFinite(posted) && Number.isFinite(latest) && posted <= latest;
}
function buildTweetSighting(t, endpoint, seenAt, freshness = "new", action = "buffered") {
  return {
    tweet_id: t.tweet_id,
    account_handle: t.account_handle,
    posted_at: t.posted_at,
    text: t.text_resolved || t.text,
    tweet_type: t.tweet_type,
    tweet_url: t.tweet_url,
    seen_at: seenAt,
    endpoint,
    archive_status: freshness === "existing" ? "saved" : "new",
    action
  };
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function isoCompact(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso.replace(/[:.]/g, "");
  const pad = (n, w = 2) => String(n).padStart(w, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}Z`;
}
function viewerUrl(s) {
  return `https://${s.owner}.github.io/${s.repo}/`;
}
function probeTypenames(node) {
  const seen = /* @__PURE__ */ new Set();
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (typeof obj2.__typename === "string") seen.add(obj2.__typename);
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return [...seen].sort();
}
function probeFirstTypeShape(node, typename) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        return Object.keys(obj2).sort();
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  return null;
}
function probeTypedNested(node, typename, path) {
  const visited = /* @__PURE__ */ new WeakSet();
  const stack = [node];
  let found = null;
  while (stack.length > 0) {
    const n = stack.pop();
    if (n === null || typeof n !== "object") continue;
    if (visited.has(n)) continue;
    visited.add(n);
    if (Array.isArray(n)) {
      for (const v of n) stack.push(v);
    } else {
      const obj2 = n;
      if (obj2.__typename === typename) {
        found = obj2;
        break;
      }
      for (const v of Object.values(obj2)) stack.push(v);
    }
  }
  if (!found) return null;
  let cur = found;
  for (const seg of path) {
    if (cur === null || typeof cur !== "object") return `<${cur === null ? "null" : typeof cur}>`;
    cur = cur[seg];
  }
  if (cur === void 0) return "<missing>";
  if (cur === null) return "<null>";
  if (typeof cur !== "object") return `<${typeof cur}>`;
  if (Array.isArray(cur)) return `<array len=${cur.length}>`;
  return Object.keys(cur).sort();
}
function shortenUrl(u) {
  try {
    const parsed = new URL(u);
    const path = parsed.pathname + (parsed.search ? "?\u2026" : "");
    return parsed.host === "x.com" || parsed.host === "twitter.com" ? path : `${parsed.host}${path}`;
  } catch {
    return u.length > 80 ? `${u.slice(0, 80)}\u2026` : u;
  }
}
globalThis.__immArchive = {
  clearAll,
  activity: getActivity,
  accounts: getAccounts,
  buffers: getRunBuffers,
  flushAll: () => flushAll("devtools"),
  state: buildState,
  refetchQueue: getRefetchQueue,
  startRefetch: startRefetchLoop,
  cancelRefetch: cancelRefetchLoop,
  mediaCrawlQueue: getMediaCrawlQueue,
  startMediaCrawl: startMediaCrawlLoop,
  cancelMediaCrawl: cancelMediaCrawlLoop,
  threadOpenQueue: getThreadOpenQueue,
  startThreadOpen: startThreadOpenLoop,
  cancelThreadOpen: cancelThreadOpenLoop
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9saWIvbG9nZ2VyLnRzIiwgIi4uL3NyYy9saWIvZ2l0aHViLnRzIiwgIi4uL3NyYy9saWIvbm9ybWFsaXplLnRzIiwgIi4uL3NyYy9saWIvcnVuaWRzLnRzIiwgIi4uL3NyYy9saWIveWFtbC50cyIsICIuLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q29uZmlnLCBTZXR0aW5ncyB9IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xyXG4gIHBhdDogJycsXHJcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcclxuICByZXBvOiAneCcsXHJcbiAgLy8gVGhlIHJlcG8ncyBjdXJyZW50IGRlZmF1bHQgYnJhbmNoIGlzIFwibWFzdGVyXCIuIElmIHlvdSBmb3JrIG9yIHJlbmFtZVxyXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXHJcbiAgYnJhbmNoOiAnbWFzdGVyJyxcclxuICBlbmFibGVkOiB0cnVlLFxyXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxyXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxuICB1cGRhdGVFeGlzdGluZzogdHJ1ZSxcbiAgbG93QmFuZHdpZHRoQnJvd3Npbmc6IGZhbHNlLFxufTtcblxyXG5leHBvcnQgY29uc3QgQVVUT19TQ1JPTExfTUlOX1NFQyA9IDM7XHJcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XHJcblxyXG4vLyBCdWlsdC1pbiBmYWxsYmFjayBpZiBjb25maWcvYWNjb3VudHMueWFtbCBjYW5ub3QgYmUgZmV0Y2hlZCAoZS5nLiwgYmVmb3JlIHRoZVxyXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXHJcbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xyXG4gIHsgaGFuZGxlOiAnREhTZ292JywgbGFiZWw6ICdEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnVVNDSVMnLCBsYWJlbDogJ1UuUy4gQ2l0aXplbnNoaXAgYW5kIEltbWlncmF0aW9uIFNlcnZpY2VzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1BPVFVTJywgbGFiZWw6ICdQcmVzaWRlbnQgb2YgdGhlIFVuaXRlZCBTdGF0ZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXHJcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1N0ZXBoZW5NJywgbGFiZWw6ICdTdGVwaGVuIE1pbGxlcicsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ0dyZWdvcnlLQm92aW5vJywgbGFiZWw6ICdHcmVnb3J5IEJvdmlubycsIGNhdGVnb3J5OiAnY29yZScgfSxcclxuICB7IGhhbmRsZTogJ1JlYWxUb21Ib21hbicsIGxhYmVsOiAnVGhvbWFzIEQuIEhvbWFuJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxyXG5dO1xyXG5cclxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cclxuZXhwb3J0IGNvbnN0IFRXRUVUX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdVc2VyVHdlZXRzJyxcclxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxyXG4gICdVc2VyTWVkaWEnLFxyXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXHJcbiAgJ1R3ZWV0RGV0YWlsJyxcclxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXHJcbiAgJ0xpa2VzJyxcclxuICAnQm9va21hcmtzJyxcclxuICAnSG9tZVRpbWVsaW5lJyxcclxuICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcclxuICAnU2VhcmNoVGltZWxpbmUnLFxyXG4gICdMaXN0TGF0ZXN0VHdlZXRzVGltZWxpbmUnLFxyXG5dKTtcclxuXHJcbi8vIEVuZHBvaW50cyB0aGF0IGNhcnJ5IENvbW11bml0eSBOb3RlIGJvZGllcyBcdTIwMTQgY2FwdHVyZWQgZm9yIGNvbXBsZXRlbmVzcyBidXRcclxuLy8gdGhleSBkb24ndCBpbnRyb2R1Y2UgbmV3IHR3ZWV0cywgc28gdGhleSBkb24ndCBuZWVkIHRvIGJlIGluIFRXRUVUX0VORFBPSU5UUy5cclxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcclxuICAnQmlyZHdhdGNoRmV0Y2hPbmVOb3RlJyxcclxuICAnQmlyZHdhdGNoRmV0Y2hOb3RlcycsXHJcbl0pO1xyXG5cclxuLy8gQXV4aWxpYXJ5IGVuZHBvaW50cyB3ZSBkb24ndCBleHRyYWN0IHR3ZWV0cyBmcm9tIGJ1dCB1c2UgZm9yIGNvbnRleHQgKGUuZy4sXHJcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXHJcbmV4cG9ydCBjb25zdCBQUk9GSUxFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoWydVc2VyQnlTY3JlZW5OYW1lJywgJ1VzZXJCeVJlc3RJZCddKTtcclxuXHJcbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxyXG4vLyBjb252ZXJzYXRpb24gXHUyMDE0IGkuZS4gdmlzaXRpbmcgYC88aGFuZGxlPmAgLyBgLzxoYW5kbGU+L3dpdGhfcmVwbGllc2AsXHJcbi8vIGxvb2tpbmcgYXQgb25lIHR3ZWV0LCBldGMuIEV2ZXJ5IHR3ZWV0IHJldHVybmVkIGJ5IHRoZXNlIGVuZHBvaW50cyBpc1xyXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cclxuLy8gKHJldHdlZXRlZCwgcXVvdGVkLCByZXBsaWVkIHRvKSwgc28gd2Uga2VlcCBldmVyeXRoaW5nIHdlIHNlZSByYXRoZXJcclxuLy8gdGhhbiBkcm9wcGluZyBub24tdHJhY2tlZCBhdXRob3JzLiBUaGF0IHdheSBhIHJldHdlZXQgb2YgYSBub24tdHJhY2tlZFxyXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXHJcbi8vXHJcbi8vIEVuZHBvaW50cyBOT1QgaW4gdGhpcyBzZXQgKEhvbWVUaW1lbGluZSwgU2VhcmNoVGltZWxpbmUsIExpa2VzLCBldGMuKVxyXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3NcclxuLy8gXCJCcm93c2luZyBteSBob21lIHRpbWVsaW5lIGlzIGlnbm9yZWRcIiBydWxlLlxyXG5leHBvcnQgY29uc3QgVVNFUl9QQUdFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xyXG4gICdVc2VyVHdlZXRzJyxcclxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxyXG4gICdVc2VyTWVkaWEnLFxyXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXHJcbiAgJ1R3ZWV0RGV0YWlsJyxcclxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXHJcbl0pO1xyXG5cclxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XHJcblxyXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xyXG5cclxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXHJcbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcclxuXHJcbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cclxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xyXG5cclxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxyXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcclxuXHJcbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xyXG4iLCAiLyoqXHJcbiAqIGNyeXB0by50cyBcdTIwMTQgYXQtcmVzdCBlbmNyeXB0aW9uIGZvciBzZW5zaXRpdmUgc2V0dGluZ3MgKHRoZSBQQVQpLlxyXG4gKlxyXG4gKiBUaHJlYXQgbW9kZWw6IGFuIGF0dGFja2VyIHdobyByZWFkcyBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCAoZGV2dG9vbHMsIGFcclxuICogZm9yZ290dGVuIGJhY2t1cCwgYSBtaXNjb25maWd1cmVkIHByb2ZpbGUgc3luYykgc2hvdWxkIG5vdCBzZWUgYSB1c2FibGVcclxuICogR2l0SHViIFBBVCBpbiBwbGFpbnRleHQuIEEgZGV0ZXJtaW5lZCBhdHRhY2tlciB3aXRoIHRoZSBleHRlbnNpb24ncyBzb3VyY2VcclxuICogY2FuIHN0aWxsIGRlcml2ZSB0aGUga2V5IFx1MjAxNCB3ZSBtYWtlIG5vIGNsYWltIG9mIFwicmVhbFwiIGNyeXB0b2dyYXBoaWNcclxuICogY29uZmlkZW50aWFsaXR5LiBUaGUgYWltIGlzIHRvIHJhaXNlIHRoZSBiYXIgc28gdGhlIFBBVCBpc24ndCBhIGNvcHlhYmxlXHJcbiAqIHN0cmluZyBzaXR0aW5nIG5leHQgdG8gaXRzIGtleSBuYW1lIGluIGV4dGVuc2lvbiBzdG9yYWdlLlxyXG4gKlxyXG4gKiBTY2hlbWU6XHJcbiAqICAgLSBPbiBmaXJzdCBlbmNyeXB0aW9uIHdlIGdlbmVyYXRlIGEgMzItYnl0ZSBzYWx0IGFuZCBwZXJzaXN0IGl0IGluXHJcbiAqICAgICBgYnJvd3Nlci5zdG9yYWdlLmxvY2FsYCB1bmRlciBgX19pbW1fYXJjaGl2ZV9zYWx0X19gLlxyXG4gKiAgIC0gV2UgZGVyaXZlIGFuIEFFUy1HQ00ga2V5IGJ5IFNIQS0yNTYnaW5nIGBzYWx0IHx8IHJ1bnRpbWUuaWQgfHwgdmVyc2lvblxyXG4gKiAgICAgfHwgXCJpbW0tYXJjaGl2ZS1wYXQtdjFcImAuIFRoZSBzYWx0IGJlaW5nIHBlci1pbnN0YWxsIG1lYW5zIHR3byBjb3BpZXNcclxuICogICAgIG9mIHRoZSBleHRlbnNpb24gZG9uJ3Qgc2hhcmUgYSBrZXkuIFRoZSBydW50aW1lLmlkIGlzIHRoZSBleHRlbnNpb24nc1xyXG4gKiAgICAgVVVJRCBcdTIwMTQgc3RhYmxlIGZvciBhIGdpdmVuIGluc3RhbGwgYnV0IHVua25vd24gdG8gYSByZW1vdGUgYXR0YWNrZXIuXHJcbiAqICAgLSBQbGFpbnRleHQgaXMgZW5jcnlwdGVkIHdpdGggYSBmcmVzaCAxMi1ieXRlIElWLiBUaGUgZW52ZWxvcGUgZm9ybWF0IGlzXHJcbiAqICAgICBgdjE6PGl2LWI2ND46PGNpcGhlcnRleHQtYjY0PmAgYW5kIGlzIHdoYXQgZ2V0cyBzdG9yZWQuXHJcbiAqXHJcbiAqIEJhY2t3YXJkcyBjb21wYXRpYmlsaXR5OiBhbiB1bnByZWZpeGVkIHZhbHVlIGlzIHRyZWF0ZWQgYXMgbGVnYWN5XHJcbiAqIHBsYWludGV4dCwgZGVjcnlwdGVkIHRvIGl0c2VsZiwgYW5kIHJlLWVuY3J5cHRlZCBvbiB0aGUgbmV4dCB3cml0ZS5cclxuICovXHJcblxyXG5jb25zdCBTQUxUX1NUT1JBR0VfS0VZID0gJ19faW1tX2FyY2hpdmVfc2FsdF9fJztcclxuY29uc3QgRU5WRUxPUEVfUFJFRklYID0gJ3YxOic7XHJcblxyXG5sZXQgZGVyaXZlZEtleUNhY2hlOiBDcnlwdG9LZXkgfCBudWxsID0gbnVsbDtcclxubGV0IGRlcml2ZWRLZXlDYWNoZVNhbHQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xyXG5cclxuZnVuY3Rpb24gdG9CYXNlNjQoYnVmOiBVaW50OEFycmF5KTogc3RyaW5nIHtcclxuICBsZXQgcyA9ICcnO1xyXG4gIGZvciAoY29uc3QgYiBvZiBidWYpIHMgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShiKTtcclxuICByZXR1cm4gYnRvYShzKTtcclxufVxyXG5cclxuZnVuY3Rpb24gZnJvbUJhc2U2NChzOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcclxuICBjb25zdCBiaW4gPSBhdG9iKHMpO1xyXG4gIGNvbnN0IG91dCA9IG5ldyBVaW50OEFycmF5KGJpbi5sZW5ndGgpO1xyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYmluLmxlbmd0aDsgaSsrKSBvdXRbaV0gPSBiaW4uY2hhckNvZGVBdChpKTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBsb2FkT3JDcmVhdGVTYWx0KCk6IFByb21pc2U8eyBzYWx0QjY0OiBzdHJpbmc7IHNhbHQ6IFVpbnQ4QXJyYXkgfT4ge1xyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoU0FMVF9TVE9SQUdFX0tFWSk7XHJcbiAgY29uc3QgdiA9IHN0b3JlZFtTQUxUX1NUT1JBR0VfS0VZXTtcclxuICBpZiAodHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCkge1xyXG4gICAgcmV0dXJuIHsgc2FsdEI2NDogdiwgc2FsdDogZnJvbUJhc2U2NCh2KSB9O1xyXG4gIH1cclxuICBjb25zdCBzYWx0ID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgzMikpO1xyXG4gIGNvbnN0IHNhbHRCNjQgPSB0b0Jhc2U2NChzYWx0KTtcclxuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NBTFRfU1RPUkFHRV9LRVldOiBzYWx0QjY0IH0pO1xyXG4gIHJldHVybiB7IHNhbHRCNjQsIHNhbHQgfTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZGVyaXZlS2V5KCk6IFByb21pc2U8Q3J5cHRvS2V5PiB7XHJcbiAgY29uc3QgeyBzYWx0QjY0LCBzYWx0IH0gPSBhd2FpdCBsb2FkT3JDcmVhdGVTYWx0KCk7XHJcbiAgaWYgKGRlcml2ZWRLZXlDYWNoZSAhPT0gbnVsbCAmJiBkZXJpdmVkS2V5Q2FjaGVTYWx0ID09PSBzYWx0QjY0KSB7XHJcbiAgICByZXR1cm4gZGVyaXZlZEtleUNhY2hlO1xyXG4gIH1cclxuICBjb25zdCBzZWVkID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKFxyXG4gICAgYCR7YnJvd3Nlci5ydW50aW1lLmlkfXwke2Jyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb259fGltbS1hcmNoaXZlLXBhdC12MWBcclxuICApO1xyXG4gIGNvbnN0IGNvbWJpbmVkID0gbmV3IFVpbnQ4QXJyYXkoc2VlZC5sZW5ndGggKyBzYWx0Lmxlbmd0aCk7XHJcbiAgY29tYmluZWQuc2V0KHNlZWQsIDApO1xyXG4gIGNvbWJpbmVkLnNldChzYWx0LCBzZWVkLmxlbmd0aCk7XHJcbiAgY29uc3QgaGFzaCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KCdTSEEtMjU2JywgY29tYmluZWQpO1xyXG4gIGNvbnN0IGtleSA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuaW1wb3J0S2V5KCdyYXcnLCBoYXNoLCB7IG5hbWU6ICdBRVMtR0NNJyB9LCBmYWxzZSwgW1xyXG4gICAgJ2VuY3J5cHQnLFxyXG4gICAgJ2RlY3J5cHQnLFxyXG4gIF0pO1xyXG4gIGRlcml2ZWRLZXlDYWNoZSA9IGtleTtcclxuICBkZXJpdmVkS2V5Q2FjaGVTYWx0ID0gc2FsdEI2NDtcclxuICByZXR1cm4ga2V5O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaXNFbmNyeXB0ZWRQYXQodjogc3RyaW5nKTogYm9vbGVhbiB7XHJcbiAgcmV0dXJuIHYuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5jcnlwdFBhdChwbGFpbnRleHQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XHJcbiAgaWYgKCFwbGFpbnRleHQpIHJldHVybiAnJztcclxuICBjb25zdCBrZXkgPSBhd2FpdCBkZXJpdmVLZXkoKTtcclxuICBjb25zdCBpdiA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTIpKTtcclxuICBjb25zdCBjdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZW5jcnlwdChcclxuICAgIHsgbmFtZTogJ0FFUy1HQ00nLCBpdiB9LFxyXG4gICAga2V5LFxyXG4gICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHBsYWludGV4dClcclxuICApO1xyXG4gIHJldHVybiBgJHtFTlZFTE9QRV9QUkVGSVh9JHt0b0Jhc2U2NChpdil9OiR7dG9CYXNlNjQobmV3IFVpbnQ4QXJyYXkoY3QpKX1gO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVjcnlwdFBhdChlbnZlbG9wZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICBpZiAoIWVudmVsb3BlKSByZXR1cm4gJyc7XHJcbiAgLy8gTGVnYWN5IHBsYWludGV4dCAocHJlLWVuY3J5cHRpb24gaW5zdGFsbHMpOiBwYXNzIHRocm91Z2guIFRoZSBuZXh0IHNhdmVcclxuICAvLyByZS1lbmNyeXB0cyBpdCB2aWEgdGhlIHN0b3JhZ2UgbGF5ZXIuXHJcbiAgaWYgKCFlbnZlbG9wZS5zdGFydHNXaXRoKEVOVkVMT1BFX1BSRUZJWCkpIHJldHVybiBlbnZlbG9wZTtcclxuICBjb25zdCBwYXJ0cyA9IGVudmVsb3BlLnNsaWNlKEVOVkVMT1BFX1BSRUZJWC5sZW5ndGgpLnNwbGl0KCc6Jyk7XHJcbiAgaWYgKHBhcnRzLmxlbmd0aCAhPT0gMikgcmV0dXJuICcnO1xyXG4gIGNvbnN0IFtpdkI2NCwgY3RCNjRdID0gcGFydHM7XHJcbiAgaWYgKCFpdkI2NCB8fCAhY3RCNjQpIHJldHVybiAnJztcclxuICB0cnkge1xyXG4gICAgY29uc3Qga2V5ID0gYXdhaXQgZGVyaXZlS2V5KCk7XHJcbiAgICBjb25zdCBpdiA9IGZyb21CYXNlNjQoaXZCNjQpO1xyXG4gICAgY29uc3QgY3QgPSBmcm9tQmFzZTY0KGN0QjY0KTtcclxuICAgIGNvbnN0IHB0ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5kZWNyeXB0KFxyXG4gICAgICB7IG5hbWU6ICdBRVMtR0NNJywgaXY6IGl2IGFzIEJ1ZmZlclNvdXJjZSB9LFxyXG4gICAgICBrZXksXHJcbiAgICAgIGN0IGFzIEJ1ZmZlclNvdXJjZVxyXG4gICAgKTtcclxuICAgIHJldHVybiBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUocHQpO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuICcnO1xyXG4gIH1cclxufVxyXG4iLCAiaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUywgRkFMTEJBQ0tfQUNDT1VOVFMsIEFDVElWSVRZX1RBSUxfTUFYIH0gZnJvbSAnLi9jb25maWcuanMnO1xyXG5pbXBvcnQgeyBkZWNyeXB0UGF0LCBlbmNyeXB0UGF0LCBpc0VuY3J5cHRlZFBhdCB9IGZyb20gJy4vY3J5cHRvLmpzJztcclxuaW1wb3J0IHR5cGUge1xyXG4gIEFjY291bnRDb25maWcsXHJcbiAgQWNjb3VudENvdW50ZXIsXHJcbiAgQXJjaGl2ZVNuYXBzaG90LFxyXG4gIENhbm9uaWNhbFR3ZWV0LFxyXG4gIENvbm5lY3Rpb25TdGF0ZSxcclxuICBMb2dFdmVudCxcclxuICBSZXR3ZWV0RWRnZSxcclxuICBTZXR0aW5ncyxcclxuICBUd2VldFNpZ2h0aW5nLFxyXG4gIFVuYXZhaWxhYmxlVHdlZXQsXHJcbn0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG4vKipcclxuICogQnVmZmVyZWQgdHdlZXRzIGZvciBhIGdpdmVuIGFjY291bnQsIGF3YWl0aW5nIGNvbW1pdC4gQSBcInJ1blwiIGlzIG9uZSBlbnRyeVxyXG4gKiBpbiB0aGlzIG1hcDsgZmx1c2hpbmcgY2xlYXJzIHRoZSBlbnRyeS4gV2Ugc3RvcmUgYXMgUmVjb3JkIHNvIHRoZSBzdHJ1Y3R1cmVcclxuICogc3Vydml2ZXMgSlNPTiBzZXJpYWxpemF0aW9uIHRocm91Z2ggYnJvd3Nlci5zdG9yYWdlLlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBSdW5CdWZmZXIge1xyXG4gIHJ1bl9pZDogc3RyaW5nO1xyXG4gIGFjY291bnRfaGFuZGxlOiBzdHJpbmc7XHJcbiAgc3RhcnRlZF9hdDogc3RyaW5nO1xyXG4gIGxhc3RfY2FwdHVyZV9hdDogc3RyaW5nO1xyXG4gIHR3ZWV0c19ieV9pZDogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+O1xyXG4gIHVuYXZhaWxhYmxlX2J5X2lkPzogUmVjb3JkPHN0cmluZywgVW5hdmFpbGFibGVUd2VldD47XHJcbiAgcmV0d2VldF9lZGdlc19ieV9rZXk/OiBSZWNvcmQ8c3RyaW5nLCBSZXR3ZWV0RWRnZT47XHJcbiAgdHdlZXRfaWRzX29ic2VydmVkOiBzdHJpbmdbXTtcclxuICBlbmRwb2ludHNfc2Vlbjogc3RyaW5nW107XHJcbiAgc291cmNlX3VybDogc3RyaW5nIHwgbnVsbDtcclxufVxyXG5cclxuLyoqIFBlci10d2VldCBjb21taXR0ZWQtc3RhdGUgaW5kZXgsIGtleWVkIGJ5IGhhbmRsZSB0aGVuIHR3ZWV0X2lkLlxyXG4gKiBVc2VkIHRvIHNraXAgcmUtY2FwdHVyaW5nIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IHB1c2hlZCB3aXRoIGlkZW50aWNhbFxyXG4gKiBlbmdhZ2VtZW50IGNvdW50cyBcdTIwMTQgYXZvaWRzIGdlbmVyYXRpbmcgb25lIG5ldyByYXcvKiBmaWxlIGV2ZXJ5IGJyb3dzZS4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBDb21taXR0ZWRFbnRyeSB7XHJcbiAgdHM6IHN0cmluZzsgLy8gSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBjb21taXRcclxuICBzaWc6IHN0cmluZzsgLy8gZW5nYWdlbWVudCBzaWduYXR1cmU6IFwibGlrZXxydHxyZXBseXxxdW90ZVwiXHJcbn1cclxuXHJcbi8qKiBQcm9ncmVzcyArIGluZmxpZ2h0IHRyYWNraW5nIGZvciBhIHF1ZXVlLWRyaXZlbiBsb29wIChyZWZldGNoIC8gbWVkaWEtY3Jhd2wpLlxyXG4gKiBUaGUgbG9vcCBwZXJzaXN0cyB0aGlzIHNvIGEgU1cgZXZpY3Rpb24gaW4gdGhlIG1pZGRsZSBvZiBhIHJ1biBwcmVzZXJ2ZXNcclxuICogXCJYIG9mIFkgcHJvY2Vzc2VkXCIgXHUyMDE0IGFuZCB0aGUgd2FpdC1mb3ItaW5nZXN0IGd1YXJkIGtub3dzIHdoYXQgdG8gZXhwZWN0LlxyXG4gKi9cclxuZXhwb3J0IGludGVyZmFjZSBMb29wU2Vzc2lvbiB7XHJcbiAgLyoqIEluaXRpYWwgcXVldWUgc2l6ZSB3aGVuIHRoZSB1c2VyIGNsaWNrZWQgXCJTdGFydFwiLiAqL1xyXG4gIHRvdGFsQXRTdGFydDogbnVtYmVyO1xyXG4gIC8qKiBUd2VldHMgcHJvY2Vzc2VkIChpbmdlc3RlZCBPUiBkcm9wcGVkIGFmdGVyIHJldHJpZXMpIHNvIGZhci4gKi9cclxuICBwcm9jZXNzZWQ6IG51bWJlcjtcclxuICAvKiogSVNPIG9mIHdoZW4gdGhpcyBzZXNzaW9uIHN0YXJ0ZWQuICovXHJcbiAgc3RhcnRlZEF0OiBzdHJpbmc7XHJcbiAgLyoqIFR3ZWV0IGN1cnJlbnRseSBpbmZsaWdodCBcdTIwMTQgd2UgbmF2aWdhdGVkIHRvIGl0IGFuZCBhcmUgd2FpdGluZyBmb3IgdGhlXHJcbiAgICogcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIHJlc3BvbnNlIGJlZm9yZSBhZHZhbmNpbmcuIG51bGwgYmV0d2VlbiB0aWNrc1xyXG4gICAqIChhbmQgb25jZSBhbiBpbmdlc3QgaGFzIGJlZW4gb2JzZXJ2ZWQpLiAqL1xyXG4gIGluZmxpZ2h0OiB7IHR3ZWV0SWQ6IHN0cmluZzsgbmF2aWdhdGVkQXQ6IHN0cmluZyB9IHwgbnVsbDtcclxufVxyXG5cclxuLyoqIEF1dG8tc2Nyb2xsIHNlc3Npb246IGNvdW50cyBvZiB0aWNrcyBhbmQgdHdlZXRzIGluZ2VzdGVkIHNpbmNlIHRoZSB1c2VyXHJcbiAqIGNsaWNrZWQgU3RhcnQuIFBlcnNpc3RlZCBzbyBTVyBldmljdGlvbiBkdXJpbmcgYSBydW4ga2VlcHMgcHJvZ3Jlc3MuICovXHJcbmV4cG9ydCBpbnRlcmZhY2UgQXV0b1Njcm9sbFNlc3Npb24ge1xyXG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xyXG4gIHNjcm9sbENvdW50OiBudW1iZXI7XHJcbiAgaW5nZXN0ZWRDb3VudDogbnVtYmVyO1xyXG4gIGluZ2VzdGVkTmV3Q291bnQ6IG51bWJlcjtcclxuICBpbmdlc3RlZEV4aXN0aW5nQ291bnQ6IG51bWJlcjtcclxuICBza2lwcGVkT2xkQ291bnQ6IG51bWJlcjtcclxuICBleHBhbmRlZENvdW50OiBudW1iZXI7XHJcbn1cclxuXHJcbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xyXG4gIHNldHRpbmdzOiBTZXR0aW5ncztcclxuICBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdO1xyXG4gIC8qKiBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IHN1Y2Nlc3NmdWwgYWNjb3VudHMueWFtbCBmZXRjaCBmcm9tIHRoZSByZXBvLlxyXG4gICAqIFVzZWQgYnkgYHJlZnJlc2hBY2NvdW50c0xpc3RgIHRvIHNraXAgcmUtZmV0Y2hpbmcgb24gZXZlcnkgU1cgd2FrZSBcdTIwMTQgdGhlXHJcbiAgICogZmlsZSBjaGFuZ2VzIHJhcmVseSBhbmQgYW4gYXV0aGVudGljYXRlZCByYXcgZmV0Y2ggZXZlcnkgd2FrZSBhZGRzIHVwLiAqL1xyXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IHN0cmluZyB8IG51bGw7XHJcbiAgYXJjaGl2ZVNuYXBzaG90OiBBcmNoaXZlU25hcHNob3QgfCBudWxsO1xyXG4gIGNvbm5lY3Rpb246IENvbm5lY3Rpb25TdGF0ZTtcclxuICBjb3VudGVyczogUmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+O1xyXG4gIHJ1bkJ1ZmZlcnM6IFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj47XHJcbiAgYWN0aXZpdHk6IExvZ0V2ZW50W107XHJcbiAgcmVjZW50VHdlZXRTaWdodGluZ3M6IFR3ZWV0U2lnaHRpbmdbXTtcclxuICBjb21taXR0ZWRJbmRleDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PjtcclxuICAvKiogVHdlZXRzIHRoZSBub3JtYWxpemVyIGZsYWdnZWQgYXMgdHJ1bmNhdGVkIGFuZCB0aGF0IHdlIGhhdmVuJ3Qgc2VlbiBhXHJcbiAgICogZnVsbC10ZXh0IHZlcnNpb24gb2YgeWV0LiBLZXllZCBieSBoYW5kbGUgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gKi9cclxuICByZWZldGNoUXVldWU6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPjtcclxuICAvKiogVHdlZXQgSURzIHNlZW4gdmlhIE1lZGlhLXRhYiAvIHBhcnRpYWwgY2FwdHVyZXMgdGhhdCBjb3VsZG4ndCBiZVxyXG4gICAqIG5vcm1hbGl6ZWQgaW50byBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBLZXllZCBieSBoaW50LWhhbmRsZSAob3JcclxuICAgKiBcIl91bmtub3duXCIpIFx1MjE5MiBhcnJheSBvZiB0d2VldCBpZHMuIFRoZSB1c2VyIGNhbiBkcml2ZSBhIGNyYXdsIHRoYXRcclxuICAgKiBvcGVucyBlYWNoIGRldGFpbCBwYWdlIHRvIGNhcHR1cmUgdGhlIHJlYWwgdGhpbmcuICovXHJcbiAgbWVkaWFDcmF3bFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XHJcbiAgLyoqIENvcmUtYWNjb3VudCB0aHJlYWQgcm9vdHMgd29ydGggb3BlbmluZyBiZWNhdXNlIHRpbWVsaW5lL3NlYXJjaCB2aWV3cyBtYXlcclxuICAgKiBvbWl0IGxhdGVyIHNlbGYtcmVwbGllcy4gS2V5ZWQgYnkgaGludC1oYW5kbGUgLT4gcm9vdCB0d2VldCBpZHMuICovXHJcbiAgdGhyZWFkT3BlblF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XHJcbiAgLyoqIFJvb3QgdHdlZXQgaWRzIGFscmVhZHkgYXR0ZW1wdGVkIGJ5IHRoZSB0aHJlYWQtb3BlbmluZyB1dGlsaXR5LiAqL1xyXG4gIHRocmVhZE9wZW5TZWVuOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xyXG4gIHJlZmV0Y2hTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XHJcbiAgbWVkaWFDcmF3bFNlc3Npb246IExvb3BTZXNzaW9uIHwgbnVsbDtcclxuICB0aHJlYWRPcGVuU2Vzc2lvbjogTG9vcFNlc3Npb24gfCBudWxsO1xyXG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw7XHJcbn1cclxuXHJcbmNvbnN0IERFRkFVTFRfQ09OTkVDVElPTjogQ29ubmVjdGlvblN0YXRlID0ge1xyXG4gIHN0YXR1czogJ3Vua25vd24nLFxyXG4gIGxvZ2luOiBudWxsLFxyXG4gIGNoZWNrZWRBdDogbnVsbCxcclxuICBlcnJvcjogbnVsbCxcclxuICBkZWZhdWx0QnJhbmNoOiBudWxsLFxyXG4gIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXHJcbiAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcclxufTtcclxuXHJcbmNvbnN0IERFRkFVTFRTOiBTdG9yYWdlU2hhcGUgPSB7XHJcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9LFxyXG4gIGFjY291bnRzOiBbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdLFxyXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IG51bGwsXHJcbiAgYXJjaGl2ZVNuYXBzaG90OiBudWxsLFxyXG4gIGNvbm5lY3Rpb246IHsgLi4uREVGQVVMVF9DT05ORUNUSU9OIH0sXHJcbiAgY291bnRlcnM6IHt9LFxyXG4gIHJ1bkJ1ZmZlcnM6IHt9LFxyXG4gIGFjdGl2aXR5OiBbXSxcclxuICByZWNlbnRUd2VldFNpZ2h0aW5nczogW10sXHJcbiAgY29tbWl0dGVkSW5kZXg6IHt9LFxyXG4gIHJlZmV0Y2hRdWV1ZToge30sXHJcbiAgbWVkaWFDcmF3bFF1ZXVlOiB7fSxcclxuICB0aHJlYWRPcGVuUXVldWU6IHt9LFxyXG4gIHRocmVhZE9wZW5TZWVuOiB7fSxcclxuICByZWZldGNoU2Vzc2lvbjogbnVsbCxcclxuICBtZWRpYUNyYXdsU2Vzc2lvbjogbnVsbCxcclxuICB0aHJlYWRPcGVuU2Vzc2lvbjogbnVsbCxcclxuICBhdXRvU2Nyb2xsU2Vzc2lvbjogbnVsbCxcclxufTtcclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGdldFJhdzxLIGV4dGVuZHMga2V5b2YgU3RvcmFnZVNoYXBlPihrZXk6IEspOiBQcm9taXNlPFN0b3JhZ2VTaGFwZVtLXT4ge1xyXG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoa2V5KTtcclxuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xyXG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICByZXR1cm4gc3RydWN0dXJlZENsb25lKERFRkFVTFRTW2tleV0pO1xyXG4gIH1cclxuICByZXR1cm4gdmFsdWUgYXMgU3RvcmFnZVNoYXBlW0tdO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBzZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLLCB2YWx1ZTogU3RvcmFnZVNoYXBlW0tdKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtrZXldOiB2YWx1ZSB9KTtcclxufVxyXG5cclxuLy8gLS0tIFNldHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XHJcbiAgLy8gQmFja2ZpbGwgYW55IGtleXMgdGhlIHVzZXIncyBzdG9yZWQgc2V0dGluZ3MgcHJlZGF0ZSBcdTIwMTQgcmVhZGVycyBjYW4gcmVseVxyXG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XHJcbiAgLy8gZXZlcnkgY2FsbHNpdGUuIFRoZSBQQVQgaXMgc3RvcmVkIGVuY3J5cHRlZC1hdC1yZXN0IGFzIG9mIHYwLjIuMDsgd2VcclxuICAvLyBkZWNyeXB0IHRyYW5zcGFyZW50bHkgc28gY2FsbGVycyBjb250aW51ZSB0byBzZWUgcGxhaW50ZXh0LlxyXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcclxuICBjb25zdCBtZXJnZWQgPSB7IC4uLkRFRkFVTFRfU0VUVElOR1MsIC4uLnN0b3JlZCB9O1xyXG4gIGlmIChtZXJnZWQucGF0ICYmIGlzRW5jcnlwdGVkUGF0KG1lcmdlZC5wYXQpKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBtZXJnZWQucGF0ID0gYXdhaXQgZGVjcnlwdFBhdChtZXJnZWQucGF0KTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICBtZXJnZWQucGF0ID0gJyc7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBtZXJnZWQ7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFNldHRpbmdzKHM6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXHJcbiAgLy8gb24gdGhlIG5leHQgc2F2ZS5cclxuICBjb25zdCB0b1dyaXRlOiBTZXR0aW5ncyA9IHsgLi4ucyB9O1xyXG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XHJcbiAgICB0b1dyaXRlLnBhdCA9IGF3YWl0IGVuY3J5cHRQYXQodG9Xcml0ZS5wYXQpO1xyXG4gIH1cclxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNldHRpbmdzKHBhdGNoOiBQYXJ0aWFsPFNldHRpbmdzPik6IFByb21pc2U8U2V0dGluZ3M+IHtcclxuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IG5leHQgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcclxuICBhd2FpdCBzZXRTZXR0aW5ncyhuZXh0KTtcclxuICByZXR1cm4gbmV4dDtcclxufVxyXG5cclxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50cygpOiBQcm9taXNlPEFjY291bnRDb25maWdbXT4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzKGE6IEFjY291bnRDb25maWdbXSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFjY291bnRzUmVmcmVzaGVkQXQoaXNvOiBzdHJpbmcgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcclxufVxyXG5cclxuLy8gLS0tIEFyY2hpdmUgc25hcHNob3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFyY2hpdmVTbmFwc2hvdCgpOiBQcm9taXNlPEFyY2hpdmVTbmFwc2hvdCB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdhcmNoaXZlU25hcHNob3QnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFyY2hpdmVTbmFwc2hvdChzbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYXJjaGl2ZVNuYXBzaG90Jywgc25hcHNob3QpO1xyXG59XHJcblxyXG4vLyAtLS0gQ29ubmVjdGlvbiBzdGF0ZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29ubmVjdGlvbigpOiBQcm9taXNlPENvbm5lY3Rpb25TdGF0ZT4ge1xyXG4gIGNvbnN0IGMgPSBhd2FpdCBnZXRSYXcoJ2Nvbm5lY3Rpb24nKTtcclxuICAvLyBCYWNrZmlsbCBmaWVsZHMgYWRkZWQgYWZ0ZXIgdGhlIHVzZXIncyBzdG9yYWdlIHdhcyB3cml0dGVuLlxyXG4gIGNvbnN0IG91dDogQ29ubmVjdGlvblN0YXRlID0ge1xyXG4gICAgLi4uYyxcclxuICAgIGRlZmF1bHRCcmFuY2g6IGMuZGVmYXVsdEJyYW5jaCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuZGVmYXVsdEJyYW5jaCxcclxuICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6XHJcbiAgICAgIGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMuY29uZmlndXJlZEJyYW5jaEV4aXN0cyxcclxuICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGMucmF0ZUxpbWl0UmVzZXRBdCA9PT0gdW5kZWZpbmVkID8gbnVsbCA6IGMucmF0ZUxpbWl0UmVzZXRBdCxcclxuICB9O1xyXG4gIHJldHVybiBvdXQ7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCdjb25uZWN0aW9uJywgYyk7XHJcbn1cclxuXHJcbi8vIC0tLSBDb3VudGVycyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xyXG4gIHJldHVybiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q291bnRlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBBY2NvdW50Q291bnRlcj4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdjb3VudGVycycpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBidW1wQ291bnRlcihcclxuICBoYW5kbGU6IHN0cmluZyxcclxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cclxuKTogUHJvbWlzZTxBY2NvdW50Q291bnRlcj4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldENvdW50ZXJzKCk7XHJcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xyXG4gICAgdG9kYXlDb3VudDogMCxcclxuICAgIHRvZGF5RGF0ZTogdG9kYXlJU08oKSxcclxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXHJcbiAgICB0b3RhbENvbW1pdHRlZDogMCxcclxuICAgIGJ1ZmZlcmVkQ291bnQ6IDAsXHJcbiAgfTtcclxuICBpZiAoY3VyLnRvZGF5RGF0ZSAhPT0gdG9kYXlJU08oKSkge1xyXG4gICAgY3VyLnRvZGF5RGF0ZSA9IHRvZGF5SVNPKCk7XHJcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XHJcbiAgfVxyXG4gIGNvbnN0IG5leHQ6IEFjY291bnRDb3VudGVyID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XHJcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xyXG4gIGF3YWl0IHNldFJhdygnY291bnRlcnMnLCBhbGwpO1xyXG4gIHJldHVybiBuZXh0O1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QnVmZmVyZWRDb3VudChoYW5kbGU6IHN0cmluZywgY291bnQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcclxufVxyXG5cclxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJ1bkJ1ZmZlcnMoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIHJldHVybiBhbGxbaGFuZGxlXSA/PyBudWxsO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nLCBidWY6IFJ1bkJ1ZmZlcik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBhbGxbaGFuZGxlXSA9IGJ1ZjtcclxuICBhd2FpdCBzZXRSYXcoJ3J1bkJ1ZmZlcnMnLCBhbGwpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgZGVsZXRlIGFsbFtoYW5kbGVdO1xyXG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XHJcbn1cclxuXHJcbi8vIC0tLSBBY3Rpdml0eSB0YWlsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWN0aXZpdHkoKTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XHJcbiAgcmV0dXJuIGdldFJhdygnYWN0aXZpdHknKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGVuZEFjdGl2aXR5KGV2OiBMb2dFdmVudCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xyXG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XHJcbiAgY3VyLnVuc2hpZnQoZXYpO1xyXG4gIGlmIChjdXIubGVuZ3RoID4gQUNUSVZJVFlfVEFJTF9NQVgpIGN1ci5sZW5ndGggPSBBQ1RJVklUWV9UQUlMX01BWDtcclxuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcclxuICByZXR1cm4gY3VyO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJBY3Rpdml0eSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgW10pO1xyXG59XHJcblxyXG4vLyAtLS0gUmVjZW50IHR3ZWV0IHNpZ2h0aW5ncyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmNvbnN0IFJFQ0VOVF9UV0VFVF9TSUdIVElOR1NfTUFYID0gODA7XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVjZW50VHdlZXRTaWdodGluZ3MoKTogUHJvbWlzZTxUd2VldFNpZ2h0aW5nW10+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdyZWNlbnRUd2VldFNpZ2h0aW5ncycpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJlcGVuZFJlY2VudFR3ZWV0U2lnaHRpbmdzKHJvd3M6IFR3ZWV0U2lnaHRpbmdbXSk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGlmIChyb3dzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk7XHJcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGNvbnN0IG5leHQ6IFR3ZWV0U2lnaHRpbmdbXSA9IFtdO1xyXG4gIGZvciAoY29uc3Qgcm93IG9mIHJvd3MpIHtcclxuICAgIGNvbnN0IGtleSA9IGAke3Jvdy5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpfToke3Jvdy50d2VldF9pZH1gO1xyXG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xyXG4gICAgc2Vlbi5hZGQoa2V5KTtcclxuICAgIG5leHQucHVzaChyb3cpO1xyXG4gIH1cclxuICBmb3IgKGNvbnN0IHJvdyBvZiBjdXIpIHtcclxuICAgIGNvbnN0IGtleSA9IGAke3Jvdy5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpfToke3Jvdy50d2VldF9pZH1gO1xyXG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xyXG4gICAgc2Vlbi5hZGQoa2V5KTtcclxuICAgIG5leHQucHVzaChyb3cpO1xyXG4gIH1cclxuICBuZXh0Lmxlbmd0aCA9IE1hdGgubWluKG5leHQubGVuZ3RoLCBSRUNFTlRfVFdFRVRfU0lHSFRJTkdTX01BWCk7XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWNlbnRUd2VldFNpZ2h0aW5ncycsIG5leHQpO1xyXG59XHJcblxyXG4vLyAtLS0gQ29tbWl0dGVkLXR3ZWV0cyBkZWR1cCBpbmRleCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29tbWl0dGVkSW5kZXgoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+PiB7XHJcbiAgcmV0dXJuIGdldFJhdygnY29tbWl0dGVkSW5kZXgnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbW1pdHRlZEluZGV4KFxyXG4gIGlkeDogUmVjb3JkPHN0cmluZywgUmVjb3JkPHN0cmluZywgQ29tbWl0dGVkRW50cnk+PlxyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ2NvbW1pdHRlZEluZGV4JywgaWR4KTtcclxufVxyXG5cclxuLyoqIENvbXB1dGUgdGhlIGVuZ2FnZW1lbnQgc2lnbmF0dXJlIHdlIHVzZSB0byBkZWNpZGUgd2hldGhlciBhIHJlLWNhcHR1cmVkXHJcbiAqIHR3ZWV0IGlzIFwibWF0ZXJpYWxseSBkaWZmZXJlbnRcIiBmcm9tIHdoYXQgd2UgbGFzdCBjb21taXR0ZWQuIFdlIG9taXRcclxuICogdmlld19jb3VudCBiZWNhdXNlIGl0IHRpY2tzIHVwIGZyZXF1ZW50bHkgb24gYWN0aXZlIHR3ZWV0cyBhbmQgd291bGRcclxuICogZGVmZWF0IHRoZSBkZWR1cC4gTGlrZXMgLyBSVHMgLyByZXBsaWVzIC8gcXVvdGVzIGNoYW5nZSByYXJlbHkgZW5vdWdoIHRoYXRcclxuICogZWFjaCBjaGFuZ2UgaXMgd29ydGggYSByZS1jb21taXQgKGFuZCBhbiBlbmdhZ2VtZW50X2hpc3Rvcnkgc25hcHNob3QpLlxyXG4gKiBgaXNfdHJ1bmNhdGVkYCBpcyBmb2xkZWQgaW4gc28gYSByZWZldGNoIHRoYXQgc3dhcHMgdGhlIDI4MC1jaGFyIGhlYWQgZm9yXHJcbiAqIHRoZSBmdWxsIGBub3RlX3R3ZWV0YCBib2R5IGJ5cGFzc2VzIHRoZSBkZWR1cCBldmVuIHdoZW4gZW5nYWdlbWVudCBjb3VudHNcclxuICogaGF2ZW4ndCBtb3ZlZCBcdTIwMTQgb3RoZXJ3aXNlIHRoZSBuZXcgYm9keSB3b3VsZCBiZSBzaWxlbnRseSBkcm9wcGVkLiAqL1xyXG5leHBvcnQgZnVuY3Rpb24gZW5nYWdlbWVudFNpZyhcclxuICBsaWtlczogbnVtYmVyLFxyXG4gIHJldHdlZXRzOiBudW1iZXIsXHJcbiAgcmVwbGllczogbnVtYmVyLFxyXG4gIHF1b3RlczogbnVtYmVyLFxyXG4gIGlzVHJ1bmNhdGVkOiBib29sZWFuID0gZmFsc2VcclxuKTogc3RyaW5nIHtcclxuICByZXR1cm4gYCR7bGlrZXN9fCR7cmV0d2VldHN9fCR7cmVwbGllc318JHtxdW90ZXN9fCR7aXNUcnVuY2F0ZWQgPyAndCcgOiAnZid9YDtcclxufVxyXG5cclxuLyoqIERyb3AgZW50cmllcyBvbGRlciB0aGFuIGBtYXhBZ2VNc2AuIFJldHVybnMgdGhlIG51bWJlciBwcnVuZWQuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcnVuZUNvbW1pdHRlZEluZGV4KG1heEFnZU1zOiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xyXG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgY29uc3QgY3V0b2ZmID0gbmV3IERhdGUoRGF0ZS5ub3coKSAtIG1heEFnZU1zKS50b0lTT1N0cmluZygpO1xyXG4gIGxldCBwcnVuZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcclxuICAgIGNvbnN0IGlubmVyID0gaWR4W2hhbmRsZV07XHJcbiAgICBpZiAoIWlubmVyKSBjb250aW51ZTtcclxuICAgIGZvciAoY29uc3QgdGlkIG9mIE9iamVjdC5rZXlzKGlubmVyKSkge1xyXG4gICAgICBjb25zdCBlID0gaW5uZXJbdGlkXTtcclxuICAgICAgaWYgKGUgJiYgZS50cyA8IGN1dG9mZikge1xyXG4gICAgICAgIGRlbGV0ZSBpbm5lclt0aWRdO1xyXG4gICAgICAgIHBydW5lZCArPSAxO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoT2JqZWN0LmtleXMoaW5uZXIpLmxlbmd0aCA9PT0gMCkgZGVsZXRlIGlkeFtoYW5kbGVdO1xyXG4gIH1cclxuICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcclxuICByZXR1cm4gcHJ1bmVkO1xyXG59XHJcblxyXG4vLyAtLS0gUmVmZXRjaCBxdWV1ZSAodHdlZXRzIG5lZWRpbmcgZnVsbC10ZXh0IHJlY2FwdHVyZSkgLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdyZWZldGNoUXVldWUnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlZmV0Y2hRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGxldCB0b3RhbCA9IDA7XHJcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcclxuICByZXR1cm4gdG90YWw7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlUmVmZXRjaChoYW5kbGU6IHN0cmluZywgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xyXG4gIGNvbnN0IGlkcyA9IHFbaGFuZGxlXSA/PyBbXTtcclxuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xyXG4gICAgaWRzLnB1c2godHdlZXRJZCk7XHJcbiAgICBxW2hhbmRsZV0gPSBpZHM7XHJcbiAgICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVSZWZldGNoKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgY29uc3QgaWRzID0gcVtoYW5kbGVdO1xyXG4gIGlmICghaWRzKSByZXR1cm47XHJcbiAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xyXG4gIGlmIChmaWx0ZXJlZC5sZW5ndGggPT09IDApIGRlbGV0ZSBxW2hhbmRsZV07XHJcbiAgZWxzZSBxW2hhbmRsZV0gPSBmaWx0ZXJlZDtcclxuICBhd2FpdCBzZXRSYXcoJ3JlZmV0Y2hRdWV1ZScsIHEpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbmV4dFJlZmV0Y2hUYXJnZXQoKTogUHJvbWlzZTx7XHJcbiAgaGFuZGxlOiBzdHJpbmc7XHJcbiAgdHdlZXRJZDogc3RyaW5nO1xyXG59IHwgbnVsbD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcclxuICAgIGlmIChpZHMubGVuZ3RoID4gMCkgcmV0dXJuIHsgaGFuZGxlLCB0d2VldElkOiBpZHNbMF0hIH07XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcblxyXG4vLyAtLS0gTWVkaWEtY3Jhd2wgcXVldWUgKHBhcnRpYWwgY2FwdHVyZXMgYXdhaXRpbmcgZGV0YWlsLXBhZ2UgZmV0Y2gpIC0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGxldCB0b3RhbCA9IDA7XHJcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcclxuICByZXR1cm4gdG90YWw7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnF1ZXVlTWVkaWFDcmF3bChoaW50SGFuZGxlOiBzdHJpbmcgfCBudWxsLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgY29uc3QgYnVja2V0ID0gaGludEhhbmRsZSA/PyAnX3Vua25vd24nO1xyXG4gIGNvbnN0IGlkcyA9IHFbYnVja2V0XSA/PyBbXTtcclxuICBpZiAoIWlkcy5pbmNsdWRlcyh0d2VldElkKSkge1xyXG4gICAgaWRzLnB1c2godHdlZXRJZCk7XHJcbiAgICBxW2J1Y2tldF0gPSBpZHM7XHJcbiAgICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIHEpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVNZWRpYUNyYXdsKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcclxuICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xyXG4gIGZvciAoY29uc3QgYnVja2V0IG9mIE9iamVjdC5rZXlzKHEpKSB7XHJcbiAgICBjb25zdCBpZHMgPSBxW2J1Y2tldF07XHJcbiAgICBpZiAoIWlkcykgY29udGludWU7XHJcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XHJcbiAgICBpZiAoZmlsdGVyZWQubGVuZ3RoICE9PSBpZHMubGVuZ3RoKSB7XHJcbiAgICAgIGNoYW5nZWQgPSB0cnVlO1xyXG4gICAgICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtidWNrZXRdO1xyXG4gICAgICBlbHNlIHFbYnVja2V0XSA9IGZpbHRlcmVkO1xyXG4gICAgfVxyXG4gIH1cclxuICBpZiAoY2hhbmdlZCkgYXdhaXQgc2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnLCBxKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRNZWRpYUNyYXdsVGFyZ2V0KCk6IFByb21pc2U8e1xyXG4gIGJ1Y2tldDogc3RyaW5nO1xyXG4gIHR3ZWV0SWQ6IHN0cmluZztcclxufSB8IG51bGw+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XHJcbiAgZm9yIChjb25zdCBbYnVja2V0LCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XHJcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGJ1Y2tldCwgdHdlZXRJZDogaWRzWzBdISB9O1xyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuLy8gLS0tIFRocmVhZC1vcGVuaW5nIHF1ZXVlIChjb3JlIGNvbnZlcnNhdGlvbiByb290cyB0byB2aXNpdCkgLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRocmVhZE9wZW5RdWV1ZSgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3RocmVhZE9wZW5RdWV1ZScpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdGhyZWFkT3BlblF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XHJcbiAgbGV0IHRvdGFsID0gMDtcclxuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xyXG4gIHJldHVybiB0b3RhbDtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhc1RocmVhZE9wZW5TZWVuKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xyXG4gIGNvbnN0IHNlZW4gPSBhd2FpdCBnZXRSYXcoJ3RocmVhZE9wZW5TZWVuJyk7XHJcbiAgcmV0dXJuIHR3ZWV0SWQgaW4gc2VlbjtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1hcmtUaHJlYWRPcGVuU2Vlbih0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBzZWVuID0gYXdhaXQgZ2V0UmF3KCd0aHJlYWRPcGVuU2VlbicpO1xyXG4gIHNlZW5bdHdlZXRJZF0gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XHJcbiAgYXdhaXQgc2V0UmF3KCd0aHJlYWRPcGVuU2VlbicsIHNlZW4pO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVRocmVhZE9wZW4oaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGlmIChhd2FpdCBoYXNUaHJlYWRPcGVuU2Vlbih0d2VldElkKSkgcmV0dXJuO1xyXG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcclxuICBjb25zdCBpZHMgPSBxW2hhbmRsZV0gPz8gW107XHJcbiAgaWYgKCFpZHMuaW5jbHVkZXModHdlZXRJZCkpIHtcclxuICAgIGlkcy5wdXNoKHR3ZWV0SWQpO1xyXG4gICAgcVtoYW5kbGVdID0gaWRzO1xyXG4gICAgYXdhaXQgc2V0UmF3KCd0aHJlYWRPcGVuUXVldWUnLCBxKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXF1ZXVlVGhyZWFkT3Blbih0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XHJcbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcclxuICBmb3IgKGNvbnN0IGJ1Y2tldCBvZiBPYmplY3Qua2V5cyhxKSkge1xyXG4gICAgY29uc3QgaWRzID0gcVtidWNrZXRdO1xyXG4gICAgaWYgKCFpZHMpIGNvbnRpbnVlO1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBpZHMuZmlsdGVyKChpZCkgPT4gaWQgIT09IHR3ZWV0SWQpO1xyXG4gICAgaWYgKGZpbHRlcmVkLmxlbmd0aCAhPT0gaWRzLmxlbmd0aCkge1xyXG4gICAgICBjaGFuZ2VkID0gdHJ1ZTtcclxuICAgICAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbYnVja2V0XTtcclxuICAgICAgZWxzZSBxW2J1Y2tldF0gPSBmaWx0ZXJlZDtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKGNoYW5nZWQpIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblF1ZXVlJywgcSk7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0VGhyZWFkT3BlblRhcmdldCgpOiBQcm9taXNlPHtcclxuICBoYW5kbGU6IHN0cmluZztcclxuICB0d2VldElkOiBzdHJpbmc7XHJcbn0gfCBudWxsPiB7XHJcbiAgY29uc3QgcSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xyXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgaWRzXSBvZiBPYmplY3QuZW50cmllcyhxKSkge1xyXG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBoYW5kbGUsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbi8qKiBIYXMgdGhpcyB0d2VldCBpZCBhbHJlYWR5IGJlZW4gY29tbWl0dGVkIChhbnkgaGFuZGxlKT8gVXNlZCB0byBza2lwXHJcbiAqIGVucXVldWVpbmcgbWVkaWEtY3Jhd2wgdGFyZ2V0cyB3ZSd2ZSBhbHJlYWR5IGFyY2hpdmVkLiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNDb21taXR0ZWQodHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICBmb3IgKGNvbnN0IGlubmVyIG9mIE9iamVjdC52YWx1ZXMoaWR4KSkge1xyXG4gICAgaWYgKGlubmVyICYmIHR3ZWV0SWQgaW4gaW5uZXIpIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICByZXR1cm4gZmFsc2U7XHJcbn1cclxuXHJcbi8vIC0tLSBMb29wIHNlc3Npb24gc3RhdGUgKHByb2dyZXNzICsgaW5mbGlnaHQgZ2F0aW5nKSAtLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFNlc3Npb24nLCBzKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcclxuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJywgcyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRocmVhZE9wZW5TZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XHJcbiAgcmV0dXJuIGdldFJhdygndGhyZWFkT3BlblNlc3Npb24nKTtcclxufVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0VGhyZWFkT3BlblNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgc2V0UmF3KCd0aHJlYWRPcGVuU2Vzc2lvbicsIHMpO1xyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpOiBQcm9taXNlPEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbD4ge1xyXG4gIHJldHVybiBnZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJyk7XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEF1dG9TY3JvbGxTZXNzaW9uKHM6IEF1dG9TY3JvbGxTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IHNldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nLCBzKTtcclxufVxyXG5cclxuLy8gLS0tIFB1cmdlOiB1bnJlbGF0ZWQgYnVmZmVycywgY291bnRlcnMsIHF1ZXVlIGVudHJpZXMgLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuLyoqXHJcbiAqIERyb3AgZXZlcnkgcGVyLWhhbmRsZSBiaXQgb2Ygc3RhdGUgKGNvdW50ZXJzLCBydW4gYnVmZmVyLCBjb21taXR0ZWQtaW5kZXhcclxuICogZW50cmllcywgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHF1ZXVlIGVudHJpZXMpIHRoYXQgZG9lc24ndCBjb3JyZXNwb25kIHRvIGFcclxuICogdHJhY2tlZCBhY2NvdW50LiBSZXR1cm5zIGEgc3VtbWFyeSBkZXNjcmliaW5nIHdoYXQgd2FzIGNsZWFyZWQgc28gdGhlXHJcbiAqIGNhbGxlciBjYW4gbG9nIGl0LlxyXG4gKlxyXG4gKiBUcmFja2VkIGFjY291bnRzIGFyZSBwYXNzZWQgaW4gKGNhbGxlciByZXNvbHZlcyBmcm9tIHRoZSBsaXZlIGNvbmZpZykuXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHVyZ2VVbnJlbGF0ZWRTdGF0ZSh0YXJnZXRlZDogUmVhZG9ubHlTZXQ8c3RyaW5nPik6IFByb21pc2U8e1xyXG4gIGNvdW50ZXJzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIGJ1ZmZlcnNSZW1vdmVkOiBudW1iZXI7XHJcbiAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQ6IG51bWJlcjtcclxuICByZWZldGNoSGFuZGxlc1JlbW92ZWQ6IG51bWJlcjtcclxuICBtZWRpYUNyYXdsSWRzUmVtb3ZlZDogbnVtYmVyO1xyXG4gIHRocmVhZE9wZW5JZHNSZW1vdmVkOiBudW1iZXI7XHJcbn0+IHtcclxuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcclxuICBjb25zdCBpc1RhcmdldGVkID0gKGg6IHN0cmluZyk6IGJvb2xlYW4gPT4gdGFyZ0xvd2VyLmhhcyhoLnRvTG93ZXJDYXNlKCkpO1xyXG5cclxuICAvLyBDb3VudGVyc1xyXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcclxuICBsZXQgY291bnRlcnNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGNvdW50ZXJzW2hdO1xyXG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcclxuXHJcbiAgLy8gUnVuIGJ1ZmZlcnNcclxuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGxldCBidWZmZXJzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGJ1ZmZlcnMpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIGJ1ZmZlcnNbaF07XHJcbiAgICAgIGJ1ZmZlcnNSZW1vdmVkICs9IDE7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGJ1ZmZlcnMpO1xyXG5cclxuICAvLyBDb21taXR0ZWQgZGVkdXAgaW5kZXhcclxuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xyXG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcclxuICAgIGlmICghaXNUYXJnZXRlZChoKSkge1xyXG4gICAgICBkZWxldGUgaWR4W2hdO1xyXG4gICAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBzZXRDb21taXR0ZWRJbmRleChpZHgpO1xyXG5cclxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXHJcbiAgY29uc3QgcnEgPSBhd2FpdCBnZXRSZWZldGNoUXVldWUoKTtcclxuICBsZXQgcmVmZXRjaEhhbmRsZXNSZW1vdmVkID0gMDtcclxuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XHJcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcclxuICAgICAgZGVsZXRlIHJxW2hdO1xyXG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XHJcblxyXG4gIC8vIE1lZGlhLWNyYXdsIHF1ZXVlOiBidWNrZXRzIGFyZSBoaW50LWhhbmRsZXMgKG9yIFwiX3Vua25vd25cIikuIERyb3BcclxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCBcdTIwMTQgaW5jbHVkaW5nIFwiX3Vua25vd25cIiBzaW5jZSB3ZVxyXG4gIC8vIGNhbid0IHZlcmlmeSByZWxhdGlvbi5cclxuICBjb25zdCBtcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xyXG4gIGxldCBtZWRpYUNyYXdsSWRzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKG1xKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xyXG4gICAgICBkZWxldGUgbXFbaF07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgbXEpO1xyXG5cclxuICBjb25zdCB0cSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xyXG4gIGxldCB0aHJlYWRPcGVuSWRzUmVtb3ZlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBoIG9mIE9iamVjdC5rZXlzKHRxKSkge1xyXG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XHJcbiAgICAgIHRocmVhZE9wZW5JZHNSZW1vdmVkICs9ICh0cVtoXSA/PyBbXSkubGVuZ3RoO1xyXG4gICAgICBkZWxldGUgdHFbaF07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblF1ZXVlJywgdHEpO1xyXG5cclxuICByZXR1cm4ge1xyXG4gICAgY291bnRlcnNSZW1vdmVkLFxyXG4gICAgYnVmZmVyc1JlbW92ZWQsXHJcbiAgICBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCxcclxuICAgIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZCxcclxuICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkLFxyXG4gICAgdGhyZWFkT3Blbklkc1JlbW92ZWQsXHJcbiAgfTtcclxufVxyXG5cclxuLy8gLS0tIEZ1bGwgcmVzZXQgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5jbGVhcigpO1xyXG59XHJcbiIsICJpbXBvcnQgeyBhcHBlbmRBY3Rpdml0eSB9IGZyb20gJy4vc3RvcmFnZS5qcyc7XHJcbmltcG9ydCB0eXBlIHsgTG9nRXZlbnQsIExvZ0xldmVsIH0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG5sZXQgYnJvYWRjYXN0OiAoKGV2OiBMb2dFdmVudCkgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBzZXRCcm9hZGNhc3RlcihmbjogKGV2OiBMb2dFdmVudCkgPT4gdm9pZCk6IHZvaWQge1xyXG4gIGJyb2FkY2FzdCA9IGZuO1xyXG59XHJcblxyXG5mdW5jdGlvbiBub3dJU08oKTogc3RyaW5nIHtcclxuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBlbWl0KGxldmVsOiBMb2dMZXZlbCwgbXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgZXY6IExvZ0V2ZW50ID0geyB0czogbm93SVNPKCksIGxldmVsLCBtc2csIGNvbnRleHQ6IHJlZGFjdChjb250ZXh0KSB9O1xyXG4gIC8vIENvbnNvbGUgZm9yIGRldnRvb2xzLlxyXG4gIGNvbnN0IGxpbmUgPSBgW2ltbS1hcmNoaXZlXSAke2xldmVsLnRvVXBwZXJDYXNlKCl9ICR7bXNnfWA7XHJcbiAgaWYgKGxldmVsID09PSAnZXJyb3InKSBjb25zb2xlLmVycm9yKGxpbmUsIGV2LmNvbnRleHQpO1xyXG4gIGVsc2UgaWYgKGxldmVsID09PSAnd2FybicpIGNvbnNvbGUud2FybihsaW5lLCBldi5jb250ZXh0KTtcclxuICBlbHNlIGNvbnNvbGUubG9nKGxpbmUsIGV2LmNvbnRleHQpO1xyXG4gIC8vIFBlcnNpc3RlbnQgdGFpbC5cclxuICB0cnkge1xyXG4gICAgYXdhaXQgYXBwZW5kQWN0aXZpdHkoZXYpO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGZhaWxlZCB0byBhcHBlbmQgYWN0aXZpdHknLCBlcnIpO1xyXG4gIH1cclxuICAvLyBMaXZlIGJyb2FkY2FzdCAoZS5nLiB0byBzaWRlYmFyKS5cclxuICB0cnkge1xyXG4gICAgYnJvYWRjYXN0Py4oZXYpO1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgLy8gU2lkZWJhciBtYXkgbm90IGJlIG9wZW47IHRoYXQncyBmaW5lLlxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGluZm8obXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge30pOiBQcm9taXNlPHZvaWQ+IHtcclxuICByZXR1cm4gZW1pdCgnaW5mbycsIG1zZywgY29udGV4dCk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIHdhcm4obXNnOiBzdHJpbmcsIGNvbnRleHQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge30pOiBQcm9taXNlPHZvaWQ+IHtcclxuICByZXR1cm4gZW1pdCgnd2FybicsIG1zZywgY29udGV4dCk7XHJcbn1cclxuZXhwb3J0IGZ1bmN0aW9uIGVycm9yKG1zZzogc3RyaW5nLCBjb250ZXh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9KTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgcmV0dXJuIGVtaXQoJ2Vycm9yJywgbXNnLCBjb250ZXh0KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGRlc2NyaWJlRXJyb3IoZXJyOiB1bmtub3duKTogeyBtZXNzYWdlOiBzdHJpbmc7IHN0YWNrOiBzdHJpbmcgfCBudWxsIH0ge1xyXG4gIGlmIChlcnIgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgcmV0dXJuIHsgbWVzc2FnZTogZXJyLm1lc3NhZ2UsIHN0YWNrOiBlcnIuc3RhY2sgPz8gbnVsbCB9O1xyXG4gIH1cclxuICB0cnkge1xyXG4gICAgcmV0dXJuIHsgbWVzc2FnZTogU3RyaW5nKGVyciksIHN0YWNrOiBudWxsIH07XHJcbiAgfSBjYXRjaCB7XHJcbiAgICByZXR1cm4geyBtZXNzYWdlOiAnPHVucHJpbnRhYmxlIGVycm9yPicsIHN0YWNrOiBudWxsIH07XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogU3RyaXAgYW55dGhpbmcgdGhhdCBsb29rcyBsaWtlIGEgUEFUIG9yIG90aGVyIGxvbmcgc2VjcmV0IGZyb20gYSBjb250ZXh0XHJcbiAqIG9iamVjdCBiZWZvcmUgcGVyc2lzdGluZyBpdC4gRGVmZW5zaXZlOiBjYWxsZXJzIHNob3VsZCBub3QgbG9nIHRva2VucywgYnV0XHJcbiAqIGlmIHRoZXkgc2xpcCB0aHJvdWdoIHdlIHdhbnQgdG8gcmVkYWN0IHRoZW0uXHJcbiAqL1xyXG5mdW5jdGlvbiByZWRhY3QoY3R4OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcclxuICBjb25zdCBvdXQ6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XHJcbiAgZm9yIChjb25zdCBbaywgdl0gb2YgT2JqZWN0LmVudHJpZXMoY3R4KSkge1xyXG4gICAgaWYgKGsudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygndG9rZW4nKSB8fCBrLnRvTG93ZXJDYXNlKCkgPT09ICdwYXQnIHx8IGsgPT09ICdhdXRob3JpemF0aW9uJykge1xyXG4gICAgICBvdXRba10gPSAnPHJlZGFjdGVkPic7XHJcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiAvZ2l0aHViX3BhdF9bQS1aYS16MC05X117MzAsfS8udGVzdCh2KSkge1xyXG4gICAgICBvdXRba10gPSB2LnJlcGxhY2UoL2dpdGh1Yl9wYXRfW0EtWmEtejAtOV9dKy9nLCAnZ2l0aHViX3BhdF88cmVkYWN0ZWQ+Jyk7XHJcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJyAmJiB2Lmxlbmd0aCA+IDQwOTYpIHtcclxuICAgICAgb3V0W2tdID0gYCR7di5zbGljZSgwLCA0MDk2KX1cdTIwMjY8dHJ1bmNhdGVkPmA7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBvdXRba10gPSB2O1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gb3V0O1xyXG59XHJcbiIsICJpbXBvcnQgeyBkZXNjcmliZUVycm9yIH0gZnJvbSAnLi9sb2dnZXIuanMnO1xyXG5pbXBvcnQgdHlwZSB7IFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XHJcblxyXG5jb25zdCBBUElfQkFTRSA9ICdodHRwczovL2FwaS5naXRodWIuY29tJztcclxuY29uc3QgUkFXX0JBU0UgPSAnaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tJztcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgUHV0RmlsZU9wdGlvbnMge1xyXG4gIHBhdGg6IHN0cmluZztcclxuICBjb250ZW50QmFzZTY0OiBzdHJpbmc7XHJcbiAgbWVzc2FnZTogc3RyaW5nO1xyXG4gIGV4cGVjdGVkU2hhPzogc3RyaW5nIHwgbnVsbDtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBQdXRGaWxlUmVzdWx0IHtcclxuICBwYXRoOiBzdHJpbmc7XHJcbiAgc2hhOiBzdHJpbmc7XHJcbiAgdXJsOiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZU9wdGlvbnMge1xyXG4gIHBhdGg6IHN0cmluZztcclxuICBjb250ZW50QmFzZTY0OiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZXNPcHRpb25zIHtcclxuICBmaWxlczogQ29tbWl0RmlsZU9wdGlvbnNbXTtcclxuICBtZXNzYWdlOiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWl0RmlsZXNSZXN1bHQge1xyXG4gIGNvbW1pdFNoYTogc3RyaW5nO1xyXG4gIHVybDogc3RyaW5nO1xyXG4gIGZpbGVzOiBzdHJpbmdbXTtcclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEdpdEh1YkVycm9yIGV4dGVuZHMgRXJyb3Ige1xyXG4gIHN0YXR1czogbnVtYmVyO1xyXG4gIGJvZHk6IHVua25vd247XHJcbiAgcmV0cmlhYmxlOiBib29sZWFuO1xyXG4gIGNhdGVnb3J5OiAnYXV0aCcgfCAncmF0ZS1saW1pdCcgfCAnY29uZmxpY3QnIHwgJ25vdC1mb3VuZCcgfCAnc2VydmVyJyB8ICduZXR3b3JrJyB8ICd1bmtub3duJztcclxuICAvKiogV2hlbiB0aGUgR2l0SHViIHJhdGUtbGltaXQgd2luZG93IGZvciB0aGlzIHRva2VuIHJlc2V0cywgYXMgYSBVbml4XHJcbiAgICogZXBvY2ggaW4gc2Vjb25kcy4gUG9wdWxhdGVkIGZyb20gYFgtUmF0ZUxpbWl0LVJlc2V0YCBvbiA0MDMvNDI5LCBvclxyXG4gICAqIGRlcml2ZWQgZnJvbSBgUmV0cnktQWZ0ZXJgIGZvciBzZWNvbmRhcnkgbGltaXRzLiBudWxsIHdoZW4gdW5rbm93bi4gKi9cclxuICByYXRlTGltaXRSZXNldEF0OiBudW1iZXIgfCBudWxsO1xyXG5cclxuICBjb25zdHJ1Y3RvcihvcHRzOiB7XHJcbiAgICBzdGF0dXM6IG51bWJlcjtcclxuICAgIGJvZHk6IHVua25vd247XHJcbiAgICBtZXNzYWdlOiBzdHJpbmc7XHJcbiAgICByZXRyaWFibGU6IGJvb2xlYW47XHJcbiAgICBjYXRlZ29yeTogR2l0SHViRXJyb3JbJ2NhdGVnb3J5J107XHJcbiAgICByYXRlTGltaXRSZXNldEF0PzogbnVtYmVyIHwgbnVsbDtcclxuICB9KSB7XHJcbiAgICBzdXBlcihvcHRzLm1lc3NhZ2UpO1xyXG4gICAgdGhpcy5uYW1lID0gJ0dpdEh1YkVycm9yJztcclxuICAgIHRoaXMuc3RhdHVzID0gb3B0cy5zdGF0dXM7XHJcbiAgICB0aGlzLmJvZHkgPSBvcHRzLmJvZHk7XHJcbiAgICB0aGlzLnJldHJpYWJsZSA9IG9wdHMucmV0cmlhYmxlO1xyXG4gICAgdGhpcy5jYXRlZ29yeSA9IG9wdHMuY2F0ZWdvcnk7XHJcbiAgICB0aGlzLnJhdGVMaW1pdFJlc2V0QXQgPSBvcHRzLnJhdGVMaW1pdFJlc2V0QXQgPz8gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBHaXRIdWJDbGllbnQge1xyXG4gIHByaXZhdGUgcmVhZG9ubHkgc2V0dGluZ3M6IFNldHRpbmdzO1xyXG5cclxuICBjb25zdHJ1Y3RvcihzZXR0aW5nczogU2V0dGluZ3MpIHtcclxuICAgIHRoaXMuc2V0dGluZ3MgPSBzZXR0aW5ncztcclxuICB9XHJcblxyXG4gIC8qKiBSZXR1cm5zIHRoZSBhdXRoZW50aWNhdGVkIHVzZXIncyBsb2dpbi4gVGhyb3dzIG9uIGF1dGggZmFpbHVyZS4gKi9cclxuICBhc3luYyB3aG9hbWkoKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdHRVQnLCAnL3VzZXInKTtcclxuICAgIHJldHVybiAocmVzIGFzIHsgbG9naW4/OiBzdHJpbmcgfSkubG9naW4gPz8gJzx1bmtub3duPic7XHJcbiAgfVxyXG5cclxuICAvKiogUmV0dXJucyB0cnVlIGlmIHRoZSBnaXZlbiBicmFuY2ggZXhpc3RzIG9uIHRoZSBjb25maWd1cmVkIHJlcG8uICovXHJcbiAgYXN5bmMgYnJhbmNoRXhpc3RzKGJyYW5jaDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCB0aGlzLmZldGNoSnNvbihcclxuICAgICAgICAnR0VUJyxcclxuICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2JyYW5jaGVzLyR7ZW5jb2RlVVJJQ29tcG9uZW50KGJyYW5jaCl9YFxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBpZiAoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IgJiYgZXJyLmNhdGVnb3J5ID09PSAnbm90LWZvdW5kJykgcmV0dXJuIGZhbHNlO1xyXG4gICAgICB0aHJvdyBlcnI7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKiogVmVyaWZpZXMgdGhlIFBBVCBjYW4gc2VlIHRoZSBjb25maWd1cmVkIHJlcG8uICovXHJcbiAgYXN5bmMgdmVyaWZ5UmVwb0FjY2VzcygpOiBQcm9taXNlPHsgbG9naW46IHN0cmluZzsgZnVsbF9uYW1lOiBzdHJpbmc7IGRlZmF1bHRfYnJhbmNoOiBzdHJpbmcgfT4ge1xyXG4gICAgY29uc3QgbWUgPSBhd2FpdCB0aGlzLmZldGNoSnNvbignR0VUJywgJy91c2VyJyk7XHJcbiAgICBjb25zdCByZXBvID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oJ0dFVCcsIGAvcmVwb3MvJHt0aGlzLnNldHRpbmdzLm93bmVyfS8ke3RoaXMuc2V0dGluZ3MucmVwb31gKTtcclxuICAgIGNvbnN0IHIgPSByZXBvIGFzIHsgZnVsbF9uYW1lOiBzdHJpbmc7IGRlZmF1bHRfYnJhbmNoOiBzdHJpbmcgfTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIGxvZ2luOiAobWUgYXMgeyBsb2dpbjogc3RyaW5nIH0pLmxvZ2luLFxyXG4gICAgICBmdWxsX25hbWU6IHIuZnVsbF9uYW1lLFxyXG4gICAgICBkZWZhdWx0X2JyYW5jaDogci5kZWZhdWx0X2JyYW5jaCxcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBWZXJpZnkgdGhlIFBBVCBjYW4gd3JpdGUgdG8gdGhlIGNvbmZpZ3VyZWQgYnJhbmNoIHdpdGhvdXQgY3JlYXRpbmcgYVxyXG4gICAqIGNvbW1pdC4gTW92aW5nIGEgcmVmIHRvIGl0cyBjdXJyZW50IFNIQSBpcyBhIG5vLW9wLCBidXQgR2l0SHViIHN0aWxsXHJcbiAgICogZW5mb3JjZXMgdGhlIENvbnRlbnRzOiBXcml0ZSBwZXJtaXNzaW9uIHJlcXVpcmVkIGJ5IGNvbW1pdEZpbGVzKCkuXHJcbiAgICovXHJcbiAgYXN5bmMgdmVyaWZ5V3JpdGVBY2Nlc3MoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XHJcbiAgICBhd2FpdCB0aGlzLmZldGNoSnNvbihcclxuICAgICAgJ1BBVENIJyxcclxuICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvcmVmcy9oZWFkcy8ke2VuY29kZVBhdGgodGhpcy5zZXR0aW5ncy5icmFuY2gpfWAsXHJcbiAgICAgIHtcclxuICAgICAgICBzaGE6IGhlYWQuc2hhLFxyXG4gICAgICAgIGZvcmNlOiBmYWxzZSxcclxuICAgICAgfVxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIEZldGNoIGEgdGV4dCBmaWxlIGZyb20gcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSBhdXRoZW50aWNhdGVkIHdpdGggdGhlXHJcbiAgICogUEFULiBSZXR1cm5zIG51bGwgaWYgdGhlIGZpbGUgZG9lc24ndCBleGlzdC4gVXNlZCBmb3IgY29uZmlnL2FjY291bnRzLnlhbWwuXHJcbiAgICovXHJcbiAgYXN5bmMgZmV0Y2hSYXdUZXh0KHBhdGhJblJlcG86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xyXG4gICAgY29uc3QgdXJsID0gYCR7UkFXX0JBU0V9LyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99LyR7dGhpcy5zZXR0aW5ncy5icmFuY2h9LyR7cGF0aEluUmVwb31gO1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsLCB7XHJcbiAgICAgIG1ldGhvZDogJ0dFVCcsXHJcbiAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3RoaXMuc2V0dGluZ3MucGF0fWAgfSxcclxuICAgIH0pO1xyXG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwNCkgcmV0dXJuIG51bGw7XHJcbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgYXdhaXQgdGhpcy5tYWtlRXJyb3IocmVzLCBgR0VUIHJhdyAke3BhdGhJblJlcG99YCk7XHJcbiAgICByZXR1cm4gcmVzLnRleHQoKTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIExvb2sgdXAgYW4gZXhpc3RpbmcgZmlsZSdzIFNIQSB2aWEgdGhlIENvbnRlbnRzIEFQSSwgb3IgbnVsbCBpZiBub3QgZm91bmQuXHJcbiAgICogVXNlZCB3aGVuIHJldHJ5aW5nIGEgUFVUIGFmdGVyIGEgNDIyIHNoYSBtaXNtYXRjaC5cclxuICAgKi9cclxuICBhc3luYyBnZXRGaWxlU2hhKHBhdGg6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXHJcbiAgICAgICAgJ0dFVCcsXHJcbiAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9P3JlZj0ke2VuY29kZVVSSUNvbXBvbmVudCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCByID0gcmVzIGFzIHsgc2hhPzogc3RyaW5nIH07XHJcbiAgICAgIHJldHVybiByLnNoYSA/PyBudWxsO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdub3QtZm91bmQnKSByZXR1cm4gbnVsbDtcclxuICAgICAgdGhyb3cgZXJyO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogUFVUIGEgZmlsZSB0byB0aGUgcmVwby4gSGFuZGxlcyA0MjIgKHNoYSByZXF1aXJlZCkgYnkgcmUtZmV0Y2hpbmcgdGhlXHJcbiAgICogZXhpc3Rpbmcgc2hhIGFuZCByZXRyeWluZyBvbmNlLiBSZXRyaWVzIG5ldHdvcmsgLyA1eHggLyByYXRlLWxpbWl0IGVycm9yc1xyXG4gICAqIHdpdGggZXhwb25lbnRpYWwgYmFja29mZiB1cCB0byBtYXhBdHRlbXB0cy5cclxuICAgKi9cclxuICBhc3luYyBwdXRGaWxlKG9wdHM6IFB1dEZpbGVPcHRpb25zKTogUHJvbWlzZTxQdXRGaWxlUmVzdWx0PiB7XHJcbiAgICBjb25zdCBwYXRoID0gb3B0cy5wYXRoO1xyXG4gICAgY29uc3QgdXJsID0gYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9jb250ZW50cy8ke2VuY29kZVBhdGgocGF0aCl9YDtcclxuICAgIGxldCBzaGE6IHN0cmluZyB8IG51bGwgPSBvcHRzLmV4cGVjdGVkU2hhID8/IG51bGw7XHJcbiAgICBjb25zdCBtYXhBdHRlbXB0cyA9IDU7XHJcblxyXG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDE7IGF0dGVtcHQgPD0gbWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xyXG4gICAgICBjb25zdCBib2R5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHtcclxuICAgICAgICBtZXNzYWdlOiBvcHRzLm1lc3NhZ2UsXHJcbiAgICAgICAgY29udGVudDogb3B0cy5jb250ZW50QmFzZTY0LFxyXG4gICAgICAgIGJyYW5jaDogdGhpcy5zZXR0aW5ncy5icmFuY2gsXHJcbiAgICAgIH07XHJcbiAgICAgIGlmIChzaGEpIGJvZHkuc2hhID0gc2hhO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKCdQVVQnLCB1cmwsIGJvZHkpO1xyXG4gICAgICAgIGNvbnN0IG91dCA9IHJlcyBhcyB7IGNvbnRlbnQ6IHsgc2hhOiBzdHJpbmc7IGh0bWxfdXJsOiBzdHJpbmc7IHBhdGg6IHN0cmluZyB9IH07XHJcbiAgICAgICAgcmV0dXJuIHsgcGF0aDogb3V0LmNvbnRlbnQucGF0aCwgc2hhOiBvdXQuY29udGVudC5zaGEsIHVybDogb3V0LmNvbnRlbnQuaHRtbF91cmwgfTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgaWYgKCEoZXJyIGluc3RhbmNlb2YgR2l0SHViRXJyb3IpKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgaWYgKGVyci5zdGF0dXMgPT09IDQyMiAmJiAhc2hhKSB7XHJcbiAgICAgICAgICAvLyBGaWxlIGFscmVhZHkgZXhpc3RzOyBmZXRjaCBpdHMgc2hhIGFuZCByZXRyeSBvbmNlLlxyXG4gICAgICAgICAgc2hhID0gYXdhaXQgdGhpcy5nZXRGaWxlU2hhKHBhdGgpO1xyXG4gICAgICAgICAgaWYgKCFzaGEpIHRocm93IGVycjtcclxuICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIWVyci5yZXRyaWFibGUgfHwgYXR0ZW1wdCA9PT0gbWF4QXR0ZW1wdHMpIHRocm93IGVycjtcclxuICAgICAgICBhd2FpdCBzbGVlcChiYWNrb2ZmTXMoYXR0ZW1wdCwgZXJyKSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHRocm93IG5ldyBFcnJvcihgcHV0RmlsZTogZXhoYXVzdGVkIGF0dGVtcHRzIGZvciAke3BhdGh9YCk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBDb21taXQgc2V2ZXJhbCBmaWxlcyB3aXRoIG9uZSBicmFuY2ggdXBkYXRlLiBUaGUgQ29udGVudHMgQVBJIGNyZWF0ZXMgb25lXHJcbiAgICogY29tbWl0IHBlciBQVVQsIHNvIHJhcGlkIGZsdXNoZXMgcmFjZSBlYWNoIG90aGVyIG9uIHRoZSBicmFuY2ggaGVhZC4gVGhpc1xyXG4gICAqIHVzZXMgdGhlIGxvd2VyLWxldmVsIEdpdCBEYXRhIEFQSSBpbnN0ZWFkOiB1cGxvYWQgYmxvYnMsIGJ1aWxkIGEgdHJlZSxcclxuICAgKiBjcmVhdGUgb25lIGNvbW1pdCwgdGhlbiBtb3ZlIHRoZSBicmFuY2ggcmVmIG9uY2UuIElmIGFub3RoZXIgd3JpdGVyIG1vdmVzXHJcbiAgICogdGhlIGJyYW5jaCBmaXJzdCwgcmViYXNlIHRoaXMgdHJlZSBwYXRjaCBvbnRvIHRoZSBsYXRlc3QgaGVhZCBhbmQgcmV0cnkuXHJcbiAgICovXHJcbiAgYXN5bmMgY29tbWl0RmlsZXMob3B0czogQ29tbWl0RmlsZXNPcHRpb25zKTogUHJvbWlzZTxDb21taXRGaWxlc1Jlc3VsdD4ge1xyXG4gICAgaWYgKG9wdHMuZmlsZXMubGVuZ3RoID09PSAwKSB0aHJvdyBuZXcgRXJyb3IoJ2NvbW1pdEZpbGVzOiBubyBmaWxlcyB0byBjb21taXQnKTtcclxuICAgIGNvbnN0IG1heEF0dGVtcHRzID0gNTtcclxuICAgIGxldCBsYXN0RXJyOiB1bmtub3duID0gbnVsbDtcclxuXHJcbiAgICBmb3IgKGxldCBhdHRlbXB0ID0gMTsgYXR0ZW1wdCA8PSBtYXhBdHRlbXB0czsgYXR0ZW1wdCsrKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgYmxvYnMgPSBhd2FpdCBQcm9taXNlLmFsbChcclxuICAgICAgICAgIG9wdHMuZmlsZXMubWFwKGFzeW5jIChmaWxlKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IG91dCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICAgICAgICdQT1NUJyxcclxuICAgICAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9ibG9ic2AsXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgY29udGVudDogZmlsZS5jb250ZW50QmFzZTY0LFxyXG4gICAgICAgICAgICAgICAgZW5jb2Rpbmc6ICdiYXNlNjQnLFxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICBwYXRoOiBmaWxlLnBhdGgsXHJcbiAgICAgICAgICAgICAgc2hhOiAob3V0IGFzIHsgc2hhOiBzdHJpbmcgfSkuc2hhLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfSlcclxuICAgICAgICApO1xyXG5cclxuICAgICAgICBjb25zdCBoZWFkID0gYXdhaXQgdGhpcy5nZXRCcmFuY2hIZWFkKCk7XHJcbiAgICAgICAgY29uc3QgdHJlZSA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICAgJ1BPU1QnLFxyXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvdHJlZXNgLFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBiYXNlX3RyZWU6IGhlYWQudHJlZVNoYSxcclxuICAgICAgICAgICAgdHJlZTogYmxvYnMubWFwKChibG9iKSA9PiAoe1xyXG4gICAgICAgICAgICAgIHBhdGg6IGJsb2IucGF0aCxcclxuICAgICAgICAgICAgICBtb2RlOiAnMTAwNjQ0JyxcclxuICAgICAgICAgICAgICB0eXBlOiAnYmxvYicsXHJcbiAgICAgICAgICAgICAgc2hhOiBibG9iLnNoYSxcclxuICAgICAgICAgICAgfSkpLFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICAgICAgY29uc3QgdHJlZVNoYSA9ICh0cmVlIGFzIHsgc2hhOiBzdHJpbmcgfSkuc2hhO1xyXG4gICAgICAgIGNvbnN0IGNvbW1pdCA9IGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICAgJ1BPU1QnLFxyXG4gICAgICAgICAgYC9yZXBvcy8ke3RoaXMuc2V0dGluZ3Mub3duZXJ9LyR7dGhpcy5zZXR0aW5ncy5yZXBvfS9naXQvY29tbWl0c2AsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IG9wdHMubWVzc2FnZSxcclxuICAgICAgICAgICAgdHJlZTogdHJlZVNoYSxcclxuICAgICAgICAgICAgcGFyZW50czogW2hlYWQuc2hhXSxcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IGNvbW1pdE91dCA9IGNvbW1pdCBhcyB7IHNoYTogc3RyaW5nOyBodG1sX3VybDogc3RyaW5nIH07XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IHRoaXMuZmV0Y2hKc29uKFxyXG4gICAgICAgICAgICAnUEFUQ0gnLFxyXG4gICAgICAgICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9yZWZzL2hlYWRzLyR7ZW5jb2RlUGF0aCh0aGlzLnNldHRpbmdzLmJyYW5jaCl9YCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIHNoYTogY29tbWl0T3V0LnNoYSxcclxuICAgICAgICAgICAgICBmb3JjZTogZmFsc2UsXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICBpZiAoaXNDb25mbGljdChlcnIpICYmIGF0dGVtcHQgPCBtYXhBdHRlbXB0cykge1xyXG4gICAgICAgICAgICBsYXN0RXJyID0gZXJyO1xyXG4gICAgICAgICAgICBhd2FpdCBzbGVlcChiYWNrb2ZmTXMoYXR0ZW1wdCwgZXJyKSk7XHJcbiAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgdGhyb3cgZXJyO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgY29tbWl0U2hhOiBjb21taXRPdXQuc2hhLFxyXG4gICAgICAgICAgdXJsOiBjb21taXRPdXQuaHRtbF91cmwsXHJcbiAgICAgICAgICBmaWxlczogb3B0cy5maWxlcy5tYXAoKGZpbGUpID0+IGZpbGUucGF0aCksXHJcbiAgICAgICAgfTtcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgbGFzdEVyciA9IGVycjtcclxuICAgICAgICBpZiAoIShlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvcikpIHRocm93IGVycjtcclxuICAgICAgICBpZiAoKCFlcnIucmV0cmlhYmxlICYmICFpc0NvbmZsaWN0KGVycikpIHx8IGF0dGVtcHQgPT09IG1heEF0dGVtcHRzKSB0aHJvdyBlcnI7XHJcbiAgICAgICAgYXdhaXQgc2xlZXAoYmFja29mZk1zKGF0dGVtcHQsIGVycikpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB0aHJvdyBsYXN0RXJyIGluc3RhbmNlb2YgRXJyb3IgPyBsYXN0RXJyIDogbmV3IEVycm9yKCdjb21taXRGaWxlczogZXhoYXVzdGVkIGF0dGVtcHRzJyk7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGFzeW5jIGdldEJyYW5jaEhlYWQoKTogUHJvbWlzZTx7IHNoYTogc3RyaW5nOyB0cmVlU2hhOiBzdHJpbmcgfT4ge1xyXG4gICAgY29uc3QgcmVmID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXHJcbiAgICAgICdHRVQnLFxyXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9yZWYvaGVhZHMvJHtlbmNvZGVQYXRoKHRoaXMuc2V0dGluZ3MuYnJhbmNoKX1gXHJcbiAgICApO1xyXG4gICAgY29uc3QgaGVhZFNoYSA9IChyZWYgYXMgeyBvYmplY3Q6IHsgc2hhOiBzdHJpbmcgfSB9KS5vYmplY3Quc2hhO1xyXG4gICAgY29uc3QgY29tbWl0ID0gYXdhaXQgdGhpcy5mZXRjaEpzb24oXHJcbiAgICAgICdHRVQnLFxyXG4gICAgICBgL3JlcG9zLyR7dGhpcy5zZXR0aW5ncy5vd25lcn0vJHt0aGlzLnNldHRpbmdzLnJlcG99L2dpdC9jb21taXRzLyR7aGVhZFNoYX1gXHJcbiAgICApO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc2hhOiBoZWFkU2hhLFxyXG4gICAgICB0cmVlU2hhOiAoY29tbWl0IGFzIHsgdHJlZTogeyBzaGE6IHN0cmluZyB9IH0pLnRyZWUuc2hhLFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgYXN5bmMgZmV0Y2hKc29uKG1ldGhvZDogc3RyaW5nLCBwYXRoOiBzdHJpbmcsIGJvZHk/OiB1bmtub3duKTogUHJvbWlzZTx1bmtub3duPiB7XHJcbiAgICBjb25zdCB1cmwgPSBwYXRoLnN0YXJ0c1dpdGgoJ2h0dHAnKSA/IHBhdGggOiBgJHtBUElfQkFTRX0ke3BhdGh9YDtcclxuICAgIGNvbnN0IGluaXQ6IFJlcXVlc3RJbml0ID0ge1xyXG4gICAgICBtZXRob2QsXHJcbiAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dGhpcy5zZXR0aW5ncy5wYXR9YCxcclxuICAgICAgICBBY2NlcHQ6ICdhcHBsaWNhdGlvbi92bmQuZ2l0aHViK2pzb24nLFxyXG4gICAgICAgICdYLUdpdEh1Yi1BcGktVmVyc2lvbic6ICcyMDIyLTExLTI4JyxcclxuICAgICAgICAuLi4oYm9keSA/IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9IDoge30pLFxyXG4gICAgICB9LFxyXG4gICAgICAuLi4oYm9keSA/IHsgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSkgfSA6IHt9KSxcclxuICAgIH07XHJcbiAgICBsZXQgcmVzOiBSZXNwb25zZTtcclxuICAgIHRyeSB7XHJcbiAgICAgIHJlcyA9IGF3YWl0IGZldGNoKHVybCwgaW5pdCk7XHJcbiAgICB9IGNhdGNoIChuZXRFcnIpIHtcclxuICAgICAgdGhyb3cgbmV3IEdpdEh1YkVycm9yKHtcclxuICAgICAgICBzdGF0dXM6IDAsXHJcbiAgICAgICAgYm9keTogbnVsbCxcclxuICAgICAgICBtZXNzYWdlOiBgbmV0d29yazogJHtkZXNjcmliZUVycm9yKG5ldEVycikubWVzc2FnZX1gLFxyXG4gICAgICAgIHJldHJpYWJsZTogdHJ1ZSxcclxuICAgICAgICBjYXRlZ29yeTogJ25ldHdvcmsnLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICAgIGlmIChyZXMuc3RhdHVzID09PSAyMDQpIHJldHVybiBudWxsO1xyXG4gICAgbGV0IHBhcnNlZDogdW5rbm93biA9IG51bGw7XHJcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzLnRleHQoKTtcclxuICAgIGlmICh0ZXh0KSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZSh0ZXh0KTtcclxuICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgcGFyc2VkID0gdGV4dDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKCFyZXMub2spIHRocm93IGF3YWl0IHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgYCR7bWV0aG9kfSAke3BhdGh9YCk7XHJcbiAgICByZXR1cm4gcGFyc2VkO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhc3luYyBtYWtlRXJyb3IocmVzOiBSZXNwb25zZSwgbGFiZWw6IHN0cmluZyk6IFByb21pc2U8R2l0SHViRXJyb3I+IHtcclxuICAgIGxldCBwYXJzZWQ6IHVua25vd24gPSBudWxsO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XHJcbiAgICAgIGlmICh0ZXh0KSBwYXJzZWQgPSBKU09OLnBhcnNlKHRleHQpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIGlnbm9yZVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMubWFrZUVycm9yRnJvbVBhcnNlZChyZXMsIHBhcnNlZCwgbGFiZWwpO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBtYWtlRXJyb3JGcm9tUGFyc2VkKHJlczogUmVzcG9uc2UsIGJvZHk6IHVua25vd24sIGxhYmVsOiBzdHJpbmcpOiBHaXRIdWJFcnJvciB7XHJcbiAgICBjb25zdCBtc2cgPVxyXG4gICAgICB0eXBlb2YgYm9keSA9PT0gJ29iamVjdCcgJiYgYm9keSAmJiAnbWVzc2FnZScgaW4gYm9keVxyXG4gICAgICAgID8gU3RyaW5nKChib2R5IGFzIHsgbWVzc2FnZTogdW5rbm93biB9KS5tZXNzYWdlKVxyXG4gICAgICAgIDogcmVzLnN0YXR1c1RleHQ7XHJcbiAgICBsZXQgY2F0ZWdvcnk6IEdpdEh1YkVycm9yWydjYXRlZ29yeSddID0gJ3Vua25vd24nO1xyXG4gICAgbGV0IHJldHJpYWJsZSA9IGZhbHNlO1xyXG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSB8fCByZXMuc3RhdHVzID09PSA0MDMpIHtcclxuICAgICAgLy8gNDAzIGNhbiBiZSBlaXRoZXIgYXV0aCBvciByYXRlIGxpbWl0OyBjaGVjayBoZWFkZXJzLlxyXG4gICAgICBjb25zdCByYXRlID0gcmVzLmhlYWRlcnMuZ2V0KCd4LXJhdGVsaW1pdC1yZW1haW5pbmcnKTtcclxuICAgICAgaWYgKHJhdGUgPT09ICcwJyB8fCAvcmF0ZSBsaW1pdC9pLnRlc3QobXNnKSkge1xyXG4gICAgICAgIGNhdGVnb3J5ID0gJ3JhdGUtbGltaXQnO1xyXG4gICAgICAgIHJldHJpYWJsZSA9IHRydWU7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY2F0ZWdvcnkgPSAnYXV0aCc7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSBpZiAocmVzLnN0YXR1cyA9PT0gNDA0KSB7XHJcbiAgICAgIGNhdGVnb3J5ID0gJ25vdC1mb3VuZCc7XHJcbiAgICB9IGVsc2UgaWYgKHJlcy5zdGF0dXMgPT09IDQwOSB8fCByZXMuc3RhdHVzID09PSA0MjIpIHtcclxuICAgICAgY2F0ZWdvcnkgPSAnY29uZmxpY3QnO1xyXG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID49IDUwMCkge1xyXG4gICAgICBjYXRlZ29yeSA9ICdzZXJ2ZXInO1xyXG4gICAgICByZXRyaWFibGUgPSB0cnVlO1xyXG4gICAgfSBlbHNlIGlmIChyZXMuc3RhdHVzID09PSA0MjkpIHtcclxuICAgICAgY2F0ZWdvcnkgPSAncmF0ZS1saW1pdCc7XHJcbiAgICAgIHJldHJpYWJsZSA9IHRydWU7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gbmV3IEdpdEh1YkVycm9yKHtcclxuICAgICAgc3RhdHVzOiByZXMuc3RhdHVzLFxyXG4gICAgICBib2R5LFxyXG4gICAgICBtZXNzYWdlOiBgJHtsYWJlbH0gXHUyMTkyICR7cmVzLnN0YXR1c306ICR7bXNnfWAsXHJcbiAgICAgIHJldHJpYWJsZSxcclxuICAgICAgY2F0ZWdvcnksXHJcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGNhdGVnb3J5ID09PSAncmF0ZS1saW1pdCcgPyBwYXJzZVJhdGVMaW1pdFJlc2V0KHJlcy5oZWFkZXJzKSA6IG51bGwsXHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBCZXN0LWVmZm9ydCBwYXJzZSBvZiB3aGVuIHRoZSBjdXJyZW50IHJhdGUtbGltaXQgd2luZG93IGVuZHMuIEdpdEh1YidzXHJcbiAqIHByaW1hcnkgbGltaXQgcmVwb3J0cyBgWC1SYXRlTGltaXQtUmVzZXRgIGFzIGEgVW5peCBlcG9jaCBpbiBzZWNvbmRzLlxyXG4gKiBTZWNvbmRhcnkgLyBhYnVzZSBsaW1pdHMgdXNlIGBSZXRyeS1BZnRlcmAsIHdoaWNoIGlzIGVpdGhlciBhbiBIVFRQLWRhdGVcclxuICogb3IgYSBkZWx0YSBpbiBzZWNvbmRzIFx1MjAxNCB3ZSBub3JtYWxpemUgYm90aCB0byBlcG9jaCBzZWNvbmRzLlxyXG4gKi9cclxuZnVuY3Rpb24gcGFyc2VSYXRlTGltaXRSZXNldChoZWFkZXJzOiBIZWFkZXJzKTogbnVtYmVyIHwgbnVsbCB7XHJcbiAgY29uc3QgcmVzZXQgPSBoZWFkZXJzLmdldCgneC1yYXRlbGltaXQtcmVzZXQnKTtcclxuICBpZiAocmVzZXQpIHtcclxuICAgIGNvbnN0IG4gPSBOdW1iZXIucGFyc2VJbnQocmVzZXQsIDEwKTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobikgJiYgbiA+IDApIHJldHVybiBuO1xyXG4gIH1cclxuICBjb25zdCByZXRyeUFmdGVyID0gaGVhZGVycy5nZXQoJ3JldHJ5LWFmdGVyJyk7XHJcbiAgaWYgKHJldHJ5QWZ0ZXIpIHtcclxuICAgIGNvbnN0IGRlbHRhID0gTnVtYmVyLnBhcnNlSW50KHJldHJ5QWZ0ZXIsIDEwKTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoZGVsdGEpICYmIGRlbHRhID49IDApIHtcclxuICAgICAgcmV0dXJuIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApICsgZGVsdGE7XHJcbiAgICB9XHJcbiAgICBjb25zdCBhc0RhdGUgPSBEYXRlLnBhcnNlKHJldHJ5QWZ0ZXIpO1xyXG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShhc0RhdGUpKSByZXR1cm4gTWF0aC5mbG9vcihhc0RhdGUgLyAxMDAwKTtcclxuICB9XHJcbiAgcmV0dXJuIG51bGw7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGVuY29kZVBhdGgocGF0aDogc3RyaW5nKTogc3RyaW5nIHtcclxuICAvLyBFbmNvZGUgc2VnbWVudHMgaW5kaXZpZHVhbGx5IHNvIHNsYXNoZXMgcmVtYWluLlxyXG4gIHJldHVybiBwYXRoLnNwbGl0KCcvJykubWFwKGVuY29kZVVSSUNvbXBvbmVudCkuam9pbignLycpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBiYWNrb2ZmTXMoYXR0ZW1wdDogbnVtYmVyLCBlcnI6IEdpdEh1YkVycm9yKTogbnVtYmVyIHtcclxuICAvLyBFeHBvbmVudGlhbCB3aXRoIGppdHRlcjsgYnVtcCBoaWdoZXIgZm9yIHJhdGUtbGltaXQgcmVzcG9uc2VzLlxyXG4gIGNvbnN0IGJhc2UgPSBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IDUwMDAgOiA1MDA7XHJcbiAgY29uc3Qgaml0dGVyID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogNDAwKTtcclxuICByZXR1cm4gTWF0aC5taW4oNjBfMDAwLCBiYXNlICogMiAqKiAoYXR0ZW1wdCAtIDEpICsgaml0dGVyKTtcclxufVxyXG5cclxuZnVuY3Rpb24gaXNDb25mbGljdChlcnI6IHVua25vd24pOiBlcnIgaXMgR2l0SHViRXJyb3Ige1xyXG4gIHJldHVybiBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciAmJiBlcnIuY2F0ZWdvcnkgPT09ICdjb25mbGljdCc7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNsZWVwKG1zOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIC8vIGJ5dGVzIGlzIGEgVVRGLTggc3RyaW5nIG9mIEpTT047IGVuY29kZSB0byBiYXNlNjQgdGhlIHNhZmUgd2F5LlxyXG4gIGNvbnN0IHV0ZjggPSBuZXcgVGV4dEVuY29kZXIoKS5lbmNvZGUoYnl0ZXMpO1xyXG4gIGxldCBiaW4gPSAnJztcclxuICBmb3IgKGNvbnN0IGIgb2YgdXRmOCkgYmluICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYik7XHJcbiAgcmV0dXJuIGJ0b2EoYmluKTtcclxufVxyXG4iLCAiaW1wb3J0IHsgVFdFRVRfVVJMX1BSRUZJWCB9IGZyb20gJy4vY29uZmlnLmpzJztcclxuaW1wb3J0IHR5cGUge1xyXG4gIENhbm9uaWNhbFR3ZWV0LFxyXG4gIENvbW11bml0eU5vdGUsXHJcbiAgTWVkaWFJdGVtLFxyXG4gIFR3ZWV0Q2FyZCxcclxuICBUd2VldFR5cGUsXHJcbiAgVW5hdmFpbGFibGVUd2VldCxcclxuICBVcmxFbnRpdHksXHJcbiAgVXNlclNuYXBzaG90LFxyXG59IGZyb20gJy4vdHlwZXMuanMnO1xyXG5cclxuLyoqXHJcbiAqIE5vcm1hbGl6ZSBHcmFwaFFMIHJlc3BvbnNlIHBheWxvYWRzIGZyb20gWCdzIGludGVybmFsIEFQSSBpbnRvXHJcbiAqIGBDYW5vbmljYWxUd2VldGBzLiBNYW55IGVuZHBvaW50cyBzaGFyZSBhIHNpbWlsYXIgdHdlZXQgc2hhcGUgYnV0IHdyYXAgaXQgaW5cclxuICogZGlmZmVyZW50IGVudmVsb3BlczsgdGhpcyBtb2R1bGUgd2Fsa3MgdGhlIHN0cnVjdHVyZSBkZWZlbnNpdmVseS5cclxuICpcclxuICogVGhlIHBhcnNlciBpcyBpbnRlbnRpb25hbGx5IHBlcm1pc3NpdmU6IGl0IHdpbGwgc2lsZW50bHkgc2tpcCBlbnRyaWVzIGl0XHJcbiAqIGNhbid0IHJlY29nbml6ZSBhcyB0d2VldHMgKGN1cnNvcnMsIGFkcywgZ2FwIGVudHJpZXMsIG1vZHVsZXMgb2Ygb3RoZXJcclxuICogdHdlZXRzLCB0b21ic3RvbmVzKS4gSXQgdGhyb3dzICpvbmx5KiB3aGVuIGdpdmVuIGEgcGF5bG9hZCBpdCBkb2Vzbid0IGtub3dcclxuICogaG93IHRvIHdhbGsgYXQgYWxsIFx1MjAxNCB0aG9zZSBjYXNlcyBhcmUgY2F1Z2h0IGFuZCBxdWFyYW50aW5lZCB1cHN0cmVhbS5cclxuICovXHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIE5vcm1hbGl6ZUNvbnRleHQge1xyXG4gIGNhcHR1cmVkQXQ6IHN0cmluZztcclxuICBydW5JZDogc3RyaW5nO1xyXG4gIGVuZHBvaW50OiBzdHJpbmc7XHJcbiAgYWxsb3dlZEhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz47XHJcbiAgc291cmNlVXJsPzogc3RyaW5nIHwgbnVsbDtcclxufVxyXG5cclxuZXhwb3J0IGludGVyZmFjZSBOb3JtYWxpemVSZXN1bHQge1xyXG4gIHR3ZWV0czogQ2Fub25pY2FsVHdlZXRbXTtcclxuICBvYnNlcnZlZF9pZHM6IHN0cmluZ1tdO1xyXG4gIHVuYXZhaWxhYmxlX3R3ZWV0czogVW5hdmFpbGFibGVUd2VldFtdO1xyXG4gIC8qKlxyXG4gICAqIFR3ZWV0LXNoYXBlZCBub2RlcyB0aGUgd2Fsa2VyIHNhdyAoaGFkIGEgYHJlc3RfaWRgKSBidXQgY291bGRuJ3QgdHVyblxyXG4gICAqIGludG8gYSBmdWxsIGBDYW5vbmljYWxUd2VldGAgXHUyMDE0IHR5cGljYWxseSBiZWNhdXNlIHRoZSBlbWJlZGRlZCB1c2VyXHJcbiAgICogaW5mbyB3YXMgbWlzc2luZyBvciB0aGUgZW50cnkgd2FzIGEgbWVkaWEtb25seSB0aHVtYm5haWwgY2FyZCBmcm9tXHJcbiAgICogdGhlIFVzZXJNZWRpYSBlbmRwb2ludC4gT25seSBJRHMgd2l0aCBhIHRydXN0d29ydGh5IGhhbmRsZSBmcm9tIHRoZVxyXG4gICAqIHR3ZWV0IG5vZGUgaXRzZWxmIGFyZSByZXR1cm5lZDsgb3RoZXJ3aXNlIHRoZSBiYWNrZ3JvdW5kIGNhbm5vdCBidWlsZFxyXG4gICAqIGEgcmVsaWFibGUgLzxoYW5kbGU+L3N0YXR1cy88aWQ+IGRldGFpbCBVUkwuXHJcbiAgICovXHJcbiAgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT47XHJcbn1cclxuXHJcbi8vIFggdHdlZXQgSURzIGFyZSA2NC1iaXQgcG9zaXRpdmUgaW50ZWdlcnMgc2VyaWFsaXplZCBhcyBkZWNpbWFsIHN0cmluZ3MuXHJcbi8vIFRoZXkndmUgZ3Jvd24gdG8gMTkgY2hhcnMgKH4xLjVlMTgpIGJ5IDIwMjYuIFJlamVjdCBhbnl0aGluZyB0aGF0IGRvZXNuJ3RcclxuLy8gbWF0Y2ggdGhpcyBzaGFwZSBcdTIwMTQgb3RoZXJ3aXNlIHNwdXJpb3VzIGNhcmQgSURzLCBjdXJzb3Igc3RyaW5ncywgYWQgc2xvdFxyXG4vLyBJRHMsIGV0Yy4gZW5kIHVwIGluIHRoZSBwYXJ0aWFsLWNhcHR1cmUgcXVldWUgYW5kIHRoZSBjcmF3bCBsb29wXHJcbi8vIG5hdmlnYXRlcyB0byBpbnZhbGlkIFVSTHMgdGhhdCBzaG93IFwidGhpcyBwYWdlIGRvZXNuJ3QgZXhpc3RcIi5cclxuY29uc3QgVFdFRVRfSURfUkUgPSAvXlxcZHsxNSwyMH0kLztcclxuXHJcbi8vIE9ubHkgb25lIGVuZHBvaW50IGFjdHVhbGx5IGV4cG9zZXMgdGhlIGZhaWx1cmUgbW9kZSB0aGUgcGFydGlhbC1jYXB0dXJlXHJcbi8vIHF1ZXVlIGV4aXN0cyBmb3IgXHUyMDE0IHRoZSBNZWRpYSB0YWIncyBgVXNlck1lZGlhYCBxdWVyeSByZXR1cm5pbmdcclxuLy8gdGh1bWJuYWlsLW9ubHkgZW50cmllcyB3aXRob3V0IGEgcG9wdWxhdGVkIGF1dGhvciBibG9jay4gRXZlcnkgb3RoZXJcclxuLy8gZW5kcG9pbnQgdGhhdCBoYW5kcyB1cyBhIGBUd2VldGAgc2hhcGUgZ2l2ZXMgdXMgdGhlIGZ1bGwgZW50cnk7IGlmXHJcbi8vIGBidWlsZFR3ZWV0YCBmYWlscyB0aGVyZSBpdCdzIGEgcmVhbCBlcnJvciwgbm90IFwiZ28gcmUtZmV0Y2ggdGhpc1wiLlxyXG4vLyBSZXN0cmljdGluZyBwYXJ0aWFsLWlkIGVtaXNzaW9uIHRvIFVzZXJNZWRpYSBzdG9wcyB0aGUgZmxvb2RzIG9mXHJcbi8vIGZhbHNlIHBvc2l0aXZlcyByZXBvcnRlZCBvbiBSZXBsaWVzIC8gVHdlZXREZXRhaWwgLyBTZWFyY2hUaW1lbGluZS5cclxuY29uc3QgUEFSVElBTF9PS19FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlck1lZGlhJ10pO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZShwYXlsb2FkOiB1bmtub3duLCBjdHg6IE5vcm1hbGl6ZUNvbnRleHQpOiBOb3JtYWxpemVSZXN1bHQge1xyXG4gIGNvbnN0IHJhd1R3ZWV0cyA9IGNvbGxlY3RUd2VldHMocGF5bG9hZCk7XHJcbiAgY29uc3QgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdID0gW107XHJcbiAgY29uc3QgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXSA9IFtdO1xyXG4gIGNvbnN0IG9ic2VydmVkOiBzdHJpbmdbXSA9IFtdO1xyXG4gIGNvbnN0IGJ1aWx0ID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbiAgY29uc3QgcGFydGlhbE1hcCA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmcgfCBudWxsPigpO1xyXG4gIGNvbnN0IGNvbGxlY3RQYXJ0aWFscyA9IFBBUlRJQUxfT0tfRU5EUE9JTlRTLmhhcyhjdHguZW5kcG9pbnQpO1xyXG4gIGZvciAoY29uc3QgcmF3IG9mIHJhd1R3ZWV0cykge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdW5hdmFpbGFibGUgPSBwaWNrVW5hdmFpbGFibGVUd2VldChyYXcsIGN0eCk7XHJcbiAgICAgIGlmICh1bmF2YWlsYWJsZSkge1xyXG4gICAgICAgIHVuYXZhaWxhYmxlVHdlZXRzLnB1c2godW5hdmFpbGFibGUpO1xyXG4gICAgICAgIG9ic2VydmVkLnB1c2godW5hdmFpbGFibGUudHdlZXRfaWQpO1xyXG4gICAgICAgIGJ1aWx0LmFkZCh1bmF2YWlsYWJsZS50d2VldF9pZCk7XHJcbiAgICAgICAgY29udGludWU7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgdCA9IGJ1aWxkVHdlZXQocmF3LCBjdHgpO1xyXG4gICAgICBpZiAoIXQpIHtcclxuICAgICAgICBpZiAoY29sbGVjdFBhcnRpYWxzKSB7XHJcbiAgICAgICAgICAvLyBPbmx5IGVucXVldWUgcmVhbC10d2VldCBzaGVsbHMgd2l0aCBhIHRydXN0d29ydGh5IGhhbmRsZSAobm90XHJcbiAgICAgICAgICAvLyB0b21ic3RvbmVzLCBzdHJpcHBlZCBub2RlcyBsYWNraW5nIGEgbGVnYWN5IGJsb2NrLCBnYXJiYWdlIElEcyxcclxuICAgICAgICAgIC8vIG9yIElEcyB0aGF0IHdvdWxkIHJlcXVpcmUgZ3Vlc3NpbmcgdGhlIGF1dGhvciBmcm9tIHRoZSBwYWdlKS5cclxuICAgICAgICAgIGNvbnN0IHBhcnRpYWwgPSBwaWNrUGFydGlhbChyYXcpO1xyXG4gICAgICAgICAgaWYgKHBhcnRpYWwpIHBhcnRpYWxNYXAuc2V0KHBhcnRpYWwudHdlZXRfaWQsIHBhcnRpYWwuaGludF9oYW5kbGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb250aW51ZTtcclxuICAgICAgfVxyXG4gICAgICBvYnNlcnZlZC5wdXNoKHQudHdlZXRfaWQpO1xyXG4gICAgICBidWlsdC5hZGQodC50d2VldF9pZCk7XHJcbiAgICAgIGlmIChjdHguYWxsb3dlZEhhbmRsZXMuc2l6ZSA9PT0gMCB8fCBjdHguYWxsb3dlZEhhbmRsZXMuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIHtcclxuICAgICAgICB0d2VldHMucHVzaCh0KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIC8vIE9uZSBiYWQgZW50cnkgc2hvdWxkbid0IHRha2UgZG93biB0aGUgd2hvbGUgYmF0Y2guXHJcbiAgICB9XHJcbiAgfVxyXG4gIC8vIEFueXRoaW5nIHRoYXQgZW5kZWQgdXAgaW4gcGFydGlhbE1hcCBidXQgQUxTTyBjYW1lIGJhY2sgYXMgYSBidWlsdFxyXG4gIC8vIHR3ZWV0IChkaWZmZXJlbnQgd2Fsa2VyIHBhc3MsIHNhbWUgaWQpIGlzbid0IGFjdHVhbGx5IHBhcnRpYWwuXHJcbiAgY29uc3QgcGFydGlhbF9pZHM6IEFycmF5PHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcclxuICBmb3IgKGNvbnN0IFtpZCwgaGludF0gb2YgcGFydGlhbE1hcCkge1xyXG4gICAgaWYgKGJ1aWx0LmhhcyhpZCkpIGNvbnRpbnVlO1xyXG4gICAgcGFydGlhbF9pZHMucHVzaCh7IHR3ZWV0X2lkOiBpZCwgaGludF9oYW5kbGU6IGhpbnQgfSk7XHJcbiAgfVxyXG4gIHJldHVybiB7IHR3ZWV0cywgb2JzZXJ2ZWRfaWRzOiBvYnNlcnZlZCwgdW5hdmFpbGFibGVfdHdlZXRzOiB1bmF2YWlsYWJsZVR3ZWV0cywgcGFydGlhbF9pZHMgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gcGlja1VuYXZhaWxhYmxlVHdlZXQobm9kZTogdW5rbm93biwgY3R4OiBOb3JtYWxpemVDb250ZXh0KTogVW5hdmFpbGFibGVUd2VldCB8IG51bGwge1xyXG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcbiAgaWYgKG4uX190eXBlbmFtZSAhPT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IHR3ZWV0SWQgPVxyXG4gICAgc3RyT3JOdWxsKG4ucmVzdF9pZCkgPz9cclxuICAgIHBpY2tUd2VldElkRnJvbVVybHMobm9kZSkgPz9cclxuICAgIChjdHguc291cmNlVXJsID8gdHdlZXRJZEZyb21Ud2VldFVybChjdHguc291cmNlVXJsKSA6IG51bGwpO1xyXG4gIGlmICghdHdlZXRJZCB8fCAhVFdFRVRfSURfUkUudGVzdCh0d2VldElkKSkgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IHVuYXZhaWxhYmxlVGV4dCA9IHBpY2tUb21ic3RvbmVUZXh0KG5vZGUpO1xyXG4gIHJldHVybiB7XHJcbiAgICB0d2VldF9pZDogdHdlZXRJZCxcclxuICAgIGFjY291bnRfaGFuZGxlOlxyXG4gICAgICBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlLCB0d2VldElkKSA/P1xyXG4gICAgICAoY3R4LnNvdXJjZVVybCA/IGhhbmRsZUZyb21Ud2VldFVybChjdHguc291cmNlVXJsLCB0d2VldElkKSA6IG51bGwpLFxyXG4gICAgdW5hdmFpbGFibGVfZGV0ZWN0ZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxyXG4gICAgdW5hdmFpbGFibGVfcmVhc29uOiBjbGFzc2lmeVVuYXZhaWxhYmxlUmVhc29uKHVuYXZhaWxhYmxlVGV4dCksXHJcbiAgICB1bmF2YWlsYWJsZV90ZXh0OiB1bmF2YWlsYWJsZVRleHQsXHJcbiAgICB1bmF2YWlsYWJsZV9zb3VyY2VfdXJsOiBjdHguc291cmNlVXJsID8/IG51bGwsXHJcbiAgfTtcclxufVxyXG5cclxuZnVuY3Rpb24gcGlja1R3ZWV0SWRGcm9tVXJscyhub2RlOiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcclxuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xyXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBjdXIgPSBzdGFjay5wb3AoKTtcclxuICAgIGlmICh0eXBlb2YgY3VyID09PSAnc3RyaW5nJykge1xyXG4gICAgICBjb25zdCBpZCA9IHR3ZWV0SWRGcm9tVHdlZXRVcmwoY3VyKTtcclxuICAgICAgaWYgKGlkKSByZXR1cm4gaWQ7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAoc2Vlbi5oYXMoY3VyIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xyXG4gICAgc2Vlbi5hZGQoY3VyIGFzIG9iamVjdCk7XHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBjdXIpIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gdHdlZXRJZEZyb21Ud2VldFVybChyYXdVcmw6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHJhd1VybCwgVFdFRVRfVVJMX1BSRUZJWCk7XHJcbiAgICBpZiAodXJsLmhvc3RuYW1lICE9PSAneC5jb20nICYmIHVybC5ob3N0bmFtZSAhPT0gJ3R3aXR0ZXIuY29tJykgcmV0dXJuIG51bGw7XHJcbiAgICBjb25zdCBtYXRjaCA9IHVybC5wYXRobmFtZS5tYXRjaCgvXlxcL1tBLVphLXowLTlfXXsxLDE1fVxcL3N0YXR1c1xcLyhcXGR7MTUsMjB9KSg/OlxcL3wkKS8pO1xyXG4gICAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gbnVsbDtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcGlja1RvbWJzdG9uZVRleHQobm9kZTogdW5rbm93bik6IHN0cmluZyB8IG51bGwge1xyXG4gIGNvbnN0IHN0cmluZ3M6IHN0cmluZ1tdID0gW107XHJcbiAgY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcclxuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xyXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBjdXIgPSBzdGFjay5wb3AoKTtcclxuICAgIGlmICh0eXBlb2YgY3VyID09PSAnc3RyaW5nJykge1xyXG4gICAgICBjb25zdCB0cmltbWVkID0gY3VyLnRyaW0oKTtcclxuICAgICAgaWYgKFxyXG4gICAgICAgIHRyaW1tZWQubGVuZ3RoID49IDQgJiZcclxuICAgICAgICAhdHJpbW1lZC5zdGFydHNXaXRoKCdodHRwOi8vJykgJiZcclxuICAgICAgICAhdHJpbW1lZC5zdGFydHNXaXRoKCdodHRwczovLycpXHJcbiAgICAgICkge1xyXG4gICAgICAgIHN0cmluZ3MucHVzaCh0cmltbWVkKTtcclxuICAgICAgfVxyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHNlZW4uaGFzKGN1ciBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKGN1ciBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkoY3VyKSkge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgY3VyKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMoY3VyIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgY29uc3QgcHJlZmVycmVkID0gc3RyaW5ncy5maW5kKChzKSA9PlxyXG4gICAgL1xcYihjb3B5cmlnaHR8ZG1jYXx1bmF2YWlsYWJsZXx3aXRoaGVsZHxyZW1vdmVkfGRlbGV0ZWR8dmlvbGF0fHN1c3BlbmRlZClcXGIvaS50ZXN0KHMpXHJcbiAgKTtcclxuICByZXR1cm4gcHJlZmVycmVkID8/IHN0cmluZ3NbMF0gPz8gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gY2xhc3NpZnlVbmF2YWlsYWJsZVJlYXNvbih0ZXh0OiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgaWYgKCF0ZXh0KSByZXR1cm4gbnVsbDtcclxuICBpZiAoL1xcYihjb3B5cmlnaHR8ZG1jYSlcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ2NvcHlyaWdodCc7XHJcbiAgaWYgKC9cXGJ3aXRoaGVsZFxcYi9pLnRlc3QodGV4dCkpIHJldHVybiAnd2l0aGhlbGQnO1xyXG4gIGlmICgvXFxiZGVsZXRlZHxyZW1vdmVkXFxiL2kudGVzdCh0ZXh0KSkgcmV0dXJuICdyZW1vdmVkJztcclxuICBpZiAoL1xcYnN1c3BlbmRlZFxcYi9pLnRlc3QodGV4dCkpIHJldHVybiAnc3VzcGVuZGVkJztcclxuICBpZiAoL1xcYnVuYXZhaWxhYmxlfG5vdCBhdmFpbGFibGVcXGIvaS50ZXN0KHRleHQpKSByZXR1cm4gJ3VuYXZhaWxhYmxlJztcclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gcGlja1BhcnRpYWwobm9kZTogdW5rbm93bik6IHsgdHdlZXRfaWQ6IHN0cmluZzsgaGludF9oYW5kbGU6IHN0cmluZyB8IG51bGwgfSB8IG51bGwge1xyXG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgbiA9IG5vZGUgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XHJcbiAgLy8gRGVsZXRlZCB0d2VldHMgc3VyZmFjZSBhcyBUd2VldFRvbWJzdG9uZSBcdTIwMTQgdGhlcmUncyBub3RoaW5nIHRvIHJlZmV0Y2gsXHJcbiAgLy8gc2tpcCB0aGVtIG9yIHRoZSBjcmF3bCBsb29wIHdpbGwgc3BpbiBvbiBcInRoaXMgcGFnZSBkb2Vzbid0IGV4aXN0XCIuXHJcbiAgaWYgKG4uX190eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XHJcbiAgLy8gUmVxdWlyZSBhIHJlY29nbml6ZWQgVHdlZXQgdHlwZW5hbWUgT1IgYSBsZWdhY3kgYmxvY2suIEN1cnNvcnMsIGFkcyxcclxuICAvLyBtb2R1bGUgaGVhZGVycywgYW5kIHRoZSBsaWtlIGdldCByZWplY3RlZCBoZXJlLlxyXG4gIGNvbnN0IHRuID0gbi5fX3R5cGVuYW1lO1xyXG4gIGlmICh0biAhPT0gJ1R3ZWV0JyAmJiB0biAhPT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiAhb2JqKG4ubGVnYWN5KSkge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG4gIGNvbnN0IHJlc3RJZCA9XHJcbiAgICAodHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgbi5yZXN0X2lkKSB8fFxyXG4gICAgKHR5cGVvZiBvYmoobi50d2VldF9yZXN1bHQpPy5yZXN1bHQgPT09ICdvYmplY3QnICYmXHJcbiAgICAgIChvYmoob2JqKG4udHdlZXRfcmVzdWx0KT8ucmVzdWx0KT8ucmVzdF9pZCBhcyBzdHJpbmcpKTtcclxuICBpZiAodHlwZW9mIHJlc3RJZCAhPT0gJ3N0cmluZycgfHwgIVRXRUVUX0lEX1JFLnRlc3QocmVzdElkKSkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgaGludEhhbmRsZSA9IHBpY2tIaW50SGFuZGxlKG5vZGUsIHJlc3RJZCk7XHJcbiAgaWYgKCFoaW50SGFuZGxlKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4geyB0d2VldF9pZDogcmVzdElkLCBoaW50X2hhbmRsZTogaGludEhhbmRsZSB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBwaWNrSGludEhhbmRsZShub2RlOiB1bmtub3duLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAodHlwZW9mIG5vZGUgIT09ICdvYmplY3QnIHx8IG5vZGUgPT09IG51bGwpIHJldHVybiBudWxsO1xyXG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIGNvbnN0IHVzZXJSZXN1bHQgPSBvYmoob2JqKG9iaihuLmNvcmUpPy51c2VyX3Jlc3VsdHMpPy5yZXN1bHQpO1xyXG4gIHJldHVybiAoXHJcbiAgICBzdHJPck51bGwob2JqKHVzZXJSZXN1bHQ/LmNvcmUpPy5zY3JlZW5fbmFtZSkgPz9cclxuICAgIHN0ck9yTnVsbChvYmoodXNlclJlc3VsdD8ubGVnYWN5KT8uc2NyZWVuX25hbWUpID8/XHJcbiAgICBzdHJPck51bGwob2JqKG4ubGVnYWN5KT8uc2NyZWVuX25hbWUpID8/XHJcbiAgICBwaWNrSGFuZGxlRnJvbVR3ZWV0VXJscyhub2RlLCB0d2VldElkKVxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tIYW5kbGVGcm9tVHdlZXRVcmxzKG5vZGU6IHVua25vd24sIHR3ZWV0SWQ6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgY3VyID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAodHlwZW9mIGN1ciA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgY29uc3QgaGFuZGxlID0gaGFuZGxlRnJvbVR3ZWV0VXJsKGN1ciwgdHdlZXRJZCk7XHJcbiAgICAgIGlmIChoYW5kbGUpIHJldHVybiBoYW5kbGU7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgaWYgKGN1ciA9PT0gbnVsbCB8fCB0eXBlb2YgY3VyICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAoc2Vlbi5oYXMoY3VyIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xyXG4gICAgc2Vlbi5hZGQoY3VyIGFzIG9iamVjdCk7XHJcbiAgICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBjdXIpIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfVxyXG4gIH1cclxuICByZXR1cm4gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gaGFuZGxlRnJvbVR3ZWV0VXJsKHJhd1VybDogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdXJsID0gbmV3IFVSTChyYXdVcmwsIFRXRUVUX1VSTF9QUkVGSVgpO1xyXG4gICAgaWYgKHVybC5ob3N0bmFtZSAhPT0gJ3guY29tJyAmJiB1cmwuaG9zdG5hbWUgIT09ICd0d2l0dGVyLmNvbScpIHJldHVybiBudWxsO1xyXG4gICAgY29uc3QgbWF0Y2ggPSB1cmwucGF0aG5hbWUubWF0Y2goL15cXC8oW0EtWmEtejAtOV9dezEsMTV9KVxcL3N0YXR1c1xcLyhcXGR7MTUsMjB9KSg/OlxcL3wkKS8pO1xyXG4gICAgaWYgKCFtYXRjaCB8fCBtYXRjaFsyXSAhPT0gdHdlZXRJZCkgcmV0dXJuIG51bGw7XHJcbiAgICByZXR1cm4gbWF0Y2hbMV0gPz8gbnVsbDtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gY29sbGVjdFR3ZWV0cyhvYmo6IHVua25vd24pOiB1bmtub3duW10ge1xyXG4gIC8vIFdhbGsgdGhlIHJlc3BvbnNlIHRyZWUgZ2F0aGVyaW5nIGV2ZXJ5dGhpbmcgdGhhdCBsb29rcyBsaWtlIGEgdHdlZXRcclxuICAvLyByZXN1bHQuIFdlIGxvb2sgZm9yIG5vZGVzIHNoYXBlZCBsaWtlOlxyXG4gIC8vICAgeyBfX3R5cGVuYW1lPzogJ1R3ZWV0J3wnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnLCByZXN0X2lkLCBsZWdhY3kgfVxyXG4gIC8vIGFuZCB1bndyYXAgdmlzaWJpbGl0eSB3cmFwcGVycy5cclxuICBjb25zdCBvdXQ6IHVua25vd25bXSA9IFtdO1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtvYmpdO1xyXG4gIHdoaWxlIChzdGFjay5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBub2RlID0gc3RhY2sucG9wKCk7XHJcbiAgICBpZiAobm9kZSA9PT0gbnVsbCB8fCBub2RlID09PSB1bmRlZmluZWQpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHR5cGVvZiBub2RlICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAoc2Vlbi5oYXMobm9kZSBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHNlZW4uYWRkKG5vZGUgYXMgb2JqZWN0KTtcclxuXHJcbiAgICBpZiAobG9va3NMaWtlVHdlZXQobm9kZSkpIHtcclxuICAgICAgb3V0LnB1c2godW53cmFwVHdlZXQobm9kZSkpO1xyXG4gICAgfVxyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkobm9kZSkpIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIG5vZGUpIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBmb3IgKGNvbnN0IHYgb2YgT2JqZWN0LnZhbHVlcyhub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuZnVuY3Rpb24gbG9va3NMaWtlVHdlZXQobm9kZTogdW5rbm93bik6IG5vZGUgaXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4ge1xyXG4gIGlmICh0eXBlb2Ygbm9kZSAhPT0gJ29iamVjdCcgfHwgbm9kZSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xyXG4gIGNvbnN0IG4gPSBub2RlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIGNvbnN0IHR5cGVuYW1lID0gbi5fX3R5cGVuYW1lO1xyXG4gIGlmIChcclxuICAgIHR5cGVuYW1lID09PSAnVHdlZXQnIHx8XHJcbiAgICB0eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyB8fFxyXG4gICAgdHlwZW5hbWUgPT09ICdUd2VldFRvbWJzdG9uZSdcclxuICApIHtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICAvLyBTb21lIGVudHJpZXMgbGFjayBfX3R5cGVuYW1lIGJ1dCBzdGlsbCBjYXJyeSBsZWdhY3kgKyByZXN0X2lkICsgY29yZS5cclxuICByZXR1cm4gdHlwZW9mIG4ucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgdHlwZW9mIG4ubGVnYWN5ID09PSAnb2JqZWN0JyAmJiBuLmxlZ2FjeSAhPT0gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gdW53cmFwVHdlZXQobm9kZTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XHJcbiAgaWYgKG5vZGUuX190eXBlbmFtZSA9PT0gJ1R3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzJyAmJiB0eXBlb2Ygbm9kZS50d2VldCA9PT0gJ29iamVjdCcpIHtcclxuICAgIHJldHVybiBub2RlLnR3ZWV0IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gIH1cclxuICByZXR1cm4gbm9kZTtcclxufVxyXG5cclxuZnVuY3Rpb24gYnVpbGRUd2VldChyYXc6IHVua25vd24sIGN0eDogTm9ybWFsaXplQ29udGV4dCk6IENhbm9uaWNhbFR3ZWV0IHwgbnVsbCB7XHJcbiAgaWYgKHR5cGVvZiByYXcgIT09ICdvYmplY3QnIHx8IHJhdyA9PT0gbnVsbCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgdCA9IHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuXHJcbiAgaWYgKHQuX190eXBlbmFtZSA9PT0gJ1R3ZWV0VG9tYnN0b25lJykgcmV0dXJuIG51bGw7XHJcblxyXG4gIGNvbnN0IHJlc3RJZCA9IHN0ck9yTnVsbCh0LnJlc3RfaWQpO1xyXG4gIC8vIGBsZWdhY3lgIGlzIHN0aWxsIHdoZXJlIG1vc3QgZW5nYWdlbWVudCAvIGVudGl0aWVzIGxpdmUgaW4gMjAyNi1lcmEgWFxyXG4gIC8vIHBheWxvYWRzLCBidXQgYXMgb2YgcmVjZW50IHNjaGVtYSBtaWdyYXRpb25zIHNldmVyYWwgZmllbGRzIHByZXZpb3VzbHlcclxuICAvLyB0aGVyZSAobm90YWJseSB0aGUgYXV0aG9yIGhhbmRsZSkgaGF2ZSBtb3ZlZCB0byBzaWJsaW5nIGxvY2F0aW9ucy4gV2VcclxuICAvLyB0b2xlcmF0ZSBhIG1pc3NpbmcgbGVnYWN5IGhlcmUgYW5kIGxvb2sgdXAgZXZlcnl0aGluZyB2aWEgZmFsbGJhY2tzLlxyXG4gIGNvbnN0IGxlZ2FjeSA9IG9iaih0LmxlZ2FjeSkgPz8ge307XHJcbiAgaWYgKCFyZXN0SWQpIHJldHVybiBudWxsO1xyXG5cclxuICBjb25zdCBjb3JlID0gb2JqKHQuY29yZSk7XHJcbiAgY29uc3QgdXNlclJlc3VsdCA9IG9iaihvYmooY29yZT8udXNlcl9yZXN1bHRzKT8ucmVzdWx0KTtcclxuICAvLyBBdXRob3IgaGFuZGxlOiB0cnkgdGhlIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIGZpcnN0IChjdXJyZW50IFggc2hhcGUpLFxyXG4gIC8vIHRoZW4gdGhlIGxlZ2FjeSBgbGVnYWN5LnNjcmVlbl9uYW1lYCwgdGhlbiBhIGNvdXBsZSBvZiBvbGRlciB2YXJpYW50cy5cclxuICBjb25zdCB1c2VyQ29yZU5ldyA9IG9iaih1c2VyUmVzdWx0Py5jb3JlKTtcclxuICBjb25zdCB1c2VyTGVnYWN5ID0gb2JqKHVzZXJSZXN1bHQ/LmxlZ2FjeSk7XHJcbiAgY29uc3QgdXNlckF2YXRhck9iaiA9IG9iaih1c2VyUmVzdWx0Py5hdmF0YXIpO1xyXG4gIGNvbnN0IGhhbmRsZSA9XHJcbiAgICBzdHJPck51bGwodXNlckNvcmVOZXc/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LnNjcmVlbl9uYW1lKSA/P1xyXG4gICAgc3RyT3JOdWxsKGxlZ2FjeS5zY3JlZW5fbmFtZSk7XHJcbiAgY29uc3QgYWNjb3VudElkID1cclxuICAgIHN0ck9yTnVsbCh1c2VyUmVzdWx0Py5yZXN0X2lkKSA/P1xyXG4gICAgc3RyT3JOdWxsKHVzZXJSZXN1bHQ/LmlkX3N0cikgPz9cclxuICAgIHN0ck9yTnVsbChsZWdhY3kudXNlcl9pZF9zdHIpO1xyXG4gIGlmICghaGFuZGxlIHx8ICFhY2NvdW50SWQpIHJldHVybiBudWxsO1xyXG4gIC8vIEF1dGhvciBzbmFwc2hvdC4gRGlzcGxheSBuYW1lICsgYXZhdGFyIG1vdmVkIGJldHdlZW4gYGxlZ2FjeWAgYW5kIHRoZVxyXG4gIC8vIG5ldyBgY29yZWAgc3Vic3RydWN0dXJlIG92ZXIgdGltZTsgdGhlIHJlc3QgKHZlcmlmaWNhdGlvbiwgZm9sbG93ZXJcclxuICAvLyBjb3VudHMsIGFjY291bnRfY3JlYXRlZF9hdCkgaXMgc3RpbGwgaW4gYGxlZ2FjeWAuIFdlIHNuYXBzaG90IHRoZVxyXG4gIC8vIHdob2xlIFVzZXJTbmFwc2hvdCBwZXIgdHdlZXQgYmVjYXVzZSB0aGVzZSB2YWx1ZXMgZHJpZnQgb3ZlciB0aW1lXHJcbiAgLy8gYW5kIHRoZSBhdC1jYXB0dXJlIHN0YXRlIGlzIHRoZSBvbmx5IHJlbGlhYmxlIHJlY29yZC5cclxuICBjb25zdCBhdXRob3IgPSBleHRyYWN0VXNlclNuYXBzaG90KHVzZXJSZXN1bHQsIHVzZXJDb3JlTmV3LCB1c2VyTGVnYWN5LCB1c2VyQXZhdGFyT2JqKTtcclxuXHJcbiAgY29uc3Qgbm90ZVR3ZWV0ID0gb2JqKG9iaihvYmoodC5ub3RlX3R3ZWV0KT8ubm90ZV90d2VldF9yZXN1bHRzKT8ucmVzdWx0KTtcclxuICBjb25zdCB0ZXh0RnJvbU5vdGUgPSBzdHJPck51bGwobm90ZVR3ZWV0Py50ZXh0KTtcclxuICBjb25zdCB0ZXh0RnJvbUxlZ2FjeSA9IHN0ck9yTnVsbChsZWdhY3kuZnVsbF90ZXh0KSA/PyAnJztcclxuICBjb25zdCB0ZXh0ID0gdGV4dEZyb21Ob3RlID8/IHRleHRGcm9tTGVnYWN5O1xyXG4gIGNvbnN0IGlzVHJ1bmNhdGVkID0gZGV0ZWN0VHJ1bmNhdGlvbihub3RlVHdlZXQsIGxlZ2FjeSwgdGV4dEZyb21MZWdhY3kpO1xyXG4gIGNvbnN0IGNvbW11bml0eU5vdGUgPSBleHRyYWN0Q29tbXVuaXR5Tm90ZSh0LCBsZWdhY3ksIGN0eC5jYXB0dXJlZEF0KTtcclxuXHJcbiAgY29uc3QgZW50aXRpZXMgPSBvYmoobGVnYWN5LmVudGl0aWVzKSA/PyB7fTtcclxuICBjb25zdCBlbnRpdGllc0Zyb21Ob3RlID0gb2JqKG5vdGVUd2VldD8uZW50aXR5X3NldCk7XHJcbiAgY29uc3QgaGFzaHRhZ3MgPSBleHRyYWN0SGFzaHRhZ3MoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XHJcbiAgY29uc3QgbWVudGlvbnMgPSBleHRyYWN0TWVudGlvbnMoZW50aXRpZXNGcm9tTm90ZSA/PyBlbnRpdGllcyk7XHJcbiAgY29uc3QgdXJscyA9IGV4dHJhY3RVcmxzKGVudGl0aWVzRnJvbU5vdGUgPz8gZW50aXRpZXMpO1xyXG4gIGNvbnN0IG1lZGlhID0gZXh0cmFjdE1lZGlhKGxlZ2FjeSk7XHJcblxyXG4gIGNvbnN0IHR3ZWV0VHlwZSA9IGNsYXNzaWZ5VHdlZXRUeXBlKHQsIGxlZ2FjeSk7XHJcblxyXG4gIC8vIHBvc3RlZF9hdDogbGVnYWN5LmNyZWF0ZWRfYXQgcmVtYWlucyB0aGUgY2Fub25pY2FsIGxvY2F0aW9uOyBpZiB0aGF0J3NcclxuICAvLyBtaXNzaW5nIGluIGEgZnV0dXJlIHNjaGVtYSB3ZSBmYWxsIGJhY2sgdG8gdG9wLWxldmVsIGNyZWF0ZWRfYXQuXHJcbiAgY29uc3QgcG9zdGVkQXQgPVxyXG4gICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwobGVnYWN5LmNyZWF0ZWRfYXQpKSA/PyBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh0LmNyZWF0ZWRfYXQpKTtcclxuICBpZiAoIXBvc3RlZEF0KSByZXR1cm4gbnVsbDtcclxuXHJcbiAgY29uc3Qgdmlld3MgPSBvYmoodC52aWV3cyk7XHJcbiAgY29uc3Qgdmlld0NvdW50ID0gbnVtT3JOdWxsKHZpZXdzPy5jb3VudCkgPz8gbnVtT3JOdWxsKHN0ck9yTnVsbCh2aWV3cz8uY291bnQpKTtcclxuXHJcbiAgY29uc3QgY2FyZCA9IGV4dHJhY3RDYXJkKHQpO1xyXG4gIGNvbnN0IHBsYWNlID0gb2JqKGxlZ2FjeS5wbGFjZSk7XHJcblxyXG4gIGNvbnN0IHR3ZWV0OiBDYW5vbmljYWxUd2VldCA9IHtcclxuICAgIHR3ZWV0X2lkOiByZXN0SWQsXHJcbiAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxyXG4gICAgYWNjb3VudF9pZDogYWNjb3VudElkLFxyXG4gICAgcG9zdGVkX2F0OiBwb3N0ZWRBdCxcclxuICAgIGZpcnN0X2NhcHR1cmVkX2F0OiBjdHguY2FwdHVyZWRBdCxcclxuICAgIGxhc3Rfc2Vlbl9hdDogY3R4LmNhcHR1cmVkQXQsXHJcbiAgICBkZWxldGlvbl9kZXRlY3RlZF9hdDogbnVsbCxcclxuICAgIHVuYXZhaWxhYmxlX2RldGVjdGVkX2F0OiBudWxsLFxyXG4gICAgdW5hdmFpbGFibGVfcmVhc29uOiBudWxsLFxyXG4gICAgdW5hdmFpbGFibGVfdGV4dDogbnVsbCxcclxuICAgIHVuYXZhaWxhYmxlX3NvdXJjZV91cmw6IG51bGwsXHJcbiAgICB0d2VldF91cmw6IGAke1RXRUVUX1VSTF9QUkVGSVh9LyR7aGFuZGxlfS9zdGF0dXMvJHtyZXN0SWR9YCxcclxuICAgIHR3ZWV0X3R5cGU6IHR3ZWV0VHlwZSxcclxuICAgIGNvbnZlcnNhdGlvbl9pZDogc3RyT3JOdWxsKGxlZ2FjeS5jb252ZXJzYXRpb25faWRfc3RyKSxcclxuICAgIHJlcGx5X3RvX3R3ZWV0X2lkOiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3N0YXR1c19pZF9zdHIpLFxyXG4gICAgcmVwbHlfdG9fYWNjb3VudDogc3RyT3JOdWxsKGxlZ2FjeS5pbl9yZXBseV90b19zY3JlZW5fbmFtZSksXHJcbiAgICByZXBseV90b19hY2NvdW50X2lkOiBzdHJPck51bGwobGVnYWN5LmluX3JlcGx5X3RvX3VzZXJfaWRfc3RyKSxcclxuICAgIHF1b3RlZF90d2VldF9pZDogc3RyT3JOdWxsKGxlZ2FjeS5xdW90ZWRfc3RhdHVzX2lkX3N0ciksXHJcbiAgICByZXR3ZWV0ZWRfdHdlZXRfaWQ6IHN0ck9yTnVsbChcclxuICAgICAgb2JqKG9iaihsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQpPy5yZXN1bHQpPy5yZXN0X2lkID8/XHJcbiAgICAgICAgKGxlZ2FjeSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikucmV0d2VldGVkX3N0YXR1c19pZF9zdHJcclxuICAgICksXHJcbiAgICB0ZXh0LFxyXG4gICAgdGV4dF9yZXNvbHZlZDogcmVzb2x2ZVNob3J0VXJscyh0ZXh0LCB1cmxzKSxcclxuICAgIGxhbmc6IHN0ck9yTnVsbChsZWdhY3kubGFuZyksXHJcbiAgICBwb3NzaWJseV9zZW5zaXRpdmU6IGJvb2xPck51bGwobGVnYWN5LnBvc3NpYmx5X3NlbnNpdGl2ZSksXHJcbiAgICBzb3VyY2U6IHN0ck9yTnVsbChsZWdhY3kuc291cmNlKSA/PyBzdHJPck51bGwodC5zb3VyY2UpLFxyXG4gICAgcGxhY2VfZnVsbF9uYW1lOiBzdHJPck51bGwocGxhY2U/LmZ1bGxfbmFtZSksXHJcbiAgICBoYXNodGFncyxcclxuICAgIG1lbnRpb25zLFxyXG4gICAgdXJscyxcclxuICAgIGNhcmQsXHJcbiAgICBtZWRpYSxcclxuICAgIGxpa2VfY291bnQ6IG51bU9yWmVybyhsZWdhY3kuZmF2b3JpdGVfY291bnQpLFxyXG4gICAgcmV0d2VldF9jb3VudDogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcclxuICAgIHJlcGx5X2NvdW50OiBudW1Pclplcm8obGVnYWN5LnJlcGx5X2NvdW50KSxcclxuICAgIHF1b3RlX2NvdW50OiBudW1Pclplcm8obGVnYWN5LnF1b3RlX2NvdW50KSxcclxuICAgIHZpZXdfY291bnQ6IHZpZXdDb3VudCxcclxuICAgIGJvb2ttYXJrX2NvdW50OiBudW1Pck51bGwobGVnYWN5LmJvb2ttYXJrX2NvdW50KSxcclxuICAgIGVuZ2FnZW1lbnRfaGlzdG9yeTogW1xyXG4gICAgICB7XHJcbiAgICAgICAgY2FwdHVyZWRfYXQ6IGN0eC5jYXB0dXJlZEF0LFxyXG4gICAgICAgIGxpa2VzOiBudW1Pclplcm8obGVnYWN5LmZhdm9yaXRlX2NvdW50KSxcclxuICAgICAgICByZXR3ZWV0czogbnVtT3JaZXJvKGxlZ2FjeS5yZXR3ZWV0X2NvdW50KSxcclxuICAgICAgICByZXBsaWVzOiBudW1Pclplcm8obGVnYWN5LnJlcGx5X2NvdW50KSxcclxuICAgICAgICBxdW90ZXM6IG51bU9yWmVybyhsZWdhY3kucXVvdGVfY291bnQpLFxyXG4gICAgICAgIHZpZXdzOiB2aWV3Q291bnQsXHJcbiAgICAgICAgYm9va21hcmtzOiBudW1Pck51bGwobGVnYWN5LmJvb2ttYXJrX2NvdW50KSxcclxuICAgICAgfSxcclxuICAgIF0sXHJcbiAgICBhdXRob3IsXHJcbiAgICBjb21tdW5pdHlfbm90ZTogY29tbXVuaXR5Tm90ZSxcclxuICAgIGlzX3RydW5jYXRlZDogaXNUcnVuY2F0ZWQsXHJcbiAgICB3YXliYWNrX3VybDogbnVsbCxcclxuICAgIHdheWJhY2tfc3VibWl0dGVkX2F0OiBudWxsLFxyXG4gICAgY2FwdHVyZV9zb3VyY2U6ICdleHRlbnNpb24nLFxyXG4gICAgY2FwdHVyZV9ydW5faWQ6IGN0eC5ydW5JZCxcclxuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxyXG4gIH07XHJcblxyXG4gIHJldHVybiB0d2VldDtcclxufVxyXG5cclxuZnVuY3Rpb24gY2xhc3NpZnlUd2VldFR5cGUodDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBUd2VldFR5cGUge1xyXG4gIGlmIChsZWdhY3kucmV0d2VldGVkX3N0YXR1c19yZXN1bHQgfHwgbGVnYWN5LnJldHdlZXRlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3JldHdlZXQnO1xyXG4gIGlmIChsZWdhY3kuaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0cikgcmV0dXJuICdyZXBseSc7XHJcbiAgaWYgKGxlZ2FjeS5pc19xdW90ZV9zdGF0dXMgPT09IHRydWUgfHwgbGVnYWN5LnF1b3RlZF9zdGF0dXNfaWRfc3RyKSByZXR1cm4gJ3F1b3RlJztcclxuICBpZiAodC5fX3R5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnKSB7XHJcbiAgICAvLyBwYXNzIHRocm91Z2hcclxuICB9XHJcbiAgcmV0dXJuICdvcmlnaW5hbCc7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGV4dHJhY3RIYXNodGFncyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XHJcbiAgY29uc3QgYXJyID0gZW50aXRpZXMuaGFzaHRhZ3M7XHJcbiAgaWYgKCFBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBbXTtcclxuICByZXR1cm4gYXJyXHJcbiAgICAubWFwKChoKSA9PlxyXG4gICAgICB0eXBlb2YgaCA9PT0gJ29iamVjdCcgJiYgaCAmJiAndGV4dCcgaW4gaCA/IFN0cmluZygoaCBhcyB7IHRleHQ6IHVua25vd24gfSkudGV4dCkgOiBudWxsXHJcbiAgICApXHJcbiAgICAuZmlsdGVyKChzKTogcyBpcyBzdHJpbmcgPT4gdHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHMubGVuZ3RoID4gMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGV4dHJhY3RNZW50aW9ucyhlbnRpdGllczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBzdHJpbmdbXSB7XHJcbiAgY29uc3QgYXJyID0gZW50aXRpZXMudXNlcl9tZW50aW9ucztcclxuICBpZiAoIUFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIFtdO1xyXG4gIHJldHVybiBhcnJcclxuICAgIC5tYXAoKHUpID0+XHJcbiAgICAgIHR5cGVvZiB1ID09PSAnb2JqZWN0JyAmJiB1ICYmICdzY3JlZW5fbmFtZScgaW4gdVxyXG4gICAgICAgID8gU3RyaW5nKCh1IGFzIHsgc2NyZWVuX25hbWU6IHVua25vd24gfSkuc2NyZWVuX25hbWUpXHJcbiAgICAgICAgOiBudWxsXHJcbiAgICApXHJcbiAgICAuZmlsdGVyKChzKTogcyBpcyBzdHJpbmcgPT4gdHlwZW9mIHMgPT09ICdzdHJpbmcnICYmIHMubGVuZ3RoID4gMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGV4dHJhY3RVcmxzKGVudGl0aWVzOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFVybEVudGl0eVtdIHtcclxuICBjb25zdCBhcnIgPSBlbnRpdGllcy51cmxzO1xyXG4gIGlmICghQXJyYXkuaXNBcnJheShhcnIpKSByZXR1cm4gW107XHJcbiAgY29uc3Qgb3V0OiBVcmxFbnRpdHlbXSA9IFtdO1xyXG4gIGZvciAoY29uc3QgdSBvZiBhcnIpIHtcclxuICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XHJcbiAgICBjb25zdCBvID0gdSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgIGNvbnN0IHNob3J0ID0gc3RyT3JOdWxsKG8udXJsKTtcclxuICAgIGNvbnN0IGV4cGFuZGVkID0gc3RyT3JOdWxsKG8uZXhwYW5kZWRfdXJsKTtcclxuICAgIGNvbnN0IGRpc3BsYXkgPSBzdHJPck51bGwoby5kaXNwbGF5X3VybCk7XHJcbiAgICBpZiAoIXNob3J0IHx8ICFleHBhbmRlZCkgY29udGludWU7XHJcbiAgICBvdXQucHVzaCh7IHNob3J0LCBleHBhbmRlZCwgZGlzcGxheTogZGlzcGxheSA/PyBleHBhbmRlZCB9KTtcclxuICB9XHJcbiAgcmV0dXJuIG91dDtcclxufVxyXG5cclxuZnVuY3Rpb24gZXh0cmFjdE1lZGlhKGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pOiBNZWRpYUl0ZW1bXSB7XHJcbiAgY29uc3QgZXh0ZW5kZWQgPSBvYmoobGVnYWN5LmV4dGVuZGVkX2VudGl0aWVzKTtcclxuICBjb25zdCBmcm9tRXh0ID0gZXh0ZW5kZWQgPyB0b0FycmF5KGV4dGVuZGVkLm1lZGlhKSA6IFtdO1xyXG4gIGNvbnN0IGZyb21FbnQgPSB0b0FycmF5KG9iaihsZWdhY3kuZW50aXRpZXMpPy5tZWRpYSk7XHJcbiAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGNvbnN0IG1lcmdlZCA9IFsuLi5mcm9tRXh0LCAuLi5mcm9tRW50XS5maWx0ZXIoKG0pID0+IHtcclxuICAgIGlmICh0eXBlb2YgbSAhPT0gJ29iamVjdCcgfHwgbSA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgY29uc3QgaWQgPVxyXG4gICAgICBzdHJPck51bGwoKG0gYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLm1lZGlhX2tleSkgPz9cclxuICAgICAgc3RyT3JOdWxsKChtIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5pZF9zdHIpO1xyXG4gICAgaWYgKCFpZCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgaWYgKHNlZW4uaGFzKGlkKSkgcmV0dXJuIGZhbHNlO1xyXG4gICAgc2Vlbi5hZGQoaWQpO1xyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSk7XHJcbiAgcmV0dXJuIG1lcmdlZC5tYXAoKHJhdykgPT4gYnVpbGRNZWRpYShyYXcgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pKTtcclxufVxyXG5cclxuZnVuY3Rpb24gYnVpbGRNZWRpYShtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IE1lZGlhSXRlbSB7XHJcbiAgY29uc3QgdHlwZSA9IHN0ck9yTnVsbChtLnR5cGUpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddO1xyXG4gIGNvbnN0IG9yaWdpbmFsID0gcGlja09yaWdpbmFsVXJsKG0sIHR5cGUpO1xyXG4gIGNvbnN0IGluZm8gPSBvYmoobS5vcmlnaW5hbF9pbmZvKTtcclxuICBjb25zdCB2aWRlb0luZm8gPSBvYmoobS52aWRlb19pbmZvKTtcclxuICBjb25zdCBkdXJhdGlvbk1zID0gbnVtT3JOdWxsKHZpZGVvSW5mbz8uZHVyYXRpb25fbWlsbGlzKTtcclxuICBjb25zdCBhbHRUZXh0ID0gc3RyT3JOdWxsKG0uZXh0X2FsdF90ZXh0KTtcclxuICBjb25zdCBtZWRpYUlkID1cclxuICAgIHN0ck9yTnVsbChtLm1lZGlhX2tleSkgPz9cclxuICAgIHN0ck9yTnVsbChtLmlkX3N0cikgPz9cclxuICAgIGAke3R5cGUgPz8gJ21lZGlhJ30tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKX1gO1xyXG4gIHJldHVybiB7XHJcbiAgICBtZWRpYV9pZDogbWVkaWFJZCxcclxuICAgIG1lZGlhX3R5cGU6ICh0eXBlID8/ICdwaG90bycpIGFzIE1lZGlhSXRlbVsnbWVkaWFfdHlwZSddLFxyXG4gICAgb3JpZ2luYWxfdXJsOiBvcmlnaW5hbCA/PyAnJyxcclxuICAgIHJlbGVhc2VfYXNzZXRfdXJsOiBudWxsLFxyXG4gICAgc2hhMjU2OiBudWxsLFxyXG4gICAgYnl0ZXM6IG51bGwsXHJcbiAgICBkdXJhdGlvbl9zZWM6IGR1cmF0aW9uTXMgIT09IG51bGwgPyBkdXJhdGlvbk1zIC8gMTAwMCA6IG51bGwsXHJcbiAgICB3aWR0aDogbnVtT3JOdWxsKGluZm8/LndpZHRoKSxcclxuICAgIGhlaWdodDogbnVtT3JOdWxsKGluZm8/LmhlaWdodCksXHJcbiAgICBhbHRfdGV4dDogYWx0VGV4dCxcclxuICAgIGFyY2hpdmVfc3RhdHVzOiAncGVuZGluZycsXHJcbiAgICBhcmNoaXZlX2F0dGVtcHRzOiAwLFxyXG4gICAgbGFzdF9hdHRlbXB0X2F0OiBudWxsLFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBpY2tPcmlnaW5hbFVybChtOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiwgdHlwZTogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xyXG4gIGlmICh0eXBlID09PSAncGhvdG8nKSByZXR1cm4gc3RyT3JOdWxsKG0ubWVkaWFfdXJsX2h0dHBzKSA/PyBzdHJPck51bGwobS5tZWRpYV91cmwpO1xyXG4gIGNvbnN0IHZhcmlhbnRzID0gdG9BcnJheShvYmoobS52aWRlb19pbmZvKT8udmFyaWFudHMpIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+W107XHJcbiAgaWYgKHZhcmlhbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHN0ck9yTnVsbChtLm1lZGlhX3VybF9odHRwcyk7XHJcbiAgLy8gSGlnaGVzdC1iaXRyYXRlIG1wNC5cclxuICBsZXQgYmVzdDogeyB1cmw6IHN0cmluZzsgYml0cmF0ZTogbnVtYmVyIH0gfCBudWxsID0gbnVsbDtcclxuICBmb3IgKGNvbnN0IHYgb2YgdmFyaWFudHMpIHtcclxuICAgIGNvbnN0IGN0ID0gc3RyT3JOdWxsKHYuY29udGVudF90eXBlKTtcclxuICAgIGNvbnN0IHVybCA9IHN0ck9yTnVsbCh2LnVybCk7XHJcbiAgICBpZiAoIXVybCkgY29udGludWU7XHJcbiAgICBpZiAoY3QgPT09ICd2aWRlby9tcDQnKSB7XHJcbiAgICAgIGNvbnN0IGJyID0gbnVtT3JOdWxsKHYuYml0cmF0ZSkgPz8gMDtcclxuICAgICAgaWYgKCFiZXN0IHx8IGJyID4gYmVzdC5iaXRyYXRlKSBiZXN0ID0geyB1cmwsIGJpdHJhdGU6IGJyIH07XHJcbiAgICB9IGVsc2UgaWYgKCFiZXN0KSB7XHJcbiAgICAgIC8vIEZhbGxiYWNrIHRvIGFueSB2YXJpYW50IGlmIG5vIG1wNCBmb3VuZC5cclxuICAgICAgYmVzdCA9IHsgdXJsLCBiaXRyYXRlOiAwIH07XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBiZXN0Py51cmwgPz8gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gcmVzb2x2ZVNob3J0VXJscyh0ZXh0OiBzdHJpbmcsIHVybHM6IFVybEVudGl0eVtdKTogc3RyaW5nIHtcclxuICBpZiAodXJscy5sZW5ndGggPT09IDApIHJldHVybiB0ZXh0O1xyXG4gIGxldCBvdXQgPSB0ZXh0O1xyXG4gIGZvciAoY29uc3QgdSBvZiB1cmxzKSBvdXQgPSBvdXQuc3BsaXQodS5zaG9ydCkuam9pbih1LmV4cGFuZGVkKTtcclxuICByZXR1cm4gb3V0O1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYXJzZVR3aXR0ZXJEYXRlKHM6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAoIXMpIHJldHVybiBudWxsO1xyXG4gIC8vIFR3aXR0ZXIgc2hpcHMgZGF0ZXMgbGlrZSBcIk1vbiBBcHIgMTIgMTQ6MjM6MDEgKzAwMDAgMjAyNVwiLlxyXG4gIGNvbnN0IGQgPSBuZXcgRGF0ZShzKTtcclxuICBpZiAoTnVtYmVyLmlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIGQudG9JU09TdHJpbmcoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc3RyT3JOdWxsKHY6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcclxuICByZXR1cm4gdHlwZW9mIHYgPT09ICdzdHJpbmcnICYmIHYubGVuZ3RoID4gMCA/IHYgOiBudWxsO1xyXG59XHJcbmZ1bmN0aW9uIGJvb2xPck51bGwodjogdW5rbm93bik6IGJvb2xlYW4gfCBudWxsIHtcclxuICByZXR1cm4gdHlwZW9mIHYgPT09ICdib29sZWFuJyA/IHYgOiBudWxsO1xyXG59XHJcbmZ1bmN0aW9uIG51bU9yTnVsbCh2OiB1bmtub3duKTogbnVtYmVyIHwgbnVsbCB7XHJcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyAmJiBOdW1iZXIuaXNGaW5pdGUodikpIHJldHVybiB2O1xyXG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwKSB7XHJcbiAgICBjb25zdCBuID0gTnVtYmVyKHYpO1xyXG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShuKSkgcmV0dXJuIG47XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcbmZ1bmN0aW9uIG51bU9yWmVybyh2OiB1bmtub3duKTogbnVtYmVyIHtcclxuICByZXR1cm4gbnVtT3JOdWxsKHYpID8/IDA7XHJcbn1cclxuZnVuY3Rpb24gb2JqKHY6IHVua25vd24pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwge1xyXG4gIHJldHVybiB0eXBlb2YgdiA9PT0gJ29iamVjdCcgJiYgdiAhPT0gbnVsbCAmJiAhQXJyYXkuaXNBcnJheSh2KVxyXG4gICAgPyAodiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPilcclxuICAgIDogbnVsbDtcclxufVxyXG5mdW5jdGlvbiB0b0FycmF5KHY6IHVua25vd24pOiB1bmtub3duW10ge1xyXG4gIHJldHVybiBBcnJheS5pc0FycmF5KHYpID8gdiA6IFtdO1xyXG59XHJcblxyXG4vKipcclxuICogRGVjaWRlIHdoZXRoZXIgYSB0d2VldCdzIGFyY2hpdmVkIGB0ZXh0YCBpcyB0aGUgdHJ1bmNhdGVkIGhlYWQgb2YgYSBsb25nZXJcclxuICogYm9keS4gQSB0cnVuY2F0ZWQgdHdlZXQgaGFzIFgncyBcIlNob3cgbW9yZVwiIHQuY28gVVJMIGFwcGVuZGVkIFx1MjAxNCB0aGF0IFVSTFxyXG4gKiBzcGVjaWZpY2FsbHkgZXhwYW5kcyB0byB0aGUgdHdlZXQncyBvd24gL2kvd2ViL3N0YXR1cy88aWQ+IHBlcm1hbGluaywgYW5kXHJcbiAqIGlzIHRoZSBvbmx5IHJlbGlhYmxlIGRpc3Rpbmd1aXNoaW5nIGZlYXR1cmUuIFBsZW50eSBvZiBub3JtYWwgdHdlZXRzIGhhdmVcclxuICogdHJhaWxpbmcgdC5jbyBVUkxzIChtZWRpYSwgcXVvdGVzLCByZWd1bGFyIGxpbmtzKSwgYW5kIHRoZWlyXHJcbiAqIGRpc3BsYXlfdGV4dF9yYW5nZSBhbHNvIHRyaW1zIHBhc3QgZnVsbF90ZXh0Lmxlbmd0aCwgc28gdGhlIG9sZFxyXG4gKiBcImRpc3BsYXlfdGV4dF9yYW5nZVsxXSA8IGZ1bGxfdGV4dC5sZW5ndGhcIiBoZXVyaXN0aWMgd2FzIG92ZXJmbGFnZ2luZ1xyXG4gKiBlc3NlbnRpYWxseSBldmVyeSB0d2VldCB3aXRoIGEgbGluayBpbiBpdC5cclxuICpcclxuICogUnVsZXM6XHJcbiAqICAgLSBub3RlX3R3ZWV0IHByZXNlbnQgIFx1MjE5MiBub3QgdHJ1bmNhdGVkICh3ZSBhbHJlYWR5IGhhdmUgdGhlIGZ1bGwgYm9keSkuXHJcbiAqICAgLSBPbmUgb2YgbGVnYWN5LmVudGl0aWVzLnVybHMgaGFzIGFuIGV4cGFuZGVkX3VybCBsaWtlXHJcbiAqICAgICBcIi4uLi9pL3dlYi9zdGF0dXMvPGlkPlwiICBcdTIxOTIgIHRydW5jYXRlZC5cclxuICogICAtIE90aGVyd2lzZSBcdTIxOTIgbm90IHRydW5jYXRlZC5cclxuICpcclxuICogVGhlIHByZXZpb3VzIGZhbGxiYWNrIChcInRyYWlsaW5nIHQuY28gVVJMICsgbGVuZ3RoIFx1MjI2NSAyNzBcIikgZmxhZ2dlZCBldmVyeVxyXG4gKiBtZWRpYSB0d2VldCBleGFjdGx5IGF0IHRoZSAyODAtY2hhciBsaW1pdC4gV2UgZHJvcCBpdCBlbnRpcmVseTsgdGhlIG9ubHlcclxuICogY29zdCBpcyBtaXNzaW5nIGdlbnVpbmVseS10cnVuY2F0ZWQgdHdlZXRzIHdob3NlIHBheWxvYWQgd2FzIHNvIGRlZ3JhZGVkXHJcbiAqIGl0IGxhY2tlZCBlbnRpdGllcyBcdTIwMTQgd2hpY2ggaXMgYWxzbyB3aGVyZSB0aGUgcmVmZXRjaCBsb29wIHdvdWxkIGZhaWxcclxuICogYW55d2F5LCBzbyBub3RoaW5nIGlzIGFjdHVhbGx5IGxvc3QuXHJcbiAqL1xyXG5mdW5jdGlvbiBkZXRlY3RUcnVuY2F0aW9uKFxyXG4gIG5vdGVUd2VldDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsLFxyXG4gIGxlZ2FjeTogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXHJcbiAgZnVsbFRleHQ6IHN0cmluZ1xyXG4pOiBib29sZWFuIHtcclxuICBpZiAobm90ZVR3ZWV0KSByZXR1cm4gZmFsc2U7XHJcbiAgaWYgKCFmdWxsVGV4dCkgcmV0dXJuIGZhbHNlO1xyXG4gIGNvbnN0IGVudGl0aWVzID0gb2JqKGxlZ2FjeS5lbnRpdGllcyk7XHJcbiAgY29uc3QgdXJscyA9IGVudGl0aWVzID8gZW50aXRpZXMudXJscyA6IG51bGw7XHJcbiAgaWYgKEFycmF5LmlzQXJyYXkodXJscykpIHtcclxuICAgIGZvciAoY29uc3QgdSBvZiB1cmxzKSB7XHJcbiAgICAgIGlmICh0eXBlb2YgdSAhPT0gJ29iamVjdCcgfHwgdSA9PT0gbnVsbCkgY29udGludWU7XHJcbiAgICAgIGNvbnN0IGV4cCA9ICh1IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5leHBhbmRlZF91cmw7XHJcbiAgICAgIC8vIFRoZSBcIlNob3cgbW9yZVwiIGxpbmsgZXhwYW5kcyB0byBlaXRoZXIgb2YgdGhlc2Ugc2VsZi1wZXJtYWxpbmtcclxuICAgICAgLy8gc2hhcGVzOiAgaHR0cHM6Ly94LmNvbS9pL3dlYi9zdGF0dXMvPGlkPlxyXG4gICAgICAvLyAgICAgICAgICBodHRwczovL3R3aXR0ZXIuY29tL2kvd2ViL3N0YXR1cy88aWQ+XHJcbiAgICAgIGlmICh0eXBlb2YgZXhwID09PSAnc3RyaW5nJyAmJiAvXFwvaVxcL3dlYlxcL3N0YXR1c1xcL1xcZCsvLnRlc3QoZXhwKSkge1xyXG4gICAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBmYWxzZTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZpbHRlciBgdHdlZXRzYCBkb3duIHRvIHRob3NlIHJlbGF0ZWQgdG8gYSB0cmFja2VkIGFjY291bnQuIEEgdHdlZXQgaXNcclxuICogXCJyZWxhdGVkXCIgaWYgYW55IG9mIHRoZSBmb2xsb3dpbmcgaG9sZDpcclxuICpcclxuICogICAtIGl0cyBhdXRob3IgaXMgdHJhY2tlZCAoaGFuZGxlIGluIGB0YXJnZXRlZGApLFxyXG4gKiAgIC0gaXRzIGF1dGhvciBpcyBjb3JlIChoYW5kbGUgaW4gYGNvcmVIYW5kbGVzYCksIHJlZ2FyZGxlc3Mgb2Ygd2hlcmUgWFxyXG4gKiAgICAgc3VyZmFjZWQgaXQsXHJcbiAqICAgLSBpdCBtZW50aW9ucyBhIHRyYWNrZWQgaGFuZGxlLFxyXG4gKiAgIC0gaXQgcmVwbGllcyB0byBhIHRyYWNrZWQgYWNjb3VudCxcclxuICogICAtIGl0IHF1b3Rlcy9yZXBsaWVzLXRvIGEgdHdlZXQgdGhhdCdzIGFsc28gcHJlc2VudCBpbiB0aGVcclxuICogICAgIGJhdGNoICphbmQqIGF1dGhvcmVkIGJ5IGEgdHJhY2tlZCBhY2NvdW50ICh0cmFuc2l0aXZlbHkgcmVsYXRlZCBcdTIwMTRcclxuICogICAgIGNhcHR1cmVzIHF1b3RlZC9yZXBseSBjb250ZXh0IHRoYXQgYXBwZWFycyBhcyBhIHNpYmxpbmcgbm9kZSBpbiB0aGVcclxuICogICAgIHNhbWUgR3JhcGhRTCByZXNwb25zZSkuXHJcbiAqXHJcbiAqIE5vbi1jb3JlIHJldHdlZXQgd3JhcHBlcnMgYXJlIG5vdCBrZXB0IG1lcmVseSBiZWNhdXNlIHRoZXkgcmV0d2VldGVkIGFcclxuICogdHJhY2tlZC9jb3JlIHR3ZWV0LiBUaGUgdW5kZXJseWluZyBjb3JlIHR3ZWV0IGlzIGtlcHQgYXMgaXRzIG93biByb3cgd2hlblxyXG4gKiBwcmVzZW50IGluIHRoZSBwYXlsb2FkLlxyXG4gKlxyXG4gKiBBbnl0aGluZyBlbHNlIChyYW5kb20gcmVwbGllcyB1bmRlciBhIHRyYWNrZWQgYWNjb3VudCdzIHR3ZWV0LCByYW5kb21cclxuICogYXV0aG9ycyB0aGF0IGhhcHBlbiB0byBzdXJmYWNlIGluIGEgdHJhY2tlZCBhY2NvdW50J3MgdGhyZWFkKSBpcyBkcm9wcGVkLlxyXG4gKiBQYXNzIGFuIGVtcHR5IGB0YXJnZXRlZGAgc2V0IHRvIGRpc2FibGUgZmlsdGVyaW5nIGVudGlyZWx5LlxyXG4gKi9cclxuZXhwb3J0IGZ1bmN0aW9uIGZpbHRlclJlbGF0ZWQoXHJcbiAgdHdlZXRzOiBDYW5vbmljYWxUd2VldFtdLFxyXG4gIHRhcmdldGVkOiBSZWFkb25seVNldDxzdHJpbmc+LFxyXG4gIGNvcmVIYW5kbGVzOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldCgpXHJcbik6IENhbm9uaWNhbFR3ZWV0W10ge1xyXG4gIGlmICh0YXJnZXRlZC5zaXplID09PSAwICYmIGNvcmVIYW5kbGVzLnNpemUgPT09IDApIHJldHVybiB0d2VldHM7XHJcbiAgLy8gRmlyc3QgcGFzczogd2hpY2ggdHdlZXQgSURzIGRvIHRyYWNrZWQtYXV0aG9yIHR3ZWV0cyByZWZlcmVuY2UgKHRoZVxyXG4gIC8vIFwiZm9yd2FyZFwiIGRpcmVjdGlvbiBcdTIwMTQgdHJhY2tlZCBhY2NvdW50IHF1b3RlcyAvIFJUcyAvIHJlcGxpZXMgdG8gWCk/XHJcbiAgLy8gQW5kIHdoaWNoIHR3ZWV0IElEcyBBUkUgdHJhY2tlZC1hdXRob3JlZCAodGhlIFwicmV2ZXJzZVwiIGRpcmVjdGlvbiBcdTIwMTRcclxuICAvLyBYIHF1b3RlcyAvIFJUcyAvIHJlcGxpZXMgdG8gYSB0cmFja2VkIHR3ZWV0KT9cclxuICBjb25zdCByZWZlcmVuY2VkSWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbiAgY29uc3QgdGFyZ2V0ZWRUd2VldElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcclxuICAgIGlmICghdGFyZ2V0ZWQuaGFzKHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKSkpIGNvbnRpbnVlO1xyXG4gICAgdGFyZ2V0ZWRUd2VldElkcy5hZGQodC50d2VldF9pZCk7XHJcbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucXVvdGVkX3R3ZWV0X2lkKTtcclxuICAgIGlmICh0LnJldHdlZXRlZF90d2VldF9pZCkgcmVmZXJlbmNlZElkcy5hZGQodC5yZXR3ZWV0ZWRfdHdlZXRfaWQpO1xyXG4gICAgaWYgKHQucmVwbHlfdG9fdHdlZXRfaWQpIHJlZmVyZW5jZWRJZHMuYWRkKHQucmVwbHlfdG9fdHdlZXRfaWQpO1xyXG4gIH1cclxuICByZXR1cm4gdHdlZXRzLmZpbHRlcigodCkgPT4ge1xyXG4gICAgY29uc3QgaCA9IHQuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKTtcclxuICAgIGlmICh0YXJnZXRlZC5oYXMoaCkpIHJldHVybiB0cnVlO1xyXG4gICAgaWYgKGNvcmVIYW5kbGVzLmhhcyhoKSkgcmV0dXJuIHRydWU7XHJcbiAgICAvLyBGb3J3YXJkOiBhIHRyYWNrZWQtYXV0aG9yIHR3ZWV0IHBvaW50ZWQgYXQgdGhpcyBvbmUuXHJcbiAgICBpZiAocmVmZXJlbmNlZElkcy5oYXModC50d2VldF9pZCkpIHJldHVybiB0cnVlO1xyXG4gICAgLy8gUmV2ZXJzZTogdGhpcyB0d2VldCBxdW90ZXMvcmVwbGllcyB0byBhIHRyYWNrZWQtYXV0aG9yIHR3ZWV0IGluIHRoZVxyXG4gICAgLy8gYmF0Y2guIFJldmVyc2UgcmV0d2VldHMgYXJlIGp1c3QgXCJub24tY29yZSBhY2NvdW50IHJldHdlZXRlZCBjb3JlXHJcbiAgICAvLyB0d2VldFwiIHdyYXBwZXJzLCBhbmQgZG8gbm90IGFkZCBjb3JlIGFyY2hpdmUgdmFsdWUuXHJcbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQgJiYgdGFyZ2V0ZWRUd2VldElkcy5oYXModC5xdW90ZWRfdHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcclxuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkICYmIHRhcmdldGVkVHdlZXRJZHMuaGFzKHQucmVwbHlfdG9fdHdlZXRfaWQpKSByZXR1cm4gdHJ1ZTtcclxuICAgIC8vIFJlcGx5LXRvLWFjY291bnQgb3IgbWVudGlvbnMgYSB0cmFja2VkIGhhbmRsZS5cclxuICAgIGlmICh0LnJlcGx5X3RvX2FjY291bnQgJiYgdGFyZ2V0ZWQuaGFzKHQucmVwbHlfdG9fYWNjb3VudC50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIHRydWU7XHJcbiAgICBmb3IgKGNvbnN0IG0gb2YgdC5tZW50aW9ucykge1xyXG4gICAgICBpZiAodGFyZ2V0ZWQuaGFzKG0udG9Mb3dlckNhc2UoKSkpIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogUHVsbCB0aGUgQ29tbXVuaXR5IE5vdGUgKGZvcm1lcmx5IEJpcmR3YXRjaCkgYmxvY2sgYXR0YWNoZWQgdG8gYSB0d2VldCwgaWZcclxuICogYW55LiBUaGUgcGl2b3QgY2FuIGxpdmUgYXQgYHR3ZWV0LmxlZ2FjeS5iaXJkd2F0Y2hfcGl2b3RgIChvbGRlciBzaGFwZSkgb3JcclxuICogYHR3ZWV0LmJpcmR3YXRjaF9waXZvdGAgKGN1cnJlbnQgc2hhcGUpLiBUaGUgc3VtbWFyeSB0ZXh0IGlzIHdoYXQgcmVhZGVyc1xyXG4gKiBhY3R1YWxseSBzZWU7IHdlIGtlZXAgdGhlIHN1cnJvdW5kaW5nIG1ldGFkYXRhIHNvIGRvd25zdHJlYW0gdG9vbGluZyBjYW5cclxuICogdGVsbCBkcmFmdHMgYXBhcnQgZnJvbSByYXRlZC1oZWxwZnVsIG5vdGVzLlxyXG4gKi9cclxuZnVuY3Rpb24gZXh0cmFjdENvbW11bml0eU5vdGUoXHJcbiAgdDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXHJcbiAgbGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcclxuICBvYnNlcnZlZEF0OiBzdHJpbmdcclxuKTogQ29tbXVuaXR5Tm90ZSB8IG51bGwge1xyXG4gIGNvbnN0IHBpdm90ID0gb2JqKHQuYmlyZHdhdGNoX3Bpdm90KSA/PyBvYmoobGVnYWN5LmJpcmR3YXRjaF9waXZvdCk7XHJcbiAgaWYgKCFwaXZvdCkgcmV0dXJuIG51bGw7XHJcbiAgY29uc3Qgc3VidGl0bGUgPSBvYmoocGl2b3Quc3VidGl0bGUpO1xyXG4gIGNvbnN0IG5vdGUgPSBvYmoocGl2b3Qubm90ZSk7XHJcbiAgY29uc3Qgc3VtbWFyeSA9IHN0ck9yTnVsbChzdWJ0aXRsZT8udGV4dCk7XHJcbiAgY29uc3QgdGl0bGUgPSBzdHJPck51bGwocGl2b3QudGl0bGUpO1xyXG4gIGNvbnN0IHNob3J0VGl0bGUgPSBzdHJPck51bGwocGl2b3Quc2hvcnRUaXRsZSk7XHJcbiAgY29uc3QgZGVzdGluYXRpb25VcmwgPSBzdHJPck51bGwocGl2b3QuZGVzdGluYXRpb25VcmwpO1xyXG4gIGNvbnN0IG5vdGVJZCA9IHN0ck9yTnVsbChwaXZvdC5ub3RlSWQpID8/IHN0ck9yTnVsbChub3RlPy5yZXN0X2lkKTtcclxuICAvLyBTa2lwIGVtcHR5IHNoZWxscyB0aGF0IGhhdmUgbm8gYWN0dWFsIGNvbnRlbnQuXHJcbiAgaWYgKCFzdW1tYXJ5ICYmICF0aXRsZSAmJiAhbm90ZUlkKSByZXR1cm4gbnVsbDtcclxuICByZXR1cm4ge1xyXG4gICAgbm90ZV9pZDogbm90ZUlkLFxyXG4gICAgdGl0bGUsXHJcbiAgICBzaG9ydF90aXRsZTogc2hvcnRUaXRsZSxcclxuICAgIHN1bW1hcnksXHJcbiAgICBkZXN0aW5hdGlvbl91cmw6IGRlc3RpbmF0aW9uVXJsLFxyXG4gICAgb2JzZXJ2ZWRfYXQ6IG9ic2VydmVkQXQsXHJcbiAgfTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFB1bGwgYSBwZXItYXV0aG9yIFVzZXJTbmFwc2hvdCBmcm9tIHRoZSB0d2VldCdzIHVzZXJfcmVzdWx0cyBub2RlLiBFdmVyeVxyXG4gKiBmaWVsZCBkZWZhdWx0cyB0byBudWxsIHdoZW4gbWlzc2luZyBzbyB0aGUgc2NoZW1hIHN0YXlzIHN0YWJsZSBhY3Jvc3NcclxuICogdGhlIGxlZ2FjeSAvIGNvcmUgc2hhcGUgbWlncmF0aW9ucyBYIGhhcyBiZWVuIGRvaW5nLlxyXG4gKi9cclxuZnVuY3Rpb24gZXh0cmFjdFVzZXJTbmFwc2hvdChcclxuICB1c2VyUmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXHJcbiAgdXNlckNvcmVOZXc6IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgbnVsbCxcclxuICB1c2VyTGVnYWN5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwsXHJcbiAgdXNlckF2YXRhck9iajogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsXHJcbik6IFVzZXJTbmFwc2hvdCB7XHJcbiAgY29uc3QgdmVyaWZpY2F0aW9uID0gb2JqKHVzZXJSZXN1bHQ/LnZlcmlmaWNhdGlvbik7XHJcbiAgcmV0dXJuIHtcclxuICAgIGRpc3BsYXlfbmFtZTpcclxuICAgICAgc3RyT3JOdWxsKHVzZXJDb3JlTmV3Py5uYW1lKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8ubmFtZSkgPz8gc3RyT3JOdWxsKHVzZXJSZXN1bHQ/Lm5hbWUpLFxyXG4gICAgYXZhdGFyX3VybDpcclxuICAgICAgc3RyT3JOdWxsKHVzZXJBdmF0YXJPYmo/LmltYWdlX3VybCkgPz9cclxuICAgICAgc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnByb2ZpbGVfaW1hZ2VfdXJsX2h0dHBzKSA/P1xyXG4gICAgICBzdHJPck51bGwodXNlclJlc3VsdD8ucHJvZmlsZV9pbWFnZV91cmxfaHR0cHMpLFxyXG4gICAgdmVyaWZpZWQ6IGJvb2xPck51bGwodmVyaWZpY2F0aW9uPy52ZXJpZmllZCkgPz8gYm9vbE9yTnVsbCh1c2VyTGVnYWN5Py52ZXJpZmllZCksXHJcbiAgICBpc19ibHVlX3ZlcmlmaWVkOiBib29sT3JOdWxsKHVzZXJSZXN1bHQ/LmlzX2JsdWVfdmVyaWZpZWQpLFxyXG4gICAgdmVyaWZpZWRfdHlwZTogc3RyT3JOdWxsKHZlcmlmaWNhdGlvbj8udmVyaWZpZWRfdHlwZSkgPz8gc3RyT3JOdWxsKHVzZXJMZWdhY3k/LnZlcmlmaWVkX3R5cGUpLFxyXG4gICAgZGVzY3JpcHRpb246IHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5kZXNjcmlwdGlvbiksXHJcbiAgICBsb2NhdGlvbjogc3RyT3JOdWxsKG9iaih1c2VyUmVzdWx0Py5sb2NhdGlvbik/LmxvY2F0aW9uKSA/PyBzdHJPck51bGwodXNlckxlZ2FjeT8ubG9jYXRpb24pLFxyXG4gICAgdXJsOiBzdHJPck51bGwodXNlckxlZ2FjeT8udXJsKSxcclxuICAgIGZvbGxvd2Vyc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LmZvbGxvd2Vyc19jb3VudCksXHJcbiAgICBmcmllbmRzX2NvdW50OiBudW1Pck51bGwodXNlckxlZ2FjeT8uZnJpZW5kc19jb3VudCksXHJcbiAgICBzdGF0dXNlc19jb3VudDogbnVtT3JOdWxsKHVzZXJMZWdhY3k/LnN0YXR1c2VzX2NvdW50KSxcclxuICAgIGFjY291bnRfY3JlYXRlZF9hdDpcclxuICAgICAgcGFyc2VUd2l0dGVyRGF0ZShzdHJPck51bGwodXNlckNvcmVOZXc/LmNyZWF0ZWRfYXQpKSA/P1xyXG4gICAgICBwYXJzZVR3aXR0ZXJEYXRlKHN0ck9yTnVsbCh1c2VyTGVnYWN5Py5jcmVhdGVkX2F0KSksXHJcbiAgICBwcm90ZWN0ZWQ6IGJvb2xPck51bGwodXNlckxlZ2FjeT8ucHJvdGVjdGVkKSxcclxuICB9O1xyXG59XHJcblxyXG4vKipcclxuICogV2FsayB0aGUgdHdlZXQncyBgY2FyZC5sZWdhY3kuYmluZGluZ192YWx1ZXNgIChrZXkvdmFsdWUgYXJyYXkpIGludG8gYVxyXG4gKiBmbGF0IFR3ZWV0Q2FyZCB3aXRoIHRpdGxlLCBkZXNjcmlwdGlvbiwgYW5kIGEgcmVwcmVzZW50YXRpdmUgaW1hZ2UgVVJMLlxyXG4gKiBSZXR1cm5zIG51bGwgd2hlbiB0aGUgdHdlZXQgaGFzIG5vIGNhcmQuXHJcbiAqL1xyXG5mdW5jdGlvbiBleHRyYWN0Q2FyZCh0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IFR3ZWV0Q2FyZCB8IG51bGwge1xyXG4gIGNvbnN0IGNhcmQgPSBvYmoodC5jYXJkKTtcclxuICBjb25zdCBjYXJkTGVnYWN5ID0gb2JqKGNhcmQ/LmxlZ2FjeSk7XHJcbiAgaWYgKCFjYXJkTGVnYWN5KSByZXR1cm4gbnVsbDtcclxuICBjb25zdCBiaW5kaW5ncyA9IGNhcmRMZWdhY3kuYmluZGluZ192YWx1ZXM7XHJcbiAgY29uc3QgYnlLZXk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+ID0ge307XHJcbiAgaWYgKEFycmF5LmlzQXJyYXkoYmluZGluZ3MpKSB7XHJcbiAgICBmb3IgKGNvbnN0IGJ2IG9mIGJpbmRpbmdzKSB7XHJcbiAgICAgIGlmICh0eXBlb2YgYnYgIT09ICdvYmplY3QnIHx8IGJ2ID09PSBudWxsKSBjb250aW51ZTtcclxuICAgICAgY29uc3QgbyA9IGJ2IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gICAgICBjb25zdCBrID0gc3RyT3JOdWxsKG8ua2V5KTtcclxuICAgICAgY29uc3QgdiA9IG9iaihvLnZhbHVlKTtcclxuICAgICAgaWYgKCFrIHx8ICF2KSBjb250aW51ZTtcclxuICAgICAgYnlLZXlba10gPVxyXG4gICAgICAgIHN0ck9yTnVsbCh2LnN0cmluZ192YWx1ZSkgPz9cclxuICAgICAgICBzdHJPck51bGwob2JqKHYuaW1hZ2VfdmFsdWUpPy51cmwpID8/XHJcbiAgICAgICAgc3RyT3JOdWxsKG9iaih2LmltYWdlX2NvbG9yX3ZhbHVlKT8ucGFsZXR0ZSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IG5hbWUgPSBzdHJPck51bGwoY2FyZExlZ2FjeS5uYW1lKTtcclxuICBjb25zdCBjYXJkVXJsID0gc3RyT3JOdWxsKGNhcmRMZWdhY3kudXJsKTtcclxuICBjb25zdCB2ZW5kb3JVcmwgPVxyXG4gICAgdHlwZW9mIGJ5S2V5Wyd2YW5pdHlfdXJsJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5Wyd2YW5pdHlfdXJsJ10gYXMgc3RyaW5nKSA6IG51bGw7XHJcbiAgY29uc3QgdGl0bGUgPSB0eXBlb2YgYnlLZXlbJ3RpdGxlJ10gPT09ICdzdHJpbmcnID8gKGJ5S2V5Wyd0aXRsZSddIGFzIHN0cmluZykgOiBudWxsO1xyXG4gIGNvbnN0IGRlc2NyaXB0aW9uID1cclxuICAgIHR5cGVvZiBieUtleVsnZGVzY3JpcHRpb24nXSA9PT0gJ3N0cmluZycgPyAoYnlLZXlbJ2Rlc2NyaXB0aW9uJ10gYXMgc3RyaW5nKSA6IG51bGw7XHJcbiAgY29uc3QgaW1hZ2VVcmwgPVxyXG4gICAgKHR5cGVvZiBieUtleVsncGhvdG9faW1hZ2VfZnVsbF9zaXplX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXHJcbiAgICAgID8gKGJ5S2V5WydwaG90b19pbWFnZV9mdWxsX3NpemVfb3JpZ2luYWwnXSBhcyBzdHJpbmcpXHJcbiAgICAgIDogbnVsbCkgPz9cclxuICAgICh0eXBlb2YgYnlLZXlbJ3RodW1ibmFpbF9pbWFnZV9vcmlnaW5hbCddID09PSAnc3RyaW5nJ1xyXG4gICAgICA/IChieUtleVsndGh1bWJuYWlsX2ltYWdlX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxyXG4gICAgICA6IG51bGwpID8/XHJcbiAgICAodHlwZW9mIGJ5S2V5WydzdW1tYXJ5X3Bob3RvX2ltYWdlX29yaWdpbmFsJ10gPT09ICdzdHJpbmcnXHJcbiAgICAgID8gKGJ5S2V5WydzdW1tYXJ5X3Bob3RvX2ltYWdlX29yaWdpbmFsJ10gYXMgc3RyaW5nKVxyXG4gICAgICA6IG51bGwpO1xyXG4gIGlmICghbmFtZSAmJiAhdGl0bGUgJiYgIWRlc2NyaXB0aW9uICYmICFpbWFnZVVybCkgcmV0dXJuIG51bGw7XHJcbiAgcmV0dXJuIHtcclxuICAgIG5hbWUsXHJcbiAgICBjYXJkX3VybDogY2FyZFVybCxcclxuICAgIHZlbmRvcl91cmw6IHZlbmRvclVybCxcclxuICAgIHRpdGxlLFxyXG4gICAgZGVzY3JpcHRpb24sXHJcbiAgICBpbWFnZV91cmw6IGltYWdlVXJsLFxyXG4gIH07XHJcbn1cclxuIiwgIi8qKlxyXG4gKiBMaWdodHdlaWdodCBVTElELWxpa2UgaWQgZ2VuZXJhdG9yOiAyNi1jaGFyYWN0ZXIgQ3JvY2tmb3JkIGJhc2UzMiBzdHJpbmdcclxuICogb2YgKHRpbWVzdGFtcF9tcyB8fCByYW5kb21uZXNzKS4gR29vZCBlbm91Z2ggZm9yIHJ1biBpZGVudGlmaWVycyB3aXRob3V0XHJcbiAqIHB1bGxpbmcgaW4gYSByZWFsIFVMSUQgZGVwZW5kZW5jeS5cclxuICovXHJcblxyXG5jb25zdCBBTFBIQUJFVCA9ICcwMTIzNDU2Nzg5QUJDREVGR0hKS01OUFFSU1RWV1hZWic7IC8vIENyb2NrZm9yZFxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIG5ld1J1bklkKCk6IHN0cmluZyB7XHJcbiAgY29uc3QgdHMgPSBEYXRlLm5vdygpO1xyXG4gIGxldCB0c1BhcnQgPSAnJztcclxuICBsZXQgdCA9IHRzO1xyXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMTA7IGkrKykge1xyXG4gICAgdHNQYXJ0ID0gKEFMUEhBQkVUW3QgJSAzMl0gPz8gJzAnKSArIHRzUGFydDtcclxuICAgIHQgPSBNYXRoLmZsb29yKHQgLyAzMik7XHJcbiAgfVxyXG4gIGNvbnN0IHJhbmQgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDEwKSk7XHJcbiAgbGV0IHJhbmRQYXJ0ID0gJyc7XHJcbiAgZm9yIChjb25zdCBiIG9mIHJhbmQpIHJhbmRQYXJ0ICs9IEFMUEhBQkVUW2IgJSAzMl0gPz8gJzAnO1xyXG4gIHJldHVybiB0c1BhcnQgKyByYW5kUGFydDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNob3J0UnVuSWQoaWQ6IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGlkLnNsaWNlKC04KTtcclxufVxyXG4iLCAiaW1wb3J0IHR5cGUgeyBBY2NvdW50Q2F0ZWdvcnksIEFjY291bnRDb25maWcgfSBmcm9tICcuL3R5cGVzLmpzJztcclxuXHJcbi8qKlxyXG4gKiBNaW5pbWFsIHBhcnNlciBmb3IgdGhlIHN0cmljdCBzaGFwZSB1c2VkIGJ5IGBjb25maWcvYWNjb3VudHMueWFtbGA6XHJcbiAqXHJcbiAqICAgYWNjb3VudHM6XHJcbiAqICAgICAtIGhhbmRsZTogREhTZ292XHJcbiAqICAgICAgIGxhYmVsOiBEZXBhcnRtZW50IG9mIEhvbWVsYW5kIFNlY3VyaXR5XHJcbiAqICAgICAgIGNhdGVnb3J5OiBjb3JlXHJcbiAqXHJcbiAqIFdlIGRlbGliZXJhdGVseSBkb24ndCBwdWxsIGluIGEgZnVsbCBZQU1MIGxpYnJhcnkgXHUyMDE0IHdlIGNvbnRyb2wgYm90aCBlbmRzIG9mXHJcbiAqIHRoaXMgZmlsZSwgYW5kIGEgc21hbGwgcGFyc2VyIGlzIGVhc2llciB0byBhdWRpdCB0aGFuIHRoZSBhbHRlcm5hdGl2ZXMuXHJcbiAqIFVua25vd24ga2V5cyBhbmQgY29tbWVudHMgYXJlIHRvbGVyYXRlZDsgbWFsZm9ybWVkIGxpbmVzIGFyZSBza2lwcGVkLlxyXG4gKlxyXG4gKiBFbnRyaWVzIG1pc3NpbmcgYSBgY2F0ZWdvcnlgIGRlZmF1bHQgdG8gYGNvcmVgIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XHJcbiAqIHdpdGggdGhlIHByZS1jYXRlZ29yaXphdGlvbiBmaWxlIHNoYXBlLlxyXG4gKi9cclxuY29uc3QgVkFMSURfQ0FURUdPUklFUzogUmVhZG9ubHlTZXQ8QWNjb3VudENhdGVnb3J5PiA9IG5ldyBTZXQoW1xyXG4gICdjb3JlJyxcclxuICAnZ292ZXJubWVudCcsXHJcbiAgJ29mZmljaWFscycsXHJcbiAgJ3B1YmxpY19maWd1cmVzJyxcclxuICAncHVibGljJyxcclxuXSk7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VBY2NvdW50c1lhbWwodGV4dDogc3RyaW5nKTogQWNjb3VudENvbmZpZ1tdIHtcclxuICBjb25zdCBhY2NvdW50czogQWNjb3VudENvbmZpZ1tdID0gW107XHJcbiAgbGV0IGN1cnJlbnQ6IFBhcnRpYWw8QWNjb3VudENvbmZpZz4gPSB7fTtcclxuICBsZXQgaW5BY2NvdW50cyA9IGZhbHNlO1xyXG4gIGNvbnN0IGZsdXNoID0gKCkgPT4ge1xyXG4gICAgaWYgKGN1cnJlbnQuaGFuZGxlICYmIGN1cnJlbnQubGFiZWwpIHtcclxuICAgICAgaWYgKCFjdXJyZW50LmNhdGVnb3J5KSBjdXJyZW50LmNhdGVnb3J5ID0gJ2NvcmUnO1xyXG4gICAgICBhY2NvdW50cy5wdXNoKGN1cnJlbnQgYXMgQWNjb3VudENvbmZpZyk7XHJcbiAgICB9XHJcbiAgfTtcclxuICBmb3IgKGNvbnN0IHJhd0xpbmUgb2YgdGV4dC5zcGxpdCgnXFxuJykpIHtcclxuICAgIGNvbnN0IGxpbmUgPSBzdHJpcENvbW1lbnRzKHJhd0xpbmUpO1xyXG4gICAgaWYgKGxpbmUudHJpbSgpID09PSAnJykgY29udGludWU7XHJcbiAgICBpZiAoL15hY2NvdW50c1xccyo6Ly50ZXN0KGxpbmUpKSB7XHJcbiAgICAgIGluQWNjb3VudHMgPSB0cnVlO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGlmICghaW5BY2NvdW50cykgY29udGludWU7XHJcblxyXG4gICAgY29uc3QgaXRlbU1hdGNoID0gbGluZS5tYXRjaCgvXlxccyotXFxzKmhhbmRsZVxccyo6XFxzKiguKykkLyk7XHJcbiAgICBpZiAoaXRlbU1hdGNoKSB7XHJcbiAgICAgIGZsdXNoKCk7XHJcbiAgICAgIGN1cnJlbnQgPSB7IGhhbmRsZTogdW5xdW90ZShpdGVtTWF0Y2hbMV0gPz8gJycpIH07XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgY29uc3QgaGFuZGxlT25seSA9IGxpbmUubWF0Y2goL15cXHMqaGFuZGxlXFxzKjpcXHMqKC4rKSQvKTtcclxuICAgIGlmIChoYW5kbGVPbmx5ICYmICFsaW5lLmluY2x1ZGVzKCctJykpIHtcclxuICAgICAgZmx1c2goKTtcclxuICAgICAgY3VycmVudCA9IHsgaGFuZGxlOiB1bnF1b3RlKGhhbmRsZU9ubHlbMV0gPz8gJycpIH07XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgY29uc3QgbGFiZWxNYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqbGFiZWxcXHMqOlxccyooLispJC8pO1xyXG4gICAgaWYgKGxhYmVsTWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcclxuICAgICAgY3VycmVudC5sYWJlbCA9IHVucXVvdGUobGFiZWxNYXRjaFsxXSA/PyAnJyk7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgY29uc3QgY2F0ZWdvcnlNYXRjaCA9IGxpbmUubWF0Y2goL15cXHMqY2F0ZWdvcnlcXHMqOlxccyooLispJC8pO1xyXG4gICAgaWYgKGNhdGVnb3J5TWF0Y2ggJiYgY3VycmVudC5oYW5kbGUpIHtcclxuICAgICAgY29uc3QgcmF3ID0gdW5xdW90ZShjYXRlZ29yeU1hdGNoWzFdID8/ICcnKTtcclxuICAgICAgY3VycmVudC5jYXRlZ29yeSA9IFZBTElEX0NBVEVHT1JJRVMuaGFzKHJhdyBhcyBBY2NvdW50Q2F0ZWdvcnkpXHJcbiAgICAgICAgPyAocmF3IGFzIEFjY291bnRDYXRlZ29yeSlcclxuICAgICAgICA6ICdjb3JlJztcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGZsdXNoKCk7XHJcbiAgcmV0dXJuIGFjY291bnRzLmZpbHRlcigoYSkgPT4gYS5oYW5kbGUubGVuZ3RoID4gMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHN0cmlwQ29tbWVudHMobGluZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICAvLyBOYWl2ZSBidXQgYWRlcXVhdGUgZm9yIG91ciBmb3JtYXQ6IHN0cmlwIGV2ZXJ5dGhpbmcgYWZ0ZXIgYSBgI2AgdGhhdCBpc24ndFxyXG4gIC8vIGluc2lkZSBxdW90ZXMuIE91ciBjb25maWcgbmV2ZXIgdXNlcyBpbmxpbmUgc3RyaW5ncyB3aXRoIGAjYC5cclxuICBjb25zdCBpZHggPSBsaW5lLmluZGV4T2YoJyMnKTtcclxuICByZXR1cm4gaWR4ID09PSAtMSA/IGxpbmUgOiBsaW5lLnNsaWNlKDAsIGlkeCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHVucXVvdGUoczogc3RyaW5nKTogc3RyaW5nIHtcclxuICBjb25zdCB0cmltbWVkID0gcy50cmltKCk7XHJcbiAgaWYgKFxyXG4gICAgKHRyaW1tZWQuc3RhcnRzV2l0aCgnXCInKSAmJiB0cmltbWVkLmVuZHNXaXRoKCdcIicpKSB8fFxyXG4gICAgKHRyaW1tZWQuc3RhcnRzV2l0aChcIidcIikgJiYgdHJpbW1lZC5lbmRzV2l0aChcIidcIikpXHJcbiAgKSB7XHJcbiAgICByZXR1cm4gdHJpbW1lZC5zbGljZSgxLCAtMSk7XHJcbiAgfVxyXG4gIHJldHVybiB0cmltbWVkO1xyXG59XHJcbiIsICIvKipcclxuICogYmFja2dyb3VuZC50cyBcdTIwMTQgZXh0ZW5zaW9uIHNlcnZpY2Ugd29ya2VyLlxyXG4gKlxyXG4gKiBPd25zIHRoZSBjYXB0dXJlIHBpcGVsaW5lOiByZWNlaXZlcyBgZ3JhcGhxbC1jYXB0dXJlYCBtZXNzYWdlcyBmcm9tIHRoZVxyXG4gKiBjb250ZW50IHNjcmlwdCwgbm9ybWFsaXplcyB0aGVtLCBhY2N1bXVsYXRlcyBwZXItaGFuZGxlIHJ1biBidWZmZXJzIGluXHJcbiAqIGBicm93c2VyLnN0b3JhZ2UubG9jYWxgLCBhbmQgY29tbWl0cyB0aGVtIHRvIHRoZSBjb25maWd1cmVkIEdpdEh1YiByZXBvXHJcbiAqIHZpYSB0aGUgR2l0IERhdGEgQVBJLlxyXG4gKlxyXG4gKiBTZXJ2aWNlIHdvcmtlcnMgaW4gTVYzIG1heSBiZSBldmljdGVkIGF0IGFueSB0aW1lLCBzbyBhbGwgY3JpdGljYWwgc3RhdGVcclxuICogbGl2ZXMgaW4gc3RvcmFnZSAobmV2ZXIgbW9kdWxlLXNjb3BlKS4gT24gZXZlcnkgd2FrZSB3ZSByZS1kZXJpdmUgd2hhdCB3ZVxyXG4gKiBuZWVkOyBwZW5kaW5nIGZsdXNoZXMgYXJlIGRyaXZlbiBieSBgYnJvd3Nlci5hbGFybXNgIHJhdGhlciB0aGFuIHRpbWVycy5cclxuICovXHJcblxyXG5pbXBvcnQge1xyXG4gIEFVVE9fU0NST0xMX01BWF9TRUMsXHJcbiAgQVVUT19TQ1JPTExfTUlOX1NFQyxcclxuICBGQUxMQkFDS19BQ0NPVU5UUyxcclxuICBGTFVTSF9BTEFSTV9NSU5VVEVTLFxyXG4gIEZMVVNIX0lETEVfTVMsXHJcbiAgRkxVU0hfVFdFRVRfVEhSRVNIT0xELFxyXG4gIFBST0ZJTEVfRU5EUE9JTlRTLFxyXG4gIFRXRUVUX0VORFBPSU5UUyxcclxuICBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUyxcclxufSBmcm9tICcuL2xpYi9jb25maWcuanMnO1xyXG5pbXBvcnQgeyBHaXRIdWJDbGllbnQsIEdpdEh1YkVycm9yLCB0b0Jhc2U2NCB9IGZyb20gJy4vbGliL2dpdGh1Yi5qcyc7XHJcbmltcG9ydCB7IGRlc2NyaWJlRXJyb3IsIGVycm9yIGFzIGxvZ0VyciwgaW5mbywgc2V0QnJvYWRjYXN0ZXIsIHdhcm4gfSBmcm9tICcuL2xpYi9sb2dnZXIuanMnO1xyXG5pbXBvcnQgeyBmaWx0ZXJSZWxhdGVkLCBub3JtYWxpemUgfSBmcm9tICcuL2xpYi9ub3JtYWxpemUuanMnO1xyXG5pbXBvcnQgeyBuZXdSdW5JZCwgc2hvcnRSdW5JZCB9IGZyb20gJy4vbGliL3J1bmlkcy5qcyc7XHJcbmltcG9ydCB7XHJcbiAgYnVtcENvdW50ZXIsXHJcbiAgY2xlYXJBY3Rpdml0eSxcclxuICBjbGVhckFsbCxcclxuICBjbGVhclJ1bkJ1ZmZlcixcclxuICBkZXF1ZXVlTWVkaWFDcmF3bCxcclxuICBkZXF1ZXVlUmVmZXRjaCxcclxuICBkZXF1ZXVlVGhyZWFkT3BlbixcclxuICBlbmdhZ2VtZW50U2lnLFxyXG4gIGVucXVldWVNZWRpYUNyYXdsLFxyXG4gIGVucXVldWVSZWZldGNoLFxyXG4gIGVucXVldWVUaHJlYWRPcGVuLFxyXG4gIGdldEFjY291bnRzLFxyXG4gIGdldEFjY291bnRzUmVmcmVzaGVkQXQsXHJcbiAgZ2V0QWN0aXZpdHksXHJcbiAgZ2V0QXJjaGl2ZVNuYXBzaG90LFxyXG4gIGdldEF1dG9TY3JvbGxTZXNzaW9uLFxyXG4gIGdldENvbW1pdHRlZEluZGV4LFxyXG4gIGdldENvbm5lY3Rpb24sXHJcbiAgZ2V0Q291bnRlcnMsXHJcbiAgZ2V0TWVkaWFDcmF3bFF1ZXVlLFxyXG4gIGdldE1lZGlhQ3Jhd2xTZXNzaW9uLFxyXG4gIGdldFJlZmV0Y2hRdWV1ZSxcclxuICBnZXRSZWZldGNoU2Vzc2lvbixcclxuICBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncyxcclxuICBnZXRSdW5CdWZmZXIsXHJcbiAgZ2V0UnVuQnVmZmVycyxcclxuICBnZXRTZXR0aW5ncyxcclxuICBnZXRUaHJlYWRPcGVuUXVldWUsXHJcbiAgZ2V0VGhyZWFkT3BlblNlc3Npb24sXHJcbiAgaGFzVGhyZWFkT3BlblNlZW4sXHJcbiAgaXNDb21taXR0ZWQsXHJcbiAgbWFya1RocmVhZE9wZW5TZWVuLFxyXG4gIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsLFxyXG4gIG5leHRNZWRpYUNyYXdsVGFyZ2V0LFxyXG4gIG5leHRSZWZldGNoVGFyZ2V0LFxyXG4gIG5leHRUaHJlYWRPcGVuVGFyZ2V0LFxyXG4gIHBydW5lQ29tbWl0dGVkSW5kZXgsXHJcbiAgcHVyZ2VVbnJlbGF0ZWRTdGF0ZSxcclxuICByZWZldGNoUXVldWVUb3RhbCxcclxuICBwcmVwZW5kUmVjZW50VHdlZXRTaWdodGluZ3MsXHJcbiAgc2V0QWNjb3VudHMsXHJcbiAgc2V0QWNjb3VudHNSZWZyZXNoZWRBdCxcclxuICBzZXRBcmNoaXZlU25hcHNob3QsXHJcbiAgc2V0QXV0b1Njcm9sbFNlc3Npb24sXHJcbiAgc2V0QnVmZmVyZWRDb3VudCxcclxuICBzZXRDb21taXR0ZWRJbmRleCxcclxuICBzZXRDb25uZWN0aW9uLFxyXG4gIHNldE1lZGlhQ3Jhd2xTZXNzaW9uLFxyXG4gIHNldFJlZmV0Y2hTZXNzaW9uLFxyXG4gIHNldFJ1bkJ1ZmZlcixcclxuICBzZXRUaHJlYWRPcGVuU2Vzc2lvbixcclxuICB0aHJlYWRPcGVuUXVldWVUb3RhbCxcclxuICB0eXBlIFJ1bkJ1ZmZlcixcclxuICB1cGRhdGVTZXR0aW5ncyxcclxufSBmcm9tICcuL2xpYi9zdG9yYWdlLmpzJztcclxuaW1wb3J0IHR5cGUge1xyXG4gIENhbm9uaWNhbFR3ZWV0LFxyXG4gIENhcHR1cmVQYXlsb2FkLFxyXG4gIEFyY2hpdmVTbmFwc2hvdCxcclxuICBDb25uZWN0aW9uU3RhdGUsXHJcbiAgRXh0ZW5zaW9uU3RhdGUsXHJcbiAgTG9nRXZlbnQsXHJcbiAgUXVhcmFudGluZVBheWxvYWQsXHJcbiAgUmV0d2VldEVkZ2UsXHJcbiAgUnVudGltZU1lc3NhZ2UsXHJcbiAgU2VlblBheWxvYWQsXHJcbiAgU2V0dGluZ3MsXHJcbiAgVHdlZXRTaWdodGluZyxcclxuICBVbmF2YWlsYWJsZVR3ZWV0LFxyXG59IGZyb20gJy4vbGliL3R5cGVzLmpzJztcclxuaW1wb3J0IHsgcGFyc2VBY2NvdW50c1lhbWwgfSBmcm9tICcuL2xpYi95YW1sLmpzJztcclxuXHJcbmNvbnN0IEVYVF9WRVJTSU9OID0gYnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbjtcbmNvbnN0IE1BTlVBTF9DQVBUVVJFX1dJTkRPV19NUyA9IDkwXzAwMDtcbmNvbnN0IExPV19CQU5EV0lEVEhfQkFTRV9SVUxFX0lEID0gNzYwXzAwMTtcbmNvbnN0IExPV19CQU5EV0lEVEhfTUVESUFfUlVMRV9JRF9CQVNFID0gNzYwXzAxMDtcbmNvbnN0IExPV19CQU5EV0lEVEhfUkVTT1VSQ0VfVFlQRVMgPSBbJ2ltYWdlJywgJ21lZGlhJywgJ2ZvbnQnXSBhcyBjb25zdDtcbmNvbnN0IExPV19CQU5EV0lEVEhfTUVESUFfQ0hVTktfUkVTT1VSQ0VfVFlQRVMgPSBbJ21lZGlhJywgJ3htbGh0dHByZXF1ZXN0JywgJ290aGVyJ10gYXMgY29uc3Q7XG5jb25zdCBMT1dfQkFORFdJRFRIX01FRElBX1VSTF9GSUxURVJTID0gW1xuICAnfHx2aWRlby50d2ltZy5jb21eJyxcbiAgJ3x8dG9uLnR3aW1nLmNvbV4nLFxuICAnfHxhbXAudHdpbWcuY29tXicsXG4gICd8fHZpZGVvLnBzY3AudHZeJyxcbiAgJ3x8cHJvZC1mYXN0bHktdXMtd2VzdC0xLnZpZGVvLnBzY3AudHZeJyxcbiAgJ3xodHRwczovL3guY29tL2kvdmlkZW9zLycsXG4gICd8aHR0cHM6Ly90d2l0dGVyLmNvbS9pL3ZpZGVvcy8nLFxuXSBhcyBjb25zdDtcbmxldCBtYW51YWxDYXB0dXJlVW50aWxNcyA9IDA7XG5cbnR5cGUgTG93QmFuZHdpZHRoUmVzb3VyY2VUeXBlID1cbiAgfCAodHlwZW9mIExPV19CQU5EV0lEVEhfUkVTT1VSQ0VfVFlQRVMpW251bWJlcl1cbiAgfCAodHlwZW9mIExPV19CQU5EV0lEVEhfTUVESUFfQ0hVTktfUkVTT1VSQ0VfVFlQRVMpW251bWJlcl07XG5cbmludGVyZmFjZSBMb3dCYW5kd2lkdGhSdWxlIHtcbiAgaWQ6IG51bWJlcjtcbiAgcHJpb3JpdHk6IG51bWJlcjtcbiAgYWN0aW9uOiB7IHR5cGU6ICdibG9jaycgfTtcbiAgY29uZGl0aW9uOiB7XG4gICAgdGFiSWRzOiBudW1iZXJbXTtcbiAgICByZXNvdXJjZVR5cGVzOiBMb3dCYW5kd2lkdGhSZXNvdXJjZVR5cGVbXTtcbiAgICB1cmxGaWx0ZXI/OiBzdHJpbmc7XG4gIH07XG59XG5cbmludGVyZmFjZSBEZWNsYXJhdGl2ZU5ldFJlcXVlc3RBcGkge1xuICB1cGRhdGVTZXNzaW9uUnVsZXModXBkYXRlOiB7XG4gICAgYWRkUnVsZXM/OiBMb3dCYW5kd2lkdGhSdWxlW107XG4gICAgcmVtb3ZlUnVsZUlkcz86IG51bWJlcltdO1xuICB9KTogUHJvbWlzZTx2b2lkPjtcbn1cblxyXG5zZXRCcm9hZGNhc3RlcigoZXY6IExvZ0V2ZW50KSA9PiB7XHJcbiAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2xvZy1ldmVudCcsIGV2ZW50OiBldiB9KS5jYXRjaCgoKSA9PiB7fSk7XHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk6IHZvaWQge1xyXG4gIG1hbnVhbENhcHR1cmVVbnRpbE1zID0gRGF0ZS5ub3coKSArIE1BTlVBTF9DQVBUVVJFX1dJTkRPV19NUztcclxufVxyXG5cclxuLy8gLS0tIFdha2UgaGFuZGxlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmJyb3dzZXIucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcihhc3luYyAoKSA9PiB7XHJcbiAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIGluc3RhbGxlZCcsIHsgdmVyc2lvbjogRVhUX1ZFUlNJT04gfSk7XHJcbiAgYXdhaXQgb25XYWtlKCdpbnN0YWxsJyk7XHJcbn0pO1xyXG5cclxuYnJvd3Nlci5ydW50aW1lLm9uU3RhcnR1cC5hZGRMaXN0ZW5lcigoKSA9PiB7XHJcbiAgdm9pZCBvbldha2UoJ3N0YXJ0dXAnKTtcclxufSk7XHJcblxyXG4vLyBGb3JjZSBhdCBsZWFzdCBvbmUgd2FrZSB0byByZWdpc3RlciBhbGFybXMgLyB2ZXJpZnkgY29ubmVjdGlvbi5cclxudm9pZCBvbldha2UoJ21vZHVsZS1sb2FkJyk7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBvbldha2UocmVhc29uOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBlbnN1cmVBbGFybXMoKTtcbiAgICBhd2FpdCBlbnN1cmVBdXRvU2Nyb2xsQWxhcm0oKTtcbiAgICBhd2FpdCBzeW5jTG93QmFuZHdpZHRoUnVsZXMoeyByZWFzb246IGB3YWtlOiR7cmVhc29ufWAsIGxvZzogZmFsc2UgfSk7XG4gICAgYXdhaXQgZmx1c2hPcnBoYW5lZEJ1ZmZlcnNJZlN0YWxlKCk7XG4gICAgYXdhaXQgcmVpbmplY3RJbnRvT3BlblRhYnMoKTtcclxuICAgIC8vIERyb3AgZGVkdXAtaW5kZXggZW50cmllcyBvbGRlciB0aGFuIDMwIGRheXMgc28gdGhlIHN0b3JlIGRvZXNuJ3RcclxuICAgIC8vIGdyb3cgdW5ib3VuZGVkIG92ZXIgbW9udGhzIG9mIGNhcHR1cmUgc2Vzc2lvbnMuXHJcbiAgICBjb25zdCBwcnVuZWQgPSBhd2FpdCBwcnVuZUNvbW1pdHRlZEluZGV4KDMwICogMjQgKiA2MCAqIDYwICogMTAwMCk7XHJcbiAgICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgaW5mbygncHJ1bmVkIGNvbW1pdHRlZCBpbmRleCcsIHsgcHJ1bmVkIH0pO1xyXG4gICAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gICAgaWYgKHNldHRpbmdzLnBhdCAmJiBzZXR0aW5ncy5vd25lciAmJiBzZXR0aW5ncy5yZXBvKSB7XHJcbiAgICAgIGF3YWl0IHZlcmlmeUNvbm5lY3Rpb24oZmFsc2UpO1xyXG4gICAgICBhd2FpdCByZWZyZXNoQWNjb3VudHNMaXN0KGZhbHNlKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xyXG4gICAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcclxuICAgICAgICBsb2dpbjogbnVsbCxcclxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBudWxsLFxyXG4gICAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXHJcbiAgICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcclxuICAgICAgfSk7XHJcbiAgICAgIGF3YWl0IGluZm8oJ2V4dGVuc2lvbiBhd2FrZTsgc2V0dGluZ3MgaW5jb21wbGV0ZScsIHsgcmVhc29uIH0pO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgYXdhaXQgbG9nRXJyKCd3YWtlIGZhaWxlZCcsIHsgcmVhc29uLCAuLi5kZXNjcmliZUVycm9yKGVycikgfSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZG5yQXBpKCk6IERlY2xhcmF0aXZlTmV0UmVxdWVzdEFwaSB8IG51bGwge1xuICBjb25zdCBtYXliZUJyb3dzZXIgPSBicm93c2VyIGFzIHVua25vd24gYXMge1xuICAgIGRlY2xhcmF0aXZlTmV0UmVxdWVzdD86IERlY2xhcmF0aXZlTmV0UmVxdWVzdEFwaTtcbiAgfTtcbiAgcmV0dXJuIG1heWJlQnJvd3Nlci5kZWNsYXJhdGl2ZU5ldFJlcXVlc3QgPz8gbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY3VycmVudFhUYWJJZHMoKTogUHJvbWlzZTxudW1iZXJbXT4ge1xuICBjb25zdCB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcbiAgcmV0dXJuIHRhYnMuZmxhdE1hcCgodGFiKSA9PiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicgPyBbdGFiLmlkXSA6IFtdKSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN5bmNMb3dCYW5kd2lkdGhSdWxlcyh7XG4gIHJlYXNvbixcbiAgbG9nLFxufToge1xuICByZWFzb246IHN0cmluZztcbiAgbG9nOiBib29sZWFuO1xufSk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IGdldFNldHRpbmdzKCk7XG4gIGNvbnN0IGRuciA9IGRuckFwaSgpO1xuICBpZiAoIWRucikge1xuICAgIGlmIChzZXR0aW5ncy5sb3dCYW5kd2lkdGhCcm93c2luZyAmJiBsb2cpIHtcbiAgICAgIGF3YWl0IHdhcm4oJ2xvdy1iYW5kd2lkdGggYnJvd3NpbmcgdW5hdmFpbGFibGU7IGRlY2xhcmF0aXZlTmV0UmVxdWVzdCBBUEkgbWlzc2luZycsIHtcbiAgICAgICAgcmVhc29uLFxuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuXG4gIGNvbnN0IHRhYklkcyA9IHNldHRpbmdzLmxvd0JhbmR3aWR0aEJyb3dzaW5nID8gYXdhaXQgY3VycmVudFhUYWJJZHMoKSA6IFtdO1xuICBjb25zdCByZW1vdmVSdWxlSWRzID0gW1xuICAgIExPV19CQU5EV0lEVEhfQkFTRV9SVUxFX0lELFxuICAgIC4uLkxPV19CQU5EV0lEVEhfTUVESUFfVVJMX0ZJTFRFUlMubWFwKChfLCBpZHgpID0+IExPV19CQU5EV0lEVEhfTUVESUFfUlVMRV9JRF9CQVNFICsgaWR4KSxcbiAgXTtcbiAgY29uc3QgYWRkUnVsZXM6IExvd0JhbmR3aWR0aFJ1bGVbXSA9XG4gICAgdGFiSWRzLmxlbmd0aCA+IDBcbiAgICAgID8gW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiBMT1dfQkFORFdJRFRIX0JBU0VfUlVMRV9JRCxcbiAgICAgICAgICAgIHByaW9yaXR5OiAxLFxuICAgICAgICAgICAgYWN0aW9uOiB7IHR5cGU6ICdibG9jaycgfSxcbiAgICAgICAgICAgIGNvbmRpdGlvbjoge1xuICAgICAgICAgICAgICB0YWJJZHMsXG4gICAgICAgICAgICAgIHJlc291cmNlVHlwZXM6IFsuLi5MT1dfQkFORFdJRFRIX1JFU09VUkNFX1RZUEVTXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICAuLi5MT1dfQkFORFdJRFRIX01FRElBX1VSTF9GSUxURVJTLm1hcCgodXJsRmlsdGVyLCBpZHgpID0+ICh7XG4gICAgICAgICAgICBpZDogTE9XX0JBTkRXSURUSF9NRURJQV9SVUxFX0lEX0JBU0UgKyBpZHgsXG4gICAgICAgICAgICBwcmlvcml0eTogMixcbiAgICAgICAgICAgIGFjdGlvbjogeyB0eXBlOiAnYmxvY2snIGFzIGNvbnN0IH0sXG4gICAgICAgICAgICBjb25kaXRpb246IHtcbiAgICAgICAgICAgICAgdGFiSWRzLFxuICAgICAgICAgICAgICB1cmxGaWx0ZXIsXG4gICAgICAgICAgICAgIHJlc291cmNlVHlwZXM6IFsuLi5MT1dfQkFORFdJRFRIX01FRElBX0NIVU5LX1JFU09VUkNFX1RZUEVTXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSkpLFxuICAgICAgICBdXG4gICAgICA6IFtdO1xuICBhd2FpdCBkbnIudXBkYXRlU2Vzc2lvblJ1bGVzKHtcbiAgICByZW1vdmVSdWxlSWRzLFxuICAgIGFkZFJ1bGVzLFxuICB9KTtcblxuICBpZiAobG9nKSB7XG4gICAgYXdhaXQgaW5mbygnbG93LWJhbmR3aWR0aCBicm93c2luZyBydWxlcyB1cGRhdGVkJywge1xuICAgICAgZW5hYmxlZDogc2V0dGluZ3MubG93QmFuZHdpZHRoQnJvd3NpbmcsXG4gICAgICB0YWJfY291bnQ6IHRhYklkcy5sZW5ndGgsXG4gICAgICBibG9ja2VkX3Jlc291cmNlX3R5cGVzOiBMT1dfQkFORFdJRFRIX1JFU09VUkNFX1RZUEVTLmpvaW4oJywnKSxcbiAgICAgIGJsb2NrZWRfbWVkaWFfZmlsdGVyczogTE9XX0JBTkRXSURUSF9NRURJQV9VUkxfRklMVEVSUy5qb2luKCcsJyksXG4gICAgICByZWFzb24sXG4gICAgfSk7XG4gIH1cbn1cblxuYnJvd3Nlci50YWJzLm9uVXBkYXRlZC5hZGRMaXN0ZW5lcigoX3RhYklkLCBjaGFuZ2VJbmZvKSA9PiB7XG4gIGlmIChjaGFuZ2VJbmZvLnVybCB8fCBjaGFuZ2VJbmZvLnN0YXR1cyA9PT0gJ2NvbXBsZXRlJykge1xuICAgIHZvaWQgc3luY0xvd0JhbmR3aWR0aFJ1bGVzKHsgcmVhc29uOiAndGFiLXVwZGF0ZWQnLCBsb2c6IGZhbHNlIH0pLmNhdGNoKChlcnIpID0+IHtcbiAgICAgIHZvaWQgd2FybignbG93LWJhbmR3aWR0aCBydWxlIHJlZnJlc2ggZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcbiAgICB9KTtcbiAgfVxufSk7XG5cbmJyb3dzZXIudGFicy5vblJlbW92ZWQuYWRkTGlzdGVuZXIoKCkgPT4ge1xuICB2b2lkIHN5bmNMb3dCYW5kd2lkdGhSdWxlcyh7IHJlYXNvbjogJ3RhYi1yZW1vdmVkJywgbG9nOiBmYWxzZSB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgdm9pZCB3YXJuKCdsb3ctYmFuZHdpZHRoIHJ1bGUgcmVmcmVzaCBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xuICB9KTtcbn0pO1xuXG4vKipcbiAqIFJlLWluamVjdCB0aGUgTUFJTi13b3JsZCBwYWdlLWhvb2sgKyBpc29sYXRlZC13b3JsZCBjb250ZW50IHNjcmlwdCBpbnRvXG4gKiBldmVyeSBhbHJlYWR5LW9wZW4geC5jb20gLyB0d2l0dGVyLmNvbSB0YWIuXHJcbiAqXHJcbiAqIE1hbmlmZXN0IGNvbnRlbnRfc2NyaXB0cyBvbmx5IGluamVjdCBvbiBmcmVzaCBuYXZpZ2F0aW9uIChydW5fYXQ6XHJcbiAqIGRvY3VtZW50X3N0YXJ0KS4gV2hlbiB0aGUgdXNlciByZWxvYWRzIHRoZSBleHRlbnNpb24gd2hpbGUgWCB0YWJzIGFyZVxyXG4gKiBvcGVuLCB0aG9zZSB0YWJzIGtlZXAgdGhlaXIgY29udGVudCBzY3JpcHRzIGJ1dCBuZXZlciBnZXQgYSBuZXcgcGFnZS1ob29rXHJcbiAqIFx1MjAxNCBzbyBmZXRjaC9YSFIgc3RheXMgdW5wYXRjaGVkIGFuZCBjYXB0dXJlcyBzaWxlbnRseSBmYWlsLiBEb2luZyB0aGlzIG9uXHJcbiAqIGV2ZXJ5IHdha2UgaXMgaWRlbXBvdGVudCAocGFnZS1ob29rIGhhcyBhIFRBRyBndWFyZCkgYW5kIGNoZWFwLlxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gcmVpbmplY3RJbnRvT3BlblRhYnMoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcclxuICB0cnkge1xyXG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdjb3VsZCBub3QgcXVlcnkgb3BlbiB0YWJzJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgaWYgKHRhYnMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcbiAgZm9yIChjb25zdCB0YWIgb2YgdGFicykge1xyXG4gICAgaWYgKHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInKSBjb250aW51ZTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXHJcbiAgICAgICAgZmlsZXM6IFsncGFnZS1ob29rLmpzJ10sXHJcbiAgICAgICAgLy8gRmlyZWZveCAxMjgrIHN1cHBvcnRzIHRoZSBNQUlOIGV4ZWN1dGlvbiB3b3JsZCB2aWEgdGhpcyBBUEksIGJ1dFxyXG4gICAgICAgIC8vIHRoZSBAdHlwZXMvZmlyZWZveC13ZWJleHQtYnJvd3NlciBwYWNrYWdlIHdlJ3JlIG9uIHN0aWxsIG9ubHlcclxuICAgICAgICAvLyBkZWNsYXJlcyAnSVNPTEFURUQnLiBDYXN0IHRocm91Z2ggdGhlIGxpdGVyYWwgdW5pb24uXHJcbiAgICAgICAgd29ybGQ6ICdNQUlOJyBhcyAnSVNPTEFURUQnLFxyXG4gICAgICB9KTtcclxuICAgICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XHJcbiAgICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcclxuICAgICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXHJcbiAgICAgIH0pO1xyXG4gICAgICBhd2FpdCBpbmZvKCdyZS1pbmplY3RlZCBzY3JpcHRzIGludG8gb3BlbiB0YWInLCB7XHJcbiAgICAgICAgdGFiSWQ6IHRhYi5pZCxcclxuICAgICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCA/PyAnJyksXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIC8vIFNvbWUgdGFicyAoYWJvdXQ6IHBhZ2VzLCBkaXNjYXJkZWQgdGFicywgbWlkLW5hdmlnYXRpb24pIHJlamVjdFxyXG4gICAgICAvLyBleGVjdXRlU2NyaXB0LiBUaGF0J3MgZmluZSBcdTIwMTQgd2UnbGwgY2F0Y2ggdGhlbSBvbiB0aGUgbmV4dCB3YWtlIG9yXHJcbiAgICAgIC8vIHdoZW4gdGhlIHVzZXIgbmF2aWdhdGVzLlxyXG4gICAgICBhd2FpdCB3YXJuKCdyZS1pbmplY3QgZmFpbGVkIGZvciB0YWI7IGNvbnRpbnVpbmcnLCB7XHJcbiAgICAgICAgdGFiSWQ6IHRhYi5pZCxcclxuICAgICAgICB1cmw6IHNob3J0ZW5VcmwodGFiLnVybCA/PyAnJyksXHJcbiAgICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGVuc3VyZUFsYXJtcygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignZmx1c2gtc3dlZXAnKTtcclxuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcigndmVyaWZ5LWNvbm5lY3Rpb24nKTtcclxuICBhd2FpdCBicm93c2VyLmFsYXJtcy5jcmVhdGUoJ2ZsdXNoLXN3ZWVwJywgeyBwZXJpb2RJbk1pbnV0ZXM6IEZMVVNIX0FMQVJNX01JTlVURVMgfSk7XHJcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY3JlYXRlKCd2ZXJpZnktY29ubmVjdGlvbicsIHtcclxuICAgIHBlcmlvZEluTWludXRlczogVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgLyA2MF8wMDAsXHJcbiAgfSk7XHJcbn1cclxuXHJcbi8vIEZpcmVmb3ggTVYzIGFsYXJtcyBoYXZlIGEgMzBzIG1pbmltdW0gcGVyaW9kLCBidXQgd2Ugd2FudCBzdWItbWludXRlXHJcbi8vIHNjcm9sbGluZy4gVGhlIGF1dG8tc2Nyb2xsIGxvb3AgdGhlcmVmb3JlIHJ1bnMgb24gYW4gaW4tU1cgaW50ZXJ2YWwuXHJcbi8vIGBhdXRvU2Nyb2xsU2Vzc2lvbmAgaW4gc3RvcmFnZSBpcyB0aGUgc291cmNlIG9mIHRydXRoIGZvciB3aGV0aGVyIHRoZSBsb29wXHJcbi8vIGlzIG1lYW50IHRvIGJlIHJ1bm5pbmcgXHUyMDE0IHRoZSB0aW1lciBpcyBqdXN0IHRoZSBsb2NhbCBleGVjdXRpb24gYXJtLlxyXG5sZXQgYXV0b1Njcm9sbFRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcclxuY29uc3QgU0hPV19NT1JFX1JFTEVWQU5DRV9UVExfTVMgPSAxMCAqIDYwICogMTAwMDtcclxuaW50ZXJmYWNlIFRhYlJlbGV2YW50VHdlZXRzIHtcclxuICB1cGRhdGVkQXQ6IG51bWJlcjtcclxuICBwYWdlVXJsOiBzdHJpbmcgfCBudWxsO1xyXG4gIHR3ZWV0SWRzOiBTZXQ8c3RyaW5nPjtcclxufVxyXG5jb25zdCBzaG93TW9yZVJlbGV2YW50VHdlZXRzQnlUYWIgPSBuZXcgTWFwPG51bWJlciwgVGFiUmVsZXZhbnRUd2VldHM+KCk7XHJcblxyXG4vLyBXYWl0LWZvci1pbmdlc3QgdGltZW91dDogaWYgYSByZWZldGNoIC8gbWVkaWEtY3Jhd2wgdGFiIG5hdmlnYXRpb24gZG9lc24ndFxyXG4vLyBwcm9kdWNlIGFuIGluZ2VzdGVkIGNhcHR1cmUgd2l0aGluIHRoaXMgbWFueSBtcywgYWR2YW5jZSBhbnl3YXkgc28gd2VcclxuLy8gZG9uJ3QgZGVhZGxvY2sgb24gZGVsZXRlZCAvIDQwNCAvIHBheXdhbGxlZCB0d2VldHMuXHJcbmNvbnN0IElOR0VTVF9XQUlUX01TID0gMjVfMDAwO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlQXV0b1Njcm9sbEFsYXJtKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIC8vIFdhcyB0aGUgbG9vcCBydW5uaW5nIGJlZm9yZSB0aGUgU1cgZXZpY3Rpb24/IFJlLWFybSBpZiBzby5cclxuICBjb25zdCBzZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoc2VzcyAhPT0gbnVsbCAmJiBzLmVuYWJsZWQgIT09IGZhbHNlKSB7XHJcbiAgICBhcm1BdXRvU2Nyb2xsVGltZXIocy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTogdm9pZCB7XHJcbiAgaWYgKGF1dG9TY3JvbGxUaW1lciAhPT0gbnVsbCkge1xyXG4gICAgY2xlYXJJbnRlcnZhbChhdXRvU2Nyb2xsVGltZXIpO1xyXG4gICAgYXV0b1Njcm9sbFRpbWVyID0gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFybUF1dG9TY3JvbGxUaW1lcihpbnRlcnZhbFNlYzogbnVtYmVyKTogdm9pZCB7XHJcbiAgY2xlYXJBdXRvU2Nyb2xsVGltZXIoKTtcclxuICBjb25zdCBjbGFtcGVkID0gTWF0aC5taW4oXHJcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxyXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChpbnRlcnZhbFNlYykpXHJcbiAgKTtcclxuICBhdXRvU2Nyb2xsVGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIGF1dG9TY3JvbGxUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ2F1dG8tc2Nyb2xsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIH0pO1xyXG4gIH0sIGNsYW1wZWQgKiAxMDAwKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc3RhcnRBdXRvU2Nyb2xsTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbih7XHJcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIHNjcm9sbENvdW50OiAwLFxyXG4gICAgaW5nZXN0ZWRDb3VudDogMCxcclxuICAgIGluZ2VzdGVkTmV3Q291bnQ6IDAsXHJcbiAgICBpbmdlc3RlZEV4aXN0aW5nQ291bnQ6IDAsXHJcbiAgICBza2lwcGVkT2xkQ291bnQ6IDAsXHJcbiAgICBleHBhbmRlZENvdW50OiAwLFxyXG4gIH0pO1xyXG4gIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XHJcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBzdGFydGVkJywgeyBpbnRlcnZhbF9zZWM6IHMuYXV0b1Njcm9sbEludGVydmFsU2VjIH0pO1xyXG4gIC8vIEZpcmUgb25lIGltbWVkaWF0ZSB0aWNrIHNvIHRoZSB1c2VyIHNlZXMgbW90aW9uIHJpZ2h0IGF3YXkuXHJcbiAgdm9pZCBhdXRvU2Nyb2xsVGljaygpO1xyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbEF1dG9TY3JvbGxMb29wKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNsZWFyQXV0b1Njcm9sbFRpbWVyKCk7XHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24obnVsbCk7XHJcbiAgYXdhaXQgaW5mbygnYXV0by1zY3JvbGwgbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBzY3JvbGxzOiBzZXNzPy5zY3JvbGxDb3VudCA/PyAwLFxyXG4gICAgaW5nZXN0ZWQ6IHNlc3M/LmluZ2VzdGVkQ291bnQgPz8gMCxcclxuICAgIGV4cGFuZGVkOiBzZXNzPy5leHBhbmRlZENvdW50ID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gYXV0b1Njcm9sbFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcclxuICB0cnkge1xyXG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IHVybDogWydodHRwczovL3guY29tLyonLCAnaHR0cHM6Ly90d2l0dGVyLmNvbS8qJ10gfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdhdXRvLXNjcm9sbDogdGFiIHF1ZXJ5IGZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxuICBpZiAodGFicy5sZW5ndGggPT09IDApIHJldHVybjtcbiAgbGV0IHNjcm9sbENvdW50ID0gMDtcbiAgbGV0IHJldHJ5Q291bnQgPSAwO1xuICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XHJcbiAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHRhYi5kaXNjYXJkZWQpIGNvbnRpbnVlO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzdWx0cyA9IChhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcclxuICAgICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxuICAgICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXG4gICAgICAgIGZ1bmM6ICgoKSA9PiB7XG4gICAgICAgICAgY29uc3Qgbm9ybWFsaXplZFRleHQgPSAoZWw6IEVsZW1lbnQpOiBzdHJpbmcgPT5cbiAgICAgICAgICAgIGAke2VsLnRleHRDb250ZW50ID8/ICcnfSAke2VsLmdldEF0dHJpYnV0ZSgnYXJpYS1sYWJlbCcpID8/ICcnfWBcbiAgICAgICAgICAgICAgLnJlcGxhY2UoL1xccysvZywgJyAnKVxuICAgICAgICAgICAgICAudHJpbSgpXG4gICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgIGNvbnN0IGNsaWNrUmV0cnlJZlJlbG9hZEVycm9yID0gKCk6IGJvb2xlYW4gPT4ge1xuICAgICAgICAgICAgY29uc3QgYm9keVRleHQgPSAoZG9jdW1lbnQuYm9keT8uaW5uZXJUZXh0ID8/ICcnKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAhYm9keVRleHQuaW5jbHVkZXMoJ3NvbWV0aGluZyB3ZW50IHdyb25nJykgJiZcbiAgICAgICAgICAgICAgIWJvZHlUZXh0LmluY2x1ZGVzKCd0cnkgcmVsb2FkaW5nJylcbiAgICAgICAgICAgICkge1xuICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBjb250cm9scyA9IEFycmF5LmZyb20oXG4gICAgICAgICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2J1dHRvbixbcm9sZT1cImJ1dHRvblwiXSxhW2hyZWZdJylcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBjb25zdCByZXRyeSA9IGNvbnRyb2xzLmZpbmQoKGVsKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHRleHQgPSBub3JtYWxpemVkVGV4dChlbCk7XG4gICAgICAgICAgICAgIHJldHVybiB0ZXh0ID09PSAncmV0cnknIHx8IHRleHQuaW5jbHVkZXMoJ3JldHJ5JykgfHwgdGV4dC5pbmNsdWRlcygndHJ5IGFnYWluJyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICghcmV0cnkpIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIChyZXRyeSBhcyBIVE1MRWxlbWVudCkuY2xpY2soKTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH07XG4gICAgICAgICAgaWYgKGNsaWNrUmV0cnlJZlJlbG9hZEVycm9yKCkpIHJldHVybiB7IHJldHJpZWQ6IHRydWUsIHNjcm9sbGVkOiBmYWxzZSB9O1xuICAgICAgICAgIC8vIFNjcm9sbCB0aGUgcGFnZS4gRGlzcGF0Y2ggRW5kIGtleSBmaXJzdCBzaW5jZSBtYW55IFggc3VyZmFjZXNcbiAgICAgICAgICAvLyAgICAobGlzdHMsIHNlYXJjaCwgcmVwbGllcykgYmluZCBwYWdpbmF0aW9uIHRyaWdnZXJzIHRvIGl0IHZpYVxyXG4gICAgICAgICAgLy8gICAgUmVhY3QgaGFuZGxlcnM7IHRoZW4gZXhwbGljaXRseSBzY3JvbGwgdGhlIGRvY3VtZW50LlxyXG4gICAgICAgICAgY29uc3Qgb3B0czogS2V5Ym9hcmRFdmVudEluaXQgPSB7XHJcbiAgICAgICAgICAgIGtleTogJ0VuZCcsXHJcbiAgICAgICAgICAgIGNvZGU6ICdFbmQnLFxyXG4gICAgICAgICAgICBrZXlDb2RlOiAzNSxcclxuICAgICAgICAgICAgd2hpY2g6IDM1LFxyXG4gICAgICAgICAgICBidWJibGVzOiB0cnVlLFxyXG4gICAgICAgICAgICBjYW5jZWxhYmxlOiB0cnVlLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIGNvbnN0IGZvY3VzID0gKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgYXMgSFRNTEVsZW1lbnQgfCBudWxsKSA/PyBkb2N1bWVudC5ib2R5O1xyXG4gICAgICAgICAgZm9jdXMuZGlzcGF0Y2hFdmVudChuZXcgS2V5Ym9hcmRFdmVudCgna2V5ZG93bicsIG9wdHMpKTtcclxuICAgICAgICAgIGZvY3VzLmRpc3BhdGNoRXZlbnQobmV3IEtleWJvYXJkRXZlbnQoJ2tleXVwJywgb3B0cykpO1xyXG4gICAgICAgICAgd2luZG93LnNjcm9sbFRvKHtcbiAgICAgICAgICAgIHRvcDogZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnNjcm9sbEhlaWdodCxcbiAgICAgICAgICAgIGJlaGF2aW9yOiAnYXV0bycsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmV0dXJuIHsgcmV0cmllZDogZmFsc2UsIHNjcm9sbGVkOiB0cnVlIH07XG4gICAgICAgIH0pIGFzIHVua25vd24gYXMgKCkgPT4gdm9pZCxcbiAgICAgIH0pKSBhcyBBcnJheTx7IHJlc3VsdD86IHVua25vd24gfT47XG4gICAgICBjb25zdCBwYWdlUmVzdWx0cyA9IHJlc3VsdHNcbiAgICAgICAgLm1hcCgocikgPT4gci5yZXN1bHQpXG4gICAgICAgIC5maWx0ZXIoXG4gICAgICAgICAgKHJlc3VsdCk6IHJlc3VsdCBpcyB7IHJldHJpZWQ/OiB1bmtub3duOyBzY3JvbGxlZD86IHVua25vd24gfSA9PlxuICAgICAgICAgICAgdHlwZW9mIHJlc3VsdCA9PT0gJ29iamVjdCcgJiYgcmVzdWx0ICE9PSBudWxsXG4gICAgICAgICk7XG4gICAgICBpZiAocGFnZVJlc3VsdHMuc29tZSgocmVzdWx0KSA9PiByZXN1bHQucmV0cmllZCA9PT0gdHJ1ZSkpIHtcbiAgICAgICAgcmV0cnlDb3VudCArPSAxO1xuICAgICAgfVxuICAgICAgaWYgKHBhZ2VSZXN1bHRzLnNvbWUoKHJlc3VsdCkgPT4gcmVzdWx0LnNjcm9sbGVkID09PSB0cnVlKSkge1xuICAgICAgICBzY3JvbGxDb3VudCArPSAxO1xuICAgICAgfVxuICAgIH0gY2F0Y2gge1xyXG4gICAgICAvLyBUYWJzIHRoYXQgZGlzYWxsb3cgc2NyaXB0aW5nIChhYm91dDosIGRpc2NhcmRlZCwgbWlkLW5hdmlnYXRpb24pXHJcbiAgICAgIC8vIGp1c3QgZ2V0IHNraXBwZWQgXHUyMDE0IHRoZXknbGwgYmUgZWxpZ2libGUgb24gYSBsYXRlciB0aWNrLlxyXG4gICAgfVxuICB9XG4gIGlmIChyZXRyeUNvdW50ID4gMCkge1xuICAgIGF3YWl0IGluZm8oJ2F1dG8tc2Nyb2xsIGNsaWNrZWQgWCByZXRyeSBjb250cm9sJywgeyB0YWJfY291bnQ6IHJldHJ5Q291bnQgfSk7XG4gIH1cbiAgaWYgKHNjcm9sbENvdW50ID4gMCkge1xuICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xyXG4gICAgaWYgKHNlc3MgIT09IG51bGwpIHtcclxuICAgICAgc2Vzcy5zY3JvbGxDb3VudCArPSBzY3JvbGxDb3VudDtcclxuICAgICAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oc2Vzcyk7XHJcbiAgICAgIC8vIE5vIGJyb2FkY2FzdCBvbiBldmVyeSB0aWNrIFx1MjAxNCB0aGUgMTVzIHNpZGViYXIgcmVmcmVzaCBwaWNrcyBpdCB1cC5cclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHBydW5lU2hvd01vcmVSZWxldmFuY2UoKTogdm9pZCB7XHJcbiAgY29uc3QgY3V0b2ZmID0gRGF0ZS5ub3coKSAtIFNIT1dfTU9SRV9SRUxFVkFOQ0VfVFRMX01TO1xyXG4gIGZvciAoY29uc3QgW3RhYklkLCBlbnRyeV0gb2Ygc2hvd01vcmVSZWxldmFudFR3ZWV0c0J5VGFiKSB7XHJcbiAgICBpZiAoZW50cnkudXBkYXRlZEF0IDwgY3V0b2ZmKSBzaG93TW9yZVJlbGV2YW50VHdlZXRzQnlUYWIuZGVsZXRlKHRhYklkKTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJlbWVtYmVyU2hvd01vcmVSZWxldmFudFR3ZWV0cyhcclxuICB0YWJJZDogbnVtYmVyIHwgbnVsbCxcclxuICBwYWdlVXJsOiBzdHJpbmcgfCBudWxsLFxyXG4gIHR3ZWV0czogUmVhZG9ubHlBcnJheTxDYW5vbmljYWxUd2VldD4sXHJcbiAgY29yZUhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz5cclxuKTogdm9pZCB7XHJcbiAgaWYgKHRhYklkID09PSBudWxsIHx8IHR3ZWV0cy5sZW5ndGggPT09IDAgfHwgY29yZUhhbmRsZXMuc2l6ZSA9PT0gMCkgcmV0dXJuO1xyXG4gIGNvbnN0IGNvcmVUd2VldElkcyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xyXG4gIGZvciAoY29uc3QgdCBvZiB0d2VldHMpIHtcclxuICAgIGlmIChjb3JlSGFuZGxlcy5oYXModC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpKSkgY29yZVR3ZWV0SWRzLmFkZCh0LnR3ZWV0X2lkKTtcclxuICB9XHJcbiAgY29uc3QgZXhpc3RpbmcgPSBzaG93TW9yZVJlbGV2YW50VHdlZXRzQnlUYWIuZ2V0KHRhYklkKTtcclxuICBjb25zdCB0d2VldElkcyA9IGV4aXN0aW5nPy50d2VldElkcyA/PyBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XHJcbiAgICBjb25zdCBoYW5kbGUgPSB0LmFjY291bnRfaGFuZGxlLnRvTG93ZXJDYXNlKCk7XHJcbiAgICBjb25zdCByZXBseUhhbmRsZSA9IHQucmVwbHlfdG9fYWNjb3VudD8udG9Mb3dlckNhc2UoKSA/PyBudWxsO1xyXG4gICAgaWYgKFxyXG4gICAgICBjb3JlSGFuZGxlcy5oYXMoaGFuZGxlKSB8fFxyXG4gICAgICAocmVwbHlIYW5kbGUgIT09IG51bGwgJiYgY29yZUhhbmRsZXMuaGFzKHJlcGx5SGFuZGxlKSkgfHxcclxuICAgICAgKHQucmVwbHlfdG9fdHdlZXRfaWQgIT09IG51bGwgJiYgY29yZVR3ZWV0SWRzLmhhcyh0LnJlcGx5X3RvX3R3ZWV0X2lkKSkgfHxcclxuICAgICAgKHQucXVvdGVkX3R3ZWV0X2lkICE9PSBudWxsICYmIGNvcmVUd2VldElkcy5oYXModC5xdW90ZWRfdHdlZXRfaWQpKSB8fFxyXG4gICAgICAodC5yZXR3ZWV0ZWRfdHdlZXRfaWQgIT09IG51bGwgJiYgY29yZVR3ZWV0SWRzLmhhcyh0LnJldHdlZXRlZF90d2VldF9pZCkpXHJcbiAgICApIHtcclxuICAgICAgdHdlZXRJZHMuYWRkKHQudHdlZXRfaWQpO1xyXG4gICAgfVxyXG4gIH1cclxuICBzaG93TW9yZVJlbGV2YW50VHdlZXRzQnlUYWIuc2V0KHRhYklkLCB7XHJcbiAgICB1cGRhdGVkQXQ6IERhdGUubm93KCksXHJcbiAgICBwYWdlVXJsLFxyXG4gICAgdHdlZXRJZHMsXHJcbiAgfSk7XHJcbn1cclxuXHJcbmJyb3dzZXIuYWxhcm1zLm9uQWxhcm0uYWRkTGlzdGVuZXIoKGFsYXJtKSA9PiB7XHJcbiAgaWYgKGFsYXJtLm5hbWUgPT09ICdmbHVzaC1zd2VlcCcpIHtcclxuICAgIHZvaWQgZmx1c2hJZGxlQnVmZmVycygpO1xyXG4gIH0gZWxzZSBpZiAoYWxhcm0ubmFtZSA9PT0gJ3ZlcmlmeS1jb25uZWN0aW9uJykge1xyXG4gICAgdm9pZCB2ZXJpZnlDb25uZWN0aW9uKGZhbHNlKTtcclxuICB9XHJcbiAgLy8gcmVmZXRjaCAvIG1lZGlhLWNyYXdsIHByZXZpb3VzbHkgcmFuIHZpYSBhbGFybXM7IHRoZXkgbm93IHVzZVxyXG4gIC8vIHNldEludGVydmFsIHRvIGVzY2FwZSB0aGUgMzBzIGFsYXJtIGZsb29yLiBMZWF2ZSB0aGUgbmFtZXMgbGlzdGVkXHJcbiAgLy8gbm93aGVyZSBzbyBhbnkgb3JwaGFuZWQgYWxhcm1zIChmcm9tIG9sZGVyIGJ1aWxkcykganVzdCBuby1vcC5cclxufSk7XHJcblxyXG4vLyAtLS0gVG9vbGJhciBhY3Rpb246IHRvZ2dsZSB0aGUgc2lkZWJhciAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5pZiAoYnJvd3Nlci5hY3Rpb24/Lm9uQ2xpY2tlZCkge1xuICBicm93c2VyLmFjdGlvbi5vbkNsaWNrZWQuYWRkTGlzdGVuZXIoYXN5bmMgKHRhYikgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzaWRlYmFyQWN0aW9uID0gKGJyb3dzZXIgYXMgdW5rbm93biBhcyB7XG4gICAgICAgIHNpZGViYXJBY3Rpb24/OiB7IHRvZ2dsZT86ICgpID0+IFByb21pc2U8dm9pZD4gfTtcbiAgICAgIH0pLnNpZGViYXJBY3Rpb247XG4gICAgICBpZiAoc2lkZWJhckFjdGlvbj8udG9nZ2xlKSB7XG4gICAgICAgIGF3YWl0IHNpZGViYXJBY3Rpb24udG9nZ2xlKCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgY29uc3Qgc2lkZVBhbmVsID0gKGJyb3dzZXIgYXMgdW5rbm93biBhcyB7XG4gICAgICAgIHNpZGVQYW5lbD86IHsgb3Blbj86IChvcHRpb25zOiB7IHdpbmRvd0lkPzogbnVtYmVyIH0pID0+IFByb21pc2U8dm9pZD4gfTtcbiAgICAgIH0pLnNpZGVQYW5lbDtcbiAgICAgIGlmIChzaWRlUGFuZWw/Lm9wZW4pIHtcbiAgICAgICAgY29uc3Qgb3B0aW9uczogeyB3aW5kb3dJZD86IG51bWJlciB9ID0ge307XG4gICAgICAgIGlmICh0eXBlb2YgdGFiLndpbmRvd0lkID09PSAnbnVtYmVyJykgb3B0aW9ucy53aW5kb3dJZCA9IHRhYi53aW5kb3dJZDtcbiAgICAgICAgYXdhaXQgc2lkZVBhbmVsLm9wZW4ob3B0aW9ucyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogYnJvd3Nlci5ydW50aW1lLmdldFVSTCgnc2lkZWJhci5odG1sJykgfSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAvLyBGYWxsYmFjazogb3BlbiB0aGUgZXh0ZW5zaW9uIFVJIGluIGEgdGFiIGlmIHRoZSBicm93c2VyLXNwZWNpZmljXG4gICAgICAvLyBzaWRlYmFyIEFQSSBpcyB1bmF2YWlsYWJsZSBvciByZWplY3RzIHRoZSBhY3Rpb24tY2xpY2sgcmVxdWVzdC5cbiAgICAgIGF3YWl0IHdhcm4oJ3NpZGViYXIgb3BlbiBmYWlsZWQ7IG9wZW5pbmcgc2lkZWJhciB0YWInLCBkZXNjcmliZUVycm9yKGVycikpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogYnJvd3Nlci5ydW50aW1lLmdldFVSTCgnc2lkZWJhci5odG1sJykgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH0gY2F0Y2ggKHRhYkVycikge1xuICAgICAgICBhd2FpdCB3YXJuKCdzaWRlYmFyIHRhYiBmYWlsZWQ7IG9wZW5pbmcgb3B0aW9ucycsIGRlc2NyaWJlRXJyb3IodGFiRXJyKSk7XG4gICAgICB9XG4gICAgICBhd2FpdCBicm93c2VyLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCk7XG4gICAgfVxuICB9KTtcbn1cblxyXG4vLyAtLS0gUnVudGltZSBtZXNzYWdlIGRpc3BhdGNoIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24sIHNlbmRlcikgPT4ge1xyXG4gIGlmICghaXNSdW50aW1lTWVzc2FnZShtc2cpKSByZXR1cm4gdW5kZWZpbmVkO1xyXG4gIHJldHVybiBoYW5kbGVNZXNzYWdlKG1zZywgc2VuZGVyKS5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICB2b2lkIGxvZ0VycignbWVzc2FnZSBoYW5kbGVyIGZhaWxlZCcsIHsgdHlwZTogbXNnLnR5cGUsIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSB9KTtcclxuICAgIHRocm93IGVycjtcclxuICB9KTtcclxufSk7XHJcblxyXG5mdW5jdGlvbiBpc1J1bnRpbWVNZXNzYWdlKG06IHVua25vd24pOiBtIGlzIFJ1bnRpbWVNZXNzYWdlIHtcclxuICByZXR1cm4gISFtICYmIHR5cGVvZiBtID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgKG0gYXMgeyB0eXBlPzogdW5rbm93biB9KS50eXBlID09PSAnc3RyaW5nJztcclxufVxyXG5cclxuLyoqIE1lc3NhZ2VzIHRoYXQgZHJpdmUgdGhlIGNhcHR1cmUgcGlwZWxpbmUuIFdoZW4gdGhlIG1hc3RlciBzd2l0Y2ggaXMgT0ZGXHJcbiAqIHdlIGlnbm9yZSB0aGVzZSBidXQgc3RpbGwgcmVzcG9uZCB0byBzdGF0dXMgLyBjb25maWd1cmF0aW9uIHF1ZXJpZXMuICovXHJcbmNvbnN0IENBUFRVUkVfUElQRUxJTkVfTUVTU0FHRVMgPSBuZXcgU2V0PFJ1bnRpbWVNZXNzYWdlWyd0eXBlJ10+KFtcclxuICAnZ3JhcGhxbC1jYXB0dXJlJyxcclxuICAnY2FwdHVyZS1ub3cnLFxyXG4gICdjYXB0dXJlLWFsbCcsXHJcbiAgJ2NhcHR1cmUtdGhpcy1wYWdlJyxcclxuICAnZmx1c2gtYWxsJyxcclxuICAnZmx1c2gtaGFuZGxlJyxcclxuICAnc3RhcnQtcmVmZXRjaCcsXHJcbiAgJ3N0YXJ0LW1lZGlhLWNyYXdsJyxcclxuICAnc3RhcnQtdGhyZWFkLW9wZW4nLFxyXG4gICdzdGFydC1hdXRvLXNjcm9sbCcsXHJcbl0pO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gaXNFbmFibGVkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xyXG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIHJldHVybiBzLmVuYWJsZWQgIT09IGZhbHNlO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVNZXNzYWdlKFxyXG4gIG1zZzogUnVudGltZU1lc3NhZ2UsXHJcbiAgc2VuZGVyPzogYnJvd3Nlci5ydW50aW1lLk1lc3NhZ2VTZW5kZXJcclxuKTogUHJvbWlzZTx1bmtub3duPiB7XHJcbiAgLy8gTWFzdGVyIHN3aXRjaDogd2hlbiB0aGUgdXNlciBoYXMgcGF1c2VkIHRoZSBleHRlbnNpb24gd2Ugc3RpbGwgbmVlZFxyXG4gIC8vIHRoZSBtZXRhLWNoYW5uZWxzIChnZXQtc3RhdGUsIHRvZ2dsZS1lbmFibGVkLCBvcGVuLW9wdGlvbnMsIFx1MjAyNikgc28gdGhlXHJcbiAgLy8gc2lkZWJhciBzdGF5cyBmdW5jdGlvbmFsLCBidXQgYW55dGhpbmcgdGhhdCB3b3VsZCBhY3R1YWxseSBjYXB0dXJlLFxyXG4gIC8vIGNvbW1pdCwgb3IgZHJpdmUgYSB0YWIgaXMgYSBuby1vcC5cclxuICBpZiAoIShhd2FpdCBpc0VuYWJsZWQoKSkgJiYgQ0FQVFVSRV9QSVBFTElORV9NRVNTQUdFUy5oYXMobXNnLnR5cGUpKSB7XHJcbiAgICByZXR1cm4geyBvazogdHJ1ZSwgcGF1c2VkOiB0cnVlIH07XHJcbiAgfVxyXG4gIHN3aXRjaCAobXNnLnR5cGUpIHtcclxuICAgIGNhc2UgJ2dyYXBocWwtY2FwdHVyZSc6XHJcbiAgICAgIGF3YWl0IG9uR3JhcGhxbENhcHR1cmUoXHJcbiAgICAgICAgbXNnLmVuZHBvaW50LFxyXG4gICAgICAgIG1zZy51cmwsXHJcbiAgICAgICAgbXNnLnBhZ2VVcmwgPz8gbnVsbCxcclxuICAgICAgICBtc2cucmVzcG9uc2UsXHJcbiAgICAgICAgc2VuZGVyPy50YWI/LmlkID8/IG51bGxcclxuICAgICAgKTtcclxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgIGNhc2UgJ2NvbnRlbnQtYWxpdmUnOlxyXG4gICAgICBhd2FpdCBpbmZvKCdjb250ZW50IHNjcmlwdCBhbGl2ZSBvbiBwYWdlJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdwYWdlLWhvb2stYWN0aXZlJzpcclxuICAgICAgYXdhaXQgaW5mbygncGFnZSBob29rIHBhdGNoZWQgZmV0Y2gvWEhSJywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICBjYXNlICdsb2ctY29udGVudC1ldmVudCc6XHJcbiAgICAgIGlmIChtc2cubGV2ZWwgPT09ICd3YXJuJykge1xyXG4gICAgICAgIGF3YWl0IHdhcm4obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAobXNnLmxldmVsID09PSAnZXJyb3InKSB7XHJcbiAgICAgICAgYXdhaXQgbG9nRXJyKG1zZy5tc2csIHsgdXJsOiBzaG9ydGVuVXJsKG1zZy51cmwpIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGF3YWl0IGluZm8obXNnLm1zZywgeyB1cmw6IHNob3J0ZW5VcmwobXNnLnVybCkgfSk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgIGNhc2UgJ2dldC11bmZvbGQtdGFyZ2V0cyc6IHtcclxuICAgICAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gICAgICBpZiAoc2V0dGluZ3MuZW5hYmxlZCA9PT0gZmFsc2UpIHtcclxuICAgICAgICByZXR1cm4geyBlbmFibGVkOiBmYWxzZSwgY29yZUhhbmRsZXM6IFtdLCByZWxldmFudFR3ZWV0SWRzOiBbXSB9O1xyXG4gICAgICB9XHJcbiAgICAgIHBydW5lU2hvd01vcmVSZWxldmFuY2UoKTtcclxuICAgICAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gICAgICBjb25zdCBjb3JlSGFuZGxlcyA9IGFjY291bnRzXHJcbiAgICAgICAgLmZpbHRlcigoYSkgPT4gYS5jYXRlZ29yeSA9PT0gJ2NvcmUnKVxyXG4gICAgICAgIC5tYXAoKGEpID0+IGEuaGFuZGxlLnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICBjb25zdCB0YWJJZCA9IHNlbmRlcj8udGFiPy5pZCA/PyBudWxsO1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGVuYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgY29yZUhhbmRsZXMsXHJcbiAgICAgICAgcmVsZXZhbnRUd2VldElkczpcclxuICAgICAgICAgIHRhYklkID09PSBudWxsID8gW10gOiBBcnJheS5mcm9tKHNob3dNb3JlUmVsZXZhbnRUd2VldHNCeVRhYi5nZXQodGFiSWQpPy50d2VldElkcyA/PyBbXSksXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgICBjYXNlICdzaG93LW1vcmUtdW5mb2xkZWQnOiB7XHJcbiAgICAgIGlmIChtc2cuY291bnQgPiAwKSB7XHJcbiAgICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICAgICAgICBpZiAoYXNTZXNzICE9PSBudWxsKSB7XHJcbiAgICAgICAgICBhc1Nlc3MuZXhwYW5kZWRDb3VudCArPSBtc2cuY291bnQ7XHJcbiAgICAgICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihhc1Nlc3MpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xyXG4gICAgfVxyXG4gICAgY2FzZSAnZ2V0LXN0YXRlJzpcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NhcHR1cmUtbm93JzpcclxuICAgICAgYXdhaXQgY2FwdHVyZU5vdyhtc2cuaGFuZGxlKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NhcHR1cmUtYWxsJzpcclxuICAgICAgYXdhaXQgY2FwdHVyZUFsbCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2FwdHVyZS10aGlzLXBhZ2UnOlxyXG4gICAgICBhd2FpdCBjYXB0dXJlVGhpc1BhZ2UoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2ZsdXNoLWFsbCc6XHJcbiAgICAgIGF3YWl0IGZsdXNoQWxsKCd1c2VyJyk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICdmbHVzaC1oYW5kbGUnOlxyXG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShtc2cuaGFuZGxlLCAndXNlcicpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAndG9nZ2xlLWF1dG8tY2FwdHVyZSc6XHJcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b0NhcHR1cmU6IG1zZy5vbiB9KTtcclxuICAgICAgYXdhaXQgaW5mbygnYXV0by1jYXB0dXJlIHRvZ2dsZWQnLCB7IG9uOiBtc2cub24gfSk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICBjYXNlICd0b2dnbGUtdXBkYXRlLWV4aXN0aW5nJzpcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgdXBkYXRlRXhpc3Rpbmc6IG1zZy5vbiB9KTtcbiAgICAgIGF3YWl0IGluZm8oJ3VwZGF0ZS1leGlzdGluZyB0b2dnbGVkJywgeyBvbjogbXNnLm9uIH0pO1xuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcbiAgICBjYXNlICd0b2dnbGUtbG93LWJhbmR3aWR0aCc6XG4gICAgICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IGxvd0JhbmR3aWR0aEJyb3dzaW5nOiBtc2cub24gfSk7XG4gICAgICBhd2FpdCBzeW5jTG93QmFuZHdpZHRoUnVsZXMoeyByZWFzb246ICd0b2dnbGUnLCBsb2c6IHRydWUgfSk7XG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xuICAgIGNhc2UgJ3RvZ2dsZS1lbmFibGVkJzoge1xuICAgICAgY29uc3QgcyA9IGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgZW5hYmxlZDogbXNnLm9uIH0pO1xyXG4gICAgICBpZiAoIW1zZy5vbikge1xyXG4gICAgICAgIC8vIFBhdXNpbmcgc3RvcHMgYWxsIGluLWZsaWdodCBsb29wcyBzbyB0aGUgdXNlciBnZXRzIGltbWVkaWF0ZVxyXG4gICAgICAgIC8vIHF1aWV0LCBub3QgYSBcIm9uZSBtb3JlIHRpY2tcIiBzdXJwcmlzZS5cclxuICAgICAgICBjbGVhckF1dG9TY3JvbGxUaW1lcigpO1xyXG4gICAgICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcclxuICAgICAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XHJcbiAgICAgICAgc3RvcFRocmVhZE9wZW5JbnRlcnZhbCgpO1xyXG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdyZWZldGNoLXRpY2snKTsgLy8gbGVnYWN5IGNsZWFudXBcclxuICAgICAgICBhd2FpdCBicm93c2VyLmFsYXJtcy5jbGVhcignbWVkaWEtY3Jhd2wtdGljaycpO1xyXG4gICAgICAgIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd0aHJlYWQtb3Blbi10aWNrJyk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gUmVzdW1pbmcgcmUtYXJtcyBhbnkgbG9vcHMgd2hvc2Ugc2Vzc2lvbiBpcyBzdGlsbCBzZXQuXHJcbiAgICAgICAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgICAgICAgaWYgKHNlc3MgIT09IG51bGwpIGFybUF1dG9TY3JvbGxUaW1lcihzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYyk7XHJcbiAgICAgIH1cclxuICAgICAgYXdhaXQgaW5mbygnZXh0ZW5zaW9uIG1hc3RlciBzd2l0Y2ggdG9nZ2xlZCcsIHsgb246IG1zZy5vbiB9KTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIH1cclxuICAgIGNhc2UgJ3N0YXJ0LWF1dG8tc2Nyb2xsJzpcclxuICAgICAgYXdhaXQgc3RhcnRBdXRvU2Nyb2xsTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2FuY2VsLWF1dG8tc2Nyb2xsJzpcclxuICAgICAgYXdhaXQgY2FuY2VsQXV0b1Njcm9sbExvb3AoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCc6IHtcclxuICAgICAgY29uc3Qgc2Vjb25kcyA9IE1hdGgubWluKFxyXG4gICAgICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXHJcbiAgICAgICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChtc2cuc2Vjb25kcykpXHJcbiAgICAgICk7XHJcbiAgICAgIGF3YWl0IHVwZGF0ZVNldHRpbmdzKHsgYXV0b1Njcm9sbEludGVydmFsU2VjOiBzZWNvbmRzIH0pO1xyXG4gICAgICAvLyBSZS1hcm0gYW55IGFjdGl2ZSBsb29wcyB3aXRoIHRoZSBuZXcgaW50ZXJ2YWwuXHJcbiAgICAgIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRBdXRvU2Nyb2xsU2Vzc2lvbigpO1xyXG4gICAgICBpZiAoc2VzcyAhPT0gbnVsbCkgYXJtQXV0b1Njcm9sbFRpbWVyKHNlY29uZHMpO1xyXG4gICAgICBpZiAocmVmZXRjaEludGVydmFsSGFuZGxlICE9PSBudWxsKSBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcclxuICAgICAgaWYgKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCkgc3RhcnRNZWRpYUNyYXdsSW50ZXJ2YWwoc2Vjb25kcyk7XHJcbiAgICAgIGlmICh0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHN0YXJ0VGhyZWFkT3BlbkludGVydmFsKHNlY29uZHMpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgfVxyXG4gICAgY2FzZSAnc3RhcnQtcmVmZXRjaCc6XHJcbiAgICAgIGF3YWl0IHN0YXJ0UmVmZXRjaExvb3AoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NhbmNlbC1yZWZldGNoJzpcclxuICAgICAgYXdhaXQgY2FuY2VsUmVmZXRjaExvb3AoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3N0YXJ0LW1lZGlhLWNyYXdsJzpcclxuICAgICAgYXdhaXQgc3RhcnRNZWRpYUNyYXdsTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2FuY2VsLW1lZGlhLWNyYXdsJzpcclxuICAgICAgYXdhaXQgY2FuY2VsTWVkaWFDcmF3bExvb3AoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3N0YXJ0LXRocmVhZC1vcGVuJzpcclxuICAgICAgYXdhaXQgc3RhcnRUaHJlYWRPcGVuTG9vcCgpO1xyXG4gICAgICByZXR1cm4gYnVpbGRTdGF0ZSgpO1xyXG4gICAgY2FzZSAnY2FuY2VsLXRocmVhZC1vcGVuJzpcclxuICAgICAgYXdhaXQgY2FuY2VsVGhyZWFkT3Blbkxvb3AoKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3B1cmdlLXVucmVsYXRlZCc6IHtcclxuICAgICAgY29uc3QgYWNjcyA9IGF3YWl0IGdldEFjY291bnRzKCk7XHJcbiAgICAgIGNvbnN0IHRyYWNrZWQgPSBuZXcgU2V0KGFjY3MubWFwKChhKSA9PiBhLmhhbmRsZS50b0xvd2VyQ2FzZSgpKSk7XHJcbiAgICAgIGNvbnN0IHN1bW1hcnkgPSBhd2FpdCBwdXJnZVVucmVsYXRlZFN0YXRlKHRyYWNrZWQpO1xyXG4gICAgICBhd2FpdCBpbmZvKCdwdXJnZWQgdW5yZWxhdGVkIHN0YXRlJywgc3VtbWFyeSk7XHJcbiAgICAgIHJldHVybiBidWlsZFN0YXRlKCk7XHJcbiAgICB9XHJcbiAgICBjYXNlICdyZWZyZXNoLWFjY291bnRzJzpcclxuICAgICAgYXdhaXQgcmVmcmVzaEFjY291bnRzTGlzdCh0cnVlKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ3ZlcmlmeS1jb25uZWN0aW9uJzpcclxuICAgICAgYXdhaXQgdmVyaWZ5Q29ubmVjdGlvbih0cnVlKTtcclxuICAgICAgcmV0dXJuIGJ1aWxkU3RhdGUoKTtcclxuICAgIGNhc2UgJ2NsZWFyLWFjdGl2aXR5JzpcclxuICAgICAgYXdhaXQgY2xlYXJBY3Rpdml0eSgpO1xyXG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xyXG4gICAgY2FzZSAnb3Blbi1vcHRpb25zJzpcclxuICAgICAgYXdhaXQgYnJvd3Nlci5ydW50aW1lLm9wZW5PcHRpb25zUGFnZSgpO1xyXG4gICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xyXG4gICAgY2FzZSAnb3Blbi12aWV3ZXInOiB7XHJcbiAgICAgIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gICAgICBjb25zdCB1cmwgPSB2aWV3ZXJVcmwocyk7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5jcmVhdGUoeyB1cmwgfSk7XHJcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlIH07XHJcbiAgICB9XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAndW5rbm93biBtZXNzYWdlIHR5cGUnIH07XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0gQ2FwdHVyZSBwaXBlbGluZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gb25HcmFwaHFsQ2FwdHVyZShcclxuICBlbmRwb2ludDogc3RyaW5nLFxyXG4gIHVybDogc3RyaW5nLFxyXG4gIHBhZ2VVcmw6IHN0cmluZyB8IG51bGwsXHJcbiAgcmVzcG9uc2U6IHVua25vd24sXHJcbiAgc2VuZGVyVGFiSWQ6IG51bWJlciB8IG51bGxcclxuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgaWYgKFBST0ZJTEVfRU5EUE9JTlRTLmhhcyhlbmRwb2ludCkpIHJldHVybjsgLy8gbm90IHR3ZWV0LWJlYXJpbmdcclxuICBpZiAoIVRXRUVUX0VORFBPSU5UUy5oYXMoZW5kcG9pbnQpKSByZXR1cm47XHJcblxyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoc2V0dGluZ3MuZW5hYmxlZCA9PT0gZmFsc2UpIHJldHVybjtcclxuICBpZiAoc2V0dGluZ3MuYXV0b0NhcHR1cmUgPT09IGZhbHNlKSB7XHJcbiAgICBjb25zdCBleHBsaWNpdENhcHR1cmVBY3RpdmUgPVxyXG4gICAgICBEYXRlLm5vdygpIDwgbWFudWFsQ2FwdHVyZVVudGlsTXMgfHxcclxuICAgICAgKGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCkpICE9PSBudWxsIHx8XHJcbiAgICAgIChhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpKSAhPT0gbnVsbCB8fFxyXG4gICAgICAoYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKSkgIT09IG51bGw7XHJcbiAgICBpZiAoIWV4cGxpY2l0Q2FwdHVyZUFjdGl2ZSkgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gIC8vIFdlIGRlbGliZXJhdGVseSBkbyBOT1Qgc2hvcnQtY2lyY3VpdCB3aGVuIHRoZSBQQVQgaXMgbWlzc2luZy4gVGhlXHJcbiAgLy8gbm9ybWFsaXplIHN0ZXAgaXMgY2hlYXAsIHRoZSBidWZmZXIgc3Vydml2ZXMgc2VydmljZS13b3JrZXIgZXZpY3Rpb24sXHJcbiAgLy8gYW5kIG9uY2UgdGhlIFBBVCBpcyBzZXQgdGhlIG5leHQgYWxhcm0gb3IgdXNlci10cmlnZ2VyZWQgZmx1c2ggY29tbWl0c1xyXG4gIC8vIGV2ZXJ5dGhpbmcgd2UndmUgc2Vlbi4gRHJvcHBpbmcgY2FwdHVyZXMgaGVyZSB3YXMgaGlkaW5nIHRoZSB1c2VyJ3NcclxuICAvLyBmaXJzdCBicm93c2luZyBzZXNzaW9uIGVudGlyZWx5LlxyXG5cclxuICAvLyBUd28tc3RhZ2UgZmlsdGVyOlxyXG4gIC8vICAgMS4gQnVpbGQgRVZFUlkgY2Fub25pY2FsIHR3ZWV0IHdlIGNhbiBmaW5kIGluIHRoZSByZXNwb25zZSAobm8gaGFuZGxlXHJcbiAgLy8gICAgICBmaWx0ZXIgYXQgdGhlIG5vcm1hbGl6ZXIgbGV2ZWwgXHUyMDE0IHdlIHN0aWxsIHdhbnQgcXVvdGVkL1JUJ2QgcGFyZW50c1xyXG4gIC8vICAgICAgdGhhdCBhcHBlYXIgYXMgc2libGluZyBub2RlcykuXHJcbiAgLy8gICAyLiBBcHBseSBgZmlsdGVyUmVsYXRlZGAgcG9zdC1ob2MgdG8gZHJvcCBhbnl0aGluZyB0aGF0IGhhcyBub1xyXG4gIC8vICAgICAgcmVsYXRpb25zaGlwIHRvIGEgdHJhY2tlZCBhY2NvdW50LiBUaGUgb2xkIGJlaGF2aW91ciAoXCJlbXB0eVxyXG4gIC8vICAgICAgYWxsb3dlZC1zZXQgb24gdXNlci1wYWdlIGVuZHBvaW50cywgZnVsbCBmaWx0ZXIgb24gaG9tZS9zZWFyY2hcIilcclxuICAvLyAgICAgIHdhcyB3YXkgdG9vIHBlcm1pc3NpdmUgb24gdGhlIFJlcGxpZXMgdGFiOiBldmVyeSByYW5kb20gcmVwbGllcidzXHJcbiAgLy8gICAgICByZXBseSBsYW5kZWQgaW4gYSBwZXItaGFuZGxlIGJ1ZmZlciBrZXllZCBieSB0aGVpciBvd24gaGFuZGxlLlxyXG4gIGNvbnN0IHRyYWNrZWQgPSBuZXcgU2V0KGFjY291bnRzLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSkpO1xyXG4gIGNvbnN0IGNvcmUgPSBuZXcgU2V0KFxyXG4gICAgYWNjb3VudHMuZmlsdGVyKChhKSA9PiBhLmNhdGVnb3J5ID09PSAnY29yZScpLm1hcCgoYSkgPT4gYS5oYW5kbGUudG9Mb3dlckNhc2UoKSlcclxuICApO1xyXG4gIGNvbnN0IGNhcHR1cmVkQXQgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XHJcblxyXG4gIGxldCBub3JtYWxpemVkO1xyXG4gIHRyeSB7XHJcbiAgICBub3JtYWxpemVkID0gbm9ybWFsaXplKHJlc3BvbnNlLCB7XHJcbiAgICAgIGNhcHR1cmVkQXQsXHJcbiAgICAgIHJ1bklkOiAncGVuZGluZycsXHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICBhbGxvd2VkSGFuZGxlczogbmV3IFNldDxzdHJpbmc+KCksXHJcbiAgICAgIHNvdXJjZVVybDogcGFnZVVybCxcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgYXdhaXQgcXVhcmFudGluZSgnbm9ybWFsaXplLXRocmV3JywgZW5kcG9pbnQsIHVybCwgcmVzcG9uc2UsIGVycik7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IHJldHdlZXRFZGdlcyA9IGJ1aWxkUmV0d2VldEVkZ2VzKFxyXG4gICAgbm9ybWFsaXplZC50d2VldHMsXHJcbiAgICBhY2NvdW50cyxcclxuICAgIGNhcHR1cmVkQXQsXHJcbiAgICBlbmRwb2ludCxcclxuICAgIHBhZ2VVcmwgPz8gdXJsXHJcbiAgKTtcclxuICAvLyBEcm9wIHVucmVsYXRlZCB0d2VldHMuIFRoZSBmaWx0ZXIgaXMgZW5kcG9pbnQtYXdhcmU6XHJcbiAgLy8gICAtIE9uIHRoZSBob21lIC8gc2VhcmNoIHRpbWVsaW5lcyB3ZSdkIGFscmVhZHkgYmVlbiBmaWx0ZXJpbmcgdG9cclxuICAvLyAgICAgdHJhY2tlZCBhdXRob3JzIG9ubHkgXHUyMDE0IGtlZXAgdGhhdCBiZWhhdmlvdXIgYnV0IGdvIHRocm91Z2ggdGhlIHNhbWVcclxuICAvLyAgICAgYGZpbHRlclJlbGF0ZWRgIGhlbHBlciBzbyB0aGUgcnVsZXMgYXJlIHVuaWZvcm0uXHJcbiAgLy8gICAtIE9uIHVzZXItcGFnZSBlbmRwb2ludHMgd2Ugbm93IGFsc28gZHJvcCBhbnl0aGluZyB0aGF0IGlzbid0IGVpdGhlclxyXG4gIC8vICAgICBhdXRob3JlZC1ieSwgbWVudGlvbmluZywgcmVwbHlpbmctdG8sIG9yIHJlZmVyZW5jZWQtYnkgYSB0cmFja2VkXHJcbiAgLy8gICAgIGFjY291bnQuXHJcbiAgY29uc3QgYmVmb3JlRmlsdGVyID0gbm9ybWFsaXplZC50d2VldHMubGVuZ3RoO1xyXG4gIG5vcm1hbGl6ZWQudHdlZXRzID0gZmlsdGVyUmVsYXRlZChub3JtYWxpemVkLnR3ZWV0cywgdHJhY2tlZCwgY29yZSk7XHJcbiAgY29uc3QgZHJvcHBlZFVucmVsYXRlZCA9IGJlZm9yZUZpbHRlciAtIG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aDtcclxuICBpZiAoZHJvcHBlZFVucmVsYXRlZCA+IDApIHtcclxuICAgIGF3YWl0IGluZm8oJ2Ryb3BwZWQgdW5yZWxhdGVkIHR3ZWV0cycsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIGRyb3BwZWQ6IGRyb3BwZWRVbnJlbGF0ZWQsXHJcbiAgICAgIGtlcHQ6IG5vcm1hbGl6ZWQudHdlZXRzLmxlbmd0aCxcclxuICAgIH0pO1xyXG4gIH1cclxuICByZW1lbWJlclNob3dNb3JlUmVsZXZhbnRUd2VldHMoc2VuZGVyVGFiSWQsIHBhZ2VVcmwsIG5vcm1hbGl6ZWQudHdlZXRzLCBjb3JlKTtcclxuXHJcbiAgLy8gRGlhZ25vc3RpYzogZXZlcnkgdHdlZXQtZW5kcG9pbnQgcGF5bG9hZCBnZXRzIGEgbGluZSBpbiB0aGUgYWN0aXZpdHlcclxuICAvLyB0YWlsIHdpdGggd2hhdCB3ZSBzYXcgdnMga2VwdC4gV2hlbiBvYnNlcnZlZD0wIHdlIGFsc28gZW1pdCBhIHNoYXBlXHJcbiAgLy8gcHJvYmUgKGtleSBwYXRocyArIHR5cGVuYW1lcykgc28gd2UgY2FuIHRlbGwgd2hldGhlciBYIHJldHVybmVkIGFuXHJcbiAgLy8gZW1wdHkgZW52ZWxvcGUsIGEgbG9naW4td2FsbCByZXNwb25zZSwgb3IgYSBuZXcgc2hhcGUgd2UgZG9uJ3Qga25vdyBob3dcclxuICAvLyB0byB3YWxrIHlldC5cclxuICBpZiAobm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdncmFwaHFsIHBheWxvYWQgZW1wdHkgXHUyMDE0IHNoYXBlIHByb2JlJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgdHlwZW5hbWVzOiBwcm9iZVR5cGVuYW1lcyhyZXNwb25zZSkuc2xpY2UoMCwgMzApLFxyXG4gICAgICB0d2VldF9rZXlzOiBwcm9iZUZpcnN0VHlwZVNoYXBlKHJlc3BvbnNlLCAnVHdlZXQnKSxcclxuICAgICAgdHdlZXRfY29yZV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbJ2NvcmUnXSksXHJcbiAgICAgIHR3ZWV0X2xlZ2FjeV9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbJ2xlZ2FjeSddKSxcclxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9rZXlzOiBwcm9iZVR5cGVkTmVzdGVkKHJlc3BvbnNlLCAnVHdlZXQnLCBbXHJcbiAgICAgICAgJ2NvcmUnLFxyXG4gICAgICAgICd1c2VyX3Jlc3VsdHMnLFxyXG4gICAgICAgICdyZXN1bHQnLFxyXG4gICAgICBdKSxcclxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9jb3JlX2tleXM6IHByb2JlVHlwZWROZXN0ZWQocmVzcG9uc2UsICdUd2VldCcsIFtcclxuICAgICAgICAnY29yZScsXHJcbiAgICAgICAgJ3VzZXJfcmVzdWx0cycsXHJcbiAgICAgICAgJ3Jlc3VsdCcsXHJcbiAgICAgICAgJ2NvcmUnLFxyXG4gICAgICBdKSxcclxuICAgICAgdXNlcl9yZXN1bHRzX3Jlc3VsdF9sZWdhY3lfa2V5czogcHJvYmVUeXBlZE5lc3RlZChyZXNwb25zZSwgJ1R3ZWV0JywgW1xyXG4gICAgICAgICdjb3JlJyxcclxuICAgICAgICAndXNlcl9yZXN1bHRzJyxcclxuICAgICAgICAncmVzdWx0JyxcclxuICAgICAgICAnbGVnYWN5JyxcclxuICAgICAgXSksXHJcbiAgICB9KTtcclxuICB9IGVsc2Uge1xyXG4gICAgYXdhaXQgaW5mbygnZ3JhcGhxbCBwYXlsb2FkIHNlZW4nLCB7XHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICBvYnNlcnZlZDogbm9ybWFsaXplZC5vYnNlcnZlZF9pZHMubGVuZ3RoLFxyXG4gICAgICBrZXB0OiBub3JtYWxpemVkLnR3ZWV0cy5sZW5ndGgsXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGlmIChub3JtYWxpemVkLnVuYXZhaWxhYmxlX3R3ZWV0cy5sZW5ndGggPiAwKSB7XHJcbiAgICBhd2FpdCByZWNvcmRVbmF2YWlsYWJsZVR3ZWV0cyhcclxuICAgICAgbm9ybWFsaXplZC51bmF2YWlsYWJsZV90d2VldHMsXHJcbiAgICAgIHRyYWNrZWQsXHJcbiAgICAgIGNhcHR1cmVkQXQsXHJcbiAgICAgIHVybCxcclxuICAgICAgZW5kcG9pbnRcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICBpZiAobm9ybWFsaXplZC50d2VldHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICBjb25zdCBidWZmZXJlZEVkZ2VzID0gYXdhaXQgYnVmZmVyUmV0d2VldEVkZ2VzKFxyXG4gICAgICByZXR3ZWV0RWRnZXMsXHJcbiAgICAgIGNhcHR1cmVkQXQsXHJcbiAgICAgIHBhZ2VVcmwgPz8gdXJsLFxyXG4gICAgICBlbmRwb2ludFxyXG4gICAgKTtcclxuICAgIGlmIChidWZmZXJlZEVkZ2VzID4gMCkgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIC8vIFJlZmV0Y2ggcXVldWUgaG91c2VrZWVwaW5nIFx1MjAxNCBydW5zIEJFRk9SRSB0aGUgZGVkdXAgc2hvcnQtY2lyY3VpdC4gQVxyXG4gIC8vIHJlZmV0Y2ggY2FwdHVyZSBjb21lcyBiYWNrIHdpdGggdGhlIHNhbWUgZW5nYWdlbWVudCBjb3VudHMgKHdlJ3JlXHJcbiAgLy8gb25seSBhZnRlciB0aGUgZnVsbCB0ZXh0KSwgc28gdGhlIGRlZHVwIGJlbG93IHdvdWxkIHNpbGVudGx5IGRyb3BcclxuICAvLyBpdCBhbmQgdGhlIHF1ZXVlIHdvdWxkIG5ldmVyIGRyYWluLiBIb2lzdCB0aGUgZW5xdWV1ZS9kZXF1ZXVlIGhlcmVcclxuICAvLyBzbyB0aGUgbG9vcCByZWxpYWJseSBhZHZhbmNlcyBldmVuIHdoZW4gbm8gY29tbWl0IGhhcHBlbnMuXHJcbiAgLy9cclxuICAvLyBBbHNvOiBpZiBlaXRoZXIgbG9vcCdzIGluZmxpZ2h0IHRhcmdldCBhcHBlYXJzIGhlcmUsIG1hcmsgdGhlIGxvb3BcclxuICAvLyBhcyBcImluZ2VzdGVkXCIgc28gdGhlIG5leHQgdGljayBjYW4gYWR2YW5jZS4gVGhlIHdhaXQtZm9yLWluZ2VzdFxyXG4gIC8vIGd1YXJkIG90aGVyd2lzZSBibG9ja3MgdW50aWwgdGhlIG5hdmlnYXRpb24tdGltZW91dCBmaXJlcy5cclxuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XHJcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xyXG4gIGNvbnN0IHRocmVhZE9wZW5TZXNzID0gYXdhaXQgZ2V0VGhyZWFkT3BlblNlc3Npb24oKTtcclxuICBmb3IgKGNvbnN0IHQgb2Ygbm9ybWFsaXplZC50d2VldHMpIHtcclxuICAgIGlmICh0LmlzX3RydW5jYXRlZCkge1xyXG4gICAgICBhd2FpdCBlbnF1ZXVlUmVmZXRjaCh0LmFjY291bnRfaGFuZGxlLCB0LnR3ZWV0X2lkKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGF3YWl0IGRlcXVldWVSZWZldGNoKHQuYWNjb3VudF9oYW5kbGUsIHQudHdlZXRfaWQpO1xyXG4gICAgfVxyXG4gICAgLy8gU3VjY2Vzc2Z1bGx5IGJ1aWx0IHR3ZWV0cyBhcmUgbm8gbG9uZ2VyIFwicGFydGlhbFwiIFx1MjAxNCBkcm9wIGZyb20gdGhlXHJcbiAgICAvLyBtZWRpYS1jcmF3bCBxdWV1ZSByZWdhcmRsZXNzIG9mIHdoaWNoIGhhbmRsZSB3ZSdkIGhpbnRlZCBlYXJsaWVyLlxyXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodC50d2VldF9pZCk7XHJcbiAgICBpZiAocmVmZXRjaFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB0LnR3ZWV0X2lkKSB7XHJcbiAgICAgIHJlZmV0Y2hTZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgICAgcmVmZXRjaFNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHJlZmV0Y2hTZXNzKTtcclxuICAgIH1cclxuICAgIGlmIChtZWRpYUNyYXdsU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHQudHdlZXRfaWQpIHtcclxuICAgICAgbWVkaWFDcmF3bFNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgICBtZWRpYUNyYXdsU2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obWVkaWFDcmF3bFNlc3MpO1xyXG4gICAgfVxyXG4gICAgaWYgKHRocmVhZE9wZW5TZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdC50d2VldF9pZCkge1xyXG4gICAgICB0aHJlYWRPcGVuU2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICAgIHRocmVhZE9wZW5TZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgICBhd2FpdCBtYXJrVGhyZWFkT3BlblNlZW4odC50d2VldF9pZCk7XHJcbiAgICAgIGF3YWl0IGRlcXVldWVUaHJlYWRPcGVuKHQudHdlZXRfaWQpO1xyXG4gICAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbih0aHJlYWRPcGVuU2Vzcyk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyBNZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXQtc2hhcGVkIG5vZGVzIHRoZSB3YWxrZXIgc2F3IGJ1dCBjb3VsZG4ndCB0dXJuXHJcbiAgLy8gaW50byBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBFbnF1ZXVlIG9ubHkgSURzIHdlIGhhdmVuJ3QgYWxyZWFkeVxyXG4gIC8vIGNvbW1pdHRlZCAodXNlci1yZXF1ZXN0ZWQgZGVkdXAgYWdhaW5zdCB0aGUgYXJjaGl2ZSkuXHJcbiAgZm9yIChjb25zdCBwYXJ0aWFsIG9mIG5vcm1hbGl6ZWQucGFydGlhbF9pZHMpIHtcclxuICAgIGlmIChhd2FpdCBpc0NvbW1pdHRlZChwYXJ0aWFsLnR3ZWV0X2lkKSkgY29udGludWU7XHJcbiAgICBhd2FpdCBlbnF1ZXVlTWVkaWFDcmF3bChwYXJ0aWFsLmhpbnRfaGFuZGxlLCBwYXJ0aWFsLnR3ZWV0X2lkKTtcclxuICB9XHJcbiAgaWYgKG5vcm1hbGl6ZWQucGFydGlhbF9pZHMubGVuZ3RoID4gMCkge1xyXG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IGVucXVldWVkIHBhcnRpYWwgY2FwdHVyZXMnLCB7XHJcbiAgICAgIGVuZHBvaW50LFxyXG4gICAgICBwYXJ0aWFsOiBub3JtYWxpemVkLnBhcnRpYWxfaWRzLmxlbmd0aCxcclxuICAgICAgcXVldWVfdG90YWw6IGF3YWl0IG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCksXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8vIENyb3NzLXNlc3Npb24gZGVkdXA6IGRyb3AgdHdlZXRzIHdlJ3ZlIGFscmVhZHkgY29tbWl0dGVkIHdpdGggaWRlbnRpY2FsXHJcbiAgLy8gZW5nYWdlbWVudCBjb3VudHMuIExpa2VzL1JUcy9yZXBsaWVzL3F1b3RlcyBzdGlsbCB0cmlnZ2VyIGEgcmVjYXB0dXJlXHJcbiAgLy8gc28gZW5nYWdlbWVudF9oaXN0b3J5IGdyb3dzIG92ZXIgdGltZS4gdmlld19jb3VudCBpcyBpbnRlbnRpb25hbGx5XHJcbiAgLy8gZXhjbHVkZWQgXHUyMDE0IGl0IGNodXJucyB0b28gZmFzdCB0byBiZSB1c2VmdWwgYXMgYSBmcmVzaG5lc3Mgc2lnbmFsLlxyXG4gIC8vIGBpc190cnVuY2F0ZWRgIGlzIHBhcnQgb2YgdGhlIHNpZ25hdHVyZSBzbyBhIHJlZmV0Y2ggdGhhdCBmbGlwc1xyXG4gIC8vIHRydW5jYXRlZFx1MjE5MmZ1bGwgaXMgdHJlYXRlZCBhcyBhIG1hdGVyaWFsIGNoYW5nZSBhbmQgZ2V0cyBjb21taXR0ZWQuXHJcbiAgLy9cclxuICAvLyBXaGVuIHRoZSB1c2VyIGhhcyB0dXJuZWQgb2ZmIFwidXBkYXRlIGV4aXN0aW5nXCIsIHdlIHNraXAgdGhlIGVuZ2FnZW1lbnRcclxuICAvLyBjb21wYXJpc29uIGVudGlyZWx5OiBhbnkgdHdlZXQgdGhhdCdzIGFscmVhZHkgY29tbWl0dGVkIHVuZGVyIGFueVxyXG4gIC8vIGhhbmRsZSBnZXRzIGRyb3BwZWQgaGVyZSwgc28gd2UgZG9uJ3QgcGF5IEdpdEh1Yi1BUEkgb3ZlcmhlYWQganVzdCB0b1xyXG4gIC8vIHJlZnJlc2ggbGlrZSAvIFJUIGNvdW50cy4gTmV3IHR3ZWV0cyBhbmQgdHJ1bmNhdGVkXHUyMTkyZnVsbCByZWZldGNoZXNcclxuICAvLyBzdGlsbCBmbG93IHRocm91Z2ggbm9ybWFsbHkgYmVjYXVzZSB0aGV5IGFyZW4ndCBpbiB0aGUgaW5kZXggeWV0XHJcbiAgLy8gKG9yIGNhcnJ5IGFuIGlzX3RydW5jYXRlZCB0cmFuc2l0aW9uIHRoYXQgZmFpbHMgdGhlIHNpZyBjaGVjaykuXHJcbiAgLy8gRnVsbC10ZXh0IHVwZ3JhZGVzIGJ5cGFzcyB0aGlzIHNraXAgZXZlbiB3aXRoIHVwZGF0ZUV4aXN0aW5nPWZhbHNlLlxyXG4gIGNvbnN0IHVwZGF0ZUV4aXN0aW5nID0gc2V0dGluZ3MudXBkYXRlRXhpc3RpbmcgIT09IGZhbHNlO1xyXG4gIGNvbnN0IGNvbW1pdHRlZElkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgY29uc3QgYXJjaGl2ZVNuYXBzaG90ID0gYXdhaXQgZ2V0QXJjaGl2ZVNuYXBzaG90KCk7XHJcbiAgbGV0IGRlZHVwZWRTa2lwcGVkID0gMDtcclxuICBsZXQgc2tpcHBlZE5vVXBkYXRlTG9jYWwgPSAwO1xyXG4gIGxldCBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCA9IDA7XHJcbiAgbGV0IG9sZEZyb21TbmFwc2hvdCA9IDA7XHJcbiAgbGV0IGZ1bGxUZXh0VXBncmFkZXMgPSAwO1xyXG4gIGNvbnN0IGxpdmVUd2VldHM6IHR5cGVvZiBub3JtYWxpemVkLnR3ZWV0cyA9IFtdO1xyXG4gIGNvbnN0IGZyZXNobmVzc0J5SWQgPSBuZXcgTWFwPHN0cmluZywgJ25ldycgfCAnZXhpc3RpbmcnPigpO1xyXG4gIGNvbnN0IGFjdGlvbkJ5SWQgPSBuZXcgTWFwPHN0cmluZywgVHdlZXRTaWdodGluZ1snYWN0aW9uJ10+KCk7XHJcbiAgZm9yIChjb25zdCB0IG9mIG5vcm1hbGl6ZWQudHdlZXRzKSB7XHJcbiAgICBjb25zdCBwcmV2ID0gY29tbWl0dGVkSWR4W3QuYWNjb3VudF9oYW5kbGVdPy5bdC50d2VldF9pZF07XHJcbiAgICBjb25zdCBvbGRCeVNuYXBzaG90ID0gIXByZXYgJiYgYXJjaGl2ZVNuYXBzaG90SGFzVHdlZXQodCwgYXJjaGl2ZVNuYXBzaG90KTtcclxuICAgIGNvbnN0IHByZXZpb3VzbHlBcmNoaXZlZCA9IEJvb2xlYW4ocHJldikgfHwgb2xkQnlTbmFwc2hvdDtcclxuICAgIGZyZXNobmVzc0J5SWQuc2V0KHQudHdlZXRfaWQsIHByZXZpb3VzbHlBcmNoaXZlZCA/ICdleGlzdGluZycgOiAnbmV3Jyk7XHJcbiAgICBpZiAob2xkQnlTbmFwc2hvdCkgb2xkRnJvbVNuYXBzaG90ICs9IDE7XHJcbiAgICBjb25zdCBzaWcgPSBlbmdhZ2VtZW50U2lnKFxyXG4gICAgICB0Lmxpa2VfY291bnQsXHJcbiAgICAgIHQucmV0d2VldF9jb3VudCxcclxuICAgICAgdC5yZXBseV9jb3VudCxcclxuICAgICAgdC5xdW90ZV9jb3VudCxcclxuICAgICAgdC5pc190cnVuY2F0ZWRcclxuICAgICk7XHJcbiAgICBjb25zdCBmdWxsVGV4dFVwZ3JhZGUgPSBwcmV2ICE9PSB1bmRlZmluZWQgJiYgc2lnTWFya3NUcnVuY2F0ZWQocHJldi5zaWcpICYmICF0LmlzX3RydW5jYXRlZDtcclxuICAgIGlmIChwcmV2aW91c2x5QXJjaGl2ZWQgJiYgIXVwZGF0ZUV4aXN0aW5nICYmICFmdWxsVGV4dFVwZ3JhZGUpIHtcclxuICAgICAgaWYgKHByZXYpIHNraXBwZWROb1VwZGF0ZUxvY2FsICs9IDE7XHJcbiAgICAgIGVsc2Ugc2tpcHBlZE5vVXBkYXRlU25hcHNob3QgKz0gMTtcclxuICAgICAgYWN0aW9uQnlJZC5zZXQodC50d2VldF9pZCwgJ3NraXBwZWQnKTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAocHJldiAmJiBwcmV2LnNpZyA9PT0gc2lnKSB7XHJcbiAgICAgIGRlZHVwZWRTa2lwcGVkICs9IDE7XHJcbiAgICAgIGFjdGlvbkJ5SWQuc2V0KHQudHdlZXRfaWQsICd1bmNoYW5nZWQnKTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAoZnVsbFRleHRVcGdyYWRlKSBmdWxsVGV4dFVwZ3JhZGVzICs9IDE7XHJcbiAgICBhY3Rpb25CeUlkLnNldCh0LnR3ZWV0X2lkLCAnYnVmZmVyZWQnKTtcclxuICAgIGxpdmVUd2VldHMucHVzaCh0KTtcclxuICB9XHJcbiAgaWYgKGRlZHVwZWRTa2lwcGVkID4gMCkge1xyXG4gICAgYXdhaXQgaW5mbygnZGVkdXA6IHNraXBwZWQgdW5jaGFuZ2VkIHR3ZWV0cycsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIHNraXBwZWQ6IGRlZHVwZWRTa2lwcGVkLFxyXG4gICAgICByZW1haW5pbmc6IGxpdmVUd2VldHMubGVuZ3RoLFxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIGlmIChza2lwcGVkTm9VcGRhdGVMb2NhbCArIHNraXBwZWROb1VwZGF0ZVNuYXBzaG90ID4gMCkge1xyXG4gICAgY29uc3Qgc2tpcHBlZE9sZCA9IHNraXBwZWROb1VwZGF0ZUxvY2FsICsgc2tpcHBlZE5vVXBkYXRlU25hcHNob3Q7XHJcbiAgICBhd2FpdCBpbmZvKCdkZWR1cDogc2tpcHBlZCBwcmV2aW91c2x5IGFyY2hpdmVkIHR3ZWV0cyAodXBkYXRlRXhpc3Rpbmc9ZmFsc2UpJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgc2tpcHBlZDogc2tpcHBlZE9sZCxcclxuICAgICAgbG9jYWxfaW5kZXg6IHNraXBwZWROb1VwZGF0ZUxvY2FsLFxyXG4gICAgICBhcmNoaXZlX3NuYXBzaG90OiBza2lwcGVkTm9VcGRhdGVTbmFwc2hvdCxcclxuICAgICAgcmVtYWluaW5nOiBsaXZlVHdlZXRzLmxlbmd0aCxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICAgIGlmIChhc1Nlc3MgIT09IG51bGwpIHtcclxuICAgICAgYXNTZXNzLnNraXBwZWRPbGRDb3VudCA9IChhc1Nlc3Muc2tpcHBlZE9sZENvdW50ID8/IDApICsgc2tpcHBlZE9sZDtcclxuICAgICAgYXdhaXQgc2V0QXV0b1Njcm9sbFNlc3Npb24oYXNTZXNzKTtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKG9sZEZyb21TbmFwc2hvdCA+IDAgJiYgdXBkYXRlRXhpc3RpbmcpIHtcclxuICAgIGF3YWl0IGluZm8oJ2FyY2hpdmUgc25hcHNob3QgcmVjb2duaXplZCBvbGQgdHdlZXRzJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgb2xkOiBvbGRGcm9tU25hcHNob3QsXHJcbiAgICAgIGFjdGlvbjogJ2J1ZmZlcmluZyBiZWNhdXNlIHVwZGF0ZUV4aXN0aW5nPXRydWUnLFxyXG4gICAgICBzbmFwc2hvdF9nZW5lcmF0ZWRfYXQ6IGFyY2hpdmVTbmFwc2hvdD8uZ2VuZXJhdGVkX2F0ID8/IG51bGwsXHJcbiAgICB9KTtcclxuICB9XHJcbiAgaWYgKGZ1bGxUZXh0VXBncmFkZXMgPiAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdkZWR1cDogYnVmZmVyaW5nIGZ1bGwtdGV4dCB1cGdyYWRlcycsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIHVwZ3JhZGVzOiBmdWxsVGV4dFVwZ3JhZGVzLFxyXG4gICAgICB1cGRhdGVFeGlzdGluZyxcclxuICAgICAgcmVtYWluaW5nOiBsaXZlVHdlZXRzLmxlbmd0aCxcclxuICAgIH0pO1xyXG4gIH1cclxuICBhd2FpdCBwcmVwZW5kUmVjZW50VHdlZXRTaWdodGluZ3MoXHJcbiAgICBub3JtYWxpemVkLnR3ZWV0cy5tYXAoKHQpID0+XHJcbiAgICAgIGJ1aWxkVHdlZXRTaWdodGluZyhcclxuICAgICAgICB0LFxyXG4gICAgICAgIGVuZHBvaW50LFxyXG4gICAgICAgIGNhcHR1cmVkQXQsXHJcbiAgICAgICAgZnJlc2huZXNzQnlJZC5nZXQodC50d2VldF9pZCksXHJcbiAgICAgICAgYWN0aW9uQnlJZC5nZXQodC50d2VldF9pZClcclxuICAgICAgKVxyXG4gICAgKVxyXG4gICk7XHJcbiAgLy8gLS0tIE1pc3NpbmctcGFyZW50IHJlY292ZXJ5IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuICAvLyBYJ3MgVXNlclR3ZWV0c0FuZFJlcGxpZXMgZW5kcG9pbnQgc29tZXRpbWVzIHNlcnZlcyBhIHJlcGx5IHdpdGhvdXQgdGhlXHJcbiAgLy8gcGFyZW50IHR3ZWV0IGl0IHBvaW50cyBhdCBcdTIwMTQgb25seSBhbiBpbl9yZXBseV90b19zY3JlZW5fbmFtZSBhbmNob3IuIFdlXHJcbiAgLy8gbmV2ZXIgc2VlIHRoYXQgcGFyZW50LCBzbyBpdCBuZXZlciBsYW5kcyBpbiB0aGUgYXJjaGl2ZS4gU2FtZSBmb3JcclxuICAvLyBxdW90ZWRfdHdlZXRfaWQgLyByZXR3ZWV0ZWRfdHdlZXRfaWQgd2hlbiBYIHN0cmlwcyB0aGUgcmVmZXJlbmNlZFxyXG4gIC8vIG5vZGUuIFdhbGsgdGhlIHR3ZWV0cyB3ZSBqdXN0IHNhdywgZmluZCBhbnkgcGFyZW50IElEIHdlIGRvbid0IGhhdmUsXHJcbiAgLy8gYW5kIGVucXVldWUgaXQgb24gdGhlIG1lZGlhLWNyYXdsIGxvb3Agc28gaXRzIGRldGFpbCBwYWdlIGdldHNcclxuICAvLyB2aXNpdGVkIGFuZCBpbmdlc3RlZCBuZXh0IHRpbWUgdGhlIHVzZXIgc3RhcnRzIHRoZSBjcmF3bC5cclxuICBhd2FpdCBlbnF1ZXVlTWlzc2luZ1BhcmVudHMobm9ybWFsaXplZC50d2VldHMsIGVuZHBvaW50KTtcclxuICBhd2FpdCBlbnF1ZXVlVGhyZWFkT3BlbkNhbmRpZGF0ZXMobm9ybWFsaXplZC50d2VldHMsIGNvcmUsIGVuZHBvaW50KTtcclxuICBjb25zdCBidWZmZXJlZFJldHdlZXRFZGdlcyA9IGF3YWl0IGJ1ZmZlclJldHdlZXRFZGdlcyhcclxuICAgIHJldHdlZXRFZGdlcyxcclxuICAgIGNhcHR1cmVkQXQsXHJcbiAgICBwYWdlVXJsID8/IHVybCxcclxuICAgIGVuZHBvaW50XHJcbiAgKTtcclxuICBpZiAobGl2ZVR3ZWV0cy5sZW5ndGggPT09IDApIHtcclxuICAgIGlmIChidWZmZXJlZFJldHdlZXRFZGdlcyA+IDApIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICAvLyBHcm91cCBzdXJ2aXZpbmcgdHdlZXRzIGJ5IGF1dGhvciBoYW5kbGUuXHJcbiAgY29uc3QgYnlIYW5kbGUgPSBuZXcgTWFwPHN0cmluZywgQ2Fub25pY2FsVHdlZXRbXT4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2YgbGl2ZVR3ZWV0cykge1xyXG4gICAgY29uc3QgYXJyID0gYnlIYW5kbGUuZ2V0KHQuYWNjb3VudF9oYW5kbGUpID8/IFtdO1xyXG4gICAgYXJyLnB1c2godCk7XHJcbiAgICBieUhhbmRsZS5zZXQodC5hY2NvdW50X2hhbmRsZSwgYXJyKTtcclxuICB9XHJcblxyXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgdHdlZXRzXSBvZiBieUhhbmRsZSkge1xyXG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgdXJsLCBlbmRwb2ludCk7XHJcbiAgICBsZXQgYWRkZWQgPSAwO1xyXG4gICAgbGV0IGFkZGVkTmV3ID0gMDtcclxuICAgIGxldCBhZGRlZEV4aXN0aW5nID0gMDtcclxuICAgIGxldCB1cGRhdGVkQnVmZmVyZWQgPSAwO1xyXG4gICAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xyXG4gICAgICBjb25zdCBleGlzdGluZyA9IGJ1Zi50d2VldHNfYnlfaWRbdC50d2VldF9pZF07XHJcbiAgICAgIGlmIChleGlzdGluZykge1xyXG4gICAgICAgIC8vIFByZXNlcnZlIGZpcnN0X2NhcHR1cmVkX2F0LCBhcHBlbmQgZW5nYWdlbWVudCBzbmFwc2hvdCwgcmVmcmVzaFxyXG4gICAgICAgIC8vIGxhc3Rfc2Vlbl9hdCArIGNvdW50cyAodGhlIGxhdGVzdCBzY3JhcGUgd2lucyBmb3IgY291bnRzKS5cclxuICAgICAgICBleGlzdGluZy5sYXN0X3NlZW5fYXQgPSBjYXB0dXJlZEF0O1xyXG4gICAgICAgIGV4aXN0aW5nLmxpa2VfY291bnQgPSB0Lmxpa2VfY291bnQ7XHJcbiAgICAgICAgZXhpc3RpbmcucmV0d2VldF9jb3VudCA9IHQucmV0d2VldF9jb3VudDtcclxuICAgICAgICBleGlzdGluZy5yZXBseV9jb3VudCA9IHQucmVwbHlfY291bnQ7XHJcbiAgICAgICAgZXhpc3RpbmcucXVvdGVfY291bnQgPSB0LnF1b3RlX2NvdW50O1xyXG4gICAgICAgIGV4aXN0aW5nLnZpZXdfY291bnQgPSB0LnZpZXdfY291bnQ7XHJcbiAgICAgICAgZXhpc3RpbmcuYm9va21hcmtfY291bnQgPSB0LmJvb2ttYXJrX2NvdW50O1xyXG4gICAgICAgIGNvbnN0IGxhc3QgPSBleGlzdGluZy5lbmdhZ2VtZW50X2hpc3RvcnlbZXhpc3RpbmcuZW5nYWdlbWVudF9oaXN0b3J5Lmxlbmd0aCAtIDFdO1xyXG4gICAgICAgIGNvbnN0IHNuYXAgPSB0LmVuZ2FnZW1lbnRfaGlzdG9yeVswXTtcclxuICAgICAgICBpZiAoc25hcCAmJiAoIWxhc3QgfHwgbGFzdC5jYXB0dXJlZF9hdCAhPT0gc25hcC5jYXB0dXJlZF9hdCkpIHtcclxuICAgICAgICAgIGV4aXN0aW5nLmVuZ2FnZW1lbnRfaGlzdG9yeS5wdXNoKHNuYXApO1xyXG4gICAgICAgIH1cclxuICAgICAgICB1cGRhdGVkQnVmZmVyZWQgKz0gMTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zdCBzdGFtcGVkOiBDYW5vbmljYWxUd2VldCA9IHsgLi4udCwgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQgfTtcclxuICAgICAgICBidWYudHdlZXRzX2J5X2lkW3QudHdlZXRfaWRdID0gc3RhbXBlZDtcclxuICAgICAgICBhZGRlZCArPSAxO1xyXG4gICAgICAgIGlmIChmcmVzaG5lc3NCeUlkLmdldCh0LnR3ZWV0X2lkKSA9PT0gJ2V4aXN0aW5nJykgYWRkZWRFeGlzdGluZyArPSAxO1xyXG4gICAgICAgIGVsc2UgYWRkZWROZXcgKz0gMTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoIWJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQuaW5jbHVkZXModC50d2VldF9pZCkpIHtcclxuICAgICAgICBidWYudHdlZXRfaWRzX29ic2VydmVkLnB1c2godC50d2VldF9pZCk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xyXG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XHJcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xyXG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIHJ1bkJ1ZmZlckl0ZW1Db3VudChidWYpKTtcclxuICAgIGlmIChhZGRlZCA+IDAgfHwgdXBkYXRlZEJ1ZmZlcmVkID4gMCkge1xyXG4gICAgICBhd2FpdCBpbmZvKCdidWZmZXJlZCB0d2VldHMnLCB7XHJcbiAgICAgICAgaGFuZGxlLFxyXG4gICAgICAgIGVuZHBvaW50LFxyXG4gICAgICAgIGFkZGVkLFxyXG4gICAgICAgIG5ldzogYWRkZWROZXcsXHJcbiAgICAgICAgZXhpc3Rpbmc6IGFkZGVkRXhpc3RpbmcsXHJcbiAgICAgICAgdXBkYXRlZF9idWZmZXJlZDogdXBkYXRlZEJ1ZmZlcmVkLFxyXG4gICAgICAgIHRvdGFsOiBPYmplY3Qua2V5cyhidWYudHdlZXRzX2J5X2lkKS5sZW5ndGgsXHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyBCdW1wIHRoZSBhdXRvLXNjcm9sbCBwcm9ncmVzcyBzbyB0aGUgdXNlciBzZWVzIFwiWCBpbmdlc3RlZFwiIHRpY2sgdXBcclxuICAgICAgLy8gaW4gcmVhbCB0aW1lLiBXZSBjb3VudCBhY3R1YWxseS1uZXcgdHdlZXRzLCBub3QgZHVwbGljYXRlcy5cclxuICAgICAgY29uc3QgYXNTZXNzID0gYXdhaXQgZ2V0QXV0b1Njcm9sbFNlc3Npb24oKTtcclxuICAgICAgaWYgKGFzU2VzcyAhPT0gbnVsbCkge1xyXG4gICAgICAgIGFzU2Vzcy5pbmdlc3RlZENvdW50ICs9IGFkZGVkO1xyXG4gICAgICAgIGFzU2Vzcy5pbmdlc3RlZE5ld0NvdW50ID0gKGFzU2Vzcy5pbmdlc3RlZE5ld0NvdW50ID8/IDApICsgYWRkZWROZXc7XHJcbiAgICAgICAgYXNTZXNzLmluZ2VzdGVkRXhpc3RpbmdDb3VudCA9IChhc1Nlc3MuaW5nZXN0ZWRFeGlzdGluZ0NvdW50ID8/IDApICsgYWRkZWRFeGlzdGluZztcclxuICAgICAgICBhd2FpdCBzZXRBdXRvU2Nyb2xsU2Vzc2lvbihhc1Nlc3MpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoT2JqZWN0LmtleXMoYnVmLnR3ZWV0c19ieV9pZCkubGVuZ3RoID49IEZMVVNIX1RXRUVUX1RIUkVTSE9MRCkge1xyXG4gICAgICBhd2FpdCBmbHVzaEhhbmRsZShoYW5kbGUsICd0aHJlc2hvbGQnKTtcclxuICAgIH1cclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVjb3JkVW5hdmFpbGFibGVUd2VldHMoXHJcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXSxcclxuICB0cmFja2VkOiBSZWFkb25seVNldDxzdHJpbmc+LFxyXG4gIGNhcHR1cmVkQXQ6IHN0cmluZyxcclxuICBzb3VyY2VVcmw6IHN0cmluZyxcclxuICBlbmRwb2ludDogc3RyaW5nXHJcbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGNvbW1pdHRlZElkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XHJcbiAgY29uc3QgcmVmZXRjaFNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xyXG4gIGNvbnN0IG1lZGlhQ3Jhd2xTZXNzID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFNlc3Npb24oKTtcclxuICBjb25zdCB0aHJlYWRPcGVuU2VzcyA9IGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCk7XHJcbiAgbGV0IHJlY29yZGVkID0gMDtcclxuICBsZXQgc2tpcHBlZCA9IDA7XHJcbiAgbGV0IG1pc3NpbmdIYW5kbGUgPSAwO1xyXG5cclxuICBmb3IgKGNvbnN0IHUgb2YgdW5hdmFpbGFibGVUd2VldHMpIHtcclxuICAgIGNvbnN0IGhhbmRsZSA9IHUuYWNjb3VudF9oYW5kbGU7XHJcbiAgICBpZiAoIWhhbmRsZSkge1xyXG4gICAgICBtaXNzaW5nSGFuZGxlICs9IDE7XHJcbiAgICAgIGF3YWl0IGRlcXVldWVNZWRpYUNyYXdsKHUudHdlZXRfaWQpO1xyXG4gICAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih1LnR3ZWV0X2lkKTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcbiAgICBpZiAodHJhY2tlZC5zaXplID4gMCAmJiAhdHJhY2tlZC5oYXMoaGFuZGxlLnRvTG93ZXJDYXNlKCkpKSB7XHJcbiAgICAgIHNraXBwZWQgKz0gMTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodS50d2VldF9pZCk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaChoYW5kbGUsIHUudHdlZXRfaWQpO1xyXG4gICAgYXdhaXQgZGVxdWV1ZVRocmVhZE9wZW4odS50d2VldF9pZCk7XHJcbiAgICBpZiAocmVmZXRjaFNlc3M/LmluZmxpZ2h0Py50d2VldElkID09PSB1LnR3ZWV0X2lkKSB7XHJcbiAgICAgIHJlZmV0Y2hTZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgICAgcmVmZXRjaFNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKHJlZmV0Y2hTZXNzKTtcclxuICAgIH1cclxuICAgIGlmIChtZWRpYUNyYXdsU2Vzcz8uaW5mbGlnaHQ/LnR3ZWV0SWQgPT09IHUudHdlZXRfaWQpIHtcclxuICAgICAgbWVkaWFDcmF3bFNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgICBtZWRpYUNyYXdsU2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obWVkaWFDcmF3bFNlc3MpO1xyXG4gICAgfVxyXG4gICAgaWYgKHRocmVhZE9wZW5TZXNzPy5pbmZsaWdodD8udHdlZXRJZCA9PT0gdS50d2VldF9pZCkge1xyXG4gICAgICB0aHJlYWRPcGVuU2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICAgIHRocmVhZE9wZW5TZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgICBhd2FpdCBtYXJrVGhyZWFkT3BlblNlZW4odS50d2VldF9pZCk7XHJcbiAgICAgIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHRocmVhZE9wZW5TZXNzKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzaWcgPSB1bmF2YWlsYWJsZVNpZyh1KTtcclxuICAgIGNvbnN0IHByZXYgPSBjb21taXR0ZWRJZHhbaGFuZGxlXT8uW3UudHdlZXRfaWRdO1xyXG4gICAgaWYgKHByZXY/LnNpZyA9PT0gc2lnKSB7XHJcbiAgICAgIHNraXBwZWQgKz0gMTtcclxuICAgICAgY29udGludWU7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgYnVmID0gYXdhaXQgZW5zdXJlUnVuQnVmZmVyKGhhbmRsZSwgY2FwdHVyZWRBdCwgc291cmNlVXJsLCBlbmRwb2ludCk7XHJcbiAgICBjb25zdCB1bmF2YWlsYWJsZUJ5SWQgPSBidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge307XHJcbiAgICB1bmF2YWlsYWJsZUJ5SWRbdS50d2VldF9pZF0gPSB1O1xyXG4gICAgYnVmLnVuYXZhaWxhYmxlX2J5X2lkID0gdW5hdmFpbGFibGVCeUlkO1xyXG4gICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHUudHdlZXRfaWQpKSB7XHJcbiAgICAgIGJ1Zi50d2VldF9pZHNfb2JzZXJ2ZWQucHVzaCh1LnR3ZWV0X2lkKTtcclxuICAgIH1cclxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xyXG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XHJcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xyXG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIHJ1bkJ1ZmZlckl0ZW1Db3VudChidWYpKTtcclxuICAgIHJlY29yZGVkICs9IDE7XHJcbiAgfVxyXG5cclxuICBpZiAocmVjb3JkZWQgPiAwIHx8IG1pc3NpbmdIYW5kbGUgPiAwIHx8IHNraXBwZWQgPiAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCd1bmF2YWlsYWJsZSB0d2VldHMgb2JzZXJ2ZWQnLCB7IGVuZHBvaW50LCByZWNvcmRlZCwgc2tpcHBlZCwgbWlzc2luZ0hhbmRsZSB9KTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gdW5hdmFpbGFibGVTaWcodTogVW5hdmFpbGFibGVUd2VldCk6IHN0cmluZyB7XHJcbiAgcmV0dXJuIGB1bmF2YWlsYWJsZXwke3UudW5hdmFpbGFibGVfcmVhc29uID8/ICcnfXwke3UudW5hdmFpbGFibGVfdGV4dCA/PyAnJ31gO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzaWdNYXJrc1RydW5jYXRlZChzaWc6IHN0cmluZyk6IGJvb2xlYW4ge1xyXG4gIGNvbnN0IHBhcnRzID0gc2lnLnNwbGl0KCd8Jyk7XHJcbiAgcmV0dXJuIHBhcnRzW3BhcnRzLmxlbmd0aCAtIDFdID09PSAndCc7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJ1bkJ1ZmZlckl0ZW1Db3VudChidWY6IFJ1bkJ1ZmZlcik6IG51bWJlciB7XHJcbiAgcmV0dXJuIChcclxuICAgIE9iamVjdC5rZXlzKGJ1Zi50d2VldHNfYnlfaWQpLmxlbmd0aCArXHJcbiAgICBPYmplY3Qua2V5cyhidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge30pLmxlbmd0aCArXHJcbiAgICBPYmplY3Qua2V5cyhidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge30pLmxlbmd0aFxyXG4gICk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJldHdlZXRFZGdlS2V5KGVkZ2U6IFJldHdlZXRFZGdlKTogc3RyaW5nIHtcclxuICByZXR1cm4gW2VkZ2UucmV0d2VldGVyX2hhbmRsZS50b0xvd2VyQ2FzZSgpLCBlZGdlLnJldHdlZXRfdHdlZXRfaWQsIGVkZ2Uub3JpZ2luYWxfdHdlZXRfaWRdLmpvaW4oXHJcbiAgICAnfCdcclxuICApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBpbmZlclJldHdlZXRlZEhhbmRsZSh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcclxuICBjb25zdCBtYXRjaCA9IHRleHQubWF0Y2goL15SVFxccytAKFtBLVphLXowLTlfXXsxLDE1fSlcXGIvaSk7XHJcbiAgcmV0dXJuIG1hdGNoPy5bMV0gPz8gbnVsbDtcclxufVxyXG5cclxuZnVuY3Rpb24gYnVpbGRSZXR3ZWV0RWRnZXMoXHJcbiAgdHdlZXRzOiBSZWFkb25seUFycmF5PENhbm9uaWNhbFR3ZWV0PixcclxuICBhY2NvdW50czogUmVhZG9ubHlBcnJheTx7IGhhbmRsZTogc3RyaW5nOyBjYXRlZ29yeTogc3RyaW5nIH0+LFxyXG4gIGNhcHR1cmVkQXQ6IHN0cmluZyxcclxuICBlbmRwb2ludDogc3RyaW5nLFxyXG4gIHNvdXJjZVVybDogc3RyaW5nIHwgbnVsbFxyXG4pOiBSZXR3ZWV0RWRnZVtdIHtcclxuICBjb25zdCBjYXRlZ29yeUJ5SGFuZGxlID0gbmV3IE1hcChhY2NvdW50cy5tYXAoKGEpID0+IFthLmhhbmRsZS50b0xvd2VyQ2FzZSgpLCBhLmNhdGVnb3J5XSkpO1xyXG4gIGNvbnN0IGJ5SWQgPSBuZXcgTWFwKHR3ZWV0cy5tYXAoKHQpID0+IFt0LnR3ZWV0X2lkLCB0XSkpO1xyXG4gIGNvbnN0IG91dCA9IG5ldyBNYXA8c3RyaW5nLCBSZXR3ZWV0RWRnZT4oKTtcclxuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XHJcbiAgICBpZiAodC50d2VldF90eXBlICE9PSAncmV0d2VldCcgfHwgIXQucmV0d2VldGVkX3R3ZWV0X2lkKSBjb250aW51ZTtcclxuICAgIGNvbnN0IHJldHdlZXRlckNhdGVnb3J5ID0gY2F0ZWdvcnlCeUhhbmRsZS5nZXQodC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpKTtcclxuICAgIGlmICghcmV0d2VldGVyQ2F0ZWdvcnkpIGNvbnRpbnVlO1xyXG4gICAgY29uc3Qgb3JpZ2luYWwgPSBieUlkLmdldCh0LnJldHdlZXRlZF90d2VldF9pZCk7XHJcbiAgICBjb25zdCBvcmlnaW5hbEhhbmRsZSA9XHJcbiAgICAgIG9yaWdpbmFsPy5hY2NvdW50X2hhbmRsZSA/PyBpbmZlclJldHdlZXRlZEhhbmRsZSh0LnRleHRfcmVzb2x2ZWQgfHwgdC50ZXh0KTtcclxuICAgIGNvbnN0IG9yaWdpbmFsQ2F0ZWdvcnkgPSBvcmlnaW5hbEhhbmRsZVxyXG4gICAgICA/IChjYXRlZ29yeUJ5SGFuZGxlLmdldChvcmlnaW5hbEhhbmRsZS50b0xvd2VyQ2FzZSgpKSA/PyAncHVibGljJylcclxuICAgICAgOiBudWxsO1xyXG4gICAgY29uc3QgZWRnZTogUmV0d2VldEVkZ2UgPSB7XHJcbiAgICAgIHJldHdlZXRlcl9oYW5kbGU6IHQuYWNjb3VudF9oYW5kbGUsXHJcbiAgICAgIHJldHdlZXRlcl9hY2NvdW50X2lkOiB0LmFjY291bnRfaWQgPz8gbnVsbCxcclxuICAgICAgcmV0d2VldGVyX2NhdGVnb3J5OiByZXR3ZWV0ZXJDYXRlZ29yeSxcclxuICAgICAgcmV0d2VldF90d2VldF9pZDogdC50d2VldF9pZCxcclxuICAgICAgcmV0d2VldF91cmw6IHQudHdlZXRfdXJsLFxyXG4gICAgICBvcmlnaW5hbF90d2VldF9pZDogdC5yZXR3ZWV0ZWRfdHdlZXRfaWQsXHJcbiAgICAgIG9yaWdpbmFsX2F1dGhvcl9oYW5kbGU6IG9yaWdpbmFsSGFuZGxlLFxyXG4gICAgICBvcmlnaW5hbF9hdXRob3JfYWNjb3VudF9pZDogb3JpZ2luYWw/LmFjY291bnRfaWQgPz8gbnVsbCxcclxuICAgICAgb3JpZ2luYWxfYXV0aG9yX2NhdGVnb3J5OiBvcmlnaW5hbENhdGVnb3J5LFxyXG4gICAgICBjYXB0dXJlZF9hdDogY2FwdHVyZWRBdCxcclxuICAgICAgY2FwdHVyZV9ydW5faWQ6ICdwZW5kaW5nJyxcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIHNvdXJjZV91cmw6IHNvdXJjZVVybCxcclxuICAgIH07XHJcbiAgICBvdXQuc2V0KHJldHdlZXRFZGdlS2V5KGVkZ2UpLCBlZGdlKTtcclxuICB9XHJcbiAgcmV0dXJuIFsuLi5vdXQudmFsdWVzKCldO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBidWZmZXJSZXR3ZWV0RWRnZXMoXHJcbiAgZWRnZXM6IFJlYWRvbmx5QXJyYXk8UmV0d2VldEVkZ2U+LFxyXG4gIGNhcHR1cmVkQXQ6IHN0cmluZyxcclxuICBzb3VyY2VVcmw6IHN0cmluZyxcclxuICBlbmRwb2ludDogc3RyaW5nXHJcbik6IFByb21pc2U8bnVtYmVyPiB7XHJcbiAgaWYgKGVkZ2VzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIDA7XHJcbiAgY29uc3QgYnlIYW5kbGUgPSBuZXcgTWFwPHN0cmluZywgUmV0d2VldEVkZ2VbXT4oKTtcclxuICBmb3IgKGNvbnN0IGVkZ2Ugb2YgZWRnZXMpIHtcclxuICAgIGNvbnN0IGFyciA9IGJ5SGFuZGxlLmdldChlZGdlLnJldHdlZXRlcl9oYW5kbGUpID8/IFtdO1xyXG4gICAgYXJyLnB1c2goZWRnZSk7XHJcbiAgICBieUhhbmRsZS5zZXQoZWRnZS5yZXR3ZWV0ZXJfaGFuZGxlLCBhcnIpO1xyXG4gIH1cclxuICBsZXQgYWRkZWQgPSAwO1xyXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgaGFuZGxlRWRnZXNdIG9mIGJ5SGFuZGxlKSB7XHJcbiAgICBjb25zdCBidWYgPSBhd2FpdCBlbnN1cmVSdW5CdWZmZXIoaGFuZGxlLCBjYXB0dXJlZEF0LCBzb3VyY2VVcmwsIGVuZHBvaW50KTtcclxuICAgIGNvbnN0IGVkZ2VNYXAgPSBidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge307XHJcbiAgICBsZXQgYWRkZWRGb3JIYW5kbGUgPSAwO1xyXG4gICAgZm9yIChjb25zdCBlZGdlIG9mIGhhbmRsZUVkZ2VzKSB7XHJcbiAgICAgIGNvbnN0IHN0YW1wZWQ6IFJldHdlZXRFZGdlID0geyAuLi5lZGdlLCBjYXB0dXJlX3J1bl9pZDogYnVmLnJ1bl9pZCB9O1xyXG4gICAgICBjb25zdCBrZXkgPSByZXR3ZWV0RWRnZUtleShzdGFtcGVkKTtcclxuICAgICAgaWYgKCFlZGdlTWFwW2tleV0pIGFkZGVkRm9ySGFuZGxlICs9IDE7XHJcbiAgICAgIGVkZ2VNYXBba2V5XSA9IHN0YW1wZWQ7XHJcbiAgICAgIGlmICghYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5pbmNsdWRlcyhzdGFtcGVkLnJldHdlZXRfdHdlZXRfaWQpKSB7XHJcbiAgICAgICAgYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5wdXNoKHN0YW1wZWQucmV0d2VldF90d2VldF9pZCk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKCFidWYudHdlZXRfaWRzX29ic2VydmVkLmluY2x1ZGVzKHN0YW1wZWQub3JpZ2luYWxfdHdlZXRfaWQpKSB7XHJcbiAgICAgICAgYnVmLnR3ZWV0X2lkc19vYnNlcnZlZC5wdXNoKHN0YW1wZWQub3JpZ2luYWxfdHdlZXRfaWQpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoYWRkZWRGb3JIYW5kbGUgPT09IDApIGNvbnRpbnVlO1xyXG4gICAgYnVmLnJldHdlZXRfZWRnZXNfYnlfa2V5ID0gZWRnZU1hcDtcclxuICAgIGlmICghYnVmLmVuZHBvaW50c19zZWVuLmluY2x1ZGVzKGVuZHBvaW50KSkgYnVmLmVuZHBvaW50c19zZWVuLnB1c2goZW5kcG9pbnQpO1xyXG4gICAgYnVmLmxhc3RfY2FwdHVyZV9hdCA9IGNhcHR1cmVkQXQ7XHJcbiAgICBhd2FpdCBzZXRSdW5CdWZmZXIoaGFuZGxlLCBidWYpO1xyXG4gICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIHJ1bkJ1ZmZlckl0ZW1Db3VudChidWYpKTtcclxuICAgIGFkZGVkICs9IGFkZGVkRm9ySGFuZGxlO1xyXG4gICAgYXdhaXQgaW5mbygnYnVmZmVyZWQgcmV0d2VldCBlZGdlcycsIHtcclxuICAgICAgaGFuZGxlLFxyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgYWRkZWQ6IGFkZGVkRm9ySGFuZGxlLFxyXG4gICAgICB0b3RhbDogT2JqZWN0LmtleXMoZWRnZU1hcCkubGVuZ3RoLFxyXG4gICAgfSk7XHJcbiAgfVxyXG4gIHJldHVybiBhZGRlZDtcclxufVxyXG5cclxuLyoqXHJcbiAqIEZpbmQgZXZlcnkgcGFyZW50IHR3ZWV0IHJlZmVyZW5jZWQgYnkgdGhlIGNhcHR1cmVzIHdlIGp1c3QgaW5nZXN0ZWRcclxuICogKGByZXBseV90b190d2VldF9pZGAsIGBxdW90ZWRfdHdlZXRfaWRgLCBgcmV0d2VldGVkX3R3ZWV0X2lkYCkgdGhhdCB3ZVxyXG4gKiBkb24ndCB5ZXQgaGF2ZSBpbiB0aGUgYXJjaGl2ZSwgYW5kIGVucXVldWUgaXQgb24gdGhlIG1lZGlhLWNyYXdsIGxvb3AuXHJcbiAqXHJcbiAqIFdoeTogWCdzIFVzZXJUd2VldHNBbmRSZXBsaWVzIGVuZHBvaW50IHNvbWV0aW1lcyByZXR1cm5zIGEgdHJhY2tlZFxyXG4gKiBhY2NvdW50J3MgcmVwbHkgKndpdGhvdXQqIHRoZSBwYXJlbnQgaXQgcG9pbnRzIGF0LiBUaGUgYHJlcGx5X3RvXypgXHJcbiAqIGZpZWxkcyBvbiB0aGUgcmVwbHkgc3RpbGwgZ2V0IHNldCBmcm9tIGBpbl9yZXBseV90b19zdGF0dXNfaWRfc3RyYCwgYnV0XHJcbiAqIGBmaWx0ZXJSZWxhdGVkYCBoYXMgbm90aGluZyB0byBrZWVwIFx1MjAxNCB0aGVyZSBpcyBubyBwYXJlbnQgbm9kZSBpbiB0aGVcclxuICogYmF0Y2ggdG8ga2VlcC4gUmVzdWx0OiB0aGUgYXJjaGl2ZSBzaG93cyBESFNnb3YncyByZXBseSBidXQgbm90IHRoZVxyXG4gKiBvcmlnaW5hbCBpdCdzIHJlcGx5aW5nIHRvLiBTeW1tZXRyaWMgcHJvYmxlbSBmb3Igb3JwaGFuZWQgcXVvdGUgLyBSVFxyXG4gKiBwb2ludGVycy5cclxuICpcclxuICogUmV1c2luZyB0aGUgbWVkaWEtY3Jhd2wgcXVldWUgKyBsb29wIG1lYW5zIG5vIG5ldyBVSTsgdGhlIHVzZXIgYWxyZWFkeVxyXG4gKiBzdGFydHMgaXQgbWFudWFsbHkgd2hlbiB0aGV5IHdhbnQgdG8gZmV0Y2ggcGFydGlhbC1jYXB0dXJlZCB0d2VldHMuXHJcbiAqIFNhbWUgZGVkdXAgcnVsZXMgYXBwbHkgKGNvbW1pdHRlZCBcdTIxOTIgc2tpcDsgYWxyZWFkeSBxdWV1ZWQgXHUyMTkyIG5vLW9wKS5cclxuICpcclxuICogV2Ugb25seSB3YWxrIHRoZSB0d2VldHMgdGhhdCBzdXJ2aXZlZCBgZmlsdGVyUmVsYXRlZGAgc28gd2UgZG9uJ3QgY3Jhd2xcclxuICogcGFyZW50cyBvZiByYW5kb20gcmVwbGllcyB0aGF0IHdvdWxkbid0IGhhdmUgYmVlbiBrZXB0IGFueXdheS5cclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGVucXVldWVNaXNzaW5nUGFyZW50cyhcclxuICB0d2VldHM6IFJlYWRvbmx5QXJyYXk8Q2Fub25pY2FsVHdlZXQ+LFxyXG4gIGVuZHBvaW50OiBzdHJpbmdcclxuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICAvLyBCdWlsZCBhIHNhbWUtYmF0Y2ggSUQgc2V0IHNvIHdlIGRvbid0IGVucXVldWUgYSBwYXJlbnQgdGhhdCBhbHJlYWR5XHJcbiAgLy8gYXJyaXZlZCBpbiB0aGlzIHZlcnkgcmVzcG9uc2UuXHJcbiAgY29uc3Qgc2FtZUJhdGNoSWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykgc2FtZUJhdGNoSWRzLmFkZCh0LnR3ZWV0X2lkKTtcclxuXHJcbiAgbGV0IGVucXVldWVkID0gMDtcclxuICBmb3IgKGNvbnN0IHQgb2YgdHdlZXRzKSB7XHJcbiAgICBjb25zdCBwYXJlbnRzOiBBcnJheTx7IGlkOiBzdHJpbmc7IGhpbnQ6IHN0cmluZyB8IG51bGwgfT4gPSBbXTtcclxuICAgIGlmICh0LnJlcGx5X3RvX3R3ZWV0X2lkKSB7XHJcbiAgICAgIHBhcmVudHMucHVzaCh7IGlkOiB0LnJlcGx5X3RvX3R3ZWV0X2lkLCBoaW50OiB0LnJlcGx5X3RvX2FjY291bnQgfSk7XHJcbiAgICB9XHJcbiAgICBpZiAodC5xdW90ZWRfdHdlZXRfaWQpIHBhcmVudHMucHVzaCh7IGlkOiB0LnF1b3RlZF90d2VldF9pZCwgaGludDogbnVsbCB9KTtcclxuICAgIGlmICh0LnJldHdlZXRlZF90d2VldF9pZCkgcGFyZW50cy5wdXNoKHsgaWQ6IHQucmV0d2VldGVkX3R3ZWV0X2lkLCBoaW50OiBudWxsIH0pO1xyXG4gICAgZm9yIChjb25zdCBwIG9mIHBhcmVudHMpIHtcclxuICAgICAgaWYgKHNhbWVCYXRjaElkcy5oYXMocC5pZCkpIGNvbnRpbnVlO1xyXG4gICAgICBpZiAoYXdhaXQgaXNDb21taXR0ZWQocC5pZCkpIGNvbnRpbnVlO1xyXG4gICAgICBhd2FpdCBlbnF1ZXVlTWVkaWFDcmF3bChwLmhpbnQsIHAuaWQpO1xyXG4gICAgICBlbnF1ZXVlZCArPSAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBpZiAoZW5xdWV1ZWQgPiAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdxdWV1ZWQgbWlzc2luZyBwYXJlbnQgdHdlZXRzIGZvciBkZXRhaWwtcGFnZSBjcmF3bCcsIHtcclxuICAgICAgZW5kcG9pbnQsXHJcbiAgICAgIGVucXVldWVkLFxyXG4gICAgICBxdWV1ZV90b3RhbDogYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKSxcclxuICAgIH0pO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVRocmVhZE9wZW5DYW5kaWRhdGVzKFxyXG4gIHR3ZWV0czogUmVhZG9ubHlBcnJheTxDYW5vbmljYWxUd2VldD4sXHJcbiAgY29yZUhhbmRsZXM6IFJlYWRvbmx5U2V0PHN0cmluZz4sXHJcbiAgZW5kcG9pbnQ6IHN0cmluZ1xyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuICBpZiAodHdlZXRzLmxlbmd0aCA9PT0gMCB8fCBjb3JlSGFuZGxlcy5zaXplID09PSAwKSByZXR1cm47XHJcbiAgaWYgKGVuZHBvaW50LmluY2x1ZGVzKCdUd2VldERldGFpbCcpIHx8IGVuZHBvaW50LmluY2x1ZGVzKCdUd2VldFJlc3VsdEJ5UmVzdElkJykpIHJldHVybjtcclxuXHJcbiAgY29uc3QgY2FuZGlkYXRlcyA9IG5ldyBNYXA8c3RyaW5nLCBzdHJpbmc+KCk7XHJcbiAgZm9yIChjb25zdCB0IG9mIHR3ZWV0cykge1xyXG4gICAgY29uc3QgaGFuZGxlID0gdC5hY2NvdW50X2hhbmRsZS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgaWYgKCFjb3JlSGFuZGxlcy5oYXMoaGFuZGxlKSkgY29udGludWU7XHJcblxyXG4gICAgY29uc3Qgcm9vdElkID0gdC5jb252ZXJzYXRpb25faWQgPz8gdC50d2VldF9pZDtcclxuICAgIGNvbnN0IGlzUm9vdCA9IHJvb3RJZCA9PT0gdC50d2VldF9pZCB8fCB0LnJlcGx5X3RvX3R3ZWV0X2lkID09PSBudWxsO1xyXG4gICAgY29uc3QgaXNDb3JlUmVwbHkgPSB0LnJlcGx5X3RvX3R3ZWV0X2lkICE9PSBudWxsO1xyXG4gICAgaWYgKGlzUm9vdCAmJiB0LnJlcGx5X2NvdW50ID4gMCkge1xyXG4gICAgICBjYW5kaWRhdGVzLnNldChyb290SWQsIHQuYWNjb3VudF9oYW5kbGUpO1xyXG4gICAgfSBlbHNlIGlmIChpc0NvcmVSZXBseSAmJiByb290SWQpIHtcclxuICAgICAgY2FuZGlkYXRlcy5zZXQocm9vdElkLCB0LmFjY291bnRfaGFuZGxlKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGxldCBlbnF1ZXVlZCA9IDA7XHJcbiAgZm9yIChjb25zdCBbdHdlZXRJZCwgaGFuZGxlXSBvZiBjYW5kaWRhdGVzKSB7XHJcbiAgICBjb25zdCBiZWZvcmUgPSBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpO1xyXG4gICAgYXdhaXQgZW5xdWV1ZVRocmVhZE9wZW4oaGFuZGxlLCB0d2VldElkKTtcclxuICAgIGNvbnN0IGFmdGVyID0gYXdhaXQgdGhyZWFkT3BlblF1ZXVlVG90YWwoKTtcclxuICAgIGlmIChhZnRlciA+IGJlZm9yZSkgZW5xdWV1ZWQgKz0gMTtcclxuICB9XHJcbiAgaWYgKGVucXVldWVkID4gMCkge1xyXG4gICAgYXdhaXQgaW5mbygncXVldWVkIGNvcmUgdGhyZWFkIHJvb3RzIGZvciBvcGVuaW5nJywge1xyXG4gICAgICBlbmRwb2ludCxcclxuICAgICAgZW5xdWV1ZWQsXHJcbiAgICAgIHF1ZXVlX3RvdGFsOiBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpLFxyXG4gICAgfSk7XHJcbiAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBlbnN1cmVSdW5CdWZmZXIoXHJcbiAgaGFuZGxlOiBzdHJpbmcsXHJcbiAgdHM6IHN0cmluZyxcclxuICBzb3VyY2VVcmw6IHN0cmluZyxcclxuICBlbmRwb2ludDogc3RyaW5nXHJcbik6IFByb21pc2U8UnVuQnVmZmVyPiB7XHJcbiAgY29uc3QgY3VyID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGhhbmRsZSk7XHJcbiAgaWYgKGN1cikgcmV0dXJuIGN1cjtcclxuICBjb25zdCBidWY6IFJ1bkJ1ZmZlciA9IHtcclxuICAgIHJ1bl9pZDogbmV3UnVuSWQoKSxcclxuICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXHJcbiAgICBzdGFydGVkX2F0OiB0cyxcclxuICAgIGxhc3RfY2FwdHVyZV9hdDogdHMsXHJcbiAgICB0d2VldHNfYnlfaWQ6IHt9LFxyXG4gICAgdW5hdmFpbGFibGVfYnlfaWQ6IHt9LFxyXG4gICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcclxuICAgIGVuZHBvaW50c19zZWVuOiBbZW5kcG9pbnRdLFxyXG4gICAgc291cmNlX3VybDogc291cmNlVXJsLFxyXG4gIH07XHJcbiAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwgYnVmKTtcclxuICBhd2FpdCBpbmZvKCdydW4gc3RhcnRlZCcsIHsgaGFuZGxlLCBydW46IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCkgfSk7XHJcbiAgcmV0dXJuIGJ1ZjtcclxufVxyXG5cclxuLy8gLS0tIEZsdXNoIGxvZ2ljIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmxldCBmbHVzaENoYWluOiBQcm9taXNlPHZvaWQ+ID0gUHJvbWlzZS5yZXNvbHZlKCk7XHJcblxyXG5pbnRlcmZhY2UgRmx1c2hJdGVtIHtcclxuICBoYW5kbGU6IHN0cmluZztcclxuICBidWY6IFJ1bkJ1ZmZlcjtcclxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W107XHJcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXTtcclxuICByZXR3ZWV0RWRnZXM6IFJldHdlZXRFZGdlW107XHJcbiAgcmF3UGF0aDogc3RyaW5nO1xyXG4gIHNlZW5QYXRoOiBzdHJpbmc7XHJcbiAgY2FwdHVyZTogQ2FwdHVyZVBheWxvYWQ7XHJcbiAgc2VlbjogU2VlblBheWxvYWQ7XHJcbiAgZGF5OiBzdHJpbmc7XHJcbiAgcnVuU2hvcnQ6IHN0cmluZztcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZmx1c2hJZGxlQnVmZmVycygpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XHJcbiAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcclxuICBjb25zdCBoYW5kbGVzOiBzdHJpbmdbXSA9IFtdO1xyXG4gIGZvciAoY29uc3QgW2hhbmRsZSwgYnVmXSBvZiBPYmplY3QuZW50cmllcyhhbGwpKSB7XHJcbiAgICBjb25zdCBsYXN0ID0gRGF0ZS5wYXJzZShidWYubGFzdF9jYXB0dXJlX2F0KTtcclxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUobGFzdCkgJiYgbm93IC0gbGFzdCA+PSBGTFVTSF9JRExFX01TKSB7XHJcbiAgICAgIGhhbmRsZXMucHVzaChoYW5kbGUpO1xyXG4gICAgfVxyXG4gIH1cclxuICBhd2FpdCBmbHVzaEhhbmRsZXMoaGFuZGxlcywgJ2lkbGUnKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZmx1c2hPcnBoYW5lZEJ1ZmZlcnNJZlN0YWxlKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIC8vIE9uIHdvcmtlciB3YWtlLCBhbnkgYnVmZmVyIG9sZGVyIHRoYW4gdGhlIGlkbGUgdGhyZXNob2xkIGdldHMgYSBjaGFuY2UgdG9cclxuICAvLyBjb21taXQgaW1tZWRpYXRlbHkgXHUyMDE0IHVzZWZ1bCB3aGVuIHRoZSB3b3JrZXIgd2FzIGV2aWN0ZWQgYmVmb3JlIGlkbGUtZmx1c2guXHJcbiAgLy8gSWYgdGhlIFBBVC9vd25lci9yZXBvIGFyZW4ndCBzZXQgd2UnZCBqdXN0IGVtaXQgXCJmbHVzaCBkZWZlcnJlZFwiIGZvciBldmVyeVxyXG4gIC8vIHNpbmdsZSBoYW5kbGUgaW4gc3RvcmFnZSAodGhlIGRpYWdub3N0aWMgc2hvd2VkIHRoaXMgZmlyaW5nIDMwMCsgdGltZXMgaW5cclxuICAvLyBhIHJvdyB3aGVuIHRoZSBleHRlbnNpb24gd29rZSBiZWZvcmUgc2V0dGluZ3MgbG9hZCksIHNvIHNob3J0LWNpcmN1aXRcclxuICAvLyBoZXJlIGluc3RlYWQuXHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykgcmV0dXJuO1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xyXG4gIGNvbnN0IGhhbmRsZXM6IHN0cmluZ1tdID0gW107XHJcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBidWZdIG9mIE9iamVjdC5lbnRyaWVzKGFsbCkpIHtcclxuICAgIGNvbnN0IGxhc3QgPSBEYXRlLnBhcnNlKGJ1Zi5sYXN0X2NhcHR1cmVfYXQpO1xyXG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShsYXN0KSAmJiBub3cgLSBsYXN0ID49IEZMVVNIX0lETEVfTVMpIHtcclxuICAgICAgaGFuZGxlcy5wdXNoKGhhbmRsZSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGF3YWl0IGZsdXNoSGFuZGxlcyhoYW5kbGVzLCAnd2FrZScpO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmbHVzaEFsbChyZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcclxuICBhd2FpdCBmbHVzaEhhbmRsZXMoT2JqZWN0LmtleXMoYWxsKSwgcmVhc29uKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZmx1c2hIYW5kbGUoaGFuZGxlOiBzdHJpbmcsIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgZmx1c2hIYW5kbGVzKFtoYW5kbGVdLCByZWFzb24pO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmbHVzaEhhbmRsZXMoaGFuZGxlczogc3RyaW5nW10sIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgdW5pcXVlID0gWy4uLm5ldyBTZXQoaGFuZGxlcyldLmZpbHRlcigoaCkgPT4gaC5sZW5ndGggPiAwKTtcclxuICBpZiAodW5pcXVlLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xyXG4gIGNvbnN0IHJ1biA9IGZsdXNoQ2hhaW4udGhlbigoKSA9PiBmbHVzaEhhbmRsZXNMb2NrZWQodW5pcXVlLCByZWFzb24pKTtcclxuICBmbHVzaENoYWluID0gcnVuLmNhdGNoKCgpID0+IHt9KTtcclxuICByZXR1cm4gcnVuO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBmbHVzaEhhbmRsZXNMb2NrZWQoaGFuZGxlczogc3RyaW5nW10sIHJlYXNvbjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xyXG4gIGNvbnN0IGl0ZW1zOiBGbHVzaEl0ZW1bXSA9IFtdO1xyXG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIGhhbmRsZXMpIHtcclxuICAgIGNvbnN0IGJ1ZiA9IGFsbFtoYW5kbGVdO1xyXG4gICAgaWYgKCFidWYpIGNvbnRpbnVlO1xyXG4gICAgY29uc3QgdHdlZXRzID0gT2JqZWN0LnZhbHVlcyhidWYudHdlZXRzX2J5X2lkKTtcclxuICAgIGNvbnN0IHVuYXZhaWxhYmxlVHdlZXRzID0gT2JqZWN0LnZhbHVlcyhidWYudW5hdmFpbGFibGVfYnlfaWQgPz8ge30pO1xyXG4gICAgY29uc3QgcmV0d2VldEVkZ2VzID0gT2JqZWN0LnZhbHVlcyhidWYucmV0d2VldF9lZGdlc19ieV9rZXkgPz8ge30pO1xyXG4gICAgaWYgKHR3ZWV0cy5sZW5ndGggPT09IDAgJiYgdW5hdmFpbGFibGVUd2VldHMubGVuZ3RoID09PSAwICYmIHJldHdlZXRFZGdlcy5sZW5ndGggPT09IDApIHtcclxuICAgICAgYXdhaXQgY2xlYXJSdW5CdWZmZXIoaGFuZGxlKTtcclxuICAgICAgYXdhaXQgc2V0QnVmZmVyZWRDb3VudChoYW5kbGUsIDApO1xyXG4gICAgICBjb250aW51ZTtcclxuICAgIH1cclxuICAgIGl0ZW1zLnB1c2goYnVpbGRGbHVzaEl0ZW0oaGFuZGxlLCBidWYsIHR3ZWV0cywgdW5hdmFpbGFibGVUd2VldHMsIHJldHdlZXRFZGdlcykpO1xyXG4gIH1cclxuICBpZiAoaXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHtcclxuICAgIGF3YWl0IHdhcm4oJ3VwbG9hZCBidWZmZXIgZGVmZXJyZWQ6IHNldHRpbmdzIGluY29tcGxldGUnLCB7XHJcbiAgICAgIGNvdW50OiBpdGVtcy5sZW5ndGgsXHJcbiAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcclxuICBjb25zdCBmaWxlcyA9IGl0ZW1zLmZsYXRNYXAoKGl0ZW0pID0+IFtcclxuICAgIHtcclxuICAgICAgcGF0aDogaXRlbS5yYXdQYXRoLFxyXG4gICAgICBjb250ZW50QmFzZTY0OiB0b0Jhc2U2NChKU09OLnN0cmluZ2lmeShpdGVtLmNhcHR1cmUsIG51bGwsIDIpICsgJ1xcbicpLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgcGF0aDogaXRlbS5zZWVuUGF0aCxcclxuICAgICAgY29udGVudEJhc2U2NDogdG9CYXNlNjQoSlNPTi5zdHJpbmdpZnkoaXRlbS5zZWVuLCBudWxsLCAyKSArICdcXG4nKSxcclxuICAgIH0sXHJcbiAgXSk7XHJcbiAgY29uc3QgY29tbWl0TXNnID0gYnVpbGRCYXRjaENvbW1pdE1lc3NhZ2UoaXRlbXMpO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2xpZW50LmNvbW1pdEZpbGVzKHtcclxuICAgICAgZmlsZXMsXHJcbiAgICAgIG1lc3NhZ2U6IGNvbW1pdE1zZyxcclxuICAgIH0pO1xyXG4gICAgY29uc3QgaWR4ID0gYXdhaXQgZ2V0Q29tbWl0dGVkSW5kZXgoKTtcclxuICAgIGZvciAoY29uc3QgaXRlbSBvZiBpdGVtcykge1xyXG4gICAgICBjb25zdCByZW1haW5pbmdDb3VudCA9IGF3YWl0IGNsZWFyQ29tbWl0dGVkVHdlZXRzRnJvbUJ1ZmZlcihpdGVtKTtcclxuICAgICAgLy8gQ291bnRlciBidW1wOiBhY3R1YWxseSBJTkNSRU1FTlQgdG9kYXlDb3VudCBhbmQgdG90YWxDb21taXR0ZWQgYnlcclxuICAgICAgLy8gdGhlIG51bWJlciBvZiB0d2VldHMgd2UganVzdCBwZXJzaXN0ZWQgKHRoZSBwcmV2aW91cyBjb2RlIHJlYWQgdGhlXHJcbiAgICAgIC8vIGV4aXN0aW5nIHZhbHVlcyBhbmQgd3JvdGUgdGhlbSBiYWNrLCBsZWF2aW5nIHRoZSBjb3VudGVyIHBlZ2dlZCBhdFxyXG4gICAgICAvLyB6ZXJvKS5cclxuICAgICAgY29uc3QgcHJldiA9IChhd2FpdCBnZXRDb3VudGVycygpKVtpdGVtLmhhbmRsZV07XHJcbiAgICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcclxuICAgICAgY29uc3QgY2FycmllZFRvZGF5ID0gcHJldiAmJiBwcmV2LnRvZGF5RGF0ZSA9PT0gdG9kYXkgPyBwcmV2LnRvZGF5Q291bnQgOiAwO1xyXG4gICAgICBhd2FpdCBidW1wQ291bnRlcihpdGVtLmhhbmRsZSwge1xyXG4gICAgICAgIHRvZGF5Q291bnQ6IGNhcnJpZWRUb2RheSArIGl0ZW0udHdlZXRzLmxlbmd0aCArIGl0ZW0udW5hdmFpbGFibGVUd2VldHMubGVuZ3RoLFxyXG4gICAgICAgIHRvZGF5RGF0ZTogdG9kYXksXHJcbiAgICAgICAgbGFzdENhcHR1cmVBdDogaXRlbS5idWYubGFzdF9jYXB0dXJlX2F0LFxyXG4gICAgICAgIHRvdGFsQ29tbWl0dGVkOlxyXG4gICAgICAgICAgKHByZXY/LnRvdGFsQ29tbWl0dGVkID8/IDApICsgaXRlbS50d2VldHMubGVuZ3RoICsgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXHJcbiAgICAgICAgYnVmZmVyZWRDb3VudDogcmVtYWluaW5nQ291bnQsXHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyBSZWNvcmQgY29tbWl0cyBpbiB0aGUgZGVkdXAgaW5kZXggc28gd2UgZG9uJ3QgcmUtY29tbWl0IHRoZW0gbmV4dFxyXG4gICAgICAvLyBicm93c2Ugd2l0aCB1bmNoYW5nZWQgZW5nYWdlbWVudC5cclxuICAgICAgY29uc3QgaW5uZXIgPSBpZHhbaXRlbS5oYW5kbGVdID8/IHt9O1xyXG4gICAgICBjb25zdCBub3dJc28gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XHJcbiAgICAgIGZvciAoY29uc3QgdCBvZiBpdGVtLnR3ZWV0cykge1xyXG4gICAgICAgIGlubmVyW3QudHdlZXRfaWRdID0ge1xyXG4gICAgICAgICAgdHM6IG5vd0lzbyxcclxuICAgICAgICAgIHNpZzogZW5nYWdlbWVudFNpZyhcclxuICAgICAgICAgICAgdC5saWtlX2NvdW50LFxyXG4gICAgICAgICAgICB0LnJldHdlZXRfY291bnQsXHJcbiAgICAgICAgICAgIHQucmVwbHlfY291bnQsXHJcbiAgICAgICAgICAgIHQucXVvdGVfY291bnQsXHJcbiAgICAgICAgICAgIHQuaXNfdHJ1bmNhdGVkXHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH1cclxuICAgICAgZm9yIChjb25zdCB1IG9mIGl0ZW0udW5hdmFpbGFibGVUd2VldHMpIHtcclxuICAgICAgICBpbm5lclt1LnR3ZWV0X2lkXSA9IHtcclxuICAgICAgICAgIHRzOiBub3dJc28sXHJcbiAgICAgICAgICBzaWc6IHVuYXZhaWxhYmxlU2lnKHUpLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH1cclxuICAgICAgaWR4W2l0ZW0uaGFuZGxlXSA9IGlubmVyO1xyXG4gICAgICBhd2FpdCBpbmZvKCd1cGxvYWQgYnVmZmVyIGNvbW1pdHRlZCcsIHtcclxuICAgICAgICBoYW5kbGU6IGl0ZW0uaGFuZGxlLFxyXG4gICAgICAgIHJlYXNvbixcclxuICAgICAgICB0d2VldHM6IGl0ZW0udHdlZXRzLmxlbmd0aCxcclxuICAgICAgICB1bmF2YWlsYWJsZTogaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGgsXHJcbiAgICAgICAgcmV0d2VldF9lZGdlczogaXRlbS5yZXR3ZWV0RWRnZXMubGVuZ3RoLFxyXG4gICAgICAgIHJ1bjogaXRlbS5ydW5TaG9ydCxcclxuICAgICAgICBwYXRoOiBpdGVtLnJhd1BhdGgsXHJcbiAgICAgICAgYmF0Y2hfY29tbWl0OiByZXN1bHQuY29tbWl0U2hhLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICAgIGF3YWl0IHNldENvbW1pdHRlZEluZGV4KGlkeCk7XHJcbiAgICBhd2FpdCBpbmZvKCd1cGxvYWQgYnVmZmVyIGJhdGNoIGNvbW1pdHRlZCcsIHtcclxuICAgICAgcmVhc29uLFxyXG4gICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXHJcbiAgICAgIGZpbGVzOiBmaWxlcy5sZW5ndGgsXHJcbiAgICAgIHR3ZWV0czogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApLFxyXG4gICAgICB1bmF2YWlsYWJsZTogaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnVuYXZhaWxhYmxlVHdlZXRzLmxlbmd0aCwgMCksXHJcbiAgICAgIHJldHdlZXRfZWRnZXM6IGl0ZW1zLnJlZHVjZSgodG90YWwsIGl0ZW0pID0+IHRvdGFsICsgaXRlbS5yZXR3ZWV0RWRnZXMubGVuZ3RoLCAwKSxcclxuICAgICAgY29tbWl0OiByZXN1bHQuY29tbWl0U2hhLFxyXG4gICAgfSk7XHJcbiAgICB7XHJcbiAgICAgIGNvbnN0IHByZXYgPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xyXG4gICAgICAgIHN0YXR1czogJ29rJyxcclxuICAgICAgICBsb2dpbjogcHJldi5sb2dpbixcclxuICAgICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBwcmV2LmRlZmF1bHRCcmFuY2gsXHJcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogcHJldi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxyXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgaWYgKGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yKSB7XHJcbiAgICAgIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XHJcbiAgICAgICAgZXJyLmNhdGVnb3J5ID09PSAnYXV0aCdcclxuICAgICAgICAgID8gJ2F1dGgtZXJyb3InXHJcbiAgICAgICAgICA6IGVyci5jYXRlZ29yeSA9PT0gJ3JhdGUtbGltaXQnXHJcbiAgICAgICAgICAgID8gJ3JhdGUtbGltaXRlZCdcclxuICAgICAgICAgICAgOiBlcnIuY2F0ZWdvcnkgPT09ICduZXR3b3JrJ1xyXG4gICAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXHJcbiAgICAgICAgICAgICAgOiBjb25uLnN0YXR1cztcclxuICAgICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgICAgc3RhdHVzLFxyXG4gICAgICAgIGxvZ2luOiBjb25uLmxvZ2luLFxyXG4gICAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIGVycm9yOiBlcnIubWVzc2FnZSxcclxuICAgICAgICBkZWZhdWx0QnJhbmNoOiBjb25uLmRlZmF1bHRCcmFuY2gsXHJcbiAgICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogY29ubi5jb25maWd1cmVkQnJhbmNoRXhpc3RzLFxyXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6XHJcbiAgICAgICAgICBlcnIuY2F0ZWdvcnkgPT09ICdyYXRlLWxpbWl0JyA/IGVyci5yYXRlTGltaXRSZXNldEF0IDogY29ubi5yYXRlTGltaXRSZXNldEF0LFxyXG4gICAgICB9KTtcclxuICAgICAgYXdhaXQgbG9nRXJyKCd1cGxvYWQgYnVmZmVyIGZhaWxlZCcsIHtcclxuICAgICAgICByZWFzb24sXHJcbiAgICAgICAgaGFuZGxlczogaXRlbXMubWFwKChpdGVtKSA9PiBpdGVtLmhhbmRsZSkuc2xpY2UoMCwgMjApLFxyXG4gICAgICAgIHJ1bnM6IGl0ZW1zLmxlbmd0aCxcclxuICAgICAgICBmaWxlczogZmlsZXMubGVuZ3RoLFxyXG4gICAgICAgIGNhdGVnb3J5OiBlcnIuY2F0ZWdvcnksXHJcbiAgICAgICAgc3RhdHVzOiBlcnIuc3RhdHVzLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVyci5tZXNzYWdlLFxyXG4gICAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IGVyci5yYXRlTGltaXRSZXNldEF0LFxyXG4gICAgICB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGF3YWl0IGxvZ0VycigndXBsb2FkIGJ1ZmZlciBmYWlsZWQnLCB7XHJcbiAgICAgICAgcmVhc29uLFxyXG4gICAgICAgIGhhbmRsZXM6IGl0ZW1zLm1hcCgoaXRlbSkgPT4gaXRlbS5oYW5kbGUpLnNsaWNlKDAsIDIwKSxcclxuICAgICAgICBydW5zOiBpdGVtcy5sZW5ndGgsXHJcbiAgICAgICAgZmlsZXM6IGZpbGVzLmxlbmd0aCxcclxuICAgICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gICAgLy8gTGVhdmUgYnVmZmVyIGludGFjdCBmb3IgcmV0cnkuXHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBidWlsZEZsdXNoSXRlbShcclxuICBoYW5kbGU6IHN0cmluZyxcclxuICBidWY6IFJ1bkJ1ZmZlcixcclxuICB0d2VldHM6IENhbm9uaWNhbFR3ZWV0W10sXHJcbiAgdW5hdmFpbGFibGVUd2VldHM6IFVuYXZhaWxhYmxlVHdlZXRbXSxcclxuICByZXR3ZWV0RWRnZXM6IFJldHdlZXRFZGdlW11cclxuKTogRmx1c2hJdGVtIHtcclxuICBjb25zdCB0cyA9IGlzb0NvbXBhY3QoYnVmLnN0YXJ0ZWRfYXQpO1xyXG4gIGNvbnN0IGRheSA9IGJ1Zi5zdGFydGVkX2F0LnNsaWNlKDAsIDEwKTtcclxuICBjb25zdCBydW5TaG9ydCA9IHNob3J0UnVuSWQoYnVmLnJ1bl9pZCk7XHJcbiAgY29uc3QgcmF3UGF0aCA9IGByYXcvJHtoYW5kbGV9LyR7dHN9LSR7cnVuU2hvcnR9Lmpzb25gO1xyXG4gIGNvbnN0IHNlZW5QYXRoID0gYHNlZW4vJHtoYW5kbGV9LyR7dHN9LSR7cnVuU2hvcnR9Lmpzb25gO1xyXG4gIHJldHVybiB7XHJcbiAgICBoYW5kbGUsXHJcbiAgICBidWYsXHJcbiAgICB0d2VldHMsXHJcbiAgICB1bmF2YWlsYWJsZVR3ZWV0cyxcclxuICAgIHJldHdlZXRFZGdlcyxcclxuICAgIHJhd1BhdGgsXHJcbiAgICBzZWVuUGF0aCxcclxuICAgIGRheSxcclxuICAgIHJ1blNob3J0LFxyXG4gICAgY2FwdHVyZToge1xyXG4gICAgICBzY2hlbWFfdmVyc2lvbjogMSxcclxuICAgICAgY2FwdHVyZV9ydW5faWQ6IGJ1Zi5ydW5faWQsXHJcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXHJcbiAgICAgIGNhcHR1cmVkX2F0OiBidWYubGFzdF9jYXB0dXJlX2F0LFxyXG4gICAgICBlbmRwb2ludDogYnVmLmVuZHBvaW50c19zZWVuLmpvaW4oJywnKSxcclxuICAgICAgdXNlcl9hZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcclxuICAgICAgc291cmNlX3VybDogYnVmLnNvdXJjZV91cmwsXHJcbiAgICAgIHR3ZWV0cyxcclxuICAgICAgdW5hdmFpbGFibGVfdHdlZXRzOiB1bmF2YWlsYWJsZVR3ZWV0cyxcclxuICAgICAgcmV0d2VldF9lZGdlczogcmV0d2VldEVkZ2VzLFxyXG4gICAgfSxcclxuICAgIHNlZW46IHtcclxuICAgICAgc2NoZW1hX3ZlcnNpb246IDEsXHJcbiAgICAgIGNhcHR1cmVfcnVuX2lkOiBidWYucnVuX2lkLFxyXG4gICAgICBhY2NvdW50X2hhbmRsZTogaGFuZGxlLFxyXG4gICAgICBjYXB0dXJlZF9hdDogYnVmLmxhc3RfY2FwdHVyZV9hdCxcclxuICAgICAgdHdlZXRfaWRzX29ic2VydmVkOiBidWYudHdlZXRfaWRzX29ic2VydmVkLFxyXG4gICAgfSxcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBidWlsZEJhdGNoQ29tbWl0TWVzc2FnZShpdGVtczogRmx1c2hJdGVtW10pOiBzdHJpbmcge1xyXG4gIGlmIChpdGVtcy5sZW5ndGggPT09IDEpIHtcclxuICAgIGNvbnN0IGl0ZW0gPSBpdGVtc1swXSE7XHJcbiAgICBjb25zdCB1bmF2YWlsYWJsZUNvdW50ID0gaXRlbS51bmF2YWlsYWJsZVR3ZWV0cy5sZW5ndGg7XHJcbiAgICBjb25zdCBlZGdlQ291bnQgPSBpdGVtLnJldHdlZXRFZGdlcy5sZW5ndGg7XHJcbiAgICBjb25zdCBzdWZmaXggPVxyXG4gICAgICAodW5hdmFpbGFibGVDb3VudCA+IDAgPyBgLCAke3VuYXZhaWxhYmxlQ291bnR9IHVuYXZhaWxhYmxlYCA6ICcnKSArXHJcbiAgICAgIChlZGdlQ291bnQgPiAwID8gYCwgJHtlZGdlQ291bnR9IHJldHdlZXQgZWRnZSR7ZWRnZUNvdW50ID09PSAxID8gJycgOiAncyd9YCA6ICcnKTtcclxuICAgIHJldHVybiBgY2FwdHVyZTogJHtpdGVtLmhhbmRsZX0gJHtpdGVtLmRheX0gJHtpdGVtLnR3ZWV0cy5sZW5ndGh9IHR3ZWV0JHtpdGVtLnR3ZWV0cy5sZW5ndGggPT09IDEgPyAnJyA6ICdzJ30ke3N1ZmZpeH0gKHJ1biAke2l0ZW0ucnVuU2hvcnR9KWA7XHJcbiAgfVxyXG4gIGNvbnN0IGRheXMgPSBbLi4ubmV3IFNldChpdGVtcy5tYXAoKGl0ZW0pID0+IGl0ZW0uZGF5KSldLnNvcnQoKTtcclxuICBjb25zdCBkYXlMYWJlbCA9IGRheXMubGVuZ3RoID09PSAxID8gZGF5c1swXSEgOiBgJHtkYXlzWzBdfS4uJHtkYXlzW2RheXMubGVuZ3RoIC0gMV19YDtcclxuICBjb25zdCB0d2VldENvdW50ID0gaXRlbXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLnR3ZWV0cy5sZW5ndGgsIDApO1xyXG4gIGNvbnN0IHVuYXZhaWxhYmxlQ291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0udW5hdmFpbGFibGVUd2VldHMubGVuZ3RoLCAwKTtcclxuICBjb25zdCBlZGdlQ291bnQgPSBpdGVtcy5yZWR1Y2UoKHRvdGFsLCBpdGVtKSA9PiB0b3RhbCArIGl0ZW0ucmV0d2VldEVkZ2VzLmxlbmd0aCwgMCk7XHJcbiAgY29uc3Qgc3VmZml4ID1cclxuICAgICh1bmF2YWlsYWJsZUNvdW50ID4gMCA/IGAsICR7dW5hdmFpbGFibGVDb3VudH0gdW5hdmFpbGFibGVgIDogJycpICtcclxuICAgIChlZGdlQ291bnQgPiAwID8gYCwgJHtlZGdlQ291bnR9IHJldHdlZXQgZWRnZSR7ZWRnZUNvdW50ID09PSAxID8gJycgOiAncyd9YCA6ICcnKTtcclxuICByZXR1cm4gYGNhcHR1cmUgYmF0Y2g6ICR7aXRlbXMubGVuZ3RofSBydW5zLCAke3R3ZWV0Q291bnR9IHR3ZWV0JHt0d2VldENvdW50ID09PSAxID8gJycgOiAncyd9JHtzdWZmaXh9ICgke2RheUxhYmVsfSlgO1xyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBjbGVhckNvbW1pdHRlZFR3ZWV0c0Zyb21CdWZmZXIoaXRlbTogRmx1c2hJdGVtKTogUHJvbWlzZTxudW1iZXI+IHtcclxuICBjb25zdCBjdXJyZW50ID0gYXdhaXQgZ2V0UnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcclxuICBpZiAoIWN1cnJlbnQpIHJldHVybiAwO1xyXG4gIGlmIChjdXJyZW50LnJ1bl9pZCAhPT0gaXRlbS5idWYucnVuX2lkKSByZXR1cm4gcnVuQnVmZmVySXRlbUNvdW50KGN1cnJlbnQpO1xyXG5cclxuICBjb25zdCBjb21taXR0ZWQgPSBuZXcgTWFwKFxyXG4gICAgaXRlbS50d2VldHMubWFwKCh0KSA9PiBbXHJcbiAgICAgIHQudHdlZXRfaWQsXHJcbiAgICAgIGVuZ2FnZW1lbnRTaWcodC5saWtlX2NvdW50LCB0LnJldHdlZXRfY291bnQsIHQucmVwbHlfY291bnQsIHQucXVvdGVfY291bnQsIHQuaXNfdHJ1bmNhdGVkKSxcclxuICAgIF0pXHJcbiAgKTtcclxuICBmb3IgKGNvbnN0IHUgb2YgaXRlbS51bmF2YWlsYWJsZVR3ZWV0cykge1xyXG4gICAgY29tbWl0dGVkLnNldCh1LnR3ZWV0X2lkLCB1bmF2YWlsYWJsZVNpZyh1KSk7XHJcbiAgfVxyXG4gIGNvbnN0IHJlbWFpbmluZ1R3ZWV0czogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+ID0ge307XHJcbiAgZm9yIChjb25zdCBbdHdlZXRJZCwgdHdlZXRdIG9mIE9iamVjdC5lbnRyaWVzKGN1cnJlbnQudHdlZXRzX2J5X2lkKSkge1xyXG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcclxuICAgIGNvbnN0IGN1cnJlbnRTaWcgPSBlbmdhZ2VtZW50U2lnKFxyXG4gICAgICB0d2VldC5saWtlX2NvdW50LFxyXG4gICAgICB0d2VldC5yZXR3ZWV0X2NvdW50LFxyXG4gICAgICB0d2VldC5yZXBseV9jb3VudCxcclxuICAgICAgdHdlZXQucXVvdGVfY291bnQsXHJcbiAgICAgIHR3ZWV0LmlzX3RydW5jYXRlZFxyXG4gICAgKTtcclxuICAgIGlmICghY29tbWl0dGVkU2lnIHx8IGNvbW1pdHRlZFNpZyAhPT0gY3VycmVudFNpZykge1xyXG4gICAgICByZW1haW5pbmdUd2VldHNbdHdlZXRJZF0gPSB7IC4uLnR3ZWV0IH07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IHJlbWFpbmluZ1VuYXZhaWxhYmxlOiBSZWNvcmQ8c3RyaW5nLCBVbmF2YWlsYWJsZVR3ZWV0PiA9IHt9O1xyXG4gIGZvciAoY29uc3QgW3R3ZWV0SWQsIHVuYXZhaWxhYmxlXSBvZiBPYmplY3QuZW50cmllcyhjdXJyZW50LnVuYXZhaWxhYmxlX2J5X2lkID8/IHt9KSkge1xyXG4gICAgY29uc3QgY29tbWl0dGVkU2lnID0gY29tbWl0dGVkLmdldCh0d2VldElkKTtcclxuICAgIGNvbnN0IGN1cnJlbnRTaWcgPSB1bmF2YWlsYWJsZVNpZyh1bmF2YWlsYWJsZSk7XHJcbiAgICBpZiAoIWNvbW1pdHRlZFNpZyB8fCBjb21taXR0ZWRTaWcgIT09IGN1cnJlbnRTaWcpIHtcclxuICAgICAgcmVtYWluaW5nVW5hdmFpbGFibGVbdHdlZXRJZF0gPSB7IC4uLnVuYXZhaWxhYmxlIH07XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IHJlbWFpbmluZ1JldHdlZXRFZGdlczogUmVjb3JkPHN0cmluZywgUmV0d2VldEVkZ2U+ID0ge307XHJcbiAgZm9yIChjb25zdCBba2V5LCBlZGdlXSBvZiBPYmplY3QuZW50cmllcyhjdXJyZW50LnJldHdlZXRfZWRnZXNfYnlfa2V5ID8/IHt9KSkge1xyXG4gICAgaWYgKCFpdGVtLnJldHdlZXRFZGdlcy5zb21lKChjb21taXR0ZWRFZGdlKSA9PiByZXR3ZWV0RWRnZUtleShjb21taXR0ZWRFZGdlKSA9PT0ga2V5KSkge1xyXG4gICAgICByZW1haW5pbmdSZXR3ZWV0RWRnZXNba2V5XSA9IHsgLi4uZWRnZSB9O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgcmVtYWluaW5nSWRzID0gbmV3IFNldChbXHJcbiAgICAuLi5PYmplY3Qua2V5cyhyZW1haW5pbmdUd2VldHMpLFxyXG4gICAgLi4uT2JqZWN0LmtleXMocmVtYWluaW5nVW5hdmFpbGFibGUpLFxyXG4gICAgLi4uT2JqZWN0LnZhbHVlcyhyZW1haW5pbmdSZXR3ZWV0RWRnZXMpLmZsYXRNYXAoKGVkZ2UpID0+IFtcclxuICAgICAgZWRnZS5yZXR3ZWV0X3R3ZWV0X2lkLFxyXG4gICAgICBlZGdlLm9yaWdpbmFsX3R3ZWV0X2lkLFxyXG4gICAgXSksXHJcbiAgXSk7XHJcbiAgY29uc3QgcmVtYWluaW5nQ291bnQgPVxyXG4gICAgT2JqZWN0LmtleXMocmVtYWluaW5nVHdlZXRzKS5sZW5ndGggK1xyXG4gICAgT2JqZWN0LmtleXMocmVtYWluaW5nVW5hdmFpbGFibGUpLmxlbmd0aCArXHJcbiAgICBPYmplY3Qua2V5cyhyZW1haW5pbmdSZXR3ZWV0RWRnZXMpLmxlbmd0aDtcclxuICBpZiAocmVtYWluaW5nQ291bnQgPT09IDApIHtcclxuICAgIGF3YWl0IGNsZWFyUnVuQnVmZmVyKGl0ZW0uaGFuZGxlKTtcclxuICAgIHJldHVybiAwO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgbmV4dFJ1bklkID0gbmV3UnVuSWQoKTtcclxuICBmb3IgKGNvbnN0IHR3ZWV0IG9mIE9iamVjdC52YWx1ZXMocmVtYWluaW5nVHdlZXRzKSkge1xyXG4gICAgdHdlZXQuY2FwdHVyZV9ydW5faWQgPSBuZXh0UnVuSWQ7XHJcbiAgfVxyXG4gIGZvciAoY29uc3QgZWRnZSBvZiBPYmplY3QudmFsdWVzKHJlbWFpbmluZ1JldHdlZXRFZGdlcykpIHtcclxuICAgIGVkZ2UuY2FwdHVyZV9ydW5faWQgPSBuZXh0UnVuSWQ7XHJcbiAgfVxyXG4gIGF3YWl0IHNldFJ1bkJ1ZmZlcihpdGVtLmhhbmRsZSwge1xyXG4gICAgLi4uY3VycmVudCxcclxuICAgIHJ1bl9pZDogbmV4dFJ1bklkLFxyXG4gICAgc3RhcnRlZF9hdDogY3VycmVudC5sYXN0X2NhcHR1cmVfYXQsXHJcbiAgICB0d2VldHNfYnlfaWQ6IHJlbWFpbmluZ1R3ZWV0cyxcclxuICAgIHVuYXZhaWxhYmxlX2J5X2lkOiByZW1haW5pbmdVbmF2YWlsYWJsZSxcclxuICAgIHJldHdlZXRfZWRnZXNfYnlfa2V5OiByZW1haW5pbmdSZXR3ZWV0RWRnZXMsXHJcbiAgICB0d2VldF9pZHNfb2JzZXJ2ZWQ6IGN1cnJlbnQudHdlZXRfaWRzX29ic2VydmVkLmZpbHRlcigoaWQpID0+IHJlbWFpbmluZ0lkcy5oYXMoaWQpKSxcclxuICB9KTtcclxuICBhd2FpdCBpbmZvKCd1cGxvYWQgYnVmZmVyIGtlcHQgbmV3ZXIgdHdlZXRzJywge1xyXG4gICAgaGFuZGxlOiBpdGVtLmhhbmRsZSxcclxuICAgIGNvbW1pdHRlZF9ydW46IGl0ZW0ucnVuU2hvcnQsXHJcbiAgICBuZXh0X3J1bjogc2hvcnRSdW5JZChuZXh0UnVuSWQpLFxyXG4gICAgcmVtYWluaW5nOiByZW1haW5pbmdDb3VudCxcclxuICB9KTtcclxuICByZXR1cm4gcmVtYWluaW5nQ291bnQ7XHJcbn1cclxuXHJcbi8vIC0tLSBDYXB0dXJlLW5vdyAvIGNhcHR1cmUtYWxsIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVOb3coaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcclxuICAvLyBMYW5kIG9uIHRoZSBSZXBsaWVzIHRhYiBzbyBYIGZldGNoZXMgdmlhIFVzZXJUd2VldHNBbmRSZXBsaWVzIFx1MjAxNCB0aGF0XHJcbiAgLy8gZW5kcG9pbnQgcmV0dXJucyBib3RoIHRvcC1sZXZlbCBwb3N0cyBhbmQgcmVwbGllcywgd2hpY2ggaXMgdGhlIHN1cGVyc2V0XHJcbiAgLy8gd2Ugd2FudCBmb3IgdGhlIGFyY2hpdmUuIFRoZSBwbGFpbiBgLzxoYW5kbGU+YCBVUkwgaGl0cyBVc2VyVHdlZXRzLFxyXG4gIC8vIHdoaWNoIG9taXRzIHJlcGxpZXMuIFRoZSBwYWdlLWhvb2sgaW50ZXJjZXB0cyBlaXRoZXIgZW5kcG9pbnQsIGJ1dFxyXG4gIC8vIGZvcmNpbmcgdGhlIGJyb2FkZXIgdGFiIG9uIHVzZXItaW5pdGlhdGVkIGNhcHR1cmVzIGlzIHRoZSByaWdodCBkZWZhdWx0LlxyXG4gIGNvbnN0IHRhcmdldFVybCA9IGBodHRwczovL3guY29tLyR7aGFuZGxlfS93aXRoX3JlcGxpZXNgO1xyXG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtbm93IHJlcXVlc3RlZCcsIHsgaGFuZGxlLCB0YWI6ICd3aXRoX3JlcGxpZXMnIH0pO1xyXG4gIGlmICghKGF3YWl0IGdldFJ1bkJ1ZmZlcihoYW5kbGUpKSkge1xyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xyXG4gICAgYXdhaXQgc2V0UnVuQnVmZmVyKGhhbmRsZSwge1xyXG4gICAgICBydW5faWQ6IG5ld1J1bklkKCksXHJcbiAgICAgIGFjY291bnRfaGFuZGxlOiBoYW5kbGUsXHJcbiAgICAgIHN0YXJ0ZWRfYXQ6IG5vdyxcclxuICAgICAgbGFzdF9jYXB0dXJlX2F0OiBub3csXHJcbiAgICAgIHR3ZWV0c19ieV9pZDoge30sXHJcbiAgICAgIHVuYXZhaWxhYmxlX2J5X2lkOiB7fSxcclxuICAgICAgdHdlZXRfaWRzX29ic2VydmVkOiBbXSxcclxuICAgICAgZW5kcG9pbnRzX3NlZW46IFtdLFxyXG4gICAgICBzb3VyY2VfdXJsOiB0YXJnZXRVcmwsXHJcbiAgICB9KTtcclxuICB9XHJcbiAgYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybDogdGFyZ2V0VXJsLCBhY3RpdmU6IHRydWUgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIGNhcHR1cmVBbGwoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gIGF3YWl0IGluZm8oJ2NhcHR1cmUtYWxsIHJlcXVlc3RlZCcsIHsgY291bnQ6IGFjY291bnRzLmxlbmd0aCB9KTtcclxuICBmb3IgKGNvbnN0IGEgb2YgYWNjb3VudHMpIHtcclxuICAgIGF3YWl0IGNhcHR1cmVOb3coYS5oYW5kbGUpO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIENhcHR1cmUgd2hhdGV2ZXIgdGhlIHVzZXIgaXMgY3VycmVudGx5IGxvb2tpbmcgYXQ6IGVuc3VyZXMgcGFnZS1ob29rIGlzXHJcbiAqIHBhdGNoZWQgaW50byB0aGUgYWN0aXZlIHRhYiwgdGhlbiBudWRnZXMgdGhlIHBhZ2Ugd2l0aCBhIHByb2dyYW1tYXRpY1xyXG4gKiBzY3JvbGwgc28gWCBmaXJlcyBhbm90aGVyIGJhdGNoIG9mIEdyYXBoUUwgcmVxdWVzdHMgd2UgY2FuIGludGVyY2VwdC5cclxuICpcclxuICogTGVzcyBkaXNydXB0aXZlIHRoYW4gYENhcHR1cmUgbm93YCAobm8gbmV3IHRhYiwgbm8gbmF2aWdhdGlvbikgYW5kIHdvcmtzXHJcbiAqIGZvciBhcmJpdHJhcnkgWCBVUkxzIChzcGVjaWZpYyB0d2VldCB0aHJlYWRzLCBzZWFyY2ggcmVzdWx0cywgbGlzdHMpXHJcbiAqIHRoYXQgZG9uJ3QgbWFwIGNsZWFubHkgdG8gb25lIG9mIHRoZSBjb25maWd1cmVkIGhhbmRsZXMuXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBjYXB0dXJlVGhpc1BhZ2UoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XHJcbiAgbGV0IHRhYnM6IGJyb3dzZXIudGFicy5UYWJbXTtcclxuICB0cnkge1xyXG4gICAgdGFicyA9IGF3YWl0IGJyb3dzZXIudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBjb3VsZCBub3QgcXVlcnkgYWN0aXZlIHRhYicsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IHRhYiA9IHRhYnNbMF07XHJcbiAgaWYgKCF0YWIgfHwgdHlwZW9mIHRhYi5pZCAhPT0gJ251bWJlcicgfHwgIXRhYi51cmwpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBubyBhY3RpdmUgdGFiJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmICghL15odHRwczpcXC9cXC8oeHx0d2l0dGVyKVxcLmNvbVxcLy8udGVzdCh0YWIudXJsKSkge1xyXG4gICAgYXdhaXQgd2FybignY2FwdHVyZS10aGlzLXBhZ2U6IGFjdGl2ZSB0YWIgaXMgbm90IG9uIHguY29tIC8gdHdpdHRlci5jb20nLCB7XHJcbiAgICAgIHVybDogc2hvcnRlblVybCh0YWIudXJsKSxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBhd2FpdCBpbmZvKCdjYXB0dXJlLXRoaXMtcGFnZSByZXF1ZXN0ZWQnLCB7IHVybDogc2hvcnRlblVybCh0YWIudXJsKSB9KTtcclxuICAvLyAoUmUtKWluamVjdCB0aGUgcGFnZS1ob29rICsgaXNvbGF0ZWQgY29udGVudCBzY3JpcHQgc28gZmV0Y2gvWEhSIGFyZVxyXG4gIC8vIHBhdGNoZWQgZXZlbiBvbiB0YWJzIG9wZW5lZCBiZWZvcmUgdGhlIGV4dGVuc2lvbiByZWxvYWRlZC5cclxuICB0cnkge1xyXG4gICAgYXdhaXQgYnJvd3Nlci5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XHJcbiAgICAgIHRhcmdldDogeyB0YWJJZDogdGFiLmlkIH0sXHJcbiAgICAgIGZpbGVzOiBbJ3BhZ2UtaG9vay5qcyddLFxyXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXHJcbiAgICB9KTtcclxuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxyXG4gICAgICBmaWxlczogWydjb250ZW50LmpzJ10sXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiByZS1pbmplY3QgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICB9XHJcbiAgLy8gTnVkZ2UgWCB0byBmaXJlIG1vcmUgR3JhcGhRTCByZXF1ZXN0cyBieSBzY3JvbGxpbmcuIE1vc3QgdGltZWxpbmUgL1xyXG4gIC8vIGNvbnZlcnNhdGlvbiB2aWV3cyBmZXRjaCBvbiBpbnRlcnNlY3Rpb24tb2JzZXJ2ZXIgdHJpZ2dlcnMuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGJyb3dzZXIuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xyXG4gICAgICB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LFxyXG4gICAgICB3b3JsZDogJ01BSU4nIGFzICdJU09MQVRFRCcsXHJcbiAgICAgIGZ1bmM6ICgpID0+IHtcclxuICAgICAgICBjb25zdCBoID0gd2luZG93LmlubmVySGVpZ2h0O1xyXG4gICAgICAgIHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuNSwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gd2luZG93LnNjcm9sbEJ5KHsgdG9wOiBoICogMS41LCBiZWhhdmlvcjogJ3Ntb290aCcgfSksIDYwMCk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3aW5kb3cuc2Nyb2xsQnkoeyB0b3A6IGggKiAxLjUsIGJlaGF2aW9yOiAnc21vb3RoJyB9KSwgMTIwMCk7XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ2NhcHR1cmUtdGhpcy1wYWdlOiBzY3JvbGwtbnVkZ2UgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbi8vIC0tLSBSZWZldGNoIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vXHJcbi8vIFggdHJ1bmNhdGVzIGxvbmcgdHdlZXRzIGluIHRpbWVsaW5lIHBheWxvYWRzIFx1MjAxNCBgbm90ZV90d2VldGAgaXMgb25seVxyXG4vLyBpbmxpbmVkIGZvciBzb21lIGVuZHBvaW50cy4gUmUtb3BlbmluZyBlYWNoIHRydW5jYXRlZCB0d2VldCdzIGRldGFpbCBwYWdlXHJcbi8vIGNhdXNlcyB0aGUgcGFnZS1ob29rIHRvIGNhcHR1cmUgdGhlIGZ1bGwgYG5vdGVfdHdlZXRgIGJvZHkuIFRoZSBsb29wXHJcbi8vIGRyaXZlcyB0aGF0IGJ5IG5hdmlnYXRpbmcgYSBzaW5nbGUgZGVkaWNhdGVkIHRhYiB0aHJvdWdoIHRoZSBxdWV1ZSwgb25lXHJcbi8vIHR3ZWV0IGF0IGEgdGltZSwgZ2F0ZWQgb24gdGhlIHBhZ2UtaG9vayBhY3R1YWxseSBpbmdlc3RpbmcgYSByZXNwb25zZSBmb3JcclxuLy8gdGhlIHR3ZWV0IHdlIGp1c3QgbmF2aWdhdGVkIHRvIChzbyBkZWxldGVkIC8gcGF5d2FsbGVkIC8gNDA0J2QgdHdlZXRzXHJcbi8vIGRvbid0IG1ha2UgdXMgc3BpbiBhbmQgc28gd2UgZG9uJ3Qgc2xhbSBYIHdpdGggcmVmcmVzaGVzIGZhc3RlciB0aGFuIHRoZVxyXG4vLyB0YWIgY2FuIGxvYWQpLlxyXG5cclxuY29uc3QgUkVGRVRDSF9UQUJfS0VZID0gJ19faW1tX2FyY2hpdmVfcmVmZXRjaF90YWJfaWRfXyc7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChSRUZFVENIX1RBQl9LRVkpO1xyXG4gIGNvbnN0IGlkID0gc3RvcmVkW1JFRkVUQ0hfVEFCX0tFWV07XHJcbiAgcmV0dXJuIHR5cGVvZiBpZCA9PT0gJ251bWJlcicgPyBpZCA6IG51bGw7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHNldFJlZmV0Y2hUYWJJZChpZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIGlmIChpZCA9PT0gbnVsbCkge1xyXG4gICAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnJlbW92ZShSRUZFVENIX1RBQl9LRVkpO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1JFRkVUQ0hfVEFCX0tFWV06IGlkIH0pO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBhbGxvd01hbnVhbENhcHR1cmVXaW5kb3coKTtcclxuICBjb25zdCB0b3RhbCA9IGF3YWl0IHJlZmV0Y2hRdWV1ZVRvdGFsKCk7XHJcbiAgaWYgKHRvdGFsID09PSAwKSB7XHJcbiAgICBhd2FpdCBpbmZvKCdyZWZldGNoOiBub3RoaW5nIHF1ZXVlZCcpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBjb25zdCBzZWNvbmRzID0gTWF0aC5taW4oXHJcbiAgICBBVVRPX1NDUk9MTF9NQVhfU0VDLFxyXG4gICAgTWF0aC5tYXgoQVVUT19TQ1JPTExfTUlOX1NFQywgTWF0aC5yb3VuZChzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYykpXHJcbiAgKTtcclxuICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbih7XHJcbiAgICB0b3RhbEF0U3RhcnQ6IHRvdGFsLFxyXG4gICAgcHJvY2Vzc2VkOiAwLFxyXG4gICAgc3RhcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICBpbmZsaWdodDogbnVsbCxcclxuICB9KTtcclxuICBzdGFydFJlZmV0Y2hJbnRlcnZhbChzZWNvbmRzKTtcclxuICB2b2lkIHJlZmV0Y2hUaWNrKCk7XHJcbiAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5sZXQgcmVmZXRjaEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0UmVmZXRjaEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xyXG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcclxuICByZWZldGNoSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIHJlZmV0Y2hUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ3JlZmV0Y2ggdGljayBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gICAgfSk7XHJcbiAgfSwgc2Vjb25kcyAqIDEwMDApO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzdG9wUmVmZXRjaEludGVydmFsKCk6IHZvaWQge1xyXG4gIGlmIChyZWZldGNoSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIHtcclxuICAgIGNsZWFySW50ZXJ2YWwocmVmZXRjaEludGVydmFsSGFuZGxlKTtcclxuICAgIHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSA9IG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5hc3luYyBmdW5jdGlvbiBjYW5jZWxSZWZldGNoTG9vcCgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBzdG9wUmVmZXRjaEludGVydmFsKCk7XHJcbiAgYXdhaXQgYnJvd3Nlci5hbGFybXMuY2xlYXIoJ3JlZmV0Y2gtdGljaycpOyAvLyBsZWdhY3kgY2xlYW51cFxyXG4gIGNvbnN0IHRhYklkID0gYXdhaXQgZ2V0UmVmZXRjaFRhYklkKCk7XHJcbiAgYXdhaXQgc2V0UmVmZXRjaFRhYklkKG51bGwpO1xyXG4gIGNvbnN0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xyXG4gIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xyXG4gIGF3YWl0IGluZm8oJ3JlZmV0Y2ggbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcclxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVmZXRjaFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRSZWZldGNoU2Vzc2lvbigpO1xyXG4gIGlmIChzZXNzID09PSBudWxsKSB7XHJcbiAgICAvLyBMb29wIHdhcyBjYW5jZWxsZWQgb3IgbmV2ZXIgc3RhcnRlZDsgbm90aGluZyB0byBkby5cclxuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgLy8gV2FpdC1mb3ItaW5nZXN0IGd1YXJkOiBpZiB3ZSdyZSBzdGlsbCBleHBlY3RpbmcgYSBjYXB0dXJlIGZvciB0aGVcclxuICAvLyBwcmV2aW91c2x5LW5hdmlnYXRlZCB0YXJnZXQsIG9ubHkgYWR2YW5jZSBvbmNlIHdlJ3ZlIGVpdGhlciBzZWVuIHRoZVxyXG4gIC8vIGNhcHR1cmUgKG9uR3JhcGhxbENhcHR1cmUgY2xlYXJzIGBpbmZsaWdodGApIG9yIGhpdCB0aGUgdGltZW91dC5cclxuICBpZiAoc2Vzcy5pbmZsaWdodCAhPT0gbnVsbCkge1xyXG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKHNlc3MuaW5mbGlnaHQubmF2aWdhdGVkQXQpO1xyXG4gICAgaWYgKGVsYXBzZWQgPCBJTkdFU1RfV0FJVF9NUykge1xyXG4gICAgICByZXR1cm47IC8vIHN0aWxsIHdhaXRpbmcgXHUyMDE0IHBhZ2UtaG9vayBtYXkgeWV0IGNhcHR1cmUgdGhlIHJlc3BvbnNlLlxyXG4gICAgfVxyXG4gICAgLy8gVGltZWQgb3V0LiBUcmVhdCBhcyBcInRoaXMgdGFyZ2V0IHdvbid0IGluZ2VzdFwiIGFuZCBkcm9wIGl0LlxyXG4gICAgYXdhaXQgd2FybigncmVmZXRjaDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXHJcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcclxuICAgIH0pO1xyXG4gICAgLy8gRmluZCB3aGljaCBoYW5kbGUgdGhpcyBpZCBpcyBxdWV1ZWQgdW5kZXIgc28gd2UgY2FuIGRlcXVldWUgaXQuXHJcbiAgICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XHJcbiAgICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcclxuICAgICAgaWYgKGlkcy5pbmNsdWRlcyhzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpKSB7XHJcbiAgICAgICAgYXdhaXQgZGVxdWV1ZVJlZmV0Y2goaGFuZGxlLCBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcclxuICB9XHJcblxyXG4gIGNvbnN0IHRhcmdldCA9IGF3YWl0IG5leHRSZWZldGNoVGFyZ2V0KCk7XHJcbiAgaWYgKCF0YXJnZXQpIHtcclxuICAgIHN0b3BSZWZldGNoSW50ZXJ2YWwoKTtcclxuICAgIGF3YWl0IHNldFJlZmV0Y2hUYWJJZChudWxsKTtcclxuICAgIGF3YWl0IHNldFJlZmV0Y2hTZXNzaW9uKG51bGwpO1xyXG4gICAgYXdhaXQgaW5mbygncmVmZXRjaCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIGNvbnN0IHVybCA9IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmhhbmRsZX0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcclxuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRSZWZldGNoVGFiSWQoKTtcclxuICBpZiAodGFiSWQgIT09IG51bGwpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHRhYklkID0gbnVsbDtcclxuICAgIH1cclxuICB9XHJcbiAgdHJ5IHtcclxuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xyXG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xyXG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicpIGF3YWl0IHNldFJlZmV0Y2hUYWJJZCh0YWIuaWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XHJcbiAgICB9XHJcbiAgICBzZXNzID0gKGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCkpID8/IHNlc3M7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xyXG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIH07XHJcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcclxuICAgIGF3YWl0IGluZm8oJ3JlZmV0Y2ggdGljaycsIHtcclxuICAgICAgaGFuZGxlOiB0YXJnZXQuaGFuZGxlLFxyXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXHJcbiAgICAgIHJlbWFpbmluZzogYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKSxcclxuICAgICAgcHJvY2Vzc2VkOiBzZXNzLnByb2Nlc3NlZCxcclxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHNlc3MudG90YWxBdFN0YXJ0LFxyXG4gICAgfSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdyZWZldGNoIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xyXG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlUmVmZXRjaCh0YXJnZXQuaGFuZGxlLCB0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRSZWZldGNoU2Vzc2lvbihzZXNzKTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuLy8gLS0tIE1lZGlhLWNyYXdsIGxvb3AgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy9cclxuLy8gTWlycm9ycyB0aGUgcmVmZXRjaCBsb29wIGJ1dCB0YXJnZXRzIHRoZSBtZWRpYS1jcmF3bCBxdWV1ZTogdHdlZXRzIHRoYXRcclxuLy8gdGhlIG5vcm1hbGl6ZXIgb2JzZXJ2ZWQgdmlhIHRoZSBNZWRpYSB0YWIgLyBVc2VyTWVkaWEgZW5kcG9pbnQgd2l0aFxyXG4vLyBpbnN1ZmZpY2llbnQgZGF0YSB0byBidWlsZCBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBUaGUgY3Jhd2wgbG9vcCB3YWxrc1xyXG4vLyBhIGRlZGljYXRlZCB0YWIgdGhyb3VnaCBlYWNoIHR3ZWV0J3MgZGV0YWlsIHBhZ2UgKGhhbmRsZS1sZXNzIFVSTCBmb3JtXHJcbi8vIHdoZW4gdGhlIGhpbnQtaGFuZGxlIGlzIG1pc3NpbmcpLCBhdCB0aGUgYXV0by1zY3JvbGwgY2FkZW5jZSwgc28gdGhlXHJcbi8vIHBhZ2UtaG9vayBjYW4gY2FwdHVyZSB0aGUgcmVhbCB0d2VldCBzaGFwZS5cclxuXHJcbmNvbnN0IE1FRElBX0NSQVdMX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV9tZWRpYV9jcmF3bF90YWJfaWRfXyc7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChNRURJQV9DUkFXTF9UQUJfS0VZKTtcclxuICBjb25zdCBpZCA9IHN0b3JlZFtNRURJQV9DUkFXTF9UQUJfS0VZXTtcclxuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2V0TWVkaWFDcmF3bFRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgaWYgKGlkID09PSBudWxsKSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKE1FRElBX0NSQVdMX1RBQl9LRVkpO1xyXG4gIGVsc2UgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtNRURJQV9DUkFXTF9UQUJfS0VZXTogaWQgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XHJcbiAgY29uc3QgdG90YWwgPSBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpO1xyXG4gIGlmICh0b3RhbCA9PT0gMCkge1xyXG4gICAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2w6IG5vdGhpbmcgcXVldWVkJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcclxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXHJcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcclxuICApO1xyXG4gIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHtcclxuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXHJcbiAgICBwcm9jZXNzZWQ6IDAsXHJcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIGluZmxpZ2h0OiBudWxsLFxyXG4gIH0pO1xyXG4gIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHMpO1xyXG4gIHZvaWQgbWVkaWFDcmF3bFRpY2soKTtcclxuICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5sZXQgbWVkaWFDcmF3bEludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0TWVkaWFDcmF3bEludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xyXG4gIGlmIChtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwobWVkaWFDcmF3bEludGVydmFsSGFuZGxlKTtcclxuICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIG1lZGlhQ3Jhd2xUaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ21lZGlhLWNyYXdsIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIH0pO1xyXG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpOiB2b2lkIHtcclxuICBpZiAobWVkaWFDcmF3bEludGVydmFsSGFuZGxlICE9PSBudWxsKSB7XHJcbiAgICBjbGVhckludGVydmFsKG1lZGlhQ3Jhd2xJbnRlcnZhbEhhbmRsZSk7XHJcbiAgICBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsTWVkaWFDcmF3bExvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xyXG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCdtZWRpYS1jcmF3bC10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXHJcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRNZWRpYUNyYXdsVGFiSWQoKTtcclxuICBhd2FpdCBzZXRNZWRpYUNyYXdsVGFiSWQobnVsbCk7XHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCk7XHJcbiAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obnVsbCk7XHJcbiAgYXdhaXQgaW5mbygnbWVkaWEtY3Jhd2wgbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcclxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gbWVkaWFDcmF3bFRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xyXG4gIGlmIChzZXNzID09PSBudWxsKSB7XHJcbiAgICBzdG9wTWVkaWFDcmF3bEludGVydmFsKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XHJcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2Uoc2Vzcy5pbmZsaWdodC5uYXZpZ2F0ZWRBdCk7XHJcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSB7XHJcbiAgICAgIHJldHVybjsgLy8gc3RpbGwgd2FpdGluZyBvbiB0aGUgcGFnZS1ob29rXHJcbiAgICB9XHJcbiAgICBhd2FpdCB3YXJuKCdtZWRpYS1jcmF3bDogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXHJcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2woc2Vzcy5pbmZsaWdodC50d2VldElkKTtcclxuICAgIHNlc3MucHJvY2Vzc2VkICs9IDE7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0gbnVsbDtcclxuICAgIGF3YWl0IHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHNlc3MpO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgdGFyZ2V0ID0gYXdhaXQgbmV4dE1lZGlhQ3Jhd2xUYXJnZXQoKTtcclxuICBpZiAoIXRhcmdldCkge1xyXG4gICAgc3RvcE1lZGlhQ3Jhd2xJbnRlcnZhbCgpO1xyXG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFRhYklkKG51bGwpO1xyXG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24obnVsbCk7XHJcbiAgICBhd2FpdCBpbmZvKCdtZWRpYS1jcmF3bCBsb29wIGNvbXBsZXRlJywgeyBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkIH0pO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgLy8gU2tpcCBpZiBhbHJlYWR5IGluIHRoZSBhcmNoaXZlIFx1MjAxNCBwYXJ0aWFsIGNhcHR1cmVzIGNhbiBvdXRsaXZlIGFcclxuICAvLyBzZXBhcmF0ZSBmdWxsIGNhcHR1cmUgcGF0aC5cclxuICBpZiAoYXdhaXQgaXNDb21taXR0ZWQodGFyZ2V0LnR3ZWV0SWQpKSB7XHJcbiAgICBhd2FpdCBkZXF1ZXVlTWVkaWFDcmF3bCh0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcclxuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICAvLyBXaGVuIHdlIGRvbid0IGtub3cgdGhlIHBhcmVudCdzIGF1dGhvciBoYW5kbGUgKHF1b3RlL1JUIG9mIGEgdHdlZXRcclxuICAvLyBYIHN0cmlwcGVkLCBvciBhIFVzZXJNZWRpYSB0aHVtYm5haWwgdGhhdCBsYWNrZWQgdGhlIGF1dGhvciBibG9jayksXHJcbiAgLy8gZmFsbCBiYWNrIHRvIGAvaS93ZWIvc3RhdHVzLzxpZD5gLiBYIHJlc29sdmVzIGl0IHRvIHRoZSBjb3JyZWN0XHJcbiAgLy8gZGV0YWlsIHBhZ2UsIHdoaWNoIGlzIGVub3VnaCBmb3IgdGhlIHBhZ2UtaG9vayB0byBpbmdlc3QgYVxyXG4gIC8vIFR3ZWV0RGV0YWlsIHJlc3BvbnNlLlxyXG4gIGNvbnN0IHVybCA9XHJcbiAgICB0YXJnZXQuYnVja2V0ID09PSAnX3Vua25vd24nXHJcbiAgICAgID8gYGh0dHBzOi8veC5jb20vaS93ZWIvc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YFxyXG4gICAgICA6IGBodHRwczovL3guY29tLyR7dGFyZ2V0LmJ1Y2tldH0vc3RhdHVzLyR7dGFyZ2V0LnR3ZWV0SWR9YDtcclxuICBsZXQgdGFiSWQgPSBhd2FpdCBnZXRNZWRpYUNyYXdsVGFiSWQoKTtcclxuICBpZiAodGFiSWQgIT09IG51bGwpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHRhYklkID0gbnVsbDtcclxuICAgIH1cclxuICB9XHJcbiAgdHJ5IHtcclxuICAgIGlmICh0YWJJZCA9PT0gbnVsbCkge1xyXG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuY3JlYXRlKHsgdXJsLCBhY3RpdmU6IGZhbHNlIH0pO1xyXG4gICAgICBpZiAodHlwZW9mIHRhYi5pZCA9PT0gJ251bWJlcicpIGF3YWl0IHNldE1lZGlhQ3Jhd2xUYWJJZCh0YWIuaWQpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYXdhaXQgYnJvd3Nlci50YWJzLnVwZGF0ZSh0YWJJZCwgeyB1cmwgfSk7XHJcbiAgICB9XHJcbiAgICBzZXNzID0gKGF3YWl0IGdldE1lZGlhQ3Jhd2xTZXNzaW9uKCkpID8/IHNlc3M7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xyXG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIH07XHJcbiAgICBhd2FpdCBzZXRNZWRpYUNyYXdsU2Vzc2lvbihzZXNzKTtcclxuICAgIGF3YWl0IGluZm8oJ21lZGlhLWNyYXdsIHRpY2snLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgaGludF9oYW5kbGU6IHRhcmdldC5idWNrZXQgPT09ICdfdW5rbm93bicgPyBudWxsIDogdGFyZ2V0LmJ1Y2tldCxcclxuICAgICAgcmVtYWluaW5nOiBhd2FpdCBtZWRpYUNyYXdsUXVldWVUb3RhbCgpLFxyXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxyXG4gICAgICB0b3RhbF9hdF9zdGFydDogc2Vzcy50b3RhbEF0U3RhcnQsXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ21lZGlhLWNyYXdsIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xyXG4gICAgICB0d2VldF9pZDogdGFyZ2V0LnR3ZWV0SWQsXHJcbiAgICAgIC4uLmRlc2NyaWJlRXJyb3IoZXJyKSxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgZGVxdWV1ZU1lZGlhQ3Jhd2wodGFyZ2V0LnR3ZWV0SWQpO1xyXG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgYXdhaXQgc2V0TWVkaWFDcmF3bFNlc3Npb24oc2Vzcyk7XHJcbiAgfVxyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbi8vIC0tLSBUaHJlYWQtb3BlbmluZyBsb29wIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy9cclxuLy8gVGltZWxpbmVzIG9mdGVuIHNob3cgYSBjb3JlIGFjY291bnQncyByb290IHR3ZWV0IHdpdGhvdXQgZXZlcnkgbGF0ZXJcclxuLy8gc2VsZi1yZXBseSBpbiB0aGUgY29udmVyc2F0aW9uLiBUaGlzIHV0aWxpdHkgd2Fsa3MgYSBkZWRpY2F0ZWQgdGFiIHRocm91Z2hcclxuLy8gcXVldWVkIGNvcmUgdGhyZWFkIHJvb3RzIGFuZCBudWRnZXMgdGhlIGRldGFpbCBwYWdlIHNvIFR3ZWV0RGV0YWlsIHBheWxvYWRzXHJcbi8vIGxvYWQgdGhlIHJlc3Qgb2YgdGhlIGNvbnZlcnNhdGlvbi5cclxuXHJcbmNvbnN0IFRIUkVBRF9PUEVOX1RBQl9LRVkgPSAnX19pbW1fYXJjaGl2ZV90aHJlYWRfb3Blbl90YWJfaWRfXyc7XHJcblxyXG5hc3luYyBmdW5jdGlvbiBnZXRUaHJlYWRPcGVuVGFiSWQoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XHJcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChUSFJFQURfT1BFTl9UQUJfS0VZKTtcclxuICBjb25zdCBpZCA9IHN0b3JlZFtUSFJFQURfT1BFTl9UQUJfS0VZXTtcclxuICByZXR1cm4gdHlwZW9mIGlkID09PSAnbnVtYmVyJyA/IGlkIDogbnVsbDtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2V0VGhyZWFkT3BlblRhYklkKGlkOiBudW1iZXIgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgaWYgKGlkID09PSBudWxsKSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFRIUkVBRF9PUEVOX1RBQl9LRVkpO1xyXG4gIGVsc2UgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtUSFJFQURfT1BFTl9UQUJfS0VZXTogaWQgfSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0VGhyZWFkT3Blbkxvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYWxsb3dNYW51YWxDYXB0dXJlV2luZG93KCk7XHJcbiAgY29uc3QgdG90YWwgPSBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpO1xyXG4gIGlmICh0b3RhbCA9PT0gMCkge1xyXG4gICAgYXdhaXQgaW5mbygndGhyZWFkLW9wZW46IG5vdGhpbmcgcXVldWVkJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IHNlY29uZHMgPSBNYXRoLm1pbihcclxuICAgIEFVVE9fU0NST0xMX01BWF9TRUMsXHJcbiAgICBNYXRoLm1heChBVVRPX1NDUk9MTF9NSU5fU0VDLCBNYXRoLnJvdW5kKHMuYXV0b1Njcm9sbEludGVydmFsU2VjKSlcclxuICApO1xyXG4gIGF3YWl0IHNldFRocmVhZE9wZW5TZXNzaW9uKHtcclxuICAgIHRvdGFsQXRTdGFydDogdG90YWwsXHJcbiAgICBwcm9jZXNzZWQ6IDAsXHJcbiAgICBzdGFydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIGluZmxpZ2h0OiBudWxsLFxyXG4gIH0pO1xyXG4gIHN0YXJ0VGhyZWFkT3BlbkludGVydmFsKHNlY29uZHMpO1xyXG4gIHZvaWQgdGhyZWFkT3BlblRpY2soKTtcclxuICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiBsb29wIHN0YXJ0ZWQnLCB7IHF1ZXVlZDogdG90YWwsIGludGVydmFsX3NlYzogc2Vjb25kcyB9KTtcclxuICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG59XHJcblxyXG5sZXQgdGhyZWFkT3BlbkludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcclxuXHJcbmZ1bmN0aW9uIHN0YXJ0VGhyZWFkT3BlbkludGVydmFsKHNlY29uZHM6IG51bWJlcik6IHZvaWQge1xyXG4gIGlmICh0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwpIGNsZWFySW50ZXJ2YWwodGhyZWFkT3BlbkludGVydmFsSGFuZGxlKTtcclxuICB0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XHJcbiAgICB2b2lkIHRocmVhZE9wZW5UaWNrKCkuY2F0Y2goKGVycikgPT4ge1xyXG4gICAgICB2b2lkIHdhcm4oJ3RocmVhZC1vcGVuIHRpY2sgZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnIpKTtcclxuICAgIH0pO1xyXG4gIH0sIHNlY29uZHMgKiAxMDAwKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc3RvcFRocmVhZE9wZW5JbnRlcnZhbCgpOiB2b2lkIHtcclxuICBpZiAodGhyZWFkT3BlbkludGVydmFsSGFuZGxlICE9PSBudWxsKSB7XHJcbiAgICBjbGVhckludGVydmFsKHRocmVhZE9wZW5JbnRlcnZhbEhhbmRsZSk7XHJcbiAgICB0aHJlYWRPcGVuSW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsVGhyZWFkT3Blbkxvb3AoKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgc3RvcFRocmVhZE9wZW5JbnRlcnZhbCgpO1xyXG4gIGF3YWl0IGJyb3dzZXIuYWxhcm1zLmNsZWFyKCd0aHJlYWQtb3Blbi10aWNrJyk7IC8vIGxlZ2FjeSBjbGVhbnVwXHJcbiAgY29uc3QgdGFiSWQgPSBhd2FpdCBnZXRUaHJlYWRPcGVuVGFiSWQoKTtcclxuICBhd2FpdCBzZXRUaHJlYWRPcGVuVGFiSWQobnVsbCk7XHJcbiAgY29uc3Qgc2VzcyA9IGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCk7XHJcbiAgYXdhaXQgc2V0VGhyZWFkT3BlblNlc3Npb24obnVsbCk7XHJcbiAgYXdhaXQgaW5mbygndGhyZWFkLW9wZW4gbG9vcCBjYW5jZWxsZWQnLCB7XHJcbiAgICBoYWRfdGFiOiB0YWJJZCAhPT0gbnVsbCxcclxuICAgIHByb2Nlc3NlZDogc2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgfSk7XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gdGhyZWFkT3BlblRpY2soKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgbGV0IHNlc3MgPSBhd2FpdCBnZXRUaHJlYWRPcGVuU2Vzc2lvbigpO1xyXG4gIGlmIChzZXNzID09PSBudWxsKSB7XHJcbiAgICBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmIChzZXNzLmluZmxpZ2h0ICE9PSBudWxsKSB7XHJcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2Uoc2Vzcy5pbmZsaWdodC5uYXZpZ2F0ZWRBdCk7XHJcbiAgICBpZiAoZWxhcHNlZCA8IElOR0VTVF9XQUlUX01TKSByZXR1cm47XHJcbiAgICBhd2FpdCB3YXJuKCd0aHJlYWQtb3BlbjogdGFyZ2V0IHRpbWVkIG91dCB3YWl0aW5nIGZvciBpbmdlc3QnLCB7XHJcbiAgICAgIHR3ZWV0X2lkOiBzZXNzLmluZmxpZ2h0LnR3ZWV0SWQsXHJcbiAgICAgIHdhaXRlZF9tczogZWxhcHNlZCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgbWFya1RocmVhZE9wZW5TZWVuKHNlc3MuaW5mbGlnaHQudHdlZXRJZCk7XHJcbiAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3BlbihzZXNzLmluZmxpZ2h0LnR3ZWV0SWQpO1xyXG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgYXdhaXQgc2V0VGhyZWFkT3BlblNlc3Npb24oc2Vzcyk7XHJcbiAgfVxyXG5cclxuICBjb25zdCB0YXJnZXQgPSBhd2FpdCBuZXh0VGhyZWFkT3BlblRhcmdldCgpO1xyXG4gIGlmICghdGFyZ2V0KSB7XHJcbiAgICBzdG9wVGhyZWFkT3BlbkludGVydmFsKCk7XHJcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuVGFiSWQobnVsbCk7XHJcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihudWxsKTtcclxuICAgIGF3YWl0IGluZm8oJ3RocmVhZC1vcGVuIGxvb3AgY29tcGxldGUnLCB7IHByb2Nlc3NlZDogc2Vzcy5wcm9jZXNzZWQgfSk7XHJcbiAgICBhd2FpdCBicm9hZGNhc3RTdGF0ZSgpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBpZiAoYXdhaXQgaGFzVGhyZWFkT3BlblNlZW4odGFyZ2V0LnR3ZWV0SWQpKSB7XHJcbiAgICBhd2FpdCBkZXF1ZXVlVGhyZWFkT3Blbih0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzLnByb2Nlc3NlZCArPSAxO1xyXG4gICAgc2Vzcy5pbmZsaWdodCA9IG51bGw7XHJcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzZXNzKTtcclxuICAgIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICBjb25zdCB1cmwgPSBgaHR0cHM6Ly94LmNvbS8ke3RhcmdldC5oYW5kbGV9L3N0YXR1cy8ke3RhcmdldC50d2VldElkfWA7XHJcbiAgbGV0IHRhYklkID0gYXdhaXQgZ2V0VGhyZWFkT3BlblRhYklkKCk7XHJcbiAgaWYgKHRhYklkICE9PSBudWxsKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcclxuICAgIH0gY2F0Y2gge1xyXG4gICAgICB0YWJJZCA9IG51bGw7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHRyeSB7XHJcbiAgICBpZiAodGFiSWQgPT09IG51bGwpIHtcclxuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYnJvd3Nlci50YWJzLmNyZWF0ZSh7IHVybCwgYWN0aXZlOiBmYWxzZSB9KTtcclxuICAgICAgaWYgKHR5cGVvZiB0YWIuaWQgIT09ICdudW1iZXInKSB0aHJvdyBuZXcgRXJyb3IoJ2NyZWF0ZWQgdGFiIHdpdGhvdXQgaWQnKTtcclxuICAgICAgdGFiSWQgPSB0YWIuaWQ7XHJcbiAgICAgIGF3YWl0IHNldFRocmVhZE9wZW5UYWJJZCh0YWJJZCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBhd2FpdCBicm93c2VyLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybCB9KTtcclxuICAgIH1cclxuICAgIGF3YWl0IG1hcmtUaHJlYWRPcGVuU2Vlbih0YXJnZXQudHdlZXRJZCk7XHJcbiAgICBzZXNzID0gKGF3YWl0IGdldFRocmVhZE9wZW5TZXNzaW9uKCkpID8/IHNlc3M7XHJcbiAgICBzZXNzLmluZmxpZ2h0ID0ge1xyXG4gICAgICB0d2VldElkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgbmF2aWdhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIH07XHJcbiAgICBhd2FpdCBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzZXNzKTtcclxuICAgIGlmICh0YWJJZCAhPT0gbnVsbCkge1xyXG4gICAgICB2b2lkIG51ZGdlVGhyZWFkT3BlblRhYih0YWJJZCk7XHJcbiAgICB9XHJcbiAgICBhd2FpdCBpbmZvKCd0aHJlYWQtb3BlbiB0aWNrJywge1xyXG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgcmVtYWluaW5nOiBhd2FpdCB0aHJlYWRPcGVuUXVldWVUb3RhbCgpLFxyXG4gICAgICBwcm9jZXNzZWQ6IHNlc3MucHJvY2Vzc2VkLFxyXG4gICAgICB0b3RhbF9hdF9zdGFydDogc2Vzcy50b3RhbEF0U3RhcnQsXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ3RocmVhZC1vcGVuIG5hdmlnYXRlIGZhaWxlZDsgZHJvcHBpbmcgdGFyZ2V0Jywge1xyXG4gICAgICBoYW5kbGU6IHRhcmdldC5oYW5kbGUsXHJcbiAgICAgIHR3ZWV0X2lkOiB0YXJnZXQudHdlZXRJZCxcclxuICAgICAgLi4uZGVzY3JpYmVFcnJvcihlcnIpLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBtYXJrVGhyZWFkT3BlblNlZW4odGFyZ2V0LnR3ZWV0SWQpO1xyXG4gICAgYXdhaXQgZGVxdWV1ZVRocmVhZE9wZW4odGFyZ2V0LnR3ZWV0SWQpO1xyXG4gICAgc2Vzcy5wcm9jZXNzZWQgKz0gMTtcclxuICAgIHNlc3MuaW5mbGlnaHQgPSBudWxsO1xyXG4gICAgYXdhaXQgc2V0VGhyZWFkT3BlblNlc3Npb24oc2Vzcyk7XHJcbiAgfVxyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIG51ZGdlVGhyZWFkT3BlblRhYih0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgMTUwMCkpO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBicm93c2VyLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcclxuICAgICAgdGFyZ2V0OiB7IHRhYklkIH0sXHJcbiAgICAgIHdvcmxkOiAnTUFJTicgYXMgJ0lTT0xBVEVEJyxcclxuICAgICAgZnVuYzogKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGggPSB3aW5kb3cuaW5uZXJIZWlnaHQ7XHJcbiAgICAgICAgY29uc3Qgc3RlcCA9ICgpID0+IHdpbmRvdy5zY3JvbGxCeSh7IHRvcDogaCAqIDEuMywgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xyXG4gICAgICAgIHN0ZXAoKTtcclxuICAgICAgICBzZXRUaW1lb3V0KHN0ZXAsIDE0MDApO1xyXG4gICAgICAgIHNldFRpbWVvdXQoc3RlcCwgMjgwMCk7XHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ3RocmVhZC1vcGVuIHNjcm9sbC1udWRnZSBmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuLy8gLS0tIFF1YXJhbnRpbmUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHF1YXJhbnRpbmUoXHJcbiAgcmVhc29uOiBzdHJpbmcsXHJcbiAgZW5kcG9pbnQ6IHN0cmluZyxcclxuICB1cmw6IHN0cmluZyxcclxuICByYXc6IHVua25vd24sXHJcbiAgZXJyOiB1bmtub3duXHJcbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGF3YWl0IGxvZ0VycigncXVhcmFudGluaW5nIGNhcHR1cmUnLCB7IHJlYXNvbiwgZW5kcG9pbnQsIHVybCwgLi4uZGVzY3JpYmVFcnJvcihlcnIpIH0pO1xyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCB8fCAhc2V0dGluZ3Mub3duZXIgfHwgIXNldHRpbmdzLnJlcG8pIHJldHVybjtcclxuICBjb25zdCBwYXlsb2FkOiBRdWFyYW50aW5lUGF5bG9hZCA9IHtcclxuICAgIHNjaGVtYV92ZXJzaW9uOiAxLFxyXG4gICAgcmVhc29uLFxyXG4gICAgZW5kcG9pbnQsXHJcbiAgICBjYXB0dXJlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgc291cmNlX3VybDogdXJsLFxyXG4gICAgZXJyb3I6IGRlc2NyaWJlRXJyb3IoZXJyKSxcclxuICAgIHJhdyxcclxuICB9O1xyXG4gIGNvbnN0IHRzID0gaXNvQ29tcGFjdChwYXlsb2FkLmNhcHR1cmVkX2F0KTtcclxuICBjb25zdCBoYXNoID0gYXdhaXQgc2hhOChKU09OLnN0cmluZ2lmeShwYXlsb2FkKSk7XHJcbiAgY29uc3QgcGF0aCA9IGByYXcvX3F1YXJhbnRpbmUvJHt0c30tJHtoYXNofS5qc29uYDtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XHJcbiAgICBhd2FpdCBjbGllbnQucHV0RmlsZSh7XHJcbiAgICAgIHBhdGgsXHJcbiAgICAgIGNvbnRlbnRCYXNlNjQ6IHRvQmFzZTY0KEpTT04uc3RyaW5naWZ5KHBheWxvYWQsIG51bGwsIDIpICsgJ1xcbicpLFxyXG4gICAgICBtZXNzYWdlOiBgcXVhcmFudGluZTogJHtyZWFzb259ICR7ZW5kcG9pbnR9YCxcclxuICAgIH0pO1xyXG4gIH0gY2F0Y2ggKHFlcnIpIHtcclxuICAgIGF3YWl0IGxvZ0VycigncXVhcmFudGluZSBjb21taXQgZmFpbGVkJywgeyAuLi5kZXNjcmliZUVycm9yKHFlcnIpIH0pO1xyXG4gIH1cclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gc2hhOChzOiBzdHJpbmcpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIGNvbnN0IGJ1ZiA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShzKTtcclxuICBjb25zdCBkaWdlc3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGJ1Zik7XHJcbiAgY29uc3QgaGV4ID0gQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShkaWdlc3QpKVxyXG4gICAgLm1hcCgoYikgPT4gYi50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKSlcclxuICAgIC5qb2luKCcnKTtcclxuICByZXR1cm4gaGV4LnNsaWNlKDAsIDgpO1xyXG59XHJcblxyXG4vLyAtLS0gQ29ubmVjdGlvbiB2ZXJpZmljYXRpb24gJiBhY2NvdW50cyBsaXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5hc3luYyBmdW5jdGlvbiB2ZXJpZnlDb25uZWN0aW9uKGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGlmICghc2V0dGluZ3MucGF0IHx8ICFzZXR0aW5ncy5vd25lciB8fCAhc2V0dGluZ3MucmVwbykge1xyXG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgIHN0YXR1czogJ25vdC1jb25maWd1cmVkJyxcclxuICAgICAgbG9naW46IG51bGwsXHJcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICBlcnJvcjogbnVsbCxcclxuICAgICAgZGVmYXVsdEJyYW5jaDogbnVsbCxcclxuICAgICAgY29uZmlndXJlZEJyYW5jaEV4aXN0czogbnVsbCxcclxuICAgICAgcmF0ZUxpbWl0UmVzZXRBdDogbnVsbCxcclxuICAgIH0pO1xyXG4gICAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcclxuICBpZiAoIWZvcmNlKSB7XHJcbiAgICAvLyBTa2lwIGlmIHdlJ3JlIGluc2lkZSB0aGUgcmVwb3J0ZWQgcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IHJlLWNoZWNraW5nXHJcbiAgICAvLyBiZWZvcmUgcmVzZXQganVzdCB3YXN0ZXMgbW9yZSBvZiB0aGUgc2FtZSBleGhhdXN0ZWQgcXVvdGEgYW5kIGtlZXBzXHJcbiAgICAvLyB0aGUgNDAzcyBjb21pbmcuXHJcbiAgICBpZiAoY29ubi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnICYmIGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAhPT0gbnVsbCkge1xyXG4gICAgICBjb25zdCBub3dTZWMgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcclxuICAgICAgaWYgKG5vd1NlYyA8IGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCkgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgLy8gQXBwbHkgdGhlIHBlcmlvZGljLWNoZWNrIGdhdGUgdG8gZXZlcnkgc3RhdHVzLCBub3QganVzdCAnb2snLiBUaGVcclxuICAgIC8vIHByZXZpb3VzIGJlaGF2aW9yIHJlLXZlcmlmaWVkIG9uIGV2ZXJ5IHdha2Ugd2hlbmV2ZXIgdGhlIGNvbm5lY3Rpb25cclxuICAgIC8vIHdhc24ndCAnb2snLCB3aGljaCBkdXJpbmcgYSByYXRlLWxpbWl0IHdpbmRvdyBtZWFudCAyIEFQSSBjYWxscyBwZXJcclxuICAgIC8vIFNXIHdha2UgKHZlcmlmeVJlcG9BY2Nlc3MgZG9lcyBHRVQgL3VzZXIgKyBHRVQgL3JlcG9zL3tvfS97cn0pLlxyXG4gICAgaWYgKGNvbm4uY2hlY2tlZEF0KSB7XHJcbiAgICAgIGNvbnN0IGFnZSA9IERhdGUubm93KCkgLSBEYXRlLnBhcnNlKGNvbm4uY2hlY2tlZEF0KTtcclxuICAgICAgaWYgKGFnZSA8IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TKSByZXR1cm47XHJcbiAgICB9XHJcbiAgfVxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBjbGllbnQgPSBuZXcgR2l0SHViQ2xpZW50KHNldHRpbmdzKTtcclxuICAgIGNvbnN0IHIgPSBhd2FpdCBjbGllbnQudmVyaWZ5UmVwb0FjY2VzcygpO1xyXG4gICAgLy8gUHJvYmUgdGhlIGNvbmZpZ3VyZWQgYnJhbmNoLiBBIG5vbi1kZWZhdWx0IGJyYW5jaCBpcyBmaW5lIFx1MjAxNCBpdCdzXHJcbiAgICAvLyByb3V0aW5lIHRvIGNhcHR1cmUgaW50byBhIHdvcmtpbmcgYnJhbmNoIFx1MjAxNCBidXQgYSAqbWlzc2luZyogYnJhbmNoXHJcbiAgICAvLyB3b3VsZCA0MjIgZXZlcnkgY29tbWl0LlxyXG4gICAgbGV0IGJyYW5jaE9rID0gdHJ1ZTtcclxuICAgIGlmIChzZXR0aW5ncy5icmFuY2ggJiYgc2V0dGluZ3MuYnJhbmNoICE9PSByLmRlZmF1bHRfYnJhbmNoKSB7XHJcbiAgICAgIGJyYW5jaE9rID0gYXdhaXQgY2xpZW50LmJyYW5jaEV4aXN0cyhzZXR0aW5ncy5icmFuY2gpO1xyXG4gICAgfVxyXG4gICAgY29uc3QgY2hlY2tXcml0ZSA9IGZvcmNlIHx8IGlzV3JpdGVBdXRoRXJyb3IoY29ubi5lcnJvcik7XHJcbiAgICBpZiAoYnJhbmNoT2sgJiYgY2hlY2tXcml0ZSkge1xyXG4gICAgICBhd2FpdCBjbGllbnQudmVyaWZ5V3JpdGVBY2Nlc3MoKTtcclxuICAgIH1cclxuICAgIGF3YWl0IHNldENvbm5lY3Rpb24oe1xyXG4gICAgICBzdGF0dXM6ICdvaycsXHJcbiAgICAgIGxvZ2luOiByLmxvZ2luLFxyXG4gICAgICBjaGVja2VkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgZXJyb3I6IG51bGwsXHJcbiAgICAgIGRlZmF1bHRCcmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXHJcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IGJyYW5jaE9rLFxyXG4gICAgICByYXRlTGltaXRSZXNldEF0OiBudWxsLFxyXG4gICAgfSk7XHJcbiAgICBhd2FpdCBpbmZvKCdjb25uZWN0aW9uIHZlcmlmaWVkJywge1xyXG4gICAgICBsb2dpbjogci5sb2dpbixcclxuICAgICAgcmVwbzogci5mdWxsX25hbWUsXHJcbiAgICAgIGRlZmF1bHRfYnJhbmNoOiByLmRlZmF1bHRfYnJhbmNoLFxyXG4gICAgICBjb25maWd1cmVkX2JyYW5jaDogc2V0dGluZ3MuYnJhbmNoLFxyXG4gICAgICBjb25maWd1cmVkX2JyYW5jaF9leGlzdHM6IGJyYW5jaE9rLFxyXG4gICAgICB3cml0ZV9hY2Nlc3M6IGNoZWNrV3JpdGUgPyAnY2hlY2tlZCcgOiAnbm90X2NoZWNrZWQnLFxyXG4gICAgfSk7XHJcbiAgICBpZiAoIWJyYW5jaE9rKSB7XHJcbiAgICAgIGF3YWl0IHdhcm4oJ2NvbmZpZ3VyZWQgYnJhbmNoIGRvZXMgbm90IGV4aXN0IG9uIHJlbW90ZScsIHtcclxuICAgICAgICBjb25maWd1cmVkOiBzZXR0aW5ncy5icmFuY2gsXHJcbiAgICAgICAgZGVmYXVsdF9icmFuY2g6IHIuZGVmYXVsdF9icmFuY2gsXHJcbiAgICAgICAgZml4OiAnb3BlbiBTZXR0aW5ncyBhbmQgY2hhbmdlIGJyYW5jaCB0byAnICsgci5kZWZhdWx0X2JyYW5jaCxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zdCBjYXQgPSBlcnIgaW5zdGFuY2VvZiBHaXRIdWJFcnJvciA/IGVyci5jYXRlZ29yeSA6ICd1bmtub3duJztcclxuICAgIGNvbnN0IHN0YXR1czogQ29ubmVjdGlvblN0YXRlWydzdGF0dXMnXSA9XHJcbiAgICAgIGNhdCA9PT0gJ2F1dGgnXHJcbiAgICAgICAgPyAnYXV0aC1lcnJvcidcclxuICAgICAgICA6IGNhdCA9PT0gJ3JhdGUtbGltaXQnXHJcbiAgICAgICAgICA/ICdyYXRlLWxpbWl0ZWQnXHJcbiAgICAgICAgICA6IGNhdCA9PT0gJ25ldHdvcmsnXHJcbiAgICAgICAgICAgID8gJ25ldHdvcmstZXJyb3InXHJcbiAgICAgICAgICAgIDogJ2F1dGgtZXJyb3InO1xyXG4gICAgY29uc3QgcmVzZXRBdCA9XHJcbiAgICAgIGVyciBpbnN0YW5jZW9mIEdpdEh1YkVycm9yICYmIGNhdCA9PT0gJ3JhdGUtbGltaXQnID8gZXJyLnJhdGVMaW1pdFJlc2V0QXQgOiBudWxsO1xyXG4gICAgYXdhaXQgc2V0Q29ubmVjdGlvbih7XHJcbiAgICAgIHN0YXR1cyxcclxuICAgICAgbG9naW46IG51bGwsXHJcbiAgICAgIGNoZWNrZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxyXG4gICAgICBlcnJvcjogZGVzY3JpYmVFcnJvcihlcnIpLm1lc3NhZ2UsXHJcbiAgICAgIGRlZmF1bHRCcmFuY2g6IG51bGwsXHJcbiAgICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXHJcbiAgICAgIHJhdGVMaW1pdFJlc2V0QXQ6IHJlc2V0QXQsXHJcbiAgICB9KTtcclxuICAgIGF3YWl0IHdhcm4oJ2Nvbm5lY3Rpb24gY2hlY2sgZmFpbGVkJywge1xyXG4gICAgICBjYXRlZ29yeTogY2F0LFxyXG4gICAgICByYXRlTGltaXRSZXNldEF0OiByZXNldEF0LFxyXG4gICAgICAuLi5kZXNjcmliZUVycm9yKGVyciksXHJcbiAgICB9KTtcclxuICB9XHJcbiAgYXdhaXQgYnJvYWRjYXN0U3RhdGUoKTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaEFjY291bnRzTGlzdChmb3JjZTogYm9vbGVhbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcclxuICBpZiAoIXNldHRpbmdzLnBhdCkge1xyXG4gICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG4gIGlmICghZm9yY2UpIHtcclxuICAgIC8vIFNraXAgd2hpbGUgaW5zaWRlIGEga25vd24gcmF0ZS1saW1pdCB3aW5kb3cgXHUyMDE0IGFjY291bnRzLnlhbWwgaXMgZmV0Y2hlZFxyXG4gICAgLy8gdmlhIGF1dGhlbnRpY2F0ZWQgcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSwgd2hpY2ggY291bnRzIGFnYWluc3QgdGhlXHJcbiAgICAvLyBzYW1lIHF1b3RhLlxyXG4gICAgY29uc3QgY29ubiA9IGF3YWl0IGdldENvbm5lY3Rpb24oKTtcclxuICAgIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcgJiYgY29ubi5yYXRlTGltaXRSZXNldEF0ICE9PSBudWxsKSB7XHJcbiAgICAgIGNvbnN0IG5vd1NlYyA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xyXG4gICAgICBpZiAobm93U2VjIDwgY29ubi5yYXRlTGltaXRSZXNldEF0KSByZXR1cm47XHJcbiAgICB9XHJcbiAgICAvLyBTa2lwIGlmIHdlIHJlZnJlc2hlZCByZWNlbnRseS4gYWNjb3VudHMueWFtbCBjaGFuZ2VzIHJhcmVseSBcdTIwMTQgdGhlIG9sZFxyXG4gICAgLy8gY29kZSByZS1mZXRjaGVkIGl0IG9uIGV2ZXJ5IFNXIHdha2UsIHdoaWNoIGR1cmluZyBoZWF2eSBicm93c2luZyBtZWFudFxyXG4gICAgLy8gYSBHaXRIdWIgY2FsbCBldmVyeSBmZXcgc2Vjb25kcyBldmVuIHdoZW4gbm90aGluZyB3YXMgYmVpbmcgY2FwdHVyZWQuXHJcbiAgICBjb25zdCBsYXN0UmVmcmVzaGVkID0gYXdhaXQgZ2V0QWNjb3VudHNSZWZyZXNoZWRBdCgpO1xyXG4gICAgaWYgKGxhc3RSZWZyZXNoZWQpIHtcclxuICAgICAgY29uc3QgYWdlID0gRGF0ZS5ub3coKSAtIERhdGUucGFyc2UobGFzdFJlZnJlc2hlZCk7XHJcbiAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUoYWdlKSAmJiBhZ2UgPCBWRVJJRllfQ09OTkVDVElPTl9JTlRFUlZBTF9NUykgcmV0dXJuO1xyXG4gICAgfVxyXG4gIH1cclxuICB0cnkge1xyXG4gICAgY29uc3QgY2xpZW50ID0gbmV3IEdpdEh1YkNsaWVudChzZXR0aW5ncyk7XHJcbiAgICBjb25zdCB0ZXh0ID0gYXdhaXQgY2xpZW50LmZldGNoUmF3VGV4dCgnY29uZmlnL2FjY291bnRzLnlhbWwnKTtcclxuICAgIGlmICghdGV4dCkge1xyXG4gICAgICBpZiAoZm9yY2UpIGF3YWl0IHdhcm4oJ2FjY291bnRzLnlhbWwgbm90IGZvdW5kIGluIHJlcG87IHVzaW5nIGZhbGxiYWNrJyk7XHJcbiAgICAgIGF3YWl0IHNldEFjY291bnRzKFsuLi5GQUxMQkFDS19BQ0NPVU5UU10pO1xyXG4gICAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlQWNjb3VudHNZYW1sKHRleHQpO1xyXG4gICAgaWYgKHBhcnNlZC5sZW5ndGggPT09IDApIHtcclxuICAgICAgYXdhaXQgd2FybignYWNjb3VudHMueWFtbCBwYXJzZWQgZW1wdHk7IGtlZXBpbmcgZmFsbGJhY2snKTtcclxuICAgICAgYXdhaXQgc2V0QWNjb3VudHMoWy4uLkZBTExCQUNLX0FDQ09VTlRTXSk7XHJcbiAgICAgIGF3YWl0IHNldEFjY291bnRzUmVmcmVzaGVkQXQobmV3IERhdGUoKS50b0lTT1N0cmluZygpKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgYXdhaXQgc2V0QWNjb3VudHMocGFyc2VkKTtcclxuICAgIGF3YWl0IHJlZnJlc2hBcmNoaXZlU25hcHNob3QoY2xpZW50LCBmb3JjZSk7XHJcbiAgICBhd2FpdCBzZXRBY2NvdW50c1JlZnJlc2hlZEF0KG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSk7XHJcbiAgICBpZiAoZm9yY2UpIGF3YWl0IGluZm8oJ2FjY291bnRzIGxpc3QgcmVmcmVzaGVkJywgeyBjb3VudDogcGFyc2VkLmxlbmd0aCB9KTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGF3YWl0IHdhcm4oJ3JlZnJlc2ggYWNjb3VudHMgZmFpbGVkOyBrZWVwaW5nIGN1cnJlbnQgbGlzdCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgfVxyXG4gIGF3YWl0IGJyb2FkY2FzdFN0YXRlKCk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hBcmNoaXZlU25hcHNob3QoY2xpZW50OiBHaXRIdWJDbGllbnQsIGZvcmNlOiBib29sZWFuKTogUHJvbWlzZTx2b2lkPiB7XHJcbiAgY29uc3QgdGV4dCA9IGF3YWl0IGNsaWVudC5mZXRjaFJhd1RleHQoJ2RhdGEvbWFuaWZlc3QuanNvbicpO1xyXG4gIGlmICghdGV4dCkge1xyXG4gICAgYXdhaXQgc2V0QXJjaGl2ZVNuYXBzaG90KG51bGwpO1xyXG4gICAgaWYgKGZvcmNlKSBhd2FpdCB3YXJuKCdhcmNoaXZlIG1hbmlmZXN0IG5vdCBmb3VuZDsgb2xkLXR3ZWV0IGRldGVjdGlvbiBkaXNhYmxlZCcpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICB0cnkge1xyXG4gICAgY29uc3Qgc25hcHNob3QgPSBwYXJzZUFyY2hpdmVTbmFwc2hvdChKU09OLnBhcnNlKHRleHQpIGFzIHVua25vd24pO1xyXG4gICAgYXdhaXQgc2V0QXJjaGl2ZVNuYXBzaG90KHNuYXBzaG90KTtcclxuICAgIGlmIChmb3JjZSkge1xyXG4gICAgICBhd2FpdCBpbmZvKCdhcmNoaXZlIHNuYXBzaG90IHJlZnJlc2hlZCcsIHtcclxuICAgICAgICBhY2NvdW50czogT2JqZWN0LmtleXMoc25hcHNob3QuYWNjb3VudHMpLmxlbmd0aCxcclxuICAgICAgICBnZW5lcmF0ZWRfYXQ6IHNuYXBzaG90LmdlbmVyYXRlZF9hdCxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBhd2FpdCB3YXJuKCdhcmNoaXZlIHNuYXBzaG90IHBhcnNlIGZhaWxlZDsgb2xkLXR3ZWV0IGRldGVjdGlvbiBkaXNhYmxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0gU3RhdGUgYnJvYWRjYXN0IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG5hc3luYyBmdW5jdGlvbiBicm9hZGNhc3RTdGF0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcclxuICBjb25zdCBzdGF0ZSA9IGF3YWl0IGJ1aWxkU3RhdGUoKTtcclxuICBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnc3RhdGUtY2hhbmdlZCcsIHN0YXRlIH0pLmNhdGNoKCgpID0+IHt9KTtcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gYnVpbGRTdGF0ZSgpOiBQcm9taXNlPEV4dGVuc2lvblN0YXRlPiB7XHJcbiAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xyXG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XHJcbiAgY29uc3QgYWNjb3VudHMgPSBhd2FpdCBnZXRBY2NvdW50cygpO1xyXG4gIGNvbnN0IGNvdW50ZXJzID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcclxuICBsZXQgdGFiQ291bnQgPSAwO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB0YWJzID0gYXdhaXQgYnJvd3Nlci50YWJzLnF1ZXJ5KHsgdXJsOiBbJ2h0dHBzOi8veC5jb20vKicsICdodHRwczovL3R3aXR0ZXIuY29tLyonXSB9KTtcclxuICAgIHRhYkNvdW50ID0gdGFicy5sZW5ndGg7XHJcbiAgfSBjYXRjaCB7XHJcbiAgICAvLyB0YWJzLnF1ZXJ5IGlzIGFsbG93ZWQgYnkgdGhlIG1hbmlmZXN0IGJ1dCBjYW4gdHJhbnNpZW50bHkgZmFpbFxyXG4gICAgLy8gYXJvdW5kIGV4dGVuc2lvbiBzdGFydHVwOyBzdXJmYWNpbmcgMCBpcyBmaW5lLlxyXG4gIH1cclxuICBjb25zdCByZWZldGNoUXVldWVkID0gYXdhaXQgcmVmZXRjaFF1ZXVlVG90YWwoKTtcclxuICBjb25zdCBtZWRpYUNyYXdsUXVldWVkID0gYXdhaXQgbWVkaWFDcmF3bFF1ZXVlVG90YWwoKTtcclxuICBjb25zdCB0aHJlYWRPcGVuUXVldWVkID0gYXdhaXQgdGhyZWFkT3BlblF1ZXVlVG90YWwoKTtcclxuICBjb25zdCByZWZldGNoU2VzcyA9IGF3YWl0IGdldFJlZmV0Y2hTZXNzaW9uKCk7XHJcbiAgY29uc3QgbWVkaWFDcmF3bFNlc3MgPSBhd2FpdCBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpO1xyXG4gIGNvbnN0IHRocmVhZE9wZW5TZXNzID0gYXdhaXQgZ2V0VGhyZWFkT3BlblNlc3Npb24oKTtcclxuICBjb25zdCBhdXRvU2Nyb2xsU2VzcyA9IGF3YWl0IGdldEF1dG9TY3JvbGxTZXNzaW9uKCk7XHJcbiAgY29uc3QgcmVjZW50VHdlZXRTaWdodGluZ3MgPSBhd2FpdCBnZXRSZWNlbnRUd2VldFNpZ2h0aW5ncygpO1xyXG4gIHJldHVybiB7XHJcbiAgICB2ZXJzaW9uOiBFWFRfVkVSU0lPTixcclxuICAgIHNldHRpbmdzOiByZWRhY3RTZXR0aW5ncyhzZXR0aW5ncyksXHJcbiAgICBjb25uZWN0aW9uOiBjb25uLFxyXG4gICAgYWNjb3VudHMsXHJcbiAgICBjb3VudGVycyxcclxuICAgIGF1dG9TY3JvbGw6IHtcclxuICAgICAgYWN0aXZlOiBhdXRvU2Nyb2xsU2VzcyAhPT0gbnVsbCAmJiBhdXRvU2Nyb2xsVGltZXIgIT09IG51bGwsXHJcbiAgICAgIHRhYkNvdW50LFxyXG4gICAgICBzY3JvbGxDb3VudDogYXV0b1Njcm9sbFNlc3M/LnNjcm9sbENvdW50ID8/IDAsXHJcbiAgICAgIGluZ2VzdGVkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5pbmdlc3RlZENvdW50ID8/IDAsXHJcbiAgICAgIGluZ2VzdGVkTmV3Q291bnQ6IGF1dG9TY3JvbGxTZXNzPy5pbmdlc3RlZE5ld0NvdW50ID8/IDAsXHJcbiAgICAgIGluZ2VzdGVkRXhpc3RpbmdDb3VudDogYXV0b1Njcm9sbFNlc3M/LmluZ2VzdGVkRXhpc3RpbmdDb3VudCA/PyAwLFxyXG4gICAgICBza2lwcGVkT2xkQ291bnQ6IGF1dG9TY3JvbGxTZXNzPy5za2lwcGVkT2xkQ291bnQgPz8gMCxcclxuICAgICAgZXhwYW5kZWRDb3VudDogYXV0b1Njcm9sbFNlc3M/LmV4cGFuZGVkQ291bnQgPz8gMCxcclxuICAgIH0sXHJcbiAgICByZWZldGNoUXVldWU6IHtcclxuICAgICAgdG90YWw6IHJlZmV0Y2hRdWV1ZWQsXHJcbiAgICAgIHJ1bm5pbmc6IHJlZmV0Y2hJbnRlcnZhbEhhbmRsZSAhPT0gbnVsbCxcclxuICAgICAgcHJvY2Vzc2VkOiByZWZldGNoU2Vzcz8ucHJvY2Vzc2VkID8/IDAsXHJcbiAgICAgIHRvdGFsX2F0X3N0YXJ0OiByZWZldGNoU2Vzcz8udG90YWxBdFN0YXJ0ID8/IDAsXHJcbiAgICB9LFxyXG4gICAgbWVkaWFDcmF3bFF1ZXVlOiB7XHJcbiAgICAgIHRvdGFsOiBtZWRpYUNyYXdsUXVldWVkLFxyXG4gICAgICBydW5uaW5nOiBtZWRpYUNyYXdsSW50ZXJ2YWxIYW5kbGUgIT09IG51bGwsXHJcbiAgICAgIHByb2Nlc3NlZDogbWVkaWFDcmF3bFNlc3M/LnByb2Nlc3NlZCA/PyAwLFxyXG4gICAgICB0b3RhbF9hdF9zdGFydDogbWVkaWFDcmF3bFNlc3M/LnRvdGFsQXRTdGFydCA/PyAwLFxyXG4gICAgfSxcclxuICAgIHRocmVhZE9wZW5RdWV1ZToge1xyXG4gICAgICB0b3RhbDogdGhyZWFkT3BlblF1ZXVlZCxcclxuICAgICAgcnVubmluZzogdGhyZWFkT3BlbkludGVydmFsSGFuZGxlICE9PSBudWxsLFxyXG4gICAgICBwcm9jZXNzZWQ6IHRocmVhZE9wZW5TZXNzPy5wcm9jZXNzZWQgPz8gMCxcclxuICAgICAgdG90YWxfYXRfc3RhcnQ6IHRocmVhZE9wZW5TZXNzPy50b3RhbEF0U3RhcnQgPz8gMCxcclxuICAgIH0sXHJcbiAgICByZWNlbnRUd2VldFNpZ2h0aW5ncyxcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiByZWRhY3RTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IEV4dGVuc2lvblN0YXRlWydzZXR0aW5ncyddIHtcclxuICByZXR1cm4ge1xyXG4gICAgb3duZXI6IHMub3duZXIsXHJcbiAgICByZXBvOiBzLnJlcG8sXHJcbiAgICBicmFuY2g6IHMuYnJhbmNoLFxyXG4gICAgZW5hYmxlZDogcy5lbmFibGVkLFxyXG4gICAgYXV0b0NhcHR1cmU6IHMuYXV0b0NhcHR1cmUsXHJcbiAgICBjb25maWd1cmVkQXQ6IHMuY29uZmlndXJlZEF0LFxuICAgIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogcy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWMsXG4gICAgdXBkYXRlRXhpc3Rpbmc6IHMudXBkYXRlRXhpc3RpbmcsXG4gICAgbG93QmFuZHdpZHRoQnJvd3Npbmc6IHMubG93QmFuZHdpZHRoQnJvd3NpbmcsXG4gICAgcGF0U2V0OiBzLnBhdC5sZW5ndGggPiAwLFxuICAgIHBhdFN1ZmZpeDogcy5wYXQubGVuZ3RoID49IDQgPyBzLnBhdC5zbGljZSgtNCkgOiAnJyxcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBwYXJzZUFyY2hpdmVTbmFwc2hvdChyYXc6IHVua25vd24pOiBBcmNoaXZlU25hcHNob3Qge1xyXG4gIGlmICghcmF3IHx8IHR5cGVvZiByYXcgIT09ICdvYmplY3QnKSB0aHJvdyBuZXcgRXJyb3IoJ21hbmlmZXN0IGlzIG5vdCBhbiBvYmplY3QnKTtcclxuICBjb25zdCBtYW5pZmVzdCA9IHJhdyBhcyB7IGdlbmVyYXRlZF9hdD86IHVua25vd247IGFjY291bnRzPzogdW5rbm93biB9O1xyXG4gIGlmICghQXJyYXkuaXNBcnJheShtYW5pZmVzdC5hY2NvdW50cykpIHRocm93IG5ldyBFcnJvcignbWFuaWZlc3QuYWNjb3VudHMgaXMgbm90IGFuIGFycmF5Jyk7XHJcbiAgY29uc3QgYWNjb3VudHM6IEFyY2hpdmVTbmFwc2hvdFsnYWNjb3VudHMnXSA9IHt9O1xyXG4gIGZvciAoY29uc3QgZW50cnkgb2YgbWFuaWZlc3QuYWNjb3VudHMpIHtcclxuICAgIGlmICghZW50cnkgfHwgdHlwZW9mIGVudHJ5ICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBjb25zdCByb3cgPSBlbnRyeSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgIGNvbnN0IGhhbmRsZSA9IHR5cGVvZiByb3cuaGFuZGxlID09PSAnc3RyaW5nJyA/IHJvdy5oYW5kbGUgOiAnJztcclxuICAgIGlmICghaGFuZGxlIHx8IGhhbmRsZSA9PT0gJ19taXNjJykgY29udGludWU7XHJcbiAgICBhY2NvdW50c1toYW5kbGUudG9Mb3dlckNhc2UoKV0gPSB7XHJcbiAgICAgIGhhbmRsZSxcclxuICAgICAgbGF0ZXN0X3Bvc3RfYXQ6IHR5cGVvZiByb3cubGF0ZXN0X3Bvc3RfYXQgPT09ICdzdHJpbmcnID8gcm93LmxhdGVzdF9wb3N0X2F0IDogbnVsbCxcclxuICAgICAgbGF0ZXN0X2NhcHR1cmVfYXQ6IHR5cGVvZiByb3cubGF0ZXN0X2NhcHR1cmVfYXQgPT09ICdzdHJpbmcnID8gcm93LmxhdGVzdF9jYXB0dXJlX2F0IDogbnVsbCxcclxuICAgICAgcm93X2NvdW50OiB0eXBlb2Ygcm93LnJvd19jb3VudCA9PT0gJ251bWJlcicgPyByb3cucm93X2NvdW50IDogbnVsbCxcclxuICAgIH07XHJcbiAgfVxyXG4gIHJldHVybiB7XHJcbiAgICBnZW5lcmF0ZWRfYXQ6IHR5cGVvZiBtYW5pZmVzdC5nZW5lcmF0ZWRfYXQgPT09ICdzdHJpbmcnID8gbWFuaWZlc3QuZ2VuZXJhdGVkX2F0IDogbnVsbCxcclxuICAgIGZldGNoZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgIGFjY291bnRzLFxyXG4gIH07XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFyY2hpdmVTbmFwc2hvdEhhc1R3ZWV0KHQ6IENhbm9uaWNhbFR3ZWV0LCBzbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbCk6IGJvb2xlYW4ge1xyXG4gIGlmICghc25hcHNob3QpIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBlbnRyeSA9IHNuYXBzaG90LmFjY291bnRzW3QuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKV07XHJcbiAgaWYgKCFlbnRyeT8ubGF0ZXN0X3Bvc3RfYXQpIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBwb3N0ZWQgPSBEYXRlLnBhcnNlKHQucG9zdGVkX2F0KTtcclxuICBjb25zdCBsYXRlc3QgPSBEYXRlLnBhcnNlKGVudHJ5LmxhdGVzdF9wb3N0X2F0KTtcclxuICByZXR1cm4gTnVtYmVyLmlzRmluaXRlKHBvc3RlZCkgJiYgTnVtYmVyLmlzRmluaXRlKGxhdGVzdCkgJiYgcG9zdGVkIDw9IGxhdGVzdDtcclxufVxyXG5cclxuZnVuY3Rpb24gYnVpbGRUd2VldFNpZ2h0aW5nKFxyXG4gIHQ6IENhbm9uaWNhbFR3ZWV0LFxyXG4gIGVuZHBvaW50OiBzdHJpbmcsXHJcbiAgc2VlbkF0OiBzdHJpbmcsXHJcbiAgZnJlc2huZXNzOiAnbmV3JyB8ICdleGlzdGluZycgPSAnbmV3JyxcclxuICBhY3Rpb246IFR3ZWV0U2lnaHRpbmdbJ2FjdGlvbiddID0gJ2J1ZmZlcmVkJ1xyXG4pOiBUd2VldFNpZ2h0aW5nIHtcclxuICByZXR1cm4ge1xyXG4gICAgdHdlZXRfaWQ6IHQudHdlZXRfaWQsXHJcbiAgICBhY2NvdW50X2hhbmRsZTogdC5hY2NvdW50X2hhbmRsZSxcclxuICAgIHBvc3RlZF9hdDogdC5wb3N0ZWRfYXQsXHJcbiAgICB0ZXh0OiB0LnRleHRfcmVzb2x2ZWQgfHwgdC50ZXh0LFxyXG4gICAgdHdlZXRfdHlwZTogdC50d2VldF90eXBlLFxyXG4gICAgdHdlZXRfdXJsOiB0LnR3ZWV0X3VybCxcclxuICAgIHNlZW5fYXQ6IHNlZW5BdCxcclxuICAgIGVuZHBvaW50LFxyXG4gICAgYXJjaGl2ZV9zdGF0dXM6IGZyZXNobmVzcyA9PT0gJ2V4aXN0aW5nJyA/ICdzYXZlZCcgOiAnbmV3JyxcclxuICAgIGFjdGlvbixcclxuICB9O1xyXG59XHJcblxyXG5mdW5jdGlvbiBpc1dyaXRlQXV0aEVycm9yKG1lc3NhZ2U6IHN0cmluZyB8IG51bGwpOiBib29sZWFuIHtcclxuICByZXR1cm4gKFxyXG4gICAgdHlwZW9mIG1lc3NhZ2UgPT09ICdzdHJpbmcnICYmXHJcbiAgICAvUmVzb3VyY2Ugbm90IGFjY2Vzc2libGUgYnkgcGVyc29uYWwgYWNjZXNzIHRva2VufFxcL2dpdFxcL2Jsb2JzfFxcL2dpdFxcL3JlZnMvaS50ZXN0KG1lc3NhZ2UpXHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gaXNvQ29tcGFjdChpc286IHN0cmluZyk6IHN0cmluZyB7XHJcbiAgLy8gMjAyNS0wNC0xMlQxNDoyMzowMS4wMDBaIFx1MjE5MiAyMDI1LTA0LTEyVDE0MjMwMVpcclxuICBjb25zdCBkID0gbmV3IERhdGUoaXNvKTtcclxuICBpZiAoTnVtYmVyLmlzTmFOKGQuZ2V0VGltZSgpKSkgcmV0dXJuIGlzby5yZXBsYWNlKC9bOi5dL2csICcnKTtcclxuICBjb25zdCBwYWQgPSAobjogbnVtYmVyLCB3ID0gMikgPT4gU3RyaW5nKG4pLnBhZFN0YXJ0KHcsICcwJyk7XHJcbiAgcmV0dXJuIChcclxuICAgIGAke2QuZ2V0VVRDRnVsbFllYXIoKX0tJHtwYWQoZC5nZXRVVENNb250aCgpICsgMSl9LSR7cGFkKGQuZ2V0VVRDRGF0ZSgpKX1gICtcclxuICAgIGBUJHtwYWQoZC5nZXRVVENIb3VycygpKX0ke3BhZChkLmdldFVUQ01pbnV0ZXMoKSl9JHtwYWQoZC5nZXRVVENTZWNvbmRzKCkpfVpgXHJcbiAgKTtcclxufVxyXG5cclxuZnVuY3Rpb24gdmlld2VyVXJsKHM6IFNldHRpbmdzKTogc3RyaW5nIHtcclxuICByZXR1cm4gYGh0dHBzOi8vJHtzLm93bmVyfS5naXRodWIuaW8vJHtzLnJlcG99L2A7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBXYWxrIGBub2RlYCBjb2xsZWN0aW5nIGRvdHRlZCBrZXkgcGF0aHMgdXAgdG8gYG1heERlcHRoYCBkZWVwLiBBcnJheVxyXG4gKiBpbmRpY2VzIGNvbGxhcHNlIHRvIGBbMF1gICh3ZSBvbmx5IGRlc2NlbmQgaW50byB0aGUgZmlyc3QgZWxlbWVudCkuIFVzZWRcclxuICogdG8gc3VyZmFjZSB0aGUgc3RydWN0dXJhbCBza2VsZXRvbiBvZiBhbiB1bmZhbWlsaWFyIEdyYXBoUUwgcmVzcG9uc2VcclxuICogd2l0aG91dCBpbmNsdWRpbmcgYW55IGRhdGEgdmFsdWVzLlxyXG4gKi9cclxuLyoqIENvbGxlY3QgZXZlcnkgZGlzdGluY3QgYF9fdHlwZW5hbWVgIHZhbHVlIGZvdW5kIGFueXdoZXJlIGluIHRoZSB0cmVlLiAqL1xyXG5mdW5jdGlvbiBwcm9iZVR5cGVuYW1lcyhub2RlOiB1bmtub3duKTogc3RyaW5nW10ge1xyXG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcclxuICBjb25zdCB2aXNpdGVkID0gbmV3IFdlYWtTZXQ8b2JqZWN0PigpO1xyXG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbbm9kZV07XHJcbiAgd2hpbGUgKHN0YWNrLmxlbmd0aCA+IDApIHtcclxuICAgIGNvbnN0IG4gPSBzdGFjay5wb3AoKTtcclxuICAgIGlmIChuID09PSBudWxsIHx8IHR5cGVvZiBuICE9PSAnb2JqZWN0JykgY29udGludWU7XHJcbiAgICBpZiAodmlzaXRlZC5oYXMobiBhcyBvYmplY3QpKSBjb250aW51ZTtcclxuICAgIHZpc2l0ZWQuYWRkKG4gYXMgb2JqZWN0KTtcclxuICAgIGlmIChBcnJheS5pc0FycmF5KG4pKSB7XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBuKSBzdGFjay5wdXNoKHYpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc3Qgb2JqID0gbiBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuICAgICAgaWYgKHR5cGVvZiBvYmouX190eXBlbmFtZSA9PT0gJ3N0cmluZycpIHNlZW4uYWRkKG9iai5fX3R5cGVuYW1lKTtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIFsuLi5zZWVuXS5zb3J0KCk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBGaW5kIHRoZSBmaXJzdCBub2RlIGFueXdoZXJlIGluIHRoZSB0cmVlIHdob3NlIGBfX3R5cGVuYW1lYCBtYXRjaGVzIGFuZFxyXG4gKiByZXR1cm4gaXRzIHRvcC1sZXZlbCBrZXkgbGlzdCAoc29ydGVkKS4gVXNlZnVsIGZvciBkaXNjb3ZlcmluZyB3aGF0IGZpZWxkc1xyXG4gKiBYIGlzIGFjdHVhbGx5IHNoaXBwaW5nIGZvciBhIGdpdmVuIG5vZGUgdHlwZSBhZnRlciBhIHNjaGVtYSBjaGFuZ2UuXHJcbiAqL1xyXG5mdW5jdGlvbiBwcm9iZUZpcnN0VHlwZVNoYXBlKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcpOiBzdHJpbmdbXSB8IG51bGwge1xyXG4gIGNvbnN0IHZpc2l0ZWQgPSBuZXcgV2Vha1NldDxvYmplY3Q+KCk7XHJcbiAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtub2RlXTtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xyXG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcclxuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xyXG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gICAgICBpZiAob2JqLl9fdHlwZW5hbWUgPT09IHR5cGVuYW1lKSB7XHJcbiAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKG9iaikuc29ydCgpO1xyXG4gICAgICB9XHJcbiAgICAgIGZvciAoY29uc3QgdiBvZiBPYmplY3QudmFsdWVzKG9iaikpIHN0YWNrLnB1c2godik7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBudWxsO1xyXG59XHJcblxyXG4vKipcclxuICogRmluZCB0aGUgZmlyc3Qgbm9kZSB3aXRoIGBfX3R5cGVuYW1lID09PSB0eXBlbmFtZWAsIHRoZW4gZGVzY2VuZCB0aHJvdWdoXHJcbiAqIHRoZSBnaXZlbiBrZXkgcGF0aCwgYW5kIHJldHVybiB0aGUgdG9wLWxldmVsIGtleXMgb2Ygd2hhdGV2ZXIgaXMgYXQgdGhlXHJcbiAqIGVuZC4gUmV0dXJucyBhIG1hcmtlciBzdHJpbmcgd2hlbiB0aGUgcGF0aCBsZWFkcyBzb21ld2hlcmUgbm9uLW9iamVjdCBzb1xyXG4gKiB3ZSBjYW4gdGVsbCBhcGFydCBcImFic2VudFwiIGZyb20gXCJwcmVzZW50IGJ1dCBub3QgYW4gb2JqZWN0XCIuXHJcbiAqL1xyXG5mdW5jdGlvbiBwcm9iZVR5cGVkTmVzdGVkKG5vZGU6IHVua25vd24sIHR5cGVuYW1lOiBzdHJpbmcsIHBhdGg6IHN0cmluZ1tdKTogdW5rbm93biB7XHJcbiAgY29uc3QgdmlzaXRlZCA9IG5ldyBXZWFrU2V0PG9iamVjdD4oKTtcclxuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW25vZGVdO1xyXG4gIGxldCBmb3VuZDogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsID0gbnVsbDtcclxuICB3aGlsZSAoc3RhY2subGVuZ3RoID4gMCkge1xyXG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xyXG4gICAgaWYgKG4gPT09IG51bGwgfHwgdHlwZW9mIG4gIT09ICdvYmplY3QnKSBjb250aW51ZTtcclxuICAgIGlmICh2aXNpdGVkLmhhcyhuIGFzIG9iamVjdCkpIGNvbnRpbnVlO1xyXG4gICAgdmlzaXRlZC5hZGQobiBhcyBvYmplY3QpO1xyXG4gICAgaWYgKEFycmF5LmlzQXJyYXkobikpIHtcclxuICAgICAgZm9yIChjb25zdCB2IG9mIG4pIHN0YWNrLnB1c2godik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCBvYmogPSBuIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xyXG4gICAgICBpZiAob2JqLl9fdHlwZW5hbWUgPT09IHR5cGVuYW1lKSB7XHJcbiAgICAgICAgZm91bmQgPSBvYmo7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgICAgZm9yIChjb25zdCB2IG9mIE9iamVjdC52YWx1ZXMob2JqKSkgc3RhY2sucHVzaCh2KTtcclxuICAgIH1cclxuICB9XHJcbiAgaWYgKCFmb3VuZCkgcmV0dXJuIG51bGw7XHJcbiAgbGV0IGN1cjogdW5rbm93biA9IGZvdW5kO1xyXG4gIGZvciAoY29uc3Qgc2VnIG9mIHBhdGgpIHtcclxuICAgIGlmIChjdXIgPT09IG51bGwgfHwgdHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIHJldHVybiBgPCR7Y3VyID09PSBudWxsID8gJ251bGwnIDogdHlwZW9mIGN1cn0+YDtcclxuICAgIGN1ciA9IChjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pW3NlZ107XHJcbiAgfVxyXG4gIGlmIChjdXIgPT09IHVuZGVmaW5lZCkgcmV0dXJuICc8bWlzc2luZz4nO1xyXG4gIGlmIChjdXIgPT09IG51bGwpIHJldHVybiAnPG51bGw+JztcclxuICBpZiAodHlwZW9mIGN1ciAhPT0gJ29iamVjdCcpIHJldHVybiBgPCR7dHlwZW9mIGN1cn0+YDtcclxuICBpZiAoQXJyYXkuaXNBcnJheShjdXIpKSByZXR1cm4gYDxhcnJheSBsZW49JHtjdXIubGVuZ3RofT5gO1xyXG4gIHJldHVybiBPYmplY3Qua2V5cyhjdXIgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLnNvcnQoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc2hvcnRlblVybCh1OiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIC8vIEFjdGl2aXR5LXRhaWwgY29udGV4dCBpcyBtb3JlIHVzZWZ1bCB3aXRoIGp1c3QgdGhlIHBhdGg7IGZ1bGwgVVJMcyBiZWNvbWVcclxuICAvLyBoYXJkIHRvIHJlYWQgYXQgdGhlIHNpZGViYXIncyB3aWR0aC5cclxuICB0cnkge1xyXG4gICAgY29uc3QgcGFyc2VkID0gbmV3IFVSTCh1KTtcclxuICAgIGNvbnN0IHBhdGggPSBwYXJzZWQucGF0aG5hbWUgKyAocGFyc2VkLnNlYXJjaCA/ICc/XHUyMDI2JyA6ICcnKTtcclxuICAgIHJldHVybiBwYXJzZWQuaG9zdCA9PT0gJ3guY29tJyB8fCBwYXJzZWQuaG9zdCA9PT0gJ3R3aXR0ZXIuY29tJ1xyXG4gICAgICA/IHBhdGhcclxuICAgICAgOiBgJHtwYXJzZWQuaG9zdH0ke3BhdGh9YDtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiB1Lmxlbmd0aCA+IDgwID8gYCR7dS5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHU7XHJcbiAgfVxyXG59XHJcblxyXG4vLyAtLS0gRGV2IGhlbHBlcnMgZXhwb3NlZCBvbiBnbG9iYWxUaGlzIGZvciB0aGUgZGV2dG9vbHMgY29uc29sZSAtLS0tLS0tLS0tXHJcbi8vIChlLmcuIGBfX2ltbUFyY2hpdmUuY2xlYXJBbGwoKWAgaW4gdGhlIGJhY2tncm91bmQgd29ya2VyJ3MgZGV2dG9vbHMpLlxyXG5cclxuKGdsb2JhbFRoaXMgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj4pLl9faW1tQXJjaGl2ZSA9IHtcclxuICBjbGVhckFsbCxcclxuICBhY3Rpdml0eTogZ2V0QWN0aXZpdHksXHJcbiAgYWNjb3VudHM6IGdldEFjY291bnRzLFxyXG4gIGJ1ZmZlcnM6IGdldFJ1bkJ1ZmZlcnMsXHJcbiAgZmx1c2hBbGw6ICgpID0+IGZsdXNoQWxsKCdkZXZ0b29scycpLFxyXG4gIHN0YXRlOiBidWlsZFN0YXRlLFxyXG4gIHJlZmV0Y2hRdWV1ZTogZ2V0UmVmZXRjaFF1ZXVlLFxyXG4gIHN0YXJ0UmVmZXRjaDogc3RhcnRSZWZldGNoTG9vcCxcclxuICBjYW5jZWxSZWZldGNoOiBjYW5jZWxSZWZldGNoTG9vcCxcclxuICBtZWRpYUNyYXdsUXVldWU6IGdldE1lZGlhQ3Jhd2xRdWV1ZSxcclxuICBzdGFydE1lZGlhQ3Jhd2w6IHN0YXJ0TWVkaWFDcmF3bExvb3AsXHJcbiAgY2FuY2VsTWVkaWFDcmF3bDogY2FuY2VsTWVkaWFDcmF3bExvb3AsXHJcbiAgdGhyZWFkT3BlblF1ZXVlOiBnZXRUaHJlYWRPcGVuUXVldWUsXHJcbiAgc3RhcnRUaHJlYWRPcGVuOiBzdGFydFRocmVhZE9wZW5Mb29wLFxyXG4gIGNhbmNlbFRocmVhZE9wZW46IGNhbmNlbFRocmVhZE9wZW5Mb29wLFxyXG59O1xyXG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFBQSxFQUNQLE1BQU07QUFBQTtBQUFBO0FBQUEsRUFHTixRQUFRO0FBQUEsRUFDUixTQUFTO0FBQUEsRUFDVCxhQUFhO0FBQUEsRUFDYixjQUFjO0FBQUEsRUFDZCx1QkFBdUI7QUFBQSxFQUN2QixnQkFBZ0I7QUFBQSxFQUNoQixzQkFBc0I7QUFDeEI7QUFFTyxJQUFNLHNCQUFzQjtBQUM1QixJQUFNLHNCQUFzQjtBQUk1QixJQUFNLG9CQUFxQztBQUFBLEVBQ2hELEVBQUUsUUFBUSxVQUFVLE9BQU8sbUNBQW1DLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxVQUFVLE9BQU8sNENBQTRDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxPQUFPLE9BQU8sc0NBQXNDLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxTQUFTLE9BQU8sNkNBQTZDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxjQUFjLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUFBLEVBQ25FLEVBQUUsUUFBUSxZQUFZLE9BQU8sK0JBQStCLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sa0NBQWtDLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sNEJBQTRCLFVBQVUsT0FBTztBQUFBLEVBQ3ZFLEVBQUUsUUFBUSxtQkFBbUIsT0FBTyxxQkFBcUIsVUFBVSxPQUFPO0FBQUEsRUFDMUUsRUFBRSxRQUFRLFlBQVksT0FBTyxrQkFBa0IsVUFBVSxPQUFPO0FBQUEsRUFDaEUsRUFBRSxRQUFRLGtCQUFrQixPQUFPLGtCQUFrQixVQUFVLE9BQU87QUFBQSxFQUN0RSxFQUFFLFFBQVEsZ0JBQWdCLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUN2RTtBQUdPLElBQU0sa0JBQXVDLG9CQUFJLElBQUk7QUFBQSxFQUMxRDtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQVdNLElBQU0sb0JBQXlDLG9CQUFJLElBQUksQ0FBQyxvQkFBb0IsY0FBYyxDQUFDO0FBdUIzRixJQUFNLHdCQUF3QjtBQUc5QixJQUFNLGdCQUFnQjtBQUd0QixJQUFNLHNCQUFzQjtBQUc1QixJQUFNLG9CQUFvQjtBQUcxQixJQUFNLGdDQUFnQyxLQUFLLEtBQUs7QUFFaEQsSUFBTSxtQkFBbUI7OztBQzNFaEMsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0I7QUFFeEIsSUFBSSxrQkFBb0M7QUFDeEMsSUFBSSxzQkFBcUM7QUFFekMsU0FBUyxTQUFTLEtBQXlCO0FBQ3pDLE1BQUksSUFBSTtBQUNSLGFBQVcsS0FBSyxJQUFLLE1BQUssT0FBTyxhQUFhLENBQUM7QUFDL0MsU0FBTyxLQUFLLENBQUM7QUFDZjtBQUVBLFNBQVMsV0FBVyxHQUF1QjtBQUN6QyxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFFBQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxNQUFNO0FBQ3JDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUssS0FBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFDOUQsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUU7QUFDaEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDL0QsUUFBTSxJQUFJLE9BQU8sZ0JBQWdCO0FBQ2pDLE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsV0FBTyxFQUFFLFNBQVMsR0FBRyxNQUFNLFdBQVcsQ0FBQyxFQUFFO0FBQUEsRUFDM0M7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxRQUFNLFVBQVUsU0FBUyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0FBQy9ELFNBQU8sRUFBRSxTQUFTLEtBQUs7QUFDekI7QUFFQSxlQUFlLFlBQWdDO0FBQzdDLFFBQU0sRUFBRSxTQUFTLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUNqRCxNQUFJLG9CQUFvQixRQUFRLHdCQUF3QixTQUFTO0FBQy9ELFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFO0FBQUEsSUFDN0IsR0FBRyxRQUFRLFFBQVEsRUFBRSxJQUFJLFFBQVEsUUFBUSxZQUFZLEVBQUUsT0FBTztBQUFBLEVBQ2hFO0FBQ0EsUUFBTSxXQUFXLElBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNO0FBQ3pELFdBQVMsSUFBSSxNQUFNLENBQUM7QUFDcEIsV0FBUyxJQUFJLE1BQU0sS0FBSyxNQUFNO0FBQzlCLFFBQU0sT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUTtBQUMzRCxRQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLE1BQU0sRUFBRSxNQUFNLFVBQVUsR0FBRyxPQUFPO0FBQUEsSUFDakY7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBQ0Qsb0JBQWtCO0FBQ2xCLHdCQUFzQjtBQUN0QixTQUFPO0FBQ1Q7QUFFTyxTQUFTLGVBQWUsR0FBb0I7QUFDakQsU0FBTyxFQUFFLFdBQVcsZUFBZTtBQUNyQztBQUVBLGVBQXNCLFdBQVcsV0FBb0M7QUFDbkUsTUFBSSxDQUFDLFVBQVcsUUFBTztBQUN2QixRQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFFBQU0sS0FBSyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3BELFFBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLElBQzdCLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxJQUN0QjtBQUFBLElBQ0EsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTO0FBQUEsRUFDcEM7QUFDQSxTQUFPLEdBQUcsZUFBZSxHQUFHLFNBQVMsRUFBRSxDQUFDLElBQUksU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMUU7QUFFQSxlQUFzQixXQUFXLFVBQW1DO0FBQ2xFLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFHdEIsTUFBSSxDQUFDLFNBQVMsV0FBVyxlQUFlLEVBQUcsUUFBTztBQUNsRCxRQUFNLFFBQVEsU0FBUyxNQUFNLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxHQUFHO0FBQzlELE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUMvQixRQUFNLENBQUMsT0FBTyxLQUFLLElBQUk7QUFDdkIsTUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFPLFFBQU87QUFDN0IsTUFBSTtBQUNGLFVBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQzdCLEVBQUUsTUFBTSxXQUFXLEdBQXVCO0FBQUEsTUFDMUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDcEMsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7OztBQ1hBLElBQU0scUJBQXNDO0FBQUEsRUFDMUMsUUFBUTtBQUFBLEVBQ1IsT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUFBLEVBQ1AsZUFBZTtBQUFBLEVBQ2Ysd0JBQXdCO0FBQUEsRUFDeEIsa0JBQWtCO0FBQ3BCO0FBRUEsSUFBTSxXQUF5QjtBQUFBLEVBQzdCLFVBQVUsRUFBRSxHQUFHLGlCQUFpQjtBQUFBLEVBQ2hDLFVBQVUsQ0FBQyxHQUFHLGlCQUFpQjtBQUFBLEVBQy9CLHFCQUFxQjtBQUFBLEVBQ3JCLGlCQUFpQjtBQUFBLEVBQ2pCLFlBQVksRUFBRSxHQUFHLG1CQUFtQjtBQUFBLEVBQ3BDLFVBQVUsQ0FBQztBQUFBLEVBQ1gsWUFBWSxDQUFDO0FBQUEsRUFDYixVQUFVLENBQUM7QUFBQSxFQUNYLHNCQUFzQixDQUFDO0FBQUEsRUFDdkIsZ0JBQWdCLENBQUM7QUFBQSxFQUNqQixjQUFjLENBQUM7QUFBQSxFQUNmLGlCQUFpQixDQUFDO0FBQUEsRUFDbEIsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGdCQUFnQjtBQUFBLEVBQ2hCLG1CQUFtQjtBQUFBLEVBQ25CLG1CQUFtQjtBQUFBLEVBQ25CLG1CQUFtQjtBQUNyQjtBQUVBLGVBQWUsT0FBcUMsS0FBa0M7QUFDcEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxHQUFHO0FBQ2xELFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsTUFBSSxVQUFVLFFBQVc7QUFDdkIsV0FBTyxnQkFBZ0IsU0FBUyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUNBLFNBQU87QUFDVDtBQUVBLGVBQWUsT0FBcUMsS0FBUSxPQUF1QztBQUNqRyxRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUM7QUFDbEQ7QUFJQSxlQUFzQixjQUFpQztBQUtyRCxRQUFNLFNBQVMsTUFBTSxPQUFPLFVBQVU7QUFDdEMsUUFBTSxTQUFTLEVBQUUsR0FBRyxrQkFBa0IsR0FBRyxPQUFPO0FBQ2hELE1BQUksT0FBTyxPQUFPLGVBQWUsT0FBTyxHQUFHLEdBQUc7QUFDNUMsUUFBSTtBQUNGLGFBQU8sTUFBTSxNQUFNLFdBQVcsT0FBTyxHQUFHO0FBQUEsSUFDMUMsUUFBUTtBQUNOLGFBQU8sTUFBTTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsWUFBWSxHQUE0QjtBQUc1RCxRQUFNLFVBQW9CLEVBQUUsR0FBRyxFQUFFO0FBQ2pDLE1BQUksUUFBUSxPQUFPLENBQUMsZUFBZSxRQUFRLEdBQUcsR0FBRztBQUMvQyxZQUFRLE1BQU0sTUFBTSxXQUFXLFFBQVEsR0FBRztBQUFBLEVBQzVDO0FBQ0EsUUFBTSxPQUFPLFlBQVksT0FBTztBQUNsQztBQUNBLGVBQXNCLGVBQWUsT0FBNkM7QUFDaEYsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE9BQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hDLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFNBQU87QUFDVDtBQUlBLGVBQXNCLGNBQXdDO0FBQzVELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFBWSxHQUFtQztBQUNuRSxRQUFNLE9BQU8sWUFBWSxDQUFDO0FBQzVCO0FBQ0EsZUFBc0IseUJBQWlEO0FBQ3JFLFNBQU8sT0FBTyxxQkFBcUI7QUFDckM7QUFDQSxlQUFzQix1QkFBdUIsS0FBbUM7QUFDOUUsUUFBTSxPQUFPLHVCQUF1QixHQUFHO0FBQ3pDO0FBSUEsZUFBc0IscUJBQXNEO0FBQzFFLFNBQU8sT0FBTyxpQkFBaUI7QUFDakM7QUFFQSxlQUFzQixtQkFBbUIsVUFBaUQ7QUFDeEYsUUFBTSxPQUFPLG1CQUFtQixRQUFRO0FBQzFDO0FBSUEsZUFBc0IsZ0JBQTBDO0FBQzlELFFBQU0sSUFBSSxNQUFNLE9BQU8sWUFBWTtBQUVuQyxRQUFNLE1BQXVCO0FBQUEsSUFDM0IsR0FBRztBQUFBLElBQ0gsZUFBZSxFQUFFLGtCQUFrQixTQUFZLE9BQU8sRUFBRTtBQUFBLElBQ3hELHdCQUNFLEVBQUUsMkJBQTJCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDcEQsa0JBQWtCLEVBQUUscUJBQXFCLFNBQVksT0FBTyxFQUFFO0FBQUEsRUFDaEU7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxlQUFzQixjQUFjLEdBQW1DO0FBQ3JFLFFBQU0sT0FBTyxjQUFjLENBQUM7QUFDOUI7QUFJQSxTQUFTLFdBQW1CO0FBQzFCLFVBQU8sb0JBQUksS0FBSyxHQUFFLFlBQVksRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUM3QztBQUVBLGVBQXNCLGNBQXVEO0FBQzNFLFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBQ0EsZUFBc0IsWUFDcEIsUUFDQSxPQUN5QjtBQUN6QixRQUFNLE1BQU0sTUFBTSxZQUFZO0FBQzlCLFFBQU0sTUFBTSxJQUFJLE1BQU0sS0FBSztBQUFBLElBQ3pCLFlBQVk7QUFBQSxJQUNaLFdBQVcsU0FBUztBQUFBLElBQ3BCLGVBQWU7QUFBQSxJQUNmLGdCQUFnQjtBQUFBLElBQ2hCLGVBQWU7QUFBQSxFQUNqQjtBQUNBLE1BQUksSUFBSSxjQUFjLFNBQVMsR0FBRztBQUNoQyxRQUFJLFlBQVksU0FBUztBQUN6QixRQUFJLGFBQWE7QUFBQSxFQUNuQjtBQUNBLFFBQU0sT0FBdUIsRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hELE1BQUksTUFBTSxJQUFJO0FBQ2QsUUFBTSxPQUFPLFlBQVksR0FBRztBQUM1QixTQUFPO0FBQ1Q7QUFFQSxlQUFzQixpQkFBaUIsUUFBZ0IsT0FBOEI7QUFDbkYsUUFBTSxZQUFZLFFBQVEsRUFBRSxlQUFlLE1BQU0sQ0FBQztBQUNwRDtBQUlBLGVBQXNCLGdCQUFvRDtBQUN4RSxTQUFPLE9BQU8sWUFBWTtBQUM1QjtBQUVBLGVBQXNCLGFBQWEsUUFBMkM7QUFDNUUsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxTQUFPLElBQUksTUFBTSxLQUFLO0FBQ3hCO0FBRUEsZUFBc0IsYUFBYSxRQUFnQixLQUErQjtBQUNoRixRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLE1BQUksTUFBTSxJQUFJO0FBQ2QsUUFBTSxPQUFPLGNBQWMsR0FBRztBQUNoQztBQUVBLGVBQXNCLGVBQWUsUUFBK0I7QUFDbEUsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxTQUFPLElBQUksTUFBTTtBQUNqQixRQUFNLE9BQU8sY0FBYyxHQUFHO0FBQ2hDO0FBSUEsZUFBc0IsY0FBbUM7QUFDdkQsU0FBTyxPQUFPLFVBQVU7QUFDMUI7QUFFQSxlQUFzQixlQUFlLElBQW1DO0FBQ3RFLFFBQU0sTUFBTSxNQUFNLFlBQVk7QUFDOUIsTUFBSSxRQUFRLEVBQUU7QUFDZCxNQUFJLElBQUksU0FBUyxrQkFBbUIsS0FBSSxTQUFTO0FBQ2pELFFBQU0sT0FBTyxZQUFZLEdBQUc7QUFDNUIsU0FBTztBQUNUO0FBRUEsZUFBc0IsZ0JBQStCO0FBQ25ELFFBQU0sT0FBTyxZQUFZLENBQUMsQ0FBQztBQUM3QjtBQUlBLElBQU0sNkJBQTZCO0FBRW5DLGVBQXNCLDBCQUFvRDtBQUN4RSxTQUFPLE9BQU8sc0JBQXNCO0FBQ3RDO0FBRUEsZUFBc0IsNEJBQTRCLE1BQXNDO0FBQ3RGLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsUUFBTSxNQUFNLE1BQU0sd0JBQXdCO0FBQzFDLFFBQU0sT0FBTyxvQkFBSSxJQUFZO0FBQzdCLFFBQU0sT0FBd0IsQ0FBQztBQUMvQixhQUFXLE9BQU8sTUFBTTtBQUN0QixVQUFNLE1BQU0sR0FBRyxJQUFJLGVBQWUsWUFBWSxDQUFDLElBQUksSUFBSSxRQUFRO0FBQy9ELFFBQUksS0FBSyxJQUFJLEdBQUcsRUFBRztBQUNuQixTQUFLLElBQUksR0FBRztBQUNaLFNBQUssS0FBSyxHQUFHO0FBQUEsRUFDZjtBQUNBLGFBQVcsT0FBTyxLQUFLO0FBQ3JCLFVBQU0sTUFBTSxHQUFHLElBQUksZUFBZSxZQUFZLENBQUMsSUFBSSxJQUFJLFFBQVE7QUFDL0QsUUFBSSxLQUFLLElBQUksR0FBRyxFQUFHO0FBQ25CLFNBQUssSUFBSSxHQUFHO0FBQ1osU0FBSyxLQUFLLEdBQUc7QUFBQSxFQUNmO0FBQ0EsT0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFFBQVEsMEJBQTBCO0FBQzlELFFBQU0sT0FBTyx3QkFBd0IsSUFBSTtBQUMzQztBQUlBLGVBQXNCLG9CQUE2RTtBQUNqRyxTQUFPLE9BQU8sZ0JBQWdCO0FBQ2hDO0FBRUEsZUFBc0Isa0JBQ3BCLEtBQ2U7QUFDZixRQUFNLE9BQU8sa0JBQWtCLEdBQUc7QUFDcEM7QUFVTyxTQUFTLGNBQ2QsT0FDQSxVQUNBLFNBQ0EsUUFDQSxjQUF1QixPQUNmO0FBQ1IsU0FBTyxHQUFHLEtBQUssSUFBSSxRQUFRLElBQUksT0FBTyxJQUFJLE1BQU0sSUFBSSxjQUFjLE1BQU0sR0FBRztBQUM3RTtBQUdBLGVBQXNCLG9CQUFvQixVQUFtQztBQUMzRSxRQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsUUFBTSxTQUFTLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxRQUFRLEVBQUUsWUFBWTtBQUMzRCxNQUFJLFNBQVM7QUFDYixhQUFXLFVBQVUsT0FBTyxLQUFLLEdBQUcsR0FBRztBQUNyQyxVQUFNLFFBQVEsSUFBSSxNQUFNO0FBQ3hCLFFBQUksQ0FBQyxNQUFPO0FBQ1osZUFBVyxPQUFPLE9BQU8sS0FBSyxLQUFLLEdBQUc7QUFDcEMsWUFBTSxJQUFJLE1BQU0sR0FBRztBQUNuQixVQUFJLEtBQUssRUFBRSxLQUFLLFFBQVE7QUFDdEIsZUFBTyxNQUFNLEdBQUc7QUFDaEIsa0JBQVU7QUFBQSxNQUNaO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxLQUFLLEtBQUssRUFBRSxXQUFXLEVBQUcsUUFBTyxJQUFJLE1BQU07QUFBQSxFQUN4RDtBQUNBLE1BQUksU0FBUyxFQUFHLE9BQU0sa0JBQWtCLEdBQUc7QUFDM0MsU0FBTztBQUNUO0FBSUEsZUFBc0Isa0JBQXFEO0FBQ3pFLFNBQU8sT0FBTyxjQUFjO0FBQzlCO0FBRUEsZUFBc0Isb0JBQXFDO0FBQ3pELFFBQU0sSUFBSSxNQUFNLGdCQUFnQjtBQUNoQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0IsZUFBZSxRQUFnQixTQUFnQztBQUNuRixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsUUFBTSxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDMUIsTUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUc7QUFDMUIsUUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBRSxNQUFNLElBQUk7QUFDWixVQUFNLE9BQU8sZ0JBQWdCLENBQUM7QUFBQSxFQUNoQztBQUNGO0FBRUEsZUFBc0IsZUFBZSxRQUFnQixTQUFnQztBQUNuRixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsUUFBTSxNQUFNLEVBQUUsTUFBTTtBQUNwQixNQUFJLENBQUMsSUFBSztBQUNWLFFBQU0sV0FBVyxJQUFJLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTztBQUNsRCxNQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNO0FBQUEsTUFDckMsR0FBRSxNQUFNLElBQUk7QUFDakIsUUFBTSxPQUFPLGdCQUFnQixDQUFDO0FBQ2hDO0FBRUEsZUFBc0Isb0JBR1o7QUFDUixRQUFNLElBQUksTUFBTSxnQkFBZ0I7QUFDaEMsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFHO0FBQUEsRUFDeEQ7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixxQkFBd0Q7QUFDNUUsU0FBTyxPQUFPLGlCQUFpQjtBQUNqQztBQUVBLGVBQXNCLHVCQUF3QztBQUM1RCxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxRQUFRO0FBQ1osYUFBVyxPQUFPLE9BQU8sT0FBTyxDQUFDLEVBQUcsVUFBUyxJQUFJO0FBQ2pELFNBQU87QUFDVDtBQUVBLGVBQXNCLGtCQUFrQixZQUEyQixTQUFnQztBQUNqRyxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsUUFBTSxTQUFTLGNBQWM7QUFDN0IsUUFBTSxNQUFNLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFDMUIsTUFBSSxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUc7QUFDMUIsUUFBSSxLQUFLLE9BQU87QUFDaEIsTUFBRSxNQUFNLElBQUk7QUFDWixVQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFBQSxFQUNuQztBQUNGO0FBRUEsZUFBc0Isa0JBQWtCLFNBQWdDO0FBQ3RFLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFVBQVU7QUFDZCxhQUFXLFVBQVUsT0FBTyxLQUFLLENBQUMsR0FBRztBQUNuQyxVQUFNLE1BQU0sRUFBRSxNQUFNO0FBQ3BCLFFBQUksQ0FBQyxJQUFLO0FBQ1YsVUFBTSxXQUFXLElBQUksT0FBTyxDQUFDLE9BQU8sT0FBTyxPQUFPO0FBQ2xELFFBQUksU0FBUyxXQUFXLElBQUksUUFBUTtBQUNsQyxnQkFBVTtBQUNWLFVBQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxFQUFFLE1BQU07QUFBQSxVQUNyQyxHQUFFLE1BQU0sSUFBSTtBQUFBLElBQ25CO0FBQUEsRUFDRjtBQUNBLE1BQUksUUFBUyxPQUFNLE9BQU8sbUJBQW1CLENBQUM7QUFDaEQ7QUFFQSxlQUFzQix1QkFHWjtBQUNSLFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBRztBQUM3QyxRQUFJLElBQUksU0FBUyxFQUFHLFFBQU8sRUFBRSxRQUFRLFNBQVMsSUFBSSxDQUFDLEVBQUc7QUFBQSxFQUN4RDtBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLHFCQUF3RDtBQUM1RSxTQUFPLE9BQU8saUJBQWlCO0FBQ2pDO0FBRUEsZUFBc0IsdUJBQXdDO0FBQzVELFFBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUNuQyxNQUFJLFFBQVE7QUFDWixhQUFXLE9BQU8sT0FBTyxPQUFPLENBQUMsRUFBRyxVQUFTLElBQUk7QUFDakQsU0FBTztBQUNUO0FBRUEsZUFBc0Isa0JBQWtCLFNBQW1DO0FBQ3pFLFFBQU0sT0FBTyxNQUFNLE9BQU8sZ0JBQWdCO0FBQzFDLFNBQU8sV0FBVztBQUNwQjtBQUVBLGVBQXNCLG1CQUFtQixTQUFnQztBQUN2RSxRQUFNLE9BQU8sTUFBTSxPQUFPLGdCQUFnQjtBQUMxQyxPQUFLLE9BQU8sS0FBSSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUN2QyxRQUFNLE9BQU8sa0JBQWtCLElBQUk7QUFDckM7QUFFQSxlQUFzQixrQkFBa0IsUUFBZ0IsU0FBZ0M7QUFDdEYsTUFBSSxNQUFNLGtCQUFrQixPQUFPLEVBQUc7QUFDdEMsUUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ25DLFFBQU0sTUFBTSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzFCLE1BQUksQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHO0FBQzFCLFFBQUksS0FBSyxPQUFPO0FBQ2hCLE1BQUUsTUFBTSxJQUFJO0FBQ1osVUFBTSxPQUFPLG1CQUFtQixDQUFDO0FBQUEsRUFDbkM7QUFDRjtBQUVBLGVBQXNCLGtCQUFrQixTQUFnQztBQUN0RSxRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsTUFBSSxVQUFVO0FBQ2QsYUFBVyxVQUFVLE9BQU8sS0FBSyxDQUFDLEdBQUc7QUFDbkMsVUFBTSxNQUFNLEVBQUUsTUFBTTtBQUNwQixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sV0FBVyxJQUFJLE9BQU8sQ0FBQyxPQUFPLE9BQU8sT0FBTztBQUNsRCxRQUFJLFNBQVMsV0FBVyxJQUFJLFFBQVE7QUFDbEMsZ0JBQVU7QUFDVixVQUFJLFNBQVMsV0FBVyxFQUFHLFFBQU8sRUFBRSxNQUFNO0FBQUEsVUFDckMsR0FBRSxNQUFNLElBQUk7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFFBQVMsT0FBTSxPQUFPLG1CQUFtQixDQUFDO0FBQ2hEO0FBRUEsZUFBc0IsdUJBR1o7QUFDUixRQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDbkMsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxDQUFDLEdBQUc7QUFDN0MsUUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLEVBQUUsUUFBUSxTQUFTLElBQUksQ0FBQyxFQUFHO0FBQUEsRUFDeEQ7QUFDQSxTQUFPO0FBQ1Q7QUFJQSxlQUFzQixZQUFZLFNBQW1DO0FBQ25FLFFBQU0sTUFBTSxNQUFNLGtCQUFrQjtBQUNwQyxhQUFXLFNBQVMsT0FBTyxPQUFPLEdBQUcsR0FBRztBQUN0QyxRQUFJLFNBQVMsV0FBVyxNQUFPLFFBQU87QUFBQSxFQUN4QztBQUNBLFNBQU87QUFDVDtBQUlBLGVBQXNCLG9CQUFpRDtBQUNyRSxTQUFPLE9BQU8sZ0JBQWdCO0FBQ2hDO0FBQ0EsZUFBc0Isa0JBQWtCLEdBQXNDO0FBQzVFLFFBQU0sT0FBTyxrQkFBa0IsQ0FBQztBQUNsQztBQUNBLGVBQXNCLHVCQUFvRDtBQUN4RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQXNDO0FBQy9FLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQUNBLGVBQXNCLHVCQUFvRDtBQUN4RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQXNDO0FBQy9FLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQUNBLGVBQXNCLHVCQUEwRDtBQUM5RSxTQUFPLE9BQU8sbUJBQW1CO0FBQ25DO0FBQ0EsZUFBc0IscUJBQXFCLEdBQTRDO0FBQ3JGLFFBQU0sT0FBTyxxQkFBcUIsQ0FBQztBQUNyQztBQVlBLGVBQXNCLG9CQUFvQixVQU92QztBQUNELFFBQU0sWUFBWSxJQUFJLElBQUksQ0FBQyxHQUFHLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO0FBQ25FLFFBQU0sYUFBYSxDQUFDLE1BQXVCLFVBQVUsSUFBSSxFQUFFLFlBQVksQ0FBQztBQUd4RSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksa0JBQWtCO0FBQ3RCLGFBQVcsS0FBSyxPQUFPLEtBQUssUUFBUSxHQUFHO0FBQ3JDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLFNBQVMsQ0FBQztBQUNqQix5QkFBbUI7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sWUFBWSxRQUFRO0FBR2pDLFFBQU0sVUFBVSxNQUFNLGNBQWM7QUFDcEMsTUFBSSxpQkFBaUI7QUFDckIsYUFBVyxLQUFLLE9BQU8sS0FBSyxPQUFPLEdBQUc7QUFDcEMsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLGFBQU8sUUFBUSxDQUFDO0FBQ2hCLHdCQUFrQjtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxjQUFjLE9BQU87QUFHbEMsUUFBTSxNQUFNLE1BQU0sa0JBQWtCO0FBQ3BDLE1BQUksMEJBQTBCO0FBQzlCLGFBQVcsS0FBSyxPQUFPLEtBQUssR0FBRyxHQUFHO0FBQ2hDLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLElBQUksQ0FBQztBQUNaLGlDQUEyQjtBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUNBLFFBQU0sa0JBQWtCLEdBQUc7QUFHM0IsUUFBTSxLQUFLLE1BQU0sZ0JBQWdCO0FBQ2pDLE1BQUksd0JBQXdCO0FBQzVCLGFBQVcsS0FBSyxPQUFPLEtBQUssRUFBRSxHQUFHO0FBQy9CLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUNsQixhQUFPLEdBQUcsQ0FBQztBQUNYLCtCQUF5QjtBQUFBLElBQzNCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxnQkFBZ0IsRUFBRTtBQUsvQixRQUFNLEtBQUssTUFBTSxtQkFBbUI7QUFDcEMsTUFBSSx1QkFBdUI7QUFDM0IsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLCtCQUF5QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDdEMsYUFBTyxHQUFHLENBQUM7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxtQkFBbUIsRUFBRTtBQUVsQyxRQUFNLEtBQUssTUFBTSxtQkFBbUI7QUFDcEMsTUFBSSx1QkFBdUI7QUFDM0IsYUFBVyxLQUFLLE9BQU8sS0FBSyxFQUFFLEdBQUc7QUFDL0IsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHO0FBQ2xCLCtCQUF5QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDdEMsYUFBTyxHQUFHLENBQUM7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxtQkFBbUIsRUFBRTtBQUVsQyxTQUFPO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBSUEsZUFBc0IsV0FBMEI7QUFDOUMsUUFBTSxRQUFRLFFBQVEsTUFBTSxNQUFNO0FBQ3BDOzs7QUNqcUJBLElBQUksWUFBNkM7QUFFMUMsU0FBUyxlQUFlLElBQWtDO0FBQy9ELGNBQVk7QUFDZDtBQUVBLFNBQVMsU0FBaUI7QUFDeEIsVUFBTyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUNoQztBQUVBLGVBQWUsS0FBSyxPQUFpQixLQUFhLFNBQWlEO0FBQ2pHLFFBQU0sS0FBZSxFQUFFLElBQUksT0FBTyxHQUFHLE9BQU8sS0FBSyxTQUFTLE9BQU8sT0FBTyxFQUFFO0FBRTFFLFFBQU0sT0FBTyxpQkFBaUIsTUFBTSxZQUFZLENBQUMsSUFBSSxHQUFHO0FBQ3hELE1BQUksVUFBVSxRQUFTLFNBQVEsTUFBTSxNQUFNLEdBQUcsT0FBTztBQUFBLFdBQzVDLFVBQVUsT0FBUSxTQUFRLEtBQUssTUFBTSxHQUFHLE9BQU87QUFBQSxNQUNuRCxTQUFRLElBQUksTUFBTSxHQUFHLE9BQU87QUFFakMsTUFBSTtBQUNGLFVBQU0sZUFBZSxFQUFFO0FBQUEsRUFDekIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDJDQUEyQyxHQUFHO0FBQUEsRUFDN0Q7QUFFQSxNQUFJO0FBQ0YsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCLFFBQVE7QUFBQSxFQUVSO0FBQ0Y7QUFFTyxTQUFTLEtBQUssS0FBYSxVQUFtQyxDQUFDLEdBQWtCO0FBQ3RGLFNBQU8sS0FBSyxRQUFRLEtBQUssT0FBTztBQUNsQztBQUNPLFNBQVMsS0FBSyxLQUFhLFVBQW1DLENBQUMsR0FBa0I7QUFDdEYsU0FBTyxLQUFLLFFBQVEsS0FBSyxPQUFPO0FBQ2xDO0FBQ08sU0FBUyxNQUFNLEtBQWEsVUFBbUMsQ0FBQyxHQUFrQjtBQUN2RixTQUFPLEtBQUssU0FBUyxLQUFLLE9BQU87QUFDbkM7QUFFTyxTQUFTLGNBQWMsS0FBeUQ7QUFDckYsTUFBSSxlQUFlLE9BQU87QUFDeEIsV0FBTyxFQUFFLFNBQVMsSUFBSSxTQUFTLE9BQU8sSUFBSSxTQUFTLEtBQUs7QUFBQSxFQUMxRDtBQUNBLE1BQUk7QUFDRixXQUFPLEVBQUUsU0FBUyxPQUFPLEdBQUcsR0FBRyxPQUFPLEtBQUs7QUFBQSxFQUM3QyxRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsdUJBQXVCLE9BQU8sS0FBSztBQUFBLEVBQ3ZEO0FBQ0Y7QUFPQSxTQUFTLE9BQU8sS0FBdUQ7QUFDckUsUUFBTSxNQUErQixDQUFDO0FBQ3RDLGFBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxPQUFPLFFBQVEsR0FBRyxHQUFHO0FBQ3hDLFFBQUksRUFBRSxZQUFZLEVBQUUsU0FBUyxPQUFPLEtBQUssRUFBRSxZQUFZLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtBQUMzRixVQUFJLENBQUMsSUFBSTtBQUFBLElBQ1gsV0FBVyxPQUFPLE1BQU0sWUFBWSwrQkFBK0IsS0FBSyxDQUFDLEdBQUc7QUFDMUUsVUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLDZCQUE2Qix1QkFBdUI7QUFBQSxJQUN6RSxXQUFXLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxNQUFNO0FBQ25ELFVBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsSUFDOUIsT0FBTztBQUNMLFVBQUksQ0FBQyxJQUFJO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7OztBQ3ZFQSxJQUFNLFdBQVc7QUFDakIsSUFBTSxXQUFXO0FBK0JWLElBQU0sY0FBTixjQUEwQixNQUFNO0FBQUEsRUFDckM7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQUlBO0FBQUEsRUFFQSxZQUFZLE1BT1Q7QUFDRCxVQUFNLEtBQUssT0FBTztBQUNsQixTQUFLLE9BQU87QUFDWixTQUFLLFNBQVMsS0FBSztBQUNuQixTQUFLLE9BQU8sS0FBSztBQUNqQixTQUFLLFlBQVksS0FBSztBQUN0QixTQUFLLFdBQVcsS0FBSztBQUNyQixTQUFLLG1CQUFtQixLQUFLLG9CQUFvQjtBQUFBLEVBQ25EO0FBQ0Y7QUFFTyxJQUFNLGVBQU4sTUFBbUI7QUFBQSxFQUNQO0FBQUEsRUFFakIsWUFBWSxVQUFvQjtBQUM5QixTQUFLLFdBQVc7QUFBQSxFQUNsQjtBQUFBO0FBQUEsRUFHQSxNQUFNLFNBQTBCO0FBQzlCLFVBQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxPQUFPLE9BQU87QUFDL0MsV0FBUSxJQUEyQixTQUFTO0FBQUEsRUFDOUM7QUFBQTtBQUFBLEVBR0EsTUFBTSxhQUFhLFFBQWtDO0FBQ25ELFFBQUk7QUFDRixZQUFNLEtBQUs7QUFBQSxRQUNUO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxtQkFBbUIsTUFBTSxDQUFDO0FBQUEsTUFDNUY7QUFDQSxhQUFPO0FBQUEsSUFDVCxTQUFTLEtBQUs7QUFDWixVQUFJLGVBQWUsZUFBZSxJQUFJLGFBQWEsWUFBYSxRQUFPO0FBQ3ZFLFlBQU07QUFBQSxJQUNSO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFHQSxNQUFNLG1CQUEwRjtBQUM5RixVQUFNLEtBQUssTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPO0FBQzlDLFVBQU0sT0FBTyxNQUFNLEtBQUssVUFBVSxPQUFPLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxFQUFFO0FBQzlGLFVBQU0sSUFBSTtBQUNWLFdBQU87QUFBQSxNQUNMLE9BQVEsR0FBeUI7QUFBQSxNQUNqQyxXQUFXLEVBQUU7QUFBQSxNQUNiLGdCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxvQkFBbUM7QUFDdkMsVUFBTSxPQUFPLE1BQU0sS0FBSyxjQUFjO0FBQ3RDLFVBQU0sS0FBSztBQUFBLE1BQ1Q7QUFBQSxNQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSSxtQkFBbUIsV0FBVyxLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDdEc7QUFBQSxRQUNFLEtBQUssS0FBSztBQUFBLFFBQ1YsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLGFBQWEsWUFBNEM7QUFDN0QsVUFBTSxNQUFNLEdBQUcsUUFBUSxJQUFJLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxLQUFLLFNBQVMsTUFBTSxJQUFJLFVBQVU7QUFDMUcsVUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsTUFDM0IsUUFBUTtBQUFBLE1BQ1IsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQUEsSUFDMUQsQ0FBQztBQUNELFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLFVBQVUsS0FBSyxXQUFXLFVBQVUsRUFBRTtBQUNwRSxXQUFPLElBQUksS0FBSztBQUFBLEVBQ2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sV0FBVyxNQUFzQztBQUNyRCxRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLFFBQ3JCO0FBQUEsUUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQyxRQUFRLG1CQUFtQixLQUFLLFNBQVMsTUFBTSxDQUFDO0FBQUEsTUFDbEk7QUFDQSxZQUFNLElBQUk7QUFDVixhQUFPLEVBQUUsT0FBTztBQUFBLElBQ2xCLFNBQVMsS0FBSztBQUNaLFVBQUksZUFBZSxlQUFlLElBQUksYUFBYSxZQUFhLFFBQU87QUFDdkUsWUFBTTtBQUFBLElBQ1I7QUFBQSxFQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxRQUFRLE1BQThDO0FBQzFELFVBQU0sT0FBTyxLQUFLO0FBQ2xCLFVBQU0sTUFBTSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQztBQUM1RixRQUFJLE1BQXFCLEtBQUssZUFBZTtBQUM3QyxVQUFNLGNBQWM7QUFFcEIsYUFBUyxVQUFVLEdBQUcsV0FBVyxhQUFhLFdBQVc7QUFDdkQsWUFBTSxPQUFnQztBQUFBLFFBQ3BDLFNBQVMsS0FBSztBQUFBLFFBQ2QsU0FBUyxLQUFLO0FBQUEsUUFDZCxRQUFRLEtBQUssU0FBUztBQUFBLE1BQ3hCO0FBQ0EsVUFBSSxJQUFLLE1BQUssTUFBTTtBQUNwQixVQUFJO0FBQ0YsY0FBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sS0FBSyxJQUFJO0FBQ2pELGNBQU0sTUFBTTtBQUNaLGVBQU8sRUFBRSxNQUFNLElBQUksUUFBUSxNQUFNLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLFFBQVEsU0FBUztBQUFBLE1BQ25GLFNBQVMsS0FBSztBQUNaLFlBQUksRUFBRSxlQUFlLGFBQWMsT0FBTTtBQUN6QyxZQUFJLElBQUksV0FBVyxPQUFPLENBQUMsS0FBSztBQUU5QixnQkFBTSxNQUFNLEtBQUssV0FBVyxJQUFJO0FBQ2hDLGNBQUksQ0FBQyxJQUFLLE9BQU07QUFDaEI7QUFBQSxRQUNGO0FBQ0EsWUFBSSxDQUFDLElBQUksYUFBYSxZQUFZLFlBQWEsT0FBTTtBQUNyRCxjQUFNLE1BQU0sVUFBVSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUNBLFVBQU0sSUFBSSxNQUFNLG1DQUFtQyxJQUFJLEVBQUU7QUFBQSxFQUMzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQSxNQUFNLFlBQVksTUFBc0Q7QUFDdEUsUUFBSSxLQUFLLE1BQU0sV0FBVyxFQUFHLE9BQU0sSUFBSSxNQUFNLGlDQUFpQztBQUM5RSxVQUFNLGNBQWM7QUFDcEIsUUFBSSxVQUFtQjtBQUV2QixhQUFTLFVBQVUsR0FBRyxXQUFXLGFBQWEsV0FBVztBQUN2RCxVQUFJO0FBQ0YsY0FBTSxRQUFRLE1BQU0sUUFBUTtBQUFBLFVBQzFCLEtBQUssTUFBTSxJQUFJLE9BQU8sU0FBUztBQUM3QixrQkFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLGNBQ3JCO0FBQUEsY0FDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxjQUNuRDtBQUFBLGdCQUNFLFNBQVMsS0FBSztBQUFBLGdCQUNkLFVBQVU7QUFBQSxjQUNaO0FBQUEsWUFDRjtBQUNBLG1CQUFPO0FBQUEsY0FDTCxNQUFNLEtBQUs7QUFBQSxjQUNYLEtBQU0sSUFBd0I7QUFBQSxZQUNoQztBQUFBLFVBQ0YsQ0FBQztBQUFBLFFBQ0g7QUFFQSxjQUFNLE9BQU8sTUFBTSxLQUFLLGNBQWM7QUFDdEMsY0FBTSxPQUFPLE1BQU0sS0FBSztBQUFBLFVBQ3RCO0FBQUEsVUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxVQUNuRDtBQUFBLFlBQ0UsV0FBVyxLQUFLO0FBQUEsWUFDaEIsTUFBTSxNQUFNLElBQUksQ0FBQyxVQUFVO0FBQUEsY0FDekIsTUFBTSxLQUFLO0FBQUEsY0FDWCxNQUFNO0FBQUEsY0FDTixNQUFNO0FBQUEsY0FDTixLQUFLLEtBQUs7QUFBQSxZQUNaLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUNBLGNBQU0sVUFBVyxLQUF5QjtBQUMxQyxjQUFNLFNBQVMsTUFBTSxLQUFLO0FBQUEsVUFDeEI7QUFBQSxVQUNBLFVBQVUsS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLFVBQ25EO0FBQUEsWUFDRSxTQUFTLEtBQUs7QUFBQSxZQUNkLE1BQU07QUFBQSxZQUNOLFNBQVMsQ0FBQyxLQUFLLEdBQUc7QUFBQSxVQUNwQjtBQUFBLFFBQ0Y7QUFDQSxjQUFNLFlBQVk7QUFDbEIsWUFBSTtBQUNGLGdCQUFNLEtBQUs7QUFBQSxZQUNUO0FBQUEsWUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksbUJBQW1CLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLFlBQ3RHO0FBQUEsY0FDRSxLQUFLLFVBQVU7QUFBQSxjQUNmLE9BQU87QUFBQSxZQUNUO0FBQUEsVUFDRjtBQUFBLFFBQ0YsU0FBUyxLQUFLO0FBQ1osY0FBSSxXQUFXLEdBQUcsS0FBSyxVQUFVLGFBQWE7QUFDNUMsc0JBQVU7QUFDVixrQkFBTSxNQUFNLFVBQVUsU0FBUyxHQUFHLENBQUM7QUFDbkM7QUFBQSxVQUNGO0FBQ0EsZ0JBQU07QUFBQSxRQUNSO0FBQ0EsZUFBTztBQUFBLFVBQ0wsV0FBVyxVQUFVO0FBQUEsVUFDckIsS0FBSyxVQUFVO0FBQUEsVUFDZixPQUFPLEtBQUssTUFBTSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUk7QUFBQSxRQUMzQztBQUFBLE1BQ0YsU0FBUyxLQUFLO0FBQ1osa0JBQVU7QUFDVixZQUFJLEVBQUUsZUFBZSxhQUFjLE9BQU07QUFDekMsWUFBSyxDQUFDLElBQUksYUFBYSxDQUFDLFdBQVcsR0FBRyxLQUFNLFlBQVksWUFBYSxPQUFNO0FBQzNFLGNBQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQ0EsVUFBTSxtQkFBbUIsUUFBUSxVQUFVLElBQUksTUFBTSxpQ0FBaUM7QUFBQSxFQUN4RjtBQUFBLEVBRUEsTUFBYyxnQkFBMkQ7QUFDdkUsVUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLE1BQ3JCO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksa0JBQWtCLFdBQVcsS0FBSyxTQUFTLE1BQU0sQ0FBQztBQUFBLElBQ3ZHO0FBQ0EsVUFBTSxVQUFXLElBQW9DLE9BQU87QUFDNUQsVUFBTSxTQUFTLE1BQU0sS0FBSztBQUFBLE1BQ3hCO0FBQUEsTUFDQSxVQUFVLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxTQUFTLElBQUksZ0JBQWdCLE9BQU87QUFBQSxJQUM1RTtBQUNBLFdBQU87QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMLFNBQVUsT0FBcUMsS0FBSztBQUFBLElBQ3REO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBYyxVQUFVLFFBQWdCLE1BQWMsTUFBa0M7QUFDdEYsVUFBTSxNQUFNLEtBQUssV0FBVyxNQUFNLElBQUksT0FBTyxHQUFHLFFBQVEsR0FBRyxJQUFJO0FBQy9ELFVBQU0sT0FBb0I7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsU0FBUztBQUFBLFFBQ1AsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFHO0FBQUEsUUFDMUMsUUFBUTtBQUFBLFFBQ1Isd0JBQXdCO0FBQUEsUUFDeEIsR0FBSSxPQUFPLEVBQUUsZ0JBQWdCLG1CQUFtQixJQUFJLENBQUM7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsR0FBSSxPQUFPLEVBQUUsTUFBTSxLQUFLLFVBQVUsSUFBSSxFQUFFLElBQUksQ0FBQztBQUFBLElBQy9DO0FBQ0EsUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLE1BQU0sTUFBTSxLQUFLLElBQUk7QUFBQSxJQUM3QixTQUFTLFFBQVE7QUFDZixZQUFNLElBQUksWUFBWTtBQUFBLFFBQ3BCLFFBQVE7QUFBQSxRQUNSLE1BQU07QUFBQSxRQUNOLFNBQVMsWUFBWSxjQUFjLE1BQU0sRUFBRSxPQUFPO0FBQUEsUUFDbEQsV0FBVztBQUFBLFFBQ1gsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0g7QUFDQSxRQUFJLElBQUksV0FBVyxJQUFLLFFBQU87QUFDL0IsUUFBSSxTQUFrQjtBQUN0QixVQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsUUFBSSxNQUFNO0FBQ1IsVUFBSTtBQUNGLGlCQUFTLEtBQUssTUFBTSxJQUFJO0FBQUEsTUFDMUIsUUFBUTtBQUNOLGlCQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxHQUFJLE9BQU0sTUFBTSxLQUFLLG9CQUFvQixLQUFLLFFBQVEsR0FBRyxNQUFNLElBQUksSUFBSSxFQUFFO0FBQ2xGLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLFVBQVUsS0FBZSxPQUFxQztBQUMxRSxRQUFJLFNBQWtCO0FBQ3RCLFFBQUk7QUFDRixZQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7QUFDNUIsVUFBSSxLQUFNLFVBQVMsS0FBSyxNQUFNLElBQUk7QUFBQSxJQUNwQyxRQUFRO0FBQUEsSUFFUjtBQUNBLFdBQU8sS0FBSyxvQkFBb0IsS0FBSyxRQUFRLEtBQUs7QUFBQSxFQUNwRDtBQUFBLEVBRVEsb0JBQW9CLEtBQWUsTUFBZSxPQUE0QjtBQUNwRixVQUFNLE1BQ0osT0FBTyxTQUFTLFlBQVksUUFBUSxhQUFhLE9BQzdDLE9BQVEsS0FBOEIsT0FBTyxJQUM3QyxJQUFJO0FBQ1YsUUFBSSxXQUFvQztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUU1QyxZQUFNLE9BQU8sSUFBSSxRQUFRLElBQUksdUJBQXVCO0FBQ3BELFVBQUksU0FBUyxPQUFPLGNBQWMsS0FBSyxHQUFHLEdBQUc7QUFDM0MsbUJBQVc7QUFDWCxvQkFBWTtBQUFBLE1BQ2QsT0FBTztBQUNMLG1CQUFXO0FBQUEsTUFDYjtBQUFBLElBQ0YsV0FBVyxJQUFJLFdBQVcsS0FBSztBQUM3QixpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFdBQVcsT0FBTyxJQUFJLFdBQVcsS0FBSztBQUNuRCxpQkFBVztBQUFBLElBQ2IsV0FBVyxJQUFJLFVBQVUsS0FBSztBQUM1QixpQkFBVztBQUNYLGtCQUFZO0FBQUEsSUFDZCxXQUFXLElBQUksV0FBVyxLQUFLO0FBQzdCLGlCQUFXO0FBQ1gsa0JBQVk7QUFBQSxJQUNkO0FBQ0EsV0FBTyxJQUFJLFlBQVk7QUFBQSxNQUNyQixRQUFRLElBQUk7QUFBQSxNQUNaO0FBQUEsTUFDQSxTQUFTLEdBQUcsS0FBSyxXQUFNLElBQUksTUFBTSxLQUFLLEdBQUc7QUFBQSxNQUN6QztBQUFBLE1BQ0E7QUFBQSxNQUNBLGtCQUFrQixhQUFhLGVBQWUsb0JBQW9CLElBQUksT0FBTyxJQUFJO0FBQUEsSUFDbkYsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQVFBLFNBQVMsb0JBQW9CLFNBQWlDO0FBQzVELFFBQU0sUUFBUSxRQUFRLElBQUksbUJBQW1CO0FBQzdDLE1BQUksT0FBTztBQUNULFVBQU0sSUFBSSxPQUFPLFNBQVMsT0FBTyxFQUFFO0FBQ25DLFFBQUksT0FBTyxTQUFTLENBQUMsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUFBLEVBQzFDO0FBQ0EsUUFBTSxhQUFhLFFBQVEsSUFBSSxhQUFhO0FBQzVDLE1BQUksWUFBWTtBQUNkLFVBQU0sUUFBUSxPQUFPLFNBQVMsWUFBWSxFQUFFO0FBQzVDLFFBQUksT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLEdBQUc7QUFDeEMsYUFBTyxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSSxJQUFJO0FBQUEsSUFDekM7QUFDQSxVQUFNLFNBQVMsS0FBSyxNQUFNLFVBQVU7QUFDcEMsUUFBSSxPQUFPLFNBQVMsTUFBTSxFQUFHLFFBQU8sS0FBSyxNQUFNLFNBQVMsR0FBSTtBQUFBLEVBQzlEO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLE1BQXNCO0FBRXhDLFNBQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJLGtCQUFrQixFQUFFLEtBQUssR0FBRztBQUN6RDtBQUVBLFNBQVMsVUFBVSxTQUFpQixLQUEwQjtBQUU1RCxRQUFNLE9BQU8sSUFBSSxhQUFhLGVBQWUsTUFBTztBQUNwRCxRQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQUc7QUFDN0MsU0FBTyxLQUFLLElBQUksS0FBUSxPQUFPLE1BQU0sVUFBVSxLQUFLLE1BQU07QUFDNUQ7QUFFQSxTQUFTLFdBQVcsS0FBa0M7QUFDcEQsU0FBTyxlQUFlLGVBQWUsSUFBSSxhQUFhO0FBQ3hEO0FBRUEsU0FBUyxNQUFNLElBQTJCO0FBQ3hDLFNBQU8sSUFBSSxRQUFRLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQzdDO0FBRU8sU0FBU0EsVUFBUyxPQUF1QjtBQUU5QyxRQUFNLE9BQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxLQUFLO0FBQzNDLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLFFBQU8sT0FBTyxhQUFhLENBQUM7QUFDbEQsU0FBTyxLQUFLLEdBQUc7QUFDakI7OztBQzNYQSxJQUFNLGNBQWM7QUFTcEIsSUFBTSx1QkFBNEMsb0JBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUVoRSxTQUFTLFVBQVUsU0FBa0IsS0FBd0M7QUFDbEYsUUFBTSxZQUFZLGNBQWMsT0FBTztBQUN2QyxRQUFNLFNBQTJCLENBQUM7QUFDbEMsUUFBTSxvQkFBd0MsQ0FBQztBQUMvQyxRQUFNLFdBQXFCLENBQUM7QUFDNUIsUUFBTSxRQUFRLG9CQUFJLElBQVk7QUFDOUIsUUFBTSxhQUFhLG9CQUFJLElBQTJCO0FBQ2xELFFBQU0sa0JBQWtCLHFCQUFxQixJQUFJLElBQUksUUFBUTtBQUM3RCxhQUFXLE9BQU8sV0FBVztBQUMzQixRQUFJO0FBQ0YsWUFBTSxjQUFjLHFCQUFxQixLQUFLLEdBQUc7QUFDakQsVUFBSSxhQUFhO0FBQ2YsMEJBQWtCLEtBQUssV0FBVztBQUNsQyxpQkFBUyxLQUFLLFlBQVksUUFBUTtBQUNsQyxjQUFNLElBQUksWUFBWSxRQUFRO0FBQzlCO0FBQUEsTUFDRjtBQUNBLFlBQU0sSUFBSSxXQUFXLEtBQUssR0FBRztBQUM3QixVQUFJLENBQUMsR0FBRztBQUNOLFlBQUksaUJBQWlCO0FBSW5CLGdCQUFNLFVBQVUsWUFBWSxHQUFHO0FBQy9CLGNBQUksUUFBUyxZQUFXLElBQUksUUFBUSxVQUFVLFFBQVEsV0FBVztBQUFBLFFBQ25FO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsZUFBUyxLQUFLLEVBQUUsUUFBUTtBQUN4QixZQUFNLElBQUksRUFBRSxRQUFRO0FBQ3BCLFVBQUksSUFBSSxlQUFlLFNBQVMsS0FBSyxJQUFJLGVBQWUsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDLEdBQUc7QUFDM0YsZUFBTyxLQUFLLENBQUM7QUFBQSxNQUNmO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFHQSxRQUFNLGNBQXVFLENBQUM7QUFDOUUsYUFBVyxDQUFDLElBQUksSUFBSSxLQUFLLFlBQVk7QUFDbkMsUUFBSSxNQUFNLElBQUksRUFBRSxFQUFHO0FBQ25CLGdCQUFZLEtBQUssRUFBRSxVQUFVLElBQUksYUFBYSxLQUFLLENBQUM7QUFBQSxFQUN0RDtBQUNBLFNBQU8sRUFBRSxRQUFRLGNBQWMsVUFBVSxvQkFBb0IsbUJBQW1CLFlBQVk7QUFDOUY7QUFFQSxTQUFTLHFCQUFxQixNQUFlLEtBQWdEO0FBQzNGLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFFOUMsUUFBTSxVQUNKLFVBQVUsRUFBRSxPQUFPLEtBQ25CLG9CQUFvQixJQUFJLE1BQ3ZCLElBQUksWUFBWSxvQkFBb0IsSUFBSSxTQUFTLElBQUk7QUFDeEQsTUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEtBQUssT0FBTyxFQUFHLFFBQU87QUFFbkQsUUFBTSxrQkFBa0Isa0JBQWtCLElBQUk7QUFDOUMsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsZ0JBQ0Usd0JBQXdCLE1BQU0sT0FBTyxNQUNwQyxJQUFJLFlBQVksbUJBQW1CLElBQUksV0FBVyxPQUFPLElBQUk7QUFBQSxJQUNoRSx5QkFBeUIsSUFBSTtBQUFBLElBQzdCLG9CQUFvQiwwQkFBMEIsZUFBZTtBQUFBLElBQzdELGtCQUFrQjtBQUFBLElBQ2xCLHdCQUF3QixJQUFJLGFBQWE7QUFBQSxFQUMzQztBQUNGO0FBRUEsU0FBUyxvQkFBb0IsTUFBOEI7QUFDekQsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sS0FBSyxvQkFBb0IsR0FBRztBQUNsQyxVQUFJLEdBQUksUUFBTztBQUNmO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLG9CQUFvQixRQUErQjtBQUMxRCxNQUFJO0FBQ0YsVUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLGdCQUFnQjtBQUM1QyxRQUFJLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxjQUFlLFFBQU87QUFDdkUsVUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLG9EQUFvRDtBQUNyRixXQUFPLFFBQVEsQ0FBQyxLQUFLO0FBQUEsRUFDdkIsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixNQUE4QjtBQUN2RCxRQUFNLFVBQW9CLENBQUM7QUFDM0IsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sVUFBVSxJQUFJLEtBQUs7QUFDekIsVUFDRSxRQUFRLFVBQVUsS0FDbEIsQ0FBQyxRQUFRLFdBQVcsU0FBUyxLQUM3QixDQUFDLFFBQVEsV0FBVyxVQUFVLEdBQzlCO0FBQ0EsZ0JBQVEsS0FBSyxPQUFPO0FBQUEsTUFDdEI7QUFDQTtBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsU0FBVTtBQUM3QyxRQUFJLEtBQUssSUFBSSxHQUFhLEVBQUc7QUFDN0IsU0FBSyxJQUFJLEdBQWE7QUFDdEIsUUFBSSxNQUFNLFFBQVEsR0FBRyxHQUFHO0FBQ3RCLGlCQUFXLEtBQUssSUFBSyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ25DLE9BQU87QUFDTCxpQkFBVyxLQUFLLE9BQU8sT0FBTyxHQUE4QixFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDN0U7QUFBQSxFQUNGO0FBQ0EsUUFBTSxZQUFZLFFBQVE7QUFBQSxJQUFLLENBQUMsTUFDOUIsOEVBQThFLEtBQUssQ0FBQztBQUFBLEVBQ3RGO0FBQ0EsU0FBTyxhQUFhLFFBQVEsQ0FBQyxLQUFLO0FBQ3BDO0FBRUEsU0FBUywwQkFBMEIsTUFBb0M7QUFDckUsTUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixNQUFJLHdCQUF3QixLQUFLLElBQUksRUFBRyxRQUFPO0FBQy9DLE1BQUksZ0JBQWdCLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDdkMsTUFBSSx1QkFBdUIsS0FBSyxJQUFJLEVBQUcsUUFBTztBQUM5QyxNQUFJLGlCQUFpQixLQUFLLElBQUksRUFBRyxRQUFPO0FBQ3hDLE1BQUksaUNBQWlDLEtBQUssSUFBSSxFQUFHLFFBQU87QUFDeEQsU0FBTztBQUNUO0FBRUEsU0FBUyxZQUFZLE1BQXdFO0FBQzNGLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBR1YsTUFBSSxFQUFFLGVBQWUsaUJBQWtCLFFBQU87QUFHOUMsUUFBTSxLQUFLLEVBQUU7QUFDYixNQUFJLE9BQU8sV0FBVyxPQUFPLGdDQUFnQyxDQUFDLElBQUksRUFBRSxNQUFNLEdBQUc7QUFDM0UsV0FBTztBQUFBLEVBQ1Q7QUFDQSxRQUFNLFNBQ0gsT0FBTyxFQUFFLFlBQVksWUFBWSxFQUFFLFdBQ25DLE9BQU8sSUFBSSxFQUFFLFlBQVksR0FBRyxXQUFXLFlBQ3JDLElBQUksSUFBSSxFQUFFLFlBQVksR0FBRyxNQUFNLEdBQUc7QUFDdkMsTUFBSSxPQUFPLFdBQVcsWUFBWSxDQUFDLFlBQVksS0FBSyxNQUFNLEVBQUcsUUFBTztBQUNwRSxRQUFNLGFBQWEsZUFBZSxNQUFNLE1BQU07QUFDOUMsTUFBSSxDQUFDLFdBQVksUUFBTztBQUN4QixTQUFPLEVBQUUsVUFBVSxRQUFRLGFBQWEsV0FBVztBQUNyRDtBQUVBLFNBQVMsZUFBZSxNQUFlLFNBQWdDO0FBQ3JFLE1BQUksT0FBTyxTQUFTLFlBQVksU0FBUyxLQUFNLFFBQU87QUFDdEQsUUFBTSxJQUFJO0FBQ1YsUUFBTSxhQUFhLElBQUksSUFBSSxJQUFJLEVBQUUsSUFBSSxHQUFHLFlBQVksR0FBRyxNQUFNO0FBQzdELFNBQ0UsVUFBVSxJQUFJLFlBQVksSUFBSSxHQUFHLFdBQVcsS0FDNUMsVUFBVSxJQUFJLFlBQVksTUFBTSxHQUFHLFdBQVcsS0FDOUMsVUFBVSxJQUFJLEVBQUUsTUFBTSxHQUFHLFdBQVcsS0FDcEMsd0JBQXdCLE1BQU0sT0FBTztBQUV6QztBQUVBLFNBQVMsd0JBQXdCLE1BQWUsU0FBZ0M7QUFDOUUsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxNQUFNLE1BQU0sSUFBSTtBQUN0QixRQUFJLE9BQU8sUUFBUSxVQUFVO0FBQzNCLFlBQU0sU0FBUyxtQkFBbUIsS0FBSyxPQUFPO0FBQzlDLFVBQUksT0FBUSxRQUFPO0FBQ25CO0FBQUEsSUFDRjtBQUNBLFFBQUksUUFBUSxRQUFRLE9BQU8sUUFBUSxTQUFVO0FBQzdDLFFBQUksS0FBSyxJQUFJLEdBQWEsRUFBRztBQUM3QixTQUFLLElBQUksR0FBYTtBQUN0QixRQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFDdEIsaUJBQVcsS0FBSyxJQUFLLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbkMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLEdBQThCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM3RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLG1CQUFtQixRQUFnQixTQUFnQztBQUMxRSxNQUFJO0FBQ0YsVUFBTSxNQUFNLElBQUksSUFBSSxRQUFRLGdCQUFnQjtBQUM1QyxRQUFJLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxjQUFlLFFBQU87QUFDdkUsVUFBTSxRQUFRLElBQUksU0FBUyxNQUFNLHNEQUFzRDtBQUN2RixRQUFJLENBQUMsU0FBUyxNQUFNLENBQUMsTUFBTSxRQUFTLFFBQU87QUFDM0MsV0FBTyxNQUFNLENBQUMsS0FBSztBQUFBLEVBQ3JCLFFBQVE7QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsU0FBUyxjQUFjQyxNQUF5QjtBQUs5QyxRQUFNLE1BQWlCLENBQUM7QUFDeEIsUUFBTSxPQUFPLG9CQUFJLFFBQWdCO0FBQ2pDLFFBQU0sUUFBbUIsQ0FBQ0EsSUFBRztBQUM3QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sT0FBTyxNQUFNLElBQUk7QUFDdkIsUUFBSSxTQUFTLFFBQVEsU0FBUyxPQUFXO0FBQ3pDLFFBQUksT0FBTyxTQUFTLFNBQVU7QUFDOUIsUUFBSSxLQUFLLElBQUksSUFBYyxFQUFHO0FBQzlCLFNBQUssSUFBSSxJQUFjO0FBRXZCLFFBQUksZUFBZSxJQUFJLEdBQUc7QUFDeEIsVUFBSSxLQUFLLFlBQVksSUFBSSxDQUFDO0FBQUEsSUFDNUI7QUFDQSxRQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUc7QUFDdkIsaUJBQVcsS0FBSyxLQUFNLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDcEMsT0FBTztBQUNMLGlCQUFXLEtBQUssT0FBTyxPQUFPLElBQStCLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUM5RTtBQUFBLEVBQ0Y7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGVBQWUsTUFBZ0Q7QUFDdEUsTUFBSSxPQUFPLFNBQVMsWUFBWSxTQUFTLEtBQU0sUUFBTztBQUN0RCxRQUFNLElBQUk7QUFDVixRQUFNLFdBQVcsRUFBRTtBQUNuQixNQUNFLGFBQWEsV0FDYixhQUFhLGdDQUNiLGFBQWEsa0JBQ2I7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQU8sT0FBTyxFQUFFLFlBQVksWUFBWSxPQUFPLEVBQUUsV0FBVyxZQUFZLEVBQUUsV0FBVztBQUN2RjtBQUVBLFNBQVMsWUFBWSxNQUF3RDtBQUMzRSxNQUFJLEtBQUssZUFBZSxnQ0FBZ0MsT0FBTyxLQUFLLFVBQVUsVUFBVTtBQUN0RixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0EsU0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLEtBQWMsS0FBOEM7QUFDOUUsTUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLEtBQU0sUUFBTztBQUNwRCxRQUFNLElBQUk7QUFFVixNQUFJLEVBQUUsZUFBZSxpQkFBa0IsUUFBTztBQUU5QyxRQUFNLFNBQVMsVUFBVSxFQUFFLE9BQU87QUFLbEMsUUFBTSxTQUFTLElBQUksRUFBRSxNQUFNLEtBQUssQ0FBQztBQUNqQyxNQUFJLENBQUMsT0FBUSxRQUFPO0FBRXBCLFFBQU0sT0FBTyxJQUFJLEVBQUUsSUFBSTtBQUN2QixRQUFNLGFBQWEsSUFBSSxJQUFJLE1BQU0sWUFBWSxHQUFHLE1BQU07QUFHdEQsUUFBTSxjQUFjLElBQUksWUFBWSxJQUFJO0FBQ3hDLFFBQU0sYUFBYSxJQUFJLFlBQVksTUFBTTtBQUN6QyxRQUFNLGdCQUFnQixJQUFJLFlBQVksTUFBTTtBQUM1QyxRQUFNLFNBQ0osVUFBVSxhQUFhLFdBQVcsS0FDbEMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxZQUFZLFdBQVcsS0FDakMsVUFBVSxPQUFPLFdBQVc7QUFDOUIsUUFBTSxZQUNKLFVBQVUsWUFBWSxPQUFPLEtBQzdCLFVBQVUsWUFBWSxNQUFNLEtBQzVCLFVBQVUsT0FBTyxXQUFXO0FBQzlCLE1BQUksQ0FBQyxVQUFVLENBQUMsVUFBVyxRQUFPO0FBTWxDLFFBQU0sU0FBUyxvQkFBb0IsWUFBWSxhQUFhLFlBQVksYUFBYTtBQUVyRixRQUFNLFlBQVksSUFBSSxJQUFJLElBQUksRUFBRSxVQUFVLEdBQUcsa0JBQWtCLEdBQUcsTUFBTTtBQUN4RSxRQUFNLGVBQWUsVUFBVSxXQUFXLElBQUk7QUFDOUMsUUFBTSxpQkFBaUIsVUFBVSxPQUFPLFNBQVMsS0FBSztBQUN0RCxRQUFNLE9BQU8sZ0JBQWdCO0FBQzdCLFFBQU0sY0FBYyxpQkFBaUIsV0FBVyxRQUFRLGNBQWM7QUFDdEUsUUFBTSxnQkFBZ0IscUJBQXFCLEdBQUcsUUFBUSxJQUFJLFVBQVU7QUFFcEUsUUFBTSxXQUFXLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQztBQUMxQyxRQUFNLG1CQUFtQixJQUFJLFdBQVcsVUFBVTtBQUNsRCxRQUFNLFdBQVcsZ0JBQWdCLG9CQUFvQixRQUFRO0FBQzdELFFBQU0sV0FBVyxnQkFBZ0Isb0JBQW9CLFFBQVE7QUFDN0QsUUFBTSxPQUFPLFlBQVksb0JBQW9CLFFBQVE7QUFDckQsUUFBTSxRQUFRLGFBQWEsTUFBTTtBQUVqQyxRQUFNLFlBQVksa0JBQWtCLEdBQUcsTUFBTTtBQUk3QyxRQUFNLFdBQ0osaUJBQWlCLFVBQVUsT0FBTyxVQUFVLENBQUMsS0FBSyxpQkFBaUIsVUFBVSxFQUFFLFVBQVUsQ0FBQztBQUM1RixNQUFJLENBQUMsU0FBVSxRQUFPO0FBRXRCLFFBQU0sUUFBUSxJQUFJLEVBQUUsS0FBSztBQUN6QixRQUFNLFlBQVksVUFBVSxPQUFPLEtBQUssS0FBSyxVQUFVLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFFOUUsUUFBTSxPQUFPLFlBQVksQ0FBQztBQUMxQixRQUFNLFFBQVEsSUFBSSxPQUFPLEtBQUs7QUFFOUIsUUFBTSxRQUF3QjtBQUFBLElBQzVCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLFdBQVc7QUFBQSxJQUNYLG1CQUFtQixJQUFJO0FBQUEsSUFDdkIsY0FBYyxJQUFJO0FBQUEsSUFDbEIsc0JBQXNCO0FBQUEsSUFDdEIseUJBQXlCO0FBQUEsSUFDekIsb0JBQW9CO0FBQUEsSUFDcEIsa0JBQWtCO0FBQUEsSUFDbEIsd0JBQXdCO0FBQUEsSUFDeEIsV0FBVyxHQUFHLGdCQUFnQixJQUFJLE1BQU0sV0FBVyxNQUFNO0FBQUEsSUFDekQsWUFBWTtBQUFBLElBQ1osaUJBQWlCLFVBQVUsT0FBTyxtQkFBbUI7QUFBQSxJQUNyRCxtQkFBbUIsVUFBVSxPQUFPLHlCQUF5QjtBQUFBLElBQzdELGtCQUFrQixVQUFVLE9BQU8sdUJBQXVCO0FBQUEsSUFDMUQscUJBQXFCLFVBQVUsT0FBTyx1QkFBdUI7QUFBQSxJQUM3RCxpQkFBaUIsVUFBVSxPQUFPLG9CQUFvQjtBQUFBLElBQ3RELG9CQUFvQjtBQUFBLE1BQ2xCLElBQUksSUFBSSxPQUFPLHVCQUF1QixHQUFHLE1BQU0sR0FBRyxXQUMvQyxPQUFtQztBQUFBLElBQ3hDO0FBQUEsSUFDQTtBQUFBLElBQ0EsZUFBZSxpQkFBaUIsTUFBTSxJQUFJO0FBQUEsSUFDMUMsTUFBTSxVQUFVLE9BQU8sSUFBSTtBQUFBLElBQzNCLG9CQUFvQixXQUFXLE9BQU8sa0JBQWtCO0FBQUEsSUFDeEQsUUFBUSxVQUFVLE9BQU8sTUFBTSxLQUFLLFVBQVUsRUFBRSxNQUFNO0FBQUEsSUFDdEQsaUJBQWlCLFVBQVUsT0FBTyxTQUFTO0FBQUEsSUFDM0M7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDM0MsZUFBZSxVQUFVLE9BQU8sYUFBYTtBQUFBLElBQzdDLGFBQWEsVUFBVSxPQUFPLFdBQVc7QUFBQSxJQUN6QyxhQUFhLFVBQVUsT0FBTyxXQUFXO0FBQUEsSUFDekMsWUFBWTtBQUFBLElBQ1osZ0JBQWdCLFVBQVUsT0FBTyxjQUFjO0FBQUEsSUFDL0Msb0JBQW9CO0FBQUEsTUFDbEI7QUFBQSxRQUNFLGFBQWEsSUFBSTtBQUFBLFFBQ2pCLE9BQU8sVUFBVSxPQUFPLGNBQWM7QUFBQSxRQUN0QyxVQUFVLFVBQVUsT0FBTyxhQUFhO0FBQUEsUUFDeEMsU0FBUyxVQUFVLE9BQU8sV0FBVztBQUFBLFFBQ3JDLFFBQVEsVUFBVSxPQUFPLFdBQVc7QUFBQSxRQUNwQyxPQUFPO0FBQUEsUUFDUCxXQUFXLFVBQVUsT0FBTyxjQUFjO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLElBQ0EsZ0JBQWdCO0FBQUEsSUFDaEIsY0FBYztBQUFBLElBQ2QsYUFBYTtBQUFBLElBQ2Isc0JBQXNCO0FBQUEsSUFDdEIsZ0JBQWdCO0FBQUEsSUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxJQUNwQixnQkFBZ0I7QUFBQSxFQUNsQjtBQUVBLFNBQU87QUFDVDtBQUVBLFNBQVMsa0JBQWtCLEdBQTRCLFFBQTRDO0FBQ2pHLE1BQUksT0FBTywyQkFBMkIsT0FBTyx3QkFBeUIsUUFBTztBQUM3RSxNQUFJLE9BQU8sMEJBQTJCLFFBQU87QUFDN0MsTUFBSSxPQUFPLG9CQUFvQixRQUFRLE9BQU8scUJBQXNCLFFBQU87QUFDM0UsTUFBSSxFQUFFLGVBQWUsOEJBQThCO0FBQUEsRUFFbkQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGdCQUFnQixVQUE2QztBQUNwRSxRQUFNLE1BQU0sU0FBUztBQUNyQixNQUFJLENBQUMsTUFBTSxRQUFRLEdBQUcsRUFBRyxRQUFPLENBQUM7QUFDakMsU0FBTyxJQUNKO0FBQUEsSUFBSSxDQUFDLE1BQ0osT0FBTyxNQUFNLFlBQVksS0FBSyxVQUFVLElBQUksT0FBUSxFQUF3QixJQUFJLElBQUk7QUFBQSxFQUN0RixFQUNDLE9BQU8sQ0FBQyxNQUFtQixPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsQ0FBQztBQUNyRTtBQUVBLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxTQUFPLElBQ0o7QUFBQSxJQUFJLENBQUMsTUFDSixPQUFPLE1BQU0sWUFBWSxLQUFLLGlCQUFpQixJQUMzQyxPQUFRLEVBQStCLFdBQVcsSUFDbEQ7QUFBQSxFQUNOLEVBQ0MsT0FBTyxDQUFDLE1BQW1CLE9BQU8sTUFBTSxZQUFZLEVBQUUsU0FBUyxDQUFDO0FBQ3JFO0FBRUEsU0FBUyxZQUFZLFVBQWdEO0FBQ25FLFFBQU0sTUFBTSxTQUFTO0FBQ3JCLE1BQUksQ0FBQyxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sQ0FBQztBQUNqQyxRQUFNLE1BQW1CLENBQUM7QUFDMUIsYUFBVyxLQUFLLEtBQUs7QUFDbkIsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU07QUFDekMsVUFBTSxJQUFJO0FBQ1YsVUFBTSxRQUFRLFVBQVUsRUFBRSxHQUFHO0FBQzdCLFVBQU0sV0FBVyxVQUFVLEVBQUUsWUFBWTtBQUN6QyxVQUFNLFVBQVUsVUFBVSxFQUFFLFdBQVc7QUFDdkMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFVO0FBQ3pCLFFBQUksS0FBSyxFQUFFLE9BQU8sVUFBVSxTQUFTLFdBQVcsU0FBUyxDQUFDO0FBQUEsRUFDNUQ7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGFBQWEsUUFBOEM7QUFDbEUsUUFBTSxXQUFXLElBQUksT0FBTyxpQkFBaUI7QUFDN0MsUUFBTSxVQUFVLFdBQVcsUUFBUSxTQUFTLEtBQUssSUFBSSxDQUFDO0FBQ3RELFFBQU0sVUFBVSxRQUFRLElBQUksT0FBTyxRQUFRLEdBQUcsS0FBSztBQUNuRCxRQUFNLE9BQU8sb0JBQUksSUFBWTtBQUM3QixRQUFNLFNBQVMsQ0FBQyxHQUFHLFNBQVMsR0FBRyxPQUFPLEVBQUUsT0FBTyxDQUFDLE1BQU07QUFDcEQsUUFBSSxPQUFPLE1BQU0sWUFBWSxNQUFNLEtBQU0sUUFBTztBQUNoRCxVQUFNLEtBQ0osVUFBVyxFQUE4QixTQUFTLEtBQ2xELFVBQVcsRUFBOEIsTUFBTTtBQUNqRCxRQUFJLENBQUMsR0FBSSxRQUFPO0FBQ2hCLFFBQUksS0FBSyxJQUFJLEVBQUUsRUFBRyxRQUFPO0FBQ3pCLFNBQUssSUFBSSxFQUFFO0FBQ1gsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNELFNBQU8sT0FBTyxJQUFJLENBQUMsUUFBUSxXQUFXLEdBQThCLENBQUM7QUFDdkU7QUFFQSxTQUFTLFdBQVcsR0FBdUM7QUFDekQsUUFBTSxPQUFPLFVBQVUsRUFBRSxJQUFJO0FBQzdCLFFBQU0sV0FBVyxnQkFBZ0IsR0FBRyxJQUFJO0FBQ3hDLFFBQU1DLFFBQU8sSUFBSSxFQUFFLGFBQWE7QUFDaEMsUUFBTSxZQUFZLElBQUksRUFBRSxVQUFVO0FBQ2xDLFFBQU0sYUFBYSxVQUFVLFdBQVcsZUFBZTtBQUN2RCxRQUFNLFVBQVUsVUFBVSxFQUFFLFlBQVk7QUFDeEMsUUFBTSxVQUNKLFVBQVUsRUFBRSxTQUFTLEtBQ3JCLFVBQVUsRUFBRSxNQUFNLEtBQ2xCLEdBQUcsUUFBUSxPQUFPLElBQUksS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7QUFDM0QsU0FBTztBQUFBLElBQ0wsVUFBVTtBQUFBLElBQ1YsWUFBYSxRQUFRO0FBQUEsSUFDckIsY0FBYyxZQUFZO0FBQUEsSUFDMUIsbUJBQW1CO0FBQUEsSUFDbkIsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsY0FBYyxlQUFlLE9BQU8sYUFBYSxNQUFPO0FBQUEsSUFDeEQsT0FBTyxVQUFVQSxPQUFNLEtBQUs7QUFBQSxJQUM1QixRQUFRLFVBQVVBLE9BQU0sTUFBTTtBQUFBLElBQzlCLFVBQVU7QUFBQSxJQUNWLGdCQUFnQjtBQUFBLElBQ2hCLGtCQUFrQjtBQUFBLElBQ2xCLGlCQUFpQjtBQUFBLEVBQ25CO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixHQUE0QixNQUFvQztBQUN2RixNQUFJLFNBQVMsUUFBUyxRQUFPLFVBQVUsRUFBRSxlQUFlLEtBQUssVUFBVSxFQUFFLFNBQVM7QUFDbEYsUUFBTSxXQUFXLFFBQVEsSUFBSSxFQUFFLFVBQVUsR0FBRyxRQUFRO0FBQ3BELE1BQUksU0FBUyxXQUFXLEVBQUcsUUFBTyxVQUFVLEVBQUUsZUFBZTtBQUU3RCxNQUFJLE9BQWdEO0FBQ3BELGFBQVcsS0FBSyxVQUFVO0FBQ3hCLFVBQU0sS0FBSyxVQUFVLEVBQUUsWUFBWTtBQUNuQyxVQUFNLE1BQU0sVUFBVSxFQUFFLEdBQUc7QUFDM0IsUUFBSSxDQUFDLElBQUs7QUFDVixRQUFJLE9BQU8sYUFBYTtBQUN0QixZQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sS0FBSztBQUNuQyxVQUFJLENBQUMsUUFBUSxLQUFLLEtBQUssUUFBUyxRQUFPLEVBQUUsS0FBSyxTQUFTLEdBQUc7QUFBQSxJQUM1RCxXQUFXLENBQUMsTUFBTTtBQUVoQixhQUFPLEVBQUUsS0FBSyxTQUFTLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFDQSxTQUFPLE1BQU0sT0FBTztBQUN0QjtBQUVBLFNBQVMsaUJBQWlCLE1BQWMsTUFBMkI7QUFDakUsTUFBSSxLQUFLLFdBQVcsRUFBRyxRQUFPO0FBQzlCLE1BQUksTUFBTTtBQUNWLGFBQVcsS0FBSyxLQUFNLE9BQU0sSUFBSSxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRO0FBQzlELFNBQU87QUFDVDtBQUVBLFNBQVMsaUJBQWlCLEdBQWlDO0FBQ3pELE1BQUksQ0FBQyxFQUFHLFFBQU87QUFFZixRQUFNLElBQUksSUFBSSxLQUFLLENBQUM7QUFDcEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPO0FBQ3RDLFNBQU8sRUFBRSxZQUFZO0FBQ3ZCO0FBRUEsU0FBUyxVQUFVLEdBQTJCO0FBQzVDLFNBQU8sT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLElBQUksSUFBSTtBQUNyRDtBQUNBLFNBQVMsV0FBVyxHQUE0QjtBQUM5QyxTQUFPLE9BQU8sTUFBTSxZQUFZLElBQUk7QUFDdEM7QUFDQSxTQUFTLFVBQVUsR0FBMkI7QUFDNUMsTUFBSSxPQUFPLE1BQU0sWUFBWSxPQUFPLFNBQVMsQ0FBQyxFQUFHLFFBQU87QUFDeEQsTUFBSSxPQUFPLE1BQU0sWUFBWSxFQUFFLFNBQVMsR0FBRztBQUN6QyxVQUFNLElBQUksT0FBTyxDQUFDO0FBQ2xCLFFBQUksT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQUEsRUFDakM7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxTQUFTLFVBQVUsR0FBb0I7QUFDckMsU0FBTyxVQUFVLENBQUMsS0FBSztBQUN6QjtBQUNBLFNBQVMsSUFBSSxHQUE0QztBQUN2RCxTQUFPLE9BQU8sTUFBTSxZQUFZLE1BQU0sUUFBUSxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQ3pELElBQ0Q7QUFDTjtBQUNBLFNBQVMsUUFBUSxHQUF1QjtBQUN0QyxTQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDO0FBQ2pDO0FBd0JBLFNBQVMsaUJBQ1AsV0FDQSxRQUNBLFVBQ1M7QUFDVCxNQUFJLFVBQVcsUUFBTztBQUN0QixNQUFJLENBQUMsU0FBVSxRQUFPO0FBQ3RCLFFBQU0sV0FBVyxJQUFJLE9BQU8sUUFBUTtBQUNwQyxRQUFNLE9BQU8sV0FBVyxTQUFTLE9BQU87QUFDeEMsTUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQ3ZCLGVBQVcsS0FBSyxNQUFNO0FBQ3BCLFVBQUksT0FBTyxNQUFNLFlBQVksTUFBTSxLQUFNO0FBQ3pDLFlBQU0sTUFBTyxFQUE4QjtBQUkzQyxVQUFJLE9BQU8sUUFBUSxZQUFZLHdCQUF3QixLQUFLLEdBQUcsR0FBRztBQUNoRSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBd0JPLFNBQVMsY0FDZCxRQUNBLFVBQ0EsY0FBbUMsb0JBQUksSUFBSSxHQUN6QjtBQUNsQixNQUFJLFNBQVMsU0FBUyxLQUFLLFlBQVksU0FBUyxFQUFHLFFBQU87QUFLMUQsUUFBTSxnQkFBZ0Isb0JBQUksSUFBWTtBQUN0QyxRQUFNLG1CQUFtQixvQkFBSSxJQUFZO0FBQ3pDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksQ0FBQyxTQUFTLElBQUksRUFBRSxlQUFlLFlBQVksQ0FBQyxFQUFHO0FBQ25ELHFCQUFpQixJQUFJLEVBQUUsUUFBUTtBQUMvQixRQUFJLEVBQUUsZ0JBQWlCLGVBQWMsSUFBSSxFQUFFLGVBQWU7QUFDMUQsUUFBSSxFQUFFLG1CQUFvQixlQUFjLElBQUksRUFBRSxrQkFBa0I7QUFDaEUsUUFBSSxFQUFFLGtCQUFtQixlQUFjLElBQUksRUFBRSxpQkFBaUI7QUFBQSxFQUNoRTtBQUNBLFNBQU8sT0FBTyxPQUFPLENBQUMsTUFBTTtBQUMxQixVQUFNLElBQUksRUFBRSxlQUFlLFlBQVk7QUFDdkMsUUFBSSxTQUFTLElBQUksQ0FBQyxFQUFHLFFBQU87QUFDNUIsUUFBSSxZQUFZLElBQUksQ0FBQyxFQUFHLFFBQU87QUFFL0IsUUFBSSxjQUFjLElBQUksRUFBRSxRQUFRLEVBQUcsUUFBTztBQUkxQyxRQUFJLEVBQUUsbUJBQW1CLGlCQUFpQixJQUFJLEVBQUUsZUFBZSxFQUFHLFFBQU87QUFDekUsUUFBSSxFQUFFLHFCQUFxQixpQkFBaUIsSUFBSSxFQUFFLGlCQUFpQixFQUFHLFFBQU87QUFFN0UsUUFBSSxFQUFFLG9CQUFvQixTQUFTLElBQUksRUFBRSxpQkFBaUIsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUNqRixlQUFXLEtBQUssRUFBRSxVQUFVO0FBQzFCLFVBQUksU0FBUyxJQUFJLEVBQUUsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUFBLElBQzVDO0FBQ0EsV0FBTztBQUFBLEVBQ1QsQ0FBQztBQUNIO0FBU0EsU0FBUyxxQkFDUCxHQUNBLFFBQ0EsWUFDc0I7QUFDdEIsUUFBTSxRQUFRLElBQUksRUFBRSxlQUFlLEtBQUssSUFBSSxPQUFPLGVBQWU7QUFDbEUsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixRQUFNLFdBQVcsSUFBSSxNQUFNLFFBQVE7QUFDbkMsUUFBTSxPQUFPLElBQUksTUFBTSxJQUFJO0FBQzNCLFFBQU0sVUFBVSxVQUFVLFVBQVUsSUFBSTtBQUN4QyxRQUFNLFFBQVEsVUFBVSxNQUFNLEtBQUs7QUFDbkMsUUFBTSxhQUFhLFVBQVUsTUFBTSxVQUFVO0FBQzdDLFFBQU0saUJBQWlCLFVBQVUsTUFBTSxjQUFjO0FBQ3JELFFBQU0sU0FBUyxVQUFVLE1BQU0sTUFBTSxLQUFLLFVBQVUsTUFBTSxPQUFPO0FBRWpFLE1BQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQVEsUUFBTztBQUMxQyxTQUFPO0FBQUEsSUFDTCxTQUFTO0FBQUEsSUFDVDtBQUFBLElBQ0EsYUFBYTtBQUFBLElBQ2I7QUFBQSxJQUNBLGlCQUFpQjtBQUFBLElBQ2pCLGFBQWE7QUFBQSxFQUNmO0FBQ0Y7QUFPQSxTQUFTLG9CQUNQLFlBQ0EsYUFDQSxZQUNBLGVBQ2M7QUFDZCxRQUFNLGVBQWUsSUFBSSxZQUFZLFlBQVk7QUFDakQsU0FBTztBQUFBLElBQ0wsY0FDRSxVQUFVLGFBQWEsSUFBSSxLQUFLLFVBQVUsWUFBWSxJQUFJLEtBQUssVUFBVSxZQUFZLElBQUk7QUFBQSxJQUMzRixZQUNFLFVBQVUsZUFBZSxTQUFTLEtBQ2xDLFVBQVUsWUFBWSx1QkFBdUIsS0FDN0MsVUFBVSxZQUFZLHVCQUF1QjtBQUFBLElBQy9DLFVBQVUsV0FBVyxjQUFjLFFBQVEsS0FBSyxXQUFXLFlBQVksUUFBUTtBQUFBLElBQy9FLGtCQUFrQixXQUFXLFlBQVksZ0JBQWdCO0FBQUEsSUFDekQsZUFBZSxVQUFVLGNBQWMsYUFBYSxLQUFLLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDNUYsYUFBYSxVQUFVLFlBQVksV0FBVztBQUFBLElBQzlDLFVBQVUsVUFBVSxJQUFJLFlBQVksUUFBUSxHQUFHLFFBQVEsS0FBSyxVQUFVLFlBQVksUUFBUTtBQUFBLElBQzFGLEtBQUssVUFBVSxZQUFZLEdBQUc7QUFBQSxJQUM5QixpQkFBaUIsVUFBVSxZQUFZLGVBQWU7QUFBQSxJQUN0RCxlQUFlLFVBQVUsWUFBWSxhQUFhO0FBQUEsSUFDbEQsZ0JBQWdCLFVBQVUsWUFBWSxjQUFjO0FBQUEsSUFDcEQsb0JBQ0UsaUJBQWlCLFVBQVUsYUFBYSxVQUFVLENBQUMsS0FDbkQsaUJBQWlCLFVBQVUsWUFBWSxVQUFVLENBQUM7QUFBQSxJQUNwRCxXQUFXLFdBQVcsWUFBWSxTQUFTO0FBQUEsRUFDN0M7QUFDRjtBQU9BLFNBQVMsWUFBWSxHQUE4QztBQUNqRSxRQUFNLE9BQU8sSUFBSSxFQUFFLElBQUk7QUFDdkIsUUFBTSxhQUFhLElBQUksTUFBTSxNQUFNO0FBQ25DLE1BQUksQ0FBQyxXQUFZLFFBQU87QUFDeEIsUUFBTSxXQUFXLFdBQVc7QUFDNUIsUUFBTSxRQUFpQyxDQUFDO0FBQ3hDLE1BQUksTUFBTSxRQUFRLFFBQVEsR0FBRztBQUMzQixlQUFXLE1BQU0sVUFBVTtBQUN6QixVQUFJLE9BQU8sT0FBTyxZQUFZLE9BQU8sS0FBTTtBQUMzQyxZQUFNLElBQUk7QUFDVixZQUFNLElBQUksVUFBVSxFQUFFLEdBQUc7QUFDekIsWUFBTSxJQUFJLElBQUksRUFBRSxLQUFLO0FBQ3JCLFVBQUksQ0FBQyxLQUFLLENBQUMsRUFBRztBQUNkLFlBQU0sQ0FBQyxJQUNMLFVBQVUsRUFBRSxZQUFZLEtBQ3hCLFVBQVUsSUFBSSxFQUFFLFdBQVcsR0FBRyxHQUFHLEtBQ2pDLFVBQVUsSUFBSSxFQUFFLGlCQUFpQixHQUFHLE9BQU87QUFBQSxJQUMvQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLE9BQU8sVUFBVSxXQUFXLElBQUk7QUFDdEMsUUFBTSxVQUFVLFVBQVUsV0FBVyxHQUFHO0FBQ3hDLFFBQU0sWUFDSixPQUFPLE1BQU0sWUFBWSxNQUFNLFdBQVksTUFBTSxZQUFZLElBQWU7QUFDOUUsUUFBTSxRQUFRLE9BQU8sTUFBTSxPQUFPLE1BQU0sV0FBWSxNQUFNLE9BQU8sSUFBZTtBQUNoRixRQUFNLGNBQ0osT0FBTyxNQUFNLGFBQWEsTUFBTSxXQUFZLE1BQU0sYUFBYSxJQUFlO0FBQ2hGLFFBQU0sWUFDSCxPQUFPLE1BQU0sZ0NBQWdDLE1BQU0sV0FDL0MsTUFBTSxnQ0FBZ0MsSUFDdkMsVUFDSCxPQUFPLE1BQU0sMEJBQTBCLE1BQU0sV0FDekMsTUFBTSwwQkFBMEIsSUFDakMsVUFDSCxPQUFPLE1BQU0sOEJBQThCLE1BQU0sV0FDN0MsTUFBTSw4QkFBOEIsSUFDckM7QUFDTixNQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsU0FBVSxRQUFPO0FBQ3pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQSxVQUFVO0FBQUEsSUFDVixZQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiO0FBQ0Y7OztBQzl6QkEsSUFBTSxXQUFXO0FBRVYsU0FBUyxXQUFtQjtBQUNqQyxRQUFNLEtBQUssS0FBSyxJQUFJO0FBQ3BCLE1BQUksU0FBUztBQUNiLE1BQUksSUFBSTtBQUNSLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLGNBQVUsU0FBUyxJQUFJLEVBQUUsS0FBSyxPQUFPO0FBQ3JDLFFBQUksS0FBSyxNQUFNLElBQUksRUFBRTtBQUFBLEVBQ3ZCO0FBQ0EsUUFBTSxPQUFPLE9BQU8sZ0JBQWdCLElBQUksV0FBVyxFQUFFLENBQUM7QUFDdEQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLEtBQU0sYUFBWSxTQUFTLElBQUksRUFBRSxLQUFLO0FBQ3RELFNBQU8sU0FBUztBQUNsQjtBQUVPLFNBQVMsV0FBVyxJQUFvQjtBQUM3QyxTQUFPLEdBQUcsTUFBTSxFQUFFO0FBQ3BCOzs7QUNQQSxJQUFNLG1CQUFpRCxvQkFBSSxJQUFJO0FBQUEsRUFDN0Q7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVNLFNBQVMsa0JBQWtCLE1BQStCO0FBQy9ELFFBQU0sV0FBNEIsQ0FBQztBQUNuQyxNQUFJLFVBQWtDLENBQUM7QUFDdkMsTUFBSSxhQUFhO0FBQ2pCLFFBQU0sUUFBUSxNQUFNO0FBQ2xCLFFBQUksUUFBUSxVQUFVLFFBQVEsT0FBTztBQUNuQyxVQUFJLENBQUMsUUFBUSxTQUFVLFNBQVEsV0FBVztBQUMxQyxlQUFTLEtBQUssT0FBd0I7QUFBQSxJQUN4QztBQUFBLEVBQ0Y7QUFDQSxhQUFXLFdBQVcsS0FBSyxNQUFNLElBQUksR0FBRztBQUN0QyxVQUFNLE9BQU8sY0FBYyxPQUFPO0FBQ2xDLFFBQUksS0FBSyxLQUFLLE1BQU0sR0FBSTtBQUN4QixRQUFJLGdCQUFnQixLQUFLLElBQUksR0FBRztBQUM5QixtQkFBYTtBQUNiO0FBQUEsSUFDRjtBQUNBLFFBQUksQ0FBQyxXQUFZO0FBRWpCLFVBQU0sWUFBWSxLQUFLLE1BQU0sNEJBQTRCO0FBQ3pELFFBQUksV0FBVztBQUNiLFlBQU07QUFDTixnQkFBVSxFQUFFLFFBQVEsUUFBUSxVQUFVLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDaEQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxhQUFhLEtBQUssTUFBTSx3QkFBd0I7QUFDdEQsUUFBSSxjQUFjLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRztBQUNyQyxZQUFNO0FBQ04sZ0JBQVUsRUFBRSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQ2pEO0FBQUEsSUFDRjtBQUNBLFVBQU0sYUFBYSxLQUFLLE1BQU0sdUJBQXVCO0FBQ3JELFFBQUksY0FBYyxRQUFRLFFBQVE7QUFDaEMsY0FBUSxRQUFRLFFBQVEsV0FBVyxDQUFDLEtBQUssRUFBRTtBQUMzQztBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixLQUFLLE1BQU0sMEJBQTBCO0FBQzNELFFBQUksaUJBQWlCLFFBQVEsUUFBUTtBQUNuQyxZQUFNLE1BQU0sUUFBUSxjQUFjLENBQUMsS0FBSyxFQUFFO0FBQzFDLGNBQVEsV0FBVyxpQkFBaUIsSUFBSSxHQUFzQixJQUN6RCxNQUNEO0FBQ0o7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNBLFFBQU07QUFDTixTQUFPLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUNuRDtBQUVBLFNBQVMsY0FBYyxNQUFzQjtBQUczQyxRQUFNLE1BQU0sS0FBSyxRQUFRLEdBQUc7QUFDNUIsU0FBTyxRQUFRLEtBQUssT0FBTyxLQUFLLE1BQU0sR0FBRyxHQUFHO0FBQzlDO0FBRUEsU0FBUyxRQUFRLEdBQW1CO0FBQ2xDLFFBQU0sVUFBVSxFQUFFLEtBQUs7QUFDdkIsTUFDRyxRQUFRLFdBQVcsR0FBRyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQy9DLFFBQVEsV0FBVyxHQUFHLEtBQUssUUFBUSxTQUFTLEdBQUcsR0FDaEQ7QUFDQSxXQUFPLFFBQVEsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUM1QjtBQUNBLFNBQU87QUFDVDs7O0FDV0EsSUFBTSxjQUFjLFFBQVEsUUFBUSxZQUFZLEVBQUU7QUFDbEQsSUFBTSwyQkFBMkI7QUFDakMsSUFBTSw2QkFBNkI7QUFDbkMsSUFBTSxtQ0FBbUM7QUFDekMsSUFBTSwrQkFBK0IsQ0FBQyxTQUFTLFNBQVMsTUFBTTtBQUM5RCxJQUFNLDJDQUEyQyxDQUFDLFNBQVMsa0JBQWtCLE9BQU87QUFDcEYsSUFBTSxrQ0FBa0M7QUFBQSxFQUN0QztBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNGO0FBQ0EsSUFBSSx1QkFBdUI7QUF3QjNCLGVBQWUsQ0FBQyxPQUFpQjtBQUMvQixVQUFRLFFBQVEsWUFBWSxFQUFFLE1BQU0sYUFBYSxPQUFPLEdBQUcsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUM5RSxDQUFDO0FBRUQsU0FBUywyQkFBaUM7QUFDeEMseUJBQXVCLEtBQUssSUFBSSxJQUFJO0FBQ3RDO0FBSUEsUUFBUSxRQUFRLFlBQVksWUFBWSxZQUFZO0FBQ2xELFFBQU0sS0FBSyx1QkFBdUIsRUFBRSxTQUFTLFlBQVksQ0FBQztBQUMxRCxRQUFNLE9BQU8sU0FBUztBQUN4QixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxNQUFNO0FBQzFDLE9BQUssT0FBTyxTQUFTO0FBQ3ZCLENBQUM7QUFHRCxLQUFLLE9BQU8sYUFBYTtBQUV6QixlQUFlLE9BQU8sUUFBK0I7QUFDbkQsTUFBSTtBQUNGLFVBQU0sYUFBYTtBQUNuQixVQUFNLHNCQUFzQjtBQUM1QixVQUFNLHNCQUFzQixFQUFFLFFBQVEsUUFBUSxNQUFNLElBQUksS0FBSyxNQUFNLENBQUM7QUFDcEUsVUFBTSw0QkFBNEI7QUFDbEMsVUFBTSxxQkFBcUI7QUFHM0IsVUFBTSxTQUFTLE1BQU0sb0JBQW9CLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBSTtBQUNqRSxRQUFJLFNBQVMsRUFBRyxPQUFNLEtBQUssMEJBQTBCLEVBQUUsT0FBTyxDQUFDO0FBQy9ELFVBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBSSxTQUFTLE9BQU8sU0FBUyxTQUFTLFNBQVMsTUFBTTtBQUNuRCxZQUFNLGlCQUFpQixLQUFLO0FBQzVCLFlBQU0sb0JBQW9CLEtBQUs7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTSxjQUFjO0FBQUEsUUFDbEIsUUFBUTtBQUFBLFFBQ1IsT0FBTztBQUFBLFFBQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLE9BQU87QUFBQSxRQUNQLGVBQWU7QUFBQSxRQUNmLHdCQUF3QjtBQUFBLFFBQ3hCLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFDRCxZQUFNLEtBQUssd0NBQXdDLEVBQUUsT0FBTyxDQUFDO0FBQUEsSUFDL0Q7QUFBQSxFQUNGLFNBQVMsS0FBSztBQUNaLFVBQU0sTUFBTyxlQUFlLEVBQUUsUUFBUSxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFBQSxFQUMvRDtBQUNGO0FBRUEsU0FBUyxTQUEwQztBQUNqRCxRQUFNLGVBQWU7QUFHckIsU0FBTyxhQUFhLHlCQUF5QjtBQUMvQztBQUVBLGVBQWUsaUJBQW9DO0FBQ2pELFFBQU0sT0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQzNGLFNBQU8sS0FBSyxRQUFRLENBQUMsUUFBUyxPQUFPLElBQUksT0FBTyxXQUFXLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFFO0FBQzNFO0FBRUEsZUFBZSxzQkFBc0I7QUFBQSxFQUNuQztBQUFBLEVBQ0E7QUFDRixHQUdrQjtBQUNoQixRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sTUFBTSxPQUFPO0FBQ25CLE1BQUksQ0FBQyxLQUFLO0FBQ1IsUUFBSSxTQUFTLHdCQUF3QixLQUFLO0FBQ3hDLFlBQU0sS0FBSyx5RUFBeUU7QUFBQSxRQUNsRjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFDQTtBQUFBLEVBQ0Y7QUFFQSxRQUFNLFNBQVMsU0FBUyx1QkFBdUIsTUFBTSxlQUFlLElBQUksQ0FBQztBQUN6RSxRQUFNLGdCQUFnQjtBQUFBLElBQ3BCO0FBQUEsSUFDQSxHQUFHLGdDQUFnQyxJQUFJLENBQUMsR0FBRyxRQUFRLG1DQUFtQyxHQUFHO0FBQUEsRUFDM0Y7QUFDQSxRQUFNLFdBQ0osT0FBTyxTQUFTLElBQ1o7QUFBQSxJQUNFO0FBQUEsTUFDRSxJQUFJO0FBQUEsTUFDSixVQUFVO0FBQUEsTUFDVixRQUFRLEVBQUUsTUFBTSxRQUFRO0FBQUEsTUFDeEIsV0FBVztBQUFBLFFBQ1Q7QUFBQSxRQUNBLGVBQWUsQ0FBQyxHQUFHLDRCQUE0QjtBQUFBLE1BQ2pEO0FBQUEsSUFDRjtBQUFBLElBQ0EsR0FBRyxnQ0FBZ0MsSUFBSSxDQUFDLFdBQVcsU0FBUztBQUFBLE1BQzFELElBQUksbUNBQW1DO0FBQUEsTUFDdkMsVUFBVTtBQUFBLE1BQ1YsUUFBUSxFQUFFLE1BQU0sUUFBaUI7QUFBQSxNQUNqQyxXQUFXO0FBQUEsUUFDVDtBQUFBLFFBQ0E7QUFBQSxRQUNBLGVBQWUsQ0FBQyxHQUFHLHdDQUF3QztBQUFBLE1BQzdEO0FBQUEsSUFDRixFQUFFO0FBQUEsRUFDSixJQUNBLENBQUM7QUFDUCxRQUFNLElBQUksbUJBQW1CO0FBQUEsSUFDM0I7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBRUQsTUFBSSxLQUFLO0FBQ1AsVUFBTSxLQUFLLHdDQUF3QztBQUFBLE1BQ2pELFNBQVMsU0FBUztBQUFBLE1BQ2xCLFdBQVcsT0FBTztBQUFBLE1BQ2xCLHdCQUF3Qiw2QkFBNkIsS0FBSyxHQUFHO0FBQUEsTUFDN0QsdUJBQXVCLGdDQUFnQyxLQUFLLEdBQUc7QUFBQSxNQUMvRDtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQUVBLFFBQVEsS0FBSyxVQUFVLFlBQVksQ0FBQyxRQUFRLGVBQWU7QUFDekQsTUFBSSxXQUFXLE9BQU8sV0FBVyxXQUFXLFlBQVk7QUFDdEQsU0FBSyxzQkFBc0IsRUFBRSxRQUFRLGVBQWUsS0FBSyxNQUFNLENBQUMsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUMvRSxXQUFLLEtBQUsscUNBQXFDLGNBQWMsR0FBRyxDQUFDO0FBQUEsSUFDbkUsQ0FBQztBQUFBLEVBQ0g7QUFDRixDQUFDO0FBRUQsUUFBUSxLQUFLLFVBQVUsWUFBWSxNQUFNO0FBQ3ZDLE9BQUssc0JBQXNCLEVBQUUsUUFBUSxlQUFlLEtBQUssTUFBTSxDQUFDLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDL0UsU0FBSyxLQUFLLHFDQUFxQyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ25FLENBQUM7QUFDSCxDQUFDO0FBWUQsZUFBZSx1QkFBc0M7QUFDbkQsTUFBSTtBQUNKLE1BQUk7QUFDRixXQUFPLE1BQU0sUUFBUSxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUMsbUJBQW1CLHVCQUF1QixFQUFFLENBQUM7QUFBQSxFQUN2RixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssNkJBQTZCLGNBQWMsR0FBRyxDQUFDO0FBQzFEO0FBQUEsRUFDRjtBQUNBLE1BQUksS0FBSyxXQUFXLEVBQUc7QUFDdkIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxPQUFPLElBQUksT0FBTyxTQUFVO0FBQ2hDLFFBQUk7QUFDRixZQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsUUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsUUFDeEIsT0FBTyxDQUFDLGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl0QixPQUFPO0FBQUEsTUFDVCxDQUFDO0FBQ0QsWUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLFFBQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLFFBQ3hCLE9BQU8sQ0FBQyxZQUFZO0FBQUEsTUFDdEIsQ0FBQztBQUNELFlBQU0sS0FBSyxxQ0FBcUM7QUFBQSxRQUM5QyxPQUFPLElBQUk7QUFBQSxRQUNYLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRTtBQUFBLE1BQy9CLENBQUM7QUFBQSxJQUNILFNBQVMsS0FBSztBQUlaLFlBQU0sS0FBSyx3Q0FBd0M7QUFBQSxRQUNqRCxPQUFPLElBQUk7QUFBQSxRQUNYLEtBQUssV0FBVyxJQUFJLE9BQU8sRUFBRTtBQUFBLFFBQzdCLEdBQUcsY0FBYyxHQUFHO0FBQUEsTUFDdEIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLFFBQU0sUUFBUSxPQUFPLE1BQU0sYUFBYTtBQUN4QyxRQUFNLFFBQVEsT0FBTyxNQUFNLG1CQUFtQjtBQUM5QyxRQUFNLFFBQVEsT0FBTyxPQUFPLGVBQWUsRUFBRSxpQkFBaUIsb0JBQW9CLENBQUM7QUFDbkYsUUFBTSxRQUFRLE9BQU8sT0FBTyxxQkFBcUI7QUFBQSxJQUMvQyxpQkFBaUIsZ0NBQWdDO0FBQUEsRUFDbkQsQ0FBQztBQUNIO0FBTUEsSUFBSSxrQkFBeUQ7QUFDN0QsSUFBTSw2QkFBNkIsS0FBSyxLQUFLO0FBTTdDLElBQU0sOEJBQThCLG9CQUFJLElBQStCO0FBS3ZFLElBQU0saUJBQWlCO0FBRXZCLGVBQWUsd0JBQXVDO0FBRXBELFFBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLE1BQUksU0FBUyxRQUFRLEVBQUUsWUFBWSxPQUFPO0FBQ3hDLHVCQUFtQixFQUFFLHFCQUFxQjtBQUFBLEVBQzVDLE9BQU87QUFDTCx5QkFBcUI7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyx1QkFBNkI7QUFDcEMsTUFBSSxvQkFBb0IsTUFBTTtBQUM1QixrQkFBYyxlQUFlO0FBQzdCLHNCQUFrQjtBQUFBLEVBQ3BCO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixhQUEyQjtBQUNyRCx1QkFBcUI7QUFDckIsUUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNuQjtBQUFBLElBQ0EsS0FBSyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sV0FBVyxDQUFDO0FBQUEsRUFDdkQ7QUFDQSxvQkFBa0IsWUFBWSxNQUFNO0FBQ2xDLFNBQUssZUFBZSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ25DLFdBQUssS0FBSywyQkFBMkIsY0FBYyxHQUFHLENBQUM7QUFBQSxJQUN6RCxDQUFDO0FBQUEsRUFDSCxHQUFHLFVBQVUsR0FBSTtBQUNuQjtBQUVBLGVBQWUsc0JBQXFDO0FBQ2xELDJCQUF5QjtBQUN6QixRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLGFBQWE7QUFBQSxJQUNiLGVBQWU7QUFBQSxJQUNmLGtCQUFrQjtBQUFBLElBQ2xCLHVCQUF1QjtBQUFBLElBQ3ZCLGlCQUFpQjtBQUFBLElBQ2pCLGVBQWU7QUFBQSxFQUNqQixDQUFDO0FBQ0QscUJBQW1CLEVBQUUscUJBQXFCO0FBQzFDLFFBQU0sS0FBSyw0QkFBNEIsRUFBRSxjQUFjLEVBQUUsc0JBQXNCLENBQUM7QUFFaEYsT0FBSyxlQUFlO0FBQ3BCLFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHVCQUFxQjtBQUNyQixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxNQUFNLGVBQWU7QUFBQSxJQUM5QixVQUFVLE1BQU0saUJBQWlCO0FBQUEsSUFDakMsVUFBVSxNQUFNLGlCQUFpQjtBQUFBLEVBQ25DLENBQUM7QUFDRCxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLGlCQUFnQztBQUM3QyxNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLEtBQUssQ0FBQyxtQkFBbUIsdUJBQXVCLEVBQUUsQ0FBQztBQUFBLEVBQ3ZGLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpQ0FBaUMsY0FBYyxHQUFHLENBQUM7QUFDOUQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxLQUFLLFdBQVcsRUFBRztBQUN2QixNQUFJLGNBQWM7QUFDbEIsTUFBSSxhQUFhO0FBQ2pCLGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksT0FBTyxJQUFJLE9BQU8sU0FBVTtBQUNoQyxRQUFJLElBQUksVUFBVztBQUNuQixRQUFJO0FBQ0YsWUFBTSxVQUFXLE1BQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxRQUNyRCxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxRQUN4QixPQUFPO0FBQUEsUUFDUCxNQUFPLE1BQU07QUFDWCxnQkFBTSxpQkFBaUIsQ0FBQyxPQUN0QixHQUFHLEdBQUcsZUFBZSxFQUFFLElBQUksR0FBRyxhQUFhLFlBQVksS0FBSyxFQUFFLEdBQzNELFFBQVEsUUFBUSxHQUFHLEVBQ25CLEtBQUssRUFDTCxZQUFZO0FBQ2pCLGdCQUFNLDBCQUEwQixNQUFlO0FBQzdDLGtCQUFNLFlBQVksU0FBUyxNQUFNLGFBQWEsSUFBSSxZQUFZO0FBQzlELGdCQUNFLENBQUMsU0FBUyxTQUFTLHNCQUFzQixLQUN6QyxDQUFDLFNBQVMsU0FBUyxlQUFlLEdBQ2xDO0FBQ0EscUJBQU87QUFBQSxZQUNUO0FBQ0Esa0JBQU0sV0FBVyxNQUFNO0FBQUEsY0FDckIsU0FBUyxpQkFBaUIsZ0NBQWdDO0FBQUEsWUFDNUQ7QUFDQSxrQkFBTSxRQUFRLFNBQVMsS0FBSyxDQUFDLE9BQU87QUFDbEMsb0JBQU0sT0FBTyxlQUFlLEVBQUU7QUFDOUIscUJBQU8sU0FBUyxXQUFXLEtBQUssU0FBUyxPQUFPLEtBQUssS0FBSyxTQUFTLFdBQVc7QUFBQSxZQUNoRixDQUFDO0FBQ0QsZ0JBQUksQ0FBQyxNQUFPLFFBQU87QUFDbkIsWUFBQyxNQUFzQixNQUFNO0FBQzdCLG1CQUFPO0FBQUEsVUFDVDtBQUNBLGNBQUksd0JBQXdCLEVBQUcsUUFBTyxFQUFFLFNBQVMsTUFBTSxVQUFVLE1BQU07QUFJdkUsZ0JBQU0sT0FBMEI7QUFBQSxZQUM5QixLQUFLO0FBQUEsWUFDTCxNQUFNO0FBQUEsWUFDTixTQUFTO0FBQUEsWUFDVCxPQUFPO0FBQUEsWUFDUCxTQUFTO0FBQUEsWUFDVCxZQUFZO0FBQUEsVUFDZDtBQUNBLGdCQUFNLFFBQVMsU0FBUyxpQkFBd0MsU0FBUztBQUN6RSxnQkFBTSxjQUFjLElBQUksY0FBYyxXQUFXLElBQUksQ0FBQztBQUN0RCxnQkFBTSxjQUFjLElBQUksY0FBYyxTQUFTLElBQUksQ0FBQztBQUNwRCxpQkFBTyxTQUFTO0FBQUEsWUFDZCxLQUFLLFNBQVMsZ0JBQWdCO0FBQUEsWUFDOUIsVUFBVTtBQUFBLFVBQ1osQ0FBQztBQUNELGlCQUFPLEVBQUUsU0FBUyxPQUFPLFVBQVUsS0FBSztBQUFBLFFBQzFDO0FBQUEsTUFDRixDQUFDO0FBQ0QsWUFBTSxjQUFjLFFBQ2pCLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUNuQjtBQUFBLFFBQ0MsQ0FBQyxXQUNDLE9BQU8sV0FBVyxZQUFZLFdBQVc7QUFBQSxNQUM3QztBQUNGLFVBQUksWUFBWSxLQUFLLENBQUMsV0FBVyxPQUFPLFlBQVksSUFBSSxHQUFHO0FBQ3pELHNCQUFjO0FBQUEsTUFDaEI7QUFDQSxVQUFJLFlBQVksS0FBSyxDQUFDLFdBQVcsT0FBTyxhQUFhLElBQUksR0FBRztBQUMxRCx1QkFBZTtBQUFBLE1BQ2pCO0FBQUEsSUFDRixRQUFRO0FBQUEsSUFHUjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLGFBQWEsR0FBRztBQUNsQixVQUFNLEtBQUssdUNBQXVDLEVBQUUsV0FBVyxXQUFXLENBQUM7QUFBQSxFQUM3RTtBQUNBLE1BQUksY0FBYyxHQUFHO0FBQ25CLFVBQU0sT0FBTyxNQUFNLHFCQUFxQjtBQUN4QyxRQUFJLFNBQVMsTUFBTTtBQUNqQixXQUFLLGVBQWU7QUFDcEIsWUFBTSxxQkFBcUIsSUFBSTtBQUFBLElBRWpDO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyx5QkFBK0I7QUFDdEMsUUFBTSxTQUFTLEtBQUssSUFBSSxJQUFJO0FBQzVCLGFBQVcsQ0FBQyxPQUFPLEtBQUssS0FBSyw2QkFBNkI7QUFDeEQsUUFBSSxNQUFNLFlBQVksT0FBUSw2QkFBNEIsT0FBTyxLQUFLO0FBQUEsRUFDeEU7QUFDRjtBQUVBLFNBQVMsK0JBQ1AsT0FDQSxTQUNBLFFBQ0EsYUFDTTtBQUNOLE1BQUksVUFBVSxRQUFRLE9BQU8sV0FBVyxLQUFLLFlBQVksU0FBUyxFQUFHO0FBQ3JFLFFBQU0sZUFBZSxvQkFBSSxJQUFZO0FBQ3JDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksWUFBWSxJQUFJLEVBQUUsZUFBZSxZQUFZLENBQUMsRUFBRyxjQUFhLElBQUksRUFBRSxRQUFRO0FBQUEsRUFDbEY7QUFDQSxRQUFNLFdBQVcsNEJBQTRCLElBQUksS0FBSztBQUN0RCxRQUFNLFdBQVcsVUFBVSxZQUFZLG9CQUFJLElBQVk7QUFDdkQsYUFBVyxLQUFLLFFBQVE7QUFDdEIsVUFBTSxTQUFTLEVBQUUsZUFBZSxZQUFZO0FBQzVDLFVBQU0sY0FBYyxFQUFFLGtCQUFrQixZQUFZLEtBQUs7QUFDekQsUUFDRSxZQUFZLElBQUksTUFBTSxLQUNyQixnQkFBZ0IsUUFBUSxZQUFZLElBQUksV0FBVyxLQUNuRCxFQUFFLHNCQUFzQixRQUFRLGFBQWEsSUFBSSxFQUFFLGlCQUFpQixLQUNwRSxFQUFFLG9CQUFvQixRQUFRLGFBQWEsSUFBSSxFQUFFLGVBQWUsS0FDaEUsRUFBRSx1QkFBdUIsUUFBUSxhQUFhLElBQUksRUFBRSxrQkFBa0IsR0FDdkU7QUFDQSxlQUFTLElBQUksRUFBRSxRQUFRO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBQ0EsOEJBQTRCLElBQUksT0FBTztBQUFBLElBQ3JDLFdBQVcsS0FBSyxJQUFJO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFFQSxRQUFRLE9BQU8sUUFBUSxZQUFZLENBQUMsVUFBVTtBQUM1QyxNQUFJLE1BQU0sU0FBUyxlQUFlO0FBQ2hDLFNBQUssaUJBQWlCO0FBQUEsRUFDeEIsV0FBVyxNQUFNLFNBQVMscUJBQXFCO0FBQzdDLFNBQUssaUJBQWlCLEtBQUs7QUFBQSxFQUM3QjtBQUlGLENBQUM7QUFJRCxJQUFJLFFBQVEsUUFBUSxXQUFXO0FBQzdCLFVBQVEsT0FBTyxVQUFVLFlBQVksT0FBTyxRQUFRO0FBQ2xELFFBQUk7QUFDRixZQUFNLGdCQUFpQixRQUVwQjtBQUNILFVBQUksZUFBZSxRQUFRO0FBQ3pCLGNBQU0sY0FBYyxPQUFPO0FBQzNCO0FBQUEsTUFDRjtBQUVBLFlBQU0sWUFBYSxRQUVoQjtBQUNILFVBQUksV0FBVyxNQUFNO0FBQ25CLGNBQU0sVUFBaUMsQ0FBQztBQUN4QyxZQUFJLE9BQU8sSUFBSSxhQUFhLFNBQVUsU0FBUSxXQUFXLElBQUk7QUFDN0QsY0FBTSxVQUFVLEtBQUssT0FBTztBQUM1QjtBQUFBLE1BQ0Y7QUFFQSxZQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLFFBQVEsT0FBTyxjQUFjLEVBQUUsQ0FBQztBQUFBLElBQzNFLFNBQVMsS0FBSztBQUdaLFlBQU0sS0FBSyw0Q0FBNEMsY0FBYyxHQUFHLENBQUM7QUFDekUsVUFBSTtBQUNGLGNBQU0sUUFBUSxLQUFLLE9BQU8sRUFBRSxLQUFLLFFBQVEsUUFBUSxPQUFPLGNBQWMsRUFBRSxDQUFDO0FBQ3pFO0FBQUEsTUFDRixTQUFTLFFBQVE7QUFDZixjQUFNLEtBQUssdUNBQXVDLGNBQWMsTUFBTSxDQUFDO0FBQUEsTUFDekU7QUFDQSxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFBQSxJQUN4QztBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBSUEsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLEtBQWMsV0FBVztBQUM5RCxNQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRyxRQUFPO0FBQ25DLFNBQU8sY0FBYyxLQUFLLE1BQU0sRUFBRSxNQUFNLENBQUMsUUFBUTtBQUMvQyxTQUFLLE1BQU8sMEJBQTBCLEVBQUUsTUFBTSxJQUFJLE1BQU0sR0FBRyxjQUFjLEdBQUcsRUFBRSxDQUFDO0FBQy9FLFVBQU07QUFBQSxFQUNSLENBQUM7QUFDSCxDQUFDO0FBRUQsU0FBUyxpQkFBaUIsR0FBaUM7QUFDekQsU0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFBWSxPQUFRLEVBQXlCLFNBQVM7QUFDbkY7QUFJQSxJQUFNLDRCQUE0QixvQkFBSSxJQUE0QjtBQUFBLEVBQ2hFO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQ0YsQ0FBQztBQUVELGVBQWUsWUFBOEI7QUFDM0MsUUFBTSxJQUFJLE1BQU0sWUFBWTtBQUM1QixTQUFPLEVBQUUsWUFBWTtBQUN2QjtBQUVBLGVBQWUsY0FDYixLQUNBLFFBQ2tCO0FBS2xCLE1BQUksQ0FBRSxNQUFNLFVBQVUsS0FBTSwwQkFBMEIsSUFBSSxJQUFJLElBQUksR0FBRztBQUNuRSxXQUFPLEVBQUUsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUFBLEVBQ2xDO0FBQ0EsVUFBUSxJQUFJLE1BQU07QUFBQSxJQUNoQixLQUFLO0FBQ0gsWUFBTTtBQUFBLFFBQ0osSUFBSTtBQUFBLFFBQ0osSUFBSTtBQUFBLFFBQ0osSUFBSSxXQUFXO0FBQUEsUUFDZixJQUFJO0FBQUEsUUFDSixRQUFRLEtBQUssTUFBTTtBQUFBLE1BQ3JCO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssZ0NBQWdDLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdkUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLEtBQUssK0JBQStCLEVBQUUsS0FBSyxXQUFXLElBQUksR0FBRyxFQUFFLENBQUM7QUFDdEUsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxVQUFJLElBQUksVUFBVSxRQUFRO0FBQ3hCLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xELFdBQVcsSUFBSSxVQUFVLFNBQVM7QUFDaEMsY0FBTSxNQUFPLElBQUksS0FBSyxFQUFFLEtBQUssV0FBVyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDcEQsT0FBTztBQUNMLGNBQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUFBLE1BQ2xEO0FBQ0EsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssc0JBQXNCO0FBQ3pCLFlBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsVUFBSSxTQUFTLFlBQVksT0FBTztBQUM5QixlQUFPLEVBQUUsU0FBUyxPQUFPLGFBQWEsQ0FBQyxHQUFHLGtCQUFrQixDQUFDLEVBQUU7QUFBQSxNQUNqRTtBQUNBLDZCQUF1QjtBQUN2QixZQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFlBQU0sY0FBYyxTQUNqQixPQUFPLENBQUMsTUFBTSxFQUFFLGFBQWEsTUFBTSxFQUNuQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDO0FBQ3BDLFlBQU0sUUFBUSxRQUFRLEtBQUssTUFBTTtBQUNqQyxhQUFPO0FBQUEsUUFDTCxTQUFTO0FBQUEsUUFDVDtBQUFBLFFBQ0Esa0JBQ0UsVUFBVSxPQUFPLENBQUMsSUFBSSxNQUFNLEtBQUssNEJBQTRCLElBQUksS0FBSyxHQUFHLFlBQVksQ0FBQyxDQUFDO0FBQUEsTUFDM0Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLHNCQUFzQjtBQUN6QixVQUFJLElBQUksUUFBUSxHQUFHO0FBQ2pCLGNBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxZQUFJLFdBQVcsTUFBTTtBQUNuQixpQkFBTyxpQkFBaUIsSUFBSTtBQUM1QixnQkFBTSxxQkFBcUIsTUFBTTtBQUFBLFFBQ25DO0FBQUEsTUFDRjtBQUNBLGFBQU8sRUFBRSxJQUFJLEtBQUs7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFdBQVcsSUFBSSxNQUFNO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFdBQVc7QUFDakIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZ0JBQWdCO0FBQ3RCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFNBQVMsTUFBTTtBQUNyQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxZQUFZLElBQUksUUFBUSxNQUFNO0FBQ3BDLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGVBQWUsRUFBRSxhQUFhLElBQUksR0FBRyxDQUFDO0FBQzVDLFlBQU0sS0FBSyx3QkFBd0IsRUFBRSxJQUFJLElBQUksR0FBRyxDQUFDO0FBQ2pELGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsSUFBSSxHQUFHLENBQUM7QUFDL0MsWUFBTSxLQUFLLDJCQUEyQixFQUFFLElBQUksSUFBSSxHQUFHLENBQUM7QUFDcEQsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sZUFBZSxFQUFFLHNCQUFzQixJQUFJLEdBQUcsQ0FBQztBQUNyRCxZQUFNLHNCQUFzQixFQUFFLFFBQVEsVUFBVSxLQUFLLEtBQUssQ0FBQztBQUMzRCxhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLGtCQUFrQjtBQUNyQixZQUFNLElBQUksTUFBTSxlQUFlLEVBQUUsU0FBUyxJQUFJLEdBQUcsQ0FBQztBQUNsRCxVQUFJLENBQUMsSUFBSSxJQUFJO0FBR1gsNkJBQXFCO0FBQ3JCLDRCQUFvQjtBQUNwQiwrQkFBdUI7QUFDdkIsK0JBQXVCO0FBQ3ZCLGNBQU0sUUFBUSxPQUFPLE1BQU0sY0FBYztBQUN6QyxjQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUM3QyxjQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUFBLE1BQy9DLE9BQU87QUFFTCxjQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsWUFBSSxTQUFTLEtBQU0sb0JBQW1CLEVBQUUscUJBQXFCO0FBQUEsTUFDL0Q7QUFDQSxZQUFNLEtBQUssbUNBQW1DLEVBQUUsSUFBSSxJQUFJLEdBQUcsQ0FBQztBQUM1RCxhQUFPLFdBQVc7QUFBQSxJQUNwQjtBQUFBLElBQ0EsS0FBSztBQUNILFlBQU0sb0JBQW9CO0FBQzFCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLHFCQUFxQjtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLLDRCQUE0QjtBQUMvQixZQUFNLFVBQVUsS0FBSztBQUFBLFFBQ25CO0FBQUEsUUFDQSxLQUFLLElBQUkscUJBQXFCLEtBQUssTUFBTSxJQUFJLE9BQU8sQ0FBQztBQUFBLE1BQ3ZEO0FBQ0EsWUFBTSxlQUFlLEVBQUUsdUJBQXVCLFFBQVEsQ0FBQztBQUV2RCxZQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsVUFBSSxTQUFTLEtBQU0sb0JBQW1CLE9BQU87QUFDN0MsVUFBSSwwQkFBMEIsS0FBTSxzQkFBcUIsT0FBTztBQUNoRSxVQUFJLDZCQUE2QixLQUFNLHlCQUF3QixPQUFPO0FBQ3RFLFVBQUksNkJBQTZCLEtBQU0seUJBQXdCLE9BQU87QUFDdEUsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLGlCQUFpQjtBQUN2QixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxrQkFBa0I7QUFDeEIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0sb0JBQW9CO0FBQzFCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLHFCQUFxQjtBQUMzQixhQUFPLFdBQVc7QUFBQSxJQUNwQixLQUFLO0FBQ0gsWUFBTSxvQkFBb0I7QUFDMUIsYUFBTyxXQUFXO0FBQUEsSUFDcEIsS0FBSztBQUNILFlBQU0scUJBQXFCO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUssbUJBQW1CO0FBQ3RCLFlBQU0sT0FBTyxNQUFNLFlBQVk7QUFDL0IsWUFBTSxVQUFVLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxZQUFZLENBQUMsQ0FBQztBQUMvRCxZQUFNLFVBQVUsTUFBTSxvQkFBb0IsT0FBTztBQUNqRCxZQUFNLEtBQUssMEJBQTBCLE9BQU87QUFDNUMsYUFBTyxXQUFXO0FBQUEsSUFDcEI7QUFBQSxJQUNBLEtBQUs7QUFDSCxZQUFNLG9CQUFvQixJQUFJO0FBQzlCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGlCQUFpQixJQUFJO0FBQzNCLGFBQU8sV0FBVztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLGNBQWM7QUFDcEIsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUs7QUFDSCxZQUFNLFFBQVEsUUFBUSxnQkFBZ0I7QUFDdEMsYUFBTyxFQUFFLElBQUksS0FBSztBQUFBLElBQ3BCLEtBQUssZUFBZTtBQUNsQixZQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFlBQU0sTUFBTSxVQUFVLENBQUM7QUFDdkIsWUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLElBQUksQ0FBQztBQUNqQyxhQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxJQUNBO0FBQ0UsYUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLHVCQUF1QjtBQUFBLEVBQ3REO0FBQ0Y7QUFJQSxlQUFlLGlCQUNiLFVBQ0EsS0FDQSxTQUNBLFVBQ0EsYUFDZTtBQUNmLE1BQUksa0JBQWtCLElBQUksUUFBUSxFQUFHO0FBQ3JDLE1BQUksQ0FBQyxnQkFBZ0IsSUFBSSxRQUFRLEVBQUc7QUFFcEMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLFNBQVMsWUFBWSxNQUFPO0FBQ2hDLE1BQUksU0FBUyxnQkFBZ0IsT0FBTztBQUNsQyxVQUFNLHdCQUNKLEtBQUssSUFBSSxJQUFJLHdCQUNaLE1BQU0scUJBQXFCLE1BQU8sUUFDbEMsTUFBTSxrQkFBa0IsTUFBTyxRQUMvQixNQUFNLHFCQUFxQixNQUFPO0FBQ3JDLFFBQUksQ0FBQyxzQkFBdUI7QUFBQSxFQUM5QjtBQUVBLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFnQm5DLFFBQU0sVUFBVSxJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDLENBQUM7QUFDbkUsUUFBTSxPQUFPLElBQUk7QUFBQSxJQUNmLFNBQVMsT0FBTyxDQUFDLE1BQU0sRUFBRSxhQUFhLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sWUFBWSxDQUFDO0FBQUEsRUFDakY7QUFDQSxRQUFNLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFFMUMsTUFBSTtBQUNKLE1BQUk7QUFDRixpQkFBYSxVQUFVLFVBQVU7QUFBQSxNQUMvQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1A7QUFBQSxNQUNBLGdCQUFnQixvQkFBSSxJQUFZO0FBQUEsTUFDaEMsV0FBVztBQUFBLElBQ2IsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxXQUFXLG1CQUFtQixVQUFVLEtBQUssVUFBVSxHQUFHO0FBQ2hFO0FBQUEsRUFDRjtBQUNBLFFBQU0sZUFBZTtBQUFBLElBQ25CLFdBQVc7QUFBQSxJQUNYO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiO0FBUUEsUUFBTSxlQUFlLFdBQVcsT0FBTztBQUN2QyxhQUFXLFNBQVMsY0FBYyxXQUFXLFFBQVEsU0FBUyxJQUFJO0FBQ2xFLFFBQU0sbUJBQW1CLGVBQWUsV0FBVyxPQUFPO0FBQzFELE1BQUksbUJBQW1CLEdBQUc7QUFDeEIsVUFBTSxLQUFLLDRCQUE0QjtBQUFBLE1BQ3JDO0FBQUEsTUFDQSxTQUFTO0FBQUEsTUFDVCxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBQ0EsaUNBQStCLGFBQWEsU0FBUyxXQUFXLFFBQVEsSUFBSTtBQU81RSxNQUFJLFdBQVcsYUFBYSxXQUFXLEdBQUc7QUFDeEMsVUFBTSxLQUFLLDRDQUF1QztBQUFBLE1BQ2hEO0FBQUEsTUFDQSxXQUFXLGVBQWUsUUFBUSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsTUFDL0MsWUFBWSxvQkFBb0IsVUFBVSxPQUFPO0FBQUEsTUFDakQsaUJBQWlCLGlCQUFpQixVQUFVLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFBQSxNQUM3RCxtQkFBbUIsaUJBQWlCLFVBQVUsU0FBUyxDQUFDLFFBQVEsQ0FBQztBQUFBLE1BQ2pFLDBCQUEwQixpQkFBaUIsVUFBVSxTQUFTO0FBQUEsUUFDNUQ7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLE1BQ0QsK0JBQStCLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUNqRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLE1BQ0QsaUNBQWlDLGlCQUFpQixVQUFVLFNBQVM7QUFBQSxRQUNuRTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0gsT0FBTztBQUNMLFVBQU0sS0FBSyx3QkFBd0I7QUFBQSxNQUNqQztBQUFBLE1BQ0EsVUFBVSxXQUFXLGFBQWE7QUFBQSxNQUNsQyxNQUFNLFdBQVcsT0FBTztBQUFBLElBQzFCLENBQUM7QUFBQSxFQUNIO0FBRUEsTUFBSSxXQUFXLG1CQUFtQixTQUFTLEdBQUc7QUFDNUMsVUFBTTtBQUFBLE1BQ0osV0FBVztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLE1BQUksV0FBVyxPQUFPLFdBQVcsR0FBRztBQUNsQyxVQUFNLGdCQUFnQixNQUFNO0FBQUEsTUFDMUI7QUFBQSxNQUNBO0FBQUEsTUFDQSxXQUFXO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFDQSxRQUFJLGdCQUFnQixFQUFHLE9BQU0sZUFBZTtBQUM1QztBQUFBLEVBQ0Y7QUFXQSxRQUFNLGNBQWMsTUFBTSxrQkFBa0I7QUFDNUMsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsUUFBTSxpQkFBaUIsTUFBTSxxQkFBcUI7QUFDbEQsYUFBVyxLQUFLLFdBQVcsUUFBUTtBQUNqQyxRQUFJLEVBQUUsY0FBYztBQUNsQixZQUFNLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxRQUFRO0FBQUEsSUFDbkQsT0FBTztBQUNMLFlBQU0sZUFBZSxFQUFFLGdCQUFnQixFQUFFLFFBQVE7QUFBQSxJQUNuRDtBQUdBLFVBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxRQUFJLGFBQWEsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNqRCxrQkFBWSxXQUFXO0FBQ3ZCLGtCQUFZLGFBQWE7QUFDekIsWUFBTSxrQkFBa0IsV0FBVztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxtQkFBbUIsRUFBRSxRQUFRO0FBQ25DLFlBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxZQUFNLHFCQUFxQixjQUFjO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBS0EsYUFBVyxXQUFXLFdBQVcsYUFBYTtBQUM1QyxRQUFJLE1BQU0sWUFBWSxRQUFRLFFBQVEsRUFBRztBQUN6QyxVQUFNLGtCQUFrQixRQUFRLGFBQWEsUUFBUSxRQUFRO0FBQUEsRUFDL0Q7QUFDQSxNQUFJLFdBQVcsWUFBWSxTQUFTLEdBQUc7QUFDckMsVUFBTSxLQUFLLDBDQUEwQztBQUFBLE1BQ25EO0FBQUEsTUFDQSxTQUFTLFdBQVcsWUFBWTtBQUFBLE1BQ2hDLGFBQWEsTUFBTSxxQkFBcUI7QUFBQSxJQUMxQyxDQUFDO0FBQUEsRUFDSDtBQWdCQSxRQUFNLGlCQUFpQixTQUFTLG1CQUFtQjtBQUNuRCxRQUFNLGVBQWUsTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxrQkFBa0IsTUFBTSxtQkFBbUI7QUFDakQsTUFBSSxpQkFBaUI7QUFDckIsTUFBSSx1QkFBdUI7QUFDM0IsTUFBSSwwQkFBMEI7QUFDOUIsTUFBSSxrQkFBa0I7QUFDdEIsTUFBSSxtQkFBbUI7QUFDdkIsUUFBTSxhQUF1QyxDQUFDO0FBQzlDLFFBQU0sZ0JBQWdCLG9CQUFJLElBQWdDO0FBQzFELFFBQU0sYUFBYSxvQkFBSSxJQUFxQztBQUM1RCxhQUFXLEtBQUssV0FBVyxRQUFRO0FBQ2pDLFVBQU0sT0FBTyxhQUFhLEVBQUUsY0FBYyxJQUFJLEVBQUUsUUFBUTtBQUN4RCxVQUFNLGdCQUFnQixDQUFDLFFBQVEsd0JBQXdCLEdBQUcsZUFBZTtBQUN6RSxVQUFNLHFCQUFxQixRQUFRLElBQUksS0FBSztBQUM1QyxrQkFBYyxJQUFJLEVBQUUsVUFBVSxxQkFBcUIsYUFBYSxLQUFLO0FBQ3JFLFFBQUksY0FBZSxvQkFBbUI7QUFDdEMsVUFBTSxNQUFNO0FBQUEsTUFDVixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsTUFDRixFQUFFO0FBQUEsSUFDSjtBQUNBLFVBQU0sa0JBQWtCLFNBQVMsVUFBYSxrQkFBa0IsS0FBSyxHQUFHLEtBQUssQ0FBQyxFQUFFO0FBQ2hGLFFBQUksc0JBQXNCLENBQUMsa0JBQWtCLENBQUMsaUJBQWlCO0FBQzdELFVBQUksS0FBTSx5QkFBd0I7QUFBQSxVQUM3Qiw0QkFBMkI7QUFDaEMsaUJBQVcsSUFBSSxFQUFFLFVBQVUsU0FBUztBQUNwQztBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsS0FBSyxRQUFRLEtBQUs7QUFDNUIsd0JBQWtCO0FBQ2xCLGlCQUFXLElBQUksRUFBRSxVQUFVLFdBQVc7QUFDdEM7QUFBQSxJQUNGO0FBQ0EsUUFBSSxnQkFBaUIscUJBQW9CO0FBQ3pDLGVBQVcsSUFBSSxFQUFFLFVBQVUsVUFBVTtBQUNyQyxlQUFXLEtBQUssQ0FBQztBQUFBLEVBQ25CO0FBQ0EsTUFBSSxpQkFBaUIsR0FBRztBQUN0QixVQUFNLEtBQUssbUNBQW1DO0FBQUEsTUFDNUM7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSx1QkFBdUIsMEJBQTBCLEdBQUc7QUFDdEQsVUFBTSxhQUFhLHVCQUF1QjtBQUMxQyxVQUFNLEtBQUssb0VBQW9FO0FBQUEsTUFDN0U7QUFBQSxNQUNBLFNBQVM7QUFBQSxNQUNULGFBQWE7QUFBQSxNQUNiLGtCQUFrQjtBQUFBLE1BQ2xCLFdBQVcsV0FBVztBQUFBLElBQ3hCLENBQUM7QUFDRCxVQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsUUFBSSxXQUFXLE1BQU07QUFDbkIsYUFBTyxtQkFBbUIsT0FBTyxtQkFBbUIsS0FBSztBQUN6RCxZQUFNLHFCQUFxQixNQUFNO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBQ0EsTUFBSSxrQkFBa0IsS0FBSyxnQkFBZ0I7QUFDekMsVUFBTSxLQUFLLDBDQUEwQztBQUFBLE1BQ25EO0FBQUEsTUFDQSxLQUFLO0FBQUEsTUFDTCxRQUFRO0FBQUEsTUFDUix1QkFBdUIsaUJBQWlCLGdCQUFnQjtBQUFBLElBQzFELENBQUM7QUFBQSxFQUNIO0FBQ0EsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLEtBQUssdUNBQXVDO0FBQUEsTUFDaEQ7QUFBQSxNQUNBLFVBQVU7QUFBQSxNQUNWO0FBQUEsTUFDQSxXQUFXLFdBQVc7QUFBQSxJQUN4QixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU07QUFBQSxJQUNKLFdBQVcsT0FBTztBQUFBLE1BQUksQ0FBQyxNQUNyQjtBQUFBLFFBQ0U7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsY0FBYyxJQUFJLEVBQUUsUUFBUTtBQUFBLFFBQzVCLFdBQVcsSUFBSSxFQUFFLFFBQVE7QUFBQSxNQUMzQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBU0EsUUFBTSxzQkFBc0IsV0FBVyxRQUFRLFFBQVE7QUFDdkQsUUFBTSw0QkFBNEIsV0FBVyxRQUFRLE1BQU0sUUFBUTtBQUNuRSxRQUFNLHVCQUF1QixNQUFNO0FBQUEsSUFDakM7QUFBQSxJQUNBO0FBQUEsSUFDQSxXQUFXO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFDQSxNQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzNCLFFBQUksdUJBQXVCLEVBQUcsT0FBTSxlQUFlO0FBQ25EO0FBQUEsRUFDRjtBQUdBLFFBQU0sV0FBVyxvQkFBSSxJQUE4QjtBQUNuRCxhQUFXLEtBQUssWUFBWTtBQUMxQixVQUFNLE1BQU0sU0FBUyxJQUFJLEVBQUUsY0FBYyxLQUFLLENBQUM7QUFDL0MsUUFBSSxLQUFLLENBQUM7QUFDVixhQUFTLElBQUksRUFBRSxnQkFBZ0IsR0FBRztBQUFBLEVBQ3BDO0FBRUEsYUFBVyxDQUFDLFFBQVEsTUFBTSxLQUFLLFVBQVU7QUFDdkMsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxLQUFLLFFBQVE7QUFDbkUsUUFBSSxRQUFRO0FBQ1osUUFBSSxXQUFXO0FBQ2YsUUFBSSxnQkFBZ0I7QUFDcEIsUUFBSSxrQkFBa0I7QUFDdEIsZUFBVyxLQUFLLFFBQVE7QUFDdEIsWUFBTSxXQUFXLElBQUksYUFBYSxFQUFFLFFBQVE7QUFDNUMsVUFBSSxVQUFVO0FBR1osaUJBQVMsZUFBZTtBQUN4QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsZ0JBQWdCLEVBQUU7QUFDM0IsaUJBQVMsY0FBYyxFQUFFO0FBQ3pCLGlCQUFTLGNBQWMsRUFBRTtBQUN6QixpQkFBUyxhQUFhLEVBQUU7QUFDeEIsaUJBQVMsaUJBQWlCLEVBQUU7QUFDNUIsY0FBTSxPQUFPLFNBQVMsbUJBQW1CLFNBQVMsbUJBQW1CLFNBQVMsQ0FBQztBQUMvRSxjQUFNLE9BQU8sRUFBRSxtQkFBbUIsQ0FBQztBQUNuQyxZQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssZ0JBQWdCLEtBQUssY0FBYztBQUM1RCxtQkFBUyxtQkFBbUIsS0FBSyxJQUFJO0FBQUEsUUFDdkM7QUFDQSwyQkFBbUI7QUFBQSxNQUNyQixPQUFPO0FBQ0wsY0FBTSxVQUEwQixFQUFFLEdBQUcsR0FBRyxnQkFBZ0IsSUFBSSxPQUFPO0FBQ25FLFlBQUksYUFBYSxFQUFFLFFBQVEsSUFBSTtBQUMvQixpQkFBUztBQUNULFlBQUksY0FBYyxJQUFJLEVBQUUsUUFBUSxNQUFNLFdBQVksa0JBQWlCO0FBQUEsWUFDOUQsYUFBWTtBQUFBLE1BQ25CO0FBQ0EsVUFBSSxDQUFDLElBQUksbUJBQW1CLFNBQVMsRUFBRSxRQUFRLEdBQUc7QUFDaEQsWUFBSSxtQkFBbUIsS0FBSyxFQUFFLFFBQVE7QUFBQSxNQUN4QztBQUFBLElBQ0Y7QUFDQSxRQUFJLENBQUMsSUFBSSxlQUFlLFNBQVMsUUFBUSxFQUFHLEtBQUksZUFBZSxLQUFLLFFBQVE7QUFDNUUsUUFBSSxrQkFBa0I7QUFDdEIsVUFBTSxhQUFhLFFBQVEsR0FBRztBQUM5QixVQUFNLGlCQUFpQixRQUFRLG1CQUFtQixHQUFHLENBQUM7QUFDdEQsUUFBSSxRQUFRLEtBQUssa0JBQWtCLEdBQUc7QUFDcEMsWUFBTSxLQUFLLG1CQUFtQjtBQUFBLFFBQzVCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLEtBQUs7QUFBQSxRQUNMLFVBQVU7QUFBQSxRQUNWLGtCQUFrQjtBQUFBLFFBQ2xCLE9BQU8sT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFO0FBQUEsTUFDdkMsQ0FBQztBQUdELFlBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxVQUFJLFdBQVcsTUFBTTtBQUNuQixlQUFPLGlCQUFpQjtBQUN4QixlQUFPLG9CQUFvQixPQUFPLG9CQUFvQixLQUFLO0FBQzNELGVBQU8seUJBQXlCLE9BQU8seUJBQXlCLEtBQUs7QUFDckUsY0FBTSxxQkFBcUIsTUFBTTtBQUFBLE1BQ25DO0FBQUEsSUFDRjtBQUNBLFFBQUksT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFVBQVUsdUJBQXVCO0FBQ2pFLFlBQU0sWUFBWSxRQUFRLFdBQVc7QUFBQSxJQUN2QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLHdCQUNiLG1CQUNBLFNBQ0EsWUFDQSxXQUNBLFVBQ2U7QUFDZixRQUFNLGVBQWUsTUFBTSxrQkFBa0I7QUFDN0MsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELE1BQUksV0FBVztBQUNmLE1BQUksVUFBVTtBQUNkLE1BQUksZ0JBQWdCO0FBRXBCLGFBQVcsS0FBSyxtQkFBbUI7QUFDakMsVUFBTSxTQUFTLEVBQUU7QUFDakIsUUFBSSxDQUFDLFFBQVE7QUFDWCx1QkFBaUI7QUFDakIsWUFBTSxrQkFBa0IsRUFBRSxRQUFRO0FBQ2xDLFlBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQztBQUFBLElBQ0Y7QUFDQSxRQUFJLFFBQVEsT0FBTyxLQUFLLENBQUMsUUFBUSxJQUFJLE9BQU8sWUFBWSxDQUFDLEdBQUc7QUFDMUQsaUJBQVc7QUFDWDtBQUFBLElBQ0Y7QUFFQSxVQUFNLGtCQUFrQixFQUFFLFFBQVE7QUFDbEMsVUFBTSxlQUFlLFFBQVEsRUFBRSxRQUFRO0FBQ3ZDLFVBQU0sa0JBQWtCLEVBQUUsUUFBUTtBQUNsQyxRQUFJLGFBQWEsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNqRCxrQkFBWSxXQUFXO0FBQ3ZCLGtCQUFZLGFBQWE7QUFDekIsWUFBTSxrQkFBa0IsV0FBVztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxxQkFBcUIsY0FBYztBQUFBLElBQzNDO0FBQ0EsUUFBSSxnQkFBZ0IsVUFBVSxZQUFZLEVBQUUsVUFBVTtBQUNwRCxxQkFBZSxXQUFXO0FBQzFCLHFCQUFlLGFBQWE7QUFDNUIsWUFBTSxtQkFBbUIsRUFBRSxRQUFRO0FBQ25DLFlBQU0scUJBQXFCLGNBQWM7QUFBQSxJQUMzQztBQUVBLFVBQU0sTUFBTSxlQUFlLENBQUM7QUFDNUIsVUFBTSxPQUFPLGFBQWEsTUFBTSxJQUFJLEVBQUUsUUFBUTtBQUM5QyxRQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JCLGlCQUFXO0FBQ1g7QUFBQSxJQUNGO0FBRUEsVUFBTSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsWUFBWSxXQUFXLFFBQVE7QUFDekUsVUFBTSxrQkFBa0IsSUFBSSxxQkFBcUIsQ0FBQztBQUNsRCxvQkFBZ0IsRUFBRSxRQUFRLElBQUk7QUFDOUIsUUFBSSxvQkFBb0I7QUFDeEIsUUFBSSxDQUFDLElBQUksbUJBQW1CLFNBQVMsRUFBRSxRQUFRLEdBQUc7QUFDaEQsVUFBSSxtQkFBbUIsS0FBSyxFQUFFLFFBQVE7QUFBQSxJQUN4QztBQUNBLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsbUJBQW1CLEdBQUcsQ0FBQztBQUN0RCxnQkFBWTtBQUFBLEVBQ2Q7QUFFQSxNQUFJLFdBQVcsS0FBSyxnQkFBZ0IsS0FBSyxVQUFVLEdBQUc7QUFDcEQsVUFBTSxLQUFLLCtCQUErQixFQUFFLFVBQVUsVUFBVSxTQUFTLGNBQWMsQ0FBQztBQUFBLEVBQzFGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsU0FBUyxlQUFlLEdBQTZCO0FBQ25ELFNBQU8sZUFBZSxFQUFFLHNCQUFzQixFQUFFLElBQUksRUFBRSxvQkFBb0IsRUFBRTtBQUM5RTtBQUVBLFNBQVMsa0JBQWtCLEtBQXNCO0FBQy9DLFFBQU0sUUFBUSxJQUFJLE1BQU0sR0FBRztBQUMzQixTQUFPLE1BQU0sTUFBTSxTQUFTLENBQUMsTUFBTTtBQUNyQztBQUVBLFNBQVMsbUJBQW1CLEtBQXdCO0FBQ2xELFNBQ0UsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLFNBQzlCLE9BQU8sS0FBSyxJQUFJLHFCQUFxQixDQUFDLENBQUMsRUFBRSxTQUN6QyxPQUFPLEtBQUssSUFBSSx3QkFBd0IsQ0FBQyxDQUFDLEVBQUU7QUFFaEQ7QUFFQSxTQUFTLGVBQWUsTUFBMkI7QUFDakQsU0FBTyxDQUFDLEtBQUssaUJBQWlCLFlBQVksR0FBRyxLQUFLLGtCQUFrQixLQUFLLGlCQUFpQixFQUFFO0FBQUEsSUFDMUY7QUFBQSxFQUNGO0FBQ0Y7QUFFQSxTQUFTLHFCQUFxQixNQUE2QjtBQUN6RCxRQUFNLFFBQVEsS0FBSyxNQUFNLGdDQUFnQztBQUN6RCxTQUFPLFFBQVEsQ0FBQyxLQUFLO0FBQ3ZCO0FBRUEsU0FBUyxrQkFDUCxRQUNBLFVBQ0EsWUFDQSxVQUNBLFdBQ2U7QUFDZixRQUFNLG1CQUFtQixJQUFJLElBQUksU0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsT0FBTyxZQUFZLEdBQUcsRUFBRSxRQUFRLENBQUMsQ0FBQztBQUMxRixRQUFNLE9BQU8sSUFBSSxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDdkQsUUFBTSxNQUFNLG9CQUFJLElBQXlCO0FBQ3pDLGFBQVcsS0FBSyxRQUFRO0FBQ3RCLFFBQUksRUFBRSxlQUFlLGFBQWEsQ0FBQyxFQUFFLG1CQUFvQjtBQUN6RCxVQUFNLG9CQUFvQixpQkFBaUIsSUFBSSxFQUFFLGVBQWUsWUFBWSxDQUFDO0FBQzdFLFFBQUksQ0FBQyxrQkFBbUI7QUFDeEIsVUFBTSxXQUFXLEtBQUssSUFBSSxFQUFFLGtCQUFrQjtBQUM5QyxVQUFNLGlCQUNKLFVBQVUsa0JBQWtCLHFCQUFxQixFQUFFLGlCQUFpQixFQUFFLElBQUk7QUFDNUUsVUFBTSxtQkFBbUIsaUJBQ3BCLGlCQUFpQixJQUFJLGVBQWUsWUFBWSxDQUFDLEtBQUssV0FDdkQ7QUFDSixVQUFNLE9BQW9CO0FBQUEsTUFDeEIsa0JBQWtCLEVBQUU7QUFBQSxNQUNwQixzQkFBc0IsRUFBRSxjQUFjO0FBQUEsTUFDdEMsb0JBQW9CO0FBQUEsTUFDcEIsa0JBQWtCLEVBQUU7QUFBQSxNQUNwQixhQUFhLEVBQUU7QUFBQSxNQUNmLG1CQUFtQixFQUFFO0FBQUEsTUFDckIsd0JBQXdCO0FBQUEsTUFDeEIsNEJBQTRCLFVBQVUsY0FBYztBQUFBLE1BQ3BELDBCQUEwQjtBQUFBLE1BQzFCLGFBQWE7QUFBQSxNQUNiLGdCQUFnQjtBQUFBLE1BQ2hCO0FBQUEsTUFDQSxZQUFZO0FBQUEsSUFDZDtBQUNBLFFBQUksSUFBSSxlQUFlLElBQUksR0FBRyxJQUFJO0FBQUEsRUFDcEM7QUFDQSxTQUFPLENBQUMsR0FBRyxJQUFJLE9BQU8sQ0FBQztBQUN6QjtBQUVBLGVBQWUsbUJBQ2IsT0FDQSxZQUNBLFdBQ0EsVUFDaUI7QUFDakIsTUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBQy9CLFFBQU0sV0FBVyxvQkFBSSxJQUEyQjtBQUNoRCxhQUFXLFFBQVEsT0FBTztBQUN4QixVQUFNLE1BQU0sU0FBUyxJQUFJLEtBQUssZ0JBQWdCLEtBQUssQ0FBQztBQUNwRCxRQUFJLEtBQUssSUFBSTtBQUNiLGFBQVMsSUFBSSxLQUFLLGtCQUFrQixHQUFHO0FBQUEsRUFDekM7QUFDQSxNQUFJLFFBQVE7QUFDWixhQUFXLENBQUMsUUFBUSxXQUFXLEtBQUssVUFBVTtBQUM1QyxVQUFNLE1BQU0sTUFBTSxnQkFBZ0IsUUFBUSxZQUFZLFdBQVcsUUFBUTtBQUN6RSxVQUFNLFVBQVUsSUFBSSx3QkFBd0IsQ0FBQztBQUM3QyxRQUFJLGlCQUFpQjtBQUNyQixlQUFXLFFBQVEsYUFBYTtBQUM5QixZQUFNLFVBQXVCLEVBQUUsR0FBRyxNQUFNLGdCQUFnQixJQUFJLE9BQU87QUFDbkUsWUFBTSxNQUFNLGVBQWUsT0FBTztBQUNsQyxVQUFJLENBQUMsUUFBUSxHQUFHLEVBQUcsbUJBQWtCO0FBQ3JDLGNBQVEsR0FBRyxJQUFJO0FBQ2YsVUFBSSxDQUFDLElBQUksbUJBQW1CLFNBQVMsUUFBUSxnQkFBZ0IsR0FBRztBQUM5RCxZQUFJLG1CQUFtQixLQUFLLFFBQVEsZ0JBQWdCO0FBQUEsTUFDdEQ7QUFDQSxVQUFJLENBQUMsSUFBSSxtQkFBbUIsU0FBUyxRQUFRLGlCQUFpQixHQUFHO0FBQy9ELFlBQUksbUJBQW1CLEtBQUssUUFBUSxpQkFBaUI7QUFBQSxNQUN2RDtBQUFBLElBQ0Y7QUFDQSxRQUFJLG1CQUFtQixFQUFHO0FBQzFCLFFBQUksdUJBQXVCO0FBQzNCLFFBQUksQ0FBQyxJQUFJLGVBQWUsU0FBUyxRQUFRLEVBQUcsS0FBSSxlQUFlLEtBQUssUUFBUTtBQUM1RSxRQUFJLGtCQUFrQjtBQUN0QixVQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFVBQU0saUJBQWlCLFFBQVEsbUJBQW1CLEdBQUcsQ0FBQztBQUN0RCxhQUFTO0FBQ1QsVUFBTSxLQUFLLDBCQUEwQjtBQUFBLE1BQ25DO0FBQUEsTUFDQTtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsT0FBTyxPQUFPLEtBQUssT0FBTyxFQUFFO0FBQUEsSUFDOUIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxTQUFPO0FBQ1Q7QUFzQkEsZUFBZSxzQkFDYixRQUNBLFVBQ2U7QUFDZixNQUFJLE9BQU8sV0FBVyxFQUFHO0FBR3pCLFFBQU0sZUFBZSxvQkFBSSxJQUFZO0FBQ3JDLGFBQVcsS0FBSyxPQUFRLGNBQWEsSUFBSSxFQUFFLFFBQVE7QUFFbkQsTUFBSSxXQUFXO0FBQ2YsYUFBVyxLQUFLLFFBQVE7QUFDdEIsVUFBTSxVQUFzRCxDQUFDO0FBQzdELFFBQUksRUFBRSxtQkFBbUI7QUFDdkIsY0FBUSxLQUFLLEVBQUUsSUFBSSxFQUFFLG1CQUFtQixNQUFNLEVBQUUsaUJBQWlCLENBQUM7QUFBQSxJQUNwRTtBQUNBLFFBQUksRUFBRSxnQkFBaUIsU0FBUSxLQUFLLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixNQUFNLEtBQUssQ0FBQztBQUN6RSxRQUFJLEVBQUUsbUJBQW9CLFNBQVEsS0FBSyxFQUFFLElBQUksRUFBRSxvQkFBb0IsTUFBTSxLQUFLLENBQUM7QUFDL0UsZUFBVyxLQUFLLFNBQVM7QUFDdkIsVUFBSSxhQUFhLElBQUksRUFBRSxFQUFFLEVBQUc7QUFDNUIsVUFBSSxNQUFNLFlBQVksRUFBRSxFQUFFLEVBQUc7QUFDN0IsWUFBTSxrQkFBa0IsRUFBRSxNQUFNLEVBQUUsRUFBRTtBQUNwQyxrQkFBWTtBQUFBLElBQ2Q7QUFBQSxFQUNGO0FBQ0EsTUFBSSxXQUFXLEdBQUc7QUFDaEIsVUFBTSxLQUFLLHNEQUFzRDtBQUFBLE1BQy9EO0FBQUEsTUFDQTtBQUFBLE1BQ0EsYUFBYSxNQUFNLHFCQUFxQjtBQUFBLElBQzFDLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxlQUFlLDRCQUNiLFFBQ0EsYUFDQSxVQUNlO0FBQ2YsTUFBSSxPQUFPLFdBQVcsS0FBSyxZQUFZLFNBQVMsRUFBRztBQUNuRCxNQUFJLFNBQVMsU0FBUyxhQUFhLEtBQUssU0FBUyxTQUFTLHFCQUFxQixFQUFHO0FBRWxGLFFBQU0sYUFBYSxvQkFBSSxJQUFvQjtBQUMzQyxhQUFXLEtBQUssUUFBUTtBQUN0QixVQUFNLFNBQVMsRUFBRSxlQUFlLFlBQVk7QUFDNUMsUUFBSSxDQUFDLFlBQVksSUFBSSxNQUFNLEVBQUc7QUFFOUIsVUFBTSxTQUFTLEVBQUUsbUJBQW1CLEVBQUU7QUFDdEMsVUFBTSxTQUFTLFdBQVcsRUFBRSxZQUFZLEVBQUUsc0JBQXNCO0FBQ2hFLFVBQU0sY0FBYyxFQUFFLHNCQUFzQjtBQUM1QyxRQUFJLFVBQVUsRUFBRSxjQUFjLEdBQUc7QUFDL0IsaUJBQVcsSUFBSSxRQUFRLEVBQUUsY0FBYztBQUFBLElBQ3pDLFdBQVcsZUFBZSxRQUFRO0FBQ2hDLGlCQUFXLElBQUksUUFBUSxFQUFFLGNBQWM7QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxNQUFJLFdBQVc7QUFDZixhQUFXLENBQUMsU0FBUyxNQUFNLEtBQUssWUFBWTtBQUMxQyxVQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsVUFBTSxrQkFBa0IsUUFBUSxPQUFPO0FBQ3ZDLFVBQU0sUUFBUSxNQUFNLHFCQUFxQjtBQUN6QyxRQUFJLFFBQVEsT0FBUSxhQUFZO0FBQUEsRUFDbEM7QUFDQSxNQUFJLFdBQVcsR0FBRztBQUNoQixVQUFNLEtBQUssd0NBQXdDO0FBQUEsTUFDakQ7QUFBQSxNQUNBO0FBQUEsTUFDQSxhQUFhLE1BQU0scUJBQXFCO0FBQUEsSUFDMUMsQ0FBQztBQUFBLEVBQ0g7QUFDRjtBQUVBLGVBQWUsZ0JBQ2IsUUFDQSxJQUNBLFdBQ0EsVUFDb0I7QUFDcEIsUUFBTSxNQUFNLE1BQU0sYUFBYSxNQUFNO0FBQ3JDLE1BQUksSUFBSyxRQUFPO0FBQ2hCLFFBQU0sTUFBaUI7QUFBQSxJQUNyQixRQUFRLFNBQVM7QUFBQSxJQUNqQixnQkFBZ0I7QUFBQSxJQUNoQixZQUFZO0FBQUEsSUFDWixpQkFBaUI7QUFBQSxJQUNqQixjQUFjLENBQUM7QUFBQSxJQUNmLG1CQUFtQixDQUFDO0FBQUEsSUFDcEIsb0JBQW9CLENBQUM7QUFBQSxJQUNyQixnQkFBZ0IsQ0FBQyxRQUFRO0FBQUEsSUFDekIsWUFBWTtBQUFBLEVBQ2Q7QUFDQSxRQUFNLGFBQWEsUUFBUSxHQUFHO0FBQzlCLFFBQU0sS0FBSyxlQUFlLEVBQUUsUUFBUSxLQUFLLFdBQVcsSUFBSSxNQUFNLEVBQUUsQ0FBQztBQUNqRSxTQUFPO0FBQ1Q7QUFJQSxJQUFJLGFBQTRCLFFBQVEsUUFBUTtBQWdCaEQsZUFBZSxtQkFBa0M7QUFDL0MsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLE1BQU0sS0FBSyxJQUFJO0FBQ3JCLFFBQU0sVUFBb0IsQ0FBQztBQUMzQixhQUFXLENBQUMsUUFBUSxHQUFHLEtBQUssT0FBTyxRQUFRLEdBQUcsR0FBRztBQUMvQyxVQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksZUFBZTtBQUMzQyxRQUFJLE9BQU8sU0FBUyxJQUFJLEtBQUssTUFBTSxRQUFRLGVBQWU7QUFDeEQsY0FBUSxLQUFLLE1BQU07QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFDQSxRQUFNLGFBQWEsU0FBUyxNQUFNO0FBQ3BDO0FBRUEsZUFBZSw4QkFBNkM7QUFPMUQsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxLQUFNO0FBQ3hELFFBQU0sTUFBTSxNQUFNLGNBQWM7QUFDaEMsUUFBTSxNQUFNLEtBQUssSUFBSTtBQUNyQixRQUFNLFVBQW9CLENBQUM7QUFDM0IsYUFBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLE9BQU8sUUFBUSxHQUFHLEdBQUc7QUFDL0MsVUFBTSxPQUFPLEtBQUssTUFBTSxJQUFJLGVBQWU7QUFDM0MsUUFBSSxPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sUUFBUSxlQUFlO0FBQ3hELGNBQVEsS0FBSyxNQUFNO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBQ0EsUUFBTSxhQUFhLFNBQVMsTUFBTTtBQUNwQztBQUVBLGVBQWUsU0FBUyxRQUErQjtBQUNyRCxRQUFNLE1BQU0sTUFBTSxjQUFjO0FBQ2hDLFFBQU0sYUFBYSxPQUFPLEtBQUssR0FBRyxHQUFHLE1BQU07QUFDN0M7QUFFQSxlQUFlLFlBQVksUUFBZ0IsUUFBK0I7QUFDeEUsUUFBTSxhQUFhLENBQUMsTUFBTSxHQUFHLE1BQU07QUFDckM7QUFFQSxlQUFlLGFBQWEsU0FBbUIsUUFBK0I7QUFDNUUsUUFBTSxTQUFTLENBQUMsR0FBRyxJQUFJLElBQUksT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUM7QUFDL0QsTUFBSSxPQUFPLFdBQVcsRUFBRztBQUN6QixRQUFNLE1BQU0sV0FBVyxLQUFLLE1BQU0sbUJBQW1CLFFBQVEsTUFBTSxDQUFDO0FBQ3BFLGVBQWEsSUFBSSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDL0IsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUIsU0FBbUIsUUFBK0I7QUFDbEYsUUFBTSxNQUFNLE1BQU0sY0FBYztBQUNoQyxRQUFNLFFBQXFCLENBQUM7QUFDNUIsYUFBVyxVQUFVLFNBQVM7QUFDNUIsVUFBTSxNQUFNLElBQUksTUFBTTtBQUN0QixRQUFJLENBQUMsSUFBSztBQUNWLFVBQU0sU0FBUyxPQUFPLE9BQU8sSUFBSSxZQUFZO0FBQzdDLFVBQU0sb0JBQW9CLE9BQU8sT0FBTyxJQUFJLHFCQUFxQixDQUFDLENBQUM7QUFDbkUsVUFBTSxlQUFlLE9BQU8sT0FBTyxJQUFJLHdCQUF3QixDQUFDLENBQUM7QUFDakUsUUFBSSxPQUFPLFdBQVcsS0FBSyxrQkFBa0IsV0FBVyxLQUFLLGFBQWEsV0FBVyxHQUFHO0FBQ3RGLFlBQU0sZUFBZSxNQUFNO0FBQzNCLFlBQU0saUJBQWlCLFFBQVEsQ0FBQztBQUNoQztBQUFBLElBQ0Y7QUFDQSxVQUFNLEtBQUssZUFBZSxRQUFRLEtBQUssUUFBUSxtQkFBbUIsWUFBWSxDQUFDO0FBQUEsRUFDakY7QUFDQSxNQUFJLE1BQU0sV0FBVyxFQUFHO0FBRXhCLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxDQUFDLFNBQVMsT0FBTyxDQUFDLFNBQVMsU0FBUyxDQUFDLFNBQVMsTUFBTTtBQUN0RCxVQUFNLEtBQUssK0NBQStDO0FBQUEsTUFDeEQsT0FBTyxNQUFNO0FBQUEsTUFDYixTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxJQUN2RCxDQUFDO0FBQ0Q7QUFBQSxFQUNGO0FBQ0EsUUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFFBQU0sUUFBUSxNQUFNLFFBQVEsQ0FBQyxTQUFTO0FBQUEsSUFDcEM7QUFBQSxNQUNFLE1BQU0sS0FBSztBQUFBLE1BQ1gsZUFBZUMsVUFBUyxLQUFLLFVBQVUsS0FBSyxTQUFTLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxJQUN0RTtBQUFBLElBQ0E7QUFBQSxNQUNFLE1BQU0sS0FBSztBQUFBLE1BQ1gsZUFBZUEsVUFBUyxLQUFLLFVBQVUsS0FBSyxNQUFNLE1BQU0sQ0FBQyxJQUFJLElBQUk7QUFBQSxJQUNuRTtBQUFBLEVBQ0YsQ0FBQztBQUNELFFBQU0sWUFBWSx3QkFBd0IsS0FBSztBQUUvQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLE1BQU0sT0FBTyxZQUFZO0FBQUEsTUFDdEM7QUFBQSxNQUNBLFNBQVM7QUFBQSxJQUNYLENBQUM7QUFDRCxVQUFNLE1BQU0sTUFBTSxrQkFBa0I7QUFDcEMsZUFBVyxRQUFRLE9BQU87QUFDeEIsWUFBTSxpQkFBaUIsTUFBTSwrQkFBK0IsSUFBSTtBQUtoRSxZQUFNLFFBQVEsTUFBTSxZQUFZLEdBQUcsS0FBSyxNQUFNO0FBQzlDLFlBQU0sU0FBUSxvQkFBSSxLQUFLLEdBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQ2xELFlBQU0sZUFBZSxRQUFRLEtBQUssY0FBYyxRQUFRLEtBQUssYUFBYTtBQUMxRSxZQUFNLFlBQVksS0FBSyxRQUFRO0FBQUEsUUFDN0IsWUFBWSxlQUFlLEtBQUssT0FBTyxTQUFTLEtBQUssa0JBQWtCO0FBQUEsUUFDdkUsV0FBVztBQUFBLFFBQ1gsZUFBZSxLQUFLLElBQUk7QUFBQSxRQUN4QixpQkFDRyxNQUFNLGtCQUFrQixLQUFLLEtBQUssT0FBTyxTQUFTLEtBQUssa0JBQWtCO0FBQUEsUUFDNUUsZUFBZTtBQUFBLE1BQ2pCLENBQUM7QUFHRCxZQUFNLFFBQVEsSUFBSSxLQUFLLE1BQU0sS0FBSyxDQUFDO0FBQ25DLFlBQU0sVUFBUyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUN0QyxpQkFBVyxLQUFLLEtBQUssUUFBUTtBQUMzQixjQUFNLEVBQUUsUUFBUSxJQUFJO0FBQUEsVUFDbEIsSUFBSTtBQUFBLFVBQ0osS0FBSztBQUFBLFlBQ0gsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFlBQ0YsRUFBRTtBQUFBLFVBQ0o7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLGlCQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdEMsY0FBTSxFQUFFLFFBQVEsSUFBSTtBQUFBLFVBQ2xCLElBQUk7QUFBQSxVQUNKLEtBQUssZUFBZSxDQUFDO0FBQUEsUUFDdkI7QUFBQSxNQUNGO0FBQ0EsVUFBSSxLQUFLLE1BQU0sSUFBSTtBQUNuQixZQUFNLEtBQUssMkJBQTJCO0FBQUEsUUFDcEMsUUFBUSxLQUFLO0FBQUEsUUFDYjtBQUFBLFFBQ0EsUUFBUSxLQUFLLE9BQU87QUFBQSxRQUNwQixhQUFhLEtBQUssa0JBQWtCO0FBQUEsUUFDcEMsZUFBZSxLQUFLLGFBQWE7QUFBQSxRQUNqQyxLQUFLLEtBQUs7QUFBQSxRQUNWLE1BQU0sS0FBSztBQUFBLFFBQ1gsY0FBYyxPQUFPO0FBQUEsTUFDdkIsQ0FBQztBQUFBLElBQ0g7QUFDQSxVQUFNLGtCQUFrQixHQUFHO0FBQzNCLFVBQU0sS0FBSyxpQ0FBaUM7QUFBQSxNQUMxQztBQUFBLE1BQ0EsTUFBTSxNQUFNO0FBQUEsTUFDWixPQUFPLE1BQU07QUFBQSxNQUNiLFFBQVEsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxPQUFPLFFBQVEsQ0FBQztBQUFBLE1BQ25FLGFBQWEsTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxrQkFBa0IsUUFBUSxDQUFDO0FBQUEsTUFDbkYsZUFBZSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLGFBQWEsUUFBUSxDQUFDO0FBQUEsTUFDaEYsUUFBUSxPQUFPO0FBQUEsSUFDakIsQ0FBQztBQUNEO0FBQ0UsWUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxZQUFNLGNBQWM7QUFBQSxRQUNsQixRQUFRO0FBQUEsUUFDUixPQUFPLEtBQUs7QUFBQSxRQUNaLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUNsQyxPQUFPO0FBQUEsUUFDUCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLFFBQzdCLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixRQUFJLGVBQWUsYUFBYTtBQUM5QixZQUFNLE9BQU8sTUFBTSxjQUFjO0FBQ2pDLFlBQU0sU0FDSixJQUFJLGFBQWEsU0FDYixlQUNBLElBQUksYUFBYSxlQUNmLGlCQUNBLElBQUksYUFBYSxZQUNmLGtCQUNBLEtBQUs7QUFDZixZQUFNLGNBQWM7QUFBQSxRQUNsQjtBQUFBLFFBQ0EsT0FBTyxLQUFLO0FBQUEsUUFDWixZQUFXLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsUUFDbEMsT0FBTyxJQUFJO0FBQUEsUUFDWCxlQUFlLEtBQUs7QUFBQSxRQUNwQix3QkFBd0IsS0FBSztBQUFBLFFBQzdCLGtCQUNFLElBQUksYUFBYSxlQUFlLElBQUksbUJBQW1CLEtBQUs7QUFBQSxNQUNoRSxDQUFDO0FBQ0QsWUFBTSxNQUFPLHdCQUF3QjtBQUFBLFFBQ25DO0FBQUEsUUFDQSxTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNyRCxNQUFNLE1BQU07QUFBQSxRQUNaLE9BQU8sTUFBTTtBQUFBLFFBQ2IsVUFBVSxJQUFJO0FBQUEsUUFDZCxRQUFRLElBQUk7QUFBQSxRQUNaLFNBQVMsSUFBSTtBQUFBLFFBQ2Isa0JBQWtCLElBQUk7QUFBQSxNQUN4QixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0wsWUFBTSxNQUFPLHdCQUF3QjtBQUFBLFFBQ25DO0FBQUEsUUFDQSxTQUFTLE1BQU0sSUFBSSxDQUFDLFNBQVMsS0FBSyxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNyRCxNQUFNLE1BQU07QUFBQSxRQUNaLE9BQU8sTUFBTTtBQUFBLFFBQ2IsR0FBRyxjQUFjLEdBQUc7QUFBQSxNQUN0QixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBRUYsVUFBRTtBQUNBLFVBQU0sZUFBZTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLGVBQ1AsUUFDQSxLQUNBLFFBQ0EsbUJBQ0EsY0FDVztBQUNYLFFBQU0sS0FBSyxXQUFXLElBQUksVUFBVTtBQUNwQyxRQUFNLE1BQU0sSUFBSSxXQUFXLE1BQU0sR0FBRyxFQUFFO0FBQ3RDLFFBQU0sV0FBVyxXQUFXLElBQUksTUFBTTtBQUN0QyxRQUFNLFVBQVUsT0FBTyxNQUFNLElBQUksRUFBRSxJQUFJLFFBQVE7QUFDL0MsUUFBTSxXQUFXLFFBQVEsTUFBTSxJQUFJLEVBQUUsSUFBSSxRQUFRO0FBQ2pELFNBQU87QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNQLGdCQUFnQjtBQUFBLE1BQ2hCLGdCQUFnQixJQUFJO0FBQUEsTUFDcEIsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYSxJQUFJO0FBQUEsTUFDakIsVUFBVSxJQUFJLGVBQWUsS0FBSyxHQUFHO0FBQUEsTUFDckMsWUFBWSxVQUFVO0FBQUEsTUFDdEIsWUFBWSxJQUFJO0FBQUEsTUFDaEI7QUFBQSxNQUNBLG9CQUFvQjtBQUFBLE1BQ3BCLGVBQWU7QUFBQSxJQUNqQjtBQUFBLElBQ0EsTUFBTTtBQUFBLE1BQ0osZ0JBQWdCO0FBQUEsTUFDaEIsZ0JBQWdCLElBQUk7QUFBQSxNQUNwQixnQkFBZ0I7QUFBQSxNQUNoQixhQUFhLElBQUk7QUFBQSxNQUNqQixvQkFBb0IsSUFBSTtBQUFBLElBQzFCO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyx3QkFBd0IsT0FBNEI7QUFDM0QsTUFBSSxNQUFNLFdBQVcsR0FBRztBQUN0QixVQUFNLE9BQU8sTUFBTSxDQUFDO0FBQ3BCLFVBQU1DLG9CQUFtQixLQUFLLGtCQUFrQjtBQUNoRCxVQUFNQyxhQUFZLEtBQUssYUFBYTtBQUNwQyxVQUFNQyxXQUNIRixvQkFBbUIsSUFBSSxLQUFLQSxpQkFBZ0IsaUJBQWlCLE9BQzdEQyxhQUFZLElBQUksS0FBS0EsVUFBUyxnQkFBZ0JBLGVBQWMsSUFBSSxLQUFLLEdBQUcsS0FBSztBQUNoRixXQUFPLFlBQVksS0FBSyxNQUFNLElBQUksS0FBSyxHQUFHLElBQUksS0FBSyxPQUFPLE1BQU0sU0FBUyxLQUFLLE9BQU8sV0FBVyxJQUFJLEtBQUssR0FBRyxHQUFHQyxPQUFNLFNBQVMsS0FBSyxRQUFRO0FBQUEsRUFDN0k7QUFDQSxRQUFNLE9BQU8sQ0FBQyxHQUFHLElBQUksSUFBSSxNQUFNLElBQUksQ0FBQyxTQUFTLEtBQUssR0FBRyxDQUFDLENBQUMsRUFBRSxLQUFLO0FBQzlELFFBQU0sV0FBVyxLQUFLLFdBQVcsSUFBSSxLQUFLLENBQUMsSUFBSyxHQUFHLEtBQUssQ0FBQyxDQUFDLEtBQUssS0FBSyxLQUFLLFNBQVMsQ0FBQyxDQUFDO0FBQ3BGLFFBQU0sYUFBYSxNQUFNLE9BQU8sQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLE9BQU8sUUFBUSxDQUFDO0FBQzlFLFFBQU0sbUJBQW1CLE1BQU0sT0FBTyxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssa0JBQWtCLFFBQVEsQ0FBQztBQUMvRixRQUFNLFlBQVksTUFBTSxPQUFPLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxhQUFhLFFBQVEsQ0FBQztBQUNuRixRQUFNLFVBQ0gsbUJBQW1CLElBQUksS0FBSyxnQkFBZ0IsaUJBQWlCLE9BQzdELFlBQVksSUFBSSxLQUFLLFNBQVMsZ0JBQWdCLGNBQWMsSUFBSSxLQUFLLEdBQUcsS0FBSztBQUNoRixTQUFPLGtCQUFrQixNQUFNLE1BQU0sVUFBVSxVQUFVLFNBQVMsZUFBZSxJQUFJLEtBQUssR0FBRyxHQUFHLE1BQU0sS0FBSyxRQUFRO0FBQ3JIO0FBRUEsZUFBZSwrQkFBK0IsTUFBa0M7QUFDOUUsUUFBTSxVQUFVLE1BQU0sYUFBYSxLQUFLLE1BQU07QUFDOUMsTUFBSSxDQUFDLFFBQVMsUUFBTztBQUNyQixNQUFJLFFBQVEsV0FBVyxLQUFLLElBQUksT0FBUSxRQUFPLG1CQUFtQixPQUFPO0FBRXpFLFFBQU0sWUFBWSxJQUFJO0FBQUEsSUFDcEIsS0FBSyxPQUFPLElBQUksQ0FBQyxNQUFNO0FBQUEsTUFDckIsRUFBRTtBQUFBLE1BQ0YsY0FBYyxFQUFFLFlBQVksRUFBRSxlQUFlLEVBQUUsYUFBYSxFQUFFLGFBQWEsRUFBRSxZQUFZO0FBQUEsSUFDM0YsQ0FBQztBQUFBLEVBQ0g7QUFDQSxhQUFXLEtBQUssS0FBSyxtQkFBbUI7QUFDdEMsY0FBVSxJQUFJLEVBQUUsVUFBVSxlQUFlLENBQUMsQ0FBQztBQUFBLEVBQzdDO0FBQ0EsUUFBTSxrQkFBa0QsQ0FBQztBQUN6RCxhQUFXLENBQUMsU0FBUyxLQUFLLEtBQUssT0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ25FLFVBQU0sZUFBZSxVQUFVLElBQUksT0FBTztBQUMxQyxVQUFNLGFBQWE7QUFBQSxNQUNqQixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsTUFDTixNQUFNO0FBQUEsSUFDUjtBQUNBLFFBQUksQ0FBQyxnQkFBZ0IsaUJBQWlCLFlBQVk7QUFDaEQsc0JBQWdCLE9BQU8sSUFBSSxFQUFFLEdBQUcsTUFBTTtBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUNBLFFBQU0sdUJBQXlELENBQUM7QUFDaEUsYUFBVyxDQUFDLFNBQVMsV0FBVyxLQUFLLE9BQU8sUUFBUSxRQUFRLHFCQUFxQixDQUFDLENBQUMsR0FBRztBQUNwRixVQUFNLGVBQWUsVUFBVSxJQUFJLE9BQU87QUFDMUMsVUFBTSxhQUFhLGVBQWUsV0FBVztBQUM3QyxRQUFJLENBQUMsZ0JBQWdCLGlCQUFpQixZQUFZO0FBQ2hELDJCQUFxQixPQUFPLElBQUksRUFBRSxHQUFHLFlBQVk7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLHdCQUFxRCxDQUFDO0FBQzVELGFBQVcsQ0FBQyxLQUFLLElBQUksS0FBSyxPQUFPLFFBQVEsUUFBUSx3QkFBd0IsQ0FBQyxDQUFDLEdBQUc7QUFDNUUsUUFBSSxDQUFDLEtBQUssYUFBYSxLQUFLLENBQUMsa0JBQWtCLGVBQWUsYUFBYSxNQUFNLEdBQUcsR0FBRztBQUNyRiw0QkFBc0IsR0FBRyxJQUFJLEVBQUUsR0FBRyxLQUFLO0FBQUEsSUFDekM7QUFBQSxFQUNGO0FBRUEsUUFBTSxlQUFlLG9CQUFJLElBQUk7QUFBQSxJQUMzQixHQUFHLE9BQU8sS0FBSyxlQUFlO0FBQUEsSUFDOUIsR0FBRyxPQUFPLEtBQUssb0JBQW9CO0FBQUEsSUFDbkMsR0FBRyxPQUFPLE9BQU8scUJBQXFCLEVBQUUsUUFBUSxDQUFDLFNBQVM7QUFBQSxNQUN4RCxLQUFLO0FBQUEsTUFDTCxLQUFLO0FBQUEsSUFDUCxDQUFDO0FBQUEsRUFDSCxDQUFDO0FBQ0QsUUFBTSxpQkFDSixPQUFPLEtBQUssZUFBZSxFQUFFLFNBQzdCLE9BQU8sS0FBSyxvQkFBb0IsRUFBRSxTQUNsQyxPQUFPLEtBQUsscUJBQXFCLEVBQUU7QUFDckMsTUFBSSxtQkFBbUIsR0FBRztBQUN4QixVQUFNLGVBQWUsS0FBSyxNQUFNO0FBQ2hDLFdBQU87QUFBQSxFQUNUO0FBRUEsUUFBTSxZQUFZLFNBQVM7QUFDM0IsYUFBVyxTQUFTLE9BQU8sT0FBTyxlQUFlLEdBQUc7QUFDbEQsVUFBTSxpQkFBaUI7QUFBQSxFQUN6QjtBQUNBLGFBQVcsUUFBUSxPQUFPLE9BQU8scUJBQXFCLEdBQUc7QUFDdkQsU0FBSyxpQkFBaUI7QUFBQSxFQUN4QjtBQUNBLFFBQU0sYUFBYSxLQUFLLFFBQVE7QUFBQSxJQUM5QixHQUFHO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDUixZQUFZLFFBQVE7QUFBQSxJQUNwQixjQUFjO0FBQUEsSUFDZCxtQkFBbUI7QUFBQSxJQUNuQixzQkFBc0I7QUFBQSxJQUN0QixvQkFBb0IsUUFBUSxtQkFBbUIsT0FBTyxDQUFDLE9BQU8sYUFBYSxJQUFJLEVBQUUsQ0FBQztBQUFBLEVBQ3BGLENBQUM7QUFDRCxRQUFNLEtBQUssbUNBQW1DO0FBQUEsSUFDNUMsUUFBUSxLQUFLO0FBQUEsSUFDYixlQUFlLEtBQUs7QUFBQSxJQUNwQixVQUFVLFdBQVcsU0FBUztBQUFBLElBQzlCLFdBQVc7QUFBQSxFQUNiLENBQUM7QUFDRCxTQUFPO0FBQ1Q7QUFJQSxlQUFlLFdBQVcsUUFBK0I7QUFDdkQsMkJBQXlCO0FBTXpCLFFBQU0sWUFBWSxpQkFBaUIsTUFBTTtBQUN6QyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsUUFBUSxLQUFLLGVBQWUsQ0FBQztBQUNuRSxNQUFJLENBQUUsTUFBTSxhQUFhLE1BQU0sR0FBSTtBQUNqQyxVQUFNLE9BQU0sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDbkMsVUFBTSxhQUFhLFFBQVE7QUFBQSxNQUN6QixRQUFRLFNBQVM7QUFBQSxNQUNqQixnQkFBZ0I7QUFBQSxNQUNoQixZQUFZO0FBQUEsTUFDWixpQkFBaUI7QUFBQSxNQUNqQixjQUFjLENBQUM7QUFBQSxNQUNmLG1CQUFtQixDQUFDO0FBQUEsTUFDcEIsb0JBQW9CLENBQUM7QUFBQSxNQUNyQixnQkFBZ0IsQ0FBQztBQUFBLE1BQ2pCLFlBQVk7QUFBQSxJQUNkLENBQUM7QUFBQSxFQUNIO0FBQ0EsUUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssV0FBVyxRQUFRLEtBQUssQ0FBQztBQUM1RDtBQUVBLGVBQWUsYUFBNEI7QUFDekMsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxRQUFNLEtBQUsseUJBQXlCLEVBQUUsT0FBTyxTQUFTLE9BQU8sQ0FBQztBQUM5RCxhQUFXLEtBQUssVUFBVTtBQUN4QixVQUFNLFdBQVcsRUFBRSxNQUFNO0FBQUEsRUFDM0I7QUFDRjtBQVdBLGVBQWUsa0JBQWlDO0FBQzlDLDJCQUF5QjtBQUN6QixNQUFJO0FBQ0osTUFBSTtBQUNGLFdBQU8sTUFBTSxRQUFRLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUFBLEVBQ3ZFLFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxpREFBaUQsY0FBYyxHQUFHLENBQUM7QUFDOUU7QUFBQSxFQUNGO0FBQ0EsUUFBTSxNQUFNLEtBQUssQ0FBQztBQUNsQixNQUFJLENBQUMsT0FBTyxPQUFPLElBQUksT0FBTyxZQUFZLENBQUMsSUFBSSxLQUFLO0FBQ2xELFVBQU0sS0FBSyxrQ0FBa0M7QUFDN0M7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLGdDQUFnQyxLQUFLLElBQUksR0FBRyxHQUFHO0FBQ2xELFVBQU0sS0FBSywrREFBK0Q7QUFBQSxNQUN4RSxLQUFLLFdBQVcsSUFBSSxHQUFHO0FBQUEsSUFDekIsQ0FBQztBQUNEO0FBQUEsRUFDRjtBQUNBLFFBQU0sS0FBSywrQkFBK0IsRUFBRSxLQUFLLFdBQVcsSUFBSSxHQUFHLEVBQUUsQ0FBQztBQUd0RSxNQUFJO0FBQ0YsVUFBTSxRQUFRLFVBQVUsY0FBYztBQUFBLE1BQ3BDLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztBQUFBLE1BQ3hCLE9BQU8sQ0FBQyxjQUFjO0FBQUEsTUFDdEIsT0FBTztBQUFBLElBQ1QsQ0FBQztBQUNELFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7QUFBQSxNQUN4QixPQUFPLENBQUMsWUFBWTtBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyx1Q0FBdUMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUN0RTtBQUdBLE1BQUk7QUFDRixVQUFNLFFBQVEsVUFBVSxjQUFjO0FBQUEsTUFDcEMsUUFBUSxFQUFFLE9BQU8sSUFBSSxHQUFHO0FBQUEsTUFDeEIsT0FBTztBQUFBLE1BQ1AsTUFBTSxNQUFNO0FBQ1YsY0FBTSxJQUFJLE9BQU87QUFDakIsZUFBTyxTQUFTLEVBQUUsS0FBSyxJQUFJLEtBQUssVUFBVSxTQUFTLENBQUM7QUFDcEQsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLEdBQUc7QUFDM0UsbUJBQVcsTUFBTSxPQUFPLFNBQVMsRUFBRSxLQUFLLElBQUksS0FBSyxVQUFVLFNBQVMsQ0FBQyxHQUFHLElBQUk7QUFBQSxNQUM5RTtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLDBDQUEwQyxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ3pFO0FBQ0Y7QUFhQSxJQUFNLGtCQUFrQjtBQUV4QixlQUFlLGtCQUEwQztBQUN2RCxRQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLGVBQWU7QUFDOUQsUUFBTSxLQUFLLE9BQU8sZUFBZTtBQUNqQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLGdCQUFnQixJQUFrQztBQUMvRCxNQUFJLE9BQU8sTUFBTTtBQUNmLFVBQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxlQUFlO0FBQUEsRUFDcEQsT0FBTztBQUNMLFVBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZUFBZSxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQzNEO0FBQ0Y7QUFFQSxlQUFlLG1CQUFrQztBQUMvQywyQkFBeUI7QUFDekIsUUFBTSxRQUFRLE1BQU0sa0JBQWtCO0FBQ3RDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLHlCQUF5QjtBQUNwQztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0sa0JBQWtCO0FBQUEsSUFDdEIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCx1QkFBcUIsT0FBTztBQUM1QixPQUFLLFlBQVk7QUFDakIsUUFBTSxLQUFLLHdCQUF3QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMzRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLHdCQUErRDtBQUVuRSxTQUFTLHFCQUFxQixTQUF1QjtBQUNuRCxNQUFJLDBCQUEwQixLQUFNLGVBQWMscUJBQXFCO0FBQ3ZFLDBCQUF3QixZQUFZLE1BQU07QUFDeEMsU0FBSyxZQUFZLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDaEMsV0FBSyxLQUFLLHVCQUF1QixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3JELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyxzQkFBNEI7QUFDbkMsTUFBSSwwQkFBMEIsTUFBTTtBQUNsQyxrQkFBYyxxQkFBcUI7QUFDbkMsNEJBQXdCO0FBQUEsRUFDMUI7QUFDRjtBQUVBLGVBQWUsb0JBQW1DO0FBQ2hELHNCQUFvQjtBQUNwQixRQUFNLFFBQVEsT0FBTyxNQUFNLGNBQWM7QUFDekMsUUFBTSxRQUFRLE1BQU0sZ0JBQWdCO0FBQ3BDLFFBQU0sZ0JBQWdCLElBQUk7QUFDMUIsUUFBTSxPQUFPLE1BQU0sa0JBQWtCO0FBQ3JDLFFBQU0sa0JBQWtCLElBQUk7QUFDNUIsUUFBTSxLQUFLLDBCQUEwQjtBQUFBLElBQ25DLFNBQVMsVUFBVTtBQUFBLElBQ25CLFdBQVcsTUFBTSxhQUFhO0FBQUEsRUFDaEMsQ0FBQztBQUNELFFBQU0sZUFBZTtBQUN2QjtBQUVBLGVBQWUsY0FBNkI7QUFDMUMsTUFBSSxPQUFPLE1BQU0sa0JBQWtCO0FBQ25DLE1BQUksU0FBUyxNQUFNO0FBRWpCLHdCQUFvQjtBQUNwQjtBQUFBLEVBQ0Y7QUFJQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGdCQUFnQjtBQUM1QjtBQUFBLElBQ0Y7QUFFQSxVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsVUFBVSxLQUFLLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsSUFDYixDQUFDO0FBRUQsVUFBTSxJQUFJLE1BQU0sZ0JBQWdCO0FBQ2hDLGVBQVcsQ0FBQyxRQUFRLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0FBQzdDLFVBQUksSUFBSSxTQUFTLEtBQUssU0FBUyxPQUFPLEdBQUc7QUFDdkMsY0FBTSxlQUFlLFFBQVEsS0FBSyxTQUFTLE9BQU87QUFDbEQ7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUNBLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxrQkFBa0IsSUFBSTtBQUFBLEVBQzlCO0FBRUEsUUFBTSxTQUFTLE1BQU0sa0JBQWtCO0FBQ3ZDLE1BQUksQ0FBQyxRQUFRO0FBQ1gsd0JBQW9CO0FBQ3BCLFVBQU0sZ0JBQWdCLElBQUk7QUFDMUIsVUFBTSxrQkFBa0IsSUFBSTtBQUM1QixVQUFNLEtBQUsseUJBQXlCLEVBQUUsV0FBVyxLQUFLLFVBQVUsQ0FBQztBQUNqRSxVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTSxNQUFNLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDbkUsTUFBSSxRQUFRLE1BQU0sZ0JBQWdCO0FBQ2xDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxnQkFBZ0IsSUFBSSxFQUFFO0FBQUEsSUFDOUQsT0FBTztBQUNMLFlBQU0sUUFBUSxLQUFLLE9BQU8sT0FBTyxFQUFFLElBQUksQ0FBQztBQUFBLElBQzFDO0FBQ0EsV0FBUSxNQUFNLGtCQUFrQixLQUFNO0FBQ3RDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxrQkFBa0IsSUFBSTtBQUM1QixVQUFNLEtBQUssZ0JBQWdCO0FBQUEsTUFDekIsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixXQUFXLE1BQU0sa0JBQWtCO0FBQUEsTUFDbkMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssNENBQTRDO0FBQUEsTUFDckQsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNLGVBQWUsT0FBTyxRQUFRLE9BQU8sT0FBTztBQUNsRCxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0sa0JBQWtCLElBQUk7QUFBQSxFQUM5QjtBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQVdBLElBQU0sc0JBQXNCO0FBRTVCLGVBQWUscUJBQTZDO0FBQzFELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksbUJBQW1CO0FBQ2xFLFFBQU0sS0FBSyxPQUFPLG1CQUFtQjtBQUNyQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLG1CQUFtQixJQUFrQztBQUNsRSxNQUFJLE9BQU8sS0FBTSxPQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU8sbUJBQW1CO0FBQUEsTUFDbEUsT0FBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxtQkFBbUIsR0FBRyxHQUFHLENBQUM7QUFDcEU7QUFFQSxlQUFlLHNCQUFxQztBQUNsRCwyQkFBeUI7QUFDekIsUUFBTSxRQUFRLE1BQU0scUJBQXFCO0FBQ3pDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLDZCQUE2QjtBQUN4QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCwwQkFBd0IsT0FBTztBQUMvQixPQUFLLGVBQWU7QUFDcEIsUUFBTSxLQUFLLDRCQUE0QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMvRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLDJCQUFrRTtBQUV0RSxTQUFTLHdCQUF3QixTQUF1QjtBQUN0RCxNQUFJLDZCQUE2QixLQUFNLGVBQWMsd0JBQXdCO0FBQzdFLDZCQUEyQixZQUFZLE1BQU07QUFDM0MsU0FBSyxlQUFlLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDbkMsV0FBSyxLQUFLLDJCQUEyQixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3pELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyx5QkFBK0I7QUFDdEMsTUFBSSw2QkFBNkIsTUFBTTtBQUNyQyxrQkFBYyx3QkFBd0I7QUFDdEMsK0JBQTJCO0FBQUEsRUFDN0I7QUFDRjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHlCQUF1QjtBQUN2QixRQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLFFBQVEsTUFBTSxtQkFBbUI7QUFDdkMsUUFBTSxtQkFBbUIsSUFBSTtBQUM3QixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxpQkFBZ0M7QUFDN0MsTUFBSSxPQUFPLE1BQU0scUJBQXFCO0FBQ3RDLE1BQUksU0FBUyxNQUFNO0FBQ2pCLDJCQUF1QjtBQUN2QjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGdCQUFnQjtBQUM1QjtBQUFBLElBQ0Y7QUFDQSxVQUFNLEtBQUssb0RBQW9EO0FBQUEsTUFDN0QsVUFBVSxLQUFLLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsSUFDYixDQUFDO0FBQ0QsVUFBTSxrQkFBa0IsS0FBSyxTQUFTLE9BQU87QUFDN0MsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQUEsRUFDakM7QUFFQSxRQUFNLFNBQVMsTUFBTSxxQkFBcUI7QUFDMUMsTUFBSSxDQUFDLFFBQVE7QUFDWCwyQkFBdUI7QUFDdkIsVUFBTSxtQkFBbUIsSUFBSTtBQUM3QixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sS0FBSyw2QkFBNkIsRUFBRSxXQUFXLEtBQUssVUFBVSxDQUFDO0FBQ3JFLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFHQSxNQUFJLE1BQU0sWUFBWSxPQUFPLE9BQU8sR0FBRztBQUNyQyxVQUFNLGtCQUFrQixPQUFPLE9BQU87QUFDdEMsU0FBSyxhQUFhO0FBQ2xCLFNBQUssV0FBVztBQUNoQixVQUFNLHFCQUFxQixJQUFJO0FBQy9CLFVBQU0sZUFBZTtBQUNyQjtBQUFBLEVBQ0Y7QUFPQSxRQUFNLE1BQ0osT0FBTyxXQUFXLGFBQ2QsOEJBQThCLE9BQU8sT0FBTyxLQUM1QyxpQkFBaUIsT0FBTyxNQUFNLFdBQVcsT0FBTyxPQUFPO0FBQzdELE1BQUksUUFBUSxNQUFNLG1CQUFtQjtBQUNyQyxNQUFJLFVBQVUsTUFBTTtBQUNsQixRQUFJO0FBQ0YsWUFBTSxRQUFRLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDOUIsUUFBUTtBQUNOLGNBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUNBLE1BQUk7QUFDRixRQUFJLFVBQVUsTUFBTTtBQUNsQixZQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssT0FBTyxFQUFFLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDNUQsVUFBSSxPQUFPLElBQUksT0FBTyxTQUFVLE9BQU0sbUJBQW1CLElBQUksRUFBRTtBQUFBLElBQ2pFLE9BQU87QUFDTCxZQUFNLFFBQVEsS0FBSyxPQUFPLE9BQU8sRUFBRSxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUNBLFdBQVEsTUFBTSxxQkFBcUIsS0FBTTtBQUN6QyxTQUFLLFdBQVc7QUFBQSxNQUNkLFNBQVMsT0FBTztBQUFBLE1BQ2hCLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUN0QztBQUNBLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLG9CQUFvQjtBQUFBLE1BQzdCLFVBQVUsT0FBTztBQUFBLE1BQ2pCLGFBQWEsT0FBTyxXQUFXLGFBQWEsT0FBTyxPQUFPO0FBQUEsTUFDMUQsV0FBVyxNQUFNLHFCQUFxQjtBQUFBLE1BQ3RDLFdBQVcsS0FBSztBQUFBLE1BQ2hCLGdCQUFnQixLQUFLO0FBQUEsSUFDdkIsQ0FBQztBQUFBLEVBQ0gsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGdEQUFnRDtBQUFBLE1BQ3pELFVBQVUsT0FBTztBQUFBLE1BQ2pCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUNELFVBQU0sa0JBQWtCLE9BQU8sT0FBTztBQUN0QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUNBLFFBQU0sZUFBZTtBQUN2QjtBQVNBLElBQU0sc0JBQXNCO0FBRTVCLGVBQWUscUJBQTZDO0FBQzFELFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksbUJBQW1CO0FBQ2xFLFFBQU0sS0FBSyxPQUFPLG1CQUFtQjtBQUNyQyxTQUFPLE9BQU8sT0FBTyxXQUFXLEtBQUs7QUFDdkM7QUFFQSxlQUFlLG1CQUFtQixJQUFrQztBQUNsRSxNQUFJLE9BQU8sS0FBTSxPQUFNLFFBQVEsUUFBUSxNQUFNLE9BQU8sbUJBQW1CO0FBQUEsTUFDbEUsT0FBTSxRQUFRLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxtQkFBbUIsR0FBRyxHQUFHLENBQUM7QUFDcEU7QUFFQSxlQUFlLHNCQUFxQztBQUNsRCwyQkFBeUI7QUFDekIsUUFBTSxRQUFRLE1BQU0scUJBQXFCO0FBQ3pDLE1BQUksVUFBVSxHQUFHO0FBQ2YsVUFBTSxLQUFLLDZCQUE2QjtBQUN4QztBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sVUFBVSxLQUFLO0FBQUEsSUFDbkI7QUFBQSxJQUNBLEtBQUssSUFBSSxxQkFBcUIsS0FBSyxNQUFNLEVBQUUscUJBQXFCLENBQUM7QUFBQSxFQUNuRTtBQUNBLFFBQU0scUJBQXFCO0FBQUEsSUFDekIsY0FBYztBQUFBLElBQ2QsV0FBVztBQUFBLElBQ1gsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ2xDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCwwQkFBd0IsT0FBTztBQUMvQixPQUFLLGVBQWU7QUFDcEIsUUFBTSxLQUFLLDRCQUE0QixFQUFFLFFBQVEsT0FBTyxjQUFjLFFBQVEsQ0FBQztBQUMvRSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxJQUFJLDJCQUFrRTtBQUV0RSxTQUFTLHdCQUF3QixTQUF1QjtBQUN0RCxNQUFJLDZCQUE2QixLQUFNLGVBQWMsd0JBQXdCO0FBQzdFLDZCQUEyQixZQUFZLE1BQU07QUFDM0MsU0FBSyxlQUFlLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDbkMsV0FBSyxLQUFLLDJCQUEyQixjQUFjLEdBQUcsQ0FBQztBQUFBLElBQ3pELENBQUM7QUFBQSxFQUNILEdBQUcsVUFBVSxHQUFJO0FBQ25CO0FBRUEsU0FBUyx5QkFBK0I7QUFDdEMsTUFBSSw2QkFBNkIsTUFBTTtBQUNyQyxrQkFBYyx3QkFBd0I7QUFDdEMsK0JBQTJCO0FBQUEsRUFDN0I7QUFDRjtBQUVBLGVBQWUsdUJBQXNDO0FBQ25ELHlCQUF1QjtBQUN2QixRQUFNLFFBQVEsT0FBTyxNQUFNLGtCQUFrQjtBQUM3QyxRQUFNLFFBQVEsTUFBTSxtQkFBbUI7QUFDdkMsUUFBTSxtQkFBbUIsSUFBSTtBQUM3QixRQUFNLE9BQU8sTUFBTSxxQkFBcUI7QUFDeEMsUUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFNLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsU0FBUyxVQUFVO0FBQUEsSUFDbkIsV0FBVyxNQUFNLGFBQWE7QUFBQSxFQUNoQyxDQUFDO0FBQ0QsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxpQkFBZ0M7QUFDN0MsTUFBSSxPQUFPLE1BQU0scUJBQXFCO0FBQ3RDLE1BQUksU0FBUyxNQUFNO0FBQ2pCLDJCQUF1QjtBQUN2QjtBQUFBLEVBQ0Y7QUFDQSxNQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLFVBQU0sVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLFdBQVc7QUFDakUsUUFBSSxVQUFVLGVBQWdCO0FBQzlCLFVBQU0sS0FBSyxvREFBb0Q7QUFBQSxNQUM3RCxVQUFVLEtBQUssU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxJQUNiLENBQUM7QUFDRCxVQUFNLG1CQUFtQixLQUFLLFNBQVMsT0FBTztBQUM5QyxVQUFNLGtCQUFrQixLQUFLLFNBQVMsT0FBTztBQUM3QyxTQUFLLGFBQWE7QUFDbEIsU0FBSyxXQUFXO0FBQ2hCLFVBQU0scUJBQXFCLElBQUk7QUFBQSxFQUNqQztBQUVBLFFBQU0sU0FBUyxNQUFNLHFCQUFxQjtBQUMxQyxNQUFJLENBQUMsUUFBUTtBQUNYLDJCQUF1QjtBQUN2QixVQUFNLG1CQUFtQixJQUFJO0FBQzdCLFVBQU0scUJBQXFCLElBQUk7QUFDL0IsVUFBTSxLQUFLLDZCQUE2QixFQUFFLFdBQVcsS0FBSyxVQUFVLENBQUM7QUFDckUsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLE1BQUksTUFBTSxrQkFBa0IsT0FBTyxPQUFPLEdBQUc7QUFDM0MsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixVQUFNLGVBQWU7QUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTSxNQUFNLGlCQUFpQixPQUFPLE1BQU0sV0FBVyxPQUFPLE9BQU87QUFDbkUsTUFBSSxRQUFRLE1BQU0sbUJBQW1CO0FBQ3JDLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFFBQUk7QUFDRixZQUFNLFFBQVEsS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUM5QixRQUFRO0FBQ04sY0FBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFFBQUksVUFBVSxNQUFNO0FBQ2xCLFlBQU0sTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLEVBQUUsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1RCxVQUFJLE9BQU8sSUFBSSxPQUFPLFNBQVUsT0FBTSxJQUFJLE1BQU0sd0JBQXdCO0FBQ3hFLGNBQVEsSUFBSTtBQUNaLFlBQU0sbUJBQW1CLEtBQUs7QUFBQSxJQUNoQyxPQUFPO0FBQ0wsWUFBTSxRQUFRLEtBQUssT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDO0FBQUEsSUFDMUM7QUFDQSxVQUFNLG1CQUFtQixPQUFPLE9BQU87QUFDdkMsV0FBUSxNQUFNLHFCQUFxQixLQUFNO0FBQ3pDLFNBQUssV0FBVztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQUEsTUFDaEIsY0FBYSxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLElBQ3RDO0FBQ0EsVUFBTSxxQkFBcUIsSUFBSTtBQUMvQixRQUFJLFVBQVUsTUFBTTtBQUNsQixXQUFLLG1CQUFtQixLQUFLO0FBQUEsSUFDL0I7QUFDQSxVQUFNLEtBQUssb0JBQW9CO0FBQUEsTUFDN0IsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixXQUFXLE1BQU0scUJBQXFCO0FBQUEsTUFDdEMsV0FBVyxLQUFLO0FBQUEsTUFDaEIsZ0JBQWdCLEtBQUs7QUFBQSxJQUN2QixDQUFDO0FBQUEsRUFDSCxTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssZ0RBQWdEO0FBQUEsTUFDekQsUUFBUSxPQUFPO0FBQUEsTUFDZixVQUFVLE9BQU87QUFBQSxNQUNqQixHQUFHLGNBQWMsR0FBRztBQUFBLElBQ3RCLENBQUM7QUFDRCxVQUFNLG1CQUFtQixPQUFPLE9BQU87QUFDdkMsVUFBTSxrQkFBa0IsT0FBTyxPQUFPO0FBQ3RDLFNBQUssYUFBYTtBQUNsQixTQUFLLFdBQVc7QUFDaEIsVUFBTSxxQkFBcUIsSUFBSTtBQUFBLEVBQ2pDO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSxtQkFBbUIsT0FBOEI7QUFDOUQsUUFBTSxJQUFJLFFBQVEsQ0FBQyxZQUFZLFdBQVcsU0FBUyxJQUFJLENBQUM7QUFDeEQsTUFBSTtBQUNGLFVBQU0sUUFBUSxVQUFVLGNBQWM7QUFBQSxNQUNwQyxRQUFRLEVBQUUsTUFBTTtBQUFBLE1BQ2hCLE9BQU87QUFBQSxNQUNQLE1BQU0sTUFBTTtBQUNWLGNBQU0sSUFBSSxPQUFPO0FBQ2pCLGNBQU0sT0FBTyxNQUFNLE9BQU8sU0FBUyxFQUFFLEtBQUssSUFBSSxLQUFLLFVBQVUsU0FBUyxDQUFDO0FBQ3ZFLGFBQUs7QUFDTCxtQkFBVyxNQUFNLElBQUk7QUFDckIsbUJBQVcsTUFBTSxJQUFJO0FBQUEsTUFDdkI7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBSztBQUNaLFVBQU0sS0FBSyxtQ0FBbUMsY0FBYyxHQUFHLENBQUM7QUFBQSxFQUNsRTtBQUNGO0FBSUEsZUFBZSxXQUNiLFFBQ0EsVUFDQSxLQUNBLEtBQ0EsS0FDZTtBQUNmLFFBQU0sTUFBTyx3QkFBd0IsRUFBRSxRQUFRLFVBQVUsS0FBSyxHQUFHLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDckYsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxLQUFNO0FBQ3hELFFBQU0sVUFBNkI7QUFBQSxJQUNqQyxnQkFBZ0I7QUFBQSxJQUNoQjtBQUFBLElBQ0E7QUFBQSxJQUNBLGNBQWEsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNwQyxZQUFZO0FBQUEsSUFDWixPQUFPLGNBQWMsR0FBRztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQUNBLFFBQU0sS0FBSyxXQUFXLFFBQVEsV0FBVztBQUN6QyxRQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUssVUFBVSxPQUFPLENBQUM7QUFDL0MsUUFBTSxPQUFPLG1CQUFtQixFQUFFLElBQUksSUFBSTtBQUMxQyxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxRQUFRO0FBQUEsTUFDbkI7QUFBQSxNQUNBLGVBQWVILFVBQVMsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLElBQUksSUFBSTtBQUFBLE1BQy9ELFNBQVMsZUFBZSxNQUFNLElBQUksUUFBUTtBQUFBLElBQzVDLENBQUM7QUFBQSxFQUNILFNBQVMsTUFBTTtBQUNiLFVBQU0sTUFBTyw0QkFBNEIsRUFBRSxHQUFHLGNBQWMsSUFBSSxFQUFFLENBQUM7QUFBQSxFQUNyRTtBQUNGO0FBRUEsZUFBZSxLQUFLLEdBQTRCO0FBQzlDLFFBQU0sTUFBTSxJQUFJLFlBQVksRUFBRSxPQUFPLENBQUM7QUFDdEMsUUFBTSxTQUFTLE1BQU0sT0FBTyxPQUFPLE9BQU8sV0FBVyxHQUFHO0FBQ3hELFFBQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxXQUFXLE1BQU0sQ0FBQyxFQUMxQyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFO0FBQ1YsU0FBTyxJQUFJLE1BQU0sR0FBRyxDQUFDO0FBQ3ZCO0FBSUEsZUFBZSxpQkFBaUIsT0FBK0I7QUFDN0QsUUFBTSxXQUFXLE1BQU0sWUFBWTtBQUNuQyxNQUFJLENBQUMsU0FBUyxPQUFPLENBQUMsU0FBUyxTQUFTLENBQUMsU0FBUyxNQUFNO0FBQ3RELFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU87QUFBQSxNQUNQLFlBQVcsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxNQUNsQyxPQUFPO0FBQUEsTUFDUCxlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxlQUFlO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLFFBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsTUFBSSxDQUFDLE9BQU87QUFJVixRQUFJLEtBQUssV0FBVyxrQkFBa0IsS0FBSyxxQkFBcUIsTUFBTTtBQUNwRSxZQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDM0MsVUFBSSxTQUFTLEtBQUssaUJBQWtCO0FBQUEsSUFDdEM7QUFLQSxRQUFJLEtBQUssV0FBVztBQUNsQixZQUFNLE1BQU0sS0FBSyxJQUFJLElBQUksS0FBSyxNQUFNLEtBQUssU0FBUztBQUNsRCxVQUFJLE1BQU0sOEJBQStCO0FBQUEsSUFDM0M7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sU0FBUyxJQUFJLGFBQWEsUUFBUTtBQUN4QyxVQUFNLElBQUksTUFBTSxPQUFPLGlCQUFpQjtBQUl4QyxRQUFJLFdBQVc7QUFDZixRQUFJLFNBQVMsVUFBVSxTQUFTLFdBQVcsRUFBRSxnQkFBZ0I7QUFDM0QsaUJBQVcsTUFBTSxPQUFPLGFBQWEsU0FBUyxNQUFNO0FBQUEsSUFDdEQ7QUFDQSxVQUFNLGFBQWEsU0FBUyxpQkFBaUIsS0FBSyxLQUFLO0FBQ3ZELFFBQUksWUFBWSxZQUFZO0FBQzFCLFlBQU0sT0FBTyxrQkFBa0I7QUFBQSxJQUNqQztBQUNBLFVBQU0sY0FBYztBQUFBLE1BQ2xCLFFBQVE7QUFBQSxNQUNSLE9BQU8sRUFBRTtBQUFBLE1BQ1QsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU87QUFBQSxNQUNQLGVBQWUsRUFBRTtBQUFBLE1BQ2pCLHdCQUF3QjtBQUFBLE1BQ3hCLGtCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFDRCxVQUFNLEtBQUssdUJBQXVCO0FBQUEsTUFDaEMsT0FBTyxFQUFFO0FBQUEsTUFDVCxNQUFNLEVBQUU7QUFBQSxNQUNSLGdCQUFnQixFQUFFO0FBQUEsTUFDbEIsbUJBQW1CLFNBQVM7QUFBQSxNQUM1QiwwQkFBMEI7QUFBQSxNQUMxQixjQUFjLGFBQWEsWUFBWTtBQUFBLElBQ3pDLENBQUM7QUFDRCxRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sS0FBSyw4Q0FBOEM7QUFBQSxRQUN2RCxZQUFZLFNBQVM7QUFBQSxRQUNyQixnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLEtBQUssd0NBQXdDLEVBQUU7QUFBQSxNQUNqRCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0YsU0FBUyxLQUFLO0FBQ1osVUFBTSxNQUFNLGVBQWUsY0FBYyxJQUFJLFdBQVc7QUFDeEQsVUFBTSxTQUNKLFFBQVEsU0FDSixlQUNBLFFBQVEsZUFDTixpQkFDQSxRQUFRLFlBQ04sa0JBQ0E7QUFDVixVQUFNLFVBQ0osZUFBZSxlQUFlLFFBQVEsZUFBZSxJQUFJLG1CQUFtQjtBQUM5RSxVQUFNLGNBQWM7QUFBQSxNQUNsQjtBQUFBLE1BQ0EsT0FBTztBQUFBLE1BQ1AsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLE1BQ2xDLE9BQU8sY0FBYyxHQUFHLEVBQUU7QUFBQSxNQUMxQixlQUFlO0FBQUEsTUFDZix3QkFBd0I7QUFBQSxNQUN4QixrQkFBa0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsVUFBTSxLQUFLLDJCQUEyQjtBQUFBLE1BQ3BDLFVBQVU7QUFBQSxNQUNWLGtCQUFrQjtBQUFBLE1BQ2xCLEdBQUcsY0FBYyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0g7QUFDQSxRQUFNLGVBQWU7QUFDdkI7QUFFQSxlQUFlLG9CQUFvQixPQUErQjtBQUNoRSxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLE1BQUksQ0FBQyxTQUFTLEtBQUs7QUFDakIsVUFBTSxZQUFZLENBQUMsR0FBRyxpQkFBaUIsQ0FBQztBQUN4QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLENBQUMsT0FBTztBQUlWLFVBQU0sT0FBTyxNQUFNLGNBQWM7QUFDakMsUUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsWUFBTSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQzNDLFVBQUksU0FBUyxLQUFLLGlCQUFrQjtBQUFBLElBQ3RDO0FBSUEsVUFBTSxnQkFBZ0IsTUFBTSx1QkFBdUI7QUFDbkQsUUFBSSxlQUFlO0FBQ2pCLFlBQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU0sYUFBYTtBQUNqRCxVQUFJLE9BQU8sU0FBUyxHQUFHLEtBQUssTUFBTSw4QkFBK0I7QUFBQSxJQUNuRTtBQUFBLEVBQ0Y7QUFDQSxNQUFJO0FBQ0YsVUFBTSxTQUFTLElBQUksYUFBYSxRQUFRO0FBQ3hDLFVBQU0sT0FBTyxNQUFNLE9BQU8sYUFBYSxzQkFBc0I7QUFDN0QsUUFBSSxDQUFDLE1BQU07QUFDVCxVQUFJLE1BQU8sT0FBTSxLQUFLLGlEQUFpRDtBQUN2RSxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxTQUFTLGtCQUFrQixJQUFJO0FBQ3JDLFFBQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsWUFBTSxLQUFLLDhDQUE4QztBQUN6RCxZQUFNLFlBQVksQ0FBQyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLFlBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQ7QUFBQSxJQUNGO0FBQ0EsVUFBTSxZQUFZLE1BQU07QUFDeEIsVUFBTSx1QkFBdUIsUUFBUSxLQUFLO0FBQzFDLFVBQU0sd0JBQXVCLG9CQUFJLEtBQUssR0FBRSxZQUFZLENBQUM7QUFDckQsUUFBSSxNQUFPLE9BQU0sS0FBSywyQkFBMkIsRUFBRSxPQUFPLE9BQU8sT0FBTyxDQUFDO0FBQUEsRUFDM0UsU0FBUyxLQUFLO0FBQ1osVUFBTSxLQUFLLGlEQUFpRCxjQUFjLEdBQUcsQ0FBQztBQUFBLEVBQ2hGO0FBQ0EsUUFBTSxlQUFlO0FBQ3ZCO0FBRUEsZUFBZSx1QkFBdUIsUUFBc0IsT0FBK0I7QUFDekYsUUFBTSxPQUFPLE1BQU0sT0FBTyxhQUFhLG9CQUFvQjtBQUMzRCxNQUFJLENBQUMsTUFBTTtBQUNULFVBQU0sbUJBQW1CLElBQUk7QUFDN0IsUUFBSSxNQUFPLE9BQU0sS0FBSywwREFBMEQ7QUFDaEY7QUFBQSxFQUNGO0FBQ0EsTUFBSTtBQUNGLFVBQU0sV0FBVyxxQkFBcUIsS0FBSyxNQUFNLElBQUksQ0FBWTtBQUNqRSxVQUFNLG1CQUFtQixRQUFRO0FBQ2pDLFFBQUksT0FBTztBQUNULFlBQU0sS0FBSyw4QkFBOEI7QUFBQSxRQUN2QyxVQUFVLE9BQU8sS0FBSyxTQUFTLFFBQVEsRUFBRTtBQUFBLFFBQ3pDLGNBQWMsU0FBUztBQUFBLE1BQ3pCLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRixTQUFTLEtBQUs7QUFDWixVQUFNLEtBQUssK0RBQStELGNBQWMsR0FBRyxDQUFDO0FBQUEsRUFDOUY7QUFDRjtBQUlBLGVBQWUsaUJBQWdDO0FBQzdDLFFBQU0sUUFBUSxNQUFNLFdBQVc7QUFDL0IsVUFBUSxRQUFRLFlBQVksRUFBRSxNQUFNLGlCQUFpQixNQUFNLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDOUU7QUFFQSxlQUFlLGFBQXNDO0FBQ25ELFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFNLFdBQVcsTUFBTSxZQUFZO0FBQ25DLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFDbkMsTUFBSSxXQUFXO0FBQ2YsTUFBSTtBQUNGLFVBQU0sT0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLG1CQUFtQix1QkFBdUIsRUFBRSxDQUFDO0FBQzNGLGVBQVcsS0FBSztBQUFBLEVBQ2xCLFFBQVE7QUFBQSxFQUdSO0FBQ0EsUUFBTSxnQkFBZ0IsTUFBTSxrQkFBa0I7QUFDOUMsUUFBTSxtQkFBbUIsTUFBTSxxQkFBcUI7QUFDcEQsUUFBTSxtQkFBbUIsTUFBTSxxQkFBcUI7QUFDcEQsUUFBTSxjQUFjLE1BQU0sa0JBQWtCO0FBQzVDLFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0saUJBQWlCLE1BQU0scUJBQXFCO0FBQ2xELFFBQU0sdUJBQXVCLE1BQU0sd0JBQXdCO0FBQzNELFNBQU87QUFBQSxJQUNMLFNBQVM7QUFBQSxJQUNULFVBQVUsZUFBZSxRQUFRO0FBQUEsSUFDakMsWUFBWTtBQUFBLElBQ1o7QUFBQSxJQUNBO0FBQUEsSUFDQSxZQUFZO0FBQUEsTUFDVixRQUFRLG1CQUFtQixRQUFRLG9CQUFvQjtBQUFBLE1BQ3ZEO0FBQUEsTUFDQSxhQUFhLGdCQUFnQixlQUFlO0FBQUEsTUFDNUMsZUFBZSxnQkFBZ0IsaUJBQWlCO0FBQUEsTUFDaEQsa0JBQWtCLGdCQUFnQixvQkFBb0I7QUFBQSxNQUN0RCx1QkFBdUIsZ0JBQWdCLHlCQUF5QjtBQUFBLE1BQ2hFLGlCQUFpQixnQkFBZ0IsbUJBQW1CO0FBQUEsTUFDcEQsZUFBZSxnQkFBZ0IsaUJBQWlCO0FBQUEsSUFDbEQ7QUFBQSxJQUNBLGNBQWM7QUFBQSxNQUNaLE9BQU87QUFBQSxNQUNQLFNBQVMsMEJBQTBCO0FBQUEsTUFDbkMsV0FBVyxhQUFhLGFBQWE7QUFBQSxNQUNyQyxnQkFBZ0IsYUFBYSxnQkFBZ0I7QUFBQSxJQUMvQztBQUFBLElBQ0EsaUJBQWlCO0FBQUEsTUFDZixPQUFPO0FBQUEsTUFDUCxTQUFTLDZCQUE2QjtBQUFBLE1BQ3RDLFdBQVcsZ0JBQWdCLGFBQWE7QUFBQSxNQUN4QyxnQkFBZ0IsZ0JBQWdCLGdCQUFnQjtBQUFBLElBQ2xEO0FBQUEsSUFDQSxpQkFBaUI7QUFBQSxNQUNmLE9BQU87QUFBQSxNQUNQLFNBQVMsNkJBQTZCO0FBQUEsTUFDdEMsV0FBVyxnQkFBZ0IsYUFBYTtBQUFBLE1BQ3hDLGdCQUFnQixnQkFBZ0IsZ0JBQWdCO0FBQUEsSUFDbEQ7QUFBQSxJQUNBO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyxlQUFlLEdBQXlDO0FBQy9ELFNBQU87QUFBQSxJQUNMLE9BQU8sRUFBRTtBQUFBLElBQ1QsTUFBTSxFQUFFO0FBQUEsSUFDUixRQUFRLEVBQUU7QUFBQSxJQUNWLFNBQVMsRUFBRTtBQUFBLElBQ1gsYUFBYSxFQUFFO0FBQUEsSUFDZixjQUFjLEVBQUU7QUFBQSxJQUNoQix1QkFBdUIsRUFBRTtBQUFBLElBQ3pCLGdCQUFnQixFQUFFO0FBQUEsSUFDbEIsc0JBQXNCLEVBQUU7QUFBQSxJQUN4QixRQUFRLEVBQUUsSUFBSSxTQUFTO0FBQUEsSUFDdkIsV0FBVyxFQUFFLElBQUksVUFBVSxJQUFJLEVBQUUsSUFBSSxNQUFNLEVBQUUsSUFBSTtBQUFBLEVBQ25EO0FBQ0Y7QUFFQSxTQUFTLHFCQUFxQixLQUErQjtBQUMzRCxNQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsU0FBVSxPQUFNLElBQUksTUFBTSwyQkFBMkI7QUFDaEYsUUFBTSxXQUFXO0FBQ2pCLE1BQUksQ0FBQyxNQUFNLFFBQVEsU0FBUyxRQUFRLEVBQUcsT0FBTSxJQUFJLE1BQU0sbUNBQW1DO0FBQzFGLFFBQU0sV0FBd0MsQ0FBQztBQUMvQyxhQUFXLFNBQVMsU0FBUyxVQUFVO0FBQ3JDLFFBQUksQ0FBQyxTQUFTLE9BQU8sVUFBVSxTQUFVO0FBQ3pDLFVBQU0sTUFBTTtBQUNaLFVBQU0sU0FBUyxPQUFPLElBQUksV0FBVyxXQUFXLElBQUksU0FBUztBQUM3RCxRQUFJLENBQUMsVUFBVSxXQUFXLFFBQVM7QUFDbkMsYUFBUyxPQUFPLFlBQVksQ0FBQyxJQUFJO0FBQUEsTUFDL0I7QUFBQSxNQUNBLGdCQUFnQixPQUFPLElBQUksbUJBQW1CLFdBQVcsSUFBSSxpQkFBaUI7QUFBQSxNQUM5RSxtQkFBbUIsT0FBTyxJQUFJLHNCQUFzQixXQUFXLElBQUksb0JBQW9CO0FBQUEsTUFDdkYsV0FBVyxPQUFPLElBQUksY0FBYyxXQUFXLElBQUksWUFBWTtBQUFBLElBQ2pFO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFBQSxJQUNMLGNBQWMsT0FBTyxTQUFTLGlCQUFpQixXQUFXLFNBQVMsZUFBZTtBQUFBLElBQ2xGLGFBQVksb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFDRjtBQUVBLFNBQVMsd0JBQXdCLEdBQW1CLFVBQTJDO0FBQzdGLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFDdEIsUUFBTSxRQUFRLFNBQVMsU0FBUyxFQUFFLGVBQWUsWUFBWSxDQUFDO0FBQzlELE1BQUksQ0FBQyxPQUFPLGVBQWdCLFFBQU87QUFDbkMsUUFBTSxTQUFTLEtBQUssTUFBTSxFQUFFLFNBQVM7QUFDckMsUUFBTSxTQUFTLEtBQUssTUFBTSxNQUFNLGNBQWM7QUFDOUMsU0FBTyxPQUFPLFNBQVMsTUFBTSxLQUFLLE9BQU8sU0FBUyxNQUFNLEtBQUssVUFBVTtBQUN6RTtBQUVBLFNBQVMsbUJBQ1AsR0FDQSxVQUNBLFFBQ0EsWUFBZ0MsT0FDaEMsU0FBa0MsWUFDbkI7QUFDZixTQUFPO0FBQUEsSUFDTCxVQUFVLEVBQUU7QUFBQSxJQUNaLGdCQUFnQixFQUFFO0FBQUEsSUFDbEIsV0FBVyxFQUFFO0FBQUEsSUFDYixNQUFNLEVBQUUsaUJBQWlCLEVBQUU7QUFBQSxJQUMzQixZQUFZLEVBQUU7QUFBQSxJQUNkLFdBQVcsRUFBRTtBQUFBLElBQ2IsU0FBUztBQUFBLElBQ1Q7QUFBQSxJQUNBLGdCQUFnQixjQUFjLGFBQWEsVUFBVTtBQUFBLElBQ3JEO0FBQUEsRUFDRjtBQUNGO0FBRUEsU0FBUyxpQkFBaUIsU0FBaUM7QUFDekQsU0FDRSxPQUFPLFlBQVksWUFDbkIsNkVBQTZFLEtBQUssT0FBTztBQUU3RjtBQUVBLFNBQVMsV0FBVyxLQUFxQjtBQUV2QyxRQUFNLElBQUksSUFBSSxLQUFLLEdBQUc7QUFDdEIsTUFBSSxPQUFPLE1BQU0sRUFBRSxRQUFRLENBQUMsRUFBRyxRQUFPLElBQUksUUFBUSxTQUFTLEVBQUU7QUFDN0QsUUFBTSxNQUFNLENBQUMsR0FBVyxJQUFJLE1BQU0sT0FBTyxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUc7QUFDM0QsU0FDRSxHQUFHLEVBQUUsZUFBZSxDQUFDLElBQUksSUFBSSxFQUFFLFlBQVksSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFDcEUsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLGNBQWMsQ0FBQyxDQUFDO0FBRTlFO0FBRUEsU0FBUyxVQUFVLEdBQXFCO0FBQ3RDLFNBQU8sV0FBVyxFQUFFLEtBQUssY0FBYyxFQUFFLElBQUk7QUFDL0M7QUFTQSxTQUFTLGVBQWUsTUFBeUI7QUFDL0MsUUFBTSxPQUFPLG9CQUFJLElBQVk7QUFDN0IsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLFNBQU8sTUFBTSxTQUFTLEdBQUc7QUFDdkIsVUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixRQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sU0FBVTtBQUN6QyxRQUFJLFFBQVEsSUFBSSxDQUFXLEVBQUc7QUFDOUIsWUFBUSxJQUFJLENBQVc7QUFDdkIsUUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0FBQ3BCLGlCQUFXLEtBQUssRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2pDLE9BQU87QUFDTCxZQUFNSSxPQUFNO0FBQ1osVUFBSSxPQUFPQSxLQUFJLGVBQWUsU0FBVSxNQUFLLElBQUlBLEtBQUksVUFBVTtBQUMvRCxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsU0FBTyxDQUFDLEdBQUcsSUFBSSxFQUFFLEtBQUs7QUFDeEI7QUFPQSxTQUFTLG9CQUFvQixNQUFlLFVBQW1DO0FBQzdFLFFBQU0sVUFBVSxvQkFBSSxRQUFnQjtBQUNwQyxRQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixTQUFPLE1BQU0sU0FBUyxHQUFHO0FBQ3ZCLFVBQU0sSUFBSSxNQUFNLElBQUk7QUFDcEIsUUFBSSxNQUFNLFFBQVEsT0FBTyxNQUFNLFNBQVU7QUFDekMsUUFBSSxRQUFRLElBQUksQ0FBVyxFQUFHO0FBQzlCLFlBQVEsSUFBSSxDQUFXO0FBQ3ZCLFFBQUksTUFBTSxRQUFRLENBQUMsR0FBRztBQUNwQixpQkFBVyxLQUFLLEVBQUcsT0FBTSxLQUFLLENBQUM7QUFBQSxJQUNqQyxPQUFPO0FBQ0wsWUFBTUEsT0FBTTtBQUNaLFVBQUlBLEtBQUksZUFBZSxVQUFVO0FBQy9CLGVBQU8sT0FBTyxLQUFLQSxJQUFHLEVBQUUsS0FBSztBQUFBLE1BQy9CO0FBQ0EsaUJBQVcsS0FBSyxPQUFPLE9BQU9BLElBQUcsRUFBRyxPQUFNLEtBQUssQ0FBQztBQUFBLElBQ2xEO0FBQUEsRUFDRjtBQUNBLFNBQU87QUFDVDtBQVFBLFNBQVMsaUJBQWlCLE1BQWUsVUFBa0IsTUFBeUI7QUFDbEYsUUFBTSxVQUFVLG9CQUFJLFFBQWdCO0FBQ3BDLFFBQU0sUUFBbUIsQ0FBQyxJQUFJO0FBQzlCLE1BQUksUUFBd0M7QUFDNUMsU0FBTyxNQUFNLFNBQVMsR0FBRztBQUN2QixVQUFNLElBQUksTUFBTSxJQUFJO0FBQ3BCLFFBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxTQUFVO0FBQ3pDLFFBQUksUUFBUSxJQUFJLENBQVcsRUFBRztBQUM5QixZQUFRLElBQUksQ0FBVztBQUN2QixRQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUc7QUFDcEIsaUJBQVcsS0FBSyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDakMsT0FBTztBQUNMLFlBQU1BLE9BQU07QUFDWixVQUFJQSxLQUFJLGVBQWUsVUFBVTtBQUMvQixnQkFBUUE7QUFDUjtBQUFBLE1BQ0Y7QUFDQSxpQkFBVyxLQUFLLE9BQU8sT0FBT0EsSUFBRyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsSUFDbEQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxDQUFDLE1BQU8sUUFBTztBQUNuQixNQUFJLE1BQWU7QUFDbkIsYUFBVyxPQUFPLE1BQU07QUFDdEIsUUFBSSxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVUsUUFBTyxJQUFJLFFBQVEsT0FBTyxTQUFTLE9BQU8sR0FBRztBQUMxRixVQUFPLElBQWdDLEdBQUc7QUFBQSxFQUM1QztBQUNBLE1BQUksUUFBUSxPQUFXLFFBQU87QUFDOUIsTUFBSSxRQUFRLEtBQU0sUUFBTztBQUN6QixNQUFJLE9BQU8sUUFBUSxTQUFVLFFBQU8sSUFBSSxPQUFPLEdBQUc7QUFDbEQsTUFBSSxNQUFNLFFBQVEsR0FBRyxFQUFHLFFBQU8sY0FBYyxJQUFJLE1BQU07QUFDdkQsU0FBTyxPQUFPLEtBQUssR0FBOEIsRUFBRSxLQUFLO0FBQzFEO0FBRUEsU0FBUyxXQUFXLEdBQW1CO0FBR3JDLE1BQUk7QUFDRixVQUFNLFNBQVMsSUFBSSxJQUFJLENBQUM7QUFDeEIsVUFBTSxPQUFPLE9BQU8sWUFBWSxPQUFPLFNBQVMsWUFBTztBQUN2RCxXQUFPLE9BQU8sU0FBUyxXQUFXLE9BQU8sU0FBUyxnQkFDOUMsT0FDQSxHQUFHLE9BQU8sSUFBSSxHQUFHLElBQUk7QUFBQSxFQUMzQixRQUFRO0FBQ04sV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQ7QUFDRjtBQUtDLFdBQXVDLGVBQWU7QUFBQSxFQUNyRDtBQUFBLEVBQ0EsVUFBVTtBQUFBLEVBQ1YsVUFBVTtBQUFBLEVBQ1YsU0FBUztBQUFBLEVBQ1QsVUFBVSxNQUFNLFNBQVMsVUFBVTtBQUFBLEVBQ25DLE9BQU87QUFBQSxFQUNQLGNBQWM7QUFBQSxFQUNkLGNBQWM7QUFBQSxFQUNkLGVBQWU7QUFBQSxFQUNmLGlCQUFpQjtBQUFBLEVBQ2pCLGlCQUFpQjtBQUFBLEVBQ2pCLGtCQUFrQjtBQUFBLEVBQ2xCLGlCQUFpQjtBQUFBLEVBQ2pCLGlCQUFpQjtBQUFBLEVBQ2pCLGtCQUFrQjtBQUNwQjsiLAogICJuYW1lcyI6IFsidG9CYXNlNjQiLCAib2JqIiwgImluZm8iLCAidG9CYXNlNjQiLCAidW5hdmFpbGFibGVDb3VudCIsICJlZGdlQ291bnQiLCAic3VmZml4IiwgIm9iaiJdCn0K
