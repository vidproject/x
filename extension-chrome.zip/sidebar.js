var browser=globalThis.browser??globalThis.chrome;

// src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var recentTweetList = $("recent-tweet-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var updateExistingToggle = $("update-existing");
var lowBandwidthToggle = $("low-bandwidth");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var threadOpenSection = $("thread-open-section");
var threadOpenCount = $("thread-open-count");
var threadOpenStartBtn = $("thread-open-start");
var threadOpenCancelBtn = $("thread-open-cancel");
var threadOpenProgress = $("thread-open-progress");
var purgeLink = $("purge-unrelated");
var coverageGapsFindBtn = $("coverage-gaps-find");
var coverageGapsList = $("coverage-gaps-list");
var coverageGapsCount = $("coverage-gaps-count");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
var GAP_KIND_LABEL = {
  recent: "new since last capture",
  empty: "empty",
  sparse: "sparse"
};
function renderCoverageGaps(gaps) {
  coverageGapsList.replaceChildren();
  if (gaps.length === 0) {
    coverageGapsCount.textContent = "no holes";
    const li = document.createElement("li");
    li.className = "muted gap-empty";
    li.textContent = "Coverage looks complete across tracked accounts.";
    coverageGapsList.append(li);
    return;
  }
  coverageGapsCount.textContent = `${gaps.length} gap${gaps.length === 1 ? "" : "s"}`;
  for (const g of gaps) {
    const li = document.createElement("li");
    li.className = `gap-row gap-${g.kind}`;
    const info = document.createElement("div");
    info.className = "gap-info";
    const head = document.createElement("div");
    head.className = "gap-head";
    head.textContent = g.fromMonth === g.toMonth ? `@${g.handle} \xB7 ${g.fromMonth}` : `@${g.handle} \xB7 ${g.fromMonth} \u2192 ${g.toMonth}`;
    const meta = document.createElement("div");
    meta.className = "gap-meta muted";
    const span = g.monthCount > 0 ? `${g.monthCount} mo` : "partial";
    meta.textContent = `${GAP_KIND_LABEL[g.kind]} \xB7 ${span} \xB7 ${g.capturedInRange} captured`;
    info.append(head, meta);
    const open = document.createElement("button");
    open.type = "button";
    open.className = "btn gap-open";
    open.textContent = "Open";
    open.title = `Open X search ${g.fromDate}\u2013${g.toDate} for @${g.handle}`;
    open.addEventListener("click", () => {
      void send({ type: "open-url", url: g.searchUrl });
    });
    li.append(info, open);
    coverageGapsList.append(li);
  }
}
coverageGapsFindBtn.addEventListener("click", async () => {
  coverageGapsFindBtn.disabled = true;
  coverageGapsCount.textContent = "scanning\u2026";
  try {
    const res = await send({
      type: "get-coverage-gaps"
    });
    if (!res.ok || !res.gaps) {
      coverageGapsCount.textContent = res.error ?? "failed";
      coverageGapsList.replaceChildren();
      return;
    }
    renderCoverageGaps(res.gaps);
  } finally {
    coverageGapsFindBtn.disabled = false;
  }
});
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = isWriteAuthError(connection.error) ? "PAT can read repo but cannot write - set Contents: Read & Write" : "Auth error - check your PAT";
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  updateExistingToggle.checked = state.settings.updateExisting !== false;
  lowBandwidthToggle.checked = state.settings.lowBandwidthBrowsing === true;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  renderRecentTweets(state.recentTweetSightings);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
  paintThreadOpen(state);
}
function renderRecentTweets(rows) {
  recentTweetList.replaceChildren();
  if (rows.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No tweets seen yet.";
    recentTweetList.append(li);
    return;
  }
  for (const row of rows.slice(0, 40)) {
    const li = document.createElement("li");
    li.className = `recent-tweet ${row.archive_status}`;
    const top = document.createElement("div");
    top.className = "tweet-head";
    const link = document.createElement("a");
    link.className = "tweet-handle";
    link.href = row.tweet_url;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = `@${row.account_handle}`;
    const status = document.createElement("span");
    status.className = `tweet-pill ${row.archive_status}`;
    status.textContent = row.archive_status === "saved" ? "saved" : "new";
    top.append(link, status);
    const text = document.createElement("div");
    text.className = "tweet-text";
    text.textContent = truncateText(row.text, 140);
    const meta = document.createElement("div");
    meta.className = "tweet-meta";
    meta.textContent = `${formatTweetAction(row.action)} \xB7 ${row.tweet_type} \xB7 posted ${fmtRel(row.posted_at)}`;
    li.append(top, text, meta);
    recentTweetList.append(li);
  }
}
function formatTweetAction(action) {
  if (action === "buffered") return "buffered";
  if (action === "unchanged") return "unchanged";
  return "skipped";
}
function truncateText(text, max) {
  const compact = text.replace(/\s+/g, " ").trim();
  return compact.length <= max ? compact : `${compact.slice(0, max - 1)}\u2026`;
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    const parts = [
      `${fmtNum(as.scrollCount)} scrolls`,
      `${fmtNum(as.ingestedNewCount)} new buffered`,
      `${fmtNum(as.ingestedExistingCount)} old buffered`
    ];
    if (as.skippedOldCount > 0) parts.push(`${fmtNum(as.skippedOldCount)} old skipped`);
    parts.push(`${fmtNum(as.expandedCount)} expanded`);
    autoScrollProgress.textContent = parts.join(" \xB7 ");
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
function paintThreadOpen(state) {
  const q = state.threadOpenQueue;
  const total = q.total;
  const running = q.running;
  threadOpenSection.hidden = total === 0 && !running;
  threadOpenCount.textContent = total === 0 ? running ? "finishing..." : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  threadOpenStartBtn.hidden = running;
  threadOpenStartBtn.disabled = total === 0;
  threadOpenCancelBtn.hidden = !running;
  paintQueueProgress(threadOpenProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
updateExistingToggle.addEventListener("change", () => {
  void send({ type: "toggle-update-existing", on: updateExistingToggle.checked });
});
lowBandwidthToggle.addEventListener("change", () => {
  void send({ type: "toggle-low-bandwidth", on: lowBandwidthToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl / thread-opening queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
threadOpenStartBtn.addEventListener("click", () => {
  threadOpenStartBtn.disabled = true;
  void send({ type: "start-thread-open" }).finally(() => {
    threadOpenStartBtn.disabled = false;
  });
});
threadOpenCancelBtn.addEventListener("click", () => {
  threadOpenCancelBtn.disabled = true;
  void send({ type: "cancel-thread-open" }).finally(() => {
    threadOpenCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgZW5hYmxlZDogdHJ1ZSxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxuICB1cGRhdGVFeGlzdGluZzogdHJ1ZSxcbiAgbG93QmFuZHdpZHRoQnJvd3Npbmc6IGZhbHNlLFxufTtcblxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01JTl9TRUMgPSAzO1xuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01BWF9TRUMgPSA2MDtcblxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcbi8vIHJlcG8gaGFzIGJlZW4gaW5pdGlhbGl6ZWQgb3IgUEFUIG1pc2NvbmZpZ3VyZWQpLiBLZXB0IGluIHN5bmMgd2l0aCB0aGUgZmlsZS5cbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdJQ0Vnb3YnLCBsYWJlbDogJ1UuUy4gSW1taWdyYXRpb24gYW5kIEN1c3RvbXMgRW5mb3JjZW1lbnQnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdXaGl0ZUhvdXNlJywgbGFiZWw6ICdUaGUgV2hpdGUgSG91c2UnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1VTRE9MJywgbGFiZWw6ICdVLlMuIERlcGFydG1lbnQgb2YgTGFib3InLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdTdGVwaGVuTScsIGxhYmVsOiAnU3RlcGhlbiBNaWxsZXInLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnR3JlZ29yeUtCb3Zpbm8nLCBsYWJlbDogJ0dyZWdvcnkgQm92aW5vJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1JlYWxUb21Ib21hbicsIGxhYmVsOiAnVGhvbWFzIEQuIEhvbWFuJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBzaWRlYmFyLnRzIFx1MjAxNCBVSSBmb3IgdGhlIHBlcnNpc3RlbnQgc2lkZWJhci5cbiAqXG4gKiBTaWRlYmFycyBpbiBGaXJlZm94IHN0YXkgb3BlbiBhY3Jvc3MgdGFiL3dpbmRvdyBzd2l0Y2hlcywgd2hpY2ggaXMgdGhlXG4gKiBpbnRlbmRlZCBwZXJzaXN0ZW5jZSBtb2RlbC4gVGhpcyBtb2R1bGUgcmVuZGVycyBzdGF0ZSBwdXNoZWQgZnJvbSB0aGVcbiAqIGJhY2tncm91bmQgc2VydmljZSB3b3JrZXIgYW5kIGZvcndhcmRzIHVzZXIgY29tbWFuZHMgYmFjay5cbiAqL1xuXG5pbXBvcnQgeyBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7XG4gIENvdmVyYWdlR2FwLFxuICBFeHRlbnNpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFJ1bnRpbWVNZXNzYWdlLFxuICBUd2VldFNpZ2h0aW5nLFxufSBmcm9tICcuL2xpYi90eXBlcy5qcyc7XG5cbmNvbnN0ICQgPSA8VCBleHRlbmRzIEhUTUxFbGVtZW50ID0gSFRNTEVsZW1lbnQ+KGlkOiBzdHJpbmcpOiBUID0+IHtcbiAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCk7XG4gIGlmICghZWwpIHRocm93IG5ldyBFcnJvcihgbWlzc2luZyBlbGVtZW50ICMke2lkfWApO1xuICByZXR1cm4gZWwgYXMgVDtcbn07XG5cbmNvbnN0IGNvbm5Eb3QgPSAkKCdjb25uLWRvdCcpO1xuY29uc3QgY29ublRleHQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2Nvbm4tdGV4dCcpO1xuY29uc3QgYWNjb3VudExpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdhY2NvdW50LWxpc3QnKTtcbmNvbnN0IHJlY2VudFR3ZWV0TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ3JlY2VudC10d2VldC1saXN0Jyk7XG5jb25zdCBhY3Rpdml0eUxpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdhY3Rpdml0eS1saXN0Jyk7XG5jb25zdCBhdXRvVG9nZ2xlID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1jYXB0dXJlJyk7XG5jb25zdCB1cGRhdGVFeGlzdGluZ1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ3VwZGF0ZS1leGlzdGluZycpO1xuY29uc3QgbG93QmFuZHdpZHRoVG9nZ2xlID0gJDxIVE1MSW5wdXRFbGVtZW50PignbG93LWJhbmR3aWR0aCcpO1xuY29uc3QgY2FwdHVyZUFsbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjYXB0dXJlLWFsbCcpO1xuY29uc3QgY2FwdHVyZVRoaXNCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2FwdHVyZS10aGlzJyk7XG5jb25zdCBmbHVzaEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdmbHVzaC1hbGwnKTtcbmNvbnN0IG9wdGlvbnNMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ29wZW4tb3B0aW9ucycpO1xuY29uc3Qgdmlld2VyTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdvcGVuLXZpZXdlcicpO1xuY29uc3QgY2xlYXJBY3RCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2xlYXItYWN0aXZpdHknKTtcbmNvbnN0IGV4dFZlcnNpb25FbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignZXh0LXZlcnNpb24nKTtcbmNvbnN0IG1hc3RlclN3aXRjaCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ21hc3Rlci1zd2l0Y2gnKTtcbmNvbnN0IG1hc3RlckxhYmVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtYXN0ZXItbGFiZWwnKTtcbmNvbnN0IGF1dG9TY3JvbGxJbnRlcnZhbCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tc2Nyb2xsLWludGVydmFsJyk7XG5jb25zdCBhdXRvU2Nyb2xsU2Vjc0VsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zZWNzJyk7XG5jb25zdCBhdXRvU2Nyb2xsU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zdGF0dXMnKTtcbmNvbnN0IGF1dG9TY3JvbGxTdGFydEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zdGFydCcpO1xuY29uc3QgYXV0b1Njcm9sbENhbmNlbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1jYW5jZWwnKTtcbmNvbnN0IGF1dG9TY3JvbGxQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtcHJvZ3Jlc3MnKTtcbmNvbnN0IHJlZmV0Y2hTZWN0aW9uID0gJDxIVE1MRWxlbWVudD4oJ3JlZmV0Y2gtc2VjdGlvbicpO1xuY29uc3QgcmVmZXRjaENvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdyZWZldGNoLWNvdW50Jyk7XG5jb25zdCByZWZldGNoU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1zdGFydCcpO1xuY29uc3QgcmVmZXRjaENhbmNlbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZWZldGNoLWNhbmNlbCcpO1xuY29uc3QgcmVmZXRjaFByb2dyZXNzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdyZWZldGNoLXByb2dyZXNzJyk7XG5jb25zdCBtZWRpYUNyYXdsU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1zZWN0aW9uJyk7XG5jb25zdCBtZWRpYUNyYXdsQ291bnQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ21lZGlhLWNyYXdsLWNvdW50Jyk7XG5jb25zdCBtZWRpYUNyYXdsU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignbWVkaWEtY3Jhd2wtc3RhcnQnKTtcbmNvbnN0IG1lZGlhQ3Jhd2xDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignbWVkaWEtY3Jhd2wtY2FuY2VsJyk7XG5jb25zdCBtZWRpYUNyYXdsUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ21lZGlhLWNyYXdsLXByb2dyZXNzJyk7XG5jb25zdCB0aHJlYWRPcGVuU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCd0aHJlYWQtb3Blbi1zZWN0aW9uJyk7XG5jb25zdCB0aHJlYWRPcGVuQ291bnQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3RocmVhZC1vcGVuLWNvdW50Jyk7XG5jb25zdCB0aHJlYWRPcGVuU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigndGhyZWFkLW9wZW4tc3RhcnQnKTtcbmNvbnN0IHRocmVhZE9wZW5DYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigndGhyZWFkLW9wZW4tY2FuY2VsJyk7XG5jb25zdCB0aHJlYWRPcGVuUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3RocmVhZC1vcGVuLXByb2dyZXNzJyk7XG5jb25zdCBwdXJnZUxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50PigncHVyZ2UtdW5yZWxhdGVkJyk7XG5jb25zdCBjb3ZlcmFnZUdhcHNGaW5kQnRuID0gJDxIVE1MQnV0dG9uRWxlbWVudD4oJ2NvdmVyYWdlLWdhcHMtZmluZCcpO1xuY29uc3QgY292ZXJhZ2VHYXBzTGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2NvdmVyYWdlLWdhcHMtbGlzdCcpO1xuY29uc3QgY292ZXJhZ2VHYXBzQ291bnQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2NvdmVyYWdlLWdhcHMtY291bnQnKTtcblxubGV0IGxhc3RTdGF0ZTogRXh0ZW5zaW9uU3RhdGUgfCBudWxsID0gbnVsbDtcblxuYXN5bmMgZnVuY3Rpb24gc2VuZDxUPihtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTxUPiB7XG4gIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKSBhcyBQcm9taXNlPFQ+O1xufVxuXG5jb25zdCBHQVBfS0lORF9MQUJFTDogUmVjb3JkPENvdmVyYWdlR2FwWydraW5kJ10sIHN0cmluZz4gPSB7XG4gIHJlY2VudDogJ25ldyBzaW5jZSBsYXN0IGNhcHR1cmUnLFxuICBlbXB0eTogJ2VtcHR5JyxcbiAgc3BhcnNlOiAnc3BhcnNlJyxcbn07XG5cbmZ1bmN0aW9uIHJlbmRlckNvdmVyYWdlR2FwcyhnYXBzOiBDb3ZlcmFnZUdhcFtdKTogdm9pZCB7XG4gIGNvdmVyYWdlR2Fwc0xpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChnYXBzLmxlbmd0aCA9PT0gMCkge1xuICAgIGNvdmVyYWdlR2Fwc0NvdW50LnRleHRDb250ZW50ID0gJ25vIGhvbGVzJztcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gJ211dGVkIGdhcC1lbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnQ292ZXJhZ2UgbG9va3MgY29tcGxldGUgYWNyb3NzIHRyYWNrZWQgYWNjb3VudHMuJztcbiAgICBjb3ZlcmFnZUdhcHNMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvdmVyYWdlR2Fwc0NvdW50LnRleHRDb250ZW50ID0gYCR7Z2Fwcy5sZW5ndGh9IGdhcCR7Z2Fwcy5sZW5ndGggPT09IDEgPyAnJyA6ICdzJ31gO1xuICBmb3IgKGNvbnN0IGcgb2YgZ2Fwcykge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSBgZ2FwLXJvdyBnYXAtJHtnLmtpbmR9YDtcbiAgICBjb25zdCBpbmZvID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgaW5mby5jbGFzc05hbWUgPSAnZ2FwLWluZm8nO1xuICAgIGNvbnN0IGhlYWQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBoZWFkLmNsYXNzTmFtZSA9ICdnYXAtaGVhZCc7XG4gICAgaGVhZC50ZXh0Q29udGVudCA9XG4gICAgICBnLmZyb21Nb250aCA9PT0gZy50b01vbnRoXG4gICAgICAgID8gYEAke2cuaGFuZGxlfSBcdTAwQjcgJHtnLmZyb21Nb250aH1gXG4gICAgICAgIDogYEAke2cuaGFuZGxlfSBcdTAwQjcgJHtnLmZyb21Nb250aH0gXHUyMTkyICR7Zy50b01vbnRofWA7XG4gICAgY29uc3QgbWV0YSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIG1ldGEuY2xhc3NOYW1lID0gJ2dhcC1tZXRhIG11dGVkJztcbiAgICBjb25zdCBzcGFuID0gZy5tb250aENvdW50ID4gMCA/IGAke2cubW9udGhDb3VudH0gbW9gIDogJ3BhcnRpYWwnO1xuICAgIG1ldGEudGV4dENvbnRlbnQgPSBgJHtHQVBfS0lORF9MQUJFTFtnLmtpbmRdfSBcdTAwQjcgJHtzcGFufSBcdTAwQjcgJHtnLmNhcHR1cmVkSW5SYW5nZX0gY2FwdHVyZWRgO1xuICAgIGluZm8uYXBwZW5kKGhlYWQsIG1ldGEpO1xuICAgIGNvbnN0IG9wZW4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdidXR0b24nKTtcbiAgICBvcGVuLnR5cGUgPSAnYnV0dG9uJztcbiAgICBvcGVuLmNsYXNzTmFtZSA9ICdidG4gZ2FwLW9wZW4nO1xuICAgIG9wZW4udGV4dENvbnRlbnQgPSAnT3Blbic7XG4gICAgb3Blbi50aXRsZSA9IGBPcGVuIFggc2VhcmNoICR7Zy5mcm9tRGF0ZX1cdTIwMTMke2cudG9EYXRlfSBmb3IgQCR7Zy5oYW5kbGV9YDtcbiAgICBvcGVuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgdm9pZCBzZW5kKHsgdHlwZTogJ29wZW4tdXJsJywgdXJsOiBnLnNlYXJjaFVybCB9KTtcbiAgICB9KTtcbiAgICBsaS5hcHBlbmQoaW5mbywgb3Blbik7XG4gICAgY292ZXJhZ2VHYXBzTGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmNvdmVyYWdlR2Fwc0ZpbmRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGNvdmVyYWdlR2Fwc0ZpbmRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICBjb3ZlcmFnZUdhcHNDb3VudC50ZXh0Q29udGVudCA9ICdzY2FubmluZ1x1MjAyNic7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgc2VuZDx7IG9rOiBib29sZWFuOyBnYXBzPzogQ292ZXJhZ2VHYXBbXTsgZXJyb3I/OiBzdHJpbmcgfT4oe1xuICAgICAgdHlwZTogJ2dldC1jb3ZlcmFnZS1nYXBzJyxcbiAgICB9KTtcbiAgICBpZiAoIXJlcy5vayB8fCAhcmVzLmdhcHMpIHtcbiAgICAgIGNvdmVyYWdlR2Fwc0NvdW50LnRleHRDb250ZW50ID0gcmVzLmVycm9yID8/ICdmYWlsZWQnO1xuICAgICAgY292ZXJhZ2VHYXBzTGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmVuZGVyQ292ZXJhZ2VHYXBzKHJlcy5nYXBzKTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjb3ZlcmFnZUdhcHNGaW5kQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBzZXRDb25uU3RhdHVzKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCB7IGNvbm5lY3Rpb24sIHNldHRpbmdzIH0gPSBzdGF0ZTtcbiAgbGV0IGNscyA9ICcnO1xuICBsZXQgdGV4dCA9ICcnO1xuICAvLyBPbmx5IHdhcm4gd2hlbiB0aGUgY29uZmlndXJlZCBicmFuY2ggZ2VudWluZWx5IGRvZXNuJ3QgZXhpc3Qgb24gdGhlXG4gIC8vIHJlbW90ZS4gQSBub24tZGVmYXVsdCBicmFuY2ggdGhhdCBleGlzdHMgaXMgZmluZSBcdTIwMTQgY2FwdHVyaW5nIGludG8gYVxuICAvLyB3b3JraW5nIGJyYW5jaCBpcyByb3V0aW5lIFx1MjAxNCBzbyB0aGUgbWVyZSBgIT09YCB0byBkZWZhdWx0X2JyYW5jaCBpcyBub3RcbiAgLy8gYSBwcm9ibGVtIGFuZCBzaG91bGRuJ3Qgc2hvdXQgaW4gdGhlIGhlYWRlci5cbiAgY29uc3QgYnJhbmNoTWlzc2luZyA9XG4gICAgY29ubmVjdGlvbi5zdGF0dXMgPT09ICdvaycgJiYgc2V0dGluZ3MuYnJhbmNoICYmIGNvbm5lY3Rpb24uY29uZmlndXJlZEJyYW5jaEV4aXN0cyA9PT0gZmFsc2U7XG4gIGlmICghc2V0dGluZ3MucGF0U2V0KSB7XG4gICAgY2xzID0gJ3dhcm4nO1xuICAgIHRleHQgPSAnTm90IGNvbmZpZ3VyZWQgXHUyMDE0IG9wZW4gU2V0dGluZ3MnO1xuICB9IGVsc2UgaWYgKGJyYW5jaE1pc3NpbmcpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gYEJyYW5jaCBcIiR7c2V0dGluZ3MuYnJhbmNofVwiIGRvZXMgbm90IGV4aXN0IG9uICR7c2V0dGluZ3Mub3duZXJ9LyR7c2V0dGluZ3MucmVwb30gXHUyMDE0IGNvbW1pdHMgd2lsbCA0MjIuIFNldCBicmFuY2ggdG8gXCIke2Nvbm5lY3Rpb24uZGVmYXVsdEJyYW5jaCA/PyAnbWFzdGVyJ31cIiBpbiBTZXR0aW5ncy5gO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnb2snKSB7XG4gICAgY2xzID0gJ29rJztcbiAgICB0ZXh0ID0gYENvbm5lY3RlZCBhcyBAJHtjb25uZWN0aW9uLmxvZ2luID8/ICc/J30gdG8gJHtzZXR0aW5ncy5vd25lcn0vJHtzZXR0aW5ncy5yZXBvfSBcdTAwQjcgXHUyMDI2JHtzZXR0aW5ncy5wYXRTdWZmaXh9YDtcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ2F1dGgtZXJyb3InKSB7XG4gICAgY2xzID0gJ2Vycic7XG4gICAgdGV4dCA9IGlzV3JpdGVBdXRoRXJyb3IoY29ubmVjdGlvbi5lcnJvcilcbiAgICAgID8gJ1BBVCBjYW4gcmVhZCByZXBvIGJ1dCBjYW5ub3Qgd3JpdGUgLSBzZXQgQ29udGVudHM6IFJlYWQgJiBXcml0ZSdcbiAgICAgIDogJ0F1dGggZXJyb3IgLSBjaGVjayB5b3VyIFBBVCc7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdyYXRlLWxpbWl0ZWQnKSB7XG4gICAgY2xzID0gJ3dhcm4nO1xuICAgIGNvbnN0IHJlc2V0cyA9IGZtdFJhdGVMaW1pdFJlc2V0KGNvbm5lY3Rpb24ucmF0ZUxpbWl0UmVzZXRBdCk7XG4gICAgdGV4dCA9IHJlc2V0c1xuICAgICAgPyBgR2l0SHViIHJhdGUtbGltaXRlZCBcdTIwMTQgcmVzZXRzICR7cmVzZXRzfWBcbiAgICAgIDogJ0dpdEh1YiByYXRlLWxpbWl0ZWQgXHUyMDE0IGNhcHR1cmVzIHdpbGwgcmV0cnknO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnbmV0d29yay1lcnJvcicpIHtcbiAgICBjbHMgPSAnZXJyJztcbiAgICB0ZXh0ID0gJ05ldHdvcmsgZXJyb3IgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpdml0eSc7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdub3QtY29uZmlndXJlZCcpIHtcbiAgICBjbHMgPSAnd2Fybic7XG4gICAgdGV4dCA9ICdOb3QgY29uZmlndXJlZCBcdTIwMTQgb3BlbiBTZXR0aW5ncyc7XG4gIH0gZWxzZSB7XG4gICAgY2xzID0gJyc7XG4gICAgdGV4dCA9ICdDaGVja2luZ1x1MjAyNic7XG4gIH1cbiAgY29ubkRvdC5jbGFzc05hbWUgPSBgZG90ICR7Y2xzfWA7XG4gIGNvbm5UZXh0LnRleHRDb250ZW50ID0gdGV4dDtcbiAgY29ublRleHQudGl0bGUgPSBjb25uZWN0aW9uLmVycm9yID8/ICcnO1xufVxuXG5mdW5jdGlvbiBmbXRSZWwoaXNvOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHtcbiAgaWYgKCFpc28pIHJldHVybiAnXHUyMDE0JztcbiAgY29uc3QgZCA9IERhdGUucGFyc2UoaXNvKTtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoZCkpIHJldHVybiAnXHUyMDE0JztcbiAgY29uc3Qgc2VjcyA9IE1hdGgubWF4KDAsIE1hdGgucm91bmQoKERhdGUubm93KCkgLSBkKSAvIDEwMDApKTtcbiAgaWYgKHNlY3MgPCA1KSByZXR1cm4gJ2p1c3Qgbm93JztcbiAgaWYgKHNlY3MgPCA2MCkgcmV0dXJuIGAke3NlY3N9cyBhZ29gO1xuICBjb25zdCBtaW5zID0gTWF0aC5yb3VuZChzZWNzIC8gNjApO1xuICBpZiAobWlucyA8IDYwKSByZXR1cm4gYCR7bWluc31tIGFnb2A7XG4gIGNvbnN0IGhvdXJzID0gTWF0aC5yb3VuZChtaW5zIC8gNjApO1xuICBpZiAoaG91cnMgPCAyNCkgcmV0dXJuIGAke2hvdXJzfWggYWdvYDtcbiAgY29uc3QgZGF5cyA9IE1hdGgucm91bmQoaG91cnMgLyAyNCk7XG4gIHJldHVybiBgJHtkYXlzfWQgYWdvYDtcbn1cblxuZnVuY3Rpb24gZm10UmF0ZUxpbWl0UmVzZXQoZXBvY2hTZWM6IG51bWJlciB8IG51bGwpOiBzdHJpbmcge1xuICBpZiAoZXBvY2hTZWMgPT09IG51bGwpIHJldHVybiAnJztcbiAgY29uc3QgZGVsdGFTZWMgPSBlcG9jaFNlYyAtIE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApO1xuICBpZiAoZGVsdGFTZWMgPD0gMCkgcmV0dXJuICdtb21lbnRhcmlseSc7XG4gIGNvbnN0IHdhbGxDbG9jayA9IG5ldyBEYXRlKGVwb2NoU2VjICogMTAwMCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7XG4gICAgaG91cjogJzItZGlnaXQnLFxuICAgIG1pbnV0ZTogJzItZGlnaXQnLFxuICB9KTtcbiAgaWYgKGRlbHRhU2VjIDwgNjApIHJldHVybiBgaW4gJHtkZWx0YVNlY31zICgke3dhbGxDbG9ja30pYDtcbiAgY29uc3QgbWlucyA9IE1hdGgucm91bmQoZGVsdGFTZWMgLyA2MCk7XG4gIGlmIChtaW5zIDwgNjApIHJldHVybiBgaW4gJHttaW5zfW0gKCR7d2FsbENsb2NrfSlgO1xuICBjb25zdCBob3VycyA9IE1hdGgucm91bmQobWlucyAvIDYwKTtcbiAgcmV0dXJuIGBpbiAke2hvdXJzfWggKCR7d2FsbENsb2NrfSlgO1xufVxuXG5mdW5jdGlvbiBmbXROdW0objogbnVtYmVyKTogc3RyaW5nIHtcbiAgcmV0dXJuIG4udG9Mb2NhbGVTdHJpbmcoJ2VuLVVTJyk7XG59XG5cbmZ1bmN0aW9uIGlzV3JpdGVBdXRoRXJyb3IobWVzc2FnZTogc3RyaW5nIHwgbnVsbCk6IGJvb2xlYW4ge1xuICByZXR1cm4gKFxuICAgIHR5cGVvZiBtZXNzYWdlID09PSAnc3RyaW5nJyAmJlxuICAgIC9SZXNvdXJjZSBub3QgYWNjZXNzaWJsZSBieSBwZXJzb25hbCBhY2Nlc3MgdG9rZW58XFwvZ2l0XFwvYmxvYnN8XFwvZ2l0XFwvcmVmcy9pLnRlc3QobWVzc2FnZSlcbiAgKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQWNjb3VudHMoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGFjY291bnRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBpZiAoc3RhdGUuYWNjb3VudHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWNjb3VudHMgY29uZmlndXJlZC4nO1xuICAgIGFjY291bnRMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3QgYSBvZiBzdGF0ZS5hY2NvdW50cykge1xuICAgIGNvbnN0IGMgPSBzdGF0ZS5jb3VudGVyc1thLmhhbmRsZV07XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9IGMgJiYgYy5idWZmZXJlZENvdW50ID4gMCA/ICdhY2MgcGVuZGluZycgOiAnYWNjJztcblxuICAgIGNvbnN0IGhlYWQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBoZWFkLmNsYXNzTmFtZSA9ICdhY2MtaGVhZCc7XG4gICAgY29uc3QgaGFuZGxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGhhbmRsZS5jbGFzc05hbWUgPSAnYWNjLWhhbmRsZSc7XG4gICAgaGFuZGxlLmlubmVySFRNTCA9IGA8c3BhbiBjbGFzcz1cImF0XCI+QDwvc3Bhbj4ke2VzY2FwZUh0bWwoYS5oYW5kbGUpfWA7XG4gICAgY29uc3QgbWV0YSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBtZXRhLmNsYXNzTmFtZSA9ICdhY2MtbWV0YSc7XG4gICAgbWV0YS50ZXh0Q29udGVudCA9IGEubGFiZWw7XG4gICAgaGVhZC5hcHBlbmQoaGFuZGxlLCBtZXRhKTtcblxuICAgIGNvbnN0IHJvdyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHJvdy5jbGFzc05hbWUgPSAnYWNjLXJvdyc7XG4gICAgY29uc3Qgc3RhdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgc3RhdHMuY2xhc3NOYW1lID0gJ2FjYy1zdGF0cyc7XG4gICAgY29uc3QgdG9kYXkgPSBjPy50b2RheUNvdW50ID8/IDA7XG4gICAgY29uc3QgYnVmZmVyZWQgPSBjPy5idWZmZXJlZENvdW50ID8/IDA7XG4gICAgY29uc3QgbGFzdCA9IGM/Lmxhc3RDYXB0dXJlQXQgPz8gbnVsbDtcbiAgICBzdGF0cy5pbm5lckhUTUwgPVxuICAgICAgYDxzcGFuIGNsYXNzPVwibnVtXCI+JHtmbXROdW0odG9kYXkpfTwvc3Bhbj4gdG9kYXlgICtcbiAgICAgIChidWZmZXJlZCA+IDAgPyBgIFx1MDBCNyA8c3BhbiBjbGFzcz1cIm51bVwiPiR7Zm10TnVtKGJ1ZmZlcmVkKX08L3NwYW4+IGJ1ZmZlcmVkYCA6ICcnKSArXG4gICAgICBgIFx1MDBCNyBsYXN0ICR7ZXNjYXBlSHRtbChmbXRSZWwobGFzdCkpfWA7XG5cbiAgICBjb25zdCBhY3Rpb25zID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGFjdGlvbnMuY2xhc3NOYW1lID0gJ2FjYy1hY3Rpb24nO1xuICAgIGNvbnN0IGJ0biA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGJ0bi5jbGFzc05hbWUgPSAnYnRuJztcbiAgICBidG4udGV4dENvbnRlbnQgPSAnQ2FwdHVyZSBub3cnO1xuICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtbm93JywgaGFuZGxlOiBhLmhhbmRsZSB9KTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGFjdGlvbnMuYXBwZW5kKGJ0bik7XG5cbiAgICByb3cuYXBwZW5kKHN0YXRzLCBhY3Rpb25zKTtcbiAgICBsaS5hcHBlbmQoaGVhZCwgcm93KTtcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFjdGl2aXR5KGV2ZW50czogTG9nRXZlbnRbXSk6IHZvaWQge1xuICBhY3Rpdml0eUxpc3QucmVwbGFjZUNoaWxkcmVuKCk7XG4gIGlmIChldmVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gYWN0aXZpdHkgeWV0Lic7XG4gICAgYWN0aXZpdHlMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3QgZXYgb2YgZXZlbnRzLnNsaWNlKDAsIEFDVElWSVRZX1RBSUxfTUFYKSkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSBgZXYgJHtldi5sZXZlbH1gO1xuICAgIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XG4gICAgdHMudGV4dENvbnRlbnQgPSBuZXcgRGF0ZShldi50cykudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1VUycsIHsgaG91cjEyOiBmYWxzZSB9KTtcbiAgICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xuICAgIGljb24udGV4dENvbnRlbnQgPSBldi5sZXZlbCA9PT0gJ2Vycm9yJyA/ICdcdTI3MTcnIDogZXYubGV2ZWwgPT09ICd3YXJuJyA/ICchJyA6ICdcdTAwQjcnO1xuICAgIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgbXNnLmNsYXNzTmFtZSA9ICdldi1tc2cnO1xuICAgIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcbiAgICBib2R5LmFwcGVuZChtc2cpO1xuICAgIGNvbnN0IGN0eEtleXMgPSBPYmplY3Qua2V5cyhldi5jb250ZXh0KTtcbiAgICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGN0eC5jbGFzc05hbWUgPSAnZXYtY3R4JztcbiAgICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgICBib2R5LmFwcGVuZChjdHgpO1xuICAgIH1cbiAgICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xuICAgIGFjdGl2aXR5TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHN0cmluZ2lmeVNob3J0KHY6IHVua25vd24pOiBzdHJpbmcge1xuICBpZiAodiA9PT0gbnVsbCkgcmV0dXJuICdudWxsJztcbiAgaWYgKHR5cGVvZiB2ID09PSAnc3RyaW5nJykgcmV0dXJuIHYubGVuZ3RoID4gODAgPyBgJHt2LnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogdjtcbiAgaWYgKHR5cGVvZiB2ID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdiA9PT0gJ2Jvb2xlYW4nKSByZXR1cm4gU3RyaW5nKHYpO1xuICB0cnkge1xuICAgIGNvbnN0IHMgPSBKU09OLnN0cmluZ2lmeSh2KTtcbiAgICByZXR1cm4gcy5sZW5ndGggPiA4MCA/IGAke3Muc2xpY2UoMCwgODApfVx1MjAyNmAgOiBzO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gJz8nO1xuICB9XG59XG5cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoczogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHMucmVwbGFjZSgvWyY8PlwiJ10vZywgKGMpID0+XG4gICAgYyA9PT0gJyYnID8gJyZhbXA7JyA6IGMgPT09ICc8JyA/ICcmbHQ7JyA6IGMgPT09ICc+JyA/ICcmZ3Q7JyA6IGMgPT09ICdcIicgPyAnJnF1b3Q7JyA6ICcmIzM5OydcbiAgKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaFN0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGxhc3RTdGF0ZSA9IGF3YWl0IHNlbmQ8RXh0ZW5zaW9uU3RhdGU+KHsgdHlwZTogJ2dldC1zdGF0ZScgfSk7XG4gICAgcGFpbnQobGFzdFN0YXRlKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNpZGViYXIgcmVmcmVzaFN0YXRlIGZhaWxlZCcsIGVycik7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGFpbnQoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGV4dFZlcnNpb25FbC50ZXh0Q29udGVudCA9IHN0YXRlLnZlcnNpb247XG4gIHNldENvbm5TdGF0dXMoc3RhdGUpO1xuICBhdXRvVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvQ2FwdHVyZTtcbiAgdXBkYXRlRXhpc3RpbmdUb2dnbGUuY2hlY2tlZCA9IHN0YXRlLnNldHRpbmdzLnVwZGF0ZUV4aXN0aW5nICE9PSBmYWxzZTtcbiAgbG93QmFuZHdpZHRoVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy5sb3dCYW5kd2lkdGhCcm93c2luZyA9PT0gdHJ1ZTtcbiAgdmlld2VyTGluay5ocmVmID0gYGh0dHBzOi8vJHtzdGF0ZS5zZXR0aW5ncy5vd25lcn0uZ2l0aHViLmlvLyR7c3RhdGUuc2V0dGluZ3MucmVwb30vYDtcbiAgcGFpbnRNYXN0ZXJTd2l0Y2goc3RhdGUpO1xuICByZW5kZXJBY2NvdW50cyhzdGF0ZSk7XG4gIHJlbmRlclJlY2VudFR3ZWV0cyhzdGF0ZS5yZWNlbnRUd2VldFNpZ2h0aW5ncyk7XG4gIHBhaW50QXV0b1Njcm9sbChzdGF0ZSk7XG4gIHBhaW50TWVkaWFDcmF3bChzdGF0ZSk7XG4gIHBhaW50UmVmZXRjaChzdGF0ZSk7XG4gIHBhaW50VGhyZWFkT3BlbihzdGF0ZSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclJlY2VudFR3ZWV0cyhyb3dzOiBUd2VldFNpZ2h0aW5nW10pOiB2b2lkIHtcbiAgcmVjZW50VHdlZXRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBpZiAocm93cy5sZW5ndGggPT09IDApIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gJ2VtcHR5JztcbiAgICBsaS50ZXh0Q29udGVudCA9ICdObyB0d2VldHMgc2VlbiB5ZXQuJztcbiAgICByZWNlbnRUd2VldExpc3QuYXBwZW5kKGxpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZm9yIChjb25zdCByb3cgb2Ygcm93cy5zbGljZSgwLCA0MCkpIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gYHJlY2VudC10d2VldCAke3Jvdy5hcmNoaXZlX3N0YXR1c31gO1xuXG4gICAgY29uc3QgdG9wID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgdG9wLmNsYXNzTmFtZSA9ICd0d2VldC1oZWFkJztcbiAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgIGxpbmsuY2xhc3NOYW1lID0gJ3R3ZWV0LWhhbmRsZSc7XG4gICAgbGluay5ocmVmID0gcm93LnR3ZWV0X3VybDtcbiAgICBsaW5rLnRhcmdldCA9ICdfYmxhbmsnO1xuICAgIGxpbmsucmVsID0gJ25vb3BlbmVyJztcbiAgICBsaW5rLnRleHRDb250ZW50ID0gYEAke3Jvdy5hY2NvdW50X2hhbmRsZX1gO1xuICAgIGNvbnN0IHN0YXR1cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBzdGF0dXMuY2xhc3NOYW1lID0gYHR3ZWV0LXBpbGwgJHtyb3cuYXJjaGl2ZV9zdGF0dXN9YDtcbiAgICBzdGF0dXMudGV4dENvbnRlbnQgPSByb3cuYXJjaGl2ZV9zdGF0dXMgPT09ICdzYXZlZCcgPyAnc2F2ZWQnIDogJ25ldyc7XG4gICAgdG9wLmFwcGVuZChsaW5rLCBzdGF0dXMpO1xuXG4gICAgY29uc3QgdGV4dCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHRleHQuY2xhc3NOYW1lID0gJ3R3ZWV0LXRleHQnO1xuICAgIHRleHQudGV4dENvbnRlbnQgPSB0cnVuY2F0ZVRleHQocm93LnRleHQsIDE0MCk7XG5cbiAgICBjb25zdCBtZXRhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgbWV0YS5jbGFzc05hbWUgPSAndHdlZXQtbWV0YSc7XG4gICAgbWV0YS50ZXh0Q29udGVudCA9IGAke2Zvcm1hdFR3ZWV0QWN0aW9uKHJvdy5hY3Rpb24pfSBcdTAwQjcgJHtyb3cudHdlZXRfdHlwZX0gXHUwMEI3IHBvc3RlZCAke2ZtdFJlbChyb3cucG9zdGVkX2F0KX1gO1xuXG4gICAgbGkuYXBwZW5kKHRvcCwgdGV4dCwgbWV0YSk7XG4gICAgcmVjZW50VHdlZXRMaXN0LmFwcGVuZChsaSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZm9ybWF0VHdlZXRBY3Rpb24oYWN0aW9uOiBUd2VldFNpZ2h0aW5nWydhY3Rpb24nXSk6IHN0cmluZyB7XG4gIGlmIChhY3Rpb24gPT09ICdidWZmZXJlZCcpIHJldHVybiAnYnVmZmVyZWQnO1xuICBpZiAoYWN0aW9uID09PSAndW5jaGFuZ2VkJykgcmV0dXJuICd1bmNoYW5nZWQnO1xuICByZXR1cm4gJ3NraXBwZWQnO1xufVxuXG5mdW5jdGlvbiB0cnVuY2F0ZVRleHQodGV4dDogc3RyaW5nLCBtYXg6IG51bWJlcik6IHN0cmluZyB7XG4gIGNvbnN0IGNvbXBhY3QgPSB0ZXh0LnJlcGxhY2UoL1xccysvZywgJyAnKS50cmltKCk7XG4gIHJldHVybiBjb21wYWN0Lmxlbmd0aCA8PSBtYXggPyBjb21wYWN0IDogYCR7Y29tcGFjdC5zbGljZSgwLCBtYXggLSAxKX1cdTIwMjZgO1xufVxuXG5mdW5jdGlvbiBwYWludE1lZGlhQ3Jhd2woc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHEgPSBzdGF0ZS5tZWRpYUNyYXdsUXVldWU7XG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcbiAgY29uc3QgcnVubmluZyA9IHEucnVubmluZztcbiAgbWVkaWFDcmF3bFNlY3Rpb24uaGlkZGVuID0gdG90YWwgPT09IDAgJiYgIXJ1bm5pbmc7XG4gIG1lZGlhQ3Jhd2xDb3VudC50ZXh0Q29udGVudCA9XG4gICAgdG90YWwgPT09IDBcbiAgICAgID8gcnVubmluZ1xuICAgICAgICA/ICdmaW5pc2hpbmdcdTIwMjYnXG4gICAgICAgIDogJzAgcXVldWVkJ1xuICAgICAgOiBgJHtmbXROdW0odG90YWwpfSBxdWV1ZWQke3J1bm5pbmcgPyAnIFx1MDBCNyBydW5uaW5nJyA6ICcnfWA7XG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcbiAgbWVkaWFDcmF3bENhbmNlbEJ0bi5oaWRkZW4gPSAhcnVubmluZztcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKG1lZGlhQ3Jhd2xQcm9ncmVzcywgcSk7XG59XG5cbmZ1bmN0aW9uIHBhaW50UXVldWVQcm9ncmVzcyhcbiAgZWw6IEhUTUxTcGFuRWxlbWVudCxcbiAgcTogeyBwcm9jZXNzZWQ6IG51bWJlcjsgdG90YWxfYXRfc3RhcnQ6IG51bWJlcjsgcnVubmluZzogYm9vbGVhbjsgdG90YWw6IG51bWJlciB9XG4pOiB2b2lkIHtcbiAgaWYgKCFxLnJ1bm5pbmcgJiYgcS5wcm9jZXNzZWQgPT09IDApIHtcbiAgICBlbC5oaWRkZW4gPSB0cnVlO1xuICAgIHJldHVybjtcbiAgfVxuICAvLyBEZW5vbWluYXRvcjogbWF4IG9mIGluaXRpYWwgdG90YWwgYW5kIGN1cnJlbnQgcHJvY2Vzc2VkK3JlbWFpbmluZyBzbyB0aGVcbiAgLy8gYmFyIHN0aWxsIG1ha2VzIHNlbnNlIGlmIG5ldyBlbnRyaWVzIHdlcmUgZW5xdWV1ZWQgbWlkLXJ1bi5cbiAgY29uc3QgZGVub20gPSBNYXRoLm1heChxLnRvdGFsX2F0X3N0YXJ0LCBxLnByb2Nlc3NlZCArIHEudG90YWwpO1xuICBlbC5oaWRkZW4gPSBmYWxzZTtcbiAgZWwudGV4dENvbnRlbnQgPSBgJHtmbXROdW0ocS5wcm9jZXNzZWQpfSAvICR7Zm10TnVtKGRlbm9tKX0gcHJvY2Vzc2VkYDtcbiAgZWwuY2xhc3NOYW1lID0gcS5ydW5uaW5nID8gJ3Byb2dyZXNzIG9uJyA6ICdwcm9ncmVzcyc7XG59XG5cbmZ1bmN0aW9uIHBhaW50TWFzdGVyU3dpdGNoKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBvbiA9IHN0YXRlLnNldHRpbmdzLmVuYWJsZWQgIT09IGZhbHNlO1xuICBtYXN0ZXJTd2l0Y2guY2hlY2tlZCA9IG9uO1xuICBtYXN0ZXJMYWJlbC50ZXh0Q29udGVudCA9IG9uID8gJ09OJyA6ICdQQVVTRUQnO1xuICBkb2N1bWVudC5ib2R5LmNsYXNzTGlzdC50b2dnbGUoJ3BhdXNlZCcsICFvbik7XG59XG5cbmZ1bmN0aW9uIHBhaW50QXV0b1Njcm9sbChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3Qgc2VjcyA9IHN0YXRlLnNldHRpbmdzLmF1dG9TY3JvbGxJbnRlcnZhbFNlYztcbiAgYXV0b1Njcm9sbEludGVydmFsLnZhbHVlID0gU3RyaW5nKHNlY3MpO1xuICBhdXRvU2Nyb2xsU2Vjc0VsLnRleHRDb250ZW50ID0gU3RyaW5nKHNlY3MpO1xuICBjb25zdCBhcyA9IHN0YXRlLmF1dG9TY3JvbGw7XG4gIGF1dG9TY3JvbGxTdGFydEJ0bi5oaWRkZW4gPSBhcy5hY3RpdmU7XG4gIGF1dG9TY3JvbGxDYW5jZWxCdG4uaGlkZGVuID0gIWFzLmFjdGl2ZTtcbiAgaWYgKGFzLmFjdGl2ZSkge1xuICAgIGNvbnN0IG4gPSBhcy50YWJDb3VudDtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLnRleHRDb250ZW50ID1cbiAgICAgIG4gPT09IDAgPyBgcnVubmluZyBcdTIwMTQgbm8gWCB0YWJzIG9wZW5gIDogYHJ1bm5pbmcgXHUyMDE0ICR7bn0gJHtuID09PSAxID8gJ3RhYicgOiAndGFicyd9YDtcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLmNsYXNzTmFtZSA9ICdtdXRlZCBvbic7XG4gIH0gZWxzZSB7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9ICdpZGxlJztcbiAgICBhdXRvU2Nyb2xsU3RhdHVzLmNsYXNzTmFtZSA9ICdtdXRlZCc7XG4gIH1cbiAgaWYgKGFzLmFjdGl2ZSB8fCBhcy5zY3JvbGxDb3VudCA+IDAgfHwgYXMuaW5nZXN0ZWRDb3VudCA+IDApIHtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuaGlkZGVuID0gZmFsc2U7XG4gICAgY29uc3QgcGFydHMgPSBbXG4gICAgICBgJHtmbXROdW0oYXMuc2Nyb2xsQ291bnQpfSBzY3JvbGxzYCxcbiAgICAgIGAke2ZtdE51bShhcy5pbmdlc3RlZE5ld0NvdW50KX0gbmV3IGJ1ZmZlcmVkYCxcbiAgICAgIGAke2ZtdE51bShhcy5pbmdlc3RlZEV4aXN0aW5nQ291bnQpfSBvbGQgYnVmZmVyZWRgLFxuICAgIF07XG4gICAgaWYgKGFzLnNraXBwZWRPbGRDb3VudCA+IDApIHBhcnRzLnB1c2goYCR7Zm10TnVtKGFzLnNraXBwZWRPbGRDb3VudCl9IG9sZCBza2lwcGVkYCk7XG4gICAgcGFydHMucHVzaChgJHtmbXROdW0oYXMuZXhwYW5kZWRDb3VudCl9IGV4cGFuZGVkYCk7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLnRleHRDb250ZW50ID0gcGFydHMuam9pbignIFx1MDBCNyAnKTtcbiAgICBhdXRvU2Nyb2xsUHJvZ3Jlc3MuY2xhc3NOYW1lID0gYXMuYWN0aXZlID8gJ3Byb2dyZXNzIG9uJyA6ICdwcm9ncmVzcyc7XG4gIH0gZWxzZSB7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmhpZGRlbiA9IHRydWU7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGFpbnRSZWZldGNoKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBxID0gc3RhdGUucmVmZXRjaFF1ZXVlO1xuICBjb25zdCB0b3RhbCA9IHEudG90YWw7XG4gIGNvbnN0IHJ1bm5pbmcgPSBxLnJ1bm5pbmc7XG4gIHJlZmV0Y2hTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xuICByZWZldGNoQ291bnQudGV4dENvbnRlbnQgPVxuICAgIHRvdGFsID09PSAwXG4gICAgICA/IHJ1bm5pbmdcbiAgICAgICAgPyAnZmluaXNoaW5nXHUyMDI2J1xuICAgICAgICA6ICcwIHF1ZXVlZCdcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xuICByZWZldGNoU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcbiAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gdG90YWwgPT09IDA7XG4gIHJlZmV0Y2hDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XG4gIHBhaW50UXVldWVQcm9ncmVzcyhyZWZldGNoUHJvZ3Jlc3MsIHEpO1xufVxuXG5mdW5jdGlvbiBwYWludFRocmVhZE9wZW4oc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHEgPSBzdGF0ZS50aHJlYWRPcGVuUXVldWU7XG4gIGNvbnN0IHRvdGFsID0gcS50b3RhbDtcbiAgY29uc3QgcnVubmluZyA9IHEucnVubmluZztcbiAgdGhyZWFkT3BlblNlY3Rpb24uaGlkZGVuID0gdG90YWwgPT09IDAgJiYgIXJ1bm5pbmc7XG4gIHRocmVhZE9wZW5Db3VudC50ZXh0Q29udGVudCA9XG4gICAgdG90YWwgPT09IDBcbiAgICAgID8gcnVubmluZ1xuICAgICAgICA/ICdmaW5pc2hpbmcuLi4nXG4gICAgICAgIDogJzAgcXVldWVkJ1xuICAgICAgOiBgJHtmbXROdW0odG90YWwpfSBxdWV1ZWQke3J1bm5pbmcgPyAnIFx1MDBCNyBydW5uaW5nJyA6ICcnfWA7XG4gIHRocmVhZE9wZW5TdGFydEJ0bi5oaWRkZW4gPSBydW5uaW5nO1xuICB0aHJlYWRPcGVuU3RhcnRCdG4uZGlzYWJsZWQgPSB0b3RhbCA9PT0gMDtcbiAgdGhyZWFkT3BlbkNhbmNlbEJ0bi5oaWRkZW4gPSAhcnVubmluZztcbiAgcGFpbnRRdWV1ZVByb2dyZXNzKHRocmVhZE9wZW5Qcm9ncmVzcywgcSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hBY3Rpdml0eSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gUHVsbCBzdHJhaWdodCBmcm9tIHN0b3JhZ2Ugb24gZmlyc3QgcmVuZGVyOyBsaXZlIHVwZGF0ZXMgY29tZSB2aWFcbiAgLy8gYGxvZy1ldmVudGAgYnJvYWRjYXN0cy5cbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldCgnYWN0aXZpdHknKTtcbiAgY29uc3QgZXZlbnRzID0gKHN0b3JlZC5hY3Rpdml0eSBhcyBMb2dFdmVudFtdIHwgdW5kZWZpbmVkKSA/PyBbXTtcbiAgcmVuZGVyQWN0aXZpdHkoZXZlbnRzKTtcbn1cblxuLy8gLS0tIFdpcmUgdXAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuY2FwdHVyZUFsbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgY2FwdHVyZUFsbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjYXB0dXJlLWFsbCcgfSk7XG4gIH0gZmluYWxseSB7XG4gICAgY2FwdHVyZUFsbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuY2FwdHVyZVRoaXNCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGNhcHR1cmVUaGlzQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2NhcHR1cmUtdGhpcy1wYWdlJyB9KTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjYXB0dXJlVGhpc0J0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuZmx1c2hCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGZsdXNoQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kKHsgdHlwZTogJ2ZsdXNoLWFsbCcgfSk7XG4gIH0gZmluYWxseSB7XG4gICAgZmx1c2hCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfVxufSk7XG5cbmF1dG9Ub2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLWF1dG8tY2FwdHVyZScsIG9uOiBhdXRvVG9nZ2xlLmNoZWNrZWQgfSk7XG59KTtcblxudXBkYXRlRXhpc3RpbmdUb2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLXVwZGF0ZS1leGlzdGluZycsIG9uOiB1cGRhdGVFeGlzdGluZ1RvZ2dsZS5jaGVja2VkIH0pO1xufSk7XG5cbmxvd0JhbmR3aWR0aFRvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCAoKSA9PiB7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICd0b2dnbGUtbG93LWJhbmR3aWR0aCcsIG9uOiBsb3dCYW5kd2lkdGhUb2dnbGUuY2hlY2tlZCB9KTtcbn0pO1xuXG5tYXN0ZXJTd2l0Y2guYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLWVuYWJsZWQnLCBvbjogbWFzdGVyU3dpdGNoLmNoZWNrZWQgfSk7XG59KTtcblxuYXV0b1Njcm9sbFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtYXV0by1zY3JvbGwnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIGF1dG9TY3JvbGxTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuYXV0b1Njcm9sbENhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgYXV0b1Njcm9sbENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtYXV0by1zY3JvbGwnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIGF1dG9TY3JvbGxDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JywgKCkgPT4ge1xuICBhdXRvU2Nyb2xsU2Vjc0VsLnRleHRDb250ZW50ID0gYXV0b1Njcm9sbEludGVydmFsLnZhbHVlO1xufSk7XG5hdXRvU2Nyb2xsSW50ZXJ2YWwuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICBjb25zdCBzZWNvbmRzID0gTnVtYmVyKGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZSk7XG4gIGlmIChOdW1iZXIuaXNGaW5pdGUoc2Vjb25kcykpIHtcbiAgICB2b2lkIHNlbmQoeyB0eXBlOiAnc2V0LWF1dG8tc2Nyb2xsLWludGVydmFsJywgc2Vjb25kcyB9KTtcbiAgfVxufSk7XG5cbnB1cmdlTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIGNvbnN0IG9rID0gd2luZG93LmNvbmZpcm0oXG4gICAgJ0Ryb3AgZXZlcnkgY291bnRlciwgcnVuIGJ1ZmZlciwgcmVmZXRjaCAvIG1lZGlhLWNyYXdsIC8gdGhyZWFkLW9wZW5pbmcgcXVldWUgZW50cnkgZm9yIGFjY291bnRzIG5vdCBpbiB5b3VyIHRyYWNrZWQgbGlzdD9cXG5cXG4nICtcbiAgICAgICdUaGlzIG9ubHkgdG91Y2hlcyBsb2NhbCBleHRlbnNpb24gc3RhdGUuIEFscmVhZHktY29tbWl0dGVkIGZpbGVzIGluIHRoZSBHaXRIdWIgcmVwbyBhcmUgbm90IGFmZmVjdGVkIFx1MjAxNCAnICtcbiAgICAgICdydW4gc2NyaXB0cy9wdXJnZV91bnJlbGF0ZWQucHkgc2VwYXJhdGVseSBpZiB5b3UgYWxzbyB3YW50IHRvIHNjcnViIHRoZSByZXBvLidcbiAgKTtcbiAgaWYgKCFvaykgcmV0dXJuO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAncHVyZ2UtdW5yZWxhdGVkJyB9KTtcbn0pO1xuXG5yZWZldGNoU3RhcnRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC1yZWZldGNoJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxucmVmZXRjaENhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgcmVmZXRjaENhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtcmVmZXRjaCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgcmVmZXRjaENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5tZWRpYUNyYXdsU3RhcnRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC1tZWRpYS1jcmF3bCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgbWVkaWFDcmF3bFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbm1lZGlhQ3Jhd2xDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLW1lZGlhLWNyYXdsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBtZWRpYUNyYXdsQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbnRocmVhZE9wZW5TdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgdGhyZWFkT3BlblN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LXRocmVhZC1vcGVuJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICB0aHJlYWRPcGVuU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxudGhyZWFkT3BlbkNhbmNlbEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgdGhyZWFkT3BlbkNhbmNlbEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdjYW5jZWwtdGhyZWFkLW9wZW4nIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHRocmVhZE9wZW5DYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxub3B0aW9uc0xpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnb3Blbi1vcHRpb25zJyB9KTtcbn0pO1xuXG52aWV3ZXJMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ29wZW4tdmlld2VyJyB9KTtcbn0pO1xuXG5jbGVhckFjdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjbGVhci1hY3Rpdml0eScgfSk7XG4gIHJlbmRlckFjdGl2aXR5KFtdKTtcbn0pO1xuXG5icm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IHVua25vd24pID0+IHtcbiAgaWYgKCFtc2cgfHwgdHlwZW9mIG1zZyAhPT0gJ29iamVjdCcpIHJldHVybjtcbiAgY29uc3QgbSA9IG1zZyBhcyB7IHR5cGU/OiBzdHJpbmc7IHN0YXRlPzogRXh0ZW5zaW9uU3RhdGU7IGV2ZW50PzogTG9nRXZlbnQgfTtcbiAgaWYgKG0udHlwZSA9PT0gJ3N0YXRlLWNoYW5nZWQnICYmIG0uc3RhdGUpIHtcbiAgICBsYXN0U3RhdGUgPSBtLnN0YXRlO1xuICAgIHBhaW50KG0uc3RhdGUpO1xuICB9IGVsc2UgaWYgKG0udHlwZSA9PT0gJ2xvZy1ldmVudCcgJiYgbS5ldmVudCkge1xuICAgIHByZXBlbmRFdmVudChtLmV2ZW50KTtcbiAgfVxufSk7XG5cbmZ1bmN0aW9uIHByZXBlbmRFdmVudChldjogTG9nRXZlbnQpOiB2b2lkIHtcbiAgLy8gSWYgdGhlIGxpc3QgaXMgc2hvd2luZyB0aGUgXCJlbXB0eVwiIHBsYWNlaG9sZGVyLCBjbGVhciBpdC5cbiAgaWYgKGFjdGl2aXR5TGlzdC5maXJzdEVsZW1lbnRDaGlsZD8uY2xhc3NMaXN0LmNvbnRhaW5zKCdlbXB0eScpKSB7XG4gICAgYWN0aXZpdHlMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICB9XG4gIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgbGkuY2xhc3NOYW1lID0gYGV2ICR7ZXYubGV2ZWx9YDtcbiAgY29uc3QgdHMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIHRzLmNsYXNzTmFtZSA9ICdldi10cyc7XG4gIHRzLnRleHRDb250ZW50ID0gbmV3IERhdGUoZXYudHMpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tVVMnLCB7IGhvdXIxMjogZmFsc2UgfSk7XG4gIGNvbnN0IGljb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIGljb24uY2xhc3NOYW1lID0gJ2V2LWljb24nO1xuICBpY29uLnRleHRDb250ZW50ID0gZXYubGV2ZWwgPT09ICdlcnJvcicgPyAnXHUyNzE3JyA6IGV2LmxldmVsID09PSAnd2FybicgPyAnIScgOiAnXHUwMEI3JztcbiAgY29uc3QgYm9keSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgY29uc3QgbXNnID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gIG1zZy5jbGFzc05hbWUgPSAnZXYtbXNnJztcbiAgbXNnLnRleHRDb250ZW50ID0gZXYubXNnO1xuICBib2R5LmFwcGVuZChtc2cpO1xuICBjb25zdCBjdHhLZXlzID0gT2JqZWN0LmtleXMoZXYuY29udGV4dCk7XG4gIGlmIChjdHhLZXlzLmxlbmd0aCA+IDApIHtcbiAgICBjb25zdCBjdHggPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBjdHguY2xhc3NOYW1lID0gJ2V2LWN0eCc7XG4gICAgY3R4LnRleHRDb250ZW50ID0gY3R4S2V5cy5tYXAoKGspID0+IGAke2t9PSR7c3RyaW5naWZ5U2hvcnQoZXYuY29udGV4dFtrXSl9YCkuam9pbignIFx1MDBCNyAnKTtcbiAgICBib2R5LmFwcGVuZChjdHgpO1xuICB9XG4gIGxpLmFwcGVuZCh0cywgaWNvbiwgYm9keSk7XG4gIGFjdGl2aXR5TGlzdC5wcmVwZW5kKGxpKTtcbiAgd2hpbGUgKGFjdGl2aXR5TGlzdC5jaGlsZEVsZW1lbnRDb3VudCA+IEFDVElWSVRZX1RBSUxfTUFYKSB7XG4gICAgYWN0aXZpdHlMaXN0Lmxhc3RFbGVtZW50Q2hpbGQ/LnJlbW92ZSgpO1xuICB9XG59XG5cbi8vIEluaXRpYWwgcGFpbnQuXG52b2lkIHJlZnJlc2hTdGF0ZSgpO1xudm9pZCByZWZyZXNoQWN0aXZpdHkoKTtcblxuLy8gUGVyaW9kaWNhbGx5IHJlLWZldGNoIHN0YXRlIHNvIFwibGFzdCBjYXB0dXJlXCIgdGltZXMgc3RheSBmcmVzaC5cbnNldEludGVydmFsKCgpID0+IHtcbiAgdm9pZCByZWZyZXNoU3RhdGUoKTtcbn0sIDE1XzAwMCk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUE4Rk8sSUFBTSxvQkFBb0I7QUFHMUIsSUFBTSxnQ0FBZ0MsS0FBSyxLQUFLOzs7QUNoRnZELElBQU0sSUFBSSxDQUFzQyxPQUFrQjtBQUNoRSxRQUFNLEtBQUssU0FBUyxlQUFlLEVBQUU7QUFDckMsTUFBSSxDQUFDLEdBQUksT0FBTSxJQUFJLE1BQU0sb0JBQW9CLEVBQUUsRUFBRTtBQUNqRCxTQUFPO0FBQ1Q7QUFFQSxJQUFNLFVBQVUsRUFBRSxVQUFVO0FBQzVCLElBQU0sV0FBVyxFQUFtQixXQUFXO0FBQy9DLElBQU0sY0FBYyxFQUFvQixjQUFjO0FBQ3RELElBQU0sa0JBQWtCLEVBQW9CLG1CQUFtQjtBQUMvRCxJQUFNLGVBQWUsRUFBb0IsZUFBZTtBQUN4RCxJQUFNLGFBQWEsRUFBb0IsY0FBYztBQUNyRCxJQUFNLHVCQUF1QixFQUFvQixpQkFBaUI7QUFDbEUsSUFBTSxxQkFBcUIsRUFBb0IsZUFBZTtBQUM5RCxJQUFNLGdCQUFnQixFQUFxQixhQUFhO0FBQ3hELElBQU0saUJBQWlCLEVBQXFCLGNBQWM7QUFDMUQsSUFBTSxXQUFXLEVBQXFCLFdBQVc7QUFDakQsSUFBTSxjQUFjLEVBQXFCLGNBQWM7QUFDdkQsSUFBTSxhQUFhLEVBQXFCLGFBQWE7QUFDckQsSUFBTSxjQUFjLEVBQXFCLGdCQUFnQjtBQUN6RCxJQUFNLGVBQWUsRUFBbUIsYUFBYTtBQUNyRCxJQUFNLGVBQWUsRUFBb0IsZUFBZTtBQUN4RCxJQUFNLGNBQWMsRUFBbUIsY0FBYztBQUNyRCxJQUFNLHFCQUFxQixFQUFvQixzQkFBc0I7QUFDckUsSUFBTSxtQkFBbUIsRUFBbUIsa0JBQWtCO0FBQzlELElBQU0sbUJBQW1CLEVBQW1CLG9CQUFvQjtBQUNoRSxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLGlCQUFpQixFQUFlLGlCQUFpQjtBQUN2RCxJQUFNLGVBQWUsRUFBbUIsZUFBZTtBQUN2RCxJQUFNLGtCQUFrQixFQUFxQixlQUFlO0FBQzVELElBQU0sbUJBQW1CLEVBQXFCLGdCQUFnQjtBQUM5RCxJQUFNLGtCQUFrQixFQUFtQixrQkFBa0I7QUFDN0QsSUFBTSxvQkFBb0IsRUFBZSxxQkFBcUI7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsbUJBQW1CO0FBQzlELElBQU0scUJBQXFCLEVBQXFCLG1CQUFtQjtBQUNuRSxJQUFNLHNCQUFzQixFQUFxQixvQkFBb0I7QUFDckUsSUFBTSxxQkFBcUIsRUFBbUIsc0JBQXNCO0FBQ3BFLElBQU0sb0JBQW9CLEVBQWUscUJBQXFCO0FBQzlELElBQU0sa0JBQWtCLEVBQW1CLG1CQUFtQjtBQUM5RCxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLFlBQVksRUFBcUIsaUJBQWlCO0FBQ3hELElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLG1CQUFtQixFQUFvQixvQkFBb0I7QUFDakUsSUFBTSxvQkFBb0IsRUFBbUIscUJBQXFCO0FBRWxFLElBQUksWUFBbUM7QUFFdkMsZUFBZSxLQUFRLEtBQWlDO0FBQ3RELFNBQU8sUUFBUSxRQUFRLFlBQVksR0FBRztBQUN4QztBQUVBLElBQU0saUJBQXNEO0FBQUEsRUFDMUQsUUFBUTtBQUFBLEVBQ1IsT0FBTztBQUFBLEVBQ1AsUUFBUTtBQUNWO0FBRUEsU0FBUyxtQkFBbUIsTUFBMkI7QUFDckQsbUJBQWlCLGdCQUFnQjtBQUNqQyxNQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3JCLHNCQUFrQixjQUFjO0FBQ2hDLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIscUJBQWlCLE9BQU8sRUFBRTtBQUMxQjtBQUFBLEVBQ0Y7QUFDQSxvQkFBa0IsY0FBYyxHQUFHLEtBQUssTUFBTSxPQUFPLEtBQUssV0FBVyxJQUFJLEtBQUssR0FBRztBQUNqRixhQUFXLEtBQUssTUFBTTtBQUNwQixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZLGVBQWUsRUFBRSxJQUFJO0FBQ3BDLFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQ0gsRUFBRSxjQUFjLEVBQUUsVUFDZCxJQUFJLEVBQUUsTUFBTSxTQUFNLEVBQUUsU0FBUyxLQUM3QixJQUFJLEVBQUUsTUFBTSxTQUFNLEVBQUUsU0FBUyxXQUFNLEVBQUUsT0FBTztBQUNsRCxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBQ2pCLFVBQU0sT0FBTyxFQUFFLGFBQWEsSUFBSSxHQUFHLEVBQUUsVUFBVSxRQUFRO0FBQ3ZELFNBQUssY0FBYyxHQUFHLGVBQWUsRUFBRSxJQUFJLENBQUMsU0FBTSxJQUFJLFNBQU0sRUFBRSxlQUFlO0FBQzdFLFNBQUssT0FBTyxNQUFNLElBQUk7QUFDdEIsVUFBTSxPQUFPLFNBQVMsY0FBYyxRQUFRO0FBQzVDLFNBQUssT0FBTztBQUNaLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWM7QUFDbkIsU0FBSyxRQUFRLGlCQUFpQixFQUFFLFFBQVEsU0FBSSxFQUFFLE1BQU0sU0FBUyxFQUFFLE1BQU07QUFDckUsU0FBSyxpQkFBaUIsU0FBUyxNQUFNO0FBQ25DLFdBQUssS0FBSyxFQUFFLE1BQU0sWUFBWSxLQUFLLEVBQUUsVUFBVSxDQUFDO0FBQUEsSUFDbEQsQ0FBQztBQUNELE9BQUcsT0FBTyxNQUFNLElBQUk7QUFDcEIscUJBQWlCLE9BQU8sRUFBRTtBQUFBLEVBQzVCO0FBQ0Y7QUFFQSxvQkFBb0IsaUJBQWlCLFNBQVMsWUFBWTtBQUN4RCxzQkFBb0IsV0FBVztBQUMvQixvQkFBa0IsY0FBYztBQUNoQyxNQUFJO0FBQ0YsVUFBTSxNQUFNLE1BQU0sS0FBNEQ7QUFBQSxNQUM1RSxNQUFNO0FBQUEsSUFDUixDQUFDO0FBQ0QsUUFBSSxDQUFDLElBQUksTUFBTSxDQUFDLElBQUksTUFBTTtBQUN4Qix3QkFBa0IsY0FBYyxJQUFJLFNBQVM7QUFDN0MsdUJBQWlCLGdCQUFnQjtBQUNqQztBQUFBLElBQ0Y7QUFDQSx1QkFBbUIsSUFBSSxJQUFJO0FBQUEsRUFDN0IsVUFBRTtBQUNBLHdCQUFvQixXQUFXO0FBQUEsRUFDakM7QUFDRixDQUFDO0FBRUQsU0FBUyxjQUFjLE9BQTZCO0FBQ2xELFFBQU0sRUFBRSxZQUFZLFNBQVMsSUFBSTtBQUNqQyxNQUFJLE1BQU07QUFDVixNQUFJLE9BQU87QUFLWCxRQUFNLGdCQUNKLFdBQVcsV0FBVyxRQUFRLFNBQVMsVUFBVSxXQUFXLDJCQUEyQjtBQUN6RixNQUFJLENBQUMsU0FBUyxRQUFRO0FBQ3BCLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxXQUFXLGVBQWU7QUFDeEIsVUFBTTtBQUNOLFdBQU8sV0FBVyxTQUFTLE1BQU0sdUJBQXVCLFNBQVMsS0FBSyxJQUFJLFNBQVMsSUFBSSw0Q0FBdUMsV0FBVyxpQkFBaUIsUUFBUTtBQUFBLEVBQ3BLLFdBQVcsV0FBVyxXQUFXLE1BQU07QUFDckMsVUFBTTtBQUNOLFdBQU8saUJBQWlCLFdBQVcsU0FBUyxHQUFHLE9BQU8sU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLGVBQU8sU0FBUyxTQUFTO0FBQUEsRUFDaEgsV0FBVyxXQUFXLFdBQVcsY0FBYztBQUM3QyxVQUFNO0FBQ04sV0FBTyxpQkFBaUIsV0FBVyxLQUFLLElBQ3BDLG9FQUNBO0FBQUEsRUFDTixXQUFXLFdBQVcsV0FBVyxnQkFBZ0I7QUFDL0MsVUFBTTtBQUNOLFVBQU0sU0FBUyxrQkFBa0IsV0FBVyxnQkFBZ0I7QUFDNUQsV0FBTyxTQUNILHFDQUFnQyxNQUFNLEtBQ3RDO0FBQUEsRUFDTixXQUFXLFdBQVcsV0FBVyxpQkFBaUI7QUFDaEQsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsV0FBVyxXQUFXLGtCQUFrQjtBQUNqRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsT0FBTztBQUNMLFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVDtBQUNBLFVBQVEsWUFBWSxPQUFPLEdBQUc7QUFDOUIsV0FBUyxjQUFjO0FBQ3ZCLFdBQVMsUUFBUSxXQUFXLFNBQVM7QUFDdkM7QUFFQSxTQUFTLE9BQU8sS0FBNEI7QUFDMUMsTUFBSSxDQUFDLElBQUssUUFBTztBQUNqQixRQUFNLElBQUksS0FBSyxNQUFNLEdBQUc7QUFDeEIsTUFBSSxDQUFDLE9BQU8sU0FBUyxDQUFDLEVBQUcsUUFBTztBQUNoQyxRQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssR0FBSSxDQUFDO0FBQzVELE1BQUksT0FBTyxFQUFHLFFBQU87QUFDckIsTUFBSSxPQUFPLEdBQUksUUFBTyxHQUFHLElBQUk7QUFDN0IsUUFBTSxPQUFPLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDakMsTUFBSSxPQUFPLEdBQUksUUFBTyxHQUFHLElBQUk7QUFDN0IsUUFBTSxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDbEMsTUFBSSxRQUFRLEdBQUksUUFBTyxHQUFHLEtBQUs7QUFDL0IsUUFBTSxPQUFPLEtBQUssTUFBTSxRQUFRLEVBQUU7QUFDbEMsU0FBTyxHQUFHLElBQUk7QUFDaEI7QUFFQSxTQUFTLGtCQUFrQixVQUFpQztBQUMxRCxNQUFJLGFBQWEsS0FBTSxRQUFPO0FBQzlCLFFBQU0sV0FBVyxXQUFXLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJO0FBQ3hELE1BQUksWUFBWSxFQUFHLFFBQU87QUFDMUIsUUFBTSxZQUFZLElBQUksS0FBSyxXQUFXLEdBQUksRUFBRSxtQkFBbUIsQ0FBQyxHQUFHO0FBQUEsSUFDakUsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUNELE1BQUksV0FBVyxHQUFJLFFBQU8sTUFBTSxRQUFRLE1BQU0sU0FBUztBQUN2RCxRQUFNLE9BQU8sS0FBSyxNQUFNLFdBQVcsRUFBRTtBQUNyQyxNQUFJLE9BQU8sR0FBSSxRQUFPLE1BQU0sSUFBSSxNQUFNLFNBQVM7QUFDL0MsUUFBTSxRQUFRLEtBQUssTUFBTSxPQUFPLEVBQUU7QUFDbEMsU0FBTyxNQUFNLEtBQUssTUFBTSxTQUFTO0FBQ25DO0FBRUEsU0FBUyxPQUFPLEdBQW1CO0FBQ2pDLFNBQU8sRUFBRSxlQUFlLE9BQU87QUFDakM7QUFFQSxTQUFTLGlCQUFpQixTQUFpQztBQUN6RCxTQUNFLE9BQU8sWUFBWSxZQUNuQiw2RUFBNkUsS0FBSyxPQUFPO0FBRTdGO0FBRUEsU0FBUyxlQUFlLE9BQTZCO0FBQ25ELGNBQVksZ0JBQWdCO0FBQzVCLE1BQUksTUFBTSxTQUFTLFdBQVcsR0FBRztBQUMvQixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLGdCQUFZLE9BQU8sRUFBRTtBQUNyQjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLEtBQUssTUFBTSxVQUFVO0FBQzlCLFVBQU0sSUFBSSxNQUFNLFNBQVMsRUFBRSxNQUFNO0FBQ2pDLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksS0FBSyxFQUFFLGdCQUFnQixJQUFJLGdCQUFnQjtBQUUxRCxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBQ2pCLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVk7QUFDbkIsV0FBTyxZQUFZLDRCQUE0QixXQUFXLEVBQUUsTUFBTSxDQUFDO0FBQ25FLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLEVBQUU7QUFDckIsU0FBSyxPQUFPLFFBQVEsSUFBSTtBQUV4QixVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFVBQU0sUUFBUSxTQUFTLGNBQWMsTUFBTTtBQUMzQyxVQUFNLFlBQVk7QUFDbEIsVUFBTSxRQUFRLEdBQUcsY0FBYztBQUMvQixVQUFNLFdBQVcsR0FBRyxpQkFBaUI7QUFDckMsVUFBTSxPQUFPLEdBQUcsaUJBQWlCO0FBQ2pDLFVBQU0sWUFDSixxQkFBcUIsT0FBTyxLQUFLLENBQUMsbUJBQ2pDLFdBQVcsSUFBSSwyQkFBd0IsT0FBTyxRQUFRLENBQUMscUJBQXFCLE1BQzdFLGNBQVcsV0FBVyxPQUFPLElBQUksQ0FBQyxDQUFDO0FBRXJDLFVBQU0sVUFBVSxTQUFTLGNBQWMsTUFBTTtBQUM3QyxZQUFRLFlBQVk7QUFDcEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxRQUFRO0FBQzNDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWM7QUFDbEIsUUFBSSxpQkFBaUIsU0FBUyxZQUFZO0FBQ3hDLFVBQUksV0FBVztBQUNmLFVBQUk7QUFDRixjQUFNLEtBQUssRUFBRSxNQUFNLGVBQWUsUUFBUSxFQUFFLE9BQU8sQ0FBQztBQUFBLE1BQ3RELFVBQUU7QUFDQSxZQUFJLFdBQVc7QUFBQSxNQUNqQjtBQUFBLElBQ0YsQ0FBQztBQUNELFlBQVEsT0FBTyxHQUFHO0FBRWxCLFFBQUksT0FBTyxPQUFPLE9BQU87QUFDekIsT0FBRyxPQUFPLE1BQU0sR0FBRztBQUNuQixnQkFBWSxPQUFPLEVBQUU7QUFBQSxFQUN2QjtBQUNGO0FBRUEsU0FBUyxlQUFlLFFBQTBCO0FBQ2hELGVBQWEsZ0JBQWdCO0FBQzdCLE1BQUksT0FBTyxXQUFXLEdBQUc7QUFDdkIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixpQkFBYSxPQUFPLEVBQUU7QUFDdEI7QUFBQSxFQUNGO0FBQ0EsYUFBVyxNQUFNLE9BQU8sTUFBTSxHQUFHLGlCQUFpQixHQUFHO0FBQ25ELFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDN0IsVUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQ3hDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUM5RSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxHQUFHLFVBQVUsVUFBVSxXQUFNLEdBQUcsVUFBVSxTQUFTLE1BQU07QUFDNUUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLEdBQUc7QUFDckIsU0FBSyxPQUFPLEdBQUc7QUFDZixVQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTztBQUN0QyxRQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLFlBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxVQUFJLFlBQVk7QUFDaEIsVUFBSSxjQUFjLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssUUFBSztBQUN4RixXQUFLLE9BQU8sR0FBRztBQUFBLElBQ2pCO0FBQ0EsT0FBRyxPQUFPLElBQUksTUFBTSxJQUFJO0FBQ3hCLGlCQUFhLE9BQU8sRUFBRTtBQUFBLEVBQ3hCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsR0FBb0I7QUFDMUMsTUFBSSxNQUFNLEtBQU0sUUFBTztBQUN2QixNQUFJLE9BQU8sTUFBTSxTQUFVLFFBQU8sRUFBRSxTQUFTLEtBQUssR0FBRyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsV0FBTTtBQUN6RSxNQUFJLE9BQU8sTUFBTSxZQUFZLE9BQU8sTUFBTSxVQUFXLFFBQU8sT0FBTyxDQUFDO0FBQ3BFLE1BQUk7QUFDRixVQUFNLElBQUksS0FBSyxVQUFVLENBQUM7QUFDMUIsV0FBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQUEsRUFDaEQsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFQSxTQUFTLFdBQVcsR0FBbUI7QUFDckMsU0FBTyxFQUFFO0FBQUEsSUFBUTtBQUFBLElBQVksQ0FBQyxNQUM1QixNQUFNLE1BQU0sVUFBVSxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sU0FBUyxNQUFNLE1BQU0sV0FBVztBQUFBLEVBQ3pGO0FBQ0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLE1BQUk7QUFDRixnQkFBWSxNQUFNLEtBQXFCLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFDNUQsVUFBTSxTQUFTO0FBQUEsRUFDakIsU0FBUyxLQUFLO0FBQ1osWUFBUSxLQUFLLDZDQUE2QyxHQUFHO0FBQUEsRUFDL0Q7QUFDRjtBQUVBLFNBQVMsTUFBTSxPQUE2QjtBQUMxQyxlQUFhLGNBQWMsTUFBTTtBQUNqQyxnQkFBYyxLQUFLO0FBQ25CLGFBQVcsVUFBVSxNQUFNLFNBQVM7QUFDcEMsdUJBQXFCLFVBQVUsTUFBTSxTQUFTLG1CQUFtQjtBQUNqRSxxQkFBbUIsVUFBVSxNQUFNLFNBQVMseUJBQXlCO0FBQ3JFLGFBQVcsT0FBTyxXQUFXLE1BQU0sU0FBUyxLQUFLLGNBQWMsTUFBTSxTQUFTLElBQUk7QUFDbEYsb0JBQWtCLEtBQUs7QUFDdkIsaUJBQWUsS0FBSztBQUNwQixxQkFBbUIsTUFBTSxvQkFBb0I7QUFDN0Msa0JBQWdCLEtBQUs7QUFDckIsa0JBQWdCLEtBQUs7QUFDckIsZUFBYSxLQUFLO0FBQ2xCLGtCQUFnQixLQUFLO0FBQ3ZCO0FBRUEsU0FBUyxtQkFBbUIsTUFBNkI7QUFDdkQsa0JBQWdCLGdCQUFnQjtBQUNoQyxNQUFJLEtBQUssV0FBVyxHQUFHO0FBQ3JCLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsb0JBQWdCLE9BQU8sRUFBRTtBQUN6QjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLE9BQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxHQUFHO0FBQ25DLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVksZ0JBQWdCLElBQUksY0FBYztBQUVqRCxVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxZQUFZO0FBQ2hCLFVBQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztBQUN2QyxTQUFLLFlBQVk7QUFDakIsU0FBSyxPQUFPLElBQUk7QUFDaEIsU0FBSyxTQUFTO0FBQ2QsU0FBSyxNQUFNO0FBQ1gsU0FBSyxjQUFjLElBQUksSUFBSSxjQUFjO0FBQ3pDLFVBQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtBQUM1QyxXQUFPLFlBQVksY0FBYyxJQUFJLGNBQWM7QUFDbkQsV0FBTyxjQUFjLElBQUksbUJBQW1CLFVBQVUsVUFBVTtBQUNoRSxRQUFJLE9BQU8sTUFBTSxNQUFNO0FBRXZCLFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLGFBQWEsSUFBSSxNQUFNLEdBQUc7QUFFN0MsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsR0FBRyxrQkFBa0IsSUFBSSxNQUFNLENBQUMsU0FBTSxJQUFJLFVBQVUsZ0JBQWEsT0FBTyxJQUFJLFNBQVMsQ0FBQztBQUV6RyxPQUFHLE9BQU8sS0FBSyxNQUFNLElBQUk7QUFDekIsb0JBQWdCLE9BQU8sRUFBRTtBQUFBLEVBQzNCO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixRQUF5QztBQUNsRSxNQUFJLFdBQVcsV0FBWSxRQUFPO0FBQ2xDLE1BQUksV0FBVyxZQUFhLFFBQU87QUFDbkMsU0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLE1BQWMsS0FBcUI7QUFDdkQsUUFBTSxVQUFVLEtBQUssUUFBUSxRQUFRLEdBQUcsRUFBRSxLQUFLO0FBQy9DLFNBQU8sUUFBUSxVQUFVLE1BQU0sVUFBVSxHQUFHLFFBQVEsTUFBTSxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQ3ZFO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsb0JBQWtCLFNBQVMsVUFBVSxLQUFLLENBQUM7QUFDM0Msa0JBQWdCLGNBQ2QsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELHFCQUFtQixTQUFTO0FBQzVCLHFCQUFtQixXQUFXLFVBQVU7QUFDeEMsc0JBQW9CLFNBQVMsQ0FBQztBQUM5QixxQkFBbUIsb0JBQW9CLENBQUM7QUFDMUM7QUFFQSxTQUFTLG1CQUNQLElBQ0EsR0FDTTtBQUNOLE1BQUksQ0FBQyxFQUFFLFdBQVcsRUFBRSxjQUFjLEdBQUc7QUFDbkMsT0FBRyxTQUFTO0FBQ1o7QUFBQSxFQUNGO0FBR0EsUUFBTSxRQUFRLEtBQUssSUFBSSxFQUFFLGdCQUFnQixFQUFFLFlBQVksRUFBRSxLQUFLO0FBQzlELEtBQUcsU0FBUztBQUNaLEtBQUcsY0FBYyxHQUFHLE9BQU8sRUFBRSxTQUFTLENBQUMsTUFBTSxPQUFPLEtBQUssQ0FBQztBQUMxRCxLQUFHLFlBQVksRUFBRSxVQUFVLGdCQUFnQjtBQUM3QztBQUVBLFNBQVMsa0JBQWtCLE9BQTZCO0FBQ3RELFFBQU0sS0FBSyxNQUFNLFNBQVMsWUFBWTtBQUN0QyxlQUFhLFVBQVU7QUFDdkIsY0FBWSxjQUFjLEtBQUssT0FBTztBQUN0QyxXQUFTLEtBQUssVUFBVSxPQUFPLFVBQVUsQ0FBQyxFQUFFO0FBQzlDO0FBRUEsU0FBUyxnQkFBZ0IsT0FBNkI7QUFDcEQsUUFBTSxPQUFPLE1BQU0sU0FBUztBQUM1QixxQkFBbUIsUUFBUSxPQUFPLElBQUk7QUFDdEMsbUJBQWlCLGNBQWMsT0FBTyxJQUFJO0FBQzFDLFFBQU0sS0FBSyxNQUFNO0FBQ2pCLHFCQUFtQixTQUFTLEdBQUc7QUFDL0Isc0JBQW9CLFNBQVMsQ0FBQyxHQUFHO0FBQ2pDLE1BQUksR0FBRyxRQUFRO0FBQ2IsVUFBTSxJQUFJLEdBQUc7QUFDYixxQkFBaUIsY0FDZixNQUFNLElBQUksa0NBQTZCLGtCQUFhLENBQUMsSUFBSSxNQUFNLElBQUksUUFBUSxNQUFNO0FBQ25GLHFCQUFpQixZQUFZO0FBQUEsRUFDL0IsT0FBTztBQUNMLHFCQUFpQixjQUFjO0FBQy9CLHFCQUFpQixZQUFZO0FBQUEsRUFDL0I7QUFDQSxNQUFJLEdBQUcsVUFBVSxHQUFHLGNBQWMsS0FBSyxHQUFHLGdCQUFnQixHQUFHO0FBQzNELHVCQUFtQixTQUFTO0FBQzVCLFVBQU0sUUFBUTtBQUFBLE1BQ1osR0FBRyxPQUFPLEdBQUcsV0FBVyxDQUFDO0FBQUEsTUFDekIsR0FBRyxPQUFPLEdBQUcsZ0JBQWdCLENBQUM7QUFBQSxNQUM5QixHQUFHLE9BQU8sR0FBRyxxQkFBcUIsQ0FBQztBQUFBLElBQ3JDO0FBQ0EsUUFBSSxHQUFHLGtCQUFrQixFQUFHLE9BQU0sS0FBSyxHQUFHLE9BQU8sR0FBRyxlQUFlLENBQUMsY0FBYztBQUNsRixVQUFNLEtBQUssR0FBRyxPQUFPLEdBQUcsYUFBYSxDQUFDLFdBQVc7QUFDakQsdUJBQW1CLGNBQWMsTUFBTSxLQUFLLFFBQUs7QUFDakQsdUJBQW1CLFlBQVksR0FBRyxTQUFTLGdCQUFnQjtBQUFBLEVBQzdELE9BQU87QUFDTCx1QkFBbUIsU0FBUztBQUFBLEVBQzlCO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsT0FBNkI7QUFDakQsUUFBTSxJQUFJLE1BQU07QUFDaEIsUUFBTSxRQUFRLEVBQUU7QUFDaEIsUUFBTSxVQUFVLEVBQUU7QUFDbEIsaUJBQWUsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUN4QyxlQUFhLGNBQ1gsVUFBVSxJQUNOLFVBQ0Usb0JBQ0EsYUFDRixHQUFHLE9BQU8sS0FBSyxDQUFDLFVBQVUsVUFBVSxrQkFBZSxFQUFFO0FBQzNELGtCQUFnQixTQUFTO0FBQ3pCLGtCQUFnQixXQUFXLFVBQVU7QUFDckMsbUJBQWlCLFNBQVMsQ0FBQztBQUMzQixxQkFBbUIsaUJBQWlCLENBQUM7QUFDdkM7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLElBQUksTUFBTTtBQUNoQixRQUFNLFFBQVEsRUFBRTtBQUNoQixRQUFNLFVBQVUsRUFBRTtBQUNsQixvQkFBa0IsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUMzQyxrQkFBZ0IsY0FDZCxVQUFVLElBQ04sVUFDRSxpQkFDQSxhQUNGLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxVQUFVLGtCQUFlLEVBQUU7QUFDM0QscUJBQW1CLFNBQVM7QUFDNUIscUJBQW1CLFdBQVcsVUFBVTtBQUN4QyxzQkFBb0IsU0FBUyxDQUFDO0FBQzlCLHFCQUFtQixvQkFBb0IsQ0FBQztBQUMxQztBQUVBLGVBQWUsa0JBQWlDO0FBRzlDLFFBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVTtBQUN6RCxRQUFNLFNBQVUsT0FBTyxZQUF1QyxDQUFDO0FBQy9ELGlCQUFlLE1BQU07QUFDdkI7QUFJQSxjQUFjLGlCQUFpQixTQUFTLFlBQVk7QUFDbEQsZ0JBQWMsV0FBVztBQUN6QixNQUFJO0FBQ0YsVUFBTSxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFBQSxFQUNwQyxVQUFFO0FBQ0Esa0JBQWMsV0FBVztBQUFBLEVBQzNCO0FBQ0YsQ0FBQztBQUVELGVBQWUsaUJBQWlCLFNBQVMsWUFBWTtBQUNuRCxpQkFBZSxXQUFXO0FBQzFCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQUEsRUFDMUMsVUFBRTtBQUNBLG1CQUFlLFdBQVc7QUFBQSxFQUM1QjtBQUNGLENBQUM7QUFFRCxTQUFTLGlCQUFpQixTQUFTLFlBQVk7QUFDN0MsV0FBUyxXQUFXO0FBQ3BCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLFlBQVksQ0FBQztBQUFBLEVBQ2xDLFVBQUU7QUFDQSxhQUFTLFdBQVc7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxXQUFXLGlCQUFpQixVQUFVLE1BQU07QUFDMUMsT0FBSyxLQUFLLEVBQUUsTUFBTSx1QkFBdUIsSUFBSSxXQUFXLFFBQVEsQ0FBQztBQUNuRSxDQUFDO0FBRUQscUJBQXFCLGlCQUFpQixVQUFVLE1BQU07QUFDcEQsT0FBSyxLQUFLLEVBQUUsTUFBTSwwQkFBMEIsSUFBSSxxQkFBcUIsUUFBUSxDQUFDO0FBQ2hGLENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFVBQVUsTUFBTTtBQUNsRCxPQUFLLEtBQUssRUFBRSxNQUFNLHdCQUF3QixJQUFJLG1CQUFtQixRQUFRLENBQUM7QUFDNUUsQ0FBQztBQUVELGFBQWEsaUJBQWlCLFVBQVUsTUFBTTtBQUM1QyxPQUFLLEtBQUssRUFBRSxNQUFNLGtCQUFrQixJQUFJLGFBQWEsUUFBUSxDQUFDO0FBQ2hFLENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxxQkFBbUIsV0FBVztBQUM5QixPQUFLLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3JELHVCQUFtQixXQUFXO0FBQUEsRUFDaEMsQ0FBQztBQUNILENBQUM7QUFDRCxvQkFBb0IsaUJBQWlCLFNBQVMsTUFBTTtBQUNsRCxzQkFBb0IsV0FBVztBQUMvQixPQUFLLEtBQUssRUFBRSxNQUFNLHFCQUFxQixDQUFDLEVBQUUsUUFBUSxNQUFNO0FBQ3RELHdCQUFvQixXQUFXO0FBQUEsRUFDakMsQ0FBQztBQUNILENBQUM7QUFFRCxtQkFBbUIsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxtQkFBaUIsY0FBYyxtQkFBbUI7QUFDcEQsQ0FBQztBQUNELG1CQUFtQixpQkFBaUIsVUFBVSxNQUFNO0FBQ2xELFFBQU0sVUFBVSxPQUFPLG1CQUFtQixLQUFLO0FBQy9DLE1BQUksT0FBTyxTQUFTLE9BQU8sR0FBRztBQUM1QixTQUFLLEtBQUssRUFBRSxNQUFNLDRCQUE0QixRQUFRLENBQUM7QUFBQSxFQUN6RDtBQUNGLENBQUM7QUFFRCxVQUFVLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNoRCxJQUFFLGVBQWU7QUFDakIsUUFBTSxLQUFLLE9BQU87QUFBQSxJQUNoQjtBQUFBLEVBR0Y7QUFDQSxNQUFJLENBQUMsR0FBSTtBQUNULE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFDdkMsQ0FBQztBQUVELGdCQUFnQixpQkFBaUIsU0FBUyxNQUFNO0FBQzlDLGtCQUFnQixXQUFXO0FBQzNCLE9BQUssS0FBSyxFQUFFLE1BQU0sZ0JBQWdCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDakQsb0JBQWdCLFdBQVc7QUFBQSxFQUM3QixDQUFDO0FBQ0gsQ0FBQztBQUVELGlCQUFpQixpQkFBaUIsU0FBUyxNQUFNO0FBQy9DLG1CQUFpQixXQUFXO0FBQzVCLE9BQUssS0FBSyxFQUFFLE1BQU0saUJBQWlCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDbEQscUJBQWlCLFdBQVc7QUFBQSxFQUM5QixDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2xELElBQUUsZUFBZTtBQUNqQixPQUFLLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNwQyxDQUFDO0FBRUQsV0FBVyxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDakQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQ25DLENBQUM7QUFFRCxZQUFZLGlCQUFpQixTQUFTLFlBQVk7QUFDaEQsUUFBTSxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNyQyxpQkFBZSxDQUFDLENBQUM7QUFDbkIsQ0FBQztBQUVELFFBQVEsUUFBUSxVQUFVLFlBQVksQ0FBQyxRQUFpQjtBQUN0RCxNQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsU0FBVTtBQUNyQyxRQUFNLElBQUk7QUFDVixNQUFJLEVBQUUsU0FBUyxtQkFBbUIsRUFBRSxPQUFPO0FBQ3pDLGdCQUFZLEVBQUU7QUFDZCxVQUFNLEVBQUUsS0FBSztBQUFBLEVBQ2YsV0FBVyxFQUFFLFNBQVMsZUFBZSxFQUFFLE9BQU87QUFDNUMsaUJBQWEsRUFBRSxLQUFLO0FBQUEsRUFDdEI7QUFDRixDQUFDO0FBRUQsU0FBUyxhQUFhLElBQW9CO0FBRXhDLE1BQUksYUFBYSxtQkFBbUIsVUFBVSxTQUFTLE9BQU8sR0FBRztBQUMvRCxpQkFBYSxnQkFBZ0I7QUFBQSxFQUMvQjtBQUNBLFFBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxLQUFHLFlBQVksTUFBTSxHQUFHLEtBQUs7QUFDN0IsUUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQ3hDLEtBQUcsWUFBWTtBQUNmLEtBQUcsY0FBYyxJQUFJLEtBQUssR0FBRyxFQUFFLEVBQUUsbUJBQW1CLFNBQVMsRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUM5RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsT0FBSyxZQUFZO0FBQ2pCLE9BQUssY0FBYyxHQUFHLFVBQVUsVUFBVSxXQUFNLEdBQUcsVUFBVSxTQUFTLE1BQU07QUFDNUUsUUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFFBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxNQUFJLFlBQVk7QUFDaEIsTUFBSSxjQUFjLEdBQUc7QUFDckIsT0FBSyxPQUFPLEdBQUc7QUFDZixRQUFNLFVBQVUsT0FBTyxLQUFLLEdBQUcsT0FBTztBQUN0QyxNQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUFjLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksZUFBZSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssUUFBSztBQUN4RixTQUFLLE9BQU8sR0FBRztBQUFBLEVBQ2pCO0FBQ0EsS0FBRyxPQUFPLElBQUksTUFBTSxJQUFJO0FBQ3hCLGVBQWEsUUFBUSxFQUFFO0FBQ3ZCLFNBQU8sYUFBYSxvQkFBb0IsbUJBQW1CO0FBQ3pELGlCQUFhLGtCQUFrQixPQUFPO0FBQUEsRUFDeEM7QUFDRjtBQUdBLEtBQUssYUFBYTtBQUNsQixLQUFLLGdCQUFnQjtBQUdyQixZQUFZLE1BQU07QUFDaEIsT0FBSyxhQUFhO0FBQ3BCLEdBQUcsSUFBTTsiLAogICJuYW1lcyI6IFtdCn0K
