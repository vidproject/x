var browser=globalThis.browser??globalThis.chrome;

// src/lib/config.ts
var ACTIVITY_TAIL_MAX = 250;
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// src/sidebar.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var connDot = $("conn-dot");
var connText = $("conn-text");
var accountList = $("account-list");
var recentTweetList = $("recent-tweet-list");
var activityList = $("activity-list");
var autoToggle = $("auto-capture");
var updateExistingToggle = $("update-existing");
var lowBandwidthToggle = $("low-bandwidth");
var captureAllBtn = $("capture-all");
var captureThisBtn = $("capture-this");
var flushBtn = $("flush-all");
var optionsLink = $("open-options");
var viewerLink = $("open-viewer");
var clearActBtn = $("clear-activity");
var extVersionEl = $("ext-version");
var masterSwitch = $("master-switch");
var masterLabel = $("master-label");
var autoScrollInterval = $("auto-scroll-interval");
var autoScrollSecsEl = $("auto-scroll-secs");
var autoScrollStatus = $("auto-scroll-status");
var autoScrollStartBtn = $("auto-scroll-start");
var autoScrollCancelBtn = $("auto-scroll-cancel");
var autoScrollProgress = $("auto-scroll-progress");
var refetchSection = $("refetch-section");
var refetchCount = $("refetch-count");
var refetchStartBtn = $("refetch-start");
var refetchCancelBtn = $("refetch-cancel");
var refetchProgress = $("refetch-progress");
var mediaCrawlSection = $("media-crawl-section");
var mediaCrawlCount = $("media-crawl-count");
var mediaCrawlStartBtn = $("media-crawl-start");
var mediaCrawlCancelBtn = $("media-crawl-cancel");
var mediaCrawlProgress = $("media-crawl-progress");
var threadOpenSection = $("thread-open-section");
var threadOpenCount = $("thread-open-count");
var threadOpenStartBtn = $("thread-open-start");
var threadOpenCancelBtn = $("thread-open-cancel");
var threadOpenProgress = $("thread-open-progress");
var purgeLink = $("purge-unrelated");
var lastState = null;
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setConnStatus(state) {
  const { connection, settings } = state;
  let cls = "";
  let text = "";
  const branchMissing = connection.status === "ok" && settings.branch && connection.configuredBranchExists === false;
  if (!settings.patSet) {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else if (branchMissing) {
    cls = "err";
    text = `Branch "${settings.branch}" does not exist on ${settings.owner}/${settings.repo} \u2014 commits will 422. Set branch to "${connection.defaultBranch ?? "master"}" in Settings.`;
  } else if (connection.status === "ok") {
    cls = "ok";
    text = `Connected as @${connection.login ?? "?"} to ${settings.owner}/${settings.repo} \xB7 \u2026${settings.patSuffix}`;
  } else if (connection.status === "auth-error") {
    cls = "err";
    text = isWriteAuthError(connection.error) ? "PAT can read repo but cannot write - set Contents: Read & Write" : "Auth error - check your PAT";
  } else if (connection.status === "rate-limited") {
    cls = "warn";
    const resets = fmtRateLimitReset(connection.rateLimitResetAt);
    text = resets ? `GitHub rate-limited \u2014 resets ${resets}` : "GitHub rate-limited \u2014 captures will retry";
  } else if (connection.status === "network-error") {
    cls = "err";
    text = "Network error \u2014 check connectivity";
  } else if (connection.status === "not-configured") {
    cls = "warn";
    text = "Not configured \u2014 open Settings";
  } else {
    cls = "";
    text = "Checking\u2026";
  }
  connDot.className = `dot ${cls}`;
  connText.textContent = text;
  connText.title = connection.error ?? "";
}
function fmtRel(iso) {
  if (!iso) return "\u2014";
  const d = Date.parse(iso);
  if (!Number.isFinite(d)) return "\u2014";
  const secs = Math.max(0, Math.round((Date.now() - d) / 1e3));
  if (secs < 5) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  return `${days}d ago`;
}
function fmtRateLimitReset(epochSec) {
  if (epochSec === null) return "";
  const deltaSec = epochSec - Math.floor(Date.now() / 1e3);
  if (deltaSec <= 0) return "momentarily";
  const wallClock = new Date(epochSec * 1e3).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
  if (deltaSec < 60) return `in ${deltaSec}s (${wallClock})`;
  const mins = Math.round(deltaSec / 60);
  if (mins < 60) return `in ${mins}m (${wallClock})`;
  const hours = Math.round(mins / 60);
  return `in ${hours}h (${wallClock})`;
}
function fmtNum(n) {
  return n.toLocaleString("en-US");
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
function renderAccounts(state) {
  accountList.replaceChildren();
  if (state.accounts.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No accounts configured.";
    accountList.append(li);
    return;
  }
  for (const a of state.accounts) {
    const c = state.counters[a.handle];
    const li = document.createElement("li");
    li.className = c && c.bufferedCount > 0 ? "acc pending" : "acc";
    const head = document.createElement("div");
    head.className = "acc-head";
    const handle = document.createElement("span");
    handle.className = "acc-handle";
    handle.innerHTML = `<span class="at">@</span>${escapeHtml(a.handle)}`;
    const meta = document.createElement("span");
    meta.className = "acc-meta";
    meta.textContent = a.label;
    head.append(handle, meta);
    const row = document.createElement("div");
    row.className = "acc-row";
    const stats = document.createElement("span");
    stats.className = "acc-stats";
    const today = c?.todayCount ?? 0;
    const buffered = c?.bufferedCount ?? 0;
    const last = c?.lastCaptureAt ?? null;
    stats.innerHTML = `<span class="num">${fmtNum(today)}</span> today` + (buffered > 0 ? ` \xB7 <span class="num">${fmtNum(buffered)}</span> buffered` : "") + ` \xB7 last ${escapeHtml(fmtRel(last))}`;
    const actions = document.createElement("span");
    actions.className = "acc-action";
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.textContent = "Capture now";
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      try {
        await send({ type: "capture-now", handle: a.handle });
      } finally {
        btn.disabled = false;
      }
    });
    actions.append(btn);
    row.append(stats, actions);
    li.append(head, row);
    accountList.append(li);
  }
}
function renderActivity(events) {
  activityList.replaceChildren();
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No activity yet.";
    activityList.append(li);
    return;
  }
  for (const ev of events.slice(0, ACTIVITY_TAIL_MAX)) {
    const li = document.createElement("li");
    li.className = `ev ${ev.level}`;
    const ts = document.createElement("span");
    ts.className = "ev-ts";
    ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
    const icon = document.createElement("span");
    icon.className = "ev-icon";
    icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
    const body = document.createElement("span");
    const msg = document.createElement("div");
    msg.className = "ev-msg";
    msg.textContent = ev.msg;
    body.append(msg);
    const ctxKeys = Object.keys(ev.context);
    if (ctxKeys.length > 0) {
      const ctx = document.createElement("div");
      ctx.className = "ev-ctx";
      ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
      body.append(ctx);
    }
    li.append(ts, icon, body);
    activityList.append(li);
  }
}
function stringifyShort(v) {
  if (v === null) return "null";
  if (typeof v === "string") return v.length > 80 ? `${v.slice(0, 80)}\u2026` : v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  try {
    const s = JSON.stringify(v);
    return s.length > 80 ? `${s.slice(0, 80)}\u2026` : s;
  } catch {
    return "?";
  }
}
function escapeHtml(s) {
  return s.replace(
    /[&<>"']/g,
    (c) => c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;"
  );
}
async function refreshState() {
  try {
    lastState = await send({ type: "get-state" });
    paint(lastState);
  } catch (err) {
    console.warn("[imm-archive] sidebar refreshState failed", err);
  }
}
function paint(state) {
  extVersionEl.textContent = state.version;
  setConnStatus(state);
  autoToggle.checked = state.settings.autoCapture;
  updateExistingToggle.checked = state.settings.updateExisting !== false;
  lowBandwidthToggle.checked = state.settings.lowBandwidthBrowsing === true;
  viewerLink.href = `https://${state.settings.owner}.github.io/${state.settings.repo}/`;
  paintMasterSwitch(state);
  renderAccounts(state);
  renderRecentTweets(state.recentTweetSightings);
  paintAutoScroll(state);
  paintMediaCrawl(state);
  paintRefetch(state);
  paintThreadOpen(state);
}
function renderRecentTweets(rows) {
  recentTweetList.replaceChildren();
  if (rows.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No tweets seen yet.";
    recentTweetList.append(li);
    return;
  }
  for (const row of rows.slice(0, 40)) {
    const li = document.createElement("li");
    li.className = `recent-tweet ${row.archive_status}`;
    const top = document.createElement("div");
    top.className = "tweet-head";
    const link = document.createElement("a");
    link.className = "tweet-handle";
    link.href = row.tweet_url;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = `@${row.account_handle}`;
    const status = document.createElement("span");
    status.className = `tweet-pill ${row.archive_status}`;
    status.textContent = row.archive_status === "saved" ? "saved" : "new";
    top.append(link, status);
    const text = document.createElement("div");
    text.className = "tweet-text";
    text.textContent = truncateText(row.text, 140);
    const meta = document.createElement("div");
    meta.className = "tweet-meta";
    meta.textContent = `${formatTweetAction(row.action)} \xB7 ${row.tweet_type} \xB7 posted ${fmtRel(row.posted_at)}`;
    li.append(top, text, meta);
    recentTweetList.append(li);
  }
}
function formatTweetAction(action) {
  if (action === "buffered") return "buffered";
  if (action === "unchanged") return "unchanged";
  return "skipped";
}
function truncateText(text, max) {
  const compact = text.replace(/\s+/g, " ").trim();
  return compact.length <= max ? compact : `${compact.slice(0, max - 1)}\u2026`;
}
function paintMediaCrawl(state) {
  const q = state.mediaCrawlQueue;
  const total = q.total;
  const running = q.running;
  mediaCrawlSection.hidden = total === 0 && !running;
  mediaCrawlCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  mediaCrawlStartBtn.hidden = running;
  mediaCrawlStartBtn.disabled = total === 0;
  mediaCrawlCancelBtn.hidden = !running;
  paintQueueProgress(mediaCrawlProgress, q);
}
function paintQueueProgress(el, q) {
  if (!q.running && q.processed === 0) {
    el.hidden = true;
    return;
  }
  const denom = Math.max(q.total_at_start, q.processed + q.total);
  el.hidden = false;
  el.textContent = `${fmtNum(q.processed)} / ${fmtNum(denom)} processed`;
  el.className = q.running ? "progress on" : "progress";
}
function paintMasterSwitch(state) {
  const on = state.settings.enabled !== false;
  masterSwitch.checked = on;
  masterLabel.textContent = on ? "ON" : "PAUSED";
  document.body.classList.toggle("paused", !on);
}
function paintAutoScroll(state) {
  const secs = state.settings.autoScrollIntervalSec;
  autoScrollInterval.value = String(secs);
  autoScrollSecsEl.textContent = String(secs);
  const as = state.autoScroll;
  autoScrollStartBtn.hidden = as.active;
  autoScrollCancelBtn.hidden = !as.active;
  if (as.active) {
    const n = as.tabCount;
    autoScrollStatus.textContent = n === 0 ? `running \u2014 no X tabs open` : `running \u2014 ${n} ${n === 1 ? "tab" : "tabs"}`;
    autoScrollStatus.className = "muted on";
  } else {
    autoScrollStatus.textContent = "idle";
    autoScrollStatus.className = "muted";
  }
  if (as.active || as.scrollCount > 0 || as.ingestedCount > 0) {
    autoScrollProgress.hidden = false;
    const parts = [
      `${fmtNum(as.scrollCount)} scrolls`,
      `${fmtNum(as.ingestedNewCount)} new buffered`,
      `${fmtNum(as.ingestedExistingCount)} old buffered`
    ];
    if (as.skippedOldCount > 0) parts.push(`${fmtNum(as.skippedOldCount)} old skipped`);
    parts.push(`${fmtNum(as.expandedCount)} expanded`);
    autoScrollProgress.textContent = parts.join(" \xB7 ");
    autoScrollProgress.className = as.active ? "progress on" : "progress";
  } else {
    autoScrollProgress.hidden = true;
  }
}
function paintRefetch(state) {
  const q = state.refetchQueue;
  const total = q.total;
  const running = q.running;
  refetchSection.hidden = total === 0 && !running;
  refetchCount.textContent = total === 0 ? running ? "finishing\u2026" : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  refetchStartBtn.hidden = running;
  refetchStartBtn.disabled = total === 0;
  refetchCancelBtn.hidden = !running;
  paintQueueProgress(refetchProgress, q);
}
function paintThreadOpen(state) {
  const q = state.threadOpenQueue;
  const total = q.total;
  const running = q.running;
  threadOpenSection.hidden = total === 0 && !running;
  threadOpenCount.textContent = total === 0 ? running ? "finishing..." : "0 queued" : `${fmtNum(total)} queued${running ? " \xB7 running" : ""}`;
  threadOpenStartBtn.hidden = running;
  threadOpenStartBtn.disabled = total === 0;
  threadOpenCancelBtn.hidden = !running;
  paintQueueProgress(threadOpenProgress, q);
}
async function refreshActivity() {
  const stored = await browser.storage.local.get("activity");
  const events = stored.activity ?? [];
  renderActivity(events);
}
captureAllBtn.addEventListener("click", async () => {
  captureAllBtn.disabled = true;
  try {
    await send({ type: "capture-all" });
  } finally {
    captureAllBtn.disabled = false;
  }
});
captureThisBtn.addEventListener("click", async () => {
  captureThisBtn.disabled = true;
  try {
    await send({ type: "capture-this-page" });
  } finally {
    captureThisBtn.disabled = false;
  }
});
flushBtn.addEventListener("click", async () => {
  flushBtn.disabled = true;
  try {
    await send({ type: "flush-all" });
  } finally {
    flushBtn.disabled = false;
  }
});
autoToggle.addEventListener("change", () => {
  void send({ type: "toggle-auto-capture", on: autoToggle.checked });
});
updateExistingToggle.addEventListener("change", () => {
  void send({ type: "toggle-update-existing", on: updateExistingToggle.checked });
});
lowBandwidthToggle.addEventListener("change", () => {
  void send({ type: "toggle-low-bandwidth", on: lowBandwidthToggle.checked });
});
masterSwitch.addEventListener("change", () => {
  void send({ type: "toggle-enabled", on: masterSwitch.checked });
});
autoScrollStartBtn.addEventListener("click", () => {
  autoScrollStartBtn.disabled = true;
  void send({ type: "start-auto-scroll" }).finally(() => {
    autoScrollStartBtn.disabled = false;
  });
});
autoScrollCancelBtn.addEventListener("click", () => {
  autoScrollCancelBtn.disabled = true;
  void send({ type: "cancel-auto-scroll" }).finally(() => {
    autoScrollCancelBtn.disabled = false;
  });
});
autoScrollInterval.addEventListener("input", () => {
  autoScrollSecsEl.textContent = autoScrollInterval.value;
});
autoScrollInterval.addEventListener("change", () => {
  const seconds = Number(autoScrollInterval.value);
  if (Number.isFinite(seconds)) {
    void send({ type: "set-auto-scroll-interval", seconds });
  }
});
purgeLink.addEventListener("click", (e) => {
  e.preventDefault();
  const ok = window.confirm(
    "Drop every counter, run buffer, refetch / media-crawl / thread-opening queue entry for accounts not in your tracked list?\n\nThis only touches local extension state. Already-committed files in the GitHub repo are not affected \u2014 run scripts/purge_unrelated.py separately if you also want to scrub the repo."
  );
  if (!ok) return;
  void send({ type: "purge-unrelated" });
});
refetchStartBtn.addEventListener("click", () => {
  refetchStartBtn.disabled = true;
  void send({ type: "start-refetch" }).finally(() => {
    refetchStartBtn.disabled = false;
  });
});
refetchCancelBtn.addEventListener("click", () => {
  refetchCancelBtn.disabled = true;
  void send({ type: "cancel-refetch" }).finally(() => {
    refetchCancelBtn.disabled = false;
  });
});
mediaCrawlStartBtn.addEventListener("click", () => {
  mediaCrawlStartBtn.disabled = true;
  void send({ type: "start-media-crawl" }).finally(() => {
    mediaCrawlStartBtn.disabled = false;
  });
});
mediaCrawlCancelBtn.addEventListener("click", () => {
  mediaCrawlCancelBtn.disabled = true;
  void send({ type: "cancel-media-crawl" }).finally(() => {
    mediaCrawlCancelBtn.disabled = false;
  });
});
threadOpenStartBtn.addEventListener("click", () => {
  threadOpenStartBtn.disabled = true;
  void send({ type: "start-thread-open" }).finally(() => {
    threadOpenStartBtn.disabled = false;
  });
});
threadOpenCancelBtn.addEventListener("click", () => {
  threadOpenCancelBtn.disabled = true;
  void send({ type: "cancel-thread-open" }).finally(() => {
    threadOpenCancelBtn.disabled = false;
  });
});
optionsLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-options" });
});
viewerLink.addEventListener("click", (e) => {
  e.preventDefault();
  void send({ type: "open-viewer" });
});
clearActBtn.addEventListener("click", async () => {
  await send({ type: "clear-activity" });
  renderActivity([]);
});
browser.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  const m = msg;
  if (m.type === "state-changed" && m.state) {
    lastState = m.state;
    paint(m.state);
  } else if (m.type === "log-event" && m.event) {
    prependEvent(m.event);
  }
});
function prependEvent(ev) {
  if (activityList.firstElementChild?.classList.contains("empty")) {
    activityList.replaceChildren();
  }
  const li = document.createElement("li");
  li.className = `ev ${ev.level}`;
  const ts = document.createElement("span");
  ts.className = "ev-ts";
  ts.textContent = new Date(ev.ts).toLocaleTimeString("en-US", { hour12: false });
  const icon = document.createElement("span");
  icon.className = "ev-icon";
  icon.textContent = ev.level === "error" ? "\u2717" : ev.level === "warn" ? "!" : "\xB7";
  const body = document.createElement("span");
  const msg = document.createElement("div");
  msg.className = "ev-msg";
  msg.textContent = ev.msg;
  body.append(msg);
  const ctxKeys = Object.keys(ev.context);
  if (ctxKeys.length > 0) {
    const ctx = document.createElement("div");
    ctx.className = "ev-ctx";
    ctx.textContent = ctxKeys.map((k) => `${k}=${stringifyShort(ev.context[k])}`).join(" \xB7 ");
    body.append(ctx);
  }
  li.append(ts, icon, body);
  activityList.prepend(li);
  while (activityList.childElementCount > ACTIVITY_TAIL_MAX) {
    activityList.lastElementChild?.remove();
  }
}
void refreshState();
void refreshActivity();
setInterval(() => {
  void refreshState();
}, 15e3);
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL3NpZGViYXIudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgQWNjb3VudENvbmZpZywgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzLmpzJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBwYXQ6ICcnLFxuICBvd25lcjogJ3ZpZHByb2plY3QnLFxuICByZXBvOiAneCcsXG4gIC8vIFRoZSByZXBvJ3MgY3VycmVudCBkZWZhdWx0IGJyYW5jaCBpcyBcIm1hc3RlclwiLiBJZiB5b3UgZm9yayBvciByZW5hbWVcbiAgLy8gaXQgbGF0ZXIsIHVwZGF0ZSBTZXR0aW5ncyBiZWZvcmUgdGhlIG5leHQgY2FwdHVyZS5cbiAgYnJhbmNoOiAnbWFzdGVyJyxcbiAgZW5hYmxlZDogdHJ1ZSxcbiAgYXV0b0NhcHR1cmU6IHRydWUsXG4gIGNvbmZpZ3VyZWRBdDogbnVsbCxcbiAgYXV0b1Njcm9sbEludGVydmFsU2VjOiA2LFxuICB1cGRhdGVFeGlzdGluZzogdHJ1ZSxcbiAgbG93QmFuZHdpZHRoQnJvd3Npbmc6IGZhbHNlLFxufTtcblxuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01JTl9TRUMgPSAzO1xuZXhwb3J0IGNvbnN0IEFVVE9fU0NST0xMX01BWF9TRUMgPSA2MDtcblxuLy8gQnVpbHQtaW4gZmFsbGJhY2sgaWYgY29uZmlnL2FjY291bnRzLnlhbWwgY2Fubm90IGJlIGZldGNoZWQgKGUuZy4sIGJlZm9yZSB0aGVcbi8vIHJlcG8gaGFzIGJlZW4gaW5pdGlhbGl6ZWQgb3IgUEFUIG1pc2NvbmZpZ3VyZWQpLiBLZXB0IGluIHN5bmMgd2l0aCB0aGUgZmlsZS5cbmV4cG9ydCBjb25zdCBGQUxMQkFDS19BQ0NPVU5UUzogQWNjb3VudENvbmZpZ1tdID0gW1xuICB7IGhhbmRsZTogJ0RIU2dvdicsIGxhYmVsOiAnRGVwYXJ0bWVudCBvZiBIb21lbGFuZCBTZWN1cml0eScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdJQ0Vnb3YnLCBsYWJlbDogJ1UuUy4gSW1taWdyYXRpb24gYW5kIEN1c3RvbXMgRW5mb3JjZW1lbnQnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnQ0JQJywgbGFiZWw6ICdVLlMuIEN1c3RvbXMgYW5kIEJvcmRlciBQcm90ZWN0aW9uJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1VTQ0lTJywgbGFiZWw6ICdVLlMuIENpdGl6ZW5zaGlwIGFuZCBJbW1pZ3JhdGlvbiBTZXJ2aWNlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdXaGl0ZUhvdXNlJywgbGFiZWw6ICdUaGUgV2hpdGUgSG91c2UnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUHJlc3NTZWMnLCBsYWJlbDogJ1doaXRlIEhvdXNlIFByZXNzIFNlY3JldGFyeScsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdQT1RVUycsIGxhYmVsOiAnUHJlc2lkZW50IG9mIHRoZSBVbml0ZWQgU3RhdGVzJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1VTRE9MJywgbGFiZWw6ICdVLlMuIERlcGFydG1lbnQgb2YgTGFib3InLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUmFwaWRSZXNwb25zZTQ3JywgbGFiZWw6ICdSYXBpZCBSZXNwb25zZSA0NycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdTdGVwaGVuTScsIGxhYmVsOiAnU3RlcGhlbiBNaWxsZXInLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnR3JlZ29yeUtCb3Zpbm8nLCBsYWJlbDogJ0dyZWdvcnkgQm92aW5vJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1JlYWxUb21Ib21hbicsIGxhYmVsOiAnVGhvbWFzIEQuIEhvbWFuJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuXTtcblxuLy8gR3JhcGhRTCBlbmRwb2ludCBuYW1lcyB3ZSBjYXJlIGFib3V0IChtYXRjaGVkIGJ5IHN1YnN0cmluZyBhZ2FpbnN0IFVSTCBwYXRoKS5cbmV4cG9ydCBjb25zdCBUV0VFVF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ1VzZXJUd2VldHMnLFxuICAnVXNlclR3ZWV0c0FuZFJlcGxpZXMnLFxuICAnVXNlck1lZGlhJyxcbiAgJ1VzZXJIaWdobGlnaHRzVHdlZXRzJyxcbiAgJ1R3ZWV0RGV0YWlsJyxcbiAgJ1R3ZWV0UmVzdWx0QnlSZXN0SWQnLFxuICAnTGlrZXMnLFxuICAnQm9va21hcmtzJyxcbiAgJ0hvbWVUaW1lbGluZScsXG4gICdIb21lTGF0ZXN0VGltZWxpbmUnLFxuICAnU2VhcmNoVGltZWxpbmUnLFxuICAnTGlzdExhdGVzdFR3ZWV0c1RpbWVsaW5lJyxcbl0pO1xuXG4vLyBFbmRwb2ludHMgdGhhdCBjYXJyeSBDb21tdW5pdHkgTm90ZSBib2RpZXMgXHUyMDE0IGNhcHR1cmVkIGZvciBjb21wbGV0ZW5lc3MgYnV0XG4vLyB0aGV5IGRvbid0IGludHJvZHVjZSBuZXcgdHdlZXRzLCBzbyB0aGV5IGRvbid0IG5lZWQgdG8gYmUgaW4gVFdFRVRfRU5EUE9JTlRTLlxuZXhwb3J0IGNvbnN0IEJJUkRXQVRDSF9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFtcbiAgJ0JpcmR3YXRjaEZldGNoT25lTm90ZScsXG4gICdCaXJkd2F0Y2hGZXRjaE5vdGVzJyxcbl0pO1xuXG4vLyBBdXhpbGlhcnkgZW5kcG9pbnRzIHdlIGRvbid0IGV4dHJhY3QgdHdlZXRzIGZyb20gYnV0IHVzZSBmb3IgY29udGV4dCAoZS5nLixcbi8vIHRvIGxlYXJuIGFjY291bnRfaWQgPC0+IGhhbmRsZSBiaW5kaW5ncykuXG5leHBvcnQgY29uc3QgUFJPRklMRV9FTkRQT0lOVFM6IFJlYWRvbmx5U2V0PHN0cmluZz4gPSBuZXcgU2V0KFsnVXNlckJ5U2NyZWVuTmFtZScsICdVc2VyQnlSZXN0SWQnXSk7XG5cbi8vIEVuZHBvaW50cyB3aG9zZSByZXNwb25zZXMgYXJlIHNjb3BlZCB0byBhIHBhcnRpY3VsYXIgYWNjb3VudCBvclxuLy8gY29udmVyc2F0aW9uIFx1MjAxNCBpLmUuIHZpc2l0aW5nIGAvPGhhbmRsZT5gIC8gYC88aGFuZGxlPi93aXRoX3JlcGxpZXNgLFxuLy8gbG9va2luZyBhdCBvbmUgdHdlZXQsIGV0Yy4gRXZlcnkgdHdlZXQgcmV0dXJuZWQgYnkgdGhlc2UgZW5kcG9pbnRzIGlzXG4vLyBlaXRoZXIgYXV0aG9yZWQgYnkgdGhlIHRyYWNrZWQgYWNjb3VudCBvciBkaXJlY3RseSByZWZlcmVuY2VkIGJ5IHRoZW1cbi8vIChyZXR3ZWV0ZWQsIHF1b3RlZCwgcmVwbGllZCB0byksIHNvIHdlIGtlZXAgZXZlcnl0aGluZyB3ZSBzZWUgcmF0aGVyXG4vLyB0aGFuIGRyb3BwaW5nIG5vbi10cmFja2VkIGF1dGhvcnMuIFRoYXQgd2F5IGEgcmV0d2VldCBvZiBhIG5vbi10cmFja2VkXG4vLyBhY2NvdW50IHN0aWxsIGdldHMgaXRzIG9yaWdpbmFsLXR3ZWV0IGNvbnRlbnQgYXJjaGl2ZWQuXG4vL1xuLy8gRW5kcG9pbnRzIE5PVCBpbiB0aGlzIHNldCAoSG9tZVRpbWVsaW5lLCBTZWFyY2hUaW1lbGluZSwgTGlrZXMsIGV0Yy4pXG4vLyBzdGlsbCBnZXQgZmlsdGVyZWQgdG8gdHJhY2tlZC1oYW5kbGUgYXV0aG9ycyBcdTIwMTQgc2VlIHRoZSBzcGVjJ3Ncbi8vIFwiQnJvd3NpbmcgbXkgaG9tZSB0aW1lbGluZSBpcyBpZ25vcmVkXCIgcnVsZS5cbmV4cG9ydCBjb25zdCBVU0VSX1BBR0VfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbl0pO1xuXG4vLyBNYXhpbXVtIHR3ZWV0cyB0byBidWZmZXIgcGVyIGhhbmRsZSBiZWZvcmUgZm9yY2luZyBhIGNvbW1pdC5cbmV4cG9ydCBjb25zdCBGTFVTSF9UV0VFVF9USFJFU0hPTEQgPSAyMDA7XG5cbi8vIElkbGUgZGVsYXkgYWZ0ZXIgdGhlIGxhc3QgY2FwdHVyZSBiZWZvcmUgYXV0by1mbHVzaGluZyBhIGhhbmRsZSdzIGJ1ZmZlci5cbmV4cG9ydCBjb25zdCBGTFVTSF9JRExFX01TID0gNDVfMDAwO1xuXG4vLyBIb3cgbG9uZyBhbiBhbGFybS1iYXNlZCBmbHVzaCBzd2VlcCB3YWl0cyBiZXR3ZWVuIGNoZWNrcy5cbmV4cG9ydCBjb25zdCBGTFVTSF9BTEFSTV9NSU5VVEVTID0gMTtcblxuLy8gQWN0aXZpdHkgdGFpbCBzaXplLlxuZXhwb3J0IGNvbnN0IEFDVElWSVRZX1RBSUxfTUFYID0gMjUwO1xuXG4vLyBQZXJpb2RpYyByZS12ZXJpZmljYXRpb24gb2YgdGhlIEdpdEh1YiBjb25uZWN0aW9uIChtcykuXG5leHBvcnQgY29uc3QgVkVSSUZZX0NPTk5FQ1RJT05fSU5URVJWQUxfTVMgPSAxMCAqIDYwICogMTAwMDtcblxuZXhwb3J0IGNvbnN0IFRXRUVUX1VSTF9QUkVGSVggPSAnaHR0cHM6Ly94LmNvbSc7XG4iLCAiLyoqXG4gKiBzaWRlYmFyLnRzIFx1MjAxNCBVSSBmb3IgdGhlIHBlcnNpc3RlbnQgc2lkZWJhci5cbiAqXG4gKiBTaWRlYmFycyBpbiBGaXJlZm94IHN0YXkgb3BlbiBhY3Jvc3MgdGFiL3dpbmRvdyBzd2l0Y2hlcywgd2hpY2ggaXMgdGhlXG4gKiBpbnRlbmRlZCBwZXJzaXN0ZW5jZSBtb2RlbC4gVGhpcyBtb2R1bGUgcmVuZGVycyBzdGF0ZSBwdXNoZWQgZnJvbSB0aGVcbiAqIGJhY2tncm91bmQgc2VydmljZSB3b3JrZXIgYW5kIGZvcndhcmRzIHVzZXIgY29tbWFuZHMgYmFjay5cbiAqL1xuXG5pbXBvcnQgeyBBQ1RJVklUWV9UQUlMX01BWCB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XG5pbXBvcnQgdHlwZSB7IEV4dGVuc2lvblN0YXRlLCBMb2dFdmVudCwgUnVudGltZU1lc3NhZ2UsIFR3ZWV0U2lnaHRpbmcgfSBmcm9tICcuL2xpYi90eXBlcy5qcyc7XG5cbmNvbnN0ICQgPSA8VCBleHRlbmRzIEhUTUxFbGVtZW50ID0gSFRNTEVsZW1lbnQ+KGlkOiBzdHJpbmcpOiBUID0+IHtcbiAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCk7XG4gIGlmICghZWwpIHRocm93IG5ldyBFcnJvcihgbWlzc2luZyBlbGVtZW50ICMke2lkfWApO1xuICByZXR1cm4gZWwgYXMgVDtcbn07XG5cbmNvbnN0IGNvbm5Eb3QgPSAkKCdjb25uLWRvdCcpO1xuY29uc3QgY29ublRleHQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ2Nvbm4tdGV4dCcpO1xuY29uc3QgYWNjb3VudExpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdhY2NvdW50LWxpc3QnKTtcbmNvbnN0IHJlY2VudFR3ZWV0TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ3JlY2VudC10d2VldC1saXN0Jyk7XG5jb25zdCBhY3Rpdml0eUxpc3QgPSAkPEhUTUxVTGlzdEVsZW1lbnQ+KCdhY3Rpdml0eS1saXN0Jyk7XG5jb25zdCBhdXRvVG9nZ2xlID0gJDxIVE1MSW5wdXRFbGVtZW50PignYXV0by1jYXB0dXJlJyk7XG5jb25zdCB1cGRhdGVFeGlzdGluZ1RvZ2dsZSA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ3VwZGF0ZS1leGlzdGluZycpO1xuY29uc3QgbG93QmFuZHdpZHRoVG9nZ2xlID0gJDxIVE1MSW5wdXRFbGVtZW50PignbG93LWJhbmR3aWR0aCcpO1xuY29uc3QgY2FwdHVyZUFsbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjYXB0dXJlLWFsbCcpO1xuY29uc3QgY2FwdHVyZVRoaXNCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2FwdHVyZS10aGlzJyk7XG5jb25zdCBmbHVzaEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdmbHVzaC1hbGwnKTtcbmNvbnN0IG9wdGlvbnNMaW5rID0gJDxIVE1MQW5jaG9yRWxlbWVudD4oJ29wZW4tb3B0aW9ucycpO1xuY29uc3Qgdmlld2VyTGluayA9ICQ8SFRNTEFuY2hvckVsZW1lbnQ+KCdvcGVuLXZpZXdlcicpO1xuY29uc3QgY2xlYXJBY3RCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2xlYXItYWN0aXZpdHknKTtcbmNvbnN0IGV4dFZlcnNpb25FbCA9ICQ8SFRNTFNwYW5FbGVtZW50PignZXh0LXZlcnNpb24nKTtcbmNvbnN0IG1hc3RlclN3aXRjaCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ21hc3Rlci1zd2l0Y2gnKTtcbmNvbnN0IG1hc3RlckxhYmVsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdtYXN0ZXItbGFiZWwnKTtcbmNvbnN0IGF1dG9TY3JvbGxJbnRlcnZhbCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2F1dG8tc2Nyb2xsLWludGVydmFsJyk7XG5jb25zdCBhdXRvU2Nyb2xsU2Vjc0VsID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zZWNzJyk7XG5jb25zdCBhdXRvU2Nyb2xsU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zdGF0dXMnKTtcbmNvbnN0IGF1dG9TY3JvbGxTdGFydEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1zdGFydCcpO1xuY29uc3QgYXV0b1Njcm9sbENhbmNlbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdhdXRvLXNjcm9sbC1jYW5jZWwnKTtcbmNvbnN0IGF1dG9TY3JvbGxQcm9ncmVzcyA9ICQ8SFRNTFNwYW5FbGVtZW50PignYXV0by1zY3JvbGwtcHJvZ3Jlc3MnKTtcbmNvbnN0IHJlZmV0Y2hTZWN0aW9uID0gJDxIVE1MRWxlbWVudD4oJ3JlZmV0Y2gtc2VjdGlvbicpO1xuY29uc3QgcmVmZXRjaENvdW50ID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdyZWZldGNoLWNvdW50Jyk7XG5jb25zdCByZWZldGNoU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmZXRjaC1zdGFydCcpO1xuY29uc3QgcmVmZXRjaENhbmNlbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZWZldGNoLWNhbmNlbCcpO1xuY29uc3QgcmVmZXRjaFByb2dyZXNzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdyZWZldGNoLXByb2dyZXNzJyk7XG5jb25zdCBtZWRpYUNyYXdsU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCdtZWRpYS1jcmF3bC1zZWN0aW9uJyk7XG5jb25zdCBtZWRpYUNyYXdsQ291bnQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ21lZGlhLWNyYXdsLWNvdW50Jyk7XG5jb25zdCBtZWRpYUNyYXdsU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignbWVkaWEtY3Jhd2wtc3RhcnQnKTtcbmNvbnN0IG1lZGlhQ3Jhd2xDYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignbWVkaWEtY3Jhd2wtY2FuY2VsJyk7XG5jb25zdCBtZWRpYUNyYXdsUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ21lZGlhLWNyYXdsLXByb2dyZXNzJyk7XG5jb25zdCB0aHJlYWRPcGVuU2VjdGlvbiA9ICQ8SFRNTEVsZW1lbnQ+KCd0aHJlYWQtb3Blbi1zZWN0aW9uJyk7XG5jb25zdCB0aHJlYWRPcGVuQ291bnQgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3RocmVhZC1vcGVuLWNvdW50Jyk7XG5jb25zdCB0aHJlYWRPcGVuU3RhcnRCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigndGhyZWFkLW9wZW4tc3RhcnQnKTtcbmNvbnN0IHRocmVhZE9wZW5DYW5jZWxCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigndGhyZWFkLW9wZW4tY2FuY2VsJyk7XG5jb25zdCB0aHJlYWRPcGVuUHJvZ3Jlc3MgPSAkPEhUTUxTcGFuRWxlbWVudD4oJ3RocmVhZC1vcGVuLXByb2dyZXNzJyk7XG5jb25zdCBwdXJnZUxpbmsgPSAkPEhUTUxBbmNob3JFbGVtZW50PigncHVyZ2UtdW5yZWxhdGVkJyk7XG5cbmxldCBsYXN0U3RhdGU6IEV4dGVuc2lvblN0YXRlIHwgbnVsbCA9IG51bGw7XG5cbmFzeW5jIGZ1bmN0aW9uIHNlbmQ8VD4obXNnOiBSdW50aW1lTWVzc2FnZSk6IFByb21pc2U8VD4ge1xuICByZXR1cm4gYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKG1zZykgYXMgUHJvbWlzZTxUPjtcbn1cblxuZnVuY3Rpb24gc2V0Q29ublN0YXR1cyhzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3QgeyBjb25uZWN0aW9uLCBzZXR0aW5ncyB9ID0gc3RhdGU7XG4gIGxldCBjbHMgPSAnJztcbiAgbGV0IHRleHQgPSAnJztcbiAgLy8gT25seSB3YXJuIHdoZW4gdGhlIGNvbmZpZ3VyZWQgYnJhbmNoIGdlbnVpbmVseSBkb2Vzbid0IGV4aXN0IG9uIHRoZVxuICAvLyByZW1vdGUuIEEgbm9uLWRlZmF1bHQgYnJhbmNoIHRoYXQgZXhpc3RzIGlzIGZpbmUgXHUyMDE0IGNhcHR1cmluZyBpbnRvIGFcbiAgLy8gd29ya2luZyBicmFuY2ggaXMgcm91dGluZSBcdTIwMTQgc28gdGhlIG1lcmUgYCE9PWAgdG8gZGVmYXVsdF9icmFuY2ggaXMgbm90XG4gIC8vIGEgcHJvYmxlbSBhbmQgc2hvdWxkbid0IHNob3V0IGluIHRoZSBoZWFkZXIuXG4gIGNvbnN0IGJyYW5jaE1pc3NpbmcgPVxuICAgIGNvbm5lY3Rpb24uc3RhdHVzID09PSAnb2snICYmIHNldHRpbmdzLmJyYW5jaCAmJiBjb25uZWN0aW9uLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IGZhbHNlO1xuICBpZiAoIXNldHRpbmdzLnBhdFNldCkge1xuICAgIGNscyA9ICd3YXJuJztcbiAgICB0ZXh0ID0gJ05vdCBjb25maWd1cmVkIFx1MjAxNCBvcGVuIFNldHRpbmdzJztcbiAgfSBlbHNlIGlmIChicmFuY2hNaXNzaW5nKSB7XG4gICAgY2xzID0gJ2Vycic7XG4gICAgdGV4dCA9IGBCcmFuY2ggXCIke3NldHRpbmdzLmJyYW5jaH1cIiBkb2VzIG5vdCBleGlzdCBvbiAke3NldHRpbmdzLm93bmVyfS8ke3NldHRpbmdzLnJlcG99IFx1MjAxNCBjb21taXRzIHdpbGwgNDIyLiBTZXQgYnJhbmNoIHRvIFwiJHtjb25uZWN0aW9uLmRlZmF1bHRCcmFuY2ggPz8gJ21hc3Rlcid9XCIgaW4gU2V0dGluZ3MuYDtcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ29rJykge1xuICAgIGNscyA9ICdvayc7XG4gICAgdGV4dCA9IGBDb25uZWN0ZWQgYXMgQCR7Y29ubmVjdGlvbi5sb2dpbiA/PyAnPyd9IHRvICR7c2V0dGluZ3Mub3duZXJ9LyR7c2V0dGluZ3MucmVwb30gXHUwMEI3IFx1MjAyNiR7c2V0dGluZ3MucGF0U3VmZml4fWA7XG4gIH0gZWxzZSBpZiAoY29ubmVjdGlvbi5zdGF0dXMgPT09ICdhdXRoLWVycm9yJykge1xuICAgIGNscyA9ICdlcnInO1xuICAgIHRleHQgPSBpc1dyaXRlQXV0aEVycm9yKGNvbm5lY3Rpb24uZXJyb3IpXG4gICAgICA/ICdQQVQgY2FuIHJlYWQgcmVwbyBidXQgY2Fubm90IHdyaXRlIC0gc2V0IENvbnRlbnRzOiBSZWFkICYgV3JpdGUnXG4gICAgICA6ICdBdXRoIGVycm9yIC0gY2hlY2sgeW91ciBQQVQnO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJykge1xuICAgIGNscyA9ICd3YXJuJztcbiAgICBjb25zdCByZXNldHMgPSBmbXRSYXRlTGltaXRSZXNldChjb25uZWN0aW9uLnJhdGVMaW1pdFJlc2V0QXQpO1xuICAgIHRleHQgPSByZXNldHNcbiAgICAgID8gYEdpdEh1YiByYXRlLWxpbWl0ZWQgXHUyMDE0IHJlc2V0cyAke3Jlc2V0c31gXG4gICAgICA6ICdHaXRIdWIgcmF0ZS1saW1pdGVkIFx1MjAxNCBjYXB0dXJlcyB3aWxsIHJldHJ5JztcbiAgfSBlbHNlIGlmIChjb25uZWN0aW9uLnN0YXR1cyA9PT0gJ25ldHdvcmstZXJyb3InKSB7XG4gICAgY2xzID0gJ2Vycic7XG4gICAgdGV4dCA9ICdOZXR3b3JrIGVycm9yIFx1MjAxNCBjaGVjayBjb25uZWN0aXZpdHknO1xuICB9IGVsc2UgaWYgKGNvbm5lY3Rpb24uc3RhdHVzID09PSAnbm90LWNvbmZpZ3VyZWQnKSB7XG4gICAgY2xzID0gJ3dhcm4nO1xuICAgIHRleHQgPSAnTm90IGNvbmZpZ3VyZWQgXHUyMDE0IG9wZW4gU2V0dGluZ3MnO1xuICB9IGVsc2Uge1xuICAgIGNscyA9ICcnO1xuICAgIHRleHQgPSAnQ2hlY2tpbmdcdTIwMjYnO1xuICB9XG4gIGNvbm5Eb3QuY2xhc3NOYW1lID0gYGRvdCAke2Nsc31gO1xuICBjb25uVGV4dC50ZXh0Q29udGVudCA9IHRleHQ7XG4gIGNvbm5UZXh0LnRpdGxlID0gY29ubmVjdGlvbi5lcnJvciA/PyAnJztcbn1cblxuZnVuY3Rpb24gZm10UmVsKGlzbzogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB7XG4gIGlmICghaXNvKSByZXR1cm4gJ1x1MjAxNCc7XG4gIGNvbnN0IGQgPSBEYXRlLnBhcnNlKGlzbyk7XG4gIGlmICghTnVtYmVyLmlzRmluaXRlKGQpKSByZXR1cm4gJ1x1MjAxNCc7XG4gIGNvbnN0IHNlY3MgPSBNYXRoLm1heCgwLCBNYXRoLnJvdW5kKChEYXRlLm5vdygpIC0gZCkgLyAxMDAwKSk7XG4gIGlmIChzZWNzIDwgNSkgcmV0dXJuICdqdXN0IG5vdyc7XG4gIGlmIChzZWNzIDwgNjApIHJldHVybiBgJHtzZWNzfXMgYWdvYDtcbiAgY29uc3QgbWlucyA9IE1hdGgucm91bmQoc2VjcyAvIDYwKTtcbiAgaWYgKG1pbnMgPCA2MCkgcmV0dXJuIGAke21pbnN9bSBhZ29gO1xuICBjb25zdCBob3VycyA9IE1hdGgucm91bmQobWlucyAvIDYwKTtcbiAgaWYgKGhvdXJzIDwgMjQpIHJldHVybiBgJHtob3Vyc31oIGFnb2A7XG4gIGNvbnN0IGRheXMgPSBNYXRoLnJvdW5kKGhvdXJzIC8gMjQpO1xuICByZXR1cm4gYCR7ZGF5c31kIGFnb2A7XG59XG5cbmZ1bmN0aW9uIGZtdFJhdGVMaW1pdFJlc2V0KGVwb2NoU2VjOiBudW1iZXIgfCBudWxsKTogc3RyaW5nIHtcbiAgaWYgKGVwb2NoU2VjID09PSBudWxsKSByZXR1cm4gJyc7XG4gIGNvbnN0IGRlbHRhU2VjID0gZXBvY2hTZWMgLSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcbiAgaWYgKGRlbHRhU2VjIDw9IDApIHJldHVybiAnbW9tZW50YXJpbHknO1xuICBjb25zdCB3YWxsQ2xvY2sgPSBuZXcgRGF0ZShlcG9jaFNlYyAqIDEwMDApLnRvTG9jYWxlVGltZVN0cmluZyhbXSwge1xuICAgIGhvdXI6ICcyLWRpZ2l0JyxcbiAgICBtaW51dGU6ICcyLWRpZ2l0JyxcbiAgfSk7XG4gIGlmIChkZWx0YVNlYyA8IDYwKSByZXR1cm4gYGluICR7ZGVsdGFTZWN9cyAoJHt3YWxsQ2xvY2t9KWA7XG4gIGNvbnN0IG1pbnMgPSBNYXRoLnJvdW5kKGRlbHRhU2VjIC8gNjApO1xuICBpZiAobWlucyA8IDYwKSByZXR1cm4gYGluICR7bWluc31tICgke3dhbGxDbG9ja30pYDtcbiAgY29uc3QgaG91cnMgPSBNYXRoLnJvdW5kKG1pbnMgLyA2MCk7XG4gIHJldHVybiBgaW4gJHtob3Vyc31oICgke3dhbGxDbG9ja30pYDtcbn1cblxuZnVuY3Rpb24gZm10TnVtKG46IG51bWJlcik6IHN0cmluZyB7XG4gIHJldHVybiBuLnRvTG9jYWxlU3RyaW5nKCdlbi1VUycpO1xufVxuXG5mdW5jdGlvbiBpc1dyaXRlQXV0aEVycm9yKG1lc3NhZ2U6IHN0cmluZyB8IG51bGwpOiBib29sZWFuIHtcbiAgcmV0dXJuIChcbiAgICB0eXBlb2YgbWVzc2FnZSA9PT0gJ3N0cmluZycgJiZcbiAgICAvUmVzb3VyY2Ugbm90IGFjY2Vzc2libGUgYnkgcGVyc29uYWwgYWNjZXNzIHRva2VufFxcL2dpdFxcL2Jsb2JzfFxcL2dpdFxcL3JlZnMvaS50ZXN0KG1lc3NhZ2UpXG4gICk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFjY291bnRzKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBhY2NvdW50TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgaWYgKHN0YXRlLmFjY291bnRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xuICAgIGxpLnRleHRDb250ZW50ID0gJ05vIGFjY291bnRzIGNvbmZpZ3VyZWQuJztcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xuICAgIHJldHVybjtcbiAgfVxuICBmb3IgKGNvbnN0IGEgb2Ygc3RhdGUuYWNjb3VudHMpIHtcbiAgICBjb25zdCBjID0gc3RhdGUuY291bnRlcnNbYS5oYW5kbGVdO1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSBjICYmIGMuYnVmZmVyZWRDb3VudCA+IDAgPyAnYWNjIHBlbmRpbmcnIDogJ2FjYyc7XG5cbiAgICBjb25zdCBoZWFkID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgaGVhZC5jbGFzc05hbWUgPSAnYWNjLWhlYWQnO1xuICAgIGNvbnN0IGhhbmRsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBoYW5kbGUuY2xhc3NOYW1lID0gJ2FjYy1oYW5kbGUnO1xuICAgIGhhbmRsZS5pbm5lckhUTUwgPSBgPHNwYW4gY2xhc3M9XCJhdFwiPkA8L3NwYW4+JHtlc2NhcGVIdG1sKGEuaGFuZGxlKX1gO1xuICAgIGNvbnN0IG1ldGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgbWV0YS5jbGFzc05hbWUgPSAnYWNjLW1ldGEnO1xuICAgIG1ldGEudGV4dENvbnRlbnQgPSBhLmxhYmVsO1xuICAgIGhlYWQuYXBwZW5kKGhhbmRsZSwgbWV0YSk7XG5cbiAgICBjb25zdCByb3cgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICByb3cuY2xhc3NOYW1lID0gJ2FjYy1yb3cnO1xuICAgIGNvbnN0IHN0YXRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIHN0YXRzLmNsYXNzTmFtZSA9ICdhY2Mtc3RhdHMnO1xuICAgIGNvbnN0IHRvZGF5ID0gYz8udG9kYXlDb3VudCA/PyAwO1xuICAgIGNvbnN0IGJ1ZmZlcmVkID0gYz8uYnVmZmVyZWRDb3VudCA/PyAwO1xuICAgIGNvbnN0IGxhc3QgPSBjPy5sYXN0Q2FwdHVyZUF0ID8/IG51bGw7XG4gICAgc3RhdHMuaW5uZXJIVE1MID1cbiAgICAgIGA8c3BhbiBjbGFzcz1cIm51bVwiPiR7Zm10TnVtKHRvZGF5KX08L3NwYW4+IHRvZGF5YCArXG4gICAgICAoYnVmZmVyZWQgPiAwID8gYCBcdTAwQjcgPHNwYW4gY2xhc3M9XCJudW1cIj4ke2ZtdE51bShidWZmZXJlZCl9PC9zcGFuPiBidWZmZXJlZGAgOiAnJykgK1xuICAgICAgYCBcdTAwQjcgbGFzdCAke2VzY2FwZUh0bWwoZm10UmVsKGxhc3QpKX1gO1xuXG4gICAgY29uc3QgYWN0aW9ucyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBhY3Rpb25zLmNsYXNzTmFtZSA9ICdhY2MtYWN0aW9uJztcbiAgICBjb25zdCBidG4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdidXR0b24nKTtcbiAgICBidG4uY2xhc3NOYW1lID0gJ2J0bic7XG4gICAgYnRuLnRleHRDb250ZW50ID0gJ0NhcHR1cmUgbm93JztcbiAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gICAgICBidG4uZGlzYWJsZWQgPSB0cnVlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjYXB0dXJlLW5vdycsIGhhbmRsZTogYS5oYW5kbGUgfSk7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBidG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBhY3Rpb25zLmFwcGVuZChidG4pO1xuXG4gICAgcm93LmFwcGVuZChzdGF0cywgYWN0aW9ucyk7XG4gICAgbGkuYXBwZW5kKGhlYWQsIHJvdyk7XG4gICAgYWNjb3VudExpc3QuYXBwZW5kKGxpKTtcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJBY3Rpdml0eShldmVudHM6IExvZ0V2ZW50W10pOiB2b2lkIHtcbiAgYWN0aXZpdHlMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBpZiAoZXZlbnRzLmxlbmd0aCA9PT0gMCkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBsaS5jbGFzc05hbWUgPSAnZW1wdHknO1xuICAgIGxpLnRleHRDb250ZW50ID0gJ05vIGFjdGl2aXR5IHlldC4nO1xuICAgIGFjdGl2aXR5TGlzdC5hcHBlbmQobGkpO1xuICAgIHJldHVybjtcbiAgfVxuICBmb3IgKGNvbnN0IGV2IG9mIGV2ZW50cy5zbGljZSgwLCBBQ1RJVklUWV9UQUlMX01BWCkpIHtcbiAgICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGkuY2xhc3NOYW1lID0gYGV2ICR7ZXYubGV2ZWx9YDtcbiAgICBjb25zdCB0cyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICB0cy5jbGFzc05hbWUgPSAnZXYtdHMnO1xuICAgIHRzLnRleHRDb250ZW50ID0gbmV3IERhdGUoZXYudHMpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tVVMnLCB7IGhvdXIxMjogZmFsc2UgfSk7XG4gICAgY29uc3QgaWNvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgICBpY29uLmNsYXNzTmFtZSA9ICdldi1pY29uJztcbiAgICBpY29uLnRleHRDb250ZW50ID0gZXYubGV2ZWwgPT09ICdlcnJvcicgPyAnXHUyNzE3JyA6IGV2LmxldmVsID09PSAnd2FybicgPyAnIScgOiAnXHUwMEI3JztcbiAgICBjb25zdCBib2R5ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGNvbnN0IG1zZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIG1zZy5jbGFzc05hbWUgPSAnZXYtbXNnJztcbiAgICBtc2cudGV4dENvbnRlbnQgPSBldi5tc2c7XG4gICAgYm9keS5hcHBlbmQobXNnKTtcbiAgICBjb25zdCBjdHhLZXlzID0gT2JqZWN0LmtleXMoZXYuY29udGV4dCk7XG4gICAgaWYgKGN0eEtleXMubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgY3R4ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICBjdHguY2xhc3NOYW1lID0gJ2V2LWN0eCc7XG4gICAgICBjdHgudGV4dENvbnRlbnQgPSBjdHhLZXlzLm1hcCgoaykgPT4gYCR7a309JHtzdHJpbmdpZnlTaG9ydChldi5jb250ZXh0W2tdKX1gKS5qb2luKCcgXHUwMEI3ICcpO1xuICAgICAgYm9keS5hcHBlbmQoY3R4KTtcbiAgICB9XG4gICAgbGkuYXBwZW5kKHRzLCBpY29uLCBib2R5KTtcbiAgICBhY3Rpdml0eUxpc3QuYXBwZW5kKGxpKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzdHJpbmdpZnlTaG9ydCh2OiB1bmtub3duKTogc3RyaW5nIHtcbiAgaWYgKHYgPT09IG51bGwpIHJldHVybiAnbnVsbCc7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycpIHJldHVybiB2Lmxlbmd0aCA+IDgwID8gYCR7di5zbGljZSgwLCA4MCl9XHUyMDI2YCA6IHY7XG4gIGlmICh0eXBlb2YgdiA9PT0gJ251bWJlcicgfHwgdHlwZW9mIHYgPT09ICdib29sZWFuJykgcmV0dXJuIFN0cmluZyh2KTtcbiAgdHJ5IHtcbiAgICBjb25zdCBzID0gSlNPTi5zdHJpbmdpZnkodik7XG4gICAgcmV0dXJuIHMubGVuZ3RoID4gODAgPyBgJHtzLnNsaWNlKDAsIDgwKX1cdTIwMjZgIDogcztcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuICc/JztcbiAgfVxufVxuXG5mdW5jdGlvbiBlc2NhcGVIdG1sKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBzLnJlcGxhY2UoL1smPD5cIiddL2csIChjKSA9PlxuICAgIGMgPT09ICcmJyA/ICcmYW1wOycgOiBjID09PSAnPCcgPyAnJmx0OycgOiBjID09PSAnPicgPyAnJmd0OycgOiBjID09PSAnXCInID8gJyZxdW90OycgOiAnJiMzOTsnXG4gICk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hTdGF0ZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBsYXN0U3RhdGUgPSBhd2FpdCBzZW5kPEV4dGVuc2lvblN0YXRlPih7IHR5cGU6ICdnZXQtc3RhdGUnIH0pO1xuICAgIHBhaW50KGxhc3RTdGF0ZSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBzaWRlYmFyIHJlZnJlc2hTdGF0ZSBmYWlsZWQnLCBlcnIpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBhaW50KHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBleHRWZXJzaW9uRWwudGV4dENvbnRlbnQgPSBzdGF0ZS52ZXJzaW9uO1xuICBzZXRDb25uU3RhdHVzKHN0YXRlKTtcbiAgYXV0b1RvZ2dsZS5jaGVja2VkID0gc3RhdGUuc2V0dGluZ3MuYXV0b0NhcHR1cmU7XG4gIHVwZGF0ZUV4aXN0aW5nVG9nZ2xlLmNoZWNrZWQgPSBzdGF0ZS5zZXR0aW5ncy51cGRhdGVFeGlzdGluZyAhPT0gZmFsc2U7XG4gIGxvd0JhbmR3aWR0aFRvZ2dsZS5jaGVja2VkID0gc3RhdGUuc2V0dGluZ3MubG93QmFuZHdpZHRoQnJvd3NpbmcgPT09IHRydWU7XG4gIHZpZXdlckxpbmsuaHJlZiA9IGBodHRwczovLyR7c3RhdGUuc2V0dGluZ3Mub3duZXJ9LmdpdGh1Yi5pby8ke3N0YXRlLnNldHRpbmdzLnJlcG99L2A7XG4gIHBhaW50TWFzdGVyU3dpdGNoKHN0YXRlKTtcbiAgcmVuZGVyQWNjb3VudHMoc3RhdGUpO1xuICByZW5kZXJSZWNlbnRUd2VldHMoc3RhdGUucmVjZW50VHdlZXRTaWdodGluZ3MpO1xuICBwYWludEF1dG9TY3JvbGwoc3RhdGUpO1xuICBwYWludE1lZGlhQ3Jhd2woc3RhdGUpO1xuICBwYWludFJlZmV0Y2goc3RhdGUpO1xuICBwYWludFRocmVhZE9wZW4oc3RhdGUpO1xufVxuXG5mdW5jdGlvbiByZW5kZXJSZWNlbnRUd2VldHMocm93czogVHdlZXRTaWdodGluZ1tdKTogdm9pZCB7XG4gIHJlY2VudFR3ZWV0TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgaWYgKHJvd3MubGVuZ3RoID09PSAwKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9ICdlbXB0eSc7XG4gICAgbGkudGV4dENvbnRlbnQgPSAnTm8gdHdlZXRzIHNlZW4geWV0Lic7XG4gICAgcmVjZW50VHdlZXRMaXN0LmFwcGVuZChsaSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAoY29uc3Qgcm93IG9mIHJvd3Muc2xpY2UoMCwgNDApKSB7XG4gICAgY29uc3QgbGkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdsaScpO1xuICAgIGxpLmNsYXNzTmFtZSA9IGByZWNlbnQtdHdlZXQgJHtyb3cuYXJjaGl2ZV9zdGF0dXN9YDtcblxuICAgIGNvbnN0IHRvcCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHRvcC5jbGFzc05hbWUgPSAndHdlZXQtaGVhZCc7XG4gICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICBsaW5rLmNsYXNzTmFtZSA9ICd0d2VldC1oYW5kbGUnO1xuICAgIGxpbmsuaHJlZiA9IHJvdy50d2VldF91cmw7XG4gICAgbGluay50YXJnZXQgPSAnX2JsYW5rJztcbiAgICBsaW5rLnJlbCA9ICdub29wZW5lcic7XG4gICAgbGluay50ZXh0Q29udGVudCA9IGBAJHtyb3cuYWNjb3VudF9oYW5kbGV9YDtcbiAgICBjb25zdCBzdGF0dXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgc3RhdHVzLmNsYXNzTmFtZSA9IGB0d2VldC1waWxsICR7cm93LmFyY2hpdmVfc3RhdHVzfWA7XG4gICAgc3RhdHVzLnRleHRDb250ZW50ID0gcm93LmFyY2hpdmVfc3RhdHVzID09PSAnc2F2ZWQnID8gJ3NhdmVkJyA6ICduZXcnO1xuICAgIHRvcC5hcHBlbmQobGluaywgc3RhdHVzKTtcblxuICAgIGNvbnN0IHRleHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICB0ZXh0LmNsYXNzTmFtZSA9ICd0d2VldC10ZXh0JztcbiAgICB0ZXh0LnRleHRDb250ZW50ID0gdHJ1bmNhdGVUZXh0KHJvdy50ZXh0LCAxNDApO1xuXG4gICAgY29uc3QgbWV0YSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIG1ldGEuY2xhc3NOYW1lID0gJ3R3ZWV0LW1ldGEnO1xuICAgIG1ldGEudGV4dENvbnRlbnQgPSBgJHtmb3JtYXRUd2VldEFjdGlvbihyb3cuYWN0aW9uKX0gXHUwMEI3ICR7cm93LnR3ZWV0X3R5cGV9IFx1MDBCNyBwb3N0ZWQgJHtmbXRSZWwocm93LnBvc3RlZF9hdCl9YDtcblxuICAgIGxpLmFwcGVuZCh0b3AsIHRleHQsIG1ldGEpO1xuICAgIHJlY2VudFR3ZWV0TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGZvcm1hdFR3ZWV0QWN0aW9uKGFjdGlvbjogVHdlZXRTaWdodGluZ1snYWN0aW9uJ10pOiBzdHJpbmcge1xuICBpZiAoYWN0aW9uID09PSAnYnVmZmVyZWQnKSByZXR1cm4gJ2J1ZmZlcmVkJztcbiAgaWYgKGFjdGlvbiA9PT0gJ3VuY2hhbmdlZCcpIHJldHVybiAndW5jaGFuZ2VkJztcbiAgcmV0dXJuICdza2lwcGVkJztcbn1cblxuZnVuY3Rpb24gdHJ1bmNhdGVUZXh0KHRleHQ6IHN0cmluZywgbWF4OiBudW1iZXIpOiBzdHJpbmcge1xuICBjb25zdCBjb21wYWN0ID0gdGV4dC5yZXBsYWNlKC9cXHMrL2csICcgJykudHJpbSgpO1xuICByZXR1cm4gY29tcGFjdC5sZW5ndGggPD0gbWF4ID8gY29tcGFjdCA6IGAke2NvbXBhY3Quc2xpY2UoMCwgbWF4IC0gMSl9XHUyMDI2YDtcbn1cblxuZnVuY3Rpb24gcGFpbnRNZWRpYUNyYXdsKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBxID0gc3RhdGUubWVkaWFDcmF3bFF1ZXVlO1xuICBjb25zdCB0b3RhbCA9IHEudG90YWw7XG4gIGNvbnN0IHJ1bm5pbmcgPSBxLnJ1bm5pbmc7XG4gIG1lZGlhQ3Jhd2xTZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xuICBtZWRpYUNyYXdsQ291bnQudGV4dENvbnRlbnQgPVxuICAgIHRvdGFsID09PSAwXG4gICAgICA/IHJ1bm5pbmdcbiAgICAgICAgPyAnZmluaXNoaW5nXHUyMDI2J1xuICAgICAgICA6ICcwIHF1ZXVlZCdcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcbiAgbWVkaWFDcmF3bFN0YXJ0QnRuLmRpc2FibGVkID0gdG90YWwgPT09IDA7XG4gIG1lZGlhQ3Jhd2xDYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XG4gIHBhaW50UXVldWVQcm9ncmVzcyhtZWRpYUNyYXdsUHJvZ3Jlc3MsIHEpO1xufVxuXG5mdW5jdGlvbiBwYWludFF1ZXVlUHJvZ3Jlc3MoXG4gIGVsOiBIVE1MU3BhbkVsZW1lbnQsXG4gIHE6IHsgcHJvY2Vzc2VkOiBudW1iZXI7IHRvdGFsX2F0X3N0YXJ0OiBudW1iZXI7IHJ1bm5pbmc6IGJvb2xlYW47IHRvdGFsOiBudW1iZXIgfVxuKTogdm9pZCB7XG4gIGlmICghcS5ydW5uaW5nICYmIHEucHJvY2Vzc2VkID09PSAwKSB7XG4gICAgZWwuaGlkZGVuID0gdHJ1ZTtcbiAgICByZXR1cm47XG4gIH1cbiAgLy8gRGVub21pbmF0b3I6IG1heCBvZiBpbml0aWFsIHRvdGFsIGFuZCBjdXJyZW50IHByb2Nlc3NlZCtyZW1haW5pbmcgc28gdGhlXG4gIC8vIGJhciBzdGlsbCBtYWtlcyBzZW5zZSBpZiBuZXcgZW50cmllcyB3ZXJlIGVucXVldWVkIG1pZC1ydW4uXG4gIGNvbnN0IGRlbm9tID0gTWF0aC5tYXgocS50b3RhbF9hdF9zdGFydCwgcS5wcm9jZXNzZWQgKyBxLnRvdGFsKTtcbiAgZWwuaGlkZGVuID0gZmFsc2U7XG4gIGVsLnRleHRDb250ZW50ID0gYCR7Zm10TnVtKHEucHJvY2Vzc2VkKX0gLyAke2ZtdE51bShkZW5vbSl9IHByb2Nlc3NlZGA7XG4gIGVsLmNsYXNzTmFtZSA9IHEucnVubmluZyA/ICdwcm9ncmVzcyBvbicgOiAncHJvZ3Jlc3MnO1xufVxuXG5mdW5jdGlvbiBwYWludE1hc3RlclN3aXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3Qgb24gPSBzdGF0ZS5zZXR0aW5ncy5lbmFibGVkICE9PSBmYWxzZTtcbiAgbWFzdGVyU3dpdGNoLmNoZWNrZWQgPSBvbjtcbiAgbWFzdGVyTGFiZWwudGV4dENvbnRlbnQgPSBvbiA/ICdPTicgOiAnUEFVU0VEJztcbiAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QudG9nZ2xlKCdwYXVzZWQnLCAhb24pO1xufVxuXG5mdW5jdGlvbiBwYWludEF1dG9TY3JvbGwoc3RhdGU6IEV4dGVuc2lvblN0YXRlKTogdm9pZCB7XG4gIGNvbnN0IHNlY3MgPSBzdGF0ZS5zZXR0aW5ncy5hdXRvU2Nyb2xsSW50ZXJ2YWxTZWM7XG4gIGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZSA9IFN0cmluZyhzZWNzKTtcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IFN0cmluZyhzZWNzKTtcbiAgY29uc3QgYXMgPSBzdGF0ZS5hdXRvU2Nyb2xsO1xuICBhdXRvU2Nyb2xsU3RhcnRCdG4uaGlkZGVuID0gYXMuYWN0aXZlO1xuICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmhpZGRlbiA9ICFhcy5hY3RpdmU7XG4gIGlmIChhcy5hY3RpdmUpIHtcbiAgICBjb25zdCBuID0gYXMudGFiQ291bnQ7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy50ZXh0Q29udGVudCA9XG4gICAgICBuID09PSAwID8gYHJ1bm5pbmcgXHUyMDE0IG5vIFggdGFicyBvcGVuYCA6IGBydW5uaW5nIFx1MjAxNCAke259ICR7biA9PT0gMSA/ICd0YWInIDogJ3RhYnMnfWA7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy5jbGFzc05hbWUgPSAnbXV0ZWQgb24nO1xuICB9IGVsc2Uge1xuICAgIGF1dG9TY3JvbGxTdGF0dXMudGV4dENvbnRlbnQgPSAnaWRsZSc7XG4gICAgYXV0b1Njcm9sbFN0YXR1cy5jbGFzc05hbWUgPSAnbXV0ZWQnO1xuICB9XG4gIGlmIChhcy5hY3RpdmUgfHwgYXMuc2Nyb2xsQ291bnQgPiAwIHx8IGFzLmluZ2VzdGVkQ291bnQgPiAwKSB7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmhpZGRlbiA9IGZhbHNlO1xuICAgIGNvbnN0IHBhcnRzID0gW1xuICAgICAgYCR7Zm10TnVtKGFzLnNjcm9sbENvdW50KX0gc2Nyb2xsc2AsXG4gICAgICBgJHtmbXROdW0oYXMuaW5nZXN0ZWROZXdDb3VudCl9IG5ldyBidWZmZXJlZGAsXG4gICAgICBgJHtmbXROdW0oYXMuaW5nZXN0ZWRFeGlzdGluZ0NvdW50KX0gb2xkIGJ1ZmZlcmVkYCxcbiAgICBdO1xuICAgIGlmIChhcy5za2lwcGVkT2xkQ291bnQgPiAwKSBwYXJ0cy5wdXNoKGAke2ZtdE51bShhcy5za2lwcGVkT2xkQ291bnQpfSBvbGQgc2tpcHBlZGApO1xuICAgIHBhcnRzLnB1c2goYCR7Zm10TnVtKGFzLmV4cGFuZGVkQ291bnQpfSBleHBhbmRlZGApO1xuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy50ZXh0Q29udGVudCA9IHBhcnRzLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgYXV0b1Njcm9sbFByb2dyZXNzLmNsYXNzTmFtZSA9IGFzLmFjdGl2ZSA/ICdwcm9ncmVzcyBvbicgOiAncHJvZ3Jlc3MnO1xuICB9IGVsc2Uge1xuICAgIGF1dG9TY3JvbGxQcm9ncmVzcy5oaWRkZW4gPSB0cnVlO1xuICB9XG59XG5cbmZ1bmN0aW9uIHBhaW50UmVmZXRjaChzdGF0ZTogRXh0ZW5zaW9uU3RhdGUpOiB2b2lkIHtcbiAgY29uc3QgcSA9IHN0YXRlLnJlZmV0Y2hRdWV1ZTtcbiAgY29uc3QgdG90YWwgPSBxLnRvdGFsO1xuICBjb25zdCBydW5uaW5nID0gcS5ydW5uaW5nO1xuICByZWZldGNoU2VjdGlvbi5oaWRkZW4gPSB0b3RhbCA9PT0gMCAmJiAhcnVubmluZztcbiAgcmVmZXRjaENvdW50LnRleHRDb250ZW50ID1cbiAgICB0b3RhbCA9PT0gMFxuICAgICAgPyBydW5uaW5nXG4gICAgICAgID8gJ2ZpbmlzaGluZ1x1MjAyNidcbiAgICAgICAgOiAnMCBxdWV1ZWQnXG4gICAgICA6IGAke2ZtdE51bSh0b3RhbCl9IHF1ZXVlZCR7cnVubmluZyA/ICcgXHUwMEI3IHJ1bm5pbmcnIDogJyd9YDtcbiAgcmVmZXRjaFN0YXJ0QnRuLmhpZGRlbiA9IHJ1bm5pbmc7XG4gIHJlZmV0Y2hTdGFydEJ0bi5kaXNhYmxlZCA9IHRvdGFsID09PSAwO1xuICByZWZldGNoQ2FuY2VsQnRuLmhpZGRlbiA9ICFydW5uaW5nO1xuICBwYWludFF1ZXVlUHJvZ3Jlc3MocmVmZXRjaFByb2dyZXNzLCBxKTtcbn1cblxuZnVuY3Rpb24gcGFpbnRUaHJlYWRPcGVuKHN0YXRlOiBFeHRlbnNpb25TdGF0ZSk6IHZvaWQge1xuICBjb25zdCBxID0gc3RhdGUudGhyZWFkT3BlblF1ZXVlO1xuICBjb25zdCB0b3RhbCA9IHEudG90YWw7XG4gIGNvbnN0IHJ1bm5pbmcgPSBxLnJ1bm5pbmc7XG4gIHRocmVhZE9wZW5TZWN0aW9uLmhpZGRlbiA9IHRvdGFsID09PSAwICYmICFydW5uaW5nO1xuICB0aHJlYWRPcGVuQ291bnQudGV4dENvbnRlbnQgPVxuICAgIHRvdGFsID09PSAwXG4gICAgICA/IHJ1bm5pbmdcbiAgICAgICAgPyAnZmluaXNoaW5nLi4uJ1xuICAgICAgICA6ICcwIHF1ZXVlZCdcbiAgICAgIDogYCR7Zm10TnVtKHRvdGFsKX0gcXVldWVkJHtydW5uaW5nID8gJyBcdTAwQjcgcnVubmluZycgOiAnJ31gO1xuICB0aHJlYWRPcGVuU3RhcnRCdG4uaGlkZGVuID0gcnVubmluZztcbiAgdGhyZWFkT3BlblN0YXJ0QnRuLmRpc2FibGVkID0gdG90YWwgPT09IDA7XG4gIHRocmVhZE9wZW5DYW5jZWxCdG4uaGlkZGVuID0gIXJ1bm5pbmc7XG4gIHBhaW50UXVldWVQcm9ncmVzcyh0aHJlYWRPcGVuUHJvZ3Jlc3MsIHEpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIFB1bGwgc3RyYWlnaHQgZnJvbSBzdG9yYWdlIG9uIGZpcnN0IHJlbmRlcjsgbGl2ZSB1cGRhdGVzIGNvbWUgdmlhXG4gIC8vIGBsb2ctZXZlbnRgIGJyb2FkY2FzdHMuXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoJ2FjdGl2aXR5Jyk7XG4gIGNvbnN0IGV2ZW50cyA9IChzdG9yZWQuYWN0aXZpdHkgYXMgTG9nRXZlbnRbXSB8IHVuZGVmaW5lZCkgPz8gW107XG4gIHJlbmRlckFjdGl2aXR5KGV2ZW50cyk7XG59XG5cbi8vIC0tLSBXaXJlIHVwIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmNhcHR1cmVBbGxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGNhcHR1cmVBbGxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB0cnkge1xuICAgIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2FwdHVyZS1hbGwnIH0pO1xuICB9IGZpbmFsbHkge1xuICAgIGNhcHR1cmVBbGxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfVxufSk7XG5cbmNhcHR1cmVUaGlzQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBjYXB0dXJlVGhpc0J0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdjYXB0dXJlLXRoaXMtcGFnZScgfSk7XG4gIH0gZmluYWxseSB7XG4gICAgY2FwdHVyZVRoaXNCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfVxufSk7XG5cbmZsdXNoQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBmbHVzaEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdmbHVzaC1hbGwnIH0pO1xuICB9IGZpbmFsbHkge1xuICAgIGZsdXNoQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH1cbn0pO1xuXG5hdXRvVG9nZ2xlLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1hdXRvLWNhcHR1cmUnLCBvbjogYXV0b1RvZ2dsZS5jaGVja2VkIH0pO1xufSk7XG5cbnVwZGF0ZUV4aXN0aW5nVG9nZ2xlLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS11cGRhdGUtZXhpc3RpbmcnLCBvbjogdXBkYXRlRXhpc3RpbmdUb2dnbGUuY2hlY2tlZCB9KTtcbn0pO1xuXG5sb3dCYW5kd2lkdGhUb2dnbGUuYWRkRXZlbnRMaXN0ZW5lcignY2hhbmdlJywgKCkgPT4ge1xuICB2b2lkIHNlbmQoeyB0eXBlOiAndG9nZ2xlLWxvdy1iYW5kd2lkdGgnLCBvbjogbG93QmFuZHdpZHRoVG9nZ2xlLmNoZWNrZWQgfSk7XG59KTtcblxubWFzdGVyU3dpdGNoLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3RvZ2dsZS1lbmFibGVkJywgb246IG1hc3RlclN3aXRjaC5jaGVja2VkIH0pO1xufSk7XG5cbmF1dG9TY3JvbGxTdGFydEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgYXV0b1Njcm9sbFN0YXJ0QnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3N0YXJ0LWF1dG8tc2Nyb2xsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBhdXRvU2Nyb2xsU3RhcnRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcbmF1dG9TY3JvbGxDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGF1dG9TY3JvbGxDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLWF1dG8tc2Nyb2xsJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICBhdXRvU2Nyb2xsQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbmF1dG9TY3JvbGxJbnRlcnZhbC5hZGRFdmVudExpc3RlbmVyKCdpbnB1dCcsICgpID0+IHtcbiAgYXV0b1Njcm9sbFNlY3NFbC50ZXh0Q29udGVudCA9IGF1dG9TY3JvbGxJbnRlcnZhbC52YWx1ZTtcbn0pO1xuYXV0b1Njcm9sbEludGVydmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsICgpID0+IHtcbiAgY29uc3Qgc2Vjb25kcyA9IE51bWJlcihhdXRvU2Nyb2xsSW50ZXJ2YWwudmFsdWUpO1xuICBpZiAoTnVtYmVyLmlzRmluaXRlKHNlY29uZHMpKSB7XG4gICAgdm9pZCBzZW5kKHsgdHlwZTogJ3NldC1hdXRvLXNjcm9sbC1pbnRlcnZhbCcsIHNlY29uZHMgfSk7XG4gIH1cbn0pO1xuXG5wdXJnZUxpbmsuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZTogRXZlbnQpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICBjb25zdCBvayA9IHdpbmRvdy5jb25maXJtKFxuICAgICdEcm9wIGV2ZXJ5IGNvdW50ZXIsIHJ1biBidWZmZXIsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCAvIHRocmVhZC1vcGVuaW5nIHF1ZXVlIGVudHJ5IGZvciBhY2NvdW50cyBub3QgaW4geW91ciB0cmFja2VkIGxpc3Q/XFxuXFxuJyArXG4gICAgICAnVGhpcyBvbmx5IHRvdWNoZXMgbG9jYWwgZXh0ZW5zaW9uIHN0YXRlLiBBbHJlYWR5LWNvbW1pdHRlZCBmaWxlcyBpbiB0aGUgR2l0SHViIHJlcG8gYXJlIG5vdCBhZmZlY3RlZCBcdTIwMTQgJyArXG4gICAgICAncnVuIHNjcmlwdHMvcHVyZ2VfdW5yZWxhdGVkLnB5IHNlcGFyYXRlbHkgaWYgeW91IGFsc28gd2FudCB0byBzY3J1YiB0aGUgcmVwby4nXG4gICk7XG4gIGlmICghb2spIHJldHVybjtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ3B1cmdlLXVucmVsYXRlZCcgfSk7XG59KTtcblxucmVmZXRjaFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICByZWZldGNoU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtcmVmZXRjaCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgcmVmZXRjaFN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbnJlZmV0Y2hDYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLXJlZmV0Y2gnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIHJlZmV0Y2hDYW5jZWxCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgfSk7XG59KTtcblxubWVkaWFDcmF3bFN0YXJ0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBtZWRpYUNyYXdsU3RhcnRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnc3RhcnQtbWVkaWEtY3Jhd2wnIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgIG1lZGlhQ3Jhd2xTdGFydEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG5tZWRpYUNyYXdsQ2FuY2VsQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBtZWRpYUNyYXdsQ2FuY2VsQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ2NhbmNlbC1tZWRpYS1jcmF3bCcgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgbWVkaWFDcmF3bENhbmNlbEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9KTtcbn0pO1xuXG50aHJlYWRPcGVuU3RhcnRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIHRocmVhZE9wZW5TdGFydEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdzdGFydC10aHJlYWQtb3BlbicgfSkuZmluYWxseSgoKSA9PiB7XG4gICAgdGhyZWFkT3BlblN0YXJ0QnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbnRocmVhZE9wZW5DYW5jZWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIHRocmVhZE9wZW5DYW5jZWxCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICB2b2lkIHNlbmQoeyB0eXBlOiAnY2FuY2VsLXRocmVhZC1vcGVuJyB9KS5maW5hbGx5KCgpID0+IHtcbiAgICB0aHJlYWRPcGVuQ2FuY2VsQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gIH0pO1xufSk7XG5cbm9wdGlvbnNMaW5rLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGU6IEV2ZW50KSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKTtcbiAgdm9pZCBzZW5kKHsgdHlwZTogJ29wZW4tb3B0aW9ucycgfSk7XG59KTtcblxudmlld2VyTGluay5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlOiBFdmVudCkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIHZvaWQgc2VuZCh7IHR5cGU6ICdvcGVuLXZpZXdlcicgfSk7XG59KTtcblxuY2xlYXJBY3RCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGF3YWl0IHNlbmQoeyB0eXBlOiAnY2xlYXItYWN0aXZpdHknIH0pO1xuICByZW5kZXJBY3Rpdml0eShbXSk7XG59KTtcblxuYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiB1bmtub3duKSA9PiB7XG4gIGlmICghbXNnIHx8IHR5cGVvZiBtc2cgIT09ICdvYmplY3QnKSByZXR1cm47XG4gIGNvbnN0IG0gPSBtc2cgYXMgeyB0eXBlPzogc3RyaW5nOyBzdGF0ZT86IEV4dGVuc2lvblN0YXRlOyBldmVudD86IExvZ0V2ZW50IH07XG4gIGlmIChtLnR5cGUgPT09ICdzdGF0ZS1jaGFuZ2VkJyAmJiBtLnN0YXRlKSB7XG4gICAgbGFzdFN0YXRlID0gbS5zdGF0ZTtcbiAgICBwYWludChtLnN0YXRlKTtcbiAgfSBlbHNlIGlmIChtLnR5cGUgPT09ICdsb2ctZXZlbnQnICYmIG0uZXZlbnQpIHtcbiAgICBwcmVwZW5kRXZlbnQobS5ldmVudCk7XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBwcmVwZW5kRXZlbnQoZXY6IExvZ0V2ZW50KTogdm9pZCB7XG4gIC8vIElmIHRoZSBsaXN0IGlzIHNob3dpbmcgdGhlIFwiZW1wdHlcIiBwbGFjZWhvbGRlciwgY2xlYXIgaXQuXG4gIGlmIChhY3Rpdml0eUxpc3QuZmlyc3RFbGVtZW50Q2hpbGQ/LmNsYXNzTGlzdC5jb250YWlucygnZW1wdHknKSkge1xuICAgIGFjdGl2aXR5TGlzdC5yZXBsYWNlQ2hpbGRyZW4oKTtcbiAgfVxuICBjb25zdCBsaSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gIGxpLmNsYXNzTmFtZSA9IGBldiAke2V2LmxldmVsfWA7XG4gIGNvbnN0IHRzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICB0cy5jbGFzc05hbWUgPSAnZXYtdHMnO1xuICB0cy50ZXh0Q29udGVudCA9IG5ldyBEYXRlKGV2LnRzKS50b0xvY2FsZVRpbWVTdHJpbmcoJ2VuLVVTJywgeyBob3VyMTI6IGZhbHNlIH0pO1xuICBjb25zdCBpY29uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBpY29uLmNsYXNzTmFtZSA9ICdldi1pY29uJztcbiAgaWNvbi50ZXh0Q29udGVudCA9IGV2LmxldmVsID09PSAnZXJyb3InID8gJ1x1MjcxNycgOiBldi5sZXZlbCA9PT0gJ3dhcm4nID8gJyEnIDogJ1x1MDBCNyc7XG4gIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIGNvbnN0IG1zZyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBtc2cuY2xhc3NOYW1lID0gJ2V2LW1zZyc7XG4gIG1zZy50ZXh0Q29udGVudCA9IGV2Lm1zZztcbiAgYm9keS5hcHBlbmQobXNnKTtcbiAgY29uc3QgY3R4S2V5cyA9IE9iamVjdC5rZXlzKGV2LmNvbnRleHQpO1xuICBpZiAoY3R4S2V5cy5sZW5ndGggPiAwKSB7XG4gICAgY29uc3QgY3R4ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgY3R4LmNsYXNzTmFtZSA9ICdldi1jdHgnO1xuICAgIGN0eC50ZXh0Q29udGVudCA9IGN0eEtleXMubWFwKChrKSA9PiBgJHtrfT0ke3N0cmluZ2lmeVNob3J0KGV2LmNvbnRleHRba10pfWApLmpvaW4oJyBcdTAwQjcgJyk7XG4gICAgYm9keS5hcHBlbmQoY3R4KTtcbiAgfVxuICBsaS5hcHBlbmQodHMsIGljb24sIGJvZHkpO1xuICBhY3Rpdml0eUxpc3QucHJlcGVuZChsaSk7XG4gIHdoaWxlIChhY3Rpdml0eUxpc3QuY2hpbGRFbGVtZW50Q291bnQgPiBBQ1RJVklUWV9UQUlMX01BWCkge1xuICAgIGFjdGl2aXR5TGlzdC5sYXN0RWxlbWVudENoaWxkPy5yZW1vdmUoKTtcbiAgfVxufVxuXG4vLyBJbml0aWFsIHBhaW50Llxudm9pZCByZWZyZXNoU3RhdGUoKTtcbnZvaWQgcmVmcmVzaEFjdGl2aXR5KCk7XG5cbi8vIFBlcmlvZGljYWxseSByZS1mZXRjaCBzdGF0ZSBzbyBcImxhc3QgY2FwdHVyZVwiIHRpbWVzIHN0YXkgZnJlc2guXG5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gIHZvaWQgcmVmcmVzaFN0YXRlKCk7XG59LCAxNV8wMDApO1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBOEZPLElBQU0sb0JBQW9CO0FBRzFCLElBQU0sZ0NBQWdDLEtBQUssS0FBSzs7O0FDdEZ2RCxJQUFNLElBQUksQ0FBc0MsT0FBa0I7QUFDaEUsUUFBTSxLQUFLLFNBQVMsZUFBZSxFQUFFO0FBQ3JDLE1BQUksQ0FBQyxHQUFJLE9BQU0sSUFBSSxNQUFNLG9CQUFvQixFQUFFLEVBQUU7QUFDakQsU0FBTztBQUNUO0FBRUEsSUFBTSxVQUFVLEVBQUUsVUFBVTtBQUM1QixJQUFNLFdBQVcsRUFBbUIsV0FBVztBQUMvQyxJQUFNLGNBQWMsRUFBb0IsY0FBYztBQUN0RCxJQUFNLGtCQUFrQixFQUFvQixtQkFBbUI7QUFDL0QsSUFBTSxlQUFlLEVBQW9CLGVBQWU7QUFDeEQsSUFBTSxhQUFhLEVBQW9CLGNBQWM7QUFDckQsSUFBTSx1QkFBdUIsRUFBb0IsaUJBQWlCO0FBQ2xFLElBQU0scUJBQXFCLEVBQW9CLGVBQWU7QUFDOUQsSUFBTSxnQkFBZ0IsRUFBcUIsYUFBYTtBQUN4RCxJQUFNLGlCQUFpQixFQUFxQixjQUFjO0FBQzFELElBQU0sV0FBVyxFQUFxQixXQUFXO0FBQ2pELElBQU0sY0FBYyxFQUFxQixjQUFjO0FBQ3ZELElBQU0sYUFBYSxFQUFxQixhQUFhO0FBQ3JELElBQU0sY0FBYyxFQUFxQixnQkFBZ0I7QUFDekQsSUFBTSxlQUFlLEVBQW1CLGFBQWE7QUFDckQsSUFBTSxlQUFlLEVBQW9CLGVBQWU7QUFDeEQsSUFBTSxjQUFjLEVBQW1CLGNBQWM7QUFDckQsSUFBTSxxQkFBcUIsRUFBb0Isc0JBQXNCO0FBQ3JFLElBQU0sbUJBQW1CLEVBQW1CLGtCQUFrQjtBQUM5RCxJQUFNLG1CQUFtQixFQUFtQixvQkFBb0I7QUFDaEUsSUFBTSxxQkFBcUIsRUFBcUIsbUJBQW1CO0FBQ25FLElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLHFCQUFxQixFQUFtQixzQkFBc0I7QUFDcEUsSUFBTSxpQkFBaUIsRUFBZSxpQkFBaUI7QUFDdkQsSUFBTSxlQUFlLEVBQW1CLGVBQWU7QUFDdkQsSUFBTSxrQkFBa0IsRUFBcUIsZUFBZTtBQUM1RCxJQUFNLG1CQUFtQixFQUFxQixnQkFBZ0I7QUFDOUQsSUFBTSxrQkFBa0IsRUFBbUIsa0JBQWtCO0FBQzdELElBQU0sb0JBQW9CLEVBQWUscUJBQXFCO0FBQzlELElBQU0sa0JBQWtCLEVBQW1CLG1CQUFtQjtBQUM5RCxJQUFNLHFCQUFxQixFQUFxQixtQkFBbUI7QUFDbkUsSUFBTSxzQkFBc0IsRUFBcUIsb0JBQW9CO0FBQ3JFLElBQU0scUJBQXFCLEVBQW1CLHNCQUFzQjtBQUNwRSxJQUFNLG9CQUFvQixFQUFlLHFCQUFxQjtBQUM5RCxJQUFNLGtCQUFrQixFQUFtQixtQkFBbUI7QUFDOUQsSUFBTSxxQkFBcUIsRUFBcUIsbUJBQW1CO0FBQ25FLElBQU0sc0JBQXNCLEVBQXFCLG9CQUFvQjtBQUNyRSxJQUFNLHFCQUFxQixFQUFtQixzQkFBc0I7QUFDcEUsSUFBTSxZQUFZLEVBQXFCLGlCQUFpQjtBQUV4RCxJQUFJLFlBQW1DO0FBRXZDLGVBQWUsS0FBUSxLQUFpQztBQUN0RCxTQUFPLFFBQVEsUUFBUSxZQUFZLEdBQUc7QUFDeEM7QUFFQSxTQUFTLGNBQWMsT0FBNkI7QUFDbEQsUUFBTSxFQUFFLFlBQVksU0FBUyxJQUFJO0FBQ2pDLE1BQUksTUFBTTtBQUNWLE1BQUksT0FBTztBQUtYLFFBQU0sZ0JBQ0osV0FBVyxXQUFXLFFBQVEsU0FBUyxVQUFVLFdBQVcsMkJBQTJCO0FBQ3pGLE1BQUksQ0FBQyxTQUFTLFFBQVE7QUFDcEIsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNULFdBQVcsZUFBZTtBQUN4QixVQUFNO0FBQ04sV0FBTyxXQUFXLFNBQVMsTUFBTSx1QkFBdUIsU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLDRDQUF1QyxXQUFXLGlCQUFpQixRQUFRO0FBQUEsRUFDcEssV0FBVyxXQUFXLFdBQVcsTUFBTTtBQUNyQyxVQUFNO0FBQ04sV0FBTyxpQkFBaUIsV0FBVyxTQUFTLEdBQUcsT0FBTyxTQUFTLEtBQUssSUFBSSxTQUFTLElBQUksZUFBTyxTQUFTLFNBQVM7QUFBQSxFQUNoSCxXQUFXLFdBQVcsV0FBVyxjQUFjO0FBQzdDLFVBQU07QUFDTixXQUFPLGlCQUFpQixXQUFXLEtBQUssSUFDcEMsb0VBQ0E7QUFBQSxFQUNOLFdBQVcsV0FBVyxXQUFXLGdCQUFnQjtBQUMvQyxVQUFNO0FBQ04sVUFBTSxTQUFTLGtCQUFrQixXQUFXLGdCQUFnQjtBQUM1RCxXQUFPLFNBQ0gscUNBQWdDLE1BQU0sS0FDdEM7QUFBQSxFQUNOLFdBQVcsV0FBVyxXQUFXLGlCQUFpQjtBQUNoRCxVQUFNO0FBQ04sV0FBTztBQUFBLEVBQ1QsV0FBVyxXQUFXLFdBQVcsa0JBQWtCO0FBQ2pELFVBQU07QUFDTixXQUFPO0FBQUEsRUFDVCxPQUFPO0FBQ0wsVUFBTTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0EsVUFBUSxZQUFZLE9BQU8sR0FBRztBQUM5QixXQUFTLGNBQWM7QUFDdkIsV0FBUyxRQUFRLFdBQVcsU0FBUztBQUN2QztBQUVBLFNBQVMsT0FBTyxLQUE0QjtBQUMxQyxNQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLFFBQU0sSUFBSSxLQUFLLE1BQU0sR0FBRztBQUN4QixNQUFJLENBQUMsT0FBTyxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQ2hDLFFBQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxHQUFJLENBQUM7QUFDNUQsTUFBSSxPQUFPLEVBQUcsUUFBTztBQUNyQixNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLE9BQU8sS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNqQyxNQUFJLE9BQU8sR0FBSSxRQUFPLEdBQUcsSUFBSTtBQUM3QixRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxNQUFJLFFBQVEsR0FBSSxRQUFPLEdBQUcsS0FBSztBQUMvQixRQUFNLE9BQU8sS0FBSyxNQUFNLFFBQVEsRUFBRTtBQUNsQyxTQUFPLEdBQUcsSUFBSTtBQUNoQjtBQUVBLFNBQVMsa0JBQWtCLFVBQWlDO0FBQzFELE1BQUksYUFBYSxLQUFNLFFBQU87QUFDOUIsUUFBTSxXQUFXLFdBQVcsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDeEQsTUFBSSxZQUFZLEVBQUcsUUFBTztBQUMxQixRQUFNLFlBQVksSUFBSSxLQUFLLFdBQVcsR0FBSSxFQUFFLG1CQUFtQixDQUFDLEdBQUc7QUFBQSxJQUNqRSxNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsRUFDVixDQUFDO0FBQ0QsTUFBSSxXQUFXLEdBQUksUUFBTyxNQUFNLFFBQVEsTUFBTSxTQUFTO0FBQ3ZELFFBQU0sT0FBTyxLQUFLLE1BQU0sV0FBVyxFQUFFO0FBQ3JDLE1BQUksT0FBTyxHQUFJLFFBQU8sTUFBTSxJQUFJLE1BQU0sU0FBUztBQUMvQyxRQUFNLFFBQVEsS0FBSyxNQUFNLE9BQU8sRUFBRTtBQUNsQyxTQUFPLE1BQU0sS0FBSyxNQUFNLFNBQVM7QUFDbkM7QUFFQSxTQUFTLE9BQU8sR0FBbUI7QUFDakMsU0FBTyxFQUFFLGVBQWUsT0FBTztBQUNqQztBQUVBLFNBQVMsaUJBQWlCLFNBQWlDO0FBQ3pELFNBQ0UsT0FBTyxZQUFZLFlBQ25CLDZFQUE2RSxLQUFLLE9BQU87QUFFN0Y7QUFFQSxTQUFTLGVBQWUsT0FBNkI7QUFDbkQsY0FBWSxnQkFBZ0I7QUFDNUIsTUFBSSxNQUFNLFNBQVMsV0FBVyxHQUFHO0FBQy9CLFVBQU0sS0FBSyxTQUFTLGNBQWMsSUFBSTtBQUN0QyxPQUFHLFlBQVk7QUFDZixPQUFHLGNBQWM7QUFDakIsZ0JBQVksT0FBTyxFQUFFO0FBQ3JCO0FBQUEsRUFDRjtBQUNBLGFBQVcsS0FBSyxNQUFNLFVBQVU7QUFDOUIsVUFBTSxJQUFJLE1BQU0sU0FBUyxFQUFFLE1BQU07QUFDakMsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxLQUFLLEVBQUUsZ0JBQWdCLElBQUksZ0JBQWdCO0FBRTFELFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLFlBQVk7QUFDakIsVUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0FBQzVDLFdBQU8sWUFBWTtBQUNuQixXQUFPLFlBQVksNEJBQTRCLFdBQVcsRUFBRSxNQUFNLENBQUM7QUFDbkUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsRUFBRTtBQUNyQixTQUFLLE9BQU8sUUFBUSxJQUFJO0FBRXhCLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsVUFBTSxRQUFRLFNBQVMsY0FBYyxNQUFNO0FBQzNDLFVBQU0sWUFBWTtBQUNsQixVQUFNLFFBQVEsR0FBRyxjQUFjO0FBQy9CLFVBQU0sV0FBVyxHQUFHLGlCQUFpQjtBQUNyQyxVQUFNLE9BQU8sR0FBRyxpQkFBaUI7QUFDakMsVUFBTSxZQUNKLHFCQUFxQixPQUFPLEtBQUssQ0FBQyxtQkFDakMsV0FBVyxJQUFJLDJCQUF3QixPQUFPLFFBQVEsQ0FBQyxxQkFBcUIsTUFDN0UsY0FBVyxXQUFXLE9BQU8sSUFBSSxDQUFDLENBQUM7QUFFckMsVUFBTSxVQUFVLFNBQVMsY0FBYyxNQUFNO0FBQzdDLFlBQVEsWUFBWTtBQUNwQixVQUFNLE1BQU0sU0FBUyxjQUFjLFFBQVE7QUFDM0MsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBYztBQUNsQixRQUFJLGlCQUFpQixTQUFTLFlBQVk7QUFDeEMsVUFBSSxXQUFXO0FBQ2YsVUFBSTtBQUNGLGNBQU0sS0FBSyxFQUFFLE1BQU0sZUFBZSxRQUFRLEVBQUUsT0FBTyxDQUFDO0FBQUEsTUFDdEQsVUFBRTtBQUNBLFlBQUksV0FBVztBQUFBLE1BQ2pCO0FBQUEsSUFDRixDQUFDO0FBQ0QsWUFBUSxPQUFPLEdBQUc7QUFFbEIsUUFBSSxPQUFPLE9BQU8sT0FBTztBQUN6QixPQUFHLE9BQU8sTUFBTSxHQUFHO0FBQ25CLGdCQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsUUFBMEI7QUFDaEQsZUFBYSxnQkFBZ0I7QUFDN0IsTUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjO0FBQ2pCLGlCQUFhLE9BQU8sRUFBRTtBQUN0QjtBQUFBLEVBQ0Y7QUFDQSxhQUFXLE1BQU0sT0FBTyxNQUFNLEdBQUcsaUJBQWlCLEdBQUc7QUFDbkQsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixVQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsT0FBRyxZQUFZO0FBQ2YsT0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsR0FBRztBQUNyQixTQUFLLE9BQU8sR0FBRztBQUNmLFVBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLFFBQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsWUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFVBQUksWUFBWTtBQUNoQixVQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFdBQUssT0FBTyxHQUFHO0FBQUEsSUFDakI7QUFDQSxPQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsaUJBQWEsT0FBTyxFQUFFO0FBQUEsRUFDeEI7QUFDRjtBQUVBLFNBQVMsZUFBZSxHQUFvQjtBQUMxQyxNQUFJLE1BQU0sS0FBTSxRQUFPO0FBQ3ZCLE1BQUksT0FBTyxNQUFNLFNBQVUsUUFBTyxFQUFFLFNBQVMsS0FBSyxHQUFHLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxXQUFNO0FBQ3pFLE1BQUksT0FBTyxNQUFNLFlBQVksT0FBTyxNQUFNLFVBQVcsUUFBTyxPQUFPLENBQUM7QUFDcEUsTUFBSTtBQUNGLFVBQU0sSUFBSSxLQUFLLFVBQVUsQ0FBQztBQUMxQixXQUFPLEVBQUUsU0FBUyxLQUFLLEdBQUcsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDLFdBQU07QUFBQSxFQUNoRCxRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVBLFNBQVMsV0FBVyxHQUFtQjtBQUNyQyxTQUFPLEVBQUU7QUFBQSxJQUFRO0FBQUEsSUFBWSxDQUFDLE1BQzVCLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLE1BQU0sTUFBTSxXQUFXO0FBQUEsRUFDekY7QUFDRjtBQUVBLGVBQWUsZUFBOEI7QUFDM0MsTUFBSTtBQUNGLGdCQUFZLE1BQU0sS0FBcUIsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUM1RCxVQUFNLFNBQVM7QUFBQSxFQUNqQixTQUFTLEtBQUs7QUFDWixZQUFRLEtBQUssNkNBQTZDLEdBQUc7QUFBQSxFQUMvRDtBQUNGO0FBRUEsU0FBUyxNQUFNLE9BQTZCO0FBQzFDLGVBQWEsY0FBYyxNQUFNO0FBQ2pDLGdCQUFjLEtBQUs7QUFDbkIsYUFBVyxVQUFVLE1BQU0sU0FBUztBQUNwQyx1QkFBcUIsVUFBVSxNQUFNLFNBQVMsbUJBQW1CO0FBQ2pFLHFCQUFtQixVQUFVLE1BQU0sU0FBUyx5QkFBeUI7QUFDckUsYUFBVyxPQUFPLFdBQVcsTUFBTSxTQUFTLEtBQUssY0FBYyxNQUFNLFNBQVMsSUFBSTtBQUNsRixvQkFBa0IsS0FBSztBQUN2QixpQkFBZSxLQUFLO0FBQ3BCLHFCQUFtQixNQUFNLG9CQUFvQjtBQUM3QyxrQkFBZ0IsS0FBSztBQUNyQixrQkFBZ0IsS0FBSztBQUNyQixlQUFhLEtBQUs7QUFDbEIsa0JBQWdCLEtBQUs7QUFDdkI7QUFFQSxTQUFTLG1CQUFtQixNQUE2QjtBQUN2RCxrQkFBZ0IsZ0JBQWdCO0FBQ2hDLE1BQUksS0FBSyxXQUFXLEdBQUc7QUFDckIsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWTtBQUNmLE9BQUcsY0FBYztBQUNqQixvQkFBZ0IsT0FBTyxFQUFFO0FBQ3pCO0FBQUEsRUFDRjtBQUNBLGFBQVcsT0FBTyxLQUFLLE1BQU0sR0FBRyxFQUFFLEdBQUc7QUFDbkMsVUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLE9BQUcsWUFBWSxnQkFBZ0IsSUFBSSxjQUFjO0FBRWpELFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLFlBQVk7QUFDaEIsVUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0FBQ3ZDLFNBQUssWUFBWTtBQUNqQixTQUFLLE9BQU8sSUFBSTtBQUNoQixTQUFLLFNBQVM7QUFDZCxTQUFLLE1BQU07QUFDWCxTQUFLLGNBQWMsSUFBSSxJQUFJLGNBQWM7QUFDekMsVUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0FBQzVDLFdBQU8sWUFBWSxjQUFjLElBQUksY0FBYztBQUNuRCxXQUFPLGNBQWMsSUFBSSxtQkFBbUIsVUFBVSxVQUFVO0FBQ2hFLFFBQUksT0FBTyxNQUFNLE1BQU07QUFFdkIsVUFBTSxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQ3pDLFNBQUssWUFBWTtBQUNqQixTQUFLLGNBQWMsYUFBYSxJQUFJLE1BQU0sR0FBRztBQUU3QyxVQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFDekMsU0FBSyxZQUFZO0FBQ2pCLFNBQUssY0FBYyxHQUFHLGtCQUFrQixJQUFJLE1BQU0sQ0FBQyxTQUFNLElBQUksVUFBVSxnQkFBYSxPQUFPLElBQUksU0FBUyxDQUFDO0FBRXpHLE9BQUcsT0FBTyxLQUFLLE1BQU0sSUFBSTtBQUN6QixvQkFBZ0IsT0FBTyxFQUFFO0FBQUEsRUFDM0I7QUFDRjtBQUVBLFNBQVMsa0JBQWtCLFFBQXlDO0FBQ2xFLE1BQUksV0FBVyxXQUFZLFFBQU87QUFDbEMsTUFBSSxXQUFXLFlBQWEsUUFBTztBQUNuQyxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGFBQWEsTUFBYyxLQUFxQjtBQUN2RCxRQUFNLFVBQVUsS0FBSyxRQUFRLFFBQVEsR0FBRyxFQUFFLEtBQUs7QUFDL0MsU0FBTyxRQUFRLFVBQVUsTUFBTSxVQUFVLEdBQUcsUUFBUSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFDdkU7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLElBQUksTUFBTTtBQUNoQixRQUFNLFFBQVEsRUFBRTtBQUNoQixRQUFNLFVBQVUsRUFBRTtBQUNsQixvQkFBa0IsU0FBUyxVQUFVLEtBQUssQ0FBQztBQUMzQyxrQkFBZ0IsY0FDZCxVQUFVLElBQ04sVUFDRSxvQkFDQSxhQUNGLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxVQUFVLGtCQUFlLEVBQUU7QUFDM0QscUJBQW1CLFNBQVM7QUFDNUIscUJBQW1CLFdBQVcsVUFBVTtBQUN4QyxzQkFBb0IsU0FBUyxDQUFDO0FBQzlCLHFCQUFtQixvQkFBb0IsQ0FBQztBQUMxQztBQUVBLFNBQVMsbUJBQ1AsSUFDQSxHQUNNO0FBQ04sTUFBSSxDQUFDLEVBQUUsV0FBVyxFQUFFLGNBQWMsR0FBRztBQUNuQyxPQUFHLFNBQVM7QUFDWjtBQUFBLEVBQ0Y7QUFHQSxRQUFNLFFBQVEsS0FBSyxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLEtBQUs7QUFDOUQsS0FBRyxTQUFTO0FBQ1osS0FBRyxjQUFjLEdBQUcsT0FBTyxFQUFFLFNBQVMsQ0FBQyxNQUFNLE9BQU8sS0FBSyxDQUFDO0FBQzFELEtBQUcsWUFBWSxFQUFFLFVBQVUsZ0JBQWdCO0FBQzdDO0FBRUEsU0FBUyxrQkFBa0IsT0FBNkI7QUFDdEQsUUFBTSxLQUFLLE1BQU0sU0FBUyxZQUFZO0FBQ3RDLGVBQWEsVUFBVTtBQUN2QixjQUFZLGNBQWMsS0FBSyxPQUFPO0FBQ3RDLFdBQVMsS0FBSyxVQUFVLE9BQU8sVUFBVSxDQUFDLEVBQUU7QUFDOUM7QUFFQSxTQUFTLGdCQUFnQixPQUE2QjtBQUNwRCxRQUFNLE9BQU8sTUFBTSxTQUFTO0FBQzVCLHFCQUFtQixRQUFRLE9BQU8sSUFBSTtBQUN0QyxtQkFBaUIsY0FBYyxPQUFPLElBQUk7QUFDMUMsUUFBTSxLQUFLLE1BQU07QUFDakIscUJBQW1CLFNBQVMsR0FBRztBQUMvQixzQkFBb0IsU0FBUyxDQUFDLEdBQUc7QUFDakMsTUFBSSxHQUFHLFFBQVE7QUFDYixVQUFNLElBQUksR0FBRztBQUNiLHFCQUFpQixjQUNmLE1BQU0sSUFBSSxrQ0FBNkIsa0JBQWEsQ0FBQyxJQUFJLE1BQU0sSUFBSSxRQUFRLE1BQU07QUFDbkYscUJBQWlCLFlBQVk7QUFBQSxFQUMvQixPQUFPO0FBQ0wscUJBQWlCLGNBQWM7QUFDL0IscUJBQWlCLFlBQVk7QUFBQSxFQUMvQjtBQUNBLE1BQUksR0FBRyxVQUFVLEdBQUcsY0FBYyxLQUFLLEdBQUcsZ0JBQWdCLEdBQUc7QUFDM0QsdUJBQW1CLFNBQVM7QUFDNUIsVUFBTSxRQUFRO0FBQUEsTUFDWixHQUFHLE9BQU8sR0FBRyxXQUFXLENBQUM7QUFBQSxNQUN6QixHQUFHLE9BQU8sR0FBRyxnQkFBZ0IsQ0FBQztBQUFBLE1BQzlCLEdBQUcsT0FBTyxHQUFHLHFCQUFxQixDQUFDO0FBQUEsSUFDckM7QUFDQSxRQUFJLEdBQUcsa0JBQWtCLEVBQUcsT0FBTSxLQUFLLEdBQUcsT0FBTyxHQUFHLGVBQWUsQ0FBQyxjQUFjO0FBQ2xGLFVBQU0sS0FBSyxHQUFHLE9BQU8sR0FBRyxhQUFhLENBQUMsV0FBVztBQUNqRCx1QkFBbUIsY0FBYyxNQUFNLEtBQUssUUFBSztBQUNqRCx1QkFBbUIsWUFBWSxHQUFHLFNBQVMsZ0JBQWdCO0FBQUEsRUFDN0QsT0FBTztBQUNMLHVCQUFtQixTQUFTO0FBQUEsRUFDOUI7QUFDRjtBQUVBLFNBQVMsYUFBYSxPQUE2QjtBQUNqRCxRQUFNLElBQUksTUFBTTtBQUNoQixRQUFNLFFBQVEsRUFBRTtBQUNoQixRQUFNLFVBQVUsRUFBRTtBQUNsQixpQkFBZSxTQUFTLFVBQVUsS0FBSyxDQUFDO0FBQ3hDLGVBQWEsY0FDWCxVQUFVLElBQ04sVUFDRSxvQkFDQSxhQUNGLEdBQUcsT0FBTyxLQUFLLENBQUMsVUFBVSxVQUFVLGtCQUFlLEVBQUU7QUFDM0Qsa0JBQWdCLFNBQVM7QUFDekIsa0JBQWdCLFdBQVcsVUFBVTtBQUNyQyxtQkFBaUIsU0FBUyxDQUFDO0FBQzNCLHFCQUFtQixpQkFBaUIsQ0FBQztBQUN2QztBQUVBLFNBQVMsZ0JBQWdCLE9BQTZCO0FBQ3BELFFBQU0sSUFBSSxNQUFNO0FBQ2hCLFFBQU0sUUFBUSxFQUFFO0FBQ2hCLFFBQU0sVUFBVSxFQUFFO0FBQ2xCLG9CQUFrQixTQUFTLFVBQVUsS0FBSyxDQUFDO0FBQzNDLGtCQUFnQixjQUNkLFVBQVUsSUFDTixVQUNFLGlCQUNBLGFBQ0YsR0FBRyxPQUFPLEtBQUssQ0FBQyxVQUFVLFVBQVUsa0JBQWUsRUFBRTtBQUMzRCxxQkFBbUIsU0FBUztBQUM1QixxQkFBbUIsV0FBVyxVQUFVO0FBQ3hDLHNCQUFvQixTQUFTLENBQUM7QUFDOUIscUJBQW1CLG9CQUFvQixDQUFDO0FBQzFDO0FBRUEsZUFBZSxrQkFBaUM7QUFHOUMsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxVQUFVO0FBQ3pELFFBQU0sU0FBVSxPQUFPLFlBQXVDLENBQUM7QUFDL0QsaUJBQWUsTUFBTTtBQUN2QjtBQUlBLGNBQWMsaUJBQWlCLFNBQVMsWUFBWTtBQUNsRCxnQkFBYyxXQUFXO0FBQ3pCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUFBLEVBQ3BDLFVBQUU7QUFDQSxrQkFBYyxXQUFXO0FBQUEsRUFDM0I7QUFDRixDQUFDO0FBRUQsZUFBZSxpQkFBaUIsU0FBUyxZQUFZO0FBQ25ELGlCQUFlLFdBQVc7QUFDMUIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFBQSxFQUMxQyxVQUFFO0FBQ0EsbUJBQWUsV0FBVztBQUFBLEVBQzVCO0FBQ0YsQ0FBQztBQUVELFNBQVMsaUJBQWlCLFNBQVMsWUFBWTtBQUM3QyxXQUFTLFdBQVc7QUFDcEIsTUFBSTtBQUNGLFVBQU0sS0FBSyxFQUFFLE1BQU0sWUFBWSxDQUFDO0FBQUEsRUFDbEMsVUFBRTtBQUNBLGFBQVMsV0FBVztBQUFBLEVBQ3RCO0FBQ0YsQ0FBQztBQUVELFdBQVcsaUJBQWlCLFVBQVUsTUFBTTtBQUMxQyxPQUFLLEtBQUssRUFBRSxNQUFNLHVCQUF1QixJQUFJLFdBQVcsUUFBUSxDQUFDO0FBQ25FLENBQUM7QUFFRCxxQkFBcUIsaUJBQWlCLFVBQVUsTUFBTTtBQUNwRCxPQUFLLEtBQUssRUFBRSxNQUFNLDBCQUEwQixJQUFJLHFCQUFxQixRQUFRLENBQUM7QUFDaEYsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsVUFBVSxNQUFNO0FBQ2xELE9BQUssS0FBSyxFQUFFLE1BQU0sd0JBQXdCLElBQUksbUJBQW1CLFFBQVEsQ0FBQztBQUM1RSxDQUFDO0FBRUQsYUFBYSxpQkFBaUIsVUFBVSxNQUFNO0FBQzVDLE9BQUssS0FBSyxFQUFFLE1BQU0sa0JBQWtCLElBQUksYUFBYSxRQUFRLENBQUM7QUFDaEUsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELHFCQUFtQixXQUFXO0FBQzlCLE9BQUssS0FBSyxFQUFFLE1BQU0sb0JBQW9CLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDckQsdUJBQW1CLFdBQVc7QUFBQSxFQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUNELG9CQUFvQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2xELHNCQUFvQixXQUFXO0FBQy9CLE9BQUssS0FBSyxFQUFFLE1BQU0scUJBQXFCLENBQUMsRUFBRSxRQUFRLE1BQU07QUFDdEQsd0JBQW9CLFdBQVc7QUFBQSxFQUNqQyxDQUFDO0FBQ0gsQ0FBQztBQUVELG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNO0FBQ2pELG1CQUFpQixjQUFjLG1CQUFtQjtBQUNwRCxDQUFDO0FBQ0QsbUJBQW1CLGlCQUFpQixVQUFVLE1BQU07QUFDbEQsUUFBTSxVQUFVLE9BQU8sbUJBQW1CLEtBQUs7QUFDL0MsTUFBSSxPQUFPLFNBQVMsT0FBTyxHQUFHO0FBQzVCLFNBQUssS0FBSyxFQUFFLE1BQU0sNEJBQTRCLFFBQVEsQ0FBQztBQUFBLEVBQ3pEO0FBQ0YsQ0FBQztBQUVELFVBQVUsaUJBQWlCLFNBQVMsQ0FBQyxNQUFhO0FBQ2hELElBQUUsZUFBZTtBQUNqQixRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFHRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsT0FBSyxLQUFLLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUN2QyxDQUFDO0FBRUQsZ0JBQWdCLGlCQUFpQixTQUFTLE1BQU07QUFDOUMsa0JBQWdCLFdBQVc7QUFDM0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNqRCxvQkFBZ0IsV0FBVztBQUFBLEVBQzdCLENBQUM7QUFDSCxDQUFDO0FBRUQsaUJBQWlCLGlCQUFpQixTQUFTLE1BQU07QUFDL0MsbUJBQWlCLFdBQVc7QUFDNUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNsRCxxQkFBaUIsV0FBVztBQUFBLEVBQzlCLENBQUM7QUFDSCxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQscUJBQW1CLFdBQVc7QUFDOUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNyRCx1QkFBbUIsV0FBVztBQUFBLEVBQ2hDLENBQUM7QUFDSCxDQUFDO0FBRUQsb0JBQW9CLGlCQUFpQixTQUFTLE1BQU07QUFDbEQsc0JBQW9CLFdBQVc7QUFDL0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUN0RCx3QkFBb0IsV0FBVztBQUFBLEVBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRUQsbUJBQW1CLGlCQUFpQixTQUFTLE1BQU07QUFDakQscUJBQW1CLFdBQVc7QUFDOUIsT0FBSyxLQUFLLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUNyRCx1QkFBbUIsV0FBVztBQUFBLEVBQ2hDLENBQUM7QUFDSCxDQUFDO0FBRUQsb0JBQW9CLGlCQUFpQixTQUFTLE1BQU07QUFDbEQsc0JBQW9CLFdBQVc7QUFDL0IsT0FBSyxLQUFLLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQyxFQUFFLFFBQVEsTUFBTTtBQUN0RCx3QkFBb0IsV0FBVztBQUFBLEVBQ2pDLENBQUM7QUFDSCxDQUFDO0FBRUQsWUFBWSxpQkFBaUIsU0FBUyxDQUFDLE1BQWE7QUFDbEQsSUFBRSxlQUFlO0FBQ2pCLE9BQUssS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3BDLENBQUM7QUFFRCxXQUFXLGlCQUFpQixTQUFTLENBQUMsTUFBYTtBQUNqRCxJQUFFLGVBQWU7QUFDakIsT0FBSyxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDbkMsQ0FBQztBQUVELFlBQVksaUJBQWlCLFNBQVMsWUFBWTtBQUNoRCxRQUFNLEtBQUssRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3JDLGlCQUFlLENBQUMsQ0FBQztBQUNuQixDQUFDO0FBRUQsUUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLFFBQWlCO0FBQ3RELE1BQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxTQUFVO0FBQ3JDLFFBQU0sSUFBSTtBQUNWLE1BQUksRUFBRSxTQUFTLG1CQUFtQixFQUFFLE9BQU87QUFDekMsZ0JBQVksRUFBRTtBQUNkLFVBQU0sRUFBRSxLQUFLO0FBQUEsRUFDZixXQUFXLEVBQUUsU0FBUyxlQUFlLEVBQUUsT0FBTztBQUM1QyxpQkFBYSxFQUFFLEtBQUs7QUFBQSxFQUN0QjtBQUNGLENBQUM7QUFFRCxTQUFTLGFBQWEsSUFBb0I7QUFFeEMsTUFBSSxhQUFhLG1CQUFtQixVQUFVLFNBQVMsT0FBTyxHQUFHO0FBQy9ELGlCQUFhLGdCQUFnQjtBQUFBLEVBQy9CO0FBQ0EsUUFBTSxLQUFLLFNBQVMsY0FBYyxJQUFJO0FBQ3RDLEtBQUcsWUFBWSxNQUFNLEdBQUcsS0FBSztBQUM3QixRQUFNLEtBQUssU0FBUyxjQUFjLE1BQU07QUFDeEMsS0FBRyxZQUFZO0FBQ2YsS0FBRyxjQUFjLElBQUksS0FBSyxHQUFHLEVBQUUsRUFBRSxtQkFBbUIsU0FBUyxFQUFFLFFBQVEsTUFBTSxDQUFDO0FBQzlFLFFBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxPQUFLLFlBQVk7QUFDakIsT0FBSyxjQUFjLEdBQUcsVUFBVSxVQUFVLFdBQU0sR0FBRyxVQUFVLFNBQVMsTUFBTTtBQUM1RSxRQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsUUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLE1BQUksWUFBWTtBQUNoQixNQUFJLGNBQWMsR0FBRztBQUNyQixPQUFLLE9BQU8sR0FBRztBQUNmLFFBQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RDLE1BQUksUUFBUSxTQUFTLEdBQUc7QUFDdEIsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQWMsUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxlQUFlLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxRQUFLO0FBQ3hGLFNBQUssT0FBTyxHQUFHO0FBQUEsRUFDakI7QUFDQSxLQUFHLE9BQU8sSUFBSSxNQUFNLElBQUk7QUFDeEIsZUFBYSxRQUFRLEVBQUU7QUFDdkIsU0FBTyxhQUFhLG9CQUFvQixtQkFBbUI7QUFDekQsaUJBQWEsa0JBQWtCLE9BQU87QUFBQSxFQUN4QztBQUNGO0FBR0EsS0FBSyxhQUFhO0FBQ2xCLEtBQUssZ0JBQWdCO0FBR3JCLFlBQVksTUFBTTtBQUNoQixPQUFLLGFBQWE7QUFDcEIsR0FBRyxJQUFNOyIsCiAgIm5hbWVzIjogW10KfQo=
