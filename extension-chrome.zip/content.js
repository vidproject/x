var browser=globalThis.browser??globalThis.chrome;
"use strict";
(() => {
  // src/content.ts
  var TARGET = "IMM_ARCHIVE_CAPTURE";
  var READY = "IMM_ARCHIVE_HOOK_READY";
  var UNFOLD_SYNC_MS = 2e3;
  var UNFOLD_SCAN_DEBOUNCE_MS = 250;
  var LOW_BANDWIDTH_SCAN_DEBOUNCE_MS = 100;
  var LOW_BANDWIDTH_RESCAN_MS = 1500;
  var LOW_BANDWIDTH_MEDIA_EVENTS = ["loadstart", "loadedmetadata", "play", "playing"];
  var unfoldEnabled = false;
  var unfoldCoreHandles = /* @__PURE__ */ new Set();
  var unfoldRelevantTweetIds = /* @__PURE__ */ new Set();
  var unfoldScanTimer = null;
  var unfoldedControls = /* @__PURE__ */ new WeakSet();
  var lowBandwidthScrubberEnabled = false;
  var lowBandwidthObserver = null;
  var lowBandwidthScanTimer = null;
  var lowBandwidthRescanTimer = null;
  void browser.runtime.sendMessage({ type: "content-alive", url: location.href }).catch((err) => {
    console.warn("[imm-archive] content-alive ping failed", err);
  });
  function fallbackInject() {
    try {
      const src = browser.runtime.getURL("page-hook.js");
      const script = document.createElement("script");
      script.src = src;
      script.async = false;
      script.dataset.immArchive = "1";
      (document.head || document.documentElement).appendChild(script);
      script.onload = () => script.remove();
      script.onerror = () => {
        browser.runtime.sendMessage({
          type: "log-content-event",
          level: "warn",
          msg: "inline page-hook injection blocked (CSP); relying on MAIN-world content script",
          url: location.href
        }).catch(() => {
        });
      };
    } catch (err) {
      console.warn("[imm-archive] inline page-hook injection threw", err);
    }
  }
  fallbackInject();
  function normalizeHandle(raw) {
    if (!raw) return null;
    const cleaned = raw.trim().replace(/^@/, "").toLowerCase();
    return cleaned.length > 0 ? cleaned : null;
  }
  var STATUS_HOSTS = /* @__PURE__ */ new Set(["x.com", "twitter.com", "mobile.twitter.com"]);
  function parseTweetUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const parts = u.pathname.split("/").filter(Boolean);
      const statusIdx = parts.indexOf("status");
      if (statusIdx <= 0) return null;
      const handle = normalizeHandle(parts[statusIdx - 1] ?? null);
      const id = parts[statusIdx + 1] ?? null;
      if (!handle || !id || !/^\d+$/.test(id)) return null;
      return { handle, id };
    } catch {
      return null;
    }
  }
  function parseHandleUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const first = u.pathname.split("/").filter(Boolean)[0];
      if (!first || first === "i" || first === "intent" || first === "search") return null;
      return normalizeHandle(first);
    } catch {
      return null;
    }
  }
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none";
  }
  function nearestTweetContainer(el) {
    return el.closest("article") ?? el.closest('div[data-testid="cellInnerDiv"]');
  }
  function isReplyToCore(container) {
    const text = (container.textContent || "").toLowerCase();
    if (!text.includes("replying to")) return false;
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const handle = parseHandleUrl(link.getAttribute("href"));
      if (handle && unfoldCoreHandles.has(handle)) return true;
    }
    return false;
  }
  function isCoreRelevant(container) {
    for (const link of Array.from(container.querySelectorAll("a[href]"))) {
      const tweet = parseTweetUrl(link.getAttribute("href"));
      if (!tweet) continue;
      if (unfoldCoreHandles.has(tweet.handle)) return true;
      if (unfoldRelevantTweetIds.has(tweet.id)) return true;
    }
    return isReplyToCore(container);
  }
  function scanAndUnfoldShowMore() {
    unfoldScanTimer = null;
    if (!unfoldEnabled || unfoldCoreHandles.size === 0) return;
    const selectors = [
      '[data-testid="tweet-text-show-more-link"]',
      'button[data-testid="tweet-text-show-more-link"]',
      'article [role="button"][tabindex="0"]',
      'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
    ];
    const seen = /* @__PURE__ */ new Set();
    let clicked = 0;
    for (const sel of selectors) {
      for (const el of Array.from(document.querySelectorAll(sel))) {
        if (seen.has(el) || unfoldedControls.has(el)) continue;
        seen.add(el);
        if ((el.textContent || "").trim().toLowerCase() !== "show more") continue;
        if (!isVisible(el)) continue;
        const container = nearestTweetContainer(el);
        if (!container || !isCoreRelevant(container)) continue;
        unfoldedControls.add(el);
        try {
          el.click();
          clicked += 1;
        } catch {
        }
      }
    }
    if (clicked > 0) {
      browser.runtime.sendMessage({ type: "show-more-unfolded", count: clicked }).catch(() => {
      });
    }
  }
  function scheduleUnfoldScan(delay = UNFOLD_SCAN_DEBOUNCE_MS) {
    if (unfoldScanTimer !== null) return;
    unfoldScanTimer = setTimeout(scanAndUnfoldShowMore, delay);
  }
  async function refreshUnfoldTargets() {
    try {
      const response = await browser.runtime.sendMessage({
        type: "get-unfold-targets"
      });
      const raw = response && typeof response === "object" ? response : {};
      unfoldEnabled = raw.enabled !== false;
      unfoldCoreHandles = new Set(
        (raw.coreHandles ?? []).map((h) => h.toLowerCase().replace(/^@/, ""))
      );
      unfoldRelevantTweetIds = new Set(raw.relevantTweetIds ?? []);
      scheduleUnfoldScan(0);
    } catch {
      unfoldEnabled = false;
    }
  }
  function installUnfoldObserver() {
    const root = document.documentElement || document.body;
    if (!root) {
      setTimeout(installUnfoldObserver, 100);
      return;
    }
    const observer = new MutationObserver(() => scheduleUnfoldScan());
    observer.observe(root, { childList: true, subtree: true });
    window.addEventListener("scroll", () => scheduleUnfoldScan(), { passive: true });
    void refreshUnfoldTargets();
    setInterval(() => {
      void refreshUnfoldTargets();
    }, UNFOLD_SYNC_MS);
  }
  installUnfoldObserver();
  function lowBandwidthSettingFrom(raw) {
    if (!raw || typeof raw !== "object") return false;
    return raw.lowBandwidthBrowsing === true;
  }
  function isScrubbableMedia(el) {
    return el instanceof HTMLVideoElement || el instanceof HTMLAudioElement;
  }
  function scrubMediaElement(el) {
    try {
      el.pause();
    } catch {
    }
    try {
      el.autoplay = false;
      el.preload = "none";
      el.removeAttribute("autoplay");
      el.removeAttribute("src");
      el.src = "";
      if ("srcObject" in el) el.srcObject = null;
      for (const source of Array.from(el.querySelectorAll("source[src]"))) {
        source.removeAttribute("src");
      }
      el.load();
    } catch {
    }
  }
  function scanLowBandwidthMedia() {
    lowBandwidthScanTimer = null;
    if (!lowBandwidthScrubberEnabled) return;
    for (const el of Array.from(document.querySelectorAll("video,audio"))) {
      if (isScrubbableMedia(el)) scrubMediaElement(el);
    }
  }
  function scheduleLowBandwidthScan(delay = LOW_BANDWIDTH_SCAN_DEBOUNCE_MS) {
    if (!lowBandwidthScrubberEnabled || lowBandwidthScanTimer !== null) return;
    lowBandwidthScanTimer = setTimeout(scanLowBandwidthMedia, delay);
  }
  function onLowBandwidthMediaEvent(event) {
    if (!lowBandwidthScrubberEnabled) return;
    if (isScrubbableMedia(event.target)) scrubMediaElement(event.target);
  }
  function setLowBandwidthScrubber(on) {
    if (lowBandwidthScrubberEnabled === on) return;
    lowBandwidthScrubberEnabled = on;
    if (on) {
      const root = document.documentElement || document.body;
      if (root) {
        lowBandwidthObserver = new MutationObserver(() => scheduleLowBandwidthScan());
        lowBandwidthObserver.observe(root, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["src"]
        });
      }
      for (const eventName of LOW_BANDWIDTH_MEDIA_EVENTS) {
        document.addEventListener(eventName, onLowBandwidthMediaEvent, true);
      }
      lowBandwidthRescanTimer = setInterval(scanLowBandwidthMedia, LOW_BANDWIDTH_RESCAN_MS);
      scheduleLowBandwidthScan(0);
      return;
    }
    if (lowBandwidthObserver) {
      lowBandwidthObserver.disconnect();
      lowBandwidthObserver = null;
    }
    if (lowBandwidthScanTimer !== null) {
      clearTimeout(lowBandwidthScanTimer);
      lowBandwidthScanTimer = null;
    }
    if (lowBandwidthRescanTimer !== null) {
      clearInterval(lowBandwidthRescanTimer);
      lowBandwidthRescanTimer = null;
    }
    for (const eventName of LOW_BANDWIDTH_MEDIA_EVENTS) {
      document.removeEventListener(eventName, onLowBandwidthMediaEvent, true);
    }
  }
  async function refreshLowBandwidthScrubber() {
    try {
      const result = await browser.storage.local.get("settings");
      setLowBandwidthScrubber(lowBandwidthSettingFrom(result.settings));
    } catch {
      setLowBandwidthScrubber(false);
    }
  }
  browser.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.settings) return;
    setLowBandwidthScrubber(lowBandwidthSettingFrom(changes.settings.newValue));
  });
  void refreshLowBandwidthScrubber();
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== "object") return;
    const d = data;
    if (d.source === READY) {
      browser.runtime.sendMessage({
        type: "page-hook-active",
        url: typeof d.url === "string" ? d.url : location.href
      }).catch(() => {
      });
      return;
    }
    if (d.source !== TARGET) return;
    const endpoint = typeof d.endpoint === "string" ? d.endpoint : null;
    const url = typeof d.url === "string" ? d.url : null;
    const pageUrl = typeof d.page_url === "string" ? d.page_url : location.href;
    const response = d.response;
    if (!endpoint || !url || response === void 0) return;
    browser.runtime.sendMessage({ type: "graphql-capture", endpoint, url, pageUrl, response }).catch((err) => {
      console.warn("[imm-archive] sendMessage failed", err);
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbnRlbnQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKlxyXG4gKiBjb250ZW50LnRzIFx1MjAxNCBjb250ZW50LXNjcmlwdCBjb250ZXh0IChpc29sYXRlZCB3b3JsZCkuXHJcbiAqXHJcbiAqIFRoZSBhY3R1YWwgcGFnZS1ob29rICh3aGljaCBwYXRjaGVzIGBmZXRjaGAgLyBgWEhSYCkgaXMgZGVjbGFyZWQgYXMgYVxyXG4gKiBzZXBhcmF0ZSBjb250ZW50IHNjcmlwdCB3aXRoIGB3b3JsZDogXCJNQUlOXCJgIGluIHRoZSBtYW5pZmVzdCwgc28gaXQgcnVuc1xyXG4gKiBpbiB0aGUgcGFnZSB3b3JsZCBkaXJlY3RseSB3aXRob3V0IHVzIGhhdmluZyB0byBpbmplY3QgYSA8c2NyaXB0PiB0YWcgXHUyMDE0XHJcbiAqIHdoaWNoIFgncyBub25jZS1iYXNlZCBDU1Agd291bGQgYmxvY2suXHJcbiAqXHJcbiAqIFRoaXMgZmlsZSBkb2VzIHRocmVlIHRoaW5nczpcclxuICpcclxuICogICAxLiBQaW5ncyB0aGUgYmFja2dyb3VuZCBvbiBsb2FkIHNvIHRoZSBhY3Rpdml0eSB0YWlsIGNvbmZpcm1zIHRoZVxyXG4gKiAgICAgIGNvbnRlbnQgc2NyaXB0IHJlYWNoZWQgdGhlIFggcGFnZSAodXNlZnVsIHdoZW4gZGlhZ25vc2luZyBhIHNpbGVudFxyXG4gKiAgICAgIFwiY2FwdHVyZS1ub3cgZG9lcyBub3RoaW5nXCIgZmFpbHVyZSkuXHJcbiAqICAgMi4gQXMgYSBkZWZlbnNpdmUgZmFsbGJhY2ssIGFsc28gdHJpZXMgdG8gaW5qZWN0IGBwYWdlLWhvb2suanNgIHZpYSBhXHJcbiAqICAgICAgc2NyaXB0IHRhZy4gSGFybWxlc3Mgb24gbW9kZXJuIEZpcmVmb3ggKHRoZSBwYWdlLWhvb2sncyBUQUcgZ3VhcmRcclxuICogICAgICBwcmV2ZW50cyBkb3VibGUtaW5pdCk7IGNvdmVycyB0aGUgcmFyZSBjYXNlIHdoZXJlIHRoZSBNQUlOLXdvcmxkXHJcbiAqICAgICAgY29udGVudCBzY3JpcHQgZW50cnkgaXNuJ3QgaG9ub3JlZC5cclxuICogICAzLiBCcmlkZ2VzIGB3aW5kb3cucG9zdE1lc3NhZ2VgIGZyb20gdGhlIHBhZ2UgaG9vayB0byB0aGUgYmFja2dyb3VuZDpcclxuICogICAgICBib3RoIHRoZSBgKl9SRUFEWWAgYm9vdCBwaW5nIGFuZCB0aGUgYElNTV9BUkNISVZFX0NBUFRVUkVgIHBheWxvYWRcclxuICogICAgICBldmVudHMuXHJcbiAqL1xyXG5cclxuY29uc3QgVEFSR0VUID0gJ0lNTV9BUkNISVZFX0NBUFRVUkUnO1xuY29uc3QgUkVBRFkgPSAnSU1NX0FSQ0hJVkVfSE9PS19SRUFEWSc7XG5jb25zdCBVTkZPTERfU1lOQ19NUyA9IDJfMDAwO1xuY29uc3QgVU5GT0xEX1NDQU5fREVCT1VOQ0VfTVMgPSAyNTA7XG5jb25zdCBMT1dfQkFORFdJRFRIX1NDQU5fREVCT1VOQ0VfTVMgPSAxMDA7XG5jb25zdCBMT1dfQkFORFdJRFRIX1JFU0NBTl9NUyA9IDFfNTAwO1xuY29uc3QgTE9XX0JBTkRXSURUSF9NRURJQV9FVkVOVFMgPSBbJ2xvYWRzdGFydCcsICdsb2FkZWRtZXRhZGF0YScsICdwbGF5JywgJ3BsYXlpbmcnXSBhcyBjb25zdDtcblxyXG5pbnRlcmZhY2UgVW5mb2xkVGFyZ2V0c1Jlc3BvbnNlIHtcclxuICBlbmFibGVkPzogYm9vbGVhbjtcclxuICBjb3JlSGFuZGxlcz86IHN0cmluZ1tdO1xyXG4gIHJlbGV2YW50VHdlZXRJZHM/OiBzdHJpbmdbXTtcclxufVxyXG5cclxubGV0IHVuZm9sZEVuYWJsZWQgPSBmYWxzZTtcclxubGV0IHVuZm9sZENvcmVIYW5kbGVzID0gbmV3IFNldDxzdHJpbmc+KCk7XHJcbmxldCB1bmZvbGRSZWxldmFudFR3ZWV0SWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG5sZXQgdW5mb2xkU2NhblRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IG51bGwgPSBudWxsO1xuY29uc3QgdW5mb2xkZWRDb250cm9scyA9IG5ldyBXZWFrU2V0PEVsZW1lbnQ+KCk7XG5sZXQgbG93QmFuZHdpZHRoU2NydWJiZXJFbmFibGVkID0gZmFsc2U7XG5sZXQgbG93QmFuZHdpZHRoT2JzZXJ2ZXI6IE11dGF0aW9uT2JzZXJ2ZXIgfCBudWxsID0gbnVsbDtcbmxldCBsb3dCYW5kd2lkdGhTY2FuVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbCA9IG51bGw7XG5sZXQgbG93QmFuZHdpZHRoUmVzY2FuVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuXHJcbnZvaWQgYnJvd3Nlci5ydW50aW1lXHJcbiAgLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2NvbnRlbnQtYWxpdmUnLCB1cmw6IGxvY2F0aW9uLmhyZWYgfSlcclxuICAuY2F0Y2goKGVycjogdW5rbm93bikgPT4ge1xyXG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGNvbnRlbnQtYWxpdmUgcGluZyBmYWlsZWQnLCBlcnIpO1xyXG4gIH0pO1xyXG5cclxuZnVuY3Rpb24gZmFsbGJhY2tJbmplY3QoKTogdm9pZCB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHNyYyA9IGJyb3dzZXIucnVudGltZS5nZXRVUkwoJ3BhZ2UtaG9vay5qcycpO1xyXG4gICAgY29uc3Qgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XHJcbiAgICBzY3JpcHQuc3JjID0gc3JjO1xyXG4gICAgc2NyaXB0LmFzeW5jID0gZmFsc2U7XHJcbiAgICBzY3JpcHQuZGF0YXNldC5pbW1BcmNoaXZlID0gJzEnO1xyXG4gICAgKGRvY3VtZW50LmhlYWQgfHwgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS5hcHBlbmRDaGlsZChzY3JpcHQpO1xyXG4gICAgc2NyaXB0Lm9ubG9hZCA9ICgpID0+IHNjcmlwdC5yZW1vdmUoKTtcclxuICAgIHNjcmlwdC5vbmVycm9yID0gKCkgPT4ge1xyXG4gICAgICAvLyBDU1AgcHJvYmFibHkgYmxvY2tlZCB0aGlzLiBOb3QgZmF0YWwgXHUyMDE0IHRoZSBNQUlOLXdvcmxkIGNvbnRlbnQgc2NyaXB0XHJcbiAgICAgIC8vIGRlY2xhcmVkIGluIG1hbmlmZXN0Lmpzb24gaXMgdGhlIHByaW1hcnkgcGF0aC4gU3VyZmFjZSBhcyBhIGxvZyBzb1xyXG4gICAgICAvLyB3ZSBrbm93IHdoYXQgaGFwcGVuZWQgd2l0aG91dCBseWluZyBhYm91dCBzdWNjZXNzLlxyXG4gICAgICBicm93c2VyLnJ1bnRpbWVcclxuICAgICAgICAuc2VuZE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgdHlwZTogJ2xvZy1jb250ZW50LWV2ZW50JyxcclxuICAgICAgICAgIGxldmVsOiAnd2FybicsXHJcbiAgICAgICAgICBtc2c6ICdpbmxpbmUgcGFnZS1ob29rIGluamVjdGlvbiBibG9ja2VkIChDU1ApOyByZWx5aW5nIG9uIE1BSU4td29ybGQgY29udGVudCBzY3JpcHQnLFxyXG4gICAgICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmLFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLmNhdGNoKCgpID0+IHt9KTtcclxuICAgIH07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLndhcm4oJ1tpbW0tYXJjaGl2ZV0gaW5saW5lIHBhZ2UtaG9vayBpbmplY3Rpb24gdGhyZXcnLCBlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZmFsbGJhY2tJbmplY3QoKTtcclxuXHJcbmZ1bmN0aW9uIG5vcm1hbGl6ZUhhbmRsZShyYXc6IHN0cmluZyB8IG51bGwpOiBzdHJpbmcgfCBudWxsIHtcclxuICBpZiAoIXJhdykgcmV0dXJuIG51bGw7XHJcbiAgY29uc3QgY2xlYW5lZCA9IHJhdy50cmltKCkucmVwbGFjZSgvXkAvLCAnJykudG9Mb3dlckNhc2UoKTtcclxuICByZXR1cm4gY2xlYW5lZC5sZW5ndGggPiAwID8gY2xlYW5lZCA6IG51bGw7XHJcbn1cclxuXHJcbmNvbnN0IFNUQVRVU19IT1NUUyA9IG5ldyBTZXQoWyd4LmNvbScsICd0d2l0dGVyLmNvbScsICdtb2JpbGUudHdpdHRlci5jb20nXSk7XHJcblxyXG5mdW5jdGlvbiBwYXJzZVR3ZWV0VXJsKGhyZWY6IHN0cmluZyB8IG51bGwpOiB7IGhhbmRsZTogc3RyaW5nOyBpZDogc3RyaW5nIH0gfCBudWxsIHtcclxuICBpZiAoIWhyZWYpIHJldHVybiBudWxsO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCB1ID0gbmV3IFVSTChocmVmLCBsb2NhdGlvbi5ocmVmKTtcclxuICAgIGlmICghU1RBVFVTX0hPU1RTLmhhcyh1Lmhvc3RuYW1lLnRvTG93ZXJDYXNlKCkpKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IHBhcnRzID0gdS5wYXRobmFtZS5zcGxpdCgnLycpLmZpbHRlcihCb29sZWFuKTtcclxuICAgIGNvbnN0IHN0YXR1c0lkeCA9IHBhcnRzLmluZGV4T2YoJ3N0YXR1cycpO1xyXG4gICAgaWYgKHN0YXR1c0lkeCA8PSAwKSByZXR1cm4gbnVsbDtcclxuICAgIGNvbnN0IGhhbmRsZSA9IG5vcm1hbGl6ZUhhbmRsZShwYXJ0c1tzdGF0dXNJZHggLSAxXSA/PyBudWxsKTtcclxuICAgIGNvbnN0IGlkID0gcGFydHNbc3RhdHVzSWR4ICsgMV0gPz8gbnVsbDtcclxuICAgIGlmICghaGFuZGxlIHx8ICFpZCB8fCAhL15cXGQrJC8udGVzdChpZCkpIHJldHVybiBudWxsO1xyXG4gICAgcmV0dXJuIHsgaGFuZGxlLCBpZCB9O1xyXG4gIH0gY2F0Y2gge1xyXG4gICAgcmV0dXJuIG51bGw7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBwYXJzZUhhbmRsZVVybChocmVmOiBzdHJpbmcgfCBudWxsKTogc3RyaW5nIHwgbnVsbCB7XHJcbiAgaWYgKCFocmVmKSByZXR1cm4gbnVsbDtcclxuICB0cnkge1xyXG4gICAgY29uc3QgdSA9IG5ldyBVUkwoaHJlZiwgbG9jYXRpb24uaHJlZik7XHJcbiAgICBpZiAoIVNUQVRVU19IT1NUUy5oYXModS5ob3N0bmFtZS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIG51bGw7XHJcbiAgICBjb25zdCBmaXJzdCA9IHUucGF0aG5hbWUuc3BsaXQoJy8nKS5maWx0ZXIoQm9vbGVhbilbMF07XHJcbiAgICBpZiAoIWZpcnN0IHx8IGZpcnN0ID09PSAnaScgfHwgZmlyc3QgPT09ICdpbnRlbnQnIHx8IGZpcnN0ID09PSAnc2VhcmNoJykgcmV0dXJuIG51bGw7XHJcbiAgICByZXR1cm4gbm9ybWFsaXplSGFuZGxlKGZpcnN0KTtcclxuICB9IGNhdGNoIHtcclxuICAgIHJldHVybiBudWxsO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gaXNWaXNpYmxlKGVsOiBFbGVtZW50KTogYm9vbGVhbiB7XHJcbiAgY29uc3QgcmVjdCA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xyXG4gIGlmIChyZWN0LndpZHRoID09PSAwIHx8IHJlY3QuaGVpZ2h0ID09PSAwKSByZXR1cm4gZmFsc2U7XHJcbiAgY29uc3Qgc3R5bGUgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbCk7XHJcbiAgcmV0dXJuIHN0eWxlLnZpc2liaWxpdHkgIT09ICdoaWRkZW4nICYmIHN0eWxlLmRpc3BsYXkgIT09ICdub25lJztcclxufVxyXG5cclxuZnVuY3Rpb24gbmVhcmVzdFR3ZWV0Q29udGFpbmVyKGVsOiBFbGVtZW50KTogRWxlbWVudCB8IG51bGwge1xyXG4gIHJldHVybiBlbC5jbG9zZXN0KCdhcnRpY2xlJykgPz8gZWwuY2xvc2VzdCgnZGl2W2RhdGEtdGVzdGlkPVwiY2VsbElubmVyRGl2XCJdJyk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGlzUmVwbHlUb0NvcmUoY29udGFpbmVyOiBFbGVtZW50KTogYm9vbGVhbiB7XHJcbiAgY29uc3QgdGV4dCA9IChjb250YWluZXIudGV4dENvbnRlbnQgfHwgJycpLnRvTG93ZXJDYXNlKCk7XHJcbiAgaWYgKCF0ZXh0LmluY2x1ZGVzKCdyZXBseWluZyB0bycpKSByZXR1cm4gZmFsc2U7XHJcbiAgZm9yIChjb25zdCBsaW5rIG9mIEFycmF5LmZyb20oY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJ2FbaHJlZl0nKSkpIHtcclxuICAgIGNvbnN0IGhhbmRsZSA9IHBhcnNlSGFuZGxlVXJsKGxpbmsuZ2V0QXR0cmlidXRlKCdocmVmJykpO1xyXG4gICAgaWYgKGhhbmRsZSAmJiB1bmZvbGRDb3JlSGFuZGxlcy5oYXMoaGFuZGxlKSkgcmV0dXJuIHRydWU7XHJcbiAgfVxyXG4gIHJldHVybiBmYWxzZTtcclxufVxyXG5cclxuZnVuY3Rpb24gaXNDb3JlUmVsZXZhbnQoY29udGFpbmVyOiBFbGVtZW50KTogYm9vbGVhbiB7XHJcbiAgZm9yIChjb25zdCBsaW5rIG9mIEFycmF5LmZyb20oY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJ2FbaHJlZl0nKSkpIHtcclxuICAgIGNvbnN0IHR3ZWV0ID0gcGFyc2VUd2VldFVybChsaW5rLmdldEF0dHJpYnV0ZSgnaHJlZicpKTtcclxuICAgIGlmICghdHdlZXQpIGNvbnRpbnVlO1xyXG4gICAgaWYgKHVuZm9sZENvcmVIYW5kbGVzLmhhcyh0d2VldC5oYW5kbGUpKSByZXR1cm4gdHJ1ZTtcclxuICAgIGlmICh1bmZvbGRSZWxldmFudFR3ZWV0SWRzLmhhcyh0d2VldC5pZCkpIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICByZXR1cm4gaXNSZXBseVRvQ29yZShjb250YWluZXIpO1xyXG59XHJcblxyXG5mdW5jdGlvbiBzY2FuQW5kVW5mb2xkU2hvd01vcmUoKTogdm9pZCB7XHJcbiAgdW5mb2xkU2NhblRpbWVyID0gbnVsbDtcclxuICBpZiAoIXVuZm9sZEVuYWJsZWQgfHwgdW5mb2xkQ29yZUhhbmRsZXMuc2l6ZSA9PT0gMCkgcmV0dXJuO1xyXG4gIGNvbnN0IHNlbGVjdG9ycyA9IFtcclxuICAgICdbZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcclxuICAgICdidXR0b25bZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcclxuICAgICdhcnRpY2xlIFtyb2xlPVwiYnV0dG9uXCJdW3RhYmluZGV4PVwiMFwiXScsXHJcbiAgICAnZGl2W2RhdGEtdGVzdGlkPVwiY2VsbElubmVyRGl2XCJdIFtyb2xlPVwiYnV0dG9uXCJdW3RhYmluZGV4PVwiMFwiXScsXHJcbiAgXTtcclxuICBjb25zdCBzZWVuID0gbmV3IFNldDxFbGVtZW50PigpO1xyXG4gIGxldCBjbGlja2VkID0gMDtcclxuICBmb3IgKGNvbnN0IHNlbCBvZiBzZWxlY3RvcnMpIHtcclxuICAgIGZvciAoY29uc3QgZWwgb2YgQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbCkpKSB7XHJcbiAgICAgIGlmIChzZWVuLmhhcyhlbCkgfHwgdW5mb2xkZWRDb250cm9scy5oYXMoZWwpKSBjb250aW51ZTtcclxuICAgICAgc2Vlbi5hZGQoZWwpO1xyXG4gICAgICBpZiAoKGVsLnRleHRDb250ZW50IHx8ICcnKS50cmltKCkudG9Mb3dlckNhc2UoKSAhPT0gJ3Nob3cgbW9yZScpIGNvbnRpbnVlO1xyXG4gICAgICBpZiAoIWlzVmlzaWJsZShlbCkpIGNvbnRpbnVlO1xyXG4gICAgICBjb25zdCBjb250YWluZXIgPSBuZWFyZXN0VHdlZXRDb250YWluZXIoZWwpO1xyXG4gICAgICBpZiAoIWNvbnRhaW5lciB8fCAhaXNDb3JlUmVsZXZhbnQoY29udGFpbmVyKSkgY29udGludWU7XHJcbiAgICAgIHVuZm9sZGVkQ29udHJvbHMuYWRkKGVsKTtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAoZWwgYXMgSFRNTEVsZW1lbnQpLmNsaWNrKCk7XHJcbiAgICAgICAgY2xpY2tlZCArPSAxO1xyXG4gICAgICB9IGNhdGNoIHtcclxuICAgICAgICAvLyBJZ25vcmUgc3RhbGUgb3Igc3ludGhldGljIGNvbnRyb2xzLlxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIGlmIChjbGlja2VkID4gMCkge1xyXG4gICAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ3Nob3ctbW9yZS11bmZvbGRlZCcsIGNvdW50OiBjbGlja2VkIH0pLmNhdGNoKCgpID0+IHt9KTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNjaGVkdWxlVW5mb2xkU2NhbihkZWxheSA9IFVORk9MRF9TQ0FOX0RFQk9VTkNFX01TKTogdm9pZCB7XHJcbiAgaWYgKHVuZm9sZFNjYW5UaW1lciAhPT0gbnVsbCkgcmV0dXJuO1xyXG4gIHVuZm9sZFNjYW5UaW1lciA9IHNldFRpbWVvdXQoc2NhbkFuZFVuZm9sZFNob3dNb3JlLCBkZWxheSk7XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hVbmZvbGRUYXJnZXRzKCk6IFByb21pc2U8dm9pZD4ge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGJyb3dzZXIucnVudGltZS5zZW5kTWVzc2FnZSh7XHJcbiAgICAgIHR5cGU6ICdnZXQtdW5mb2xkLXRhcmdldHMnLFxyXG4gICAgfSk7XHJcbiAgICBjb25zdCByYXcgPSByZXNwb25zZSAmJiB0eXBlb2YgcmVzcG9uc2UgPT09ICdvYmplY3QnID8gKHJlc3BvbnNlIGFzIFVuZm9sZFRhcmdldHNSZXNwb25zZSkgOiB7fTtcclxuICAgIHVuZm9sZEVuYWJsZWQgPSByYXcuZW5hYmxlZCAhPT0gZmFsc2U7XHJcbiAgICB1bmZvbGRDb3JlSGFuZGxlcyA9IG5ldyBTZXQoXHJcbiAgICAgIChyYXcuY29yZUhhbmRsZXMgPz8gW10pLm1hcCgoaCkgPT4gaC50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL15ALywgJycpKVxyXG4gICAgKTtcclxuICAgIHVuZm9sZFJlbGV2YW50VHdlZXRJZHMgPSBuZXcgU2V0KHJhdy5yZWxldmFudFR3ZWV0SWRzID8/IFtdKTtcclxuICAgIHNjaGVkdWxlVW5mb2xkU2NhbigwKTtcclxuICB9IGNhdGNoIHtcclxuICAgIHVuZm9sZEVuYWJsZWQgPSBmYWxzZTtcclxuICB9XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGluc3RhbGxVbmZvbGRPYnNlcnZlcigpOiB2b2lkIHtcclxuICBjb25zdCByb290ID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50IHx8IGRvY3VtZW50LmJvZHk7XHJcbiAgaWYgKCFyb290KSB7XHJcbiAgICBzZXRUaW1lb3V0KGluc3RhbGxVbmZvbGRPYnNlcnZlciwgMTAwKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigoKSA9PiBzY2hlZHVsZVVuZm9sZFNjYW4oKSk7XHJcbiAgb2JzZXJ2ZXIub2JzZXJ2ZShyb290LCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcclxuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgKCkgPT4gc2NoZWR1bGVVbmZvbGRTY2FuKCksIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcclxuICB2b2lkIHJlZnJlc2hVbmZvbGRUYXJnZXRzKCk7XHJcbiAgc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgdm9pZCByZWZyZXNoVW5mb2xkVGFyZ2V0cygpO1xyXG4gIH0sIFVORk9MRF9TWU5DX01TKTtcclxufVxyXG5cclxuaW5zdGFsbFVuZm9sZE9ic2VydmVyKCk7XG5cbmZ1bmN0aW9uIGxvd0JhbmR3aWR0aFNldHRpbmdGcm9tKHJhdzogdW5rbm93bik6IGJvb2xlYW4ge1xuICBpZiAoIXJhdyB8fCB0eXBlb2YgcmF3ICE9PSAnb2JqZWN0JykgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gKHJhdyBhcyB7IGxvd0JhbmR3aWR0aEJyb3dzaW5nPzogdW5rbm93biB9KS5sb3dCYW5kd2lkdGhCcm93c2luZyA9PT0gdHJ1ZTtcbn1cblxuZnVuY3Rpb24gaXNTY3J1YmJhYmxlTWVkaWEoZWw6IEV2ZW50VGFyZ2V0IHwgRWxlbWVudCB8IG51bGwpOiBlbCBpcyBIVE1MTWVkaWFFbGVtZW50IHtcbiAgcmV0dXJuIGVsIGluc3RhbmNlb2YgSFRNTFZpZGVvRWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxBdWRpb0VsZW1lbnQ7XG59XG5cbmZ1bmN0aW9uIHNjcnViTWVkaWFFbGVtZW50KGVsOiBIVE1MTWVkaWFFbGVtZW50KTogdm9pZCB7XG4gIHRyeSB7XG4gICAgZWwucGF1c2UoKTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gSWdub3JlIHN0YWxlIG1lZGlhIG5vZGVzLlxuICB9XG4gIHRyeSB7XG4gICAgZWwuYXV0b3BsYXkgPSBmYWxzZTtcbiAgICBlbC5wcmVsb2FkID0gJ25vbmUnO1xuICAgIGVsLnJlbW92ZUF0dHJpYnV0ZSgnYXV0b3BsYXknKTtcbiAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoJ3NyYycpO1xuICAgIGVsLnNyYyA9ICcnO1xuICAgIGlmICgnc3JjT2JqZWN0JyBpbiBlbCkgZWwuc3JjT2JqZWN0ID0gbnVsbDtcbiAgICBmb3IgKGNvbnN0IHNvdXJjZSBvZiBBcnJheS5mcm9tKGVsLnF1ZXJ5U2VsZWN0b3JBbGwoJ3NvdXJjZVtzcmNdJykpKSB7XG4gICAgICBzb3VyY2UucmVtb3ZlQXR0cmlidXRlKCdzcmMnKTtcbiAgICB9XG4gICAgZWwubG9hZCgpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBYIGNhbiByZXBsYWNlIG5vZGVzIGR1cmluZyBzY3JvbGw7IGJlc3QtZWZmb3J0IHNjcnViYmluZyBpcyBlbm91Z2guXG4gIH1cbn1cblxuZnVuY3Rpb24gc2Nhbkxvd0JhbmR3aWR0aE1lZGlhKCk6IHZvaWQge1xuICBsb3dCYW5kd2lkdGhTY2FuVGltZXIgPSBudWxsO1xuICBpZiAoIWxvd0JhbmR3aWR0aFNjcnViYmVyRW5hYmxlZCkgcmV0dXJuO1xuICBmb3IgKGNvbnN0IGVsIG9mIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgndmlkZW8sYXVkaW8nKSkpIHtcbiAgICBpZiAoaXNTY3J1YmJhYmxlTWVkaWEoZWwpKSBzY3J1Yk1lZGlhRWxlbWVudChlbCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc2NoZWR1bGVMb3dCYW5kd2lkdGhTY2FuKGRlbGF5ID0gTE9XX0JBTkRXSURUSF9TQ0FOX0RFQk9VTkNFX01TKTogdm9pZCB7XG4gIGlmICghbG93QmFuZHdpZHRoU2NydWJiZXJFbmFibGVkIHx8IGxvd0JhbmR3aWR0aFNjYW5UaW1lciAhPT0gbnVsbCkgcmV0dXJuO1xuICBsb3dCYW5kd2lkdGhTY2FuVGltZXIgPSBzZXRUaW1lb3V0KHNjYW5Mb3dCYW5kd2lkdGhNZWRpYSwgZGVsYXkpO1xufVxuXG5mdW5jdGlvbiBvbkxvd0JhbmR3aWR0aE1lZGlhRXZlbnQoZXZlbnQ6IEV2ZW50KTogdm9pZCB7XG4gIGlmICghbG93QmFuZHdpZHRoU2NydWJiZXJFbmFibGVkKSByZXR1cm47XG4gIGlmIChpc1NjcnViYmFibGVNZWRpYShldmVudC50YXJnZXQpKSBzY3J1Yk1lZGlhRWxlbWVudChldmVudC50YXJnZXQpO1xufVxuXG5mdW5jdGlvbiBzZXRMb3dCYW5kd2lkdGhTY3J1YmJlcihvbjogYm9vbGVhbik6IHZvaWQge1xuICBpZiAobG93QmFuZHdpZHRoU2NydWJiZXJFbmFibGVkID09PSBvbikgcmV0dXJuO1xuICBsb3dCYW5kd2lkdGhTY3J1YmJlckVuYWJsZWQgPSBvbjtcblxuICBpZiAob24pIHtcbiAgICBjb25zdCByb290ID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50IHx8IGRvY3VtZW50LmJvZHk7XG4gICAgaWYgKHJvb3QpIHtcbiAgICAgIGxvd0JhbmR3aWR0aE9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4gc2NoZWR1bGVMb3dCYW5kd2lkdGhTY2FuKCkpO1xuICAgICAgbG93QmFuZHdpZHRoT2JzZXJ2ZXIub2JzZXJ2ZShyb290LCB7XG4gICAgICAgIGNoaWxkTGlzdDogdHJ1ZSxcbiAgICAgICAgc3VidHJlZTogdHJ1ZSxcbiAgICAgICAgYXR0cmlidXRlczogdHJ1ZSxcbiAgICAgICAgYXR0cmlidXRlRmlsdGVyOiBbJ3NyYyddLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgZXZlbnROYW1lIG9mIExPV19CQU5EV0lEVEhfTUVESUFfRVZFTlRTKSB7XG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwgb25Mb3dCYW5kd2lkdGhNZWRpYUV2ZW50LCB0cnVlKTtcbiAgICB9XG4gICAgbG93QmFuZHdpZHRoUmVzY2FuVGltZXIgPSBzZXRJbnRlcnZhbChzY2FuTG93QmFuZHdpZHRoTWVkaWEsIExPV19CQU5EV0lEVEhfUkVTQ0FOX01TKTtcbiAgICBzY2hlZHVsZUxvd0JhbmR3aWR0aFNjYW4oMCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGxvd0JhbmR3aWR0aE9ic2VydmVyKSB7XG4gICAgbG93QmFuZHdpZHRoT2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgIGxvd0JhbmR3aWR0aE9ic2VydmVyID0gbnVsbDtcbiAgfVxuICBpZiAobG93QmFuZHdpZHRoU2NhblRpbWVyICE9PSBudWxsKSB7XG4gICAgY2xlYXJUaW1lb3V0KGxvd0JhbmR3aWR0aFNjYW5UaW1lcik7XG4gICAgbG93QmFuZHdpZHRoU2NhblRpbWVyID0gbnVsbDtcbiAgfVxuICBpZiAobG93QmFuZHdpZHRoUmVzY2FuVGltZXIgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKGxvd0JhbmR3aWR0aFJlc2NhblRpbWVyKTtcbiAgICBsb3dCYW5kd2lkdGhSZXNjYW5UaW1lciA9IG51bGw7XG4gIH1cbiAgZm9yIChjb25zdCBldmVudE5hbWUgb2YgTE9XX0JBTkRXSURUSF9NRURJQV9FVkVOVFMpIHtcbiAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwgb25Mb3dCYW5kd2lkdGhNZWRpYUV2ZW50LCB0cnVlKTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoTG93QmFuZHdpZHRoU2NydWJiZXIoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldCgnc2V0dGluZ3MnKTtcbiAgICBzZXRMb3dCYW5kd2lkdGhTY3J1YmJlcihsb3dCYW5kd2lkdGhTZXR0aW5nRnJvbShyZXN1bHQuc2V0dGluZ3MpKTtcbiAgfSBjYXRjaCB7XG4gICAgc2V0TG93QmFuZHdpZHRoU2NydWJiZXIoZmFsc2UpO1xuICB9XG59XG5cbmJyb3dzZXIuc3RvcmFnZS5vbkNoYW5nZWQuYWRkTGlzdGVuZXIoKGNoYW5nZXMsIGFyZWFOYW1lKSA9PiB7XG4gIGlmIChhcmVhTmFtZSAhPT0gJ2xvY2FsJyB8fCAhY2hhbmdlcy5zZXR0aW5ncykgcmV0dXJuO1xuICBzZXRMb3dCYW5kd2lkdGhTY3J1YmJlcihsb3dCYW5kd2lkdGhTZXR0aW5nRnJvbShjaGFuZ2VzLnNldHRpbmdzLm5ld1ZhbHVlKSk7XG59KTtcblxudm9pZCByZWZyZXNoTG93QmFuZHdpZHRoU2NydWJiZXIoKTtcblxud2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCAoZXZlbnQ6IE1lc3NhZ2VFdmVudCkgPT4ge1xuICBpZiAoZXZlbnQuc291cmNlICE9PSB3aW5kb3cpIHJldHVybjtcclxuICBjb25zdCBkYXRhID0gZXZlbnQuZGF0YSBhcyB1bmtub3duO1xyXG4gIGlmICghZGF0YSB8fCB0eXBlb2YgZGF0YSAhPT0gJ29iamVjdCcpIHJldHVybjtcclxuICBjb25zdCBkID0gZGF0YSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcclxuXHJcbiAgaWYgKGQuc291cmNlID09PSBSRUFEWSkge1xyXG4gICAgYnJvd3Nlci5ydW50aW1lXHJcbiAgICAgIC5zZW5kTWVzc2FnZSh7XHJcbiAgICAgICAgdHlwZTogJ3BhZ2UtaG9vay1hY3RpdmUnLFxyXG4gICAgICAgIHVybDogdHlwZW9mIGQudXJsID09PSAnc3RyaW5nJyA/IGQudXJsIDogbG9jYXRpb24uaHJlZixcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKCgpID0+IHt9KTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIGlmIChkLnNvdXJjZSAhPT0gVEFSR0VUKSByZXR1cm47XHJcbiAgY29uc3QgZW5kcG9pbnQgPSB0eXBlb2YgZC5lbmRwb2ludCA9PT0gJ3N0cmluZycgPyBkLmVuZHBvaW50IDogbnVsbDtcclxuICBjb25zdCB1cmwgPSB0eXBlb2YgZC51cmwgPT09ICdzdHJpbmcnID8gZC51cmwgOiBudWxsO1xyXG4gIGNvbnN0IHBhZ2VVcmwgPSB0eXBlb2YgZC5wYWdlX3VybCA9PT0gJ3N0cmluZycgPyBkLnBhZ2VfdXJsIDogbG9jYXRpb24uaHJlZjtcclxuICBjb25zdCByZXNwb25zZSA9IGQucmVzcG9uc2U7XHJcbiAgaWYgKCFlbmRwb2ludCB8fCAhdXJsIHx8IHJlc3BvbnNlID09PSB1bmRlZmluZWQpIHJldHVybjtcclxuICBicm93c2VyLnJ1bnRpbWVcclxuICAgIC5zZW5kTWVzc2FnZSh7IHR5cGU6ICdncmFwaHFsLWNhcHR1cmUnLCBlbmRwb2ludCwgdXJsLCBwYWdlVXJsLCByZXNwb25zZSB9KVxyXG4gICAgLmNhdGNoKChlcnIpID0+IHtcclxuICAgICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNlbmRNZXNzYWdlIGZhaWxlZCcsIGVycik7XHJcbiAgICB9KTtcclxufSk7XHJcbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7QUFzQkEsTUFBTSxTQUFTO0FBQ2YsTUFBTSxRQUFRO0FBQ2QsTUFBTSxpQkFBaUI7QUFDdkIsTUFBTSwwQkFBMEI7QUFDaEMsTUFBTSxpQ0FBaUM7QUFDdkMsTUFBTSwwQkFBMEI7QUFDaEMsTUFBTSw2QkFBNkIsQ0FBQyxhQUFhLGtCQUFrQixRQUFRLFNBQVM7QUFRcEYsTUFBSSxnQkFBZ0I7QUFDcEIsTUFBSSxvQkFBb0Isb0JBQUksSUFBWTtBQUN4QyxNQUFJLHlCQUF5QixvQkFBSSxJQUFZO0FBQzdDLE1BQUksa0JBQXdEO0FBQzVELE1BQU0sbUJBQW1CLG9CQUFJLFFBQWlCO0FBQzlDLE1BQUksOEJBQThCO0FBQ2xDLE1BQUksdUJBQWdEO0FBQ3BELE1BQUksd0JBQThEO0FBQ2xFLE1BQUksMEJBQWlFO0FBRXJFLE9BQUssUUFBUSxRQUNWLFlBQVksRUFBRSxNQUFNLGlCQUFpQixLQUFLLFNBQVMsS0FBSyxDQUFDLEVBQ3pELE1BQU0sQ0FBQyxRQUFpQjtBQUN2QixZQUFRLEtBQUssMkNBQTJDLEdBQUc7QUFBQSxFQUM3RCxDQUFDO0FBRUgsV0FBUyxpQkFBdUI7QUFDOUIsUUFBSTtBQUNGLFlBQU0sTUFBTSxRQUFRLFFBQVEsT0FBTyxjQUFjO0FBQ2pELFlBQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtBQUM5QyxhQUFPLE1BQU07QUFDYixhQUFPLFFBQVE7QUFDZixhQUFPLFFBQVEsYUFBYTtBQUM1QixPQUFDLFNBQVMsUUFBUSxTQUFTLGlCQUFpQixZQUFZLE1BQU07QUFDOUQsYUFBTyxTQUFTLE1BQU0sT0FBTyxPQUFPO0FBQ3BDLGFBQU8sVUFBVSxNQUFNO0FBSXJCLGdCQUFRLFFBQ0wsWUFBWTtBQUFBLFVBQ1gsTUFBTTtBQUFBLFVBQ04sT0FBTztBQUFBLFVBQ1AsS0FBSztBQUFBLFVBQ0wsS0FBSyxTQUFTO0FBQUEsUUFDaEIsQ0FBQyxFQUNBLE1BQU0sTUFBTTtBQUFBLFFBQUMsQ0FBQztBQUFBLE1BQ25CO0FBQUEsSUFDRixTQUFTLEtBQUs7QUFDWixjQUFRLEtBQUssa0RBQWtELEdBQUc7QUFBQSxJQUNwRTtBQUFBLEVBQ0Y7QUFFQSxpQkFBZTtBQUVmLFdBQVMsZ0JBQWdCLEtBQW1DO0FBQzFELFFBQUksQ0FBQyxJQUFLLFFBQU87QUFDakIsVUFBTSxVQUFVLElBQUksS0FBSyxFQUFFLFFBQVEsTUFBTSxFQUFFLEVBQUUsWUFBWTtBQUN6RCxXQUFPLFFBQVEsU0FBUyxJQUFJLFVBQVU7QUFBQSxFQUN4QztBQUVBLE1BQU0sZUFBZSxvQkFBSSxJQUFJLENBQUMsU0FBUyxlQUFlLG9CQUFvQixDQUFDO0FBRTNFLFdBQVMsY0FBYyxNQUE0RDtBQUNqRixRQUFJLENBQUMsS0FBTSxRQUFPO0FBQ2xCLFFBQUk7QUFDRixZQUFNLElBQUksSUFBSSxJQUFJLE1BQU0sU0FBUyxJQUFJO0FBQ3JDLFVBQUksQ0FBQyxhQUFhLElBQUksRUFBRSxTQUFTLFlBQVksQ0FBQyxFQUFHLFFBQU87QUFDeEQsWUFBTSxRQUFRLEVBQUUsU0FBUyxNQUFNLEdBQUcsRUFBRSxPQUFPLE9BQU87QUFDbEQsWUFBTSxZQUFZLE1BQU0sUUFBUSxRQUFRO0FBQ3hDLFVBQUksYUFBYSxFQUFHLFFBQU87QUFDM0IsWUFBTSxTQUFTLGdCQUFnQixNQUFNLFlBQVksQ0FBQyxLQUFLLElBQUk7QUFDM0QsWUFBTSxLQUFLLE1BQU0sWUFBWSxDQUFDLEtBQUs7QUFDbkMsVUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLEVBQUUsRUFBRyxRQUFPO0FBQ2hELGFBQU8sRUFBRSxRQUFRLEdBQUc7QUFBQSxJQUN0QixRQUFRO0FBQ04sYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsV0FBUyxlQUFlLE1BQW9DO0FBQzFELFFBQUksQ0FBQyxLQUFNLFFBQU87QUFDbEIsUUFBSTtBQUNGLFlBQU0sSUFBSSxJQUFJLElBQUksTUFBTSxTQUFTLElBQUk7QUFDckMsVUFBSSxDQUFDLGFBQWEsSUFBSSxFQUFFLFNBQVMsWUFBWSxDQUFDLEVBQUcsUUFBTztBQUN4RCxZQUFNLFFBQVEsRUFBRSxTQUFTLE1BQU0sR0FBRyxFQUFFLE9BQU8sT0FBTyxFQUFFLENBQUM7QUFDckQsVUFBSSxDQUFDLFNBQVMsVUFBVSxPQUFPLFVBQVUsWUFBWSxVQUFVLFNBQVUsUUFBTztBQUNoRixhQUFPLGdCQUFnQixLQUFLO0FBQUEsSUFDOUIsUUFBUTtBQUNOLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFdBQVMsVUFBVSxJQUFzQjtBQUN2QyxVQUFNLE9BQU8sR0FBRyxzQkFBc0I7QUFDdEMsUUFBSSxLQUFLLFVBQVUsS0FBSyxLQUFLLFdBQVcsRUFBRyxRQUFPO0FBQ2xELFVBQU0sUUFBUSxPQUFPLGlCQUFpQixFQUFFO0FBQ3hDLFdBQU8sTUFBTSxlQUFlLFlBQVksTUFBTSxZQUFZO0FBQUEsRUFDNUQ7QUFFQSxXQUFTLHNCQUFzQixJQUE2QjtBQUMxRCxXQUFPLEdBQUcsUUFBUSxTQUFTLEtBQUssR0FBRyxRQUFRLGlDQUFpQztBQUFBLEVBQzlFO0FBRUEsV0FBUyxjQUFjLFdBQTZCO0FBQ2xELFVBQU0sUUFBUSxVQUFVLGVBQWUsSUFBSSxZQUFZO0FBQ3ZELFFBQUksQ0FBQyxLQUFLLFNBQVMsYUFBYSxFQUFHLFFBQU87QUFDMUMsZUFBVyxRQUFRLE1BQU0sS0FBSyxVQUFVLGlCQUFpQixTQUFTLENBQUMsR0FBRztBQUNwRSxZQUFNLFNBQVMsZUFBZSxLQUFLLGFBQWEsTUFBTSxDQUFDO0FBQ3ZELFVBQUksVUFBVSxrQkFBa0IsSUFBSSxNQUFNLEVBQUcsUUFBTztBQUFBLElBQ3REO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxXQUFTLGVBQWUsV0FBNkI7QUFDbkQsZUFBVyxRQUFRLE1BQU0sS0FBSyxVQUFVLGlCQUFpQixTQUFTLENBQUMsR0FBRztBQUNwRSxZQUFNLFFBQVEsY0FBYyxLQUFLLGFBQWEsTUFBTSxDQUFDO0FBQ3JELFVBQUksQ0FBQyxNQUFPO0FBQ1osVUFBSSxrQkFBa0IsSUFBSSxNQUFNLE1BQU0sRUFBRyxRQUFPO0FBQ2hELFVBQUksdUJBQXVCLElBQUksTUFBTSxFQUFFLEVBQUcsUUFBTztBQUFBLElBQ25EO0FBQ0EsV0FBTyxjQUFjLFNBQVM7QUFBQSxFQUNoQztBQUVBLFdBQVMsd0JBQThCO0FBQ3JDLHNCQUFrQjtBQUNsQixRQUFJLENBQUMsaUJBQWlCLGtCQUFrQixTQUFTLEVBQUc7QUFDcEQsVUFBTSxZQUFZO0FBQUEsTUFDaEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxPQUFPLG9CQUFJLElBQWE7QUFDOUIsUUFBSSxVQUFVO0FBQ2QsZUFBVyxPQUFPLFdBQVc7QUFDM0IsaUJBQVcsTUFBTSxNQUFNLEtBQUssU0FBUyxpQkFBaUIsR0FBRyxDQUFDLEdBQUc7QUFDM0QsWUFBSSxLQUFLLElBQUksRUFBRSxLQUFLLGlCQUFpQixJQUFJLEVBQUUsRUFBRztBQUM5QyxhQUFLLElBQUksRUFBRTtBQUNYLGFBQUssR0FBRyxlQUFlLElBQUksS0FBSyxFQUFFLFlBQVksTUFBTSxZQUFhO0FBQ2pFLFlBQUksQ0FBQyxVQUFVLEVBQUUsRUFBRztBQUNwQixjQUFNLFlBQVksc0JBQXNCLEVBQUU7QUFDMUMsWUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLFNBQVMsRUFBRztBQUM5Qyx5QkFBaUIsSUFBSSxFQUFFO0FBQ3ZCLFlBQUk7QUFDRixVQUFDLEdBQW1CLE1BQU07QUFDMUIscUJBQVc7QUFBQSxRQUNiLFFBQVE7QUFBQSxRQUVSO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxRQUFJLFVBQVUsR0FBRztBQUNmLGNBQVEsUUFBUSxZQUFZLEVBQUUsTUFBTSxzQkFBc0IsT0FBTyxRQUFRLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxNQUFDLENBQUM7QUFBQSxJQUM1RjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLG1CQUFtQixRQUFRLHlCQUErQjtBQUNqRSxRQUFJLG9CQUFvQixLQUFNO0FBQzlCLHNCQUFrQixXQUFXLHVCQUF1QixLQUFLO0FBQUEsRUFDM0Q7QUFFQSxpQkFBZSx1QkFBc0M7QUFDbkQsUUFBSTtBQUNGLFlBQU0sV0FBVyxNQUFNLFFBQVEsUUFBUSxZQUFZO0FBQUEsUUFDakQsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUNELFlBQU0sTUFBTSxZQUFZLE9BQU8sYUFBYSxXQUFZLFdBQXFDLENBQUM7QUFDOUYsc0JBQWdCLElBQUksWUFBWTtBQUNoQywwQkFBb0IsSUFBSTtBQUFBLFNBQ3JCLElBQUksZUFBZSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxZQUFZLEVBQUUsUUFBUSxNQUFNLEVBQUUsQ0FBQztBQUFBLE1BQ3RFO0FBQ0EsK0JBQXlCLElBQUksSUFBSSxJQUFJLG9CQUFvQixDQUFDLENBQUM7QUFDM0QseUJBQW1CLENBQUM7QUFBQSxJQUN0QixRQUFRO0FBQ04sc0JBQWdCO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsV0FBUyx3QkFBOEI7QUFDckMsVUFBTSxPQUFPLFNBQVMsbUJBQW1CLFNBQVM7QUFDbEQsUUFBSSxDQUFDLE1BQU07QUFDVCxpQkFBVyx1QkFBdUIsR0FBRztBQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLFdBQVcsSUFBSSxpQkFBaUIsTUFBTSxtQkFBbUIsQ0FBQztBQUNoRSxhQUFTLFFBQVEsTUFBTSxFQUFFLFdBQVcsTUFBTSxTQUFTLEtBQUssQ0FBQztBQUN6RCxXQUFPLGlCQUFpQixVQUFVLE1BQU0sbUJBQW1CLEdBQUcsRUFBRSxTQUFTLEtBQUssQ0FBQztBQUMvRSxTQUFLLHFCQUFxQjtBQUMxQixnQkFBWSxNQUFNO0FBQ2hCLFdBQUsscUJBQXFCO0FBQUEsSUFDNUIsR0FBRyxjQUFjO0FBQUEsRUFDbkI7QUFFQSx3QkFBc0I7QUFFdEIsV0FBUyx3QkFBd0IsS0FBdUI7QUFDdEQsUUFBSSxDQUFDLE9BQU8sT0FBTyxRQUFRLFNBQVUsUUFBTztBQUM1QyxXQUFRLElBQTJDLHlCQUF5QjtBQUFBLEVBQzlFO0FBRUEsV0FBUyxrQkFBa0IsSUFBMEQ7QUFDbkYsV0FBTyxjQUFjLG9CQUFvQixjQUFjO0FBQUEsRUFDekQ7QUFFQSxXQUFTLGtCQUFrQixJQUE0QjtBQUNyRCxRQUFJO0FBQ0YsU0FBRyxNQUFNO0FBQUEsSUFDWCxRQUFRO0FBQUEsSUFFUjtBQUNBLFFBQUk7QUFDRixTQUFHLFdBQVc7QUFDZCxTQUFHLFVBQVU7QUFDYixTQUFHLGdCQUFnQixVQUFVO0FBQzdCLFNBQUcsZ0JBQWdCLEtBQUs7QUFDeEIsU0FBRyxNQUFNO0FBQ1QsVUFBSSxlQUFlLEdBQUksSUFBRyxZQUFZO0FBQ3RDLGlCQUFXLFVBQVUsTUFBTSxLQUFLLEdBQUcsaUJBQWlCLGFBQWEsQ0FBQyxHQUFHO0FBQ25FLGVBQU8sZ0JBQWdCLEtBQUs7QUFBQSxNQUM5QjtBQUNBLFNBQUcsS0FBSztBQUFBLElBQ1YsUUFBUTtBQUFBLElBRVI7QUFBQSxFQUNGO0FBRUEsV0FBUyx3QkFBOEI7QUFDckMsNEJBQXdCO0FBQ3hCLFFBQUksQ0FBQyw0QkFBNkI7QUFDbEMsZUFBVyxNQUFNLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixhQUFhLENBQUMsR0FBRztBQUNyRSxVQUFJLGtCQUFrQixFQUFFLEVBQUcsbUJBQWtCLEVBQUU7QUFBQSxJQUNqRDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLHlCQUF5QixRQUFRLGdDQUFzQztBQUM5RSxRQUFJLENBQUMsK0JBQStCLDBCQUEwQixLQUFNO0FBQ3BFLDRCQUF3QixXQUFXLHVCQUF1QixLQUFLO0FBQUEsRUFDakU7QUFFQSxXQUFTLHlCQUF5QixPQUFvQjtBQUNwRCxRQUFJLENBQUMsNEJBQTZCO0FBQ2xDLFFBQUksa0JBQWtCLE1BQU0sTUFBTSxFQUFHLG1CQUFrQixNQUFNLE1BQU07QUFBQSxFQUNyRTtBQUVBLFdBQVMsd0JBQXdCLElBQW1CO0FBQ2xELFFBQUksZ0NBQWdDLEdBQUk7QUFDeEMsa0NBQThCO0FBRTlCLFFBQUksSUFBSTtBQUNOLFlBQU0sT0FBTyxTQUFTLG1CQUFtQixTQUFTO0FBQ2xELFVBQUksTUFBTTtBQUNSLCtCQUF1QixJQUFJLGlCQUFpQixNQUFNLHlCQUF5QixDQUFDO0FBQzVFLDZCQUFxQixRQUFRLE1BQU07QUFBQSxVQUNqQyxXQUFXO0FBQUEsVUFDWCxTQUFTO0FBQUEsVUFDVCxZQUFZO0FBQUEsVUFDWixpQkFBaUIsQ0FBQyxLQUFLO0FBQUEsUUFDekIsQ0FBQztBQUFBLE1BQ0g7QUFDQSxpQkFBVyxhQUFhLDRCQUE0QjtBQUNsRCxpQkFBUyxpQkFBaUIsV0FBVywwQkFBMEIsSUFBSTtBQUFBLE1BQ3JFO0FBQ0EsZ0NBQTBCLFlBQVksdUJBQXVCLHVCQUF1QjtBQUNwRiwrQkFBeUIsQ0FBQztBQUMxQjtBQUFBLElBQ0Y7QUFFQSxRQUFJLHNCQUFzQjtBQUN4QiwyQkFBcUIsV0FBVztBQUNoQyw2QkFBdUI7QUFBQSxJQUN6QjtBQUNBLFFBQUksMEJBQTBCLE1BQU07QUFDbEMsbUJBQWEscUJBQXFCO0FBQ2xDLDhCQUF3QjtBQUFBLElBQzFCO0FBQ0EsUUFBSSw0QkFBNEIsTUFBTTtBQUNwQyxvQkFBYyx1QkFBdUI7QUFDckMsZ0NBQTBCO0FBQUEsSUFDNUI7QUFDQSxlQUFXLGFBQWEsNEJBQTRCO0FBQ2xELGVBQVMsb0JBQW9CLFdBQVcsMEJBQTBCLElBQUk7QUFBQSxJQUN4RTtBQUFBLEVBQ0Y7QUFFQSxpQkFBZSw4QkFBNkM7QUFDMUQsUUFBSTtBQUNGLFlBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVTtBQUN6RCw4QkFBd0Isd0JBQXdCLE9BQU8sUUFBUSxDQUFDO0FBQUEsSUFDbEUsUUFBUTtBQUNOLDhCQUF3QixLQUFLO0FBQUEsSUFDL0I7QUFBQSxFQUNGO0FBRUEsVUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLFNBQVMsYUFBYTtBQUMzRCxRQUFJLGFBQWEsV0FBVyxDQUFDLFFBQVEsU0FBVTtBQUMvQyw0QkFBd0Isd0JBQXdCLFFBQVEsU0FBUyxRQUFRLENBQUM7QUFBQSxFQUM1RSxDQUFDO0FBRUQsT0FBSyw0QkFBNEI7QUFFakMsU0FBTyxpQkFBaUIsV0FBVyxDQUFDLFVBQXdCO0FBQzFELFFBQUksTUFBTSxXQUFXLE9BQVE7QUFDN0IsVUFBTSxPQUFPLE1BQU07QUFDbkIsUUFBSSxDQUFDLFFBQVEsT0FBTyxTQUFTLFNBQVU7QUFDdkMsVUFBTSxJQUFJO0FBRVYsUUFBSSxFQUFFLFdBQVcsT0FBTztBQUN0QixjQUFRLFFBQ0wsWUFBWTtBQUFBLFFBQ1gsTUFBTTtBQUFBLFFBQ04sS0FBSyxPQUFPLEVBQUUsUUFBUSxXQUFXLEVBQUUsTUFBTSxTQUFTO0FBQUEsTUFDcEQsQ0FBQyxFQUNBLE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUNqQjtBQUFBLElBQ0Y7QUFFQSxRQUFJLEVBQUUsV0FBVyxPQUFRO0FBQ3pCLFVBQU0sV0FBVyxPQUFPLEVBQUUsYUFBYSxXQUFXLEVBQUUsV0FBVztBQUMvRCxVQUFNLE1BQU0sT0FBTyxFQUFFLFFBQVEsV0FBVyxFQUFFLE1BQU07QUFDaEQsVUFBTSxVQUFVLE9BQU8sRUFBRSxhQUFhLFdBQVcsRUFBRSxXQUFXLFNBQVM7QUFDdkUsVUFBTSxXQUFXLEVBQUU7QUFDbkIsUUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLGFBQWEsT0FBVztBQUNqRCxZQUFRLFFBQ0wsWUFBWSxFQUFFLE1BQU0sbUJBQW1CLFVBQVUsS0FBSyxTQUFTLFNBQVMsQ0FBQyxFQUN6RSxNQUFNLENBQUMsUUFBUTtBQUNkLGNBQVEsS0FBSyxvQ0FBb0MsR0FBRztBQUFBLElBQ3RELENBQUM7QUFBQSxFQUNMLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
