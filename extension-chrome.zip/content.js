var browser=globalThis.browser??globalThis.chrome;
"use strict";
(() => {
  // src/content.ts
  var TARGET = "IMM_ARCHIVE_CAPTURE";
  var READY = "IMM_ARCHIVE_HOOK_READY";
  var UNFOLD_SYNC_MS = 2e3;
  var UNFOLD_SCAN_DEBOUNCE_MS = 250;
  var LOW_BANDWIDTH_SCAN_DEBOUNCE_MS = 100;
  var LOW_BANDWIDTH_RESCAN_MS = 1500;
  var LOW_BANDWIDTH_MEDIA_EVENTS = ["loadstart", "loadedmetadata", "play", "playing"];
  var unfoldEnabled = false;
  var unfoldRelevantTweetIds = /* @__PURE__ */ new Set();
  var unfoldScanTimer = null;
  var unfoldedControls = /* @__PURE__ */ new WeakSet();
  var lowBandwidthScrubberEnabled = false;
  var lowBandwidthObserver = null;
  var lowBandwidthScanTimer = null;
  var lowBandwidthRescanTimer = null;
  void browser.runtime.sendMessage({ type: "content-alive", url: location.href }).catch((err) => {
    console.warn("[imm-archive] content-alive ping failed", err);
  });
  function fallbackInject() {
    try {
      const src = browser.runtime.getURL("page-hook.js");
      const script = document.createElement("script");
      script.src = src;
      script.async = false;
      script.dataset.immArchive = "1";
      (document.head || document.documentElement).appendChild(script);
      script.onload = () => script.remove();
      script.onerror = () => {
        browser.runtime.sendMessage({
          type: "log-content-event",
          level: "warn",
          msg: "inline page-hook injection blocked (CSP); relying on MAIN-world content script",
          url: location.href
        }).catch(() => {
        });
      };
    } catch (err) {
      console.warn("[imm-archive] inline page-hook injection threw", err);
    }
  }
  fallbackInject();
  function normalizeHandle(raw) {
    if (!raw) return null;
    const cleaned = raw.trim().replace(/^@/, "").toLowerCase();
    return cleaned.length > 0 ? cleaned : null;
  }
  var STATUS_HOSTS = /* @__PURE__ */ new Set(["x.com", "twitter.com", "mobile.twitter.com"]);
  function parseTweetUrl(href) {
    if (!href) return null;
    try {
      const u = new URL(href, location.href);
      if (!STATUS_HOSTS.has(u.hostname.toLowerCase())) return null;
      const parts = u.pathname.split("/").filter(Boolean);
      const statusIdx = parts.indexOf("status");
      if (statusIdx <= 0) return null;
      const handle = normalizeHandle(parts[statusIdx - 1] ?? null);
      const id = parts[statusIdx + 1] ?? null;
      if (!handle || !id || !/^\d+$/.test(id)) return null;
      return { handle, id };
    } catch {
      return null;
    }
  }
  function isVisible(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return false;
    const style = window.getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none";
  }
  function scanAndUnfoldShowMore() {
    unfoldScanTimer = null;
    if (!unfoldEnabled) return;
    const selectors = [
      '[data-testid="tweet-text-show-more-link"]',
      'button[data-testid="tweet-text-show-more-link"]',
      'article [role="button"][tabindex="0"]',
      'div[data-testid="cellInnerDiv"] [role="button"][tabindex="0"]'
    ];
    const seen = /* @__PURE__ */ new Set();
    let clicked = 0;
    for (const sel of selectors) {
      for (const el of Array.from(document.querySelectorAll(sel))) {
        if (seen.has(el) || unfoldedControls.has(el)) continue;
        seen.add(el);
        if ((el.textContent || "").trim().toLowerCase() !== "show more") continue;
        if (!isVisible(el)) continue;
        const link = el.closest("a[href]");
        const linkedTweet = link ? parseTweetUrl(link.getAttribute("href")) : null;
        if (linkedTweet && !unfoldRelevantTweetIds.has(linkedTweet.id)) continue;
        unfoldedControls.add(el);
        try {
          el.click();
          clicked += 1;
        } catch {
        }
      }
    }
    if (clicked > 0) {
      browser.runtime.sendMessage({ type: "show-more-unfolded", count: clicked }).catch(() => {
      });
    }
  }
  function scheduleUnfoldScan(delay = UNFOLD_SCAN_DEBOUNCE_MS) {
    if (unfoldScanTimer !== null) return;
    unfoldScanTimer = setTimeout(scanAndUnfoldShowMore, delay);
  }
  async function refreshUnfoldTargets() {
    try {
      const response = await browser.runtime.sendMessage({
        type: "get-unfold-targets"
      });
      const raw = response && typeof response === "object" ? response : {};
      unfoldEnabled = raw.enabled !== false;
      unfoldRelevantTweetIds = new Set(raw.relevantTweetIds ?? []);
      scheduleUnfoldScan(0);
    } catch {
      unfoldEnabled = false;
    }
  }
  function installUnfoldObserver() {
    const root = document.documentElement || document.body;
    if (!root) {
      setTimeout(installUnfoldObserver, 100);
      return;
    }
    const observer = new MutationObserver(() => scheduleUnfoldScan());
    observer.observe(root, { childList: true, subtree: true });
    window.addEventListener("scroll", () => scheduleUnfoldScan(), { passive: true });
    void refreshUnfoldTargets();
    setInterval(() => {
      void refreshUnfoldTargets();
    }, UNFOLD_SYNC_MS);
  }
  installUnfoldObserver();
  function lowBandwidthSettingFrom(raw) {
    if (!raw || typeof raw !== "object") return false;
    return raw.lowBandwidthBrowsing === true;
  }
  function isScrubbableMedia(el) {
    return el instanceof HTMLVideoElement || el instanceof HTMLAudioElement;
  }
  function scrubMediaElement(el) {
    try {
      el.pause();
    } catch {
    }
    try {
      el.autoplay = false;
      el.preload = "none";
      el.removeAttribute("autoplay");
      el.removeAttribute("src");
      el.src = "";
      if ("srcObject" in el) el.srcObject = null;
      for (const source of Array.from(el.querySelectorAll("source[src]"))) {
        source.removeAttribute("src");
      }
      el.load();
    } catch {
    }
  }
  function scanLowBandwidthMedia() {
    lowBandwidthScanTimer = null;
    if (!lowBandwidthScrubberEnabled) return;
    for (const el of Array.from(document.querySelectorAll("video,audio"))) {
      if (isScrubbableMedia(el)) scrubMediaElement(el);
    }
  }
  function scheduleLowBandwidthScan(delay = LOW_BANDWIDTH_SCAN_DEBOUNCE_MS) {
    if (!lowBandwidthScrubberEnabled || lowBandwidthScanTimer !== null) return;
    lowBandwidthScanTimer = setTimeout(scanLowBandwidthMedia, delay);
  }
  function onLowBandwidthMediaEvent(event) {
    if (!lowBandwidthScrubberEnabled) return;
    if (isScrubbableMedia(event.target)) scrubMediaElement(event.target);
  }
  function setLowBandwidthScrubber(on) {
    if (lowBandwidthScrubberEnabled === on) return;
    lowBandwidthScrubberEnabled = on;
    if (on) {
      const root = document.documentElement || document.body;
      if (root) {
        lowBandwidthObserver = new MutationObserver(() => scheduleLowBandwidthScan());
        lowBandwidthObserver.observe(root, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["src"]
        });
      }
      for (const eventName of LOW_BANDWIDTH_MEDIA_EVENTS) {
        document.addEventListener(eventName, onLowBandwidthMediaEvent, true);
      }
      lowBandwidthRescanTimer = setInterval(scanLowBandwidthMedia, LOW_BANDWIDTH_RESCAN_MS);
      scheduleLowBandwidthScan(0);
      return;
    }
    if (lowBandwidthObserver) {
      lowBandwidthObserver.disconnect();
      lowBandwidthObserver = null;
    }
    if (lowBandwidthScanTimer !== null) {
      clearTimeout(lowBandwidthScanTimer);
      lowBandwidthScanTimer = null;
    }
    if (lowBandwidthRescanTimer !== null) {
      clearInterval(lowBandwidthRescanTimer);
      lowBandwidthRescanTimer = null;
    }
    for (const eventName of LOW_BANDWIDTH_MEDIA_EVENTS) {
      document.removeEventListener(eventName, onLowBandwidthMediaEvent, true);
    }
  }
  async function refreshLowBandwidthScrubber() {
    try {
      const result = await browser.storage.local.get("settings");
      setLowBandwidthScrubber(lowBandwidthSettingFrom(result.settings));
    } catch {
      setLowBandwidthScrubber(false);
    }
  }
  browser.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local" || !changes.settings) return;
    setLowBandwidthScrubber(lowBandwidthSettingFrom(changes.settings.newValue));
  });
  void refreshLowBandwidthScrubber();
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || typeof data !== "object") return;
    const d = data;
    if (d.source === READY) {
      browser.runtime.sendMessage({
        type: "page-hook-active",
        url: typeof d.url === "string" ? d.url : location.href
      }).catch(() => {
      });
      return;
    }
    if (d.source !== TARGET) return;
    const endpoint = typeof d.endpoint === "string" ? d.endpoint : null;
    const url = typeof d.url === "string" ? d.url : null;
    const pageUrl = typeof d.page_url === "string" ? d.page_url : location.href;
    const response = d.response;
    if (!endpoint || !url || response === void 0) return;
    browser.runtime.sendMessage({ type: "graphql-capture", endpoint, url, pageUrl, response }).catch((err) => {
      console.warn("[imm-archive] sendMessage failed", err);
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbnRlbnQudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKlxuICogY29udGVudC50cyBcdTIwMTQgY29udGVudC1zY3JpcHQgY29udGV4dCAoaXNvbGF0ZWQgd29ybGQpLlxuICpcbiAqIFRoZSBhY3R1YWwgcGFnZS1ob29rICh3aGljaCBwYXRjaGVzIGBmZXRjaGAgLyBgWEhSYCkgaXMgZGVjbGFyZWQgYXMgYVxuICogc2VwYXJhdGUgY29udGVudCBzY3JpcHQgd2l0aCBgd29ybGQ6IFwiTUFJTlwiYCBpbiB0aGUgbWFuaWZlc3QsIHNvIGl0IHJ1bnNcbiAqIGluIHRoZSBwYWdlIHdvcmxkIGRpcmVjdGx5IHdpdGhvdXQgdXMgaGF2aW5nIHRvIGluamVjdCBhIDxzY3JpcHQ+IHRhZyBcdTIwMTRcbiAqIHdoaWNoIFgncyBub25jZS1iYXNlZCBDU1Agd291bGQgYmxvY2suXG4gKlxuICogVGhpcyBmaWxlIGRvZXMgdGhyZWUgdGhpbmdzOlxuICpcbiAqICAgMS4gUGluZ3MgdGhlIGJhY2tncm91bmQgb24gbG9hZCBzbyB0aGUgYWN0aXZpdHkgdGFpbCBjb25maXJtcyB0aGVcbiAqICAgICAgY29udGVudCBzY3JpcHQgcmVhY2hlZCB0aGUgWCBwYWdlICh1c2VmdWwgd2hlbiBkaWFnbm9zaW5nIGEgc2lsZW50XG4gKiAgICAgIFwiY2FwdHVyZS1ub3cgZG9lcyBub3RoaW5nXCIgZmFpbHVyZSkuXG4gKiAgIDIuIEFzIGEgZGVmZW5zaXZlIGZhbGxiYWNrLCBhbHNvIHRyaWVzIHRvIGluamVjdCBgcGFnZS1ob29rLmpzYCB2aWEgYVxuICogICAgICBzY3JpcHQgdGFnLiBIYXJtbGVzcyBvbiBtb2Rlcm4gRmlyZWZveCAodGhlIHBhZ2UtaG9vaydzIFRBRyBndWFyZFxuICogICAgICBwcmV2ZW50cyBkb3VibGUtaW5pdCk7IGNvdmVycyB0aGUgcmFyZSBjYXNlIHdoZXJlIHRoZSBNQUlOLXdvcmxkXG4gKiAgICAgIGNvbnRlbnQgc2NyaXB0IGVudHJ5IGlzbid0IGhvbm9yZWQuXG4gKiAgIDMuIEJyaWRnZXMgYHdpbmRvdy5wb3N0TWVzc2FnZWAgZnJvbSB0aGUgcGFnZSBob29rIHRvIHRoZSBiYWNrZ3JvdW5kOlxuICogICAgICBib3RoIHRoZSBgKl9SRUFEWWAgYm9vdCBwaW5nIGFuZCB0aGUgYElNTV9BUkNISVZFX0NBUFRVUkVgIHBheWxvYWRcbiAqICAgICAgZXZlbnRzLlxuICovXG5cbmNvbnN0IFRBUkdFVCA9ICdJTU1fQVJDSElWRV9DQVBUVVJFJztcbmNvbnN0IFJFQURZID0gJ0lNTV9BUkNISVZFX0hPT0tfUkVBRFknO1xuY29uc3QgVU5GT0xEX1NZTkNfTVMgPSAyXzAwMDtcbmNvbnN0IFVORk9MRF9TQ0FOX0RFQk9VTkNFX01TID0gMjUwO1xuY29uc3QgTE9XX0JBTkRXSURUSF9TQ0FOX0RFQk9VTkNFX01TID0gMTAwO1xuY29uc3QgTE9XX0JBTkRXSURUSF9SRVNDQU5fTVMgPSAxXzUwMDtcbmNvbnN0IExPV19CQU5EV0lEVEhfTUVESUFfRVZFTlRTID0gWydsb2Fkc3RhcnQnLCAnbG9hZGVkbWV0YWRhdGEnLCAncGxheScsICdwbGF5aW5nJ10gYXMgY29uc3Q7XG5cbmludGVyZmFjZSBVbmZvbGRUYXJnZXRzUmVzcG9uc2Uge1xuICBlbmFibGVkPzogYm9vbGVhbjtcbiAgcmVsZXZhbnRUd2VldElkcz86IHN0cmluZ1tdO1xufVxuXG5sZXQgdW5mb2xkRW5hYmxlZCA9IGZhbHNlO1xubGV0IHVuZm9sZFJlbGV2YW50VHdlZXRJZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbmxldCB1bmZvbGRTY2FuVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbCA9IG51bGw7XG5jb25zdCB1bmZvbGRlZENvbnRyb2xzID0gbmV3IFdlYWtTZXQ8RWxlbWVudD4oKTtcbmxldCBsb3dCYW5kd2lkdGhTY3J1YmJlckVuYWJsZWQgPSBmYWxzZTtcbmxldCBsb3dCYW5kd2lkdGhPYnNlcnZlcjogTXV0YXRpb25PYnNlcnZlciB8IG51bGwgPSBudWxsO1xubGV0IGxvd0JhbmR3aWR0aFNjYW5UaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCBudWxsID0gbnVsbDtcbmxldCBsb3dCYW5kd2lkdGhSZXNjYW5UaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG5cbnZvaWQgYnJvd3Nlci5ydW50aW1lXG4gIC5zZW5kTWVzc2FnZSh7IHR5cGU6ICdjb250ZW50LWFsaXZlJywgdXJsOiBsb2NhdGlvbi5ocmVmIH0pXG4gIC5jYXRjaCgoZXJyOiB1bmtub3duKSA9PiB7XG4gICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIGNvbnRlbnQtYWxpdmUgcGluZyBmYWlsZWQnLCBlcnIpO1xuICB9KTtcblxuZnVuY3Rpb24gZmFsbGJhY2tJbmplY3QoKTogdm9pZCB7XG4gIHRyeSB7XG4gICAgY29uc3Qgc3JjID0gYnJvd3Nlci5ydW50aW1lLmdldFVSTCgncGFnZS1ob29rLmpzJyk7XG4gICAgY29uc3Qgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XG4gICAgc2NyaXB0LnNyYyA9IHNyYztcbiAgICBzY3JpcHQuYXN5bmMgPSBmYWxzZTtcbiAgICBzY3JpcHQuZGF0YXNldC5pbW1BcmNoaXZlID0gJzEnO1xuICAgIChkb2N1bWVudC5oZWFkIHx8IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcbiAgICBzY3JpcHQub25sb2FkID0gKCkgPT4gc2NyaXB0LnJlbW92ZSgpO1xuICAgIHNjcmlwdC5vbmVycm9yID0gKCkgPT4ge1xuICAgICAgLy8gQ1NQIHByb2JhYmx5IGJsb2NrZWQgdGhpcy4gTm90IGZhdGFsIFx1MjAxNCB0aGUgTUFJTi13b3JsZCBjb250ZW50IHNjcmlwdFxuICAgICAgLy8gZGVjbGFyZWQgaW4gbWFuaWZlc3QuanNvbiBpcyB0aGUgcHJpbWFyeSBwYXRoLiBTdXJmYWNlIGFzIGEgbG9nIHNvXG4gICAgICAvLyB3ZSBrbm93IHdoYXQgaGFwcGVuZWQgd2l0aG91dCBseWluZyBhYm91dCBzdWNjZXNzLlxuICAgICAgYnJvd3Nlci5ydW50aW1lXG4gICAgICAgIC5zZW5kTWVzc2FnZSh7XG4gICAgICAgICAgdHlwZTogJ2xvZy1jb250ZW50LWV2ZW50JyxcbiAgICAgICAgICBsZXZlbDogJ3dhcm4nLFxuICAgICAgICAgIG1zZzogJ2lubGluZSBwYWdlLWhvb2sgaW5qZWN0aW9uIGJsb2NrZWQgKENTUCk7IHJlbHlpbmcgb24gTUFJTi13b3JsZCBjb250ZW50IHNjcmlwdCcsXG4gICAgICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmLFxuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKCkgPT4ge30pO1xuICAgIH07XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUud2FybignW2ltbS1hcmNoaXZlXSBpbmxpbmUgcGFnZS1ob29rIGluamVjdGlvbiB0aHJldycsIGVycik7XG4gIH1cbn1cblxuZmFsbGJhY2tJbmplY3QoKTtcblxuZnVuY3Rpb24gbm9ybWFsaXplSGFuZGxlKHJhdzogc3RyaW5nIHwgbnVsbCk6IHN0cmluZyB8IG51bGwge1xuICBpZiAoIXJhdykgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGNsZWFuZWQgPSByYXcudHJpbSgpLnJlcGxhY2UoL15ALywgJycpLnRvTG93ZXJDYXNlKCk7XG4gIHJldHVybiBjbGVhbmVkLmxlbmd0aCA+IDAgPyBjbGVhbmVkIDogbnVsbDtcbn1cblxuY29uc3QgU1RBVFVTX0hPU1RTID0gbmV3IFNldChbJ3guY29tJywgJ3R3aXR0ZXIuY29tJywgJ21vYmlsZS50d2l0dGVyLmNvbSddKTtcblxuZnVuY3Rpb24gcGFyc2VUd2VldFVybChocmVmOiBzdHJpbmcgfCBudWxsKTogeyBoYW5kbGU6IHN0cmluZzsgaWQ6IHN0cmluZyB9IHwgbnVsbCB7XG4gIGlmICghaHJlZikgcmV0dXJuIG51bGw7XG4gIHRyeSB7XG4gICAgY29uc3QgdSA9IG5ldyBVUkwoaHJlZiwgbG9jYXRpb24uaHJlZik7XG4gICAgaWYgKCFTVEFUVVNfSE9TVFMuaGFzKHUuaG9zdG5hbWUudG9Mb3dlckNhc2UoKSkpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IHBhcnRzID0gdS5wYXRobmFtZS5zcGxpdCgnLycpLmZpbHRlcihCb29sZWFuKTtcbiAgICBjb25zdCBzdGF0dXNJZHggPSBwYXJ0cy5pbmRleE9mKCdzdGF0dXMnKTtcbiAgICBpZiAoc3RhdHVzSWR4IDw9IDApIHJldHVybiBudWxsO1xuICAgIGNvbnN0IGhhbmRsZSA9IG5vcm1hbGl6ZUhhbmRsZShwYXJ0c1tzdGF0dXNJZHggLSAxXSA/PyBudWxsKTtcbiAgICBjb25zdCBpZCA9IHBhcnRzW3N0YXR1c0lkeCArIDFdID8/IG51bGw7XG4gICAgaWYgKCFoYW5kbGUgfHwgIWlkIHx8ICEvXlxcZCskLy50ZXN0KGlkKSkgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIHsgaGFuZGxlLCBpZCB9O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBpc1Zpc2libGUoZWw6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgY29uc3QgcmVjdCA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICBpZiAocmVjdC53aWR0aCA9PT0gMCB8fCByZWN0LmhlaWdodCA9PT0gMCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBzdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsKTtcbiAgcmV0dXJuIHN0eWxlLnZpc2liaWxpdHkgIT09ICdoaWRkZW4nICYmIHN0eWxlLmRpc3BsYXkgIT09ICdub25lJztcbn1cblxuZnVuY3Rpb24gc2NhbkFuZFVuZm9sZFNob3dNb3JlKCk6IHZvaWQge1xuICB1bmZvbGRTY2FuVGltZXIgPSBudWxsO1xuICBpZiAoIXVuZm9sZEVuYWJsZWQpIHJldHVybjtcbiAgY29uc3Qgc2VsZWN0b3JzID0gW1xuICAgICdbZGF0YS10ZXN0aWQ9XCJ0d2VldC10ZXh0LXNob3ctbW9yZS1saW5rXCJdJyxcbiAgICAnYnV0dG9uW2RhdGEtdGVzdGlkPVwidHdlZXQtdGV4dC1zaG93LW1vcmUtbGlua1wiXScsXG4gICAgJ2FydGljbGUgW3JvbGU9XCJidXR0b25cIl1bdGFiaW5kZXg9XCIwXCJdJyxcbiAgICAnZGl2W2RhdGEtdGVzdGlkPVwiY2VsbElubmVyRGl2XCJdIFtyb2xlPVwiYnV0dG9uXCJdW3RhYmluZGV4PVwiMFwiXScsXG4gIF07XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PEVsZW1lbnQ+KCk7XG4gIGxldCBjbGlja2VkID0gMDtcbiAgZm9yIChjb25zdCBzZWwgb2Ygc2VsZWN0b3JzKSB7XG4gICAgZm9yIChjb25zdCBlbCBvZiBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsKSkpIHtcbiAgICAgIGlmIChzZWVuLmhhcyhlbCkgfHwgdW5mb2xkZWRDb250cm9scy5oYXMoZWwpKSBjb250aW51ZTtcbiAgICAgIHNlZW4uYWRkKGVsKTtcbiAgICAgIGlmICgoZWwudGV4dENvbnRlbnQgfHwgJycpLnRyaW0oKS50b0xvd2VyQ2FzZSgpICE9PSAnc2hvdyBtb3JlJykgY29udGludWU7XG4gICAgICBpZiAoIWlzVmlzaWJsZShlbCkpIGNvbnRpbnVlO1xuICAgICAgY29uc3QgbGluayA9IGVsLmNsb3Nlc3QoJ2FbaHJlZl0nKTtcbiAgICAgIGNvbnN0IGxpbmtlZFR3ZWV0ID0gbGluayA/IHBhcnNlVHdlZXRVcmwobGluay5nZXRBdHRyaWJ1dGUoJ2hyZWYnKSkgOiBudWxsO1xuICAgICAgaWYgKGxpbmtlZFR3ZWV0ICYmICF1bmZvbGRSZWxldmFudFR3ZWV0SWRzLmhhcyhsaW5rZWRUd2VldC5pZCkpIGNvbnRpbnVlO1xuICAgICAgdW5mb2xkZWRDb250cm9scy5hZGQoZWwpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgICAgICBjbGlja2VkICs9IDE7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gSWdub3JlIHN0YWxlIG9yIHN5bnRoZXRpYyBjb250cm9scy5cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGNsaWNrZWQgPiAwKSB7XG4gICAgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ3Nob3ctbW9yZS11bmZvbGRlZCcsIGNvdW50OiBjbGlja2VkIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzY2hlZHVsZVVuZm9sZFNjYW4oZGVsYXkgPSBVTkZPTERfU0NBTl9ERUJPVU5DRV9NUyk6IHZvaWQge1xuICBpZiAodW5mb2xkU2NhblRpbWVyICE9PSBudWxsKSByZXR1cm47XG4gIHVuZm9sZFNjYW5UaW1lciA9IHNldFRpbWVvdXQoc2NhbkFuZFVuZm9sZFNob3dNb3JlLCBkZWxheSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hVbmZvbGRUYXJnZXRzKCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYnJvd3Nlci5ydW50aW1lLnNlbmRNZXNzYWdlKHtcbiAgICAgIHR5cGU6ICdnZXQtdW5mb2xkLXRhcmdldHMnLFxuICAgIH0pO1xuICAgIGNvbnN0IHJhdyA9IHJlc3BvbnNlICYmIHR5cGVvZiByZXNwb25zZSA9PT0gJ29iamVjdCcgPyAocmVzcG9uc2UgYXMgVW5mb2xkVGFyZ2V0c1Jlc3BvbnNlKSA6IHt9O1xuICAgIHVuZm9sZEVuYWJsZWQgPSByYXcuZW5hYmxlZCAhPT0gZmFsc2U7XG4gICAgdW5mb2xkUmVsZXZhbnRUd2VldElkcyA9IG5ldyBTZXQocmF3LnJlbGV2YW50VHdlZXRJZHMgPz8gW10pO1xuICAgIHNjaGVkdWxlVW5mb2xkU2NhbigwKTtcbiAgfSBjYXRjaCB7XG4gICAgdW5mb2xkRW5hYmxlZCA9IGZhbHNlO1xuICB9XG59XG5cbmZ1bmN0aW9uIGluc3RhbGxVbmZvbGRPYnNlcnZlcigpOiB2b2lkIHtcbiAgY29uc3Qgcm9vdCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCB8fCBkb2N1bWVudC5ib2R5O1xuICBpZiAoIXJvb3QpIHtcbiAgICBzZXRUaW1lb3V0KGluc3RhbGxVbmZvbGRPYnNlcnZlciwgMTAwKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigoKSA9PiBzY2hlZHVsZVVuZm9sZFNjYW4oKSk7XG4gIG9ic2VydmVyLm9ic2VydmUocm9vdCwgeyBjaGlsZExpc3Q6IHRydWUsIHN1YnRyZWU6IHRydWUgfSk7XG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdzY3JvbGwnLCAoKSA9PiBzY2hlZHVsZVVuZm9sZFNjYW4oKSwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICB2b2lkIHJlZnJlc2hVbmZvbGRUYXJnZXRzKCk7XG4gIHNldEludGVydmFsKCgpID0+IHtcbiAgICB2b2lkIHJlZnJlc2hVbmZvbGRUYXJnZXRzKCk7XG4gIH0sIFVORk9MRF9TWU5DX01TKTtcbn1cblxuaW5zdGFsbFVuZm9sZE9ic2VydmVyKCk7XG5cbmZ1bmN0aW9uIGxvd0JhbmR3aWR0aFNldHRpbmdGcm9tKHJhdzogdW5rbm93bik6IGJvb2xlYW4ge1xuICBpZiAoIXJhdyB8fCB0eXBlb2YgcmF3ICE9PSAnb2JqZWN0JykgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gKHJhdyBhcyB7IGxvd0JhbmR3aWR0aEJyb3dzaW5nPzogdW5rbm93biB9KS5sb3dCYW5kd2lkdGhCcm93c2luZyA9PT0gdHJ1ZTtcbn1cblxuZnVuY3Rpb24gaXNTY3J1YmJhYmxlTWVkaWEoZWw6IEV2ZW50VGFyZ2V0IHwgRWxlbWVudCB8IG51bGwpOiBlbCBpcyBIVE1MTWVkaWFFbGVtZW50IHtcbiAgcmV0dXJuIGVsIGluc3RhbmNlb2YgSFRNTFZpZGVvRWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxBdWRpb0VsZW1lbnQ7XG59XG5cbmZ1bmN0aW9uIHNjcnViTWVkaWFFbGVtZW50KGVsOiBIVE1MTWVkaWFFbGVtZW50KTogdm9pZCB7XG4gIHRyeSB7XG4gICAgZWwucGF1c2UoKTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gSWdub3JlIHN0YWxlIG1lZGlhIG5vZGVzLlxuICB9XG4gIHRyeSB7XG4gICAgZWwuYXV0b3BsYXkgPSBmYWxzZTtcbiAgICBlbC5wcmVsb2FkID0gJ25vbmUnO1xuICAgIGVsLnJlbW92ZUF0dHJpYnV0ZSgnYXV0b3BsYXknKTtcbiAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoJ3NyYycpO1xuICAgIGVsLnNyYyA9ICcnO1xuICAgIGlmICgnc3JjT2JqZWN0JyBpbiBlbCkgZWwuc3JjT2JqZWN0ID0gbnVsbDtcbiAgICBmb3IgKGNvbnN0IHNvdXJjZSBvZiBBcnJheS5mcm9tKGVsLnF1ZXJ5U2VsZWN0b3JBbGwoJ3NvdXJjZVtzcmNdJykpKSB7XG4gICAgICBzb3VyY2UucmVtb3ZlQXR0cmlidXRlKCdzcmMnKTtcbiAgICB9XG4gICAgZWwubG9hZCgpO1xuICB9IGNhdGNoIHtcbiAgICAvLyBYIGNhbiByZXBsYWNlIG5vZGVzIGR1cmluZyBzY3JvbGw7IGJlc3QtZWZmb3J0IHNjcnViYmluZyBpcyBlbm91Z2guXG4gIH1cbn1cblxuZnVuY3Rpb24gc2Nhbkxvd0JhbmR3aWR0aE1lZGlhKCk6IHZvaWQge1xuICBsb3dCYW5kd2lkdGhTY2FuVGltZXIgPSBudWxsO1xuICBpZiAoIWxvd0JhbmR3aWR0aFNjcnViYmVyRW5hYmxlZCkgcmV0dXJuO1xuICBmb3IgKGNvbnN0IGVsIG9mIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgndmlkZW8sYXVkaW8nKSkpIHtcbiAgICBpZiAoaXNTY3J1YmJhYmxlTWVkaWEoZWwpKSBzY3J1Yk1lZGlhRWxlbWVudChlbCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc2NoZWR1bGVMb3dCYW5kd2lkdGhTY2FuKGRlbGF5ID0gTE9XX0JBTkRXSURUSF9TQ0FOX0RFQk9VTkNFX01TKTogdm9pZCB7XG4gIGlmICghbG93QmFuZHdpZHRoU2NydWJiZXJFbmFibGVkIHx8IGxvd0JhbmR3aWR0aFNjYW5UaW1lciAhPT0gbnVsbCkgcmV0dXJuO1xuICBsb3dCYW5kd2lkdGhTY2FuVGltZXIgPSBzZXRUaW1lb3V0KHNjYW5Mb3dCYW5kd2lkdGhNZWRpYSwgZGVsYXkpO1xufVxuXG5mdW5jdGlvbiBvbkxvd0JhbmR3aWR0aE1lZGlhRXZlbnQoZXZlbnQ6IEV2ZW50KTogdm9pZCB7XG4gIGlmICghbG93QmFuZHdpZHRoU2NydWJiZXJFbmFibGVkKSByZXR1cm47XG4gIGlmIChpc1NjcnViYmFibGVNZWRpYShldmVudC50YXJnZXQpKSBzY3J1Yk1lZGlhRWxlbWVudChldmVudC50YXJnZXQpO1xufVxuXG5mdW5jdGlvbiBzZXRMb3dCYW5kd2lkdGhTY3J1YmJlcihvbjogYm9vbGVhbik6IHZvaWQge1xuICBpZiAobG93QmFuZHdpZHRoU2NydWJiZXJFbmFibGVkID09PSBvbikgcmV0dXJuO1xuICBsb3dCYW5kd2lkdGhTY3J1YmJlckVuYWJsZWQgPSBvbjtcblxuICBpZiAob24pIHtcbiAgICBjb25zdCByb290ID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50IHx8IGRvY3VtZW50LmJvZHk7XG4gICAgaWYgKHJvb3QpIHtcbiAgICAgIGxvd0JhbmR3aWR0aE9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4gc2NoZWR1bGVMb3dCYW5kd2lkdGhTY2FuKCkpO1xuICAgICAgbG93QmFuZHdpZHRoT2JzZXJ2ZXIub2JzZXJ2ZShyb290LCB7XG4gICAgICAgIGNoaWxkTGlzdDogdHJ1ZSxcbiAgICAgICAgc3VidHJlZTogdHJ1ZSxcbiAgICAgICAgYXR0cmlidXRlczogdHJ1ZSxcbiAgICAgICAgYXR0cmlidXRlRmlsdGVyOiBbJ3NyYyddLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgZXZlbnROYW1lIG9mIExPV19CQU5EV0lEVEhfTUVESUFfRVZFTlRTKSB7XG4gICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwgb25Mb3dCYW5kd2lkdGhNZWRpYUV2ZW50LCB0cnVlKTtcbiAgICB9XG4gICAgbG93QmFuZHdpZHRoUmVzY2FuVGltZXIgPSBzZXRJbnRlcnZhbChzY2FuTG93QmFuZHdpZHRoTWVkaWEsIExPV19CQU5EV0lEVEhfUkVTQ0FOX01TKTtcbiAgICBzY2hlZHVsZUxvd0JhbmR3aWR0aFNjYW4oMCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKGxvd0JhbmR3aWR0aE9ic2VydmVyKSB7XG4gICAgbG93QmFuZHdpZHRoT2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgIGxvd0JhbmR3aWR0aE9ic2VydmVyID0gbnVsbDtcbiAgfVxuICBpZiAobG93QmFuZHdpZHRoU2NhblRpbWVyICE9PSBudWxsKSB7XG4gICAgY2xlYXJUaW1lb3V0KGxvd0JhbmR3aWR0aFNjYW5UaW1lcik7XG4gICAgbG93QmFuZHdpZHRoU2NhblRpbWVyID0gbnVsbDtcbiAgfVxuICBpZiAobG93QmFuZHdpZHRoUmVzY2FuVGltZXIgIT09IG51bGwpIHtcbiAgICBjbGVhckludGVydmFsKGxvd0JhbmR3aWR0aFJlc2NhblRpbWVyKTtcbiAgICBsb3dCYW5kd2lkdGhSZXNjYW5UaW1lciA9IG51bGw7XG4gIH1cbiAgZm9yIChjb25zdCBldmVudE5hbWUgb2YgTE9XX0JBTkRXSURUSF9NRURJQV9FVkVOVFMpIHtcbiAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50TmFtZSwgb25Mb3dCYW5kd2lkdGhNZWRpYUV2ZW50LCB0cnVlKTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoTG93QmFuZHdpZHRoU2NydWJiZXIoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldCgnc2V0dGluZ3MnKTtcbiAgICBzZXRMb3dCYW5kd2lkdGhTY3J1YmJlcihsb3dCYW5kd2lkdGhTZXR0aW5nRnJvbShyZXN1bHQuc2V0dGluZ3MpKTtcbiAgfSBjYXRjaCB7XG4gICAgc2V0TG93QmFuZHdpZHRoU2NydWJiZXIoZmFsc2UpO1xuICB9XG59XG5cbmJyb3dzZXIuc3RvcmFnZS5vbkNoYW5nZWQuYWRkTGlzdGVuZXIoKGNoYW5nZXMsIGFyZWFOYW1lKSA9PiB7XG4gIGlmIChhcmVhTmFtZSAhPT0gJ2xvY2FsJyB8fCAhY2hhbmdlcy5zZXR0aW5ncykgcmV0dXJuO1xuICBzZXRMb3dCYW5kd2lkdGhTY3J1YmJlcihsb3dCYW5kd2lkdGhTZXR0aW5nRnJvbShjaGFuZ2VzLnNldHRpbmdzLm5ld1ZhbHVlKSk7XG59KTtcblxudm9pZCByZWZyZXNoTG93QmFuZHdpZHRoU2NydWJiZXIoKTtcblxud2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCAoZXZlbnQ6IE1lc3NhZ2VFdmVudCkgPT4ge1xuICBpZiAoZXZlbnQuc291cmNlICE9PSB3aW5kb3cpIHJldHVybjtcbiAgY29uc3QgZGF0YSA9IGV2ZW50LmRhdGEgYXMgdW5rbm93bjtcbiAgaWYgKCFkYXRhIHx8IHR5cGVvZiBkYXRhICE9PSAnb2JqZWN0JykgcmV0dXJuO1xuICBjb25zdCBkID0gZGF0YSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcblxuICBpZiAoZC5zb3VyY2UgPT09IFJFQURZKSB7XG4gICAgYnJvd3Nlci5ydW50aW1lXG4gICAgICAuc2VuZE1lc3NhZ2Uoe1xuICAgICAgICB0eXBlOiAncGFnZS1ob29rLWFjdGl2ZScsXG4gICAgICAgIHVybDogdHlwZW9mIGQudXJsID09PSAnc3RyaW5nJyA/IGQudXJsIDogbG9jYXRpb24uaHJlZixcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKCkgPT4ge30pO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChkLnNvdXJjZSAhPT0gVEFSR0VUKSByZXR1cm47XG4gIGNvbnN0IGVuZHBvaW50ID0gdHlwZW9mIGQuZW5kcG9pbnQgPT09ICdzdHJpbmcnID8gZC5lbmRwb2ludCA6IG51bGw7XG4gIGNvbnN0IHVybCA9IHR5cGVvZiBkLnVybCA9PT0gJ3N0cmluZycgPyBkLnVybCA6IG51bGw7XG4gIGNvbnN0IHBhZ2VVcmwgPSB0eXBlb2YgZC5wYWdlX3VybCA9PT0gJ3N0cmluZycgPyBkLnBhZ2VfdXJsIDogbG9jYXRpb24uaHJlZjtcbiAgY29uc3QgcmVzcG9uc2UgPSBkLnJlc3BvbnNlO1xuICBpZiAoIWVuZHBvaW50IHx8ICF1cmwgfHwgcmVzcG9uc2UgPT09IHVuZGVmaW5lZCkgcmV0dXJuO1xuICBicm93c2VyLnJ1bnRpbWVcbiAgICAuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnZ3JhcGhxbC1jYXB0dXJlJywgZW5kcG9pbnQsIHVybCwgcGFnZVVybCwgcmVzcG9uc2UgfSlcbiAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgY29uc29sZS53YXJuKCdbaW1tLWFyY2hpdmVdIHNlbmRNZXNzYWdlIGZhaWxlZCcsIGVycik7XG4gICAgfSk7XG59KTtcbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7QUFzQkEsTUFBTSxTQUFTO0FBQ2YsTUFBTSxRQUFRO0FBQ2QsTUFBTSxpQkFBaUI7QUFDdkIsTUFBTSwwQkFBMEI7QUFDaEMsTUFBTSxpQ0FBaUM7QUFDdkMsTUFBTSwwQkFBMEI7QUFDaEMsTUFBTSw2QkFBNkIsQ0FBQyxhQUFhLGtCQUFrQixRQUFRLFNBQVM7QUFPcEYsTUFBSSxnQkFBZ0I7QUFDcEIsTUFBSSx5QkFBeUIsb0JBQUksSUFBWTtBQUM3QyxNQUFJLGtCQUF3RDtBQUM1RCxNQUFNLG1CQUFtQixvQkFBSSxRQUFpQjtBQUM5QyxNQUFJLDhCQUE4QjtBQUNsQyxNQUFJLHVCQUFnRDtBQUNwRCxNQUFJLHdCQUE4RDtBQUNsRSxNQUFJLDBCQUFpRTtBQUVyRSxPQUFLLFFBQVEsUUFDVixZQUFZLEVBQUUsTUFBTSxpQkFBaUIsS0FBSyxTQUFTLEtBQUssQ0FBQyxFQUN6RCxNQUFNLENBQUMsUUFBaUI7QUFDdkIsWUFBUSxLQUFLLDJDQUEyQyxHQUFHO0FBQUEsRUFDN0QsQ0FBQztBQUVILFdBQVMsaUJBQXVCO0FBQzlCLFFBQUk7QUFDRixZQUFNLE1BQU0sUUFBUSxRQUFRLE9BQU8sY0FBYztBQUNqRCxZQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7QUFDOUMsYUFBTyxNQUFNO0FBQ2IsYUFBTyxRQUFRO0FBQ2YsYUFBTyxRQUFRLGFBQWE7QUFDNUIsT0FBQyxTQUFTLFFBQVEsU0FBUyxpQkFBaUIsWUFBWSxNQUFNO0FBQzlELGFBQU8sU0FBUyxNQUFNLE9BQU8sT0FBTztBQUNwQyxhQUFPLFVBQVUsTUFBTTtBQUlyQixnQkFBUSxRQUNMLFlBQVk7QUFBQSxVQUNYLE1BQU07QUFBQSxVQUNOLE9BQU87QUFBQSxVQUNQLEtBQUs7QUFBQSxVQUNMLEtBQUssU0FBUztBQUFBLFFBQ2hCLENBQUMsRUFDQSxNQUFNLE1BQU07QUFBQSxRQUFDLENBQUM7QUFBQSxNQUNuQjtBQUFBLElBQ0YsU0FBUyxLQUFLO0FBQ1osY0FBUSxLQUFLLGtEQUFrRCxHQUFHO0FBQUEsSUFDcEU7QUFBQSxFQUNGO0FBRUEsaUJBQWU7QUFFZixXQUFTLGdCQUFnQixLQUFtQztBQUMxRCxRQUFJLENBQUMsSUFBSyxRQUFPO0FBQ2pCLFVBQU0sVUFBVSxJQUFJLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxFQUFFLFlBQVk7QUFDekQsV0FBTyxRQUFRLFNBQVMsSUFBSSxVQUFVO0FBQUEsRUFDeEM7QUFFQSxNQUFNLGVBQWUsb0JBQUksSUFBSSxDQUFDLFNBQVMsZUFBZSxvQkFBb0IsQ0FBQztBQUUzRSxXQUFTLGNBQWMsTUFBNEQ7QUFDakYsUUFBSSxDQUFDLEtBQU0sUUFBTztBQUNsQixRQUFJO0FBQ0YsWUFBTSxJQUFJLElBQUksSUFBSSxNQUFNLFNBQVMsSUFBSTtBQUNyQyxVQUFJLENBQUMsYUFBYSxJQUFJLEVBQUUsU0FBUyxZQUFZLENBQUMsRUFBRyxRQUFPO0FBQ3hELFlBQU0sUUFBUSxFQUFFLFNBQVMsTUFBTSxHQUFHLEVBQUUsT0FBTyxPQUFPO0FBQ2xELFlBQU0sWUFBWSxNQUFNLFFBQVEsUUFBUTtBQUN4QyxVQUFJLGFBQWEsRUFBRyxRQUFPO0FBQzNCLFlBQU0sU0FBUyxnQkFBZ0IsTUFBTSxZQUFZLENBQUMsS0FBSyxJQUFJO0FBQzNELFlBQU0sS0FBSyxNQUFNLFlBQVksQ0FBQyxLQUFLO0FBQ25DLFVBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxFQUFFLEVBQUcsUUFBTztBQUNoRCxhQUFPLEVBQUUsUUFBUSxHQUFHO0FBQUEsSUFDdEIsUUFBUTtBQUNOLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFdBQVMsVUFBVSxJQUFzQjtBQUN2QyxVQUFNLE9BQU8sR0FBRyxzQkFBc0I7QUFDdEMsUUFBSSxLQUFLLFVBQVUsS0FBSyxLQUFLLFdBQVcsRUFBRyxRQUFPO0FBQ2xELFVBQU0sUUFBUSxPQUFPLGlCQUFpQixFQUFFO0FBQ3hDLFdBQU8sTUFBTSxlQUFlLFlBQVksTUFBTSxZQUFZO0FBQUEsRUFDNUQ7QUFFQSxXQUFTLHdCQUE4QjtBQUNyQyxzQkFBa0I7QUFDbEIsUUFBSSxDQUFDLGNBQWU7QUFDcEIsVUFBTSxZQUFZO0FBQUEsTUFDaEI7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQ0EsVUFBTSxPQUFPLG9CQUFJLElBQWE7QUFDOUIsUUFBSSxVQUFVO0FBQ2QsZUFBVyxPQUFPLFdBQVc7QUFDM0IsaUJBQVcsTUFBTSxNQUFNLEtBQUssU0FBUyxpQkFBaUIsR0FBRyxDQUFDLEdBQUc7QUFDM0QsWUFBSSxLQUFLLElBQUksRUFBRSxLQUFLLGlCQUFpQixJQUFJLEVBQUUsRUFBRztBQUM5QyxhQUFLLElBQUksRUFBRTtBQUNYLGFBQUssR0FBRyxlQUFlLElBQUksS0FBSyxFQUFFLFlBQVksTUFBTSxZQUFhO0FBQ2pFLFlBQUksQ0FBQyxVQUFVLEVBQUUsRUFBRztBQUNwQixjQUFNLE9BQU8sR0FBRyxRQUFRLFNBQVM7QUFDakMsY0FBTSxjQUFjLE9BQU8sY0FBYyxLQUFLLGFBQWEsTUFBTSxDQUFDLElBQUk7QUFDdEUsWUFBSSxlQUFlLENBQUMsdUJBQXVCLElBQUksWUFBWSxFQUFFLEVBQUc7QUFDaEUseUJBQWlCLElBQUksRUFBRTtBQUN2QixZQUFJO0FBQ0YsVUFBQyxHQUFtQixNQUFNO0FBQzFCLHFCQUFXO0FBQUEsUUFDYixRQUFRO0FBQUEsUUFFUjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsUUFBSSxVQUFVLEdBQUc7QUFDZixjQUFRLFFBQVEsWUFBWSxFQUFFLE1BQU0sc0JBQXNCLE9BQU8sUUFBUSxDQUFDLEVBQUUsTUFBTSxNQUFNO0FBQUEsTUFBQyxDQUFDO0FBQUEsSUFDNUY7QUFBQSxFQUNGO0FBRUEsV0FBUyxtQkFBbUIsUUFBUSx5QkFBK0I7QUFDakUsUUFBSSxvQkFBb0IsS0FBTTtBQUM5QixzQkFBa0IsV0FBVyx1QkFBdUIsS0FBSztBQUFBLEVBQzNEO0FBRUEsaUJBQWUsdUJBQXNDO0FBQ25ELFFBQUk7QUFDRixZQUFNLFdBQVcsTUFBTSxRQUFRLFFBQVEsWUFBWTtBQUFBLFFBQ2pELE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRCxZQUFNLE1BQU0sWUFBWSxPQUFPLGFBQWEsV0FBWSxXQUFxQyxDQUFDO0FBQzlGLHNCQUFnQixJQUFJLFlBQVk7QUFDaEMsK0JBQXlCLElBQUksSUFBSSxJQUFJLG9CQUFvQixDQUFDLENBQUM7QUFDM0QseUJBQW1CLENBQUM7QUFBQSxJQUN0QixRQUFRO0FBQ04sc0JBQWdCO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsV0FBUyx3QkFBOEI7QUFDckMsVUFBTSxPQUFPLFNBQVMsbUJBQW1CLFNBQVM7QUFDbEQsUUFBSSxDQUFDLE1BQU07QUFDVCxpQkFBVyx1QkFBdUIsR0FBRztBQUNyQztBQUFBLElBQ0Y7QUFDQSxVQUFNLFdBQVcsSUFBSSxpQkFBaUIsTUFBTSxtQkFBbUIsQ0FBQztBQUNoRSxhQUFTLFFBQVEsTUFBTSxFQUFFLFdBQVcsTUFBTSxTQUFTLEtBQUssQ0FBQztBQUN6RCxXQUFPLGlCQUFpQixVQUFVLE1BQU0sbUJBQW1CLEdBQUcsRUFBRSxTQUFTLEtBQUssQ0FBQztBQUMvRSxTQUFLLHFCQUFxQjtBQUMxQixnQkFBWSxNQUFNO0FBQ2hCLFdBQUsscUJBQXFCO0FBQUEsSUFDNUIsR0FBRyxjQUFjO0FBQUEsRUFDbkI7QUFFQSx3QkFBc0I7QUFFdEIsV0FBUyx3QkFBd0IsS0FBdUI7QUFDdEQsUUFBSSxDQUFDLE9BQU8sT0FBTyxRQUFRLFNBQVUsUUFBTztBQUM1QyxXQUFRLElBQTJDLHlCQUF5QjtBQUFBLEVBQzlFO0FBRUEsV0FBUyxrQkFBa0IsSUFBMEQ7QUFDbkYsV0FBTyxjQUFjLG9CQUFvQixjQUFjO0FBQUEsRUFDekQ7QUFFQSxXQUFTLGtCQUFrQixJQUE0QjtBQUNyRCxRQUFJO0FBQ0YsU0FBRyxNQUFNO0FBQUEsSUFDWCxRQUFRO0FBQUEsSUFFUjtBQUNBLFFBQUk7QUFDRixTQUFHLFdBQVc7QUFDZCxTQUFHLFVBQVU7QUFDYixTQUFHLGdCQUFnQixVQUFVO0FBQzdCLFNBQUcsZ0JBQWdCLEtBQUs7QUFDeEIsU0FBRyxNQUFNO0FBQ1QsVUFBSSxlQUFlLEdBQUksSUFBRyxZQUFZO0FBQ3RDLGlCQUFXLFVBQVUsTUFBTSxLQUFLLEdBQUcsaUJBQWlCLGFBQWEsQ0FBQyxHQUFHO0FBQ25FLGVBQU8sZ0JBQWdCLEtBQUs7QUFBQSxNQUM5QjtBQUNBLFNBQUcsS0FBSztBQUFBLElBQ1YsUUFBUTtBQUFBLElBRVI7QUFBQSxFQUNGO0FBRUEsV0FBUyx3QkFBOEI7QUFDckMsNEJBQXdCO0FBQ3hCLFFBQUksQ0FBQyw0QkFBNkI7QUFDbEMsZUFBVyxNQUFNLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixhQUFhLENBQUMsR0FBRztBQUNyRSxVQUFJLGtCQUFrQixFQUFFLEVBQUcsbUJBQWtCLEVBQUU7QUFBQSxJQUNqRDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLHlCQUF5QixRQUFRLGdDQUFzQztBQUM5RSxRQUFJLENBQUMsK0JBQStCLDBCQUEwQixLQUFNO0FBQ3BFLDRCQUF3QixXQUFXLHVCQUF1QixLQUFLO0FBQUEsRUFDakU7QUFFQSxXQUFTLHlCQUF5QixPQUFvQjtBQUNwRCxRQUFJLENBQUMsNEJBQTZCO0FBQ2xDLFFBQUksa0JBQWtCLE1BQU0sTUFBTSxFQUFHLG1CQUFrQixNQUFNLE1BQU07QUFBQSxFQUNyRTtBQUVBLFdBQVMsd0JBQXdCLElBQW1CO0FBQ2xELFFBQUksZ0NBQWdDLEdBQUk7QUFDeEMsa0NBQThCO0FBRTlCLFFBQUksSUFBSTtBQUNOLFlBQU0sT0FBTyxTQUFTLG1CQUFtQixTQUFTO0FBQ2xELFVBQUksTUFBTTtBQUNSLCtCQUF1QixJQUFJLGlCQUFpQixNQUFNLHlCQUF5QixDQUFDO0FBQzVFLDZCQUFxQixRQUFRLE1BQU07QUFBQSxVQUNqQyxXQUFXO0FBQUEsVUFDWCxTQUFTO0FBQUEsVUFDVCxZQUFZO0FBQUEsVUFDWixpQkFBaUIsQ0FBQyxLQUFLO0FBQUEsUUFDekIsQ0FBQztBQUFBLE1BQ0g7QUFDQSxpQkFBVyxhQUFhLDRCQUE0QjtBQUNsRCxpQkFBUyxpQkFBaUIsV0FBVywwQkFBMEIsSUFBSTtBQUFBLE1BQ3JFO0FBQ0EsZ0NBQTBCLFlBQVksdUJBQXVCLHVCQUF1QjtBQUNwRiwrQkFBeUIsQ0FBQztBQUMxQjtBQUFBLElBQ0Y7QUFFQSxRQUFJLHNCQUFzQjtBQUN4QiwyQkFBcUIsV0FBVztBQUNoQyw2QkFBdUI7QUFBQSxJQUN6QjtBQUNBLFFBQUksMEJBQTBCLE1BQU07QUFDbEMsbUJBQWEscUJBQXFCO0FBQ2xDLDhCQUF3QjtBQUFBLElBQzFCO0FBQ0EsUUFBSSw0QkFBNEIsTUFBTTtBQUNwQyxvQkFBYyx1QkFBdUI7QUFDckMsZ0NBQTBCO0FBQUEsSUFDNUI7QUFDQSxlQUFXLGFBQWEsNEJBQTRCO0FBQ2xELGVBQVMsb0JBQW9CLFdBQVcsMEJBQTBCLElBQUk7QUFBQSxJQUN4RTtBQUFBLEVBQ0Y7QUFFQSxpQkFBZSw4QkFBNkM7QUFDMUQsUUFBSTtBQUNGLFlBQU0sU0FBUyxNQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksVUFBVTtBQUN6RCw4QkFBd0Isd0JBQXdCLE9BQU8sUUFBUSxDQUFDO0FBQUEsSUFDbEUsUUFBUTtBQUNOLDhCQUF3QixLQUFLO0FBQUEsSUFDL0I7QUFBQSxFQUNGO0FBRUEsVUFBUSxRQUFRLFVBQVUsWUFBWSxDQUFDLFNBQVMsYUFBYTtBQUMzRCxRQUFJLGFBQWEsV0FBVyxDQUFDLFFBQVEsU0FBVTtBQUMvQyw0QkFBd0Isd0JBQXdCLFFBQVEsU0FBUyxRQUFRLENBQUM7QUFBQSxFQUM1RSxDQUFDO0FBRUQsT0FBSyw0QkFBNEI7QUFFakMsU0FBTyxpQkFBaUIsV0FBVyxDQUFDLFVBQXdCO0FBQzFELFFBQUksTUFBTSxXQUFXLE9BQVE7QUFDN0IsVUFBTSxPQUFPLE1BQU07QUFDbkIsUUFBSSxDQUFDLFFBQVEsT0FBTyxTQUFTLFNBQVU7QUFDdkMsVUFBTSxJQUFJO0FBRVYsUUFBSSxFQUFFLFdBQVcsT0FBTztBQUN0QixjQUFRLFFBQ0wsWUFBWTtBQUFBLFFBQ1gsTUFBTTtBQUFBLFFBQ04sS0FBSyxPQUFPLEVBQUUsUUFBUSxXQUFXLEVBQUUsTUFBTSxTQUFTO0FBQUEsTUFDcEQsQ0FBQyxFQUNBLE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUNqQjtBQUFBLElBQ0Y7QUFFQSxRQUFJLEVBQUUsV0FBVyxPQUFRO0FBQ3pCLFVBQU0sV0FBVyxPQUFPLEVBQUUsYUFBYSxXQUFXLEVBQUUsV0FBVztBQUMvRCxVQUFNLE1BQU0sT0FBTyxFQUFFLFFBQVEsV0FBVyxFQUFFLE1BQU07QUFDaEQsVUFBTSxVQUFVLE9BQU8sRUFBRSxhQUFhLFdBQVcsRUFBRSxXQUFXLFNBQVM7QUFDdkUsVUFBTSxXQUFXLEVBQUU7QUFDbkIsUUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLGFBQWEsT0FBVztBQUNqRCxZQUFRLFFBQ0wsWUFBWSxFQUFFLE1BQU0sbUJBQW1CLFVBQVUsS0FBSyxTQUFTLFNBQVMsQ0FBQyxFQUN6RSxNQUFNLENBQUMsUUFBUTtBQUNkLGNBQVEsS0FBSyxvQ0FBb0MsR0FBRztBQUFBLElBQ3RELENBQUM7QUFBQSxFQUNMLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
