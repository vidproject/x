var browser=globalThis.browser??globalThis.chrome;

// src/lib/config.ts
var DEFAULT_SETTINGS = {
  pat: "",
  owner: "vidproject",
  repo: "x",
  // The repo's current default branch is "master". If you fork or rename
  // it later, update Settings before the next capture.
  branch: "master",
  enabled: true,
  autoCapture: true,
  configuredAt: null,
  autoScrollIntervalSec: 6,
  updateExisting: true,
  lowBandwidthBrowsing: false
};
var FALLBACK_ACCOUNTS = [
  { handle: "DHSgov", label: "Department of Homeland Security", category: "core" },
  { handle: "ICEgov", label: "U.S. Immigration and Customs Enforcement", category: "core" },
  { handle: "CBP", label: "U.S. Customs and Border Protection", category: "core" },
  { handle: "USCIS", label: "U.S. Citizenship and Immigration Services", category: "core" },
  { handle: "WhiteHouse", label: "The White House", category: "core" },
  { handle: "PressSec", label: "White House Press Secretary", category: "core" },
  { handle: "POTUS", label: "President of the United States", category: "core" },
  { handle: "USDOL", label: "U.S. Department of Labor", category: "core" },
  { handle: "RapidResponse47", label: "Rapid Response 47", category: "core" },
  { handle: "StephenM", label: "Stephen Miller", category: "core" },
  { handle: "GregoryKBovino", label: "Gregory Bovino", category: "core" },
  { handle: "RealTomHoman", label: "Thomas D. Homan", category: "core" }
];
var VERIFY_CONNECTION_INTERVAL_MS = 10 * 60 * 1e3;

// src/lib/crypto.ts
var SALT_STORAGE_KEY = "__imm_archive_salt__";
var ENVELOPE_PREFIX = "v1:";
var derivedKeyCache = null;
var derivedKeyCacheSalt = null;
function toBase64(buf) {
  let s = "";
  for (const b of buf) s += String.fromCharCode(b);
  return btoa(s);
}
function fromBase64(s) {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
async function loadOrCreateSalt() {
  const stored = await browser.storage.local.get(SALT_STORAGE_KEY);
  const v = stored[SALT_STORAGE_KEY];
  if (typeof v === "string" && v.length > 0) {
    return { saltB64: v, salt: fromBase64(v) };
  }
  const salt = crypto.getRandomValues(new Uint8Array(32));
  const saltB64 = toBase64(salt);
  await browser.storage.local.set({ [SALT_STORAGE_KEY]: saltB64 });
  return { saltB64, salt };
}
async function deriveKey() {
  const { saltB64, salt } = await loadOrCreateSalt();
  if (derivedKeyCache !== null && derivedKeyCacheSalt === saltB64) {
    return derivedKeyCache;
  }
  const seed = new TextEncoder().encode(
    `${browser.runtime.id}|${browser.runtime.getManifest().version}|imm-archive-pat-v1`
  );
  const combined = new Uint8Array(seed.length + salt.length);
  combined.set(seed, 0);
  combined.set(salt, seed.length);
  const hash = await crypto.subtle.digest("SHA-256", combined);
  const key = await crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, [
    "encrypt",
    "decrypt"
  ]);
  derivedKeyCache = key;
  derivedKeyCacheSalt = saltB64;
  return key;
}
function isEncryptedPat(v) {
  return v.startsWith(ENVELOPE_PREFIX);
}
async function encryptPat(plaintext) {
  if (!plaintext) return "";
  const key = await deriveKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext)
  );
  return `${ENVELOPE_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(ct))}`;
}
async function decryptPat(envelope) {
  if (!envelope) return "";
  if (!envelope.startsWith(ENVELOPE_PREFIX)) return envelope;
  const parts = envelope.slice(ENVELOPE_PREFIX.length).split(":");
  if (parts.length !== 2) return "";
  const [ivB64, ctB64] = parts;
  if (!ivB64 || !ctB64) return "";
  try {
    const key = await deriveKey();
    const iv = fromBase64(ivB64);
    const ct = fromBase64(ctB64);
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ct
    );
    return new TextDecoder().decode(pt);
  } catch {
    return "";
  }
}

// src/lib/storage.ts
var DEFAULT_CONNECTION = {
  status: "unknown",
  login: null,
  checkedAt: null,
  error: null,
  defaultBranch: null,
  configuredBranchExists: null,
  rateLimitResetAt: null
};
var DEFAULTS = {
  settings: { ...DEFAULT_SETTINGS },
  accounts: [...FALLBACK_ACCOUNTS],
  accountsRefreshedAt: null,
  archiveSnapshot: null,
  connection: { ...DEFAULT_CONNECTION },
  counters: {},
  runBuffers: {},
  activity: [],
  recentTweetSightings: [],
  committedIndex: {},
  refetchQueue: {},
  mediaCrawlQueue: {},
  threadOpenQueue: {},
  threadOpenSeen: {},
  refetchSession: null,
  mediaCrawlSession: null,
  threadOpenSession: null,
  autoScrollSession: null
};
async function getRaw(key) {
  const result = await browser.storage.local.get(key);
  const value = result[key];
  if (value === void 0) {
    return structuredClone(DEFAULTS[key]);
  }
  return value;
}
async function setRaw(key, value) {
  await browser.storage.local.set({ [key]: value });
}
async function getSettings() {
  const stored = await getRaw("settings");
  const merged = { ...DEFAULT_SETTINGS, ...stored };
  if (merged.pat && isEncryptedPat(merged.pat)) {
    try {
      merged.pat = await decryptPat(merged.pat);
    } catch {
      merged.pat = "";
    }
  }
  return merged;
}
async function setSettings(s) {
  const toWrite = { ...s };
  if (toWrite.pat && !isEncryptedPat(toWrite.pat)) {
    toWrite.pat = await encryptPat(toWrite.pat);
  }
  await setRaw("settings", toWrite);
}
async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  await setSettings(next);
  return next;
}
async function getAccounts() {
  return getRaw("accounts");
}
async function getArchiveSnapshot() {
  return getRaw("archiveSnapshot");
}
async function getConnection() {
  const c = await getRaw("connection");
  const out = {
    ...c,
    defaultBranch: c.defaultBranch === void 0 ? null : c.defaultBranch,
    configuredBranchExists: c.configuredBranchExists === void 0 ? null : c.configuredBranchExists,
    rateLimitResetAt: c.rateLimitResetAt === void 0 ? null : c.rateLimitResetAt
  };
  return out;
}
async function getCounters() {
  return getRaw("counters");
}
async function getRunBuffers() {
  return getRaw("runBuffers");
}
async function getActivity() {
  return getRaw("activity");
}
async function clearAll() {
  await browser.storage.local.clear();
}

// src/options.ts
var $ = (id) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`missing element #${id}`);
  return el;
};
var form = $("settings-form");
var ownerInput = $("owner");
var repoInput = $("repo");
var branchInput = $("branch");
var patInput = $("pat");
var revealBtn = $("reveal-pat");
var saveStatus = $("save-status");
var connDetail = $("conn-detail");
var accountList = $("account-readonly");
var refreshBtn = $("refresh-accounts");
var diagBox = $("diagnostics");
var copyDiagBtn = $("copy-diagnostics");
var clearStorageBtn = $("clear-storage");
var diagStatus = $("diag-status");
async function send(msg) {
  return browser.runtime.sendMessage(msg);
}
function setStatus(el, kind, msg) {
  el.className = kind ? `status ${kind}` : "status";
  el.textContent = msg;
}
function isWriteAuthError(message) {
  return typeof message === "string" && /Resource not accessible by personal access token|\/git\/blobs|\/git\/refs/i.test(message);
}
async function loadSettings() {
  const s = await getSettings();
  ownerInput.value = s.owner || DEFAULT_SETTINGS.owner;
  repoInput.value = s.repo || DEFAULT_SETTINGS.repo;
  branchInput.value = s.branch || DEFAULT_SETTINGS.branch;
  if (s.pat) {
    patInput.value = s.pat;
    patInput.placeholder = `\u2026${s.pat.slice(-4)}`;
  }
  await paintConnDetail();
}
async function paintConnDetail() {
  const conn = await getConnection();
  const s = await getSettings();
  const lines = [];
  lines.push(`Status: ${conn.status}`);
  if (conn.login) lines.push(`Logged in as: @${conn.login}`);
  lines.push(`Repository: ${s.owner || "?"}/${s.repo || "?"}@${s.branch || "?"}`);
  if (conn.checkedAt) lines.push(`Last checked: ${conn.checkedAt}`);
  if (conn.status === "rate-limited" && conn.rateLimitResetAt !== null) {
    const resetIso = new Date(conn.rateLimitResetAt * 1e3).toISOString();
    const deltaSec = conn.rateLimitResetAt - Math.floor(Date.now() / 1e3);
    const inLabel = deltaSec <= 0 ? "momentarily" : deltaSec < 60 ? `in ${deltaSec}s` : deltaSec < 3600 ? `in ${Math.round(deltaSec / 60)}m` : `in ${Math.round(deltaSec / 3600)}h`;
    lines.push(`Rate limit resets: ${resetIso} (${inLabel})`);
  }
  if (conn.error) lines.push(`Error: ${conn.error}`);
  connDetail.textContent = lines.join("\n");
}
async function paintAccounts() {
  const list = await getAccounts();
  accountList.replaceChildren();
  for (const a of list) {
    const li = document.createElement("li");
    const handle = document.createElement("span");
    handle.className = "handle";
    handle.textContent = `@${a.handle}`;
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = a.label;
    li.append(handle, label);
    accountList.append(li);
  }
}
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const pat = patInput.value.trim();
  const owner = ownerInput.value.trim();
  const repo = repoInput.value.trim();
  const branch = branchInput.value.trim() || "main";
  if (!pat || !owner || !repo) {
    setStatus(saveStatus, "err", "All fields are required.");
    return;
  }
  setStatus(saveStatus, "", "Saving\u2026");
  await updateSettings({ pat, owner, repo, branch, configuredAt: Date.now() });
  setStatus(saveStatus, "", "Verifying\u2026");
  await send({ type: "verify-connection" });
  await send({ type: "refresh-accounts" });
  const conn = await getConnection();
  if (conn.status === "ok") {
    setStatus(saveStatus, "ok", `Connected as @${conn.login ?? "?"}.`);
  } else if (conn.status === "auth-error") {
    setStatus(
      saveStatus,
      "err",
      isWriteAuthError(conn.error) ? "PAT can read this repo but cannot write. Set Contents: Read & Write." : "Auth failed - check the PAT and its repo scope."
    );
  } else if (conn.status === "rate-limited") {
    setStatus(saveStatus, "warn", "Rate-limited \u2014 token is valid but GitHub is throttling.");
  } else if (conn.status === "network-error") {
    setStatus(saveStatus, "err", "Network error \u2014 check connectivity.");
  } else {
    setStatus(saveStatus, "err", `Verification: ${conn.status}`);
  }
  await paintConnDetail();
  await paintAccounts();
  await refreshDiag();
});
revealBtn.addEventListener("click", () => {
  if (patInput.type === "password") {
    patInput.type = "text";
    revealBtn.textContent = "Hide";
  } else {
    patInput.type = "password";
    revealBtn.textContent = "Show";
  }
});
refreshBtn.addEventListener("click", async () => {
  refreshBtn.disabled = true;
  try {
    await send({ type: "refresh-accounts" });
    await paintAccounts();
    setStatus(diagStatus, "ok", "Accounts refreshed.");
  } catch (err) {
    setStatus(diagStatus, "err", `Refresh failed: ${err.message}`);
  } finally {
    refreshBtn.disabled = false;
  }
});
async function refreshDiag() {
  const [settings, conn, accounts, counters, buffers, activity, archiveSnapshot] = await Promise.all([
    getSettings(),
    getConnection(),
    getAccounts(),
    getCounters(),
    getRunBuffers(),
    getActivity(),
    getArchiveSnapshot()
  ]);
  const redactedBuffers = Object.fromEntries(
    Object.entries(buffers).map(([k, b]) => [
      k,
      {
        run_id: b.run_id,
        started_at: b.started_at,
        last_capture_at: b.last_capture_at,
        tweets_count: Object.keys(b.tweets_by_id).length,
        observed_count: b.tweet_ids_observed.length,
        endpoints_seen: b.endpoints_seen,
        source_url: b.source_url
      }
    ])
  );
  const dump = {
    version: browser.runtime.getManifest().version,
    user_agent: navigator.userAgent,
    settings: {
      owner: settings.owner,
      repo: settings.repo,
      branch: settings.branch,
      autoCapture: settings.autoCapture,
      updateExisting: settings.updateExisting,
      configuredAt: settings.configuredAt,
      patSet: settings.pat.length > 0,
      patSuffix: settings.pat.length >= 4 ? settings.pat.slice(-4) : ""
    },
    connection: conn,
    accounts,
    counters,
    archiveSnapshot: archiveSnapshot ? {
      generated_at: archiveSnapshot.generated_at,
      fetched_at: archiveSnapshot.fetched_at,
      accounts: Object.keys(archiveSnapshot.accounts).length
    } : null,
    runBuffers: redactedBuffers,
    activity_tail_size: activity.length,
    activity_recent: activity.slice(0, 30)
  };
  diagBox.value = JSON.stringify(dump, null, 2);
}
copyDiagBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(diagBox.value);
  setStatus(diagStatus, "ok", "Copied diagnostics to clipboard.");
});
clearStorageBtn.addEventListener("click", async () => {
  const ok = window.confirm(
    "Clear extension storage? This erases your PAT, settings, counters, buffered captures, and activity tail. There is no undo."
  );
  if (!ok) return;
  await clearAll();
  setStatus(diagStatus, "warn", "Storage cleared.");
  await loadSettings();
  await paintAccounts();
  await refreshDiag();
});
void loadSettings();
void paintAccounts();
void refreshDiag();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9jb25maWcudHMiLCAiLi4vc3JjL2xpYi9jcnlwdG8udHMiLCAiLi4vc3JjL2xpYi9zdG9yYWdlLnRzIiwgIi4uL3NyYy9vcHRpb25zLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgdHlwZSB7IEFjY291bnRDb25maWcsIFNldHRpbmdzIH0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX1NFVFRJTkdTOiBTZXR0aW5ncyA9IHtcbiAgcGF0OiAnJyxcbiAgb3duZXI6ICd2aWRwcm9qZWN0JyxcbiAgcmVwbzogJ3gnLFxuICAvLyBUaGUgcmVwbydzIGN1cnJlbnQgZGVmYXVsdCBicmFuY2ggaXMgXCJtYXN0ZXJcIi4gSWYgeW91IGZvcmsgb3IgcmVuYW1lXG4gIC8vIGl0IGxhdGVyLCB1cGRhdGUgU2V0dGluZ3MgYmVmb3JlIHRoZSBuZXh0IGNhcHR1cmUuXG4gIGJyYW5jaDogJ21hc3RlcicsXG4gIGVuYWJsZWQ6IHRydWUsXG4gIGF1dG9DYXB0dXJlOiB0cnVlLFxuICBjb25maWd1cmVkQXQ6IG51bGwsXG4gIGF1dG9TY3JvbGxJbnRlcnZhbFNlYzogNixcbiAgdXBkYXRlRXhpc3Rpbmc6IHRydWUsXG4gIGxvd0JhbmR3aWR0aEJyb3dzaW5nOiBmYWxzZSxcbn07XG5cbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NSU5fU0VDID0gMztcbmV4cG9ydCBjb25zdCBBVVRPX1NDUk9MTF9NQVhfU0VDID0gNjA7XG5cbi8vIEJ1aWx0LWluIGZhbGxiYWNrIGlmIGNvbmZpZy9hY2NvdW50cy55YW1sIGNhbm5vdCBiZSBmZXRjaGVkIChlLmcuLCBiZWZvcmUgdGhlXG4vLyByZXBvIGhhcyBiZWVuIGluaXRpYWxpemVkIG9yIFBBVCBtaXNjb25maWd1cmVkKS4gS2VwdCBpbiBzeW5jIHdpdGggdGhlIGZpbGUuXG5leHBvcnQgY29uc3QgRkFMTEJBQ0tfQUNDT1VOVFM6IEFjY291bnRDb25maWdbXSA9IFtcbiAgeyBoYW5kbGU6ICdESFNnb3YnLCBsYWJlbDogJ0RlcGFydG1lbnQgb2YgSG9tZWxhbmQgU2VjdXJpdHknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnSUNFZ292JywgbGFiZWw6ICdVLlMuIEltbWlncmF0aW9uIGFuZCBDdXN0b21zIEVuZm9yY2VtZW50JywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0NCUCcsIGxhYmVsOiAnVS5TLiBDdXN0b21zIGFuZCBCb3JkZXIgUHJvdGVjdGlvbicsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0NJUycsIGxhYmVsOiAnVS5TLiBDaXRpemVuc2hpcCBhbmQgSW1taWdyYXRpb24gU2VydmljZXMnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnV2hpdGVIb3VzZScsIGxhYmVsOiAnVGhlIFdoaXRlIEhvdXNlJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1ByZXNzU2VjJywgbGFiZWw6ICdXaGl0ZSBIb3VzZSBQcmVzcyBTZWNyZXRhcnknLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnUE9UVVMnLCBsYWJlbDogJ1ByZXNpZGVudCBvZiB0aGUgVW5pdGVkIFN0YXRlcycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdVU0RPTCcsIGxhYmVsOiAnVS5TLiBEZXBhcnRtZW50IG9mIExhYm9yJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ1JhcGlkUmVzcG9uc2U0NycsIGxhYmVsOiAnUmFwaWQgUmVzcG9uc2UgNDcnLCBjYXRlZ29yeTogJ2NvcmUnIH0sXG4gIHsgaGFuZGxlOiAnU3RlcGhlbk0nLCBsYWJlbDogJ1N0ZXBoZW4gTWlsbGVyJywgY2F0ZWdvcnk6ICdjb3JlJyB9LFxuICB7IGhhbmRsZTogJ0dyZWdvcnlLQm92aW5vJywgbGFiZWw6ICdHcmVnb3J5IEJvdmlubycsIGNhdGVnb3J5OiAnY29yZScgfSxcbiAgeyBoYW5kbGU6ICdSZWFsVG9tSG9tYW4nLCBsYWJlbDogJ1Rob21hcyBELiBIb21hbicsIGNhdGVnb3J5OiAnY29yZScgfSxcbl07XG5cbi8vIEdyYXBoUUwgZW5kcG9pbnQgbmFtZXMgd2UgY2FyZSBhYm91dCAobWF0Y2hlZCBieSBzdWJzdHJpbmcgYWdhaW5zdCBVUkwgcGF0aCkuXG5leHBvcnQgY29uc3QgVFdFRVRfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdVc2VyVHdlZXRzJyxcbiAgJ1VzZXJUd2VldHNBbmRSZXBsaWVzJyxcbiAgJ1VzZXJNZWRpYScsXG4gICdVc2VySGlnaGxpZ2h0c1R3ZWV0cycsXG4gICdUd2VldERldGFpbCcsXG4gICdUd2VldFJlc3VsdEJ5UmVzdElkJyxcbiAgJ0xpa2VzJyxcbiAgJ0Jvb2ttYXJrcycsXG4gICdIb21lVGltZWxpbmUnLFxuICAnSG9tZUxhdGVzdFRpbWVsaW5lJyxcbiAgJ1NlYXJjaFRpbWVsaW5lJyxcbiAgJ0xpc3RMYXRlc3RUd2VldHNUaW1lbGluZScsXG5dKTtcblxuLy8gRW5kcG9pbnRzIHRoYXQgY2FycnkgQ29tbXVuaXR5IE5vdGUgYm9kaWVzIFx1MjAxNCBjYXB0dXJlZCBmb3IgY29tcGxldGVuZXNzIGJ1dFxuLy8gdGhleSBkb24ndCBpbnRyb2R1Y2UgbmV3IHR3ZWV0cywgc28gdGhleSBkb24ndCBuZWVkIHRvIGJlIGluIFRXRUVUX0VORFBPSU5UUy5cbmV4cG9ydCBjb25zdCBCSVJEV0FUQ0hfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbXG4gICdCaXJkd2F0Y2hGZXRjaE9uZU5vdGUnLFxuICAnQmlyZHdhdGNoRmV0Y2hOb3RlcycsXG5dKTtcblxuLy8gQXV4aWxpYXJ5IGVuZHBvaW50cyB3ZSBkb24ndCBleHRyYWN0IHR3ZWV0cyBmcm9tIGJ1dCB1c2UgZm9yIGNvbnRleHQgKGUuZy4sXG4vLyB0byBsZWFybiBhY2NvdW50X2lkIDwtPiBoYW5kbGUgYmluZGluZ3MpLlxuZXhwb3J0IGNvbnN0IFBST0ZJTEVfRU5EUE9JTlRTOiBSZWFkb25seVNldDxzdHJpbmc+ID0gbmV3IFNldChbJ1VzZXJCeVNjcmVlbk5hbWUnLCAnVXNlckJ5UmVzdElkJ10pO1xuXG4vLyBFbmRwb2ludHMgd2hvc2UgcmVzcG9uc2VzIGFyZSBzY29wZWQgdG8gYSBwYXJ0aWN1bGFyIGFjY291bnQgb3Jcbi8vIGNvbnZlcnNhdGlvbiBcdTIwMTQgaS5lLiB2aXNpdGluZyBgLzxoYW5kbGU+YCAvIGAvPGhhbmRsZT4vd2l0aF9yZXBsaWVzYCxcbi8vIGxvb2tpbmcgYXQgb25lIHR3ZWV0LCBldGMuIEV2ZXJ5IHR3ZWV0IHJldHVybmVkIGJ5IHRoZXNlIGVuZHBvaW50cyBpc1xuLy8gZWl0aGVyIGF1dGhvcmVkIGJ5IHRoZSB0cmFja2VkIGFjY291bnQgb3IgZGlyZWN0bHkgcmVmZXJlbmNlZCBieSB0aGVtXG4vLyAocmV0d2VldGVkLCBxdW90ZWQsIHJlcGxpZWQgdG8pLCBzbyB3ZSBrZWVwIGV2ZXJ5dGhpbmcgd2Ugc2VlIHJhdGhlclxuLy8gdGhhbiBkcm9wcGluZyBub24tdHJhY2tlZCBhdXRob3JzLiBUaGF0IHdheSBhIHJldHdlZXQgb2YgYSBub24tdHJhY2tlZFxuLy8gYWNjb3VudCBzdGlsbCBnZXRzIGl0cyBvcmlnaW5hbC10d2VldCBjb250ZW50IGFyY2hpdmVkLlxuLy9cbi8vIEVuZHBvaW50cyBOT1QgaW4gdGhpcyBzZXQgKEhvbWVUaW1lbGluZSwgU2VhcmNoVGltZWxpbmUsIExpa2VzLCBldGMuKVxuLy8gc3RpbGwgZ2V0IGZpbHRlcmVkIHRvIHRyYWNrZWQtaGFuZGxlIGF1dGhvcnMgXHUyMDE0IHNlZSB0aGUgc3BlYydzXG4vLyBcIkJyb3dzaW5nIG15IGhvbWUgdGltZWxpbmUgaXMgaWdub3JlZFwiIHJ1bGUuXG5leHBvcnQgY29uc3QgVVNFUl9QQUdFX0VORFBPSU5UUzogUmVhZG9ubHlTZXQ8c3RyaW5nPiA9IG5ldyBTZXQoW1xuICAnVXNlclR3ZWV0cycsXG4gICdVc2VyVHdlZXRzQW5kUmVwbGllcycsXG4gICdVc2VyTWVkaWEnLFxuICAnVXNlckhpZ2hsaWdodHNUd2VldHMnLFxuICAnVHdlZXREZXRhaWwnLFxuICAnVHdlZXRSZXN1bHRCeVJlc3RJZCcsXG5dKTtcblxuLy8gTWF4aW11bSB0d2VldHMgdG8gYnVmZmVyIHBlciBoYW5kbGUgYmVmb3JlIGZvcmNpbmcgYSBjb21taXQuXG5leHBvcnQgY29uc3QgRkxVU0hfVFdFRVRfVEhSRVNIT0xEID0gMjAwO1xuXG4vLyBJZGxlIGRlbGF5IGFmdGVyIHRoZSBsYXN0IGNhcHR1cmUgYmVmb3JlIGF1dG8tZmx1c2hpbmcgYSBoYW5kbGUncyBidWZmZXIuXG5leHBvcnQgY29uc3QgRkxVU0hfSURMRV9NUyA9IDQ1XzAwMDtcblxuLy8gSG93IGxvbmcgYW4gYWxhcm0tYmFzZWQgZmx1c2ggc3dlZXAgd2FpdHMgYmV0d2VlbiBjaGVja3MuXG5leHBvcnQgY29uc3QgRkxVU0hfQUxBUk1fTUlOVVRFUyA9IDE7XG5cbi8vIEFjdGl2aXR5IHRhaWwgc2l6ZS5cbmV4cG9ydCBjb25zdCBBQ1RJVklUWV9UQUlMX01BWCA9IDI1MDtcblxuLy8gUGVyaW9kaWMgcmUtdmVyaWZpY2F0aW9uIG9mIHRoZSBHaXRIdWIgY29ubmVjdGlvbiAobXMpLlxuZXhwb3J0IGNvbnN0IFZFUklGWV9DT05ORUNUSU9OX0lOVEVSVkFMX01TID0gMTAgKiA2MCAqIDEwMDA7XG5cbmV4cG9ydCBjb25zdCBUV0VFVF9VUkxfUFJFRklYID0gJ2h0dHBzOi8veC5jb20nO1xuIiwgIi8qKlxuICogY3J5cHRvLnRzIFx1MjAxNCBhdC1yZXN0IGVuY3J5cHRpb24gZm9yIHNlbnNpdGl2ZSBzZXR0aW5ncyAodGhlIFBBVCkuXG4gKlxuICogVGhyZWF0IG1vZGVsOiBhbiBhdHRhY2tlciB3aG8gcmVhZHMgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgKGRldnRvb2xzLCBhXG4gKiBmb3Jnb3R0ZW4gYmFja3VwLCBhIG1pc2NvbmZpZ3VyZWQgcHJvZmlsZSBzeW5jKSBzaG91bGQgbm90IHNlZSBhIHVzYWJsZVxuICogR2l0SHViIFBBVCBpbiBwbGFpbnRleHQuIEEgZGV0ZXJtaW5lZCBhdHRhY2tlciB3aXRoIHRoZSBleHRlbnNpb24ncyBzb3VyY2VcbiAqIGNhbiBzdGlsbCBkZXJpdmUgdGhlIGtleSBcdTIwMTQgd2UgbWFrZSBubyBjbGFpbSBvZiBcInJlYWxcIiBjcnlwdG9ncmFwaGljXG4gKiBjb25maWRlbnRpYWxpdHkuIFRoZSBhaW0gaXMgdG8gcmFpc2UgdGhlIGJhciBzbyB0aGUgUEFUIGlzbid0IGEgY29weWFibGVcbiAqIHN0cmluZyBzaXR0aW5nIG5leHQgdG8gaXRzIGtleSBuYW1lIGluIGV4dGVuc2lvbiBzdG9yYWdlLlxuICpcbiAqIFNjaGVtZTpcbiAqICAgLSBPbiBmaXJzdCBlbmNyeXB0aW9uIHdlIGdlbmVyYXRlIGEgMzItYnl0ZSBzYWx0IGFuZCBwZXJzaXN0IGl0IGluXG4gKiAgICAgYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAgdW5kZXIgYF9faW1tX2FyY2hpdmVfc2FsdF9fYC5cbiAqICAgLSBXZSBkZXJpdmUgYW4gQUVTLUdDTSBrZXkgYnkgU0hBLTI1NidpbmcgYHNhbHQgfHwgcnVudGltZS5pZCB8fCB2ZXJzaW9uXG4gKiAgICAgfHwgXCJpbW0tYXJjaGl2ZS1wYXQtdjFcImAuIFRoZSBzYWx0IGJlaW5nIHBlci1pbnN0YWxsIG1lYW5zIHR3byBjb3BpZXNcbiAqICAgICBvZiB0aGUgZXh0ZW5zaW9uIGRvbid0IHNoYXJlIGEga2V5LiBUaGUgcnVudGltZS5pZCBpcyB0aGUgZXh0ZW5zaW9uJ3NcbiAqICAgICBVVUlEIFx1MjAxNCBzdGFibGUgZm9yIGEgZ2l2ZW4gaW5zdGFsbCBidXQgdW5rbm93biB0byBhIHJlbW90ZSBhdHRhY2tlci5cbiAqICAgLSBQbGFpbnRleHQgaXMgZW5jcnlwdGVkIHdpdGggYSBmcmVzaCAxMi1ieXRlIElWLiBUaGUgZW52ZWxvcGUgZm9ybWF0IGlzXG4gKiAgICAgYHYxOjxpdi1iNjQ+OjxjaXBoZXJ0ZXh0LWI2ND5gIGFuZCBpcyB3aGF0IGdldHMgc3RvcmVkLlxuICpcbiAqIEJhY2t3YXJkcyBjb21wYXRpYmlsaXR5OiBhbiB1bnByZWZpeGVkIHZhbHVlIGlzIHRyZWF0ZWQgYXMgbGVnYWN5XG4gKiBwbGFpbnRleHQsIGRlY3J5cHRlZCB0byBpdHNlbGYsIGFuZCByZS1lbmNyeXB0ZWQgb24gdGhlIG5leHQgd3JpdGUuXG4gKi9cblxuY29uc3QgU0FMVF9TVE9SQUdFX0tFWSA9ICdfX2ltbV9hcmNoaXZlX3NhbHRfXyc7XG5jb25zdCBFTlZFTE9QRV9QUkVGSVggPSAndjE6JztcblxubGV0IGRlcml2ZWRLZXlDYWNoZTogQ3J5cHRvS2V5IHwgbnVsbCA9IG51bGw7XG5sZXQgZGVyaXZlZEtleUNhY2hlU2FsdDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG5cbmZ1bmN0aW9uIHRvQmFzZTY0KGJ1ZjogVWludDhBcnJheSk6IHN0cmluZyB7XG4gIGxldCBzID0gJyc7XG4gIGZvciAoY29uc3QgYiBvZiBidWYpIHMgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShiKTtcbiAgcmV0dXJuIGJ0b2Eocyk7XG59XG5cbmZ1bmN0aW9uIGZyb21CYXNlNjQoczogc3RyaW5nKTogVWludDhBcnJheSB7XG4gIGNvbnN0IGJpbiA9IGF0b2Iocyk7XG4gIGNvbnN0IG91dCA9IG5ldyBVaW50OEFycmF5KGJpbi5sZW5ndGgpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGJpbi5sZW5ndGg7IGkrKykgb3V0W2ldID0gYmluLmNoYXJDb2RlQXQoaSk7XG4gIHJldHVybiBvdXQ7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWRPckNyZWF0ZVNhbHQoKTogUHJvbWlzZTx7IHNhbHRCNjQ6IHN0cmluZzsgc2FsdDogVWludDhBcnJheSB9PiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoU0FMVF9TVE9SQUdFX0tFWSk7XG4gIGNvbnN0IHYgPSBzdG9yZWRbU0FMVF9TVE9SQUdFX0tFWV07XG4gIGlmICh0eXBlb2YgdiA9PT0gJ3N0cmluZycgJiYgdi5sZW5ndGggPiAwKSB7XG4gICAgcmV0dXJuIHsgc2FsdEI2NDogdiwgc2FsdDogZnJvbUJhc2U2NCh2KSB9O1xuICB9XG4gIGNvbnN0IHNhbHQgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDMyKSk7XG4gIGNvbnN0IHNhbHRCNjQgPSB0b0Jhc2U2NChzYWx0KTtcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLnNldCh7IFtTQUxUX1NUT1JBR0VfS0VZXTogc2FsdEI2NCB9KTtcbiAgcmV0dXJuIHsgc2FsdEI2NCwgc2FsdCB9O1xufVxuXG5hc3luYyBmdW5jdGlvbiBkZXJpdmVLZXkoKTogUHJvbWlzZTxDcnlwdG9LZXk+IHtcbiAgY29uc3QgeyBzYWx0QjY0LCBzYWx0IH0gPSBhd2FpdCBsb2FkT3JDcmVhdGVTYWx0KCk7XG4gIGlmIChkZXJpdmVkS2V5Q2FjaGUgIT09IG51bGwgJiYgZGVyaXZlZEtleUNhY2hlU2FsdCA9PT0gc2FsdEI2NCkge1xuICAgIHJldHVybiBkZXJpdmVkS2V5Q2FjaGU7XG4gIH1cbiAgY29uc3Qgc2VlZCA9IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShcbiAgICBgJHticm93c2VyLnJ1bnRpbWUuaWR9fCR7YnJvd3Nlci5ydW50aW1lLmdldE1hbmlmZXN0KCkudmVyc2lvbn18aW1tLWFyY2hpdmUtcGF0LXYxYFxuICApO1xuICBjb25zdCBjb21iaW5lZCA9IG5ldyBVaW50OEFycmF5KHNlZWQubGVuZ3RoICsgc2FsdC5sZW5ndGgpO1xuICBjb21iaW5lZC5zZXQoc2VlZCwgMCk7XG4gIGNvbWJpbmVkLnNldChzYWx0LCBzZWVkLmxlbmd0aCk7XG4gIGNvbnN0IGhhc2ggPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdCgnU0hBLTI1NicsIGNvbWJpbmVkKTtcbiAgY29uc3Qga2V5ID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoJ3JhdycsIGhhc2gsIHsgbmFtZTogJ0FFUy1HQ00nIH0sIGZhbHNlLCBbXG4gICAgJ2VuY3J5cHQnLFxuICAgICdkZWNyeXB0JyxcbiAgXSk7XG4gIGRlcml2ZWRLZXlDYWNoZSA9IGtleTtcbiAgZGVyaXZlZEtleUNhY2hlU2FsdCA9IHNhbHRCNjQ7XG4gIHJldHVybiBrZXk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0VuY3J5cHRlZFBhdCh2OiBzdHJpbmcpOiBib29sZWFuIHtcbiAgcmV0dXJuIHYuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5jcnlwdFBhdChwbGFpbnRleHQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGlmICghcGxhaW50ZXh0KSByZXR1cm4gJyc7XG4gIGNvbnN0IGtleSA9IGF3YWl0IGRlcml2ZUtleSgpO1xuICBjb25zdCBpdiA9IGNyeXB0by5nZXRSYW5kb21WYWx1ZXMobmV3IFVpbnQ4QXJyYXkoMTIpKTtcbiAgY29uc3QgY3QgPSBhd2FpdCBjcnlwdG8uc3VidGxlLmVuY3J5cHQoXG4gICAgeyBuYW1lOiAnQUVTLUdDTScsIGl2IH0sXG4gICAga2V5LFxuICAgIG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShwbGFpbnRleHQpXG4gICk7XG4gIHJldHVybiBgJHtFTlZFTE9QRV9QUkVGSVh9JHt0b0Jhc2U2NChpdil9OiR7dG9CYXNlNjQobmV3IFVpbnQ4QXJyYXkoY3QpKX1gO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVjcnlwdFBhdChlbnZlbG9wZTogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgaWYgKCFlbnZlbG9wZSkgcmV0dXJuICcnO1xuICAvLyBMZWdhY3kgcGxhaW50ZXh0IChwcmUtZW5jcnlwdGlvbiBpbnN0YWxscyk6IHBhc3MgdGhyb3VnaC4gVGhlIG5leHQgc2F2ZVxuICAvLyByZS1lbmNyeXB0cyBpdCB2aWEgdGhlIHN0b3JhZ2UgbGF5ZXIuXG4gIGlmICghZW52ZWxvcGUuc3RhcnRzV2l0aChFTlZFTE9QRV9QUkVGSVgpKSByZXR1cm4gZW52ZWxvcGU7XG4gIGNvbnN0IHBhcnRzID0gZW52ZWxvcGUuc2xpY2UoRU5WRUxPUEVfUFJFRklYLmxlbmd0aCkuc3BsaXQoJzonKTtcbiAgaWYgKHBhcnRzLmxlbmd0aCAhPT0gMikgcmV0dXJuICcnO1xuICBjb25zdCBbaXZCNjQsIGN0QjY0XSA9IHBhcnRzO1xuICBpZiAoIWl2QjY0IHx8ICFjdEI2NCkgcmV0dXJuICcnO1xuICB0cnkge1xuICAgIGNvbnN0IGtleSA9IGF3YWl0IGRlcml2ZUtleSgpO1xuICAgIGNvbnN0IGl2ID0gZnJvbUJhc2U2NChpdkI2NCk7XG4gICAgY29uc3QgY3QgPSBmcm9tQmFzZTY0KGN0QjY0KTtcbiAgICBjb25zdCBwdCA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGVjcnlwdChcbiAgICAgIHsgbmFtZTogJ0FFUy1HQ00nLCBpdjogaXYgYXMgQnVmZmVyU291cmNlIH0sXG4gICAgICBrZXksXG4gICAgICBjdCBhcyBCdWZmZXJTb3VyY2VcbiAgICApO1xuICAgIHJldHVybiBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUocHQpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gJyc7XG4gIH1cbn1cbiIsICJpbXBvcnQgeyBERUZBVUxUX1NFVFRJTkdTLCBGQUxMQkFDS19BQ0NPVU5UUywgQUNUSVZJVFlfVEFJTF9NQVggfSBmcm9tICcuL2NvbmZpZy5qcyc7XG5pbXBvcnQgeyBkZWNyeXB0UGF0LCBlbmNyeXB0UGF0LCBpc0VuY3J5cHRlZFBhdCB9IGZyb20gJy4vY3J5cHRvLmpzJztcbmltcG9ydCB0eXBlIHtcbiAgQWNjb3VudENvbmZpZyxcbiAgQWNjb3VudENvdW50ZXIsXG4gIEFyY2hpdmVTbmFwc2hvdCxcbiAgQ2Fub25pY2FsVHdlZXQsXG4gIENvbm5lY3Rpb25TdGF0ZSxcbiAgTG9nRXZlbnQsXG4gIFJldHdlZXRFZGdlLFxuICBTZXR0aW5ncyxcbiAgVHdlZXRTaWdodGluZyxcbiAgVW5hdmFpbGFibGVUd2VldCxcbn0gZnJvbSAnLi90eXBlcy5qcyc7XG5cbi8qKlxuICogQnVmZmVyZWQgdHdlZXRzIGZvciBhIGdpdmVuIGFjY291bnQsIGF3YWl0aW5nIGNvbW1pdC4gQSBcInJ1blwiIGlzIG9uZSBlbnRyeVxuICogaW4gdGhpcyBtYXA7IGZsdXNoaW5nIGNsZWFycyB0aGUgZW50cnkuIFdlIHN0b3JlIGFzIFJlY29yZCBzbyB0aGUgc3RydWN0dXJlXG4gKiBzdXJ2aXZlcyBKU09OIHNlcmlhbGl6YXRpb24gdGhyb3VnaCBicm93c2VyLnN0b3JhZ2UuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUnVuQnVmZmVyIHtcbiAgcnVuX2lkOiBzdHJpbmc7XG4gIGFjY291bnRfaGFuZGxlOiBzdHJpbmc7XG4gIHN0YXJ0ZWRfYXQ6IHN0cmluZztcbiAgbGFzdF9jYXB0dXJlX2F0OiBzdHJpbmc7XG4gIHR3ZWV0c19ieV9pZDogUmVjb3JkPHN0cmluZywgQ2Fub25pY2FsVHdlZXQ+O1xuICB1bmF2YWlsYWJsZV9ieV9pZD86IFJlY29yZDxzdHJpbmcsIFVuYXZhaWxhYmxlVHdlZXQ+O1xuICByZXR3ZWV0X2VkZ2VzX2J5X2tleT86IFJlY29yZDxzdHJpbmcsIFJldHdlZXRFZGdlPjtcbiAgdHdlZXRfaWRzX29ic2VydmVkOiBzdHJpbmdbXTtcbiAgZW5kcG9pbnRzX3NlZW46IHN0cmluZ1tdO1xuICBzb3VyY2VfdXJsOiBzdHJpbmcgfCBudWxsO1xufVxuXG4vKiogUGVyLXR3ZWV0IGNvbW1pdHRlZC1zdGF0ZSBpbmRleCwga2V5ZWQgYnkgaGFuZGxlIHRoZW4gdHdlZXRfaWQuXG4gKiBVc2VkIHRvIHNraXAgcmUtY2FwdHVyaW5nIHR3ZWV0cyB3ZSd2ZSBhbHJlYWR5IHB1c2hlZCB3aXRoIGlkZW50aWNhbFxuICogZW5nYWdlbWVudCBjb3VudHMgXHUyMDE0IGF2b2lkcyBnZW5lcmF0aW5nIG9uZSBuZXcgcmF3LyogZmlsZSBldmVyeSBicm93c2UuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbW1pdHRlZEVudHJ5IHtcbiAgdHM6IHN0cmluZzsgLy8gSVNPIHRpbWVzdGFtcCBvZiB0aGUgbGFzdCBjb21taXRcbiAgc2lnOiBzdHJpbmc7IC8vIGVuZ2FnZW1lbnQgc2lnbmF0dXJlOiBcImxpa2V8cnR8cmVwbHl8cXVvdGVcIlxufVxuXG4vKiogUHJvZ3Jlc3MgKyBpbmZsaWdodCB0cmFja2luZyBmb3IgYSBxdWV1ZS1kcml2ZW4gbG9vcCAocmVmZXRjaCAvIG1lZGlhLWNyYXdsKS5cbiAqIFRoZSBsb29wIHBlcnNpc3RzIHRoaXMgc28gYSBTVyBldmljdGlvbiBpbiB0aGUgbWlkZGxlIG9mIGEgcnVuIHByZXNlcnZlc1xuICogXCJYIG9mIFkgcHJvY2Vzc2VkXCIgXHUyMDE0IGFuZCB0aGUgd2FpdC1mb3ItaW5nZXN0IGd1YXJkIGtub3dzIHdoYXQgdG8gZXhwZWN0LlxuICovXG5leHBvcnQgaW50ZXJmYWNlIExvb3BTZXNzaW9uIHtcbiAgLyoqIEluaXRpYWwgcXVldWUgc2l6ZSB3aGVuIHRoZSB1c2VyIGNsaWNrZWQgXCJTdGFydFwiLiAqL1xuICB0b3RhbEF0U3RhcnQ6IG51bWJlcjtcbiAgLyoqIFR3ZWV0cyBwcm9jZXNzZWQgKGluZ2VzdGVkIE9SIGRyb3BwZWQgYWZ0ZXIgcmV0cmllcykgc28gZmFyLiAqL1xuICBwcm9jZXNzZWQ6IG51bWJlcjtcbiAgLyoqIElTTyBvZiB3aGVuIHRoaXMgc2Vzc2lvbiBzdGFydGVkLiAqL1xuICBzdGFydGVkQXQ6IHN0cmluZztcbiAgLyoqIFR3ZWV0IGN1cnJlbnRseSBpbmZsaWdodCBcdTIwMTQgd2UgbmF2aWdhdGVkIHRvIGl0IGFuZCBhcmUgd2FpdGluZyBmb3IgdGhlXG4gICAqIHBhZ2UtaG9vayB0byBjYXB0dXJlIHRoZSByZXNwb25zZSBiZWZvcmUgYWR2YW5jaW5nLiBudWxsIGJldHdlZW4gdGlja3NcbiAgICogKGFuZCBvbmNlIGFuIGluZ2VzdCBoYXMgYmVlbiBvYnNlcnZlZCkuICovXG4gIGluZmxpZ2h0OiB7IHR3ZWV0SWQ6IHN0cmluZzsgbmF2aWdhdGVkQXQ6IHN0cmluZyB9IHwgbnVsbDtcbn1cblxuLyoqIEF1dG8tc2Nyb2xsIHNlc3Npb246IGNvdW50cyBvZiB0aWNrcyBhbmQgdHdlZXRzIGluZ2VzdGVkIHNpbmNlIHRoZSB1c2VyXG4gKiBjbGlja2VkIFN0YXJ0LiBQZXJzaXN0ZWQgc28gU1cgZXZpY3Rpb24gZHVyaW5nIGEgcnVuIGtlZXBzIHByb2dyZXNzLiAqL1xuZXhwb3J0IGludGVyZmFjZSBBdXRvU2Nyb2xsU2Vzc2lvbiB7XG4gIHN0YXJ0ZWRBdDogc3RyaW5nO1xuICBzY3JvbGxDb3VudDogbnVtYmVyO1xuICBpbmdlc3RlZENvdW50OiBudW1iZXI7XG4gIGluZ2VzdGVkTmV3Q291bnQ6IG51bWJlcjtcbiAgaW5nZXN0ZWRFeGlzdGluZ0NvdW50OiBudW1iZXI7XG4gIHNraXBwZWRPbGRDb3VudDogbnVtYmVyO1xuICBleHBhbmRlZENvdW50OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBTdG9yYWdlU2hhcGUge1xuICBzZXR0aW5nczogU2V0dGluZ3M7XG4gIGFjY291bnRzOiBBY2NvdW50Q29uZmlnW107XG4gIC8qKiBJU08gdGltZXN0YW1wIG9mIHRoZSBsYXN0IHN1Y2Nlc3NmdWwgYWNjb3VudHMueWFtbCBmZXRjaCBmcm9tIHRoZSByZXBvLlxuICAgKiBVc2VkIGJ5IGByZWZyZXNoQWNjb3VudHNMaXN0YCB0byBza2lwIHJlLWZldGNoaW5nIG9uIGV2ZXJ5IFNXIHdha2UgXHUyMDE0IHRoZVxuICAgKiBmaWxlIGNoYW5nZXMgcmFyZWx5IGFuZCBhbiBhdXRoZW50aWNhdGVkIHJhdyBmZXRjaCBldmVyeSB3YWtlIGFkZHMgdXAuICovXG4gIGFjY291bnRzUmVmcmVzaGVkQXQ6IHN0cmluZyB8IG51bGw7XG4gIGFyY2hpdmVTbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbDtcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvblN0YXRlO1xuICBjb3VudGVyczogUmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+O1xuICBydW5CdWZmZXJzOiBSZWNvcmQ8c3RyaW5nLCBSdW5CdWZmZXI+O1xuICBhY3Rpdml0eTogTG9nRXZlbnRbXTtcbiAgcmVjZW50VHdlZXRTaWdodGluZ3M6IFR3ZWV0U2lnaHRpbmdbXTtcbiAgY29tbWl0dGVkSW5kZXg6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIENvbW1pdHRlZEVudHJ5Pj47XG4gIC8qKiBUd2VldHMgdGhlIG5vcm1hbGl6ZXIgZmxhZ2dlZCBhcyB0cnVuY2F0ZWQgYW5kIHRoYXQgd2UgaGF2ZW4ndCBzZWVuIGFcbiAgICogZnVsbC10ZXh0IHZlcnNpb24gb2YgeWV0LiBLZXllZCBieSBoYW5kbGUgXHUyMTkyIGFycmF5IG9mIHR3ZWV0IGlkcy4gKi9cbiAgcmVmZXRjaFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XG4gIC8qKiBUd2VldCBJRHMgc2VlbiB2aWEgTWVkaWEtdGFiIC8gcGFydGlhbCBjYXB0dXJlcyB0aGF0IGNvdWxkbid0IGJlXG4gICAqIG5vcm1hbGl6ZWQgaW50byBhIGZ1bGwgY2Fub25pY2FsIHR3ZWV0LiBLZXllZCBieSBoaW50LWhhbmRsZSAob3JcbiAgICogXCJfdW5rbm93blwiKSBcdTIxOTIgYXJyYXkgb2YgdHdlZXQgaWRzLiBUaGUgdXNlciBjYW4gZHJpdmUgYSBjcmF3bCB0aGF0XG4gICAqIG9wZW5zIGVhY2ggZGV0YWlsIHBhZ2UgdG8gY2FwdHVyZSB0aGUgcmVhbCB0aGluZy4gKi9cbiAgbWVkaWFDcmF3bFF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XG4gIC8qKiBDb3JlLWFjY291bnQgdGhyZWFkIHJvb3RzIHdvcnRoIG9wZW5pbmcgYmVjYXVzZSB0aW1lbGluZS9zZWFyY2ggdmlld3MgbWF5XG4gICAqIG9taXQgbGF0ZXIgc2VsZi1yZXBsaWVzLiBLZXllZCBieSBoaW50LWhhbmRsZSAtPiByb290IHR3ZWV0IGlkcy4gKi9cbiAgdGhyZWFkT3BlblF1ZXVlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XG4gIC8qKiBSb290IHR3ZWV0IGlkcyBhbHJlYWR5IGF0dGVtcHRlZCBieSB0aGUgdGhyZWFkLW9wZW5pbmcgdXRpbGl0eS4gKi9cbiAgdGhyZWFkT3BlblNlZW46IFJlY29yZDxzdHJpbmcsIHN0cmluZz47XG4gIHJlZmV0Y2hTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XG4gIG1lZGlhQ3Jhd2xTZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XG4gIHRocmVhZE9wZW5TZXNzaW9uOiBMb29wU2Vzc2lvbiB8IG51bGw7XG4gIGF1dG9TY3JvbGxTZXNzaW9uOiBBdXRvU2Nyb2xsU2Vzc2lvbiB8IG51bGw7XG59XG5cbmNvbnN0IERFRkFVTFRfQ09OTkVDVElPTjogQ29ubmVjdGlvblN0YXRlID0ge1xuICBzdGF0dXM6ICd1bmtub3duJyxcbiAgbG9naW46IG51bGwsXG4gIGNoZWNrZWRBdDogbnVsbCxcbiAgZXJyb3I6IG51bGwsXG4gIGRlZmF1bHRCcmFuY2g6IG51bGwsXG4gIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6IG51bGwsXG4gIHJhdGVMaW1pdFJlc2V0QXQ6IG51bGwsXG59O1xuXG5jb25zdCBERUZBVUxUUzogU3RvcmFnZVNoYXBlID0ge1xuICBzZXR0aW5nczogeyAuLi5ERUZBVUxUX1NFVFRJTkdTIH0sXG4gIGFjY291bnRzOiBbLi4uRkFMTEJBQ0tfQUNDT1VOVFNdLFxuICBhY2NvdW50c1JlZnJlc2hlZEF0OiBudWxsLFxuICBhcmNoaXZlU25hcHNob3Q6IG51bGwsXG4gIGNvbm5lY3Rpb246IHsgLi4uREVGQVVMVF9DT05ORUNUSU9OIH0sXG4gIGNvdW50ZXJzOiB7fSxcbiAgcnVuQnVmZmVyczoge30sXG4gIGFjdGl2aXR5OiBbXSxcbiAgcmVjZW50VHdlZXRTaWdodGluZ3M6IFtdLFxuICBjb21taXR0ZWRJbmRleDoge30sXG4gIHJlZmV0Y2hRdWV1ZToge30sXG4gIG1lZGlhQ3Jhd2xRdWV1ZToge30sXG4gIHRocmVhZE9wZW5RdWV1ZToge30sXG4gIHRocmVhZE9wZW5TZWVuOiB7fSxcbiAgcmVmZXRjaFNlc3Npb246IG51bGwsXG4gIG1lZGlhQ3Jhd2xTZXNzaW9uOiBudWxsLFxuICB0aHJlYWRPcGVuU2Vzc2lvbjogbnVsbCxcbiAgYXV0b1Njcm9sbFNlc3Npb246IG51bGwsXG59O1xuXG5hc3luYyBmdW5jdGlvbiBnZXRSYXc8SyBleHRlbmRzIGtleW9mIFN0b3JhZ2VTaGFwZT4oa2V5OiBLKTogUHJvbWlzZTxTdG9yYWdlU2hhcGVbS10+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmdldChrZXkpO1xuICBjb25zdCB2YWx1ZSA9IHJlc3VsdFtrZXldO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiBzdHJ1Y3R1cmVkQ2xvbmUoREVGQVVMVFNba2V5XSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlIGFzIFN0b3JhZ2VTaGFwZVtLXTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0UmF3PEsgZXh0ZW5kcyBrZXlvZiBTdG9yYWdlU2hhcGU+KGtleTogSywgdmFsdWU6IFN0b3JhZ2VTaGFwZVtLXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHsgW2tleV06IHZhbHVlIH0pO1xufVxuXG4vLyAtLS0gU2V0dGluZ3MgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICAvLyBCYWNrZmlsbCBhbnkga2V5cyB0aGUgdXNlcidzIHN0b3JlZCBzZXR0aW5ncyBwcmVkYXRlIFx1MjAxNCByZWFkZXJzIGNhbiByZWx5XG4gIC8vIG9uIGV2ZXJ5IFNldHRpbmdzIGZpZWxkIGJlaW5nIHByZXNlbnQgcmF0aGVyIHRoYW4gYD8/IGRlZmF1bHRpbmdgIGF0XG4gIC8vIGV2ZXJ5IGNhbGxzaXRlLiBUaGUgUEFUIGlzIHN0b3JlZCBlbmNyeXB0ZWQtYXQtcmVzdCBhcyBvZiB2MC4yLjA7IHdlXG4gIC8vIGRlY3J5cHQgdHJhbnNwYXJlbnRseSBzbyBjYWxsZXJzIGNvbnRpbnVlIHRvIHNlZSBwbGFpbnRleHQuXG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGdldFJhdygnc2V0dGluZ3MnKTtcbiAgY29uc3QgbWVyZ2VkID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi5zdG9yZWQgfTtcbiAgaWYgKG1lcmdlZC5wYXQgJiYgaXNFbmNyeXB0ZWRQYXQobWVyZ2VkLnBhdCkpIHtcbiAgICB0cnkge1xuICAgICAgbWVyZ2VkLnBhdCA9IGF3YWl0IGRlY3J5cHRQYXQobWVyZ2VkLnBhdCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBtZXJnZWQucGF0ID0gJyc7XG4gICAgfVxuICB9XG4gIHJldHVybiBtZXJnZWQ7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2V0dGluZ3MoczogU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gRW5jcnlwdCB0aGUgUEFUIGJlZm9yZSBwZXJzaXN0aW5nOyBsZWdhY3kgcGxhaW50ZXh0IFBBVHMgZ2V0IHVwZ3JhZGVkXG4gIC8vIG9uIHRoZSBuZXh0IHNhdmUuXG4gIGNvbnN0IHRvV3JpdGU6IFNldHRpbmdzID0geyAuLi5zIH07XG4gIGlmICh0b1dyaXRlLnBhdCAmJiAhaXNFbmNyeXB0ZWRQYXQodG9Xcml0ZS5wYXQpKSB7XG4gICAgdG9Xcml0ZS5wYXQgPSBhd2FpdCBlbmNyeXB0UGF0KHRvV3JpdGUucGF0KTtcbiAgfVxuICBhd2FpdCBzZXRSYXcoJ3NldHRpbmdzJywgdG9Xcml0ZSk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2V0dGluZ3MocGF0Y2g6IFBhcnRpYWw8U2V0dGluZ3M+KTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICBjb25zdCBjdXIgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBuZXh0ID0geyAuLi5jdXIsIC4uLnBhdGNoIH07XG4gIGF3YWl0IHNldFNldHRpbmdzKG5leHQpO1xuICByZXR1cm4gbmV4dDtcbn1cblxuLy8gLS0tIEFjY291bnRzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjY291bnRzKCk6IFByb21pc2U8QWNjb3VudENvbmZpZ1tdPiB7XG4gIHJldHVybiBnZXRSYXcoJ2FjY291bnRzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHMoYTogQWNjb3VudENvbmZpZ1tdKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWNjb3VudHMnLCBhKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBY2NvdW50c1JlZnJlc2hlZEF0KCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0Jyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QWNjb3VudHNSZWZyZXNoZWRBdChpc286IHN0cmluZyB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdhY2NvdW50c1JlZnJlc2hlZEF0JywgaXNvKTtcbn1cblxuLy8gLS0tIEFyY2hpdmUgc25hcHNob3QgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QXJjaGl2ZVNuYXBzaG90KCk6IFByb21pc2U8QXJjaGl2ZVNuYXBzaG90IHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdhcmNoaXZlU25hcHNob3QnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldEFyY2hpdmVTbmFwc2hvdChzbmFwc2hvdDogQXJjaGl2ZVNuYXBzaG90IHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ2FyY2hpdmVTbmFwc2hvdCcsIHNuYXBzaG90KTtcbn1cblxuLy8gLS0tIENvbm5lY3Rpb24gc3RhdGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29ubmVjdGlvbigpOiBQcm9taXNlPENvbm5lY3Rpb25TdGF0ZT4ge1xuICBjb25zdCBjID0gYXdhaXQgZ2V0UmF3KCdjb25uZWN0aW9uJyk7XG4gIC8vIEJhY2tmaWxsIGZpZWxkcyBhZGRlZCBhZnRlciB0aGUgdXNlcidzIHN0b3JhZ2Ugd2FzIHdyaXR0ZW4uXG4gIGNvbnN0IG91dDogQ29ubmVjdGlvblN0YXRlID0ge1xuICAgIC4uLmMsXG4gICAgZGVmYXVsdEJyYW5jaDogYy5kZWZhdWx0QnJhbmNoID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5kZWZhdWx0QnJhbmNoLFxuICAgIGNvbmZpZ3VyZWRCcmFuY2hFeGlzdHM6XG4gICAgICBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMgPT09IHVuZGVmaW5lZCA/IG51bGwgOiBjLmNvbmZpZ3VyZWRCcmFuY2hFeGlzdHMsXG4gICAgcmF0ZUxpbWl0UmVzZXRBdDogYy5yYXRlTGltaXRSZXNldEF0ID09PSB1bmRlZmluZWQgPyBudWxsIDogYy5yYXRlTGltaXRSZXNldEF0LFxuICB9O1xuICByZXR1cm4gb3V0O1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldENvbm5lY3Rpb24oYzogQ29ubmVjdGlvblN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnY29ubmVjdGlvbicsIGMpO1xufVxuXG4vLyAtLS0gQ291bnRlcnMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5mdW5jdGlvbiB0b2RheUlTTygpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldENvdW50ZXJzKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgQWNjb3VudENvdW50ZXI+PiB7XG4gIHJldHVybiBnZXRSYXcoJ2NvdW50ZXJzJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVtcENvdW50ZXIoXG4gIGhhbmRsZTogc3RyaW5nLFxuICBwYXRjaDogUGFydGlhbDxBY2NvdW50Q291bnRlcj5cbik6IFByb21pc2U8QWNjb3VudENvdW50ZXI+IHtcbiAgY29uc3QgYWxsID0gYXdhaXQgZ2V0Q291bnRlcnMoKTtcbiAgY29uc3QgY3VyID0gYWxsW2hhbmRsZV0gPz8ge1xuICAgIHRvZGF5Q291bnQ6IDAsXG4gICAgdG9kYXlEYXRlOiB0b2RheUlTTygpLFxuICAgIGxhc3RDYXB0dXJlQXQ6IG51bGwsXG4gICAgdG90YWxDb21taXR0ZWQ6IDAsXG4gICAgYnVmZmVyZWRDb3VudDogMCxcbiAgfTtcbiAgaWYgKGN1ci50b2RheURhdGUgIT09IHRvZGF5SVNPKCkpIHtcbiAgICBjdXIudG9kYXlEYXRlID0gdG9kYXlJU08oKTtcbiAgICBjdXIudG9kYXlDb3VudCA9IDA7XG4gIH1cbiAgY29uc3QgbmV4dDogQWNjb3VudENvdW50ZXIgPSB7IC4uLmN1ciwgLi4ucGF0Y2ggfTtcbiAgYWxsW2hhbmRsZV0gPSBuZXh0O1xuICBhd2FpdCBzZXRSYXcoJ2NvdW50ZXJzJywgYWxsKTtcbiAgcmV0dXJuIG5leHQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRCdWZmZXJlZENvdW50KGhhbmRsZTogc3RyaW5nLCBjb3VudDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGJ1bXBDb3VudGVyKGhhbmRsZSwgeyBidWZmZXJlZENvdW50OiBjb3VudCB9KTtcbn1cblxuLy8gLS0tIFJ1biBidWZmZXJzICh0aGUgcGVuZGluZyBjYXB0dXJlcyBhd2FpdGluZyBjb21taXQpIC0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVycygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIFJ1bkJ1ZmZlcj4+IHtcbiAgcmV0dXJuIGdldFJhdygncnVuQnVmZmVycycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuQnVmZmVyKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxSdW5CdWZmZXIgfCBudWxsPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgcmV0dXJuIGFsbFtoYW5kbGVdID8/IG51bGw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRSdW5CdWZmZXIoaGFuZGxlOiBzdHJpbmcsIGJ1ZjogUnVuQnVmZmVyKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGFsbCA9IGF3YWl0IGdldFJ1bkJ1ZmZlcnMoKTtcbiAgYWxsW2hhbmRsZV0gPSBidWY7XG4gIGF3YWl0IHNldFJhdygncnVuQnVmZmVycycsIGFsbCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclJ1bkJ1ZmZlcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBnZXRSdW5CdWZmZXJzKCk7XG4gIGRlbGV0ZSBhbGxbaGFuZGxlXTtcbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYWxsKTtcbn1cblxuLy8gLS0tIEFjdGl2aXR5IHRhaWwgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2aXR5KCk6IFByb21pc2U8TG9nRXZlbnRbXT4ge1xuICByZXR1cm4gZ2V0UmF3KCdhY3Rpdml0eScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwZW5kQWN0aXZpdHkoZXY6IExvZ0V2ZW50KTogUHJvbWlzZTxMb2dFdmVudFtdPiB7XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldEFjdGl2aXR5KCk7XG4gIGN1ci51bnNoaWZ0KGV2KTtcbiAgaWYgKGN1ci5sZW5ndGggPiBBQ1RJVklUWV9UQUlMX01BWCkgY3VyLmxlbmd0aCA9IEFDVElWSVRZX1RBSUxfTUFYO1xuICBhd2FpdCBzZXRSYXcoJ2FjdGl2aXR5JywgY3VyKTtcbiAgcmV0dXJuIGN1cjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyQWN0aXZpdHkoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYWN0aXZpdHknLCBbXSk7XG59XG5cbi8vIC0tLSBSZWNlbnQgdHdlZXQgc2lnaHRpbmdzIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5jb25zdCBSRUNFTlRfVFdFRVRfU0lHSFRJTkdTX01BWCA9IDgwO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVjZW50VHdlZXRTaWdodGluZ3MoKTogUHJvbWlzZTxUd2VldFNpZ2h0aW5nW10+IHtcbiAgcmV0dXJuIGdldFJhdygncmVjZW50VHdlZXRTaWdodGluZ3MnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByZXBlbmRSZWNlbnRUd2VldFNpZ2h0aW5ncyhyb3dzOiBUd2VldFNpZ2h0aW5nW10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKHJvd3MubGVuZ3RoID09PSAwKSByZXR1cm47XG4gIGNvbnN0IGN1ciA9IGF3YWl0IGdldFJlY2VudFR3ZWV0U2lnaHRpbmdzKCk7XG4gIGNvbnN0IHNlZW4gPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgY29uc3QgbmV4dDogVHdlZXRTaWdodGluZ1tdID0gW107XG4gIGZvciAoY29uc3Qgcm93IG9mIHJvd3MpIHtcbiAgICBjb25zdCBrZXkgPSBgJHtyb3cuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKX06JHtyb3cudHdlZXRfaWR9YDtcbiAgICBpZiAoc2Vlbi5oYXMoa2V5KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQoa2V5KTtcbiAgICBuZXh0LnB1c2gocm93KTtcbiAgfVxuICBmb3IgKGNvbnN0IHJvdyBvZiBjdXIpIHtcbiAgICBjb25zdCBrZXkgPSBgJHtyb3cuYWNjb3VudF9oYW5kbGUudG9Mb3dlckNhc2UoKX06JHtyb3cudHdlZXRfaWR9YDtcbiAgICBpZiAoc2Vlbi5oYXMoa2V5KSkgY29udGludWU7XG4gICAgc2Vlbi5hZGQoa2V5KTtcbiAgICBuZXh0LnB1c2gocm93KTtcbiAgfVxuICBuZXh0Lmxlbmd0aCA9IE1hdGgubWluKG5leHQubGVuZ3RoLCBSRUNFTlRfVFdFRVRfU0lHSFRJTkdTX01BWCk7XG4gIGF3YWl0IHNldFJhdygncmVjZW50VHdlZXRTaWdodGluZ3MnLCBuZXh0KTtcbn1cblxuLy8gLS0tIENvbW1pdHRlZC10d2VldHMgZGVkdXAgaW5kZXggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q29tbWl0dGVkSW5kZXgoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+PiB7XG4gIHJldHVybiBnZXRSYXcoJ2NvbW1pdHRlZEluZGV4Jyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRDb21taXR0ZWRJbmRleChcbiAgaWR4OiBSZWNvcmQ8c3RyaW5nLCBSZWNvcmQ8c3RyaW5nLCBDb21taXR0ZWRFbnRyeT4+XG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCdjb21taXR0ZWRJbmRleCcsIGlkeCk7XG59XG5cbi8qKiBDb21wdXRlIHRoZSBlbmdhZ2VtZW50IHNpZ25hdHVyZSB3ZSB1c2UgdG8gZGVjaWRlIHdoZXRoZXIgYSByZS1jYXB0dXJlZFxuICogdHdlZXQgaXMgXCJtYXRlcmlhbGx5IGRpZmZlcmVudFwiIGZyb20gd2hhdCB3ZSBsYXN0IGNvbW1pdHRlZC4gV2Ugb21pdFxuICogdmlld19jb3VudCBiZWNhdXNlIGl0IHRpY2tzIHVwIGZyZXF1ZW50bHkgb24gYWN0aXZlIHR3ZWV0cyBhbmQgd291bGRcbiAqIGRlZmVhdCB0aGUgZGVkdXAuIExpa2VzIC8gUlRzIC8gcmVwbGllcyAvIHF1b3RlcyBjaGFuZ2UgcmFyZWx5IGVub3VnaCB0aGF0XG4gKiBlYWNoIGNoYW5nZSBpcyB3b3J0aCBhIHJlLWNvbW1pdCAoYW5kIGFuIGVuZ2FnZW1lbnRfaGlzdG9yeSBzbmFwc2hvdCkuXG4gKiBgaXNfdHJ1bmNhdGVkYCBpcyBmb2xkZWQgaW4gc28gYSByZWZldGNoIHRoYXQgc3dhcHMgdGhlIDI4MC1jaGFyIGhlYWQgZm9yXG4gKiB0aGUgZnVsbCBgbm90ZV90d2VldGAgYm9keSBieXBhc3NlcyB0aGUgZGVkdXAgZXZlbiB3aGVuIGVuZ2FnZW1lbnQgY291bnRzXG4gKiBoYXZlbid0IG1vdmVkIFx1MjAxNCBvdGhlcndpc2UgdGhlIG5ldyBib2R5IHdvdWxkIGJlIHNpbGVudGx5IGRyb3BwZWQuICovXG5leHBvcnQgZnVuY3Rpb24gZW5nYWdlbWVudFNpZyhcbiAgbGlrZXM6IG51bWJlcixcbiAgcmV0d2VldHM6IG51bWJlcixcbiAgcmVwbGllczogbnVtYmVyLFxuICBxdW90ZXM6IG51bWJlcixcbiAgaXNUcnVuY2F0ZWQ6IGJvb2xlYW4gPSBmYWxzZVxuKTogc3RyaW5nIHtcbiAgcmV0dXJuIGAke2xpa2VzfXwke3JldHdlZXRzfXwke3JlcGxpZXN9fCR7cXVvdGVzfXwke2lzVHJ1bmNhdGVkID8gJ3QnIDogJ2YnfWA7XG59XG5cbi8qKiBEcm9wIGVudHJpZXMgb2xkZXIgdGhhbiBgbWF4QWdlTXNgLiBSZXR1cm5zIHRoZSBudW1iZXIgcHJ1bmVkLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBydW5lQ29tbWl0dGVkSW5kZXgobWF4QWdlTXM6IG51bWJlcik6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGNvbnN0IGN1dG9mZiA9IG5ldyBEYXRlKERhdGUubm93KCkgLSBtYXhBZ2VNcykudG9JU09TdHJpbmcoKTtcbiAgbGV0IHBydW5lZCA9IDA7XG4gIGZvciAoY29uc3QgaGFuZGxlIG9mIE9iamVjdC5rZXlzKGlkeCkpIHtcbiAgICBjb25zdCBpbm5lciA9IGlkeFtoYW5kbGVdO1xuICAgIGlmICghaW5uZXIpIGNvbnRpbnVlO1xuICAgIGZvciAoY29uc3QgdGlkIG9mIE9iamVjdC5rZXlzKGlubmVyKSkge1xuICAgICAgY29uc3QgZSA9IGlubmVyW3RpZF07XG4gICAgICBpZiAoZSAmJiBlLnRzIDwgY3V0b2ZmKSB7XG4gICAgICAgIGRlbGV0ZSBpbm5lclt0aWRdO1xuICAgICAgICBwcnVuZWQgKz0gMTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKE9iamVjdC5rZXlzKGlubmVyKS5sZW5ndGggPT09IDApIGRlbGV0ZSBpZHhbaGFuZGxlXTtcbiAgfVxuICBpZiAocHJ1bmVkID4gMCkgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcbiAgcmV0dXJuIHBydW5lZDtcbn1cblxuLy8gLS0tIFJlZmV0Y2ggcXVldWUgKHR3ZWV0cyBuZWVkaW5nIGZ1bGwtdGV4dCByZWNhcHR1cmUpIC0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZWZldGNoUXVldWUoKTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT4+IHtcbiAgcmV0dXJuIGdldFJhdygncmVmZXRjaFF1ZXVlJyk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWZldGNoUXVldWVUb3RhbCgpOiBQcm9taXNlPG51bWJlcj4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGxldCB0b3RhbCA9IDA7XG4gIGZvciAoY29uc3QgaWRzIG9mIE9iamVjdC52YWx1ZXMocSkpIHRvdGFsICs9IGlkcy5sZW5ndGg7XG4gIHJldHVybiB0b3RhbDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVucXVldWVSZWZldGNoKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBjb25zdCBpZHMgPSBxW2hhbmRsZV0gPz8gW107XG4gIGlmICghaWRzLmluY2x1ZGVzKHR3ZWV0SWQpKSB7XG4gICAgaWRzLnB1c2godHdlZXRJZCk7XG4gICAgcVtoYW5kbGVdID0gaWRzO1xuICAgIGF3YWl0IHNldFJhdygncmVmZXRjaFF1ZXVlJywgcSk7XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVSZWZldGNoKGhhbmRsZTogc3RyaW5nLCB0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBjb25zdCBpZHMgPSBxW2hhbmRsZV07XG4gIGlmICghaWRzKSByZXR1cm47XG4gIGNvbnN0IGZpbHRlcmVkID0gaWRzLmZpbHRlcigoaWQpID0+IGlkICE9PSB0d2VldElkKTtcbiAgaWYgKGZpbHRlcmVkLmxlbmd0aCA9PT0gMCkgZGVsZXRlIHFbaGFuZGxlXTtcbiAgZWxzZSBxW2hhbmRsZV0gPSBmaWx0ZXJlZDtcbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBxKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5leHRSZWZldGNoVGFyZ2V0KCk6IFByb21pc2U8e1xuICBoYW5kbGU6IHN0cmluZztcbiAgdHdlZXRJZDogc3RyaW5nO1xufSB8IG51bGw+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFJlZmV0Y2hRdWV1ZSgpO1xuICBmb3IgKGNvbnN0IFtoYW5kbGUsIGlkc10gb2YgT2JqZWN0LmVudHJpZXMocSkpIHtcbiAgICBpZiAoaWRzLmxlbmd0aCA+IDApIHJldHVybiB7IGhhbmRsZSwgdHdlZXRJZDogaWRzWzBdISB9O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vLyAtLS0gTWVkaWEtY3Jhd2wgcXVldWUgKHBhcnRpYWwgY2FwdHVyZXMgYXdhaXRpbmcgZGV0YWlsLXBhZ2UgZmV0Y2gpIC0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1lZGlhQ3Jhd2xRdWV1ZSgpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPj4ge1xuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsUXVldWUnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1lZGlhQ3Jhd2xRdWV1ZVRvdGFsKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgbGV0IHRvdGFsID0gMDtcbiAgZm9yIChjb25zdCBpZHMgb2YgT2JqZWN0LnZhbHVlcyhxKSkgdG90YWwgKz0gaWRzLmxlbmd0aDtcbiAgcmV0dXJuIHRvdGFsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZU1lZGlhQ3Jhd2woaGludEhhbmRsZTogc3RyaW5nIHwgbnVsbCwgdHdlZXRJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgY29uc3QgYnVja2V0ID0gaGludEhhbmRsZSA/PyAnX3Vua25vd24nO1xuICBjb25zdCBpZHMgPSBxW2J1Y2tldF0gPz8gW107XG4gIGlmICghaWRzLmluY2x1ZGVzKHR3ZWV0SWQpKSB7XG4gICAgaWRzLnB1c2godHdlZXRJZCk7XG4gICAgcVtidWNrZXRdID0gaWRzO1xuICAgIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgcSk7XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVNZWRpYUNyYXdsKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0TWVkaWFDcmF3bFF1ZXVlKCk7XG4gIGxldCBjaGFuZ2VkID0gZmFsc2U7XG4gIGZvciAoY29uc3QgYnVja2V0IG9mIE9iamVjdC5rZXlzKHEpKSB7XG4gICAgY29uc3QgaWRzID0gcVtidWNrZXRdO1xuICAgIGlmICghaWRzKSBjb250aW51ZTtcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XG4gICAgaWYgKGZpbHRlcmVkLmxlbmd0aCAhPT0gaWRzLmxlbmd0aCkge1xuICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtidWNrZXRdO1xuICAgICAgZWxzZSBxW2J1Y2tldF0gPSBmaWx0ZXJlZDtcbiAgICB9XG4gIH1cbiAgaWYgKGNoYW5nZWQpIGF3YWl0IHNldFJhdygnbWVkaWFDcmF3bFF1ZXVlJywgcSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0TWVkaWFDcmF3bFRhcmdldCgpOiBQcm9taXNlPHtcbiAgYnVja2V0OiBzdHJpbmc7XG4gIHR3ZWV0SWQ6IHN0cmluZztcbn0gfCBudWxsPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRNZWRpYUNyYXdsUXVldWUoKTtcbiAgZm9yIChjb25zdCBbYnVja2V0LCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBidWNrZXQsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLy8gLS0tIFRocmVhZC1vcGVuaW5nIHF1ZXVlIChjb3JlIGNvbnZlcnNhdGlvbiByb290cyB0byB2aXNpdCkgLS0tLS0tLS0tLS0tLVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGhyZWFkT3BlblF1ZXVlKCk6IFByb21pc2U8UmVjb3JkPHN0cmluZywgc3RyaW5nW10+PiB7XG4gIHJldHVybiBnZXRSYXcoJ3RocmVhZE9wZW5RdWV1ZScpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdGhyZWFkT3BlblF1ZXVlVG90YWwoKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xuICBsZXQgdG90YWwgPSAwO1xuICBmb3IgKGNvbnN0IGlkcyBvZiBPYmplY3QudmFsdWVzKHEpKSB0b3RhbCArPSBpZHMubGVuZ3RoO1xuICByZXR1cm4gdG90YWw7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBoYXNUaHJlYWRPcGVuU2Vlbih0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3Qgc2VlbiA9IGF3YWl0IGdldFJhdygndGhyZWFkT3BlblNlZW4nKTtcbiAgcmV0dXJuIHR3ZWV0SWQgaW4gc2Vlbjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1hcmtUaHJlYWRPcGVuU2Vlbih0d2VldElkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc2VlbiA9IGF3YWl0IGdldFJhdygndGhyZWFkT3BlblNlZW4nKTtcbiAgc2Vlblt0d2VldElkXSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgYXdhaXQgc2V0UmF3KCd0aHJlYWRPcGVuU2VlbicsIHNlZW4pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5xdWV1ZVRocmVhZE9wZW4oaGFuZGxlOiBzdHJpbmcsIHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoYXdhaXQgaGFzVGhyZWFkT3BlblNlZW4odHdlZXRJZCkpIHJldHVybjtcbiAgY29uc3QgcSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xuICBjb25zdCBpZHMgPSBxW2hhbmRsZV0gPz8gW107XG4gIGlmICghaWRzLmluY2x1ZGVzKHR3ZWV0SWQpKSB7XG4gICAgaWRzLnB1c2godHdlZXRJZCk7XG4gICAgcVtoYW5kbGVdID0gaWRzO1xuICAgIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblF1ZXVlJywgcSk7XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlcXVldWVUaHJlYWRPcGVuKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBxID0gYXdhaXQgZ2V0VGhyZWFkT3BlblF1ZXVlKCk7XG4gIGxldCBjaGFuZ2VkID0gZmFsc2U7XG4gIGZvciAoY29uc3QgYnVja2V0IG9mIE9iamVjdC5rZXlzKHEpKSB7XG4gICAgY29uc3QgaWRzID0gcVtidWNrZXRdO1xuICAgIGlmICghaWRzKSBjb250aW51ZTtcbiAgICBjb25zdCBmaWx0ZXJlZCA9IGlkcy5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gdHdlZXRJZCk7XG4gICAgaWYgKGZpbHRlcmVkLmxlbmd0aCAhPT0gaWRzLmxlbmd0aCkge1xuICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgICBpZiAoZmlsdGVyZWQubGVuZ3RoID09PSAwKSBkZWxldGUgcVtidWNrZXRdO1xuICAgICAgZWxzZSBxW2J1Y2tldF0gPSBmaWx0ZXJlZDtcbiAgICB9XG4gIH1cbiAgaWYgKGNoYW5nZWQpIGF3YWl0IHNldFJhdygndGhyZWFkT3BlblF1ZXVlJywgcSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBuZXh0VGhyZWFkT3BlblRhcmdldCgpOiBQcm9taXNlPHtcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIHR3ZWV0SWQ6IHN0cmluZztcbn0gfCBudWxsPiB7XG4gIGNvbnN0IHEgPSBhd2FpdCBnZXRUaHJlYWRPcGVuUXVldWUoKTtcbiAgZm9yIChjb25zdCBbaGFuZGxlLCBpZHNdIG9mIE9iamVjdC5lbnRyaWVzKHEpKSB7XG4gICAgaWYgKGlkcy5sZW5ndGggPiAwKSByZXR1cm4geyBoYW5kbGUsIHR3ZWV0SWQ6IGlkc1swXSEgfTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLyoqIEhhcyB0aGlzIHR3ZWV0IGlkIGFscmVhZHkgYmVlbiBjb21taXR0ZWQgKGFueSBoYW5kbGUpPyBVc2VkIHRvIHNraXBcbiAqIGVucXVldWVpbmcgbWVkaWEtY3Jhd2wgdGFyZ2V0cyB3ZSd2ZSBhbHJlYWR5IGFyY2hpdmVkLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGlzQ29tbWl0dGVkKHR3ZWV0SWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCBpZHggPSBhd2FpdCBnZXRDb21taXR0ZWRJbmRleCgpO1xuICBmb3IgKGNvbnN0IGlubmVyIG9mIE9iamVjdC52YWx1ZXMoaWR4KSkge1xuICAgIGlmIChpbm5lciAmJiB0d2VldElkIGluIGlubmVyKSByZXR1cm4gdHJ1ZTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbi8vIC0tLSBMb29wIHNlc3Npb24gc3RhdGUgKHByb2dyZXNzICsgaW5mbGlnaHQgZ2F0aW5nKSAtLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlZmV0Y2hTZXNzaW9uKCk6IFByb21pc2U8TG9vcFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ3JlZmV0Y2hTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UmVmZXRjaFNlc3Npb24oczogTG9vcFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygncmVmZXRjaFNlc3Npb24nLCBzKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZWRpYUNyYXdsU2Vzc2lvbigpOiBQcm9taXNlPExvb3BTZXNzaW9uIHwgbnVsbD4ge1xuICByZXR1cm4gZ2V0UmF3KCdtZWRpYUNyYXdsU2Vzc2lvbicpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldE1lZGlhQ3Jhd2xTZXNzaW9uKHM6IExvb3BTZXNzaW9uIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xTZXNzaW9uJywgcyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VGhyZWFkT3BlblNlc3Npb24oKTogUHJvbWlzZTxMb29wU2Vzc2lvbiB8IG51bGw+IHtcbiAgcmV0dXJuIGdldFJhdygndGhyZWFkT3BlblNlc3Npb24nKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRUaHJlYWRPcGVuU2Vzc2lvbihzOiBMb29wU2Vzc2lvbiB8IG51bGwpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgc2V0UmF3KCd0aHJlYWRPcGVuU2Vzc2lvbicsIHMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEF1dG9TY3JvbGxTZXNzaW9uKCk6IFByb21pc2U8QXV0b1Njcm9sbFNlc3Npb24gfCBudWxsPiB7XG4gIHJldHVybiBnZXRSYXcoJ2F1dG9TY3JvbGxTZXNzaW9uJyk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0QXV0b1Njcm9sbFNlc3Npb24oczogQXV0b1Njcm9sbFNlc3Npb24gfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNldFJhdygnYXV0b1Njcm9sbFNlc3Npb24nLCBzKTtcbn1cblxuLy8gLS0tIFB1cmdlOiB1bnJlbGF0ZWQgYnVmZmVycywgY291bnRlcnMsIHF1ZXVlIGVudHJpZXMgLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4vKipcbiAqIERyb3AgZXZlcnkgcGVyLWhhbmRsZSBiaXQgb2Ygc3RhdGUgKGNvdW50ZXJzLCBydW4gYnVmZmVyLCBjb21taXR0ZWQtaW5kZXhcbiAqIGVudHJpZXMsIHJlZmV0Y2ggLyBtZWRpYS1jcmF3bCBxdWV1ZSBlbnRyaWVzKSB0aGF0IGRvZXNuJ3QgY29ycmVzcG9uZCB0byBhXG4gKiB0cmFja2VkIGFjY291bnQuIFJldHVybnMgYSBzdW1tYXJ5IGRlc2NyaWJpbmcgd2hhdCB3YXMgY2xlYXJlZCBzbyB0aGVcbiAqIGNhbGxlciBjYW4gbG9nIGl0LlxuICpcbiAqIFRyYWNrZWQgYWNjb3VudHMgYXJlIHBhc3NlZCBpbiAoY2FsbGVyIHJlc29sdmVzIGZyb20gdGhlIGxpdmUgY29uZmlnKS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1cmdlVW5yZWxhdGVkU3RhdGUodGFyZ2V0ZWQ6IFJlYWRvbmx5U2V0PHN0cmluZz4pOiBQcm9taXNlPHtcbiAgY291bnRlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGJ1ZmZlcnNSZW1vdmVkOiBudW1iZXI7XG4gIGNvbW1pdHRlZEhhbmRsZXNSZW1vdmVkOiBudW1iZXI7XG4gIHJlZmV0Y2hIYW5kbGVzUmVtb3ZlZDogbnVtYmVyO1xuICBtZWRpYUNyYXdsSWRzUmVtb3ZlZDogbnVtYmVyO1xuICB0aHJlYWRPcGVuSWRzUmVtb3ZlZDogbnVtYmVyO1xufT4ge1xuICBjb25zdCB0YXJnTG93ZXIgPSBuZXcgU2V0KFsuLi50YXJnZXRlZF0ubWFwKChoKSA9PiBoLnRvTG93ZXJDYXNlKCkpKTtcbiAgY29uc3QgaXNUYXJnZXRlZCA9IChoOiBzdHJpbmcpOiBib29sZWFuID0+IHRhcmdMb3dlci5oYXMoaC50b0xvd2VyQ2FzZSgpKTtcblxuICAvLyBDb3VudGVyc1xuICBjb25zdCBjb3VudGVycyA9IGF3YWl0IGdldENvdW50ZXJzKCk7XG4gIGxldCBjb3VudGVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoY291bnRlcnMpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgY291bnRlcnNbaF07XG4gICAgICBjb3VudGVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdjb3VudGVycycsIGNvdW50ZXJzKTtcblxuICAvLyBSdW4gYnVmZmVyc1xuICBjb25zdCBidWZmZXJzID0gYXdhaXQgZ2V0UnVuQnVmZmVycygpO1xuICBsZXQgYnVmZmVyc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMoYnVmZmVycykpIHtcbiAgICBpZiAoIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIGRlbGV0ZSBidWZmZXJzW2hdO1xuICAgICAgYnVmZmVyc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdydW5CdWZmZXJzJywgYnVmZmVycyk7XG5cbiAgLy8gQ29tbWl0dGVkIGRlZHVwIGluZGV4XG4gIGNvbnN0IGlkeCA9IGF3YWl0IGdldENvbW1pdHRlZEluZGV4KCk7XG4gIGxldCBjb21taXR0ZWRIYW5kbGVzUmVtb3ZlZCA9IDA7XG4gIGZvciAoY29uc3QgaCBvZiBPYmplY3Qua2V5cyhpZHgpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgaWR4W2hdO1xuICAgICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0Q29tbWl0dGVkSW5kZXgoaWR4KTtcblxuICAvLyBSZWZldGNoIHF1ZXVlOiBidWNrZXRzIGFyZSBrZXllZCBieSBoYW5kbGUuXG4gIGNvbnN0IHJxID0gYXdhaXQgZ2V0UmVmZXRjaFF1ZXVlKCk7XG4gIGxldCByZWZldGNoSGFuZGxlc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMocnEpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICBkZWxldGUgcnFbaF07XG4gICAgICByZWZldGNoSGFuZGxlc1JlbW92ZWQgKz0gMTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCdyZWZldGNoUXVldWUnLCBycSk7XG5cbiAgLy8gTWVkaWEtY3Jhd2wgcXVldWU6IGJ1Y2tldHMgYXJlIGhpbnQtaGFuZGxlcyAob3IgXCJfdW5rbm93blwiKS4gRHJvcFxuICAvLyBlbnRyaWVzIHdob3NlIGJ1Y2tldCBpc24ndCB0YXJnZXRlZCwgYnV0IEtFRVAgXCJfdW5rbm93blwiOiB0aG9zZSBhcmVcbiAgLy8gY2FwdHVyZXMgYXdhaXRpbmcgaGFuZGxlIHJlc29sdXRpb24gZm9yIGxhdGVyIGZ1bGwtZGV0YWlsIHJlY2FwdHVyZSwgc29cbiAgLy8gcHVyZ2luZyB0aGVtIHdvdWxkIHNpbGVudGx5IGRpc2NhcmQgcGVuZGluZyB3b3JrLlxuICBjb25zdCBtcSA9IGF3YWl0IGdldE1lZGlhQ3Jhd2xRdWV1ZSgpO1xuICBsZXQgbWVkaWFDcmF3bElkc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXMobXEpKSB7XG4gICAgaWYgKGggIT09ICdfdW5rbm93bicgJiYgIWlzVGFyZ2V0ZWQoaCkpIHtcbiAgICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkICs9IChtcVtoXSA/PyBbXSkubGVuZ3RoO1xuICAgICAgZGVsZXRlIG1xW2hdO1xuICAgIH1cbiAgfVxuICBhd2FpdCBzZXRSYXcoJ21lZGlhQ3Jhd2xRdWV1ZScsIG1xKTtcblxuICBjb25zdCB0cSA9IGF3YWl0IGdldFRocmVhZE9wZW5RdWV1ZSgpO1xuICBsZXQgdGhyZWFkT3Blbklkc1JlbW92ZWQgPSAwO1xuICBmb3IgKGNvbnN0IGggb2YgT2JqZWN0LmtleXModHEpKSB7XG4gICAgaWYgKCFpc1RhcmdldGVkKGgpKSB7XG4gICAgICB0aHJlYWRPcGVuSWRzUmVtb3ZlZCArPSAodHFbaF0gPz8gW10pLmxlbmd0aDtcbiAgICAgIGRlbGV0ZSB0cVtoXTtcbiAgICB9XG4gIH1cbiAgYXdhaXQgc2V0UmF3KCd0aHJlYWRPcGVuUXVldWUnLCB0cSk7XG5cbiAgcmV0dXJuIHtcbiAgICBjb3VudGVyc1JlbW92ZWQsXG4gICAgYnVmZmVyc1JlbW92ZWQsXG4gICAgY29tbWl0dGVkSGFuZGxlc1JlbW92ZWQsXG4gICAgcmVmZXRjaEhhbmRsZXNSZW1vdmVkLFxuICAgIG1lZGlhQ3Jhd2xJZHNSZW1vdmVkLFxuICAgIHRocmVhZE9wZW5JZHNSZW1vdmVkLFxuICB9O1xufVxuXG4vLyAtLS0gRnVsbCByZXNldCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhckFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgYnJvd3Nlci5zdG9yYWdlLmxvY2FsLmNsZWFyKCk7XG59XG4iLCAiLyoqXG4gKiBvcHRpb25zLnRzIFx1MjAxNCBzZXR0aW5ncyBwYWdlLlxuICpcbiAqIFN0b3JlcyBQQVQgYW5kIHJlcG8gaWRlbnRpZmllcnMgaW4gYGJyb3dzZXIuc3RvcmFnZS5sb2NhbGAsIHZlcmlmaWVzIGFjY2Vzc1xuICogYnkgY2FsbGluZyAvdXNlciBhbmQgL3JlcG9zLzpvd25lci86cmVwbywgYW5kIHN1cmZhY2VzIHRoZSByZXN1bHRpbmdcbiAqIGNvbm5lY3Rpb24gc3RhdGUuXG4gKi9cblxuaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUyB9IGZyb20gJy4vbGliL2NvbmZpZy5qcyc7XG5pbXBvcnQge1xuICBjbGVhckFsbCxcbiAgZ2V0QWNjb3VudHMsXG4gIGdldEFjdGl2aXR5LFxuICBnZXRBcmNoaXZlU25hcHNob3QsXG4gIGdldENvbm5lY3Rpb24sXG4gIGdldENvdW50ZXJzLFxuICBnZXRSdW5CdWZmZXJzLFxuICBnZXRTZXR0aW5ncyxcbiAgdXBkYXRlU2V0dGluZ3MsXG59IGZyb20gJy4vbGliL3N0b3JhZ2UuanMnO1xuaW1wb3J0IHR5cGUgeyBSdW50aW1lTWVzc2FnZSB9IGZyb20gJy4vbGliL3R5cGVzLmpzJztcblxuY29uc3QgJCA9IDxUIGV4dGVuZHMgSFRNTEVsZW1lbnQgPSBIVE1MRWxlbWVudD4oaWQ6IHN0cmluZyk6IFQgPT4ge1xuICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcbiAgaWYgKCFlbCkgdGhyb3cgbmV3IEVycm9yKGBtaXNzaW5nIGVsZW1lbnQgIyR7aWR9YCk7XG4gIHJldHVybiBlbCBhcyBUO1xufTtcblxuY29uc3QgZm9ybSA9ICQ8SFRNTEZvcm1FbGVtZW50Pignc2V0dGluZ3MtZm9ybScpO1xuY29uc3Qgb3duZXJJbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ293bmVyJyk7XG5jb25zdCByZXBvSW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdyZXBvJyk7XG5jb25zdCBicmFuY2hJbnB1dCA9ICQ8SFRNTElucHV0RWxlbWVudD4oJ2JyYW5jaCcpO1xuY29uc3QgcGF0SW5wdXQgPSAkPEhUTUxJbnB1dEVsZW1lbnQ+KCdwYXQnKTtcbmNvbnN0IHJldmVhbEJ0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdyZXZlYWwtcGF0Jyk7XG5jb25zdCBzYXZlU3RhdHVzID0gJDxIVE1MU3BhbkVsZW1lbnQ+KCdzYXZlLXN0YXR1cycpO1xuY29uc3QgY29ubkRldGFpbCA9ICQoJ2Nvbm4tZGV0YWlsJyk7XG5jb25zdCBhY2NvdW50TGlzdCA9ICQ8SFRNTFVMaXN0RWxlbWVudD4oJ2FjY291bnQtcmVhZG9ubHknKTtcbmNvbnN0IHJlZnJlc2hCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PigncmVmcmVzaC1hY2NvdW50cycpO1xuY29uc3QgZGlhZ0JveCA9ICQ8SFRNTFRleHRBcmVhRWxlbWVudD4oJ2RpYWdub3N0aWNzJyk7XG5jb25zdCBjb3B5RGlhZ0J0biA9ICQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KCdjb3B5LWRpYWdub3N0aWNzJyk7XG5jb25zdCBjbGVhclN0b3JhZ2VCdG4gPSAkPEhUTUxCdXR0b25FbGVtZW50PignY2xlYXItc3RvcmFnZScpO1xuY29uc3QgZGlhZ1N0YXR1cyA9ICQ8SFRNTFNwYW5FbGVtZW50PignZGlhZy1zdGF0dXMnKTtcblxuYXN5bmMgZnVuY3Rpb24gc2VuZDxUPihtc2c6IFJ1bnRpbWVNZXNzYWdlKTogUHJvbWlzZTxUPiB7XG4gIHJldHVybiBicm93c2VyLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKSBhcyBQcm9taXNlPFQ+O1xufVxuXG5mdW5jdGlvbiBzZXRTdGF0dXMoZWw6IEhUTUxFbGVtZW50LCBraW5kOiAnb2snIHwgJ2VycicgfCAnd2FybicgfCAnJywgbXNnOiBzdHJpbmcpOiB2b2lkIHtcbiAgZWwuY2xhc3NOYW1lID0ga2luZCA/IGBzdGF0dXMgJHtraW5kfWAgOiAnc3RhdHVzJztcbiAgZWwudGV4dENvbnRlbnQgPSBtc2c7XG59XG5cbmZ1bmN0aW9uIGlzV3JpdGVBdXRoRXJyb3IobWVzc2FnZTogc3RyaW5nIHwgbnVsbCk6IGJvb2xlYW4ge1xuICByZXR1cm4gKFxuICAgIHR5cGVvZiBtZXNzYWdlID09PSAnc3RyaW5nJyAmJlxuICAgIC9SZXNvdXJjZSBub3QgYWNjZXNzaWJsZSBieSBwZXJzb25hbCBhY2Nlc3MgdG9rZW58XFwvZ2l0XFwvYmxvYnN8XFwvZ2l0XFwvcmVmcy9pLnRlc3QobWVzc2FnZSlcbiAgKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZFNldHRpbmdzKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBzID0gYXdhaXQgZ2V0U2V0dGluZ3MoKTtcbiAgb3duZXJJbnB1dC52YWx1ZSA9IHMub3duZXIgfHwgREVGQVVMVF9TRVRUSU5HUy5vd25lcjtcbiAgcmVwb0lucHV0LnZhbHVlID0gcy5yZXBvIHx8IERFRkFVTFRfU0VUVElOR1MucmVwbztcbiAgYnJhbmNoSW5wdXQudmFsdWUgPSBzLmJyYW5jaCB8fCBERUZBVUxUX1NFVFRJTkdTLmJyYW5jaDtcbiAgaWYgKHMucGF0KSB7XG4gICAgcGF0SW5wdXQudmFsdWUgPSBzLnBhdDtcbiAgICBwYXRJbnB1dC5wbGFjZWhvbGRlciA9IGBcdTIwMjYke3MucGF0LnNsaWNlKC00KX1gO1xuICB9XG4gIGF3YWl0IHBhaW50Q29ubkRldGFpbCgpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBwYWludENvbm5EZXRhaWwoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGNvbnN0IHMgPSBhd2FpdCBnZXRTZXR0aW5ncygpO1xuICBjb25zdCBsaW5lczogc3RyaW5nW10gPSBbXTtcbiAgbGluZXMucHVzaChgU3RhdHVzOiAke2Nvbm4uc3RhdHVzfWApO1xuICBpZiAoY29ubi5sb2dpbikgbGluZXMucHVzaChgTG9nZ2VkIGluIGFzOiBAJHtjb25uLmxvZ2lufWApO1xuICBsaW5lcy5wdXNoKGBSZXBvc2l0b3J5OiAke3Mub3duZXIgfHwgJz8nfS8ke3MucmVwbyB8fCAnPyd9QCR7cy5icmFuY2ggfHwgJz8nfWApO1xuICBpZiAoY29ubi5jaGVja2VkQXQpIGxpbmVzLnB1c2goYExhc3QgY2hlY2tlZDogJHtjb25uLmNoZWNrZWRBdH1gKTtcbiAgaWYgKGNvbm4uc3RhdHVzID09PSAncmF0ZS1saW1pdGVkJyAmJiBjb25uLnJhdGVMaW1pdFJlc2V0QXQgIT09IG51bGwpIHtcbiAgICBjb25zdCByZXNldElzbyA9IG5ldyBEYXRlKGNvbm4ucmF0ZUxpbWl0UmVzZXRBdCAqIDEwMDApLnRvSVNPU3RyaW5nKCk7XG4gICAgY29uc3QgZGVsdGFTZWMgPSBjb25uLnJhdGVMaW1pdFJlc2V0QXQgLSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKTtcbiAgICBjb25zdCBpbkxhYmVsID1cbiAgICAgIGRlbHRhU2VjIDw9IDBcbiAgICAgICAgPyAnbW9tZW50YXJpbHknXG4gICAgICAgIDogZGVsdGFTZWMgPCA2MFxuICAgICAgICAgID8gYGluICR7ZGVsdGFTZWN9c2BcbiAgICAgICAgICA6IGRlbHRhU2VjIDwgMzYwMFxuICAgICAgICAgICAgPyBgaW4gJHtNYXRoLnJvdW5kKGRlbHRhU2VjIC8gNjApfW1gXG4gICAgICAgICAgICA6IGBpbiAke01hdGgucm91bmQoZGVsdGFTZWMgLyAzNjAwKX1oYDtcbiAgICBsaW5lcy5wdXNoKGBSYXRlIGxpbWl0IHJlc2V0czogJHtyZXNldElzb30gKCR7aW5MYWJlbH0pYCk7XG4gIH1cbiAgaWYgKGNvbm4uZXJyb3IpIGxpbmVzLnB1c2goYEVycm9yOiAke2Nvbm4uZXJyb3J9YCk7XG4gIGNvbm5EZXRhaWwudGV4dENvbnRlbnQgPSBsaW5lcy5qb2luKCdcXG4nKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcGFpbnRBY2NvdW50cygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgbGlzdCA9IGF3YWl0IGdldEFjY291bnRzKCk7XG4gIGFjY291bnRMaXN0LnJlcGxhY2VDaGlsZHJlbigpO1xuICBmb3IgKGNvbnN0IGEgb2YgbGlzdCkge1xuICAgIGNvbnN0IGxpID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGknKTtcbiAgICBjb25zdCBoYW5kbGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gICAgaGFuZGxlLmNsYXNzTmFtZSA9ICdoYW5kbGUnO1xuICAgIGhhbmRsZS50ZXh0Q29udGVudCA9IGBAJHthLmhhbmRsZX1gO1xuICAgIGNvbnN0IGxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICAgIGxhYmVsLmNsYXNzTmFtZSA9ICdsYWJlbCc7XG4gICAgbGFiZWwudGV4dENvbnRlbnQgPSBhLmxhYmVsO1xuICAgIGxpLmFwcGVuZChoYW5kbGUsIGxhYmVsKTtcbiAgICBhY2NvdW50TGlzdC5hcHBlbmQobGkpO1xuICB9XG59XG5cbmZvcm0uYWRkRXZlbnRMaXN0ZW5lcignc3VibWl0JywgYXN5bmMgKGU6IEV2ZW50KSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKTtcbiAgY29uc3QgcGF0ID0gcGF0SW5wdXQudmFsdWUudHJpbSgpO1xuICBjb25zdCBvd25lciA9IG93bmVySW5wdXQudmFsdWUudHJpbSgpO1xuICBjb25zdCByZXBvID0gcmVwb0lucHV0LnZhbHVlLnRyaW0oKTtcbiAgY29uc3QgYnJhbmNoID0gYnJhbmNoSW5wdXQudmFsdWUudHJpbSgpIHx8ICdtYWluJztcbiAgaWYgKCFwYXQgfHwgIW93bmVyIHx8ICFyZXBvKSB7XG4gICAgc2V0U3RhdHVzKHNhdmVTdGF0dXMsICdlcnInLCAnQWxsIGZpZWxkcyBhcmUgcmVxdWlyZWQuJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnJywgJ1NhdmluZ1x1MjAyNicpO1xuICBhd2FpdCB1cGRhdGVTZXR0aW5ncyh7IHBhdCwgb3duZXIsIHJlcG8sIGJyYW5jaCwgY29uZmlndXJlZEF0OiBEYXRlLm5vdygpIH0pO1xuICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJycsICdWZXJpZnlpbmdcdTIwMjYnKTtcbiAgYXdhaXQgc2VuZCh7IHR5cGU6ICd2ZXJpZnktY29ubmVjdGlvbicgfSk7XG4gIGF3YWl0IHNlbmQoeyB0eXBlOiAncmVmcmVzaC1hY2NvdW50cycgfSk7XG4gIGNvbnN0IGNvbm4gPSBhd2FpdCBnZXRDb25uZWN0aW9uKCk7XG4gIGlmIChjb25uLnN0YXR1cyA9PT0gJ29rJykge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnb2snLCBgQ29ubmVjdGVkIGFzIEAke2Nvbm4ubG9naW4gPz8gJz8nfS5gKTtcbiAgfSBlbHNlIGlmIChjb25uLnN0YXR1cyA9PT0gJ2F1dGgtZXJyb3InKSB7XG4gICAgc2V0U3RhdHVzKFxuICAgICAgc2F2ZVN0YXR1cyxcbiAgICAgICdlcnInLFxuICAgICAgaXNXcml0ZUF1dGhFcnJvcihjb25uLmVycm9yKVxuICAgICAgICA/ICdQQVQgY2FuIHJlYWQgdGhpcyByZXBvIGJ1dCBjYW5ub3Qgd3JpdGUuIFNldCBDb250ZW50czogUmVhZCAmIFdyaXRlLidcbiAgICAgICAgOiAnQXV0aCBmYWlsZWQgLSBjaGVjayB0aGUgUEFUIGFuZCBpdHMgcmVwbyBzY29wZS4nXG4gICAgKTtcbiAgfSBlbHNlIGlmIChjb25uLnN0YXR1cyA9PT0gJ3JhdGUtbGltaXRlZCcpIHtcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ3dhcm4nLCAnUmF0ZS1saW1pdGVkIFx1MjAxNCB0b2tlbiBpcyB2YWxpZCBidXQgR2l0SHViIGlzIHRocm90dGxpbmcuJyk7XG4gIH0gZWxzZSBpZiAoY29ubi5zdGF0dXMgPT09ICduZXR3b3JrLWVycm9yJykge1xuICAgIHNldFN0YXR1cyhzYXZlU3RhdHVzLCAnZXJyJywgJ05ldHdvcmsgZXJyb3IgXHUyMDE0IGNoZWNrIGNvbm5lY3Rpdml0eS4nKTtcbiAgfSBlbHNlIHtcbiAgICBzZXRTdGF0dXMoc2F2ZVN0YXR1cywgJ2VycicsIGBWZXJpZmljYXRpb246ICR7Y29ubi5zdGF0dXN9YCk7XG4gIH1cbiAgYXdhaXQgcGFpbnRDb25uRGV0YWlsKCk7XG4gIGF3YWl0IHBhaW50QWNjb3VudHMoKTtcbiAgYXdhaXQgcmVmcmVzaERpYWcoKTtcbn0pO1xuXG5yZXZlYWxCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGlmIChwYXRJbnB1dC50eXBlID09PSAncGFzc3dvcmQnKSB7XG4gICAgcGF0SW5wdXQudHlwZSA9ICd0ZXh0JztcbiAgICByZXZlYWxCdG4udGV4dENvbnRlbnQgPSAnSGlkZSc7XG4gIH0gZWxzZSB7XG4gICAgcGF0SW5wdXQudHlwZSA9ICdwYXNzd29yZCc7XG4gICAgcmV2ZWFsQnRuLnRleHRDb250ZW50ID0gJ1Nob3cnO1xuICB9XG59KTtcblxucmVmcmVzaEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgcmVmcmVzaEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZCh7IHR5cGU6ICdyZWZyZXNoLWFjY291bnRzJyB9KTtcbiAgICBhd2FpdCBwYWludEFjY291bnRzKCk7XG4gICAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICdvaycsICdBY2NvdW50cyByZWZyZXNoZWQuJyk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHNldFN0YXR1cyhkaWFnU3RhdHVzLCAnZXJyJywgYFJlZnJlc2ggZmFpbGVkOiAkeyhlcnIgYXMgRXJyb3IpLm1lc3NhZ2V9YCk7XG4gIH0gZmluYWxseSB7XG4gICAgcmVmcmVzaEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICB9XG59KTtcblxuYXN5bmMgZnVuY3Rpb24gcmVmcmVzaERpYWcoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IFtzZXR0aW5ncywgY29ubiwgYWNjb3VudHMsIGNvdW50ZXJzLCBidWZmZXJzLCBhY3Rpdml0eSwgYXJjaGl2ZVNuYXBzaG90XSA9XG4gICAgYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgZ2V0U2V0dGluZ3MoKSxcbiAgICAgIGdldENvbm5lY3Rpb24oKSxcbiAgICAgIGdldEFjY291bnRzKCksXG4gICAgICBnZXRDb3VudGVycygpLFxuICAgICAgZ2V0UnVuQnVmZmVycygpLFxuICAgICAgZ2V0QWN0aXZpdHkoKSxcbiAgICAgIGdldEFyY2hpdmVTbmFwc2hvdCgpLFxuICAgIF0pO1xuICBjb25zdCByZWRhY3RlZEJ1ZmZlcnMgPSBPYmplY3QuZnJvbUVudHJpZXMoXG4gICAgT2JqZWN0LmVudHJpZXMoYnVmZmVycykubWFwKChbaywgYl0pID0+IFtcbiAgICAgIGssXG4gICAgICB7XG4gICAgICAgIHJ1bl9pZDogYi5ydW5faWQsXG4gICAgICAgIHN0YXJ0ZWRfYXQ6IGIuc3RhcnRlZF9hdCxcbiAgICAgICAgbGFzdF9jYXB0dXJlX2F0OiBiLmxhc3RfY2FwdHVyZV9hdCxcbiAgICAgICAgdHdlZXRzX2NvdW50OiBPYmplY3Qua2V5cyhiLnR3ZWV0c19ieV9pZCkubGVuZ3RoLFxuICAgICAgICBvYnNlcnZlZF9jb3VudDogYi50d2VldF9pZHNfb2JzZXJ2ZWQubGVuZ3RoLFxuICAgICAgICBlbmRwb2ludHNfc2VlbjogYi5lbmRwb2ludHNfc2VlbixcbiAgICAgICAgc291cmNlX3VybDogYi5zb3VyY2VfdXJsLFxuICAgICAgfSxcbiAgICBdKVxuICApO1xuICBjb25zdCBkdW1wID0ge1xuICAgIHZlcnNpb246IGJyb3dzZXIucnVudGltZS5nZXRNYW5pZmVzdCgpLnZlcnNpb24sXG4gICAgdXNlcl9hZ2VudDogbmF2aWdhdG9yLnVzZXJBZ2VudCxcbiAgICBzZXR0aW5nczoge1xuICAgICAgb3duZXI6IHNldHRpbmdzLm93bmVyLFxuICAgICAgcmVwbzogc2V0dGluZ3MucmVwbyxcbiAgICAgIGJyYW5jaDogc2V0dGluZ3MuYnJhbmNoLFxuICAgICAgYXV0b0NhcHR1cmU6IHNldHRpbmdzLmF1dG9DYXB0dXJlLFxuICAgICAgdXBkYXRlRXhpc3Rpbmc6IHNldHRpbmdzLnVwZGF0ZUV4aXN0aW5nLFxuICAgICAgY29uZmlndXJlZEF0OiBzZXR0aW5ncy5jb25maWd1cmVkQXQsXG4gICAgICBwYXRTZXQ6IHNldHRpbmdzLnBhdC5sZW5ndGggPiAwLFxuICAgICAgcGF0U3VmZml4OiBzZXR0aW5ncy5wYXQubGVuZ3RoID49IDQgPyBzZXR0aW5ncy5wYXQuc2xpY2UoLTQpIDogJycsXG4gICAgfSxcbiAgICBjb25uZWN0aW9uOiBjb25uLFxuICAgIGFjY291bnRzLFxuICAgIGNvdW50ZXJzLFxuICAgIGFyY2hpdmVTbmFwc2hvdDogYXJjaGl2ZVNuYXBzaG90XG4gICAgICA/IHtcbiAgICAgICAgICBnZW5lcmF0ZWRfYXQ6IGFyY2hpdmVTbmFwc2hvdC5nZW5lcmF0ZWRfYXQsXG4gICAgICAgICAgZmV0Y2hlZF9hdDogYXJjaGl2ZVNuYXBzaG90LmZldGNoZWRfYXQsXG4gICAgICAgICAgYWNjb3VudHM6IE9iamVjdC5rZXlzKGFyY2hpdmVTbmFwc2hvdC5hY2NvdW50cykubGVuZ3RoLFxuICAgICAgICB9XG4gICAgICA6IG51bGwsXG4gICAgcnVuQnVmZmVyczogcmVkYWN0ZWRCdWZmZXJzLFxuICAgIGFjdGl2aXR5X3RhaWxfc2l6ZTogYWN0aXZpdHkubGVuZ3RoLFxuICAgIGFjdGl2aXR5X3JlY2VudDogYWN0aXZpdHkuc2xpY2UoMCwgMzApLFxuICB9O1xuICBkaWFnQm94LnZhbHVlID0gSlNPTi5zdHJpbmdpZnkoZHVtcCwgbnVsbCwgMik7XG59XG5cbmNvcHlEaWFnQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChkaWFnQm94LnZhbHVlKTtcbiAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICdvaycsICdDb3BpZWQgZGlhZ25vc3RpY3MgdG8gY2xpcGJvYXJkLicpO1xufSk7XG5cbmNsZWFyU3RvcmFnZUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgY29uc3Qgb2sgPSB3aW5kb3cuY29uZmlybShcbiAgICAnQ2xlYXIgZXh0ZW5zaW9uIHN0b3JhZ2U/IFRoaXMgZXJhc2VzIHlvdXIgUEFULCBzZXR0aW5ncywgY291bnRlcnMsIGJ1ZmZlcmVkIGNhcHR1cmVzLCBhbmQgYWN0aXZpdHkgdGFpbC4gVGhlcmUgaXMgbm8gdW5kby4nXG4gICk7XG4gIGlmICghb2spIHJldHVybjtcbiAgYXdhaXQgY2xlYXJBbGwoKTtcbiAgc2V0U3RhdHVzKGRpYWdTdGF0dXMsICd3YXJuJywgJ1N0b3JhZ2UgY2xlYXJlZC4nKTtcbiAgYXdhaXQgbG9hZFNldHRpbmdzKCk7XG4gIGF3YWl0IHBhaW50QWNjb3VudHMoKTtcbiAgYXdhaXQgcmVmcmVzaERpYWcoKTtcbn0pO1xuXG52b2lkIGxvYWRTZXR0aW5ncygpO1xudm9pZCBwYWludEFjY291bnRzKCk7XG52b2lkIHJlZnJlc2hEaWFnKCk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLEtBQUs7QUFBQSxFQUNMLE9BQU87QUFBQSxFQUNQLE1BQU07QUFBQTtBQUFBO0FBQUEsRUFHTixRQUFRO0FBQUEsRUFDUixTQUFTO0FBQUEsRUFDVCxhQUFhO0FBQUEsRUFDYixjQUFjO0FBQUEsRUFDZCx1QkFBdUI7QUFBQSxFQUN2QixnQkFBZ0I7QUFBQSxFQUNoQixzQkFBc0I7QUFDeEI7QUFPTyxJQUFNLG9CQUFxQztBQUFBLEVBQ2hELEVBQUUsUUFBUSxVQUFVLE9BQU8sbUNBQW1DLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxVQUFVLE9BQU8sNENBQTRDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxPQUFPLE9BQU8sc0NBQXNDLFVBQVUsT0FBTztBQUFBLEVBQy9FLEVBQUUsUUFBUSxTQUFTLE9BQU8sNkNBQTZDLFVBQVUsT0FBTztBQUFBLEVBQ3hGLEVBQUUsUUFBUSxjQUFjLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUFBLEVBQ25FLEVBQUUsUUFBUSxZQUFZLE9BQU8sK0JBQStCLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sa0NBQWtDLFVBQVUsT0FBTztBQUFBLEVBQzdFLEVBQUUsUUFBUSxTQUFTLE9BQU8sNEJBQTRCLFVBQVUsT0FBTztBQUFBLEVBQ3ZFLEVBQUUsUUFBUSxtQkFBbUIsT0FBTyxxQkFBcUIsVUFBVSxPQUFPO0FBQUEsRUFDMUUsRUFBRSxRQUFRLFlBQVksT0FBTyxrQkFBa0IsVUFBVSxPQUFPO0FBQUEsRUFDaEUsRUFBRSxRQUFRLGtCQUFrQixPQUFPLGtCQUFrQixVQUFVLE9BQU87QUFBQSxFQUN0RSxFQUFFLFFBQVEsZ0JBQWdCLE9BQU8sbUJBQW1CLFVBQVUsT0FBTztBQUN2RTtBQThETyxJQUFNLGdDQUFnQyxLQUFLLEtBQUs7OztBQ3pFdkQsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0I7QUFFeEIsSUFBSSxrQkFBb0M7QUFDeEMsSUFBSSxzQkFBcUM7QUFFekMsU0FBUyxTQUFTLEtBQXlCO0FBQ3pDLE1BQUksSUFBSTtBQUNSLGFBQVcsS0FBSyxJQUFLLE1BQUssT0FBTyxhQUFhLENBQUM7QUFDL0MsU0FBTyxLQUFLLENBQUM7QUFDZjtBQUVBLFNBQVMsV0FBVyxHQUF1QjtBQUN6QyxRQUFNLE1BQU0sS0FBSyxDQUFDO0FBQ2xCLFFBQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxNQUFNO0FBQ3JDLFdBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUssS0FBSSxDQUFDLElBQUksSUFBSSxXQUFXLENBQUM7QUFDOUQsU0FBTztBQUNUO0FBRUEsZUFBZSxtQkFBbUU7QUFDaEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDL0QsUUFBTSxJQUFJLE9BQU8sZ0JBQWdCO0FBQ2pDLE1BQUksT0FBTyxNQUFNLFlBQVksRUFBRSxTQUFTLEdBQUc7QUFDekMsV0FBTyxFQUFFLFNBQVMsR0FBRyxNQUFNLFdBQVcsQ0FBQyxFQUFFO0FBQUEsRUFDM0M7QUFDQSxRQUFNLE9BQU8sT0FBTyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUUsQ0FBQztBQUN0RCxRQUFNLFVBQVUsU0FBUyxJQUFJO0FBQzdCLFFBQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO0FBQy9ELFNBQU8sRUFBRSxTQUFTLEtBQUs7QUFDekI7QUFFQSxlQUFlLFlBQWdDO0FBQzdDLFFBQU0sRUFBRSxTQUFTLEtBQUssSUFBSSxNQUFNLGlCQUFpQjtBQUNqRCxNQUFJLG9CQUFvQixRQUFRLHdCQUF3QixTQUFTO0FBQy9ELFdBQU87QUFBQSxFQUNUO0FBQ0EsUUFBTSxPQUFPLElBQUksWUFBWSxFQUFFO0FBQUEsSUFDN0IsR0FBRyxRQUFRLFFBQVEsRUFBRSxJQUFJLFFBQVEsUUFBUSxZQUFZLEVBQUUsT0FBTztBQUFBLEVBQ2hFO0FBQ0EsUUFBTSxXQUFXLElBQUksV0FBVyxLQUFLLFNBQVMsS0FBSyxNQUFNO0FBQ3pELFdBQVMsSUFBSSxNQUFNLENBQUM7QUFDcEIsV0FBUyxJQUFJLE1BQU0sS0FBSyxNQUFNO0FBQzlCLFFBQU0sT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPLFdBQVcsUUFBUTtBQUMzRCxRQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU8sVUFBVSxPQUFPLE1BQU0sRUFBRSxNQUFNLFVBQVUsR0FBRyxPQUFPO0FBQUEsSUFDakY7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBQ0Qsb0JBQWtCO0FBQ2xCLHdCQUFzQjtBQUN0QixTQUFPO0FBQ1Q7QUFFTyxTQUFTLGVBQWUsR0FBb0I7QUFDakQsU0FBTyxFQUFFLFdBQVcsZUFBZTtBQUNyQztBQUVBLGVBQXNCLFdBQVcsV0FBb0M7QUFDbkUsTUFBSSxDQUFDLFVBQVcsUUFBTztBQUN2QixRQUFNLE1BQU0sTUFBTSxVQUFVO0FBQzVCLFFBQU0sS0FBSyxPQUFPLGdCQUFnQixJQUFJLFdBQVcsRUFBRSxDQUFDO0FBQ3BELFFBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLElBQzdCLEVBQUUsTUFBTSxXQUFXLEdBQUc7QUFBQSxJQUN0QjtBQUFBLElBQ0EsSUFBSSxZQUFZLEVBQUUsT0FBTyxTQUFTO0FBQUEsRUFDcEM7QUFDQSxTQUFPLEdBQUcsZUFBZSxHQUFHLFNBQVMsRUFBRSxDQUFDLElBQUksU0FBUyxJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDMUU7QUFFQSxlQUFzQixXQUFXLFVBQW1DO0FBQ2xFLE1BQUksQ0FBQyxTQUFVLFFBQU87QUFHdEIsTUFBSSxDQUFDLFNBQVMsV0FBVyxlQUFlLEVBQUcsUUFBTztBQUNsRCxRQUFNLFFBQVEsU0FBUyxNQUFNLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxHQUFHO0FBQzlELE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUMvQixRQUFNLENBQUMsT0FBTyxLQUFLLElBQUk7QUFDdkIsTUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFPLFFBQU87QUFDN0IsTUFBSTtBQUNGLFVBQU0sTUFBTSxNQUFNLFVBQVU7QUFDNUIsVUFBTSxLQUFLLFdBQVcsS0FBSztBQUMzQixVQUFNLEtBQUssV0FBVyxLQUFLO0FBQzNCLFVBQU0sS0FBSyxNQUFNLE9BQU8sT0FBTztBQUFBLE1BQzdCLEVBQUUsTUFBTSxXQUFXLEdBQXVCO0FBQUEsTUFDMUM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUNBLFdBQU8sSUFBSSxZQUFZLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDcEMsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7OztBQ1hBLElBQU0scUJBQXNDO0FBQUEsRUFDMUMsUUFBUTtBQUFBLEVBQ1IsT0FBTztBQUFBLEVBQ1AsV0FBVztBQUFBLEVBQ1gsT0FBTztBQUFBLEVBQ1AsZUFBZTtBQUFBLEVBQ2Ysd0JBQXdCO0FBQUEsRUFDeEIsa0JBQWtCO0FBQ3BCO0FBRUEsSUFBTSxXQUF5QjtBQUFBLEVBQzdCLFVBQVUsRUFBRSxHQUFHLGlCQUFpQjtBQUFBLEVBQ2hDLFVBQVUsQ0FBQyxHQUFHLGlCQUFpQjtBQUFBLEVBQy9CLHFCQUFxQjtBQUFBLEVBQ3JCLGlCQUFpQjtBQUFBLEVBQ2pCLFlBQVksRUFBRSxHQUFHLG1CQUFtQjtBQUFBLEVBQ3BDLFVBQVUsQ0FBQztBQUFBLEVBQ1gsWUFBWSxDQUFDO0FBQUEsRUFDYixVQUFVLENBQUM7QUFBQSxFQUNYLHNCQUFzQixDQUFDO0FBQUEsRUFDdkIsZ0JBQWdCLENBQUM7QUFBQSxFQUNqQixjQUFjLENBQUM7QUFBQSxFQUNmLGlCQUFpQixDQUFDO0FBQUEsRUFDbEIsaUJBQWlCLENBQUM7QUFBQSxFQUNsQixnQkFBZ0IsQ0FBQztBQUFBLEVBQ2pCLGdCQUFnQjtBQUFBLEVBQ2hCLG1CQUFtQjtBQUFBLEVBQ25CLG1CQUFtQjtBQUFBLEVBQ25CLG1CQUFtQjtBQUNyQjtBQUVBLGVBQWUsT0FBcUMsS0FBa0M7QUFDcEYsUUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxHQUFHO0FBQ2xELFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsTUFBSSxVQUFVLFFBQVc7QUFDdkIsV0FBTyxnQkFBZ0IsU0FBUyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUNBLFNBQU87QUFDVDtBQUVBLGVBQWUsT0FBcUMsS0FBUSxPQUF1QztBQUNqRyxRQUFNLFFBQVEsUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUM7QUFDbEQ7QUFJQSxlQUFzQixjQUFpQztBQUtyRCxRQUFNLFNBQVMsTUFBTSxPQUFPLFVBQVU7QUFDdEMsUUFBTSxTQUFTLEVBQUUsR0FBRyxrQkFBa0IsR0FBRyxPQUFPO0FBQ2hELE1BQUksT0FBTyxPQUFPLGVBQWUsT0FBTyxHQUFHLEdBQUc7QUFDNUMsUUFBSTtBQUNGLGFBQU8sTUFBTSxNQUFNLFdBQVcsT0FBTyxHQUFHO0FBQUEsSUFDMUMsUUFBUTtBQUNOLGFBQU8sTUFBTTtBQUFBLElBQ2Y7QUFBQSxFQUNGO0FBQ0EsU0FBTztBQUNUO0FBQ0EsZUFBc0IsWUFBWSxHQUE0QjtBQUc1RCxRQUFNLFVBQW9CLEVBQUUsR0FBRyxFQUFFO0FBQ2pDLE1BQUksUUFBUSxPQUFPLENBQUMsZUFBZSxRQUFRLEdBQUcsR0FBRztBQUMvQyxZQUFRLE1BQU0sTUFBTSxXQUFXLFFBQVEsR0FBRztBQUFBLEVBQzVDO0FBQ0EsUUFBTSxPQUFPLFlBQVksT0FBTztBQUNsQztBQUNBLGVBQXNCLGVBQWUsT0FBNkM7QUFDaEYsUUFBTSxNQUFNLE1BQU0sWUFBWTtBQUM5QixRQUFNLE9BQU8sRUFBRSxHQUFHLEtBQUssR0FBRyxNQUFNO0FBQ2hDLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFNBQU87QUFDVDtBQUlBLGVBQXNCLGNBQXdDO0FBQzVELFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBYUEsZUFBc0IscUJBQXNEO0FBQzFFLFNBQU8sT0FBTyxpQkFBaUI7QUFDakM7QUFRQSxlQUFzQixnQkFBMEM7QUFDOUQsUUFBTSxJQUFJLE1BQU0sT0FBTyxZQUFZO0FBRW5DLFFBQU0sTUFBdUI7QUFBQSxJQUMzQixHQUFHO0FBQUEsSUFDSCxlQUFlLEVBQUUsa0JBQWtCLFNBQVksT0FBTyxFQUFFO0FBQUEsSUFDeEQsd0JBQ0UsRUFBRSwyQkFBMkIsU0FBWSxPQUFPLEVBQUU7QUFBQSxJQUNwRCxrQkFBa0IsRUFBRSxxQkFBcUIsU0FBWSxPQUFPLEVBQUU7QUFBQSxFQUNoRTtBQUNBLFNBQU87QUFDVDtBQVdBLGVBQXNCLGNBQXVEO0FBQzNFLFNBQU8sT0FBTyxVQUFVO0FBQzFCO0FBNkJBLGVBQXNCLGdCQUFvRDtBQUN4RSxTQUFPLE9BQU8sWUFBWTtBQUM1QjtBQXFCQSxlQUFzQixjQUFtQztBQUN2RCxTQUFPLE9BQU8sVUFBVTtBQUMxQjtBQXFZQSxlQUFzQixXQUEwQjtBQUM5QyxRQUFNLFFBQVEsUUFBUSxNQUFNLE1BQU07QUFDcEM7OztBQy9vQkEsSUFBTSxJQUFJLENBQXNDLE9BQWtCO0FBQ2hFLFFBQU0sS0FBSyxTQUFTLGVBQWUsRUFBRTtBQUNyQyxNQUFJLENBQUMsR0FBSSxPQUFNLElBQUksTUFBTSxvQkFBb0IsRUFBRSxFQUFFO0FBQ2pELFNBQU87QUFDVDtBQUVBLElBQU0sT0FBTyxFQUFtQixlQUFlO0FBQy9DLElBQU0sYUFBYSxFQUFvQixPQUFPO0FBQzlDLElBQU0sWUFBWSxFQUFvQixNQUFNO0FBQzVDLElBQU0sY0FBYyxFQUFvQixRQUFRO0FBQ2hELElBQU0sV0FBVyxFQUFvQixLQUFLO0FBQzFDLElBQU0sWUFBWSxFQUFxQixZQUFZO0FBQ25ELElBQU0sYUFBYSxFQUFtQixhQUFhO0FBQ25ELElBQU0sYUFBYSxFQUFFLGFBQWE7QUFDbEMsSUFBTSxjQUFjLEVBQW9CLGtCQUFrQjtBQUMxRCxJQUFNLGFBQWEsRUFBcUIsa0JBQWtCO0FBQzFELElBQU0sVUFBVSxFQUF1QixhQUFhO0FBQ3BELElBQU0sY0FBYyxFQUFxQixrQkFBa0I7QUFDM0QsSUFBTSxrQkFBa0IsRUFBcUIsZUFBZTtBQUM1RCxJQUFNLGFBQWEsRUFBbUIsYUFBYTtBQUVuRCxlQUFlLEtBQVEsS0FBaUM7QUFDdEQsU0FBTyxRQUFRLFFBQVEsWUFBWSxHQUFHO0FBQ3hDO0FBRUEsU0FBUyxVQUFVLElBQWlCLE1BQWtDLEtBQW1CO0FBQ3ZGLEtBQUcsWUFBWSxPQUFPLFVBQVUsSUFBSSxLQUFLO0FBQ3pDLEtBQUcsY0FBYztBQUNuQjtBQUVBLFNBQVMsaUJBQWlCLFNBQWlDO0FBQ3pELFNBQ0UsT0FBTyxZQUFZLFlBQ25CLDZFQUE2RSxLQUFLLE9BQU87QUFFN0Y7QUFFQSxlQUFlLGVBQThCO0FBQzNDLFFBQU0sSUFBSSxNQUFNLFlBQVk7QUFDNUIsYUFBVyxRQUFRLEVBQUUsU0FBUyxpQkFBaUI7QUFDL0MsWUFBVSxRQUFRLEVBQUUsUUFBUSxpQkFBaUI7QUFDN0MsY0FBWSxRQUFRLEVBQUUsVUFBVSxpQkFBaUI7QUFDakQsTUFBSSxFQUFFLEtBQUs7QUFDVCxhQUFTLFFBQVEsRUFBRTtBQUNuQixhQUFTLGNBQWMsU0FBSSxFQUFFLElBQUksTUFBTSxFQUFFLENBQUM7QUFBQSxFQUM1QztBQUNBLFFBQU0sZ0JBQWdCO0FBQ3hCO0FBRUEsZUFBZSxrQkFBaUM7QUFDOUMsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxRQUFNLElBQUksTUFBTSxZQUFZO0FBQzVCLFFBQU0sUUFBa0IsQ0FBQztBQUN6QixRQUFNLEtBQUssV0FBVyxLQUFLLE1BQU0sRUFBRTtBQUNuQyxNQUFJLEtBQUssTUFBTyxPQUFNLEtBQUssa0JBQWtCLEtBQUssS0FBSyxFQUFFO0FBQ3pELFFBQU0sS0FBSyxlQUFlLEVBQUUsU0FBUyxHQUFHLElBQUksRUFBRSxRQUFRLEdBQUcsSUFBSSxFQUFFLFVBQVUsR0FBRyxFQUFFO0FBQzlFLE1BQUksS0FBSyxVQUFXLE9BQU0sS0FBSyxpQkFBaUIsS0FBSyxTQUFTLEVBQUU7QUFDaEUsTUFBSSxLQUFLLFdBQVcsa0JBQWtCLEtBQUsscUJBQXFCLE1BQU07QUFDcEUsVUFBTSxXQUFXLElBQUksS0FBSyxLQUFLLG1CQUFtQixHQUFJLEVBQUUsWUFBWTtBQUNwRSxVQUFNLFdBQVcsS0FBSyxtQkFBbUIsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFDckUsVUFBTSxVQUNKLFlBQVksSUFDUixnQkFDQSxXQUFXLEtBQ1QsTUFBTSxRQUFRLE1BQ2QsV0FBVyxPQUNULE1BQU0sS0FBSyxNQUFNLFdBQVcsRUFBRSxDQUFDLE1BQy9CLE1BQU0sS0FBSyxNQUFNLFdBQVcsSUFBSSxDQUFDO0FBQzNDLFVBQU0sS0FBSyxzQkFBc0IsUUFBUSxLQUFLLE9BQU8sR0FBRztBQUFBLEVBQzFEO0FBQ0EsTUFBSSxLQUFLLE1BQU8sT0FBTSxLQUFLLFVBQVUsS0FBSyxLQUFLLEVBQUU7QUFDakQsYUFBVyxjQUFjLE1BQU0sS0FBSyxJQUFJO0FBQzFDO0FBRUEsZUFBZSxnQkFBK0I7QUFDNUMsUUFBTSxPQUFPLE1BQU0sWUFBWTtBQUMvQixjQUFZLGdCQUFnQjtBQUM1QixhQUFXLEtBQUssTUFBTTtBQUNwQixVQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsVUFBTSxTQUFTLFNBQVMsY0FBYyxNQUFNO0FBQzVDLFdBQU8sWUFBWTtBQUNuQixXQUFPLGNBQWMsSUFBSSxFQUFFLE1BQU07QUFDakMsVUFBTSxRQUFRLFNBQVMsY0FBYyxNQUFNO0FBQzNDLFVBQU0sWUFBWTtBQUNsQixVQUFNLGNBQWMsRUFBRTtBQUN0QixPQUFHLE9BQU8sUUFBUSxLQUFLO0FBQ3ZCLGdCQUFZLE9BQU8sRUFBRTtBQUFBLEVBQ3ZCO0FBQ0Y7QUFFQSxLQUFLLGlCQUFpQixVQUFVLE9BQU8sTUFBYTtBQUNsRCxJQUFFLGVBQWU7QUFDakIsUUFBTSxNQUFNLFNBQVMsTUFBTSxLQUFLO0FBQ2hDLFFBQU0sUUFBUSxXQUFXLE1BQU0sS0FBSztBQUNwQyxRQUFNLE9BQU8sVUFBVSxNQUFNLEtBQUs7QUFDbEMsUUFBTSxTQUFTLFlBQVksTUFBTSxLQUFLLEtBQUs7QUFDM0MsTUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsTUFBTTtBQUMzQixjQUFVLFlBQVksT0FBTywwQkFBMEI7QUFDdkQ7QUFBQSxFQUNGO0FBQ0EsWUFBVSxZQUFZLElBQUksY0FBUztBQUNuQyxRQUFNLGVBQWUsRUFBRSxLQUFLLE9BQU8sTUFBTSxRQUFRLGNBQWMsS0FBSyxJQUFJLEVBQUUsQ0FBQztBQUMzRSxZQUFVLFlBQVksSUFBSSxpQkFBWTtBQUN0QyxRQUFNLEtBQUssRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ3hDLFFBQU0sS0FBSyxFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDdkMsUUFBTSxPQUFPLE1BQU0sY0FBYztBQUNqQyxNQUFJLEtBQUssV0FBVyxNQUFNO0FBQ3hCLGNBQVUsWUFBWSxNQUFNLGlCQUFpQixLQUFLLFNBQVMsR0FBRyxHQUFHO0FBQUEsRUFDbkUsV0FBVyxLQUFLLFdBQVcsY0FBYztBQUN2QztBQUFBLE1BQ0U7QUFBQSxNQUNBO0FBQUEsTUFDQSxpQkFBaUIsS0FBSyxLQUFLLElBQ3ZCLHlFQUNBO0FBQUEsSUFDTjtBQUFBLEVBQ0YsV0FBVyxLQUFLLFdBQVcsZ0JBQWdCO0FBQ3pDLGNBQVUsWUFBWSxRQUFRLDhEQUF5RDtBQUFBLEVBQ3pGLFdBQVcsS0FBSyxXQUFXLGlCQUFpQjtBQUMxQyxjQUFVLFlBQVksT0FBTywwQ0FBcUM7QUFBQSxFQUNwRSxPQUFPO0FBQ0wsY0FBVSxZQUFZLE9BQU8saUJBQWlCLEtBQUssTUFBTSxFQUFFO0FBQUEsRUFDN0Q7QUFDQSxRQUFNLGdCQUFnQjtBQUN0QixRQUFNLGNBQWM7QUFDcEIsUUFBTSxZQUFZO0FBQ3BCLENBQUM7QUFFRCxVQUFVLGlCQUFpQixTQUFTLE1BQU07QUFDeEMsTUFBSSxTQUFTLFNBQVMsWUFBWTtBQUNoQyxhQUFTLE9BQU87QUFDaEIsY0FBVSxjQUFjO0FBQUEsRUFDMUIsT0FBTztBQUNMLGFBQVMsT0FBTztBQUNoQixjQUFVLGNBQWM7QUFBQSxFQUMxQjtBQUNGLENBQUM7QUFFRCxXQUFXLGlCQUFpQixTQUFTLFlBQVk7QUFDL0MsYUFBVyxXQUFXO0FBQ3RCLE1BQUk7QUFDRixVQUFNLEtBQUssRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3ZDLFVBQU0sY0FBYztBQUNwQixjQUFVLFlBQVksTUFBTSxxQkFBcUI7QUFBQSxFQUNuRCxTQUFTLEtBQUs7QUFDWixjQUFVLFlBQVksT0FBTyxtQkFBb0IsSUFBYyxPQUFPLEVBQUU7QUFBQSxFQUMxRSxVQUFFO0FBQ0EsZUFBVyxXQUFXO0FBQUEsRUFDeEI7QUFDRixDQUFDO0FBRUQsZUFBZSxjQUE2QjtBQUMxQyxRQUFNLENBQUMsVUFBVSxNQUFNLFVBQVUsVUFBVSxTQUFTLFVBQVUsZUFBZSxJQUMzRSxNQUFNLFFBQVEsSUFBSTtBQUFBLElBQ2hCLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxJQUNaLFlBQVk7QUFBQSxJQUNaLGNBQWM7QUFBQSxJQUNkLFlBQVk7QUFBQSxJQUNaLG1CQUFtQjtBQUFBLEVBQ3JCLENBQUM7QUFDSCxRQUFNLGtCQUFrQixPQUFPO0FBQUEsSUFDN0IsT0FBTyxRQUFRLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUFBLE1BQ3RDO0FBQUEsTUFDQTtBQUFBLFFBQ0UsUUFBUSxFQUFFO0FBQUEsUUFDVixZQUFZLEVBQUU7QUFBQSxRQUNkLGlCQUFpQixFQUFFO0FBQUEsUUFDbkIsY0FBYyxPQUFPLEtBQUssRUFBRSxZQUFZLEVBQUU7QUFBQSxRQUMxQyxnQkFBZ0IsRUFBRSxtQkFBbUI7QUFBQSxRQUNyQyxnQkFBZ0IsRUFBRTtBQUFBLFFBQ2xCLFlBQVksRUFBRTtBQUFBLE1BQ2hCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQU0sT0FBTztBQUFBLElBQ1gsU0FBUyxRQUFRLFFBQVEsWUFBWSxFQUFFO0FBQUEsSUFDdkMsWUFBWSxVQUFVO0FBQUEsSUFDdEIsVUFBVTtBQUFBLE1BQ1IsT0FBTyxTQUFTO0FBQUEsTUFDaEIsTUFBTSxTQUFTO0FBQUEsTUFDZixRQUFRLFNBQVM7QUFBQSxNQUNqQixhQUFhLFNBQVM7QUFBQSxNQUN0QixnQkFBZ0IsU0FBUztBQUFBLE1BQ3pCLGNBQWMsU0FBUztBQUFBLE1BQ3ZCLFFBQVEsU0FBUyxJQUFJLFNBQVM7QUFBQSxNQUM5QixXQUFXLFNBQVMsSUFBSSxVQUFVLElBQUksU0FBUyxJQUFJLE1BQU0sRUFBRSxJQUFJO0FBQUEsSUFDakU7QUFBQSxJQUNBLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQTtBQUFBLElBQ0EsaUJBQWlCLGtCQUNiO0FBQUEsTUFDRSxjQUFjLGdCQUFnQjtBQUFBLE1BQzlCLFlBQVksZ0JBQWdCO0FBQUEsTUFDNUIsVUFBVSxPQUFPLEtBQUssZ0JBQWdCLFFBQVEsRUFBRTtBQUFBLElBQ2xELElBQ0E7QUFBQSxJQUNKLFlBQVk7QUFBQSxJQUNaLG9CQUFvQixTQUFTO0FBQUEsSUFDN0IsaUJBQWlCLFNBQVMsTUFBTSxHQUFHLEVBQUU7QUFBQSxFQUN2QztBQUNBLFVBQVEsUUFBUSxLQUFLLFVBQVUsTUFBTSxNQUFNLENBQUM7QUFDOUM7QUFFQSxZQUFZLGlCQUFpQixTQUFTLFlBQVk7QUFDaEQsUUFBTSxVQUFVLFVBQVUsVUFBVSxRQUFRLEtBQUs7QUFDakQsWUFBVSxZQUFZLE1BQU0sa0NBQWtDO0FBQ2hFLENBQUM7QUFFRCxnQkFBZ0IsaUJBQWlCLFNBQVMsWUFBWTtBQUNwRCxRQUFNLEtBQUssT0FBTztBQUFBLElBQ2hCO0FBQUEsRUFDRjtBQUNBLE1BQUksQ0FBQyxHQUFJO0FBQ1QsUUFBTSxTQUFTO0FBQ2YsWUFBVSxZQUFZLFFBQVEsa0JBQWtCO0FBQ2hELFFBQU0sYUFBYTtBQUNuQixRQUFNLGNBQWM7QUFDcEIsUUFBTSxZQUFZO0FBQ3BCLENBQUM7QUFFRCxLQUFLLGFBQWE7QUFDbEIsS0FBSyxjQUFjO0FBQ25CLEtBQUssWUFBWTsiLAogICJuYW1lcyI6IFtdCn0K
